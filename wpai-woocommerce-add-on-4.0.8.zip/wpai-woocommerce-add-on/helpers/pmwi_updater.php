<?php

function pmwi_edd_item_name() {
	return 'WooCommerce Add-On';
}

// The updater up to 4.0.7 cached under the SDK's key without a version stamp, which the SDK trusts until it expires.
function pmwi_forget_legacy_update_cache($plugin_file) {
	if (get_option('pmwi_legacy_update_cache_cleared') === PMWI_VERSION) {
		return;
	}

	$cache_key = md5('edd_plugin_' . sanitize_key(plugin_basename($plugin_file)) . '_version_info');

	delete_transient($cache_key);
	delete_option('wpai-woocommerce-add-on_' . $cache_key);
	delete_option('wpai-woocommerce-add-on_timeout_' . $cache_key);
	update_option('pmwi_legacy_update_cache_cleared', PMWI_VERSION, true);
}

function pmwi_updater($plugin_file) {
	$options = get_option('PMXI_Plugin_Options');

	if (!empty($options['info_api_url_new'])) {
		$api_url = $options['info_api_url_new'];
	} elseif (!empty($options['info_api_url'])) {
		$api_url = $options['info_api_url'];
	} else {
		return null;
	}

	// Composer's classmap would include a missing file with a warning on every load.
	if (!is_file(dirname(__DIR__) . '/vendor-prefixed/soflyy/updater/src/Updater.php') || !class_exists('\PMWI_Vendor\Soflyy\Updater\Updater')) {
		return null;
	}

	require_once dirname(__DIR__) . '/classes/updater.php';

	pmwi_forget_legacy_update_cache($plugin_file);

	return new PMWI_Updater($api_url, $plugin_file, array(
		'version'   => PMWI_VERSION,
		'item_name' => pmwi_edd_item_name(),
		'author'    => 'Soflyy',
	));
}
