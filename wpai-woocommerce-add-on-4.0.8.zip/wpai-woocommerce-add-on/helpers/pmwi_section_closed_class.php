<?php

if ( ! function_exists('pmwi_has_mapped_field') ) {
	/**
	 * Whether any of $keys in $values holds a value bound to the import file. For
	 * fields whose default is non-empty, where a literal is indistinguishable from
	 * an untouched option.
	 *
	 * @param array $values
	 * @param array $keys
	 * @return bool
	 */
	function pmwi_has_mapped_field($values, $keys) {
		foreach ($keys as $key) {
			if ( isset($values[$key]) && wp_all_import_has_template_token($values[$key]) ) {
				return TRUE;
			}
		}
		return FALSE;
	}
}

if ( ! function_exists('pmwi_has_filled_field') ) {
	/**
	 * Whether any of $keys in $values is filled. Only for free text whose default is
	 * empty, where filling it at all is deliberate and a literal is as much a mapping
	 * as a token.
	 *
	 * @param array $values
	 * @param array $keys
	 * @return bool
	 */
	function pmwi_has_filled_field($values, $keys) {
		foreach ($keys as $key) {
			if ( isset($values[$key]) && wp_all_import_has_mapped_value($values[$key]) ) {
				return TRUE;
			}
		}
		return FALSE;
	}
}

if ( ! function_exists('pmwi_has_mapped_choice') ) {
	/**
	 * Whether a mode control sits on the choice that reveals an XPath field and that
	 * field is filled. $pairs maps the mode key to its companion field.
	 *
	 * @param array  $values
	 * @param array  $pairs
	 * @param string $mode Value the mode control takes for the XPath choice.
	 * @return bool
	 */
	function pmwi_has_mapped_choice($values, $pairs, $mode) {
		foreach ($pairs as $key => $companion) {
			if ( isset($values[$key]) && $mode == $values[$key]
				&& isset($values[$companion]) && wp_all_import_is_mapped_value($values[$companion]) ) {
				return TRUE;
			}
		}
		return FALSE;
	}
}

if ( ! function_exists('pmwi_first_repeater_row') ) {
	/**
	 * Whether a repeater row the user explicitly filled in exists. Only the first row is
	 * rendered on step 3; the rest are added client side.
	 *
	 * @param array $order
	 * @param string $key
	 * @return array
	 */
	function pmwi_first_repeater_row($order, $key) {
		$rows = ( isset($order[$key]) && is_array($order[$key]) ) ? $order[$key] : array();
		$row = $rows ? array_shift($rows) : array();
		return is_array($row) ? $row : array();
	}
}

if ( ! function_exists('pmwi_section_has_mapping') ) {
	/**
	 * Whether a step 3 section holds at least one value the user bound to their import
	 * file, as opposed to an option left at or statically changed from its default.
	 *
	 * @param string $section
	 * @param array  $post
	 * @return bool
	 */
	function pmwi_section_has_mapping($section, $post) {

		if ( ! function_exists('wp_all_import_has_template_token')
			|| ! function_exists('wp_all_import_is_mapped_value')
			|| ! function_exists('wp_all_import_has_mapped_value') ) {
			return FALSE;
		}

		$order = ( isset($post['pmwi_order']) && is_array($post['pmwi_order']) ) ? $post['pmwi_order'] : array();

		switch ($section) {

			case 'product':

				foreach (array('attribute_name', 'variable_attribute_name') as $key) {
					foreach ( (array) ( isset($post[$key]) ? $post[$key] : array() ) as $name ) {
						if ( wp_all_import_is_mapped_value($name) ) {
							return TRUE;
						}
					}
				}

				if ( pmwi_has_mapped_choice($post, array(
					'is_product_virtual'                => 'single_product_virtual',
					'is_product_downloadable'           => 'single_product_downloadable',
					'is_product_enabled'                => 'single_product_enabled',
					'is_product_featured'               => 'single_product_featured',
					'is_product_visibility'             => 'single_product_visibility',
					'is_product_enable_reviews'         => 'single_product_enable_reviews',
					'is_product_manage_stock'           => 'single_product_manage_stock',
					'product_stock_status'              => 'single_product_stock_status',
					'product_allow_backorders'          => 'single_product_allow_backorders',
					'product_sold_individually'         => 'single_product_sold_individually',
					'is_variable_product_virtual'       => 'single_variable_product_virtual',
					'is_variable_product_downloadable'  => 'single_variable_product_downloadable',
					'is_variable_product_enabled'       => 'single_variable_product_enabled',
					'is_variable_product_manage_stock'  => 'single_variable_product_manage_stock',
					'variable_stock_status'             => 'single_variable_stock_status',
					'variable_allow_backorders'         => 'single_variable_allow_backorders',
					'is_variation_product_manage_stock' => 'single_variation_product_manage_stock',
					'variation_stock_status'            => 'single_variation_stock_status',
				), 'xpath') ) {
					return TRUE;
				}

				// These pairs invert the convention: 'no' is the XPath choice.
				if ( pmwi_has_mapped_choice($post, array(
					'is_multiple_product_type'                         => 'single_product_type',
					'is_multiple_product_tax_status'                   => 'single_product_tax_status',
					'is_multiple_product_tax_class'                    => 'single_product_tax_class',
					'is_multiple_product_shipping_class'               => 'single_product_shipping_class',
					'is_multiple_grouping_product'                     => 'single_grouping_product',
					'is_multiple_variable_product_shipping_class'      => 'single_variable_product_shipping_class',
					'is_multiple_variable_product_tax_class'           => 'single_variable_product_tax_class',
					'is_multiple_product_subscription_period_interval' => 'single_product_subscription_period_interval',
					'is_multiple_product_subscription_period'          => 'single_product_subscription_period',
					'is_multiple_product_subscription_trial_period'    => 'single_product_subscription_trial_period',
					'is_multiple_product_subscription_length'          => 'single_product_subscription_length',
					'is_multiple_product_subscription_limit'           => 'single_product_subscription_limit',
				), 'no') ) {
					return TRUE;
				}

				// The variations tab prefills these two from the core title template
				// whenever they are blank, so an untouched import posts the title back
				// into them. Only a value that diverges from it was typed here.
				$title = isset($post['title']) ? (string) $post['title'] : '';

				foreach (array('single_product_id_first_is_parent_title', 'single_product_id_first_is_variation') as $key) {
					$value = isset($post[$key]) ? $post[$key] : '';

					if ( wp_all_import_has_mapped_value($value) && $title !== (string) $value ) {
						return TRUE;
					}
				}

				// Sale price dates default to 'now' and the parent lookup field to '_sku',
				// so for those only a token counts.
				if ( pmwi_has_mapped_field($post, array(
					'single_sale_price_dates_from', 'single_sale_price_dates_to',
					'existing_parent_product_cf_name',
				)) ) {
					return TRUE;
				}

				return pmwi_has_filled_field($post, array(
					'single_product_sku', 'single_product_global_unique_id', 'single_product_url', 'single_product_button_text',
					'single_product_regular_price', 'single_product_sale_price',
					'single_product_regular_price_adjust', 'single_product_sale_price_adjust',
					'single_product_files', 'single_product_files_names', 'single_product_download_type',
					'single_product_download_limit', 'single_product_download_expiry',
					'single_product_stock_qty', 'single_product_low_stock_amount',
					'single_product_weight', 'single_product_length', 'single_product_width', 'single_product_height',
					'single_product_up_sells', 'single_product_cross_sells',
					'single_product_purchase_note', 'single_product_menu_order',
					'single_product_id', 'single_product_parent_id',
					'single_product_id_first_is_parent_id', 'single_product_first_is_parent_id_parent_sku',
					'single_product_first_is_parent_title_parent_sku',
					'single_product_variation_description',
					'single_product_subscription_price', 'single_product_subscription_sign_up_fee',
					'custom_grouping_indicator_name', 'custom_grouping_indicator_value',
					'existing_parent_product_title', 'existing_parent_product_cf_value',
					'grouped_product_children_xpath', 'default_attributes_xpath', 'variations_xpath',
					'variable_sku', 'variable_global_unique_id', 'variable_image', 'variable_description', 'variable_stock',
					'variable_regular_price', 'variable_sale_price',
					'variable_sale_price_dates_from', 'variable_sale_price_dates_to',
					'variable_weight', 'variable_length', 'variable_width', 'variable_height',
					'variable_file_paths', 'variable_file_names', 'variable_download_limit', 'variable_download_expiry',
					'variable_whosale_price', 'variation_stock',
				));

			case 'order-billing-shipping':

				if ( pmwi_has_mapped_choice($order, array('payment_method' => 'payment_method_xpath'), 'xpath') ) {
					return TRUE;
				}

				// The payment date defaults to 'now', so only a token counts.
				if ( pmwi_has_mapped_field($order, array('payment_date')) ) {
					return TRUE;
				}

				$fields = array(
					'billing_first_name', 'billing_last_name', 'billing_company', 'billing_address_1', 'billing_address_2',
					'billing_city', 'billing_postcode', 'billing_country', 'billing_state', 'billing_email', 'billing_phone',
					'guest_billing_first_name', 'guest_billing_last_name', 'guest_billing_company',
					'guest_billing_address_1', 'guest_billing_address_2', 'guest_billing_city', 'guest_billing_postcode',
					'guest_billing_country', 'guest_billing_state', 'guest_billing_email', 'guest_billing_phone',
					'billing_source_username', 'billing_source_email', 'billing_source_id',
					'billing_source_cf_name', 'billing_source_cf_value',
					'customer_provided_note', 'transaction_id',
				);

				// The shipping fields are only submitted when the shipping address is imported.
				if ( isset($order['shipping_source']) && 'guest' == $order['shipping_source'] ) {
					$fields = array_merge($fields, array(
						'shipping_first_name', 'shipping_last_name', 'shipping_company',
						'shipping_address_1', 'shipping_address_2', 'shipping_city', 'shipping_postcode',
						'shipping_country', 'shipping_state', 'shipping_phone',
					));
				}

				return pmwi_has_filled_field($order, $fields);

			case 'order-items':

				if ( pmwi_has_mapped_choice($order, array(
					'products_repeater_mode' => 'products_repeater_mode_foreach',
					'fees_repeater_mode'     => 'fees_repeater_mode_foreach',
					'coupons_repeater_mode'  => 'coupons_repeater_mode_foreach',
					'shipping_repeater_mode' => 'shipping_repeater_mode_foreach',
					'refunds_repeater_mode'  => 'refunds_repeater_mode_foreach',
				), 'xml') ) {
					return TRUE;
				}

				$rows = array(
					'product_items' => array('unique_key', 'sku', 'qty', 'price_per_unit'),
					'fees'          => array('name', 'amount'),
					'coupons'       => array('code', 'amount', 'amount_tax'),
					'shipping'      => array('name', 'amount'),
					'refunds'       => array(
						'full_reason', 'full_date', 'full_amount',
						'partial_reason', 'partial_date', 'partial_amount',
						'order_item_name', 'item_refund_quantity', 'item_refund_amount', 'item_refund_tax_amount',
						'shipping_name', 'shipping_refund_amount', 'shipping_refund_tax_amount',
						'fee_name', 'fee_refund_amount', 'fee_refund_tax_amount',
					),
				);

				// Pre-2023 order item rows. The 4.0 migration copies them into
				// product_items, but only for the matching products_source and only for
				// an import the upgrade routine actually walked, so the legacy rows stay
				// the sole record of the mapping for the rest.
				$legacy_rows = array(
					'products'        => array('unique_key', 'sku', 'qty', 'price_per_unit'),
					'manual_products' => array('unique_key', 'sku', 'qty', 'price_per_unit'),
				);

				foreach (array_merge($rows, $legacy_rows) as $key => $fields) {
					$row = pmwi_first_repeater_row($order, $key);

					if ( pmwi_has_filled_field($row, $fields) ) {
						return TRUE;
					}

					if ( isset($row['meta_name']) && wp_all_import_has_mapped_value($row['meta_name']) ) {
						return TRUE;
					}

					// Legacy tax rate rows carry calculate_logic, a select defaulting to
					// 'percentage', so they cannot be tested for mere non-emptiness.
					foreach ( (array) ( isset($row['tax_rates']) ? $row['tax_rates'] : array() ) as $tax_rate ) {
						if ( is_array($tax_rate)
							&& pmwi_has_filled_field($tax_rate, array('code', 'percentage_value', 'amount_per_unit')) ) {
							return TRUE;
						}
					}
				}

				$shipping_row = pmwi_first_repeater_row($order, 'shipping');

				if ( pmwi_has_mapped_choice($shipping_row, array('class' => 'class_xpath'), 'xpath') ) {
					return TRUE;
				}

				// Pre-2023 order total, superseded by order_total_amount.
				if ( pmwi_has_mapped_choice($order, array('order_total_logic' => 'order_total_xpath'), 'xpath') ) {
					return TRUE;
				}

				return pmwi_has_filled_field($order, array(
					'order_total_amount', 'order_total_tax_amount',
					'order_refund_reason', 'order_refund_amount', 'order_refund_date',
					'order_refund_issued_username', 'order_refund_issued_email',
					'order_refund_issued_cf_name', 'order_refund_issued_cf_value', 'order_refund_issued_id',
				));

			case 'order-notes':

				if ( pmwi_has_mapped_choice($order, array('notes_repeater_mode' => 'notes_repeater_mode_foreach'), 'xml') ) {
					return TRUE;
				}

				// A note row is only rendered once it has content, so content is the mapping.
				foreach ( (array) ( isset($order['notes']) ? $order['notes'] : array() ) as $note ) {
					if ( is_array($note) && isset($note['content']) && wp_all_import_is_mapped_value($note['content']) ) {
						return TRUE;
					}
				}

				return FALSE;
		}

		return FALSE;
	}
}

if ( ! function_exists('pmwi_section_closed_class') ) {
	/**
	 * Returns the `closed` class for a step 3 section, omitting it when the section holds
	 * mappings so it renders expanded. Falls back to `closed` when the core helpers are
	 * unavailable.
	 *
	 * @param string $section
	 * @param array  $post
	 * @return string
	 */
	function pmwi_section_closed_class($section, $post) {
		return pmwi_section_has_mapping($section, $post) ? '' : 'closed';
	}
}
