<?php return array (
  'root' => 
  array (
    'name' => 'soflyy/wpai-woocommerce-add-on',
    'pretty_version' => 'dev-master',
    'version' => 'dev-master',
    'reference' => '441f0f35a2fc54b52d460c136ab15e00c54285c5',
    'type' => 'wordpress-plugin',
    'install_path' => __DIR__ . '/../',
    'aliases' => 
    array (
    ),
    'dev' => true,
  ),
  'versions' => 
  array (
    'soflyy/updater' => 
    array (
      'pretty_version' => 'v2.7.0',
      'version' => '2.7.0.0',
      'reference' => 'dec3afc27064851bc9554b5f4c1b60f8f8664815',
      'type' => 'library',
      'install_path' => __DIR__ . '/../soflyy/updater',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
  ),
);