<?php

namespace wpai_woocommerce_add_on\actions;

use wpai_woocommerce_add_on\parser\Parser;
use wpai_woocommerce_add_on\XmlImportWooCommerceService;

/**
 * Created by PhpStorm.
 * User: cmd
 * Date: 11/16/17
 * Time: 3:44 PM
 */

class OrderActions extends Actions {

    protected $completion_dates = array();

    /**
     * A new instance is constructed for every chunk. A long-running WP-CLI import processes
     * many chunks in the same PHP process, so without this, each chunk's instance would leave
     * its callbacks hooked forever, stacking duplicate calls on every subsequent order save.
     * @var self|null
     */
    private static $active_instance = null;

    /**
     * OrderActions constructor.
     * @param Parser $parser
     */
    public function __construct(Parser $parser) {

        parent::__construct($parser);

        if (self::$active_instance) {
            remove_filter('pmxi_custom_field', array(self::$active_instance, 'pmxi_custom_field'), 10);
            remove_action('woocommerce_before_order_object_save', array(self::$active_instance, 'woocommerce_before_order_object_save'), 10);
        }
        self::$active_instance = $this;

        add_filter('pmxi_custom_field', array($this, 'pmxi_custom_field'), 10, 6);
        add_action('woocommerce_before_order_object_save', array($this, 'woocommerce_before_order_object_save'));

        if (!has_filter('wp_all_import_is_post_to_skip')) {
            add_filter('wp_all_import_is_post_to_skip', array(
                &$this,
                'wp_all_import_is_post_to_skip'
            ), 10, 5);
        }

        if (!has_filter('wp_all_import_combine_article_data')) {
            add_filter('wp_all_import_combine_article_data', array(
                &$this,
                'wp_all_import_combine_article_data'
            ), 10, 4);
        }
    }

    public function pmxi_custom_field($value, $pid, $key, $original_value, $existing_meta_keys, $import_id) {
        if ($key == '_date_completed' && $import_id == $this->getParser()->getImport()->id && $this->getImporter() && $pid == $this->getImporter()->getPid()) {
            $this->completion_dates[$pid] = wp_unslash($value);
        }
        return $value;
    }

    public function woocommerce_before_order_object_save($order) {
        $pid = $order->get_id();
        if (!array_key_exists($pid, $this->completion_dates)) {
            return;
        }
        $value = trim((string) $this->completion_dates[$pid]);
        unset($this->completion_dates[$pid]);

        if ('' === $value) {
            $order->set_date_completed(null);
            return;
        }
        // A migrated _date_completed is a UNIX timestamp (legacy storage) or an ISO 8601 string with
        // offset (HPOS); both carry their own zone. Only a bare datetime is ambiguous: WooCommerce
        // would read it as site-local, but the exporter writes it as UTC.
        if (is_numeric($value) && abs((float) $value) < 10000000000) {
            $order->set_date_completed($value);
            return;
        }
        if (is_numeric($value)) {
            $this->logUnparseableCompletionDate($value);
            return;
        }
        if (preg_match('/(Z|[+-]\d{2}:?\d{2})$/i', $value)) {
            try {
                $order->set_date_completed((new \DateTime($value))->getTimestamp());
            } catch (\Exception $e) {
                $this->logUnparseableCompletionDate($value);
            }
            return;
        }
        if (false === strtotime($value)) {
            $this->logUnparseableCompletionDate($value);
            return;
        }
        $order->set_date_completed(get_date_from_gmt($value));
    }

    private function logUnparseableCompletionDate($value) {
        $logger = $this->getParser()->getLogger();
        $logger and call_user_func($logger, sprintf(__('<b>WARNING</b>: Completion date `%s` is not a recognizable date; existing value left unchanged.', 'wpai_woocommerce_addon_plugin'), $value));
    }

    /**
     *
     * When users are matching to existing customers and/or products and no match it found,
     * WP All Import doesn't have enough information to import that order, so the whole order will be skipped.
     *
     * @param $is_post_to_skip
     * @param $import_id
     * @param $current_xml_node
     * @param $index
     * @param $post_to_update_id
     * @return bool
     */
    public function wp_all_import_is_post_to_skip($is_post_to_skip, $import_id, $current_xml_node, $index, $post_to_update_id) {

        $order_title = 'Order &ndash; ' . date_i18n('F j, Y @ h:i A', strtotime($this->getParser()->getData()['pmwi_order']['date'][$index]));

        if (empty($post_to_update_id) or $this->getParser()->getImport()->options['update_all_data'] == 'yes' or $this->getParser()->getImport()->options['is_update_billing_details']) {
            if ($this->getParser()->getImport()->options['pmwi_order']['billing_source'] == 'existing') {
                $customer = $this->getParser()->get_existing_customer('billing_source', $index);
                if (empty($customer) && empty($this->getParser()->getImport()->options['pmwi_order']['is_guest_matching'])) {
                    $this->getParser()->getLogger() and call_user_func($this->getParser()->getLogger(), sprintf(__('<b>SKIPPED</b>: %s Existing customer not found for Order `%s`.', 'wpai_woocommerce_addon_plugin'), $this->getParser()->get_existing_customer_for_logger('billing_source', $index), $order_title));
                    $is_post_to_skip = TRUE;
                }
            }
        }

        if ($is_post_to_skip) {
            return $is_post_to_skip;
        }

        return $is_post_to_skip;
    }

    /**
     * @param $articleData
     * @param $post_type
     * @param $import_id
     * @param $index
     * @return mixed
     */
    public function wp_all_import_combine_article_data($articleData, $post_type, $import_id, $index) {
        if ($post_type == 'shop_order' && empty($articleData['post_title'])) {
            $articleData['post_title'] = 'Order &ndash; ' . date_i18n('F j, Y @ h:i A', strtotime($this->getParser()->getData()['pmwi_order']['date'][$index]));
        }
        return $articleData;
    }
}
