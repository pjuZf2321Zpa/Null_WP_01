<?php

namespace wpai_woocommerce_add_on\importer;

use WC_Data_Store;
use wpai_woocommerce_add_on\importer\orders\ImportOrderAddress;
use wpai_woocommerce_add_on\importer\orders\ImportOrderBase;
use wpai_woocommerce_add_on\importer\orders\ImportOrderDetails;
use wpai_woocommerce_add_on\importer\orders\ImportOrderItemsBase;
use wpai_woocommerce_add_on\importer\orders\ImportOrderNotes;
use wpai_woocommerce_add_on\importer\orders\ImportOrderPayment;
use wpai_woocommerce_add_on\importer\orders\ImportOrderRefunds;
use wpai_woocommerce_add_on\importer\orders\ImportOrderTotal;
use wpai_woocommerce_add_on\importer\orders\items\ImportOrderCouponItems;
use wpai_woocommerce_add_on\importer\orders\items\ImportOrderFeeItems;
use wpai_woocommerce_add_on\importer\orders\items\ImportOrderProductItems;
use wpai_woocommerce_add_on\importer\orders\items\ImportOrderShippingItems;

/**
 * Class OrdersImporter
 * @package wpai_woocommerce_add_on\importer
 */
class OrdersImporter extends Importer {

    /**
     * @var array
     */
    public $importers = array();

    /**
     *
     * Import WooCommerce Order
     *
     * @return array
     */
    public function import() {

        $data = $this->getParsedData()['pmwi_order'];

        // Block email notifications during import process.
        if (!empty($this->getImport()->options['do_not_send_order_notifications'])) {
            add_filter('woocommerce_email_classes', [$this, 'woocommerce_email_classes'], 99, 1);
        }

		// Block automatic order notes unless they're explicitly allowed.
	    if( empty($this->getImport()->options['pmwi_order']['notes_add_auto_order_status_notes'])) {
		    add_filter( 'woocommerce_new_order_note_data', [ $this, 'woocommerce_new_order_note_data' ], 10, 2 );
		    add_action( 'woocommerce_order_note_added', [ $this, 'woocommerce_order_note_added' ] );
	    }

        $order = wc_get_order($this->index->getPid());

        $this->importers['orderAddress'] = new ImportOrderAddress($this->getIndexObject(), $this->getOptions(), $order, $data);
        $this->importers['orderPayment'] = new ImportOrderPayment($this->getIndexObject(), $this->getOptions(), $order, $data);
        $this->importers['orderProductItems'] = new ImportOrderProductItems($this->getIndexObject(), $this->getOptions(), $order, $data);
        $this->importers['orderFeeItems'] = new ImportOrderFeeItems($this->getIndexObject(), $this->getOptions(), $order, $data);
        $this->importers['orderCouponItems'] = new ImportOrderCouponItems($this->getIndexObject(), $this->getOptions(), $order, $data);
        $this->importers['orderShippingItems'] = new ImportOrderShippingItems($this->getIndexObject(), $this->getOptions(), $order, $data);
        $this->importers['orderTotal'] = new ImportOrderTotal($this->getIndexObject(), $this->getOptions(), $order, $data);
        $this->importers['orderRefunds'] = new ImportOrderRefunds($this->getIndexObject(), $this->getOptions(), $order, $data);
        $this->importers['orderNotes'] = new ImportOrderNotes($this->getIndexObject(), $this->getOptions(), $order, $data);
        $this->importers['orderDetails'] = new ImportOrderDetails($this->getIndexObject(), $this->getOptions(), $order, $data);

        $removed_item_types = array();
        /** @var ImportOrderBase $importer */
        foreach ($this->importers as $importer) {
            /** @var ImportOrderItemsBase $importer */
            if ($importer instanceof ImportOrderItemsBase) {
                $removed_type = $importer->removeExistingItems();
                if ($removed_type) {
                    $removed_item_types[] = $removed_type;
                }
            }
        }

        // WC 11+ defers these deletes to the next save() and deletes by item type, so any
        // item re-added first would be deleted along with the old ones. Saving here drains
        // the queue while the order legitimately holds none of those items.
        $skip_item_import = FALSE;
        if ( ! empty($removed_item_types) && ImportOrderItemsBase::orderDefersItemDeletion($order)) {
            $order->save();
            if ($this->hasPendingItemDeletions($order)) {
                $skip_item_import = TRUE;
                $this->log(sprintf(__('- <b>WARNING</b> Order `%s` still has items queued for deletion after saving, so no order items were imported for this record. This usually means another plugin raised an error while the order was being saved.', 'wpai_woocommerce_addon_plugin'), $order->get_id()));
            }
        }

        /** @var ImportOrderBase $importer */
        foreach ($this->importers as $importer) {
            // Importing while deletes are still queued would lose those items on the next
            // order save, silently and leaving orphaned item meta behind.
            if ($skip_item_import && $importer instanceof ImportOrderItemsBase) {
                continue;
            }
            $importer->import();
        }

        $order->update_taxes();

		// Remove order note filter.
	    remove_filter('woocommerce_new_order_note_data', [$this, 'woocommerce_new_order_note_data']);
	    remove_action('woocommerce_order_note_added', [$this, 'woocommerce_order_note_added']);

    }

    /**
     * WC_Abstract_Order::save() logs and swallows exceptions, so the deletes it was meant to
     * flush can still be queued afterwards. The queue is the only reliable signal: an order
     * that held no items of a removed type leaves no trace of the failure in the database.
     *
     * @param \WC_Abstract_Order $order
     *
     * @return bool
     */
    protected function hasPendingItemDeletions($order) {
        if ( ! ImportOrderItemsBase::orderDefersItemDeletion($order)) {
            return FALSE;
        }

        foreach (array('item_types_to_bulk_delete', 'bulk_delete_all_items_pending') as $property) {
            if ( ! property_exists($order, $property)) {
                continue;
            }
            $pending = new \ReflectionProperty($order, $property);
            if (PHP_VERSION_ID < 80100) {
                $pending->setAccessible(TRUE);
            }
            if ( ! empty($pending->getValue($order))) {
                return TRUE;
            }
        }

        return FALSE;
    }

    /**
     * @param $emails
     * @return array
     */
    public function woocommerce_email_classes($emails) {
        remove_all_actions( 'woocommerce_order_status_cancelled_to_completed_notification');
        remove_all_actions( 'woocommerce_order_status_cancelled_to_on-hold_notification');
        remove_all_actions( 'woocommerce_order_status_cancelled_to_processing_notification');
        remove_all_actions( 'woocommerce_order_status_completed_notification');
        remove_all_actions( 'woocommerce_order_status_failed_to_completed_notification');
        remove_all_actions( 'woocommerce_order_status_failed_to_on-hold_notification');
        remove_all_actions( 'woocommerce_order_status_failed_to_processing_notification');
        remove_all_actions( 'woocommerce_order_status_on-hold_to_cancelled_notification');
        remove_all_actions( 'woocommerce_order_status_on-hold_to_failed_notification');
        remove_all_actions( 'woocommerce_order_status_on-hold_to_processing_notification');
        remove_all_actions( 'woocommerce_order_status_pending_to_completed_notification');
        remove_all_actions( 'woocommerce_order_status_pending_to_failed_notification');
        remove_all_actions( 'woocommerce_order_status_pending_to_on-hold_notification');
        remove_all_actions( 'woocommerce_order_status_pending_to_processing_notification');
        remove_all_actions( 'woocommerce_order_status_processing_to_cancelled_notification');
        return [];
    }

    /**
     * Do not add system generated notes during import process.
     *
     * @param $note_data
     * @param $order_data
     *
     * @return array
     */
    public function woocommerce_new_order_note_data($note_data, $order_data) {
        return [];
    }

    // The note-data filter cannot stop the insert, so a suppressed note is removed once it exists.
    public function woocommerce_order_note_added($note_id) {
        wp_delete_comment($note_id, TRUE);
    }

    /**
     *
     * After Import WooCommerce Order
     *
     * @return array
     */
    public function afterPostImport() {
	    $data_store = WC_Data_Store::load( 'customer-download' );
	    $data_store->delete_by_order_id( $this->getPid() );
	    wc_downloadable_product_permissions($this->getPid(), true);
        update_option('wp_all_import_previously_updated_order_' . $this->getImport()->id, $this->getPid(), false);
    }
}
