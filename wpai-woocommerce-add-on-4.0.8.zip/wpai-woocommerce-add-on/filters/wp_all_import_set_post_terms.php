<?php

/**
 * @param $assign_taxes
 * @param $tx_name
 * @param $pid
 * @param $import_id
 * @return array
 */
function pmwi_wp_all_import_set_post_terms($assign_taxes, $tx_name, $pid, $import_id){
	// Handle product_cat taxonomy
	if ($tx_name == 'product_cat') {

		$default_tt_id = pmwi_get_default_product_cat_taxonomy_id();

		// Get import record to check update mode
		$import = new PMXI_Import_Record();
		$import->getById($import_id);

		// Check if we're in "add_new" mode
		if (!$import->isEmpty() &&
		    isset($import->options['update_categories_logic']) &&
		    $import->options['update_categories_logic'] == 'add_new') {

			// In "add_new" mode, get existing categories
			$existing_categories = wp_get_object_terms($pid, 'product_cat', array('fields' => 'tt_ids'));

			if (!is_wp_error($existing_categories)) {

				if (!empty($assign_taxes)) {
					// We have categories to assign - remove default category if present
					$filtered_taxes = array_diff($assign_taxes, array($default_tt_id));
					if (!empty($filtered_taxes)) {
						// We have real categories after removing default, use them
						return array_values($filtered_taxes); // Re-index array
					} else {
						// Only default category in assign_taxes
						if (!empty($existing_categories)) {
							// Keep existing categories if we only had default to assign
							return $existing_categories;
						}
						// If no existing categories and only default to assign, fall through to assign default
					}
				} else {
					// No new categories to import
					// If existing categories exist, keep them; otherwise fall through to assign default
					if (!empty($existing_categories)) {
						return $existing_categories;
					}
					// If no existing categories, fall through to assign default category
				}
			}
		}

		// Not in "add_new" mode, or no existing categories - add default if no categories assigned
		if (empty($assign_taxes) && $default_tt_id) {
			$assign_taxes[] = $default_tt_id;
		}
	}

	return $assign_taxes;
}

/**
 * Resolve WooCommerce's default product category to a term_taxonomy_id.
 *
 * $assign_taxes carries term_taxonomy_ids, and default_product_cat can hold either
 * form: WooCommerce seeds it with a term_taxonomy_id on install but stores a term_id
 * when "Make default" is used on the category list, which is also how WooCommerce's
 * own admin compares it back.
 *
 * @return int term_taxonomy_id, or 0 when no default resolves.
 */
function pmwi_get_default_product_cat_taxonomy_id(){

	$default_term_id = (int) get_option('default_product_cat', 0);

	if ($default_term_id) {
		$term = get_term($default_term_id, 'product_cat');
		if ( ! empty($term) and ! is_wp_error($term) ) {
			return (int) $term->term_taxonomy_id;
		}
		$term = get_term_by('term_taxonomy_id', $default_term_id, 'product_cat');
		if ( ! empty($term) and ! is_wp_error($term) ) {
			return (int) $term->term_taxonomy_id;
		}
	}

	// No default configured, or it points at a deleted term. Fall back to
	// Uncategorized so products aren't left with no category at all.
	$term = is_exists_term('uncategorized', 'product_cat', 0);
	if ( ! empty($term) and ! is_wp_error($term) ) {
		return (int) $term['term_taxonomy_id'];
	}

	return 0;
}
