<?php

if ( ! class_exists( 'PMWI_Updater', false ) ) {

	// Built with no 'license' entry: the package shows licence copy whenever that key is present.
	class PMWI_Updater extends \PMWI_Vendor\Soflyy\Updater\Updater {

		protected function textDomain() {
			return 'wpai_woocommerce_addon_plugin';
		}

		protected function productName() {
			return 'WP All Import - WooCommerce Import Add-On Pro';
		}

		protected function settingsUrl() {
			return admin_url( 'admin.php?page=pmxi-admin-settings' );
		}

		protected function updateTransientPriority() {
			return 21;
		}

		protected function changelogMetaTitle() {
			return __( 'View WP All Import - WooCommerce Add-On Pro Changelog', 'wpai_woocommerce_addon_plugin' );
		}
	}

}
