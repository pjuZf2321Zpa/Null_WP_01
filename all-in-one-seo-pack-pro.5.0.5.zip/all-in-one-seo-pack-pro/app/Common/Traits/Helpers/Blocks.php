<?php
namespace AIOSEO\Plugin\Common\Traits\Helpers;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Contains block specific helper methods.
 *
 * @since 4.8.7
 */
trait Blocks {
	/**
	 * Blocks known to conflict with AIOSEO.
	 *
	 * @since 4.8.7
	 *
	 * @var array
	 */
	private $conflictingBlocks = [
		'edd/checkout' => 'EDD Checkout',
	];

	/**
	 * Parses blocks using the stock WordPress block parser.
	 *
	 * NOTE: Deliberately bypasses the `block_parser_class` filter. Page builders like Divi 5 swap in a parser
	 * that mutates global render state on every parse (e.g. Divi's module order counters), which corrupts
	 * their front-end CSS when we parse content outside the main render.
	 *
	 * @since 5.0.2
	 *
	 * @param  string $content The raw post content.
	 * @return array           The parsed blocks.
	 */
	public function parseBlocksSafely( $content ) {
		return ( new \WP_Block_Parser() )->parse( (string) $content );
	}

	/**
	 * Returns the content with blocks replaced.
	 *
	 * @since   4.8.7
	 * @version 4.9.8 Guard against null block names (freeform/classic content) to prevent a PHP deprecation warning on newer PHP versions.
	 *
	 * @param  string $content    The content.
	 * @param  bool   $noConflict Whether to remove the conflicting blocks.
	 * @return string             The content with blocks replaced.
	 */
	public function doBlocks( $content, $noConflict = true ) {
		if ( $noConflict ) {
			$conflictingBlocks = apply_filters( 'aioseo_conflicting_blocks', $this->conflictingBlocks );

			static $preRenderBlockCallback = null;
			if ( null === $preRenderBlockCallback ) {
				$preRenderBlockCallback = function( $preRender, $parsedBlock ) use ( $conflictingBlocks ) {
					// Classic/freeform blocks have a null blockName, which PHP 8.5 deprecates as an array offset.
					$blockName = isset( $parsedBlock['blockName'] ) ? (string) $parsedBlock['blockName'] : '';
					if ( isset( $conflictingBlocks[ $blockName ] ) ) {
						return '';
					}

					return $preRender;
				};
			}

			add_filter( 'pre_render_block', $preRenderBlockCallback, 10, 2 );

			$content = do_blocks( $content );

			remove_filter( 'pre_render_block', $preRenderBlockCallback );

			return $content;
		}

		return do_blocks( $content );
	}
}