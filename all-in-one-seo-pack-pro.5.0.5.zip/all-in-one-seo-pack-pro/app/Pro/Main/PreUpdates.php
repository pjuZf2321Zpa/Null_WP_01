<?php
namespace AIOSEO\Plugin\Pro\Main;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AIOSEO\Plugin\Common\Main as CommonMain;
/**
 * Pre Updates class.
 *
 * @since 4.1.5
 */
class PreUpdates extends CommonMain\PreUpdates {
	/**
	 * Class constructor.
	 *
	 * @since 4.1.5
	 */
	public function __construct() {
		// We don't check wp_doing_ajax() here since the plugin might be installed/activated
		// for the first time via AJAX (e.g. EDD/BLC). The parent class also intentionally
		// allows AJAX for the same reason.
		if ( wp_doing_cron() ) {
			return;
		}

		parent::__construct();
	}
}