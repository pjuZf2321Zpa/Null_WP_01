<?php
namespace AIOSEO\Plugin\Pro\Main\Migrations\Definitions;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AIOSEO\Plugin\Common\Main\Migrations\Migration;

/**
 * Adds the TruSEO analysis columns to the terms table on existing installs.
 *
 * Fresh installs get them from {@see \AIOSEO\Plugin\Pro\Db\Schema::getTermsTableSchema()}; dbDelta
 * does not reliably add columns to an existing table, so they are added explicitly here.
 *
 * @since 5.0.1
 */
class AddTruSeoTermColumns implements Migration {
	/**
	 * The columns to add, keyed by name, with the clause that creates each one.
	 *
	 * NOTE: Deliberately no `keyphrases` or `page_analysis` — both are pre-5.0 stores read only as a
	 * fallback for rows analysed before `truseo` existed, and only for posts.
	 *
	 * @since 5.0.1
	 *
	 * @var array
	 */
	private $columns = [
		'focus_keyword'       => 'ADD `focus_keyword` varchar(255) DEFAULT NULL AFTER seo_analyzer_scan_date',
		'truseo'              => 'ADD `truseo` longtext DEFAULT NULL AFTER focus_keyword',
		'additional_keywords' => 'ADD `additional_keywords` text DEFAULT NULL AFTER truseo',
		'truseo_locale'       => 'ADD `truseo_locale` varchar(20) DEFAULT NULL AFTER additional_keywords',
		'seo_score'           => 'ADD `seo_score` int(11) NOT NULL DEFAULT 0 AFTER truseo_locale'
	];

	/**
	 * {@inheritdoc}
	 *
	 * @since 5.0.1
	 */
	public function name() {
		return 'add_truseo_term_columns';
	}

	/**
	 * {@inheritdoc}
	 *
	 * @since 5.0.1
	 */
	public function version() {
		return '5.0.1';
	}

	/**
	 * {@inheritdoc}
	 *
	 * NOTE: the runner executes in preLoad(), which on a fresh install is before the table is
	 * created, so a missing table is a no-op rather than a failure.
	 *
	 * @since 5.0.1
	 */
	public function up() {
		$existingColumns = $this->existingColumns();
		if ( empty( $existingColumns ) ) {
			return;
		}

		$tableName = aioseo()->core->db->db->prefix . 'aioseo_terms';

		$changed = false;
		foreach ( $this->columns as $columnName => $statement ) {
			if ( in_array( $columnName, $existingColumns, true ) ) {
				continue;
			}

			aioseo()->core->db->execute( "ALTER TABLE {$tableName} {$statement}" );
			$changed = true;
		}

		if ( $changed ) {
			aioseo()->core->cache->delete( 'db_schema' );
		}
	}

	/**
	 * {@inheritdoc}
	 *
	 * NOTE: a missing table verifies as done, for the reason given on {@see self::up()}.
	 *
	 * @since 5.0.1
	 */
	public function verify() {
		$existingColumns = $this->existingColumns();
		if ( empty( $existingColumns ) ) {
			return true;
		}

		foreach ( array_keys( $this->columns ) as $columnName ) {
			if ( ! in_array( $columnName, $existingColumns, true ) ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * The terms table's current columns. An empty array means the table does not exist.
	 *
	 * NOTE: deliberately not columnExists()/tableExists() — both read the `db_schema` cache,
	 * which is held for a day and can be stale while DDL is in flight.
	 *
	 * @since 5.0.1
	 *
	 * @return array
	 */
	private function existingColumns() {
		$db = aioseo()->core->db->db;

		return $db->get_col(
			$db->prepare(
				'SELECT COLUMN_NAME
				FROM INFORMATION_SCHEMA.COLUMNS
				WHERE TABLE_SCHEMA = DATABASE()
				AND TABLE_NAME = %s',
				$db->prefix . 'aioseo_terms'
			)
		);
	}
}