<?php
namespace AIOSEO\Plugin\Pro\Main\Migrations\Definitions;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AIOSEO\Plugin\Common\Main\Migrations\Migration;

/**
 * Grants the `upload_files` capability to the SEO Manager and SEO Editor roles
 * on existing installs.
 *
 * The cap was added in 4.9.9, but only inside the add_role() defaults in
 * {@see \AIOSEO\Plugin\Pro\Utils\Access::addCapabilities()}. add_role() is a
 * no-op once the role already exists, so sites that created these roles on an
 * earlier version never received it — and unlike AIOSEO's own capabilities,
 * upload_files is a WordPress core cap that addCapabilities() does not re-sync.
 * This migration backfills it directly on the existing role objects.
 *
 * @since 4.9.9
 */
class AddUploadFilesCapability implements Migration {
	/**
	 * The roles that should receive the capability.
	 *
	 * @since 4.9.9
	 *
	 * @var string[]
	 */
	private $roles = [ 'aioseo_manager', 'aioseo_editor' ];

	/**
	 * {@inheritdoc}
	 *
	 * @since 4.9.9
	 */
	public function name() {
		return 'add_seo_roles_upload_files_capability';
	}

	/**
	 * {@inheritdoc}
	 *
	 * @since 4.9.9
	 */
	public function version() {
		return '4.9.9';
	}

	/**
	 * {@inheritdoc}
	 *
	 * @since 4.9.9
	 */
	public function up() {
		foreach ( $this->roles as $wpRole ) {
			$roleObject = get_role( $wpRole );
			if ( is_object( $roleObject ) && ! $roleObject->has_cap( 'upload_files' ) ) {
				$roleObject->add_cap( 'upload_files' );
			}
		}
	}

	/**
	 * {@inheritdoc}
	 *
	 * Roles that don't exist (e.g. they were never created) are nothing to
	 * migrate, so they don't hold the migration back.
	 *
	 * @since 4.9.9
	 */
	public function verify() {
		foreach ( $this->roles as $wpRole ) {
			$roleObject = get_role( $wpRole );
			if ( is_object( $roleObject ) && ! $roleObject->has_cap( 'upload_files' ) ) {
				return false;
			}
		}

		return true;
	}
}