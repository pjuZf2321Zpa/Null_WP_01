<?php
namespace AIOSEO\Plugin\Pro\Redirects\Db;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Database Schema for Redirects addon tables.
 *
 * This class defines the complete, current state of all database tables
 * used by the Redirects addon. These schemas are used with WordPress's
 * dbDelta() function to automatically create tables and add missing columns.
 *
 * @since 4.9.7
 */
class Schema {
	/**
	 * Get all table schemas for Redirects tables.
	 *
	 * Returns an array of CREATE TABLE statements for all tables
	 * used by Redirects. These will be processed by dbDelta() to ensure
	 * the database schema matches the definitions.
	 *
	 * @since 4.9.7
	 *
	 * @return array Array of SQL CREATE TABLE statements.
	 */
	public function getSchema() {
		return [
			$this->getRedirectsTableSchema(),
			$this->getRedirectsHitsTableSchema(),
			$this->getRedirectsLogsTableSchema(),
			$this->getRedirects404LogsTableSchema(),
			$this->getRedirects404TableSchema()
		];
	}

	/**
	 * Get the schema for aioseo_redirects table.
	 *
	 * Column history:
	 * - 1.0.0: Initial table creation
	 * - 1.1.0: custom_rules, target_url_hash changed to allow NULL
	 * - 1.2.7: post_id
	 * - 4.9.6: comment
	 *
	 * @since 4.9.7
	 *
	 * @return string SQL CREATE TABLE statement.
	 */
	private function getRedirectsTableSchema() {
		if ( ! function_exists( 'aioseo' ) ) {
			return '';
		}

		$tableName      = aioseo()->core->db->db->prefix . 'aioseo_redirects';
		$charsetCollate = aioseo()->core->db->db->get_charset_collate();

		return "CREATE TABLE {$tableName} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			post_id bigint(20) unsigned DEFAULT NULL,
			source_url text NOT NULL,
			source_url_hash varchar(40) NOT NULL,
			source_url_match text NOT NULL,
			source_url_match_hash varchar(40) NOT NULL,
			target_url text NOT NULL,
			target_url_hash varchar(40) DEFAULT NULL,
			type int(11) unsigned NOT NULL DEFAULT 301,
			query_param varchar(40) NOT NULL DEFAULT 'ignore',
			custom_rules text DEFAULT NULL,
			`group` varchar(256) NOT NULL DEFAULT 'manual',
			regex tinyint(1) unsigned NOT NULL DEFAULT 0,
			ignore_slash tinyint(1) unsigned NOT NULL DEFAULT 1,
			ignore_case tinyint(1) unsigned NOT NULL DEFAULT 1,
			enabled tinyint(1) unsigned NOT NULL DEFAULT 1,
			comment text DEFAULT NULL,
			created datetime NOT NULL,
			updated datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY ndx_aioseo_redirects_source_url_hash (source_url_hash),
			KEY ndx_aioseo_redirects_post_id (post_id),
			KEY ndx_aioseo_redirects_source_url_match_hash (source_url_match_hash),
			KEY ndx_aioseo_redirects_target_url_hash (target_url_hash),
			KEY ndx_aioseo_redirects_type (type),
			KEY ndx_aioseo_redirects_enabled (enabled)
		) {$charsetCollate};";
	}

	/**
	 * Get the schema for aioseo_redirects_hits table.
	 *
	 * @since 4.9.7
	 *
	 * @return string SQL CREATE TABLE statement.
	 */
	private function getRedirectsHitsTableSchema() {
		if ( ! function_exists( 'aioseo' ) ) {
			return '';
		}

		$tableName      = aioseo()->core->db->db->prefix . 'aioseo_redirects_hits';
		$charsetCollate = aioseo()->core->db->db->get_charset_collate();

		return "CREATE TABLE {$tableName} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			redirect_id bigint(20) unsigned NOT NULL,
			count bigint(20) unsigned NOT NULL DEFAULT 0,
			created datetime NOT NULL,
			updated datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY ndx_aioseo_redirects_hits_redirect_id (redirect_id),
			KEY ndx_aioseo_redirects_hits_count (count)
		) {$charsetCollate};";
	}

	/**
	 * Get the schema for aioseo_redirects_logs table.
	 *
	 * Column history:
	 * - 4.9.1: url_hash
	 *
	 * NOTE: the url_hash index is named `ndx_aioseo_redirects_404_logs_url_hash`
	 * on this table. That's a copy-paste mistake from the 4.9.1 migration that
	 * shipped to the field; the schema mirrors what already exists on upgraded
	 * sites so dbDelta doesn't try to create a duplicate index under a corrected
	 * name. Renaming would require a dedicated migration.
	 *
	 * @since 4.9.7
	 *
	 * @return string SQL CREATE TABLE statement.
	 */
	private function getRedirectsLogsTableSchema() {
		if ( ! function_exists( 'aioseo' ) ) {
			return '';
		}

		$tableName      = aioseo()->core->db->db->prefix . 'aioseo_redirects_logs';
		$charsetCollate = aioseo()->core->db->db->get_charset_collate();

		return "CREATE TABLE {$tableName} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			url mediumtext NOT NULL,
			url_hash varchar(40) DEFAULT NULL,
			domain varchar(255) DEFAULT NULL,
			sent_to mediumtext DEFAULT NULL,
			agent mediumtext,
			referrer mediumtext DEFAULT NULL,
			http_code int(11) unsigned NOT NULL DEFAULT 0,
			request_method varchar(10) DEFAULT NULL,
			request_data mediumtext DEFAULT NULL,
			redirect_by varchar(50) DEFAULT NULL,
			redirect_id bigint(20) unsigned DEFAULT NULL,
			ip varchar(45) DEFAULT NULL,
			created datetime NOT NULL,
			updated datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY ndx_aioseo_redirects_logs_created (created),
			KEY ndx_aioseo_redirects_logs_redirect_id (redirect_id),
			KEY ndx_aioseo_redirects_logs_ip (ip),
			KEY ndx_aioseo_redirects_404_logs_url_hash (url_hash)
		) {$charsetCollate};";
	}

	/**
	 * Get the schema for aioseo_redirects_404_logs table.
	 *
	 * Column history:
	 * - 4.9.1: url_hash
	 *
	 * @since 4.9.7
	 *
	 * @return string SQL CREATE TABLE statement.
	 */
	private function getRedirects404LogsTableSchema() {
		if ( ! function_exists( 'aioseo' ) ) {
			return '';
		}

		$tableName      = aioseo()->core->db->db->prefix . 'aioseo_redirects_404_logs';
		$charsetCollate = aioseo()->core->db->db->get_charset_collate();

		return "CREATE TABLE {$tableName} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			url mediumtext NOT NULL,
			url_hash varchar(40) DEFAULT NULL,
			domain varchar(255) DEFAULT NULL,
			agent mediumtext,
			referrer mediumtext DEFAULT NULL,
			http_code int(11) unsigned NOT NULL DEFAULT 0,
			request_method varchar(10) DEFAULT NULL,
			request_data mediumtext DEFAULT NULL,
			ip varchar(45) DEFAULT NULL,
			created datetime NOT NULL,
			updated datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY ndx_aioseo_redirects_404_logs_created (created),
			KEY ndx_aioseo_redirects_404_logs_ip (ip),
			KEY ndx_aioseo_redirects_404_logs_url_hash (url_hash)
		) {$charsetCollate};";
	}

	/**
	 * Get the schema for aioseo_redirects_404 table.
	 *
	 * @since 4.9.7
	 *
	 * @return string SQL CREATE TABLE statement.
	 */
	private function getRedirects404TableSchema() {
		if ( ! function_exists( 'aioseo' ) ) {
			return '';
		}

		$tableName      = aioseo()->core->db->db->prefix . 'aioseo_redirects_404';
		$charsetCollate = aioseo()->core->db->db->get_charset_collate();

		return "CREATE TABLE {$tableName} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			post_id bigint(20) unsigned DEFAULT NULL,
			post_type varchar(256) DEFAULT NULL,
			taxonomy varchar(256) DEFAULT NULL,
			source_url text,
			source_url_hash varchar(40) NOT NULL,
			parent_posts text,
			parent_terms text,
			created datetime NOT NULL,
			updated datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY ndx_aioseo_redirects_404_source_url_hash (source_url_hash)
		) {$charsetCollate};";
	}
}