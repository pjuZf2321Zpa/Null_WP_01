<?php
namespace AIOSEO\Plugin\Pro\Redirects\Main;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AIOSEO\Plugin\Pro\Redirects\Models;
use AIOSEO\Plugin\Pro\Redirects\Utils;

/**
 * Main class to run our redirects.
 *
 * @since 4.9.1
 */
class Redirect {
	/**
	 * Matched redirect.
	 *
	 * @since 4.9.1
	 *
	 * @var boolean
	 */
	private $matched = false;

	/**
	 * The target redirect URL.
	 *
	 * @since 4.9.1
	 *
	 * @var string|null
	 */
	private $redirectUrl = null;

	/**
	 * The target redirect code.
	 *
	 * @since 4.9.1
	 *
	 * @var int
	 */
	private $redirectCode = 0;

	/**
	 * Class constructor.
	 *
	 * @since 4.9.1
	 */
	public function __construct() {
		add_action( 'admin_init', [ $this, 'scheduleActions' ], 20 );

		add_action( 'aioseo_redirects_clear_404_logs', [ $this, 'clear404Logs' ] );
		add_action( 'aioseo_redirects_clear_logs', [ $this, 'clearRedirectLogs' ] );

		if ( is_admin() || aioseo()->helpers->isAjaxCronRestRequest() || aioseo()->helpers->isDoingWpCli() ) {
			return;
		}

		// Log 404's.
		if ( apply_filters( 'aioseo_redirects_use_alternate_404_hook', false, Utils\Request::getRequestUrl() ) ) {
			add_filter( 'template_include', [ $this, 'templateInclude' ], 10 );
		} else {
			add_action( 'template_redirect', [ $this, 'templateRedirect' ], 5 );
		}

		// Log external redirect agents.
		add_filter( 'x_redirect_by', [ $this, 'logExternalRedirect' ], 1000 );

		// The main redirect loop.
		add_action( 'init', [ $this, 'init' ] );

		// Redirect HTTP headers and server-specific overrides.
		add_filter( 'wp_redirect', [ $this, 'wpRedirect' ], 1, 2 );
	}

	/**
	 * Redirection 'main loop'. Checks the currently requested URL against the database and perform a redirect, if necessary.
	 *
	 * @since   4.9.1
	 * @version 5.0.4 Regex redirects match against {@see Utils\Request::getRegexRequestUrl()}.
	 *
	 * @return void
	 */
	public function init() {
		if (
			is_admin() ||
			$this->matched ||
			aioseo()->helpers->isAjaxCronRestRequest() ||
			$this->isPageBuilderPreviewRequest()
		) {
			return;
		}

		$requestUrl = Utils\Request::getRequestUrl();
		if ( ! $requestUrl || Utils\Request::isProtectedPath( $requestUrl ) ) {
			return;
		}

		// The query string is passed on raw: decoding it first would let an encoded `&`, `=`, `#` or `+`
		// in a value restructure the target's query.
		$requestUri = Utils\Request::getRequestUri();

		// First try the regular path redirects.
		$redirects = $this->getRegularRedirects( $requestUrl );

		// Run through the list until one fires.
		foreach ( $redirects as $redirect ) {
			// Test custom rules.
			if ( ! $this->matchCustomRules( $redirect, $requestUrl ) ) {
				continue;
			}

			$this->doRedirect( $redirect, $requestUri );
		}

		// Next try the regex redirects. These keep reserved characters encoded so one in the path can't be
		// read as the query delimiter once a capture group picks it up.
		$regexRedirects = $this->getRegexRedirects( Utils\Request::getRegexRequestUrl() );

		// Run through the list until one fires.
		foreach ( $regexRedirects as $regexRedirect ) {
			// Test custom rules.
			if ( ! $this->matchCustomRules( $regexRedirect, $requestUrl ) ) {
				continue;
			}

			$this->doRedirect( $regexRedirect, $requestUri );
		}
	}

	/**
	 * Runs a redirect.
	 *
	 * @since   4.9.1
	 * @version 4.9.9 Collapse mid-path double slashes left behind by empty regex capture-group substitutions (issue #8181).
	 * @version 5.0.3 Skip redirects whose type requires a target but have none.
	 *
	 * @param  Models\Redirect $redirect   The redirect model.
	 * @param  string          $requestUrl The request url.
	 * @return void
	 */
	private function doRedirect( $redirect, $requestUrl ) {
		// An empty target resolves to the home URL, which would turn a target-less
		// placeholder redirect into a silent soft 404. Leave the 404 in place instead.
		if ( aioseo()->redirects->helpers->isMissingTarget( $redirect ) ) {
			return;
		}

		$targetUrl = $this->buildTargetUrl( $redirect, isset( $redirect->regexMatches ) ? $redirect->regexMatches : [] );

		// Let's add the query string if necessary.
		$queryString = wp_parse_url( $requestUrl, PHP_URL_QUERY );
		if ( $queryString && ( 'pass' === $redirect->query_param || 'utm' === $redirect->query_param ) ) {
			parse_str( $queryString, $queryStringArray );

			// If we're only passing utm_ let's remove all other params.
			if ( 'utm' === $redirect->query_param ) {
				foreach ( $queryStringArray as $queryStringArrayKey => $queryStringArrayValue ) {
					if ( ! preg_match( '/^utm_/', (string) $queryStringArrayKey ) ) {
						unset( $queryStringArray[ $queryStringArrayKey ] );
					}
				}
			}

			// Add encoded params to the target URL. urlencode_deep handles nested arrays
			// (e.g. ?utm_medium[key]=value), which array_map( 'urlencode', ... ) chokes on.
			$targetUrl = add_query_arg( urlencode_deep( $queryStringArray ), $targetUrl );
		}

		$this->matched = $redirect->id;

		$this->redirectUrl = $targetUrl;
		// Cast to int before using.
		$this->redirectCode = (int) $redirect->type;

		// Log only if it's not a redirect test.
		if ( ! Utils\Request::getRequestHeader( 'X-AIOSEO-Redirect-Test' ) ) {
			$redirect->addHit();

			$this->logRedirect( $this->redirectCode, 'aioseo', $redirect->id );
		}

		// Pass through.
		if ( 0 === $this->redirectCode ) {
			$this->processPassThrough( $targetUrl );

			return;
		}

		// Pass through.
		if ( 404 === $this->redirectCode ) {
			$this->process404();

			return;
		}

		// wp_redirect will stop the execution if our redirect code is below 300 or over 399.
		if ( 300 <= $this->redirectCode && 399 >= $this->redirectCode ) {
			wp_redirect( $targetUrl, $this->redirectCode, 'AIOSEO' );
			die;
		} else {
			status_header( $redirect->type );
			exit( 0 );
		}
	}

	/**
	 * Returns if the query string matches for a redirect.
	 *
	 * @since 4.9.1
	 *
	 * @param  Models\Redirect $redirect   The redirect model.
	 * @param  string          $requestUrl The request url.
	 * @return bool                        Query string match.
	 */
	private function matchQueryStringRedirect( $redirect, $requestUrl ) {
		$sourceQueryString = wp_parse_url( trim( $redirect->source_url ), PHP_URL_QUERY );

		// If no query string is present in the source we can return early.
		if ( empty( $sourceQueryString ) ) {
			return true;
		}

		$queryString = wp_parse_url( $requestUrl, PHP_URL_QUERY ) ?: '';

		parse_str( $sourceQueryString, $sourceQueryStringArray );
		parse_str( $queryString, $queryStringArray );

		if ( 'exact' === $redirect->query_param ) {
			// If we can't find this query string inside the source query, we need to skip this redirect.
			foreach ( $queryStringArray as $key => $value ) {
				if ( ! isset( $sourceQueryStringArray[ $key ] ) || $sourceQueryStringArray[ $key ] !== $value ) {
					return false;
				}
			}

			// Same needs to happen the other way around.
			foreach ( $sourceQueryStringArray as $keySource => $valueSource ) {
				if ( ! isset( $queryStringArray[ $keySource ] ) || $queryStringArray[ $keySource ] !== $valueSource ) {
					return false;
				}
			}
		}

		return true;
	}

	/**
	 * Is this source->target a redirect loop?
	 *
	 * @since   4.9.1
	 * @version 5.0.4 Ignores the scheme and a leading `www.` of the host when comparing.
	 *
	 * @param  Models\Redirect  $redirect The redirect model.
	 * @return bool                       True if it's a loop.
	 */
	private function isRedirectLoop( $redirect ) {
		// Build comparable urls.
		$urlParams = [ 'scheme', 'host', 'path' ];
		if ( 'exact' === $redirect->query_param ) {
			$urlParams[] = 'query';
		}

		$sourceUrl = $this->getLoopComparableUrl( Utils\Request::formatSourceUrl( trim( $redirect->source_url ) ), $urlParams );
		$targetUrl = $this->getLoopComparableUrl( Utils\Request::formatTargetUrl( trim( $redirect->target_url ) ), $urlParams, true );
		if ( $sourceUrl === $targetUrl ) {
			return true;
		}

		// If we're ignoring the slash and this is a non-slash to slash redirect it could trigger a redirect loop.
		if (
			$redirect->ignore_slash &&
			untrailingslashit( $sourceUrl ) === untrailingslashit( $targetUrl )
		) {
			return true;
		}

		return false;
	}

	/**
	 * Returns the URL built from the given parts, without an HTTP(S) scheme, a leading `www.` or a trailing dot in the host.
	 * NOTE: Sources match on the path alone, so a target that only differs in those still loops back to the source.
	 *
	 * @since 5.0.4
	 *
	 * @param  string $url           The URL.
	 * @param  array  $urlParams     The URL parts to keep.
	 * @param  bool   $normalizePath Whether to resolve the path the way a browser requests it.
	 * @return string                The comparable URL.
	 */
	private function getLoopComparableUrl( $url, $urlParams, $normalizePath = false ) {
		$parsedUrl = wp_parse_url( $url );
		if ( ! is_array( $parsedUrl ) ) {
			return (string) $url;
		}

		if ( ! empty( $parsedUrl['scheme'] ) && in_array( strtolower( $parsedUrl['scheme'] ), [ 'http', 'https' ], true ) ) {
			unset( $parsedUrl['scheme'] );
		}

		if ( ! empty( $parsedUrl['host'] ) ) {
			$parsedUrl['host'] = preg_replace( '/^www\./', '', rtrim( strtolower( $parsedUrl['host'] ), '.' ) );
		}

		if ( $normalizePath && ! empty( $parsedUrl['path'] ) ) {
			$parsedUrl['path'] = $this->normalizeLoopPath( $parsedUrl['path'] );
		}

		return Utils\Request::buildUrl( $parsedUrl, $urlParams );
	}

	/**
	 * Returns the path with repeated slashes collapsed and `.` and `..` segments resolved.
	 * NOTE: Meant for targets only. A source like `/a//b` is matched as typed, so redirecting it to `/a/b` is not a loop.
	 *
	 * @since 5.0.4
	 *
	 * @param  string $path The URL path.
	 * @return string       The normalized path.
	 */
	private function normalizeLoopPath( $path ) {
		$segments   = explode( '/', (string) preg_replace( '#/{2,}#', '/', $path ) );
		$isAbsolute = '' === $segments[0];
		if ( $isAbsolute ) {
			array_shift( $segments );
		}

		$lastIndex = count( $segments ) - 1;
		$output    = [];
		foreach ( $segments as $index => $segment ) {
			if ( '.' !== $segment && '..' !== $segment ) {
				$output[] = $segment;
				continue;
			}

			if ( '..' === $segment ) {
				array_pop( $output );
			}

			if ( $lastIndex === $index ) {
				$output[] = '';
			}
		}

		return ( $isAbsolute ? '/' : '' ) . implode( '/', $output );
	}

	/**
	 * Returns if the path matches for a redirect.
	 *
	 * @since 4.9.1
	 *
	 * @param  Models\Redirect $redirect   The redirect data.
	 * @param  string          $requestUrl The URL to match against.
	 * @return bool                        Paths match.
	 */
	private function matchSourceRedirect( $redirect, $requestUrl ) {
		$sourceUrlPath     = Utils\Request::getUrlPath( aioseo()->helpers->decodeUrl( trim( $redirect->source_url ) ) );
		$requestUrlNoQuery = Utils\Request::getUrlPath( aioseo()->helpers->decodeUrl( $requestUrl ) ) ?: '/';
		// If we're ignoring the slash we already matched the redirect in que DB query.
		// Here we'll figure out the ignore_slash rule.
		if ( ! $redirect->ignore_slash ) {
			$sourceHasSlash  = Utils\Request::urlHasTrailingSlash( $sourceUrlPath );
			$requestHasSlash = Utils\Request::urlHasTrailingSlash( $requestUrlNoQuery );

			if ( ( $sourceHasSlash && ! $requestHasSlash ) || ( ! $sourceHasSlash && $requestHasSlash ) ) {
				return false;
			}
		}

		// If we're ignoring the case we already matched the redirect in que DB query.
		// Here we'll figure out the ignore_case rule.
		if (
			! $redirect->ignore_case &&
			untrailingslashit( $sourceUrlPath ) !== untrailingslashit( $requestUrlNoQuery )
		) {
			return false;
		}

		return true;
	}

	/**
	 * Returns matches for a regex.
	 *
	 * @since   4.9.1
	 * @version 5.0.4 Tries each {@see getRegexSubjects()} subject in turn; reports unmatched groups as null.
	 *
	 * @param  Models\Redirect $redirect   A redirect object model.
	 * @param  string          $requestUrl The request url, without the home path.
	 * @return array                       An array of matches.
	 */
	public function matchRegexRedirect( $redirect, $requestUrl ) {
		$pattern = $this->formatPattern( trim( $redirect->source_url ), $redirect->ignore_case, $redirect->ignore_slash );

		$matches = [];
		foreach ( $this->getRegexSubjects( $requestUrl ) as $subject ) {
			// Without the flag, trailing unmatched groups are left out, so their `$N` placeholders would never be replaced.
			$result = preg_match( $pattern, $subject, $matches, PREG_UNMATCHED_AS_NULL ); // phpcs:ignore PHPCompatibility.Constants.NewConstants.preg_unmatched_as_nullFound

			// An invalid pattern fails the same way for every subject; stop at the first warning.
			if ( false === $result ) {
				return [];
			}

			if ( $result ) {
				break;
			}
		}

		return $matches;
	}

	/**
	 * Returns the URLs a regex source is matched against, in priority order.
	 *
	 * Ordered most to least restrictive, so the first match wins:
	 *
	 * 1. the path, with reserved characters left encoded - a capture group can't absorb the query
	 *    string or a decoded delimiter and smuggle either into the target;
	 * 2. the full URL, so sources that deliberately match the query keep working, whichever way the
	 *    question mark is spelled (`\?`, `[?]`, or none at all as in `^.*utm_source=(.*)$`);
	 * 3. the same two fully decoded, as a last resort, so a source written against a decoded
	 *    reserved character (`\?` matching a `%3F` in the path) still matches as it used to.
	 *
	 * Later subjects only ever add matches, so no source that matched before can stop matching,
	 * while the earlier subjects keep the fix in place whenever they match.
	 *
	 * @since 5.0.4
	 *
	 * @param  string $requestUrl The request url, without the home path.
	 * @return array              The urls to match against, in priority order.
	 */
	private function getRegexSubjects( $requestUrl ) {
		$requestUrl = (string) $requestUrl;
		$parts      = explode( '?', $requestUrl, 2 );
		$hasQuery   = isset( $parts[1] );

		$subjects = [ $this->normalizeRegexSubject( $parts[0] ) ];
		if ( $hasQuery ) {
			$subjects[] = $this->normalizeRegexSubject( $requestUrl );
		}

		$subjects[] = $this->normalizeRegexSubject( $parts[0], true );
		if ( $hasQuery ) {
			$subjects[] = $this->normalizeRegexSubject( $requestUrl, true );
		}

		// Fully decoding is a no-op for most URLs, so drop the duplicates it produces.
		return array_values( array_unique( $subjects ) );
	}

	/**
	 * Normalizes a request URL into a regex matching subject.
	 *
	 * @since 5.0.4
	 *
	 * @param  string $requestUrl The request url, without the home path.
	 * @param  bool   $decodeAll  Whether to also decode the reserved delimiters.
	 * @return string             The matching subject.
	 */
	private function normalizeRegexSubject( $requestUrl, $decodeAll = false ) {
		return $decodeAll
			? rawurldecode( (string) $requestUrl )
			: Utils\Request::decodeUrlPreservingDelimiters( $requestUrl );
	}

	/**
	 * Builds the final target URL for a redirect, applying regex placeholder substitution,
	 * mid-path slash collapsing, space encoding and trailing-slash formatting.
	 *
	 * @since   4.9.9
	 * @version 5.0.4 Substitute all regex placeholders in a single prefix-safe pass.
	 *
	 * @param  Models\Redirect $redirect The redirect model.
	 * @param  array           $matches  The regex capture matches (`$redirect->regexMatches` or `matchRegexRedirect()` output).
	 * @return string                    The formatted target URL.
	 */
	public function buildTargetUrl( $redirect, $matches = [] ) {
		$targetUrl = trim( $redirect->target_url );

		if ( $redirect->regex ) {
			// Replace the target placeholders.
			if ( ! empty( $matches ) ) {
				$placeholders = [];
				foreach ( $matches as $key => $match ) {
					// Named groups add string keys too, but only numbered groups have a `$N` placeholder.
					if ( is_int( $key ) && 0 < $key ) {
						$placeholders[ '$' . $key ] = (string) $match;
					}
				}

				// strtr() prefers the longest placeholder, so `$1` can't clip the `$1` inside `$10`,
				// and it never rescans substituted values for placeholders of their own.
				$targetUrl = strtr( $targetUrl, $placeholders );

				// Collapse mid-path double slashes left by an empty capture-group substitution, while
				// preserving any `scheme://` and a leading protocol-relative `//host`. See issue #8181.
				$targetUrl = preg_replace( '#(?<!:)(?<!^)/{2,}#', '/', (string) $targetUrl );

				// A capture must not turn a relative target into a protocol-relative `//host` one.
				if ( preg_match( '#^/(?!/)#', trim( $redirect->target_url ) ) ) {
					$targetUrl = preg_replace( '#^/{2,}#', '/', (string) $targetUrl );
				}
			}

			// Space encode the target after placeholders are replaced.
			$split     = explode( '?', $targetUrl );
			$targetUrl = str_replace( ' ', '%20', $targetUrl );
			if ( count( $split ) === 2 ) {
				$targetUrl = implode( '?', [
					str_replace( ' ', '%20', $split[0] ),
					str_replace( ' ', '+', $split[1] )
				] );
			}
		}

		// Format the target URL accounting for relative URLs that may have a trailing slash.
		// Runs after placeholder substitution so regex captures containing a trailing slash
		// don't produce double slashes like `/foo/bar//`.
		return Utils\Request::formatTargetUrl( $targetUrl );
	}

	/**
	 * Process a pass through.
	 *
	 * @since 4.9.1
	 *
	 * @param  string $to The url to.
	 * @return void
	 */
	private function processPassThrough( $to ) {
		if ( Utils\Request::isUrlExternal( $to ) ) {
			echo apply_filters( 'aioseo_redirects_pass_through', wp_remote_fopen( $to ), $to ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			exit;
		}

		$parsedTo = wp_parse_url( $to );

		$_SERVER['REQUEST_URI'] = ! empty( $parsedTo['path'] ) ? $parsedTo['path'] : '';

		if ( ! empty( $parsedTo['query'] ) ) {
			$_SERVER['QUERY_STRING'] = $parsedTo['query'];
			parse_str( $parsedTo['query'], $_GET ); // phpcs:ignore HM.Security.NonceVerification.Recommended
		}
	}

	/**
	 * Process a 404.
	 *
	 * @since 4.9.1
	 *
	 * @return void
	 */
	private function process404() {
		// Resetting the global query here will allow us to use the 404 template.
		// phpcs:disable Squiz.NamingConventions.ValidVariableName
		global $wp_query;
		$wp_query = new \WP_Query();
		$wp_query->set_404();
		// phpcs:enable Squiz.NamingConventions.ValidVariableName
		status_header( 404 );
	}

	/**
	 * Match the custom rules.
	 *
	 * @since 4.9.1
	 *
	 * @param  Models\Redirect $redirect          A redirect object model.
	 * @param  string          $compareUrlRequest The url being redirected.
	 * @return boolean                            True if all the custom rules apply.
	 */
	private function matchCustomRules( $redirect, $compareUrlRequest = '' ) {
		if ( empty( $redirect->custom_rules ) || ! is_array( $redirect->custom_rules ) ) {
			return true;
		}

		foreach ( $redirect->custom_rules as $customRule ) {
			$customRule = is_object( $customRule ) ? $customRule : json_decode( wp_json_encode( $customRule ) );
			// Let's skip rules without values.
			if ( 'schedule' !== $customRule->type && empty( $customRule->value ) ) {
				continue;
			}

			// Small sanitization.
			$customRule->value = is_array( $customRule->value ) ? array_map( 'trim', $customRule->value ) : trim( $customRule->value );

			// This is used for the default matching rule.
			$valueToMatch = null;

			// Define value to match for regex and straight matches.
			switch ( $customRule->type ) {
				case 'agent':
					$valueToMatch = Utils\Request::getUserAgent();
					break;
				case 'referrer':
					$valueToMatch = Utils\Request::getReferrer();
					break;
				case 'cookie':
					$valueToMatch = Utils\Request::getCookie( $customRule->key );
					break;
				case 'header':
					$valueToMatch = Utils\Request::getRequestHeader( $customRule->key );
					break;
				case 'ip':
					$valueToMatch = Utils\Request::getIp();
					break;
				case 'server':
					$valueToMatch = Utils\Request::getServerName();
					break;
				case 'locale':
					$valueToMatch = get_locale();
					break;
			}

			// Custom matches + default match for $valueToMatch.
			switch ( $customRule->type ) {
				case 'login':
					if ( 'loggedin' === $customRule->value && ! is_user_logged_in() ) {
						return false;
					}
					if ( 'loggedout' === $customRule->value && is_user_logged_in() ) {
						return false;
					}
					break;
				case 'role':
					$matchRole = false;
					foreach ( $customRule->value as $role ) {
						if ( current_user_can( $role ) ) {
							$matchRole = true;
							break;
						}
					}
					if ( ! $matchRole ) {
						return false;
					}
					break;
				case 'wp_filter':
					$matchFilter = false;
					foreach ( $customRule->value as $filter ) {
						if ( apply_filters( $filter, false, $compareUrlRequest, $redirect ) ) {
							$matchFilter = true;
							break;
						}
					}
					if ( ! $matchFilter ) {
						return false;
					}
					break;
				case 'agent':
					$matchAgent = false;
					// Custom values for matching.
					foreach ( $customRule->value as $agentItem ) {
						$regex = ! empty( $customRule->regex );
						switch ( $agentItem ) {
							case 'mobile':
								$agentItem = 'iPad|iPod|iPhone|Android|BlackBerry|SymbianOS|SCH-Md+|Opera Mini|Windows CE|Nokia|SonyEricsson|webOS|PalmOS';
								$regex     = true;
								break;
							case 'feeds':
								$agentItem = 'Bloglines|feed|rss';
								$regex     = true;
								break;
							case 'libraries':
								$agentItem = 'cURL|Java|libwww-perl|PHP|urllib';
								$regex     = true;
								break;
						}

						$matchAgent = $agentItem === $customRule->value;
						if ( $regex ) {
							$matchAgent = $this->matchRegexRule( $agentItem, $valueToMatch );
						}

						if ( $matchAgent ) {
							break;
						}
					}

					if ( ! $matchAgent ) {
						return false;
					}
					break;
				case 'schedule':
					if ( ! empty( $customRule->scheduleStart ) && time() < strtotime( $customRule->scheduleStart ) ) {
						return false;
					}

					if ( ! empty( $customRule->scheduleEnd ) && time() > strtotime( $customRule->scheduleEnd ) ) {
						return false;
					}
					break;
				default:
					$match = is_array( $customRule->value ) ? in_array( $valueToMatch, $customRule->value, true ) : $valueToMatch === $customRule->value;
					if ( ! empty( $customRule->regex ) ) {
						$match = $this->matchRegexRule( $customRule->value, $valueToMatch );
					}

					if ( ! $match ) {
						return false;
					}
					break;
			}
		}

		return true;
	}

	/**
	 * Helper to match a regex rule against a value.
	 *
	 * @since 4.9.1
	 *
	 * @param  array|string $regex The regex.
	 * @param  string       $value The value to match against.
	 * @return false|int           The match result.
	 */
	private function matchRegexRule( $regex, $value ) {
		if ( ! is_array( $regex ) ) {
			$regex = [ $regex ];
		}
		// Try each regex and return on the first one that is true.
		foreach ( $regex as $ex ) {
			if ( preg_match( sprintf( '/%s/', $ex ), (string) $value ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Schedule actions to clear the logs.
	 *
	 * @since 4.9.1
	 *
	 * @return void
	 */
	public function scheduleActions() {
		if (
			! aioseo()->license->hasCoreFeature( 'redirects', 'logs' ) ||
			! aioseo()->core->db->tableExists( 'aioseo_redirects_404_logs' ) ||
			! aioseo()->core->db->tableExists( 'aioseo_redirects_logs' )
		) {
			return;
		}

		$actions = [
			'log404'    => [
				'action' => 'aioseo_redirects_clear_404_logs',
				'method' => 'clear404Logs'
			],
			'redirects' => [
				'action' => 'aioseo_redirects_clear_logs',
				'method' => 'clearRedirectLogs'
			]
		];

		foreach ( $actions as $k => $data ) {
			if ( ! aioseo()->redirects->options->logs->{ $k }->enabled ) {
				aioseo()->actionScheduler->unschedule( $data['action'] );
				continue;
			}

			if ( aioseo()->actionScheduler->isScheduled( $data['action'] ) ) {
				continue;
			}

			aioseo()->actionScheduler->scheduleRecurrent( $data['action'], 60, HOUR_IN_SECONDS, [] );
		}
	}

	/**
	 * Clears the 404 logs.
	 *
	 * @since 4.9.1
	 *
	 * @return void
	 */
	public function clear404Logs() {
		if ( ! aioseo()->license->hasCoreFeature( 'redirects', 'logs' ) ) {
			return;
		}

		$optionLength = json_decode( aioseo()->redirects->options->logs->log404->length )->value;
		if ( 'forever' !== $optionLength ) {
			$date = date( 'Y-m-d H:i:s', strtotime( '-1 ' . $optionLength ) );
			aioseo()->core->db
				->delete( 'aioseo_redirects_404_logs' )
				->where( 'created <', $date )
				->run();
		}

		$this->trimLogTable( 'aioseo_redirects_404_logs' );
	}

	/**
	 * Clears the redirect logs.
	 *
	 * @return void
	 */
	public function clearRedirectLogs() {
		if ( ! aioseo()->license->hasCoreFeature( 'redirects', 'logs' ) ) {
			return;
		}

		$optionLength = json_decode( aioseo()->redirects->options->logs->redirects->length )->value;
		if ( 'forever' !== $optionLength ) {
			$date = date( 'Y-m-d H:i:s', strtotime( '-1 ' . $optionLength ) );
			aioseo()->core->db
				->delete( 'aioseo_redirects_logs' )
				->where( 'created <', $date )
				->run();
		}

		$this->trimLogTable( 'aioseo_redirects_logs' );
	}

	/**
	 * Trims the log table to a maximum number of rows if it exceeds that limit.
	 *
	 * @since 4.9.5
	 *
	 * @param  string $tableName The table name.
	 * @param  int    $maxRows   The maximum number of rows to keep.
	 * @return void
	 */
	private function trimLogTable( $tableName, $maxRows = 200000 ) {
		$totalRows = aioseo()->core->db->start( $tableName )->count();
		if ( $totalRows <= $maxRows ) {
			return;
		}

		$rowsToDelete = $totalRows - $maxRows;
		aioseo()->core->db->delete( $tableName )
			->orderBy( 'id ASC' )
			->limit( $rowsToDelete )
			->run();
	}

	/**
	 * Perform any pre-redirect processing, such as logging and header fixing.
	 *
	 * @since 4.9.1
	 *
	 * @param  string $url    The target URL.
	 * @param  int    $status HTTP status.
	 * @return string         The target URL.
	 */
	public function wpRedirect( $url, $status = 302 ) {
		// These are set early on so when other filters run, we have access to it.
		$this->redirectUrl  = $url;
		$this->redirectCode = $status;

		global $is_IIS; // phpcs:ignore Squiz.NamingConventions.ValidVariableName

		if ( $is_IIS ) { // phpcs:ignore Squiz.NamingConventions.ValidVariableName
			header( "Refresh: 0;url=$url" );
		}

		if ( 301 === $status && php_sapi_name() === 'cgi-fcgi' ) {
			$serversToCheck = [ 'lighttpd', 'nginx' ];

			foreach ( $serversToCheck as $name ) {
				if (
					isset( $_SERVER['SERVER_SOFTWARE'] ) &&
					false !== stripos( wp_unslash( $_SERVER['SERVER_SOFTWARE'] ), $name ) // phpcs:ignore HM.Security.ValidatedSanitizedInput.InputNotSanitized
				) {
					status_header( $status );
					header( "Location: $url" );
					exit( 0 );
				}
			}
		}

		if ( 307 === intval( $status, 10 ) ) {
			status_header( $status );
			nocache_headers();

			return $url;
		}

		if ( ! aioseo()->redirects->options->cache->httpHeader->enabled ) {
			// No cache - just use WP function.
			nocache_headers();
		} else {
			if (
				! headers_sent() &&
				'forever' !== aioseo()->redirects->options->cache->httpHeader->length &&
				301 === intval( $status, 10 )
			) {
				// Custom cache.
				$cacheTime = 1;
				switch ( aioseo()->redirects->options->cache->httpHeader->length ) {
					case 'day':
						$cacheTime = 24;
					case 'week':
						$cacheTime = 168;
					case 'hour':
					default:
						break;
				}
				header( 'Expires: ' . gmdate( 'D, d M Y H:i:s T', time() + $cacheTime * 60 * 60 ) );
				header( 'Cache-Control: max-age=' . $cacheTime * 60 * 60 );
			}
		}

		status_header( $status );

		return $url;
	}

	/**
	 * Logs a redirect.
	 *
	 * @since 4.9.1
	 *
	 * @param  string $agent Redirect agent.
	 * @return string        Redirect agent.
	 */
	public function logExternalRedirect( $agent ) {
		if ( ! aioseo()->license->hasCoreFeature( 'redirects', 'logs' ) ) {
			return $agent;
		}

		// Have we already redirected?
		if ( $this->matched || 'aioseo' === $agent ) {
			return $agent;
		}

		if (
			! aioseo()->redirects->options->logs->external ||
			! aioseo()->redirects->options->logs->redirects->enabled
		) {
			return $agent;
		}

		$redirectBy = $agent ? strtolower( substr( $agent, 0, 50 ) ) : 'wordpress'; // phpcs:ignore WordPress.WP.CapitalPDangit.MisspelledInText
		$this->logRedirect( $this->redirectCode, $redirectBy );

		return $agent;
	}

	/**
	 * Intercept the request and parse if needed.
	 *
	 * @since 4.9.1
	 *
	 * @return void
	 */
	public function templateRedirect() {
		// Skip redirecting if it's a redirect test.
		if ( ! is_404() || Utils\Request::isRedirectTest() || 200 === http_response_code() ) {
			return;
		}

		// We don't want to log 404 urls that will be redirected by WordPress.
		if ( in_array( untrailingslashit( Utils\Request::getRequestUrl() ), Utils\WpUri::getRedirectAdminPaths(), true ) ) {
			return;
		}

		// Last check before logging a 404.
		if ( aioseo()->redirects->redirect404->avoid404Redirect() ) {
			return;
		}

		$this->log404();
	}

	/**
	 * Alternate hook for 404 logs.
	 *
	 * @since 4.9.1
	 *
	 * @param  string $template The template.
	 * @return string
	 */
	public function templateInclude( $template ) {
		$this->templateRedirect();

		return $template;
	}

	/**
	 * WordPress 'template_redirect' hook. Used to check for 404s.
	 *
	 * @since 4.9.1
	 *
	 * @return void
	 */
	public function log404() {
		if ( ! aioseo()->license->hasCoreFeature( 'redirects', 'logs' ) ) {
			return;
		}

		if ( $this->matched ) {
			return;
		}

		if ( ! aioseo()->redirects->options->logs->log404->enabled ) {
			return;
		}

		$this->logRedirect( 404 );
	}

	/**
	 * Logs the redirects.
	 *
	 * @since 4.9.1
	 *
	 * @param  int    $status     The HTTP status code.
	 * @param  string $redirectBy The redirect agent.
	 * @param  int    $redirectId The redirect ID.
	 * @return void
	 */
	private function logRedirect( $status, $redirectBy = null, $redirectId = null ) {
		if ( ! aioseo()->license->hasCoreFeature( 'redirects', 'logs' ) ) {
			return;
		}

		$ip = null;
		if ( aioseo()->redirects->options->logs->ipAddress->enabled ) {
			$ip      = Utils\Request::getIp();
			$ipLevel = json_decode( aioseo()->redirects->options->logs->ipAddress->level )->value;
			if ( 'full' !== $ipLevel ) {
				$ip = Utils\Request::maskIp( $ip );
			}
		}

		$requestUrl = Utils\Request::getRequestUrl();

		$data = [
			'url'            => $requestUrl,
			'url_hash'       => sha1( $requestUrl ),
			'domain'         => Utils\Request::getServer(),
			'sent_to'        => $this->redirectUrl,
			'agent'          => Utils\Request::getUserAgent(),
			'referrer'       => Utils\Request::getReferrer(),
			'http_code'      => $status,
			'request_method' => Utils\Request::getRequestMethod(),
			'ip'             => $ip,
			'request_data'   => [
				'source' => array_values( $this->getRedirectSource() )
			]
		];

		if ( $redirectId ) {
			$data['redirect_id'] = $redirectId;
		}

		if ( $redirectBy ) {
			$data['redirect_by'] = $redirectBy;
		}

		if ( aioseo()->redirects->options->logs->httpHeader ) {
			$data['request_data']['headers'] = Utils\Request::getRequestHeaders();
		}

		// Filter to maybe skip the redirect log.
		if ( apply_filters( 'aioseo_redirects_log_skip', false, $data ) ) {
			return;
		}

		$log = 404 === $status ? new Models\Redirects404Log() : new Models\RedirectsLog();
		$log->set( $data );
		$log->save();
	}

	/**
	 * Get a 'source' for a redirect by digging through the backtrace.
	 *
	 * @since 4.9.1
	 *
	 * @return array The redirect source.
	 */
	private function getRedirectSource() {
		$ignore = [
			'WP_Hook',
			'template-loader.php',
			'wp-blog-header.php',
		];

		// phpcs:ignore
		$source = wp_debug_backtrace_summary( null, 5, false );

		return array_filter( $source, function( $item ) use ( $ignore ) {
			foreach ( $ignore as $ignore_item ) { // phpcs:ignore Squiz.NamingConventions.ValidVariableName
				if ( strpos( $item, $ignore_item ) !== false ) { // phpcs:ignore Squiz.NamingConventions.ValidVariableName
					return false;
				}
			}

			return true;
		} );
	}

	/**
	 * Formats the regex pattern that we are using.
	 *
	 * @since   4.9.1
	 * @version 5.0.4 Only a glob-style `*` expands to `.*`; an already escaped `\/` isn't escaped again.
	 *
	 * @param  string  $pattern     The pattern to format.
	 * @param  boolean $ignoreCase  Whether to ignore case.
	 * @param  boolean $ignoreSlash Whether to ignore the slash.
	 * @return string               The formatted pattern.
	 */
	private function formatPattern( $pattern, $ignoreCase = false, $ignoreSlash = false ) {
		if ( $ignoreSlash ) {
			$pattern = Utils\Regex::ignoreSlash( $pattern );
		}

		// Escape only the slashes the admin left unescaped, so a source written with `\/` stays valid.
		$pattern = preg_replace( '/(?<!\\\\)(?:\\\\\\\\)*\K\//', '\/', (string) $pattern );

		// Expand a glob-style `*` into `.*`, but leave a `*` that validly quantifies the token before
		// it (`.*`, `[^?]*`, `(ab)*`, `\d*`) alone so it keeps its regex meaning. A `*` following
		// another quantifier (`a+*`, `a{2}*`) is not valid PCRE, so those keep expanding.
		$pattern = preg_replace( '/(?<![.\])])(?<!\\\\[a-zA-Z0-9])\*/', '.*', (string) $pattern );

		$pattern = str_replace( '\/^', '^', $pattern );
		$pattern = str_replace( '\\\'', '\'', $pattern );

		if ( preg_match( '/^\^/', (string) $pattern ) && ! preg_match( '/^\^\\\\\//', (string) $pattern ) ) {
			$pattern = str_replace( '^', '^\/', (string) $pattern );
		}

		$pattern = "/$pattern/";
		if ( $ignoreCase ) {
			$pattern .= 'i';
		}

		return $pattern;
	}

	/**
	 * Try matching a redirect to a URL.
	 *
	 * NOTE: Regex redirects are matched against a URL that keeps reserved characters encoded, path
	 * redirects against the decoded one, so $requestUrl arrives in the form the caller's redirects need.
	 *
	 * @since   4.9.1
	 * @version 5.0.4 A regex redirect's $requestUrl may keep reserved characters encoded.
	 *
	 * @param  Models\Redirect $redirect   A redirect object model.
	 * @param  string          $requestUrl The request url.
	 * @return bool|array                  Whether the redirect matches the url or a regex match array.
	 */
	private function matchRedirect( $redirect, $requestUrl ) {
		// Regex first.
		if ( $redirect->regex ) {
			$matches = $this->matchRegexRedirect( $redirect, $requestUrl );
			if ( empty( $matches ) ) {
				return false;
			}

			return $matches;
		}

		// Prevent redirect loop.
		if ( $this->isRedirectLoop( $redirect ) ) {
			return false;
		}

		// Try matching the source.
		if ( ! $this->matchSourceRedirect( $redirect, $requestUrl ) ) {
			return false;
		}

		// Try matching the query string parameters.
		if ( ! $this->matchQueryStringRedirect( $redirect, $requestUrl ) ) {
			return false;
		}

		return true;
	}

	/**
	 * Returns whether any enabled redirects of the given type exist. The count is cached to avoid a DB query per request.
	 *
	 * @since 5.0.1
	 *
	 * @param  string $type The redirect type to check, 'regular' or 'regex'.
	 * @return bool         Whether enabled redirects of the given type exist.
	 */
	private function hasEnabledRedirects( $type ) {
		$cacheName = aioseo()->redirects->cache->getEnabledCountCacheName( $type );
		$count     = aioseo()->redirects->cache->get( $cacheName );
		if ( null === $count ) {
			$count = aioseo()->core->db->start( 'aioseo_redirects' )
				->where( 'enabled', 1 )
				->where( 'regex', 'regex' === $type ? 1 : 0 )
				->count();
			aioseo()->redirects->cache->update( $cacheName, $count, WEEK_IN_SECONDS );
		}

		return 0 < (int) $count;
	}

	/**
	 * Match and cache regular redirects for a URL.
	 *
	 * @since 4.9.1
	 *
	 * @param  string     $requestUrl The full request url.
	 * @param  int|string $enabled    Enabled redirects 1|0|all.
	 * @return array                  An array of matched redirects.
	 */
	public function getRegularRedirects( $requestUrl, $enabled = 1 ) {
		// Don't match or cache anything when there are no enabled regular redirects.
		if ( 1 === $enabled && ! $this->hasEnabledRedirects( 'regular' ) ) {
			return [];
		}

		$requestUrl = Utils\WpUri::excludeHomeUrl( $requestUrl );
		$redirects  = aioseo()->redirects->cache->getRedirects( $requestUrl );
		if ( null === $redirects ) {
			$redirects = $this->matchRegularRedirects( $requestUrl, $enabled );
			aioseo()->redirects->cache->setRedirects( $requestUrl, $redirects );
		}

		return $redirects;
	}

	/**
	 * Matches redirects for a URL.
	 *
	 * @since 4.9.1
	 *
	 * @param  string     $requestUrl The full request url.
	 * @param  int|string $enabled    Enabled redirects 1|0|all.
	 * @return array                  An array of matched redirects.
	 */
	private function matchRegularRedirects( $requestUrl, $enabled = 1 ) {
		$requestUrlNoQuery = Utils\Request::getUrlPath( $requestUrl ) ?: '/';
		$redirects         = $this->getRedirectsBySource( $requestUrlNoQuery, $enabled );
		foreach ( $redirects as $key => $redirect ) {
			if ( ! $this->matchRedirect( $redirect, $requestUrl ) ) {
				unset( $redirects[ $key ] );
			}
		}

		return $redirects ?: [];
	}

	/**
	 * Match and cache regex redirects for a URL.
	 *
	 * NOTE: The cache name is versioned. Entries hold the capture groups they matched with, so ones
	 * written by an earlier release would keep serving captures computed the old way for as long as
	 * they live - a bumped name retires them instead of waiting a week for them to expire.
	 *
	 * @since   4.9.1
	 * @version 5.0.4 Reserved characters in $requestUrl may stay encoded; cache name versioned to `regex2`.
	 *
	 * @param  string     $requestUrl The request url.
	 * @param  int|string $enabled    Enabled redirects 1|0|all.
	 * @return array                  The regex redirects.
	 */
	public function getRegexRedirects( $requestUrl, $enabled = 1 ) {
		// Don't match or cache anything when there are no enabled regex redirects.
		if ( 1 === $enabled && ! $this->hasEnabledRedirects( 'regex' ) ) {
			return [];
		}

		$requestUrl = Utils\WpUri::excludeHomeUrl( $requestUrl );
		$cacheName  = 'regex2:' . $requestUrl;
		$redirects  = aioseo()->redirects->cache->getRedirects( $cacheName );
		if ( null === $redirects ) {
			$redirects = $this->matchRegexRedirects( $requestUrl, $enabled );
			aioseo()->redirects->cache->setRedirects( $cacheName, $redirects );
		}

		return $redirects;
	}

	/**
	 * Matches redirects for a URL.
	 *
	 * @since   4.9.1
	 * @version 5.0.4 Reserved characters in $requestUrl may stay encoded.
	 *
	 * @param  string     $requestUrl The request url.
	 * @param  int|string $enabled    Enabled redirects 1|0|all.
	 * @return array                  An array of matched redirects.
	 */
	public function matchRegexRedirects( $requestUrl, $enabled = 1 ) {
		$redirects = $this->getAllRegexRedirects( $enabled );
		foreach ( $redirects as $key => &$redirect ) {
			$matches = $this->matchRedirect( $redirect, $requestUrl );
			if ( empty( $matches ) ) {
				unset( $redirects[ $key ] );
				continue;
			}

			$redirect->regexMatches = $matches;
		}

		return $redirects ?: [];
	}

	/**
	 * Gets all redirects for a URL. This is not cached and used for the Redirects post metabox.
	 *
	 * @since 4.9.1
	 *
	 * @param  string     $requestUrl The full request url.
	 * @param  int|string $enabled    Enabled redirects 1|0|all.
	 * @return array                  An array of matched redirects.
	 */
	public function getRedirects( $requestUrl, $enabled = 1 ) {
		$requestUrl = Utils\WpUri::excludeHomeUrl( $requestUrl );

		return array_merge(
			$this->matchRegularRedirects( $requestUrl, $enabled ),
			$this->matchRegexRedirects( $requestUrl, $enabled )
		);
	}

	/**
	 * Return all redirects for a source.
	 *
	 * @since 4.9.1
	 *
	 * @param  string     $requestUrl The request url.
	 * @param  int|string $enabled    Enabled redirects 1|0|all.
	 * @return array                  The redirects.
	 */
	public function getRedirectsBySource( $requestUrl, $enabled = 1 ) {
		$requestUrlNoQuery = Utils\Request::getUrlPath( $requestUrl ) ?: '/';

		$query = aioseo()->core->db->start( 'aioseo_redirects' )
			->where( 'source_url_match_hash', Utils\Request::getMatchedUrlHash( $requestUrlNoQuery ) )
			->orderBy( 'id DESC' );

		if ( 'all' !== $enabled ) {
			$query->where( 'enabled', $enabled );
		}

		return $query->run()->models( 'AIOSEO\\Plugin\\Pro\\Redirects\\Models\\Redirect' );
	}

	/**
	 * Return all redirects for a target.
	 *
	 * @since 4.9.1
	 *
	 * @param  string     $targetUrl  The target url.
	 * @param  int|string $enabled    Enabled redirects 1|0|all.
	 * @return array                  The redirects.
	 */
	public function getRedirectsByTarget( $targetUrl, $enabled = 1 ) {
		$targetUrlNoQuery = wp_parse_url( $targetUrl );
		$targetUrlNoQuery = ! empty( $targetUrlNoQuery['path'] ) ? $targetUrlNoQuery['path'] : '/';

		$query = aioseo()->core->db->start( 'aioseo_redirects' )
			->where( 'target_url_hash', Utils\Request::getUrlHash( $targetUrlNoQuery ) )
			->orderBy( 'id DESC' );

		if ( 'all' !== $enabled ) {
			$query->where( 'enabled', $enabled );
		}

		return $query->run()->models( 'AIOSEO\\Plugin\\Pro\\Redirects\\Models\\Redirect' );
	}

	/**
	 * Return all regex redirects.
	 *
	 * @since 4.9.1
	 *
	 * @param  int|string $enabled Enabled redirects 1|0|all.
	 * @return array               The regex redirects.
	 */
	private function getAllRegexRedirects( $enabled ) {
		$query = aioseo()->core->db->start( 'aioseo_redirects' )
			->where( 'source_url_match_hash', Utils\Request::getRegexHash() )
			->orderBy( 'id DESC' );

		if ( 'all' !== $enabled ) {
			$query->where( 'enabled', $enabled );
		}

		return $query->run()->models( 'AIOSEO\\Plugin\\Pro\\Redirects\\Models\\Redirect' );
	}

	/**
	 * Checks whether the current request is for a page builder preview.
	 * If so, don't need to check for redirects because we'll otherwise break page builder.
	 *
	 * @since 4.9.1
	 *
	 * @return bool Whether the current request is for the page builder preview.
	 */
	public function isPageBuilderPreviewRequest() {
		$pageBuilderRequest = [
			'elementor'  => [ 'elementor-preview' ],
			'wpbakery'   => [ 'vc_editable' ],
			'avada'      => [ 'fb-edit', 'builder_id' ],
			'divi'       => [ 'et_fb' ],
			'siteorigin' => [ 'siteorigin_panels_live_editor' ],
			'thrive'     => [ 'tve', 'tcbf' ],
			'bricks'     => [ 'bricks' ],
			'oxygen'     => [ 'oxygen', 'breakdance_iframe' ]
		];

		foreach ( $pageBuilderRequest as $pageBuilder => $possibleRequests ) {
			foreach ( $possibleRequests as $request ) {
				if ( ! empty( $_REQUEST[ $request ] ) ) { // phpcs:ignore HM.Security.NonceVerification.Recommended
					return isset( aioseo()->standalone->pageBuilderIntegrations[ $pageBuilder ] ) && aioseo()->standalone->pageBuilderIntegrations[ $pageBuilder ]->isActive();
				}
			}
		}

		return false;
	}

	/**
	 * Return a redirect for a post id.
	 *
	 * @since 4.9.1
	 *
	 * @param  int             $postId The post ID.
	 * @return Models\Redirect         The redirect tied to the post id.
	 */
	public function getRedirectByPostId( $postId ) {
		$query = aioseo()->core->db->start( 'aioseo_redirects' )->where( 'post_id', $postId )->orderBy( 'id DESC' );

		// This assumes there's only one tied redirect at any given time.
		return $query->run()->model( 'AIOSEO\\Plugin\\Pro\\Redirects\\Models\\Redirect' );
	}
}