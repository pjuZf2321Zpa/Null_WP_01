<?php
namespace AIOSEO\Plugin\Pro\Redirects\Main;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AIOSEO\Plugin\Pro\Redirects\Utils;
use AIOSEO\Plugin\Pro\Redirects\Models;
use AIOSEO\Plugin\Pro\Redirects\Utils\WpUri;

/**
 * Main class to run our 404 redirects.
 *
 * @since 4.9.1
 */
class Redirect404 {
	/**
	 * Class constructor.
	 *
	 * @since 4.9.1
	 */
	public function __construct() {
		add_action( 'init', [ $this, 'init' ], 1 );
	}

	/**
	 * Initialize the class after AIOSEO is fully loaded.
	 *
	 * @since 4.9.1
	 *
	 * @return void
	 */
	public function init() {
		if ( ! aioseo()->redirects->options->advanced404s->enabled ) {
			return;
		}

		if ( apply_filters( 'aioseo_redirects_use_alternate_404_hook', false, Utils\Request::getRequestUrl() ) ) {
			add_filter( 'template_include', [ $this, 'templateInclude' ], 10 );
		} else {
			// Maybe redirect 404s.
			add_action( 'template_redirect', [ $this, 'templateRedirect' ], 2000 );

			// Maybe short-circuit WP's redirect guess.
			add_filter( 'pre_redirect_guess_404_permalink', [ $this, 'redirectGuess' ] );
		}
	}

	/**
	 * Short-circuit WP's redirect guess.
	 *
	 * @since 4.9.1
	 *
	 * @param  string|null $guessUrl The pre guess url.
	 * @return string                The guess url.
	 */
	public function redirectGuess( $guessUrl ) {
		if ( ! Utils\Request::isRedirectTest() ) {
			$this->maybeRedirect();
		}

		return $guessUrl;
	}

	/**
	 * Intercept the request and redirect after logs have been saved.
	 *
	 * @since 4.9.1
	 *
	 * @return void
	 */
	public function templateRedirect() {
		// Skip redirecting if it's a redirect test.
		if ( ! is_404() || Utils\Request::isRedirectTest() || 200 === http_response_code() ) {
			return;
		}

		$this->maybeRedirect();
	}

	/**
	 * Tries to redirect a 404.
	 *
	 * @since   4.9.1
	 * @version 5.0.2 Skip asset paths via {@see WpUri::isAssetPath()}.
	 *
	 * @return void
	 */
	public function maybeRedirect() {
		// Check if we should really redirect 404s.
		if ( $this->avoid404Redirect() ) {
			return;
		}

		// Asset/infrastructure paths — admin/frontend pages fetch these via <script>/<link>/fetch();
		// redirecting them to a cross-origin URL triggers CORS errors (e.g. stale plugin-update chunks).
		// This stays out of avoid404Redirect() because those are still real 404s that belong in the log.
		if ( WpUri::isAssetPath( Utils\Request::getRequestUrl() ) ) {
			return;
		}

		// Smart slug redirect.
		// Skip it when a manual redirect already matches this URL; otherwise the two can ping-pong into a loop.
		if ( aioseo()->redirects->options->advanced404s->redirectToSmart && ! $this->hasManualRedirect() ) {
			$this->smartRedirect();
		}

		// We'll try redirecting to the parent first.
		if ( aioseo()->redirects->options->advanced404s->redirectToParent ) {
			$this->parentRedirect();
		}

		if ( aioseo()->redirects->options->advanced404s->redirectDefaultEnabled ) {
			switch ( aioseo()->redirects->options->advanced404s->redirectDefault ) {
				// Try redirecting to a Custom URL
				case 'custom':
					$this->customRedirect();
					break;
				// Last fallback is to the home page.
				case 'home':
					aioseo()->redirects->helpers->do404Redirect( get_home_url(), 'HOME' );
					break;
			}
		}
	}

	/**
	 * Smart redirect.
	 *
	 * @since 4.9.1
	 *
	 * @return void
	 */
	private function smartRedirect() {
		// Separate the path.
		$path = array_filter( explode( '/', Utils\Request::getRequestUrl() ) );

		// Get the last item which should be always the post name/slug.
		$slug = array_pop( $path );

		if ( empty( $slug ) ) {
			return;
		}

		// Look in the database if there's any post_type with the exact same name/slug.
		$post = aioseo()->core->db->start( 'posts' )
			->select( 'ID, post_type' )
			->where( [
				'post_name'   => $slug,
				'post_status' => 'publish'
			] )
			->run()
			->result();

		if (
			empty( $post ) ||
			empty( $post[0]->ID ) ||
			! aioseo()->helpers->isPostTypePublic( $post[0]->post_type )
		) {
			return;
		}

		$permalink = get_permalink( $post[0]->ID );
		if ( empty( $permalink ) ) {
			return;
		}

		// Prevent redirect loop.
		if ( Utils\Request::formatTargetUrl( Utils\Request::getRequestUrl() ) === $permalink ) {
			return;
		}

		// Let's redirect to the found post URL.
		aioseo()->redirects->helpers->do404Redirect( $permalink, 'SMART' );
		die;
	}

	/**
	 * Tries to redirect to a custom url.
	 *
	 * @since 4.9.1
	 *
	 * @return void
	 */
	private function customRedirect() {
		$url = aioseo()->redirects->options->advanced404s->redirectToCustomUrl;
		if ( empty( $url ) ) {
			return;
		}

		$url = Utils\Request::formatTargetUrl( $url );

		// Prevent redirect loop.
		if ( Utils\Request::formatTargetUrl( Utils\Request::getRequestUrl() ) === $url ) {
			return;
		}

		aioseo()->redirects->helpers->do404Redirect( $url, 'CUSTOM' );
	}

	/**
	 * Tries to redirect to a stored parent reference.
	 *
	 * @since 4.9.1
	 *
	 * @return void
	 */
	private function parentRedirect() {
		if ( ! aioseo()->license->hasCoreFeature( 'redirects', 'advanced-404-settings' ) ) {
			return;
		}

		$requestUrl  = Utils\Request::getRequestUrl();
		$redirect404 = Models\Redirect404::getRedirectByUrl( $requestUrl );
		if ( ! $redirect404->exists() ) {
			$this->dynamicParentRedirect( $requestUrl );

			return;
		}

		$redirectParent = new RedirectParent404( $redirect404 );

		// Redirects below are in order of importance.
		// 1. First the parent post.
		$redirectParent->postParentRedirect();

		// 2. Second the parent term.
		$redirectParent->termParentRedirect();

		// 3. WooCommerce redirect to the shop page.
		$redirectParent->woocommerceParentRedirect();

		// 4. Lastly, let's try the post type archive.
		$redirectParent->postTypeArchiveRedirect();
	}

	/**
	 * Dynamically tries to redirect a 404 URL to its parent path.
	 *
	 * This is a fallback for when no pre-recorded 404 redirect exists in the database.
	 * It parses the URL segments and tries to find a valid parent post or term.
	 *
	 * @since 5.0.1
	 *
	 * @param  string $requestUrl The request URL path.
	 * @return void
	 */
	private function dynamicParentRedirect( $requestUrl ) {
		$segments = array_values( array_filter( explode( '/', $requestUrl ) ) );

		// We need at least 2 segments (parent + child) to attempt a parent redirect.
		if ( count( $segments ) < 2 ) {
			return;
		}

		// Walk up the URL hierarchy, trying each parent level.
		// For /a/b/c/d, we try /a/b/c, then /a/b, then /a.
		while ( count( $segments ) > 1 ) {
			array_pop( $segments );
			$parentPath = implode( '/', $segments );

			// 1. Try to find a matching post by the parent path.
			$this->tryPostByPath( $parentPath );

			// 2. Try to find a matching term by the last segment of the parent path.
			$parentSlug = end( $segments );
			$this->tryTermBySlug( $parentSlug );
		}

		// 3. Try WooCommerce shop page fallback.
		$this->tryWooCommerceShopRedirect( $requestUrl );
	}

	/**
	 * Tries to find a published post by its path and redirect to it.
	 *
	 * @since 5.0.1
	 *
	 * @param  string $path The URL path to look up.
	 * @return void
	 */
	private function tryPostByPath( $path ) {
		static $hierarchicalTypes = null;
		if ( null === $hierarchicalTypes ) {
			$hierarchicalTypes = array_values( get_post_types( [
				'public'       => true,
				'hierarchical' => true
			] ) );
		}

		if ( empty( $hierarchicalTypes ) ) {
			return;
		}

		$post = get_page_by_path( $path, OBJECT, $hierarchicalTypes );
		if ( empty( $post ) || 'publish' !== $post->post_status || ! empty( $post->post_password ) ) {
			return;
		}

		$permalink = get_permalink( $post );
		if ( empty( $permalink ) ) {
			return;
		}

		aioseo()->redirects->helpers->do404Redirect( $permalink, 'PARENT-POST' );
	}

	/**
	 * Tries to find a term by slug across public taxonomies and redirect to it.
	 *
	 * @since 5.0.1
	 *
	 * @param  string $slug The term slug to look up.
	 * @return void
	 */
	private function tryTermBySlug( $slug ) {
		static $taxonomies = null;
		if ( null === $taxonomies ) {
			$taxonomies = get_taxonomies( [ 'public' => true ] );
		}

		foreach ( $taxonomies as $taxonomy ) {
			$term = get_term_by( 'slug', $slug, $taxonomy );
			if ( empty( $term ) ) {
				continue;
			}

			$termLink = get_term_link( $term );
			if ( is_wp_error( $termLink ) || empty( $termLink ) ) {
				continue;
			}

			aioseo()->redirects->helpers->do404Redirect( $termLink, 'PARENT-TERM' );
		}
	}

	/**
	 * Tries to redirect to the WooCommerce shop page if the URL matches a product or category base.
	 *
	 * @since 5.0.1
	 *
	 * @param  string $requestUrl The request URL path.
	 * @return void
	 */
	private function tryWooCommerceShopRedirect( $requestUrl ) {
		if ( ! aioseo()->helpers->isWooCommerceActive() || ! aioseo()->redirects->options->advanced404s->redirectToParentWoocommerce ) {
			return;
		}

		$permalinkStructure = wc_get_permalink_structure();
		$productBase        = trim( $permalinkStructure['product_rewrite_slug'] ?? '', '/' );
		$categoryBase       = trim( $permalinkStructure['category_rewrite_slug'] ?? '', '/' );

		$requestPath = trim( $requestUrl, '/' );
		$isProduct   = ! empty( $productBase ) && 0 === strpos( $requestPath, $productBase . '/' );
		$isCategory  = ! empty( $categoryBase ) && 0 === strpos( $requestPath, $categoryBase . '/' );

		if ( ! $isProduct && ! $isCategory ) {
			return;
		}

		$shopPage = wc_get_page_id( 'shop' );
		if ( ! empty( $shopPage ) && 0 < $shopPage ) {
			aioseo()->redirects->helpers->do404Redirect( get_permalink( $shopPage ), 'PARENT-WC' );
		}
	}

	/**
	 * Whether an enabled manual redirect already matches the current request URL.
	 *
	 * @since   5.0.1
	 * @version 5.0.4 Regex redirects match against {@see Utils\Request::getRegexRequestUrl()}.
	 *
	 * @return bool
	 */
	private function hasManualRedirect() {
		return ! empty( aioseo()->redirects->redirect->getRegularRedirects( Utils\Request::getRequestUrl() ) ) ||
			! empty( aioseo()->redirects->redirect->getRegexRedirects( Utils\Request::getRegexRequestUrl() ) );
	}

	/**
	 * Check if we should avoid redirecting 404s.
	 *
	 * @since 4.9.1
	 *
	 * @return bool
	 */
	public function avoid404Redirect() {
		$avoid      = false;
		$requestUrl = Utils\Request::getRequestUrl();

		// Check html sitemap dedicated page.
		if (
			aioseo()->options->sitemap->html->enable &&
			rtrim( WpUri::excludeHomeUrl( aioseo()->options->sitemap->html->pageUrl ), '/' ) === rtrim( $requestUrl, '/' )
		) {
			$avoid = true;
		}

		// We don't want to redirect 404 urls that will be redirected by WordPress.
		if ( in_array( untrailingslashit( $requestUrl ), WpUri::getRedirectAdminPaths(), true ) ) {
			$avoid = true;
		}

		if ( ! $avoid && aioseo()->redirects->redirect->isPageBuilderPreviewRequest() ) {
			$avoid = true;
		}

		return apply_filters( 'aioseo_redirects_avoid_advanced_404_redirect', $avoid, $requestUrl );
	}

	/**
	 * Alternate hook for 404 redirects.
	 *
	 * @since 4.9.1
	 *
	 * @param  string $template The template.
	 * @return string
	 */
	public function templateInclude( $template ) {
		$this->templateRedirect();

		return $template;
	}
}