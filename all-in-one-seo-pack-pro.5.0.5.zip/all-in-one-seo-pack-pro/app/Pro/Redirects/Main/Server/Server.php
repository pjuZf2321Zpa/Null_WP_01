<?php
namespace AIOSEO\Plugin\Pro\Redirects\Main\Server;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AIOSEO\Plugin\Pro\Redirects\Models;
use AIOSEO\Plugin\Pro\Redirects\Utils;

/**
 * Main class to work with server redirects.
 *
 * @since 4.9.1
 */
abstract class Server {
	/**
	 * The URL format.
	 *
	 * @since 4.9.1
	 *
	 * @var string
	 */
	protected $urlFormat = '';

	/**
	 * The regex format.
	 *
	 * @since 4.9.1
	 *
	 * @var string
	 */
	protected $regexFormat = '';

	/**
	 * The relocation format.
	 *
	 * @since 4.9.1
	 *
	 * @var string
	 */
	protected $relocationFormat = '';

	/**
	 * The alias format.
	 *
	 * @since 4.9.1
	 *
	 * @var string
	 */
	protected $aliasFormat = '';

	/**
	 * File path for the redirects file.
	 *
	 * @since 4.9.1
	 *
	 * @var string|null
	 */
	protected $filePath = null;

	/**
	 * The start of the server code.
	 *
	 * @since 4.9.1
	 *
	 * @var string
	 */
	protected $preContent = '';

	/**
	 * The end of the server code.
	 *
	 * @since 4.9.1
	 *
	 * @var string
	 */
	protected $postContent = '';

	/**
	 * The Test class.
	 *
	 * @since 4.9.1
	 *
	 * @var Test
	 */
	public $test = null;

	/**
	 * Class constructor.
	 *
	 * @since 4.9.1
	 */
	public function __construct() {
		$uploadDirectory    = wp_upload_dir();
		$redirectsDirectory = $uploadDirectory['basedir'] . '/aioseo/redirects/';
		$this->filePath     = $redirectsDirectory . '.redirects';
		if ( wp_mkdir_p( $redirectsDirectory ) ) {
			$fs = aioseo()->core->fs;
			if ( ! $fs->exists( $this->filePath ) ) {
				$fs->touch( $this->filePath );
			}

			if ( ! $fs->exists( $redirectsDirectory . 'index.php' ) ) {
				$fs->touch( $redirectsDirectory . 'index.php' );
				$fs->putContents( $redirectsDirectory . 'index.php', '<?php' . PHP_EOL . '// Silence is golden.' );
			}

			if ( ! $fs->exists( $redirectsDirectory . '.htaccess' ) ) {
				$fs->touch( $redirectsDirectory . '.htaccess' );
				$fs->putContents( $redirectsDirectory . '.htaccess', "Options -Indexes\ndeny from all" );
			}
		}

		$this->test = new Test();
	}

	/**
	 * Exports the server config file content.
	 *
	 * @since   4.9.1
	 * @version 5.0.3 Skip redirects whose type requires a target but have none.
	 *
	 * @return string
	 */
	public function getConfigFileContent() {
		$content = $this->getAioseoRedirectTest();

		// If there's a relocation we don't need any more rules.
		$relocation = aioseo()->redirects->fullSiteRedirects->shouldRelocate();
		if ( $relocation ) {
			$content .= $this->formatRelocation( $relocation, implode( '|', Utils\Request::getProtectedPaths() ) ) . PHP_EOL;

			return $content;
		}

		// Aliases.
		$aliases = aioseo()->redirects->fullSiteRedirects->getAliases();
		if ( ! empty( $aliases ) ) {
			foreach ( $aliases as $alias ) {
				$content .= $this->formatAlias( $alias ) . PHP_EOL;
			}
		}

		// Canonical.
		$canonical = aioseo()->redirects->fullSiteRedirects->shouldCanonical();
		if ( $canonical ) {
			$content .= $this->formatCanonical(
				$canonical,
				aioseo()->redirects->options->fullSite->canonical->httpToHttps,
				aioseo()->redirects->options->fullSite->canonical->preferredDomain
			) . PHP_EOL;
		}

		$redirects = aioseo()->core->db->start( 'aioseo_redirects' )
			->where( 'enabled', 1 )
			->groupBy( 'source_url' )
			->run()
			->result();

		if ( ! empty( $redirects ) ) {
			foreach ( $redirects as $redirect ) {
				// A target-less rule would send the visitor to the site root once the server rewrites it.
				if ( aioseo()->redirects->helpers->isMissingTarget( $redirect ) ) {
					continue;
				}

				$formattedRedirect = $this->format( $redirect );
				if ( ! empty( $formattedRedirect ) ) {
					$content .= $formattedRedirect . PHP_EOL;
				}
			}
		}

		return $content;
	}

	/**
	 * Exports an array of redirects.
	 *
	 * @since 4.9.1
	 *
	 * @return void
	 */
	public function export() {
		// Empty file if server redirects are disabled.
		if ( ! $this->valid() ) {
			$this->save( $this->getAioseoRedirectTest() );

			return;
		}

		// Regenerate the server config test, so we can make sure the configuration works.
		$this->test->regenerateTestRedirect();

		// Save the content.
		$this->save( $this->getConfigFileContent() );
	}

	/**
	 * Save the redirect file.
	 *
	 * @since 4.9.1
	 *
	 * @param  string  $content The file content that will be saved.
	 * @return void
	 */
	protected function save( $content ) {
		$content = $this->preContent . $content . $this->postContent;

		// Save the actual file.
		if ( aioseo()->core->fs->isWritable( $this->filePath ) ) {
			aioseo()->core->fs->putContents( $this->filePath, $content );
		}
	}

	/**
	 * Formats a redirect for use in the export.
	 *
	 * @since 4.9.1
	 *
	 * @param  object $redirect The redirect to format.
	 * @return mixed            The formatted redirect.
	 */
	abstract public function format( $redirect );

	/**
	 * Get's a test redirect to use when ensuring users have set it up correctly.
	 *
	 * @since 4.9.1
	 *
	 * @return string The test redirect.
	 */
	abstract protected function getAioseoRedirectTest();

	/**
	 * Formats a relocation.
	 *
	 * @since 4.9.1
	 *
	 * @param  string $relocationAddress The redirect to format.
	 * @return string                    The formatted redirect.
	 */
	abstract public function formatRelocation( $relocationAddress, $protectedPaths = '' );

	/**
	 * Formats an alias.
	 *
	 * @since 4.9.1
	 *
	 * @param  string $alias The alias to format.
	 * @return string        The formatted alias.
	 */
	abstract public function formatAlias( $alias );

	/**
	 * Formats a canonical redirect.
	 *
	 * @since 4.9.1
	 *
	 * @return void|string The formatted redirect.
	 */
	abstract public function formatCanonical( $url, $https = false, $preferredDomain = '' );

	/**
	 * Returns the needed format for the redirect.
	 *
	 * @param  boolean $regex Whether or not to use regex.
	 * @return string         The format to use.
	 */
	protected function getFormat( $regex = false ) {
		return $regex ? $this->regexFormat : $this->urlFormat;
	}

	/**
	 * Escapes a regex redirect source for safe interpolation into a (quoted) server directive.
	 *
	 * Regex sources are written verbatim into the generated server config. Control characters
	 * (newlines/tabs) would split a directive and a literal double quote would close the quoted
	 * value, so both must be neutralized - including for rows that predate input sanitization.
	 * Backslashes are escaped first: both Nginx and Apache treat backslash as the in-quote escape,
	 * so a source `\"` (or a trailing `\`) would otherwise collapse the quote we add and break out.
	 *
	 * @since 4.9.10
	 *
	 * @param  string $source The regex source URL.
	 * @return string         The escaped source, safe to place inside a double-quoted directive value.
	 */
	protected function escapeRegexSource( $source ) {
		$source = (string) preg_replace( '/[\x00-\x1F\x7F]/', '', (string) $source );
		$source = str_replace( '\\', '\\\\', $source );

		return str_replace( '"', '\"', $source );
	}

	/**
	 * Replaces control characters in a regex built from a plain source, raw or percent-encoded, with `\xHH` escapes.
	 *
	 * @since 5.0.5
	 *
	 * @param  string $source The regex built from a plain source.
	 * @return string         The regex with its control characters escaped.
	 */
	protected function escapeControlCharacters( $source ) {
		// Sources store control characters percent-encoded, but the server matches the decoded path.
		$source = (string) preg_replace_callback(
			'/%([01][0-9a-f]|7f)/i',
			function ( $matches ) {
				return '\x' . strtoupper( $matches[1] );
			},
			(string) $source
		);

		// Rows saved before control characters were encoded can still hold them raw.
		return (string) preg_replace_callback(
			'/[\x00-\x1F\x7F]/',
			function ( $matches ) {
				return sprintf( '\x%02X', ord( $matches[0] ) );
			},
			$source
		);
	}

	/**
	 * Reset the redirects.
	 *
	 * @since 4.9.1
	 *
	 * @return void
	 */
	public function rewrite() {
		$this->export();
	}

	/**
	 * Checks if server redirects are valid.
	 *
	 * @since 4.9.1
	 *
	 * @return boolean True if valid, false otherwise.
	 */
	public function valid() {
		if ( 'server' !== aioseo()->redirects->options->main->method ) {
			return false;
		}

		if (
			aioseo()->helpers->isApache() ||
			aioseo()->helpers->isNginx() ||
			aioseo()->helpers->isLiteSpeed()
		) {
			return true;
		}

		return false;
	}

	/**
	 * Returns the server name (e.g. Apache, Nginx, Litespeed).
	 *
	 * @since 4.9.1
	 *
	 * @return string The server name.
	 */
	public function getName() {
		return aioseo()->helpers->getServerName();
	}

	/**
	 * Returns an instance for the current server.
	 *
	 * @since 4.9.1
	 *
	 * @return Apache|Nginx|Unknown
	 */
	public static function getServer() {
		if ( aioseo()->helpers->isApache() || aioseo()->helpers->isLiteSpeed() ) {
			return new Apache();
		}
		if ( aioseo()->helpers->isNginx() ) {
			return new Nginx();
		}

		return new Unknown();
	}

	/**
	 * Checks if a redirect should be handled by the server.
	 *
	 * @since   4.9.1
	 * @version 5.0.4 Excludes regex redirects whose target uses a `$10` or higher back-reference.
	 *
	 * @param  Models\Redirect $redirect The redirect to check.
	 * @return bool                      Whether or not the redirect should be handled by the server.
	 */
	public function shouldRedirect( $redirect ) {
		// Pass-through.
		if ( 0 === (int) $redirect->type ) {
			return false;
		}

		// Custom rules are handled in PHP.
		if ( ! empty( $redirect->custom_rules ) ) {
			return false;
		}

		// Apache and Nginx only read single-digit back-references, so they'd resolve `$10` as `$1` followed by "0".
		if ( $redirect->regex && preg_match( '/\$[1-9]\d/', (string) $redirect->target_url ) ) {
			return false;
		}

		return true;
	}
}