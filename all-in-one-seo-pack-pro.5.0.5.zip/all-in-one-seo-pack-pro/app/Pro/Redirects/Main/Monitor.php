<?php
namespace AIOSEO\Plugin\Pro\Redirects\Main;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AIOSEO\Plugin\Pro\Redirects\Models;
use AIOSEO\Plugin\Pro\Redirects\Utils;

/**
 * Monitors changes to posts.
 *
 * @since 4.9.1
 */
class Monitor {
	/**
	 * Class constructor.
	 *
	 * @since 4.9.1
	 */
	public function __construct() {
		// We can't monitor changes without permalinks enabled.
		if ( ! get_option( 'permalink_structure' ) ) {
			return;
		}

		add_action( 'init', [ $this, 'init' ], 1 );
	}

	/**
	 * Initialize the class after AIOSEO is fully loaded.
	 *
	 * @since   4.9.1
	 * @version 5.0.3 Hook permanent deletion instead of trashing so restoring a post preserves its redirect.
	 *
	 * @return void
	 */
	public function init() {
		if ( aioseo()->redirects->options->monitor->trash ) {
			add_action( 'wp_trash_post', [ $this, 'postTrashing' ] );
			add_action( 'before_delete_post', [ $this, 'postDeleted' ] );
			add_action( 'untrashed_post', [ $this, 'postUntrashed' ] );
		}
	}

	/**
	 * Adds an automatic redirect.
	 *
	 * @since 4.9.1
	 *
	 * @param  string $postType The post type.
	 * @param  string $before   The url before.
	 * @param  string $after    The url after.
	 * @return bool             Automatic redirect added.
	 */
	public function automaticRedirect( $postType, $before, $after ) {
		if ( ! $this->canMonitorPostType( $postType ) ) {
			return false;
		}

		$this->addRedirect( $before, $after );

		return true;
	}

	/**
	 * Checks if this is a post we can monitor.
	 *
	 * @since 4.9.1
	 *
	 * @param  string $postType  The post type.
	 * @return bool              True if we can monitor this post type.
	 */
	public function canMonitorPostType( $postType ) {
		if (
			! in_array( $postType, aioseo()->redirects->options->monitor->postTypes->included, true ) &&
			! aioseo()->redirects->options->monitor->postTypes->all
		) {
			return false;
		}

		// Don't do anything is the post type is not public.
		if ( ! is_post_type_viewable( $postType ) ) {
			return false;
		}

		return true;
	}

	/**
	 * Checks for a modified slug on a monitored post.
	 *
	 * @since 4.9.1
	 *
	 * @param  string $before The url path before.
	 * @param  string $after  The url path after.
	 * @return void
	 */
	private function addRedirect( $before, $after ) {
		// Disable all redirects that match the new URL.
		$newUrlRedirects = aioseo()->redirects->redirect->getRedirectsBySource( $after );
		if ( ! empty( $newUrlRedirects ) ) {
			foreach ( $newUrlRedirects as $newUrlRedirect ) {
				$newUrlRedirect->enabled = false;
				$newUrlRedirect->save();
			}
		}

		// Maybe get an existing redirect to update it.
		// Should we ignore custom rule redirects?
		$redirect = aioseo()->redirects->redirect->getRedirectsBySource( $before, 'all' );
		$redirect = empty( $redirect ) ? new Models\Redirect() : current( $redirect );
		$redirect->set( [
			'source_url'   => $before,
			'target_url'   => $after,
			'type'         => 301,
			'query_param'  => json_decode( aioseo()->redirects->options->redirectDefaults->queryParam )->value,
			'group'        => 'modified',
			'regex'        => false,
			'ignore_slash' => aioseo()->redirects->options->redirectDefaults->ignoreSlash,
			'ignore_case'  => aioseo()->redirects->options->redirectDefaults->ignoreCase,
			'enabled'      => true
		] );

		$redirect->save();
	}

	/**
	 * Stores the source URL of a monitored post right before it's trashed.
	 *
	 * NOTE: WordPress resolves a trashed post's permalink to the home URL, so the URL must be captured while
	 * the post is still published. Trashing itself must not touch any redirect, otherwise restoring loses it.
	 *
	 * @since 5.0.3
	 *
	 * @param  int  $postId The post ID.
	 * @return void
	 */
	public function postTrashing( $postId ) {
		if ( ! $this->canMonitorPostType( get_post_type( $postId ) ) ) {
			return;
		}

		$url = Utils\WpUri::getPostPath( $postId );
		if ( '/' === $url ) {
			return;
		}

		update_post_meta( $postId, '_aioseo_redirect_monitor_source', $url );
	}

	/**
	 * Removes the captured source URL when a monitored post is restored from trash.
	 *
	 * @since 5.0.3
	 *
	 * @param  int  $postId The post ID.
	 * @return void
	 */
	public function postUntrashed( $postId ) {
		delete_post_meta( $postId, '_aioseo_redirect_monitor_source' );
	}

	/**
	 * Creates a redirect when a monitored post is permanently deleted.
	 *
	 * @since   4.9.1
	 * @version 5.0.3 Renamed from postTrashed(); now fires on permanent deletion via the captured source URL.
	 * @version 5.0.3 Stage the redirect without a target instead of pointing it at the home URL;
	 *                leave an existing redirect for the URL untouched.
	 *
	 * @param  int  $postId The post ID.
	 * @return void
	 */
	public function postDeleted( $postId ) {
		// Don't do anything if we can't monitor this post type.
		if ( ! $this->canMonitorPostType( get_post_type( $postId ) ) ) {
			return;
		}

		// Prefer the URL captured before trashing; fall back to the live URL for posts deleted without trashing.
		$url = (string) get_post_meta( $postId, '_aioseo_redirect_monitor_source', true );
		if ( '' === $url ) {
			$url = Utils\WpUri::getPostPath( $postId );
		}

		if ( '/' === $url ) {
			return;
		}

		// The target is left empty on purpose: this is a disabled placeholder for the user to fill in.
		// Defaulting it to the home URL turns every deleted post into a soft 404 the moment it's enabled.
		$redirect = Models\Redirect::getRedirectBySourceUrl( $url );

		// A redirect the user already has for this URL says where it should go; a placeholder would only erase it.
		if ( $redirect->exists() ) {
			return;
		}

		$redirect->set( [
			'source_url'   => $url,
			'target_url'   => '',
			'type'         => 301,
			'query_param'  => json_decode( aioseo()->redirects->options->redirectDefaults->queryParam )->value,
			'group'        => 'modified',
			'regex'        => false,
			'ignore_slash' => aioseo()->redirects->options->redirectDefaults->ignoreSlash,
			'ignore_case'  => aioseo()->redirects->options->redirectDefaults->ignoreCase,
			'enabled'      => false
		] );
		$redirect->save();
	}
}