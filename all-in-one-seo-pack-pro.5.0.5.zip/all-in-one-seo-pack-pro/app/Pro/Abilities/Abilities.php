<?php
namespace AIOSEO\Plugin\Pro\Abilities;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AIOSEO\Plugin\Common\Abilities\Abilities as CommonAbilities;
use AIOSEO\Plugin\Pro\Services\RedirectsService;
use AIOSEO\Plugin\Pro\Services\SearchStatisticsService;
use AIOSEO\Plugin\Pro\Services\TermSeoService;

/**
 * Registers Pro-only AIOSEO abilities with the WordPress Abilities API.
 *
 * Like the Common counterpart, this is registration-only — all logic lives in
 * Pro\Services\* (see ../../Common/Services/README.md for the architectural rules).
 *
 * @since 4.9.8
 */
class Abilities extends CommonAbilities {
	/**
	 * Registers Pro categories on top of the Common ones.
	 *
	 * @since 4.9.8
	 *
	 * @return void
	 */
	public function registerCategories() {
		parent::registerCategories();

		$categories = [
			'aioseo-terms'             => __( 'AIOSEO — Terms', 'aioseo-pro' ),
			'aioseo-redirects'         => __( 'AIOSEO — Redirects', 'aioseo-pro' ),
			'aioseo-search-statistics' => __( 'AIOSEO — Search Statistics', 'aioseo-pro' )
		];

		foreach ( $categories as $slug => $label ) {
			wp_register_ability_category( $slug, [
				'label'       => $label,
				'description' => __( 'SEO management abilities provided by AIOSEO Pro.', 'aioseo-pro' )
			] );
		}

		aioseo()->addons->doAddonFunction( 'abilities', 'registerCategories' );
	}

	/**
	 * Registers Common + Pro abilities.
	 *
	 * @since 4.9.8
	 *
	 * @return void
	 */
	public function registerAbilities() {
		parent::registerAbilities();

		$this->registerTermAbilities();
		$this->registerRedirectAbilities();
		$this->registerSearchStatisticsAbilities();

		aioseo()->addons->doAddonFunction( 'abilities', 'register' );
	}

	/**
	 * Registers term abilities. Pro-only because the Term model lives in Pro.
	 *
	 * @since 4.9.8
	 *
	 * @return void
	 */
	protected function registerTermAbilities() {
		wp_register_ability( 'aioseo-terms/seo-data-get', [
			'label'               => __( 'Get Term SEO Data', 'aioseo-pro' ),
			'description'         => __( 'Returns the SEO snapshot for a term (category, tag, custom taxonomy): title, description, canonical URL, robots flags, and social meta.', 'aioseo-pro' ),
			'category'            => 'aioseo-terms',
			'input_schema'        => [
				'type'                 => 'object',
				'properties'           => [
					'termId' => [
						'type'        => 'integer',
						'description' => __( 'The term ID.', 'aioseo-pro' )
					]
				],
				'required'             => [ 'termId' ],
				'additionalProperties' => false
			],
			'output_schema'       => $this->termSnapshotOutputSchema(),
			'execute_callback'    => [ $this, 'getTermSeoData' ],
			'permission_callback' => [ $this, 'canEditTerms' ],
			'meta'                => $this->readonlyMeta()
		] );

		wp_register_ability( 'aioseo-terms/seo-data-update', [
			'label'               => __( 'Update Term SEO Data', 'aioseo-pro' ),
			'description'         => __( 'Updates SEO fields for a term: title, description, canonical URL, robots flags, and social meta. Only the fields provided are changed.', 'aioseo-pro' ),
			'category'            => 'aioseo-terms',
			'input_schema'        => [
				'type'                 => 'object',
				'properties'           => [
					'termId'        => [ 'type' => 'integer' ],
					'title'         => [ 'type' => [ 'string', 'null' ] ],
					'description'   => [ 'type' => [ 'string', 'null' ] ],
					'canonical_url' => [ 'type' => [ 'string', 'null' ] ],
					'robots'        => $this->robotsInputSchema(),
					'social'        => $this->socialInputSchema()
				],
				'required'             => [ 'termId' ],
				'additionalProperties' => false
			],
			'output_schema'       => [
				'type'       => 'object',
				'properties' => [
					'updated' => [ 'type' => 'boolean' ],
					'term'    => $this->termSnapshotOutputSchema()
				]
			],
			'execute_callback'    => [ $this, 'updateTermSeoData' ],
			'permission_callback' => [ $this, 'canEditTerms' ],
			'meta'                => [
				'show_in_rest' => true,
				'mcp'          => [ 'public' => true ]
			]
		] );

		wp_register_ability( 'aioseo-terms/list-missing-seo', [
			'label'               => __( 'List Terms Missing SEO Data', 'aioseo-pro' ),
			'description'         => __( 'Returns terms (categories, tags, custom taxonomies) where one or more SEO fields are unset (title or description). Defaults to description. Useful for "which terms need SEO attention?" prompts.', 'aioseo-pro' ), // phpcs:ignore Generic.Files.LineLength.MaxExceeded
			'category'            => 'aioseo-terms',
			'input_schema'        => [
				'type'                 => 'object',
				'properties'           => [
					'missing_fields' => [
						'type'    => 'array',
						'items'   => [
							'type' => 'string',
							'enum' => [ 'title', 'description' ]
						],
						'default' => [ 'description' ]
					],
					'taxonomy'       => [
						'type'  => 'array',
						'items' => [ 'type' => 'string' ]
					],
					'limit'          => [
						'type'    => 'integer',
						'minimum' => 1,
						'maximum' => 100,
						'default' => 20
					],
					'offset'         => [
						'type'    => 'integer',
						'minimum' => 0,
						'default' => 0
					]
				],
				'additionalProperties' => false,
				// All properties are optional — default the whole input to an empty object so
				// a no-argument call (the natural "list" prompt from an MCP agent) validates.
				'default'              => []
			],
			'output_schema'       => $this->termListOutputSchema(),
			'execute_callback'    => [ $this, 'listTermsMissingSeo' ],
			'permission_callback' => [ $this, 'canEditTerms' ],
			'meta'                => $this->readonlyMeta()
		] );
	}

	/**
	 * Registers redirect abilities (Pro+addon).
	 *
	 * @since 4.9.8
	 *
	 * @return void
	 */
	protected function registerRedirectAbilities() {
		wp_register_ability( 'aioseo-redirects/list', [
			'label'               => __( 'List Redirects', 'aioseo-pro' ),
			'description'         => __( 'Lists redirect rules currently configured in AIOSEO. Paginated via limit and offset.', 'aioseo-pro' ),
			'category'            => 'aioseo-redirects',
			'input_schema'        => [
				'type'                 => 'object',
				'properties'           => [
					'limit'   => [
						'type'    => 'integer',
						'default' => 20,
						'minimum' => 1,
						'maximum' => 100
					],
					'offset'  => [
						'type'    => 'integer',
						'default' => 0,
						'minimum' => 0
					],
					'enabled' => [
						'type'        => 'boolean',
						'description' => __( 'When set, filters to only enabled or only disabled redirects.', 'aioseo-pro' )
					]
				],
				'additionalProperties' => false,
				// All properties are optional — default the whole input to an empty object so
				// a no-argument call (the natural "list" prompt from an MCP agent) validates.
				'default'              => []
			],
			'output_schema'       => [
				'type'       => 'object',
				'properties' => [
					'redirects' => [
						'type'  => 'array',
						'items' => $this->redirectRowSchema()
					],
					'total'     => [ 'type' => 'integer' ]
				]
			],
			'execute_callback'    => [ $this, 'listRedirects' ],
			'permission_callback' => [ $this, 'canManageRedirects' ],
			'meta'                => $this->readonlyMeta()
		] );

		wp_register_ability( 'aioseo-redirects/create', [
			'label'               => __( 'Create Redirect', 'aioseo-pro' ),
			'description'         => __( 'Creates a redirect rule. Source URL may be a relative path (e.g. "/old-page/") or absolute URL. Returns the created record, or an error if a redirect for that source already exists.', 'aioseo-pro' ), // phpcs:ignore Generic.Files.LineLength.MaxExceeded
			'category'            => 'aioseo-redirects',
			'input_schema'        => [
				'type'                 => 'object',
				'properties'           => [
					'sourceUrl' => [
						'type'        => 'string',
						'minLength'   => 1,
						'description' => __( 'Source path or URL. Must be a relative path starting with "/" or an absolute URL.', 'aioseo-pro' )
					],
					'targetUrl' => [
						'type'      => 'string',
						'minLength' => 1
					],
					'type'      => [
						'type'    => 'integer',
						'enum'    => [ 301, 302, 307, 308 ],
						'default' => 301
					]
				],
				'required'             => [ 'sourceUrl', 'targetUrl' ],
				'additionalProperties' => false
			],
			'output_schema'       => [
				'type'       => 'object',
				'properties' => [ 'redirect' => $this->redirectRowSchema() ]
			],
			'execute_callback'    => [ $this, 'createRedirect' ],
			'permission_callback' => [ $this, 'canManageRedirects' ],
			'meta'                => [
				'show_in_rest' => true,
				'mcp'          => [ 'public' => true ]
			]
		] );

		wp_register_ability( 'aioseo-redirects/update', [
			'label'               => __( 'Update Redirect', 'aioseo-pro' ),
			'description'         => __( 'Updates an existing redirect by id. Only the fields provided are changed.', 'aioseo-pro' ),
			'category'            => 'aioseo-redirects',
			'input_schema'        => [
				'type'                 => 'object',
				'properties'           => [
					'id'        => [
						'type'        => 'integer',
						'description' => __( 'The redirect id (from aioseo-redirects/list).', 'aioseo-pro' )
					],
					'sourceUrl' => [
						'type'      => 'string',
						'minLength' => 1
					],
					'targetUrl' => [
						'type'      => 'string',
						'minLength' => 1
					],
					'type'      => [
						'type' => 'integer',
						'enum' => [ 301, 302, 307, 308 ]
					],
					'enabled'   => [ 'type' => 'boolean' ]
				],
				'required'             => [ 'id' ],
				'additionalProperties' => false
			],
			'output_schema'       => [
				'type'       => 'object',
				'properties' => [
					'updated'  => [ 'type' => 'boolean' ],
					'redirect' => $this->redirectRowSchema()
				]
			],
			'execute_callback'    => [ $this, 'updateRedirect' ],
			'permission_callback' => [ $this, 'canManageRedirects' ],
			'meta'                => [
				'show_in_rest' => true,
				'mcp'          => [ 'public' => true ]
			]
		] );

		wp_register_ability( 'aioseo-redirects/delete', [
			'label'               => __( 'Delete Redirect', 'aioseo-pro' ),
			'description'         => __( 'Deletes a redirect by id.', 'aioseo-pro' ),
			'category'            => 'aioseo-redirects',
			'input_schema'        => [
				'type'                 => 'object',
				'properties'           => [
					'id' => [
						'type'        => 'integer',
						'description' => __( 'The redirect id (from aioseo-redirects/list).', 'aioseo-pro' )
					]
				],
				'required'             => [ 'id' ],
				'additionalProperties' => false
			],
			'output_schema'       => [
				'type'       => 'object',
				'properties' => [ 'deleted' => [ 'type' => 'boolean' ] ]
			],
			'execute_callback'    => [ $this, 'deleteRedirect' ],
			'permission_callback' => [ $this, 'canManageRedirects' ],
			'meta'                => [
				'annotations'  => [ 'destructive' => true ],
				'show_in_rest' => true,
				'mcp'          => [ 'public' => true ]
			]
		] );

		wp_register_ability( 'aioseo-redirects/logs-404s-list', [
			'label'               => __( 'List 404 Log Entries', 'aioseo-pro' ),
			'description'         => __( 'Lists URLs that returned 404 on this site, grouped by URL, with hit count and last-accessed timestamp. Useful for finding URLs that need a redirect.', 'aioseo-pro' ), // phpcs:ignore Generic.Files.LineLength.MaxExceeded
			'category'            => 'aioseo-redirects',
			'input_schema'        => [
				'type'                 => 'object',
				'properties'           => [
					'limit'  => [
						'type'    => 'integer',
						'minimum' => 1,
						'maximum' => 100,
						'default' => 20
					],
					'offset' => [
						'type'    => 'integer',
						'minimum' => 0,
						'default' => 0
					],
					'search' => [
						'type'        => 'string',
						'description' => __( 'Substring filter applied to the URL column.', 'aioseo-pro' )
					]
				],
				'additionalProperties' => false,
				// All properties are optional — default the whole input to an empty object so
				// a no-argument call (the natural "list" prompt from an MCP agent) validates.
				'default'              => []
			],
			'output_schema'       => [
				'type'       => 'object',
				'properties' => [
					'entries' => [
						'type'  => 'array',
						'items' => $this->redirectLogEntrySchema()
					],
					'total'   => [ 'type' => 'integer' ]
				]
			],
			'execute_callback'    => [ $this, 'listRedirects404Log' ],
			'permission_callback' => [ $this, 'canManageRedirects' ],
			'meta'                => $this->readonlyMeta()
		] );

		wp_register_ability( 'aioseo-redirects/logs-hits-list', [
			'label'               => __( 'List Redirect Hit Log', 'aioseo-pro' ),
			'description'         => __( 'Lists redirect hits (redirects that have fired) grouped by URL, with hit count and last-accessed timestamp.', 'aioseo-pro' ),
			'category'            => 'aioseo-redirects',
			'input_schema'        => [
				'type'                 => 'object',
				'properties'           => [
					'limit'  => [
						'type'    => 'integer',
						'minimum' => 1,
						'maximum' => 100,
						'default' => 20
					],
					'offset' => [
						'type'    => 'integer',
						'minimum' => 0,
						'default' => 0
					],
					'search' => [
						'type'        => 'string',
						'description' => __( 'Substring filter applied to the URL column.', 'aioseo-pro' )
					]
				],
				'additionalProperties' => false,
				// All properties are optional — default the whole input to an empty object so
				// a no-argument call (the natural "list" prompt from an MCP agent) validates.
				'default'              => []
			],
			'output_schema'       => [
				'type'       => 'object',
				'properties' => [
					'entries' => [
						'type'  => 'array',
						'items' => $this->redirectLogEntrySchema()
					],
					'total'   => [ 'type' => 'integer' ]
				]
			],
			'execute_callback'    => [ $this, 'listRedirectsHitLog' ],
			'permission_callback' => [ $this, 'canManageRedirects' ],
			'meta'                => $this->readonlyMeta()
		] );
	}

	/**
	 * Registers Search Statistics abilities.
	 *
	 * @since 4.9.8
	 *
	 * @return void
	 */
	protected function registerSearchStatisticsAbilities() {
		$dateRangeSchema = [
			'startDate' => [
				'type'    => 'string',
				'pattern' => '^\\d{4}-\\d{2}-\\d{2}$'
			],
			'endDate'   => [
				'type'    => 'string',
				'pattern' => '^\\d{4}-\\d{2}-\\d{2}$'
			]
		];

		wp_register_ability( 'aioseo-search-statistics/overview-get', [
			'label'               => __( 'Get Search Statistics Overview', 'aioseo-pro' ),
			'description'         => __( 'Returns aggregated Google Search Console performance for the site over a date range: clicks, impressions, CTR, average position, and top keywords and pages. Requires Search Statistics to be connected.', 'aioseo-pro' ), // phpcs:ignore Generic.Files.LineLength.MaxExceeded
			'category'            => 'aioseo-search-statistics',
			'input_schema'        => [
				'type'                 => 'object',
				'properties'           => $dateRangeSchema,
				'required'             => [ 'startDate', 'endDate' ],
				'additionalProperties' => false
			],
			'output_schema'       => [
				'type'       => 'object',
				'properties' => [
					'connected'    => [ 'type' => 'boolean' ],
					'date_range'   => [
						'type'       => 'object',
						'properties' => [
							'start' => [ 'type' => 'string' ],
							'end'   => [ 'type' => 'string' ]
						]
					],
					'totals'       => [
						'type'       => 'object',
						'properties' => [
							'clicks'           => [ 'type' => 'integer' ],
							'impressions'      => [ 'type' => 'integer' ],
							'ctr'              => [ 'type' => 'number' ],
							'average_position' => [ 'type' => 'number' ]
						]
					],
					'top_keywords' => [ 'type' => 'array' ],
					'top_pages'    => [ 'type' => 'array' ]
				]
			],
			'execute_callback'    => [ $this, 'getSearchStatisticsOverview' ],
			'permission_callback' => [ $this, 'canManageSearchStatistics' ],
			'meta'                => $this->readonlyMeta()
		] );

		wp_register_ability( 'aioseo-search-statistics/page-performance-get', [
			'label'               => __( 'Get Page Performance', 'aioseo-pro' ),
			'description'         => __( 'Returns GSC performance metrics for a single page (URL or path) over a date range — clicks, impressions, CTR, position over time, and ranking keywords for that page.', 'aioseo-pro' ), // phpcs:ignore Generic.Files.LineLength.MaxExceeded
			'category'            => 'aioseo-search-statistics',
			'input_schema'        => [
				'type'                 => 'object',
				'properties'           => array_merge( $dateRangeSchema, [
					'page' => [
						'type'        => 'string',
						'description' => __( 'The page URL or path on this site.', 'aioseo-pro' )
					]
				] ),
				'required'             => [ 'page', 'startDate', 'endDate' ],
				'additionalProperties' => false
			],
			'output_schema'       => [
				'type'       => 'object',
				'properties' => [
					'page'       => [ 'type' => 'string' ],
					'date_range' => [ 'type' => 'object' ],
					'data'       => [ 'type' => 'object' ]
				]
			],
			'execute_callback'    => [ $this, 'getPagePerformance' ],
			'permission_callback' => [ $this, 'canManageSearchStatistics' ],
			'meta'                => $this->readonlyMeta()
		] );

		wp_register_ability( 'aioseo-search-statistics/content-decay-get', [
			'label'               => __( 'Get Content Decay', 'aioseo-pro' ),
			'description'         => __( 'Returns pages losing the most clicks/positions over the given date range. Useful for "which content needs a refresh?" prompts.', 'aioseo-pro' ),
			'category'            => 'aioseo-search-statistics',
			'input_schema'        => [
				'type'                 => 'object',
				'properties'           => array_merge( $dateRangeSchema, [
					'limit'  => [
						'type'    => 'integer',
						'minimum' => 1,
						'maximum' => 100,
						'default' => 20
					],
					'offset' => [
						'type'    => 'integer',
						'minimum' => 0,
						'default' => 0
					]
				] ),
				'required'             => [ 'startDate', 'endDate' ],
				'additionalProperties' => false
			],
			'output_schema'       => [
				'type'       => 'object',
				'properties' => [
					'date_range' => [ 'type' => 'object' ],
					'rows'       => [ 'type' => 'array' ]
				]
			],
			'execute_callback'    => [ $this, 'getContentDecay' ],
			'permission_callback' => [ $this, 'canManageSearchStatistics' ],
			'meta'                => $this->readonlyMeta()
		] );

		wp_register_ability( 'aioseo-search-statistics/quick-wins-get', [
			'label'               => __( 'Get Quick-Win Keywords', 'aioseo-pro' ),
			'description'         => __( 'Returns keywords currently ranking just outside the top 3 with high impressions and low CTR — pages a small optimisation could push higher.', 'aioseo-pro' ),
			'category'            => 'aioseo-search-statistics',
			'input_schema'        => [
				'type'                 => 'object',
				'properties'           => array_merge( $dateRangeSchema, [
					'min_impressions' => [
						'type'    => 'integer',
						'minimum' => 0,
						'default' => 50
					],
					'max_ctr'         => [
						'type'    => 'number',
						'minimum' => 0,
						'default' => 2
					],
					'position_min'    => [
						'type'    => 'integer',
						'minimum' => 1,
						'default' => 4
					],
					'position_max'    => [
						'type'    => 'integer',
						'minimum' => 1,
						'default' => 10
					],
					'limit'           => [
						'type'    => 'integer',
						'minimum' => 1,
						'maximum' => 100,
						'default' => 20
					]
				] ),
				'required'             => [ 'startDate', 'endDate' ],
				'additionalProperties' => false
			],
			'output_schema'       => [
				'type'       => 'object',
				'properties' => [
					'date_range' => [ 'type' => 'object' ],
					'criteria'   => [ 'type' => 'object' ],
					'rows'       => [ 'type' => 'array' ],
					'total'      => [ 'type' => 'integer' ]
				]
			],
			'execute_callback'    => [ $this, 'getQuickWins' ],
			'permission_callback' => [ $this, 'canManageSearchStatistics' ],
			'meta'                => $this->readonlyMeta()
		] );
	}

	// =========================================================================
	// Permission callbacks
	// =========================================================================

	/**
	 * Permission callback: caller can edit terms.
	 *
	 * @since 4.9.8
	 *
	 * @return bool
	 */
	public function canEditTerms() {
		return aioseo()->access->hasAccess( 'aioseo_page_general_settings' );
	}

	/**
	 * Permission callback: caller can manage redirects.
	 *
	 * @since 4.9.8
	 *
	 * @return bool
	 */
	public function canManageRedirects() {
		return aioseo()->access->hasAccess( [ 'aioseo_redirects_manage', 'aioseo_page_redirects_manage' ] );
	}

	/**
	 * Permission callback: caller can read search statistics.
	 *
	 * @since 4.9.8
	 *
	 * @return bool
	 */
	public function canManageSearchStatistics() {
		return aioseo()->access->hasAccess( 'aioseo_search_statistics_settings' );
	}

	// =========================================================================
	// Execute callbacks — thin delegates to Pro\Services\*.
	// =========================================================================

	/**
	 * Delegate to TermSeoService::getSeoData.
	 *
	 * @since 4.9.8
	 *
	 * @param  array $input The input data.
	 * @return array|\WP_Error
	 */
	public function getTermSeoData( $input ) {
		$input = is_array( $input ) ? $input : [];

		return ( new TermSeoService() )->getSeoData( isset( $input['termId'] ) ? (int) $input['termId'] : 0 );
	}

	/**
	 * Delegate to TermSeoService::updateSeoData.
	 *
	 * @since 4.9.8
	 *
	 * @param  array $input The input data.
	 * @return array|\WP_Error
	 */
	public function updateTermSeoData( $input ) {
		$input  = is_array( $input ) ? $input : [];
		$termId = isset( $input['termId'] ) ? (int) $input['termId'] : 0;
		$fields = $input;
		unset( $fields['termId'] );

		return ( new TermSeoService() )->updateSeoData( $termId, $fields );
	}

	/**
	 * Delegate to TermSeoService::listMissingSeo.
	 *
	 * @since 4.9.10
	 *
	 * @param  array $input The input data.
	 * @return array|\WP_Error
	 */
	public function listTermsMissingSeo( $input ) {
		return ( new TermSeoService() )->listMissingSeo( is_array( $input ) ? $input : [] );
	}

	/**
	 * Delegate to RedirectsService::listRedirects.
	 *
	 * @since 4.9.8
	 *
	 * @param  array $input The input data.
	 * @return array|\WP_Error
	 */
	public function listRedirects( $input ) {
		return ( new RedirectsService() )->listRedirects( is_array( $input ) ? $input : [] );
	}

	/**
	 * Delegate to RedirectsService::create.
	 *
	 * @since 4.9.8
	 *
	 * @param  array $input The input data.
	 * @return array|\WP_Error
	 */
	public function createRedirect( $input ) {
		return ( new RedirectsService() )->create( is_array( $input ) ? $input : [] );
	}

	/**
	 * Delegate to RedirectsService::update.
	 *
	 * @since 4.9.8
	 *
	 * @param  array $input The input data.
	 * @return array|\WP_Error
	 */
	public function updateRedirect( $input ) {
		$input  = is_array( $input ) ? $input : [];
		$id     = isset( $input['id'] ) ? (int) $input['id'] : 0;
		$fields = $input;
		unset( $fields['id'] );

		return ( new RedirectsService() )->update( $id, $fields );
	}

	/**
	 * Delegate to RedirectsService::delete.
	 *
	 * @since 4.9.8
	 *
	 * @param  array $input The input data.
	 * @return array|\WP_Error
	 */
	public function deleteRedirect( $input ) {
		$input = is_array( $input ) ? $input : [];

		return ( new RedirectsService() )->delete( isset( $input['id'] ) ? (int) $input['id'] : 0 );
	}

	/**
	 * Delegate to RedirectsService::listFourOhFourLog.
	 *
	 * @since 4.9.8
	 *
	 * @param  array $input The input data.
	 * @return array|\WP_Error
	 */
	public function listRedirects404Log( $input ) {
		return ( new RedirectsService() )->listFourOhFourLog( is_array( $input ) ? $input : [] );
	}

	/**
	 * Delegate to RedirectsService::listHitsLog.
	 *
	 * @since 4.9.8
	 *
	 * @param  array $input The input data.
	 * @return array|\WP_Error
	 */
	public function listRedirectsHitLog( $input ) {
		return ( new RedirectsService() )->listHitsLog( is_array( $input ) ? $input : [] );
	}

	/**
	 * Delegate to SearchStatisticsService::getOverview.
	 *
	 * @since 4.9.8
	 *
	 * @param  array $input The input data.
	 * @return array|\WP_Error
	 */
	public function getSearchStatisticsOverview( $input ) {
		return ( new SearchStatisticsService() )->getOverview( is_array( $input ) ? $input : [] );
	}

	/**
	 * Delegate to SearchStatisticsService::getPagePerformance.
	 *
	 * @since 4.9.8
	 *
	 * @param  array $input The input data.
	 * @return array|\WP_Error
	 */
	public function getPagePerformance( $input ) {
		return ( new SearchStatisticsService() )->getPagePerformance( is_array( $input ) ? $input : [] );
	}

	/**
	 * Delegate to SearchStatisticsService::getContentDecay.
	 *
	 * @since 4.9.8
	 *
	 * @param  array $input The input data.
	 * @return array|\WP_Error
	 */
	public function getContentDecay( $input ) {
		return ( new SearchStatisticsService() )->getContentDecay( is_array( $input ) ? $input : [] );
	}

	/**
	 * Delegate to SearchStatisticsService::getQuickWins.
	 *
	 * @since 4.9.8
	 *
	 * @param  array $input The input data.
	 * @return array|\WP_Error
	 */
	public function getQuickWins( $input ) {
		return ( new SearchStatisticsService() )->getQuickWins( is_array( $input ) ? $input : [] );
	}

	// =========================================================================
	// Schema helpers
	// =========================================================================

	/**
	 * Output schema for a term SEO snapshot.
	 *
	 * @since 4.9.8
	 *
	 * @return array
	 */
	protected function termSnapshotOutputSchema() {
		return [
			'type'       => 'object',
			'properties' => [
				'term_id'       => [ 'type' => 'integer' ],
				'taxonomy'      => [ 'type' => 'string' ],
				'name'          => [ 'type' => 'string' ],
				'slug'          => [ 'type' => 'string' ],
				'title'         => [ 'type' => [ 'string', 'null' ] ],
				'description'   => [ 'type' => [ 'string', 'null' ] ],
				'canonical_url' => [ 'type' => [ 'string', 'null' ] ],
				'robots'        => [
					'type'       => 'object',
					'properties' => [
						'use_default'  => [ 'type' => 'boolean' ],
						'noindex'      => [ 'type' => 'boolean' ],
						'nofollow'     => [ 'type' => 'boolean' ],
						'noarchive'    => [ 'type' => 'boolean' ],
						'nosnippet'    => [ 'type' => 'boolean' ],
						'noimageindex' => [ 'type' => 'boolean' ],
						'notranslate'  => [ 'type' => 'boolean' ],
						'noodp'        => [ 'type' => 'boolean' ]
					]
				],
				'social'        => [
					'type'       => 'object',
					'properties' => [
						'og_title'            => [ 'type' => [ 'string', 'null' ] ],
						'og_description'      => [ 'type' => [ 'string', 'null' ] ],
						'twitter_title'       => [ 'type' => [ 'string', 'null' ] ],
						'twitter_description' => [ 'type' => [ 'string', 'null' ] ]
					]
				]
			]
		];
	}

	/**
	 * Output schema for a list of terms.
	 *
	 * @since 4.9.10
	 *
	 * @return array
	 */
	protected function termListOutputSchema() {
		return [
			'type'       => 'object',
			'properties' => [
				'terms' => [
					'type'  => 'array',
					'items' => [
						'type'       => 'object',
						'properties' => [
							'id'             => [ 'type' => 'integer' ],
							'name'           => [ 'type' => 'string' ],
							'slug'           => [ 'type' => 'string' ],
							'taxonomy'       => [ 'type' => 'string' ],
							'permalink'      => [ 'type' => [ 'string', 'null' ] ],
							'missing_fields' => [
								'type'  => 'array',
								'items' => [
									'type' => 'string',
									'enum' => [ 'title', 'description' ]
								]
							]
						]
					]
				],
				'total' => [ 'type' => 'integer' ]
			]
		];
	}

	/**
	 * Output schema for a single redirect record.
	 *
	 * @since 4.9.8
	 *
	 * @return array
	 */
	protected function redirectRowSchema() {
		return [
			'type'       => 'object',
			'properties' => [
				'id'        => [ 'type' => 'integer' ],
				'source'    => [ 'type' => 'string' ],
				'target'    => [ 'type' => 'string' ],
				'type'      => [
					'type'        => 'integer',
					// Reflects the stored status code, which spans every type AIOSEO's UI offers
					// (301/302/307/308 plus non-redirecting codes like 404, 410, 451) — not just the
					// four the create/update abilities accept. No enum, so listing never rejects a row.
					'description' => __( 'HTTP status code of the redirect (e.g. 301, 302, 307, 308, or a non-redirecting code such as 404 or 410).', 'aioseo-pro' )
				],
				'enabled'   => [ 'type' => 'boolean' ],
				'hit_count' => [ 'type' => 'integer' ],
				'last_hit'  => [ 'type' => [ 'string', 'null' ] ],
				'updated'   => [ 'type' => [ 'string', 'null' ] ]
			]
		];
	}

	/**
	 * Output schema for a single redirect log entry (404 or hits log).
	 *
	 * @since 4.9.8
	 *
	 * @return array
	 */
	protected function redirectLogEntrySchema() {
		return [
			'type'       => 'object',
			'properties' => [
				'id'            => [ 'type' => 'integer' ],
				'url'           => [ 'type' => 'string' ],
				'hits'          => [ 'type' => 'integer' ],
				'last_accessed' => [ 'type' => [ 'string', 'null' ] ],
				'referrers'     => [
					'type'  => 'array',
					'items' => [ 'type' => 'string' ]
				]
			]
		];
	}
}