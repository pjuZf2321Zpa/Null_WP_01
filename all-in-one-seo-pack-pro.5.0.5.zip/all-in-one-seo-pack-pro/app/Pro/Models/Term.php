<?php
namespace AIOSEO\Plugin\Pro\Models;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AIOSEO\Plugin\Common\Models as CommonModels;

/**
 * The Term DB Model.
 *
 * @since 4.0.0
 */
class Term extends CommonModels\Model {
	/**
	 * The name of the table in the database, without the prefix.
	 *
	 * @since 4.0.0
	 *
	 * @var string
	 */
	protected $table = 'aioseo_terms';

	/**
	 * Fields that should be json encoded on save and decoded on get.
	 *
	 * @since 4.0.0
	 *
	 * @var array
	 */
	protected $jsonFields = [
		'keywords',
		'truseo',
		'additional_keywords',
		'og_article_tags',
		'videos',
		'breadcrumb_settings'
	];

	/**
	 * Fields that should be boolean values.
	 *
	 * @since 4.0.0
	 *
	 * @var array
	 */
	protected $booleanFields = [
		'twitter_use_og',
		'robots_default',
		'robots_noindex',
		'robots_noarchive',
		'robots_nosnippet',
		'robots_nofollow',
		'robots_noimageindex',
		'robots_noodp',
		'robots_notranslate'
	];

	/**
	 * Fields that can be null when saved.
	 *
	 * @since 4.5.7
	 *
	 * @var array
	 */
	protected $nullFields = [
		'priority'
	];

	/**
	 * Fields that should be float values.
	 *
	 * @since 4.7.3
	 *
	 * @var array
	 */
	protected $floatFields = [
		'priority'
	];

	/**
	 * Fields that should be hidden when serialized.
	 *
	 * @since 4.0.0
	 *
	 * @var array
	 */
	protected $hidden = [ 'id' ];

	/**
	 * Returns a Term with a given ID.
	 *
	 * @since 4.0.0
	 *
	 * @param  int  $termId The term ID.
	 * @return Term         The Term object.
	 */
	public static function getTerm( $termId ) {
		$term = aioseo()->core->db
			->start( 'aioseo_terms' )
			->where( 'term_id', $termId )
			->run()
			->model( 'AIOSEO\\Plugin\\Pro\\Models\\Term' );

		if ( ! $term->exists() ) {
			$term->term_id = $termId;
		}

		return apply_filters( 'aioseo_get_term', $term );
	}

	/**
	 * Saves the Term object.
	 *
	 * @since 4.0.3
	 *
	 * @param  int              $termId The term ID.
	 * @param  string           $data   The term data to save.
	 * @return bool|void|string         Whether the term data was saved or a DB error message.
	 */
	public static function saveTerm( $termId, $data ) {
		if ( empty( $data ) ) {
			return false;
		}

		$theTerm = self::getTerm( $termId );
		$data    = apply_filters( 'aioseo_save_term', $data, $theTerm );

		// Before setting the data, we check if the title/description are the same as the defaults and clear them if so.
		$data    = self::checkForDefaultFormat( $termId, $theTerm, $data );
		$theTerm = self::sanitizeAndSetDefaults( $termId, $theTerm, $data );

		// Update traditional term meta so that it can be used by multilingual plugins.
		self::updateTermMeta( $termId, $data );

		$theTerm->save();

		$lastError = $theTerm->lastError;
		if ( ! empty( $lastError ) ) {
			return $lastError;
		}

		$theTerm->reset();

		// Fires once an AIOSEO term has been saved.
		do_action( 'aioseo_insert_term', $termId );

		return true;
	}

	/**
	 * Checks if the title/description is the same as their default format in Search Appearance and nulls it if this is the case.
	 * Doing this ensures that updates to the default title/description format also propogate to the term.
	 *
	 * @since 4.1.5
	 *
	 * @param  int   $termId  The term ID.
	 * @param  Term  $theTerm The Term object.
	 * @param  array $data    The data.
	 * @return array          The data.
	 */
	private static function checkForDefaultFormat( $termId, $theTerm, $data ) {
		// Patch-friendly: only normalise fields the caller actually sent. Missing keys are left alone
		// so the patch-style sanitizeAndSetDefaults below doesn't overwrite the existing model value.
		$hasTitle       = array_key_exists( 'title', $data );
		$hasDescription = array_key_exists( 'description', $data );

		if ( ! $hasTitle && ! $hasDescription ) {
			return $data;
		}

		if ( $hasTitle ) {
			$data['title'] = trim( (string) $data['title'] );
		}
		if ( $hasDescription ) {
			$data['description'] = trim( (string) $data['description'] );
		}

		$term                     = aioseo()->helpers->getTerm( $termId );
		$defaultTitleFormat       = trim( aioseo()->meta->title->getTaxonomyTitle( $term->taxonomy ) );
		$defaultDescriptionFormat = trim( aioseo()->meta->description->getTaxonomyDescription( $term->taxonomy ) );

		if ( $hasTitle && ! empty( $data['title'] ) && $data['title'] === $defaultTitleFormat ) {
			$data['title'] = null;
		}
		if ( $hasDescription && ! empty( $data['description'] ) && $data['description'] === $defaultDescriptionFormat ) {
			$data['description'] = null;
		}

		return $data;
	}

	/**
	 * Returns the patch-friendly field map for {@see Term::sanitizeAndSetDefaults()}.
	 *
	 * Mirrors the Post equivalent but with the term-specific column set (no keyphrases, no schema,
	 * no AI, simpler image surface). Field map semantics are documented on {@see CommonModels\Post::getSanitizeFieldMap()}.
	 *
	 * @since 4.9.8
	 *
	 * @return array
	 */
	protected static function getSanitizeFieldMap() {
		return [
			// General.
			'title'                       => [
				'column'   => 'title',
				'sanitize' => 'text'
			],
			'description'                 => [
				'column'   => 'description',
				'sanitize' => 'text'
			],
			'keywords'                    => [
				'column'   => 'keywords',
				'sanitize' => 'helper'
			],
			'seo_score'                   => [
				'column'   => 'seo_score',
				'sanitize' => 'text',
				'default'  => 0
			],
			// Sitemap.
			'frequency'                   => [
				'column'   => 'frequency',
				'sanitize' => 'text'
			],
			// Robots Meta.
			'default'                     => [
				'column'   => 'robots_default',
				'sanitize' => 'bool'
			],
			'noindex'                     => [
				'column'   => 'robots_noindex',
				'sanitize' => 'bool'
			],
			'nofollow'                    => [
				'column'   => 'robots_nofollow',
				'sanitize' => 'bool'
			],
			'noarchive'                   => [
				'column'   => 'robots_noarchive',
				'sanitize' => 'bool'
			],
			'notranslate'                 => [
				'column'   => 'robots_notranslate',
				'sanitize' => 'bool'
			],
			'noimageindex'                => [
				'column'   => 'robots_noimageindex',
				'sanitize' => 'bool'
			],
			'nosnippet'                   => [
				'column'   => 'robots_nosnippet',
				'sanitize' => 'bool'
			],
			'noodp'                       => [
				'column'   => 'robots_noodp',
				'sanitize' => 'bool'
			],
			'maxSnippet'                  => [
				'column'   => 'robots_max_snippet',
				'sanitize' => 'int_neg1'
			],
			'maxVideoPreview'             => [
				'column'   => 'robots_max_videopreview',
				'sanitize' => 'int_neg1'
			],
			'maxImagePreview'             => [
				'column'   => 'robots_max_imagepreview',
				'sanitize' => 'text',
				'default'  => 'large'
			],
			// Open Graph Meta.
			'og_title'                    => [
				'column'   => 'og_title',
				'sanitize' => 'text'
			],
			'og_description'              => [
				'column'   => 'og_description',
				'sanitize' => 'text'
			],
			'og_object_type'              => [
				'column'   => 'og_object_type',
				'sanitize' => 'text',
				'default'  => 'default'
			],
			'og_image_custom_url'         => [
				'column'   => 'og_image_custom_url',
				'sanitize' => 'url'
			],
			'og_image_custom_fields'      => [
				'column'   => 'og_image_custom_fields',
				'sanitize' => 'text'
			],
			'og_image_type'               => [
				'column'   => 'og_image_type',
				'sanitize' => 'text',
				'default'  => 'default'
			],
			'og_video'                    => [
				'column'   => 'og_video',
				'sanitize' => 'text',
				'default'  => ''
			],
			'og_article_section'          => [
				'column'   => 'og_article_section',
				'sanitize' => 'text'
			],
			'og_article_tags'             => [
				'column'   => 'og_article_tags',
				'sanitize' => 'helper'
			],
			// Twitter Meta.
			'twitter_title'               => [
				'column'   => 'twitter_title',
				'sanitize' => 'text'
			],
			'twitter_description'         => [
				'column'   => 'twitter_description',
				'sanitize' => 'text'
			],
			'twitter_card'                => [
				'column'   => 'twitter_card',
				'sanitize' => 'text',
				'default'  => 'default'
			],
			'twitter_use_og'              => [
				'column'   => 'twitter_use_og',
				'sanitize' => 'bool'
			],
			'twitter_image'               => [
				'column'   => 'twitter_image',
				'sanitize' => 'text'
			],
			'twitter_image_custom_url'    => [
				'column'   => 'twitter_image_custom_url',
				'sanitize' => 'url'
			],
			'twitter_image_custom_fields' => [
				'column'   => 'twitter_image_custom_fields',
				'sanitize' => 'text'
			],
			'twitter_image_type'          => [
				'column'   => 'twitter_image_type',
				'sanitize' => 'text',
				'default'  => 'default'
			]
		];
	}

	/**
	 * Sanitizes the term data and sets it (or the default value) to the Term object.
	 *
	 * @since 4.1.5
	 *
	 * @param  int   $termId  The term ID.
	 * @param  Term  $theTerm The Term object.
	 * @param  array $data    The data.
	 * @return Term           The Term object with data set.
	 */
	private static function sanitizeAndSetDefaults( $termId, $theTerm, $data ) {
		// Patch semantics: only assign fields that appear in $data. Missing keys preserve the
		// current model value. Callers that want to clear a field must pass an explicit null/empty.

		$theTerm->term_id = $termId;

		CommonModels\Post::applyPatchFields( $theTerm, $data, self::getSanitizeFieldMap() );

		// Custom fields — fields that need bespoke per-field logic don't fit the generic map.
		if ( array_key_exists( 'canonicalUrl', $data ) || array_key_exists( 'canonical_url', $data ) ) {
			// camelCase takes precedence; an explicit empty camelCase value clears the field even if snake_case is present.
			$canonicalUrl           = $data['canonicalUrl'] ?? $data['canonical_url'] ?? null;
			$theTerm->canonical_url = ! empty( $canonicalUrl ) ? esc_url_raw( $canonicalUrl ) : null;
		}
		if ( array_key_exists( 'priority', $data ) ) {
			$theTerm->priority = 'default' === sanitize_text_field( (string) $data['priority'] ) ? null : (float) $data['priority'];
		}
		if ( array_key_exists( 'breadcrumb_settings', $data ) ) {
			$theTerm->breadcrumb_settings = isset( $data['breadcrumb_settings']['default'] ) && false === $data['breadcrumb_settings']['default'] ? $data['breadcrumb_settings'] : null;
		}
		if ( array_key_exists( 'truseo', $data ) ) {
			$theTerm->truseo = ! empty( $data['truseo'] ) ? CommonModels\Post::sanitizeTruseo( $data['truseo'] ) : null;
		}
		if ( array_key_exists( 'focus_keyword', $data ) ) {
			$theTerm->focus_keyword = ! empty( $data['focus_keyword'] ) && is_string( $data['focus_keyword'] ) ? sanitize_text_field( $data['focus_keyword'] ) : null;
		}
		if ( array_key_exists( 'additional_keywords', $data ) ) {
			$theTerm->additional_keywords = ! empty( $data['additional_keywords'] ) ? CommonModels\Post::sanitizeAdditionalKeywords( $data['additional_keywords'] ) : null;
		}
		if ( array_key_exists( 'truseo_locale', $data ) ) {
			$theTerm->truseo_locale = ! empty( $data['truseo_locale'] ) ? sanitize_text_field( $data['truseo_locale'] ) : null;
		}

		// Always-stamped — every save bumps the timestamp.
		$theTerm->updated = gmdate( 'Y-m-d H:i:s' );

		// Before we determine the OG/Twitter image, we need to set the meta data cache manually because the changes haven't been saved yet.
		aioseo()->meta->metaData->bustTermCache( $theTerm->term_id, $theTerm );

		// Set the OG/Twitter image data.
		$theTerm = self::setOgTwitterImageData( $theTerm );

		if ( ! $theTerm->exists() ) {
			$theTerm->created = gmdate( 'Y-m-d H:i:s' );
		}

		return $theTerm;
	}

	/**
	 * Set the OG/Twitter image data on the term object.
	 *
	 * @since 4.1.6
	 *
	 * @param  Term $theTerm The Term object to modify.
	 * @return Term          The modified Term object.
	 */
	public static function setOgTwitterImageData( $theTerm ) {
		// Set the OG image.
		if (
			in_array( $theTerm->og_image_type, [
				'custom',
				'custom_image'
			], true )
		) {
			// Disable the cache.
			aioseo()->social->image->useCache = false;

			// Set the image details.
			$ogImage                  = aioseo()->social->facebook->getImage();
			$theTerm->og_image_url    = is_array( $ogImage ) ? $ogImage[0] : $ogImage;
			$theTerm->og_image_width  = aioseo()->social->facebook->getImageWidth();
			$theTerm->og_image_height = aioseo()->social->facebook->getImageHeight();

			// Reset the cache property.
			aioseo()->social->image->useCache = true;
		}

		// Set the Twitter image.
		if (
			! $theTerm->twitter_use_og &&
			in_array( $theTerm->twitter_image_type, [
				'custom',
				'custom_image'
			], true )
		) {
			// Disable the cache.
			aioseo()->social->image->useCache = false;

			// Set the image details.
			$ogImage                    = aioseo()->social->twitter->getImage();
			$theTerm->twitter_image_url = is_array( $ogImage ) ? $ogImage[0] : $ogImage;

			// Reset the cache property.
			aioseo()->social->image->useCache = true;
		}

		return $theTerm;
	}

	/**
	 * Saves some of the data as term meta so that it can be used for localization.
	 *
	 * @since   4.1.5
	 * @version 4.9.8 Patch-aware: only syncs meta for keys present in $data, so partial saves
	 *                 (e.g. the Abilities API) don't warn on, or wipe, fields they didn't touch.
	 *
	 * @param  int   $termId The term ID.
	 * @param  array $data   The data.
	 * @return void
	 */
	public static function updateTermMeta( $termId, $data ) {
		// Only the keys actually present in $data are synced — missing keys keep their existing meta,
		// mirroring sanitizeAndSetDefaults()'s patch semantics.
		$metaMap = [
			'title'               => '_aioseo_title',
			'description'         => '_aioseo_description',
			'og_title'            => '_aioseo_og_title',
			'og_description'      => '_aioseo_og_description',
			'og_article_section'  => '_aioseo_og_article_section',
			'twitter_title'       => '_aioseo_twitter_title',
			'twitter_description' => '_aioseo_twitter_description'
		];
		foreach ( $metaMap as $key => $metaKey ) {
			if ( array_key_exists( $key, $data ) ) {
				update_term_meta( $termId, $metaKey, $data[ $key ] );
			}
		}

		if ( array_key_exists( 'keywords', $data ) ) {
			$keywords = ! empty( $data['keywords'] ) ? aioseo()->helpers->jsonTagsToCommaSeparatedList( $data['keywords'] ) : [];
			update_term_meta( $termId, '_aioseo_keywords', $keywords );
		}
		if ( array_key_exists( 'og_article_tags', $data ) ) {
			$ogArticleTags = ! empty( $data['og_article_tags'] ) ? aioseo()->helpers->jsonTagsToCommaSeparatedList( $data['og_article_tags'] ) : [];
			update_term_meta( $termId, '_aioseo_og_article_tags', $ogArticleTags );
		}
	}

	/**
	 * Returns the default breadcrumb settings options.
	 *
	 * @since 4.8.3
	 *
	 * @param  string  $taxonomy        The taxonomy name.
	 * @param  array   $existingOptions The existing options.
	 * @return object                   The default options.
	 */
	public static function getDefaultBreadcrumbSettingsOptions( $taxonomy, $existingOptions = [] ) {
		$default       = aioseo()->dynamicOptions->breadcrumbs->taxonomies->$taxonomy->useDefaultTemplate;
		$showHomeCrumb = $default ? aioseo()->options->breadcrumbs->homepageLink : aioseo()->dynamicOptions->breadcrumbs->taxonomies->$taxonomy->showHomeCrumb;

		$defaults = [
			'default'            => true,
			'separator'          => aioseo()->options->breadcrumbs->separator,
			'breadcrumbPrefix'   => aioseo()->options->breadcrumbs->breadcrumbPrefix ?? false,
			'showHomeCrumb'      => $showHomeCrumb,
			'showTaxonomyCrumbs' => aioseo()->dynamicOptions->breadcrumbs->taxonomies->$taxonomy->showTaxonomyCrumbs ?? false,
			'showParentCrumbs'   => aioseo()->dynamicOptions->breadcrumbs->taxonomies->$taxonomy->showParentCrumbs ?? false,
			'template'           => aioseo()->helpers->encodeOutputHtml( aioseo()->breadcrumbs->frontend->getDefaultTemplate( 'taxonomy' ) ),
			'parentTemplate'     => aioseo()->helpers->encodeOutputHtml( aioseo()->breadcrumbs->frontend->getDefaultTemplate( 'taxonomy' ) )
		];

		if ( empty( $existingOptions ) ) {
			return json_decode( wp_json_encode( $defaults ) );
		}

		$existingOptions = json_decode( wp_json_encode( $existingOptions ), true );
		if ( ! is_array( $existingOptions ) ) {
			return json_decode( wp_json_encode( $defaults ) );
		}

		$existingOptions = array_replace_recursive( $defaults, $existingOptions );

		return json_decode( wp_json_encode( $existingOptions ) );
	}
}