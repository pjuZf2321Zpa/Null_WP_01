<?php

namespace AIOSEO\Plugin\Pro\Ai;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AIOSEO\Plugin\Common\Ai as CommonAi;

/**
 * Handles AIOSEO AI.
 *
 * @since 4.8.4
 */
class Ai extends CommonAi\Ai {
	/**
	 * Gets an access token from the server.
	 *
	 * @since 4.8.4
	 *
	 * @param  bool $refresh Whether to refresh the access token.
	 * @return void
	 */
	public function getAccessToken( $refresh = false ) {
		if (
			(
				aioseo()->sensitiveOptions->hasValue( 'aiAccessToken' ) ||
				aioseo()->core->cache->get( 'ai_access_token_idle' )
			) &&
			! $refresh
		) {
			return;
		}

		// If user has no valid license, run the Lite flow.
		if ( ! aioseo()->license->isActive() ) {
			parent::getAccessToken( $refresh );

			return;
		}

		$response = aioseo()->helpers->wpRemotePost( $this->getApiUrl() . 'ai/auth/', [
			'body'    => wp_json_encode( [
				'domain' => aioseo()->helpers->getSiteDomain()
			] ),
			'headers' => $this->getRequestHeaders()
		] );

		if ( is_wp_error( $response ) ) {
			aioseo()->core->cache->update( 'ai_access_token_idle', true, 4 * HOUR_IN_SECONDS );

			return;
		}

		$body = wp_remote_retrieve_body( $response );
		$data = json_decode( $body );
		if ( empty( $data->accessToken ) ) {
			aioseo()->core->cache->update( 'ai_access_token_idle', true, HOUR_IN_SECONDS );

			return;
		}

		aioseo()->sensitiveOptions->set( 'aiAccessToken', sanitize_text_field( $data->accessToken ) );
		aioseo()->internalOptions->internal->ai->isTrialAccessToken  = $data->isFree ?? false;
		aioseo()->internalOptions->internal->ai->isManuallyConnected = false;

		aioseo()->core->cache->update( 'ai_access_token_idle', true, 12 * HOUR_IN_SECONDS );

		$this->updateCredits( true );
	}

	/**
	 * Returns the default request headers.
	 *
	 * @since   4.8.4
	 * @version 4.9.6 Changed method visibility to public.
	 *
	 * @return array The default request headers.
	 */
	public function getRequestHeaders() {
		$headers = parent::getRequestHeaders();

		$licenseKey = aioseo()->license->getLicenseKey();
		if ( ! $licenseKey || ! aioseo()->license->isActive() ) {
			return $headers;
		}

		$headers['X-AIOSEO-License'] = $licenseKey;

		return $headers;
	}
}