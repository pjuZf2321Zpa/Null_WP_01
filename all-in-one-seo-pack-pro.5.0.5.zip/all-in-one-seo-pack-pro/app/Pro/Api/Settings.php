<?php
namespace AIOSEO\Plugin\Pro\Api;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AIOSEO\Plugin\Common\Api as CommonApi;
use AIOSEO\Plugin\Pro\Models;

/**
 * Route class for the API.
 *
 * @since 4.0.0
 */
class Settings extends CommonApi\Settings {
	/**
	 * Save options from the front end.
	 *
	 * @since 4.1.0
	 *
	 * @param  \WP_REST_Request  $request The REST Request
	 * @return \WP_REST_Response          The response.
	 */
	public static function saveChanges( $request ) {
		$oldSearchAppearanceSettings = self::getScanRelevantSearchAppearanceSettings();
		$newSearchAppearanceSettings = self::getScanRelevantSearchAppearanceSettingsFromRequest( $request );

		$response = parent::saveChanges( $request );

		self::resetScanDatesForChangedSettings( $oldSearchAppearanceSettings, $newSearchAppearanceSettings );

		Api::addonsApi( $request, null, '\\Api\\Settings', 'saveChanges' );

		return $response;
	}

	/**
	 * Reset SEO Analysis scan dates only for the scopes whose settings changed.
	 *
	 * Post-type template changes invalidate post scans; taxonomy template changes
	 * invalidate term scans. The separator affects both because it is rendered into
	 * post and term titles/descriptions via `#separator_sa`.
	 *
	 * @since 4.9.7
	 *
	 * @param  array $oldSettings The search appearance settings before save.
	 * @param  array $newSettings The search appearance settings after save.
	 * @return void
	 */
	private static function resetScanDatesForChangedSettings( $oldSettings, $newSettings ) {
		$separatorChanged = $oldSettings['separator'] !== $newSettings['separator'];
		$oldPostTypes     = $oldSettings['postTypes'] ?? [];
		$newPostTypes     = $newSettings['postTypes'] ?? [];
		$oldTaxonomies    = $oldSettings['taxonomies'] ?? [];
		$newTaxonomies    = $newSettings['taxonomies'] ?? [];

		if ( $separatorChanged ) {
			aioseo()->seoAnalysis->resetPostScanDates();
			aioseo()->seoAnalysis->resetTermScanDates();

			return;
		}

		foreach ( $newPostTypes as $postType => $settings ) {
			if ( ( $oldPostTypes[ $postType ] ?? null ) !== $settings ) {
				aioseo()->seoAnalysis->resetPostScanDatesForPostType( $postType );
			}
		}

		foreach ( $newTaxonomies as $taxonomy => $settings ) {
			if ( ( $oldTaxonomies[ $taxonomy ] ?? null ) !== $settings ) {
				aioseo()->seoAnalysis->resetTermScanDatesForTaxonomy( $taxonomy );
			}
		}
	}

	/**
	 * Get the current search appearance settings whose changes invalidate SEO Analysis results.
	 *
	 * Only includes settings that affect scanned posts and terms. Home page settings
	 * (e.g. `global.siteTitle`, `global.metaDescription`) are excluded because the
	 * home page is not part of the site audit.
	 *
	 * @since 4.9.7
	 *
	 * @return array The settings.
	 */
	private static function getScanRelevantSearchAppearanceSettings() {
		$settings = [
			'separator' => aioseo()->options->searchAppearance->global->separator
		];

		foreach ( aioseo()->helpers->getPublicPostTypes( true ) as $postType ) {
			if ( aioseo()->dynamicOptions->searchAppearance->postTypes->has( $postType ) ) {
				$settings['postTypes'][ $postType ] = [
					'title'           => aioseo()->dynamicOptions->searchAppearance->postTypes->{$postType}->title,
					'metaDescription' => aioseo()->dynamicOptions->searchAppearance->postTypes->{$postType}->metaDescription
				];
			}
		}

		foreach ( aioseo()->helpers->getPublicTaxonomies( true ) as $taxonomy ) {
			if ( aioseo()->dynamicOptions->searchAppearance->taxonomies->has( $taxonomy ) ) {
				$settings['taxonomies'][ $taxonomy ] = [
					'title'           => aioseo()->dynamicOptions->searchAppearance->taxonomies->{$taxonomy}->title,
					'metaDescription' => aioseo()->dynamicOptions->searchAppearance->taxonomies->{$taxonomy}->metaDescription
				];
			}
		}

		return $settings;
	}

	/**
	 * Get the scan-relevant search appearance settings from the request body.
	 *
	 * This reads from the request payload rather than the in-memory options cache
	 * to avoid comparing stale values after the cache is updated by parent::saveChanges().
	 * Mirrors getScanRelevantSearchAppearanceSettings() — home page settings are excluded.
	 *
	 * @since 4.9.7
	 *
	 * @param  \WP_REST_Request $request The REST Request.
	 * @return array                     The settings.
	 */
	private static function getScanRelevantSearchAppearanceSettingsFromRequest( $request ) {
		$body           = $request->get_json_params();
		$options        = ! empty( $body['options'] ) ? $body['options'] : [];
		$dynamicOptions = ! empty( $body['dynamicOptions'] ) ? $body['dynamicOptions'] : [];

		$settings = [
			'separator' => $options['searchAppearance']['global']['separator'] ?? aioseo()->options->searchAppearance->global->separator
		];

		foreach ( aioseo()->helpers->getPublicPostTypes( true ) as $postType ) {
			if ( aioseo()->dynamicOptions->searchAppearance->postTypes->has( $postType ) ) {
				$settings['postTypes'][ $postType ] = [
					'title'           => $dynamicOptions['searchAppearance']['postTypes'][ $postType ]['title']
						?? aioseo()->dynamicOptions->searchAppearance->postTypes->{$postType}->title,
					'metaDescription' => $dynamicOptions['searchAppearance']['postTypes'][ $postType ]['metaDescription']
						?? aioseo()->dynamicOptions->searchAppearance->postTypes->{$postType}->metaDescription
				];
			}
		}

		foreach ( aioseo()->helpers->getPublicTaxonomies( true ) as $taxonomy ) {
			if ( aioseo()->dynamicOptions->searchAppearance->taxonomies->has( $taxonomy ) ) {
				$settings['taxonomies'][ $taxonomy ] = [
					'title'           => $dynamicOptions['searchAppearance']['taxonomies'][ $taxonomy ]['title']
						?? aioseo()->dynamicOptions->searchAppearance->taxonomies->{$taxonomy}->title,
					'metaDescription' => $dynamicOptions['searchAppearance']['taxonomies'][ $taxonomy ]['metaDescription']
						?? aioseo()->dynamicOptions->searchAppearance->taxonomies->{$taxonomy}->metaDescription
				];
			}
		}

		return $settings;
	}

	/**
	 * Import from other plugins.
	 *
	 * @since 4.2.5
	 *
	 * @param  \WP_REST_Request  $request The REST Request
	 * @return \WP_REST_Response          The response.
	 */
	public static function importPlugins( $request ) {
		$body   = $request->get_json_params();
		$siteId = ! empty( $body['siteId'] ) ? (int) $body['siteId'] : get_current_blog_id();

		// Ensure the user has access to the target site.
		if (
			is_multisite() &&
			(
				! is_user_member_of_blog( get_current_user_id(), $siteId ) &&
				! is_super_admin()
			)
		) {
			return new \WP_REST_Response( [
				'success' => false,
				'message' => 'You do not have permission to access this site.'
			], 403 );
		}

		aioseo()->helpers->switchToBlog( $siteId );

		return parent::importPlugins( $request );
	}

	/**
	 * Imports settings.
	 *
	 * @since 4.0.0
	 *
	 * @param  \WP_REST_Request  $request The REST Request
	 * @return \WP_REST_Response          The response.
	 */
	public static function importSettings( $request ) {
		$args   = $request->get_params();
		$siteId = ! empty( $args['siteId'] ) ? (int) $args['siteId'] : get_current_blog_id();

		// Ensure the user has access to the target site.
		if (
			is_multisite() &&
			(
				! is_user_member_of_blog( get_current_user_id(), $siteId ) &&
				! is_super_admin()
			)
		) {
			return new \WP_REST_Response( [
				'success' => false,
				'message' => 'You do not have permission to access this site.'
			], 403 );
		}

		aioseo()->helpers->switchToBlog( $siteId );

		$response = parent::importSettings( $request );
		if ( ! $response->data['success'] ) {
			return $response;
		}

		$contents = parent::$importFile;

		if ( ! empty( $contents['postOptions'] ) ) {
			$notAllowedFields = aioseo()->access->getNotAllowedPageFields();
			foreach ( $contents['postOptions'] as $postData ) {
				// Terms.
				if ( ! empty( $postData['terms'] ) ) {
					foreach ( $postData['terms'] as $term ) {
						unset( $term['id'] );
						// Clean up the array removing fields the user should not manage.
						$term = array_diff_key( $term, $notAllowedFields );

						$floatFields = [ 'priority' ];
						foreach ( $term as $key => $field ) {
							if ( in_array( $key, $floatFields, true ) ) {
								$field        = ! empty( $field ) ? trim( $field ) : $field;
								$term[ $key ] = ! empty( $field ) ? number_format( (float) $field, 1 ) : null;
							}
						}

						$theTerm = Models\Term::getTerm( $term['term_id'] );
						$theTerm->set( $term );
						$theTerm->save();
					}
				}
			}
		}

		$response->data['license'] = [
			'isActive'   => aioseo()->license->isActive(),
			'isExpired'  => aioseo()->license->isExpired(),
			'isDisabled' => aioseo()->license->isDisabled(),
			'isInvalid'  => aioseo()->license->isInvalid(),
			'expires'    => aioseo()->internalOptions->internal->license->expires
		];

		return Api::addonsApi( $request, $response, '\\Api\\Settings', 'importSettings' );
	}

	/**
	 * Export settings.
	 *
	 * @since 4.0.6
	 *
	 * @param  \WP_REST_Request  $request The REST Request
	 * @return \WP_REST_Response          The response.
	 */
	public static function exportSettings( $request ) {
		$body   = $request->get_json_params();
		$siteId = ! empty( $body['siteId'] ) ? (int) $body['siteId'] : get_current_blog_id();

		// Ensure the user has access to the target site.
		if (
			is_multisite() &&
			(
				! is_user_member_of_blog( get_current_user_id(), $siteId ) &&
				! is_super_admin()
			)
		) {
			return new \WP_REST_Response( [
				'success' => false,
				'message' => 'You do not have permission to access this site.'
			], 403 );
		}

		aioseo()->helpers->switchToBlog( $siteId );

		$response = parent::exportSettings( $request );

		return Api::addonsApi( $request, $response, '\\Api\\Settings', 'exportSettings' );
	}

	/**
	 * Export Post Types.
	 *
	 * @since   4.7.2
	 * @version 5.0.2 Check the capability before switching; restore the blog before returning.
	 *
	 * @param  \WP_REST_Request  $request The REST Request.
	 * @return \WP_REST_Response          The response.
	 */
	public static function exportContent( $request ) {
		$body              = $request->get_json_params();
		$postTypes         = $body['postOptions'] ?? [];
		$taxonomies        = $body['taxonomiesOptions'] ?? [];
		$typeFile          = $body['typeFile'] ?? false;
		$siteId            = (int) ( $body['siteId'] ?? get_current_blog_id() );
		$contentTaxonomies = null;
		$return            = true;

		if ( ! empty( $postTypes ) ) {
			return parent::exportContent( $request );
		}

		// Ensure the user has access to the target site.
		if (
			is_multisite() &&
			(
				! is_user_member_of_blog( get_current_user_id(), $siteId ) &&
				! is_super_admin()
			)
		) {
			return new \WP_REST_Response( [
				'success' => false,
				'message' => 'You do not have permission to access this site.'
			], 403 );
		}

		try {
			aioseo()->helpers->switchToBlog( $siteId );

			if ( ! empty( $taxonomies ) ) {
				if ( in_array( 'product_attributes', $taxonomies, true ) ) {
					$allTaxonomies = get_taxonomies( [ 'public' => true ], 'objects' );
					foreach ( $allTaxonomies as $taxonomy ) {
						if ( aioseo()->helpers->isWooCommerceProductAttribute( $taxonomy->name ) ) {
							$taxonomies[] = $taxonomy->name;
						}
					}

					unset( $taxonomies[ array_search( 'product_attributes', $taxonomies, true ) ] );
				}

				$fieldsToExclude = [
					'images'          => '',
					'videos'          => '',
					'video_scan_date' => '',
					'local_seo'       => ''
				];

				$notAllowed = array_merge( aioseo()->access->getNotAllowedPageFields(), $fieldsToExclude );
				$terms      = self::getTermData( $taxonomies, $notAllowed );

				// Generate content to CSV or JSON.
				if ( ! empty( $terms ) ) {
					// Change the order of keys so the taxonomy shows up at the beginning.
					$data = [];
					foreach ( $terms as $t ) {
						$item = [
							'id'      => $t['id'],
							'term_id' => $t['term_id'],
							'name'    => $t['name'],
						];

						$data[] = array_merge( $item, $t );
					}

					if ( 'csv' === $typeFile ) {
						$contentTaxonomies = parent::dataToCsv( $data );
					}
					if ( 'json' === $typeFile ) {
						$contentTaxonomies['postOptions']['content']['terms'] = $data;
					}
				}
			}
		} catch ( \Throwable $th ) {
			$return = false;
		} finally {
			aioseo()->helpers->restoreCurrentBlog();
		}

		return new \WP_REST_Response( [
			'success'        => $return,
			'postTypeData'   => null,
			'taxonomiesData' => $contentTaxonomies
		], 200 );
	}

	/**
	 * Returns the Terms for the specific Taxonomies Options.
	 *
	 * @since 4.7.2
	 *
	 * @param  array $taxonomies       The taxonomies.
	 * @param  array $notAllowedFields The fields not allowed.
	 * @return array                   The terms.
	 */
	private static function getTermData( $taxonomies, $notAllowedFields = [] ) {
		$terms = aioseo()->core->db->start( 'aioseo_terms as at' )
			->select( 'at.*, t.name' )
			->join( 'terms as t', 't.term_id = at.term_id' )
			->join( 'term_taxonomy as tt', 'tt.term_id = at.term_id' )
			->whereIn( 'tt.taxonomy', $taxonomies )
			->orderBy( 'tt.taxonomy' )
			->groupBy( 'at.id, at.term_id' )
			->run()
			->result();

		if ( ! empty( $notAllowedFields ) ) {
			foreach ( $terms as $key => &$term ) {
				$term = array_diff_key( (array) $term, $notAllowedFields );
				if ( count( $term ) <= 2 ) {
					unset( $terms[ $key ] );
				}
			}
		}

		return $terms;
	}

	/**
	 * Reset settings.
	 *
	 * @since 4.1.0
	 *
	 * @param  \WP_REST_Request  $request The REST Request.
	 * @return \WP_REST_Response          The response.
	 */
	public static function resetSettings( $request ) {
		$body   = $request->get_json_params();
		$siteId = ! empty( $body['siteId'] ) ? (int) $body['siteId'] : get_current_blog_id();

		// Ensure the user has access to the target site.
		if (
			is_multisite() &&
			(
				! is_user_member_of_blog( get_current_user_id(), $siteId ) &&
				! is_super_admin()
			)
		) {
			return new \WP_REST_Response( [
				'success' => false,
				'message' => 'You do not have permission to access this site.'
			], 403 );
		}

		aioseo()->helpers->switchToBlog( $siteId );

		$response = parent::resetSettings( $request );

		return Api::addonsApi( $request, $response, '\\Api\\Settings', 'resetSettings' );
	}

	/**
	 * Executes a given administrative task.
	 *
	 * @since 4.1.6
	 *
	 * @param  \WP_REST_Request  $request The REST Request.
	 * @return \WP_REST_Response          The response.
	 */
	public static function doTask( $request ) {
		$body          = $request->get_json_params();
		$action        = ! empty( $body['action'] ) ? $body['action'] : '';
		$siteId        = ! empty( $body['siteId'] ) ? intval( $body['siteId'] ) : false;
		$siteOrNetwork = empty( $siteId ) ? aioseo()->helpers->getNetworkId() : $siteId;

		// First, check if an addon registered action is found.
		$addonActionExecuted = array_filter( aioseo()->addons->doAddonFunction( 'helpers', 'doTask', [ $action ] ) );
		$addonActionExecuted = end( $addonActionExecuted );

		if ( $addonActionExecuted ) {
			return new \WP_REST_Response( [
				'success' => true
			], 200 );
		}

		// Ensure the user has access to the target site.
		if (
			is_multisite() &&
			(
				! is_user_member_of_blog( get_current_user_id(), $siteId ) &&
				! is_super_admin()
			)
		) {
			return new \WP_REST_Response( [
				'success' => false,
				'message' => 'You do not have permission to access this site.'
			], 403 );
		}

		aioseo()->helpers->switchToBlog( $siteOrNetwork );

		// Then, check our Pro actions.
		switch ( $action ) {
			case 'reset-data':
				aioseo()->uninstall->dropData( true );
				aioseo()->core->cache->delete( 'db_schema' );
				aioseo()->internalOptions->internal->lastActiveProVersion = '4.0.0';
				aioseo()->internalOptions->save( true );
				aioseo()->updates->addInitialCustomTablesForV4();
				break;
			case 'rerun-migrations':
				aioseo()->core->cache->delete( 'db_schema' );
				aioseo()->internalOptions->internal->lastActiveProVersion = '4.0.0';
				aioseo()->internalOptions->save( true );
				break;
			case 'reset-seo-analysis-data':
				aioseo()->core->db->truncate( 'aioseo_seo_analyzer_objects' )->run();
				aioseo()->seoAnalysis->resetScanDates();

				aioseo()->helpers->restoreCurrentBlog();

				return new \WP_REST_Response( [
					'success' => true
				], 200 );
		}

		aioseo()->helpers->restoreCurrentBlog();

		// We still want to run through the Common actions here since we still need to retrigger the common migrations as well.
		return parent::doTask( $request );
	}
}