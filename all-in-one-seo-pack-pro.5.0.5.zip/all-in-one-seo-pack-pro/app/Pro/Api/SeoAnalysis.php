<?php
namespace AIOSEO\Plugin\Pro\Api;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AIOSEO\Plugin\Pro\Models\Issue;
use AIOSEO\Plugin\Pro\Models as ProModels;
use AIOSEO\Plugin\Common\Models\Post;

/**
 * Route class for the API.
 *
 * @since 4.8.6
 */
class SeoAnalysis {
	/**
	 * Get list of issues code.
	 *
	 * @since 4.8.6
	 *
	 * @param  \WP_REST_Request  $request The REST Request
	 * @return \WP_REST_Response          The response.
	 */
	public static function getIssues( $request ) {
		$queryParams = $request->get_query_params();
		$status      = isset( $queryParams['status'] ) ? sanitize_text_field( $queryParams['status'] ) : null;

		$codes   = empty( $status ) ? aioseo()->seoAnalysis->getAllCodes() : aioseo()->seoAnalysis->getCodesByStatus( $status );
		$results = [
			'basic'       => [],
			'advanced'    => [],
			'performance' => []
		];
		$counts  = [
			'passed'  => 0,
			'warning' => 0,
			'error'   => 0
		];

		if ( empty( $codes ) ) {
			return new \WP_REST_Response( [
				'success' => true,
				'result'  => [
					'counts'  => $counts,
					'results' => $results
				],
			], 200 );
		}

		$items = Issue::getIssuesByCodes( $codes );
		if ( empty( $items ) ) {
			return new \WP_REST_Response( [
				'success' => true,
				'result'  => [
					'counts'  => $counts,
					'results' => $results
				],
			], 200 );
		}

		$passedCodes  = aioseo()->seoAnalysis->getCodesByStatus( 'passed' );
		$warningCodes = aioseo()->seoAnalysis->getCodesByStatus( 'warning' );
		$errorCodes   = aioseo()->seoAnalysis->getCodesByStatus( 'error' );
		$sortedCodes  = aioseo()->seoAnalysis->getAllCodesSortedByGroupAndStatus( $status );
		foreach ( $items as $item ) {
			if ( in_array( $item->code, $warningCodes, true ) ) {
				$status = 'warning';
			} elseif ( in_array( $item->code, $errorCodes, true ) ) {
				$status = 'error';
			} elseif ( in_array( $item->code, $passedCodes, true ) ) {
				$status = 'passed';
			}

			$group = aioseo()->seoAnalysis->getGroupByCodeAndStatus( $item->code, $status );
			if ( ! empty( $status ) && ! empty( $group ) ) {
				$results[ $group ][] = [
					'code'   => $item->code,
					'status' => $status,
					'count'  => $item->count,
					'order'  => empty( $sortedCodes ) ? null : $sortedCodes[ $group ][ $status ][ $item->code ]
				];

				$counts[ $status ] = $counts[ $status ] + $item->count;
			}
		}

		if ( ! empty( $sortedCodes ) ) {
			foreach ( $results as $group => $items ) {
				usort( $results[ $group ], function( $a, $b ) {
					return $a['order'] - $b['order'];
				});
			}
		}

		return new \WP_REST_Response( [
			'success' => true,
			'result'  => [
				'results' => $results,
				'counts'  => $counts
			]
		], 200 );
	}

	/**
	 * Get objects by issue code.
	 *
	 * @since 4.8.6
	 *
	 * @param  \WP_REST_Request  $request The REST Request
	 * @return \WP_REST_Response          The response.
	 */
	public static function getObjectsByIssueCode( $request ) {
		$params      = $request->get_params();
		$queryParams = $request->get_query_params();

		$code   = isset( $params['issueCode'] ) ? sanitize_text_field( $params['issueCode'] ) : '';
		$search = isset( $queryParams['search'] ) ? sanitize_text_field( $queryParams['search'] ) : '';
		$limit  = isset( $queryParams['limit'] ) ? (int) sanitize_text_field( $queryParams['limit'] ) : aioseo()->settings->tablePagination['seoAnalysis'];
		$offset = isset( $queryParams['offset'] ) ? (int) sanitize_text_field( $queryParams['offset'] ) : 0;

		$results      = Issue::getObjectsByIssueCode( $code, $limit, $offset, $search );
		$totalResults = Issue::getTotalObjectsByIssueCode( $code, $search );
		$page       = 0 === $offset ? 1 : ( $offset / $limit ) + 1;

		return new \WP_REST_Response( [
			'success' => true,
			'result'  => [
				'rows'            => $results,
				'hasIssueDetails' => self::hasIssueDetails( $results ),
				'totals'          => [
					'page'  => $page,
					'pages' => ceil( $totalResults / $limit ),
					'total' => $totalResults
				]
			],
		], 200 );
	}

	/**
	 * Get issues by object id.
	 *
	 * @since   4.8.6
	 * @version 5.0.2 Authorize the request against the target object (edit_post/edit_term).
	 *
	 * @param  \WP_REST_Request  $request The REST Request
	 * @return \WP_REST_Response          The response.
	 */
	public static function getIssuesByObject( $request ) {
		$params      = $request->get_params();
		$queryParams = $request->get_query_params();

		// WordPress matches REST routes case-insensitively, so "TERM" reaches this handler too.
		$objectId   = isset( $params['objectId'] ) ? sanitize_text_field( $params['objectId'] ) : '';
		$objectType = isset( $params['objectType'] ) ? strtolower( sanitize_text_field( $params['objectType'] ) ) : '';
		$search     = isset( $queryParams['search'] ) ? sanitize_text_field( $queryParams['search'] ) : '';

		if ( ! in_array( $objectType, [ 'post', 'term' ], true ) ) {
			return new \WP_REST_Response( [
				'success' => false,
				'message' => 'The request "objectType" is invalid.', // Not displayed to the user.
			], 400 );
		}

		// The route capability is site-wide, so scope an object's issues to users who can edit that object.
		if ( ! self::canEditObject( $objectId, $objectType ) ) {
			return new \WP_REST_Response( [ 'success' => false ], 403 );
		}

		$results      = Issue::getIssuesByObject( $objectId, $objectType, $search );
		$totalResults = Issue::getTotalIssuesByObject( $objectId, $objectType, $search );

		$passedCodes  = aioseo()->seoAnalysis->getCodesByStatus( 'passed' );
		$warningCodes = aioseo()->seoAnalysis->getCodesByStatus( 'warning' );
		$errorCodes   = aioseo()->seoAnalysis->getCodesByStatus( 'error' );

		$results = array_map(function( $post ) use ( $passedCodes, $warningCodes, $errorCodes ) {
			if ( in_array( $post->code, $warningCodes, true ) ) {
				$post->status = 'warning';
			} elseif ( in_array( $post->code, $errorCodes, true ) ) {
				$post->status = 'error';
			} elseif ( in_array( $post->code, $passedCodes, true ) ) {
				$post->status = 'passed';
			}

			return $post;
		}, $results);

		return new \WP_REST_Response( [
			'success' => true,
			'result'  => [
				'rows'   => $results,
				'totals' => [
					'total' => $totalResults
				]
			],
		], 200 );
	}

	/**
	 * Get objects.
	 *
	 * @since 4.8.6
	 * @param  \WP_REST_Request  $request The REST Request
	 * @return \WP_REST_Response          The response.
	 */
	public static function getObjects( $request ) {
		$queryParams = $request->get_query_params();

		$search            = isset( $queryParams['search'] ) ? sanitize_text_field( $queryParams['search'] ) : '';
		$limit             = isset( $queryParams['limit'] ) ? (int) sanitize_text_field( $queryParams['limit'] ) : aioseo()->settings->tablePagination['seoAnalysis'];
		$offset            = isset( $queryParams['offset'] ) ? (int) sanitize_text_field( $queryParams['offset'] ) : 0;
		$additionalFilters = isset( $queryParams['additionalFilters'] ) ? $queryParams['additionalFilters'] : [];

		$results      = Issue::getResults( $limit, $offset, $search, $additionalFilters );
		$totalResults = Issue::getTotalResults( $search, $additionalFilters );

		$page = 0 === $offset ? 1 : ( $offset / $limit ) + 1;

		return new \WP_REST_Response( [
			'success' => true,
			'result'  => [
				'rows'   => $results,
				'totals' => [
					'page'  => $page,
					'pages' => ceil( $totalResults / $limit ),
					'total' => $totalResults
				]
			],
		], 200 );
	}


	/**
	 * Ignore issue by id.
	 *
	 * @since   4.8.6
	 * @version 5.0.2 Authorize the request against the issue's object (edit_post/edit_term).
	 *
	 * @param  \WP_REST_Request  $request The REST Request
	 * @return \WP_REST_Response          The response.
	 */
	public static function ignoreIssue( $request ) {
		$params = $request->get_params();
		$id     = isset( $params['id'] ) ? (int) sanitize_text_field( $params['id'] ) : 0;

		$issue = Issue::getById( $id );

		if ( ! $issue->exists() ) {
			return new \WP_REST_Response( [
				'success' => true,
			], 200 );
		}

		// The route capability is site-wide, so only let users ignore issues on objects they can edit.
		if ( ! self::canEditObject( $issue->object_id, $issue->object_type ) ) { // @phpstan-ignore-line
			return new \WP_REST_Response( [ 'success' => false ], 403 );
		}

		$issue->is_ignored = true; // @phpstan-ignore-line
		$issue->save();

		return new \WP_REST_Response( [
			'success' => true,
		], 200 );
	}

	/**
	 * Check if the results have issue details (metadata).
	 *
	 * @since 4.8.6
	 *
	 * @param  array $results The results.
	 * @return bool           True if the results have issue details, false otherwise.
	 */
	private static function hasIssueDetails( $results ) {
		foreach ( $results as $result ) {
			if ( ! empty( $result->metadata ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Add focus keyword.
	 *
	 * @since   4.8.6
	 * @version 5.0.0.1 Preserves the existing additional keywords in the legacy column.
	 * @version 5.0.1 Added the `objectType` parameter so terms are written to the terms table.
	 * @version 5.0.1 The keyphrase parameter is normalized instead of indexed blind.
	 * @version 5.0.2 Authorize the request against the target object (edit_post/edit_term).
	 *
	 * @param  \WP_REST_Request  $request The REST Request
	 * @return \WP_REST_Response          The response.
	 */
	public static function addFocusKeyword( $request ) {
		$params = $request->get_params();

		if ( ! isset( $params['id'] ) || ! isset( $params['keyphrase'] ) ) {
			return new \WP_REST_Response( [
				'success' => false,
				'message' => 'Missing required parameters',
			], 400 );
		}

		$id         = (int) sanitize_text_field( $params['id'] );
		$objectType = ! empty( $params['objectType'] ) && 'term' === $params['objectType'] ? 'term' : 'post';
		$keyphrase  = self::normalizeKeyphrase( $params['keyphrase'] );
		if ( ! $keyphrase ) {
			return new \WP_REST_Response( [
				'success' => false,
				'message' => 'Invalid keyphrase.',
			], 400 );
		}

		// The route capability is site-wide, so only allow writing a keyphrase to objects the user can edit.
		if ( ! self::canEditObject( $id, $objectType ) ) {
			return new \WP_REST_Response( [
				'success' => false,
				'message' => 'You do not have permission to edit this object.', // Not displayed to the user.
			], 403 );
		}

		// A term row's ID is a term ID. Without this branch it would be handed to Post::getPost(),
		// which would create an aioseo_posts row keyed to a post that doesn't exist.
		if ( 'term' === $objectType ) {
			return self::addTermFocusKeyword( $id, $keyphrase );
		}

		$post = Post::getPost( $id );
		if ( ! $post ) {
			return new \WP_REST_Response( [
				'success' => false,
				'message' => 'Post not found',
			], 404 );
		}

		$post->focus_keyword = $keyphrase['word'];

		// Model decodes JSON fields to stdClass on read; round-trip to a nested array so we can
		// merge the focus_keyword sub-key without clobbering any existing `general` data.
		$truseo = $post->truseo;
		$truseo = empty( $truseo ) ? [] : (array) json_decode( wp_json_encode( $truseo ), true );
		$truseo['focus_keyword'] = [
			'score' => $keyphrase['score'],
			'items' => []
		];
		$post->truseo = $truseo;

		// Mirror into the legacy column, derived from the canonical ones so that any existing
		// additional keywords survive — assigning a bare `focus` array dropped them.
		$post->keyphrases = Post::getKeyphrasesFromKeywordColumns(
			$post->focus_keyword,
			$post->additional_keywords,
			$post->keyphrases,
			$post->truseo
		);
		$post->save();

		// Trigger a save post action to update the post and its SEO data.
		aioseo()->seoAnalysis->enqueuePostToScan( $id );

		return new \WP_REST_Response( [
			'success' => true,
		], 200 );
	}

	/**
	 * Normalizes the keyphrase parameter into a word/score pair.
	 *
	 * NOTE: On PHP 8, indexing a string with a string key is a TypeError, not a warning — so a
	 * client that sends `keyphrase` as a plain string took the whole request down instead of getting
	 * a 400. Both shapes are accepted here and anything else is rejected by the caller.
	 *
	 * @since 5.0.1
	 *
	 * @param  mixed      $keyphrase The raw keyphrase parameter.
	 * @return array|null            The word and score, or null when there is no usable word.
	 */
	private static function normalizeKeyphrase( $keyphrase ) {
		if ( is_scalar( $keyphrase ) ) {
			$keyphrase = [ 'word' => (string) $keyphrase ];
		}

		if ( is_object( $keyphrase ) ) {
			$keyphrase = (array) $keyphrase;
		}

		if ( ! is_array( $keyphrase ) ) {
			return null;
		}

		$word = isset( $keyphrase['word'] ) && is_scalar( $keyphrase['word'] )
			? sanitize_text_field( (string) $keyphrase['word'] )
			: '';

		if ( '' === $word ) {
			return null;
		}

		return [
			'word'  => $word,
			'score' => isset( $keyphrase['score'] ) && is_scalar( $keyphrase['score'] ) ? (int) $keyphrase['score'] : 0
		];
	}

	/**
	 * Sets a term's focus keyword.
	 *
	 * NOTE: No legacy `keyphrases` mirror — that column is post-only and the terms table has no
	 * equivalent.
	 *
	 * @since 5.0.1
	 *
	 * @param  int               $termId    The term ID.
	 * @param  array             $keyphrase A normalized keyphrase {@see normalizeKeyphrase}.
	 * @return \WP_REST_Response            The response.
	 */
	private static function addTermFocusKeyword( $termId, $keyphrase ) {
		$term = aioseo()->helpers->getTerm( $termId );
		if ( ! is_a( $term, 'WP_Term' ) ) {
			return new \WP_REST_Response( [
				'success' => false,
				'message' => 'Term not found',
			], 404 );
		}

		$taxonomy = get_taxonomy( $term->taxonomy );
		if (
			! $taxonomy ||
			! current_user_can( $taxonomy->cap->edit_terms ) ||
			! aioseo()->helpers->isTermTruSeoEligible( $termId )
		) {
			return new \WP_REST_Response( [
				'success' => false,
				'message' => 'You are not allowed to update this term.',
			], 403 );
		}

		$theTerm          = ProModels\Term::getTerm( $termId );
		$theTerm->term_id = $termId;

		$theTerm->focus_keyword = $keyphrase['word'];

		// Model decodes JSON fields to stdClass on read; round-trip to a nested array so the
		// focus_keyword sub-key merges without clobbering any existing `general` data.
		$truseo                  = $theTerm->truseo;
		$truseo                  = empty( $truseo ) ? [] : (array) json_decode( wp_json_encode( $truseo ), true );
		$truseo['focus_keyword'] = [
			'score' => $keyphrase['score'],
			'items' => []
		];
		$theTerm->truseo = $truseo;

		$theTerm->updated = gmdate( 'Y-m-d H:i:s' );
		if ( ! $theTerm->exists() ) {
			$theTerm->created = gmdate( 'Y-m-d H:i:s' );
		}

		$theTerm->save();

		aioseo()->seoAnalysis->enqueueTermToScan( $termId );

		return new \WP_REST_Response( [
			'success' => true,
		], 200 );
	}

	/**
	 * Get objects scan percent.
	 *
	 * @since 4.8.6
	 * @param  \WP_REST_Request  $request The REST Request
	 * @return \WP_REST_Response          The response.
	 */
	public static function getObjectsScanPercent( $request ) { //phpcs:ignore
		$total = aioseo()->seoAnalysis->getObjectsScanPercent();

		return new \WP_REST_Response( [
			'success' => true,
			'percent' => $total
		], 200 );
	}

	/**
	 * Authorizes the current user to act on a given object's SEO Analysis data.
	 *
	 * The route capability (aioseo_page_seo_analysis_settings) is site-wide, so an object's issues
	 * must only be read or mutated by users who can edit the post/term they belong to.
	 *
	 * @since 5.0.2
	 *
	 * @param  int    $objectId   The object ID.
	 * @param  string $objectType The object type ('post' or 'term').
	 * @return bool                Whether the current user can edit the object.
	 */
	private static function canEditObject( $objectId, $objectType ) {
		$objectCapability = 'term' === $objectType ? 'edit_term' : 'edit_post';

		return current_user_can( $objectCapability, (int) $objectId );
	}
}