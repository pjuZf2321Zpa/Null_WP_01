<?php
namespace AIOSEO\Plugin\Pro\Api;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AIOSEO\Plugin\Common\Api as CommonApi;
use AIOSEO\Plugin\Common\Models as CommonModels;
use AIOSEO\Plugin\Pro\Models as ProModels;

/**
 * Route class for the API.
 *
 * @since 4.0.0
 */
class PostsTerms extends CommonApi\PostsTerms {
	/**
	 * Update post settings.
	 *
	 * @since 4.0.0
	 *
	 * @param  \WP_REST_Request  $request The REST Request
	 * @return \WP_REST_Response          The response.
	 */
	public static function updatePosts( $request ) {
		$body    = $request->get_json_params();
		$postId  = ! empty( $body['id'] ) ? intval( $body['id'] ) : null;
		$context = ! empty( $body['context'] ) ? sanitize_text_field( $body['context'] ) : 'post';

		if ( ! $postId ) {
			return new \WP_REST_Response( [
				'success' => false,
				'message' => 'Post ID is missing.'
			], 400 );
		}

		if ( ! aioseo()->access->hasCapability( 'aioseo_page_general_settings' ) || ! current_user_can( 'edit_post', $postId ) ) {
			return new \WP_REST_Response( [
				'success' => false,
				'message' => 'You are not allowed to update the post settings.'
			], 403 );
		}

		$body['id']                  = $postId;
		$body['context']             = $context;
		$body['title']               = ! empty( $body['title'] ) ? sanitize_text_field( $body['title'] ) : null;
		$body['description']         = ! empty( $body['description'] ) ? sanitize_text_field( $body['description'] ) : null;
		$body['keywords']            = ! empty( $body['keywords'] ) ? aioseo()->helpers->sanitize( $body['keywords'] ) : null;
		$body['og_title']            = ! empty( $body['og_title'] ) ? sanitize_text_field( $body['og_title'] ) : null;
		$body['og_description']      = ! empty( $body['og_description'] ) ? sanitize_text_field( $body['og_description'] ) : null;
		$body['og_article_section']  = ! empty( $body['og_article_section'] ) ? sanitize_text_field( $body['og_article_section'] ) : null;
		$body['og_article_tags']     = ! empty( $body['og_article_tags'] ) ? aioseo()->helpers->sanitize( $body['og_article_tags'] ) : null;
		$body['twitter_title']       = ! empty( $body['twitter_title'] ) ? sanitize_text_field( $body['twitter_title'] ) : null;
		$body['twitter_description'] = ! empty( $body['twitter_description'] ) ? sanitize_text_field( $body['twitter_description'] ) : null;

		$saveStatus = ( 'post' === $context ) ? CommonModels\Post::savePost( $postId, $body ) : ProModels\Term::saveTerm( $postId, $body );

		if ( ! empty( $saveStatus ) ) {
			return new \WP_REST_Response( [
				'success' => false,
				'message' => 'Failed to update the post data.'
			], 500 );
		}

		$response = new \WP_REST_Response( [
			'success' => true,
			'posts'   => $postId
		], 200 );

		return Api::addonsApi( $request, $response, '\\Api\\PostsTerms', 'updatePosts' );
	}

	/**
	 * Update post settings from posts list AIOSEO Details column.
	 *
	 * Extends the Common implementation to enqueue the post for an SEO Analyzer
	 * re-scan, clearing existing site audit issues and resetting the scan date.
	 *
	 * @since 4.9.7
	 *
	 * @param  \WP_REST_Request  $request The REST Request
	 * @return \WP_REST_Response          The response.
	 */
	public static function updatePostDetailsColumn( $request ) {
		$response = parent::updatePostDetailsColumn( $request );

		if ( 200 === $response->get_status() ) {
			$body   = $request->get_json_params();
			$postId = ! empty( $body['postId'] ) ? intval( $body['postId'] ) : null;
			if ( ! empty( $postId ) ) {
				aioseo()->seoAnalysis->enqueuePostToScan( $postId );
			}
		}

		return $response;
	}

	/**
	 * Load term settings from Term screen.
	 *
	 * @since 4.5.5
	 *
	 * @param  \WP_REST_Request  $request  The REST Request
	 * @return \WP_REST_Response $response The response.
	 */
	public static function loadTermDetailsColumn( $request ) {
		$body   = $request->get_json_params();
		$ids = ! empty( $body['ids'] ) ? (array) $body['ids'] : [];

		if ( ! $ids ) {
			return new \WP_REST_Response( [
				'success' => false,
				'message' => 'Term IDs are missing.'
			], 400 );
		}

		// phpcs:disable Squiz.NamingConventions.ValidVariableName
		global $wp_query;
		$isTax            = $wp_query->is_tax;
		$wp_query->is_tax = true;
		// phpcs:disable Squiz.NamingConventions.ValidVariableName

		$terms = [];
		foreach ( $ids as $termId ) {
			$term = aioseo()->helpers->getTerm( $termId );

			$aioseoTerm    = ProModels\Term::getTerm( $termId );
			$hasTruseoData = ! empty( $aioseoTerm->truseo );

			$data = [
				'id'                => $termId,
				'taxonomy'          => $term->taxonomy,
				'titleParsed'       => aioseo()->meta->title->getTermTitle( aioseo()->helpers->getTerm( $termId ) ),
				'descriptionParsed' => aioseo()->meta->description->getTermDescription( aioseo()->helpers->getTerm( $termId ) ),
				'hasTruseoData'     => $hasTruseoData,
				// Mirrors what the column localizes at render time, so a row added or quick-edited
				// after page load picks up its score badge without a reload.
				'value'             => ! empty( $aioseoTerm->seo_score ) ? (int) $aioseoTerm->seo_score : 0,
				'showScore'         => aioseo()->helpers->isTermTruSeoAnalyzable( $termId )
			];

			// Mirrors the post payload: the batch scanner only receives a payload for rows that still
			// need scoring, and skips any row without one. A term with no description has nothing to
			// analyse — the same condition that hides its badge above, so the two cannot disagree.
			if (
				! $hasTruseoData &&
				aioseo()->helpers->isTermTruSeoAnalyzable( $termId )
			) {
				$data['truseoData'] = self::getTermAnalysisData( $termId, $term, $aioseoTerm );
			}

			$terms[] = $data;
		}

		$wp_query->is_tax = $isTax; // phpcs:ignore Squiz.NamingConventions.ValidVariableName

		$response = new \WP_REST_Response( [
			'success' => true,
			'terms'   => $terms
		], 200 );

		return $response;
	}

	/**
	 * Returns the data the batch scanner needs to analyse a term from a list screen.
	 *
	 * NOTE: The rendered title/description are used rather than the raw templates so a list score
	 * matches what the term editor shows.
	 *
	 * @since 5.0.1
	 *
	 * @param  int               $termId     The term ID.
	 * @param  \WP_Term          $term       The term.
	 * @param  ProModels\Term    $aioseoTerm The AIOSEO term.
	 * @return array                         The analysis data.
	 */
	private static function getTermAnalysisData( $termId, $term, $aioseoTerm ) {
		$permalink   = get_term_link( $termId );
		$additional  = [];
		$keywordList = ! empty( $aioseoTerm->additional_keywords ) ? $aioseoTerm->additional_keywords : [];
		foreach ( (array) $keywordList as $keyword ) {
			// Entries are `{ word, score }` — cast so a decoded JSON object and an array read alike.
			$keyword = (array) $keyword;
			$word    = isset( $keyword['word'] ) && is_scalar( $keyword['word'] ) ? trim( (string) $keyword['word'] ) : '';
			if ( '' !== $word ) {
				$additional[] = [
					'word'     => $word,
					// Synonyms live only on the keyphrases column, which terms do not have.
					'synonyms' => ''
				];
			}
		}

		return [
			'termType'           => $term->taxonomy,
			// The description is the only body content a term has.
			'content'            => $term->description,
			'aioseoTitle'        => aioseo()->meta->title->getTermTitle( $term ),
			'description'        => aioseo()->meta->description->getTermDescription( $term ),
			// The term name is the archive's visible heading, so it stands in for the post title.
			'postTitle'          => $term->name,
			'slug'               => $term->slug,
			'permalink'          => is_wp_error( $permalink ) ? '' : $permalink,
			'focusKeyword'       => ! empty( $aioseoTerm->focus_keyword ) ? $aioseoTerm->focus_keyword : '',
			'additionalKeywords' => $additional,
			'truseoLocale'       => ! empty( $aioseoTerm->truseo_locale ) ? $aioseoTerm->truseo_locale : '',
			// Mirrors what the term editor sends the worker. Without these the batch scanner builds
			// the post assessor instead and persists a score the editor would never show.
			'useTaxonomy'        => true,
			'customAnalysisType' => self::getTermCustomAnalysisType( $term->taxonomy ),
			'contentNouns'       => aioseo()->helpers->getTaxonomyContentNouns( $term->taxonomy ),
			'locale'             => get_locale()
		];
	}

	/**
	 * Returns the custom analysis type for a term's taxonomy.
	 *
	 * NOTE: Mirrors `getCustomAnalysisType()` in `src/vue/plugins/tru-seo/utils/customAnalysisType.js`.
	 * The two have to agree, or a list score will not match the editor's.
	 *
	 * @since 5.0.1
	 *
	 * @param  string $taxonomy The taxonomy name.
	 * @return string           The custom analysis type, or an empty string when there is none.
	 */
	private static function getTermCustomAnalysisType( $taxonomy ) {
		if ( ! aioseo()->helpers->isWooCommerceActive() ) {
			return '';
		}

		return in_array( $taxonomy, [ 'product_cat', 'product_tag' ], true ) ? 'collectionPage' : '';
	}

	/**
	 * Updates a term's TruSEO analysis results.
	 *
	 * @since 5.0.1
	 *
	 * @param  \WP_REST_Request  $request  The REST Request.
	 * @return \WP_REST_Response $response The response.
	 */
	public static function updateTermTruseo( $request ) {
		$body   = $request->get_json_params();
		$termId = ! empty( $request->get_param( 'termId' ) ) ? intval( $request->get_param( 'termId' ) ) : null;

		if ( ! $termId ) {
			return new \WP_REST_Response( [
				'success' => false,
				'message' => 'Term ID is missing.'
			], 400 );
		}

		$term = aioseo()->helpers->getTerm( $termId );
		if ( ! is_a( $term, 'WP_Term' ) ) {
			return new \WP_REST_Response( [
				'success' => false,
				'message' => 'Term not found.'
			], 404 );
		}

		$taxonomy = get_taxonomy( $term->taxonomy );
		if (
			! aioseo()->access->hasCapability( 'aioseo_page_analysis' ) ||
			! $taxonomy ||
			! current_user_can( $taxonomy->cap->edit_terms )
		) {
			return new \WP_REST_Response( [
				'success' => false,
				'message' => 'You are not allowed to update the term settings.'
			], 403 );
		}

		$theTerm          = ProModels\Term::getTerm( $termId );
		$theTerm->term_id = $termId;

		if ( ! empty( $body['truseo'] ) ) {
			$theTerm->truseo = wp_json_encode( CommonModels\Post::sanitizeTruseo( $body['truseo'] ) );
		}

		if ( isset( $body['seo_score'] ) ) {
			$theTerm->seo_score = sanitize_text_field( $body['seo_score'] );
		}

		if ( array_key_exists( 'focus_keyword', $body ) ) {
			$focusKeyword           = is_string( $body['focus_keyword'] ) ? sanitize_text_field( $body['focus_keyword'] ) : '';
			$theTerm->focus_keyword = '' !== $focusKeyword ? $focusKeyword : null;
		}

		// Keyed on presence, not truthiness: an empty array means the user removed every additional
		// keyword, and `! empty()` would leave the deleted set in place.
		if ( array_key_exists( 'additional_keywords', $body ) ) {
			$additionalKeywords           = is_array( $body['additional_keywords'] )
				? CommonModels\Post::sanitizeAdditionalKeywords( $body['additional_keywords'] )
				: [];
			$theTerm->additional_keywords = ! empty( $additionalKeywords ) ? wp_json_encode( $additionalKeywords ) : null;
		}

		if ( isset( $body['truseo_locale'] ) ) {
			$theTerm->truseo_locale = ! empty( $body['truseo_locale'] ) ? sanitize_text_field( $body['truseo_locale'] ) : null;
		}

		$theTerm->updated = gmdate( 'Y-m-d H:i:s' );
		if ( ! $theTerm->exists() ) {
			$theTerm->created = gmdate( 'Y-m-d H:i:s' );
		}

		$theTerm->save();

		if ( ! empty( $theTerm->lastError ) ) {
			return new \WP_REST_Response( [
				'success' => false,
				'message' => 'Failed to update the term data.'
			], 500 );
		}

		return new \WP_REST_Response( [
			'success'   => true,
			'seo_score' => (int) $theTerm->seo_score
		], 200 );
	}

	/**
	 * Update term settings from Term screen.
	 *
	 * @since 4.0.0
	 *
	 * @param  \WP_REST_Request  $request  The REST Request
	 * @return \WP_REST_Response $response The response.
	 */
	public static function updateTermDetailsColumn( $request ) {
		$body   = $request->get_json_params();
		$termId = ! empty( $body['termId'] ) ? intval( $body['termId'] ) : null;

		if ( ! $termId ) {
			return new \WP_REST_Response( [
				'success' => false,
				'message' => 'Term ID is missing.'
			], 400 );
		}

		if ( ! aioseo()->access->hasCapability( 'aioseo_page_general_settings' ) || ! current_user_can( 'edit_term', $termId ) ) {
			return new \WP_REST_Response( [
				'success' => false,
				'message' => 'You are not allowed to update the term settings.'
			], 403 );
		}

		$theTerm = aioseo()->core->db
			->start( 'aioseo_terms' )
			->where( 'term_id', $termId )
			->run()
			->model( 'AIOSEO\\Plugin\\Pro\\Models\\Term' );

		if ( $theTerm->exists() ) {
			$theTerm->title       = ! empty( $body['title'] ) ? sanitize_text_field( $body['title'] ) : '';
			$theTerm->description = ! empty( $body['description'] ) ? sanitize_text_field( $body['description'] ) : '';
			$theTerm->updated     = gmdate( 'Y-m-d H:i:s' );
		} else {
			$theTerm->term_id     = $termId;
			$theTerm->title       = ! empty( $body['title'] ) ? sanitize_text_field( $body['title'] ) : '';
			$theTerm->description = ! empty( $body['description'] ) ? sanitize_text_field( $body['description'] ) : '';
			$theTerm->created     = gmdate( 'Y-m-d H:i:s' );
			$theTerm->updated     = gmdate( 'Y-m-d H:i:s' );
		}

		$theTerm->save();

		if ( ! empty( $theTerm->lastError ) ) {
			return new \WP_REST_Response( [
				'success' => false,
				'message' => 'Failed to update the term data.'
			], 500 );
		}

		// Trigger the action hook so we can create a revision.
		do_action( 'aioseo_insert_term', $termId );

		aioseo()->seoAnalysis->enqueueTermToScan( $termId );

		global $wp_query;
		$isTax            = $wp_query->is_tax;
		$wp_query->is_tax = true;

		$response = new \WP_REST_Response( [
			'success'         => true,
			'terms'           => $termId,
			'title'           => aioseo()->meta->title->getTermTitle( aioseo()->helpers->getTerm( $termId ) ),
			'description'     => aioseo()->meta->description->getTermDescription( aioseo()->helpers->getTerm( $termId ) ),
			'showTitle'       => apply_filters( 'aioseo_details_column_term_show_title', true, $termId ),
			'showDescription' => apply_filters( 'aioseo_details_column_term_show_desc', true, $termId )
		], 200 );

		$wp_query->is_tax = $isTax;

		return $response;
	}
}