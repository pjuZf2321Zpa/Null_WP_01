<?php
namespace AIOSEO\Plugin\Pro\Api;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * TruSeo API class.
 *
 * Provides REST API endpoints for real-time TruSEO analysis in the post editor.
 *
 * @since 5.0.0
 */
class TruSeo {
	/**
	 * Checks for keyword cannibalization.
	 *
	 * Queries the database to find other content targeting the same focus keyphrase.
	 *
	 * @since   5.0.0
	 * @version 5.0.1 Added the `objectType` parameter; terms are searched alongside posts.
	 *
	 * @param  \WP_REST_Request  $request The REST Request.
	 * @return \WP_REST_Response          The response.
	 */
	public static function checkKeywordCannibalization( $request ) {
		$body       = $request->get_json_params();
		$objectId   = ! empty( $body['postId'] ) ? intval( $body['postId'] ) : 0;
		$objectType = ! empty( $body['objectType'] ) && 'term' === $body['objectType'] ? 'term' : 'post';
		$keyphrase  = ! empty( $body['keyphrase'] ) ? sanitize_text_field( $body['keyphrase'] ) : '';

		if ( empty( $objectId ) ) {
			return new \WP_REST_Response( [
				'success' => false,
				'message' => 'No object ID was provided.'
			], 400 );
		}

		if ( empty( $keyphrase ) ) {
			return new \WP_REST_Response( [
				'success' => false,
				'message' => 'No keyphrase was provided.'
			], 400 );
		}

		if ( ! self::isCannibalizationEligible( $objectId, $objectType ) ) {
			return new \WP_REST_Response( [
				'success'            => true,
				'cannibalizingPosts' => []
			] );
		}

		// Both object types are searched whichever one is being edited: a category and a post
		// competing for the same keyword cannibalize each other just as two posts would.
		$cannibalizing = array_merge(
			self::getCannibalizingPosts( $keyphrase, 'post' === $objectType ? $objectId : 0 ),
			self::getCannibalizingTerms( $keyphrase, 'term' === $objectType ? $objectId : 0 )
		);

		return new \WP_REST_Response( [
			'success'            => true,
			'cannibalizingPosts' => array_slice( $cannibalizing, 0, 10 )
		] );
	}

	/**
	 * Returns whether the object being edited should be checked for keyword cannibalization.
	 *
	 * @since 5.0.1
	 *
	 * @param  int    $objectId   The object ID.
	 * @param  string $objectType Either 'post' or 'term'.
	 * @return bool               Whether the object is eligible.
	 */
	private static function isCannibalizationEligible( $objectId, $objectType ) {
		if ( 'term' === $objectType ) {
			return aioseo()->helpers->isTermTruSeoEligible( $objectId );
		}

		return ! aioseo()->helpers->isWooCommercePage( $objectId ) &&
			! aioseo()->helpers->isStaticPostsPage( $objectId ) &&
			aioseo()->helpers->isTruSeoEligible( $objectId );
	}

	/**
	 * Returns the published posts targeting the given keyphrase.
	 *
	 * @since 5.0.1
	 *
	 * @param  string $keyphrase The focus keyphrase.
	 * @param  int    $excludeId The post ID to exclude, if any.
	 * @return array             The matching posts.
	 */
	private static function getCannibalizingPosts( $keyphrase, $excludeId = 0 ) {
		$query = aioseo()->core->db->start( 'aioseo_posts as ap' )
			->select( 'p.ID, p.post_title' )
			->join( 'posts as p', 'p.ID = ap.post_id' )
			->where( 'ap.focus_keyword', $keyphrase )
			->whereRaw( "p.post_status = 'publish'" )
			->whereRaw( "p.post_type NOT IN ('revision', 'attachment')" )
			->limit( 10 );

		if ( $excludeId ) {
			$query->where( 'p.ID !=', $excludeId );
		}

		$posts = $query->run()->result();
		if ( empty( $posts ) ) {
			return [];
		}

		return array_map( function( $post ) {
			return [
				'id'         => (int) $post->ID,
				// Titles are stored with entities encoded, so a title containing "&" would otherwise
				// render as "&amp;" inside the assessment's plain-text result.
				'title'      => aioseo()->helpers->decodeHtmlEntities( (string) $post->post_title ),
				'editLink'   => admin_url( 'post.php?post=' . (int) $post->ID . '&action=edit' ),
				'objectType' => 'post'
			];
		}, $posts );
	}

	/**
	 * Returns the terms targeting the given keyphrase.
	 *
	 * NOTE: Scoped to TruSEO-eligible taxonomies — a term the feature never analyses cannot be
	 * competing for the keyword on purpose.
	 *
	 * @since 5.0.1
	 *
	 * @param  string $keyphrase The focus keyphrase.
	 * @param  int    $excludeId The term ID to exclude, if any.
	 * @return array             The matching terms.
	 */
	private static function getCannibalizingTerms( $keyphrase, $excludeId = 0 ) {
		$eligibleTaxonomies = aioseo()->helpers->getTruSeoEligibleTaxonomies();
		if ( empty( $eligibleTaxonomies ) ) {
			return [];
		}

		$query = aioseo()->core->db->start( 'aioseo_terms as at' )
			->select( 't.term_id, t.name, tt.taxonomy' )
			->join( 'terms as t', 't.term_id = at.term_id' )
			->join( 'term_taxonomy as tt', 'tt.term_id = t.term_id' )
			->where( 'at.focus_keyword', $keyphrase )
			->whereIn( 'tt.taxonomy', $eligibleTaxonomies )
			->limit( 10 );

		if ( $excludeId ) {
			$query->where( 't.term_id !=', $excludeId );
		}

		$terms = $query->run()->result();
		if ( empty( $terms ) ) {
			return [];
		}

		// A term_id can carry more than one term_taxonomy row (legacy shared terms), which would
		// list the same term twice. Deduplicated here rather than with GROUP BY so the query never
		// depends on the server inferring `tt.taxonomy`'s functional dependency on the grouped
		// `t.term_id` — MySQL 8 accepts it, but that inference varies across versions and MariaDB.
		$cannibalizing = [];
		foreach ( $terms as $term ) {
			$termId = (int) $term->term_id;
			if ( isset( $cannibalizing[ $termId ] ) ) {
				continue;
			}

			$editLink = get_edit_term_link( $termId, $term->taxonomy );

			$cannibalizing[ $termId ] = [
				'id'         => $termId,
				'title'      => aioseo()->helpers->decodeHtmlEntities( (string) $term->name ),
				'editLink'   => is_string( $editLink ) ? $editLink : '',
				'objectType' => 'term'
			];
		}

		return array_values( $cannibalizing );
	}
}