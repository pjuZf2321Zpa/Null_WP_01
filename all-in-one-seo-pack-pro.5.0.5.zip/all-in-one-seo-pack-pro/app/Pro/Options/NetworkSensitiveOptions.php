<?php
namespace AIOSEO\Plugin\Pro\Options;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AIOSEO\Plugin\Common\Options as CommonOptions;

/**
 * Class that holds network-wide sensitive options for AIOSEO Pro.
 *
 * Extends the Common SensitiveOptions with network-wide storage
 * using get_site_option/update_site_option so that values are
 * accessible across all sites in a multisite network.
 *
 * @since 4.9.6
 */
class NetworkSensitiveOptions extends CommonOptions\SensitiveOptions {
	/**
	 * The option name used for DB storage.
	 *
	 * @since 4.9.6
	 *
	 * @var string
	 */
	protected $optionsName = 'aioseo_network_sensitive_options';

	/**
	 * The list of allowed keys.
	 *
	 * @since 4.9.6
	 *
	 * @var array
	 */
	protected $allowedKeys = [
		'networkLicenseKey'
	];

	/**
	 * Reads the raw option values from the database using get_site_option.
	 *
	 * @since 4.9.6
	 *
	 * @return array The decoded option values.
	 */
	protected function getFromDb() {
		$dbValues = json_decode( (string) get_site_option( $this->optionsName, '' ), true );

		return is_array( $dbValues ) ? $dbValues : [];
	}

	/**
	 * Writes the option values to the database using update_site_option.
	 *
	 * @since 4.9.6
	 *
	 * @param  array $values The values to save.
	 * @return void
	 */
	protected function saveToDb( $values ) {
		update_site_option( $this->optionsName, wp_json_encode( $values ) );
	}
}