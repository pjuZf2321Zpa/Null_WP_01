<?php
namespace AIOSEO\Plugin\Pro\Options;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AIOSEO\Plugin\Common\Options as CommonOptions;

/**
 * Class that holds all sensitive options for AIOSEO Pro.
 *
 * Extends the Common SensitiveOptions with Pro-specific keys.
 *
 * @since 4.9.6
 */
class SensitiveOptions extends CommonOptions\SensitiveOptions {
	/**
	 * Pro-specific allowed keys.
	 *
	 * @since 4.9.6
	 *
	 * @var array
	 */
	private $proKeys = [
		'licenseKey'
	];

	/**
	 * Class constructor.
	 *
	 * @since 4.9.6
	 */
	public function __construct() {
		$this->allowedKeys = array_merge( $this->allowedKeys, $this->proKeys );

		parent::__construct();
	}
}