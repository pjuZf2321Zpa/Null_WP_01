<?php
namespace AIOSEO\Plugin\Pro\ImportExport\YoastSeo;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AIOSEO\Plugin\Pro\Models;

// phpcs:disable WordPress.Arrays.ArrayDeclarationSpacing.AssociativeArrayFound

/**
 * Imports the term meta from Yoast SEO.
 *
 * @since 4.0.0
 */
class TermMeta {
	/**
	 * The term action name.
	 *
	 * @since 4.4.3
	 *
	 * @var string
	 */
	private $termActionName = 'aioseo_import_term_meta_yoast_seo';

	/**
	 * Class constructor.
	 *
	 * @since 4.4.3
	 *
	 */
	public function __construct() {
		add_action( $this->termActionName, [ $this, 'importTermMeta' ] );
	}

	/**
	 * Schedules the term meta import.
	 *
	 * @since 4.0.0
	 *
	 * @return void
	 */
	public function scheduleImport() {
		try {
			if ( as_next_scheduled_action( $this->termActionName ) ) {
				return;
			}

			if ( ! aioseo()->core->cache->get( 'import_term_meta_yoast_seo' ) ) {
				aioseo()->core->cache->update( 'import_term_meta_yoast_seo', time(), WEEK_IN_SECONDS );
			}

			as_schedule_single_action( time(), $this->termActionName, [], 'aioseo' );
		} catch ( \Exception $e ) {
			// Do nothing.
		}
	}

	/**
	 * Imports the term meta.
	 *
	 * @since   4.0.0
	 * @version 5.0.5 Read from the wpseo_taxonomy_meta option instead of the yoast_indexable table.
	 *
	 * @return void
	 */
	public function importTermMeta() {
		$yoastTaxMeta = get_option( 'wpseo_taxonomy_meta', [] );
		if ( empty( $yoastTaxMeta ) || ! is_array( $yoastTaxMeta ) ) {
			aioseo()->core->cache->delete( 'import_term_meta_yoast_seo' );

			return;
		}

		$cachedStart = aioseo()->core->cache->get( 'import_term_meta_yoast_seo' );
		if ( empty( $cachedStart ) ) {
			// scheduleImport() primes the cache, so a missing value means the action fired out-of-band.
			// Bail rather than treating the entire aioseo_terms table as "already imported".
			return;
		}

		$publicTaxonomies = aioseo()->helpers->getPublicTaxonomies( true );
		$yoastHelpers     = aioseo()->importExport->yoastSeo->helpers;
		$termsPerAction   = 100;
		$timeStarted      = gmdate( 'Y-m-d H:i:s', $cachedStart );

		// Bulk-load term IDs already processed in this import run to avoid per-term DB queries.
		$imported = aioseo()->core->db
			->start( 'aioseo_terms' )
			->select( 'term_id' )
			->where( 'updated >=', $timeStarted )
			->run()
			->result();

		$importedIds = array_flip( wp_list_pluck( $imported ?: [], 'term_id' ) );
		$count       = 0;

		foreach ( $yoastTaxMeta as $taxonomy => $termsMeta ) {
			if ( ! in_array( $taxonomy, $publicTaxonomies, true ) ) {
				continue;
			}

			if ( ! is_array( $termsMeta ) ) {
				continue;
			}

			foreach ( $termsMeta as $termId => $yoastMeta ) {
				if ( ! is_numeric( $termId ) || ! is_array( $yoastMeta ) ) {
					continue;
				}

				$termId = (int) $termId;

				if ( isset( $importedIds[ $termId ] ) ) {
					continue;
				}

				$meta = [
					'term_id'                  => $termId,
					'robots_default'           => true,
					'robots_noindex'           => false,
					'robots_nofollow'          => false,
					'robots_noarchive'         => false,
					'robots_noimageindex'      => false,
					'robots_nosnippet'         => false,
					'title'                    => '',
					'description'              => '',
					'og_title'                 => '',
					'og_description'           => '',
					'og_image_custom_url'      => '',
					'og_image_type'            => 'default',
					'twitter_use_og'           => true,
					'twitter_title'            => '',
					'twitter_description'      => '',
					'twitter_image_custom_url' => '',
					'twitter_image_type'       => 'default'
				];

				// wpseo_noindex is a string ("noindex"/"index"/"default"), not a boolean.
				// Anything outside that vocabulary is treated as no-op so malformed data can't silently flip robots flags.
				$noindexValue = isset( $yoastMeta['wpseo_noindex'] ) ? $yoastHelpers->sanitizeStringValue( $yoastMeta['wpseo_noindex'] ) : null;
				if ( in_array( $noindexValue, [ 'noindex', 'index' ], true ) ) {
					if ( 'noindex' === $noindexValue ) {
						$meta['robots_noindex'] = true;
					}
					$meta['robots_default'] = false;
				}

				$textFields = [
					'wpseo_title'                 => 'title',
					'wpseo_desc'                  => 'description',
					'wpseo_opengraph-title'       => 'og_title',
					'wpseo_opengraph-description' => 'og_description',
					'wpseo_twitter-title'         => 'twitter_title',
					'wpseo_twitter-description'   => 'twitter_description'
				];

				foreach ( $textFields as $yoastKey => $aioseoKey ) {
					$rawValue = $yoastHelpers->sanitizeStringValue( $yoastMeta[ $yoastKey ] ?? null );
					if ( null === $rawValue || '' === $rawValue ) {
						continue;
					}

					$value              = $yoastHelpers->macrosToSmartTags( $rawValue, null, 'term' );
					$meta[ $aioseoKey ] = esc_html( wp_strip_all_tags( $value ) );
				}

				$canonical = $yoastHelpers->sanitizeStringValue( $yoastMeta['wpseo_canonical'] ?? null );
				if ( null !== $canonical && '' !== $canonical ) {
					$meta['canonical_url'] = esc_url( $canonical );
				}

				$ogImage = $yoastHelpers->sanitizeStringValue( $yoastMeta['wpseo_opengraph-image'] ?? null );
				if ( null !== $ogImage && '' !== $ogImage ) {
					$meta['og_image_type']       = 'custom_image';
					$meta['og_image_custom_url'] = esc_url( $ogImage );
				}

				$twitterImage = $yoastHelpers->sanitizeStringValue( $yoastMeta['wpseo_twitter-image'] ?? null );
				if ( null !== $twitterImage && '' !== $twitterImage ) {
					$meta['twitter_use_og']           = false;
					$meta['twitter_image_type']       = 'custom_image';
					$meta['twitter_image_custom_url'] = esc_url( $twitterImage );
				}

				$aioseoTerm = Models\Term::getTerm( $termId );
				$aioseoTerm->set( $meta );
				$aioseoTerm->save();

				$count++;
				if ( $count >= $termsPerAction ) {
					break 2;
				}
			}
		}

		if ( $count >= $termsPerAction ) {
			try {
				as_schedule_single_action( time() + 30, $this->termActionName, [], 'aioseo' );
			} catch ( \Exception $e ) {
				// Do nothing.
			}
		} else {
			aioseo()->core->cache->delete( 'import_term_meta_yoast_seo' );
		}
	}
}