<?php
namespace AIOSEO\Plugin\Pro\Llms;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use AIOSEO\Plugin\Common\Llms\Llms as CommonLlms;
use League\HTMLToMarkdown\Converter\TableConverter;
use League\HTMLToMarkdown\HtmlConverter;

/**
 * Handles the LLMS-full.txt generation by creating a static file that contains more data than the LLMS.txt file.
 *
 * @since 4.8.8
 */
class Llms extends CommonLlms {
	/**
	 * Stands in for a backtick from the content until the Markdown is escaped, so it can't be read as a code delimiter.
	 *
	 * @since 5.0.3
	 *
	 * @var string
	 */
	const BACKTICK = "\u{E001}";

	/**
	 * Marks a code delimiter the converter emitted. A control character, as no entity decodes to one.
	 *
	 * @since 5.0.3
	 *
	 * @var string
	 */
	const DELIMITER = "\x01";

	/**
	 * The content renderer instance.
	 *
	 * @since 4.8.8
	 *
	 * @var \AIOSEO\Plugin\Pro\Llms\ContentRenderer
	 */
	private $contentRenderer;

	/**
	 * Class constructor.
	 *
	 * @since 4.8.8
	 *
	 * @return void
	 */
	public function __construct() {
		parent::__construct();

		// Initialize the content renderer.
		$this->contentRenderer = new ContentRenderer();

		// Use 'init' hook with high priority to run before redirects plugin
		add_action( 'init', [ $this, 'checkIfPageIsMd' ], 1 );

		add_action( 'admin_init', [ $this, 'scheduleRecurrentGenerationForLlmsFullTxt' ] );

		add_action( 'wp_insert_post', [ $this, 'scheduleSingleGenerationForLlmsFullTxt' ] );
		add_action( 'edited_term', [ $this, 'scheduleSingleGenerationForLlmsFullTxt' ] );

		add_action( $this->llmsFullTxtRecurrentAction, [ $this, 'generateLlmsFullTxt' ] );
		add_action( $this->llmsFullTxtSingleAction, [ $this, 'generateLlmsFullTxt' ] );
	}

	/**
	 * Schedules the LLMS-full.txt file generation.
	 *
	 * @since 4.8.8
	 *
	 * @return void
	 */
	public function scheduleRecurrentGenerationForLlmsFullTxt() {
		// llms-full.txt is independent of the master llms.txt toggle; only enableFull gates it.
		if (
			! aioseo()->options->sitemap->llms->enableFull ||
			aioseo()->actionScheduler->isScheduled( $this->llmsFullTxtRecurrentAction )
		) {
			return;
		}

		aioseo()->actionScheduler->scheduleRecurrent( $this->llmsFullTxtRecurrentAction, 10, DAY_IN_SECONDS );
	}

	/**
	 * Schedules a single LLMS-full.txt file generation.
	 *
	 * @since 4.8.8
	 *
	 * @return void
	 */
	public function scheduleSingleGenerationForLlmsFullTxt() {
		// llms-full.txt is independent of the master llms.txt toggle; only enableFull gates it.
		if (
			! aioseo()->options->sitemap->llms->enableFull ||
			aioseo()->actionScheduler->isScheduled( $this->llmsFullTxtSingleAction )
		) {
			return;
		}

		aioseo()->actionScheduler->scheduleSingle( $this->llmsFullTxtSingleAction, 10 );
	}

	/**
	 * Schedules a single regeneration of every static LLMs file.
	 *
	 * @since 5.0.3
	 *
	 * @return void
	 */
	public function scheduleRegeneration() {
		parent::scheduleRegeneration();

		$this->scheduleSingleGenerationForLlmsFullTxt();
	}

	/**
	 * Generates the LLMS-full.txt file.
	 *
	 * @since 4.8.8
	 *
	 * @return void
	 */
	public function generateLlmsFullTxt() {
		// Disabled: remove the static file and stop. llms-full.txt is independent of the master
		// llms.txt toggle. Read via all() (empty() on the magic option property misreports - the
		// options __isset() returns value-truthiness).
		$sitemap  = aioseo()->options->sitemap;
		$llmsOpts = $sitemap ? $sitemap->llms->all() : [];
		if ( empty( $llmsOpts['enableFull'] ) ) {
			$this->cleanupLlmsFullTxt();

			return;
		}

		$fs   = aioseo()->core->fs;
		$file = $this->getFilePath( true );

		$this->setSiteInfo();
		$content = $this->generateContent();

		// Add UTF-8 BOM to help browsers recognize the encoding
		$content = "\xEF\xBB\xBF" . $content;
		$fs->putContents( $file, $content );
	}

	/**
	 * Generates the LLMS-full.txt file content in a markdown format.
	 *
	 * @since 4.8.8
	 *
	 * @return string
	 */
	private function generateContent() {
		$this->setSiteInfo();

		$content  = $this->getHeader( true );
		$content .= $this->getContent( true );

		return $content;
	}

	/**
	 * Gets the post content section of the llms.txt file.
	 *
	 * @since 4.8.8
	 *
	 * @param  \WP_Post $post     The post object.
	 * @param  bool     $llmsFull Whether to include the llms-full.txt file.
	 * @return string             The content of the llms.txt file.
	 */
	protected function getPostContent( $post, $llmsFull = false ) {
		if ( ! $llmsFull ) {
			return parent::getPostContent( $post );
		}

		return $this->getFullPostContent( $post );
	}

	/**
	 * Gets the term content section of the llms.txt file.
	 *
	 * @since 4.9.3
	 *
	 * @param  \WP_Term $term     The term object.
	 * @param  string   $taxonomy The taxonomy name.
	 * @param  bool     $llmsFull Whether to include the llms-full.txt file.
	 * @return string             The content of the llms.txt file.
	 */
	protected function getTermContent( $term, $taxonomy, $llmsFull = false ) {
		if ( ! $llmsFull ) {
			return parent::getTermContent( $term, $taxonomy );
		}

		return $this->getFullTermContent( $term, $taxonomy );
	}

	/**
	 * Gets the full content for a single term in markdown format.
	 *
	 * @since   4.9.3
	 * @version 5.0.5 Sanitize the link text via {@see parent::sanitizeMarkdownLinkText()}.
	 *
	 * @param  \WP_Term $term     The term object.
	 * @param  string   $taxonomy The taxonomy name.
	 * @return string             The content of the llms.txt file.
	 */
	protected function getFullTermContent( $term, $taxonomy ) {
		$title       = apply_filters( 'aioseo_llms_term_title', $term->name, $term );
		$linkText    = $this->sanitizeMarkdownLinkText( aioseo()->helpers->decodeHtmlEntities( $title ) );
		$content     = '### [' . $linkText . '](' . aioseo()->helpers->decodeUrl( get_term_link( $term, $taxonomy ) ) . ")\n\n";
		$description = aioseo()->meta->description->getTermDescription( $term );
		$description = apply_filters( 'aioseo_llms_term_description', $description, $term );

		if ( ! empty( $description ) ) {
			$content .= '**Description:** ' . aioseo()->helpers->decodeHtmlEntities( $description ) . "\n\n";
		}

		$content .= "---\n\n";

		return $content;
	}

	/**
	 * Gets the full content for a single post in markdown format.
	 *
	 * @since   4.8.8
	 * @version 5.0.5 Sanitize the link text via {@see parent::sanitizeMarkdownLinkText()}.
	 *
	 * @param \WP_Post $post The post object.
	 * @return string
	 */
	protected function getFullPostContent( $post ) {
		$content = '';

		// Post title and link
		$title    = apply_filters( 'aioseo_llms_post_title', $post->post_title, $post );
		$content .= '### [' . $this->sanitizeMarkdownLinkText( aioseo()->helpers->decodeHtmlEntities( $title ) ) . '](' . aioseo()->helpers->decodeUrl( get_permalink( $post->ID ) ) . ")\n\n";

		// Post meta information
		$content .= '**Published:** ' . get_the_date( 'F j, Y', $post->ID ) . "\n";
		$content .= '**Author:** ' . get_the_author_meta( 'display_name', get_post_field( 'post_author', $post->ID ) ) . "\n\n";

		// Post excerpt if available
		if ( ! empty( $post->post_excerpt ) ) {
			$content .= '**Excerpt:** ' . aioseo()->helpers->decodeHtmlEntities( $post->post_excerpt ) . "\n\n";
		}

		// Full post content
		$post        = get_post( $post->ID );
		$postContent = $this->contentRenderer->getRenderedContent( $post );
		if ( ! empty( $postContent ) ) {
			$content .= '**Content:**' . "\n\n";
			$content .= $this->convertToMarkdown( $postContent ) . "\n\n";
		}

		// Get all taxonomies associated with this post
		$taxonomies = get_object_taxonomies( $post->post_type, 'objects' );

		foreach ( $taxonomies as $taxonomy ) {
			// Skip built-in taxonomies that are not public or don't have a UI
			if ( ! $taxonomy->public || ! $taxonomy->show_ui ) {
				continue;
			}

			$terms = get_the_terms( $post->ID, $taxonomy->name );
			if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
				$content .= '**' . $taxonomy->labels->name . ':** ';
				$termNames = array_map( function( $term ) {
					return $term->name;
				}, $terms );
				$content .= implode( ', ', $termNames ) . "\n\n";
			}
		}

		$content .= "---\n\n";

		return $content;
	}

	/**
	 * Converts HTML content to markdown format using the league/html-to-markdown package.
	 *
	 * @since 4.8.8
	 *
	 * @param string $html The HTML content to convert.
	 * @return string
	 */
	private function convertToMarkdown( $html ) {
		// Swapped out first, so the only backticks in the converter's output are the code delimiters it adds.
		$html = str_replace( '`', self::BACKTICK, (string) $html );

		// An inlined SVG file's XML declaration. Removing it from the nodes only catches one the DOM parser doesn't read
		// as the document's own declaration, which it does when it leads the content. Text and code samples are encoded.
		$html = (string) preg_replace( '/<\?xml\b[^>]*\?>/i', '', $html );

		try {
			// Inline data: URI images (e.g. the base64 SVG social icons in the appended author bio)
			// would each turn into a multi-KB base64 blob that text consumers cannot render.
			// Lazy-load plugins park the real URL in a data- attribute; keep the image through that.
			// Quoted attribute values are opaque, so a `>` inside one (e.g. alt text) cannot end the tag early
			// and leak its tail as text. A value that does not close before the next `<` (core's texturize has
			// already split such a tag at that `>`) falls back to the first `>`, so the match cannot run past the
			// tag. Possessive, so the scan stays linear.
			$html = preg_replace_callback( '/<img\b(?:(?:[^>"\']++|"[^"<]*+"|\'[^\'<]*+\')*+>|[^>]*+>)/i', function ( $matches ) {
				$img = $matches[0];

				// A tag core's texturize already split leaves its last attribute value's quote open, and the
				// DOM parser then swallows the rest of the document into that value. Close the quote so the
				// markup after the tag still parses as markup.
				if ( preg_match( '/^<img\b(?:[^"\']++|"[^"]*+"|\'[^\']*+\')*+(["\'])[^"\'>]*+>$/i', $img, $unterminated ) ) {
					$img = substr( $img, 0, -1 ) . $unterminated[1] . '>';
				}

				if ( ! preg_match( '/\bsrc\s*=\s*["\']?data:/i', $img ) ) {
					return $img;
				}

				if ( preg_match( '/\bdata-(?:lazy-)?src\s*=\s*(["\'])(.*?)\1/i', $img, $realSrc ) ) {
					$altText = preg_match( '/\balt\s*=\s*(["\'])(.*?)\1/i', $img, $alt ) ? $alt[2] : '';

					return '<img src="' . esc_url( $realSrc[2] ) . '" alt="' . esc_attr( $altText ) . '"/>';
				}

				return '';
			}, (string) $html );

			// Anchors left with no content (a stripped icon, or an svg the converter removes) would come out
			// as '[](url)' noise, and deleting them takes the URL with them. An icon link names itself in
			// `aria-label`/`title`, so promote that to the link text — unless the URL already reaches the
			// reader through a link that has text, where the icon is only a second copy of it. This must
			// happen on the HTML: a markdown-level cleanup cannot tell prose from code samples. The possessive
			// quantifiers keep the scan linear on an anchor that does not match; a pattern that still gives up
			// leaves the anchor in place, and leaves every URL looking already-linked so nothing is promoted.
			$emptyAnchor = '#(<a\b[^>]*>)(?:\s++|&nbsp;|<svg\b[^<]*+(?:<(?!/svg>)[^<]*+)*+</svg>)*+</a>#is';
			$hrefPattern = '/\bhref\s*=\s*(["\'])(.*?)\1/i';

			preg_match_all( $hrefPattern, preg_replace( $emptyAnchor, '', (string) $html ) ?? (string) $html, $linked );
			$linked = array_flip( $linked[2] );

			$html = preg_replace_callback( $emptyAnchor, function ( $matches ) use ( $hrefPattern, &$linked ) {
				$href = preg_match( $hrefPattern, $matches[1], $url ) ? $url[2] : '';
				$name = preg_match( '/\b(?:aria-label|title)\s*=\s*(["\'])(.*?)\1/i', $matches[1], $label )
					? trim( str_replace( '<', '&lt;', $label[2] ) )
					: '';

				if ( '' === $name || isset( $linked[ $href ] ) ) {
					return '';
				}

				$linked[ $href ] = true;

				return $matches[1] . $name . '</a>';
			}, (string) $html ) ?? $html;

			// The converter emits an anchor with no URL (e.g. an old `<a name>` jump target) as its raw tag, so keep only its text.
			$html = preg_replace_callback( '#<a\b((?:[^>"\']++|"[^"]*+"|\'[^\']*+\')*+)>(.*?)</a>#is', function ( $matches ) {
				return preg_match( '/\bhref\s*=\s*(["\']?)\s*[^"\'\s>]/i', $matches[1] ) ? $matches[0] : $matches[2];
			}, (string) $html ) ?? $html;

			$converter = new HtmlConverter();

			// Configure conversion options for better WordPress content handling
			$converter->getConfig()->setOption( 'strip_tags', true );
			$converter->getConfig()->setOption( 'hard_break', true );
			$converter->getConfig()->setOption( 'header_style', 'atx' );
			// `remove_nodes` matches bare node names. `xml` catches the processing instruction that an
			// inlined SVG file's XML declaration becomes on libxml < 2.14, where it is not parsed as a comment.
			$converter->getConfig()->setOption( 'remove_nodes', 'script style link meta noscript svg xml' );

			// Tables are left as run-on text unless this is registered; the default environment omits it.
			$converter->getEnvironment()->addConverter( new TableConverter() );

			// Convert HTML to Markdown. Tag stripping is the converter's `strip_tags` option above;
			// a second pass here would read a `<?php` code sample as an open tag and delete the rest.
			$markdown = $converter->convert( $html );
			$markdown = preg_replace( '/\n\s*\n\s*\n+/', "\n\n", (string) trim( $markdown ) );
			// Marked before decoding, as an entity in an attribute the converter copies (e.g. `&#96;`) decodes to a backtick.
			$markdown = str_replace( [ self::DELIMITER, '`' ], [ '', self::DELIMITER ], (string) $markdown );
			$markdown = aioseo()->helpers->decodeHtmlEntities( $markdown );

			return $this->escapeMarkdown( $markdown );
		} catch ( \Throwable $e ) {
			// Fallback: strip HTML tags and clean up using AIOSEO's existing method
			$content = wp_strip_all_tags( $html );
			$content = preg_replace( '/\n\s*\n\s*\n+/', "\n\n", (string) trim( $content ) );
			$content = aioseo()->helpers->decodeHtmlEntities( $content );

			return $this->escapeMarkdown( $content );
		}
	}

	/**
	 * Escapes the HTML tags and code delimiters in the Markdown that didn't come from the converter's own code.
	 *
	 * NOTE: Attribute values the converter copies verbatim (a link title, an image alt) and entities decoded into
	 * markup would otherwise reach the output as working tags. Code is kept as is, so samples such as `<?php` survive.
	 * It's only safe to skip code a renderer is sure to read as code, so the content's own backticks never act as
	 * delimiters, and each code span and block is rebuilt with delimiters its content can't close.
	 *
	 * @since 5.0.3
	 *
	 * @param  string $markdown The Markdown, with the converter's code delimiters marked.
	 * @return string           The escaped Markdown.
	 */
	private function escapeMarkdown( $markdown ) {
		$markdown = str_replace( '`', self::BACKTICK, (string) $markdown );

		$codeFence = function ( $code, $minimum ) {
			preg_match_all( '/`++/', $code, $runs );

			return str_repeat( '`', max( $minimum, 1 + max( array_merge( [ 0 ], array_map( 'strlen', $runs[0] ) ) ) ) );
		};

		$escapeText = function ( $text ) {
			// An entity rather than `\``, which some renderers won't let a code span open right after.
			// Four backslashes give a literal one before the tildes; two would escape the `$` and print a literal "$0".
			// A run the converter already escaped (at the start of a line) is skipped, so it doesn't get a second one.
			return (string) preg_replace( [ '/[`\x01]|\xEE\x80\x81/', '/(?<!\\\\)~{3,}+/', '/<(?=[a-zA-Z\/!?])/' ], [ '&#96;', '\\\\$0', '&lt;' ], $text );
		};

		$codeSpan = function ( $code ) use ( $codeFence, $escapeText ) {
			// A GFM table splits its cells on pipes before it parses code spans, so a span with one is left as text.
			if ( false !== strpos( $code, '|' ) ) {
				return '&#96;' . $escapeText( $code ) . '&#96;';
			}

			$code    = str_replace( self::BACKTICK, '`', $code );
			$fence   = $codeFence( $code, 1 );
			$padding = ( '`' === $code[0] || '`' === substr( $code, -1 ) ) ? ' ' : '';

			return $fence . $padding . $code . $padding . $fence;
		};

		$pattern = '/' .
			// A code block the converter emitted, at the top level or nested in a quote or a list item, whose lines
			// carry the `>` and indentation prefixes.
			'^(?<open>[ \t>]*+(?:(?:[-*+]|\d++[.)])[ \t]++)?)\x01{3}(?<info>[^\n\x01]*+)\n(?<block>(?:[^\x01]*\n)?)(?<close>[ \t>]*+)\x01{3}$' .
			// One or more adjacent code spans, after any backslashes.
			'|(?<backslashes>\\\\*+)(?<spans>(?:\x01[^\x01\n]++\x01)++)' .
			// A delimiter left over from code that isn't matched above, a backtick from the content, a tilde fence, or a tag.
			'|\x01|\xEE\x80\x81|(?<!\\\\)~{3,}+|<(?=[a-zA-Z\/!?])/m';

		return (string) preg_replace_callback( $pattern, function ( $matches ) use ( $codeFence, $codeSpan, $escapeText ) {
			if ( '<' === $matches[0] ) {
				return '&lt;';
			}

			if ( empty( $matches['spans'] ) && ! isset( $matches['block'] ) ) {
				return $escapeText( $matches[0] );
			}

			if ( ! empty( $matches['spans'] ) ) {
				preg_match_all( '/\x01([^\x01\n]++)\x01/', $matches['spans'], $spans );

				// An odd run of backslashes would escape the opening delimiter, and adjacent spans would merge theirs.
				$backslashes = $matches['backslashes'] . ( strlen( $matches['backslashes'] ) % 2 ? '\\' : '' );

				return $backslashes . implode( ' ', array_map( $codeSpan, $spans[1] ) );
			}

			$block = str_replace( self::BACKTICK, '`', $matches['block'] );
			$fence = $codeFence( $block, 3 );

			return $matches['open'] . $fence . str_replace( self::BACKTICK, '', $matches['info'] ) . "\n" . $block . $matches['close'] . $fence;
		}, $markdown );
	}

	/**
	 * Handles .md requests and outputs markdown content.
	 *
	 * @since 4.8.8
	 *
	 * @return void
	 */
	public function checkIfPageIsMd() {
		if ( ! aioseo()->options->sitemap->llms->convertToMd ) {
			return;
		}

		// Cheap URL gate; defer the post lookup to `template_redirect` so CPTs registered on init priority 10+ are loaded.
		if ( ! preg_match( '/\.md\/?$/i', $this->getRequestPath() ) ) {
			return;
		}

		add_filter( 'aioseo_redirects_avoid_advanced_404_redirect', [ $this, 'avoidRedirectForThisRequest' ], 10, 2 );
		add_action( 'template_redirect', [ $this, 'handleMdRequest' ], 1 );
	}

	/**
	 * Prevents redirects plugin from interfering with the current request.
	 *
	 * @since 4.8.8
	 *
	 * @param  bool   $avoid      Whether to avoid redirect.
	 * @param  string $requestUrl The request URL.
	 * @return bool
	 */
	public function avoidRedirectForThisRequest( $avoid, $requestUrl ) {
		// Only avoid redirect for the current request URL
		$currentUrl = aioseo()->helpers->getRequestUrl();
		if ( $requestUrl === $currentUrl ) {
			return true;
		}

		return $avoid;
	}

	/**
	 * Handles the .md request.
	 *
	 * @since   4.8.8
	 * @version 5.0.3 Renders in the post's own query context; serves only publicly viewable posts.
	 *
	 * @return void
	 */
	public function handleMdRequest() {
		$post = $this->getPostByPathForMd();
		if ( ! $post ) {
			return;
		}

		// Serve only what the front end serves to an anonymous visitor.
		if ( ! is_post_publicly_viewable( $post ) || post_password_required( $post ) ) {
			wp_die( 'Access denied', '403 Forbidden', [ 'response' => 403 ] );
		}

		// The .md URL resolves as a 404 main query. Render inside the post's own query context, as the
		// llms-full.txt loop does, so query-dependent output (breadcrumbs, builder layouts) targets the post.
		aioseo()->helpers->setWpQueryPost( $post );
		$markdown = $this->getFullPostContent( $post );
		aioseo()->helpers->restoreWpQuery();

		// Set headers for markdown response
		$charset = aioseo()->helpers->getCharset();

		status_header( 200 );
		header( "Content-Type: text/markdown; charset={$charset}" );
		send_nosniff_header();
		header( 'X-Robots-Tag: noindex, follow' );

		// Output the markdown
		echo $markdown; #phpcs:ignore
		exit;
	}

	/**
	 * Gets the post by path for .md requests.
	 *
	 * @since 4.8.8
	 *
	 * @return \WP_Post|void The post object or false if not found.
	 */
	private function getPostByPathForMd() {
		$path = $this->getRequestPath();

		// Only match if the path itself ends with .md (with optional trailing slash).
		if ( ! preg_match( '/\.md\/?$/i', $path ) ) {
			return;
		}

		// Remove .md (and optional trailing slash) from the path only.
		$path = preg_replace( '/\.md\/?$/i', '', $path );

		// Both resolvers below expect the path relative to the home URL, which matters on subdirectory installs. The
		// home path is matched ignoring case, as WP does, so the .md resolves to the page its HTML URL shows.
		$path = aioseo()->helpers->excludeHomePath( $path, true );
		$path = aioseo()->helpers->unleadingSlashIt( $path );

		// Try to find a post using our specialized function for .md requests.
		$post = $this->getPostByPathForMdHelper( $path );

		return $post;
	}

	/**
	 * Resolves a .md request path to a post.
	 *
	 * @since 4.8.8
	 * @version 5.0.3 Encode `&`, `?` and `#` so url_to_postid() ignores `p=`/`page_id=` inside the path.
	 *
	 * @param  string         $path The URL path to search for.
	 * @return \WP_Post|false       The post object or false if not found.
	 */
	private function getPostByPathForMdHelper( $path ) {
		$post = aioseo()->helpers->getPostByPath( $path );
		if ( $post ) {
			return $post;
		}

		// WordPress' own resolver covers what the slug lookup above cannot: permalink structures whose
		// last segment is not the slug, and rewrite rules registered by other plugins. It also honours
		// `?p=<ID>`/`&p=<ID>` anywhere in the URL, so a decoded `?`, `&` or `#` in the path must stay a path character.
		$postId = url_to_postid( home_url( '/' . str_replace( [ '&', '?', '#' ], [ '%26', '%3F', '%23' ], $path ) ) );

		return $postId ? get_post( $postId ) : false;
	}

	/**
	 * Returns the decoded path of the current request.
	 *
	 * @since 5.0.3
	 *
	 * @return string The decoded path.
	 */
	private function getRequestPath() {
		// Parse before decoding: parse_url() turns bytes of decoded multibyte characters (0x80-0x9F) into `_`.
		$requestUri = isset( $_SERVER['REQUEST_URI'] ) ? sanitize_url( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '';

		return aioseo()->helpers->decodeUrl( (string) wp_parse_url( $requestUri, PHP_URL_PATH ) );
	}
}