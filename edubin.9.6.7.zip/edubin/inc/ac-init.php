<?php

/**
 * Academy compatibility
 *
 * @package Edubin
 */

	// edubin_academy_course_price
    // edubin_ac_course_loop_wishlist
    // edubin_ac_course_loop_rating

    // add_body_classes_for_ac_lms
	// edubin_ac_course_info
	// edubin_ac_course_category
	// edubin_ac_related_course_content
	// edubin_ac_related_course_sidebar
    // edubin_ac_course_page_title_section_03
    // edubin_ac_course_page_title_section_04
    // edubin_ac_course_page_title_section_05
    // edubin_ac_course_page_title_section_06

    remove_action( 'academy/templates/single_course_content', 'academy_single_course_header', 10 );
    remove_action( 'academy/templates/single_course_content', 'academy_single_course_instructors', 15 );


    /**
     * Load Academy LMS Icon Font for Elementor Course Loop
     */
    add_action('wp_enqueue_scripts', 'edubin_academy_lms_scripts');

    function edubin_academy_lms_scripts() {
        
        // Check if Academy LMS is active
        if ( ! defined('ACADEMY_ASSETS_URI') || ! defined('ACADEMY_ASSETS_DIR_PATH') ) {
            return;
        }

        // Load only the icon font (lightweight)
        wp_enqueue_style(
            'academy-icon',
            ACADEMY_ASSETS_URI . 'lib/css/academy-icon.css',
            array(),
            filemtime(ACADEMY_ASSETS_DIR_PATH . 'lib/css/academy-icon.css')
        );
    }

    /**
     * Course course price for academy lms
     */

    // Custom function to display ONLY the course price (anywhere in loop or single course)
    function edubin_academy_course_price() {
        $course_id = get_the_ID();

        $is_public = \Academy\Helper::is_public_course( $course_id );
        $enrolled  = \Academy\Helper::is_enrolled( $course_id, get_current_user_id() );
        $is_paid   = (bool) \Academy\Helper::is_course_purchasable( $course_id );

        $price_html = '';
        $monetization = \Academy\Helper::get_settings( 'monetization_engine', 'woocommerce' );

        // Get actual price HTML if course is paid and connected to WooCommerce or EDD
        if ( $is_paid && ( \Academy\Helper::is_active_woocommerce() || \Academy\Helper::is_active_easy_digital_downloads() ) ) {
            if ( 'woocommerce' === $monetization ) {
                $product_id = \Academy\Helper::get_course_product_id( $course_id );
                if ( $product_id ) {
                    $product = wc_get_product( $product_id );
                    if ( $product ) {
                        $price_html = $product->get_price_html(); // Includes sale price, regular price strikethrough, etc.
                    }
                }
            } elseif ( 'edd' === $monetization ) {
                $download_id = \Academy\Helper::get_course_download_id( $course_id );
                if ( $download_id ) {
                    // edd_price() echoes by default, so we need to capture it
                    ob_start();
                    edd_price( $download_id, false );
                    $price_html = ob_get_clean();
                }
            }
        }

        // Final display text
        if ( $is_paid && $price_html ) {
            $output = $price_html; // e.g., <del>$100</del> <ins>$79</ins>
        } elseif ( $is_paid ) {
            $output = esc_html__( 'Paid', 'edubin' );
        } elseif ( $is_public ) {
            $output = esc_html__( 'Public', 'edubin' );
        } else {
            $output = esc_html__( 'Free', 'edubin' );
        }

        // Allow filtering (same as original plugin)
        $output = apply_filters( 'academy/templates/loop/price', $output, $course_id );

        // Output price
        echo wp_kses_post( $output ); 
    }

    // Replace the default course loop header with ONLY the wishlist button
   // remove_action( 'academy/templates/course_loop_header', 'academy_course_loop_header' );
    //add_action( 'academy/templates/course_loop_header', 'edubin_ac_course_loop_wishlist' );

    function edubin_ac_course_loop_wishlist() {
        global $wpdb;

        $course_id = get_the_ID();
        $user_id   = get_current_user_id();

        // Check if wishlist feature is enabled
        $wishlists_status = (bool) \Academy\Helper::get_settings( 'is_enabled_course_wishlist', true );

        $is_already_in_wishlist = false;
        if ( $wishlists_status && is_user_logged_in() ) {
            // Check if course is already in user's wishlist
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery
            $is_already_in_wishlist = $wpdb->get_row(
                $wpdb->prepare(
                    "SELECT * FROM {$wpdb->usermeta} WHERE user_id = %d AND meta_key = 'academy_course_wishlist' AND meta_value = %d",
                    $user_id,
                    $course_id
                )
            );
        }

        // Get card style for correct wishlist button class
        $card_style     = \Academy\Helper::get_settings( 'course_card_style' );
        $wishlist_class = in_array( $card_style, ['layout_two', 'layout_four'], true ) ? 'academy-wishlist-dynamic' : '';
        ?>

        <div class="academy-course__header">
            <?php do_action( 'academy/templates/before_course_loop_header_inner' ); ?>

            <?php if ( $wishlists_status ) : ?>
                <div class="academy-course-header-meta">
                    <?php if ( $is_already_in_wishlist ) : ?>
                        <a href="#" 
                           class="academy-course__wishlist academy-add-wishlist-btn <?php echo esc_attr( $wishlist_class ); ?>" 
                           data-course-id="<?php echo esc_attr( $course_id ); ?>">
                            <i class="academy-icon academy-icon--heart" aria-hidden="true"></i>
                        </a>
                    <?php else : ?>
                        <a href="#" 
                           class="academy-course__wishlist academy-add-wishlist-btn <?php echo esc_attr( $wishlist_class ); ?>" 
                           data-course-id="<?php echo esc_attr( $course_id ); ?>">
                            <i class="academy-icon academy-icon--heart-o" aria-hidden="true"></i>
                        </a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <?php do_action( 'academy/templates/after_course_loop_header_inner' ); ?>
        </div>

        <?php
    }


    /**
     * Edubin Academy LMS Course Loop Rating
     * 
     * Displays course rating with star icons and review count
     * 
     * @param int  $course_id  Course ID (optional). If empty, gets current post ID.
     * @param bool $echo       Whether to echo the output or return it.
     * @return string|void
     */
    function edubin_ac_course_loop_rating( $course_id = 0, $echo = true ) {
        
        // Get course ID if not provided
        if ( empty( $course_id ) ) {
            $course_id = get_the_ID();
        }

        // Validate course ID
        if ( empty( $course_id ) || get_post_type( $course_id ) !== 'academy_courses' ) {
            return '';
        }

        // Get rating data from Academy LMS
        $rating = \Academy\Traits\Courses::get_course_rating( $course_id );

        // If no ratings yet, you can return empty or show 0 rating
        if ( ! $rating || $rating->rating_count <= 0 ) {
            return ''; // Change to show empty stars if you want
        }

        $output = '<div class="edubin-ac-course-rating-wrapper edubin-ac-rating">';

        // Star Rating
        $output .= \Academy\Traits\Courses::star_rating_generator( (float) $rating->rating_avg );

        // Rating Average
        $output .= '<span class="edubin-ac-rating-count-wrap">';
        $output .= '<span class="edubin-ac-rating-number">';
        $output .= esc_html( '(' );
        $output .= esc_html( $rating->rating_avg );
        $output .= '</span>';

        // Separator
        $output .= '<span class="edubin-ac-rating-separate">';
        $output .= esc_html( '/' );
        $output .= '</span>';

        // Review Count
        $output .= '<span class="edubin-ac-rating-count">';
        $output .= esc_html( $rating->rating_count );
        $output .= esc_html( ')' );
        $output .= '</span>';
        $output .= '</span>'; //academy-rating-count-wrap

        $output .= '</div>';

        if ( $echo ) {
            echo wp_kses_post( $output );
        } else {
            return $output;
        }
    }

	//** ==== Academy add body class ** ====
	function add_body_classes_for_ac_lms( $classes ) {

	    $prefix = '_edubin_';
	    $post_id = edubin_get_id();
		    
	    $ac_single_page_layout = Edubin::setting( 'ac_single_page_layout' );

	    // Get body class for Academy lms profile page
	    if ( class_exists('Academy') && $ac_single_page_layout && is_singular( 'academy_courses' )) {
	        $classes[] = 'single-course-layout-0'.$ac_single_page_layout.'';
	    } // End - Get body class for Academy lms profile page
	    
	    // Finally $classes return 
		return $classes;

	}
	add_filter( 'body_class', 'add_body_classes_for_ac_lms' );

   // ==== Display Course info / edubin_ac_course_info =====
    
    if ( ! function_exists( 'edubin_ac_course_info' ) ) {

        function edubin_ac_course_info() {  

            $ac_single_course_info = Edubin::setting( 'ac_single_course_info' );
            $ac_single_page_layout = Edubin::setting( 'ac_single_page_layout' );
            $ac_intro_video_position = Edubin::setting( 'ac_intro_video_position' );
            $ac_instructor_single = Edubin::setting( 'ac_instructor_single' );
            $ac_single_enroll = Edubin::setting( 'ac_single_enroll' );
            $ac_single_duration = Edubin::setting( 'ac_single_duration' );
            $ac_single_lesson = Edubin::setting( 'ac_single_lesson' ); 
            $ac_single_cat = Edubin::setting( 'ac_single_cat' ); 
            $ac_single_language = Edubin::setting( 'ac_single_language' );  
            $ac_single_info_heading = Edubin::setting( 'ac_single_info_heading'); 
            $ac_custom_features_position = Edubin::setting( 'ac_custom_features_position' );
            $ac_single_certificate = Edubin::setting( 'ac_single_certificate' );
            $ac_single_course_price = Edubin::setting( 'ac_single_course_price' );
    
            global $post;
            $course = new \LLMS_Course( $post );
            $ac_enrolled  = $course->get_student_count();
            $ac_duration  = $course->get( 'length' );

            if ($ac_single_course_info) {

                echo '<div class="edubin-course-info">';

                    if ($ac_single_info_heading) {
                        echo '<h4 class="ld-segment-title tpc_mt_30">' . esc_html($ac_single_info_heading) . '</h4>';
                    } 

                    echo '<ul class="course-info-list">';

                        if ($ac_single_course_price):
                            echo '<li class="edubin-price-meta">';
                                echo '<span class="label edubin-price-label"><i class="flaticon-price-tag edubin-price-icon"></i>' . esc_html__('Price :', 'edubin') . '</span>';
                                echo '<span class="value edubin-price-value">';
                                        echo wp_kses_post( Edubin_LIF_LMS_Helper::course_price() );
                                echo '</span>';
                            echo '</li>';

                        endif;

                        if ($ac_custom_features_position == 'top') {
                           get_template_part( 'academy/tpl-part/single/meta', 'custom' );
                        }

                        if ($ac_instructor_single) { 
                            echo '<li>';
                            echo '<span class="label"><i class="meta-icon flaticon-student"></i>' . esc_html__('Instructor: :', 'edubin') . '</span>';
                            echo '<span class="value">' . get_the_author() . '</span>';
                            echo '</li>';
                        }
                        
                        if ($ac_single_enroll ) {
                            $ac_enrolled_count = $ac_enrolled ? $ac_enrolled : 0; // Ensure $ac_enrolleds is an integer
                            $ac_enrolled_text = ('1' == $ac_enrolled_count) ? esc_html__('Student', 'edubin') : esc_html__('Students', 'edubin');

                            echo '<li>';
                            echo '<span class="label"><i class="meta-icon flaticon-users"></i>' . esc_html__('Enrolled :', 'edubin') . '</span>';
                            echo '<span class="value">' . esc_attr($ac_enrolled_count) . ' ' . esc_html($ac_enrolled_text) . '</span>';
                            echo '</li>';
                        }
               
                        if ($ac_single_lesson ) {
                            $lessons              = $course->get_lessons_count();
                            $lesson_count = $lessons ? $lessons : 0; // Ensure $lessons is an integer
                            $lesson_text = ('1' == $lesson_count) ? esc_html__('Lesson', 'edubin') : esc_html__('Lessons', 'edubin');

                            echo '<li>';
                            echo '<span class="label"><i class="meta-icon flaticon-book"></i>' . esc_html__('Lessons :', 'edubin') . '</span>';
                            echo '<span class="value">' . esc_attr($lesson_count) . ' ' . esc_html($lesson_text) . '</span>';
                            echo '</li>';
                        }
         
                       if ( ! empty( $ac_duration ) && $ac_single_duration ) {
                            echo '<li>';
                            echo '<span class="label"><i class="meta-icon flaticon-start"></i>' . esc_html__('Duration :', 'edubin') . '</span>';
                            echo '<span class="value">' . esc_html( $ac_duration ) . '</span>';
                            echo '</li>';
                       }
         
                        if ( $ac_single_cat && get_the_terms(get_the_ID(), 'course_cat') ) {
                            echo '<li>';
                            echo '<span class="label"><i class="meta-icon flaticon-tags"></i>' . esc_html__('Category :', 'edubin') . '</span>';
                            echo '<span class="ac_course_cat value">';
                            if (!get_the_terms(get_the_ID(), 'course_cat')) {
                                esc_html_e('Uncategorized', 'edubin');
                            } else {
                                echo get_the_term_list(get_the_ID(), 'course_cat', '');
                            }
                            echo '</span>';
                            echo '</li>';
                        }

                        if ($ac_single_language && !empty(get_the_terms(get_the_ID(), 'academy_course_language'))) {  
                            echo '<li>';
                            echo '<span class="label"><i class="meta-icon flaticon-worldwide"></i>' . esc_html__('Language :', 'edubin') . '</span>';
                            echo '<span class="language-tag value">';
                                echo get_the_term_list(get_the_ID(), 'academy_course_language', '');
                            echo '</span>';
                            echo '</li>';
                        }

                        $ac_certificate_show = get_post_meta( get_the_ID(), '_edubin_ac_certificate_show', true );

                        $get_certificate = 'yes' === $ac_certificate_show ? __( 'Yes', 'edubin' ) : __( 'No', 'edubin' ); 

                       if ( $ac_single_certificate == 'yes' ) {  
                            echo '<li>';
                            echo '<span class="label"><i class="meta-icon flaticon-award"></i>' . esc_html__('Certificate :', 'edubin') . '</span>';
                            echo '<span class="ac_certificate value">';
                                echo esc_html($get_certificate);
                            echo '</span>';
                            echo '</li>';
                        }

                        if ($ac_custom_features_position == 'bottom') {
                            get_template_part( 'academy/tpl-part/single/meta', 'custom' );
                        }

                    echo '</ul>';
                echo '</div>';
            }

        }
    }

    /**
     * Display Course Category
     */
    
    if ( ! function_exists( 'edubin_ac_course_category' ) ) {

        function edubin_ac_course_category() {  

        ?>
       <!--  Academy Course Category -->
        <div class="ac__widget">    
            <section class="widget edubin-course-widget">
                <h2 class="widget-title"><?php esc_html_e('Course Categories', 'edubin');?></h2> 

                <?php

				$args = array(
				   'taxonomy' => 'course_cat',
				   'orderby' => 'name',
				   'order'   => 'ASC'
				);
			   $terms = get_categories($args);

                if ($terms && ! is_wp_error($terms)): ?>
                    <ul>
                    <?php foreach($terms as $term): ?>
                        <li><a href="<?php echo get_term_link( $term->slug, 'course_cat'); ?>" rel="tag" class="<?php echo esc_attr($term->slug); ?>"><?php echo esc_html($term->name); ?></a></li>
                    <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
             </section>
        </div>

    <?php
        }
    }

    /**
     * Display related courses Content
     */
    
    if ( ! function_exists( 'edubin_ac_related_course_content' ) ) {

        function edubin_ac_related_course_content( $postType = 'academy_courses', $postID = null, $totalPosts = null, $relatedBy = null) { 

        $ac_related_course_title = Edubin::setting( 'ac_related_course_title' );
        $ac_related_course_items = Edubin::setting( 'ac_related_course_items' );
        $ac_related_course_by = Edubin::setting( 'ac_related_course_by' );

        $ac_related_course_columns = Edubin::setting( "ac_related_course_columns" );

        $args = array(
            'style' => $style = Edubin::setting( 'ac_course_archive_style' )
        );

        global $post, $related_posts_custom_query_args;
        if (null === $postID) $postID = $post->ID;
        if (null === $totalPosts) $totalPosts = $ac_related_course_items;
        if (null === $relatedBy) $relatedBy = $ac_related_course_by;
        if (null === $postType) $postType = 'academy_courses';

        // Build our basic custom query arguments

        if ($relatedBy === 'category') {
            $categories = get_the_category( $post->ID );
            $catidlist = '';
            foreach( $categories as $category) {
                $catidlist .= $category->cat_ID . ",";
            }
            // Build our category based custom query arguments
            $related_posts_custom_query_args = array(
                'post_type' => $postType,
                'posts_per_page' => $totalPosts, // Number of related posts to display
                'post__not_in' => array($postID), // Ensure that the current post is not displayed
                'orderby' => 'rand', // Randomize the results
                'cat' => $catidlist, // Select posts in the same categories as the current post
            );
        }

        if ($relatedBy === 'tags') {

            // Get the tags for the current post
            $tags = wp_get_post_tags($postID);
            // If the post has tags, run the related post tag query
            if ($tags) {
                $tag_ids = array();
                foreach($tags as $individual_tag) $tag_ids[] = $individual_tag->term_id;
                // Build our tag related custom query arguments
                $related_posts_custom_query_args = array(
                    'post_type' => $postType,
                    'tag__in' => $tag_ids, // Select posts with related tags
                    'posts_per_page' => $totalPosts, // Number of related posts to display
                    'post__not_in' => array($postID), // Ensure that the current post is not displayed
                    'orderby' => 'rand', // Randomize the results
                );
            } else {
                // If the post does not have tags, run the standard related posts query
                $related_posts_custom_query_args = array(
                    'post_type' => $postType,
                    'posts_per_page' => $totalPosts, // Number of related posts to display
                    'post__not_in' => array($postID), // Ensure that the current post is not displayed
                    'orderby' => 'rand', // Randomize the results
                );
            }

        }

        // Initiate the custom query
        $custom_query = new WP_Query( $related_posts_custom_query_args );


        // Run the loop and output data for the results
        if ( $custom_query->have_posts() ) : 

            echo '<div class="related-post-title-wrap">';
                echo '<h3 class="related-title text-center">' . esc_html( $ac_related_course_title ) . '</h3>';
            echo '</div>';

            echo '<div class="edubin-row">';
            while ( $custom_query->have_posts() ) : $custom_query->the_post();
                echo '<div class="edubin-col-lg-'. esc_attr( $ac_related_course_columns ). ' edubin-col-sm-6">';

                    get_template_part( 'academy/tpl-part/course/th-layouts', '', $args );

                echo '</div>';
            endwhile;
            echo '</div>';
        endif;

        // Reset postdata
        wp_reset_postdata();
        }
    }

    /**
     * Display related courses sidebar
     */

    if ( ! function_exists( 'edubin_ac_related_course_sidebar' ) ) {

        function edubin_ac_related_course_sidebar( $postType = 'academy_courses', $postID = null, $totalPosts = null, $relatedBy = null) { 

        $ac_related_course_title = Edubin::setting( 'ac_related_course_title' );
        $ac_related_course_items = Edubin::setting( 'ac_related_course_items' );
        $ac_related_course_by = Edubin::setting( 'ac_related_course_by' );
        $ac_related_course_style = Edubin::setting( 'ac_related_course_style' );
        $final_ac_related_course_style = ($ac_related_course_style == 'square') ? 'square' : 'round';

        global $post, $related_posts_custom_query_args;
        if (null === $postID) $postID = $post->ID;
        if (null === $totalPosts) $totalPosts = $ac_related_course_items;
        if (null === $relatedBy) $relatedBy = $ac_related_course_by;
        if (null === $postType) $postType = 'academy_courses';

        // Build our basic custom query arguments

        if ($relatedBy === 'category') {
            $categories = get_the_category( $post->ID );
            $catidlist = '';
            foreach( $categories as $category) {
                $catidlist .= $category->cat_ID . ",";
            }
            // Build our category based custom query arguments
            $related_posts_custom_query_args = array(
                'post_type' => $postType,
                'posts_per_page' => $totalPosts, // Number of related posts to display
                'post__not_in' => array($postID), // Ensure that the current post is not displayed
                'orderby' => 'rand', // Randomize the results
                'cat' => $catidlist, // Select posts in the same categories as the current post
            );
        }

        if ($relatedBy === 'tags') {

            // Get the tags for the current post
            $tags = wp_get_post_tags($postID);
            // If the post has tags, run the related post tag query
            if ($tags) {
                $tag_ids = array();
                foreach($tags as $individual_tag) $tag_ids[] = $individual_tag->term_id;
                // Build our tag related custom query arguments
                $related_posts_custom_query_args = array(
                    'post_type' => $postType,
                    'tag__in' => $tag_ids, // Select posts with related tags
                    'posts_per_page' => $totalPosts, // Number of related posts to display
                    'post__not_in' => array($postID), // Ensure that the current post is not displayed
                    'orderby' => 'rand', // Randomize the results
                );
            } else {
                // If the post does not have tags, run the standard related posts query
                $related_posts_custom_query_args = array(
                    'post_type' => $postType,
                    'posts_per_page' => $totalPosts, // Number of related posts to display
                    'post__not_in' => array($postID), // Ensure that the current post is not displayed
                    'orderby' => 'rand', // Randomize the results
                );
            }

        }

        // Initiate the custom query
        $custom_query = new WP_Query( $related_posts_custom_query_args );

        // Run the loop and output data for the results
        if ( $custom_query->have_posts() ) : ?>
     
              <section id="pxcv-ac-course-2" class="widget edubin-course-widget widget_pxcv_posts style__<?php echo esc_attr($final_ac_related_course_style); ?>">
                <h2 class="widget-title"><?php echo esc_html__('Related Courses', 'edubin'); ?></h2>
                <ul class="pxcv-rr-item-widget">

                  <?php while ( $custom_query->have_posts() ) : $custom_query->the_post(); ?>
                    <li class="clearfix has_image">

                     <?php if ( has_post_thumbnail() ) : ?>
                          
                          <a class="post__link"  href="<?php the_permalink(); ?>">
                            <div class="pxcv-rr-item-image_wrapper">
                            <?php the_post_thumbnail( 'thumbnail' ); ?>
                            </div>
                          </a>
                          
                      <?php endif; ?>

                      <div class="pxcv-rr-item-content_wrapper">
                        <a class="post__link" href="<?php the_permalink(); ?>">
                          <h6 class="post__title"><?php the_title(); ?></h6>
                        </a>
                        <span class="course-price">
                        <?php echo wp_kses_post( Edubin_LIF_LMS_Helper::course_price() ); ?>
                        </span>
                      </div>
                    </li>
                  <?php endwhile; ?>

                </ul>
              </section>

        <?php endif;
        // Reset postdata
        wp_reset_postdata();

        }
    }

    /**
     * Academy course archive page post_per_page
     */
       
    function edubin_ac_archive_course_post_per_page( $query ) {

        $ac_course_per_pag = Edubin::setting( 'ac_course_per_page' );

        if ( ! is_admin() && $query->is_main_query() && is_post_type_archive( 'course' ) ) {
            $query->set( 'posts_per_page', $ac_course_per_pag );

        }

        return;
    }
    add_action( 'pre_get_posts', 'edubin_ac_archive_course_post_per_page', 15 );


// ===== edubin_ac_course_page_title_section_03

if ( ! function_exists( 'edubin_ac_course_page_title_section_03' ) ) :
    function edubin_ac_course_page_title_section_03( $title = null, $has_bg_image = null, $extra_style = null ) {

    $ac_excerpt = get_post_meta(get_the_ID(), '_edubin_ac_excerpt', true);
    
    $ac_single_excerpt = Edubin::setting( 'ac_single_excerpt' );
    $ac_single_breadcrumb = Edubin::setting( 'ac_single_breadcrumb' );
    $ac_single_page_layout  = Edubin::setting( 'ac_single_page_layout' );
    $ac_header_color = ( $ac_single_page_layout == '4' ) ? 'light' : 'dark' ;

echo '<div class="edubin-course-top-info edubin-page-title-area edubin-breadcrumb-style-1 '. esc_attr( $ac_header_color ).'">';
    echo '<div class="edubin-container">';
        echo '<div class="edubin-row">';
            echo '<div class="edubin-col-lg-8">';
                echo '<div class="edubin-single-course-lead-info ld">';

                    if ( $ac_single_breadcrumb ) {

                        echo '<div class="edubin-breadcrumb-wrapper">';
                            do_action( 'edubin_breadcrumb' );
                        echo '</div>';

                    }
                    
                    echo '<h1 class="course-title">';
                            the_title();
                    echo '</div>';

                    if ( $ac_single_excerpt) : 
                        echo '<div class="course-short-text">';
                                the_excerpt();
                        echo '</div>'; 
                    endif; 

               // get_template_part( 'academy/tpl-part/single/meta', 'review-update' );
                get_template_part( 'academy/tpl-part/single/meta', 'top' );


        echo '</div>'; 
        echo '<div class="edubin-col-lg-4"></div>'; 
      
        echo '</div>'; 
    echo '</div>'; 
echo '</div>'; 

    }
endif;


/**
 * Course page title section edubin_ac_course_page_title_section_05
 */
if ( ! function_exists( 'edubin_ac_course_page_title_section_05' ) ) :
    function edubin_ac_course_page_title_section_05( $title = null, $has_bg_image = null, $extra_style = null ) {

    $ac_single_short_text = Edubin::setting( 'ac_single_short_text' );
    $ac_single_review = Edubin::setting( 'ac_single_review' );
    $ac_single_last_update = Edubin::setting( 'ac_single_last_update' );
    
    $ac_single_page_layout  = Edubin::setting( 'ac_single_page_layout' );

    $ac_header_color = ( $ac_single_page_layout == '4' ) ? 'light' : 'dark' ;
    $header_title_tag = Edubin::setting( 'header_title_tag' );
    $header_page_title_align = Edubin::setting( 'header_page_title_align' );
    $ac_course_header_style = Edubin::setting( 'ac_course_header_style' );
    $ac_single_breadcrumb = Edubin::setting( 'ac_single_breadcrumb' );

        echo '<div class="edubin-page-title-area edubin-default-breadcrumb '. esc_attr( $has_bg_image ) . 'course-header-style--' . $ac_course_header_style .'"' . $extra_style .'>';
            echo '<div class="' . esc_attr( apply_filters( 'edubin_breadcrumb_container_class', 'edubin-container' ) ) . '">';

             echo '<div class="edubin-course-top-info">';

                echo '<div class="edubin-page-title">';
                    echo '<'.$header_title_tag.' class="page-title has-text-align-'.$header_page_title_align.'">';
                      the_title();
                    echo '</'.$header_title_tag.' class="page-title">';
                echo '</div>';

                if ( $ac_single_breadcrumb ) {

                echo '<div class="edubin-breadcrumb-wrapper has-text-align-'.$header_page_title_align.'">';
                    do_action( 'edubin_breadcrumb' );
                echo '</div>';

                }

               edubin_breadcrumb_shapes();

              get_template_part( 'academy/tpl-part/single/meta', 'top' );

            echo '</div>'; 

            echo '</div>';
        
        echo '</div>';
    }
endif;

// ===== edubin_ac_course_page_title_section_04 ====

if ( ! function_exists( 'edubin_ac_course_page_title_section_04' ) ) :
    function edubin_ac_course_page_title_section_04( $title = null, $has_bg_image = null, $extra_style = null ) {

    global $post; $post_id = $post->ID;
    $course_id = $post_id;
    $user_id   = get_current_user_id();
    $current_id = $post->ID;
    $prefix = '_edubin_';

    $ac_single_short_text = Edubin::setting( 'ac_single_short_text' );
    $ac_single_review = Edubin::setting( 'ac_single_review' );
    $ac_single_last_update = Edubin::setting( 'ac_single_last_update' );
    $ac_single_page_layout  = Edubin::setting( 'ac_single_page_layout' );

    $ac_header_color = ( $ac_single_page_layout == '4' ) ? 'light' : 'dark' ;

    $page_header_img = get_post_meta($post_id, $prefix . 'header_img', true);

    $ac_intro_video_position = Edubin::setting( 'ac_intro_video_position' ); 
    $ac_single_social_shear = Edubin::setting( 'ac_single_social_shear ' ); 

    $breadcrumb_show = Edubin::setting( 'breadcrumb_show' );
    $shortcode_breadcrumb = Edubin::setting( 'shortcode_breadcrumb' );
    $ac_single_breadcrumb = Edubin::setting( 'ac_single_breadcrumb' );

echo '<div class="edubin-course-top-info edubin-page-title-area edubin-breadcrumb-style-1 '.$ac_header_color.'">';
    echo '<div class="edubin-container">';
        echo '<div class="edubin-row">';

            echo '<div class="edubin-col-lg-8">';
                echo '<div class="edubin-single-course-lead-info lp">';

                    if ( $ac_single_breadcrumb ) {

                    echo '<div class="edubin-breadcrumb-wrapper">';
                        do_action( 'edubin_breadcrumb' );
                    echo '</div>';

                    }

                    echo '<h1 class="course-title">';
                            the_title();
                    echo '</h1>';

                    if ( $ac_single_short_text) : 
                        echo '<div class="course-short-text">';
                            the_excerpt();
                        echo '</div>'; 
                    endif; 

                 get_template_part( 'academy/tpl-part/single/meta', 'top' );

                echo '</div>'; // End edubin-single-course-lead-info

            echo '</div>'; // End edubin-col-lg-8

            echo '<div class="edubin-col-lg-4">';  
                if ( $ac_single_page_layout == '5' ) {
                  get_template_part( 'academy/tpl-part/single/media', 'header' );
                }
            echo '</div>'; // End edubin-col-lg-4

        echo '</div>';  // End edubin-row
    echo '</div>';  // End edubin-container
echo '</div>'; // End edubin-course-top-info

    }
endif;

// ===== edubin_ac_course_page_title_section_06

if ( ! function_exists( 'edubin_ac_course_page_title_section_06' ) ) :
    function edubin_ac_course_page_title_section_06( $title = null, $has_bg_image = null, $extra_style = null ) {

            $custom_page_header_img = get_post_meta( get_the_ID(), '_edubin_header_img', 1 ); 
            $ac_single_short_text = Edubin::setting( 'ac_single_short_text' );
            $ac_single_review = Edubin::setting( 'ac_single_review' );
            $ac_single_last_update = Edubin::setting( 'ac_single_last_update' );
            $ac_single_page_layout  = Edubin::setting( 'ac_single_page_layout' );
            $ac_course_header_style  = Edubin::setting( 'ac_course_header_style' );
            $ac_single_breadcrumb = Edubin::setting( 'ac_single_breadcrumb' );

        echo '<div style="background-image: url('.$custom_page_header_img.')" class="edubin-page-title-area edubin-breadcrumb-style-1 edubin-breadcrumb-has-bg '. esc_attr( $has_bg_image ) . 'course-header-style--' . $ac_course_header_style .'"' . $extra_style .'>';

            echo '<div class="' . esc_attr( apply_filters( 'edubin_breadcrumb_container_class', 'edubin-container' ) ) . '">';

            echo '<div class="edubin-course-top-info">';
                echo '<div class="edubin-page-title">';
                    echo '<h1 class="entry-title">';
                       echo the_title(); 
                    echo '</h1>';
                echo '</div>';

                echo '<div class="edubin-breadcrumb-wrapper">';
                    do_action( 'edubin_breadcrumb' );
                echo '</div>';

                get_template_part( 'academy/tpl-part/single/meta', 'top' );

             echo '</div>'; 

            echo '</div>';
        
        echo '</div>';
    }
endif;

