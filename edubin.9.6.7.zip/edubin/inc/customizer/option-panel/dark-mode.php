<?php
/**
 * Dark / Light mode customizer options.
 *
 * @package Edubin
 */

defined( 'ABSPATH' ) || exit;

Kirki::add_field( 'edubin_theme_config', array(
	'type'     => 'custom',
	'settings' => 'dark_mode_section_divider',
	'section'  => 'colors',
	'priority' => 9,
	'default'  => '<hr><strong>' . esc_html__( 'Dark / Light Mode', 'edubin' ) . '</strong>',
) );

Kirki::add_field( 'edubin_theme_config', array(
	'type'        => 'toggle',
	'settings'    => 'dark_mode_switch_enable',
	'label'       => esc_html__( 'Enable Dark / Light Mode', 'edubin' ),
	'description' => esc_html__( 'When disabled, the theme does not load dark-mode styles, scripts, or switch controls.', 'edubin' ),
	'section'     => 'colors',
	'priority'    => 9,
	'default'     => false,
) );

Kirki::add_field( 'edubin_theme_config', array(
	'type'            => 'toggle',
	'settings'        => 'dark_mode_header_toggle',
	'label'           => esc_html__( 'Show Header Toggle', 'edubin' ),
	'description'     => esc_html__( 'Turn off to hide the switch from the header and mobile menu. Dark / Light mode will still follow the Default Mode below.', 'edubin' ),
	'section'         => 'colors',
	'priority'        => 9,
	'default'         => true,
	'active_callback' => array(
		array(
			'setting'  => 'dark_mode_switch_enable',
			'operator' => '===',
			'value'    => true,
		),
	),
) );

Kirki::add_field( 'edubin_theme_config', array(
	'type'     => 'select',
	'settings' => 'dark_mode_default',
	'label'    => esc_html__( 'Default Mode', 'edubin' ),
	'section'  => 'colors',
	'priority' => 9,
	'default'  => 'light',
	'choices'  => array(
		'light' => esc_html__( 'Light', 'edubin' ),
		'dark'  => esc_html__( 'Dark', 'edubin' ),
		'auto'  => esc_html__( 'System Preference (Auto)', 'edubin' ),
	),
	'active_callback' => array(
		array(
			'setting'  => 'dark_mode_switch_enable',
			'operator' => '===',
			'value'    => true,
		),
	),
) );

Kirki::add_field( 'edubin_theme_config', array(
	'type'            => 'image',
	'settings'        => 'dark_mode_logo',
	'label'           => esc_html__( 'Dark Mode Logo', 'edubin' ),
	'description'     => esc_html__( 'Optional light-colored logo shown in dark mode in the Edubin header and Elementor Site Logo widget.', 'edubin' ),
	'section'         => 'colors',
	'priority'        => 9,
	'default'         => '',
	'active_callback' => array(
		array(
			'setting'  => 'dark_mode_switch_enable',
			'operator' => '===',
			'value'    => true,
		),
	),
) );

Kirki::add_field( 'edubin_theme_config', array(
	'type'        => 'custom',
	'settings'    => 'dark_mode_shortcode_info',
	'section'     => 'colors',
	'priority'    => 9,
	'default'     => '<p style="margin:0;font-size:12px;line-height:1.6;color:#666;">' . esc_html__( 'To place the switch in an Elementor header or footer, use the shortcode [edubin_dark_mode_toggle].', 'edubin' ) . '</p>',
	'active_callback' => array(
		array(
			'setting'  => 'dark_mode_switch_enable',
			'operator' => '===',
			'value'    => true,
		),
	),
) );
