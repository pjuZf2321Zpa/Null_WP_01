<?php

/*----------------------------
Utilities
----------------------------*/
 Kirki::add_section( 'edubin_utilities_section', array(
    'title'    =>  esc_html__( 'Utilities', 'edubin' ),
    'panel' =>  'edubin_general_panel'
) );

Kirki::add_field( 'edubin_theme_config', [
    'type'        => 'toggle',
    'settings'    => 'pages_featured_image',
    'label'       => esc_html__( 'Pages Featured Image?', 'edubin' ),
    'section'     => 'edubin_utilities_section',
    'default'     => '1',
] );

Kirki::add_field( 'edubin_theme_config', [
    'type'        => 'toggle',
    'settings'    => 'multiple_lms_error_massage',
    'label'       => esc_html__( 'Multiple LMS Activate Notice?', 'edubin' ),
    'section'     => 'edubin_utilities_section',
    'default'     => '1',
] );

Kirki::add_field( 'edubin_theme_config', [
    'type'        => 'custom',
    'settings'    => 'third_party_js_lib',
    'section'     => 'edubin_utilities_section',
    'default'     => '<h3 style="padding:10px 20px; background:#ffffff; color:#000000; margin:0; border-radius: 3px;">' . esc_html__( 'Third-Party JS Library', 'edubin' ) . '</h3>',
] );

Kirki::add_field( 'edubin_theme_config', [
    'type'        => 'toggle',
    'settings'    => 'mouse_move_animation_js',
    'label'       => esc_html__( 'Mouse Move Animation JS?', 'edubin' ),
    'section'     => 'edubin_utilities_section',
    'default'     => true,
] );

Kirki::add_field( 'edubin_theme_config', [
    'type'        => 'toggle',
    'settings'    => 'smooth_scroll_js',
    'label'       => esc_html__( 'Smooth Scroll JS?', 'edubin' ),
    'section'     => 'edubin_utilities_section',
    'default'     => '0',
] );

Kirki::add_field( 'edubin_theme_config', [
    'type'        => 'toggle',
    'settings'    => 'metismenu_js',
    'label'       => esc_html__( 'MetisMenu JS?', 'edubin' ),
    'section'     => 'edubin_utilities_section',
    'default'     => '0',
] );

Kirki::add_field( 'edubin_theme_config', [
    'type'        => 'toggle',
    'settings'    => 'theia_sticky_sidebar_js',
    'label'       => esc_html__( 'Theia Sticky Sidebar JS?', 'edubin' ),
    'section'     => 'edubin_utilities_section',
    'default'     => '0',
] );

Kirki::add_field( 'edubin_theme_config', [
    'type'        => 'toggle',
    'settings'    => 'fancybox_js',
    'label'       => esc_html__( 'Fancybox JS?', 'edubin' ),
    'section'     => 'edubin_utilities_section',
    'default'     => '0',
] );

Kirki::add_field( 'edubin_theme_config', [
    'type'        => 'toggle',
    'settings'    => 'skip_link_focus_fix_js',
    'label'       => esc_html__( 'Skip Link Focus JS?', 'edubin' ),
    'section'     => 'edubin_utilities_section',
    'default'     => '0',
] );

Kirki::add_field( 'edubin_theme_config', [
    'type'        => 'toggle',
    'settings'    => 'tipped_js',
    'label'       => esc_html__( 'Tipped JS?', 'edubin' ),
    'section'     => 'edubin_utilities_section',
    'default'     => '0',
] );

Kirki::add_field( 'edubin_theme_config', [
    'type'        => 'toggle',
    'settings'    => 'nice_select_js',
    'label'       => esc_html__( 'Nice Select JS?', 'edubin' ),
    'section'     => 'edubin_utilities_section',
    'default'     => '0',
] );

Kirki::add_field( 'edubin_theme_config', [
    'type'        => 'custom',
    'settings'    => 'third_party_css_lib',
    'section'     => 'edubin_utilities_section',
    'default'     => '<h3 style="padding:10px 20px; background:#ffffff; color:#000000; margin:0; border-radius: 3px;">' . esc_html__( 'Third-Party CSS Library', 'edubin' ) . '</h3>',
] );

Kirki::add_field( 'edubin_theme_config', [
    'type'        => 'toggle',
    'settings'    => 'metismenu_css',
    'label'       => esc_html__( 'MetisMenu CSS?', 'edubin' ),
    'section'     => 'edubin_utilities_section',
    'default'     => '0',
] );

Kirki::add_field( 'edubin_theme_config', [
    'type'        => 'toggle',
    'settings'    => 'tipped_css',
    'label'       => esc_html__( 'Tipped CSS?', 'edubin' ),
    'section'     => 'edubin_utilities_section',
    'default'     => '0',
] );

Kirki::add_field( 'edubin_theme_config', [
    'type'        => 'toggle',
    'settings'    => 'nice_select_css',
    'label'       => esc_html__( 'Nice Select CSS?', 'edubin' ),
    'section'     => 'edubin_utilities_section',
    'default'     => '0',
] );

Kirki::add_field( 'edubin_theme_config', [
    'type'        => 'toggle',
    'settings'    => 'fancybox_css',
    'label'       => esc_html__( 'Fancybox CSS?', 'edubin' ),
    'section'     => 'edubin_utilities_section',
    'default'     => '0',
] );
