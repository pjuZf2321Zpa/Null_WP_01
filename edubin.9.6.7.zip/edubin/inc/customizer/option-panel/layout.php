<?php
/*----------------------------
Layout
----------------------------*/
 Kirki::add_section( 'edubin_page_layout_section', array(
    'title'    =>  esc_html__( 'Layout', 'edubin' ),
    'panel' =>  'edubin_general_panel'
) );

Kirki::add_field( 'edubin_theme_config', [
    'type'        => 'toggle',
    'settings'    => 'edubin_fixed_container_width',
    'label'       => esc_html__( 'Fixed Container Width', 'edubin' ),
    'section'     => 'edubin_page_layout_section',
    'default'     => true,
] );
