<?php
/**
 * Dark / Light mode.
 *
 * A small, self-contained module. The active color scheme is stored on the
 * <html> element as data-edubin-theme="light|dark" so CSS can react to it
 * without touching any of the existing theme stylesheets.
 *
 * @package Edubin
 */

defined( 'ABSPATH' ) || exit;

/**
 * Read a setting from the theme mods, falling back to the theme setting API.
 *
 * Using the theme mod directly keeps the switcher working even when Kirki
 * is not loaded on the frontend (for example while Elementor is inactive).
 *
 * @param string $key     Setting key.
 * @param mixed  $default Default value.
 * @return mixed
 */
if ( ! function_exists( 'edubin_dark_mode_get_setting' ) ) :
	function edubin_dark_mode_get_setting( $key, $default ) {
		$value = get_theme_mod( $key, null );

		if ( null === $value ) {
			$value = Edubin::setting( $key, $default );
		}

		if ( null === $value || '' === $value ) {
			$value = $default;
		}

		return $value;
	}
endif;

/**
 * Is the dark / light mode feature enabled?
 *
 * @return bool
 */
if ( ! function_exists( 'edubin_dark_mode_is_enabled' ) ) :
	function edubin_dark_mode_is_enabled() {
		$enabled = filter_var(
			edubin_dark_mode_get_setting( 'dark_mode_switch_enable', false ),
			FILTER_VALIDATE_BOOLEAN
		);

		if ( ! $enabled ) {
			return false;
		}

		return (bool) apply_filters( 'edubin_dark_mode_enabled', true );
	}
endif;

/**
 * Available coordinated color presets.
 *
 * The "theme" key is retained for compatibility and represents Carbon Mist.
 *
 * @return array
 */
if ( ! function_exists( 'edubin_dark_mode_color_presets' ) ) :
	function edubin_dark_mode_color_presets() {
		return array(
			'theme' => array(
				'label'             => __( 'Carbon Mist', 'edubin' ),
				'preview'           => array( '#151515', '#4A4A4A', '#BDBDBD', '#202020', '#303030' ),
				'accent'            => '#4A4A4A',
				'accent_alt'        => '#353535',
				'dark_accent'       => '#BDBDBD',
				'dark_accent_alt'   => '#D6D6D6',
				'secondary'         => '#303030',
				'dark_bg'           => '#151515',
				'dark_surface'      => '#202020',
				'dark_surface_2'    => '#2C2C2C',
				'dark_surface_3'    => '#383838',
				'dark_border'       => '#494949',
				'dark_border_soft'  => '#353535',
				'dark_text'         => '#C4C4C4',
				'dark_heading'      => '#F5F5F5',
				'dark_muted'        => '#999999',
			),
			'ocean' => array(
				'label'          => __( 'Celestial Tide', 'edubin' ),
				'preview'        => array( '#0B1C29', '#A9D4EC', '#102B3D', '#245879', '#163E59' ),
				'accent'        => '#087f9c',
				'accent_alt'    => '#0c6380',
				'dark_accent'   => '#38b8d5',
				'dark_accent_alt' => '#55cbe5',
				'secondary'     => '#103c52',
				'dark_bg'       => '#08151f',
				'dark_surface'  => '#0d2230',
				'dark_surface_2' => '#123044',
				'dark_surface_3' => '#193b50',
				'dark_border'   => '#285064',
				'dark_border_soft' => '#1d3d50',
				'dark_text'     => '#c1d9e2',
				'dark_heading'  => '#effaff',
				'dark_muted'    => '#89aebb',
			),
			'forest' => array(
				'label'          => __( 'Verdant Depths', 'edubin' ),
				'preview'        => array( '#0a1712', '#c5d9ca', '#10241a', '#173123', '#1e3d2c' ),
				'accent'        => '#287a50',
				'accent_alt'    => '#1c6340',
				'dark_accent'   => '#55b982',
				'dark_accent_alt' => '#70ca99',
				'secondary'     => '#193e2d',
				'dark_bg'       => '#0a1712',
				'dark_surface'  => '#10241a',
				'dark_surface_2' => '#173123',
				'dark_surface_3' => '#1e3d2c',
				'dark_border'   => '#315743',
				'dark_border_soft' => '#244431',
				'dark_text'     => '#c5d9ca',
				'dark_heading'  => '#f2fbf4',
				'dark_muted'    => '#91ad98',
			),
			'sunset' => array(
				'label'          => __( 'Emberwood', 'edubin' ),
				'preview'        => array( '#1b1112', '#e1c9c1', '#29191a', '#382121', '#462b29' ),
				'accent'        => '#b64f30',
				'accent_alt'    => '#963d24',
				'dark_accent'   => '#f28b62',
				'dark_accent_alt' => '#ffa47e',
				'secondary'     => '#4b3034',
				'dark_bg'       => '#1b1112',
				'dark_surface'  => '#29191a',
				'dark_surface_2' => '#382121',
				'dark_surface_3' => '#462b29',
				'dark_border'   => '#634039',
				'dark_border_soft' => '#4c302d',
				'dark_text'     => '#e1c9c1',
				'dark_heading'  => '#fff5f0',
				'dark_muted'    => '#b49a91',
			),
			'violet' => array(
				'label'          => __( 'Midnight Reverie', 'edubin' ),
				'preview'        => array( '#12101d', '#d0cbe2', '#1d1a2e', '#28233d', '#332c4b' ),
				'accent'        => '#684eb1',
				'accent_alt'    => '#553c9c',
				'dark_accent'   => '#aa94f5',
				'dark_accent_alt' => '#c0afff',
				'secondary'     => '#382e59',
				'dark_bg'       => '#12101d',
				'dark_surface'  => '#1d1a2e',
				'dark_surface_2' => '#28233d',
				'dark_surface_3' => '#332c4b',
				'dark_border'   => '#4b4269',
				'dark_border_soft' => '#3a3454',
				'dark_text'     => '#d0cbe2',
				'dark_heading'  => '#f7f3ff',
				'dark_muted'    => '#a39abf',
			),
			'material_indigo' => array(
				'label'             => __( 'Material Indigo', 'edubin' ),
				'preview'           => array( '#141218', '#D0BCFF', '#1D1B20', '#6750A4', '#332D41' ),
				'accent'            => '#6750A4',
				'accent_alt'        => '#4F378B',
				'dark_accent'       => '#D0BCFF',
				'dark_accent_alt'   => '#EADDFF',
				'secondary'         => '#625B71',
				'dark_bg'           => '#141218',
				'dark_surface'      => '#1D1B20',
				'dark_surface_2'    => '#25232A',
				'dark_surface_3'    => '#332D41',
				'dark_border'       => '#49454F',
				'dark_border_soft'  => '#36343B',
				'dark_text'         => '#E6E0E9',
				'dark_heading'      => '#F7F1FA',
				'dark_muted'        => '#CAC4D0',
			),
			'material_teal' => array(
				'label'             => __( 'Material Teal', 'edubin' ),
				'preview'           => array( '#101414', '#A8DADC', '#191F1F', '#006A6A', '#263333' ),
				'accent'            => '#006A6A',
				'accent_alt'        => '#005353',
				'dark_accent'       => '#A8DADC',
				'dark_accent_alt'   => '#C4F1F1',
				'secondary'         => '#4A6363',
				'dark_bg'           => '#101414',
				'dark_surface'      => '#191F1F',
				'dark_surface_2'    => '#202828',
				'dark_surface_3'    => '#263333',
				'dark_border'       => '#3F4A4A',
				'dark_border_soft'  => '#303A3A',
				'dark_text'         => '#DCE5E4',
				'dark_heading'      => '#F2FAF9',
				'dark_muted'        => '#AAB9B8',
			),
			'monochrome' => array(
				'label'             => __( 'Black & White', 'edubin' ),
				'preview'           => array( '#050505', '#FFFFFF', '#111111', '#303030', '#777777' ),
				'accent'            => '#1F1F1F',
				'accent_alt'        => '#000000',
				'dark_accent'       => '#FFFFFF',
				'dark_accent_alt'   => '#D9D9D9',
				'secondary'         => '#111111',
				'dark_bg'           => '#050505',
				'dark_surface'      => '#111111',
				'dark_surface_2'    => '#1C1C1C',
				'dark_surface_3'    => '#292929',
				'dark_border'       => '#3A3A3A',
				'dark_border_soft'  => '#272727',
				'dark_text'         => '#D0D0D0',
				'dark_heading'      => '#FFFFFF',
				'dark_muted'        => '#A0A0A0',
			),
		);
	}
endif;

/**
 * Get the selected color preset, falling back to the theme palette.
 *
 * @return string
 */
if ( ! function_exists( 'edubin_dark_mode_get_color_preset' ) ) :
	function edubin_dark_mode_get_color_preset() {
		$preset  = edubin_dark_mode_get_setting( 'dark_mode_color_preset', 'theme' );
		$presets = edubin_dark_mode_color_presets();

		return is_string( $preset ) && isset( $presets[ $preset ] ) ? $preset : 'theme';
	}
endif;

/**
 * Register the visual preset picker in the WordPress Customizer.
 *
 * @param WP_Customize_Manager $wp_customize Customizer manager.
 */
if ( ! function_exists( 'edubin_dark_mode_register_preset_control' ) ) :
	function edubin_dark_mode_register_preset_control( $wp_customize ) {
		if ( ! class_exists( 'WP_Customize_Control' ) ) {
			return;
		}

		if ( ! class_exists( 'Edubin_Dark_Mode_Preset_Control' ) ) {
			class Edubin_Dark_Mode_Preset_Control extends WP_Customize_Control {
				public $type = 'edubin_dark_mode_preset';

				/**
				 * Render the selectable palette cards.
				 */
				public function render_content() {
					$presets = edubin_dark_mode_color_presets();
					$order   = array( 'theme', 'violet', 'forest', 'ocean', 'sunset', 'material_indigo', 'material_teal', 'monochrome' );
					?>
					<?php if ( ! empty( $this->label ) ) : ?>
						<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
					<?php endif; ?>
					<?php if ( ! empty( $this->description ) ) : ?>
						<span class="description customize-control-description"><?php echo esc_html( $this->description ); ?></span>
					<?php endif; ?>
					<div class="edubin-dark-mode-presets" role="radiogroup" aria-label="<?php echo esc_attr( $this->label ); ?>">
						<?php foreach ( $order as $preset_id ) : ?>
							<?php
							if ( ! isset( $presets[ $preset_id ] ) ) {
								continue;
							}

							$preset    = $presets[ $preset_id ];
							$input_id  = $this->id . '-' . $preset_id;
							$swatches  = isset( $preset['preview'] ) ? $preset['preview'] : array();
							$name      = isset( $preset['label'] ) ? $preset['label'] : $preset_id;
							?>
							<label class="edubin-dark-mode-preset-card" for="<?php echo esc_attr( $input_id ); ?>">
								<input
									type="radio"
									id="<?php echo esc_attr( $input_id ); ?>"
									name="<?php echo esc_attr( $this->id ); ?>"
									value="<?php echo esc_attr( $preset_id ); ?>"
									data-customize-setting-link="<?php echo esc_attr( $this->id ); ?>"
									<?php checked( $this->value(), $preset_id ); ?>
								/>
								<span class="edubin-dark-mode-preset-card__swatches" aria-hidden="true">
									<?php foreach ( $swatches as $color ) : ?>
										<span style="background-color:<?php echo esc_attr( $color ); ?>"></span>
									<?php endforeach; ?>
								</span>
								<span class="edubin-dark-mode-preset-card__name"><?php echo esc_html( $name ); ?></span>
							</label>
						<?php endforeach; ?>
					</div>
					<?php
				}
			}
		}

		$wp_customize->add_setting(
			'dark_mode_color_preset',
			array(
				'default'           => 'theme',
				'type'              => 'theme_mod',
				'sanitize_callback' => function( $value ) {
					$presets = edubin_dark_mode_color_presets();
					return is_string( $value ) && isset( $presets[ $value ] ) ? $value : 'theme';
				},
			)
		);

		$wp_customize->add_control(
			new Edubin_Dark_Mode_Preset_Control(
				$wp_customize,
				'dark_mode_color_preset',
				array(
					'label'           => esc_html__( 'Choose a color preset', 'edubin' ),
					'description'     => esc_html__( 'Select a palette manually. It coordinates the site accent with the dark-mode surfaces and text.', 'edubin' ),
					'section'         => 'colors',
					'priority'        => 9,
					'active_callback' => 'edubin_dark_mode_preset_control_is_active',
				)
			)
		);
	}
	add_action( 'customize_register', 'edubin_dark_mode_register_preset_control', 20 );
endif;

/**
 * Show the preset picker only while dark mode is enabled in the Customizer.
 *
 * @param WP_Customize_Control $control Customizer control.
 * @return bool
 */
if ( ! function_exists( 'edubin_dark_mode_preset_control_is_active' ) ) :
	function edubin_dark_mode_preset_control_is_active( $control ) {
		$setting = $control->manager->get_setting( 'dark_mode_switch_enable' );

		return $setting && filter_var( $setting->value(), FILTER_VALIDATE_BOOLEAN );
	}
endif;

/**
 * Load visual preset-picker styling only in the Customizer controls pane.
 */
if ( ! function_exists( 'edubin_dark_mode_customizer_assets' ) ) :
	function edubin_dark_mode_customizer_assets() {
		$css_file = EDUBIN_DIR . 'assets/css/dark-mode-customizer.css';
		$version  = file_exists( $css_file ) ? EDUBIN_THEME_VERSION . '.' . filemtime( $css_file ) : EDUBIN_THEME_VERSION;

		wp_enqueue_style(
			'edubin-dark-mode-customizer',
			EDUBIN_URI . 'assets/css/dark-mode-customizer.css',
			array(),
			$version
		);
	}
	add_action( 'customize_controls_enqueue_scripts', 'edubin_dark_mode_customizer_assets' );
endif;

/**
 * Should the switch be shown in the header and mobile menu?
 *
 * This is separate from edubin_dark_mode_is_enabled(): hiding the switch does
 * not turn off the styles or the default mode.
 *
 * @return bool
 */
if ( ! function_exists( 'edubin_dark_mode_show_toggle' ) ) :
	function edubin_dark_mode_show_toggle() {
		if ( ! edubin_dark_mode_is_enabled() ) {
			return false;
		}

		$show = edubin_dark_mode_get_setting( 'dark_mode_header_toggle', true );

		if ( '0' === $show || 0 === $show || false === $show || 'false' === $show ) {
			$show = false;
		}

		return (bool) apply_filters( 'edubin_dark_mode_show_toggle', $show );
	}
endif;

/**
 * Default mode used before the visitor chooses one.
 *
 * @return string light|dark|auto
 */
if ( ! function_exists( 'edubin_dark_mode_default_mode' ) ) :
	function edubin_dark_mode_default_mode() {
		$mode = edubin_dark_mode_get_setting( 'dark_mode_default', 'light' );

		if ( ! in_array( $mode, array( 'light', 'dark', 'auto' ), true ) ) {
			$mode = 'light';
		}

		return (string) apply_filters( 'edubin_dark_mode_default_mode', $mode );
	}
endif;

/**
 * Get the configured dark-mode logo URL.
 *
 * @return string
 */
if ( ! function_exists( 'edubin_dark_mode_logo_url' ) ) :
	function edubin_dark_mode_logo_url() {
		$logo = edubin_dark_mode_get_setting( 'dark_mode_logo', '' );

		if ( is_array( $logo ) ) {
			$logo = isset( $logo['url'] ) ? $logo['url'] : '';
		}

		if ( is_numeric( $logo ) ) {
			$logo = wp_get_attachment_image_url( (int) $logo, 'full' );
		}

		return is_string( $logo ) ? esc_url_raw( $logo ) : '';
	}
endif;

/**
 * Configuration shared by the inline head script and the frontend script.
 *
 * @return array
 */
if ( ! function_exists( 'edubin_dark_mode_config' ) ) :
	function edubin_dark_mode_config() {
		$default_mode = edubin_dark_mode_default_mode();
		$toggle       = edubin_dark_mode_show_toggle() ? 'show' : 'hidden';
		$preset       = edubin_dark_mode_color_presets()[ edubin_dark_mode_get_color_preset() ];

		return array(
			'storageKey'        => apply_filters( 'edubin_dark_mode_storage_key', 'edubin-color-mode' ),
			'defaultMode'       => $default_mode,
			'colorPreset'       => edubin_dark_mode_get_color_preset(),
			'darkModeLogoUrl'   => edubin_dark_mode_logo_url(),
			// Changing the default mode or hiding the switch resets old visitor choices.
			'preferenceVersion' => $default_mode . '|' . $toggle,
			'darkColor'         => apply_filters( 'edubin_dark_mode_theme_color', $preset['dark_bg'] ),
			'darkTextColor'     => $preset['dark_text'],
			'lightColor'        => apply_filters( 'edubin_dark_mode_light_theme_color', '#ffffff' ),
		);
	}
endif;

/**
 * Print the color scheme before the page is painted (prevents a light flash).
 */
if ( ! function_exists( 'edubin_dark_mode_head_script' ) ) :
	function edubin_dark_mode_head_script() {
		if ( ! edubin_dark_mode_is_enabled() ) {
			return;
		}

		$config_data = edubin_dark_mode_config();
		$config      = wp_json_encode( $config_data );

		$theme_color = 'dark' === edubin_dark_mode_default_mode() ? $config_data['darkColor'] : $config_data['lightColor'];
		echo '<meta name="theme-color" id="edubin-theme-color-meta" content="' . esc_attr( $theme_color ) . '">';

		$script = '(function(){'
			. 'var c=' . $config . ';'
			. 'var r=document.documentElement;'
			. 'var m=c.defaultMode;'
			. 'try{var s=window.localStorage.getItem(c.storageKey),p=c.preferenceVersion+"|";'
			. 'if(s&&s.indexOf(p)===0){var v=s.slice(p.length);'
			. 'if(v==="light"||v==="dark"||v==="auto"){m=v;}}}catch(e){}'
			. 'var d=m==="dark"||(m==="auto"&&window.matchMedia&&window.matchMedia("(prefers-color-scheme: dark)").matches);'
			. 'r.setAttribute("data-edubin-theme",d?"dark":"light");'
			. 'r.setAttribute("data-edubin-color-mode",m);'
			. 'r.setAttribute("data-edubin-color-preset",c.colorPreset);'
			. 'r.style.colorScheme=d?"dark":"light";'
			. 'var t=document.getElementById("edubin-theme-color-meta");'
			. 'if(t){t.setAttribute("content",d?c.darkColor:c.lightColor);}'
			. '})();';

		if ( function_exists( 'wp_print_inline_script_tag' ) ) {
			wp_print_inline_script_tag( $script, array( 'id' => 'edubin-dark-mode-init' ) );
		} else {
			echo '<script id="edubin-dark-mode-init">' . $script . '</script>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}

		echo '<noscript><style>.edubin-dark-mode-switch{display:none !important;}</style></noscript>';
	}
endif;
add_action( 'wp_head', 'edubin_dark_mode_head_script', 1 );

/**
 * Render the optional dark-mode logo for the theme header.
 */
if ( ! function_exists( 'edubin_dark_mode_logo' ) ) :
	function edubin_dark_mode_logo() {
		if ( ! edubin_dark_mode_is_enabled() ) {
			return;
		}

		$logo = edubin_dark_mode_logo_url();

		if ( '' === $logo ) {
			return;
		}

		echo '<a href="' . esc_url( home_url( '/' ) ) . '" class="navbar-brand edubin-dark-mode-logo">';
			echo '<img src="' . esc_url( $logo ) . '" class="edubin-dark-mode-logo-image" alt="' . esc_attr( get_bloginfo( 'name' ) ) . '" />';
		echo '</a>';
	}
endif;

/**
 * Is the current singular page built with Elementor?
 *
 * @return bool
 */
if ( ! function_exists( 'edubin_dark_mode_is_elementor_page' ) ) :
	function edubin_dark_mode_is_elementor_page() {
		return did_action( 'elementor/loaded' )
			&& is_singular()
			&& 'builder' === get_post_meta( get_queried_object_id(), '_elementor_edit_mode', true );
	}
endif;

/**
 * Load the dark mode stylesheet and script.
 */
if ( ! function_exists( 'edubin_dark_mode_enqueue_assets' ) ) :
	function edubin_dark_mode_enqueue_assets() {
		if ( ! edubin_dark_mode_is_enabled() ) {
			return;
		}

		$css_file = EDUBIN_DIR . 'assets/css/dark-mode.css';
		$js_file  = EDUBIN_DIR . 'assets/js/dark-mode.js';
		$css_ver  = file_exists( $css_file ) ? EDUBIN_THEME_VERSION . '.' . filemtime( $css_file ) : EDUBIN_THEME_VERSION;
		$js_ver   = file_exists( $js_file ) ? EDUBIN_THEME_VERSION . '.' . filemtime( $js_file ) : EDUBIN_THEME_VERSION;

		wp_enqueue_style(
			'edubin-dark-mode',
			EDUBIN_URI . 'assets/css/dark-mode.css',
			array( 'edubin-main' ),
			$css_ver
		);

		$preset_id = edubin_dark_mode_get_color_preset();
		$presets   = edubin_dark_mode_color_presets();
		$preset    = $presets[ $preset_id ];

		$preset_css = 'html[data-edubin-color-preset="' . esc_attr( $preset_id ) . '"]{'
				. '--edubin-primary-color:' . esc_attr( $preset['accent'] ) . ';'
				. '--edubin-primary-color-alt:' . esc_attr( $preset['accent_alt'] ) . ';'
				. '--edubin-color-secondary:' . esc_attr( $preset['secondary'] ) . ';'
				. '}'
				. 'html[data-edubin-color-preset="' . esc_attr( $preset_id ) . '"][data-edubin-theme="dark"]{'
				. '--edubin-dm-bg:' . esc_attr( $preset['dark_bg'] ) . ';'
				. '--edubin-dm-surface:' . esc_attr( $preset['dark_surface'] ) . ';'
				. '--edubin-dm-surface-2:' . esc_attr( $preset['dark_surface_2'] ) . ';'
				. '--edubin-dm-surface-3:' . esc_attr( $preset['dark_surface_3'] ) . ';'
				. '--edubin-dm-border:' . esc_attr( $preset['dark_border'] ) . ';'
				. '--edubin-dm-border-soft:' . esc_attr( $preset['dark_border_soft'] ) . ';'
				. '--edubin-dm-text:' . esc_attr( $preset['dark_text'] ) . ';'
				. '--edubin-dm-heading:' . esc_attr( $preset['dark_heading'] ) . ';'
				. '--edubin-dm-muted:' . esc_attr( $preset['dark_muted'] ) . ';'
				. '--edubin-primary-color:' . esc_attr( $preset['dark_accent'] ) . ';'
				. '--edubin-primary-color-alt:' . esc_attr( $preset['dark_accent_alt'] ) . ';'
				. '}';

		wp_add_inline_style( 'edubin-dark-mode', $preset_css );

		$elementor_color_engine = edubin_dark_mode_is_elementor_page();
		$script_dependencies    = array();
		$dark_mode_config       = edubin_dark_mode_config();
		$script_config          = array_merge(
			$dark_mode_config,
			array(
				'elementorColorEngine' => $elementor_color_engine,
				'darkReaderOptions'    => array(
					'mode'                     => 1,
					'brightness'               => 100,
					'contrast'                 => 90,
					'sepia'                    => 0,
					'darkSchemeBackgroundColor' => $dark_mode_config['darkColor'],
					'darkSchemeTextColor'      => $dark_mode_config['darkTextColor'],
				),
				'i18n'                 => array(
					'dark'       => __( 'Switch to dark mode', 'edubin' ),
					'light'      => __( 'Switch to light mode', 'edubin' ),
					'auto'       => __( 'Use system color mode', 'edubin' ),
					'labelDark'  => __( 'Dark mode', 'edubin' ),
					'labelLight' => __( 'Light mode', 'edubin' ),
				),
			)
		);

		if ( $elementor_color_engine ) {
			$darkreader_file = EDUBIN_DIR . 'assets/js/darkreader.js';
			$darkreader_ver  = file_exists( $darkreader_file ) ? EDUBIN_THEME_VERSION . '.' . filemtime( $darkreader_file ) : EDUBIN_THEME_VERSION;

			wp_enqueue_script(
				'edubin-darkreader',
				EDUBIN_URI . 'assets/js/darkreader.js',
				array(),
				$darkreader_ver,
				true
			);
			wp_localize_script( 'edubin-darkreader', 'edubinDarkModeConfig', $script_config );
			$script_dependencies[] = 'edubin-darkreader';
		}

		wp_enqueue_script(
			'edubin-dark-mode',
			EDUBIN_URI . 'assets/js/dark-mode.js',
			$script_dependencies,
			$js_ver,
			true
		);

		if ( ! $elementor_color_engine ) {
			wp_localize_script( 'edubin-dark-mode', 'edubinDarkModeConfig', $script_config );
		}
	}
endif;
add_action( 'wp_enqueue_scripts', 'edubin_dark_mode_enqueue_assets', 30 );

/**
 * Render the dark / light mode switch.
 *
 * This only checks the main feature setting, not the "Show Header Toggle"
 * setting, so [edubin_dark_mode_toggle] can still be used when the header
 * switch is hidden.
 *
 * @param array $args Optional. class, label, echo.
 * @return string|void
 */
if ( ! function_exists( 'edubin_dark_mode_toggle' ) ) :
	function edubin_dark_mode_toggle( $args = array() ) {
		if ( ! edubin_dark_mode_is_enabled() ) {
			return '';
		}

		$args = wp_parse_args(
			$args,
			array(
				'class' => '',
				'label' => false,
				'echo'  => true,
			)
		);

		$wrapper_class = 'edubin-dark-mode-switch';
		if ( ! empty( $args['class'] ) ) {
			$wrapper_class .= ' ' . $args['class'];
		}

		$label = __( 'Toggle dark mode', 'edubin' );

		ob_start();
		?>
		<div class="<?php echo esc_attr( $wrapper_class ); ?>">
			<button type="button" class="edubin-dark-mode-toggle" aria-pressed="false" aria-label="<?php echo esc_attr( $label ); ?>" title="<?php echo esc_attr( $label ); ?>">
				<span class="edubin-dark-mode-toggle__track" aria-hidden="true">
					<span class="edubin-dark-mode-toggle__icon edubin-dark-mode-toggle__icon--sun">
						<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">
							<circle cx="12" cy="12" r="4.2" fill="currentColor"/>
							<g stroke="currentColor" stroke-width="1.8" stroke-linecap="round">
								<path d="M12 2.8v2.1M12 19.1v2.1M2.8 12h2.1M19.1 12h2.1M5.5 5.5l1.5 1.5M17 17l1.5 1.5M18.5 5.5L17 7M7 17l-1.5 1.5"/>
							</g>
						</svg>
					</span>
					<span class="edubin-dark-mode-toggle__icon edubin-dark-mode-toggle__icon--moon">
						<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">
							<path d="M20.2 14.8A8.5 8.5 0 0 1 9.2 3.8a8.6 8.6 0 1 0 11 11Z" fill="currentColor"/>
						</svg>
					</span>
					<span class="edubin-dark-mode-toggle__thumb"></span>
				</span>
				<?php if ( $args['label'] ) : ?>
					<span class="edubin-dark-mode-toggle__label"><?php esc_html_e( 'Dark mode', 'edubin' ); ?></span>
				<?php endif; ?>
			</button>
		</div>
		<?php
		$html = ob_get_clean();

		$html = apply_filters( 'edubin_dark_mode_toggle_html', $html, $args );

		if ( $args['echo'] ) {
			echo $html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			return;
		}

		return $html;
	}
endif;

/**
 * Shortcode so the switch can be placed in Elementor headers / footers.
 */
if ( ! function_exists( 'edubin_dark_mode_toggle_shortcode' ) ) :
	function edubin_dark_mode_toggle_shortcode( $atts = array() ) {
		$atts = shortcode_atts(
			array(
				'class' => 'edubin-dark-mode-switch--shortcode',
				'label' => 'no',
			),
			$atts,
			'edubin_dark_mode_toggle'
		);

		return edubin_dark_mode_toggle(
			array(
				'class' => $atts['class'],
				'label' => in_array( $atts['label'], array( 'yes', 'true', '1' ), true ),
				'echo'  => false,
			)
		);
	}
endif;
add_shortcode( 'edubin_dark_mode_toggle', 'edubin_dark_mode_toggle_shortcode' );
