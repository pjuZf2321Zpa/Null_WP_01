<?php

//Edubin course features metabox
add_action('cmb2_admin_init', 'tpc_edubin_ac_course_features_metabox');
function tpc_edubin_ac_course_features_metabox()
{
    $prefix                = '_edubin_';
    $cmb_ac_course_metabox = new_cmb2_box(array(
        'id'           => $prefix . 'edubin_ac_course_metabox',
        'title'        => __('<span>Course Options</span>', 'edubin'),
        'object_types' => array('academy_courses'), // Post type
        'context'      => 'normal',
        'priority'     => 'high',
        'show_names'   => true, // Show field names on the left
    ));
   $cmb_ac_course_metabox->add_field(array(
        'name' => 'Add Intro Video URL',
        'id'   => 'edubin_ac_video',
        'type' => 'oembed',
        'description'  => __( 'Add video URLs from YouTube, Vimeo, self-hosted MP4, and other supported sources.', 'edubin' )
    ));
 
    $cmb_ac_course_metabox->add_field(array(
        'name' => __('Excerpt', 'edubin'),
        'desc' => __('Add course short description', 'edubin'),
        'id'   =>  $prefix . 'ac_excerpt',
        'type' => 'textarea_small',
    ));   

}

// ========= Academy course custom features metxbox ========

add_action('cmb2_admin_init', 'tpc_edubin_ac_course_feature_metaboxes');
function tpc_edubin_ac_course_feature_metaboxes()
{
    $prefix                = '_edubin_';
    
    $cmb_ac_course_metabox = new_cmb2_box(array(
        'id'           => 'edubin_ac_course_feature_repeater', 
        'title'        => 'Custom Course Features',
        'object_types' => array('academy_courses'), // Post type
        'context'      => 'normal',
        'priority'     => 'low',
        'show_names'   => true, // Show field names on the left
    ));

    $cmb_ac_course_metabox->add_field( array(
        'id'      => $prefix . 'ac_certificate_show',
        'name'    => 'Certificate?',
        'type'    => 'radio_inline',
        'default' => 'no',
        'options' => array(
            'yes'  => __( 'Yes', 'edubin' ),
            'no' => __( 'No', 'edubin' ),
        ),
    ) );
    $ac_custom_feature_group_id = $cmb_ac_course_metabox->add_field(array(
        'id'         => 'ac_custom_feature_group',
        'type'       => 'group',
        'repeatable' => true,
        'options'    => array(
            'group_title'   => 'Course Features {#}',
            'add_button'    => 'Add Course Feature',
            'remove_button' => 'Remove Feature',
            'closed'        => true, // Repeater fields closed by default - neat & compact.
            'sortable'      => true, // Allow changing the order of repeated groups.
        ),
    ));
    $cmb_ac_course_metabox->add_group_field($ac_custom_feature_group_id, array(
        'name' => __('Add Icon', 'edubin'),
        'desc' => __('Here you can add icon classes such as Dashicon, Elementor, etc. Learn more about the icons class. <a target="_blank" href="https://devthrow.com/support/docs/edubin/#icons">go here</a>', 'edubin'),
        'id'   => 'ac_custom_feature_group_icon',
        'type' => 'text', // This field type
    ));
    $cmb_ac_course_metabox->add_group_field($ac_custom_feature_group_id, array(
        'name' => __('Label', 'edubin'),
        'desc' => __('Add your custom course feature label', 'edubin'),
        'id'   => 'ac_custom_feature_group_label',
        'type' => 'text',
    ));
    $cmb_ac_course_metabox->add_group_field($ac_custom_feature_group_id, array(
        'name' => __('Value', 'edubin'),
        'desc' => __('Add your custom course feature label value', 'edubin'),
        'id'   => 'ac_custom_feature_group_value',
        'type' => 'text',
    ));
}
