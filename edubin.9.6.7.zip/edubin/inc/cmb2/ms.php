<?php

// Edubin course features metabox
add_action('cmb2_admin_init', 'tpc_edubin_ms_course_features_metabox');
function tpc_edubin_ms_course_features_metabox()
{
    $prefix                = '_edubin_';
    $cmb_ms_course_metabox = new_cmb2_box(array(
        'id'           => $prefix . 'edubin_ms_course_metabox',
        'title'        => __('<span>Course Options</span>', 'edubin'),
        'object_types' => array('stm-courses'), // Post type
        'context'      => 'normal',
        'priority'     => 'high',
        'show_names'   => true, // Show field names on the left
    ));
   $cmb_ms_course_metabox->add_field(array(
        'name' => 'Add Intro Video URL',
        'id'   => 'edubin_ms_video',
        'type' => 'oembed',
        //'description'  => __( 'Add video URLs from YouTube, Vimeo, self-hosted MP4, and other supported sources.', 'edubin' )
    ));
}

// ========= LearnDash course custom features metxbox ========

add_action('cmb2_admin_init', 'tpc_edubin_ms_course_feature_metaboxes');
function tpc_edubin_ms_course_feature_metaboxes()
{
    $prefix                = '_edubin_';
    
    $cmb = new_cmb2_box(array(
        'id'           => 'edubin_ms_course_feature_repeater', 
        'title'        => 'Custom Course Features',
        'object_types' => array('stm-courses'), // Post type
        'context'      => 'normal',
        'priority'     => 'high',
        'show_names'   => true, // Show field names on the left
    ));

    $ms_custom_feature_group_id = $cmb->add_field(array(
        'id'         => 'ms_custom_feature_group',
        'type'       => 'group',
        'repeatable' => true,
        'options'    => array(
            'group_title'   => 'Course Features {#}',
            'add_button'    => 'Add Course Feature',
            'remove_button' => 'Remove Feature',
            'closed'        => true, // Repeater fields closed by default - neat & compact.
            'sortable'      => true, // Allow changing the order of repeated groups.
        ),
    ));
    $cmb->add_group_field($ms_custom_feature_group_id, array(
        'name' => __('Add Icon', 'edubin'),
        'desc' => __('Here you can add icon classes such as Dashicon, Elementor, etc. Learn more about the icons class. <a target="_blank" href="https://devthrow.com/support/docs/edubin/#icons">go here</a>', 'edubin'),
        'id'   => 'ms_custom_feature_group_icon',
        'type' => 'text', // This field type
    ));
    $cmb->add_group_field($ms_custom_feature_group_id, array(
        'name' => __('Label', 'edubin'),
        'desc' => __('Add your custom course feature label', 'edubin'),
        'id'   => 'ms_custom_feature_group_label',
        'type' => 'text',
    ));
    $cmb->add_group_field($ms_custom_feature_group_id, array(
        'name' => __('Value', 'edubin'),
        'desc' => __('Add your custom course feature label value', 'edubin'),
        'id'   => 'ms_custom_feature_group_value',
        'type' => 'text',
    ));
}
