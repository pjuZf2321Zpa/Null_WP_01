=== Edubin===
Theme Name: Edubin 
Theme URI: https://devthrow.com/wp/edubin/
Description: Edubin is a Education LMS WordPress Theme.
Author: Pixelcurve
Author URI: https://devthrow.com/
Version: 9.6.7
Tags: two-columns, three-columns, left-sidebar, sticky-post, theme-options, translation-ready.
Text Domain: edubin
License: GNU General Public License v2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html


== Description ==
Edubin is a Education LMS WordPress Theme.

For more information about edubin please go to https://themeforest.net/item/edubin-education-lms-wordpress-theme/24037792

== Installation ==

Please see installation guide in Documentation. here https://devthrow.com/support/docs/edubin/