<?php
/**
 * The template for displaying content of archive page meetings
 *
 * This template can be overridden by copying it to yourtheme/video-conferencing-zoom/content-meeting.php.
 *
 * @author Deepen
 * @since 3.0.0
 * @version 3.6.0
 */

defined( 'ABSPATH' ) || exit;

global $zoom;

if ( ! vczapi_pro_version_active() && ( ! empty( $zoom['api']->type ) && vczapi_pro_check_type( $zoom['api']->type ) ) || empty( $zoom ) || ! empty( $zoom['api']->code ) ) {
    return;
}

$edubin_zm_columns = Edubin::setting( 'edubin_zm_columns' );

?>

<div class="vczapi-col-<?php echo esc_attr( $edubin_zm_columns ); ?> vczapi-pb-3">
    <div class="vczapi-list-zoom-meetings--item">
        <?php if ( has_post_thumbnail() ) { ?>
            <div class="vczapi-list-zoom-meetings--item__image">
                <?php the_post_thumbnail(); ?>
            </div><!--Image End-->
        <?php } ?>

        <div class="vczapi-list-zoom-meetings--item__details">

            <?php if (Edubin::setting( 'edubin_zm_title' )): ?>
                <a href="<?php echo esc_url( get_the_permalink() ) ?>" class="vczapi-list-zoom-title-link"><h3><?php the_title(); ?></h3></a>
             <?php endif; ?>

            <div class="vczapi-list-zoom-meetings--item__details__meta">

                <?php if (Edubin::setting( 'edubin_zm_archive_hosted' )): ?>

                    <div class="hosted-by meta">
                        <strong><?php _e( 'Hosted By:', 'edubin' ); ?></strong> <span><?php echo apply_filters( 'vczapi_host_name', $zoom['host_name'] ); ?></span>
                    </div>
                    
                <?php endif; ?>

                <?php if (Edubin::setting( 'edubin_zm_archive_start_date' )): ?>
                <?php
                if ( vczapi_pro_version_active() && vczapi_pro_check_type( $zoom['api']->type ) ) {
                    $type      = ! empty( $zoom['api']->type ) ? $zoom['api']->type : false;
                    $timezone  = ! empty( $zoom['api']->timezone ) ? $zoom['api']->timezone : false;
                    $occurence = ! empty( $zoom['api']->occurrences ) ? $zoom['api']->occurrences : false;
                    if ( ! empty( $occurence ) ) {
                        $start_time = Codemanas\ZoomPro\Helpers::get_latest_occurence_by_type( $type, $timezone, $occurence );
                        ?>
                        <div class="start-date meta">
                            <strong><?php _e( 'Next Occurrence', 'edubin' ); ?>:</strong>
                            <span><?php echo vczapi_dateConverter( $start_time, $timezone, 'F j, Y @ g:i a' ); ?></span>
                        </div>
                        <?php
                    } else {
                        ?>
                        <div class="start-date meta">
                            <strong><?php _e( 'Start Time', 'edubin' ); ?>:</strong>
                            <span><?php echo vczapi_dateConverter( $zoom['start_date'], 'UTC', 'F j, Y @ g:i a' ); ?></span>
                        </div>
                        <?php
                    }
                    ?>
                    <div class="start-date meta">
                        <strong><?php _e( 'Type', 'edubin' ); ?>:</strong>
                        <span><?php _e( 'Recurring', 'edubin' ); ?></span>
                    </div>
                    <?php
                } else {
                    ?>
                    <div class="start-date meta">
                        <strong><?php _e( 'Start', 'edubin' ); ?>:</strong>
                        <span><?php echo vczapi_dateConverter( $zoom['api']->start_time, $zoom['api']->timezone, 'F j, Y @ g:i a' ); ?></span>
                    </div>
                <?php } ?>
                <?php endif; ?>

                <?php if (Edubin::setting( 'edubin_zm_archive_time_zone' )): ?>
                    <div class="timezone meta">
                        <strong><?php _e( 'Timezone', 'edubin' ); ?>:</strong> <span><?php echo $zoom['api']->timezone; ?></span>
                    </div>
                <?php endif; ?>

            </div>

        </div><!--Details end-->
    </div><!--List item end-->
</div>
