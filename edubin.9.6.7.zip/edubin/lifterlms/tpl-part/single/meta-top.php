<?php

$lif_single_page_layout = Edubin::setting( 'lif_single_page_layout' );
$lif_instructor_single = Edubin::setting( 'lif_instructor_single' );
$lif_single_duration = Edubin::setting( 'lif_single_duration' );
$lif_lesson_single = Edubin::setting( 'lif_lesson_single' ); 
$lif_course_feature_enroll_show = Edubin::setting( 'lif_course_feature_enroll_show' ); 
$lif_course_feature_lessons_show = Edubin::setting( 'lif_course_feature_lessons_show' ); 
$lif_single_last_update = Edubin::setting( 'lif_single_last_update' );

global $post;
$course = new \LLMS_Course( $post );
$lif_enrolled  = $course->get_student_count();
$lif_duration  = $course->get( 'length' );

if ( !in_array( $lif_single_page_layout, array('5')) ) {
    echo '<div class="edubin-course-single-header-meta-01">';

            if ($lif_instructor_single) { 
                echo '<div class="course-instructor post-author">';

                    echo '<span class="meta-icon meta-image">';
                        echo get_avatar( get_the_author_meta( 'ID' ), 42 );
                    echo '</span>';

                    echo '<span class="meta-value">';
                        the_author();
                    echo '</span>'; 

                echo '</div>'; 

            } 

            if ($lif_single_last_update) {
                echo '<div class="edubin-last-update-wrap">';
                echo '<span class="edubin-last-update">';
                    echo esc_html__('Last Updated : ', 'edubin');
                    echo get_the_modified_date();
                echo '</span>';
                echo '</div>';

            }

    echo '</div>';
}

if ( in_array( $lif_single_page_layout, array('5')) ) {
    echo '<div class="edubin-course-single-header-meta-02">';

             if ($lif_instructor_single) { 
                echo '<div class=" course-instructor post-author">';

                    echo '<span class="meta-icon meta-image">';
                        echo get_avatar( get_the_author_meta( 'ID' ), 42 );
                    echo '</span>';

                    echo '<span class="meta-value">';
                        the_author();
                    echo '</span>'; 

                echo '</div>'; 

            } 
                
            $lif_enrolled_count = $lif_enrolled ? $lif_enrolled : 0; // Ensure $lif_enrolleds is an integer
            $lif_enrolled_text = esc_html__('Enrolled', 'edubin');

          //  if ($lif_lesson_single) {

                echo '<div class="top__meta course-lesson">';
                echo '<i class="meta-icon flaticon-book"></i>';
                    echo '<span class="meta-value">';
                       echo esc_html($lif_enrolled_count) . ' ' . esc_html($lif_enrolled_text);
                    echo '</span>';
                echo '</div>';
         //   }

            $lif_lessons              = $course->get_lessons_count();
            $lif_lesson_count = $lif_lessons ? $lif_lessons : 0; // Ensure $lessons is an integer
            $lif_lesson_text = ('1' == $lif_lesson_count) ? esc_html__('Lesson', 'edubin') : esc_html__('Lessons', 'edubin');

          //  if ($lif_lesson_single) {

                echo '<div class="top__meta course-lesson">';
                echo '<i class="meta-icon flaticon-book"></i>';
                    echo '<span class="meta-value">';
                       echo esc_html($lif_lesson_count) . ' ' . esc_html($lif_lesson_text);
                    echo '</span>';
                echo '</div>';
         //   }

    echo '</div>'; 
}