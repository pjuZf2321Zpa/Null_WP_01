 <?php

 get_template_part( 'learndash/tpl-part/single/single-layout', 'groups');  