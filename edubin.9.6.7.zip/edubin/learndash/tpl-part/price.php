<?php

    // Get the price array
    $price_data = learndash_get_course_price( get_the_ID() );

    // Safely output the formatted price
    if ( ! empty( $price_data['price'] ) ) {
        echo '<div class="price"><span>';
        echo wp_kses_post( $price_data['price'] );   // Already formatted HTML (with currency, etc.)
        echo '</span></div>';
    } else {
        echo '<div class="price"><span>' . esc_html__( 'Free', 'edubin' ) . '</span></div>';  // fallback
    }
?>