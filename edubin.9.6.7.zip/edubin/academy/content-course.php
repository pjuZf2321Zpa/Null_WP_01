<?php
// if ( ! defined( 'ABSPATH' ) ) {
//  exit; // Exit if accessed directly
// }
// get_template_part( 'academy/tpl-part/course/th-layouts' );



/**
 * Template part for displaying course content in archive.php.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Edubin
 * @since   1.0.0
 */

if ( ! isset( $get_options ) ) :
    $get_options = array();
endif;

if ( ! isset( $style ) ) :
    $style = Edubin::setting( 'ac_course_archive_style' );
endif;


$edubin_course_container = array();
$masonry_status = Edubin::setting( 'ac_course_masonry_layout' );
$wrapper = 'edubin-lms-courses-grid edubin-row edubin-course-archive';

if ( $masonry_status || isset( $_GET['masonry'] ) ) :
    $wrapper = $wrapper . ' ' . 'tpc-masonry-grid-wrapper';
    $edubin_course_container[] = 'tpc-masonry-item';
endif;

if ( ! isset( $column ) ) :
    $column = apply_filters( 'edubin_course_archive_grid_column', array( 'edubin-col-lg-4 edubin-col-md-6 edubin-col-sm-12' ) );
endif;

$edubin_course_container = array_merge( $edubin_course_container, $column );

?>

<div id="post-<?php the_ID(); ?>" <?php post_class( apply_filters( 'edubin_course_loop_classes', $edubin_course_container ) ); ?> data-sal>
    <?php get_template_part( 'academy/tpl-part/course/th-layouts' );
echo '</div>';

    
    
