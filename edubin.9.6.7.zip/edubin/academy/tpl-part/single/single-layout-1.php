<?php
/**
 * The template for displaying course single page
 */

get_header(); 

    $ac_course_header_style = Edubin::setting( 'ac_course_header_style' );
    $ac_related_course_position = Edubin::setting( 'ac_related_course_position' );
    $ac_intro_video_position = Edubin::setting( 'ac_intro_video_position' );


    // ==== Course Header =====

    while ( have_posts() ) : the_post(); 

       if ( '1' == $ac_course_header_style ) { edubin_course_page_title_section_02(); } else { edubin_course_page_title_section_01();}

    endwhile; wp_reset_postdata(); 

     // ==== Content Area  =====   
    echo '<div id="primary" class="content-area">';
        echo '<main id="main" class="site-main" role="main">';
            echo '<div class="edubin-container">';
                echo '<div class="edubin-row">';
                echo '<div class="edubin-col-lg-8 edubin-order-last edubin-course-single-top-space">'; 
                    echo '<div class="edubin-course-single-layout-wrap-01">'; 

                    while ( have_posts() ) : the_post();

                        Academy\Helper::get_template_part( 'content', 'single-course' );

                    endwhile; 

                    echo '</div>'; // End Layout-wrap-01
                echo '</div>'; // End col-8
                
                echo '<div class="edubin-col-lg-4 edubin-order-first">';

                  get_template_part( 'academy/tpl-part/single/single', 'sidebar'); 

                echo '</div>'; // End col-4

                echo '</div>'; // End edubin-row

                if ( $ac_related_course_position == 'content' ) { 

                    echo '<div class="related-post-wrap related_course">';
                        edubin_ac_related_course_content(); 
                    echo '</div>';

                } 

            echo '</div>';
        echo '</main>';
    echo '</div>';

get_footer();