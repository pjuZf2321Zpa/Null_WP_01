<?php
/**
 * The template for displaying course single page
 */
