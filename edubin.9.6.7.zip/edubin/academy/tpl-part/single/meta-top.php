<?php

$ac_single_page_layout = Edubin::setting( 'ac_single_page_layout' );
$ac_instructor_single = Edubin::setting( 'ac_instructor_single' );
$ac_single_last_update = Edubin::setting( 'ac_single_last_update' );
$ac_lesson_single = Edubin::setting( 'ac_lesson_single' ); 
$ac_single_enroll_btn = Edubin::setting( 'ac_single_enroll_btn' ); 
$ac_duration_single = Edubin::setting( 'ac_duration_single' ); 
$ac_single_review = Edubin::setting( 'ac_single_review' ); 
$ac_single_duration     = Edubin::setting( 'ac_single_duration' );
$ac_single_lesson     = Edubin::setting( 'ac_single_lesson' );
$ac_single_enroll       = Edubin::setting( 'ac_single_enroll' );


if ( in_array( $ac_single_page_layout, array('2', '4')) ) {
    echo '<div class="edubin-course-single-header-meta-01">';

            if ($ac_instructor_single) { 
                echo '<div class="course-instructor post-author">';

                    echo '<span class="meta-icon meta-image">';
                        echo get_avatar( get_the_author_meta( 'ID' ), 42 );
                    echo '</span>';

                    echo '<span class="meta-value">';
                        the_author();
                    echo '</span>'; 

                echo '</div>'; 

            } 

            if ( function_exists('edubin_ac_course_loop_rating') && $ac_single_review ):

                 echo '<div class="edubin-rating-wrap">';
                        edubin_ac_course_loop_rating();
                 echo '</div>'; // End .edubin-rating-wrap
            endif;       

            if ($ac_single_last_update) {
                echo '<div class="edubin-last-update-wrap">';
                echo '<span class="edubin-last-update">';
                    echo esc_html__('Last Updated : ', 'edubin');
                    echo get_the_modified_date();
                echo '</span>';
                echo '</div>';
            }

    echo '</div>';
}

if ( in_array( $ac_single_page_layout, array('3')) ) {
    echo '<div class="edubin-course-single-header-meta-01">';

            if ($ac_instructor_single) { 
                echo '<div class="course-instructor post-author">';

                    echo '<span class="meta-icon meta-image">';
                        echo get_avatar( get_the_author_meta( 'ID' ), 42 );
                    echo '</span>';

                    echo '<span class="meta-value">';
                        the_author();
                    echo '</span>'; 

                echo '</div>'; 

            } 

            $students = \Academy\Helper::count_course_enrolled( get_the_ID());
            $ac_student_text = esc_html__(' Enrolled', 'edubin');

            if ( $ac_single_enroll ): 
              
                echo '<div class="course-students">';
                    echo '<i class="meta-icon flaticon-users"></i>';
                        echo '<span class="meta-value">';
                             echo esc_html($students); 
                             echo esc_html($ac_student_text); 
                    echo '</span>'; 
                echo '</div>';    
            endif; 

            $lessons = \Academy\Helper::get_total_number_of_course_lesson( get_the_ID());
            $lessons = $lessons ? $lessons : 0; // Ensure $lessons is an integer
            $lessons_text = ($lessons == 1) ? esc_html__(' Lesson', 'edubin') : esc_html__(' Lessons', 'edubin');

            if ( $ac_single_lesson ): 
                echo '<div class="course-lesson">';
                    echo '<i class="meta-icon flaticon-book"></i>';
                    echo '<span class="meta-value">';
                        echo esc_html( $lessons . $lessons_text); 
                    echo '</span>'; 
                echo '</div>';    
            endif; 

           //  $ac_quizzes      = $course->get_curriculum_items('ac_quiz');

           //  $quiz = $course->get_items('ac_quiz', false) ? count($course->get_items('ac_quiz', false)) : 0;
           //  $quiz_text = ('1' == $quiz) ? esc_html__(' Quiz', 'edubin') : esc_html__(' Quizzes', 'edubin'); 

           //  if ( $quiz && $ac_course_feature_quizzes_show ): 
           //      echo '<div class="course-duration">';
           //          echo '<i class="meta-icon flaticon-pin"></i>';
           //              echo '<span class="meta-value">';
           //                  echo esc_html( $quiz . $quiz_text);
           //          echo '</span>'; 
           //      echo '</div>';   
           // endif;

            if ($ac_single_last_update) {
                echo '<div class="edubin-last-update-wrap">';
                echo '<span class="edubin-last-update">';
                    echo esc_html__('Last Updated : ', 'edubin');
                    echo get_the_modified_date();
                echo '</span>';
                echo '</div>';
            }

    echo '</div>';
}

if ( in_array( $ac_single_page_layout, array('5')) ) {
    echo '<div class="edubin-course-single-header-meta-02">';
            global $post; $post_id = $post->ID;
            $course_id = $post_id;
            $user_id   = get_current_user_id();
            $current_id = $post->ID;

            if ($ac_instructor_single) { 
                echo '<div class="course-instructor post-author">';

                    echo '<span class="meta-icon meta-image">';
                        echo get_avatar( get_the_author_meta( 'ID' ), 42 );
                    echo '</span>';

                    echo '<span class="meta-value">';
                        the_author();
                    echo '</span>'; 

                echo '</div>'; 

            } 

            $students = \Academy\Helper::count_course_enrolled( get_the_ID());
            $ac_student_text = esc_html__(' Enrolled', 'edubin');

            if ( $ac_single_enroll ): 
              
                echo '<div class="top__meta course-students">';
                    echo '<i class="meta-icon flaticon-users"></i>';
                        echo '<span class="meta-value">';
                             echo esc_html($students); 
                             echo esc_html($ac_student_text); 
                    echo '</span>'; 
                echo '</div>';    
            endif; 

 
            $lessons = \Academy\Helper::get_total_number_of_course_lesson( get_the_ID());
            $lessons = $lessons ? $lessons : 0; // Ensure $lessons is an integer
            $lessons_text = ($lessons == 1) ? esc_html__(' Lesson', 'edubin') : esc_html__(' Lessons', 'edubin');

             if ( $ac_single_lesson ): 
                echo '<div class="top__meta course-lesson">';
                    echo '<i class="meta-icon flaticon-book"></i>';
                    echo '<span class="meta-value">';
                        echo esc_html( $lessons . $lessons_text); 
                    echo '</span>'; 
                echo '</div>';    
            endif; 

           //  $ac_quizzes      = $course->get_curriculum_items('ac_quiz');

           //  $quiz = $course->get_items('ac_quiz', false) ? count($course->get_items('ac_quiz', false)) : 0;
           //  $quiz_text = ('1' == $quiz) ? esc_html__(' Quiz', 'edubin') : esc_html__(' Quizzes', 'edubin'); 

           //  if ( $ac_course_feature_quizzes_show ): 
           //      echo '<div class="top__meta course-duration">';
           //          echo '<i class="meta-icon flaticon-pin"></i>';
           //              echo '<span class="meta-value">';
           //                  echo esc_html( $quiz . $quiz_text);
           //          echo '</span>'; 
           //      echo '</div>';   
           // endif;

    echo '</div>'; 
}