<?php 

    global $post;
    $post_id    = $post->ID;
        
    $ac_related_course_position = Edubin::setting( 'ac_related_course_position' );
    $ac_single_social_shear = Edubin::setting( 'ac_single_social_shear' );
    $ac_single_course_info = Edubin::setting( 'ac_single_course_info' );
    $ac_single_course_cat = Edubin::setting( 'ac_single_course_cat' );
    $ac_single_course_price = Edubin::setting( 'ac_single_course_price' );
    $ac_single_enroll_btn = Edubin::setting( 'ac_single_enroll_btn' );
    $ac_single_course_graduation = Edubin::setting( 'ac_single_course_graduation' );
    $ac_single_course_time = Edubin::setting( 'ac_single_course_time' );
    $ac_single_progress = Edubin::setting( 'ac_single_progress' ); 
    $ac_intro_video_position = Edubin::setting( 'ac_intro_video_position' ); 
    $ac_single_sidebar_sticky = Edubin::setting( 'ac_single_sidebar_sticky' );
    $sidebar_sticky_on_off = ( $ac_single_sidebar_sticky ? 'do_sticky' : '');
    $ac_single_page_layout = Edubin::setting( 'ac_single_page_layout' );

echo '<aside id="secondary" class="widget-area '. esc_attr( $sidebar_sticky_on_off ) .'">';
    echo '<div class="course-sidebar-preview ac">';

    if ( in_array($ac_single_page_layout , array('1', '2', '3', '4')) ) { 

     echo '<div class="intro-video-sidebar intro-video-content is__sidebar">'; 

        $edubin_ac_video = get_post_meta( $post_id, 'edubin_ac_video', true );
        if ( $edubin_ac_video && $ac_intro_video_position == 'intro_video_sidebar' ) : 

            echo '<div class="intro-video" style="background-image: url(' . esc_url( get_the_post_thumbnail_url(get_the_ID(),'full') ) . ')">';

                echo '<a href="' . esc_url( $edubin_ac_video ) . '" class="edubin-popup-videos bla-2">';
                    echo '<i class="flaticon-play-button"></i>';
                echo '</a>';

            echo '</div>'; 

        elseif( has_post_thumbnail() && $ac_intro_video_position == 'intro_video_sidebar') :

            echo '<div class="post-thumbnail">';    
               the_post_thumbnail( 'full' ); 
            echo '</div>';  

        endif; 
    echo '</div>';  

   } 
        //=== Plugin default sidebar

        do_action( 'academy/templates/single_course_sidebar_widgets' );
        
        //=== End plugin default sidebar

        echo '<div class="ac_sidebar_wrap ac__widget">';   
        
           //  if ( $ac_single_course_graduation ) { 
           //      // Graduation.
           //      LP()->template( 'course' )->course_graduation();
           //  }
           // if ( $ac_single_course_time ) { 
           //     LP()->template( 'course' )->user_time();
           // }
           // if ( $ac_single_progress ) { 
           //     LP()->template( 'course' )->user_progress();
           // }

        echo '</div>';  

        if ( $ac_single_course_info ) { 

        if( function_exists('edubin_ac_course_info') ){ 

            echo '<div class="ac__widget">'; 

              // edubin_ac_course_info(); 

            echo '</div>';  
        } 

        } 

        // if ( $ac_single_social_shear ) { 
          
        //   echo '<div class="entry-post-share text-center tpc_pb_30">';
        //       echo '<div class="post-share style-03">';
        //           echo '<div class="share-label">';
        //             esc_html_e( 'Share this course', 'edubin' );
        //           echo '</div>';
        //           echo '<div class="share-media">';
        //               echo '<i class="share-icon flaticon-share"></i>';

        //               echo '<div class="share-list">';
        //                 edubin_get_sharing_list(); 
        //               echo '</div>';
        //           echo '</div>';
        //       echo '</div>';
        //   echo '</div>';
          
        // } 
    echo '</div>';
    
    // edubin_ac_related_course_sidebar 
    if ($ac_related_course_position == 'sidebar') { 

        if( function_exists('edubin_ac_related_course_sidebar') ){ 
             echo '<div class="ac__widget">';
                edubin_ac_related_course_sidebar(); 
            echo '</div>';

        } 
    } 

    // edubin_ac_course_category
    if ( $ac_single_course_cat && !empty(get_the_terms(get_the_ID(), 'ac_course_category'))) { 

        if( function_exists('edubin_ac_course_category') ){ 
            echo '<div class="ac__widget">';
                edubin_ac_course_category(); 
            echo '</div>';

        }

    }

    // ac-course-sidebar-2 sidebar
    if ( is_active_sidebar( 'ac-course-sidebar-2' ) ) : 
        echo '<div class="ac__widget">';                   
            dynamic_sidebar( 'ac-course-sidebar-2' ); 
        echo '</div>';
    endif;


echo '</aside>';

