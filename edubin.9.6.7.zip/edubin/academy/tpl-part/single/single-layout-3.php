<?php
/**
 * The template for displaying course single page
 */

get_header(); 

    $ac_intro_video_position = Edubin::setting( 'ac_intro_video_position' ); 
    $ac_related_course_position = Edubin::setting( 'ac_related_course_position' );
    $ac_single_enroll_btn = Edubin::setting( 'ac_single_enroll_btn' );
    $ac_single_social_shear = Edubin::setting( 'ac_single_social_shear' );
    $ac_course_header_style = Edubin::setting( 'ac_course_header_style' );

    // ==== Course Header =====

     while ( have_posts() ) : the_post(); 

    if ( '1' == $ac_course_header_style ) { 
        edubin_ac_course_page_title_section_05(); 
    }
     else { 
        edubin_ac_course_page_title_section_06();
    }

    endwhile; wp_reset_postdata();  

     // ==== Content Area  =====   
    echo '<div id="primary" class="content-area">';
        echo '<main id="main" class="site-main" role="main">';
            echo '<div class="edubin-container">';

                echo '<div class="edubin-course-single-wrap">';

                    while ( have_posts() ) : the_post();

                        Academy\Helper::get_template_part( 'content', 'single-course' );

                    endwhile; 
                echo '</div>';   
                
                if ($ac_related_course_position == 'content') { 

                echo '<div class="related-post-wrap related_course">';
                    edubin_ac_related_course_content(); 
                echo '</div>';

                } 
            echo '</div>';
        echo '</main>';
    echo '</div>';

get_footer();