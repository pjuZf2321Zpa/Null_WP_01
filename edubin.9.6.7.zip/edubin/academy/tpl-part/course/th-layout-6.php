<?php

 if ( ! defined( 'ABSPATH' ) ) exit;

    $ac_archive_media_show = Edubin::setting( 'ac_archive_media_show' );
    $ac_intor_video = Edubin::setting( 'ac_intor_video' );
    $ac_archive_title_show = Edubin::setting( 'ac_archive_title_show' );
    $ac_excerpt_show = Edubin::setting( 'ac_excerpt_show' );
    $ac_cat_show = Edubin::setting( 'ac_cat_show' );
    $ac_wishlist_show = Edubin::setting( 'ac_wishlist_show' );
    $ac_instructor_img_on_off = Edubin::setting( 'ac_instructor_img_on_off' );
    $ac_instructor_name_on_off = Edubin::setting( 'ac_instructor_name_on_off' );
    $ac_lesson_show = Edubin::setting( 'ac_lesson_show' );
    $ac_lesson_text_show = Edubin::setting( 'ac_lesson_text_show' );    
    $ac_enroll_show = Edubin::setting( 'ac_enroll_show' );
    $ac_enroll_text_show = Edubin::setting( 'ac_enroll_text_show' );
    $ac_price_show = Edubin::setting( 'ac_price_show' );
    $ac_level_show = Edubin::setting( 'ac_level_show' );
    $ac_review_show = Edubin::setting( 'ac_review_show' );
    $ac_see_more_btn = Edubin::setting( 'ac_see_more_btn' );
    $ac_see_more_btn_text = Edubin::setting( 'ac_see_more_btn_text' );

echo '<div class="edubin-course layout__' . esc_attr( $args['style'] ) . '">';
    echo '<div class="course__container">';

        if ( $ac_archive_media_show ) {
            echo '<div class="course__media">';

                    echo '<a class="no-course-thumb" href="' . esc_url( get_the_permalink() ) . '">';

                        echo '<div class="edubin-triangle-up"></div>';
                        echo '<div class="edubin-circle"></div>';
                        echo '<div class="edubin-rectangle"></div>';
                        echo '<div class="edubin-circle-border"></div>';

                    echo '</a>';

            if ( $ac_archive_title_show ) {
                echo '<div class="top--title">';
                     echo edubin_get_title();
                echo '</div>';
            }

            echo '</div>';

        } // == End media

        echo '<div class="course__content">';
            echo '<div class="course__content--info">';

            if ( function_exists( 'edubin_ac_course_loop_rating' ) && $ac_review_show ) :
                echo '<div class="edubin-course-rate">';
                    edubin_ac_course_loop_rating();
                echo '</div>';
            endif;

            if ( $ac_excerpt_show ) :
                echo '<div class="course-excerpt">';
                    echo wpautop( wp_trim_words( wp_kses_post( get_the_excerpt() ), esc_html( $args['excerpt_length'] ), esc_html( $args['excerpt_end'] ) ) );
                echo '</div>';
            endif;
            
            if ( $ac_instructor_img_on_off || $ac_instructor_name_on_off): 
                 echo '<div class="author__name">';
                    if ( $ac_instructor_img_on_off ) {
                           echo get_avatar( get_the_author_meta( 'ID' ), 32, '', esc_attr( get_the_author() ) ); 
                    } 
                    if ( $ac_instructor_name_on_off ) {
                        the_author();
                    }  
                 echo '</div>';
            endif;

            echo '</div>';

            echo '<div class="course__border"></div>';
                echo '<div class="course__content--meta">';

                if ( $ac_price_show ) {
                    echo '<div class="course__meta-left">';

                        if ($ac_price_show) {
                            echo '<div class="course__meta-right">';
                                echo '<div class="price__1">';
                                      edubin_academy_course_price();
                                echo '</div>';
                            echo '</div>';
                        }

                    echo '</div>';
                }

               if ( $ac_see_more_btn ) {
                    echo '<div class="course__meta-right">';
                        echo '<div class="view-more-btn">';
                            if (!empty($ac_see_more_btn_text)) {
                                echo '<a href="' . esc_url( get_permalink() ) . '">'. $ac_see_more_btn_text .'</a>';
                            } else {
                                echo '<a href="' . esc_url( get_permalink() ) . '">'. esc_html__('View Details', 'edubin').'</a>';
                            }   
                        echo '</div>';
                    echo '</div>';
                }

                echo '</div>';
        echo '</div>';
    echo '</div>';


echo '</div>';