<?php

 if ( ! defined( 'ABSPATH' ) ) exit;

    $ac_archive_media_show = Edubin::setting( 'ac_archive_media_show' );
    $ac_intor_video = Edubin::setting( 'ac_intor_video' );
    $ac_archive_title_show = Edubin::setting( 'ac_archive_title_show' );
    $ac_excerpt_show = Edubin::setting( 'ac_excerpt_show' );
    $ac_cat_show = Edubin::setting( 'ac_cat_show' );
    $ac_wishlist_show = Edubin::setting( 'ac_wishlist_show' );
    $ac_instructor_img_on_off = Edubin::setting( 'ac_instructor_img_on_off' );
    $ac_instructor_name_on_off = Edubin::setting( 'ac_instructor_name_on_off' );
    $ac_lesson_show = Edubin::setting( 'ac_lesson_show' );
    $ac_lesson_text_show = Edubin::setting( 'ac_lesson_text_show' );    
    $ac_enroll_show = Edubin::setting( 'ac_enroll_show' );
    $ac_enroll_text_show = Edubin::setting( 'ac_enroll_text_show' );
    $ac_price_show = Edubin::setting( 'ac_price_show' );
    $ac_level_show = Edubin::setting( 'ac_level_show' );
    $ac_review_show = Edubin::setting( 'ac_review_show' );
    $ac_see_more_btn = Edubin::setting( 'ac_see_more_btn' );
    $ac_see_more_btn_text = Edubin::setting( 'ac_see_more_btn_text' );

echo '<div class="edubin-course layout__' . esc_attr( $args['style'] ) . '">';
    echo '<div class="course__container">';

        if ( $ac_archive_media_show ) {
            echo '<div class="course__media">';

                $edubin_ac_video = get_post_meta(get_the_ID(), 'edubin_ac_video', 1); 

                if ( !empty( $edubin_ac_video ) && $ac_intor_video ) : 

                    echo '<div class="intro-video-sidebar">';
                        echo '<div class="intro-video" style="background-image:url('. esc_url( $args['thumb_url'] ) .')">';
                            echo '<a href="' . esc_url( $edubin_ac_video ) . '" class="edubin-popup-videos bla-2"><i class="flaticon-play-button"></i></a>';
                        echo '</div>';
                    echo '</div>';
               
                else :

                echo '<a class="course-thumb" href="' . esc_url( get_the_permalink() ) . '">';
                    echo '<img class="w-100" src="' . esc_url( $args['thumb_url'] ) . '" alt="' . esc_attr( edubin_thumbanil_alt_text( get_post_thumbnail_id( get_the_id() ) ) ). '">';
                echo '</a>';

                endif;

                echo '<div class="course__meta-top">';

                 if ($ac_price_show) {
                    echo '<div class="price__4">';
                         edubin_academy_course_price();
                    echo '</div>';
                }

                if ( $ac_wishlist_show ) {
                    echo '<div class="wishlist-4">';

                    echo '<div class="edubin-ac-wishlist-wrapper">';
                      //  edubin_ac_course_loop_wishlist();
                    echo '</div>';

                     echo '</div>';
                 }

                echo '</div>';

                    if ( $ac_instructor_img_on_off ): 
                     echo '<div class="author__name">';
                        if ( $ac_instructor_img_on_off ) {
                               echo get_avatar( get_the_author_meta( 'ID' ), 50 ); 
                        } 
                     echo '</div>';
                    endif; 

            echo '</div>';

        } // == End media

        echo '<div class="course__content">';
            echo '<div class="course__content--info">';

            if ( $ac_archive_title_show ) {
                echo '<div class="course__title--info">';
                    echo edubin_get_title();
                echo '</div>';
            }

            if ( $ac_excerpt_show ) :
                echo '<div class="course-excerpt">';
                    echo wpautop( wp_trim_words( wp_kses_post( get_the_excerpt() ), esc_html( $args['excerpt_length'] ), esc_html( $args['excerpt_end'] ) ) );
                echo '</div>';
            endif;

            if ( function_exists( 'edubin_ac_course_loop_rating' ) && $ac_review_show ) :
                echo '<div class="edubin-course-rate">';
                   edubin_ac_course_loop_rating();
                echo '</div>';
            endif;


            echo '</div>';

            echo '<div class="course__border"></div>';
                echo '<div class="course__content--meta">';

                    if ( $ac_enroll_show || $ac_lesson_show ) {
                        echo '<div class="course__meta-left">';

                        $students = \Academy\Helper::count_course_enrolled( get_the_ID());
                        $students_text = esc_html__(' Enrolled', 'edubin');

                        if ( $ac_enroll_show && !empty($students ) ) {
                            echo '<span class="course-enroll"><i class="flaticon-study"></i>';
                                echo '<span class="value">';
                                        echo esc_attr($students);
                                        if ($ac_enroll_text_show) {
                                            echo esc_html($students_text); 
                                        }
                                echo '</span>';
                            echo '</span>';
                        }

                        $lessons = \Academy\Helper::get_total_number_of_course_lesson( get_the_ID());
                        $lessons = $lessons ? $lessons : 0; // Ensure $lessons is an integer
                        $lessons_text = ($lessons == 1) ? esc_html__(' Lesson', 'edubin') : esc_html__(' Lessons', 'edubin');

                        if ( $ac_lesson_show ) {
                            echo '<span class="course-lessons"><i class="flaticon-book"></i>';
                                 echo '<span class="value">';
                                    echo esc_attr($lessons);
                                    if ($ac_lesson_text_show) {
                                        echo esc_html($lessons_text);
                                    }
                                 echo '</span>';
                            echo '</span>';
                        }
                        
                        echo '</div>';
                    }

                    if ( $ac_see_more_btn ) {
                        echo '<div class="course__meta-right">';
                            echo '<div class="view-more-btn">';
                                if (!empty($ac_see_more_btn_text)) {
                                    echo '<a href="' . esc_url( get_permalink() ) . '">'. $ac_see_more_btn_text .'</a>';
                                } else {
                                    echo '<a href="' . esc_url( get_permalink() ) . '">'. esc_html__('View Details', 'edubin').'</a>';
                                }   
                            echo '</div>';
                        echo '</div>';
                    }

                echo '</div>';
        echo '</div>';
    echo '</div>';

echo '</div>';