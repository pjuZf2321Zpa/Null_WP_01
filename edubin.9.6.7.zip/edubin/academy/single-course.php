<?php
/**
 * The template for displaying LearnPress single page
 */
//get_header();

$ac_single_page_layout = Edubin::setting('ac_single_page_layout');

if (in_array($ac_single_page_layout, ['1', '2', '3', '4', '5', '6'])) {
    get_template_part('academy/tpl-part/single/single-layout', $ac_single_page_layout);
}

//get_footer();
