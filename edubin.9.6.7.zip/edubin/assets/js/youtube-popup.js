/*
    Name: YouTubePopUp
    Description: Lightweight, responsive modal popup for YouTube, Vimeo, Kinescope, MP4, and standard embeds.
    Version: 1.2.0
    Websites: devthrow.com
*/
(function ( $ ) {
 
    $.fn.YouTubePopUp = function(options) {

        var YouTubePopUpOptions = $.extend({
            autoplay: 1
        }, options );

        $(this).on('click', function (e) {

            var videoLink = $(this).attr("href");
            var videoEmbedHtml = ""; 

            // 1. Direct Video Files (.mp4, .webm, .ogg)
            if ( videoLink.match(/\.(mp4|webm|ogg)($|\?)/i) ) {
                var autoPlayAttr = YouTubePopUpOptions.autoplay ? "autoplay" : "";
                videoEmbedHtml = '<video src="' + videoLink + '" controls ' + autoPlayAttr + ' style="width:100%; height:100%; max-height: 80vh;"></video>';
            } 
            // 2. Kinescope.io
            else if ( videoLink.match(/kinescope\.io/) ) {
                var kinescopeID = videoLink.indexOf('/embed/') !== -1 
                    ? videoLink.split('/embed/')[1].split('?')[0] 
                    : videoLink.split('kinescope.io/')[1].split('?')[0];

                var autoPlayParam = YouTubePopUpOptions.autoplay ? "?autoplay=1" : "";
                var videoEmbedLink = "https://kinescope.io/embed/" + kinescopeID + autoPlayParam;

                videoEmbedHtml = '<iframe src="' + videoEmbedLink + '" allowfullscreen allow="autoplay; fullscreen; picture-in-picture; encrypted-media; gyroscope; accelerometer; clipboard-write; screen-wake-lock;" frameborder="0"></iframe>';
            }
            // 3. YouTube (Standard & Short links)
            else if ( videoLink.match(/(youtube\.com|youtu\.be)/) ) {
                var videoID = "";
                if ( videoLink.match(/v=/) ) {
                    videoID = videoLink.split('v=')[1].split('&')[0];
                } else if ( videoLink.match(/youtu\.be\//) ) {
                    videoID = videoLink.split('youtu.be/')[1].split('?')[0];
                } else if ( videoLink.match(/\/embed\//) ) {
                    videoID = videoLink.split('/embed/')[1].split('?')[0];
                }
                
                var videoEmbedLink = "https://www.youtube.com/embed/" + videoID + "?autoplay=" + YouTubePopUpOptions.autoplay;
                videoEmbedHtml = '<iframe src="' + videoEmbedLink + '" allowfullscreen allow="autoplay"></iframe>';
            } 
            // 4. Vimeo
            else if ( videoLink.match(/vimeo\.com/) ) {
                var vimeoID = videoLink.replace(/[^0-9]/g, '');
                if ( videoLink.match(/\/video\//) ) {
                    vimeoID = videoLink.split('/video/')[1].split('?')[0];
                }
                
                var videoEmbedLink = "https://player.vimeo.com/video/" + vimeoID + "?autoplay=" + YouTubePopUpOptions.autoplay;
                videoEmbedHtml = '<iframe src="' + videoEmbedLink + '" allowfullscreen allow="autoplay"></iframe>';
            }
            // 5. Dailymotion
            else if ( videoLink.match(/dailymotion\.com|dai\.ly/) ) {
                var dailyID = "";
                if ( videoLink.match(/\/video\//) ) {
                    dailyID = videoLink.split('/video/')[1].split('?')[0];
                } else if ( videoLink.match(/dai\.ly\//) ) {
                    dailyID = videoLink.split('dai.ly/')[1].split('?')[0];
                }
                var videoEmbedLink = "https://www.dailymotion.com/embed/video/" + dailyID + "?autoplay=" + YouTubePopUpOptions.autoplay;
                videoEmbedHtml = '<iframe src="' + videoEmbedLink + '" allowfullscreen allow="autoplay"></iframe>';
            }
            // 6. TikTok
            else if ( videoLink.match(/tiktok\.com/) ) {
                var videoID = videoLink.split('/video/')[1] ? videoLink.split('/video/')[1].split('?')[0] : "";
                var videoEmbedLink = "https://www.tiktok.com/embed/v2/" + videoID;
                videoEmbedHtml = '<iframe src="' + videoEmbedLink + '" allowfullscreen allow="autoplay"></iframe>';
            }
            // 7. Universal Fallback for any other Embed/Iframe Link (TED, Wistia, WordPress.tv, etc.)
            else {
                videoEmbedHtml = '<iframe src="' + videoLink + '" allowfullscreen allow="autoplay; fullscreen; picture-in-picture"></iframe>';
            }

            // Render Popup
            if ( videoEmbedHtml !== "" ) {
                $("body").append('<div class="YouTubePopUp-Wrap YouTubePopUp-animation"><div class="YouTubePopUp-Content"><span class="YouTubePopUp-Close"></span>' + videoEmbedHtml + '</div></div>');

                if ( $('.YouTubePopUp-Wrap').hasClass('YouTubePopUp-animation') ) {
                    setTimeout(function() {
                        $('.YouTubePopUp-Wrap').removeClass("YouTubePopUp-animation");
                    }, 600);
                }

                $(".YouTubePopUp-Wrap, .YouTubePopUp-Close").click(function() {
                    $(".YouTubePopUp-Wrap").addClass("YouTubePopUp-Hide").delay(515).queue(function() { 
                        $(this).remove(); 
                    });
                });

                e.preventDefault();
            }
        });
        $(document).keyup(function(e) {
            if ( e.keyCode == 27 ) {
                $('.YouTubePopUp-Wrap, .YouTubePopUp-Close').click();
            }
        });
    };
}( jQuery ));