/**
 * Edubin dark / light mode.
 *
 * The initial color scheme is set by a tiny inline script in <head> to avoid
 * a flash of the wrong theme. This file keeps the switch buttons, storage,
 * system preference and <meta name="theme-color"> in sync.
 */
(function () {
	'use strict';

	var config = window.edubinDarkModeConfig || {};
	var root = document.documentElement;
	var storageKey = config.storageKey || 'edubin-color-mode';
	var defaultMode = config.defaultMode || 'light';
	var preferenceVersion = config.preferenceVersion || '';
	var preferencePrefix = preferenceVersion + '|';
	var darkColor = config.darkColor || '#0b1220';
	var lightColor = config.lightColor || '#ffffff';
	var darkModeLogoUrl = config.darkModeLogoUrl || '';
	var colorPreset = config.colorPreset || 'theme';
	var i18n = config.i18n || {};
	var media = window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)') : null;
	var transitionTimer = null;
	var darkReaderFetchConfigured = false;

	function getStoredMode() {
		try {
			var value = window.localStorage.getItem(storageKey);

			if (!value || value.indexOf(preferencePrefix) !== 0) {
				return null;
			}

			var mode = value.slice(preferencePrefix.length);
			if (mode === 'light' || mode === 'dark' || mode === 'auto') {
				return mode;
			}
		} catch (e) {}

		return null;
	}

	function storeMode(mode) {
		try {
			window.localStorage.setItem(storageKey, preferencePrefix + mode);
		} catch (e) {}
	}

	function systemPrefersDark() {
		return !!(media && media.matches);
	}

	function resolveDark(mode) {
		return mode === 'dark' || (mode === 'auto' && systemPrefersDark());
	}

	function getAppliedTheme() {
		return root.getAttribute('data-edubin-theme') === 'dark' ? 'dark' : 'light';
	}

	function updateMeta(isDark) {
		var meta = document.getElementById('edubin-theme-color-meta');
		if (meta) {
			meta.setAttribute('content', isDark ? darkColor : lightColor);
		}
	}

	function updateButtons(isDark) {
		var label = isDark ? (i18n.light || 'Switch to light mode') : (i18n.dark || 'Switch to dark mode');
		var labelText = isDark ? (i18n.labelLight || 'Light mode') : (i18n.labelDark || 'Dark mode');
		var buttons = document.querySelectorAll('.edubin-dark-mode-toggle');

		for (var i = 0; i < buttons.length; i++) {
			buttons[i].setAttribute('aria-pressed', isDark ? 'true' : 'false');
			buttons[i].setAttribute('aria-label', label);
			buttons[i].setAttribute('title', label);

			var labelEl = buttons[i].querySelector('.edubin-dark-mode-toggle__label');
			if (labelEl) {
				labelEl.textContent = labelText;
			}
		}
	}

	function dispatchChange(mode, isDark) {
		var detail = {
			mode: mode,
			theme: isDark ? 'dark' : 'light'
		};
		var event;

		try {
			event = new CustomEvent('edubin:themechange', { detail: detail });
		} catch (e) {
			event = document.createEvent('CustomEvent');
			event.initCustomEvent('edubin:themechange', true, true, detail);
		}

		document.dispatchEvent(event);
	}

	function updateElementorColors(isDark) {
		if (!config.elementorColorEngine || !window.DarkReader) {
			return;
		}

		if (isDark) {
			if (!darkReaderFetchConfigured && window.fetch && window.DarkReader.setFetchMethod) {
				window.DarkReader.setFetchMethod(window.fetch.bind(window));
				darkReaderFetchConfigured = true;
			}

			if (!window.DarkReader.isEnabled()) {
				window.DarkReader.enable(config.darkReaderOptions, {
					ignoreImageAnalysis: [
						'.edubin-dark-mode-logo-image',
						'.site-logo',
						'.header-white-logo'
					]
				});
			}
		} else if (window.DarkReader.isEnabled()) {
			window.DarkReader.disable();
		}
	}

	function updateElementorLogo(isDark) {
		if (!darkModeLogoUrl) {
			return;
		}

		var logos = document.querySelectorAll('.edubin-elementor-header-wrapper .elementor-widget-theme-site-logo img');

		for (var i = 0; i < logos.length; i++) {
			var logo = logos[i];

			if (!logo.hasAttribute('data-edubin-light-logo-src')) {
				logo.setAttribute('data-edubin-light-logo-src', logo.getAttribute('src') || '');
				logo.setAttribute('data-edubin-light-logo-srcset', logo.getAttribute('srcset') || '');
			}

			if (isDark) {
				logo.setAttribute('src', darkModeLogoUrl);
				logo.removeAttribute('srcset');
			} else {
				logo.setAttribute('src', logo.getAttribute('data-edubin-light-logo-src'));
				var lightSrcset = logo.getAttribute('data-edubin-light-logo-srcset');
				if (lightSrcset) {
					logo.setAttribute('srcset', lightSrcset);
				} else {
					logo.removeAttribute('srcset');
				}
			}
		}
	}

	function applyMode(mode, persist) {
		var isDark = resolveDark(mode);

		root.setAttribute('data-edubin-color-mode', mode);
		root.setAttribute('data-edubin-theme', isDark ? 'dark' : 'light');
		root.setAttribute('data-edubin-color-preset', colorPreset);
		root.style.colorScheme = isDark ? 'dark' : 'light';
		updateElementorColors(isDark);
		updateElementorLogo(isDark);

		if (persist) {
			storeMode(mode);
		}

		updateButtons(isDark);
		updateMeta(isDark);
		dispatchChange(mode, isDark);
	}

	function runWithTransition(callback) {
		if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
			callback();
			return;
		}

		root.classList.add('edubin-theme-transition');
		callback();

		window.clearTimeout(transitionTimer);
		transitionTimer = window.setTimeout(function () {
			root.classList.remove('edubin-theme-transition');
		}, 360);
	}

	function toggleTheme() {
		var next = getAppliedTheme() === 'dark' ? 'light' : 'dark';

		runWithTransition(function () {
			applyMode(next, true);
		});
	}

	function handleSystemChange() {
		/* Only follow the OS when the current mode is "auto". */
		if ((root.getAttribute('data-edubin-color-mode') || defaultMode) !== 'auto') {
			return;
		}

		runWithTransition(function () {
			applyMode('auto', false);
		});
	}

	function init() {
		var stored = getStoredMode();
		var mode = stored || root.getAttribute('data-edubin-color-mode') || defaultMode;

		if (mode !== 'light' && mode !== 'dark' && mode !== 'auto') {
			mode = 'light';
		}

		applyMode(mode, false);
	}

	document.addEventListener('click', function (event) {
		var button = event.target.closest ? event.target.closest('.edubin-dark-mode-toggle') : null;

		if (!button) {
			return;
		}

		event.preventDefault();
		toggleTheme();
	});

	if (media) {
		if (media.addEventListener) {
			media.addEventListener('change', handleSystemChange);
		} else if (media.addListener) {
			media.addListener(handleSystemChange);
		}
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', init);
	} else {
		init();
	}

	// Small public API for Elementor integrations and custom scripts.
	window.edubinDarkMode = {
		getMode: function () {
			return root.getAttribute('data-edubin-color-mode') || defaultMode;
		},
		getTheme: getAppliedTheme,
		setMode: function (mode) {
			if (mode === 'light' || mode === 'dark' || mode === 'auto') {
				runWithTransition(function () {
					applyMode(mode, true);
				});
			}
		},
		toggle: toggleTheme
	};
})();
