<?php
/**
 * Theme functions and definitions
 *
 * @package Edubin
 */

// Define constants for theme directory and URI
define('EDUBIN_DIR', trailingslashit(get_template_directory()));
define('EDUBIN_URI', trailingslashit(get_template_directory_uri()));

// Define constant for theme version
define('EDUBIN_THEME_VERSION', wp_get_theme()->get('Version'));

/**
 * Load Theme Dependencies
 */
require_once get_theme_file_path('/inc/theme-dependencies.php');