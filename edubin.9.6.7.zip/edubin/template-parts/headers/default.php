<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

    $blog_single_layout = Edubin::setting( 'blog_single_layout' );
    do_action( 'edubin_before_header' );

    do_action( 'edubin_main_header' );

    if ($blog_single_layout == 'blog_layout_overlay' && is_single() && 'post' == get_post_type() ): 

        if ( have_posts() ) : while ( have_posts() ) : the_post();  // For blog single page image overlay 
        
             do_action( 'edubin_blog_image_overlay_header' );
        
         endwhile; endif; 
        
    elseif(class_exists('Academy') && is_singular('academy_courses' )): // Blank header for Academy LMS course single page

    elseif(Edubin::setting( 'page_header_show' )): 

        do_action( 'edubin_after_header' );

    endif;

