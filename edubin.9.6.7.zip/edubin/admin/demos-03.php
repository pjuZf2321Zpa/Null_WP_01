<?php
defined( 'ABSPATH' ) || exit;

function edubin_ocdi_import_update_options( $file ) {
    require_once ABSPATH . 'wp-admin/includes/class-wp-filesystem-base.php';
    require_once ABSPATH . 'wp-admin/includes/class-wp-filesystem-direct.php';
    $file_obj = new WP_Filesystem_Direct( array() );
    $datas = $file_obj->get_contents($file);
    $datas = json_decode( $datas, true );

    if ( count( array_filter( $datas ) ) < 1 ) :
        return;
    endif;

    if ( ! empty( $datas['page_options'] ) ) :
        edubin_ocdi_import_page_options( $datas['page_options'] );
    endif;
}

function edubin_ocdi_import_page_options( $datas ) {
    if ( $datas ) :
        foreach ( $datas as $option_name => $page_id ) :
            update_option( $option_name, $page_id );
        endforeach;
    endif;
}

function edubin_after_import_setup($selected_import)
{
    // Assign menus to their locations.
    $main_menu   = get_term_by('name', 'Primary', 'nav_menu');
    $footer_menu = get_term_by('name', 'Footer Menu', 'nav_menu');

    set_theme_mod('nav_menu_locations', array(
        'primary'     => $main_menu->term_id,
        'footer_menu' => $footer_menu->term_id,
    )
    );
    // LearnPress LMS
    if ('LearnPress LMS' === $selected_import['import_file_name']) {
        $front_page_id = get_page_by_path('home-learning-space-learnpress');
    } 
    // Tutor LMS
    elseif ('Tutor LMS' === $selected_import['import_file_name']) {
        $front_page_id = get_page_by_path('home-learning-space-tutor');
    }
    // LearnDash LMS
    elseif ('LearnDash LMS' === $selected_import['import_file_name']) {
        $front_page_id = get_page_by_path('home-online-academy-learndash');
    } 
    // Academy LMS
    elseif ('Academy LMS' === $selected_import['import_file_name']) {
        $front_page_id = get_page_by_path('home-learning-space-academy');
    } 
    // Masterstudy LMS
    elseif ('Masterstudy LMS' === $selected_import['import_file_name']) {
        $front_page_id = get_page_by_path('home-learning-space-masterstudy');
    } 
    // Sensei LMS
    elseif ('Sensei LMS' === $selected_import['import_file_name']) {
        $front_page_id = get_page_by_path('home-online-academy-sensei');
    } 
    // Lifter LMS
    elseif ('Lifter LMS' === $selected_import['import_file_name']) {
        $front_page_id = get_page_by_path('home-learning-space-lifter');
    }
    // RTL LearnPress LMS
    if ('RTL (LearnPress LMS)' === $selected_import['import_file_name']) {
        $front_page_id = get_page_by_path('rtl-home-learning-space-learnpress');
    } 
    // Dark LearnPress LMS
    if ('Dark (LearnPress LMS)' === $selected_import['import_file_name']) {
        $front_page_id = get_page_by_path('dark-home-learning-space-learnpress');
    } 

    $blog_page_id = get_page_by_title('Blog');
    update_option('show_on_front', 'page');
    $shop_page_id     = get_page_by_title( 'Shop' );
    $cart_page_id     = get_page_by_title( 'Cart' );
    $checkout_page_id = get_page_by_title( 'Checkout' );

    update_option('page_on_front', $front_page_id->ID);
    update_option('page_for_posts', $blog_page_id->ID);

    update_option( 'woocommerce_shop_page_id', $shop_page_id->ID );
    update_option( 'woocommerce_cart_page_id', $cart_page_id->ID );
    update_option( 'woocommerce_checkout_page_id', $checkout_page_id->ID );
    update_option( 'woocommerce_enable_myaccount_registration', 'yes' );

    update_option( 'elementor_container_width', 1200 );
    update_option( 'elementor_disable_color_schemes', 'yes' );
    update_option( 'elementor_disable_typography_schemes', 'yes' );
    update_option( 'elementor_global_image_lightbox', 0 );

    $file = trailingslashit( get_template_directory() ) . 'admin/update_options.json';
    if ( file_exists( $file ) ) :
        edubin_ocdi_import_update_options($file);
    endif;

    // Reset site permalink
    global $wp_rewrite;
    $wp_rewrite->set_permalink_structure('/%postname%/');

}
add_action('ocdi/after_import', 'edubin_after_import_setup');


/**
 * Edubin Theme: Complete After-Import Demo URL & Elementor JSON Replacer
 * Hooks into One Click Demo Import to cleanly map all dev paths to the live domain.
 */
add_action( 'ocdi/after_import', 'edubin_ocdi_complete_url_replacement' );

function edubin_ocdi_complete_url_replacement( $selected_import ) {
    global $wpdb;

    // 1. Dynamic detection of the customer's live site URL (e.g., https://my-site.com)
    $live_url = untrailingslashit( site_url() );

    // 2. Define the 4 target demo sub-sites
    $demo_paths = array(
        'devthrow.com/wp/edubin/tut',
        'devthrow.com/wp/edubin/rtl',
        'devthrow.com/wp/edubin/ld',
        'devthrow.com/wp/edubin/lp',
        'devthrow.com/wp/edubin/mst',
        'devthrow.com/wp/edubin/sen',
        'devthrow.com/wp/edubin/lif',
        'devthrow.com/wp/edubin/cr',
        'devthrow.com/wp/edubin/ac',        
        'devthrow.com/wp/edubin/dark',        
        'devthrow.com/edubin/tut',
        'devthrow.com/edubin/rtl',
        'devthrow.com/edubin/ld',
        'devthrow.com/edubin/lp',
        'devthrow.com/edubin/mst',
        'devthrow.com/edubin/sen',
        'devthrow.com/edubin/lif',
        'devthrow.com/edubin/cr',
        'devthrow.com/edubin/ac',
    );

    $replacements = array();

    // Generate standard and JSON-escaped variations
    foreach ( $demo_paths as $path ) {
        // --- Standard URL Mapping (Slashed versions first to prevent double-slash bugs) ---
        $replacements[ 'https://' . $path . '/' ] = $live_url . '/';
        $replacements[ 'http://' . $path . '/' ]  = $live_url . '/';
        $replacements[ 'https://' . $path ]       = $live_url;
        $replacements[ 'http://' . $path ]        = $live_url;

        // --- Elementor / JSON Escaped Mapping (Converts / to \/) ---
        $escaped_path = str_replace( '/', '\/', $path );
        $escaped_live = str_replace( '/', '\/', $live_url );

        $replacements[ 'https:\/\/' . $escaped_path . '\/' ] = $escaped_live . '\/';
        $replacements[ 'http:\/\/' . $escaped_path . '\/' ]  = $escaped_live . '\/';
        $replacements[ 'https:\/\/' . $escaped_path ]       = $escaped_live;
        $replacements[ 'http:\/\/' . $escaped_path ]        = $escaped_live;
    }

    $search_keys  = array_keys( $replacements );
    $replace_vals = array_values( $replacements );

    // SQL wildcard pattern that catches both standard ('/') and escaped ('\/') DB rows
    $sql_like = '%' . $wpdb->esc_like( 'devthrow.com' ) . '%' . $wpdb->esc_like( 'edubin' ) . '%';

    /*-------------------------------------------------------------------------
     * PART A: Update wp_posts (Content, Excerpts, Menu Items, GUIDs)
     *------------------------------------------------------------------------*/
    $posts = $wpdb->get_results( $wpdb->prepare(
        "SELECT ID, post_content, post_excerpt, guid FROM {$wpdb->posts} 
         WHERE post_content LIKE %s OR post_excerpt LIKE %s OR guid LIKE %s",
        $sql_like, $sql_like, $sql_like
    ) );

    if ( ! empty( $posts ) ) {
        foreach ( $posts as $post ) {
            $wpdb->update(
                $wpdb->posts,
                array(
                    'post_content' => str_replace( $search_keys, $replace_vals, $post->post_content ),
                    'post_excerpt' => str_replace( $search_keys, $replace_vals, $post->post_excerpt ),
                    'guid'         => str_replace( $search_keys, $replace_vals, $post->guid ),
                ),
                array( 'ID' => $post->ID ),
                array( '%s', '%s', '%s' ),
                array( '%d' )
            );
        }
    }

    /*-------------------------------------------------------------------------
     * PART B: Update wp_postmeta (Elementor Data, Widget Settings, Custom Fields)
     *------------------------------------------------------------------------*/
    $postmetas = $wpdb->get_results( $wpdb->prepare(
        "SELECT meta_id, meta_value FROM {$wpdb->postmeta} WHERE meta_value LIKE %s",
        $sql_like
    ) );

    if ( ! empty( $postmetas ) ) {
        foreach ( $postmetas as $meta ) {
            $new_meta_val = edubin_recursive_string_replace( $search_keys, $replace_vals, $meta->meta_value );
            if ( $new_meta_val !== $meta->meta_value ) {
                $wpdb->update(
                    $wpdb->postmeta,
                    array( 'meta_value' => $new_meta_val ),
                    array( 'meta_id' => $meta->meta_id ),
                    array( '%s' ),
                    array( '%d' )
                );
            }
        }
    }

    /*-------------------------------------------------------------------------
     * PART C: Update wp_options (Customizer settings, Theme choices, Widgits)
     *------------------------------------------------------------------------*/
    $options = $wpdb->get_results( $wpdb->prepare(
        "SELECT option_id, option_value FROM {$wpdb->options} 
         WHERE option_value LIKE %s AND option_name NOT LIKE '_transient%%'",
        $sql_like
    ) );

    if ( ! empty( $options ) ) {
        foreach ( $options as $option ) {
            $new_opt_val = edubin_recursive_string_replace( $search_keys, $replace_vals, $option->option_value );
            if ( $new_opt_val !== $option->option_value ) {
                $wpdb->update(
                    $wpdb->options,
                    array( 'option_value' => $new_opt_val ),
                    array( 'option_id' => $option->option_id ),
                    array( '%s' ),
                    array( '%d' )
                );
            }
        }
    }

    /*-------------------------------------------------------------------------
     * PART D: Housekeeping (Cache Eviction & Permalinks Rebuild)
     *------------------------------------------------------------------------*/
    // 1. Clear internal WordPress engine cache
    wp_cache_flush();

    // 2. Force Elementor to purge broken CSS layout files and regenerate
    if ( class_exists( '\Elementor\Plugin' ) ) {
        \Elementor\Plugin::$instance->files_manager->clear_cache();
    }

    // 3. Automatically rebuild site permalinks rules (fixes broken links & custom post loops)
    flush_rewrite_rules( true );
}

/**
 * Clean Unserializer & Replacement Tool
 * Traverses normal text, standard arrays, objects, and deeply nested serialized strings safely.
 */
if ( ! function_exists( 'edubin_recursive_string_replace' ) ) {
    function edubin_recursive_string_replace( $search, $replace, $data ) {
        if ( is_string( $data ) ) {
            // Check if string is a PHP serialized array/object
            if ( is_serialized( $data ) ) {
                $unserialized = @unserialize( $data );
                if ( $unserialized !== false || $data === 'b:0;' ) {
                    return serialize( edubin_recursive_string_replace( $search, $replace, $unserialized ) );
                }
            }
            // Fallback to basic string or JSON string replacement
            return str_replace( $search, $replace, $data );

        } elseif ( is_array( $data ) ) {
            $array_holder = array();
            foreach ( $data as $key => $value ) {
                $array_holder[ $key ] = edubin_recursive_string_replace( $search, $replace, $value );
            }
            return $array_holder;

        } elseif ( is_object( $data ) ) {
            $object_holder = new stdClass();
            foreach ( $data as $key => $value ) {
                $object_holder->$key = edubin_recursive_string_replace( $search, $replace, $value );
            }
            return $object_holder;
        }

        return $data;
    }
}
