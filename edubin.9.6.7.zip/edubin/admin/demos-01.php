<?php
defined( 'ABSPATH' ) || exit;

function edubin_import_files()
{

    $specific_path = 'eb-24037792/';
    $ocdi_repo = edubin_ocdi_plugin_repo();
    $ocdi_dif_main = '/dtf/main/';
    $repo_path = $ocdi_repo . $ocdi_dif_main;
    $site_url = 'https://devthrow.com/edubin/';
    $main_url = 'https://raw.githubusercontent.com/';

        $get_demos = array();

        $get_demos[] = array(
            'import_file_name'             => 'LearnPress LMS',
            'categories'                   => array('LearnPress'),
            'import_file_url'              => $main_url . $repo_path . $specific_path . 'lp/content.xml',
            'import_widget_file_url'       => $main_url . $repo_path . $specific_path . 'lp/widget_data.wie',
            'import_customizer_file_url'   => $main_url . $repo_path . $specific_path . 'lp/customizer.dat',
            'import_preview_image_url'     => EDUBIN_URI . 'admin/demo/images/license.jpg',
            'preview_url'                  => $site_url . 'lp',

        );
        $get_demos[] = array(
            'import_file_name'             => 'Tutor LMS',
            'categories'                   => array('Tutor'),
            'import_file_url'              => $main_url . $repo_path . $specific_path . 'tut/content.xml',
            'import_widget_file_url'       => $main_url . $repo_path . $specific_path . 'tut/widget_data.wie',
            'import_customizer_file_url'   => $main_url . $repo_path . $specific_path . 'tut/customizer.dat',
            'import_preview_image_url'     => EDUBIN_URI . 'admin/demo/images/license.jpg',
            'preview_url'                  => $site_url . 'tut',
        );
        $get_demos[] = array(
            'import_file_name'             => 'LearnDash LMS',
            'categories'                   => array('LearnDash'),
            'import_file_url'              => $main_url . $repo_path . $specific_path . 'ld/content.xml',
            'import_widget_file_url'       => $main_url . $repo_path . $specific_path . 'ld/widget_data.wie',
            'import_customizer_file_url'   => $main_url . $repo_path . $specific_path . 'ld/customizer.dat',
            'import_preview_image_url'     => EDUBIN_URI . 'admin/demo/images/license.jpg',
            'preview_url'                  => $site_url . 'ld',
        );
        $get_demos[] = array(
            'import_file_name'             => 'Academy LMS',
            'categories'                   => array('Academy'),
            'import_file_url'              => $main_url . $repo_path . $specific_path . 'ac/content.xml',
            'import_widget_file_url'       => $main_url . $repo_path . $specific_path . 'ac/widget_data.wie',
            'import_customizer_file_url'   => $main_url . $repo_path . $specific_path . 'ac/customizer.dat',
            'import_preview_image_url'     => EDUBIN_URI . 'admin/demo/images/license.jpg',
            'preview_url'                  => $site_url . 'ac',
        );
        $get_demos[] = array(
            'import_file_name'             => 'Sensei LMS',
            'categories'                   => array('Sensei'),
            'import_file_url'              => $main_url . $repo_path . $specific_path . 'sen/content.xml',
            'import_widget_file_url'       => $main_url . $repo_path . $specific_path . 'sen/widget_data.wie',
            'import_customizer_file_url'   => $main_url . $repo_path . $specific_path . 'sen/customizer.dat',
            'import_preview_image_url'     => EDUBIN_URI . 'admin/demo/images/license.jpg',
            'preview_url'                  => $site_url . 'sen',
        );
        $get_demos[] = array(
            'import_file_name'             => 'MasterStudy LMS',
            'categories'                   => array('Masterstudy'),
            'import_file_url'              => $main_url . $repo_path . $specific_path . 'mst/content.xml',
            'import_widget_file_url'       => $main_url . $repo_path . $specific_path . 'mst/widget_data.wie',
            'import_customizer_file_url'   => $main_url . $repo_path . $specific_path . 'mst/customizer.dat',
            'import_preview_image_url'     => EDUBIN_URI . 'admin/demo/images/license.jpg',
            'preview_url'                  => $site_url . 'mst',
        );  
        $get_demos[] = array(
            'import_file_name'             => 'LifterLMS',
            'categories'                   => array('LifterLMS'),
            'import_file_url'              => $main_url . $repo_path . $specific_path . 'lif/content.xml',
            'import_widget_file_url'       => $main_url . $repo_path . $specific_path . 'lif/widget_data.wie',
            'import_customizer_file_url'   => $main_url . $repo_path . $specific_path . 'lif/customizer.dat',
            'import_preview_image_url'     => EDUBIN_URI . 'admin/demo/images/license.jpg',
            'preview_url'                  => $site_url . 'lif',
        );
        $get_demos[] = array(
            'import_file_name'             => 'RTL (LearnPress LMS)',
            'categories'                   => array('RTL'),
            'import_file_url'              => $main_url . $repo_path . $specific_path . 'rtl/content.xml',
            'import_widget_file_url'       => $main_url . $repo_path . $specific_path . 'rtl/widget_data.wie',
            'import_customizer_file_url'   => $main_url . $repo_path . $specific_path . 'rtl/customizer.dat',
            'import_preview_image_url'     => EDUBIN_URI . 'admin/demo/images/license-rtl.jpg',
            'preview_url'                  => $site_url . 'rtl',
        );
        $get_demos[] = array(
            'import_file_name'             => 'Dark (LearnPress LMS)',
            'categories'                   => array('Dark'),
            'import_file_url'              => $main_url . $repo_path . $specific_path . 'dk/content.xml',
            'import_widget_file_url'       => $main_url . $repo_path . $specific_path . 'dk/widget_data.wie',
            'import_customizer_file_url'   => $main_url . $repo_path . $specific_path . 'dk/customizer.dat',
            'import_preview_image_url'     => EDUBIN_URI . 'admin/demo/images/license-dk.jpg',
            'preview_url'                  => $site_url . 'dark',
        );

    return apply_filters( 'edubin_ocdi_demo_files_args', $get_demos );
}
