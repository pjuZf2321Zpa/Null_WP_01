<?php
defined( 'ABSPATH' ) || exit;

function edubin_import_flies()
{
    return array(
        array(
            'import_file_name'             => 'LearnPress LMS',
            'categories'                   => array('LearnPress'),
            'import_preview_image_url'     => EDUBIN_URI . 'admin/demo/images/license.jpg',
        ),
        array(
            'import_file_name'             => 'Tutor LMS',
            'categories'                   => array('Tutor'),
            'import_preview_image_url'     => EDUBIN_URI . 'admin/demo/images/license.jpg',
        ),
        array(
            'import_file_name'             => 'LearnDash LMS',
            'categories'                   => array('LearnDash'),
            'import_preview_image_url'     => EDUBIN_URI . 'admin/demo/images/license.jpg',
        ),
        array(
            'import_file_name'             => 'Academy LMS',
            'categories'                   => array('Academy'),
            'import_preview_image_url'     => EDUBIN_URI . 'admin/demo/images/license.jpg',
        ),
        array(
            'import_file_name'             => 'Sensei LMS',
            'categories'                   => array('Sensei'),
            'import_preview_image_url'     => EDUBIN_URI . 'admin/demo/images/license.jpg',
        ),
        array(
            'import_file_name'             => 'MasterStudy LMS',
            'categories'                   => array('MasterStudy'),
            'import_preview_image_url'     => EDUBIN_URI . 'admin/demo/images/license.jpg',
        ), 
        array(
            'import_file_name'             => 'RTL (LearnPress LMS)',
            'categories'                   => array('RTL'),
            'import_preview_image_url'     => EDUBIN_URI . 'admin/demo/images/license-rtl.jpg',
        ),
        array(
            'import_file_name'             => 'Dark (LearnPress LMS)',
            'categories'                   => array('Dark'),
            'import_preview_image_url'     => EDUBIN_URI . 'admin/demo/images/license-dk.jpg',
        ),
       
    );
}
