<?php
defined( 'ABSPATH' ) || exit;

function edubin_ocdi_register_plugins( $plugins ) {

    $lms_plugins = [];
    $site_url = 'https://devthrow.com';
    $repo_path = '/envato/file/';
    $specific_path = edubin_ocdi_plugin_repo_value();
    $ld007634 = 'sfwd-lms.zip';
    $get_slug = $site_url . $repo_path . $specific_path . $ld007634;

    if ( isset( $_GET['step'] ) && $_GET['step'] === 'import' && isset( $_GET['import'] ) ) :
 
        if ( $_GET['import'] === '0') :
            $lms_plugins = [
                [
                    'name'     => 'LearnPress LMS',
                    'slug'     => 'learnpress',
                    'required' => true
                ],
                [
                    'name'     => 'LearnPress - Course Review',
                    'slug'     => 'learnpress-course-review',
                    'required' => true
                ],
                [
                    'name'     => 'LearnPress – Course Wishlist',
                    'slug'     => 'learnpress-wishlist',
                    'required' => true
                ],
                [
                    'name'     => esc_html__('WooCommerce', 'edubin'),
                    'slug'     => 'woocommerce',
                    'required' => true
                ],
                [
                    'name'     => esc_html__('WP Events Manager', 'edubin'),
                    'slug'     => 'wp-events-manager',
                    'required' => true
                ],
                [
                    'name'      => esc_html__('Contact Form 7','edubin'),
                    'slug'      => 'contact-form-7',
                    'required'  => true,
                ],
                [
                    'name'      => esc_html__('Video Conferencing with Zoom','edubin'),
                    'slug'      => 'video-conferencing-with-zoom-api',
                    'required'  => true,
                ]
            ];
        endif;
 
        if ( $_GET['import'] === '1' ) :
            $lms_plugins = [
                [
                    'name'     => 'Tutor LMS',
                    'slug'     => 'tutor',
                    'required' => true
                ],
                [
                    'name'     => esc_html__('WooCommerce', 'edubin'),
                    'slug'     => 'woocommerce',
                    'required' => true
                ],
                [
                    'name'     => esc_html__('WP Events Manager', 'edubin'),
                    'slug'     => 'wp-events-manager',
                    'required' => true
                ],
                [
                    'name'      => esc_html__('Contact Form 7','edubin'),
                    'slug'      => 'contact-form-7',
                    'required'  => true,
                ],
                [
                    'name'      => esc_html__('Video Conferencing with Zoom','edubin'),
                    'slug'      => 'video-conferencing-with-zoom-api',
                    'required'  => true,
                ]
            ];
        endif;
 
        if ( $_GET['import'] === '2' ) :
            $lms_plugins = [
                [
                    'name'     => 'LaernDash LMS',
                    'slug'     => 'sfwd-lms',
                    'source'      => $get_slug,
                    'required' => true
                ],
                [
                    'name'     => esc_html__('WooCommerce', 'edubin'),
                    'slug'     => 'woocommerce',
                    'required' => true
                ],
                [
                    'name'     => esc_html__('WP Events Manager', 'edubin'),
                    'slug'     => 'wp-events-manager',
                    'required' => true
                ],
                [
                    'name'      => esc_html__('Contact Form 7','edubin'),
                    'slug'      => 'contact-form-7',
                    'required'  => true,
                ],
                [
                    'name'      => esc_html__('Video Conferencing with Zoom','edubin'),
                    'slug'      => 'video-conferencing-with-zoom-api',
                    'required'  => true,
                ]
            ];
        endif;

        if ( $_GET['import'] === '3' ) :
            $lms_plugins = [
                [
                    'name'     => 'Academy LMS',
                    'slug'     => 'academy',
                    'required' => true
                ],
                [
                    'name'     => esc_html__('WooCommerce', 'edubin'),
                    'slug'     => 'woocommerce',
                    'required' => true
                ],
                [
                    'name'     => esc_html__('WP Events Manager', 'edubin'),
                    'slug'     => 'wp-events-manager',
                    'required' => true
                ],
                [
                    'name'      => esc_html__('Contact Form 7','edubin'),
                    'slug'      => 'contact-form-7',
                    'required'  => true,
                ],
                [
                    'name'      => esc_html__('Video Conferencing with Zoom','edubin'),
                    'slug'      => 'video-conferencing-with-zoom-api',
                    'required'  => true,
                ]
            ];
        endif;

        if ( $_GET['import'] === '4' ) :
            $lms_plugins = [
                [
                    'name'     => 'Sensei LMS',
                    'slug'     => 'sensei-lms',
                    'required' => true
                ],
                [
                    'name'     => esc_html__('WooCommerce', 'edubin'),
                    'slug'     => 'woocommerce',
                    'required' => true
                ],
                [
                    'name'     => esc_html__('WP Events Manager', 'edubin'),
                    'slug'     => 'wp-events-manager',
                    'required' => true
                ],
                [
                    'name'      => esc_html__('Contact Form 7','edubin'),
                    'slug'      => 'contact-form-7',
                    'required'  => true,
                ],
                [
                    'name'      => esc_html__('Video Conferencing with Zoom','edubin'),
                    'slug'      => 'video-conferencing-with-zoom-api',
                    'required'  => true,
                ]
            ];
        endif;

        if ( $_GET['import'] === '5' ) :
            $lms_plugins = [
                [
                    'name'     => 'MasterStudy LMS',
                    'slug'     => 'masterstudy-lms-learning-management-system',
                    'required' => true
                ],
                [
                    'name'     => esc_html__('WooCommerce', 'edubin'),
                    'slug'     => 'woocommerce',
                    'required' => true
                ],
                [
                    'name'     => esc_html__('WP Events Manager', 'edubin'),
                    'slug'     => 'wp-events-manager',
                    'required' => true
                ],
                [
                    'name'      => esc_html__('Contact Form 7','edubin'),
                    'slug'      => 'contact-form-7',
                    'required'  => true,
                ],
                [
                    'name'      => esc_html__('Video Conferencing with Zoom','edubin'),
                    'slug'      => 'video-conferencing-with-zoom-api',
                    'required'  => true,
                ]
            ];
        endif;
 
        if ( $_GET['import'] === '6' ) :
            $lms_plugins = [
                [
                    'name'     => 'LifterLMS',
                    'slug'     => 'lifterlms',
                    'required' => true
                ],
                [
                    'name'     => esc_html__('WooCommerce', 'edubin'),
                    'slug'     => 'woocommerce',
                    'required' => true
                ],
                [
                    'name'     => esc_html__('WP Events Manager', 'edubin'),
                    'slug'     => 'wp-events-manager',
                    'required' => true
                ],
                [
                    'name'      => esc_html__('Contact Form 7','edubin'),
                    'slug'      => 'contact-form-7',
                    'required'  => true,
                ],
                [
                    'name'      => esc_html__('Video Conferencing with Zoom','edubin'),
                    'slug'      => 'video-conferencing-with-zoom-api',
                    'required'  => true,
                ]
            ];
        endif;

        // For RTL Demo 
        if ( $_GET['import'] === '7' ) :
            $lms_plugins = [
                [
                    'name'     => 'LearnPress LMS',
                    'slug'     => 'learnpress',
                    'required' => true
                ],
                [
                    'name'     => 'LearnPress - Course Review',
                    'slug'     => 'learnpress-course-review',
                    'required' => true
                ],
                [
                    'name'     => 'LearnPress – Course Wishlist',
                    'slug'     => 'learnpress-wishlist',
                    'required' => true
                ],
                [
                    'name'     => esc_html__('WooCommerce', 'edubin'),
                    'slug'     => 'woocommerce',
                    'required' => true
                ],
                [
                    'name'     => esc_html__('WP Events Manager', 'edubin'),
                    'slug'     => 'wp-events-manager',
                    'required' => true
                ],
                [
                    'name'      => esc_html__('Contact Form 7','edubin'),
                    'slug'      => 'contact-form-7',
                    'required'  => true,
                ],
                [
                    'name'      => esc_html__('Video Conferencing with Zoom','edubin'),
                    'slug'      => 'video-conferencing-with-zoom-api',
                    'required'  => true,
                ]
            ];
        endif;
 
        // For Dark Demo 
        if ( $_GET['import'] === '8' ) :
            $lms_plugins = [
                [
                    'name'     => 'LearnPress LMS',
                    'slug'     => 'learnpress',
                    'required' => true
                ],
                [
                    'name'     => 'LearnPress - Course Review',
                    'slug'     => 'learnpress-course-review',
                    'required' => true
                ],
                [
                    'name'     => 'LearnPress – Course Wishlist',
                    'slug'     => 'learnpress-wishlist',
                    'required' => true
                ],
                [
                    'name'     => esc_html__('WooCommerce', 'edubin'),
                    'slug'     => 'woocommerce',
                    'required' => true
                ],
                [
                    'name'     => esc_html__('WP Events Manager', 'edubin'),
                    'slug'     => 'wp-events-manager',
                    'required' => true
                ],
                [
                    'name'      => esc_html__('Contact Form 7','edubin'),
                    'slug'      => 'contact-form-7',
                    'required'  => true,
                ],
                [
                    'name'      => esc_html__('Video Conferencing with Zoom','edubin'),
                    'slug'      => 'video-conferencing-with-zoom-api',
                    'required'  => true,
                ]
            ];
        endif;
 
    endif;
 
    return array_merge( $plugins, $lms_plugins );
}
add_filter( 'ocdi/register_plugins', 'edubin_ocdi_register_plugins' );