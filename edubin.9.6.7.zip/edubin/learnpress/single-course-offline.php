<?php
/**
 * Template for displaying content of single course offline.
 *
 * @author  ThimPress
 * @package LearnPress/Templates
 * @version 4.2.7
 * @version 1.0.1
 */

use LearnPress\Models\CourseModel;

defined( 'ABSPATH' ) || exit;

/**
 * Header for page
 */
if ( ! wp_is_block_theme() ) {
	do_action( 'learn-press/template-header' );
}

$lp_single_page_layout = Edubin::setting('lp_single_page_layout');

if (in_array($lp_single_page_layout, ['1', '2', '3', '4', '5', '6'])) {
    get_template_part('learnpress/tpl-part/single/single-layout', $lp_single_page_layout);
}

/**
 * Footer for page
 */
if ( ! wp_is_block_theme() ) {
	do_action( 'learn-press/template-footer' );
}
