<?php
/**
 * The template for displaying LearnPress single page
 */
get_header();

$lp_single_page_layout = Edubin::setting('lp_single_page_layout');

if (in_array($lp_single_page_layout, ['1', '2', '3', '4', '5', '6'])) {
    get_template_part('learnpress/tpl-part/single/single-layout', $lp_single_page_layout);
}

get_footer();
