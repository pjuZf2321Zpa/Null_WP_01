<?php
/**
 * Template for displaying meta primary
 * Edit by Nhamdv
 *
 * @author   ThimPress
 * @package  Learnpress/Templates
 * @version  4.0.12
 */