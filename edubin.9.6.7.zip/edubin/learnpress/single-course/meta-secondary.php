<?php
/**
 * Template for displaying meta secondary
 * Edit by Nhamdv
 *
 * @author   ThimPress
 * @package  Learnpress/Templates
 * @version  4.0.12
 */