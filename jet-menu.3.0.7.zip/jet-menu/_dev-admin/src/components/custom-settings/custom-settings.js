function hasValue( value ) {
	if ( typeof value === "string" ) {
		return value.trim() !== "";
	}

	return typeof value === "number" && Number.isFinite( value );
}

function numberValue( value ) {
	if ( ! hasValue( value ) ) {
		return null;
	}

	const number = Number( value );

	return Number.isFinite( number ) ? number : null;
}

function isEnabled( value ) {
	if ( value === true || value === 1 ) {
		return true;
	}

	if ( typeof value !== "string" ) {
		return false;
	}

	const enabledValues = [ "true", "1", "yes", "on" ];

	return enabledValues.includes( value.toLowerCase() );
}

/**
 * Return customized nextgen item sections in display order, ignoring saved defaults.
 */
export function getCustomSettingsSections( settings = {} ) {
	if ( ! settings || typeof settings !== "object" || Array.isArray( settings ) ) {
		return [];
	}

	const sections = [];

	if ( numberValue( settings.menu_svg ) > 0 ) {
		sections.push( "icon" );
	}

	const hasBadgeContent = settings.menu_badge_type === "svg"
		? numberValue( settings.badge_svg ) > 0
		: hasValue( settings.menu_badge );

	if ( hasBadgeContent ) {
		sections.push( "badge" );
	}

	const isLabelHidden = isEnabled( settings.hide_item_text );
	const paddingSides = [ "top", "right", "bottom", "left" ];
	const hasCustomPadding = paddingSides.some( ( side ) => {
		return hasValue( settings.item_padding?.[ side ] );
	} );

	if ( isLabelHidden || hasCustomPadding ) {
		sections.push( "advanced" );
	}

	const dynamicVisibility = settings.dynamic_visibility;
	const isVisibilityEnabled = isEnabled( dynamicVisibility?.enabled );
	const hasVisibilityRules = Array.isArray( dynamicVisibility?.rules )
		&& dynamicVisibility.rules.length > 0;

	if ( isVisibilityEnabled && hasVisibilityRules ) {
		sections.push( "visibility" );
	}

	return sections;
}
