import { Tooltip } from "@wordpress/components";
import { __, sprintf } from "@wordpress/i18n";
import { getCustomSettingsSections } from "./custom-settings";
import "./custom-settings.scss";

export default function CustomSettingsIndicator( { settings } ) {
	const sections = getCustomSettingsSections( settings );

	if ( ! sections.length ) {
		return null;
	}

	const labels = {
		icon: __( "Item Icon", "jet-menu" ),
		badge: __( "Item Badge", "jet-menu" ),
		advanced: __( "Advanced", "jet-menu" ),
		visibility: __( "Dynamic Visibility", "jet-menu" ),
	};
	const sectionNames = sections.map( ( section ) => labels[ section ] ).join( ", " );

	const description = sprintf(
		/* translators: %s: comma-separated customized menu item sections. */
		__( "Custom settings: %s", "jet-menu" ),
		sectionNames
	);

	return (
		<Tooltip
			text={ description }
			className="jet-menu-custom-settings-tooltip"
		>
			<span
				className="jet-menu-custom-settings"
				tabIndex={ 0 }
				aria-label={ description }
			>
				{ __( "Custom settings", "jet-menu" ) }
			</span>
		</Tooltip>
	);
}
