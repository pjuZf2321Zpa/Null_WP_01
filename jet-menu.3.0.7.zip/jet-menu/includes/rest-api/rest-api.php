<?php
namespace Jet_Menu;

/**
 * API controller class
 */
// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}
/**
 * Define Controller class
 */
class Rest_Api {

	/**
	 * A reference to an instance of this class.
	 *
	 * @since 1.0.0
	 * @var   object
	 */
	private static $instance = null;

	/**
	 * [$api_namespace description]
	 * @var string
	 */
	public $api_namespace = 'jet-menu-api/v2';

	/**
	 * [$_endpoints description]
	 * @var null
	 */
	private $_endpoints = null;

	/**
	 * Returns the instance.
	 *
	 * @since  1.0.0
	 * @return object
	 */
	public static function get_instance() {

		// If the single instance hasn't been set, set it now.
		if ( null == self::$instance ) {
			self::$instance = new self;
		}
		return self::$instance;
	}

	// Here initialize our namespace and resource name.
	public function __construct() {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	/**
	 * Initialize all JetEngine related Rest API endpoints
	 *
	 * @return [type] [description]
	 */
	public function init_endpoints() {

		$this->_endpoints = array();

		$this->register_endpoint( new Endpoints\Clear_Cache() );
		$this->register_endpoint( new Endpoints\Get_Blocks_Template_Content() );
		$this->register_endpoint( new Endpoints\Get_Elementor_Template_Content() );
		$this->register_endpoint( new Endpoints\Plugin_Settings() );
		$this->register_endpoint( new Endpoints\Get_Menu_Items() );

		do_action( 'jet-menu/rest/init-endpoints', $this );

	}

	/**
	 * Register new endpoint
	 *
	 * @param  object $endpoint_instance Endpoint instance
	 * @return void
	 */
	public function register_endpoint( $endpoint_instance = null ) {

		if ( $endpoint_instance ) {
			$this->_endpoints[ $endpoint_instance->get_name() ] = $endpoint_instance;
		}

	}

	/**
	 * Returns all registererd API endpoints
	 *
	 * @return [type] [description]
	 */
	public function get_endpoints() {

		if ( null === $this->_endpoints ) {
			$this->init_endpoints();
		}

		return $this->_endpoints;

	}

	/**
	 * Returns endpoints URLs
	 */
	public function get_endpoints_urls() {

		$result    = array();
		$endpoints = $this->get_endpoints();

		foreach ( $endpoints as $endpoint ) {
			$key = str_replace( '-', '', ucwords( $endpoint->get_name(), '-' ) );
			$result[ $key ] = get_rest_url( null, $this->api_namespace . '/' . $endpoint->get_name() . '/' . $endpoint->get_query_params() , 'rest' );
		}

		return $result;

	}

	/**
	 * Returns route to passed endpoint
	 *
	 * @return [type] [description]
	 */
	public function get_route( $endpoint = '', $full = false ) {

		$path = $this->api_namespace . '/' . $endpoint . '/';

		if ( ! $full ) {
			return $path;
		} else {
			return get_rest_url( null, $path );
		}

	}

	// Register our routes.
	public function register_routes() {

		if ( jet_menu_tools()->is_nextgen_mode() ) {
			register_rest_field( 'nav_menu_item', 'jet_menu_settings', array(
				'get_callback' => array( $this, 'get_menu_item_settings' ),
				'schema'       => array(
					'type'     => 'object',
					'context'  => array( 'edit' ),
					'readonly' => true,
				),
			) );
		}

		$endpoints = $this->get_endpoints();

		foreach ( $endpoints as $endpoint ) {

			$args = array(
				'methods'             => $endpoint->get_method(),
				'callback'            => array( $endpoint, 'callback' ),
				'permission_callback' => array( $endpoint, 'permission_callback' ),
			);

			$endpoint_args = $endpoint->get_args();

			if ( ! empty( $endpoint_args ) ) {
				$args['args'] = $endpoint->get_args();
			}

			$route = '/' . $endpoint->get_name() . '/' . $endpoint->get_query_params();

			register_rest_route( $this->api_namespace, $route, $args );
		}
	}

	/**
	 * Returns recognized menu item settings for authorized REST edit requests.
	 *
	 * @param array           $item       Menu item data.
	 * @param string          $field_name REST field name.
	 * @param WP_REST_Request $request    Current REST request.
	 *
	 * @return object|null
	 */
	public function get_menu_item_settings( $item, $field_name, $request ) {
		$item_id = isset( $item['id'] ) ? absint( $item['id'] ) : 0;

		if ( 'edit' !== $request->get_param( 'context' ) || ! $item_id ||
			! current_user_can( 'manage_options' ) || ! current_user_can( 'edit_post', $item_id ) ) {

			return null;
		}

		$manager = jet_menu()->settings_manager;
		$settings = $manager->get_item_settings( $item_id );

		return (object) array_intersect_key(
			is_array( $settings ) ? $settings : array(),

			$manager->default_nav_item_controls_data()
		);
	}

}

