<?php

declare(strict_types=1);

namespace MobileDetect_4_11_0\Detection\Exception;

class MobileDetectException extends \Exception
{
}
