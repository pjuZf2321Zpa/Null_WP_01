<?php

declare(strict_types=1);

namespace MobileDetect_4_11_0\Detection\Cache;

use MobileDetect_4_11_0\Psr\SimpleCache\InvalidArgumentException;

class CacheInvalidArgumentException extends CacheException implements InvalidArgumentException
{
}
