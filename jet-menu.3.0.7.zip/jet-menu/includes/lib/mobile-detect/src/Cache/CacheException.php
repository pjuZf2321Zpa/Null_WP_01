<?php

declare(strict_types=1);

namespace MobileDetect_4_11_0\Detection\Cache;

class CacheException extends \Exception implements \MobileDetect_4_11_0\Psr\SimpleCache\CacheException
{
}
