<?php
/** Load or reuse the shared, versioned Mobile Detect package for this PHP. */
if ( ! defined( 'WPINC' ) ) {
	die;
}

if ( PHP_VERSION_ID < 80200 ) {
	if ( ! class_exists( 'MobileDetect_3_74_0\Detection\MobileDetect', false ) ) {
		require_once dirname( __DIR__ ) . '/class-mobile-detect.php';
	}
	return;
}

// Keep PHP 8.2+ code out of the older-PHP path. Other plugins may have loaded
// all or part of this exact package; check each symbol without autoloading.
foreach ( array(
	'Psr\SimpleCache\CacheException'                => 'standalone/deps/simple-cache/src/CacheException.php',
	'Psr\SimpleCache\InvalidArgumentException'      => 'standalone/deps/simple-cache/src/InvalidArgumentException.php',
	'Psr\SimpleCache\CacheInterface'                => 'standalone/deps/simple-cache/src/CacheInterface.php',
	'Detection\Exception\MobileDetectException'     => 'src/Exception/MobileDetectException.php',
	'Detection\Exception\MobileDetectExceptionCode' => 'src/Exception/MobileDetectExceptionCode.php',
	'Detection\Cache\CacheException'                => 'src/Cache/CacheException.php',
	'Detection\Cache\CacheInvalidArgumentException' => 'src/Cache/CacheInvalidArgumentException.php',
	'Detection\Cache\Cache'                         => 'src/Cache/Cache.php',
	'Detection\MobileDetect'                        => 'src/MobileDetect.php',
) as $jet_menu_mobile_detect_class => $jet_menu_mobile_detect_file ) {
	$jet_menu_mobile_detect_class = 'MobileDetect_4_11_0\\' . $jet_menu_mobile_detect_class;
	if ( ! class_exists( $jet_menu_mobile_detect_class, false ) && ! interface_exists( $jet_menu_mobile_detect_class, false ) ) {
		require_once __DIR__ . '/' . $jet_menu_mobile_detect_file;
	}
}
unset( $jet_menu_mobile_detect_class, $jet_menu_mobile_detect_file );
