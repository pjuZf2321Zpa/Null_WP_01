<?php return array('dependencies' => array(), 'version' => 'b18ae3635609f0f04daf');
