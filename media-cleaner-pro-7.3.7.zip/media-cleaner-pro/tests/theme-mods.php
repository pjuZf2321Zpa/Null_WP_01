<?php
// Standalone check for the Customizer references: php -d zend.assertions=1 tests/theme-mods.php
// No WordPress, no framework. A theme mod this misses is an image on a live page offered up for
// deletion, which is how a homepage's Customizer images were flagged.

function __( $s, $d = null ) { return $s; }
function is_wp_error( $t ) { return false; }
function trailingslashit( $s ) { return rtrim( $s, '/' ) . '/'; }
function wp_parse_url( $url, $component = -1 ) { return parse_url( $url, $component ); }

class FakeWpdb {
	public $options = 'wp_options';
	public $last_error = '';
	public $num_queries = 0;
	public function get_col( $sql ) { return array_keys( $GLOBALS['options'] ); }
}
$wpdb = new FakeWpdb();
function get_option( $name ) { return $GLOBALS['options'][ $name ] ?? false; }

$options = array(
	'theme_mods_some-theme' => array(
		'theme_instagram_image_1' => 'https://example.com/wp-content/uploads/2026/01/abandoned-phone-booth-night.jpg',
		'theme_hero_image' => 32927,
		'custom_logo' => '41',
		'posts_columns' => 3,
		'footer_html' => '<p><img src="/wp-content/uploads/2025/05/footer.png"></p>',
		'nav_menu_locations' => array( 'primary' => 7 ),
	),
	'theme_mods_twentytwentyfive' => array( 'header_image_data' => (object) array( 'attachment_id' => 12, 'url' => 'https://example.com/wp-content/uploads/old-header.jpg' ) ),
);

require __DIR__ . '/../classes/core.php';

class Probe extends Meow_WPMC_Core {
	function normalize_upload_relative_path( $path ) { return $path; }
	function get_urls_from_html( $html ) {
		preg_match_all( '/src="([^"]+)"/', $html, $m );
		return array_map( array( $this, 'clean_url' ), $m[1] );
	}
}

$p = ( new ReflectionClass( 'Probe' ) )->newInstanceWithoutConstructor();
$prop = new ReflectionProperty( 'Meow_WPMC_Core', 'upload_url' );
$prop->setValue( $p, 'https://example.com/wp-content/uploads' );
$ids = array();
$urls = array();
( new ReflectionMethod( 'Meow_WPMC_Core', 'get_images_from_theme_mods' ) )->invokeArgs( $p, array( &$ids, &$urls ) );
sort( $ids );

assert( in_array( '2026/01/abandoned-phone-booth-night.jpg', $urls ), 'a Customizer Image control (URL) is a reference' );
assert( in_array( '2025/05/footer.png', $urls ), 'images inside HTML theme mods are references' );
assert( in_array( 'old-header.jpg', $urls ), 'an inactive theme still keeps its images' );
assert( $ids === array( 12, 41, 32927 ), 'IDs only under image-like keys, not column counts or menus: ' . json_encode( $ids ) );

echo "ok\n";
