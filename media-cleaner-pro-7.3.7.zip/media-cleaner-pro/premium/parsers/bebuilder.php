<?php

add_action( 'wpmc_scan_postmeta', 'wpmc_scan_postmeta_bebuilder', 10, 1 );

  /**
   * BeBuilder (BeTheme) stores its layout as a JSON string in 'mfn-page-object'.
   * URLs live in many places ('src' like ".../image.png#9093", HTML inside 'content',
   * backgrounds), so they are read from the raw string. Galleries only keep
   * comma-separated attachment IDs in 'ids' (like "9647,9643").
   *
   * @param int $id The post ID.
   */
  function wpmc_scan_postmeta_bebuilder( $id ) {
    global $wpmc;
    $postmeta_images_ids = array();
    $postmeta_images_urls = array();

    $raw = get_post_meta( $id, 'mfn-page-object', true );
    if ( empty( $raw ) || !is_string( $raw ) ) {
      return;
    }

    $postmeta_images_urls = $wpmc->get_urls_from_string( $raw );
    $wpmc->get_from_meta( json_decode( $raw, true ), [ 'ids' ], $postmeta_images_ids, $postmeta_images_urls );

    $wpmc->add_reference_id( $postmeta_images_ids, 'BeBuilder', $id );
    $wpmc->add_reference_url( $postmeta_images_urls, 'BeBuilder', $id );
  }

?>
