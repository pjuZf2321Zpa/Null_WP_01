<?php
namespace SabaiApps\Directories;

/**
 * MainIndexController class for handling the default main index route.
 * Prevents recursive routing by using a static flag.
 */
class MainIndexController extends Controller {

	/**
	 * @var bool Static flag to prevent recursive routing.
	 */
	private static $_done = false;

	/**
	 * Executes the main index logic.
	 *
	 * @param Context $context
	 */
	protected function _doExecute( Context $context ) {
		// Prevent recursive routing
		if ( ! self::$_done ) {
			self::$_done = true;
		}
	}
}
