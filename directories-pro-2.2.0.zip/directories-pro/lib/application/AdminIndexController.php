<?php
namespace SabaiApps\Directories;

/**
 * AdminIndexController class for handling the default admin index route.
 * Redirects administrators to the settings page and prevents recursive routing.
 */
class AdminIndexController extends Controller {

	/**
	 * @var bool Flag to prevent recursive routing.
	 */
	private static $_done = false;

	/**
	 * Executes the admin index logic.
	 *
	 * @param Context $context
	 * @return void
	 */
	protected function _doExecute( Context $context ) {
		if ( ! $this->IsAdministrator() ) {
			$context->setForbiddenError();
			return;
		}

		// Prevent recursive routing
		if ( ! self::$_done ) {
			$this->_parent->forward( '/directories/settings', $context );
			self::$_done = true;
		}
	}
}
