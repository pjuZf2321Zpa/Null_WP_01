<?php
namespace SabaiApps\Directories;

use SabaiApps\Framework\Application\IRoute;

/**
 * Route class for representing application routes.
 * Stores route path and associated data, and provides methods for accessing controller and component information.
 */
class Route implements IRoute {

	/**
	 * @var string Route path.
	 */
	private $_route;
	/**
	 * @var array Route data.
	 */
	private $_data;

	/**
	 * Constructor
	 *
	 * @param string $route Route path.
	 * @param array  $data Route data.
	 */
	public function __construct( $route, array $data ) {
		$this->_route = $route;
		$this->_data  = $data;
	}

	/**
	 * Gets the route data array.
	 *
	 * @return array
	 */
	public function getData() {
		return $this->_data;
	}

	/**
	 * Magic getter for route data.
	 *
	 * @param string $name
	 * @return mixed
	 */
	public function __get( $name ) {
		return isset( $this->_data[ $name ] ) ? $this->_data[ $name ] : null;
	}

	/**
	 * Returns the route as a string.
	 *
	 * @return string
	 */
	public function __toString() {
		return $this->_route;
	}

	/**
	 * Gets the class name of the requested controller found in the route.
	 *
	 * @return string|false
	 */
	public function getController() {
		return isset( $this->_data['controller_class'] ) ? $this->_data['controller_class'] : false;
	}

	/**
	 * Returns controller file path.
	 *
	 * @return null
	 */
	public function getControllerFile() {}

	/**
	 * Returns controller constructor parameters.
	 *
	 * @return array
	 */
	public function getControllerArgs() {
		return isset( $this->_data['controller_args'] ) ? $this->_data['controller_args'] : array();
	}

	/**
	 * Gets the name of the requested controller.
	 *
	 * @return string|false
	 */
	public function getControllerName() {
		return isset( $this->_data['controller'] ) ? $this->_data['controller'] : false;
	}

	/**
	 * Returns another route to which the request should be forwarded.
	 *
	 * @return string|false
	 */
	public function isForward() {
		return isset( $this->_data['forward'] ) ? $this->_data['forward'] : false;
	}

	/**
	 * Gets the name of the plugin/component with which this route is associated.
	 *
	 * @return string|false
	 */
	public function getComponent() {
		return isset( $this->_data['component'] ) ? $this->_data['component'] : false;
	}
}
