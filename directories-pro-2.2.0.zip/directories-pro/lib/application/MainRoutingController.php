<?php
namespace SabaiApps\Directories;

/**
 * MainRoutingController class for handling main (front-end) routing logic.
 * Provides methods for retrieving main routes, processing access and title callbacks,
 * and executing main route logic.
 */
class MainRoutingController extends AbstractRoutingController {

	/**
	 * Gets the default main route.
	 *
	 * @return Route
	 */
	protected function _getDefaultRoute() {
		return new Route( '/', array( 'controller_class' => '\SabaiApps\Directories\MainIndexController' ) );
	}

	/**
	 * Gets component main routes for a given root path.
	 *
	 * @param string $rootPath
	 * @return array
	 */
	protected function _getComponentRoutes( $rootPath ) {
		return $this->_application->getComponent( 'System' )->getMainRoutes( $rootPath );
	}

	/**
	 * Processes the access callback for a main route.
	 *
	 * @param Context $context
	 * @param array   $route
	 * @param int     $accessType
	 * @return bool
	 */
	protected function _processAccessCallback( Context $context, array &$route, $accessType ) {
		return $this->_application->getComponent( $route['callback_component'] )->systemOnAccessMainRoute(
			$context,
			$route['callback_path'],
			$accessType,
			$route
		);
	}

	/**
	 * Processes the title callback for a main route.
	 *
	 * @param Context $context
	 * @param array   $route
	 * @param int     $titleType
	 * @return string|null
	 */
	protected function _processTitleCallback( Context $context, array $route, $titleType ) {
		return $this->_application->getComponent( $route['callback_component'] )->systemMainRouteTitle(
			$context,
			$route['callback_path'],
			$titleType,
			$route
		);
	}

	/**
	 * Processes the route and sets the controller class for main routes.
	 *
	 * @param array $route
	 * @return void
	 */
	protected function _processRoute( array &$route ) {
		$route['controller_class'] = '\SabaiApps\Directories\Component\\' . $route['controller_component'] . '\Controller\\' . $route['controller'];
	}
}
