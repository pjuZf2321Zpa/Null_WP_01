<?php
namespace SabaiApps\Directories;

use SabaiApps\Framework\Application\AbstractApplication;
use SabaiApps\Framework\Application\AbstractRoutingController as FrameworkAbstractRoutingController;
use SabaiApps\Framework\Application\Context as FrameworkContext;

/**
 * AbstractRoutingController class for handling application routing logic.
 * Provides methods for matching routes, checking access, managing tabs and menus, and processing route callbacks.
 */
abstract class AbstractRoutingController extends FrameworkAbstractRoutingController {

	/**
	 * @var array Stores results of access callbacks for routes.
	 */
	private $_accessCallbackResults = array(), $_tabsAdded = 0;

	/**
	 * @var AbstractApplication Reference to the application instance.
	 */
	protected $_application, $_parent;

	/**
	 * Sets the application instance.
	 *
	 * @param AbstractApplication $application
	 * @return $this
	 */
	public function setApplication( AbstractApplication $application ) {
		$this->_application = $application;

		return $this;
	}

	/**
	 * Gets the application instance.
	 *
	 * @return AbstractApplication
	 */
	public function getApplication() {
		return $this->_application;
	}

	/**
	 * Sets the parent routing controller.
	 *
	 * @param FrameworkAbstractRoutingController $controller
	 * @return $this
	 */
	public function setParent( FrameworkAbstractRoutingController $controller ) {
		$this->_parent = $controller;

		return $this;
	}

	/**
	 * Magic method to forward method calls to the application instance.
	 *
	 * @param string $method
	 * @param array  $args
	 * @return mixed
	 */
	final public function __call( $method, $args ) {
		return call_user_func_array( array( $this->_application, $method ), $args );
	}

	/**
	 * Determines if a route is routable and processes the routing logic.
	 *
	 * @param FrameworkContext $context
	 * @param string           $route
	 * @return Route|false
	 */
	protected function _isRoutable( FrameworkContext $context, $route ) {
		$route                 = trim( $route, '/' );
		$allowed_content_types = array( 'html', 'xml', 'json' );
		if ( $dot_pos = strpos( $route, '.' ) ) {
			$content_type = substr( $route, $dot_pos + 1 );
			if ( in_array( $content_type, $allowed_content_types ) ) {
				$route = substr( $route, 0, $dot_pos );
			} else {
				unset( $content_type );
			}
		} elseif ( $context->getRequest()->has( Request::PARAM_CONTENT_TYPE ) ) {
			$content_type = $context->getRequest()->asStr( Request::PARAM_CONTENT_TYPE );
			if ( ! in_array( $content_type, $allowed_content_types ) ) {
				unset( $content_type );
			}
		}
		if ( ! $context->getContentType() ) {
			$context->setContentType( isset( $content_type ) ? $content_type : 'html' );
		}

		$paths_requested = explode( '/', $route . '/' );

		if ( ! $requested_root_route = array_shift( $paths_requested ) ) {
			return false;
		}

		// URL encode multi-byte char route
		if ( function_exists( 'mb_strlen' )
			&& strlen( $requested_root_route ) !== mb_strlen( $requested_root_route )
		) {
			$requested_root_route = strtolower( urlencode( $requested_root_route ) );
		}

		$requested_root_path = '/' . $requested_root_route;

		if ( ( ! $all_routes = $this->_getComponentRoutes( $requested_root_path ) )
			|| ! isset( $all_routes[ $requested_root_path ] )
			|| ( ! $route_matched = $all_routes[ $requested_root_path ] )
			|| ! $this->isComponentLoaded( $route_matched['component'] )
		) {
			$context->setNotFoundError();

			return false;
		}

		// Check if can access
		if ( ! $this->_canAccessRoute( $context, $route_matched, Application::ROUTE_ACCESS_LINK ) ) {
			// Access denied. Set error if not already set and not a redirect
			if ( ! $context->isError() && ! $context->isRedirect() ) {
				$context->setForbiddenError();
			}

			return false;
		}

		// Set page info of the root route. Skipped when info is already present
		// - a forward re-enters _dispatch() with the same context, and the
		// outer pass has already recorded this crumb (re-recording it produced
		// a duplicate root breadcrumb).
		if ( ! $context->getInfo()
			&& ( $route_matched_title = $this->_getTitle( $context, $route_matched ) )
		) {
			$context->setInfo( $route_matched_title, $this->Url( $requested_root_path ) );
		}

		// Initialize some required variables
		$path_selected       = $requested_root_route;
		$paths_matched       = array( $requested_root_route );
		$tabs                = $menus = $dynamic_route_keys = array();
		$valid_route_matched = $route_matched;

		while ( ! empty( $route_matched['routes'] )
			&& null !== ( $path_requested = array_shift( $paths_requested ) )
		) {
			$routes = $route_matched['routes'];
			foreach ( $routes as $route_key => $route_path ) {
				if ( ! isset( $all_routes[ $route_path ] ) ) {
					continue;
				}

				$route_data = $all_routes[ $route_path ];

				if ( $route_data['type'] == Application::ROUTE_TAB ) {
					// Dynamic routes may not become tabs
					if ( 0 === strpos( $route_key, ':' ) ) {
						continue;
					}

					$tabs[ $route_data['weight'] + 1 ][ $route_key ] = $route_data;
				} elseif ( $route_data['type'] == Application::ROUTE_MENU ) {
					// Dynamic routes may not become menu items
					if ( 0 === strpos( $route_key, ':' ) ) {
						continue;
					}

					$menus[ $route_key ] = $route_data;
				}
			}

			if ( isset( $route_matched['controller'] ) ) {
				$tabs[0][''] = $route_matched;
			}

			// Some access callbacks set the response status as error, but the status should not be changed here since
			// we are now just checking whether or not the route is accessible, not really trying to access the route.
			$context->setView();

			// Default route
			if ( $path_requested == '' ) {
				// Only seed the "" (default) tab's breadcrumb when there
				// actually is one - a route landed on directly that has tab
				// children but no controller of its own (e.g. a forward-only
				// root) produces no "" tab, and setInfo(null, null) would push
				// an empty breadcrumb segment.
				if ( ( $tabs_added = $this->_addTabs( $context, $tabs, $paths_matched ) )
					&& isset( $tabs_added[''] )
				) {
					$context->setCurrentTab( '' )->setInfo( $tabs_added['']['title'], $tabs_added['']['url'] );
				}
				$this->_addMenus( $context, $menus, $paths_matched );

				break;
			}

			if ( isset( $routes[ $path_requested ] ) ) {
				$path_selected = $path_requested;
				$route_matched = $all_routes[ $routes[ $path_requested ] ];
			} else {
				$matched = false;
				// Check if dynamic routes are defined and any matching route
				krsort( $routes, SORT_STRING );
				foreach ( $routes as $route_key => $route_path ) {
					if ( 0 !== strpos( $route_key, ':' ) ) {
						continue;
					}
					if ( ! isset( $all_routes[ $route_path ] ) ) {
						continue;
					}

					$route_data = $all_routes[ $route_path ];
					if ( ! empty( $route_data['format'][ $route_key ] ) ) {
						$regex = '#^(' . str_replace( '#', '\#', $route_data['format'][ $route_key ] ) . ')$#i';
					} else {
						$regex = '#^([a-z0-9~\s\.:_\-\+@%]+)$#i';
					}
					if ( strpos( $route_key, '...' )
						&& ( $_paths_requested = array_filter( $paths_requested, 'strlen' ) )
					) {
						$_path_requested = array_pop( $_paths_requested );
						$path_to_match   = $_path_requested;
						if ( ! preg_match( $regex, $path_to_match, $matches ) ) {
							continue;
						}

						while ( $_path_requested = array_shift( $_paths_requested ) ) {
							$path_requested .= '/' . $_path_requested;
						}
						$path_requested .= '/' . $path_to_match;
						$context->getRequest()->set( ltrim( $route_key, ':' ), $path_requested );
					} else {
						$path_to_match = $path_requested;
						if ( ! preg_match( $regex, $path_to_match, $matches ) ) {
							continue;
						}
					}
					$context->getRequest()->set( rtrim( ltrim( $route_key, ':' ), '.' ), $matches[1] );
					$dynamic_route_keys[ $route_key ] = $matches[1];
					$path_selected                    = $route_key;
					$route_matched                    = $route_data;
					$matched                          = true;
					break;
				}

				if ( ! $matched ) {
					$context->setNotFoundError();

					return false;
				}
			}

			// Check if can access content of the route
			if ( ! $this->_canAccessRoute( $context, $route_matched, Application::ROUTE_ACCESS_LINK ) ) {
				// Access denied

				// Forward to another route if format key is set in route
				if ( ! empty( $route_matched['forward'] ) ) {
					return new Route( null, $route_matched );
				}

				// Set error if not already set
				if ( ! $context->isError() && ! $context->isRedirect() ) {
					$context->setForbiddenError();
				}

				return false;
			}

			if ( $route_matched['type'] != Application::ROUTE_CALLBACK ) {
				// Add breadcrumbs
				if ( $tabs_added = $this->_addTabs( $context, $tabs, $paths_matched ) ) {
					// Resolve current tab if requested route is not a tab
					if ( $route_matched['type'] != Application::ROUTE_TAB ) {
						// Set the default tab as the current tab and add its
						// breadcrumb - but only if there is one (a forward-only
						// root has tab children yet no "" tab of its own).
						if ( isset( $tabs_added[''] ) ) {
							$context->setCurrentTab( '' );
							$context->setInfo( $tabs_added['']['title'], $this->Url( $tabs_added['']['url'] ) );
						}
					} else {
						$context->setCurrentTab( $path_selected );
					}
				}
				if ( $title = $this->_getTitle( $context, $route_matched, Application::ROUTE_TITLE_INFO ) ) {
					$context->setInfo(
						$title,
						$this->Url( isset( $route_matched['permalink_url'] ) ? $route_matched['permalink_url'] : '/' . implode( '/', $paths_matched ) . '/' . $path_requested )
					);
				}
			}

			$paths_matched[] = $path_requested;

			if ( ! empty( $route_matched['controller'] ) || ! empty( $route_matched['forward'] ) ) {
				$valid_route_matched = $route_matched;
			}

			// Clear menus/tabs
			$tabs = $menus = array();
		}

		// Any valid route has matched?
		if ( empty( $valid_route_matched )
			|| ( empty( $route_matched['controller'] ) && empty( $route_matched['forward'] ) ) // make sure controller/forward is set by the last route matched
			|| ( ! empty( $route_matched['data']['embed_only'] ) && ! $context->isEmbed() )
		) {
			$context->setNotFoundError();

			return false;
		}

		// Check if can access content of the route
		if ( ! $this->Filter( 'core_access_route', $this->_canAccessRoute( $context, $valid_route_matched ), array( $context, $valid_route_matched, $paths_matched ) ) ) {
			// Access denied. Set error if not already set
			if ( ! $context->isError() && ! $context->isRedirect() ) {
				$context->setForbiddenError();
			}

			return false;
		}

		// We don't need routes data anymore, save memory
		unset( $valid_route_matched['routes'] );

		if ( ! empty( $valid_route_matched['method'] )
			&& strcasecmp( Request::method(), $valid_route_matched['method'] ) !== 0
		) {
			// The requested method is not allowed for this route
			$context->setMethodNotAllowedError();

			return false;
		}

		if ( ! empty( $valid_route_matched['forward'] ) ) {
			// Convert dynamic route parts to actual values
			$valid_route_matched['forward'] = strtr( $valid_route_matched['forward'], $dynamic_route_keys );
		} else {
			if ( empty( $valid_route_matched['controller'] ) ) {
				$context->setRedirect( $this->_application->getPlatform()->getMainUrl() );

				return false;
			}

			$this->_processRoute( $valid_route_matched );
		}

		return new Route( '/' . implode( '/', $paths_matched ) . '/', $valid_route_matched );
	}

	/**
	 * Gets component routes for a given root path.
	 *
	 * @param string $rootPath
	 * @return array
	 */
	abstract protected function _getComponentRoutes( $rootPath );

	/**
	 * Processes the access callback for a route.
	 *
	 * @param Context $context
	 * @param array   $route
	 * @param int     $accessType
	 * @return bool
	 */
	abstract protected function _processAccessCallback( Context $context, array &$route, $accessType );

	/**
	 * Processes the title callback for a route.
	 *
	 * @param Context $context
	 * @param array   $route
	 * @param int     $titleType
	 * @return string|null
	 */
	abstract protected function _processTitleCallback( Context $context, array $route, $titleType );

	/**
	 * Processes the route callback.
	 *
	 * @param array $route
	 * @return void
	 */
	abstract protected function _processRoute( array &$route );

	/**
	 * Checks if the current user can access a route.
	 *
	 * @param Context $context
	 * @param array   $route
	 * @param int     $accessType
	 * @return bool
	 */
	private function _canAccessRoute( Context $context, &$route, $accessType = Application::ROUTE_ACCESS_CONTENT ) {
		if ( isset( $route['callback_component'] ) && ! $this->isComponentLoaded( $route['callback_component'] ) ) {
			return false;
		}

		if ( empty( $route['access_callback'] ) ) {
			return true;
		}

		// Make sure the callback is called only once for each path
		$path = $route['path'];
		if ( ! isset( $this->_accessCallbackResults[ $path ][ $accessType ] ) ) {
			$this->_accessCallbackResults[ $path ][ $accessType ] = $this->_processAccessCallback( $context, $route, $accessType );
			// Also deny access if any error is set in context
			if ( $context->isError() ) {
				$this->_accessCallbackResults[ $path ][ $accessType ] = false;
			}
		}

		return $this->_accessCallbackResults[ $path ][ $accessType ];
	}

	/**
	 * Gets the title for a route, using a callback if defined.
	 *
	 * @param Context $context
	 * @param array   $route
	 * @param int     $titleType
	 * @return string|null
	 */
	private function _getTitle( Context $context, array $route, $titleType = Application::ROUTE_TITLE_NORMAL ) {
		if ( empty( $route['title_callback'] ) ) {
			return isset( $route['title'] ) ? $route['title'] : null;
		}

		return $this->_processTitleCallback( $context, $route, $titleType );
	}

	/**
	 * Adds tabs to the context for the current route.
	 *
	 * @param Context $context
	 * @param array   $tabs
	 * @param array   $pathsMatched
	 * @return array|false
	 */
	private function _addTabs( Context $context, array $tabs, array $pathsMatched ) {
		ksort( $tabs );
		$_tabs = array();
		$path  = implode( '/', $pathsMatched );
		foreach ( array_keys( $tabs ) as $weight ) {
			foreach ( $tabs[ $weight ] as $route_key => $route_data ) {
				// Is the current user allowed to access the link to this route?
				if ( ! $this->_canAccessRoute( $context, $route_data, Application::ROUTE_ACCESS_LINK ) ) {
					continue;
				}

				if ( ! $title = $this->_getTitle( $context, $route_data, Application::ROUTE_TITLE_TAB ) ) {
					if ( $route_key !== '' ) {
						continue;
					}

					$title = __( 'Top', 'directories-pro' );
				}

				$tab_data = isset( $route_data['data'] ) ? $route_data['data'] : array();
				// A route may carry a 'tip' (info) or 'help' (question) string;
				// render it as the same sabaitooltip icon the form component
				// appends to its own #tabs (Form::_renderTabs).
				if ( ! empty( $tab_data['tip'] ) || ! empty( $tab_data['help'] ) ) {
					$is_help                               = ! empty( $tab_data['help'] );
					$title                                 = $this->_application->H( $title )
						. ' <span rel="sabaitooltip" title="' . $this->_application->H( $is_help ? $tab_data['help'] : $tab_data['tip'] ) . '">'
						. '<i class="drts-fas ' . ( $is_help ? 'fa-circle-question' : 'fa-circle-info' ) . '"></i></span>';
					$tab_data['link_options']['no_escape'] = true;
				}

				$_tabs[ $route_key ] = array(
					'title' => $title,
					'url'   => '/' . $path . '/' . $route_key,
					'data'  => $tab_data,
				);
			}
		}

		if ( count( $_tabs ) <= 1 ) {
			return false;
		}

		// Add tabs
		$context->pushTabs( $_tabs );
		++$this->_tabsAdded;

		return $_tabs;
	}

	/**
	 * Adds menus to the context for the current route.
	 *
	 * @param Context $context
	 * @param array   $menus
	 * @param array   $pathsMatched
	 * @return void
	 */
	private function _addMenus( Context $context, array $menus, $pathsMatched ) {
		$_menus = array();
		$path   = implode( '/', $pathsMatched );
		foreach ( $menus as $route_key => $route ) {
			// Is the current user allowed to access the link to this route?
			if ( ! $this->_canAccessRoute( $context, $route, Application::ROUTE_ACCESS_LINK ) ) {
				continue;
			}

			if ( ! $title = $this->_getTitle( $context, $route, Application::ROUTE_TITLE_MENU ) ) {
				continue;
			}

			$_url = '/' . $path . '/' . $route_key;
			if ( is_array( $title ) ) {
				$_title = array_shift( $title );
				$url    = array();
				foreach ( $title as $key => $__title ) {
					$url[ $_url . '/' . $key ] = $__title;
				}
				$title = $_title;
			} else {
				$url = $_url;
			}

			// Add menu
			$_menus[ $route['weight'] ][ $route_key ] = array(
				'title' => $title,
				'url'   => $url,
				'data'  => $route['data'],
			);
		}
		if ( empty( $_menus ) ) {
			return;
		}

		ksort( $_menus );
		$menus = array();
		foreach ( array_keys( $_menus ) as $weight ) {
			foreach ( $_menus[ $weight ] as $data ) {
				$menus[] = $data;
			}
		}
		$context->setMenus( $menus );
	}
}
