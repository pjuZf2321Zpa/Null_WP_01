<?php
namespace SabaiApps\Directories;

/**
 * Link class extending the framework Link class.
 * Adds support for active and disabled states for links.
 */
class Link extends \SabaiApps\Framework\Link {

	/**
	 * Gets the HTML attributes for the link, including active/disabled classes.
	 *
	 * @return array
	 */
	protected function _getAttributes() {
		$attr = parent::_getAttributes();
		if ( ! isset( $attr['class'] ) ) {
			$attr['class'] = '';
		}
		if ( $this->isActive() ) {
			$attr['class'] .= ' ' . DRTS_BS_PREFIX . 'active';
		} elseif ( $this->isDisabled() ) {
			$attr['class'] .= ' ' . DRTS_BS_PREFIX . 'disabled';
		}
		return $attr;
	}

	/**
	 * Sets the link as active.
	 *
	 * @param bool $flag
	 * @return $this
	 */
	public function setActive( $flag = true ) {
		$this->_options['active'] = (bool) $flag;
		return $this;
	}

	/**
	 * Checks if the link is active.
	 *
	 * @return bool
	 */
	public function isActive() {
		return ! empty( $this->_options['active'] );
	}

	/**
	 * Sets the link as disabled.
	 *
	 * @param bool $flag
	 * @return $this
	 */
	public function setDisabled( $flag = true ) {
		$this->_options['disabled'] = (bool) $flag;
		return $this;
	}

	/**
	 * Checks if the link is disabled.
	 *
	 * @return bool
	 */
	public function isDisabled() {
		return ! empty( $this->_options['disabled'] );
	}
}
