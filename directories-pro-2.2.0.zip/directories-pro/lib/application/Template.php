<?php
namespace SabaiApps\Directories;

/**
 * Template class for rendering application templates.
 * Extends the framework Template class and provides access to application helpers.
 */
class Template extends \SabaiApps\Framework\Template {

	/**
	 * @var Application Reference to the application instance.
	 */
	private $_application;

	/**
	 * Constructor.
	 *
	 * @param Application $application
	 * @param array       $dirs Template directories.
	 */
	public function __construct( Application $application, array $dirs = array() ) {
		parent::__construct( $dirs );
		$this->_application = $application;
	}

	/**
	 * Calls an application helper from the template.
	 *
	 * @param string $name
	 * @param array  $args
	 * @return mixed
	 */
	public function __call( $name, $args ) {
		return $this->_application->callHelper( $name, $args );
	}

	/**
	 * Retrieves a model from the application.
	 *
	 * @param string      $modelName
	 * @param string|null $component
	 * @return \SabaiApps\Directories\Model\AbstractModel
	 */
	public function getModel( $modelName, $component = null ) {
		return $this->_application->getModel( $modelName, $component );
	}
}
