<?php
namespace SabaiApps\Directories\Component\System;

/**
 * ISlugs interface for components that provide custom slugs.
 */
interface ISlugs {

	/**
	 * Returns an array of slugs provided by the component.
	 *
	 * @return array
	 */
	public function systemSlugs();
}
