<?php if ( ! defined( 'ABSPATH' ) ) {
	exit;} ?>
<?php if ( isset( $colors['primary'] ) ) : ?>
.drts {
	--bs-primary: <?php echo $colors['primary'][0]; ?>;
	--drts-bg-primary: rgba(<?php echo implode( ', ', $colors['primary']['rgb'][0] ); ?>, 1);
	--drts-bg-primary-subtle: rgba(<?php echo implode( ', ', $colors['primary']['rgb'][25] ); ?>, 0.4);
	--drts-text-primary: <?php echo $colors['primary'][0]; ?>;
	--drts-text-primary-emphasis: color-mix(in srgb, <?php echo $colors['primary'][0]; ?>, black 20%);
}
.drts .<?php echo $prefix; ?>text-primary {
	color: var(--drts-text-primary) !important;
}
.drts .<?php echo $prefix; ?>text-primary-emphasis {
	color: var(--drts-text-primary-emphasis) !important;
}
.drts .<?php echo $prefix; ?>btn-primary,
.drts .<?php echo $prefix; ?>btn-primary.<?php echo $prefix; ?>disabled,
.drts  .<?php echo $prefix; ?>btn-primary:disabled {
	color: #fff;
	background-color: <?php echo $colors['primary'][0]; ?>;
	border-color: <?php echo $colors['primary'][0]; ?>;
}
.drts .<?php echo $prefix; ?>btn-primary:hover {
	color: #fff;
	background-color: <?php echo $colors['primary'][-7]; ?>;
	border-color: <?php echo $colors['primary'][-9]; ?>;
}
.drts .<?php echo $prefix; ?>btn-primary:focus,
.drts  .<?php echo $prefix; ?>btn-primary.<?php echo $prefix; ?>focus {
	color: #fff;
	background-color: <?php echo $colors['primary'][-7]; ?>;
	border-color: <?php echo $colors['primary'][-9]; ?>;
}
.drts .<?php echo $prefix; ?>btn-primary:not(:disabled):not(.<?php echo $prefix; ?>disabled):active,
.drts  .<?php echo $prefix; ?>btn-primary:not(:disabled):not(.<?php echo $prefix; ?>disabled).<?php echo $prefix; ?>active,
.drts .<?php echo $prefix; ?>show > .<?php echo $prefix; ?>btn-primary.<?php echo $prefix; ?>dropdown-toggle {
	color: #fff;
	background-color: <?php echo $colors['primary'][-9]; ?>;
	border-color: <?php echo $colors['primary'][12]; ?>;
}
.drts .<?php echo $prefix; ?>btn-outline-primary {
	color: <?php echo $colors['primary'][0]; ?>;
	border-color: <?php echo $colors['primary'][0]; ?>;
}
.drts .<?php echo $prefix; ?>btn-outline-primary:hover,
.drts .<?php echo $prefix; ?>btn-outline-primary:not(:disabled):not(.<?php echo $prefix; ?>disabled):active,
.drts .<?php echo $prefix; ?>btn-outline-primary:not(:disabled):not(.<?php echo $prefix; ?>disabled).<?php echo $prefix; ?>active,
.drts .<?php echo $prefix; ?>show > .<?php echo $prefix; ?>btn-outline-primary.<?php echo $prefix; ?>dropdown-toggle {
	color: #fff;
	background-color: <?php echo $colors['primary'][0]; ?>;
	border-color: <?php echo $colors['primary'][0]; ?>;
}
.drts .<?php echo $prefix; ?>btn-outline-primary.<?php echo $prefix; ?>disabled,
.drts  .<?php echo $prefix; ?>btn-outline-primary:disabled {
	color: <?php echo $colors['primary'][0]; ?>;
}
.drts .<?php echo $prefix; ?>btn-link {
	color: <?php echo $colors['primary'][0]; ?>;
}
.drts .<?php echo $prefix; ?>btn-link:hover {
	color: <?php echo $colors['primary'][-15]; ?>;
}
.drts .<?php echo $prefix; ?>form-check-input:checked~.<?php echo $prefix; ?>form-check-label::before {
	color: #fff;
	background-color: <?php echo $colors['primary'][0]; ?>;
	border-color: <?php echo $colors['primary'][0]; ?>
}
.drts .<?php echo $prefix; ?>form-check-input:checked {
	background-color: <?php echo $colors['primary'][0]; ?>;
	border-color: <?php echo $colors['primary'][0]; ?>
}
.drts .irs--flat .irs-from::before,.drts .irs--flat .irs-single::before,
.drts .irs--flat .irs-to::before,
.drts .irs--flat .irs-from::after,
.drts .irs--flat .irs-single::after,
.drts .irs--flat .irs-to::after {
	border-top-color: <?php echo $colors['primary'][0]; ?>
}
.drts .irs--flat .irs-from,
.drts .irs--flat .irs-single,
.drts .irs--flat .irs-to,
.drts .irs--flat .irs-bar,
.drts .irs--flat .irs-handle > i:first-child {
	background-color: <?php echo $colors['primary'][0]; ?>;
}
.drts .<?php echo $prefix; ?>dropdown-item.<?php echo $prefix; ?>active,
.drts .<?php echo $prefix; ?>dropdown-item:active {
	color: #fff;
	background-color: <?php echo $colors['primary'][0]; ?>;
}
.drts .<?php echo $prefix; ?>form-control:focus {
	color: #495057;
	background-color: #fff;
	border-color: <?php echo $colors['primary'][25]; ?>;
	box-shadow: 0 0 0 0.2rem rgb(<?php echo implode( ' ', $colors['primary']['rgb'][0] ); ?> / 25%);
}
.drts .<?php echo $prefix; ?>bg-primary,
.drts .<?php echo $prefix; ?>text-bg-primary {
	background-color: var(--drts-bg-primary) !important;
}
.drts .<?php echo $prefix; ?>text-bg-primary {
	color: var(--drts-text-primary-emphasis) !important;
}
.drts .<?php echo $prefix; ?>bg-primary-subtle {
	background-color: var(--drts-bg-primary-subtle) !important;
}
.drts a.<?php echo $prefix; ?>bg-primary:hover,
.drts a.<?php echo $prefix; ?>bg-primary:focus,
.drts button.<?php echo $prefix; ?>bg-primary:hover,
.drts button.<?php echo $prefix; ?>bg-primary:focus {
	background-color: <?php echo $colors['primary'][-9]; ?> !important;
}
.drts .<?php echo $prefix; ?>border-primary {
	border-color: rgba(<?php echo implode( ', ', $colors['primary']['rgb'][0] ); ?>, var(--bs-border-opacity)) !important;
}
.swal2-styled.swal2-confirm {
	background-color: <?php echo $colors['primary'][0]; ?> !important;
}
.drts .<?php echo $prefix; ?>accordion-button:not(.<?php echo $prefix; ?>collapsed) {
	color: #fff;
	background-color: <?php echo $colors['primary'][0]; ?>;
	border-color: <?php echo $colors['primary'][0]; ?>;
}
.drts .<?php echo $prefix; ?>accordion-button:focus {
	box-shadow: 0 0 0 0.25rem rgb(<?php echo implode( ' ', $colors['primary']['rgb'][0] ); ?> / 25%);
}
.drts .<?php echo $prefix; ?>list-group-item.<?php echo $prefix; ?>active {
	color: #000;
	background-color: rgba(<?php echo implode( ', ', $colors['primary']['rgb'][25] ); ?>, 0.4);
	border-color: rgba(<?php echo implode( ', ', $colors['primary']['rgb'][25] ); ?>, 0.4);
}
.drts .<?php echo $prefix; ?>list-group-item-action:not(.<?php echo $prefix; ?>active):hover, 
.drts .<?php echo $prefix; ?>list-group-item-action:not(.<?php echo $prefix; ?>active):focus {
	background-color: rgba(<?php echo implode( ', ', $colors['primary']['rgb'][25] ); ?>, 0.3);
}
.drts .uppy-DashboardContent-addMore:focus {
	background-color: <?php echo $colors['primary'][0]; ?>;
	color: #fff;
}
<?php endif; ?>
<?php if ( isset( $colors['secondary'] ) ) : ?>
.drts {
	--bs-secondary: <?php echo $colors['secondary'][0]; ?>;
	--drts-bg-secondary: rgba(<?php echo implode( ', ', $colors['secondary']['rgb'][0] ); ?>, 1);
	--drts-bg-secondary-subtle: rgba(<?php echo implode( ', ', $colors['secondary']['rgb'][25] ); ?>, 0.4);
	--drts-text-secondary: <?php echo $colors['secondary'][0]; ?>;
	--drts-text-secondary-emphasis: color-mix(in srgb, <?php echo $colors['secondary'][0]; ?>, black 20%);
}
.drts .<?php echo $prefix; ?>text-secondary {
	color: var(--drts-text-secondary) !important;
}
.drts .<?php echo $prefix; ?>text-secondary-emphasis {
	color: var(--drts-text-secondary-emphasis) !important;
}
.drts .<?php echo $prefix; ?>btn-secondary,
.drts .<?php echo $prefix; ?>btn-secondary.<?php echo $prefix; ?>disabled,
.drts .<?php echo $prefix; ?>btn-secondary:disabled {
	color: #fff;
	background-color: <?php echo $colors['secondary'][0]; ?>;
	border-color: <?php echo $colors['secondary'][0]; ?>;
}
.drts .<?php echo $prefix; ?>btn-secondary:hover {
	color: #fff;
	background-color: <?php echo $colors['secondary'][-7]; ?>;
	border-color: <?php echo $colors['secondary'][-9]; ?>;
}
.drts .<?php echo $prefix; ?>btn-secondary:focus,
.drts .<?php echo $prefix; ?>btn-secondary.<?php echo $prefix; ?>focus {
	color: #fff;
	background-color: <?php echo $colors['secondary'][-7]; ?>;
	border-color: <?php echo $colors['secondary'][-9]; ?>;
}
.drts .<?php echo $prefix; ?>accordion-button:focus {
	border-color: <?php echo $colors['primary'][-9]; ?>;
}
.drts .<?php echo $prefix; ?>btn-secondary:not(:disabled):not(.<?php echo $prefix; ?>disabled):active,
.drts .<?php echo $prefix; ?>btn-secondary:not(:disabled):not(.<?php echo $prefix; ?>disabled).<?php echo $prefix; ?>active,
.drts .<?php echo $prefix; ?>show > .<?php echo $prefix; ?>btn-secondary.<?php echo $prefix; ?>dropdown-toggle {
	color: #fff;
	background-color: <?php echo $colors['secondary'][-9]; ?>;
	border-color: <?php echo $colors['secondary'][-12]; ?>;
}
.drts .<?php echo $prefix; ?>btn-outline-secondary {
	color: <?php echo $colors['secondary'][0]; ?>;
	border-color: <?php echo $colors['secondary'][0]; ?>;
}
.drts .<?php echo $prefix; ?>btn-outline-secondary:hover,
.drts .<?php echo $prefix; ?>btn-outline-secondary:not(:disabled):not(.<?php echo $prefix; ?>disabled):active,
.drts .<?php echo $prefix; ?>btn-outline-secondary:not(:disabled):not(.<?php echo $prefix; ?>disabled).<?php echo $prefix; ?>active,
.drts .<?php echo $prefix; ?>show > .<?php echo $prefix; ?>btn-outline-secondary.<?php echo $prefix; ?>dropdown-toggle {
	color: #fff;
	background-color: <?php echo $colors['secondary'][0]; ?>;
	border-color: <?php echo $colors['secondary'][0]; ?>;
}
.drts .<?php echo $prefix; ?>btn-outline-secondary.<?php echo $prefix; ?>disabled,
.drts .<?php echo $prefix; ?>btn-outline-secondary:disabled {
	color: <?php echo $colors['secondary'][0]; ?>;
}
.drts .<?php echo $prefix; ?>btn-link:disabled,
.drts  .<?php echo $prefix; ?>btn-link.<?php echo $prefix; ?>disabled {
	color: <?php echo $colors['secondary'][0]; ?>;
}
.drts .<?php echo $prefix; ?>bg-secondary,
.drts .<?php echo $prefix; ?>text-bg-secondary {
	background-color: var(--drts-bg-secondary) !important;
}
.drts .<?php echo $prefix; ?>text-bg-secondary {
	color: var(--drts-text-secondary-emphasis) !important;
}
.drts .<?php echo $prefix; ?>bg-secondary-subtle {
	background-color: var(--drts-bg-secondary-subtle) !important;
}
.drts a.<?php echo $prefix; ?>bg-secondary:hover,
.drts  a.<?php echo $prefix; ?>bg-secondary:focus,
.drts button.<?php echo $prefix; ?>bg-secondary:hover,
.drts button.<?php echo $prefix; ?>bg-secondary:focus {
	background-color: <?php echo $colors['secondary'][-9]; ?> !important;
}
.drts .<?php echo $prefix; ?>border-secondary {
	border-color: rgba(<?php echo implode( ', ', $colors['secondary']['rgb'][0] ); ?>, var(--bs-border-opacity)) !important;
}
<?php endif; ?>
<?php if ( isset( $colors['light'] ) ) : ?>
.drts {
	--bs-light: <?php echo $colors['light'][0]; ?>; /
}
.drts .<?php echo $prefix; ?>text-light {
	color: <?php echo $colors['light'][0]; ?> !important;
}
.drts .<?php echo $prefix; ?>text-light-emphasis {
	color: color-mix(in srgb, <?php echo $colors['light'][0]; ?>, black 20%) !important;
}
.drts .<?php echo $prefix; ?>btn-light,
.drts .<?php echo $prefix; ?>btn-light.<?php echo $prefix; ?>disabled,
.drts .<?php echo $prefix; ?>btn-light:disabled {
	color: #000;
	background-color: <?php echo $colors['light'][0]; ?>;
	border-color: <?php echo $colors['light'][0]; ?>;
}
.drts .<?php echo $prefix; ?>btn-light:hover {
	color: #000;
	background-color: <?php echo $colors['light'][-7]; ?>;
	border-color: <?php echo $colors['light'][-9]; ?>;
}
.drts .<?php echo $prefix; ?>btn-light:focus,
.drts .<?php echo $prefix; ?>btn-light.<?php echo $prefix; ?>focus {
	color: #000;
	background-color: <?php echo $colors['light'][-7]; ?>;
	border-color: <?php echo $colors['light'][-9]; ?>;
}
.drts .<?php echo $prefix; ?>btn-light:not(:disabled):not(.<?php echo $prefix; ?>disabled):active,
.drts .<?php echo $prefix; ?>btn-light:not(:disabled):not(.<?php echo $prefix; ?>disabled).<?php echo $prefix; ?>active,
.drts .<?php echo $prefix; ?>show > .<?php echo $prefix; ?>btn-light.<?php echo $prefix; ?>dropdown-toggle {
	color: #000;
	background-color: <?php echo $colors['light'][-9]; ?>;
	border-color: <?php echo $colors['light'][-12]; ?>;
}
.drts .<?php echo $prefix; ?>btn-outline-light {
	color: <?php echo $colors['light'][0]; ?>;
	border-color: <?php echo $colors['light'][0]; ?>;
}
.drts .<?php echo $prefix; ?>btn-outline-light:hover,
.drts .<?php echo $prefix; ?>btn-outline-light:not(:disabled):not(.<?php echo $prefix; ?>disabled):active,
.drts .<?php echo $prefix; ?>btn-outline-light:not(:disabled):not(.<?php echo $prefix; ?>disabled).<?php echo $prefix; ?>active,
.drts .<?php echo $prefix; ?>show > .<?php echo $prefix; ?>btn-outline-light.<?php echo $prefix; ?>dropdown-toggle {
	color: #000;
	background-color: <?php echo $colors['light'][0]; ?>;
	border-color: <?php echo $colors['light'][0]; ?>;
}
.drts .<?php echo $prefix; ?>btn-outline-light.<?php echo $prefix; ?>disabled,
.drts .<?php echo $prefix; ?>btn-outline-light:disabled {
	color: <?php echo $colors['light'][0]; ?>;
}
.drts .<?php echo $prefix; ?>bg-light,
.drts .<?php echo $prefix; ?>text-bg-light {
	background-color: rgba(<?php echo implode( ', ', $colors['light']['rgb'][0] ); ?>, var(--bs-bg-opacity, 1)) !important;
}
.drts .<?php echo $prefix; ?>bg-light-subtle {
	background-color: rgba(<?php echo implode( ', ', $colors['light']['rgb'][-5] ); ?>, var(--bs-bg-opacity, 1)) !important;
}
.drts a.<?php echo $prefix; ?>bg-light:hover,
.drts  a.<?php echo $prefix; ?>bg-light:focus,
.drts button.<?php echo $prefix; ?>bg-light:hover,
.drts button.<?php echo $prefix; ?>bg-light:focus {
	background-color: <?php echo $colors['light'][-9]; ?> !important;
}
.drts .<?php echo $prefix; ?>border-light {
	border-color: rgba(<?php echo implode( ', ', $colors['light']['rgb'][0] ); ?>, var(--bs-border-opacity)) !important;
}
<?php endif; ?>
<?php if ( isset( $colors['dark'] ) ) : ?>
.drts {
	--bs-dark: <?php echo $colors['dark'][0]; ?>; /
}
.drts .<?php echo $prefix; ?>text-dark {
	color: <?php echo $colors['dark'][0]; ?> !important;
}
.drts .<?php echo $prefix; ?>text-dark-emphasis {
	color: color-mix(in srgb, <?php echo $colors['dark'][0]; ?>, black 20%) !important;
}
.drts .<?php echo $prefix; ?>btn-dark,
.drts .<?php echo $prefix; ?>btn-dark.<?php echo $prefix; ?>disabled,
.drts .<?php echo $prefix; ?>btn-dark:disabled {
	color: #fff;
	background-color: <?php echo $colors['dark'][0]; ?>;
	border-color: <?php echo $colors['dark'][0]; ?>;
}
.drts .<?php echo $prefix; ?>btn-dark:hover {
	color: #fff;
	background-color: <?php echo $colors['dark'][-7]; ?>;
	border-color: <?php echo $colors['dark'][-9]; ?>;
}
.drts .<?php echo $prefix; ?>btn-dark:focus,
.drts .<?php echo $prefix; ?>btn-dark.<?php echo $prefix; ?>focus {
	color: #fff;
	background-color: <?php echo $colors['dark'][-7]; ?>;
	border-color: <?php echo $colors['dark'][-9]; ?>;
}
.drts .<?php echo $prefix; ?>btn-dark:not(:disabled):not(.<?php echo $prefix; ?>disabled):active,
.drts .<?php echo $prefix; ?>btn-dark:not(:disabled):not(.<?php echo $prefix; ?>disabled).<?php echo $prefix; ?>active,
.drts .<?php echo $prefix; ?>show > .<?php echo $prefix; ?>btn-dark.<?php echo $prefix; ?>dropdown-toggle {
	color: #fff;
	background-color: <?php echo $colors['dark'][-9]; ?>;
	border-color: <?php echo $colors['dark'][-12]; ?>;
}
.drts .<?php echo $prefix; ?>btn-outline-dark {
	color: <?php echo $colors['dark'][0]; ?>;
	border-color: <?php echo $colors['dark'][0]; ?>;
}
.drts .<?php echo $prefix; ?>btn-outline-dark:hover,
.drts .<?php echo $prefix; ?>btn-outline-dark:not(:disabled):not(.<?php echo $prefix; ?>disabled):active,
.drts .<?php echo $prefix; ?>btn-outline-dark:not(:disabled):not(.<?php echo $prefix; ?>disabled).<?php echo $prefix; ?>active,
.drts .<?php echo $prefix; ?>show > .<?php echo $prefix; ?>btn-outline-dark.<?php echo $prefix; ?>dropdown-toggle {
	color: #fff;
	background-color: <?php echo $colors['dark'][0]; ?>;
	border-color: <?php echo $colors['dark'][0]; ?>;
}
.drts .<?php echo $prefix; ?>btn-outline-dark.<?php echo $prefix; ?>disabled,
.drts .<?php echo $prefix; ?>btn-outline-dark:disabled {
	color: <?php echo $colors['dark'][0]; ?>;
}
.drts .<?php echo $prefix; ?>bg-dark,
.drts .<?php echo $prefix; ?>text-bg-dark {
	background-color: rgba(<?php echo implode( ', ', $colors['dark']['rgb'][0] ); ?>, var(--bs-bg-opacity, 1)) !important;
}
.drts .<?php echo $prefix; ?>bg-dark-subtle {
	background-color: rgba(<?php echo implode( ', ', $colors['dark']['rgb'][25] ); ?>, 0.4) !important;
}
.drts a.<?php echo $prefix; ?>bg-dark:hover,
.drts  a.<?php echo $prefix; ?>bg-dark:focus,
.drts button.<?php echo $prefix; ?>bg-dark:hover,
.drts button.<?php echo $prefix; ?>bg-dark:focus {
	background-color: <?php echo $colors['dark'][-9]; ?> !important;
}
.drts .<?php echo $prefix; ?>border-dark {
	border-color: rgba(<?php echo implode( ', ', $colors['dark']['rgb'][0] ); ?>, var(--bs-border-opacity)) !important;
}
<?php endif; ?>