<?php
namespace SabaiApps\Directories\Component\System\Helper;

use SabaiApps\Directories\Application;
use SabaiApps\Directories\Component\System\Model\Component;
use SabaiApps\Directories\Exception;

/**
 * ComponentHelper provides methods for managing components: install, upgrade, config, and reload.
 */
class ComponentHelper {

	/**
	 * Fetches a component entity from the database.
	 *
	 * @param Application $application
	 * @param string      $componentName
	 * @return Component
	 * @throws Exception\RuntimeException
	 */
	public function help( Application $application, $componentName ) {
		if ( ! $component = $application->getModel( 'Component', 'System' )->fetchById( $componentName ) ) {
			throw new Exception\RuntimeException( 'Failed fetching component from database: ' . $componentName );
		}
		return $component;
	}

	/**
	 * Installs a component by name.
	 *
	 * @param Application $application
	 * @param string      $componentName
	 * @param int         $priority
	 * @return Component
	 * @throws Exception\UnexpectedValueException
	 * @throws Exception\ComponentNotInstallableException
	 */
	public function install( Application $application, $componentName, $priority = 0 ) {
		// Check if plugin name is not a reserved name
		$reserved_component_names = array( 'Sabai', 'Main', 'Admin', 'Component', 'Application', 'Model', 'Helper', 'Core', 'Platform', 'Components' );
		if ( in_array( strtolower( $componentName ), array_map( 'strtolower', $reserved_component_names ) ) ) {
			throw new Exception\UnexpectedValueException( sprintf( 'Component name %s is reserved by the system.', $componentName ) );
		}
		if ( ! preg_match( Application::COMPONENT_NAME_REGEX, $componentName ) ) {
			throw new Exception\UnexpectedValueException( sprintf( 'Invalid component name %s.', $componentName ) );
		}

		$_component = $application->fetchComponent( $componentName );

		if ( ! $_component->isInstallable() ) {
			throw new Exception\ComponentNotInstallableException( 'Component is not installable.' );
		}

		$component           = $application->getModel( null, 'System' )->create( 'Component' );
		$component->name     = $_component->getName();
		$component->version  = $_component->getVersion();
		$component->priority = $priority >= 99 ? 98 : $priority;
		$component->config   = $_component->getDefaultConfig();
		$component->events   = $application->ComponentEvents( $_component );

		$component->markNew()->commit();

		$_component->install();

		return $component;
	}

	/**
	 * Installs multiple components.
	 *
	 * @param Application $application
	 * @param array       $components
	 * @return array
	 */
	public function installAll( Application $application, array $components ) {
		if ( empty( $components ) ) {
			return;
		}

		$component_entities = array();
		foreach ( $components as $component_name ) {
			$component_entities[ $component_name ] = $this->install( $application, $component_name, 0 );
		}
		$application->reloadComponents();
		foreach ( $component_entities as $component_name => $component_entity ) {
			$application->Action( 'system_component_installed', array( $component_entity ) );
		}
		$application->getPlatform()->clearCache();

		return array_keys( $component_entities );
	}

	/**
	 * Upgrades a component to the latest version.
	 *
	 * @param Application      $application
	 * @param Component|string $component
	 * @param bool             $force
	 * @return Component|null
	 */
	public function upgrade( Application $application, $component, $force = false ) {
		if ( ! $component instanceof Component ) {
			$component = $this->help( $application, $component );
		}
		if ( ! $application->isComponentLoaded( $component->name ) ) {
			return;
		}

		$_component  = $application->getComponent( $component->name );
		$new_version = $_component->getVersion();
		if ( $force
			|| $_component->isUpgradeable( $component->version, $new_version )
		) {
			$_component->upgrade( $component, $new_version );
			$component->version = $new_version;
			$component->config  = array_replace_recursive( $_component->getDefaultConfig(), (array) $component->config );
			$component->events  = $application->ComponentEvents( $_component );
			$component->commit();
		}

		return $component;
	}

	/**
	 * Upgrades all components or a given list of components.
	 *
	 * @param Application $application
	 * @param array|null  $components
	 * @param bool        $force
	 * @return array
	 */
	public function upgradeAll( Application $application, ?array $components = null, $force = false ) {
		$model = $application->getModel( 'Component', 'System' );
		if ( ! empty( $components ) ) {
			$model->name_in( $components );
		}
		$component_entities = $component_versions = array();
		foreach ( $model->fetch() as $component ) {
			$component_versions[ $component->name ] = $component->version;
			if ( $component_entity = $this->upgrade( $application, $component, $force ) ) {
				$component_entities[ $component->name ] = $component_entity;
			}
		}
		$application->reloadComponents();
		foreach ( $component_entities as $component_name => $component_entity ) {
			$application->Action( 'system_component_upgraded', array( $component_entity, $component_versions[ $component_name ] ) );
		}
		$application->getPlatform()->clearCache();

		return array_keys( $component_entities );
	}

	/**
	 * Saves the configuration for a component.
	 *
	 * @param Application $application
	 * @param string      $componentName
	 * @param array       $config
	 * @param bool        $merge
	 */
	public function saveConfig( Application $application, $componentName, array $config, $merge = true ) {
		if ( ! $application->isComponentLoaded( $componentName ) ) {
			return;
		}

		$component      = $this->help( $application, $componentName );
		$current_config = (array) $component->config;

		// Merge current config?
		if ( $merge && $current_config ) {
			$this->_merge( $config, $current_config, $merge );
		}

		$component->config = $config;
		$component->commit();

		// The persisted component-info caches (core_components_loaded /
		// core_components_installed) bake in each component's config, so the
		// next request would keep serving the pre-save config until something
		// clears them. The settings-form controller used to do this itself
		// after every saveConfig() call; do it here so every caller is covered
		// (e.g. Account adopting FrontendSubmit's login/register config during
		// a component reload - without this the migrated values are correct in
		// the DB but the Settings page shows the old ones until a manual
		// reload).
		$application->clearComponentInfoCache();

		$application->getComponent( $componentName )->init( $config );

		$application->Action( 'system_component_config_saved', array( $componentName, $config ) );
	}

	/**
	 * Recursively merges new config values with old ones.
	 *
	 * @param array    $new
	 * @param array    $old
	 * @param bool|int $deeper
	 */
	protected function _merge( array &$new, array $old, $deeper = true ) {
		// Do not merge if values contains integer keys, since the value is coming from
		// checkboxes which we do not want to have it merged with old values.
		if ( array_key_exists( 0, $new )
			|| array_key_exists( 0, $old )
		) {
			return;
		}

		$new += $old;
		if ( $deeper !== true ) {
			--$deeper;
			if ( $deeper <= 0 ) {
				return;
			}
		}

		foreach ( array_keys( $new ) as $key ) {
			if ( is_array( $new[ $key ] )
				&& array_key_exists( $key, $old )
				&& is_array( $old[ $key ] )
			) {
				$this->_merge( $new[ $key ], $old[ $key ], $deeper );
			}
		}
	}

	/**
	 * Reloads all components, upgrading or installing as needed.
	 *
	 * @param Application $application
	 * @param array|null  $errors
	 */
	public function reload( Application $application, ?array &$errors = null ) {
		// A reload runs precisely because component files changed on disk
		// (components added, moved, renamed; controllers or event listeners
		// relocated between components). A component-info / component-events /
		// route cache left over from the previous file set can reference
		// classes or listener methods that no longer exist and fatal partway
		// through the reload - which is why running "Clear cache" before
		// "Reload components" succeeds where "Reload components" alone throws a
		// 500. Start from a cold cache so everything below rebuilds from the
		// current files. Session vars (multi-step form storage included) live
		// under an excluded prefix and survive this clear.
		$application->getPlatform()->clearCache();
		$application->clearComponentInfoCache();
		// Rebuild the in-memory component-by-interface map from the current
		// files before reloadComponents() below fires core_components_loaded:
		// that action runs listeners (e.g. Notification's) which look components
		// up by interface, and the memoised map from earlier in the request
		// still lists interfaces a component shed in this update (e.g.
		// FrontendSubmit dropping Notification\IEvents), leading to a
		// "call to undefined method" fatal.
		$application->InstalledComponentsByInterface( null, true );
		$application->reloadComponents();

		$components_upgraded = $this->upgradeAll( $application, null, true );
		$installed_entities  = array();
		foreach ( array_keys( $application->LocalComponents() ) as $component_name ) {
			if ( ! in_array( $component_name, $components_upgraded ) ) {
				try {
					$installed_entities[ $component_name ] = $this->install( $application, $component_name );
				} catch ( Exception\IException $e ) {
					if ( isset( $errors ) ) {
						$errors[] = sprintf(
							'Failed installing component %s (Error: %s)',
							$component_name,
							$e->getMessage()
						);
					} else {
						throw $e;
					}
				}
			}
		}
		if ( $installed_entities ) {
			// Load the just-installed components into the running application so
			// reloadAllRoutes() below sees them (and their IAdminRouter/IMainRouter
			// interfaces) this pass - otherwise a brand-new component's routes only
			// register on a *second* reload, once it is loaded at request start.
			$application->reloadComponents();
			// Rebuild the component-by-interface map now that the new components
			// exist: it was last built (at the top of this method) before they
			// were installed, and consumers like SlugsHelper read it WITHOUT
			// forcing. A stale map here means System_Slugs() skips a new
			// component, its slug pages never get created, and its slug-gated
			// routes (e.g. Account's /login/*) are absent until a second reload.
			$application->InstalledComponentsByInterface( null, true );
			// Fire the same post-install action installAll() does, now that the
			// listeners are loaded. Brand-new components rely on this to migrate
			// config/data from a component they were split out of (e.g. Account
			// adopting FrontendSubmit's login/register settings). install() on
			// its own does not dispatch it, so without this the migration never
			// runs on the update path and those settings come back empty.
			foreach ( $installed_entities as $component_entity ) {
				$application->Action( 'system_component_installed', array( $component_entity ) );
			}
		}
		$application->getComponent( 'System' )->reloadAllRoutes();
	}
}
