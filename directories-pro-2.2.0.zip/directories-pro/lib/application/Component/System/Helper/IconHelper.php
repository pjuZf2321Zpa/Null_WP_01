<?php
namespace SabaiApps\Directories\Component\System\Helper;

use SabaiApps\Directories\Application;
use SabaiApps\Directories\Component\Entity\Model\Bundle;
use SabaiApps\Directories\Component\Form;

/**
 * IconHelper provides various utility methods for icon operations.
 */
class IconHelper {

	/**
	 * Returns icon size options.
	 *
	 * @param Application $application
	 * @return array
	 */
	public function sizeOptions( Application $application ) {
		return $application->Filter(
			'system_icon_size_options',
			array(
				'sm' => __( 'Small', 'directories-pro' ),
				''   => __( 'Medium', 'directories-pro' ),
			)
		);
	}

	/**
	 * Returns the icon settings form for a bundle.
	 *
	 * @param Application $application
	 * @param Bundle      $bundle
	 * @param array       $settings
	 * @param array       $parents
	 * @param int|null    $weight
	 * @param bool        $horizontal
	 * @return array
	 */
	public function settingsForm( Application $application, Bundle $bundle, array $settings, array $parents = array(), $weight = null, $horizontal = true ) {
		if ( empty( $bundle->info['entity_icon'] )
			&& empty( $bundle->info['entity_image'] )
		) {
			return array();
		}

		$form = array(
			'icon'          => array(
				'#type'          => 'checkbox',
				'#title'         => __( 'Show icon', 'directories-pro' ),
				'#default_value' => ! empty( $settings['icon'] ),
				'#weight'        => isset( $weight ) ? $weight : null,
				'#horizontal'    => $horizontal,
			),
			'icon_settings' => array(
				'#tree'             => true,
				'#element_validate' => array(
					function ( Form\Form $form, &$value ) use ( $bundle ) {
						$value['is_image'] = ! empty( $bundle->info['entity_image'] );
					},
				),
				'#weight'           => isset( $weight ) ? ++$weight : null,
				'#states'           => array(
					'visible' => array(
						sprintf( 'input[name="%s"]', $application->Form_Form_fieldName( array_merge( $parents, array( 'icon' ) ) ) ) => array(
							'type'  => 'checked',
							'value' => true,
						),
					),
				),
				'size'              => array(
					'#type'          => 'select',
					'#title'         => __( 'Icon size', 'directories-pro' ),
					'#default_value' => isset( $settings['icon_settings']['size'] ) ? $settings['icon_settings']['size'] : null,
					'#options'       => $application->System_Icon_sizeOptions(),
					'#horizontal'    => $horizontal,
				),
				'fallback'          => array(
					'#type'          => 'checkbox',
					'#title'         => __( 'Fallback to default icon', 'directories-pro' ),
					'#default_value' => ! empty( $settings['icon_settings']['fallback'] ),
					'#states'        => array(
						'invisible' => array(
							sprintf( '[name="%s"]', $application->Form_Form_fieldName( array_merge( $parents, array( 'icon_settings', 'field' ) ) ) ) => array(
								'value' => '',
							),
						),
					),
					'#horizontal'    => $horizontal,
				),
			),
		);

		if ( empty( $bundle->info['entity_image'] ) ) {
			// Add color options
			$form['icon_settings']['color'] = $this->colorSettingsForm(
				$application,
				$bundle,
				isset( $settings['icon_settings']['color'] ) && is_array( $settings['icon_settings']['color'] ) ? $settings['icon_settings']['color'] : array(),
				array_merge( $parents, array( 'icon_settings', 'color' ) ),
				$horizontal
			);
		}

		return $form;
	}

	/**
	 * Returns the icon color settings form for a bundle.
	 *
	 * @param Application $application
	 * @param Bundle      $bundle
	 * @param array       $settings
	 * @param array       $parents
	 * @param bool        $horizontal
	 * @return array
	 */
	public function colorSettingsForm( Application $application, Bundle $bundle, array $settings, array $parents = array(), $horizontal = true, $prefix = '' ) {
		$color_field_options = $application->Entity_Field_options(
			$bundle,
			array(
				'interface'       => 'Field\Type\ColorType',
				'prefix'          => __( 'Field - ', 'directories-pro' ),
				'return_disabled' => true,
			)
		);
		return array(
			'type'   => array(
				'#type'             => 'select',
				'#title'            => $prefix . __( 'Icon color', 'directories-pro' ),
				'#default_value'    => isset( $settings['type'] ) ? $settings['type'] : '',
				'#options'          => $color_field_options[0] + array(
					'_custom' => __( 'Choose a color', 'directories-pro' ),
					''        => __( 'Default', 'directories-pro' ),
				),
				'#options_disabled' => array_keys( $color_field_options[1] ),
				'#horizontal'       => $horizontal,
			),
			'custom' => array(
				'#type'          => 'colorpicker',
				'#default_value' => isset( $settings['custom'] ) ? $settings['custom'] : null,
				'#states'        => array(
					'visible' => array(
						sprintf( 'select[name="%s"]', $application->Form_Form_fieldName( array_merge( $parents, array( 'type' ) ) ) ) => array(
							'value' => '_custom',
						),
					),
				),
				'#horizontal'    => $horizontal,
			),
		);
	}

	/**
	 * Converts icon settings to permalink options.
	 *
	 * @param Application $application
	 * @param mixed       $bundle
	 * @param array       $settings
	 * @return array
	 */
	public function settingsToPermalinkOptions( Application $application, $bundle, array $settings ) {
		if ( ( ! $bundle = $application->Entity_Bundle( $bundle ) )
			|| empty( $settings['icon'] )
			|| empty( $settings['icon_settings'] )
		) {
			return array();
		}

		$options = array(
			'icon'          => empty( $bundle->info['entity_image'] ) ? @$bundle->info['entity_icon'] : $bundle->info['entity_image'],
			'icon_is_image' => ! empty( $bundle->info['entity_image'] ) || ! empty( $bundle->info['entity_icon_is_image'] ),
			'icon_size'     => $settings['icon_settings']['size'],
			'icon_fallback' => ! empty( $settings['icon_settings']['fallback'] ),
		);
		if ( ! empty( $settings['icon_settings']['color']['type'] ) ) {
			$options['icon_color'] = $settings['icon_settings']['color']['type'] === '_custom'
				? $settings['icon_settings']['color']['custom']
				: $settings['icon_settings']['color']['type'];
		}
		return $options;
	}
}
