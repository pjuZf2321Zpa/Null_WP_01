<?php
namespace SabaiApps\Directories\Component\System\Helper;

use SabaiApps\Directories\Application;
use SabaiApps\Directories\Exception;

/**
 * CustomCssHelper provides various utility methods for custom CSS manipulation.
 */
class CustomCssHelper {

	/**
	 * Fallback hex value for a color the admin hasn't customized - see
	 * generateFile()'s own use below, and SettingsFormHelper's colorpicker
	 * settings form, which shows these same values as its "Default color:
	 * #xxx" hint text.
	 */
	const DEFAULT_COLORS = array(
		'primary'   => '#467FCF',
		'secondary' => '#868E96',
		'light'     => '#F8F9FA',
		'dark'      => '#212529',
	);

	/**
	 * Generates a custom CSS file based on settings.
	 *
	 * @param Application $application
	 * @param array|null  $settings
	 * @param array|null  $oldSettings
	 * @param bool        $force
	 * @throws Exception\RuntimeException
	 */
	public function generateFile( Application $application, ?array $settings = null, ?array $oldSettings = null, $force = false ) {
		$file              = $application->getPlatform()->getVarDir() . '/style.css';
		$file_no_bs_prefix = $application->getPlatform()->getVarDir() . '/style-no-bs-prefix.css';
		if ( ! isset( $settings ) ) {
			$settings = $application->getComponent( 'System' )->getConfig();
		}
		if ( ! $force
			&& isset( $oldSettings )
			&& file_exists( $file )
			&& file_exists( $file_no_bs_prefix )
		) {
			if ( $settings == array(
				'css'   => isset( $oldSettings['css'] ) ? $oldSettings['css'] : null,
				'color' => isset( $oldSettings['color'] ) ? $oldSettings['color'] : null,
			) ) {
				return; // no change so abort
			}
		}

		$custom_css = '';
		if ( strlen( $settings['css']['custom_css'] ) ) {
			$custom_css .= $settings['css']['custom_css'];
		}
		$colors = array();
		foreach ( array( 'primary', 'secondary', 'light', 'dark' ) as $color ) {
			// Fall back to the default color rather than skipping this
			// color entirely - _style.php's --drts-bg-primary/
			// etc. CSS custom properties must always be defined, since
			// other CSS (e.g. Comparison's own stylesheet) references them
			// unconditionally and would otherwise render with a transparent
			// background whenever the admin hasn't customized a color.
			// The value is written into a CSS file, so accept a 6-digit hex color only
			$hex              = ! empty( $settings['color'][ $color ] ) && preg_match( '/^#[0-9a-f]{6}$/i', (string) $settings['color'][ $color ] )
				? $settings['color'][ $color ]
				: self::DEFAULT_COLORS[ $color ];
			$colors[ $color ] = $this->_getCustomCssColors( $application, $hex );
		}
		foreach ( array(
			DRTS_BS_PREFIX => $file,
			''             => $file_no_bs_prefix,
		) as $prefix => $_file ) {
			$css = $custom_css;
			if ( ! empty( $colors ) ) {
				ob_start();
				include __DIR__ . '/_style.php';
				$css .= ob_get_clean();
			}
			if ( strlen( $css ) ) {
				if ( false === file_put_contents( $_file, $css ) ) {
					throw new Exception\RuntimeException( 'Error writing into file: ' . $_file . '. Make sure the file can be created and is writeable.' );
				}
			} else {
				$application->getPlatform()->deleteFile( $_file );
			}
		}
	}

	/**
	 * Helper to get custom CSS color variations.
	 *
	 * @param Application $application
	 * @param string      $hex
	 * @return array
	 */
	protected function _getCustomCssColors( Application $application, $hex ) {
		$hsl = $application->System_Color_hexToHsl( $hex = substr( $hex, 1 ) );
		foreach ( array( -30, -20, -15, -12, -9, -7, -5, 5, 7, 9, 12, 15, 25, 30, 40 ) as $percent ) {
			$_hex = $application->System_Color_hslToHex( array( $hsl[0], $hsl[1], ( $hsl[2] * 100 + $percent ) / 100 ) );
			if ( $_hex === 'ffffff' ) {
				$_hex = $hex;
			}
			$ret[ $percent ] = '#' . $_hex;
			foreach ( $application->System_Color_hexToRgb( $_hex ) as $_rgb ) {
				$ret['rgb'][ $percent ][] = $_rgb * 255;
			}
		}
		$ret[0] = '#' . $hex;
		foreach ( $application->System_Color_hexToRgb( $hex ) as $_rgb ) {
			$ret['rgb'][0][] = $_rgb * 255;
		}

		return $ret;
	}
}
