<?php
namespace SabaiApps\Directories\Component\System\Helper;

use SabaiApps\Directories\Application;

/**
 * TranslateStringHelper provides translation and auto-registration of strings for localization.
 */
class TranslateStringHelper {

	protected $_translate, $_autoRegister;

	/**
	 * Constructor.
	 *
	 * @param Application $application
	 */
	public function __construct( Application $application ) {
		$this->_translate    = $application->getPlatform()->getLanguages() ? true : false;
		$this->_autoRegister = $this->_translate && $application->getComponent( 'System' )->getConfig( 'auto_reg_str' );
	}

	/**
	 * Translates a string and optionally auto-registers it for translation.
	 *
	 * @param Application $application
	 * @param string      $str
	 * @param string      $name
	 * @param string      $domain
	 * @param string|null $lang
	 * @return string
	 */
	public function help( Application $application, $str, $name, $domain = 'directories-pro', $lang = null ) {
		if ( ! $this->_translate ) {
			return $str;
		}

		$translated = $application->getPlatform()->translateString( $str, $name, $domain, $lang );

		if ( $this->_autoRegister
			&& $translated === $str
		) {
			$application->getPlatform()->registerString( $str, $name, $domain );
		}

		return $translated;
	}
}
