<?php
namespace SabaiApps\Directories\Component\System\Helper;

use SabaiApps\Directories\Application;
use SabaiApps\Directories\Component\Entity\Type\IEntity;

/**
 * NoImageHelper provides a fallback image or URL when no image is available for an entity.
 */
class NoImageHelper {

	protected $_cache, $_urls = array();

	/**
	 * Returns a no-image HTML tag or image URL for a given size and entity.
	 *
	 * @param Application  $application
	 * @param string|null  $size
	 * @param bool         $srcOnly
	 * @param IEntity|null $entity
	 * @param array        $attributes Additional attributes for the img tag. The class attribute is appended to the default class.
	 * @return string
	 */
	public function help( Application $application, $size = null, $srcOnly = false, ?IEntity $entity = null, array $attributes = array() ) {
		if ( ! isset( $this->_cache ) ) {
			$this->_cache = $application->Filter( 'core_no_image_cache', true );
		}

		if ( ! $url = $this->url( $application, $size, $entity ) ) {
			// 240x180 px transparent png
			$url = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAPAAAAC0CAQAAAAAlWljAAABH0lEQVR42u3RAQ0AAAzCsOPf9HVAOglrTtPFAsACLMACLMACLMCABViABViABViAAQuwAAuwAAuwAAswYAEWYAEWYAEWYMACLMACLMACLMCABViABViABViABRiwAAuwAAuwAAswYAEWYAEWYAEWYMACLMACLMACLMACDFiABViABViABRiwAAuwAAuwAAuwAAMWYAEWYAEWYAEGLMACLMACLMACDFiABViABViABViAAQuwAAuwAAuwAAMWYAEWYAEWYAEGLMACLMACLMACLMCABViABViABViAAQuwAAuwAAuwAAswYAEWYAEWYAEWYMACLMACLMACLMCABViABViABViABRiwAAuwAAuwAAswYAEWYAEWYAEWYMACrNYe6J4AtdAWxOcAAAAASUVORK5CYII=';
		}

		if ( $srcOnly ) {
			return $url;
		}

		$attributes          = array_filter(
			array_merge( array( 'alt' => '' ), $attributes ),
			function ( $v ) {
				return $v !== null && $v !== false;
			}
		);
		$attributes['class'] = trim( 'drts-no-image ' . ( $attributes['class'] ?? '' ) );
		$attributes['src']   = $url;

		return '<img' . $application->Attr( $attributes ) . ' />';
	}

	/**
	 * Returns the URL for a no-image placeholder for a given size and entity.
	 *
	 * @param Application  $application
	 * @param string|null  $size
	 * @param IEntity|null $entity
	 * @return string
	 */
	public function url( Application $application, $size = null, ?IEntity $entity = null ) {
		if ( ! $this->_cache ) {
			return $application->Filter( 'core_no_image_src', false, array( $size, $entity ) );
		}

		if ( ! in_array( $size, array( 'icon', 'thumbnail', 'medium', 'large' ) ) ) {
			$size = 'full';
		}
		if ( ! isset( $this->_urls[ $size ] ) ) {
			$this->_urls[ $size ] = $application->Filter( 'core_no_image_src', false, array( $size, $entity ) );

		}
		return $this->_urls[ $size ];
	}
}
