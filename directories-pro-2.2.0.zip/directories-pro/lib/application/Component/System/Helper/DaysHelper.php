<?php
namespace SabaiApps\Directories\Component\System\Helper;

use SabaiApps\Directories\Application;

/**
 * DaysHelper provides day names and utilities for week days.
 */
class DaysHelper {

	const MONDAY = 1, TUESDAY = 2, WEDNESDAY = 3, THURSDAY = 4, FRIDAY = 5, SATURDAY = 6, SUNDAY = 7;

	protected $_days;

	/**
	 * Returns the name of a day or an array of all days, optionally starting from a specific day.
	 *
	 * @param Application $application
	 * @param int|null    $value
	 * @param int|null    $startOfWeek
	 * @return string|array
	 */
	public function help( Application $application, $value = null, $startOfWeek = null ) {
		if ( isset( $value ) ) {
			return isset( $this->_days ) ? $this->_days[ $value ] : $this->_day( $value );
		}

		if ( ! isset( $this->_days ) ) {
			foreach ( range( self::MONDAY, self::SUNDAY ) as $value ) {
				$this->_days[ $value ] = $this->_day( $value );
			}
			$start_of_week = isset( $startOfWeek ) && is_int( $startOfWeek ) ? $startOfWeek : (int) $application->getPlatform()->getStartOfWeek();
			if ( isset( $this->_days[ $start_of_week ] ) && $start_of_week !== self::MONDAY ) {
				$_days = array( $start_of_week => $this->_days[ $start_of_week ] );
				unset( $this->_days[ $start_of_week ] );
				for ( $i = $start_of_week + 1; $i <= self::SUNDAY; $i++ ) {
					$_days[ $i ] = $this->_days[ $i ];
					unset( $this->_days[ $i ] );
				}
				foreach ( $this->_days as $i => $_day ) {
					$_days[ $i ] = $_day;
				}
				$this->_days = $_days;
			}
		}

		return $this->_days;
	}

	/**
	 * Returns the name of a day for a given value.
	 *
	 * @param int $value
	 * @return string
	 */
	protected function _day( $value ) {
		switch ( $value ) {
			case self::MONDAY:
				return __( 'Monday', 'directories-pro' );
			case self::TUESDAY:
				return __( 'Tuesday', 'directories-pro' );
			case self::WEDNESDAY:
				return __( 'Wednesday', 'directories-pro' );
			case self::THURSDAY:
				return __( 'Thursday', 'directories-pro' );
			case self::FRIDAY:
				return __( 'Friday', 'directories-pro' );
			case self::SATURDAY:
				return __( 'Saturday', 'directories-pro' );
			case self::SUNDAY:
				return __( 'Sunday', 'directories-pro' );
			default:
				return '';
		}
	}

	/**
	 * Returns the string for "All week".
	 *
	 * @param Application $application
	 * @return string
	 */
	public function allWeekStr( Application $application ) {
		return __( 'All week', 'directories-pro' );
	}
}
