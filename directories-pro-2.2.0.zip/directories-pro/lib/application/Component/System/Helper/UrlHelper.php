<?php
namespace SabaiApps\Directories\Component\System\Helper;

use SabaiApps\Directories\Application;

/**
 * UrlHelper provides various utility methods for URL operations.
 */
class UrlHelper {

	/**
	 * Gets the public URL for a given path.
	 *
	 * @param Application $application
	 * @param string      $path
	 * @return string
	 */
	public function site( Application $application, $path = null ) {
		$site_url = $application->getPlatform()->getSiteUrl();
		if ( ! isset( $path ) ) {
			return $site_url;
		}

		$site_path = $application->getPath( $application->getPlatform()->getSitePath() );
		$site_url  = $application->getPlatform()->getSiteUrl();
		return $site_path !== '/' // For sites with a slash only site path, for some reason
			? str_replace( $site_path, $site_url, $path )
			: $site_url . $path;
	}

	protected $_images = array();

	/**
	 * Gets the URL for an image file.
	 *
	 * @param Application $application
	 * @param string      $file Image file name.
	 * @param string|null $package Optional package name.
	 * @return string
	 */
	public function image( Application $application, $file, $package = null ) {
		if ( isset( $package ) ) {
			return $application->getPlatform()->getAssetsUrl( $package ) . '/images/' . $file;
		}

		if ( ! isset( $this->_images[ $file ] ) ) {
			$this->_images[ $file ] = $this->_getImageFileUrl( $application, $file );
		}
		return $this->_images[ $file ];
	}

	/**
	 * Finds the image file URL in custom asset directories or falls back to the default.
	 *
	 * @param Application $application
	 * @param string      $file
	 * @return string
	 */
	protected function _getImageFileUrl( Application $application, $file ) {
		foreach ( $application->getPlatform()->getCustomAssetsDir() as $index => $custom_dir ) {
			if ( file_exists( $custom_dir . '/' . $file ) ) {
				return $application->getPlatform()->getCustomAssetsDirUrl( $index ) . '/' . $file;
			}
		}
		return $application->getPlatform()->getAssetsUrl() . '/images/' . $file;
	}

	/**
	 * Gets the URL for a JavaScript file.
	 *
	 * @param Application $application
	 * @param string      $file JavaScript file name.
	 * @param string|null $package Optional package name.
	 * @return string
	 */
	public function js( Application $application, $file, $package = null ) {
		return $application->getPlatform()->getAssetsUrl( $package ) . '/js/' . $file;
	}

	/**
	 * Gets the login URL, optionally with a redirect.
	 *
	 * @param Application $application
	 * @param string      $redirect
	 * @return string
	 */
	public function login( Application $application, $redirect = '' ) {
		$redirect = (string) $redirect;
		return $application->Filter( 'core_login_url', $application->getPlatform()->getLoginUrl( $redirect ), array( $redirect ) );
	}

	/**
	 * Gets the Gravatar URL for an email address.
	 *
	 * @param Application $application
	 * @param string      $email
	 * @param int         $size
	 * @param string      $default
	 * @param string|null $rating
	 * @param bool        $secure
	 * @return string
	 */
	public function gravatar( Application $application, $email, $size = 96, $default = 'mm', $rating = null, $secure = false ) {
		$url = sprintf(
			'%s://www.gravatar.com/avatar/%s?s=%d&d=%s',
			$secure ? 'https' : 'http',
			md5( strtolower( $email ) ),
			$size,
			urlencode( $default )
		);
		if ( isset( $rating ) ) {
			$url .= '&r=' . urlencode( $rating );
		}

		return $url;
	}
}
