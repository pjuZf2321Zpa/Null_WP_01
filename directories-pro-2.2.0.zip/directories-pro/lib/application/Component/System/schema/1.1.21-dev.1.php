<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
use SabaiApps\Directories\Application;

$tables = array(
	'system_component' => array(
		'fields'         => array(
			'component_name'     => array(
				'type'    => Application::COLUMN_VARCHAR,
				'notnull' => true,
				'length'  => 40,
				'default' => '',
			),
			'component_version'  => array(
				'type'    => Application::COLUMN_VARCHAR,
				'notnull' => true,
				'length'  => 30,
				'default' => '',
			),
			'component_priority' => array(
				'type'     => Application::COLUMN_INTEGER,
				'unsigned' => true,
				'notnull'  => true,
				'length'   => 2,
				'default'  => 0,
			),
			'component_config'   => array(
				'type'    => Application::COLUMN_TEXT,
				'notnull' => true,
			),
			'component_events'   => array(
				'type'    => Application::COLUMN_TEXT,
				'notnull' => true,
			),
			'component_created'  => array(
				'type'     => Application::COLUMN_INTEGER,
				'unsigned' => true,
				'notnull'  => true,
				'length'   => 10,
				'default'  => 0,
			),
			'component_updated'  => array(
				'type'     => Application::COLUMN_INTEGER,
				'unsigned' => true,
				'notnull'  => true,
				'length'   => 10,
				'default'  => 0,
			),
		),
		'indexes'        => array(
			'component_name'     => array(
				'primary' => true,
				'fields'  => array(
					'component_name' => array( 'sorting' => 'ascending' ),
				),
			),
			'component_priority' => array(
				'fields' => array(
					'component_priority' => array(),
				),
			),
		),
		'initialization' => array(
			'insert' => array(
				array(
					'component_name'     => 'System',
					'component_created'  => '1357603200',
					'component_updated'  => '0',
					'component_version'  => '2.2.0',
					'component_priority' => '99',
					'component_config'   => '',
					'component_events'   => '',
				),
			),
		),
	),
	'system_route'     => array(
		'fields'         => array(
			'route_path'                 => array(
				'type'    => Application::COLUMN_VARCHAR,
				'notnull' => true,
				'length'  => 255,
				'default' => '',
			),
			'route_method'               => array(
				'type'    => Application::COLUMN_VARCHAR,
				'notnull' => true,
				'length'  => 10,
				'default' => '',
			),
			'route_format'               => array(
				'type'    => Application::COLUMN_TEXT,
				'notnull' => true,
			),
			'route_controller'           => array(
				'type'    => Application::COLUMN_VARCHAR,
				'notnull' => true,
				'length'  => 255,
				'default' => '',
			),
			'route_controller_component' => array(
				'type'    => Application::COLUMN_VARCHAR,
				'notnull' => true,
				'length'  => 40,
				'default' => '',
			),
			'route_forward'              => array(
				'type'    => Application::COLUMN_VARCHAR,
				'notnull' => true,
				'length'  => 255,
				'default' => '',
			),
			'route_component'            => array(
				'type'    => Application::COLUMN_VARCHAR,
				'notnull' => true,
				'length'  => 40,
				'default' => '',
			),
			'route_type'                 => array(
				'type'     => Application::COLUMN_INTEGER,
				'unsigned' => true,
				'notnull'  => true,
				'length'   => 2,
				'default'  => 0,
			),
			'route_access_callback'      => array(
				'type'    => Application::COLUMN_BOOLEAN,
				'notnull' => true,
				'default' => false,
			),
			'route_title_callback'       => array(
				'type'    => Application::COLUMN_BOOLEAN,
				'notnull' => true,
				'default' => false,
			),
			'route_callback_path'        => array(
				'type'    => Application::COLUMN_VARCHAR,
				'notnull' => true,
				'length'  => 255,
				'default' => '',
			),
			'route_callback_component'   => array(
				'type'    => Application::COLUMN_VARCHAR,
				'notnull' => true,
				'length'  => 40,
				'default' => '',
			),
			'route_weight'               => array(
				'type'     => Application::COLUMN_INTEGER,
				'unsigned' => true,
				'notnull'  => true,
				'length'   => 3,
				'default'  => 0,
			),
			'route_depth'                => array(
				'type'     => Application::COLUMN_INTEGER,
				'unsigned' => true,
				'notnull'  => true,
				'length'   => 2,
				'default'  => 0,
			),
			'route_priority'             => array(
				'type'     => Application::COLUMN_INTEGER,
				'unsigned' => true,
				'notnull'  => true,
				'length'   => 1,
				'default'  => 5,
			),
			'route_data'                 => array(
				'type'    => Application::COLUMN_TEXT,
				'notnull' => true,
			),
			'route_language'             => array(
				'type'    => Application::COLUMN_VARCHAR,
				'notnull' => true,
				'length'  => 7,
				'default' => '',
			),
			'route_admin'                => array(
				'type'    => Application::COLUMN_BOOLEAN,
				'notnull' => true,
				'default' => false,
			),
			'route_id'                   => array(
				'autoincrement' => true,
				'type'          => Application::COLUMN_INTEGER,
				'unsigned'      => true,
				'notnull'       => true,
				'length'        => 10,
				'default'       => 0,
			),
			'route_created'              => array(
				'type'     => Application::COLUMN_INTEGER,
				'unsigned' => true,
				'notnull'  => true,
				'length'   => 10,
				'default'  => 0,
			),
			'route_updated'              => array(
				'type'     => Application::COLUMN_INTEGER,
				'unsigned' => true,
				'notnull'  => true,
				'length'   => 10,
				'default'  => 0,
			),
		),
		'indexes'        => array(
			'route_id'        => array(
				'primary' => true,
				'fields'  => array(
					'route_id' => array( 'sorting' => 'ascending' ),
				),
			),
			'route_path'      => array(
				'fields' => array(
					'route_path' => array(),
				),
			),
			'route_component' => array(
				'fields' => array(
					'route_component' => array(),
				),
			),
			'route_depth'     => array(
				'fields' => array(
					'route_depth' => array(),
				),
			),
			'route_language'  => array(
				'fields' => array(
					'route_language' => array(),
				),
			),
		),
		'initialization' => array(
			'insert' => array(),
		),
	),
);
return array(
	'charset'     => '',
	'description' => '',
	'tables'      => $tables,
);
