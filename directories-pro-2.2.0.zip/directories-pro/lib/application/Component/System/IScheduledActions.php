<?php
namespace SabaiApps\Directories\Component\System;

interface IScheduledActions {

	public function systemScheduledActions();
}
