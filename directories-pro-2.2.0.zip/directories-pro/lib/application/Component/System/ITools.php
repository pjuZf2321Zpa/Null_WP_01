<?php
namespace SabaiApps\Directories\Component\System;

/**
 * ITools interface for components that provide tools.
 */
interface ITools {

	/**
	 * Returns an array of available tool names.
	 *
	 * @return array
	 */
	public function systemGetToolNames();

	/**
	 * Returns the tool object for the given tool name.
	 *
	 * @param string $name
	 * @return mixed
	 */
	public function systemGetTool( $name );
}
