<?php
namespace SabaiApps\Directories\Component\System\Tool;

use SabaiApps\Directories\Context;

/**
 * ClearLogsTool deletes all log files in the system log directory.
 */
class ClearLogsTool extends AbstractTool {

	/**
	 * Returns tool information.
	 *
	 * @return array
	 */
	protected function _systemToolInfo() {
		return array(
			'label'       => __( 'Clear log files', 'directories-pro' ),
			'description' => sprintf(
				/* translators: %s: log dir */
				__( 'This tool will clear all log files saved under %s.', 'directories-pro' ),
				$this->_application->getComponent( 'System' )->getLogDir()
			),
			'weight'      => 20,
			'redirect'    => true,
		);
	}

	/**
	 * Runs the log file clearing task.
	 *
	 * @param string       $task
	 * @param array        $settings
	 * @param int          $iteration
	 * @param int          $total
	 * @param array        $storage
	 * @param array        $logs
	 * @param Context|null $context
	 * @return int
	 */
	public function systemToolRunTask( $task, array $settings, $iteration, $total, array &$storage, array &$logs, ?Context $context = null ) {
		foreach ( glob( $this->_application->getComponent( 'System' )->getLogDir() . '/drts_*.log' ) as $log_file ) {
			if ( ! $this->_application->getPlatform()->deleteFile( $log_file ) ) {
				/* translators: %s: log file */
				$logs['error'][] = sprintf( __( 'Failed deleting log file: %s', 'directories-pro' ), $log_file );
			}
		}

		return 1;
	}
}
