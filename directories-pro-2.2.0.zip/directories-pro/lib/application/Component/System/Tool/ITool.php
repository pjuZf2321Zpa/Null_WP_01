<?php
namespace SabaiApps\Directories\Component\System\Tool;

use SabaiApps\Directories\Context;

/**
 * ITool interface for system tools.
 * Defines required methods for tool info, settings, task execution, and completion.
 */
interface ITool {

	/**
	 * Returns tool information as an array.
	 */
	public function systemToolInfo();

	/**
	 * Indicates whether the tool is supported.
	 *
	 * @return bool
	 */
	public function systemToolSupports();

	/**
	 * Returns the settings form for the tool step.
	 *
	 * @return array|false False if no settings form is needed.
	 */
	public function systemToolSettingsForm( $step, array $values, array $parents = array(), ?Context $context = null );

	/**
	 * Initializes the tool and returns an array of tasks.
	 */
	public function systemToolInit( array $settings, array &$storage, array &$logs, ?Context $context = null );

	/**
	 * Runs a single task for the tool.
	 */
	public function systemToolRunTask( $task, array $settings, $iteration, $total, array &$storage, array &$logs, ?Context $context = null );

	/**
	 * Called when the tool completes all tasks.
	 */
	public function systemToolComplete( array &$storage, array &$logs, &$downloadFile, ?Context $context = null );
}
