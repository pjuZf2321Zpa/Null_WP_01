<?php
namespace SabaiApps\Directories\Component\System\Tool;

use SabaiApps\Directories\Context;
use SabaiApps\Directories\Exception;

/**
 * ClearCacheTool clears all cached settings and data.
 */
class ClearCacheTool extends AbstractTool {

	/**
	 * Returns tool information.
	 *
	 * @return array
	 */
	protected function _systemToolInfo() {
		return array(
			'label'       => __( 'Clear cache', 'directories-pro' ),
			'description' => __( 'This tool will clear settings and data currently cached.', 'directories-pro' ),
			'weight'      => 5,
			'redirect'    => true,
		);
	}

	/**
	 * Runs the cache clearing task.
	 *
	 * @param string       $task
	 * @param array        $settings
	 * @param int          $iteration
	 * @param int          $total
	 * @param array        $storage
	 * @param array        $logs
	 * @param Context|null $context
	 * @return int
	 */
	public function systemToolRunTask( $task, array $settings, $iteration, $total, array &$storage, array &$logs, ?Context $context = null ) {
		$this->_application->getPlatform()->clearCache();
		$this->_application->Action( 'system_clear_cache' );

		// Regenerate custom CSS file.
		try {
			$this->_application->System_CustomCss_generateFile( null, null, true );
		} catch ( Exception\IException $e ) {
			$logs['error'][] = $e->getMessage();
		}

		return 1;
	}
}
