<?php
namespace SabaiApps\Directories\Component\System\Tool;

use SabaiApps\Directories\Context;
use SabaiApps\Directories\Exception\RuntimeException;

/**
 * ExportSettingsTool exports system settings to a file.
 */
class ExportSettingsTool extends AbstractExportJsonTool {

	/**
	 * Returns tool information.
	 *
	 * @return array
	 */
	protected function _systemToolInfo() {
		return array(
			'label'       => __( 'Export system settings', 'directories-pro' ),
			'description' => __( 'This tool exports the current system settings to a file.', 'directories-pro' ),
			'weight'      => 40,
		);
	}

	public function systemToolSupports() {
		return $this->_application->getPlatform()->getCache( 'system_settings_component_configs' ) ? true : false;
	}

	protected function _getDefaultJsonFileName( ?Context $context = null ) {
		return 'system_settings_' . gmdate( 'Ymd' );
	}

	protected function _export( array $settings, ?Context $context = null ) {
		$component_configs = $this->_application->getPlatform()->getCache( 'system_settings_component_configs' );
		if ( null === $component_configs ) {
			throw new RuntimeException( 'Failed retrieving component configurations from cache' );
		}

		return $component_configs;
	}
}
