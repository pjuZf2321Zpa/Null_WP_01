<?php
namespace SabaiApps\Directories\Component\System\Tool;

use SabaiApps\Directories\Context;
use SabaiApps\Directories\Exception\RuntimeException;

/**
 * ImportSettingsTool imports system settings from a file.
 */
class ImportSettingsTool extends AbstractImportJsonTool {

	/**
	 * Returns tool information.
	 *
	 * @return array
	 */
	protected function _systemToolInfo() {
		return array(
			'label'       => __( 'Import system settings', 'directories-pro' ),
			'description' => __( 'This tool imports system settings from a file.', 'directories-pro' ),
			'weight'      => 40,
			'redirect'    => true,
		);
	}

	protected function _import( array $data, array &$logs, ?Context $context = null ) {
		if ( ! is_array( $data ) ) {
			throw new RuntimeException( 'Invalid system settings data format' );
		}
		foreach ( array_keys( $data ) as $component_name ) {
			$this->_application->System_Component_saveConfig( $component_name, $data[ $component_name ], true );
		}
		$this->_application->clearComponentInfoCache();

		// Cache the imported settings for export tool
		$this->_application->getPlatform()->setCache( $data, 'system_settings_component_configs' );
	}
}
