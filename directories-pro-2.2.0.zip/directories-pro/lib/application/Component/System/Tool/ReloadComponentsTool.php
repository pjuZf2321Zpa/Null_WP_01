<?php
namespace SabaiApps\Directories\Component\System\Tool;

use SabaiApps\Directories\Context;

/**
 * ReloadComponentsTool reloads all components to ensure they are in sync with stored data.
 */
class ReloadComponentsTool extends AbstractTool {

	/**
	 * Returns tool information.
	 *
	 * @return array
	 */
	protected function _systemToolInfo() {
		return array(
			'label'       => __( 'Reload components', 'directories-pro' ),
			'description' => __( 'This tool will reload all componentns to ensure they are in sync with stored data.', 'directories-pro' ),
			'weight'      => 1,
			'redirect'    => true,
		);
	}

	/**
	 * Runs the reload components task.
	 *
	 * @param string       $task
	 * @param array        $settings
	 * @param int          $iteration
	 * @param int          $total
	 * @param array        $storage
	 * @param array        $logs
	 * @param Context|null $context
	 * @return int
	 */
	public function systemToolRunTask( $task, array $settings, $iteration, $total, array &$storage, array &$logs, ?Context $context = null ) {
		$this->_application->callHelper( 'System_Component_reload', array( $logs['error'] ) );

		return 1;
	}
}
