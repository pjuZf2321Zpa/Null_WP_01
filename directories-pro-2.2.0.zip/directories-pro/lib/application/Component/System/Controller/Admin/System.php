<?php
namespace SabaiApps\Directories\Component\System\Controller\Admin;

class System extends AbstractSystem{}
