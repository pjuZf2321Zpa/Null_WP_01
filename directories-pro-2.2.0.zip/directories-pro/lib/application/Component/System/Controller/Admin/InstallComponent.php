<?php
namespace SabaiApps\Directories\Component\System\Controller\Admin;

use SabaiApps\Directories\Component\Form;
use SabaiApps\Directories\Context;

/**
 * InstallComponent controller for handling the installation of a new component.
 */
class InstallComponent extends Form\Controller {

	private $_componentName;

	/**
	 * Returns the form settings for installing a component.
	 *
	 * @param Context $context
	 * @param array   $formStorage
	 * @return array|false
	 */
	protected function _doGetFormSettings( Context $context, array &$formStorage ) {
		$this->_componentName = $context->getRequest()->asStr( 'component_name' );

		// Fetch component info from the file system
		$local_components = $this->LocalComponents( true );
		if ( ! isset( $local_components[ $this->_componentName ] ) ) {
			return false;
		}

		$component_local = $local_components[ $this->_componentName ];

		$this->_submitButtons[] = array(
			'#btn_label' => __( 'Install Component', 'directories-pro' ),
			'#btn_color' => 'success',
		);

		$form = array(
			'#header'    => array(
				'<div class="' . DRTS_BS_PREFIX . 'alert ' . DRTS_BS_PREFIX . 'alert-info">' . sprintf(
					/* translators: %1$s: component name, %2$s: version */
					$this->H( __( 'You are about to install the %1$s (version: %2$s) component.', 'directories-pro' ) ),
					'<strong>' . $this->H( $this->_componentName ) . '</strong>',
					'<strong>' . $component_local['version'] . '</strong>'
				) . '</div>',
			),
			'#component' => $this->_componentName,
		);

		return $form;
	}

	/**
	 * Handles the form submission and installs the component.
	 *
	 * @param Form\Form $form
	 * @param Context   $context
	 */
	public function submitForm( Form\Form $form, Context $context ) {
		$component = $this->System_Component_install( $this->_componentName );
		$this->reloadComponents(); // Refresh components to include the installed component during the installed event
		$this->Action( 'system_component_installed', array( $component ) );
		$this->getPlatform()->clearCache();

		// Reload all routes
		$this->getComponent( 'System' )->reloadAllRoutes();

		$this->Action( 'system_admin_component_installed', array( $this->_componentName ) );

		$context->setSuccess( $this->Url( '/settings', array( 'refresh' => 0 ) ) )
			/* translators: %s: component name */
			->addFlash( sprintf( __( 'Component %s has been installed.', 'directories-pro' ), $this->_componentName ) );
	}
}
