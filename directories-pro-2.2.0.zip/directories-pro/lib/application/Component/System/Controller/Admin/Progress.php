<?php
namespace SabaiApps\Directories\Component\System\Controller\Admin;

use SabaiApps\Directories\Controller;
use SabaiApps\Directories\Context;

/**
 * Progress controller for displaying progress information via AJAX.
 */
class Progress extends Controller {

	/**
	 * Executes the controller logic to return progress data.
	 *
	 * @param Context $context
	 */
	protected function _doExecute( Context $context ) {
		if ( ( ! $name = $context->getRequest()->asStr( 'name' ) )
			|| ! $context->getRequest()->isAjax()
		) {
			$context->setError();
			return;
		}

		$context->addTemplate( 'system_list' )->setAttributes( array( 'list' => $this->System_Progress_get( $name ) ) );
	}
}
