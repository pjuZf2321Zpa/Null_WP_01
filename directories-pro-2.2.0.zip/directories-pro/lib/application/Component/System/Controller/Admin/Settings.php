<?php
namespace SabaiApps\Directories\Component\System\Controller\Admin;

use SabaiApps\Directories\Component\Form;
use SabaiApps\Directories\Context;

class Settings extends AbstractSettings {

	protected function _getSettingsForm( Context $context, array &$formStorage ) {
		$form                              = array(
			'#tabs'      => array(),
			'#tab_style' => 'pill_less_margin',
			'#name'      => 'system_admin_settings_form',
		);
		$settings_form                     = $this->Filter(
			'system_admin_settings_form',
			array(
				'tabs'   => array(),
				'fields' => array(),
			)
		);
		$settings_form['tabs']['general']  = array(
			'#title'  => __( 'General', 'directories-pro' ),
			'#weight' => 1,
		);
		$settings_form['tabs']['Security'] = array(
			'#title'  => __( 'Security', 'directories-pro' ),
			'#weight' => 75,
		);
		$settings_form['tabs']['System']   = array(
			'#title'  => __( 'System', 'directories-pro' ),
			'#weight' => 99,
		);
		foreach ( $settings_form['tabs'] as $tab_name => $tab ) {
			$form['#tabs'][ $tab_name ] = $tab;
			$form[ $tab_name ]          = array(
				'#tree' => false,
				'#tab'  => $tab_name,
			);
		}
		foreach ( array_keys( $settings_form['fields'] ) as $key ) {
			if ( ! isset( $settings_form['fields'][ $key ]['#tab'] ) ) {
				continue;
			}

			$tab = $settings_form['fields'][ $key ]['#tab'];
			if ( ! isset( $form[ $tab ] ) ) {
				continue;
			}

			unset( $settings_form['fields'][ $key ]['#tab'] );
			$form[ $tab ][ $key ] = $settings_form['fields'][ $key ];
			if ( ! isset( $form[ $tab ][ $key ]['#tree'] ) ) {
				$form[ $tab ][ $key ]['#tree'] = true;
			}
		}

		// Drop tabs no component populated - e.g. "Security" when neither a
		// captcha nor report moderation is in play on this install.
		foreach ( array_keys( $form['#tabs'] ) as $tab_name ) {
			foreach ( array_keys( $form[ $tab_name ] ) as $k ) {
				if ( strpos( $k, '#' ) !== 0 ) {
					continue 2; // has a real field -> keep
				}
			}
			unset( $form['#tabs'][ $tab_name ], $form[ $tab_name ] );
		}

		return $form;
	}

	protected function _getComponentConfigFormSettings( Form\Form $form ) {
		$settings = array();
		foreach ( array_keys( $form->settings ) as $tab_name ) {
			if ( strpos( $tab_name, '#' ) === 0 ) {
				continue;
			}

			foreach ( array_keys( $form->settings[ $tab_name ] ) as $key ) {
				if ( ! empty( $form->settings[ $tab_name ][ $key ]['#component'] ) ) {
					$settings[ $key ] = $form->settings[ $tab_name ][ $key ];
				}
			}
		}
		return $settings;
	}

	protected function _getComponentConfigs( Context $context, array $config, Form\Form $form, array &$overwriteConfigs = array() ) {
		$component_configs = parent::_getComponentConfigs( $context, $config, $form, $overwriteConfigs );
		$this->getPlatform()->setCache( $component_configs, 'system_settings_component_configs' );
		return $component_configs;
	}
}
