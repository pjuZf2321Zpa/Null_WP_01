<?php
namespace SabaiApps\Directories\Component\System\Controller\Admin;

use SabaiApps\Directories\Component\Form;
use SabaiApps\Directories\Context;

/**
 * Generic "create a native content page" modal form - admin-editable
 * title/slug/content fields, all pre-fillable by a subclass. Delegates the
 * actual page creation to Platform::createPage() rather than calling
 * WordPress functions directly - this component isn't WordPress-specific.
 * An empty slug lets the platform auto-generate one from the title; a
 * non-empty slug reuses (and republishes) an existing page at that exact
 * path instead of creating a duplicate - see Platform::createPage().
 *
 * Since this runs inside a modal, success doesn't navigate anywhere -
 * _ajaxOnSuccess just closes the modal (same as _ajaxOnSuccessEdit/
 * _ajaxOnSuccessDelete elsewhere in this class) and flashes a message with
 * a link to the new page's editor (see submitForm()). Subclass and
 * override _getDefaultTitle()/_getDefaultSlug()/_getDefaultContent() to
 * pre-fill for a specific use case - see View\Controller\Admin\
 * CreateViewPage.
 */
class CreatePage extends Form\Controller {

	protected function _doGetFormSettings( Context $context, array &$storage ) {
		$this->_ajaxSubmit             = true;
		$this->_ajaxOnSuccessRedirect  = $this->_ajaxOnErrorRedirect = false;
		$this->_ajaxModalHideOnSuccess = true;
		$this->_submitButtons[]        = array(
			'#btn_label' => __( 'Create Page', 'directories-pro' ),
			'#btn_color' => 'success',
			'#btn_size'  => 'lg',
		);

		return array(
			'title'   => array(
				'#type'          => 'textfield',
				'#title'         => __( 'Page Title', 'directories-pro' ),
				'#default_value' => $this->_getDefaultTitle( $context ),
				'#max_length'    => 255,
				'#required'      => true,
				'#horizontal'    => true,
			),
			'slug'    => array(
				'#type'          => 'textfield',
				'#title'         => __( 'Page Path', 'directories-pro' ),
				'#description'   => __( 'Optional. Leave blank to auto-generate one.', 'directories-pro' ),
				'#default_value' => $this->_getDefaultSlug( $context ),
				'#max_length'    => 200,
				'#horizontal'    => true,
			),
			'content' => array(
				'#type'          => 'textarea',
				'#title'         => __( 'Page Content', 'directories-pro' ),
				'#default_value' => $this->_getDefaultContent( $context ),
				'#rows'          => 6,
				'#horizontal'    => true,
			),
		);
	}

	public function submitForm( Form\Form $form, Context $context ) {
		// $reuse false - a page already existing at the given path should
		// fail here, not silently reuse/republish it.
		if ( ! $page_id = $this->getPlatform()->createPage( $form->values['slug'], $form->values['title'], false, $form->values['content'], false, false ) ) {
			$context->setError(
				strlen( $form->values['slug'] )
				? 'Unable to create page - a page may already exist at that path.'
				: 'Unable to create page.'
			);
			return;
		}

		// The page's own front-end URL, not its wp-admin edit URL - it's
		// published by default (see createPage()'s $draft param above),
		// so there's actually something to visit.
		$page_url = $this->getPlatform()->getPageUrl( $page_id );
		// Passing '' (not null) for the success URL is deliberate - it's
		// what makes Response::_sendSuccess() include flash messages in
		// the AJAX JSON response at all (it drops them whenever there's a
		// non-empty success URL, on the assumption a redirect is about to
		// show them on the next page load instead). page_id/page_title
		// are extra attributes a subclass's own _ajaxOnSuccess can act on -
		// see CreateSlugPage, which uses them to select the new page in
		// Page Settings' own page dropdown.
		$context->setSuccess(
			'',
			array(
				'page_id'    => $page_id,
				'page_title' => $form->values['title'],
			)
		)->addFlash(
			sprintf(
				/* translators: %s: page url */
				__( 'Page created successfully. %s', 'directories-pro' ),
				'<a href="' . $this->H( $page_url ) . '" target="_blank">' . $this->H( $page_url ) . '</a>'
			),
			'success',
			15000
		);
	}

	protected function _getDefaultTitle( Context $context ) {
		return '';
	}

	protected function _getDefaultSlug( Context $context ) {
		return '';
	}

	protected function _getDefaultContent( Context $context ) {
		return '';
	}
}
