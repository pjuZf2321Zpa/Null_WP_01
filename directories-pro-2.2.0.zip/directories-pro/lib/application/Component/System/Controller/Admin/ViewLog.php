<?php
namespace SabaiApps\Directories\Component\System\Controller\Admin;

use SabaiApps\Directories\Controller;
use SabaiApps\Directories\Context;

/**
 * ViewLog controller for displaying log file contents via AJAX.
 */
class ViewLog extends Controller {

	/**
	 * Executes the controller logic to output the log file content.
	 *
	 * @param Context $context
	 */
	protected function _doExecute( Context $context ) {
		// Must be an Ajax request
		if ( ! $log = $context->getRequest()->asStr( 'log' ) ) {
			$context->setBadRequestError();
			return;
		}

		// Check if valid log
		$logs = $this->Filter( 'system_admin_system_logs', array() );
		if ( ! isset( $logs[ $log ] )
			|| empty( $logs[ $log ]['file'] )
			|| ! file_exists( $logs[ $log ]['file'] )
		) {
			return;
		}
		$file = $logs[ $log ]['file'];

		$max_size = 10 * 1024 * 1024; // 10MB
		if ( filesize( $file ) > $max_size ) {
			echo $this->_application->H( __( 'The log file is too large to display. Please run the "Clear log files" tool to clear the log and try again.', 'directories-pro' ) );
			exit;
		}

		header( 'Content-type: text/plain' );
		$this->getPlatform()->readFile( $file );
		exit;
	}
}
