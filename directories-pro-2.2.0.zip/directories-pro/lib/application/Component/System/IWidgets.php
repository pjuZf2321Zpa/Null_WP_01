<?php
namespace SabaiApps\Directories\Component\System;

/**
 * IWidgets interface for components that provide widgets.
 */
interface IWidgets {

	/**
	 * Returns an array of available widget names.
	 *
	 * @return array
	 */
	public function systemGetWidgetNames();

	/**
	 * Returns the widget object or configuration for the given widget name.
	 *
	 * @param string $widgetName
	 * @return mixed
	 */
	public function systemGetWidget( $widgetName );
}
