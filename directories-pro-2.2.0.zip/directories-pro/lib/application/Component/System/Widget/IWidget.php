<?php
namespace SabaiApps\Directories\Component\System\Widget;

/**
 * IWidget interface for all system widgets.
 * Defines required methods for widget info, settings, content, and settings save event.
 */
interface IWidget {

	/**
	 * Returns widget information as an array.
	 */
	public function systemWidgetInfo();

	/**
	 * Returns the settings form array for the widget.
	 *
	 * @param array $settings
	 * @return array
	 */
	public function systemWidgetSettings( array $settings );

	/**
	 * Returns the content array for the widget.
	 *
	 * @param array $settings
	 * @return array
	 */
	public function systemWidgetContent( array $settings );

	/**
	 * Called when widget settings are saved.
	 *
	 * @param array $settings
	 * @param array $oldSettings
	 */
	public function systemWidgetOnSettingsSaved( array $settings, array $oldSettings );
}
