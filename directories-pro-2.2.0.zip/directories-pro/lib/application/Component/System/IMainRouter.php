<?php
namespace SabaiApps\Directories\Component\System;

use SabaiApps\Directories\Context;

/**
 * IMainRouter interface for components that provide main (front-end) routes.
 */
interface IMainRouter {

	/**
	 * Returns an array of main routes, optionally for a specific language.
	 *
	 * @param string|null $lang
	 * @return array
	 */
	public function systemMainRoutes( $lang = null );

	/**
	 * Handles access control for a main route.
	 *
	 * @param Context $context
	 * @param string  $path
	 * @param string  $accessType
	 * @param array   $route
	 * @return mixed
	 */
	public function systemOnAccessMainRoute( Context $context, $path, $accessType, array &$route );

	/**
	 * Returns the title for a main route.
	 *
	 * @param Context $context
	 * @param string  $path
	 * @param string  $titleType
	 * @param array   $route
	 * @return string
	 */
	public function systemMainRouteTitle( Context $context, $path, $titleType, array $route );
}
