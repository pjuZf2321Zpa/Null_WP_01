<?php
namespace SabaiApps\Directories\Component\System;

use SabaiApps\Directories\Context;

/**
 * IAdminRouter interface for components that provide admin routes.
 */
interface IAdminRouter {

	/**
	 * Returns an array of admin routes.
	 *
	 * @return array
	 */
	public function systemAdminRoutes();

	/**
	 * Handles access control for an admin route.
	 *
	 * @param Context $context
	 * @param string  $path
	 * @param string  $accessType
	 * @param array   $route
	 * @return mixed
	 */
	public function systemOnAccessAdminRoute( Context $context, $path, $accessType, array &$route );

	/**
	 * Returns the title for an admin route.
	 *
	 * @param Context $context
	 * @param string  $path
	 * @param string  $title
	 * @param array   $route
	 * @return string
	 */
	public function systemAdminRouteTitle( Context $context, $path, $title, array $route );
}
