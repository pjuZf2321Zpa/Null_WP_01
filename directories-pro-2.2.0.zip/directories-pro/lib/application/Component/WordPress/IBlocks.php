<?php
namespace SabaiApps\Directories\Component\WordPress;

/**
 * IBlocks interface for components that provide WordPress blocks.
 */
interface IBlocks {

	/**
	 * Returns an array of available block names.
	 *
	 * @return array
	 */
	public function wordpressGetBlockNames();

	/**
	 * Returns the block object for a given block name.
	 *
	 * @param string $name
	 * @return mixed
	 */
	public function wordpressGetBlock( $name );
}
