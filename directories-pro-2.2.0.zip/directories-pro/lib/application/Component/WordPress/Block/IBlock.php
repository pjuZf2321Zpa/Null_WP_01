<?php
namespace SabaiApps\Directories\Component\WordPress\Block;

/**
 * IBlock interface for all WordPress blocks.
 * Defines required methods for block info, editor variables, rendering, and placeholders.
 */
interface IBlock {
	/**
	 * Returns block information as an array.
	 */
	public function wordpressBlockInfo();

	/**
	 * Returns variables for the block editor.
	 */
	public function wordpressBlockEditorVars();

	/**
	 * Called when block editor assets are enqueued.
	 *
	 * @param string $editorScriptHandle
	 */
	public function wordpressBlockOnEnqueueEditorAssets( $editorScriptHandle );

	/**
	 * Renders the block content.
	 *
	 * @param array       $attributes
	 * @param string|null $content
	 * @param bool        $isBlockEditorRequest
	 * @return string
	 */
	public function wordpressBlockRender( array $attributes, $content, $isBlockEditorRequest );

	/**
	 * Returns the placeholder HTML for the block.
	 *
	 * @param array       $attributes
	 * @param string|null $content
	 * @return string
	 */
	public function wordpressBlockPlaceholder( array $attributes, $content );
}
