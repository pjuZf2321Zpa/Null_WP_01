<?php
namespace SabaiApps\Directories\Component\WordPress\Tool;

use SabaiApps\Directories\Component\System\Tool\AbstractTool;
use SabaiApps\Directories\Component\WordPress\Updater;
use SabaiApps\Directories\Context;

/**
 * RecheckLicenseTool clears the cached license validation result for every
 * package that currently requires a key and re-attempts validation with
 * directoriespro.com. The updater's own cooldown between remote attempts
 * still applies, so this tool cannot be used to flood the remote API.
 */
class RecheckLicenseTool extends AbstractTool {

	protected function _systemToolInfo() {
		return array(
			'label'       => __( 'Recheck license', 'directories-pro' ),
			'description' => __( 'This tool will clear the cached license validation result and re-attempt validation.', 'directories-pro' ),
			'weight'      => 10,
			'hidden'      => true,
		);
	}

	public function systemToolSettingsForm( $step, array $values, array $parents = array(), ?Context $context = null ) {
		$packages  = Updater::getInstance( $this->_application )->getKeyRequiredPackages();
		$requested = isset( $context ) ? $context->getRequest()->asStr( 'package' ) : null;
		$default   = isset( $packages[ $requested ] ) ? $requested : key( $packages );
		if ( count( $packages ) === 1 ) {
			$form = array(
				'package' => array(
					'#type'          => 'hidden',
					'#default_value' => $default,
				),
			);
		} else {
			$form = array(
				'package' => array(
					'#type'          => 'select',
					'#title'         => __( 'License to check', 'directories-pro' ),
					'#options'       => $packages,
					'#default_value' => $default,
					'#horizontal'    => true,
				),
			);
		}
		if ( $this->_application->getPlatform()->isDebugEnabled() ) {
			$form['force'] = array(
				'#type'          => 'checkbox',
				'#title'         => __( 'Force a new request', 'directories-pro' ),
				'#description'   => __( 'For debugging only - avoid running repeatedly.', 'directories-pro' ),
				'#default_value' => false,
				'#horizontal'    => true,
			);
		}

		return $form;
	}

	public function systemToolRunTask( $task, array $settings, $iteration, $total, array &$storage, array &$logs, ?Context $context = null ) {
		$updater  = Updater::getInstance( $this->_application );
		$packages = $updater->getKeyRequiredPackages();
		if ( empty( $settings['package'] )
			|| ! isset( $packages[ $settings['package'] ] )
		) {
			$logs['error'][] = __( 'No license key is currently required.', 'directories-pro' );
			return 1;
		}

		$force   = ! empty( $settings['force'] ) && $this->_application->getPlatform()->isDebugEnabled();
		$package = $settings['package'];
		if ( ! $force
			&& ( $wait = $updater->getRetryWait( $package ) )
		) {
			$logs['warning'][] = sprintf(
				__( '%1$s: The license key was checked recently, so no new request was sent. Please try again in %2$d minute(s).', 'directories-pro' ),
				$packages[ $package ],
				ceil( $wait / 60 )
			);
			return 1;
		}
		if ( $updater->recheck( $package, $force ) ) {
			$logs['success'][] = sprintf( __( '%s: license key validated successfully.', 'directories-pro' ), $packages[ $package ] );
		} elseif ( $error = $updater->getLastError( $package ) ) {
			$logs['error'][] = sprintf( '%s: %s', $packages[ $package ], $error );
		} else {
			$logs['error'][] = sprintf( __( '%s: license key validation failed.', 'directories-pro' ), $packages[ $package ] );
		}

		return 1;
	}
}
