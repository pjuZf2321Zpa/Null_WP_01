<?php
namespace SabaiApps\Directories\Component;

/**
 * Model class for component-specific data access.
 * Extends the framework Model and provides helper access and entity fetching.
 */
class Model extends \SabaiApps\Framework\Model\Model {

	/**
	 * @var SabaiApps\Directories\Application
	 */
	private $_application;

	/**
	 * Constructor.
	 *
	 * @param AbstractComponent $component
	 */
	public function __construct( AbstractComponent $component ) {
		parent::__construct(
			$component->getApplication()->getDB(),
			$component->getApplication()->getComponentPath( $component->getName() ) . '/Model',
			'\SabaiApps\Directories\Component\\' . $component->getName() . '\Model\\'
		);
		$this->_application = $component->getApplication();
	}

	/**
	 * Magic method to call helpers via the application.
	 *
	 * @param string $name
	 * @param array  $args
	 * @return mixed
	 */
	public function __call( $name, $args ) {
		return $this->_application->callHelper( $name, $args );
	}

	/**
	 * Fetches a single entity from another component by entity ID.
	 *
	 * @param string $component
	 * @param string $entity
	 * @param int    $entityId
	 * @return mixed
	 */
	public function getComponentEntity( $component, $entity, $entityId ) {
		return $this->_application->getModel( $entity, $component )->fetchById( $entityId );
	}

	/**
	 * Fetches multiple entities from another component by entity IDs.
	 *
	 * @param string $component
	 * @param string $entity
	 * @param array  $entityIds
	 * @return mixed
	 */
	public function getComponentEntities( $component, $entity, array $entityIds ) {
		return $this->_application->getModel( $entity, $component )->fetchByIds( $entityIds );
	}
}
