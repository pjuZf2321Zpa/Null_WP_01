<?php
namespace SabaiApps\Directories\Component\Form\Field;

use SabaiApps\Directories\Component\Form\Form;

/**
 * LengthsField provides a group of number inputs for specifying top, right, bottom, and left values.
 * Supports optional suffix and validation for numeric input.
 */
class LengthsField extends ItemField {

	/**
	 * Renders the Lengths field as a row of number inputs for each direction.
	 *
	 * @param array $data
	 * @param Form  $form
	 */
	public function formFieldRender( array &$data, Form $form ) {
		$markup = array( '<div class="' . DRTS_BS_PREFIX . 'row" style="margin-left:0; margin-right:-10px">' );
		foreach ( array(
			'top'    => __( 'Top', 'directories-pro' ),
			'right'  => __( 'Right', 'directories-pro' ),
			'bottom' => __( 'Bottom', 'directories-pro' ),
			'left'   => __( 'Left', 'directories-pro' ),
		) as $key => $label ) {
			$markup[] = sprintf(
				'<div class="%1$scol-sm-3" style="padding-left:0; padding-right:10px">
    %2$s<input class="%1$sform-control" name="%3$s[%4$s]" type="number" placeholder="%5$s" value="%6$s" />%7$s
</div>',
				DRTS_BS_PREFIX,
				isset( $data['#length_suffix'] ) ? '<div class="' . DRTS_BS_PREFIX . 'input-group">' : '',
				$this->_application->H( $data['#name'] ),
				$key,
				$this->_application->H( $label ),
				isset( $data['#default_value'][ $key ] ) && strlen( $data['#default_value'][ $key ] ) ? $this->_application->H( $data['#default_value'][ $key ] ) : null,
				isset( $data['#length_suffix'] ) ? '<span class="' . DRTS_BS_PREFIX . 'input-group-text">' . $data['#length_suffix'] . '</span></div>' : ''
			);
		}
		$markup[] = '</div>';

		$data['#markup'] = implode( PHP_EOL, $markup );

		return parent::formFieldRender( $data, $form );
	}

	/**
	 * Handles value processing and validation for the Lengths field on submit.
	 *
	 * @param mixed $value
	 * @param array $data
	 * @param Form  $form
	 */
	public function formFieldSubmit( &$value, array &$data, Form $form ) {
		foreach ( array( 'top', 'right', 'bottom', 'left' ) as $key ) {
			if ( isset( $value[ $key ] ) && strlen( $value[ $key ] ) ) {
				if ( ! is_numeric( $value[ $key ] ) ) {
					$form->setError(
						/* translators: %s: field label */
						sprintf( __( 'Invalid value: %s', 'directories-pro' ), $value[ $key ] ),
						$data
					);
					break;
				}
			}
		}
	}
}
