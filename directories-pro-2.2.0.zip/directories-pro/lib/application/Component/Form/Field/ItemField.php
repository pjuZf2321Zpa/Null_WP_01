<?php
namespace SabaiApps\Directories\Component\Form\Field;

use SabaiApps\Directories\Component\Form\Form;

/**
 * ItemField provides a simple field for displaying static or dynamic content.
 * Supports optional prefix and suffix markup, and horizontal layout.
 */
class ItemField extends AbstractField {

	/**
	 * Renders the Item field with optional prefix and suffix.
	 *
	 * @param array $data
	 * @param Form  $form
	 */
	public function formFieldRender( array &$data, Form $form ) {
		if ( ! isset( $data['#markup'] ) ) {
			$data['#markup'] = isset( $data['#default_value'] ) ? $this->_application->H( $data['#default_value'] ) : '';
		}
		$html = array();
		if ( isset( $data['#field_prefix'] ) ) {
			$html[] = $this->_application->H( $data['#field_prefix'] );
		}
		$html[] = $data['#markup'];
		if ( isset( $data['#field_suffix'] ) ) {
			$html[] = $this->_application->H( $data['#field_suffix'] );
		}
		$html = implode( PHP_EOL, $html );
		if ( ! empty( $data['#horizontal'] ) ) {
			// Add margin for horizontal layout
			$html = '<div class="' . DRTS_BS_PREFIX . 'mt-2">' . $html . '</div>';
		}
		$this->_render( $html, $data, $form );
	}
}
