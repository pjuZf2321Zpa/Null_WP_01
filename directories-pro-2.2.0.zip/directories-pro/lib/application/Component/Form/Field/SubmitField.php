<?php
namespace SabaiApps\Directories\Component\Form\Field;

use SabaiApps\Directories\Component\Form\Form;
use SabaiApps\Directories\Exception;

/**
 * SubmitField provides a submit button for forms.
 * Supports custom label, color, size, and block display.
 */
class SubmitField extends AbstractField {

	/**
	 * Initializes the Submit field with default label, value, and button classes.
	 *
	 * @param string $name
	 * @param array  $data
	 * @param Form   $form
	 */
	public function formFieldInit( $name, array &$data, Form $form ) {
		if ( ! isset( $data['#value'] ) ) {
			if ( ! isset( $data['#default_value'] ) ) {
				$data['#value'] = 'submit';
			}
		}
		if ( ! isset( $data['#btn_label'] ) ) {
			$data['#btn_label']           = __( 'Submit', 'directories-pro' );
			$data['#btn_label_no_escape'] = false;
		}
		$button_class = DRTS_BS_PREFIX . 'btn ' . DRTS_BS_PREFIX . 'btn-' . ( isset( $data['#btn_color'] ) ? $data['#btn_color'] : 'secondary' );
		if ( isset( $data['#btn_size'] )
			&& in_array( $data['#btn_size'], array( 'sm', 'lg' ) )
		) {
			$button_class .= ' ' . DRTS_BS_PREFIX . 'btn-' . $data['#btn_size'];
		}
		if ( ! empty( $data['#disabled'] ) ) {
			$button_class .= ' ' . DRTS_BS_PREFIX . 'disabled';
		}
		if ( isset( $data['#attributes']['class'] ) ) {
			$data['#attributes']['class'] .= ' ' . $button_class;
		} else {
			$data['#attributes']['class'] = $button_class;
		}
		$data['#attributes']['class'] .= ' ' . DRTS_BS_PREFIX . 'text-nowrap';
	}

	/**
	 * Handles submit logic, validation, and submit handlers for the Submit field.
	 *
	 * @param mixed $value
	 * @param array $data
	 * @param Form  $form
	 */
	public function formFieldSubmit( &$value, array &$data, Form $form ) {
		if ( ! isset( $value )
			|| ! $form->isClickedButton( $data )
		) {
			return; // the button was not clicked
		}

		// Move validate/submit handlers for this button to the global scope
		if ( ! empty( $data['#validate'] ) ) {
			foreach ( $data['#validate'] as $callback ) {
				$form->settings['#validate'][] = $callback;
			}
		}
		if ( ! empty( $data['#submit'] ) ) {
			foreach ( $data['#submit'] as $weight => $submits ) {
				foreach ( $submits as $callback ) {
					$form->settings['#submit'][ $weight ][] = $callback;
				}
			}
		}

		if ( ! empty( $data['#skip_validate'] ) ) {
			$form->settings['#skip_validate'] = true;
		}
	}

	/**
	 * Renders the Submit field as a button with optional prefix/suffix and block display.
	 *
	 * @param array $data
	 * @param Form  $form
	 */
	public function formFieldRender( array &$data, Form $form ) {
		$data['#html'][] = sprintf(
			'%s%s<button type="%s" name="%s" value="%s"%s>%s</button>%s%s',
			isset( $data['#field_prefix'] ) ? $data['#field_prefix'] : '',
			empty( $data['#btn_block'] ) ? '' : '<div class="' . DRTS_BS_PREFIX . 'd-grid">',
			isset( $data['#btn_type'] ) && in_array( $data['#btn_type'], array( 'button', 'reset' ) ) ? $data['#btn_type'] : 'submit',
			$this->_application->H( $data['#name'] ),
			$this->_application->H( $data['#default_value'] ),
			$this->_application->Attr( $data['#attributes'] ),
			empty( $data['#btn_label_no_escape'] ) ? $this->_application->H( $data['#btn_label'] ) : $data['#btn_label'],
			empty( $data['#btn_block'] ) ? '' : '</div>',
			isset( $data['#field_suffix'] ) ? $data['#field_suffix'] : ''
		);
	}
}
