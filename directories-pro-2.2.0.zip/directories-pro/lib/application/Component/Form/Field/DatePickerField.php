<?php
namespace SabaiApps\Directories\Component\Form\Field;

use SabaiApps\Directories\Component\Form\Form;

/**
 * DatePickerField provides a date (and optionally time) picker field.
 * Handles initialization, default value logic, and value validation/formatting.
 */
class DatePickerField extends AbstractDatePickerField {

	/**
	 * Initializes the DatePicker field with default values and settings.
	 *
	 * @param string $name
	 * @param array  $data
	 * @param Form   $form
	 */
	public function formFieldInit( $name, array &$data, Form $form ) {
		$data['#disable_time'] = isset( $data['#disable_time'] ) ? $data['#disable_time'] : false;
		if ( ! isset( $data['#default_value'] ) ) {
			if ( ! empty( $data['#current_date_selected'] ) ) {
				$data['#default_value'] = time();
			}
		}
		parent::formFieldInit( $name, $data, $form );
	}

	/**
	 * Handles value processing and validation for the DatePicker field on submit.
	 *
	 * @param mixed $value
	 * @param array $data
	 * @param Form  $form
	 */
	public function formFieldSubmit( &$value, array &$data, Form $form ) {
		if ( ! isset( $value )
			|| ! strlen( $value = trim( $value ) ) ) {
			$value = null;
			return;
		}

		if ( ! empty( $data['#multiple'] ) ) {
			$value = array_filter( array_map( 'trim', explode( ',', $value ) ) );
			foreach ( array_keys( $value ) as $i ) {
				if ( false === $validated = $this->_checkDateValue( $value[ $i ], $data, $form ) ) {
					unset( $value[ $i ] );
					continue;
				}
				$value[ $i ] = $validated;
			}
			$value = array_values( $value );
			return;
		}

		if ( false !== $validated = $this->_checkDateValue( $value, $data, $form ) ) {
			$value = $validated;
			return;
		}
		$value = null;
	}

	protected function _checkDateValue( $value, array $data, Form $form ) {
		$format = 'Y-m-d';
		if ( empty( $data['#disable_time'] ) ) {
			if ( empty( $data['#time_12hr'] ) ) {
				$format .= ' H:i';
			} else {
				$format .= ' h:i A';
			}
		} else {
			$format .= ' H:i:s';
			$value  .= ' 00:00:00';
		}
		return $this->_application->Form_Validate_date( $value, $data, $form, $format );
	}

	/**
	 * Returns the configuration options for the calendar widget.
	 *
	 * @param array $data
	 * @return array
	 */
	protected function _getCalendarOptions( array $data ) {
		$options = parent::_getCalendarOptions( $data );
		if ( ! empty( $data['#multiple'] ) ) {
			$options['settings']['selection']['day'] = 'multiple';
		}
		if ( ! empty( $data['#default_value'] ) ) {
			if ( ! is_array( $data['#default_value'] ) ) {
				$data['#default_value'] = array( $data['#default_value'] );
			}
			foreach ( $data['#default_value'] as $i => $v ) {
				$value = is_string( $v ) ? $this->_application->System_Date_strToTime( $v ) : $v;
				if ( is_int( $value )
					&& $value > 0
					&& $value !== $data['#empty_value']
				) {
					$options['settings']['selected']['dates'][] = $this->_application->getPlatform()->getDate( 'Y-m-d', $value );
					// VanillaCalendar only ever tracks one displayed/edited
					// time regardless of how many dates are selected (its
					// own internal selectedTime/selectedHours/selectedMinutes
					// state is singular, not per-date), and its own parsing
					// of settings.selected.time only runs when it's a plain
					// string (`typeof === "string"`) - not the array 'dates'
					// is. So only ever set it once, from the first date.
					if ( ! isset( $options['settings']['selected']['time'] ) ) {
						$options['settings']['selected']['time'] = empty( $data['#time_12hr'] )
							? $this->_application->getPlatform()->getDate( 'H:i', $value )
							: $this->_application->getPlatform()->getDate( 'h:i A', $value );
					}
				}
			}
			if ( ! empty( $options['settings']['selected']['dates'] ) ) {
				$first_date_parts                         = explode( '-', $options['settings']['selected']['dates'][0] );
				$options['settings']['selected']['year']  = $first_date_parts[0];
				$options['settings']['selected']['month'] = $first_date_parts[1] - 1;
			}
		}
		return $options;
	}
}
