<?php
namespace SabaiApps\Directories\Component\Form\Field;

use SabaiApps\Directories\Component\Form\Form;

/**
 * CheckboxesField provides a group of checkboxes for multiple selections.
 * Handles validation for maximum allowed selections.
 */
class CheckboxesField extends RadiosField {

	protected $_type = 'checkbox';

	/**
	 * Handles value processing and validation for the Checkboxes field on submit.
	 *
	 * @param mixed $value
	 * @param array $data
	 * @param Form  $form
	 */
	public function formFieldSubmit( &$value, array &$data, Form $form ) {
		parent::formFieldSubmit( $value, $data, $form );

		if ( ! empty( $data['#max_selection'] ) && count( $value ) > $data['#max_selection'] ) {
			/* translators: %d: max selection */
			$form->setError( sprintf( __( 'Maximum of %d selections allowed.', 'directories-pro' ), $data['#max_selection'] ), $data );
		}
	}
}
