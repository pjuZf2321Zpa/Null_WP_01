<?php
namespace SabaiApps\Directories\Component\Form\Field;

use SabaiApps\Directories\Component\Form\Form;

/**
 * AutocompleteField provides a select field with AJAX-powered autocomplete functionality.
 * Integrates with Select2 for enhanced user experience.
 */
class AutocompleteField extends SelectField {

	/**
	 * Initializes the Autocomplete field with Select2 AJAX options if provided.
	 *
	 * @param string $name
	 * @param array  $data
	 * @param Form   $form
	 * @return mixed
	 */
	public function formFieldInit( $name, array &$data, Form $form ) {
		// Enable Select2 AJAX if an AJAX URL is set
		if ( isset( $data['#select2_ajax_url'] ) ) {
			$data += array(
				'#select2'      => true,
				'#select2_ajax' => true,
			);
		} else {
			$data['#select2'] = false;
		}

		return parent::formFieldInit( $name, $data, $form );
	}
}
