<?php
namespace SabaiApps\Directories\Component\Form\Field;

use SabaiApps\Directories\Component\Form\Form;

/**
 * HiddenField provides a hidden input field.
 * Supports multiple values and inline or bottom-of-form rendering.
 */
class HiddenField extends AbstractField {

	/**
	 * Renders the Hidden field as one or more hidden input elements.
	 *
	 * @param array $data
	 * @param Form  $form
	 */
	public function formFieldRender( array &$data, Form $form ) {
		if ( isset( $data['#attributes']['class'] ) ) {
			$data['#attributes']['class'] .= ' ' . $data['#class'];
		} else {
			$data['#attributes']['class'] = $data['#class'];
		}

		$name = $this->_application->H( $data['#name'] );
		if ( ! empty( $data['#multiple'] ) ) {
			$name .= '[]';
		}
		$html = array();
		if ( isset( $data['#default_value'] ) ) {
			$values = (array) $data['#default_value'];
			foreach ( $values as $value ) {
				$is_first = ! isset( $is_first );
				$html[]   = $this->_getHtml( $data, $name, $is_first && isset( $data['#id'] ) ? $data['#id'] : null, $value );
			}
		} else {
			$html[] = $this->_getHtml( $data, $name, isset( $data['#id'] ) ? $data['#id'] : null );
		}
		$html = implode( PHP_EOL, $html );
		if ( ! empty( $data['#render_hidden_inline'] ) ) {
			// Render hidden field inline with other fields
			$data['#html'][] = $html;
		} else {
			// Moves to bottom of the form
			$form->settings['#rendered_hiddens'][] = $html;
		}
	}

	/**
	 * Returns the HTML for a hidden input element.
	 *
	 * @param array       $data
	 * @param string      $name
	 * @param string|null $id
	 * @param string|null $value
	 * @return string
	 */
	protected function _getHtml( array $data, $name, $id = null, $value = null ) {
		$data_attr = null;
		if ( ! empty( $data['#data'] ) ) {
			if ( isset( $data['#data'][ $value ] ) ) {
				$data_attr = $data['#data'][ $value ];
			} else {
				$data_attr = $data['#data'];
			}
		}
		return sprintf(
			'<input type="hidden" name="%s" value="%s"%s%s%s>',
			$name,
			isset( $value ) ? $this->_application->H( $value ) : '',
			empty( $id ) ? '' : ' id="' . $this->_application->H( $id ) . '"',
			empty( $data['#attributes'] ) ? '' : $this->_application->Attr( $data['#attributes'] ),
			empty( $data_attr ) ? '' : $this->_application->Attr( $data_attr, null, 'data-' )
		);
	}
}
