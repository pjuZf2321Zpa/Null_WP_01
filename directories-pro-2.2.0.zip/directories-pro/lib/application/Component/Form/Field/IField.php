<?php
namespace SabaiApps\Directories\Component\Form\Field;

use SabaiApps\Directories\Component\Form\Form;

/**
 * IField defines the interface for all form field types.
 * Requires methods for initialization, submission, cleanup, and rendering.
 */
interface IField {

	/**
	 * Initializes the field with settings and default values.
	 *
	 * @param string $name
	 * @param array  $data
	 * @param Form   $form
	 */
	public function formFieldInit( $name, array &$data, Form $form );

	/**
	 * Determines if the field should be submitted based on the clicked button.
	 *
	 * @param array $data
	 * @param Form  $form
	 * @return bool
	 */
	public function formFieldIsSubmittable( array $data, Form $form );

	/**
	 * Handles field value processing and validation on form submit.
	 *
	 * @param mixed $value
	 * @param array $data
	 * @param Form  $form
	 */
	public function formFieldSubmit( &$value, array &$data, Form $form );

	/**
	 * Cleans up field state after form submission.
	 *
	 * @param array $data
	 * @param Form  $form
	 */
	public function formFieldCleanup( array &$data, Form $form );

	/**
	 * Renders the field as HTML.
	 *
	 * @param array $data
	 * @param Form  $form
	 */
	public function formFieldRender( array &$data, Form $form );
}
