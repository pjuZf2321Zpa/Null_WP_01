<?php
namespace SabaiApps\Directories\Component\Form\Helper;

use SabaiApps\Directories\Application;

class ScriptsHelper {

	/**
	 * Loads required JavaScript and CSS files for form fields based on options.
	 *
	 * @param Application $application
	 * @param array       $options
	 */
	public function help( Application $application, array $options = array() ) {
		$platform = $application->getPlatform();
		$platform->addJsFile( 'form.min.js', 'drts-form', array( 'drts' ) );
		if ( empty( $options ) || in_array( 'file', $options ) ) {
			$platform->loadJqueryUiJs( array( 'widget' ) )
				->addJsFile( 'jquery.iframe-transport.min.js', 'jquery-iframe-transform', 'jquery', null, true, true )
				->addJsFile( 'jquery.fileupload.min.js', 'jquery-fileupload', 'jquery-ui-widget', null, true, true )
				->addJsFile( 'form-field-file.min.js', 'drts-form-field-file', array( 'jquery-fileupload', 'drts-form' ) );
		}
		if ( empty( $options ) || in_array( 'slider', $options ) || in_array( 'range', $options ) ) {
			$platform->addJsFile( 'ion.rangeSlider.min.js', 'ion-range-slider', array( 'jquery' ), null, true, true )
				->addJsFile( 'form-field-slider.min.js', 'drts-form-field-slider', array( 'drts-form', 'ion-range-slider' ) )
				->addCssFile( 'ion.rangeSlider.min.css', 'ion-range-slider', null, null, null, true );
		}
		if ( empty( $options ) || in_array( 'tableselect', $options ) || in_array( 'options', $options ) ) {
			$platform->loadJqueryUiJs( array( 'sortable' ) );
		}
		if ( empty( $options ) || in_array( 'text_maskedinput', $options ) ) {
			$platform->addJsFile( 'jquery.maskedinput.min.js', 'jquery-maskedinput', array( 'jquery' ), null, true, true );
		}
		if ( empty( $options ) || in_array( 'latinise', $options ) ) {
			$platform->addJsFile( 'form-latinise.min.js', 'latinise' );
		}
		if ( empty( $options ) || in_array( 'select', $options ) || in_array( 'autocomplete', $options ) || in_array( 'user', $options ) ) {
			$this->select2( $application );
			$platform->addJsFile( 'form-field-select.min.js', 'drts-form-field-select', array( 'drts-form' ) );
		}
		if ( empty( $options ) || in_array( 'iconpicker', $options ) ) {
			$this->iconpicker( $application );
		}
		if ( empty( $options ) || in_array( 'colorpicker', $options ) ) {
			$this->colorpicker( $application );
		}
		if ( empty( $options ) || in_array( 'options', $options ) ) {
			$platform->addJsFile( 'form-field-options.min.js', 'drts-form-field-options', array( 'drts-form' ) );
		}
		if ( empty( $options ) || in_array( 'selecthierarchical', $options ) ) {
			$platform->addJsFile( 'form-field-selecthierarchical.min.js', 'drts-form-field-selecthierarchical', array( 'drts-form' ) );
		}
		if ( empty( $options ) || in_array( 'datepicker', $options ) || in_array( 'daterange', $options ) ) {
			$this->date( $application );
		}
		if ( empty( $options ) || in_array( 'timepicker', $options ) ) {
			$this->time( $application );
		}
		if ( empty( $options ) || in_array( 'addmore', $options ) ) {
			$platform->addJsFile( 'form-field-addmore.min.js', 'drts-form-field-addmore', array( 'drts-form' ) );
		}
		if ( empty( $options ) || in_array( 'upload', $options ) ) {
			$this->file( $application );
		}
		if ( empty( $options ) || in_array( 'editor', $options ) ) {
			// Load CodeMirror editor scripts and styles
			$platform->addJsFile( 'codemirror.min.js', 'codemirror', null, null, true, true )
				->addCssFile( 'codemirror.min.css', 'codemirror', null, null, null, true )
				->addCssFile( 'codemirror/theme/mdn-like.min.css', 'codemirror-theme-midnight', array( 'codemirror' ), null, null, true );
		}
		if ( empty( $options ) || in_array( 'rangelist', $options ) ) {
			$platform->addJsFile( 'form-field-rangelist.min.js', 'drts-form-field-rangelist', array( 'drts-form' ) );
		}
		if ( empty( $options ) || in_array( 'multiselect', $options ) ) {
			$platform->addJsFile( 'BsMultiSelect.min.js', 'bs-multi-select', array( 'drts-bootstrap' ), null, true, true );
		}
		if ( empty( $options ) || in_array( 'uppy', $options ) ) {
			$this->uppy( $application );
		}
		// Trigger custom action for additional scripts
		$application->Action( 'form_scripts', array( $options ) );
	}

	/**
	 * Loads JavaScript for time picker field.
	 *
	 * @param Application $application
	 */
	public function time( Application $application ) {
		$application->getPlatform()->addJsFile( 'form-field-timepicker.min.js', 'drts-form-field-timepicker', array( 'drts-form' ) );
	}

	/**
	 * Loads JavaScript and CSS for date picker field.
	 *
	 * @param Application $application
	 * @param string|null $locale
	 */
	public function date( Application $application, $locale = null ) {
		$theme    = 'light';
		$platform = $application->getPlatform();
		$platform->addJsFile( false, 'vanilla-calendar' )
			->addJsFile( 'vanilla-calendar.min.js', 'vanilla-calendar', null, null, true, true )
			->addCssFile( false, 'vanilla-calendar' )
			->addCssFile( 'vanilla-calendar.min.css', 'vanilla-calendar', null, null, null, true )
			->addCssFile( 'vanilla-calendar/themes/' . $theme . '.min.css', 'vanilla-calendar-' . $theme, 'vanilla-calendar', null, null, true )
			->addJsFile( 'form-field-datepicker.min.js', 'drts-form-field-datepicker', array( 'vanilla-calendar', 'drts-form' ) )
			->addJsFile( 'php-date-formatter.min.js', 'php-date-formatter', null, null, true, true );
	}

	/**
	 * Checks if the given locale is valid for date picker.
	 *
	 * @param Application $application
	 * @param string      $locale
	 * @return bool
	 */
	public function isValidDateLocale( Application $application, $locale ) {
		return in_array(
			$locale,
			array(
				'ar',
				'at',
				'be',
				'bg',
				'bn',
				'cat',
				'cs',
				'cy',
				'da',
				'de',
				'eo',
				'es',
				'et',
				'fa',
				'fi',
				'fr',
				'gr',
				'he',
				'hi',
				'hr',
				'hu',
				'id',
				'it',
				'ja',
				'ko',
				'lt',
				'lv',
				'mk',
				'mn',
				'ms',
				'my',
				'nl',
				'no',
				'pa',
				'pl',
				'pt',
				'ro',
				'ru',
				'si',
				'sk',
				'sl',
				'sq',
				'sr',
				'sv',
				'th',
				'tr',
				'uk',
				'vn',
				'zh',
			)
		);
	}

	/**
	 * Returns the current locale for date picker.
	 *
	 * @param Application $application
	 * @return string
	 */
	public function dateLocale( Application $application ) {
		if ( $locale = $application->getPlatform()->getLocale() ) {
			if ( strpos( $locale, '_' ) ) {
				$locale = explode( '_', $locale )[0];
			}
		}
		return (string) $locale;
	}

	/**
	 * Loads JavaScript for file upload field.
	 *
	 * @param Application $application
	 */
	public function file( Application $application ) {
		$application->getPlatform()->loadJqueryUiJs( array( 'widget', 'sortable' ) )
			->addJsFile( 'jquery.iframe-transport.min.js', 'jquery-iframe-transport', 'jquery', null, true, true )
			->addJsFile( 'jquery.fileupload.min.js', 'jquery-fileupload', 'jquery-ui-widget', null, true, true )
			->addJsFile( 'form-field-upload.min.js', 'drts-form-field-upload', array( 'jquery-fileupload', 'jquery-ui-sortable', 'drts-form' ) );
	}

	/**
	 * Loads Select2 JavaScript and CSS for select fields.
	 *
	 * @param Application $application
	 * @param string|null $lang
	 */
	public function select2( Application $application, $lang = null ) {
		$application->getPlatform()->addJsFile( 'select2.min.js', 'drts-select2', array( 'jquery' ), null, true, true )
			->addCssFile( 'select2.min.css', 'drts-select2', null, null, null, true )
			->addCssFile( 'form-select2.min.css', 'drts-form-select2', 'drts-select2' );
		if ( isset( $lang ) ) {
			$application->getPlatform()->addJsFile( 'select2/i18n/' . $lang . '.min.js', 'drts-select2-' . $lang, 'drts-select2', null, true, true );
		}
	}

	/**
	 * Loads icon picker JavaScript for icon fields.
	 *
	 * @param Application $application
	 * @param array       $iconsets
	 */
	public function iconpicker( Application $application, array $iconsets = array() ) {
		$application->getPlatform()->addJsFile( 'form-field-picker.min.js', 'drts-form-field-picker', 'drts-form' )
			->addJsFile( 'form-field-iconpicker.min.js', 'drts-form-field-iconpicker', 'drts-form-field-picker' );
		if ( empty( $iconsets ) ) {
			$iconsets = array( 'fontawesome', 'dashicons' );
		}
		foreach ( $iconsets as $iconset ) {
			$application->getPlatform()->addJsFile( 'form-field-' . $iconset . '.min.js', 'drts-form-field-' . $iconset, 'drts-form-field-iconpicker' );
		}
	}

	/**
	 * Loads color picker JavaScript and CSS for color fields.
	 *
	 * @param Application $application
	 */
	public function colorpicker( Application $application ) {
		$application->getPlatform()->addJsFile( 'huebee.pkgd.min.js', 'huebee', 'jquery', null, true, true )
			->addCssFile( 'huebee.min.css', 'huebee', null, null, null, true )
			->addJsFile( 'form-field-colorpicker.min.js', 'drts-form-field-colorpicker', array( 'drts-form', 'huebee' ) );
	}

	/**
	 * Loads Typeahead JavaScript for autocomplete fields.
	 *
	 * @param Application $application
	 */
	public function typeahead( Application $application ) {
		$application->getPlatform()->addJsFile( 'typeahead.bundle.min.js', 'twitter-typeahead', 'jquery', 'directories-pro', true, true );
	}

	/**
	 * Loads Uppy JavaScript and CSS for advanced file uploads.
	 *
	 * @param Application $application
	 */
	public function uppy( Application $application ) {
		$application->getPlatform()
			->addJsFile( 'uppy/uppy.min.js', 'uppy', null, null, true, true )
			->addJsFile( 'form-field-uppy.min.js', 'drts-form-field-uppy', array( 'drts-form', 'uppy' ) )
			->addCssFile( 'uppy.min.css', 'uppy', null, null, null, true );
		$uppy_locales = array(
			'ar' => 'sa',
			'bg' => 'bg',
			'zh' => array( 'cn', 'tw' ),
			'hr' => 'hr',
			'cs' => 'cz',
			'da' => 'dk',
			'nl' => 'nl',
			'en' => 'us',
			'fi' => 'fi',
			'fr' => 'fr',
			'gl' => 'es',
			'de' => 'de',
			'el' => 'gr',
			'he' => 'il',
			'hi' => 'in',
			'hu' => 'hu',
			'is' => 'is',
			'id' => 'id',
			'it' => 'it',
			'ja' => 'jp',
			'ko' => 'kr',
			'nb' => 'no',
			'fa' => 'ir',
			'pl' => 'pl',
			'pt' => array( 'br', 'pt' ),
			'ro' => 'ro',
			'ru' => 'ru',
			'sk' => 'sk',
			'es' => array( 'es', 'mx' ),
			'sv' => 'se',
			'th' => 'th',
			'tr' => 'tr',
			'uk' => 'ua',
			'uz' => 'uz',
			'vi' => 'vn',
			'sr' => 'rs',
		);
		if ( $locale = $application->getPlatform()->getLocale() ) {
			list($lang, $country, $char) = explode( '_', strtolower( $locale ) ) + array( null, null, null );
			if ( isset( $uppy_locales[ $lang ] ) ) {
				if ( empty( $country )
					|| ! is_array( $uppy_locales[ $lang ] )
					|| ! in_array( $country, $uppy_locales[ $lang ] )
				) {
					$country = is_array( $uppy_locales[ $lang ] ) ? $uppy_locales[ $lang ][0] : $uppy_locales[ $lang ];
				}
				$uppy_locale = $lang . '_' . strtoupper( $country );
				if ( $uppy_locale === 'sr_RS' ) {
					$uppy_locale .= '_' . ( empty( $char ) || $char !== 'Cyrillic' ? 'Latin' : 'Cyrillic' );
				}
				$application->getPlatform()->addJsFile( 'uppy/locales/' . $uppy_locale . '.min.js', 'uppy-locale', array( 'uppy' ), null, true, true );
			}
		}
	}
}
