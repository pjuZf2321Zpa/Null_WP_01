<?php
namespace SabaiApps\Directories\Component\Form\Helper;

use SabaiApps\Directories\Application;

/**
 * ProgressHelper provides JavaScript helpers for form progress bars and AJAX progress handling.
 */
class ProgressHelper {

	/**
	 * Returns JavaScript for handling form submission with progress bar updates.
	 *
	 * @param Application $application
	 * @return string
	 */
	public function formSubmitJs( Application $application ) {
		return sprintf(
			'function (form, trigger, ajaxOptions) {
    form.slideUp("fast");
    var headers = form.parent().find(".drts-form-headers");
    if (headers.length) {
        headers.hide();
    }
    var modal = trigger.closest(".%1$smodal-content");
    if (modal.length) {
        modal.find(".drts-form-buttons").remove();
    }
    $(".drts-system-progress")
        .find(".drts-system-progress-bar > div").css("background-color", "#ccc").end()
        .slideDown("fast");
    var options = $.extend({}, ajaxOptions);
    var successCallback = options["onSuccess"] || function () {};
    var request = function (next) {
        options["data"] += "&next=" + next;
        DRTS.ajax(options);
    };
    var processResult = function(result, target, trigger) {
        var done = result.done || typeof result.next === "undefined";
        var $progress = $(".drts-system-progress");
        if (result.percent || done) {
            var percent = done ? 100 : result.percent;
            $progress.find(".drts-system-progress-bar > div").css({"background-color": "", width: percent + "%%"}).end()
                .find(".drts-system-progress-percent").text(percent + "%%");
        }
        if (result.logs) {        
            ["error", "warning", "info", "success"].forEach(function (level) {
                if (result.logs[level]
                    && result.logs[level].length
                ) {
                    if (!Array.isArray(result.logs[level])) {
                        result.logs[level] = [result.logs[level]];
                    }
                    $("<div class=\"%1$salert %1$salert-dismissible %1$sfade %1$sshow %1$salert-" + (level === "error" ? "danger" : level) + "\" style=\"display:none;\"><p class=\"%1$smy-0\">" + result.logs[level].join("</p><p class=\"%1$smt-2 %1$smb-0\">") + "</p><button type=\"button\" class=\"%1$sbtn-close\" data-bs-dismiss=\"alert\" aria-label=\"Close\"></button></div>")
                        .insertAfter($progress)
                        .slideDown("fast");
                }
            });
        }
        
        if (done) {
            $progress.find(".drts-system-progress-message").text(result.message ? result.message : "%2$s").end()
                .find(".drts-system-progress-bar > div").removeClass("%1$sprogress-bar-animated");
            successCallback(result, target, trigger);
        } else {
            if (result.message) {
                $progress.find(".drts-system-progress-message").text(result.message);
            }
            request(result.next); 
        }
    };
    options["onSuccess"] = processResult;
    ajaxOptions["onSuccess"] = function (result, target, trigger) {
        processResult(result, target, trigger);
    }  
}',
			DRTS_BS_PREFIX,
			$application->H( __( 'All done. Have fun!!', 'directories-pro' ) )
		);
	}

	/**
	 * Returns JavaScript for handling success events after progress completion.
	 *
	 * @param Application $application
	 * @return string
	 */
	public function onSuccessJs( Application $application ) {
		$js = 'if (result.download_file) {
    var btn = target.find(".drts-system-download");
    if (btn.length) {
        var modal = btn.closest(".' . DRTS_BS_PREFIX . 'modal-content");
        if (modal.length) {
            modal.find(".' . DRTS_BS_PREFIX . 'modal-footer").append(btn);
        }
        btn.slideDown("fast").on("click", function(e){
            e.preventDefault();
            var href = $(this).attr("href");
            window.location.href = href + (href.indexOf("?") === -1 ? "?" : "&") + "file=" + result.download_file;
        }).click();
    }
} else if (result.url) {
    if (target && target.attr("id") === "drts-modal") {
        setTimeout(function(){
            bootstrap.Modal.getInstance("#drts-modal").hide();
            window.location.href = result.url;
        }, 500);
    }
}';
		return 'function (result, target, trigger) {' . $js . '}';
	}
}
