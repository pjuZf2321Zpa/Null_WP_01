<?php
namespace SabaiApps\Directories\Component\Form;

/**
 * IFields interface for components that provide custom form fields.
 */
interface IFields {

	/**
	 * Returns an array of available field types.
	 *
	 * @return array
	 */
	public function formGetFieldTypes();

	/**
	 * Returns the field object for a given field type.
	 *
	 * @param string $type
	 * @return object|null
	 */
	public function formGetField( $type );
}
