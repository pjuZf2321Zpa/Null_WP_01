<?php
namespace SabaiApps\Directories\Helper;

use SabaiApps\Directories\Application;
use SabaiApps\Framework\User\AbstractIdentity;

/**
 * IsAdministratorHelper class for checking administrator status.
 * Returns true if the given identity or current user is an administrator.
 */
class IsAdministratorHelper {

	/**
	 * Checks if the given identity or current user is an administrator.
	 *
	 * @param Application           $application
	 * @param AbstractIdentity|null $identity
	 * @return bool
	 */
	public function help( Application $application, ?AbstractIdentity $identity = null ) {
		if ( ! isset( $identity ) ) {
			return $application->getUser()->isAdministrator();
		}
		return ! $identity->isAnonymous() && $application->getPlatform()->isAdministrator( $identity->id );
	}
}
