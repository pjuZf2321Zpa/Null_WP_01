<?php
namespace SabaiApps\Directories\Helper;

use SabaiApps\Directories\Application;

/**
 * ActionHelper class for dispatching application events.
 * Provides a method to trigger an event and optionally capture its output.
 */
class ActionHelper {

	/**
	 * Triggers an application event.
	 *
	 * @param Application $application
	 * @param string      $name Event name.
	 * @param array       $args Arguments to pass to the event.
	 * @param bool        $return If true, returns the output buffer.
	 * @return string|null
	 */
	public function help( Application $application, $name, array $args = array(), $return = false ) {
		if ( $return ) {
			ob_start();
			$this->_doAction( $application, $name, $args );
			return ob_get_clean();
		}
		$this->_doAction( $application, $name, $args );
	}

	/**
	 * Internal method to dispatch the event.
	 *
	 * @param Application $application
	 * @param string      $name
	 * @param array       $args
	 */
	protected function _doAction( Application $application, $name, array $args ) {
		$event_type = str_replace( '_', '', $name );
		if ( $application->hasEventListner( $event_type ) ) {
			$application->dispatchEvent( $event_type, $args );
		}
	}
}
