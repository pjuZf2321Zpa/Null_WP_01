<?php
namespace SabaiApps\Directories\Helper;

use SabaiApps\Directories\Application;
use SabaiApps\Framework\User\AbstractIdentity;

/**
 * UserIdentityHtmlHelper class for rendering user identity as HTML.
 * Supports rendering as link, text, thumbnail, or combinations.
 */
class UserIdentityHtmlHelper {

	protected $_thumbnails = array();

	/**
	 * Renders user identity in various formats.
	 *
	 * @param Application           $application
	 * @param AbstractIdentity|null $identity
	 * @param string                $format Output format ('link', 'text', 'thumb', etc.).
	 * @param bool                  $thumbnailOnly If true, only render the thumbnail.
	 * @return string|array
	 */
	public function help( Application $application, ?AbstractIdentity $identity = null, $format = '', $thumbnailOnly = false ) {
		switch ( $format ) {
			case 'link':
				return $this->_doLink( $application, $identity, $application->H( $this->_getUserIdentityName( $identity ) ) );
			case 'text':
				return $this->_doLink( $application, $identity, $application->H( $this->_getUserIdentityName( $identity ) ), false );
			case 'link_thumb_s':
				return $this->_linkWithThubmnail( $application, $identity, 'sm', $thumbnailOnly );
			case 'link_thumb':
				return $this->_linkWithThubmnail( $application, $identity, '', $thumbnailOnly );
			case 'thumb_s':
				return $this->_thumbnail( $application, $identity, 'sm', true );
			case 'thumb':
				return $this->_thumbnail( $application, $identity, '', true );
			default:
				return isset( $identity ) ? '' : array(
					'link'         => __( 'Link', 'directories-pro' ),
					'text'         => __( 'No link', 'directories-pro' ),
					'thumb_s'      => __( 'Thumbnail (small)', 'directories-pro' ),
					'thumb'        => __( 'Thumbnail', 'directories-pro' ),
					'link_thumb_s' => __( 'Thumbnail (small) with link', 'directories-pro' ),
					'link_thumb'   => __( 'Thumbnail with link', 'directories-pro' ),
				);
		}
	}

	/**
	 * Renders a link with a thumbnail and optional label.
	 */
	public function _linkWithThubmnail( Application $application, AbstractIdentity $identity, $size, $thumbnailOnly = false ) {
		$content = $this->_thumbnail( $application, $identity, $size, $thumbnailOnly );
		if ( ! $thumbnailOnly ) {
			$content .= '<span>' . $application->H( $this->_getUserIdentityName( $identity ) ) . '</span>';
		}

		return $this->_doLink( $application, $identity, $content );
	}

	/**
	 * Renders a link or span for the user identity.
	 */
	protected function _doLink( Application $application, AbstractIdentity $identity, $html, $link = true ) {
		if ( $identity->isAnonymous() ) {
			$class = 'drts-user drts-user-anonymous';
		} else {
			$class = 'drts-user drts-user-registered drts-user-' . $identity->id;
		}
		$attr = array(
			'href'   => $link ? $identity->url : false,
			'target' => '_blank',
			'rel'    => 'nofollow external noopener',
			'class'  => $class,
		);
		$attr = $application->Filter( 'core_user_link_attr', $attr, array( $identity ) );
		if ( ! $link
			|| empty( $attr['href'] )
		) {
			$tag = 'span';
			unset( $attr['href'], $attr['target'] );
		} else {
			$tag = 'a';
		}
		return '<' . $tag . $application->Attr( $attr ) . '>' . $application->Filter( 'core_user_link_html', $html, array( $identity ) ) . '</' . $tag . '>';
	}

	/**
	 * Renders a user thumbnail image.
	 */
	protected function _thumbnail( Application $application, AbstractIdentity $identity, $size, $tooltip = false ) {
		if ( $identity->isAnonymous() ) {
			return $this->_getThumbnail( $application, $identity, $size, $tooltip );
		}

		$id = $identity->id;
		if ( ! isset( $this->_thumbnails[ $id ][ $size ] ) ) {
			$this->_thumbnails[ $id ][ $size ] = $this->_getThumbnail( $application, $identity, $size, $tooltip );
		}
		return $this->_thumbnails[ $id ][ $size ];
	}

	/**
	 * Gets the thumbnail image HTML for the user.
	 */
	protected function _getThumbnail( Application $application, AbstractIdentity $identity, $size, $tooltip = false ) {
		if ( ! $url = $this->_getGravatarUrl( $application, $identity, $size ) ) {
			return '';
		}

		return sprintf(
			'<img src="%1$s" alt="%2$s" class="drts-user-thumbnail drts-icon %3$s" data-bs-title="%2$s"%4$s />',
			$application->H( $url ),
			$application->H( $this->_getUserIdentityName( $identity ) ),
			$size === 'sm' ? 'drts-icon-sm' : '',
			$tooltip ? ' rel="sabaitooltip"' : ''
		);
	}

	/**
	 * Gets the Gravatar URL for the user.
	 */
	protected function _getGravatarUrl( Application $application, AbstractIdentity $identity, $size ) {
		if ( ! $identity->email ) {
			return;
		}

		return $application->System_Url_gravatar( $identity->email, $size, $identity->gravatar_default, $identity->gravatar_rating );
	}

	/**
	 * Gets the display name for the user identity.
	 */
	protected function _getUserIdentityName( AbstractIdentity $identity ) {
		$name = $identity->name;
		if ( $name === null
			&& $identity->isAnonymous()
		) {
			$name = __( 'Guest', 'directories-pro' );
		}
		return $name;
	}
}
