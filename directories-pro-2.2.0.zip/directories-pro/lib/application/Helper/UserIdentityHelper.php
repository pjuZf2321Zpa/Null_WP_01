<?php
namespace SabaiApps\Directories\Helper;

use SabaiApps\Directories\Application;

/**
 * UserIdentityHelper class for fetching user identity objects.
 * Returns the identity for the current user or a given user ID.
 */
class UserIdentityHelper {

	/**
	 * Gets the user identity for the current user or a specific user ID.
	 *
	 * @param Application    $application
	 * @param int|array|null $userId User ID or array of IDs.
	 * @return mixed User identity object or array of identities.
	 */
	public function help( Application $application, $userId = null ) {
		if ( ! isset( $userId ) ) {
			if ( ! $application->getUser()->isAnonymous() ) {
				return $application->getUser()->getIdentity();
			}
			$userId = 0;
		}

		return is_array( $userId )
			? $application->getPlatform()->getUserIdentityFetcher()->fetchByIds( $userId )
			: $application->getPlatform()->getUserIdentityFetcher()->fetchById( $userId );
	}
}
