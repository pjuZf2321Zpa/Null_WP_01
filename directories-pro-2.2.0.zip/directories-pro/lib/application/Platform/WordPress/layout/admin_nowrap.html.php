<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
require_once ABSPATH . 'wp-admin/admin-header.php';
echo $this->Platform()->getHeadHtml();
echo $CONTENT;
echo $this->Platform()->getJsHtml();
require_once ABSPATH . 'wp-admin/admin-footer.php';
