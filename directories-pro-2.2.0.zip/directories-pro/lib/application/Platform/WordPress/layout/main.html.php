<?php if ( ! defined( 'ABSPATH' ) ) {
	exit;} ?>
<?php $this->Platform()->getTemplate()->setContext( $CONTEXT )->render(); ?>
<div<?php echo $CONTEXT->getHtmlAttribute(); ?> class="drts drts-main
<?php
if ( $this->Platform()->isRtl() ) :
	?>
	drts-rtl<?php endif; ?> <?php echo DRTS_BS_PREFIX; ?>clearfix"<?php echo $this->Attr( $CONTEXT->getExtraHtmlAttributes() ); ?>>
	<?php echo $CONTENT; ?>
</div>