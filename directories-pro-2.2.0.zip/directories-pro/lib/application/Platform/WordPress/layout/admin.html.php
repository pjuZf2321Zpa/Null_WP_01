<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
global $title, $menu, $submenu, $pagenow, $typenow, $self, $parent_file, $submenu_file, $plugin_page;
require_once ABSPATH . 'wp-admin/admin-header.php';
echo $this->Platform()->getHeadHtml();
?>
<div class="wrap">
	<?php if ( strlen( $CONTENT_TITLE = $CONTEXT->getTitle( true ) ) ) : ?>
		<h1 class="wp-heading-inline"><?php echo $this->H( $CONTENT_TITLE ); ?></h1>
	<?php endif; ?>
	<?php if ( $CONTENT_MENU = $CONTEXT->getMenus() ) : ?>
		<?php
		foreach ( $CONTENT_MENU as $_CONTENT_MENU ) :
			$options = isset( $_CONTENT_MENU['data']['link_options'] ) ? $_CONTENT_MENU['data']['link_options'] : array();
			$attr    = isset( $_CONTENT_MENU['data']['link_attr'] ) ? $_CONTENT_MENU['data']['link_attr'] : array();
			unset( $options['icon'], $attr['class'] );
			?>
			<?php echo $this->LinkTo( $_CONTENT_MENU['title'], $_CONTENT_MENU['url'], $options, $attr + array( 'class' => 'page-title-action' ) ); ?>
		<?php endforeach; ?>
	<?php endif; ?>
	<?php
	if ( ( $CONTENT_BREADCRUMBS = $CONTEXT->getInfo() ) && count( $CONTENT_BREADCRUMBS ) > 1 ) :
		$_CONTENT_BREADCRUMB_LAST = array_pop( $CONTENT_BREADCRUMBS );
		?>
		<div class="drts-breadcrumbs">
			<?php foreach ( $CONTENT_BREADCRUMBS as $_CONTENT_BREADCRUMB ) : ?>
				<span><?php echo $this->LinkTo( $_CONTENT_BREADCRUMB['title'], $_CONTENT_BREADCRUMB['url'] ); ?></span>
				<span> &raquo; </span>
			<?php endforeach; ?>
			<?php echo $this->H( $_CONTENT_BREADCRUMB_LAST['title'] ); ?>
		</div>
	<?php endif; ?>
	<hr class="wp-header-end" style="margin:-2px 0 0; border:0; border-top:1px solid #ddd; border-bottom:1px solid #fafafa;" />
	<div<?php echo $CONTEXT->getHtmlAttribute(); ?> class="drts drts-admin
	<?php
	if ( $this->Platform()->isRtl() ) :
		?>
		drts-rtl<?php endif; ?>"<?php echo $this->Attr( $CONTEXT->getExtraHtmlAttributes() ); ?>>
<?php echo $CONTENT; ?>
	</div>
</div>
<?php
echo $this->Platform()->getJsHtml();
require_once ABSPATH . 'wp-admin/admin-footer.php';