<?php
namespace SabaiApps\Directories\Platform\WordPress;

class Loader {

	private static $_path, $_version, $_priority, $_freemius;

	public static function pluginsDir() {
		return isset( self::$_path ) ? dirname( self::$_path ) : WP_CONTENT_DIR . '/plugins';
	}

	public static function plugin( $file = false ) {
		return $file ? self::pluginsDir() . '/directories-pro/directories-pro.php' : 'directories-pro';
	}

	public static function vendorDir() {
		return self::pluginsDir() . '/directories-pro/vendor';
	}

	public static function register( $path, $version, $priority = 0 ) {
		if ( isset( self::$_path ) ) {
			if ( self::$_version !== $version ) {
				if ( version_compare( $version, self::$_version, '<' ) ) {
					return;
				}
			} elseif ( $priority <= self::$_priority ) {
					return;
			}
			self::$_path = $path;
		} else {
			self::$_path = $path;
			$loader      = require self::$_path . '/vendor/autoload.php';
			if ( PHP_VERSION_ID >= 80000
				&& defined( 'DRTS_WORDPRESS_COMPOSER_USE_PHP8' )
				&& DRTS_WORDPRESS_COMPOSER_USE_PHP8
			) {
				foreach ( array(
					'Psr\\Log\\' => array( self::$_path . '/vendor8/psr/log/src' ),
				) as $namespace => $path ) {
					$loader->setPsr4( $namespace, $path );
				}
			}
			$freemius = self::freemius();
			add_action(
				'plugins_loaded',
				function () {
					self::getPlatform()->run();
				}
			);
			if ( is_admin() ) {
				register_activation_hook(
					self::plugin( true ),
					function () {
						self::getPlatform()->activate();
					}
				);
				if ( $freemius ) {
					$freemius->add_action( 'after_uninstall', array( __CLASS__, '_uninstall' ) );
				} else {
					register_uninstall_hook( self::plugin( true ), array( __CLASS__, '_uninstall' ) ); // needs to be static
				}
			}
		}
		self::$_version  = $version;
		self::$_priority = $priority;
	}

	/**
	 * @return Platform
	 */
	public static function getPlatform() {
		return Platform::getInstance();
	}

	public static function _uninstall() {
		try {
			self::getPlatform()->getApplication( true, true )->Uninstall();
		} catch ( \SabaiApps\Directories\Exception\NotInstalledException $e ) {
		}
	}

	public static function freemius() {
		if ( substr( 'directories-pro', -4 ) === '-pro' ) {
			return; // disable Freemius for Pro version for now
		}
		if ( ! function_exists( 'fs_dynamic_init' ) ) {
			return; // the Freemius SDK is not bundled with this build
		}

		if ( ! isset( self::$_freemius ) ) {
			self::$_freemius = fs_dynamic_init(
				array(
					'id'                  => '1564',
					'slug'                => 'directories-pro-lite',
					'premium_slug'        => 'directories-pro',
					'type'                => 'plugin',
					'public_key'          => 'pk_9e0dd9eeddb7a933de6a99459fe55',
					'is_premium'          => substr( 'directories-pro', -4 ) === '-pro',
					'has_premium_version' => true,
					'has_addons'          => false,
					'has_paid_plans'      => true,
					'is_org_compliant'    => true,
					'menu'                => array(
						'slug'    => 'drts/directories',
						'account' => false,
						'contact' => false,
						'support' => false,
					),
				)
			);
			do_action( 'drts_freemium_initialized', self::$_freemius );
		}
		return self::$_freemius;
	}
}
