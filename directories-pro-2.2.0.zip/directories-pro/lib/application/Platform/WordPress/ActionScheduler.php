<?php
namespace SabaiApps\Directories\Platform\WordPress;

class ActionScheduler extends AbstractScheduler {

	public function __toString() {
		return 'Action Scheduler';
	}

	public function scheduleRecurringAction( $recurrence, $action, array $args = array(), $priority = 10, $timestamp = null ) {
		switch ( $recurrence ) {
			case 'hourly':
				$interval_in_seconds = 3600;
				break;
			case 'twicedaily':
				$interval_in_seconds = 43200;
				break;
			case 'weekly':
				$interval_in_seconds = 604800;
				break;
			case 'monthly':
				$interval_in_seconds = 2592000;
				break;
			case 'daily':
			default:
				$interval_in_seconds = 86400;
				break;
		}
		return as_schedule_recurring_action( $timestamp ?? time(), $interval_in_seconds, $this->_getHookName( $action ), $args, 'drts', false, $priority );
	}

	public function scheduleSingleAction( $action, array $args = array(), $priority = 10, $timestamp = null ) {
		return as_schedule_single_action( $timestamp ?? time(), $this->_getHookName( $action ), $args, 'drts', false, $priority );
	}

	public function enqueueAction( $action, array $args = array(), $priority = 10 ) {
		return false === as_enqueue_async_action( $this->_getHookName( $action ), $args, 'drts', false, $priority ) ? false : true;
	}

	public function nextScheduledAction( $action, array $args = array() ) {
		return as_next_scheduled_action( $this->_getHookName( $action ), $args, 'drts' );
	}

	public function clearScheduledAction( $action, $args = array() ) {
		return as_unschedule_all_actions( $this->_getHookName( $action ), $args, 'drts' ) === null ? null : true;
	}
}
