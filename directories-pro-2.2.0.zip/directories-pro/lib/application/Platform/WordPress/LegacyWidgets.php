<?php
/**
 * Widget classes kept for backward compatibility.
 */
use SabaiApps\Directories\Platform\WordPress\Widget;

class SabaiApps_Directories_WordPress_Widget_directory_filters extends Widget {

	protected $_widgetName = 'directory_filters';
}

class SabaiApps_Directories_WordPress_Widget_display_element extends Widget {

	protected $_widgetName = 'display_element';
}

class SabaiApps_Directories_WordPress_Widget_user_users extends Widget {

	protected $_widgetName = 'user_users';
}

class SabaiApps_Directories_WordPress_Widget_directory_posts_directory__listing extends Widget {

	protected $_widgetName = 'directory_posts_directory__listing';
}

class SabaiApps_Directories_WordPress_Widget_directory_related_posts_directory__listing extends Widget {

	protected $_widgetName = 'directory_related_posts_directory__listing';
}

class SabaiApps_Directories_WordPress_Widget_directory_terms_directory_category___directory__listing extends Widget {

	protected $_widgetName = 'directory_terms_directory_category___directory__listing';
}

class SabaiApps_Directories_WordPress_Widget_directory_terms_location_location___directory__listing extends Widget {

	protected $_widgetName = 'directory_terms_location_location___directory__listing';
}
