<?php
namespace SabaiApps\Directories\Exception;

/**
 * Base runtime exception for the application.
 */
class RuntimeException extends \RuntimeException implements IException {}
