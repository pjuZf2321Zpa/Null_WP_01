<?php
namespace SabaiApps\Directories\Exception;

/**
 * Exception thrown when a component file or class is not found.
 */
class ComponentNotFoundException extends RuntimeException {}
