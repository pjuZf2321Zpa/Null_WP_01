<?php
namespace SabaiApps\Directories\Exception;

/**
 * Exception thrown when a component is not installed.
 */
class ComponentNotInstalledException extends RuntimeException {}
