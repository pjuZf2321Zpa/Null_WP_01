<?php
namespace SabaiApps\Directories\Exception;

/**
 * Exception thrown if an argument is not of the expected type.
 */
class InvalidArgumentException extends \InvalidArgumentException implements IException {}
