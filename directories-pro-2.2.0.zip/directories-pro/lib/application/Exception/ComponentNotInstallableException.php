<?php
namespace SabaiApps\Directories\Exception;

/**
 * Exception thrown when a component cannot be installed.
 */
class ComponentNotInstallableException extends RuntimeException {}
