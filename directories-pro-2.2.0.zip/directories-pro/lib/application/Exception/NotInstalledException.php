<?php
namespace SabaiApps\Directories\Exception;

/**
 * Exception thrown when the application or a component is not installed.
 */
class NotInstalledException extends RuntimeException {}
