<?php
namespace SabaiApps\Directories\Exception;

/**
 * Interface for all custom application exceptions.
 */
interface IException {}
