<?php
namespace SabaiApps\Directories\Component\Captcha;

interface IApis {

	public function captchaGetApiNames();
	public function captchaGetApi( $name );
}
