<?php
namespace SabaiApps\Directories\Component\Captcha\Api;

use SabaiApps\Directories\Component\Form\Form;

class ReCaptcha2Api extends AbstractReCaptchaApi {

	protected function _captchaApiInfo() {
		return array(
			'label'            => __( 'reCAPTCHA v2 (Checkbox)', 'directories-pro' ),
			'default_settings' => array(
				'sitekey' => null,
				'secret'  => null,
				'size'    => 'normal',
				'type'    => 'image',
				'theme'   => 'light',
			),
			'weight'           => 2,
		);
	}

	public function captchaApiSettingsForm( array $settings, array $parents ) {
		return array(
			'sitekey' => array(
				'#title'         => __( 'Site key', 'directories-pro' ),
				'#type'          => 'textfield',
				'#default_value' => $settings['sitekey'],
				'#horizontal'    => true,
			),
			'secret'  => array(
				'#title'         => __( 'Secret key', 'directories-pro' ),
				'#type'          => 'textfield',
				'#default_value' => $settings['secret'],
				'#horizontal'    => true,
			),
			'size'    => array(
				'#type'          => 'select',
				'#title'         => __( 'Display size', 'directories-pro' ),
				'#options'       => array(
					'normal'  => __( 'Normal', 'directories-pro' ),
					'compact' => __( 'Compact', 'directories-pro' ),
				),
				'#default_value' => $settings['size'],
				'#horizontal'    => true,
			),
			'type'    => array(
				'#type'          => 'select',
				'#title'         => __( 'Display type', 'directories-pro' ),
				'#options'       => array(
					'image' => __( 'Image', 'directories-pro' ),
					'audio' => __( 'Audio', 'directories-pro' ),
				),
				'#default_value' => $settings['type'],
				'#horizontal'    => true,
			),
			'theme'   => array(
				'#type'          => 'select',
				'#title'         => __( 'Theme', 'directories-pro' ),
				'#options'       => array(
					'light' => __( 'Light', 'directories-pro' ),
					'dark'  => __( 'Dark', 'directories-pro' ),
				),
				'#default_value' => $settings['theme'],
				'#horizontal'    => true,
			),
		);
	}

	public function captchaApiForm( array $settings, $name, $trigger = null ) {
		if ( ! self::$_jsLoaded ) {
			$js     = sprintf(
				'var drtsReCaptchaCallback = function() {
    if (typeof(grecaptcha) === "undefined"
        || typeof(grecaptcha.render) === "undefined"
    ) return;
    jQuery(".drts-captcha-recaptcha-form-field").each(function(i) {
        var $this = jQuery(this), options = {
            sitekey: "%s",
            size: $this.data("size"),
            type: $this.data("type"),
            theme: $this.data("theme")
        };
        $this.data("recaptcha-widget-id", grecaptcha.render($this.attr("id"), options))
            .find("textarea").attr("name", $this.attr("id"));
    });
};',
				$this->_application->H( $settings['sitekey'] )
			);
			$locale = $this->_application->getPlatform()->getLocale();
			if ( strpos( $locale, '_' ) ) {
				$locale = explode( '_', $locale );
				$locale = in_array( $locale[0], array( 'zh', 'pt' ) ) ? $locale[0] . '-' . $locale[1] : $locale[0];
			}
			$platform = $this->_application->getPlatform();
			$platform->addJsFile( 'https://www.google.com/recaptcha/api.js?onload=drtsReCaptchaCallback&render=explicit&hl=' . $locale, 'captcha_recaptcha', null, false, true, false, '' );
			$platform->addJsInline( 'captcha_recaptcha', $js, false, 'before' );
			self::$_jsLoaded = true;
		}

		$id = 'drts-captcha-recaptcha-form-field-' . $name;
		return array(
			'#type'             => 'item',
			'#element_validate' => array(
				array( array( $this, '_validateCaptchaV2' ), array( $settings['secret'], $trigger, $id ) ),
			),
			'#markup'           => '<div class="drts-captcha-recaptcha-form-field" id="' . $id . '" data-size="' . $this->_application->H( $settings['size'] ) . '"'
				. ' data-type="' . $this->_application->H( $settings['type'] ) . '" data-theme="' . $this->_application->H( $settings['theme'] ) . '"'
				. ' data-trigger="' . $this->_application->H( $trigger ) . '"></div>',
		);
	}

	public function _validateCaptchaV2( Form $form, &$value, $element, $secret, $trigger, $id ) {
		$this->_validateCaptcha( $form, $secret, $trigger, $id, $element );
	}
}
