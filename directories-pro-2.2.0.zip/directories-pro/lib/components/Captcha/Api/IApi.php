<?php
namespace SabaiApps\Directories\Component\Captcha\Api;

interface IApi {

	public function captchaApiInfo( $key = null );
	public function captchaApiIsEnabled();
	public function captchaApiSettingsForm( array $settings, array $parents );
	public function captchaApiForm( array $settings, $name, $trigger = null );
}
