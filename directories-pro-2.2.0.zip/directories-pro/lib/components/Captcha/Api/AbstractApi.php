<?php
namespace SabaiApps\Directories\Component\Captcha\Api;

use SabaiApps\Directories\Application;
use SabaiApps\Framework\Application\HttpRequest;

abstract class AbstractApi implements IApi {

	protected $_application, $_name, $_info;

	public function __construct( Application $application, $name ) {
		$this->_application = $application;
		$this->_name        = $name;
	}

	public function captchaApiInfo( $key = null ) {
		if ( ! isset( $this->_info ) ) {
			$this->_info = (array) $this->_captchaApiInfo();
		}

		return isset( $key ) ? ( isset( $this->_info[ $key ] ) ? $this->_info[ $key ] : null ) : $this->_info;
	}

	public function captchaApiIsEnabled() {
		return true;
	}

	public function captchaApiSettingsForm( array $settings, array $parents ) {
		return array();
	}

	protected function _getIp() {
		return HttpRequest::ip( '' );
	}

	abstract protected function _captchaApiInfo();
}
