<?php
namespace SabaiApps\Directories\Component\Contact;

use SabaiApps\Directories\Component\AbstractComponent;
use SabaiApps\Directories\Component\Display;
use SabaiApps\Directories\Component\Entity;

class ContactComponent extends AbstractComponent implements Display\IElements, Entity\IFeatures, IForms {

	const VERSION = '2.2.0', PACKAGE = 'directories-pro';

	public static function interfaces() {
		return array( 'Payment\IFeatures' );
	}

	public static function description() {
		return 'Allows visitors to send messages to content authors/owners through a contact form.';
	}

	public function displayGetElementNames( Entity\Model\Bundle $bundle ) {
		if ( ! empty( $bundle->info['is_taxonomy'] )
			|| ! empty( $bundle->info['parent'] )
			|| ! empty( $bundle->info['parent_field'] )
		) {
			return array();
		}

		return array( 'contact_form' );
	}

	public function displayGetElement( $name ) {
		return new DisplayElement\FormDisplayElement( $this->_application, $name );
	}

	public function entityGetFeatureNames() {
		return array( 'contact_form' );
	}

	public function entityGetFeature( $name ) {
		return new EntityFeature\FormEntityFeature( $this->_application, $name );
	}

	public function paymentGetFeatureNames() {
		return array( 'contact_form' );
	}

	public function paymentGetFeature( $name ) {
		return new PaymentFeature\FormPaymentFeature( $this->_application, $name );
	}

	public function onCorePlatformWordPressInit() {
		if ( $forms = $this->_application->Contact_Forms() ) {
			foreach ( array_keys( $forms ) as $form_name ) {
				if ( ( $form = $this->_application->Contact_Forms_impl( $form_name ) )
					&& $form->contactFormIsEnabled()
				) {
					$form->contactFormInit();
				}
			}
		}
	}

	public function onEntityAdminBundleSettingsFormFilter( &$form, $bundle, $submitValues ) {
		if ( ! $this->_application->Entity_BundleTypeInfo( $bundle, 'contact_enable' ) ) {
			return;
		}

		if ( $this->_application->isComponentLoaded( 'Payment' )
			&& ! empty( $bundle->info['payment_enable'] )
		) {
			return; // the setting is integrated with payment feature settings
		}

		$value                           = empty( $bundle->info['contact_form'] ) ? array() : $bundle->info['contact_form'];
		$recipient_options               = $this->_application->getComponent( 'Contact' )->getRecipientOptions( $bundle );
		$form['general']['contact_form'] = array(
			'#title'     => __( 'Contact Form', 'directories-pro' ),
			'#tree'      => true,
			'#weight'    => 99,
			'recipients' => array(
				'#title'            => __( 'Contact form recipients', 'directories-pro' ),
				'#type'             => 'checkboxes',
				'#options'          => $recipient_options[0],
				'#options_disabled' => $recipient_options[1],
				'#default_value'    => isset( $value['recipients'] ) ? $value['recipients'] : ( in_array( 'author', $recipient_options[0] ) ? array( 'author' ) : null ),
				'#horizontal'       => true,
				'#columns'          => 1,
			),
		);
	}

	public function onEntityBundleInfoUserKeysFilter( &$keys ) {
		$keys[] = 'contact_form';
	}

	public function getRecipientOptions( Entity\Model\Bundle $bundle ) {
		$options = array(
			'site' => __( 'Site E-mail', 'directories-pro' ) . ' - ' . $this->_application->getPlatform()->getSiteEmail(),
		);
		if ( empty( $bundle->info['is_user'] ) ) {
			$options['author'] = __( 'Author', 'directories-pro' );
		}
		$email_field_options = $this->_application->Entity_Field_options(
			$bundle,
			array(
				'interface'       => 'Field\Type\IEmail',
				'prefix'          => __( 'Field - ', 'directories-pro' ),
				'return_disabled' => true,
			)
		);
		$options            += $email_field_options[0];
		return array( $options, array_keys( $email_field_options[1] ) );
	}

	public function contactGetFormNames() {
		if ( $this->_application->getPlatform()->getName() === 'WordPress' ) {
			return array( 'cf7', 'wpforms', 'gravityform', 'happyforms', 'formidable' );
		}
		return array();
	}

	public function contactGetForm( $name ) {
		switch ( $name ) {
			case 'cf7':
				return new Form\ContactForm7Form( $this->_application, $name );
			case 'wpforms':
				return new Form\WpFormsForm( $this->_application, $name );
			case 'gravityform':
				return new Form\GravityFormForm( $this->_application, $name );
			case 'happyforms':
				return new Form\HappyFormsForm( $this->_application, $name );
			case 'formidable':
				return new Form\FormidableFormsForm( $this->_application, $name );
		}
	}
}
