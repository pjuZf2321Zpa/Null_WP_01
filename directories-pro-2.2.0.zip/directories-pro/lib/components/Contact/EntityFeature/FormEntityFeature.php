<?php
namespace SabaiApps\Directories\Component\Contact\EntityFeature;

use SabaiApps\Directories\Component\Entity\Feature\AbstractFeature;
use SabaiApps\Directories\Component\Entity\Model\Bundle;

class FormEntityFeature extends AbstractFeature {

	protected function _entityFeatureInfo() {
		return array(
			'label'            => __( 'Contact Form', 'directories-pro' ),
			'weight'           => 99,
			'default_settings' => array(
				'enable'     => false,
				'recipients' => array( 'author' ),
			),
		);
	}

	public function entityFeatureSupports( Bundle $bundle, $planType = 'base' ) {
		return (bool) $this->_application->Entity_BundleTypeInfo( $bundle, 'contact_enable' );
	}

	public function entityFeatureSettingsForm( Bundle $bundle, array $settings, array $parents = array() ) {
		$recipient_options = $this->_application->getComponent( 'Contact' )->getRecipientOptions( $bundle );
		return array(
			'enable'     => array(
				'#title'         => __( 'Enable contact form', 'directories-pro' ),
				'#type'          => 'checkbox',
				'#default_value' => ! empty( $settings['enable'] ),
				'#horizontal'    => true,
			),
			'recipients' => array(
				'#title'            => __( 'Contact form recipients', 'directories-pro' ),
				'#type'             => 'checkboxes',
				'#options'          => $recipient_options[0],
				'#options_disabled' => $recipient_options[1],
				'#default_value'    => isset( $settings['recipients'] ) ? $settings['recipients'] : null,
				'#horizontal'       => true,
				'#columns'          => 1,
				'#states'           => array(
					'visible' => array(
						sprintf( 'input[name="%s"]', $this->_application->Form_Form_fieldName( array( $parents, 'enable' ) ) ) => array(
							'type'  => 'checked',
							'value' => true,
						),
					),
				),
			),
		);
	}

	public function entityFeatureIsEnabled( Bundle $bundle, array $settings ) {
		return ! empty( $settings['enable'] );
	}
}
