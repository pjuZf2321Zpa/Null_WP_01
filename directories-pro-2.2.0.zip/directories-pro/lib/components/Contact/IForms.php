<?php
namespace SabaiApps\Directories\Component\Contact;

use SabaiApps\Directories\Component\Contact\Form\IForm;

interface IForms {

	/**
	 * @return array
	 */
	public function contactGetFormNames();

	/**
	 * @param string $name
	 * @return IForm
	 */
	public function contactGetForm( $name );
}
