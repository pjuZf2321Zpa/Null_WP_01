<?php
namespace SabaiApps\Directories\Component\Contact\Form;

use SabaiApps\Directories\Component\Display\Model\Element;
use SabaiApps\Directories\Component\Entity\Model\Bundle;
use SabaiApps\Directories\Component\Entity\Type\IEntity;

interface IForm {

	public function contactFormInfo( $key = null );
	public function contactFormIsEnabled();
	public function contactFormInit();
	public function contactFormList();
	public function contactFormRender( $formId, IEntity $entity );
	public function contactFormOnDisplayElementSaved( $formId, Bundle $bundle, Element $element );
	public function contactFormOnDisplayElementRemoved( $formId, Bundle $bundle, array $settings, $elementName, $elementId );
}
