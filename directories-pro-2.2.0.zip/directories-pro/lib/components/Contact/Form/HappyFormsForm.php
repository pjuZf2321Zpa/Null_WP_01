<?php
namespace SabaiApps\Directories\Component\Contact\Form;

use SabaiApps\Directories\Component\Display\Model\Element;
use SabaiApps\Directories\Component\Entity\Model\Bundle;
use SabaiApps\Directories\Component\Entity\Type\IEntity;

class HappyFormsForm extends AbstractForm {

	protected function _contactFormInfo() {
		return array(
			'title' => 'HappyForms',
		);
	}

	public function contactFormIsEnabled() {
		return defined( 'HAPPYFORMS_VERSION' ) || defined( 'HAPPYFORMS_UPGRADE_VERSION' );
	}

	public function contactFormInit() {
		add_filter( 'happyforms_email_alert', array( $this, 'emailAlertFilter' ) );
	}

	public function emailAlertFilter( $message ) {
		if ( $recipients = $this->_isSending() ) {
			$message->set_to( implode( ',', $recipients ) );
		}
		return $message;
	}

	public function contactFormList() {
		$list = array();
		if ( $happyforms = get_posts(
			array(
				'post_type'      => 'happyform',
				'post_status'    => 'publish',
				'posts_per_page' => -1,
			)
		) ) {
			foreach ( $happyforms as $post ) {
				$list[ $post->ID ] = $post->post_title;
			}
		}
		return $list;
	}

	public function contactFormRender( $formId, IEntity $entity ) {
		if ( $post_id = intval( $formId ) ) {
			if ( happyforms_get_meta( $post_id, 'modal', true ) ) {
				return '<div class="' . DRTS_BS_PREFIX . 'alert ' . DRTS_BS_PREFIX . 'alert-danger ">Directories Pro can not display HappyForms forms in overlay window.</div>';
			}
			return do_shortcode( '[happyforms id="' . $this->_maybeGetTranslatedPostId( $post_id, 'happyforms' ) . '"]' );
		}
	}

	protected function _getSendingEntity() {
		if ( empty( $_REQUEST['happyforms_form_id'] )
			|| empty( $_REQUEST['happyforms_client_referer'] )
			|| ( ! $form_id = intval( $_REQUEST['happyforms_form_id'] ) )
			|| ( ! $slug = basename( sanitize_text_field( wp_unslash( $_REQUEST['happyforms_client_referer'] ) ) ) )
			|| ( ! $happyforms = $this->_application->getPlatform()->getCache( 'contact_happyforms' ) )
			|| empty( $happyforms[ $form_id ] )
		) {
			return;
		}

		$entity = null;
		foreach ( array_keys( $happyforms[ $form_id ] ) as $bundle_name ) {
			if ( $entity = $this->_application->Entity_Entity( 'post', is_numeric( $slug ) ? $slug : array( $bundle_name, $slug ) ) ) {
				break;
			}
		}

		return $entity;
	}

	public function contactFormOnDisplayElementRemoved( $formId, Bundle $bundle, array $settings, $elementName, $elementId ) {
		if ( ! $happyforms = $this->_application->getPlatform()->getCache( 'contact_happyforms' ) ) {
			return;
		}

		$form_id = intval( substr( $settings['form'], strlen( $this->_name . '-' ) ) );
		if ( isset( $happyforms[ $form_id ][ $bundle->name ][ $elementId ] ) ) {
			unset( $happyforms[ $form_id ][ $bundle->name ][ $elementId ] );
			if ( empty( $happyforms[ $form_id ][ $bundle->name ] ) ) {
				unset( $happyforms[ $form_id ][ $bundle->name ] );
			}
			$this->_application->getPlatform()->setCache( $happyforms, 'contact_happyforms' );
		}
	}

	public function contactFormOnDisplayElementSaved( $formId, Bundle $bundle, Element $element ) {
		if ( ! $happyforms = $this->_application->getPlatform()->getCache( 'contact_happyforms' ) ) {
			$happyforms = array();
		}
		$form_id = substr( $element->data['settings']['form'], strlen( $this->_name . '-' ) );
		$happyforms[ $form_id ][ $bundle->name ][ $element->element_id ] = true;
		$this->_application->getPlatform()->setCache( $happyforms, 'contact_happyforms' );
	}
}
