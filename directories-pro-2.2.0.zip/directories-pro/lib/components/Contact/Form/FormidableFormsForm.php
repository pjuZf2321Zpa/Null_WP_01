<?php
namespace SabaiApps\Directories\Component\Contact\Form;

use SabaiApps\Directories\Component\Entity\Type\IEntity;

class FormidableFormsForm extends AbstractForm {

	protected function _contactFormInfo() {
		return array(
			'title' => 'Formidable Form',
		);
	}

	public function contactFormIsEnabled() {
		return function_exists( 'load_formidable_forms' );
	}

	public function contactFormInit() {
		add_action( 'frm_entry_form', array( $this, 'entryFormAction' ) );
		add_filter( 'frm_to_email', array( $this, 'toEmailFilter' ), 10, 4 );
	}

	public function entryFormAction() {
		if ( $entity = $this->_isDisplaying() ) {
			echo $this->_getHiddenFieldHtml( $entity ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- hidden input with an integer entity ID
		}
	}

	public function toEmailFilter( $recipients, $values, $formId, $args ) {
		if ( $_recipients = $this->_isSending() ) {
			$recipients = $_recipients;
		}
		return $recipients;
	}

	public function contactFormList() {
		$list  = array();
		$where = array(
			'is_template' => 0,
			'status'      => 'published',
			array(
				'or'               => 1,
				'parent_form_id'   => null,
				'parent_form_id <' => 1,
			),
		);
		if ( $forms = \FrmForm::getAll( $where, 'name' ) ) {
			foreach ( $forms as $form ) {
				$list[ $form->id ] = $form->name;
			}
		}
		return $list;
	}

	public function contactFormRender( $formId, IEntity $entity ) {
		if ( $form_id = intval( $formId ) ) {
			return do_shortcode( '[formidable id=' . $form_id . ']' );
		}
	}
}
