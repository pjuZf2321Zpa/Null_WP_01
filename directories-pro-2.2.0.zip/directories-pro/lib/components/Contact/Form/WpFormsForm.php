<?php
namespace SabaiApps\Directories\Component\Contact\Form;

use SabaiApps\Directories\Component\Entity\Type\IEntity;

class WpFormsForm extends AbstractForm {

	protected function _contactFormInfo() {
		return array(
			'title' => 'WPForms',
		);
	}

	public function contactFormIsEnabled() {
		return defined( 'WPFORMS_VERSION' );
	}

	public function contactFormInit() {
		add_action( 'wpforms_frontend_output', array( $this, 'frontendOutputAction' ) );
		add_filter( 'wpforms_entry_email_atts', array( $this, 'entryEmailAttsFilter' ) );
	}

	public function contactFormList() {
		$list = array();
		if ( $wpforms_forms = wpforms()->form->get( '', array( 'orderby' => 'title' ) ) ) {
			foreach ( $wpforms_forms as $post ) {
				$list[ $post->ID ] = $post->post_title;
			}
		}
		return $list;
	}

	public function contactFormRender( $formId, IEntity $entity ) {
		if ( $post_id = intval( $formId ) ) {
			return do_shortcode( '[wpforms id="' . $this->_maybeGetTranslatedPostId( $post_id, 'wpforms' ) . '" title="false" description="false"]' );
		}
	}

	public function frontendOutputAction() {
		if ( $entity = $this->_isDisplaying() ) {
			echo $this->_getHiddenFieldHtml( $entity ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- hidden input with an integer entity ID
		}
	}

	public function entryEmailAttsFilter( $email ) {
		if ( $recipients = $this->_isSending() ) {
			$email['address'] = $recipients;
		}
		return $email;
	}
}
