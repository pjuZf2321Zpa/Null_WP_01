<?php
namespace SabaiApps\Directories\Component\Comparison;

use SabaiApps\Directories\Component\AbstractComponent;
use SabaiApps\Directories\Component\View;
use SabaiApps\Directories\Component\System;
use SabaiApps\Directories\Component\Display;
use SabaiApps\Directories\Context;
use SabaiApps\Directories\Component\Entity\Model\Bundle;

class ComparisonComponent extends AbstractComponent implements View\IModes, System\IMainRouter, System\ISlugs, Display\IButtons {

	const VERSION = '2.2.0', PACKAGE = 'directories-pro';

	public static function description() {
		return 'Provides entity comparison functionality.';
	}

	public function viewGetModeNames() {
		return array( 'comparison' );
	}

	public function viewGetMode( $name ) {
		switch ( $name ) {
			case 'comparison':
				return new ViewMode\ComparisonViewMode( $this->_application, $name );
		}
	}

	public function systemMainRoutes( $lang = null ) {
		$routes = array();
		foreach ( $this->_application->Entity_Bundles() as $bundle ) {
			if ( empty( $bundle->info['comparison_enable'] ) ) {
				continue;
			}

			$routes[ $bundle->getPath( false, $lang ) . '/compare' ] = array(
				'controller'      => 'CompareEntities',
				'title_callback'  => true,
				'access_callback' => true,
				'callback_path'   => 'compare_entities',
				'priority'        => 3,
			);

			// The page assigned under Page Settings (see onSystemSlugsFilter()) is
			// itself a main route, served by the same controller.
			if ( $this->_isPagelessBundle( $bundle )
				&& $this->hasSlug( $slug_name = self::slugName( $bundle ), $lang )
			) {
				$routes[ '/' . $this->getSlug( $slug_name, $lang ) ] = array(
					'controller'      => 'CompareEntities',
					'title_callback'  => true,
					'access_callback' => true,
					'callback_path'   => 'compare_page',
					'priority'        => 3,
					'data'            => array( 'bundle' => $bundle->name ),
				);
			}
		}

		return $routes;
	}
	public function systemOnAccessMainRoute( Context $context, $path, $accessType, array &$route ) {
		switch ( $path ) {
			case 'compare_entities':
				return isset( $context->bundle ) && ! empty( $context->bundle->info['comparison_enable'] );
			case 'compare_page':
				if ( ! isset( $context->bundle ) ) {
					if ( ! $bundle = $this->_application->Entity_Bundle( $route['data']['bundle'] ) ) {
						return false;
					}

					$context->bundle = $bundle;
				}
				return ! empty( $context->bundle->info['comparison_enable'] );
		}
	}

	public function systemMainRouteTitle( Context $context, $path, $titleType, array $route ) {
		switch ( $path ) {
			case 'compare_entities':
			case 'compare_page':
				return $context->bundle->getLabel( 'compare' );
		}
	}

	/**
	 * [<prefix>-directory-compare] renders the same route/controller as the
	 * dedicated /compare page (DirectoryComponent's generic shortcode
	 * dispatch resolves the path to $bundle->getPath() . '/compare', which is
	 * exactly what systemMainRoutes() above registers - CompareEntities sets
	 * $context->settings itself regardless of what the shortcode passed in,
	 * so no onDirectoryDoShortcodeFilter is needed here). This lets a content
	 * type with no page of its own (e.g. one adopting another plugin's post
	 * type - see ProductDirectoryType's 'pageable' => false) still offer a
	 * real, working comparison page: a page carrying this shortcode is assigned
	 * under Page Settings (see onSystemSlugsFilter()) and the Compare button
	 * links to it - see CompareDisplayButton.
	 */
	public function onDirectoryShortcodesFilter( &$shortcodes ) {
		$shortcodes['compare'] = array( 'path' => '/compare' );
	}

	public function onDirectoryContentTypeSettingsFormFilter( &$form, $directoryType, $contentType, $info, $settings, $parents, $submitValues ) {
		if ( empty( $info['comparison_enable'] )
			|| ! empty( $info['is_taxonomy'] )
			|| ! empty( $info['parent'] )
			|| empty( $info['public'] )
		) {
			return;
		}

		$form['comparison_enable'] = array(
			'#type'          => 'checkbox',
			'#title'         => __( 'Enable comparison', 'directories-pro' ),
			'#default_value' => ! empty( $settings['comparison_enable'] ) || is_null( $settings ),
			'#horizontal'    => true,
			'#weight'        => 30,
		);
	}

	const SLUG_PREFIX = 'compare-';

	public static function slugName( Bundle $bundle ) {
		// Component::hasSlug()/getSlug() lowercase the slug name they're given
		return strtolower( self::SLUG_PREFIX . $bundle->name );
	}

	/**
	 * Whether $bundle belongs to a directory type with no page of its own
	 * (pageable => false) - the only case that gets a comparison page slug.
	 */
	protected function _isPagelessBundle( Bundle $bundle ) {
		return ! empty( $bundle->info['comparison_enable'] )
			&& $bundle->group
			&& ( $directory = $this->_application->Directory_Directory( $bundle->group ) )
			&& $this->_application->Directory_Types_impl( $directory->type )->directoryInfo( 'pageable' ) === false;
	}

	// Slugs are contributed dynamically per content type - see onSystemSlugsFilter().
	public function systemSlugs() {
		return array();
	}

	/**
	 * A content type with no page of its own (pageable => false, e.g.
	 * ProductDirectoryType) has no working auto-URL for the /compare route, so
	 * offer a page slug for it under Page Settings (with the compare shortcode
	 * pre-filled when creating the page). Content types that do have a page
	 * are unaffected.
	 */
	public function onSystemSlugsFilter( &$slugs ) {
		foreach ( $this->_application->Entity_Bundles() as $bundle ) {
			if ( ! $this->_isPagelessBundle( $bundle ) ) {
				continue;
			}

			$slugs[ $this->_name ] = $this->getComparePageSlugs( $bundle ) + (array) @$slugs[ $this->_name ];
		}
	}

	/**
	 * The page slug definition for $bundle's comparison page (whether or not
	 * comparison is enabled at the moment - lets a settings screen show the page
	 * selection before the setting is saved).
	 */
	public function getComparePageSlugs( Bundle $bundle ) {
		$slug_name = self::slugName( $bundle );
		$title     = $bundle->getLabel( 'compare' ) ?: __( 'Compare', 'directories-pro' );
		return array(
			$slug_name => array(
				'slug'         => $slug_name,
				'admin_title'  => $title,
				'title'        => $title,
				'component'    => $this->_name,
				'wp_shortcode' => array( 'drts-directory-compare', array( 'directory' => $bundle->group ) ),
				'required'     => false,
				'weight'       => 90,
			),
		);
	}

	public function onDirectoryContentTypeInfoFilter( &$info, $contentType, $settings = null ) {
		if ( ! isset( $info['comparison_enable'] ) ) {
			return;
		}

		if ( ! empty( $info['is_taxonomy'] )
			|| ! empty( $info['parent'] )
			|| empty( $info['public'] )
		) {
			unset( $info['comparison_enable'] );
		}

		if ( isset( $settings['comparison_enable'] ) && ! $settings['comparison_enable'] ) {
			$info['comparison_enable'] = false;
		}
	}

	public function onEntityBundleInfoKeysFilter( &$keys ) {
		$keys[] = 'comparison_enable';
	}

	public function onEntityBundleInfoUserKeysFilter( &$keys ) {
		$keys[] = 'comparison';
	}

	public function onEntityAdminBundleSettingsFormFilter( array &$form, Bundle $bundle, $submitValues ) {
		if ( empty( $bundle->info['comparison_enable'] ) ) {
			return;
		}

		// Add search settings
		$form['#tabs'][ $this->_name ] = array(
			'#title'  => __( 'Comparison', 'directories-pro' ),
			'#weight' => 30,
		);
		$form['comparison']            = array(
			'#tab'  => $this->_name,
			'#tree' => true,
		);
		$settings                      = empty( $bundle->info['comparison'] ) ? array() : $bundle->info['comparison'];
		$form['comparison']            = array(
			'#tab'  => $this->_name,
			'#tree' => true,
		) + $this->_application->View_SettingsForm_mode( $bundle, 'comparison', $settings, array( 'comparison' ) );

		// Add label setting
		$form['general']['labels']['label_compare'] = array(
			'#type'          => 'textfield',
			'#title'         => __( 'Compare items label', 'directories-pro' ),
			'#default_value' => $bundle->getLabel( 'compare' ),
			'#horizontal'    => true,
			'#placeholder'   => ( $placeholder = $this->_application->Entity_BundleTypeInfo( $bundle, 'label_compare' ) ) ? $placeholder : __( 'Compare', 'directories-pro' ),
			'#required'      => true,
		);
	}

	public function displayGetButtonNames( Bundle $bundle ) {
		return array( 'comparison_compare' );
	}

	public function displayGetButton( $name ) {
		return new DisplayButton\CompareDisplayButton( $this->_application, $name );
	}
}
