<?php
namespace SabaiApps\Directories\Component\Comparison\DisplayButton;

use SabaiApps\Directories\Component\Entity\Model\Bundle;
use SabaiApps\Directories\Component\Entity\Type\IEntity;
use SabaiApps\Directories\Component\Display\Button\AbstractButton;
use SabaiApps\Directories\Component\Comparison\ComparisonComponent;

class CompareDisplayButton extends AbstractButton {

	protected static $_jsAdded = array();

	protected function _displayButtonInfo( Bundle $bundle ) {
		return array(
			'label'            => __( 'Compare button', 'directories-pro' ),
			'description'      => __( 'Add selected items to comparison list.', 'directories-pro' ),
			'default_settings' => array(
				'_label' => __( 'Compare', 'directories-pro' ),
				'_color' => 'outline-secondary',
				'_icon'  => 'fas fa-arrow-right-arrow-left',
			),
			'labellable'       => false,
			'iconable'         => false,
		);
	}

	public function displayButtonIsPreRenderable( Bundle $bundle, array $settings ) {
		// A Display's Button element can reference this button independently
		// of the bundle's own "Enable comparison" setting (e.g. carried over
		// from default display content authored for a different bundle type -
		// see ProductDirectoryType, which never sets comparison_enable) -
		// don't register the tray JS or render the button unless comparison
		// is actually turned on for this bundle.
		return ! empty( $bundle->info['comparison_enable'] );
	}

	public function displayButtonPreRender( Bundle $bundle, array $settings, array $entities = array() ) {
		if ( empty( self::$_jsAdded ) ) {
			$this->_application->getPlatform()
				->addJsFile( 'comparison.min.js', 'drts-comparison', array( 'drts' ), 'directories-pro', true );
		}
		if ( empty( self::$_jsAdded[ $bundle->name ] ) ) {
			$this->_application->getPlatform()
				->addJs(
					sprintf(
						'DRTS.Comparison.Tray.getInstance("%s", %s);',
						$bundle->name,
						$this->_application->System_Util_jsonEncode(
							array(
								'comparePageUrl'           => $this->_getComparePageUrl( $bundle ),
								'maxCompareItems'          => $bundle->info['comparison']['compare_max_items'] ?? 5,
								'maxItemsMessage'          => sprintf( __( 'You can compare up to %s items.', 'directories-pro' ), '{max}' ),
								'trayTitle'                => $bundle->getLabel( 'compare' ),
								'clearAllLabel'            => __( 'Clear All', 'directories-pro' ),
								'compareButtonLabel'       => __( 'Compare', 'directories-pro' ),
								'emptyListMessage'         => __( 'Please select items to compare.', 'directories-pro' ),
								'removeItemConfirmMessage' => __( 'This item already exists in the comparison list. Do you want to remove it?', 'directories-pro' ),
								'compareOpenNewTab'        => ! empty( $bundle->info['comparison']['compare_open_newtab'] ),
							)
						)
					)
				);
			self::$_jsAdded[ $bundle->name ] = true;
		}
	}

	/**
	 * The dedicated /compare route (registered by ComparisonComponent::
	 * systemMainRoutes()) only has a real, navigable URL when $bundle->getPath()
	 * resolves to an actual page - true for a Sabai-native, pageable content
	 * type, but not for one that adopted another plugin's post type with no
	 * page of its own (e.g. ProductDirectoryType's 'pageable' => false).
	 * For that case the page assigned under Page Settings - which embeds the
	 * [<prefix>-directory-compare] shortcode, rendering that exact same route
	 * internally regardless of pageable - is used instead. See
	 * ComparisonComponent::onSystemSlugsFilter().
	 */
	protected function _getComparePageUrl( Bundle $bundle ) {
		$platform = $this->_application->getPlatform();
		if ( $slug = $platform->hasSlug( 'Comparison', ComparisonComponent::slugName( $bundle ) ) ) {
			return (string) $this->_application->Url( '/' . $slug );
		}

		return (string) $this->_application->Url( $bundle->getPath( false ) . '/compare' );
	}

	public function displayButtonLink( Bundle $bundle, IEntity $entity, array $settings, $displayName ) {
		// ButtonsHelper::renderButtons() (the per-entity rendering path used
		// by ButtonElement) calls this directly and does NOT consult
		// displayButtonIsPreRenderable() first, so the same guard is needed
		// here too - otherwise the link markup alone would still render (with
		// no tray JS behind it) even with comparison disabled.
		if ( empty( $bundle->info['comparison_enable'] ) ) {
			return;
		}

		return $this->_application->LinkTo(
			$settings['_label'],
			'#',
			array( 'icon' => $settings['_icon'] ),
			array(
				'class'              => $settings['_class'],
				'style'              => $settings['_style'],
				'data-compare-id'    => $entity->getId(),
				'data-compare-title' => $entity->getTitle(),
				'data-compare-thumb' => $this->_application->Entity_Image( $entity, 'thumbnail', null, true ),
				'data-compare-name'  => $bundle->name,
			)
		);
	}
}
