<?php
namespace SabaiApps\Directories\Component\Comparison\Controller;

use SabaiApps\Directories\Context;
use SabaiApps\Directories\Component\View\Controller\ViewEntities;

class CompareEntities extends ViewEntities {

	protected function _doExecute( Context $context ) {
		$context->settings = array(
			'mode'          => 'comparison',
			'view_settings' => $context->bundle->info['comparison'],
		);
		parent::_doExecute( $context );
	}
}
