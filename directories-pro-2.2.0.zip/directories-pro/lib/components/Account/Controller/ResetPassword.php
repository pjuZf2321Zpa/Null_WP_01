<?php
namespace SabaiApps\Directories\Component\Account\Controller;

use SabaiApps\Directories\Context;
use SabaiApps\Directories\Component\Form;

class ResetPassword extends Form\Controller {

	protected function _doGetFormSettings( Context $context, array &$storage ) {
		$this->_submitButtons[] = array(
			'#btn_label' => __( 'Reset Password', 'directories-pro' ),
			'#btn_color' => 'primary',
		);

		return array(
			'#header'          => array(
				array(
					'level'   => 'info',
					'message' => __( 'Enter your new password below.', 'directories-pro' ),
				),
			),
			'password'         => array(
				'#type'     => 'password',
				'#title'    => __( 'New Password', 'directories-pro' ),
				'#required' => true,
			),
			'password_confirm' => array(
				'#type'     => 'password',
				'#title'    => __( 'Confirm New Password', 'directories-pro' ),
				'#required' => true,
			),
			'key'              => array(
				'#type'          => 'hidden',
				'#default_value' => $context->getRequest()->asStr( 'key' ),
			),
			'id'               => array(
				'#type'          => 'hidden',
				'#default_value' => $context->identity->id,
			),
		);
	}

	public function submitForm( \SabaiApps\Directories\Component\Form\Form $form, Context $context ) {
		if ( $form->values['password'] !== $form->values['password_confirm'] ) {
			$form->setError( __( 'Passwords do not match.', 'directories-pro' ), 'password_confirm' );
			return;
		}

		// Delete cookie
		$this->System_Cookie( 'drts-frontendsubmit-reset-password', '', time() - 86400 );

		$this->getPlatform()->resetPassword( $form->values['password'], $form->values['key'], $context->identity );

		$context->setSuccess( '/' . $this->getComponent( 'Account' )->getSlug( 'login' ) )
			->addFlash( __( 'Your password has been reset successfully.', 'directories-pro' ), 'success', 60000 );
	}
}
