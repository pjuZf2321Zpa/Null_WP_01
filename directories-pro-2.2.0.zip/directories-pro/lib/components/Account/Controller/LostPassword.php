<?php
namespace SabaiApps\Directories\Component\Account\Controller;

use SabaiApps\Directories\Context;
use SabaiApps\Directories\Component\Form;

class LostPassword extends Form\Controller {

	protected function _doGetFormSettings( Context $context, array &$storage ) {
		$this->_cancelUrl       = '/' . $this->getComponent( 'Account' )->getSlug( 'login' );
		$this->_submitButtons[] = array(
			'#btn_label' => __( 'Get New Password', 'directories-pro' ),
			'#btn_color' => 'primary',
			'#btn_size'  => 'lg',
		);

		return array(
			'#header' => array(
				array(
					'level'   => 'info',
					'message' => __( 'Lost your password? Please enter your username or email address. You will receive a link to create a new password via email.', 'directories-pro' ),
				),
			),
			'user'    => array(
				'#type'     => 'textfield',
				'#title'    => __( 'Username or E-mail Address', 'directories-pro' ),
				'#required' => true,
			),
		);
	}

	public function submitForm( \SabaiApps\Directories\Component\Form\Form $form, Context $context ) {
		if ( empty( $form->values['user'] ) ) {
			$form->setError( __( 'Invalid username or e-mail address.', 'directories-pro' ), 'user' );
			return;
		}

		if ( strpos( $form->values['user'], '@' ) ) {
			$identity = $this->getPlatform()->getUserIdentityFetcher()->fetchByEmail( $form->values['user'] );
		} else {
			$identity = $this->getPlatform()->getUserIdentityFetcher()->fetchByUsername( $form->values['user'] );
		}
		if ( $identity->isAnonymous() ) {
			$form->setError( __( 'Invalid username or e-mail address.', 'directories-pro' ), 'user' );
			return;
		}

		$this->Account_LostPassword_sendEmail( $identity );

		$context->setSuccess( '/' . $this->getComponent( 'Account' )->getSlug( 'login' ) )
			->addFlash( __( 'Password reset email has been sent.', 'directories-pro' ), 'success', 60000 );
	}
}
