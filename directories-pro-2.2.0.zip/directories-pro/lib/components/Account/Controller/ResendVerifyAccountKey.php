<?php
namespace SabaiApps\Directories\Component\Account\Controller;

use SabaiApps\Directories\Context;
use SabaiApps\Directories\Controller;

class ResendVerifyAccountKey extends Controller {

	protected function _doExecute( Context $context ) {
		if ( ! $this->_checkToken( $context, 'frontendsubmit_resend_verify_account_key_' . $context->identity->id, true ) ) {
			return;
		}

		try {
			$this->Account_VerifyAccount_sendEmail( $context->identity );
			$context->addFlash( __( 'Please check your email address to verify your account.', 'directories-pro' ) )
				->setSuccess( '/' . $this->getComponent( 'Account' )->getSlug( 'login' ) );
		} catch ( Exception\IException $e ) {
			$context->setError( $e->getMessage() );
		}
	}
}
