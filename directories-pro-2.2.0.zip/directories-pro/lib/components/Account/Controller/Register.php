<?php
namespace SabaiApps\Directories\Component\Account\Controller;

class Register extends LoginOrRegister {

	protected $_template = 'account_register_form', $_isRegistrationPage = true;

	protected function _isShowLoginForm() {
		return false;
	}
}
