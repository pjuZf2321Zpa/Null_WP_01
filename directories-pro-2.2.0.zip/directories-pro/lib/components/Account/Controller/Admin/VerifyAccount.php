<?php
namespace SabaiApps\Directories\Component\Account\Controller\Admin;

use SabaiApps\Directories\Context;
use SabaiApps\Directories\Controller;
use SabaiApps\Directories\Exception;

class VerifyAccount extends Controller {

	protected function _doExecute( Context $context ) {
		if ( ! $this->_checkToken( $context, 'frontendsubmit_admin_verify_account', true ) ) {
			return;
		}

		if ( $this->Account_VerifyAccount_isRequired( $context->identity->id ) ) {
			try {
				$this->Account_VerifyAccount( $context->identity, true );
			} catch ( Exception\IException $e ) {
				$context->setError( $e->getMessage() );
				return;
			}
		}
		$context->addFlash( __( 'Account verified successfully.', 'directories-pro' ) )
			->setSuccess( false ); // false required to send success messages
	}
}
