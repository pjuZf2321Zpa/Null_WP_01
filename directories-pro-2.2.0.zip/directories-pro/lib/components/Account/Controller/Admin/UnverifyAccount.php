<?php
namespace SabaiApps\Directories\Component\Account\Controller\Admin;

use SabaiApps\Directories\Component\Form\Form;
use SabaiApps\Directories\Context;
use SabaiApps\Directories\Component\Form\Controller;
use SabaiApps\Directories\Exception;

class UnverifyAccount extends Controller {

	protected function _doGetFormSettings( Context $context, array &$storage ) {
		$this->_submitButtons         = null;
		$this->_ajaxOnSuccessRedirect = $this->_ajaxOnErrorRedirect = false;
		$this->_ajaxOnSuccess         = 'function (result, target, trigger) {
    target.find(".drts-modal-close").click();
    if (result.messages) DRTS.flash(result.messages, "success");
    $(DRTS).trigger("drts_frontendsubmit_unverify_account", {
        id: ' . $context->identity->id . ',
        title: result.title
    });
}';
		$has_key                      = $this->Account_VerifyAccount_hasKey( $context->identity );
		$has_valid_key                = $has_key && $has_key[1] > time();
		$form                         = array(
			'send_key' => array(
				'#type'          => 'checkbox',
				'#title'         => __( 'Send verification e-mail', 'directories-pro' ),
				'#default_value' => ! $has_valid_key,
				'#horizontal'    => true,
				'#weight'        => 2,
			),
			'id'       => array(
				'#type'          => 'hidden',
				'#default_value' => $context->identity->id,
			),
		);
		if ( $has_key ) {
			if ( empty( $has_key[2] ) ) {
				$time = 'N/A';
			} else {
				$time = $this->System_Date_datetime( $has_key[2] );
				if ( $has_valid_key ) {
					$time = sprintf( __( '%1$s (expires at %2$s)', 'directories-pro' ), $time, $this->System_Date_datetime( $has_key[1] ) );
				} else {
					$time = sprintf( __( '%s (expired)', 'directories-pro' ), $time );
				}
			}
			$form['#header'][] = array(
				'level'   => 'info',
				'message' => sprintf( __( 'Verification e-mail was last sent at %s.', 'directories-pro' ), $time ),
			);
		}

		return $form;
	}

	public function submitForm( Form $form, Context $context ) {
		try {
			$this->Account_VerifyAccount_unverify( $context->identity, false );
			$context->addFlash( __( 'Account unverified.', 'directories-pro' ) );
		} catch ( Exception\IException $e ) {
			$context->setError( $e->getMessage() );
			return;
		}
		if ( ! empty( $form->values['send_key'] ) ) {
			try {
				$this->Account_VerifyAccount_sendEmail( $context->identity );
				$context->addFlash( __( 'Verification e-mail sent successfully.', 'directories-pro' ) );
				$key_sent = true;
			} catch ( Exception\IException $e ) {
				$context->addFlash( $e->getMessage(), 'danger' );
			}
		}
		$context->setSuccess(
			false, // false required to send success messages
			array(
				'title' => sprintf(
					__( 'Account unverified since %1$s, verification e-mail last sent at %2$s', 'directories-pro' ),
					$this->System_Date( time() ),
					empty( $key_sent ) ? 'N/A' : $this->System_Date_datetime( time() )
				),
			)
		);
	}
}
