<?php
namespace SabaiApps\Directories\Component\Account\Controller\Admin;

use SabaiApps\Directories\Context;
use SabaiApps\Directories\Controller;
use SabaiApps\Directories\Exception;

class ResendVerifyAccountKey extends Controller {

	protected function _doExecute( Context $context ) {
		if ( ! $this->_checkToken( $context, 'frontendsubmit_admin_resend_verify_account_key', true )
			|| ( ! $unverified_at = $this->Account_VerifyAccount_isRequired( $context->identity->id ) )
		) {
			$context->setError();
			return;
		}
		try {
			$this->Account_VerifyAccount_sendEmail( $context->identity );
			$context->addFlash( __( 'Verification e-mail sent successfully.', 'directories-pro' ) )
				->setSuccess(
					false, // false required to send success messages
					array(
						'title' => sprintf(
							__( 'Account unverified since %1$s, verification e-mail last sent at %2$s', 'directories-pro' ),
							$this->System_Date( $unverified_at ),
							$this->System_Date_datetime( time() )
						),
					)
				);
		} catch ( Exception\IException $e ) {
			$context->setError( $e->getMessage() );
		}
	}
}
