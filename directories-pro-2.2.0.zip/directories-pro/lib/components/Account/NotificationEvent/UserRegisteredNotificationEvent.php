<?php
namespace SabaiApps\Directories\Component\Account\NotificationEvent;

use SabaiApps\Directories\Exception;
use SabaiApps\Framework\User\RegisteredIdentity;
use SabaiApps\Directories\Component\Notification\Event\AbstractEvent;

class UserRegisteredNotificationEvent extends AbstractEvent {

	protected $_isForAdmin = true;

	protected function _notificationEventInfo() {
		return array(
			'label'            => __( 'New user has registered', 'directories-pro' ),
			'global'           => true,
			'default_settings' => array(),
			'actions'          => array(
				'frontendsubmit_register',
			),
			'weight'           => 18,
			'testable'         => true,
		);
	}

	public function notificationEventIsEnabled() {
		return (bool) $this->_application->getComponent( 'Account' )->getConfig( 'register', 'form' );
	}

	public function notificationEventMessageMeta( array $settings ) {
		return array(
			'tags' => $this->_getUserTags(),
		);
	}

	public function notificationEventMessages( array $settings, array $params ) {
		if ( ! isset( $params[0] )
			|| ! $params[0] instanceof RegisteredIdentity
		) {
			throw new Exception\RuntimeException( 'Invalid identity.' );
		}

		$message = array(
			'tags' => $this->_getUserTags( $params[0] ),
		);

		return array( $message );
	}

	protected function _getDefaultNotificationLabel() {
		return __( 'New user has registered', 'directories-pro' );
	}

	protected function _getDefaultNotificationBody() {
		return array(
			__( 'A new user has registered on your site.', 'directories-pro' ),
			'%user_username%' . PHP_EOL . '%user_email%',
		);
	}

	public function notificationEventParamSettingsForm( array $settings, array $parents = array() ) {
		return array(
			'user' => array(
				'#title'      => __( 'Select user', 'directories-pro' ),
				'#type'       => 'user',
				'#horizontal' => true,
			),
		);
	}

	public function notificationEventParams( array $settings, array $paramSettings ) {
		if ( ! $identity = $this->_application->UserIdentity( $paramSettings['user'] ) ) {
			throw new Exception\RuntimeException( 'Failed fetching user by user ID: ' . $paramSettings['user'] );
		}
		return array( 0 => $identity );
	}
}
