<?php
namespace SabaiApps\Directories\Component\Account;

use SabaiApps\Directories\Component\AbstractComponent;
use SabaiApps\Directories\Component\System;
use SabaiApps\Directories\Component\System\Model\Component;
use SabaiApps\Directories\Context;
use SabaiApps\Directories\Application;
use SabaiApps\Directories\Response;

/**
 * Frontend user login, registration, lost-password and e-mail account
 * verification. Split out of FrontendSubmit so a directory plugin that does not
 * offer frontend content submission can still provide a custom login /
 * registration experience.
 *
 * Config keys `login` and `register` live here (migrated from the FrontendSubmit
 * component config on install - see onSystemComponentInstalled()). Entity-meta
 * keys, action hooks, tokens and the `/_x/frontendsubmit/*` admin ajax paths
 * keep their historical `frontendsubmit_` names for backward compatibility.
 */
class AccountComponent extends AbstractComponent implements
	System\IMainRouter,
	System\IAdminRouter,
	System\ISlugs,
	System\IScheduledActions {

	const VERSION = '2.2.0', PACKAGE = 'directories-pro';

	const REGISTER_FORM_FIELD_WEIGHT_USER_NAME    = 1, REGISTER_FORM_FIELD_WEIGHT_EMAIL = 5, REGISTER_FORM_FIELD_WEIGHT_PASSWORD = 90,
		REGISTER_FORM_FIELD_WEIGHT_PRIVACY_POLICY = 96, REGISTER_FORM_FIELD_WEIGHT_SUBMIT = 99;

	public static function description() {
		return 'Frontend user login, registration and account verification.';
	}

	public static function interfaces() {
		return array(
			'Notification\IEvents',
		);
	}

	public function systemMainRoutes( $lang = null ) {
		$routes = array();
		if ( $this->hasSlug( 'login', $lang ) ) {
			$login_slug                                      = $this->getSlug( 'login', $lang );
			$routes[ '/' . $login_slug ]                     = array(
				'controller'      => 'LoginOrRegister',
				'access_callback' => true,
				'callback_path'   => 'login',
				'title_callback'  => true,
			);
			$routes[ '/' . $login_slug . '/register' ]       = array(
				'controller'      => 'Register',
				'callback_path'   => 'register',
				'title_callback'  => true,
				'access_callback' => true,
			);
			$routes[ '/' . $login_slug . '/lost_password' ]  = array(
				'controller'     => 'LostPassword',
				'callback_path'  => 'lost_password',
				'title_callback' => true,
			);
			$routes[ '/' . $login_slug . '/reset_password' ] = array(
				'controller'      => 'ResetPassword',
				'access_callback' => true,
				'callback_path'   => 'reset_password',
				'title_callback'  => true,
			);
			$routes[ '/' . $login_slug . '/verify_account' ] = array(
				'controller'      => 'VerifyAccount',
				'access_callback' => true,
				'callback_path'   => 'verify_account',
			);
			$routes[ '/' . $login_slug . '/resend_verify_account_key' ] = array(
				'controller'      => 'ResendVerifyAccountKey',
				'access_callback' => true,
				'callback_path'   => 'resend_verify_account_key',
			);
		}

		return $routes;
	}

	public function systemOnAccessMainRoute( Context $context, $path, $accessType, array &$route ) {
		switch ( $path ) {
			case 'login':
				if ( ! $this->_application->getUser()->isAnonymous() ) {
					// Redirect to frontend dashboard if enabled
					if ( $this->_application->isComponentLoaded( 'Dashboard' )
						&& ( $dashboard_slug = $this->_application->getComponent( 'Dashboard' )->getSlug( 'dashboard' ) )
					) {
						$context->setRedirect( '/' . $dashboard_slug );
					}
					return false;
				}
				return true;
			case 'verify_account':
			case 'resend_verify_account_key':
				if ( $accessType === Application::ROUTE_ACCESS_LINK ) {
					if ( ! $this->getConfig( 'register', 'verify_email' )
						|| ! $this->_application->getUser()->isAnonymous()
						|| ( ! $id = $context->getRequest()->asInt( 'id' ) )
						|| ( ! $identity = $this->_application->getPlatform()->getUserIdentityFetcher()->fetchById( $id ) )
						|| ! $this->_application->Account_VerifyAccount_isRequired( $identity->id )
					) {
						return false;
					}

					if ( $path === 'verify_account' ) {
						if ( ! $key = $context->getRequest()->asStr( 'key' ) ) {
							return false;
						}
						$context->key = $key;
					}
					$context->identity = $identity;
				}
				return true;
			case 'reset_password':
				if ( $accessType === Application::ROUTE_ACCESS_LINK ) {
					if ( ! $this->_application->getUser()->isAnonymous() ) {
						if ( $this->_application->isComponentLoaded( 'Dashboard' )
							&& ( $dashboard_slug = $this->_application->getComponent( 'Dashboard' )->getSlug( 'dashboard' ) )
						) {
							$context->setRedirect( '/' . $dashboard_slug );
						}
						return false;
					}

					if ( ! $cookie = $this->_application->System_Cookie( 'drts-frontendsubmit-reset-password' ) ) {
						// No cookie, so set a cookie and redirect if valid id/key

						if ( ( ! $key = $context->getRequest()->asStr( 'key' ) )
							|| ( ! $id = $context->getRequest()->asInt( 'id' ) )
							|| ( ! $identity = $this->_application->getPlatform()->getUserIdentityFetcher()->fetchById( $id ) )
						) {
							return false;
						}

						try {
							if ( ! $this->_application->getPlatform()->checkResetPasswordKey( $key, $identity ) ) {
								return false;
							}
						} catch ( \Exception $e ) {
							$this->_application->logError( $e );
							return false;
						}

						if ( ! headers_sent() ) {
							$this->_application->System_Cookie( 'drts-frontendsubmit-reset-password', sprintf( '%d:%s', $id, $key ) );
							$context->setRedirect( $route['path'] );
							return false;
						}
					}
					if ( ! isset( $key )
						|| ! isset( $identity )
					) {
						if ( ( ! $parts = explode( ':', $cookie ) )
							|| count( $parts ) !== 2
							|| ( ! $id = intval( $parts[0] ) )
							|| ( ! $key = $parts[1] )
							|| ( ! $identity = $this->_application->getPlatform()->getUserIdentityFetcher()->fetchById( $id ) )
						) {
							return false;
						}
					}

					try {
						if ( ! $this->_application->getPlatform()->checkResetPasswordKey( $key, $identity ) ) {
							return false;
						}
					} catch ( \Exception $e ) {
						$this->_application->logError( $e );
						return false;
					}
					$context->identity = $identity;
				}
				return true;
			case 'register':
				return $this->getConfig( 'register', 'show_separate_page' );
		}
	}

	public function systemMainRouteTitle( Context $context, $path, $titleType, array $route ) {
		switch ( $path ) {
			case 'login':
				return $this->getTitle( 'login' );
			case 'register':
				return __( 'Register', 'directories-pro' );
			case 'lost_password':
				return __( 'Lost your password?', 'directories-pro' );
			case 'reset_password':
				return __( 'Reset Password', 'directories-pro' );
		}
	}

	public function systemAdminRoutes() {
		return array(
			'/_drts/frontendsubmit/verify_account'   => array(
				'controller'      => 'VerifyAccount',
				'access_callback' => true,
				'callback_path'   => 'verify_account',
			),
			'/_drts/frontendsubmit/unverify_account' => array(
				'controller'      => 'UnverifyAccount',
				'access_callback' => true,
				'callback_path'   => 'unverify_account',
			),
			'/_drts/frontendsubmit/resend_verify_account_key' => array(
				'controller'      => 'ResendVerifyAccountKey',
				'access_callback' => true,
				'callback_path'   => 'resend_verify_account_key',
			),
		);
	}

	public function systemOnAccessAdminRoute( Context $context, $path, $accessType, array &$route ) {
		switch ( $path ) {
			case 'verify_account':
			case 'unverify_account':
			case 'resend_verify_account_key':
				if ( $accessType === Application::ROUTE_ACCESS_LINK ) {
					if ( ! $this->getConfig( 'register', 'verify_email' )
						|| ( ! $id = $context->getRequest()->asInt( 'id' ) )
						|| ( ! $identity = $this->_application->getPlatform()->getUserIdentityFetcher()->fetchById( $id ) )
					) {
						return false;
					}

					$context->identity = $identity;
				}
				return true;
		}
	}

	public function systemAdminRouteTitle( Context $context, $path, $title, array $route ) {}

	public function systemSlugs() {
		return array(
			'login' => array(
				'admin_title'  => __( 'Login/Registration', 'directories-pro' ),
				'title'        => __( 'Login or Register', 'directories-pro' ),
				'wp_shortcode' => 'drts-frontend-login',
				'required'     => false,
				'auto_create'  => false,
			),
		);
	}

	public function isLoginDisabled() {
		return $this->_application->Filter( 'frontendsubmit_login_disable', false )
			|| ( defined( 'DRTS_FRONTENDSUBMIT_LOGIN_DISABLE' ) && DRTS_FRONTENDSUBMIT_LOGIN_DISABLE );
	}

	public function onCoreLoginUrlFilter( &$url, $redirect ) {
		if ( $this->isLoginFormEnabled()
			&& ( $login_slug = $this->hasCustomLoginRegistrationPage() )
		) {
			$url = (string) $this->_application->Url( '/' . $login_slug, array( 'redirect_to' => $redirect ) );
		}
	}

	public function hasCustomLoginRegistrationPage() {
		return ! $this->isLoginDisabled() && ( $slug = $this->hasSlug( 'login' ) ) ? $slug : false;
	}

	public function isLoginFormEnabled() {
		if ( $this->_application->getPlatform()->isLoginFormRequired() ) {
			return true;
		}

		return ! empty( $this->_config['login']['form'] )
			|| ( ! isset( $this->_config['login']['form'] ) && ! empty( $this->_config['login']['login_form'] ) ); // for compat with <=1.2.42
	}

	public function showLostPasswordLink() {
		return ! isset( $this->_config['login']['lost_pass_link'] ) || $this->_config['login']['lost_pass_link'];
	}

	public function isRegisterFormEnabled() {
		if ( $this->_application->getPlatform()->isRegisterFormRequired() ) {
			return true;
		}

		return ! empty( $this->_config['register']['form'] )
			|| ( ! isset( $this->_config['register']['form'] ) && ! empty( $this->_config['login']['register_form'] ) ); // for compat with <=1.2.42
	}

	public function onWordPressDoShortcodeFilter( &$ret, $shortcode, $component ) {
		if ( $shortcode !== 'drts-frontend-login' ) {
			return;
		}

		if ( ! $login_slug = $this->hasCustomLoginRegistrationPage() ) {
			return;
		}

		$path          = '/' . $login_slug;
		$url           = (string) $this->_application->Url( $path );
		$url_requested = (string) \SabaiApps\Directories\Request::url( false );
		if ( strpos( $url_requested, $url ) === 0
			&& ( $_path = substr( $url_requested, strlen( $url ) ) )
			&& ( $_path = trim( $_path, '/' ) )
		) {
			$ret['path'] = array(
				'path'   => $path . '/' . $_path, // additional path
				'params' => empty( $_REQUEST ) ? array() : $_REQUEST,
			);
		}
	}

	public function onCorePlatformWordPressAdminInit() {
		// Self-heal a login/registration config that never made it across from
		// FrontendSubmit (e.g. the install-time migration ran on an early build
		// where it fataled, or was never dispatched). No-op once adopted.
		$this->_adoptFromFrontendSubmit();

		if ( isset( $GLOBALS['pagenow'] )
			&& $GLOBALS['pagenow'] === 'users.php'
			&& $this->getConfig( 'register', 'verify_email' )
			&& current_user_can( 'edit_users' )
		) {
			$this->_application->Account_VerifyAccount_wordPressUsersColumn();
		}
	}

	public function systemScheduledActions() {
		if ( ! $this->getConfig( 'register', 'verify_email' ) ) {
			return array();
		}

		return array(
			'frontendsubmit_delete_unverified_accounts' => array(
				'title'       => __( 'Delete Unverified Accounts', 'directories-pro' ),
				'description' => __( 'Deletes user accounts that have not been verified within the specified time period.', 'directories-pro' ),
				'recurrence'  => 'monthly',
				'args'        => array(),
				'priority'    => 10,
			),
		);
	}

	public function onFrontendSubmitDeleteUnverifiedAccounts() {
		if ( ! $this->getConfig( 'register', 'verify_email' )
			|| ! $this->getConfig( 'register', 'verify_email_settings', 'delete' )
			|| ( ! $days = $this->getConfig( 'register', 'verify_email_settings', 'delete_after' ) )
		) {
			return;
		}

		$this->_application->callHelper( 'Account_VerifyAccount_deleteUnverified', array( $days ) );
	}

	public function notificationGetEventNames() {
		return array( 'account_user_registered' );
	}

	public function notificationGetEvent( $name ) {
		switch ( $name ) {
			case 'account_user_registered':
				return new NotificationEvent\UserRegisteredNotificationEvent( $this->_application, $name );
		}
	}

	public function onCoreResponseSendViewAccount( Context $context, Response $response ) {
		if ( in_array( $context->getRoute()->getControllerName(), array( 'LoginOrRegister', 'Register', 'LostPassword', 'ResetPassword' ) ) ) {
			Response::sendNoCacheHeaders();
		}
	}

	public function onViewFeatureSettingsFormFilter( &$form, $bundle, $settings, $submitValues ) {
		if ( $bundle->entitytype_name !== 'user'
			|| ! $this->getConfig( 'register', 'form' )
			|| ! $this->getConfig( 'register', 'verify_email' )
		) {
			return;
		}

		$form['query']['frontendsubmit_verified_account_only'] = array(
			'#type'          => 'checkbox',
			'#title'         => __( 'Show verified accounts only', 'directories-pro' ),
			'#default_value' => ! empty( $settings['query']['frontendsubmit_verified_account_only'] ),
			'#horizontal'    => true,
			'#weight'        => 30,
		);
	}

	public function onViewQueryFilter( $query, $bundle, $mode, $name, $settings, $isDefault ) {
		if ( $this->_application->getPlatform()->getName() !== 'WordPress' ) {
			return;
		}

		if ( $bundle->entitytype_name === 'user'
			&& $this->getConfig( 'register', 'form' )
			&& $this->getConfig( 'register', 'verify_email' )
			&& ! empty( $settings['query']['frontendsubmit_verified_account_only'] )
		) {
			$db          = $this->_application->getDB();
			$db_prefix   = $db->getConnection()->getWpdb()->prefix;
			$meta_key    = $db_prefix . 'drts_frontendsubmit_verify_account_required';
			$table_alias = 'wp_usermeta';
			$tables      = array(
				$db_prefix . 'usermeta' => array(
					'alias' => $table_alias,
					'on'    => $bundle->entitytype_name . '_id = %3$s AND %1$s.meta_key = ' . $db->escapeString( $meta_key ),
				),
			);
			$column      = array(
				'tables'      => $tables,
				'column'      => $table_alias . '.meta_value',
				'column_type' => Application::COLUMN_TEXT,
			);
			$query->addCriteria( new \SabaiApps\Framework\Criteria\IsNullCriteria( $column ) );
		}
	}

	public function onSystemAdminSettingsFormFilter( &$form ) {
		$form['tabs'][ $this->_name ]   = array(
			'#title'  => __( 'Login/Registration', 'directories-pro' ),
			'#weight' => 15,
		);
		$form['fields'][ $this->_name ] = array(
			'#component' => $this->_name,
			'#tab'       => $this->_name,
		) + $this->_application->Account_SettingsForm( $this->_config, array( $this->_name ) );
	}

	public function onDirectoryAdminSettingsFormFilter( &$form ) {
		$this->onSystemAdminSettingsFormFilter( $form );
	}

	// --- migration from the FrontendSubmit component -------------------------

	public function onSystemComponentInstalled( Component $componentEntity ) {
		if ( $componentEntity->name !== $this->_name ) {
			return;
		}

		$this->_adoptFromFrontendSubmit();
	}

	/**
	 * Adopts the login/registration config (and renames the user-registered
	 * notification event) that used to live under the FrontendSubmit component
	 * before Account was split out of it.
	 *
	 * Idempotent: a platform option records that it has run, so it is safe to
	 * call on every admin init as a self-heal for sites whose install-time
	 * migration never completed. The flag lives outside the component config so
	 * a later settings save cannot drop it.
	 */
	private function _adoptFromFrontendSubmit() {
		if ( ! $this->_application->isComponentLoaded( $this->_name )
			|| $this->_application->getPlatform()->getOption( 'account_frontendsubmit_migrated' )
		) {
			return;
		}

		try {
			$fs        = $this->_application->getModel( 'Component', 'System' )->fetchById( 'FrontendSubmit' );
			$fs_config = $fs ? (array) $fs->config : array();

			$config = array();
			foreach ( array( 'login', 'register' ) as $key ) {
				$fs_val  = isset( $fs_config[ $key ] ) && is_array( $fs_config[ $key ] ) ? $fs_config[ $key ] : array();
				$cur_val = isset( $this->_config[ $key ] ) && is_array( $this->_config[ $key ] ) ? $this->_config[ $key ] : array();
				// FrontendSubmit's values are the base; anything already set on
				// Account (e.g. edited post-migration) wins.
				if ( $merged = array_replace_recursive( $fs_val, $cur_val ) ) {
					$config[ $key ] = $merged;
				}
			}
			if ( $config ) {
				// merge = true: only touch the keys we pass, leave the rest of
				// the component config alone.
				$this->_application->System_Component_saveConfig( $this->_name, $config, true );
				$this->_config = array_replace_recursive( $this->_config, $config );
			}
			$this->_application->getPlatform()->setOption( 'account_frontendsubmit_migrated', 1 );
		} catch ( \Throwable $e ) {
			$this->_application->logError( $e );
			return;
		}

		// Rename the user-registered notification event on existing notifications.
		if ( $this->_application->isComponentLoaded( 'Notification' ) ) {
			try {
				foreach ( $this->_application->getModel( 'Notification', 'Notification' )->fetch() as $notification ) {
					if ( $notification->event === 'frontendsubmit_user_registered' ) {
						$notification->event = 'account_user_registered';
						$notification->commit();
					}
				}
			} catch ( \Throwable $e ) {
				$this->_application->logError( $e );
			}
		}
	}
}
