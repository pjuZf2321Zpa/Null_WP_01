<?php
namespace SabaiApps\Directories\Component\Claiming\CSVExporter;

use SabaiApps\Directories\Component\CSV\Exporter\AbstractExporter;
use SabaiApps\Directories\Component\Entity\Model\Field;

class ClaimingCSVExporter extends AbstractExporter {

	public function csvExporterDoExport( Field $field, array $settings, $value, array $columns, array &$formStorage, array &$logs ) {
		switch ( $this->_name ) {
			case 'claiming_status':
				return $value[0];
		}
	}
}
