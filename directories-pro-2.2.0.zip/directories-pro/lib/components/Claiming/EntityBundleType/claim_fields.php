<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
return array(
	'claiming_status' =>
	array(
		'type'     => 'claiming_status',
		'settings' =>
		array(),
		'realm'    => 2,
		'data'     =>
		array(
			'label'           => __( 'Claim Status', 'directories-pro' ),
			'description'     => '',
			'default_value'   => null,
			'required'        => false,
			'disabled'        => false,
			'weight'          => 0,
			'max_num_items'   => 1,
			'widget'          => 'claiming_status',
			'widget_settings' =>
			array(),
		),
	),
);
