<?php
namespace SabaiApps\Directories\Component\Claiming\NotificationEvent;

use SabaiApps\Directories\Application;
use SabaiApps\Directories\Component\Entity\Model\Bundle;
use SabaiApps\Directories\Component\Entity\Type\IEntity;
use SabaiApps\Directories\Exception;
use SabaiApps\Directories\Component\Notification\Event\AbstractEntityEvent;

abstract class AbstractClaimNotificationEvent extends AbstractEntityEvent {

	public function __construct( Application $application, $name ) {
		parent::__construct( $application, $name, 'claiming_claim' );
	}

	public function notificationEventMessages( array $settings, array $params ) {
		if ( ! isset( $params[0] )
			|| ! $params[0] instanceof IEntity
		) {
			throw new Exception\RuntimeException( 'Invalid entity.' );
		}

		if ( ! $this->_isBundleEnabled( $params[0], $settings ) ) {
			return;
		}

		return array( array( 'entity' => $params[0] ) );
	}

	protected function _isEventBundle( Bundle $bundle ) {
		return true;
	}
}
