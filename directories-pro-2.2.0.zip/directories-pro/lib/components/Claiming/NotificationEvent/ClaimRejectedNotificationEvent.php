<?php
namespace SabaiApps\Directories\Component\Claiming\NotificationEvent;

class ClaimRejectedNotificationEvent extends AbstractClaimNotificationEvent {

	protected function _notificationEntityEventInfo() {
		return array(
			'label'            => __( 'Claim rejected', 'directories-pro' ),
			'default_settings' => array(),
			'actions'          => array(
				'claiming_claim_rejected',
			),
			'weight'           => 72,
			'testable'         => true,
		);
	}

	protected function _getDefaultNotificationLabel() {
		return __( 'Claim rejected', 'directories-pro' );
	}

	protected function _getDefaultNotificationBody() {
		return array(
			__( 'Your claim submitted for the following item was rejected.', 'directories-pro' ),
			'%parent_title%' . PHP_EOL . '%parent_permalink_url%',
		);
	}
}
