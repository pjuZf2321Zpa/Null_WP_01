<?php
namespace SabaiApps\Directories\Component\Claiming\NotificationEvent;

class ClaimApprovedNotificationEvent extends AbstractClaimNotificationEvent {

	protected function _notificationEntityEventInfo() {
		return array(
			'label'            => __( 'Claim approved', 'directories-pro' ),
			'default_settings' => array(),
			'actions'          => array(
				'claiming_claim_approved',
			),
			'weight'           => 71,
			'testable'         => true,
		);
	}

	protected function _getDefaultNotificationLabel() {
		return __( 'Claim approved', 'directories-pro' );
	}

	protected function _getDefaultNotificationBody() {
		return array(
			__( 'Your claim submitted for the following item has been approved.', 'directories-pro' ),
			'%parent_title%' . PHP_EOL . '%parent_permalink_url%',
		);
	}
}
