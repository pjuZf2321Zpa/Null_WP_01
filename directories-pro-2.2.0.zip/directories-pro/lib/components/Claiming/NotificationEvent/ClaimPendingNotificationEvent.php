<?php
namespace SabaiApps\Directories\Component\Claiming\NotificationEvent;

class ClaimPendingNotificationEvent extends AbstractClaimNotificationEvent {

	protected $_isForAdmin = true;

	protected function _notificationEntityEventInfo() {
		return array(
			'label'            => __( 'Claim pending review', 'directories-pro' ),
			'default_settings' => array(),
			'actions'          => array(
				'claiming_claim_pending',
			),
			'weight'           => 70,
			'testable'         => true,
		);
	}

	protected function _getDefaultNotificationLabel() {
		return sprintf( __( 'A new %1$s has been submitted', 'directories-pro' ), strtolower( $singular = $this->_getContentTypeLabel() ), $singular );
	}

	protected function _getDefaultNotificationBody() {
		return array(
			__( 'A new claim has been submitted for the following item.', 'directories-pro' ),
			'%parent_title%' . PHP_EOL . '%parent_permalink_url%',
			__( 'You can approve or reject the claim from the following page.', 'directories-pro' ) . PHP_EOL . '%admin_permalink_url%',
		);
	}
}
