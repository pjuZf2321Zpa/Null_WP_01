<?php
namespace SabaiApps\Directories\Component\Claiming\DisplayLabel;

use SabaiApps\Directories\Component\Entity\Model\Bundle;
use SabaiApps\Directories\Component\Entity\Type\IEntity;
use SabaiApps\Directories\Component\Display;

class ClaimedEntityDisplayLabel extends Display\Label\AbstractLabel {

	protected function _displayLabelInfo( Bundle $bundle ) {
		if ( empty( $bundle->info['claiming_enable'] ) ) {
			return false;
		}

		return array(
			'label'            => __( 'Claimed content label', 'directories-pro' ),
			'default_settings' => array(
				'_label' => _x( 'Claimed', 'claimed label', 'directories-pro' ),
				'_color' => array( 'type' => 'info' ),
			),
		);
	}

	public function displayLabelText( Bundle $bundle, IEntity $entity, array $settings ) {
		if ( ! $entity->getAuthorId() ) {
			return;
		}

		return array(
			'label' => $settings['_label'],
			'color' => $settings['_color'],
		);
	}
}
