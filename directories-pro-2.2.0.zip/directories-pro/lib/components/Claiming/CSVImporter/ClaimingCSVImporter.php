<?php
namespace SabaiApps\Directories\Component\Claiming\CSVImporter;

use SabaiApps\Directories\Component\CSV\Importer\AbstractImporter;
use SabaiApps\Directories\Component\Entity\Model\Field;

class ClaimingCSVImporter extends AbstractImporter {

	public function csvImporterDoImport( Field $field, array $settings, $column, $value, &$formStorage, array &$logs ) {
		switch ( $this->_name ) {
			case 'claiming_status':
				return array( array( 'value' => $value ) );
		}
	}
}
