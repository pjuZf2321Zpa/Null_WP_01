<?php
namespace SabaiApps\Directories\Component\Claiming\DisplayButton;

use SabaiApps\Directories\Component\Entity;
use SabaiApps\Directories\Component\Display;

class ClaimEntityDisplayButton extends Display\Button\AbstractButton {

	protected function _displayButtonInfo( Entity\Model\Bundle $bundle ) {
		return array(
			'label'            => __( 'Claim listing button', 'directories-pro' ),
			'default_settings' => array(
				'_color' => 'outline-warning',
			),
			'labellable'       => false,
			'iconable'         => false,
		);
	}

	public function displayButtonSettingsForm( Entity\Model\Bundle $bundle, array $settings, $displayName, array $parents = array() ) {
		return array(
			'modal' => array(
				'#type'          => 'checkbox',
				'#title'         => __( 'Show form in modal window', 'directories-pro' ),
				'#default_value' => $settings['modal'],
				'#horizontal'    => true,
			),
		);
	}

	public function displayButtonLink( Entity\Model\Bundle $bundle, Entity\Type\IEntity $entity, array $settings, $displayName ) {
		if ( ! $claim_bundle = $this->_application->Entity_Bundle( 'claiming_claim', $bundle->group ) ) {
			return;
		}

		if ( $this->_application->Entity_IsRoutable( $claim_bundle, 'add', $entity ) ) {
			if ( ! empty( $settings['modal'] ) ) {
				$this->_application->Entity_Form_loadAssets( $claim_bundle );
			}
			$add_entity_route = '/' . $this->_application->FrontendSubmit_AddEntitySlug( $claim_bundle );
			return $this->_application->LinkTo(
				$claim_bundle->getLabel( 'add' ),
				$this->_application->Url( $add_entity_route, array( 'entity_id' => $entity->getId() ) ),
				array(
					'icon'      => $this->_application->Entity_BundleTypeInfo( $claim_bundle, 'icon' ),
					'btn'       => true,
					'container' => empty( $settings['modal'] ) ? null : 'modal',
					'modalSize' => 'lg',
					'route'     => $add_entity_route,
				),
				array(
					'class' => $settings['_class'],
					'style' => $settings['_style'],
				)
			);
		}

		if ( $this->_application->getUser()->isAnonymous() ) {
			// We can't use Entity_IsRoutable helper here since it will always return false if guest

			// Allow other components to filter result
			$result = $this->_application->Filter(
				'claiming_is_entity_claimable',
				$entity->getAuthorId() ? false : true,
				array( $entity )
			);

			if ( ! $result ) {
				return;
			}

			return $this->_getLoginButton(
				$claim_bundle->getLabel( 'add' ),
				$this->_application->Url( '/' . $this->_application->FrontendSubmit_AddEntitySlug( $claim_bundle ), array( 'entity_id' => $entity->getId() ) ),
				array(
					'no_escape' => true,
					'icon'      => $this->_application->Entity_BundleTypeInfo( $claim_bundle, 'icon' ),
					'btn'       => true,
				),
				array(
					'class' => $settings['_class'],
					'style' => $settings['_style'],
				)
			);
		}
	}
}
