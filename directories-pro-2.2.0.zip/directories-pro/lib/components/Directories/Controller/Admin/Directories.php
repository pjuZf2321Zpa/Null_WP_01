<?php
namespace SabaiApps\Directories\Component\Directories\Controller\Admin;

use SabaiApps\Directories\Context;
use SabaiApps\Directories\Component\Form;
use SabaiApps\Directories\Component\Directory\Model\Directory;

class Directories extends Form\Controller {

	protected function _doGetFormSettings( Context $context, array &$storage ) {
		// Load scripts for add directory modal form
		$this->Form_Scripts( array( 'iconpicker', 'latinise', 'file', 'select' ) );
		$this->getPlatform()->loadJqueryUiJs( array( 'effects-highlight' ) );

		$form = array(
			'#js_ready'   => 'var params = {}; params[DRTS.params.ajax] = "#drts-modal"; $.get("' . $this->Url( '/directories/add', array(), '', '&' ) . '", params, function (_data) {
                DRTS.cache("drts-directories-add-directory", _data);
            });',
			'directories' => array(
				'#type'           => 'tableselect',
				'#responsive'     => false, // prevent dropdown menus being hidden
				'#header'         => array(
					'name'  => __( 'Directory name', 'directories-pro' ),
					'type'  => __( 'Directory type', 'directories-pro' ),
					'date'  => _x( 'Created', 'date directory created', 'directories-pro' ),
					'links' => array(
						'label' => '',
						'order' => 99,
					),
				),
				'#disabled'       => true,
				'#multiple'       => true,
				'#js_select'      => true,
				'#options'        => array(),
				'#class'          => 'drts-data-table',
				'#row_attributes' => array(
					'@all' => array(
						'name'  => array(
							'style' => 'width:30%;',
						),
						'type'  => array(
							'style' => 'width:20%;',
						),
						'date'  => array(
							'style' => 'width:20%;',
						),
						'links' => array(
							'style' => 'white-space:nowrap;text-align:' . ( $this->getPlatform()->isRtl() ? 'left' : 'right' ) . ';',
						),
					),
				),
			),
		);

		$directory_types = array();
		foreach ( $this->getModel( 'Directory', 'Directory' )->fetch( 0, 0, array( 'directory_type', 'directory_name' ), array( 'ASC', 'ASC' ) ) as $directory ) {
			if ( ! $directory_type_impl = $this->Directory_Types_impl( $directory->type, true ) ) {
				continue;
			}
			if ( ! $this->HasPermission( 'directory_admin_directory_' . $directory->name ) ) {
				continue;
			}

			$icon_html = '';
			if ( $icon = $directory->getIcon() ) {
				$icon_html = '<i class="drts-icon ' . $this->H( $icon ) . '"></i> ';
			}
			// Only offer "Visit Directory" when the directory actually has a
			// URL - see Directory\Helper\UrlHelper. A type can customize the
			// label via directoryInfo('url_label') - see ProductDirectoryType,
			// which uses this for its opt-in "Visit Shop" link.
			$visit_link = ( $url = $this->Directory_Url( $directory ) ) ? $this->LinkTo(
				'',
				$url,
				array( 'icon' => 'fas fa-external-link-alt' ),
				array( 'title' => $directory_type_impl->directoryInfo( 'url_label' ) ?: __( 'Visit Directory', 'directories-pro' ) )
			) : '';
			$form['directories']['#options'][ $directory->name ] = array(
				'name'  => $icon_html . '<span><strong>' . $this->H( $directory->getLabel() ) . '</strong> <small>(' . $this->H( $directory->name ) . ')</small> ' . $visit_link . '</span>',
				'type'  => $this->H( $directory_type_impl->directoryInfo( 'label' ) ),
				'date'  => $this->System_Date( $directory->created ),
				'links' => $this->System_Button_links(
					$this->_getLinks( $directory ),
					array(
						'label'   => true,
						'right'   => true,
						'color'   => 'outline-secondary',
						'btn'     => false,
						'split'   => true,
						'tooltip' => true,
					)
				),
			);
			$directory_types[ $directory->type ]                 = $directory->type;
		}
		// Hide directory type column if only single type enabled
		if ( count( $directory_types ) === 1 ) {
			unset( $form['directories']['#header']['type'] );
			$form['directories']['#row_attributes']['@all']['name']['style'] = 'width:40%;';
			$form['directories']['#row_attributes']['@all']['date']['style'] = 'width:25%;';
		}

		return $form;
	}

	protected function _getLinks( Directory $directory ) {
		$links = array(
			'settings' => array(
				'link'   => array(
					$this->LinkTo(
						'',
						'/directories/' . $directory->name,
						array( 'icon' => 'fas fa-cog' ),
						array(
							'title' => __( 'Settings', 'directories-pro' ),
							'rel'   => 'sabaitooltip',
						)
					),
					$this->LinkTo(
						__( 'Content Types', 'directories-pro' ),
						'/directories/' . $directory->name . '/content_types'
					),
				),
				'weight' => 50,
			),
		);
		if ( $this->getUser()->isAdministrator() ) {
			$links['settings']['link'][98] = '';
			$links['settings']['link'][99] = $this->_application->LinkTo(
				$title                     = __( 'Export Settings', 'directories-pro' ),
				$this->_application->Url( '/directories/' . $directory->name . '/export_settings' ),
				array(
					'btn'       => true,
					'container' => 'modal',
					'modalSize' => 'xl',
				),
				array(
					'data-modal-title' => $title . ' - ' . $directory->getLabel(),
					'rel'              => 'sabaitooltip',
				)
			);
			$links['delete'] = array(
				'link'   => $this->LinkTo(
					'',
					$this->Url( '/directories/' . $directory->name . '/delete' ),
					array(
						'icon'      => 'fas fa-trash-can',
						'btn'       => true,
						'container' => 'modal',
						'modalSize' => 'lg',
					),
					array(
						'class'            => DRTS_BS_PREFIX . 'btn-outline-danger',
						'title'            => $title = __( 'Delete Directory', 'directories-pro' ),
						'data-modal-title' => $title . ' - ' . $directory->getLabel(),
						'rel'              => 'sabaitooltip',
					)
				),
				'weight' => 99,
			);
		}

		$links = $this->Filter( 'directory_admin_directory_links', $links, array( $directory ) );
		ksort( $links['settings']['link'] );

		// Sort
		uasort(
			$links,
			function ( $a, $b ) {
				return $a['weight'] < $b['weight'] ? -1 : 1;
			}
		);
		// Remove weight
		foreach ( array_keys( $links ) as $key ) {
			$links[ $key ] = $links[ $key ]['link'];
		}

		return $links;
	}
}
