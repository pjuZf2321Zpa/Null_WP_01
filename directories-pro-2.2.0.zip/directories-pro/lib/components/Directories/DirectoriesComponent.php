<?php
namespace SabaiApps\Directories\Component\Directories;

use SabaiApps\Directories\Component\AbstractComponent;
use SabaiApps\Directories\Component\System;
use SabaiApps\Directories\Application;
use SabaiApps\Directories\Context;

/**
 * Provides the multi-directory management admin UI (directory list, add, delete).
 *
 * This is an optional companion to the Directory component. Directory on its own
 * knows how to manage a single directory's contents; Directories layers the
 * "many directories" surface on top - the list page at the plugin's top-level
 * admin route, the "Add Directory" form, and directory deletion. When this
 * component is not installed, Directory falls back to a single-directory landing
 * (its own Directory\Controller\Admin\Directories, which this component's
 * same-named controller overrides via a higher route priority).
 *
 * Directory never references Directories - the dependency only goes one way.
 */
class DirectoriesComponent extends AbstractComponent implements
	System\IAdminRouter {

	const VERSION = '2.2.0', PACKAGE = 'directories-pro';

	public static function description() {
		return 'Adds the multi-directory management admin UI (directory list, add, delete).';
	}

	public function systemAdminRoutes() {
		return array(
			// Overrides Directory's own fallback root route for the same path.
			// _getRoutes() fetches rows priority ASC and lets later (higher
			// priority) rows overwrite earlier ones, so priority 6 > default 5.
			'/directories'                        => array(
				'controller'     => 'Directories',
				'title_callback' => true,
				'callback_path'  => 'directories',
				'type'           => Application::ROUTE_TAB,
				'weight'         => 9,
				'priority'       => 6,
			),
			'/directories/add'                    => array(
				'controller'      => 'AddDirectory',
				'access_callback' => true,
				'title_callback'  => true,
				'callback_path'   => 'add_directory',
				'type'            => Application::ROUTE_MENU,
				'priority'        => 6,
			),
			'/directories/:directory_name/delete' => array(
				'controller'     => 'DeleteDirectory',
				'title_callback' => true,
				'callback_path'  => 'delete_directory',
				'priority'       => 6,
			),
		);
	}

	public function systemOnAccessAdminRoute( Context $context, $path, $accessType, array &$route ) {
		switch ( $path ) {
			case 'add_directory':
				if ( $accessType === Application::ROUTE_ACCESS_LINK ) {
					if ( ! $this->_application->getUser()->isAdministrator() ) {
						return false;
					}

					$route['data'] = array(
						'link_options' => array(
							'container' => 'modal',
							'modalSize' => 'xl',
							'cache'     => 'drts-directories-add-directory',
							'icon'      => 'fas fa-plus',
						),
						'link_attr'    => array(
							'class' => DRTS_BS_PREFIX . 'btn ' . DRTS_BS_PREFIX . 'btn-success',
						),
					);
				}
				return true;
			default:
				if ( $accessType === Application::ROUTE_ACCESS_LINK ) {
					return $this->_application->getUser()->isAdministrator();
				}
				return true;
		}
	}

	public function systemAdminRouteTitle( Context $context, $path, $titleType, array $route ) {
		switch ( $path ) {
			case 'directories':
				return $titleType === Application::ROUTE_TITLE_TAB
					? __( 'All Directories', 'directories-pro' )
					: 'Directories';
			case 'add_directory':
				return __( 'Add Directory', 'directories-pro' );
			case 'delete_directory':
				return __( 'Delete Directory', 'directories-pro' );
		}
	}
}
