<?php
namespace SabaiApps\Directories\Component\Directory\SystemTool;

use SabaiApps\Directories\Component\System\Tool\AbstractExportJsonTool;
use SabaiApps\Directories\Context;

class ExportDirectorySettingsSystemTool extends AbstractExportJsonTool {

	protected function _systemToolInfo() {
		return array(
			'hidden'    => true,
			'btn_label' => __( 'Export Settings', 'directories-pro' ),
		);
	}

	protected function _getDefaultJsonFileName( ?Context $context = null ) {
		return $context->directory->name;
	}

	protected function _export( array $settings, ?Context $context = null ) {
		$directory = $context->directory;

		$export_data = array(
			'name'    => $directory->name,
			'type'    => $directory->type,
			'data'    => $directory->data,
			'bundles' => array(),
		);
		foreach ( $this->_application->Entity_Bundles( null, $directory->name ) as $bundle ) {
			$export_data['bundles'][ $bundle->type ]['info'] = $bundle->info;
			foreach ( $this->_application->Directory_ExportBundle( $bundle ) as $key => $arr ) {
				$export_data['bundles'][ $bundle->type ][ $key ] = $arr['data'];
			}
		}

		return $this->_application->Filter( 'directory_system_tool_export_directory_settings', $export_data, array( $directory ) );
	}
}
