<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
use SabaiApps\Directories\Application;

$tables = array(
	'directory_directory' => array(
		'fields'         => array(
			'directory_name'    => array(
				'type'    => Application::COLUMN_VARCHAR,
				'notnull' => true,
				'length'  => 12,
				'default' => '',
			),
			'directory_type'    => array(
				'type'    => Application::COLUMN_VARCHAR,
				'notnull' => true,
				'length'  => 40,
				'default' => '',
			),
			'directory_data'    => array(
				'type'    => Application::COLUMN_TEXT,
				'notnull' => true,
			),
			'directory_created' => array(
				'type'     => Application::COLUMN_INTEGER,
				'unsigned' => true,
				'notnull'  => true,
				'length'   => 10,
				'default'  => 0,
			),
			'directory_updated' => array(
				'type'     => Application::COLUMN_INTEGER,
				'unsigned' => true,
				'notnull'  => true,
				'length'   => 10,
				'default'  => 0,
			),
		),
		'indexes'        => array(
			'directory_name' => array(
				'primary' => true,
				'fields'  => array(
					'directory_name' => array( 'sorting' => 'ascending' ),
				),
			),
		),
		'initialization' => array(
			'insert' => array(),
		),
	),
);
return array(
	'charset'     => '',
	'description' => '',
	'tables'      => $tables,
);
