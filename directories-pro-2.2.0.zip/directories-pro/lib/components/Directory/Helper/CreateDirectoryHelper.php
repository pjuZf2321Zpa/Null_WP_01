<?php
namespace SabaiApps\Directories\Component\Directory\Helper;

use SabaiApps\Directories\Application;
use SabaiApps\Directories\Exception;
use SabaiApps\Directories\Component\Directory\Model\Directory;

/**
 * Programmatically creates a directory and its content type bundles, with no
 * form/UI involved.
 *
 * This is the shared "create a directory" core that both the admin
 * "Add Directory" form (Directories\Controller\Admin\AddDirectory) and any
 * activation-hook auto-provisioner can call, so the create + bundle + reload
 * sequence lives in exactly one place.
 *
 * Invoked as $application->Directory_CreateDirectory($args) - see
 * Application::_getHelper() for the name resolution.
 */
class CreateDirectoryHelper {

	/**
	 * @param Application $application
	 * @param array       $args {
	 *     @var string $type     Directory type name (required).
	 *     @var string $name     Machine name (required unless the type hard-codes one).
	 *     @var string $label    Admin label (defaults to the type's own label).
	 *     @var string $icon     Icon class (ignored if the type hard-codes one).
	 *     @var array  $settings Per-content-type settings, keyed by content type.
	 * }
	 * @return Directory
	 * @throws Exception\RuntimeException
	 */
	public function help( Application $application, array $args ) {
		if ( empty( $args['type'] )
			|| ! $directory_impl = $application->Directory_Types_impl( $args['type'], true )
		) {
			throw new Exception\RuntimeException( sprintf( 'Invalid directory type: %s', isset( $args['type'] ) ? $args['type'] : '' ) );
		}

		// Abort if this directory type allows one directory only and one already exists.
		if ( $directory_impl->directoryInfo( 'multiple' ) === false
			&& $application->getModel( 'Directory', 'Directory' )->type_is( $args['type'] )->count()
		) {
			throw new Exception\RuntimeException( sprintf( 'Only one directory of type "%s" may be created.', $args['type'] ) );
		}

		$settings = isset( $args['settings'] ) && is_array( $args['settings'] ) ? $args['settings'] : array();

		if ( ! ( $name = $directory_impl->directoryInfo( 'name' ) ) && empty( $args['name'] ) ) {
			throw new Exception\RuntimeException( sprintf( 'A directory name is required for directory type "%s".', $args['type'] ) );
		}

		$directory       = $application->getModel( 'Directory', 'Directory' )->create();
		$directory->name = $name ? $name : $args['name'];
		$directory->type = $args['type'];
		$directory->data = array(
			'label'    => isset( $args['label'] ) && strlen( $args['label'] ) ? $args['label'] : $directory_impl->directoryInfo( 'label' ),
			'icon'     => ( $icon = $directory_impl->directoryInfo( 'icon' ) ) ? $icon : ( isset( $args['icon'] ) ? $args['icon'] : null ),
			'settings' => $settings,
		);
		$directory->markNew()->commit();

		// Create a bundle for each content type in the directory type
		$bundles = array();
		foreach ( $directory_impl->directoryContentTypeNames() as $content_type ) {
			if ( ! $content_type_info = $application->Filter(
				'directory_content_type_info',
				$directory_impl->directoryContentTypeInfo( $content_type ),
				array( $content_type, isset( $settings[ $content_type ] ) ? $settings[ $content_type ] : array() )
			) ) {
				continue;
			}

			// Convert content type info to bundle type info
			$bundles[ $directory->type . '__' . $content_type ] = $application->Directory_Types_entityBundleTypeInfo(
				$directory->type,
				$content_type,
				$content_type_info
			);
		}
		$bundles_created = array();
		if ( $bundles ) {
			foreach ( $application->Entity_Admin_createEntityBundles( $bundles, $directory->name ) as $bundle ) {
				$bundles_created[ $bundle->type ] = $bundle;
			}
		}

		$application->getPlatform()->deleteCache( 'wordpress_admin_menu_post_type_icons' );

		$application->Action( 'directory_admin_directory_added', array( $directory, $args, $bundles_created, null ) );

		// Run upgrade process to notify directory slugs have been updated
		$application->System_Component_upgradeAll( array_keys( $application->System_Slugs() ) );

		// Reload all routes
		$application->getComponent( 'System' )->reloadAllRoutes();

		// Clear available widgets cache
		$application->getPlatform()->deleteCache( 'system_widgets' );

		return $directory;
	}
}
