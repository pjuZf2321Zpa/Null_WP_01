<?php
namespace SabaiApps\Directories\Component\Directory\Helper;

use SabaiApps\Directories\Application;
use SabaiApps\Directories\Component\Directory\Model\Directory;

/**
 * UrlHelper resolves the front-end URL for a directory, if it has one.
 *
 * Not every directory has a single canonical front-end URL: one whose type
 * has its own auto-created page (pageable !== false, the common case) is
 * reachable at that page's URL; one shown only through a shortcode/block
 * wherever a site owner places it (pageable === false, e.g. Product
 * Directory) has none unless the type supplies one itself via
 * directoryInfo('url').
 */
class UrlHelper {

	/**
	 * @param Application      $application
	 * @param Directory|string $directory Directory entity, or its name
	 * @return string|false The directory's URL, or false if it has none
	 */
	public function help( Application $application, $directory ) {
		if ( ! $directory instanceof Directory ) {
			if ( ! $directory = $application->getModel( 'Directory', 'Directory' )->fetchById( $directory ) ) {
				return false;
			}
		}

		if ( ! $directory_type = $application->Directory_Types_impl( $directory->type, true ) ) {
			return false;
		}

		if ( $url = $directory_type->directoryInfo( 'url' ) ) {
			return is_callable( $url ) ? call_user_func( $url, $directory ) : $url;
		}

		if ( $directory_type->directoryInfo( 'pageable' ) === false ) {
			return false;
		}

		return $application->MainUrl( '/' . $application->getComponent( 'Directory' )->getSlug( $directory->name ) );
	}
}
