<?php
namespace SabaiApps\Directories\Component\Directory\EntityBundleType;

use SabaiApps\Directories\Component\Entity\BundleType\AbstractBundleType;

class TagEntityBundleType extends AbstractBundleType {

	protected function _entityBundleTypeInfo() {
		return array(
			'type'            => $this->_name,
			'entity_type'     => 'term',
			'suffix'          => 'dir_tag',
			'component'       => 'Directory',
			'slug'            => 'tags',
			'is_taxonomy'     => true,
			'label'           => __( 'Tags', 'directories-pro' ),
			'label_singular'  => __( 'Tag', 'directories-pro' ),
			'label_add'       => __( 'Add Tag', 'directories-pro' ),
			'label_all'       => __( 'All Tags', 'directories-pro' ),
			'label_select'    => __( 'Select Tag', 'directories-pro' ),
			/* translators: %s: 1 */
			'label_count'     => __( '%s tag', 'directories-pro' ),
			/* translators: %s: plural number */
			'label_count2'    => __( '%s tags', 'directories-pro' ),
			/* translators: %s: tag title */
			'label_page'      => __( 'Tag: %s', 'directories-pro' ),
			'icon'            => 'fas fa-tag',
			'public'          => true,
			'is_hierarchical' => false,
			'entity_icon'     => '',
			'entity_color'    => '',
			'displays'        => __DIR__ . '/tag_displays.php',
			'views'           => __DIR__ . '/tag_views.php',
		);
	}
}
