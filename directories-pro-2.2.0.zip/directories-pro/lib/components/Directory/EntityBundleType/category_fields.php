<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
return array(
	'directory_color' =>
	array(
		'type'     => 'color',
		'settings' =>
		array(),
		'realm'    => 2,
		'data'     =>
		array(
			'label'           => __( 'Category Color', 'directories-pro' ),
			'description'     => '',
			'default_value'   => null,
			'required'        => false,
			'disabled'        => false,
			'weight'          => 4,
			'max_num_items'   => 1,
			'widget'          => 'color',
			'widget_settings' =>
			array(),
		),
	),
	'directory_icon'  =>
	array(
		'type'     => 'icon',
		'settings' =>
		array(),
		'realm'    => 2,
		'data'     =>
		array(
			'label'           => __( 'Category Icon', 'directories-pro' ),
			'description'     => '',
			'default_value'   => null,
			'required'        => false,
			'disabled'        => false,
			'weight'          => 5,
			'max_num_items'   => 1,
			'widget'          => 'icon',
			'widget_settings' =>
			array(),
		),
	),
);
