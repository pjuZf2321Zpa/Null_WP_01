<?php
namespace SabaiApps\Directories\Component\Directory\EntityBundleType;

use SabaiApps\Directories\Component\Entity\BundleType\AbstractBundleType;

class CategoryEntityBundleType extends AbstractBundleType {

	protected function _entityBundleTypeInfo() {
		return array(
			'type'            => $this->_name,
			'entity_type'     => 'term',
			'suffix'          => 'dir_cat',
			'slug'            => 'categories',
			'component'       => 'Directory',
			'is_taxonomy'     => true,
			'label'           => __( 'Categories', 'directories-pro' ),
			'label_singular'  => __( 'Category', 'directories-pro' ),
			'label_add'       => __( 'Add Category', 'directories-pro' ),
			'label_all'       => __( 'All Categories', 'directories-pro' ),
			'label_select'    => __( 'Select Category', 'directories-pro' ),
			/* translators: %s: 1 */
			'label_count'     => __( '%s category', 'directories-pro' ),
			/* translators: %s: plural number */
			'label_count2'    => __( '%s categories', 'directories-pro' ),
			/* translators: %s: category title */
			'label_page'      => __( 'Category: %s', 'directories-pro' ),
			'icon'            => 'fas fa-folder',
			'public'          => true,
			'is_hierarchical' => true,
			'entity_icon'     => 'directory_icon',
			'entity_color'    => 'directory_color',
			'properties'      => array(
				'parent' => array(
					'label' => __( 'Parent Category', 'directories-pro' ),
				),
			),
			'fields'          => __DIR__ . '/category_fields.php',
			'displays'        => __DIR__ . '/category_displays.php',
			'views'           => __DIR__ . '/category_views.php',
		);
	}
}
