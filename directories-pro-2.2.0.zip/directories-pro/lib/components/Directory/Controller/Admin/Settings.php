<?php
namespace SabaiApps\Directories\Component\Directory\Controller\Admin;

use SabaiApps\Directories\Component\System\Controller\Admin\Settings as SystemAdminSettings;

class Settings extends SystemAdminSettings{}
