<?php
namespace SabaiApps\Directories\Component\Directory\Controller\Admin;

use SabaiApps\Directories\Component\Form;
use SabaiApps\Directories\Context;

class ExportBundle extends Form\Controller {

	protected function _doGetFormSettings( Context $context, array &$storage ) {
		$this->_submitable = false;

		$ret = array();
		foreach ( $this->Directory_ExportBundle( $context->bundle, true ) as $key => $arr ) {
			$ret[ $key ] = array(
				'#title'         => $arr['title'],
				'#type'          => 'textarea',
				'#default_value' => '<?php' . PHP_EOL . 'return ' . strtr( var_export( $arr['data'], true ), $arr['placeholders'] ) . ';',
				'#rows'          => 30,
				'#attributes'    => array( 'style' => 'max-height:500px; overflow:scroll;' ),
			);
		}

		return $ret;
	}
}
