<?php
namespace SabaiApps\Directories\Component\Directory\Controller\Admin;

use SabaiApps\Directories\Component\System\Controller\Admin\System as SystemAdminSystem;

class System extends SystemAdminSystem{}
