<?php
namespace SabaiApps\Directories\Component\Directory\Controller\Admin;

use SabaiApps\Directories\Context;
use SabaiApps\Directories\Component\System\Controller\Admin\RunToolWithProgress;

class SendEmail extends RunToolWithProgress {

	protected function _getToolName( Context $context ) {
		return 'directory_bulk_send_email';
	}
}
