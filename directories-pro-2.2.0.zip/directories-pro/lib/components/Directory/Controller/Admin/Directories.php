<?php
namespace SabaiApps\Directories\Component\Directory\Controller\Admin;

use SabaiApps\Directories\Controller;
use SabaiApps\Directories\Context;

/**
 * Fallback landing controller for the plugin's top-level admin route.
 *
 * The multi-directory list / add / delete UI lives in the optional Directories
 * component, whose own controller of the same name overrides this route (with a
 * higher route priority) when installed. On its own, Directory only ever manages
 * a single directory, so there is nothing to list here - redirect straight to
 * that directory's settings (or to the System tab if, exceptionally, none
 * exists yet).
 *
 * Deliberately kept named "Directories" (not e.g. "DirectoriesFallback") so that
 * a route row left over from before the Directory/Directories split - which
 * still points controller "Directories" at the Directory component - keeps
 * resolving to a real class until routes are rebuilt.
 */
class Directories extends Controller {

	protected function _doExecute( Context $context ) {
		$directory = $this->getModel( 'Directory', 'Directory' )->fetchOne( 'directory_name', 'ASC' );

		if ( $directory ) {
			$context->setRedirect(
				$this->_application->AdminUrl( '/directories/' . $directory->name )
			);
			return;
		}

		$context->setRedirectMessage(
			__( 'No directory has been configured yet.', 'directories-pro' )
		);
		$context->setRedirect( $this->_application->AdminUrl( '/directories/system' ) );
	}
}
