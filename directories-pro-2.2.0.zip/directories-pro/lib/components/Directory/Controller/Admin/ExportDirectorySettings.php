<?php
namespace SabaiApps\Directories\Component\Directory\Controller\Admin;

use SabaiApps\Directories\Component\System\Controller\Admin\RunToolWithProgress;
use SabaiApps\Directories\Context;

class ExportDirectorySettings extends RunToolWithProgress {

	protected function _getToolName( Context $context ) {
		return 'directory_export_directory_settings';
	}
}
