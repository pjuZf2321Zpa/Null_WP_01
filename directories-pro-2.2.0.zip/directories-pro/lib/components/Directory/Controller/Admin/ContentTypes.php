<?php
namespace SabaiApps\Directories\Component\Directory\Controller\Admin;

use SabaiApps\Directories\Context;
use SabaiApps\Directories\Component\System;

class ContentTypes extends System\Controller\Admin\AbstractSettings {

	protected function _getSettingsForm( Context $context, array &$formStorage ) {
		$this->_submitable = false;
		$form              = array(
			'#directory'           => $context->directory,
			'#primary_bundle_name' => null,
		);
		$path              = rtrim( $this->_bundleAdminLinkBase( $context ), '/' ) . '/';
		foreach ( $this->Entity_Bundles_sort( null, $context->directory->name ) as $bundle ) {
			$info = $this->Entity_BundleTypeInfo( $bundle );
			if ( isset( $info['configurable'] ) && ! $info['configurable'] ) {
				continue;
			}

			if ( ! empty( $bundle->info['is_primary'] ) ) {
				$form['#primary_bundle_name'] = $bundle->name;
			}
			if ( $bundle->entitytype_name === 'term'
				&& ( $_bundle = $bundle->isAlias() )
			) {
				$admin_links = array(
					'edit' => $this->LinkTo(
						'',
						'/directories/' . $_bundle->group . '/content_types/' . $_bundle->name,
						array( 'icon' => 'fas fa-pen-to-square' ),
						/* translators: %s: directory label */
											array( 'title' => sprintf( _x( 'Edit in %s', 'directory name', 'directories-pro' ), $_bundle->getGroupLabel() ) )
					),
				);
				$bundle = $_bundle;
			} else {
				$admin_links = $this->Entity_Bundle_adminLinks( $bundle, $path . $bundle->name );
			}

			$btn_options  = array(
				'label'   => true,
				'right'   => true,
				'color'   => 'outline-secondary',
				'split'   => true,
				'btn'     => false,
				'tooltip' => true,
			);
			$bundle_name  = $bundle->name;
			$bundle_label = '<strong>' . $this->H( $bundle->getLabel( 'singular' ) ) . '</strong>';
			$name_prefix  = '';
			if ( $bundle->entitytype_name === 'post' ) {
				if ( $context->directory->type !== 'directory' ) {
					/* translators: %s: post type name */
					$bundle_name = sprintf( __( 'Post type: %s', 'directories-pro' ), $bundle_name );
				}
				if ( empty( $bundle->info['is_primary'] ) ) {
					$name_prefix = '<span>--</span> ';
				}
			} elseif ( $bundle->entitytype_name === 'term' ) {
					/* translators: %s: taxonomy label */
					$bundle_label = sprintf( $this->H( __( 'Taxonomy: %s', 'directories-pro' ) ), $bundle_label );
			}
			if ( $context->directory->type !== 'directory' && $bundle->entitytype_name === 'post' ) {

			}
			$form['content']['#options'][ $bundle->name ] = array(
				'name'  => $name_prefix . $bundle_label . ' <small>(' . $bundle_name . ')</small>',
				'type'  => '<i class="drts-icon drts-icon-sm fa-fw ' . $info['icon'] . '"></i><span>' . $this->H( $info['label_singular'] ) . ' <small style="display:none;">(' . $bundle->type . ')</small>' . '</span>',
				'links' => $admin_links
					? ( count( $admin_links ) > 1 ? $this->System_Button_dropdownLinks( $admin_links, $btn_options ) : $this->System_Button_links( $admin_links, $btn_options ) )
					// A bundle can legitimately have no admin links at all
					// - reserve a button-sized (but invisible) placeholder so
					// its row doesn't end up visibly thinner than the others.
					: '<span class="' . DRTS_BS_PREFIX . 'btn ' . DRTS_BS_PREFIX . 'btn-outline-secondary ' . DRTS_BS_PREFIX . 'invisible">&nbsp;</span>',
			);
		}
		$this->_addTable( $form['content'] );

		return $form;
	}

	/**
	 * Base path the per-bundle admin links (Fields / Displays / Views / …) are
	 * built on. Normally the current route already is
	 * "/directories/:directory_name/content_types"; a subclass that
	 * renders this list from a different route (e.g. the flattened
	 * single-directory admin) overrides this to point back at the real
	 * bundle-admin route.
	 */
	protected function _bundleAdminLinkBase( Context $context ) {
		return $context->getRoute();
	}

	protected function _addTable( &$form ) {
		$form += array(
			'#type'           => 'tableselect',
			'#responsive'     => false, // prevent dropdown menus being hidden
			'#header'         => array(
				'name'  => __( 'Name', 'directories-pro' ),
				'type'  => ucwords( __( 'Content type', 'directories-pro' ) ),
				'links' => '',
			),
			'#disabled'       => true,
			'#class'          => 'drts-data-table',
			'#row_attributes' => array(
				'@all' => array(
					'links' => array(
						'style' => 'white-space:nowrap;text-align:' . ( $this->getPlatform()->isRtl() ? 'left' : 'right' ) . ';',
					),
				),
			),
		);
	}
}
