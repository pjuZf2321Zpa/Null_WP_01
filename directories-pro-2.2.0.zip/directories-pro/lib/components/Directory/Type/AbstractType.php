<?php
namespace SabaiApps\Directories\Component\Directory\Type;

use SabaiApps\Directories\Application;

abstract class AbstractType implements IType {

	protected $_application, $_name, $_info, $_primaryContentType, $_primaryContentTypeName;

	public function __construct( Application $application, $name ) {
		$this->_application = $application;
		$this->_name        = $name;
	}

	public function directoryInfo( $key = null ) {
		if ( ! isset( $this->_info ) ) {
			$this->_info = (array) $this->_directoryInfo();
		}

		return isset( $key ) ? ( isset( $this->_info[ $key ] ) ? $this->_info[ $key ] : null ) : $this->_info;
	}

	// Always available by default - a directory type gated on something that
	// can change mid-request (e.g. ProductDirectoryType, on WooCommerce) should
	// override this, not stash the answer in _directoryInfo() (cached forever
	// once computed - see directoryInfo() above).
	public function directoryIsAvailable() {
		return true;
	}

	public function directoryUnavailableReason() {
		return null;
	}

	// Falls back to the (cached) directoryInfo() array by default - a
	// directory type whose content types can change mid-request (e.g.
	// ProductDirectoryType) should override this instead, same reasoning as
	// directoryIsAvailable() above.
	public function directoryContentTypeNames() {
		return (array) $this->directoryInfo( 'content_types' );
	}

	abstract protected function _directoryInfo();
}
