<?php
namespace SabaiApps\Directories\Component\Directory\Type;

interface IType {

	public function directoryInfo( $key );
	public function directoryContentTypeInfo( $contentType );

	/**
	 * Whether this directory type can currently be used (e.g. a type gated on
	 * a third-party plugin being active) - unlike directoryInfo(), never
	 * cached by AbstractType, since availability can change within a single
	 * request (see e.g. ProductDirectoryType, gated on WooCommerce's own
	 * 'product' post type, which isn't registered until WordPress 'init'
	 * priority 5 - an earlier check elsewhere in the same request would see
	 * it as unavailable even though it plainly isn't by the time an admin
	 * screen like Add Directory actually asks).
	 *
	 * @return bool
	 */
	public function directoryIsAvailable();

	/**
	 * A short, human-readable reason this type isn't available right now -
	 * only meaningful when directoryIsAvailable() returns false.
	 *
	 * @return string|null
	 */
	public function directoryUnavailableReason();

	/**
	 * The content type names (listing/category/tag/...) this directory type
	 * currently offers - unlike directoryInfo('content_types'), never cached
	 * by AbstractType, for a type whose set can depend on something that can
	 * change within a single request (see e.g. ProductDirectoryType, whose
	 * 'brand' entry depends on WooCommerce's own taxonomy registration, not
	 * done until WordPress 'init' priority 5 - same reasoning as
	 * directoryIsAvailable() above).
	 *
	 * @return string[]
	 */
	public function directoryContentTypeNames();
}
