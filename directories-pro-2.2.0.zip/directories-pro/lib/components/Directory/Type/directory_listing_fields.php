<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
return array(
	'field_phone'            =>
	array(
		'type'     => 'phone',
		'settings' =>
		array(
			'min_length'      => null,
			'max_length'      => null,
			'char_validation' => 'none',
			'mask'            => '(999) 999-9999',
		),
		'realm'    => 0,
		'data'     =>
		array(
			'label'               => __( 'Phone Number', 'directories-pro' ),
			'hide_label'          => false,
			'description'         => '',
			'default_value'       => null,
			'required'            => false,
			'admin_unrequired'    => false,
			'disabled'            => false,
			'weight'              => 4,
			'max_num_items'       => 1,
			'widget'              => 'phone',
			'widget_settings'     =>
			array(
				'autopopulate' => '',
				'field_prefix' => null,
				'field_suffix' => null,
				'mask'         => null,
			),
			'conditions'          =>
			array(),
			'_display'            => 'default',
			'_admin_only'         => false,
			'_user_register_show' => false,
			'_wp_roles'           => null,
		),
	),
	'field_fax'              =>
	array(
		'type'     => 'phone',
		'settings' =>
		array(
			'min_length'      => null,
			'max_length'      => null,
			'char_validation' => 'none',
			'mask'            => '(999) 999-9999',
		),
		'realm'    => 0,
		'data'     =>
		array(
			'label'               => __( 'Fax Number', 'directories-pro' ),
			'hide_label'          => false,
			'description'         => '',
			'default_value'       => null,
			'required'            => false,
			'admin_unrequired'    => false,
			'disabled'            => false,
			'weight'              => 5,
			'max_num_items'       => 1,
			'widget'              => 'phone',
			'widget_settings'     =>
			array(
				'autopopulate' => '',
				'field_prefix' => null,
				'field_suffix' => null,
				'mask'         => null,
			),
			'conditions'          =>
			array(),
			'_display'            => 'default',
			'_admin_only'         => false,
			'_user_register_show' => false,
			'_wp_roles'           => null,
		),
	),
	'field_email'            =>
	array(
		'type'     => 'email',
		'settings' =>
		array(
			'min_length'      => null,
			'max_length'      => null,
			'char_validation' => 'email',
			'check_mx'        => false,
		),
		'realm'    => 0,
		'data'     =>
		array(
			'label'               => __( 'E-mail Address', 'directories-pro' ),
			'hide_label'          => false,
			'description'         => '',
			'default_value'       => null,
			'required'            => false,
			'admin_unrequired'    => false,
			'disabled'            => false,
			'weight'              => 6,
			'max_num_items'       => 1,
			'widget'              => 'email',
			'widget_settings'     =>
			array(
				'autopopulate' => false,
				'field_prefix' => null,
				'field_suffix' => null,
				'mask'         => null,
			),
			'conditions'          =>
			array(),
			'_display'            => 'default',
			'_admin_only'         => false,
			'_user_register_show' => false,
			'_wp_roles'           => null,
		),
	),
	'field_website'          =>
	array(
		'type'     => 'url',
		'settings' =>
		array(
			'min_length'      => '',
			'max_length'      => '',
			'regex'           => '',
			'char_validation' => 'url',
		),
		'realm'    => 0,
		'data'     =>
		array(
			'label'               => __( 'Website URL', 'directories-pro' ),
			'hide_label'          => false,
			'description'         => '',
			'default_value'       => null,
			'required'            => false,
			'admin_unrequired'    => false,
			'disabled'            => false,
			'weight'              => 7,
			'max_num_items'       => 1,
			'widget'              => 'url',
			'widget_settings'     =>
			array(
				'mask'         => '',
				'autopopulate' => false,
			),
			'conditions'          =>
			array(),
			'_display'            => 'default',
			'_admin_only'         => false,
			'_user_register_show' => false,
			'_wp_roles'           => null,
		),
	),
	'field_social_accounts'  =>
	array(
		'type'     => 'social_accounts',
		'settings' =>
		array(
			'medias' =>
			array(
				0 => 'facebook',
				1 => 'twitter',
				2 => 'instagram',
				3 => 'rss',
			),
		),
		'realm'    => 0,
		'data'     =>
		array(
			'label'               => __( 'Social Accounts', 'directories-pro' ),
			'hide_label'          => false,
			'description'         => '',
			'default_value'       => null,
			'required'            => false,
			'admin_unrequired'    => false,
			'disabled'            => false,
			'weight'              => 8,
			'max_num_items'       => 0,
			'widget'              => 'social_accounts',
			'widget_settings'     =>
			array(),
			'conditions'          =>
			array(),
			'_display'            => 'default',
			'_admin_only'         => false,
			'_user_register_show' => false,
			'_wp_roles'           => null,
		),
	),
	'field_price_range'      =>
	array(
		'type'     => 'range',
		'settings' =>
		array(
			'decimals' => '2',
			'prefix'   => '$',
			'suffix'   => '',
			'min'      => null,
			'max'      => null,
		),
		'realm'    => 0,
		'data'     =>
		array(
			'label'               => __( 'Price Range', 'directories-pro' ),
			'hide_label'          => false,
			'description'         => '',
			'default_value'       => null,
			'required'            => false,
			'admin_unrequired'    => false,
			'disabled'            => false,
			'weight'              => 12,
			'max_num_items'       => 1,
			'widget'              => 'range',
			'widget_settings'     =>
			array(
				'step' => '1',
			),
			'conditions'          =>
			array(),
			'_display'            => 'default',
			'_admin_only'         => false,
			'_user_register_show' => false,
			'_wp_roles'           => null,
		),
	),
	'directory_photos'       =>
	array(
		'type'     => 'wp_image',
		'settings' =>
		array(),
		'realm'    => 2,
		'data'     =>
		array(
			'label'               => __( 'Photos', 'directories-pro' ),
			'hide_label'          => false,
			'description'         => '',
			'default_value'       => null,
			'required'            => false,
			'admin_unrequired'    => false,
			'disabled'            => false,
			'weight'              => 10,
			'max_num_items'       => 0,
			'widget'              => 'wp_image',
			'widget_settings'     =>
			array(
				'max_file_size' => 2048,
			),
			'conditions'          =>
			array(),
			'_display'            => 'default',
			'_admin_only'         => false,
			'_user_register_show' => false,
			'_wp_roles'           => null,
		),
	),
	'field_date_established' =>
	array(
		'type'     => 'date',
		'settings' =>
		array(
			'enable_time'       => false,
			'date_range_enable' => false,
			'date_range'        => null,
			'month_only'        => false,
		),
		'realm'    => 0,
		'data'     =>
		array(
			'label'               => __( 'Date Established', 'directories-pro' ),
			'hide_label'          => false,
			'description'         => '',
			'default_value'       => null,
			'required'            => false,
			'admin_unrequired'    => false,
			'disabled'            => false,
			'weight'              => 14,
			'max_num_items'       => 1,
			'widget'              => 'date',
			'widget_settings'     =>
			array(
				'current_date_selected' => false,
			),
			'conditions'          =>
			array(),
			'_display'            => 'default',
			'_admin_only'         => false,
			'_user_register_show' => false,
			'_wp_roles'           => null,
		),
	),
	'field_videos'           =>
	array(
		'type'     => 'video',
		'settings' =>
		array(),
		'realm'    => 0,
		'data'     =>
		array(
			'label'               => __( 'Videos', 'directories-pro' ),
			'hide_label'          => false,
			'description'         => '',
			'default_value'       => null,
			'required'            => false,
			'admin_unrequired'    => false,
			'disabled'            => false,
			'weight'              => 11,
			'max_num_items'       => 0,
			'widget'              => 'video',
			'widget_settings'     =>
			array(),
			'conditions'          =>
			array(),
			'_display'            => 'default',
			'_admin_only'         => false,
			'_user_register_show' => false,
			'_wp_roles'           => null,
		),
	),
	'entity_expires'         =>
	array(
		'type'     => 'entity_expires',
		'settings' =>
		array(),
		'realm'    => 2,
		'data'     =>
		array(
			'label'            => __( 'Exp. Date', 'directories-pro' ),
			'hide_label'       => false,
			'description'      => '',
			'default_value'    => null,
			'required'         => false,
			'admin_unrequired' => false,
			'disabled'         => false,
			'weight'           => 0,
			'max_num_items'    => 1,
			'widget'           => 'entity_expires',
			'widget_settings'  =>
			array(),
			'conditions'       =>
			array(),
		),
	),
	'entity_level'           =>
	array(
		'type'     => 'entity_level',
		'settings' =>
		array(),
		'realm'    => 2,
		'data'     =>
		array(
			'label'            => __( 'Feature level', 'directories-pro' ),
			'hide_label'       => false,
			'description'      => '',
			'default_value'    => null,
			'required'         => false,
			'admin_unrequired' => false,
			'disabled'         => false,
			'weight'           => 0,
			'max_num_items'    => 1,
			'widget'           => 'entity_level',
			'widget_settings'  =>
			array(),
			'conditions'       =>
			array(),
		),
	),
	'entity_meta'            =>
	array(
		'type'     => 'entity_meta',
		'settings' =>
		array(),
		'realm'    => 2,
		'data'     =>
		array(
			'label'            => __( 'Additional Settings', 'directories-pro' ),
			'hide_label'       => false,
			'description'      => '',
			'default_value'    => null,
			'required'         => false,
			'admin_unrequired' => false,
			'disabled'         => false,
			'weight'           => 0,
			'max_num_items'    => 1,
			'widget'           => 'entity_meta',
			'widget_settings'  =>
			array(),
			'conditions'       =>
			array(),
		),
	),
);
