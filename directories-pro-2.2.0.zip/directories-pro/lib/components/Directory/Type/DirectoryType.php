<?php
namespace SabaiApps\Directories\Component\Directory\Type;

class DirectoryType extends AbstractType {

	protected function _directoryInfo() {
		return array(
			'label'                => _x( 'Directory', 'directory type', 'directories-pro' ),
			'content_types'        => array( 'listing' ),
			'primary_content_type' => 'listing',
		);
	}

	public function directoryContentTypeInfo( $contentType ) {
		switch ( $contentType ) {
			case 'listing':
				return array(
					'component'                 => 'Directory',
					'entity_type'               => 'post',
					'suffix'                    => 'dir_ltg',
					'slug'                      => 'listing',
					'label'                     => __( 'Listings', 'directories-pro' ),
					'label_singular'            => __( 'Listing', 'directories-pro' ),
					'label_add'                 => __( 'Add Listing', 'directories-pro' ),
					'label_all'                 => __( 'All Listings', 'directories-pro' ),
					'label_select'              => __( 'Select Listing', 'directories-pro' ),
					'label_search'              => __( 'Search Listings', 'directories-pro' ),
					'label_compare'             => __( 'Compare Listings', 'directories-pro' ),
					/* translators: %s: 1 */
					'label_count'               => __( '%s listing', 'directories-pro' ),
					/* translators: %s: plural number */
					'label_count2'              => __( '%s listings', 'directories-pro' ),
					/* translators: %s: listing title */
					'label_page'                => __( 'Listing: %s', 'directories-pro' ),
					'icon'                      => 'fas fa-file-alt',
					'public'                    => true,
					'properties'                => array(
						'content' => array(
							'label'           => __( 'Listing Description', 'directories-pro' ),
							'weight'          => 10,
							'widget_settings' => array( 'rows' => 10 ),
						),
					),
					'fields'                    => array(),
					'taxonomies'                => array(),
					'levelable'                 => true,
					'privatable'                => false,
					'featurable'                => true,
					'expirable'                 => true,
					'frontendsubmit_enable'     => true,
					'frontendsubmit_guest'      => true,
					'entity_tag'                => 'directory_category',
					'voting_enable'             => array( 'updown', 'rating', 'bookmark', 'report' ),
					'search_enable'             => true,
					'search_fields'             => array(
						'search_keyword' => array(),
					),
					'directory_category_enable' => true,
					'directory_category_field'  => array( 'weight' => 2 ),
					'directory_tag_enable'      => true,
					'directory_tag_field'       => array( 'weight' => 98 ),
					'displays'                  => 'directory_listing_displays.php',
					'views'                     => 'directory_listing_views.php',
					'comparison_enable'         => true,
					'fields'                    => 'directory_listing_fields.php',
					'entity_image'              => 'directory_photos',
					'search_fields'             => array(
						'keyword'                 => array(
							'disabled' => false,
							'settings' => array(
								'min_length'         => 2,
								'match'              => 'all',
								'taxonomies'         => array( 'directory_category', 'directory_tag' ),
								'suggest'            => array(
									'enable'             => true,
									'settings'           => array(
										'min_length' => 1,
										'post_jump'  => false,
										'post_num'   => 5,
									),
									'directory_category' => true,
									'directory_category_jump' => false,
									'directory_category_num' => 5,
									'directory_category_hide_empty' => false,
									'directory_category_hide_count' => false,
									'directory_category_depth' => 0,
									'directory_category_inc_parents' => 1,
									'directory_tag'      => false,
									'location_location'  => false,
								),
								'form'               => array(
									'icon'        => 'fas fa-magnifying-glass',
									'placeholder' => 'Search for...',
									'order'       => 1,
								),
								'child_bundle_types' => array(),
							),
						),
						'location_address'        => array(
							'disabled' => false,
							'settings' => array(
								'suggest_place_country' => '',
								'radius'                => '0',
								'geolocation'           => 1,
								'suggest'               => array(
									'enable'   => 1,
									'settings' => array(
										'depth'       => 0,
										'hide_empty'  => false,
										'hide_count'  => false,
										'inc_parents' => 1,
									),
								),
								'form'                  => array(
									'icon'        => 'fas fa-location-dot',
									'placeholder' => 'Near...',
									'order'       => 2,
								),
							),
						),
						'term_location_location'  => array(
							'disabled' => 1,
						),
						'term_directory_category' => array(
							'disabled' => 1,
						),
					),
					'location_enable'           => true,
					'location_location_field'   => array( 'weight' => 10 ),
					'location_address_field'    => array( 'weight' => 3 ),
					'location_marker_taxonomy'  => 'directory_category',
					'entity_schemaorg'          => array(
						'type'       => 'LocalBusiness',
						'properties' => array(
							'description'               => 'post_content',
							'name'                      => 'post_title',
							'telephone'                 => 'field_phone',
							'faxNumber'                 => 'field_fax',
							'email'                     => 'field_email',
							'url'                       => 'field_website',
							'sameAs'                    => 'field_social_accounts',
							'openingHoursSpecification' => 'field_opening_hours',
							'priceRange'                => 'field_price_range',
							'image'                     => 'directory_photos',
							'address'                   => 'location_address',
							'geo'                       => 'location_address',
						),
					),
					'entity_opengraph'          => array(
						'type'       => 'business.business',
						'properties' => array(
							'og__description'         => 'post_content',
							'article__published_time' => '',
							'og__title'               => 'post_title',
							'books__isbn'             => '',
							'music__isrc'             => '',
							'product__isbn'           => '',
							'og__audio'               => '',
							'og__video'               => '',
							'books__sample'           => '',
							'product__product_link'   => '',
							'article__author'         => '',
							'books__author'           => '',
							'music__musician'         => '',
							'business__hours'         => 'field_opening_hours',
							'og__image'               => 'directory_photos',
							'books__release_date'     => '',
							'music__release_date'     => '',
							'video__release_date'     => '',
							'business__contact_data'  => 'location_address',
							'place__location'         => '',
						),
						'fb_app_id'  => '',
					),
					'contact_enable'            => true,
				);
		}
	}
}
