<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
return array(
	'entity'  =>
	array(
		'detailed'              =>
		array(
			'name'     => 'detailed',
			'type'     => 'entity',
			'data'     =>
			array(
				'css' => '',
			),
			'elements' =>
			array(
				1  =>
				array(
					'id'        => 1,
					'name'      => 'button',
					'data'      =>
					array(
						'settings'   =>
						array(
							'size'           => '',
							'dropdown'       => 1,
							'dropdown_icon'  => 'fas fa-cog',
							'dropdown_label' => '',
							'dropdown_right' => 1,
							'separate'       => 1,
							'arrangement'    =>
							array(
								0 => 'dashboard_posts_edit',
								1 => 'dashboard_posts_delete',
							),
							'buttons'        =>
							array(
								'dashboard_posts_edit'   =>
								array(
									'settings' =>
									array(
										'_hide_label' => false,
										'_icon'       => 'fas fa-pen-to-square',
										'_color'      => 'outline-secondary',
									),
								),
								'dashboard_posts_delete' =>
								array(
									'settings' =>
									array(
										'_hide_label' => false,
										'_icon'       => 'fas fa-trash-can',
										'_color'      => 'danger',
									),
								),
							),
							'btn'            => true,
							'tooltip'        => true,
						),
						'heading'    => null,
						'advanced'   =>
						array(
							'css_class' => 'drts-entity-admin-buttons directory-listing-admin-buttons',
						),
						'visibility' =>
						array(
							'animate'          => 1,
							'animation'        => 'fade-left',
							'wp_check_role'    => false,
							'globalize'        => false,
							'globalize_remove' => false,
							'wp_roles'         =>
							array(),
						),
					),
					'parent_id' => 0,
					'weight'    => 1,
					'system'    => false,
				),
				2  =>
				array(
					'id'        => 2,
					'name'      => 'button',
					'data'      =>
					array(
						'settings'   =>
						array(
							'size'           => '',
							'separate'       => 1,
							'tooltip'        => 1,
							'arrangement'    =>
							array(
								0 => 'voting_bookmark',
								1 => 'voting_form_report',
							),
							'dropdown'       => false,
							'buttons'        =>
							array(
								'voting_bookmark'    =>
								array(
									'settings' =>
									array(
										'_color'      => 'outline-secondary',
										'_hide_label' => false,
										'show_count'  => false,
									),
								),
								'voting_form_report' =>
								array(
									'settings' =>
									array(
										'_hide_label' => 1,
										'_color'      => 'danger',
										'modal'       => 1,
									),
								),
							),
							'btn'            => true,
							'dropdown_icon'  => 'fas fa-cog',
							'dropdown_label' => '',
							'dropdown_right' => false,
						),
						'heading'    =>
						array(
							'label' => 'none',
						),
						'advanced'   =>
						array(
							'css_class'     => 'directory-listing-buttons',
							'css_id'        => '',
							'margin_enable' => 1,
							'margin_top'    => '4',
							'margin_right'  => '0',
							'margin_bottom' => '0',
							'margin_left'   => '0',
						),
						'visibility' =>
						array(
							'author_only'    => false,
							'wp_check_role'  => false,
							'hide_on_mobile' => false,
							'globalize'      => false,
						),
					),
					'parent_id' => 0,
					'weight'    => 9,
					'system'    => false,
				),
				3  =>
				array(
					'id'        => 3,
					'name'      => 'columns',
					'data'      =>
					array(
						'settings'   =>
						array(
							'gutter_width' => 'md',
							'columns'      => 3,
						),
						'heading'    =>
						array(
							'label'           => 'custom',
							'label_custom'    => __( 'Contact Information', 'directories-pro' ),
							'label_icon'      => 'fas ',
							'label_icon_size' => '',
						),
						'advanced'   =>
						array(
							'css_class' => 'directory-listing-contact-info-container',
						),
						'visibility' =>
						array(
							'animate'          => 1,
							'animation'        => 'fade-up',
							'wp_check_role'    => false,
							'globalize'        => false,
							'globalize_remove' => false,
							'wp_roles'         =>
							array(),
						),
					),
					'parent_id' => 0,
					'weight'    => 10,
					'system'    => false,
				),
				4  =>
				array(
					'id'        => 4,
					'name'      => 'column',
					'data'      =>
					array(
						'settings'   =>
						array(
							'width'      => 'responsive',
							'responsive' =>
							array(
								'xs'   =>
								array(
									'width' => '12',
								),
								'sm'   =>
								array(
									'width' => null,
								),
								'md'   =>
								array(
									'width' => '6',
								),
								'lg'   =>
								array(
									'width' => null,
								),
								'xl'   =>
								array(
									'width' => null,
								),
								'grow' => false,
							),
							'hide_empty' => true,
						),
						'heading'    =>
						array(
							'label'           => 'none',
							'label_custom'    => '',
							'label_icon'      => null,
							'label_icon_size' => '',
						),
						'advanced'   => null,
						'visibility' =>
						array(
							'wp_check_role'    => false,
							'globalize'        => false,
							'globalize_remove' => false,
							'wp_roles'         =>
							array(),
						),
					),
					'parent_id' => 3,
					'weight'    => 11,
					'system'    => false,
				),
				5  =>
				array(
					'id'        => 5,
					'name'      => 'entity_fieldlist',
					'data'      =>
					array(
						'settings'   =>
						array(
							'size'      => '',
							'no_border' => false,
							'inline'    => true,
						),
						'heading'    =>
						array(
							'label'           => 'none',
							'label_custom'    => '',
							'label_icon'      => null,
							'label_icon_size' => '',
						),
						'advanced'   =>
						array(
							'css_class' => 'directory-listing-contact-info',
						),
						'visibility' =>
						array(
							'wp_check_role'    => false,
							'globalize'        => false,
							'globalize_remove' => false,
							'wp_roles'         =>
							array(),
						),
					),
					'parent_id' => 4,
					'weight'    => 12,
					'system'    => false,
				),
				6  =>
				array(
					'id'        => 6,
					'name'      => 'column',
					'data'      =>
					array(
						'settings'   =>
						array(
							'width'      => 'responsive',
							'responsive' =>
							array(
								'xs'   =>
								array(
									'width' => '12',
								),
								'sm'   =>
								array(
									'width' => null,
								),
								'md'   =>
								array(
									'width' => '6',
								),
								'lg'   =>
								array(
									'width' => null,
								),
								'xl'   =>
								array(
									'width' => null,
								),
								'grow' => false,
							),
							'hide_empty' => true,
						),
						'heading'    =>
						array(
							'label'           => 'none',
							'label_custom'    => '',
							'label_icon'      => null,
							'label_icon_size' => '',
						),
						'advanced'   =>
						array(
							'css_class' => 'drts-display-element-overflow-visible',
						),
						'visibility' =>
						array(
							'wp_check_role'    => false,
							'globalize'        => false,
							'globalize_remove' => false,
							'wp_roles'         =>
							array(),
						),
					),
					'parent_id' => 3,
					'weight'    => 19,
					'system'    => false,
				),
				7  =>
				array(
					'id'        => 7,
					'name'      => 'group',
					'data'      =>
					array(
						'settings'   =>
						array(
							'inline'           => false,
							'separator'        => '',
							'separator_margin' => true,
							'nowrap'           => false,
						),
						'heading'    =>
						array(
							'label'           => 'custom',
							'label_custom'    => __( 'Detailed Information', 'directories-pro' ),
							'label_icon'      => 'fas ',
							'label_icon_size' => '',
						),
						'advanced'   =>
						array(
							'css_class' => 'directory-listing-detailed-info-container',
						),
						'visibility' =>
						array(
							'animate'          => 1,
							'animation'        => 'fade-up',
							'wp_check_role'    => false,
							'globalize'        => false,
							'globalize_remove' => false,
							'wp_roles'         =>
							array(),
						),
					),
					'parent_id' => 0,
					'weight'    => 21,
					'system'    => false,
				),
				8  =>
				array(
					'id'        => 8,
					'name'      => 'entity_field_post_content',
					'data'      =>
					array(
						'settings'           =>
						array(
							'label'             => 'none',
							'label_custom'      => '',
							'label_icon'        => '',
							'label_icon_size'   => '',
							'renderer_settings' =>
							array(
								'wp_post_content' =>
								array(
									'trim_length'          => 200,
									'disable_excerpt_more' => 1,
									'trim'                 => false,
								),
							),
							'renderer'          => 'wp_post_content',
							'label_as_heading'  => false,
						),
						'heading'            => null,
						'advanced'           =>
						array(
							'css_class'     => 'directory-listing-description',
							'margin_enable' => 1,
							'margin_top'    => '0',
							'margin_right'  => '0',
							'margin_bottom' => '4',
							'margin_left'   => '0',
							'font_size'     => '',
							'font_size_rel' => '1',
							'font_size_abs' => '16',
							'font_weight'   => '',
							'font_style'    => '',
						),
						'visibility'         =>
						array(
							'wp_check_role'    => false,
							'wp_roles'         =>
							array(),
							'globalize'        => false,
							'globalize_remove' => false,
						),
						'_entity_field_type' => 'wp_post_content',
					),
					'parent_id' => 7,
					'weight'    => 22,
					'system'    => false,
				),
				9  =>
				array(
					'id'        => 9,
					'name'      => 'entity_fieldlist',
					'data'      =>
					array(
						'settings'   =>
						array(
							'size'      => '',
							'no_border' => 1,
							'inline'    => true,
						),
						'heading'    =>
						array(
							'label'           => 'none',
							'label_custom'    => '',
							'label_icon'      => null,
							'label_icon_size' => '',
						),
						'advanced'   =>
						array(
							'css_class' => 'directory-listing-extra-info',
						),
						'visibility' =>
						array(
							'wp_check_role'    => false,
							'globalize'        => false,
							'globalize_remove' => false,
							'wp_roles'         =>
							array(),
						),
					),
					'parent_id' => 7,
					'weight'    => 23,
					'system'    => false,
				),
				10 =>
				array(
					'id'        => 10,
					'name'      => 'entity_field_location_address',
					'data'      =>
					array(
						'settings'           =>
						array(
							'label'             => 'icon',
							'label_custom'      => '',
							'label_icon'        => 'fas fa-location-dot',
							'label_icon_size'   => '',
							'label_as_heading'  => false,
							'renderer'          => 'location_address',
							'renderer_settings' =>
							array(
								'map_map'          =>
								array(
									'height'             => 300,
									'zoom_control'       => 1,
									'map_type_control'   => 1,
									'fullscreen_control' => 1,
								),
								'location_address' =>
								array(
									'custom_format' => 0,
									'format'        => '{street}, {city}, {province} {zip}',
									'link'          => false,
									'_separator'    => '<br />',
								),
							),
						),
						'heading'            => null,
						'advanced'           => null,
						'visibility'         =>
						array(
							'wp_check_role'    => false,
							'globalize'        => false,
							'globalize_remove' => false,
							'wp_roles'         =>
							array(),
						),
						'_entity_field_type' => 'location_address',
					),
					'parent_id' => 5,
					'weight'    => 13,
					'system'    => false,
				),
				11 =>
				array(
					'id'        => 11,
					'name'      => 'entity_field_field_phone',
					'data'      =>
					array(
						'settings'           =>
						array(
							'label'             => 'icon',
							'label_custom'      => '',
							'label_icon'        => 'fas fa-phone',
							'label_icon_size'   => '',
							'label_as_heading'  => false,
							'renderer_settings' =>
							array(
								'phone' =>
								array(
									'_separator' => ', ',
								),
							),
							'renderer'          => 'phone',
						),
						'heading'            => null,
						'advanced'           => null,
						'visibility'         =>
						array(
							'wp_check_role'    => false,
							'globalize'        => false,
							'globalize_remove' => false,
							'wp_roles'         =>
							array(),
						),
						'_entity_field_type' => 'phone',
					),
					'parent_id' => 5,
					'weight'    => 14,
					'system'    => false,
				),
				12 =>
				array(
					'id'        => 12,
					'name'      => 'entity_field_field_fax',
					'data'      =>
					array(
						'settings'           =>
						array(
							'label'             => 'icon',
							'label_custom'      => '',
							'label_icon'        => 'fas fa-fax',
							'label_icon_size'   => '',
							'label_as_heading'  => false,
							'renderer_settings' =>
							array(
								'phone' =>
								array(
									'_separator' => ', ',
								),
							),
							'renderer'          => 'phone',
						),
						'heading'            => null,
						'advanced'           => null,
						'visibility'         =>
						array(
							'wp_check_role'    => false,
							'globalize'        => false,
							'globalize_remove' => false,
							'wp_roles'         =>
							array(),
						),
						'_entity_field_type' => 'phone',
					),
					'parent_id' => 5,
					'weight'    => 15,
					'system'    => false,
				),
				13 =>
				array(
					'id'        => 13,
					'name'      => 'entity_field_field_email',
					'data'      =>
					array(
						'settings'           =>
						array(
							'label'             => 'icon',
							'label_custom'      => '',
							'label_icon'        => 'fas fa-envelope',
							'label_icon_size'   => '',
							'label_as_heading'  => false,
							'renderer_settings' =>
							array(
								'email' =>
								array(
									'type'       => 'default',
									'label'      => 'custom label',
									'target'     => '_self',
									'_separator' => ', ',
								),
							),
							'renderer'          => 'email',
						),
						'heading'            => null,
						'advanced'           => null,
						'visibility'         =>
						array(
							'wp_check_role'    => false,
							'globalize'        => false,
							'globalize_remove' => false,
							'wp_roles'         =>
							array(),
						),
						'_entity_field_type' => 'email',
					),
					'parent_id' => 5,
					'weight'    => 16,
					'system'    => false,
				),
				14 =>
				array(
					'id'        => 14,
					'name'      => 'entity_field_field_website',
					'data'      =>
					array(
						'settings'           =>
						array(
							'label'             => 'icon',
							'label_custom'      => '',
							'label_icon'        => 'fas fa-globe',
							'label_icon_size'   => '',
							'label_as_heading'  => false,
							'renderer_settings' =>
							array(
								'url' =>
								array(
									'type'       => 'default',
									'label'      => '',
									'max_len'    => '40',
									'target'     => '_blank',
									'rel'        =>
									array(
										0 => 'nofollow',
										1 => 'external',
									),
									'_separator' => ', ',
								),
							),
							'renderer'          => 'url',
						),
						'heading'            => null,
						'advanced'           => null,
						'visibility'         =>
						array(
							'wp_check_role'    => false,
							'globalize'        => false,
							'globalize_remove' => false,
							'wp_roles'         =>
							array(),
						),
						'_entity_field_type' => 'url',
					),
					'parent_id' => 5,
					'weight'    => 17,
					'system'    => false,
				),
				15 =>
				array(
					'id'        => 15,
					'name'      => 'entity_field_field_social_accounts',
					'data'      =>
					array(
						'settings'           =>
						array(
							'label'             => 'none',
							'label_custom'      => '',
							'label_icon'        => null,
							'label_icon_size'   => '',
							'label_as_heading'  => false,
							'renderer'          => 'social_accounts',
							'renderer_settings' =>
							array(
								'social_accounts'      =>
								array(
									'size'       => 'fa-lg',
									'target'     => '_blank',
									'rel'        =>
									array(
										0 => 'nofollow',
										1 => 'external',
									),
									'_limit'     => 0,
									'_separator' => ' ',
								),
								'social_twitter_feed'  =>
								array(
									'height'     => 600,
									'_limit'     => 0,
									'_separator' => '',
								),
								'social_facebook_page' =>
								array(
									'height'     => 600,
									'_limit'     => 0,
									'_separator' => '',
								),
							),
						),
						'heading'            => null,
						'advanced'           => null,
						'visibility'         =>
						array(
							'wp_check_role'    => false,
							'globalize'        => false,
							'globalize_remove' => false,
							'wp_roles'         =>
							array(),
						),
						'_entity_field_type' => 'social_accounts',
					),
					'parent_id' => 5,
					'weight'    => 18,
					'system'    => false,
				),
				16 =>
				array(
					'id'        => 16,
					'name'      => 'entity_field_directory_photos',
					'data'      =>
					array(
						'settings'           =>
						array(
							'label'             => 'none',
							'label_custom'      => '',
							'label_icon'        => null,
							'label_icon_size'   => '',
							'label_as_heading'  => false,
							'renderer'          => 'photoslider',
							'renderer_settings' =>
							array(
								'image'       =>
								array(
									'size'               => 'thumbnail',
									'width'              => 100,
									'height'             => 0,
									'cols'               => '4',
									'link'               => 'photo',
									'link_image_size'    => 'large',
									'_limit'             => 0,
									'_render_background' => false,
									'_hover_zoom'        => false,
									'_hover_brighten'    => false,
									'_render_empty'      => false,
								),
								'photoslider' =>
								array(
									'size'           => 'large',
									'show_thumbs'    => 1,
									'thumbs_columns' => '6',
									'effect'         => 'slide',
									'pager'          => false,
									'auto'           => false,
									'zoom'           => 1,
									'controls'       => 1,
									'show_videos'    => 1,
									'video_field'    => 'field_videos',
									'prepend_videos' => 1,
									'num_videos'     => '1',
									'_limit'         => 0,
								),
								'wp_gallery'  =>
								array(
									'cols'   => '4',
									'size'   => 'thumbnail',
									'_limit' => 0,
								),
							),
						),
						'heading'            => null,
						'advanced'           =>
						array(
							'css_class' => 'directory-listing-photos',
						),
						'visibility'         =>
						array(
							'wp_check_role'    => false,
							'globalize'        => false,
							'globalize_remove' => false,
							'wp_roles'         =>
							array(),
						),
						'_entity_field_type' => 'wp_image',
					),
					'parent_id' => 0,
					'weight'    => 8,
					'system'    => false,
				),
				17 =>
				array(
					'id'        => 17,
					'name'      => 'entity_field_field_price_range',
					'data'      =>
					array(
						'settings'           =>
						array(
							'label'             => 'form_icon',
							'label_custom'      => '',
							'label_icon'        => 'fas fa-dollar-sign',
							'label_icon_size'   => '',
							'label_as_heading'  => false,
							'renderer_settings' =>
							array(
								'range' =>
								array(
									'dec_point'     => '.',
									'thousands_sep' => ',',
									'range_sep'     => ' to ',
									'_separator'    => ' ',
								),
							),
							'renderer'          => 'range',
						),
						'heading'            => null,
						'advanced'           => null,
						'visibility'         =>
						array(
							'wp_check_role'    => false,
							'globalize'        => false,
							'globalize_remove' => false,
							'wp_roles'         =>
							array(),
						),
						'_entity_field_type' => 'range',
					),
					'parent_id' => 9,
					'weight'    => 25,
					'system'    => false,
				),
				18 =>
				array(
					'id'        => 18,
					'name'      => 'group',
					'data'      =>
					array(
						'settings'   =>
						array(
							'inline'           => false,
							'separator'        => '',
							'separator_margin' => true,
							'nowrap'           => false,
						),
						'heading'    =>
						array(
							'label'           => 'custom',
							'label_custom'    => __( 'Reviews', 'directories-pro' ),
							'label_icon'      => 'fas ',
							'label_icon_size' => '',
						),
						'advanced'   =>
						array(
							'css_class' => 'directory-listing-review-container',
						),
						'visibility' =>
						array(
							'animate'          => 1,
							'animation'        => 'fade-up',
							'wp_check_role'    => false,
							'globalize'        => false,
							'globalize_remove' => false,
							'wp_roles'         =>
							array(),
						),
					),
					'parent_id' => 0,
					'weight'    => 27,
					'system'    => false,
				),
				19 =>
				array(
					'id'        => 19,
					'name'      => 'columns',
					'data'      =>
					array(
						'settings'   =>
						array(
							'gutter_width' => 'lg',
							'columns'      => 3,
						),
						'heading'    =>
						array(
							'label'           => 'none',
							'label_custom'    => '',
							'label_icon'      => '',
							'label_icon_size' => '',
						),
						'advanced'   =>
						array(
							'css_class'     => 'directory-listing-review-ratings',
							'margin_enable' => 1,
							'margin_top'    => '0',
							'margin_right'  => '0',
							'margin_bottom' => '4',
							'margin_left'   => '0',
						),
						'visibility' =>
						array(
							'wp_check_role'    => false,
							'wp_roles'         =>
							array(),
							'globalize'        => false,
							'globalize_remove' => false,
						),
					),
					'parent_id' => 18,
					'weight'    => 29,
					'system'    => false,
				),
				20 =>
				array(
					'id'        => 20,
					'name'      => 'column',
					'data'      =>
					array(
						'settings'   =>
						array(
							'width'      => 'responsive',
							'responsive' =>
							array(
								'xs'   =>
								array(
									'width' => '12',
								),
								'sm'   =>
								array(
									'width' => null,
								),
								'md'   =>
								array(
									'width' => '4',
								),
								'lg'   =>
								array(
									'width' => null,
								),
								'xl'   =>
								array(
									'width' => null,
								),
								'grow' => false,
							),
							'hide_empty' => true,
						),
						'heading'    =>
						array(
							'label'           => 'none',
							'label_custom'    => '',
							'label_icon'      => null,
							'label_icon_size' => '',
						),
						'advanced'   => null,
						'visibility' =>
						array(
							'wp_check_role'    => false,
							'globalize'        => false,
							'globalize_remove' => false,
							'wp_roles'         =>
							array(),
						),
					),
					'parent_id' => 19,
					'weight'    => 30,
					'system'    => false,
				),
				21 =>
				array(
					'id'        => 21,
					'name'      => 'column',
					'data'      =>
					array(
						'settings'   =>
						array(
							'width'      => 'responsive',
							'responsive' =>
							array(
								'xs' =>
								array(
									'width' => '12',
									'grow'  => 1,
								),
								'sm' =>
								array(
									'width' => null,
									'grow'  => 1,
								),
								'md' =>
								array(
									'width' => '8',
									'grow'  => 1,
								),
								'lg' =>
								array(
									'width' => null,
									'grow'  => 1,
								),
								'xl' =>
								array(
									'width' => null,
									'grow'  => 1,
								),
							),
							'hide_empty' => true,
						),
						'heading'    =>
						array(
							'label'           => 'none',
							'label_custom'    => '',
							'label_icon'      => '',
							'label_icon_size' => '',
						),
						'advanced'   => null,
						'visibility' =>
						array(
							'wp_check_role' => false,
							'wp_roles'      =>
							array(),
						),
					),
					'parent_id' => 19,
					'weight'    => 32,
					'system'    => false,
				),
				22 =>
				array(
					'id'        => 22,
					'name'      => 'entity_field_field_date_established',
					'data'      =>
					array(
						'settings'           =>
						array(
							'label'             => 'form_icon',
							'label_custom'      => '',
							'label_icon'        => 'fas fa-calendar-alt',
							'label_icon_size'   => '',
							'label_as_heading'  => false,
							'renderer_settings' =>
							array(
								'date' =>
								array(
									'_separator' => ', ',
								),
							),
							'renderer'          => 'date',
						),
						'heading'            => null,
						'advanced'           => null,
						'visibility'         =>
						array(
							'wp_check_role'    => false,
							'globalize'        => false,
							'globalize_remove' => false,
							'wp_roles'         =>
							array(),
						),
						'_entity_field_type' => 'date',
					),
					'parent_id' => 9,
					'weight'    => 24,
					'system'    => false,
				),
				23 =>
				array(
					'id'        => 23,
					'name'      => 'group',
					'data'      =>
					array(
						'settings'   =>
						array(
							'separator'        => '',
							'separator_margin' => 1,
							'inline'           => false,
							'nowrap'           => false,
						),
						'heading'    =>
						array(
							'label'           => 'none',
							'label_custom'    => '',
							'label_icon'      => 'fas',
							'label_icon_size' => '',
						),
						'advanced'   =>
						array(
							'css_class'      => 'directory-listing-info',
							'margin_enable'  => 1,
							'margin_top'     => '0',
							'margin_right'   => '0',
							'margin_bottom'  => '3',
							'margin_left'    => '0',
							'padding_top'    => '0',
							'padding_right'  => '0',
							'padding_bottom' => '0',
							'padding_left'   => '0',
							'font_size'      => '',
							'font_size_rel'  => '1',
							'font_size_abs'  => '16',
							'font_weight'    => '',
							'font_style'     => '',
							'padding_enable' => false,
						),
						'visibility' =>
						array(
							'wp_check_role'    => false,
							'wp_roles'         =>
							array(),
							'globalize'        => false,
							'globalize_remove' => false,
						),
					),
					'parent_id' => 0,
					'weight'    => 2,
					'system'    => false,
				),
				24 =>
				array(
					'id'        => 24,
					'name'      => 'labels',
					'data'      =>
					array(
						'settings'   =>
						array(
							'arrangement' =>
							array(
								0 => 'entity_featured',
								1 => 'entity_new',
							),
							'style'       => '',
							'labels'      =>
							array(
								'entity_featured' =>
								array(
									'settings' =>
									array(
										'_label' => 'Featured',
										'_color' =>
										array(
											'type' => '',
											'name' => 'warning',
										),
									),
								),
								'entity_new'      =>
								array(
									'settings' =>
									array(
										'_label' => 'New',
										'_color' =>
										array(
											'type' => '',
											'name' => 'danger',
										),
										'days'   => '1',
									),
								),
								'custom-1'        =>
								array(
									'settings' =>
									array(
										'label_type'  => null,
										'label_text'  => '',
										'_color'      =>
										array(
											'type' => null,
											'name' => null,
										),
										'_conditions' => null,
									),
								),
								'custom-2'        =>
								array(
									'settings' =>
									array(
										'label_type'  => null,
										'label_text'  => '',
										'_color'      =>
										array(
											'type' => null,
											'name' => null,
										),
										'_conditions' => null,
									),
								),
								'custom-3'        =>
								array(
									'settings' =>
									array(
										'label_type'  => null,
										'label_text'  => '',
										'_color'      =>
										array(
											'type' => null,
											'name' => null,
										),
										'_conditions' => null,
									),
								),
								'custom-4'        =>
								array(
									'settings' =>
									array(
										'label_type'  => null,
										'label_text'  => '',
										'_color'      =>
										array(
											'type' => null,
											'name' => null,
										),
										'_conditions' => null,
									),
								),
								'custom-5'        =>
								array(
									'settings' =>
									array(
										'label_type'  => null,
										'label_text'  => '',
										'_color'      =>
										array(
											'type' => null,
											'name' => null,
										),
										'_conditions' => null,
									),
								),
								'entity_status'   => null,
								'entity_level'    =>
								array(
									'settings' =>
									array(
										'_color'          =>
										array(
											'type' => null,
											'name' => null,
										),
										'exclude_default' => false,
									),
								),
							),
						),
						'heading'    =>
						array(
							'label' => 'none',
						),
						'advanced'   =>
						array(
							'css_class'     => 'directory-listing-labels',
							'css_id'        => '',
							'margin_enable' => 1,
							'margin_top'    => '0',
							'margin_right'  => '0',
							'margin_bottom' => '2',
							'margin_left'   => '0',
							'font_size'     => '',
							'font_weight'   => '',
							'font_style'    => '',
						),
						'visibility' =>
						array(
							'author_only'    => false,
							'wp_check_role'  => false,
							'hide_on_mobile' => false,
							'globalize'      => false,
						),
					),
					'parent_id' => 23,
					'weight'    => 3,
					'system'    => false,
				),
				25 =>
				array(
					'id'        => 25,
					'name'      => 'group',
					'data'      =>
					array(
						'settings'   =>
						array(
							'inline'           => 1,
							'separator'        => '  ',
							'separator_margin' => 1,
							'nowrap'           => false,
						),
						'heading'    =>
						array(
							'label'           => 'none',
							'label_custom'    => '',
							'label_icon'      => '',
							'label_icon_size' => '',
						),
						'advanced'   =>
						array(
							'css_class'      => 'directory-listing-terms',
							'margin_enable'  => 1,
							'margin_top'     => '0',
							'margin_right'   => '0',
							'margin_bottom'  => '2',
							'margin_left'    => '0',
							'padding_top'    => '0',
							'padding_right'  => '0',
							'padding_bottom' => '0',
							'padding_left'   => '0',
							'font_size'      => '',
							'font_size_rel'  => '1',
							'font_size_abs'  => '16',
							'font_weight'    => '',
							'font_style'     => '',
							'padding_enable' => false,
						),
						'visibility' =>
						array(
							'wp_check_role'    => false,
							'wp_roles'         =>
							array(),
							'globalize'        => false,
							'globalize_remove' => false,
						),
					),
					'parent_id' => 23,
					'weight'    => 5,
					'system'    => false,
				),
				26 =>
				array(
					'id'        => 26,
					'name'      => 'entity_field_location_location',
					'data'      =>
					array(
						'settings'           =>
						array(
							'label'             => 'none',
							'label_custom'      => '',
							'label_icon'        => null,
							'label_icon_size'   => '',
							'label_as_heading'  => false,
							'renderer_settings' =>
							array(
								'entity_terms' =>
								array(
									'icon'       => 1,
									'icon_size'  => 'sm',
									'_limit'     => 0,
									'_separator' => '  ',
								),
							),
							'renderer'          => 'entity_terms',
						),
						'heading'            => null,
						'advanced'           => null,
						'visibility'         =>
						array(
							'wp_check_role'    => false,
							'globalize'        => false,
							'globalize_remove' => false,
							'wp_roles'         =>
							array(),
						),
						'_entity_field_type' => 'entity_terms',
					),
					'parent_id' => 25,
					'weight'    => 7,
					'system'    => false,
				),
				27 =>
				array(
					'id'        => 27,
					'name'      => 'entity_field_directory_category',
					'data'      =>
					array(
						'settings'           =>
						array(
							'label'             => 'none',
							'label_custom'      => '',
							'label_icon'        => null,
							'label_icon_size'   => '',
							'label_as_heading'  => false,
							'renderer_settings' =>
							array(
								'entity_terms' =>
								array(
									'icon'       => 1,
									'icon_size'  => 'sm',
									'_limit'     => 0,
									'_separator' => ' ',
								),
							),
							'renderer'          => 'entity_terms',
						),
						'heading'            => null,
						'advanced'           => null,
						'visibility'         =>
						array(
							'wp_check_role'    => false,
							'globalize'        => false,
							'globalize_remove' => false,
							'wp_roles'         =>
							array(),
						),
						'_entity_field_type' => 'entity_terms',
					),
					'parent_id' => 25,
					'weight'    => 6,
					'system'    => false,
				),
				28 =>
				array(
					'id'        => 28,
					'name'      => 'entity_field_location_address',
					'data'      =>
					array(
						'settings'           =>
						array(
							'label'             => null,
							'label_custom'      => null,
							'label_icon'        => null,
							'label_icon_size'   => null,
							'label_as_heading'  => false,
							'renderer'          => null,
							'renderer_settings' =>
							array(),
						),
						'visibility'         => null,
						'advanced'           => null,
						'_entity_field_type' => 'location_address',
					),
					'parent_id' => 6,
					'weight'    => 20,
					'system'    => false,
				),
				29 =>
				array(
					'id'        => 29,
					'name'      => 'entity_field_voting_rating',
					'data'      =>
					array(
						'settings'           =>
						array(
							'label'             => 'none',
							'label_custom'      => '',
							'label_icon'        => '',
							'label_icon_size'   => '',
							'renderer_settings' =>
							array(
								'voting_rating' =>
								array(
									'_separator'    => '',
									'_render_empty' => '1',
									'hide_empty'    => false,
									'hide_count'    => false,
									'read_only'     => false,
								),
							),
							'renderer'          => 'voting_rating',
							'label_as_heading'  => false,
						),
						'heading'            => null,
						'advanced'           =>
						array(
							'css_class'     => 'directory-listing-rating',
							'margin_enable' => 1,
							'margin_top'    => '0',
							'margin_right'  => '0',
							'margin_bottom' => '2',
							'margin_left'   => '0',
							'font_size'     => '',
							'font_size_rel' => '1',
							'font_size_abs' => '16',
							'font_weight'   => '',
							'font_style'    => '',
						),
						'visibility'         =>
						array(
							'wp_check_role'    => false,
							'wp_roles'         =>
							array(),
							'globalize'        => false,
							'globalize_remove' => false,
						),
						'_entity_field_type' => 'voting_vote',
					),
					'parent_id' => 23,
					'weight'    => 4,
					'system'    => false,
				),
			),
		),
		'dashboard_row'         =>
		array(
			'name'     => 'dashboard_row',
			'type'     => 'entity',
			'data'     =>
			array(
				'css' => '.drts-display--dashboard-row .directory-listing-title a {
    white-space: normal;
}',
			),
			'elements' =>
			array(
				30 =>
				array(
					'id'        => 30,
					'name'      => 'group',
					'data'      =>
					array(
						'settings'   =>
						array(
							'inline'           => 1,
							'separator'        => ' ',
							'separator_margin' => true,
							'nowrap'           => false,
						),
						'heading'    =>
						array(
							'label'           => 'custom',
							'label_custom'    => __( 'Title', 'directories-pro' ),
							'label_icon'      => '',
							'label_icon_size' => '',
						),
						'advanced'   =>
						array(
							'css_class' => 'directory-listing-title-container',
						),
						'visibility' =>
						array(
							'wp_check_role' => false,
							'wp_roles'      =>
							array(),
						),
					),
					'parent_id' => 0,
					'weight'    => 1,
					'system'    => false,
				),
				31 =>
				array(
					'id'        => 31,
					'name'      => 'entity_field_post_title',
					'data'      =>
					array(
						'settings'           =>
						array(
							'label'             => 'none',
							'label_custom'      => '',
							'label_icon'        => '',
							'label_icon_size'   => '',
							'renderer_settings' =>
							array(
								'entity_title' =>
								array(
									'link'              => 'post',
									'link_field'        => 'field_website,',
									'link_target'       => '_self',
									'link_custom_label' => '',
									'max_chars'         => 0,
									'icon'              => 1,
									'icon_settings'     =>
									array(
										'size'     => '',
										'fallback' => false,
										'is_image' => true,
									),
									'_separator'        => '',
									'link_rel'          =>
									array(),
								),
							),
							'renderer'          => 'entity_title',
							'label_as_heading'  => false,
						),
						'heading'            => null,
						'advanced'           =>
						array(
							'css_class'     => 'directory-listing-title',
							'margin_enable' => 1,
							'margin_top'    => '0',
							'margin_right'  => '0',
							'margin_bottom' => '2',
							'margin_left'   => '0',
							'font_size'     => '',
							'font_size_rel' => '1',
							'font_size_abs' => '16',
							'font_weight'   => 'bold',
							'font_style'    => '',
						),
						'visibility'         =>
						array(
							'wp_check_role' => false,
							'wp_roles'      =>
							array(),
						),
						'_entity_field_type' => 'entity_title',
					),
					'parent_id' => 30,
					'weight'    => 2,
					'system'    => false,
				),
				32 =>
				array(
					'id'        => 32,
					'name'      => 'labels',
					'data'      =>
					array(
						'settings'   =>
						array(
							'arrangement' =>
							array(
								0 => 'entity_featured',
							),
							'labels'      =>
							array(
								'entity_featured' =>
								array(
									'settings' =>
									array(
										'_label' => 'Featured',
									),
								),
							),
							'style'       => null,
						),
						'heading'    =>
						array(
							'label'           => 'none',
							'label_custom'    => '',
							'label_icon'      => null,
							'label_icon_size' => '',
						),
						'advanced'   =>
						array(
							'css_class' => 'directory-listing-labels',
						),
						'visibility' =>
						array(
							'wp_check_role' => false,
							'wp_roles'      =>
							array(),
						),
					),
					'parent_id' => 30,
					'weight'    => 3,
					'system'    => false,
				),
				33 =>
				array(
					'id'        => 33,
					'name'      => 'labels',
					'data'      =>
					array(
						'settings'   =>
						array(
							'arrangement' =>
							array(
								0 => 'entity_status',
							),
							'labels'      =>
							array(
								'entity_featured' =>
								array(
									'settings' =>
									array(
										'_color' => 'warning',
									),
								),
							),
							'style'       => null,
						),
						'heading'    =>
						array(
							'label'           => 'custom',
							'label_custom'    => __( 'Status', 'directories-pro' ),
							'label_icon'      => '',
							'label_icon_size' => '',
						),
						'advanced'   =>
						array(
							'css_class' => 'directory-listing-status',
						),
						'visibility' =>
						array(
							'wp_check_role' => false,
							'wp_roles'      =>
							array(),
						),
					),
					'parent_id' => 0,
					'weight'    => 5,
					'system'    => false,
				),
				34 =>
				array(
					'id'        => 34,
					'name'      => 'button',
					'data'      =>
					array(
						'settings'   =>
						array(
							'size'           => '',
							'dropdown'       => 1,
							'dropdown_icon'  => 'fas fa-cog',
							'dropdown_label' => '',
							'dropdown_right' => 1,
							'separate'       => 1,
							'arrangement'    =>
							array(
								0 => 'dashboard_posts_edit',
								1 => 'dashboard_posts_delete',
								2 => 'dashboard_posts_submit',
							),
							'buttons'        =>
							array(
								'dashboard_posts_edit'   =>
								array(
									'settings' =>
									array(
										'_hide_label' => false,
										'_icon'       => 'fas fa-pen-to-square',
										'_color'      => 'outline-secondary',
									),
								),
								'dashboard_posts_delete' =>
								array(
									'settings' =>
									array(
										'_hide_label' => false,
										'_icon'       => 'fas fa-trash-can',
										'_color'      => 'danger',
									),
								),
								'dashboard_posts_submit' =>
								array(
									'settings' =>
									array(
										'_hide_label' => false,
										'_icon'       => 'fas fa-plus',
										'_color'      => 'outline-secondary',
									),
								),
							),
							'btn'            => true,
							'tooltip'        => true,
						),
						'heading'    => null,
						'advanced'   =>
						array(
							'css_class' => 'directory-listing-admin-buttons',
						),
						'visibility' =>
						array(
							'wp_check_role' => false,
							'wp_roles'      =>
							array(),
						),
					),
					'parent_id' => 0,
					'weight'    => 6,
					'system'    => false,
				),
				35 =>
				array(
					'id'        => 35,
					'name'      => 'entity_field_voting_rating',
					'data'      =>
					array(
						'settings'           =>
						array(
							'label'             => 'none',
							'label_custom'      => '',
							'label_icon'        => null,
							'label_icon_size'   => '',
							'label_as_heading'  => false,
							'renderer_settings' =>
							array(
								'voting_rating' =>
								array(
									'hide_empty'    => 1,
									'hide_count'    => false,
									'read_only'     => 1,
									'_separator'    => '',
									'_render_empty' => '1',
								),
							),
							'renderer'          => 'voting_rating',
						),
						'advanced'           => null,
						'visibility'         =>
						array(
							'wp_check_role' => false,
							'wp_roles'      =>
							array(),
						),
						'heading'            => null,
						'_entity_field_type' => 'voting_vote',
					),
					'parent_id' => 30,
					'weight'    => 4,
					'system'    => false,
				),
			),
		),
		'summary'               =>
		array(
			'name'     => 'summary',
			'type'     => 'entity',
			'data'     =>
			array(
				'css' => '',
			),
			'elements' =>
			array(
				36 =>
				array(
					'id'        => 36,
					'name'      => 'columns',
					'data'      =>
					array(
						'settings'   =>
						array(
							'gutter_width' => 'none',
							'_labels'      =>
							array(
								'enable'      => 1,
								'arrangement' =>
								array(
									0 => 'entity_featured',
									1 => 'entity_new',
								),
								'style'       => '',
								'position'    => 'tl',
							),
							'_buttons'     =>
							array(
								'enable' => false,
							),
							'_icons'       =>
							array(
								'enable' => false,
							),
							'labels'       =>
							array(
								'entity_featured' =>
								array(
									'settings' =>
									array(
										'_label' => 'Featured',
										'_color' =>
										array(
											'type' => '',
											'name' => 'warning',
										),
									),
								),
								'entity_new'      =>
								array(
									'settings' =>
									array(
										'_label' => 'New',
										'_color' =>
										array(
											'type' => '',
											'name' => 'danger',
										),
										'days'   => '1',
									),
								),
								'custom-1'        =>
								array(
									'settings' =>
									array(
										'label_type'  => null,
										'label_text'  => '',
										'_color'      =>
										array(
											'type' => null,
											'name' => null,
										),
										'_conditions' => null,
									),
								),
								'custom-2'        =>
								array(
									'settings' =>
									array(
										'label_type'  => null,
										'label_text'  => '',
										'_color'      =>
										array(
											'type' => null,
											'name' => null,
										),
										'_conditions' => null,
									),
								),
								'custom-3'        =>
								array(
									'settings' =>
									array(
										'label_type'  => null,
										'label_text'  => '',
										'_color'      =>
										array(
											'type' => null,
											'name' => null,
										),
										'_conditions' => null,
									),
								),
								'custom-4'        =>
								array(
									'settings' =>
									array(
										'label_type'  => null,
										'label_text'  => '',
										'_color'      =>
										array(
											'type' => null,
											'name' => null,
										),
										'_conditions' => null,
									),
								),
								'custom-5'        =>
								array(
									'settings' =>
									array(
										'label_type'  => null,
										'label_text'  => '',
										'_color'      =>
										array(
											'type' => null,
											'name' => null,
										),
										'_conditions' => null,
									),
								),
								'entity_status'   => null,
								'entity_level'    =>
								array(
									'settings' =>
									array(
										'_color'          =>
										array(
											'type' => null,
											'name' => null,
										),
										'exclude_default' => false,
									),
								),
							),
							'icons'        =>
							array(
								'image-1'          =>
								array(
									'settings' =>
									array(
										'_link'      =>
										array(
											'link_type' => '',
										),
										'conditions' => null,
										'image'      =>
										array(),
									),
								),
								'icon-1'           =>
								array(
									'settings' =>
									array(
										'_icon'      => '',
										'_color'     =>
										array(
											'type' => 'primary',
										),
										'_link'      =>
										array(
											'link_type' => '',
										),
										'conditions' => null,
									),
								),
								'image-2'          =>
								array(
									'settings' =>
									array(
										'image'      =>
										array(),
										'_link'      =>
										array(
											'link_type' => null,
										),
										'conditions' => null,
									),
								),
								'image-3'          =>
								array(
									'settings' =>
									array(
										'image'      =>
										array(),
										'_link'      =>
										array(
											'link_type' => null,
										),
										'conditions' => null,
									),
								),
								'icon-2'           =>
								array(
									'settings' =>
									array(
										'_icon'      => null,
										'_color'     =>
										array(
											'type' => null,
										),
										'_link'      =>
										array(
											'link_type' => null,
										),
										'conditions' => null,
									),
								),
								'icon-3'           =>
								array(
									'settings' =>
									array(
										'_icon'      => null,
										'_color'     =>
										array(
											'type' => null,
										),
										'_link'      =>
										array(
											'link_type' => null,
										),
										'conditions' => null,
									),
								),
								'view_top_ranking' =>
								array(
									'settings' =>
									array(
										'images'     =>
										array(),
										'conditions' => null,
									),
								),
							),
							'buttons'      =>
							array(
								'voting_updown'      =>
								array(
									'settings' =>
									array(
										'_hide_label' => '1',
										'_color'      => 'link',
										'_link_color' => '',
									),
								),
								'voting_updown_down' =>
								array(
									'settings' =>
									array(
										'_hide_label' => '1',
										'_color'      => 'link',
										'_link_color' => '',
									),
								),
								'voting_bookmark'    =>
								array(
									'settings' =>
									array(
										'_hide_label' => '1',
										'_color'      => 'link',
										'_link_color' => '',
									),
								),
								'voting_form_report' =>
								array(
									'settings' =>
									array(
										'_hide_label' => '1',
										'_color'      => 'link',
										'_link_color' => '',
										'modal'       => false,
									),
								),
							),
							'columns'      => 3,
						),
						'heading'    =>
						array(
							'label' => 'none',
						),
						'advanced'   =>
						array(
							'css_class'     => '',
							'css_id'        => '',
							'z_index'       => '',
							'margin_enable' => false,
						),
						'visibility' =>
						array(
							'author_only'    => false,
							'wp_check_role'  => false,
							'hide_on_mobile' => false,
						),
					),
					'parent_id' => 0,
					'weight'    => 1,
					'system'    => false,
				),
				37 =>
				array(
					'id'        => 37,
					'name'      => 'column',
					'data'      =>
					array(
						'settings'   =>
						array(
							'width'      => 'responsive',
							'responsive' =>
							array(
								'xs'   =>
								array(
									'width' => '12',
								),
								'xsm'  =>
								array(
									'width' => 'inherit',
								),
								'sm'   =>
								array(
									'width' => '4',
								),
								'md'   =>
								array(
									'width' => 'inherit',
								),
								'lg'   =>
								array(
									'width' => 'inherit',
								),
								'xl'   =>
								array(
									'width' => 'inherit',
								),
								'xxl'  =>
								array(
									'width' => 'inherit',
								),
								'grow' => false,
							),
							'hide_empty' => 1,
							'_labels'    =>
							array(
								'enable' => false,
							),
							'_buttons'   =>
							array(
								'enable'      => 1,
								'arrangement' =>
								array(
									0 => 'voting_bookmark',
								),
								'position'    => 'bl',
								'hover'       => false,
							),
							'_icons'     =>
							array(
								'enable' => false,
							),
							'labels'     =>
							array(
								'custom-1'        =>
								array(
									'settings' =>
									array(
										'label_type'  => '',
										'label_text'  => '',
										'_color'      =>
										array(
											'type' => '',
											'name' => '',
										),
										'_conditions' => null,
									),
								),
								'custom-2'        =>
								array(
									'settings' =>
									array(
										'label_type'  => '',
										'label_text'  => '',
										'_color'      =>
										array(
											'type' => '',
											'name' => '',
										),
										'_conditions' => null,
									),
								),
								'custom-3'        =>
								array(
									'settings' =>
									array(
										'label_type'  => '',
										'label_text'  => '',
										'_color'      =>
										array(
											'type' => '',
											'name' => '',
										),
										'_conditions' => null,
									),
								),
								'custom-4'        =>
								array(
									'settings' =>
									array(
										'label_type'  => '',
										'label_text'  => '',
										'_color'      =>
										array(
											'type' => '',
											'name' => '',
										),
										'_conditions' => null,
									),
								),
								'custom-5'        =>
								array(
									'settings' =>
									array(
										'label_type'  => '',
										'label_text'  => '',
										'_color'      =>
										array(
											'type' => '',
											'name' => '',
										),
										'_conditions' => null,
									),
								),
								'entity_featured' =>
								array(
									'settings' =>
									array(
										'_label' => 'Featured',
										'_color' =>
										array(
											'type' => '',
											'name' => '',
										),
									),
								),
								'entity_new'      =>
								array(
									'settings' =>
									array(
										'_label' => 'New',
										'_color' =>
										array(
											'type' => '',
											'name' => '',
										),
										'days'   => '1',
									),
								),
								'entity_status'   => null,
								'entity_level'    =>
								array(
									'settings' =>
									array(
										'_color'          =>
										array(
											'type' => null,
											'name' => null,
										),
										'exclude_default' => false,
									),
								),
							),
							'buttons'    =>
							array(
								'voting_bookmark'    =>
								array(
									'settings' =>
									array(
										'_link_color' => '#EEEEEE',
										'_hide_label' => '1',
										'_color'      => 'link',
									),
								),
								'voting_updown'      =>
								array(
									'settings' =>
									array(
										'_hide_label' => '1',
										'_color'      => 'link',
										'_link_color' => '',
									),
								),
								'voting_updown_down' =>
								array(
									'settings' =>
									array(
										'_hide_label' => '1',
										'_color'      => 'link',
										'_link_color' => '',
									),
								),
								'voting_form_report' =>
								array(
									'settings' =>
									array(
										'_hide_label' => '1',
										'_color'      => 'link',
										'_link_color' => '',
										'modal'       => false,
									),
								),
							),
							'icons'      =>
							array(
								'image-1'          =>
								array(
									'settings' =>
									array(
										'_link'      =>
										array(
											'link_type' => '',
										),
										'conditions' => null,
										'image'      =>
										array(),
									),
								),
								'icon-1'           =>
								array(
									'settings' =>
									array(
										'_icon'      => '',
										'_color'     =>
										array(
											'type' => 'primary',
										),
										'_link'      =>
										array(
											'link_type' => '',
										),
										'conditions' => null,
									),
								),
								'image-2'          =>
								array(
									'settings' =>
									array(
										'image'      =>
										array(),
										'_link'      =>
										array(
											'link_type' => null,
										),
										'conditions' => null,
									),
								),
								'image-3'          =>
								array(
									'settings' =>
									array(
										'image'      =>
										array(),
										'_link'      =>
										array(
											'link_type' => null,
										),
										'conditions' => null,
									),
								),
								'icon-2'           =>
								array(
									'settings' =>
									array(
										'_icon'      => null,
										'_color'     =>
										array(
											'type' => null,
										),
										'_link'      =>
										array(
											'link_type' => null,
										),
										'conditions' => null,
									),
								),
								'icon-3'           =>
								array(
									'settings' =>
									array(
										'_icon'      => null,
										'_color'     =>
										array(
											'type' => null,
										),
										'_link'      =>
										array(
											'link_type' => null,
										),
										'conditions' => null,
									),
								),
								'view_top_ranking' =>
								array(
									'settings' =>
									array(
										'images'     =>
										array(),
										'conditions' => null,
									),
								),
							),
						),
						'heading'    =>
						array(
							'label' => 'none',
						),
						'advanced'   =>
						array(
							'css_class'      => 'directory-listing-aside',
							'css_id'         => '',
							'padding_enable' => false,
						),
						'visibility' =>
						array(
							'author_only'    => false,
							'wp_check_role'  => false,
							'hide_on_mobile' => false,
						),
					),
					'parent_id' => 36,
					'weight'    => 2,
					'system'    => false,
				),
				38 =>
				array(
					'id'        => 38,
					'name'      => 'column',
					'data'      =>
					array(
						'settings'   =>
						array(
							'width'      => 'responsive',
							'responsive' =>
							array(
								'xs'   =>
								array(
									'width' => '12',
								),
								'sm'   =>
								array(
									'width' => '8',
								),
								'md'   =>
								array(
									'width' => 'inherit',
								),
								'lg'   =>
								array(
									'width' => 'inherit',
								),
								'xl'   =>
								array(
									'width' => 'inherit',
								),
								'grow' => false,
							),
							'hide_empty' => true,
						),
						'heading'    =>
						array(
							'label'           => 'none',
							'label_custom'    => '',
							'label_icon'      => '',
							'label_icon_size' => '',
						),
						'advanced'   =>
						array(
							'css_class'      => 'directory-listing-main',
							'padding_enable' => 1,
							'padding_top'    => '2',
							'padding_right'  => '3',
							'padding_bottom' => '2',
							'padding_left'   => '3',
						),
						'visibility' =>
						array(
							'wp_check_role' => false,
							'wp_roles'      =>
							array(),
						),
					),
					'parent_id' => 36,
					'weight'    => 4,
					'system'    => false,
				),
				39 =>
				array(
					'id'        => 39,
					'name'      => 'entity_field_post_title',
					'data'      =>
					array(
						'settings'           =>
						array(
							'label'             => 'none',
							'renderer'          => 'entity_title',
							'renderer_settings' =>
							array(
								'entity_title' =>
								array(
									'link'              => 'post',
									'link_target'       => '',
									'link_custom_label' => '',
									'max_chars'         => 50,
									'skip_entity_title_filter' => 1,
									'_separator'        => '',
									'icon'              => false,
								),
							),
							'label_custom'      => null,
							'label_icon'        => null,
							'label_icon_size'   => null,
							'label_as_heading'  => false,
						),
						'heading'            => null,
						'advanced'           =>
						array(
							'css_class'     => 'directory-listing-title',
							'css_id'        => '',
							'font_size'     => 'rel',
							'font_size_rel' => '1.2',
							'font_weight'   => '',
							'font_style'    => '',
							'margin_enable' => false,
						),
						'visibility'         =>
						array(
							'author_only'    => false,
							'wp_check_role'  => false,
							'hide_on_mobile' => false,
						),
						'_entity_field_type' => 'entity_title',
					),
					'parent_id' => 38,
					'weight'    => 5,
					'system'    => false,
				),
				40 =>
				array(
					'id'        => 40,
					'name'      => 'group',
					'data'      =>
					array(
						'settings'   =>
						array(
							'inline'           => 1,
							'separator'        => '·',
							'separator_margin' => 1,
							'nowrap'           => false,
						),
						'heading'    =>
						array(
							'label'           => 'none',
							'label_custom'    => '',
							'label_icon'      => '',
							'label_icon_size' => '',
						),
						'advanced'   =>
						array(
							'css_class'      => 'directory-listing-info',
							'margin_enable'  => 1,
							'margin_top'     => '2',
							'margin_right'   => '0',
							'margin_bottom'  => '0',
							'margin_left'    => '0',
							'padding_top'    => '0',
							'padding_right'  => '0',
							'padding_bottom' => '0',
							'padding_left'   => '0',
							'font_size'      => 'rel',
							'font_size_rel'  => '0.9',
							'font_size_abs'  => '16',
							'font_weight'    => '',
							'font_style'     => '',
							'padding_enable' => false,
						),
						'visibility' =>
						array(
							'wp_check_role' => false,
							'wp_roles'      =>
							array(),
						),
					),
					'parent_id' => 38,
					'weight'    => 7,
					'system'    => false,
				),
				41 =>
				array(
					'id'        => 41,
					'name'      => 'entity_fieldlist',
					'data'      =>
					array(
						'settings'   =>
						array(
							'size'      => 'sm',
							'inline'    => 1,
							'no_border' => false,
						),
						'heading'    =>
						array(
							'label'           => 'none',
							'label_custom'    => '',
							'label_icon'      => '',
							'label_icon_size' => '',
						),
						'advanced'   =>
						array(
							'css_class'      => 'directory-listing-contact-info',
							'margin_enable'  => 1,
							'margin_top'     => '2',
							'margin_right'   => '0',
							'margin_bottom'  => '0',
							'margin_left'    => '0',
							'padding_top'    => '0',
							'padding_right'  => '0',
							'padding_bottom' => '0',
							'padding_left'   => '0',
							'font_size'      => 'rel',
							'font_size_rel'  => '0.9',
							'font_size_abs'  => '16',
							'font_weight'    => '',
							'font_style'     => '',
							'padding_enable' => false,
						),
						'visibility' =>
						array(
							'wp_check_role' => false,
							'wp_roles'      =>
							array(),
						),
					),
					'parent_id' => 38,
					'weight'    => 9,
					'system'    => false,
				),
				42 =>
				array(
					'id'        => 42,
					'name'      => 'entity_field_directory_photos',
					'data'      =>
					array(
						'settings'           =>
						array(
							'label'             => 'none',
							'label_custom'      => '',
							'label_icon'        => 'fas ',
							'label_icon_size'   => '',
							'label_as_heading'  => false,
							'renderer'          => 'image',
							'renderer_settings' =>
							array(
								'image'       =>
								array(
									'size'               => 'medium',
									'width'              => 100,
									'height'             => 0,
									'cols'               => '1',
									'link'               => 'page',
									'link_image_size'    => 'large',
									'_limit'             => 1,
									'_render_background' => 1,
									'_hover_zoom'        => 1,
									'_hover_brighten'    => false,
									'_render_empty'      => 1,
									'_no_image'          => 'thumbnail',
								),
								'photoslider' =>
								array(
									'size'           => 'large',
									'show_thumbs'    => 1,
									'thumbs_columns' => '6',
									'effect'         => 'slide',
									'pager'          => false,
									'auto'           => false,
									'zoom'           => 1,
									'controls'       => 1,
									'show_videos'    => false,
									'video_field'    => '',
									'prepend_videos' => false,
									'_limit'         => 0,
								),
								'wp_gallery'  =>
								array(
									'cols'   => '4',
									'size'   => 'thumbnail',
									'_limit' => 0,
								),
							),
						),
						'heading'            => null,
						'advanced'           =>
						array(
							'css_class' => 'directory-listing-photo',
						),
						'visibility'         =>
						array(
							'wp_check_role' => false,
							'wp_roles'      =>
							array(),
						),
						'_entity_field_type' => 'wp_image',
					),
					'parent_id' => 37,
					'weight'    => 3,
					'system'    => false,
				),
				43 =>
				array(
					'id'        => 43,
					'name'      => 'entity_field_location_address',
					'data'      =>
					array(
						'settings'           =>
						array(
							'label'             => 'icon',
							'label_custom'      => '',
							'label_icon'        => 'fas fa-location-dot',
							'label_icon_size'   => '',
							'label_as_heading'  => false,
							'renderer'          => 'location_address',
							'renderer_settings' =>
							array(
								'map_map'          =>
								array(
									'height'           => 300,
									'zoom_control'     => 1,
									'map_type_control' => 1,
								),
								'location_address' =>
								array(
									'custom_format' => 0,
									'format'        => '{street}, {city}, {province} {zip}',
									'link'          => false,
									'_separator'    => '<br />',
								),
							),
						),
						'heading'            => null,
						'advanced'           => null,
						'visibility'         =>
						array(
							'wp_check_role' => false,
							'wp_roles'      =>
							array(),
						),
						'_entity_field_type' => 'location_address',
					),
					'parent_id' => 41,
					'weight'    => 10,
					'system'    => false,
				),
				44 =>
				array(
					'id'        => 44,
					'name'      => 'entity_field_field_phone',
					'data'      =>
					array(
						'settings'           =>
						array(
							'label'             => 'icon',
							'label_custom'      => '',
							'label_icon'        => 'fas fa-phone',
							'label_icon_size'   => '',
							'label_as_heading'  => false,
							'renderer_settings' =>
							array(
								'phone' =>
								array(
									'_separator' => ', ',
								),
							),
							'renderer'          => 'phone',
						),
						'heading'            => null,
						'advanced'           => null,
						'visibility'         =>
						array(
							'wp_check_role' => false,
							'wp_roles'      =>
							array(),
						),
						'_entity_field_type' => 'phone',
					),
					'parent_id' => 41,
					'weight'    => 11,
					'system'    => false,
				),
				45 =>
				array(
					'id'        => 45,
					'name'      => 'entity_field_directory_category',
					'data'      =>
					array(
						'settings'           =>
						array(
							'label'             => 'none',
							'label_custom'      => '',
							'label_icon'        => null,
							'label_icon_size'   => '',
							'label_as_heading'  => false,
							'renderer_settings' =>
							array(
								'entity_terms' =>
								array(
									'icon'       => false,
									'icon_size'  => 24,
									'_limit'     => 0,
									'_separator' => ', ',
								),
							),
							'renderer'          => 'entity_terms',
						),
						'advanced'           => null,
						'visibility'         =>
						array(
							'wp_check_role' => false,
							'wp_roles'      =>
							array(),
						),
						'heading'            => null,
						'_entity_field_type' => 'entity_terms',
					),
					'parent_id' => 40,
					'weight'    => 8,
					'system'    => false,
				),
				46 =>
				array(
					'id'        => 46,
					'name'      => 'entity_field_voting_rating',
					'data'      =>
					array(
						'settings'           =>
						array(
							'label'             => 'none',
							'label_custom'      => '',
							'label_icon'        => 'fas ',
							'label_icon_size'   => '',
							'label_as_heading'  => false,
							'renderer_settings' =>
							array(
								'voting_rating' =>
								array(
									'hide_empty' => 1,
									'hide_count' => false,
									'read_only'  => 1,
									'_separator' => '',
								),
							),
							'renderer'          => 'voting_rating',
						),
						'heading'            => null,
						'advanced'           =>
						array(
							'css_class' => 'directory-listing-rating',
						),
						'visibility'         =>
						array(
							'wp_check_role' => false,
							'wp_roles'      =>
							array(),
						),
						'_entity_field_type' => 'voting_vote',
					),
					'parent_id' => 38,
					'weight'    => 6,
					'system'    => false,
				),
			),
		),
		'summary-infobox'       =>
		array(
			'name'     => 'summary-infobox',
			'type'     => 'entity',
			'data'     =>
			array(
				'css' => '.drts-display--summary-infobox .directory-listing-labels {
  position: absolute;
  top: 5px;
  left: 10px;
}',
			),
			'elements' =>
			array(
				47 =>
				array(
					'id'        => 47,
					'name'      => 'columns',
					'data'      =>
					array(
						'settings'   =>
						array(
							'gutter_width' => 'none',
							'_labels'      =>
							array(
								'enable'      => 1,
								'arrangement' =>
								array(
									0 => 'entity_featured',
									1 => 'entity_new',
								),
								'style'       => '',
								'position'    => 'tl',
							),
							'_buttons'     =>
							array(
								'enable' => false,
							),
							'_icons'       =>
							array(
								'enable' => false,
							),
							'labels'       =>
							array(
								'entity_featured' =>
								array(
									'settings' =>
									array(
										'_label' => 'Featured',
										'_color' =>
										array(
											'type' => '',
											'name' => 'warning',
										),
									),
								),
								'entity_new'      =>
								array(
									'settings' =>
									array(
										'_label' => 'New',
										'_color' =>
										array(
											'type' => '',
											'name' => 'danger',
										),
										'days'   => '1',
									),
								),
								'custom-1'        =>
								array(
									'settings' =>
									array(
										'label_type'  => null,
										'label_text'  => '',
										'_color'      =>
										array(
											'type' => null,
											'name' => null,
										),
										'_conditions' => null,
									),
								),
								'custom-2'        =>
								array(
									'settings' =>
									array(
										'label_type'  => null,
										'label_text'  => '',
										'_color'      =>
										array(
											'type' => null,
											'name' => null,
										),
										'_conditions' => null,
									),
								),
								'custom-3'        =>
								array(
									'settings' =>
									array(
										'label_type'  => null,
										'label_text'  => '',
										'_color'      =>
										array(
											'type' => null,
											'name' => null,
										),
										'_conditions' => null,
									),
								),
								'custom-4'        =>
								array(
									'settings' =>
									array(
										'label_type'  => null,
										'label_text'  => '',
										'_color'      =>
										array(
											'type' => null,
											'name' => null,
										),
										'_conditions' => null,
									),
								),
								'custom-5'        =>
								array(
									'settings' =>
									array(
										'label_type'  => null,
										'label_text'  => '',
										'_color'      =>
										array(
											'type' => null,
											'name' => null,
										),
										'_conditions' => null,
									),
								),
								'entity_status'   => null,
								'entity_level'    =>
								array(
									'settings' =>
									array(
										'_color'          =>
										array(
											'type' => null,
											'name' => null,
										),
										'exclude_default' => false,
									),
								),
							),
							'icons'        =>
							array(
								'image-1'          =>
								array(
									'settings' =>
									array(
										'_link'      =>
										array(
											'link_type' => '',
										),
										'conditions' => null,
										'image'      =>
										array(),
									),
								),
								'icon-1'           =>
								array(
									'settings' =>
									array(
										'_icon'      => '',
										'_color'     =>
										array(
											'type' => 'primary',
										),
										'_link'      =>
										array(
											'link_type' => '',
										),
										'conditions' => null,
									),
								),
								'image-2'          =>
								array(
									'settings' =>
									array(
										'image'      =>
										array(),
										'_link'      =>
										array(
											'link_type' => null,
										),
										'conditions' => null,
									),
								),
								'image-3'          =>
								array(
									'settings' =>
									array(
										'image'      =>
										array(),
										'_link'      =>
										array(
											'link_type' => null,
										),
										'conditions' => null,
									),
								),
								'icon-2'           =>
								array(
									'settings' =>
									array(
										'_icon'      => null,
										'_color'     =>
										array(
											'type' => null,
										),
										'_link'      =>
										array(
											'link_type' => null,
										),
										'conditions' => null,
									),
								),
								'icon-3'           =>
								array(
									'settings' =>
									array(
										'_icon'      => null,
										'_color'     =>
										array(
											'type' => null,
										),
										'_link'      =>
										array(
											'link_type' => null,
										),
										'conditions' => null,
									),
								),
								'view_top_ranking' =>
								array(
									'settings' =>
									array(
										'images'     =>
										array(),
										'conditions' => null,
									),
								),
							),
							'buttons'      =>
							array(
								'voting_updown'      =>
								array(
									'settings' =>
									array(
										'_hide_label' => '1',
										'_color'      => 'link',
										'_link_color' => '',
									),
								),
								'voting_updown_down' =>
								array(
									'settings' =>
									array(
										'_hide_label' => '1',
										'_color'      => 'link',
										'_link_color' => '',
									),
								),
								'voting_bookmark'    =>
								array(
									'settings' =>
									array(
										'_hide_label' => '1',
										'_color'      => 'link',
										'_link_color' => '',
									),
								),
								'voting_form_report' =>
								array(
									'settings' =>
									array(
										'_hide_label' => '1',
										'_color'      => 'link',
										'_link_color' => '',
										'modal'       => false,
									),
								),
							),
							'columns'      => 3,
						),
						'heading'    =>
						array(
							'label' => 'none',
						),
						'advanced'   =>
						array(
							'css_class'     => '',
							'css_id'        => '',
							'z_index'       => '',
							'margin_enable' => false,
						),
						'visibility' =>
						array(
							'author_only'    => false,
							'wp_check_role'  => false,
							'hide_on_mobile' => false,
						),
					),
					'parent_id' => 0,
					'weight'    => 1,
					'system'    => false,
				),
				48 =>
				array(
					'id'        => 48,
					'name'      => 'column',
					'data'      =>
					array(
						'settings'   =>
						array(
							'width'      => '4',
							'responsive' =>
							array(
								'xs'   =>
								array(
									'width' => '12',
								),
								'sm'   =>
								array(
									'width' => '4',
								),
								'md'   =>
								array(
									'width' => 'inherit',
								),
								'lg'   =>
								array(
									'width' => 'inherit',
								),
								'xl'   =>
								array(
									'width' => 'inherit',
								),
								'grow' => false,
							),
							'hide_empty' => true,
						),
						'heading'    =>
						array(
							'label'           => 'none',
							'label_custom'    => '',
							'label_icon'      => '',
							'label_icon_size' => '',
						),
						'advanced'   =>
						array(
							'css_class' => 'directory-listing-aside',
						),
						'visibility' =>
						array(
							'wp_check_role' => false,
							'wp_roles'      =>
							array(),
						),
					),
					'parent_id' => 47,
					'weight'    => 2,
					'system'    => false,
				),
				49 =>
				array(
					'id'        => 49,
					'name'      => 'column',
					'data'      =>
					array(
						'settings'   =>
						array(
							'width'      => '8',
							'responsive' =>
							array(
								'xs'   =>
								array(
									'width' => '12',
								),
								'sm'   =>
								array(
									'width' => '8',
								),
								'md'   =>
								array(
									'width' => 'inherit',
								),
								'lg'   =>
								array(
									'width' => 'inherit',
								),
								'xl'   =>
								array(
									'width' => 'inherit',
								),
								'grow' => false,
							),
							'hide_empty' => true,
						),
						'heading'    =>
						array(
							'label'           => 'none',
							'label_custom'    => '',
							'label_icon'      => '',
							'label_icon_size' => '',
						),
						'advanced'   =>
						array(
							'css_class'      => 'directory-listing-main',
							'padding_enable' => 1,
							'padding_top'    => '2',
							'padding_right'  => '3',
							'padding_bottom' => '2',
							'padding_left'   => '3',
						),
						'visibility' =>
						array(
							'wp_check_role' => false,
							'wp_roles'      =>
							array(),
						),
					),
					'parent_id' => 47,
					'weight'    => 5,
					'system'    => false,
				),
				50 =>
				array(
					'id'        => 50,
					'name'      => 'entity_field_post_title',
					'data'      =>
					array(
						'settings'           =>
						array(
							'label'             => 'none',
							'renderer'          => 'entity_title',
							'renderer_settings' =>
							array(
								'entity_title' =>
								array(
									'link'              => 'post',
									'link_target'       => '',
									'link_custom_label' => '',
									'max_chars'         => 50,
									'skip_entity_title_filter' => 1,
									'_separator'        => '',
									'icon'              => false,
								),
							),
							'label_custom'      => null,
							'label_icon'        => null,
							'label_icon_size'   => null,
							'label_as_heading'  => false,
						),
						'heading'            => null,
						'advanced'           =>
						array(
							'css_class'     => 'directory-listing-title',
							'css_id'        => '',
							'font_size'     => 'rel',
							'font_size_rel' => '1.2',
							'font_weight'   => '',
							'font_style'    => '',
							'margin_enable' => false,
						),
						'visibility'         =>
						array(
							'author_only'    => false,
							'wp_check_role'  => false,
							'hide_on_mobile' => false,
						),
						'_entity_field_type' => 'entity_title',
					),
					'parent_id' => 49,
					'weight'    => 6,
					'system'    => false,
				),
				51 =>
				array(
					'id'        => 51,
					'name'      => 'group',
					'data'      =>
					array(
						'settings'   =>
						array(
							'inline'           => 1,
							'separator'        => '·',
							'separator_margin' => 1,
							'nowrap'           => false,
						),
						'heading'    =>
						array(
							'label'           => 'none',
							'label_custom'    => '',
							'label_icon'      => '',
							'label_icon_size' => '',
						),
						'advanced'   =>
						array(
							'css_class'      => 'directory-listing-info',
							'margin_enable'  => 1,
							'margin_top'     => '2',
							'margin_right'   => '0',
							'margin_bottom'  => '0',
							'margin_left'    => '0',
							'padding_top'    => '0',
							'padding_right'  => '0',
							'padding_bottom' => '0',
							'padding_left'   => '0',
							'font_size'      => 'rel',
							'font_size_rel'  => '0.9',
							'font_size_abs'  => '16',
							'font_weight'    => '',
							'font_style'     => '',
							'padding_enable' => false,
						),
						'visibility' =>
						array(
							'wp_check_role' => false,
							'wp_roles'      =>
							array(),
						),
					),
					'parent_id' => 49,
					'weight'    => 8,
					'system'    => false,
				),
				52 =>
				array(
					'id'        => 52,
					'name'      => 'entity_fieldlist',
					'data'      =>
					array(
						'settings'   =>
						array(
							'size'      => 'sm',
							'inline'    => 1,
							'no_border' => false,
						),
						'heading'    =>
						array(
							'label'           => 'none',
							'label_custom'    => '',
							'label_icon'      => '',
							'label_icon_size' => '',
						),
						'advanced'   =>
						array(
							'css_class'      => 'directory-listing-contact-info',
							'margin_enable'  => 1,
							'margin_top'     => '2',
							'margin_right'   => '0',
							'margin_bottom'  => '0',
							'margin_left'    => '0',
							'padding_top'    => '0',
							'padding_right'  => '0',
							'padding_bottom' => '0',
							'padding_left'   => '0',
							'font_size'      => 'rel',
							'font_size_rel'  => '0.9',
							'font_size_abs'  => '16',
							'font_weight'    => '',
							'font_style'     => '',
							'padding_enable' => false,
						),
						'visibility' =>
						array(
							'wp_check_role' => false,
							'wp_roles'      =>
							array(),
						),
					),
					'parent_id' => 49,
					'weight'    => 10,
					'system'    => false,
				),
				53 =>
				array(
					'id'        => 53,
					'name'      => 'entity_field_directory_photos',
					'data'      =>
					array(
						'settings'           =>
						array(
							'label'             => 'none',
							'label_custom'      => '',
							'label_icon'        => 'fas ',
							'label_icon_size'   => '',
							'label_as_heading'  => false,
							'renderer'          => 'image',
							'renderer_settings' =>
							array(
								'image'       =>
								array(
									'size'               => 'medium',
									'width'              => 100,
									'height'             => 100,
									'cols'               => '1',
									'link'               => 'page',
									'link_image_size'    => 'large',
									'_limit'             => 1,
									'_render_background' => 1,
									'_hover_zoom'        => 1,
									'_hover_brighten'    => false,
									'_render_empty'      => 1,
									'_no_image'          => 'thumbnail',
								),
								'photoslider' =>
								array(
									'size'           => 'large',
									'show_thumbs'    => 1,
									'thumbs_columns' => '6',
									'effect'         => 'slide',
									'pager'          => false,
									'auto'           => false,
									'zoom'           => 1,
									'controls'       => 1,
									'show_videos'    => false,
									'video_field'    => '',
									'prepend_videos' => false,
									'_limit'         => 0,
								),
								'wp_gallery'  =>
								array(
									'cols'   => '4',
									'size'   => 'thumbnail',
									'_limit' => 0,
								),
							),
						),
						'heading'            => null,
						'advanced'           =>
						array(
							'css_class' => 'directory-listing-photo',
						),
						'visibility'         =>
						array(
							'wp_check_role' => false,
							'wp_roles'      =>
							array(),
						),
						'_entity_field_type' => 'wp_image',
					),
					'parent_id' => 48,
					'weight'    => 3,
					'system'    => false,
				),
				54 =>
				array(
					'id'        => 54,
					'name'      => 'entity_field_location_address',
					'data'      =>
					array(
						'settings'           =>
						array(
							'label'             => 'icon',
							'label_custom'      => '',
							'label_icon'        => 'fas fa-location-dot',
							'label_icon_size'   => '',
							'label_as_heading'  => false,
							'renderer'          => 'location_address',
							'renderer_settings' =>
							array(
								'map_map'          =>
								array(
									'height'           => 300,
									'zoom_control'     => 1,
									'map_type_control' => 1,
								),
								'location_address' =>
								array(
									'custom_format' => 0,
									'format'        => '{street}, {city}, {province} {zip}',
									'link'          => false,
									'_separator'    => '<br />',
								),
							),
						),
						'heading'            => null,
						'advanced'           => null,
						'visibility'         =>
						array(
							'wp_check_role' => false,
							'wp_roles'      =>
							array(),
						),
						'_entity_field_type' => 'location_address',
					),
					'parent_id' => 52,
					'weight'    => 11,
					'system'    => false,
				),
				55 =>
				array(
					'id'        => 55,
					'name'      => 'entity_field_field_phone',
					'data'      =>
					array(
						'settings'           =>
						array(
							'label'             => 'icon',
							'label_custom'      => '',
							'label_icon'        => 'fas fa-phone',
							'label_icon_size'   => '',
							'label_as_heading'  => false,
							'renderer_settings' =>
							array(
								'phone' =>
								array(
									'_separator' => ', ',
								),
							),
							'renderer'          => 'phone',
						),
						'heading'            => null,
						'advanced'           => null,
						'visibility'         =>
						array(
							'wp_check_role' => false,
							'wp_roles'      =>
							array(),
						),
						'_entity_field_type' => 'phone',
					),
					'parent_id' => 52,
					'weight'    => 12,
					'system'    => false,
				),
				56 =>
				array(
					'id'        => 56,
					'name'      => 'entity_field_directory_category',
					'data'      =>
					array(
						'settings'           =>
						array(
							'label'             => 'none',
							'label_custom'      => '',
							'label_icon'        => null,
							'label_icon_size'   => '',
							'label_as_heading'  => false,
							'renderer_settings' =>
							array(
								'entity_terms' =>
								array(
									'icon'       => false,
									'icon_size'  => 24,
									'_limit'     => 0,
									'_separator' => ', ',
								),
							),
							'renderer'          => 'entity_terms',
						),
						'advanced'           => null,
						'visibility'         =>
						array(
							'wp_check_role' => false,
							'wp_roles'      =>
							array(),
						),
						'heading'            => null,
						'_entity_field_type' => 'entity_terms',
					),
					'parent_id' => 51,
					'weight'    => 9,
					'system'    => false,
				),
				57 =>
				array(
					'id'        => 57,
					'name'      => 'labels',
					'data'      =>
					array(
						'settings'   =>
						array(
							'arrangement' =>
							array(
								0 => 'entity_featured',
							),
							'labels'      =>
							array(
								'entity_featured' =>
								array(
									'settings' =>
									array(
										'_label' => 'Featured',
									),
								),
							),
							'style'       => null,
						),
						'heading'    =>
						array(
							'label'           => 'none',
							'label_custom'    => '',
							'label_icon'      => null,
							'label_icon_size' => '',
						),
						'advanced'   =>
						array(
							'css_class' => 'directory-listing-labels',
						),
						'visibility' =>
						array(
							'wp_check_role' => false,
							'wp_roles'      =>
							array(),
						),
					),
					'parent_id' => 48,
					'weight'    => 4,
					'system'    => false,
				),
				58 =>
				array(
					'id'        => 58,
					'name'      => 'entity_field_voting_rating',
					'data'      =>
					array(
						'settings'           =>
						array(
							'label'             => 'none',
							'label_custom'      => '',
							'label_icon'        => 'fas ',
							'label_icon_size'   => '',
							'label_as_heading'  => false,
							'renderer_settings' =>
							array(
								'voting_rating' =>
								array(
									'hide_empty' => 1,
									'hide_count' => false,
									'read_only'  => 1,
									'_separator' => '',
								),
							),
							'renderer'          => 'voting_rating',
						),
						'heading'            => null,
						'advanced'           =>
						array(
							'css_class' => 'directory-listing-rating',
						),
						'visibility'         =>
						array(
							'wp_check_role' => false,
							'wp_roles'      =>
							array(),
						),
						'_entity_field_type' => 'voting_vote',
					),
					'parent_id' => 49,
					'weight'    => 7,
					'system'    => false,
				),
			),
		),
		'summary-image_overlay' =>
		array(
			'name'     => 'summary-image_overlay',
			'type'     => 'entity',
			'data'     =>
			array(
				'css' => '',
			),
			'elements' =>
			array(
				59 =>
				array(
					'id'        => 59,
					'name'      => 'entity_field_directory_photos',
					'data'      =>
					array(
						'settings'           =>
						array(
							'label'             => 'none',
							'label_custom'      => '',
							'label_icon'        => '',
							'label_icon_size'   => '',
							'renderer'          => 'image',
							'renderer_settings' =>
							array(
								'image'         =>
								array(
									'size'               => 'medium',
									'width'              => 100,
									'height'             => 0,
									'cols'               => '1',
									'link'               => 'page',
									'link_image_size'    => 'large',
									'_limit'             => 1,
									'_hover_zoom'        => 1,
									'_hover_brighten'    => 1,
									'_render_background' => true,
									'_render_empty'      => true,
								),
								'wp_gallery'    =>
								array(
									'cols'    => '4',
									'size'    => 'thumbnail',
									'_limit'  => 0,
									'no_link' => false,
								),
								'slider_photos' =>
								array(
									'size'               => 'large',
									'show_thumbs'        => 1,
									'thumbs_columns'     => '6',
									'effect'             => 'slide',
									'zoom'               => 1,
									'controls'           => 1,
									'video_field'        => 'field_videos',
									'num_videos'         => '1',
									'_limit'             => 0,
									'_render_empty'      => '1',
									'pager'              => false,
									'auto'               => false,
									'show_videos'        => false,
									'prepend_videos'     => false,
									'video_privacy_mode' => false,
								),
							),
							'label_as_heading'  => false,
						),
						'heading'            => null,
						'advanced'           =>
						array(
							'css_class' => 'directory-listing-photo',
							'cache'     => '',
						),
						'visibility'         =>
						array(
							'wp_check_role' => false,
							'wp_roles'      =>
							array(),
						),
						'_entity_field_type' => 'wp_image',
					),
					'parent_id' => 0,
					'weight'    => 1,
					'system'    => false,
				),
				60 =>
				array(
					'id'        => 60,
					'name'      => 'group',
					'data'      =>
					array(
						'settings'   =>
						array(
							'separator'        => '',
							'separator_margin' => 1,
							'inline'           => false,
							'nowrap'           => false,
						),
						'advanced'   =>
						array(
							'css_class' => 'drts-display-element-overlay drts-display-element-overlay-center directory-listing-overlay',
						),
						'visibility' =>
						array(
							'wp_check_role' => false,
							'wp_roles'      =>
							array(),
						),
						'heading'    =>
						array(
							'label'           => 'none',
							'label_custom'    => '',
							'label_icon'      => '',
							'label_icon_size' => '',
						),
					),
					'parent_id' => 0,
					'weight'    => 2,
					'system'    => false,
				),
				61 =>
				array(
					'id'        => 61,
					'name'      => 'entity_field_post_title',
					'data'      =>
					array(
						'settings'           =>
						array(
							'label'             => 'none',
							'renderer'          => 'entity_title',
							'renderer_settings' =>
							array(
								'entity_title' =>
								array(
									'link'              => 'post',
									'link_target'       => '',
									'link_custom_label' => '',
									'max_chars'         => 0,
									'skip_entity_title_filter' => 1,
									'_separator'        => '',
									'icon'              => false,
								),
							),
							'label_custom'      => null,
							'label_icon'        => null,
							'label_icon_size'   => null,
							'label_as_heading'  => false,
						),
						'heading'            => null,
						'advanced'           =>
						array(
							'css_class'     => 'directory-listing-title',
							'css_id'        => '',
							'font_size'     => 'rel',
							'font_size_rel' => '1.2',
							'font_weight'   => '',
							'font_style'    => '',
							'margin_enable' => false,
						),
						'visibility'         =>
						array(
							'author_only'    => false,
							'wp_check_role'  => false,
							'hide_on_mobile' => false,
						),
						'_entity_field_type' => 'entity_title',
					),
					'parent_id' => 60,
					'weight'    => 3,
					'system'    => false,
				),
				62 =>
				array(
					'id'        => 62,
					'name'      => 'entity_field_location_address',
					'data'      =>
					array(
						'settings'           =>
						array(
							'label'             => 'none',
							'label_custom'      => '',
							'label_icon'        => '',
							'label_icon_size'   => '',
							'renderer'          => 'location_address',
							'renderer_settings' =>
							array(
								'map_map'          =>
								array(
									'height'           => 300,
									'view_marker_icon' => 'default',
									'directions'       => 1,
								),
								'map_street_view'  =>
								array(
									'height'           => 300,
									'view_marker_icon' => 'default',
								),
								'location_address' =>
								array(
									'custom_format' => 0,
									'format'        => '{street}, {city}, {province} {zip}',
									'target'        => '_self',
									'_separator'    => '<br />',
									'link'          => false,
								),
							),
							'label_as_heading'  => false,
						),
						'heading'            => null,
						'advanced'           =>
						array(
							'css_class'     => 'directory-listing-location-address',
							'margin_top'    => '0',
							'margin_right'  => '0',
							'margin_bottom' => '0',
							'margin_left'   => '0',
							'font_size'     => 'rel',
							'font_size_rel' => '0.8',
							'font_size_abs' => '16',
							'font_weight'   => '',
							'font_style'    => '',
							'margin_enable' => false,
						),
						'visibility'         =>
						array(
							'wp_check_role' => false,
							'wp_roles'      =>
							array(),
						),
						'_entity_field_type' => 'location_address',
					),
					'parent_id' => 60,
					'weight'    => 4,
					'system'    => false,
				),
			),
		),
		'row'                   =>
		array(
			'name'     => 'row',
			'type'     => 'entity',
			'data'     =>
			array(
				'css'   => '.drts-display--row .directory-listing-title a {
    white-space: normal;
}',
				'label' => null,
			),
			'elements' =>
			array(
				63 =>
				array(
					'id'        => 63,
					'name'      => 'group',
					'data'      =>
					array(
						'settings'   =>
						array(
							'inline'           => 1,
							'separator'        => ' ',
							'separator_margin' => true,
							'nowrap'           => false,
						),
						'heading'    =>
						array(
							'label'           => 'custom',
							'label_custom'    => __( 'Title', 'directories-pro' ),
							'label_icon'      => '',
							'label_icon_size' => '',
						),
						'advanced'   =>
						array(
							'css_class' => 'directory-listing-title-container',
						),
						'visibility' =>
						array(
							'wp_check_role' => false,
							'wp_roles'      =>
							array(),
						),
					),
					'parent_id' => 0,
					'weight'    => 1,
					'system'    => false,
				),
				64 =>
				array(
					'id'        => 64,
					'name'      => 'entity_field_post_title',
					'data'      =>
					array(
						'settings'           =>
						array(
							'label'             => 'none',
							'renderer'          => 'entity_title',
							'renderer_settings' =>
							array(
								'entity_title' =>
								array(
									'link'              => 'post',
									'link_target'       => '',
									'link_custom_label' => '',
									'max_chars'         => 0,
									'icon'              => 1,
									'icon_settings'     =>
									array(
										'size'     => '',
										'fallback' => false,
										'is_image' => true,
									),
									'skip_entity_title_filter' => 1,
									'_separator'        => '',
								),
							),
							'label_custom'      => null,
							'label_icon'        => null,
							'label_icon_size'   => null,
							'label_as_heading'  => false,
						),
						'heading'            => null,
						'advanced'           =>
						array(
							'css_class'     => 'directory-listing-title',
							'css_id'        => '',
							'margin_enable' => 1,
							'margin_top'    => '0',
							'margin_right'  => '0',
							'margin_bottom' => '2',
							'margin_left'   => '0',
							'font_size'     => '',
							'font_weight'   => 'bold',
							'font_style'    => '',
						),
						'visibility'         =>
						array(
							'author_only'    => false,
							'wp_check_role'  => false,
							'hide_on_mobile' => false,
						),
						'_entity_field_type' => 'entity_title',
					),
					'parent_id' => 63,
					'weight'    => 2,
					'system'    => false,
				),
				65 =>
				array(
					'id'        => 65,
					'name'      => 'labels',
					'data'      =>
					array(
						'settings'   =>
						array(
							'arrangement' =>
							array(
								0 => 'entity_featured',
								1 => 'entity_new',
							),
							'style'       => '',
							'labels'      =>
							array(
								'entity_featured' =>
								array(
									'settings' =>
									array(
										'_label' => 'Featured',
										'_color' =>
										array(
											'type' => '',
											'name' => 'warning',
										),
									),
								),
								'entity_new'      =>
								array(
									'settings' =>
									array(
										'_label' => 'New',
										'_color' =>
										array(
											'type' => '',
											'name' => 'danger',
										),
										'days'   => '1',
									),
								),
								'custom-1'        =>
								array(
									'settings' =>
									array(
										'label_type'  => null,
										'label_text'  => '',
										'_color'      =>
										array(
											'type' => null,
											'name' => null,
										),
										'_conditions' => null,
									),
								),
								'custom-2'        =>
								array(
									'settings' =>
									array(
										'label_type'  => null,
										'label_text'  => '',
										'_color'      =>
										array(
											'type' => null,
											'name' => null,
										),
										'_conditions' => null,
									),
								),
								'custom-3'        =>
								array(
									'settings' =>
									array(
										'label_type'  => null,
										'label_text'  => '',
										'_color'      =>
										array(
											'type' => null,
											'name' => null,
										),
										'_conditions' => null,
									),
								),
								'custom-4'        =>
								array(
									'settings' =>
									array(
										'label_type'  => null,
										'label_text'  => '',
										'_color'      =>
										array(
											'type' => null,
											'name' => null,
										),
										'_conditions' => null,
									),
								),
								'custom-5'        =>
								array(
									'settings' =>
									array(
										'label_type'  => null,
										'label_text'  => '',
										'_color'      =>
										array(
											'type' => null,
											'name' => null,
										),
										'_conditions' => null,
									),
								),
								'entity_status'   => null,
								'entity_level'    =>
								array(
									'settings' =>
									array(
										'_color'          =>
										array(
											'type' => null,
											'name' => null,
										),
										'exclude_default' => false,
									),
								),
							),
						),
						'heading'    =>
						array(
							'label' => 'none',
						),
						'advanced'   =>
						array(
							'css_class'     => 'directory-listing-labels',
							'css_id'        => '',
							'font_size'     => '',
							'font_weight'   => '',
							'font_style'    => '',
							'margin_enable' => false,
						),
						'visibility' =>
						array(
							'author_only'    => false,
							'wp_check_role'  => false,
							'hide_on_mobile' => false,
						),
					),
					'parent_id' => 63,
					'weight'    => 3,
					'system'    => false,
				),
				66 =>
				array(
					'id'        => 66,
					'name'      => 'entity_field_voting_rating',
					'data'      =>
					array(
						'settings'           =>
						array(
							'label'             => 'none',
							'label_custom'      => '',
							'label_icon'        => null,
							'label_icon_size'   => '',
							'label_as_heading'  => false,
							'renderer_settings' =>
							array(
								'voting_rating' =>
								array(
									'hide_empty'    => 1,
									'hide_count'    => false,
									'read_only'     => 1,
									'_separator'    => '',
									'_render_empty' => '1',
								),
							),
							'renderer'          => 'voting_rating',
						),
						'advanced'           => null,
						'visibility'         =>
						array(
							'wp_check_role' => false,
							'wp_roles'      =>
							array(),
						),
						'heading'            => null,
						'_entity_field_type' => 'voting_vote',
					),
					'parent_id' => 63,
					'weight'    => 4,
					'system'    => false,
				),
				67 =>
				array(
					'id'        => 67,
					'name'      => 'entity_field_location_address',
					'data'      =>
					array(
						'settings'           =>
						array(
							'label'             => 'form',
							'label_as_heading'  => 1,
							'renderer'          => 'location_address',
							'renderer_settings' =>
							array(
								'location_address' =>
								array(
									'link'          => 1,
									'target'        => '_blank',
									'_separator'    => '<br />',
									'custom_format' => false,
								),
								'map_map'          =>
								array(),
								'map_street_view'  =>
								array(),
								'map_static_map'   =>
								array(),
							),
							'label_custom'      => null,
							'label_icon'        => null,
							'label_icon_size'   => null,
						),
						'heading'            => null,
						'advanced'           =>
						array(
							'font_size'     => '',
							'font_weight'   => '',
							'font_style'    => '',
							'margin_enable' => false,
						),
						'visibility'         =>
						array(
							'author_only'   => false,
							'wp_check_role' => false,
						),
						'element'            => 'entity_field_location_address',
						'parent_id'          => '0',
						'_entity_field_type' => 'location_address',
					),
					'parent_id' => 0,
					'weight'    => 5,
					'system'    => false,
				),
				68 =>
				array(
					'id'        => 68,
					'name'      => 'entity_field_field_date_established',
					'data'      =>
					array(
						'settings'           =>
						array(
							'label'             => 'form',
							'label_as_heading'  => 1,
							'renderer'          => 'date',
							'renderer_settings' =>
							array(
								'date' =>
								array(
									'format'     => 'date',
									'_separator' => ', ',
								),
							),
							'label_custom'      => null,
							'label_icon'        => null,
							'label_icon_size'   => null,
						),
						'heading'            => null,
						'advanced'           =>
						array(
							'font_size'     => '',
							'font_weight'   => '',
							'font_style'    => '',
							'margin_enable' => false,
						),
						'visibility'         =>
						array(
							'author_only'   => false,
							'wp_check_role' => false,
						),
						'element'            => 'entity_field_field_date_established',
						'parent_id'          => '0',
						'_entity_field_type' => 'date',
					),
					'parent_id' => 0,
					'weight'    => 6,
					'system'    => false,
				),
			),
		),
	),
	'filters' =>
	array(
		'default'    =>
		array(
			'name'     => 'default',
			'type'     => 'filters',
			'data'     =>
			array(),
			'elements' =>
			array(
				69 =>
				array(
					'id'        => 69,
					'name'      => 'view_filter_directory_category',
					'data'      =>
					array(
						'settings'   =>
						array(
							'field_name'       => 'directory_category',
							'filter_name'      => 'filter_directory_category',
							'display_name'     => 'default',
							'name'             => 'directory_category',
							'label'            => 'form_icon',
							'label_custom'     => __( 'Categories', 'directories-pro' ),
							'label_icon'       => 'fas fa-folder',
							'label_icon_size'  => '',
							'label_as_heading' => true,
							'filter'           => 'view_term_list',
							'filter_settings'  =>
							array(
								'view_term_list' =>
								array(
									'depth'         => 0,
									'hide_empty'    => false,
									'hide_count'    => false,
									'andor'         => 'OR',
									'visible_count' => 10,
								),
							),
						),
						'heading'    => null,
						'advanced'   => null,
						'visibility' =>
						array(
							'wp_check_role' => false,
							'wp_roles'      =>
							array(),
						),
					),
					'parent_id' => 0,
					'weight'    => 1,
					'system'    => false,
				),
				70 =>
				array(
					'id'        => 70,
					'name'      => 'group',
					'data'      =>
					array(
						'settings'   =>
						array(
							'inline'           => false,
							'separator'        => '',
							'separator_margin' => true,
							'nowrap'           => false,
						),
						'heading'    =>
						array(
							'label'           => 'custom_icon',
							'label_custom'    => __( 'Business Info', 'directories-pro' ),
							'label_icon'      => 'fas fa-info-circle',
							'label_icon_size' => '',
						),
						'advanced'   => null,
						'visibility' =>
						array(
							'wp_check_role' => false,
							'wp_roles'      =>
							array(),
						),
					),
					'parent_id' => 0,
					'weight'    => 7,
					'system'    => false,
				),
				71 =>
				array(
					'id'        => 71,
					'name'      => 'view_filter_field_price_range',
					'data'      =>
					array(
						'settings'   =>
						array(
							'field_name'       => 'field_price_range',
							'filter_name'      => 'filter_field_price_range',
							'display_name'     => 'default',
							'name'             => 'field_price_range',
							'label'            => 'form',
							'label_custom'     => __( 'Price Range', 'directories-pro' ),
							'label_icon'       => null,
							'label_icon_size'  => '',
							'label_as_heading' => false,
							'filter'           => 'range',
							'filter_settings'  =>
							array(
								'range' =>
								array(
									'step'           => '0.01',
									'ignore_min_max' => 1,
								),
							),
						),
						'heading'    => null,
						'advanced'   => null,
						'visibility' =>
						array(
							'wp_check_role' => false,
							'wp_roles'      =>
							array(),
						),
					),
					'parent_id' => 70,
					'weight'    => 9,
					'system'    => false,
				),
				72 =>
				array(
					'id'        => 72,
					'name'      => 'view_filter_field_date_established',
					'data'      =>
					array(
						'settings'   =>
						array(
							'field_name'       => 'field_date_established',
							'filter_name'      => 'filter_field_date_established',
							'display_name'     => 'default',
							'name'             => 'field_date_established',
							'label'            => 'form',
							'label_custom'     => '',
							'label_icon'       => null,
							'label_icon_size'  => '',
							'label_as_heading' => false,
							'filter'           => 'daterange',
							'filter_settings'  =>
							array(
								'daterange' =>
								array(),
							),
						),
						'heading'    => null,
						'advanced'   => null,
						'visibility' =>
						array(
							'wp_check_role' => false,
							'wp_roles'      =>
							array(),
						),
					),
					'parent_id' => 70,
					'weight'    => 8,
					'system'    => false,
				),
				73 =>
				array(
					'id'        => 73,
					'name'      => 'group',
					'data'      =>
					array(
						'settings'   =>
						array(
							'inline'           => false,
							'separator'        => '',
							'separator_margin' => true,
							'nowrap'           => false,
						),
						'heading'    =>
						array(
							'label'           => 'custom_icon',
							'label_custom'    => __( 'Others', 'directories-pro' ),
							'label_icon'      => 'fas fa-ellipsis-v',
							'label_icon_size' => '',
						),
						'advanced'   => null,
						'visibility' =>
						array(
							'wp_check_role' => false,
							'wp_roles'      =>
							array(),
						),
					),
					'parent_id' => 0,
					'weight'    => 11,
					'system'    => false,
				),
				74 =>
				array(
					'id'        => 74,
					'name'      => 'view_filter_field_videos',
					'data'      =>
					array(
						'settings'   =>
						array(
							'field_name'       => 'field_videos',
							'filter_name'      => 'filter_field_videos',
							'display_name'     => 'default',
							'name'             => 'field_videos',
							'label'            => 'form',
							'label_custom'     => '',
							'label_icon'       => null,
							'label_icon_size'  => '',
							'label_as_heading' => false,
							'filter'           => 'video',
							'filter_settings'  =>
							array(
								'video' =>
								array(
									'checkbox_label' => 'Show with video only',
								),
							),
						),
						'heading'    => null,
						'advanced'   => null,
						'visibility' =>
						array(
							'wp_check_role' => false,
							'wp_roles'      =>
							array(),
						),
					),
					'parent_id' => 73,
					'weight'    => 13,
					'system'    => false,
				),
				75 =>
				array(
					'id'        => 75,
					'name'      => 'group',
					'data'      =>
					array(
						'settings'   =>
						array(
							'inline'           => false,
							'separator'        => '',
							'separator_margin' => true,
							'nowrap'           => false,
						),
						'heading'    =>
						array(
							'label'           => 'custom_icon',
							'label_custom'    => __( 'Locations', 'directories-pro' ),
							'label_icon'      => 'fas fa-location-dot',
							'label_icon_size' => '',
						),
						'advanced'   => null,
						'visibility' =>
						array(
							'wp_check_role' => false,
							'wp_roles'      =>
							array(),
						),
					),
					'parent_id' => 0,
					'weight'    => 2,
					'system'    => false,
				),
				76 =>
				array(
					'id'        => 76,
					'name'      => 'view_filter_location_location',
					'data'      =>
					array(
						'settings'   =>
						array(
							'field_name'       => 'location_location',
							'filter_name'      => 'filter_location_location',
							'display_name'     => 'default',
							'name'             => 'location_location',
							'label'            => 'form',
							'label_custom'     => __( 'Locations', 'directories-pro' ),
							'label_icon'       => null,
							'label_icon_size'  => '',
							'label_as_heading' => false,
							'filter'           => 'view_term_list',
							'filter_settings'  =>
							array(
								'view_term_list' =>
								array(
									'depth'         => 2,
									'hide_empty'    => false,
									'hide_count'    => false,
									'icon'          => 1,
									'icon_size'     => 'sm',
									'andor'         => 'OR',
									'visible_count' => 10,
								),
							),
						),
						'heading'    => null,
						'advanced'   => null,
						'visibility' =>
						array(
							'wp_check_role' => false,
							'wp_roles'      =>
							array(),
						),
					),
					'parent_id' => 75,
					'weight'    => 3,
					'system'    => false,
				),
				77 =>
				array(
					'id'        => 77,
					'name'      => 'view_filter_location_address',
					'data'      =>
					array(
						'settings'   =>
						array(
							'field_name'       => 'location_address',
							'filter_name'      => 'filter_location_address',
							'display_name'     => 'default',
							'name'             => 'location_address',
							'label'            => 'form',
							'label_custom'     => __( 'Location', 'directories-pro' ),
							'label_icon'       => null,
							'label_icon_size'  => '',
							'label_as_heading' => false,
							'filter'           => 'location_address',
							'filter_settings'  =>
							array(
								'location_address' =>
								array(
									'disable_input'    => 1,
									'radius'           => '0',
									'disable_radius'   => false,
									'placeholder'      => '',
									'search_this_area' => 1,
									'search_my_loc'    => 1,
								),
							),
						),
						'heading'    => null,
						'advanced'   => null,
						'visibility' =>
						array(
							'wp_check_role' => false,
							'wp_roles'      =>
							array(),
						),
					),
					'parent_id' => 75,
					'weight'    => 4,
					'system'    => false,
				),
				78 =>
				array(
					'id'        => 78,
					'name'      => 'view_filter_voting_rating',
					'data'      =>
					array(
						'settings'   =>
						array(
							'field_name'       => 'voting_rating',
							'filter_name'      => 'filter_voting_rating',
							'display_name'     => 'default',
							'name'             => 'voting_rating',
							'label'            => 'form_icon',
							'label_custom'     => '',
							'label_icon'       => 'fas fa-star',
							'label_icon_size'  => '',
							'label_as_heading' => true,
							'filter'           => 'voting_rating',
							'filter_settings'  =>
							array(
								'voting_rating' =>
								array(
									'inline' => false,
								),
							),
						),
						'heading'    => null,
						'advanced'   => null,
						'visibility' =>
						array(
							'wp_check_role' => false,
							'wp_roles'      =>
							array(),
						),
					),
					'parent_id' => 0,
					'weight'    => 6,
					'system'    => false,
				),
			),
		),
		'a_z_filter' =>
		array(
			'name'     => 'a_z_filter',
			'type'     => 'filters',
			'data'     =>
			array(
				'label' => 'A - Z Filter',
			),
			'elements' =>
			array(
				79 =>
				array(
					'id'        => 79,
					'name'      => 'view_filter_post_title',
					'data'      =>
					array(
						'settings'   =>
						array(
							'field_name'      => 'post_title',
							'filter_name'     => 'filter_post_title',
							'display_name'    => 'a_z_filter',
							'name'            => 'post_title',
							'label'           => 'none',
							'filter'          => 'view_glossary',
							'filter_settings' =>
							array(
								'view_glossary' =>
								array(
									'type'       => 'buttons',
									'hide_empty' => false,
									'hide_count' => false,
								),
							),
						),
						'heading'    => null,
						'advanced'   => null,
						'visibility' =>
						array(
							'wp_check_role' => false,
						),
						'element'    => 'view_filter_post_title',
						'parent_id'  => '0',
					),
					'parent_id' => 0,
					'weight'    => 1,
					'system'    => false,
				),
			),
		),
	),
	'form'    =>
	array(
		'default' =>
		array(
			'name'     => 'default',
			'type'     => 'form',
			'data'     => null,
			'elements' =>
			array(
				95  =>
				array(
					'id'        => 95,
					'name'      => 'entity_form_wp_post_content',
					'data'      =>
					array(
						'settings'           =>
						array(
							'field_name'          => 'post_content',
							'settings'            =>
							array(),
							'label'               => 'Listing Description',
							'hide_label'          => false,
							'description'         => '',
							'default_value'       => null,
							'required'            => false,
							'admin_unrequired'    => false,
							'disabled'            => false,
							'weight'              => 10,
							'max_num_items'       => 1,
							'widget'              => 'wp_post_content',
							'widget_settings'     =>
							array(
								'rows' => 10,
							),
							'conditions'          =>
							array(),
							'_display'            => 'default',
							'_admin_only'         => false,
							'_user_register_show' => false,
							'_wp_roles'           => null,
						),
						'visibility'         => null,
						'advanced'           => null,
						'_entity_field_type' => 'wp_post_content',
					),
					'parent_id' => 0,
					'weight'    => 10,
					'system'    => true,
				),
				96  =>
				array(
					'id'        => 96,
					'name'      => 'entity_form_entity_title',
					'data'      =>
					array(
						'settings'           =>
						array(
							'field_name'          => 'post_title',
							'settings'            =>
							array(),
							'label'               => 'Title',
							'hide_label'          => false,
							'description'         => '',
							'default_value'       => null,
							'required'            => false,
							'admin_unrequired'    => false,
							'disabled'            => false,
							'weight'              => 0,
							'max_num_items'       => 1,
							'widget'              => 'entity_title',
							'widget_settings'     =>
							array(
								'minmax'      =>
								array(
									'min' => 0,
									'max' => 255,
								),
								'placeholder' => null,
							),
							'conditions'          =>
							array(),
							'_display'            => 'default',
							'_admin_only'         => false,
							'_user_register_show' => false,
							'_wp_roles'           => null,
						),
						'visibility'         => null,
						'advanced'           => null,
						'_entity_field_type' => 'entity_title',
					),
					'parent_id' => 0,
					'weight'    => 0,
					'system'    => true,
				),
				97  =>
				array(
					'id'        => 97,
					'name'      => 'entity_form_phone',
					'data'      =>
					array(
						'settings'           =>
						array(
							'field_name'          => 'field_phone',
							'settings'            =>
							array(
								'min_length'      => null,
								'max_length'      => null,
								'char_validation' => 'none',
								'mask'            => '(999) 999-9999',
							),
							'label'               => 'Phone Number',
							'hide_label'          => false,
							'description'         => '',
							'default_value'       => null,
							'required'            => false,
							'admin_unrequired'    => false,
							'disabled'            => false,
							'weight'              => 4,
							'max_num_items'       => 1,
							'widget'              => 'phone',
							'widget_settings'     =>
							array(
								'autopopulate' => '',
								'field_prefix' => null,
								'field_suffix' => null,
								'mask'         => null,
							),
							'conditions'          =>
							array(),
							'_display'            => 'default',
							'_admin_only'         => false,
							'_user_register_show' => false,
							'_wp_roles'           => null,
						),
						'visibility'         => null,
						'advanced'           => null,
						'_entity_field_type' => 'phone',
					),
					'parent_id' => 0,
					'weight'    => 4,
					'system'    => false,
				),
				98  =>
				array(
					'id'        => 98,
					'name'      => 'entity_form_phone',
					'data'      =>
					array(
						'settings'           =>
						array(
							'field_name'          => 'field_fax',
							'settings'            =>
							array(
								'min_length'      => null,
								'max_length'      => null,
								'char_validation' => 'none',
								'mask'            => '(999) 999-9999',
							),
							'label'               => 'Fax Number',
							'hide_label'          => false,
							'description'         => '',
							'default_value'       => null,
							'required'            => false,
							'admin_unrequired'    => false,
							'disabled'            => false,
							'weight'              => 5,
							'max_num_items'       => 1,
							'widget'              => 'phone',
							'widget_settings'     =>
							array(
								'autopopulate' => '',
								'field_prefix' => null,
								'field_suffix' => null,
								'mask'         => null,
							),
							'conditions'          =>
							array(),
							'_display'            => 'default',
							'_admin_only'         => false,
							'_user_register_show' => false,
							'_wp_roles'           => null,
						),
						'visibility'         => null,
						'advanced'           => null,
						'_entity_field_type' => 'phone',
					),
					'parent_id' => 0,
					'weight'    => 5,
					'system'    => false,
				),
				99  =>
				array(
					'id'        => 99,
					'name'      => 'entity_form_email',
					'data'      =>
					array(
						'settings'           =>
						array(
							'field_name'          => 'field_email',
							'settings'            =>
							array(
								'min_length'      => null,
								'max_length'      => null,
								'char_validation' => 'email',
								'check_mx'        => false,
							),
							'label'               => 'E-mail Address',
							'hide_label'          => false,
							'description'         => '',
							'default_value'       => null,
							'required'            => false,
							'admin_unrequired'    => false,
							'disabled'            => false,
							'weight'              => 6,
							'max_num_items'       => 1,
							'widget'              => 'email',
							'widget_settings'     =>
							array(
								'autopopulate' => false,
								'field_prefix' => null,
								'field_suffix' => null,
								'mask'         => null,
							),
							'conditions'          =>
							array(),
							'_display'            => 'default',
							'_admin_only'         => false,
							'_user_register_show' => false,
							'_wp_roles'           => null,
						),
						'visibility'         => null,
						'advanced'           => null,
						'_entity_field_type' => 'email',
					),
					'parent_id' => 0,
					'weight'    => 6,
					'system'    => false,
				),
				100 =>
				array(
					'id'        => 100,
					'name'      => 'entity_form_url',
					'data'      =>
					array(
						'settings'           =>
						array(
							'field_name'          => 'field_website',
							'settings'            =>
							array(
								'min_length'      => '',
								'max_length'      => '',
								'regex'           => '',
								'char_validation' => 'url',
							),
							'label'               => 'Website URL',
							'hide_label'          => false,
							'description'         => '',
							'default_value'       => null,
							'required'            => false,
							'admin_unrequired'    => false,
							'disabled'            => false,
							'weight'              => 7,
							'max_num_items'       => 1,
							'widget'              => 'url',
							'widget_settings'     =>
							array(
								'mask'         => '',
								'autopopulate' => false,
							),
							'conditions'          =>
							array(),
							'_display'            => 'default',
							'_admin_only'         => false,
							'_user_register_show' => false,
							'_wp_roles'           => null,
						),
						'visibility'         => null,
						'advanced'           => null,
						'_entity_field_type' => 'url',
					),
					'parent_id' => 0,
					'weight'    => 7,
					'system'    => false,
				),
				101 =>
				array(
					'id'        => 101,
					'name'      => 'entity_form_social_accounts',
					'data'      =>
					array(
						'settings'           =>
						array(
							'field_name'          => 'field_social_accounts',
							'settings'            =>
							array(
								'medias' =>
								array(
									0 => 'facebook',
									1 => 'twitter',
									2 => 'instagram',
									3 => 'rss',
								),
							),
							'label'               => 'Social Accounts',
							'hide_label'          => false,
							'description'         => '',
							'default_value'       => null,
							'required'            => false,
							'admin_unrequired'    => false,
							'disabled'            => false,
							'weight'              => 8,
							'max_num_items'       => 0,
							'widget'              => 'social_accounts',
							'widget_settings'     =>
							array(),
							'conditions'          =>
							array(),
							'_display'            => 'default',
							'_admin_only'         => false,
							'_user_register_show' => false,
							'_wp_roles'           => null,
						),
						'visibility'         => null,
						'advanced'           => null,
						'_entity_field_type' => 'social_accounts',
					),
					'parent_id' => 0,
					'weight'    => 8,
					'system'    => false,
				),
				102 =>
				array(
					'id'        => 102,
					'name'      => 'entity_form_range',
					'data'      =>
					array(
						'settings'           =>
						array(
							'field_name'          => 'field_price_range',
							'settings'            =>
							array(
								'decimals' => '2',
								'prefix'   => '$',
								'suffix'   => '',
								'min'      => null,
								'max'      => null,
							),
							'label'               => 'Price Range',
							'hide_label'          => false,
							'description'         => '',
							'default_value'       => null,
							'required'            => false,
							'admin_unrequired'    => false,
							'disabled'            => false,
							'weight'              => 12,
							'max_num_items'       => 1,
							'widget'              => 'range',
							'widget_settings'     =>
							array(
								'step' => '1',
							),
							'conditions'          =>
							array(),
							'_display'            => 'default',
							'_admin_only'         => false,
							'_user_register_show' => false,
							'_wp_roles'           => null,
						),
						'visibility'         => null,
						'advanced'           => null,
						'_entity_field_type' => 'range',
					),
					'parent_id' => 0,
					'weight'    => 12,
					'system'    => false,
				),
				103 =>
				array(
					'id'        => 103,
					'name'      => 'entity_form_wp_image',
					'data'      =>
					array(
						'settings'           =>
						array(
							'field_name'          => 'directory_photos',
							'settings'            =>
							array(),
							'label'               => 'Photos',
							'hide_label'          => false,
							'description'         => '',
							'default_value'       => null,
							'required'            => false,
							'admin_unrequired'    => false,
							'disabled'            => false,
							'weight'              => 10,
							'max_num_items'       => 0,
							'widget'              => 'wp_image',
							'widget_settings'     =>
							array(
								'max_file_size' => 2048,
							),
							'conditions'          =>
							array(),
							'_display'            => 'default',
							'_admin_only'         => false,
							'_user_register_show' => false,
							'_wp_roles'           => null,
						),
						'visibility'         => null,
						'advanced'           => null,
						'_entity_field_type' => 'wp_image',
					),
					'parent_id' => 0,
					'weight'    => 10,
					'system'    => true,
				),
				104 =>
				array(
					'id'        => 104,
					'name'      => 'entity_form_date',
					'data'      =>
					array(
						'settings'           =>
						array(
							'field_name'          => 'field_date_established',
							'settings'            =>
							array(
								'enable_time'       => false,
								'date_range_enable' => false,
								'date_range'        => null,
								'month_only'        => false,
							),
							'label'               => 'Date Established',
							'hide_label'          => false,
							'description'         => '',
							'default_value'       => null,
							'required'            => false,
							'admin_unrequired'    => false,
							'disabled'            => false,
							'weight'              => 14,
							'max_num_items'       => 1,
							'widget'              => 'date',
							'widget_settings'     =>
							array(
								'current_date_selected' => false,
							),
							'conditions'          =>
							array(),
							'_display'            => 'default',
							'_admin_only'         => false,
							'_user_register_show' => false,
							'_wp_roles'           => null,
						),
						'visibility'         => null,
						'advanced'           => null,
						'_entity_field_type' => 'date',
					),
					'parent_id' => 0,
					'weight'    => 14,
					'system'    => false,
				),
				105 =>
				array(
					'id'        => 105,
					'name'      => 'entity_form_video',
					'data'      =>
					array(
						'settings'           =>
						array(
							'field_name'          => 'field_videos',
							'settings'            =>
							array(),
							'label'               => 'Videos',
							'hide_label'          => false,
							'description'         => '',
							'default_value'       => null,
							'required'            => false,
							'admin_unrequired'    => false,
							'disabled'            => false,
							'weight'              => 11,
							'max_num_items'       => 0,
							'widget'              => 'video',
							'widget_settings'     =>
							array(),
							'conditions'          =>
							array(),
							'_display'            => 'default',
							'_admin_only'         => false,
							'_user_register_show' => false,
							'_wp_roles'           => null,
						),
						'visibility'         => null,
						'advanced'           => null,
						'_entity_field_type' => 'video',
					),
					'parent_id' => 0,
					'weight'    => 11,
					'system'    => false,
				),
				106 =>
				array(
					'id'        => 106,
					'name'      => 'entity_form_location_address',
					'data'      =>
					array(
						'settings'           =>
						array(
							'field_name'          => 'location_address',
							'settings'            =>
							array(
								'format' => '{street} {street2}, {city}, {province} {zip}, {country}',
							),
							'label'               => 'Location Address',
							'hide_label'          => false,
							'description'         => '',
							'default_value'       => null,
							'required'            => false,
							'admin_unrequired'    => false,
							'disabled'            => false,
							'weight'              => 3,
							'max_num_items'       => 1,
							'widget'              => 'location_address',
							'widget_settings'     =>
							array(
								'map_type'                => 'roadmap',
								'map_height'              => 300,
								'center_latitude'         => null,
								'center_longitude'        => null,
								'zoom'                    => 10,
								'custom_input_fields'     => false,
								'input_fields'            =>
								array(
									'options' =>
									array(
										'street'   => 'Address Line 1',
										'street2'  => 'Address Line 2',
										'zip'      => 'Postal / Zip Code',
										'city'     => 'City',
										'province' => 'State / Province / Region',
										'country'  => 'Country',
									),
									'default' =>
									array(
										0 => 'street',
										1 => 'zip',
										2 => 'city',
										3 => 'province',
									),
								),
								'input_country'           => null,
								'hide_timezone_if_no_map' => false,
								'hide_timezone_if'        => false,
								'find_btn_overwrite'      => false,
								'latlng_required'         => true,
							),
							'conditions'          =>
							array(),
							'_display'            => 'default',
							'_admin_only'         => false,
							'_user_register_show' => false,
							'_wp_roles'           => null,
						),
						'visibility'         => null,
						'advanced'           => null,
						'_entity_field_type' => 'location_address',
					),
					'parent_id' => 0,
					'weight'    => 3,
					'system'    => true,
				),
				107 =>
				array(
					'id'        => 107,
					'name'      => 'entity_form_entity_terms',
					'data'      =>
					array(
						'settings'           =>
						array(
							'field_name'          => 'directory_category',
							'settings'            =>
							array(),
							'_bundle_name'        => 'directory_dir_cat',
							'label'               => 'Categories',
							'hide_label'          => false,
							'description'         => '',
							'default_value'       => null,
							'required'            => false,
							'admin_unrequired'    => false,
							'disabled'            => false,
							'weight'              => 2,
							'max_num_items'       => 0,
							'widget'              => 'entity_term_select',
							'widget_settings'     =>
							array(
								'num'                 => 30,
								'select_hierarchical' => false,
								'depth'               => 5,
								'no_fancy'            => true,
							),
							'conditions'          =>
							array(),
							'_display'            => 'default',
							'_admin_only'         => false,
							'_user_register_show' => false,
							'_wp_roles'           => null,
						),
						'visibility'         => null,
						'advanced'           => null,
						'_entity_field_type' => 'entity_terms',
					),
					'parent_id' => 0,
					'weight'    => 2,
					'system'    => true,
				),
				108 =>
				array(
					'id'        => 108,
					'name'      => 'entity_form_entity_terms',
					'data'      =>
					array(
						'settings'           =>
						array(
							'field_name'          => 'directory_tag',
							'settings'            =>
							array(),
							'_bundle_name'        => 'directory_dir_tag',
							'label'               => 'Tags',
							'hide_label'          => false,
							'description'         => '',
							'default_value'       => null,
							'required'            => false,
							'admin_unrequired'    => false,
							'disabled'            => false,
							'weight'              => 98,
							'max_num_items'       => 0,
							'widget'              => 'entity_term_tagging',
							'widget_settings'     =>
							array(
								'enhanced_ui' => true,
								'tagging'     => true,
								'separator'   => ',',
								'placeholder' => null,
							),
							'conditions'          =>
							array(),
							'_display'            => 'default',
							'_admin_only'         => false,
							'_user_register_show' => false,
							'_wp_roles'           => null,
						),
						'visibility'         => null,
						'advanced'           => null,
						'_entity_field_type' => 'entity_terms',
					),
					'parent_id' => 0,
					'weight'    => 98,
					'system'    => true,
				),
			),
		),
	),
);
