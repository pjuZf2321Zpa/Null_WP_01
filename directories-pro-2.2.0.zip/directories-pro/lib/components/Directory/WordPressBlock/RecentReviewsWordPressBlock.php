<?php
namespace SabaiApps\Directories\Component\Directory\WordPressBlock;

use SabaiApps\Directories\Component\Entity\Model\Bundle;

class RecentReviewsWordPressBlock extends AbstractWordPressBlock {

	protected function _wordpressBlockInfo() {
		return array(
			'title'       => __( 'Recent Reviews', 'directories-pro' ),
			'description' => __( 'Displays a list of recently published reviews from your directory.', 'directories-pro' ),
			'package'     => 'directories-pro',
			'icon'        => 'admin-comments',
			'bundle_type' => 'review_review',
			'view_mode'   => 'masonry',
		);
	}

	protected function _getRenderSettings( Bundle $bundle ) {
		return array(
			'mode'          => 'masonry',
			'view_settings' => array(
				'no_js'      => true,
				'no_js_grid' => array(
					'masonry_cols'            => 'responsive',
					'masonry_cols_responsive' => array(
						'xs'  => 1,
						'sm'  => 2,
						'md'  => 'inherit',
						'lg'  => 3,
						'xl'  => 4,
						'xxl' => 'inherit',
					),
				),
				'query'      => array(
					'limit' => 8,
				),
				'sort'       => array(
					'default' => 'post_published',
					'options' => array( 'post_published' ),
				),
			),
		);
	}
}
