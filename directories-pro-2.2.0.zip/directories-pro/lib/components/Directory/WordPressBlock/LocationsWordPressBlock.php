<?php
namespace SabaiApps\Directories\Component\Directory\WordPressBlock;

use SabaiApps\Directories\Component\Entity\Model\Bundle;

class LocationsWordPressBlock extends AbstractWordPressBlock {

	protected function _wordpressBlockInfo() {
		return array(
			'title'       => _x( 'Locations', 'WordPress block name', 'directories-pro' ),
			'description' => __( 'Displays a list of locations with images from your directory.', 'directories-pro' ),
			'package'     => 'directories-pro',
			'icon'        => 'location',
			'bundle_type' => 'location_location',
			'view_mode'   => 'masonry',
		);
	}

	protected function _getRenderSettings( Bundle $bundle ) {
		return array(
			'mode'          => 'masonry',
			'view_settings' => array(
				'query'      => array(
					'fields' => array(
						'location_photo' => 1,
					),
					'limit'  => 12,
				),
				'sort'       => array(
					'default' => 'random',
					'options' => array( 'random' ),
				),
				'pagination' => array(
					'no_pagination' => true,
				),
				'display'    => 'summary-image_overlay',
			),
		);
	}
}
