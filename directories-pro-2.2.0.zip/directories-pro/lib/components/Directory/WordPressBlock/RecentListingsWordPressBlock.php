<?php
namespace SabaiApps\Directories\Component\Directory\WordPressBlock;

use SabaiApps\Directories\Component\Entity\Model\Bundle;

class RecentListingsWordPressBlock extends AbstractWordPressBlock {

	protected function _wordpressBlockInfo() {
		return array(
			'title'       => __( 'Recent Listings', 'directories-pro' ),
			'description' => __( 'Displays a list of recently published listings from your directory.', 'directories-pro' ),
			'package'     => 'directories-pro',
			'icon'        => 'excerpt-view',
			'bundle_type' => 'directory__listing',
			'view_mode'   => 'slider_carousel',
		);
	}

	protected function _getRenderSettings( Bundle $bundle ) {
		return array(
			'mode'          => 'slider_carousel',
			'view_settings' => array(
				'carousel_columns'    => 4,
				'carousel_controls'   => 1,
				'carousel_auto'       => 1,
				'carousel_auto_speed' => 3000,
				'carousel_pager'      => false,
				'carousel_fade'       => false,
				'pagination'          => array(
					'no_pagination' => 1,
				),
				'query'               => array(
					'limit' => 10,
				),
				'sort'                => array(
					'default' => 'post_published',
					'options' => array( 'post_published' ),
				),
			),
		);
	}
}
