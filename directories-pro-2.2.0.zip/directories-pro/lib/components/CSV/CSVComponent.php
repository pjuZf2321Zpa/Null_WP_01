<?php
namespace SabaiApps\Directories\Component\CSV;

use SabaiApps\Directories\Component\AbstractComponent;
use SabaiApps\Directories\Component\System;
use SabaiApps\Directories\Context;

class CSVComponent extends AbstractComponent implements
	System\IAdminRouter,
	System\ITools,
	IImporters,
	IExporters {

	const VERSION = '2.2.0', PACKAGE = 'directories-pro';

	public static function description() {
		return 'Lets you import and export content to and from CSV files.';
	}

	// WordPress-platform CSV field exporters/importers. Split out of
	// WordPressContent - a WP-content component shouldn't be needed just to CSV
	// export WP fields - and kept behind a platform check so a non-WordPress
	// platform build simply offers none.

	public function csvGetExporterNames() {
		if ( $this->_application->getPlatform()->getName() !== 'WordPress' ) {
			return array();
		}

		return array( 'wp_image', 'wp_file', 'wp_post_content', 'wp_term_description', 'wp_post_status', 'wp_post_parent', 'wp_shortcode' );
	}

	public function csvGetExporter( $name ) {
		return new Exporter\WPCSVExporter( $this->_application, $name );
	}

	public function csvGetImporterNames() {
		if ( $this->_application->getPlatform()->getName() !== 'WordPress' ) {
			return array();
		}

		return array( 'wp_image', 'wp_file', 'wp_post_content', 'wp_term_description', 'wp_post_status', 'wp_post_parent', 'wp_shortcode' );
	}

	public function csvGetImporter( $name ) {
		return new Importer\WPCSVImporter( $this->_application, $name );
	}

	public function hasVarDir() {
		return true;
	}

	public function systemAdminRoutes() {
		$routes = array();
		foreach ( array_keys( $this->_application->Entity_BundleTypes() ) as $bundle_type ) {
			if ( ( ! $admin_path = $this->_application->Entity_BundleTypeInfo( $bundle_type, 'admin_path' ) )
				|| isset( $routes[ $admin_path . '/export' ] ) // path added already
			) {
				continue;
			}

			$routes += array(

				$admin_path . '/import' => array(
					'controller'     => 'Import',
					'title_callback' => true,
					'callback_path'  => 'import',
				),

				$admin_path . '/export' => array(
					'controller'     => 'Export',
					'title_callback' => true,
					'callback_path'  => 'export',
				),
			);
		}
		return $routes;
	}

	public function systemOnAccessAdminRoute( Context $context, $path, $accessType, array &$route ) {}

	public function systemAdminRouteTitle( Context $context, $path, $titleType, array $route ) {
		switch ( $path ) {

			case 'import':
				return $this->_application->Filter(
					'csv_admin_import_title',
					__( 'Import', 'directories-pro' ),
					array( $context, $context->bundle, $titleType )
				);

			case 'export':
				return $this->_application->Filter(
					'csv_admin_export_title',
					__( 'Export', 'directories-pro' ),
					array( $context, $context->bundle, $titleType )
				);
		}
	}

	protected function _isCsvEnabled( $bundle ) {
		return ! $this->_application->Entity_BundleTypeInfo( $bundle->type, 'csv_disable' );
	}

	public function systemGetToolNames() {
		return array( 'csv_export', 'csv_import' );
	}

	public function systemGetTool( $name ) {
		switch ( $name ) {
			case 'csv_export':
				return new SystemTool\ExportSystemTool( $this->_application, $name );

			case 'csv_import':
				return new SystemTool\ImportSystemTool( $this->_application, $name );

		}
	}
}
