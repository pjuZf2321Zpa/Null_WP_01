<?php
namespace SabaiApps\Directories\Component\CSV\Importer;

use SabaiApps\Directories\Component\Entity\Model\Field;
use SabaiApps\Directories\Component\Entity\Model\Bundle;

interface IImporter {

	public function csvImporterInfo( $key = null );
	public function csvImporterColumns( Field $field );
	public function csvImporterSettingsForm( Field $field, array $settings, $column, $enclosure, array $parents = array() );
	public function csvImporterDoImport( Field $field, array $settings, $column, $value, &$formStorage, array &$logs );
	public function csvImporterSupports( Bundle $bundle, Field $field );
	public function csvImporterOnComplete( Field $field, array $settings, $column, &$formStorage, array &$logs );
}
