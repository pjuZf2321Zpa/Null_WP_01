<?php
namespace SabaiApps\Directories\Component\CSV\Exporter;

use SabaiApps\Directories\Component\Entity\Model\Field;
use SabaiApps\Directories\Component\Entity\Model\Bundle;

interface IExporter {

	public function csvExporterInfo( $key = null );
	public function csvExporterColumns( Field $field );
	public function csvExporterSettingsForm( Field $field, array $settings, $column, $enclosure, array $parents = array() );
	public function csvExporterDoExport( Field $field, array $settings, $value, array $columns, array &$formStorage, array &$logs );
	public function csvExporterSupports( Bundle $bundle, Field $field );
	public function csvExporterOnComplete( Field $field, array $settings, array $columns, &$formStorage, array &$logs );
}
