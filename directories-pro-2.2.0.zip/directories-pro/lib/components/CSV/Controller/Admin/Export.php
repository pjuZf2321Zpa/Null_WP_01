<?php
namespace SabaiApps\Directories\Component\CSV\Controller\Admin;

use SabaiApps\Directories\Context;
use SabaiApps\Directories\Component\System\Controller\Admin\RunToolWithProgress;

class Export extends RunToolWithProgress {

	protected $_ajaxSubmitStepForm = false;

	protected function _getToolName( Context $context ) {
		return 'csv_export';
	}
}
