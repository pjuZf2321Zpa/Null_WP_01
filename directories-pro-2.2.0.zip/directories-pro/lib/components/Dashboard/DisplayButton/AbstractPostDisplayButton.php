<?php
namespace SabaiApps\Directories\Component\Dashboard\DisplayButton;

use SabaiApps\Directories\Component\Entity\Type\IEntity;
use SabaiApps\Directories\Component\Entity\Model\Bundle;

abstract class AbstractPostDisplayButton extends AbstractDisplayButton {

	protected function _getUrl( Bundle $bundle, IEntity $entity, array $settings, $displayName ) {
		$path = $this->_route === 'edit' ? '/' : '/' . $this->_route;

		if ( $displayName === 'dashboard_row' ) {
			$this->_params['from_dashboard'] = 1;
		}

		return $this->_application->Dashboard_Panels_postsPanelUrl( $entity, '/posts/' . $entity->getId() . $path, $this->_params, true );
	}
}
