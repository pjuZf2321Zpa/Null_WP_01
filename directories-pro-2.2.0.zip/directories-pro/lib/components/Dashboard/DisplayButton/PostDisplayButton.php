<?php
namespace SabaiApps\Directories\Component\Dashboard\DisplayButton;

use SabaiApps\Directories\Application;
use SabaiApps\Directories\Component\Entity\Model\Bundle;
use SabaiApps\Directories\Component\Entity\Type\IEntity;
use SabaiApps\Directories\Exception;

class PostDisplayButton extends AbstractPostDisplayButton {

	public function __construct( Application $application, $name ) {
		switch ( $name ) {
			case 'dashboard_posts_edit':
				$route = 'edit';
				break;
			case 'dashboard_posts_delete':
				$route = 'delete';
				break;
			case 'dashboard_posts_submit':
				$route = 'submit';
				break;
			case 'dashboard_posts_assign':
				$route = 'assign';
				break;
			default:
				throw new Exception\InvalidArgumentException();
		}
		parent::__construct( $application, $name, $route );
	}

	protected function _displayButtonInfo( Bundle $bundle ) {
		switch ( $this->_name ) {
			case 'dashboard_posts_edit':
				return array(
					'label'            => __( 'Edit post button', 'directories-pro' ),
					'labellable'       => false,
					'default_settings' => array(
						'_color' => 'outline-secondary',
						'_icon'  => 'fas fa-pen-to-square',
					),
				);
			case 'dashboard_posts_delete':
				return array(
					'label'            => __( 'Delete post button', 'directories-pro' ),
					'labellable'       => false,
					'default_settings' => array(
						'_color' => 'danger',
						'_icon'  => 'fas fa-trash-can',
					),
				);
			case 'dashboard_posts_submit':
				return array(
					'label'            => __( 'Submit post button', 'directories-pro' ),
					'labellable'       => true,
					'default_settings' => array(
						'_color' => 'outline-secondary',
						'_icon'  => 'fas fa-plus',
						'_label' => __( 'Submit for review', 'directories-pro' ),
					),
					'overlayable'      => false,
				);
			case 'dashboard_posts_assign':
				$permissions = $this->_application->Entity_Permissions( $bundle );
				if ( empty( $permissions['entity_edit_others'] ) ) {
					return false;
				}

				return array(
					'label'            => __( 'Change author button', 'directories-pro' ),
					'labellable'       => true,
					'default_settings' => array(
						'_color' => 'outline-secondary',
						'_icon'  => 'fas fa-user-pen',
						'_label' => __( 'Change author', 'directories-pro' ),
					),
					'overlayable'      => false,
					'description'      => sprintf(
						__( 'Requires the "%s" permission.', 'directories-pro' ),
						$permissions['entity_edit_others']['title']
					),
				);
		}
	}

	protected function _getLabel( Bundle $bundle, IEntity $entity, array $settings ) {
		switch ( $this->_name ) {
			case 'dashboard_posts_edit':
				return __( 'Edit', 'directories-pro' );
			case 'dashboard_posts_delete':
				return __( 'Delete', 'directories-pro' );
			case 'dashboard_posts_submit':
				return $settings['_label'];
			case 'dashboard_posts_assign':
				return $settings['_label'];
		}
	}

	public function displayButtonSettingsForm( Bundle $bundle, array $settings, $displayName, array $parents = array() ) {
		switch ( $this->_name ) {
			case 'dashboard_posts_edit':
				return array(
					'modal' => array(
						'#type'          => 'checkbox',
						'#title'         => __( 'Show form in modal window', 'directories-pro' ),
						'#default_value' => ! empty( $settings['modal'] ),
						'#horizontal'    => true,
					),
				);
		}
	}

	protected function _isModal( Bundle $bundle, IEntity $entity, array $settings ) {
		switch ( $this->_name ) {
			case 'dashboard_posts_edit':
				return empty( $settings['modal'] ) ? false : array( 'size' => 'xl' );
			case 'dashboard_posts_delete':
				return array( 'danger' => true );
			case 'dashboard_posts_submit':
				return array( 'size' => 'lg' );
			case 'dashboard_posts_assign':
				return array( 'size' => 'lg' );
		}
	}

	protected function _loadModalAssets( Bundle $bundle, IEntity $entity, array $settings ) {
		if ( $this->_name === 'dashboard_posts_edit' ) {
			$this->_application->Entity_Form_loadAssets( $bundle );
		} else {
			parent::_loadModalAssets( $bundle, $entity, $settings );
		}
	}
}
