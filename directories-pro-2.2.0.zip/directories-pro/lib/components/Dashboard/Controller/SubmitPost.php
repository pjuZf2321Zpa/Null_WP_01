<?php
namespace SabaiApps\Directories\Component\Dashboard\Controller;

use SabaiApps\Directories\Component\FrontendSubmit;
use SabaiApps\Directories\Component\Form;
use SabaiApps\Directories\Context;
use SabaiApps\Directories\Component\Entity\Model\Bundle;

class SubmitPost extends FrontendSubmit\Controller\AbstractSubmitEntity {

	protected function _getSteps( Context $context, array &$formStorage ) {
		if ( ! isset( $formStorage['from_dashboard'] ) ) {
			$formStorage['from_dashboard'] = $context->getRequest()->asBool( 'from_dashboard' );
		}
		return array( 'submit' => array( 'order' => 3 ) );
	}

	public function _getFormForStepSubmit( Context $context, array &$formStorage ) {
		if ( $context->action === 'submit' ) {
			$bundle = $this->_getBundle( $context, $formStorage );

			// Check if submission is restricted
			if ( ! $this->_isSubmitAllowed( $context, $formStorage, $bundle ) ) {
				return false;
			}
		}

		$form              = array();
		$form['#header'][] = '<div class="' . DRTS_BS_PREFIX . 'alert ' . DRTS_BS_PREFIX . 'alert-info">' . $this->H( __( 'Press the button below to submit for review.', 'directories-pro' ) ) . '</div>';

		return $form;
	}

	public function _submitFormForStepSubmit( Context $context, Form\Form $form ) {
		$bundle = $this->_getBundle( $context, $form->storage );
		$status = $this->_getEntityStatus( $context, $form, $bundle );
		$values = $this->_getEntityValues( $context, $form, $bundle );
		$this->_updateSubmittedEntity( $context, $status, $values );
	}

	protected function _getEntityValues( Context $context, Form\Form $form, Bundle $bundle ) {
		$values = array();
		if ( $level = $this->_hasEntityLevel( $context, $form->storage, $bundle ) ) {
			$values['entity_level'] = $level;
		}
		return $values;
	}

	protected function _updateSubmittedEntity( Context $context, $status, array $values = array() ) {
		if ( ! $context->entity->isPublished() ) { // keep published
			$_values = $values;
			if ( $status !== $context->entity->getStatus() ) {
				$_values['status'] = $status;
			}
			if ( ! empty( $_values ) ) {
				$context->entity = $this->Entity_Save( $context->entity, $_values );
			}
		}
		// Update status of translated posts
		foreach ( $this->Entity_Translations( $context->entity, false ) as $_entity ) {
			if ( ! $_entity->isPublished() ) { // keep published
				$_values = $values;
				if ( $status !== $_entity->getStatus() ) {
					$_values['status'] = $status;
				}
				if ( ! empty( $_values ) ) {
					$this->Entity_Save( $_entity, $_values );
				}
			}
		}
	}

	protected function _getEntityStatus( Context $context, Form\Form $form, Bundle $bundle ) {
		if ( ! empty( $bundle->info['public'] )
			&& ! $this->HasPermission( 'entity_publish_' . $bundle->name )
		) {
			$status = 'pending';
		} else {
			$status = 'publish';
		}
		return $this->Entity_Status( $bundle->entitytype_name, $status );
	}

	protected function _complete( Context $context, array $formStorage ) {
		$context->setSuccess( $this->_getSuccessUrl( $context, $formStorage ) );
		if ( $context->entity->getType() === 'post' ) {
			if ( $context->entity->isPending() ) {
				$context->addFlash( __( 'Your item has been submitted successfully. We will review your submission and publish it when it is approved.', 'directories-pro' ) );
			} elseif ( $context->entity->isPublished() ) {
				$context->addFlash( __( 'Your item has been submitted and published successfully.', 'directories-pro' ) );
			}
		}
	}

	protected function _getSuccessUrl( Context $context, array $formStorage ) {
		if ( empty( $formStorage['from_dashboard'] ) ) {
			if ( $url = $this->Filter( 'dashboard_submit_post_success_url', null, array( $context->entity ) ) ) {
				return $url;
			}

			return $this->Entity_PermalinkUrl( $context->entity );
		}

		return $this->Dashboard_Panels_postsPanelUrl( $context->entity );
	}
}
