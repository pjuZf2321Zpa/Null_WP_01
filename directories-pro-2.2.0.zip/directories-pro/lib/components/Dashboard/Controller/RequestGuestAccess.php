<?php
namespace SabaiApps\Directories\Component\Dashboard\Controller;

use SabaiApps\Directories\Context;
use SabaiApps\Directories\Component\Form;

class RequestGuestAccess extends Form\Controller {

	protected function _doGetFormSettings( Context $context, array &$formStorage ) {
		$this->_submitButtons['submit'] = array(
			'#btn_label'  => ucfirst( __( 'Request Guest Access', 'directories-pro' ) ),
			'#btn_color'  => 'primary',
			'#btn_size'   => 'lg',
			'#attributes' => array( 'data-modal-title' => '' ), // prevents modal title from changing on submit error
		);
		return $this->Dashboard_GuestAccess_requestActivationForm() + array(
			'#submit' => array(
				9 => array( // weight
					function ( Form\Form $form ) {
						$this->Dashboard_GuestAccess_requestActivation( $form->values );
					},
				),
			),
		);
	}

	public function submitForm( Form\Form $form, Context $context ) {
		$context->setSuccess()
			->addFlash( __( 'Guest access URL has been sent to your e-mail address.', 'directories-pro' ), 'success', 60000 );
	}
}
