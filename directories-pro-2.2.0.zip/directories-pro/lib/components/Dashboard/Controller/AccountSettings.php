<?php
namespace SabaiApps\Directories\Component\Dashboard\Controller;

use SabaiApps\Directories\Controller;
use SabaiApps\Directories\Context;

class AccountSettings extends Controller {

	protected function _doExecute( Context $context ) {
		$account_settings_sections = $this->Filter(
			'dashboard_account_settings_sections',
			array(
				'change_password' => array(
					'title'       => __( 'Change password', 'directories-pro' ),
					'description' => __( 'Change your account password.', 'directories-pro' ),
					'url'         => $this->_application->Dashboard_Panels_panelUrl( 'account', 'settings', '/settings/change_password' ),
				),
				'delete_account'  => array(
					'title'       => __( 'Delete account', 'directories-pro' ),
					'description' => __( 'Delete your account permanently.', 'directories-pro' ),
					'url'         => $this->_application->Dashboard_Panels_panelUrl( 'account', 'settings', '/settings/delete_account' ),
					'btn_color'   => 'danger',
				),
			),
			array( $context )
		);

		if ( ! empty( $context->section ) ) {
			if ( ! isset( $account_settings_sections[ $context->section ] )
				|| empty( $account_settings_sections[ $context->section ]['callback'] )
			) {
				$context->setNotFoundError();
				return;
			}
			$callback = $account_settings_sections[ $context->section ]['callback'];
			if ( empty( $callback )
				|| ! is_callable( $callback )
			) {
				$context->setNotFoundError();
				return;
			}
			$context->content = call_user_func_array( $callback, array( $context ) );
		} else {
			foreach ( array_keys( $account_settings_sections ) as $section ) {
				if ( isset( $account_settings_sections[ $section ]['html'] ) ) {
					continue;
				}

				if ( isset( $account_settings_sections[ $section ]['description'] ) ) {
					$account_settings_sections[ $section ]['html'] = '<p>' . $this->Htmlize( $account_settings_sections[ $section ]['description'] ) . '</p>';
				}
				if ( isset( $account_settings_sections[ $section ]['section_callback'] )
					&& is_callable( $account_settings_sections[ $section ]['section_callback'] )
				) {
					$account_settings_sections[ $section ]['html'] .= call_user_func_array( $account_settings_sections[ $section ]['section_callback'], array( $context ) );
				}
			}
			$context->addTemplate( 'dashboard_account_settings' );
			$context->setAttributes(
				array(
					'sections' => $account_settings_sections,
				)
			);
		}
	}
}
