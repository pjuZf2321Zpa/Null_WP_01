<?php
namespace SabaiApps\Directories\Component\Dashboard\Panel;

use SabaiApps\Directories\Application;
use SabaiApps\Framework\User\AbstractIdentity;

class CustomPanel extends AbstractPanel {

	protected $_customName;

	public function __construct( Application $application, $name ) {
		parent::__construct( $application, $name );
		$this->_customName = substr( $name, strlen( 'custom_' ) );
	}

	protected function _dashboardPanelInfo() {
		return $this->_application->Filter( 'dashboard_panel_custom_info', array(), array( $this->_customName ) ) + array(
			'weight' => 99,
		);
	}

	protected function _dashboardPanelLinks( array $settings, ?AbstractIdentity $identity = null ) {
		if ( isset( $identity ) ) {
			return; // Do not show if public dashboard
		}

		return $this->_application->Filter( 'dashboard_panel_custom_links', array(), array( $this->_customName ) );
	}

	public function dashboardPanelSettingsForm( array $settings, array $parents ) {
		return $this->_application->Filter( 'dashboard_panel_custom_settings', array(), array( $this->_customName, $settings, $parents ) );
	}

	public function dashboardPanelContent( $link, array $settings, array $params, ?AbstractIdentity $identity = null ) {
		if ( isset( $identity ) ) {
			return; // Do not show if public dashboard
		}

		return $this->_application->Filter( 'dashboard_panel_custom_content', '', array( $this->_customName, $link, $settings ) );
	}
}
