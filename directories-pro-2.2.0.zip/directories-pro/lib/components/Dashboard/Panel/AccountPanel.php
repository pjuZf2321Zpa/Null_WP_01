<?php
namespace SabaiApps\Directories\Component\Dashboard\Panel;

use SabaiApps\Framework\User\AbstractIdentity;

class AccountPanel extends AbstractPanel {

	protected function _dashboardPanelInfo() {
		return array(
			'label'  => __( 'Account', 'directories-pro' ),
			'weight' => 10,
			'wp'     => false,
		);
	}

	protected function _dashboardPanelLinks( array $settings, ?AbstractIdentity $identity = null ) {
		if ( isset( $identity ) ) {
			return; // Do not show if public dashboard
		}

		$ret       = array();
		$weight    = 0;
		$all_pages = $this->_accountPanelPages();
		$pages     = isset( $settings['pages']['default'] ) ? $settings['pages']['default'] : array_keys( $all_pages );
		foreach ( $pages as $page ) {
			if ( ! isset( $all_pages[ $page ] ) ) {
				continue;
			}

			$ret[ $page ] = $all_pages[ $page ];
			if ( isset( $settings['pages']['options'][ $page ] ) ) {
				$ret[ $page ]['title']           = $settings['pages']['options'][ $page ];
				$ret[ $page ]['title_is_custom'] = true;
			}
			$ret[ $page ]['weight'] = ++$weight;
		}
		return $ret;
	}

	protected function _accountPanelPages() {
		$pages = array(
			'settings' => array(
				'title'  => __( 'Account settings', 'directories-pro' ),
				'icon'   => 'fas fa-user-gear',
				'weight' => 50,
			),
		);

		return $this->_application->Filter( 'dashboard_account_panel_pages', $pages );
	}

	public function dashboardPanelSettingsForm( array $settings, array $parents ) {
		$options = array();
		foreach ( $this->_accountPanelPages() as $link_name => $link ) {
			$options[ $link_name ] = isset( $settings['pages']['options'][ $link_name ] ) ? $settings['pages']['options'][ $link_name ] : $link['title'];
		}
		$form = array(
			'pages' => array(
				'#title'                  => __( 'Select subpanels', 'directories-pro' ),
				'#type'                   => 'options',
				'#horizontal'             => true,
				'#disable_add'            => true,
				'#disable_icon'           => true,
				'#disable_add_csv'        => true,
				'#multiple'               => true,
				'#options_value_disabled' => true,
				'#default_value'          => array(
					'options' => $options,
					'default' => isset( $settings['pages']['default'] ) ? $settings['pages']['default'] : array_keys( $options ),
				),
				'#options_placeholder'    => $options,
			),
		);

		return $form;
	}

	public function dashboardPanelContent( $link, array $settings, array $params, ?AbstractIdentity $identity = null ) {
		if ( isset( $identity ) ) {
			return;
		}

		return $this->_application->getPlatform()->render(
			$this->_application->Dashboard_Panels_panelUrl( 'account', $link, '/' . $link, array(), true, $identity ),
			array( 'is_dashboard' => false ) // prevent rendering duplicate panel sections on reload panel
		);
	}
}
