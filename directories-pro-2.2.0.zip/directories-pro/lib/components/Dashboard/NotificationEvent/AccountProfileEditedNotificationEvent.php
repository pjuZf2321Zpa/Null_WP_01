<?php
namespace SabaiApps\Directories\Component\Dashboard\NotificationEvent;

use SabaiApps\Directories\Component\Entity\Type\IEntity;
use SabaiApps\Directories\Exception;
use SabaiApps\Framework\User\RegisteredIdentity;

class AccountProfileEditedNotificationEvent extends AbstractAccountNotificationEvent {

	protected function _notificationEventInfo() {
		return array(
			'label'            => _x( 'Profile edited by user', 'notification event', 'directories-pro' ),
			'global'           => true,
			'default_settings' => array(),
			'actions'          => array(
				'user_edit_profile_success',
			),
			'weight'           => 15,
			'testable'         => true,
		);
	}

	protected function _getDefaultNotificationLabel() {
		return __( 'Profile edited by user', 'directories-pro' );
	}

	protected function _getDefaultNotificationBody() {
		return array(
			__( 'The following user profile has been updated on your site.', 'directories-pro' ),
			'%user_username%' . PHP_EOL . '%user_email%',
		);
	}

	protected function _extractIdentity( array $params ) {
		if ( ! isset( $params[0] ) ) {
			throw new Exception\RuntimeException( 'Invalid entity.' );
		}

		if ( $params[0] instanceof RegisteredIdentity ) {
			return parent::_extractIdentity( $params ); // came from testing
		}

		if ( ! $params[0] instanceof IEntity
			|| ( ! $identity = $this->_application->UserIdentity( $params[0]->getId() ) )
		) {
			throw new Exception\RuntimeException( 'Invalid entity.' );
		}

		return $identity;
	}
}
