<?php
namespace SabaiApps\Directories\Component\Dashboard\NotificationEvent;

use SabaiApps\Directories\Component\Entity\Type\IEntity;
use SabaiApps\Directories\Exception;
use SabaiApps\Directories\Component\Notification\Event\AbstractEntityEvent;

abstract class AbstractPostNotificationEvent extends AbstractEntityEvent {

	protected $_isForAdmin = true;

	public function notificationEventMessages( array $settings, array $params ) {
		if ( ! isset( $params[0] )
			|| ! $params[0] instanceof IEntity
		) {
			throw new Exception\RuntimeException( 'Invalid entity.' );
		}

		if ( ! $this->_isBundleEnabled( $params[0], $settings ) ) {
			return;
		}

		return array( array( 'entity' => $params[0] ) );
	}

	public function notificationEventParams( array $settings, array $paramSettings ) {
		$params = array( '_action' => $this->notificationEventInfo( 'actions' )[0] );
		if ( ! $entity = $this->_application->Entity_Entity( 'post', $paramSettings['entity'] ) ) {
			throw new Exception\RuntimeException( 'Failed fetching post. ID: ' . $paramSettings['entity'] );
		}
		$params[0] = $entity;
		return $params;
	}
}
