<?php
namespace SabaiApps\Directories\Component\Dashboard\NotificationEvent;

class PostEditedNotificationEvent extends AbstractPostNotificationEvent {

	protected function _notificationEntityEventInfo() {
		return array(
			'label'            => _x( 'Post edited by user', 'notification event', 'directories-pro' ) . ' - %s',
			'default_settings' => array(),
			'actions'          => array(
				'dashboard_edit_post_success',
			),
			'weight'           => 10,
			'testable'         => true,
		);
	}

	protected function _getDefaultNotificationLabel() {
		return sprintf( __( '%s has been edited', 'directories-pro' ), $this->_getContentTypeLabel() );
	}

	protected function _getDefaultNotificationBody() {
		return array(
			sprintf( __( 'The following %s has been updated by the user.', 'directories-pro' ), strtolower( $singular = $this->_getContentTypeLabel() ), $singular ),
			'%title%' . PHP_EOL . '%admin_permalink_url%',
		);
	}
}
