<?php
namespace SabaiApps\Directories\Component\Dashboard\NotificationEvent;

class AccountPasswordChangedNotificationEvent extends AbstractAccountNotificationEvent {

	protected function _notificationEventInfo() {
		return array(
			'label'            => __( 'Account password changed by user', 'directories-pro' ),
			'global'           => true,
			'default_settings' => array(),
			'actions'          => array(
				'dashboard_change_password_success',
			),
			'weight'           => 16,
			'testable'         => true,
		);
	}

	protected function _getDefaultNotificationLabel() {
		return __( 'Account password changed by user', 'directories-pro' );
	}

	protected function _getDefaultNotificationBody() {
		return array(
			__( 'The following user has changed the account password.', 'directories-pro' ),
			'%user_username%' . PHP_EOL . '%user_email%',
		);
	}
}
