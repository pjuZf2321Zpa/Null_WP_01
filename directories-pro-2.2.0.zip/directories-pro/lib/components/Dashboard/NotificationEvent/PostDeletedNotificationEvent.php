<?php
namespace SabaiApps\Directories\Component\Dashboard\NotificationEvent;

class PostDeletedNotificationEvent extends AbstractPostNotificationEvent {

	protected function _notificationEntityEventInfo() {
		return array(
			'label'            => _x( 'Post deleted by user', 'notification event', 'directories-pro' ) . ' - %s',
			'default_settings' => array(),
			'actions'          => array(
				'dashboard_delete_post_success',
			),
			'weight'           => 11,
			'testable'         => true,
		);
	}

	protected function _getDefaultNotificationLabel() {
		return sprintf( __( '%s has been deleted', 'directories-pro' ), $this->_getContentTypeLabel() );
	}

	protected function _getDefaultNotificationBody() {
		return array(
			sprintf( __( 'The following %s has been deleted by the user.', 'directories-pro' ), strtolower( $singular = $this->_getContentTypeLabel() ), $singular ),
			'%title%' . PHP_EOL . '%admin_permalink_url%',
		);
	}
}
