<?php
namespace SabaiApps\Directories\Component\Dashboard\NotificationEvent;

class AccountDeletedNotificationEvent extends AbstractAccountNotificationEvent {


	protected function _notificationEventInfo() {
		return array(
			'label'            => __( 'Account deleted by user', 'directories-pro' ),
			'global'           => true,
			'default_settings' => array(),
			'actions'          => array(
				'dashboard_delete_account_success',
			),
			'weight'           => 17,
			'testable'         => true,
		);
	}

	protected function _getDefaultNotificationLabel() {
		return __( 'Account deleted by user', 'directories-pro' );
	}

	protected function _getDefaultNotificationBody() {
		return array(
			__( 'The following account has been deleted by the user.', 'directories-pro' ),
			'%user_username%' . PHP_EOL . '%user_email%',
		);
	}
}
