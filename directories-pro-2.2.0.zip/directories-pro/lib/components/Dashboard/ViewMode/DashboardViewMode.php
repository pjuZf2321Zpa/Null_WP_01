<?php
namespace SabaiApps\Directories\Component\Dashboard\ViewMode;

use SabaiApps\Directories\Component\View\Mode\AbstractMode;
use SabaiApps\Directories\Component\Entity\Model\Bundle;
use SabaiApps\Directories\Request;

class DashboardViewMode extends AbstractMode {

	protected function _viewModeInfo() {
		return array(
			'label'            => 'Dashboard',
			'icon'             => 'fas fa-tasks',
			'default_settings' => array(
				'template' => 'view_entities_table',
				'display'  => 'dashboard_row',
			),
			'displays'         => $this->_getDisplays(),
			'system'           => true,
		);
	}

	protected function _getDisplays() {
		return array(
			'dashboard_row' => _x( 'Dashboard Row', 'display name', 'directories-pro' ),
		);
	}

	public function viewModeSupports( Bundle $bundle ) {
		return parent::viewModeSupports( $bundle )
			&& $bundle->entitytype_name === 'post'
			&& ! $this->_application->Entity_BundleTypeInfo( $bundle->type, 'dashboard_disable' )
			&& ! $this->_application->Entity_BundleTypeInfo( $bundle->type, 'frontendsubmit_disable' );
	}

	public function viewModeOnInitSettings( Bundle $bundle, array &$viewSettings, Request $request ) {
		if ( ! $status = $request->asStr( 'status' ) ) {
			return;
		}

		switch ( $status ) {
			case 'publish':
			case 'pending':
			case 'draft':
			case 'private':
				$viewSettings['view_settings']['query']['status'] = array( $status );
				if ( ! empty( $viewSettings['view_settings']['query']['status_others'] ) ) {
					if ( ! in_array( $status, $viewSettings['view_settings']['query']['status_others'] ) ) {
						unset( $viewSettings['view_settings']['query']['status_others'] );
					} else {
						$viewSettings['view_settings']['query']['status_others'] = array( $status );
					}
				}
				break;
			case 'expired':
			case 'deactivated':
			case 'expiring':
				if ( ! $this->_application->isComponentLoaded( 'Payment' )
					|| empty( $bundle->info['payment_enable'] )
				) {
					return;
				}

				switch ( $status ) {
					case 'expired':
						$viewSettings['view_settings']['query']['fields']['payment_plan'] = -1;
						break;
					case 'deactivated':
						$viewSettings['view_settings']['query']['fields']['payment_plan'] = -2;
						break;
					case 'expiring':
						$viewSettings['view_settings']['query']['fields']['payment_plan'] = -3;
						break;
				}
				break;
			default:
		}
	}

	public function viewModeNav( Bundle $bundle, array $settings ) {
		if ( empty( $settings['filter']['show'] ) ) {
			return array(
				array(
					array( array( 'num' ), array( 'status', 'sort', 'add' ) ),
					array( array(), array(), array() ),
				), // header
				array(
					array( array(), array(), array() ),
					array( array(), array(), array( 'perpages', 'pagination' ) ),
				), // footer
			);
		}

		return array(
			array(
				array( array( 'filters' ) ),
				array( array( 'filter' ), array( 'status', 'sort', 'add' ) ),
			), // header
			array(
				array( array(), array(), array() ),
				array( array( 'num' ), array( 'perpages', 'pagination' ) ),
			), // footer
		);
	}
}
