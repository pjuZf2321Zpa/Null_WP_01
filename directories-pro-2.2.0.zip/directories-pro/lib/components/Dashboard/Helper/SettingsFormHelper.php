<?php
namespace SabaiApps\Directories\Component\Dashboard\Helper;

use SabaiApps\Directories\Application;

class SettingsFormHelper {

	public function help( Application $application, array $config, $publicDashboardAllowed, array $parents ) {
		$panel_options = $original_panel_labels = $panel_label_disabled = $panel_settings_form = array();
		foreach ( $application->Dashboard_Panels( false ) as $panel_name => $panel ) {
			$ipanel                               = $application->Dashboard_Panels_impl( $panel_name );
			$original_panel_labels[ $panel_name ] = $panel_options[ $panel_name ] = $ipanel->dashboardPanelLabel();
			if ( ! $panel['labellable'] ) {
				$panel_label_disabled[] = $panel_name;
			} elseif ( isset( $config['panel']['panels']['options'][ $panel_name ] ) ) {
					$panel_options[ $panel_name ] = $config['panel']['panels']['options'][ $panel_name ];
			}
			$panel_settings = isset( $config['panel']['panel_settings'][ $panel_name ] ) ? $config['panel']['panel_settings'][ $panel_name ] : array();
			if ( $_panel_settings_form = $ipanel->dashboardPanelSettingsForm( $panel_settings, array_merge( $parents, array( 'panel', 'panel_settings', $panel_name ) ) ) ) {
				$panel_settings_form[ $panel_name ] = array(
					'#title'  => sprintf( __( 'Dashboard Panel Settings (%s)', 'directories-pro' ), $original_panel_labels[ $panel_name ] ),
					'#class'  => 'drts-form-label-lg',
					'#states' => array(
						'visible' => array(
							sprintf( '[name="%s[default][]"][data-option-value="%s"]', $application->Form_Form_fieldName( array( $parents, 'panel', 'panels' ) ), $panel_name ) => array(
								'type'  => 'empty',
								'value' => false,
							),
						),
					),
				) + $_panel_settings_form;
			}
		}
		if ( isset( $config['panel']['panels']['options'] ) ) {
			// Re-order panels as saved previously
			$_panel_options = array();
			foreach ( array_keys( $config['panel']['panels']['options'] ) as $panel_name ) {
				if ( ! isset( $panel_options[ $panel_name ] ) ) {
					continue;
				}

				$_panel_options[ $panel_name ] = $panel_options[ $panel_name ];
				unset( $panel_options[ $panel_name ] );
			}
			$panel_options = $_panel_options + $panel_options;
		}
		$guest_access_default_email = $application->Dashboard_GuestAccess_defaultEmail();
		$form                       = array(
			'#submit'      => array(
				9 => array( // weight
					array( $application, 'Dashboard_SettingsForm_submitSettingsCallback' ),
				),
			),
			'panel'        => array(
				'#title'         => __( 'Dashboard Panel Settings', 'directories-pro' ),
				'#weight'        => 1,
				'panels'         => array(
					'#title'                  => __( 'Dashboard panels', 'directories-pro' ),
					'#type'                   => 'options',
					'#horizontal'             => true,
					'#disable_add'            => true,
					'#disable_icon'           => true,
					'#disable_add_csv'        => true,
					'#multiple'               => true,
					'#options_label_disabled' => $panel_label_disabled,
					'#options_value_disabled' => array_keys( $original_panel_labels ),
					'#default_value'          => array(
						'options' => $panel_options,
						'default' => isset( $config['panel']['panels']['default'] ) ? $config['panel']['panels']['default'] : array_keys( $panel_options ),
					),
					'#options_placeholder'    => $original_panel_labels,
					'#weight'                 => 1,
				),
				'accordion'      => array(
					'#type'          => 'checkbox',
					'#title'         => __( 'Enable accordion effect', 'directories-pro' ),
					'#horizontal'    => true,
					'#default_value' => ! empty( $config['panel']['accordion'] ),
					'#weight'        => 5,
				),
				'logout_btn'     => array(
					'#type'          => 'checkbox',
					'#title'         => __( 'Show logout button', 'directories-pro' ),
					'#horizontal'    => true,
					'#default_value' => ! empty( $config['panel']['logout_btn'] ),
					'#weight'        => 10,
				),
				'panel_settings' => array(
					'#weight' => 20,
				) + $panel_settings_form,
			),
			'guest_access' => array(
				'#title'        => __( 'Guest Access Settings', 'directories-pro' ),
				'#weight'       => 5,
				'enable'        => array(
					'#type'          => 'checkbox',
					'#title'         => __( 'Enable guest access', 'directories-pro' ),
					'#horizontal'    => true,
					'#default_value' => ! empty( $config['guest_access']['enable'] ),
				),
				'duration'      => array(
					'#title'         => __( 'Duration in days', 'directories-pro' ),
					'#description'   => __( 'Enter the number of days guest access is allowed.', 'directories-pro' ),
					'#type'          => 'slider',
					'#default_value' => isset( $config['guest_access']['duration'] ) ? $config['guest_access']['duration'] : GuestAccessHelper::DEFAULT_DURATION,
					'#integer'       => true,
					'#field_suffix'  => __( 'day(s)', 'directories-pro' ),
					'#min_value'     => 1,
					'#max_value'     => 30,
					'#horizontal'    => true,
					'#states'        => array(
						'visible' => array(
							$guest_access_enable_selector = 'input[name="' . $application->Form_Form_fieldName( array( $parents, 'guest_access' ) ) . '[enable]"]' => array(
								'type'  => 'checked',
								'value' => true,
							),
						),
					),
				),
				'custom_email'  => array(
					'#type'          => 'checkbox',
					'#title'         => __( 'Customize guest access URL notification e-mail', 'directories-pro' ),
					'#horizontal'    => true,
					'#default_value' => ! empty( $config['guest_access']['custom_email'] ),
					'#states'        => array(
						'visible' => array(
							$guest_access_enable_selector => array(
								'type'  => 'checked',
								'value' => true,
							),
						),
					),
				),
				'email_subject' => array(
					'#type'                  => 'textfield',
					'#field_prefix'          => __( 'E-mail subject', 'directories-pro' ),
					'#description'           => $guest_request_email_tags = $application->System_Util_availableTags( $application->Dashboard_GuestAccess_emailTags() ),
					'#description_no_escape' => true,
					'#horizontal'            => true,
					'#default_value'         => empty( $config['guest_access']['email_subject'] ) ? $guest_access_default_email[0] : $config['guest_access']['email_subject'],
					'#states'                => array(
						'visible' => array(
							$guest_access_enable_selector => array(
								'type'  => 'checked',
								'value' => true,
							),
							$guest_access_custom_email_selector = 'input[name="' . $application->Form_Form_fieldName( array( $parents, 'guest_access' ) ) . '[custom_email]"]' => array(
								'type'  => 'checked',
								'value' => true,
							),
						),
					),
				),
				'email_body'    => array(
					'#type'                  => 'textarea',
					'#description'           => $guest_request_email_tags,
					'#description_no_escape' => true,
					'#horizontal'            => true,
					'#default_value'         => empty( $config['guest_access']['email_body'] ) ? $guest_access_default_email[1] : $config['guest_access']['email_body'],
					'#rows'                  => count( explode( PHP_EOL, $guest_access_default_email[1] ) ),
					'#states'                => array(
						'visible' => array(
							$guest_access_enable_selector => array(
								'type'  => 'checked',
								'value' => true,
							),
							$guest_access_custom_email_selector => array(
								'type'  => 'checked',
								'value' => true,
							),
						),
					),
				),
			),
		);
		if ( $publicDashboardAllowed ) {
			$form['panel']['enable_public'] = array(
				'#type'          => 'checkbox',
				'#title'         => __( 'Enable public dashboard', 'directories-pro' ),
				'#horizontal'    => true,
				'#default_value' => ! empty( $config['panel']['enable_public'] ),
				'#weight'        => 15,
			);
		} else {
			$form['panel']['enable_public'] = array(
				'#type'          => 'hidden',
				'#default_value' => 0,
			);
		}

		if ( $application->getPlatform()->getName() === 'WordPress' ) {
			// 3rd party plugin profile page integration
			foreach ( array( 'BuddyPress', 'UM', 'PeepSo' ) as $plugin_class ) {
				if ( class_exists( $plugin_class, false ) ) {
					$profile_class                      = 'SabaiApps\\Directories\\Component\\Dashboard\\WordPress\\' . $plugin_class . 'Profile';
					$settings                           = $config['wordpress'][ $plugin_class ] ?? array();
					$parents                            = array_merge( $parents, array( 'wordpress', $plugin_class ) );
					$form['wordpress'][ $plugin_class ] = $profile_class::init( $application, $settings )->getSettingsForm( $parents );
				}
			}
			if ( ! empty( $form['wordpress'] ) ) {
				$form['wordpress']['#weight'] = 99;
			}
		}

		return $form;
	}

	public function submitSettingsCallback( Application $application ) {
		$application->getComponent( 'System' )->reloadRoutes( $application->getComponent( 'Dashboard' ) );
	}
}
