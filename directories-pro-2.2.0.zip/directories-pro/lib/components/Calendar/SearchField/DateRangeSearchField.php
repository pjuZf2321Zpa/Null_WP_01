<?php
namespace SabaiApps\Directories\Component\Calendar\SearchField;

use SabaiApps\Directories\Component\Search\Field\AbstractField;
use SabaiApps\Directories\Component\Entity\Model\Bundle;
use SabaiApps\Directories\Component\Entity\Type\Query;

class DateRangeSearchField extends AbstractField {

	protected function _searchFieldInfo() {
		return array(
			'label'            => __( 'Date Range Search', 'directories-pro' ),
			'weight'           => 3,
			'default_settings' => array(
				'slot_field'   => null,
				'default_year' => null,
				'form'         => array(
					'icon'        => 'fas fa-calendar-days',
					'placeholder' => _x( 'Select dates...', 'search form', 'directories-pro' ),
					'order'       => 3,
				),
			),
		);
	}

	public function searchFieldSupports( Bundle $bundle ) {
		return $this->_application->Entity_Field_options( $bundle, array( 'type' => 'calendar_slot' ) ) ? true : false;
	}

	public function searchFieldSettingsForm( Bundle $bundle, array $settings, array $parents = array() ) {
		$slot_field_options = $this->_application->Entity_Field_options(
			$bundle,
			array(
				'type'            => 'calendar_slot',
				'return_disabled' => true,
			)
		);
		return array(
			'slot_field'   => array(
				'#type'             => 'select',
				'#title'            => __( 'Calendar slot field', 'directories-pro' ),
				'#horizontal'       => true,
				'#multiple'         => true,
				'#options'          => $slot_field_options[0],
				'#options_disabled' => array_keys( $slot_field_options[1] ),
				'#default_value'    => $settings['slot_field'] ?? array_keys( $slot_field_options[0] ),
				'#required'         => true,
			),
			'default_year' => array(
				'#type'          => 'number',
				'#title'         => __( 'Default year', 'directories-pro' ),
				'#horizontal'    => true,
				'#integer'       => true,
				'#min_value'     => 0,
				'#default_value' => $settings['default_year'],
			),
		);
	}

	public function searchFieldForm( Bundle $bundle, array $settings, $request = null, ?array $requests = null, array $parents = array() ) {
		$form = array(
			'#type'            => 'daterangepicker',
			'#calendar_months' => 1,
			'#default_value'   => $request,
			'#default_year'    => empty( $settings['default_year'] ) ? null : (int) $settings['default_year'],
			'#placeholder'     => $settings['form']['placeholder'],
			'#required'        => ! empty( $settings['required'] ),
			'#error_no_output' => true,
		);

		if ( ! empty( $settings['form']['icon'] ) ) {
			$form['#field_prefix']          = '<label for="__FORM_ID__-calendar-search-date-range" class="' . $this->_application->H( $settings['form']['icon'] ) . '"></label>';
			$form['#field_prefix_no_addon'] = true;
			$form['#date_id']               = '__FORM_ID__-calendar-search-date-range';
			$form['#field_prefix_no_addon'] = true;
		}

		return $form;
	}

	public function searchFieldIsSearchable( Bundle $bundle, array $settings, &$value, ?array $requests = null ) {
		// The value is passed to the form for submission afterwards, so it must be left as a "from,to" string
		if ( $this->_parseValue( $value ) === null ) {
			return false;
		}

		if ( is_array( $value ) ) {
			$value = implode( ',', $value );
		}

		return true;
	}

	public function searchFieldSearch( Bundle $bundle, Query $query, array $settings, $value, $sort, array &$sorts ) {
		$this->_application->Calendar_Calendar_filterByDateRange(
			$bundle,
			$query,
			(array) ( $settings['slot_field'] ?? array() ),
			$value[0],
			$value[1]
		);
	}

	public function searchFieldLabels( Bundle $bundle, array $settings, $value ) {
		if ( ( $range = $this->_parseValue( $value ) ) === null ) {
			return array();
		}

		return array(
			array(
				( $range[0] ? $this->_application->System_Date( $range[0] ) : '' )
				. ' - '
				. ( $range[1] ? $this->_application->System_Date( $range[1] ) : '' ),
			),
		);
	}

	public function searchFieldUnsearchableLabel( Bundle $bundle, array $settings, $value ) {
		return is_string( $value ) ? $value : null;
	}

	/**
	 * Normalizes a "from,to" string or a two-item array into [from, to] timestamps.
	 * The end date is a timestamp within the last day of the range, as returned by the date range picker field on submit.
	 *
	 * @return array|null Null if the value is not a valid range or both ends are empty
	 */
	protected function _parseValue( $value ) {
		if ( ! is_array( $value ) ) {
			if ( ! is_string( $value ) || false === strpos( $value, ',' ) ) {
				return;
			}

			$value = explode( ',', $value );
		}
		if ( count( $value ) !== 2 ) {
			return;
		}

		$range = array();
		foreach ( array_values( $value ) as $date ) {
			$range[] = empty( $date )
				? null
				: ( is_numeric( $date ) ? (int) $date : $this->_application->System_Date_strToTime( $date, true, 'Y-m-d' ) );
		}
		if ( empty( $range[0] ) && empty( $range[1] ) ) {
			return;
		}

		return $range;
	}
}
