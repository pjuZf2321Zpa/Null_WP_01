<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
use SabaiApps\Directories\Application;

$tables = array(
	'calendar_occurrence' => array(
		'fields'         => array(
			'occurrence_entity_type'        => array(
				'type'    => Application::COLUMN_VARCHAR,
				'notnull' => true,
				'length'  => 40,
				'default' => '',
			),
			'occurrence_bundle_name'        => array(
				'type'    => Application::COLUMN_VARCHAR,
				'notnull' => true,
				'length'  => 40,
				'default' => '',
			),
			'occurrence_entity_id'          => array(
				'type'     => Application::COLUMN_INTEGER,
				'unsigned' => true,
				'notnull'  => true,
				'length'   => 10,
				'default'  => 0,
			),
			'occurrence_slot_field_name'    => array(
				'type'    => Application::COLUMN_VARCHAR,
				'notnull' => true,
				'length'  => 150,
				'default' => '',
			),
			'occurrence_slot_id'            => array(
				'type'    => Application::COLUMN_VARCHAR,
				'notnull' => true,
				'length'  => 12,
				'default' => '',
			),
			'occurrence_hash'               => array(
				'type'    => Application::COLUMN_VARCHAR,
				'notnull' => true,
				'length'  => 64,
				'default' => '',
			),
			'occurrence_title'              => array(
				'type'    => Application::COLUMN_VARCHAR,
				'notnull' => true,
				'length'  => 255,
				'default' => '',
			),
			'occurrence_start_date'         => array(
				'type'     => Application::COLUMN_INTEGER,
				'unsigned' => true,
				'notnull'  => true,
				'length'   => 10,
				'default'  => 0,
			),
			'occurrence_end_date'           => array(
				'type'     => Application::COLUMN_INTEGER,
				'unsigned' => true,
				'notnull'  => true,
				'length'   => 10,
				'default'  => 0,
			),
			'occurrence_all_day'            => array(
				'type'     => Application::COLUMN_INTEGER,
				'unsigned' => true,
				'notnull'  => true,
				'length'   => 1,
				'default'  => 0,
			),
			'occurrence_status'             => array(
				'type'     => Application::COLUMN_INTEGER,
				'unsigned' => true,
				'notnull'  => true,
				'length'   => 1,
				'default'  => 1,
			),
			'occurrence_slot_data_snapshot' => array(
				'type'    => Application::COLUMN_JSON,
				'notnull' => true,
			),
			'occurrence_data'               => array(
				'type'    => Application::COLUMN_JSON,
				'notnull' => true,
			),
			'occurrence_id'                 => array(
				'autoincrement' => true,
				'type'          => Application::COLUMN_INTEGER,
				'unsigned'      => true,
				'notnull'       => true,
				'length'        => 10,
				'default'       => 0,
			),
			'occurrence_created'            => array(
				'type'     => Application::COLUMN_INTEGER,
				'unsigned' => true,
				'notnull'  => true,
				'length'   => 10,
				'default'  => 0,
			),
			'occurrence_updated'            => array(
				'type'     => Application::COLUMN_INTEGER,
				'unsigned' => true,
				'notnull'  => true,
				'length'   => 10,
				'default'  => 0,
			),
		),
		'indexes'        => array(
			'occurrence_id'              => array(
				'primary' => true,
				'fields'  => array(
					'occurrence_id' => array( 'sorting' => 'ascending' ),
				),
			),
			'occurrence_entity_type'     => array(
				'fields' => array(
					'occurrence_entity_type' => array(),
				),
			),
			'occurrence_bundle_name'     => array(
				'fields' => array(
					'occurrence_bundle_name' => array(),
				),
			),
			'occurrence_entity_id'       => array(
				'fields' => array(
					'occurrence_entity_id' => array(),
				),
			),
			'occurrence_slot_field_name' => array(
				'fields' => array(
					'occurrence_slot_field_name' => array(),
				),
			),
			'occurrence_slot_id'         => array(
				'fields' => array(
					'occurrence_slot_id' => array(),
				),
			),
			'occurrence_hash'            => array(
				'unique' => true,
				'fields' => array(
					'occurrence_hash' => array(),
				),
			),
			'occurrence_title'           => array(
				'fields' => array(
					'occurrence_title' => array(),
				),
			),
			'occurrence_start_date'      => array(
				'fields' => array(
					'occurrence_start_date' => array(),
				),
			),
			'occurrence_end_date'        => array(
				'fields' => array(
					'occurrence_end_date' => array(),
				),
			),
			'occurrence_all_day'         => array(
				'fields' => array(
					'occurrence_all_day' => array(),
				),
			),
			'occurrence_status'          => array(
				'fields' => array(
					'occurrence_status' => array(),
				),
			),
			'occurrence_data_range'      => array(
				'fields' => array(
					'occurrence_start_date' => array(
						'sorting' => 'ascending',
					),
					'occurrence_end_date'   => array(
						'sorting' => 'ascending',
					),
				),
			),
		),
		'initialization' => array(
			'insert' => array(),
		),
	),
);
return array(
	'charset'     => '',
	'description' => '',
	'tables'      => $tables,
);
