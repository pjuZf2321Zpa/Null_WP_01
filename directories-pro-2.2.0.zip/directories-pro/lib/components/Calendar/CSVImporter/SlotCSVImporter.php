<?php
namespace SabaiApps\Directories\Component\Calendar\CSVImporter;

use SabaiApps\Directories\Component\CSV\Importer\AbstractImporter;
use SabaiApps\Directories\Component\Calendar\FieldType\SlotFieldType;
use SabaiApps\Directories\Component\Entity\Model\Field;

class SlotCSVImporter extends AbstractImporter {

	/**
	 * Imports a JSON array of slots. Dates may be given as timestamps or Y-m-d strings and times as seconds from
	 * midnight or H:i(:s) strings. A single JSON object is also accepted.
	 */
	public function csvImporterDoImport( Field $field, array $settings, $column, $value, &$formStorage, array &$logs ) {
		if ( ( ! $slots = json_decode( $value, true ) )
			|| ! is_array( $slots )
		) {
			return;
		}

		if ( ! isset( $slots[0] ) ) {
			$slots = array( $slots );
		}
		$ret = array();
		foreach ( $slots as $slot ) {
			if ( ! is_array( $slot )
				|| ( false === $start_date = $this->_toDate( $slot['start_date'] ?? null ) )
			) {
				continue;
			}

			$slot['start_date'] = $start_date;
			foreach ( array( 'start_time', 'end_time' ) as $key ) {
				if ( isset( $slot[ $key ] ) ) {
					$slot[ $key ] = $this->_toSeconds( $slot[ $key ] );
				}
			}
			if ( isset( $slot['repeat_end_date'] )
				&& ( false === $slot['repeat_end_date'] = $this->_toDate( $slot['repeat_end_date'] ) )
			) {
				unset( $slot['repeat_end_date'] );
			}
			if ( ! empty( $slot['exclude_dates'] ) ) {
				$slot['exclude_dates'] = array_filter( array_map( array( $this, '_toDate' ), (array) $slot['exclude_dates'] ) );
			}
			// Accept the stored rrule string as well
			if ( empty( $slot['repeat'] )
				&& ! empty( $slot['rrule'] )
				&& ( $repeat = SlotFieldType::parseRrule( $slot['rrule'] ) )
			) {
				$slot += $repeat;
			}
			unset( $slot['rrule'] );

			$ret[] = $slot;
		}

		return $ret;
	}

	protected function _toDate( $value ) {
		if ( is_int( $value ) || ( is_string( $value ) && ctype_digit( $value ) ) ) {
			return (int) $value;
		}

		if ( ! is_string( $value ) || ! strlen( $value ) ) {
			return false;
		}

		return $this->_application->System_Date_strToTime( $value );
	}

	protected function _toSeconds( $value ) {
		if ( is_numeric( $value ) ) {
			return (int) $value;
		}

		$parts = explode( ':', trim( (string) $value ) );
		if ( count( $parts ) < 2 ) {
			return 0;
		}

		return (int) $parts[0] * 3600 + (int) $parts[1] * 60 + (int) ( $parts[2] ?? 0 );
	}
}
