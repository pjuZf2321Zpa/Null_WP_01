<?php
namespace SabaiApps\Directories\Component\Calendar\SystemTool;

use SabaiApps\Directories\Component\System\Tool\AbstractTool;
use SabaiApps\Directories\Component\Calendar\FieldType\SlotFieldType;
use SabaiApps\Directories\Component\Entity\Model\Bundle;
use SabaiApps\Directories\Component\Form\Form;
use SabaiApps\Directories\Context;
use SabaiApps\Directories\Exception;

class ExtendRepeatEndSystemTool extends AbstractTool {

	// Maximum number of years ahead the repeat end date can be extended to, to avoid generating too many occurrences at once
	const MAX_YEARS = 2;

	protected function _systemToolInfo() {
		return array(
			'label'       => __( 'Extend calendar repeat end dates', 'directories-pro' ),
			'description' => __( 'Extends the repeat end date of recurring calendar slots and generates occurrences up to the new date. Items are saved in the process.', 'directories-pro' ),
			'weight'      => 60,
			'btn_label'   => __( 'Extend', 'directories-pro' ),
		);
	}

	public function systemToolSupports() {
		// Requires at least one calendar slot field with recurring options enabled
		return ! empty( $this->_application->Calendar_Calendar_slotFields( true ) );
	}

	public function systemToolSettingsForm( $step, array $values, array $parents = array(), ?Context $context = null ) {
		$options = array();
		foreach ( $this->_application->Calendar_Calendar_slotFields( true ) as $field_name => $fields ) {
			foreach ( $fields as $field ) {
				if ( ! $bundle = $this->_application->Entity_Bundle( $field->getBundleName() ) ) {
					continue;
				}

				$options[ $bundle->name . ',' . $field_name ] = sprintf( '%s - %s (%s)', $bundle->getGroupLabel(), $bundle->getLabel(), $field->getFieldLabel() ?: $field_name );
			}
		}
		if ( empty( $options ) ) {
			return false;
		}

		$max_date = strtotime( '+' . self::MAX_YEARS . ' years' );
		return array(
			'target'          => array(
				'#type'          => 'select',
				'#title'         => __( 'Calendar slot field', 'directories-pro' ),
				'#description'   => __( 'Only fields with recurring options enabled are listed.', 'directories-pro' ),
				'#options'       => $options,
				'#default_value' => key( $options ),
				'#required'      => true,
				'#horizontal'    => true,
			),
			'repeat_end_date' => array(
				'#type'             => 'datepicker',
				'#title'            => __( 'New repeat end date', 'directories-pro' ),
				'#description'      => sprintf(
					/* translators: %d: maximum number of years */
					__( 'Occurrences will be generated up to this date. The date may not be more than %d years from now.', 'directories-pro' ),
					self::MAX_YEARS
				),
				'#disable_time'     => true,
				'#min_date'         => time(),
				'#max_date'         => $max_date,
				'#element_validate' => array(
					function ( Form $form, &$value, $element ) use ( $max_date ) {
						if ( ! empty( $value ) && $value > $max_date ) {
							$form->setError(
								/* translators: %d: maximum number of years */
								sprintf( __( 'The date may not be more than %d years from now.', 'directories-pro' ), self::MAX_YEARS ),
								$element
							);
						}
					},
				),
				'#required'         => true,
				'#horizontal'       => true,
			),
			'limit_request'   => array(
				'#type'          => 'slider',
				'#title'         => __( 'Number of items to process per request', 'directories-pro' ),
				'#description'   => __( 'Adjust this setting if you are experiencing timeout errors.', 'directories-pro' ),
				'#default_value' => 10,
				'#min_value'     => 1,
				'#max_value'     => 50,
				'#integer'       => true,
				'#horizontal'    => true,
			),
		);
	}

	public function systemToolInit( array $settings, array &$storage, array &$logs, ?Context $context = null ) {
		if ( ! $target = $this->_getTarget( $settings ) ) {
			return array();
		}

		return array( 'default' => $this->_getQuery( $target[0], $target[1] )->count() );
	}

	public function systemToolRunTask( $task, array $settings, $iteration, $total, array &$storage, array &$logs, ?Context $context = null ) {
		if ( ! $target = $this->_getTarget( $settings ) ) {
			return false;
		}

		list($bundle, $field_name) = $target;
		// Include the whole last day
		$new_end_date = (int) $settings['repeat_end_date'] + 86399;
		$paginator    = $this->_getQuery( $bundle, $field_name )
			->sortById()
			->paginate( (int) $settings['limit_request'] )
			->setCurrentPage( $iteration );

		$calendar = $this->_application->getComponent( 'Calendar' );
		// Occurrences are generated only up to the horizon, so make sure it reaches the new end date
		$calendar->setOccurrenceHorizonDays( (int) ceil( ( $new_end_date - time() ) / 86400 ) + 1 );
		try {
			foreach ( $paginator->getElements() as $entity ) {
				try {
					$this->_extend( $bundle, $entity, $field_name, $new_end_date, $logs );
				} catch ( Exception\IException $e ) {
					$logs['error'][] = sprintf( 'Failed updating item ID %d: %s', $entity->getId(), $e->getMessage() );
				}
			}
		} finally {
			$calendar->setOccurrenceHorizonDays( null );
		}

		return $paginator->getElementLimit();
	}

	protected function _extend( Bundle $bundle, $entity, $fieldName, $newEndDate, array &$logs ) {
		if ( ! $slots = $entity->getFieldValue( $fieldName ) ) {
			return;
		}

		$values  = array();
		$updated = false;
		foreach ( $slots as $slot ) {
			if ( ! empty( $slot['rrule'] ) ) {
				// Convert the stored rrule back to the repeat settings since the field requires them upon saving
				if ( false === $repeat = SlotFieldType::parseRrule( $slot['rrule'] ) ) {
					$logs['error'][] = sprintf( 'Skipped item ID %d since the repeat rule of slot %s could not be parsed: %s', $entity->getId(), $slot['slot_id'], $slot['rrule'] );
					return;
				}
				$slot                 += $repeat;
				$slot['exclude_dates'] = empty( $slot['exclude_dates'] ) ? array() : array_map( 'intval', explode( ',', $slot['exclude_dates'] ) );
				if ( empty( $slot['repeat_end_date'] ) || $slot['repeat_end_date'] < $newEndDate ) {
					$slot['repeat_end_date'] = $newEndDate;
					$updated                 = true;
				}
			}
			unset( $slot['rrule'] );
			$values[] = $slot;
		}
		if ( ! $updated ) {
			return;
		}

		$this->_application->Entity_Save( $entity, array( $fieldName => $values ) );
		$logs['success'][] = sprintf(
			'%s updated: %s (ID: %d)',
			$bundle->getGroupLabel() . ' - ' . $bundle->getLabel( 'singular' ),
			$this->_application->Entity_Title( $entity, true ),
			$entity->getId()
		);
	}

	protected function _getTarget( array $settings ) {
		if ( empty( $settings['target'] )
			|| count( $target = explode( ',', $settings['target'] ) ) !== 2
			|| ( ! $bundle = $this->_application->Entity_Bundle( $target[0] ) )
		) {
			return;
		}

		return array( $bundle, $target[1] );
	}

	protected function _getQuery( Bundle $bundle, $fieldName ) {
		return $this->_application->Entity_Query( $bundle->entitytype_name, $bundle->name )
			->fieldIsNotNull( $fieldName, 'rrule' )
			->fieldIsNot( $fieldName, '', 'rrule' );
	}
}
