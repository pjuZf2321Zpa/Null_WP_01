<?php
namespace SabaiApps\Directories\Component\Calendar\Model;

class Occurrence extends Base\Occurrence {

}

class OccurrenceRepository extends Base\OccurrenceRepository {

}
