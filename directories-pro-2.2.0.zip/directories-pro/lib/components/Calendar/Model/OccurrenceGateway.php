<?php
namespace SabaiApps\Directories\Component\Calendar\Model;

class OccurrenceGateway extends Base\OccurrenceGateway {

}
