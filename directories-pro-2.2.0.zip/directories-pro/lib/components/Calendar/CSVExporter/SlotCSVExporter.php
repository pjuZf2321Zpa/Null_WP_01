<?php
namespace SabaiApps\Directories\Component\Calendar\CSVExporter;

use SabaiApps\Directories\Component\CSV\Exporter\AbstractExporter;
use SabaiApps\Directories\Component\Calendar\FieldType\SlotFieldType;
use SabaiApps\Directories\Component\Entity\Model\Field;

class SlotCSVExporter extends AbstractExporter {

	public function csvExporterDoExport( Field $field, array $settings, $value, array $columns, array &$formStorage, array &$logs ) {
		$slots = array();
		foreach ( $value as $slot ) {
			if ( ! is_array( $slot ) || empty( $slot['start_date'] ) ) {
				continue;
			}

			$_slot = array(
				'start_date' => (int) $slot['start_date'],
				'start_time' => (int) $slot['start_time'],
				'end_time'   => (int) $slot['end_time'],
				'all_day'    => empty( $slot['all_day'] ) ? 0 : 1,
				'slot_id'    => $slot['slot_id'],
			);
			if ( isset( $slot['title'] ) && strlen( $slot['title'] ) ) {
				$_slot['title'] = $slot['title'];
			}
			if ( ! empty( $slot['rrule'] ) ) {
				if ( false === $repeat = SlotFieldType::parseRrule( $slot['rrule'] ) ) {
					$logs['error'][] = sprintf( 'Skipped the repeat rule of slot %s since it could not be exported: %s', $slot['slot_id'], $slot['rrule'] );
				} else {
					$_slot += $repeat;
					if ( ! empty( $slot['repeat_end_date'] ) ) {
						$_slot['repeat_end_date'] = (int) $slot['repeat_end_date'];
					}
					if ( ! empty( $slot['exclude_dates'] ) ) {
						$_slot['exclude_dates'] = array_map( 'intval', explode( ',', $slot['exclude_dates'] ) );
					}
				}
			}
			if ( ! empty( $slot['data'] ) ) {
				$_slot['data'] = $slot['data'];
			}
			$slots[] = $_slot;
		}

		return empty( $slots ) ? '' : json_encode( $slots );
	}
}
