<?php
namespace SabaiApps\Directories\Component\Calendar\FieldRenderer;

use SabaiApps\Directories\Component\Field\Renderer\AbstractRenderer;
use SabaiApps\Directories\Component\Field\IField;
use SabaiApps\Directories\Component\Entity\Type\IEntity;

class CalendarFieldRenderer extends AbstractRenderer {

	protected function _fieldRendererInfo() {
		return array(
			'label'            => __( 'Calendar', 'directories-pro' ),
			'field_types'      => array( 'calendar_slot' ),
			'default_settings' => array(
				'calendar_color' => 'primary',
			),
			'accept_multiple'  => true,
		);
	}

	public function fieldRendererSettingsForm( IField $field, array $settings, array $parents = array() ) {
		return array(
			'calendar_color' => array(
				'#type'             => 'radios',
				'#title'            => __( 'Calendar color', 'directories-pro' ),
				'#options'          => array( '' => __( 'None', 'directories-pro' ) ) + $this->_application->System_Color_options( array( 'as_background' => true ) ),
				'#option_no_escape' => true,
				'#horizontal'       => true,
				'#default_value'    => $settings['calendar_color'],
				'#weight'           => 1,
				'#columns'          => 3,
			),
		);
	}

	protected function _fieldRendererRenderField( IField $field, array &$settings, IEntity $entity, array $values, ?array $context = null, $more = 0 ) {
		if ( ! $field->Bundle ) {
			return;
		}

		$render_settings = array(
			'name'          => 'calendar',
			'mode'          => 'calendar',
			'push_state'    => false,
			'view_settings' => $this->_getViewSettings( $field, $settings, $entity ),
		);
		if ( ! empty( $context['_avoid_side_effects'] ) ) {
			// ViewEntities (which this ultimately routes through) renders JSON instead of
			// HTML when the current request is XHR - correct for its own ajax-refresh use
			// case, but wrong here when the *outer* render (e.g. Map's modal fetch) is what's
			// marked XHR, not this sub-render itself. Force HTML via ViewEntities' own
			// no_json setting (ViewEntities.php:13,46-49) - a top-level View setting, not a
			// mode-specific one, so it's a sibling of view_settings, not nested inside it.
			$render_settings['no_json'] = true;
		}

		return $this->_application->getPlatform()->render(
			$field->Bundle->getPath(),
			array(
				'settings' => $render_settings,
			),
			array(
				'cache'         => false,
				'title'         => false,
				'container'     => null,
				'render_assets' => false,
			)
		);
	}

	protected function _getViewSettings( IField $field, array &$settings, IEntity $entity ) {
		return array(
			'display'                => 'summary',
			'calendar_color'         => $settings['calendar_color'] ?? 'primary',
			'calendar_display_modes' => array( 'month', 'year', 'list' ),
			'calendar_display_mode'  => 'month',
			'calendar_slot_field'    => array( $field->getFieldName() ),
			'query'                  => array(
				'fields' => array(
					$field->Bundle->entitytype_name . '_id' => $entity->getId(),
				),
			),
			'filter'                 => array(
				'show' => false,
			),
			'other'                  => array(
				'search' => false,
				'add'    => array(
					'show' => false,
				),
			),
		);
	}
}
