<?php
namespace SabaiApps\Directories\Component\DirectoryPro\DirectoryType;

use SabaiApps\Directories\Component\Directory;

class DirectoryType extends Directory\Type\DirectoryType {

	public function directoryContentTypeInfo( $contentType ) {
		switch ( $contentType ) {
			case 'listing':
				return array(
					'component'       => 'DirectoryPro',
					'claiming_enable' => true,
					'booking_enable'  => true,
					'payment_enable'  => true,
					'review_enable'   => true,
				) + parent::directoryContentTypeInfo( $contentType );
		}
	}
}
