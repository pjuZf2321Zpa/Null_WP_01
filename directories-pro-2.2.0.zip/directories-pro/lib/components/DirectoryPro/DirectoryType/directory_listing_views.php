<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
return array(
	'default'           =>
	array(
		'mode'     => 'list',
		'label'    => __( 'Default', 'directories-pro' ),
		'settings' =>
		array(
			'list_grid'              => 1,
			'list_grid_cols'         =>
			array(
				'num'            => 'responsive',
				'num_responsive' =>
				array(
					'xs'  => '1',
					'xsm' => 'inherit',
					'sm'  => '2',
					'md'  => '3',
					'lg'  => '4',
					'xl'  => 'inherit',
					'xxl' => '6',
				),
			),
			'list_grid_gutter_width' => 'sm',
			'display'                => 'summary',
			'map'                    =>
			array(
				'show'              => 1,
				'coordinates_field' => 'location_address',
				'position'          => 'left',
				'span'              => 4,
				'height'            => 400,
				'margin'            => '2',
				'view_marker_icon'  => 'directory_category',
				'scroll_to_item'    => 1,
				'scroll_offset'     => 0,
				'sticky'            => 1,
				'sticky_offset'     => 0,
				'fullscreen'        => 1,
				'fullscreen_span'   => 6,
				'fullscreen_offset' => 0,
				'infobox'           => 1,
				'infobox_width'     => 240,
				'marker_link'       => 1,
				'hide_xs'           => false,
				'trigger_infobox'   => false,
			),
			'display_cache'          => '',
			'list_no_row'            => false,
			'list_grid_default'      => false,
			'sort'                   =>
			array(
				'default'            => 'entity_featured,value',
				'default_settings'   =>
				array(
					'entity_featured-value' =>
					array(
						'term_page_only' => false,
					),
				),
				'secondary'          => 'post_published',
				'secondary_settings' =>
				array(),
				'third'              => '',
				'third_settings'     =>
				array(),
				'default_label'      => '',
				'options'            =>
				array(
					0 => 'post_published',
					1 => 'post_published,asc',
					2 => 'post_title',
					3 => 'post_title,desc',
					4 => 'location_address',
					5 => 'voting_rating',
					6 => 'random',
					7 => 'entity_child_count,review_review',
					8 => 'review_ratings',
					9 => 'voting_bookmark',
				),
			),
			'pagination'             =>
			array(
				'type'          => '',
				'perpage'       => 20,
				'allow_perpage' => 1,
				'perpages'      =>
				array(
					0 => 10,
					1 => 20,
					2 => 50,
				),
				'no_pagination' => false,
			),
			'filter'                 =>
			array(
				'show'             => false,
				'display'          => 'default',
				'show_mobile_only' => true,
				'show_modal'       => false,
				'shown'            => false,
			),
			'other'                  =>
			array(
				'search'             => false,
				'num'                => 1,
				'add'                =>
				array(
					'show'       => false,
					'show_label' => false,
				),
				'not_found'          =>
				array(
					'custom' => false,
				),
				'search_mobile_only' => false,
				'gad_enable'         => false,
			),
			'query'                  =>
			array(
				'fields'                 =>
				array(),
				'fields_exclude_enabled' => false,
				'fields_exclude'         =>
				array(),
				'limit'                  => 0,
				'voting_bookmark_only'   => false,
			),
			'directory_name'         => 'directory',
			'bundle_name'            => 'directory_dir_ltg',
			'view_id'                => '1',
		),
		'default'  => true,
	),
	'featured_listings' =>
	array(
		'mode'     => 'slider_photos',
		'label'    => __( 'Featured Listings', 'directories-pro' ),
		'settings' =>
		array(
			'photoslider_image_field'    => 'directory_photos',
			'photoslider_image_size'     => 'thumbnail',
			'photoslider_columns'        => 10,
			'photoslider_pager'          => 1,
			'photoslider_controls'       => 1,
			'photoslider_caption'        => 1,
			'photoslider_speed'          => 260,
			'photoslider_auto'           => 1,
			'photoslider_auto_speed'     => 3000,
			'photoslider_height'         => 135,
			'photoslider_padding'        => '5',
			'photoslider_thumbs_columns' => 5,
			'photoslider_zoom'           => false,
			'photoslider_responsive'     => false,
			'photoslider_center'         => true,
			'photoslider_link'           => true,
			'sort'                       =>
			array(
				'default'            => 'post_id',
				'default_settings'   =>
				array(),
				'secondary'          => '',
				'secondary_settings' =>
				array(),
				'third'              => '',
				'third_settings'     =>
				array(),
				'default_label'      => '',
				'options'            =>
				array(
					0 => 'post_id',
				),
			),
			'filter'                     =>
			array(
				'display' => 'default',
				'show'    => false,
			),
			'other'                      =>
			array(
				'not_found' =>
				array(
					'custom' => false,
				),
				'search'    => false,
				'num'       => false,
				'add'       =>
				array(
					'show' => false,
				),
			),
			'query'                      =>
			array(
				'fields'               =>
				array(
					'entity_featured'  => '1',
					'directory_photos' => '1',
				),
				'limit'                => 12,
				'voting_bookmark_only' => false,
			),
			'directory_name'             => 'directory',
			'bundle_name'                => 'directory_dir_ltg',
			'view_id'                    => '2',
		),
		'default'  => false,
	),
	'map'               =>
	array(
		'mode'     => 'fullmap',
		'label'    => __( 'Map', 'directories-pro' ),
		'settings' =>
		array(
			'display'                        => 'summary',
			'map_coordinates_field'          => 'location_address',
			'map_color'                      => 'primary',
			'map_height'                     => 1000,
			'map_marker_icon'                => 'directory_category',
			'map_infobox_width'              => 360,
			'map_min_zoom_for_update'        => 10,
			'map_max_markers'                => 500,
			'map_debounce_delay'             => 500,
			'map_loading_indicator_position' => 'top-left',
			'map_loading_indicator_theme'    => 'light',
			'map_fullscreen'                 => 1,
			'map_fullscreen_offset'          => 0,
			'map_infobox_detail_modal'       => 1,
			'map_modal_display'              => 'detailed',
			'display_cache'                  => '',
			'map_load_more'                  => false,
			'map_geolocate'                  => false,
			'filter'                         =>
			array(
				'display' => 'default',
				'show'    => false,
			),
			'other'                          =>
			array(
				'num'    => 1,
				'search' => false,
			),
			'query'                          =>
			array(
				'fields'                 =>
				array(),
				'limit'                  => 0,
				'fields_exclude_enabled' => false,
				'voting_bookmark_only'   => false,
				'fields_exclude'         =>
				array(),
			),
			'directory_name'                 => 'directory',
			'bundle_name'                    => 'directory_dir_ltg',
			'view_id'                        => '168',
		),
		'default'  => false,
	),
	'carousel'          =>
	array(
		'mode'     => 'slider_carousel',
		'label'    => __( 'Recent Listings', 'directories-pro' ),
		'settings' =>
		array(
			'carousel_columns'         => 4,
			'carousel_controls'        => 1,
			'carousel_auto'            => 1,
			'carousel_auto_speed'      => 3000,
			'display'                  => 'summary',
			'display_cache'            => '',
			'display_cache_guest_only' => 1,
			'carousel_pager'           => false,
			'carousel_fade'            => false,
			'sort'                     =>
			array(
				'options'        =>
				array(
					0 => 'post_published',
				),
				'default'        => 'post_published',
				'stick_featured' => false,
			),
			'pagination'               =>
			array(
				'no_pagination' => 1,
				'perpage'       => 10,
				'perpages'      =>
				array(
					0 => 10,
					1 => 20,
					2 => 50,
				),
				'allow_perpage' => false,
			),
			'query'                    =>
			array(
				'fields' =>
				array(),
				'limit'  => 10,
			),
			'filter'                   =>
			array(
				'display'    => 'default',
				'show'       => false,
				'show_modal' => false,
				'shown'      => false,
			),
			'other'                    =>
			array(
				'not_found' =>
				array(
					'html'   => '',
					'custom' => false,
				),
				'num'       => false,
				'add'       =>
				array(
					'show'       => false,
					'show_label' => false,
				),
			),
			'directory_name'           => 'directory',
			'bundle_name'              => 'directory_dir_ltg',
			'view_id'                  => '22',
		),
		'default'  => false,
	),
	'a_z_index'         =>
	array(
		'mode'     => 'table',
		'label'    => __( 'A - Z Index', 'directories-pro' ),
		'settings' =>
		array(
			'display'        => 'row',
			'map'            =>
			array(
				'show' => false,
			),
			'display_cache'  => '',
			'sort'           =>
			array(
				'options'        =>
				array(
					0 => 'post_title',
				),
				'default'        => 'post_title',
				'secondary'      => '',
				'stick_featured' => false,
			),
			'pagination'     =>
			array(
				'perpage'       => 20,
				'no_pagination' => false,
				'allow_perpage' => false,
				'type'          => '',
			),
			'filter'         =>
			array(
				'show'       => 1,
				'display'    => 'a_z_filter',
				'shown'      => 1,
				'hide_btn'   => 1,
				'show_modal' => false,
			),
			'other'          =>
			array(
				'num'       => 1,
				'not_found' =>
				array(
					'custom' => false,
				),
				'add'       =>
				array(
					'show' => false,
				),
			),
			'query'          =>
			array(
				'fields'               =>
				array(),
				'limit'                => 0,
				'voting_bookmark_only' => false,
			),
			'directory_name' => 'directory',
			'bundle_name'    => 'directory_dir_ltg',
			'view_id'        => '44',
		),
		'default'  => false,
	),
);
