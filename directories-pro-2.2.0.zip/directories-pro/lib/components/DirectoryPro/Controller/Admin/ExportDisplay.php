<?php
namespace SabaiApps\Directories\Component\DirectoryPro\Controller\Admin;

use SabaiApps\Directories\Context;
use SabaiApps\Directories\Component\System\Controller\Admin\RunToolWithProgress;

class ExportDisplay extends RunToolWithProgress {

	protected function _getToolName( Context $context ) {
		return 'directory_export_display';
	}

	public function _getFormForStepRun( Context $context, array &$formStorage ) {
		$form                 = parent::_getFormForStepRun( $context, $formStorage );
		$form['display_type'] = array(
			'#type'  => 'hidden',
			'#value' => $context->display->type,
		);
		$form['display_name'] = array(
			'#type'  => 'hidden',
			'#value' => $context->display->name,
		);
		return $form;
	}
}
