<?php
namespace SabaiApps\Directories\Component\DirectoryPro\Controller\Admin;

use SabaiApps\Directories\Context;
use SabaiApps\Directories\Component\System\Controller\Admin\RunToolWithProgress;

class ImportDisplay extends RunToolWithProgress {

	protected function _getToolName( Context $context ) {
		return 'directory_import_display';
	}

	public function _getFormForStepRun( Context $context, array &$formStorage ) {
		$form                 = parent::_getFormForStepRun( $context, $formStorage );
		$form['display_type'] = array(
			'#type'  => 'hidden',
			'#value' => $context->display->type,
		);
		$form['display_name'] = array(
			'#type'  => 'hidden',
			'#value' => $context->display->name,
		);
		return $form;
	}

	protected function _complete( Context $context, array $formStorage ) {
		// Send success
		$admin_path = $this->Entity_BundleTypeInfo_adminPath( $context->bundle );
		switch ( $context->display->type ) {
			case 'filters':
				$admin_path .= '/views/filters';
				break;
			case 'form':
				$admin_path .= '/fields';
				break;
			default:
				$admin_path .= '/displays';
				break;
		}
		$params = array();
		if ( $tab_names = $context->display->getAdminTabNames() ) {
			if ( ! empty( $tab_names[0] ) ) {
				$params['_drts_form_current_tab'] = $tab_names[0];
			}
			if ( ! empty( $tab_names[1] ) ) {
				$params['_drts_form_current_tab2'] = $tab_names[1];
			}
		}
		$context->setSuccess( $this->Url( $admin_path, $params ) );
		parent::_complete( $context, $formStorage );
	}
}
