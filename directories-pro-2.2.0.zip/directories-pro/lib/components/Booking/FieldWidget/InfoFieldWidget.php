<?php
namespace SabaiApps\Directories\Component\Booking\FieldWidget;

use SabaiApps\Directories\Component\Calendar\Model\Occurrence;
use SabaiApps\Directories\Component\Field\Widget\AbstractWidget;
use SabaiApps\Directories\Component\Field\IField;
use SabaiApps\Directories\Component\Entity\Type\IEntity;
use SabaiApps\Directories\Component\Calendar\CalendarComponent;

class InfoFieldWidget extends AbstractWidget {

	protected function _fieldWidgetInfo() {
		return array(
			'label'       => __( 'Booking Info', 'directories-pro' ),
			'field_types' => array( $this->_name ),
		);
	}

	public function fieldWidgetForm( IField $field, array $settings, $value = null, ?IEntity $entity = null, array $parents = array(), $language = null ) {
		if ( isset( $value ) ) {
			if ( empty( $value['occurrence_hash'] )
				|| ( ! $occurrence = $this->_application->Calendar_Calendar_isValidOccurrence( $value['occurrence_hash'] ) )
			) {
				return;
			}

			return array(
				'#type'   => 'item',
				'#markup' => $this->_application->Booking_Util_renderDate( $occurrence->start_date, $occurrence->end_date, false )
					. '<input type="hidden" value="' . $this->_application->H( $value['occurrence_hash'] ) . '" name="' . $this->_application->Form_Form_fieldName( array( $parents, 'occurrence_hash' ) ) . '" />',
			);
		}

		if ( $this->_application->getPlatform()->isAdmin()
			|| empty( $_REQUEST['occurrence_hash'] )
		) {
			return;
		}

		$occurrence_hash = $_REQUEST['occurrence_hash'];
		if ( ( ! $occurrence = $this->_application->Calendar_Calendar_isValidOccurrence( $occurrence_hash, $this->_application->getPlatform()->isAdmin() ? null : CalendarComponent::OCCURRENCE_STATUS_ACTIVE ) )
			|| empty( $occurrence->slot_data_snapshot['booking_allow'] )
		) {
			return;
		}

		$occ_options                      = $occ_options_disabled = $occ_dates = array();
		$occ_dates[ $occurrence->hash ]   = $occurrence->start_date;
		$spaces_available                 = $this->_application->Booking_Util_spacesAvailable( $occurrence );
		$occ_options[ $occurrence->hash ] = sprintf(
			__( '%1$s (%2$s)', 'directories-pro' ),
			$this->_application->Booking_Util_renderDate( $occurrence->start_date, $occurrence->end_date, false ),
			sprintf( _n( '%s space available', '%s spaces available', $spaces_available, 'directories-pro' ), $spaces_available )
		);
		if ( ! $spaces_available
			|| $occurrence->start_date < time()
		) {
			$occ_options_disabled[] = $occurrence->hash;
		}
		foreach ( $this->_application->Calendar_Calendar_relatedOccurrences( $occurrence, 4 ) as $related_occurrence ) {
			$occ_dates[ $related_occurrence->hash ]   = $related_occurrence->start_date;
			$occ_options[ $related_occurrence->hash ] = sprintf(
				__( '%1$s (%2$s)', 'directories-pro' ),
				$this->_application->Booking_Util_renderDate( $related_occurrence->start_date, $related_occurrence->end_date, false ),
				sprintf( _n( '%s space available', '%s spaces available', $spaces_available, 'directories-pro' ), $spaces_available )
			);
			if ( ( ! $spaces_available = $this->_application->Booking_Util_spacesAvailable( $related_occurrence ) )
				|| $related_occurrence->start_date < time()
			) {
				$occ_options_disabled[] = $related_occurrence->hash;
			}
		}

		uasort(
			$occ_dates,
			function ( $a, $b ) {
				return $a <=> $b;
			}
		);
		$occ_options = array_merge( $occ_dates, $occ_options );

		return array(
			'occurrence_hash' => array(
				'#type'             => 'select',
				'#options'          => $occ_options,
				'#options_disabled' => $occ_options_disabled,
				'#class'            => DRTS_BS_PREFIX . 'mb-0',
				'#default_value'    => $occurrence->hash,
			),
		);
	}
}
