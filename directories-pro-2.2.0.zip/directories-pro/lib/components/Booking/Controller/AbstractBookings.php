<?php
namespace SabaiApps\Directories\Component\Booking\Controller;

use SabaiApps\Directories\Component\Entity\Type\IEntity;
use SabaiApps\Directories\Component\Entity\Type\Query;
use SabaiApps\Directories\Component\Form;
use SabaiApps\Directories\Context;

abstract class AbstractBookings extends Form\Controller {

	protected function _doGetFormSettings( Context $context, array &$formStorage ) {
		$this->_submitable = false;

		// Init form
		$form = array(
			'bookings' => array(
				'#type'       => 'tableselect',
				'#header'     => $this->_getHeaders( $context ),
				'#disabled'   => true,
				'#options'    => array(),
				'#class'      => 'drts-data-table drts-booking-bookings',
				'#attributes' => array(
					'style' => 'margin-bottom: 100px !important;',
				),
			),
		);

		// Init variables
		$sortable_headers = $this->_getSortableHeaders( $context );
		$sort             = $context->getRequest()->asStr( 'sort', 'booking_date', $sortable_headers );
		$order            = $context->getRequest()->asStr( 'order', 'ASC', array( 'ASC', 'DESC' ) );

		// Set sortable headers
		$this->_makeTableSortable( $context, $form['bookings'], $sortable_headers, $sort, $order, $this->_getSortableHeaderParams( $context ) );

		// Add rows
		$query = $this->Entity_Query( 'post' )->fieldIs( 'bundle_type', 'booking_booking' )
			->fieldIs( 'status', $this->Entity_Status( 'post', 'publish' ) );
		if ( $sort === 'booking_date' ) {
			$query->sortByField( 'booking_info', $order, 'start_date' );
		}
		$user_id = isset( $context->dashboard_user ) ? $context->dashboard_user->id : $this->getUser()->id;
		if ( ! $query = $this->_getQuery( $query, $user_id, $sort, $order ) ) {
			return;
		}

		foreach ( $query->fetch( 100, 0 ) as $booking ) {
			if ( $row = $this->_getBookingRow( $context, $booking, $form['bookings']['#header'] ) ) {
				$form['bookings']['#options'][ $booking->getId() ] = $row;
			}
		}

		return $form;
	}

	protected function _getHeaders( Context $context ) {
		return array(
			'number'         => array(
				'label' => '#',
				'order' => 1,
			),
			'name'           => array(
				'label' => __( 'Name', 'directories-pro' ),
				'order' => 2,
			),
			'booking_date'   => array(
				'label' => __( 'Date', 'directories-pro' ),
				'order' => 5,
			),
			'booking_status' => array(
				'label' => __( 'Status', 'directories-pro' ),
				'order' => 10,
			),
			'buttons'        => array(
				'label' => '',
				'order' => 20,
			),
		);
	}

	protected function _getSortableHeaders( Context $context ) {
		return array( 'booking_date' );
	}

	protected function _getSortableHeaderParams( Context $context ) {
		return array( 'link' => $context->dashboard_panel_link );
	}

	abstract protected function _getQuery( Query $query, $userId, $sort, $order );

	protected function _getBookingRow( Context $context, IEntity $booking, array $tableHeaders ) {
		if ( ! $parent_entity = $this->Entity_ParentEntity( $booking, false ) ) {
			$this->logError( 'Could not fetch parent entity for booking ID: ' . $booking->getId() );
			return;
		}

		if ( ! $date = $booking->getSingleFieldValue( 'booking_info', 'start_date' ) ) {
			$this->logError( 'Could not fetch booking date for booking ID: ' . $booking->getId() );
			return;
		}
		$identity = isset( $context->dashboard_user ) ? $context->dashboard_user : $this->getUser()->getIdentity();
		return array(
			'number'         => $this->LinkTo(
				$booking->getTitle(),
				'#',
				array(
					'url'       => $this->Dashboard_Panels_panelUrl( 'booking_bookings', 'bookings', '/bookings/' . $booking->getId(), array(), true, $identity ),
					'container' => 'modal',
					'modalSize' => 'lg',
				),
				array(
					'data-modal-title' => $booking->getTitle(),
				)
			),
			'name'           => $this->Entity_Permalink( $parent_entity ),
			'booking_date'   => $this->Booking_Util_renderDate( $date ),
			'booking_status' => $this->Booking_Util_statusLabel( $booking ),
			'buttons'        => ( ! $links = $this->_getButtonLinks( $context, $booking ) ) ? '' : $this->System_Button_dropdownLinks(
				array(
					'' => $this->LinkTo(
						'',
						'#',
						array(
							'active' => true,
							'icon'   => 'fas fa-cog',
						)
					),
				) + $links,
				array(
					'label' => true,
					'color' => 'outline-secondary',
					'right' => true,
				)
			),
		);
	}

	protected function _getButtonLinks( Context $context, IEntity $booking ) {
		return array();
	}

	protected function _getButtonLink( IEntity $booking, $path, array $options, $label, $modalTitle = null, array $params = array() ) {
		$identity    = isset( $context->dashboard_user ) ? $context->dashboard_user : $this->getUser()->getIdentity();
		$modal_title = $booking->getTitle();
		if ( isset( $modalTitle ) ) {
			$modal_title = sprintf( $modalTitle, $this->Entity_Bundle( $booking )->getLabel( 'singular' ) ) . ': ' . $modal_title;
		}
		return $this->LinkTo(
			$label,
			$this->Dashboard_Panels_panelUrl( 'booking_bookings', 'bookings', $path, $params, true, $identity ),
			$options,
			array( 'data-modal-title' => $modal_title )
		);
	}
}
