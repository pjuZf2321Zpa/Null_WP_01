<?php
namespace SabaiApps\Directories\Component\Booking\Controller;

use SabaiApps\Directories\Component\Form;
use SabaiApps\Directories\Context;

class ChangeBookingStatus extends Form\Controller {

	protected function _doGetFormSettings( Context $context, array &$formStorage ) {
		switch ( $context->booking_status ) {
			case 'cancelled':
				$label = __( 'Cancel %s', 'directories-pro' );
				$color = 'danger';
				break;
			case 'confirmed':
				$label = __( 'Approve %s', 'directories-pro' );
				$color = 'success';
				break;
			case 'rejected':
				$label = __( 'Reject %s', 'directories-pro' );
				$color = 'danger';
				break;
			default:
				// This should not happen
				$context->setError();
				return;
		}
		$this->_submitButtons['submit'] = array(
			'#btn_label' => sprintf( $label, $this->Entity_Bundle( $context->booking )->getLabel( 'singular' ) ),
			'#btn_color' => $color,
			'#btn_size'  => 'lg',
		);

		return array(
			'#action'       =>
				$this->Dashboard_Panels_panelUrl(
					'booking_bookings',
					'bookings',
					'/bookings/' . $context->booking->getId() . '/change_status',
					array( 'status' => $context->booking_status ),
					true
				),
			'#header'       => array(
				sprintf(
					'<div class="%1$salert %1$salert-warning %1$smb-0">%2$s</div>',
					DRTS_BS_PREFIX,
					$this->H( __( 'Are you sure you want to proceed?', 'directories-pro' ) )
				),
			),
			'#header_class' => DRTS_BS_PREFIX . 'mb-0',
		);
	}

	public function submitForm( Form\Form $form, Context $context ) {
		$this->Entity_Save(
			$context->booking,
			array(
				'booking_status' => $context->booking_status,
			)
		);
		$context->setSuccess( $this->Dashboard_Panels_panelUrl( 'booking_bookings', 'bookings', '/bookings_received' ) )
			->addFlash( __( 'Your item has been updated successfully.', 'directories-pro' ) );
	}
}
