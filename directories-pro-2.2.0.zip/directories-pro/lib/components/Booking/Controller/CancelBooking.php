<?php
namespace SabaiApps\Directories\Component\Booking\Controller;

use SabaiApps\Directories\Component\Form;
use SabaiApps\Directories\Context;

class CancelBooking extends Form\Controller {

	protected function _doGetFormSettings( Context $context, array &$formStorage ) {
		$this->_submitButtons['submit'] = array(
			'#btn_label' => __( 'Cancel Booking', 'directories-pro' ),
			'#btn_color' => 'danger',
			'#btn_size'  => 'lg',
		);
		$this->_ajaxOnSuccessDelete     = '.drts-booking-bookings tr[data-row-id=\'' . $context->booking->getId() . '\']';

		return array(
			'#action'       => $this->Dashboard_Panels_panelUrl( 'booking_bookings', 'bookings', '/bookings/' . $context->booking->getId() . '/cancel', array(), true ),
			'#header'       => array(
				sprintf(
					'<div class="%1$salert %1$salert-warning %1$smb-0">%2$s</div>',
					DRTS_BS_PREFIX,
					$this->H( __( 'Are you sure you want to proceed?', 'directories-pro' ) )
				),
			),
			'#header_class' => DRTS_BS_PREFIX . 'mb-0',
		);
	}

	public function submitForm( Form\Form $form, Context $context ) {
		$this->Entity_Save(
			$context->booking,
			array(
				'booking_status' => 'cancelled',
			)
		);
		$context->setSuccess( $this->Dashboard_Panels_panelUrl( 'booking_bookings', 'bookings', '/bookings' ) )
			->addFlash( __( 'Your booking has been cancelled successfully.', 'directories-pro' ) );
	}
}
