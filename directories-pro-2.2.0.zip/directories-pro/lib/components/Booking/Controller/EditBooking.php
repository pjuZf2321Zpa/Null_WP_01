<?php
namespace SabaiApps\Directories\Component\Booking\Controller;

use SabaiApps\Directories\Component\Form;
use SabaiApps\Directories\Component\Entity;
use SabaiApps\Directories\Context;

class EditBooking extends Form\Controller {

	protected function _doGetFormSettings( Context $context, array &$formStorage ) {
		$this->_submitButtons['submit'] = array(
			'#btn_label'  => __( 'Save Changes', 'directories-pro' ),
			'#btn_color'  => 'primary',
			'#btn_size'   => 'lg',
			'#attributes' => array( 'data-modal-title' => '' ), // prevents modal title from changing on submit error
		);
		$this->_ajaxOnSuccessEdit       = '.drts-booking-bookings tr[data-row-id=\'' . $context->booking->getId() . '\'] td';
		$context->addTemplate( 'entity_form' );

		return array(
			'#action' => $this->Dashboard_Panels_panelUrl( 'booking_bookings', 'bookings', '/bookings/' . $context->booking->getId() . '/edit', array(), true ),
		) + $this->Entity_Form(
			$context->booking,
			array(
				'values'             => $context->getRequest()->getParams(),
				'pre_render_display' => true,
				'wrap'               => 'drts',
			)
		);
	}

	public function submitForm( Form\Form $form, Context $context ) {
		$this->_saveEntity( $context->booking, $form );
		$context->setSuccess( $this->Dashboard_Panels_panelUrl( 'booking_bookings', 'bookings', '/bookings' ) )
			->addFlash( __( 'Your item has been updated successfully.', 'directories-pro' ), 'success', 60000 );
	}

	protected function _saveEntity( Entity\Type\IEntity $entity, Form\Form $form, array $extraArgs = array() ) {
		$values = $form->values['drts'];

		// Make sure the parent entity can not be changed
		unset( $values['entity_parent'], $values['parent'] );

		$extra_args = array(
			'entity_field_max_num_items' => $form->settings['#entity_field_max_num_items'],
		);

		return $this->Entity_Save( $entity, $values, $extra_args );
	}
}
