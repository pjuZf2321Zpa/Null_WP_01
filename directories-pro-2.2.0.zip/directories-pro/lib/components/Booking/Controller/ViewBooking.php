<?php
namespace SabaiApps\Directories\Component\Booking\Controller;

use SabaiApps\Directories\Controller;
use SabaiApps\Directories\Context;

class ViewBooking extends Controller {

	protected function _doExecute( Context $context ) {
		$context->addTemplate( 'view_entity' )
			->setAttributes(
				array(
					'entity'  => $context->booking,
					'display' => 'detailed',
				)
			);
	}
}
