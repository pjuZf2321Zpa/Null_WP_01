<?php
namespace SabaiApps\Directories\Component\Booking\Controller;

use SabaiApps\Directories\Component\Entity\Type\IEntity;
use SabaiApps\Directories\Component\Entity\Type\Query;
use SabaiApps\Directories\Context;

class Bookings extends AbstractBookings {

	protected function _getQuery( Query $query, $userId, $sort, $order ) {
		if ( $this->getUser()->isAnonymous() ) {
			if ( ! $guest_email = $this->_application->Dashboard_GuestAccess_isGranted() ) {
				return;
			}

			return $query->fieldIs( 'frontendsubmit_guest', $guest_email, 'email' );
		}
		return $query->fieldIs( 'author', $userId );
	}

	protected function _getButtonLinks( Context $context, IEntity $booking ) {
		$links = array();
		if ( ( ! $status = $booking->getSingleFieldValue( 'booking_status' ) )
			|| $status === 'pending'
		) {
			$links['edit'] = $this->_getButtonLink(
				$booking,
				'/bookings/' . $booking->getId() . '/edit',
				array(
					'icon'      => 'fas fa-cog',
					'container' => 'modal',
					'modalSize' => 'xl',
				),
				__( 'Edit', 'directories-pro' ),
			);
		}
		if ( $this->Booking_Util_canChangeStatus( $booking, 'cancelled' ) ) {
			$links['cancel'] = $this->_getButtonLink(
				$booking,
				'/bookings/' . $booking->getId() . '/cancel',
				array(
					'icon'      => 'fas fa-ban',
					'container' => 'modal',
				),
				__( 'Cancel', 'directories-pro' ),
				__( 'Cancel %s', 'directories-pro' )
			);
		}
		return $links;
	}
}
