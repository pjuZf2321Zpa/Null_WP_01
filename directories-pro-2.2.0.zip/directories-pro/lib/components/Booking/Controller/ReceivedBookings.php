<?php
namespace SabaiApps\Directories\Component\Booking\Controller;

use SabaiApps\Directories\Component\Entity\Type\IEntity;
use SabaiApps\Directories\Component\Entity\Type\Query;
use SabaiApps\Directories\Context;

class ReceivedBookings extends AbstractBookings {

	protected function _getQuery( Query $query, $userId, $sort, $order ) {
		$entity_ids = array();
		foreach ( $this->Entity_BundleTypes_byFeatures( array( 'booking_enable' ) ) as $entity_type => $bundle_types ) {
			foreach ( $this->Entity_Query( $entity_type )->fieldIsIn( 'bundle_type', $bundle_types )->fieldIs( 'author', $userId )->fetch( 500 ) as $entity ) {
				$entity_ids[ $entity->getType() ][ $entity->getId() ] = $entity->getId();
			}
		}
		if ( ! empty( $entity_ids ) ) {
			$query->startCriteriaGroup( 'OR' );
			foreach ( array_keys( $entity_ids ) as $entity_type ) {
				$query->startCriteriaGroup()
					->fieldIs( 'entity_parent', $entity_type, 'parent_entity_type' )
					->fieldIsIn( 'entity_parent', $entity_ids[ $entity_type ], 'parent_entity_id' )
					->finishCriteriaGroup();
			}
			$query->finishCriteriaGroup();
		}
		return $query;
	}

	public function taxonomyTermTitleContains( $taxonomyBundleName, $taxonomyBundleType, $string ) {
		$this->addCriteria( new ContainsCriteria( $this->_getTaxonomyTermNameTarget( $taxonomyBundleType ), $string ) );
	}

	protected function _getParentEntityAuthorTarget( $taxonomyBundleType ) {
		$db = $this->_application->getPlatform()->getDb();
		return array(
			'tables'      => array(
				$db->getResourcePrefix() . 'entity_field_entity_terms' => array(
					'alias' => $entity_terms,
					'on'    => 'entity_id = %3$s AND %1$s.field_name = ' . $this->_db->escapeString( $taxonomyBundleType ),
				),
				$this->_db->getResourcePrefix() . 'terms' => array(
					'alias' => $terms,
					'on'    => 'term_id = ' . $entity_terms . '.value',
					// 'join_type' => 'INNER',
				),
			),
			'column'      => $terms . '.term_title',
			'column_type' => Application::COLUMN_VARCHAR,
		);
	}

	protected function _getBookingRow( Context $context, IEntity $booking, array $tableHeaders ) {
		if ( ! $row = parent::_getBookingRow( $context, $booking, $tableHeaders ) ) {
			return;
		}

		$row['customer'] = $this->_application->UserIdentityHtml( $this->Entity_Author( $booking ), 'link_thumb_s' );
		return $row;
	}

	protected function _getHeaders( Context $context ) {
		$headers             = parent::_getHeaders( $context );
		$headers['customer'] = array(
			'label' => __( 'Customer', 'directories-pro' ),
			'order' => 6,
		);
		return $headers;
	}

	protected function _getButtonLinks( Context $context, IEntity $booking ) {
		if ( ! $statuses = $this->Booking_Util_canChangeStatus( $booking, array( 'confirmed', 'rejected', 'cancelled' ), 'bookie' ) ) {
			return;
		}

		$links = array();
		if ( in_array( 'confirmed', $statuses ) ) {
			$links['approve'] = $this->_getButtonLink(
				$booking,
				'/bookings/' . $booking->getId() . '/change_status',
				array(
					'icon'      => 'fas fa-check',
					'container' => 'modal',
				),
				__( 'Approve', 'directories-pro' ),
				__( 'Approve %s', 'directories-pro' ),
				array( 'status' => 'confirmed' )
			);
		}
		if ( in_array( 'rejected', $statuses ) ) {
			$links['reject'] = $this->_getButtonLink(
				$booking,
				'/bookings/' . $booking->getId() . '/change_status',
				array(
					'icon'      => 'fas fa-times',
					'container' => 'modal',
				),
				__( 'Reject', 'directories-pro' ),
				__( 'Reject %s', 'directories-pro' ),
				array( 'status' => 'rejected' )
			);
		}
		if ( in_array( 'cancelled', $statuses ) ) {
			$links['cancel'] = $this->_getButtonLink(
				$booking,
				'/bookings/' . $booking->getId() . '/change_status',
				array(
					'icon'      => 'fas fa-ban',
					'container' => 'modal',
				),
				__( 'Cancel', 'directories-pro' ),
				__( 'Cancel %s', 'directories-pro' ),
				array( 'status' => 'cancelled' )
			);
		}
		return $links;
	}
}
