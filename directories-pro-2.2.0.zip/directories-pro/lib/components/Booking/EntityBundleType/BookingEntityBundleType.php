<?php
namespace SabaiApps\Directories\Component\Booking\EntityBundleType;

use SabaiApps\Directories\Component\Entity\BundleType\AbstractBundleType;

class BookingEntityBundleType extends AbstractBundleType {

	protected function _entityBundleTypeInfo() {
		return array(
			'type'                                 => $this->_name,
			'entity_type'                          => 'post',
			'slug'                                 => 'bookings',
			'suffix'                               => 'bkg_bkg',
			'component'                            => 'Booking',
			'parent'                               => 'booking_enable',
			'parent_field'                         => true,
			'label'                                => __( 'Bookings', 'directories-pro' ),
			'label_singular'                       => __( 'Booking', 'directories-pro' ),
			'label_add'                            => __( 'Book a Slot', 'directories-pro' ),
			'label_all'                            => __( 'All Bookings', 'directories-pro' ),
			'label_count'                          => __( '%s booking', 'directories-pro' ),
			'label_count2'                         => __( '%s bookings', 'directories-pro' ),
			'label_author'                         => __( 'Customer', 'directories-pro' ),
			'icon'                                 => 'fas fa-calendar-check',
			'properties'                           => array(),
			'fields'                               => __DIR__ . '/booking_fields.php',
			'displays'                             => __DIR__ . '/booking_displays.php',
			// 'views' => __DIR__ . '/booking_views.php',
			'public'                               => false,
			'no_title'                             => true,
			'no_content'                           => true,
			'dashboard_disable'                    => true,
			'display_enable_detailed'              => true,
			'wordpress_admin_disable_add'          => true,
			'faker_disable'                        => true,
			'frontendsubmit_enable'                => true,
			'frontendsubmit_guest'                 => true,
			'frontendsubmit_guest_redirect_params' => array( 'booking_data' ),
		);
	}

	public function entityBundleTypeSettingsForm( array $settings, array $parents = array() ) {
		return array(
			'#title'         => __( 'Booking Number Settings', 'directories-pro' ),
			'booking_number' => array(
				'#tree' => true,
			) + $this->_application->Entity_NumberFormat_settingsForm(
				isset( $settings['booking_number'] ) ? $settings['booking_number'] : array(),
				array_merge( $parents, array( 'booking_number' ) )
			),
		);
	}
}
