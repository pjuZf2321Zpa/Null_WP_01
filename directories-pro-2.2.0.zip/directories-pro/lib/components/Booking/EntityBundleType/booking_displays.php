<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
return array(
	'form'   =>
	array(
		'default' =>
		array(
			'name'     => 'default',
			'type'     => 'form',
			'data'     =>
			array(),
			'elements' =>
			array(
				2516 =>
				array(
					'id'        => 2516,
					'name'      => 'entity_form_string',
					'data'      =>
					array(
						'settings'           =>
						array(
							'field_name'                => 'booking_name',
							'settings'                  =>
							array(
								'min_length'      => '',
								'max_length'      => '',
								'regex'           => '',
								'prefix'          => '',
								'suffix'          => '',
								'char_validation' => 'none',
							),
							'_admin_only'               => false,
							'_is_personal_data'         => true,
							'_personal_data_identifier' => 'author',
							'_user_register_show'       => false,
							'_wp_roles'                 => null,
							'label'                     => 'Your Name',
							'hide_label'                => false,
							'description'               => '',
							'default_value'             => '',
							'required'                  => true,
							'admin_unrequired'          => false,
							'disabled'                  => false,
							'weight'                    => 4,
							'max_num_items'             => 1,
							'widget'                    => 'textfield',
							'widget_settings'           =>
							array(
								'autopopulate' => 'name',
								'placeholder'  => '',
								'mask'         => '',
							),
							'conditions'                =>
							array(),
							'_display'                  => 'default',
						),
						'heading'            => null,
						'advanced'           => null,
						'visibility'         =>
						array(
							'wp_check_role' => false,
							'wp_roles'      =>
							array(),
							'admin_only'    => false,
						),
						'element'            => 'entity_form_string',
						'parent_id'          => '0',
						'_entity_field_type' => 'string',
					),
					'parent_id' => 0,
					'weight'    => 4,
					'system'    => true,
				),
				2517 =>
				array(
					'id'        => 2517,
					'name'      => 'entity_form_phone',
					'data'      =>
					array(
						'settings'           =>
						array(
							'field_name'                => 'field_booking_phone',
							'settings'                  =>
							array(
								'min_length'      => null,
								'max_length'      => null,
								'char_validation' => 'none',
								'mask'            => '(999) 999-9999',
							),
							'_admin_only'               => false,
							'_is_personal_data'         => true,
							'_personal_data_identifier' => 'author',
							'_user_register_show'       => false,
							'_wp_roles'                 => null,
							'label'                     => 'Phone Number',
							'hide_label'                => false,
							'description'               => '',
							'default_value'             => '',
							'required'                  => false,
							'admin_unrequired'          => false,
							'disabled'                  => false,
							'weight'                    => 5,
							'max_num_items'             => 1,
							'widget'                    => 'phone',
							'widget_settings'           =>
							array(
								'placeholder' => '',
								'mask'        => '',
							),
							'conditions'                =>
							array(),
							'_display'                  => 'default',
						),
						'heading'            => null,
						'advanced'           => null,
						'visibility'         =>
						array(
							'wp_check_role' => false,
							'wp_roles'      =>
							array(),
							'admin_only'    => false,
						),
						'element'            => 'entity_form_phone',
						'parent_id'          => '0',
						'_entity_field_type' => 'phone',
					),
					'parent_id' => 0,
					'weight'    => 5,
					'system'    => false,
				),
				2518 =>
				array(
					'id'        => 2518,
					'name'      => 'entity_form_text',
					'data'      =>
					array(
						'settings'           =>
						array(
							'field_name'                => 'field_booking_comment',
							'settings'                  =>
							array(
								'min_length'      => '',
								'max_length'      => '',
								'regex'           => '',
								'char_validation' => 'none',
							),
							'_admin_only'               => false,
							'_is_personal_data'         => false,
							'_personal_data_identifier' => 'author',
							'_user_register_show'       => false,
							'_wp_roles'                 => null,
							'label'                     => 'Comment',
							'hide_label'                => false,
							'description'               => '',
							'default_value'             => '',
							'required'                  => false,
							'admin_unrequired'          => false,
							'disabled'                  => false,
							'weight'                    => 6,
							'max_num_items'             => 1,
							'widget'                    => 'textarea',
							'widget_settings'           =>
							array(
								'rows'  => 4,
								'nl2br' => false,
							),
							'conditions'                =>
							array(),
							'_display'                  => 'default',
						),
						'heading'            => null,
						'advanced'           => null,
						'visibility'         =>
						array(
							'wp_check_role' => false,
							'wp_roles'      =>
							array(),
							'admin_only'    => false,
						),
						'element'            => 'entity_form_text',
						'parent_id'          => '0',
						'_entity_field_type' => 'text',
					),
					'parent_id' => 0,
					'weight'    => 6,
					'system'    => false,
				),
				2519 =>
				array(
					'id'        => 2519,
					'name'      => 'entity_form_entity_parent',
					'data'      =>
					array(
						'settings'           =>
						array(
							'field_name'          => 'entity_parent',
							'settings'            =>
							array(),
							'_admin_only'         => false,
							'_user_register_show' => false,
							'_wp_roles'           => null,
							'label'               => 'Listing',
							'hide_label'          => false,
							'description'         => '',
							'default_value'       => null,
							'required'            => true,
							'admin_unrequired'    => false,
							'disabled'            => false,
							'weight'              => 1,
							'max_num_items'       => 1,
							'widget'              => 'entity_parent',
							'widget_settings'     =>
							array(),
							'conditions'          =>
							array(),
							'_display'            => 'default',
						),
						'visibility'         => null,
						'advanced'           => null,
						'_entity_field_type' => 'entity_parent',
					),
					'parent_id' => 0,
					'weight'    => 1,
					'system'    => true,
				),
				2527 =>
				array(
					'id'        => 2527,
					'name'      => 'entity_form_booking_spaces',
					'data'      =>
					array(
						'settings'           =>
						array(
							'field_name'          => 'booking_spaces',
							'settings'            =>
							array(),
							'label'               => 'Number of Spaces',
							'hide_label'          => false,
							'description'         => '',
							'default_value'       => null,
							'required'            => true,
							'admin_unrequired'    => false,
							'disabled'            => false,
							'weight'              => 3,
							'max_num_items'       => 1,
							'widget'              => 'booking_spaces',
							'widget_settings'     =>
							array(),
							'conditions'          =>
							array(),
							'_display'            => 'default',
							'_admin_only'         => false,
							'_user_register_show' => false,
							'_wp_roles'           => null,
						),
						'_entity_field_type' => 'booking_spaces',
					),
					'parent_id' => 0,
					'weight'    => 3,
					'system'    => true,
				),
				2528 =>
				array(
					'id'        => 2528,
					'name'      => 'entity_form_booking_info',
					'data'      =>
					array(
						'settings'           =>
						array(
							'field_name'          => 'booking_info',
							'settings'            =>
							array(),
							'label'               => 'Booking Date',
							'hide_label'          => false,
							'description'         => '',
							'default_value'       => null,
							'required'            => false,
							'admin_unrequired'    => false,
							'disabled'            => false,
							'weight'              => 2,
							'max_num_items'       => 1,
							'widget'              => 'booking_info',
							'widget_settings'     =>
							array(),
							'conditions'          =>
							array(),
							'_display'            => 'default',
							'_admin_only'         => false,
							'_user_register_show' => false,
							'_wp_roles'           => null,
						),
						'_entity_field_type' => 'booking_info',
					),
					'parent_id' => 0,
					'weight'    => 2,
					'system'    => true,
				),
			),
		),
	),
	'entity' =>
	array(
		'dashboard_row' =>
		array(
			'name'     => 'dashboard_row',
			'type'     => 'entity',
			'data'     =>
			array(
				'css' => '',
			),
			'elements' =>
			array(
				2520 =>
				array(
					'id'        => 2520,
					'name'      => 'button',
					'data'      =>
					array(
						'settings'   =>
						array(
							'size'           => '',
							'dropdown'       => 1,
							'dropdown_icon'  => 'fas fa-cog',
							'dropdown_label' => '',
							'dropdown_right' => 1,
							'separate'       => 1,
							'tooltip'        => 1,
							'arrangement'    =>
							array(
								0 => 'dashboard_posts_edit',
								1 => 'dashboard_posts_delete',
							),
							'buttons'        =>
							array(
								'dashboard_posts_edit'   =>
								array(
									'settings' =>
									array(
										'_color'      => 'outline-secondary',
										'_icon'       => 'fas fa-pen-to-square',
										'_link_color' => '',
										'_hide_label' => false,
									),
								),
								'dashboard_posts_delete' =>
								array(
									'settings' =>
									array(
										'_color'      => 'danger',
										'_icon'       => 'fas fa-trash-can',
										'_link_color' => '',
										'_hide_label' => false,
									),
								),
							),
							'btn'            => true,
						),
						'heading'    => null,
						'advanced'   =>
						array(
							'margin_top'    => '0',
							'margin_right'  => '0',
							'margin_bottom' => '0',
							'margin_left'   => '0',
							'margin_enable' => false,
						),
						'visibility' =>
						array(
							'wp_check_role' => false,
							'wp_roles'      =>
							array(),
						),
						'element'    => 'button',
						'parent_id'  => '0',
					),
					'parent_id' => 0,
					'weight'    => 4,
					'system'    => false,
				),
				2521 =>
				array(
					'id'        => 2521,
					'name'      => 'entity_parent_field_post_title',
					'data'      =>
					array(
						'settings'           =>
						array(
							'label'             => 'custom',
							'label_custom'      => __( 'Listing', 'directories-pro' ),
							'label_icon'        => '',
							'label_icon_size'   => '',
							'label_as_heading'  => 1,
							'renderer_settings' =>
							array(
								'entity_title' =>
								array(
									'link'              => 'post',
									'link_field'        => 'field_website,',
									'link_target'       => '_self',
									'link_custom_label' => '',
									'max_chars'         => 0,
									'icon'              => 1,
									'icon_settings'     =>
									array(
										'size'     => 'sm',
										'fallback' => false,
										'is_image' => true,
									),
									'_separator'        => '',
									'link_rel'          =>
									array(),
								),
							),
							'renderer'          => 'entity_title',
						),
						'heading'            => null,
						'advanced'           =>
						array(
							'margin_top'    => '0',
							'margin_right'  => '0',
							'margin_bottom' => '0',
							'margin_left'   => '0',
							'font_size'     => '',
							'font_size_rel' => '1',
							'font_size_abs' => '16',
							'font_weight'   => '',
							'font_style'    => '',
							'margin_enable' => false,
						),
						'visibility'         =>
						array(
							'wp_check_role' => false,
							'wp_roles'      =>
							array(),
						),
						'element'            => 'entity_parent_field_post_title',
						'parent_id'          => '0',
						'_entity_field_type' => 'entity_title',
					),
					'parent_id' => 0,
					'weight'    => 2,
					'system'    => false,
				),
				2522 =>
				array(
					'id'        => 2522,
					'name'      => 'labels',
					'data'      =>
					array(
						'settings'   =>
						array(
							'arrangement' =>
							array(
								0 => 'booking_status',
							),
							'style'       => '',
							'labels'      =>
							array(
								'custom-1'       =>
								array(
									'settings' =>
									array(
										'label_type' => '',
										'label_text' => '',
										'_color'     =>
										array(
											'type'  =>
											array(),
											'value' => '',
											'text'  => '',
										),
										'conditions' => null,
									),
								),
								'custom-2'       =>
								array(
									'settings' =>
									array(
										'label_type' => '',
										'label_text' => '',
										'_color'     =>
										array(
											'type'  =>
											array(),
											'value' => '',
											'text'  => '',
										),
										'conditions' => null,
									),
								),
								'custom-3'       =>
								array(
									'settings' =>
									array(
										'label_type' => '',
										'label_text' => '',
										'_color'     =>
										array(
											'type'  =>
											array(),
											'value' => '',
											'text'  => '',
										),
										'conditions' => null,
									),
								),
								'custom-4'       =>
								array(
									'settings' =>
									array(
										'label_type' => '',
										'label_text' => '',
										'_color'     =>
										array(
											'type'  =>
											array(),
											'value' => '',
											'text'  => '',
										),
										'conditions' => null,
									),
								),
								'custom-5'       =>
								array(
									'settings' =>
									array(
										'label_type' => '',
										'label_text' => '',
										'_color'     =>
										array(
											'type'  =>
											array(),
											'value' => '',
											'text'  => '',
										),
										'conditions' => null,
									),
								),
								'entity_status'  => null,
								'entity_new'     =>
								array(
									'settings' =>
									array(
										'_label' => '',
										'_color' =>
										array(
											'type'  =>
											array(),
											'value' => '',
											'text'  => '',
										),
										'days'   => '',
									),
								),
								'booking_status' => null,
							),
						),
						'heading'    =>
						array(
							'label'           => 'custom',
							'label_custom'    => __( 'Status', 'directories-pro' ),
							'label_icon'      => '',
							'label_icon_size' => '',
						),
						'advanced'   =>
						array(
							'margin_top'    => '0',
							'margin_right'  => '0',
							'margin_bottom' => '0',
							'margin_left'   => '0',
							'font_size'     => '',
							'font_size_rel' => '1',
							'font_size_abs' => '16',
							'font_weight'   => '',
							'font_style'    => '',
							'margin_enable' => false,
						),
						'visibility' =>
						array(
							'wp_check_role' => false,
							'wp_roles'      =>
							array(),
						),
					),
					'parent_id' => 0,
					'weight'    => 3,
					'system'    => false,
				),
			),
		),
		'detailed'      =>
		array(
			'name'     => 'detailed',
			'type'     => 'entity',
			'data'     =>
			array(
				'css' => '',
			),
			'elements' =>
			array(
				2523 =>
				array(
					'id'        => 2523,
					'name'      => 'entity_field_field_booking_phone',
					'data'      =>
					array(
						'settings'           =>
						array(
							'label'             => 'form',
							'label_custom'      => '',
							'label_icon'        => '',
							'label_icon_size'   => '',
							'renderer'          => 'phone',
							'renderer_settings' =>
							array(
								'phone'    =>
								array(
									'type'         => 'default',
									'label'        => '',
									'field'        => 'booking_name',
									'_separator'   => ', ',
									'button'       => false,
									'button_color' =>
									array(),
								),
								'whatsapp' =>
								array(
									'type'                => 'default',
									'label'               => '',
									'target'              => '_self',
									'country_code'        => '+93',
									'message'             => '',
									'_separator'          => '',
									'prefix_country_code' => false,
								),
							),
							'label_as_heading'  => false,
						),
						'heading'            => null,
						'advanced'           =>
						array(
							'margin_enable' => 1,
							'margin_top'    => '3',
							'margin_right'  => '0',
							'margin_bottom' => '0',
							'margin_left'   => '0',
							'font_size'     => '',
							'font_size_rel' => '1',
							'font_size_abs' => '16',
							'font_weight'   => '',
							'font_style'    => '',
						),
						'visibility'         =>
						array(
							'wp_check_role'    => false,
							'wp_roles'         =>
							array(),
							'globalize'        => false,
							'globalize_remove' => false,
						),
						'_entity_field_type' => 'phone',
					),
					'parent_id' => 0,
					'weight'    => 6,
					'system'    => false,
				),
				2524 =>
				array(
					'id'        => 2524,
					'name'      => 'entity_field_booking_name',
					'data'      =>
					array(
						'settings'           =>
						array(
							'label'             => 'form',
							'label_custom'      => '',
							'label_icon'        => '',
							'label_icon_size'   => '',
							'renderer_settings' =>
							array(
								'email' =>
								array(
									'type'         => 'default',
									'label'        => '',
									'field'        => 'booking_name',
									'target'       => '_self',
									'_separator'   => ', ',
									'button'       => false,
									'button_color' =>
									array(),
								),
							),
							'renderer'          => 'email',
							'label_as_heading'  => false,
						),
						'heading'            => null,
						'advanced'           =>
						array(
							'margin_enable' => 1,
							'margin_top'    => '3',
							'margin_right'  => '0',
							'margin_bottom' => '0',
							'margin_left'   => '0',
							'font_size'     => '',
							'font_size_rel' => '1',
							'font_size_abs' => '16',
							'font_weight'   => '',
							'font_style'    => '',
						),
						'visibility'         =>
						array(
							'wp_check_role'    => false,
							'wp_roles'         =>
							array(),
							'globalize'        => false,
							'globalize_remove' => false,
						),
						'_entity_field_type' => 'string',
					),
					'parent_id' => 0,
					'weight'    => 5,
					'system'    => false,
				),
				2526 =>
				array(
					'id'        => 2526,
					'name'      => 'entity_field_field_booking_comment',
					'data'      =>
					array(
						'settings'           =>
						array(
							'label'             => 'form',
							'label_custom'      => '',
							'label_icon'        => '',
							'label_icon_size'   => '',
							'renderer_settings' =>
							array(
								'text' =>
								array(
									'trim_length'          => 200,
									'disable_excerpt_more' => 1,
									'_separator'           => ' ',
									'trim'                 => false,
									'shortcode'            => false,
								),
							),
							'renderer'          => 'text',
							'label_as_heading'  => false,
						),
						'heading'            => null,
						'advanced'           =>
						array(
							'margin_enable' => 1,
							'margin_top'    => '3',
							'margin_right'  => '0',
							'margin_bottom' => '0',
							'margin_left'   => '0',
							'font_size'     => '',
							'font_size_rel' => '1',
							'font_size_abs' => '16',
							'font_weight'   => '',
							'font_style'    => '',
						),
						'visibility'         =>
						array(
							'wp_check_role'    => false,
							'wp_roles'         =>
							array(),
							'globalize'        => false,
							'globalize_remove' => false,
						),
						'_entity_field_type' => 'text',
					),
					'parent_id' => 0,
					'weight'    => 7,
					'system'    => false,
				),
				2530 =>
				array(
					'id'        => 2530,
					'name'      => 'entity_field_booking_info',
					'data'      =>
					array(
						'settings'           =>
						array(
							'label'             => 'form',
							'renderer'          => 'booking_date',
							'renderer_settings' =>
							array(
								'booking_date' =>
								array(
									'_separator' => ', ',
								),
							),
							'label_as_heading'  => false,
							'label_custom'      => null,
							'label_icon'        => null,
							'label_icon_size'   => null,
						),
						'heading'            => null,
						'advanced'           =>
						array(
							'css_class'     => '',
							'css_id'        => '',
							'margin_enable' => 1,
							'margin_top'    => '3',
							'margin_right'  => '0',
							'margin_bottom' => '0',
							'margin_left'   => '0',
							'font_size'     => '',
							'font_weight'   => '',
							'font_style'    => '',
						),
						'visibility'         =>
						array(
							'author_only'      => false,
							'wp_check_role'    => false,
							'membership_check' => false,
							'hide_on_parent'   => false,
							'hide_on_mobile'   => false,
							'globalize'        => false,
						),
						'_entity_field_type' => 'booking_info',
					),
					'parent_id' => 0,
					'weight'    => 2,
					'system'    => false,
				),
				2531 =>
				array(
					'id'        => 2531,
					'name'      => 'entity_parent_field_post_title',
					'data'      =>
					array(
						'settings'           =>
						array(
							'label'             => 'form',
							'renderer'          => 'entity_title',
							'renderer_settings' =>
							array(
								'entity_title' =>
								array(
									'link'              => 'post',
									'link_target'       => '',
									'link_custom_label' => '',
									'max_chars'         => 0,
									'_separator'        => '',
									'icon'              => false,
									'skip_entity_title_filter' => false,
								),
							),
							'label_as_heading'  => false,
							'label_custom'      => null,
							'label_icon'        => null,
							'label_icon_size'   => null,
						),
						'heading'            => null,
						'advanced'           =>
						array(
							'css_class'     => '',
							'css_id'        => '',
							'margin_enable' => 1,
							'margin_top'    => '3',
							'margin_right'  => '0',
							'margin_bottom' => '0',
							'margin_left'   => '0',
							'font_size'     => '',
							'font_weight'   => '',
							'font_style'    => '',
						),
						'visibility'         =>
						array(
							'author_only'      => false,
							'wp_check_role'    => false,
							'membership_check' => false,
							'hide_on_parent'   => false,
							'hide_on_mobile'   => false,
							'globalize'        => false,
						),
						'_entity_field_type' => 'entity_title',
					),
					'parent_id' => 0,
					'weight'    => 3,
					'system'    => false,
				),
				2532 =>
				array(
					'id'        => 2532,
					'name'      => 'labels',
					'data'      =>
					array(
						'settings'   =>
						array(
							'arrangement' =>
							array(
								0 => 'booking_status',
							),
							'style'       => '',
							'labels'      =>
							array(
								'custom-1'       =>
								array(
									'settings' =>
									array(
										'label_type'  => null,
										'label_text'  => '',
										'_color'      =>
										array(
											'type' => null,
											'name' => null,
										),
										'_conditions' => null,
									),
								),
								'custom-2'       =>
								array(
									'settings' =>
									array(
										'label_type'  => null,
										'label_text'  => '',
										'_color'      =>
										array(
											'type' => null,
											'name' => null,
										),
										'_conditions' => null,
									),
								),
								'custom-3'       =>
								array(
									'settings' =>
									array(
										'label_type'  => null,
										'label_text'  => '',
										'_color'      =>
										array(
											'type' => null,
											'name' => null,
										),
										'_conditions' => null,
									),
								),
								'custom-4'       =>
								array(
									'settings' =>
									array(
										'label_type'  => null,
										'label_text'  => '',
										'_color'      =>
										array(
											'type' => null,
											'name' => null,
										),
										'_conditions' => null,
									),
								),
								'custom-5'       =>
								array(
									'settings' =>
									array(
										'label_type'  => null,
										'label_text'  => '',
										'_color'      =>
										array(
											'type' => null,
											'name' => null,
										),
										'_conditions' => null,
									),
								),
								'entity_new'     =>
								array(
									'settings' =>
									array(
										'_label' => '',
										'_color' =>
										array(
											'type' => null,
											'name' => null,
										),
										'days'   => '',
									),
								),
								'booking_status' => null,
							),
						),
						'heading'    =>
						array(
							'label' => 'none',
						),
						'advanced'   =>
						array(
							'css_class'     => '',
							'css_id'        => '',
							'font_size'     => '',
							'font_weight'   => '',
							'font_style'    => '',
							'margin_enable' => false,
						),
						'visibility' =>
						array(
							'author_only'      => false,
							'wp_check_role'    => false,
							'membership_check' => false,
							'hide_on_parent'   => false,
							'hide_on_mobile'   => false,
							'globalize'        => false,
						),
					),
					'parent_id' => 0,
					'weight'    => 1,
					'system'    => false,
				),
				2533 =>
				array(
					'id'        => 2533,
					'name'      => 'entity_field_booking_spaces',
					'data'      =>
					array(
						'settings'           =>
						array(
							'label'             => 'form',
							'renderer'          => 'booking_spaces',
							'renderer_settings' =>
							array(
								'booking_spaces' =>
								array(
									'_separator' => ', ',
								),
							),
							'label_as_heading'  => false,
							'label_custom'      => null,
							'label_icon'        => null,
							'label_icon_size'   => null,
						),
						'heading'            => null,
						'advanced'           =>
						array(
							'css_class'     => '',
							'css_id'        => '',
							'margin_enable' => 1,
							'margin_top'    => '3',
							'margin_right'  => '0',
							'margin_bottom' => '0',
							'margin_left'   => '0',
							'font_size'     => '',
							'font_weight'   => '',
							'font_style'    => '',
						),
						'visibility'         =>
						array(
							'author_only'      => false,
							'wp_check_role'    => false,
							'membership_check' => false,
							'hide_on_parent'   => false,
							'hide_on_mobile'   => false,
							'globalize'        => false,
						),
						'_entity_field_type' => 'booking_spaces',
					),
					'parent_id' => 0,
					'weight'    => 4,
					'system'    => false,
				),
			),
		),
	),
);
