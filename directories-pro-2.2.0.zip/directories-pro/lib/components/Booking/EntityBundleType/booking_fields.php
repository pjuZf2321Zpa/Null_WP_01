<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
return array(
	'booking_spaces'        =>
	array(
		'type'     => 'booking_spaces',
		'settings' =>
		array(),
		'realm'    => 2,
		'data'     =>
		array(
			'label'               => __( 'Number of Spaces', 'directories-pro' ),
			'hide_label'          => false,
			'description'         => '',
			'default_value'       => null,
			'required'            => true,
			'admin_unrequired'    => false,
			'disabled'            => false,
			'weight'              => 3,
			'max_num_items'       => 1,
			'widget'              => 'booking_spaces',
			'widget_settings'     =>
			array(),
			'conditions'          =>
			array(),
			'_display'            => 'default',
			'_admin_only'         => false,
			'_user_register_show' => false,
			'_wp_roles'           => null,
		),
	),
	'booking_status'        =>
	array(
		'type'     => 'booking_status',
		'settings' =>
		array(),
		'realm'    => 2,
		'data'     =>
		array(
			'label'            => __( 'Booking Status', 'directories-pro' ),
			'hide_label'       => false,
			'description'      => '',
			'default_value'    => null,
			'required'         => false,
			'admin_unrequired' => false,
			'disabled'         => false,
			'weight'           => 0,
			'max_num_items'    => 1,
			'widget'           => 'booking_status',
			'widget_settings'  =>
			array(),
			'conditions'       =>
			array(),
		),
	),
	'booking_info'          =>
	array(
		'type'     => 'booking_info',
		'settings' =>
		array(),
		'realm'    => 2,
		'data'     =>
		array(
			'label'               => __( 'Booking Date', 'directories-pro' ),
			'hide_label'          => false,
			'description'         => '',
			'default_value'       => null,
			'required'            => false,
			'admin_unrequired'    => false,
			'disabled'            => false,
			'weight'              => 2,
			'max_num_items'       => 1,
			'widget'              => 'booking_info',
			'widget_settings'     =>
			array(),
			'conditions'          =>
			array(),
			'_display'            => 'default',
			'_admin_only'         => false,
			'_user_register_show' => false,
			'_wp_roles'           => null,
		),
	),
	'booking_name'          =>
	array(
		'type'     => 'string',
		'settings' =>
		array(
			'min_length'      => '',
			'max_length'      => '',
			'regex'           => '',
			'prefix'          => '',
			'suffix'          => '',
			'char_validation' => 'none',
		),
		'realm'    => 2,
		'data'     =>
		array(
			'_admin_only'               => false,
			'_is_personal_data'         => true,
			'_personal_data_identifier' => 'author',
			'_user_register_show'       => false,
			'_wp_roles'                 => null,
			'label'                     => __( 'Your Name', 'directories-pro' ),
			'hide_label'                => false,
			'description'               => '',
			'default_value'             => '',
			'required'                  => true,
			'admin_unrequired'          => false,
			'disabled'                  => false,
			'weight'                    => 4,
			'max_num_items'             => 1,
			'widget'                    => 'textfield',
			'widget_settings'           =>
			array(
				'autopopulate' => 'name',
				'placeholder'  => '',
				'mask'         => '',
			),
			'conditions'                =>
			array(),
			'_display'                  => 'default',
		),
	),
	'field_booking_phone'   =>
	array(
		'type'     => 'phone',
		'settings' =>
		array(
			'min_length'      => null,
			'max_length'      => null,
			'char_validation' => 'none',
			'mask'            => '(999) 999-9999',
		),
		'realm'    => 0,
		'data'     =>
		array(
			'_admin_only'               => false,
			'_is_personal_data'         => true,
			'_personal_data_identifier' => 'author',
			'_user_register_show'       => false,
			'_wp_roles'                 => null,
			'label'                     => __( 'Phone Number', 'directories-pro' ),
			'hide_label'                => false,
			'description'               => '',
			'default_value'             => '',
			'required'                  => false,
			'admin_unrequired'          => false,
			'disabled'                  => false,
			'weight'                    => 5,
			'max_num_items'             => 1,
			'widget'                    => 'phone',
			'widget_settings'           =>
			array(
				'placeholder' => '',
				'mask'        => '',
			),
			'conditions'                =>
			array(),
			'_display'                  => 'default',
		),
	),
	'field_booking_comment' =>
	array(
		'type'     => 'text',
		'settings' =>
		array(
			'min_length'      => '',
			'max_length'      => '',
			'regex'           => '',
			'char_validation' => 'none',
		),
		'realm'    => 0,
		'data'     =>
		array(
			'_admin_only'               => false,
			'_is_personal_data'         => false,
			'_personal_data_identifier' => 'author',
			'_user_register_show'       => false,
			'_wp_roles'                 => null,
			'label'                     => __( 'Comment', 'directories-pro' ),
			'hide_label'                => false,
			'description'               => '',
			'default_value'             => '',
			'required'                  => false,
			'admin_unrequired'          => false,
			'disabled'                  => false,
			'weight'                    => 6,
			'max_num_items'             => 1,
			'widget'                    => 'textarea',
			'widget_settings'           =>
			array(
				'rows'  => 4,
				'nl2br' => false,
			),
			'conditions'                =>
			array(),
			'_display'                  => 'default',
		),
	),
	'entity_parent'         =>
	array(
		'type'     => 'entity_parent',
		'settings' =>
		array(),
		'realm'    => 2,
		'data'     =>
		array(
			'_admin_only'         => false,
			'_user_register_show' => false,
			'_wp_roles'           => null,
			'label'               => __( 'Listing', 'directories-pro' ),
			'hide_label'          => false,
			'description'         => '',
			'default_value'       => null,
			'required'            => true,
			'admin_unrequired'    => false,
			'disabled'            => false,
			'weight'              => 1,
			'max_num_items'       => 1,
			'widget'              => 'entity_parent',
			'widget_settings'     =>
			array(),
			'conditions'          =>
			array(),
			'_display'            => 'default',
		),
	),
	'entity_meta'           =>
	array(
		'type'     => 'entity_meta',
		'settings' =>
		array(),
		'realm'    => 2,
		'data'     =>
		array(
			'label'            => __( 'Additional Settings', 'directories-pro' ),
			'hide_label'       => false,
			'description'      => '',
			'default_value'    => null,
			'required'         => false,
			'admin_unrequired' => false,
			'disabled'         => false,
			'weight'           => 0,
			'max_num_items'    => 1,
			'widget'           => 'entity_meta',
			'widget_settings'  =>
			array(),
			'conditions'       =>
			array(),
		),
	),
);
