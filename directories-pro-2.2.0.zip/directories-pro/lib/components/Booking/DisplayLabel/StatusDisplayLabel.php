<?php
namespace SabaiApps\Directories\Component\Booking\DisplayLabel;

use SabaiApps\Directories\Component\Display\Label\AbstractLabel;
use SabaiApps\Directories\Component\Entity\Model\Bundle;
use SabaiApps\Directories\Component\Entity\Type\IEntity;

class StatusDisplayLabel extends AbstractLabel {

	protected function _displayLabelInfo( Bundle $bundle ) {
		if ( $bundle->type !== 'booking_booking' ) {
			return false;
		}

		return array(
			'label'            => __( 'Booking status label', 'directories-pro' ),
			'default_settings' => array(
				'_icon' => '',
			),
			'labellable'       => false,
			'colorable'        => false,
		);
	}

	public function displayLabelText( Bundle $bundle, IEntity $entity, array $settings ) {
		return $this->_application->Booking_Util_statusLabel( $entity, true );
	}
}
