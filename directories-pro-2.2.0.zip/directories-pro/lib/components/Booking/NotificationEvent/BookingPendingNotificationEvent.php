<?php
namespace SabaiApps\Directories\Component\Booking\NotificationEvent;

class BookingPendingNotificationEvent extends AbstractBookingNotificationEvent {

	protected function _notificationEntityEventInfo() {
		return array(
			'label'            => __( 'Booking pending review', 'directories-pro' ),
			'default_settings' => array(),
			'actions'          => array(
				'booking_booking_pending',
			),
			'weight'           => 80,
			'testable'         => true,
		);
	}

	protected function _getDefaultNotificationLabel() {
		return sprintf( __( 'A new %1$s has been submitted', 'directories-pro' ), strtolower( $singular = $this->_getContentTypeLabel() ), $singular );
	}

	protected function _getDefaultNotificationBody() {
		return array(
			__( 'A new booking has been requested for the following.', 'directories-pro' ),
			'%parent_title%' . PHP_EOL . '%parent_permalink_url%',
			sprintf( __( 'Booking date/time: %s', 'directories-pro' ), '%field_booking_info__datetime%' )
				. PHP_EOL . sprintf( __( 'Number of spaces booked: %s', 'directories-pro' ), '%field_booking_spaces%' ),
			__( 'You can approve or reject the booking request from the following page.', 'directories-pro' )
				. PHP_EOL . '%dashboard_url%',
		);
	}

	protected function _getDefaultNotificationRecipients() {
		return array(
			'event' => array( 'post_author' ),
		);
	}
}
