<?php
namespace SabaiApps\Directories\Component\Booking\NotificationEvent;

use SabaiApps\Directories\Exception;

class BookingReminderNotificationEvent extends AbstractBookingNotificationEvent {

	protected function _notificationEntityEventInfo() {
		return array(
			'label'            => __( 'Booking reminder', 'directories-pro' ),
			'default_settings' => array(
				'start_before' => 3,
			),
			'actions'          => array(
				'booking_upcoming',
			),
			'weight'           => 85,
			'testable'         => true,
		);
	}

	public function notificationEventSettingsForm( array $settings, array $parents = array() ) {
		return parent::notificationEventSettingsForm( $settings, $parents ) + array(
			'start_before' => array(
				'#type'          => 'slider',
				'#title'         => __( 'Start sending before X days', 'directories-pro' ),
				'#integer'       => true,
				'#min_value'     => 1,
				'#max_value'     => 7,
				'#horizontal'    => true,
				'#default_value' => $settings['start_before'],
			),
		);
	}

	public function notificationEventMessages( array $settings, array $params ) {
		if ( empty( $params[0] )
			|| ( ! $params[0] = $this->_application->Entity_Entity( 'post', $params[0] ) )
		) {
			throw new Exception\RuntimeException( 'Invalid entity ID.' );
		}

		if ( ! $messages = parent::notificationEventMessages( $settings, $params ) ) {
			return;
		}

		$booking = $messages[0]['entity'];
		if ( $booking->getSingleFieldValue( 'booking_info', 'start_date' ) - time() > $settings['start_before'] * 86400 ) {
			return;
		}

		return $messages;
	}


	protected function _getDefaultNotificationLabel() {
		return __( 'Upcoming appointment reminder', 'directories-pro' );
	}

	protected function _getDefaultNotificationBody() {
		return array(
			__( 'Just a friendly reminder that you have an appointment coming up soon!', 'directories-pro' ),
			'%parent_title%' . PHP_EOL . '%parent_permalink_url%',
			sprintf( __( 'Booking date/time: %s', 'directories-pro' ), '%field_booking_info__datetime%' )
				. PHP_EOL . sprintf( __( 'Number of spaces booked: %s', 'directories-pro' ), '%field_booking_spaces%' ),
		);
	}
}
