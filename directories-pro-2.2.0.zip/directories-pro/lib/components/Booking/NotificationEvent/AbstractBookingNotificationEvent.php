<?php
namespace SabaiApps\Directories\Component\Booking\NotificationEvent;

use SabaiApps\Directories\Application;
use SabaiApps\Directories\Component\Entity\Model\Bundle;
use SabaiApps\Directories\Component\Entity\Type\IEntity;
use SabaiApps\Directories\Exception;
use SabaiApps\Directories\Component\Notification\Event\AbstractEntityEvent;

abstract class AbstractBookingNotificationEvent extends AbstractEntityEvent {

	public function __construct( Application $application, $name ) {
		parent::__construct( $application, $name, 'booking_booking' );
	}

	public function notificationEventMessages( array $settings, array $params ) {
		if ( ! isset( $params[0] )
			|| ! $params[0] instanceof IEntity
		) {
			throw new Exception\RuntimeException( 'Invalid entity.' );
		}

		if ( ! $this->_isBundleEnabled( $params[0], $settings ) ) {
			return;
		}

		return array( array( 'entity' => $params[0] ) );
	}

	public function notificationEventMessageMeta( array $settings ) {
		$meta           = parent::notificationEventMessageMeta( $settings );
		$meta['tags'][] = '%field_booking_info__datetime%';
		$meta['tags'][] = '%field_booking_spaces%';
		return $meta;
	}

	protected function _isEventBundle( Bundle $bundle ) {
		return true;
	}
}
