<?php
namespace SabaiApps\Directories\Component\Booking\NotificationEvent;

class BookingCancelledNotificationEvent extends AbstractBookingNotificationEvent {

	protected function _notificationEntityEventInfo() {
		return array(
			'label'            => __( 'Booking cancelled', 'directories-pro' ),
			'default_settings' => array(),
			'actions'          => array(
				'booking_booking_cancelled',
			),
			'weight'           => 83,
			'testable'         => true,
		);
	}

	protected function _getDefaultNotificationLabel() {
		return __( 'Booking cancelled', 'directories-pro' );
	}

	protected function _getDefaultNotificationBody() {
		return array(
			__( 'Your booking has been cancelled.', 'directories-pro' ),
			'%parent_title%' . PHP_EOL . '%parent_permalink_url%',
			sprintf( __( 'Booking date/time: %s', 'directories-pro' ), '%field_booking_info__datetime%' )
				. PHP_EOL . sprintf( __( 'Number of spaces booked: %s', 'directories-pro' ), '%field_booking_spaces%' ),
		);
	}
}
