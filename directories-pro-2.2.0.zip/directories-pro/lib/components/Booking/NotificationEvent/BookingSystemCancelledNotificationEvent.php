<?php
namespace SabaiApps\Directories\Component\Booking\NotificationEvent;

class BookingSystemCancelledNotificationEvent extends AbstractBookingNotificationEvent {

	protected function _notificationEntityEventInfo() {
		return array(
			'label'            => __( 'Booking cancelled (schedule change)', 'directories-pro' ),
			'default_settings' => array(),
			'actions'          => array(
				'booking_booking_system_cancelled',
			),
			'weight'           => 84,
			'testable'         => true,
		);
	}

	protected function _getDefaultNotificationLabel() {
		return __( 'Booking cancelled due to schedule change', 'directories-pro' );
	}

	protected function _getDefaultNotificationBody() {
		return array(
			__( 'We are writing to let you know that your upcoming booking has been cancelled due to a necessary update to our schedule.', 'directories-pro' ),
			__( 'We sincerely apologize for any inconvenience this may cause.', 'directories-pro' ),
			__( 'Cancelled Booking Details:', 'directories-pro' )
				. PHP_EOL . sprintf( __( 'Service: %s', 'directories-pro' ), '%parent_title%' )
				. PHP_EOL . sprintf( __( 'Booking date/time: %s', 'directories-pro' ), '%field_booking_info__datetime%' )
				. PHP_EOL . sprintf( __( 'Number of spaces booked: %s', 'directories-pro' ), '%field_booking_spaces%' )
				. PHP_EOL . sprintf( __( 'URL: %s', 'directories-pro' ), '%parent_permalink_url%' ),
		);
	}
}
