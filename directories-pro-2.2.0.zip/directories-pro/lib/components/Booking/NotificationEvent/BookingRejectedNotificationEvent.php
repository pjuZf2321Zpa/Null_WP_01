<?php
namespace SabaiApps\Directories\Component\Booking\NotificationEvent;

class BookingRejectedNotificationEvent extends AbstractBookingNotificationEvent {

	protected function _notificationEntityEventInfo() {
		return array(
			'label'            => __( 'Booking rejected', 'directories-pro' ),
			'default_settings' => array(),
			'actions'          => array(
				'booking_booking_rejected',
			),
			'weight'           => 82,
			'testable'         => true,
		);
	}

	protected function _getDefaultNotificationLabel() {
		return __( 'Booking rejected', 'directories-pro' );
	}

	protected function _getDefaultNotificationBody() {
		return array(
			__( 'Your booking has been rejected.', 'directories-pro' ),
			'%parent_title%' . PHP_EOL . '%parent_permalink_url%',
			sprintf( __( 'Booking date/time: %s', 'directories-pro' ), '%field_booking_info__datetime%' )
				. PHP_EOL . sprintf( __( 'Number of spaces booked: %s', 'directories-pro' ), '%field_booking_spaces%' ),
		);
	}
}
