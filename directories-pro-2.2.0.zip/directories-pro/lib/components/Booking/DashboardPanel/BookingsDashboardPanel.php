<?php
namespace SabaiApps\Directories\Component\Booking\DashboardPanel;

use SabaiApps\Directories\Component\Dashboard\Panel\AbstractPanel;
use SabaiApps\Framework\User\AbstractIdentity;

class BookingsDashboardPanel extends AbstractPanel {

	protected function _dashboardPanelInfo() {
		return array(
			'label'         => __( 'Bookings', 'directories-pro' ),
			'weight'        => 8,
			'guest_allowed' => true,
		);
	}

	protected function _dashboardPanelLinks( array $settings, ?AbstractIdentity $identity = null ) {
		if ( isset( $identity ) ) {
			return; // Do not show if public dashboard
		}

		$ret       = array();
		$weight    = 0;
		$all_pages = $this->_bookingsPanelPages();
		// Allow your bookings page only if anonymous
		if ( $this->_application->getUser()->isAnonymous() ) {
			$all_pages = array(
				'bookings' => $all_pages['bookings'],
			);
		}

		$pages = isset( $settings['pages']['default'] ) ? $settings['pages']['default'] : array_keys( $all_pages );
		foreach ( $pages as $page ) {
			if ( ! isset( $all_pages[ $page ] ) ) {
				continue;
			}

			$ret[ $page ] = $all_pages[ $page ];
			if ( isset( $settings['pages']['options'][ $page ] ) ) {
				$ret[ $page ]['title']           = $settings['pages']['options'][ $page ];
				$ret[ $page ]['title_is_custom'] = true;
			}
			$ret[ $page ]['weight'] = ++$weight;
		}
		return $ret;
	}

	protected function _bookingsPanelPages() {
		return array(
			'bookings'          => array(
				'title'  => __( 'Your Bookings', 'directories-pro' ),
				'icon'   => 'fas fa-calendar-check',
				'weight' => 1,
			),
			'bookings_received' => array(
				'title'  => __( 'Bookings Received', 'directories-pro' ),
				'icon'   => 'far fa-calendar-check',
				'weight' => 2,
			),
		);
	}

	public function dashboardPanelSettingsForm( array $settings, array $parents ) {
		$options = array();
		foreach ( $this->_bookingsPanelPages() as $link_name => $link ) {
			$options[ $link_name ] = isset( $settings['pages']['options'][ $link_name ] ) ? $settings['pages']['options'][ $link_name ] : $link['title'];
		}
		return array(
			'pages' => array(
				'#title'                  => __( 'Select subpanels', 'directories-pro' ),
				'#type'                   => 'options',
				'#horizontal'             => true,
				'#disable_add'            => true,
				'#disable_icon'           => true,
				'#disable_add_csv'        => true,
				'#multiple'               => true,
				'#options_value_disabled' => true,
				'#default_value'          => array(
					'options' => $options,
					'default' => isset( $settings['pages']['default'] ) ? $settings['pages']['default'] : array_keys( $options ),
				),
				'#options_placeholder'    => $options,
			),
		);
	}

	public function dashboardPanelContent( $link, array $settings, array $params, ?AbstractIdentity $identity = null ) {
		return $this->_application->getPlatform()->render(
			$this->_application->Dashboard_Panels_panelUrl( 'booking_bookings', $link, '/' . $link, array(), true, $identity ),
			array(
				'is_dashboard' => false, // prevent rendering duplicate panel sections on reload panel
				'identity'     => $identity,
			)
		);
	}
}
