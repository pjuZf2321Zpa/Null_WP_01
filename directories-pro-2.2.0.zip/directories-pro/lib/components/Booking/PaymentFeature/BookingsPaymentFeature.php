<?php
namespace SabaiApps\Directories\Component\Booking\PaymentFeature;

use SabaiApps\Directories\Component\Payment;
use SabaiApps\Directories\Component\Entity\Type\IEntity;
use SabaiApps\Directories\Component\Entity\Model\Bundle;

class BookingsPaymentFeature extends Payment\Feature\AbstractFeature implements Payment\Feature\IAddonFeature {

	protected function _paymentFeatureInfo() {
		return array(
			'label'            => _x( 'Bookings', 'payment feature', 'directories-pro' ),
			'weight'           => 50,
			'default_settings' => array(
				'enable' => false,
			),
		);
	}

	public function paymentFeatureSupports( Bundle $bundle, $planType = 'base' ) {
		return ! empty( $bundle->info['booking_enable'] );
	}

	public function paymentFeatureSettingsForm( Bundle $bundle, array $settings, $planType = 'base', array $parents = array() ) {
		return $this->_getSettingsForm( $settings );
	}

	protected function _getSettingsForm( array $settings, $horizontal = true ) {
		return array(
			'enable' => array(
				'#title'         => __( 'Enable bookings', 'directories-pro' ),
				'#type'          => 'checkbox',
				'#default_value' => ! empty( $settings['enable'] ),
				'#horizontal'    => $horizontal,
			),
		);
	}

	public function paymentFeatureIsEnabled( Bundle $bundle, array $settings ) {
		return ! empty( $settings['enable'] );
	}

	public function paymentFeatureRender( Bundle $bundle, array $settings, ?Payment\IPlan $plan = null ) {
		return array(
			array(
				'icon' => 'fas fa-calendar-check',
				'html' => $this->_application->H( _x( 'Bookings', 'payment feature', 'directories-pro' ) ),
			),
		);
	}

	public function paymentFeatureApply( IEntity $entity, $featureName, array $featureSettings, array &$values, $orderId, $isAddon = false ) {
		if ( ! $isAddon ) {
			return;
		}

		return $this->_applyAddonFeature( $entity, $featureName, $featureSettings, $values, $orderId );
	}

	public function paymentFeatureUnapply( IEntity $entity, $featureName, array $featureSettings, array &$values, $orderId, $isAddon = false ) {
		if ( ! $isAddon ) {
			return;
		}

		return $this->_unapplyAddonFeature( $entity, $featureName, $featureSettings, $values, $orderId );
	}

	public function paymentAddonFeatureSupports( Bundle $bundle ) {
		return $this->paymentFeatureSupports( $bundle );
	}

	public function paymentAddonFeatureSettingsForm( Bundle $bundle, array $settings, array $parents = array() ) {
		return $this->_getSettingsForm( $settings );
	}

	public function paymentAddonFeatureExtraSettingsForm( Bundle $bundle, array $planFeatures, array $currentExtraFeatures, array $parents = array() ) {
		return $this->_getSettingsForm( $currentExtraFeatures, false );
	}

	public function paymentAddonFeatureIsEnabled( Bundle $bundle, array $settings ) {
		return empty( $settings['enable'] ) ? false : $settings;
	}

	public function paymentAddonFeatureIsOrderable( array $settings, array $currentFeatures ) {
		return $this->paymentAddonFeatureExtraIsOrderable( $currentFeatures );
	}

	public function paymentAddonFeatureExtraIsOrderable( array $planFeatures ) {
		// Can't order if already enabled
		return ! isset( $planFeatures[ $this->_name ] );
	}

	public function paymentAddonFeatureExtraApply( $feature, $extra ) {
		if ( empty( $feature['enable'] )
			&& ! empty( $extra['enable'] )
		) {
			$feature['enable'] = true;
		}
		return $feature;
	}
}
