<?php
namespace SabaiApps\Directories\Component\Booking\CSVExporter;

use SabaiApps\Directories\Component\CSV\Exporter\AbstractExporter;
use SabaiApps\Directories\Component\Entity\Model\Field;

class BookingCSVExporter extends AbstractExporter {

	public function csvExporterDoExport( Field $field, array $settings, $value, array $columns, array &$formStorage, array &$logs ) {
		switch ( $this->_name ) {
			case 'booking_date':
				if ( ! isset( $value[0] ) ) {
					return;
				}

				return json_encode( array( $value[0] ) );
			case 'booking_status':
				return $value[0];
		}
	}
}
