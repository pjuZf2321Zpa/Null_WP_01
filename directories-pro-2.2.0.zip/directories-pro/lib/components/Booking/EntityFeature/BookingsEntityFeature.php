<?php
namespace SabaiApps\Directories\Component\Booking\EntityFeature;

use SabaiApps\Directories\Component\Entity\Feature\AbstractFeature;
use SabaiApps\Directories\Component\Entity\Model\Bundle;

class BookingsEntityFeature extends AbstractFeature {

	protected function _entityFeatureInfo() {
		return array(
			'label'            => __( 'Bookings', 'directories-pro' ),
			'weight'           => 50,
			'default_settings' => array(
				'enable' => false,
			),
		);
	}

	public function entityFeatureSupports( Bundle $bundle, $planType = 'base' ) {
		return ! empty( $bundle->info['booking_enable'] );
	}

	public function entityFeatureSettingsForm( Bundle $bundle, array $settings, array $parents = array() ) {
		return array(
			'enable' => array(
				'#title'         => __( 'Enable bookings', 'directories-pro' ),
				'#type'          => 'checkbox',
				'#default_value' => ! empty( $settings['enable'] ),
				'#horizontal'    => true,
			),
		);
	}

	public function entityFeatureIsEnabled( Bundle $bundle, array $settings ) {
		return ! empty( $settings['enable'] );
	}
}
