<?php
namespace SabaiApps\Directories\Component\Booking\FieldType;

use SabaiApps\Directories\Component\Field\Type\AbstractValueType;
use SabaiApps\Directories\Component\Field\Type\IColumnable;
use SabaiApps\Directories\Component\Field\Type\IRestrictable;
use SabaiApps\Directories\Component\Field\IField;
use SabaiApps\Directories\Component\Entity\Type\IEntity;

class StatusFieldType extends AbstractValueType implements IColumnable, IRestrictable {

	protected function _fieldTypeInfo() {
		return array(
			'label'       => __( 'Booking Status', 'directories-pro' ),
			'admin_only'  => true,
			'schema_type' => 'string',
		);
	}

	public function fieldColumnableInfo( IField $field ) {
		return array(
			'' => array(
				'label' => $field->getFieldLabel(),
			),
		);
	}

	public function fieldColumnableColumn( IField $field, IEntity $entity, $column = '' ) {
		$values   = $entity->getFieldValue( $field->getFieldName() );
		$status   = isset( $values[0] ) ? $values[0] : 'pending';
		$statuses = $this->_application->Booking_Util_statuses();
		if ( ! isset( $statuses[ $status ] ) ) {
			return;
		}

		return $this->_application->Booking_Util_statusHtmlLabel( $statuses[ $status ]['label'], $statuses[ $status ]['color'] );
	}

	public function fieldRestrictableOptions( IField $field ) {
		$ret = array();
		foreach ( $this->_application->Booking_Util_statuses() as $status => $status_info ) {
			$ret[ $status ] = $status_info['label'];
		}
		return array( 'status' => $ret );
	}

	public function fieldRestrictableRestrict( IField $field, $value, $name ) {
		return ( $value === 'pending' ) ? array( 'compare' => 'NULL' ) : array();
	}
}
