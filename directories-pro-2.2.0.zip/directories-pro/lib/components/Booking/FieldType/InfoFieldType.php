<?php
namespace SabaiApps\Directories\Component\Booking\FieldType;

use SabaiApps\Directories\Component\Field\Type\AbstractType;
use SabaiApps\Directories\Component\Field\Type\IColumnable;
use SabaiApps\Directories\Component\Field\IField;
use SabaiApps\Directories\Component\Entity\Type\IEntity;
use SabaiApps\Directories\Application;
use SabaiApps\Directories\Component\Field\Type\IHumanReadable;

class InfoFieldType extends AbstractType implements IColumnable, IHumanReadable {

	protected function _fieldTypeInfo() {
		return array(
			'label'      => __( 'Booking Info', 'directories-pro' ),
			'creatable'  => false,
			'disablable' => false,
			'requirable' => false,
			'required'   => true,
		);
	}

	public function fieldTypeSchema( array $settings = array() ) {
		return array(
			'columns' => array(
				'start_date'                    => array(
					'type'     => Application::COLUMN_INTEGER,
					'notnull'  => true,
					'unsigned' => true,
					'length'   => 10,
					'default'  => 0,
				),
				'end_date'                      => array(
					'type'     => Application::COLUMN_INTEGER,
					'notnull'  => true,
					'unsigned' => true,
					'length'   => 10,
					'default'  => 0,
				),
				'occurrence_hash'               => array(
					'type'    => Application::COLUMN_VARCHAR,
					'notnull' => true,
					'length'  => 64,
					'default' => '',
				),
				'occurrence_slot_data_snapshot' => array(
					'type'    => Application::COLUMN_JSON,
					'notnull' => false,
					'default' => null,
				),
			),
			'indexes' => array(
				'occurrence_hash' => array(
					'fields' => array( 'occurrence_hash' => array( 'sorting' => 'ascending' ) ),
				),
			),
		);
	}

	public function fieldTypeOnSaveValues( IField $field, array $values, ?array $currentValues = null, array &$extraArgs = array() ) {
		$ret = array();
		foreach ( $values as $weight => $value ) {
			if ( ! is_array( $value )
				|| empty( $value['occurrence_hash'] )
				|| ( ! $occurrence = $this->_application->Calendar_Calendar_isValidOccurrence( $value['occurrence_hash'] ) )
			) {
				continue;
			}

			$ret[] = array(
				'start_date'                    => $occurrence->start_date,
				'end_date'                      => $occurrence->end_date,
				'occurrence_hash'               => $occurrence->hash,
				'occurrence_slot_data_snapshot' => $occurrence->slot_data_snapshot,
			);
		}

		return $ret;
	}

	public function fieldColumnableInfo( IField $field ) {
		return array(
			'date' => array(
				'label'  => __( 'Booking date', 'directories-pro' ),
				'sortby' => array( 'start_date' ),
			),
		);
	}

	public function fieldColumnableColumn( IField $field, IEntity $entity, $column = '' ) {
		switch ( $column ) {
			case 'date':
				if ( ( ! $value = $entity->getSingleFieldValue( $field->getFieldName() ) )
					|| empty( $value['start_date'] )
					|| empty( $value['end_date'] )
				) {
					return;
				}

				return $this->_application->Booking_Util_renderDate( $value['start_date'], $value['end_date'] );
		}
	}

	public function fieldHumanReadableText( IField $field, IEntity $entity, $separator = null, $key = null ) {
		if ( isset( $key ) && $key !== 'datetime' ) {
			return '';
		}
		if ( ! $value = $entity->getSingleFieldValue( $field->getFieldName(), 'start_date' ) ) {
			return '';
		}

		return $this->_application->System_Date_datetime( $value );
	}
}
