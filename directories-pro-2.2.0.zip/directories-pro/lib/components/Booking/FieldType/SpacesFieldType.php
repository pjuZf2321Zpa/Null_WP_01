<?php
namespace SabaiApps\Directories\Component\Booking\FieldType;

use SabaiApps\Directories\Component\Field\Type\AbstractValueType;
use SabaiApps\Directories\Component\Field\Type\IColumnable;
use SabaiApps\Directories\Component\Field\IField;
use SabaiApps\Directories\Component\Entity\Type\IEntity;
use SabaiApps\Directories\Component\Field\Type\IHumanReadable;

class SpacesFieldType extends AbstractValueType implements IColumnable, IHumanReadable {

	protected function _fieldTypeInfo() {
		return array(
			'label'       => __( 'Booking Spaces', 'directories-pro' ),
			'creatable'   => false,
			'disablable'  => false,
			'requirable'  => false,
			'required'    => true,
			'schema_type' => 'number',
		);
	}

	public function fieldColumnableInfo( IField $field ) {
		return array(
			'' => array(
				'label' => $field->getFieldLabel(),
			),
		);
	}

	public function fieldColumnableColumn( IField $field, IEntity $entity, $column = '' ) {
		$value = $entity->getSingleFieldValue( $field->getFieldName() );
		return isset( $value ) ? (int) $value : '';
	}

	public function fieldHumanReadableText( IField $field, IEntity $entity, $separator = null, $key = null ) {
		if ( null === $value = $entity->getSingleFieldValue( $field->getFieldName() ) ) {
			return '';
		}

		return sprintf( _n( '%d space', '%d spaces', $value, 'directories-pro' ), $value );
	}
}
