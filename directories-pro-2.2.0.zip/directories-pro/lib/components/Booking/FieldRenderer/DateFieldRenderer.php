<?php
namespace SabaiApps\Directories\Component\Booking\FieldRenderer;

use SabaiApps\Directories\Component\Entity\Type\IEntity;
use SabaiApps\Directories\Component\Field\IField;
use SabaiApps\Directories\Component\Field\Renderer\AbstractRenderer;

class DateFieldRenderer extends AbstractRenderer {

	protected function _fieldRendererInfo() {
		return array(
			'field_types'      => array( 'booking_info' ),
			'default_settings' => array(
				'_separator' => ', ',
			),
		);
	}

	protected function _fieldRendererRenderField( IField $field, array &$settings, IEntity $entity, array $values, ?array $context = null, $more = 0 ) {
		$ret = array();
		foreach ( $values as $value ) {
			$ret[] = $this->_application->Booking_Util_renderDate( $value['start_date'], $value['end_date'] );
		}
		return implode( $settings['_separator'], $ret );
	}
}
