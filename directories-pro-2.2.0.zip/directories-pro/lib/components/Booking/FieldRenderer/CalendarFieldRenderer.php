<?php
namespace SabaiApps\Directories\Component\Booking\FieldRenderer;

use SabaiApps\Directories\Component\Entity\Model\Bundle;
use SabaiApps\Directories\Component\Field\IField;
use SabaiApps\Directories\Component\Entity\Type\IEntity;
use SabaiApps\Directories\Component\Calendar\FieldRenderer\CalendarFieldRenderer as CalendarFieldRendererBase;

class CalendarFieldRenderer extends CalendarFieldRendererBase {

	protected function _fieldRendererInfo() {
		$info = parent::_fieldRendererInfo();
		$info['default_settings']['booking_allowed_only'] = true;
		return $info;
	}

	public function fieldRendererSupports( Bundle $bundle, IField $field ) {
		return ! empty( $bundle->info['booking_enable'] )
			&& ( $field_settings = $field->getFieldSettings() )
			&& ! empty( $field_settings['enable_booking'] );
	}

	public function fieldRendererSettingsForm( IField $field, array $settings, array $parents = array() ) {
		return parent::fieldRendererSettingsForm( $field, $settings, $parents ) + array(
			'booking_allowed_only'           => array(
				'#type'          => 'checkbox',
				'#title'         => __( 'Only show bookable slots', 'directories-pro' ),
				'#default_value' => ! empty( $settings['booking_allowed_only'] ),
				'#weight'        => 2,
			),
			'booking_display_next_available' => array(
				'#type'          => 'checkbox',
				'#title'         => __( 'Display "Next Available Date" summary', 'directories-pro' ),
				'#description'   => __( 'Show a brief text summary above the calendar.', 'directories-pro' ),
				'#default_value' => ! empty( $settings['booking_display_next_available'] ),
				'#weight'        => 3,
			),
			'booking_auto_jump'              => array(
				'#type'          => 'checkbox',
				'#title'         => __( 'Auto-jump to the first available slot', 'directories-pro' ),
				'#description'   => __( 'Automatically navigate the calendar to the month with the next occurrence.', 'directories-pro' ),
				'#default_value' => ! empty( $settings['booking_auto_jump'] ),
				'#weight'        => 4,
			),
		);
	}

	protected function _fieldRendererRenderField( IField $field, array &$settings, IEntity $entity, array $values, ?array $context = null, $more = 0 ) {
		if ( $field->Bundle
			&& ! empty( $field->Bundle->info['booking_enable'] )
			&& ( $booking_bundle = $this->_application->Entity_Bundle( 'booking_booking', $field->Bundle->group ) )
		) {
			$this->_application->Entity_Form_loadAssets( $booking_bundle );
		}

		return parent::_fieldRendererRenderField( $field, $settings, $entity, $values, $context, $more );
	}

	protected function _getViewSettings( IField $field, array &$settings, IEntity $entity ) {
		return parent::_getViewSettings( $field, $settings, $entity ) + array(
			'booking_enable'       => true,
			'booking_allowed_only' => ! empty( $settings['booking_allowed_only'] ),
		);
	}
}
