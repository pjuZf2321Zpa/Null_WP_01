<?php
namespace SabaiApps\Directories\Component\Booking\FieldRenderer;

use SabaiApps\Directories\Component\Entity\Type\IEntity;
use SabaiApps\Directories\Component\Field\IField;
use SabaiApps\Directories\Component\Field\Renderer\AbstractRenderer;

class SpacesFieldRenderer extends AbstractRenderer {

	protected function _fieldRendererInfo() {
		return array(
			'field_types'      => array( $this->_name ),
			'default_settings' => array(
				'_separator' => ', ',
			),
		);
	}

	protected function _fieldRendererRenderField( IField $field, array &$settings, IEntity $entity, array $values, ?array $context = null, $more = 0 ) {
		$ret = array();
		foreach ( $values as $value ) {
			$ret[] = sprintf( _n( '%d space', '%d spaces', $value, 'directories-pro' ), $value );
		}
		return implode( $settings['_separator'], $ret );
	}
}
