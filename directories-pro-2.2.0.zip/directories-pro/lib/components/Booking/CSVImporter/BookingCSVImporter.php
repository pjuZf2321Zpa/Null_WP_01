<?php
namespace SabaiApps\Directories\Component\Booking\CSVImporter;

use SabaiApps\Directories\Component\CSV\Importer\AbstractImporter;
use SabaiApps\Directories\Component\Entity\Model\Field;

class BookingCSVImporter extends AbstractImporter {

	public function csvImporterDoImport( Field $field, array $settings, $column, $value, &$formStorage, array &$logs ) {
		switch ( $this->_name ) {
			case 'booking_date':
				if ( ( ! $value = json_decode( $value ) )
					|| ! is_array( $value )
				) {
					return;
				}

				$ret = array();
				if ( ! isset( $value[0] ) ) {
					$value = array( $value );
				}
				// Need to convert each to array since json_decode will return object(s)
				foreach ( $value as $_value ) {
					$ret[] = (array) $_value;
				}
				return $ret;
			case 'booking_status':
				return array( array( 'value' => $value ) );
		}
	}
}
