<?php
/**
 * Plugin Name: Directories Pro
 * Plugin URI: https://directoriespro.com/
 * Description: Build a directory website with listings, categories, maps, search and more.
 * Author: SabaiApps
 * Author URI: https://codecanyon.net/user/onokazu/portfolio?ref=onokazu
 * Text Domain: directories-pro
 * Domain Path: /languages
 * Version: 2.2.0
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( '\SabaiApps\Directories\Platform\WordPress\Loader', false ) ) {
	require __DIR__ . '/lib/application/Platform/WordPress/Loader.php';
}
\SabaiApps\Directories\Platform\WordPress\Loader::register( __DIR__, '2.2.0' );

add_filter(
	'drts_core_component_paths',
	function ( $paths ) {
		// Remove old Directories Pro component paths
		unset( $paths['directories'], $paths['directories-frontend'], $paths['directories-faker'], $paths['directories-payments'], $paths['directories-reviews'] );
		$paths['directories-pro'] = array( __DIR__ . '/lib/components', '2.2.0' );
		return $paths;
	},
	99
);

if ( ! function_exists( 'drts' ) ) {
	function drts() {
		return \SabaiApps\Directories\Platform\WordPress\Loader::getPlatform()->getApplication();
	}
}
if ( ! function_exists( 'drts_fs' ) ) {
	function drts_fs() {
		return \SabaiApps\Directories\Platform\WordPress\Loader::freemius();
	}
}

// Deactivate deprecated plugins if active
add_action(
	'plugins_loaded',
	function () {
		$deactivated_plugins = array();
		foreach ( array( 'directories', 'directories-frontend', 'directories-faker', 'directories-payments', 'directories-reviews' ) as $plugin ) {
			if ( is_plugin_active( $plugin_file = $plugin . '/' . $plugin . '.php' ) ) {
				deactivate_plugins( $plugin_file );
				$deactivated_plugins[] = $plugin;
			}
		}
		if ( ! empty( $deactivated_plugins ) ) {
			drts()->LocalComponents( true );
			add_action(
				'admin_notices',
				function () use ( $deactivated_plugins ) {
					printf(
						'<div class="notice notice-warning is-dismissible"><p>%s</p></div>',
						sprintf(
							esc_html__( 'The following plugin(s) have been deactivated as they are now included in %1$s: %2$s. You may safely delete these plugin(s).', 'directories-pro' ),
							'<strong>Directories Pro</strong>',
							'<strong>' . implode( ', ', $deactivated_plugins ) . '</strong>'
						)
					);
				}
			);
		}
	},
	1
);
