<?php if (!defined('ABSPATH')) exit; ?>
<div class="drts-view-filter-entities <?php echo $this->H($html_attributes['class']);?>"<?php echo $this->Attr($html_attributes, 'class');?>>
    <div class="drts-view-filter-entities-header">        
        <?php /* translators: %s: search query text labels */ ?>
        <div class="drts-view-entities-filters-search-labels <?php echo DRTS_BS_PREFIX;?>fs-5 <?php echo DRTS_BS_PREFIX;?>mb-2 <?php echo DRTS_BS_PREFIX;?>fw-bold <?php echo DRTS_BS_PREFIX;?>text-center"><?php if (isset($search_labels)):?><?php printf($this->H(__('Search: %s', 'directories-pro')), $this->Search_Form_renderSearchLabels($search_labels));?><?php endif;?></div>
        <div class="drts-view-entities-filters-applied <?php echo DRTS_BS_PREFIX;?>mb-1"></div>
    </div>
    <div class="drts-view-filter-entities-form <?php echo DRTS_BS_PREFIX;?>mb-2">
        <?php $this->display('view_filter_form', $CONTEXT->getAttributes());?>
    </div>
    <div class="drts-view-filter-entities-footer <?php echo DRTS_BS_PREFIX;?>d-flex <?php echo DRTS_BS_PREFIX;?>justify-content-between <?php echo DRTS_BS_PREFIX;?>align-items-center">
        <div class="<?php echo DRTS_BS_PREFIX;?>d-flex <?php echo DRTS_BS_PREFIX;?>gap-2"> </div>
        <div class="<?php echo DRTS_BS_PREFIX;?>d-flex <?php echo DRTS_BS_PREFIX;?>gap-2">
            <button type="button" class="drts-view-filter-reset <?php echo DRTS_BS_PREFIX;?>invisible <?php echo DRTS_BS_PREFIX;?>btn<?php if ($btn_size):?> <?php echo DRTS_BS_PREFIX;?>btn-<?php echo $this->H($btn_size);?><?php endif;?> <?php echo DRTS_BS_PREFIX;?>btn-outline-<?php echo $this->H($btn_color);?>"><?php echo $this->H(__('Reset', 'directories-pro'))?></button>
            <button type="button" class="drts-view-filter-trigger <?php echo DRTS_BS_PREFIX;?>btn<?php if ($btn_size):?> <?php echo DRTS_BS_PREFIX;?>btn-<?php echo $this->H($btn_size);?><?php endif;?> <?php echo DRTS_BS_PREFIX;?>btn-<?php echo $this->H($btn_color);?>" data-view-filter-ajax-disable="1">
            <?php /* translators: %s: number of items found and their label, e.g. 10 listings */ ?>
            <?php printf(_x('Show %s', 'show x items', 'directories-pro'), sprintf($this->H(($num_found == 1 ? $bundle->getLabel('count') : $bundle->getLabel('count2'))), '<span class="drts-view-filter-entities-num-found">' . $num_found . '</span>'));?>
            </button>
        </div>
    </div>
</div> 