<?php if (!defined('ABSPATH')) exit; ?>
<?php if (empty($entities)) { $this->display('view_entities_none', $CONTEXT->getAttributes()); return; }?>
<div class="drts-comparison-grid-container" data-bundle-name="<?php echo $bundle->name;?>">
    <div class="drts-comparison-grid" style="--rows: <?php echo intval($settings['compare_grid_rows']);?>; --label-width: <?php echo intval($settings['compare_label_width']) . 'px';?>; --item-width: <?php echo intval($settings['compare_item_width']) . 'px';?>; --img-size: <?php echo intval($settings['compare_image_width']) . 'px';?>;">
        <div class="drts-comparison-grid-label drts-comparison-sticky-top drts-comparison-sticky-left"></div>
<?php foreach ($settings['compare_fields'] as $field_key => $field_name):?>
<?php   if ((!$field = $this->Entity_Field($bundle, $field_name)) || (!$field_type = $this->Field_Type($field->getFieldType(), true)) || (!$labels = $field_type->fieldComparableItemLabels($field))):?>
<?php     unset($settings['compare_fields'][$field_key]); continue;?>
<?php   endif;?>
<?php   foreach ($labels as $item_name => $item_label):?>
        <div class="drts-comparison-grid-label drts-comparison-sticky-left" data-field-name="<?php echo $this->H($field_name);?>" data-field-type="<?php echo $this->H($field->getFieldType());?>" data-item-name="<?php echo $this->H($item_name);?>"><?php echo $this->H($item_label);?></div>
<?php   endforeach;?>
<?php endforeach;?>    
<?php foreach (array_keys($entities) as $entity_id): $entity = $entities[$entity_id];?>  
        <div class="drts-comparison-grid-item drts-comparison-grid-header drts-comparison-sticky-top" data-entity-id="<?php echo $entity_id;?>">
<?php   if (!empty($settings['compare_image_field'])):?>
            <img src="<?php echo $this->Entity_Image($entity, $settings['compare_image_size'], $settings['compare_image_field'], true);?>" alt="">
<?php   endif;?>
<?php   echo $this->Entity_Permalink($entity);?>
<?php   if (!empty($settings['compare_remove_button'])):?>
            <button class="drts-comparison-grid-remove-item <?php echo DRTS_BS_PREFIX; ?>btn <?php echo DRTS_BS_PREFIX; ?>btn-link <?php echo DRTS_BS_PREFIX; ?>position-absolute <?php echo DRTS_BS_PREFIX; ?>top-0 <?php echo DRTS_BS_PREFIX; ?>end-0 <?php echo DRTS_BS_PREFIX; ?>m-1 <?php echo DRTS_BS_PREFIX; ?>p-0 <?php echo DRTS_BS_PREFIX; ?>lh-1 "><i class="drts-icon drts-icon-sm fas fa-times"></i></button>
<?php   endif;?>
        </div>
<?php   foreach ($settings['compare_fields'] as $field_name): $field = $this->Entity_Field($bundle, $field_name); $field_type = $this->Field_Type($field->getFieldType());?>
<?php     foreach ($field_type->fieldComparableItemValues($field, $entity) as $item_name => $item_value):?>
        <div class="drts-comparison-grid-item" data-entity-id="<?php echo $entity_id;?>" data-field-name="<?php echo $this->H($field_name);?>" data-field-type="<?php echo $this->H($field->getFieldType());?>" data-item-name="<?php echo $this->H($item_name);?>">
<?php       echo strlen($item_value) ? $item_value : '-';?>
        </div>
<?php     endforeach;?>
<?php   endforeach;?>
<?php endforeach;?>  
    </div>
</div>