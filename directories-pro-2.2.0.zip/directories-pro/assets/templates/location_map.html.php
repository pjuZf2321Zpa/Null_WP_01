<?php
if (!defined('ABSPATH')) exit;
if (empty($entities)) {
    if (empty($skip_view_entities_none)) $this->display('view_entities_none', $CONTEXT->getAttributes());
    return;
}
?>
<div class="drts-location-map-container<?php if (!empty($classes)):?> <?php echo $this->H(implode(' ', $classes));?><?php endif;?>"<?php if (!empty($settings['map']['fullscreen_offset'])):?> data-fullscreen-offset="<?php echo $this->H($settings['map']['fullscreen_offset']);?>"<?php endif;?><?php if (!empty($settings['map']['height'])):?> style="height:<?php echo intval($settings['map']['height']);?>px;"<?php endif;?>>
    <?php $this->Action('location_before_map', [$CONTEXT]);?>
    <?php $this->display(
        'map_map',
        [
            'settings' => $settings['map'],
            'field' => $settings['map']['coordinates_field'],
            'display' => isset($settings['display']) && (string)$view === 'map' ? $settings['display'] : null,
            'draw_options' => $this->Location_DrawMapOptions([], $CONTEXT)
        ] + $CONTEXT->getAttributes()
    );?>
    <?php $this->Action('location_after_map', [$CONTEXT]);?>
</div>
