<?php if (!defined('ABSPATH')) exit; ?>
<div class="drts-dashboard<?php if (isset($dashboard_user)):?> drts-dashboard-user<?php endif;?> <?php echo DRTS_BS_PREFIX;?>row">
    <div class="drts-dashboard-aside <?php echo DRTS_BS_PREFIX;?>col-md-3 <?php echo DRTS_BS_PREFIX;?>offcanvas-md <?php echo DRTS_BS_PREFIX;?>offcanvas-start <?php echo DRTS_BS_PREFIX;?>overflow-y-scroll" id="<?php echo $dashboard_id;?>-offcanvas" data-bs-scroll="true" >
        <div class="<?php echo DRTS_BS_PREFIX;?>offcanvas-header">
            <h5 class="<?php echo DRTS_BS_PREFIX;?>offcanvas-title <?php echo DRTS_BS_PREFIX;?>m-0 <?php echo DRTS_BS_PREFIX;?>p-0"><?php echo $this->H($dashboard_menu_title);?></h5>
            <button type="button" class="<?php echo DRTS_BS_PREFIX;?>btn-close" data-bs-dismiss="offcanvas" data-bs-target="#<?php echo $dashboard_id;?>-offcanvas" aria-label="Close"></button>
        </div>
        <div class="<?php echo DRTS_BS_PREFIX;?>offcanvas-body <?php echo DRTS_BS_PREFIX;?>d-md-block">
            <div class="drts-dashboard-links <?php echo DRTS_BS_PREFIX;?>accordion" id="<?php echo $dashboard_id;?>-panels">
<?php foreach ($panels as $panel_name => $panel): $show_panel = !empty($panel['active']) || empty($accordion);?>
                <div class="<?php echo DRTS_BS_PREFIX;?>accordion-item">
<?php   if (isset($panel['title']) && strlen($panel['title'])):?>
                    <div class="<?php echo DRTS_BS_PREFIX;?>accordion-header">
                        <button class="<?php echo DRTS_BS_PREFIX;?>accordion-button<?php if (!$show_panel):?> <?php echo DRTS_BS_PREFIX;?>collapsed<?php endif;?>" type="button" data-bs-toggle="collapse" data-bs-target="#<?php echo $dashboard_id;?>-panel-<?php echo $panel_name;?>" aria-expanded="<?php if (!$show_panel):?>false<?php else:?>true<?php endif;?>" aria-controls="<?php echo $dashboard_id;?>-panel-<?php echo $panel_name;?>"><?php echo $this->H($panel['title']);?></button>
                    </div>
<?php   endif;?>
                    <div id="<?php echo $dashboard_id;?>-panel-<?php echo $panel_name;?>" class="<?php echo DRTS_BS_PREFIX;?>accordion-collapse <?php echo DRTS_BS_PREFIX;?>collapse<?php if ($show_panel):?> <?php echo DRTS_BS_PREFIX;?>show<?php endif;?>" <?php if (!empty($accordion)):?>data-bs-parent="#<?php echo $dashboard_id;?>-panels"<?php endif;?>>
                        <div class="drts-dashboard-panel-links <?php echo DRTS_BS_PREFIX;?>list-group <?php echo DRTS_BS_PREFIX;?>list-group-flush">
<?php   foreach ($panel['links'] as $link_name => $link):?>
                            <button type="button" class="<?php echo DRTS_BS_PREFIX;?>d-flex <?php echo DRTS_BS_PREFIX;?>justify-content-between <?php echo DRTS_BS_PREFIX;?>align-items-center <?php echo $this->H($link['attr']['class']);?> <?php echo DRTS_BS_PREFIX;?>list-group-item <?php echo DRTS_BS_PREFIX;?>list-group-item-action"<?php echo $this->Attr($link['attr'], 'class');?>><?php echo $link['title'];?></button>
<?php   endforeach;?>
                        </div>
                    </div>
                </div>
<?php endforeach;?>
            </div>
<?php if (isset($logout_btn)):?>
            <div class="drts-dashboard-logout <?php echo DRTS_BS_PREFIX;?>mt-3 <?php echo DRTS_BS_PREFIX;?>d-grid"><?php echo $logout_btn;?></div>
<?php endif;?>
        </div>
    </div>

    <div id="<?php echo $dashboard_id;?>-main" class="drts-dashboard-main <?php echo DRTS_BS_PREFIX;?>col-md-9">
        <button class="<?php echo DRTS_BS_PREFIX;?>btn <?php echo DRTS_BS_PREFIX;?>btn-outline-secondary <?php echo DRTS_BS_PREFIX;?>d-md-none <?php echo DRTS_BS_PREFIX;?>mb-4" type="button" data-bs-toggle="offcanvas" data-bs-target="#<?php echo $dashboard_id;?>-offcanvas" aria-controls="<?php echo $dashboard_id;?>-offcanvas"><i class="fas fa-bars"></i> <?php echo $this->H($dashboard_menu_title);?></button>
        <h5 class="drts-dashboard-main-title <?php echo DRTS_BS_PREFIX;?>my-0 <?php echo DRTS_BS_PREFIX;?>mb-3 <?php echo DRTS_BS_PREFIX;?>p-0 <?php echo DRTS_BS_PREFIX;?>d-md-none"><?php echo $this->H($dashboard_main_title);?></h5>
        <div id="<?php echo $dashboard_id;?>-main-content">
            <?php $this->display($dashboard_templates, $CONTEXT->getAttributes());?>
        </div>
    </div>
</div>
<?php echo $this->Dashboard_Panels_js('#' . $dashboard_id . '-main-content', '#' . $dashboard_id . '-main', !$CONTEXT->isEmbed());?>
