<?php
if (!defined('ABSPATH')) exit;
$form = $this->Form_Form_render($form);
$html = $form->getHtml(true);
$hidden_html = $form->getHiddenHtml();
$js_html = $form->getJsHtml(false);
?>
<?php echo $form->getHeaderHtml();?>
<?php echo $form->getFormTag();?>
    <div class="drts-frontendsubmit-login-register-form-column" data-column-type="register">
        <div class="drts-frontendsubmit-register-form">
            <?php $this->Action('frontendsubmit_before_register_form');?>
            <?php echo $html['register'];?>
            <?php $this->Action('frontendsubmit_after_register_form');?>
        </div>
    </div>
    <?php echo $hidden_html;?>
</form>
<script type="text/javascript">
<?php echo $js_html;?>
</script>