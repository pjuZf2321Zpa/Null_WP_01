<?php
if (!defined('ABSPATH')) exit;
return $this->includeTemplate(
    'view_entities_container', 
    $CONTEXT->getAttributes() + ['skip_render_entities' => !empty($settings['skip_render_entities'])], 
    '.array'
) + $this->includeTemplate(
    'location_map', 
    $CONTEXT->getAttributes(), 
    '.array'
);