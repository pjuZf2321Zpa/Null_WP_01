<?php
if (!defined('ABSPATH')) exit;
return [
    'html' => [
        '.drts-view-filter-entities-form' => $this->View_FilterForm_render($filter['form']),
        '.drts-view-filter-entities-num-found' => $num_found,
        '.drts-view-entities-filters-applied' => empty($filter['filters_applied_labels']) ? '' : $this->View_Nav_getAppliedFilterButtons($filter['filters_applied_labels'], ['wrap' => false, 'label' => false, 'color' => $btn_color, 'is_subtle_bg' => true]),
        /* translators: %s: search query text labels */
        '.drts-view-entities-filters-search-labels' => isset($search_labels) ? sprintf($this->H(__('Search: %s', 'directories-pro')), $this->Search_Form_renderSearchLabels($search_labels)) : '',
    ],
];