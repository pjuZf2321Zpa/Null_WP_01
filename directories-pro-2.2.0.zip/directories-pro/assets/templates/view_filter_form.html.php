<?php if (!defined('ABSPATH')) exit; ?>
<?php echo $this->View_FilterForm_render($filter['form']);?>