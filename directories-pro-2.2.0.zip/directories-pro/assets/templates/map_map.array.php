<?php
if (!defined('ABSPATH')) exit;
return [
    'draw_options' => $draw_options ?? [],
    'markers' => $this->Map_Map_renderEntityMarkers(
        $entities,
        $field,
        $settings,
        $display ?? null,
        $CONTEXT->getAttributes(),
        $current_marker_ids ?? []
    ),
    'total' => $CONTEXT->num_total ?? count($entities),
];