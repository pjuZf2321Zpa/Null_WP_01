<?php
if (!defined('ABSPATH')) exit;
if ($this->Map_Map_isGdprConsentRequired()) {
    // Per-visitor state (has *this* visitor consented yet), so a shared cache entry
    // (e.g. AbstractPlatform::render()'s cache option, used when this View is embedded
    // via shortcode) must not be allowed to freeze in this consent-form state.
    $CONTEXT->setCacheable(false);
    echo $this->Map_Map_gdprConsentForm();
    return;
}
$this->Entity_Display_preRenderbyBundle($bundle->name, [], $settings['display']);
if (!\SabaiApps\Directories\Request::isXhr()) {
    // Markers are only ever loaded afterward via AJAX, so this is the only point in the
    // real page-load flow where popover/modal-display assets can be preloaded and
    // actually printed.
    $this->Map_Map_primeMarkerAssets($bundle, $settings['display'], $settings['map']);
}
// Sent back with the marker detail-modal fetch so the server can look up which display
// *that view* is configured to use, rather than trusting a display name from the request
// directly (see MapComponent::onViewEntityRequestedDisplayFilter()).
$settings['map']['view_name'] = $CONTEXT->view_name;
// Show map centered at searched location if any
if (isset($search_values['drts_search_location_address'])) {
    $search_value = $search_values['drts_search_location_address'];
    if (!empty($search_value['center'])
        && ($center = explode(',', $search_value['center']))
        && count($center) === 2
    ) {
        $settings['map']['default_location'] = ['lat' => $center[0], 'lng' => $center[1]];
    }
}
?>
<script type="text/javascript">
<?php if (\SabaiApps\Directories\Request::isXhr()):?>
jQuery(function($) {
<?php else:?>
document.addEventListener('DOMContentLoaded', function() {
    var $ = jQuery;
<?php endif;?>
    var settings = <?php echo $this->System_Util_jsonEncode($settings['map']);?>;
    var map = DRTS.Map.api.getMap('<?php echo $CONTEXT->getContainer();?>', settings);
    var params = <?php $url_params[\SabaiApps\Directories\Request::PARAM_CONTENT_TYPE] = 'json'; echo json_encode($url_params);?>;
    var fullmap = new DRTS.Map.fullmap(map, {
        url: '<?php echo $this->Url($CONTEXT->getRoute());?>',
        route: '<?php echo $this->H((string)$CONTEXT->getRoute());?>',
        params: params,
        debounceDelay: <?php echo intval($settings['map_debounce_delay']);?>,
        minZoomForUpdate: <?php echo intval($settings['map_min_zoom_for_update']);?>,
        fullscreenOffsetTop: <?php echo intval($settings['map_fullscreen_offset'] ?? 0);?>,
        labelFullscreen: '<?php echo $this->H(__('Full screen', 'directories-pro')); ?>',
        labelExitFullscreen: '<?php echo $this->H(__('Exit full screen', 'directories-pro')); ?>',
        labelZoomIn: '<?php echo $this->H(__('Zoom in to load more markers', 'directories-pro')); ?>',
        labelGeolocationNotSupported: '<?php echo $this->H(__('Geolocation is not supported by this browser.', 'directories-pro')); ?>',
        labelLoadMore: '<?php echo $this->H(__('Load more', 'directories-pro')); ?> - <?php echo $this->H(/* translators: 1: number of items shown, 2: total number of items */ __('%1$s of %2$s shown', 'directories-pro')); ?>',
    });
});
</script>
<div class="drts-map-container">
    <?php $this->Action('map_before_map', [$CONTEXT]);?>
    <div class="drts-map-map drts-map-map-with-height" style="height:<?php echo intval($settings['map_height']);?>px;" data-height="<?php echo intval($settings['map_height']);?>px"></div>
    <?php if ($settings['map_loading_indicator'] ?? true): ?>
    <span class="drts-map-loading-indicator<?php
        echo ($settings['map_loading_indicator_position'] ?? 'top-right') === 'top-left' ? ' drts-map-loading-indicator-top-left' : '';
        echo ($settings['map_loading_indicator_theme'] ?? 'light') === 'dark' ? ' drts-map-loading-indicator-dark' : '';
    ?>"></span>
    <?php endif; ?>
    <?php $this->Action('map_after_map', [$CONTEXT]);?>
</div>