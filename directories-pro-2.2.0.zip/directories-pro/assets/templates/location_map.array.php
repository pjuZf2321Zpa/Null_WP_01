<?php
if (!defined('ABSPATH')) exit;
return $this->includeTemplate(
    'map_map', 
    [
        'field' => $settings['map']['coordinates_field'] ?? 'location_address',
        'settings' => $settings['map'],
        'draw_options' => $this->Location_DrawMapOptions([], $CONTEXT),
        'display' => isset($settings['display']) && (string)$view === 'map' ? $settings['display'] : null,
    ] + $CONTEXT->getAttributes(), 
    '.array'
);