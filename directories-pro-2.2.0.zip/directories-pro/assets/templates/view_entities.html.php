<?php if (!defined('ABSPATH')) exit; ?>
<?php if (empty($entities) && !empty($hide_empty)) return;?>
<?php $this->Action('view_before_entities_container', array($entities, $CONTEXT));?>
<?php $this->display($container_template, $CONTEXT->getAttributes());?>
<?php $this->Action('view_after_entities_container', array($entities, $CONTEXT));?>