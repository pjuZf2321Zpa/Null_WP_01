<?php if (!defined('ABSPATH')) exit; ?>
<div class="<?php echo DRTS_BS_PREFIX;?>row drts-dashboard-account-settings">
<?php foreach ($sections as $section => $info): ?>    
  <div class="<?php echo DRTS_BS_PREFIX;?>col-sm-6 <?php echo DRTS_BS_PREFIX;?>mb-3 drts-dashboard-account-settings-section">
    <div class="<?php echo DRTS_BS_PREFIX;?>card">
      <div class="<?php echo DRTS_BS_PREFIX;?>card-body">
        <h5 class="<?php echo DRTS_BS_PREFIX;?>card-title"><?php echo $this->H($info['title']);?></h5>
        <div class="<?php echo DRTS_BS_PREFIX;?>card-text"><?php echo $info['html'];?></div>
<?php   if (!empty($info['url'])): ?>
        <?php echo $this->LinkTo($info['btn_label'] ?? $info['title'], $info['url'], ['btn' => true, 'container' =>  'modal', 'modalSize' => 'lg'], ['class' => DRTS_BS_PREFIX . 'btn ' . DRTS_BS_PREFIX . 'btn-' . ($info['btn_color'] ?? 'primary')]);?>
<?php   endif;?>
      </div>
    </div>
  </div>
<?php endforeach; ?>
</div>
