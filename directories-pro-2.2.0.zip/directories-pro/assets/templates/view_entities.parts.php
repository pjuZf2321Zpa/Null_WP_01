<?php if (!defined('ABSPATH')) exit; ?>
<?php 
if (empty($entities) && !empty($hide_empty)) return;
return $this->includeTemplate($container_template, $CONTEXT->getAttributes(), '.parts');?>