<?php if (!defined('ABSPATH')) exit; ?>
<?php $this->Action('view_before_entities', [$entities, $CONTEXT]);?>
<div class="drts-view-entities drts-view-<?php echo $bundle->entitytype_name;?>-entities drts-view-entities-<?php echo $view;?>">
    <?php $this->display($settings['template'], $CONTEXT->getAttributes());?>
</div>
<?php $this->Action('view_after_entities', [$entities, $CONTEXT]);?>