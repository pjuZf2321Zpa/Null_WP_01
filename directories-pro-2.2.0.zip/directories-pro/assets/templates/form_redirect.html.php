<?php if (!defined('ABSPATH')) exit; ?>
<?php $this->System_Util_redirectHtml($url, '<p>' . $this->H($message) . '</p>');?>
