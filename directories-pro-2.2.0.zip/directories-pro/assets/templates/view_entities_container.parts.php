<?php
if (!defined('ABSPATH')) exit;
return [
    'header' => $this->render('view_entities_container_header', $CONTEXT->getAttributes()),
    'entities' => $this->render('view_entities_container_entities', $CONTEXT->getAttributes()),
    'footer' => $this->render('view_entities_container_footer', $CONTEXT->getAttributes()),
];