<?php
if (!defined('ABSPATH')) exit;
if ($this->Map_Map_isGdprConsentRequired()) {
    echo $this->Map_Map_gdprConsentForm();
    return;
}

$markers = [];
if (!empty($entities)) {
    $markers = $this->Map_Map_renderEntityMarkers($entities, $field, $settings, $display ?? null, $CONTEXT->getAttributes());
}
$settings += $this->Map_Map_controlLabels();
?>
<script type="text/javascript">
<?php if (\SabaiApps\Directories\Request::isXhr()):?>
jQuery(function($) {
<?php else:?>
document.addEventListener('DOMContentLoaded', function() {
    var $ = jQuery;
<?php endif;?>
    var settings = <?php echo $this->System_Util_jsonEncode($settings);?>;
    var map = DRTS.Map.api.getMap('<?php echo $CONTEXT->getContainer();?>', settings)
        .initView()
        .setMarkers(<?php echo $this->System_Util_jsonEncode($markers);?>)
        .drawMarkers(<?php if (isset($draw_options)):?><?php echo $this->System_Util_jsonEncode($draw_options);?><?php endif;?>);
});
</script>
<div class="drts-map-container">
    <?php $this->Action('map_before_map', [$CONTEXT]);?>
    <div class="drts-map-map drts-map-map-with-height" style="height:<?php echo intval($settings['height']);?>px;"></div>
    <?php $this->Action('map_after_map', [$CONTEXT]);?>
</div>