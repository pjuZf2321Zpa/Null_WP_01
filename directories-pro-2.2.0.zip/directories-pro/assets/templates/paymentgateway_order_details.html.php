<?php if (!defined('ABSPATH')) exit; ?>
<p class="drts-paymentgateway-payment-detail-message <?php echo DRTS_BS_PREFIX;?>mb-3"><?php echo $this->PaymentGateway_Order_message($order);?></p>

<?php if (!empty($notices)):?>
<div class="drts-paymentgateway-payment-detail-notices <?php echo DRTS_BS_PREFIX;?>mb-3">
<?php   foreach ($notices as $notice_name => $notice):?>
    <div data-notice-name="<?php echo $this->H($notice_name);?>" class="<?php echo DRTS_BS_PREFIX;?>alert <?php echo DRTS_BS_PREFIX;?>alert-<?php echo $this->H($notice['level']);?>">
        <?php echo $this->Htmlize($notice['message'], true);?>
    </div>
<?php   endforeach;?>
</div>
<?php endif;?>

<?php if (!empty($actions)):?>
    <div class="drts-paymentgateway-payment-detail-actions <?php echo DRTS_BS_PREFIX;?>mb-3">
<?php   foreach ($actions as $action_name => $action):?>
        <?php echo $action;?>
<?php   endforeach;?>
    </div>
<?php endif;?>

<div class="drts-paymentgateway-payment-detail-summary <?php echo DRTS_BS_PREFIX;?>mb-3">
    <h3><?php echo __('Order summary', 'directories-pro');?></h3>
    <?php echo $this->PaymentGateway_Order_renderSummary($order);?>
</div>

<?php if ($notes = $order->getSingleFieldValue('paymentgateway_order', 'notes')):?>
<div class="drts-paymentgateway-payment-detail-notes <?php echo DRTS_BS_PREFIX;?>mb-3">
    <h3><?php echo __('Order notes', 'directories-pro');?></h3>
<?php   foreach (array_reverse($notes) as $note):?>
    <?php echo $this->PaymentGateway_Util_renderNote($note);?>
<?php   endforeach;?>
</div>
<?php endif;?>
