<?php
if (!defined('ABSPATH')) exit;
return $this->includeTemplate(
    'view_entities_container',
    $CONTEXT->getAttributes(),
    '.array'
) + $this->includeTemplate(
    'map_map',
    [
        'field' => $settings['map_coordinates_field'],
        'settings' => $settings['map'],
        'draw_options' => $this->Map_Map_getDrawOptions([], $CONTEXT),
        'display' => $settings['display'] ?? null,
        'current_marker_ids' => $settings['map_current_marker_ids'] ?? [],
    ] + $CONTEXT->getAttributes() ,
    '.array'
);