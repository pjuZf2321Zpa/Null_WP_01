<?php
if (!defined('ABSPATH')) exit;
$users = [];
if (!empty($identities)) {
    foreach ($identities as $identity) {
        $users[] = [
            'id' => $identity->id,
            'title' => $this->H($identity->name),
            'username' => $identity->username,
            'gravatar' => $this->System_Url_gravatar($identity->email, 24),
        ];
    }
}
return $users;