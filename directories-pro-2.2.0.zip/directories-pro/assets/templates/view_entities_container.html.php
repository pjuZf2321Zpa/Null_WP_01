<?php if (!defined('ABSPATH')) exit; ?>
<?php 
$this->display('view_entities_container_header', $CONTEXT->getAttributes());
$this->display('view_entities_container_entities', $CONTEXT->getAttributes());
$this->display('view_entities_container_footer', $CONTEXT->getAttributes());