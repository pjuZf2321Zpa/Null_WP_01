<?php if (!defined('ABSPATH')) exit; ?>
<?php 
$this->display('view_entities_container_header', $CONTEXT->getAttributes());
$this->display(__DIR__ . '/location_entities_map_container', $CONTEXT->getAttributes());
$this->display('view_entities_container_footer', $CONTEXT->getAttributes());