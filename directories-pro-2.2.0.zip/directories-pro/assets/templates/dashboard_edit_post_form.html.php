<?php if (!defined('ABSPATH')) exit; ?>
<?php if (!empty($displays)):?>
<div class="<?php echo DRTS_BS_PREFIX;?>nav <?php echo DRTS_BS_PREFIX;?>nav-tabs <?php echo DRTS_BS_PREFIX;?>mb-4">
<?php   foreach ($displays as $_display):?>
<?php     if (isset($_display['url'])):?>
    <a class="<?php echo DRTS_BS_PREFIX;?>nav-link" href="<?php echo $this->H($_display['url']);?>"><?php echo $this->H($_display['label']);?></a>
<?php     else:?>
    <span class="<?php echo DRTS_BS_PREFIX;?>nav-link <?php echo DRTS_BS_PREFIX;?>active"><?php echo $this->H($_display['label']);?></span>
<?php     endif;?>
<?php   endforeach;?>
</div>
<?php endif;?>
<?php $this->display('entity_form', $CONTEXT->getAttributes());?>