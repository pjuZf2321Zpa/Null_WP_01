<?php
if (!defined('ABSPATH')) exit;
return $this->includeTemplate(__DIR__ . '/location_map_container', $CONTEXT->getAttributes(), '.array');