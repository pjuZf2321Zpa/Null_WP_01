<?php if (!defined('ABSPATH')) exit; ?>
<div class="drts-view-entities-header <?php echo DRTS_BS_PREFIX;?>mb-<?php if (isset($nav[0]['margin'])):?><?php echo intval($nav[0]['margin']);?><?php else:?>4<?php endif;?>"><?php if (!empty($nav[0])):?><?php echo $this->View_Nav($CONTEXT, $nav[0]);?><?php endif;?></div>
<?php if (isset($filter['form']) && ($filter_form = $this->View_FilterForm_render($filter['form']))):?>
<?php   if (!empty($settings['filter']['show'])):?>
<div id="<?php echo $this->H(ltrim($settings['filter']['target'], '#'));?>-view-filter-form" class="drts-view-entities-filter-form<?php if (empty($settings['filter']['show_modal'])):?> <?php echo DRTS_BS_PREFIX;?>collapse<?php if (!empty($settings['filter']['shown'])):?> <?php echo DRTS_BS_PREFIX;?>show<?php endif;?><?php endif;?> <?php echo DRTS_BS_PREFIX;?>mb-<?php if (isset($nav[0]['margin'])):?><?php echo intval($nav[0]['margin']);?><?php else:?>4<?php endif;?>"<?php if (empty($settings['filter']['show_modal'])):?><?php if (empty($settings['filter']['shown'])):?> data-collapsible="1"<?php endif;?><?php endif;?><?php if (empty($settings['filter']['shown'])):?> style="display:none"<?php endif;?>>
    <?php echo $filter_form;?>
</div>
<?php   else:?>
<div class="drts-view-entities-filter-form-template" data-bundle-group="<?php echo $bundle->group;?>" data-bundle-type="<?php echo $bundle->type;?>" style="display:none">
    <div id="<?php echo $this->H(ltrim($settings['filter']['target'], '#'));?>-view-filter-form" class="drts-view-entities-filter-form"><?php echo $filter_form;?></div>
</div>
<?php   endif;?>
<?php endif;?>