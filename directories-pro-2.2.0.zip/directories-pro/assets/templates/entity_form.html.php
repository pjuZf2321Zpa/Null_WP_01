<?php if (!defined('ABSPATH')) exit; ?>
<?php 
echo $this->Entity_Form_render($form);