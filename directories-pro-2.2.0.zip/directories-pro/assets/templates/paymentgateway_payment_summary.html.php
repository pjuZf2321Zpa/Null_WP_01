<?php if (!defined('ABSPATH')) exit; ?>
<div class="drts-paymentgateway-payment-summary">
    <div class="drts-paymentgateway-payment-summary-item drts-paymentgateway-payment-summary-plan <?php echo DRTS_BS_PREFIX;?>d-flex <?php echo DRTS_BS_PREFIX;?>justify-content-between">
        <div class="drts-paymentgateway-payment-summary-item-label"><?php echo $this->H($title);?><?php if ($description):?><small><?php echo $this->System_Text_summarize($description, 300);?></small><?php endif;?></div>
        <div class="drts-paymentgateway-payment-summary-item-price"><?php echo $this->System_Currency_format($price, $currency);?></div>
    </div>
    <div class="drts-paymentgateway-payment-summary-item drts-paymentgateway-payment-summary-subtotal <?php echo DRTS_BS_PREFIX;?>d-flex <?php echo DRTS_BS_PREFIX;?>justify-content-between">
        <div class="drts-paymentgateway-payment-summary-item-label"><?php echo $this->H(__('Subtotal', 'directories-pro'));?></div>
        <div class="drts-paymentgateway-payment-summary-item-price"><?php echo $this->System_Currency_format($subtotal, $currency);?></div>
    </div>
<?php if (!empty($discounts)):?>
    <div class="drts-paymentgateway-payment-summary-item drts-paymentgateway-payment-summary-discount <?php echo DRTS_BS_PREFIX;?>d-flex <?php echo DRTS_BS_PREFIX;?>justify-content-between">
        <div class="drts-paymentgateway-payment-summary-item-label">
            <span><?php echo $this->H(__('Discount', 'directories-pro'));?></span>
<?php   foreach ($discounts as $discount): if (!is_array($discount)) continue; ?>
            <span class="<?php echo DRTS_BS_PREFIX;?>badge <?php echo DRTS_BS_PREFIX;?>text-bg-secondary <?php echo DRTS_BS_PREFIX;?>ms-1 <?php echo DRTS_BS_PREFIX;?>rounded-pill" title="<?php echo $this->H($discount['code']);?>"><i class="fas fa-tag"></i> <?php echo $this->H($discount['label']);?></span>
<?php   endforeach;?>
        </div>
        <div class="drts-paymentgateway-payment-summary-item-price">-<?php echo $this->System_Currency_format($discount_amount, $currency);?></div>
    </div>
<?php endif;?>
<?php if (!empty($fees)):?>
<?php   foreach ($fees as $fee):?>
    <div class="drts-paymentgateway-payment-summary-item drts-paymentgateway-payment-summary-fee <?php echo DRTS_BS_PREFIX;?>d-flex <?php echo DRTS_BS_PREFIX;?>justify-content-between">
        <div class="drts-paymentgateway-payment-summary-item-label"><?php echo $this->H($fee['label']);?></div>
        <div class="drts-paymentgateway-payment-summary-item-price"><?php echo $fee['price'];?></div>
    </div>
<?php   endforeach;?>
<?php endif;?>
<?php if (!empty($tax)):?>
    <div class="drts-paymentgateway-payment-summary-item drts-paymentgateway-payment-summary-tax <?php echo DRTS_BS_PREFIX;?>d-flex <?php echo DRTS_BS_PREFIX;?>justify-content-between">
        <div class="drts-paymentgateway-payment-summary-item-label"><?php echo $this->H(__('Tax', 'directories-pro'));?><?php if (isset($tax_rate)):?> <?php echo $this->H($tax_rate);?>%<?php endif;?></div>
        <div class="drts-paymentgateway-payment-summary-item-price"><?php if ($tax):?><?php echo $this->System_Currency_format($tax, $currency);?><?php else:?>--<?php endif;?></div>
    </div>
<?php endif;?>
    <div class="drts-paymentgateway-payment-summary-item drts-paymentgateway-payment-summary-total <?php echo DRTS_BS_PREFIX;?>d-flex <?php echo DRTS_BS_PREFIX;?>justify-content-between">
        <div class="drts-paymentgateway-payment-summary-item-label"><?php echo $this->H(__('Total', 'directories-pro'));?></div>
        <div class="drts-paymentgateway-payment-summary-item-price"><?php echo $this->System_Currency_format($total, $currency);?></div>
    </div>
</div>