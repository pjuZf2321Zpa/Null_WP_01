<?php
if (!defined('ABSPATH')) exit;
$ret = [];
if (isset($filter['form'])
    && ($filter_form = $this->View_FilterForm_render($filter['form']))
) {
    $ret['html']['.drts-view-entities-filter-form'] = $filter_form;
}

if (!empty($nav[0])) {
    $ret['html']['.drts-view-entities-header'] = $this->View_Nav($CONTEXT, $nav[0]);
}
if (!empty($nav[1])) {
    $ret['html']['.drts-view-entities-footer'] = $this->View_Nav($CONTEXT, $nav[1], true);
}
if (empty($settings['skip_render_entities'])) {
    $ret['html']['.drts-view-entities'] = $this->render($settings['template'], $CONTEXT->getAttributes());
}
return $ret;