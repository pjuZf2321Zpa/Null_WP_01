<?php
if (!defined('ABSPATH')) exit;
$events = [];
$all_occurrence_hashes = $occurrence_hashes_by_entity = [];
foreach ($entities as $entity) {
    if (!$occurrence_hashes = $entity->getExtraFieldValue('occurrence_hash')) continue;

    foreach ($occurrence_hashes as $occurrence_hash) {
        $occurrence_hashes_by_entity[$entity->getId()][$occurrence_hash] = true;
        $all_occurrence_hashes[$occurrence_hash] = true;
    }
}
if (!empty($all_occurrence_hashes)) {
    $occurrences = $this->getModel('Occurrence', 'Calendar')->hash_in(array_keys($all_occurrence_hashes))->fetch()->getArray(null, 'hash');
    foreach (array_keys($occurrence_hashes_by_entity) as $entity_id) {
        $entity = $entities[$entity_id];
        $is_current_entity = isset($GLOBALS['drts_entity']) && $GLOBALS['drts_entity']->getId() === $entity_id;
        $default_classes = [];
        $default_color = $default_text_color = null;
        if (!empty($settings['calendar_item_color'])) {
            $default_color = $entity->getSingleFieldValue($settings['calendar_item_color']);
            if ($default_color instanceof \SabaiApps\Directories\Component\Entity\Type\IEntity) {
                $default_color = $default_color->getCustomProperty('color');
            }
        }
        if (null === ($default_content = $this->Filter('calendar_occurrence_default_content', null, [$entity, $settings, &$default_classes, &$default_color, &$default_text_color]))
            || !is_string($default_content)
        ) {   
            if (!$is_current_entity
                && $settings['display']
            ) {
                ob_start();
                $this->Entity_Display($entity, $settings['display'], $CONTEXT->getAttributes());
                $default_content = ob_get_clean();
            } else {
                $default_content = '';
            }
        }
        foreach (array_keys($occurrence_hashes_by_entity[$entity_id]) as $occurrence_hash) {
            if (!isset($occurrences[$occurrence_hash])) continue;

            $occurrence = $occurrences[$occurrence_hash];
            $options = [
                'classes' => $default_classes,
                'view_classes' => [],
                'color' => $default_color,
                'text_color' => $default_text_color,
                'modal' => false,
                'modal_size' => 'lg',
                'modal_title' => null,
            ];
            $content = $this->Filter('calendar_occurrence_content', $default_content, [$occurrence, $entity, $settings, &$options]);
            if (false === $content) continue;
            
            $is_all_day = $occurrence->all_day === 1;
            if ($options['color'] === null
                && $options['text_color'] === null
                && !empty($settings['calendar_color'])
            ) {
                $options['color'] = 'var(--bs-' . $settings['calendar_color'] . ')';
                if ($is_all_day) {
                    $options['view_classes']['multiMonthYear'][] = $options['view_classes']['dayGridMonth'][] 
                        = DRTS_BS_PREFIX . 'text-bg-' . $settings['calendar_color'];
                }
            }
            $events[] = [
                'title' => isset($settings['calendar_item_title_format']) 
                    ? strtr($settings['calendar_item_title_format'], [
                        '%content_item_title%' => $entity->getTitle(), 
                        '%calendar_slot_title%' => strlen($occurrence->title) ? $occurrence->title : '',
                        '%field_label' => ($slot_field = $this->Entity_Field($bundle, $occurrence->slot_field_name)) ? $slot_field->getFieldLabel() : '',
                    ])
                    : (strlen($occurrence->title) ? $occurrence->title : $entity->getTitle()),
                'start' => gmdate('Y-m-d\TH:i:s\Z', $occurrence->start_date),
                'end' => strlen($occurrence->end_date) ? gmdate('Y-m-d\TH:i:s\Z', $occurrence->end_date) : null,
                'raw' => [
                    'content' => $content === '' ? ($is_current_entity ? null : $this->Entity_PermalinkUrl($entity)) : $content,
                    'classes' => $options['classes'],
                    'viewClasses' => $options['view_classes'],
                    'modal' => $options['modal'],
                    'modalSize' => $options['modal_size'],
                    'modalTitle' => $options['modal_title'],
                    'date' => $this->System_Date($occurrence->start_date),
                ],
                'borderColor' => $options['color'],
                'backgroundColor' => $options['color'],
                'textColor' => $options['text_color'],
                'allDay' => $is_all_day,
            ];
        }
    }
}
return $events;