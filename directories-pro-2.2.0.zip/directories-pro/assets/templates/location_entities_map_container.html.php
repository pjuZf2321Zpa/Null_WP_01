<?php
if (!defined('ABSPATH')) exit;
$container_classes = [
    'drts-location-entities-with-map-' . $settings['map']['position'],
    DRTS_BS_PREFIX . 'row',
    DRTS_BS_PREFIX . 'g-0',
];
$map_container_classes = $entities_container_classes = [
    DRTS_BS_PREFIX . 'col',
];
$map_container_classes[] = DRTS_BS_PREFIX . 'mb-3';
$map_container_classes[] = DRTS_BS_PREFIX . 'position-relative';
if ($settings['map']['position'] === 'bottom') {
    $container_classes[] = DRTS_BS_PREFIX . 'flex-column';
} else {
    $span = $settings['map']['span'] ?? 4;
    if (!$span = intval($span)) $span = 4;
    $container_classes[] = DRTS_BS_PREFIX . 'flex-column-reverse';
    if ($settings['map']['position'] !== 'top') {
        $entities_container_classes[] = DRTS_BS_PREFIX . 'col-sm-' . (12 - $span);
        $map_container_classes[] = DRTS_BS_PREFIX . 'col-sm-' . (int)$span;
        $margin = isset($settings['map']['margin']) ? (int)$settings['map']['margin'] : 3;
        if ($settings['map']['position'] === 'left') {
            $container_classes[] = DRTS_BS_PREFIX . 'flex-sm-row-reverse';
            $entities_container_classes[] = DRTS_BS_PREFIX . 'ps-sm-' . $margin;
        } elseif ($settings['map']['position'] === 'right') {
            $container_classes[] = DRTS_BS_PREFIX . 'flex-sm-row';
            $entities_container_classes[] = DRTS_BS_PREFIX . 'pe-sm-' . $margin;
        }
    }
}
if (!empty($settings['map']['hide_xs'])) {
    $map_container_classes[] = DRTS_BS_PREFIX . 'd-none';
    $map_container_classes[] = DRTS_BS_PREFIX . 'd-sm-block';
}
?>
<div class="drts-location-entities-map-container drts-location-entities-with-map <?php echo $this->H(implode(' ', $container_classes));?>" data-map-span="<?php echo intval($settings['map']['span'] ?? 4);?>" data-fullscreen-map-span="<?php echo intval($settings['map']['fullscreen_span'] ?? 5);?>" data-map-position="<?php echo $settings['map']['position'];?>"<?php if (!empty($settings['map']['sticky_offset'])):?> data-map-sticky-scroll-top="<?php echo intval($settings['map']['sticky_offset']);?>"<?php endif;?><?php if (!empty($settings['map']['scroll_offset'])):?> data-map-scroll-offset="<?php echo intval($settings['map']['scroll_offset']);?>"<?php endif;?>>
    <div class="drts-location-entities <?php echo $this->H(implode(' ', $entities_container_classes));?>">
        <?php $this->display('view_entities_container_entities', $CONTEXT->getAttributes());?>
    </div>
    <?php $this->display(__DIR__ . '/location_map', $CONTEXT->getAttributes() + ['classes' => $map_container_classes, 'skip_view_entities_none' => true]);?>
</div>
