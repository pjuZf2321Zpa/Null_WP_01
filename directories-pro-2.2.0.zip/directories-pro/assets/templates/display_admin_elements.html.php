<?php if (!defined('ABSPATH')) exit; ?>
<div class="drts-display-element-search <?php echo DRTS_BS_PREFIX;?>float-sm-end" style="width:200px; max-width:200px;">
    <input type="text" class="<?php echo DRTS_BS_PREFIX;?>form-control" placeholder="<?php echo $this->H(__('Search elements...', 'directories-pro'));?>" />
</div>
<div class="drts-display-elements">
    <div class="<?php echo DRTS_BS_PREFIX;?>nav <?php echo DRTS_BS_PREFIX;?>nav-pills drts-display-tabs <?php echo DRTS_BS_PREFIX;?>mb-3">
        <a href="#" data-bs-target="#drts-display-element-type-all" class="drts-content-tab <?php echo DRTS_BS_PREFIX;?>nav-item <?php echo DRTS_BS_PREFIX;?>nav-link<?php if (!isset($default_type)):?> <?php echo DRTS_BS_PREFIX;?>active<?php endif;?>" data-bs-toggle="tab"><?php echo $this->H(_x('All', 'all elements tab', 'directories-pro'));?></a>
<?php foreach (array_keys($element_types) as $type):?>
        <a href="#" data-bs-target="#drts-display-element-type-<?php echo $this->H($type);?>" class="drts-content-tab <?php echo DRTS_BS_PREFIX;?>nav-item <?php echo DRTS_BS_PREFIX;?>nav-link<?php if ($default_type === $type):?> <?php echo DRTS_BS_PREFIX;?>active<?php endif;?>" data-bs-toggle="tab"><?php echo $this->H($element_types[$type]);?></a>
<?php endforeach;?>
    </div>
    <div class="<?php echo DRTS_BS_PREFIX;?>tab-content">
        <div class="<?php echo DRTS_BS_PREFIX;?>tab-pane <?php echo DRTS_BS_PREFIX;?>fade<?php if (!isset($default_type)):?> <?php echo DRTS_BS_PREFIX;?>active <?php echo DRTS_BS_PREFIX;?>show<?php endif;?>" id="drts-display-element-type-all">
            <div class="drts-row">
<?php foreach (array_keys($element_types) as $type):?>
<?php   if (!empty($elements[$type])):?>
<?php     foreach ($elements[$type] as $element_name => $element):?>
                <div class="drts-col-12 drts-col-sm-6 drts-col-md-4 drts-col-lg-3 drts-col-xl-3">
                    <a href="#" class="drts-display-element <?php echo DRTS_BS_PREFIX;?>btn <?php echo DRTS_BS_PREFIX;?>btn-light" data-element-name="<?php echo $this->H($element_name);?>" data-element-type="<?php echo $this->H($element['type']);?>" data-element-type-label="<?php echo $this->H($element_types[$element['type']]);?>" data-element-label="<?php echo $this->H($element['label']);?>">
                        <span class="drts-display-element-label <?php echo DRTS_BS_PREFIX;?>mb-1"><?php if (isset($element['icon'])):?><i class="fa-fw <?php echo $this->H($element['icon']);?>"></i><?php endif;?><?php echo $this->H($element['label']);?></span>
                        <span class="drts-display-element-description"><?php echo $this->H($element['description']);?></span>
                    </a>
                </div>
<?php     endforeach;?>
<?php   endif;?>
<?php endforeach;?>  
            </div>
        </div>
<?php foreach (array_keys($element_types) as $type):?>
        <div class="<?php echo DRTS_BS_PREFIX;?>tab-pane <?php echo DRTS_BS_PREFIX;?>fade<?php if ($default_type === $type):?> <?php echo DRTS_BS_PREFIX;?>active <?php echo DRTS_BS_PREFIX;?>show<?php endif;?>" id="drts-display-element-type-<?php echo $this->H($type);?>">
            <div class="drts-row">
<?php   if (!empty($elements[$type])):?>
<?php     foreach ($elements[$type] as $element_name => $element):?>
                <div class="drts-col-12 drts-col-sm-6 drts-col-md-4 drts-col-lg-3 drts-col-xl-3">
                    <a href="#" class="drts-display-element <?php echo DRTS_BS_PREFIX;?>btn <?php echo DRTS_BS_PREFIX;?>btn-light" data-element-name="<?php echo $this->H($element_name);?>" data-element-type="<?php echo $this->H($element['type']);?>" data-element-type-label="<?php echo $this->H($element_types[$element['type']]);?>" data-element-label="<?php echo $this->H($element['label']);?>">
                        <span class="drts-display-element-label <?php echo DRTS_BS_PREFIX;?>mb-1"><?php if (isset($element['icon'])):?><i class="fa-fw <?php echo $this->H($element['icon']);?>"></i><?php endif;?><?php echo $this->H($element['label']);?></span>
                        <span class="drts-display-element-description"><?php echo $this->H($element['description']);?></span>
                    </a>
                </div>
<?php     endforeach;?>
<?php   endif;?>
            </div>
        </div>
<?php endforeach;?>
    </div>
    <div class="drts-display-elements-buttons">
        <a href="#" class="<?php echo DRTS_BS_PREFIX;?>btn <?php echo DRTS_BS_PREFIX;?>btn-link drts-form-cancel"><?php echo $this->H(__('cancel', 'directories-pro'));?></a>
    </div>
</div>
