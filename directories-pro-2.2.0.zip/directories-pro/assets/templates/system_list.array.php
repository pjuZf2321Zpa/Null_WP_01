<?php if (!defined('ABSPATH')) exit; ?>
<?php return (array)$list;?>