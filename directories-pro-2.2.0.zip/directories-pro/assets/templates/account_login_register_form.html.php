<?php
if (!defined('ABSPATH')) exit;
$form = $this->Form_Form_render($form);
$html = $form->getHtml(true);
$is_two_columns = isset($html['register']) || isset($html['guest']);
$hidden_html = $form->getHiddenHtml();
$js_html = $form->getJsHtml(false);
?>
<?php echo $form->getHeaderHtml();?>
<?php echo $form->getFormTag();?>
    <div class="drts-frontendsubmit-login-register-form-column" data-column-type="login">
        <div class="drts-frontendsubmit-login-form">
<?php if ($is_two_columns):?>
            <h2><?php echo $this->H($label_login);?></h2>
<?php endif;?>
            <?php $this->Action('frontendsubmit_before_login_form');?>
            <?php echo $html['login'];?>
            <?php $this->Action('frontendsubmit_after_login_form');?>
        </div>
    </div>
<?php if ($is_two_columns):?>
    <div class="drts-frontendsubmit-login-register-form-separator">
        <div class="drts-frontendsubmit-login-register-form-separator-line"></div>
        <div class="drts-frontendsubmit-login-register-form-separator-word">
            <span><?php echo $this->H(__('or', 'directories-pro'));?></span>
        </div>
    </div>
    <div class="drts-frontendsubmit-login-register-form-column" data-column-type="register">
<?php   if (isset($html['register'])):?>
        <div class="drts-frontendsubmit-register-form">
            <h2><?php echo $this->H($label_register);?></h2>
            <?php $this->Action('frontendsubmit_before_register_form');?>
            <?php echo $html['register'];?>
            <?php $this->Action('frontendsubmit_after_register_form');?>
        </div>
<?php   endif;?>
<?php   if (isset($html['guest'])):?>
        <div class="drts-frontendsubmit-guest-form">
            <h2><?php echo $this->H($label_guest);?></h2>
            <?php $this->Action('frontendsubmit_before_guest_login_form');?>
            <?php echo $html['guest'];?>
            <?php $this->Action('frontendsubmit_after_guest_login_form');?>
        </div>
<?php   endif;?>
    </div>
<?php endif;?>
<?php echo $hidden_html;?>
</form>
<script type="text/javascript">
<?php echo $js_html;?>
</script>