<?php if (!defined('ABSPATH')) exit; ?>
<?php 
return [
    'header' => $this->render('view_entities_container_header', $CONTEXT->getAttributes()),
    'entities' => $this->render(__DIR__ . '/location_entities_map_container', $CONTEXT->getAttributes()),
    'footer' => $this->render('view_entities_container_footer', $CONTEXT->getAttributes()),
];