<?php

// AI Engine managing itself over MCP: chatbots, discussions, insights, knowledge, settings and
// modules. Chatbot, settings and module writes are journaled per chatbot and per option key
// (the 'mwai_chatbot' and 'mwai_settings' undo kinds below), never as the whole option: the
// usage stats rewrite mwai_options after every AI query, so an undo of the whole row would be
// refused as "changed since" almost at once, and it would also roll back other chatbots.
class MeowPro_MWAI_MCP_AIEngine {
  private const CATEGORY = 'AI Engine';
  private const CHATBOTS_OPTION = 'mwai_chatbots';
  private const SETTINGS_OPTION = 'mwai_options';
  // Same list as proOptions in app/js/screens/Settings.js: the modules that need a registered licence.
  private const PRO_MODULES = [ 'module_forms', 'module_statistics', 'module_embeddings', 'module_assistants',
    'module_orchestration', 'module_cross_site', 'module_models_api' ];
  // Never written through mwai_update_settings: environments (they hold API keys), lists with their
  // own screens, values AI Engine computes, and the public API switch. Every mcp_* key is refused
  // too, so an assistant can never loosen its own guard rails (approvals, role, drafts only).
  private const LOCKED_SETTINGS = [ 'ai_envs', 'ai_engines', 'embeddings_envs', 'mcp_envs', 'ai_models', 'chatbots',
    'themes', 'ai_usage', 'ai_usage_daily', 'ai_models_usage', 'ai_models_usage_daily', 'chatbot_defaults',
    'default_limits', 'languages', 'pro_modules_paused', 'public_api' ];
  // Large or computed, so left out of mwai_get_settings unless asked for by name.
  private const BULKY_SETTINGS = [ 'ai_engines', 'ai_models', 'ai_usage', 'ai_usage_daily', 'ai_models_usage', 'ai_models_usage_daily',
    'chatbot_defaults', 'default_limits', 'languages' ];
  // Shortcodes and embeds point at botId, so it never changes once created.
  private const CHATBOT_LOCKED = [ 'botId', 'id', 'customId', 'previousResponseId', 'parentBotId' ];
  private const TEXT_LIMIT = 2000;

  private $core = null;

  #region Initialize
  public function __construct( $core ) {
    $this->core = $core;
    add_action( 'rest_api_init', [ $this, 'rest_api_init' ] );
    add_filter( 'mwai_mcp_undo_targets', [ $this, 'undo_targets' ], 10, 3 );
    add_filter( 'mwai_mcp_undo_kinds', [ $this, 'undo_kinds' ] );
  }

  public function rest_api_init() {
    add_filter( 'mwai_mcp_tools', [ $this, 'register_rest_tools' ] );
    add_filter( 'mwai_mcp_callback', [ $this, 'handle_call' ], 10, 4 );
  }
  #endregion

  #region Tools
  private function tool( string $name, string $description, array $properties, array $required, string $hint ): array {
    return [
      'name' => $name,
      'description' => $description,
      'inputSchema' => [
        'type' => 'object',
        'properties' => $properties ? $properties : (object) [],
        'required' => $required,
      ],
      'category' => self::CATEGORY,
      'annotations' => [
        'readOnlyHint' => $hint === 'read',
        'destructiveHint' => $hint === 'delete',
        'openWorldHint' => false,
      ],
      'accessLevel' => 'admin',
    ];
  }

  private function tools(): array {
    $botId = [ 'type' => 'string', 'description' => 'The chatbot ID (botId), as listed by mwai_list_chatbots.' ];
    $fields = [ 'type' => 'object', 'description' => 'Chatbot parameters to set, as { key: value } (for example { "model": "gpt-5.1", "temperature": 0.7, "instructions": "..." }). Keys must be existing chatbot parameters (see mwai_get_chatbot) and keep their type. botId and secrets (apiKey) cannot be set here.' ];
    $envId = [ 'type' => 'string', 'description' => 'The Knowledge environment ID (see mwai_list_knowledge_envs). Defaults to the default environment.' ];
    $limit = function ( int $default, int $max ) {
      return [ 'type' => 'integer', 'description' => "How many to return (default {$default}, max {$max})." ];
    };
    $offset = [ 'type' => 'integer', 'description' => 'How many to skip, for paging (default 0).' ];
    $list = [
      $this->tool( 'mwai_list_chatbots', 'List the AI Engine chatbots: botId, name, model, AI environment, theme, mode, Knowledge environment, tools, a short excerpt of the instructions, and the shortcode.', [], [], 'read' ),
      $this->tool( 'mwai_get_chatbot', 'Get every parameter of one AI Engine chatbot (secrets such as apiKey are masked).', [ 'botId' => $botId ], [ 'botId' ], 'read' ),
      $this->tool( 'mwai_create_chatbot', 'Create an AI Engine chatbot, starting from the defaults or from a copy of an existing chatbot (from_botId), then applying fields. The name must be unique; the botId is derived from it unless given. Can be undone with mcp_undo_change.', [
        'name' => [ 'type' => 'string', 'description' => 'The chatbot name (unique).' ],
        'botId' => [ 'type' => 'string', 'description' => 'Optional botId (letters, digits, - and _). Used in the shortcode, cannot be changed later.' ],
        'from_botId' => [ 'type' => 'string', 'description' => 'Optional: copy the parameters of this chatbot.' ],
        'fields' => $fields,
      ], [ 'name' ], 'write' ),
      $this->tool( 'mwai_update_chatbot', 'Change some parameters of one AI Engine chatbot. Only the given fields change, everything else (and every other chatbot) is kept. Can be undone with mcp_undo_change.', [
        'botId' => $botId,
        'fields' => $fields,
      ], [ 'botId', 'fields' ], 'write' ),
      $this->tool( 'mwai_delete_chatbot', 'Delete an AI Engine chatbot (never the default one). Its discussions are kept. Pages that embed its shortcode will stop showing it. Can be undone with mcp_undo_change.', [ 'botId' => $botId ], [ 'botId' ], 'delete' ),

      $this->tool( 'mwai_ask_chatbot', 'Send a message to a chatbot as a visitor would, and get its reply: the way to try a change (instructions, model, knowledge) before visitors see it. It runs a real AI query, so it costs like any chat. It is not saved as a discussion.', [
        'botId' => $botId,
        'message' => [ 'type' => 'string', 'description' => 'The visitor message.' ],
      ], [ 'botId', 'message' ], 'read' ),

      $this->tool( 'mwai_list_discussions', 'List the chatbot discussions stored by AI Engine (needs Discussions on), newest activity first: id, chatId, botId, title, message count, user, created and updated dates.', [
        'botId' => [ 'type' => 'string', 'description' => 'Only the discussions of this chatbot.' ],
        'search' => [ 'type' => 'string', 'description' => 'Only the discussions whose messages or title contain this text.' ],
        'user' => [ 'type' => 'string', 'description' => 'Only the discussions of this WordPress user ID, or of this IP address.' ],
        'since' => [ 'type' => 'string', 'description' => 'Only the discussions updated since this date (YYYY-MM-DD or any date PHP understands).' ],
        'limit' => $limit( 20, 100 ),
        'offset' => $offset,
      ], [], 'read' ),
      $this->tool( 'mwai_get_discussion', 'Read one chatbot discussion: its messages as role and content (long messages are trimmed).', [
        'chatId' => [ 'type' => 'string', 'description' => 'The chatId, as listed by mwai_list_discussions.' ],
        'botId' => $botId,
        'max_messages' => [ 'type' => 'integer', 'description' => 'Return only the last N messages (default 50, max 200).' ],
      ], [ 'chatId', 'botId' ], 'read' ),

      $this->tool( 'mwai_get_usage', 'AI Engine usage over the last days: queries and tokens per day and per model (kept for 30 days), monthly totals, and, when Insights is on, the queries, tokens and estimated cost per day, model and scope from the Insights logs.', [
        'days' => [ 'type' => 'integer', 'description' => 'How many days back, today included (default 7, max 30).' ],
        'months' => [ 'type' => 'integer', 'description' => 'How many months of monthly totals (default 3, max 24).' ],
      ], [], 'read' ),
      $this->tool( 'mwai_list_query_logs', 'The latest AI queries recorded by Insights (needs the Insights module): time, model, feature, scope, environment, tokens and estimated price. MCP tool calls are left out unless include_mcp is true.', [
        'model' => [ 'type' => 'string', 'description' => 'Only this model.' ],
        'feature' => [ 'type' => 'string', 'description' => 'Only this feature (for example chatbot, form, mcp_tool).' ],
        'scope' => [ 'type' => 'string', 'description' => 'Only this scope.' ],
        'envId' => [ 'type' => 'string', 'description' => 'Only this AI environment.' ],
        'include_mcp' => [ 'type' => 'boolean', 'description' => 'Include MCP tool calls (default false).' ],
        'limit' => $limit( 20, 100 ),
        'offset' => $offset,
      ], [], 'read' ),

      $this->tool( 'mwai_list_knowledge_envs', 'List the Knowledge (embeddings) environments: id, name, vector database type, whether it is the default, and how many entries it holds. Needs the Knowledge module.', [], [], 'read' ),
      $this->tool( 'mwai_list_knowledge', 'List the Knowledge entries of an environment, newest first: id, title, type, status, envId, the post it comes from, and the start of the content. Needs the Knowledge module.', [
        'envId' => $envId,
        'status' => [ 'type' => 'string', 'description' => 'Only this status (ok, error, outdated, processing, pending).' ],
        'type' => [ 'type' => 'string', 'description' => 'Only this type (manual, postId, upload, remoteUrl, mediaId).' ],
        'title' => [ 'type' => 'string', 'description' => 'Only the entries whose title contains this text.' ],
        'contains' => [ 'type' => 'string', 'description' => 'Only the entries whose content contains this exact text (a URL, a name...).' ],
        'unlinked' => [ 'type' => 'boolean', 'description' => 'Only the entries made from a post or media that lost their link to it (stale copies the sync never updates).' ],
        'limit' => $limit( 20, 100 ),
        'offset' => $offset,
      ], [], 'read' ),
      $this->tool( 'mwai_get_knowledge', 'Get one Knowledge entry in full: its whole content, the post or URL it comes from, its status and dates.', [
        'id' => [ 'type' => 'integer', 'description' => 'The entry ID, as listed by mwai_list_knowledge.' ],
      ], [ 'id' ], 'read' ),
      $this->tool( 'mwai_search_knowledge', 'Semantic search in a Knowledge environment, exactly as the chatbots search it (an embeddings query, so it costs a little). Returns the matching entries with their score, above the environment\'s minimum score.', [
        'query' => [ 'type' => 'string', 'description' => 'What to search for, in natural language.' ],
        'envId' => $envId,
        'limit' => $limit( 10, 50 ),
      ], [ 'query' ], 'read' ),
      $this->tool( 'mwai_add_knowledge', 'Add a Knowledge entry: AI Engine creates its embedding and pushes it to the environment\'s vector database. Cannot be undone with mcp_undo_change; delete it with mwai_delete_knowledge instead.', [
        'title' => [ 'type' => 'string', 'description' => 'A short title.' ],
        'content' => [ 'type' => 'string', 'description' => 'The text the chatbots will find (max 65535 characters).' ],
        'envId' => $envId,
      ], [ 'title', 'content' ], 'write' ),
      $this->tool( 'mwai_update_knowledge', 'Change the title or the content of a Knowledge entry. A new content is embedded again and replaces the old vector. Cannot be undone with mcp_undo_change, so the result returns the previous title and text.', [
        'id' => [ 'type' => 'integer', 'description' => 'The entry ID, as listed by mwai_list_knowledge.' ],
        'title' => [ 'type' => 'string', 'description' => 'The new title.' ],
        'content' => [ 'type' => 'string', 'description' => 'The new content.' ],
      ], [ 'id' ], 'write' ),
      $this->tool( 'mwai_delete_knowledge', 'Delete Knowledge entries, from AI Engine and from the vector database. Cannot be undone, so the result returns each deleted entry in full (previous), to add it back if needed.', [
        'ids' => [ 'type' => 'array', 'items' => [ 'type' => 'integer' ], 'description' => 'The entry IDs (max 50).' ],
      ], [ 'ids' ], 'delete' ),

      $this->tool( 'mwai_get_settings', 'Read the AI Engine settings. API keys, tokens and other secrets are masked. Without keys, large computed values (usage, models, languages) are left out and listed in "omitted".', [
        'keys' => [ 'type' => 'array', 'items' => [ 'type' => 'string' ], 'description' => 'Only these settings.' ],
        'search' => [ 'type' => 'string', 'description' => 'Only the settings whose name contains this text.' ],
      ], [], 'read' ),
      $this->tool( 'mwai_update_settings', 'Change some AI Engine settings, as { key: value }. Only existing settings, with the same type; an object is merged one level deep into the current one, a list is replaced. Refused: secrets, environments, MCP settings (mcp_*), modules (use mwai_set_module) and masked values. Can be undone with mcp_undo_change.', [
        'changes' => [ 'type' => 'object', 'description' => 'The settings to change, as { key: value } (max 20).' ],
      ], [ 'changes' ], 'write' ),
      $this->tool( 'mwai_list_modules', 'List the AI Engine modules (module_* settings): on or off, and whether they need Pro.', [], [], 'read' ),
      $this->tool( 'mwai_set_module', 'Turn one AI Engine module on or off. It takes effect from the next request. Pro modules need a registered licence. MCP itself cannot be switched here. Can be undone with mcp_undo_change.', [
        'module' => [ 'type' => 'string', 'description' => 'The module setting, for example module_embeddings (see mwai_list_modules).' ],
        'enabled' => [ 'type' => 'boolean', 'description' => 'true to turn it on, false to turn it off.' ],
      ], [ 'module', 'enabled' ], 'write' ),
    ];
    $tools = [];
    foreach ( $list as $tool ) {
      $tools[ $tool['name'] ] = $tool;
    }
    return $tools;
  }
  #endregion

  #region Register
  public function register_rest_tools( array $prev ): array {
    return array_merge( $prev, array_values( $this->tools() ) );
  }
  #endregion

  #region Callback
  public function handle_call( $prev, string $tool, array $args, int|string|null $id ) {
    if ( !empty( $prev ) || !isset( $this->tools()[ $tool ] ) ) {
      return $prev;
    }
    // These tools act on the whole site, so they refuse rather than run as another user.
    if ( !current_user_can( 'manage_options' ) ) {
      throw new Exception( 'This tool needs an account that can manage the site.', Meow_MWAI_Labs_MCP::DENIED_CODE );
    }
    return $this->dispatch( $tool, $args );
  }
  #endregion

  #region Dispatcher
  private function dispatch( string $tool, array $a ) {
    switch ( $tool ) {
      case 'mwai_list_chatbots':
        $bots = $this->fresh_chatbots();
        $summaries = array_map( [ $this, 'chatbot_summary' ], $bots );
        // A chatbot pointed at an empty Knowledge environment answers without any context, silently.
        if ( $this->core->get_option( 'module_embeddings' ) && !empty( $GLOBALS['mwai_embeddings'] ) ) {
          $counts = [];
          foreach ( $summaries as &$summary ) {
            $env = $summary['embeddingsEnvId'];
            if ( $env ) {
              $counts[ $env ] ??= (int) ( $this->embeddings()->query_vectors( 0, 1, [ 'envId' => $env ] )['total'] ?? 0 );
              if ( $counts[ $env ] === 0 ) {
                $summary['warning'] = "Its Knowledge environment {$env} has no entries, so it answers without any site context.";
              }
            }
          }
          unset( $summary );
        }
        return [ 'count' => count( $bots ), 'chatbots' => $summaries ];
      case 'mwai_get_chatbot':
        return $this->get_chatbot( $this->str( $a, 'botId' ) );
      case 'mwai_create_chatbot':
        return $this->create_chatbot( $a );
      case 'mwai_update_chatbot':
        return $this->update_chatbot( $a );
      case 'mwai_delete_chatbot':
        return $this->delete_chatbot( $this->str( $a, 'botId' ) );
      case 'mwai_ask_chatbot':
        return $this->ask_chatbot( $a );
      case 'mwai_list_discussions':
        return $this->list_discussions( $a );
      case 'mwai_get_discussion':
        return $this->get_discussion( $a );
      case 'mwai_get_usage':
        return $this->get_usage( $a );
      case 'mwai_list_query_logs':
        return $this->list_query_logs( $a );
      case 'mwai_list_knowledge_envs':
        return $this->list_knowledge_envs();
      case 'mwai_list_knowledge':
        return $this->list_knowledge( $a );
      case 'mwai_get_knowledge':
        return $this->get_knowledge( $a );
      case 'mwai_search_knowledge':
        return $this->search_knowledge( $a );
      case 'mwai_add_knowledge':
        return $this->add_knowledge( $a );
      case 'mwai_update_knowledge':
        return $this->update_knowledge( $a );
      case 'mwai_delete_knowledge':
        return $this->delete_knowledge( $a );
      case 'mwai_get_settings':
        return $this->get_settings( $a );
      case 'mwai_update_settings':
        return $this->update_settings( $a );
      case 'mwai_list_modules':
        return $this->list_modules();
      case 'mwai_set_module':
        return $this->set_module( $a );
      default:
        throw new Exception( 'Unknown tool' );
    }
  }
  #endregion

  #region Helpers
  private function str( array $a, string $key, bool $required = true ): string {
    $value = is_scalar( $a[ $key ] ?? null ) ? trim( (string) $a[ $key ] ) : '';
    if ( $required && $value === '' ) {
      throw new Exception( "{$key} is required." );
    }
    return $value;
  }

  private function int( array $a, string $key, int $default, int $min, int $max ): int {
    $value = isset( $a[ $key ] ) && is_numeric( $a[ $key ] ) ? (int) $a[ $key ] : $default;
    return max( $min, min( $max, $value ) );
  }

  // Objects and lists may arrive as JSON strings, depending on the client.
  private function json_arg( $value ): array {
    if ( is_string( $value ) ) {
      $decoded = json_decode( $value, true );
      return is_array( $decoded ) ? $decoded : [];
    }
    return is_array( $value ) ? $value : [];
  }

  private function excerpt( $text, int $length ): string {
    $text = is_scalar( $text ) ? (string) $text : wp_json_encode( $text );
    return mb_strlen( $text ) > $length ? mb_substr( $text, 0, $length ) . '…' : $text;
  }

  private function is_registered(): bool {
    return (bool) apply_filters( MWAI_PREFIX . '_meowapps_is_registered', false, MWAI_PREFIX );
  }

  // Values must keep the type of the current one: a "false" string in a boolean setting reads as true.
  private function type_error( string $key, $value, $current ): ?string {
    if ( $current === null ) {
      return is_object( $value ) ? "{$key} must be a plain value or an array." : null;
    }
    if ( is_bool( $current ) ) {
      return is_bool( $value ) ? null : "{$key} must be true or false.";
    }
    if ( is_int( $current ) || is_float( $current ) ) {
      return is_numeric( $value ) && !is_bool( $value ) ? null : "{$key} must be a number.";
    }
    if ( is_array( $current ) ) {
      return is_array( $value ) ? null : "{$key} must be an array or an object.";
    }
    return is_string( $value ) || ( is_numeric( $value ) && !is_bool( $value ) ) ? null : "{$key} must be a string.";
  }
  #endregion

  #region Chatbots
  // The chatbots as stored, read from the database (not the request cache) right before a write:
  // update_chatbots() replaces the whole list, so a stale copy would undo other changes.
  private function stored_chatbots(): array {
    $this->core->forget_cached_options( self::CHATBOTS_OPTION );
    $list = get_option( self::CHATBOTS_OPTION, [] );
    if ( empty( $list ) ) {
      // Never saved yet: get_chatbots() creates and saves the default chatbot.
      $this->core->get_chatbots();
      $this->core->forget_cached_options( self::CHATBOTS_OPTION );
      $list = get_option( self::CHATBOTS_OPTION, [] );
    }
    if ( !is_array( $list ) || empty( $list ) ) {
      throw new Exception( 'The chatbots could not be read, so nothing was changed.' );
    }
    return $list;
  }

  private function stored_chatbot( string $botId ): ?array {
    foreach ( $this->stored_chatbots() as $bot ) {
      if ( is_array( $bot ) && (string) ( $bot['botId'] ?? '' ) === $botId ) {
        return $bot;
      }
    }
    return null;
  }

  // Writes one chatbot (null removes it) into a fresh read of the list; the others are written
  // back exactly as stored.
  private function write_chatbot( string $botId, ?array $bot ): void {
    $list = $this->stored_chatbots();
    $found = false;
    $out = [];
    foreach ( $list as $item ) {
      if ( is_array( $item ) && (string) ( $item['botId'] ?? '' ) === $botId ) {
        $found = true;
        if ( $bot !== null ) {
          $out[] = $bot;
        }
        continue;
      }
      $out[] = $item;
    }
    if ( !$found ) {
      if ( $bot === null ) {
        return;
      }
      $out[] = $bot;
    }
    if ( empty( $out ) ) {
      throw new Exception( 'This would leave no chatbot, so nothing was changed.' );
    }
    $this->core->update_chatbots( $out );
  }

  private function fresh_chatbots(): array {
    $this->core->forget_cached_options( self::CHATBOTS_OPTION );
    return $this->core->get_chatbots();
  }

  private function chatbot_summary( array $bot ): array {
    return [
      'botId' => $bot['botId'] ?? null,
      'name' => $bot['name'] ?? null,
      'mode' => $bot['mode'] ?? null,
      'model' => $bot['model'] ?? null,
      'envId' => !empty( $bot['envId'] ) ? $bot['envId'] : null,
      'themeId' => $bot['themeId'] ?? null,
      'popup' => !empty( $bot['window'] ),
      'embeddingsEnvId' => !empty( $bot['embeddingsEnvId'] ) ? $bot['embeddingsEnvId'] : null,
      'contentAware' => !empty( $bot['contentAware'] ),
      'tools' => array_values( (array) ( $bot['tools'] ?? [] ) ),
      'functions' => count( (array) ( $bot['functions'] ?? [] ) ),
      'mcpServers' => count( (array) ( $bot['mcpServers'] ?? [] ) ),
      'instructions' => $this->excerpt( $bot['instructions'] ?? '', 200 ),
      'shortcode' => '[mwai_chatbot id="' . ( $bot['botId'] ?? '' ) . '"]',
    ];
  }

  private function get_chatbot( string $botId ): array {
    $this->core->forget_cached_options( self::CHATBOTS_OPTION );
    $bot = $this->core->get_chatbot( $botId );
    if ( !$bot ) {
      throw new Exception( "No chatbot with the botId \"{$botId}\". Use mwai_list_chatbots." );
    }
    // Very old chatbots still carry snake_case copies (max_tokens, start_sentence...) that nothing
    // reads anymore; showing both with different values only confuses.
    $camel = array_change_key_case( array_flip( array_keys( $bot ) ) );
    foreach ( array_keys( $bot ) as $key ) {
      if ( strpos( $key, '_' ) !== false && isset( $camel[ strtolower( str_replace( '_', '', $key ) ) ] ) ) {
        unset( $bot[ $key ] );
      }
    }
    // Instructions are stored HTML-escaped (wp_kses_post) and decoded before reaching the model;
    // show what the model reads, so an assistant doesn't see or copy "&amp;".
    if ( isset( $bot['instructions'] ) && is_string( $bot['instructions'] ) ) {
      $bot['instructions'] = html_entity_decode( $bot['instructions'] );
    }
    // Numbers are stored as strings by the admin; give them back as numbers when the parameter is one.
    $defaults = $this->core->get_chatbot_default_params();
    foreach ( $bot as $key => $value ) {
      if ( is_string( $value ) && is_numeric( $value ) && ( is_int( $defaults[ $key ] ?? null ) || is_float( $defaults[ $key ] ?? null ) ) ) {
        $bot[ $key ] = $value + 0;
      }
    }
    return [
      'chatbot' => Meow_MWAI_Labs_MCP_Core::mask_secrets( $bot ),
      'shortcode' => '[mwai_chatbot id="' . $botId . '"]',
    ];
  }

  // From AI Engine's price table. Providers log dated snapshots (gpt-5.4-2026-03-05,
  // claude-opus-4-8-20260101) that the table only knows under their base name.
  private function estimate_price( string $model, ?string $envId, $in, $out, $cached = 0 ): ?float {
    $data = $model !== '' ? $this->core->find_model_data( $model, $envId ) : null;
    if ( empty( $data['price'] ) ) {
      $base = preg_replace( '/-(\d{4}-\d{2}-\d{2}|\d{8})$/', '', $model );
      $data = $base !== $model ? $this->core->find_model_data( $base, $envId ) : null;
    }
    if ( ( $data['type'] ?? '' ) !== 'token' || !isset( $data['price'] ) ) {
      return null;
    }
    $unit = $data['unit'] ?? 1 / 1000000;
    // Embedding models have one price for every token.
    if ( is_numeric( $data['price'] ) ) {
      return ( (float) $in + (float) $out ) * $data['price'] * $unit;
    }
    if ( !is_array( $data['price'] ) ) {
      return null;
    }
    $cached = min( (float) $cached, (float) $in );
    $cachedPrice = $data['price']['cached'] ?? ( $data['price']['in'] ?? 0 );
    return ( (float) $in - $cached ) * ( $data['price']['in'] ?? 0 ) * $unit + $cached * $cachedPrice * $unit
      + (float) $out * ( $data['price']['out'] ?? 0 ) * $unit;
  }

  private function ask_chatbot( array $a ): array {
    global $mwai;
    $botId = $this->str( $a, 'botId' );
    $message = $this->str( $a, 'message' );
    if ( !$this->core->get_chatbot( $botId ) ) {
      throw new Exception( "No chatbot with the botId \"{$botId}\". Use mwai_list_chatbots." );
    }
    $start = microtime( true );
    $data = $mwai->simpleChatbotQuery( $botId, $message, [], false );
    $usage = is_array( $data ) ? ( $data['usage'] ?? null ) : null;
    if ( is_array( $usage ) && empty( $usage['price'] ) ) {
      $bot = $this->core->get_chatbot( $botId );
      $estimate = $this->estimate_price( $bot['model'] ?? '', $bot['envId'] ?? null, $usage['prompt_tokens'] ?? 0, $usage['completion_tokens'] ?? 0, $usage['cached_tokens'] ?? 0 );
      if ( $estimate !== null ) {
        $usage['estimated_price'] = round( $estimate, 6 );
      }
    }
    return [
      'botId' => $botId,
      'reply' => is_array( $data ) ? ( $data['reply'] ?? '' ) : (string) $data,
      'seconds' => round( microtime( true ) - $start, 1 ),
      'usage' => $usage,
    ];
  }

  private function allowed_chatbot_keys(): array {
    $keys = array_keys( $this->core->get_chatbot_default_params() );
    foreach ( [ 'MWAI_CHATBOT_FRONT_PARAMS', 'MWAI_CHATBOT_SERVER_PARAMS' ] as $constant ) {
      if ( defined( $constant ) ) {
        $keys = array_merge( $keys, constant( $constant ) );
      }
    }
    foreach ( $this->stored_chatbots() as $bot ) {
      $keys = array_merge( $keys, array_keys( (array) $bot ) );
    }
    $keys[] = 'name';
    return array_values( array_diff( array_unique( $keys ), self::CHATBOT_LOCKED ) );
  }

  private function validate_chatbot_fields( array $fields, array $reference ): array {
    $allowed = $this->allowed_chatbot_keys();
    $errors = [];
    foreach ( $fields as $key => $value ) {
      $key = (string) $key;
      if ( in_array( $key, self::CHATBOT_LOCKED, true ) ) {
        $errors[] = "{$key} cannot be changed (shortcodes and embeds use it).";
      }
      elseif ( preg_match( Meow_MWAI_Labs_MCP_Core::SECRET_NAME, $key ) ) {
        $errors[] = "{$key} is a secret: set it in AI Engine → Chatbots.";
      }
      elseif ( !in_array( $key, $allowed, true ) ) {
        $errors[] = "{$key} is not a chatbot parameter (see mwai_get_chatbot).";
      }
      elseif ( Meow_MWAI_Labs_MCP_Core::contains_mask( $value ) ) {
        $errors[] = "{$key} holds a masked value (" . Meow_MWAI_Labs_MCP_Core::SECRET_MASK . '), which would overwrite the real one.';
      }
      elseif ( $error = $this->type_error( $key, $value, $reference[ $key ] ?? null ) ) {
        $errors[] = $error;
      }
    }
    if ( $errors ) {
      throw new Exception( 'Nothing was changed. ' . implode( ' ', $errors ) );
    }
    return $fields;
  }

  private function assert_unique_name( string $name, ?string $exceptBotId = null ): void {
    if ( $name === '' ) {
      throw new Exception( 'The name cannot be empty.' );
    }
    foreach ( $this->stored_chatbots() as $bot ) {
      if ( ( $bot['botId'] ?? null ) !== $exceptBotId && mb_strtolower( trim( (string) ( $bot['name'] ?? '' ) ) ) === mb_strtolower( $name ) ) {
        throw new Exception( "A chatbot is already named \"{$name}\" (botId: {$bot['botId']})." );
      }
    }
  }

  // Also called by undo_targets() before the call runs, so it must give the same ID both times.
  private function new_bot_id( array $a ): string {
    $taken = array_map( function ( $bot ) {
      return (string) ( $bot['botId'] ?? '' );
    }, $this->stored_chatbots() );
    $given = $this->str( $a, 'botId', false );
    if ( $given !== '' ) {
      if ( !preg_match( '/^[a-zA-Z0-9][a-zA-Z0-9_-]{0,63}$/', $given ) ) {
        throw new Exception( 'The botId may only use letters, digits, - and _ (64 characters at most).' );
      }
      if ( in_array( $given, $taken, true ) ) {
        throw new Exception( "The botId \"{$given}\" is already used." );
      }
      return $given;
    }
    $base = substr( sanitize_title( $this->str( $a, 'name' ) ), 0, 50 );
    $base = $base !== '' ? $base : 'chatbot';
    $candidate = $base;
    for ( $i = 2; in_array( $candidate, $taken, true ); $i++ ) {
      $candidate = $base . '-' . $i;
    }
    return $candidate;
  }

  private function create_chatbot( array $a ): array {
    $name = $this->str( $a, 'name' );
    $this->assert_unique_name( $name );
    $base = $this->core->get_chatbot_default_params();
    $from = $this->str( $a, 'from_botId', false );
    if ( $from !== '' ) {
      $source = $this->stored_chatbot( $from );
      if ( !$source ) {
        throw new Exception( "No chatbot with the botId \"{$from}\" to copy." );
      }
      $base = array_merge( $base, $source );
    }
    $fields = $this->validate_chatbot_fields( $this->json_arg( $a['fields'] ?? null ), $base );
    unset( $fields['name'] );
    $botId = $this->new_bot_id( $a );
    $this->write_chatbot( $botId, array_merge( $base, $fields, [ 'botId' => $botId, 'name' => $name ] ) );
    $this->core->forget_cached_options( self::CHATBOTS_OPTION );
    $bot = $this->core->get_chatbot( $botId );
    return [ 'created' => $this->chatbot_summary( $bot ?? [ 'botId' => $botId, 'name' => $name ] ) ];
  }

  private function update_chatbot( array $a ): array {
    $botId = $this->str( $a, 'botId' );
    $fields = $this->json_arg( $a['fields'] ?? null );
    if ( empty( $fields ) ) {
      throw new Exception( 'fields is required: the parameters to change, as { key: value }.' );
    }
    $current = $this->stored_chatbot( $botId );
    if ( !$current ) {
      throw new Exception( "No chatbot with the botId \"{$botId}\". Use mwai_list_chatbots." );
    }
    $fields = $this->validate_chatbot_fields( $fields, array_merge( $this->core->get_chatbot_default_params(), $current ) );
    if ( array_key_exists( 'name', $fields ) ) {
      $fields['name'] = trim( (string) $fields['name'] );
      $this->assert_unique_name( $fields['name'], $botId );
    }
    $this->write_chatbot( $botId, array_merge( $current, $fields ) );
    $this->core->forget_cached_options( self::CHATBOTS_OPTION );
    $bot = $this->core->get_chatbot( $botId );
    return [ 'updated' => array_keys( $fields ), 'chatbot' => $this->chatbot_summary( $bot ?? $current ) ];
  }

  private function delete_chatbot( string $botId ): array {
    if ( $botId === 'default' ) {
      throw new Exception( 'The default chatbot cannot be deleted. Change its parameters instead.' );
    }
    $current = $this->stored_chatbot( $botId );
    if ( !$current ) {
      throw new Exception( "No chatbot with the botId \"{$botId}\". Use mwai_list_chatbots." );
    }
    $this->write_chatbot( $botId, null );
    return [ 'deleted' => [ 'botId' => $botId, 'name' => $current['name'] ?? null ], 'note' => 'Its discussions are kept. Pages embedding its shortcode no longer show it.' ];
  }
  #endregion

  #region Discussions
  private function discussions() {
    if ( !$this->core->get_option( 'chatbot_discussions' ) || empty( $this->core->discussions ) ) {
      throw new Exception( 'Discussions are off, so none are stored. They can be turned on in AI Engine → Settings → Chatbot → Discussions (setting chatbot_discussions).' );
    }
    return $this->core->discussions;
  }

  private function list_discussions( array $a ): array {
    $discussions = $this->discussions();
    $limit = $this->int( $a, 'limit', 20, 1, 100 );
    $offset = $this->int( $a, 'offset', 0, 0, PHP_INT_MAX );
    $filters = [];
    if ( ( $botId = $this->str( $a, 'botId', false ) ) !== '' ) {
      $filters[] = [ 'accessor' => 'botId', 'value' => $botId ];
    }
    if ( ( $search = $this->str( $a, 'search', false ) ) !== '' ) {
      $filters[] = [ 'accessor' => 'preview', 'value' => $search ];
    }
    if ( ( $user = $this->str( $a, 'user', false ) ) !== '' ) {
      $filters[] = [ 'accessor' => 'user', 'value' => $user ];
    }
    $since = null;
    if ( ( $sinceArg = $this->str( $a, 'since', false ) ) !== '' ) {
      $time = strtotime( $sinceArg );
      if ( $time === false ) {
        throw new Exception( "since: \"{$sinceArg}\" is not a date." );
      }
      $since = date( 'Y-m-d H:i:s', $time );
    }
    $chats = $discussions->chats_query( [], $offset, $limit, $filters, [ 'accessor' => 'updated', 'by' => 'DESC' ] );
    $rows = [];
    $older = false;
    // Sorted by updated, newest first: the rows older than "since" are all at the end.
    foreach ( $chats['rows'] ?? [] as $row ) {
      if ( $since && $row['updated'] < $since ) {
        $older = true;
        break;
      }
      $messages = json_decode( (string) $row['messages'], true );
      $messages = is_array( $messages ) ? $messages : [];
      $first = '';
      foreach ( $messages as $message ) {
        if ( ( $message['role'] ?? '' ) === 'user' ) {
          $first = $this->excerpt( $message['content'] ?? '', 150 );
          break;
        }
      }
      $rows[] = [
        'id' => (int) $row['id'],
        'chatId' => $row['chatId'],
        'botId' => $row['botId'],
        'title' => $row['title'],
        'messages' => count( $messages ),
        // The greeting counts as a message, so exchanges says how many times the visitor wrote.
        'exchanges' => count( array_filter( $messages, fn ( $m ) => ( $m['role'] ?? '' ) === 'user' ) ),
        'firstUserMessage' => $first,
        'userId' => $row['userId'] ? (int) $row['userId'] : null,
        'created' => $row['created'],
        'updated' => $row['updated'],
      ];
    }
    $result = [ 'discussions' => $rows ];
    if ( $since ) {
      $result['more'] = !$older && count( $chats['rows'] ?? [] ) === $limit;
    }
    else {
      $result['total'] = (int) ( $chats['total'] ?? 0 );
    }
    return $result;
  }

  private function get_discussion( array $a ): array {
    $discussions = $this->discussions();
    $chatId = $this->str( $a, 'chatId' );
    $botId = $this->str( $a, 'botId' );
    $chat = $discussions->get_discussion( $botId, $chatId );
    if ( !$chat ) {
      throw new Exception( "No discussion with the chatId \"{$chatId}\" for the chatbot \"{$botId}\"." );
    }
    $max = $this->int( $a, 'max_messages', 50, 1, 200 );
    $messages = json_decode( wp_json_encode( $chat['messages'] ?? [] ), true );
    $messages = is_array( $messages ) ? $messages : [];
    $total = count( $messages );
    $out = [];
    foreach ( array_slice( $messages, -$max ) as $message ) {
      $out[] = [
        'role' => $message['role'] ?? null,
        'content' => $this->excerpt( $message['content'] ?? '', self::TEXT_LIMIT ),
      ];
    }
    return [
      'id' => (int) $chat['id'],
      'chatId' => $chat['chatId'],
      'botId' => $chat['botId'],
      'title' => $chat['title'],
      'userId' => $chat['userId'] ? (int) $chat['userId'] : null,
      'created' => $chat['created'],
      'updated' => $chat['updated'],
      'messageCount' => $total,
      'shown' => count( $out ),
      'messages' => $out,
    ];
  }
  #endregion

  #region Insights
  private function stats() {
    global $mwai_stats;
    if ( !$this->core->get_option( 'module_statistics' ) || empty( $mwai_stats ) ) {
      return null;
    }
    return $mwai_stats;
  }

  private function get_usage( array $a ): array {
    $days = $this->int( $a, 'days', 7, 1, 30 );
    $months = $this->int( $a, 'months', 3, 1, 24 );
    $options = $this->core->get_all_options( true );
    $sinceDay = date( 'Y-m-d', strtotime( '-' . ( $days - 1 ) . ' days' ) );
    $fields = [ 'queries', 'prompt_tokens', 'completion_tokens', 'total_tokens', 'returned_price', 'images', 'seconds' ];
    $pick = function ( $usage ) use ( $fields ) {
      $out = [];
      foreach ( $fields as $field ) {
        if ( isset( $usage[ $field ] ) && is_numeric( $usage[ $field ] ) ) {
          $out[ $field ] = $usage[ $field ] + 0;
        }
      }
      return $out;
    };
    $daily = [];
    $byModel = [];
    foreach ( (array) ( $options['ai_usage_daily'] ?? [] ) as $day => $models ) {
      if ( $day < $sinceDay ) {
        continue;
      }
      foreach ( (array) $models as $model => $usage ) {
        $entry = $pick( $usage );
        $daily[ $day ][ $model ] = $entry;
        foreach ( $entry as $field => $value ) {
          $byModel[ $model ][ $field ] = ( $byModel[ $model ][ $field ] ?? 0 ) + $value;
        }
      }
    }
    ksort( $daily );
    // Providers rarely report a price, so estimate it from AI Engine's own price table.
    foreach ( $byModel as $model => &$entry ) {
      $estimate = $this->estimate_price( $model, null, $entry['prompt_tokens'] ?? 0, $entry['completion_tokens'] ?? 0 );
      if ( $estimate !== null ) {
        $entry['estimated_price'] = round( $estimate, 4 );
      }
    }
    unset( $entry );
    $sinceMonth = date( 'Y-m', strtotime( date( 'Y-m-01' ) . ' -' . ( $months - 1 ) . ' months' ) );
    $monthly = [];
    foreach ( (array) ( $options['ai_usage'] ?? [] ) as $month => $models ) {
      if ( $month < $sinceMonth ) {
        continue;
      }
      foreach ( (array) $models as $model => $usage ) {
        $monthly[ $month ][ $model ] = $pick( $usage );
      }
    }
    ksort( $monthly );
    $result = [
      'days' => $days,
      'since' => $sinceDay,
      'daily' => $daily,
      'byModel' => $byModel,
      'monthly' => $monthly,
      'note' => 'returned_price is only filled by providers that report a price. estimated_price (per model, in USD) comes from AI Engine\'s price table and prices every input token at the full rate (the daily totals do not keep cached tokens), so it runs high for chatbots that reuse a long prompt. It is given per model only, not per day. The Insights figures carry AI Engine\'s own per-query estimate.',
    ];
    $stats = $this->stats();
    $result['insights'] = $stats
      ? $this->aggregate_logs( $stats, $sinceDay . ' 00:00:00' )
      : 'The Insights module (module_statistics) is off, so queries and costs are not logged one by one. Turn it on with mwai_set_module to get them from now on.';
    return $result;
  }

  // Through the same list Insights uses, newest first, until the rows are older than the range.
  private function aggregate_logs( $stats, string $since ): array {
    $pageSize = 500;
    $maxPages = 10;
    $daily = [];
    $byModel = [];
    $byScope = [];
    $rows = 0;
    $complete = false;
    $add = function ( &$bucket, array $row ) {
      $bucket['queries'] = ( $bucket['queries'] ?? 0 ) + 1;
      $bucket['tokens'] = ( $bucket['tokens'] ?? 0 ) + (int) $row['units'];
      $bucket['price'] = round( ( $bucket['price'] ?? 0 ) + (float) $row['price'], 6 );
    };
    for ( $page = 0; $page < $maxPages && !$complete; $page++ ) {
      $logs = $stats->stats_logs_list(
        [],
        $page * $pageSize,
        $pageSize,
        [ [ 'accessor' => 'feature_not', 'value' => 'mcp_tool' ] ],
        [ 'accessor' => 'time', 'by' => 'DESC' ]
      );
      $list = $logs['rows'] ?? [];
      foreach ( $list as $row ) {
        if ( $row['time'] < $since ) {
          $complete = true;
          break;
        }
        $rows++;
        $day = substr( $row['time'], 0, 10 );
        $model = $row['model'] ?: 'unknown';
        $scope = $row['scope'] ?: 'unknown';
        $add( $daily[ $day ][ $model ], $row );
        $add( $byModel[ $model ], $row );
        $add( $byScope[ $scope ], $row );
      }
      if ( count( $list ) < $pageSize ) {
        $complete = true;
      }
    }
    ksort( $daily );
    $result = [ 'queries' => $rows, 'daily' => $daily, 'byModel' => $byModel, 'byScope' => $byScope ];
    if ( !$complete ) {
      $result['partial'] = 'Only the latest ' . ( $pageSize * $maxPages ) . ' queries were counted; use fewer days for exact totals.';
    }
    return $result;
  }

  private function list_query_logs( array $a ): array {
    $stats = $this->stats();
    if ( !$stats ) {
      throw new Exception( 'The Insights module (module_statistics) is off, so queries are not logged. Turn it on with mwai_set_module to log them from now on.' );
    }
    $filters = [];
    foreach ( [ 'model', 'feature', 'scope', 'envId' ] as $key ) {
      if ( ( $value = $this->str( $a, $key, false ) ) !== '' ) {
        $filters[] = [ 'accessor' => $key, 'value' => $value ];
      }
    }
    if ( empty( $a['include_mcp'] ) && $this->str( $a, 'feature', false ) === '' ) {
      $filters[] = [ 'accessor' => 'feature_not', 'value' => 'mcp_tool' ];
    }
    $limit = $this->int( $a, 'limit', 20, 1, 100 );
    $offset = $this->int( $a, 'offset', 0, 0, PHP_INT_MAX );
    $logs = $stats->stats_logs_list( [], $offset, $limit, $filters, [ 'accessor' => 'time', 'by' => 'DESC' ] );
    $rows = [];
    foreach ( $logs['rows'] ?? [] as $row ) {
      $split = json_decode( (string) ( $row['stats'] ?? '' ), true );
      $rows[] = [
        'id' => (int) $row['id'],
        'time' => $row['time'],
        'model' => $row['model'],
        'feature' => $row['feature'],
        'scope' => $row['scope'],
        'envId' => $row['envId'],
        'type' => $row['type'],
        'tokens' => (int) $row['units'],
        'inTokens' => is_array( $split ) && isset( $split['in_tokens'] ) ? (int) $split['in_tokens'] : null,
        'outTokens' => is_array( $split ) && isset( $split['out_tokens'] ) ? (int) $split['out_tokens'] : null,
        'price' => $row['price'] !== null ? (float) $row['price'] : null,
        'accuracy' => $row['accuracy'] ?? null,
        'userId' => $row['userId'] ? (int) $row['userId'] : null,
        'ip' => $row['ip'],
      ];
    }
    return [ 'total' => (int) ( $logs['total'] ?? 0 ), 'logs' => $rows ];
  }
  #endregion

  #region Knowledge
  private function embeddings() {
    global $mwai_embeddings;
    if ( !$this->core->get_option( 'module_embeddings' ) || empty( $mwai_embeddings ) ) {
      throw new Exception( 'The Knowledge module (module_embeddings) is off. Turn it on with mwai_set_module; it takes effect from the next request.' );
    }
    return $mwai_embeddings;
  }

  private function env_id( array $a ): string {
    $envId = $this->str( $a, 'envId', false );
    // With several environments, the "default" one is often not the one the chatbots use (on
    // meowapps.com it was an empty Pinecone while the bot read Chroma): writing there silently
    // is worse than asking.
    $envs = (array) $this->core->get_option( 'embeddings_envs', [] );
    if ( $envId === '' && count( $envs ) > 1 ) {
      throw new Exception( 'envId is required: this site has ' . count( $envs ) . ' Knowledge environments ('
        . implode( ', ', array_map( fn ( $e ) => ( $e['id'] ?? '?' ) . ' "' . ( $e['name'] ?? '' ) . '"', $envs ) )
        . '). Check mwai_list_knowledge_envs and the chatbots\' embeddingsEnvId to pick the right one.' );
    }
    $envId = $envId !== '' ? $envId : (string) $this->core->get_option( 'embeddings_default_env' );
    if ( $envId === '' ) {
      throw new Exception( 'envId is required: no default Knowledge environment is set (see mwai_list_knowledge_envs).' );
    }
    if ( !$this->core->get_embeddings_env( $envId ) ) {
      throw new Exception( "No Knowledge environment with the ID \"{$envId}\" (see mwai_list_knowledge_envs)." );
    }
    return $envId;
  }

  private function vector_summary( array $vector, int $length = 300 ): array {
    return [
      'id' => (int) $vector['id'],
      'title' => $vector['title'],
      'type' => $vector['type'],
      'status' => $vector['status'],
      'envId' => $vector['envId'],
      'refId' => $vector['refId'] ? (int) $vector['refId'] : null,
      'source' => $vector['source'] ?? null,
      'error' => $vector['error'] ?? null,
      'created' => $vector['created'],
      'updated' => $vector['updated'],
      'text' => $this->excerpt( $vector['content'] ?? '', $length ),
    ];
  }

  private function list_knowledge_envs(): array {
    $embeddings = $this->embeddings();
    $default = (string) $this->core->get_option( 'embeddings_default_env' );
    $envs = [];
    foreach ( (array) $this->core->get_option( 'embeddings_envs', [] ) as $env ) {
      $id = (string) ( $env['id'] ?? '' );
      if ( $id === '' ) {
        continue;
      }
      $count = $embeddings->query_vectors( 0, 1, [ 'envId' => $id ] );
      $envs[] = [
        'id' => $id,
        'name' => $env['name'] ?? $id,
        'type' => $env['type'] ?? null,
        'isDefault' => $id === $default,
        'entries' => (int) ( $count['total'] ?? 0 ),
      ];
    }
    return [ 'environments' => $envs ];
  }

  private function list_knowledge( array $a ): array {
    $embeddings = $this->embeddings();
    $filters = [ 'envId' => $this->env_id( $a ) ];
    foreach ( [ 'status', 'type', 'title' ] as $key ) {
      if ( ( $value = $this->str( $a, $key, false ) ) !== '' ) {
        $filters[ $key ] = $value;
      }
    }
    if ( ( $contains = $this->str( $a, 'contains', false ) ) !== '' ) {
      $filters['content'] = $contains;
    }
    if ( !empty( $a['unlinked'] ) ) {
      $filters['unlinked'] = true;
    }
    $limit = $this->int( $a, 'limit', 20, 1, 100 );
    $offset = $this->int( $a, 'offset', 0, 0, PHP_INT_MAX );
    $vectors = $embeddings->query_vectors( $offset, $limit, $filters, [ 'accessor' => 'created', 'by' => 'DESC' ] );
    return [
      'envId' => $filters['envId'],
      'total' => (int) ( $vectors['total'] ?? 0 ),
      'entries' => array_map( [ $this, 'vector_summary' ], $vectors['rows'] ?? [] ),
    ];
  }

  private function get_knowledge( array $a ): array {
    $embeddings = $this->embeddings();
    $id = (int) $this->str( $a, 'id' );
    $vector = $id > 0 ? $embeddings->get_vector( $id ) : null;
    if ( empty( $vector ) ) {
      throw new Exception( "No Knowledge entry #{$id}. Use mwai_list_knowledge." );
    }
    return array_merge( $this->vector_summary( $vector ), [
      'text' => (string) ( $vector['content'] ?? '' ),
      'refUrl' => $vector['refUrl'] ?? null,
      'remoteId' => $vector['dbId'] ?? null,
    ] );
  }

  private function search_knowledge( array $a ): array {
    $embeddings = $this->embeddings();
    $query = $this->str( $a, 'query' );
    $envId = $this->env_id( $a );
    $limit = $this->int( $a, 'limit', 10, 1, 50 );
    $vectors = $embeddings->query_vectors( 0, $limit, [ 'envId' => $envId, 'search' => $query ] );
    $rows = $vectors['rows'] ?? [];
    usort( $rows, function ( $x, $y ) {
      return ( $y['score'] ?? 0 ) <=> ( $x['score'] ?? 0 );
    } );
    $results = [];
    foreach ( array_slice( $rows, 0, $limit ) as $row ) {
      $results[] = [ 'score' => isset( $row['score'] ) ? round( (float) $row['score'], 4 ) : null ] + $this->vector_summary( $row, 600 );
    }
    return [ 'envId' => $envId, 'query' => $query, 'results' => $results ];
  }

  // vectors_add() and update_vector() keep a failed embedding as a row in error: say so loudly.
  private function vector_result( $vector, string $verb ): array {
    if ( !is_array( $vector ) ) {
      throw new Exception( "The entry could not be {$verb}." );
    }
    if ( ( $vector['status'] ?? '' ) === 'error' ) {
      throw new Exception( "Entry #{$vector['id']} was {$verb} in AI Engine, but its embedding failed: " . ( $vector['error'] ?? 'unknown error' )
        . ' Fix the environment, then call mwai_update_knowledge, or remove it with mwai_delete_knowledge.' );
    }
    return [ $verb => $this->vector_summary( $vector ) ];
  }

  private function add_knowledge( array $a ): array {
    $embeddings = $this->embeddings();
    $title = sanitize_text_field( $this->str( $a, 'title' ) );
    $content = is_string( $a['content'] ?? null ) ? trim( $a['content'] ) : '';
    if ( $content === '' ) {
      throw new Exception( 'content is required.' );
    }
    $vector = $embeddings->vectors_add( [
      'type' => 'manual',
      'title' => $title,
      'content' => $content,
      'envId' => $this->env_id( $a ),
    ] );
    return $this->vector_result( $vector, 'added' );
  }

  private function update_knowledge( array $a ): array {
    $embeddings = $this->embeddings();
    $id = (int) ( $a['id'] ?? 0 );
    $vector = $id ? $embeddings->get_vector( $id ) : null;
    if ( !$vector ) {
      throw new Exception( "No Knowledge entry #{$id}." );
    }
    $changed = false;
    if ( ( $title = $this->str( $a, 'title', false ) ) !== '' ) {
      $vector['title'] = sanitize_text_field( $title );
      $changed = true;
    }
    if ( is_string( $a['content'] ?? null ) && trim( $a['content'] ) !== '' ) {
      $vector['content'] = trim( $a['content'] );
      $changed = true;
    }
    if ( !$changed ) {
      throw new Exception( 'Give a title or a content to change.' );
    }
    // Not undoable, so the old version comes back with the result: the caller can restore it.
    $previous = $embeddings->get_vector( $id );
    return $this->vector_result( $embeddings->update_vector( $vector ), 'updated' )
      + [ 'previous' => [ 'title' => $previous['title'] ?? '', 'text' => (string) ( $previous['content'] ?? '' ) ] ];
  }

  private function delete_knowledge( array $a ): array {
    $embeddings = $this->embeddings();
    $ids = array_values( array_unique( array_filter( array_map( 'intval', $this->json_arg( $a['ids'] ?? null ) ) ) ) );
    if ( empty( $ids ) && !empty( $a['id'] ) ) {
      $ids = [ (int) $a['id'] ];
    }
    if ( empty( $ids ) || count( $ids ) > 50 ) {
      throw new Exception( 'ids is required: between 1 and 50 entry IDs.' );
    }
    $byEnv = [];
    $missing = [];
    $previous = [];
    foreach ( $ids as $id ) {
      $vector = $embeddings->get_vector( $id );
      if ( $vector ) {
        $byEnv[ (string) $vector['envId'] ][] = $id;
        $previous[ $id ] = [ 'id' => $id, 'title' => $vector['title'], 'type' => $vector['type'], 'refId' => $vector['refId'] ? (int) $vector['refId'] : null,
          'envId' => $vector['envId'], 'text' => (string) ( $vector['content'] ?? '' ) ];
      }
      else {
        $missing[] = $id;
      }
    }
    $deleted = [];
    foreach ( $byEnv as $envId => $envIds ) {
      if ( $embeddings->vectors_delete( $envId, $envIds ) ) {
        $deleted = array_merge( $deleted, $envIds );
      }
    }
    // Not undoable: the deleted entries come back in full, so they can be added again if needed.
    return [ 'deleted' => $deleted, 'notFound' => $missing,
      'previous' => array_values( array_intersect_key( $previous, array_flip( $deleted ) ) ) ];
  }
  #endregion

  #region Settings
  private function stored_settings(): array {
    $this->core->forget_cached_options( self::SETTINGS_OPTION );
    $stored = get_option( self::SETTINGS_OPTION, [] );
    return is_array( $stored ) ? $stored : [];
  }

  private function get_settings( array $a ): array {
    $options = $this->core->get_all_options( true );
    $keys = array_values( array_filter( array_map( 'strval', $this->json_arg( $a['keys'] ?? null ) ) ) );
    $search = mb_strtolower( $this->str( $a, 'search', false ) );
    $picked = [];
    $omitted = [];
    $missing = [];
    if ( $keys ) {
      foreach ( $keys as $key ) {
        if ( array_key_exists( $key, $options ) ) {
          $picked[ $key ] = $options[ $key ];
        }
        else {
          $missing[] = $key;
        }
      }
    }
    else {
      foreach ( $options as $key => $value ) {
        if ( $search !== '' && strpos( mb_strtolower( (string) $key ), $search ) === false ) {
          continue;
        }
        if ( in_array( $key, self::BULKY_SETTINGS, true ) ) {
          $omitted[] = $key;
          continue;
        }
        $picked[ $key ] = $value;
      }
    }
    ksort( $picked );
    $result = [ 'settings' => Meow_MWAI_Labs_MCP_Core::mask_secrets( $picked ) ];
    if ( $omitted ) {
      $result['omitted'] = $omitted;
    }
    if ( $missing ) {
      $result['notFound'] = $missing;
    }
    return $result;
  }

  // Why a setting cannot be written through MCP, or null.
  private function locked_reason( string $key ): ?string {
    if ( preg_match( Meow_MWAI_Labs_MCP_Core::SECRET_NAME, $key ) || stripos( $key, 'bearer' ) !== false ) {
      return "{$key} is a secret: set it in the AI Engine settings.";
    }
    if ( strpos( $key, 'module_' ) === 0 ) {
      return "{$key} is a module: use mwai_set_module.";
    }
    if ( strpos( $key, 'mcp_' ) === 0 ) {
      return "{$key} is an MCP setting: only the site owner can change it, in AI Engine → Settings → MCP.";
    }
    if ( in_array( $key, self::LOCKED_SETTINGS, true ) ) {
      return "{$key} cannot be changed through MCP: use the AI Engine settings.";
    }
    return null;
  }

  private function update_settings( array $a ): array {
    $changes = $this->json_arg( $a['changes'] ?? null );
    if ( empty( $changes ) ) {
      throw new Exception( 'changes is required: the settings to change, as { key: value }.' );
    }
    if ( count( $changes ) > 20 ) {
      throw new Exception( 'At most 20 settings at once.' );
    }
    $current = $this->core->get_all_options( true );
    $stored = $this->stored_settings();
    $errors = [];
    $final = [];
    foreach ( $changes as $key => $value ) {
      $key = (string) $key;
      if ( $reason = $this->locked_reason( $key ) ) {
        $errors[] = $reason;
        continue;
      }
      if ( !array_key_exists( $key, MWAI_OPTIONS ) && !array_key_exists( $key, $stored ) ) {
        $errors[] = "{$key} is not an AI Engine setting (see mwai_get_settings).";
        continue;
      }
      if ( Meow_MWAI_Labs_MCP_Core::contains_mask( $value ) ) {
        $errors[] = "{$key} holds a masked value (" . Meow_MWAI_Labs_MCP_Core::SECRET_MASK . '), which would overwrite the real one.';
        continue;
      }
      $was = $current[ $key ] ?? null;
      if ( $error = $this->type_error( $key, $value, $was ) ) {
        $errors[] = $error;
        continue;
      }
      if ( is_int( $was ) && is_numeric( $value ) && (string) (int) $value === (string) $value ) {
        $value = (int) $value;
      }
      elseif ( is_float( $was ) && is_numeric( $value ) ) {
        $value = (float) $value;
      }
      elseif ( is_string( $was ) && is_numeric( $value ) ) {
        $value = (string) $value;
      }
      elseif ( is_array( $was ) && is_array( $value ) && $was && !array_is_list( $was ) && !array_is_list( $value ) ) {
        $value = array_replace( $was, $value );
      }
      $final[ $key ] = $value;
    }
    if ( $errors ) {
      throw new Exception( 'Nothing was changed. ' . implode( ' ', $errors ) );
    }
    $this->core->patch_options( $final );
    $after = $this->core->get_all_options( true );
    $values = [];
    foreach ( array_keys( $final ) as $key ) {
      $values[ $key ] = $after[ $key ] ?? null;
    }
    return [ 'updated' => Meow_MWAI_Labs_MCP_Core::mask_secrets( $values ) ];
  }
  #endregion

  #region Modules
  private function module_keys(): array {
    $keys = array_merge( array_keys( MWAI_OPTIONS ), array_keys( $this->stored_settings() ), self::PRO_MODULES );
    $keys = array_filter( array_unique( $keys ), function ( $key ) {
      return strpos( (string) $key, 'module_' ) === 0;
    } );
    sort( $keys );
    return $keys;
  }

  private function list_modules(): array {
    $options = $this->core->get_all_options( true );
    $registered = $this->is_registered();
    $modules = [];
    foreach ( $this->module_keys() as $key ) {
      $pro = in_array( $key, self::PRO_MODULES, true );
      $modules[] = [ 'module' => $key, 'enabled' => !empty( $options[ $key ] ), 'pro' => $pro, 'available' => !$pro || $registered ];
    }
    return [ 'proRegistered' => $registered, 'modules' => $modules ];
  }

  private function set_module( array $a ): array {
    $module = $this->str( $a, 'module' );
    if ( !array_key_exists( 'enabled', $a ) || !is_bool( $a['enabled'] ) ) {
      throw new Exception( 'enabled is required: true or false.' );
    }
    $enabled = $a['enabled'];
    if ( !in_array( $module, $this->module_keys(), true ) ) {
      throw new Exception( "{$module} is not an AI Engine module (see mwai_list_modules)." );
    }
    if ( $module === 'module_mcp' ) {
      throw new Exception( 'MCP itself can only be switched by the site owner, in AI Engine → Settings → Modules.' );
    }
    if ( $enabled && in_array( $module, self::PRO_MODULES, true ) && !$this->is_registered() ) {
      throw new Exception( "{$module} needs AI Engine Pro with a registered licence." );
    }
    if ( (bool) $this->core->get_option( $module ) === $enabled ) {
      return [ 'module' => $module, 'enabled' => $enabled, 'note' => 'It was already ' . ( $enabled ? 'on' : 'off' ) . '.' ];
    }
    $this->core->patch_options( [ $module => $enabled ] );
    return [ 'module' => $module, 'enabled' => $enabled, 'note' => 'Takes effect from the next request.' ];
  }
  #endregion

  #region Undo
  public function undo_targets( $targets, string $tool, array $a ) {
    switch ( $tool ) {
      case 'mwai_create_chatbot':
        return [ [ 'kind' => 'mwai_chatbot', 'id' => $this->new_bot_id( $a ) ] ];
      case 'mwai_update_chatbot':
      case 'mwai_delete_chatbot':
        $botId = $this->str( $a, 'botId', false );
        return $botId !== '' ? [ [ 'kind' => 'mwai_chatbot', 'id' => $botId ] ] : null;
      case 'mwai_update_settings':
        $keys = array_map( 'strval', array_keys( $this->json_arg( $a['changes'] ?? null ) ) );
        return $keys ? [ [ 'kind' => 'mwai_settings', 'id' => implode( ',', $keys ), 'keys' => $keys ] ] : null;
      case 'mwai_set_module':
        $module = $this->str( $a, 'module', false );
        return $module !== '' ? [ [ 'kind' => 'mwai_settings', 'id' => $module, 'keys' => [ $module ] ] ] : null;
    }
    return $targets;
  }

  // Each kind reads its state from the database and writes back through AI Engine's own methods.
  // A null state means absent: a created chatbot is removed, a setting falls back to its default.
  public function undo_kinds( array $kinds ): array {
    $can = function () {
      return current_user_can( 'manage_options' );
    };
    $kinds['mwai_chatbot'] = [
      'recreates' => true,
      'read' => function ( $t ) {
        return $this->stored_chatbot( (string) $t['id'] );
      },
      'write' => function ( $t, $state ) {
        if ( $state === null && $t['id'] === 'default' ) {
          throw new Exception( 'The default chatbot cannot be removed.' );
        }
        $this->write_chatbot( (string) $t['id'], is_array( $state ) ? $state : null );
      },
      'can' => $can,
      'title' => function ( $t ) {
        $bot = $this->stored_chatbot( (string) $t['id'] );
        return 'Chatbot ' . ( $bot['name'] ?? $t['id'] );
      },
    ];
    $kinds['mwai_settings'] = [
      'recreates' => true,
      'read' => function ( $t ) {
        $stored = $this->stored_settings();
        $state = [];
        foreach ( (array) $t['keys'] as $key ) {
          $state[ $key ] = $stored[ $key ] ?? null;
        }
        return $state;
      },
      'write' => function ( $t, $state ) {
        $stored = $this->stored_settings();
        if ( empty( $stored ) ) {
          throw new Exception( 'The AI Engine settings could not be read, so nothing was restored.' );
        }
        foreach ( (array) $t['keys'] as $key ) {
          if ( !is_array( $state ) || !isset( $state[ $key ] ) ) {
            unset( $stored[ $key ] );
          }
          else {
            $stored[ $key ] = $state[ $key ];
          }
        }
        $this->core->update_options( $stored );
      },
      'can' => $can,
      'title' => function ( $t ) {
        return 'AI Engine settings: ' . implode( ', ', (array) $t['keys'] );
      },
    ];
    return $kinds;
  }
  #endregion
}
