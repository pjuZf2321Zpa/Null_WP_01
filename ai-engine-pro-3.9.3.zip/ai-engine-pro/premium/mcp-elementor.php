<?php

// Elementor pages as MCP tools: read a page as an outline, then change one element at a time.
// Elementor keeps the real page in _elementor_data, and post_content is only a plain copy, so
// editing post_content changed nothing visible. Every write goes through Elementor's own
// document save, never a raw meta write: update_post_meta() strips the JSON's backslashes, and
// the save also rebuilds the page CSS and adds a revision, so a change can be undone in Elementor.
class MeowPro_MWAI_MCP_Elementor {
  private $core = null;

  // Settings worth showing in the outline: the visible text, links and images of the common widgets.
  private const SUMMARY_KEYS = [ 'title', 'editor', 'text', 'description', 'heading', 'caption',
    'title_text', 'description_text', 'button_text', 'html', 'link', 'url', 'image', 'tab_title' ];

  #region Initialize
  public function __construct( $core ) {
    $this->core = $core;
    add_action( 'rest_api_init', [ $this, 'rest_api_init' ] );
  }

  public function rest_api_init() {
    add_filter( 'mwai_mcp_tools', [ $this, 'register_rest_tools' ] );
    add_filter( 'mwai_mcp_callback', [ $this, 'handle_call' ], 10, 4 );
    add_filter( 'mwai_mcp_undo_targets', [ $this, 'undo_targets' ], 10, 3 );
    add_filter( 'mwai_mcp_undo_kinds', [ $this, 'undo_kinds' ] );
  }
  #endregion

  #region Undo (labs/mcp-undo.php)
  // The page is restored through Elementor's own save, like every write here, so its CSS is
  // rebuilt and Elementor keeps a revision of the undo too.
  public function undo_targets( $targets, string $tool, array $a ) {
    if ( strpos( $tool, 'elementor_' ) !== 0 || $tool === 'elementor_get_page' || $tool === 'elementor_get_element' ) {
      return $targets;
    }
    $post_id = (int) ( $a['post_id'] ?? 0 );
    return $post_id && empty( $a['dry_run'] ) ? [ [ 'kind' => 'elementor', 'id' => $post_id ] ] : [];
  }

  public function undo_kinds( array $kinds ): array {
    $kinds['elementor'] = [
      'read' => function ( $t ) {
        $rows = Meow_MWAI_Labs_MCP_Undo::raw_meta( (int) $t['id'], '_elementor_data' );
        return $rows ? $rows[0] : null;
      },
      'write' => function ( $t, $state ) {
        $elements = json_decode( (string) $state, true );
        if ( !is_array( $elements ) ) {
          throw new Exception( 'The previous version of this Elementor page could not be read.' );
        }
        $this->document( (int) $t['id'] )->save( [ 'elements' => $elements ] );
      },
      'can' => function ( $t ) { return current_user_can( 'edit_post', (int) $t['id'] ); },
      'title' => function ( $t ) { return Meow_MWAI_Labs_MCP_Undo::post_title( (int) $t['id'] ); },
    ];
    return $kinds;
  }
  #endregion

  #region Helpers
  private function post_schema( array $extra = [], array $required = [] ): array {
    return [
      'type' => 'object',
      'properties' => array_merge( [
        'post_id' => [ 'type' => 'integer', 'description' => 'The post or page ID.' ],
      ], $extra ),
      'required' => array_merge( [ 'post_id' ], $required ),
    ];
  }

  private function dry_run_schema(): array {
    return [ 'type' => 'boolean', 'description' => 'Return the change without saving it.' ];
  }

  private function hash_schema(): array {
    return [ 'type' => 'string', 'description' => 'Optional. The hash from elementor_get_page; the write is refused if the page changed since.' ];
  }

  private function document( int $post_id ) {
    if ( !current_user_can( 'edit_post', $post_id ) ) {
      throw new Exception( "You are not allowed to edit post #{$post_id}.", Meow_MWAI_Labs_MCP::DENIED_CODE );
    }
    $document = \Elementor\Plugin::$instance->documents->get( $post_id, false );
    if ( !$document ) {
      throw new Exception( "Post #{$post_id} was not found." );
    }
    if ( !$document->is_built_with_elementor() ) {
      throw new Exception( "Post #{$post_id} is not built with Elementor. Use the regular post tools." );
    }
    return $document;
  }

  private function hash( array $elements ): string {
    return substr( md5( wp_json_encode( $elements ) ), 0, 12 );
  }

  private function check_hash( array $elements, array $a ) {
    if ( !empty( $a['if_hash'] ) && $a['if_hash'] !== $this->hash( $elements ) ) {
      throw new Exception( 'The page changed since you read it. Read it again with elementor_get_page.' );
    }
  }

  private function summarize( $value ) {
    if ( is_array( $value ) ) {
      $value = $value['url'] ?? ( $value['text'] ?? null );
    }
    if ( !is_string( $value ) || $value === '' ) {
      return null;
    }
    $text = trim( preg_replace( '/\s+/', ' ', wp_strip_all_tags( $value ) ) );
    return mb_strlen( $text ) > 120 ? mb_substr( $text, 0, 117 ) . '...' : $text;
  }

  private function outline( array $elements, int $depth = 0 ): array {
    $out = [];
    foreach ( $elements as $el ) {
      $node = [
        'id' => $el['id'] ?? '',
        'type' => ( $el['elType'] ?? '' ) === 'widget' ? ( $el['widgetType'] ?? 'widget' ) : ( $el['elType'] ?? '' ),
      ];
      $summary = [];
      foreach ( self::SUMMARY_KEYS as $key ) {
        if ( isset( $el['settings'][ $key ] ) ) {
          $value = $this->summarize( $el['settings'][ $key ] );
          if ( $value !== null ) {
            $summary[ $key ] = $value;
          }
        }
      }
      if ( $summary ) {
        $node['content'] = $summary;
      }
      if ( !empty( $el['elements'] ) ) {
        $node['children'] = $this->outline( $el['elements'], $depth + 1 );
      }
      $out[] = $node;
    }
    return $out;
  }

  // Walks the tree and hands every element to $fn by reference. $fn returns true to stop.
  private function walk( array &$elements, callable $fn ): bool {
    foreach ( $elements as $i => &$el ) {
      if ( $fn( $el, $elements, $i ) === true ) {
        return true;
      }
      if ( !empty( $el['elements'] ) && $this->walk( $el['elements'], $fn ) ) {
        return true;
      }
    }
    return false;
  }

  private function find( array $elements, string $id ) {
    $found = null;
    $this->walk( $elements, function ( &$el ) use ( $id, &$found ) {
      if ( ( $el['id'] ?? '' ) === $id ) {
        $found = $el;
        return true;
      }
    } );
    return $found;
  }

  private function new_id(): string {
    return substr( bin2hex( random_bytes( 4 ) ), 0, 7 );
  }

  // New elements need fresh ids, children included, or Elementor mixes them up with the originals.
  private function fresh_ids( array $el ): array {
    $el['id'] = $this->new_id();
    if ( !empty( $el['elements'] ) ) {
      $el['elements'] = array_map( [ $this, 'fresh_ids' ], $el['elements'] );
    }
    else {
      $el['elements'] = [];
    }
    return $el;
  }

  private function replace_in( $value, string $search, string $replace, bool $regex, int &$count ) {
    if ( is_string( $value ) ) {
      $n = 0;
      $new = $regex ? preg_replace( $search, $replace, $value, -1, $n ) : str_replace( $search, $replace, $value, $n );
      if ( $new === null ) {
        throw new Exception( 'The regular expression is not valid.' );
      }
      $count += $n;
      return $new;
    }
    if ( is_array( $value ) ) {
      foreach ( $value as $k => $v ) {
        // Leave ids, CSS classes and keys alone: only content values are rewritten.
        if ( in_array( $k, [ 'id', '_id', '_element_id', 'css_classes', '__dynamic__' ], true ) ) {
          continue;
        }
        $value[ $k ] = $this->replace_in( $v, $search, $replace, $regex, $count );
      }
    }
    return $value;
  }

  private function save( $document, array $elements, int $post_id ): array {
    $document->save( [ 'elements' => $elements ] );
    // Re-read what Elementor stored, so the result reflects the saved page, not our intention.
    $saved = \Elementor\Plugin::$instance->documents->get( $post_id, false )->get_elements_data();
    return [ 'saved' => true, 'hash' => $this->hash( $saved ),
      'edit_link' => admin_url( "post.php?post={$post_id}&action=elementor" ) ];
  }
  #endregion

  #region Tools
  private function tools(): array {
    return [
      'elementor_get_page' => [
        'name' => 'elementor_get_page',
        'title' => 'Read an Elementor page',
        'description' => 'Read an Elementor page as an outline: every section, container and widget with its id, type and visible text, links and images. Use this before any Elementor change: post_content does not hold the real page. Returns a hash to pass to the write tools.',
        'inputSchema' => $this->post_schema(),
        'accessLevel' => 'read',
      ],
      'elementor_get_element' => [
        'name' => 'elementor_get_element',
        'title' => 'Read an Elementor element',
        'description' => 'Get the full settings of one element (widget, container or section) by its id, to see exactly which setting to change.',
        'inputSchema' => $this->post_schema( [
          'element_id' => [ 'type' => 'string', 'description' => 'The element id from elementor_get_page.' ],
        ], [ 'element_id' ] ),
        'accessLevel' => 'read',
      ],
      'elementor_update_element' => [
        'name' => 'elementor_update_element',
        'title' => 'Update an Elementor element',
        'description' => 'Change some settings of one element, for example {"title": "New heading"} on a heading widget or {"editor": "<p>New text</p>"} on a text editor. Only the given settings change. Saved through Elementor, with a revision.',
        'inputSchema' => $this->post_schema( [
          'element_id' => [ 'type' => 'string', 'description' => 'The element id from elementor_get_page.' ],
          'settings' => [ 'type' => 'object', 'description' => 'The settings to change, merged into the existing ones.' ],
          'if_hash' => $this->hash_schema(),
          'dry_run' => $this->dry_run_schema(),
        ], [ 'element_id', 'settings' ] ),
        'accessLevel' => 'write',
      ],
      'elementor_replace_text' => [
        'name' => 'elementor_replace_text',
        'title' => 'Replace text in an Elementor page',
        'description' => 'Find and replace text in every widget of an Elementor page (headings, texts, buttons, links). Use dry_run first to see how many places change.',
        'inputSchema' => $this->post_schema( [
          'search' => [ 'type' => 'string', 'description' => 'The text to find.' ],
          'replace' => [ 'type' => 'string', 'description' => 'The replacement.' ],
          'regex' => [ 'type' => 'boolean', 'description' => 'Treat search as a PHP regular expression, with delimiters.' ],
          'if_hash' => $this->hash_schema(),
          'dry_run' => $this->dry_run_schema(),
        ], [ 'search', 'replace' ] ),
        'accessLevel' => 'write',
      ],
      'elementor_insert_element' => [
        'name' => 'elementor_insert_element',
        'title' => 'Add an Elementor element',
        'description' => 'Insert a new element, given as Elementor JSON ({"elType": "widget", "widgetType": "heading", "settings": {"title": "Hello"}}), before or after an element, or as the last child of a container. Without a target, it is added at the end of the page. Copy an existing element with elementor_get_element to match the page style. New ids are generated.',
        'inputSchema' => $this->post_schema( [
          'element' => [ 'type' => 'object', 'description' => 'The element to insert, in Elementor JSON.' ],
          'target_id' => [ 'type' => 'string', 'description' => 'The element to insert next to, or inside.' ],
          'position' => [ 'type' => 'string', 'enum' => [ 'before', 'after', 'inside' ], 'description' => 'Where to insert, relative to the target. Default: after.' ],
          'if_hash' => $this->hash_schema(),
          'dry_run' => $this->dry_run_schema(),
        ], [ 'element' ] ),
        'accessLevel' => 'write',
      ],
      'elementor_delete_element' => [
        'name' => 'elementor_delete_element',
        'title' => 'Remove an Elementor element',
        'description' => 'Remove one element and everything inside it from an Elementor page. A revision is kept, so it can be restored from Elementor.',
        'inputSchema' => $this->post_schema( [
          'element_id' => [ 'type' => 'string', 'description' => 'The element id from elementor_get_page.' ],
          'if_hash' => $this->hash_schema(),
        ], [ 'element_id' ] ),
        'accessLevel' => 'write',
      ],
    ];
  }

  public function register_rest_tools( array $prev ): array {
    $tools = $this->tools();
    foreach ( $tools as &$tool ) {
      $tool['category'] = 'AI Engine (Elementor)';
      $tool['annotations'] = [
        'readOnlyHint' => $tool['accessLevel'] === 'read',
        'destructiveHint' => $tool['name'] === 'elementor_delete_element',
        'openWorldHint' => false,
      ];
    }
    return array_merge( $prev, array_values( $tools ) );
  }
  #endregion

  #region Callback
  public function handle_call( $prev, string $tool, array $args, int|string|null $id ) {
    if ( !empty( $prev ) || !isset( $this->tools()[ $tool ] ) ) {
      return $prev;
    }
    if ( !class_exists( '\Elementor\Plugin' ) ) {
      throw new Exception( 'Elementor is not active.' );
    }
    $post_id = intval( $args['post_id'] ?? 0 );
    $document = $this->document( $post_id );
    $elements = $document->get_elements_data();
    if ( !is_array( $elements ) ) {
      $elements = [];
    }

    switch ( $tool ) {
      case 'elementor_get_page':
        return [
          'post_id' => $post_id,
          'title' => get_the_title( $post_id ),
          'hash' => $this->hash( $elements ),
          'elementor_version' => get_post_meta( $post_id, '_elementor_version', true ),
          'outline' => $this->outline( $elements ),
        ];

      case 'elementor_get_element':
        $el = $this->find( $elements, (string) $args['element_id'] );
        if ( !$el ) {
          throw new Exception( 'Element not found. Read the page again with elementor_get_page.' );
        }
        if ( !empty( $el['elements'] ) ) {
          $el['elements'] = $this->outline( $el['elements'] );
        }
        return $el;

      case 'elementor_update_element':
        $this->check_hash( $elements, $args );
        $settings = $args['settings'] ?? null;
        if ( is_string( $settings ) ) {
          $settings = json_decode( $settings, true );
        }
        if ( !is_array( $settings ) || !$settings ) {
          throw new Exception( 'settings must be an object with at least one setting.' );
        }
        $target = (string) $args['element_id'];
        $before = null;
        $after = null;
        $done = $this->walk( $elements, function ( &$el ) use ( $target, $settings, &$before, &$after ) {
          if ( ( $el['id'] ?? '' ) !== $target ) {
            return;
          }
          $current = isset( $el['settings'] ) && is_array( $el['settings'] ) ? $el['settings'] : [];
          $before = array_intersect_key( $current, $settings );
          $el['settings'] = array_replace( $current, $settings );
          $after = $settings;
          return true;
        } );
        if ( !$done ) {
          throw new Exception( 'Element not found. Read the page again with elementor_get_page.' );
        }
        $change = [ 'element_id' => $target, 'before' => $before, 'after' => $after ];
        if ( !empty( $args['dry_run'] ) ) {
          return $change + [ 'dry_run' => true ];
        }
        return $change + $this->save( $document, $elements, $post_id );

      case 'elementor_replace_text':
        $this->check_hash( $elements, $args );
        $search = (string) ( $args['search'] ?? '' );
        if ( $search === '' ) {
          throw new Exception( 'search cannot be empty.' );
        }
        $regex = !empty( $args['regex'] );
        $count = 0;
        $changed = [];
        $this->walk( $elements, function ( &$el ) use ( $search, $args, $regex, &$count, &$changed ) {
          if ( empty( $el['settings'] ) || !is_array( $el['settings'] ) ) {
            return;
          }
          $before = $count;
          $el['settings'] = $this->replace_in( $el['settings'], $search, (string) $args['replace'], $regex, $count );
          if ( $count > $before ) {
            $changed[] = $el['id'] ?? '';
          }
        } );
        $result = [ 'replacements' => $count, 'elements' => $changed ];
        if ( !empty( $args['dry_run'] ) || $count === 0 ) {
          return $result + [ 'dry_run' => !empty( $args['dry_run'] ), 'saved' => false ];
        }
        return $result + $this->save( $document, $elements, $post_id );

      case 'elementor_insert_element':
        $this->check_hash( $elements, $args );
        $new = $args['element'] ?? null;
        if ( is_string( $new ) ) {
          $new = json_decode( $new, true );
        }
        if ( !is_array( $new ) || empty( $new['elType'] ) ) {
          throw new Exception( 'element must be Elementor JSON with at least an elType.' );
        }
        if ( $new['elType'] === 'widget' && empty( $new['widgetType'] ) ) {
          throw new Exception( 'A widget needs a widgetType (for example heading, text-editor, button, image).' );
        }
        $new = $this->fresh_ids( $new );
        $new['settings'] = isset( $new['settings'] ) && is_array( $new['settings'] ) ? $new['settings'] : [];
        $target = (string) ( $args['target_id'] ?? '' );
        $position = in_array( $args['position'] ?? 'after', [ 'before', 'after', 'inside' ], true ) ? ( $args['position'] ?? 'after' ) : 'after';
        if ( $target === '' ) {
          if ( $new['elType'] === 'widget' ) {
            throw new Exception( 'A widget must go inside a container: give a target_id.' );
          }
          $elements[] = $new;
        }
        else {
          $done = $this->walk( $elements, function ( &$el, &$siblings, $i ) use ( $target, $position, $new ) {
            if ( ( $el['id'] ?? '' ) !== $target ) {
              return;
            }
            if ( $position === 'inside' ) {
              if ( ( $el['elType'] ?? '' ) === 'widget' ) {
                throw new Exception( 'A widget cannot hold other elements: insert before or after it.' );
              }
              $el['elements'][] = $new;
            }
            else {
              array_splice( $siblings, $position === 'before' ? $i : $i + 1, 0, [ $new ] );
            }
            return true;
          } );
          if ( !$done ) {
            throw new Exception( 'Target element not found. Read the page again with elementor_get_page.' );
          }
        }
        if ( !empty( $args['dry_run'] ) ) {
          return [ 'dry_run' => true, 'element' => $new ];
        }
        return [ 'element_id' => $new['id'] ] + $this->save( $document, $elements, $post_id );

      case 'elementor_delete_element':
        $this->check_hash( $elements, $args );
        $target = (string) $args['element_id'];
        $done = $this->walk( $elements, function ( &$el, &$siblings, $i ) use ( $target ) {
          if ( ( $el['id'] ?? '' ) !== $target ) {
            return;
          }
          array_splice( $siblings, $i, 1 );
          return true;
        } );
        if ( !$done ) {
          throw new Exception( 'Element not found. Read the page again with elementor_get_page.' );
        }
        return [ 'deleted' => $target ] + $this->save( $document, $elements, $post_id );
    }
    throw new Exception( 'Unknown tool' );
  }
  #endregion
}
