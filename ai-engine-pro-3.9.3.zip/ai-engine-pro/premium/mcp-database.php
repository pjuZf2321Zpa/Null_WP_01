<?php

class MeowPro_MWAI_MCP_Database {
  private $core = null;

  #region Initialize
  public function __construct( $core ) {
    $this->core = $core;
    add_action( 'rest_api_init', [ $this, 'rest_api_init' ] );
  }

  public function rest_api_init() {
    add_filter( 'mwai_mcp_tools', [ $this, 'register_rest_tools' ] );
    add_filter( 'mwai_mcp_callback', [ $this, 'handle_call' ], 10, 4 );
  }
  #endregion

  #region Tools
  private function tools(): array {
    global $wpdb;
    return [
      'wp_db_tables' => [
        'name' => 'wp_db_tables',
        'description' => "List the tables of this WordPress database with their row count, size, engine and the plugin that most likely created them. Read-only. Use it before writing SQL, instead of guessing table names. Optional 'search' filters by name.",
        'inputSchema' => [
          'type' => 'object',
          'properties' => [
            'search' => [ 'type' => 'string', 'description' => 'Only tables whose name contains this text.' ],
            'all_prefixes' => [ 'type' => 'boolean', 'description' => "Also list tables that don't use this site's prefix '{$wpdb->prefix}' (other installs sharing the database)." ],
          ],
        ],
        'category' => 'AI Engine (Database)',
        'annotations' => [ 'readOnlyHint' => true, 'destructiveHint' => false, 'openWorldHint' => false ],
        'accessLevel' => 'admin',
      ],
      'wp_db_describe' => [
        'name' => 'wp_db_describe',
        'description' => 'Describe one table: its columns (type, null, default, key), its indexes, its row count and size. Read-only.',
        'inputSchema' => [
          'type' => 'object',
          'properties' => [
            'table' => [ 'type' => 'string', 'description' => "The full table name, for example '{$wpdb->prefix}posts'." ],
          ],
          'required' => [ 'table' ],
        ],
        'category' => 'AI Engine (Database)',
        'annotations' => [ 'readOnlyHint' => true, 'destructiveHint' => false, 'openWorldHint' => false ],
        'accessLevel' => 'admin',
      ],
      'wp_db_autoload' => [
        'name' => 'wp_db_autoload',
        'description' => 'Show what WordPress loads on every page from the options table: the total size of autoloaded options and the biggest ones, with the plugin they most likely belong to. Read-only. A large total (over about 1 MB) slows every request.',
        'inputSchema' => [
          'type' => 'object',
          'properties' => [
            'limit' => [ 'type' => 'integer', 'description' => 'How many of the biggest options to return (default 20, max 100).' ],
          ],
        ],
        'category' => 'AI Engine (Database)',
        'annotations' => [ 'readOnlyHint' => true, 'destructiveHint' => false, 'openWorldHint' => false ],
        'accessLevel' => 'admin',
      ],
      'wp_db_query' => [
        'name' => 'wp_db_query',
        'description' => "Run a SQL query against the WordPress database and return the rows. Use wp_db_tables and wp_db_describe first to know the tables and columns. The table prefix is '{$wpdb->prefix}'. Read-only by default: SELECT / SHOW / DESCRIBE / EXPLAIN / WITH. Anything else is a write and is blocked unless you pass confirm_write: true. The gate covers ALL non-read SQL: DML (INSERT, UPDATE, DELETE, REPLACE) and DDL (ALTER, DROP, CREATE, TRUNCATE, RENAME, GRANT, REVOKE). For post / meta mutations prefer the dedicated tools (wp_create_post, wp_update_post, wp_alter_post, wp_delete_post, wp_update_post_meta) which validate inputs and bust caches.",
        'inputSchema' => [
          'type' => 'object',
          'properties' => [
            'query' => [
              'type' => 'string',
              'description' => 'The SQL query to execute.',
            ],
            'confirm_write' => [
              'type' => 'boolean',
              'description' => 'Required to be true for non-read queries. Without it, write queries are rejected.',
            ],
          ],
          'required' => [ 'query' ],
        ],
        'category' => 'AI Engine (Database)',
        'annotations' => [
          'readOnlyHint' => false,
          'destructiveHint' => true,
          'openWorldHint' => false,
        ],
        'accessLevel' => 'admin',
      ],
    ];
  }
  #endregion

  #region Helpers
  // Best guess of who created a table or option, from well-known name prefixes. A hint for the
  // assistant, never used to decide anything.
  private const OWNERS = [
    'mwai_' => 'AI Engine', 'mwseo' => 'SEO Engine', 'mwcode' => 'Code Engine', 'mwflow' => 'Workflow Engine', 'mclean' => 'Media Cleaner', 'mfrh_' => 'Media File Renamer', 'mgcl_' => 'Meow Gallery',
    'wc_' => 'WooCommerce', 'woocommerce_' => 'WooCommerce', 'actionscheduler_' => 'Action Scheduler (WooCommerce and others)',
    'yoast_' => 'Yoast SEO', 'wpseo' => 'Yoast SEO', 'rank_math' => 'Rank Math', 'aioseo' => 'All in One SEO',
    'icl_' => 'WPML', 'pll_' => 'Polylang', 'polylang' => 'Polylang', 'elementor' => 'Elementor', '_elementor' => 'Elementor',
    'gf_' => 'Gravity Forms', 'rg_' => 'Gravity Forms', 'wpforms' => 'WPForms', 'fluentform' => 'Fluent Forms', 'frm_' => 'Formidable Forms',
    'redirection_' => 'Redirection', 'wfl' => 'Wordfence', 'wf' => 'Wordfence', 'itsec' => 'Solid Security', 'litespeed' => 'LiteSpeed Cache',
    'wp_rocket' => 'WP Rocket', 'jetpack' => 'Jetpack', 'edd_' => 'Easy Digital Downloads', 'learndash' => 'LearnDash',
    'acf_' => 'ACF', 'mailpoet' => 'MailPoet', 'wpml' => 'WPML', 'updraft' => 'UpdraftPlus', 'smush' => 'Smush', 'wpcode' => 'WPCode',
  ];
  private const CORE_TABLES = [ 'posts', 'postmeta', 'users', 'usermeta', 'options', 'terms', 'termmeta', 'term_taxonomy',
    'term_relationships', 'comments', 'commentmeta', 'links', 'blogs', 'blogmeta', 'site', 'sitemeta', 'signups',
    'registration_log', 'blog_versions' ];

  private const CORE_OPTIONS = [ 'rewrite_rules', 'wp_user_roles', 'cron', 'active_plugins', 'sidebars_widgets',
    'siteurl', 'home', 'recently_activated', 'uninstall_plugins', 'can_compress_scripts', 'db_version' ];

  private function guess_owner( string $name, bool $isTable ): string {
    global $wpdb;
    if ( !$isTable ) {
      $cache = preg_match( '/^_(site_)?transient_(timeout_)?/', $name );
      $base = preg_replace( '/^_(site_)?transient_(timeout_)?/', '', $name );
      $owner = in_array( $base, self::CORE_OPTIONS, true ) || preg_match( '/^(widget_|theme_mods_|wp_core_|dirsize|update_|health-check)/', $base )
        ? 'WordPress' : $this->guess_owner_by_prefix( $base );
      return $cache ? ( $owner === 'Unknown' ? 'Cache (transient)' : "$owner (cache)" ) : $owner;
    }
    $short = $isTable && strpos( $name, $wpdb->base_prefix ) === 0 ? substr( $name, strlen( $wpdb->base_prefix ) ) : $name;
    $short = $isTable ? preg_replace( '/^\d+_/', '', $short ) : $short;
    if ( $isTable && in_array( $short, self::CORE_TABLES, true ) ) {
      return 'WordPress';
    }
    return $this->guess_owner_by_prefix( $short );
  }

  private function guess_owner_by_prefix( string $name ): string {
    $lower = strtolower( ltrim( $name, '_' ) );
    foreach ( self::OWNERS as $prefix => $owner ) {
      if ( strpos( $lower, ltrim( $prefix, '_' ) ) === 0 ) {
        return $owner;
      }
    }
    return 'Unknown';
  }

  // Table names can't be bound as SQL parameters, so a name is only used once it is confirmed to
  // be a real table of this database.
  private function existing_table( string $table ): string {
    global $wpdb;
    $table = trim( $table, ' `' );
    if ( $table === '' || !preg_match( '/^[A-Za-z0-9_$]+$/', $table ) ) {
      throw new Exception( 'Invalid table name.' );
    }
    $found = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $table ) ) );
    if ( $found !== $table ) {
      throw new Exception( "No table named '$table'. Use wp_db_tables to see the tables." );
    }
    return $table;
  }

  private function human_size( $bytes ): string {
    $bytes = (float) $bytes;
    if ( $bytes >= 1048576 ) {
      return round( $bytes / 1048576, 1 ) . ' MB';
    }
    return $bytes >= 1024 ? round( $bytes / 1024, 1 ) . ' KB' : (int) $bytes . ' B';
  }
  #endregion

  #region Register
  public function register_rest_tools( array $prev ): array {
    $tools = $this->tools();
    $merged = array_merge( $prev, array_values( $tools ) );
    return $merged;
  }
  #endregion

  #region Callback
  public function handle_call( $prev, string $tool, array $args, int|string|null $id ) {
    if ( !empty( $prev ) || !isset( $this->tools()[ $tool ] ) ) {
      return $prev;
    }
    // These tools act on the whole site, so they refuse rather than run as another user.
    if ( !current_user_can( 'manage_options' ) ) {
      throw new Exception( 'This tool needs an account that can manage the site.', Meow_MWAI_Labs_MCP::DENIED_CODE );
    }
    return $this->dispatch( $tool, $args );
  }
  #endregion

  #region Dispatcher
  private function dispatch( string $tool, array $a ) {
    global $wpdb;

    switch ( $tool ) {
      case 'wp_db_tables':
        $status = $wpdb->get_results( 'SHOW TABLE STATUS', ARRAY_A );
        if ( $wpdb->last_error ) {
          throw new Exception( $wpdb->last_error );
        }
        $search = strtolower( (string) ( $a['search'] ?? '' ) );
        $tables = [];
        $total = 0;
        foreach ( $status as $t ) {
          $name = $t['Name'];
          if ( empty( $a['all_prefixes'] ) && strpos( $name, $wpdb->prefix ) !== 0 ) {
            continue;
          }
          if ( $search !== '' && strpos( strtolower( $name ), $search ) === false ) {
            continue;
          }
          $size = (int) $t['Data_length'] + (int) $t['Index_length'];
          $total += $size;
          $tables[] = [
            'table' => $name,
            // InnoDB only estimates Rows; exact counts need wp_db_describe.
            'rows_estimate' => (int) $t['Rows'],
            'size' => $this->human_size( $size ),
            'engine' => $t['Engine'],
            'owner' => $this->guess_owner( $name, true ),
          ];
        }
        usort( $tables, fn ( $x, $y ) => strcmp( $x['table'], $y['table'] ) );
        return [ 'prefix' => $wpdb->prefix, 'count' => count( $tables ), 'total_size' => $this->human_size( $total ), 'tables' => $tables ];

      case 'wp_db_describe':
        $table = $this->existing_table( (string) ( $a['table'] ?? '' ) );
        $columns = $wpdb->get_results( "SHOW FULL COLUMNS FROM `$table`", ARRAY_A );
        $indexes = $wpdb->get_results( "SHOW INDEX FROM `$table`", ARRAY_A );
        $status = $wpdb->get_row( $wpdb->prepare( 'SHOW TABLE STATUS LIKE %s', $wpdb->esc_like( $table ) ), ARRAY_A );
        $rows = (int) $wpdb->get_var( "SELECT COUNT(*) FROM `$table`" );
        $keys = [];
        foreach ( $indexes as $i ) {
          $keys[ $i['Key_name'] ]['unique'] = !(int) $i['Non_unique'];
          $keys[ $i['Key_name'] ]['columns'][] = $i['Column_name'];
        }
        return [
          'table' => $table,
          'owner' => $this->guess_owner( $table, true ),
          'rows' => $rows,
          'size' => $this->human_size( (int) ( $status['Data_length'] ?? 0 ) + (int) ( $status['Index_length'] ?? 0 ) ),
          'engine' => $status['Engine'] ?? null,
          'columns' => array_map( fn ( $c ) => [
            'name' => $c['Field'], 'type' => $c['Type'], 'null' => $c['Null'] === 'YES',
            'default' => $c['Default'], 'key' => $c['Key'], 'extra' => $c['Extra'],
          ], $columns ),
          'indexes' => $keys,
        ];

      case 'wp_db_autoload':
        $limit = max( 1, min( 100, (int) ( $a['limit'] ?? 20 ) ) );
        // WordPress 6.6+ also marks autoloaded options as 'on' and 'auto-on'.
        $autoloaded = "autoload IN ('yes', 'on', 'auto-on', 'auto')";
        $total = (int) $wpdb->get_var( "SELECT SUM(LENGTH(option_value)) FROM {$wpdb->options} WHERE $autoloaded" );
        $count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->options} WHERE $autoloaded" );
        $rows = $wpdb->get_results( $wpdb->prepare(
          "SELECT option_name, LENGTH(option_value) AS size FROM {$wpdb->options} WHERE $autoloaded ORDER BY size DESC LIMIT %d",
          $limit
        ), ARRAY_A );
        return [
          'autoloaded_options' => $count,
          'total_size' => $this->human_size( $total ),
          'biggest' => array_map( fn ( $r ) => [
            'option' => $r['option_name'], 'size' => $this->human_size( $r['size'] ), 'owner' => $this->guess_owner( $r['option_name'], false ),
          ], $rows ),
        ];

      case 'wp_db_query':
        $query = $a['query'] ?? '';
        if ( empty( $query ) ) {
          throw new Exception( 'Query is required.' );
        }
        $trimmed = ltrim( $query );
        // Strip a leading SQL comment so "/* foo */ UPDATE ..." is still classified as a write.
        $trimmed = preg_replace( '#^(?:--[^\n]*\n|/\*.*?\*/)\s*#s', '', $trimmed );
        $is_read = (bool) preg_match( '/^\s*(SELECT|SHOW|DESCRIBE|DESC|EXPLAIN|WITH)\b/i', $trimmed );
        if ( $is_read ) {
          $results = $wpdb->get_results( $query, ARRAY_A );
          if ( $wpdb->last_error ) {
            throw new Exception( $wpdb->last_error );
          }
          $count = count( $results );
          return [
            'rows' => $count,
            'data' => $results,
          ];
        }

        // Write path: require explicit confirmation. Silently no-op'ing writes is the worst
        // outcome (the caller assumes success and the data is unchanged), so be loud.
        if ( empty( $a['confirm_write'] ) ) {
          throw new Exception(
            'wp_db_query: write queries are blocked unless confirm_write is true. ' .
            'Prefer the dedicated tools (wp_create_post, wp_update_post, wp_alter_post, ' .
            'wp_delete_post, wp_update_post_meta) which validate inputs and bust caches. ' .
            'If raw SQL is genuinely necessary, retry with confirm_write: true.'
          );
        }
        $affected = $wpdb->query( $query );
        if ( $wpdb->last_error ) {
          throw new Exception( $wpdb->last_error );
        }
        if ( $affected === false ) {
          throw new Exception( 'wp_db_query: query failed (no MySQL error reported).' );
        }
        return [
          'affected_rows' => (int) $affected,
        ];

      default:
        throw new Exception( 'Unknown tool' );
    }
  }
  #endregion
}
