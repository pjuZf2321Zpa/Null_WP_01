<?php

// Beaver Builder pages as MCP tools, like premium/mcp-elementor.php: read a page as an outline,
// then change one module at a time. Beaver keeps the page in _fl_builder_data (published) and
// _fl_builder_draft; writes go through FLBuilderModel::update_layout_data(), which slashes the
// settings, to both, so the editor never opens on an older draft, and the page's CSS/JS cache is
// cleared. Undo restores the whole layout (the "beaver" kind).
class MeowPro_MWAI_MCP_Beaver {
  private $core = null;
  private const TEXT_KEYS = [ 'heading', 'text', 'html', 'content', 'title', 'link', 'photo_src', 'btn_text', 'cta_text', 'subtitle' ];

  public function __construct( $core ) {
    $this->core = $core;
    add_action( 'rest_api_init', [ $this, 'rest_api_init' ] );
  }

  public function rest_api_init() {
    add_filter( 'mwai_mcp_tools', [ $this, 'register_rest_tools' ] );
    add_filter( 'mwai_mcp_callback', [ $this, 'handle_call' ], 10, 4 );
    add_filter( 'mwai_mcp_undo_targets', [ $this, 'undo_targets' ], 10, 3 );
    add_filter( 'mwai_mcp_undo_kinds', [ $this, 'undo_kinds' ] );
  }

  #region Helpers
  private function layout( int $post_id ): array {
    if ( !current_user_can( 'edit_post', $post_id ) ) {
      throw new Exception( "You are not allowed to edit post #{$post_id}.", Meow_MWAI_Labs_MCP::DENIED_CODE );
    }
    if ( !get_post( $post_id ) ) {
      throw new Exception( "Post #{$post_id} was not found." );
    }
    if ( !get_post_meta( $post_id, '_fl_builder_enabled', true ) ) {
      throw new Exception( "Post #{$post_id} is not built with Beaver Builder. Use the regular post tools." );
    }
    return (array) FLBuilderModel::get_layout_data( 'published', $post_id );
  }

  private function hash( array $data ): string {
    return substr( md5( maybe_serialize( $data ) ), 0, 12 );
  }

  private function check_hash( array $data, array $a ) {
    if ( !empty( $a['if_hash'] ) && $a['if_hash'] !== $this->hash( $data ) ) {
      throw new Exception( 'The page changed since you read it. Read it again with beaver_get_page.' );
    }
  }

  private function summary( $settings ): array {
    $out = [];
    foreach ( self::TEXT_KEYS as $key ) {
      $value = $settings->$key ?? null;
      if ( is_string( $value ) && $value !== '' ) {
        $text = trim( preg_replace( '/\s+/', ' ', wp_strip_all_tags( $value ) ) );
        $out[ $key ] = mb_strlen( $text ) > 120 ? mb_substr( $text, 0, 117 ) . '...' : $text;
      }
    }
    return $out;
  }

  // Nodes are a flat list with parents and positions: rebuilt here as a tree.
  private function outline( array $data, string $parent = '' ): array {
    $children = array_filter( $data, function ( $node ) use ( $parent ) {
      return (string) ( $node->parent ?? '' ) === $parent;
    } );
    uasort( $children, function ( $x, $y ) { return ( $x->position ?? 0 ) <=> ( $y->position ?? 0 ); } );
    $out = [];
    foreach ( $children as $id => $node ) {
      $row = [ 'id' => $id, 'type' => $node->type === 'module' ? ( $node->settings->type ?? 'module' ) : $node->type ];
      if ( $node->type === 'module' && ( $summary = $this->summary( $node->settings ) ) ) {
        $row['content'] = $summary;
      }
      if ( $kids = $this->outline( $data, (string) $id ) ) {
        $row['children'] = $kids;
      }
      $out[] = $row;
    }
    return $out;
  }

  private function save( int $post_id, array $data ): array {
    FLBuilderModel::update_layout_data( $data, 'published', $post_id );
    FLBuilderModel::update_layout_data( $data, 'draft', $post_id );
    FLBuilderModel::delete_all_asset_cache( $post_id );
    clean_post_cache( $post_id );
    return [ 'saved' => true, 'hash' => $this->hash( (array) FLBuilderModel::get_layout_data( 'published', $post_id ) ),
      'edit_link' => add_query_arg( 'fl_builder', '', get_permalink( $post_id ) ) ];
  }

  private function replace_in( $value, string $search, string $replace, int &$count ) {
    if ( is_string( $value ) ) {
      $n = 0;
      $value = str_replace( $search, $replace, $value, $n );
      $count += $n;
      return $value;
    }
    if ( is_array( $value ) || is_object( $value ) ) {
      foreach ( $value as $key => $item ) {
        // Ids, classes and the module type are structure, not content.
        if ( in_array( $key, [ 'type', 'id', 'class', 'node' ], true ) ) {
          continue;
        }
        $new = $this->replace_in( $item, $search, $replace, $count );
        is_object( $value ) ? $value->$key = $new : $value[ $key ] = $new;
      }
    }
    return $value;
  }

  // The descendants of a node, to delete them with it.
  private function subtree( array $data, string $id ): array {
    $ids = [ $id ];
    foreach ( $data as $child_id => $node ) {
      if ( (string) ( $node->parent ?? '' ) === $id ) {
        $ids = array_merge( $ids, $this->subtree( $data, (string) $child_id ) );
      }
    }
    return $ids;
  }
  #endregion

  #region Tools
  private function tools(): array {
    $post = [ 'post_id' => [ 'type' => 'integer', 'description' => 'The post or page ID.' ] ];
    $hash = [ 'if_hash' => [ 'type' => 'string', 'description' => 'Optional. The hash from beaver_get_page; the write is refused if the page changed since.' ] ];
    return [
      'beaver_get_page' => [
        'name' => 'beaver_get_page',
        'description' => 'Read a Beaver Builder page as an outline: rows, columns and modules (heading, rich-text, photo, button...), each with its id and visible text, plus a hash. Pass node to get one node with all its settings.',
        'inputSchema' => [ 'type' => 'object', 'properties' => $post + [ 'node' => [ 'type' => 'string', 'description' => 'Optional node id.' ] ], 'required' => [ 'post_id' ] ],
        'accessLevel' => 'read',
      ],
      'beaver_update_module' => [
        'name' => 'beaver_update_module',
        'description' => 'Change settings of one Beaver Builder module: "settings" is merged into it (e.g. {"heading": "New title"} for a heading, {"text": "<p>...</p>"} for rich text, {"text": "Book now", "link": "https://..."} for a button). Read the module first with beaver_get_page and node to see its setting names. Can be undone with mcp_undo_change.',
        'inputSchema' => [ 'type' => 'object', 'properties' => $post + $hash + [
          'node' => [ 'type' => 'string', 'description' => 'The module id.' ],
          'settings' => [ 'type' => 'object', 'additionalProperties' => true ],
        ], 'required' => [ 'post_id', 'node', 'settings' ] ],
        'accessLevel' => 'write',
      ],
      'beaver_replace_text' => [
        'name' => 'beaver_replace_text',
        'description' => 'Replace text in the modules of a Beaver Builder page (or in one node and its children): every place "search" appears in their content becomes "replace". Returns the count. Can be undone with mcp_undo_change.',
        'inputSchema' => [ 'type' => 'object', 'properties' => $post + $hash + [
          'search' => [ 'type' => 'string' ], 'replace' => [ 'type' => 'string' ],
          'node' => [ 'type' => 'string', 'description' => 'Optional: only in this node and its children.' ],
        ], 'required' => [ 'post_id', 'search', 'replace' ] ],
        'accessLevel' => 'write',
      ],
      'beaver_delete_node' => [
        'name' => 'beaver_delete_node',
        'description' => 'Remove a module, column or row (and what it contains) from a Beaver Builder page. Can be undone with mcp_undo_change.',
        'inputSchema' => [ 'type' => 'object', 'properties' => $post + $hash + [ 'node' => [ 'type' => 'string' ] ], 'required' => [ 'post_id', 'node' ] ],
        'accessLevel' => 'write',
      ],
    ];
  }

  public function register_rest_tools( array $prev ): array {
    foreach ( $this->tools() as $name => $tool ) {
      $tool['annotations'] = [ 'readOnlyHint' => $tool['accessLevel'] === 'read', 'destructiveHint' => $name === 'beaver_delete_node', 'openWorldHint' => false ];
      $prev[] = $tool;
    }
    return $prev;
  }

  public function handle_call( $prev, string $tool, array $args, $id ) {
    if ( !empty( $prev ) || !isset( $this->tools()[ $tool ] ) ) {
      return $prev;
    }
    $post_id = (int) ( $args['post_id'] ?? $args['ID'] ?? 0 );
    $data = $this->layout( $post_id );
    $node = (string) ( $args['node'] ?? '' );
    if ( $node !== '' && !isset( $data[ $node ] ) ) {
      throw new Exception( "No node \"$node\" on this page. See beaver_get_page." );
    }
    switch ( $tool ) {
      case 'beaver_get_page':
        if ( $node !== '' ) {
          return [ 'node' => $node, 'type' => $data[ $node ]->type, 'settings' => $data[ $node ]->settings, 'hash' => $this->hash( $data ) ];
        }
        return [ 'post_id' => $post_id, 'hash' => $this->hash( $data ), 'outline' => $this->outline( $data ) ];

      case 'beaver_update_module':
        $this->check_hash( $data, $args );
        if ( $data[ $node ]->type !== 'module' ) {
          throw new Exception( 'Only modules have content settings; this node is a ' . $data[ $node ]->type . '.' );
        }
        $settings = is_string( $args['settings'] ?? null ) ? json_decode( $args['settings'], true ) : ( $args['settings'] ?? [] );
        foreach ( (array) $settings as $key => $value ) {
          if ( $key === 'type' ) {
            continue;
          }
          $data[ $node ]->settings->$key = is_array( $value ) ? json_decode( wp_json_encode( $value ) ) : $value;
        }
        return [ 'node' => $node ] + $this->save( $post_id, $data );

      case 'beaver_replace_text':
        $this->check_hash( $data, $args );
        $search = (string) ( $args['search'] ?? '' );
        if ( $search === '' ) {
          throw new Exception( '"search" cannot be empty.' );
        }
        $scope = $node !== '' ? $this->subtree( $data, $node ) : array_keys( $data );
        $count = 0;
        foreach ( $scope as $node_id ) {
          if ( ( $data[ $node_id ]->type ?? '' ) === 'module' ) {
            $data[ $node_id ]->settings = $this->replace_in( $data[ $node_id ]->settings, $search, (string) ( $args['replace'] ?? '' ), $count );
          }
        }
        if ( !$count ) {
          return [ 'replacements' => 0, 'saved' => false ];
        }
        return [ 'replacements' => $count ] + $this->save( $post_id, $data );

      case 'beaver_delete_node':
        $this->check_hash( $data, $args );
        foreach ( $this->subtree( $data, $node ) as $node_id ) {
          unset( $data[ $node_id ] );
        }
        return [ 'deleted' => $node ] + $this->save( $post_id, $data );
    }
    return $prev;
  }
  #endregion

  #region Undo (labs/mcp-undo.php)
  public function undo_targets( $targets, string $tool, array $a ) {
    if ( !in_array( $tool, [ 'beaver_update_module', 'beaver_replace_text', 'beaver_delete_node' ], true ) ) {
      return $targets;
    }
    $post_id = (int) ( $a['post_id'] ?? $a['ID'] ?? 0 );
    return $post_id ? [ [ 'kind' => 'beaver', 'id' => $post_id ] ] : null;
  }

  public function undo_kinds( array $kinds ): array {
    $kinds['beaver'] = [
      'read' => function ( $t ) {
        $rows = Meow_MWAI_Labs_MCP_Undo::raw_meta( (int) $t['id'], '_fl_builder_data' );
        return $rows ? $rows[0] : null;
      },
      'write' => function ( $t, $state ) {
        $data = maybe_unserialize( (string) $state );
        if ( !is_array( $data ) ) {
          throw new Exception( 'The previous version of this Beaver Builder page could not be read.' );
        }
        $this->save( (int) $t['id'], $data );
      },
      'can' => function ( $t ) { return current_user_can( 'edit_post', (int) $t['id'] ); },
      'title' => function ( $t ) { return Meow_MWAI_Labs_MCP_Undo::post_title( (int) $t['id'] ); },
    ];
    return $kinds;
  }
  #endregion
}
