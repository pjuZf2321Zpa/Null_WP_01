<?php

/**
 * @copyright © Melograno Ventures. All rights reserved.
 * @licence   See LICENCE.md for license details.
 */

namespace AmeliaBooking\Application\Commands\Activation;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class DeactivatePluginCommand
 *
 * @package AmeliaBooking\Application\Commands\Activation
 */
class DeactivatePluginCommand extends Command
{
}
