<?php

/**
 * @copyright © Melograno Ventures. All rights reserved.
 * @licence   See LICENCE.md for license details.
 */

namespace AmeliaBooking\Application\Commands\Activation;

use AmeliaBooking\Application\Commands\CommandHandler;
use AmeliaBooking\Application\Commands\CommandResult;
use AmeliaBooking\Application\Common\Exceptions\AccessDeniedException;
use AmeliaBooking\Domain\Services\Settings\SettingsService;
use AmeliaBooking\Infrastructure\WP\InstallActions\AutoUpdateHook;
use AmeliaBooking\Infrastructure\WP\UserRoles\SuperAdminRoleService;

/**
 * Class ActivatePluginCommandHandler
 *
 * @package AmeliaBooking\Application\Commands\Activation
 */
class ActivatePluginCommandHandler extends CommandHandler
{
    /**
     * @param ActivatePluginCommand $command
     *
     * @return CommandResult
     * @throws AccessDeniedException
     *
     */
    public function handle(ActivatePluginCommand $command)
    {
        $result = new CommandResult();

        /** @var SettingsService $settingsService */
        $settingsService = $this->container->get('domain.settings.service');

        $superAdminService = new SuperAdminRoleService($settingsService);

        if (!$superAdminService->canAccessActivationSettings()) {
            throw new AccessDeniedException('You are not allowed to manage activation settings.');
        }

        // Get the purchase code from query string
        $purchaseCode = trim($command->getField('params')['purchaseCodeStore']);

        // Get domain and subdomain from site URL
        $siteUrl = parse_url(AMELIA_SITE_URL, PHP_URL_HOST);
        $domain = AutoUpdateHook::getDomain($siteUrl);
        $subdomain = AutoUpdateHook::getSubDomain($siteUrl);

        // Call the Melograno Store API to check if purchase code is valid
        $ch = curl_init(
            AMELIA_STORE_API_URL . 'activation/code?slug=ameliabooking&purchaseCode=' . $purchaseCode .
            '&domain=' . $domain . '&subdomain=' . $subdomain
        );
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, apply_filters('amelia/curlopt_ssl_verifypeer', 1));

        // Response from the Melograno Store
        $curlResult = curl_exec($ch);
        $curlErrno  = curl_errno($ch);
        $curlError  = curl_error($ch);

        // Handle connection/SSL failures (curl_exec returns false on error)
        if ($curlResult === false) {
            $result->setResult(CommandResult::RESULT_SUCCESS);
            $result->setMessage('cURL request failed: ' . $curlError);
            $result->setData(
                [
                'valid'            => false,
                'domainRegistered' => false,
                'connectionError' => true,
                'curlError'       => $curlError,
                'curlErrno'       => $curlErrno,
                ]
            );

            return $result;
        }

        $response = json_decode($curlResult);

        // Update Amelia Settings
        $settingsService->setSetting('activation', 'active', $response->valid && $response->domainRegistered);

        if ($response->valid && $response->domainRegistered) {
            $settingsService->setSetting('activation', 'purchaseCodeStore', $purchaseCode);

            $currentUserId = get_current_user_id();

            if ($currentUserId) {
                if (!$settingsService->getSetting('activation', 'licenseActivatorUserId')) {
                    $settingsService->setSetting('activation', 'licenseActivatorUserId', $currentUserId);
                }

                if (!$superAdminService->grant($currentUserId)) {
                    $result->setResult(CommandResult::RESULT_ERROR);
                    $result->setMessage('Failed to assign Superadmin to the activating user.');
                    $result->setData(
                        [
                        'valid'              => $response->valid,
                        'domainRegistered'   => $response->domainRegistered,
                        'superAdminAssigned' => false,
                        ]
                    );

                    return $result;
                }
            }
        }

        $result->setResult(CommandResult::RESULT_SUCCESS);
        $result->setMessage('Successfully checked purchase code');
        $result->setData(
            [
            'valid'            => $response->valid,
            'domainRegistered' => $response->domainRegistered,
            ]
        );

        return $result;
    }
}
