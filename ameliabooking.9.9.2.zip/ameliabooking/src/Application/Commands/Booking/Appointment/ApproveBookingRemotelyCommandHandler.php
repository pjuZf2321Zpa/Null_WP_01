<?php

namespace AmeliaBooking\Application\Commands\Booking\Appointment;

use AmeliaBooking\Application\Commands\CommandHandler;
use AmeliaBooking\Application\Commands\CommandResult;
use AmeliaBooking\Application\Common\Exceptions\AccessDeniedException;
use AmeliaBooking\Application\Services\Booking\BookingFallbackService;
use AmeliaBooking\Application\Services\Helper\HelperService;
use AmeliaBooking\Application\Services\User\CustomerApplicationService;
use AmeliaBooking\Application\Services\Reservation\AppointmentReservationService;
use AmeliaBooking\Application\Services\WaitingList\WaitingListService;
use AmeliaBooking\Domain\Common\Exceptions\BookingCancellationException;
use AmeliaBooking\Domain\Common\Exceptions\BookingUnavailableException;
use AmeliaBooking\Domain\Entity\Booking\Appointment\Appointment;
use AmeliaBooking\Domain\Entity\Booking\Appointment\CustomerBooking;
use AmeliaBooking\Domain\Entity\Entities;
use AmeliaBooking\Domain\Entity\User\AbstractUser;
use AmeliaBooking\Domain\Services\Reservation\ReservationServiceInterface;
use AmeliaBooking\Domain\Services\Settings\SettingsService;
use AmeliaBooking\Domain\Common\Exceptions\InvalidArgumentException;
use AmeliaBooking\Domain\ValueObjects\String\BookingStatus;
use AmeliaBooking\Domain\ValueObjects\String\Token;
use AmeliaBooking\Infrastructure\Common\Exceptions\NotFoundException;
use AmeliaBooking\Infrastructure\Common\Exceptions\QueryExecutionException;
use AmeliaBooking\Infrastructure\Repository\Booking\Appointment\AppointmentRepository;
use AmeliaBooking\Infrastructure\Repository\Booking\Appointment\CustomerBookingRepository;
use AmeliaBooking\Infrastructure\WP\Translations\BackendStrings;
use UnexpectedValueException;

/**
 * Class ApproveBookingRemotelyCommandHandler
 *
 * @package AmeliaBooking\Application\Commands\Booking\Appointment
 */
class ApproveBookingRemotelyCommandHandler extends CommandHandler
{
    /**
     * @var array
     */
    public $mandatoryFields = [
        'token',
    ];

    /**
     * @throws UnexpectedValueException
     * @throws QueryExecutionException
     * @throws InvalidArgumentException
     * @throws AccessDeniedException
     * @throws NotFoundException
     * @throws BookingCancellationException
     * @throws BookingUnavailableException
     */
    public function handle(ApproveBookingRemotelyCommand $command): CommandResult
    {
        $this->checkMandatoryFields($command);

        $result = new CommandResult();

        $type = Entities::APPOINTMENT;

        /** @var CustomerApplicationService $customerAS */
        $customerAS = $this->container->get('application.user.customer.service');

        /** @var CustomerBookingRepository $bookingRepository */
        $bookingRepository = $this->container->get('domain.booking.customerBooking.repository');

        /** @var AbstractUser $user */
        $user = $this->container->get('logged.in.user');

        /** @var CustomerBooking $booking */
        $booking = $bookingRepository->getById((int)$command->getArg('id'));

        /** @var SettingsService $settingsService */
        $settingsService = $this->container->get('domain.settings.service');

        $notificationSettings = $settingsService->getCategorySettings('notifications');

        if ($booking === null) {
            if (!empty($notificationSettings['approveErrorUrl'])) {
                $result->setUrl($notificationSettings['approveErrorUrl']);
                return $result;
            }

            return $result->setHtml(BookingFallbackService::getFallbackHtml('failed'));
        }

        $token = $bookingRepository->getToken((int)$command->getArg('id'));

        if (!empty($token['token'])) {
            $booking->setToken(new Token($token['token']));
        }

        /** @var HelperService $helperService */
        $helperService = $this->container->get('application.helper.service');

        $requestToken = (string)$command->getField('token');

        // Stored booking token authorizes the booking's customer. Employees use the panel-secret signature.
        $isCustomer = !empty($token['token'])
            && $customerAS->isCustomerBooking($booking, $user, $requestToken);

        $isEmployee = $helperService->isEmployeeApproveToken((int)$command->getArg('id'), $requestToken);

        if (!$isCustomer && !$isEmployee) {
            throw new AccessDeniedException('You are not allowed to update booking status');
        }

        // A customer's link approves only while the booking is still on the waiting list. Once it has
        // left the list (canceled, or already promoted) the link is valid but the spot is gone for it.
        if (!$isEmployee && $booking->getStatus()->getValue() !== BookingStatus::WAITING) {
            return $this->buildWaitingListDeniedResult($result, $settingsService, $notificationSettings);
        }

        if ($booking->getStatus()->getValue() === BookingStatus::WAITING) {
            try {
                $this->validateWaitingListCapacity($booking);
            } catch (BookingCancellationException $e) {
                return $this->buildWaitingListDeniedResult($result, $settingsService, $notificationSettings);
            }
        }

        /** @var ReservationServiceInterface $reservationService */
        $reservationService = $this->container->get('application.reservation.service')->get($type);

        $status = BookingStatus::APPROVED;
        $oldBookingStatus = $booking->getStatus()->getValue();

        do_action('amelia_before_booking_approved_link', $booking ? $booking->toArray() : null);

        try {
            $bookingData = $reservationService->updateStatus($booking, $status);
        } catch (BookingUnavailableException $e) {
            // updateStatus can throw for capacity on any booking; waitlist denied redirect
            // is only appropriate when promoting a waiting-list booking.
            if ($oldBookingStatus === BookingStatus::WAITING) {
                return $this->buildWaitingListDeniedResult($result, $settingsService, $notificationSettings);
            }

            throw $e;
        }

        $result->setResult(CommandResult::RESULT_SUCCESS);
        $result->setMessage('Successfully updated booking status');
        $result->setData(
            array_merge(
                $bookingData,
                [
                    'type'    => $type,
                    'status'  => $status,
                    'message' => BackendStrings::get('appointment_status_changed') . strtolower(BackendStrings::get($status))
                ]
            )
        );

        if ($notificationSettings['approveSuccessUrl'] && $result->getResult() === CommandResult::RESULT_SUCCESS) {
            $result->setUrl($notificationSettings['approveSuccessUrl']);

            do_action('amelia_after_booking_approved_link', $booking ? $booking->toArray() : null);
            return $result;
        }

        if ($notificationSettings['approveErrorUrl'] && $result->getResult() === CommandResult::RESULT_ERROR) {
            $result->setUrl($notificationSettings['approveErrorUrl']);

            return $result;
        }
        // No redirect URL defined - show fallback page
        if ($result->getResult() === CommandResult::RESULT_SUCCESS) {
            return $result->setHtml(BookingFallbackService::getFallbackHtml('approved'));
        }
        return $result->setHtml(BookingFallbackService::getFallbackHtml('approved_with_issues'));
    }

    /**
     * Validates waiting list appointment capacity and provider availability
     *
     * @throws BookingCancellationException
     * @throws NotFoundException
     * @throws QueryExecutionException
     */
    private function validateWaitingListCapacity(CustomerBooking $booking): void
    {
        /** @var AppointmentRepository $appointmentRepo */
        $appointmentRepo = $this->container->get('domain.booking.appointment.repository');

        /** @var Appointment $appointment */
        $appointment = $appointmentRepo->getById($booking->getAppointmentId()->getValue());

        if ($appointment === null) {
            throw new NotFoundException('This appointment does not exist!');
        }

        /** @var WaitingListService $waitingListService */
        $waitingListService = $this->container->get('application.waitingList.service');

        if (!$waitingListService->canApproveWaitingBooking($appointment, $booking)) {
            throw new BookingCancellationException('This slot is already taken!');
        }

        /** @var AppointmentReservationService $reservationService */
        $reservationService = $this->container->get('application.reservation.service')->get(Entities::APPOINTMENT);

        // Capacity on this appointment can still look free after cancel, while another
        // appointment already occupies the same provider/time (e.g. original customer rebooked).
        if ($reservationService->isDoubleBooking($appointment, true)) {
            throw new BookingCancellationException('This slot is already taken!');
        }
    }

    /**
     * Redirects waitlist customers to the denied URL when the spot is no longer available.
     */
    private function buildWaitingListDeniedResult(
        CommandResult $result,
        SettingsService $settingsService,
        array $notificationSettings
    ): CommandResult {
        $appointmentSettings = $settingsService->getCategorySettings('appointments');
        $waitingListDeniedUrl = !empty($appointmentSettings['waitingListAppointments']['redirectUrlDenied']) ?
            $appointmentSettings['waitingListAppointments']['redirectUrlDenied'] : '';

        if (!empty($waitingListDeniedUrl)) {
            $result->setUrl($waitingListDeniedUrl);
            return $result;
        }

        if (!empty($notificationSettings['approveErrorUrl'])) {
            $result->setUrl($notificationSettings['approveErrorUrl']);
            return $result;
        }

        return $result->setHtml(BookingFallbackService::getFallbackHtml('failed'));
    }
}
