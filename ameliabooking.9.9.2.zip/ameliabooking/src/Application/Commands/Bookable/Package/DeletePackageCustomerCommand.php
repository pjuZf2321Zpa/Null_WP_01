<?php

/**
 * @copyright © Melograno Ventures. All rights reserved.
 * @licence   See LICENCE.md for license details.
 */

namespace AmeliaBooking\Application\Commands\Bookable\Package;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class DeletePackageCustomerCommand
 *
 * @package AmeliaBooking\Application\Commands\Bookable\Package
 */
class DeletePackageCustomerCommand extends Command
{
}
