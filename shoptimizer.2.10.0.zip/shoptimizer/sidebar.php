<?php
/**
 * The sidebar containing the main widget area.
 *
 * @package shoptimizer
 */

// Search results use their own region when it has widgets, otherwise fall back to the shop sidebar.
$shoptimizer_sidebar_id = ( is_search() && is_active_sidebar( 'sidebar-search' ) )
	? 'sidebar-search'
	: 'sidebar-1';

if ( ! is_active_sidebar( $shoptimizer_sidebar_id ) ) {
	return;
}

$shoptimizer_layout_woocommerce_sidebar	 = '';
$shoptimizer_layout_woocommerce_sidebar	 = shoptimizer_get_option( 'shoptimizer_layout_woocommerce_sidebar' );
?>

<?php if ( 'no-woocommerce-sidebar' !== $shoptimizer_layout_woocommerce_sidebar ) { ?>
<div class="secondary-wrapper">
    <div id="secondary" class="widget-area" role="complementary">
    	<?php dynamic_sidebar( $shoptimizer_sidebar_id ); ?>
    </div><!-- #secondary -->
    <button class="filters close-drawer" aria-label="Close filters">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"></path></svg>
    </button>
</div>
<?php } ?>
