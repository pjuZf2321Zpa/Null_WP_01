<?php
/**
 * Title: Minimal Background Color
 * Slug: shoptimizer/minimal-background-color
 * Description: Simple colored background with heading and text
 * Categories: shoptimizer-grid-promotions
 * Keywords: background, color, promo, guarantee
 * Viewport Width: 500
 */
?>
<!-- wp:group {"metadata":{"categories":["shoptimizer-grid-promotions"],"patternName":"shoptimizer/minimal-background-color","name":"Minimal Background Color"},"className":"shoptimizer-product-grid-ratio-box","style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}},"color":{"background":"#ae5b3d"},"spacing":{"padding":{"top":"var:preset|spacing|large","bottom":"var:preset|spacing|large","left":"var:preset|spacing|medium","right":"var:preset|spacing|medium"},"blockGap":"var:preset|spacing|small"}},"textColor":"white","layout":{"type":"default"}} -->
<div class="wp-block-group shoptimizer-product-grid-ratio-box has-white-color has-text-color has-background has-link-color" style="background-color:#ae5b3d;padding-top:var(--wp--preset--spacing--large);padding-right:var(--wp--preset--spacing--medium);padding-bottom:var(--wp--preset--spacing--large);padding-left:var(--wp--preset--spacing--medium)"><!-- wp:heading {"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white","fontSize":"medium"} -->
<h2 class="wp-block-heading has-white-color has-text-color has-link-color has-medium-font-size">60-Day Money Back Guarantee</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"spacing":{"margin":{"top":"5px"}}},"fontSize":"small"} -->
<p class="has-small-font-size" style="margin-top:5px">We believe in our products, full stop. Try them for 60 days, risk-free. If it's not right for you, we've got you covered.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->
