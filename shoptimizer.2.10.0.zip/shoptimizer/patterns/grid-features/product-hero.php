<?php
/**
 * Title: Product Hero
 * Slug: shoptimizer/product-hero
 * Description: Full-height cover image with text and button overlay
 * Categories: shoptimizer-grid-promotions
 * Keywords: hero, cover, image, button, cta
 * Viewport Width: 500
 */

if ( ! function_exists( 'shoptimizer_grid_feature_image_url' ) ) {
	return;
}
?>
<!-- wp:cover {"url":"<?php echo esc_url( shoptimizer_grid_feature_image_url( 'running_shoes.jpg' ) ); ?>","alt":"<?php esc_attr_e( 'Featured product hero banner showcasing comfortable running shoes', 'shoptimizer' ); ?>","dimRatio":0,"contentPosition":"bottom left","className":"cg-cover-gradient-bottom","style":{"spacing":{"padding":{"top":"var:preset|spacing|medium","bottom":"var:preset|spacing|medium","left":"var:preset|spacing|medium","right":"var:preset|spacing|medium"}}}} -->
<div class="wp-block-cover has-custom-content-position is-position-bottom-left cg-cover-gradient-bottom" style="padding-top:var(--wp--preset--spacing--medium);padding-right:var(--wp--preset--spacing--medium);padding-bottom:var(--wp--preset--spacing--medium);padding-left:var(--wp--preset--spacing--medium)"><span aria-hidden="true" class="wp-block-cover__background has-background-dim-0 has-background-dim"></span><img class="wp-block-cover__image-background" alt="<?php esc_attr_e( 'Featured product hero banner showcasing comfortable running shoes', 'shoptimizer' ); ?>" src="<?php echo esc_url( shoptimizer_grid_feature_image_url( 'running_shoes.jpg' ) ); ?>" data-object-fit="cover"/><div class="wp-block-cover__inner-container"><!-- wp:group {"layout":{"type":"default"}} -->
<div class="wp-block-group"><!-- wp:heading {"textAlign":"left","style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white","fontSize":"medium"} -->
<h2 class="wp-block-heading has-text-align-left has-white-color has-text-color has-link-color has-medium-font-size">All-Day Comfort</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"left","style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white","fontSize":"small"} -->
<p class="has-text-align-left has-white-color has-text-color has-link-color has-small-font-size">Engineered for training, walking, and everything between.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"layout":{"type":"flex"}} -->
<div class="wp-block-buttons"><!-- wp:button {"backgroundColor":"white","textColor":"black","width":100,"className":"is-style-fill","style":{"border":{"radius":{"topLeft":"6px","topRight":"6px","bottomLeft":"6px","bottomRight":"6px"}},"elements":{"link":{"color":{"text":"var:preset|color|black"}}},"typography":{"fontStyle":"normal","fontWeight":"700"}},"fontSize":"x-small"} -->
<div class="wp-block-button has-custom-width wp-block-button__width-100 is-style-fill"><a class="wp-block-button__link has-black-color has-white-background-color has-text-color has-background has-link-color has-x-small-font-size has-custom-font-size wp-element-button" href="#" style="border-top-left-radius:6px;border-top-right-radius:6px;border-bottom-left-radius:6px;border-bottom-right-radius:6px;font-style:normal;font-weight:700">Shop now</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --></div></div>
<!-- /wp:cover -->
