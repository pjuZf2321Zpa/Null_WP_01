<?php
/**
 * Title: Testimonial
 * Slug: shoptimizer/testimonial
 * Description: Customer testimonial with star rating and call-to-action
 * Categories: shoptimizer-grid-promotions
 * Keywords: testimonial, review, quote, stars, customer
 * Viewport Width: 500
 */

if ( ! function_exists( 'shoptimizer_grid_feature_image_url' ) ) {
	return;
}
?>
<!-- wp:cover {"url":"<?php echo esc_url( shoptimizer_grid_feature_image_url( 'boots_testimonial.jpg' ) ); ?>","alt":"<?php esc_attr_e( 'Comfortable boots', 'shoptimizer' ); ?>","dimRatio":50,"overlayColor":"black","isUserOverlayColor":true,"contentPosition":"bottom left","sizeSlug":"full","metadata":{"categories":["shoptimizer-grid-promotions"],"patternName":"shoptimizer/product-hero","name":"Testimonial"},"style":{"spacing":{"padding":{"top":"var:preset|spacing|medium","bottom":"var:preset|spacing|medium","left":"var:preset|spacing|medium","right":"var:preset|spacing|medium"},"blockGap":"0"}}} -->
<div class="wp-block-cover has-custom-content-position is-position-bottom-left" style="padding-top:var(--wp--preset--spacing--medium);padding-right:var(--wp--preset--spacing--medium);padding-bottom:var(--wp--preset--spacing--medium);padding-left:var(--wp--preset--spacing--medium)"><img class="wp-block-cover__image-background size-full" alt="<?php esc_attr_e( 'Comfortable boots', 'shoptimizer' ); ?>" src="<?php echo esc_url( shoptimizer_grid_feature_image_url( 'boots_testimonial.jpg' ) ); ?>" data-object-fit="cover"/><span aria-hidden="true" class="wp-block-cover__background has-black-background-color has-background-dim"></span><div class="wp-block-cover__inner-container"><!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|small"}},"layout":{"type":"default"}} -->
<div class="wp-block-group"><!-- wp:paragraph {"style":{"typography":{"letterSpacing":"3px"},"spacing":{"margin":{"top":"0","bottom":"10px"}},"color":{"text":"#fab01a"},"elements":{"link":{"color":{"text":"#fab01a"}}}},"fontSize":"x-small"} -->
<p class="has-text-color has-link-color has-x-small-font-size" style="color:#fab01a;margin-top:0;margin-bottom:10px;letter-spacing:3px">★★★★★</p>
<!-- /wp:paragraph -->

<!-- wp:pullquote {"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}},"typography":{"fontStyle":"normal","fontWeight":"700"},"spacing":{"margin":{"top":"0","bottom":"0"}}},"textColor":"white","fontSize":"base"} -->
<figure class="wp-block-pullquote has-white-color has-text-color has-link-color has-base-font-size" style="margin-top:0;margin-bottom:0;font-style:normal;font-weight:700"><blockquote><p>"Super comfortable, easy to slip on, and they still look sharp. I don't wear regular shoes anymore — these are my new everyday go-to."</p><cite>— Daniel</cite></blockquote></figure>
<!-- /wp:pullquote -->

<!-- wp:buttons {"style":{"spacing":{"margin":{"top":"var:preset|spacing|medium"}}},"layout":{"type":"flex"}} -->
<div class="wp-block-buttons" style="margin-top:var(--wp--preset--spacing--medium)"><!-- wp:button {"backgroundColor":"white","textColor":"black","width":100,"className":"is-style-fill","style":{"border":{"radius":{"topLeft":"6px","topRight":"6px","bottomLeft":"6px","bottomRight":"6px"}},"elements":{"link":{"color":{"text":"var:preset|color|black"}}},"typography":{"fontStyle":"normal","fontWeight":"700"}},"fontSize":"x-small"} -->
<div class="wp-block-button has-custom-width wp-block-button__width-100 is-style-fill"><a class="wp-block-button__link has-black-color has-white-background-color has-text-color has-background has-link-color has-x-small-font-size has-custom-font-size wp-element-button" href="#" style="border-top-left-radius:6px;border-top-right-radius:6px;border-bottom-left-radius:6px;border-bottom-right-radius:6px;font-style:normal;font-weight:700">Shop Shoes</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --></div></div>
<!-- /wp:cover -->
