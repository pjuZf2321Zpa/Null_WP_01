<?php
/**
 * Title: Product Hero (2 col)
 * Slug: shoptimizer/product-hero-wide
 * Description: Full-height cover image spanning 2 columns with text and button overlay
 * Categories: shoptimizer-grid-promotions
 * Keywords: hero, cover, image, button, cta, wide, 2col
 * Viewport Width: 500
 */

if ( ! function_exists( 'shoptimizer_grid_feature_image_url' ) ) {
	return;
}
?>
<!-- wp:cover {"url":"<?php echo esc_url( shoptimizer_grid_feature_image_url( 'road_running.jpg' ) ); ?>","alt":"<?php esc_attr_e( 'Product showcase featuring premium running shoes', 'shoptimizer' ); ?>","dimRatio":0,"customOverlayColor":"#9a897d","isUserOverlayColor":false,"minHeightUnit":"vh","contentPosition":"bottom left","isDark":false,"sizeSlug":"full","className":"cg-cover-gradient-bottom","style":{"color":{"duotone":"unset"},"spacing":{"padding":{"top":"var:preset|spacing|medium","bottom":"var:preset|spacing|medium","left":"var:preset|spacing|medium","right":"var:preset|spacing|medium"},"blockGap":"var:preset|spacing|small"}},"layout":{"type":"default"}} -->
<div class="wp-block-cover is-light has-custom-content-position is-position-bottom-left cg-cover-gradient-bottom" style="padding-top:var(--wp--preset--spacing--medium);padding-right:var(--wp--preset--spacing--medium);padding-bottom:var(--wp--preset--spacing--medium);padding-left:var(--wp--preset--spacing--medium)"><img class="wp-block-cover__image-background size-full" alt="<?php esc_attr_e( 'Product showcase featuring premium running shoes', 'shoptimizer' ); ?>" src="<?php echo esc_url( shoptimizer_grid_feature_image_url( 'road_running.jpg' ) ); ?>" data-object-fit="cover"/><span aria-hidden="true" class="wp-block-cover__background has-background-dim-0 has-background-dim" style="background-color:#9a897d"></span><div class="wp-block-cover__inner-container"><!-- wp:group {"layout":{"type":"default"}} -->
<div class="wp-block-group"><!-- wp:heading {"textAlign":"left","style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white","fontSize":"large"} -->
<h2 class="wp-block-heading has-text-align-left has-white-color has-text-color has-link-color has-large-font-size">Conquer Any Surface</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"left","style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white","fontSize":"small"} -->
<p class="has-text-align-left has-white-color has-text-color has-link-color has-small-font-size">From pavement to peaks, our shoes are engineered for unstoppable traction.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"layout":{"type":"flex"}} -->
<div class="wp-block-buttons"><!-- wp:button {"backgroundColor":"white","textColor":"black","className":"is-style-fill","style":{"border":{"radius":{"topLeft":"6px","topRight":"6px","bottomLeft":"6px","bottomRight":"6px"}},"elements":{"link":{"color":{"text":"var:preset|color|black"}}},"typography":{"fontStyle":"normal","fontWeight":"700"},"spacing":{"padding":{"left":"var:preset|spacing|large","right":"var:preset|spacing|large"}}},"fontSize":"x-small"} -->
<div class="wp-block-button is-style-fill"><a class="wp-block-button__link has-black-color has-white-background-color has-text-color has-background has-link-color has-x-small-font-size has-custom-font-size wp-element-button" href="#" style="border-top-left-radius:6px;border-top-right-radius:6px;border-bottom-left-radius:6px;border-bottom-right-radius:6px;padding-right:var(--wp--preset--spacing--large);padding-left:var(--wp--preset--spacing--large);font-style:normal;font-weight:700">Shop now</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --></div></div>
<!-- /wp:cover -->
