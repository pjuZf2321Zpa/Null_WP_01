<?php
/**
 * Title: Product Image Info
 * Slug: shoptimizer/product-image-info
 * Description: Product image with colored text block below
 * Categories: shoptimizer-grid-promotions
 * Keywords: image, text, product, promo
 * Viewport Width: 500
 */

if ( ! function_exists( 'shoptimizer_grid_feature_image_url' ) ) {
	return;
}
?>
<!-- wp:image {"lightbox":{"enabled":false},"scale":"cover","sizeSlug":"full","linkDestination":"custom","className":"shoptimizer-product-grid-ratio-box","style":{"spacing":{"margin":{"top":"0","bottom":"0"}}}} -->
<figure class="wp-block-image size-full shoptimizer-product-grid-ratio-box" style="margin-top:0;margin-bottom:0"><a href="#"><img src="<?php echo esc_url( shoptimizer_grid_feature_image_url( 'nyc_streetwear.jpg' ) ); ?>" alt="NYC Streetwear" style="object-fit:cover"/></a></figure>
<!-- /wp:image -->

<!-- wp:group {"metadata":{"categories":["shoptimizer-grid-promotions"],"patternName":"shoptimizer/product-image-info","name":"Product Info Block"},"style":{"elements":{"link":{"color":{"text":"var:preset|color|black"}}},"color":{"background":"#f6f3eb"},"spacing":{"padding":{"top":"var:preset|spacing|medium","bottom":"var:preset|spacing|medium","left":"var:preset|spacing|medium","right":"var:preset|spacing|medium"},"margin":{"top":"0","bottom":"0"}}},"textColor":"black","layout":{"type":"constrained","justifyContent":"left"}} -->
<div class="wp-block-group has-black-color has-text-color has-background has-link-color" style="background-color:#f6f3eb;margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--medium);padding-right:var(--wp--preset--spacing--medium);padding-bottom:var(--wp--preset--spacing--medium);padding-left:var(--wp--preset--spacing--medium)"><!-- wp:heading {"fontSize":"small"} -->
<h2 class="wp-block-heading has-small-font-size">Streetwear Edit</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"fontSize":"x-small"} -->
<p class="has-x-small-font-size"><strong>$78 Savings. </strong>Bestselling Downtown Jacket and Statement Sweater.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->
