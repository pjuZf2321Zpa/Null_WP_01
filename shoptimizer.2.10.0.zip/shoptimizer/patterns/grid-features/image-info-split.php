<?php
/**
 * Title: Image Info Split (Full width)
 * Slug: shoptimizer/image-info-split
 * Description: Full-width split layout with image on left and info box on right
 * Categories: shoptimizer-grid-promotions
 * Keywords: image, info, split, columns, full-width, promo
 * Viewport Width: 1200
 */

if ( ! function_exists( 'shoptimizer_grid_feature_image_url' ) ) {
	return;
}
?>
<!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group"><!-- wp:columns {"verticalAlignment":"center","className":"gap-0","style":{"spacing":{"padding":{"right":"0","left":"0","top":"0","bottom":"0"},"margin":{"top":"0","bottom":"0"},"blockGap":{"top":"0px","left":"0"}},"border":{"radius":{"topLeft":"0px","topRight":"0px","bottomLeft":"0px","bottomRight":"0px"}},"color":{"background":"#e4eeee"},"layout":{"selfStretch":"fit","flexSize":null}}} -->
<div class="wp-block-columns are-vertically-aligned-center gap-0 has-background" style="border-top-left-radius:0px;border-top-right-radius:0px;border-bottom-left-radius:0px;border-bottom-right-radius:0px;background-color:#e4eeee;margin-top:0;margin-bottom:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:column {"verticalAlignment":"center","width":"50%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:50%"><!-- wp:image {"scale":"cover","sizeSlug":"full","linkDestination":"none","className":"is-style-default","style":{"border":{"radius":{"topLeft":"0px","topRight":"0px","bottomLeft":"0px","bottomRight":"0px"}}}} -->
<figure class="wp-block-image size-full has-custom-border is-style-default"><img src="<?php echo esc_url( shoptimizer_grid_feature_image_url( 'group_people.jpg' ) ); ?>" alt="<?php esc_attr_e( 'Group of people wearing casual essentials', 'shoptimizer' ); ?>" style="border-top-left-radius:0px;border-top-right-radius:0px;border-bottom-left-radius:0px;border-bottom-right-radius:0px;object-fit:cover"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","style":{"spacing":{"padding":{"right":"30px","left":"30px","top":"20px","bottom":"20px"}}}} -->
<div class="wp-block-column is-vertically-aligned-center" style="padding-top:20px;padding-right:30px;padding-bottom:20px;padding-left:30px"><!-- wp:heading {"style":{"elements":{"link":{"color":{"text":"var:preset|color|black"}}},"typography":{"letterSpacing":"-0.3px"}},"textColor":"black","fontSize":"medium"} -->
<h2 class="wp-block-heading has-black-color has-text-color has-link-color has-medium-font-size" style="letter-spacing:-0.3px">Effortless layers. Elevated essentials. Because the best days aren't planned — they're lived.</h2>
<!-- /wp:heading -->

<!-- wp:buttons {"style":{"spacing":{"margin":{"top":"var:preset|spacing|medium"},"padding":{"right":"0","left":"0"}},"layout":{"selfStretch":"fit","flexSize":null}},"layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"left"}} -->
<div class="wp-block-buttons" style="margin-top:var(--wp--preset--spacing--medium);padding-right:0;padding-left:0"><!-- wp:button {"backgroundColor":"white","textColor":"black","className":"is-style-fill","style":{"border":{"radius":{"topLeft":"6px","topRight":"6px","bottomLeft":"6px","bottomRight":"6px"}},"elements":{"link":{"color":{"text":"var:preset|color|black"}}},"typography":{"fontStyle":"normal","fontWeight":"700","fontSize":"0.83rem"},"spacing":{"padding":{"left":"var:preset|spacing|medium","right":"var:preset|spacing|medium","top":"var:preset|spacing|small","bottom":"var:preset|spacing|small"}}}} -->
<div class="wp-block-button is-style-fill"><a class="wp-block-button__link has-black-color has-white-background-color has-text-color has-background has-link-color has-custom-font-size wp-element-button" href="#" style="border-top-left-radius:6px;border-top-right-radius:6px;border-bottom-left-radius:6px;border-bottom-right-radius:6px;padding-top:var(--wp--preset--spacing--small);padding-right:var(--wp--preset--spacing--medium);padding-bottom:var(--wp--preset--spacing--small);padding-left:var(--wp--preset--spacing--medium);font-size:0.83rem;font-style:normal;font-weight:700">Shop Essentials</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
