<?php
/**
 * Title: Sale Feature
 * Slug: shoptimizer/sale-feature
 * Description: Centered cover image with sale promotion text and button
 * Categories: shoptimizer-grid-promotions
 * Keywords: sale, promo, cover, centered, discount
 * Viewport Width: 500
 */

if ( ! function_exists( 'shoptimizer_grid_feature_image_url' ) ) {
	return;
}
?>
<!-- wp:cover {"url":"<?php echo esc_url( shoptimizer_grid_feature_image_url( 'mountain_opacity.jpg' ) ); ?>","alt":"<?php esc_attr_e( 'Special sale promotion banner with mountain landscape', 'shoptimizer' ); ?>","dimRatio":0,"isUserOverlayColor":true,"focalPoint":{"x":0.57,"y":0.25},"contentPosition":"center center","sizeSlug":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|medium","bottom":"var:preset|spacing|medium","left":"var:preset|spacing|medium","right":"var:preset|spacing|medium"}}}} -->
<div class="wp-block-cover" style="padding-top:var(--wp--preset--spacing--medium);padding-right:var(--wp--preset--spacing--medium);padding-bottom:var(--wp--preset--spacing--medium);padding-left:var(--wp--preset--spacing--medium)"><img class="wp-block-cover__image-background size-full" alt="<?php esc_attr_e( 'Special sale promotion banner with mountain landscape', 'shoptimizer' ); ?>" src="<?php echo esc_url( shoptimizer_grid_feature_image_url( 'mountain_opacity.jpg' ) ); ?>" style="object-position:57% 25%" data-object-fit="cover" data-object-position="57% 25%"/><span aria-hidden="true" class="wp-block-cover__background has-background-dim-0 has-background-dim"></span><div class="wp-block-cover__inner-container"><!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|small"}},"layout":{"type":"default"}} -->
<div class="wp-block-group"><!-- wp:heading {"textAlign":"center","style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white","fontSize":"x-large"} -->
<h2 class="wp-block-heading has-text-align-center has-white-color has-text-color has-link-color has-x-large-font-size">Sale</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white"} -->
<p class="has-text-align-center has-white-color has-text-color has-link-color">Your favorites, for less</p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"style":{"spacing":{"margin":{"top":"var:preset|spacing|medium","bottom":"0"}}},"layout":{"type":"flex","justifyContent":"center"}} -->
<div class="wp-block-buttons" style="margin-top:var(--wp--preset--spacing--medium);margin-bottom:0"><!-- wp:button {"backgroundColor":"white","textColor":"black","className":"is-style-fill","style":{"border":{"radius":{"topLeft":"6px","topRight":"6px","bottomLeft":"6px","bottomRight":"6px"}},"elements":{"link":{"color":{"text":"var:preset|color|black"}}},"typography":{"fontStyle":"normal","fontWeight":"700"},"spacing":{"padding":{"left":"var:preset|spacing|medium","right":"var:preset|spacing|medium"}}},"fontSize":"x-small"} -->
<div class="wp-block-button is-style-fill"><a class="wp-block-button__link has-black-color has-white-background-color has-text-color has-background has-link-color has-x-small-font-size has-custom-font-size wp-element-button" href="#" style="border-top-left-radius:6px;border-top-right-radius:6px;border-bottom-left-radius:6px;border-bottom-right-radius:6px;padding-right:var(--wp--preset--spacing--medium);padding-left:var(--wp--preset--spacing--medium);font-style:normal;font-weight:700">Shop now</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --></div></div>
<!-- /wp:cover -->
