# Contributing

## PHP linting

The repository uses PHP_CodeSniffer with the WordPress Coding Standards. Install the development dependencies with Composer, then run the documented lint gate. The launcher uses the system PHP when available and falls back to Local's bundled PHP on macOS:

```sh
composer install
composer run lint:php
```

The current gate covers `inc/woocommerce/template-functions/mini-cart.php`. To check another first-party PHP file with the same ruleset, run:

```sh
vendor/bin/phpcs --standard=phpcs.xml path/to/file.php
```

The release-critical audit target checks the staged WooCommerce, onboarding, and demo-import groups without changing files:

```sh
composer run lint:php:release-critical
```

This audit target is intentionally not the CI gate yet. It currently reports pre-existing violations in the next groups scheduled for cleanup. The V2-only WooCommerce batch may receive a narrowly scoped formatting pass when it is explicitly being reviewed, but every non-whitespace diff must be inspected and the relevant browser smoke tests rerun. Do not apply automatic formatting to the legacy WooCommerce monolith, onboarding, or importer files. Each group must be cleaned and reviewed separately before the CI gate is expanded.

The staged order is:

1. `pdp.php`.
2. `plp.php`.
3. `class-shoptimizer-load-more.php`.
4. `cart.php`.
5. `checkout.php` and `checkout-flow.php`.
6. `class-shoptimizer-grid-feature.php`.
7. `shoptimizer-woocommerce-template-functions.php`.
8. Onboarding and demo-import files.

The lower-risk follow-up group is `loop.php`, `discount.php`, `breadcrumbs.php`, `search.php`, and `search-results.php`. The `woocommerce/content-product.php` override is excluded until issue #550 is resolved.

The lint-only mini-cart cleanup intentionally does not change cart, checkout, AJAX response, or nonce behavior. Nonce enforcement is tracked separately in issue #494.
