<?php
/**
 * WP-CLI commands for Shoptimizer theme.
 *
 * @package Shoptimizer
 */

namespace Shoptimizer\Core;

use WP_CLI;
use WP_Filesystem_Direct;

/**
 * Shoptimizer theme CLI commands.
 */
class CLI {

	/**
	 * Clear Kirki's downloaded font cache.
	 *
	 * Removes:
	 *  - All downloaded font files from wp-content/fonts/
	 *  - Google Font transient caches
	 *
	 * ## EXAMPLES
	 *
	 *     # Clear all font caches
	 *     $ wp shoptimizer clear-font-cache
	 *
	 * @subcommand clear-font-cache
	 */
	public function clear_font_cache() {
		global $wpdb;

		// Include filesystem classes.
		if ( ! class_exists( 'WP_Filesystem_Base' ) ) {
			require_once ABSPATH . 'wp-admin/includes/class-wp-filesystem-base.php';
		}
		if ( ! class_exists( 'WP_Filesystem_Direct' ) ) {
			require_once ABSPATH . 'wp-admin/includes/class-wp-filesystem-direct.php';
		}

		$file_system = new WP_Filesystem_Direct( false );
		$fonts_dir   = WP_CONTENT_DIR . '/fonts';

		// Delete transients.
		$prefix         = '%transient_kirki_googlefont%';
		$prefix_timeout = '%transient_timeout_kirki_googlefont%';

		$deleted_transients = $wpdb->query(
			$wpdb->prepare(
				"DELETE FROM $wpdb->options WHERE option_name LIKE %s OR option_name LIKE %s",
				$prefix,
				$prefix_timeout
			)
		);

		// Also clear the remote URL contents transient.
		delete_transient( 'kirki_remote_url_contents' );

		// Also clear the downloaded font files option.
		delete_option( 'kirki_downloaded_font_files' );

		$file_count = 0;

		if ( is_dir( $fonts_dir ) ) {
			// Delete font files but preserve the directory structure.
			$iterator = new \RecursiveIteratorIterator(
				new \RecursiveDirectoryIterator( $fonts_dir, \RecursiveDirectoryIterator::SKIP_DOTS ),
				\RecursiveIteratorIterator::CHILD_FIRST
			);

			foreach ( $iterator as $file ) {
				$filename = $file->getFilename();

				// Skip .gitkeep files.
				if ( '.gitkeep' === $filename ) {
					continue;
				}

				if ( $file->isFile() ) {
					$file_system->delete( $file->getPathname() );
					$file_count++;
				} elseif ( $file->isDir() ) {
					// Only remove empty subdirectories (font family folders).
					@rmdir( $file->getPathname() );
				}
			}
		}

		if ( $file_count > 0 ) {
			WP_CLI::success( "Cleared font cache: $file_count font file(s) deleted." );
		} elseif ( $deleted_transients > 0 ) {
			WP_CLI::success( 'Cleared font transients (no font files found).' );
		} else {
			WP_CLI::warning( 'No font cache found.' );
		}
	}

	/**
	 * Show Shoptimizer theme information.
	 *
	 * Displays version, active features, and configuration status.
	 *
	 * ## EXAMPLES
	 *
	 *     $ wp shoptimizer info
	 *
	 * @subcommand info
	 */
	public function info() {
		$theme = wp_get_theme( 'shoptimizer' );

		WP_CLI::line( '' );
		WP_CLI::line( WP_CLI::colorize( '%G=== Shoptimizer Theme ===%n' ) );
		WP_CLI::line( '' );
		WP_CLI::line( 'Version: ' . $theme->get( 'Version' ) );
		WP_CLI::line( 'Text Domain: ' . $theme->get( 'TextDomain' ) );
		WP_CLI::line( '' );

		// Check Kirki status.
		WP_CLI::line( WP_CLI::colorize( '%BKirki Framework:%n' ) );
		if ( defined( 'KIRKI_VERSION' ) ) {
			WP_CLI::line( '   ✓ Version: ' . KIRKI_VERSION );
			WP_CLI::line( '   ✓ URL: ' . ( defined( 'KIRKI_PLUGIN_URL' ) ? KIRKI_PLUGIN_URL : 'Not defined' ) );
		} else {
			WP_CLI::line( '   - Not loaded' );
		}
		WP_CLI::line( '' );

		// Check font cache status.
		WP_CLI::line( WP_CLI::colorize( '%BFont Cache:%n' ) );
		$fonts_dir = WP_CONTENT_DIR . '/fonts';
		if ( is_dir( $fonts_dir ) ) {
			$file_count = 0;
			$total_size = 0;
			$iterator   = new \RecursiveIteratorIterator(
				new \RecursiveDirectoryIterator( $fonts_dir, \RecursiveDirectoryIterator::SKIP_DOTS ),
				\RecursiveIteratorIterator::CHILD_FIRST
			);

			foreach ( $iterator as $file ) {
				if ( $file->isFile() ) {
					$file_count++;
					$total_size += $file->getSize();
				}
			}

			WP_CLI::line( '   ✓ Directory: ' . $fonts_dir );
			WP_CLI::line( '   ✓ Files: ' . number_format( $file_count ) );
			WP_CLI::line( '   ✓ Size: ' . size_format( $total_size ) );
		} else {
			WP_CLI::line( '   - No cached fonts' );
		}
		WP_CLI::line( '' );
	}
}

