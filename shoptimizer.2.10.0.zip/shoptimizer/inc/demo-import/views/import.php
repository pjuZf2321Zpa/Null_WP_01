<?php
/**
 * The install plugins page view.
 *
 * @package CGDI
 */

$theme      = wp_get_theme();
$screenshot = $theme->get_screenshot();
$name       = $theme->name;
$plugins    = array(
	'woocommerce/woocommerce.php' => 'WooCommerce',
	'commercegurus-commercekit/commercegurus-commercekit.php' => 'CommerceKit',
	'elementor/elementor.php'     => 'Elementor',
);

$activate_plugins = array();
$install_plugins  = array();
foreach ( $plugins as $key => $value ) {
	if ( file_exists( WP_PLUGIN_DIR . '/' . $key ) && ! is_plugin_active( $key ) ) {
		$activate_plugins[ $key ] = $value;
	}
	if ( ! file_exists( WP_PLUGIN_DIR . '/' . $key ) ) {
		$install_plugins[ $key ] = $value;
	}
}
?>

<div class="cgdi cgdi--install-plugins">

	<div class="cgdi__title-container">
		<h1 class="cgdi__title-container-title"><?php esc_html_e( 'Shoptimizer Demo Data Import', 'shoptimizer' ); ?></h1>
	</div>

	<div class="cgdi__content-container">

		<div class="cgdi__admin-notices js-cgdi-admin-notices-container"></div>

		<div class="cgdi__content-container-content cgdi__demo-welcome-conent">

			<div class="cgdi__theme-about">
				<div class="cgdi__theme-about-screenshots">
					<?php if ( $screenshot ) : ?>
					<div class="screenshot"><img src="<?php echo esc_url( $screenshot ); ?>" alt="<?php esc_attr_e( 'Theme screenshot', 'one-click-demo-import' ); ?>" loading="lazy" /></div>
					<?php else : ?>
					<div class="screenshot blank"></div>
					<?php endif; ?>
				</div>

				<div class="cgdi__theme-about-info">
					<div class="top-content">
						<div class="theme-title">
							<h2 class="theme-name"><?php echo esc_html( $theme->name ); ?></h2>
							<span class="theme-version">
								<?php
								/* translators: %s: Theme version. */
								printf( __( 'Version: %s' ), esc_html( $theme->version ) );
								?>
							</span>
						</div>
						<p class="theme-author">
							<?php
							/* translators: %s: Theme author link. */
							printf( __( 'By %s' ), wp_kses_post( $theme->author ) );
							?>
						</p>

						<p class="theme-description"><?php echo wp_kses_post( $theme->description ); ?></p>

						<?php if ( ! empty( $theme->tags ) ) : ?>
						<hr>
						<p class="theme-tags"><span><?php esc_html_e( 'Tags:' ); ?></span> <?php echo esc_html( implode( ', ', $theme->tags ) ); ?></p>
						<?php endif; ?>
					</div>
				</div>
			</div>

			<?php if ( count( $install_plugins ) || count( $activate_plugins ) ) { ?>
			<div class="cgdi__theme-demo-data">
				<h2><?php esc_html_e( 'Before We Import Demo Data', 'shoptimizer' ); ?></h2>
				<?php if ( count( $install_plugins ) ) { ?>
				<p><?php esc_html_e( 'Installing the following plugins is required.', 'shoptimizer' ); ?></p>
				<div class="notice notice-error">
					<p class="cgdi-install-plugins-error"><span><?php echo implode( ', ', $install_plugins ); ?></span><a class="cgdi-install-plugins button button-primary" href="<?php echo esc_url( admin_url( 'themes.php?page=tgmpa-install-plugins' ) ); ?>"><?php esc_html_e( 'Install Plugins', 'shoptimizer' ); ?></a></p>
				</div>
				<?php } ?>
				<?php if ( count( $activate_plugins ) ) { ?>
				<p><?php esc_html_e( 'Activating the following plugins is required.', 'shoptimizer' ); ?></p>
				<div class="notice notice-warning">
					<p class="cgdi-install-plugins-error"><span><?php echo implode( ', ', $activate_plugins ); ?></span><a class="cgdi-install-plugins button button-primary" href="<?php echo esc_url( admin_url( 'themes.php?page=tgmpa-install-plugins' ) ); ?>"><?php esc_html_e( 'Activate Plugins', 'shoptimizer' ); ?></a></p>
				</div>
				<?php } ?>
			</div>
			<?php } else { ?>
			<p class="cgdi__button-container">
				<a href="#" class="button button-primary js-cgdi-import-button" data-type="default"><?php esc_html_e( 'Import Demo Data', 'shoptimizer' ); ?></a>
			</p>
			<?php } ?>
		</div>
		<div class="cgdi__content-container-content cgdi__demo-importing-conent">
			<div class="cgdi__content-container-content--main">

				<div class="cgdi-importing js-cgdi-importing">
					<div class="cgdi-importing-header">
						<h2><?php esc_html_e( 'Importing Content', 'shoptimizer' ); ?></h2>
						<p><?php esc_html_e( 'Please sit tight while we import your content. Do not refresh the page or hit the back button.', 'shoptimizer' ); ?></p>
					</div>
					<div class="cgdi-importing-content">
						<img class="cgdi-importing-content-importing" src="<?php echo esc_url( CGDI_URL . 'assets/images/importing.svg' ); ?>" alt="<?php esc_attr_e( 'Importing animation', 'shoptimizer' ); ?>">
					</div>
				</div>

				<div class="cgdi-imported js-cgdi-imported">
					<div class="cgdi-imported-header">
						<h2 class="js-cgdi-ajax-response-title"><?php esc_html_e( 'Import Complete!', 'shoptimizer' ); ?></h2>
						<div class="js-cgdi-ajax-response-subtitle">
							<p>
								<?php esc_html_e( 'Congrats, your demo was imported successfully. You can now begin editing your site.', 'shoptimizer' ); ?>
							</p>
						</div>
					</div>
					<div class="cgdi-imported-content">
						<div class="cgdi__response  js-cgdi-ajax-response"></div>
					</div>
					<div class="cgdi-imported-footer">
						<?php
						echo wp_kses(
							$this->get_import_successful_buttons_html(),
							array(
								'a' => array(
									'href'   => array(),
									'class'  => array(),
									'target' => array(),
								),
							)
						);
						?>
					</div>
				</div>
			</div>
			<div class="cgdi__content-container-content--side">
				<div class="cgdi__card cgdi__card--theme">
					<div class="cgdi__card-content">
						<?php if ( $screenshot ) : ?>
							<div class="screenshot"><img src="<?php echo esc_url( $screenshot ); ?>" alt="<?php esc_attr_e( 'Theme screenshot', 'shoptimizer' ); ?>" /></div>
						<?php else : ?>
							<div class="screenshot blank"></div>
						<?php endif; ?>
					</div>
					<div class="cgdi__card-footer">
						<h3><?php esc_attr_e( 'Shoptimizer Demo Data', 'shoptimizer' ); ?></h3>
					</div>
				</div>
			</div>
		</div>

	</div>
</div>
