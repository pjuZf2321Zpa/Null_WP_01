jQuery( function ( $ ) {
	'use strict';

	var $importType = 'default';
	$( '.button.js-cgdi-import-button' ).on( 'click', function ( event ) {
		event.preventDefault();
		var $button = $( this );
		if ( $button.hasClass( 'cgdi-button-disabled' ) ) {
			return false;
		}
		$( '.button.js-cgdi-import-button' ).addClass( 'cgdi-button-disabled' );
		$importType = $button.data( 'type' );
		startImport( $importType );
	} );

	function ajaxCall( data ) {
		$.ajax( {
			method:      'POST',
			url:         cgdi.ajax_url,
			data:        data,
			contentType: false,
			processData: false,
			beforeSend:  function() {
				$( '.cgdi__demo-welcome-conent' ).hide();
				$( '.cgdi__demo-importing-conent' ).addClass( 'active' );
				$( '.js-cgdi-importing' ).show();
			}
		}).done( function( response ) {
			if ( 'undefined' !== typeof response.status && 'newAJAX' === response.status ) {
				ajaxCall( data );
			} else if ( 'undefined' !== typeof response.status && 'afterAllImportAJAX' === response.status ) {
				var newData = new FormData();
				newData.append( 'action', 'cgdi_after_import_data' );
				newData.append( 'security', cgdi.ajax_nonce );
				newData.append( 'import_type', $importType );
				ajaxCall( newData );
			} else if ( 'undefined' !== typeof response.message ) {
				$( '.js-cgdi-ajax-response' ).append( response.message );

				if ( 'undefined' !== typeof response.title ) {
					$( '.js-cgdi-ajax-response-title' ).html( response.title );
				}

				if ( 'undefined' !== typeof response.subtitle ) {
					$( '.js-cgdi-ajax-response-subtitle' ).html( response.subtitle );
				}

				$( '.js-cgdi-importing' ).hide();
				$( '.js-cgdi-imported' ).show();

				$( document ).trigger( 'cgdiImportComplete' );
			} else {
				$( '.js-cgdi-ajax-response' ).append( '<img class="cgdi-imported-content-imported cgdi-imported-content-imported--error" src="' + cgdi.plugin_url + 'assets/images/error.svg" alt="' + cgdi.texts.import_failed + '"><p>' + response + '</p>' );
				$( '.js-cgdi-ajax-response-title' ).html( cgdi.texts.import_failed );
				$( '.js-cgdi-ajax-response-subtitle' ).html( '<p>' + cgdi.texts.import_failed_subtitle + '</p>' );
				$( '.js-cgdi-importing' ).hide();
				$( '.js-cgdi-imported' ).show();
			}
		}).fail( function( error ) {
			$( '.js-cgdi-ajax-response' ).append( '<img class="cgdi-imported-content-imported cgdi-imported-content-imported--error" src="' + cgdi.plugin_url + 'assets/images/error.svg" alt="' + cgdi.texts.import_failed + '"><p>Error: ' + error.statusText + ' (' + error.status + ')' + '</p>' );
			$( '.js-cgdi-ajax-response-title' ).html( cgdi.texts.import_failed );
			$( '.js-cgdi-ajax-response-subtitle' ).html( '<p>' + cgdi.texts.import_failed_subtitle + '</p>' );
			$( '.js-cgdi-importing' ).hide();
			$( '.js-cgdi-imported' ).show();
		});
	}

	function startImport( import_type ) {
		var data = new FormData();
		data.append( 'action', 'cgdi_import_demo_data' );
		data.append( 'security', cgdi.ajax_nonce );

		if ( import_type ) {
			data.append( 'import_type', import_type );
		}

		ajaxCall( data );
	}
} );
