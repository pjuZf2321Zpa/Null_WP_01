<?php
/**
 * Class for the import actions used in the Shoptimizer Demo Import plugin.
 * Register default WP actions for CGDI plugin.
 *
 * @package CGDI
 */

// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedClassFound -- Public importer class name is part of the existing demo-import integration contract.
class CGDI_ImportActions {
	/**
	 * Register all action hooks for this class.
	 */
	public function register_hooks() {
		// Before content import.
		add_action( 'cgdi/before_content_import_execution', array( $this, 'before_content_import_action' ), 10, 3 );

		// After content import.
		add_action( 'cgdi/after_content_import_execution', array( $this, 'before_widget_import_action' ), 10, 3 );
		add_action( 'cgdi/after_content_import_execution', array( $this, 'widgets_import' ), 20, 3 );
		add_action( 'cgdi/after_content_import_execution', array( $this, 'wpforms_import' ), 40, 3 );

		// After full import action.
		add_action( 'cgdi/after_all_import_execution', array( $this, 'after_import_action' ), 10, 3 );

		// Special widget import cases.
		if ( CGDI_Helpers::apply_filters( 'cgdi/enable_custom_menu_widget_ids_fix', true ) ) {
			add_action( 'cgdi/widget_settings_array', array( $this, 'fix_custom_menu_widget_ids' ) );
		}
	}


	/**
	 * Change the menu IDs in the custom menu widgets in the widget import data.
	 * This solves the issue with custom menu widgets not having the correct (new) menu ID, because they
	 * have the old menu ID from the export site.
	 *
	 * @since 3.4.0 Made sure `$widget` is an array.
	 *
	 * @param array $widget The widget settings array.
	 */
	public function fix_custom_menu_widget_ids( $widget ) {

		// Make sure the passed variable is an array to prevent fatal error.
		if ( ! is_array( $widget ) ) {
			$widget = array();
		}

		// Skip (no changes needed), if this is not a custom menu widget.
		if ( ! array_key_exists( 'nav_menu', $widget ) || empty( $widget['nav_menu'] ) || ! is_int( $widget['nav_menu'] ) ) {
			return $widget;
		}

		// Get import data, with new menu IDs.
		$cgdi                = Shoptimizer_Demo_Import::get_instance();
		$content_import_data = $cgdi->importer->get_importer_data();
		$term_ids            = $content_import_data['mapping']['term_id'];

		// Set the new menu ID for the widget.
		$widget['nav_menu'] = $term_ids[ $widget['nav_menu'] ];

		return $widget;
	}


	/**
	 * Execute the widgets import.
	 *
	 * @param array $selected_import_files Actual selected import files (content, widgets).
	 * @param array $import_files          The filtered import files.
	 * @param int   $selected_index        Selected index of import.
	 */
	public function widgets_import( $selected_import_files, $import_files, $selected_index ) {
		if ( ! empty( $selected_import_files['widgets'] ) ) {
			CGDI_WidgetImporter::import( $selected_import_files['widgets'] );
		}
	}

	/**
	 * Execute the WPForms import.
	 *
	 * @param array $selected_import_files Actual selected import files (content, widgets).
	 * @param array $import_files          The filtered import files.
	 * @param int   $selected_index        Selected index of import.
	 */
	public function wpforms_import( $selected_import_files, $import_files, $selected_index ) {
		if ( ! empty( $selected_import_files['wpforms'] ) ) {
			( new CGDI_WPFormsImporter( $selected_import_files['wpforms'] ) )->import();
		}
	}

	/**
	 * Execute the action: 'cgdi/before_content_import'.
	 *
	 * @param array $selected_import_files Actual selected import files (content, widgets).
	 * @param array $import_files          The filtered import files.
	 * @param int   $selected_index        Selected index of import.
	 */
	public function before_content_import_action( $selected_import_files, $import_files, $selected_index ) {
		$this->do_import_action( 'cgdi/before_content_import', $import_files[ $selected_index ] );
	}


	/**
	 * Execute the action: 'cgdi/before_widgets_import'.
	 *
	 * @param array $selected_import_files Actual selected import files (content, widgets).
	 * @param array $import_files          The filtered import files.
	 * @param int   $selected_index        Selected index of import.
	 */
	public function before_widget_import_action( $selected_import_files, $import_files, $selected_index ) {
		$this->do_import_action( 'cgdi/before_widgets_import', $import_files[ $selected_index ] );
	}


	/**
	 * Execute the action: 'cgdi/after_import'.
	 *
	 * @param array $selected_import_files Actual selected import files (content, widgets).
	 * @param array $import_files          The filtered import files.
	 * @param int   $selected_index        Selected index of import.
	 */
	public function after_import_action( $selected_import_files, $import_files, $selected_index ) {
		$this->do_import_action( 'cgdi/after_import', $import_files[ $selected_index ] );
	}


	/**
	 * Register the do_action hook, so users can hook to these during import.
	 *
	 * @param string $action          The action name to be executed.
	 * @param array  $selected_import The data of selected import files.
	 */
	private function do_import_action( $action, $selected_import ) {
		if ( false !== CGDI_Helpers::has_action( $action ) ) {
			$cgdi          = Shoptimizer_Demo_Import::get_instance();
			$log_file_path = $cgdi->get_log_file_path();

			ob_start();
				CGDI_Helpers::do_action( $action, $selected_import );
			$message = ob_get_clean();

			// Add this message to log file.
			$log_added = CGDI_Helpers::append_to_file(
				$message,
				$log_file_path,
				$action
			);
		}
	}
}
