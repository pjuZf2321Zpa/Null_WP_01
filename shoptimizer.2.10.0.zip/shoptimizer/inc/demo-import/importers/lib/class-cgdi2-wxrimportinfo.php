<?php
/**
 * Import metadata container for CGDI.
 *
 * @package CGDI
 */

// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedClassFound -- Public importer data class name is part of the existing demo-import integration contract.
class CGDI2_WXRImportInfo {
	public $home;
	public $siteurl;
	public $title;
	public $users         = array();
	public $post_count    = 0;
	public $media_count   = 0;
	public $comment_count = 0;
	public $term_count    = 0;
	public $generator     = '';
	public $version;
}
