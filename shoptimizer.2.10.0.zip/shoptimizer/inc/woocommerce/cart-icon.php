<?php
/**
 * Shared cart icon sanitization and rendering helpers.
 *
 * @package Shoptimizer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'shoptimizer_custom_cart_svg_style_properties' ) ) {
	/**
	 * Limit inline SVG styles to presentation properties used by icons.
	 *
	 * This callback is attached only while sanitizing a custom cart SVG.
	 *
	 * @param array $properties Existing safe CSS properties.
	 * @return array
	 */
	function shoptimizer_custom_cart_svg_style_properties( $properties ) {
		unset( $properties );

		return array(
			'fill',
			'fill-opacity',
			'fill-rule',
			'opacity',
			'paint-order',
			'stroke',
			'stroke-dasharray',
			'stroke-dashoffset',
			'stroke-linecap',
			'stroke-linejoin',
			'stroke-miterlimit',
			'stroke-opacity',
			'stroke-width',
			'vector-effect',
		);
	}
}

if ( ! function_exists( 'shoptimizer_custom_cart_svg_allowed_html' ) ) {
	/**
	 * Return the SVG elements and attributes supported by custom cart icons.
	 *
	 * @return array
	 */
	function shoptimizer_custom_cart_svg_allowed_html() {
		$presentation_attributes = array(
			'class'             => true,
			'fill'              => true,
			'fill-opacity'      => true,
			'fill-rule'         => true,
			'opacity'           => true,
			'paint-order'       => true,
			'shape-rendering'   => true,
			'stroke'            => true,
			'stroke-dasharray'  => true,
			'stroke-dashoffset' => true,
			'stroke-linecap'    => true,
			'stroke-linejoin'   => true,
			'stroke-miterlimit' => true,
			'stroke-opacity'    => true,
			'stroke-width'      => true,
			'style'             => true,
			'transform'         => true,
			'vector-effect'     => true,
		);

		return array(
			'svg'      => array_merge(
				$presentation_attributes,
				array(
					'aria-hidden'         => true,
					'focusable'           => true,
					'height'              => true,
					'preserveaspectratio' => true,
					'role'                => true,
					'viewbox'             => true,
					'width'               => true,
					'xmlns'               => true,
				)
			),
			'g'        => $presentation_attributes,
			'path'     => array_merge(
				$presentation_attributes,
				array(
					'd'          => true,
					'pathlength' => true,
				)
			),
			'circle'   => array_merge(
				$presentation_attributes,
				array(
					'cx' => true,
					'cy' => true,
					'r'  => true,
				)
			),
			'rect'     => array_merge(
				$presentation_attributes,
				array(
					'height' => true,
					'rx'     => true,
					'ry'     => true,
					'width'  => true,
					'x'      => true,
					'y'      => true,
				)
			),
			'line'     => array_merge(
				$presentation_attributes,
				array(
					'x1' => true,
					'x2' => true,
					'y1' => true,
					'y2' => true,
				)
			),
			'polyline' => array_merge( $presentation_attributes, array( 'points' => true ) ),
			'polygon'  => array_merge( $presentation_attributes, array( 'points' => true ) ),
			'ellipse'  => array_merge(
				$presentation_attributes,
				array(
					'cx' => true,
					'cy' => true,
					'rx' => true,
					'ry' => true,
				)
			),
		);
	}
}

if ( ! function_exists( 'shoptimizer_sanitize_custom_cart_svg' ) ) {
	/**
	 * Sanitize a complete inline SVG supplied through the Customizer.
	 *
	 * @param mixed $svg Customizer value.
	 * @return string
	 */
	function shoptimizer_sanitize_custom_cart_svg( $svg ) {
		if ( ! is_string( $svg ) ) {
			return '';
		}

		$svg = trim( $svg );

		if ( '' === $svg || 100000 < strlen( $svg ) || preg_match( '/<!ENTITY/i', $svg ) ) {
			return '';
		}

		$svg = preg_replace( '/^\xEF\xBB\xBF/', '', $svg );
		$svg = preg_replace( '/<\?xml[^>]*\?>/i', '', $svg );
		$svg = preg_replace( '/<!--.*?-->/s', '', $svg );
		$svg = preg_replace( '/<!DOCTYPE[^>]*>/is', '', $svg );
		$svg = trim( $svg );

		if ( ! preg_match( '/^<svg\b[^>]*>.*<\/svg>$/is', $svg ) ) {
			return '';
		}

		add_filter( 'safe_style_css', 'shoptimizer_custom_cart_svg_style_properties' );
		$sanitized_svg = wp_kses( $svg, shoptimizer_custom_cart_svg_allowed_html() );
		remove_filter( 'safe_style_css', 'shoptimizer_custom_cart_svg_style_properties' );

		// SVG text elements are not supported, so discard inert text left by stripped wrappers.
		$sanitized_svg = preg_replace( '/>[^<]+</', '><', $sanitized_svg );
		$sanitized_svg = trim( $sanitized_svg );

		if (
			1 !== substr_count( strtolower( $sanitized_svg ), '<svg' ) ||
			! preg_match( '/^<svg\b[^>]*>.*<\/svg>$/is', $sanitized_svg ) ||
			! preg_match( '/<(?:path|circle|rect|line|polyline|polygon|ellipse)\b/i', $sanitized_svg ) ||
			preg_match( '/(?:url\s*\(|javascript\s*:|data\s*:|@import|expression\s*\()/i', $sanitized_svg )
		) {
			return '';
		}

		$sanitized_svg = preg_replace_callback(
			'/<svg\b([^>]*)>/i',
			function ( $matches ) {
				$attributes = preg_replace(
					'/\s+(?:aria-hidden|focusable|role)\s*=\s*(?:"[^"]*"|\'[^\']*\'|[^\s>]+)/i',
					'',
					$matches[1]
				);

				return '<svg' . $attributes . ' aria-hidden="true" focusable="false" role="presentation">';
			},
			$sanitized_svg,
			1
		);

		return is_string( $sanitized_svg ) ? $sanitized_svg : '';
	}
}

if ( ! function_exists( 'shoptimizer_sanitize_custom_cart_icon_style' ) ) {
	/**
	 * Sanitize the explicit paint mode selected for a custom cart icon.
	 *
	 * @param mixed $style Customizer value.
	 * @return string
	 */
	function shoptimizer_sanitize_custom_cart_icon_style( $style ) {
		$allowed_styles = array( 'stroke', 'fill', 'preserve' );

		return in_array( $style, $allowed_styles, true ) ? $style : 'preserve';
	}
}

if ( ! function_exists( 'shoptimizer_get_cart_icon_markup' ) ) {
	/**
	 * Return the selected cart icon and count markup.
	 *
	 * @param mixed $icon_style    Selected built-in/custom icon.
	 * @param mixed $display_count Cart item count.
	 * @return string
	 */
	function shoptimizer_get_cart_icon_markup( $icon_style, $display_count ) {
		$icon_style    = is_string( $icon_style ) ? $icon_style : 'basket';
		$display_count = esc_html( (string) $display_count );

		if ( 'cart' === $icon_style ) {
			$svg = '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true" focusable="false" role="presentation"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" /></svg>';

			return '<span class="shoptimizer-cart-icon shoptimizer-cart-icon--builtin shoptimizer-cart-icon--stroke">' . $svg . '<span class="mini-count">' . $display_count . '</span></span>';
		}

		if ( 'bag' === $icon_style ) {
			$svg = '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true" focusable="false" role="presentation"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" /></svg>';

			return '<span class="shoptimizer-cart-icon shoptimizer-cart-icon--builtin shoptimizer-cart-icon--stroke">' . $svg . '<span class="mini-count">' . $display_count . '</span></span>';
		}

		if ( 'custom' === $icon_style ) {
			$svg = shoptimizer_sanitize_custom_cart_svg(
				shoptimizer_get_option( 'shoptimizer_layout_woocommerce_custom_cart_icon_svg' )
			);

			if ( '' !== $svg ) {
				$custom_style = shoptimizer_sanitize_custom_cart_icon_style(
					shoptimizer_get_option( 'shoptimizer_layout_woocommerce_custom_cart_icon_style' )
				);

				return '<span class="shoptimizer-cart-icon shoptimizer-cart-icon--custom shoptimizer-cart-icon--' . esc_attr( $custom_style ) . '">' . $svg . '<span class="mini-count">' . $display_count . '</span></span>';
			}
		}

		return '<span class="count">' . $display_count . '</span>';
	}
}
