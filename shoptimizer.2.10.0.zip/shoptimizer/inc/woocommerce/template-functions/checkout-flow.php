<?php
/**
 * Checkout Flow specific template functions and hooks
 *
 * @package shoptimizer
 *
 * Function Index:
 * - shoptimizer_cart_progress() - Displays checkout progress bar on cart and checkout pages
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! function_exists( 'shoptimizer_get_progress_bar_label' ) ) {
	/**
	 * Resolve the visible label for a progress bar step.
	 *
	 * Returns the merchant's custom Customizer label when the "Customize
	 * progress bar labels" toggle is enabled and a value has been entered.
	 * Otherwise it falls back to the existing translatable gettext string, so
	 * existing gettext/WPML/Polylang translations of the original labels keep
	 * working when the new fields are left empty.
	 *
	 * Custom values are read with get_theme_mod() (singular) so the
	 * theme_mod_{key} filter registered in class-shoptimizer-translations.php
	 * fires, allowing WPML/Polylang to translate custom label values.
	 *
	 * @since 1.0.0
	 * @param string $step One of 'cart', 'checkout', 'confirmation'.
	 * @return string The resolved, human-readable step label.
	 */
	function shoptimizer_get_progress_bar_label( string $step ): string {
		switch ( $step ) {
			case 'cart':
				$mod_key  = 'shoptimizer_layout_progress_bar_cart_label';
				$fallback = __( 'Shopping Cart', 'shoptimizer' );
				break;
			case 'checkout':
				$mod_key  = 'shoptimizer_layout_progress_bar_checkout_label';
				$fallback = __( 'Shipping and Checkout', 'shoptimizer' );
				break;
			case 'confirmation':
				$mod_key  = 'shoptimizer_layout_progress_bar_confirmation_label';
				$fallback = __( 'Confirmation', 'shoptimizer' );
				break;
			default:
				return '';
		}

		// Only honour custom labels when the reveal toggle is enabled.
		if ( shoptimizer_get_option( 'shoptimizer_layout_progress_bar_custom_labels' ) ) {
			// Singular get_theme_mod() so the translation filter can run.
			$custom = (string) get_theme_mod( $mod_key, '' );

			if ( '' !== trim( $custom ) ) {
				return $custom;
			}
		}

		return $fallback;
	}
}

/**
 * Add Progress Bar to the Cart and Checkout pages.
 */
add_action( 'woocommerce_before_cart', 'shoptimizer_cart_progress' );
add_action( 'woocommerce_before_checkout_form', 'shoptimizer_cart_progress', 5 );

if ( ! function_exists( 'shoptimizer_cart_progress' ) ) {
	/**
	 * Displays a progress bar for the checkout process.
	 * Shows current step (Cart, Shipping/Checkout, Confirmation).
	 * Only displays if enabled in theme options.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function shoptimizer_cart_progress(): void {
		$shoptimizer_layout_progress_bar_display = shoptimizer_get_option( 'shoptimizer_layout_progress_bar_display' );

		if ( true === $shoptimizer_layout_progress_bar_display ) {
			$current_page = is_cart() ? 'cart' : ( is_checkout() ? 'checkout' : '' );

			// Resolve visible labels once so markup and aria labels stay in sync.
				$cart_label         = shoptimizer_get_progress_bar_label( 'cart' );
				$checkout_label     = shoptimizer_get_progress_bar_label( 'checkout' );
				$confirmation_label = shoptimizer_get_progress_bar_label( 'confirmation' );
				$cart_aria_label    = 'cart' === $current_page
					? sprintf(
						/* translators: %s: progress bar step name, e.g. Shopping Cart. */
						__( '%s, current step', 'shoptimizer' ),
						$cart_label
					)
					: sprintf(
						/* translators: %s: progress bar step name, e.g. Shopping Cart. */
						__( 'Return to %s', 'shoptimizer' ),
						$cart_label
					);
				$checkout_aria_label = 'checkout' === $current_page
					? sprintf(
						/* translators: %s: progress bar step name, e.g. Shipping and Checkout. */
						__( '%s, current step', 'shoptimizer' ),
						$checkout_label
					)
					: sprintf(
						/* translators: %s: progress bar step name, e.g. Shipping and Checkout. */
						__( 'Proceed to %s', 'shoptimizer' ),
						$checkout_label
					);
			?>
			<div class="checkout-wrap"
				role="navigation"
				aria-label="<?php esc_attr_e( 'Checkout Progress', 'shoptimizer' ); ?>"
				aria-live="polite">
				<!-- Add overall progress -->
				<span class="screen-reader-text">
					<?php
					printf(
						/* translators: %s: current step */
						esc_html__( 'Currently on step %s of 3', 'shoptimizer' ),
						'cart' === $current_page ? '1' : ( 'checkout' === $current_page ? '2' : '3' )
					);
					?>
				</span>
				<ul class="checkout-bar" role="list">
					<li class="active first" aria-current="<?php echo 'cart' === $current_page ? 'step' : 'false'; ?>">
						<span>
								<a href="<?php echo esc_url( get_permalink( wc_get_page_id( 'cart' ) ) ); ?>"
									aria-label="<?php echo esc_attr( $cart_aria_label ); ?>">
								<?php echo esc_html( $cart_label ); ?>
							</a>
						</span>
					</li>
					<li class="next" aria-current="<?php echo 'checkout' === $current_page ? 'step' : 'false'; ?>">
						<span>
								<a href="<?php echo esc_url( get_permalink( wc_get_page_id( 'checkout' ) ) ); ?>"
									aria-label="<?php echo esc_attr( $checkout_aria_label ); ?>">
								<?php echo esc_html( $checkout_label ); ?>
							</a>
						</span>
					</li>
					<li aria-current="false">
						<span>
							<?php echo esc_html( $confirmation_label ); ?>
						</span>
					</li>
				</ul>
			</div>
			<?php
		}
	}
}
