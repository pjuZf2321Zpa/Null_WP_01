<?php
/**
 * Shared sale badge helpers.
 *
 * @package shoptimizer
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! function_exists( 'shoptimizer_get_sale_badge_display_mode' ) ) {
	/**
	 * Get the configured sale badge content mode.
	 *
	 * @return string Either percentage or amount.
	 */
	function shoptimizer_get_sale_badge_display_mode(): string {
		$mode = shoptimizer_get_option( 'shoptimizer_layout_woocommerce_display_badge_content' );

		return 'amount' === $mode ? 'amount' : 'percentage';
	}
}

if ( ! function_exists( 'shoptimizer_get_sale_badge_prefix' ) ) {
	/**
	 * Get the configured prefix for amount-based sale badges.
	 *
	 * @return string Sale badge prefix, which may be empty.
	 */
	function shoptimizer_get_sale_badge_prefix(): string {
		$prefix = shoptimizer_get_option( 'shoptimizer_layout_woocommerce_display_badge_prefix' );
		$prefix = is_string( $prefix ) ? trim( $prefix ) : '';

		return $prefix;
	}
}

if ( ! function_exists( 'shoptimizer_format_sale_badge_amount' ) ) {
	/**
	 * Format an amount for display inside a sale badge.
	 *
	 * @param float $amount Amount saved.
	 * @return string Formatted amount without WooCommerce markup.
	 */
	function shoptimizer_format_sale_badge_amount( float $amount ): string {
		return trim( wp_specialchars_decode( wp_strip_all_tags( wc_price( $amount ) ) ) );
	}
}

if ( ! function_exists( 'shoptimizer_format_sale_badge_amount_label' ) ) {
	/**
	 * Format a complete amount-based sale badge label.
	 *
	 * @param float $amount Amount saved.
	 * @return string Sale badge label.
	 */
	function shoptimizer_format_sale_badge_amount_label( float $amount ): string {
		$prefix = shoptimizer_get_sale_badge_prefix();
		$amount = shoptimizer_format_sale_badge_amount( $amount );

		if ( '' === $prefix ) {
			return $amount;
		}

		return '-' === $prefix ? $prefix . $amount : $prefix . ' ' . $amount;
	}
}

if ( ! function_exists( 'shoptimizer_format_sale_badge_percentage_label' ) ) {
	/**
	 * Format a percentage-based sale badge label.
	 *
	 * @param int $percentage Discount percentage without the percent sign.
	 * @return string Formatted percentage label.
	 */
	function shoptimizer_format_sale_badge_percentage_label( int $percentage ): string {
		return sprintf(
			/* translators: %s: discount percentage number, without the percent sign. */
			__( '-%s%%', 'shoptimizer' ),
			$percentage
		);
	}
}

if ( ! function_exists( 'shoptimizer_get_sale_badge_amount_from_prices' ) ) {
	/**
	 * Get the largest saving represented by a variation price array.
	 *
	 * @param array $prices WooCommerce variation prices.
	 * @return float Largest amount saved.
	 */
	function shoptimizer_get_sale_badge_amount_from_prices( array $prices ): float {
		$saved_amount = 0.0;

		if ( empty( $prices['regular_price'] ) || empty( $prices['sale_price'] ) ) {
			return $saved_amount;
		}

		foreach ( $prices['regular_price'] as $key => $regular_price ) {
			if ( ! array_key_exists( $key, $prices['sale_price'] ) || '' === $prices['sale_price'][ $key ] ) {
				continue;
			}

			$regular_price = (float) $regular_price;
			$sale_price    = (float) $prices['sale_price'][ $key ];

			if ( $regular_price > 0.005 && $sale_price < $regular_price ) {
				$saved_amount = max( $saved_amount, $regular_price - $sale_price );
			}
		}

		return $saved_amount;
	}
}

if ( ! function_exists( 'shoptimizer_get_sale_badge_amount' ) ) {
	/**
	 * Get the amount saved for a product.
	 *
	 * Variable products use the largest saving among their variations, matching
	 * the existing percentage badge behavior.
	 *
	 * @param WC_Product $product Product object.
	 * @return float Amount saved.
	 */
	function shoptimizer_get_sale_badge_amount( WC_Product $product ): float {
		if ( $product->is_type( 'variable' ) ) {
			return shoptimizer_get_sale_badge_amount_from_prices( $product->get_variation_prices() );
		}

		$regular_price = (float) $product->get_regular_price();
		$sale_price    = $product->get_sale_price();

		if ( '' === $sale_price ) {
			return 0.0;
		}

		$sale_price = (float) $sale_price;

		return $regular_price > 0.005 && $sale_price < $regular_price ? $regular_price - $sale_price : 0.0;
	}
}

if ( ! function_exists( 'shoptimizer_get_sale_badge_label_for_prices' ) ) {
	/**
	 * Build the label used when a variable product variation is selected.
	 *
	 * @param mixed $regular_price Regular variation price.
	 * @param mixed $sale_price Sale variation price.
	 * @return string Sale badge label, or an empty string when not on sale.
	 */
	function shoptimizer_get_sale_badge_label_for_prices( $regular_price, $sale_price ): string {
		if ( '' === $sale_price ) {
			return '';
		}

		$regular_price = (float) $regular_price;
		$sale_price    = (float) $sale_price;

		if ( $regular_price <= 0.005 || $sale_price >= $regular_price ) {
			return '';
		}

		if ( 'amount' === shoptimizer_get_sale_badge_display_mode() ) {
			return shoptimizer_format_sale_badge_amount_label( $regular_price - $sale_price );
		}

		$percentage = (int) round( 100 - ( $sale_price / $regular_price * 100 ) );

		return $percentage > 0 ? shoptimizer_format_sale_badge_percentage_label( $percentage ) : '';
	}
}
