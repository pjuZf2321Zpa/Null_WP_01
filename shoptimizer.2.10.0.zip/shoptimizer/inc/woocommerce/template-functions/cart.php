<?php
/**
 * Cart specific template functions and hooks
 *
 * This file contains functions and hooks specific to the cart functionality.
 *
 * @package shoptimizer
 *
 * Function Index:
 * - shoptimizer_cart_link() - Displays cart icon and total
 * - shoptimizer_cart_link_fragment() - Updates cart fragments via AJAX
 * - shoptimizer_header_cart() - Displays header cart navigation
 * - shoptimizer_cart_link_shortcode() - Provides cart shortcode functionality
 * - shoptimizer_cart_register_elementor_widget() - Registers Elementor cart widget
 * - shoptimizer_cross_sells_columns() - Controls cross-sells column count
 * - shoptimizer_cross_sells_number() - Controls number of cross-sells
 * - shoptimizer_display_cross_sells() - Manages cross-sells display
 * - shoptimizer_cart_custom_field() - Adds custom widget below cart
 * - shoptimizer_cart_custom_summary() - Adds custom widget below summary
 * - shoptimizer_cart_wrapper_open() - Opens cart wrapper
 * - shoptimizer_cart_wrapper_close() - Closes cart wrapper
 * - shoptimizer_cart_ajax_update_quantity() - Handles AJAX quantity updates
 * - shoptimizer_mobile_cart_body_class() - Adds mobile cart body class
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Cart Display Functions
 * ---------------------
 */

if ( ! function_exists( 'shoptimizer_cart_link' ) ) {
	/**
	 * Displays the cart link including item count and total.
	 * Supports different cart icon styles based on theme settings.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function shoptimizer_cart_link(): void {
		if ( ! shoptimizer_woo_cart_available() ) {
			return;
		}

		$sidebar_cart_enabled = shoptimizer_get_option( 'shoptimizer_layout_woocommerce_enable_sidebar_cart' );
		$cart_icon_style      = shoptimizer_get_option( 'shoptimizer_layout_woocommerce_cart_icon' );
		$cart_url             = $sidebar_cart_enabled ? '#' : esc_url( wc_get_cart_url() );

		// Format cart count: show decimals only when the count has a fractional part,
		// so plugins like ATUM that allow decimal stock quantities display correctly.
		$cart_count    = WC()->cart->get_cart_contents_count();
		$display_count = ( floor( (float) $cart_count ) === (float) $cart_count )
			? (int) $cart_count
			: rtrim( rtrim( number_format( $cart_count, 6, '.', '' ), '0' ), '.' );

		?>
		<div class="shoptimizer-cart">
			<a class="cart-contents"
				role="button"
				href="<?php echo esc_url( $cart_url ); ?>"
				<?php if ( true === $sidebar_cart_enabled ) { ?>
					aria-controls="shoptimizerCartDrawer"
					aria-expanded="false"
				<?php } ?>
				aria-label="<?php esc_attr_e( 'View your shopping cart', 'shoptimizer' ); ?>"
				title="<?php esc_attr_e( 'View your shopping cart', 'shoptimizer' ); ?>">

				<span class="amount"><?php echo wp_kses_post( WC()->cart->get_cart_subtotal() ); ?></span>

				<?php
				// The shared helper sanitizes custom SVG markup and escapes the count.
				echo shoptimizer_get_cart_icon_markup( $cart_icon_style, $display_count ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				?>
			</a>
		</div>
		<?php
	}
}

if ( ! function_exists( 'shoptimizer_cart_link_fragment' ) ) {
	/**
	 * Updates cart fragments via AJAX.
	 * Ensures cart contents update when products are added to the cart via AJAX.
	 *
	 * @since 1.0.0
	 * @param array $fragments Fragments to refresh via AJAX
	 * @return array Modified fragments
	 */
	function shoptimizer_cart_link_fragment( array $fragments ): array {
		ob_start();
		shoptimizer_cart_link();
		$fragments['div.shoptimizer-cart'] = ob_get_clean();

		return $fragments;
	}
}

if ( ! function_exists( 'shoptimizer_header_cart' ) ) {
	/**
	 * Displays the header cart if WooCommerce is activated and cart display is enabled.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function shoptimizer_header_cart(): void {
		if ( ! shoptimizer_is_woocommerce_activated() ) {
			return;
		}

		$display_cart = shoptimizer_get_option( 'shoptimizer_layout_woocommerce_display_cart' );

		if ( true === $display_cart ) {
			?>
			<nav class="site-header-cart menu" aria-label="<?php esc_attr_e( 'Cart contents', 'shoptimizer' ); ?>">
				<?php shoptimizer_cart_link(); ?>
			</nav>
			<?php
		}
	}
}

/**
 * Cart Shortcode & Elementor Widget
 * ---------------------------------
 * SP-520 Fix 6: ported from the legacy template-functions file so the
 * [shoptimizer_cart] shortcode and the Elementor cart widget remain
 * available under V2 (used by Elementor Header/Footer Builder).
 */

if ( ! function_exists( 'shoptimizer_cart_link_shortcode' ) ) {
	/**
	 * Cart Link Shortcode.
	 * Outputs a link to the cart including the item count and cart total.
	 *
	 * @since 2.7.7
	 * @return string
	 */
	function shoptimizer_cart_link_shortcode() {

		$shoptimizer_layout_woocommerce_enable_sidebar_cart = shoptimizer_get_option( 'shoptimizer_layout_woocommerce_enable_sidebar_cart' );
		$shoptimizer_layout_woocommerce_cart_icon           = shoptimizer_get_option( 'shoptimizer_layout_woocommerce_cart_icon' );

		if ( ! shoptimizer_woo_cart_available() ) {
			return '';
		}

		// Show decimals only when the count is fractional (ATUM decimal-stock support).
		$cart_count    = WC()->cart->get_cart_contents_count();
		$display_count = ( floor( (float) $cart_count ) === (float) $cart_count )
			? (int) $cart_count
			: rtrim( rtrim( number_format( $cart_count, 6, '.', '' ), '0' ), '.' );

		$html = '<div class="shoptimizer-cart-shortcode"><div class="shoptimizer-cart">';

		if ( true === $shoptimizer_layout_woocommerce_enable_sidebar_cart ) {
			$html .= '<a class="cart-contents" role="button" href="#" aria-controls="shoptimizerCartDrawer" aria-expanded="false" aria-label="' . esc_attr__( 'View your shopping cart', 'shoptimizer' ) . '" title="' . esc_attr__( 'View your shopping cart', 'shoptimizer' ) . '">';
		} else {
			$html .= '<a class="cart-contents" role="button" href="' . esc_url( wc_get_cart_url() ) . '" aria-label="' . esc_attr__( 'View your shopping cart', 'shoptimizer' ) . '" title="' . esc_attr__( 'View your shopping cart', 'shoptimizer' ) . '">';
		}

		$html .= '<span class="amount">' . wp_kses_post( WC()->cart->get_cart_subtotal() ) . '</span>';

		$html .= shoptimizer_get_cart_icon_markup( $shoptimizer_layout_woocommerce_cart_icon, $display_count );

		$html .= '</a></div></div>';

		return $html;
	}

	add_shortcode( 'shoptimizer_cart', 'shoptimizer_cart_link_shortcode' );
	add_action( 'hfe_header', 'shoptimizer_header_cart_drawer', 5 ); // Elementor Header & Footer Builder.
}

if ( ! function_exists( 'shoptimizer_cart_register_elementor_widget' ) ) {
	/**
	 * Register the Shoptimizer cart Elementor widget.
	 *
	 * @since 2.7.7
	 * @param \Elementor\Widgets_Manager $widgets_manager Elementor widgets manager.
	 * @return void
	 */
	function shoptimizer_cart_register_elementor_widget( $widgets_manager ) {
		require_once get_template_directory() . '/inc/compatibility/elementor-pro/class-shoptimizer-cart-elementor-widget.php';
		$widgets_manager->register( new Shoptimizer_Cart_Elementor_Widget() );
	}

	add_action( 'elementor/widgets/register', 'shoptimizer_cart_register_elementor_widget' );
}

/**
 * Cross Sells Functions
 * --------------------
 */

if ( ! function_exists( 'shoptimizer_cross_sells_columns' ) ) {
	/**
	 * Controls the number of columns for cross-sells display.
	 *
	 * @since 1.0.0
	 * @param mixed $columns Current number of columns
	 * @return int Modified number of columns
	 */
	function shoptimizer_cross_sells_columns( $columns ): int { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found -- Required WooCommerce filter parameter.
		return (int) shoptimizer_get_option( 'shoptimizer_layout_cross_sells_amount' );
	}
}
add_filter( 'woocommerce_cross_sells_columns', 'shoptimizer_cross_sells_columns' );

if ( ! function_exists( 'shoptimizer_cross_sells_number' ) ) {
	/**
	 * Controls the total number of cross-sells to display.
	 *
	 * @since 1.0.0
	 * @param mixed $columns Current number of cross-sells
	 * @return int Modified number of cross-sells
	 */
	function shoptimizer_cross_sells_number( $columns ): int { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found -- Required WooCommerce filter parameter.
		return (int) shoptimizer_get_option( 'shoptimizer_layout_cross_sells_amount' );
	}
}
add_filter( 'woocommerce_cross_sells_total', 'shoptimizer_cross_sells_number' );

if ( ! function_exists( 'shoptimizer_display_cross_sells' ) ) {
	/**
	 * Controls whether to display cross-sells on the cart page.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function shoptimizer_display_cross_sells(): void {
		$display_cross_sells = shoptimizer_get_option( 'shoptimizer_display_cross_sells' );

		if ( false === $display_cross_sells ) {
			remove_action( 'woocommerce_after_cart', 'woocommerce_cross_sell_display' );
		}
	}
}
add_action( 'wp', 'shoptimizer_display_cross_sells' );

/**
 * Cart Widget Areas
 * ----------------
 */

if ( ! function_exists( 'shoptimizer_cart_custom_field' ) ) {
	/**
	 * Displays custom widget area below the cart totals.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function shoptimizer_cart_custom_field(): void {
		if ( is_active_sidebar( 'cart-field' ) ) {
			echo '<div class="cart-custom-field">';
			dynamic_sidebar( 'cart-field' );
			echo '</div>';
		}
	}
}
add_action( 'woocommerce_after_cart_totals', 'shoptimizer_cart_custom_field', 15 );

if ( ! function_exists( 'shoptimizer_cart_custom_summary' ) ) {
	/**
	 * Displays custom widget area below the cart table.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function shoptimizer_cart_custom_summary(): void {
		if ( is_active_sidebar( 'cart-summary' ) ) {
			echo '<div class="cart-summary">';
			dynamic_sidebar( 'cart-summary' );
			echo '</div>';
		}
	}
}
add_action( 'woocommerce_after_cart_table', 'shoptimizer_cart_custom_summary', 50 );

/**
 * Cart Layout Functions
 * --------------------
 */

if ( ! function_exists( 'shoptimizer_cart_wrapper_open' ) ) {
	/**
	 * Opens the cart wrapper section.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function shoptimizer_cart_wrapper_open(): void {
		echo '<section class="shoptimizer-cart-wrapper" role="region" aria-label="' . esc_attr__( 'Shopping Cart', 'shoptimizer' ) . '">';
	}
}

if ( ! function_exists( 'shoptimizer_cart_wrapper_close' ) ) {
	/**
	 * Closes the cart wrapper section.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function shoptimizer_cart_wrapper_close(): void {
		echo '</section>';
	}
}

add_action( 'woocommerce_before_cart', 'shoptimizer_cart_wrapper_open', 20 );
add_action( 'woocommerce_after_cart', 'shoptimizer_cart_wrapper_close', 10 );

/**
 * Cart AJAX Functions
 * ------------------
 */

if ( ! function_exists( 'shoptimizer_cart_ajax_update_quantity' ) ) {
	/**
	 * Enables automatic cart updates when quantity is changed.
	 *
	 * @since 2.6.6
	 * @return void
	 */
	function shoptimizer_cart_ajax_update_quantity(): void {
		if ( true !== shoptimizer_get_option( 'shoptimizer_ajaxcart_quantity' ) || ! is_cart() ) {
			return;
		}

		$handle = 'shoptimizer-cart-ajax-quantity';

		$version = defined( 'SHOPTIMIZER_VERSION' ) ? SHOPTIMIZER_VERSION : wp_get_theme()->get( 'Version' );
		wp_register_script( $handle, false, array( 'jquery' ), $version, true );
		wp_enqueue_script( $handle );

		wp_add_inline_script(
			$handle,
			'(function($) {
                var timeout;
                $("div.woocommerce").on("change keyup mouseup", "input.qty, select.qty", function() {
                    if (timeout !== undefined) {
                        clearTimeout(timeout);
                    }
                    if ($(this).val() === "") {
                        return;
                    }
                    timeout = setTimeout(function() {
                        $("[name=\"update_cart\"]").trigger("click");
                    }, 600);
                });
            })(jQuery);'
		);
	}
}
add_action( 'wp_enqueue_scripts', 'shoptimizer_cart_ajax_update_quantity', 30 );

if ( ! function_exists( 'shoptimizer_cart_ajax_update_quantity_class' ) ) {
	/**
	 * Adds the AJAX cart body class when cart quantity auto-update is enabled.
	 *
	 * @since 2.6.6
	 * @param array $classes Existing body classes
	 * @return array Modified body classes
	 */
	function shoptimizer_cart_ajax_update_quantity_class( array $classes ): array {
		if ( true === shoptimizer_get_option( 'shoptimizer_ajaxcart_quantity' ) && is_cart() ) {
			$classes[] = 'shoptimizer-ajax-cart';
		}

		return $classes;
	}
}
add_filter( 'body_class', 'shoptimizer_cart_ajax_update_quantity_class' );

/**
 * Cart Body Classes
 * ----------------
 */

if ( ! function_exists( 'shoptimizer_mobile_cart_body_class' ) ) {
	/**
	 * Adds mobile cart specific body class.
	 *
	 * @since 1.0.0
	 * @param array $classes Existing body classes
	 * @return array Modified body classes
	 */
	function shoptimizer_mobile_cart_body_class( array $classes ): array {
		$mobile_cart_page = shoptimizer_get_option( 'shoptimizer_layout_woocommerce_mobile_cart_page' );

		if ( true === $mobile_cart_page && is_cart() ) {
			$classes[] = 'm-cart';
		}
		return $classes;
	}
}
add_filter( 'body_class', 'shoptimizer_mobile_cart_body_class' );

// Move cross-sells to after cart
remove_action( 'woocommerce_cart_collaterals', 'woocommerce_cross_sell_display' );
add_action( 'woocommerce_after_cart', 'woocommerce_cross_sell_display' );
