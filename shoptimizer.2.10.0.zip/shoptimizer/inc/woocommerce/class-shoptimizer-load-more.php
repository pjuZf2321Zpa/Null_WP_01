<?php
/**
 * Shoptimizer Load More
 *
 * @package  Shoptimizer
 * @author   CommerceGurus
 * @since    1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Shoptimizer_Load_More' ) ) :

	class Shoptimizer_Load_More {

		/**
		 * Constructor
		 */
		public function __construct() {
			add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_assets' ) );
			add_action( 'woocommerce_after_shop_loop', array( $this, 'render_load_more_ui' ), 35 );
			add_action( 'woocommerce_before_template_part', array( $this, 'start_result_count_buffer' ), 10, 1 );
			add_action( 'woocommerce_after_template_part', array( $this, 'finish_result_count_buffer' ), 10, 4 );
			add_filter( 'body_class', array( $this, 'body_class' ), 40, 1 );
		}

		/**
		 * Determine whether Load More is enabled for the current archive.
		 *
		 * The taxonomy list is intentionally explicit. Third-party taxonomies
		 * may use custom loops or pagination contracts that Load More cannot
		 * safely reproduce, so integrations must opt compatible taxonomies in.
		 *
		 * @return bool
		 */
		private function is_enabled_for_current_archive() {
			if ( ! get_theme_mod( 'shoptimizer_layout_woocommerce_load_more', false ) ) {
				return false;
			}

			if ( is_shop() || is_product_category() || is_product_tag() ) {
				return true;
			}

			$supported_taxonomies = apply_filters(
				'shoptimizer_load_more_supported_taxonomies',
				array( 'product_brand', 'pwb-brand' )
			);
			$taxonomy_slugs       = array();

			foreach ( (array) $supported_taxonomies as $taxonomy ) {
				if ( is_string( $taxonomy ) && '' !== $taxonomy ) {
					$taxonomy_slugs[] = sanitize_key( $taxonomy );
				}
			}

			return ! empty( $taxonomy_slugs ) && is_tax( array_unique( $taxonomy_slugs ) );
		}

		/**
		 * Start buffering WooCommerce's result-count template so structured
		 * metadata can be added without overriding the template.
		 *
		 * @param string $template_name Template name.
		 */
		public function start_result_count_buffer( $template_name ) {
			if ( 'loop/result-count.php' !== $template_name || ! $this->is_enabled_for_current_archive() ) {
				return;
			}

			ob_start();
		}

		/**
		 * Add structured result metadata to WooCommerce's result-count markup.
		 *
		 * @param string $template_name Template name.
		 * @param string $_template_path Template path.
		 * @param string $_located       Located template path.
		 * @param array  $args          Template arguments.
		 */
		public function finish_result_count_buffer( $template_name, $_template_path, $_located, $args ) {
			if ( 'loop/result-count.php' !== $template_name || ! $this->is_enabled_for_current_archive() || ! ob_get_level() ) {
				return;
			}

			$html            = ob_get_clean();
			$total           = isset( $args['total'] ) ? absint( $args['total'] ) : 0;
			$per_page        = isset( $args['per_page'] ) ? absint( $args['per_page'] ) : 0;
			$current         = isset( $args['current'] ) ? max( 1, absint( $args['current'] ) ) : 1;
			$result_from     = $total > 0 && $per_page > 0 ? ( ( $current - 1 ) * $per_page ) + 1 : 0;
			$result_to       = $per_page > 0 ? min( $total, $current * $per_page ) : $total;
			$attributes      = sprintf(
				' data-shoptimizer-result-from="%s" data-shoptimizer-result-to="%s" data-shoptimizer-result-total="%s"',
				esc_attr( $result_from ),
				esc_attr( $result_to ),
				esc_attr( $total )
			);
			$metadata_marker = sprintf(
				'<span class="shoptimizer-result-metadata" hidden data-shoptimizer-result-from="%s" data-shoptimizer-result-to="%s" data-shoptimizer-result-total="%s"></span>',
				esc_attr( $result_from ),
				esc_attr( $result_to ),
				esc_attr( $total )
			);
			$match_count     = 0;

			$html = preg_replace_callback(
				'/(<p\b[^>]*class=(["\'])[^"\']*\bwoocommerce-result-count\b[^"\']*\2)/i',
				function ( $matches ) use ( $attributes ) {
					return $matches[1] . $attributes;
				},
				$html,
				1,
				$match_count
			);

			if ( 1 !== $match_count ) {
				$html = is_string( $html ) ? $html . $metadata_marker : $metadata_marker;
			}

			// WooCommerce owns this already-escaped template output; injected attributes are escaped above.
			// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			echo is_string( $html ) ? $html : '';
		}

		/**
		 * Enqueue frontend assets.
		 */
		public function enqueue_assets() {
			if ( ! $this->is_enabled_for_current_archive() ) {
				return;
			}

			global $wp_query;

			$theme        = wp_get_theme();
			$version      = $theme->get( 'Version' );
			$result_total = absint( $wp_query->found_posts );

			wp_enqueue_script(
				'shoptimizer-load-more',
				get_template_directory_uri() . '/assets/js/load-more.min.js',
				array(),
				$version,
				true
			);

			wp_localize_script(
				'shoptimizer-load-more',
				'ShoptimizerLoadMore',
				array(
					/* translators: {FROM}, {TO}, and {TOTAL} are replaced with result ranges. */
					'result_text'    => esc_html__( 'Showing {FROM}–{TO} of {TOTAL} results', 'shoptimizer' ),
					'result_total'   => $result_total,
					'load_more_text' => esc_html( get_theme_mod( 'shoptimizer_layout_woocommerce_load_more_text', __( 'Load more products', 'shoptimizer' ) ) ),
					'i18n'           => array(
						'error_message' => esc_html__( 'Failed to load more products. Please try again.', 'shoptimizer' ),
					),
				)
			);
		}

		/**
		 * Render Load More UI.
		 */
		public function render_load_more_ui() {
			if ( ! $this->is_enabled_for_current_archive() ) {
				return;
			}

			global $wp_query;

			$hide_wrapper = $wp_query->max_num_pages <= 1;
			$paged        = max( 1, get_query_var( 'paged' ), get_query_var( 'page' ) );
			$total        = absint( $wp_query->found_posts );
			$per_page     = absint( $wp_query->get( 'posts_per_page' ) );
			$result_from  = $total > 0 ? ( ( $paged - 1 ) * $per_page ) + 1 : 0;
			$result_to    = min( $total, $paged * $per_page );
			$viewed       = $result_to;

			if ( $wp_query->max_num_pages === $paged ) {
				$hide_wrapper = true;
			}

			$load_more_text = get_theme_mod( 'shoptimizer_layout_woocommerce_load_more_text', __( 'Load more products', 'shoptimizer' ) );
			?>

		<div class="shoptimizer-load-more-wrapper" data-result-from="<?php echo esc_attr( $result_from ); ?>" data-result-to="<?php echo esc_attr( $result_to ); ?>" data-result-total="<?php echo esc_attr( $total ); ?>" <?php echo true === $hide_wrapper ? 'style="display: none;"' : ''; ?>>
			<p class="load-more-status" aria-live="polite">
				<?php
				printf(
					/* translators: 1: viewed count, 2: total products */
					esc_html__( 'You\'ve viewed %1$s of %2$s products', 'shoptimizer' ),
					'<span class="viewed-count">' . esc_html( $viewed ) . '</span>',
					'<span class="total-count">' . esc_html( $total ) . '</span>'
				);
				?>
			</p>
			<div class="load-more-progress" role="progressbar" aria-label="<?php esc_attr_e( 'Products viewed progress', 'shoptimizer' ); ?>" aria-valuemin="0" aria-valuemax="<?php echo esc_attr( $total ); ?>" aria-valuenow="<?php echo esc_attr( $viewed ); ?>">
				<div class="load-more-progress-bar" style="width: <?php echo esc_attr( $total > 0 ? ( $viewed / $total ) * 100 : 0 ); ?>%;"></div>
			</div>
			<button id="shoptimizer-load-more-btn" class="button" type="button" aria-label="<?php echo esc_attr( $load_more_text ); ?>">
				<span class="load-more-button-text"><?php echo esc_html( $load_more_text ); ?></span>
				<span class="load-more-button-spinner" aria-hidden="true"></span>
			</button>
		</div>
			<?php
		}

		/**
		 * Add the Load More body class only while the feature is enabled.
		 *
		 * @param array $classes Existing body classes.
		 * @return array
		 */
		public function body_class( $classes ) {
			if ( ! $this->is_enabled_for_current_archive() ) {
				return $classes;
			}

			$classes[] = 'shoptimizer-load-more';

			return $classes;
		}
	}

	new Shoptimizer_Load_More();

endif;
