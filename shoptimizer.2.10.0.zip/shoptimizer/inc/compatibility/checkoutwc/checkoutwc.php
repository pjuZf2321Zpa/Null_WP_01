<?php

/**
 * CheckoutWC
 *
 * @package Shoptimizer
 * @since Shoptimizer 2.8.7
 */

/**
 * WooCommerce add to cart redirect
 * Adds support for prevent redirect to cart on ajax add to cart action
 *
 * @since   1.0.0
 * @return  void
 */
function shoptimizer_checkoutwc_ajax_add_to_cart_redirect( $url ){
	if ( isset( $_REQUEST['wc-ajax'] ) && 'shoptimizer_pdp_ajax_atc' === $_REQUEST['wc-ajax'] ) {
		return false;
	}

	return $url;
}
add_filter( 'woocommerce_add_to_cart_redirect', 'shoptimizer_checkoutwc_ajax_add_to_cart_redirect', 9999, 1 );

/**
 * Tell CheckoutWC to render its native cart quantity input.
 *
 * Shoptimizer adds wrapper markup to the standard WooCommerce checkout
 * quantity HTML. CheckoutWC interprets that changed HTML as a custom quantity
 * override and hides its own quantity controls unless this compatibility
 * filter is disabled.
 *
 * @param bool   $has_override Whether the cart quantity HTML was overridden.
 * @param string $cart_item_key The cart item key.
 * @return bool
 */
function shoptimizer_checkoutwc_cart_quantity_input_has_override(
	$has_override,
	$cart_item_key
) {
	unset( $has_override, $cart_item_key );
	return false;
}
add_filter( 'cfw_cart_quantity_input_has_override', 'shoptimizer_checkoutwc_cart_quantity_input_has_override', 9999, 2 );
