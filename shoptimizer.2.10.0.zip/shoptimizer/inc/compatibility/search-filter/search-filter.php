<?php
/**
 * Search & Filter Free/Pro compatibility.
 *
 * @package Shoptimizer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Add a body class when Search & Filter is active so child themes can scope
 * additional integration styles without repeating plugin activation checks.
 *
 * @param array $classes Body classes.
 * @return array
 */
if ( ! function_exists( 'shoptimizer_search_filter_body_class' ) ) {
	function shoptimizer_search_filter_body_class( $classes ) {
		$classes[] = 'shoptimizer-search-filter';

		return $classes;
	}
}
add_filter( 'body_class', 'shoptimizer_search_filter_body_class' );

/**
 * Search & Filter Pro wraps WooCommerce results for Ajax refreshes. Its default
 * close priority can close Shoptimizer's sorting wrapper before pagination is
 * rendered, so move the Search & Filter close after Shoptimizer's loop wrappers.
 */
if ( ! function_exists( 'shoptimizer_search_filter_adjust_woocommerce_wrappers' ) ) {
	function shoptimizer_search_filter_adjust_woocommerce_wrappers() {
		$integration = 'Search_Filter_Pro\Integrations\Woocommerce';

		if ( ! class_exists( $integration ) ) {
			return;
		}

		remove_action( 'woocommerce_after_shop_loop', array( $integration, 'close_classic_shop_results_container' ), 20 );
		remove_action( 'woocommerce_after_shop_loop', array( $integration, 'close_classic_shop_results_container' ), 60 );
		add_action( 'woocommerce_after_shop_loop', array( $integration, 'close_classic_shop_results_container' ), 60 );

		remove_action( 'woocommerce_no_products_found', array( $integration, 'close_classic_shop_results_container' ), 20 );
		remove_action( 'woocommerce_no_products_found', array( $integration, 'close_classic_shop_results_container' ), 60 );
		add_action( 'woocommerce_no_products_found', array( $integration, 'close_classic_shop_results_container' ), 60 );

		remove_action( 'woocommerce_shortcode_after_products_loop', array( $integration, 'close_shortcode_results_container' ), 20 );
		remove_action( 'woocommerce_shortcode_after_products_loop', array( $integration, 'close_shortcode_results_container' ), 60 );
		add_action( 'woocommerce_shortcode_after_products_loop', array( $integration, 'close_shortcode_results_container' ), 60 );

		remove_action( 'woocommerce_shortcode_products_loop_no_results', array( $integration, 'close_shortcode_results_container' ), 20 );
		remove_action( 'woocommerce_shortcode_products_loop_no_results', array( $integration, 'close_shortcode_results_container' ), 60 );
		add_action( 'woocommerce_shortcode_products_loop_no_results', array( $integration, 'close_shortcode_results_container' ), 60 );
	}
}
add_action( 'wp', 'shoptimizer_search_filter_adjust_woocommerce_wrappers', 20 );
add_action( 'woocommerce_before_shop_loop', 'shoptimizer_search_filter_adjust_woocommerce_wrappers', 1 );
add_action( 'woocommerce_after_shop_loop', 'shoptimizer_search_filter_adjust_woocommerce_wrappers', 1, 0 );
add_action( 'woocommerce_no_products_found', 'shoptimizer_search_filter_adjust_woocommerce_wrappers', 1, 0 );
add_action( 'woocommerce_shortcode_before_products_loop', 'shoptimizer_search_filter_adjust_woocommerce_wrappers', 1, 0 );
add_action( 'woocommerce_shortcode_after_products_loop', 'shoptimizer_search_filter_adjust_woocommerce_wrappers', 1, 0 );
add_action( 'woocommerce_shortcode_products_loop_no_results', 'shoptimizer_search_filter_adjust_woocommerce_wrappers', 1, 0 );
