<?php
/**
 * Getting started template
 *
 * @package CommerceGurus
 * @subpackage Shoptimizer
 */

$customizer_url = admin_url() . 'customize.php';
?>

<div id="fonts" class="ccfw-tab-pane kirki-settings-page">

	<div class="ccfw-tab-pane-center">

		<h1 class="ccfw-welcome-title"><?php esc_html_e( 'Clear Font Cache', 'shoptimizer' ); ?></h1>
		<p><?php esc_html_e( 'In order to achieve GDPR-compliance, Shoptimizer stores Google Fonts locally on your server.', 'shoptimizer' ); ?><br /><?php esc_html_e( 'If Google Fonts selected in the Customizer are not displayed correctly, please try clearing the font cache.', 'shoptimizer' ); ?></p>
		<p><?php esc_html_e( 'This is safe to do on production sites.', 'shoptimizer' ); ?></p>
	</div>
	<div class="kirki-clear-font-cache-metabox">
		<button type="button" class="button button-larger button-primary kirki-clear-font-cache" data-nonce="<?php echo esc_attr( wp_create_nonce( 'Kirki_Clear_Font_Cache' ) ); ?>"><?php _e( 'Clear Cache', 'shoptimizer' ); ?></button>
		<span class="submission-status is-hidden"></span>
	</div>
	<div class="ccfw-clear"></div>
</div>
