<?php
/**
 * Hidden onboarding proof of concept.
 *
 * @package Shoptimizer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Shoptimizer_Onboarding' ) ) {
	/**
	 * Registers the feature-flagged Shoptimizer onboarding POC.
	 */
	class Shoptimizer_Onboarding {
		/**
		 * Admin page slug.
		 *
		 * @var string
		 */
		const PAGE_SLUG = 'shoptimizer-onboarding';

		/**
		 * REST namespace.
		 *
		 * @var string
		 */
		const REST_NAMESPACE = 'shoptimizer/v1';

		/**
		 * Option used to persist onboarding step states.
		 *
		 * @var string
		 */
		const STEP_STATES_OPTION = 'shoptimizer_onboarding_step_states';

		/**
		 * Admin page hook suffix.
		 *
		 * @var string
		 */
		private $page_hook = '';

		/**
		 * Recommended plugin definitions for onboarding.
		 *
		 * @var array
		 */
		private $recommended_plugins = array(
			'commercegurus-commercekit' => array(
				'name'        => 'CommerceKit',
				'file'        => 'commercegurus-commercekit/commercegurus-commercekit.php',
				'source'      => 'https://files.commercegurus.com/commercekit/2.5.2/commercegurus-commercekit.zip',
				'description' => 'Add the conversion features Shoptimizer is known for — live product search, swatches, wishlists, order bumps, and faster product galleries.',
				'badge'       => 'Strongly recommended',
				'icon_label'  => 'CK',
				'icon'        => 'commercekit.png',
				'manage_path' => 'admin.php?page=commercekit',
			),
			'elementor'                 => array(
				'name'        => 'Elementor',
				'file'        => 'elementor/elementor.php',
				'source'      => 'wordpress.org',
				'description' => 'Edit imported Shoptimizer layouts and build pages with a visual drag-and-drop editor.',
				'badge'       => 'Recommended',
				'icon_label'  => 'E',
				'icon'        => 'elementor.png',
				'manage_path' => 'admin.php?page=elementor-settings',
			),
			'woocommerce'               => array(
				'name'        => 'WooCommerce',
				'file'        => 'woocommerce/woocommerce.php',
				'source'      => 'wordpress.org',
				'description' => 'Create products, manage orders, configure payments, and run your online store.',
				'badge'       => 'Required',
				'icon_label'  => 'Woo',
				'icon'        => 'woocommerce.svg',
				'manage_path' => 'admin.php?page=wc-admin',
			),
		);

		/**
		 * Boot the onboarding hooks.
		 *
		 * @return void
		 */
		public function __construct() {
			if ( ! $this->is_enabled() ) {
				return;
			}

			add_action( 'admin_menu', array( $this, 'register_admin_page' ) );
			add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_assets' ) );
			add_action( 'rest_api_init', array( $this, 'register_rest_routes' ) );
			add_action( 'after_switch_theme', array( $this, 'queue_activation_redirect' ) );
			add_action( 'admin_init', array( $this, 'maybe_redirect_to_onboarding' ) );
			add_action( 'load-themes.php', array( $this, 'register_activation_notice' ) );
			add_action( 'cgdi/after_import', array( $this, 'mark_demo_imported' ), 20 );
			add_action( 'shoptimizer/onboarding/demo_import_outcome', array( $this, 'record_demo_import_outcome' ) );
		}

		/**
		 * Queue a one-time redirect to onboarding after theme activation.
		 *
		 * @return void
		 */
		public function queue_activation_redirect() {
			if ( get_option( 'shoptimizer_onboarding_complete', false ) ) {
				return;
			}

			set_transient( 'shoptimizer_onboarding_redirect', 1, 60 );
		}

		/**
		 * Redirect to the onboarding page once after a fresh activation.
		 *
		 * @return void
		 */
		public function maybe_redirect_to_onboarding() {
			if ( ! get_transient( 'shoptimizer_onboarding_redirect' ) ) {
				return;
			}

			delete_transient( 'shoptimizer_onboarding_redirect' );

			if (
				wp_doing_ajax() ||
				is_network_admin() ||
				! current_user_can( 'manage_options' ) ||
				isset( $_GET['activate-multi'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			) {
				return;
			}

			wp_safe_redirect( admin_url( 'themes.php?page=' . self::PAGE_SLUG ) );
			exit;
		}

		/**
		 * Register the activation admin notice on the themes screen.
		 *
		 * @return void
		 */
		public function register_activation_notice() {
			if ( ! isset( $_GET['activated'] ) || get_option( 'shoptimizer_onboarding_complete', false ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
				return;
			}

			add_action( 'admin_notices', array( $this, 'render_activation_notice' ), 98 );
		}

		/**
		 * Render the activation admin notice linking to onboarding.
		 *
		 * @return void
		 */
		public function render_activation_notice() {
			?>
			<div class="updated notice is-dismissible">
				<p>
					<?php
					printf(
						/* translators: %1$s: opening link tag, %2$s: closing link tag. */
						esc_html__( 'Thanks for choosing Shoptimizer! Head to the %1$ssetup screen%2$s to install plugins, import demo content, and add your branding.', 'shoptimizer' ),
						'<a href="' . esc_url( admin_url( 'themes.php?page=' . self::PAGE_SLUG ) ) . '">',
						'</a>'
					);
					?>
				</p>
				<p><a href="<?php echo esc_url( admin_url( 'themes.php?page=' . self::PAGE_SLUG ) ); ?>" class="button" style="text-decoration: none;"><?php esc_html_e( 'Start setup', 'shoptimizer' ); ?></a></p>
			</div>
			<?php
		}

		/**
		 * Record that demo content has been imported.
		 *
		 * @return void
		 */
		public function mark_demo_imported() {
			update_option( 'shoptimizer_onboarding_demo_imported', true );
		}

		/**
		 * Persist the final demo import outcome.
		 *
		 * @param string $outcome Demo import outcome.
		 * @return void
		 */
		public function record_demo_import_outcome( $outcome ) {
			if ( ! in_array( $outcome, array( 'success', 'warning' ), true ) ) {
				return;
			}

			$state = 'warning' === $outcome ? 'needs_attention' : 'completed';

			$this->set_saved_step_state( 'demo', $state );
		}

		/**
		 * Check whether the onboarding POC is enabled.
		 *
		 * @return bool
		 */
		private function is_enabled() {
			return defined( 'SHOPTIMIZER_ONBOARDING_POC' ) && SHOPTIMIZER_ONBOARDING_POC;
		}

		/**
		 * Register the hidden admin page.
		 *
		 * @return void
		 */
		public function register_admin_page() {
			$this->page_hook = add_theme_page(
				esc_html__( 'Shoptimizer', 'shoptimizer' ),
				esc_html__( 'Shoptimizer', 'shoptimizer' ),
				'manage_options',
				self::PAGE_SLUG,
				array( $this, 'render_admin_page' )
			);
		}

		/**
		 * Enqueue onboarding assets.
		 *
		 * @param string $hook_suffix Current admin page hook suffix.
		 * @return void
		 */
		public function enqueue_admin_assets( $hook_suffix ) {
			if ( $this->page_hook !== $hook_suffix ) {
				return;
			}

			wp_enqueue_media();

			wp_enqueue_style(
				'shoptimizer-onboarding',
				get_template_directory_uri() . '/assets/css/admin/onboarding.css',
				array(),
				SHOPTIMIZER_VERSION
			);

			$script_base = get_template_directory_uri() . '/assets/js/';
			$scripts     = array(
				'shoptimizer-onboarding-core'        => array(
					'file' => 'onboarding-core.js',
					'deps' => array(),
				),
				'shoptimizer-onboarding-quick-setup' => array(
					'file' => 'onboarding-quick-setup.js',
					'deps' => array( 'shoptimizer-onboarding-core' ),
				),
				'shoptimizer-onboarding-child-theme' => array(
					'file' => 'onboarding-child-theme.js',
					'deps' => array( 'shoptimizer-onboarding-core', 'shoptimizer-onboarding-quick-setup' ),
				),
				'shoptimizer-onboarding-plugins'     => array(
					'file' => 'onboarding-plugins.js',
					'deps' => array( 'shoptimizer-onboarding-core' ),
				),
				'shoptimizer-onboarding-brand'       => array(
					'file' => 'onboarding-brand.js',
					'deps' => array( 'shoptimizer-onboarding-core' ),
				),
				'shoptimizer-onboarding-homepage'    => array(
					'file' => 'onboarding-homepage.js',
					'deps' => array( 'shoptimizer-onboarding-core' ),
				),
				'shoptimizer-onboarding-demo'        => array(
					'file' => 'onboarding-demo.js',
					'deps' => array( 'shoptimizer-onboarding-core' ),
				),
				'shoptimizer-onboarding-finish'      => array(
					'file' => 'onboarding-finish.js',
					'deps' => array( 'shoptimizer-onboarding-core' ),
				),
				'shoptimizer-onboarding-font-cache'  => array(
					'file' => 'onboarding-font-cache.js',
					'deps' => array( 'shoptimizer-onboarding-core' ),
				),
				'shoptimizer-onboarding-init'        => array(
					'file' => 'onboarding-init.js',
					'deps' => array(
						'shoptimizer-onboarding-quick-setup',
						'shoptimizer-onboarding-child-theme',
						'shoptimizer-onboarding-plugins',
						'shoptimizer-onboarding-brand',
						'shoptimizer-onboarding-homepage',
						'shoptimizer-onboarding-demo',
						'shoptimizer-onboarding-finish',
						'shoptimizer-onboarding-font-cache',
					),
				),
			);

			foreach ( $scripts as $handle => $script ) {
				wp_enqueue_script(
					$handle,
					$script_base . $script['file'],
					$script['deps'],
					SHOPTIMIZER_VERSION,
					true
				);
			}

			wp_localize_script(
				'shoptimizer-onboarding-core',
				'shoptimizerOnboarding',
				array(
					'status'     => $this->build_status(),
					'endpoint'   => esc_url_raw( rest_url( self::REST_NAMESPACE . '/onboarding/status' ) ),
					'actions'    => array(
						'installPlugin'   => esc_url_raw( rest_url( self::REST_NAMESPACE . '/onboarding/plugins/install' ) ),
						'activatePlugin'  => esc_url_raw( rest_url( self::REST_NAMESPACE . '/onboarding/plugins/activate' ) ),
						'setupChildTheme' => esc_url_raw( rest_url( self::REST_NAMESPACE . '/onboarding/child-theme/setup' ) ),
						'saveBrand'       => esc_url_raw( rest_url( self::REST_NAMESPACE . '/onboarding/brand' ) ),
						'saveHomepage'    => esc_url_raw( rest_url( self::REST_NAMESPACE . '/onboarding/homepage' ) ),
						'saveStepState'   => esc_url_raw( rest_url( self::REST_NAMESPACE . '/onboarding/steps/state' ) ),
						'clearFontCache'  => esc_url_raw( rest_url( self::REST_NAMESPACE . '/onboarding/fonts/clear-cache' ) ),
						'complete'        => esc_url_raw( rest_url( self::REST_NAMESPACE . '/onboarding/complete' ) ),
					),
					'demoImport' => array(
						'ajaxUrl' => admin_url( 'admin-ajax.php' ),
						'nonce'   => current_user_can( 'import' ) ? wp_create_nonce( 'cgdi-ajax-verification' ) : '',
					),
					'nonce'      => wp_create_nonce( 'wp_rest' ),
					'i18n'       => $this->get_js_strings(),
				)
			);
		}

		/**
		 * Translatable strings used by the onboarding script.
		 *
		 * @return array
		 */
		private function get_js_strings() {
			return array(
				'continue'                => esc_html__( 'Continue', 'shoptimizer' ),
				'done'                    => esc_html__( 'Done', 'shoptimizer' ),
				'goToDashboard'           => esc_html__( 'Go to dashboard', 'shoptimizer' ),
				'saveAndContinue'         => esc_html__( 'Save and continue', 'shoptimizer' ),
				'importAndContinue'       => esc_html__( 'Import and continue', 'shoptimizer' ),
				'savingBrand'             => esc_html__( 'Saving brand settings…', 'shoptimizer' ),
				'savingHomepage'          => esc_html__( 'Saving homepage…', 'shoptimizer' ),
				'working'                 => esc_html__( 'Working…', 'shoptimizer' ),
				'finishing'               => esc_html__( 'Finishing…', 'shoptimizer' ),
				'install'                 => esc_html__( 'Install', 'shoptimizer' ),
				'activate'                => esc_html__( 'Activate', 'shoptimizer' ),
				'manage'                  => esc_html__( 'Manage', 'shoptimizer' ),
				'installing'              => esc_html__( 'Installing plugin…', 'shoptimizer' ),
				'activating'              => esc_html__( 'Activating plugin…', 'shoptimizer' ),
				'clearing'                => esc_html__( 'Clearing…', 'shoptimizer' ),
				'clearCache'              => esc_html__( 'Clear cache', 'shoptimizer' ),
				'pluginInstalled'         => esc_html__( 'Plugin installed and activated successfully.', 'shoptimizer' ),
				'pluginActivated'         => esc_html__( 'Plugin activated successfully.', 'shoptimizer' ),
				'pluginActionUnavailable' => esc_html__( 'This plugin action is not available yet.', 'shoptimizer' ),
				'pluginActionFailed'      => esc_html__( 'Plugin activation failed.', 'shoptimizer' ),
				'childThemeUnavailable'   => esc_html__( 'Child theme setup is not available yet.', 'shoptimizer' ),
				'childThemeFailed'        => esc_html__( 'Child theme setup failed.', 'shoptimizer' ),
				'childThemeDone'          => esc_html__( 'Child theme setup completed.', 'shoptimizer' ),
				'childThemeActive'        => esc_html__( 'Child theme is active.', 'shoptimizer' ),
				'childThemeInstalled'     => esc_html__( 'Child theme is installed but not active.', 'shoptimizer' ),
				'childThemeMissing'       => esc_html__( 'Child theme is not installed yet.', 'shoptimizer' ),
				'childThemeReady'         => esc_html__( 'The child theme is ready to use.', 'shoptimizer' ),
				'childThemeActivateHint'  => esc_html__( 'Click the button to activate it.', 'shoptimizer' ),
				'childThemeInstallHint'   => esc_html__( 'Click the button to install it.', 'shoptimizer' ),
				'installChildTheme'       => esc_html__( 'Install child theme', 'shoptimizer' ),
				'activateChildTheme'      => esc_html__( 'Activate child theme', 'shoptimizer' ),
				'brandUnavailable'        => esc_html__( 'Brand saving is not available yet.', 'shoptimizer' ),
				'brandInvalidColor'       => esc_html__( 'Please enter a valid 6-digit hex color.', 'shoptimizer' ),
				'brandSaveFailed'         => esc_html__( 'Brand settings could not be saved.', 'shoptimizer' ),
				'unsavedChangesConfirm'   => esc_html__( 'You have unsaved changes. Leave this step and discard them?', 'shoptimizer' ),
				'mediaUnavailable'        => esc_html__( 'The WordPress media library is not available.', 'shoptimizer' ),
				'selectLogo'              => esc_html__( 'Select logo', 'shoptimizer' ),
				'selectSiteIcon'          => esc_html__( 'Select site icon', 'shoptimizer' ),
				'useThisImage'            => esc_html__( 'Use this image', 'shoptimizer' ),
				'homepageChoose'          => esc_html__( 'Please choose a published page for your homepage.', 'shoptimizer' ),
				'homepageSaveFailed'      => esc_html__( 'The homepage could not be saved.', 'shoptimizer' ),
				'homepageSelect'          => esc_html__( 'Select a page', 'shoptimizer' ),
				'homepageNone'            => esc_html__( 'No published pages available', 'shoptimizer' ),
				'homepageUntitled'        => esc_html__( 'Untitled page', 'shoptimizer' ),
				'fontCacheUnavailable'    => esc_html__( 'Font cache clearing is not available yet.', 'shoptimizer' ),
				'fontCacheFailed'         => esc_html__( 'Font cache could not be cleared.', 'shoptimizer' ),
				'fontCacheCleared'        => esc_html__( 'Font cache cleared.', 'shoptimizer' ),
				'statusLoadFailed'        => esc_html__( 'Unable to load onboarding status.', 'shoptimizer' ),
				'noDemoSelected'          => esc_html__( 'No demo selected', 'shoptimizer' ),
				'skipped'                 => esc_html__( 'Skipped', 'shoptimizer' ),
				'needsAttention'          => esc_html__( 'Needs attention', 'shoptimizer' ),
				'stepStateFailed'         => esc_html__( 'This step could not be updated. Please try again.', 'shoptimizer' ),
				'demoUnavailable'         => esc_html__( 'Demo import is not available on this site.', 'shoptimizer' ),
				'demoPluginsMissing'      => esc_html__( 'Demo import needs WooCommerce, CommerceKit, and Elementor active. Complete the Plugins step first.', 'shoptimizer' ),
				'demoAlreadyImported'     => esc_html__( 'Demo content has already been imported on this site. Importing again can create duplicate content.', 'shoptimizer' ),
				'demoReimportConfirm'     => esc_html__( 'Importing the demo again can create duplicate products, pages, menus, and media. Do you want to continue?', 'shoptimizer' ),
				'importAgain'             => esc_html__( 'Import again', 'shoptimizer' ),
				'demoStageDownload'       => esc_html__( 'Downloading import files…', 'shoptimizer' ),
				'demoStageContent'        => esc_html__( 'Importing products, pages, and images — this can take a few minutes…', 'shoptimizer' ),
				'demoStageFinalize'       => esc_html__( 'Setting up menus, widgets, and your homepage…', 'shoptimizer' ),
				'demoImportComplete'      => esc_html__( 'Demo content imported successfully.', 'shoptimizer' ),
				'demoImportWarning'       => esc_html__( 'Demo content was imported, but some items may need attention. Review the demo import log for details.', 'shoptimizer' ),
				'demoImportFailed'        => esc_html__( 'The demo import failed. Nothing else was changed — you can try again, or import later from Appearance → Import Demo Data.', 'shoptimizer' ),
				'completeFailed'          => esc_html__( 'Setup could not be marked as complete. Please try again.', 'shoptimizer' ),
				'finishCompleteTitle'     => esc_html__( 'Setup complete — your store is ready', 'shoptimizer' ),
				'finishCompleteCopy'      => esc_html__( 'Your store foundation is ready. Review the front end, then refine your branding, products, and checkout settings.', 'shoptimizer' ),
				'finishGuidedTitle'       => esc_html__( 'Guided setup complete', 'shoptimizer' ),
				'finishGuidedCopy'        => esc_html__( 'Review any skipped or unfinished tasks from the dashboard whenever you are ready.', 'shoptimizer' ),
				'stepCount'               => /* translators: %1$s: current step number, %2$s: total steps. */ esc_html__( 'Step %1$s of %2$s', 'shoptimizer' ),
				'countOf'                 => /* translators: %1$s: completed count, %2$s: total count. */ esc_html__( '%1$s of %2$s', 'shoptimizer' ),
				'versionLabel'            => /* translators: %s: plugin version. */ esc_html__( 'Version %s', 'shoptimizer' ),
			);
		}

		/**
		 * Register onboarding REST routes.
		 *
		 * @return void
		 */
		public function register_rest_routes() {
			register_rest_route(
				self::REST_NAMESPACE,
				'/onboarding/status',
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_status' ),
					'permission_callback' => array( $this, 'can_manage_onboarding' ),
				)
			);

			register_rest_route(
				self::REST_NAMESPACE,
				'/onboarding/plugins/activate',
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'activate_plugin' ),
					'permission_callback' => array( $this, 'can_activate_plugins' ),
					'args'                => array(
						'slug' => array(
							'required'          => true,
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_key',
						),
					),
				)
			);

			register_rest_route(
				self::REST_NAMESPACE,
				'/onboarding/plugins/install',
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'install_plugin' ),
					'permission_callback' => array( $this, 'can_install_plugins' ),
					'args'                => array(
						'slug' => array(
							'required'          => true,
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_key',
						),
					),
				)
			);

			register_rest_route(
				self::REST_NAMESPACE,
				'/onboarding/brand',
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'save_brand_settings' ),
					'permission_callback' => array( $this, 'can_edit_brand_settings' ),
					'args'                => array(
						'primary_color' => array(
							'required' => true,
							'type'     => 'string',
						),
						'logo_id'       => array(
							'required'          => true,
							'type'              => 'integer',
							'sanitize_callback' => 'absint',
						),
						'site_icon_id'  => array(
							'required'          => true,
							'type'              => 'integer',
							'sanitize_callback' => 'absint',
						),
					),
				)
			);

			register_rest_route(
				self::REST_NAMESPACE,
				'/onboarding/homepage',
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'save_homepage_settings' ),
					'permission_callback' => array( $this, 'can_edit_homepage_settings' ),
					'args'                => array(
						'page_id' => array(
							'required'          => true,
							'type'              => 'integer',
							'sanitize_callback' => 'absint',
						),
					),
				)
			);

			register_rest_route(
				self::REST_NAMESPACE,
				'/onboarding/steps/state',
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'save_step_state' ),
					'permission_callback' => array( $this, 'can_manage_onboarding' ),
					'args'                => array(
						'step'  => array(
							'required'          => true,
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_key',
						),
						'state' => array(
							'required'          => true,
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_key',
						),
					),
				)
			);

			register_rest_route(
				self::REST_NAMESPACE,
				'/onboarding/child-theme/setup',
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'setup_child_theme' ),
					'permission_callback' => array( $this, 'can_setup_child_theme' ),
				)
			);

			register_rest_route(
				self::REST_NAMESPACE,
				'/onboarding/fonts/clear-cache',
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'clear_font_cache' ),
					'permission_callback' => array( $this, 'can_manage_onboarding' ),
				)
			);

			register_rest_route(
				self::REST_NAMESPACE,
				'/onboarding/complete',
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'complete_onboarding' ),
					'permission_callback' => array( $this, 'can_manage_onboarding' ),
				)
			);
		}

		/**
		 * Mark onboarding as complete.
		 *
		 * @return WP_REST_Response
		 */
		public function complete_onboarding() {
			update_option( 'shoptimizer_onboarding_complete', true );

			return rest_ensure_response( $this->build_status() );
		}

		/**
		 * Save an explicit onboarding step state.
		 *
		 * @param WP_REST_Request $request REST request.
		 * @return WP_REST_Response|WP_Error
		 */
		public function save_step_state( $request ) {
			$step  = sanitize_key( $request->get_param( 'step' ) );
			$state = sanitize_key( $request->get_param( 'state' ) );

			if ( ! in_array( $step, $this->get_onboarding_step_names(), true ) ) {
				return new WP_Error(
					'shoptimizer_onboarding_invalid_step',
					esc_html__( 'This onboarding step is not valid.', 'shoptimizer' ),
					array( 'status' => 400 )
				);
			}

			if ( ! in_array( $state, array( 'completed', 'skipped', 'needs_attention' ), true ) ) {
				return new WP_Error(
					'shoptimizer_onboarding_invalid_step_state',
					esc_html__( 'This onboarding step state is not valid.', 'shoptimizer' ),
					array( 'status' => 400 )
				);
			}

			$this->set_saved_step_state( $step, $state );

			return rest_ensure_response( $this->build_status() );
		}

		/**
		 * Determine whether the current user can manage onboarding.
		 *
		 * @return bool
		 */
		public function can_manage_onboarding() {
			return current_user_can( 'manage_options' );
		}

		/**
		 * Determine whether the current user can activate plugins.
		 *
		 * @return bool
		 */
		public function can_activate_plugins() {
			return current_user_can( 'manage_options' ) && current_user_can( 'activate_plugins' );
		}

		/**
		 * Determine whether the current user can install plugins.
		 *
		 * @return bool
		 */
		public function can_install_plugins() {
			return current_user_can( 'manage_options' ) && current_user_can( 'install_plugins' );
		}

		/**
		 * Determine whether the current user can install or activate the child theme.
		 *
		 * @return bool
		 */
		public function can_setup_child_theme() {
			return current_user_can( 'manage_options' ) && ( current_user_can( 'install_themes' ) || current_user_can( 'switch_themes' ) );
		}

		/**
		 * Determine whether the current user can edit brand settings.
		 *
		 * @return bool
		 */
		public function can_edit_brand_settings() {
			return current_user_can( 'manage_options' ) && current_user_can( 'edit_theme_options' );
		}

		/**
		 * Determine whether the current user can edit homepage settings.
		 *
		 * @return bool
		 */
		public function can_edit_homepage_settings() {
			return current_user_can( 'manage_options' ) && current_user_can( 'edit_theme_options' );
		}

		/**
		 * Render the proof-of-concept admin page.
		 *
		 * @return void
		 */
		public function render_admin_page() {
			if ( ! current_user_can( 'manage_options' ) ) {
				wp_die( esc_html__( 'You do not have permission to access this page.', 'shoptimizer' ) );
			}

			$theme_version      = defined( 'SHOPTIMIZER_VERSION' ) ? SHOPTIMIZER_VERSION : wp_get_theme()->get( 'Version' );
			$commercekit_active = $this->is_plugin_active( $this->recommended_plugins['commercegurus-commercekit']['file'] );
			$commercekit_url    = $commercekit_active ? admin_url( 'admin.php?page=commercekit' ) : '#setup/plugins';
			$commercekit_label  = $commercekit_active ? __( 'View settings', 'shoptimizer' ) : __( 'Set up CommerceKit', 'shoptimizer' );

			$this->render_view(
				'shell',
				array(
					'theme_version'     => $theme_version,
					'commercekit_url'   => $commercekit_url,
					'commercekit_label' => $commercekit_label,
				)
			);
		}

		/**
		 * Render an onboarding view template.
		 *
		 * @param string $view View template name.
		 * @param array  $args Data exposed to the template.
		 * @return void
		 */
		// phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed -- The view receives $args through require scope.
		private function render_view( $view, $args = array() ) {
			$view_path = get_template_directory() . '/inc/onboarding/views/' . sanitize_file_name( $view ) . '.php';

			if ( file_exists( $view_path ) ) {
				require $view_path;
			}
		}

		/**
		 * Return onboarding status.
		 *
		 * @return WP_REST_Response
		 */
		public function get_status() {
			return rest_ensure_response( $this->build_status() );
		}

		/**
		 * Install and activate the Shoptimizer child theme.
		 *
		 * @return WP_REST_Response|WP_Error
		 */
		public function setup_child_theme() {
			$child_theme = $this->get_child_theme_status();

			if ( $child_theme['active'] ) {
				$this->set_saved_step_state( 'child-theme', 'completed' );
				return rest_ensure_response( $this->build_status() );
			}

			if ( $child_theme['installed'] ) {
				if ( ! current_user_can( 'switch_themes' ) ) {
					return new WP_Error(
						'shoptimizer_onboarding_child_theme_switch_forbidden',
						esc_html__( 'You do not have permission to activate themes.', 'shoptimizer' ),
						array( 'status' => 403 )
					);
				}

				switch_theme( $child_theme['stylesheet'] );
				$this->set_saved_step_state( 'child-theme', 'completed' );

				return rest_ensure_response( $this->build_status() );
			}

			if ( ! current_user_can( 'install_themes' ) ) {
				return new WP_Error(
					'shoptimizer_onboarding_child_theme_install_forbidden',
					esc_html__( 'You do not have permission to install themes.', 'shoptimizer' ),
					array( 'status' => 403 )
				);
			}

			$package_url = $this->get_child_theme_package_url();

			if ( ! $package_url ) {
				return new WP_Error(
					'shoptimizer_onboarding_child_theme_package_missing',
					esc_html__( 'The child theme zip URL is not configured yet.', 'shoptimizer' ),
					array( 'status' => 400 )
				);
			}

			$this->load_theme_install_functions();

			$skin     = new Automatic_Upgrader_Skin();
			$upgrader = new Theme_Upgrader( $skin );
			$result   = $upgrader->install( $package_url );

			wp_clean_themes_cache( true );

			if ( is_wp_error( $result ) ) {
				return new WP_Error(
					'shoptimizer_onboarding_child_theme_install_failed',
					$result->get_error_message(),
					array( 'status' => 500 )
				);
			}

			if ( is_wp_error( $skin->result ) ) {
				return new WP_Error(
					'shoptimizer_onboarding_child_theme_install_failed',
					$skin->result->get_error_message(),
					array( 'status' => 500 )
				);
			}

			$child_theme = $this->get_child_theme_status();

			if ( ! $child_theme['installed'] ) {
				return new WP_Error(
					'shoptimizer_onboarding_child_theme_install_failed',
					esc_html__( 'The child theme could not be installed.', 'shoptimizer' ),
					array( 'status' => 500 )
				);
			}

			if ( current_user_can( 'switch_themes' ) ) {
				switch_theme( $child_theme['stylesheet'] );
			}

			$child_theme = $this->get_child_theme_status();

			if ( $child_theme['active'] ) {
				$this->set_saved_step_state( 'child-theme', 'completed' );
			}

			return rest_ensure_response( $this->build_status() );
		}

		/**
		 * Clear locally stored font files and related Kirki Google Font transients.
		 *
		 * @return WP_REST_Response|WP_Error
		 */
		public function clear_font_cache() {
			global $wpdb;

			if ( ! current_user_can( 'manage_options' ) ) {
				return new WP_Error(
					'shoptimizer_onboarding_font_cache_forbidden',
					esc_html__( 'You do not have permission to clear the font cache.', 'shoptimizer' ),
					array( 'status' => 403 )
				);
			}

			include_once ABSPATH . 'wp-admin/includes/class-wp-filesystem-base.php';
			include_once ABSPATH . 'wp-admin/includes/class-wp-filesystem-direct.php';

			$file_system    = new WP_Filesystem_Direct( false );
			$fonts_dir      = WP_CONTENT_DIR . '/fonts';
			$font_dir_found = is_dir( $fonts_dir );
			$prefix         = '%transient_kirki_googlefont%';
			$prefix_timeout = '%transient_timeout_kirki_googlefont%';

			// This is a prepared, targeted deletion of the Kirki font transients; cache deletion is not applicable.
			$wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
				$wpdb->prepare(
					"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s",
					$prefix,
					$prefix_timeout
				)
			);

			// Clear the caches used by Shoptimizer's Typography 2.0 font loader as
			// well as Kirki's local downloader. Removing only the files leaves these
			// maps and preload URLs pointing at stale or missing font files.
			delete_site_option( 'downloaded_font_files' );
			delete_option( 'kirki_downloaded_font_files' );
			delete_option( 'shoptimizer_preload_woffs' );
			delete_transient( 'kirki_remote_url_contents' );
			delete_site_transient( 'kirki_googlefonts_cache' );
			delete_site_transient( 'kirki_googlefont_names_cache' );

			if ( $font_dir_found && ! $file_system->rmdir( $fonts_dir, true ) ) {
				return new WP_Error(
					'shoptimizer_onboarding_font_cache_failed',
					esc_html__( 'The font cache directory could not be removed.', 'shoptimizer' ),
					array( 'status' => 500 )
				);
			}

			return rest_ensure_response(
				array(
					'message' => $font_dir_found ? esc_html__( 'Font cache cleared.', 'shoptimizer' ) : esc_html__( 'No local font cache was found. Google Font transients were cleared.', 'shoptimizer' ),
				)
			);
		}

		/**
		 * Activate an installed recommended plugin.
		 *
		 * @param WP_REST_Request $request REST request.
		 * @return WP_REST_Response|WP_Error
		 */
		public function activate_plugin( $request ) {
			$slug = $request->get_param( 'slug' );

			if ( ! isset( $this->recommended_plugins[ $slug ] ) ) {
				return new WP_Error(
					'shoptimizer_onboarding_invalid_plugin',
					esc_html__( 'This plugin is not part of the Shoptimizer onboarding flow.', 'shoptimizer' ),
					array( 'status' => 400 )
				);
			}

			$plugin      = $this->recommended_plugins[ $slug ];
			$plugin_file = WP_PLUGIN_DIR . '/' . $plugin['file'];

			if ( ! file_exists( $plugin_file ) ) {
				return new WP_Error(
					'shoptimizer_onboarding_plugin_missing',
					esc_html__( 'This plugin is not installed yet.', 'shoptimizer' ),
					array( 'status' => 404 )
				);
			}

			$this->load_plugin_functions();

			if ( is_plugin_active( $plugin['file'] ) ) {
				if ( $this->are_recommended_plugins_active() ) {
					$this->set_saved_step_state( 'plugins', 'completed' );
				}

				return rest_ensure_response( $this->build_status() );
			}

			$result = activate_plugin( $plugin['file'] );

			if ( is_wp_error( $result ) ) {
				return new WP_Error(
					'shoptimizer_onboarding_activation_failed',
					$result->get_error_message(),
					array( 'status' => 500 )
				);
			}

			if ( $this->are_recommended_plugins_active() ) {
				$this->set_saved_step_state( 'plugins', 'completed' );
			}

			return rest_ensure_response( $this->build_status() );
		}

		/**
		 * Install and activate a recommended plugin.
		 *
		 * @param WP_REST_Request $request REST request.
		 * @return WP_REST_Response|WP_Error
		 */
		public function install_plugin( $request ) {
			$slug = $request->get_param( 'slug' );

			if ( ! isset( $this->recommended_plugins[ $slug ] ) ) {
				return new WP_Error(
					'shoptimizer_onboarding_invalid_plugin',
					esc_html__( 'This plugin is not part of the Shoptimizer onboarding flow.', 'shoptimizer' ),
					array( 'status' => 400 )
				);
			}

			$plugin = $this->recommended_plugins[ $slug ];

			if ( file_exists( WP_PLUGIN_DIR . '/' . $plugin['file'] ) ) {
				return $this->activate_plugin( $request );
			}

			$download_url = $this->get_plugin_download_url( $slug, $plugin );

			if ( is_wp_error( $download_url ) ) {
				return $download_url;
			}

			$this->load_plugin_install_functions();

			$skin     = new Automatic_Upgrader_Skin();
			$upgrader = new Plugin_Upgrader( $skin );
			$result   = $upgrader->install( $download_url );

			wp_clean_plugins_cache( false );

			if ( is_wp_error( $result ) ) {
				return new WP_Error(
					'shoptimizer_onboarding_install_failed',
					$result->get_error_message(),
					array( 'status' => 500 )
				);
			}

			if ( is_wp_error( $skin->result ) ) {
				return new WP_Error(
					'shoptimizer_onboarding_install_failed',
					$skin->result->get_error_message(),
					array( 'status' => 500 )
				);
			}

			if ( ! $result || ! file_exists( WP_PLUGIN_DIR . '/' . $plugin['file'] ) ) {
				return new WP_Error(
					'shoptimizer_onboarding_install_failed',
					esc_html__( 'The plugin could not be installed. Please try again from the WordPress plugin installer.', 'shoptimizer' ),
					array( 'status' => 500 )
				);
			}

			return $this->activate_plugin( $request );
		}

		/**
		 * Save brand settings to their existing WordPress/Shoptimizer settings.
		 *
		 * @param WP_REST_Request $request REST request.
		 * @return WP_REST_Response|WP_Error
		 */
		public function save_brand_settings( $request ) {
			$primary_color = sanitize_hex_color( $request->get_param( 'primary_color' ) );
			$logo_id       = absint( $request->get_param( 'logo_id' ) );
			$site_icon_id  = absint( $request->get_param( 'site_icon_id' ) );

			if ( ! $primary_color ) {
				return new WP_Error(
					'shoptimizer_onboarding_invalid_primary_color',
					esc_html__( 'Please choose a valid primary color.', 'shoptimizer' ),
					array( 'status' => 400 )
				);
			}

			if ( $logo_id && ! $this->is_valid_image_attachment( $logo_id ) ) {
				return new WP_Error(
					'shoptimizer_onboarding_invalid_logo',
					esc_html__( 'Please choose a valid image for the logo.', 'shoptimizer' ),
					array( 'status' => 400 )
				);
			}

			if ( $site_icon_id && ! $this->is_valid_image_attachment( $site_icon_id ) ) {
				return new WP_Error(
					'shoptimizer_onboarding_invalid_site_icon',
					esc_html__( 'Please choose a valid image for the site icon.', 'shoptimizer' ),
					array( 'status' => 400 )
				);
			}

			set_theme_mod( 'shoptimizer_color_general_swatch', $primary_color );

			if ( $logo_id ) {
				set_theme_mod( 'custom_logo', $logo_id );
			} else {
				remove_theme_mod( 'custom_logo' );
			}

			if ( $site_icon_id ) {
				update_option( 'site_icon', $site_icon_id );
			} else {
				delete_option( 'site_icon' );
			}

			$this->set_saved_step_state( 'brand', 'completed' );

			return rest_ensure_response( $this->build_status() );
		}

		/**
		 * Save the selected static homepage.
		 *
		 * @param WP_REST_Request $request REST request.
		 * @return WP_REST_Response|WP_Error
		 */
		public function save_homepage_settings( $request ) {
			$page_id = absint( $request->get_param( 'page_id' ) );
			$page    = get_post( $page_id );

			if ( ! $page || 'page' !== $page->post_type || 'publish' !== $page->post_status ) {
				return new WP_Error(
					'shoptimizer_onboarding_invalid_homepage',
					esc_html__( 'Please choose a published page for your homepage.', 'shoptimizer' ),
					array( 'status' => 400 )
				);
			}

			update_option( 'show_on_front', 'page' );
			update_option( 'page_on_front', $page_id );
			$this->set_saved_step_state( 'homepage', 'completed' );

			return rest_ensure_response( $this->build_status() );
		}

		/**
		 * Build read-only onboarding status data.
		 *
		 * @return array
		 */
		private function build_status() {
			$quick_setup = $this->get_quick_setup_status();

			return array(
				'enabled'     => true,
				'admin_url'   => admin_url( 'themes.php?page=' . self::PAGE_SLUG ),
				'docs_url'    => 'https://www.commercegurus.com/docs/shoptimizer-theme/',
				'tgmpa_url'   => admin_url( 'themes.php?page=tgmpa-install-plugins' ),
				'demo_url'    => admin_url( 'themes.php?page=shoptimizer-demo' ),
				'plugins'     => $this->get_plugin_statuses(),
				'brand'       => $this->get_brand_status(),
				'theme'       => array(
					'child_theme' => $this->get_child_theme_status(),
				),
				'site'        => array(
					'home_url'          => home_url( '/' ),
					'show_on_front'     => get_option( 'show_on_front' ),
					'page_on_front'     => (int) get_option( 'page_on_front' ),
					'page_for_posts'    => (int) get_option( 'page_for_posts' ),
					'permalink_enabled' => (bool) get_option( 'permalink_structure' ),
					'pages'             => $this->get_homepage_options(),
				),
				'onboarding'  => array(
					'complete'       => (bool) get_option( 'shoptimizer_onboarding_complete', false ),
					'steps'          => wp_list_pluck( $quick_setup['tasks'], 'state', 'id' ),
					'has_skipped'    => $quick_setup['skipped'] > 0,
					'has_unresolved' => $quick_setup['needs_attention'] > 0,
					'all_complete'   => $quick_setup['completed'] === $quick_setup['total'],
				),
				'demo'        => array(
					'available'     => class_exists( 'Shoptimizer_Demo_Import' ),
					'imported'      => (bool) get_option( 'shoptimizer_onboarding_demo_imported', false ),
					'plugins_ready' => $this->are_recommended_plugins_active(),
					'can_import'    => current_user_can( 'import' ),
					'page_url'      => admin_url( 'themes.php?page=shoptimizer-demo' ),
				),
				'quick_setup' => $quick_setup,
			);
		}

		/**
		 * Get published pages available for homepage selection.
		 *
		 * @return array
		 */
		private function get_homepage_options() {
			$pages = get_pages(
				array(
					'sort_column' => 'post_title',
					'sort_order'  => 'ASC',
					'post_status' => 'publish',
				)
			);

			return array_map(
				function ( $page ) {
					return array(
						'id'    => (int) $page->ID,
						'title' => get_the_title( $page->ID ),
						'url'   => get_permalink( $page->ID ),
					);
				},
				$pages
			);
		}

		/**
		 * Get dashboard quick setup status.
		 *
		 * @return array
		 */
		private function get_quick_setup_status() {
			$plugins_active = $this->are_recommended_plugins_active();
			$brand          = $this->get_brand_status();
			$child_theme    = $this->get_child_theme_status();
			$demo_imported  = (bool) get_option( 'shoptimizer_onboarding_demo_imported', false );
			$homepage_set   = 'page' === get_option( 'show_on_front' ) && (bool) get_option( 'page_on_front' );
			$saved_states   = $this->get_saved_step_states();
			$states         = array(
				'child-theme' => $this->resolve_step_state( 'child-theme', $child_theme['active'], $saved_states ),
				'plugins'     => $this->resolve_step_state( 'plugins', $plugins_active, $saved_states ),
				'demo'        => $this->resolve_step_state( 'demo', $demo_imported, $saved_states ),
				'brand'       => $this->resolve_step_state( 'brand', $this->is_brand_setup_complete( $brand ), $saved_states, true ),
				'homepage'    => $this->resolve_step_state( 'homepage', $homepage_set, $saved_states ),
			);
			$tasks          = array(
				array(
					'id'          => 'child-theme',
					'title'       => esc_html__( 'Install the Shoptimizer child theme', 'shoptimizer' ),
					'description' => esc_html__( 'Keep custom code separate from parent theme updates.', 'shoptimizer' ),
					'state'       => $states['child-theme'],
					'complete'    => 'completed' === $states['child-theme'],
					'action'      => 'child_theme',
					'actionLabel' => $this->get_child_theme_action_label( $child_theme ),
					'disabled'    => ! $child_theme['active'] && ! $child_theme['installed'] && ! $child_theme['package_url_configured'],
				),
				array(
					'id'          => 'plugins',
					'title'       => esc_html__( 'Install recommended plugins', 'shoptimizer' ),
					'description' => esc_html__( 'Prepare WooCommerce, CommerceKit, and Elementor.', 'shoptimizer' ),
					'state'       => $states['plugins'],
					'complete'    => 'completed' === $states['plugins'],
					'action'      => 'view_step',
					'step'        => 'plugins',
					'actionLabel' => $plugins_active ? esc_html__( 'Review', 'shoptimizer' ) : esc_html__( 'Review plugins', 'shoptimizer' ),
					'disabled'    => false,
				),
				array(
					'id'          => 'demo',
					'title'       => esc_html__( 'Import demo content', 'shoptimizer' ),
					'description' => esc_html__( 'Start with a ready-made store layout, or skip this step.', 'shoptimizer' ),
					'state'       => $states['demo'],
					'complete'    => 'completed' === $states['demo'],
					'action'      => 'view_step',
					'step'        => 'demo',
					'actionLabel' => esc_html__( 'Choose demo', 'shoptimizer' ),
					'disabled'    => false,
				),
				array(
					'id'          => 'brand',
					'title'       => esc_html__( 'Add brand details', 'shoptimizer' ),
					'description' => esc_html__( 'Set your primary color, logo, and site icon.', 'shoptimizer' ),
					'state'       => $states['brand'],
					'complete'    => 'completed' === $states['brand'],
					'action'      => 'view_step',
					'step'        => 'brand',
					'actionLabel' => esc_html__( 'Edit brand', 'shoptimizer' ),
					'disabled'    => false,
				),
				array(
					'id'          => 'homepage',
					'title'       => esc_html__( 'Set your homepage', 'shoptimizer' ),
					'description' => esc_html__( 'Choose the page visitors see first.', 'shoptimizer' ),
					'state'       => $states['homepage'],
					'complete'    => 'completed' === $states['homepage'],
					'action'      => 'view_step',
					'step'        => 'homepage',
					'actionLabel' => esc_html__( 'Set homepage', 'shoptimizer' ),
					'disabled'    => false,
				),
			);

			$completed       = count(
				array_filter(
					$tasks,
					function ( $task ) {
						return ! empty( $task['complete'] );
					}
				)
			);
			$skipped         = count(
				array_filter(
					$tasks,
					function ( $task ) {
						return 'skipped' === $task['state'];
					}
				)
			);
			$needs_attention = count( $tasks ) - $completed - $skipped;

			return array(
				'completed'       => $completed,
				'skipped'         => $skipped,
				'needs_attention' => $needs_attention,
				'resolved'        => $completed + $skipped,
				'total'           => count( $tasks ),
				'tasks'           => $tasks,
			);
		}

		/**
		 * Get valid onboarding step names.
		 *
		 * @return array
		 */
		private function get_onboarding_step_names() {
			return array( 'child-theme', 'plugins', 'demo', 'brand', 'homepage' );
		}

		/**
		 * Get persisted onboarding step states.
		 *
		 * @return array
		 */
		private function get_saved_step_states() {
			$saved_states = get_option( self::STEP_STATES_OPTION, array() );
			$valid_states = array( 'completed', 'skipped', 'needs_attention' );

			if ( ! is_array( $saved_states ) ) {
				return array();
			}

			$saved_states = array_intersect_key( $saved_states, array_flip( $this->get_onboarding_step_names() ) );

			return array_filter(
				$saved_states,
				function ( $state ) use ( $valid_states ) {
					return in_array( $state, $valid_states, true );
				}
			);
		}

		/**
		 * Persist one onboarding step state.
		 *
		 * @param string $step  Onboarding step.
		 * @param string $state Onboarding step state.
		 * @return void
		 */
		private function set_saved_step_state( $step, $state ) {
			if (
				! in_array( $step, $this->get_onboarding_step_names(), true ) ||
				! in_array( $state, array( 'completed', 'skipped', 'needs_attention' ), true )
			) {
				return;
			}

			$saved_states          = $this->get_saved_step_states();
			$saved_states[ $step ] = $state;

			update_option( self::STEP_STATES_OPTION, $saved_states );
		}

		/**
		 * Resolve a step state from live data and persisted user intent.
		 *
		 * @param string $step                    Onboarding step.
		 * @param bool   $is_complete             Whether the underlying task is complete.
		 * @param array  $saved_states            Persisted step states.
		 * @param bool   $allow_explicit_complete Whether an accepted default can count as complete.
		 * @return string
		 */
		private function resolve_step_state( $step, $is_complete, $saved_states, $allow_explicit_complete = false ) {
			$saved_state = isset( $saved_states[ $step ] ) ? $saved_states[ $step ] : '';

			if ( 'needs_attention' === $saved_state ) {
				return 'needs_attention';
			}

			if ( $is_complete || ( $allow_explicit_complete && 'completed' === $saved_state ) ) {
				return 'completed';
			}

			if ( 'skipped' === $saved_state ) {
				return 'skipped';
			}

			return 'needs_attention';
		}

		/**
		 * Get current brand settings from existing theme/core settings.
		 *
		 * @return array
		 */
		private function get_brand_status() {
			$default_primary_color = $this->get_default_primary_color();
			$primary_color         = function_exists( 'shoptimizer_get_option' ) ? shoptimizer_get_option( 'shoptimizer_color_general_swatch' ) : get_theme_mod( 'shoptimizer_color_general_swatch', $default_primary_color );
			$logo_id               = absint( get_theme_mod( 'custom_logo' ) );
			$site_icon_id          = absint( get_option( 'site_icon' ) );

			$sanitized_primary_color = sanitize_hex_color( $primary_color );

			return array(
				'primary_color'         => $sanitized_primary_color ? $sanitized_primary_color : $default_primary_color,
				'default_primary_color' => $default_primary_color,
				'logo'                  => $this->get_image_setting_status( $logo_id ),
				'site_icon'             => $this->get_image_setting_status( $site_icon_id ),
			);
		}

		/**
		 * Check whether enough brand settings have been added for quick setup.
		 *
		 * @param array $brand Brand status.
		 * @return bool
		 */
		private function is_brand_setup_complete( $brand ) {
			$has_custom_color = ! empty( $brand['primary_color'] ) && ! empty( $brand['default_primary_color'] ) && $brand['primary_color'] !== $brand['default_primary_color'];
			$has_logo         = ! empty( $brand['logo']['id'] );
			$has_site_icon    = ! empty( $brand['site_icon']['id'] );

			return $has_custom_color || $has_logo || $has_site_icon;
		}

		/**
		 * Get the current Shoptimizer child theme status.
		 *
		 * @return array
		 */
		private function get_child_theme_status() {
			$themes           = wp_get_themes();
			$stylesheet       = $this->get_child_theme_stylesheet( $themes );
			$installed        = $stylesheet && isset( $themes[ $stylesheet ] );
			$active           = $installed && get_stylesheet() === $stylesheet;
			$package_url      = $this->get_child_theme_package_url();
			$current_theme    = wp_get_theme();
			$current_parent   = $current_theme->parent();
			$current_is_child = $current_parent && 'shoptimizer' === $current_parent->get_stylesheet();

			if ( ! $active && $current_is_child ) {
				$stylesheet = get_stylesheet();
				$installed  = true;
				$active     = true;
			}

			return array(
				'stylesheet'             => $stylesheet ? $stylesheet : $this->get_preferred_child_theme_stylesheet(),
				'installed'              => (bool) $installed,
				'active'                 => (bool) $active,
				'package_url_configured' => (bool) $package_url,
				'actions'                => array(
					'install'  => ! $installed && (bool) $package_url && current_user_can( 'install_themes' ),
					'activate' => $installed && ! $active && current_user_can( 'switch_themes' ),
				),
			);
		}

		/**
		 * Get the preferred child theme stylesheet.
		 *
		 * @return string
		 */
		private function get_preferred_child_theme_stylesheet() {
			return defined( 'SHOPTIMIZER_CHILD_THEME_STYLESHEET' ) ? sanitize_key( SHOPTIMIZER_CHILD_THEME_STYLESHEET ) : 'shoptimizer-child';
		}

		/**
		 * Find an installed Shoptimizer child theme.
		 *
		 * @param array $themes Installed themes.
		 * @return string
		 */
		private function get_child_theme_stylesheet( $themes ) {
			$preferred = $this->get_preferred_child_theme_stylesheet();

			if ( isset( $themes[ $preferred ] ) ) {
				return $preferred;
			}

			foreach ( $themes as $stylesheet => $theme ) {
				if ( 'shoptimizer' === $theme->get( 'Template' ) ) {
					return $stylesheet;
				}
			}

			return $preferred;
		}

		/**
		 * Get the Shoptimizer child theme package URL.
		 *
		 * @return string
		 */
		private function get_child_theme_package_url() {
			return esc_url_raw( 'https://files.commercegurus.com/shoptimizer-child/shoptimizer-child-theme.zip' );
		}

		/**
		 * Get the child theme action label.
		 *
		 * @param array $child_theme Child theme status.
		 * @return string
		 */
		private function get_child_theme_action_label( $child_theme ) {
			if ( $child_theme['active'] ) {
				return esc_html__( 'Done', 'shoptimizer' );
			}

			if ( $child_theme['installed'] ) {
				return esc_html__( 'Activate child theme', 'shoptimizer' );
			}

			return esc_html__( 'Install child theme', 'shoptimizer' );
		}

		/**
		 * Get the Shoptimizer primary color default.
		 *
		 * @return string
		 */
		private function get_default_primary_color() {
			$defaults = function_exists( 'shoptimizer_get_option_defaults' ) ? shoptimizer_get_option_defaults() : array();

			return isset( $defaults['shoptimizer_color_general_swatch'] ) ? $defaults['shoptimizer_color_general_swatch'] : '#dc9814';
		}

		/**
		 * Get image attachment data for onboarding controls.
		 *
		 * @param int $attachment_id Attachment ID.
		 * @return array
		 */
		private function get_image_setting_status( $attachment_id ) {
			if ( ! $attachment_id || ! $this->is_valid_image_attachment( $attachment_id ) ) {
				return array(
					'id'        => 0,
					'url'       => '',
					'thumbnail' => '',
					'title'     => '',
				);
			}

			$thumbnail = wp_get_attachment_image_url( $attachment_id, 'thumbnail' );
			$url       = wp_get_attachment_image_url( $attachment_id, 'full' );

			return array(
				'id'        => $attachment_id,
				'url'       => $url ? $url : '',
				'thumbnail' => $thumbnail ? $thumbnail : $url,
				'title'     => get_the_title( $attachment_id ),
			);
		}

		/**
		 * Check that an attachment exists and is an image.
		 *
		 * @param int $attachment_id Attachment ID.
		 * @return bool
		 */
		private function is_valid_image_attachment( $attachment_id ) {
			return 'attachment' === get_post_type( $attachment_id ) && wp_attachment_is_image( $attachment_id );
		}

		/**
		 * Get status for recommended plugins.
		 *
		 * @return array
		 */
		private function get_plugin_statuses() {
			$plugins = array();

			foreach ( $this->recommended_plugins as $slug => $plugin ) {
				$plugins[] = $this->get_plugin_status( $slug, $plugin );
			}

			return $plugins;
		}

		/**
		 * Check whether all recommended plugins are active.
		 *
		 * @return bool
		 */
		private function are_recommended_plugins_active() {
			foreach ( $this->get_plugin_statuses() as $plugin ) {
				if ( empty( $plugin['active'] ) ) {
					return false;
				}
			}

			return true;
		}

		/**
		 * Get status for a single plugin.
		 *
		 * @param string $slug   Plugin slug.
		 * @param array  $plugin Plugin definition.
		 * @return array
		 */
		private function get_plugin_status( $slug, $plugin ) {
			$plugin_file = WP_PLUGIN_DIR . '/' . $plugin['file'];
			$installed   = file_exists( $plugin_file );
			$this->load_plugin_functions();
			$active  = $installed && $this->is_plugin_active( $plugin['file'] );
			$version = '';

			if ( $installed && function_exists( 'get_plugin_data' ) ) {
				$plugin_data = get_plugin_data( $plugin_file, false, false );
				$version     = isset( $plugin_data['Version'] ) ? $plugin_data['Version'] : '';
			}

			if ( $active ) {
				$status       = 'active';
				$status_label = esc_html__( 'Active', 'shoptimizer' );
			} elseif ( $installed ) {
				$status       = 'installed';
				$status_label = esc_html__( 'Installed, inactive', 'shoptimizer' );
			} else {
				$status       = 'missing';
				$status_label = esc_html__( 'Not installed', 'shoptimizer' );
			}

			return array(
				'slug'         => $slug,
				'name'         => $plugin['name'],
				'description'  => isset( $plugin['description'] ) ? $plugin['description'] : '',
				'badge'        => isset( $plugin['badge'] ) ? $plugin['badge'] : '',
				'icon_label'   => isset( $plugin['icon_label'] ) ? $plugin['icon_label'] : '',
				'icon_url'     => ! empty( $plugin['icon'] ) ? get_template_directory_uri() . '/inc/onboarding/images/' . $plugin['icon'] : '',
				'file'         => $plugin['file'],
				'installed'    => $installed,
				'active'       => $active,
				'status'       => $status,
				'status_label' => $status_label,
				'version'      => $version,
				'manage_url'   => isset( $plugin['manage_path'] ) ? admin_url( $plugin['manage_path'] ) : admin_url( 'plugins.php' ),
				'actions'      => array(
					'activate' => $installed && ! $active && current_user_can( 'activate_plugins' ),
					'install'  => ! $installed && current_user_can( 'install_plugins' ),
					'manage'   => $active,
					'update'   => false,
				),
			);
		}

		/**
		 * Wrapper for is_plugin_active().
		 *
		 * @param string $plugin Plugin file.
		 * @return bool
		 */
		private function is_plugin_active( $plugin ) {
			$this->load_plugin_functions();

			return is_plugin_active( $plugin );
		}

		/**
		 * Load WordPress plugin helper functions when needed.
		 *
		 * @return void
		 */
		private function load_plugin_functions() {
			if ( ! function_exists( 'is_plugin_active' ) || ! function_exists( 'get_plugin_data' ) ) {
				require_once ABSPATH . 'wp-admin/includes/plugin.php';
			}
		}

		/**
		 * Load WordPress plugin install helper functions.
		 *
		 * @return void
		 */
		private function load_plugin_install_functions() {
			$this->load_plugin_functions();

			require_once ABSPATH . 'wp-admin/includes/file.php';
			require_once ABSPATH . 'wp-admin/includes/plugin-install.php';
			require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
		}

		/**
		 * Load WordPress theme install helper functions.
		 *
		 * @return void
		 */
		private function load_theme_install_functions() {
			require_once ABSPATH . 'wp-admin/includes/file.php';
			require_once ABSPATH . 'wp-admin/includes/theme.php';
			require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
		}

		/**
		 * Get the package URL for a plugin.
		 *
		 * @param string $slug   Plugin slug.
		 * @param array  $plugin Plugin definition.
		 * @return string|WP_Error
		 */
		private function get_plugin_download_url( $slug, $plugin ) {
			if ( 'wordpress.org' !== $plugin['source'] ) {
				return esc_url_raw( $plugin['source'] );
			}

			require_once ABSPATH . 'wp-admin/includes/plugin-install.php';

			$api = plugins_api(
				'plugin_information',
				array(
					'slug'   => $slug,
					'fields' => array(
						'sections' => false,
					),
				)
			);

			if ( is_wp_error( $api ) ) {
				return new WP_Error(
					'shoptimizer_onboarding_plugin_api_failed',
					$api->get_error_message(),
					array( 'status' => 500 )
				);
			}

			if ( empty( $api->download_link ) ) {
				return new WP_Error(
					'shoptimizer_onboarding_plugin_package_missing',
					esc_html__( 'WordPress could not find a plugin package to install.', 'shoptimizer' ),
					array( 'status' => 500 )
				);
			}

			return esc_url_raw( $api->download_link );
		}
	}
}
