<?php
/**
 * Child theme setup step.
 *
 * @package Shoptimizer
 */

defined( 'ABSPATH' ) || exit;
?>
<section class="shoptimizer-step" data-step="child-theme">
	<div class="shoptimizer-step-heading">
		<p><?php esc_html_e( 'Safe customization', 'shoptimizer' ); ?></p>
		<h2><?php esc_html_e( 'Install the Shoptimizer child theme', 'shoptimizer' ); ?></h2>
	</div>
	<p><?php esc_html_e( 'A child theme is recommended if you plan to add custom code. It keeps your customizations separate from the parent theme, so Shoptimizer updates are safer.', 'shoptimizer' ); ?></p>
	<div class="shoptimizer-child-theme-notice" data-child-theme-notice role="status" hidden></div>
	<div class="shoptimizer-child-theme-panel" data-child-theme-panel></div>
</section>
