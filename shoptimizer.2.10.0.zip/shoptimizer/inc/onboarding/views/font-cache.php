<?php
/**
 * Onboarding font cache view.
 *
 * @package Shoptimizer
 */

defined( 'ABSPATH' ) || exit;
?>
<section class="shoptimizer-view" data-view="fonts">
	<div class="shoptimizer-font-cache-panel">
		<p class="shoptimizer-kicker"><?php esc_html_e( 'Local fonts', 'shoptimizer' ); ?></p>
		<h1><?php esc_html_e( 'Clear font cache', 'shoptimizer' ); ?></h1>
		<p><?php esc_html_e( 'Shoptimizer stores Google Fonts locally on your server to help with GDPR compliance and performance.', 'shoptimizer' ); ?></p>
		<p><?php esc_html_e( 'If fonts selected in the Customizer are not displaying correctly, clear the font cache and let Shoptimizer rebuild it. This is safe to do on production sites.', 'shoptimizer' ); ?></p>
		<div class="shoptimizer-action-row">
			<button class="button button-primary button-hero" type="button" data-font-cache-clear><?php esc_html_e( 'Clear cache', 'shoptimizer' ); ?></button>
			<span class="shoptimizer-font-cache-status" data-font-cache-status role="status" hidden></span>
		</div>
	</div>
</section>
