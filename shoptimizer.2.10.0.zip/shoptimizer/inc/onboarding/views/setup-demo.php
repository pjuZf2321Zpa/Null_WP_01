<?php
/**
 * Demo content setup step.
 *
 * @package Shoptimizer
 */

defined( 'ABSPATH' ) || exit;
?>
<section class="shoptimizer-step" data-step="demo">
	<div class="shoptimizer-step-heading">
		<p><?php esc_html_e( 'Starter content', 'shoptimizer' ); ?></p>
		<h2><?php esc_html_e( 'Choose a starting point for your store', 'shoptimizer' ); ?></h2>
	</div>
	<p><?php esc_html_e( 'We highly recommend importing the demo content to get started quickly — it gives you a ready-made store layout with products you can customize. You can skip this step and import content later.', 'shoptimizer' ); ?></p>
	<div class="shoptimizer-demo-notice" data-demo-notice role="status" hidden></div>
	<div class="shoptimizer-demo-groups" data-demo-options>
		<div class="shoptimizer-demo-group">
			<div class="shoptimizer-demo-options">
				<button class="shoptimizer-demo-card" type="button" data-demo-option="standard" aria-pressed="false">
					<span class="shoptimizer-demo-card-header">
						<span>
							<span class="shoptimizer-demo-card-title">
								<strong><?php esc_html_e( 'Standard demo', 'shoptimizer' ); ?></strong>
								<span class="shoptimizer-demo-recommended"><?php esc_html_e( 'Recommended', 'shoptimizer' ); ?></span>
							</span>
							<em><?php esc_html_e( 'A complete store: products, pages, menus, and homepage.', 'shoptimizer' ); ?></em>
						</span>
						<span class="shoptimizer-demo-status-tag" data-demo-imported-tag hidden><?php esc_html_e( 'Imported', 'shoptimizer' ); ?></span>
					</span>
					<span class="shoptimizer-demo-preview">
						<img src="<?php echo esc_url( get_template_directory_uri() . '/inc/onboarding/images/shoptimizer-minimal.jpg' ); ?>" alt="<?php esc_attr_e( 'Shoptimizer standard demo preview', 'shoptimizer' ); ?>" loading="lazy" />
					</span>
				</button>
				<button class="shoptimizer-demo-card is-blank" type="button" data-demo-option="skip" aria-pressed="false">
					<span class="shoptimizer-demo-card-header">
						<span>
							<strong><?php esc_html_e( 'Start from scratch', 'shoptimizer' ); ?></strong>
							<em><?php esc_html_e( 'Skip the demo and build your store your own way.', 'shoptimizer' ); ?></em>
						</span>
					</span>
					<span class="shoptimizer-demo-preview">
						<img src="<?php echo esc_url( get_template_directory_uri() . '/inc/onboarding/images/shoptimizer-empty.jpg' ); ?>" alt="<?php esc_attr_e( 'Empty Shoptimizer store preview', 'shoptimizer' ); ?>" loading="lazy" />
					</span>
				</button>
			</div>
		</div>
	</div>
	<div class="shoptimizer-demo-progress" data-demo-progress role="status" hidden>
		<div class="shoptimizer-demo-progress-bar" aria-hidden="true"><span></span></div>
		<p class="shoptimizer-demo-progress-stage" data-demo-progress-stage></p>
		<p class="shoptimizer-demo-progress-warning"><?php esc_html_e( 'Please keep this tab open and don’t refresh while the import runs.', 'shoptimizer' ); ?></p>
	</div>
</section>
