<?php
/**
 * Homepage setup step.
 *
 * @package Shoptimizer
 */

defined( 'ABSPATH' ) || exit;
?>
<section class="shoptimizer-step" data-step="homepage">
	<div class="shoptimizer-step-heading">
		<p><?php esc_html_e( 'Homepage setup', 'shoptimizer' ); ?></p>
		<h2><?php esc_html_e( 'Choose your homepage', 'shoptimizer' ); ?></h2>
	</div>
	<p><?php esc_html_e( 'Select the page visitors should see when they arrive at your store. The preview updates automatically when you choose a different page.', 'shoptimizer' ); ?></p>
	<div class="shoptimizer-homepage-notice" data-homepage-notice role="status" hidden></div>
	<div class="shoptimizer-homepage-panel" data-homepage-status>
		<div class="shoptimizer-homepage-control">
			<label for="shoptimizer-homepage-select"><?php esc_html_e( 'Select homepage', 'shoptimizer' ); ?></label>
			<select id="shoptimizer-homepage-select" data-homepage-select></select>
		</div>
		<div class="shoptimizer-homepage-preview" data-homepage-preview hidden>
			<div class="shoptimizer-homepage-browser">
				<div class="shoptimizer-homepage-browser-bar" aria-hidden="true">
					<div class="shoptimizer-homepage-browser-lights">
						<span></span>
						<span></span>
						<span></span>
					</div>
					<div class="shoptimizer-homepage-browser-url" data-homepage-preview-url></div>
				</div>
				<div class="shoptimizer-homepage-browser-viewport" data-homepage-preview-viewport>
					<iframe title="<?php esc_attr_e( 'Homepage preview', 'shoptimizer' ); ?>" data-homepage-preview-frame loading="lazy"></iframe>
				</div>
			</div>
		</div>
		<div class="shoptimizer-homepage-empty" data-homepage-empty>
			<?php esc_html_e( 'Select a published page to preview it here.', 'shoptimizer' ); ?>
		</div>
	</div>
</section>
