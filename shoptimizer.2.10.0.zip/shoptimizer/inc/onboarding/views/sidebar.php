<?php
/**
 * Onboarding primary sidebar view.
 *
 * @package Shoptimizer
 */

defined( 'ABSPATH' ) || exit;

$shoptimizer_theme_version = isset( $args['theme_version'] ) ? $args['theme_version'] : '';
?>
<aside class="shoptimizer-onboarding-primary">
	<a class="shoptimizer-back-link" href="<?php echo esc_url( admin_url() ); ?>">
		<span class="dashicon dashicons dashicons-wordpress" aria-hidden="true"></span>
		<span class="shoptimizer-back-link-label"><?php esc_html_e( 'Back to Dashboard', 'shoptimizer' ); ?></span>
	</a>

	<div class="shoptimizer-primary-copy" data-view-copy="welcome">
		<h1>
			<a class="shoptimizer-title-back" href="<?php echo esc_url( admin_url() ); ?>" aria-label="<?php esc_attr_e( 'Back to dashboard', 'shoptimizer' ); ?>">
				<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" focusable="false">
					<path stroke-linecap="round" stroke-linejoin="round" d="M15.75 19.5 8.25 12l7.5-7.5" />
				</svg>
			</a>
			<?php esc_html_e( 'Welcome to Shoptimizer', 'shoptimizer' ); ?>
		</h1>
		<p><?php esc_html_e( 'Set up the essentials for a fast WooCommerce store, then continue refining everything in WordPress.', 'shoptimizer' ); ?></p>
	</div>
	<div class="shoptimizer-primary-copy" data-view-copy="setup" hidden>
		<h1>
			<a class="shoptimizer-title-back" href="<?php echo esc_url( admin_url() ); ?>" aria-label="<?php esc_attr_e( 'Back to dashboard', 'shoptimizer' ); ?>">
				<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" focusable="false">
					<path stroke-linecap="round" stroke-linejoin="round" d="M15.75 19.5 8.25 12l7.5-7.5" />
				</svg>
			</a>
			<?php esc_html_e( 'Theme setup', 'shoptimizer' ); ?>
		</h1>
		<p><?php esc_html_e( 'Install the recommended plugins, choose starter content, add your brand, and review launch links.', 'shoptimizer' ); ?></p>
	</div>
	<div class="shoptimizer-primary-copy" data-view-copy="fonts" hidden>
		<h1>
			<a class="shoptimizer-title-back" href="<?php echo esc_url( admin_url() ); ?>" aria-label="<?php esc_attr_e( 'Back to dashboard', 'shoptimizer' ); ?>">
				<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" focusable="false">
					<path stroke-linecap="round" stroke-linejoin="round" d="M15.75 19.5 8.25 12l7.5-7.5" />
				</svg>
			</a>
			<?php esc_html_e( 'Clear font cache', 'shoptimizer' ); ?>
		</h1>
		<p><?php esc_html_e( 'Refresh locally stored Google Fonts if typography chosen in the Customizer is not displaying correctly.', 'shoptimizer' ); ?></p>
	</div>
	<div class="shoptimizer-primary-copy" data-view-copy="docs" hidden>
		<h1>
			<a class="shoptimizer-title-back" href="<?php echo esc_url( admin_url() ); ?>" aria-label="<?php esc_attr_e( 'Back to dashboard', 'shoptimizer' ); ?>">
				<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" focusable="false">
					<path stroke-linecap="round" stroke-linejoin="round" d="M15.75 19.5 8.25 12l7.5-7.5" />
				</svg>
			</a>
			<?php esc_html_e( 'Documentation', 'shoptimizer' ); ?>
		</h1>
		<p><?php esc_html_e( 'Find setup guides and answers for the most common Shoptimizer questions.', 'shoptimizer' ); ?></p>
	</div>
	<div class="shoptimizer-primary-copy" data-view-copy="recommended" hidden>
		<h1>
			<a class="shoptimizer-title-back" href="<?php echo esc_url( admin_url() ); ?>" aria-label="<?php esc_attr_e( 'Back to dashboard', 'shoptimizer' ); ?>">
				<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" focusable="false">
					<path stroke-linecap="round" stroke-linejoin="round" d="M15.75 19.5 8.25 12l7.5-7.5" />
				</svg>
			</a>
			<?php esc_html_e( 'Recommended plugins', 'shoptimizer' ); ?>
		</h1>
		<p><?php esc_html_e( 'A selection of optional tools recommended by CommerceGurus to complement Shoptimizer and CommerceKit.', 'shoptimizer' ); ?></p>
	</div>

	<nav class="shoptimizer-primary-nav" aria-label="<?php esc_attr_e( 'Onboarding navigation', 'shoptimizer' ); ?>">
		<span class="shoptimizer-primary-nav-label"><?php esc_html_e( 'Setup', 'shoptimizer' ); ?></span>
		<button class="is-active" type="button" data-view-target="welcome">
			<span aria-hidden="true">
				<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" focusable="false">
					<path stroke-linecap="round" stroke-linejoin="round" d="m2.25 12 8.954-8.955c.44-.439 1.152-.439 1.591 0L21.75 12M4.5 9.75v10.125c0 .621.504 1.125 1.125 1.125H9.75v-4.875c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21h4.125c.621 0 1.125-.504 1.125-1.125V9.75M8.25 21h8.25" />
				</svg>
			</span>
			<?php esc_html_e( 'Welcome', 'shoptimizer' ); ?>
		</button>
		<button type="button" data-view-target="setup">
			<span aria-hidden="true">
				<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" focusable="false">
					<path stroke-linecap="round" stroke-linejoin="round" d="M8.25 6.75h12M8.25 12h12m-12 5.25h12M3.75 6.75h.007v.008H3.75V6.75Zm.375 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0ZM3.75 12h.007v.008H3.75V12Zm.375 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Zm-.375 5.25h.007v.008H3.75v-.008Zm.375 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Z" />
				</svg>
			</span>
			<?php esc_html_e( 'Theme setup', 'shoptimizer' ); ?>
		</button>
		<span class="shoptimizer-primary-nav-label"><?php esc_html_e( 'Tools', 'shoptimizer' ); ?></span>
		<button type="button" data-view-target="fonts">
			<span aria-hidden="true">
				<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" focusable="false">
					<path stroke-linecap="round" stroke-linejoin="round" d="M11.42 15.17 17.25 21A2.652 2.652 0 0 0 21 17.25l-5.877-5.877M11.42 15.17l2.496-3.03c.317-.384.74-.626 1.208-.766M11.42 15.17l-4.655 5.653a2.548 2.548 0 1 1-3.586-3.586l6.837-5.63m5.108-.233c.55-.164 1.163-.188 1.743-.14a4.5 4.5 0 0 0 4.486-6.336l-3.276 3.277a3.004 3.004 0 0 1-2.25-2.25l3.276-3.276a4.5 4.5 0 0 0-6.336 4.486c.091 1.076-.071 2.264-.904 2.95l-.102.085m-1.745 1.437L5.909 7.5H4.5L2.25 3.75l1.5-1.5L7.5 4.5v1.409l4.26 4.26m-1.745 1.437 1.745-1.437m6.615 8.206L15.75 15.75M4.867 19.125h.008v.008h-.008v-.008Z" />
				</svg>
			</span>
			<?php esc_html_e( 'Clear font cache', 'shoptimizer' ); ?>
		</button>
		<span class="shoptimizer-primary-nav-label"><?php esc_html_e( 'Resources', 'shoptimizer' ); ?></span>
		<button type="button" data-view-target="recommended">
			<span aria-hidden="true">
				<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" focusable="false">
					<path stroke-linecap="round" stroke-linejoin="round" d="M9.568 3.058c.427-1.757 2.923-1.757 3.35 0a1.724 1.724 0 0 0 2.573 1.066c1.545-.94 3.31.826 2.37 2.37a1.724 1.724 0 0 0 1.065 2.573c1.757.427 1.757 2.923 0 3.35a1.724 1.724 0 0 0-1.066 2.573c.94 1.545-.826 3.31-2.37 2.37a1.724 1.724 0 0 0-2.573 1.065c-.427 1.757-2.923 1.757-3.35 0a1.724 1.724 0 0 0-2.573-1.066c-1.545.94-3.31-.826-2.37-2.37a1.724 1.724 0 0 0-1.065-2.573c-1.757-.427-1.757-2.923 0-3.35a1.724 1.724 0 0 0 1.066-2.573c-.94-1.545.826-3.31 2.37-2.37.996.608 2.296.07 2.573-1.065Z" />
					<path stroke-linecap="round" stroke-linejoin="round" d="M14.25 10.5a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
				</svg>
			</span>
			<?php esc_html_e( 'Recommended plugins', 'shoptimizer' ); ?>
		</button>
		<button type="button" data-view-target="docs">
			<span aria-hidden="true">
				<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" focusable="false">
					<path stroke-linecap="round" stroke-linejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 0 0-3.375-3.375h-1.5A1.125 1.125 0 0 1 13.5 7.125v-1.5a3.375 3.375 0 0 0-3.375-3.375H8.25m0 12.75h7.5m-7.5 3H12M10.5 2.25H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 0 0-9-9Z" />
				</svg>
			</span>
			<?php esc_html_e( 'Documentation', 'shoptimizer' ); ?>
		</button>
	</nav>
	<div class="shoptimizer-sidebar-footer">
		<div class="shoptimizer-sidebar-footer-links">
			<a href="https://www.commercegurus.com/docs/shoptimizer-theme/" target="_blank" rel="noopener"><?php esc_html_e( 'Docs', 'shoptimizer' ); ?></a>
			<a href="https://www.commercegurus.com/contact/" target="_blank" rel="noopener"><?php esc_html_e( 'Support', 'shoptimizer' ); ?></a>
		</div>
		<span>
			<?php
			printf(
				/* translators: %s: Shoptimizer version. */
				esc_html__( 'Version %s', 'shoptimizer' ),
				esc_html( $shoptimizer_theme_version )
			);
			?>
		</span>
	</div>
</aside>
