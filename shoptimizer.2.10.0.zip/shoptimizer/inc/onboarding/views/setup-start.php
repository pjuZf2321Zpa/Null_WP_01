<?php
/**
 * Theme setup introduction step.
 *
 * @package Shoptimizer
 */

defined( 'ABSPATH' ) || exit;
?>
<section class="shoptimizer-step is-active" data-step="start">
	<div class="shoptimizer-step-heading">
		<p><?php esc_html_e( 'Theme setup', 'shoptimizer' ); ?></p>
		<h2><?php esc_html_e( 'Set up your store', 'shoptimizer' ); ?></h2>
	</div>
	<p><?php esc_html_e( 'This setup guides you through the essentials: plugins, starter content, branding, homepage setup, and useful launch links. It takes about 5 minutes. Every step is optional and can be skipped — you can change all of these settings later from the WordPress admin or the Customizer.', 'shoptimizer' ); ?></p>
	<button class="button button-primary button-hero" type="button" data-start-steps><?php esc_html_e( 'Get started', 'shoptimizer' ); ?></button>
</section>
