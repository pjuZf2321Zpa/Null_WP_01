<?php
/**
 * Onboarding shell view.
 *
 * @package Shoptimizer
 */

defined( 'ABSPATH' ) || exit;

$shoptimizer_commercekit_url   = isset( $args['commercekit_url'] ) ? $args['commercekit_url'] : '#setup/plugins';
$shoptimizer_commercekit_label = isset( $args['commercekit_label'] ) ? $args['commercekit_label'] : __( 'Set up CommerceKit', 'shoptimizer' );
$shoptimizer_theme_version     = isset( $args['theme_version'] ) ? $args['theme_version'] : '';
?>
<div class="shoptimizer-onboarding-app is-welcome-view" data-shoptimizer-onboarding>
	<?php $this->render_view( 'sidebar', array( 'theme_version' => $shoptimizer_theme_version ) ); ?>

	<div class="shoptimizer-onboarding-content">
		<main class="shoptimizer-onboarding-stage">
			<div class="shoptimizer-onboarding-scroll">
				<?php
				$this->render_view(
					'welcome',
					array(
						'commercekit_url'   => $shoptimizer_commercekit_url,
						'commercekit_label' => $shoptimizer_commercekit_label,
					)
				);
				$this->render_view( 'setup' );
				$this->render_view( 'documentation' );
				$this->render_view( 'recommended-plugins' );
				$this->render_view( 'font-cache' );
				?>
			</div>
		</main>
	</div>
</div>
