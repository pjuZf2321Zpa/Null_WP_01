<?php
/**
 * Onboarding dashboard view.
 *
 * @package Shoptimizer
 */

defined( 'ABSPATH' ) || exit;
?>
<section class="shoptimizer-view is-active" data-view="welcome">
	<div class="shoptimizer-welcome-hero">
		<div class="shoptimizer-dashboard-copy">
			<img class="shoptimizer-dashboard-logo" src="<?php echo esc_url( get_template_directory_uri() . '/inc/onboarding/images/shoptimizer-logo.png' ); ?>" alt="<?php esc_attr_e( 'Shoptimizer', 'shoptimizer' ); ?>" />
			<h1><?php esc_html_e( 'Welcome to your new, fast, conversion-optimized store!', 'shoptimizer' ); ?></h1>
			<p><?php esc_html_e( 'You’re starting with a performance-first WooCommerce foundation shaped by extensive Baymard Institute eCommerce UX research and proven conversion best practices. Complete the essentials below, then make the store unmistakably yours.', 'shoptimizer' ); ?></p>
			<div class="shoptimizer-dashboard-actions">
				<button class="button button-primary button-hero" type="button" data-start-setup><?php esc_html_e( 'Start theme setup', 'shoptimizer' ); ?></button>
				<a href="https://www.commercegurus.com/docs/shoptimizer-theme/" target="_blank" rel="noopener">
					<?php esc_html_e( 'View documentation', 'shoptimizer' ); ?>
					<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" aria-hidden="true" focusable="false">
						<path stroke-linecap="round" stroke-linejoin="round" d="M13.5 4.5 21 12m0 0-7.5 7.5M21 12H3" />
					</svg>
				</a>
			</div>
		</div>
		<div class="shoptimizer-dashboard-preview" aria-hidden="true">
			<img src="<?php echo esc_url( get_template_directory_uri() . '/inc/onboarding/images/shoptimizer-screenshot.jpg' ); ?>" alt="" loading="lazy" />
		</div>
	</div>
	<div class="shoptimizer-quick-setup" data-quick-setup>
		<div class="shoptimizer-quick-setup-header">
			<div>
				<p class="shoptimizer-kicker"><?php esc_html_e( 'Quick setup', 'shoptimizer' ); ?></p>
				<h3><?php esc_html_e( 'Complete the essentials', 'shoptimizer' ); ?></h3>
				<p><?php esc_html_e( 'Use this checklist to track the main setup tasks and jump back into the wizard when something still needs attention.', 'shoptimizer' ); ?></p>
			</div>
			<span class="shoptimizer-quick-setup-count" data-quick-setup-count></span>
		</div>
		<div class="shoptimizer-quick-setup-progress" aria-hidden="true">
			<span data-quick-setup-progress></span>
		</div>
		<div class="shoptimizer-quick-setup-notice" data-quick-setup-notice role="status" hidden></div>
		<div class="shoptimizer-quick-setup-list" data-quick-setup-list></div>
	</div>
	<div class="shoptimizer-welcome-cards">
		<article class="shoptimizer-recommendation-card shoptimizer-dashboard-feature-card">
			<div class="shoptimizer-recommendation-icon is-turbo" aria-hidden="true">
				<img src="<?php echo esc_url( get_template_directory_uri() . '/inc/onboarding/images/commercegurus-turbo.png' ); ?>" alt="" />
			</div>
			<span class="shoptimizer-recommendation-category"><?php esc_html_e( 'Performance', 'shoptimizer' ); ?></span>
			<h3><?php esc_html_e( 'CommerceGurus Turbo', 'shoptimizer' ); ?></h3>
			<p><?php esc_html_e( 'Speed up your WooCommerce store with page caching, asset optimization, image improvements, and safe performance defaults.', 'shoptimizer' ); ?></p>
			<a href="https://www.commercegurus.com/product/commercegurus-turbo/?utm_source=shoptimizer&amp;utm_medium=onboarding&amp;utm_campaign=dashboard&amp;utm_content=commercegurus_turbo" target="_blank" rel="noopener"><?php esc_html_e( 'Learn more', 'shoptimizer' ); ?></a>
		</article>
		<article class="shoptimizer-recommendation-card shoptimizer-dashboard-feature-card">
			<div class="shoptimizer-recommendation-icon is-commercekit" aria-hidden="true">
				<img src="<?php echo esc_url( get_template_directory_uri() . '/inc/onboarding/images/commercekit.png' ); ?>" alt="" />
			</div>
			<span class="shoptimizer-recommendation-category"><?php esc_html_e( 'Included with Shoptimizer', 'shoptimizer' ); ?></span>
			<h3><?php esc_html_e( 'CommerceKit', 'shoptimizer' ); ?></h3>
			<p><?php esc_html_e( 'Enable search suggestions, attribute swatches, waitlists, order bumps, enhanced product galleries, and lots more!', 'shoptimizer' ); ?></p>
			<a href="<?php echo esc_url( $args['commercekit_url'] ); ?>"><?php echo esc_html( $args['commercekit_label'] ); ?></a>
		</article>
		<article class="shoptimizer-recommendation-card shoptimizer-dashboard-feature-card">
			<div class="shoptimizer-recommendation-icon is-documentation" aria-hidden="true">
				<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" focusable="false">
					<path stroke-linecap="round" stroke-linejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 0 0-3.375-3.375h-1.5A1.125 1.125 0 0 1 13.5 7.125v-1.5a3.375 3.375 0 0 0-3.375-3.375H8.25m0 12.75h7.5m-7.5 3H12M10.5 2.25H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 0 0-9-9Z" />
				</svg>
			</div>
			<span class="shoptimizer-recommendation-category"><?php esc_html_e( 'Help and guidance', 'shoptimizer' ); ?></span>
			<h3><?php esc_html_e( 'Documentation', 'shoptimizer' ); ?></h3>
			<p><?php esc_html_e( 'Find detailed guidance for installation, theme options, CommerceKit features, and common setup questions.', 'shoptimizer' ); ?></p>
			<a href="#docs"><?php esc_html_e( 'View documentation', 'shoptimizer' ); ?></a>
		</article>
	</div>
</section>
