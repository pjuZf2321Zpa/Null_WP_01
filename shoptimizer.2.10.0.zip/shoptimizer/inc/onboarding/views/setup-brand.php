<?php
/**
 * Brand setup step.
 *
 * @package Shoptimizer
 */

defined( 'ABSPATH' ) || exit;
?>
<section class="shoptimizer-step" data-step="brand">
	<div class="shoptimizer-step-heading">
		<p><?php esc_html_e( 'Brand setup', 'shoptimizer' ); ?></p>
		<h2><?php esc_html_e( 'Add your brand details', 'shoptimizer' ); ?></h2>
	</div>
	<p><?php esc_html_e( 'Set the main color, logo, and browser icon for your store. These are the same settings used by the WordPress Customizer, so changes made here stay in sync.', 'shoptimizer' ); ?></p>
	<div class="shoptimizer-brand-notice" data-brand-notice role="status" hidden></div>
	<div class="shoptimizer-brand-list">
		<div class="shoptimizer-brand-row">
			<div>
				<h3><?php esc_html_e( 'Primary color', 'shoptimizer' ); ?></h3>
				<p><?php esc_html_e( 'Choose the main accent color used for prices, highlights, buttons, tabs, and other key theme elements.', 'shoptimizer' ); ?></p>
			</div>
			<div class="shoptimizer-brand-control">
				<div class="shoptimizer-color-control">
					<div class="shoptimizer-color-presets" role="group" aria-label="<?php esc_attr_e( 'Primary color presets', 'shoptimizer' ); ?>">
						<button type="button" data-brand-primary-preset="#1d2327" style="--preset-color: #1d2327;" aria-pressed="false"><span><?php esc_html_e( 'Charcoal', 'shoptimizer' ); ?></span></button>
						<button type="button" data-brand-primary-preset="#2271b1" style="--preset-color: #2271b1;" aria-pressed="false"><span><?php esc_html_e( 'Blue', 'shoptimizer' ); ?></span></button>
						<button type="button" data-brand-primary-preset="#2563eb" style="--preset-color: #2563eb;" aria-pressed="false"><span><?php esc_html_e( 'Royal blue', 'shoptimizer' ); ?></span></button>
						<button type="button" data-brand-primary-preset="#4f46e5" style="--preset-color: #4f46e5;" aria-pressed="false"><span><?php esc_html_e( 'Indigo', 'shoptimizer' ); ?></span></button>
						<button type="button" data-brand-primary-preset="#7c3aed" style="--preset-color: #7c3aed;" aria-pressed="false"><span><?php esc_html_e( 'Purple', 'shoptimizer' ); ?></span></button>
						<button type="button" data-brand-primary-preset="#c026d3" style="--preset-color: #c026d3;" aria-pressed="false"><span><?php esc_html_e( 'Magenta', 'shoptimizer' ); ?></span></button>
						<button type="button" data-brand-primary-preset="#dc9814" style="--preset-color: #dc9814;" aria-pressed="false"><span><?php esc_html_e( 'Shoptimizer orange', 'shoptimizer' ); ?></span></button>
					</div>
					<div class="shoptimizer-color-custom">
						<span class="shoptimizer-color-custom-label"><?php esc_html_e( 'Custom', 'shoptimizer' ); ?></span>
						<input type="color" value="#dc9814" data-brand-primary-color aria-label="<?php esc_attr_e( 'Primary color', 'shoptimizer' ); ?>" />
						<input type="text" value="#dc9814" maxlength="7" data-brand-primary-color-text aria-label="<?php esc_attr_e( 'Primary color hex value', 'shoptimizer' ); ?>" />
					</div>
				</div>
				<button class="button button-secondary" type="button" data-brand-reset-color><?php esc_html_e( 'Reset default', 'shoptimizer' ); ?></button>
			</div>
		</div>

		<div class="shoptimizer-brand-row">
			<div>
				<h3><?php esc_html_e( 'Logo', 'shoptimizer' ); ?></h3>
				<p><?php esc_html_e( 'Upload the logo visitors will see in your store header. If no logo is set, WordPress will show your site title instead.', 'shoptimizer' ); ?></p>
			</div>
			<div class="shoptimizer-brand-control">
				<div class="shoptimizer-image-preview" data-brand-preview="logo" hidden>
					<img alt="<?php esc_attr_e( 'Selected logo preview', 'shoptimizer' ); ?>" data-brand-preview-image hidden />
				</div>
				<div class="shoptimizer-brand-buttons">
					<button class="button button-secondary" type="button" data-brand-select-image="logo"><?php esc_html_e( 'Select image', 'shoptimizer' ); ?></button>
					<button class="button button-link-delete" type="button" data-brand-remove-image="logo" hidden><?php esc_html_e( 'Remove', 'shoptimizer' ); ?></button>
				</div>
			</div>
		</div>

		<div class="shoptimizer-brand-row">
			<div>
				<h3><?php esc_html_e( 'Site icon', 'shoptimizer' ); ?></h3>
				<p><?php esc_html_e( 'Choose the small square icon shown in browser tabs, bookmarks, and mobile shortcuts.', 'shoptimizer' ); ?></p>
			</div>
			<div class="shoptimizer-brand-control">
				<div class="shoptimizer-image-preview is-site-icon" data-brand-preview="site_icon" hidden>
					<div class="shoptimizer-site-icon-browser" aria-hidden="true">
						<div class="shoptimizer-site-icon-title-bar">
							<div class="shoptimizer-site-icon-traffic-lights">
								<span class="is-red"></span>
								<span class="is-yellow"></span>
								<span class="is-green"></span>
							</div>
							<div class="shoptimizer-site-icon-tab">
								<span class="shoptimizer-site-icon-favicon">
									<img alt="" data-brand-preview-image hidden />
								</span>
								<span class="shoptimizer-site-icon-site-name"><?php echo esc_html( get_bloginfo( 'name' ) ? get_bloginfo( 'name' ) : __( 'Company name', 'shoptimizer' ) ); ?></span>
							</div>
						</div>
						<div class="shoptimizer-site-icon-toolbar">
							<div class="shoptimizer-site-icon-nav">
								<span>
									<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" aria-hidden="true" focusable="false">
										<path stroke-linecap="round" stroke-linejoin="round" d="M10.5 19.5 3 12m0 0 7.5-7.5M3 12h18" />
									</svg>
								</span>
								<span class="is-disabled">
									<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" aria-hidden="true" focusable="false">
										<path stroke-linecap="round" stroke-linejoin="round" d="M13.5 4.5 21 12m0 0-7.5 7.5M21 12H3" />
									</svg>
								</span>
								<span>
									<svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" focusable="false">
										<path d="M12 20c-2.21665 0-4.10415-.77915-5.6625-2.3375C4.779165 16.10415 4 14.21665 4 12c0-2.21665.779165-4.10415 2.3375-5.6625C7.89585 4.779165 9.78335 4 12 4c1.41665 0 2.65835.2875 3.725.8625 1.06665.575 1.99165 1.3625 2.775 2.3625V4.75c0-.216665.07085-.395835.2125-.5375C18.85415 4.070835 19.03335 4 19.25 4c.21665 0 .39585.070835.5375.2125.14165.141665.2125.320835.2125.5375v4.85c0 .21665-.07085.39585-.2125.5375s-.32085.2125-.5375.2125H14.4c-.21665 0-.39585-.07085-.5375-.2125s-.2125-.32085-.2125-.5375c0-.21665.07085-.39585.2125-.5375s.32085-.2125.5375-.2125h3.45c-.63335-1-1.44165-1.80835-2.425-2.425C14.44165 5.80835 13.3 5.5 12 5.5c-1.81665 0-3.35415.62915-4.6125 1.8875C6.12915 8.64585 5.5 10.18335 5.5 12c0 1.81665.62915 3.35415 1.8875 4.6125C8.64585 17.87085 10.18335 18.5 12 18.5c1.25 0 2.41665-.32915 3.5-.9875 1.08335-.65835 1.89165-1.54585 2.425-2.6625.08335-.18335.22085-.32085.4125-.4125.19165-.09165.37915-.09585.5625-.0125.2.08335.33335.22085.4.4125.06665.19165.05835.3875-.025.5875-.65 1.4-1.62915 2.5125-2.9375 3.3375C15.02915 19.5875 13.58335 20 12 20Z" />
									</svg>
								</span>
							</div>
							<div class="shoptimizer-site-icon-url"><?php echo esc_html( wp_parse_url( home_url(), PHP_URL_HOST ) ? wp_parse_url( home_url(), PHP_URL_HOST ) : 'companyname.com' ); ?></div>
						</div>
					</div>
				</div>
				<div class="shoptimizer-brand-buttons">
					<button class="button button-secondary" type="button" data-brand-select-image="site_icon"><?php esc_html_e( 'Select image', 'shoptimizer' ); ?></button>
					<button class="button button-link-delete" type="button" data-brand-remove-image="site_icon" hidden><?php esc_html_e( 'Remove', 'shoptimizer' ); ?></button>
				</div>
			</div>
		</div>
	</div>
</section>
