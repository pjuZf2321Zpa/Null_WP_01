<?php
/**
 * Theme setup finish step.
 *
 * @package Shoptimizer
 */

defined( 'ABSPATH' ) || exit;
?>
<section class="shoptimizer-step" data-step="finish">
	<div data-finish-default>
		<div class="shoptimizer-step-heading">
			<p><?php esc_html_e( 'Finish', 'shoptimizer' ); ?></p>
			<h2 data-finish-title><?php esc_html_e( 'Setup complete — your store is ready', 'shoptimizer' ); ?></h2>
		</div>
		<p data-finish-copy><?php esc_html_e( 'Your store foundation is ready. Review the front end, then refine your branding, products, and checkout settings.', 'shoptimizer' ); ?></p>
	</div>
	<div class="shoptimizer-finish-notice" data-finish-notice role="status" hidden></div>
	<div class="shoptimizer-action-row shoptimizer-finish-actions">
		<a class="button button-primary button-hero" href="<?php echo esc_url( home_url( '/' ) ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'View site', 'shoptimizer' ); ?></a>
		<a class="button button-secondary button-hero" href="<?php echo esc_url( admin_url( 'customize.php' ) ); ?>"><?php esc_html_e( 'Open customizer', 'shoptimizer' ); ?></a>
		<a class="button button-secondary button-hero" href="https://www.commercegurus.com/docs/shoptimizer-theme/" target="_blank" rel="noopener"><?php esc_html_e( 'Read documentation', 'shoptimizer' ); ?></a>
	</div>
</section>
