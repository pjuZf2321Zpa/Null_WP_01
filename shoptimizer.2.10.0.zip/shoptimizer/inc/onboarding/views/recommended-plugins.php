<?php
/**
 * Onboarding recommended plugins view.
 *
 * @package Shoptimizer
 */

defined( 'ABSPATH' ) || exit;
?>
<section class="shoptimizer-view" data-view="recommended">
	<div class="shoptimizer-recommendations-panel">
		<div class="shoptimizer-recommendations-intro">
			<p class="shoptimizer-kicker"><?php esc_html_e( 'Extend your store', 'shoptimizer' ); ?></p>
			<h2><?php esc_html_e( 'Recommended plugins for Shoptimizer stores', 'shoptimizer' ); ?></h2>
			<p><?php esc_html_e( 'Optional tools we recommend at CommerceGurus to complement Shoptimizer and CommerceKit.', 'shoptimizer' ); ?></p>
		</div>
		<div class="shoptimizer-recommendations-grid">
			<article class="shoptimizer-recommendation-card">
				<div class="shoptimizer-recommendation-icon is-turbo" aria-hidden="true">
					<img src="<?php echo esc_url( get_template_directory_uri() . '/inc/onboarding/images/commercegurus-turbo.png' ); ?>" alt="" />
				</div>
				<span class="shoptimizer-recommendation-category"><?php esc_html_e( 'Performance', 'shoptimizer' ); ?></span>
				<h3><?php esc_html_e( 'CommerceGurus Turbo', 'shoptimizer' ); ?></h3>
				<p><?php esc_html_e( 'WooCommerce-specific performance optimization with page caching, asset optimization, image improvements, and safe store defaults.', 'shoptimizer' ); ?></p>
				<a href="https://www.commercegurus.com/product/commercegurus-turbo/?utm_source=shoptimizer&amp;utm_medium=onboarding&amp;utm_campaign=recommended_plugins&amp;utm_content=commercegurus_turbo" target="_blank" rel="noopener"><?php esc_html_e( 'Learn more', 'shoptimizer' ); ?></a>
			</article>
			<article class="shoptimizer-recommendation-card">
				<div class="shoptimizer-recommendation-icon is-search-filter" aria-hidden="true">
					<img src="<?php echo esc_url( get_template_directory_uri() . '/inc/onboarding/images/search-filter.jpg' ); ?>" alt="" />
				</div>
				<span class="shoptimizer-recommendation-category"><?php esc_html_e( 'Product discovery', 'shoptimizer' ); ?></span>
				<h3><?php esc_html_e( 'Search & Filter', 'shoptimizer' ); ?></h3>
				<p><?php esc_html_e( 'Create advanced product filtering and search experiences using categories, attributes, taxonomies, and custom fields.', 'shoptimizer' ); ?></p>
				<a href="https://searchandfilter.com/?utm_source=shoptimizer&amp;utm_medium=onboarding&amp;utm_campaign=recommended_plugins&amp;utm_content=search_and_filter" target="_blank" rel="noopener"><?php esc_html_e( 'Learn more', 'shoptimizer' ); ?></a>
			</article>
			<article class="shoptimizer-recommendation-card">
				<div class="shoptimizer-recommendation-icon is-checkoutwc" aria-hidden="true">
					<img src="<?php echo esc_url( get_template_directory_uri() . '/inc/onboarding/images/checkoutwc.jpg' ); ?>" alt="" />
				</div>
				<span class="shoptimizer-recommendation-category"><?php esc_html_e( 'Checkout', 'shoptimizer' ); ?></span>
				<h3><?php esc_html_e( 'CheckoutWC', 'shoptimizer' ); ?></h3>
				<p><?php esc_html_e( 'Replace the standard WooCommerce checkout with a focused, mobile-friendly checkout experience designed to reduce friction.', 'shoptimizer' ); ?></p>
				<a href="https://www.checkoutwc.com/?utm_source=shoptimizer&amp;utm_medium=onboarding&amp;utm_campaign=recommended_plugins&amp;utm_content=checkoutwc" target="_blank" rel="noopener"><?php esc_html_e( 'Learn more', 'shoptimizer' ); ?></a>
			</article>
		</div>
	</div>
</section>
