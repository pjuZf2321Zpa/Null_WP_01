<?php
/**
 * Recommended plugin setup step.
 *
 * @package Shoptimizer
 */

defined( 'ABSPATH' ) || exit;
?>
<section class="shoptimizer-step" data-step="plugins">
	<div class="shoptimizer-step-heading">
		<p><?php esc_html_e( 'Store foundation', 'shoptimizer' ); ?></p>
		<h2><?php esc_html_e( 'Install the plugins Shoptimizer works best with', 'shoptimizer' ); ?></h2>
	</div>
	<p><?php esc_html_e( 'WooCommerce powers your store, CommerceKit adds conversion features, and Elementor supports page building capabilities. Install or activate anything missing before importing demo content.', 'shoptimizer' ); ?></p>
	<div class="shoptimizer-plugin-notice" data-plugin-notice role="status" hidden></div>
	<div class="shoptimizer-plugin-list" data-plugin-list></div>
</section>
