<?php
/**
 * Theme setup view.
 *
 * @package Shoptimizer
 */

defined( 'ABSPATH' ) || exit;
?>
<section class="shoptimizer-view" data-view="setup">
	<div class="shoptimizer-setup-shell">
		<aside class="shoptimizer-setup-sidebar">
			<h2><?php esc_html_e( 'Theme setup', 'shoptimizer' ); ?></h2>
			<p><?php esc_html_e( 'Work through the key Shoptimizer setup tasks in order.', 'shoptimizer' ); ?></p>
			<nav class="shoptimizer-setup-steps" aria-label="<?php esc_attr_e( 'Theme setup steps', 'shoptimizer' ); ?>">
				<button class="is-active" type="button" data-step-target="start"><?php esc_html_e( 'Get started', 'shoptimizer' ); ?></button>
				<button type="button" data-step-target="child-theme"><?php esc_html_e( 'Child theme', 'shoptimizer' ); ?></button>
				<button type="button" data-step-target="plugins"><?php esc_html_e( 'Plugins', 'shoptimizer' ); ?></button>
				<button type="button" data-step-target="demo"><?php esc_html_e( 'Demo content', 'shoptimizer' ); ?></button>
				<button type="button" data-step-target="brand"><?php esc_html_e( 'Brand', 'shoptimizer' ); ?></button>
				<button type="button" data-step-target="homepage"><?php esc_html_e( 'Homepage', 'shoptimizer' ); ?></button>
				<button type="button" data-step-target="finish"><?php esc_html_e( 'Finish', 'shoptimizer' ); ?></button>
			</nav>
		</aside>

		<div class="shoptimizer-setup-content">
			<?php
			$this->render_view( 'setup-start' );
			$this->render_view( 'setup-child-theme' );
			$this->render_view( 'setup-plugins' );
			$this->render_view( 'setup-demo' );
			$this->render_view( 'setup-brand' );
			$this->render_view( 'setup-homepage' );
			$this->render_view( 'setup-finish' );
			?>

			<div class="shoptimizer-setup-footer">
				<span class="shoptimizer-step-count" data-step-count hidden></span>
				<div class="shoptimizer-demo-selection" data-demo-selection hidden>
					<strong><?php esc_html_e( 'Selected import:', 'shoptimizer' ); ?></strong>
					<span data-demo-selection-label><?php esc_html_e( 'No demo selected', 'shoptimizer' ); ?></span>
				</div>
				<div class="shoptimizer-setup-footer-actions">
					<button class="shoptimizer-step-skip" type="button" data-step-skip hidden><?php esc_html_e( 'Skip this step', 'shoptimizer' ); ?></button>
					<button class="button button-secondary" type="button" data-step-prev><?php esc_html_e( 'Back', 'shoptimizer' ); ?></button>
					<button class="button button-primary" type="button" data-step-next><?php esc_html_e( 'Continue', 'shoptimizer' ); ?></button>
				</div>
			</div>
		</div>
	</div>
</section>
