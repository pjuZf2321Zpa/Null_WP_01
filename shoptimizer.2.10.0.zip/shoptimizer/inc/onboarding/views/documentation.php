<?php
/**
 * Onboarding documentation view.
 *
 * @package Shoptimizer
 */

defined( 'ABSPATH' ) || exit;
?>
<section class="shoptimizer-view" data-view="docs">
	<div class="shoptimizer-docs-panel">
		<p class="shoptimizer-kicker"><?php esc_html_e( 'Documentation', 'shoptimizer' ); ?></p>
		<h1><?php esc_html_e( 'Shoptimizer documentation', 'shoptimizer' ); ?></h1>
		<p><?php esc_html_e( 'Our website includes over 100 Shoptimizer documentation articles, including installation guidance, setup help, Customizer options, CommerceKit features, and answers to common support questions.', 'shoptimizer' ); ?></p>
		<div class="shoptimizer-action-row">
			<a class="button button-primary button-hero" href="https://www.commercegurus.com/docs/shoptimizer-theme/" target="_blank" rel="noopener"><?php esc_html_e( 'View Shoptimizer documentation', 'shoptimizer' ); ?></a>
			<a class="button button-secondary button-hero" href="https://www.commercegurus.com/contact/" target="_blank" rel="noopener"><?php esc_html_e( 'Contact support', 'shoptimizer' ); ?></a>
		</div>
	</div>
</section>
