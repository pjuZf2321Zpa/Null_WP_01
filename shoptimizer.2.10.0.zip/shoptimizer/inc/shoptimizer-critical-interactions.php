<?php
/**
 * Immediate, dependency-free header interactions.
 *
 * @package shoptimizer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Enqueue the small menu/cart shell before delayed theme scripts.
 *
 * @return void
 */
function shoptimizer_enqueue_critical_interactions() {
	wp_enqueue_script(
		'shoptimizer-critical-interactions',
		get_theme_file_uri( '/assets/js/critical-interactions.min.js' ),
		array(),
		SHOPTIMIZER_VERSION,
		array(
			'strategy'  => 'defer',
			'in_footer' => false,
		)
	);
}
add_action( 'wp_enqueue_scripts', 'shoptimizer_enqueue_critical_interactions', 5 );

/**
 * Keep the critical shell on its native deferred path in CG Turbo.
 *
 * @param array $exclusions Script-tag exclusion patterns.
 * @return array
 */
function shoptimizer_exclude_critical_interactions_from_turbo( $exclusions ) {
	$handle = 'shoptimizer-critical-interactions';

	if ( ! in_array( $handle, $exclusions, true ) ) {
		$exclusions[] = $handle;
	}

	return $exclusions;
}
add_filter( 'cgturbo_delay_scripts_exclusions', 'shoptimizer_exclude_critical_interactions_from_turbo' );
add_filter( 'cgturbo_defer_scripts_exclusions', 'shoptimizer_exclude_critical_interactions_from_turbo' );
