/**
 * Shoptimizer Mini Cart Quantity Script V2
 * Based on original minicart-quantity.js with improved security
 *
 * @package Shoptimizer
 */

(() => {
    let changEv = new Event('change');
    let sidebarEl = [];
    let timerId;
    let miniItems;
    const shopWidget = document.querySelector('.widget_shopping_cart');

    const shoptimizerDelayFunction = function(func, delay) {
        clearTimeout(timerId);
        timerId = setTimeout(func, delay);
    };

    function shoptimizerInitMiniCartQty() {
        if (!shopWidget) {
            return;
        }
        sidebarEl = [];
        miniItems = shopWidget.querySelectorAll('.shoptimizer-custom-quantity-mini-cart');
        miniItems.forEach(function(item) {
            const input = item.querySelector('input');
            const buttons = Array.from(item.querySelectorAll('.shoptimizer-custom-quantity-mini-cart_button'));
            
            if (input && buttons.length) {
                input.dataset.shoptimizerCommittedValue = input.value;
                sidebarEl.push({
                    qtInput: input,
                    qtButtons: buttons
                });
                
                // Add keyboard support
                buttons.forEach(btn => {
                    btn.addEventListener('keydown', function(e) {
                        if (e.key === 'Enter' || e.key === ' ') {
                            e.preventDefault();
                            this.click();
                        }
                    });
                });
                
                // Commit typed quantities only after the customer finishes editing.
                input.addEventListener('change', function() {
                    shoptimizerCommitMiniCartInput(this, item);
                });
                input.addEventListener('keydown', function(e) {
                    if (e.key === 'Enter') {
                        e.preventDefault();
                        shoptimizerCommitMiniCartInput(this, item);
                        this.blur();
                    }
                });
            }
        });
        
        sidebarEl.forEach(function(item) {
            item.qtButtons.forEach(function(btn) {
                btn.addEventListener('click', shoptimizerEachSideBtnListener);
            });
        });
    }

    function shoptimizerNormalizeMiniCartInput(input) {
        if (input.getAttribute('data-input-flexible') !== '1') {
            return;
        }

        let value = parseFloat(input.value);
        let minValue = parseFloat(input.getAttribute('min'));
        let maxValue = parseFloat(input.getAttribute('max'));
        if (!isNaN(maxValue)) {
            maxValue = Math.floor(maxValue);
        }
        const fallback = !isNaN(minValue) && minValue > 0 ? Math.ceil(minValue) : 1;

        value = isNaN(value) ? fallback : Math.floor(value);
        value = Math.max(fallback, value);
        if (!isNaN(maxValue)) {
            value = Math.min(maxValue, value);
        }
        input.value = value;
    }

    function shoptimizerCommitMiniCartInput(input, item) {
        shoptimizerNormalizeMiniCartInput(input);

        if (input.value === input.dataset.shoptimizerCommittedValue) {
            return;
        }

        input.dataset.shoptimizerCommittedValue = input.value;

        const announcement = document.createElement('div');
        announcement.setAttribute('aria-live', 'polite');
        announcement.setAttribute('class', 'screen-reader-text');
        announcement.textContent = `Quantity updated to ${input.value}`;
        item.appendChild(announcement);
        setTimeout(() => announcement.remove(), 1000);

        shoptimizerUpdateMiniCart();
    }

    /**
     * Return the number of decimal places in a numeric string, used so we can
     * round incremented values to the precision defined by the `step` attribute
     * (important for plugins like ATUM that allow decimal stock quantities).
     */
    function shoptimizerDecimalPlaces(numStr) {
        if (!numStr) {
            return 0;
        }
        const parts = String(numStr).split('.');
        return parts[1] ? parts[1].length : 0;
    }

    function shoptimizerEachSideBtnListener() {
        const item    = sidebarEl.find((el) => el.qtButtons.includes(this));
        let value     = parseFloat(item.qtInput.value);
        const stepAttr = item.qtInput.getAttribute('step');
        let step      = parseFloat(stepAttr);
        if (isNaN(step) || step <= 0) {
            step = 1;
        }
        let minValue  = parseFloat(item.qtInput.getAttribute('min'));
        let maxValue  = parseFloat(item.qtInput.getAttribute('max'));
        let fallback  = (!isNaN(minValue) && minValue > 0) ? minValue : step;
        value         = isNaN(value) ? fallback : value;
        const decimals = Math.max(shoptimizerDecimalPlaces(stepAttr), shoptimizerDecimalPlaces(item.qtInput.value));
        if (this.classList.contains('quantity-up')) {
            value += step;
            if (!isNaN(maxValue) && value > maxValue) {
                value = maxValue;
            }
        } else {
            value -= step;
            if (!isNaN(minValue) && value < minValue) {
                value = minValue;
            }
            // Never go below the step value (or min, if min is positive).
            if (value < fallback) {
                value = fallback;
            }
        }
        // Round to the precision of the step to avoid floating-point artefacts
        // like 0.1 + 0.2 = 0.30000000000000004.
        if (decimals > 0) {
            value = parseFloat(value.toFixed(decimals));
        }
        if (parseFloat(item.qtInput.value) !== value) {
            item.qtInput.value = value;
            item.qtInput.dispatchEvent(changEv);
        }
    }

    function shoptimizerUpdateMiniCart() {
        shoptimizerDelayFunction(function() {
            const formData = new FormData();
            const loader = document.querySelector('#ajax-loading');
            
            try {
                miniItems = document.querySelectorAll('.shoptimizer-custom-quantity-mini-cart');
                miniItems.forEach(function(item) {
                    const input = item.querySelector('input');
                    if (!input) return;
                    
                    // Use parseFloat so decimal quantities (e.g. ATUM) are preserved.
                    let qty = parseFloat(input.value);
                    if (isNaN(qty)) {
                        qty = 1;
                    }
                    const itemKey = input.getAttribute('data-cart_item_key');
                    if (itemKey) {
                        formData.append('data[' + itemKey + ']', qty);
                    }
                });
                
                if (loader) loader.style.display = 'block';
                
                formData.append('action', 'cg_shoptimizer_update_mini_cart');
                fetch(
                    woocommerce_params.ajax_url,
                    {
                        method: 'POST',
                        body: formData
                    }
                ).then(
                    function(response) {
                        return response.json().then(function(json) {
                            if (!response.ok || !json || !json.success) {
                                const errorText = json && json.data && json.data.message ? json.data.message : (typeof shoptimizer_mini_cart !== 'undefined' && shoptimizer_mini_cart.error_text ? shoptimizer_mini_cart.error_text : 'Cart update failed.');
                                throw new Error(errorText);
                            }
                            return json;
                        });
                    }
                ).then(
                    function() {
                        var wcfragment = new Event('wc_fragment_refresh');
                        document.body.dispatchEvent(wcfragment);
                        var wccart = document.querySelectorAll('form.woocommerce-cart-form input.qty, form.woocommerce-checkout');
                        if (0 < wccart.length) {
                            window.location.reload();
                        }
                    }
                ).catch(function(error) {
                    console.error('Cart update error:', error);
                    if (loader) loader.style.display = 'none';
                });
            } catch (error) {
                console.error('Cart update error:', error);
                if (loader) loader.style.display = 'none';
            }
        }, 600);
    }

    jQuery('body').on('wc_fragments_refreshed wc_fragments_loaded', shoptimizerInitMiniCartQty);
    shoptimizerInitMiniCartQty();
})();
