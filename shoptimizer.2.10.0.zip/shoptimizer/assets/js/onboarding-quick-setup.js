(function (window) {
	'use strict';

	window.ShoptimizerOnboardingApp.registerFeature('quickSetup', function (context) {
		var quickSetupList = context.app.querySelector('[data-quick-setup-list]');
		var quickSetupCount = context.app.querySelector('[data-quick-setup-count]');
		var quickSetupProgress = context.app.querySelector('[data-quick-setup-progress]');
		var quickSetupNotice = context.app.querySelector('[data-quick-setup-notice]');

		function render() {
			var status = context.getStatus();

			if (!quickSetupList || !status.quick_setup || !status.quick_setup.tasks) {
				return;
			}

			var completed = status.quick_setup.completed || 0;
			var total = status.quick_setup.total || status.quick_setup.tasks.length;

			quickSetupList.innerHTML = '';

			if (quickSetupCount) {
				quickSetupCount.textContent = context.sprintf(context.t('countOf', '%1$s of %2$s'), completed, total);
			}

			if (quickSetupProgress) {
				quickSetupProgress.style.width = total ? (completed / total * 100) + '%' : '0%';
			}

			status.quick_setup.tasks.forEach(function (task, index) {
				var taskState = task.state || (task.complete ? 'completed' : 'needs_attention');
				var stateClass = taskState === 'completed' ? 'is-complete' : 'is-' + taskState.replace('_', '-');
				var item = context.createElement('div', 'shoptimizer-quick-setup-item ' + stateClass);
				var markerText = taskState === 'completed' ? '✓' : taskState === 'skipped' ? '–' : String(index + 1);
				var marker = context.createElement('span', 'shoptimizer-quick-setup-marker', markerText);
				var content = context.createElement('div', 'shoptimizer-quick-setup-content');
				var actions = context.createElement('div', 'shoptimizer-quick-setup-actions');

				marker.setAttribute('aria-label', taskState === 'completed' ? context.t('done', 'Done') : taskState === 'skipped' ? context.t('skipped', 'Skipped') : context.t('needsAttention', 'Needs attention'));
				content.appendChild(context.createElement('strong', '', task.title));
				content.appendChild(context.createElement('span', '', task.description));

				if (taskState === 'completed') {
					actions.appendChild(context.createElement('span', 'shoptimizer-quick-setup-done', context.t('done', 'Done')));
				} else if (taskState === 'skipped') {
					actions.appendChild(context.createElement('span', 'shoptimizer-quick-setup-skipped', context.t('skipped', 'Skipped')));
					actions.appendChild(createButton(task));
				} else {
					actions.appendChild(createButton(task));
				}

				item.appendChild(marker);
				item.appendChild(content);
				item.appendChild(actions);
				quickSetupList.appendChild(item);
			});
		}

		function createButton(task) {
			var button = context.createElement('button', 'button button-secondary shoptimizer-quick-setup-button', task.actionLabel || context.t('continue', 'Continue'));
			button.type = 'button';
			button.disabled = !!task.disabled;
			button.setAttribute('data-quick-setup-action', task.action || '');

			if (task.step) {
				button.setAttribute('data-quick-setup-step', task.step);
			}

			button.addEventListener('click', function () {
				if (task.action === 'view_step') {
					context.openSetupStep(task.step);
					return;
				}

				if (task.action === 'child_theme' && context.features.childTheme) {
					context.features.childTheme.runAction(button, showNotice);
				}
			});

			return button;
		}

		function showNotice(message, type) {
			if (!quickSetupNotice) {
				return;
			}

			quickSetupNotice.hidden = false;
			quickSetupNotice.className = 'shoptimizer-quick-setup-notice is-' + type;
			quickSetupNotice.textContent = message;
		}

		function clearNotice() {
			if (!quickSetupNotice) {
				return;
			}

			quickSetupNotice.hidden = true;
			quickSetupNotice.textContent = '';
		}

		return {
			clearNotice: clearNotice,
			render: render,
			showNotice: showNotice
		};
	});
})(window);
