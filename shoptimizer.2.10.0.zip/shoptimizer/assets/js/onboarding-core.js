(function (window, document) {
	'use strict';

	var runtime = {
		features: {},

		registerFeature: function (name, factory) {
			runtime.features[name] = factory;
		},

		init: function () {
			var app = document.querySelector('[data-shoptimizer-onboarding]');

			if (!app || !window.shoptimizerOnboarding) {
				return;
			}

			var context = createContext(app);

			Object.keys(runtime.features).forEach(function (name) {
				context.features[name] = runtime.features[name](context) || {};
			});

			bindEvents(context);
			context.applyRoute(context.getRouteFromHash() || 'welcome', { moveFocus: false });
			context.normalizeRouteHash();
			context.refreshStatusAsync();
		}
	};

	function createContext(app) {
		var i18n = window.shoptimizerOnboarding.i18n || {};
		var context = {
			app: app,
			config: window.shoptimizerOnboarding,
			features: {},
			state: {
				activeView: 'welcome',
				activeStepIndex: 0,
				demoImportRunning: false,
				status: window.shoptimizerOnboarding.status,
				suppressHashChange: false
			},
			els: {
				viewButtons: Array.prototype.slice.call(app.querySelectorAll('[data-view-target]')),
				viewCopyBlocks: Array.prototype.slice.call(app.querySelectorAll('[data-view-copy]')),
				views: Array.prototype.slice.call(app.querySelectorAll('[data-view]')),
				stepButtons: Array.prototype.slice.call(app.querySelectorAll('[data-step-target]')),
				steps: Array.prototype.slice.call(app.querySelectorAll('[data-step]')),
				previousButton: app.querySelector('[data-step-prev]'),
				nextButton: app.querySelector('[data-step-next]'),
				skipButton: app.querySelector('[data-step-skip]'),
				stepCount: app.querySelector('[data-step-count]'),
				startSetupButton: app.querySelector('[data-start-setup]'),
				startStepsButton: app.querySelector('[data-start-steps]'),
				demoSelection: app.querySelector('[data-demo-selection]')
			},
			skippableSteps: ['child-theme', 'plugins', 'demo', 'brand', 'homepage']
		};

		context.t = function (key, fallback) {
			return Object.prototype.hasOwnProperty.call(i18n, key) ? i18n[key] : fallback;
		};

		context.sprintf = function (template) {
			var args = Array.prototype.slice.call(arguments, 1);

			return template.replace(/%(\d+)\$s|%s/g, function (match, index) {
				if (index) {
					return typeof args[index - 1] === 'undefined' ? match : String(args[index - 1]);
				}

				return typeof args[0] === 'undefined' ? match : String(args.shift());
			});
		};

		context.createElement = function (tag, className, text) {
			var element = document.createElement(tag);

			if (className) {
				element.className = className;
			}

			if (text) {
				element.textContent = text;
			}

			return element;
		};

		context.getStatus = function () {
			return context.state.status || {};
		};

		context.setStatus = function (status) {
			context.state.status = status || {};
		};

		context.getViewNames = function () {
			return context.els.views.map(function (view) {
				return view.getAttribute('data-view');
			});
		};

		context.getStepIndexByName = function (stepName) {
			var stepIndex = -1;

			context.els.steps.forEach(function (step, index) {
				if (step.getAttribute('data-step') === stepName) {
					stepIndex = index;
				}
			});

			return stepIndex;
		};

		context.getActiveStepName = function () {
			if (!context.els.steps[context.state.activeStepIndex]) {
				return '';
			}

			return context.els.steps[context.state.activeStepIndex].getAttribute('data-step');
		};

		context.getCurrentRoute = function () {
			if (context.state.activeView === 'setup') {
				return 'setup/' + context.getActiveStepName();
			}

			return context.state.activeView;
		};

		context.getRouteFromHash = function () {
			return window.location.hash.replace(/^#\/?/, '');
		};

		context.syncRoute = function () {
			var route = context.getCurrentRoute();

			if (context.getRouteFromHash() === route) {
				return;
			}

			context.state.suppressHashChange = true;
			window.location.hash = route;
		};

		context.normalizeRouteHash = function () {
			if (context.getRouteFromHash() !== context.getCurrentRoute() && window.history && window.history.replaceState) {
				window.history.replaceState(null, '', '#' + context.getCurrentRoute());
			}
		};

		context.hasUnsavedChanges = function () {
			return !!(
				context.features.brand &&
				context.features.brand.isDirty &&
				context.features.brand.isDirty()
			) || !!(
				context.features.homepage &&
				context.features.homepage.isDirty &&
				context.features.homepage.isDirty()
			);
		};

		context.discardUnsavedChanges = function () {
			if (context.features.brand && context.features.brand.discard) {
				context.features.brand.discard();
			}

			if (context.features.homepage && context.features.homepage.discard) {
				context.features.homepage.discard();
			}

			context.updateNextButtonLabel();
		};

		context.confirmDiscardUnsavedChanges = function () {
			if (!context.hasUnsavedChanges()) {
				return true;
			}

			if (!window.confirm(context.t('unsavedChangesConfirm', 'You have unsaved changes. Leave this step and discard them?'))) {
				return false;
			}

			context.discardUnsavedChanges();
			return true;
		};

		context.applyRoute = function (route, options) {
			options = options || {};

			var parts = (route || '').split('/');
			var viewName = parts[0] || 'welcome';

			if (context.getViewNames().indexOf(viewName) === -1) {
				viewName = 'welcome';
			}

			context.setView(viewName, { syncRoute: false, moveFocus: options.moveFocus });

			if (viewName === 'setup') {
				var stepIndex = context.getStepIndexByName(parts[1]);

				context.setStep(stepIndex >= 0 ? stepIndex : 0, { syncRoute: false, moveFocus: options.moveFocus });
			}
		};

		context.focusHeading = function (container) {
			if (!container) {
				return;
			}

			var heading = container.querySelector('h1, h2');

			if (!heading) {
				return;
			}

			if (!heading.hasAttribute('tabindex')) {
				heading.setAttribute('tabindex', '-1');
			}

			heading.focus();
		};

		context.setView = function (viewName, options) {
			options = options || {};
			context.state.activeView = viewName;
			context.app.classList.toggle('is-setup-view', viewName === 'setup');
			context.app.classList.toggle('is-welcome-view', viewName === 'welcome');

			context.els.viewButtons.forEach(function (button) {
				var isActive = button.getAttribute('data-view-target') === viewName;

				button.classList.toggle('is-active', isActive);

				if (isActive) {
					button.setAttribute('aria-current', 'page');
				} else {
					button.removeAttribute('aria-current');
				}
			});

			context.els.viewCopyBlocks.forEach(function (copyBlock) {
				copyBlock.hidden = copyBlock.getAttribute('data-view-copy') !== viewName;
			});

			var activeViewElement = null;

			context.els.views.forEach(function (view) {
				var isActive = view.getAttribute('data-view') === viewName;

				view.classList.toggle('is-active', isActive);

				if (isActive) {
					activeViewElement = view;
				}
			});

			if (options.syncRoute !== false) {
				context.syncRoute();
			}

			if (options.moveFocus) {
				context.focusHeading(viewName === 'setup' ? context.els.steps[context.state.activeStepIndex] : activeViewElement);
			}
		};

		context.setStep = function (index, options) {
			options = options || {};
			context.state.activeStepIndex = Math.max(0, Math.min(index, context.els.steps.length - 1));

			context.els.stepButtons.forEach(function (button, buttonIndex) {
				var stepName = button.getAttribute('data-step-target');
				var isActive = buttonIndex === context.state.activeStepIndex;
				var isComplete = buttonIndex < context.state.activeStepIndex && context.isStepComplete(stepName);
				var isSkipped = buttonIndex < context.state.activeStepIndex && context.isStepSkipped(stepName);
				var isWarning = buttonIndex < context.state.activeStepIndex && !isComplete && !isSkipped;

				button.classList.toggle('is-active', isActive);
				button.classList.toggle('is-complete', isComplete);
				button.classList.toggle('is-skipped', isSkipped);
				button.classList.toggle('is-warning', isWarning);

				if (isActive) {
					button.setAttribute('aria-current', 'step');
				} else {
					button.removeAttribute('aria-current');
				}
			});

			var activeStepElement = null;

			context.els.steps.forEach(function (step, stepIndex) {
				var isActiveStep = stepIndex === context.state.activeStepIndex;

				step.classList.toggle('is-active', isActiveStep);

				if (isActiveStep) {
					step.scrollTop = 0;
					activeStepElement = step;
				}
			});

			if (context.els.previousButton) {
				context.els.previousButton.disabled = context.state.activeStepIndex === 0;
			}

			context.updateNextButtonLabel();
			context.updateStepCount();
			context.updateSkipButton();

			if (context.els.demoSelection) {
				context.els.demoSelection.hidden = context.getActiveStepName() !== 'demo';
			}

			if (context.getActiveStepName() === 'homepage' && context.features.homepage && context.features.homepage.updatePreviewScale) {
				window.requestAnimationFrame(function () {
					window.requestAnimationFrame(context.features.homepage.updatePreviewScale);
				});
			}

			if (options.syncRoute !== false && context.state.activeView === 'setup') {
				context.syncRoute();
			}

			if (options.moveFocus) {
				context.focusHeading(activeStepElement);
			}
		};

		context.updateStepCount = function () {
			var stepCount = context.els.stepCount;

			if (!stepCount) {
				return;
			}

			var stepName = context.getActiveStepName();

			if (stepName === 'start' || stepName === 'finish' || context.state.activeStepIndex === 0) {
				stepCount.hidden = true;
				stepCount.textContent = '';
				return;
			}

			stepCount.hidden = false;
			stepCount.textContent = context.sprintf(context.t('stepCount', 'Step %1$s of %2$s'), context.state.activeStepIndex, context.els.steps.length - 2);
		};

		context.updateSkipButton = function () {
			var skipButton = context.els.skipButton;

			if (!skipButton) {
				return;
			}

			skipButton.hidden = context.skippableSteps.indexOf(context.getActiveStepName()) === -1;
			skipButton.disabled = context.state.demoImportRunning;
		};

		context.isOnboardingComplete = function () {
			var status = context.getStatus();

			return !!(status.onboarding && status.onboarding.complete);
		};

		context.getPersistedStepState = function (stepName) {
			var status = context.getStatus();

			if (!status.onboarding || !status.onboarding.steps) {
				return '';
			}

			return status.onboarding.steps[stepName] || '';
		};

		context.isStepComplete = function (stepName) {
			if (stepName === 'start' || stepName === 'finish') {
				return true;
			}

			return context.getPersistedStepState(stepName) === 'completed';
		};

		context.isStepSkipped = function (stepName) {
			if (
				stepName === 'demo' &&
				context.features.demo &&
				context.features.demo.getSelected &&
				context.features.demo.getSelected() === 'skip'
			) {
				return true;
			}

			return context.getPersistedStepState(stepName) === 'skipped';
		};

		context.areRequiredPluginsActive = function () {
			var status = context.getStatus();

			if (!status.plugins || !status.plugins.length) {
				return false;
			}

			return status.plugins.every(function (plugin) {
				return plugin.active;
			});
		};

		context.updateNextButtonLabel = function () {
			var nextButton = context.els.nextButton;

			if (!nextButton) {
				return;
			}

			if (context.state.activeStepIndex === context.els.steps.length - 1) {
				nextButton.textContent = context.t('goToDashboard', 'Go to dashboard');
				return;
			}

			if (context.getActiveStepName() === 'brand' && context.features.brand && context.features.brand.isDirty && context.features.brand.isDirty()) {
				nextButton.textContent = context.t('saveAndContinue', 'Save and continue');
				return;
			}

			if (context.getActiveStepName() === 'demo' && context.features.demo && context.features.demo.getSelected && context.features.demo.getSelected() === 'standard' && !context.features.demo.isImported()) {
				nextButton.textContent = context.t('importAndContinue', 'Import and continue');
				return;
			}

			if (context.getActiveStepName() === 'demo' && context.features.demo && context.features.demo.getSelected && context.features.demo.getSelected() === 'standard' && context.features.demo.isImported()) {
				nextButton.textContent = context.t('importAgain', 'Import again');
				return;
			}

			if (context.getActiveStepName() === 'homepage' && context.features.homepage && context.features.homepage.isDirty && context.features.homepage.isDirty()) {
				nextButton.textContent = context.t('saveAndContinue', 'Save and continue');
				return;
			}

			nextButton.textContent = context.t('continue', 'Continue');
		};

		context.showStepNotice = function (stepName, message, type) {
			if (stepName === 'child-theme' && context.features.childTheme) {
				context.features.childTheme.showNotice(message, type);
			} else if (stepName === 'plugins' && context.features.plugins) {
				context.features.plugins.showNotice(message, type);
			} else if (stepName === 'demo' && context.features.demo) {
				context.features.demo.showNotice(message, type);
			} else if (stepName === 'brand' && context.features.brand) {
				context.features.brand.showNotice(message, type);
			} else if (stepName === 'homepage' && context.features.homepage) {
				context.features.homepage.showNotice(message, type);
			}
		};

		context.saveStepState = function (stepName, stepState) {
			var endpoint = context.config.actions ? context.config.actions.saveStepState : '';

			if (!endpoint) {
				context.showStepNotice(stepName, context.t('stepStateFailed', 'This step could not be updated. Please try again.'), 'error');
				return Promise.reject(new Error(context.t('stepStateFailed', 'This step could not be updated. Please try again.')));
			}

			if (context.els.nextButton) {
				context.els.nextButton.disabled = true;
			}

			if (context.els.skipButton) {
				context.els.skipButton.disabled = true;
			}

			return window.fetch(endpoint, {
				method: 'POST',
				credentials: 'same-origin',
				headers: {
					'Content-Type': 'application/json',
					'X-WP-Nonce': context.config.nonce
				},
				body: JSON.stringify({
					step: stepName,
					state: stepState
				})
			})
				.then(function (response) {
					return response.json().then(function (data) {
						if (!response.ok) {
							throw new Error(data && data.message ? data.message : context.t('stepStateFailed', 'This step could not be updated. Please try again.'));
						}

						return data;
					});
				})
				.then(function (data) {
					context.setStatus(data);
					context.render();
					return data;
				})
				.catch(function (error) {
					context.showStepNotice(stepName, error.message, 'error');
					throw error;
				})
				.finally(function () {
					if (context.els.nextButton) {
						context.els.nextButton.disabled = false;
					}

					context.updateSkipButton();
					context.updateNextButtonLabel();
				});
		};

		context.openSetupStep = function (stepName) {
			var stepIndex = context.getStepIndexByName(stepName);

			context.setView('setup', { moveFocus: false });
			context.setStep(stepIndex >= 0 ? stepIndex : 0, { moveFocus: true });
		};

		context.render = function () {
			['quickSetup', 'childTheme', 'plugins', 'brand', 'homepage', 'demo', 'finish'].forEach(function (featureName) {
				if (context.features[featureName] && context.features[featureName].render) {
					context.features[featureName].render();
				}
			});

			context.updateNextButtonLabel();
		};

		context.refreshStatusAsync = function () {
			if (!context.config.endpoint) {
				context.render();
				return Promise.resolve(context.getStatus());
			}

			return window.fetch(context.config.endpoint, {
				credentials: 'same-origin',
				headers: {
					'X-WP-Nonce': context.config.nonce
				}
			})
				.then(function (response) {
					if (!response.ok) {
						throw new Error(context.t('statusLoadFailed', 'Unable to load onboarding status.'));
					}

					return response.json();
				})
				.then(function (data) {
					context.setStatus(data);
					context.render();
					return data;
				})
				.catch(function () {
					context.render();
					return context.getStatus();
				});
		};

		return context;
	}

	function bindEvents(context) {
		context.els.viewButtons.forEach(function (button) {
			button.addEventListener('click', function () {
				if (context.state.demoImportRunning) {
					return;
				}

				if (button.getAttribute('data-view-target') !== context.state.activeView && !context.confirmDiscardUnsavedChanges()) {
					return;
				}

				context.setView(button.getAttribute('data-view-target'), { moveFocus: true });
			});
		});

		context.els.stepButtons.forEach(function (button, index) {
			button.addEventListener('click', function () {
				if (context.state.demoImportRunning) {
					return;
				}

				if (index !== context.state.activeStepIndex && !context.confirmDiscardUnsavedChanges()) {
					return;
				}

				context.setStep(index, { moveFocus: true });
			});
		});

		if (context.els.startSetupButton) {
			context.els.startSetupButton.addEventListener('click', function () {
				context.setView('setup', { moveFocus: false });
				context.setStep(0, { moveFocus: true });
			});
		}

		if (context.els.startStepsButton) {
			context.els.startStepsButton.addEventListener('click', function () {
				context.setStep(1, { moveFocus: true });
			});
		}

		if (context.els.previousButton) {
			context.els.previousButton.addEventListener('click', function () {
				if (context.state.demoImportRunning || !context.confirmDiscardUnsavedChanges()) {
					return;
				}

				context.setStep(context.state.activeStepIndex - 1, { moveFocus: true });
			});
		}

		if (context.els.skipButton) {
			context.els.skipButton.addEventListener('click', function () {
				if (context.state.demoImportRunning) {
					return;
				}

				var stepName = context.getActiveStepName();

				if (!context.confirmDiscardUnsavedChanges()) {
					return;
				}

				context.saveStepState(stepName, 'skipped')
					.then(function () {
						if (context.state.activeStepIndex < context.els.steps.length - 1) {
							context.setStep(context.state.activeStepIndex + 1, { moveFocus: true });
						}
					})
					.catch(function () {});
			});
		}

		if (context.els.nextButton) {
			context.els.nextButton.addEventListener('click', function () {
				if (context.state.demoImportRunning) {
					return;
				}

				var stepName = context.getActiveStepName();

				function advance() {
					if (context.state.activeStepIndex < context.els.steps.length - 1) {
						context.setStep(context.state.activeStepIndex + 1, { moveFocus: true });
					}
				}

				if (stepName === 'brand' && context.features.brand && context.features.brand.isDirty && context.features.brand.isDirty()) {
					context.features.brand.save().then(advance).catch(function () {});
					return;
				}

				if (stepName === 'brand') {
					context.saveStepState('brand', 'completed').then(advance).catch(function () {});
					return;
				}

				if (stepName === 'homepage' && context.features.homepage && context.features.homepage.isDirty && context.features.homepage.isDirty()) {
					context.features.homepage.save().then(advance).catch(function () {});
					return;
				}

				if (stepName === 'homepage' && context.features.homepage && !context.features.homepage.getPageId()) {
					context.features.homepage.showNotice(context.t('homepageChoose', 'Please choose a published page for your homepage.'), 'error');
					return;
				}

				if (stepName === 'demo' && context.features.demo && context.features.demo.getSelected() === 'skip') {
					context.saveStepState('demo', 'skipped').then(advance).catch(function () {});
					return;
				}

				if (stepName === 'demo' && context.features.demo && context.features.demo.getSelected() === 'standard') {
					context.features.demo.runImport();
					return;
				}

				if (stepName === 'finish') {
					if (context.isOnboardingComplete()) {
						context.setView('welcome', { moveFocus: true });
					} else if (context.features.finish) {
						context.features.finish.complete();
					}

					return;
				}

				advance();
			});
		}

		window.addEventListener('hashchange', function () {
			if (context.state.suppressHashChange) {
				context.state.suppressHashChange = false;
				return;
			}

			if (!context.confirmDiscardUnsavedChanges()) {
				context.normalizeRouteHash();
				return;
			}

			context.applyRoute(context.getRouteFromHash(), { moveFocus: true });
			context.normalizeRouteHash();
		});

		window.addEventListener('beforeunload', function (event) {
			if (context.state.demoImportRunning || context.hasUnsavedChanges()) {
				event.preventDefault();
				event.returnValue = '';
			}
		});
	}

	window.ShoptimizerOnboardingApp = runtime;
})(window, document);
