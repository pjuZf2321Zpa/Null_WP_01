// Shoptimizer ajax add to cart js.

document.addEventListener( 'DOMContentLoaded', function() {
	var cart_forms = document.querySelectorAll( '.summary form.cart' );
	cart_forms.forEach( function( cart_form ) {
		cart_form.addEventListener( 'submit', function( event ) {
			var parent_elem = cart_form.closest( '.product.type-product' );
			if ( ! parent_elem ) {
				return;
			}
			if ( parent_elem.classList.contains( 'product-type-external' ) || parent_elem.classList.contains( 'product-type-subscription' ) || parent_elem.classList.contains( 'product-type-variable-subscription' ) || parent_elem.classList.contains( 'product-type-grouped' ) ) {
				return;
			}
			// Do not intercept WooCommerce Subscriptions switch/upgrade/downgrade submissions.
			if ( cart_form.querySelector( 'input[name="switch-subscription"]' ) ) {
				return;
			}
			if ( typeof shoptimizer_ajax_obj === 'undefined' ) {
				return;
			}
			event.preventDefault();

			var atc_elem = cart_form.querySelector( '.single_add_to_cart_button' );
			var formData = new FormData( cart_form );

			if ( atc_elem.value ) {
				formData.append( 'add-to-cart', atc_elem.value );
			}

			atc_elem.classList.remove( 'added' );
			atc_elem.classList.remove( 'not-added' );
			atc_elem.classList.add( 'loading' );

			// Trigger adding to cart event
			var wce_add_cart = new Event( 'adding_to_cart' );
			document.body.dispatchEvent( wce_add_cart );

			fetch( shoptimizer_ajax_obj.wcAjaxUrl.toString().replace( '%%endpoint%%', 'shoptimizer_pdp_ajax_atc' ), {
				method: 'POST',
				body: formData,
				credentials: 'same-origin',
				headers: {
					'X-Requested-With': 'XMLHttpRequest'
				}
			} ).then( function( resp ) {
				if ( ! resp ) {
					return;
				}
				if ( 'yes' === shoptimizer_ajax_obj.isCartRedirect ) {
					window.location = shoptimizer_ajax_obj.cartUrl;
					return;
				}
				return resp.json();
			} ).then( resp => {
				if ( ! resp ) {
					return;
				}

				// SP-520 Fix 2: V2 responds via wp_send_json_success()/_error(), which
				// nests the payload under `data`. Normalize so both the V2 (nested) and
				// any legacy (top-level) response shapes are handled by one code path.
				var payload = resp.data || resp;
				var ok = ( typeof resp.success === 'boolean' ) ? resp.success : ! payload.error;

				var cur_page = window.location.toString();
				cur_page = cur_page.replace( 'add-to-cart', 'added-to-cart' );

				// Error case — validate the redirect target against the current origin
				// before navigating (SP-520 Fix 2b / security-audit finding #3).
				if ( payload.error && payload.product_url ) {
					try {
						var dest = new URL( payload.product_url, window.location.origin );
						if ( dest.origin === window.location.origin ) {
							window.location = dest.toString();
						}
					} catch ( e ) { /* malformed URL — ignore */ }
					return;
				}

				atc_elem.classList.remove( 'loading' );

				// Check for error notices in both legacy and new format
				var notices = payload.notices || ( payload.fragments && payload.fragments.notices ) || '';
				var hasError = ! ok || ( notices && notices.indexOf( 'error' ) > -1 );

				if ( hasError ) {
					if ( notices ) {
						document.body.insertAdjacentHTML( 'beforeend', notices );
					}
					atc_elem.classList.add( 'not-added' );
				} else {
					atc_elem.classList.add( 'added' );

					// Handle fragments for both legacy and new format
					var fragments = payload.fragments || {};
					jQuery.each( fragments, function( key, value ) {
						jQuery( key ).replaceWith( value );
					} );

					// Trigger fragment refresh
					jQuery(document.body).trigger('wc_fragments_refreshed');

					// Open cart drawer (only if it exists)
					if (document.getElementById('shoptimizerCartDrawer')) {
						document.querySelector('body').classList.add('drawer-open');
					}

					// Trigger added_to_cart event with appropriate data
					var cartHash = payload.cart_hash || '';

					// Ensure the button carries data-product_id so plugins like
					// Google Analytics for WooCommerce can read the product ID.
					if ( ! atc_elem.dataset.product_id ) {
						var productIdInput = cart_form.querySelector( 'input[name="product_id"]' );
						var productId = productIdInput ? productIdInput.value : atc_elem.value;
						if ( productId ) {
							atc_elem.setAttribute( 'data-product_id', productId );
						}
					}

					jQuery(document.body).trigger('added_to_cart', [fragments, cartHash, jQuery(atc_elem)]);
				}
			} ).catch(error => {
				console.error('Error:', error);
				atc_elem.classList.remove('loading');
				atc_elem.classList.add('not-added');
			});
		} );
	} );
} );
