( function() {
	'use strict';

	var doc = document;
	var body = doc.body;
	var menuToggle = doc.querySelector( '.menu-toggle' );
	var menuPanel = doc.querySelector( '.col-full-nav' );
	var menuClose = doc.querySelector( '.mobile-menu.close-drawer' );
	var cartDrawer = doc.getElementById( 'shoptimizerCartDrawer' );
	var cartOpener;
	var menuClass = 'mobile-toggled';
	var cartClass = 'drawer-open';
	var cartTriggerSelector = '[aria-controls=shoptimizerCartDrawer],.shoptimizer-cart a[href="#"]';
	var filterCloseSelector = '.filters.close-drawer';
	var focusableSelector = 'a[href],button,input,select,textarea,[tabindex]:not([tabindex^="-"])';

	function hasClass( className ) {
		return body.classList.contains( className );
	}

	function syncCartTriggers( open ) {
		doc.querySelectorAll( cartTriggerSelector ).forEach( function( trigger ) {
			trigger.setAttribute( 'aria-controls', 'shoptimizerCartDrawer' );
			trigger.setAttribute( 'aria-expanded', open );
		} );
	}

	function setMenu( open, restoreFocus ) {
		if ( ! menuToggle || ! menuPanel ) {
			return;
		}

		body.classList.toggle( menuClass, open );
		menuToggle.setAttribute( 'aria-expanded', open );

		if ( open ) {
			setCart( false );
			if ( menuClose ) {
				menuClose.focus();
			}
		} else if ( restoreFocus && menuToggle.isConnected ) {
			menuToggle.focus();
		}
	}

	function setCart( open, restoreFocus, opener ) {
		if ( ! cartDrawer ) {
			return;
		}

		body.classList.toggle( cartClass, open );
		cartDrawer.setAttribute( 'aria-hidden', ! open );
		cartDrawer.toggleAttribute( 'inert', ! open );
		syncCartTriggers( open );

		if ( open ) {
			setMenu( false );
			cartOpener = opener || null;
			cartDrawer.focus();
		} else if ( restoreFocus && cartOpener && cartOpener.isConnected ) {
			cartOpener.focus();
		}
	}

	function trapFocus( event, scope, extra ) {
		var controls = [ ...scope.querySelectorAll( focusableSelector ) ];
		if ( extra ) {
			controls.unshift( extra );
		}
		controls = controls.filter( function( control ) {
			return ! control.disabled && control.getClientRects().length;
		} );

		var index = controls.indexOf( doc.activeElement );
		if ( controls.length && ( -1 === index || ( event.shiftKey && 0 === index ) || ( ! event.shiftKey && index === controls.length - 1 ) ) ) {
			event.preventDefault();
			controls[ event.shiftKey ? controls.length - 1 : 0 ].focus();
		}
	}

	function act( event, setter, open, opener ) {
		event.preventDefault();
		setter( open, true, opener );
	}

	function resolveActivation( target ) {
		if ( ! target || ! target.closest ) {
			return null;
		}

		var trigger = target.closest( cartTriggerSelector );
		if ( trigger && cartDrawer ) {
			return { type: 'cart-toggle', trigger: trigger };
		}

		if ( menuToggle && menuPanel && menuToggle.contains( target ) ) {
			return { type: 'menu-toggle' };
		}

		var search = target.closest( '.mobile-search-toggle' );
		if ( search ) {
			return { type: 'search-toggle', trigger: search };
		}

		if ( cartDrawer && target.closest( '#shoptimizerCartDrawer .close-drawer' ) ) {
			return { type: 'cart-close' };
		}

		if ( menuToggle && menuPanel && menuClose && menuClose.contains( target ) ) {
			return { type: 'menu-close' };
		}

		if ( target.closest( filterCloseSelector ) ) {
			return null;
		}

		if ( target.closest( '.mobile-overlay' ) ) {
			if ( hasClass( cartClass ) && cartDrawer ) {
				return { type: 'cart-close' };
			}
			if ( hasClass( menuClass ) && menuToggle && menuPanel ) {
				return { type: 'menu-close' };
			}
		}

		return null;
	}

	function handleActivation( event, activation ) {
		if ( 'cart-toggle' === activation.type ) {
			act( event, setCart, ! hasClass( cartClass ), activation.trigger );
		} else if ( 'menu-toggle' === activation.type ) {
			act( event, setMenu, ! hasClass( menuClass ) );
		} else if ( 'search-toggle' === activation.type ) {
			event.preventDefault();
			var open = body.classList.toggle( 'm-search-toggled' );
			activation.trigger.setAttribute( 'aria-expanded', open );
		} else if ( 'cart-close' === activation.type ) {
			act( event, setCart, false );
		} else if ( 'menu-close' === activation.type ) {
			act( event, setMenu, false );
		}
	}

	doc.addEventListener( 'cgturbo-before-queue-activation', function( event ) {
		if ( resolveActivation( event.target ) ) {
			event.preventDefault();
		}
	} );

	doc.addEventListener( 'click', function( event ) {
		var target = event.target;
		var activation = resolveActivation( target );
		if ( activation ) {
			handleActivation( event, activation );
			return;
		}

		if ( ! target.closest || target.closest( filterCloseSelector ) ) {
			return;
		}

		if ( hasClass( cartClass ) && cartDrawer && ! cartDrawer.contains( target ) ) {
			setCart( false, true );
		} else if ( hasClass( menuClass ) && menuPanel && ! menuPanel.contains( target ) ) {
			setMenu( false, true );
		}
	}, true );

	doc.addEventListener( 'keydown', function( event ) {
		if ( 'Escape' === event.key ) {
			if ( hasClass( cartClass ) ) {
				setCart( false, true );
			} else if ( hasClass( menuClass ) ) {
				setMenu( false, true );
			}
		} else if ( 'Tab' === event.key ) {
			if ( hasClass( cartClass ) && cartDrawer ) {
				trapFocus( event, cartDrawer );
			} else if ( hasClass( menuClass ) && menuPanel ) {
				trapFocus( event, menuPanel, menuClose );
			}
		}
	} );

	doc.addEventListener( 'shoptimizer:cart', function( event ) {
		if ( 'open' === event.detail ) {
			setCart( true );
		} else if ( 'sync' === event.detail ) {
			syncCartTriggers( hasClass( cartClass ) );
		}
	} );
}() );
