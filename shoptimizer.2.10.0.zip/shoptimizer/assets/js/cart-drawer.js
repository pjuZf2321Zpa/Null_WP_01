/**
 * Shoptimizer Cart Drawer Script
 * Handles cart drawer functionality including opening/closing and AJAX loading states
 *
 * @package Shoptimizer
 */

(function($) {
    'use strict';

    const ajaxEvents = [
        'wc-ajax=get_refreshed_fragments',
        'wc-ajax=remove_from_cart'
    ];

    $('body').on('added_to_cart', function() {
        if (!$('body').hasClass('elementor-editor-active')) {
            document.dispatchEvent(new CustomEvent('shoptimizer:cart', { detail: 'open' }));
        }
    });

    $('body').on('wc_fragments_loaded wc_fragments_refreshed', function() {
        document.dispatchEvent(new CustomEvent('shoptimizer:cart', { detail: 'sync' }));
    });

    function isCartRequest(settings) {
        return settings && ajaxEvents.some(function(event) {
            return settings.url.indexOf(event) !== -1;
        });
    }

    $(document).ajaxSend(function(event, jqXHR, settings) {
        if (isCartRequest(settings)) {
            $('#ajax-loading').css('display', 'block');
        }
    });

    $(document).ajaxComplete(function(event, jqXHR, settings) {
        if (isCartRequest(settings)) {
            $('#ajax-loading').css('display', 'none');
            document.dispatchEvent(new CustomEvent('shoptimizer:cart', { detail: 'sync' }));
        }
    });
}(jQuery));
