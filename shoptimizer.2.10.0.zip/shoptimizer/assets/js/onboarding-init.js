(function (window) {
	'use strict';

	if (window.ShoptimizerOnboardingApp) {
		window.ShoptimizerOnboardingApp.init();
	}
})(window);
