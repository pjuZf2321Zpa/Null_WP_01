(function (window) {
	'use strict';

	window.ShoptimizerOnboardingApp.registerFeature('childTheme', function (context) {
		var childThemePanel = context.app.querySelector('[data-child-theme-panel]');
		var childThemeNotice = context.app.querySelector('[data-child-theme-notice]');

		function render() {
			var status = context.getStatus();

			if (!childThemePanel || !status.theme || !status.theme.child_theme) {
				return;
			}

			var childTheme = status.theme.child_theme;
			var statusText = childTheme.active ? context.t('childThemeActive', 'Child theme is active.') : childTheme.installed ? context.t('childThemeInstalled', 'Child theme is installed but not active.') : context.t('childThemeMissing', 'Child theme is not installed yet.');
			var helperText = childTheme.active ? context.t('childThemeReady', 'The child theme is ready to use.') : childTheme.installed ? context.t('childThemeActivateHint', 'Click the button to activate it.') : context.t('childThemeInstallHint', 'Click the button to install it.');

			childThemePanel.innerHTML = '';

			var card = context.createElement('div', 'shoptimizer-child-theme-card' + (childTheme.active ? ' is-active' : ''));
			var details = context.createElement('div');
			var actions = context.createElement('div', 'shoptimizer-child-theme-actions');

			details.appendChild(context.createElement('strong', '', statusText));
			details.appendChild(context.createElement('span', '', helperText));

			if (childTheme.active) {
				actions.appendChild(context.createElement('span', 'shoptimizer-quick-setup-done', context.t('done', 'Done')));
			} else {
				var buttonLabel = childTheme.installed ? context.t('activateChildTheme', 'Activate child theme') : context.t('installChildTheme', 'Install child theme');
				var button = context.createElement('button', 'button button-secondary shoptimizer-child-theme-action', buttonLabel);
				button.type = 'button';
				button.disabled = !childTheme.installed && !childTheme.package_url_configured;
				button.addEventListener('click', function () {
					runAction(button, showNotice);
				});
				actions.appendChild(button);
			}

			card.appendChild(details);
			card.appendChild(actions);
			childThemePanel.appendChild(card);
		}

		function showNotice(message, type) {
			if (!childThemeNotice) {
				return;
			}

			childThemeNotice.hidden = false;
			childThemeNotice.className = 'shoptimizer-child-theme-notice is-' + type;
			childThemeNotice.textContent = message;
		}

		function clearNotice() {
			if (!childThemeNotice) {
				return;
			}

			childThemeNotice.hidden = true;
			childThemeNotice.textContent = '';
		}

		function runAction(button, noticeCallback) {
			var endpoint = context.config.actions ? context.config.actions.setupChildTheme : '';
			var originalLabel = button ? button.textContent : '';

			if (!endpoint) {
				noticeCallback(context.t('childThemeUnavailable', 'Child theme setup is not available yet.'), 'error');
				return;
			}

			if (context.features.quickSetup) {
				context.features.quickSetup.clearNotice();
			}

			clearNotice();

			if (button) {
				button.disabled = true;
				button.textContent = context.t('working', 'Working…');
			}

			window.fetch(endpoint, {
				method: 'POST',
				credentials: 'same-origin',
				headers: {
					'Content-Type': 'application/json',
					'X-WP-Nonce': context.config.nonce
				}
			})
				.then(function (response) {
					return response.json().then(function (data) {
						if (!response.ok) {
							throw new Error(data && data.message ? data.message : context.t('childThemeFailed', 'Child theme setup failed.'));
						}

						return data;
					});
				})
				.then(function (data) {
					context.setStatus(data);
					context.render();
					noticeCallback(context.t('childThemeDone', 'Child theme setup completed.'), 'success');
				})
				.catch(function (error) {
					if (button) {
						button.disabled = false;
						button.textContent = originalLabel;
					}

					noticeCallback(error.message, 'error');
				});
		}

		return {
			clearNotice: clearNotice,
			render: render,
			runAction: runAction,
			showNotice: showNotice
		};
	});
})(window);
