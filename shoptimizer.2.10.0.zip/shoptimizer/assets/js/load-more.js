/* global ShoptimizerLoadMore */
if ( 'scrollRestoration' in history && history.state && history.state.shoptimizerLoadMore === true ) {
	history.scrollRestoration = 'manual';
}

document.addEventListener( 'DOMContentLoaded', function () {
	var button = null;
	var grid = null;
	var statusText = null;
	var totalCount = null;
	var statusWrap = null;
	var progress = null;
	var progressBar = null;

	if ( typeof ShoptimizerLoadMore === 'undefined' ) {
		return;
	}

	var resultTotal = parseInt( ShoptimizerLoadMore.result_total, 10 ) || 0;
	var resultText = ShoptimizerLoadMore.result_text || 'Showing {FROM}–{TO} of {TOTAL} results';
	var resultFrom = 0;
	var resultTo = 0;
	var loading = false;
	var filterRefreshFrame = null;
	var ignoreMutationBatch = false;
	var restoringArchive = false;
	var snapshotPrefix = 'shoptimizer-load-more-';
	var snapshotKey = snapshotPrefix + 'snapshot';
	var snapshotByteLimit = 2 * 1024 * 1024;
	var historyStateByteLimit = 64 * 1024;
	var paginationByteLimit = 24 * 1024;
	var snapshotStorageAvailable = true;
	var snapshotStorageFailureReported = false;
	var historyStateFailureReported = false;
	var sequenceCounter = 0;
	var scrollSaveTimer = null;
	var pendingScrollY = null;
	var restoringScroll = false;
	var archiveRestoreRequest = 0;

	function findGrid( root ) {
		var grids;
		var selectedGrid = null;
		var selectedCount = -1;

		if ( ! root ) {
			return null;
		}

		grids = root.querySelectorAll( '.site-main .products' );

		if ( ! grids.length ) {
			grids = root.querySelectorAll( '.products' );
		}

		Array.prototype.forEach.call( grids, function ( candidate ) {
			var productCount = getProducts( candidate ).length;

			if ( productCount > selectedCount ) {
				selectedGrid = candidate;
				selectedCount = productCount;
			}
		} );

		return selectedGrid;
	}

	function findResultCount( root ) {
		if ( ! root ) {
			return null;
		}

		return root.querySelector( '.site-main .woocommerce-result-count' ) || root.querySelector( '.woocommerce-result-count' );
	}

	function getPaginationElements( root ) {
		if ( ! root ) {
			return [];
		}

		var paginations = root.querySelectorAll( '.site-main .woocommerce-pagination' );

		if ( ! paginations.length ) {
			paginations = root.querySelectorAll( '.woocommerce-pagination' );
		}

		return Array.prototype.slice.call( paginations );
	}

	function getNextPageLink( root ) {
		var paginations = getPaginationElements( root || document );
		var nextLink = null;

		paginations.some( function ( pagination ) {
			nextLink = pagination.querySelector( 'a.next, a.page-numbers.next' );
			return !! nextLink;
		} );

		return nextLink;
	}

	function getProducts( productGrid ) {
		var products = [];

		if ( ! productGrid ) {
			return products;
		}

		Array.prototype.forEach.call( productGrid.children, function ( child ) {
			if ( child.classList && child.classList.contains( 'product' ) && child.classList.contains( 'type-product' ) && ! child.classList.contains( 'cg-grid-feature' ) ) {
				products.push( child );
			}
		} );

		return products;
	}

	function refreshElements() {
		button      = document.getElementById( 'shoptimizer-load-more-btn' );
		grid        = findGrid( document );
		statusText  = document.querySelector( '.site-main .viewed-count' );
		totalCount  = document.querySelector( '.site-main .total-count' );
		statusWrap  = document.querySelector( '.site-main .load-more-status' );
		progress    = document.querySelector( '.site-main .load-more-progress' );
		progressBar = document.querySelector( '.site-main .load-more-progress-bar' );
	}

	function getResultMetadata( root ) {
		var resultElements;
		var resultElement;
		var metadataMarker;
		var wrapper = root && root.querySelector ? root.querySelector( '.shoptimizer-load-more-wrapper' ) : null;
		var from;
		var to;
		var total;

		if ( root && root.querySelectorAll ) {
			resultElements = root.querySelectorAll( '.site-main .woocommerce-result-count, .woocommerce-result-count' );
			for ( var index = 0; index < resultElements.length; index++ ) {
				resultElement = resultElements[ index ];
				from = parseInt( resultElement.getAttribute( 'data-shoptimizer-result-from' ), 10 );
				to = parseInt( resultElement.getAttribute( 'data-shoptimizer-result-to' ), 10 );
				total = parseInt( resultElement.getAttribute( 'data-shoptimizer-result-total' ), 10 );

				if ( ! isNaN( from ) && ! isNaN( to ) && ! isNaN( total ) ) {
					return { from: from, to: to, total: total };
				}
			}
		}

		metadataMarker = root && root.querySelector ? root.querySelector( '.shoptimizer-result-metadata' ) : null;
		if ( metadataMarker ) {
			from = parseInt( metadataMarker.getAttribute( 'data-shoptimizer-result-from' ), 10 );
			to = parseInt( metadataMarker.getAttribute( 'data-shoptimizer-result-to' ), 10 );
			total = parseInt( metadataMarker.getAttribute( 'data-shoptimizer-result-total' ), 10 );

			if ( ! isNaN( from ) && ! isNaN( to ) && ! isNaN( total ) ) {
				return { from: from, to: to, total: total };
			}
		}

		if ( ! wrapper ) {
			return null;
		}

		from  = parseInt( wrapper.getAttribute( 'data-result-from' ), 10 );
		to    = parseInt( wrapper.getAttribute( 'data-result-to' ), 10 );
		total = parseInt( wrapper.getAttribute( 'data-result-total' ), 10 );

		if ( isNaN( from ) || isNaN( to ) || isNaN( total ) ) {
			return null;
		}

		return { from: from, to: to, total: total };
	}

	function syncResultMetadata( root ) {
		var metadata = getResultMetadata( root );

		if ( ! metadata ) {
			return null;
		}

		resultTotal = metadata.total;
		resultFrom  = metadata.from;
		resultTo    = metadata.to;

		return metadata;
	}

	function updateWrapperResultMetadata( metadata ) {
		var wrapper = document.querySelector( '.shoptimizer-load-more-wrapper' );
		var resultElements = document.querySelectorAll( '.site-main .woocommerce-result-count, .woocommerce-result-count' );

		if ( ! metadata ) {
			return;
		}

		if ( wrapper ) {
			wrapper.setAttribute( 'data-result-from', metadata.from );
			wrapper.setAttribute( 'data-result-to', metadata.to );
			wrapper.setAttribute( 'data-result-total', metadata.total );
		}

		Array.prototype.forEach.call( resultElements, function ( resultElement ) {
			resultElement.setAttribute( 'data-shoptimizer-result-from', metadata.from );
			resultElement.setAttribute( 'data-shoptimizer-result-to', metadata.to );
			resultElement.setAttribute( 'data-shoptimizer-result-total', metadata.total );
		} );
	}

	function updateViewedCount() {
		var viewed = Math.min( Math.max( resultTo, 0 ), resultTotal );

		if ( statusText ) {
			statusText.textContent = viewed;
			if ( statusWrap ) {
				statusWrap.style.visibility = 'visible';
			}
		}
		if ( totalCount ) {
			totalCount.textContent = resultTotal;
		}

		if ( progress ) {
			progress.setAttribute( 'aria-valuenow', viewed );
			progress.setAttribute( 'aria-valuemax', resultTotal );
		}

		if ( progressBar && resultTotal > 0 ) {
			progressBar.style.width = ( viewed / resultTotal ) * 100 + '%';
			progressBar.setAttribute( 'aria-valuenow', viewed );
			progressBar.setAttribute( 'aria-valuemax', resultTotal );
		}
	}

	function updateResultCount() {
		var resultElement = findResultCount( document );

		if ( ! resultElement || resultTotal <= 0 ) {
			return;
		}

		resultElement.setAttribute( 'aria-live', 'polite' );
		resultElement.textContent = resultText
			.replace( '{FROM}', resultFrom )
			.replace( '{TO}', resultTo )
			.replace( '{TOTAL}', resultTotal );
		resultElement.style.visibility = 'visible';
	}

	function updateLoadMoreVisibility() {
		var wrapper = document.querySelector( '.shoptimizer-load-more-wrapper' );

		if ( ! wrapper || ! button ) {
			return;
		}

		if ( ! getNextPageLink( document ) || getProducts( grid ).length >= resultTotal ) {
			wrapper.style.display = 'none';
			return;
		}

		wrapper.style.display = 'block';
		button.style.display = 'inline-flex';
	}

	function setLoading( state ) {
		loading = state;

		if ( grid ) {
			grid.setAttribute( 'aria-busy', state ? 'true' : 'false' );
		}
		if ( button ) {
			button.disabled = state;
			button.classList.toggle( 'is-loading', state );
			button.setAttribute( 'aria-busy', state ? 'true' : 'false' );
			button.style.display = 'inline-flex';
		}
	}

	function showErrorMessage( message ) {
		var errorElement = document.querySelector( '.shoptimizer-load-more-error' );

		if ( ! errorElement ) {
			errorElement = document.createElement( 'p' );
			errorElement.className = 'shoptimizer-load-more-error';
			errorElement.setAttribute( 'role', 'alert' );
			errorElement.setAttribute( 'aria-live', 'assertive' );
			errorElement.style.cssText = 'color: #d63638; margin: 1em 0; text-align: center;';

			var wrapper = document.querySelector( '.shoptimizer-load-more-wrapper' );
			if ( wrapper ) {
				wrapper.appendChild( errorElement );
			}
		}

		errorElement.textContent = message;
		errorElement.style.display = 'block';
		setTimeout( function () {
			errorElement.style.display = 'none';
		}, 5000 );
	}

	function focusFirstNewProduct( product ) {
		if ( ! product ) {
			return;
		}

		var link = product.querySelector( 'a' );
		if ( link ) {
			var originalTabIndex = link.getAttribute( 'tabindex' );

			link.setAttribute( 'data-shoptimizer-temporary-tabindex', 'true' );
			if ( originalTabIndex !== null ) {
				link.setAttribute( 'data-shoptimizer-original-tabindex', originalTabIndex );
			}
			link.setAttribute( 'tabindex', '-1' );
			link.focus();
			link.addEventListener( 'blur', function () {
				if ( originalTabIndex === null ) {
					link.removeAttribute( 'tabindex' );
				} else {
					link.setAttribute( 'tabindex', originalTabIndex );
				}
				link.removeAttribute( 'data-shoptimizer-temporary-tabindex' );
				link.removeAttribute( 'data-shoptimizer-original-tabindex' );
			}, { once: true } );
		}
	}

	function markPageStart( product, pageUrl, sequenceId, pageIndex ) {
		var normalizedUrl;
		var markerId;

		if ( ! product ) {
			return;
		}

		normalizedUrl = normalizePageUrl( pageUrl );
		markerId = 'shoptimizer-marker-' + hashString( String( sequenceId || '' ) + '|' + normalizedUrl );
		product.classList.add( 'shoptimizer-load-more-page-start' );
		product.setAttribute( 'data-shoptimizer-page-url', normalizedUrl );
		if ( sequenceId ) {
			product.setAttribute( 'data-shoptimizer-sequence-id', sequenceId );
		}
		if ( pageIndex ) {
			product.setAttribute( 'data-shoptimizer-page-index', pageIndex );
		}
		product.setAttribute( 'data-shoptimizer-page-marker-id', markerId );
	}

	function findPageMarker( state ) {
		var markers = document.querySelectorAll( '.shoptimizer-load-more-page-start' );
		var marker = null;

		Array.prototype.some.call( markers, function ( candidate ) {
			if ( state && state.shoptimizerLoadMoreBoundaryMarkerId && candidate.getAttribute( 'data-shoptimizer-page-marker-id' ) === state.shoptimizerLoadMoreBoundaryMarkerId ) {
				marker = candidate;
				return true;
			}

			if ( state && candidate.getAttribute( 'data-shoptimizer-page-url' ) === state.shoptimizerLoadMorePageUrl && ( ! state.shoptimizerLoadMoreSequenceId || candidate.getAttribute( 'data-shoptimizer-sequence-id' ) === state.shoptimizerLoadMoreSequenceId ) ) {
				marker = candidate;
				return true;
			}

			return false;
		} );

		return marker;
	}

	function trimAfterMarker( state ) {
		var marker = findPageMarker( state );
		var markers;
		var nextMarker = null;
		var targetIndex = state && parseInt( state.shoptimizerLoadMoreSequencePageIndex, 10 );
		var sequenceId = state && state.shoptimizerLoadMoreSequenceId;
		var foundMarker = false;

		if ( ! marker || ! marker.parentElement ) {
			return false;
		}

		markers = document.querySelectorAll( '.shoptimizer-load-more-page-start' );
		Array.prototype.some.call( markers, function ( candidate ) {
			var candidateIndex;

			if ( candidate === marker ) {
				foundMarker = true;
				return false;
			}

			if ( ! foundMarker || ( sequenceId && candidate.getAttribute( 'data-shoptimizer-sequence-id' ) !== sequenceId ) ) {
				return false;
			}

			candidateIndex = parseInt( candidate.getAttribute( 'data-shoptimizer-page-index' ), 10 );
			if ( ! isNaN( targetIndex ) && candidateIndex > targetIndex ) {
				nextMarker = candidate;
				return true;
			}

			return false;
		} );

		if ( ! nextMarker ) {
			return true;
		}

		var nodeToRemove = nextMarker;
		while ( nodeToRemove ) {
			var nextSibling = nodeToRemove.nextSibling;
			nodeToRemove.parentElement.removeChild( nodeToRemove );
			nodeToRemove = nextSibling;
		}

		return true;
	}

	function getHistoryState() {
		return history.state && typeof history.state === 'object' ? Object.assign( {}, history.state ) : {};
	}

	function getSessionStorage() {
		try {
			return typeof sessionStorage === 'undefined' ? null : sessionStorage;
		} catch ( error ) {
			return null;
		}
	}

	function getByteLength( value ) {
		if ( typeof Blob !== 'undefined' ) {
			return new Blob( [ value ] ).size;
		}

		return String( value ).length * 2;
	}

	function getStateByteLength( state ) {
		try {
			return getByteLength( JSON.stringify( state ) );
		} catch ( error ) {
			return Infinity;
		}
	}

	function hashString( value ) {
		var hash = 0;

		for ( var index = 0; index < value.length; index++ ) {
			hash = ( ( hash << 5 ) - hash ) + value.charCodeAt( index );
			hash |= 0;
		}

		return Math.abs( hash ).toString( 36 );
	}

	function normalizePageUrl( value ) {
		var url;
		var params = [];

		try {
			url = new URL( value || window.location.href, window.location.href );
			url.hash = '';
			url.searchParams.forEach( function ( paramValue, paramName ) {
				params.push( { name: paramName, value: paramValue } );
			} );
			params.sort( function ( first, second ) {
				return first.name === second.name ? first.value.localeCompare( second.value ) : first.name.localeCompare( second.name );
			} );
			url.search = '';
			params.forEach( function ( param ) {
				url.searchParams.append( param.name, param.value );
			} );
			return url.href;
		} catch ( error ) {
			return value || window.location.href;
		}
	}

	function getContextKey( value ) {
		var url;
		var pathname;
		var params = [];

		try {
			url = new URL( value || window.location.href, window.location.href );
			url.hash = '';
			pathname = url.pathname.replace( /\/page\/\d+\/?$/i, '/' );
			url.searchParams.forEach( function ( paramValue, paramName ) {
				if ( 'paged' !== paramName ) {
					params.push( { name: paramName, value: paramValue } );
				}
			} );
			params.sort( function ( first, second ) {
				return first.name === second.name ? first.value.localeCompare( second.value ) : first.name.localeCompare( second.name );
			} );
			return url.origin + pathname + '?' + params.map( function ( param ) {
				return encodeURIComponent( param.name ) + '=' + encodeURIComponent( param.value );
			} ).join( '&' );
		} catch ( error ) {
			return value || window.location.href;
		}
	}

	function createSequenceId() {
		sequenceCounter += 1;
		return 'shoptimizer-sequence-' + Date.now().toString( 36 ) + '-' + sequenceCounter + '-' + Math.random().toString( 36 ).slice( 2, 8 );
	}

	function reportHistoryStateFailure( error ) {
		if ( historyStateFailureReported ) {
			return;
		}

		historyStateFailureReported = true;
		console.warn( 'Load More history state reduced:', error );
	}

	function getMinimalHistoryState( state ) {
		var minimalState = Object.assign( {}, state );

		delete minimalState.shoptimizerLoadMorePaginationHTML;
		delete minimalState.shoptimizerLoadMoreNextUrl;
		delete minimalState.shoptimizerLoadMorePrevUrl;
		minimalState.shoptimizerLoadMoreNeedsRefetch = true;
		return minimalState;
	}

	function writeHistoryState( state, url, method ) {
		var minimalState;

		try {
			history[ method + 'State' ]( state, '', url );
			return true;
		} catch ( error ) {
			reportHistoryStateFailure( error );
			minimalState = getMinimalHistoryState( state );
			try {
				history[ method + 'State' ]( minimalState, '', url );
				return true;
			} catch ( minimalError ) {
				reportHistoryStateFailure( minimalError );
				return false;
			}
		}
	}

	function isStorageWriteError( error ) {
		var message = error && error.message ? error.message : '';

		return !! error && ( error.name === 'QuotaExceededError' || error.name === 'SecurityError' || error.code === 22 || error.code === 1014 || message.indexOf( 'NS_ERROR_DOM_QUOTA_REACHED' ) !== -1 || message.toLowerCase().indexOf( 'quota' ) !== -1 );
	}

	function disableSnapshotWrites( error ) {
		snapshotStorageAvailable = false;

		if ( snapshotStorageFailureReported ) {
			return;
		}

		snapshotStorageFailureReported = true;
		console.warn( 'Load More snapshot persistence disabled:', error );
	}

	function useManualScrollRestoration() {
		if ( 'scrollRestoration' in history ) {
			history.scrollRestoration = 'manual';
		}
	}

	function getArchiveSnapshotHTML( siteMain ) {
		var snapshot = siteMain.cloneNode( true );
		var temporaryTabIndexes = snapshot.querySelectorAll( '[data-shoptimizer-temporary-tabindex]' );

		Array.prototype.forEach.call( temporaryTabIndexes, function ( link ) {
			var originalTabIndex = link.getAttribute( 'data-shoptimizer-original-tabindex' );

			if ( originalTabIndex === null ) {
				link.removeAttribute( 'tabindex' );
			} else {
				link.setAttribute( 'tabindex', originalTabIndex );
			}
			link.removeAttribute( 'data-shoptimizer-temporary-tabindex' );
			link.removeAttribute( 'data-shoptimizer-original-tabindex' );
		} );

		return snapshot.innerHTML;
	}

	function readSnapshot() {
		var storage = getSessionStorage();
		var value;

		if ( ! storage ) {
			return null;
		}

		try {
			value = storage.getItem( snapshotKey );
			value = value ? JSON.parse( value ) : null;
			return value && typeof value.html === 'string' && value.sequenceId && parseInt( value.sequencePageIndex, 10 ) > 0 ? value : null;
		} catch ( error ) {
			return null;
		}
	}

	function markSnapshotUnavailable( state ) {
		writeHistoryState( Object.assign( {}, state, {
			shoptimizerLoadMoreSnapshotUnavailable: true,
		} ), window.location.href, 'replace' );
	}

	function saveArchiveSnapshot( state, forceNewSequence ) {
		var siteMain = document.querySelector( '.site-main' );
		var storage = getSessionStorage();
		var payload;
		var serialized;
		var previous;

		if ( ! siteMain || ! storage || ! state || ! state.shoptimizerLoadMoreSequenceId || ! snapshotStorageAvailable ) {
			return false;
		}

		payload = {
			sequenceId: state.shoptimizerLoadMoreSequenceId,
			sequencePageIndex: parseInt( state.shoptimizerLoadMoreSequencePageIndex, 10 ) || 1,
			savedAt: Date.now(),
			html: getArchiveSnapshotHTML( siteMain ),
		};
		serialized = JSON.stringify( payload );

		if ( getByteLength( serialized ) > snapshotByteLimit ) {
			markSnapshotUnavailable( state );
			return false;
		}

		if ( ! forceNewSequence ) {
			previous = readSnapshot();
			if ( previous && previous.sequenceId === payload.sequenceId && parseInt( previous.sequencePageIndex, 10 ) >= payload.sequencePageIndex ) {
				return true;
			}
		}

		try {
			storage.setItem( snapshotKey, serialized );
			return true;
		} catch ( error ) {
			if ( isStorageWriteError( error ) ) {
				disableSnapshotWrites( error );
			}
			return false;
		}
	}

	function restoreArchiveSnapshot( state ) {
		var siteMain = document.querySelector( '.site-main' );
		var payload = readSnapshot();
		var targetIndex;

		if ( ! siteMain || ! state || state.shoptimizerLoadMore !== true || ! state.shoptimizerLoadMoreSequenceId || ! payload || typeof payload.html !== 'string' ) {
			return false;
		}

		targetIndex = parseInt( state.shoptimizerLoadMoreSequencePageIndex, 10 ) || 1;
		if ( payload.sequenceId !== state.shoptimizerLoadMoreSequenceId || parseInt( payload.sequencePageIndex, 10 ) < targetIndex ) {
			return false;
		}

		restoringArchive = true;
		ignoreMutationBatch = true;
		siteMain.innerHTML = payload.html;
		if ( ! trimAfterMarker( state ) ) {
			restoringArchive = false;
			return false;
		}

		initializeProductCarousels( siteMain );
		var restoredButton = document.getElementById( 'shoptimizer-load-more-btn' );
		if ( restoredButton ) {
			restoredButton.removeAttribute( 'data-shoptimizer-bound' );
		}
		window.requestAnimationFrame( function () {
			restoringArchive = false;
		} );
		return true;
	}

	function restoreScrollPosition( state ) {
		var scrollY = state && parseFloat( state.shoptimizerLoadMoreScrollY );
		var marker;

		if ( ! isNaN( scrollY ) ) {
			restoringScroll = true;
			window.requestAnimationFrame( function () {
				window.scrollTo( 0, scrollY );
				window.setTimeout( function () {
					window.scrollTo( 0, scrollY );
					restoringScroll = false;
				}, 250 );
			} );
			return;
		}

		marker = findPageMarker( state );
		if ( marker ) {
			marker.scrollIntoView( { behavior: 'smooth', block: 'start' } );
		}
	}

	function saveHistoryScrollPosition( flush ) {
		var state;
		var scrollY;

		if ( restoringScroll || restoringArchive ) {
			return;
		}

		if ( scrollSaveTimer ) {
			window.clearTimeout( scrollSaveTimer );
			scrollSaveTimer = null;
		}

		state = getHistoryState();
		if ( state.shoptimizerLoadMore !== true ) {
			return;
		}

		scrollY = flush || pendingScrollY === null ? window.scrollY : pendingScrollY;
		pendingScrollY = null;
		state.shoptimizerLoadMoreScrollY = scrollY;
		writeHistoryState( state, window.location.href, 'replace' );
	}

	function queueHistoryScrollPosition() {
		if ( restoringScroll || restoringArchive ) {
			return;
		}

		pendingScrollY = window.scrollY;
		if ( scrollSaveTimer ) {
			return;
		}

		scrollSaveTimer = window.setTimeout( function () {
			saveHistoryScrollPosition( true );
		}, 200 );
	}

	function getPaginationHTML( root ) {
		var html = getPaginationElements( root ).map( function ( element ) {
			return element.outerHTML;
		} );

		return getByteLength( JSON.stringify( html ) ) <= paginationByteLimit ? html : null;
	}

	function getResultState() {
		var viewed = Math.min( Math.max( resultTo, 0 ), resultTotal );

		return {
			from: resultFrom,
			to: resultTo,
			total: resultTotal,
			viewed: viewed,
			progress: resultTotal > 0 ? ( viewed / resultTotal ) * 100 : 0,
		};
	}

	function getCurrentMarker( sequenceId, pageUrl, pageIndex ) {
		var products = getProducts( findGrid( document ) );
		var normalizedUrl = normalizePageUrl( pageUrl );
		var existingMarker = null;
		var markers = document.querySelectorAll( '.shoptimizer-load-more-page-start' );

		Array.prototype.some.call( markers, function ( marker ) {
			if ( marker.getAttribute( 'data-shoptimizer-page-url' ) === normalizedUrl && marker.getAttribute( 'data-shoptimizer-sequence-id' ) === String( sequenceId ) ) {
				existingMarker = marker;
				return true;
			}

			return false;
		} );

		if ( existingMarker ) {
			return existingMarker.getAttribute( 'data-shoptimizer-page-marker-id' );
		}

		if ( ! products.length ) {
			return null;
		}

		markPageStart( products[ 0 ], pageUrl, sequenceId, pageIndex );
		return products[ 0 ].getAttribute( 'data-shoptimizer-page-marker-id' );
	}

	function getEntryState( baseState, pageUrl, pageIndex, previousUrl ) {
		var nextLink = getNextPageLink( document );
		var state = Object.assign( {}, baseState, {
			shoptimizerLoadMore: true,
			shoptimizerLoadMoreStartUrl: pageIndex === 1 ? normalizePageUrl( pageUrl ) : baseState.shoptimizerLoadMoreStartUrl,
			shoptimizerLoadMoreSnapshotKey: snapshotKey,
			shoptimizerLoadMoreSequencePageIndex: pageIndex,
			shoptimizerLoadMoreContextKey: getContextKey( pageUrl ),
			shoptimizerLoadMorePageUrl: normalizePageUrl( pageUrl ),
			shoptimizerLoadMoreNextUrl: nextLink ? normalizePageUrl( nextLink.href ) : null,
			shoptimizerLoadMorePrevUrl: previousUrl ? normalizePageUrl( previousUrl ) : null,
			shoptimizerLoadMorePaginationHTML: getPaginationHTML( document ),
			shoptimizerLoadMoreResult: getResultState(),
			shoptimizerLoadMoreScrollY: window.scrollY,
			shoptimizerLoadMoreBoundaryMarkerId: getCurrentMarker( baseState.shoptimizerLoadMoreSequenceId, pageUrl, pageIndex ),
		} );

		if ( ! state.shoptimizerLoadMorePaginationHTML || getStateByteLength( state ) > historyStateByteLimit ) {
			delete state.shoptimizerLoadMorePaginationHTML;
			state.shoptimizerLoadMoreNeedsRefetch = true;
		}

		return state;
	}

	function updateHistory( nextUrl, currentUrl ) {
		var currentState = getHistoryState();
		var nextState;
		var currentPageIndex;

		currentState.shoptimizerLoadMore = true;
		currentState.shoptimizerLoadMoreNextUrl = normalizePageUrl( nextUrl );
		writeHistoryState( currentState, currentUrl, 'replace' );
		currentPageIndex = parseInt( currentState.shoptimizerLoadMoreSequencePageIndex, 10 ) || 1;
		nextState = getEntryState( Object.assign( {}, currentState, {
			shoptimizerLoadMoreScrollY: null,
			shoptimizerLoadMorePrevUrl: normalizePageUrl( currentUrl ),
		} ), nextUrl, currentPageIndex + 1, currentUrl );

		return writeHistoryState( nextState, nextUrl, 'push' );
	}

	function saveCurrentHistorySnapshot( forceNewSequence ) {
		var state = getHistoryState();

		if ( state.shoptimizerLoadMore !== true || restoringArchive ) {
			return false;
		}

		return saveArchiveSnapshot( state, !! forceNewSequence );
	}

	function applyEntryMetadata( state ) {
		var metadata = state && state.shoptimizerLoadMoreResult;

		if ( ! metadata ) {
			return false;
		}

		resultFrom = parseInt( metadata.from, 10 ) || 0;
		resultTo = parseInt( metadata.to, 10 ) || 0;
		resultTotal = parseInt( metadata.total, 10 ) || 0;
		updateWrapperResultMetadata( { from: resultFrom, to: resultTo, total: resultTotal } );
		updateViewedCount();
		updateResultCount();
		return true;
	}

	function restoreEntryPagination( state ) {
		if ( state && state.shoptimizerLoadMoreNeedsRefetch ) {
			return false;
		}

		if ( ! state || ! state.shoptimizerLoadMorePaginationHTML ) {
			return false;
		}

		return replacePaginationFromHTML( state.shoptimizerLoadMorePaginationHTML );
	}

	function replacePaginationFromHTML( paginationHTML ) {
		var currentPaginations = getPaginationElements( document );
		var replacements = ( paginationHTML || [] ).map( function ( html ) {
			var wrapper = document.createElement( 'div' );
			wrapper.innerHTML = html;
			return wrapper.firstElementChild;
		} ).filter( function ( element ) {
			return !! element;
		} );

		if ( ! replacements.length ) {
			return false;
		}

		ignoreMutationBatch = true;
		currentPaginations.forEach( function ( currentPagination, index ) {
			currentPagination.replaceWith( ( replacements[ index ] || replacements[ 0 ] ).cloneNode( true ) );
		} );
		if ( ! currentPaginations.length ) {
			var siteMain = document.querySelector( '.site-main' );
			if ( siteMain ) {
				siteMain.appendChild( replacements[ 0 ].cloneNode( true ) );
			}
		}
		return true;
	}

	function refetchEntryMetadata( state ) {
		return fetch( state.shoptimizerLoadMorePageUrl, { credentials: 'same-origin' } )
			.then( function ( response ) {
				if ( ! response.ok ) {
					throw new Error( 'HTTP ' + response.status );
				}

				return response.text();
			} )
			.then( function ( html ) {
				var responseDocument = new DOMParser().parseFromString( html, 'text/html' );
				var metadata = getResultMetadata( responseDocument );
				var paginationHTML = getPaginationHTML( responseDocument );

				if ( normalizePageUrl( window.location.href ) !== normalizePageUrl( state.shoptimizerLoadMorePageUrl ) || ! metadata || ! paginationHTML || ! replacePaginationFromHTML( paginationHTML ) ) {
					throw new Error( 'Load More metadata unavailable' );
				}

				resultFrom = metadata.from;
				resultTo = metadata.to;
				resultTotal = metadata.total;
				updateWrapperResultMetadata( metadata );
				updateViewedCount();
				updateResultCount();
				updateLoadMoreVisibility();
				writeHistoryState( Object.assign( {}, state, {
					shoptimizerLoadMorePaginationHTML: paginationHTML,
					shoptimizerLoadMoreNeedsRefetch: false,
					shoptimizerLoadMoreResult: getResultState(),
				} ), window.location.href, 'replace' );
				return true;
			} );
	}

	// Snapshots are an optimization. Rebuild from pagination when storage is
	// unavailable, full, or has been replaced by another archive sequence.
	function rebuildArchive( state, complete ) {
		var request = ++archiveRestoreRequest;
		var location = window.location.href;
		var targetIndex = parseInt( state.shoptimizerLoadMoreSequencePageIndex, 10 ) || 1;
		var siteMain = document.querySelector( '.site-main' );
		var requestGrid = findGrid( document );
		var requestFirstProduct = getProducts( requestGrid )[ 0 ];
		var rebuiltMain;
		var rebuiltGrid;
		var lastDocument;
		var visited = [];

		function isCurrent() {
			var current = getHistoryState();
			return request === archiveRestoreRequest && location === window.location.href &&
				current.shoptimizerLoadMoreSequenceId === state.shoptimizerLoadMoreSequenceId &&
				current.shoptimizerLoadMoreSequencePageIndex === state.shoptimizerLoadMoreSequencePageIndex &&
				siteMain === document.querySelector( '.site-main' ) &&
				requestGrid === findGrid( document ) && getProducts( requestGrid )[ 0 ] === requestFirstProduct;
		}

		function fetchPage( url, index ) {
			url = normalizePageUrl( url );
			if ( ! isCurrent() ) {
				return Promise.resolve( false );
			}
			if ( new URL( url ).origin !== window.location.origin || getContextKey( url ) !== state.shoptimizerLoadMoreContextKey || visited.indexOf( url ) !== -1 ) {
				return Promise.reject( new Error( 'Load More archive context changed' ) );
			}
			visited.push( url );
			return fetch( url, { credentials: 'same-origin' } ).then( function ( response ) {
				if ( ! response.ok ) {
					throw new Error( 'HTTP ' + response.status );
				}
				return response.text();
			} ).then( function ( html ) {
				var responseDocument = new DOMParser().parseFromString( html, 'text/html' );
				var responseGrid = findGrid( responseDocument );
				var products = getProducts( responseGrid );
				var nextLink;

				if ( ! isCurrent() ) {
					return false;
				}
				if ( ! products.length || ! responseDocument.querySelector( '.site-main' ) ) {
					throw new Error( 'Load More product grid unavailable' );
				}
				markPageStart( products[ 0 ], url, state.shoptimizerLoadMoreSequenceId, index );
				if ( index === 1 ) {
					rebuiltMain = responseDocument.querySelector( '.site-main' );
					rebuiltGrid = responseGrid;
				} else {
					products.forEach( function ( product ) {
						rebuiltGrid.appendChild( product );
					} );
				}
				lastDocument = responseDocument;
				if ( index === targetIndex ) {
					if ( url !== normalizePageUrl( state.shoptimizerLoadMorePageUrl ) ) {
						throw new Error( 'Load More pagination changed' );
					}
					return true;
				}
				nextLink = getNextPageLink( responseDocument );
				if ( ! nextLink ) {
					throw new Error( 'Load More next page unavailable' );
				}
				return fetchPage( new URL( nextLink.getAttribute( 'href' ), url ).href, index + 1 );
			} );
		}

		if ( ! siteMain || ! state.shoptimizerLoadMoreStartUrl ) {
			reloadCanonicalArchive( state );
			return;
		}
		restoringArchive = true;
		setLoading( true );
		fetchPage( state.shoptimizerLoadMoreStartUrl, 1 ).then( function ( restored ) {
			if ( ! restored || ! isCurrent() ) {
				if ( request === archiveRestoreRequest ) {
					restoringArchive = false;
					setLoading( false );
				}
				return;
			}
			ignoreMutationBatch = true;
			siteMain.innerHTML = rebuiltMain.innerHTML;
			refreshElements();
			replacePagination( lastDocument );
			restoringArchive = false;
			finishRequest();
			complete();
		} ).catch( function () {
			if ( isCurrent() ) {
				restoringArchive = false;
				setLoading( false );
				reloadCanonicalArchive( state );
			} else if ( request === archiveRestoreRequest ) {
				restoringArchive = false;
				setLoading( false );
			}
		} );
	}

	function reloadCanonicalArchive( state ) {
		var reloadState;

		if ( state && state.shoptimizerLoadMoreReloaded ) {
			return;
		}

		reloadState = Object.assign( {}, state || getHistoryState(), {
			shoptimizerLoadMoreReloaded: true,
		} );
		writeHistoryState( reloadState, window.location.href, 'replace' );
		window.location.replace( state && state.shoptimizerLoadMorePageUrl ? state.shoptimizerLoadMorePageUrl : window.location.href );
	}

	function onPopState( event, rebuilt ) {
		archiveRestoreRequest += 1;
		restoringArchive = false;
		setLoading( false );
		if ( ! event.state || event.state.shoptimizerLoadMore !== true ) {
			return;
		}

		if ( ! rebuilt && ! restoreArchiveSnapshot( event.state ) ) {
			rebuildArchive( event.state, function () {
				onPopState( { state: event.state }, true );
			} );
			return;
		}

		refreshElements();
		applyEntryMetadata( event.state );
		restoreEntryPagination( event.state );
		bindButton();
		updateLoadMoreVisibility();
		if ( event.state.shoptimizerLoadMoreNeedsRefetch || ! event.state.shoptimizerLoadMorePaginationHTML || ! getNextPageLink( document ) && event.state.shoptimizerLoadMoreNextUrl ) {
			refetchEntryMetadata( event.state ).catch( function () {
				reloadCanonicalArchive( event.state );
			} );
		}
		restoreScrollPosition( event.state );
	}

	function markCurrentPageStart() {
		var products = getProducts( grid );
		var state = getHistoryState();

		if ( state.shoptimizerLoadMoreSequenceId && parseInt( state.shoptimizerLoadMoreSequencePageIndex, 10 ) > 1 ) {
			return;
		}

		if ( products.length ) {
			markPageStart( products[ 0 ], window.location.href, state.shoptimizerLoadMoreSequenceId, state.shoptimizerLoadMoreSequencePageIndex || 1 );
		}
	}

	function replacePagination( responseDocument ) {
		var currentPaginations = getPaginationElements( document );
		var responsePaginations = getPaginationElements( responseDocument );

		if ( responsePaginations.length ) {
			currentPaginations.forEach( function ( currentPagination, index ) {
				var responsePagination = responsePaginations[ index ] || responsePaginations[ 0 ];
				currentPagination.replaceWith( document.importNode( responsePagination, true ) );
			} );
		} else {
			currentPaginations.forEach( function ( currentPagination ) {
				currentPagination.remove();
			} );
		}
	}

	function finishRequest() {
		setLoading( false );
		refreshElements();
		initializeProductCarousels( document.querySelector( '.site-main' ) );
		bindButton();
		updateViewedCount();
		updateResultCount();
		updateLoadMoreVisibility();
	}

	function loadNextPage() {
		var nextLink = getNextPageLink( document );
		var nextUrl;
		var requestLocation;
		var requestGrid;
		var requestFirstProduct;

		if ( loading || ! nextLink ) {
			return;
		}

		prepareInitialHistoryState();
		nextUrl = new URL( nextLink.href, window.location.href ).href;
		requestLocation = window.location.href;
		requestGrid = grid;
		requestFirstProduct = getProducts( grid )[ 0 ] || null;
		setLoading( true );

		fetch( nextUrl, {
			credentials: 'same-origin'
		} )
			.then( function ( response ) {
				if ( ! response.ok ) {
					throw new Error( 'HTTP ' + response.status );
				}

				return response.text();
			} )
			.then( function ( html ) {
				var responseDocument;
				var responseGrid;
				var responseProducts;
				var responseMetadata;
				var currentGrid;
				var currentFirstProduct;
				var fragment;
				var firstNewProduct = null;

				// A filter may have changed the archive while this request was in
				// flight. Never append an old archive response to the new grid.
				currentGrid = findGrid( document );
				currentFirstProduct = getProducts( currentGrid )[ 0 ] || null;
				if ( requestLocation !== window.location.href || requestGrid !== currentGrid || requestFirstProduct !== currentFirstProduct ) {
					finishRequest();
					return;
				}

				responseDocument = new DOMParser().parseFromString( html, 'text/html' );
				responseGrid = findGrid( responseDocument );

				if ( ! responseGrid ) {
					throw new Error( 'Product grid missing from response' );
				}

				responseProducts = getProducts( responseGrid );
				if ( ! responseProducts.length ) {
					ignoreMutationBatch = true;
					replacePagination( responseDocument );
					finishRequest();
					return;
				}

				responseMetadata = getResultMetadata( responseDocument );

				fragment = document.createDocumentFragment();
				responseProducts.forEach( function ( product ) {
					var importedProduct = document.importNode( product, true );

					if ( ! firstNewProduct ) {
						firstNewProduct = importedProduct;
					}
					fragment.appendChild( importedProduct );
				} );

				var currentState = getHistoryState();
				var currentPageIndex = parseInt( currentState.shoptimizerLoadMoreSequencePageIndex, 10 ) || 1;
				markPageStart( firstNewProduct, nextUrl, currentState.shoptimizerLoadMoreSequenceId, currentPageIndex + 1 );
				ignoreMutationBatch = true;
				grid.appendChild( fragment );
				replacePagination( responseDocument );
				if ( responseMetadata ) {
					resultTotal = responseMetadata.total;
					resultTo = responseMetadata.to;
					updateWrapperResultMetadata( {
						from: resultFrom,
						to: resultTo,
						total: resultTotal,
					} );
					updateResultCount();
				}
				updateHistory( nextUrl, requestLocation );
				focusFirstNewProduct( firstNewProduct );
				finishRequest();
				saveCurrentHistorySnapshot( false );
			} )
			.catch( function ( error ) {
				console.error( 'Load More Error:', error );
				finishRequest();
				showErrorMessage( ShoptimizerLoadMore.i18n.error_message );
		} );
	}

	function isRelevantMutationNode( node ) {
		if ( ! node || node.nodeType !== 1 ) {
			return false;
		}

		return node.matches( '.products, .woocommerce-pagination, .woocommerce-result-count, .shoptimizer-sorting, .shoptimizer-load-more-wrapper' ) || !! node.querySelector( '.products, .woocommerce-pagination, .woocommerce-result-count, .shoptimizer-sorting, .shoptimizer-load-more-wrapper' );
	}

	function hasRelevantMutations( mutations ) {
		return mutations.some( function ( mutation ) {
			if ( isRelevantMutationNode( mutation.target ) ) {
				return true;
			}

			return Array.prototype.some.call( mutation.addedNodes, isRelevantMutationNode ) || Array.prototype.some.call( mutation.removedNodes, isRelevantMutationNode );
		} );
	}

	function onGridMutation( mutations ) {
		if ( ignoreMutationBatch ) {
			ignoreMutationBatch = false;
			return;
		}

		if ( loading || ! hasRelevantMutations( mutations ) ) {
			return;
		}

		if ( filterRefreshFrame ) {
			cancelAnimationFrame( filterRefreshFrame );
		}

		filterRefreshFrame = requestAnimationFrame( function () {
			filterRefreshFrame = null;
			if ( loading ) {
				return;
			}

			refreshElements();
			initializeProductCarousels( document.querySelector( '.site-main' ) );
			bindButton();
			var metadata = syncResultMetadata( document );
			if ( metadata ) {
				updateWrapperResultMetadata( metadata );
				updateResultCount();
			}
			updateViewedCount();
			startNewSequenceForCurrentContext();
			markCurrentPageStart();
			updateLoadMoreVisibility();
		} );
	}

	function bindButton() {
		if ( ! button || button.getAttribute( 'data-shoptimizer-bound' ) === 'yes' ) {
			return;
		}

		button.addEventListener( 'click', loadNextPage );
		button.setAttribute( 'data-shoptimizer-bound', 'yes' );
	}

	function initializeProductCarousels( root ) {
		if ( typeof window.shoptimizerInitProductCarousels === 'function' ) {
			window.shoptimizerInitProductCarousels( root );
		}
	}

	function prepareInitialHistoryState() {
		var state = getHistoryState();
		var sequenceId;

		if ( state.shoptimizerLoadMore === true && state.shoptimizerLoadMoreSequenceId && state.shoptimizerLoadMoreContextKey === getContextKey( window.location.href ) ) {
			return;
		}

		useManualScrollRestoration();
		sequenceId = createSequenceId();
		state.shoptimizerLoadMore = true;
		state.shoptimizerLoadMoreSequenceId = sequenceId;
		state.shoptimizerLoadMoreSequencePageIndex = 1;
		state.shoptimizerLoadMoreContextKey = getContextKey( window.location.href );
		state = getEntryState( state, window.location.href, 1, null );
		writeHistoryState( state, window.location.href, 'replace' );
		saveCurrentHistorySnapshot( true );
	}

	function clearLoadMoreState( state ) {
		var cleared = Object.assign( {}, state );
		[
			'shoptimizerLoadMore',
			'shoptimizerLoadMoreUrl',
			'shoptimizerLoadMoreStartUrl',
			'shoptimizerLoadMoreSnapshotKey',
			'shoptimizerLoadMoreSequenceId',
			'shoptimizerLoadMoreSequencePageIndex',
			'shoptimizerLoadMoreContextKey',
			'shoptimizerLoadMorePageUrl',
			'shoptimizerLoadMoreNextUrl',
			'shoptimizerLoadMorePrevUrl',
			'shoptimizerLoadMorePaginationHTML',
			'shoptimizerLoadMoreResult',
			'shoptimizerLoadMoreScrollY',
			'shoptimizerLoadMoreBoundaryMarkerId',
			'shoptimizerLoadMoreSnapshotUnavailable',
			'shoptimizerLoadMoreNeedsReload',
			'shoptimizerLoadMoreNeedsRefetch',
			'shoptimizerLoadMoreReloaded',
		].forEach( function ( key ) {
			delete cleared[ key ];
		} );
		return cleared;
	}

	function migrateLegacySnapshot() {
		var state = getHistoryState();
		var storage = getSessionStorage();
		var legacyKey = state.shoptimizerLoadMoreSnapshotKey;
		var legacyHTML;
		var sequenceId;
		var pageIndex;

		if ( ! storage || ! legacyKey || legacyKey === snapshotKey || legacyKey.indexOf( snapshotPrefix ) !== 0 ) {
			return;
		}

		try {
			legacyHTML = storage.getItem( legacyKey );
		} catch ( error ) {
			return;
		}

		if ( ! legacyHTML ) {
			return;
		}

		sequenceId = state.shoptimizerLoadMoreSequenceId || createSequenceId();
		pageIndex = parseInt( state.shoptimizerLoadMoreSequencePageIndex, 10 ) || ( legacyHTML.match( /shoptimizer-load-more-page-start/g ) || [] ).length || 1;
		try {
			storage.setItem( snapshotKey, JSON.stringify( {
				sequenceId: sequenceId,
				sequencePageIndex: pageIndex,
				savedAt: Date.now(),
				html: legacyHTML,
			} ) );
			state.shoptimizerLoadMore = true;
			state.shoptimizerLoadMoreSnapshotKey = snapshotKey;
			state.shoptimizerLoadMoreSequenceId = sequenceId;
			state.shoptimizerLoadMoreSequencePageIndex = pageIndex;
			state.shoptimizerLoadMorePageUrl = state.shoptimizerLoadMorePageUrl || normalizePageUrl( window.location.href );
			state.shoptimizerLoadMoreContextKey = state.shoptimizerLoadMoreContextKey || getContextKey( window.location.href );
			writeHistoryState( state, window.location.href, 'replace' );
		} catch ( error ) {
			if ( isStorageWriteError( error ) ) {
				disableSnapshotWrites( error );
			}
		}
	}

	function cleanupLegacySnapshots() {
		var storage = getSessionStorage();
		var keys = [];

		if ( ! storage ) {
			return;
		}

		migrateLegacySnapshot();
		try {
			for ( var index = 0; index < storage.length; index++ ) {
				if ( storage.key( index ) && storage.key( index ).indexOf( snapshotPrefix ) === 0 && storage.key( index ) !== snapshotKey ) {
					keys.push( storage.key( index ) );
				}
			}
			keys.forEach( function ( key ) {
				storage.removeItem( key );
			} );
		} catch ( error ) {
			if ( isStorageWriteError( error ) ) {
				disableSnapshotWrites( error );
			}
		}
	}

	function startNewSequenceForCurrentContext() {
		var state = getHistoryState();
		var sequenceId;

		if ( state.shoptimizerLoadMore !== true || state.shoptimizerLoadMoreContextKey === getContextKey( window.location.href ) ) {
			return;
		}

		sequenceId = createSequenceId();
		state.shoptimizerLoadMoreSequenceId = sequenceId;
		state.shoptimizerLoadMoreSequencePageIndex = 1;
		state.shoptimizerLoadMoreContextKey = getContextKey( window.location.href );
		state = getEntryState( state, window.location.href, 1, null );
		writeHistoryState( state, window.location.href, 'replace' );
		saveCurrentHistorySnapshot( true );
	}

	function initialize( rebuiltState ) {
		var state;
		var restoredFromHistory;

		cleanupLegacySnapshots();
		state = getHistoryState();
		if ( state.shoptimizerLoadMoreReloaded ) {
			state = clearLoadMoreState( state );
			writeHistoryState( state, window.location.href, 'replace' );
		}
		restoredFromHistory = !! rebuiltState || state.shoptimizerLoadMore === true && restoreArchiveSnapshot( state );

		refreshElements();
		if ( ! grid ) {
			return;
		}

		grid.setAttribute( 'aria-live', 'polite' );
		grid.setAttribute( 'aria-busy', 'false' );
		syncResultMetadata( document );
		updateViewedCount();
		if ( restoredFromHistory ) {
			applyEntryMetadata( state );
			restoreEntryPagination( state );
		} else if ( state.shoptimizerLoadMore === true ) {
			rebuildArchive( state, function () {
				initialize( state );
			} );
			return;
		} else {
			markCurrentPageStart();
		}
		bindButton();
		updateLoadMoreVisibility();
		window.addEventListener( 'popstate', onPopState );
		window.addEventListener( 'pagehide', function () {
			saveHistoryScrollPosition( true );
		} );
		window.addEventListener( 'pageshow', function ( event ) {
			if ( event.persisted ) {
				restoreScrollPosition( getHistoryState() );
			}
		} );
		window.addEventListener( 'scroll', queueHistoryScrollPosition, { passive: true } );

		if ( restoredFromHistory ) {
			if ( state.shoptimizerLoadMoreNeedsRefetch || ! state.shoptimizerLoadMorePaginationHTML || ! getNextPageLink( document ) && state.shoptimizerLoadMoreNextUrl ) {
				refetchEntryMetadata( state ).catch( function () {
					reloadCanonicalArchive( state );
				} );
			}
			restoreScrollPosition( getHistoryState() );
			window.addEventListener( 'load', function () {
				restoreScrollPosition( state );
			} );
		}

		var siteMain = document.querySelector( '.site-main' );
		if ( siteMain ) {
			var gridObserver = new MutationObserver( onGridMutation );
			gridObserver.observe( siteMain, { childList: true, subtree: true } );
		}
		if ( restoredFromHistory ) {
			ignoreMutationBatch = false;
		}
	}

	initialize();
} );
