(function (window) {
	'use strict';

	window.ShoptimizerOnboardingApp.registerFeature('brand', function (context) {
		var brandNotice = context.app.querySelector('[data-brand-notice]');
		var primaryColorInput = context.app.querySelector('[data-brand-primary-color]');
		var primaryColorTextInput = context.app.querySelector('[data-brand-primary-color-text]');
		var primaryColorResetButton = context.app.querySelector('[data-brand-reset-color]');
		var primaryColorPresetButtons = Array.prototype.slice.call(context.app.querySelectorAll('[data-brand-primary-preset]'));
		var brandSelectImageButtons = Array.prototype.slice.call(context.app.querySelectorAll('[data-brand-select-image]'));
		var brandRemoveImageButtons = Array.prototype.slice.call(context.app.querySelectorAll('[data-brand-remove-image]'));
		var brandState = getStateFromStatus();
		var isDirtyState = false;

		function getStateFromStatus() {
			var status = context.getStatus();
			var brand = status && status.brand ? status.brand : {};

			return {
				primaryColor: normalizeHexColor(brand.primary_color || brand.default_primary_color || '#dc9814'),
				defaultPrimaryColor: normalizeHexColor(brand.default_primary_color || '#dc9814'),
				logo: getImageState(brand.logo),
				siteIcon: getImageState(brand.site_icon)
			};
		}

		function getImageState(image) {
			image = image || {};

			return {
				id: image.id ? parseInt(image.id, 10) : 0,
				url: image.url || '',
				thumbnail: image.thumbnail || image.url || '',
				title: image.title || ''
			};
		}

		function normalizeHexColor(value) {
			value = String(value || '').trim();

			return /^#[0-9a-fA-F]{6}$/.test(value) ? value : '#dc9814';
		}

		function isValidHexColor(value) {
			return /^#[0-9a-fA-F]{6}$/.test(String(value || '').trim());
		}

		function render() {
			var status = context.getStatus();

			if (!status.brand) {
				return;
			}

			brandState = getStateFromStatus();
			isDirtyState = false;
			updateColorInputs(brandState.primaryColor);
			renderImage('logo');
			renderImage('site_icon');
			context.updateNextButtonLabel();
		}

		function updateColorInputs(color) {
			if (primaryColorInput) {
				primaryColorInput.value = color;
			}

			if (primaryColorTextInput) {
				primaryColorTextInput.value = color;
			}

			updateColorPresets(color);
		}

		function updateColorPresets(color) {
			primaryColorPresetButtons.forEach(function (button) {
				var isSelected = normalizeHexColor(button.getAttribute('data-brand-primary-preset')) === normalizeHexColor(color);

				button.classList.toggle('is-selected', isSelected);
				button.setAttribute('aria-pressed', isSelected ? 'true' : 'false');
			});
		}

		function renderImage(type) {
			var preview = context.app.querySelector('[data-brand-preview="' + type + '"]');
			var removeButton = context.app.querySelector('[data-brand-remove-image="' + type + '"]');
			var image = preview ? preview.querySelector('[data-brand-preview-image]') : null;
			var imageState = type === 'site_icon' ? brandState.siteIcon : brandState.logo;
			var previewUrl = getPreviewUrl(type, imageState);
			var hasImage = !!(imageState && imageState.id && previewUrl);

			if (preview) {
				preview.hidden = !hasImage;
			}

			if (image) {
				image.hidden = !hasImage;

				if (hasImage) {
					image.src = previewUrl;
				} else {
					image.removeAttribute('src');
				}
			}

			if (removeButton) {
				removeButton.hidden = !hasImage;
			}
		}

		function markDirty() {
			isDirtyState = getSignature(brandState) !== getSignature(getStateFromStatus());
			context.updateNextButtonLabel();
		}

		function getSignature(state) {
			return [
				normalizeHexColor(state.primaryColor),
				state.logo && state.logo.id ? state.logo.id : 0,
				state.siteIcon && state.siteIcon.id ? state.siteIcon.id : 0
			].join('|');
		}

		function getPreviewUrl(type, imageState) {
			if (!imageState) {
				return '';
			}

			return type === 'logo' ? imageState.url || imageState.thumbnail : imageState.thumbnail || imageState.url;
		}

		function setImage(type, attachment) {
			var imageState = {
				id: attachment.id ? parseInt(attachment.id, 10) : 0,
				url: attachment.url || '',
				thumbnail: getAttachmentPreviewUrl(attachment),
				title: attachment.title || ''
			};

			if (type === 'site_icon') {
				brandState.siteIcon = imageState;
			} else {
				brandState.logo = imageState;
			}

			renderImage(type);
			markDirty();
			clearNotice();
		}

		function removeImage(type) {
			if (type === 'site_icon') {
				brandState.siteIcon = getImageState();
			} else {
				brandState.logo = getImageState();
			}

			renderImage(type);
			markDirty();
			clearNotice();
		}

		function getAttachmentPreviewUrl(attachment) {
			if (attachment.sizes && attachment.sizes.thumbnail && attachment.sizes.thumbnail.url) {
				return attachment.sizes.thumbnail.url;
			}

			if (attachment.sizes && attachment.sizes.medium && attachment.sizes.medium.url) {
				return attachment.sizes.medium.url;
			}

			return attachment.url || '';
		}

		function openMediaFrame(type) {
			var frame;
			var title = type === 'site_icon' ? context.t('selectSiteIcon', 'Select site icon') : context.t('selectLogo', 'Select logo');

			if (!window.wp || !window.wp.media) {
				showNotice(context.t('mediaUnavailable', 'The WordPress media library is not available.'), 'error');
				return;
			}

			frame = window.wp.media({
				title: title,
				button: {
					text: context.t('useThisImage', 'Use this image')
				},
				library: {
					type: 'image'
				},
				multiple: false
			});

			frame.on('select', function () {
				var attachment = frame.state().get('selection').first().toJSON();
				setImage(type, attachment);
			});

			frame.open();
		}

		function showNotice(message, type) {
			if (!brandNotice) {
				return;
			}

			brandNotice.hidden = false;
			brandNotice.className = 'shoptimizer-brand-notice is-' + type;
			brandNotice.textContent = message;
		}

		function clearNotice() {
			if (!brandNotice) {
				return;
			}

			brandNotice.hidden = true;
			brandNotice.textContent = '';
		}

		function save() {
			var endpoint = context.config.actions ? context.config.actions.saveBrand : '';
			var primaryColor = primaryColorTextInput ? primaryColorTextInput.value.trim() : brandState.primaryColor;

			if (!endpoint) {
				showNotice(context.t('brandUnavailable', 'Brand saving is not available yet.'), 'error');
				return Promise.reject(new Error(context.t('brandUnavailable', 'Brand saving is not available yet.')));
			}

			if (!isValidHexColor(primaryColor)) {
				showNotice(context.t('brandInvalidColor', 'Please enter a valid 6-digit hex color.'), 'error');
				return Promise.reject(new Error(context.t('brandInvalidColor', 'Please enter a valid 6-digit hex color.')));
			}

			brandState.primaryColor = primaryColor;
			clearNotice();

			if (context.els.nextButton) {
				context.els.nextButton.disabled = true;
				context.els.nextButton.textContent = context.t('savingBrand', 'Saving brand settings…');
			}

			return window.fetch(endpoint, {
				method: 'POST',
				credentials: 'same-origin',
				headers: {
					'Content-Type': 'application/json',
					'X-WP-Nonce': context.config.nonce
				},
				body: JSON.stringify({
					primary_color: brandState.primaryColor,
					logo_id: brandState.logo.id,
					site_icon_id: brandState.siteIcon.id
				})
			})
				.then(function (response) {
					return response.json().then(function (data) {
						if (!response.ok) {
							throw new Error(data && data.message ? data.message : context.t('brandSaveFailed', 'Brand settings could not be saved.'));
						}

						return data;
					});
				})
				.then(function (data) {
					context.setStatus(data);
					context.render();
					isDirtyState = false;
					context.updateNextButtonLabel();
					return data;
				})
				.catch(function (error) {
					showNotice(error.message, 'error');
					throw error;
				})
				.finally(function () {
					if (context.els.nextButton) {
						context.els.nextButton.disabled = false;
						context.updateNextButtonLabel();
					}
				});
		}

		if (primaryColorInput) {
			primaryColorInput.addEventListener('input', function () {
				brandState.primaryColor = normalizeHexColor(primaryColorInput.value);
				updateColorInputs(brandState.primaryColor);
				markDirty();
				clearNotice();
			});
		}

		if (primaryColorTextInput) {
			primaryColorTextInput.addEventListener('input', function () {
				if (isValidHexColor(primaryColorTextInput.value)) {
					brandState.primaryColor = primaryColorTextInput.value.trim();
					updateColorInputs(brandState.primaryColor);
					markDirty();
					clearNotice();
				}
			});
		}

		if (primaryColorResetButton) {
			primaryColorResetButton.addEventListener('click', function () {
				brandState.primaryColor = brandState.defaultPrimaryColor;
				updateColorInputs(brandState.primaryColor);
				markDirty();
				clearNotice();
			});
		}

		primaryColorPresetButtons.forEach(function (button) {
			button.addEventListener('click', function () {
				brandState.primaryColor = normalizeHexColor(button.getAttribute('data-brand-primary-preset'));
				updateColorInputs(brandState.primaryColor);
				markDirty();
				clearNotice();
			});
		});

		brandSelectImageButtons.forEach(function (button) {
			button.addEventListener('click', function () {
				openMediaFrame(button.getAttribute('data-brand-select-image'));
			});
		});

		brandRemoveImageButtons.forEach(function (button) {
			button.addEventListener('click', function () {
				removeImage(button.getAttribute('data-brand-remove-image'));
			});
		});

		return {
			clearNotice: clearNotice,
			discard: render,
			isDirty: function () {
				return isDirtyState;
			},
			render: render,
			save: save,
			showNotice: showNotice
		};
	});
})(window);
