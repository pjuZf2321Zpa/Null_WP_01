(function (window) {
	'use strict';

	window.ShoptimizerOnboardingApp.registerFeature('finish', function (context) {
		var finishNotice = context.app.querySelector('[data-finish-notice]');
		var finishTitle = context.app.querySelector('[data-finish-title]');
		var finishCopy = context.app.querySelector('[data-finish-copy]');

		function showNotice(message, type) {
			if (!finishNotice) {
				return;
			}

			finishNotice.hidden = false;
			finishNotice.className = 'shoptimizer-finish-notice is-' + type;
			finishNotice.textContent = message;
		}

		function clearNotice() {
			if (!finishNotice) {
				return;
			}

			finishNotice.hidden = true;
			finishNotice.textContent = '';
		}

		function render() {
			var status = context.getStatus();
			var quickSetup = status.quick_setup || {};
			var hasIncompleteTasks = (quickSetup.skipped || 0) > 0 || (quickSetup.needs_attention || 0) > 0;

			if (finishTitle) {
				finishTitle.textContent = hasIncompleteTasks ? context.t('finishGuidedTitle', 'Guided setup complete') : context.t('finishCompleteTitle', 'Setup complete — your store is ready');
			}

			if (finishCopy) {
				finishCopy.textContent = hasIncompleteTasks ? context.t('finishGuidedCopy', 'Review any skipped or unfinished tasks from the dashboard whenever you are ready.') : context.t('finishCompleteCopy', 'Your store foundation is ready. Review the front end, then refine your branding, products, and checkout settings.');
			}
		}

		function complete() {
			var endpoint = context.config.actions ? context.config.actions.complete : '';

			if (!endpoint) {
				showNotice(context.t('completeFailed', 'Setup could not be marked as complete. Please try again.'), 'error');
				return;
			}

			clearNotice();

			if (context.els.nextButton) {
				context.els.nextButton.disabled = true;
				context.els.nextButton.textContent = context.t('finishing', 'Finishing…');
			}

			window.fetch(endpoint, {
				method: 'POST',
				credentials: 'same-origin',
				headers: {
					'Content-Type': 'application/json',
					'X-WP-Nonce': context.config.nonce
				}
			})
				.then(function (response) {
					return response.json().then(function (data) {
						if (!response.ok) {
							throw new Error(data && data.message ? data.message : context.t('completeFailed', 'Setup could not be marked as complete. Please try again.'));
						}

						return data;
					});
				})
				.then(function (data) {
					context.setStatus(data);
					context.render();
					context.setView('welcome', { moveFocus: true });
				})
				.catch(function (error) {
					showNotice(error && error.message ? error.message : context.t('completeFailed', 'Setup could not be marked as complete. Please try again.'), 'error');
				})
				.finally(function () {
					if (context.els.nextButton) {
						context.els.nextButton.disabled = false;
						context.updateNextButtonLabel();
					}
				});
		}

		return {
			complete: complete,
			render: render
		};
	});
})(window);
