(function (window) {
	'use strict';

	window.ShoptimizerOnboardingApp.registerFeature('fontCache', function (context) {
		var fontCacheClearButton = context.app.querySelector('[data-font-cache-clear]');
		var fontCacheStatus = context.app.querySelector('[data-font-cache-status]');

		function showStatus(message, type) {
			if (!fontCacheStatus) {
				return;
			}

			fontCacheStatus.hidden = false;
			fontCacheStatus.className = 'shoptimizer-font-cache-status is-' + type;
			fontCacheStatus.textContent = message;
		}

		function clearStatus() {
			if (!fontCacheStatus) {
				return;
			}

			fontCacheStatus.hidden = true;
			fontCacheStatus.textContent = '';
		}

		function clearCache() {
			var endpoint = context.config.actions ? context.config.actions.clearFontCache : '';

			if (!endpoint) {
				showStatus(context.t('fontCacheUnavailable', 'Font cache clearing is not available yet.'), 'error');
				return;
			}

			clearStatus();

			if (fontCacheClearButton) {
				fontCacheClearButton.disabled = true;
				fontCacheClearButton.textContent = context.t('clearing', 'Clearing…');
			}

			window.fetch(endpoint, {
				method: 'POST',
				credentials: 'same-origin',
				headers: {
					'Content-Type': 'application/json',
					'X-WP-Nonce': context.config.nonce
				}
			})
				.then(function (response) {
					return response.json().then(function (data) {
						if (!response.ok) {
							throw new Error(data && data.message ? data.message : context.t('fontCacheFailed', 'Font cache could not be cleared.'));
						}

						return data;
					});
				})
				.then(function (data) {
					showStatus(data && data.message ? data.message : context.t('fontCacheCleared', 'Font cache cleared.'), 'success');
				})
				.catch(function (error) {
					showStatus(error.message, 'error');
				})
				.finally(function () {
					if (fontCacheClearButton) {
						fontCacheClearButton.disabled = false;
						fontCacheClearButton.textContent = context.t('clearCache', 'Clear cache');
					}
				});
		}

		if (fontCacheClearButton) {
			fontCacheClearButton.addEventListener('click', clearCache);
		}

		return {};
	});
})(window);
