(function (window) {
	'use strict';

	window.ShoptimizerOnboardingApp.registerFeature('plugins', function (context) {
		var pluginList = context.app.querySelector('[data-plugin-list]');
		var pluginNotice = context.app.querySelector('[data-plugin-notice]');

		function render() {
			var status = context.getStatus();

			if (!pluginList || !status.plugins) {
				return;
			}

			pluginList.innerHTML = '';

			status.plugins.forEach(function (plugin) {
				var card = context.createElement('div', 'shoptimizer-plugin-card is-' + plugin.status);
				var header = context.createElement('div', 'shoptimizer-plugin-card-header');
				var icon = context.createElement('span', 'shoptimizer-plugin-icon', plugin.icon_url ? '' : plugin.icon_label || plugin.name.charAt(0));
				var heading = context.createElement('div', 'shoptimizer-plugin-heading');
				var titleRow = context.createElement('div', 'shoptimizer-plugin-title-row');
				var description = context.createElement('p', 'shoptimizer-plugin-description', plugin.description);
				var footer = context.createElement('div', 'shoptimizer-plugin-card-footer');
				var pluginStatus = context.createElement('div', 'shoptimizer-plugin-status is-' + plugin.status);
				var statusDot = context.createElement('span', 'shoptimizer-plugin-status-dot');
				var statusText = context.createElement('span', 'shoptimizer-plugin-status-text', plugin.status_label);
				var actions = context.createElement('div', 'shoptimizer-plugin-actions');

				card.setAttribute('data-plugin-card', plugin.slug);
				icon.setAttribute('aria-hidden', 'true');

				if (plugin.icon_url) {
					var iconImage = context.createElement('img');
					iconImage.src = plugin.icon_url;
					iconImage.alt = '';
					icon.appendChild(iconImage);
				}

				titleRow.appendChild(context.createElement('strong', '', plugin.name));

				if (plugin.badge) {
					titleRow.appendChild(context.createElement('span', 'shoptimizer-plugin-badge', plugin.badge));
				}

				heading.appendChild(titleRow);

				if (plugin.version) {
					heading.appendChild(context.createElement('span', 'shoptimizer-plugin-version', context.sprintf(context.t('versionLabel', 'Version %s'), plugin.version)));
				}

				header.appendChild(icon);
				header.appendChild(heading);
				pluginStatus.appendChild(statusDot);
				pluginStatus.appendChild(statusText);

				if (plugin.actions && plugin.actions.activate) {
					actions.appendChild(createActionButton(plugin, 'activate', context.t('activate', 'Activate')));
				} else if (plugin.actions && plugin.actions.install) {
					actions.appendChild(createActionButton(plugin, 'install', context.t('install', 'Install')));
				} else if (plugin.actions && plugin.actions.manage && plugin.manage_url) {
					actions.appendChild(createManageLink(plugin));
				}

				footer.appendChild(pluginStatus);
				footer.appendChild(actions);
				card.appendChild(header);
				card.appendChild(description);
				card.appendChild(footer);
				pluginList.appendChild(card);
			});
		}

		function createActionButton(plugin, action, label) {
			var button = context.createElement('button', 'button button-secondary shoptimizer-plugin-action', label);
			button.type = 'button';
			button.setAttribute('data-plugin-slug', plugin.slug);
			button.setAttribute('data-plugin-action', action);

			button.addEventListener('click', function () {
				runAction(plugin.slug, action, button);
			});

			return button;
		}

		function createManageLink(plugin) {
			var link = context.createElement('a', 'button button-secondary shoptimizer-plugin-action', context.t('manage', 'Manage'));
			link.href = plugin.manage_url;

			return link;
		}

		function showNotice(message, type) {
			if (!pluginNotice) {
				return;
			}

			pluginNotice.hidden = false;
			pluginNotice.className = 'shoptimizer-plugin-notice is-' + type;
			pluginNotice.textContent = message;
		}

		function clearNotice() {
			if (!pluginNotice) {
				return;
			}

			pluginNotice.hidden = true;
			pluginNotice.textContent = '';
		}

		function runAction(slug, action, button) {
			var endpoint = getActionEndpoint(action);
			var actionLabel = action === 'install' ? context.t('install', 'Install') : context.t('activate', 'Activate');
			var progressLabel = action === 'install' ? context.t('installing', 'Installing plugin…') : context.t('activating', 'Activating plugin…');
			var successLabel = action === 'install' ? context.t('pluginInstalled', 'Plugin installed and activated successfully.') : context.t('pluginActivated', 'Plugin activated successfully.');

			if (!endpoint) {
				showNotice(context.t('pluginActionUnavailable', 'This plugin action is not available yet.'), 'error');
				return;
			}

			clearNotice();
			button.disabled = true;
			button.textContent = progressLabel;

			window.fetch(endpoint, {
				method: 'POST',
				credentials: 'same-origin',
				headers: {
					'Content-Type': 'application/json',
					'X-WP-Nonce': context.config.nonce
				},
				body: JSON.stringify({
					slug: slug
				})
			})
				.then(function (response) {
					return response.json().then(function (data) {
						if (!response.ok) {
							throw new Error(data && data.message ? data.message : context.t('pluginActionFailed', 'Plugin activation failed.'));
						}

						return data;
					});
				})
				.then(function (data) {
					context.setStatus(data);
					context.render();
					showNotice(successLabel, 'success');
				})
				.catch(function (error) {
					button.disabled = false;
					button.textContent = actionLabel;
					showNotice(error.message, 'error');
				});
		}

		function getActionEndpoint(action) {
			if (!context.config.actions) {
				return '';
			}

			if (action === 'install') {
				return context.config.actions.installPlugin;
			}

			return context.config.actions.activatePlugin;
		}

		return {
			clearNotice: clearNotice,
			render: render,
			showNotice: showNotice
		};
	});
})(window);
