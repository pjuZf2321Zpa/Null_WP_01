(function (window) {
	'use strict';

	window.ShoptimizerOnboardingApp.registerFeature('homepage', function (context) {
		var homepageStatus = context.app.querySelector('[data-homepage-status]');
		var homepageSelect = context.app.querySelector('[data-homepage-select]');
		var homepagePreview = context.app.querySelector('[data-homepage-preview]');
		var homepagePreviewViewport = context.app.querySelector('[data-homepage-preview-viewport]');
		var homepagePreviewFrame = context.app.querySelector('[data-homepage-preview-frame]');
		var homepagePreviewUrl = context.app.querySelector('[data-homepage-preview-url]');
		var homepageEmpty = context.app.querySelector('[data-homepage-empty]');
		var homepageNotice = context.app.querySelector('[data-homepage-notice]');
		var homepagePageId = getSavedPageId();
		var isDirtyState = false;

		function getSavedPageId() {
			var status = context.getStatus();

			if (!status.site || status.site.show_on_front !== 'page') {
				return 0;
			}

			return parseInt(status.site.page_on_front, 10) || 0;
		}

		function getPage(pageId) {
			var status = context.getStatus();
			var pages = status.site && status.site.pages ? status.site.pages : [];
			var selectedPage = null;

			pages.forEach(function (page) {
				if (parseInt(page.id, 10) === parseInt(pageId, 10)) {
					selectedPage = page;
				}
			});

			return selectedPage;
		}

		function render() {
			var status = context.getStatus();

			if (!homepageStatus || !homepageSelect || !status.site) {
				return;
			}

			var pages = status.site.pages || [];
			var savedPageId = getSavedPageId();

			if (!isDirtyState) {
				homepagePageId = savedPageId;
			}

			homepageSelect.innerHTML = '';

			var placeholder = context.createElement('option', '', pages.length ? context.t('homepageSelect', 'Select a page') : context.t('homepageNone', 'No published pages available'));
			placeholder.value = '';
			placeholder.disabled = true;
			homepageSelect.appendChild(placeholder);

			pages.forEach(function (page) {
				var option = context.createElement('option', '', page.title || context.t('homepageUntitled', 'Untitled page'));

				option.value = page.id;
				homepageSelect.appendChild(option);
			});

			homepageSelect.disabled = !pages.length;
			homepageSelect.value = homepagePageId ? String(homepagePageId) : '';
			updatePreview();
		}

		function updatePreview() {
			var page = getPage(homepagePageId);
			var hasPage = !!(page && page.url);

			if (homepagePreview) {
				homepagePreview.hidden = !hasPage;
			}

			if (homepageEmpty) {
				homepageEmpty.hidden = hasPage;
			}

			if (homepagePreviewFrame) {
				if (hasPage && homepagePreviewFrame.getAttribute('src') !== page.url) {
					homepagePreviewFrame.src = page.url;
				} else if (!hasPage) {
					homepagePreviewFrame.removeAttribute('src');
				}
			}

			if (homepagePreviewUrl) {
				homepagePreviewUrl.textContent = hasPage ? page.url.replace(/^https?:\/\//, '').replace(/\/$/, '') : '';
			}

			if (hasPage) {
				window.requestAnimationFrame(updatePreviewScale);
			}
		}

		function updatePreviewScale() {
			var desktopWidth = 1440;
			var desktopHeight = 900;
			var availableWidth;
			var scale;

			if (!homepagePreviewViewport || !homepagePreviewFrame || homepagePreview.hidden) {
				return;
			}

			availableWidth = homepagePreviewViewport.clientWidth;

			if (!availableWidth) {
				return;
			}

			scale = Math.min(1, availableWidth / desktopWidth);

			homepagePreviewFrame.style.transform = 'scale(' + scale + ')';
			homepagePreviewViewport.style.height = Math.round(desktopHeight * scale) + 'px';
		}

		function showNotice(message, type) {
			if (!homepageNotice) {
				return;
			}

			homepageNotice.hidden = false;
			homepageNotice.className = 'shoptimizer-homepage-notice is-' + type;
			homepageNotice.textContent = message;
		}

		function clearNotice() {
			if (!homepageNotice) {
				return;
			}

			homepageNotice.hidden = true;
			homepageNotice.textContent = '';
		}

		function save() {
			var endpoint = context.config.actions ? context.config.actions.saveHomepage : '';

			if (!endpoint || !homepagePageId) {
				showNotice(context.t('homepageChoose', 'Please choose a published page for your homepage.'), 'error');
				return Promise.reject(new Error(context.t('homepageChoose', 'Please choose a published page for your homepage.')));
			}

			clearNotice();

			if (context.els.nextButton) {
				context.els.nextButton.disabled = true;
				context.els.nextButton.textContent = context.t('savingHomepage', 'Saving homepage…');
			}

			return window.fetch(endpoint, {
				method: 'POST',
				credentials: 'same-origin',
				headers: {
					'Content-Type': 'application/json',
					'X-WP-Nonce': context.config.nonce
				},
				body: JSON.stringify({
					page_id: homepagePageId
				})
			})
				.then(function (response) {
					return response.json().then(function (data) {
						if (!response.ok) {
							throw new Error(data && data.message ? data.message : context.t('homepageSaveFailed', 'The homepage could not be saved.'));
						}

						return data;
					});
				})
				.then(function (data) {
					context.setStatus(data);
					isDirtyState = false;
					context.render();
					return data;
				})
				.catch(function (error) {
					showNotice(error.message, 'error');
					throw error;
				})
				.finally(function () {
					if (context.els.nextButton) {
						context.els.nextButton.disabled = false;
						context.updateNextButtonLabel();
					}
				});
		}

		if (homepageSelect) {
			homepageSelect.addEventListener('change', function () {
				homepagePageId = parseInt(homepageSelect.value, 10) || 0;
				isDirtyState = homepagePageId !== getSavedPageId();
				clearNotice();
				updatePreview();
				context.updateNextButtonLabel();
			});
		}

		window.addEventListener('resize', updatePreviewScale);

		return {
			clearNotice: clearNotice,
			discard: function () {
				isDirtyState = false;
				homepagePageId = getSavedPageId();
				render();
				clearNotice();
			},
			getPageId: function () {
				return homepagePageId;
			},
			isDirty: function () {
				return isDirtyState;
			},
			render: render,
			save: save,
			showNotice: showNotice,
			updatePreviewScale: updatePreviewScale
		};
	});
})(window);
