(function (window) {
	'use strict';

	window.ShoptimizerOnboardingApp.registerFeature('demo', function (context) {
		var demoOptions = Array.prototype.slice.call(context.app.querySelectorAll('[data-demo-option]'));
		var demoSelectionLabel = context.app.querySelector('[data-demo-selection-label]');
		var demoNotice = context.app.querySelector('[data-demo-notice]');
		var demoProgress = context.app.querySelector('[data-demo-progress]');
		var demoProgressStage = context.app.querySelector('[data-demo-progress-stage]');
		var demoImportedTag = context.app.querySelector('[data-demo-imported-tag]');
		var selectedDemo = '';

		function setOption(option) {
			var optionLabel = '';
			var clickedSelectedOption = selectedDemo === option.getAttribute('data-demo-option');

			selectedDemo = clickedSelectedOption ? '' : option.getAttribute('data-demo-option');

			demoOptions.forEach(function (demoOption) {
				var isSelected = !clickedSelectedOption && demoOption === option;

				demoOption.classList.toggle('is-selected', isSelected);
				demoOption.setAttribute('aria-pressed', isSelected ? 'true' : 'false');

				if (isSelected) {
					optionLabel = getOptionLabel(demoOption);
				}
			});

			if (demoSelectionLabel) {
				demoSelectionLabel.textContent = optionLabel || context.t('noDemoSelected', 'No demo selected');
			}

			if (selectedDemo === 'standard' && isImported()) {
				showNotice(context.t('demoAlreadyImported', 'Demo content has already been imported on this site. Importing again can create duplicate content.'), 'warning');
			} else {
				clearNotice();
			}

			context.updateNextButtonLabel();
		}

		function getOptionLabel(option) {
			var label = option.querySelector('strong');

			return label ? label.textContent : option.getAttribute('data-demo-option');
		}

		function isImported() {
			var status = context.getStatus();

			return !!(status.demo && status.demo.imported);
		}

		function showNotice(message, type) {
			if (!demoNotice) {
				return;
			}

			demoNotice.hidden = false;
			demoNotice.className = 'shoptimizer-demo-notice is-' + type;
			demoNotice.textContent = message;
		}

		function clearNotice() {
			if (!demoNotice) {
				return;
			}

			demoNotice.hidden = true;
			demoNotice.textContent = '';
		}

		function setStage(message) {
			if (demoProgressStage) {
				demoProgressStage.textContent = message;
			}
		}

		function setImportRunning(running) {
			context.state.demoImportRunning = running;
			context.app.classList.toggle('is-importing', running);

			if (demoProgress) {
				demoProgress.hidden = !running;
			}

			if (context.els.nextButton) {
				context.els.nextButton.disabled = running;
			}

			if (context.els.previousButton) {
				context.els.previousButton.disabled = running || context.state.activeStepIndex === 0;
			}

			context.updateSkipButton();

			demoOptions.forEach(function (option) {
				option.disabled = running;
			});

			context.els.stepButtons.forEach(function (button) {
				button.disabled = running;
			});

			context.els.viewButtons.forEach(function (button) {
				button.disabled = running;
			});
		}

		function render() {
			if (demoImportedTag) {
				demoImportedTag.hidden = !isImported();
			}
		}

		function runImport() {
			var config = context.config.demoImport || {};
			var status = context.getStatus();
			var demo = status.demo || {};

			if (!demo.available || !demo.can_import || !config.ajaxUrl || !config.nonce) {
				showNotice(context.t('demoUnavailable', 'Demo import is not available on this site.'), 'error');
				return;
			}

			if (!demo.plugins_ready) {
				showNotice(context.t('demoPluginsMissing', 'Demo import needs WooCommerce, CommerceKit, and Elementor active. Complete the Plugins step first.'), 'error');
				return;
			}

			if (isImported() && !window.confirm(context.t('demoReimportConfirm', 'Importing the demo again can create duplicate products, pages, menus, and media. Do you want to continue?'))) {
				return;
			}

			clearNotice();
			setImportRunning(true);
			setStage(context.t('demoStageDownload', 'Downloading import files…'));

			var stageTimer = window.setTimeout(function () {
				setStage(context.t('demoStageContent', 'Importing products, pages, and images — this can take a few minutes…'));
			}, 4000);

			function buildFormData(action) {
				var data = new FormData();

				data.append('action', action);
				data.append('security', config.nonce);
				data.append('import_type', 'default');

				return data;
			}

			function request(formData) {
				return window.fetch(config.ajaxUrl, {
					method: 'POST',
					credentials: 'same-origin',
					body: formData
				}).then(function (response) {
					return response.text().then(function (text) {
						var data;

						try {
							data = JSON.parse(text);
						} catch (error) {
							throw new Error(context.t('demoImportFailed', 'The demo import failed. Nothing else was changed — you can try again, or import later from Appearance → Import Demo Data.'));
						}

						if (!response.ok) {
							throw new Error(data && data.message ? data.message : context.t('demoImportFailed', 'The demo import failed. Nothing else was changed — you can try again, or import later from Appearance → Import Demo Data.'));
						}

						return data;
					});
				});
			}

			function handleResponse(response) {
				if (response && response.status === 'newAJAX') {
					return request(buildFormData('cgdi_import_demo_data')).then(handleResponse);
				}

				if (response && response.status === 'afterAllImportAJAX') {
					setStage(context.t('demoStageFinalize', 'Setting up menus, widgets, and your homepage…'));
					return request(buildFormData('cgdi_after_import_data')).then(handleResponse);
				}

				if (response && typeof response.message !== 'undefined') {
					return response;
				}

				throw new Error(typeof response === 'string' && response ? response : context.t('demoImportFailed', 'The demo import failed. Nothing else was changed — you can try again, or import later from Appearance → Import Demo Data.'));
			}

			request(buildFormData('cgdi_import_demo_data'))
				.then(handleResponse)
				.then(function (result) {
					window.clearTimeout(stageTimer);

					return context.refreshStatusAsync().then(function () {
						setImportRunning(false);

						if (result.outcome === 'warning') {
							showNotice(context.t('demoImportWarning', 'Demo content was imported, but some items may need attention. Review the demo import log for details.'), 'warning');
							return;
						}

						showNotice(context.t('demoImportComplete', 'Demo content imported successfully.'), 'success');

						if (context.state.activeStepIndex < context.els.steps.length - 1) {
							context.setStep(context.state.activeStepIndex + 1, { moveFocus: true });
						}
					});
				})
				.catch(function (error) {
					window.clearTimeout(stageTimer);
					setImportRunning(false);
					showNotice(error && error.message ? error.message : context.t('demoImportFailed', 'The demo import failed. Nothing else was changed — you can try again, or import later from Appearance → Import Demo Data.'), 'error');
				});
		}

		demoOptions.forEach(function (option) {
			option.addEventListener('click', function () {
				if (!option.disabled && !context.state.demoImportRunning) {
					setOption(option);
				}
			});
		});

		return {
			clearNotice: clearNotice,
			getSelected: function () {
				return selectedDemo;
			},
			isImported: isImported,
			render: render,
			runImport: runImport,
			showNotice: showNotice
		};
	});
})(window);
