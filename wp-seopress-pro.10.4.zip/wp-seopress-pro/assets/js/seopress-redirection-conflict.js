/* global wp, seopressRedirectionConflict */
(function () {
    'use strict';
    wp.domReady(function () {
        var settings = seopressRedirectionConflict;
        var noticeId = 'seopress-redirection-conflict';
        var lastUrl = null;
        var timer;
        var request;
        var revision = 0;

        function display(message) {
            if (settings.blockEditor) {
                var notices = wp.data.dispatch('core/notices');
                notices.removeNotice(noticeId);
                if (message) {
                    notices.createWarningNotice(message, {id: noticeId, isDismissible: true});
                }
                return;
            }
            var existing = document.getElementById(noticeId);
            if (existing) existing.remove();
            var anchor = document.getElementById('poststuff');
            if (message && anchor) {
                var notice = document.createElement('div');
                notice.id = noticeId;
                notice.className = 'notice notice-warning';
                notice.setAttribute('role', 'alert');
                var paragraph = document.createElement('p');
                paragraph.textContent = message;
                notice.appendChild(paragraph);
                anchor.parentNode.insertBefore(notice, anchor);
            }
        }

        function check(url) {
            if (url === lastUrl) return;
            lastUrl = url;
            var current = ++revision;
            clearTimeout(timer);
            if (request) request.abort();
            display('');
            if (!url) return;
            timer = setTimeout(function () {
                request = new AbortController();
                wp.apiFetch({path: '/seopress/v1/redirections/post-conflict?post_id=' + settings.postId + '&url=' + encodeURIComponent(url), signal: request.signal})
                    .then(function (result) {
                        if (current === revision) display(result.conflict ? settings.message : '');
                    })
                    .catch(function (error) {
                        if (current === revision && error.name !== 'AbortError') display(settings.errorMessage);
                    });
            }, 400);
        }

        if (settings.blockEditor) {
            function update() {
                var editor = wp.data.select('core/editor');
                check(editor && editor.getPermalink ? editor.getPermalink() : '');
            }
            wp.data.subscribe(update);
            update();
        } else {
            function updateClassic() {
                var target = document.getElementById('seopress-redirection-target');
                check(target ? target.getAttribute('data-url') : '');
            }
            var slugBox = document.getElementById('edit-slug-box');
            if (slugBox) new MutationObserver(updateClassic).observe(slugBox, {childList: true, subtree: true, attributes: true});
            updateClassic();
        }
    });
}());
