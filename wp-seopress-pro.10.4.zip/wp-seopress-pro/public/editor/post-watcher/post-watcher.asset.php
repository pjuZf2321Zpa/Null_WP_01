<?php return array('dependencies' => array('wp-data'), 'version' => '06104952c79f868eb699');
