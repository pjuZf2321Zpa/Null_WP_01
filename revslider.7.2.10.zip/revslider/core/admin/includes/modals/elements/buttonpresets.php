<?php
/**
 * @author    ThemePunch <info@themepunch.com>
 * @link      https://www.themepunch.com/
 * @copyright 2026 ThemePunch
 */

if(!defined('ABSPATH')) exit();
?>
<sr-separator id="layers_button_presets" keepborder>
	<sr-separator-head notoggle>
		<sr-separator-title><?php _e('Button Presets','revslider'); ?></sr-separator-title>
	</sr-separator-head>
	<sr-separator-body>
		<sr-wrap id="sr_btn_essentials" style="--sr-v2-columns:2"></sr-wrap>
		<sr-sp h="5"></sr-sp>
	</sr-separator-body>
</sr-separator>
