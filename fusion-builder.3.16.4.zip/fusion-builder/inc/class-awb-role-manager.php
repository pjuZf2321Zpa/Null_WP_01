<?php
/**
 * The AWB_Role_Manager class.
 *
 * @package fusion-builder
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The AWB_Role_Manager class.
 *
 * @since 3.9
 */
class AWB_Role_Manager {

	/**
	 * The one, true instance of this object.
	 *
	 * @static
	 * @access private
	 * @since 3.9
	 * @var object
	 */
	private static $instance;

	/**
	 * Avada post types.
	 *
	 * @access private
	 * @since 3.11.7
	 * @var array
	 */
	private $avada_post_types = [
		'awb_global_options',
		'awb_svg_upload',
		'awb_prebuilts',
		'awb_studio',
		'fusion_tb_layout',
		'fusion_tb_section',
		'awb_off_canvas',
		'fusion_icons',
		'fusion_form',
		'slide',
		'fusion_template',
		'fusion_element',
		'avada_library',
		'avada_portfolio',
		'avada_faq',
	];

	/**
	 * Non-Avada post types.
	 *
	 * @access private
	 * @since 3.11.7
	 * @var array
	 */
	private $non_avada_post_types = [
		'post',
		'page',
		'product',
	];

	/**
	 * Role manager default role capabilities data.
	 *
	 * @static
	 * @access private
	 * @since 3.11.10
	 * @var array
	 */
	private static $default_role_capabilities;

	/**
	 * Role manager default capabilities data.
	 *
	 * @static
	 * @access private
	 * @since 3.11.10
	 * @var array
	 */
	private static $default_role_manager_capabilities;

	/**
	 * Role manager capabilities data.
	 *
	 * @static
	 * @access private
	 * @since 3.9
	 * @var array
	 */
	private static $role_manager_capabilities;

	/**
	 * Role of the current user.
	 *
	 * @static
	 * @access private
	 * @since 3.11.7
	 * @var string
	 */
	private static $current_user_role;

	/**
	 * Sub-contexts the rest of the codebase asks for, mapped onto the key the
	 * capability is actually stored under.
	 *
	 * 'backed_builder_edit' is a typo that shipped in 3.11.7 and is baked into
	 * every saved role_manager_caps array, so it has to stay as the storage key.
	 * Call sites use the correct spelling and are translated here instead of
	 * silently missing the isset() and falling through to the un-downgraded
	 * capability, which is what half of them did.
	 *
	 * @static
	 * @access private
	 * @since 7.16
	 * @var array
	 */
	private static $sub_context_aliases = [
		'backend_builder_edit' => 'backed_builder_edit',
	];

	/**
	 * Constructor.
	 *
	 * @access public
	 */
	public function __construct() {
		$this->set_default_role_capabilities();
		$this->set_default_role_manager_capabilities();
		$this->set_role_manager_capabilities();

		add_action( 'awb_add_builder_options_section', [ $this, 'add_role_manager_options_to_builder_options' ] );
		add_filter( 'awb_role_manager_access_capability', [ $this, 'set_access_capability_based_on_role_manager' ], PHP_INT_MAX, 4 );

		add_action( 'load-post.php', [ $this, 'check_edit_screen_access' ] );
		add_action( 'load-post-new.php', [ $this, 'check_edit_screen_access' ] );
		add_action( 'load-edit.php', [ $this, 'check_list_screen_access' ] );

		// The screen checks alone leave the post list's bulk actions and Quick Edit open.
		add_filter( 'map_meta_cap', [ $this, 'restrict_post_caps' ], 10, 4 );
	}

	/**
	 * Creates or returns an instance of this class.
	 *
	 * @static
	 * @access public
	 * @since 3.9
	 * @return object
	 */
	public static function get_instance() {

		// If an instance hasn't been created and set to $instance create an instance and set it to $instance.
		if ( null === self::$instance ) {
			self::$instance = new AWB_Role_Manager();
		}
		return self::$instance;
	}

	/**
	 * Gets all affected post types.
	 *
	 * @since 3.11.7
	 * @access public
	 * @return array
	 */
	public function get_all_post_types() {
		return apply_filters( 'awb_role_manager_post_types', array_merge( $this->avada_post_types, $this->non_avada_post_types ) );
	}

	/**
	 * Gets non-Avada post types.
	 *
	 * @since 3.11.7
	 * @access public
	 * @return array
	 */
	public function get_non_avada_post_types() {
		return apply_filters( 'awb_role_manager_non_avada_post_types', $this->non_avada_post_types );
	}

	/**
	 * Set capabilities for a default role.
	 *
	 * @since 3.11.10
	 * @access private
	 * @return array
	 */
	private function set_default_role_capabilities() {
		if ( null === self::$default_role_capabilities ) {
			self::$default_role_capabilities = [
				'awb_global_options' => $this->get_capability_choices( [ 'off' ] ),
				'awb_prebuilts'      => $this->get_capability_choices( [ 'off' ] ),
				'awb_studio'         => $this->get_capability_choices( [ 'off' ] ),
				'fusion_tb_layout'   => $this->get_capability_choices( [ 'off' ] ),
				'fusion_tb_section'  => $this->get_capability_choices( [ 'off', 'off', 'off', 'off' ] ),
				'awb_off_canvas'     => $this->get_capability_choices( [ 'on', 'on', 'on', 'on' ] ),
				'fusion_icons'       => $this->get_capability_choices( [ 'on' ] ),
				'awb_svg_upload'     => $this->get_capability_choices( [ 'off' ] ),
				'fusion_form'        => $this->get_capability_choices(
					[
						'dashboard_access'    => 'on',
						'backed_builder_edit' => 'on',
						'live_builder_edit'   => 'on',
						'page_options'        => 'on',
						'submissions_access'  => 'off',
						'submissions_manage'  => 'off',
					]
				),
				'slide'              => $this->get_capability_choices(
					[
						'dashboard_access' => 'on',
						'page_options'     => 'on',
					]
				),
				'avada_library'      => $this->get_capability_choices(
					[
						'dashboard_access'    => 'on',
						'backed_builder_edit' => 'on',
						'live_builder_edit'   => 'on',
						'page_options'        => 'on',
						'global_elements'     => 'off',
					]
				),
				'avada_portfolio'    => $this->get_capability_choices( [ 'on', 'on', 'on', 'on' ] ),
				'avada_faq'          => $this->get_capability_choices( [ 'on', 'on', 'on', 'on' ] ),
				'post'               => $this->get_capability_choices( [ 'on', 'on', 'on', 'on' ] ),
				'page'               => $this->get_capability_choices( [ 'on', 'on', 'on', 'on' ] ),
				'product'            => $this->get_capability_choices( [ 'on', 'on', 'on', 'on' ] ),
			];
		}
	}

	/**
	 * Get capability choices.
	 *
	 * @since 3.11.7
	 * @access private
	 * @param array $selection The selection "mask" of choices.
	 * @return array
	 */
	private function get_capability_choices( $selection ) {
		$available_choices = [ 'dashboard_access', 'backed_builder_edit', 'live_builder_edit', 'page_options', 'submissions_access', 'submissions_manage', 'global_elements' ];
		$selected_choices  = [];

		foreach ( $selection as $index => $value ) {
			if ( '' === $value ) {
				continue;
			}

			// A row that just switches on a leading run of capabilities can stay
			// positional. A row with gaps or type-specific extras names its keys
			// instead, so adding a capability to the list above cannot silently
			// shift what it means.
			$capability = is_int( $index ) ? ( isset( $available_choices[ $index ] ) ? $available_choices[ $index ] : '' ) : $index;

			if ( '' !== $capability ) {
				$selected_choices[ $capability ] = $value;
			}
		}

		return $selected_choices;
	}

	/**
	 * Get capabilities for a default role.
	 *
	 * @since 3.11.10
	 * @access public
	 * @return array
	 */
	public function get_default_role_capabilities() {
		return self::$default_role_capabilities;
	}

	/**
	 * Get default role manager capabilities.
	 *
	 * @since 3.11.7
	 * @access private
	 * @return array
	 */
	public function set_default_role_manager_capabilities() {
		if ( null === self::$default_role_manager_capabilities ) {
			self::$default_role_manager_capabilities = [
				'editor'      => $this->get_editor_default_role_capabilities(),
				'author'      => $this->get_default_role_capabilities(),
				'contributor' => $this->get_contributor_default_role_capabilities(),
				'subscriber'  => $this->get_subscriber_default_role_capabilities(),
				'default'     => $this->get_default_role_capabilities(),
			];
		}
	}

	/**
	 * Get default capabilities for the Editor role.
	 *
	 * @since 3.11.10
	 * @access private
	 * @return array
	 */
	private function get_editor_default_role_capabilities() {
		$default_role_capabilities = $this->get_default_role_capabilities();

		$editor                      = $default_role_capabilities;
		$editor['fusion_tb_layout']  = $this->get_capability_choices( [ 'on' ] );
		$editor['fusion_tb_section'] = $this->get_capability_choices( [ 'on', 'on', 'on', 'on' ] );

		// An SVG can carry script. A single-site editor may post unfiltered HTML anyway, so
		// SVG uploads add nothing to what they can do. On multisite they may not, so off there.
		$editor['awb_svg_upload'] = $this->get_capability_choices( [ is_multisite() ? 'off' : 'on' ] );
		$editor['fusion_form']       = $this->get_capability_choices(
			[
				'dashboard_access'    => 'on',
				'backed_builder_edit' => 'on',
				'live_builder_edit'   => 'on',
				'page_options'        => 'on',
				'submissions_access'  => 'on',
				// Deleting entries is withheld by default even from editors.
				'submissions_manage'  => 'off',
			]
		);
		$editor['avada_library']     = $this->get_capability_choices(
			[
				'dashboard_access'    => 'on',
				'backed_builder_edit' => 'on',
				'live_builder_edit'   => 'on',
				'page_options'        => 'on',
				'global_elements'     => 'on',
			]
		);

		return $editor;
	}

	/**
	 * Get default capabilities for the Contributor role.
	 *
	 * A contributor writes content and nothing else, so out of the box they get
	 * the editorial post types - posts, pages, products, portfolio and FAQs -
	 * and none of the types that shape the site itself. This matters more than
	 * it looks: switching a row "on" does not mean "apply the capability this
	 * post type would normally require", it downgrades the check to 'exist',
	 * which every logged-in user passes. Leaving these on by default therefore
	 * handed a contributor access the post types' own capability mapping would
	 * have refused. Any of it can still be granted per site in the Role Manager.
	 *
	 * @since 7.16
	 * @access private
	 * @return array
	 */
	private function get_contributor_default_role_capabilities() {
		$contributor = $this->get_default_role_capabilities();

		$site_level_post_types = [
			'awb_off_canvas',
			'fusion_icons',
			'fusion_form',
			'slide',
			'avada_library',
		];

		foreach ( $site_level_post_types as $post_type ) {
			if ( isset( $contributor[ $post_type ] ) ) {
				$contributor[ $post_type ] = array_fill_keys( array_keys( $contributor[ $post_type ] ), 'off' );
			}
		}

		return $contributor;
	}

	/**
	 * Get default capabilities for the Subscriber role.
	 *
	 * @since 3.11.10
	 * @access private
	 * @return array
	 */
	private function get_subscriber_default_role_capabilities() {
		$subscriber = $this->get_default_role_capabilities();

		foreach ( $subscriber as $post_type => $caps ) {
			$subscriber[ $post_type ] = array_fill_keys( array_keys( $caps ), 'off' );
		}

		return $subscriber;
	}

	public function get_default_role_manager_capabilities() {
		return self::$default_role_manager_capabilities;
	}

	/**
	 * Sets the role manager capabilities from fusion settings.
	 *
	 * @since 3.9
	 * @access private
	 * @return void
	 */
	private function set_role_manager_capabilities() {
		if ( null === self::$role_manager_capabilities ) {
			$fusion_builder_settings = get_option( 'fusion_builder_settings', [] );
			$default_capabilities    = $this->get_default_role_manager_capabilities();

			if ( isset( $fusion_builder_settings['role_manager_caps'] ) ) {
				self::$role_manager_capabilities            = $fusion_builder_settings['role_manager_caps'];
				self::$role_manager_capabilities['default'] = $default_capabilities['default'];

				// Settings saved before an area existed have no row for it. The built-in roles get
				// its defaults, so the screen and the actual access agree until the next save.
				foreach ( [ 'awb_svg_upload' ] as $area ) {
					foreach ( $default_capabilities as $role => $role_defaults ) {
						if ( 'default' !== $role && isset( $role_defaults[ $area ] ) && ! isset( self::$role_manager_capabilities[ $role ][ $area ] ) ) {
							self::$role_manager_capabilities[ $role ][ $area ] = $role_defaults[ $area ];
						}
					}
				}
			} else {
				self::$role_manager_capabilities = $default_capabilities;
			}
		}
	}

	/**
	 * Get role manager capabilities.
	 *
	 * @since 3.11.7
	 * @access public
	 * @return array The capabilities.
	 */
	public function get_role_manager_capabilities() {
		return self::$role_manager_capabilities;
	}

	/**
	 * Get role of current user.
	 *
	 * @since 3.11.7
	 * @access public
	 * @return array The capabilities.
	 */
	public function get_current_user_role() {
		if ( ! self::$current_user_role ) {
			self::$current_user_role = is_user_logged_in() ? $this->get_user_role( wp_get_current_user() ) : 'default';
		}

		return self::$current_user_role;
	}

	/**
	 * Get the role the role manager applies to a user: administrator, or else the user's role with the most capabilities.
	 *
	 * @since 3.16.3
	 * @access public
	 * @param WP_User $user The user.
	 * @return string The role.
	 */
	public function get_user_role( $user ) {
		if ( user_can( $user, 'administrator' ) ) {
			return 'administrator';
		}

		$role               = 'subscriber';
		$capabilities_count = 0;

		foreach ( (array) $user->roles as $user_role ) {
			$role_data = get_role( $user_role );

			if ( isset( $role_data->capabilities ) && $capabilities_count < count( $role_data->capabilities ) ) {
				$capabilities_count = count( $role_data->capabilities );
				$role               = $user_role;
			}
		}

		return $role;
	}

	/**
	 * Whether a role has a role manager area switched on. Areas the role has no setting for are not restricted.
	 *
	 * @since 3.16.3
	 * @access private
	 * @param string $role        The role.
	 * @param string $context     The area, a post type or 'avada_library'.
	 * @param string $sub_context The sub-area.
	 * @return bool
	 */
	private function role_has_area( $role, $context, $sub_context = 'dashboard_access' ) {
		if ( 'administrator' === $role || ! isset( self::$role_manager_capabilities[ $role ][ $context ][ $sub_context ] ) ) {
			return true;
		}

		return 'on' === self::$role_manager_capabilities[ $role ][ $context ][ $sub_context ];
	}

	/**
	 * Resolves a sub-context to the key its capability is stored under.
	 *
	 * @since 7.16
	 * @access private
	 * @param string $sub_context The requested sub-context.
	 * @return string The storage key.
	 */
	private function normalize_sub_context( $sub_context ) {
		return isset( self::$sub_context_aliases[ $sub_context ] ) ? self::$sub_context_aliases[ $sub_context ] : $sub_context;
	}

	/**
	 * Set the needed capability based on what is saved in the role manager.
	 *
	 * @since 3.11.7
	 * @access public
	 * @param string|bool $minimum_capability The minimum capability to access. Bool if for post type registration and a few other areas.
	 * @param string      $context The context for the access.
	 * @param string      $sub_context The sub-context for the access.
	 * @param int         $object_id The object ID for the access.
	 * @return string The adjusted minimum capability.
	 */
	public function set_access_capability_based_on_role_manager( $minimum_capability, $context, $sub_context = 'dashboard_access', $object_id = 0 ) {
		$user_role   = $this->get_current_user_role();
		$context     = is_null( $context ) ? $this->get_post_type() : $context;
		$sub_context = $this->normalize_sub_context( $sub_context );

		// Set the capability based on post types, if it is relevant for posts and pages in the source.
		if ( in_array( $minimum_capability, [ 'edit_', 'publish_', 'edit_post', 'publish_post', 'read_post', 'delete_post', 'edit_avada_library', 'edit_private_posts' ], true ) ) {
			$post_type_object = get_post_type_object( $context );

			if ( 'edit_' === $minimum_capability || 'publish_' === $minimum_capability ) {
				$minimum_capability .= ( $object_id ) ? 'post' : 'posts';
			}

			if ( $post_type_object ) {
				if ( isset( $post_type_object->cap->$minimum_capability ) ) {
					$minimum_capability = $post_type_object->cap->$minimum_capability;
				}
			}
		}

		if ( 'administrator' === $user_role ) {
			return $minimum_capability;
		}

		// Never relax a capability check for a logged-out visitor. The 'default'
		// pseudo-role only exists so there is something to fall back to, but it is
		// not admin-configurable and its stored defaults mark the builder contexts
		// as "on". Downgrading to 'exist' on the strength of that would make the
		// check pass anonymously, because WP core grants 'exist' to every user -
		// user ID 0 included. See WP_User::has_cap().
		if ( ! is_user_logged_in() ) {
			return is_bool( $minimum_capability ) ? false : $minimum_capability;
		}

		if ( isset( self::$role_manager_capabilities[ $user_role ][ $context ][ $sub_context ] ) ) {
			if ( 'on' === self::$role_manager_capabilities[ $user_role ][ $context ][ $sub_context ] ) {
				// If it's on, we should return the original capability if an object id is provided,
				// This allows for meta capability check.
				if ( $object_id ) {
					return $minimum_capability;
				}
				$minimum_capability = is_bool( $minimum_capability ) ? true : 'exist';
			} else {
				$minimum_capability = is_bool( $minimum_capability ) ? false : 'administrator';
			}
		}

		return $minimum_capability;
	}

	/**
	 * Prepares and gets the post types for the options page.
	 *
	 * @since 3.7.11
	 * @access public
	 * @return array
	 */
	public function get_post_types_for_options_page() {
		$post_type_names = $this->get_all_post_types();

		// Remove templates and elements. So that library option can be used for both.
		$post_type_names = array_diff( $post_type_names, [ 'fusion_template', 'fusion_element' ] );
		$post_types      = [];

		foreach ( $post_type_names as $post_type_name ) {

			$special_post_types = [
				'awb_global_options' => __( 'Avada Global Options', 'fusion-builder' ),
				'awb_prebuilts'      => __( 'Avada Prebuilts', 'fusion-builder' ),
				'awb_studio'         => __( 'Avada Studio', 'fusion-builder' ),
				'awb_svg_upload'     => __( 'SVG Uploads', 'fusion-builder' ),
				'avada_library'      => __( 'Avada Library', 'fusion-builder' ),
			];

			if ( isset( $special_post_types[ $post_type_name ] ) ) {
				$post_type        = new stdClass();
				$post_type->label = $special_post_types[ $post_type_name ];
				$post_type->name  = $post_type_name;
			} else {
				$post_type = get_post_type_object( $post_type_name );
			}

			if ( ! is_object( $post_type ) || ! isset( $post_type->label ) || ! isset( $post_type->name ) ) {
				continue;
			}

			$post_types[ $post_type_name ] = $post_type;
		}

		return $post_types;
	}

	/**
	 * Gets the post type label including any needed prefixes.
	 *
	 * @since 3.7.11
	 * @param array $post_type The post type object.
	 * @access public
	 * @return string
	 */
	public function get_post_type_label( $post_type ) {
		$label = isset( $post_type->label ) ? $post_type->label : '';

		if ( in_array( $post_type->name, $this->get_non_avada_post_types(), true ) || 'awb_svg_upload' === $post_type->name ) {
			$label = $post_type->label;
		} elseif ( false === strpos( $post_type->label, 'Avada' ) ) {
			$label = __( 'Avada', 'fusion-builder' ) . ' ' . str_replace( 'Custom ', '', $post_type->label );
		}

		return apply_filters( 'awb_role_manager_post_type_label', $label );
	}

	/**
	 * Gets the capability value for the options page.
	 *
	 * @since 3.11.7
	 * @access public
	 * @param string $role The user role.
	 * @param string $context The context for the access.
	 * @param string $sub_context The sub-context for the access.
	 * @return string The capability or empty string if not set.
	 */
	public function get_option_page_value( $role, $context, $sub_context = 'dashboard_access' ) {
		$sub_context = $this->normalize_sub_context( $sub_context );

		if ( isset( self::$role_manager_capabilities[ $role ][ $context ][ $sub_context ] ) ) {
			return self::$role_manager_capabilities[ $role ][ $context ][ $sub_context ];
		}

		return '';
	}

	/**
	 * Adds the role manager options to the builder options page
	 *
	 * @since 3.11.7
	 * @access public
	 * @return void
	 */
	public function add_role_manager_options_to_builder_options() {
		$post_types = $this->get_post_types_for_options_page();
		$roles      = get_editable_roles();

		// Remove admin role.
		unset( $roles['administrator'] );

		include FUSION_BUILDER_PLUGIN_DIR . 'inc/admin-screens/role-manager-options.php';
	}

	/**
	 * Gets current post type.
	 *
	 * @since 3.11.7
	 * @access private
	 * @return string
	 */
	private function get_post_type() {
		if ( is_admin() ) {
			$post_type = $this->get_post_type_admin();
		} elseif ( isset( $_SERVER['REQUEST_URI'] ) && ( false !== strpos( $_SERVER['REQUEST_URI'], 'fb-edit' ) || false !== strpos( $_SERVER['REQUEST_URI'], 'builder=true' ) ) ) { // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
			$post_type = $this->get_post_type_live_editor();
		} elseif ( isset( $_SERVER['REQUEST_URI'] ) && false === strpos( $_SERVER['REQUEST_URI'], 'fb-edit' ) && false === strpos( $_SERVER['REQUEST_URI'], 'builder=true' ) ) { // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
			$post_type = get_post_type();
		}

		$post_type = in_array( $post_type, [ 'fusion_template', 'fusion_element' ], true ) ? 'avada_library' : $post_type;

		return apply_filters( 'awb_role_manager_current_screen_post_type', $post_type );
	}

	/**
	 * Gets post type of WP admin screens.
	 *
	 * @since 3.11.7
	 * @access private
	 * @return string
	 */
	private function get_post_type_admin() {
		global $post, $pagenow, $typenow, $current_screen;

		$post_type = '';

		if ( isset( $post->post_type ) ) {
			$post_type = $post->post_type;
		} elseif ( $typenow ) {
			$post_type = $typenow;
		} elseif ( isset( $current_screen->post_type ) ) {
			$post_type = $current_screen->post_type;
		} elseif ( isset( $_REQUEST['post_type'] ) ) {
			$post_type = sanitize_text_field( wp_unslash( $_REQUEST['post_type'] ) );
		} elseif ( 'edit.php' === $pagenow && '' === $typenow ) {
			$post_type = 'post';
		} else {
			$post_type = $this->get_post_type_avada_admin_screen();
		}

		return $post_type;
	}

	/**
	 * Gets post type of Avada admin screens.
	 *
	 * @since 3.11.7
	 * @access private
	 * @return string
	 */
	private function get_post_type_avada_admin_screen() {
		$post_type = '';

		$page    = isset( $_GET['page'] ) ? sanitize_text_field( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		$screens = [
			'avada-layouts'         => 'fusion_tb_layout',
			'avada-layout-sections' => 'fusion_tb_section',
			'avada-off-canvas'      => 'awb_off_canvas',
			'avada-icons'           => 'fusion_icons',
			'avada-forms'           => 'fusion_form',
			'avada-form-entries'    => 'fusion_form',
			'avada-library'         => 'avada_library',
			'avada-studio'          => 'awb_studio',
		];

		$post_type = isset( $screens[ $page ] ) ? $screens[ $page ] : $post_type;

		return $post_type;
	}

	/**
	 * Gets current page post type in live editor.
	 *
	 * @since 3.9
	 * @access private
	 * @return string
	 */
	private function get_post_type_live_editor() {
		global $wp_rewrite;

		$fusion_settings = class_exists( 'Fusion_Settings' ) ? awb_get_fusion_settings() : false;
		$url             = $this->get_current_url();
		$post_type       = '';
		$portfolio_slug  = $fusion_settings && '' !== $fusion_settings->get( 'portfolio_slug' ) ? $fusion_settings->get( 'portfolio_slug' ) : 'portfolio-items';
		$faqs_slug       = $fusion_settings && '' !== $fusion_settings->get( 'faq_slug' ) ? $fusion_settings->get( 'faq_slug' ) : 'faq-items';
		$post_types      = [
			'awb_off_canvas'    => 'awb_off_canvas',
			'fusion_tb_section' => 'fusion_tb_section',
			'fusion_form'       => 'fusion_form',
			'fusion_element'    => 'fusion_element',
			'fusion_template'   => 'fusion_template',
			'avada_portfolio'   => $portfolio_slug,
			'avada_faq'         => $faqs_slug,
		];

		foreach ( $post_types as $item ) {
			if ( false !== strpos( $url, $item ) ) {
				$post_type = $item;
				break;
			}
		}

		if ( empty( $post_type ) && ! is_null( $wp_rewrite ) ) {

			// Avoid text domain error.
			if ( class_exists( 'Tribe__Events__Rewrite' ) ) {
				remove_filter( 'url_to_postid', [ Tribe__Events__Rewrite::instance(), 'filter_url_to_postid' ] );
			}
			$post_type = get_post_type( url_to_postid( $url ) );

			// Avoid text domain error.
			if ( class_exists( 'Tribe__Events__Rewrite' ) ) {
				add_filter( 'url_to_postid', [ Tribe__Events__Rewrite::instance(), 'filter_url_to_postid' ] );
			}
		}

		if ( false === $post_type && get_home_url() === $url && 'page' === get_option( 'show_on_front' ) ) {
			$post_type = 'page';
		}

		return $post_type;
	}

	/**
	 * Gets current URL.
	 *
	 * @since 3.11.7
	 * @access private
	 * @return string
	 */
	private function get_current_url() {
		$url_parts = parse_url( home_url() );
		$full_url  = $url_parts['scheme'] . '://' . $url_parts['host'] . add_query_arg( null, null );

		return $full_url;
	}

	/**
	 * Checks if user should have access to global elements and the backend builder.
	 *
	 * @since 3.11.7
	 * @access public
	 * @return void
	 */
	public function check_edit_screen_access() {
		$post_id   = isset( $_GET['post'] ) ? sanitize_text_field( wp_unslash( $_GET['post'] ) ) : null; // phpcs:ignore WordPress.Security.NonceVerification
		$post_type = $this->get_post_type();

		// Global elements access.
		if ( isset( $post_id ) && 'yes' === get_post_meta( $post_id, '_fusion_is_global', true ) && ! current_user_can( apply_filters( 'awb_role_manager_access_capability', 'edit_private_posts', 'avada_library', 'global_elements' ) ) ) {
			wp_die( __( 'Sorry, you are not allowed to access this page.' ), 403 ); // phpcs:ignore WordPress.Security.EscapeOutput
		}

		// Content type access. The capabilities nested under it - Back-end Builder,
		// Live Builder and Page Options - each withhold their own UI where it would
		// be rendered, so switching one off narrows what the role can do on the edit
		// screen instead of locking them out of the post entirely, which is what
		// turning off the Back-end Builder used to do.
		if ( ! current_user_can( apply_filters( 'awb_role_manager_access_capability', 'edit_', $post_type, 'dashboard_access' ) ) ) {
			wp_die( __( 'Sorry, you are not allowed to access this page.' ), 403 ); // phpcs:ignore WordPress.Security.EscapeOutput
		}
	}

	/**
	 * Blocks the native post list of an Avada content type for roles that have it switched off,
	 * so its bulk actions and Quick Edit are as closed as the edit screen.
	 *
	 * @since 3.16.3
	 * @access public
	 * @return void
	 */
	public function check_list_screen_access() {
		global $typenow;

		$context = in_array( $typenow, [ 'fusion_template', 'fusion_element' ], true ) ? 'avada_library' : $typenow;

		if ( in_array( $context, $this->avada_post_types, true ) && ! $this->role_has_area( $this->get_current_user_role(), $context ) ) {
			wp_die( __( 'Sorry, you are not allowed to access this page.' ), 403 ); // phpcs:ignore WordPress.Security.EscapeOutput
		}
	}

	/**
	 * Denies editing, deleting and publishing an Avada content type's posts to roles that have the type
	 * switched off, and global elements to roles without the global elements area. Without this the
	 * role manager only closes the edit screens, while the post caps it leaves untouched still allow
	 * trashing, deleting and Quick Edit from anywhere else.
	 *
	 * @since 3.16.3
	 * @access public
	 * @param string[] $caps    Primitive caps the meta cap maps to.
	 * @param string   $cap     The capability being checked.
	 * @param int      $user_id The user ID.
	 * @param array    $args    Extra arguments, the post ID first.
	 * @return string[]
	 */
	public function restrict_post_caps( $caps, $cap, $user_id, $args ) {
		if ( ! in_array( $cap, [ 'edit_post', 'delete_post', 'publish_post' ], true ) || empty( $args[0] ) ) {
			return $caps;
		}

		$post = get_post( $args[0] );
		$user = $post ? get_userdata( $user_id ) : false;
		if ( ! $user ) {
			return $caps;
		}

		$context = in_array( $post->post_type, [ 'fusion_template', 'fusion_element' ], true ) ? 'avada_library' : $post->post_type;
		if ( ! in_array( $context, $this->avada_post_types, true ) ) {
			return $caps;
		}

		$role = $this->get_user_role( $user );
		if ( ! $this->role_has_area( $role, $context ) ) {
			return [ 'do_not_allow' ];
		}

		if ( 'avada_library' === $context && 'yes' === get_post_meta( $post->ID, '_fusion_is_global', true ) && ! $this->role_has_area( $role, 'avada_library', 'global_elements' ) ) {
			return [ 'do_not_allow' ];
		}

		return $caps;
	}
}

/**
 * Instantiates the AWB_Role_Manager class.
 * Make sure the class is properly set-up.
 *
 * @since object 3.9
 * @return object AWB_Role_Manager
 */
function AWB_Role_Manager() { // phpcs:ignore WordPress.NamingConventions
	return AWB_Role_Manager::get_instance();
}
AWB_Role_Manager();
