<?php
/**
 * Avada Builder Aurora Helper class.
 *
 * @package Avada-Builder
 * @since 3.16.2
 */

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'Direct script access denied.' );
}

/**
 * Avada Builder Aurora Helper class.
 *
 * An animated gradient background layer of soft color blobs, rendered in CSS only.
 *
 * @since 3.16.2
 */
class AWB_Aurora_Helper {

	/**
	 * The number of color blobs.
	 *
	 * @since 3.16.2
	 * @var int
	 */
	const COLORS = 4;

	/**
	 * The aurora modes that render the layer, 'static' has no animation.
	 *
	 * @since 3.16.4
	 * @var array
	 */
	const MODES = [ 'static', 'drift', 'swirl', 'pulse' ];

	/**
	 * Get aurora params.
	 *
	 * @since 3.16.2
	 * @access public
	 * @param array $args The placeholder arguments.
	 * @return array
	 */
	public static function get_params( $args ) {
		$subgroup   = [
			'name' => 'background_type',
			'tab'  => 'aurora',
		];
		$dependency = [
			[
				'element'  => 'aurora',
				'value'    => 'none',
				'operator' => '!=',
			],
		];

		$speed_dependency   = $dependency;
		$speed_dependency[] = [
			'element'  => 'aurora',
			'value'    => 'static',
			'operator' => '!=',
		];

		$params = [
			[
				'type'        => 'radio_button_set',
				'heading'     => esc_attr__( 'Aurora', 'fusion-builder' ),
				'param_name'  => 'aurora',
				'description' => esc_attr__( 'Select the aurora, a gradient of soft color blobs behind the content, and how it moves. Static keeps the blobs still. Visitors who prefer reduced motion always see the colors standing still.', 'fusion-builder' ),
				'group'       => esc_attr__( 'Background', 'fusion-builder' ),
				'subgroup'    => $subgroup,
				'default'     => 'none',
				'value'       => [
					'none'   => esc_attr__( 'None', 'fusion-builder' ),
					'static' => esc_attr__( 'Static', 'fusion-builder' ),
					'drift'  => esc_attr__( 'Drift', 'fusion-builder' ),
					'swirl'  => esc_attr__( 'Swirl', 'fusion-builder' ),
					'pulse'  => esc_attr__( 'Pulse', 'fusion-builder' ),
				],
			],
		];

		for ( $i = 1; $i <= self::COLORS; $i++ ) {
			$params[] = [
				'type'        => 'colorpickeralpha',
				/* translators: The color number. */
				'heading'     => sprintf( esc_attr__( 'Aurora Color %s', 'fusion-builder' ), $i ),
				'param_name'  => 'aurora_color_' . $i,
				'description' => esc_attr__( 'Set the color of a blob. Leave empty for fewer blobs, which calms the effect.', 'fusion-builder' ),
				'group'       => esc_attr__( 'Background', 'fusion-builder' ),
				'subgroup'    => $subgroup,
				'default'     => self::get_default_color( $i ),
				'dependency'  => $dependency,
			];
		}

		$params[] = [
			'type'        => 'range',
			'heading'     => esc_attr__( 'Aurora Speed', 'fusion-builder' ),
			'param_name'  => 'aurora_speed',
			'description' => esc_attr__( 'Set the duration of one movement cycle of the blobs, in seconds. Higher values are slower.', 'fusion-builder' ),
			'min'         => 6,
			'max'         => 60,
			'value'       => 18,
			'step'        => 1,
			'group'       => esc_attr__( 'Background', 'fusion-builder' ),
			'subgroup'    => $subgroup,
			'dependency'  => $speed_dependency,
		];
		$params[] = [
			'type'        => 'range',
			'heading'     => esc_attr__( 'Aurora Size', 'fusion-builder' ),
			'param_name'  => 'aurora_size',
			'description' => esc_attr__( 'Set the size of the blobs, in percent of the container width.', 'fusion-builder' ),
			'min'         => 30,
			'max'         => 100,
			'value'       => 55,
			'step'        => 1,
			'group'       => esc_attr__( 'Background', 'fusion-builder' ),
			'subgroup'    => $subgroup,
			'dependency'  => $dependency,
		];
		$params[] = [
			'type'        => 'range',
			'heading'     => esc_attr__( 'Aurora Blur', 'fusion-builder' ),
			'param_name'  => 'aurora_blur',
			'description' => esc_attr__( 'Set how soft the edges of the blobs are, in pixels.', 'fusion-builder' ),
			'min'         => 0,
			'max'         => 150,
			'value'       => 60,
			'step'        => 1,
			'group'       => esc_attr__( 'Background', 'fusion-builder' ),
			'subgroup'    => $subgroup,
			'dependency'  => $dependency,
		];
		$params[] = [
			'type'        => 'range',
			'heading'     => esc_attr__( 'Aurora Opacity', 'fusion-builder' ),
			'param_name'  => 'aurora_opacity',
			'description' => esc_attr__( 'Set the aurora opacity.', 'fusion-builder' ),
			'min'         => 0,
			'max'         => 100,
			'value'       => 85,
			'step'        => 1,
			'group'       => esc_attr__( 'Background', 'fusion-builder' ),
			'subgroup'    => $subgroup,
			'dependency'  => $dependency,
		];
		$params[] = [
			'type'        => 'select',
			'heading'     => esc_attr__( 'Aurora Blend Mode', 'fusion-builder' ),
			'param_name'  => 'aurora_blend_mode',
			'description' => esc_attr__( 'Set how the aurora will blend with the element background, e.g. to tint a background image.', 'fusion-builder' ),
			'group'       => esc_attr__( 'Background', 'fusion-builder' ),
			'value'       => [
				'normal'       => esc_attr__( 'Normal', 'fusion-builder' ),
				'multiply'     => esc_attr__( 'Multiply', 'fusion-builder' ),
				'screen'       => esc_attr__( 'Screen', 'fusion-builder' ),
				'overlay'      => esc_attr__( 'Overlay', 'fusion-builder' ),
				'darken'       => esc_attr__( 'Darken', 'fusion-builder' ),
				'lighten'      => esc_attr__( 'Lighten', 'fusion-builder' ),
				'color-dodge'  => esc_attr__( 'Color Dodge', 'fusion-builder' ),
				'color-burn'   => esc_attr__( 'Color Burn', 'fusion-builder' ),
				'hard-light'   => esc_attr__( 'Hard Light', 'fusion-builder' ),
				'soft-light'   => esc_attr__( 'Soft Light', 'fusion-builder' ),
				'difference'   => esc_attr__( 'Difference', 'fusion-builder' ),
				'exclusion'    => esc_attr__( 'Exclusion', 'fusion-builder' ),
				'hue'          => esc_attr__( 'Hue', 'fusion-builder' ),
				'saturation'   => esc_attr__( 'Saturation', 'fusion-builder' ),
				'color'        => esc_attr__( 'Color', 'fusion-builder' ),
				'luminosity'   => esc_attr__( 'Luminosity', 'fusion-builder' ),
				'plus-lighter' => esc_attr__( 'Plus Lighter', 'fusion-builder' ),
			],
			'default'     => 'normal',
			'subgroup'    => $subgroup,
			'dependency'  => $dependency,
		];

		return $params;
	}

	/**
	 * The default color of a blob. Two palette colors, the other blobs are opt-in.
	 *
	 * @since 3.16.2
	 * @access public
	 * @param int $index The color number, starting at 1.
	 * @return string
	 */
	public static function get_default_color( $index ) {
		$defaults = [
			1 => 'var(--awb-color4)',
			2 => 'var(--awb-color5)',
		];

		return isset( $defaults[ $index ] ) ? $defaults[ $index ] : '';
	}

	/**
	 * The element defaults of the aurora params.
	 *
	 * @since 3.16.2
	 * @access public
	 * @return array
	 */
	public static function get_defaults() {
		$defaults = [ 'aurora' => 'none' ];

		for ( $i = 1; $i <= self::COLORS; $i++ ) {
			$defaults[ 'aurora_color_' . $i ] = self::get_default_color( $i );
		}

		return array_merge(
			$defaults,
			[
				'aurora_speed'      => '18',
				'aurora_size'       => '55',
				'aurora_blur'       => '60',
				'aurora_opacity'    => '85',
				'aurora_blend_mode' => 'normal',
			]
		);
	}

	/**
	 * Whether the aurora is enabled.
	 *
	 * @since 3.16.2
	 * @access public
	 * @param array $atts The element attributes.
	 * @return bool
	 */
	public static function is_enabled( $atts ) {
		return isset( $atts['aurora'] ) && in_array( $atts['aurora'], self::MODES, true );
	}

	/**
	 * The colors that are set, in order.
	 *
	 * The single place that reads the color params, so a later switch to a
	 * color stop list only needs to change this method, incl. the fallback
	 * to the numbered params. Mirrored by _.fusionGetAuroraColors().
	 *
	 * @since 3.16.2
	 * @access public
	 * @param array $atts The element attributes.
	 * @return array
	 */
	public static function get_colors( $atts ) {
		$colors = [];

		for ( $i = 1; $i <= self::COLORS; $i++ ) {
			if ( ! empty( $atts[ 'aurora_color_' . $i ] ) ) {
				$colors[] = $atts[ 'aurora_color_' . $i ];
			}
		}

		return $colors;
	}

	/**
	 * Get the aurora element.
	 *
	 * @since 3.16.2
	 * @access public
	 * @param array $atts The element attributes.
	 * @return string
	 */
	public static function get_element( $atts ) {
		if ( ! self::is_enabled( $atts ) ) {
			return '';
		}

		$colors = self::get_colors( $atts );

		if ( empty( $colors ) ) {
			return '';
		}

		$blobs = '';
		foreach ( $colors as $color ) {
			$blobs .= '<span style="--awb-aurora-color:' . esc_attr( $color ) . ';"></span>';
		}

		$style = '';
		if ( '' !== $atts['aurora_speed'] && 'static' !== $atts['aurora'] ) {
			$style .= '--awb-aurora-speed:' . (float) $atts['aurora_speed'] . 's;';
		}
		if ( '' !== $atts['aurora_size'] ) {
			$style .= '--awb-aurora-size:' . (float) $atts['aurora_size'] . '%;';
		}
		if ( '' !== $atts['aurora_blur'] ) {
			$style .= '--awb-aurora-blur:' . (float) $atts['aurora_blur'] . 'px;';
		}
		if ( '' !== $atts['aurora_opacity'] ) {
			$style .= 'opacity:' . ( (float) $atts['aurora_opacity'] / 100 ) . ';';
		}
		if ( '' !== $atts['aurora_blend_mode'] && 'normal' !== $atts['aurora_blend_mode'] ) {
			$style .= 'mix-blend-mode:' . esc_attr( $atts['aurora_blend_mode'] ) . ';';
		}

		return '<div class="awb-background-aurora awb-background-aurora--' . esc_attr( $atts['aurora'] ) . '" style="' . esc_attr( $style ) . '" aria-hidden="true">' . $blobs . '</div>';
	}
}
