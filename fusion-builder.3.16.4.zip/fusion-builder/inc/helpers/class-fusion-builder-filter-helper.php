<?php
/**
 * Avada Builder Filter Helper class.
 *
 * @package Avada-Builder
 * @since 2.2
 */

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'Direct script access denied.' );
}

/**
 * Avada Builder Filter Helper class.
 *
 * @since 2.2
 */
class Fusion_Builder_Filter_Helper {

	/**
	 * Class constructor.
	 *
	 * @since 2.2
	 * @access public
	 */
	public function __construct() {
	}

	/**
	 * Get filter params.
	 *
	 * @since 2.2
	 * @access public
	 * @param array $args The placeholder arguments.
	 * @return array
	 */
	public static function get_params( $args ) {

		$selector_base = isset( $args['selector_base'] ) ? $args['selector_base'] : '';

		$states         = [ 'regular', 'hover' ];
		$filter_options = [
			[
				'type'             => 'subgroup',
				'heading'          => esc_attr__( 'Filter Type', 'fusion-builder' ),
				'description'      => esc_attr__( 'Use filters to see specific type of content.', 'fusion-builder' ),
				'param_name'       => 'filter_type',
				'default'          => 'regular',
				'group'            => esc_attr__( 'Extras', 'fusion-builder' ),
				'remove_from_atts' => true,
				'value'            => [
					'regular' => esc_attr__( 'Regular', 'fusion-builder' ),
					'hover'   => esc_attr__( 'Hover', 'fusion-builder' ),
				],
				'icons'            => [
					'regular' => '<span class="fusiona-regular-state" style="font-size:18px;"></span>',
					'hover'   => '<span class="fusiona-hover-state" style="font-size:18px;"></span>',
				],
			],
		];

		if ( isset( $args['parent_hover'] ) && $args['parent_hover'] ) {
			$filter_options[] = [
				'type'        => 'select',
				'heading'     => esc_attr__( 'Hover Element', 'fusion-builder' ),
				'description' => esc_attr__( 'Select which element should be hovered to apply the filter hover options.', 'fusion-builder' ),
				'param_name'  => 'filter_hover_element',
				'group'       => esc_attr__( 'Extras', 'fusion-builder' ),
				'default'     => 'self',
				'value'       => [
					'self'   => esc_attr__( 'Self', 'fusion-builder' ),
					'parent' => esc_attr__( 'Parent', 'fusion-builder' ),
				],
				'subgroup'    => [
					'name' => 'filter_type',
					'tab'  => 'hover',
				],
				'callback'    => [
					'function' => 'fusion_update_filter_style',
					'args'     => [
						'selector_base' => $selector_base,
					],
				],
			];
		}

		foreach ( $states as $key ) {
			$filter_options = array_merge(
				$filter_options,
				[
					[
						'type'        => 'range',
						'heading'     => esc_attr__( 'Hue', 'fusion-builder' ),
						'description' => esc_attr__( 'Filter hue.', 'fusion-builder' ),
						'param_name'  => 'filter_hue' . ( 'regular' !== $key ? '_' . $key : '' ),
						'value'       => '0',
						'min'         => '0',
						'max'         => '359',
						'group'       => esc_attr__( 'Extras', 'fusion-builder' ),
						'subgroup'    => [
							'name' => 'filter_type',
							'tab'  => $key,
						],
						'callback'    => [
							'function' => 'fusion_update_filter_style',
							'args'     => [
								'selector_base' => $selector_base,
							],
						],
					],
					[
						'type'        => 'range',
						'heading'     => esc_attr__( 'Saturation', 'fusion-builder' ),
						'description' => esc_attr__( 'Filter saturation.', 'fusion-builder' ),
						'param_name'  => 'filter_saturation' . ( 'regular' !== $key ? '_' . $key : '' ),
						'value'       => '100',
						'min'         => '0',
						'max'         => '200',
						'group'       => esc_attr__( 'Extras', 'fusion-builder' ),
						'subgroup'    => [
							'name' => 'filter_type',
							'tab'  => $key,
						],
						'callback'    => [
							'function' => 'fusion_update_filter_style',
							'args'     => [
								'selector_base' => $selector_base,
							],
						],
					],
					[
						'type'        => 'range',
						'heading'     => esc_attr__( 'Brightness', 'fusion-builder' ),
						'description' => esc_attr__( 'Filter brightness.', 'fusion-builder' ),
						'param_name'  => 'filter_brightness' . ( 'regular' !== $key ? '_' . $key : '' ),
						'value'       => '100',
						'min'         => '0',
						'max'         => '200',
						'group'       => esc_attr__( 'Extras', 'fusion-builder' ),
						'subgroup'    => [
							'name' => 'filter_type',
							'tab'  => $key,
						],
						'callback'    => [
							'function' => 'fusion_update_filter_style',
							'args'     => [
								'selector_base' => $selector_base,
							],
						],
					],
					[
						'type'        => 'range',
						'heading'     => esc_attr__( 'Contrast', 'fusion-builder' ),
						'description' => esc_attr__( 'Filter contrast.', 'fusion-builder' ),
						'param_name'  => 'filter_contrast' . ( 'regular' !== $key ? '_' . $key : '' ),
						'value'       => '100',
						'min'         => '0',
						'max'         => '200',
						'group'       => esc_attr__( 'Extras', 'fusion-builder' ),
						'subgroup'    => [
							'name' => 'filter_type',
							'tab'  => $key,
						],
						'callback'    => [
							'function' => 'fusion_update_filter_style',
							'args'     => [
								'selector_base' => $selector_base,
							],
						],
					],
					[
						'type'        => 'range',
						'heading'     => esc_attr__( 'Invert', 'fusion-builder' ),
						'description' => esc_attr__( 'Filter invert.', 'fusion-builder' ),
						'param_name'  => 'filter_invert' . ( 'regular' !== $key ? '_' . $key : '' ),
						'value'       => '0',
						'min'         => '0',
						'max'         => '100',
						'group'       => esc_attr__( 'Extras', 'fusion-builder' ),
						'subgroup'    => [
							'name' => 'filter_type',
							'tab'  => $key,
						],
						'callback'    => [
							'function' => 'fusion_update_filter_style',
							'args'     => [
								'selector_base' => $selector_base,
							],
						],
					],
					[
						'type'        => 'range',
						'heading'     => esc_attr__( 'Sepia', 'fusion-builder' ),
						'description' => esc_attr__( 'Filter sepia.', 'fusion-builder' ),
						'param_name'  => 'filter_sepia' . ( 'regular' !== $key ? '_' . $key : '' ),
						'value'       => '0',
						'min'         => '0',
						'max'         => '100',
						'group'       => esc_attr__( 'Extras', 'fusion-builder' ),
						'subgroup'    => [
							'name' => 'filter_type',
							'tab'  => $key,
						],
						'callback'    => [
							'function' => 'fusion_update_filter_style',
							'args'     => [
								'selector_base' => $selector_base,
							],
						],
					],
					[
						'type'        => 'range',
						'heading'     => esc_attr__( 'Opacity', 'fusion-builder' ),
						'description' => esc_attr__( 'Filter opacity.', 'fusion-builder' ),
						'param_name'  => 'filter_opacity' . ( 'regular' !== $key ? '_' . $key : '' ),
						'value'       => '100',
						'min'         => '0',
						'max'         => '100',
						'group'       => esc_attr__( 'Extras', 'fusion-builder' ),
						'subgroup'    => [
							'name' => 'filter_type',
							'tab'  => $key,
						],
						'callback'    => [
							'function' => 'fusion_update_filter_style',
							'args'     => [
								'selector_base' => $selector_base,
							],
						],
					],
					[
						'type'        => 'range',
						'heading'     => esc_attr__( 'Blur', 'fusion-builder' ),
						'description' => esc_attr__( 'Filter blur.', 'fusion-builder' ),
						'param_name'  => 'filter_blur' . ( 'regular' !== $key ? '_' . $key : '' ),
						'value'       => '0',
						'min'         => '0',
						'max'         => '50',
						'group'       => esc_attr__( 'Extras', 'fusion-builder' ),
						'subgroup'    => [
							'name' => 'filter_type',
							'tab'  => $key,
						],
						'callback'    => [
							'function' => 'fusion_update_filter_style',
							'args'     => [
								'selector_base' => $selector_base,
							],
						],
					],
				]
			);

		}

		// Backdrop filters are opt-in, they need a transparent or semi-transparent element background to be visible.
		if ( isset( $args['backdrop'] ) && $args['backdrop'] ) {
			$filter_options[] = [
				'type'             => 'subgroup',
				'heading'          => esc_attr__( 'Backdrop Filters', 'fusion-builder' ),
				'description'      => esc_attr__( 'Backdrop filters apply to the area behind the element. The element needs a transparent or semi-transparent background for them to be visible.', 'fusion-builder' ),
				'param_name'       => 'filter_backdrop_type',
				'default'          => 'regular',
				'group'            => esc_attr__( 'Extras', 'fusion-builder' ),
				'remove_from_atts' => true,
				'value'            => [
					'regular' => esc_attr__( 'Regular', 'fusion-builder' ),
					'hover'   => esc_attr__( 'Hover', 'fusion-builder' ),
				],
				'icons'            => [
					'regular' => '<span class="fusiona-regular-state" style="font-size:18px;"></span>',
					'hover'   => '<span class="fusiona-hover-state" style="font-size:18px;"></span>',
				],
			];

			if ( isset( $args['parent_hover'] ) && $args['parent_hover'] ) {
				$filter_options[] = [
					'type'        => 'select',
					'heading'     => esc_attr__( 'Hover Element', 'fusion-builder' ),
					'description' => esc_attr__( 'Select which element should be hovered to apply the backdrop filter hover options.', 'fusion-builder' ),
					'param_name'  => 'filter_backdrop_hover_element',
					'group'       => esc_attr__( 'Extras', 'fusion-builder' ),
					'default'     => 'self',
					'value'       => [
						'self'   => esc_attr__( 'Self', 'fusion-builder' ),
						'parent' => esc_attr__( 'Parent', 'fusion-builder' ),
					],
					'subgroup'    => [
						'name' => 'filter_backdrop_type',
						'tab'  => 'hover',
					],
					'callback'    => [
						'function' => 'fusion_update_filter_style',
						'args'     => [
							'selector_base' => $selector_base,
						],
					],
				];
			}

			foreach ( $states as $key ) {
				$filter_options = array_merge(
					$filter_options,
					[
						[
							'type'        => 'range',
							'heading'     => esc_attr__( 'Backdrop Hue', 'fusion-builder' ),
							'description' => esc_attr__( 'Backdrop filter hue.', 'fusion-builder' ),
							'param_name'  => 'filter_backdrop_hue' . ( 'regular' !== $key ? '_' . $key : '' ),
							'value'       => '0',
							'min'         => '0',
							'max'         => '359',
							'group'       => esc_attr__( 'Extras', 'fusion-builder' ),
							'subgroup'    => [
								'name' => 'filter_backdrop_type',
								'tab'  => $key,
							],
							'callback'    => [
								'function' => 'fusion_update_filter_style',
								'args'     => [
									'selector_base' => $selector_base,
								],
							],
						],
						[
							'type'        => 'range',
							'heading'     => esc_attr__( 'Backdrop Saturation', 'fusion-builder' ),
							'description' => esc_attr__( 'Backdrop filter saturation.', 'fusion-builder' ),
							'param_name'  => 'filter_backdrop_saturation' . ( 'regular' !== $key ? '_' . $key : '' ),
							'value'       => '100',
							'min'         => '0',
							'max'         => '200',
							'group'       => esc_attr__( 'Extras', 'fusion-builder' ),
							'subgroup'    => [
								'name' => 'filter_backdrop_type',
								'tab'  => $key,
							],
							'callback'    => [
								'function' => 'fusion_update_filter_style',
								'args'     => [
									'selector_base' => $selector_base,
								],
							],
						],
						[
							'type'        => 'range',
							'heading'     => esc_attr__( 'Backdrop Brightness', 'fusion-builder' ),
							'description' => esc_attr__( 'Backdrop filter brightness.', 'fusion-builder' ),
							'param_name'  => 'filter_backdrop_brightness' . ( 'regular' !== $key ? '_' . $key : '' ),
							'value'       => '100',
							'min'         => '0',
							'max'         => '200',
							'group'       => esc_attr__( 'Extras', 'fusion-builder' ),
							'subgroup'    => [
								'name' => 'filter_backdrop_type',
								'tab'  => $key,
							],
							'callback'    => [
								'function' => 'fusion_update_filter_style',
								'args'     => [
									'selector_base' => $selector_base,
								],
							],
						],
						[
							'type'        => 'range',
							'heading'     => esc_attr__( 'Backdrop Contrast', 'fusion-builder' ),
							'description' => esc_attr__( 'Backdrop filter contrast.', 'fusion-builder' ),
							'param_name'  => 'filter_backdrop_contrast' . ( 'regular' !== $key ? '_' . $key : '' ),
							'value'       => '100',
							'min'         => '0',
							'max'         => '200',
							'group'       => esc_attr__( 'Extras', 'fusion-builder' ),
							'subgroup'    => [
								'name' => 'filter_backdrop_type',
								'tab'  => $key,
							],
							'callback'    => [
								'function' => 'fusion_update_filter_style',
								'args'     => [
									'selector_base' => $selector_base,
								],
							],
						],
						[
							'type'        => 'range',
							'heading'     => esc_attr__( 'Backdrop Invert', 'fusion-builder' ),
							'description' => esc_attr__( 'Backdrop filter invert.', 'fusion-builder' ),
							'param_name'  => 'filter_backdrop_invert' . ( 'regular' !== $key ? '_' . $key : '' ),
							'value'       => '0',
							'min'         => '0',
							'max'         => '100',
							'group'       => esc_attr__( 'Extras', 'fusion-builder' ),
							'subgroup'    => [
								'name' => 'filter_backdrop_type',
								'tab'  => $key,
							],
							'callback'    => [
								'function' => 'fusion_update_filter_style',
								'args'     => [
									'selector_base' => $selector_base,
								],
							],
						],
						[
							'type'        => 'range',
							'heading'     => esc_attr__( 'Backdrop Sepia', 'fusion-builder' ),
							'description' => esc_attr__( 'Backdrop filter sepia.', 'fusion-builder' ),
							'param_name'  => 'filter_backdrop_sepia' . ( 'regular' !== $key ? '_' . $key : '' ),
							'value'       => '0',
							'min'         => '0',
							'max'         => '100',
							'group'       => esc_attr__( 'Extras', 'fusion-builder' ),
							'subgroup'    => [
								'name' => 'filter_backdrop_type',
								'tab'  => $key,
							],
							'callback'    => [
								'function' => 'fusion_update_filter_style',
								'args'     => [
									'selector_base' => $selector_base,
								],
							],
						],
						[
							'type'        => 'range',
							'heading'     => esc_attr__( 'Backdrop Opacity', 'fusion-builder' ),
							'description' => esc_attr__( 'Backdrop filter opacity.', 'fusion-builder' ),
							'param_name'  => 'filter_backdrop_opacity' . ( 'regular' !== $key ? '_' . $key : '' ),
							'value'       => '100',
							'min'         => '0',
							'max'         => '100',
							'group'       => esc_attr__( 'Extras', 'fusion-builder' ),
							'subgroup'    => [
								'name' => 'filter_backdrop_type',
								'tab'  => $key,
							],
							'callback'    => [
								'function' => 'fusion_update_filter_style',
								'args'     => [
									'selector_base' => $selector_base,
								],
							],
						],
						[
							'type'        => 'range',
							'heading'     => esc_attr__( 'Backdrop Blur', 'fusion-builder' ),
							'description' => esc_attr__( 'Backdrop filter blur, e.g. for frosted glass effects.', 'fusion-builder' ),
							'param_name'  => 'filter_backdrop_blur' . ( 'regular' !== $key ? '_' . $key : '' ),
							'value'       => '0',
							'min'         => '0',
							'max'         => '50',
							'group'       => esc_attr__( 'Extras', 'fusion-builder' ),
							'subgroup'    => [
								'name' => 'filter_backdrop_type',
								'tab'  => $key,
							],
							'callback'    => [
								'function' => 'fusion_update_filter_style',
								'args'     => [
									'selector_base' => $selector_base,
								],
							],
						],
					]
				);
			}
		}

		return $filter_options;
	}

	/**
	 * Get filter styles
	 *
	 * @since 2.2
	 * @access public
	 * @param array  $atts The filter parameters.
	 * @param string $state Element state, regular or hover.
	 * @return string
	 */
	public static function get_filter_styles( $atts, $state = 'regular' ) {

		$state_suffix       = 'regular' === $state ? '' : '_hover';
		$other_state_suffix = 'regular' === $state ? '_hover' : '';

		$filters = [
			'filter_hue'        => [
				'property' => 'hue-rotate',
				'unit'     => 'deg',
				'default'  => '0',
			],
			'filter_saturation' => [
				'property' => 'saturate',
				'unit'     => '%',
				'default'  => '100',
			],
			'filter_brightness' => [
				'property' => 'brightness',
				'unit'     => '%',
				'default'  => '100',
			],
			'filter_contrast'   => [
				'property' => 'contrast',
				'unit'     => '%',
				'default'  => '100',
			],
			'filter_invert'     => [
				'property' => 'invert',
				'unit'     => '%',
				'default'  => '0',
			],
			'filter_sepia'      => [
				'property' => 'sepia',
				'unit'     => '%',
				'default'  => '0',
			],
			'filter_opacity'    => [
				'property' => 'opacity',
				'unit'     => '%',
				'default'  => '100',
			],
			'filter_blur'       => [
				'property' => 'blur',
				'unit'     => 'px',
				'default'  => '0',
			],
		];

		$filter_style = '';
		foreach ( $filters as $filter_id => $filter ) {
			$filter_id_state = $filter_id . $state_suffix;
			$filter_id_other = $filter_id . $other_state_suffix;
			if ( $filter['default'] !== $atts[ $filter_id_state ] || $filter['default'] !== $atts[ $filter_id_other ] ) {
				$filter_style .= $filter['property'] . '(' . $atts[ $filter_id_state ] . $filter['unit'] . ') ';
			}
		}

		return trim( $filter_style );
	}

	/**
	 * Get backdrop-filter styles.
	 *
	 * @since 3.16
	 * @access public
	 * @param array  $atts The filter parameters.
	 * @param string $state Element state, regular or hover.
	 * @return string
	 */
	public static function get_backdrop_filter_styles( $atts, $state = 'regular' ) {

		$state_suffix       = 'regular' === $state ? '' : '_hover';
		$other_state_suffix = 'regular' === $state ? '_hover' : '';

		$filters = [
			'filter_backdrop_hue'        => [
				'property' => 'hue-rotate',
				'unit'     => 'deg',
				'default'  => '0',
			],
			'filter_backdrop_saturation' => [
				'property' => 'saturate',
				'unit'     => '%',
				'default'  => '100',
			],
			'filter_backdrop_brightness' => [
				'property' => 'brightness',
				'unit'     => '%',
				'default'  => '100',
			],
			'filter_backdrop_contrast'   => [
				'property' => 'contrast',
				'unit'     => '%',
				'default'  => '100',
			],
			'filter_backdrop_invert'     => [
				'property' => 'invert',
				'unit'     => '%',
				'default'  => '0',
			],
			'filter_backdrop_sepia'      => [
				'property' => 'sepia',
				'unit'     => '%',
				'default'  => '0',
			],
			'filter_backdrop_opacity'    => [
				'property' => 'opacity',
				'unit'     => '%',
				'default'  => '100',
			],
			'filter_backdrop_blur'       => [
				'property' => 'blur',
				'unit'     => 'px',
				'default'  => '0',
			],
		];

		$filter_style = '';
		foreach ( $filters as $filter_id => $filter ) {
			$value_state = isset( $atts[ $filter_id . $state_suffix ] ) ? $atts[ $filter_id . $state_suffix ] : $filter['default'];
			$value_other = isset( $atts[ $filter_id . $other_state_suffix ] ) ? $atts[ $filter_id . $other_state_suffix ] : $filter['default'];
			if ( $filter['default'] !== $value_state || $filter['default'] !== $value_other ) {
				$filter_style .= $filter['property'] . '(' . $value_state . $filter['unit'] . ') ';
			}
		}

		return trim( $filter_style );
	}

	/**
	 * Get filter style element.
	 *
	 * @since 2.2
	 * @access public
	 * @param array  $atts The filter parameters.
	 * @param string $selector Element selector.
	 * @param bool   $include_style_tag Include <style> tag or not.
	 * @return string
	 */
	public static function get_filter_style_element( $atts, $selector, $include_style_tag = true ) {

		$opening_style_tag = true === $include_style_tag ? '<style type="text/css">' : '';
		$closing_style_tag = true === $include_style_tag ? '</style>' : '';

		$filter_style = self::get_filter_styles( $atts, 'regular' );
		if ( '' !== $filter_style ) {
			$filter_style = $selector . '{filter: ' . $filter_style . ';}';
		}

		$backdrop_filter_style = self::get_backdrop_filter_styles( $atts, 'regular' );
		if ( '' !== $backdrop_filter_style ) {
			$filter_style .= $selector . '{-webkit-backdrop-filter: ' . $backdrop_filter_style . ';backdrop-filter: ' . $backdrop_filter_style . ';}';
		}

		$filter_style_hover          = self::get_filter_styles( $atts, 'hover' );
		$backdrop_filter_style_hover = self::get_backdrop_filter_styles( $atts, 'hover' );
		if ( '' !== $filter_style_hover || '' !== $backdrop_filter_style_hover ) {

			// Add transition.
			$filter_style = str_replace( '}', 'transition: filter 0.3s ease, -webkit-backdrop-filter 0.3s ease, backdrop-filter 0.3s ease;}', $filter_style );

			// Hover state.
			if ( '' !== $filter_style_hover ) {
				$hover_selector = self::get_hover_selector( $atts, $selector, 'filter_hover_element' );
				$filter_style  .= $hover_selector . '{filter: ' . $filter_style_hover . ';}';
			}
			if ( '' !== $backdrop_filter_style_hover ) {
				$hover_selector = self::get_hover_selector( $atts, $selector, 'filter_backdrop_hover_element' );
				$filter_style  .= $hover_selector . '{-webkit-backdrop-filter: ' . $backdrop_filter_style_hover . ';backdrop-filter: ' . $backdrop_filter_style_hover . ';}';
			}
		}

		return '' !== $filter_style ? $opening_style_tag . $filter_style . $closing_style_tag : '';
	}

	/**
	 * Get the hover selector for an element state.
	 *
	 * @since 3.16
	 * @access public
	 * @param array  $atts The filter parameters.
	 * @param string $selector Element selector.
	 * @param string $hover_element_param The param holding the self|parent hover element choice.
	 * @return string
	 */
	public static function get_hover_selector( $atts, $selector, $hover_element_param = 'filter_hover_element' ) {
		$hover_selector = $selector . ':hover';

		if ( isset( $atts[ $hover_element_param ] ) && 'parent' === $atts[ $hover_element_param ] ) {
			if ( strpos( $selector, 'nested-column-' ) !== false ) {
				$hover_selector  = '.fusion-column-wrapper:hover > .fusion-builder-row >' . $selector;
				$hover_selector .= ', .fusion-column-inner-bg:hover + .fusion-column-wrapper > .fusion-builder-row >' . $selector;
			} else {
				$hover_selector = '.fusion-builder-row:hover > ' . $selector;
			}
		}

		return $hover_selector;
	}

	/**
	 * Get filter style element.
	 *
	 * @param array $atts The filter parameters.
	 * @param bool  $parent_hover Whether or not the parent is hover.
	 * @return string
	 */
	public static function get_filter_vars( $atts, $parent_hover = false ) {
		$filter_style                = self::get_filter_styles( $atts, 'regular' );
		$filter_style_hover          = self::get_filter_styles( $atts, 'hover' );
		$backdrop_filter_style       = self::get_backdrop_filter_styles( $atts, 'regular' );
		$backdrop_filter_style_hover = self::get_backdrop_filter_styles( $atts, 'hover' );

		$final_vars = '';

		if ( '' !== $filter_style ) {
			$final_vars .= '--awb-filter:' . $filter_style . ';';
		}

		if ( '' !== $backdrop_filter_style ) {
			$final_vars .= '--awb-backdrop-filter:' . $backdrop_filter_style . ';';
		}

		if ( '' !== $filter_style_hover || '' !== $backdrop_filter_style_hover ) {
			$final_vars .= '--awb-filter-transition:filter 0.3s ease, -webkit-backdrop-filter 0.3s ease, backdrop-filter 0.3s ease;';
		}

		if ( '' !== $filter_style_hover ) {
			$final_vars .= '--awb-filter-hover:' . $filter_style_hover . ';';

			if ( 'parent' === $atts['filter_hover_element'] && $parent_hover ) {
				$final_vars .= '--awb-filter-parent-hover:' . $filter_style_hover . ';';
			}
		}

		if ( '' !== $backdrop_filter_style_hover ) {
			$final_vars .= '--awb-backdrop-filter-hover:' . $backdrop_filter_style_hover . ';';

			if ( isset( $atts['filter_backdrop_hover_element'] ) && 'parent' === $atts['filter_backdrop_hover_element'] && $parent_hover ) {
				$final_vars .= '--awb-backdrop-filter-parent-hover:' . $backdrop_filter_style_hover . ';';
			}
		}

		return $final_vars;
	}
}
