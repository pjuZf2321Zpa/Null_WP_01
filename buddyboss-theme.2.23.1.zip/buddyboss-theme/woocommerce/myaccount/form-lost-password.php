<?php
/**
 * Lost password form
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/myaccount/form-lost-password.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see https://woocommerce.com/document/template-structure/
 * @package WooCommerce/Templates
 * @version 9.2.0
 */

defined( 'ABSPATH' ) || exit;

do_action( 'woocommerce_before_lost_password_form' );

wc_print_notices(); ?>

<div class="bsMyAccount">

	<div class="woocommerce-MyAccount-content">

		<div class="wc-MyAccount-sub-heading">
			<h2><?php esc_html_e( 'Lost your password?', 'buddyboss-theme' ); ?></h2>
		</div>

		<div class="wc-LostPassword">

			<form method="post" class="woocommerce-ResetPassword lost_reset_password">

            	<p class="bs_woocommerce_reset_message"><?php echo apply_filters( 'woocommerce_lost_password_message', esc_html__( 'Please enter your username or email address. You will receive a link to create a new password via email.', 'buddyboss-theme' ) ); ?></p><?php // @codingStandardsIgnoreLine ?>

				<p class="woocommerce-form-row woocommerce-form-row--first form-row">
					<label for="user_login"><?php esc_html_e( 'Username or email', 'buddyboss-theme' ); ?></label>
					<input class="woocommerce-Input woocommerce-Input--text input-text" type="text" name="user_login" id="user_login" autocomplete="username" />
				</p>

				<div class="clear"></div>

				<?php do_action( 'woocommerce_lostpassword_form' ); ?>

				<p class="woocommerce-form-row form-row bs_woocommerce_reset_ctrls">
					<input type="hidden" name="wc_reset_password" value="true" />
					<button type="submit" class="woocommerce-Button button<?php echo esc_attr( wc_wp_theme_get_element_class_name( 'button' ) ? ' ' . wc_wp_theme_get_element_class_name( 'button' ) : '' ); ?>" value="<?php esc_attr_e( 'Reset password', 'buddyboss-theme' ); ?>"><?php esc_html_e( 'Reset password', 'buddyboss-theme' ); ?></button>
				</p>

				<?php wp_nonce_field( 'lost_password', 'woocommerce-lost-password-nonce' ); ?>

			</form>

		</div>

	</div>

</div>

<?php
do_action( 'woocommerce_after_lost_password_form' );
