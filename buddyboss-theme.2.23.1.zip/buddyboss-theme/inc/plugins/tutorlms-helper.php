<?php
/**
 * Tutor LMS helper
 *
 * Tutor 4.0 rewrote the frontend dashboard and learning area from the ground
 * up: it owns its own layout, routing and SVG icon set. The theme therefore
 * ships no Tutor template overrides any more — everything below is hook-based,
 * so a Tutor update can change markup freely without silently stranding a
 * stale copy in the theme.
 *
 * What the theme still does:
 *   - keeps the theme header and BuddyPanel on Tutor's screens by switching on
 *     Tutor's own "site header" option (Tutor >= 4.0.7 renders get_header()
 *     itself and measures the header for its offsets; Tutor 4.0.0-4.0.6 gets
 *     the header printed in by bb_tutorlms_render_theme_header())
 *   - swaps Tutor's avatars for BuddyBoss ones (see bb_tutorlms_avatar_* below)
 *   - redirects Tutor's own profile URLs to the BuddyBoss profile
 *   - hides the Tutor account tabs that BuddyBoss already owns
 *   - adds body classes so tutorlms.css can scope itself
 *
 * @since   2.4.90
 *
 * @package BuddyBoss_Theme
 */

namespace BuddyBossTheme;

if ( ! class_exists( '\BuddyBossTheme\TutorLMSHelper' ) ) {

	/**
	 * Tutor LMS integration: theme header on Tutor screens, BuddyBoss avatars,
	 * profile redirects and the account tabs BuddyBoss owns.
	 *
	 * @since 2.4.90
	 */
	class TutorLMSHelper {

		/**
		 * Placeholder written in place of a real `_tutor_profile_photo`
		 * attachment ID. Deliberately non-numeric so Tutor's own
		 * `is_numeric()` guards (e.g. its photo-delete path) skip it.
		 *
		 * @since 2.23.1
		 *
		 * @var string
		 */
		const AVATAR_SENTINEL = 'bb_tutorlms_bp_avatar';

		/**
		 * Tutor option keys the theme pins on the front end so Tutor renders
		 * the theme header itself. Values are Tutor's stored 'on'/'off' form.
		 *
		 * @since 2.23.1
		 *
		 * @var array
		 */
		const SITE_HEADER_OPTIONS = array(
			'show_learning_site_header'  => 'on',
			'show_dashboard_site_header' => 'on',
			'enable_spotlight_mode'      => 'off',
		);

		/**
		 * User ID whose profile photo Tutor asked for most recently.
		 *
		 * @since 2.23.1
		 *
		 * @var int
		 */
		protected $avatar_user_id = 0;

		/**
		 * True while the helper reads `_tutor_profile_photo` for itself, so
		 * bb_tutorlms_avatar_meta() lets the real value through.
		 *
		 * @since 2.23.1
		 *
		 * @var bool
		 */
		protected $reading_raw_meta = false;

		/**
		 * Resolved BuddyBoss avatars for this request, keyed "user_id:type".
		 *
		 * @since 2.23.1
		 *
		 * @var array
		 */
		protected $avatar_cache = array();

		/**
		 * Attachment ID => owning user ID for Tutor profile photos seen this request.
		 *
		 * @since 2.23.1
		 *
		 * @var array
		 */
		protected $photo_owner_cache = array();

		/**
		 * True while bp_core_fetch_avatar() runs for the bridge, so a nested
		 * image-src filter call (e.g. a BuddyBoss default avatar that is itself
		 * an attachment) is left alone instead of recursing.
		 *
		 * @since 2.23.1
		 *
		 * @var bool
		 */
		protected $resolving_avatar = false;

		/**
		 * Cached learning-area content access for the current request.
		 *
		 * @since 2.23.1
		 *
		 * @var bool|null
		 */
		protected $learning_access = null;

		/**
		 * Cached result of bb_tutorlms_use_theme_header().
		 *
		 * @since 2.23.1
		 *
		 * @var bool|null
		 */
		protected $use_theme_header = null;

		/**
		 * Cached result of bb_tutorlms_is_standalone_screen().
		 *
		 * @since 2.23.1
		 *
		 * @var bool|null
		 */
		protected $standalone_screen = null;

		/**
		 * Cached result of bb_tutorlms_is_site_shell_screen().
		 *
		 * @since 2.23.1
		 *
		 * @var bool|null
		 */
		protected $site_shell_screen = null;

		/**
		 * Constructor
		 *
		 * @since 2.4.90
		 * @since 2.23.1 Runs the redirect before Tutor's own old-slug redirect, pins
		 *                    Tutor's site-header options and filters the public profile layout.
		 */
		public function __construct() {
			// Priority 9: Tutor's Dashboard::redirect_old_dashboard_pages() runs at 10 and exits on /dashboard/my-profile/.
			add_action( 'template_redirect', array( $this, 'bb_tutorlms_template_redirect' ), 9 );
			add_filter( 'tutor_dashboard/nav_items/settings/nav_items', array( $this, 'bb_tutorlms_filter_profile_tabs' ) );
			add_filter( 'tutor_dashboard/nav_ui_items', array( $this, 'bb_tutorlms_filter_dashboard_nav_items' ) );
			add_filter( 'body_class', array( $this, 'bb_tutorlms_custom_class' ) );

			// BuddyBoss avatars inside Tutor's own avatar rendering.
			add_filter( 'get_user_metadata', array( $this, 'bb_tutorlms_avatar_meta' ), 10, 4 );
			add_filter( 'wp_get_attachment_image_src', array( $this, 'bb_tutorlms_avatar_src' ), 10, 3 );

			/*
			 * BuddyBoss owns member profiles, so Tutor's profile-completion
			 * prompt is redundant. tutor_utils()->get_option() ends in
			 * apply_filters( $key, $value ), so the option key is the filter
			 * name. This replaces the old dashboard/dashboard.php override.
			 */
			add_filter( 'enable_profile_completion', array( $this, 'bb_tutorlms_disable_profile_completion' ) );

			/*
			 * Tutor's own public profile is replaced by the BuddyBoss profile
			 * (see bb_tutorlms_template_redirect()), so a "Private" layout
			 * would only turn course-card author links into dead "#" links.
			 */
			add_filter( 'public_profile_layout', array( $this, 'bb_tutorlms_public_profile_layout' ) );
			add_filter( 'student_public_profile_layout', array( $this, 'bb_tutorlms_public_profile_layout' ) );

			// Tutor's login form fires `login_form` but already has its own lost-password link.
			add_action( 'tutor_before_login_form', array( $this, 'bb_tutorlms_suspend_login_lost_password' ) );
			add_action( 'tutor_after_login_form', array( $this, 'bb_tutorlms_restore_login_lost_password' ) );

			/*
			 * Theme header on Tutor's full-page screens. Tutor >= 4.0.7 renders
			 * get_header() itself once its site-header options are on, and
			 * measures the header for every offset; the theme only pins those
			 * options. Tutor 4.0.0-4.0.6 has no such option, so the header is
			 * printed into the page instead.
			 */
			add_filter( 'option_tutor_option', array( $this, 'bb_tutorlms_pin_site_header_options' ) );
			add_filter( 'tutor_theme_header_selector', array( $this, 'bb_tutorlms_theme_header_selector' ) );
			add_filter( 'tutor/options/attr', array( $this, 'bb_tutorlms_settings_note' ) );
			add_filter( 'pre_update_option_tutor_option', array( $this, 'bb_tutorlms_unpin_site_header_options' ) );
			add_action( 'wp_body_open', array( $this, 'bb_tutorlms_render_theme_header' ), 5 );
		}

		/**
		 * Whether the theme header and BuddyPanel should appear on Tutor's screens.
		 *
		 * Front-end page requests only: wp-admin (Tutor's settings screen must
		 * keep showing the stored values), admin-ajax, REST, cron and WP-CLI
		 * are left alone so nothing that reads and re-saves `tutor_option`
		 * sees the pinned values.
		 *
		 * @since 2.23.1
		 *
		 * @return bool
		 */
		public function bb_tutorlms_use_theme_header() {
			if ( null !== $this->use_theme_header ) {
				return $this->use_theme_header;
			}

			$is_frontend_page = ! is_admin()
				&& ! wp_doing_ajax()
				&& ! wp_doing_cron()
				&& ! $this->bb_tutorlms_is_rest_request()
				&& ! ( defined( 'WP_CLI' ) && WP_CLI );

			/**
			 * Filters whether the theme header is shown on Tutor LMS full-page screens.
			 *
			 * @since 2.23.1
			 *
			 * @param bool $use_theme_header Whether to show the theme header.
			 */
			$this->use_theme_header = (bool) apply_filters( 'bb_tutorlms_use_theme_header', $is_frontend_page );

			return $this->use_theme_header;
		}

		/**
		 * Whether this is a REST request.
		 *
		 * REST_REQUEST is only defined at parse_request, after Tutor has read
		 * its options for the first time, so the constant alone would miss the
		 * early reads; the URL prefix is known from the start.
		 *
		 * @since 2.23.1
		 *
		 * @return bool
		 */
		protected function bb_tutorlms_is_rest_request() {
			if ( function_exists( 'wp_is_serving_rest_request' ) && wp_is_serving_rest_request() ) {
				return true;
			}

			if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
				return true;
			}

			$request_uri = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- compared against a known prefix only.

			return '' !== $request_uri && false !== strpos( $request_uri, '/' . rest_get_url_prefix() . '/' );
		}

		/**
		 * Whether this Tutor version renders the theme header itself (Tutor >= 4.0.7).
		 *
		 * @since 2.23.1
		 *
		 * @return bool
		 */
		public function bb_tutorlms_supports_site_shell() {
			return method_exists( '\TUTOR\Template', 'get_site_shell_data' );
		}

		/**
		 * Pin the Tutor options that make Tutor render the theme header.
		 *
		 * Filtering `option_tutor_option` rather than Tutor's per-key filters
		 * because tutor_utils()->get_option() only fires those for keys that
		 * exist in the stored array; on a fresh install the site-header keys
		 * are absent and Tutor falls back to its defaults (dashboard header
		 * off). This also covers Tutor 3.x and Tutor 4 legacy learning mode,
		 * where `enable_spotlight_mode` decides between get_header() and
		 * Tutor's bare <html> shell, and Tutor's dashboard sidebar logo,
		 * which Tutor only prints while its own header option is off.
		 *
		 * @since 2.23.1
		 *
		 * @param mixed $option Stored `tutor_option` value.
		 *
		 * @return mixed
		 */
		public function bb_tutorlms_pin_site_header_options( $option ) {
			if ( ! is_array( $option ) || ! $this->bb_tutorlms_use_theme_header() ) {
				return $option;
			}

			return array_merge( $option, self::SITE_HEADER_OPTIONS );
		}

		/**
		 * Point Tutor's header measurement at the theme header.
		 *
		 * Tutor resolves its selector list with querySelector() and takes the
		 * first match. With a BuddyPanel the panel's own `<header class="panel-head">`
		 * is printed before `#masthead`; Tutor picked it, rejected it as not
		 * fixed, and fell back to an admin-bar-only offset, so its sticky bars
		 * slid under the theme header on scroll.
		 *
		 * @since 2.23.1
		 *
		 * @param string $selector Tutor's default selector list.
		 *
		 * @return string
		 */
		public function bb_tutorlms_theme_header_selector( $selector ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found -- querySelector() returns the first element in document order for a list, so Tutor's list cannot be kept.
			return '#masthead';
		}

		/**
		 * Explain on Tutor's settings screen that the header toggles are managed by the theme.
		 *
		 * The stored values stay editable there (they still drive Tutor's
		 * footer logic and are honoured again the moment the theme override is
		 * switched off), but on the front end the header is always on.
		 *
		 * @since 2.23.1
		 *
		 * @param array $attr Tutor settings definition.
		 *
		 * @return array
		 */
		public function bb_tutorlms_settings_note( $attr ) {
			if ( ! is_array( $attr ) ) {
				return $attr;
			}

			$note = __( 'The BuddyBoss Theme shows its header on the Dashboard and Learning Area while its Tutor LMS integration is active; the Header toggles below do not apply on the front end.', 'buddyboss-theme' );

			$this->bb_tutorlms_append_field_desc( $attr, 'page_elements', $note );

			return $attr;
		}

		/**
		 * Append a note to the description of a Tutor settings field, wherever it sits in the tree.
		 *
		 * @since 2.23.1
		 *
		 * @param array  $node Settings tree (modified in place).
		 * @param string $key  Field key to find.
		 * @param string $note Text to append.
		 */
		protected function bb_tutorlms_append_field_desc( array &$node, $key, $note ) {
			if ( isset( $node['key'] ) && $key === $node['key'] ) {
				$desc = isset( $node['desc'] ) ? trim( (string) $node['desc'] ) : '';

				// Tutor's own description has no terminal punctuation.
				if ( '' !== $desc && ! in_array( substr( $desc, -1 ), array( '.', '!', '?' ), true ) ) {
					$desc .= '.';
				}

				$node['desc'] = trim( $desc . ' ' . $note );

				return;
			}

			foreach ( $node as &$child ) {
				if ( is_array( $child ) ) {
					$this->bb_tutorlms_append_field_desc( $child, $key, $note );
				}
			}
		}

		/**
		 * Keep the pinned values out of the database.
		 *
		 * Anything that reads `tutor_option` on the front end, changes one key
		 * and writes the array back would otherwise persist the pinned values
		 * as the site owner's own settings. A key carrying exactly the pinned
		 * value is put back to what is stored (or dropped when nothing is);
		 * real edits happen in wp-admin / admin-ajax, where nothing is pinned.
		 *
		 * @since 2.23.1
		 *
		 * @param mixed $value New option value.
		 *
		 * @return mixed
		 */
		public function bb_tutorlms_unpin_site_header_options( $value ) {
			if ( ! is_array( $value ) || ! $this->bb_tutorlms_use_theme_header() ) {
				return $value;
			}

			remove_filter( 'option_tutor_option', array( $this, 'bb_tutorlms_pin_site_header_options' ) );
			$stored = get_option( 'tutor_option', array() );
			add_filter( 'option_tutor_option', array( $this, 'bb_tutorlms_pin_site_header_options' ) );
			add_filter( 'tutor/options/attr', array( $this, 'bb_tutorlms_settings_note' ) );

			foreach ( self::SITE_HEADER_OPTIONS as $key => $pinned ) {
				if ( ! isset( $value[ $key ] ) || $pinned !== $value[ $key ] ) {
					continue;
				}

				if ( ! is_array( $stored ) || ! array_key_exists( $key, $stored ) ) {
					unset( $value[ $key ] );
				} elseif ( $pinned !== $stored[ $key ] ) {
					$value[ $key ] = $stored[ $key ];
				}
			}

			return $value;
		}

		/**
		 * Whether this request is a Tutor 4.0.0-4.0.6 full-page screen that needs the theme header printed in.
		 *
		 * Those versions' Modern/Kids learning area and frontend dashboard
		 * print their own <html>/<body> and never call get_header(). Anything
		 * that already went through get_header() — Legacy learning mode (its
		 * spotlight option is pinned off above), Tutor's login screen for
		 * logged-out visitors, every regular theme page — is left alone. From
		 * Tutor 4.0.7 the pinned site-header options make Tutor call
		 * get_header() itself, so this is always false there.
		 *
		 * @since 2.23.1
		 *
		 * @return bool
		 */
		public function bb_tutorlms_is_standalone_screen() {
			if ( null !== $this->standalone_screen ) {
				return $this->standalone_screen;
			}

			$this->standalone_screen = false;

			if ( is_admin() || did_action( 'get_header' ) || ! function_exists( 'tutor_utils' ) || $this->bb_tutorlms_supports_site_shell() || ! $this->bb_tutorlms_use_theme_header() ) {
				return $this->standalone_screen;
			}

			$utils = tutor_utils();

			$is_learning_area = method_exists( $utils, 'is_learning_area' ) && $utils->is_learning_area();
			$is_legacy        = method_exists( $utils, 'is_legacy_learning_mode' ) && $utils->is_legacy_learning_mode();
			$is_dashboard     = $utils->is_tutor_frontend_dashboard() && ! $utils->is_tutor_frontend_dashboard( 'create-course' );

			/*
			 * Without content access Tutor swaps in its login / permission-denied
			 * templates, which run get_header() themselves.
			 */
			$this->standalone_screen = is_user_logged_in() && (
				( $is_learning_area && ! $is_legacy && $this->bb_tutorlms_has_learning_access() )
				|| $is_dashboard
			);

			return $this->standalone_screen;
		}

		/**
		 * Whether this is a Tutor >= 4.0.7 learning-area or dashboard screen rendered inside the theme header.
		 *
		 * Tutor lays these out itself around the measured theme header; the
		 * theme only widens its content container and restyles its own chrome
		 * for Tutor's dark mode (see tutorlms.css `.bb-tutorlms-site-shell`).
		 *
		 * @since 2.23.1
		 *
		 * @return bool
		 */
		public function bb_tutorlms_is_site_shell_screen() {
			if ( null !== $this->site_shell_screen ) {
				return $this->site_shell_screen;
			}

			$this->site_shell_screen = false;

			if ( is_admin() || ! function_exists( 'tutor_utils' ) || ! $this->bb_tutorlms_supports_site_shell() || ! $this->bb_tutorlms_use_theme_header() ) {
				return $this->site_shell_screen;
			}

			$utils = tutor_utils();

			$is_learning_area = method_exists( $utils, 'is_learning_area' ) && $utils->is_learning_area();
			$is_legacy        = method_exists( $utils, 'is_legacy_learning_mode' ) && $utils->is_legacy_learning_mode();
			$is_dashboard     = $utils->is_tutor_frontend_dashboard() && ! $utils->is_tutor_frontend_dashboard( 'create-course' );

			$this->site_shell_screen = ( $is_learning_area && ! $is_legacy ) || $is_dashboard;

			return $this->site_shell_screen;
		}

		/**
		 * Whether the learning area will render its own content for this user.
		 *
		 * Mirrors the check in Tutor's learning-area/index.php, which falls back to
		 * the login or permission-denied template when this is false.
		 *
		 * @since 2.23.1
		 *
		 * @return bool
		 */
		protected function bb_tutorlms_has_learning_access() {
			if ( null !== $this->learning_access ) {
				return $this->learning_access;
			}

			if ( ! class_exists( '\Tutor\Models\CourseModel' ) || ! method_exists( '\Tutor\Models\CourseModel', 'has_course_content_access' ) ) {
				$this->learning_access = true;

				return $this->learning_access;
			}

			$post_id   = get_the_ID();
			$post_type = get_post_type();
			$course_id = tutor()->course_post_type === $post_type ? $post_id : tutor_utils()->get_course_id_by_subcontent( $post_id );

			try {
				$this->learning_access = \Tutor\Models\CourseModel::has_course_content_access(
					array(
						'current_post_type' => $post_type,
						'current_post_id'   => $post_id,
						'course_id'         => $course_id,
						'is_public'         => \TUTOR\Course_List::is_public( (int) $course_id ),
						'is_enrolled'       => \Tutor\Models\EnrollmentModel::is_enrolled( $course_id ),
					)
				);
			} catch ( \Throwable $e ) {
				$this->learning_access = false;
			}

			return $this->learning_access;
		}

		/**
		 * Print the theme's BuddyPanel and site header at the top of Tutor 4.0.0-4.0.6 full-page screens.
		 *
		 * Mirrors header.php up to the end of the header, using the same hooks so
		 * header builders (Elementor, Beaver Themer) and the BuddyPanel keep working.
		 * The #page wrapper is closed straight away: Tutor's own layout follows it.
		 *
		 * @since 2.23.1
		 */
		public function bb_tutorlms_render_theme_header() {
			if ( ! $this->bb_tutorlms_is_standalone_screen() ) {
				return;
			}

			do_action( THEME_HOOK_PREFIX . 'before_page' );
			?>
			<div id="page" class="site bb-tutorlms-theme-header">
				<?php do_action( THEME_HOOK_PREFIX . 'before_header' ); ?>
				<header id="masthead" class="<?php echo esc_attr( apply_filters( 'buddyboss_site_header_class', 'site-header site-header--bb' ) ); ?>">
					<?php do_action( THEME_HOOK_PREFIX . 'header' ); ?>
				</header>
				<?php do_action( THEME_HOOK_PREFIX . 'after_header' ); ?>
			</div>
			<?php
		}

		/**
		 * Keep the theme's "Forgot Password?" link out of Tutor's login form.
		 *
		 * The theme's login_custom_form() echoes it on every `login_form` action, which Tutor's
		 * login template also fires, so the form showed two links pointing at
		 * different reset pages.
		 *
		 * @since 2.23.1
		 */
		public function bb_tutorlms_suspend_login_lost_password() {
			remove_action( 'login_form', 'login_custom_form' );
		}

		/**
		 * Re-attach the theme's lost-password link once Tutor's form has rendered.
		 *
		 * @since 2.23.1
		 */
		public function bb_tutorlms_restore_login_lost_password() {
			if ( function_exists( 'login_custom_form' ) && ! has_action( 'login_form', 'login_custom_form' ) ) {
				add_action( 'login_form', 'login_custom_form' );
			}
		}

		/**
		 * Whether BuddyBoss avatars should stand in for Tutor's.
		 *
		 * Off in wp-admin: Tutor's user-profile metabox renders the stored
		 * `_tutor_profile_photo` into a hidden input and writes it back on
		 * save, so substituting a value there would overwrite the real one.
		 * admin-ajax.php is treated as front end — Tutor 4.x fetches dashboard
		 * sections through it — except for Tutor's own photo upload and remove
		 * handlers, which must keep working on the genuine value.
		 *
		 * @since 2.23.1
		 *
		 * @return bool
		 */
		protected function bb_tutorlms_use_bb_avatars() {
			if ( wp_doing_ajax() ) {
				// Tutor 4.x loads dashboard sections (e.g. recent reviews) over admin-ajax; only its photo handlers must see the real value.
				$action  = isset( $_REQUEST['action'] ) ? sanitize_key( wp_unslash( $_REQUEST['action'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only routing check.
				$enabled = ! in_array( $action, array( 'tutor_user_photo_upload', 'tutor_user_photo_remove' ), true );
			} else {
				$enabled = ! is_admin();
			}

			$enabled = $enabled && function_exists( 'bp_core_fetch_avatar' );

			/**
			 * Filters whether BuddyBoss avatars replace Tutor's.
			 *
			 * @since 2.23.1
			 *
			 * @param bool $enabled Whether to substitute avatars.
			 */
			return (bool) apply_filters( 'bb_tutorlms_use_bb_avatars', $enabled );
		}

		/**
		 * Report a profile photo for every user, and remember who was asked about.
		 *
		 * Tutor resolves avatars (`tutor_utils()->get_tutor_avatar()` and
		 * `get_user_avatar_url()`) by reading this meta key and passing the
		 * result to `wp_get_attachment_image_url()`. Returning a non-empty
		 * placeholder here sends both paths into bb_tutorlms_avatar_src()
		 * below, which is what actually supplies the BuddyBoss image — no
		 * template override required.
		 *
		 * @since 2.23.1
		 *
		 * @param mixed  $value     Short-circuit value; null means "read the database".
		 * @param int    $object_id User ID.
		 * @param string $meta_key  Meta key being read.
		 * @param bool   $single    Whether a single value was requested.
		 *
		 * @return mixed
		 */
		public function bb_tutorlms_avatar_meta( $value, $object_id, $meta_key, $single ) {
			if ( '_tutor_profile_photo' !== $meta_key || $this->reading_raw_meta || ! $this->bb_tutorlms_use_bb_avatars() ) {
				return $value;
			}

			$this->avatar_user_id = (int) $object_id;

			return $single ? self::AVATAR_SENTINEL : array( self::AVATAR_SENTINEL );
		}

		/**
		 * Serve the BuddyBoss avatar wherever Tutor renders a profile photo.
		 *
		 * Handles the placeholder from bb_tutorlms_avatar_meta() and real
		 * attachment IDs alike: Tutor's reviewer and instructor queries join
		 * `_tutor_profile_photo` in SQL, which never passes through the meta
		 * filter, so a photo a member uploaded through Tutor would otherwise
		 * surface on instructor dashboards while every other screen shows the
		 * BuddyBoss avatar.
		 *
		 * @since 2.23.1
		 *
		 * @param array|false  $image         Attachment image data, or false.
		 * @param int|string   $attachment_id Attachment ID being resolved.
		 * @param string|int[] $size          Requested image size.
		 *
		 * @return array|false
		 */
		public function bb_tutorlms_avatar_src( $image, $attachment_id, $size = 'thumbnail' ) {
			if ( $this->resolving_avatar || ! $this->bb_tutorlms_use_bb_avatars() ) {
				return $image;
			}

			if ( self::AVATAR_SENTINEL === $attachment_id ) {
				$user_id = $this->avatar_user_id;
			} elseif ( is_numeric( $attachment_id ) ) {
				$user_id = $this->bb_tutorlms_get_photo_owner( (int) $attachment_id );
			} else {
				return $image;
			}

			if ( ! $user_id ) {
				return $image;
			}

			$avatar = $this->bb_tutorlms_get_bb_avatar( $user_id, $this->bb_tutorlms_avatar_type( $size ) );

			return $avatar ? $avatar : $image;
		}

		/**
		 * Map a WordPress image size onto a BuddyBoss avatar type.
		 *
		 * @since 2.23.1
		 *
		 * @param string|int|int[] $size Registered size name, pixel size, or [ width, height ].
		 *
		 * @return string 'thumb' or 'full'.
		 */
		protected function bb_tutorlms_avatar_type( $size ) {
			$thumb_width = function_exists( 'bp_core_avatar_thumb_width' ) ? (int) bp_core_avatar_thumb_width() : 150;

			if ( is_array( $size ) ) {
				$requested = (int) max( array_map( 'intval', $size ) );
			} elseif ( is_numeric( $size ) ) {
				$requested = (int) $size;
			} elseif ( in_array( $size, array( 'thumbnail', 'thumb' ), true ) ) {
				$requested = $thumb_width;
			} else {
				$requested = PHP_INT_MAX;
			}

			return $requested <= $thumb_width ? 'thumb' : 'full';
		}

		/**
		 * The user whose Tutor profile photo an attachment is, if any.
		 *
		 * Tutor stores the uploader as the attachment author and only accepts
		 * the photo while that matches the user (see Tutor's User::delete_photo()),
		 * so author + stored meta identifies it without a reverse meta query.
		 *
		 * @since 2.23.1
		 *
		 * @param int $attachment_id Attachment ID.
		 *
		 * @return int User ID, or 0.
		 */
		protected function bb_tutorlms_get_photo_owner( $attachment_id ) {
			if ( isset( $this->photo_owner_cache[ $attachment_id ] ) ) {
				return $this->photo_owner_cache[ $attachment_id ];
			}

			$this->photo_owner_cache[ $attachment_id ] = 0;

			$attachment = get_post( $attachment_id );

			if ( $attachment instanceof \WP_Post && 'attachment' === $attachment->post_type && $attachment->post_author ) {
				$this->reading_raw_meta = true;
				$stored_photo           = (int) get_user_meta( (int) $attachment->post_author, '_tutor_profile_photo', true );
				$this->reading_raw_meta = false;

				if ( $stored_photo === $attachment_id ) {
					$this->photo_owner_cache[ $attachment_id ] = (int) $attachment->post_author;
				}
			}

			return $this->photo_owner_cache[ $attachment_id ];
		}

		/**
		 * BuddyBoss avatar image data for a user, memoised per request.
		 *
		 * @since 2.23.1
		 *
		 * @param int    $user_id User ID.
		 * @param string $type    'thumb' or 'full'.
		 *
		 * @return array|false [ url, width, height, false ] or false.
		 */
		protected function bb_tutorlms_get_bb_avatar( $user_id, $type ) {
			$key = $user_id . ':' . $type;

			if ( array_key_exists( $key, $this->avatar_cache ) ) {
				return $this->avatar_cache[ $key ];
			}

			$this->resolving_avatar = true;
			$url                    = bp_core_fetch_avatar(
				array(
					'item_id' => $user_id,
					'object'  => 'user',
					'type'    => $type,
					'html'    => false,
				)
			);
			$this->resolving_avatar = false;

			if ( ! $url ) {
				$this->avatar_cache[ $key ] = false;

				return false;
			}

			if ( 'thumb' === $type ) {
				$width  = function_exists( 'bp_core_avatar_thumb_width' ) ? (int) bp_core_avatar_thumb_width() : 150;
				$height = function_exists( 'bp_core_avatar_thumb_height' ) ? (int) bp_core_avatar_thumb_height() : 150;
			} else {
				$width  = function_exists( 'bp_core_avatar_full_width' ) ? (int) bp_core_avatar_full_width() : 300;
				$height = function_exists( 'bp_core_avatar_full_height' ) ? (int) bp_core_avatar_full_height() : 300;
			}

			$this->avatar_cache[ $key ] = array( $url, $width, $height, false );

			return $this->avatar_cache[ $key ];
		}

		/**
		 * Send Tutor's own profile and account URLs to their BuddyBoss equivalents.
		 *
		 * @since 2.4.90
		 * @since 2.23.1 Logged-out visitors are left to Tutor; Tutor 3.x
		 *                    `settings/reset-password` and `settings/social-profile`
		 *                    sub-pages redirect to BuddyBoss settings.
		 */
		public function bb_tutorlms_template_redirect() {
			global $wp;

			if ( ! function_exists( 'bp_core_get_user_domain' ) ) {
				return;
			}

			$dashboard_page = ! empty( $wp->query_vars['tutor_dashboard_page'] ) ? $wp->query_vars['tutor_dashboard_page'] : '';

			// Tutor profile permalinks (/profile/<nicename>/) -> BuddyBoss profile.
			if ( ! empty( $wp->query_vars['tutor_profile_username'] ) ) {
				$username = sanitize_text_field( $wp->query_vars['tutor_profile_username'] );
				$user     = tutor_utils()->get_user_by_login( $username );

				if ( ! $user ) {
					return;
				}

				$is_instructor         = tutor_utils()->is_instructor( $user->ID, true );
				$student_course_url    = bp_core_get_user_domain( $user->ID ) . bb_tutorlms_profile_courses_slug();
				$instructor_course_url = $student_course_url . '/' . bb_tutorlms_profile_instructor_courses_slug();
				$requested_view        = isset( $_GET['view'] ) ? sanitize_key( wp_unslash( $_GET['view'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only, only selects the redirect target.

				if ( $is_instructor && ( '' === $requested_view || 'instructor' === $requested_view ) ) {
					$profile_course_url = $instructor_course_url;
				} else {
					$profile_course_url = $student_course_url;
				}

				wp_safe_redirect( $profile_course_url, 301 );
				exit;
			}

			// The dashboard redirects below are per-user; Tutor shows its login screen to visitors.
			if ( ! is_user_logged_in() ) {
				return;
			}

			$user_domain = bp_core_get_user_domain( bp_loggedin_user_id() );

			/*
			 * 3.x kept a dedicated dashboard profile page; 4.x dropped it and
			 * no longer registers a rewrite rule for it, so the query var is
			 * empty there — match the URL the way Tutor's own old-slug redirect does.
			 */
			$is_my_profile = 'my-profile' === $dashboard_page;

			if ( ! $is_my_profile && ! empty( $wp->request ) ) {
				$my_profile_url = untrailingslashit( tutor_utils()->tutor_dashboard_url( 'my-profile' ) );
				$is_my_profile  = untrailingslashit( home_url( $wp->request ) ) === $my_profile_url;
			}

			if ( $is_my_profile ) {
				wp_safe_redirect( $user_domain, 301 );
				exit;
			}

			if ( ! $dashboard_page ) {
				return;
			}

			$settings_slug = function_exists( 'bp_get_settings_slug' ) ? bp_get_settings_slug() : 'settings';
			$settings_url  = trailingslashit( $user_domain . $settings_slug );

			/*
			 * Account settings tabs that BuddyBoss owns. In 4.x these are query
			 * string tabs on the account page rather than dashboard sub-pages,
			 * and bb_tutorlms_filter_profile_tabs() already removes them from
			 * the UI — this only catches someone arriving by direct link.
			 */
			$owned_tabs = array( 'security', 'social-accounts' );
			$active_tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only, only selects the redirect target.

			if ( 'account' === $dashboard_page && in_array( $active_tab, $owned_tabs, true ) ) {
				wp_safe_redirect( $settings_url, 301 );
				exit;
			}

			// Tutor 3.x: the same tabs were dashboard sub-pages under settings/.
			$owned_sub_pages = array( 'reset-password', 'social-profile' );
			$sub_page        = ! empty( $wp->query_vars['tutor_dashboard_sub_page'] ) ? $wp->query_vars['tutor_dashboard_sub_page'] : '';

			if ( 'settings' === $dashboard_page && in_array( $sub_page, $owned_sub_pages, true ) ) {
				wp_safe_redirect( $settings_url, 301 );
				exit;
			}
		}

		/**
		 * Hide Tutor's profile-completion prompt — BuddyBoss owns profiles.
		 *
		 * @since 2.23.1
		 *
		 * @param mixed $enabled Current option value.
		 *
		 * @return mixed
		 */
		public function bb_tutorlms_disable_profile_completion( $enabled ) {
			return bb_theme_enable_tutorlms_override() ? false : $enabled;
		}

		/**
		 * Never report Tutor's public profile as "private" on the front end.
		 *
		 * Tutor's profile_url() returns "#" for a private layout; with
		 * the BuddyBoss profile standing in for Tutor's (see
		 * bb_tutorlms_template_redirect()) the layout choice has nothing left
		 * to protect, so the link is kept and lands on the BuddyBoss profile.
		 *
		 * @since 2.23.1
		 *
		 * @param mixed $layout Stored layout key.
		 *
		 * @return mixed
		 */
		public function bb_tutorlms_public_profile_layout( $layout ) {
			if ( is_admin() || 'private' !== $layout ) {
				return $layout;
			}

			return 'pp-rectangle';
		}

		/**
		 * Tutor LMS body classes.
		 *
		 * @since 2.4.90
		 * @since 2.23.1 Adds `bb-tutorlms-has-theme-header` (Tutor 4.0.0-4.0.6
		 *                    screens with the header printed in) and
		 *                    `bb-tutorlms-site-shell` (Tutor >= 4.0.7 screens rendered
		 *                    inside the theme header).
		 *
		 * @param array $classes array of body classes.
		 *
		 * @return array
		 */
		public function bb_tutorlms_custom_class( $classes ) {

			$classes[] = 'bb-tutorlms-avatars';

			if ( $this->bb_tutorlms_is_standalone_screen() ) {
				$classes[] = 'bb-tutorlms-has-theme-header';
			}

			if ( $this->bb_tutorlms_is_site_shell_screen() ) {
				$classes[] = 'bb-tutorlms-site-shell';
			}

			return $classes;
		}

		/**
		 * Remove the account settings tabs BuddyBoss already provides.
		 *
		 * The `account` tab is deliberately left in place: Tutor uses it as the
		 * default tab, so removing it leaves the settings screen with nothing selected.
		 *
		 * @since 2.4.90
		 *
		 * @param array $setting_menus array of profile navigation tabs.
		 *
		 * @return array
		 */
		public function bb_tutorlms_filter_profile_tabs( $setting_menus ) {
			if ( ! is_array( $setting_menus ) || ! bb_theme_enable_tutorlms_override() ) {
				return $setting_menus;
			}

			// 4.x keys first, then the 3.x names, so either version is handled.
			$owned_by_buddyboss = array( 'security', 'social-accounts', 'reset_password', 'social-profile' );

			foreach ( $owned_by_buddyboss as $key ) {
				unset( $setting_menus[ $key ] );
			}

			return $setting_menus;
		}

		/**
		 * Filter the tutor lms dashboard navigation.
		 *
		 * Tutor 4.x no longer registers `logout` or `my-profile`, so this is a
		 * no-op there; it is kept for 3.x installs and in case they return.
		 *
		 * @since 2.4.90
		 *
		 * @param array $dashboard_menus array of profile navigations.
		 *
		 * @return array
		 */
		public function bb_tutorlms_filter_dashboard_nav_items( $dashboard_menus ) {

			if ( is_array( $dashboard_menus ) && bb_theme_enable_tutorlms_override() ) {
				unset( $dashboard_menus['logout'], $dashboard_menus['my-profile'] );
			}

			return $dashboard_menus;
		}

		/**
		 * Relabelled Tutor 3.x's dashboard notification drawer. No longer used.
		 *
		 * Tutor 4.x replaced that drawer; the inline script this enqueued
		 * (`bb-tutorlms-custom-js`) had nothing left to target.
		 *
		 * @since 2.4.90
		 * @deprecated 2.23.1
		 */
		public function bb_tutorlms_helper_script() {
			_deprecated_function( __METHOD__, '2.23.1' );
		}
	}
}
