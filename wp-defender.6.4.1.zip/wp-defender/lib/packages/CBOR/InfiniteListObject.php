<?php

declare(strict_types=1);

/*
 * The MIT License (MIT)
 *
 * Copyright (c) 2018-2020 Spomky-Labs
 *
 * This software may be modified and distributed under the terms
 * of the MIT license.  See the LICENSE file for details.
 */

namespace WP_DEFENDER_VENDOR\CBOR;

/**
 * @deprecated Will be removed in v3.0. Please use IndefiniteLengthListObject instead
 */
final class InfiniteListObject extends IndefiniteLengthListObject
{
}
