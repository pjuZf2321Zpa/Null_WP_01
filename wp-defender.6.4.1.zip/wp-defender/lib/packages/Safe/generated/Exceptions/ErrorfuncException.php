<?php
namespace WP_DEFENDER_VENDOR\Safe\Exceptions;

class ErrorfuncException extends \ErrorException implements SafeExceptionInterface
{
    public static function createFromPhpError(): self
    {
        $error = error_get_last();
        return new self($error['message'] ?? 'An error occured', 0, $error['type'] ?? 1);
    }
}
