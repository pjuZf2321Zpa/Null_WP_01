<?php

class Penci_Library_Source extends Elementor\TemplateLibrary\Source_Base {

	public static $data_import_option = 'penci_import_demo_data';

	public function get_id() {
		return 'penci';
	}

	public function get_title() {
		return esc_html__( 'Penci', 'soledad' );
	}

	public function register_data() {
	}

	public function get_items( $args = [] ) {
		return [];
	}

	public function get_item( $template_id ) {
		$templates = $this->get_items();

		return $templates[ $template_id ];
	}


	private function get_template_content( $template_id ) {
		$response = wp_remote_get( add_query_arg( 'id', $template_id, 'https://library.pencidesign.net/wp-json/penci-blocks/v1/templates' ) );

		if ( is_wp_error( $response ) ) {
			return new WP_Error( 'penci_library_request_failed', __( 'The template library could not be reached. Please try again later.', 'soledad' ) );
		}

		if ( ! is_array( $response ) || wp_remote_retrieve_response_code( $response ) < 200 || wp_remote_retrieve_response_code( $response ) >= 300 ) {
			return new WP_Error( 'penci_library_request_failed', __( 'The template library could not be reached. Please try again later.', 'soledad' ) );
		}

		$data = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( JSON_ERROR_NONE !== json_last_error() || ! is_array( $data ) || empty( $data['content'] ) || ! is_array( $data['content'] ) ) {
			return new WP_Error( 'penci_library_invalid_template', __( 'The template library returned invalid template data. Please try again later.', 'soledad' ) );
		}

		return $data;
	}

	public function get_data( array $args, $context = 'display' ) {
		if ( ! is_array( $args ) || ! isset( $args['template_id'] ) ) {
			throw new \Exception( 'Missing template ID' );
		}
		if ( 'update' === $context ) {
			$data = $args['data'];
		} else {
			$data = $this->get_template_content( $args['template_id'] );

			if ( is_wp_error( $data ) ) {
				return $data;
			}

			self::penci_templ_remove_placeholer( $data['content'] );
		}

		if ( empty( $data ) || empty( $data['content'] ) ) {
			throw new \Exception( 'Template does not have any content' );
		}

		$data['content'] = $this->convert_imported_contact_forms( $data['content'] );
		$data['content'] = $this->replace_elements_ids( $data['content'] );
		$data['content'] = $this->process_export_import_content( $data['content'], 'on_import' );


		// After the upload complete, set the elementor upload state back to false
		//Plugin::$instance->uploads_manager->set_elementor_upload_state( false );

		return $data;
	}

	public static function penci_templ_remove_placeholer( &$array ) {
		foreach ( $array as $key => &$value ) {
			if ( is_array( $value ) ) {
				if ( isset( $value['image'] ) && strpos( $value['image']['url'], 'placeholder' ) !== false ) {
					$value['image'] = [
						'url' => ''
					];
				}
				self::penci_templ_remove_placeholer( $value );
			}
		}
	}

	private function convert_imported_contact_forms( $content ) {
		if ( ! $this->has_contact_form_shortcodes( $content ) ) {
			return $content;
		}

		$form_id = $this->get_or_import_wpforms_demo_form();
		if ( ! $form_id ) {
			return $content;
		}

		$replacement_count = 0;
		$replaced = $this->replace_contact_form_shortcodes( $content, $form_id, $replacement_count );

		if ( $replacement_count ) {
			return $replaced;
		}

		return $content;
	}

	/**
	 * Determine whether Elementor content contains an unescaped Contact Form 7 shortcode.
	 *
	 * @param mixed $content Elementor content to inspect.
	 * @return bool
	 */
	private function has_contact_form_shortcodes( $content ) {
		if ( is_array( $content ) ) {
			foreach ( $content as $value ) {
				if ( $this->has_contact_form_shortcodes( $value ) ) {
					return true;
				}
			}

			return false;
		}

		if ( ! is_string( $content ) ) {
			return false;
		}

		$shortcode_pattern = '/' . get_shortcode_regex( array( 'contact-form-7' ) ) . '/s';
		$matches           = array();
		$matched           = preg_match_all( $shortcode_pattern, $content, $matches, PREG_SET_ORDER );

		if ( false === $matched ) {
			return false;
		}

		foreach ( $matches as $match ) {
			if ( $this->is_unescaped_contact_form_shortcode( $match ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Replace unescaped Contact Form 7 shortcodes in Elementor content.
	 *
	 * @param mixed $content Elementor content to update.
	 * @param int    $form_id WPForms form ID.
	 * @param int    $replacement_count Number of shortcodes replaced.
	 * @return mixed
	 */
	private function replace_contact_form_shortcodes( $content, $form_id, &$replacement_count ) {
		if ( is_array( $content ) ) {
			foreach ( $content as $key => $value ) {
				$content[ $key ] = $this->replace_contact_form_shortcodes( $value, $form_id, $replacement_count );
			}

			return $content;
		}

		if ( ! is_string( $content ) ) {
			return $content;
		}

		$shortcode_pattern = '/' . get_shortcode_regex( array( 'contact-form-7' ) ) . '/s';

		$replaced = preg_replace_callback(
			$shortcode_pattern,
			function ( $matches ) use ( $form_id, &$replacement_count ) {
				if ( ! $this->is_unescaped_contact_form_shortcode( $matches ) ) {
					return $matches[0];
				}

				$replacement_count++;

				return '[wpforms id="' . absint( $form_id ) . '"]';
			},
			$content
		);

		return is_string( $replaced ) ? $replaced : $content;
	}

	/**
	 * Check whether a shortcode-regex match is an active, unescaped shortcode.
	 *
	 * @param array $matches Shortcode regex match.
	 * @return bool
	 */
	private function is_unescaped_contact_form_shortcode( $matches ) {
		return empty( $matches[1] ) && empty( $matches[6] );
	}

	/**
	 * Return the importer-managed WPForms form, creating it from the bundled export when needed.
	 *
	 * @return int
	 */
	private function get_or_import_wpforms_demo_form() {
		$data_import_option = get_option( self::$data_import_option, array() );
		$form_id = isset( $data_import_option['wpforms_form_id'] ) ? absint( $data_import_option['wpforms_form_id'] ) : 0;
		if ( $form_id && 'wpforms' === get_post_type( $form_id ) ) {
			return $form_id;
		}

		if ( ! function_exists( 'wpforms' ) || ! function_exists( 'wpforms_encode' ) ) {
			return 0;
		}

		$json_path = PENCI_SOLEDAD_DIR . '/inc/blocks/wpforms.json';
		$json      = is_readable( $json_path ) ? file_get_contents( $json_path ) : false;
		$forms     = $json ? json_decode( $json, true ) : null;

		if ( ! is_array( $forms ) || 1 !== count( $forms ) || empty( $forms[0]['fields'] ) || empty( $forms[0]['settings'] ) || ! is_array( $forms[0]['fields'] ) || ! is_array( $forms[0]['settings'] ) ) {
			return 0;
		}

		$form_data  = $forms[0];
		$form_title = ! empty( $form_data['settings']['form_title'] ) ? sanitize_text_field( $form_data['settings']['form_title'] ) : __( 'Soledad Contact Form', 'penci-soledad-demo-importer' );
		$form_desc  = ! empty( $form_data['settings']['form_desc'] ) ? sanitize_text_field( $form_data['settings']['form_desc'] ) : '';
		$form_id    = wp_insert_post(
			array(
				'post_title'   => wp_slash( $form_title ),
				'post_status'  => 'publish',
				'post_type'    => 'wpforms',
				'post_excerpt' => wp_slash( $form_desc ),
			),
			true
		);
		if ( is_wp_error( $form_id ) || ! $form_id ) {
			return 0;
		}

		$form_id         = absint( $form_id );
		$form_data['id'] = $form_id;
		if ( function_exists( 'wpforms_is_form_data_slashing_enabled' ) && wpforms_is_form_data_slashing_enabled() ) {
			$form_data = wp_slash( $form_data );
		}

		$updated_form = wp_update_post(
			array(
				'ID'           => $form_id,
				'post_content' => wpforms_encode( $form_data ),
			),
			true
		);
		if ( is_wp_error( $updated_form ) || ! $updated_form ) {
			wp_delete_post( $form_id, true );
			return 0;
		}

		$data_import_option['wpforms_form_id'] = $form_id;
		$data_import_option['posts']['wpforms'][ $form_id ] = '';
		update_option( self::$data_import_option, $data_import_option );

		return $form_id;
	}

	public function save_item( $template_data ) {
		return new WP_Error( 'invalid_request', 'Cannot save template to a remote source' );
	}

	public function update_item( $new_data ) {
		return new WP_Error( 'invalid_request', 'Cannot update template to a remote source' );
	}

	public function delete_template( $template_id ) {
		return new WP_Error( 'invalid_request', 'Cannot delete template from a remote source' );
	}


	public function export_template( $template_id ) {
		return new WP_Error( 'invalid_request', 'Cannot export template from a remote source' );
	}
}
