<?php
/**
 * Bootstrap the Soledad theme updater.
 *
 * @package Soledad
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Register the Soledad theme updater.
 *
 * The updater is skipped when the legacy Envato purchase data exists,
 * preventing multiple update systems from running simultaneously.
 *
 * @return void
 */
function penci_soledad_register_updater() {
	$legacy_purchase_data = get_option( 'penci_soledad_purchased_data', array() );

	if ( empty( $legacy_purchase_data ) ) {
		return;
	}

	$updater_file = __DIR__ . '/class-penci-soledad-updater.php';

	if ( ! file_exists( $updater_file ) ) {
		return;
	}

	require_once $updater_file;

	if ( ! class_exists( 'Penci_Soledad_Updater' ) ) {
		return;
	}

	/**
	 * Filters the license data used by the Soledad updater.
	 *
	 * A companion plugin can use this filter to provide license data
	 * without adding license-management UI to the theme.
	 *
	 * @param mixed $license_provider License value, provider object, or null.
	 */
	$license_provider = apply_filters(
		'penci_soledad_updater_license_provider',
		null
	);

	$updater = new Penci_Soledad_Updater( $license_provider );
	$updater->register();
}

add_action( 'after_setup_theme', 'penci_soledad_register_updater', 20 );
