<?php
/**
 * Secure custom-update integration example for the Soledad theme.
 *
 * @package Soledad
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Requests and caches update metadata from the Penci Theme Updater API.
 */
final class Penci_Soledad_Updater {
	const STYLESHEET        = 'soledad';
	const UPDATE_URI        = 'https://updates.pencidesign.net/themes/soledad';
	const LICENSE_OPTION    = 'penci_soledad_purchased_data';
	const CACHE_INDEX       = 'penci_soledad_update_cache_keys';
	const SUCCESS_CACHE_TTL = 300;
	const FAILURE_CACHE_TTL = 30;

	/**
	 * Stores the injected license provider.
	 *
	 * @var callable
	 */
	private $license_provider;

	/**
	 * Stores the API endpoint.
	 *
	 * @var string
	 */
	private $api_url;

	/**
	 * Creates the updater with a site-specific provider and endpoint.
	 *
	 * @param callable|null $license_provider Returns the current site's Soledad license code.
	 * @param string        $api_url          HTTPS endpoint for the Laravel update check.
	 */
	public function __construct( $license_provider = null, $api_url = 'https://updates.pencidesign.net/api/v1/themes/soledad/check' ) {
		$this->license_provider = is_callable( $license_provider ) ? $license_provider : array( $this, 'option_license' );
		$this->api_url          = is_string( $api_url ) ? $api_url : '';
	}

	/**
	 * Registers the official WordPress theme-update hook and safe invalidation paths.
	 *
	 * @return void
	 */
	public function register() {
		add_filter(
			'update_themes_updates.pencidesign.net',
			array( $this, 'filter_update' ),
			10,
			4
		);

		add_action( 'upgrader_process_complete', array( $this, 'clear_cache_after_theme_upgrade' ), 10, 2 );
		add_action( 'update_option_' . self::LICENSE_OPTION, array( $this, 'clear_cache' ), 10, 0 );
		add_action( 'add_option_' . self::LICENSE_OPTION, array( $this, 'clear_cache' ), 10, 0 );
		add_action( 'delete_option_' . self::LICENSE_OPTION, array( $this, 'clear_cache' ), 10, 0 );
		add_action( 'update_site_option_' . self::LICENSE_OPTION, array( $this, 'clear_cache' ), 10, 0 );
		add_action( 'add_site_option_' . self::LICENSE_OPTION, array( $this, 'clear_cache' ), 10, 0 );
		add_action( 'delete_site_option_' . self::LICENSE_OPTION, array( $this, 'clear_cache' ), 10, 0 );
		add_action( 'admin_post_penci_soledad_clear_update_cache', array( $this, 'clear_cache_from_admin' ) );
	}

	/**
	 * Supplies WordPress with an available Soledad update, or preserves its original value.
	 *
	 * @param array|false $update            Existing update information from WordPress.
	 * @param array       $theme_data        Parsed theme header data.
	 * @param string      $theme_stylesheet  Theme stylesheet directory name.
	 * @param array       $locales           Requested locales; retained for the hook contract.
	 * @return array|false
	 */
	public function filter_update( $update, $theme_data, $theme_stylesheet, $locales ) {
		unset( $locales );

		if ( self::STYLESHEET !== $theme_stylesheet ) {
			return $update;
		}

		$installed_version = $this->installed_version( $theme_data, $theme_stylesheet );
		$license           = $this->license();
		$origin            = $this->site_origin();

		if ( ! $installed_version || ! $license || ! $origin || ! $this->is_https_url( $this->api_url ) ) {
			return $update;
		}

		$cache_key = $this->cache_key( $installed_version, $license, $origin );
		$cached    = get_site_transient( $cache_key );
		if ( is_array( $cached ) && isset( $cached['state'] ) ) {
			if ( 'update' === $cached['state'] ) {
				$cached_update = $this->update_from_payload( $cached );

				return $cached_update ? $cached_update : $update;
			}

			return $update;
		}

		$payload = $this->request_update( $installed_version, $license, $origin );
		if ( ! is_array( $payload ) ) {
			$this->cache( $cache_key, array( 'state' => 'failure' ), self::FAILURE_CACHE_TTL );

			return $update;
		}

		if ( ! $payload['update_available'] ) {
			$this->cache( $cache_key, array( 'state' => 'no_update' ), self::SUCCESS_CACHE_TTL );

			return $update;
		}

		$this->cache( $cache_key, $payload, self::SUCCESS_CACHE_TTL );

		$wordpress_update = $this->update_from_payload( $payload );

		return $wordpress_update ? $wordpress_update : $update;
	}

	/**
	 * Clears all known updater cache entries after a Soledad upgrade.
	 *
	 * @param object $upgrader   WordPress upgrader instance.
	 * @param array  $hook_extra Upgrade context supplied by WordPress.
	 * @return void
	 */
	public function clear_cache_after_theme_upgrade( $upgrader, $hook_extra ) {
		if ( ! is_array( $hook_extra ) || 'update' !== ( $hook_extra['action'] ?? '' ) || 'theme' !== ( $hook_extra['type'] ?? '' ) ) {
			return;
		}
		if ( isset( $upgrader->result ) && ( false === $upgrader->result || is_wp_error( $upgrader->result ) ) ) {
			return;
		}

		$themes = array();
		if ( isset( $hook_extra['themes'] ) && is_array( $hook_extra['themes'] ) ) {
			$themes = $hook_extra['themes'];
		} elseif ( isset( $hook_extra['theme'] ) && is_string( $hook_extra['theme'] ) ) {
			$themes = array( $hook_extra['theme'] );
		}

		if ( in_array( self::STYLESHEET, $themes, true ) ) {
			$this->clear_cache();
		}
	}

	/**
	 * Clears tracked network transients without flushing unrelated site cache.
	 *
	 * @return void
	 */
	public function clear_cache() {
		$keys = get_site_transient( self::CACHE_INDEX );
		if ( is_array( $keys ) ) {
			foreach ( $keys as $key ) {
				if ( is_string( $key ) && 0 === strpos( $key, 'penci_soledad_update_' ) ) {
					delete_site_transient( $key );
				}
			}
		}

		delete_site_transient( self::CACHE_INDEX );
	}

	/**
	 * Handles the explicit, capability-protected troubleshooting cache clear action.
	 *
	 * @return void
	 */
	public function clear_cache_from_admin() {
		if ( ! current_user_can( 'update_themes' ) ) {
			wp_die( esc_html__( 'You are not allowed to clear the Soledad update cache.', 'penci-soledad-updater' ), '', array( 'response' => 403 ) );
		}

		check_admin_referer( 'penci_soledad_clear_update_cache' );
		$this->clear_cache();

		$redirect = wp_get_referer();
		wp_safe_redirect( $redirect ? $redirect : admin_url( 'themes.php' ) );
		exit;
	}

	/**
	 * Reads the documented option without exposing its value.
	 *
	 * @return string
	 */
	private function option_license() {
		$license = get_option( self::LICENSE_OPTION, array() );

		$license_key = is_array( $license ) && isset( $license['purchase_code'] ) ? $license['purchase_code'] : '';

		return is_string( $license_key ) ? $license_key : '';
	}

	/**
	 * Resolves the current license code through the configured provider.
	 *
	 * @return string
	 */
	private function license() {
		try {
			$license = call_user_func( $this->license_provider );
		} catch ( Throwable $exception ) {
			return '';
		}

		if ( ! $this->is_safe_string( $license, 150 ) ) {
			return '';
		}

		return trim( $license );
	}

	/**
	 * Reads a validated installed version from WordPress theme metadata.
	 *
	 * @param array  $theme_data       Parsed theme header data.
	 * @param string $theme_stylesheet Theme stylesheet directory name.
	 * @return string
	 */
	private function installed_version( $theme_data, $theme_stylesheet ) {
		$version = is_array( $theme_data ) && isset( $theme_data['Version'] ) ? $theme_data['Version'] : '';
		if ( ! $this->is_safe_version( $version ) ) {
			$theme   = wp_get_theme( $theme_stylesheet );
			$version = $theme->get( 'Version' );
		}

		return $this->is_safe_version( $version ) ? $version : '';
	}

	/**
	 * Normalizes the current WordPress site origin for the API request.
	 *
	 * @return string
	 */
	private function site_origin() {
		$parts = wp_parse_url( home_url( '/' ) );
		if ( ! is_array( $parts ) || empty( $parts['host'] ) || empty( $parts['scheme'] ) || ! in_array( strtolower( $parts['scheme'] ), array( 'http', 'https' ), true ) ) {
			return '';
		}

		$host = strtolower( $parts['host'] );
		if ( 0 === strpos( $host, 'www.' ) ) {
			$host = substr( $host, 4 );
		}
		if ( ! preg_match( '/\A[a-z0-9.-]+\z/', $host ) || false === strpos( $host, '.' ) ) {
			return '';
		}

		$origin = strtolower( $parts['scheme'] ) . '://' . $host;
		if ( isset( $parts['port'] ) && ( ( 'https' === $parts['scheme'] && 443 !== (int) $parts['port'] ) || ( 'http' === $parts['scheme'] && 80 !== (int) $parts['port'] ) ) ) {
			$origin .= ':' . (int) $parts['port'];
		}

		return $origin;
	}

	/**
	 * Derives a privacy-safe network transient key.
	 *
	 * @param string $installed_version Installed Soledad version.
	 * @param string $license           Current site license.
	 * @param string $origin            Normalized site origin.
	 * @return string
	 */
	private function cache_key( $installed_version, $license, $origin ) {
		$fingerprint = hash_hmac( 'sha256', $license, wp_salt( 'auth' ) );
		$material    = self::STYLESHEET . '|' . $installed_version . '|' . $origin . '|' . $fingerprint;

		return 'penci_soledad_update_' . substr( hash_hmac( 'sha256', $material, wp_salt( 'nonce' ) ), 0, 40 );
	}

	/**
	 * Stores a sanitized updater result and tracks its transient key.
	 *
	 * @param string $cache_key Cache key containing hashes only.
	 * @param array  $value     Sanitized response state.
	 * @param int    $ttl       Bounded transient lifetime.
	 * @return void
	 */
	private function cache( $cache_key, $value, $ttl ) {
		set_site_transient( $cache_key, $value, $ttl );

		$keys   = get_site_transient( self::CACHE_INDEX );
		$keys   = is_array( $keys ) ? $keys : array();
		$keys   = array_values( array_unique( array_filter( $keys, 'is_string' ) ) );
		$keys[] = $cache_key;
		$keys   = array_slice( array_values( array_unique( $keys ) ), -20 );
		set_site_transient( self::CACHE_INDEX, $keys, self::SUCCESS_CACHE_TTL );
	}

	/**
	 * Posts the bounded update-check request and decodes its JSON response.
	 *
	 * @param string $installed_version Installed Soledad version.
	 * @param string $license           Current site license.
	 * @param string $origin            Normalized site origin.
	 * @return array|null
	 */
	private function request_update( $installed_version, $license, $origin ) {
		$body = wp_json_encode(
			array(
				'theme'             => self::STYLESHEET,
				'code'              => $license,
				'domain'            => $origin,
				'installed_version' => $installed_version,
				'wordpress_version' => get_bloginfo( 'version' ),
				'php_version'       => PHP_VERSION,
				'locale'            => function_exists( 'determine_locale' ) ? determine_locale() : get_locale(),
			)
		);
		if ( ! is_string( $body ) ) {
			return null;
		}

		$response = wp_remote_post(
			$this->api_url,
			array(
				'timeout'             => 5,
				'redirection'         => 0,
				'sslverify'           => true,
				'reject_unsafe_urls'  => true,
				'limit_response_size' => 16384,
				'headers'             => array(
					'Accept'       => 'application/json',
					'Content-Type' => 'application/json; charset=utf-8',
				),
				'body'                => $body,
			)
		);
		if ( is_wp_error( $response ) || 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
			return null;
		}

		$decoded = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( JSON_ERROR_NONE !== json_last_error() || ! is_array( $decoded ) ) {
			return null;
		}

		return $this->validated_payload( $decoded );
	}

	/**
	 * Validates and whitelists the API data that can enter the cache or update UI.
	 *
	 * @param array $payload API response or cached response.
	 * @return array|null
	 */
	private function validated_payload( $payload ) {
		if ( self::STYLESHEET !== ( $payload['theme'] ?? '' ) || ! isset( $payload['update_available'] ) || ! is_bool( $payload['update_available'] ) || ! $this->is_safe_version( $payload['version'] ?? '' ) ) {
			return null;
		}

		if ( ! $payload['update_available'] ) {
			return array(
				'state'            => 'no_update',
				'update_available' => false,
			);
		}

		if ( ! $this->is_https_url( $payload['package'] ?? '' ) || ! $this->is_https_url( $payload['details_url'] ?? '' ) || ! $this->is_safe_string( $payload['tested'] ?? '', 50 ) || ! $this->is_safe_string( $payload['requires_php'] ?? '', 50 ) ) {
			return null;
		}

		return array(
			'state'            => 'update',
			'update_available' => true,
			'theme'            => self::STYLESHEET,
			'version'          => $payload['version'],
			'package'          => $payload['package'],
			'details_url'      => $payload['details_url'],
			'tested'           => $payload['tested'],
			'requires_php'     => $payload['requires_php'],
		);
	}

	/**
	 * Validates the supported Soledad version grammar.
	 *
	 * Builds only the officially documented dynamic-hook fields.
	 *
	 * @param array $payload Validated update payload.
	 * @return array|null
	 */
	private function update_from_payload( $payload ) {
		$payload = $this->validated_payload( $payload );
		if ( ! is_array( $payload ) || 'update' !== $payload['state'] ) {
			return null;
		}

		return array(
			'id'           => self::UPDATE_URI,
			'theme'        => self::STYLESHEET,
			'version'      => $payload['version'],
			'url'          => $payload['details_url'],
			'package'      => $payload['package'],
			'tested'       => $payload['tested'],
			'requires_php' => $payload['requires_php'],
		);
	}

	/**
	 * Validates a bounded HTTPS endpoint or package URL.
	 *
	 * @param mixed $value Candidate version.
	 * @return bool
	 */
	private function is_safe_version( $value ) {
		return $this->is_safe_string( $value, 50 ) && 1 === preg_match( '/\A\d+\.\d+(?:\.\d+)?(?:-[0-9A-Za-z]+(?:\.[0-9A-Za-z]+)*)?\z/', $value );
	}

	/**
	 * Validates a bounded HTTPS endpoint or package URL.
	 *
	 * @param mixed $value Candidate URL.
	 * @return bool
	 */
	private function is_https_url( $value ) {
		if ( ! $this->is_safe_string( $value, 2048 ) ) {
			return false;
		}

		$parts = wp_parse_url( $value );

		return is_array( $parts ) && isset( $parts['scheme'], $parts['host'] ) && 'https' === strtolower( $parts['scheme'] ) && '' !== $parts['host'] && ! isset( $parts['user'], $parts['pass'] );
	}

	/**
	 * Validates a bounded scalar string without control characters.
	 *
	 * @param mixed $value Candidate scalar value.
	 * @param int   $max   Maximum byte length.
	 * @return bool
	 */
	private function is_safe_string( $value, $max ) {
		return is_string( $value ) && '' !== trim( $value ) && strlen( $value ) <= $max && 1 !== preg_match( '/[\x00-\x1F\x7F]/', $value );
	}
}
