<?php

class TwitterSettingPages {
	function __construct() {
		if ( ! function_exists( 'sb_twitter_feed_init' ) ) {
			add_action( 'init', [ $this, 'sb_twitter_feed' ] );
		}
	}

	public function sb_twitter_feed() {
		if ( ! is_admin() || ! current_user_can( 'manage_options' ) ) {
			return;
		}

		if ( ! empty( $_GET['page'] ) && sanitize_text_field( $_GET['page'] ) === 'custom-twitter-feeds' && is_array( $_GET ) ) {

			$nonce = isset( $_REQUEST['nonce'] ) && $_REQUEST['nonce'] ? $_REQUEST['nonce'] : '';
			
			if ( wp_verify_nonce( $nonce, 'custom-twitter-feeds' ) ) {

				$data = array();
				foreach ( wp_unslash( $_GET ) as $key => $value ) { // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
					if ( is_scalar( $value ) ) {
						$data[ sanitize_key( $key ) ] = sanitize_text_field( (string) $value );
					}
				}
				update_option( 'penci_options[penci_twitter]', $data );

				// Redirect
				$redirect = admin_url( 'admin.php?page=soledad_integrations&tab=twitter' );
				wp_redirect( $redirect );

				exit;
			}
		}
	}

	/**
	 * OAuth start URL.
	 *
	 * @return string
	 */
	public static function connect_url() {
		$nonce = wp_create_nonce( 'custom-twitter-feeds' );

		return 'https://api.smashballoon.com/twitter-login.php?return_uri=' . admin_url( 'admin.php?page=custom-twitter-feeds&nonce=' . $nonce );
	}

	/**
	 * Connection state for the Integrations page.
	 *
	 * @return array
	 */
	public static function get_state() {
		$token = get_option( 'penci_options[penci_twitter]' );

		return array(
			'id'         => 'twitter',
			'name'       => 'X (Twitter)',
			'available'  => ! function_exists( 'sb_twitter_feed_init' ),
			'connected'  => is_array( $token ) && ! empty( $token['screen_name'] ),
			'account'    => is_array( $token ) && ! empty( $token['screen_name'] ) ? (string) $token['screen_name'] : '',
			'error'      => is_array( $token ) && ! empty( $token['error'] ),
			'connectUrl' => self::connect_url(),
		);
	}

	/**
	 * Forget the stored token.
	 */
	public static function disconnect() {
		delete_option( 'penci_options[penci_twitter]' );
	}
}

new TwitterSettingPages();
