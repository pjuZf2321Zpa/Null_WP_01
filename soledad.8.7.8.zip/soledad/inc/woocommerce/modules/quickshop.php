<?php

class penci_product_quickshop {
	function __construct() {
		add_action( 'wp_ajax_penci_quick_shop', array( $this, 'quick_shop' ) );
		add_action( 'wp_ajax_nopriv_penci_quick_shop', array( $this, 'quick_shop' ) );
		add_action( 'penci_loop_product_image', array( $this, 'quick_shop_wrapper' ) );
	}

	public function quick_shop( $id = false ) {
		check_ajax_referer( 'ajax-nonce', 'nonce' );

		if ( isset( $_GET['id'] ) ) {
			$id = absint( $_GET['id'] );
		}
		if ( ! $id || 'product' !== get_post_type( $id ) || 'publish' !== get_post_status( $id ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid product.', 'soledad' ) ), 404 );
		}

		global $post;

		$args = array( 'post__in' => array( $id ), 'post_type' => 'product', 'posts_per_page' => 1 );

		$quick_posts = get_posts( $args );

		foreach ( $quick_posts as $post ) :
			setup_postdata( $post );
			woocommerce_template_single_add_to_cart();
		endforeach;

		wp_reset_postdata();

		die();
	}

	function quick_shop_wrapper() {
		?>
        <div class="quick-shop-wrapper">
            <div class="quick-shop-close"><a href="#"
                                             rel="nofollow noopener"><?php penci_woo_translate_text( 'penci_woo_trans_close' ); ?></a>
            </div>
            <div class="quick-shop-form" data-pid="<?php echo get_the_ID(); ?>"></div>
        </div>
		<?php
	}
}

$penci_product_quickshop = new penci_product_quickshop();
