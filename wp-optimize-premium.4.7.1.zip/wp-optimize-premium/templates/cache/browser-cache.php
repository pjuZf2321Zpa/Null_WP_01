<?php if (!defined('ABSPATH')) die('No direct access allowed'); ?>

<div class="wpo_section wpo_group">

	<h3 class="wpo-first-child"><?php esc_html_e('Browser static file caching settings (via headers)', 'wp-optimize');?></h3>
	<p>
		<?php echo esc_html__("Browser static file caching uses HTTP response headers to advise a visitor's browser to cache non-changing files for a while, so that it doesn't attempt to retrieve them upon every visit.", 'wp-optimize').' '.sprintf('<a href="%s" target="_blank">%s</a>', esc_url($info_link), esc_html__('Follow this link to get more information.', 'wp-optimize')); ?>
	</p>

	<div id="browser_cache_control_panel">
		<?php echo $browser_cache_control_panel; // phpcs:ignore WordPress.Security.EscapeOutput -- Output is already escaped ?>
	</div>
</div><!-- END .wpo_section -->
