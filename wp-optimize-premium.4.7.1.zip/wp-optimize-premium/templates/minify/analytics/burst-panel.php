<?php
if (!defined('ABSPATH')) die('No direct access allowed');

/**
 * Analytics tab: the "Enable Burst" action shown under the cards when Burst is selected.
 * Shared by the free and premium tab templates.
 *
 * @var array $state          Output of WPO_Analytics_Provider::get_state()
 * @var bool  $burst_selected Whether Burst is the selected provider
 */
$burst_button_label = ('inactive' === $state['burst_status']) ? __('Activate Burst', 'wp-optimize') : __('Enable Burst', 'wp-optimize');
if ('active' === $state['burst_status']) $burst_button_label = __('Use Burst Statistics', 'wp-optimize');
?>
<div class="wpo-analytics__panel" id="wpo-analytics-burst-panel" <?php echo $burst_selected ? '' : 'style="display:none"'; ?>>
	<div class="wpo-analytics__action">
		<button type="button" class="button button-primary" id="wpo-analytics-enable-burst" <?php disabled(!$state['can_enable_burst']); ?> data-label="<?php echo esc_attr($burst_button_label); ?>" data-steps="<?php echo esc_attr(implode(',', $state['steps'])); ?>">
			<?php echo esc_html($burst_button_label); ?>
		</button>
		<p class="wpo-analytics__help">
			<?php if ($state['can_enable_burst']) : ?>
				<?php if ('active' === $state['burst_status']) : ?>
					<?php esc_html_e('Burst Statistics is already active on this site.', 'wp-optimize'); ?>
					<?php esc_html_e('This only records Burst as your analytics tool and turns off the Google Analytics script.', 'wp-optimize'); ?>
				<?php elseif ('inactive' === $state['burst_status']) : ?>
					<?php esc_html_e('Burst Statistics is already installed.', 'wp-optimize'); ?>
					<?php esc_html_e('This activates it with recommended settings, without a setup wizard.', 'wp-optimize'); ?>
					<?php esc_html_e('You can deactivate it anytime.', 'wp-optimize'); ?>
				<?php else : ?>
					<?php esc_html_e('Installs the free Burst Statistics plugin from WordPress.org and switches it on with recommended settings, without a setup wizard.', 'wp-optimize'); ?>
					<?php esc_html_e('You can deactivate it anytime.', 'wp-optimize'); ?>
				<?php endif; ?>
			<?php else : ?>
				<?php echo esc_html($state['enable_burst_blocker']); ?>
				<a href="<?php echo esc_url($state['burst_wporg_url']); ?>" target="_blank" rel="noopener"><?php esc_html_e('Get Burst Statistics on WordPress.org', 'wp-optimize'); ?></a>
			<?php endif; ?>
		</p>
	</div>
</div>
