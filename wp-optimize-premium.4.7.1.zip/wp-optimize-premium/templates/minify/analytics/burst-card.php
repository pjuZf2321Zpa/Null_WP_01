<?php
if (!defined('ABSPATH')) die('No direct access allowed');

/**
 * Analytics tab: the Burst Statistics radio card. Shared by the free and premium tab templates.
 *
 * @var array $state          Output of WPO_Analytics_Provider::get_state()
 * @var bool  $burst_selected Whether Burst is the selected provider
 */
?>
<?php // Both radios use the GA form as form owner, because browsers only group radios with the same name and form owner. The form only exists in Premium; in free both radios have no owner. A Burst choice is applied by the "Enable Burst" flow: analytics.js clears need_saving, so another tab's "Save settings" does not post it. ?>
<label class="wpo-analytics-card <?php echo $burst_selected ? 'wpo-analytics-card--selected' : ''; ?>" for="wpo_analytics_provider_burst">
	<input type="radio" name="enable_analytics" id="wpo_analytics_provider_burst" value="false" form="analytics-form" <?php checked($burst_selected); ?>>
	<span class="wpo-analytics-card__body">
		<span class="wpo-analytics-card__title">
			<?php esc_html_e('Burst Statistics', 'wp-optimize'); ?>
			<span class="wpo-analytics-card__badge wpo-analytics-card__badge--recommended"><?php esc_html_e('Recommended', 'wp-optimize'); ?></span>
		</span>
		<span class="wpo-analytics-card__subtitle"><?php esc_html_e('Self-hosted analytics by Burst, part of Team Updraft', 'wp-optimize'); ?></span>
		<ul class="wpo-analytics-card__list wpo-analytics-card__list--checks">
			<li><?php esc_html_e('No account or tracking ID needed', 'wp-optimize'); ?></li>
			<li><?php esc_html_e('Data stays in your own WordPress database', 'wp-optimize'); ?></li>
			<li><?php esc_html_e('Lightweight script, no third-party requests', 'wp-optimize'); ?></li>
			<li><?php esc_html_e('Dashboard right inside WordPress', 'wp-optimize'); ?></li>
		</ul>
	</span>
</label>
