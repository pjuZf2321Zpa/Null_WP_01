<?php
if (!defined('ABSPATH')) die('No direct access allowed');

/**
 * Analytics tab: the panel shown when Burst Statistics is running.
 * Shared by the free and premium tab templates.
 *
 * @var array $state                 Output of WPO_Analytics_Provider::get_state()
 * @var bool  $show_switch_to_google Whether the "Switch to Google Analytics" link is offered (Premium only)
 */
?>
<div class="wpo-analytics__success" id="wpo-analytics-burst-success" <?php echo $state['show_burst_success'] ? '' : 'style="display:none"'; ?>>
	<div class="wpo-analytics__status wpo-analytics__status--stacked">
		<span class="wpo-analytics__status-icon dashicons dashicons-yes"></span>
		<div class="wpo-analytics__status-text">
			<h3><?php esc_html_e('Burst Statistics is active', 'wp-optimize'); ?></h3>
			<p><?php esc_html_e('Tracking has started.', 'wp-optimize'); ?> <?php esc_html_e('Your first visits show up in the dashboard within a few minutes.', 'wp-optimize'); ?></p>
		</div>
	</div>
	<div class="wpo-analytics__tiles">
		<div class="wpo-analytics__tile">
			<span class="wpo-analytics__tile-label"><?php esc_html_e('Tracking method', 'wp-optimize'); ?></span>
			<span class="wpo-analytics__tile-value" id="wpo-analytics-tracking-method"><?php echo esc_html($state['tracking_method']); ?></span>
		</div>
		<div class="wpo-analytics__tile">
			<span class="wpo-analytics__tile-label"><?php esc_html_e('Data storage', 'wp-optimize'); ?></span>
			<span class="wpo-analytics__tile-value"><?php esc_html_e('Your WordPress database', 'wp-optimize'); ?></span>
		</div>
		<div class="wpo-analytics__tile">
			<span class="wpo-analytics__tile-label"><?php esc_html_e('Configuration', 'wp-optimize'); ?></span>
			<span class="wpo-analytics__tile-value"><?php esc_html_e('Recommended defaults', 'wp-optimize'); ?></span>
		</div>
	</div>
	<div class="wpo-analytics__success-actions">
		<a class="button button-primary" href="<?php echo esc_url($state['burst_dashboard_url']); ?>"><?php esc_html_e('Open Burst dashboard', 'wp-optimize'); ?></a>
		<a class="button" href="<?php echo esc_url($state['burst_settings_url']); ?>"><?php esc_html_e('Burst settings', 'wp-optimize'); ?></a>
		<?php if (!empty($show_switch_to_google)) : ?>
			<a href="#" class="wpo-analytics__switch-to-google" id="wpo-analytics-switch-to-google"><?php esc_html_e('Switch to Google Analytics', 'wp-optimize'); ?></a>
		<?php endif; ?>
	</div>
</div>
