<?php
if (!defined('ABSPATH')) die('No direct access allowed');

/**
 * Minify > Analytics tab, premium version: choose between Burst Statistics (default)
 * and Google Analytics. Replaces src/templates/minify/analytics-settings-tab.php in the premium build.
 *
 * @var array $state Output of WPO_Analytics_Provider::get_state()
 */
$burst_selected = ('burst' === $state['selected']);
$ga_method_label = ('minimal-analytics' === $state['ga_method']) ? __('Minimal Analytics', 'wp-optimize') : __('Gtag.js', 'wp-optimize');
?>
<div class="wpo_section wpo_group wpo-analytics" id="wpo-analytics">

	<p class="wpo-analytics__intro">
		<?php esc_html_e('See how many people visit your site without slowing it down.', 'wp-optimize'); ?>
		<?php esc_html_e('Pick the analytics tool you want to use.', 'wp-optimize'); ?>
		<?php esc_html_e('Both are included in your Premium plan.', 'wp-optimize'); ?>
	</p>

	<!-- Provider choice -->
	<div class="wpo-analytics__choice" id="wpo-analytics-choice" <?php echo $state['show_burst_success'] ? 'style="display:none"' : ''; ?>>
		<div class="wpo-analytics__cards">
			<label class="wpo-analytics-card <?php echo $burst_selected ? '' : 'wpo-analytics-card--selected'; ?>" for="wpo_analytics_provider_google">
				<input type="radio" name="enable_analytics" id="wpo_analytics_provider_google" value="true" form="analytics-form" <?php checked(!$burst_selected); ?>>
				<span class="wpo-analytics-card__body">
					<span class="wpo-analytics-card__title"><?php esc_html_e('Google Analytics', 'wp-optimize'); ?></span>
					<span class="wpo-analytics-card__subtitle"><?php esc_html_e('Connect your existing Google Analytics property', 'wp-optimize'); ?></span>
					<ul class="wpo-analytics-card__list">
						<li><?php esc_html_e('Requires a Google account and tracking ID', 'wp-optimize'); ?></li>
						<li><?php esc_html_e('Visitor data is processed by Google', 'wp-optimize'); ?></li>
						<li><?php esc_html_e('Serve Gtag.js locally, or use Minimal Analytics', 'wp-optimize'); ?></li>
						<li><?php esc_html_e('Usually needs a cookie consent banner', 'wp-optimize'); ?></li>
					</ul>
				</span>
			</label>

			<?php WP_Optimize()->include_template('minify/analytics/burst-card.php', false, array('state' => $state, 'burst_selected' => $burst_selected)); ?>
		</div>

		<?php WP_Optimize()->include_template('minify/analytics/burst-panel.php', false, array('state' => $state, 'burst_selected' => $burst_selected)); ?>

		<!-- Google Analytics: existing settings, saved through the regular minify settings flow -->
		<div class="wpo-analytics__panel" id="wpo-analytics-google-panel" <?php echo $burst_selected ? 'style="display:none"' : ''; ?>>
			<?php if ($state['ga_active']) : ?>
			<div class="wpo-analytics__status">
				<span class="wpo-analytics__status-icon dashicons dashicons-yes"></span>
				<div class="wpo-analytics__status-text">
					<h3><?php esc_html_e('Google Analytics is active', 'wp-optimize'); ?></h3>
					<p>
						<?php /* translators: %s: analytics script name (Gtag.js or Minimal Analytics) */ ?>
						<?php echo esc_html(sprintf(__('%s is served from your own server.', 'wp-optimize'), $ga_method_label)); ?>
						<?php esc_html_e('Visit your Google Analytics property to see the data.', 'wp-optimize'); ?>
					</p>
				</div>
				<a class="button wpo-analytics__status-action" href="<?php echo esc_url($state['google_analytics_url']); ?>" target="_blank" rel="noopener"><?php esc_html_e('Open Google Analytics', 'wp-optimize'); ?></a>
			</div>
			<?php endif; ?>
			<!-- Shown when Burst is active while Google is selected; also revealed by the JS once "Enable Burst" has run -->
			<div class="notice notice-warning inline wpo-analytics__notice" id="wpo-analytics-burst-running" <?php echo ('active' === $state['burst_status']) ? '' : 'style="display:none"'; ?>>
				<p>
					<?php esc_html_e('Burst Statistics is still tracking visitors.', 'wp-optimize'); ?>
					<?php esc_html_e('Deactivate it to avoid running two trackers.', 'wp-optimize'); ?>
					<a href="<?php echo esc_url(self_admin_url('plugins.php')); ?>"><?php esc_html_e('Open the Plugins screen', 'wp-optimize'); ?></a>
				</p>
			</div>
			<form id="analytics-form">
				<div id="wpo_settings_warnings"></div>
				<div class="wpo-fieldgroup wpo-show">
					<table class="form-table">
						<tbody>
							<tr>
								<th scope="row"><label for="tracking_id"><?php esc_html_e('Tracking ID', 'wp-optimize'); ?></label></th>
								<td>
									<input name="tracking_id" id="tracking_id" type="text" value="<?php echo esc_attr($state['ga_tracking_id']); ?>" placeholder="G-XXXXXXXXXX">
									<p class="description"><a href="https://support.google.com/analytics/answer/9539598" target="_blank"><?php esc_html_e('Where to find my Google Analytics tracking ID?', 'wp-optimize'); ?></a></p>
								</td>
							</tr>
							<tr>
								<th scope="row"><label for="analytics_method"><?php esc_html_e('Analytics script', 'wp-optimize'); ?></label></th>
								<td>
									<select name="analytics_method" id="analytics_method" class="wpo-select2">
										<option value="gtagv4" <?php selected($state['ga_method'], 'gtagv4'); ?>><?php esc_html_e('Gtag.js v4 (~116KB GZipped)', 'wp-optimize'); ?></option>
										<option value="minimal-analytics" <?php selected($state['ga_method'], 'minimal-analytics'); ?>><?php esc_html_e('Minimal Analytics.js (~3KB GZipped)', 'wp-optimize'); ?></option>
									</select>
									<p class="description"><a href="<?php echo esc_url(WP_Optimize()->maybe_add_affiliate_params('https://teamupdraft.com/documentation/wp-optimize/topics/general/faqs/how-to-set-up-google-analytics-in-wp-optimize/#which-one-should-i-use-google-analytics-or-minimal-analytics')); ?>" target="_blank"><?php esc_html_e('Which analytics script should I use?', 'wp-optimize'); ?></a></p>
								</td>
							</tr>
						</tbody>
					</table>
				</div>
				<div class="wpo-save-btn-container">
					<input class="wp-optimize-save-minify-settings button button-primary" type="submit" value="<?php esc_attr_e('Save settings', 'wp-optimize'); ?>">
					<img class="wpo_spinner" src="<?php echo esc_url(admin_url('images/spinner-2x.gif')); // phpcs:ignore PluginCheck.CodeAnalysis.ImageFunctions.NonEnqueuedImage -- N/A ?>" alt="...">
					<span class="save-done dashicons dashicons-yes display-none"></span>
					<?php if ($state['ga_enabled']) : ?>
						<a href="#" class="wpo-analytics__turn-off" id="wpo-analytics-turn-off"><?php esc_html_e('Turn analytics off', 'wp-optimize'); ?></a>
					<?php endif; ?>
				</div>
			</form>
		</div>
	</div>

	<?php WP_Optimize()->include_template('minify/analytics/burst-success.php', false, array('state' => $state, 'show_switch_to_google' => true)); ?>
</div>
