<?php

use Updraftplus\Wp_Optimize\Wizard\Installer\Installer;

if (!defined('ABSPATH')) die('No direct access allowed');

// Registers the autoloader for the Updraftplus\Wp_Optimize\Wizard\* classes (a no-op when WPO_Onboarding already did).
require_once(WPO_PLUGIN_MAIN_PATH . 'vendor/team-updraft/lib-onboarding-wizard/autoload.php');

/**
 * Analytics provider choice for the Minify > Analytics tab.
 *
 * The user picks Burst Statistics (self-hosted, free) or Google Analytics (Premium).
 * Burst is installed/activated through the Installer class shipped with
 * lib-onboarding-wizard, wrapped here so it can be driven from the settings page
 * (the library only registers its own REST endpoints while the wizard is active).
 */
class WPO_Analytics_Provider {

	/**
	 * Provider values. There is no stored choice: the `enable_analytics` minify setting,
	 * saved through the Analytics tab's radio cards, decides which provider is in use.
	 */
	const PROVIDER_BURST = 'burst';

	const PROVIDER_GOOGLE = 'google';

	/**
	 * Slug used by the Installer (folder name, must exist in the library's plugins.json)
	 */
	const BURST_SLUG = 'burst-statistics';

	/**
	 * Minimum PHP version of the lib-onboarding-wizard Installer (typed properties); loading it below that is a parse error.
	 * Burst's own requirements are not mirrored here: the download step checks them live from WordPress.org.
	 */
	const INSTALLER_REQUIRED_PHP_VERSION = '7.4';

	const CALLER_SLUG = 'wp-optimize';

	const BURST_WPORG_URL = 'https://wordpress.org/plugins/burst-statistics/';

	const GOOGLE_ANALYTICS_URL = 'https://analytics.google.com/';

	/**
	 * Burst status values
	 */
	const STATUS_ACTIVE = 'active';

	const STATUS_INACTIVE = 'inactive';

	const STATUS_NOT_INSTALLED = 'not_installed';

	/**
	 * Install steps, in order
	 */
	const STEP_DOWNLOAD = 'download';

	const STEP_ACTIVATE = 'activate';

	const STEP_CONFIGURE = 'configure';

	/**
	 * Burst status for this request, detected once (see get_burst_status()); null until detected
	 *
	 * @var string|null
	 */
	private $burst_status = null;

	/**
	 * Singleton instance
	 *
	 * @return WPO_Analytics_Provider
	 */
	public static function instance(): WPO_Analytics_Provider {
		static $instance = null;
		if (null === $instance) {
			$instance = new self();
		}
		return $instance;
	}

	/**
	 * Whether Google Analytics can be used at all (Premium feature).
	 *
	 * @return bool
	 */
	public function can_use_google(): bool {
		return WP_Optimize::is_premium();
	}

	/**
	 * Get the provider in use, derived from the minify config.
	 *
	 * Google Analytics is the provider while its script is switched on (Premium only),
	 * Burst otherwise. Existing Premium sites with Google Analytics enabled therefore keep
	 * Google without any migration; in the free version Google is never returned.
	 *
	 * @return string 'burst' or 'google'
	 */
	public function get_provider(): string {
		return ($this->can_use_google() && $this->is_google_enabled()) ? self::PROVIDER_GOOGLE : self::PROVIDER_BURST;
	}

	/**
	 * Whether the Google Analytics script is switched on in the minify config
	 *
	 * @return bool
	 */
	private function is_google_enabled(): bool {
		$config = wp_optimize_minify_config()->get();
		return !empty($config['enable_analytics']);
	}

	/**
	 * Whether Google Analytics is actually tracking: Premium, enabled and a tracking ID present
	 * (the same condition WP_Optimize_Minify_Premium uses to load the analytics class).
	 *
	 * @return bool
	 */
	public function is_google_active(): bool {
		$config = wp_optimize_minify_config()->get();
		return $this->can_use_google() && $this->is_google_enabled() && !empty($config['tracking_id']);
	}

	/**
	 * Get the Burst plugin status.
	 *
	 * Detection is left to the Installer, whose plugins.json knows the free and premium
	 * constants of Burst; Burst Pro counts as active, the free plugin is not needed then.
	 *
	 * @return string One of the STATUS_* constants
	 */
	public function get_burst_status(): string {
		if (null === $this->burst_status) $this->burst_status = $this->detect_burst_status();
		return $this->burst_status;
	}

	/**
	 * Detect the Burst plugin status; cached per request by get_burst_status() and
	 * invalidated by the download and activate steps.
	 *
	 * @return string One of the STATUS_* constants
	 */
	private function detect_burst_status(): string {
		// An older Burst release can be active on a PHP version the Installer cannot load on,
		// so look for a running Burst first, without the Installer.
		if ($this->burst_is_running()) return self::STATUS_ACTIVE;

		// Nothing can be installed or activated from here without the Installer.
		if (!$this->installer_can_load()) return self::STATUS_NOT_INSTALLED;

		switch ($this->get_installer()->get_plugin_action(self::BURST_SLUG)) {
			case 'download':
				return self::STATUS_NOT_INSTALLED;
			case 'activate':
				return self::STATUS_INACTIVE;
			default:
				// 'installed' (Burst Pro is active) or 'upgrade-to-pro' (free Burst is active).
				return self::STATUS_ACTIVE;
		}
	}

	/**
	 * Whether Burst (free or Pro) is active, checked without the Installer.
	 *
	 * These are the constants plugins.json declares for Burst (`constant_free` and the premium
	 * constant). They are checked directly here because the Installer uses typed properties and
	 * cannot be loaded on the PHP 7.2 and 7.3 sites WP-Optimize still supports.
	 *
	 * @return bool
	 */
	private function burst_is_running(): bool {
		return defined('BURST_PRO') || defined('BURST_FREE');
	}

	/**
	 * Plugin file of the free Burst plugin, as listed in the library's plugins.json.
	 * Only called for an installed Burst, which implies installer_can_load() passed.
	 *
	 * @return string
	 */
	private function get_burst_file(): string {
		return (string) $this->get_installer()->get_activation_slug(self::BURST_SLUG);
	}

	/**
	 * Whether the library's Installer can be loaded on this PHP version.
	 *
	 * @return bool
	 */
	private function installer_can_load(): bool {
		return version_compare(PHP_VERSION, self::INSTALLER_REQUIRED_PHP_VERSION, '>=');
	}

	/**
	 * Whether the current user may download plugins from WordPress.org.
	 * `install_plugins` is already denied by WordPress when DISALLOW_FILE_MODS is set; checked explicitly for clarity.
	 *
	 * @return bool
	 */
	public function can_install(): bool {
		if (defined('DISALLOW_FILE_MODS') && DISALLOW_FILE_MODS) return false;
		return current_user_can('install_plugins');
	}

	/**
	 * Whether the current user may activate the installed Burst plugin.
	 * Activation needs no file changes, so it stays possible under DISALLOW_FILE_MODS.
	 *
	 * @return bool
	 */
	public function can_activate(): bool {
		$capability = is_multisite() ? 'manage_network_plugins' : 'activate_plugins';
		return current_user_can($capability) && current_user_can('activate_plugin', $this->get_burst_file());
	}

	/**
	 * Steps still needed to get Burst running, based on the current status.
	 *
	 * @return array
	 */
	public function get_remaining_steps(): array {
		switch ($this->get_burst_status()) {
			case self::STATUS_ACTIVE:
				return array(self::STEP_CONFIGURE);
			case self::STATUS_INACTIVE:
				return array(self::STEP_ACTIVATE, self::STEP_CONFIGURE);
			default:
				return array(self::STEP_DOWNLOAD, self::STEP_ACTIVATE, self::STEP_CONFIGURE);
		}
	}

	/**
	 * Whether the "Enable Burst" action can run for the current user and status.
	 *
	 * @return bool
	 */
	public function can_enable_burst(): bool {
		$status = $this->get_burst_status();
		if (self::STATUS_ACTIVE === $status) return true;
		if (self::STATUS_INACTIVE === $status) return $this->can_activate();
		return $this->installer_can_load() && $this->can_install();
	}

	/**
	 * Why the "Enable Burst" button is disabled, shown next to the button.
	 *
	 * @return string Empty when the button is enabled
	 */
	public function get_enable_burst_blocker(): string {
		if ($this->can_enable_burst()) return '';

		if (!$this->installer_can_load()) {
			return sprintf(
				/* translators: %s: PHP version of this site */
				__('Burst Statistics cannot be installed from here on PHP %s.', 'wp-optimize'),
				PHP_VERSION
			) . ' ' . __('Update PHP to use Burst Statistics.', 'wp-optimize');
		}

		if (self::STATUS_INACTIVE === $this->get_burst_status()) {
			return __('Your account is not allowed to activate plugins.', 'wp-optimize') . ' ' . __('Ask an administrator to activate Burst Statistics.', 'wp-optimize');
		}

		if (defined('DISALLOW_FILE_MODS') && DISALLOW_FILE_MODS) {
			return __('Plugin installation is disabled on this site (DISALLOW_FILE_MODS).', 'wp-optimize');
		}

		return __('Your account is not allowed to install plugins.', 'wp-optimize') . ' ' . __('Ask an administrator to install Burst Statistics.', 'wp-optimize');
	}

	/**
	 * Everything the template and the JS need to render the tab.
	 *
	 * @return array
	 */
	public function get_state(): array {
		$config = wp_optimize_minify_config()->get();
		$burst_status = $this->get_burst_status();
		$selected = $this->get_provider();

		return array(
			// Burst is the default and recommended choice; Google is selected while its script is enabled (Premium).
			'selected' => $selected,
			// The "Burst Statistics is active" panel replaces the cards when Burst is running and Google Analytics is off.
			'show_burst_success' => (self::STATUS_ACTIVE === $burst_status && self::PROVIDER_GOOGLE !== $selected),
			'burst_status' => $burst_status,
			'steps' => $this->get_remaining_steps(),
			'can_enable_burst' => $this->can_enable_burst(),
			'enable_burst_blocker' => $this->get_enable_burst_blocker(),
			'burst_dashboard_url' => admin_url('admin.php?page=burst'),
			'burst_settings_url' => admin_url('admin.php?page=burst#/settings/general'),
			'burst_wporg_url' => self::BURST_WPORG_URL,
			'tracking_method' => $this->get_burst_tracking_method_label(),
			'ga_enabled' => $this->is_google_enabled(),
			'ga_active' => $this->is_google_active(),
			'ga_tracking_id' => $config['tracking_id'] ?? '',
			'ga_method' => $config['analytics_method'] ?? 'gtagv4',
			'google_analytics_url' => self::GOOGLE_ANALYTICS_URL,
			'upgrade_url' => apply_filters('wpo_premium_buy_url', WP_Optimize()->premium_version_link . '&utm_content=analytics-tab', 'analytics_tab'),
		);
	}

	/**
	 * Run one step of the Burst install flow.
	 *
	 * Errors are returned as WP_Error; WPO_Ajax turns them into the standard error response
	 * that the JS notices show.
	 *
	 * @param string $step One of the STEP_* constants
	 * @return array|WP_Error {success: true, state: array} or the error
	 */
	public function run_burst_step(string $step) {
		if (!$this->can_enable_burst()) {
			return new WP_Error('cannot_enable_burst', $this->get_enable_burst_blocker());
		}

		switch ($step) {
			case self::STEP_DOWNLOAD:
				$result = $this->download_burst();
				break;
			case self::STEP_ACTIVATE:
				$result = $this->activate_burst();
				break;
			case self::STEP_CONFIGURE:
				$result = $this->configure_burst();
				break;
			default:
				$result = new WP_Error('invalid_step', __('Unknown installation step.', 'wp-optimize'));
				break;
		}

		if (is_wp_error($result)) return $result;

		return array(
			'success' => true,
			'state' => $this->get_state(),
		);
	}

	/**
	 * Download Burst from WordPress.org via the library's Installer.
	 *
	 * @return true|WP_Error
	 */
	private function download_burst() {
		if (self::STATUS_NOT_INSTALLED !== $this->get_burst_status()) return true;

		if (!$this->can_install()) {
			return new WP_Error('cannot_install', __('You are not allowed to install plugins on this site.', 'wp-optimize'));
		}

		// Temporary: remove once WP-Optimize ships the lib-onboarding-wizard release in which
		// Installer::download_plugin() checks the WordPress.org requirements itself and exposes
		// the reason through Installer::get_last_error(). The vendored 1.0.7 returns a bare false.
		$requirements_error = $this->get_live_requirements_error();
		if (is_wp_error($requirements_error)) return $requirements_error;

		// The library returns a boolean only; the upgrader's own error message is not exposed.
		$downloaded = $this->get_installer()->download_plugin();
		$this->burst_status = null;
		if (!$downloaded || !$this->get_installer()->plugin_is_downloaded(self::BURST_SLUG)) {
			$reason = $this->get_installer_error_message();
			if ('' === $reason) $reason = __('Check the site\'s connection and file permissions, or install it from the Plugins screen.', 'wp-optimize');
			return new WP_Error('download_failed', __('Burst Statistics could not be downloaded from WordPress.org.', 'wp-optimize') . ' ' . $reason);
		}

		return true;
	}

	/**
	 * Check the current Burst release's "Requires at least" / "Requires PHP" from WordPress.org against this site.
	 *
	 * The download always fetches the latest release, so its live requirements decide. Cached for a day.
	 *
	 * @return WP_Error|null Null when the site meets the requirements or WordPress.org could not be asked.
	 */
	private function get_live_requirements_error() {
		$transient_key = 'wpo_analytics_burst_requirements';
		$requirements = get_site_transient($transient_key);

		if (!is_array($requirements)) {
			require_once(ABSPATH . 'wp-admin/includes/plugin-install.php');
			$plugin_info = plugins_api('plugin_information', array('slug' => self::BURST_SLUG, 'fields' => array('sections' => false)));
			// Unreachable WordPress.org is reported by the download itself; do not block on it here.
			if (is_wp_error($plugin_info) || !is_object($plugin_info)) return null;

			$requirements = array(
				'requires' => !empty($plugin_info->requires) ? (string) $plugin_info->requires : '',
				'requires_php' => !empty($plugin_info->requires_php) ? (string) $plugin_info->requires_php : '',
			);
			set_site_transient($transient_key, $requirements, DAY_IN_SECONDS);
		}

		// version_compare() rather than is_php_version_compatible(): WP-Optimize still supports WordPress < 5.2.
		if ('' !== $requirements['requires_php'] && version_compare(PHP_VERSION, $requirements['requires_php'], '<')) {
			return new WP_Error('incompatible_php_required_version', sprintf(
				/* translators: 1: minimum PHP version required by Burst, 2: PHP version of this site */
				__('Burst Statistics requires PHP %1$s or higher, this site runs PHP %2$s.', 'wp-optimize'),
				$requirements['requires_php'],
				PHP_VERSION
			));
		}

		if ('' !== $requirements['requires'] && version_compare(get_bloginfo('version'), $requirements['requires'], '<')) {
			return new WP_Error('incompatible_wp_required_version', sprintf(
				/* translators: 1: minimum WordPress version required by Burst, 2: WordPress version of this site */
				__('Burst Statistics requires WordPress %1$s or higher, this site runs WordPress %2$s.', 'wp-optimize'),
				$requirements['requires'],
				get_bloginfo('version')
			));
		}

		return null;
	}

	/**
	 * Activate Burst through core and record WP-Optimize as the installation source.
	 *
	 * @return true|WP_Error
	 */
	private function activate_burst() {
		$status = $this->get_burst_status();
		if (self::STATUS_ACTIVE === $status) return true;

		if (self::STATUS_NOT_INSTALLED === $status) {
			return new WP_Error('not_installed', __('Burst Statistics is not installed yet.', 'wp-optimize'));
		}

		if (!$this->can_activate()) {
			return new WP_Error('cannot_activate', __('You are not allowed to activate plugins on this site.', 'wp-optimize'));
		}

		// Same as Installer::activate_plugin() in 1.0.7, but keeps core's WP_Error.
		$result = activate_plugin($this->get_burst_file(), '', is_multisite());
		$this->burst_status = null;
		if (is_wp_error($result)) {
			$reason = $result->get_error_message();
			if ('' === $reason) $reason = __('Activate it from the Plugins screen.', 'wp-optimize');
			return new WP_Error('activation_failed', __('Burst Statistics could not be activated.', 'wp-optimize') . ' ' . $reason);
		}

		update_site_option('teamupdraft_installation_source_' . self::BURST_SLUG, self::CALLER_SLUG);

		return true;
	}

	/**
	 * Apply the recommended settings.
	 *
	 * Runs in a separate request after activation, so Burst is fully loaded and its own
	 * activation routine (cookie tracking, turbo mode, tracking script) has already run
	 * on admin_init. This step only records the choice and, when WP-Optimize activated Burst,
	 * keeps Burst's setup wizard closed.
	 *
	 * @return true|WP_Error
	 */
	private function configure_burst() {
		if (self::STATUS_ACTIVE !== $this->get_burst_status()) {
			return new WP_Error('not_active', __('Burst Statistics is not active.', 'wp-optimize'));
		}

		$source = get_site_option('teamupdraft_installation_source_' . self::BURST_SLUG);
		if (self::CALLER_SLUG === $source) $this->suppress_burst_wizard();

		// Google Analytics is switched off so the site does not run two trackers. Saved through the
		// regular minify settings command, so the minify and page caches are purged like any other change.
		$minify_commands = new WP_Optimize_Minify_Commands();
		$saved = $minify_commands->save_minify_settings(array('enable_analytics' => false));
		if (empty($saved['success'])) {
			return new WP_Error('save_failed', __('The Google Analytics setting could not be saved.', 'wp-optimize'));
		}

		return true;
	}

	/**
	 * Keep Burst's onboarding wizard from opening.
	 *
	 * Burst sets `burst_start_onboarding` on activation; its wizard library treats
	 * `burst_skipped_onboarding` as a permanent skip and clears the start flag itself.
	 * The post-activation redirect is already skipped because activate_burst() records
	 * `teamupdraft_installation_source_burst-statistics`.
	 *
	 * @return void
	 */
	private function suppress_burst_wizard(): void {
		delete_option('burst_start_onboarding');
		update_option('burst_skipped_onboarding', true, false);
		delete_transient('burst_redirect_to_settings_page');
	}

	/**
	 * Human readable tracking method, read from Burst's settings.
	 *
	 * @return string
	 */
	private function get_burst_tracking_method_label(): string {
		$settings = get_option('burst_options_settings', array());
		if (!is_array($settings)) $settings = array();

		$privacy_level = empty($settings['privacy_level']) ? '' : (string) $settings['privacy_level'];
		if ('' === $privacy_level) {
			// Burst before 3.6.1 only had a cookieless (fingerprint) toggle.
			$privacy_level = !empty($settings['enable_cookieless_tracking']) ? 'fingerprint' : 'cookie';
		}

		// The same names Burst uses for its "How Burst recognizes visitors" setting.
		$labels = array(
			'cookie' => __('Cookie', 'wp-optimize'),
			'fingerprint' => __('Cookieless fingerprint', 'wp-optimize'),
			'private_mode' => __('Cookieless', 'wp-optimize'),
		);

		return $labels[$privacy_level] ?? $labels['cookie'];
	}

	/**
	 * Why the Installer's last download failed.
	 *
	 * Newer lib-onboarding-wizard releases expose the reason through Installer::get_last_error();
	 * the vendored 1.0.7 does not, in which case the caller falls back to a generic hint.
	 *
	 * @return string Empty when unknown
	 */
	private function get_installer_error_message(): string {
		$installer = $this->get_installer();
		if (!method_exists($installer, 'get_last_error')) return '';

		$error = $installer->get_last_error();
		return is_wp_error($error) ? $error->get_error_message() : '';
	}

	/**
	 * Installer instance for Burst.
	 *
	 * @return Installer
	 */
	private function get_installer(): Installer {
		static $installer = null;
		if (null === $installer) {
			$installer = new Installer(self::CALLER_SLUG, self::BURST_SLUG);
		}
		return $installer;
	}
}
