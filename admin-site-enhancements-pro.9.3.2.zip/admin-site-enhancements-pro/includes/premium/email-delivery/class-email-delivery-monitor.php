<?php
/**
 * Scheduled SMTP handshake checks and failure alerts for Email Delivery.
 *
 * Loaded only for the Pro version.
 *
 * @package ASENHA
 * @since   9.2.3
 */

namespace ASENHA\Classes;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Checks the primary and fallback SMTP connections and sends alerts when they fail.
 *
 * @since 9.2.3
 */
class Email_Delivery_Monitor {

	const STATUS_OPTION   = 'asenha_smtp_health_status';
	const LOCK_TRANSIENT  = 'asenha_smtp_health_check_running';
	const CRON_HOOK       = 'asenha_smtp_health_check';
	const ALERT_HOOK      = 'asenha_smtp_send_alert';
	const CHECK_TIMEOUT   = 15;
	const ALERT_TIMEOUT   = 15;
	const LOCK_TTL        = 300;
	const MAX_ERROR_LENGTH = 1000;

	/**
	 * Email Delivery instance that owns the SMTP connection settings.
	 *
	 * @since 9.2.3
	 *
	 * @var Email_Delivery
	 */
	private $email_delivery;

	/**
	 * Whether an alert email is currently being sent.
	 *
	 * Stops a failed alert from scheduling another alert.
	 *
	 * @since 9.2.3
	 *
	 * @var bool
	 */
	private $sending_alert = false;

	/**
	 * @since 9.2.3
	 *
	 * @param Email_Delivery $email_delivery Email Delivery instance.
	 */
	public function __construct( Email_Delivery $email_delivery ) {
		$this->email_delivery = $email_delivery;
	}

	/**
	 * Whether an alert email is in progress.
	 *
	 * @since 9.2.3
	 *
	 * @return bool
	 */
	public function is_sending_alert() {
		return $this->sending_alert;
	}

	/**
	 * Whether connection monitoring is turned on for the current site.
	 *
	 * @since 9.2.3
	 *
	 * @return bool
	 */
	public function is_enabled() {
		$options = get_option( ASENHA_SLUG_U, array() );

		return is_array( $options )
			&& ! empty( $options['smtp_email_delivery'] )
			&& ! empty( $options['smtp_health_check'] );
	}

	/**
	 * Schedule or clear the recurring handshake check.
	 *
	 * @since 9.2.3
	 *
	 * @return void
	 */
	public function maybe_schedule() {
		if ( ! $this->is_enabled() ) {
			wp_clear_scheduled_hook( self::CRON_HOOK );
			wp_clear_scheduled_hook( self::ALERT_HOOK );
			return;
		}

		$frequency = $this->get_frequency();
		$current   = wp_get_schedule( self::CRON_HOOK );

		if ( $current !== $frequency ) {
			wp_clear_scheduled_hook( self::CRON_HOOK );
			wp_schedule_event( time(), $frequency, self::CRON_HOOK );
		}
	}

	/**
	 * Reschedule when the main ASE option is saved.
	 *
	 * @since 9.2.3
	 *
	 * @param string $option_name Updated option name.
	 * @return void
	 */
	public function maybe_schedule_on_option_change( $option_name ) {
		if ( ASENHA_SLUG_U !== $option_name ) {
			return;
		}

		$this->maybe_schedule();
	}

	/**
	 * Cron callback. Checks each enabled connection and alerts on a status change.
	 *
	 * @since 9.2.3
	 *
	 * @return void
	 */
	public function run_scheduled_check() {
		$this->run_check( 'scheduled_check' );
	}

	/**
	 * AJAX callback for the "Run check now" button.
	 *
	 * @since 9.2.3
	 *
	 * @return void
	 */
	public function ajax_run_check_now() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error(
				array(
					'message' => __( 'You do not have permission to run this check.', 'admin-site-enhancements' ),
				),
				403
			);
		}

		$nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';

		if ( ! wp_verify_nonce( $nonce, 'asenha-smtp-health-check-nonce_' . get_current_user_id() ) ) {
			wp_send_json_error(
				array(
					'message' => __( 'The check could not be completed. Please reload the page and try again.', 'admin-site-enhancements' ),
				),
				403
			);
		}

		if ( ! $this->is_enabled() ) {
			wp_send_json_error(
				array(
					'message' => __( 'Save the Connection Monitoring settings before running a check.', 'admin-site-enhancements' ),
				),
				400
			);
		}

		$results = $this->run_check( 'manual_check' );

		if ( null === $results ) {
			wp_send_json_error(
				array(
					'message' => __( 'A check is already running. Try again in a minute.', 'admin-site-enhancements' ),
				),
				409
			);
		}

		$connections = array();
		$failed      = array();

		foreach ( $results as $id => $result ) {
			$status = isset( $result['status'] ) ? $result['status'] : '';

			$connections[ $id ] = array(
				'status'             => $status,
				'label'              => self::status_label( $status ),
				'error'              => isset( $result['error'] ) ? $result['error'] : '',
				'checked_at_display' => self::format_checked_at( isset( $result['checked_at'] ) ? (int) $result['checked_at'] : 0 ),
			);

			if ( 'failed' === $status ) {
				$failed[] = self::connection_name( $id );
			}
		}

		if ( ! empty( $failed ) ) {
			$message = sprintf(
				/* translators: %s: comma-separated connection names */
				__( 'Check complete. Failed: %s.', 'admin-site-enhancements' ),
				implode( ', ', $failed )
			);
		} else {
			$message = __( 'Check complete.', 'admin-site-enhancements' );
		}

		wp_send_json_success(
			array(
				'message'     => $message,
				'connections' => $connections,
			)
		);
	}

	/**
	 * Queue an alert for a real wp_mail() failure.
	 *
	 * A per-connection transient stops a burst of failures from sending an alert
	 * on every message. The alert itself is deferred to cron so it is not sent
	 * from inside wp_mail_failed.
	 *
	 * @since 9.2.3
	 *
	 * @param string $connection Connection id: `primary`, `fallback`, or `both`.
	 * @param string $error      Delivery error. Passwords are removed before storage.
	 * @param string $event      `email_delivery_failed` or `email_delivered_via_fallback`.
	 * @return void
	 */
	public function record_live_failure( $connection, $error, $event ) {
		if ( $this->sending_alert || ! $this->is_enabled() ) {
			return;
		}

		$connection = sanitize_key( (string) $connection );
		$event      = sanitize_key( (string) $event );

		if ( ! in_array( $connection, array( 'primary', 'fallback', 'both' ), true ) ) {
			return;
		}

		if ( ! in_array( $event, array( 'email_delivery_failed', 'email_delivered_via_fallback' ), true ) ) {
			return;
		}

		$this->flag_connection_admin_notice( $connection );

		$cooldown = (int) apply_filters( 'asenha_smtp_live_alert_cooldown', HOUR_IN_SECONDS );

		if ( $cooldown < MINUTE_IN_SECONDS ) {
			$cooldown = HOUR_IN_SECONDS;
		}

		$transient_key = 'asenha_smtp_live_alert_' . $connection;

		if ( get_transient( $transient_key ) ) {
			return;
		}

		set_transient( $transient_key, 1, $cooldown );

		$payload = array(
			'event'       => $event,
			'source'      => 'live_delivery',
			'connection'  => $connection,
			'error'       => $this->redact_error_message( $error ),
			'occurred_at' => gmdate( 'Y-m-d\TH:i:s\Z' ),
		);

		$scheduled = wp_schedule_single_event( time(), self::ALERT_HOOK, array( $payload ) );

		if ( true !== $scheduled ) {
			delete_transient( $transient_key );
			// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
			error_log( 'ASE: could not schedule the SMTP failure alert.' );
			return;
		}

		if ( ! wp_doing_cron() ) {
			spawn_cron();
		}
	}

	/**
	 * Send the email alert and webhook payload for one event.
	 *
	 * @since 9.2.3
	 *
	 * @param array<string,string> $payload Alert payload queued by a check or a live failure.
	 * @return void
	 */
	public function dispatch_alert( $payload ) {
		if ( ! is_array( $payload ) || ! $this->is_enabled() ) {
			return;
		}

		$event = isset( $payload['event'] ) ? sanitize_key( (string) $payload['event'] ) : '';
		$source = isset( $payload['source'] ) ? sanitize_key( (string) $payload['source'] ) : '';
		$connection = isset( $payload['connection'] ) ? sanitize_key( (string) $payload['connection'] ) : '';

		$allowed_events = array(
			'smtp_connection_failed',
			'smtp_connection_recovered',
			'email_delivery_failed',
			'email_delivered_via_fallback',
		);

		if ( ! in_array( $event, $allowed_events, true ) ) {
			return;
		}

		if ( ! in_array( $connection, array( 'primary', 'fallback', 'both' ), true ) ) {
			return;
		}

		if ( ! in_array( $source, array( 'scheduled_check', 'manual_check', 'live_delivery' ), true ) ) {
			$source = 'scheduled_check';
		}

		$error = isset( $payload['error'] ) ? $this->redact_error_message( $payload['error'] ) : '';
		$occurred_at = isset( $payload['occurred_at'] ) ? sanitize_text_field( (string) $payload['occurred_at'] ) : gmdate( 'Y-m-d\TH:i:s\Z' );

		$clean_payload = array(
			'event'       => $event,
			'source'      => $source,
			'connection'  => $connection,
			'error'       => $error,
			'occurred_at' => $occurred_at,
		);

		$text = $this->build_summary( $clean_payload );

		$this->sending_alert = true;

		try {
			$this->send_alert_email( $clean_payload, $text );
			$this->send_alert_webhooks( $clean_payload, $text );
		} finally {
			$this->sending_alert = false;
		}
	}

	/**
	 * Keep an alert email from waiting on a dead SMTP server.
	 *
	 * @since 9.2.3
	 *
	 * @param object $phpmailer PHPMailer instance.
	 * @return void
	 */
	public function limit_alert_mailer_timeout( $phpmailer ) {
		if ( is_object( $phpmailer ) ) {
			$phpmailer->Timeout = self::ALERT_TIMEOUT; // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
		}
	}

	/**
	 * Show a warning while a monitored SMTP connection is failed.
	 *
	 * The notice stays until a later handshake for that connection succeeds.
	 * It is not dismissible, and Hide Admin Notices leaves it in place.
	 *
	 * @since 9.2.3
	 *
	 * @return void
	 */
	public function maybe_show_connection_failure_notice() {
		if ( ! is_admin() || ! current_user_can( 'manage_options' ) ) {
			return;
		}

		if ( ! $this->is_enabled() ) {
			return;
		}

		$failing = $this->get_notice_connection_ids();

		if ( empty( $failing ) ) {
			return;
		}

		if ( count( $failing ) > 1 ) {
			$message = __( 'The Primary and fallback SMTP connections failed.', 'admin-site-enhancements' );
		} else {
			$message = sprintf(
				/* translators: %s: SMTP connection name, Primary or Fallback. */
				__( 'The %s SMTP connection failed.', 'admin-site-enhancements' ),
				self::connection_name( $failing[0] )
			);
		}

		$settings_url = admin_url( 'tools.php?page=' . ASENHA_SLUG . '#utilities' );
		?>
		<div class="notice notice-warning asenha-smtp-connection-notice" id="asenha-smtp-connection-notice">
			<p>
				<?php echo esc_html( $message ); ?>
				<a href="<?php echo esc_url( $settings_url ); ?>"><?php esc_html_e( 'Check configuration', 'admin-site-enhancements' ); ?></a>
			</p>
		</div>
		<?php
	}

	/**
	 * Markup for the last-check status field on the settings screen.
	 *
	 * @since 9.2.3
	 *
	 * @return string
	 */
	public static function get_status_field_html() {
		$stored  = get_option( self::STATUS_OPTION, array() );
		$options = get_option( ASENHA_SLUG_U, array() );

		if ( ! is_array( $stored ) ) {
			$stored = array();
		}

		if ( ! is_array( $options ) ) {
			$options = array();
		}

		$primary = isset( $stored['primary'] ) && is_array( $stored['primary'] ) ? $stored['primary'] : array();

		if ( ! empty( $options['smtp_fallback'] ) ) {
			$fallback = isset( $stored['fallback'] ) && is_array( $stored['fallback'] ) ? $stored['fallback'] : array();
		} else {
			$fallback = array(
				'status' => 'not_enabled',
			);
		}

		$html  = '<div class="asenha-smtp-health-status">';
		$html .= self::render_connection_row( 'primary', $primary );
		$html .= self::render_connection_row( 'fallback', $fallback );
		$html .= '<div class="asenha-smtp-health-status__actions">';
		$html .= '<button type="button" class="button" id="smtp-health-check-run">' . esc_html__( 'Run check now', 'admin-site-enhancements' ) . '</button>';
		$html .= '</div>';
		$html .= '<div id="smtp-health-check-result" class="asenha-smtp-health-status__result" aria-live="polite"></div>';
		$html .= '</div>';

		return $html;
	}

	/**
	 * Human label for a stored or live check status.
	 *
	 * @since 9.2.3
	 *
	 * @param string $status Status key.
	 * @return string
	 */
	public static function status_label( $status ) {
		switch ( $status ) {
			case 'ok':
				return __( 'Connected', 'admin-site-enhancements' );
			case 'failed':
				return __( 'Failed', 'admin-site-enhancements' );
			case 'not_configured':
				return __( 'Not configured', 'admin-site-enhancements' );
			case 'not_enabled':
				return __( 'Not enabled', 'admin-site-enhancements' );
			default:
				return __( 'Not checked yet', 'admin-site-enhancements' );
		}
	}

	/**
	 * Badge class for a check status.
	 *
	 * @since 9.2.3
	 *
	 * @param string $status Status key.
	 * @return string
	 */
	public static function status_class( $status ) {
		if ( 'ok' === $status ) {
			return 'is-ok';
		}

		if ( 'failed' === $status ) {
			return 'is-failed';
		}

		return 'is-unknown';
	}

	/**
	 * Display name for a connection id.
	 *
	 * @since 9.2.3
	 *
	 * @param string $id Connection id.
	 * @return string
	 */
	public static function connection_name( $id ) {
		if ( 'fallback' === $id ) {
			return __( 'Fallback', 'admin-site-enhancements' );
		}

		if ( 'both' === $id ) {
			return __( 'Primary and fallback', 'admin-site-enhancements' );
		}

		return __( 'Primary', 'admin-site-enhancements' );
	}

	/**
	 * Format a check timestamp with the site's date and time settings.
	 *
	 * @since 9.2.3
	 *
	 * @param int $timestamp Unix timestamp.
	 * @return string
	 */
	public static function format_checked_at( $timestamp ) {
		$timestamp = (int) $timestamp;

		if ( $timestamp <= 0 ) {
			return '';
		}

		$format = trim( (string) get_option( 'date_format' ) . ' ' . (string) get_option( 'time_format' ) );

		if ( '' === $format ) {
			$format = 'F j, Y g:i a';
		}

		return wp_date( $format, $timestamp );
	}

	/**
	 * Run the handshake checks unless another check is already in progress.
	 *
	 * @since 9.2.3
	 *
	 * @param string $source `scheduled_check` or `manual_check`.
	 * @return array<string,array<string,mixed>>|null Null when a check is already running.
	 */
	private function run_check( $source ) {
		if ( ! $this->is_enabled() ) {
			return array();
		}

		if ( get_transient( self::LOCK_TRANSIENT ) ) {
			return null;
		}

		set_transient( self::LOCK_TRANSIENT, 1, self::LOCK_TTL );

		try {
			$results = array(
				'primary' => $this->check_connection( 'primary' ),
			);

			$options = get_option( ASENHA_SLUG_U, array() );

			if ( is_array( $options ) && ! empty( $options['smtp_fallback'] ) ) {
				$results['fallback'] = $this->check_connection( 'fallback' );
			}

			$this->update_status_and_maybe_alert( $results, $source );

			return $results;
		} finally {
			delete_transient( self::LOCK_TRANSIENT );
		}
	}

	/**
	 * Open one SMTP connection, authenticate when required, then close it.
	 *
	 * No message is sent.
	 *
	 * @since 9.2.3
	 *
	 * @param string $id Connection id, `primary` or `fallback`.
	 * @return array<string,mixed>
	 */
	private function check_connection( $id ) {
		$checked_at = time();
		$id         = ( 'fallback' === $id ) ? 'fallback' : 'primary';
		$connection = $this->email_delivery->get_smtp_connection_for_check__premium_only( $id );

		if ( empty( $connection['configured'] ) ) {
			return array(
				'status'     => 'not_configured',
				'error'      => '',
				'checked_at' => $checked_at,
			);
		}

		if ( ! empty( $connection['password_blocked'] ) ) {
			return array(
				'status'     => 'failed',
				'error'      => __( 'SMTP password unavailable (decryption failed or not configured).', 'admin-site-enhancements' ),
				'checked_at' => $checked_at,
			);
		}

		$connection['debug'] = false;
		$connected           = false;
		$error               = '';
		$phpmailer           = null;

		try {
			$phpmailer = $this->create_mailer();
			$this->email_delivery->apply_smtp_connection_for_check__premium_only( $phpmailer, $connection );
			$phpmailer->Timeout = self::CHECK_TIMEOUT; // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
			$connected = (bool) $phpmailer->smtpConnect();

			if ( ! $connected ) {
				$error = isset( $phpmailer->ErrorInfo ) ? (string) $phpmailer->ErrorInfo : '';
			}
		} catch ( \Exception $exception ) {
			$connected = false;
			$error     = $exception->getMessage();
		} finally {
			if ( is_object( $phpmailer ) ) {
				$phpmailer->smtpClose();
			}
		}

		if ( ! $connected ) {
			if ( '' === $error ) {
				$error = __( 'SMTP connection failed.', 'admin-site-enhancements' );
			}

			return array(
				'status'     => 'failed',
				'error'      => $this->redact_error_message( $error ),
				'checked_at' => $checked_at,
			);
		}

		return array(
			'status'     => 'ok',
			'error'      => '',
			'checked_at' => $checked_at,
		);
	}

	/**
	 * Remember a live delivery failure so the admin notice stays up.
	 *
	 * This does not change the handshake status and does not send an alert.
	 * A later handshake that returns ok clears the flag.
	 *
	 * @since 9.2.3
	 *
	 * @param string $connection Connection id: `primary`, `fallback`, or `both`.
	 * @return void
	 */
	private function flag_connection_admin_notice( $connection ) {
		$ids = ( 'both' === $connection ) ? array( 'primary', 'fallback' ) : array( $connection );

		$stored = get_option( self::STATUS_OPTION, array() );

		if ( ! is_array( $stored ) ) {
			$stored = array();
		}

		foreach ( $ids as $id ) {
			if ( ! isset( $stored[ $id ] ) || ! is_array( $stored[ $id ] ) ) {
				$stored[ $id ] = array();
			}

			$stored[ $id ]['show_admin_notice'] = true;
		}

		update_option( self::STATUS_OPTION, $stored, false );
	}

	/**
	 * Connection ids that should keep the failure notice visible.
	 *
	 * @since 9.2.3
	 *
	 * @return string[]
	 */
	private function get_notice_connection_ids() {
		$stored  = get_option( self::STATUS_OPTION, array() );
		$options = get_option( ASENHA_SLUG_U, array() );

		if ( ! is_array( $stored ) ) {
			return array();
		}

		$ids = array( 'primary' );

		if ( is_array( $options ) && ! empty( $options['smtp_fallback'] ) ) {
			$ids[] = 'fallback';
		}

		$failing = array();

		foreach ( $ids as $id ) {
			$entry  = isset( $stored[ $id ] ) && is_array( $stored[ $id ] ) ? $stored[ $id ] : array();
			$status = isset( $entry['status'] ) ? (string) $entry['status'] : '';

			if ( 'failed' === $status || ! empty( $entry['show_admin_notice'] ) ) {
				$failing[] = $id;
			}
		}

		return $failing;
	}

	/**
	 * Store the latest result for each connection and alert only when it changes.
	 *
	 * A failure alert is sent the first time a connection fails, including the
	 * first check. A recovery alert is sent when a failing connection connects
	 * again. Repeated checks during an outage do not send another alert.
	 *
	 * @since 9.2.3
	 *
	 * @param array<string,array<string,mixed>> $results Check results keyed by connection id.
	 * @param string                             $source  `scheduled_check` or `manual_check`.
	 * @return void
	 */
	private function update_status_and_maybe_alert( $results, $source ) {
		$stored = get_option( self::STATUS_OPTION, array() );

		if ( ! is_array( $stored ) ) {
			$stored = array();
		}

		$now    = time();
		$alerts = array();

		foreach ( $results as $id => $result ) {
			if ( ! in_array( $id, array( 'primary', 'fallback' ), true ) || ! is_array( $result ) ) {
				continue;
			}

			$previous          = isset( $stored[ $id ]['status'] ) ? (string) $stored[ $id ]['status'] : '';
			$current           = isset( $result['status'] ) ? (string) $result['status'] : '';
			$failing_since     = isset( $stored[ $id ]['failing_since'] ) ? (int) $stored[ $id ]['failing_since'] : 0;
			$last_alerted      = isset( $stored[ $id ]['last_alerted'] ) ? (int) $stored[ $id ]['last_alerted'] : 0;
			$error             = isset( $result['error'] ) ? $this->redact_error_message( $result['error'] ) : '';
			$show_admin_notice = ! empty( $stored[ $id ]['show_admin_notice'] );
			$event             = '';

			if ( 'failed' === $current && 'failed' !== $previous ) {
				$event         = 'smtp_connection_failed';
				$failing_since = $now;
				$last_alerted  = $now;
			} elseif ( 'ok' === $current && 'failed' === $previous ) {
				$event         = 'smtp_connection_recovered';
				$failing_since = 0;
				$last_alerted  = $now;
			} elseif ( 'failed' === $current ) {
				if ( ! $failing_since ) {
					$failing_since = $now;
				}
			} else {
				$failing_since = 0;
			}

			$stored[ $id ] = array(
				'status'        => $current,
				'last_checked'  => isset( $result['checked_at'] ) ? (int) $result['checked_at'] : $now,
				'last_error'    => $error,
				'failing_since' => $failing_since,
				'last_alerted'  => $last_alerted,
			);

			if ( 'ok' !== $current && $show_admin_notice ) {
				$stored[ $id ]['show_admin_notice'] = true;
			}

			if ( '' === $event ) {
				continue;
			}

			$alerts[] = array(
				'event'       => $event,
				'source'      => $source,
				'connection'  => $id,
				'error'       => $error,
				'occurred_at' => gmdate( 'Y-m-d\TH:i:s\Z', $now ),
			);
		}

		update_option( self::STATUS_OPTION, $stored, false );

		foreach ( $alerts as $alert ) {
			$this->dispatch_alert( $alert );
		}
	}

	/**
	 * Send the alert through the SMTP connection that is still usable.
	 *
	 * @since 9.2.3
	 *
	 * @param array<string,string> $payload Clean alert payload.
	 * @param string               $text    Human-readable summary.
	 * @return void
	 */
	private function send_alert_email( $payload, $text ) {
		$options = get_option( ASENHA_SLUG_U, array() );
		$raw     = ( is_array( $options ) && isset( $options['smtp_health_check_notify_emails'] ) ) ? (string) $options['smtp_health_check_notify_emails'] : '';
		$emails  = array();

		foreach ( explode( ',', $raw ) as $email ) {
			$email = sanitize_email( trim( $email ) );

			if ( is_email( $email ) ) {
				$emails[] = $email;
			}
		}

		$emails = array_slice( array_unique( $emails ), 0, 20 );

		if ( empty( $emails ) ) {
			return;
		}

		$site_name = $this->get_site_name();
		$subject   = sprintf(
			'[%s] %s',
			$site_name,
			$this->email_subject_label( $payload['event'] )
		);

		$mode = $this->mailer_mode_for_alert( $payload['event'], $payload['connection'] );

		$this->email_delivery->set_smtp_mailer_mode__premium_only( $mode );
		add_action( 'phpmailer_init', array( $this, 'limit_alert_mailer_timeout' ), 100000 );

		try {
			wp_mail( $emails, $subject, $text );
		} finally {
			remove_action( 'phpmailer_init', array( $this, 'limit_alert_mailer_timeout' ), 100000 );
			$this->email_delivery->set_smtp_mailer_mode__premium_only( 'auto' );
		}
	}

	/**
	 * POST the alert payload to each saved webhook URL.
	 *
	 * @since 9.2.3
	 *
	 * @param array<string,string> $payload Clean alert payload.
	 * @param string               $text    Human-readable summary, also used by Slack and Discord.
	 * @return void
	 */
	private function send_alert_webhooks( $payload, $text ) {
		$options = get_option( ASENHA_SLUG_U, array() );
		$raw     = ( is_array( $options ) && isset( $options['smtp_health_check_webhook_urls'] ) ) ? (string) $options['smtp_health_check_webhook_urls'] : '';
		$urls    = array();

		foreach ( preg_split( '/\r\n|\r|\n/', $raw ) as $url ) {
			$url = esc_url_raw( trim( (string) $url ) );

			if ( '' === $url || ! wp_http_validate_url( $url ) ) {
				continue;
			}

			$scheme = wp_parse_url( $url, PHP_URL_SCHEME );

			if ( ! in_array( $scheme, array( 'http', 'https' ), true ) ) {
				continue;
			}

			$urls[] = $url;

			if ( count( $urls ) >= 10 ) {
				break;
			}
		}

		if ( empty( $urls ) ) {
			return;
		}

		$body = array(
			'event'       => $payload['event'],
			'source'      => $payload['source'],
			'connection'  => $payload['connection'],
			'error'       => $payload['error'],
			'site_name'   => $this->get_site_name(),
			'site_url'    => home_url(),
			'occurred_at' => $payload['occurred_at'],
			'text'        => $text,
			'content'     => $text,
		);

		/**
		 * Filter the JSON body posted to SMTP alert webhooks.
		 *
		 * `text` and `content` carry the same summary so the payload can be posted
		 * to a Slack or Discord incoming webhook without a transformer.
		 *
		 * @since 9.2.3
		 *
		 * @param array<string,string> $body    Webhook body.
		 * @param array<string,string> $payload Alert payload.
		 */
		$body = apply_filters( 'asenha_smtp_alert_webhook_payload', $body, $payload );

		if ( ! is_array( $body ) ) {
			return;
		}

		$json = wp_json_encode( $body );

		if ( ! is_string( $json ) || '' === $json ) {
			return;
		}

		foreach ( $urls as $url ) {
			$response = wp_safe_remote_post(
				$url,
				array(
					'timeout'     => 10,
					'redirection' => 2,
					'headers'     => array(
						'Content-Type' => 'application/json; charset=utf-8',
					),
					'body'        => $json,
				)
			);

			if ( is_wp_error( $response ) ) {
				// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
				error_log( 'ASE: SMTP alert webhook failed - ' . $response->get_error_code() );
				continue;
			}

			$code = (int) wp_remote_retrieve_response_code( $response );

			if ( $code < 200 || $code >= 300 ) {
				// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
				error_log( 'ASE: SMTP alert webhook failed - HTTP ' . $code );
			}
		}
	}

	/**
	 * Build the text used for the email body and the webhook text.
	 *
	 * Failure alerts are three paragraphs: what happened, the error, and a
	 * prompt to review the Email Delivery settings. A recovery is one sentence.
	 * The time uses the site date format, time format, and timezone.
	 *
	 * @since 9.2.3
	 *
	 * @param array<string,string> $payload Clean alert payload.
	 * @return string
	 */
	private function build_summary( $payload ) {
		$site_name        = $this->get_site_name();
		$site_url         = home_url();
		$connection_label = self::connection_name( $payload['connection'] );
		$when             = $this->format_alert_datetime( $payload['occurred_at'] );
		$error            = $payload['error'];

		if ( '' === $error && 'smtp_connection_recovered' !== $payload['event'] ) {
			$error = __( 'Unknown error.', 'admin-site-enhancements' );
		}

		switch ( $payload['event'] ) {
			case 'smtp_connection_recovered':
				return sprintf(
					/* translators: 1: connection name, 2: site name, 3: site URL, 4: localized date and time */
					__( 'The %1$s SMTP connection on %2$s (%3$s) is working again as of %4$s.', 'admin-site-enhancements' ),
					$connection_label,
					$site_name,
					$site_url,
					$when
				);
			case 'email_delivered_via_fallback':
				$sentence = sprintf(
					/* translators: 1: site name, 2: site URL, 3: localized date and time */
					__( 'Email delivery on %1$s (%2$s) failed on the primary SMTP connection at %3$s and was sent through the fallback connection.', 'admin-site-enhancements' ),
					$site_name,
					$site_url,
					$when
				);
				break;
			case 'email_delivery_failed':
				$sentence = sprintf(
					/* translators: 1: connection name, 2: site name, 3: site URL, 4: localized date and time */
					__( 'Email delivery on %2$s (%3$s) failed using the %1$s SMTP connection at %4$s.', 'admin-site-enhancements' ),
					$connection_label,
					$site_name,
					$site_url,
					$when
				);
				break;
			default:
				$sentence = sprintf(
					/* translators: 1: connection name, 2: site name, 3: site URL, 4: localized date and time */
					__( 'The %1$s SMTP connection on %2$s (%3$s) failed at %4$s.', 'admin-site-enhancements' ),
					$connection_label,
					$site_name,
					$site_url,
					$when
				);
				break;
		}

		return $sentence . "\n\n" . sprintf(
			/* translators: %s: SMTP or delivery error message */
			__( 'Error: %s', 'admin-site-enhancements' ),
			$error
		) . "\n\n" . __( 'Please check the configuration in ASE\'s Email Delivery module.', 'admin-site-enhancements' );
	}

	/**
	 * Format an alert timestamp with the site date format, time format, and timezone.
	 *
	 * @since 9.2.3
	 *
	 * @param string $occurred_at UTC time from the alert payload, such as 2026-10-16T07:20:14Z.
	 * @return string
	 */
	private function format_alert_datetime( $occurred_at ) {
		$timestamp = strtotime( (string) $occurred_at );

		if ( ! $timestamp ) {
			$timestamp = time();
		}

		$date_format = (string) get_option( 'date_format' );
		$time_format = (string) get_option( 'time_format' );

		if ( '' === $date_format ) {
			$date_format = 'F j, Y';
		}

		if ( '' === $time_format ) {
			$time_format = 'H:i';
		}

		return wp_date( $date_format, $timestamp ) . ' - ' . wp_date( $time_format, $timestamp );
	}

	/**
	 * Subject fragment for an alert event.
	 *
	 * @since 9.2.3
	 *
	 * @param string $event Alert event name.
	 * @return string
	 */
	private function email_subject_label( $event ) {
		switch ( $event ) {
			case 'smtp_connection_recovered':
				return __( 'SMTP connection recovered', 'admin-site-enhancements' );
			case 'email_delivery_failed':
				return __( 'Email delivery failed', 'admin-site-enhancements' );
			case 'email_delivered_via_fallback':
				return __( 'Email sent via fallback SMTP', 'admin-site-enhancements' );
			default:
				return __( 'SMTP connection failed', 'admin-site-enhancements' );
		}
	}

	/**
	 * Choose which SMTP connection should carry the alert email.
	 *
	 * A primary failure is sent through the fallback connection. A fallback
	 * failure is sent through the primary connection. When both failed, delivery
	 * is left on automatic so the fallback can still be tried.
	 *
	 * @since 9.2.3
	 *
	 * @param string $event      Alert event name.
	 * @param string $connection Connection id.
	 * @return string `auto`, `primary_only`, or `fallback_only`.
	 */
	private function mailer_mode_for_alert( $event, $connection ) {
		if ( 'both' === $connection ) {
			return 'auto';
		}

		if ( 'smtp_connection_recovered' === $event ) {
			return 'primary_only';
		}

		if ( 'primary' === $connection ) {
			return 'fallback_only';
		}

		return 'primary_only';
	}

	/**
	 * Saved check frequency, limited to core cron schedules.
	 *
	 * @since 9.2.3
	 *
	 * @return string
	 */
	private function get_frequency() {
		$options   = get_option( ASENHA_SLUG_U, array() );
		$frequency = ( is_array( $options ) && isset( $options['smtp_health_check_frequency'] ) ) ? sanitize_key( (string) $options['smtp_health_check_frequency'] ) : 'hourly';
		$allowed   = array( 'hourly', 'twicedaily', 'daily', 'weekly' );

		if ( ! in_array( $frequency, $allowed, true ) ) {
			$frequency = 'hourly';
		}

		$schedules = wp_get_schedules();

		if ( ! isset( $schedules[ $frequency ] ) ) {
			$frequency = 'hourly';
		}

		return $frequency;
	}

	/**
	 * Site name for alert text, with HTML entities decoded.
	 *
	 * @since 9.2.3
	 *
	 * @return string
	 */
	private function get_site_name() {
		$name = wp_specialchars_decode( (string) get_bloginfo( 'name' ), ENT_QUOTES );
		$name = sanitize_text_field( $name );

		if ( '' === $name ) {
			$name = home_url();
		}

		return $name;
	}

	/**
	 * Remove credentials and tags from an SMTP error before it is stored or sent.
	 *
	 * @since 9.2.3
	 *
	 * @param string $error Raw error.
	 * @return string
	 */
	private function redact_error_message( $error ) {
		$error = wp_strip_all_tags( (string) $error );
		$error = preg_replace( '/(AUTH|PASS)\b[^\r\n]*/i', '$1 [redacted]', $error );

		if ( ! is_string( $error ) ) {
			$error = '';
		}

		foreach ( array( 'primary', 'fallback' ) as $id ) {
			$connection = $this->email_delivery->get_smtp_connection_for_check__premium_only( $id );

			if ( ! is_array( $connection ) ) {
				continue;
			}

			foreach ( array( 'password', 'username' ) as $secret_key ) {
				$secret = isset( $connection[ $secret_key ] ) ? (string) $connection[ $secret_key ] : '';
				$redact = ( 'username' === $secret_key )
					? ( false !== strpos( $secret, '@' ) || strlen( $secret ) >= 8 )
					: ( strlen( $secret ) >= 4 );

				if ( $redact ) {
					$error = str_replace( $secret, '[redacted]', $error );
				}
			}
		}

		$error = sanitize_text_field( $error );

		if ( strlen( $error ) > self::MAX_ERROR_LENGTH ) {
			$error = substr( $error, 0, self::MAX_ERROR_LENGTH );
		}

		return $error;
	}

	/**
	 * A fresh PHPMailer that does not retry through the fallback connection.
	 *
	 * @since 9.2.3
	 *
	 * @return \PHPMailer\PHPMailer\PHPMailer
	 */
	private function create_mailer() {
		if ( ! class_exists( 'PHPMailer\\PHPMailer\\PHPMailer', false ) ) {
			require_once ABSPATH . WPINC . '/PHPMailer/PHPMailer.php';
			require_once ABSPATH . WPINC . '/PHPMailer/SMTP.php';
			require_once ABSPATH . WPINC . '/PHPMailer/Exception.php';
		}

		return new \PHPMailer\PHPMailer\PHPMailer( true );
	}

	/**
	 * One connection row in the settings status field.
	 *
	 * @since 9.2.3
	 *
	 * @param string              $id    Connection id.
	 * @param array<string,mixed> $entry Stored status entry.
	 * @return string
	 */
	private static function render_connection_row( $id, $entry ) {
		$status  = isset( $entry['status'] ) ? (string) $entry['status'] : '';
		$error   = isset( $entry['last_error'] ) ? (string) $entry['last_error'] : '';
		$checked = self::format_checked_at( isset( $entry['last_checked'] ) ? (int) $entry['last_checked'] : 0 );

		$html  = '<div class="asenha-smtp-health-status__row">';
		$html .= '<span class="asenha-smtp-health-status__name">' . esc_html( self::connection_name( $id ) ) . '</span>';
		$html .= '<span id="' . esc_attr( 'smtp-health-check-' . $id . '-status' ) . '" class="asenha-smtp-health-badge ' . esc_attr( self::status_class( $status ) ) . '">' . esc_html( self::status_label( $status ) ) . '</span>';
		$html .= '<span id="' . esc_attr( 'smtp-health-check-' . $id . '-checked' ) . '" class="asenha-smtp-health-status__time">' . esc_html( $checked ) . '</span>';
		$html .= '<span id="' . esc_attr( 'smtp-health-check-' . $id . '-error' ) . '" class="asenha-smtp-health-status__error">' . esc_html( $error ) . '</span>';
		$html .= '</div>';

		return $html;
	}
}
