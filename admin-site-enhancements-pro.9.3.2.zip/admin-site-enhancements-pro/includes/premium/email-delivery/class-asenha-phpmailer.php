<?php
/**
 * PHPMailer subclass that retries a failed delivery once via the fallback SMTP connection.
 *
 * Loaded only for the Pro version, and only while Fallback SMTP is enabled.
 *
 * @package ASENHA
 * @since   9.2.3
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'PHPMailer\PHPMailer\PHPMailer', false ) ) {
	require_once ABSPATH . WPINC . '/PHPMailer/PHPMailer.php';
	require_once ABSPATH . WPINC . '/PHPMailer/SMTP.php';
	require_once ABSPATH . WPINC . '/PHPMailer/Exception.php';
}

if ( ! class_exists( 'WP_PHPMailer', false ) && file_exists( ABSPATH . WPINC . '/class-wp-phpmailer.php' ) ) {
	require_once ABSPATH . WPINC . '/class-wp-phpmailer.php';
}

if ( ! trait_exists( 'ASENHA_PHPMailer_Fallback_Retry', false ) ) {

	/**
	 * Shared send() behavior for the core and legacy PHPMailer parents.
	 *
	 * @since 9.2.3
	 */
	trait ASENHA_PHPMailer_Fallback_Retry {

		/**
		 * How this message should be delivered.
		 *
		 * auto          Primary connection, then one fallback attempt on failure.
		 * primary_only  Primary connection, no retry. Used by the test-email tool.
		 * fallback_only Fallback connection only. Used by the test-email tool.
		 *
		 * @since 9.2.3
		 *
		 * @var string
		 */
		public $mode = 'auto';

		/**
		 * Whether send() is already inside the single fallback attempt.
		 *
		 * @since 9.2.3
		 *
		 * @var bool
		 */
		private $fallback_retry_in_progress = false;

		/**
		 * Send the message, retrying once through the fallback SMTP connection.
		 *
		 * WordPress calls this inside wp_mail()'s try/catch. Retrying here lets
		 * wp_mail() return true when the fallback succeeds, and fires wp_mail_failed
		 * only when both connections fail.
		 *
		 * @since 9.2.3
		 *
		 * @throws \PHPMailer\PHPMailer\Exception When sending fails and exceptions are enabled.
		 * @return bool
		 */
		public function send() {
			if ( $this->fallback_retry_in_progress || 'primary_only' === $this->mode || 'fallback_only' === $this->mode ) {
				return parent::send();
			}

			$primary_exception = null;
			$primary_error     = '';

			try {
				if ( parent::send() ) {
					return true;
				}

				$primary_error = (string) $this->ErrorInfo;
			} catch ( \PHPMailer\PHPMailer\Exception $exception ) {
				$primary_exception = $exception;
				$primary_error     = $exception->getMessage();
			}

			if ( '' === $primary_error ) {
				$primary_error = __( 'Unknown error.', 'admin-site-enhancements' );
			}

			$delivery  = \ASENHA\Classes\Email_Delivery::get_runtime_instance();
			$can_retry = ( $delivery instanceof \ASENHA\Classes\Email_Delivery )
				&& method_exists( $delivery, 'should_retry_via_fallback_smtp__premium_only' )
				&& $delivery->should_retry_via_fallback_smtp__premium_only();

			if ( ! $can_retry ) {
				if ( null !== $primary_exception ) {
					throw $primary_exception;
				}

				if ( $this->exceptions ) {
					throw new \PHPMailer\PHPMailer\Exception( $primary_error );
				}

				return false;
			}

			$this->smtpClose();
			$this->smtp = null;
			$delivery->apply_fallback_smtp_connection__premium_only( $this );

			$this->fallback_retry_in_progress = true;

			try {
				$sent = parent::send();
			} catch ( \PHPMailer\PHPMailer\Exception $fallback_exception ) {
				throw new \PHPMailer\PHPMailer\Exception(
					$this->format_combined_smtp_error( $primary_error, $fallback_exception->getMessage() ),
					(int) $fallback_exception->getCode()
				);
			} finally {
				$this->fallback_retry_in_progress = false;
			}

			if ( ! $sent ) {
				$fallback_error = (string) $this->ErrorInfo;

				if ( '' === $fallback_error ) {
					$fallback_error = __( 'Unknown error.', 'admin-site-enhancements' );
				}

				if ( $this->exceptions ) {
					throw new \PHPMailer\PHPMailer\Exception(
						$this->format_combined_smtp_error( $primary_error, $fallback_error )
					);
				}

				return false;
			}

			if ( method_exists( $delivery, 'mark_log_entry_delivered_via_fallback__premium_only' ) ) {
				$delivery->mark_log_entry_delivered_via_fallback__premium_only( $primary_error );
			}

			if ( method_exists( $delivery, 'notify_smtp_live_failure__premium_only' ) ) {
				$delivery->notify_smtp_live_failure__premium_only( 'primary', $primary_error, 'email_delivered_via_fallback' );
			}

			return true;
		}

		/**
		 * Build the error recorded when both SMTP connections fail.
		 *
		 * @since 9.2.3
		 *
		 * @param string $primary_error  Error from the primary connection.
		 * @param string $fallback_error Error from the fallback connection.
		 * @return string
		 */
		private function format_combined_smtp_error( $primary_error, $fallback_error ) {
			return sprintf(
				/* translators: 1: primary SMTP error, 2: fallback SMTP error */
				__( 'Primary: %1$s | Fallback: %2$s', 'admin-site-enhancements' ),
				$primary_error,
				$fallback_error
			);
		}
	}
}

if ( ! class_exists( 'ASENHA_PHPMailer', false ) ) {
	if ( class_exists( 'WP_PHPMailer', false ) ) {
		/**
		 * Fallback-capable mailer for WordPress 6.8 and newer.
		 *
		 * @since 9.2.3
		 */
		class ASENHA_PHPMailer extends WP_PHPMailer {
			use ASENHA_PHPMailer_Fallback_Retry;
		}
	} else {
		/**
		 * Fallback-capable mailer for WordPress versions without WP_PHPMailer.
		 *
		 * @since 9.2.3
		 */
		class ASENHA_PHPMailer extends PHPMailer\PHPMailer\PHPMailer {
			use ASENHA_PHPMailer_Fallback_Retry;
		}
	}
}
