<?php

use Ase\Integrations\Breakdance\Breakdance_Ase_Field;
use Breakdance\DynamicData\StringField;
use Breakdance\DynamicData\StringData;

class Ase_Url extends StringField {

    /**
     * @var ASE Field
     */
    public array $field;

    /**
     * @param AseString $field
     */
    public function __construct( $field ) {
        $this->field = $field;
    }

    /**
     * @inheritDoc
     */
    public function label() {
        $label = isset( $this->field['label'] ) ? (string) $this->field['label'] : '';

        if ( isset( $this->field['type'] ) && 'map' === $this->field['type'] ) {
            $provider = isset( $this->field['options']['map_provider'] )
                ? (string) $this->field['options']['map_provider']
                : 'openstreetmap';
            $provider_label = ( 'google_maps' === $provider )
                ? __( 'Google Maps', 'admin-site-enhancements' )
                : __( 'OpenStreetMap', 'admin-site-enhancements' );

            return $label . ' [map · ' . $provider_label . ']';
        }

        return $label;
    }

    /**
     * @inheritDoc
     */
    public function category() {
        return 'ASE';
    }

    /**
     * @inheritDoc
     */
    public function subcategory() {
    	if ( $this->field['is_repeater_sub_field'] ) {
	        return $this->field['parent_repeater']; // Repeater name		
    	} else {
	        return $this->field['field_group']; // Field group name		    		
    	}
    }

    /**
     * @inheritDoc
     */
    public function returnTypes() {
        return ['url'];
    }

    /**
     * @inheritDoc
     */
    public function slug() {
        return 'ase_field_url_return_' . $this->field['name'];
    }

    /**
     * @param string $postType
     * @return bool
     */
    public function availableForPostType( $post_type ) {
        if ( isset( $this->field['for_post_types'] ) && in_array( $post_type, $this->field['for_post_types'] ) ) {
            return true;        
        }
        
        if ( isset( $this->field['is_for_an_option_page'] ) && $this->field['is_for_an_option_page'] ) {
            return true;
        }
        
        return false;
    }

    /**
     * @inheritDoc
     */
    public function handler( $attributes ): StringData {
        $post_id = get_the_ID();

        $breakdance_ase_field = new Breakdance_Ase_Field( $post_id, $this->field, 'url' );
        $value = (string) $breakdance_ase_field->get_field_value();

        // Make $value is a string even when it is null. This prevents error in Breakdance editor.
        if ( null === $value ) {
            $value = (string) '';
        }
    	
        return StringData::fromString( $value );
    }
    
}