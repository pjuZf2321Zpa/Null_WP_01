<?php
/**
 * Prepare a Custom Field Group editor save from either the packed JSON payload
 * or the classic per-input POST, and refuse a request that PHP truncated.
 *
 * @package ASENHA
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Maximum accepted size, in bytes, of the packed editor payload.
 */
const CFG_EDITOR_PAYLOAD_MAX_BYTES = 2097152;

/**
 * Decide how a Custom Field Group editor save should be applied.
 *
 * `$cfgroup` is the raw `$_POST['cfgroup']` slice (WordPress-slashed).
 * A packed payload is preferred. Without one, the classic inputs are used
 * only when the end-of-form sentinel arrived, which means PHP did not drop
 * the tail of the request.
 *
 * @param mixed $cfgroup Request slice.
 * @return array {
 *     @type string $status payload|classic|discard
 *     @type string $reason input_vars|payload|''
 *     @type array  $fields Field rows. Slashed, for the existing stripslashes_deep() save path.
 *     @type array  $rules  Placement rules. Payload rules are unslashed; classic rules stay as posted.
 *     @type array  $extras Group settings. Payload extras are unslashed; classic extras stay as posted.
 * }
 */
function cfgroup_prepare_editor_save( $cfgroup ) {
	$discard = array(
		'status' => 'discard',
		'reason' => 'payload',
		'fields' => array(),
		'rules'  => array(),
		'extras' => array(),
	);

	if ( ! is_array( $cfgroup ) ) {
		$discard['reason'] = 'input_vars';
		return $discard;
	}

	$payload = isset( $cfgroup['payload'] ) ? $cfgroup['payload'] : '';

	if ( is_string( $payload ) && '' !== $payload ) {
		$payload = wp_unslash( $payload );

		if ( strlen( $payload ) > CFG_EDITOR_PAYLOAD_MAX_BYTES ) {
			return $discard;
		}

		$decoded = json_decode( $payload, true );

		if ( ! is_array( $decoded ) || cfgroup_editor_save_is_list( $decoded ) ) {
			return $discard;
		}

		$fields = isset( $decoded['fields'] ) && is_array( $decoded['fields'] ) ? $decoded['fields'] : array();
		$rules  = isset( $decoded['rules'] ) && is_array( $decoded['rules'] ) ? $decoded['rules'] : array();
		$extras = isset( $decoded['extras'] ) && is_array( $decoded['extras'] ) ? $decoded['extras'] : array();

		return array(
			'status' => 'payload',
			'reason' => '',
			'fields' => wp_slash( $fields ),
			'rules'  => $rules,
			'extras' => $extras,
		);
	}

	if ( empty( $cfgroup['form_end'] ) ) {
		$discard['reason'] = 'input_vars';
		return $discard;
	}

	return array(
		'status' => 'classic',
		'reason' => '',
		'fields' => isset( $cfgroup['fields'] ) && is_array( $cfgroup['fields'] ) ? $cfgroup['fields'] : array(),
		'rules'  => isset( $cfgroup['rules'] ) && is_array( $cfgroup['rules'] ) ? $cfgroup['rules'] : array(),
		'extras' => isset( $cfgroup['extras'] ) && is_array( $cfgroup['extras'] ) ? $cfgroup['extras'] : array(),
	);
}

/**
 * Whether a decoded JSON value is a list rather than an object.
 *
 * An empty array is treated as a list so `{}` and `[]` are both rejected.
 *
 * @param array $value Decoded JSON value.
 * @return bool
 */
function cfgroup_editor_save_is_list( $value ) {
	$index = 0;

	foreach ( $value as $key => $unused ) {
		if ( $key !== $index ) {
			return false;
		}
		$index++;
	}

	return true;
}
