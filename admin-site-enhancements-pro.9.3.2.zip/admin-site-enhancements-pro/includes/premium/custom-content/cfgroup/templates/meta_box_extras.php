<?php

global $wpdb;

// Post types
$post_types = [];
$types = get_post_types( [ 'public' => true ] );

foreach ( $types as $post_type ) {
    if ( ! in_array( $post_type, [ 'asenha_cfgroup', 'attachment' ] ) ) {
        $post_types[] = $post_type;
    }
}

$extras = (array) get_post_meta( $post->ID, 'cfgroup_extras', true );

$cfgroup_rules_for_ui = (array) get_post_meta( $post->ID, 'cfgroup_rules', true );
$placement_for_ui      = isset( $cfgroup_rules_for_ui['placement']['values'] ) ? $cfgroup_rules_for_ui['placement']['values'] : 'posts';
$show_rest_api_row     = in_array( $placement_for_ui, array( 'posts', 'taxonomy-terms' ), true );

if ( ! isset( $extras['order'] ) ) {
    $extras['order'] = 0;
}
if ( ! isset( $extras['context'] ) ) {
    $extras['context'] = 'normal';
}
if ( ! isset( $extras['hide_editor'] ) ) {
    $extras['hide_editor'] = '';
}
if ( ! isset( $extras['show_in_rest_api'] ) ) {
    $extras['show_in_rest_api'] = '';
}
if ( ! isset( $extras['tab_layout'] ) || ! in_array( $extras['tab_layout'], array( 'horizontal', 'vertical' ), true ) ) {
    $extras['tab_layout'] = 'horizontal';
}

?>

<table>
    <tr>
        <td class="label">
            <label>
                <?php _e( 'Order', 'admin-site-enhancements' ); ?>
                <div class="cfgroup_tooltip">?
                    <div class="tooltip_inner"><?php _e( 'The field group with the lowest order will appear first.', 'admin-site-enhancements' ); ?></div>
                </div>
            </label>
        </td>
        <td style="vertical-align:top">
            <input type="text" name="cfgroup[extras][order]" value="<?php echo $extras['order']; ?>" style="width:80px" />
        </td>
    </tr>
    <tr>
        <td class="label">
            <label><?php _e( 'Position', 'admin-site-enhancements' ); ?></label>
        </td>
        <td style="vertical-align:top">
            <input type="radio" name="cfgroup[extras][context]" value="normal"<?php echo ( $extras['context'] == 'normal' ) ? ' checked' : ''; ?> /> <?php _e( 'Normal', 'admin-site-enhancements' ); ?> &nbsp; &nbsp;
            <input type="radio" name="cfgroup[extras][context]" value="side"<?php echo ( $extras['context'] == 'side' ) ? ' checked' : ''; ?> /> <?php _e( 'Side', 'admin-site-enhancements' ); ?>
        </td>
    </tr>
    <tr>
        <td class="label">
            <label><?php esc_html_e( 'Tab layout', 'admin-site-enhancements' ); ?></label>
        </td>
        <td style="vertical-align:top">
            <input type="radio" name="cfgroup[extras][tab_layout]" value="horizontal" <?php checked( $extras['tab_layout'], 'horizontal' ); ?> /> <?php esc_html_e( 'Horizontal', 'admin-site-enhancements' ); ?> &nbsp; &nbsp;
            <input type="radio" name="cfgroup[extras][tab_layout]" value="vertical" <?php checked( $extras['tab_layout'], 'vertical' ); ?> /> <?php esc_html_e( 'Vertical', 'admin-site-enhancements' ); ?>
            <p class="description"><?php esc_html_e( 'How Tab fields are shown. Vertical places them in a list on the left. Applies when this field group contains Tab fields.', 'admin-site-enhancements' ); ?></p>
        </td>
    </tr>
    <tr>
        <td class="label">
            <label><?php _e( 'Display Settings', 'admin-site-enhancements' ); ?></label>
        </td>
        <td style="vertical-align:top">
            <div>
                <?php
                    CFG()->create_field( [
                        'type'          => 'true_false',
                        'input_name'    => "cfgroup[extras][hide_editor]",
                        'input_class'   => 'true_false',
                        'value'         => $extras['hide_editor'],
                        'options'       => [ 'message' => __( 'Hide the content editor', 'admin-site-enhancements' ) ],
                    ] );
                ?>
            </div>
        </td>
    </tr>
    <tr id="asenha-cfgroup-rest-api-row"<?php echo $show_rest_api_row ? '' : ' style="display:none;"'; ?>>
        <td class="label">
            <label><?php _e( 'REST API', 'admin-site-enhancements' ); ?></label>
        </td>
        <td style="vertical-align:top">
            <div>
                <?php
                    CFG()->create_field( [
                        'type'          => 'true_false',
                        'input_name'    => 'cfgroup[extras][show_in_rest_api]',
                        'input_class'   => 'true_false',
                        'value'         => $extras['show_in_rest_api'],
                        'options'       => [ 'message' => __( 'Show in REST API', 'admin-site-enhancements' ) ],
                    ] );
                ?>
            </div>
        </td>
    </tr>

</table>