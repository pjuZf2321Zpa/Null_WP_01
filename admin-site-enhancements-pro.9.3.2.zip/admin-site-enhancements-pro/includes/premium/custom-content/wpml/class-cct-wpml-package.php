<?php
/**
 * WPML string package helper for ASE Custom Content Types.
 *
 * @package Admin and Site Enhancements
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ASENHA_CCT_WPML_Package {

	const KIND_FIELD_GROUP  = 'asenha-cfgroup-labels';
	const KIND_POST_TYPE    = 'asenha-cpt-labels';
	const KIND_TAXONOMY     = 'asenha-taxonomy-labels';
	const KIND_OPTIONS_PAGE = 'asenha-options-page-labels';
	const STATUS_ST_INACTIVE         = 'st_inactive';
	const STATUS_NOT_REGISTERED      = 'not_registered';
	const STATUS_NOT_TRANSLATED      = 'not_translated';
	const STATUS_PARTIALLY_TRANSLATED = 'partially_translated';
	const STATUS_FULLY_TRANSLATED    = 'fully_translated';

	/**
	 * Package identifier.
	 *
	 * @var string
	 */
	private $package_id;

	/**
	 * Package kind.
	 *
	 * @var string
	 */
	private $package_kind;

	/**
	 * Number of strings registered in the current pass.
	 *
	 * @var int
	 */
	private $registered_strings_count = 0;

	/**
	 * ASE definition post ID backing this package, when known by the caller.
	 *
	 * @var int
	 */
	private $definition_id = 0;

	/**
	 * Per-request cache of full package data, keyed by "kind|package_id".
	 *
	 * @var array<string,array<string,string>>
	 */
	private static $package_data_cache = array();

	/**
	 * Per-request cache of definition lookup maps, keyed by definition post type.
	 * Each map is keyed by the definition's lookup meta value (CPT key, taxonomy key, menu slug).
	 *
	 * @var array<string,array<string,int>>
	 */
	private static $definition_id_maps = array();

	/**
	 * Constructor.
	 *
	 * @param string $package_id    Stable package ID.
	 * @param string $package_kind  Package kind.
	 * @param int    $definition_id Optional ASE definition post ID, which avoids a lookup query.
	 */
	public function __construct( $package_id, $package_kind, $definition_id = 0 ) {
		$this->package_id    = (string) $package_id;
		$this->package_kind  = (string) $package_kind;
		$this->definition_id = absint( $definition_id );
	}

	/**
	 * Clear the per-request package data and definition lookup caches.
	 *
	 * Call this when an ASE definition is saved, trashed or deleted so that
	 * package titles and edit links are resolved again in the same request.
	 *
	 * @return void
	 */
	public static function flush_runtime_cache() {
		self::$package_data_cache = array();
		self::$definition_id_maps = array();
	}

	/**
	 * Register a string inside this package.
	 *
	 * @param string $value String value.
	 * @param array  $meta  String metadata.
	 * @return void
	 */
	public function register_string( $value, $meta ) {
		if ( ! defined( 'WPML_ST_VERSION' ) || '' === (string) $value ) {
			return;
		}

		do_action(
			'wpml_register_string',
			$value,
			$this->get_string_name( $value, $meta ),
			$this->get_package_data(),
			isset( $meta['title'] ) ? $meta['title'] : '',
			isset( $meta['type'] ) ? $meta['type'] : 'LINE'
		);

		++$this->registered_strings_count;
	}

	/**
	 * Translate a string from this package.
	 *
	 * @param string $value String value.
	 * @param array  $meta  String metadata.
	 * @return string
	 */
	public function translate_string( $value, $meta ) {
		if ( ! defined( 'WPML_ST_VERSION' ) || '' === (string) $value ) {
			return $value;
		}

		// WPML resolves translations from kind_slug and name only, so skip title / edit link lookups here.
		return apply_filters(
			'wpml_translate_string',
			$value,
			$this->get_string_name( $value, $meta ),
			$this->get_package_identity()
		);
	}

	/**
	 * Get the stored WPML context for this package.
	 *
	 * @return string
	 */
	public function get_string_context() {
		$package_data = $this->get_package_identity();

		return $package_data['kind_slug'] . '-' . $package_data['name'];
	}

	/**
	 * Build the WPML string name for a package entry.
	 *
	 * @param string $value String value.
	 * @param array  $meta  String metadata.
	 * @return string
	 */
	public function get_string_name_for_meta( $value, $meta ) {
		return $this->get_string_name( $value, $meta );
	}

	/**
	 * Mark the start of a registration run.
	 *
	 * @return void
	 */
	public function start_registration() {
		$this->registered_strings_count = 0;

		if ( defined( 'WPML_ST_VERSION' ) ) {
			do_action( 'wpml_start_string_package_registration', $this->get_package_data() );
		}
	}

	/**
	 * Clean up package strings not re-registered on the current run.
	 *
	 * @return void
	 */
	public function cleanup_unused_strings() {
		if ( defined( 'WPML_ST_VERSION' ) && $this->has_registered_strings() ) {
			do_action( 'wpml_delete_unused_package_strings', $this->get_package_data() );
		}
	}

	/**
	 * Check whether the current pass registered any strings.
	 *
	 * @return bool
	 */
	public function has_registered_strings() {
		return $this->registered_strings_count > 0;
	}

	/**
	 * Get active package kinds as expected by WPML.
	 *
	 * @return array<string,array<string,string>>
	 */
	public static function get_active_package_kinds() {
		$definitions = array();

		foreach ( self::get_package_kind_configurations() as $kind_slug => $config ) {
			$definitions[ $kind_slug ] = array(
				'title'  => $config['kind'],
				'plural' => $config['plural'],
				'slug'   => $kind_slug,
			);
		}

		return $definitions;
	}

	/**
	 * Get the current translation status for this package.
	 *
	 * @return string
	 */
	public function get_status() {
		$package = $this->get_wpml_package();
		if ( ! $package ) {
			return self::STATUS_ST_INACTIVE;
		}

		$strings = $package->get_package_strings();
		if ( ! is_array( $strings ) || empty( $strings ) ) {
			return self::STATUS_NOT_REGISTERED;
		}

		$translated_strings = $package->get_translated_strings( array() );
		if ( ! is_array( $translated_strings ) || empty( $translated_strings ) ) {
			return self::STATUS_NOT_TRANSLATED;
		}

		$secondary_languages_count = $this->get_secondary_languages_count();
		$is_partial                = count( $translated_strings ) < count( $strings );

		if ( $secondary_languages_count > 0 ) {
			foreach ( $strings as $string ) {
				$string_name = isset( $string->name ) ? (string) $string->name : '';
				if ( '' === $string_name ) {
					$is_partial = true;
					continue;
				}

				$string_translations = isset( $translated_strings[ $string_name ] ) && is_array( $translated_strings[ $string_name ] )
					? $translated_strings[ $string_name ]
					: array();

				if ( count( $string_translations ) < $secondary_languages_count ) {
					$is_partial = true;
					break;
				}
			}
		}

		return $is_partial ? self::STATUS_PARTIALLY_TRANSLATED : self::STATUS_FULLY_TRANSLATED;
	}

	/**
	 * Get a user-facing status label.
	 *
	 * @return string
	 */
	public function get_status_label() {
		return self::get_status_label_for( $this->get_status() );
	}

	/**
	 * Map a package status code to label text.
	 *
	 * @param string $status Internal status code.
	 * @return string
	 */
	public static function get_status_label_for( $status ) {
		switch ( $status ) {
			case self::STATUS_FULLY_TRANSLATED:
				return __( 'Complete', 'admin-site-enhancements' );

			case self::STATUS_PARTIALLY_TRANSLATED:
				return __( 'In progress', 'admin-site-enhancements' );

			case self::STATUS_ST_INACTIVE:
				return __( 'WPML String Translation required', 'admin-site-enhancements' );

			case self::STATUS_NOT_REGISTERED:
			case self::STATUS_NOT_TRANSLATED:
			default:
				return __( 'Not translated', 'admin-site-enhancements' );
		}
	}

	/**
	 * Get the WPML dashboard URL for this package kind.
	 *
	 * @return string
	 */
	public function get_translation_dashboard_url() {
		$dashboard_url = '';

		if ( class_exists( 'WPML\\UIPage' ) && method_exists( 'WPML\\UIPage', 'getTMDashboard' ) ) {
			$dashboard_url = admin_url( \WPML\UIPage::getTMDashboard() );
		} elseif ( defined( 'WPML_TM_FOLDER' ) ) {
			$dashboard_url = admin_url( 'admin.php?page=' . trim( WPML_TM_FOLDER, '/' ) . '/menu/main.php' );
		}

		if ( '' === $dashboard_url ) {
			return '';
		}

		return add_query_arg(
			array(
				'sections' => sprintf( 'stringPackage/%s', $this->package_kind ),
			),
			$dashboard_url
		);
	}

	/**
	 * Get the minimal package identity WPML needs to resolve string translations.
	 *
	 * Performs no lookups, so it is safe to call on every runtime translation.
	 *
	 * @return array<string,string>
	 */
	private function get_package_identity() {
		$config = self::get_package_kind_configuration( $this->package_kind );

		return array(
			'kind'      => $config['kind'],
			'kind_slug' => $this->package_kind,
			'name'      => $this->package_id,
		);
	}

	/**
	 * Get full package metadata (including title and edit link) as expected by WPML
	 * when registering strings or reading package records.
	 *
	 * Memoized per request because callers create a new package helper per call.
	 *
	 * @return array<string,string>
	 */
	private function get_package_data() {
		$cache_key = $this->package_kind . '|' . $this->package_id;

		if ( isset( self::$package_data_cache[ $cache_key ] ) ) {
			return self::$package_data_cache[ $cache_key ];
		}

		$config        = self::get_package_kind_configuration( $this->package_kind );
		$definition_id = $this->get_definition_id();

		$package_data          = $this->get_package_identity();
		$package_data['title'] = $this->get_package_title( $config, $definition_id );

		$edit_link = $this->get_package_edit_link( $definition_id );
		if ( '' !== $edit_link ) {
			$package_data['edit_link'] = $edit_link;
		}

		self::$package_data_cache[ $cache_key ] = $package_data;

		return $package_data;
	}

	/**
	 * Get the user-facing package title.
	 *
	 * @param array<string,string> $config        Package-kind configuration.
	 * @param int                  $definition_id Resolved ASE definition post ID, or 0.
	 * @return string
	 */
	private function get_package_title( $config, $definition_id ) {
		if ( self::KIND_FIELD_GROUP === $this->package_kind ) {
			$display_name = $this->get_field_group_post_title( $definition_id );
		} else {
			$lookup = self::get_definition_lookup_configuration( $this->package_kind );
			if ( empty( $lookup ) ) {
				return sprintf( $config['title_tpl'], $this->package_id );
			}

			$display_name = $definition_id > 0
				? trim( (string) get_post_meta( $definition_id, $lookup['title_meta'], true ) )
				: '';
		}

		if ( '' !== $display_name ) {
			return sprintf( $config['title_tpl'], $display_name, $this->package_id );
		}

		return $this->package_id;
	}

	/**
	 * Get the field-group post title for package display.
	 *
	 * @param int $field_group_id Field-group post ID, or 0.
	 * @return string
	 */
	private function get_field_group_post_title( $field_group_id ) {
		if ( $field_group_id <= 0 ) {
			return '';
		}

		$field_group = get_post( $field_group_id );
		if ( ! $field_group instanceof WP_Post ) {
			return '';
		}

		return trim( (string) $field_group->post_title );
	}

	/**
	 * Resolve the ASE definition post ID that backs this package.
	 *
	 * Uses, in order: the field-group ID embedded in the package ID, the definition ID
	 * passed to the constructor, then a per-request lookup map built with one query
	 * per definition post type.
	 *
	 * @return int Definition post ID, or 0 when not found.
	 */
	private function get_definition_id() {
		if ( self::KIND_FIELD_GROUP === $this->package_kind ) {
			if ( preg_match( '/^cfgroup-(\d+)$/', $this->package_id, $matches ) ) {
				return absint( $matches[1] );
			}

			return 0;
		}

		$lookup = self::get_definition_lookup_configuration( $this->package_kind );
		if ( empty( $lookup ) || 0 !== strpos( $this->package_id, $lookup['prefix'] ) ) {
			return 0;
		}

		if ( $this->definition_id > 0 && $lookup['post_type'] === get_post_type( $this->definition_id ) ) {
			return $this->definition_id;
		}

		$lookup_value = (string) substr( $this->package_id, strlen( $lookup['prefix'] ) );
		if ( '' === $lookup_value ) {
			return 0;
		}

		$definition_ids = self::get_definition_id_map( $lookup['post_type'], $lookup['key_meta'] );

		return isset( $definition_ids[ $lookup_value ] ) ? $definition_ids[ $lookup_value ] : 0;
	}

	/**
	 * Get (and memoize) a lookup-value => definition post ID map for one definition post type.
	 *
	 * When several definitions share a lookup value, the most recently published one wins,
	 * matching the previous single-post lookup ordering.
	 *
	 * @param string $post_type Definition post type.
	 * @param string $key_meta  Meta key holding the lookup value.
	 * @return array<string,int>
	 */
	private static function get_definition_id_map( $post_type, $key_meta ) {
		if ( isset( self::$definition_id_maps[ $post_type ] ) ) {
			return self::$definition_id_maps[ $post_type ];
		}

		$definition_ids = array();

		if ( function_exists( 'get_posts' ) ) {
			$post_ids = get_posts(
				array(
					'post_type'              => $post_type,
					'post_status'            => 'any',
					'numberposts'            => -1,
					'fields'                 => 'ids',
					'orderby'                => 'date',
					'order'                  => 'DESC',
					'no_found_rows'          => true,
					'update_post_term_cache' => false,
				)
			);

			if ( ! empty( $post_ids ) ) {
				update_meta_cache( 'post', $post_ids );

				foreach ( $post_ids as $post_id ) {
					$lookup_value = (string) get_post_meta( $post_id, $key_meta, true );
					if ( '' !== $lookup_value && ! isset( $definition_ids[ $lookup_value ] ) ) {
						$definition_ids[ $lookup_value ] = (int) $post_id;
					}
				}
			}
		}

		self::$definition_id_maps[ $post_type ] = $definition_ids;

		return $definition_ids;
	}

	/**
	 * Get definition lookup settings for package kinds backed by an ASE definition post.
	 *
	 * @param string $package_kind Package kind slug.
	 * @return array<string,string> Empty array for kinds without a meta-keyed definition.
	 */
	private static function get_definition_lookup_configuration( $package_kind ) {
		$configurations = array(
			self::KIND_POST_TYPE    => array(
				'prefix'     => 'cpt-',
				'post_type'  => 'asenha_cpt',
				'key_meta'   => 'cpt_key',
				'title_meta' => 'cpt_plural_name',
			),
			self::KIND_TAXONOMY     => array(
				'prefix'     => 'taxonomy-',
				'post_type'  => 'asenha_ctax',
				'key_meta'   => 'ctax_key',
				'title_meta' => 'ctax_plural_name',
			),
			self::KIND_OPTIONS_PAGE => array(
				'prefix'     => 'options-page-',
				'post_type'  => 'options_page_config',
				'key_meta'   => 'options_page_menu_slug',
				'title_meta' => 'options_page_menu_title',
			),
		);

		return isset( $configurations[ $package_kind ] ) ? $configurations[ $package_kind ] : array();
	}

	/**
	 * Build a stable string name for a package entry.
	 *
	 * @param string $value String value.
	 * @param array  $meta  String metadata.
	 * @return string
	 */
	private function get_string_name( $value, $meta ) {
		$namespace = isset( $meta['namespace'] ) ? sanitize_key( $meta['namespace'] ) : 'ase';
		$id        = isset( $meta['id'] ) ? sanitize_key( (string) $meta['id'] ) : 'item';
		$key       = isset( $meta['key'] ) ? sanitize_key( (string) $meta['key'] ) : 'string';

		return $namespace . '-' . $id . '-' . $key . '-' . md5( $value );
	}

	/**
	 * Instantiate the underlying WPML package helper.
	 *
	 * @return WPML_Package|null
	 */
	private function get_wpml_package() {
		if ( ! defined( 'WPML_ST_VERSION' ) || ! class_exists( 'WPML_Package' ) ) {
			return null;
		}

		return new WPML_Package( $this->get_package_data() );
	}

	/**
	 * Get package kind configuration.
	 *
	 * @param string $package_kind Package kind slug.
	 * @return array<string,string>
	 */
	private static function get_package_kind_configuration( $package_kind ) {
		$configurations = self::get_package_kind_configurations();

		if ( isset( $configurations[ $package_kind ] ) ) {
			return $configurations[ $package_kind ];
		}

		return $configurations[ self::KIND_FIELD_GROUP ];
	}

	/**
	 * Get all supported package kind configurations.
	 *
	 * @return array<string,array<string,string>>
	 */
	private static function get_package_kind_configurations() {
		return array(
			self::KIND_FIELD_GROUP  => array(
				'kind'      => 'ASE Field Group Labels',
				'plural'    => 'ASE Field Group Labels',
				'title_tpl' => '%s (%s)',
			),
			self::KIND_POST_TYPE    => array(
				'kind'      => 'ASE Custom Post Type Labels',
				'plural'    => 'ASE Custom Post Type Labels',
				'title_tpl' => '%s (%s)',
			),
			self::KIND_TAXONOMY     => array(
				'kind'      => 'ASE Custom Taxonomy Labels',
				'plural'    => 'ASE Custom Taxonomy Labels',
				'title_tpl' => '%s (%s)',
			),
			self::KIND_OPTIONS_PAGE => array(
				'kind'      => 'ASE Options Page Labels',
				'plural'    => 'ASE Options Page Labels',
				'title_tpl' => '%s (%s)',
			),
		);
	}

	/**
	 * Resolve an edit link for this package when possible.
	 *
	 * @param int $definition_id Resolved ASE definition post ID, or 0.
	 * @return string
	 */
	private function get_package_edit_link( $definition_id ) {
		if ( $definition_id <= 0 || ! function_exists( 'admin_url' ) ) {
			return '';
		}

		return admin_url( 'post.php?post=' . absint( $definition_id ) . '&action=edit' );
	}

	/**
	 * Count secondary WPML languages.
	 *
	 * @return int
	 */
	private function get_secondary_languages_count() {
		$languages = apply_filters(
			'wpml_active_languages',
			null,
			array(
				'skip_missing' => 0,
				'orderby'      => 'code',
			)
		);

		if ( ! is_array( $languages ) || empty( $languages ) ) {
			return 0;
		}

		$default_language = apply_filters( 'wpml_default_language', null );
		$count            = 0;

		foreach ( $languages as $language_code => $language_data ) {
			unset( $language_data );

			if ( (string) $language_code === (string) $default_language ) {
				continue;
			}

			++$count;
		}

		return $count;
	}
}
