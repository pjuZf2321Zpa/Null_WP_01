<?php

/**
 * Recursive directory iterator that skips unreadable / restricted children.
 *
 * Used by Display System Summary (Pro) to avoid fatals from open_basedir
 * restrictions and inaccessible symlinked directories.
 *
 * @package admin-site-enhancements
 */

class IgnorantRecursiveDirectoryIterator extends RecursiveDirectoryIterator {

	/**
	 * Return children, or an empty iterator when the child path is inaccessible.
	 *
	 * @return RecursiveDirectoryIterator|RecursiveArrayIterator
	 */
	#[\ReturnTypeWillChange]
	public function getChildren() {

		try {

			return new IgnorantRecursiveDirectoryIterator( $this->getPathname() );

		} catch ( UnexpectedValueException $e ) {

			return new RecursiveArrayIterator( array() );

		}

	}

}
