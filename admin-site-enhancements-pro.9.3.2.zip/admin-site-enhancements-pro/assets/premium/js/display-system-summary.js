/**
 * Display System Summary — async site size loading for the Dashboard.
 *
 * @package admin-site-enhancements
 */
( function ( $ ) {
	'use strict';

	var pollCount = 0;
	var pollTimer = null;

	function getConfig() {
		return window.asenhaDss || {};
	}

	function $container() {
		return $( '.site-sizes[data-asenha-dss-ready]' );
	}

	function applySizes( sizes ) {
		var $wrap = $container();
		if ( ! $wrap.length || ! sizes ) {
			return;
		}

		$.each( sizes, function ( key, formatted ) {
			$wrap
				.find( '.size-item[data-size-key="' + key + '"] .asenha-dss-value' )
				.text( formatted );
		} );

		$wrap
			.attr( 'data-asenha-dss-ready', '1' )
			.removeClass( 'asenha-dss-calculating asenha-dss-unavailable' )
			.addClass( 'asenha-dss-ready' );
	}

	function markUnavailable() {
		var cfg = getConfig();
		var $wrap = $container();
		if ( ! $wrap.length ) {
			return;
		}

		$wrap.find( '.asenha-dss-value' ).each( function () {
			var $el = $( this );
			if ( $el.text() === cfg.calculating ) {
				$el.text( cfg.unavailable || 'Unavailable' );
			}
		} );

		$wrap
			.removeClass( 'asenha-dss-calculating asenha-dss-ready' )
			.addClass( 'asenha-dss-unavailable' );
	}

	function stopPolling() {
		if ( pollTimer ) {
			clearTimeout( pollTimer );
			pollTimer = null;
		}
	}

	function schedulePoll() {
		var cfg = getConfig();
		var interval = parseInt( cfg.pollInterval, 10 ) || 4000;
		var maxPolls = parseInt( cfg.maxPolls, 10 ) || 45;

		pollCount += 1;
		if ( pollCount > maxPolls ) {
			stopPolling();
			markUnavailable();
			return;
		}

		pollTimer = setTimeout( requestSizes, interval );
	}

	function requestSizes() {
		var cfg = getConfig();
		var $wrap = $container();

		if ( ! $wrap.length ) {
			return;
		}

		if ( $wrap.attr( 'data-asenha-dss-ready' ) === '1' ) {
			stopPolling();
			return;
		}

		if ( ! cfg.ajaxUrl || ! cfg.nonce ) {
			markUnavailable();
			return;
		}

		$.ajax( {
			url: cfg.ajaxUrl,
			type: 'POST',
			dataType: 'json',
			timeout: 120000,
			data: {
				action: 'asenha_dss_get_sizes',
				nonce: cfg.nonce,
			},
		} )
			.done( function ( response ) {
				if ( ! response || ! response.success || ! response.data ) {
					schedulePoll();
					return;
				}

				if ( response.data.status === 'ready' && response.data.sizes ) {
					applySizes( response.data.sizes );
					stopPolling();
					return;
				}

				// Still calculating (or lock held / cron will finish).
				schedulePoll();
			} )
			.fail( function () {
				// Timeout or gateway error: cron fallback may still complete — keep polling.
				schedulePoll();
			} );
	}

	$( function () {
		var $wrap = $container();
		if ( ! $wrap.length ) {
			return;
		}

		// Cache already rendered server-side — nothing to fetch.
		if ( $wrap.attr( 'data-asenha-dss-ready' ) === '1' ) {
			return;
		}

		requestSizes();
	} );
}( jQuery ) );
