<?php

namespace ASENHA\Classes;

/**
 * Class for Disable Updates module
 *
 * @since 6.9.5
 */
class Disable_Updates {

    /**
     * Whether HTTP blocking and cron filters have already been added.
     *
     * @since 9.1.1
     * @var bool
     */
    protected $http_cron_filters_added = false;

    /**
     * Block core version-check HTTP requests.
     *
     * @since 9.1.1
     * @var bool
     */
    protected $block_http_core = false;

    /**
     * Block plugin update-check HTTP requests.
     *
     * @since 9.1.1
     * @var bool
     */
    protected $block_http_plugins = false;

    /**
     * Block theme update-check HTTP requests.
     *
     * @since 9.1.1
     * @var bool
     */
    protected $block_http_themes = false;

    /**
     * Prevent wp_version_check from being scheduled.
     *
     * @since 9.1.1
     * @var bool
     */
    protected $block_cron_core = false;

    /**
     * Prevent wp_update_plugins from being scheduled.
     *
     * @since 9.1.1
     * @var bool
     */
    protected $block_cron_plugins = false;

    /**
     * Prevent wp_update_themes from being scheduled.
     *
     * @since 9.1.1
     * @var bool
     */
    protected $block_cron_themes = false;

    /**
     * Prevent wp_maybe_auto_update from being scheduled.
     *
     * @since 9.1.1
     * @var bool
     */
    protected $block_cron_auto_update = false;

    /**
     * Which admin_init disables to apply for the Pro granular path.
     *
     * @since 9.1.1
     * @var array
     */
    protected $granular_admin_init = array();

    /**
     * Disable updates and related functionalities (free all-in-one path).
     *
     * @since 4.0.0
     */
    public function disable_update_notices_version_checks() {

        $this->disable_update_notices();
        $this->disable_core_update_checks();
        $this->disable_theme_update_checks();
        $this->disable_plugin_update_checks();
        $this->disable_auto_update_cron();
        add_filter( 'site_status_tests', [ $this, 'disable_update_checks_in_site_health' ] );

    }

    /**
     * Remove update and maintenance nags in wp-admin.
     *
     * @since 9.1.1
     */
    public function disable_update_notices() {

        remove_action( 'admin_notices', 'update_nag', 3 );
        remove_action( 'network_admin_notices', 'update_nag', 3 );
        remove_action( 'admin_notices', 'maintenance_nag' );
        remove_action( 'network_admin_notices', 'maintenance_nag' );

    }

    /**
     * Stop WordPress core version checks.
     *
     * @since 9.1.1
     */
    public function disable_core_update_checks() {

        remove_action( 'wp_version_check', 'wp_version_check' );
        remove_action( 'admin_init', 'wp_version_check' );
        remove_action( 'admin_init', '_maybe_update_core' );
        wp_clear_scheduled_hook( 'wp_version_check' );

    }

    /**
     * Stop theme version checks.
     *
     * @since 9.1.1
     */
    public function disable_theme_update_checks() {

        remove_action( 'wp_update_themes', 'wp_update_themes' );
        remove_action( 'admin_init', '_maybe_update_themes' );
        wp_clear_scheduled_hook( 'wp_update_themes' );

        remove_action( 'load-themes.php', 'wp_update_themes' );
        remove_action( 'load-update.php', 'wp_update_themes' );
        remove_action( 'load-update-core.php', 'wp_update_themes' );

    }

    /**
     * Stop plugin version checks.
     *
     * @since 9.1.1
     */
    public function disable_plugin_update_checks() {

        remove_action( 'wp_update_plugins', 'wp_update_plugins' );
        remove_action( 'admin_init', '_maybe_update_plugins' );
        wp_clear_scheduled_hook( 'wp_update_plugins' );

        remove_action( 'load-plugins.php', 'wp_update_plugins' );
        remove_action( 'load-update.php', 'wp_update_plugins' );
        remove_action( 'load-update-core.php', 'wp_update_plugins' );

    }

    /**
     * Stop the automatic updater cron and related admin_init callbacks.
     *
     * @since 9.1.1
     */
    public function disable_auto_update_cron() {

        wp_clear_scheduled_hook( 'wp_maybe_auto_update' );

        remove_action( 'wp_maybe_auto_update', 'wp_maybe_auto_update' );
        remove_action( 'admin_init', 'wp_maybe_auto_update' );
        remove_action( 'admin_init', 'wp_auto_update_core' );

    }

    /**
     * Override version check info stored in transients named update_core, update_plugins, update_themes.
     *
     * @since 4.0.0
     */
    public function override_version_check_info() {

        if ( function_exists( 'wp_get_wp_version' ) ) {
            $wp_version = wp_get_wp_version();
        } else {
            include ABSPATH . WPINC . '/version.php'; // get $wp_version from here
        }

        $current = new \stdClass();
        $current->updates = array();
        $current->response = array();
        $current->no_update = array();
        $current->translations = array();
        $current->checked = array();
        $current->version_checked = $wp_version;
        $current->last_checked = time();

        return $current;

    }

    /**
     * Strip translation offers from an update transient without hiding other updates.
     *
     * @since 9.1.1
     *
     * @param mixed $transient Update transient object or other value.
     * @return mixed
     */
    public function strip_translations_from_transient( $transient ) {

        if ( is_object( $transient ) ) {
            $transient->translations = array();
        }

        return $transient;

    }

    /**
     * Disable Background Updates and Auto-Updates tests in Site Health tests
     *
     * @since 4.0.0
     */
    public function disable_update_checks_in_site_health( $tests ) {

        unset( $tests['async']['background_updates'] );
        unset( $tests['direct']['plugin_theme_auto_updates'] );

        return $tests;

    }

    /**
     * Remove Dashboard >> Updates menu item
     *
     * @since 4.0.0
     */
    public function remove_updates_menu() {
        remove_submenu_page( 'index.php', 'update-core.php' );
    }

    /**
     * Enable HTTP API and cron blocking for selected update components.
     *
     * @since 9.1.1
     *
     * @param array $blocks {
     *     @type bool $core        Block core version checks.
     *     @type bool $plugins     Block plugin update checks.
     *     @type bool $themes      Block theme update checks.
     *     @type bool $auto_update Block the maybe-auto-update cron.
     * }
     */
    public function enable_request_and_cron_blocks( $blocks ) {

        $this->block_http_core        = ! empty( $blocks['core'] );
        $this->block_http_plugins     = ! empty( $blocks['plugins'] );
        $this->block_http_themes      = ! empty( $blocks['themes'] );
        $this->block_cron_core        = ! empty( $blocks['core'] );
        $this->block_cron_plugins     = ! empty( $blocks['plugins'] );
        $this->block_cron_themes      = ! empty( $blocks['themes'] );
        $this->block_cron_auto_update = ! empty( $blocks['auto_update'] );

        if ( $this->http_cron_filters_added ) {
            return;
        }

        if ( $this->block_http_core || $this->block_http_plugins || $this->block_http_themes ) {
            add_filter( 'pre_http_request', [ $this, 'block_update_http_requests' ], 10, 3 );
        }

        if ( $this->block_cron_core || $this->block_cron_plugins || $this->block_cron_themes || $this->block_cron_auto_update ) {
            add_filter( 'schedule_event', [ $this, 'filter_cron_events' ] );
        }

        $this->http_cron_filters_added = true;

    }

    /**
     * Short-circuit wordpress.org update-check HTTP requests.
     *
     * @since 9.1.1
     *
     * @param false|array|\WP_Error $pre  Whether to short-circuit. Default false.
     * @param array                 $args Request arguments.
     * @param string                $url  Request URL.
     * @return false|array|\WP_Error
     */
    public function block_update_http_requests( $pre, $args, $url ) {

        unset( $args );

        if ( empty( $url ) || ! is_string( $url ) ) {
            return $pre;
        }

        $host = wp_parse_url( $url, PHP_URL_HOST );
        if ( empty( $host ) || false === stripos( $host, 'api.wordpress.org' ) ) {
            return $pre;
        }

        $path = (string) wp_parse_url( $url, PHP_URL_PATH );

        if ( $this->block_http_core && (
            false !== stripos( $path, 'core/version-check' ) ||
            false !== stripos( $path, 'browse-happy' ) ||
            false !== stripos( $path, 'serve-happy' )
        ) ) {
            return $this->get_blocked_http_response();
        }

        if ( $this->block_http_plugins && false !== stripos( $path, 'plugins/update-check' ) ) {
            return $this->get_blocked_http_response();
        }

        if ( $this->block_http_themes && false !== stripos( $path, 'themes/update-check' ) ) {
            return $this->get_blocked_http_response();
        }

        return $pre;

    }

    /**
     * Prevent selected update crons from being rescheduled.
     *
     * @since 9.1.1
     *
     * @param object|false $event Cron event object.
     * @return object|false
     */
    public function filter_cron_events( $event ) {

        if ( ! is_object( $event ) || empty( $event->hook ) ) {
            return $event;
        }

        switch ( $event->hook ) {
            case 'wp_version_check':
                if ( $this->block_cron_core ) {
                    return false;
                }
                break;
            case 'wp_update_plugins':
                if ( $this->block_cron_plugins ) {
                    return false;
                }
                break;
            case 'wp_update_themes':
                if ( $this->block_cron_themes ) {
                    return false;
                }
                break;
            case 'wp_maybe_auto_update':
                if ( $this->block_cron_auto_update ) {
                    return false;
                }
                break;
        }

        return $event;

    }

    /**
     * Dummy HTTP response used when an update-check request is blocked.
     *
     * @since 9.1.1
     *
     * @return array
     */
    protected function get_blocked_http_response() {

        return array(
            'headers'  => array(),
            'body'     => '',
            'response' => array(
                'code'    => 200,
                'message' => 'OK',
            ),
            'cookies'  => array(),
            'filename' => null,
        );

    }

    /**
     * Apply Pro granular disable-update settings.
     *
     * @since 9.1.1
     *
     * @param array $options Saved ASE options.
     */
    public function apply_granular_settings__premium_only( $options ) {

        $legacy_all_on = ! array_key_exists( 'disable_updates_core', $options );

        $disable_core         = $legacy_all_on || ! empty( $options['disable_updates_core'] );
        $disable_plugins      = $legacy_all_on || ! empty( $options['disable_updates_plugins'] );
        $disable_themes       = $legacy_all_on || ! empty( $options['disable_updates_themes'] );
        $disable_translations = $legacy_all_on || ! empty( $options['disable_updates_translations'] );

        $disable_auto_core         = $disable_core || $legacy_all_on || ! empty( $options['disable_auto_updates_core'] );
        $disable_auto_plugins      = $disable_plugins || $legacy_all_on || ! empty( $options['disable_auto_updates_plugins'] );
        $disable_auto_themes       = $disable_themes || $legacy_all_on || ! empty( $options['disable_auto_updates_themes'] );
        $disable_auto_translations = $disable_translations || $legacy_all_on || ! empty( $options['disable_auto_updates_translations'] );

        $allow_minor_core = ! $disable_core
            && $disable_auto_core
            && ! empty( $options['disable_auto_updates_core_allow_minor'] );

        $disable_notices       = $legacy_all_on || ! empty( $options['disable_update_notices'] );
        $disable_emails_core   = $legacy_all_on || ! empty( $options['disable_update_emails_core'] );
        $disable_emails_pt     = $legacy_all_on || ! empty( $options['disable_update_emails_plugins_themes'] );
        $disable_menu          = $legacy_all_on || ! empty( $options['disable_updates_menu'] );
        $disable_site_health   = $legacy_all_on || ! empty( $options['disable_updates_site_health'] );

        if ( $disable_core ) {
            add_filter( 'pre_transient_update_core', [ $this, 'override_version_check_info' ] );
            add_filter( 'pre_site_transient_update_core', [ $this, 'override_version_check_info' ] );
        }

        if ( $disable_themes ) {
            add_filter( 'pre_transient_update_themes', [ $this, 'override_version_check_info' ] );
            add_filter( 'pre_site_transient_update_themes', [ $this, 'override_version_check_info' ] );
            add_filter( 'pre_set_site_transient_update_themes', [ $this, 'override_version_check_info' ], 20 );
        }

        if ( $disable_plugins ) {
            add_filter( 'pre_transient_update_plugins', [ $this, 'override_version_check_info' ] );
            add_filter( 'pre_site_transient_update_plugins', [ $this, 'override_version_check_info' ] );
            add_filter( 'pre_set_site_transient_update_plugins', [ $this, 'override_version_check_info' ], 20 );
        }

        if ( $disable_translations ) {
            add_filter( 'site_transient_update_core', [ $this, 'strip_translations_from_transient' ] );
            add_filter( 'site_transient_update_plugins', [ $this, 'strip_translations_from_transient' ] );
            add_filter( 'site_transient_update_themes', [ $this, 'strip_translations_from_transient' ] );
            add_filter( 'auto_update_translation', '__return_false' );
            add_filter( 'async_update_translation', '__return_false' );
        }

        if ( $allow_minor_core ) {
            if ( ! defined( 'WP_AUTO_UPDATE_CORE' ) ) {
                define( 'WP_AUTO_UPDATE_CORE', 'minor' );
            }
            add_filter( 'allow_minor_auto_core_updates', '__return_true' );
            add_filter( 'allow_major_auto_core_updates', '__return_false' );
            add_filter( 'allow_dev_auto_core_updates', '__return_false' );
        } elseif ( $disable_auto_core ) {
            add_filter( 'auto_update_core', '__return_false' );
            add_filter( 'wp_auto_update_core', '__return_false' );
            add_filter( 'allow_minor_auto_core_updates', '__return_false' );
            add_filter( 'allow_major_auto_core_updates', '__return_false' );
            add_filter( 'allow_dev_auto_core_updates', '__return_false' );
        }

        if ( $disable_auto_plugins ) {
            add_filter( 'auto_update_plugin', '__return_false' );
        }

        if ( $disable_auto_themes ) {
            add_filter( 'auto_update_theme', '__return_false' );
        }

        if ( $disable_auto_translations ) {
            add_filter( 'auto_update_translation', '__return_false' );
            add_filter( 'async_update_translation', '__return_false' );
        }

        $all_components_fully_disabled = $disable_core && $disable_plugins && $disable_themes && $disable_translations;
        $all_auto_disabled_no_security = $disable_auto_core && $disable_auto_plugins && $disable_auto_themes && $disable_auto_translations && ! $allow_minor_core;

        if ( $all_components_fully_disabled ) {
            remove_action( 'init', 'wp_schedule_update_checks' );
        }

        if ( $all_auto_disabled_no_security ) {
            add_filter( 'automatic_updater_disabled', '__return_true' );
            if ( ! defined( 'AUTOMATIC_UPDATER_DISABLED' ) ) {
                define( 'AUTOMATIC_UPDATER_DISABLED', true );
            }
            if ( ! defined( 'WP_AUTO_UPDATE_CORE' ) ) {
                define( 'WP_AUTO_UPDATE_CORE', false );
            }
        }

        if ( $disable_emails_core ) {
            add_filter( 'auto_core_update_send_email', '__return_false' );
            add_filter( 'send_core_update_notification_email', '__return_false' );
            add_filter( 'automatic_updates_send_debug_email', '__return_false' );
        }

        if ( $disable_emails_pt ) {
            add_filter( 'auto_plugin_update_send_email', '__return_false' );
            add_filter( 'auto_theme_update_send_email', '__return_false' );
        }

        if ( $disable_menu ) {
            add_action( 'admin_menu', [ $this, 'remove_updates_menu' ] );
        }

        $block_auto_update_cron = ( $disable_auto_core && ! $allow_minor_core ) && $disable_auto_plugins && $disable_auto_themes && $disable_auto_translations;

        $this->enable_request_and_cron_blocks(
            array(
                'core'        => $disable_core,
                'plugins'     => $disable_plugins,
                'themes'      => $disable_themes,
                'auto_update' => $block_auto_update_cron,
            )
        );

        $this->granular_admin_init = array(
            'notices'     => $disable_notices,
            'core'        => $disable_core,
            'plugins'     => $disable_plugins,
            'themes'      => $disable_themes,
            'auto_update' => $block_auto_update_cron,
            'site_health' => $disable_site_health,
        );

        add_action( 'admin_init', [ $this, 'apply_granular_admin_init__premium_only' ] );

    }

    /**
     * Apply Pro granular disable actions that must run on admin_init.
     *
     * @since 9.1.1
     */
    public function apply_granular_admin_init__premium_only() {

        $flags = $this->granular_admin_init;

        if ( ! empty( $flags['notices'] ) ) {
            $this->disable_update_notices();
        }

        if ( ! empty( $flags['core'] ) ) {
            $this->disable_core_update_checks();
        }

        if ( ! empty( $flags['themes'] ) ) {
            $this->disable_theme_update_checks();
        }

        if ( ! empty( $flags['plugins'] ) ) {
            $this->disable_plugin_update_checks();
        }

        if ( ! empty( $flags['auto_update'] ) ) {
            $this->disable_auto_update_cron();
        }

        if ( ! empty( $flags['site_health'] ) ) {
            add_filter( 'site_status_tests', [ $this, 'disable_update_checks_in_site_health' ] );
        }

    }

}
