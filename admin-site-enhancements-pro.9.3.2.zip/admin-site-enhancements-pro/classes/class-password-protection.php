<?php

namespace ASENHA\Classes;

use WP_Error;

/**
 * Class for Password Protection module
 *
 * @since 6.9.5
 */
class Password_Protection {

    /**
     * Whether a failed ?bypass= attempt has already been counted this request.
     *
     * @since 9.1.2
     * @var bool
     */
    private $bypass_failure_counted = false;

    /**
     * Show Password Protection admin bar status icon
     *
     * @since 4.1.0
     */
    public function show_password_protection_admin_bar_icon() {
        add_action( 'wp_before_admin_bar_render', [ $this, 'add_password_protection_admin_bar_item' ] );
        add_action( 'admin_head', [ $this, 'add_password_protection_admin_bar_item_styles' ] );
        add_action( 'wp_head', [ $this, 'add_password_protection_admin_bar_item_styles' ] );
    }

    /**
     * Add WP Admin Bar item
     *
     * @since 4.1.0
     */
    public function add_password_protection_admin_bar_item() {
        global $wp_admin_bar;

        if ( is_user_logged_in() ) {
            if ( current_user_can( 'manage_options' ) ) {
                $wp_admin_bar->add_menu( array(
                    'id'    => 'password_protection',
                    'title' => '',
                    'href'  => admin_url( 'tools.php?page=admin-site-enhancements#utilities' ),
                    'meta'  => array(
                        'title' => __( 'Password protection is currently enabled for this site.', 'admin-site-enhancements' ),
                    ),
                ) );
            }
        }

    }

    /**
     * Add icon and CSS for admin bar item
     *
     * @since 4.1.0
     */
    public function add_password_protection_admin_bar_item_styles() {

        if ( is_user_logged_in() ) {
            if ( current_user_can( 'manage_options' ) ) {

                ?>
                <style>
                    #wp-admin-bar-password_protection { 
                        background-color: #c32121 !important;
                        transition: .25s;
                    }
                    #wp-admin-bar-password_protection > .ab-item { 
                        color: #fff !important;  
                    }
                    #wp-admin-bar-password_protection > .ab-item:before { 
                        content: "\f160"; 
                        top: 2px; 
                        color: #fff !important; 
                        margin-right: 0px; 
                    }
                    #wp-admin-bar-password_protection:hover > .ab-item { 
                        background-color: #af1d1d !important; 
                        color: #fff; 
                    }
                </style>
                <?php

            }
        }

    }

    /**
     * Disable page caching
     *
     * @since 4.1.0
     */
    public function maybe_disable_page_caching() {

        if ( ! defined( 'DONOTCACHEPAGE' ) ) {
            define( 'DONOTCACHEPAGE', true );
        }

    }

    /**
     * Whether the current user can edit content in the block editor.
     *
     * Used by the admin-ajax gate so contributors, authors, editors,
     * page-only roles, and CPT-only roles can use Heartbeat and other AJAX
     * while Password Protection is on. REST allows any logged-in user.
     * The frontend HTML gate still requires an administrator or a valid
     * unlock cookie.
     *
     * @since 9.1.3
     * @return bool
     */
    private function current_user_can_edit_content() {
        if ( ! is_user_logged_in() ) {
            return false;
        }

        if ( current_user_can( 'edit_posts' ) || current_user_can( 'edit_pages' ) ) {
            return true;
        }

        $post_types = get_post_types(
            array(
                'show_ui'      => true,
                'show_in_rest' => true,
            ),
            'objects'
        );

        foreach ( $post_types as $post_type ) {
            if ( ! empty( $post_type->cap->edit_posts ) && current_user_can( $post_type->cap->edit_posts ) ) {
                return true;
            }
        }

        return false;
    }

    /**
     * Determine whether the current request is allowed past the password
     * protection gate. Shared by the template_redirect gate, the REST gate
     * and the admin-ajax gate.
     *
     * @since 9.1.2
     * @return bool True when the request may proceed, false when the gate applies.
     */
    private function is_request_allowed() {
        // Do not gate WP-Cron requests; wp-cron.php must return from bootstrap so core can run scheduled hooks.
        if ( function_exists( 'wp_doing_cron' ) && wp_doing_cron() ) {
            return true;
        }
        if ( defined( 'DOING_CRON' ) && DOING_CRON ) {
            return true;
        }

        // Novamira OAuth discovery and token exchange stay reachable while the site is password protected.
        // MCP Toolkit tool listing stays reachable on its own HTTP endpoint.
        $common_methods = new Common_Methods;
        if ( $common_methods->is_novamira_auth_request() || $common_methods->is_mcp_toolkit_auth_request() ) {
            return true;
        }

        if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
            $common_methods = new Common_Methods;
            if ( $common_methods->is_site_backup_worker_request__premium_only() ) {
                return true;
            }
            if ( $common_methods->is_site_sync_rest_request__premium_only() ) {
                return true;
            }
            if ( $common_methods->is_altcha_challenge_rest_request__premium_only() ) {
                return true;
            }
        }

        $options = get_option( ASENHA_SLUG_U, array() );
        $stored_password = isset( $options['password_protection_password'] ) ? $options['password_protection_password'] : '';

        // When user is logged-in as an administrator
        if ( is_user_logged_in() ) {
            if ( current_user_can( 'manage_options' ) ) {
                return true;
            }
        }

        // When site visitor has entered the correct password, get the auth cookie.
        // The value is a 64-character HMAC, not user text. Do not run it through
        // sanitize_text_field(), which strips %[a-f0-9]{2} octets.
        $auth_cookie = isset( $_COOKIE['asenha_password_protection'] ) ? (string) wp_unslash( $_COOKIE['asenha_password_protection'] ) : '';

        if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {

            // Get array of whitelisted IP addresses
            $ip_address_whitelist_raw = ( isset( $options['password_protection_ip_whitelist'] ) ) ? explode( PHP_EOL, $options['password_protection_ip_whitelist'] ) : array();
            $ip_address_whitelist = array();
            if ( ! empty( $ip_address_whitelist_raw ) ) {
                foreach( $ip_address_whitelist_raw as $ip_address ) {
                    $ip_address_whitelist[] = trim( $ip_address );
                }
            }

            // Get user/visitor IP address
            $common_methods = new Common_Methods;
            $ip_address = $common_methods->get_user_ip_address( 'ip', 'password-protection' );

            // Skip password protection for whitelisted IP addresses
            if ( in_array( $ip_address, $ip_address_whitelist, true ) ) {
                if ( empty( $auth_cookie ) ) {
                    $this->set_auth_cookie( $stored_password );
                }
                return true;
            }

            // Check for password in 'bypass' URL parameter, throttled per IP
            // (keyed separately from the login form) so it cannot be used to
            // sidestep form throttling. A matching password always unlocks,
            // even if the IP is already throttled — the documented share URL
            // must keep working after fat-fingered attempts.
            $password_in_url = ( isset( $_GET['bypass'] ) ) ? sanitize_text_field( wp_unslash( $_GET['bypass'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

            if ( '' !== $password_in_url && '' !== $stored_password ) {
                $bypass_attempts_key = 'asenha_pwd_protect_bypass_' . md5( $ip_address );
                $bypass_attempts     = (int) get_transient( $bypass_attempts_key );

                // Constant-time comparison; loose == would admit type-juggled
                // equivalents like '0123' vs '123' or magic-hash '0e...' strings.
                if ( hash_equals( (string) $stored_password, (string) $password_in_url ) ) {
                    if ( empty( $auth_cookie ) ) {
                        $this->set_auth_cookie( $stored_password );
                    }
                    delete_transient( $bypass_attempts_key );
                    return true;
                }

                if ( $bypass_attempts < 5 ) {
                    // Count at most once per HTTP request so REST preloads
                    // cannot burn the budget on a single typo.
                    if ( ! $this->bypass_failure_counted ) {
                        set_transient( $bypass_attempts_key, $bypass_attempts + 1, 10 * MINUTE_IN_SECONDS );
                        $this->bypass_failure_counted = true;
                    }
                }
            }
        }

        // Compared $auth_cookie against the HMAC set in set_auth_cookie().
        // A bcrypt, phpass, or Argon2 string fails the hex-format check and
        // never reaches a password hasher.
        if ( $this->is_auth_cookie_valid( $auth_cookie, $stored_password ) ) {
            return true;
        }

        if ( $this->is_authentication_ajax_request() ) {
            return true;
        }

        return false;
    }

    /**
     * Whether this admin-ajax request is a login authentication call that must
     * succeed while password protection is on.
     *
     * Wordfence Login Security posts credentials to admin-ajax.php before it
     * shows the 2FA, CAPTCHA, or passkey step. Those actions only authenticate.
     * A non-AJAX request that carries the same action name stays gated.
     *
     * @since 9.1.5
     * @return bool
     */
    private function is_authentication_ajax_request() {
        if ( ! wp_doing_ajax() ) {
            return false;
        }

        // Action name only. Wordfence registers these endpoints with nonce verification disabled.
        $action = isset( $_REQUEST['action'] ) ? sanitize_key( wp_unslash( $_REQUEST['action'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

        if ( '' === $action ) {
            return false;
        }

        $allowed_actions = array(
            'wordfence_ls_authenticate',
            'wordfence_ls_begin_passkey_login',
            'wordfence_ls_finish_passkey_login',
        );

        /**
         * Filters admin-ajax actions allowed through Password Protection.
         *
         * Only authentication actions belong here. A return value that is not
         * an array of strings is ignored, and the default list stays in place.
         *
         * @since 9.1.5
         * @param string[] $allowed_actions Action names.
         */
        $filtered_actions = apply_filters( 'asenha_password_protection_allowed_ajax_actions', $allowed_actions );

        if ( is_array( $filtered_actions ) ) {
            $strings_only = true;

            foreach ( $filtered_actions as $filtered_action ) {
                if ( ! is_string( $filtered_action ) ) {
                    $strings_only = false;
                    break;
                }
            }

            if ( $strings_only ) {
                $allowed_actions = $filtered_actions;
            }
        }

        return in_array( $action, $allowed_actions, true );
    }

    /**
     * Build the session cookie value for a successful unlock.
     *
     * HMAC-SHA256 of the host and site password, keyed with the site auth salt.
     * This is a bearer token, not a password hash: verification is a fixed-time
     * compare and never runs bcrypt, phpass, or Argon2 on a client-supplied value.
     *
     * @since 9.1.5
     * @param string $stored_password The site-wide protection password.
     * @return string 64-character lowercase hex digest.
     */
    private function build_auth_cookie_value( $stored_password ) {
        $host = isset( $_SERVER['HTTP_HOST'] ) ? (string) $_SERVER['HTTP_HOST'] : '';
        return hash_hmac( 'sha256', $host . '__' . $stored_password, wp_salt( 'auth' ) );
    }

    /**
     * Whether the unlock cookie matches the current host and site password.
     *
     * Rejects any value that is not a 64-character lowercase hex digest before
     * comparing, so a bcrypt, phpass, or Argon2 string never reaches a password hasher.
     *
     * @since 9.1.5
     * @param string $auth_cookie     Cookie value.
     * @param string $stored_password The site-wide protection password.
     * @return bool
     */
    private function is_auth_cookie_valid( $auth_cookie, $stored_password ) {
        if ( '' === $stored_password || 1 !== preg_match( '/\A[a-f0-9]{64}\z/', $auth_cookie ) ) {
            return false;
        }

        return hash_equals( $this->build_auth_cookie_value( $stored_password ), $auth_cookie );
    }

    /**
     * Set the password protection auth cookie. The value is an HMAC of the
     * host and site password, keyed with the site auth salt. Secure follows
     * the current connection (is_ssl()) so HTTP responses never send a Secure
     * cookie the browser would discard. TLS-terminating proxies should map
     * X-Forwarded-Proto so is_ssl() is already true on public HTTPS.
     *
     * @since 9.1.2
     * @param string $stored_password The site-wide protection password.
     */
    private function set_auth_cookie( $stored_password ) {
        // $expiration = time() + DAY_IN_SECONDS; // in 24 hours
        $expiration = 0; // by the end of browsing session
        $cookie_value = $this->build_auth_cookie_value( $stored_password );
        $secure = is_ssl();
        setcookie( 'asenha_password_protection', $cookie_value, $expiration, COOKIEPATH, COOKIE_DOMAIN, $secure, true );
        // setcookie() does not populate $_COOKIE; mirror it so same-request
        // REST preloads and admin-ajax see the unlock without ?bypass=.
        $_COOKIE['asenha_password_protection'] = $cookie_value;
    }

    /**
     * Keep the ?bypass= query arg across redirect_canonical so a homepage
     * trailing-slash or scheme redirect does not drop the unlock before
     * the session cookie is stored by the browser.
     *
     * @since 9.1.2
     * @param string|false $redirect_url  Canonical target, or false to skip.
     * @param string       $requested_url Original requested URL.
     * @return string|false
     */
    public function preserve_bypass_query_arg( $redirect_url, $requested_url ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed
        if ( empty( $redirect_url ) ) {
            return $redirect_url;
        }

        $password_in_url = ( isset( $_GET['bypass'] ) ) ? sanitize_text_field( wp_unslash( $_GET['bypass'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

        if ( '' === $password_in_url ) {
            return $redirect_url;
        }

        return add_query_arg( 'bypass', $password_in_url, $redirect_url );
    }

    /**
     * Return 401 for REST API requests when the protection gate applies, since
     * /wp-json/* requests never reach the template_redirect gate.
     *
     * Used on rest_authentication_errors (primary: skips dispatch) and on
     * rest_pre_dispatch at PHP_INT_MAX (defense in depth so a later callback
     * such as ACF_Rest_Api::initialize cannot replace a 401 with null).
     *
     * @since 9.1.2
     * @param mixed $result Prior filter value; passed through when allowed or already a WP_Error.
     * @return mixed Original $result when allowed, WP_Error otherwise.
     */
    public function rest_gate( $result ) {
        if ( is_wp_error( $result ) ) {
            return $result;
        }

        $common_methods = new Common_Methods;
        $common_methods->recover_basic_auth_from_request_headers();

        if ( is_user_logged_in() ) {
            return $result;
        }

        // rest_cookie_check_errors() (priority 100) sets the current user to 0
        // when a login cookie arrives without a REST nonce, as wp-api.js does
        // for its schema fetch. A valid logged-in cookie still means this
        // visitor is logged in, so the site password should not block them.
        // Do not restore the current user: WordPress leaves them at 0 so a
        // missing nonce cannot authorize writes.
        if ( $this->has_valid_logged_in_cookie_for_rest() ) {
            return $result;
        }

        $application_password_error = $common_methods->get_application_password_authentication_error();
        if ( is_wp_error( $application_password_error ) ) {
            return $application_password_error;
        }

        if ( $this->is_request_allowed() ) {
            return $result;
        }

        if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
            if ( $this->is_rest_route_excluded__premium_only() ) {
                return $result;
            }
        }

        return new WP_Error(
            'asenha_password_protection_required',
            __( 'This site is password protected.', 'admin-site-enhancements' ),
            array( 'status' => 401 )
        );
    }

    /**
     * Whether this REST request carries a valid WordPress logged-in cookie.
     *
     * Used only by the REST gate. Does not call wp_set_current_user(), so
     * permission callbacks still see an unauthenticated user when no nonce
     * was sent.
     *
     * @since 9.2.2
     * @return bool
     */
    private function has_valid_logged_in_cookie_for_rest() {
        if ( ! defined( 'LOGGED_IN_COOKIE' ) || empty( $_COOKIE[ LOGGED_IN_COOKIE ] ) ) { // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
            return false;
        }

        $user_id = wp_validate_auth_cookie( '', 'logged_in' );

        return $user_id > 0;
    }

    /**
     * Whether the current REST route matches a Password Protection whitelist entry.
     *
     * Matching copies Disable REST API: one string per line, strip the public
     * wp-json/ prefix, trim slashes, then substring strpos against the
     * internal rest_route. Empty / root /wp-json is never excluded.
     *
     * @since 9.1.3
     * @return bool True when the current route should skip the REST gate.
     */
    private function is_rest_route_excluded__premium_only() {
        if ( ! isset( $GLOBALS['wp']->query_vars['rest_route'] ) ) {
            return false;
        }

        $route = ltrim( (string) $GLOBALS['wp']->query_vars['rest_route'], '/' );
        $route = rtrim( $route, '/' );

        if ( '' === $route ) {
            return false;
        }

        $options = get_option( ASENHA_SLUG_U, array() );
        $excluded_api_routes_raw = ( isset( $options['password_protection_excluded_routes'] ) ) ? explode( PHP_EOL, $options['password_protection_excluded_routes'] ) : array();
        $excluded_api_routes = array();

        if ( ! empty( $excluded_api_routes_raw ) ) {
            $rest_url_prefix = rest_get_url_prefix() . '/';
            foreach ( $excluded_api_routes_raw as $excluded_api_route ) {
                $cleaned = trim( $excluded_api_route );
                if ( '' === $cleaned ) {
                    continue;
                }
                $cleaned = ltrim( $cleaned, '/' );
                if ( 0 === strpos( $cleaned, $rest_url_prefix ) ) {
                    $cleaned = substr( $cleaned, strlen( $rest_url_prefix ) );
                }
                $cleaned = rtrim( $cleaned, '/' );
                if ( '' === $cleaned ) {
                    continue;
                }
                $excluded_api_routes[] = $cleaned;
            }
        }

        if ( empty( $excluded_api_routes ) ) {
            return false;
        }

        foreach ( $excluded_api_routes as $excluded_route ) {
            if ( ! empty( $excluded_route ) && false !== strpos( $route, $excluded_route ) ) {
                return true;
            }
        }

        return false;
    }

    /**
     * Return 401 for admin-ajax.php requests when the protection gate applies,
     * since AJAX requests never reach the template_redirect gate.
     *
     * Hooked on init priority 20 so plugin CPTs are registered before the
     * content-editor capability check.
     *
     * @since 9.1.3
     */
    public function ajax_gate() {
        if ( ! wp_doing_ajax() ) {
            return;
        }

        if ( $this->current_user_can_edit_content() ) {
            return;
        }

        if ( $this->is_request_allowed() ) {
            return;
        }

        wp_die( '', '', array( 'response' => 401 ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    }

    /**
     * Maybe show login form
     *
     * @since 4.1.0
     */
    public function maybe_show_login_form() {
        if ( $this->is_request_allowed() ) {
            return;
        }

        if ( isset( $_REQUEST['protected-page'] ) && 'view' == $_REQUEST['protected-page'] ) {// Show login form

            $password_protected_login_page_template = ASENHA_PATH . 'includes/password-protected-login.php';

            load_template( $password_protected_login_page_template );
            exit();

        } else { // Redirect from current URL to login form

            $current_url = ( is_ssl() ? 'https://' : 'http://' ) . sanitize_text_field( $_SERVER['HTTP_HOST'] ) . sanitize_text_field( $_SERVER['REQUEST_URI'] );

            $args = array(
                'protected-page' => 'view',
                'source'        => urlencode( $current_url ),
            );

            $pwd_protect_login_url = add_query_arg( $args, home_url( '/' ) );

            nocache_headers();
            wp_safe_redirect( $pwd_protect_login_url );
            exit();

        }

    }

    /**
     * Maybe process login to access protected page content
     *
     * @since 4.1.0
     */
    public function maybe_process_login() {

        global $password_protected_errors;
        $password_protected_errors = new WP_Error();

        if ( isset( $_REQUEST['protected_page_pwd'] ) ) {

            $password_input = sanitize_text_field( $_REQUEST['protected_page_pwd'] );

            $options = get_option( ASENHA_SLUG_U, array() );
            $stored_password = isset( $options['password_protection_password'] ) ? $options['password_protection_password'] : '';

            if ( ! empty( $password_input ) ) {

                // Per-IP throttle: 5 attempts per 10 minutes.
                $common_methods = new Common_Methods;
                $ip_address     = $common_methods->get_user_ip_address( 'ip', 'password-protection' );
                $attempts_key   = 'asenha_pwd_protect_' . md5( $ip_address );
                $attempts       = (int) get_transient( $attempts_key );

                if ( $attempts >= 5 ) {
                    $password_protected_errors->add( 'too_many_attempts', __( 'Too many attempts. Please try again in 10 minutes.', 'admin-site-enhancements' ) );
                    return;
                }

                // Constant-time comparison; loose == would admit type-juggled
                // equivalents like '0123' vs '123' or magic-hash '0e...' strings.
                if ( '' !== $stored_password && hash_equals( (string) $stored_password, (string) $password_input ) ) { // Password is correct

                    delete_transient( $attempts_key );

                    // Set auth cookie
                    $this->set_auth_cookie( $stored_password );

                    // Redirect
                    $redirect_to_url = isset( $_REQUEST['source'] ) ? sanitize_url( $_REQUEST['source'] ) : '';
                    wp_safe_redirect( $redirect_to_url );
                    exit();

                } else { // Password is incorrect

                    set_transient( $attempts_key, $attempts + 1, 10 * MINUTE_IN_SECONDS );

                    // Add error message
                    $password_protected_errors->add( 'incorrect_password', __( 'Incorrect password.', 'admin-site-enhancements' ) );

                }

            } else { // Password input is empty

                // Add error message
                $password_protected_errors->add( 'empty_password', __( 'Password can not be empty.', 'admin-site-enhancements' ) );

            }

        }
    }

    /**
     * Add custom login error messages
     *
     * @since 4.1.0
     */
    public function add_login_error_messages() {

        global $password_protected_errors;

        if ( $password_protected_errors->get_error_code() ) {

            $messages = '';
            $errors = '';

            // Extract the error message

            foreach( $password_protected_errors->get_error_codes() as $code ) {

                $severity = $password_protected_errors->get_error_data( $code );

                foreach( $password_protected_errors->get_error_messages( $code ) as $error ) {
                    if ( 'message' == $severity ) {
                        $messages .= $error . '<br />';
                    } else {
                        $errors .= $error . '<br />';
                    }
                }

            }

            // Output the error message

            if ( ! empty( $messages ) ) {
                echo '<p class="message">' . wp_kses_post( $messages ) . '</p>';
            }

            if ( ! empty( $errors ) ) {
                echo '<div id="login_error">' . wp_kses_post( $errors ) . '</div>';
            }

        }

    }    
    
}