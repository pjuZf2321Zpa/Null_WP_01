<?php

namespace ASENHA\Classes;

/**
 * Class for Custom Content Types module
 *
 * @since 6.9.5
 */
class Custom_Content_Types {

    /**
     * Attachment catch-all rule from /%postname%/ that can shadow later CPT singles.
     *
     * @since 8.8.4
     */
    const ATTACHMENT_CATCHALL_RULE = '[^/]+/([^/]+)/?$';

    /**
     * Register CPTs for registering additional custom post types and custom taxonomies
     * 
     * @since 5.1.0
     */
    public function register_asenha_cpts__premium_only() {
        // Custom Post Types
        register_post_type(
            'asenha_cpt',
            array(
                'labels'                => array(
                    'name'                  => __( 'Custom Post Types', 'admin-site-enhancements' ),
                    'singular_name'         => __( 'Custom Post Type', 'admin-site-enhancements' ),
                    'add_new'               => __( 'Add New', 'admin-site-enhancements' ),
                    'add_new_item'          => __( 'Add New Post Type', 'admin-site-enhancements' ),
                    'new_item'              => __( 'New Post Type', 'admin-site-enhancements' ),
                    'edit_item'             => __( 'Edit Post Type', 'admin-site-enhancements' ),
                    'update_item'           => __( 'Update Post Type', 'admin-site-enhancements' ),
                    'view_item'             => __( 'View Post Type', 'admin-site-enhancements' ),
                    'search_items'          => __( 'Search Post Types', 'admin-site-enhancements' ),
                    'not_found'             => __( 'No Custom Post Types found', 'admin-site-enhancements' ),
                    'not_found_in_trash'    => __( 'No Custom Post Types found in Trash', 'admin-site-enhancements' ),
                ),
                'public'            => false,
                'show_ui'           => true,
                'show_in_menu'      => 'options-general.php',
                'hierarchical'      => false,
                // Hide 'title' and 'editor'
                'supports'          => false,
                'rewrite'           => false,
                'query_var'         => false,
                'can_export'        => true,
                // Allow administrator to edit/read/delete without adding custom capabilites
                'map_meta_cap'      => true,
                // Limit CRUD operations to administrators
                'capabilities'      => array(
                    // Meta capabilities.
                    'edit_post'              => 'edit_asenha_cpt',
                    'read_post'              => 'read_asenha_cpt',
                    'delete_post'            => 'delete_asenha_cpt',

                    // Primitive capabilities used outside of map_meta_cap():
                    'edit_posts'             => 'manage_options',
                    'edit_others_posts'      => 'manage_options',
                    'publish_posts'          => 'manage_options',
                    'read_private_posts'     => 'manage_options',

                    // Primitive capabilities used within map_meta_cap():
                    'read'                   => 'read',
                    'delete_posts'           => 'manage_options',
                    'delete_private_posts'   => 'manage_options',
                    'delete_published_posts' => 'manage_options',
                    'delete_others_posts'    => 'manage_options',
                    'edit_private_posts'     => 'manage_options',
                    'edit_published_posts'   => 'manage_options',
                    'create_posts'           => 'manage_options',               
                ),
            )
        );

        // Custom Taxonomies
        register_post_type(
            'asenha_ctax',
            array(
                'labels'                => array(
                    'name'                  => __( 'Custom Taxonomies', 'admin-site-enhancements' ),
                    'singular_name'         => __( 'Custom Taxonomy', 'admin-site-enhancements' ),
                    'add_new'               => __( 'Add New', 'admin-site-enhancements' ),
                    'add_new_item'          => __( 'Add New Taxonomy', 'admin-site-enhancements' ),
                    'edit_item'             => __( 'Edit Taxonomy', 'admin-site-enhancements' ),
                    'new_item'              => __( 'New Taxonomy', 'admin-site-enhancements' ),
                    'view_item'             => __( 'View Taxonomy', 'admin-site-enhancements' ),
                    'search_items'          => __( 'Search Taxonomies', 'admin-site-enhancements' ),
                    'not_found'             => __( 'No Custom Taxonomies found', 'admin-site-enhancements' ),
                    'not_found_in_trash'    => __( 'No Custom Taxonomies found in Trash', 'admin-site-enhancements' ),
                ),
                'public'            => false,
                'show_ui'           => true,
                'show_in_menu'      => 'options-general.php',
                'hierarchical'      => false,
                // Hide 'title' and 'editor'
                'supports'          => false,
                'rewrite'           => false,
                'query_var'         => false,
                'can_export'        => true,
                // Allow administrator to edit/read/delete without adding custom capabilites
                'map_meta_cap'      => true,
                // Limit CRUD operations to administrators
                'capabilities'      => array(
                    // Meta capabilities.
                    'edit_post'              => 'edit_asenha_ctax',
                    'read_post'              => 'read_asenha_ctax',
                    'delete_post'            => 'delete_asenha_ctax',

                    // Primitive capabilities used outside of map_meta_cap():
                    'edit_posts'             => 'manage_options',
                    'edit_others_posts'      => 'manage_options',
                    'publish_posts'          => 'manage_options',
                    'read_private_posts'     => 'manage_options',

                    // Primitive capabilities used within map_meta_cap():
                    'read'                   => 'read',
                    'delete_posts'           => 'manage_options',
                    'delete_private_posts'   => 'manage_options',
                    'delete_published_posts' => 'manage_options',
                    'delete_others_posts'    => 'manage_options',
                    'edit_private_posts'     => 'manage_options',
                    'edit_published_posts'   => 'manage_options',
                    'create_posts'           => 'manage_options',               
                ),
            )
        );

    }

    /**
     * Get featured image labels for a custom post type definition.
     *
     * Blank saved values fall back to the same defaults WordPress uses so the
     * classic editor can still render the meta box title and related strings.
     *
     * @since 8.9.0
     *
     * @param int $definition_post_id ASE CPT definition post ID.
     * @return array<string, string>
     */
    private function get_post_type_featured_image_labels__premium_only( $definition_post_id ) {
        return array(
            'featured_image'        => $this->get_post_type_label_value__premium_only( $definition_post_id, 'cpt_label_featured_image', _x( 'Featured image', 'post' ) ),
            'set_featured_image'    => $this->get_post_type_label_value__premium_only( $definition_post_id, 'cpt_label_set_featured_image', _x( 'Set featured image', 'post' ) ),
            'remove_featured_image' => $this->get_post_type_label_value__premium_only( $definition_post_id, 'cpt_label_remove_featured_image', _x( 'Remove featured image', 'post' ) ),
            'use_featured_image'    => $this->get_post_type_label_value__premium_only( $definition_post_id, 'cpt_label_use_featured_image', _x( 'Use as featured image', 'post' ) ),
        );
    }

    /**
     * Get a CPT label value with fallback for blank saved meta.
     *
     * @since 8.9.0
     *
     * @param int    $definition_post_id ASE CPT definition post ID.
     * @param string $meta_key           Stored meta key.
     * @param string $default_value      Fallback label value.
     * @return string
     */
    private function get_post_type_label_value__premium_only( $definition_post_id, $meta_key, $default_value ) {
        $value = get_post_meta( $definition_post_id, $meta_key, true );

        return '' !== $value ? $value : $default_value;
    }
    
    /**
     * Add meta boxes to the creation screen of CPTs and custom taxonomies
     * 
     * @since 5.1.0
     */
    public function add_meta_boxes_for_asenha_cpts__premium_only() {
        
        add_meta_box(
            'asenha_cpt_meta_box',
            __( 'Post Type Options', 'admin-site-enhancements' ),
            [ $this, 'render_cpt_meta_box__premium_only' ],
            'asenha_cpt',
            'advanced',
            'high'
        );
        
        add_meta_box(
            'asenha_ctax_meta_box',
            __( 'Taxonomy Options', 'admin-site-enhancements' ),
            [ $this, 'render_ctax_meta_box__premium_only' ],
            'asenha_ctax',
            'advanced',
            'high'
        );

        // add_meta_box(
        //  'asenha_cpt_references_meta_box',
        //  'References',
        //  [ $this, 'render_cpt_references_meta_box__premium_only' ],
        //  'asenha_cpt',
        //  'side',
        //  'low'
        // );
        
        // add_meta_box(
        //  'asenha_ctax_references_meta_box',
        //  'References',
        //  [ $this, 'render_ctax_references_meta_box__premium_only' ],
        //  'asenha_ctax',
        //  'side',
        //  'low'
        // );
        
    }
    
    /**
     * Render options for custom post type
     * 
     * @since 5.1.0
     */
    public function render_cpt_meta_box__premium_only() {

        // Get or set the values of CPT fields
        require_once ASENHA_PATH . 'includes/premium/custom-content/cpt/cpt-fields-values.php';

        // Render metabox to input / update CPT fields
        require_once ASENHA_PATH . 'includes/premium/custom-content/cpt/cpt-form-fields.php';
        
    }

    /**
     * Render options for taxonomies
     * 
     * @since 5.1.0
     */
    public function render_ctax_meta_box__premium_only() {

        // Get or set the values of custom taxonomy fields
        require_once ASENHA_PATH . 'includes/premium/custom-content/ctax/ctax-fields-values.php';

        // Render metabox to input / update custom taxonomy fields
        require_once ASENHA_PATH . 'includes/premium/custom-content/ctax/ctax-form-fields.php';

    }

    /**
     * Render documentation metabox for the create CPT screen
     * 
     * @since 5.1.0
     */
    public function render_cpt_references_meta_box__premium_only() {
        ?>
        <div class="tips-wrapper">
            Message about upgrading to ASENHA PRO
            <ul>
                <li><span class="dashicons dashicons-yes"></span> Benefit #1</li>
            </ul>
            <a href="#" class="button">Upgrade Now</a>
        </div>
        <?php
    }
    
    /**
     * Render documentation metabox for the create CPT screen
     * 
     * @since 5.1.0
     */
    public function render_ctax_references_meta_box__premium_only() {
        ?>
        <div class="references-wrapper">
            Message about upgrading to ASENHA PRO
            <ul>
                <li><span class="dashicons dashicons-yes"></span> Benefit #1</li>
            </ul>
            <a href="#" class="button">Upgrade Now</a>
        </div>
        <?php
    }
    
    /**
     * Save fields for custom post types and taxonomies
     * 
     * @link https://developer.wordpress.org/reference/hooks/save_post/
     * @since 5.1.0
     */
    public function save_asenha_cpt_ctax_optionp_fields__premium_only( $post_id, $post, $update ) {

        $common_methods = new Common_Methods;

        // Sanitize and save custom post type, custom taxonomy or options page fields values in post meta
        require_once ASENHA_PATH . 'includes/premium/custom-content/save-cpt-ctax-optionp-fields.php';
        
    }
    
    /**
     * Flush rewrite rules after creating or updating CPTs and custom taxonomies
     * 
     * @since 5.1.0
     */
    public function asenha_cpts_flush_rewrite_rules__premium_only() {
        $options = get_option( ASENHA_SLUG_U );
        
        if ( true === $options['custom_content_types_flush_rewrite_rules_needed'] ) {
            flush_rewrite_rules();
            $options['custom_content_types_flush_rewrite_rules_needed'] = false;
            update_option( ASENHA_SLUG_U, $options, true );
        }
    }

    /**
     * Reorder ASE CCT rewrite rules to prevent front-end 404s on CPT-heavy sites.
     *
     * Pass 1: Promote CCT rules that appear after the /%postname%/ attachment catch-all
     * above it so late-registered CPT singles are not shadowed.
     *
     * Pass 2: Promote Bricks template rules that appear after the attachment catch-all
     * above it so /template/{slug}/ URLs resolve to bricks_template instead of attachment.
     *
     * Pass 3: Promote CCT archive rules above the generic post/page name catch-all when
     * archives register late (after that shadow rule). Rules already before the shadow rule
     * are left untouched (preserves the light-site archive fix).
     *
     * Pass 4: Promote path-style taxonomy rules (e.g. producten/categori/...) above the
     * CPT attachment shadow rule `{cpt-slug}/[^/]+/([^/]+)/?$` when the taxonomy rewrite
     * slug shares that CPT's first path segment. Otherwise parent term archives 404.
     *
     * @since 8.8.4
     *
     * @param array $rules Rewrite rules.
     * @return array
     */
    public function prioritize_cct_rewrite_rules__premium_only( $rules ) {
        if ( empty( $rules ) ) {
            return $rules;
        }

        $markers = $this->get_cct_rewrite_rule_markers__premium_only();

        $has_single_promotion_markers = ! empty( $markers['rewrite_slugs'] )
            || ! empty( $markers['query_vars'] )
            || ! empty( $markers['post_types'] )
            || ! empty( $markers['taxonomies'] );
        $has_archive_promotion_markers = ! empty( $markers['archive_slugs'] );

        if ( isset( $rules[ self::ATTACHMENT_CATCHALL_RULE ] ) ) {
            if ( $has_single_promotion_markers ) {
                $rules = $this->promote_cct_rules_above_attachment_catchall__premium_only( $rules, $markers );
            }

            $rules = $this->promote_bricks_template_rules_above_attachment_catchall__premium_only( $rules );
        }

        if ( $has_archive_promotion_markers ) {
            $rules = $this->promote_cct_archive_rules_above_postname_catchall__premium_only( $rules, $markers );
        }

        if ( ! empty( $markers['path_style_taxonomy_slugs'] ) ) {
            $rules = $this->promote_path_style_taxonomy_rules_above_cpt_attachment__premium_only( $rules, $markers );
        }

        return $rules;
    }

    /**
     * Promote ASE CCT rules that appear after the attachment catch-all above it.
     *
     * @since 8.8.4
     *
     * @param array $rules   Rewrite rules.
     * @param array $markers Marker data from get_cct_rewrite_rule_markers__premium_only().
     * @return array
     */
    private function promote_cct_rules_above_attachment_catchall__premium_only( $rules, $markers ) {
        $before_catchall = array();
        $after_catchall  = array();
        $past_catchall   = false;

        foreach ( $rules as $pattern => $query ) {
            if ( self::ATTACHMENT_CATCHALL_RULE === $pattern ) {
                $past_catchall = true;
                continue;
            }

            if ( $past_catchall ) {
                $after_catchall[ $pattern ] = $query;
            } else {
                $before_catchall[ $pattern ] = $query;
            }
        }

        $cct_after     = array();
        $non_cct_after = array();

        foreach ( $after_catchall as $pattern => $query ) {
            if ( $this->is_cct_rewrite_rule__premium_only( $pattern, $query, $markers ) ) {
                $cct_after[ $pattern ] = $query;
            } else {
                $non_cct_after[ $pattern ] = $query;
            }
        }

        if ( empty( $cct_after ) ) {
            return $rules;
        }

        return array_merge(
            $before_catchall,
            $cct_after,
            array( self::ATTACHMENT_CATCHALL_RULE => $rules[ self::ATTACHMENT_CATCHALL_RULE ] ),
            $non_cct_after
        );
    }

    /**
     * Promote Bricks template rules that appear after the attachment catch-all above it.
     *
     * @since 8.9.1
     *
     * @param array $rules Rewrite rules.
     * @return array
     */
    private function promote_bricks_template_rules_above_attachment_catchall__premium_only( $rules ) {
        $before_catchall = array();
        $after_catchall  = array();
        $past_catchall   = false;

        foreach ( $rules as $pattern => $query ) {
            if ( self::ATTACHMENT_CATCHALL_RULE === $pattern ) {
                $past_catchall = true;
                continue;
            }

            if ( $past_catchall ) {
                $after_catchall[ $pattern ] = $query;
            } else {
                $before_catchall[ $pattern ] = $query;
            }
        }

        $bricks_after     = array();
        $non_bricks_after = array();

        foreach ( $after_catchall as $pattern => $query ) {
            if ( $this->is_bricks_template_rewrite_rule__premium_only( $pattern, $query ) ) {
                $bricks_after[ $pattern ] = $query;
            } else {
                $non_bricks_after[ $pattern ] = $query;
            }
        }

        if ( empty( $bricks_after ) ) {
            return $rules;
        }

        return array_merge(
            $before_catchall,
            $bricks_after,
            array( self::ATTACHMENT_CATCHALL_RULE => $rules[ self::ATTACHMENT_CATCHALL_RULE ] ),
            $non_bricks_after
        );
    }

    /**
     * Promote ASE CCT archive rules above the generic post/page name catch-all.
     *
     * @since 8.9.0
     *
     * @param array $rules   Rewrite rules.
     * @param array $markers Marker data from get_cct_rewrite_rule_markers__premium_only().
     * @return array
     */
    private function promote_cct_archive_rules_above_postname_catchall__premium_only( $rules, $markers ) {
        $archive_rules = array();

        foreach ( $rules as $pattern => $query ) {
            if ( $this->is_cct_archive_rewrite_rule__premium_only( $pattern, $query, $markers ) ) {
                $archive_rules[ $pattern ] = $query;
            }
        }

        if ( empty( $archive_rules ) ) {
            return $rules;
        }

        $shadow_pattern = null;

        foreach ( $rules as $pattern => $query ) {
            if ( $this->is_generic_postname_catchall_rule__premium_only( $pattern, $query ) ) {
                $shadow_pattern = $pattern;
                break;
            }
        }

        if ( null === $shadow_pattern ) {
            return $rules;
        }

        $needs_promotion = false;
        $past_shadow     = false;

        foreach ( $rules as $pattern => $query ) {
            if ( $pattern === $shadow_pattern ) {
                $past_shadow = true;
                continue;
            }

            if ( $past_shadow && isset( $archive_rules[ $pattern ] ) ) {
                $needs_promotion = true;
                break;
            }
        }

        if ( ! $needs_promotion ) {
            return $rules;
        }

        $reordered       = array();
        $inserted_archive = false;

        foreach ( $rules as $pattern => $query ) {
            if ( $pattern === $shadow_pattern && ! $inserted_archive ) {
                foreach ( $archive_rules as $archive_pattern => $archive_query ) {
                    $reordered[ $archive_pattern ] = $archive_query;
                }
                $inserted_archive = true;
            }

            if ( isset( $archive_rules[ $pattern ] ) ) {
                continue;
            }

            $reordered[ $pattern ] = $query;
        }

        return $reordered;
    }

    /**
     * Promote path-style taxonomy rewrite rules above conflicting CPT attachment rules.
     *
     * When a taxonomy rewrite slug is path-style (e.g. producten/categori) and shares its
     * first segment with a CPT rewrite slug (producten), WordPress's CPT attachment rule
     * `producten/[^/]+/([^/]+)/?$` matches parent term URLs before the taxonomy rule.
     *
     * @since 8.9.2
     *
     * @param array $rules   Rewrite rules.
     * @param array $markers Marker data from get_cct_rewrite_rule_markers__premium_only().
     * @return array
     */
    private function promote_path_style_taxonomy_rules_above_cpt_attachment__premium_only( $rules, $markers ) {
        $slugs_by_segment = array();

        foreach ( $markers['path_style_taxonomy_slugs'] as $path_style_slug ) {
            $segments = explode( '/', $path_style_slug );

            if ( empty( $segments[0] ) ) {
                continue;
            }

            $slugs_by_segment[ $segments[0] ][] = $path_style_slug;
        }

        foreach ( $slugs_by_segment as $segment => $path_style_slugs ) {
            $rules = $this->promote_path_style_taxonomy_rules_for_segment__premium_only(
                $rules,
                $segment,
                array_values( array_unique( $path_style_slugs ) )
            );
        }

        return $rules;
    }

    /**
     * Promote path-style taxonomy rules for one CPT path segment above its attachment shadow rule.
     *
     * @since 8.9.2
     *
     * @param array  $rules            Rewrite rules.
     * @param string $segment          First path segment shared with a CPT (e.g. producten).
     * @param array  $path_style_slugs Path-style taxonomy rewrite slugs under that segment.
     * @return array
     */
    private function promote_path_style_taxonomy_rules_for_segment__premium_only( $rules, $segment, $path_style_slugs ) {
        $taxonomy_rules = array();

        foreach ( $rules as $pattern => $query ) {
            if ( $this->is_path_style_taxonomy_rewrite_rule__premium_only( $pattern, $path_style_slugs ) ) {
                $taxonomy_rules[ $pattern ] = $query;
            }
        }

        if ( empty( $taxonomy_rules ) ) {
            return $rules;
        }

        $shadow_pattern = null;

        foreach ( $rules as $pattern => $query ) {
            if ( $this->is_cpt_segment_attachment_shadow_rule__premium_only( $pattern, $query, $segment ) ) {
                $shadow_pattern = $pattern;
                break;
            }
        }

        if ( null === $shadow_pattern ) {
            return $rules;
        }

        $needs_promotion = false;
        $past_shadow     = false;

        foreach ( $rules as $pattern => $query ) {
            if ( $pattern === $shadow_pattern ) {
                $past_shadow = true;
                continue;
            }

            if ( $past_shadow && isset( $taxonomy_rules[ $pattern ] ) ) {
                $needs_promotion = true;
                break;
            }
        }

        if ( ! $needs_promotion ) {
            return $rules;
        }

        $reordered         = array();
        $inserted_taxonomy = false;

        foreach ( $rules as $pattern => $query ) {
            if ( $pattern === $shadow_pattern && ! $inserted_taxonomy ) {
                foreach ( $taxonomy_rules as $taxonomy_pattern => $taxonomy_query ) {
                    $reordered[ $taxonomy_pattern ] = $taxonomy_query;
                }
                $inserted_taxonomy = true;
            }

            if ( isset( $taxonomy_rules[ $pattern ] ) ) {
                continue;
            }

            $reordered[ $pattern ] = $query;
        }

        return $reordered;
    }

    /**
     * Whether a rewrite rule belongs to a path-style taxonomy rewrite slug.
     *
     * @since 8.9.2
     *
     * @param string $pattern          Rewrite pattern.
     * @param array  $path_style_slugs Path-style taxonomy rewrite slugs.
     * @return bool
     */
    private function is_path_style_taxonomy_rewrite_rule__premium_only( $pattern, $path_style_slugs ) {
        foreach ( $path_style_slugs as $path_style_slug ) {
            // Compare against the literal rewrite pattern string (slashes are not regex-escaped there).
            if ( $pattern === $path_style_slug . '/?$' || 0 === strpos( $pattern, $path_style_slug . '/' ) ) {
                return true;
            }
        }

        return false;
    }

    /**
     * Whether a rewrite rule is a CPT attachment shadow for a given path segment.
     *
     * Matches WordPress patterns like `{segment}/[^/]+/([^/]+)/?$` that resolve to
     * attachment= and collide with path-style taxonomy parent term URLs.
     *
     * @since 8.9.2
     *
     * @param string $pattern Rewrite pattern.
     * @param string $query   Rewrite query.
     * @param string $segment CPT rewrite/archive first segment (e.g. producten).
     * @return bool
     */
    private function is_cpt_segment_attachment_shadow_rule__premium_only( $pattern, $query, $segment ) {
        if ( false === strpos( $query, 'attachment=' ) ) {
            return false;
        }

        $quoted_segment = preg_quote( $segment, '/' );

        // Literal rewrite pattern string: segment/[^/]+/([^/]+)...
        // Exclude segment/[^/]+/attachment/... which requires the "attachment" path piece.
        return (bool) preg_match(
            '/^' . $quoted_segment . '\/\[\^\/\]\+\/\(\[\^\/\]\+\)/',
            $pattern
        );
    }

    /**
     * Collect rewrite slugs and query vars for ASE-defined CPTs and taxonomies.
     *
     * @since 8.8.4
     *
     * @return array{
     *     rewrite_slugs: string[],
     *     archive_slugs: string[],
     *     path_style_taxonomy_slugs: string[],
     *     query_vars: string[],
     *     post_types: string[],
     *     taxonomies: string[]
     * }
     */
    private function get_cct_rewrite_rule_markers__premium_only() {
        static $markers = null;

        if ( null !== $markers ) {
            return $markers;
        }

        $markers = array(
            'rewrite_slugs'             => array(),
            'archive_slugs'             => array(),
            'path_style_taxonomy_slugs' => array(),
            'query_vars'                => array(),
            'post_types'                => array(),
            'taxonomies'                => array(),
        );

        $asenha_cpts = get_posts(
            array(
                'numberposts'      => -1,
                'post_type'        => 'asenha_cpt',
                'post_status'      => 'publish',
                'suppress_filters' => false,
                'fields'           => 'ids',
            )
        );

        foreach ( $asenha_cpts as $cpt_id ) {
            if ( ! get_post_meta( $cpt_id, 'cpt_rewrite', true ) ) {
                continue;
            }

            $post_type_key = get_post_meta( $cpt_id, 'cpt_key', true );

            if ( empty( $post_type_key ) ) {
                continue;
            }

            $markers['post_types'][] = $post_type_key;

            $use_custom_slug  = get_post_meta( $cpt_id, 'cpt_use_custom_rewrite_slug', true );
            $custom_slug      = get_post_meta( $cpt_id, 'cpt_rewrite_custom_slug', true );

            if ( $use_custom_slug && empty( $custom_slug ) ) {
                $use_custom_slug = false;
            }

            $rewrite_slug = $this->get_rewrite_slug__premium_only( $use_custom_slug, $custom_slug, $post_type_key );

            $markers['rewrite_slugs'][] = $rewrite_slug;

            if ( get_post_meta( $cpt_id, 'cpt_has_archive', true ) ) {
                $use_custom_archive_slug = get_post_meta( $cpt_id, 'cpt_use_custom_archive_slug', true );
                $archive_slug              = get_post_meta( $cpt_id, 'cpt_has_archive_custom_slug', true );

                if ( $use_custom_archive_slug && ! empty( $archive_slug ) ) {
                    $markers['rewrite_slugs'][] = $archive_slug;
                    $effective_archive_slug     = $archive_slug;
                } else {
                    $effective_archive_slug = $rewrite_slug;
                }

                $markers['archive_slugs'][] = $effective_archive_slug;
            }

            if ( ! get_post_meta( $cpt_id, 'cpt_query_var', true ) ) {
                continue;
            }

            $use_custom_query_var = get_post_meta( $cpt_id, 'cpt_use_custom_query_var_string', true );
            $query_var_string     = get_post_meta( $cpt_id, 'cpt_query_var_string', true );

            if ( $use_custom_query_var && ! empty( $query_var_string ) ) {
                $markers['query_vars'][] = $query_var_string;
            } else {
                $markers['query_vars'][] = $post_type_key;
            }
        }

        $asenha_ctaxs = get_posts(
            array(
                'numberposts'      => -1,
                'post_type'        => 'asenha_ctax',
                'post_status'      => 'publish',
                'suppress_filters' => false,
                'fields'           => 'ids',
            )
        );

        foreach ( $asenha_ctaxs as $ctax_id ) {
            if ( ! get_post_meta( $ctax_id, 'ctax_rewrite', true ) ) {
                continue;
            }

            $taxonomy_key = get_post_meta( $ctax_id, 'ctax_key', true );

            if ( empty( $taxonomy_key ) ) {
                continue;
            }

            $markers['taxonomies'][] = $taxonomy_key;

            $use_custom_slug = get_post_meta( $ctax_id, 'ctax_use_custom_rewrite_slug', true );
            $custom_slug     = get_post_meta( $ctax_id, 'ctax_rewrite_custom_slug', true );

            if ( $use_custom_slug && empty( $custom_slug ) ) {
                $use_custom_slug = false;
            }

            $taxonomy_rewrite_slug      = $this->get_rewrite_slug__premium_only( $use_custom_slug, $custom_slug, $taxonomy_key );
            $markers['rewrite_slugs'][] = $taxonomy_rewrite_slug;

            if ( false !== strpos( $taxonomy_rewrite_slug, '/' ) ) {
                $markers['path_style_taxonomy_slugs'][] = $taxonomy_rewrite_slug;
            }

            if ( ! get_post_meta( $ctax_id, 'ctax_query_var', true ) ) {
                continue;
            }

            $use_custom_query_var = get_post_meta( $ctax_id, 'ctax_use_custom_query_var_string', true );
            $query_var_string     = get_post_meta( $ctax_id, 'ctax_query_var_string', true );

            if ( $use_custom_query_var && ! empty( $query_var_string ) ) {
                $markers['query_vars'][] = $query_var_string;
            } else {
                $markers['query_vars'][] = $taxonomy_key;
            }
        }

        $markers['rewrite_slugs']             = array_values( array_unique( array_filter( $markers['rewrite_slugs'] ) ) );
        $markers['archive_slugs']             = array_values( array_unique( array_filter( $markers['archive_slugs'] ) ) );
        $markers['path_style_taxonomy_slugs'] = array_values( array_unique( array_filter( $markers['path_style_taxonomy_slugs'] ) ) );
        $markers['query_vars']                = array_values( array_unique( array_filter( $markers['query_vars'] ) ) );
        $markers['post_types']                = array_values( array_unique( array_filter( $markers['post_types'] ) ) );
        $markers['taxonomies']                = array_values( array_unique( array_filter( $markers['taxonomies'] ) ) );

        return $markers;
    }

    /**
     * Determine whether a rewrite rule belongs to an ASE-defined CPT or taxonomy.
     *
     * @since 8.8.4
     *
     * @param string $pattern Rewrite pattern.
     * @param string $query   Rewrite query.
     * @param array  $markers Marker data from get_cct_rewrite_rule_markers__premium_only().
     * @return bool
     */
    private function is_cct_rewrite_rule__premium_only( $pattern, $query, $markers ) {
        foreach ( $markers['post_types'] as $post_type ) {
            if ( false !== strpos( $query, 'post_type=' . $post_type ) ) {
                return true;
            }
        }

        foreach ( $markers['taxonomies'] as $taxonomy ) {
            if ( false !== strpos( $query, 'taxonomy=' . $taxonomy ) || preg_match( '/(^|&)' . preg_quote( $taxonomy, '/' ) . '=/', $query ) ) {
                return true;
            }
        }

        foreach ( $markers['query_vars'] as $query_var ) {
            if ( preg_match( '/(^|&)' . preg_quote( $query_var, '/' ) . '=/', $query ) ) {
                return true;
            }
        }

        foreach ( $markers['rewrite_slugs'] as $rewrite_slug ) {
            $quoted_slug = preg_quote( $rewrite_slug, '/' );

            if ( $pattern === $quoted_slug . '/?$' || 0 === strpos( $pattern, $quoted_slug . '/' ) ) {
                return true;
            }
        }

        return false;
    }

    /**
     * Determine whether a rewrite rule belongs to the Bricks template post type.
     *
     * @since 8.9.1
     *
     * @param string $pattern Rewrite pattern.
     * @param string $query   Rewrite query.
     * @return bool
     */
    private function is_bricks_template_rewrite_rule__premium_only( $pattern, $query ) {
        $is_builder_template_rule = apply_filters( 'asenha_cct_is_builder_template_rewrite_rule', false, $pattern, $query );

        if ( $is_builder_template_rule ) {
            return true;
        }

        if ( ! post_type_exists( 'bricks_template' ) ) {
            return false;
        }

        return false !== strpos( $query, 'bricks_template=' );
    }

    /**
     * Determine whether a rewrite rule is an ASE-defined CPT archive rule.
     *
     * @since 8.9.0
     *
     * @param string $pattern Rewrite pattern.
     * @param string $query   Rewrite query.
     * @param array  $markers Marker data from get_cct_rewrite_rule_markers__premium_only().
     * @return bool
     */
    private function is_cct_archive_rewrite_rule__premium_only( $pattern, $query, $markers ) {
        $is_post_type_archive = false;

        foreach ( $markers['post_types'] as $post_type ) {
            if ( false !== strpos( $query, 'post_type=' . $post_type ) ) {
                $is_post_type_archive = true;
                break;
            }
        }

        if ( ! $is_post_type_archive ) {
            return false;
        }

        foreach ( $markers['query_vars'] as $query_var ) {
            if ( preg_match( '/(^|&)' . preg_quote( $query_var, '/' ) . '=/', $query ) ) {
                return false;
            }
        }

        foreach ( $markers['archive_slugs'] as $archive_slug ) {
            $quoted_slug = preg_quote( $archive_slug, '/' );

            if ( $pattern === $quoted_slug . '/?$' || 0 === strpos( $pattern, $quoted_slug . '/' ) ) {
                return true;
            }
        }

        return false;
    }

    /**
     * Determine whether a rewrite rule is the generic post/page name catch-all.
     *
     * @since 8.9.0
     *
     * @param string $pattern Rewrite pattern.
     * @param string $query   Rewrite query.
     * @return bool
     */
    private function is_generic_postname_catchall_rule__premium_only( $pattern, $query ) {
        if ( false === strpos( $query, 'name=$matches[1]' ) && false === strpos( $query, 'name=$1' ) ) {
            return false;
        }

        $single_segment_patterns = array(
            '([^/]+)/?$',
            '([^/]+)(?:/([0-9]+))?/?$',
        );

        return in_array( $pattern, $single_segment_patterns, true );
    }

    /**
     * Get a safe rewrite slug for a custom content object.
     * CPT and taxonomy rewrite slugs fall back to their object keys instead of ever producing an empty/root-level slug.
     *
     * @since 7.9.0
     *
     * @param bool   $use_custom_slug Whether a custom slug should be used.
     * @param string $custom_slug     Custom slug entered in the UI.
     * @param string $fallback_slug   Object key to fall back to.
     * @return string
     */
    private function get_rewrite_slug__premium_only( $use_custom_slug, $custom_slug, $fallback_slug ) {
        if ( $use_custom_slug && ! empty( $custom_slug ) ) {
            return $custom_slug;
        }

        return $fallback_slug;
    }

    /**
     * Convert a saved endpoint mask constant name into its integer value.
     *
     * @since 7.9.0
     *
     * @param bool   $ep_mask_enabled  Whether the endpoint mask option is enabled.
     * @param string $ep_mask_constant Endpoint mask constant name, e.g. EP_PERMALINK.
     * @return int|null
     */
    private function get_rewrite_ep_mask__premium_only( $ep_mask_enabled, $ep_mask_constant ) {
        if ( ! $ep_mask_enabled || empty( $ep_mask_constant ) ) {
            return null;
        }

        if ( 0 !== strpos( $ep_mask_constant, 'EP_' ) || ! defined( $ep_mask_constant ) ) {
            return null;
        }

        $ep_mask = constant( $ep_mask_constant );

        if ( ! is_int( $ep_mask ) ) {
            return null;
        }

        return $ep_mask;
    }
    
    /**
     * Register CPTs and custom taxonomies created by custom content module
     * 
     * @since 5.1.0
     */
    public function register_cpts_and_ctaxs_created_by_asenha__premium_only() {
        
        // ====== REGISTER CPTS ======
        
        // Get CPT posts in wp_posts table added via Settings >> Custom Post Types
        $asenha_cpts_posts = get_posts( array(
            'numberposts'       => -1,
            'post_type'         => 'asenha_cpt',
            'post_status'       => 'publish',
            'suppress_filters'  => false,       
        ) );

        // Get CPT posts meta and use them to register the CPTs
        if ( $asenha_cpts_posts ) {
            foreach( $asenha_cpts_posts as $asenha_cpt ) {
                
                $post_type_key = get_post_meta( $asenha_cpt->ID, 'cpt_key', true );
                
                // --- Set LABELS ---

                $featured_image_labels = $this->get_post_type_featured_image_labels__premium_only( $asenha_cpt->ID );

                $labels = array(
                    'name'                      => get_post_meta( $asenha_cpt->ID, 'cpt_plural_name', true ),
                    'singular_name'             => get_post_meta( $asenha_cpt->ID, 'cpt_singular_name', true ),
                    'add_new'                   => get_post_meta( $asenha_cpt->ID, 'cpt_label_add_new', true ),
                    'add_new_item'              => get_post_meta( $asenha_cpt->ID, 'cpt_label_add_new_item', true ),
                    'edit_item'                 => get_post_meta( $asenha_cpt->ID, 'cpt_label_edit_item', true ),
                    'new_item'                  => get_post_meta( $asenha_cpt->ID, 'cpt_label_new_item', true ),
                    'view_item'                 => get_post_meta( $asenha_cpt->ID, 'cpt_label_view_item', true ),
                    'view_items'                => get_post_meta( $asenha_cpt->ID, 'cpt_label_view_items', true ),
                    'search_items'              => get_post_meta( $asenha_cpt->ID, 'cpt_label_search_items', true ),
                    'not_found'                 => get_post_meta( $asenha_cpt->ID, 'cpt_label_not_found', true ),
                    'not_found_in_trash'        => get_post_meta( $asenha_cpt->ID, 'cpt_label_not_found_in_trash', true ),
                    'parent_item_colon'         => get_post_meta( $asenha_cpt->ID, 'cpt_label_parent_item_colon', true ),
                    'all_items'                 => get_post_meta( $asenha_cpt->ID, 'cpt_label_all_items', true ),
                    'archives'                  => get_post_meta( $asenha_cpt->ID, 'cpt_label_archives', true ),
                    'attributes'                => get_post_meta( $asenha_cpt->ID, 'cpt_label_attributes', true ),
                    'insert_into_item'          => get_post_meta( $asenha_cpt->ID, 'cpt_label_insert_into_item', true ),
                    'uploaded_to_this_item'     => get_post_meta( $asenha_cpt->ID, 'cpt_label_uploaded_to_this_item', true ),
                    'featured_image'            => $featured_image_labels['featured_image'],
                    'set_featured_image'        => $featured_image_labels['set_featured_image'],
                    'remove_featured_image'     => $featured_image_labels['remove_featured_image'],
                    'use_featured_image'        => $featured_image_labels['use_featured_image'],
                    'menu_name'                 => get_post_meta( $asenha_cpt->ID, 'cpt_label_menu_name', true ),
                    'filter_items_list'         => get_post_meta( $asenha_cpt->ID, 'cpt_label_filter_items_list', true ),
                    'filter_by_date'            => get_post_meta( $asenha_cpt->ID, 'cpt_label_filter_by_date', true ),
                    'items_list_navigation'     => get_post_meta( $asenha_cpt->ID, 'cpt_label_items_list_navigation', true ),
                    'items_list'                => get_post_meta( $asenha_cpt->ID, 'cpt_label_items_list', true ),
                    'item_published'            => get_post_meta( $asenha_cpt->ID, 'cpt_label_item_published', true ),
                    'item_published_privately'  => get_post_meta( $asenha_cpt->ID, 'cpt_label_item_published_privately', true ),
                    'item_reverted_to_draft'    => get_post_meta( $asenha_cpt->ID, 'cpt_label_item_reverted_to_draft', true ),
                    'item_scheduled'            => get_post_meta( $asenha_cpt->ID, 'cpt_label_item_scheduled', true ),
                    'item_updated'              => get_post_meta( $asenha_cpt->ID, 'cpt_label_item_updated', true ),
                    'item_link'                 => get_post_meta( $asenha_cpt->ID, 'cpt_label_item_link', true ),
                    'item_link_description'     => get_post_meta( $asenha_cpt->ID, 'cpt_label_item_link_description', true ),
                );

                $labels = \ASENHA_CCT_Label_Context::filter_post_type_labels( $labels, (int) $asenha_cpt->ID );

                // --- Set ARGS ---
                
                // Get capability type

                $cpt_capability_type = get_post_meta( $asenha_cpt->ID, 'cpt_capability_type', true );
                $cpt_custom_cap_slug_singular = get_post_meta( $asenha_cpt->ID, 'cpt_capability_type_custom_slug_singular', true );
                $cpt_custom_cap_slug_plural = get_post_meta( $asenha_cpt->ID, 'cpt_capability_type_custom_slug_plural', true );

                if ( $cpt_capability_type == 'post' || $cpt_capability_type == 'page' ) {
                    $capability_type = $cpt_capability_type;
                } elseif ( $cpt_capability_type == 'custom' ) {
                    if ( ! empty( $cpt_custom_cap_slug_singular ) && ! empty( $cpt_custom_cap_slug_plural ) ) {
                        $capability_type = array( $cpt_custom_cap_slug_singular, $cpt_custom_cap_slug_plural );                 
                    } else if ( ! empty( $cpt_custom_cap_slug_singular )  && empty( $cpt_custom_cap_slug_plural ) ) {
                        $capability_type = $cpt_custom_cap_slug_singular;
                    } else {
                        $capability_type = 'post';
                    }
                } else {
                    $capability_type = 'post';
                }
                
                // Define query_var value to use
                
                $cpt_query_var = get_post_meta( $asenha_cpt->ID, 'cpt_query_var', true );
                $cpt_use_custom_query_var_string = get_post_meta( $asenha_cpt->ID, 'cpt_use_custom_query_var_string', true );
                $cpt_query_var_string = get_post_meta( $asenha_cpt->ID, 'cpt_query_var_string', true );

                if ( $cpt_query_var ) {
                    if ( $cpt_use_custom_query_var_string ) {
                        if ( ! empty( $cpt_query_var_string ) ) {
                            $query_var = $cpt_query_var_string;
                        } else {
                            $query_var = true;
                        }
                    } else {
                        $query_var = true;
                    }
                } else {
                    $query_var = false;
                }

                // Define has_archive value to use
                
                $cpt_has_archive = get_post_meta( $asenha_cpt->ID, 'cpt_has_archive', true );
                $cpt_use_custom_archive_slug = get_post_meta( $asenha_cpt->ID, 'cpt_use_custom_archive_slug', true );
                $cpt_has_archive_custom_slug = get_post_meta( $asenha_cpt->ID, 'cpt_has_archive_custom_slug', true );

                if ( $cpt_has_archive ) {
                    if ( $cpt_use_custom_archive_slug ) {
                        if ( ! empty( $cpt_has_archive_custom_slug ) ) {
                            $has_archive = $cpt_has_archive_custom_slug;
                        } else {
                            $has_archive = true;
                        }
                    } else {
                        $has_archive = true;
                    }
                } else {
                    $has_archive = false;
                }
                
                // Define rewrite value to use

                $cpt_rewrite = get_post_meta( $asenha_cpt->ID, 'cpt_rewrite', true );
                $cpt_use_custom_rewrite_slug = get_post_meta( $asenha_cpt->ID, 'cpt_use_custom_rewrite_slug', true );
                $cpt_rewrite_custom_slug = get_post_meta( $asenha_cpt->ID, 'cpt_rewrite_custom_slug', true );
                $cpt_with_front = ( '1' == get_post_meta( $asenha_cpt->ID, 'cpt_with_front', true ) ) ? true : false;
                $cpt_feeds = ( '1' == get_post_meta( $asenha_cpt->ID, 'cpt_feeds', true ) ) ? true : false;
                $cpt_pages = ( '1' == get_post_meta( $asenha_cpt->ID, 'cpt_pages', true ) ) ? true : false;
                $cpt_ep_mask = get_post_meta( $asenha_cpt->ID, 'cpt_ep_mask', true );
                $cpt_ep_mask_custom = get_post_meta( $asenha_cpt->ID, 'cpt_ep_mask_custom', true );

                // Treat custom slug toggle as disabled when the slug value is empty,
                // and persist the correction so stale meta doesn't keep entering the array branch.
                if ( $cpt_use_custom_rewrite_slug && empty( $cpt_rewrite_custom_slug ) ) {
                    $cpt_use_custom_rewrite_slug = false;
                    update_post_meta( $asenha_cpt->ID, 'cpt_use_custom_rewrite_slug', false );
                }

                $rewrite_slug = $this->get_rewrite_slug__premium_only( $cpt_use_custom_rewrite_slug, $cpt_rewrite_custom_slug, $post_type_key );
                $rewrite_ep_mask = $this->get_rewrite_ep_mask__premium_only( $cpt_ep_mask, $cpt_ep_mask_custom );

                if ( $cpt_rewrite ) {
                    if ( $cpt_use_custom_rewrite_slug || $cpt_with_front || $cpt_pages || $cpt_ep_mask ) {
                        $rewrite = array(
                            'slug'          => $rewrite_slug,
                            'with_front'    => $cpt_with_front,
                            'feeds'         => $cpt_feeds,
                            'pages'         => $cpt_pages,
                        );
                        if ( null !== $rewrite_ep_mask ) {
                            $rewrite['ep_mask'] = $rewrite_ep_mask;
                        }
                    } else {
                        $rewrite = true;
                    }
                } else {
                    $rewrite = false;
                }
                
                // Supports
                $cpt_supports_raw = get_post_meta( $asenha_cpt->ID, 'cpt_supports', true );
                if ( is_array( $cpt_supports_raw ) && in_array( 'none', $cpt_supports_raw ) ) {
                    $supports = false;
                } else {
                    $supports = $cpt_supports_raw;
                }

                $menu_icon = get_post_meta( $asenha_cpt->ID, 'cpt_menu_icon', true );
                if ( is_string( $menu_icon ) && ( 0 === strpos( $menu_icon, 'data:image/svg+xml' ) ) ) {
                    Admin_Menu_Svg_Icon_Mask::register_post_type_svg_icon( $post_type_key, $menu_icon );
                    $menu_icon = 'dashicons-admin-generic';
                }

                $args = array(
                    'labels'                => $labels,
                    'public'                => ( '1' == get_post_meta( $asenha_cpt->ID, 'cpt_public', true ) ) ? true : false,
                    'hierarchical'          => ( '1' == get_post_meta( $asenha_cpt->ID, 'cpt_hierarchical', true ) ) ? true : false,
                    'capability_type'       => $capability_type,
                    'map_meta_cap'          => ( '1' == get_post_meta( $asenha_cpt->ID, 'cpt_map_meta_cap', true ) ) ? true : NULL,
                    'supports'              => $supports,
                    'taxonomies'            => get_post_meta( $asenha_cpt->ID, 'cpt_taxonomies', true ),
                    'show_ui'               => ( '1' == get_post_meta( $asenha_cpt->ID, 'cpt_show_ui', true ) ) ? true : false,
                    'show_in_menu'          => ( '1' == get_post_meta( $asenha_cpt->ID, 'cpt_show_in_menu', true ) ) ? true : false,
                    'menu_position'         => 5,
                    'menu_icon'             => $menu_icon,
                    'show_in_admin_bar'     => ( '1' == get_post_meta( $asenha_cpt->ID, 'cpt_show_in_admin_bar', true ) ) ? true : false,
                    'show_in_nav_menus'     => ( '1' == get_post_meta( $asenha_cpt->ID, 'cpt_show_in_nav_menus', true ) ) ? true : false,
                    'can_export'            => ( '1' == get_post_meta( $asenha_cpt->ID, 'cpt_can_export', true ) ) ? true : false,
                    'delete_with_user'      => ( '1' == get_post_meta( $asenha_cpt->ID, 'cpt_delete_with_user', true ) ) ? true : false,
                    'publicly_queryable'    => ( '1' == get_post_meta( $asenha_cpt->ID, 'cpt_publicly_queryable', true ) ) ? true : false,
                    'query_var'             => $query_var,
                    'has_archive'           => $has_archive,
                    'rewrite'               => $rewrite,
                    'show_in_rest'          => ( '1' == get_post_meta( $asenha_cpt->ID, 'cpt_show_in_rest', true ) ) ? true : false,
                );
                
                if ( ! empty( get_post_meta( $asenha_cpt->ID, 'cpt_rest_base', true ) ) ) {
                    $args['rest_base'] = get_post_meta( $asenha_cpt->ID, 'cpt_rest_base', true );
                }

                if ( ! empty( get_post_meta( $asenha_cpt->ID, 'cpt_rest_base', true ) ) ) {
                    $args['rest_namespace'] = get_post_meta( $asenha_cpt->ID, 'cpt_rest_namespace', true );
                }

                if ( ! empty( get_post_meta( $asenha_cpt->ID, 'cpt_rest_base', true ) ) ) {
                    $args['rest_controller_class'] = get_post_meta( $asenha_cpt->ID, 'cpt_rest_controller_class', true );
                }

                $labels = apply_filters( 'asenha_cct_registered_post_type_labels', $labels, $args, (int) $asenha_cpt->ID, $post_type_key );
                $args   = apply_filters( 'asenha_cct_registered_post_type_args', $args, $labels, (int) $asenha_cpt->ID, $post_type_key );
                $args['labels'] = $labels;

                register_post_type( $post_type_key, $args );
            }
        }

        // ====== REGISTER CUSTOM TAXONOMIES ======
        
        // Get Taxonomy posts in wp_posts table added via Settings >> Custom Taxonomies
        $asenha_ctaxs_posts = get_posts( array(
            'numberposts'       => -1,
            'post_type'         => 'asenha_ctax',
            'post_status'       => 'publish',
            'suppress_filters'  => false,       
        ) );
        
        // Get CPT posts meta and use them to register the CPTs
        if ( $asenha_ctaxs_posts ) {
            foreach( $asenha_ctaxs_posts as $asenha_ctax ) {
                
                $taxonomy_key = get_post_meta( $asenha_ctax->ID, 'ctax_key', true );

                $labels = array(
                    'name'                      => get_post_meta( $asenha_ctax->ID, 'ctax_plural_name', true ),
                    'singular_name'             => get_post_meta( $asenha_ctax->ID, 'ctax_singular_name', true ),
                    'menu_name'                 => get_post_meta( $asenha_ctax->ID, 'ctax_plural_name', true ),
                    'search_items'              => get_post_meta( $asenha_ctax->ID, 'ctax_label_search_items', true ),
                    'popular_items'             => get_post_meta( $asenha_ctax->ID, 'ctax_label_popular_items', true ),
                    'all_items'                 => get_post_meta( $asenha_ctax->ID, 'ctax_label_all_items', true ),
                    'parent_item'               => get_post_meta( $asenha_ctax->ID, 'ctax_label_parent_item', true ),
                    'parent_item_colon'         => get_post_meta( $asenha_ctax->ID, 'ctax_label_parent_item_colon', true ),
                    'name_field_description'    => get_post_meta( $asenha_ctax->ID, 'ctax_label_name_field_description', true ),
                    'slug_field_description'    => get_post_meta( $asenha_ctax->ID, 'ctax_label_slug_field_description', true ),
                    'parent_field_description'  => get_post_meta( $asenha_ctax->ID, 'ctax_label_parent_field_description', true ),
                    'desc_field_description'    => get_post_meta( $asenha_ctax->ID, 'ctax_label_desc_field_description', true ),
                    'edit_item'                 => get_post_meta( $asenha_ctax->ID, 'ctax_label_edit_item', true ),
                    'view_item'                 => get_post_meta( $asenha_ctax->ID, 'ctax_label_view_item', true ),
                    'update_item'               => get_post_meta( $asenha_ctax->ID, 'ctax_label_update_item', true ),
                    'add_new_item'              => get_post_meta( $asenha_ctax->ID, 'ctax_label_add_new_item', true ),
                    'new_item_name'             => get_post_meta( $asenha_ctax->ID, 'ctax_label_new_item_name', true ),
                    'separate_items_with_commas' => get_post_meta( $asenha_ctax->ID, 'ctax_label_separate_items_with_commas', true ),
                    'add_or_remove_items'       => get_post_meta( $asenha_ctax->ID, 'ctax_label_add_or_remove_items', true ),
                    'choose_from_most_used'     => get_post_meta( $asenha_ctax->ID, 'ctax_label_choose_from_most_used', true ),
                    'not_found'                 => get_post_meta( $asenha_ctax->ID, 'ctax_label_not_found', true ),
                    'no_terms'                  => get_post_meta( $asenha_ctax->ID, 'ctax_label_no_terms', true ),
                    'filter_by_item'            => get_post_meta( $asenha_ctax->ID, 'ctax_label_filter_by_item', true ),
                    'items_list_navigation'     => get_post_meta( $asenha_ctax->ID, 'ctax_label_items_list_navigation', true ),
                    'items_list'                => get_post_meta( $asenha_ctax->ID, 'ctax_label_items_list', true ),
                    'most_used'                 => get_post_meta( $asenha_ctax->ID, 'ctax_label_most_used', true ),
                    'back_to_items'             => get_post_meta( $asenha_ctax->ID, 'ctax_label_back_to_items', true ),
                    'item_link'                 => get_post_meta( $asenha_ctax->ID, 'ctax_label_item_link', true ),
                    'item_link_description'     => get_post_meta( $asenha_ctax->ID, 'ctax_label_item_link_description', true ),
                );

                $labels = \ASENHA_CCT_Label_Context::filter_taxonomy_labels( $labels, (int) $asenha_ctax->ID );
                
                // --- Set ARGS ---

                // Define query_var value to use
                
                $ctax_query_var = get_post_meta( $asenha_ctax->ID, 'ctax_query_var', true );
                $ctax_use_custom_query_var_string = get_post_meta( $asenha_ctax->ID, 'ctax_use_custom_query_var_string', true );
                $ctax_query_var_string = get_post_meta( $asenha_ctax->ID, 'ctax_query_var_string', true );

                if ( $ctax_query_var ) {
                    if ( $ctax_use_custom_query_var_string ) {
                        if ( ! empty( $ctax_query_var_string ) ) {
                            $query_var = $ctax_query_var_string;
                        } else {
                            $query_var = true;
                        }
                    } else {
                        $query_var = true;
                    }
                } else {
                    $query_var = false;
                }

                // Define rewrite value to use

                $ctax_rewrite = get_post_meta( $asenha_ctax->ID, 'ctax_rewrite', true );
                $ctax_use_custom_rewrite_slug = get_post_meta( $asenha_ctax->ID, 'ctax_use_custom_rewrite_slug', true );
                $ctax_rewrite_custom_slug = get_post_meta( $asenha_ctax->ID, 'ctax_rewrite_custom_slug', true );
                $ctax_with_front = ( '1' == get_post_meta( $asenha_ctax->ID, 'ctax_with_front', true ) ) ? true : false;
                $ctax_hierarchical_urls = ( '1' == get_post_meta( $asenha_ctax->ID, 'ctax_hierarchical_urls', true ) ) ? true : false;
                $ctax_ep_mask = get_post_meta( $asenha_ctax->ID, 'ctax_ep_mask', true );
                $ctax_ep_mask_custom = get_post_meta( $asenha_ctax->ID, 'ctax_ep_mask_custom', true );

                // Treat custom slug toggle as disabled when the slug value is empty,
                // and persist the correction so stale meta doesn't keep entering the array branch.
                if ( $ctax_use_custom_rewrite_slug && empty( $ctax_rewrite_custom_slug ) ) {
                    $ctax_use_custom_rewrite_slug = false;
                    update_post_meta( $asenha_ctax->ID, 'ctax_use_custom_rewrite_slug', false );
                }

                $rewrite_slug = $this->get_rewrite_slug__premium_only( $ctax_use_custom_rewrite_slug, $ctax_rewrite_custom_slug, $taxonomy_key );
                $rewrite_ep_mask = $this->get_rewrite_ep_mask__premium_only( $ctax_ep_mask, $ctax_ep_mask_custom );

                if ( $ctax_rewrite ) {
                    if ( $ctax_use_custom_rewrite_slug || $ctax_with_front || $ctax_hierarchical_urls || $ctax_ep_mask ) {
                        $rewrite = array(
                            'slug'          => $rewrite_slug,
                            'with_front'    => $ctax_with_front,
                            'hierarchical'  => $ctax_hierarchical_urls,
                        );
                        if ( null !== $rewrite_ep_mask ) {
                            $rewrite['ep_mask'] = $rewrite_ep_mask;
                        }
                    } else {
                        $rewrite = true;
                    }
                } else {
                    $rewrite = false;
                }

                $args = array(
                    'labels'                    => $labels,
                    'public'                    => ( '1' == get_post_meta( $asenha_ctax->ID, 'ctax_public', true ) ) ? true : false,
                    'publicly_queryable'        => ( '1' == get_post_meta( $asenha_ctax->ID, 'ctax_publicly_queryable', true ) ) ? true : false,
                    'hierarchical'              => ( '1' == get_post_meta( $asenha_ctax->ID, 'ctax_hierarchical', true ) ) ? true : false,
                    'show_ui'                   => ( '1' == get_post_meta( $asenha_ctax->ID, 'ctax_show_ui', true ) ) ? true : false,
                    'show_in_menu'              => ( '1' == get_post_meta( $asenha_ctax->ID, 'ctax_show_in_menu', true ) ) ? true : false,
                    'show_in_nav_menus'         => ( '1' == get_post_meta( $asenha_ctax->ID, 'ctax_show_in_nav_menus', true ) ) ? true : false,
                    'show_tagcloud'             => ( '1' == get_post_meta( $asenha_ctax->ID, 'ctax_show_tagcloud', true ) ) ? true : false,
                    'show_in_quick_edit'        => ( '1' == get_post_meta( $asenha_ctax->ID, 'ctax_show_in_quick_edit', true ) ) ? true : false,
                    'show_admin_column'         => ( '1' == get_post_meta( $asenha_ctax->ID, 'ctax_show_admin_column', true ) ) ? true : false,
                    'capabilities'              => array(
                                                        'manage_terms'  => 'manage_categories',
                                                        'edit_terms'    => 'manage_categories',
                                                        'delete_terms'  => 'manage_categories',
                                                        'assign_terms'  => 'edit_posts',
                                                    ),
                    'query_var'                 => $query_var,
                    'rewrite'                   => $rewrite,
                    'update_count_callback'     => '_update_post_term_count',
                    'sort'                      => ( '1' == get_post_meta( $asenha_ctax->ID, 'ctax_sort', true ) ) ? true : false,
                    'show_in_rest'              => ( '1' == get_post_meta( $asenha_ctax->ID, 'ctax_show_in_rest', true ) ) ? true : false,
                );
                
                // Add default term for hierarchical taxonomies
                
                // if ( ( '1' == get_post_meta( $asenha_ctax->ID, 'ctax_hierarchical', true ) ) ) {
                //     $args['default_term'] = array(
                //                             'name'          => 'Uncategorized',
                //                             'slug'          => 'uncategorized',
                //                             'description'   => 'Not yet categorized',
                //                         );
                // }
                
                // Add optional arguments related to REST API
                
                if ( ! empty( get_post_meta( $asenha_ctax->ID, 'ctax_rest_base', true ) ) ) {
                    $args['rest_base'] = get_post_meta( $asenha_ctax->ID, 'ctax_rest_base', true );
                }

                if ( ! empty( get_post_meta( $asenha_ctax->ID, 'ctax_rest_namespace', true ) ) ) {
                    $args['rest_namespace'] = get_post_meta( $asenha_ctax->ID, 'ctax_rest_namespace', true );
                }

                if ( ! empty( get_post_meta( $asenha_ctax->ID, 'ctax_rest_controller_class', true ) ) ) {
                    $args['rest_controller_class'] = get_post_meta( $asenha_ctax->ID, 'ctax_rest_controller_class', true );
                }
                
                // Register custom taxonomy with their supported post types
                
                $supported_post_types = get_post_meta( $asenha_ctax->ID, 'ctax_post_types', true );

                $labels = apply_filters( 'asenha_cct_registered_taxonomy_labels', $labels, $args, (int) $asenha_ctax->ID, $taxonomy_key );
                $args   = apply_filters( 'asenha_cct_registered_taxonomy_args', $args, $labels, (int) $asenha_ctax->ID, $taxonomy_key );
                $args['labels'] = $labels;
                
                register_taxonomy( $taxonomy_key, $supported_post_types, $args );
            }
        }

    }
    
    /**
     * Use plural name as CPT and Custom Taxonomy title in admin table
     * 
     * @link https://developer.wordpress.org/reference/hooks/wp_insert_post_data/
     * @since 5.1.0
     */
    public function use_plural_name_as_cpt_ctax_title__premium_only( $data ) {
        if ( ( $data['post_type'] == 'asenha_cpt' && isset( $_POST['cpt_plural_name'] ) ) 
            || ( $data['post_type'] == 'asenha_ctax' && isset( $_POST['ctax_plural_name'] ) )
        ) {
            if ( isset( $_POST['cpt_plural_name'] ) ) {
                $data['post_title'] = $_POST['cpt_plural_name'];
            } elseif ( isset( $_POST['ctax_plural_name'] ) ) {
                $data['post_title'] = $_POST['ctax_plural_name'];               
            }
        }
        
        if ( $data['post_type'] == 'options_page_config' && isset( $_POST['options_page_title'] ) ) {
                $data['post_title'] = $_POST['options_page_title'];
        }
        
        return $data;
    }

    /**
     * Define columns to show for CPT admin table
     *
     * @since  5.1.0
     */
    public function cpt_posts_define_columns__premium_only( $columns ) {

        $columns = array(
            'cb' => $columns['cb'], // Checkbox for bulk actions
            'basic' => 'Basic Info',
            'supports' => 'Supported Features',
            'taxonomies' => 'Supported Taxonomies',
            'author' => 'Author',
            'date' => 'Date',
        );
        return $columns;
    }

    /**
     * Render custom columns content for CPT admin table
     *
     * @since  5.1.0
     */
    public function cpt_posts_custom_columns_content__premium_only( $column_name, $id ) {
        
        $edit_link = get_edit_post_link();
        $singular_name = get_post_meta( get_the_ID(), 'cpt_singular_name', true );
        $plural_name = get_post_meta( get_the_ID(), 'cpt_plural_name', true );
        $description = get_post_meta( get_the_ID(), 'cpt_description', true );
        $description_separator = ( ! empty( get_post_meta( get_the_ID(), 'cpt_description', true ) ) ) ? '<br />' : '';
        $key = get_post_meta( get_the_ID(), 'cpt_key', true );
        $public = ( get_post_meta( get_the_ID(), 'cpt_public', true ) ) ? 'Public' : 'Not public';
        $hierarchical = ( get_post_meta( get_the_ID(), 'cpt_hierarchical', true ) ) ? ' | Hierarchical' : ' | Not hierarchical';

        $supports_raw = get_post_meta( get_the_ID(), 'cpt_supports', true );
        $supports = '';
        $separator = ', ';

        if ( is_array( $supports_raw ) ) {
            if ( in_array( 'none', $supports_raw ) ) {
                $supports = 'None';
            } else {
                foreach( $supports_raw as $support_raw ) {
                    if ( $support_raw == 'title' ) {
                        $supports .= 'Title' . $separator;
                    }
                    if ( $support_raw == 'editor' ) {
                        $supports .= 'Editor' . $separator;
                    }
                    if ( $support_raw == 'author' ) {
                        $supports .= 'Author' . $separator;
                    }
                    if ( $support_raw == 'thumbnail' ) {
                        $supports .= 'Featured Image' . $separator;
                    }
                    if ( $support_raw == 'excerpt' ) {
                        $supports .= 'Excerpt' . $separator;
                    }
                    if ( $support_raw == 'trackbacks' ) {
                        $supports .= 'Trackback' . $separator;
                    }
                    if ( $support_raw == 'custom-fields' ) {
                        $supports .= 'Custom Fields' . $separator;
                    }
                    if ( $support_raw == 'comments' ) {
                        $supports .= 'Comments' . $separator;
                    }
                    if ( $support_raw == 'revisions' ) {
                        $supports .= 'Revisions' . $separator;
                    }
                    if ( $support_raw == 'page-attributes' ) {
                        $supports .= 'Page Attributes' . $separator;
                    }
                    if ( $support_raw == 'post-formats' ) {
                        $supports .= 'Post Formats' . $separator;
                    }
                }
            }
        }

        $supports = trim( trim( $supports ), ',' );
        
        $taxonomies = get_taxonomies( array(), 'objects' );
        $supported_taxonomies_slugs = array();
        foreach ( $taxonomies as $taxonomy_slug => $taxonomy_object  ) {
            foreach( $taxonomy_object->object_type as $object_type_slug ) {
                if ( $key == $object_type_slug ) {
                    $supported_taxonomies_slugs[] = $taxonomy_slug;
                }
            }
        }
        
        $taxonomies = '';
        $taxonomy_page_link_suffix = ( ! in_array( $key, array( 'post', 'page' ) ) ) ? '&post_type=' . $key : '' ;
        if ( ! empty( $supported_taxonomies_slugs ) ) {
            foreach( $supported_taxonomies_slugs as $taxonomy_slug ) {
                $taxonomy = get_taxonomy( $taxonomy_slug );
                $taxonomies .= '<a href="/wp-admin/edit-tags.php?taxonomy=' . $taxonomy_slug . $taxonomy_page_link_suffix . '">' . $taxonomy->labels->name . '</a>' . $separator;
            }
            $taxonomies = trim( trim( $taxonomies ), ',' );
        } else {
            $taxonomies = 'None supported yet.';
        }

        if ( $column_name === 'basic' ) {
            echo '<a href="' . esc_attr( $edit_link ) . '"><strong>' . esc_html( $plural_name ) . '</strong></a> (' . esc_html( $key ) . ')<br />' . esc_html( $description ) . esc_html( $description_separator ) . esc_html( $public ) . esc_html( $hierarchical ) ;
        }
        if ( $column_name === 'description' ) {
            echo wp_kses_post( get_post_meta( get_the_ID(), 'cpt_description', true ) );
        }
        if ( $column_name === 'supports' ) {
            echo esc_html( $supports );
        }
        if ( $column_name === 'taxonomies' ) {
            echo wp_kses_post( $taxonomies );
        }
    }

    /**
     * Define columns to show for custom taxonomies admin table
     *
     * @since  5.1.0
     */
    public function ctax_posts_define_columns__premium_only( $columns ) {

        $columns = array(
            'cb' => $columns['cb'], // Checkbox for bulk actions
            'basic' => 'Basic Info',
            'post_types' => 'Supported Post Types',
            'author' => 'Author',
            'date' => 'Date',
        );
        return $columns;
    }

    /**
     * Render custom columns content for CPT admin table
     *
     * @since  5.1.0
     */
    public function ctax_posts_custom_columns_content__premium_only( $column_name, $id ) {
        
        $edit_link = get_edit_post_link();
        $singular_name = get_post_meta( get_the_ID(), 'ctax_singular_name', true );
        $plural_name = get_post_meta( get_the_ID(), 'ctax_plural_name', true );
        $description = get_post_meta( get_the_ID(), 'ctax_description', true );
        $description_separator = ( ! empty( get_post_meta( get_the_ID(), 'ctax_description', true ) ) ) ? '<br />' : '';
        $key = get_post_meta( get_the_ID(), 'ctax_key', true );
        $public = ( get_post_meta( get_the_ID(), 'ctax_public', true ) ) ? 'Public' : 'Not public';
        $hierarchical = ( get_post_meta( get_the_ID(), 'ctax_hierarchical', true ) ) ? ' | Hierarchical' : ' | Not hierarchical';
        
        $post_types_raw = get_post_meta( get_the_ID(), 'ctax_post_types', true );
        $post_types = '';
        $separator = ', ';
        if ( ! empty( $post_types_raw ) ) {
            foreach( $post_types_raw as $post_type_slug ) {
                $post_type_page_link_suffix = ( ! in_array( $post_type_slug, array( 'post', 'page' ) ) ) ? '?post_type=' . $post_type_slug : '' ;
                $post_type = get_post_type_object( $post_type_slug );
                if ( is_object( $post_type ) && property_exists( $post_type, 'label' ) ) {
                    $post_type_label = $post_type->label;
                } elseif ( is_object( $post_type ) && ! is_null( $post_type->labels ) ) {
                    $post_type_label = $post_type->labels->name;                 
                } else {
                    $post_type_label = $post_type_slug;
                }
                $post_types .= '<a href="/wp-admin/edit.php' . $post_type_page_link_suffix . '">' . $post_type_label . '</a>' . $separator;
            }
            $post_types = trim( trim( $post_types ), ',' );
        } else {
            $post_types = 'None supported yet.';
        }

        if ( $column_name === 'basic' ) {
            echo '<a href="' . esc_attr( $edit_link ) . '"><strong>' . esc_html( $plural_name ) . '</strong></a> (' . esc_html( $key ) . ')<br />' . esc_html( $description ) . esc_html( $description_separator )  . esc_html( $public ) . esc_html( $hierarchical ) ;
        }
        if ( $column_name === 'post_types' ) {
            echo wp_kses_post( $post_types );
        }
    }

    /**
     * Remove Custom Post Types and Custom Taxonomies submenus from Settings menu
     * 
     * @since 5.1.0
     */
    public function remove_cpt_ctax_submenus_for_nonadmins__premium_only() {
        global $current_user;
        $roles = array();
        foreach( $current_user->roles as $key => $role ) {
            $roles[] = $role;
        }
        if ( ! in_array( 'administrator', $roles ) ) {
            remove_submenu_page( 'options-general.php', 'edit.php?post_type=asenha_cpt' );          
            remove_submenu_page( 'options-general.php', 'edit.php?post_type=asenha_ctax' );         
        }
    }    

}