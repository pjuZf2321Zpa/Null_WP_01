<?php

namespace ASENHA\Classes;

/**
 * Class for Show Custom Taxonomy Filters module
 *
 * @since 6.9.5
 */
class Show_Custom_Taxonomy_Filters {
        
    // Excluded taxonomies
    private $inapplicable_taxonomies = array( 
            'category', // Post Categories
            'product_cat', // WooCommerce Product Categories
            'asenha_code_snippet_category', // ASE Code Snippets Categories
            'asenha-media-category', // ASE Media Categories
        );

    /**
     * Built-in taxonomies that stay eligible alongside custom taxonomies.
     *
     * @var string[]
     */
    private $included_builtin_taxonomies = array(
        'post_tag',
        'post_format',
    );

    /**
     * Enabled taxonomy slugs for the current request, keyed by hierarchy.
     *
     * @var array<string, string[]>
     */
    private $cached_enabled_taxonomy_slugs = array();

    /**
     * Show custom (hierarchical) taxonomy filter(s) for all post types.
     *
     * @since 1.0.0
     */
    public function show_custom_taxonomy_filters( $post_type ) {
        $object_taxonomies = get_object_taxonomies( $post_type, 'objects' );
        
        array_walk( $object_taxonomies, [ $this, 'output_taxonomy_filter' ] );
    }

    /**
     * Output filter on the post type's list table for a taxonomy
     *
     * @since 1.0.0
     */
    public function output_taxonomy_filter( $taxonomy ) {

        // Show filter if taxonomy is hierarchical.
        // Free shows every taxonomy that passes this check. Pro limits it to the saved allowlist.
        if ( true === $taxonomy->hierarchical && ! in_array( $taxonomy->name, $this->inapplicable_taxonomies, true ) ) {
            $show_hierarchical_filter = true;

            if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
                $show_hierarchical_filter = $this->is_taxonomy_filter_enabled__premium_only( $taxonomy->name, true );
            }

            if ( $show_hierarchical_filter ) {
                $this->render_additional_filter( $taxonomy );
            }
        }

        if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
            $options = get_option( ASENHA_SLUG_U );
            $show_custom_taxonomy_filters_non_hierarchical = isset( $options['show_custom_taxonomy_filters_non_hierarchical'] ) ? $options['show_custom_taxonomy_filters_non_hierarchical'] : false;            

            if ( $show_custom_taxonomy_filters_non_hierarchical ) {
                // Show filter if taxonomy is non-hierarchical and included in the allowlist.
                if ( false === $taxonomy->hierarchical && ! in_array( $taxonomy->name, $this->inapplicable_taxonomies, true ) ) {
                    if ( $this->is_taxonomy_filter_enabled__premium_only( $taxonomy->name, false ) ) {
                        $this->render_additional_filter( $taxonomy );
                    }
                }                
            }
        }

    }

    /**
     * Whether a taxonomy can be offered as a list-table filter.
     *
     * Custom taxonomies are included. Built-in taxonomies are included only for
     * Post Tag and Post Format. Taxonomies must be attached to at least one post type.
     *
     * @since 9.2.0
     *
     * @param WP_Taxonomy $taxonomy Taxonomy object.
     * @return bool
     */
    public function is_eligible_taxonomy__premium_only( $taxonomy ) {
        if ( ! is_object( $taxonomy ) || empty( $taxonomy->name ) ) {
            return false;
        }

        if ( in_array( $taxonomy->name, $this->inapplicable_taxonomies, true ) ) {
            return false;
        }

        $is_builtin = ! empty( $taxonomy->_builtin );
        if ( $is_builtin && ! in_array( $taxonomy->name, $this->included_builtin_taxonomies, true ) ) {
            return false;
        }

        if ( empty( $taxonomy->object_type ) || ! is_array( $taxonomy->object_type ) ) {
            return false;
        }

        foreach ( $taxonomy->object_type as $post_type_slug ) {
            if ( post_type_exists( $post_type_slug ) ) {
                return true;
            }
        }

        return false;
    }

    /**
     * Checkbox choices for one hierarchy group.
     *
     * @since 9.2.0
     *
     * @param bool $hierarchical True for hierarchical taxonomies.
     * @return array<string, string> Choice label HTML keyed to the taxonomy slug.
     */
    public function get_taxonomy_filter_choices__premium_only( $hierarchical ) {
        $hierarchical = (bool) $hierarchical;
        $taxonomies   = get_taxonomies( array(), 'objects' );
        $sorted       = array();

        foreach ( $taxonomies as $taxonomy ) {
            if ( (bool) $taxonomy->hierarchical !== $hierarchical ) {
                continue;
            }

            if ( ! $this->is_eligible_taxonomy__premium_only( $taxonomy ) ) {
                continue;
            }

            $sorted[] = array(
                'label'    => $this->get_taxonomy_sort_label__premium_only( $taxonomy ),
                'taxonomy' => $taxonomy,
            );
        }

        usort(
            $sorted,
            static function( $a, $b ) {
                $label_compare = strnatcasecmp( $a['label'], $b['label'] );
                if ( 0 !== $label_compare ) {
                    return $label_compare;
                }

                return strnatcasecmp( $a['taxonomy']->name, $b['taxonomy']->name );
            }
        );

        $choices = array();
        foreach ( $sorted as $item ) {
            $choices[ $this->get_taxonomy_choice_label__premium_only( $item['taxonomy'] ) ] = $item['taxonomy']->name;
        }

        return $choices;
    }

    /**
     * Eligible taxonomy slugs for one hierarchy group, sorted by label.
     *
     * @since 9.2.0
     *
     * @param bool $hierarchical True for hierarchical taxonomies.
     * @return string[]
     */
    public function get_eligible_taxonomy_slugs__premium_only( $hierarchical ) {
        return array_values( $this->get_taxonomy_filter_choices__premium_only( $hierarchical ) );
    }

    /**
     * Taxonomy slugs that should render a filter.
     *
     * A missing option means every eligible taxonomy. A stored array, including an empty one, is respected.
     *
     * @since 9.2.0
     *
     * @param bool $hierarchical True for hierarchical taxonomies.
     * @return string[]
     */
    public function get_enabled_taxonomy_slugs__premium_only( $hierarchical ) {
        $hierarchical = (bool) $hierarchical;
        $option_key   = $hierarchical
            ? 'show_custom_taxonomy_filters_taxonomies'
            : 'show_custom_taxonomy_filters_non_hierarchical_taxonomies';

        $eligible_slugs = $this->get_eligible_taxonomy_slugs__premium_only( $hierarchical );
        $options        = get_option( ASENHA_SLUG_U, array() );

        if ( ! is_array( $options ) || ! array_key_exists( $option_key, $options ) ) {
            return $eligible_slugs;
        }

        $saved_slugs = array_map( 'sanitize_key', (array) $options[ $option_key ] );

        return array_values( array_intersect( $eligible_slugs, $saved_slugs ) );
    }

    /**
     * Whether a taxonomy slug is enabled for its hierarchy group.
     *
     * @since 9.2.0
     *
     * @param string $taxonomy_slug Taxonomy slug.
     * @param bool   $hierarchical  True for hierarchical taxonomies.
     * @return bool
     */
    public function is_taxonomy_filter_enabled__premium_only( $taxonomy_slug, $hierarchical ) {
        $cache_key = $hierarchical ? 'hierarchical' : 'non_hierarchical';

        if ( ! isset( $this->cached_enabled_taxonomy_slugs[ $cache_key ] ) ) {
            $this->cached_enabled_taxonomy_slugs[ $cache_key ] = $this->get_enabled_taxonomy_slugs__premium_only( $hierarchical );
        }

        return in_array( $taxonomy_slug, $this->cached_enabled_taxonomy_slugs[ $cache_key ], true );
    }

    /**
     * Keep only eligible slugs from a submitted allowlist.
     *
     * An absent or non-array submission is stored as an empty selection.
     *
     * @since 9.2.0
     *
     * @param mixed $submitted_slugs Submitted taxonomy slugs.
     * @param bool  $hierarchical    True for hierarchical taxonomies.
     * @return string[]
     */
    public function sanitize_taxonomy_filter_slugs__premium_only( $submitted_slugs, $hierarchical ) {
        if ( ! is_array( $submitted_slugs ) ) {
            $submitted_slugs = array();
        }

        $submitted_slugs = array_filter( array_map( 'sanitize_key', $submitted_slugs ) );
        $eligible_slugs  = $this->get_eligible_taxonomy_slugs__premium_only( $hierarchical );

        return array_values( array_intersect( $eligible_slugs, $submitted_slugs ) );
    }

    /**
     * Plain taxonomy label used to sort the settings choices.
     *
     * @since 9.2.0
     *
     * @param WP_Taxonomy $taxonomy Taxonomy object.
     * @return string
     */
    private function get_taxonomy_sort_label__premium_only( $taxonomy ) {
        if ( isset( $taxonomy->labels->name ) && '' !== $taxonomy->labels->name ) {
            return $taxonomy->labels->name;
        }

        return (string) $taxonomy->label;
    }

    /**
     * Settings checkbox label, including the slug and the post types that use the taxonomy.
     *
     * @since 9.2.0
     *
     * @param WP_Taxonomy $taxonomy Taxonomy object.
     * @return string HTML label safe for wp_kses_post().
     */
    private function get_taxonomy_choice_label__premium_only( $taxonomy ) {
        $taxonomy_name = $this->get_taxonomy_sort_label__premium_only( $taxonomy );
        $post_types    = array();

        foreach ( (array) $taxonomy->object_type as $post_type_slug ) {
            $post_type_object = get_post_type_object( $post_type_slug );
            if ( ! is_object( $post_type_object ) ) {
                continue;
            }

            $post_type_label = ( isset( $post_type_object->labels->name ) && '' !== $post_type_object->labels->name )
                ? $post_type_object->labels->name
                : $post_type_slug;

            $post_types[ $post_type_label . ' ' . $post_type_slug ] = sprintf(
                '%1$s (%2$s)',
                $post_type_label,
                $post_type_slug
            );
        }

        ksort( $post_types, SORT_NATURAL | SORT_FLAG_CASE );

        $faded = '(' . esc_html( $taxonomy->name ) . ')';
        if ( ! empty( $post_types ) ) {
            $faded .= ' ' . sprintf(
                /* translators: %s: comma-separated post types, for example "Movies (movie), Directors (director)". */
                esc_html__( '— used in %s', 'admin-site-enhancements' ),
                esc_html( implode( ', ', $post_types ) )
            );
        }

        return esc_html( $taxonomy_name ) . ' <span class="faded">' . $faded . '</span>';
    }
    
    /**
     * Render additional filter
     * 
     * @since 6.9.7
     */
    public function render_additional_filter( $taxonomy ) {
        $show_option_all_label = sprintf( 'All %s', ucwords( $taxonomy->label ) );

        if ( property_exists( $taxonomy, 'labels' ) ) {
            $taxonomy_labels = $taxonomy->labels;
            if ( property_exists( $taxonomy_labels, 'all_items' ) && ! empty( $taxonomy_labels->all_items ) ) {
                $show_option_all_label = $taxonomy->labels->all_items;
            }
        }

        $request_key = $this->get_filter_request_key( $taxonomy );
        $selected    = '';
        if ( isset( $_GET[ $request_key ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- List-table filter form, same as core.
            $selected = sanitize_title( wp_unslash( $_GET[ $request_key ] ) );
        }

        $dropdown = wp_dropdown_categories( array(
            'show_option_all'   => $show_option_all_label,
            'orderby'           => 'name',
            'order'             => 'ASC',
            'hide_empty'        => false,
            'hide_if_empty'     => true,
            'selected'          => $selected,
            'hierarchical'      => true,
            'name'              => $request_key,
            'taxonomy'          => $taxonomy->name,
            'value_field'       => 'slug',
            'echo'              => false,
        ) );

        if ( ! is_string( $dropdown ) || '' === $dropdown ) {
            return;
        }

        // Core hardcodes the "All" option as value 0. A slug query for 0 matches nothing.
        $dropdown = preg_replace( "/value='0'/", "value=''", $dropdown, 1 );

        echo $dropdown; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- HTML is generated by wp_dropdown_categories().
    }

    /**
     * Query-string key for a taxonomy filter dropdown.
     *
     * A taxonomy with a public query var keeps that key so WordPress can filter it.
     * A taxonomy with query_var turned off uses its slug. Those are applied in the admin list query.
     *
     * @since 9.2.0
     *
     * @param WP_Taxonomy $taxonomy Taxonomy object.
     * @return string
     */
    private function get_filter_request_key( $taxonomy ) {
        if ( is_string( $taxonomy->query_var ) && '' !== $taxonomy->query_var ) {
            return $taxonomy->query_var;
        }

        return $taxonomy->name;
    }

    /**
     * Limit the admin list query for taxonomies that have no query var.
     *
     * WordPress only maps a taxonomy argument into tax_query when query_var is registered.
     * Registering one here would make the taxonomy publicly queryable.
     *
     * @since 9.2.0
     *
     * @param WP_Query $query Main admin query.
     * @return void
     */
    public function filter_admin_list_by_taxonomy( $query ) {
        if ( ! is_admin() || ! $query->is_main_query() ) {
            return;
        }

        global $pagenow;
        if ( 'edit.php' !== $pagenow ) {
            return;
        }

        $post_type = $query->get( 'post_type' );
        if ( ! is_string( $post_type ) || '' === $post_type ) {
            $post_type = 'post';
        }

        $taxonomies = get_object_taxonomies( $post_type, 'objects' );
        if ( empty( $taxonomies ) || ! is_array( $taxonomies ) ) {
            return;
        }

        $tax_query = array();

        foreach ( $taxonomies as $taxonomy ) {
            if ( is_string( $taxonomy->query_var ) && '' !== $taxonomy->query_var ) {
                continue;
            }

            if ( ! isset( $_GET[ $taxonomy->name ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- List-table filter form, same as core.
                continue;
            }

            $slug = sanitize_title( wp_unslash( $_GET[ $taxonomy->name ] ) );
            if ( '' === $slug || '0' === $slug ) {
                continue;
            }

            $tax_query[] = array(
                'taxonomy' => $taxonomy->name,
                'field'    => 'slug',
                'terms'    => $slug,
            );
        }

        if ( empty( $tax_query ) ) {
            return;
        }

        $existing_tax_query = $query->get( 'tax_query' );
        if ( is_array( $existing_tax_query ) && ! empty( $existing_tax_query ) ) {
            $tax_query = array_merge( $existing_tax_query, $tax_query );
        }

        $query->set( 'tax_query', $tax_query );
    }
    
    /**
     * Remove malformed string inside the $where clause that is breaking search for posts.
     * This malformed string appears when filter(s) for non-hierarchical taxonomies are shown/enabled.
     * 
     * @since 7.8.7
     */
    public function filter_where_clause__premium_only( $where, $query ) {
        if ( is_admin() ) {
            // do_action( 'inspect', [ 'where', $where ] );        
            $where = str_replace( ' AND ( ' . PHP_EOL . '  0 = 1' . PHP_EOL . ')', '', $where );
            // do_action( 'inspect', [ 'where', $where ] );
        }
        
        return $where;
    }
    
}