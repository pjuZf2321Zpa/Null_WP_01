<?php

namespace ASENHA\Classes;

/**
 * Class for Display System Summary module
 *
 * @since 6.9.5
 */
class Display_System_Summary {

	/**
	 * Aggregated sizes transient key.
	 *
	 * @since 9.0.3
	 * @var string
	 */
	const SIZES_TRANSIENT = 'asenha_dss_sizes';

	/**
	 * Calculation lock transient key.
	 *
	 * @since 9.0.3
	 * @var string
	 */
	const LOCK_TRANSIENT = 'asenha_dss_calc_lock';

	/**
	 * WP-Cron hook for background size calculation.
	 *
	 * @since 9.0.3
	 * @var string
	 */
	const CRON_HOOK = 'asenha_dss_calculate_sizes';

	/**
	 * Cache TTL for calculated sizes (24 hours).
	 *
	 * @since 9.0.3
	 * @var int
	 */
	const CACHE_TTL = 86400; // 24 * HOUR_IN_SECONDS when HOUR_IN_SECONDS is available.

	/**
	 * Lock TTL while a calculation is in progress (long walks on large sites).
	 *
	 * @since 9.0.3
	 * @var int
	 */
	const LOCK_TTL = 1800; // 30 minutes.

	/**
	 * Display system summary in the "At a Glance" dashboard widget
	 *
	 * @since 5.6.0
	 */
	public function display_system_summary() {

		// When user is logged-in as in an administrator
		if ( is_user_logged_in() ) {
			if ( current_user_can( 'manage_options' ) ) {

				if ( isset( $_SERVER['SERVER_SOFTWARE'] ) ) {
					$server_software_raw   = str_replace( '/', ' ', $_SERVER['SERVER_SOFTWARE'] );
					$server_software_parts = explode( ' (', $server_software_raw );
					$server_software       = ucfirst( $server_software_parts[0] );
				} else {
					$server_software = 'Unknown';
				}

				$php_version = phpversion();

				// From WP core /wp-admin/includes/class-wp-debug-data.php
				global $wpdb;
				$db_server       = $wpdb->get_var( 'SELECT VERSION()' );
				$db_server_parts = explode( ':', $db_server );
				$db_server       = $db_server_parts[0];

				$ip = 'localhost';

				if ( isset( $_SERVER['HTTP_X_SERVER_ADDR'] ) ) {
					$ip = sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_SERVER_ADDR'] ) );
				} elseif ( isset( $_SERVER['SERVER_ADDR'] ) ) {
					$ip = sanitize_text_field( wp_unslash( $_SERVER['SERVER_ADDR'] ) );
				}

				echo '<div class="system-summary"><a href="' . esc_url( admin_url( 'site-health.php?tab=debug' ) ) . '">System</a>: ' . esc_html( $server_software ) . ' &#9642; PHP ' . esc_html( $php_version ) . ' (' . esc_html( php_sapi_name() ) . ') &#9642;' . esc_html( $db_server ) . ' &#9642; IP: ' . esc_html( $ip ) . '</div>';

				if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
					$this->render_site_sizes__premium_only();
				}
			}
		}

	}

	/**
	 * Render Pro site size rows from cache, or Calculating placeholders.
	 *
	 * Never walks the filesystem on dashboard load.
	 *
	 * @since 9.0.3
	 */
	private function render_site_sizes__premium_only() {
		$sizes   = $this->get_cached_sizes__premium_only();
		$ready   = is_array( $sizes ) && $this->sizes_are_complete__premium_only( $sizes );
		$labels  = $this->get_size_labels__premium_only();
		$pending = esc_html__( 'Calculating…', 'admin-site-enhancements' );

		$values = array(
			'entire_site' => $ready ? size_format( (int) $sizes['entire_site'], 2 ) : $pending,
			'database'    => $ready ? size_format( (int) $sizes['database'], 2 ) : $pending,
			'all_files'   => $ready ? size_format( (int) $sizes['all_files'], 2 ) : $pending,
			'wp_content'  => $ready ? size_format( (int) $sizes['wp_content'], 2 ) : $pending,
			'plugins'     => $ready ? size_format( (int) $sizes['plugins'], 2 ) : $pending,
			'themes'      => $ready ? size_format( (int) $sizes['themes'], 2 ) : $pending,
			'uploads'     => $ready ? size_format( (int) $sizes['uploads'], 2 ) : $pending,
		);

		$status_class = $ready ? 'asenha-dss-ready' : 'asenha-dss-calculating';

		echo '<div class="site-sizes ' . esc_attr( $status_class ) . '" data-asenha-dss-ready="' . ( $ready ? '1' : '0' ) . '">';
		echo '<div class="first-sizes">';
		echo '<div class="size-item" data-size-key="entire_site"><span class="item-heading">' . esc_html( $labels['entire_site'] ) . '</span> <span class="asenha-dss-value">' . esc_html( $values['entire_site'] ) . '</span></div>';
		echo '<div class="size-item" data-size-key="database"><span class="item-heading">' . esc_html( $labels['database'] ) . '</span> <span class="asenha-dss-value">' . esc_html( $values['database'] ) . '</span></div>';
		echo '<div class="size-item" data-size-key="all_files"><span class="item-heading">' . esc_html( $labels['all_files'] ) . '</span> <span class="asenha-dss-value">' . esc_html( $values['all_files'] ) . '</span></div>';
		echo '</div>';
		echo '<div class="second-sizes">';
		echo '<div class="size-item" data-size-key="wp_content"><span class="item-heading">' . esc_html( $labels['wp_content'] ) . '</span> <span class="asenha-dss-value">' . esc_html( $values['wp_content'] ) . '</span></div>';
		echo '<div class="size-item" data-size-key="plugins"><span class="item-heading">' . esc_html( $labels['plugins'] ) . '</span> <span class="asenha-dss-value">' . esc_html( $values['plugins'] ) . '</span></div>';
		echo '<div class="size-item" data-size-key="themes"><span class="item-heading">' . esc_html( $labels['themes'] ) . '</span> <span class="asenha-dss-value">' . esc_html( $values['themes'] ) . '</span></div>';
		echo '<div class="size-item" data-size-key="uploads"><span class="item-heading">' . esc_html( $labels['uploads'] ) . '</span> <span class="asenha-dss-value">' . esc_html( $values['uploads'] ) . '</span></div>';
		echo '</div>';
		echo '</div>';
	}

	/**
	 * Size row labels.
	 *
	 * @since 9.0.3
	 * @return array<string,string>
	 */
	private function get_size_labels__premium_only() {
		return array(
			'entire_site' => __( 'Entire site', 'admin-site-enhancements' ),
			'database'    => __( 'Database', 'admin-site-enhancements' ),
			'all_files'   => __( 'All files', 'admin-site-enhancements' ),
			'wp_content'  => __( 'wp-content', 'admin-site-enhancements' ),
			'plugins'     => __( 'plugins', 'admin-site-enhancements' ),
			'themes'      => __( 'themes', 'admin-site-enhancements' ),
			'uploads'     => __( 'uploads', 'admin-site-enhancements' ),
		);
	}

	/**
	 * Enqueue dashboard JS for async size loading (Pro).
	 *
	 * @since 9.0.3
	 * @param string $hook_suffix Current admin page hook.
	 */
	public function enqueue_dashboard_assets__premium_only( $hook_suffix ) {
		if ( 'index.php' !== $hook_suffix ) {
			return;
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		wp_enqueue_script(
			'asenha-display-system-summary',
			ASENHA_URL . 'assets/premium/js/display-system-summary.js',
			array( 'jquery' ),
			ASENHA_VERSION,
			true
		);

		wp_localize_script(
			'asenha-display-system-summary',
			'asenhaDss',
			array(
				'ajaxUrl'      => admin_url( 'admin-ajax.php' ),
				'nonce'        => wp_create_nonce( 'asenha_dss_get_sizes' ),
				'calculating'  => __( 'Calculating…', 'admin-site-enhancements' ),
				'unavailable'  => __( 'Unavailable', 'admin-site-enhancements' ),
				'pollInterval' => 4000,
				'maxPolls'     => 45,
			)
		);
	}

	/**
	 * AJAX: return cached sizes or start / continue calculation.
	 *
	 * @since 9.0.3
	 */
	public function ajax_get_sizes__premium_only() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error(
				array(
					'status'  => 'forbidden',
					'message' => __( 'Forbidden', 'admin-site-enhancements' ),
				),
				403
			);
		}

		check_ajax_referer( 'asenha_dss_get_sizes', 'nonce' );

		$cached = $this->get_cached_sizes__premium_only();
		if ( is_array( $cached ) && $this->sizes_are_complete__premium_only( $cached ) ) {
			wp_send_json_success(
				array(
					'status' => 'ready',
					'sizes'  => $this->format_sizes_for_js__premium_only( $cached ),
				)
			);
		}

		// Always schedule cron fallback so a killed AJAX request can still finish.
		$this->schedule_calculation_cron__premium_only();

		$lock = get_transient( self::LOCK_TRANSIENT );
		if ( false !== $lock ) {
			wp_send_json_success(
				array(
					'status' => 'calculating',
				)
			);
		}

		// Attempt inline calculation (small/medium sites finish in this request).
		$result = $this->run_calculation__premium_only();

		if ( is_array( $result ) && $this->sizes_are_complete__premium_only( $result ) ) {
			wp_send_json_success(
				array(
					'status' => 'ready',
					'sizes'  => $this->format_sizes_for_js__premium_only( $result ),
				)
			);
		}

		wp_send_json_success(
			array(
				'status' => 'calculating',
			)
		);
	}

	/**
	 * WP-Cron callback to calculate sizes in the background.
	 *
	 * @since 9.0.3
	 */
	public function cron_calculate_sizes__premium_only() {
		$cached = $this->get_cached_sizes__premium_only();
		if ( is_array( $cached ) && $this->sizes_are_complete__premium_only( $cached ) ) {
			return;
		}

		$this->run_calculation__premium_only();
	}

	/**
	 * Schedule a single cron event if one is not already queued.
	 *
	 * @since 9.0.3
	 */
	private function schedule_calculation_cron__premium_only() {
		if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
			wp_schedule_single_event( time() + 5, self::CRON_HOOK );
		}
	}

	/**
	 * Run size calculation under a lock.
	 *
	 * @since 9.0.3
	 * @return array<string,int>|false Complete sizes array, or false on lock contention / failure.
	 */
	private function run_calculation__premium_only() {
		if ( false !== get_transient( self::LOCK_TRANSIENT ) ) {
			return false;
		}

		set_transient( self::LOCK_TRANSIENT, time(), self::LOCK_TTL );

		// Soften time pressure only in AJAX / cron workers, never on dashboard HTML.
		if ( function_exists( 'set_time_limit' ) ) {
			// phpcs:ignore Squiz.PHP.DiscouragedFunctions.Discouraged -- intentional for large filesystem walks.
			@set_time_limit( 0 );
		}

		try {
			$sizes = $this->calculate_all_sizes__premium_only();
			if ( is_array( $sizes ) && $this->sizes_are_complete__premium_only( $sizes ) ) {
				$ttl = defined( 'HOUR_IN_SECONDS' ) ? 24 * HOUR_IN_SECONDS : self::CACHE_TTL;
				set_transient( self::SIZES_TRANSIENT, $sizes, $ttl );
				delete_transient( self::LOCK_TRANSIENT );
				return $sizes;
			}
		} catch ( \Throwable $e ) {
			delete_transient( self::LOCK_TRANSIENT );
			return false;
		}

		delete_transient( self::LOCK_TRANSIENT );
		return false;
	}

	/**
	 * Calculate DB + filesystem sizes (single-pass where possible).
	 *
	 * @since 9.0.3
	 * @return array<string,int>
	 */
	private function calculate_all_sizes__premium_only() {
		$db_size = $this->calculate_db_size__premium_only();

		$uploads     = wp_get_upload_dir();
		$uploads_dir = isset( $uploads['basedir'] ) ? $uploads['basedir'] : '';
		$theme_root  = get_theme_root();

		$buckets = array(
			'all_files'  => 0,
			'wp_content' => 0,
			'plugins'    => 0,
			'themes'     => 0,
			'uploads'    => 0,
		);

		$prefixes = array(
			'wp_content' => $this->normalize_path_prefix__premium_only( WP_CONTENT_DIR ),
			'plugins'    => $this->normalize_path_prefix__premium_only( WP_PLUGIN_DIR ),
			'themes'     => $this->normalize_path_prefix__premium_only( $theme_root ),
			'uploads'    => $this->normalize_path_prefix__premium_only( $uploads_dir ),
		);

		$abspath_prefix = $this->normalize_path_prefix__premium_only( ABSPATH );
		$content_prefix = $prefixes['wp_content'];
		$content_in_abspath = ( '' !== $content_prefix && 0 === strpos( $content_prefix, $abspath_prefix ) );

		// One pass over ABSPATH buckets all in-tree paths.
		$abspath_buckets = $this->walk_directory_buckets__premium_only( ABSPATH, $prefixes, true );
		foreach ( $buckets as $key => $value ) {
			$buckets[ $key ] += $abspath_buckets[ $key ];
		}

		// If wp-content lives outside ABSPATH, walk it separately and add to totals.
		if ( ! $content_in_abspath ) {
			$external_buckets = $this->walk_directory_buckets__premium_only( WP_CONTENT_DIR, $prefixes, true );
			foreach ( $buckets as $key => $value ) {
				$buckets[ $key ] += $external_buckets[ $key ];
			}
		}

		// Walk any special roots that sit outside both ABSPATH and WP_CONTENT_DIR (custom setups).
		$covered_roots = array( $abspath_prefix );
		if ( ! $content_in_abspath && '' !== $content_prefix ) {
			$covered_roots[] = $content_prefix;
		}

		foreach ( array( 'plugins', 'themes', 'uploads', 'wp_content' ) as $bucket_key ) {
			$prefix = isset( $prefixes[ $bucket_key ] ) ? $prefixes[ $bucket_key ] : '';
			if ( '' === $prefix ) {
				continue;
			}
			if ( $this->path_is_under_any__premium_only( $prefix, $covered_roots ) ) {
				continue;
			}

			$isolated = $this->walk_directory_buckets__premium_only(
				$prefix,
				array( $bucket_key => $prefix ),
				( 'wp_content' === $bucket_key )
			);

			$buckets[ $bucket_key ] += $isolated[ $bucket_key ];
			if ( 'wp_content' === $bucket_key ) {
				$buckets['all_files'] += $isolated['all_files'];
			} else {
				// Custom plugin/theme/upload roots outside the site tree still count toward all files.
				$buckets['all_files'] += $isolated[ $bucket_key ];
			}

			$covered_roots[] = $prefix;
		}

		return array(
			'database'      => (int) $db_size,
			'all_files'     => (int) $buckets['all_files'],
			'wp_content'    => (int) $buckets['wp_content'],
			'plugins'       => (int) $buckets['plugins'],
			'themes'        => (int) $buckets['themes'],
			'uploads'       => (int) $buckets['uploads'],
			'entire_site'   => (int) $db_size + (int) $buckets['all_files'],
			'calculated_at' => time(),
		);
	}

	/**
	 * Whether a path is under any of the given root prefixes.
	 *
	 * @since 9.0.3
	 * @param string   $path  Normalized path with trailing slash.
	 * @param string[] $roots Normalized root prefixes.
	 * @return bool
	 */
	private function path_is_under_any__premium_only( $path, $roots ) {
		foreach ( $roots as $root ) {
			if ( '' !== $root && 0 === strpos( $path, $root ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Calculate database size from SHOW TABLE STATUS.
	 *
	 * @since 9.0.3
	 * @return int
	 */
	private function calculate_db_size__premium_only() {
		global $wpdb;

		$db_size = 0;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- intentional size probe.
		$result = $wpdb->get_results( 'SHOW TABLE STATUS', ARRAY_A );

		if ( is_array( $result ) && ! empty( $result ) ) {
			foreach ( $result as $row ) {
				$data_length  = isset( $row['Data_length'] ) ? (int) $row['Data_length'] : 0;
				$index_length = isset( $row['Index_length'] ) ? (int) $row['Index_length'] : 0;
				$db_size     += $data_length + $index_length;
			}
		}

		return $db_size;
	}

	/**
	 * Walk a directory once and bucket file sizes by path prefix.
	 *
	 * @since 9.0.3
	 * @param string               $root              Root path to walk.
	 * @param array<string,string> $prefixes          Map of bucket key => normalized path prefix.
	 * @param bool                 $count_all_as_root Whether every file under $root counts toward all_files.
	 * @return array<string,int>
	 */
	private function walk_directory_buckets__premium_only( $root, $prefixes, $count_all_as_root = true ) {
		$buckets = array(
			'all_files'  => 0,
			'wp_content' => 0,
			'plugins'    => 0,
			'themes'     => 0,
			'uploads'    => 0,
		);

		if ( empty( $root ) || ! is_dir( $root ) ) {
			return $buckets;
		}

		// Paths that should be excluded because they'll trigger open_basedir restriction errors / warnings.
		if ( false !== strpos( $root, 'wp-nc-easywp' ) ) {
			return $buckets;
		}

		$root = $this->normalize_path_prefix__premium_only( $root );

		try {
			$directory = new \IgnorantRecursiveDirectoryIterator( $root, \FilesystemIterator::SKIP_DOTS );
			$iterator  = new \RecursiveIteratorIterator( $directory, \RecursiveIteratorIterator::SELF_FIRST );
		} catch ( \UnexpectedValueException $e ) {
			return $buckets;
		} catch ( \Exception $e ) {
			return $buckets;
		}

		foreach ( $iterator as $file ) {
			try {
				$file_path = $file->getPathname();
			} catch ( \Throwable $e ) {
				continue;
			}

			if ( $this->should_skip_path__premium_only( $file_path ) ) {
				continue;
			}

			$path_length = function_exists( 'mb_strlen' ) ? mb_strlen( $file_path ) : strlen( $file_path );
			if ( ! is_numeric( $path_length ) || (int) $path_length > PHP_MAXPATHLEN ) {
				continue;
			}

			try {
				if ( ! $file->isFile() ) {
					continue;
				}
				$size = (int) $file->getSize();
			} catch ( \Throwable $e ) {
				continue;
			}

			$normalized = $this->normalize_path_prefix__premium_only( $file_path );

			if ( $count_all_as_root ) {
				$buckets['all_files'] += $size;
			}

			// Most-specific buckets first so nested paths (uploads under wp-content) are counted in each matching bucket.
			foreach ( array( 'uploads', 'plugins', 'themes', 'wp_content' ) as $key ) {
				if ( empty( $prefixes[ $key ] ) ) {
					continue;
				}
				if ( 0 === strpos( $normalized, $prefixes[ $key ] ) ) {
					$buckets[ $key ] += $size;
				}
			}
		}

		return $buckets;
	}

	/**
	 * Whether a path should be skipped during walks.
	 *
	 * @since 9.0.3
	 * @param string $file_path File or directory path.
	 * @return bool
	 */
	private function should_skip_path__premium_only( $file_path ) {
		// Do not process files with file path that includes the following strings. These are not default WordPress files, and can contain symlinks that causes fatal error when they are affected by open_base_dir restrictions.
		if ( false !== strpos( $file_path, '.cagefs' )
			|| false !== strpos( $file_path, '.cl.selector' )
			|| false !== strpos( $file_path, '.clwpos' )
			|| false !== strpos( $file_path, '.well-known' )
			|| false !== strpos( $file_path, '.tmb' )
			|| false !== strpos( $file_path, '.wp-cli' )
			|| false !== strpos( $file_path, 'cgi-bin' )
			|| false !== strpos( $file_path, 'bacups' )
			|| false !== strpos( $file_path, 'wp-nc-easywp' )
			|| 'wp' === substr( $file_path, -2 ) // specific case where there is a /wp/ folder symlinked to wp-cli
		) {
			return true;
		}

		return false;
	}

	/**
	 * Normalize a filesystem path to a trailing-slash, forward-slash form for prefix matching.
	 *
	 * @since 9.0.3
	 * @param string $path Path.
	 * @return string
	 */
	private function normalize_path_prefix__premium_only( $path ) {
		if ( empty( $path ) ) {
			return '';
		}

		$path = wp_normalize_path( $path );
		if ( '/' !== substr( $path, -1 ) ) {
			$path .= '/';
		}

		return $path;
	}

	/**
	 * Get cached sizes array from transient.
	 *
	 * @since 9.0.3
	 * @return array<string,mixed>|false
	 */
	private function get_cached_sizes__premium_only() {
		$cached = get_transient( self::SIZES_TRANSIENT );
		return is_array( $cached ) ? $cached : false;
	}

	/**
	 * Whether a sizes array has all required keys.
	 *
	 * @since 9.0.3
	 * @param array<string,mixed> $sizes Sizes payload.
	 * @return bool
	 */
	private function sizes_are_complete__premium_only( $sizes ) {
		$required = array( 'entire_site', 'database', 'all_files', 'wp_content', 'plugins', 'themes', 'uploads' );
		foreach ( $required as $key ) {
			if ( ! array_key_exists( $key, $sizes ) || ! is_numeric( $sizes[ $key ] ) ) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Format raw byte sizes for the dashboard JS.
	 *
	 * @since 9.0.3
	 * @param array<string,int> $sizes Raw sizes.
	 * @return array<string,string>
	 */
	private function format_sizes_for_js__premium_only( $sizes ) {
		$formatted = array();
		foreach ( array( 'entire_site', 'database', 'all_files', 'wp_content', 'plugins', 'themes', 'uploads' ) as $key ) {
			$formatted[ $key ] = size_format( (int) $sizes[ $key ], 2 );
		}
		return $formatted;
	}

}
