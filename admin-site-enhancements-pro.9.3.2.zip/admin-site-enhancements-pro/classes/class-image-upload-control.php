<?php

namespace ASENHA\Classes;
use Imagick;

/**
 * Class for Image Upload Control module
 *
 * @since 6.9.5
 */
class Image_Upload_Control {
    
    public $png_is_transparent;

    /**
     * Per-request cache of PNG transparency checks, keyed by file path.
     *
     * @since 9.1.2
     *
     * @var array
     */
    private $png_transparency_cache;

    /**
     * Last readable PNG path seen by `image_editor_output_format` in this request.
     *
     * WordPress calls the filter with the source path first, then again with
     * an empty or not-yet-written destination when generating intermediate sizes.
     *
     * @since 9.1.2
     *
     * @var string
     */
    private $png_source_file;

    /**
     * Array storing the file names that were processed, as keys.
     *
     * @since 7.5.0
     * @link https://plugins.trac.wordpress.org/browser/fix-image-rotation/tags/2.2.2/includes/class-fix-image-rotation.php#L30
     *
     * @access private
     *
     * @var array
     */
    private $orientation_fixed;

    /**
     * Array storing the meta data of original files in case it
     * needs to be restored later.
     *
     * @since 7.5.0
     * @link https://plugins.trac.wordpress.org/browser/fix-image-rotation/tags/2.2.2/includes/class-fix-image-rotation.php#L42
     *
     * @access private
     *
     * @var array
     */
    private $previous_meta;
        
    /**
     * Constructor
     * @since 7.4.3
     */
    function __construct() {
        $this->png_is_transparent      = false;
        $this->png_transparency_cache  = array();
        $this->png_source_file         = '';
        $this->orientation_fixed       = array();
        $this->previous_meta           = array();
    }

    /**
     * Handler for image uploads. Convert and resize images.
     *
     * @since 4.3.0
     */
    public function image_upload_handler( $upload ) {
        $options = get_option( ASENHA_SLUG_U, array() );

        if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
            if ( ! $this->should_apply_image_upload_control__premium_only( $options ) ) {
                return $upload;
            }   
        }

        if ( $this->is_client_side_processing_enabled( $options ) && $this->is_client_side_upload_request() ) {
            $disable_image_conversion = false;
            if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
                $disable_image_conversion = isset( $options['disable_image_conversion'] ) ? $options['disable_image_conversion'] : false;
            }

            // wasm-vips does not handle BMP; keep server-side conversion on the original upload.
            if (
                ! $disable_image_conversion
                && isset( $upload['type'], $upload['file'] )
                && ( 'image/bmp' === $upload['type'] || 'image/x-ms-bmp' === $upload['type'] )
                && false === strpos( $upload['file'], '-nr.' )
            ) {
                return $this->maybe_convert_image( 'bmp', $upload );
            }

            return $upload;
        }

        $applicable_mime_types = array(
            'image/bmp',
            'image/x-ms-bmp',
            'image/png',
            'image/jpeg',
            'image/jpg',
            'image/webp',
        );

        $disable_image_conversion = false;
        if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
            $disable_image_conversion = isset( $options['disable_image_conversion'] ) ? $options['disable_image_conversion'] : false ;
        }
                
        if ( in_array( $upload['type'], $applicable_mime_types ) ) {

            // Exlude from conversion and resizing images with filenames ending with '-nr', e.g. birds-nr.png
            if ( false !== strpos( $upload['file'], '-nr.' ) ) {
                return $upload;
            }
            
            // Image conversion is not disabled
            if ( ! $disable_image_conversion ) {
                // Convert BMP
                if ( ( 'image/bmp' === $upload['type'] || 'image/x-ms-bmp' === $upload['type'] ) ) {
                    $upload = $this->maybe_convert_image( 'bmp', $upload );
                }

                // Convert PNG without transparency
                if ( 'image/png' === $upload['type'] ) {
                    $upload = $this->maybe_convert_image( 'png', $upload );
                }                
            }
            
            // At this point, BMPs and non-transparent PNGs are already converted to JPGs, unless excluded with '-nr' suffix.
            // Let's perform resize operation as needed, i.e. if image dimension is larger than specified
            $mime_types_to_resize = array( 'image/jpeg', 'image/jpg', 'image/png', 'image/webp' );

            if ( 
                ( ! is_wp_error( $upload ) && 
                in_array( $upload['type'], $mime_types_to_resize ) &&
                filesize( $upload['file'] ) > 0 )
            ) {

                // https://developer.wordpress.org/reference/classes/wp_image_editor/
                $wp_image_editor = wp_get_image_editor( $upload['file'] );

                if ( ! is_wp_error( $wp_image_editor ) ) {
                    $image_size = $wp_image_editor->get_size();

                    $max_width = $options['image_max_width'];
                    $max_height = $options['image_max_height'];
                    if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
                        $convert_to_jpg_quality = isset( $options['convert_to_jpg_quality'] ) ? intval( $options['convert_to_jpg_quality'] ) : 82 ;
                    } else {
                        $convert_to_jpg_quality = 82;
                    }

                    $did_resize = false;

                    // Check upload image's dimension and only resize if larger than the defined max dimension
                    if (
                        ( isset( $image_size['width'] ) && $image_size['width'] > $max_width ) ||
                        ( isset( $image_size['height'] ) && $image_size['height'] > $max_height )
                    ) {
                        $wp_image_editor->resize( $max_width, $max_height, false ); // false is for no cropping
                        $did_resize = true;
                    }
                    
                    // Save only when a resize happened.
                    // Avoid re-encoding (and potentially recompressing) images that are already within max dimensions.
                    if ( $did_resize ) {
                        if ( 'image/jpg' === $upload['type'] || 'image/jpeg' === $upload['type'] ) {
                            $wp_image_editor->set_quality( $convert_to_jpg_quality );
                        }

                        // Overwrite the upload in its own format. ASE's output format map (for
                        // client-side processing) would otherwise make WP_Image_Editor write
                        // x.webp next to an unresized x.jpg. Conversion happens further below.
                        add_filter( 'image_editor_output_format', '__return_empty_array', PHP_INT_MAX );
                        $wp_image_editor->save( $upload['file'] );
                        remove_filter( 'image_editor_output_format', '__return_empty_array', PHP_INT_MAX );
                    }
                }
            }

            if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
                // Image conversion is not disabled
                if ( ! $disable_image_conversion ) {
                    $options = get_option( ASENHA_SLUG_U, array() );
                    $convert_to_webp = isset( $options['convert_to_webp'] ) ? $options['convert_to_webp'] : false ;
                    $webp_conversion_quality = isset( $options['convert_to_webp_quality'] ) ? intval( $options['convert_to_webp_quality'] ) : 82 ;
                    $mime_types_to_convert = array( 'image/jpeg', 'image/jpg', 'image/png' );

                    // Let's convert to WebP
                    if ( $convert_to_webp  && in_array( $upload['type'], $mime_types_to_convert ) ) {
                        // Get file extension
                        if ( false !== strpos( $upload['file'], '.png' ) ) {
                            $file_extension = 'png';
                        }
                        if ( false !== strpos( $upload['file'], '.jpg' ) ) {
                            $file_extension = 'jpg';
                        }
                        if ( false !== strpos( $upload['file'], '.jpeg' ) ) {
                            $file_extension = 'jpeg';
                        }

                        $keep_original_image = isset( $options['keep_original_image'] ) ? $options['keep_original_image'] : false ;

                        // Assign new, unique file name for the converted image
                        $wp_uploads     = wp_upload_dir();
                        $new_filename   = $this->get_converted_image_filename( $upload['file'], 'webp', ! $keep_original_image );
                        $webp_path      = $wp_uploads['path'] . '/' . $new_filename;
                        
                        // Let's convert to WebP based on the active editor
                        // which is shown in Tools >> Site Health >> Info >> Media Handling
                        $active_editor = _wp_image_editor_choose();

                        // For wp_image_editor_supports()
                        // $args = array(
                        //     'mime_type' => 'image/webp',
                        //     'methods'   => array(
                        //         'set_quality',
                        //         'save',
                        //     ),
                        // );

                        $converted_to_webp = false;

                        if ( 'WP_Image_Editor_GD' == $active_editor && function_exists( 'imagewebp' ) ) {
                            // Generate image object from PNG/JPG, then generate WebP from it
                            $converted_to_webp = $this->gd_generate_webp( 
                                $upload['file'], 
                                $file_extension, 
                                $webp_path, 
                                $webp_conversion_quality 
                            );
                        } elseif ( 'WP_Image_Editor_Imagick' == $active_editor && class_exists( 'Imagick' ) ) {
                            if ( in_array( $file_extension, array( 'png', 'jpg', 'jpeg' ) ) ) {
                                // Image is a JPG / JPEG or non-transparent PNG. Let's convert with Imagick
                                try {
                                    $imagick = new Imagick();
                                    $supported_formats = $imagick::queryFormats();
                                    if ( in_array( 'WEBP', $supported_formats ) ) {
                                        // Ref: https://www.jclabs.co.uk/generate-webp-images-in-php-using-and-gd-or-imagick/
                                        $imagick->readImage( $upload['file'] );
                                        $imagick->setImageFormat( 'webp' );
                                        // $imagick->setFormat( 'webp' );
                                        $imagick->setImageCompressionQuality( $webp_conversion_quality );
                                        if ( 100 == $webp_conversion_quality ) {
                                            $imagick->setOption( 'webp:lossless', 'true' );
                                        }
                                        $converted_to_webp = (bool) $imagick->writeImage( $wp_uploads['path'] . '/' . $new_filename );
                                    } elseif ( function_exists( 'imagewebp' ) ) {
                                        // Imagick does not support WebP, let's try to use GD
                                        $converted_to_webp = $this->gd_generate_webp( 
                                            $upload['file'], 
                                            $file_extension, 
                                            $webp_path, 
                                            $webp_conversion_quality 
                                        );
                                    }
                                    $imagick->clear();
                                    $imagick->destroy();
            } catch ( \Exception $e ) {
                $converted_to_webp = false;
                if ( isset( $imagick ) && $imagick instanceof Imagick ) {
                    try {
                        $imagick->clear();
                        $imagick->destroy();
                    } catch ( \Exception $cleanup_exception ) {
                        unset( $cleanup_exception );
                    }
                }
                unset( $e );
            }
                            }
                        }

                        // elseif ( 'WP_Image_Editor_Imagick' == $active_editor && wp_image_editor_supports( $args ) ) {
                        //     $wp_image_editor = wp_get_image_editor( $upload['file'] );
                        //     if ( ! is_wp_error( $wp_image_editor ) ) {
                        //         $wp_image_editor->set_quality( $webp_conversion_quality );
                        //         $wp_image_editor->save( $wp_uploads['path'] . '/' . $new_filename, 'image/webp' );
                        //     }
                        // }

                        // Replace the original only after a WebP file was actually written.
                        if ( $converted_to_webp && is_file( $webp_path ) ) {
                            if ( ! $keep_original_image ) {
                                unlink( $upload['file'] );
                            }

                            // Add converted WebP info into $upload
                            $upload['file'] = $wp_uploads['path'] . '/' . $new_filename;
                            $upload['url']  = $wp_uploads['url'] . '/' . $new_filename;
                            $upload['type'] = 'image/webp';
                        }
                    }                    
                }
            }
        }

        return $upload;

    }

    /**
     * Convert BMP or PNG without transparency into JPG
     *
     * @since 4.3.0
     */
    public function maybe_convert_image( $file_extension, $upload ) {

        $image_object = false;

        // Get image object from uploaded BMP/PNG. imagecreatefromstring() accepts
        // any raster type GD supports, so a valid image with a mismatched
        // extension (common in demo imports) is still converted.

        if ( 'png' === $file_extension ) {

            $this->png_is_transparent = $this->png_has_transparency( $upload['file'] );

            // Do not convert PNG with alpha/transparency, or a file that could not be decoded.
            if ( $this->png_is_transparent ) {
                return $upload;
            }

        }

        if ( 'bmp' === $file_extension || 'png' === $file_extension ) {
            $image_object = $this->load_gd_image_from_file( $upload['file'] );
        }
        
        // Let's convert BMP and non-transparent PNG into JPG
        $converted_to_jpg = false;
        $keep_original_image = false;

        if ( is_object( $image_object ) || class_exists( 'Imagick' ) ) {
            $wp_uploads     = wp_upload_dir();

            // maybe delete original BMP/PNG
            if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
                $options = get_option( ASENHA_SLUG_U, array() );
                $keep_original_image = isset( $options['keep_original_image'] ) ? $options['keep_original_image'] : false ;
            } else {
                // original image is always deleted in ASE Free
                $keep_original_image = false;
            }

            // Assign new, unique file name for the converted image
            $new_filename   = $this->get_converted_image_filename( $upload['file'], 'jpg', ! $keep_original_image );

            $converted_to_jpg = false;
        }

        // Prefer GD when JPEG encode is available. Some custom PHP builds ship GD with PNG
        // support but without imagejpeg(); guard that case and fall back to Imagick below.
        if ( is_gd_image( $image_object ) && function_exists( 'imagejpeg' ) ) {
            // When conversion from BMP/PNG to JPG is successful using GD. Last parameter is JPG quality (0-100).
            if ( \imagejpeg( $image_object, $wp_uploads['path'] . '/' . $new_filename, 90 ) ) {
                $converted_to_jpg = true;
            }
        }

        $this->destroy_gd_image( $image_object );

        // Fall back to Imagick when GD image object creation failed, imagejpeg() is unavailable,
        // or GD JPEG encode returned false.
        if ( ! $converted_to_jpg && class_exists( 'Imagick' ) ) {
            try {
                $imagick = new Imagick();

                $imagick->readImage( $upload['file'] );
                $imagick->setImageCompressionQuality( 90 );
                $imagick->setImageFormat( 'jpg' );
                // $imagick->setFormat( 'jpg' );
                if ( $imagick->writeImage( $wp_uploads['path'] . '/' . $new_filename ) ) {
                    $converted_to_jpg = true;
                }

                $imagick->clear();
                $imagick->destroy();
            } catch ( \Exception $e ) {
                $converted_to_jpg = false;
                if ( isset( $imagick ) && $imagick instanceof Imagick ) {
                    try {
                        $imagick->clear();
                        $imagick->destroy();
                    } catch ( \Exception $cleanup_exception ) {
                        unset( $cleanup_exception );
                    }
                }
                unset( $e );
            }
        }

        if ( $converted_to_jpg ) {
            // Delete original BMP / PNG
            if ( ! $keep_original_image ) {
                unlink( $upload['file'] );
            }

            // Add converted JPG info into $upload
            $upload['file'] = $wp_uploads['path'] . '/' . $new_filename;
            $upload['url']  = $wp_uploads['url'] . '/' . $new_filename;
            $upload['type'] = 'image/jpeg';            
        }

        return $upload;

    }

    /**
     * Pick a unique file name for a converted image.
     *
     * With an output format map active (e.g. jpeg => webp), wp_unique_filename()
     * also treats same-named files with the mapped extensions as conflicts. The
     * source file is still on disk at this point, so photo.webp would become
     * photo-1.webp because of photo.jpg. When the source is about to be deleted
     * that conflict is not real. wp_handle_upload() already checked the source
     * name against those alternate names, so the map is set aside here. Exact
     * matches and sub-size names are still checked.
     *
     * @since 9.3.1
     *
     * @param string $source_file        Absolute path of the image being converted.
     * @param string $new_extension      Extension of the converted image, without the dot.
     * @param bool   $will_delete_source Whether the source file is deleted after conversion.
     * @return string Unique file name (basename) in the source file's directory.
     */
    private function get_converted_image_filename( $source_file, $new_extension, $will_delete_source ) {
        $directory      = dirname( $source_file );
        $source_ext     = pathinfo( $source_file, PATHINFO_EXTENSION );
        $source_name    = wp_basename( $source_file, '' !== $source_ext ? '.' . $source_ext : '' );
        $new_filename   = $source_name . '.' . $new_extension;

        if ( ! $will_delete_source ) {
            return wp_unique_filename( $directory, $new_filename );
        }

        add_filter( 'image_editor_output_format', '__return_empty_array', PHP_INT_MAX );
        $new_filename = wp_unique_filename( $directory, $new_filename );
        remove_filter( 'image_editor_output_format', '__return_empty_array', PHP_INT_MAX );

        return $new_filename;
    }

    /**
     * Load a raster image into a GD object from file bytes.
     *
     * Modeled on WP_Image_Editor_GD::load(). imagecreatefromstring() detects
     * the format from the binary signature, so a valid JPEG, GIF, WebP, or BMP
     * stored with a .png name still becomes an image. The silence matches core:
     * a non-image sideloaded by a demo importer must not emit a warning.
     *
     * @since 9.2.0
     *
     * @param string $file Absolute path to the image file.
     * @return GdImage|resource|false GD image on success, false otherwise.
     */
    private function load_gd_image_from_file( $file ) {
        if ( ! is_string( $file ) || '' === $file || ! is_file( $file ) || ! is_readable( $file ) ) {
            return false;
        }

        if ( ! function_exists( 'imagecreatefromstring' ) ) {
            return false;
        }

        if ( function_exists( 'wp_raise_memory_limit' ) ) {
            wp_raise_memory_limit( 'image' );
        }

        // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
        $contents = file_get_contents( $file );
        if ( ! is_string( $contents ) || '' === $contents ) {
            return false;
        }

        // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- See method docblock. Matches WP_Image_Editor_GD::load().
        $image = @imagecreatefromstring( $contents );

        if ( ! is_gd_image( $image ) ) {
            return false;
        }

        return $image;
    }

    /**
     * Free a GD image created while inspecting or converting an upload.
     *
     * @since 9.2.0
     *
     * @param mixed $image GD image, or false when loading failed.
     */
    private function destroy_gd_image( $image ) {
        if ( is_gd_image( $image ) && function_exists( 'imagedestroy' ) ) {
            imagedestroy( $image );
        }
    }

    /**
     * Whether a PNG file has at least one transparent / alpha pixel.
     *
     * Results are cached per file path for the current request because
     * `image_editor_output_format` can run once per intermediate size.
     *
     * A file that GD and Imagick cannot decode returns true. Callers treat
     * true as "do not convert", so an undecodable demo file is left as uploaded
     * instead of being treated as an opaque PNG.
     *
     * @since 9.1.2
     *
     * @param string $file Absolute path to the PNG file.
     * @return bool True when a transparent pixel is found, or the file cannot be decoded.
     */
    private function png_has_transparency( $file ) {
        if ( array_key_exists( $file, $this->png_transparency_cache ) ) {
            return $this->png_transparency_cache[ $file ];
        }

        $is_transparent = false;
        $image_object   = $this->load_gd_image_from_file( $file );

        if ( is_gd_image( $image_object ) ) {
            $width  = \imagesx( $image_object );
            $height = \imagesy( $image_object );

            // Run through pixels until a transparent pixel is found.
            if ( $width > 0 && $height > 0 ) {
                for ( $x = 0; $x < $width; $x++ ) {
                    for ( $y = 0; $y < $height; $y++ ) {
                        $pixel_color_index = \imagecolorat( $image_object, $x, $y );
                        $pixel_rgba = \imagecolorsforindex( $image_object, $pixel_color_index );

                        if ( $pixel_rgba['alpha'] > 0 ) {
                            // Alpha value range from 0 (completely opaque) to 127 (fully transparent).
                            // Ref: https://www.php.net/manual/en/function.imagecolorallocatealpha.php
                            $is_transparent = true;
                            break 2;
                        }
                    }
                }
            }

            $this->destroy_gd_image( $image_object );
        } elseif ( class_exists( 'Imagick' ) ) {
            try {
                $imagick = new Imagick();
                $imagick->readImage( $file );
                // Ref: https://stackoverflow.com/a/52295997
                // Ref: https://www.php.net/manual/en/imagick.getimagechannelrange.php
                $alpha_range = $imagick->getImageChannelRange( Imagick::CHANNEL_ALPHA );
                $is_transparent = $alpha_range['minima'] < $alpha_range['maxima'];
                $imagick->clear();
                $imagick->destroy();
            } catch ( \Exception $e ) {
                $is_transparent = true;
                if ( isset( $imagick ) && $imagick instanceof Imagick ) {
                    try {
                        $imagick->clear();
                        $imagick->destroy();
                    } catch ( \Exception $cleanup_exception ) {
                        unset( $cleanup_exception );
                    }
                }
                unset( $e );
            }
        } elseif ( is_file( $file ) ) {
            $is_transparent = true;
        }

        $this->png_transparency_cache[ $file ] = $is_transparent;

        return $is_transparent;
    }

    /**
     * Whether PNG should be mapped to JPEG in `image_editor_output_format`.
     *
     * WordPress calls this filter with the source path first, then again with
     * an empty filename (`make_subsize`) or a destination path that does not
     * exist yet. Remember the last readable PNG and inspect that file when
     * the current path cannot be read. Fail closed (keep PNG) when no source
     * is available — empty filename must not imply PNG→JPEG.
     *
     * @since 9.1.2
     *
     * @param string $filename  Path passed to the output format filter.
     * @param string $mime_type Source mime type passed to the filter.
     * @return bool
     */
    private function should_convert_png_to_jpeg( $filename, $mime_type ) {
        $inspect = $filename;
        $is_png  = ( 'image/png' === $mime_type )
            || ( '' !== $filename && 'png' === strtolower( pathinfo( $filename, PATHINFO_EXTENSION ) ) );

        if ( '' !== $filename && is_readable( $filename ) && $is_png ) {
            $this->png_source_file = $filename;
        } elseif ( '' === $filename || ! is_readable( $filename ) ) {
            $inspect = $this->png_source_file;
        }

        if ( '' === $inspect || ! is_readable( $inspect ) ) {
            return false;
        }

        $inspect_is_png = ( 'image/png' === $mime_type )
            || ( 'png' === strtolower( pathinfo( $inspect, PATHINFO_EXTENSION ) ) );

        if ( $inspect_is_png && $this->png_has_transparency( $inspect ) ) {
            return false;
        }

        return true;
    }
    
    /**
     * Generate a WebP image from a PNG or JPEG file with GD.
     *
     * @since 6.9.11
     *
     * @param string $file                     Absolute path to the source image.
     * @param string $file_extension           Source extension: png, jpg, or jpeg.
     * @param string $webp_path                Destination path for the WebP file.
     * @param int    $webp_conversion_quality  WebP quality from 0 to 100.
     * @return bool True when the WebP file was written.
     */
    public function gd_generate_webp( $file, $file_extension, $webp_path, $webp_conversion_quality ) {
        $image_object = $this->load_gd_image_from_file( $file );

        if ( ! is_gd_image( $image_object ) ) {
            return false;
        }

        if ( 'png' == $file_extension && $this->png_is_transparent && function_exists( 'imagepalettetotruecolor' ) ) {
            \imagepalettetotruecolor( $image_object );
        }

        $created = false;

        // Second parameter is file path, last parameter is WebP quality (0-100).
        if ( function_exists( 'imagewebp' ) ) {
            $created = \imagewebp( $image_object, $webp_path, $webp_conversion_quality );
        }

        $this->destroy_gd_image( $image_object );

        return (bool) $created;
    }
    
    /**
     * Checks the filename before it is uploaded to WordPress and
     * runs the fix_image_orientation function in case its needed.
     *
     * @since 7.5.0
     * @link https://plugins.trac.wordpress.org/browser/fix-image-rotation/tags/2.2.2/includes/class-fix-image-rotation.php#L172
     *
     * @access public
     *
     * @hook wp_handle_upload_prefilter
     *
     * @param array $file An array of data for a single file.
     *
     * @return array An array of data for a single file.
     */
    public function prefilter_maybe_fix_image_orientation( $file ) {
        if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
            if ( ! $this->should_apply_image_upload_control__premium_only() ) {
                return $file;
            }   
        }

        if ( $this->is_client_side_processing_enabled() && $this->is_client_side_upload_request() ) {
            return $file;
        }

        // Get the file extension
        // $suffix = substr( $file['name'], strrpos( $file['name'], '.', -1 ) + 1 );
        $suffix = pathinfo( $file['name'], PATHINFO_EXTENSION );

        if ( in_array( strtolower( $suffix ), array( 'jpg', 'jpeg', 'tiff' ), true ) ) {
            $this->fix_image_orientation( $file['tmp_name'] );
        }
        
        return $file;
    }

    /**
     * Checks the filename before it is uploaded to WordPress and
     * runs the fix_image_orientation function in case its needed.
     *
     * @since 7.5.0
     * @link https://plugins.trac.wordpress.org/browser/fix-image-rotation/tags/2.2.2/includes/class-fix-image-rotation.php#L150
     *
     * @access public
     *
     * @hook wp_handle_upload
     *
     * @param array $file {
     *    Array of upload data.
     *
     *     @type string $file Filename of the newly-uploaded file.
     *     @type string $url  URL of the uploaded file.
     *     @type string $type File type.
     * }
     *
     * @return array Array of upload data.
     */
    public function maybe_fix_image_orientation( $file ) {
        if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
            if ( ! $this->should_apply_image_upload_control__premium_only() ) {
                return $file;
            }   
        }

        if ( $this->is_client_side_processing_enabled() && $this->is_client_side_upload_request() ) {
            return $file;
        }

        $suffix = substr( $file['file'], strrpos( $file['file'], '.', -1 ) + 1 );
        if ( in_array( strtolower( $suffix ), array( 'jpg', 'jpeg', 'tiff' ), true ) ) {
            $this->fix_image_orientation( $file['file'] );
        }
        return $file;
    }

    /**
     * Fixes the orientation of the image based on exif data
     *
     * @since 7.5.0
     * @link https://plugins.trac.wordpress.org/browser/fix-image-rotation/tags/2.2.2/includes/class-fix-image-rotation.php#L191
     *
     * @access public
     *
     * @param string $file Path of the file.
     *
     * @return void
     */
    public function fix_image_orientation( $file ) {
        if ( ! isset( $this->orientation_fixed[ $file ] ) ) {
            $exif = @exif_read_data( $file );

            if ( isset( $exif ) && isset( $exif['Orientation'] ) && $exif['Orientation'] > 1 ) {

                // Need it so that image editors are available to us.
                // include_once ABSPATH . 'wp-admin/includes/image-edit.php';

                // Calculate the operations we need to perform on the image.
                $operations = $this->calculate_flip_and_rotate( $file, $exif );

                if ( false !== $operations ) {
                    // Lets flip flop and rotate the image as needed.
                    $this->do_flip_and_rotate( $file, $operations );
                }
            }
        }
    }

    /**
     * Calculate the flips and rotations image will need to do to fix its orientation.
     *
     * @since 7.5.0
     * @link https://plugins.trac.wordpress.org/browser/fix-image-rotation/tags/2.2.2/includes/class-fix-image-rotation.php#L225
     *
     * @access private
     *
     * @param string $file Path of the file.
     *
     * @param array  $exif Exif data of the image.
     *
     * @return array|bool Array of operations to be performed on the image,
     *                    false if no operations are needed.
     */
    private function calculate_flip_and_rotate( $file, $exif ) {
        $rotator     = false;
        $flipper     = false;
        $orientation = 0;

        // Lets switch to the orientation defined in the exif data.
        switch ( $exif['Orientation'] ) {
            case 1:
                // We don't want to fix an already correct image :).
                $this->orientation_fixed[ $file ] = true;
                return false;
            case 2:
                $flipper = array( false, true );
                break;
            case 3:
                $orientation = -180;
                $rotator     = true;
                break;
            case 4:
                $flipper = array( true, false );
                break;
            case 5:
                $orientation = -90;
                $rotator     = true;
                $flipper     = array( false, true );
                break;
            case 6:
                $orientation = -90;
                $rotator     = true;
                break;
            case 7:
                $orientation = -270;
                $rotator     = true;
                $flipper     = array( false, true );
                break;
            case 8:
            case 9:
                $orientation = -270;
                $rotator     = true;
                break;
            default:
                $orientation = 0;
                $rotator     = true;
                break;
        }

        return compact( 'orientation', 'rotator', 'flipper' );
    }

    /**
     * Flips and rotates the image based on the parameters provided.
     *
     * @since 7.5.0
     * @link https://plugins.trac.wordpress.org/browser/fix-image-rotation/tags/2.2.2/includes/class-fix-image-rotation.php#L299
     *
     * @access private
     *
     * @param string $file Path of the file.
     *
     * @param array  $operations {
     *      Array of operations to be performed on the image.
     *
     *      @type bool       $rotator Whether to rotate the image or not.
     *      @type int        $orientation Amount of rotation to be performed in degrees.
     *      @type array|bool $flipper {
     *          Whether to flip the image or not, false if no flipping needed.
     *
     *          @type bool $0 Flip along Horizontal Axis.
     *          @type bool $1 Flip along Vertical Axis.
     *      }
     * }
     *
     * @return bool Returns true if operations were successful, false otherwise.
     */
    private function do_flip_and_rotate( $file, $operations ) {
        $editor = wp_get_image_editor( $file );

        // If GD Library is being used, then we need to store metadata to restore later.
        if ( 'WP_Image_Editor_GD' === get_class( $editor ) ) {
            include_once ABSPATH . 'wp-admin/includes/image.php';
            $this->previous_meta[ $file ] = wp_read_image_metadata( $file );
        }

        if ( ! is_wp_error( $editor ) ) {
            // Lets rotate and flip the image based on exif orientation.
            if ( true === $operations['rotator'] ) {
                $editor->rotate( $operations['orientation'] );
            }
            if ( false !== $operations['flipper'] ) {
                $editor->flip( $operations['flipper'][0], $operations['flipper'][1] );
            }
            $editor->save( $file );
            $this->orientation_fixed[ $file ] = true;
            add_filter( 'wp_read_image_metadata', array( $this, 'restore_meta_data' ), 10, 2 );
            return true;
        }

        return false;
    }

    /**
     * Restores the meta data of the image after being processed.
     *
     * WordPress' Imagick Library does not need this, but GD library
     * removes metadata from the image upon rotation or flip so this
     * method restores those values.
     *
     * @since 7.5.0
     * @link https://plugins.trac.wordpress.org/browser/fix-image-rotation/tags/2.2.2/includes/class-fix-image-rotation.php#L341
     *
     * @hook wp_read_image_metadata
     *
     * @param array  $meta Image meta data.
     * @param string $file Path to image file.
     *
     * @return array Image meta data.
     */
    public function restore_meta_data( $meta, $file ) {
        if ( isset( $this->previous_meta[ $file ] ) ) {
            $meta = $this->previous_meta[ $file ];

            // Setting the Orientation meta to the new value after fixing the rotation.
            $meta['orientation'] = 1;
            return $meta;
        }
        return $meta;
    }

    /**
     * Disable the generation of auto-generated intermediate sizes
     * 
     * @since 7.8.2
     */
    public function disable_intermediate_image_sizes__premium_only( $sizes, $image_meta ) {
        if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
            if ( ! $this->should_apply_image_upload_control__premium_only() ) {
                return $sizes;
            }
        }

        $options = get_option( ASENHA_SLUG_U, array() );
        $disabled_image_sizes = isset( $options['disabled_image_sizes'] ) ? $options['disabled_image_sizes'] : array();

        $common_methods = new Common_Methods;
        $disabled_image_size_slugs = $common_methods->get_array_of_keys_with_true_value( $disabled_image_sizes );
        
        foreach( $sizes as $size_slug => $size_info ) {
            if ( in_array( $size_slug, $disabled_image_size_slugs ) ) {
                unset( $sizes[$size_slug] );
            }
        }
       
        return $sizes;
    }

    /**
     * Whether Image Upload Control should process the current request.
     *
     * When the setting `image_upload_control_only_media_library_uploads` is enabled,
     * processing is limited to Media Library / wp.media uploads and REST media uploads
     * used by the block editor (`wp/v2/media`).
     *
     * @since 7.9.0
     *
     * @param array|null $options Optional cached plugin options.
     * @return bool
     */
    private function should_apply_image_upload_control__premium_only( $options = null ) {
        if ( null === $options ) {
            $options = get_option( ASENHA_SLUG_U, array() );
        }

        $only_media_library_uploads = isset( $options['image_upload_control_only_media_library_uploads'] )
            ? (bool) $options['image_upload_control_only_media_library_uploads']
            : false;

        if ( ! $only_media_library_uploads ) {
            return true;
        }

        return $this->is_media_library_upload_request__premium_only();
    }

    /**
     * Whether the upload request originated from an allowed wp-admin screen.
     *
     * @since 7.9.0
     *
     * @return bool
     */
    private function is_allowed_upload_referer__premium_only() {
        $referer = wp_get_referer();
        if ( empty( $referer ) ) {
            return false;
        }

        $admin_path = wp_parse_url( admin_url(), PHP_URL_PATH );
        $ref_path   = wp_parse_url( $referer, PHP_URL_PATH );

        if ( empty( $admin_path ) || empty( $ref_path ) || 0 !== strpos( $ref_path, $admin_path ) ) {
            return false;
        }

        $allowed_pages = array(
            'post.php',
            'post-new.php',
            'upload.php',
            'media-new.php',
        );

        $ref_page = wp_basename( $ref_path );

        return in_array( $ref_page, $allowed_pages, true );
    }

    /**
     * Detect whether current request is a Media Library / block editor media upload.
     *
     * @since 7.9.0
     *
     * @return bool
     */
    private function is_media_library_upload_request__premium_only() {
        // AJAX uploader used by Media Library and wp.media (admin).
        if ( function_exists( 'wp_doing_ajax' ) && wp_doing_ajax() ) {
            if ( isset( $_REQUEST['action'] ) ) {
                $action = sanitize_key( wp_unslash( $_REQUEST['action'] ) );
                if ( 'upload-attachment' === $action ) {
                    return $this->is_allowed_upload_referer__premium_only();
                }
            }
        }

        // Admin async upload endpoint.
        if ( is_admin() ) {
            global $pagenow;
            if ( isset( $pagenow ) && 'async-upload.php' === $pagenow ) {
                return $this->is_allowed_upload_referer__premium_only();
            }
        }

        // REST endpoint used by block editor and other clients: /wp/v2/media.
        if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
            // If referrer is missing or not one of the allowed wp-admin pages, treat it as frontend.
            if ( ! $this->is_allowed_upload_referer__premium_only() ) {
                return false;
            }

            if ( isset( $_GET['rest_route'] ) ) {
                $rest_route = (string) wp_unslash( $_GET['rest_route'] );
                if ( 0 === strpos( $rest_route, '/wp/v2/media' ) ) {
                    return true;
                }
            }

            $request_uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
            if ( '' !== $request_uri ) {
                $prefix = '/' . rest_get_url_prefix() . '/wp/v2/media';
                if ( false !== strpos( $request_uri, $prefix ) ) {
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * Whether browser-based libvips processing is enabled for Image Upload Control.
     *
     * Absent option defaults to true on WordPress 7.1+.
     *
     * @since 9.2.0
     *
     * @param array|null $options Optional cached plugin options.
     * @return bool
     */
    public function is_client_side_processing_enabled( $options = null ) {
        if ( ! function_exists( 'wp_is_client_side_media_processing_enabled' ) ) {
            return false;
        }

        if ( null === $options ) {
            $options = get_option( ASENHA_SLUG_U, array() );
        }

        if ( ! is_array( $options ) || ! array_key_exists( 'image_upload_control_client_side_processing', $options ) ) {
            return true;
        }

        return (bool) $options['image_upload_control_client_side_processing'];
    }

    /**
     * Disable Core client-side media processing when the ASE checkbox is off.
     *
     * @since 9.2.0
     *
     * @param bool $enabled Whether Core client-side processing is enabled.
     * @return bool
     */
    public function maybe_disable_client_side_media_processing( $enabled ) {
        if ( ! $this->is_client_side_processing_enabled() ) {
            return false;
        }

        return $enabled;
    }

    /**
     * Map ASE max dimensions onto Core's longest-side threshold for wasm-vips.
     *
     * @since 9.2.0
     *
     * @param int|bool $threshold Current big image size threshold.
     * @return int|bool
     */
    public function maybe_set_big_image_size_threshold( $threshold ) {
        if ( ! $this->is_client_side_processing_enabled() ) {
            return $threshold;
        }

        if ( ! $this->should_map_client_side_filters() ) {
            return $threshold;
        }

        $options = get_option( ASENHA_SLUG_U, array() );
        $max_width = isset( $options['image_max_width'] ) ? intval( $options['image_max_width'] ) : 1920;
        $max_height = isset( $options['image_max_height'] ) ? intval( $options['image_max_height'] ) : 1920;

        if ( $max_width < 1 ) {
            $max_width = 1920;
        }
        if ( $max_height < 1 ) {
            $max_height = 1920;
        }

        return max( $max_width, $max_height );
    }

    /**
     * Map ASE conversion settings onto Core's output format filter for wasm-vips.
     *
     * @since 9.2.0
     *
     * @param array  $formats   Mime-type conversion map.
     * @param string $filename  Path to the image being converted, if known.
     * @param string $mime_type Source mime type, if known.
     * @return array
     */
    public function maybe_set_image_editor_output_format( $formats, $filename = '', $mime_type = '' ) {
        if ( ! is_array( $formats ) ) {
            $formats = array();
        }

        if ( ! $this->is_client_side_processing_enabled() ) {
            return $formats;
        }

        if ( ! $this->should_map_client_side_filters() ) {
            return $formats;
        }

        $options = get_option( ASENHA_SLUG_U, array() );
        $disable_image_conversion = false;

        if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
            $disable_image_conversion = isset( $options['disable_image_conversion'] ) ? $options['disable_image_conversion'] : false;
        }

        if ( $disable_image_conversion ) {
            return $formats;
        }

        if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
            $convert_to_webp = isset( $options['convert_to_webp'] ) ? $options['convert_to_webp'] : false;
            if ( $convert_to_webp ) {
                $formats['image/jpeg'] = 'image/webp';
                $formats['image/png']  = 'image/webp';
                return $formats;
            }
        }

        if ( $this->should_convert_png_to_jpeg( (string) $filename, (string) $mime_type ) ) {
            $formats['image/png'] = 'image/jpeg';
        }

        return $formats;
    }

    /**
     * Map ASE quality settings onto Core's editor quality filter for wasm-vips.
     *
     * @since 9.2.0
     *
     * @param int    $quality    Quality on a 1-100 scale.
     * @param string $mime_type  Output mime type.
     * @param array  $size       Size data from Core.
     * @return int
     */
    public function maybe_set_editor_quality( $quality, $mime_type = '', $size = array() ) {
        if ( ! $this->is_client_side_processing_enabled() ) {
            return $quality;
        }

        if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
            if ( ! $this->should_map_client_side_filters() ) {
                return $quality;
            }

            $options = get_option( ASENHA_SLUG_U, array() );

            if ( 'image/webp' === $mime_type ) {
                return isset( $options['convert_to_webp_quality'] ) ? intval( $options['convert_to_webp_quality'] ) : 82;
            }

            return isset( $options['convert_to_jpg_quality'] ) ? intval( $options['convert_to_jpg_quality'] ) : 82;
        }

        return $quality;
    }

    /**
     * Map ASE JPEG quality onto the legacy jpeg_quality filter.
     *
     * @since 9.2.0
     *
     * @param int $quality Quality on a 1-100 scale.
     * @return int
     */
    public function maybe_set_jpeg_quality( $quality ) {
        return $this->maybe_set_editor_quality( $quality, 'image/jpeg' );
    }

    /**
     * Delete the oversized original after client-side finalize.
     *
     * The scaled file stays as the attachment. This removes only the original
     * named in the metadata passed into the filter. That metadata has not been
     * saved yet. A repeated finalize deletes nothing once that original is gone.
     *
     * @since 9.2.0
     * @since 9.3.1 Resolves the original from incoming metadata. Stored metadata
     *              has no original_image on the first finalize, so
     *              wp_get_original_image_path() would return the scaled file.
     *
     * @param array  $metadata      Attachment metadata.
     * @param int    $attachment_id Attachment ID.
     * @param string $context       Filter context: create or update.
     * @return array
     */
    public function maybe_delete_original_image_after_client_side_processing( $metadata, $attachment_id, $context = 'create' ) {
        if ( 'update' !== $context ) {
            return $metadata;
        }

        if ( ! $this->is_client_side_processing_enabled() ) {
            return $metadata;
        }

        if ( ! $this->is_client_side_upload_request() ) {
            return $metadata;
        }

        if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
            if ( ! $this->should_apply_image_upload_control__premium_only() ) {
                return $metadata;
            }
        }

        if ( empty( $metadata['original_image'] ) || ! is_string( $metadata['original_image'] ) ) {
            return $metadata;
        }

        $original_image = $metadata['original_image'];
        if ( false !== strpos( $original_image, '-nr.' ) ) {
            return $metadata;
        }

        $attached_file = get_attached_file( $attachment_id );
        if ( ! is_string( $attached_file ) || '' === $attached_file ) {
            return $metadata;
        }

        if ( false !== strpos( $attached_file, '-nr.' ) ) {
            return $metadata;
        }

        $this->maybe_delete_pre_conversion_original( $attachment_id, $attached_file, $metadata );

        /*
         * Core stores original_image as a basename in the attachment directory.
         * Reject anything else so a finalize payload cannot point cleanup at
         * another path. The active scaled file is never a deletion candidate.
         */
        $original_basename = wp_basename( $original_image );

        if ( ! $this->is_plain_basename( $original_image ) || wp_basename( $attached_file ) === $original_basename ) {
            unset( $metadata['original_image'] );
            return $metadata;
        }

        $directory     = dirname( $attached_file );
        $original_path = path_join( $directory, $original_basename );
        $real_original = realpath( $original_path );
        $real_attached = realpath( $attached_file );

        if ( is_string( $real_original ) && is_string( $real_attached ) ) {
            $real_original = wp_normalize_path( $real_original );
            $real_attached = wp_normalize_path( $real_attached );

            if ( $real_original === $real_attached ) {
                unset( $metadata['original_image'] );
                return $metadata;
            }
        }

        // Already removed, including a retried finalize. Drop the stale key.
        if ( ! is_file( $original_path ) ) {
            unset( $metadata['original_image'] );
            return $metadata;
        }

        // Leave original_image set when the file is real but could not be deleted.
        if ( wp_delete_file_from_directory( $original_path, $directory ) ) {
            unset( $metadata['original_image'] );
        }

        return $metadata;
    }

    /**
     * Delete the pre-conversion original that finalize is about to forget.
     *
     * When the server converts the upload on create (e.g. photo.jpg to
     * photo.webp), stored metadata records original_image = photo.jpg. A scaled
     * sideload then sends original_image = photo.webp, and finalize overwrites
     * the stored value with it. Without this, photo.jpg stays on disk with no
     * metadata pointing at it. It survives attachment deletion, and the next
     * upload with the same name gets a "-1" suffix.
     *
     * Stored metadata is read here because finalize has not saved yet.
     *
     * @since 9.3.1
     *
     * @param int    $attachment_id Attachment ID.
     * @param string $attached_file Absolute path of the active attached file.
     * @param array  $metadata      Incoming attachment metadata.
     */
    private function maybe_delete_pre_conversion_original( $attachment_id, $attached_file, $metadata ) {
        $stored_metadata = wp_get_attachment_metadata( $attachment_id, true );

        if ( ! is_array( $stored_metadata ) || empty( $stored_metadata['original_image'] ) || ! is_string( $stored_metadata['original_image'] ) ) {
            return;
        }

        $stored_original = $stored_metadata['original_image'];

        if ( ! $this->is_plain_basename( $stored_original ) || false !== strpos( $stored_original, '-nr.' ) ) {
            return;
        }

        // Still referenced by the metadata being saved, or the active file itself.
        $referenced = array( wp_basename( $attached_file ) );
        foreach ( array( 'original_image', 'file' ) as $key ) {
            if ( ! empty( $metadata[ $key ] ) && is_string( $metadata[ $key ] ) ) {
                $referenced[] = wp_basename( $metadata[ $key ] );
            }
        }

        if ( in_array( $stored_original, $referenced, true ) ) {
            return;
        }

        $directory     = dirname( $attached_file );
        $original_path = path_join( $directory, $stored_original );

        if ( ! is_file( $original_path ) ) {
            return;
        }

        $real_original = realpath( $original_path );
        $real_attached = realpath( $attached_file );

        if ( ! is_string( $real_original ) || ( is_string( $real_attached ) && wp_normalize_path( $real_original ) === wp_normalize_path( $real_attached ) ) ) {
            return;
        }

        wp_delete_file_from_directory( $original_path, $directory );
    }

    /**
     * Whether a metadata file name is a plain basename.
     *
     * Core stores original_image as a basename in the attachment directory.
     * Anything else (a path, "." or "..") is rejected so cleanup cannot be
     * pointed outside that directory.
     *
     * @since 9.3.1
     *
     * @param string $name File name from attachment metadata.
     * @return bool
     */
    private function is_plain_basename( $name ) {
        return (
            wp_basename( $name ) === $name
            && '.' !== $name
            && '..' !== $name
            && false === strpos( $name, '/' )
            && false === strpos( $name, '\\' )
        );
    }

    /**
     * Whether ASE settings should be mapped onto Core client-side filters.
     *
     * @since 9.2.0
     *
     * @param array|null $options Optional cached plugin options.
     * @return bool
     */
    private function should_map_client_side_filters( $options = null ) {
        if ( bwasenha_fs()->can_use_premium_code__premium_only() ) {
            if ( null === $options ) {
                $options = get_option( ASENHA_SLUG_U, array() );
            }

            $only_media_library_uploads = isset( $options['image_upload_control_only_media_library_uploads'] )
                ? (bool) $options['image_upload_control_only_media_library_uploads']
                : false;

            if ( ! $only_media_library_uploads ) {
                return true;
            }

            // REST index / editor preloads use the post editor referer, not /wp/v2/media.
            return $this->is_allowed_upload_referer__premium_only();
        }

        return true;
    }

    /**
     * Detect a Core client-side media REST request.
     *
     * @since 9.2.0
     *
     * @return bool
     */
    private function is_client_side_upload_request() {
        if ( ! defined( 'REST_REQUEST' ) || ! REST_REQUEST ) {
            return false;
        }

        $generate_sub_sizes = null;
        if ( isset( $_POST['generate_sub_sizes'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
            $generate_sub_sizes = wp_unslash( $_POST['generate_sub_sizes'] ); // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
        } elseif ( isset( $_REQUEST['generate_sub_sizes'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            $generate_sub_sizes = wp_unslash( $_REQUEST['generate_sub_sizes'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
        }

        if ( null !== $generate_sub_sizes && false === rest_sanitize_boolean( $generate_sub_sizes ) ) {
            return true;
        }

        $route = '';
        if ( isset( $_GET['rest_route'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            $route = (string) wp_unslash( $_GET['rest_route'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
        } elseif ( isset( $_SERVER['REQUEST_URI'] ) ) {
            $route = (string) wp_unslash( $_SERVER['REQUEST_URI'] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
        }

        if ( '' !== $route && preg_match( '#/media/\d+/(sideload|finalize)(?:/|\?|$)#', $route ) ) {
            return true;
        }

        return false;
    }
}