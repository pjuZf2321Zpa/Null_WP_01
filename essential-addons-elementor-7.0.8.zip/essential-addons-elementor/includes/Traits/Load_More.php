<?php
namespace Essential_Addons_Elementor\Pro\Traits;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly

use Essential_Addons_Elementor\Classes\Helper as HelperClass;

/**
 * Load More support for Pro widgets.
 *
 * Essential Addons (Lite) owns the shared `load_more` AJAX endpoint. The
 * widget-specific preparation for Pro widgets — Post Block and Dynamic Gallery —
 * lives here and is attached through Lite's `eael/load_more/prepare_query` and
 * `eael/load_more/before_items_html` filters. Registering
 * `eael/load_more/pro_prepares_own_widgets` tells Lite to skip its legacy copy.
 */
trait Load_More {

	/**
	 * Prepare load-more settings and query args for Pro widgets.
	 *
	 * @param array  $prepared { settings: array, args: array }.
	 * @param string $class    Widget class named by the load-more request.
	 * @return array
	 */
	public function eael_pro_load_more_prepare_query( $prepared, $class ) {
		if ( ! is_array( $prepared ) || ! isset( $prepared['settings'], $prepared['args'] ) ) {
			return $prepared;
		}

		if ( ! in_array( $class, [ '\Essential_Addons_Elementor\Pro\Elements\Post_Block', '\Essential_Addons_Elementor\Pro\Elements\Dynamic_Filterable_Gallery' ], true ) ) {
			return $prepared;
		}

		$settings = $prepared['settings'];
		$args     = $prepared['args'];

		// ensure control name compatibility to old code if it is post block
		if ( $class === '\Essential_Addons_Elementor\Pro\Elements\Post_Block' ) {
			$settings ['post_block_hover_animation']    = $settings['eael_post_block_hover_animation'];
			$settings ['show_read_more_button']         = $settings['eael_show_read_more_button'];
			$settings ['eael_post_block_bg_hover_icon'] = ( isset( $settings['__fa4_migrated']['eael_post_block_bg_hover_icon_new'] ) || empty( $settings['eael_post_block_bg_hover_icon'] ) ) ? $settings['eael_post_block_bg_hover_icon_new']['value'] : $settings['eael_post_block_bg_hover_icon'];
			$settings ['expanison_indicator']           = $settings['excerpt_expanison_indicator'];
		}
		if ( $class === '\Essential_Addons_Elementor\Pro\Elements\Dynamic_Filterable_Gallery' ) {
			$settings['eael_section_fg_zoom_icon'] = ( isset( $settings['__fa4_migrated']['eael_section_fg_zoom_icon_new'] ) || empty( $settings['eael_section_fg_zoom_icon'] ) ? $settings['eael_section_fg_zoom_icon_new']['value'] : $settings['eael_section_fg_zoom_icon'] );
			$settings['eael_section_fg_link_icon'] = ( isset( $settings['__fa4_migrated']['eael_section_fg_link_icon_new'] ) || empty( $settings['eael_section_fg_link_icon'] ) ? $settings['eael_section_fg_link_icon_new']['value'] : $settings['eael_section_fg_link_icon'] );
			$settings['show_load_more_text']       = $settings['eael_fg_loadmore_btn_text'];
			$settings['layout_mode']               = isset( $settings['layout_mode'] ) ? $settings['layout_mode'] : 'masonry';

			// NOTE: Use server-trusted whitelists; ACF gallery needs broader post_status/type for attachments (inherit), but never 'any'—it would expose private/draft posts to unauthenticated users.
			//NOTE: The inherit status is intentionally allowed to ensure access to attachments, since the same attachment may be associated with both private and public pages.
			$dfg_safe_post_status = [ 'publish', 'inherit' ];
			$dfg_safe_post_types = [ 'attachment' ];
			if ( ! empty( $settings['post_type'] ) && is_string( $settings['post_type'] ) ) {
				if ( 'by_id' === $settings['post_type'] ) {
					// NOTE: Manual selection allows all public post types (to include ACF gallery parents) but excludes internal types (e.g., revision, oembed_cache, nav_menu_item) that 'any' would expose.
					$dfg_safe_post_types = array_values( array_unique( array_merge(
						$dfg_safe_post_types,
						(array) get_post_types( [ 'public' => true ] )
					) ) );
				} else {
					$dfg_safe_post_types[] = sanitize_key( $settings['post_type'] );
				}
			}

			if ( ! empty( $args['fetch_acf_image'] ) && 'yes' === $args['fetch_acf_image'] && ! empty( $args['post__in'] ) ) {
				// SECURITY: previously set to 'any'/'any' which let unauthenticated
				// callers read drafts/private posts by passing arbitrary post__in IDs.
				$args['post_status'] = $dfg_safe_post_status;
				$args['post_type']   = $dfg_safe_post_types;
			}

			// phpcs:disable WordPress.Security.NonceVerification.Missing -- Only reached from Essential Addons' ajax_load_more(), after its nonce check.
			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.MissingUnslash, WordPress.Security.ValidatedSanitizedInput.InputNotValidated
			$exclude_ids = json_decode( html_entity_decode( stripslashes ( $_POST['exclude_ids'] ) ) );
			$args['post__not_in'] = ( !empty( $_POST['exclude_ids'] ) ) ? array_map( 'intval', array_unique( (array) $exclude_ids ) ) : array();
			$active_term_id = ( !empty( $_POST['active_term_id'] ) ) ? intval( $_POST['active_term_id'] ) : 0;
			$active_taxonomy = ( !empty( $_POST['active_taxonomy'] ) ) ? sanitize_text_field( wp_unslash( $_POST['active_taxonomy'] ) ) : '';
			// phpcs:enable WordPress.Security.NonceVerification.Missing

			// Check if this is a hybrid/combined query with ACF gallery
			// Also check settings for hybrid query flag as backup (in case args encoding failed)
			$is_hybrid_query = ( ! empty( $args['eael_dfg_enable_combined_query'] ) && 'yes' === $args['eael_dfg_enable_combined_query'] )
				|| ( ! empty( $settings['eael_dfg_enable_combined_query'] ) && 'yes' === $settings['eael_dfg_enable_combined_query'] && 'yes' === $settings['fetch_acf_image_gallery'] );

			if ( $is_hybrid_query && class_exists( 'ACF' ) && ! empty( $settings['eael_acf_gallery_keys'] ) ) {
				// Build taxonomy map for ACF gallery attachments
				$taxonomy_map = $this->eael_pro_dfg_acf_taxonomy_map( $args, $settings, $active_term_id, $active_taxonomy );

				// Store globally for templates
				global $eael_dfg_attachment_taxonomy_map;
				$eael_dfg_attachment_taxonomy_map = $taxonomy_map['taxonomy_map'];

				// Update args with the filtered post IDs
				if ( ! empty( $taxonomy_map['post_ids'] ) ) {
					// post_ids here are server-derived (parent post IDs + their ACF
					// attachment IDs from eael_pro_dfg_acf_taxonomy_map), so they are
					// trustworthy. Still constrain post_type/post_status to the
					// whitelist so a stale entry can't leak non-public content.
					$args['post__in']    = $taxonomy_map['post_ids'];
					$args['post_type']   = $dfg_safe_post_types;
					$args['post_status'] = $dfg_safe_post_status;
					$args['tax_query']   = [];
					$args['orderby']     = 'post__in';
				}

				// Apply exclusions
				if ( ! empty( $args['post__not_in'] ) && ! empty( $args['post__in'] ) ) {
					$args['post__in'] = array_values( array_diff( $args['post__in'], array_unique( $args['post__not_in'] ) ) );
				}
			} else {
				// Standard ACF gallery handling (non-hybrid)
				if ( ! empty( $args['fetch_acf_image'] ) && 'yes' === $args['fetch_acf_image'] && ! empty( $args['post__in'] ) ) {
					// SECURITY: same rationale as above — never use 'any'.
					$args['post_status'] = $dfg_safe_post_status;
					$args['post_type']   = $dfg_safe_post_types;
				}

				if ( ! empty( $args['post__not_in'] ) && ! empty( $args['post__in'] ) ) {
					$args['post__in'] = array_diff( $args['post__in'], array_unique( $args['post__not_in'] ) );
				}

				if( 0 < $active_term_id &&
					!empty( $active_taxonomy ) &&
					!empty($args['tax_query'])
				) {
					foreach ($args['tax_query'] as $key => $taxonomy) {
						if (isset($taxonomy['taxonomy']) && $taxonomy['taxonomy'] === $active_taxonomy) {
							$args['tax_query'][$key]['terms'] = [$active_term_id];
						}
					}
				}
			}
		}

		$prepared['settings'] = $settings;
		$prepared['args']     = $args;

		return $prepared;
	}

	/**
	 * Hidden found-posts marker Dynamic Gallery's load-more script reads.
	 *
	 * @param string $html        Markup placed before the loaded items.
	 * @param string $class       Widget class named by the load-more request.
	 * @param int    $found_posts Total matching posts.
	 * @param array  $settings    Widget settings.
	 * @return string
	 */
	public function eael_pro_load_more_before_items_html( $html, $class, $found_posts, $settings ) {
		if ( '\Essential_Addons_Elementor\Pro\Elements\Dynamic_Filterable_Gallery' === $class ) {
			$html .= "<div class='found_posts' style='display: none;'>{$found_posts}</div>";
		}

		return $html;
	}

	/**
	 * Build taxonomy map for Dynamic Filterable Gallery ACF attachments
	 * Maps attachment IDs to their parent post's taxonomy classes for filtering
	 *
	 * @param array $args Query args
	 * @param array $settings Widget settings
	 * @param int $active_term_id Active filter term ID
	 * @param string $active_taxonomy Active filter taxonomy
	 * @return array Array with 'post_ids' and 'taxonomy_map'
	 */
	protected function eael_pro_dfg_acf_taxonomy_map( $args, $settings, $active_term_id = 0, $active_taxonomy = '' ) {
		$_args = $args;
		$_args['posts_per_page'] = -1;
		$_args['fields'] = 'ids';

		// Restore original post_type from settings (args may have 'any' from hybrid query encoding)
		if ( ! empty( $settings['post_type'] ) && $settings['post_type'] !== 'by_id' ) {
			$_args['post_type'] = $settings['post_type'];
			$_args['post_status'] = 'publish';
		}

		// Remove post__in constraint to get all matching parent posts
		unset( $_args['post__in'] );

		// If filtering by a specific term, apply the filter to parent posts
		if ( $active_term_id > 0 && ! empty( $active_taxonomy ) ) {
			$_args['tax_query'] = [
				[
					'taxonomy' => $active_taxonomy,
					'field' => 'term_id',
					'terms' => [ $active_term_id ],
				]
			];
		}

		$query = new \WP_Query( $_args );

		$post_ids = [];
		$taxonomy_map = [];

		if ( $query->have_posts() ) {
			while ( $query->have_posts() ) {
				$query->the_post();
				$parent_post_id = get_the_ID();

				// Get parent post's taxonomy classes
				$parent_taxonomy_classes = $this->eael_pro_dfg_post_taxonomy_classes( $parent_post_id, $settings );

				// Include parent posts unless hidden
				if ( ! isset( $settings['eael_gf_hide_parent_items'] ) || 'yes' !== $settings['eael_gf_hide_parent_items'] ) {
					$post_ids[] = $parent_post_id;
				}

				// Get ACF gallery items
				$acf_gallery = [];
				if ( ! empty( $settings['eael_acf_gallery_keys'] ) ) {
					foreach ( $settings['eael_acf_gallery_keys'] as $key ) {
						$_acf_gallery = get_field( $key, $parent_post_id );
						if ( ! empty( $_acf_gallery ) ) {
							$acf_gallery = array_merge( $_acf_gallery, $acf_gallery );
						}
					}
				}

				if ( ! empty( $acf_gallery ) ) {
					foreach ( $acf_gallery as $item ) {
						$attachment_id = false;

						if ( empty( $item['ID'] ) ) {
							if ( 'integer' === gettype( $item ) ) {
								$attachment_id = $item;
							} else if ( 'string' === gettype( $item ) ) {
								$attachment_id = HelperClass::eael_get_attachment_id_from_url( $item );
							}

							if ( ! $attachment_id ) {
								continue;
							}

							$attachment = get_post( $attachment_id );
							if ( ! is_object( $attachment ) || ! isset( $attachment->ID ) ) {
								continue;
							}
						} else {
							$attachment_id = $item['ID'];
						}

						$post_ids[] = $attachment_id;

						// Map this attachment to its parent's taxonomy classes
						if ( ! isset( $taxonomy_map[ $attachment_id ] ) ) {
							$taxonomy_map[ $attachment_id ] = $parent_taxonomy_classes;
						} else {
							$taxonomy_map[ $attachment_id ] = array_unique(
								array_merge( $taxonomy_map[ $attachment_id ], $parent_taxonomy_classes )
							);
						}
					}
				}
			}
		}
		wp_reset_postdata();

		return [
			'post_ids' => array_unique( $post_ids ),
			'taxonomy_map' => $taxonomy_map
		];
	}

	/**
	 * Get taxonomy classes for a post (for DFG ACF gallery parent posts)
	 *
	 * @param int $post_id Post ID
	 * @param array $settings Widget settings
	 * @return array Array of taxonomy slug classes
	 */
	protected function eael_pro_dfg_post_taxonomy_classes( $post_id, $settings ) {
		$classes = [];
		$post_type = get_post_type( $post_id );

		// Get all taxonomies for this post type
		$get_object_taxonomies = get_object_taxonomies( $post_type );
		$taxonomies = wp_get_object_terms( $post_id, $get_object_taxonomies, array( "fields" => "slugs" ) );

		if ( $taxonomies && ! is_wp_error( $taxonomies ) ) {
			foreach ( $taxonomies as $taxonomy ) {
				$classes[] = $taxonomy;
			}
		}

		// Handle category child items
		$show_category_child_items = ! empty( $settings['category_show_child_items'] ) && 'yes' === $settings['category_show_child_items'] ? 1 : 0;
		$show_product_cat_child_items = ! empty( $settings['product_cat_show_child_items'] ) && 'yes' === $settings['product_cat_show_child_items'] ? 1 : 0;

		$category_or_product_cat = '';
		if ( 1 === $show_category_child_items && ! empty( $get_object_taxonomies ) && in_array( 'category', $get_object_taxonomies ) ) {
			$category_or_product_cat = 'category';
		}

		if ( 1 === $show_product_cat_child_items && ! empty( $get_object_taxonomies ) && in_array( 'product_cat', $get_object_taxonomies ) ) {
			$category_or_product_cat = 'product_cat';
		}

		if ( $category_or_product_cat ) {
			$terms = get_the_terms( $post_id, $category_or_product_cat );
			if ( $terms && ! is_wp_error( $terms ) ) {
				foreach ( $terms as $term ) {
					$parent_list = get_term_parents_list( $term->term_id, $category_or_product_cat, array( "format" => "slug", 'separator' => '/', "link" => 0, "inclusive" => 0 ) );
					$parent_list = explode( '/', $parent_list );
					$classes = array_merge( $classes, array_filter( $parent_list ) );
				}
			}
		}

		// Get categories
		$categories = get_the_category( $post_id );
		if ( $categories ) {
			foreach ( $categories as $category ) {
				$classes[] = $category->slug;
			}
		}

		// Get tags
		$tags = wp_get_post_tags( $post_id );
		if ( $tags ) {
			foreach ( $tags as $tag ) {
				$classes[] = $tag->slug;
			}
		}

		// Get product categories
		$product_cats = get_the_terms( $post_id, 'product_cat' );
		if ( $product_cats && ! is_wp_error( $product_cats ) ) {
			foreach ( $product_cats as $cat ) {
				if ( is_object( $cat ) ) {
					$classes[] = $cat->slug;
				}
			}
		}

		// Add post name/slug
		$classes[] = get_post_field( 'post_name', $post_id );

		return array_unique( array_filter( $classes ) );
	}
}
