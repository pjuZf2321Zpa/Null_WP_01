<?php
namespace Essential_Addons_Elementor\Pro\Classes\FigWP;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * What FigWP needs to know about this site before it builds a page: which
 * builder plugins are active, the breakpoints and container width the design
 * must match, and the kit's global colors and fonts.
 */
class Site_Profile {

	/**
	 * Everything figwp.app shows as the site profile.
	 *
	 * @return array<string,mixed>
	 */
	public static function build() {
		global $wp_version;

		$plugins  = self::plugins();
		$problems = self::problems( $plugins );

		$profile = array(
			'site'       => array(
				'name'       => wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ),
				'url'        => home_url( '/' ),
				'wpVersion'  => $wp_version,
				'phpVersion' => PHP_VERSION,
				'locale'     => get_locale(),
			),
			'plugins'    => $plugins,
			'ready'      => empty( $problems ),
			'problems'   => $problems,
			'warnings'   => self::warnings(),
			'connection' => array(
				'pluginVersion' => EAEL_PRO_PLUGIN_VERSION,
				'wpUser'        => self::connected_user_login(),
			),
		);

		if ( $plugins['elementor']['active'] ) {
			$profile['elementor'] = self::elementor();
		}

		return $profile;
	}

	/**
	 * Why the site can't receive pages yet, in words an admin can act on.
	 *
	 * @return string[]
	 */
	public static function problems( $plugins = null ) {
		$plugins  = $plugins ? $plugins : self::plugins();
		$problems = array();
		if ( ! $plugins['elementor']['active'] ) {
			$problems[] = 'Elementor is not active. Install and activate Elementor.';
		}
		if ( $plugins['elementor']['active'] && ! self::containers_active() ) {
			$problems[] = 'Elementor\'s Flexbox Container feature is off. Turn it on in Elementor > Settings > Features.';
		}
		return $problems;
	}

	/**
	 * What doesn't stop FigWP building pages but will spoil some of them.
	 *
	 * Every page FigWP saves runs as the connected user. Elementor passes the
	 * page through kses when that user can't post unfiltered HTML (an Editor,
	 * anyone but a Super Admin on multisite, or DISALLOW_UNFILTERED_HTML), so
	 * inline SVG and HTML widgets are stripped and a ">" in custom CSS is
	 * stored as "&gt;" and the rule is dropped. Nothing fails; parts of the
	 * page just go missing.
	 *
	 * @return string[]
	 */
	public static function warnings() {
		$connection = Connection::get();
		$user       = $connection ? get_userdata( (int) $connection['wp_user_id'] ) : false;
		if ( ! $user || user_can( $user, 'unfiltered_html' ) ) {
			return array();
		}
		$what = 'Elementor filters every page FigWP saves on this site: inline SVG and HTML widgets are stripped, and custom CSS that uses ">" stops working.';
		if ( defined( 'DISALLOW_UNFILTERED_HTML' ) && DISALLOW_UNFILTERED_HTML ) {
			return array( $what . ' DISALLOW_UNFILTERED_HTML is set in wp-config.php, so no user can post unfiltered HTML; remove it to keep that content.' );
		}
		$who = is_multisite() ? 'a Super Admin' : 'an administrator';
		return array( sprintf( '%s The connected WordPress user (%s) isn\'t allowed to post unfiltered HTML. Reconnect the site from %s account to keep that content.', $what, $user->user_login, $who ) );
	}

	public static function is_ready() {
		return empty( self::problems() );
	}

	/**
	 * @return array<string,array{active:bool,version:?string}>
	 */
	private static function plugins() {
		return array(
			'elementor'          => self::plugin( defined( 'ELEMENTOR_VERSION' ), 'ELEMENTOR_VERSION' ),
			'elementorPro'       => self::plugin( defined( 'ELEMENTOR_PRO_VERSION' ), 'ELEMENTOR_PRO_VERSION' ),
			'essentialAddons'    => self::plugin( defined( 'EAEL_PLUGIN_VERSION' ), 'EAEL_PLUGIN_VERSION' ),
			'essentialAddonsPro' => self::plugin( defined( 'EAEL_PRO_PLUGIN_VERSION' ), 'EAEL_PRO_PLUGIN_VERSION' ),
		);
	}

	private static function plugin( $active, $version_constant ) {
		return array(
			'active'  => (bool) $active,
			'version' => $active ? (string) constant( $version_constant ) : null,
		);
	}

	private static function containers_active() {
		return class_exists( '\Elementor\Plugin' )
			&& \Elementor\Plugin::$instance->experiments->is_feature_active( 'container' );
	}

	private static function connected_user_login() {
		$connection = Connection::get();
		if ( ! $connection ) {
			return null;
		}
		$user = get_userdata( (int) $connection['wp_user_id'] );
		return $user ? $user->user_login : null;
	}

	/**
	 * Breakpoints, container width and kit globals.
	 *
	 * @return array<string,mixed>
	 */
	private static function elementor() {
		$elementor = \Elementor\Plugin::$instance;

		$breakpoints = array();
		foreach ( $elementor->breakpoints->get_breakpoints_config() as $name => $config ) {
			if ( ! empty( $config['is_enabled'] ) ) {
				$breakpoints[ $name ] = array(
					'label'     => $config['label'],
					'value'     => (int) $config['value'],
					'direction' => $config['direction'],
				);
			}
		}

		$kit             = $elementor->kits_manager->get_active_kit_for_frontend();
		$container_width = $kit ? $kit->get_settings( 'container_width' ) : null;

		return array(
			'containersActive' => self::containers_active(),
			'breakpoints'      => $breakpoints,
			'containerWidth'   => is_array( $container_width ) && isset( $container_width['size'] ) ? (int) $container_width['size'] : 1140,
			'kitId'            => $kit ? $kit->get_main_id() : null,
			'globals'          => $kit ? self::globals( $kit ) : array(
				'colors'     => array(),
				'typography' => array(),
			),
		);
	}

	private static function globals( $kit ) {
		$colors = array();
		foreach ( array( 'system_colors', 'custom_colors' ) as $group ) {
			foreach ( (array) $kit->get_settings( $group ) as $item ) {
				if ( empty( $item['_id'] ) ) {
					continue;
				}
				$colors[] = array(
					'id'     => $item['_id'],
					'title'  => isset( $item['title'] ) ? $item['title'] : '',
					'color'  => isset( $item['color'] ) ? $item['color'] : '',
					'system' => 'system_colors' === $group,
				);
			}
		}

		$typography = array();
		foreach ( array( 'system_typography', 'custom_typography' ) as $group ) {
			foreach ( (array) $kit->get_settings( $group ) as $item ) {
				if ( empty( $item['_id'] ) ) {
					continue;
				}
				$typography[] = array(
					'id'         => $item['_id'],
					'title'      => isset( $item['title'] ) ? $item['title'] : '',
					'fontFamily' => isset( $item['typography_font_family'] ) ? $item['typography_font_family'] : null,
					'fontWeight' => isset( $item['typography_font_weight'] ) ? $item['typography_font_weight'] : null,
					'fontSize'   => isset( $item['typography_font_size']['size'] ) ? $item['typography_font_size'] : null,
					'system'     => 'system_typography' === $group,
				);
			}
		}

		return array(
			'colors'     => $colors,
			'typography' => $typography,
		);
	}

	/**
	 * How Elementor would load each font family: from Google Fonts, the
	 * system, or a font uploaded to the site (Custom Fonts). Null means it
	 * has no way to, and the page would fall back to another face.
	 *
	 * @param string[] $families
	 */
	public static function fonts( array $families ) {
		$out = array();
		foreach ( array_slice( $families, 0, 100 ) as $family ) {
			$family = sanitize_text_field( (string) $family );
			if ( '' === $family ) {
				continue;
			}
			$type           = \Elementor\Fonts::get_font_type( $family );
			$out[ $family ] = $type ? (string) $type : null;
		}
		return array(
			'fonts'              => (object) $out,
			// Elementor's "Load Google Fonts" setting; off means Google fonts don't load.
			'googleFontsEnabled' => '0' !== (string) get_option( 'elementor_google_font', '1' ),
		);
	}
}
