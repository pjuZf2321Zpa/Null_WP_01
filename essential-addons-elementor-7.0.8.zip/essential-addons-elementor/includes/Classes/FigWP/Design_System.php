<?php
namespace Essential_Addons_Elementor\Pro\Classes\FigWP;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * The site's Elementor kit as FigWP's design system target: the colours and
 * fonts a Figma file defines become kit globals, matched by name.
 *
 * A token whose name matches a kit colour or font (system or custom, case
 * aside) updates it; any other is added as a custom one. Nothing is
 * removed. A dry run reports what would change without saving.
 */
class Design_System {

	const MAX_TOKENS = 200;

	/**
	 * @param array $colors     Each { title, color } (#rrggbb or #rrggbbaa).
	 * @param array $typography Each { title, settings } with typography_* controls.
	 * @return array|\WP_Error
	 */
	public static function sync( array $colors, array $typography, $dry_run ) {
		$kit = \Elementor\Plugin::$instance->kits_manager->get_active_kit();
		if ( ! $kit || ! $kit->get_main_id() ) {
			return new \WP_Error( 'figwp_no_kit', 'This site has no active Elementor kit.', array( 'status' => 409 ) );
		}
		if ( ! current_user_can( 'edit_post', $kit->get_main_id() ) ) {
			return new \WP_Error( 'figwp_forbidden', 'The connected WordPress user cannot edit the site\'s global styles.', array( 'status' => 403 ) );
		}
		if ( count( $colors ) > self::MAX_TOKENS || count( $typography ) > self::MAX_TOKENS ) {
			return new \WP_Error( 'figwp_too_many', sprintf( 'Send at most %d colours and %d fonts.', self::MAX_TOKENS, self::MAX_TOKENS ), array( 'status' => 400 ) );
		}

		$settings = $kit->get_settings();
		$groups   = array();
		foreach ( array( 'system_colors', 'custom_colors', 'system_typography', 'custom_typography' ) as $key ) {
			$groups[ $key ] = isset( $settings[ $key ] ) && is_array( $settings[ $key ] ) ? $settings[ $key ] : array();
		}

		$color_report = array();
		foreach ( $colors as $token ) {
			$title = isset( $token['title'] ) ? sanitize_text_field( (string) $token['title'] ) : '';
			$color = isset( $token['color'] ) ? strtolower( (string) $token['color'] ) : '';
			if ( '' === $title || ! preg_match( '/^#([0-9a-f]{6}|[0-9a-f]{8})$/', $color ) ) {
				continue;
			}
			$color_report[] = self::upsert( $groups, 'system_colors', 'custom_colors', $title, array( 'color' => strtoupper( $color ) ), 'color' );
		}

		$type_report = array();
		foreach ( $typography as $token ) {
			$title = isset( $token['title'] ) ? sanitize_text_field( (string) $token['title'] ) : '';
			$value = isset( $token['settings'] ) && is_array( $token['settings'] ) ? self::typography_settings( $token['settings'] ) : array();
			if ( '' === $title || ! $value ) {
				continue;
			}
			$type_report[] = self::upsert( $groups, 'system_typography', 'custom_typography', $title, $value, 'typography' );
		}

		$changed = false;
		foreach ( array_merge( $color_report, $type_report ) as $row ) {
			$changed = $changed || 'unchanged' !== $row['action'];
		}
		if ( ! $dry_run && $changed ) {
			$kit->update_settings( $groups );
			\Elementor\Plugin::$instance->files_manager->clear_cache();
		}

		return array(
			'dryRun'     => (bool) $dry_run,
			'kitId'      => $kit->get_main_id(),
			'colors'     => $color_report,
			'typography' => $type_report,
		);
	}

	/** Update the item with this title in either group, or add a custom one. */
	private static function upsert( array &$groups, $system, $custom, $title, array $value, $kind ) {
		foreach ( array( $system, $custom ) as $group ) {
			foreach ( $groups[ $group ] as $i => $item ) {
				if ( isset( $item['title'] ) && 0 === strcasecmp( (string) $item['title'], $title ) ) {
					$before = array_intersect_key( $item, $value );
					$same   = 'color' === $kind
						? isset( $item['color'] ) && 0 === strcasecmp( (string) $item['color'], $value['color'] )
						: wp_json_encode( self::comparable( $before ) ) === wp_json_encode( self::comparable( $value ) );
					if ( ! $same ) {
						$groups[ $group ][ $i ] = array_merge( $item, $value );
					}
					return array(
						'title'    => $title,
						'id'       => $item['_id'],
						'system'   => $group === $system,
						'action'   => $same ? 'unchanged' : 'updated',
						'previous' => $same ? null : ( 'color' === $kind ? ( isset( $item['color'] ) ? $item['color'] : null ) : (object) $before ),
					);
				}
			}
		}
		$id                  = substr( md5( $kind . ':' . strtolower( $title ) ), 0, 7 );
		$groups[ $custom ][] = array_merge(
			array(
				'_id'   => $id,
				'title' => $title,
			),
			$value
		);
		return array(
			'title'    => $title,
			'id'       => $id,
			'system'   => false,
			'action'   => 'created',
			'previous' => null,
		);
	}

	/** Only typography_* controls, as Elementor stores them. */
	private static function typography_settings( array $settings ) {
		$out = array();
		foreach ( $settings as $key => $value ) {
			if ( 0 === strpos( (string) $key, 'typography_' ) && ( is_scalar( $value ) || is_array( $value ) ) ) {
				$out[ (string) $key ] = $value;
			}
		}
		if ( $out ) {
			$out['typography_typography'] = 'custom';
		}
		return $out;
	}

	/** Values as strings, so "600" and 600 compare equal. */
	private static function comparable( array $value ) {
		ksort( $value );
		array_walk_recursive(
			$value,
			function ( &$v ) {
				$v = (string) $v;
			}
		);
		return $value;
	}
}
