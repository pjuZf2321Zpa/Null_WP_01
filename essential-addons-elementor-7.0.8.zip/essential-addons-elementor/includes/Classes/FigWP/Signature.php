<?php
namespace Essential_Addons_Elementor\Pro\Classes\FigWP;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * HMAC request signing shared with figwp.app.
 *
 * Every request between FigWP and this site is signed with the secret both
 * sides received when the site was connected. The signed string covers the
 * method, the route, a timestamp, a single-use nonce and a hash of the body,
 * so a captured request can't be replayed, retargeted or altered.
 *
 * Must stay identical to src/api/src/sites/site-signature.ts in figwp-app.
 */
class Signature {

	const SCHEME = 'FIGWP-HMAC-SHA256';

	/** Requests older or newer than this many seconds are refused. */
	const MAX_SKEW = 300;

	/** How long a nonce is remembered; longer than the allowed skew. */
	const NONCE_TTL = 900;

	/**
	 * The string both sides sign.
	 *
	 * @param string $method    HTTP method.
	 * @param string $route     Path, e.g. /figwp/v1/status (no query string).
	 * @param string $timestamp Unix seconds.
	 * @param string $nonce     Random, single use.
	 * @param string $body      Raw request body.
	 */
	public static function canonical( $method, $route, $timestamp, $nonce, $body ) {
		return implode(
			"\n",
			array(
				self::SCHEME,
				strtoupper( $method ),
				$route,
				$timestamp,
				$nonce,
				hash( 'sha256', (string) $body ),
			)
		);
	}

	public static function sign( $secret, $method, $route, $timestamp, $nonce, $body ) {
		return hash_hmac( 'sha256', self::canonical( $method, $route, $timestamp, $nonce, $body ), $secret );
	}

	/**
	 * Headers for a request this site sends to figwp.app.
	 *
	 * @return array<string,string>
	 */
	public static function headers_for( $site_id, $secret, $method, $route, $body ) {
		$timestamp = (string) time();
		$nonce     = bin2hex( random_bytes( 16 ) );
		return array(
			'X-FigWP-Site-Id'   => $site_id,
			'X-FigWP-Timestamp' => $timestamp,
			'X-FigWP-Nonce'     => $nonce,
			'X-FigWP-Signature' => self::sign( $secret, $method, $route, $timestamp, $nonce, $body ),
		);
	}

	/**
	 * Check a signed request from figwp.app.
	 *
	 * @param \WP_REST_Request $request The incoming request.
	 * @param string          $site_id This site's FigWP id.
	 * @param string          $secret  The shared secret.
	 * @return true|\WP_Error
	 */
	public static function verify( \WP_REST_Request $request, $site_id, $secret ) {
		$given_site = (string) $request->get_header( 'x_figwp_site_id' );
		$timestamp  = (string) $request->get_header( 'x_figwp_timestamp' );
		$nonce      = (string) $request->get_header( 'x_figwp_nonce' );
		$signature  = (string) $request->get_header( 'x_figwp_signature' );

		if ( '' === $given_site || '' === $timestamp || '' === $nonce || '' === $signature ) {
			return self::error( 'figwp_unsigned', 'This request is not signed by FigWP.' );
		}
		if ( ! hash_equals( (string) $site_id, $given_site ) ) {
			return self::error( 'figwp_wrong_site', 'This request was signed for a different site.' );
		}
		if ( ! ctype_digit( $timestamp ) || abs( time() - (int) $timestamp ) > self::MAX_SKEW ) {
			return self::error( 'figwp_stale', 'The request timestamp is too old or in the future. Check the server clock.' );
		}
		if ( ! preg_match( '/^[a-f0-9]{32}$/', $nonce ) ) {
			return self::error( 'figwp_bad_nonce', 'The request nonce is malformed.' );
		}

		$expected = self::sign( $secret, $request->get_method(), $request->get_route(), $timestamp, $nonce, $request->get_body() );
		if ( ! hash_equals( $expected, $signature ) ) {
			return self::error( 'figwp_bad_signature', 'The request signature does not match.' );
		}

		// Checked last, so an unsigned flood can't fill the nonce store.
		$key = 'figwp_nonce_' . $nonce;
		if ( false !== get_transient( $key ) ) {
			return self::error( 'figwp_replayed', 'This request was already handled.' );
		}
		set_transient( $key, 1, self::NONCE_TTL );

		return true;
	}

	private static function error( $code, $message ) {
		return new \WP_Error( $code, $message, array( 'status' => 401 ) );
	}
}
