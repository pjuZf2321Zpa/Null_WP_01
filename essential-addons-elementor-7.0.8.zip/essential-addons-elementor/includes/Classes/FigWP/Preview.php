<?php
namespace Essential_Addons_Elementor\Pro\Classes\FigWP;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Short-lived preview links, so FigWP can render a draft it imported.
 *
 * Drafts are not public. figwp.app asks for a link over a signed request; the
 * link carries a random token, good for ten minutes, that lets that one page
 * render as the WordPress user who connected the site. Only the page itself:
 * the user is switched only when the request is for that page, any other URL
 * with the token is refused, the REST API and wp-admin ignore it, and no
 * cookie is set.
 */
class Preview {

	const PARAM          = 'figwp_preview';
	const TTL            = 600;
	const TRANSIENT_PREF = 'figwp_preview_';

	/** The post this request is previewing, once a token was accepted. */
	private static $post_id = 0;

	/** A valid token was attached to a URL other than its page. */
	private static $wrong_page = false;

	public static function init() {
		add_action( 'parse_request', array( __CLASS__, 'accept_token' ), 1 );
		add_action( 'template_redirect', array( __CLASS__, 'guard' ), 0 );
	}

	/**
	 * A preview link for a page or template this plugin imported.
	 *
	 * @return array|\WP_Error
	 */
	public static function create( $post_id ) {
		$post = get_post( (int) $post_id );
		if ( ! $post || ! get_post_meta( $post->ID, Importer::META, true ) ) {
			return new \WP_Error( 'figwp_not_found', 'No FigWP import with that id.', array( 'status' => 404 ) );
		}
		if ( ! current_user_can( 'edit_post', $post->ID ) ) {
			return new \WP_Error( 'figwp_forbidden', 'The connected WordPress user cannot view this page.', array( 'status' => 403 ) );
		}

		$token = bin2hex( random_bytes( 24 ) );
		set_transient(
			self::TRANSIENT_PREF . hash( 'sha256', $token ),
			array(
				'post_id' => $post->ID,
				'user_id' => get_current_user_id(),
			),
			self::TTL
		);

		$base = 'publish' === $post->post_status ? get_permalink( $post->ID ) : get_preview_post_link( $post->ID );
		return array(
			'postId'    => $post->ID,
			'url'       => add_query_arg( self::PARAM, $token, $base ),
			'expiresAt' => gmdate( 'c', time() + self::TTL ),
		);
	}

	/** parse_request: a valid token on a front-end request renders as its user. */
	public static function accept_token( $wp ) {
		if ( empty( $_GET[ self::PARAM ] ) || is_admin() || ! empty( $wp->query_vars['rest_route'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return;
		}
		$token = sanitize_text_field( wp_unslash( $_GET[ self::PARAM ] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$grant = get_transient( self::TRANSIENT_PREF . hash( 'sha256', $token ) );
		if ( ! is_array( $grant ) || empty( $grant['post_id'] ) ) {
			return;
		}
		$user = get_userdata( (int) $grant['user_id'] );
		if ( ! $user || ! user_can( $user, 'edit_post', (int) $grant['post_id'] ) ) {
			return;
		}
		// Elevate only for the page the token was issued for. This has to be
		// decided here, from the parsed query vars: the main query runs next and
		// needs the user to find a draft, but everything from here to
		// template_redirect (pre_get_posts, wp, send_headers, ...) would otherwise
		// run as that user on whatever URL the token was attached to.
		if ( self::requested_post_id( $wp ) !== (int) $grant['post_id'] ) {
			self::$wrong_page = true;
			return;
		}
		self::$post_id = (int) $grant['post_id'];
		// A site with WP_DEBUG_DISPLAY on prints notices into the page; a
		// render for verification must show the page, not PHP's warnings.
		@ini_set( 'display_errors', '0' ); // phpcs:ignore WordPress.PHP.IniSet.display_errors_Disallowed, WordPress.PHP.NoSilencedErrors.Discouraged
		wp_set_current_user( $user->ID );
		add_filter( 'show_admin_bar', '__return_false' );
	}

	/**
	 * The post a front-end request asks for, from its parsed query vars, before
	 * the main query runs. Covers the links create() hands out: preview links
	 * (?p= / ?page_id=), permalinks by slug, and a static front page. Anything
	 * else resolves to 0 and is never elevated.
	 *
	 * @param \WP $wp Current request.
	 *
	 * @return int
	 */
	private static function requested_post_id( $wp ) {
		$vars = $wp->query_vars;
		$ids  = array();

		foreach ( array( 'p', 'page_id', 'attachment_id' ) as $key ) {
			if ( ! empty( $vars[ $key ] ) ) {
				$ids[] = (int) $vars[ $key ];
			}
		}

		if ( ! empty( $vars['pagename'] ) ) {
			$post  = get_page_by_path( $vars['pagename'], OBJECT, 'page' );
			$ids[] = $post ? (int) $post->ID : 0;
		}

		if ( ! empty( $vars['name'] ) ) {
			$types = ! empty( $vars['post_type'] ) ? (array) $vars['post_type'] : array( 'post' );
			$post  = get_page_by_path( $vars['name'], OBJECT, $types );
			$ids[] = $post ? (int) $post->ID : 0;
		}

		// Every identifier in the URL has to name the same post.
		if ( $ids ) {
			$ids = array_unique( $ids );
			return 1 === count( $ids ) ? (int) reset( $ids ) : 0;
		}

		// The site root shows the static front page, if there is one.
		$identifying = array_diff( array_keys( array_filter( $vars ) ), array( 'preview' ) );
		if ( empty( $identifying ) && '' === trim( (string) $wp->request, '/' ) && 'page' === get_option( 'show_on_front' ) ) {
			return (int) get_option( 'page_on_front' );
		}

		return 0;
	}

	/** template_redirect: the token is for one page only. */
	public static function guard() {
		if ( self::$wrong_page ) {
			wp_die( 'This FigWP preview link is for another page.', 'Forbidden', array( 'response' => 403 ) );
		}
		if ( ! self::$post_id ) {
			return;
		}
		if ( (int) get_queried_object_id() !== self::$post_id ) {
			wp_set_current_user( 0 );
			wp_die( 'This FigWP preview link is for another page.', 'Forbidden', array( 'response' => 403 ) );
		}
		nocache_headers();
		header( 'X-Robots-Tag: noindex, nofollow' );
	}
}
