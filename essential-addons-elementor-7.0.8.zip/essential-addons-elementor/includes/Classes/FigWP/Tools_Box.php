<?php
namespace Essential_Addons_Elementor\Pro\Classes\FigWP;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * FigWP on Essential Addons > Tools: one box that connects the site, shows the
 * connection and what still blocks building pages, and disconnects. Connect
 * and disconnect are admin-post links that come back to the Tools tab with
 * `eael_figwp` set to what happened.
 */
class Tools_Box {

	/** Query parameter the redirects back to the Tools tab carry. */
	const FLAG = 'eael_figwp';

	public static function init() {
		add_filter( 'eael/admin/tools', array( __CLASS__, 'box' ) );
		add_action( 'admin_post_eael_figwp_start', array( __CLASS__, 'start' ) );
		add_action( 'admin_post_eael_figwp_finish', array( __CLASS__, 'finish' ) );
		add_action( 'admin_post_eael_figwp_disconnect', array( __CLASS__, 'disconnect' ) );
	}

	public static function box( $tools ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			return $tools;
		}
		$connection = Connection::get();
		$notices    = array();

		$result = self::result_notice();
		if ( $result ) {
			$notices[] = $result;
		}
		$problems = Site_Profile::problems();
		if ( $problems ) {
			$notices[] = array(
				'type'  => 'warning',
				'text'  => __( 'Before FigWP can build pages here:', 'essential-addons-elementor' ),
				'items' => $problems,
			);
		}
		foreach ( Site_Profile::warnings() as $warning ) {
			$notices[] = array(
				'type' => 'warning',
				'text' => $warning,
			);
		}

		$box = array(
			'heading'  => __( 'FigWP: Figma to Pages with AI', 'essential-addons-elementor' ),
			'content'  => $connection
				? __( 'AI apps like Claude and ChatGPT, connected to your FigWP account, build pages here from your Figma designs with Essential Addons widgets. Pages are always created as drafts.', 'essential-addons-elementor' )
				: __( 'Connect this site to your FigWP account so AI apps like Claude and ChatGPT can build pages here from your Figma designs, using Essential Addons widgets. Pages are always created as drafts.', 'essential-addons-elementor' ),
			'icon'     => 'ea-figma-to-elementor',
			'notices'  => $notices,
			'url_flag' => self::FLAG,
		);

		if ( $connection ) {
			$user           = get_userdata( (int) $connection['wp_user_id'] );
			$box['status']  = array(
				'type' => 'success',
				'text' => __( 'Connected', 'essential-addons-elementor' ),
			);
			$box['rows']    = array(
				array(
					'label' => __( 'FigWP account', 'essential-addons-elementor' ),
					'value' => trim( $connection['account_name'] . ' ' . ( $connection['account_email'] ? '(' . $connection['account_email'] . ')' : '' ) ),
				),
				array(
					'label' => __( 'Pages are created as', 'essential-addons-elementor' ),
					'value' => $user ? $user->display_name . ' (' . $user->user_login . ')' : __( 'Unknown user — reconnect the site', 'essential-addons-elementor' ),
				),
				array(
					'label' => __( 'Connected on', 'essential-addons-elementor' ),
					'value' => wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), (int) $connection['connected_at'] ),
				),
			);
			$box['buttons'] = array(
				array(
					'label'  => __( 'Open FigWP', 'essential-addons-elementor' ),
					'url'    => Connection::app_url( '/sites' ),
					'target' => '_blank',
				),
				array(
					'label' => __( 'Disconnect', 'essential-addons-elementor' ),
					'url'   => self::action_url( 'eael_figwp_disconnect' ),
				),
			);
		} else {
			$box['status']  = array(
				'type' => 'warning',
				'text' => __( 'Not connected', 'essential-addons-elementor' ),
			);
			$box['buttons'] = array(
				array(
					'label'   => __( 'Connect to FigWP', 'essential-addons-elementor' ),
					'url'     => self::action_url( 'eael_figwp_start' ),
					'primary' => true,
				),
			);
		}

		$tools['figwp'] = $box;
		return $tools;
	}

	/** Send the admin to figwp.app to approve this site. */
	public static function start() {
		self::require_admin();
		check_admin_referer( 'eael_figwp_start' );
		// The URL is figwp.app, a different host, so wp_safe_redirect won't do.
		wp_redirect( Connection::pairing_url( wp_get_current_user() ) ); // phpcs:ignore WordPress.Security.SafeRedirect.wp_redirect_wp_redirect
		exit;
	}

	/** figwp.app sends the browser back here with a code. */
	public static function finish() {
		self::require_admin();
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- the state parameter is the CSRF check here.
		$error = isset( $_GET['error'] ) ? sanitize_key( wp_unslash( $_GET['error'] ) ) : '';
		$code  = isset( $_GET['figwp_code'] ) ? sanitize_text_field( wp_unslash( $_GET['figwp_code'] ) ) : '';
		$state = isset( $_GET['state'] ) ? sanitize_text_field( wp_unslash( $_GET['state'] ) ) : '';
		// phpcs:enable

		if ( 'access_denied' === $error ) {
			self::back_to_tools( 'cancelled' );
		}

		$result = Connection::finish_pairing( wp_get_current_user(), $code, $state );
		if ( is_wp_error( $result ) ) {
			set_transient( 'figwp_connect_error_' . get_current_user_id(), $result->get_error_message(), 5 * MINUTE_IN_SECONDS );
			self::back_to_tools( 'failed' );
		}
		self::back_to_tools( 'connected' );
	}

	public static function disconnect() {
		self::require_admin();
		check_admin_referer( 'eael_figwp_disconnect' );
		Connection::disconnect();
		self::back_to_tools( 'disconnected' );
	}

	private static function require_admin() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You need to be an administrator to connect this site to FigWP.', 'essential-addons-elementor' ), 403 );
		}
	}

	/** Not wp_nonce_url(): its &amp; would reach the dashboard's React app as is. */
	private static function action_url( $action ) {
		return add_query_arg(
			array(
				'action'   => $action,
				'_wpnonce' => wp_create_nonce( $action ),
			),
			admin_url( 'admin-post.php' )
		);
	}

	/** Back to Essential Addons > Tools, saying what happened. */
	private static function back_to_tools( $result ) {
		wp_safe_redirect( admin_url( 'admin.php?page=eael-settings&' . self::FLAG . '=' . $result . '#/tools' ) );
		exit;
	}

	/** The notice for the redirect that brought the admin back here, if any. */
	private static function result_notice() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- display only.
		$result = isset( $_GET[ self::FLAG ] ) ? sanitize_key( wp_unslash( $_GET[ self::FLAG ] ) ) : '';
		$map    = array(
			'connected'    => array( 'success', __( 'This site is connected to FigWP.', 'essential-addons-elementor' ) ),
			'disconnected' => array( 'success', __( 'This site is disconnected from FigWP.', 'essential-addons-elementor' ) ),
			'cancelled'    => array( 'warning', __( 'Connection cancelled on FigWP.', 'essential-addons-elementor' ) ),
		);
		if ( 'failed' === $result ) {
			$key     = 'figwp_connect_error_' . get_current_user_id();
			$message = get_transient( $key );
			delete_transient( $key );
			$map['failed'] = array( 'error', $message ? $message : __( 'The connection failed. Try again.', 'essential-addons-elementor' ) );
		}
		if ( ! isset( $map[ $result ] ) ) {
			return null;
		}
		return array(
			'type' => $map[ $result ][0],
			'text' => $map[ $result ][1],
		);
	}
}
