<?php
namespace Essential_Addons_Elementor\Pro\Classes\FigWP;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

use Essential_Addons_Elementor\Pro\Classes\Helper;

/**
 * The forms a FigWP page can show. Essential Addons has a widget for each of
 * these form plugins; the widget renders one of the plugin's forms, picked
 * by id. FigWP never builds a form itself: a design's contact or newsletter
 * form is connected to a form the site owner made in one of these plugins.
 */
class Forms {

	/** Forms listed per plugin; a site rarely has more, and the list is for picking one. */
	const MAX_FORMS = 100;

	/** Field labels listed per form, enough to tell whether it matches the design. */
	const MAX_FIELDS = 30;

	/**
	 * Form plugins Essential Addons has a widget for, in the order FigWP
	 * suggests installing them. `files` are the plugin's main files, free
	 * edition first; `wporg` is false for plugins not on WordPress.org.
	 */
	private static function providers() {
		return array(
			'fluentform'     => array(
				'name'    => 'Fluent Forms',
				'files'   => array( 'fluentform/fluentform.php' ),
				'wporg'   => 'fluentform',
				'newForm' => 'admin.php?page=fluent_forms',
			),
			'contact-form-7' => array(
				'name'    => 'Contact Form 7',
				'files'   => array( 'contact-form-7/wp-contact-form-7.php' ),
				'wporg'   => 'contact-form-7',
				'newForm' => 'admin.php?page=wpcf7-new',
			),
			'wpforms'        => array(
				'name'    => 'WPForms',
				'files'   => array( 'wpforms-lite/wpforms.php', 'wpforms/wpforms.php' ),
				'wporg'   => 'wpforms-lite',
				'newForm' => 'admin.php?page=wpforms-builder',
			),
			'ninja-forms'    => array(
				'name'    => 'Ninja Forms',
				'files'   => array( 'ninja-forms/ninja-forms.php' ),
				'wporg'   => 'ninja-forms',
				'newForm' => 'admin.php?page=ninja-forms&form_id=new',
			),
			'weforms'        => array(
				'name'    => 'weForms',
				'files'   => array( 'weforms/weforms.php' ),
				'wporg'   => 'weforms',
				'newForm' => 'admin.php?page=weforms#/',
			),
			'gravityforms'   => array(
				'name'    => 'Gravity Forms',
				'files'   => array( 'gravityforms/gravityforms.php' ),
				'wporg'   => false,
				'newForm' => 'admin.php?page=gf_new_form',
			),
		);
	}

	/**
	 * Every supported form plugin with its state and forms, and whether the
	 * Essential Addons Mailchimp widget can subscribe people.
	 *
	 * @return array<string,mixed>
	 */
	public static function inventory() {
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		$installed = get_plugins();

		$providers = array();
		foreach ( self::providers() as $key => $provider ) {
			$file = null;
			foreach ( $provider['files'] as $candidate ) {
				if ( isset( $installed[ $candidate ] ) ) {
					$file = $candidate;
					break;
				}
			}
			$active = $file && is_plugin_active( $file );

			$providers[] = array(
				'key'        => $key,
				'name'       => $provider['name'],
				'installed'  => (bool) $file,
				'active'     => (bool) $active,
				'version'    => $file ? $installed[ $file ]['Version'] : null,
				'forms'      => $active ? self::forms( $key ) : array(),
				'newFormUrl' => admin_url( $provider['newForm'] ),
				'installUrl' => $provider['wporg']
					? admin_url( 'plugin-install.php?tab=plugin-information&plugin=' . $provider['wporg'] )
					: null,
			);
		}

		return array(
			'providers'         => $providers,
			'mailchimp'         => self::mailchimp(),
			'canInstallPlugins' => current_user_can( 'install_plugins' ),
			'pluginsUrl'        => admin_url( 'plugins.php' ),
		);
	}

	/**
	 * One plugin's forms as {id, title, fields}. A plugin whose API changed
	 * shows no forms rather than failing the whole inventory.
	 *
	 * @return array<int,array{id:string,title:string,fields:string[]}>
	 */
	private static function forms( $key ) {
		try {
			switch ( $key ) {
				case 'fluentform':
					return self::fluentform_forms();
				case 'contact-form-7':
					return self::post_forms( 'wpcf7_contact_form', array( __CLASS__, 'cf7_fields' ) );
				case 'wpforms':
					return self::post_forms( 'wpforms', array( __CLASS__, 'wpforms_fields' ) );
				case 'ninja-forms':
					return self::ninja_forms();
				case 'weforms':
					return self::post_forms( 'wpuf_contact_form', array( __CLASS__, 'weforms_fields' ) );
				case 'gravityforms':
					return self::gravity_forms();
			}
		} catch ( \Throwable $e ) {
			return array();
		}
		return array();
	}

	private static function form( $id, $title, array $fields ) {
		$fields = array_values( array_unique( array_filter( array_map( 'strval', $fields ) ) ) );
		return array(
			'id'     => (string) $id,
			'title'  => wp_specialchars_decode( (string) $title, ENT_QUOTES ),
			'fields' => array_slice( $fields, 0, self::MAX_FIELDS ),
		);
	}

	/** Forms stored as posts (Contact Form 7, WPForms, weForms). */
	private static function post_forms( $post_type, callable $fields ) {
		$posts = get_posts(
			array(
				'post_type'      => $post_type,
				'post_status'    => 'publish',
				'posts_per_page' => self::MAX_FORMS,
				'orderby'        => 'ID',
				'order'          => 'DESC',
			)
		);
		$out   = array();
		foreach ( $posts as $post ) {
			$out[] = self::form( $post->ID, $post->post_title, call_user_func( $fields, $post ) );
		}
		return $out;
	}

	private static function cf7_fields( \WP_Post $post ) {
		if ( ! class_exists( 'WPCF7_ContactForm' ) ) {
			return array();
		}
		$form = \WPCF7_ContactForm::get_instance( $post->ID );
		if ( ! $form ) {
			return array();
		}
		$out = array();
		foreach ( $form->scan_form_tags() as $tag ) {
			if ( '' !== $tag->name ) {
				$out[] = $tag->name . ' (' . $tag->basetype . ')';
			} elseif ( 'submit' === $tag->basetype ) {
				$out[] = 'submit';
			}
		}
		return $out;
	}

	private static function wpforms_fields( \WP_Post $post ) {
		$data = json_decode( $post->post_content, true );
		$out  = array();
		foreach ( (array) ( $data['fields'] ?? array() ) as $field ) {
			$out[] = ( $field['label'] ?? '' ) . ' (' . ( $field['type'] ?? '' ) . ')';
		}
		return $out;
	}

	private static function weforms_fields( \WP_Post $post ) {
		$inputs = get_posts(
			array(
				'post_type'      => 'wpuf_input',
				'post_parent'    => $post->ID,
				'posts_per_page' => self::MAX_FIELDS,
			)
		);
		$out    = array();
		foreach ( $inputs as $input ) {
			$field = maybe_unserialize( $input->post_content );
			if ( is_array( $field ) ) {
				$out[] = ( $field['label'] ?? '' ) . ' (' . ( $field['template'] ?? '' ) . ')';
			}
		}
		return $out;
	}

	private static function fluentform_forms() {
		global $wpdb;
		$table = $wpdb->prefix . 'fluentform_forms';
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) !== $table ) {
			return array();
		}
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT id, title, form_fields FROM {$table} WHERE status = %s ORDER BY id DESC LIMIT %d", 'published', self::MAX_FORMS ) );
		$out  = array();
		foreach ( (array) $rows as $row ) {
			$data   = json_decode( (string) $row->form_fields, true );
			$fields = self::fluentform_fields( (array) ( $data['fields'] ?? array() ) );
			// The form's own button, unless a custom submit button replaced it.
			if ( ! empty( $data['submitButton'] ) && ! preg_grep( '/^submit/', $fields ) ) {
				$fields = array_merge( $fields, self::fluentform_fields( array( array( 'element' => 'submit' ) + $data['submitButton'] ) ) );
			}
			$out[] = self::form( $row->id, $row->title, $fields );
		}
		return $out;
	}

	/** Fluent Forms nests fields inside containers (columns) and name groups. */
	private static function fluentform_fields( array $fields ) {
		$out = array();
		foreach ( $fields as $field ) {
			if ( ! empty( $field['columns'] ) ) {
				foreach ( (array) $field['columns'] as $column ) {
					$out = array_merge( $out, self::fluentform_fields( (array) ( $column['fields'] ?? array() ) ) );
				}
				continue;
			}
			$element = (string) ( $field['element'] ?? '' );
			if ( false !== strpos( $element, 'submit' ) ) {
				$text  = $field['settings']['button_ui']['text'] ?? '';
				$out[] = $text ? 'submit "' . $text . '"' : 'submit';
				continue;
			}
			if ( 'custom_html' === $element ) {
				$text  = trim( wp_strip_all_tags( (string) ( $field['settings']['html_codes'] ?? '' ) ) );
				$out[] = 'text "' . wp_trim_words( $text, 8, '…' ) . '"';
				continue;
			}
			// Many forms show placeholders only; the label is then empty.
			$label = $field['settings']['label'] ?? '';
			foreach ( array( $field['settings']['admin_field_label'] ?? '', $field['attributes']['placeholder'] ?? '', $field['attributes']['name'] ?? '' ) as $fallback ) {
				if ( '' !== $label ) {
					break;
				}
				$label = (string) $fallback;
			}
			$out[] = $label . ' (' . $element . ')';
		}
		return $out;
	}

	private static function ninja_forms() {
		if ( ! function_exists( 'Ninja_Forms' ) ) {
			return array();
		}
		$out = array();
		foreach ( array_slice( (array) Ninja_Forms()->form()->get_forms(), 0, self::MAX_FORMS ) as $form ) {
			$fields = array();
			foreach ( (array) Ninja_Forms()->form( $form->get_id() )->get_fields() as $field ) {
				$fields[] = $field->get_setting( 'label' ) . ' (' . $field->get_setting( 'type' ) . ')';
			}
			$out[] = self::form( $form->get_id(), $form->get_setting( 'title' ), $fields );
		}
		return $out;
	}

	private static function gravity_forms() {
		if ( ! class_exists( 'GFAPI' ) ) {
			return array();
		}
		$out = array();
		foreach ( array_slice( (array) \GFAPI::get_forms(), 0, self::MAX_FORMS ) as $form ) {
			$fields = array();
			foreach ( (array) ( $form['fields'] ?? array() ) as $field ) {
				$fields[] = $field->label . ' (' . $field->type . ')';
			}
			$out[] = self::form( $form['id'], $form['title'], $fields );
		}
		return $out;
	}

	/**
	 * The Mailchimp widget subscribes people to a Mailchimp list with the API
	 * key saved in Essential Addons' settings. Lists are only fetched when a
	 * key is saved (it asks Mailchimp).
	 */
	private static function mailchimp() {
		$key   = (string) get_option( 'eael_save_mailchimp_api', '' );
		$lists = array();
		if ( '' !== $key ) {
			try {
				foreach ( (array) Helper::mailchimp_lists() as $id => $name ) {
					$lists[] = array(
						'id'    => (string) $id,
						'title' => (string) $name,
					);
				}
			} catch ( \Throwable $e ) {
				$lists = array();
			}
		}
		return array(
			'available'   => true,
			'apiKeySet'   => '' !== $key,
			'lists'       => $lists,
			'settingsUrl' => admin_url( 'admin.php?page=eael-settings' ),
		);
	}
}
