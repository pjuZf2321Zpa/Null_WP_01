<?php
namespace Essential_Addons_Elementor\Pro\Classes\FigWP;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * FigWP: AI apps like Claude and ChatGPT, connected to the FigWP MCP server,
 * build draft pages on this site from Figma designs with Essential Addons
 * widgets. The site is connected from Essential Addons > Tools > FigWP; from
 * then on figwp.app calls the signed REST routes under /wp-json/figwp/v1.
 */
class Module {

	public static function init() {
		// Where FigWP lives: the dev server while FigWP is in development.
		// The live server is https://api.figwp.app with
		// https://dashboard.figwp.app. Override both in wp-config.php to use
		// another server (or a local one).
		if ( ! defined( 'EAEL_PRO_FIGWP_API_URL' ) ) {
			define( 'EAEL_PRO_FIGWP_API_URL', 'https://devapi.figwp.app' );
		}
		if ( ! defined( 'EAEL_PRO_FIGWP_APP_URL' ) ) {
			define( 'EAEL_PRO_FIGWP_APP_URL', 'https://user.dev.figwp.app' );
		}

		add_action( 'rest_api_init', array( Rest_Controller::class, 'register_routes' ) );
		Preview::init();

		if ( is_admin() ) {
			Tools_Box::init();
		}
	}
}
