<?php
namespace Essential_Addons_Elementor\Pro\Classes\FigWP;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Turns FigWP's Elementor JSON into a draft page or template.
 *
 * Content goes through Elementor's own import path: every control's
 * on_import runs (so MEDIA controls download images into the media library,
 * deduplicated by Elementor's source hash), then the document is saved the
 * way the editor saves it. Nothing is ever published here.
 */
class Importer {

	/** Post meta marking a post this plugin created; only those are replaced. */
	const META = '_figwp_import';

	const PAGE_TEMPLATES = array(
		'canvas'     => 'elementor_canvas',
		'full_width' => 'elementor_header_footer',
		'theme'      => 'default',
	);

	const TEMPLATE_TYPES = array( 'page', 'section', 'container', 'header', 'footer' );

	/**
	 * Where FigWP hosts exported images. They expire after 7 days, so any
	 * still referenced after the import has to be reported.
	 */
	const REMOTE_IMAGE_PATTERN = '#^https?://storage\.googleapis\.com/figwp-#';

	/**
	 * Import content as a new draft, or into a draft this plugin made before.
	 *
	 * @param array $args {
	 *     @type string $title         Post title.
	 *     @type array  $content       Elementor elements (top level).
	 *     @type array  $page_settings Optional document settings.
	 *     @type string $target        'page' (default) or 'template'.
	 *     @type string $template_type For templates: page|section|container|header|footer.
	 *     @type string $page_template canvas (default) | full_width | theme.
	 *     @type int    $replace_post_id Replace this FigWP draft instead of creating one.
	 *     @type int    $append_to_post_id Add the content after this FigWP draft's own.
	 *     @type array  $source        Optional { conversionId }: the FigWP conversion this came from.
	 * }
	 * @return array|\WP_Error
	 */
	public static function import( array $args ) {
		$problems = Site_Profile::problems();
		if ( $problems ) {
			return new \WP_Error(
				'figwp_not_ready',
				implode( ' ', $problems ),
				array(
					'status'   => 409,
					'problems' => $problems,
				)
			);
		}

		$content = isset( $args['content'] ) ? $args['content'] : null;
		if ( ! is_array( $content ) || empty( $content ) || ! self::is_list( $content ) ) {
			return new \WP_Error( 'figwp_bad_content', 'content must be a non-empty list of Elementor elements.', array( 'status' => 400 ) );
		}

		$missing = self::missing_element_types( $content );
		if ( $missing ) {
			return new \WP_Error(
				'figwp_missing_widgets',
				'This site does not have these widgets: ' . implode( ', ', $missing ) . '. Activate the plugin that provides them, or convert those sections with other widgets.',
				array(
					'status'  => 422,
					'missing' => $missing,
				)
			);
		}

		$document = self::resolve_document( $args );
		if ( is_wp_error( $document ) ) {
			return $document;
		}

		// The same part added twice (a retry after a timeout) is added once.
		$append_key = self::is_append( $args ) && ! empty( $args['append_key'] ) ? (string) $args['append_key'] : '';
		if ( '' !== $append_key ) {
			$previous = (array) get_post_meta( $document->get_main_id(), self::META, true );
			foreach ( (array) ( $previous['appended'] ?? array() ) as $part ) {
				if ( isset( $part['key'] ) && $part['key'] === $append_key ) {
					$elements = (array) $document->get_elements_data();
					return array_merge(
						self::describe( $document->get_main_id() ),
						array(
							'elementCount' => self::count_elements( $elements ),
							'widgets'      => self::widget_counts( $elements ),
							'idMap'        => (object) ( $part['id_map'] ?? array() ),
							'remoteImages' => array(),
							'warnings'     => array( 'This part was already added to the page; it was not added again.' ),
						)
					);
				}
			}
		}

		// Appending keeps the page's own elements first; new ids must not
		// repeat theirs.
		$existing = self::is_append( $args ) ? (array) $document->get_elements_data() : array();
		$seen     = array();
		self::walk(
			$existing,
			function ( $element ) use ( &$seen ) {
				if ( isset( $element['id'] ) ) {
					$seen[ (string) $element['id'] ] = true;
				}
			}
		);
		$id_map  = array();
		$content = self::normalize_ids( $content, $id_map, $seen );

		$warnings = array();
		$content  = self::create_menus( $content, $document->get_main_id(), $warnings );

		self::adopt_local_images( $content );
		$elementor = \Elementor\Plugin::$instance;
		$content   = $elementor->db->iterate_data(
			$content,
			function ( $element_data ) use ( $elementor, $document ) {
				$element = $elementor->elements_manager->create_element_instance( $element_data );
				if ( ! $element ) {
					return null;
				}
				return $document->process_element_import_export( $element, 'on_import' );
			}
		);

		$settings = isset( $args['page_settings'] ) && is_array( $args['page_settings'] ) ? $args['page_settings'] : array();
		if ( self::is_append( $args ) && ! $settings ) {
			$settings = (array) $document->get_settings();
		}
		$saved    = $document->save(
			array(
				'elements' => array_merge( $existing, $content ),
				'settings' => $settings,
			)
		);
		if ( ! $saved ) {
			return new \WP_Error( 'figwp_save_failed', 'Elementor could not save the page.', array( 'status' => 500 ) );
		}

		$post_id = $document->get_main_id();
		self::rebuild_css( $post_id );
		if ( 'page' === self::target( $args ) ) {
			$template = isset( $args['page_template'] ) ? (string) $args['page_template'] : 'canvas';
			update_post_meta( $post_id, '_wp_page_template', self::PAGE_TEMPLATES[ $template ] ?? self::PAGE_TEMPLATES['canvas'] );
		}
		$meta = array(
			'imported_at'    => time(),
			'plugin_version' => EAEL_PRO_PLUGIN_VERSION,
			'source'         => self::source( $args ),
			'id_map'         => $id_map,
		);
		if ( self::is_append( $args ) ) {
			// The page's first import stays its source; appended parts are listed.
			$previous         = (array) get_post_meta( $post_id, self::META, true );
			$meta['source']   = $previous['source'] ?? $meta['source'];
			$meta['id_map']   = array_merge( (array) ( $previous['id_map'] ?? array() ), $id_map );
			$meta['appended'] = array_merge(
				(array) ( $previous['appended'] ?? array() ),
				array(
					array(
						'at'     => time(),
						'key'    => $append_key,
						'source' => self::source( $args ),
						'id_map' => $id_map,
					),
				)
			);
		}
		update_post_meta( $post_id, self::META, $meta );

		$remote = self::remote_images( $content );
		if ( $remote ) {
			$warnings[] = sprintf(
				'%d image(s) could not be copied into the media library and still point at FigWP\'s temporary image storage, which expires after 7 days. Replace them in Elementor or import again.',
				count( $remote )
			);
		}

		return array_merge(
			self::describe( $post_id ),
			array(
				'elementCount' => self::count_elements( $content ),
				'widgets'      => self::widget_counts( $content ),
				'idMap'        => (object) $id_map,
				'remoteImages' => array_slice( $remote, 0, 50 ),
				'warnings'     => $warnings,
			)
		);
	}

	/**
	 * A page or template's current Elementor content.
	 *
	 * @return array|\WP_Error
	 */
	public static function get_page( $post_id ) {
		$post = get_post( (int) $post_id );
		if ( ! $post || ! self::is_elementor_post( $post->ID ) ) {
			return new \WP_Error( 'figwp_not_found', 'No Elementor page with that id.', array( 'status' => 404 ) );
		}
		$document = \Elementor\Plugin::$instance->documents->get( $post->ID );
		$elements = $document ? $document->get_elements_data() : array();

		return array_merge(
			self::describe( $post->ID ),
			array(
				'elementCount' => self::count_elements( $elements ),
				'widgets'      => self::widget_counts( $elements ),
				'elements'     => $elements,
			)
		);
	}

	/**
	 * Publish a draft this plugin imported.
	 *
	 * @return array|\WP_Error
	 */
	public static function publish( $post_id ) {
		$post = get_post( (int) $post_id );
		if ( ! $post || ! get_post_meta( $post->ID, self::META, true ) ) {
			return new \WP_Error( 'figwp_not_found', 'No FigWP import with that id.', array( 'status' => 404 ) );
		}
		if ( ! current_user_can( 'publish_post', $post->ID ) ) {
			return new \WP_Error( 'figwp_forbidden', 'The connected WordPress user cannot publish this page.', array( 'status' => 403 ) );
		}
		if ( 'publish' !== $post->post_status ) {
			$result = wp_update_post(
				array(
					'ID'          => $post->ID,
					'post_status' => 'publish',
				),
				true
			);
			if ( is_wp_error( $result ) ) {
				return $result;
			}
		}
		return self::describe( $post->ID );
	}

	// ── Helpers ────────────────────────────────────────────────────────────

	/**
	 * Write the page's Elementor CSS now. Elementor otherwise rebuilds it on
	 * the next view, and that first view renders without it: a verification
	 * right after a save measured an unstyled page three times too tall.
	 */
	public static function rebuild_css( $post_id ) {
		if ( class_exists( '\\Elementor\\Core\\Files\\CSS\\Post' ) ) {
			\Elementor\Core\Files\CSS\Post::create( $post_id )->update();
		}
	}

	private static function is_append( array $args ) {
		return ! empty( $args['append_to_post_id'] ) && empty( $args['replace_post_id'] );
	}

	/** Images one media request copies, so each request stays short. */
	const MEDIA_BATCH = 20;

	/**
	 * Copy FigWP's hosted images into the media library, a few per request.
	 *
	 * A big page's import downloaded every image inside one request and
	 * outlived the caller's timeout. figwp.app copies them here first, in
	 * batches, then imports the page with these attachments, which the
	 * import only looks up. Each image is copied once: Elementor's importer
	 * finds one it copied before by a hash of the source URL.
	 *
	 * @param string[] $urls FigWP image URLs; nothing else is fetched.
	 * @return array|\WP_Error { images: [ { url, id, mediaUrl } | { url, error } ] }
	 */
	public static function import_media( array $urls ) {
		if ( ! current_user_can( 'upload_files' ) ) {
			return new \WP_Error( 'figwp_forbidden', 'The connected WordPress user cannot upload files.', array( 'status' => 403 ) );
		}
		$urls = array_values( array_unique( array_filter( array_map( 'strval', $urls ) ) ) );
		if ( ! $urls ) {
			return new \WP_Error( 'figwp_bad_media', 'urls must list at least one image.', array( 'status' => 400 ) );
		}
		if ( count( $urls ) > self::MEDIA_BATCH ) {
			return new \WP_Error( 'figwp_bad_media', 'At most ' . self::MEDIA_BATCH . ' images per request.', array( 'status' => 400 ) );
		}

		$importer = \Elementor\Plugin::$instance->templates_manager->get_import_images_instance();
		$images   = array();
		foreach ( $urls as $url ) {
			if ( ! preg_match( self::REMOTE_IMAGE_PATTERN, $url ) || 0 !== strpos( $url, 'https://' ) ) {
				$images[] = array(
					'url'   => $url,
					'error' => 'Only images FigWP hosts are copied.',
				);
				continue;
			}
			// A non-empty id makes Elementor look for a copy it made before.
			$attachment = $importer->import(
				array(
					'id'  => 'figwp-' . sha1( $url ),
					'url' => $url,
				)
			);
			if ( empty( $attachment['id'] ) || empty( $attachment['url'] ) ) {
				$images[] = array(
					'url'   => $url,
					'error' => 'The image could not be downloaded.',
				);
				continue;
			}
			$images[] = array(
				'url'      => $url,
				'id'       => (int) $attachment['id'],
				'mediaUrl' => (string) $attachment['url'],
			);
		}
		return array( 'images' => $images );
	}

	private static function target( array $args ) {
		return isset( $args['target'] ) && 'template' === $args['target'] ? 'template' : 'page';
	}

	/**
	 * @return \Elementor\Core\Base\Document|\WP_Error
	 */
	private static function resolve_document( array $args ) {
		$documents = \Elementor\Plugin::$instance->documents;

		if ( ! empty( $args['replace_post_id'] ) || self::is_append( $args ) ) {
			$append  = self::is_append( $args );
			$post_id = (int) ( $append ? $args['append_to_post_id'] : $args['replace_post_id'] );
			$post    = get_post( $post_id );
			if ( ! $post || ! get_post_meta( $post_id, self::META, true ) ) {
				return new \WP_Error( 'figwp_not_found', $append ? 'Content can only be added to pages FigWP imported.' : 'Only pages FigWP imported can be replaced.', array( 'status' => 404 ) );
			}
			if ( 'publish' === $post->post_status ) {
				return new \WP_Error( 'figwp_published', $append ? 'This page is published. Add to a draft instead.' : 'This page is published. Import a new draft instead of replacing it.', array( 'status' => 409 ) );
			}
			if ( ! current_user_can( 'edit_post', $post_id ) ) {
				return new \WP_Error( 'figwp_forbidden', 'The connected WordPress user cannot edit this page.', array( 'status' => 403 ) );
			}
			// Adding to a page doesn't rename it.
			$title = isset( $args['title'] ) && ! $append ? sanitize_text_field( (string) $args['title'] ) : '';
			if ( '' !== $title && $title !== $post->post_title ) {
				wp_update_post(
					array(
						'ID'         => $post_id,
						'post_title' => $title,
					)
				);
			}
			$document = $documents->get( $post_id, false );
			return $document ? $document : new \WP_Error( 'figwp_not_found', 'Elementor could not open that page.', array( 'status' => 404 ) );
		}

		$title = isset( $args['title'] ) ? sanitize_text_field( (string) $args['title'] ) : '';
		$title = '' !== $title ? $title : 'FigWP import';

		if ( 'template' === self::target( $args ) ) {
			$type = isset( $args['template_type'] ) ? (string) $args['template_type'] : 'page';
			if ( ! in_array( $type, self::TEMPLATE_TYPES, true ) ) {
				return new \WP_Error( 'figwp_template_type', '"' . $type . '" is not a template type. Valid types: ' . implode( ', ', self::TEMPLATE_TYPES ) . '.', array( 'status' => 422 ) );
			}
			if ( ! $documents->get_document_type( $type, false ) ) {
				$why = in_array( $type, array( 'header', 'footer' ), true )
					? 'Header and footer templates need Elementor Pro.'
					: 'This template type is not enabled in this site\'s Elementor.';
				return new \WP_Error( 'figwp_template_type', 'This site cannot create a "' . $type . '" template. ' . $why, array( 'status' => 422 ) );
			}
			if ( ! current_user_can( 'edit_posts' ) ) {
				return new \WP_Error( 'figwp_forbidden', 'The connected WordPress user cannot create templates.', array( 'status' => 403 ) );
			}
			$document = $documents->create(
				$type,
				array(
					'post_title'  => $title,
					'post_status' => 'draft',
				)
			);
		} else {
			if ( ! current_user_can( 'edit_pages' ) ) {
				return new \WP_Error( 'figwp_forbidden', 'The connected WordPress user cannot create pages.', array( 'status' => 403 ) );
			}
			$document = $documents->create(
				'wp-page',
				array(
					'post_title'  => $title,
					'post_status' => 'draft',
					'post_type'   => 'page',
				)
			);
		}

		if ( is_wp_error( $document ) ) {
			$document->add_data( array( 'status' => 500 ) );
		}
		return $document;
	}

	/**
	 * Widget and element types the content uses that this site lacks.
	 * Elementor's importer silently drops unknown elements; refusing instead
	 * means a section never disappears without anyone being told.
	 *
	 * @return string[]
	 */
	public static function missing_element_types( array $content ) {
		$elementor = \Elementor\Plugin::$instance;
		$missing   = array();
		self::walk(
			$content,
			function ( $element ) use ( $elementor, &$missing ) {
				$el_type = isset( $element['elType'] ) ? (string) $element['elType'] : '';
				if ( 'widget' === $el_type ) {
					$type = isset( $element['widgetType'] ) ? (string) $element['widgetType'] : '';
					if ( '' === $type || ! $elementor->widgets_manager->get_widget_types( $type ) ) {
						$missing[ '' === $type ? '(widget without a type)' : $type ] = true;
					}
				} elseif ( '' === $el_type || ! $elementor->elements_manager->get_element_types( $el_type ) ) {
					$missing[ '' === $el_type ? '(element without elType)' : $el_type ] = true;
				}
			}
		);
		return array_keys( $missing );
	}

	/**
	 * Keep FigWP's element ids (they tie elements back to Figma nodes) unless
	 * one is malformed or repeated; those get a fresh id, reported in $id_map.
	 */
	public static function normalize_ids( array $elements, array &$id_map, array &$seen = array() ) {
		foreach ( $elements as $i => $element ) {
			if ( ! is_array( $element ) ) {
				continue;
			}
			$id     = isset( $element['id'] ) ? (string) $element['id'] : '';
			$old_id = $id;
			if ( ! preg_match( '/^[a-z0-9]{1,20}$/i', $id ) || isset( $seen[ $id ] ) ) {
				$new_id = \Elementor\Utils::generate_random_string();
				if ( '' !== $id ) {
					$id_map[ $id ] = $new_id;
				}
				$id = $new_id;
				// Multicolumn Pricing Table keys each plan's cells by the
				// element id (eael_mcpt_package_{id}_{plan}_features).
				if ( '' !== $old_id && ! empty( $element['settings'] ) && is_array( $element['settings'] ) ) {
					$elements[ $i ]['settings'] = self::rekey_settings( $element['settings'], $old_id, $id );
				}
			}
			$seen[ $id ]          = true;
			$elements[ $i ]['id'] = $id;
			if ( ! empty( $element['elements'] ) && is_array( $element['elements'] ) ) {
				$elements[ $i ]['elements'] = self::normalize_ids( $element['elements'], $id_map, $seen );
			}
		}
		return $elements;
	}

	/** Settings whose keys embed the element's old id, under its new one. */
	private static function rekey_settings( array $settings, $old_id, $new_id ) {
		$prefix = 'eael_mcpt_package_' . $old_id . '_';
		$out    = array();
		foreach ( $settings as $key => $value ) {
			if ( is_string( $key ) && 0 === strpos( $key, $prefix ) ) {
				$key = 'eael_mcpt_package_' . $new_id . '_' . substr( $key, strlen( $prefix ) );
			}
			$out[ $key ] = $value;
		}
		return $out;
	}

	/**
	 * Mark images that are already in this site's media library so
	 * Elementor's on_import reuses them. Its importer only recognises
	 * attachments it downloaded itself (by a hash of the source URL);
	 * anything else it fetches again, and wp_safe_remote_get refuses this
	 * site's own address on a local install, leaving a placeholder.
	 */
	public static function adopt_local_images( array $elements ) {
		$adopt = function ( $value ) use ( &$adopt ) {
			if ( ! is_array( $value ) ) {
				return;
			}
			if ( ! empty( $value['id'] ) && ! empty( $value['url'] ) && is_string( $value['url'] ) && is_numeric( $value['id'] ) ) {
				$id    = (int) $value['id'];
				$own   = array();
				if ( 'attachment' === get_post_type( $id ) ) {
					// An image over WordPress's big-image threshold (2,560px)
					// is served as a "-scaled" copy; Elementor's importer
					// reports the original's URL, which is the same image.
					$own = array_filter( array( wp_get_attachment_url( $id ), wp_get_original_image_url( $id ) ) );
				}
				$strip = function ( $url ) {
					return preg_replace( '#^https?:#i', '', (string) $url );
				};
				if ( in_array( $strip( $value['url'] ), array_map( $strip, $own ), true ) ) {
					$hash = sha1( $value['url'] );
					if ( ! in_array( $hash, get_post_meta( $id, '_elementor_source_image_hash' ), true ) ) {
						add_post_meta( $id, '_elementor_source_image_hash', $hash );
					}
				}
			}
			foreach ( $value as $child ) {
				$adopt( $child );
			}
		};
		self::walk(
			$elements,
			function ( $element ) use ( $adopt ) {
				$adopt( (array) ( $element['settings'] ?? array() ) );
			}
		);
	}

	/**
	 * Settings that still reference FigWP-hosted images after the import.
	 * Only settings the element actually registers count: a stray key the
	 * widget never reads isn't rendered, so its URL can't break the page.
	 *
	 * @return array<int,array{elementId:string,setting:string,url:string}>
	 */
	public static function remote_images( array $elements ) {
		$found            = array();
		$elements_manager = \Elementor\Plugin::$instance->elements_manager;
		self::walk(
			$elements,
			function ( $element ) use ( &$found, $elements_manager ) {
				$instance = $elements_manager->create_element_instance( $element );
				$controls = $instance ? $instance->get_controls() : array();
				$scan     = function ( $value, $path ) use ( &$scan, &$found, $element ) {
					if ( is_string( $value ) ) {
						if ( preg_match( self::REMOTE_IMAGE_PATTERN, $value ) ) {
							$found[] = array(
								'elementId' => isset( $element['id'] ) ? (string) $element['id'] : '',
								'setting'   => $path,
								'url'       => $value,
							);
						}
					} elseif ( is_array( $value ) ) {
						foreach ( $value as $key => $child ) {
							$scan( $child, '' === $path ? (string) $key : $path . '.' . $key );
						}
					}
				};
				foreach ( (array) ( $element['settings'] ?? array() ) as $key => $value ) {
					if ( isset( $controls[ $key ] ) ) {
						$scan( $value, (string) $key );
					}
				}
			}
		);
		return $found;
	}

	/** Menu widgets and the setting that holds their WordPress menu id. */
	const MENU_SETTINGS = array(
		'eael-simple-menu'   => 'eael_simple_menu_menu',
		'eael-advanced-menu' => 'eael_advanced_menu_menu',
	);

	/** Post meta remembering the menus an import created, by element id. */
	const MENUS_META = '_figwp_menus';

	/**
	 * Create the WordPress menus the design draws.
	 *
	 * A menu widget can only show a menu that exists on the site, and Figma
	 * has none, so FigWP sends each menu's link labels with the element
	 * ("figwp": { "menu": { "items": [...] } }). Each becomes a menu of
	 * custom links — "#" until someone sets real URLs — and the widget is
	 * pointed at it. Re-importing the same draft refills the same menus
	 * instead of adding new ones. The "figwp" key is removed from every
	 * element before Elementor sees the content.
	 *
	 * @param array    $elements  Elementor elements.
	 * @param int      $post_id   The page being imported into.
	 * @param string[] $warnings  Collected for the import result.
	 */
	private static function create_menus( array $elements, $post_id, array &$warnings ) {
		$known   = get_post_meta( $post_id, self::MENUS_META, true );
		$known   = is_array( $known ) ? $known : array();
		$created = $known;
		$can     = current_user_can( 'edit_theme_options' );
		$title   = get_the_title( $post_id );

		$process = function ( array $items ) use ( &$process, &$created, &$warnings, $known, $can, $title ) {
			foreach ( $items as $i => $element ) {
				if ( ! is_array( $element ) ) {
					continue;
				}
				$menu   = $element['figwp']['menu']['items'] ?? null;
				$widget = $element['widgetType'] ?? '';
				unset( $items[ $i ]['figwp'] );

				if ( is_array( $menu ) && isset( self::MENU_SETTINGS[ $widget ] ) ) {
					$labels = array_slice(
						array_values( array_filter( array_map( 'sanitize_text_field', array_map( 'strval', $menu ) ) ) ),
						0,
						30
					);
					if ( ! $labels ) {
						// Nothing to build.
					} elseif ( ! $can ) {
						$warnings[] = 'The connected WordPress user cannot manage menus, so the header menu was not created. Pick a menu for it in Elementor.';
					} else {
						$element_id = (string) ( $element['id'] ?? '' );
						$error      = '';
						$menu_id    = self::fill_menu( $known[ $element_id ] ?? 0, $title, $labels, $error );
						if ( $menu_id ) {
							$created[ $element_id ]                                    = $menu_id;
							$items[ $i ]['settings'][ self::MENU_SETTINGS[ $widget ] ] = (string) $menu_id;
						} else {
							$warnings[] = 'A menu for "' . $title . '" could not be created' . ( '' !== $error ? ' (the site said: ' . $error . ')' : '' ) . '. Pick a menu for the menu widget in Elementor.';
						}
					}
				}

				if ( ! empty( $element['elements'] ) && is_array( $element['elements'] ) ) {
					$items[ $i ]['elements'] = $process( $element['elements'] );
				}
			}
			return $items;
		};

		$elements = $process( $elements );
		if ( $created !== $known ) {
			update_post_meta( $post_id, self::MENUS_META, $created );
		}
		return $elements;
	}

	/** wp_die() handler filters, one per request type wp_die() can pick. */
	const DIE_HANDLER_FILTERS = array(
		'wp_die_handler',
		'wp_die_ajax_handler',
		'wp_die_json_handler',
		'wp_die_jsonp_handler',
		'wp_die_xmlrpc_handler',
		'wp_die_xml_handler',
	);

	/**
	 * Fill a menu with custom links: reuse $menu_id when it still exists,
	 * otherwise create "<page title> menu" (numbered if the name is taken).
	 *
	 * Menus are optional, so a failure here must never cost the page. Other
	 * plugins hook menu saves and some call check_admin_referer(), which
	 * can't pass in a REST request and would wp_die() the whole import
	 * ("The link you followed has expired."). While the menu is built,
	 * wp_die() throws instead; any failure deletes a menu this call created
	 * and returns 0, so the import goes on and warns about the menu.
	 *
	 * @param int      $menu_id A menu an earlier import created, or 0.
	 * @param string   $title   The page title, for the menu's name.
	 * @param string[] $labels  The drawn link labels.
	 * @param string   $error   Set to why the menu failed, if it did.
	 * @return int The menu's term id, or 0.
	 */
	private static function fill_menu( $menu_id, $title, array $labels, &$error = '' ) {
		$throw   = function ( $message ) {
			throw new \RuntimeException( is_wp_error( $message ) ? $message->get_error_message() : wp_strip_all_tags( (string) $message ) );
		};
		$handler = function () use ( $throw ) {
			return $throw;
		};
		foreach ( self::DIE_HANDLER_FILTERS as $filter ) {
			add_filter( $filter, $handler, PHP_INT_MAX );
		}

		$new_menu = 0;
		try {
			return self::build_menu( $menu_id, $title, $labels, $new_menu );
		} catch ( \Throwable $e ) {
			$error = $e->getMessage();
			if ( $new_menu ) {
				wp_delete_nav_menu( $new_menu );
			}
			return 0;
		} finally {
			foreach ( self::DIE_HANDLER_FILTERS as $filter ) {
				remove_filter( $filter, $handler, PHP_INT_MAX );
			}
		}
	}

	/**
	 * The menu work fill_menu() guards. Throws on any failure.
	 *
	 * @param int $new_menu Set to the menu's id when this call created it.
	 * @return int The menu's term id.
	 */
	private static function build_menu( $menu_id, $title, array $labels, &$new_menu ) {
		$menu = $menu_id ? wp_get_nav_menu_object( (int) $menu_id ) : false;
		if ( $menu ) {
			foreach ( (array) wp_get_nav_menu_items( $menu->term_id, array( 'post_status' => 'any' ) ) as $item ) {
				wp_delete_post( $item->ID, true );
			}
			$menu_id = $menu->term_id;
		} else {
			$base = trim( $title ) !== '' ? trim( $title ) . ' menu' : 'FigWP menu';
			$name = $base;
			for ( $n = 2; wp_get_nav_menu_object( $name ) && $n < 50; $n++ ) {
				$name = $base . ' ' . $n;
			}
			$menu_id = wp_create_nav_menu( $name );
			if ( is_wp_error( $menu_id ) ) {
				throw new \RuntimeException( $menu_id->get_error_message() );
			}
			$new_menu = (int) $menu_id;
		}

		foreach ( $labels as $position => $label ) {
			$item = wp_update_nav_menu_item(
				$menu_id,
				0,
				array(
					'menu-item-title'    => $label,
					'menu-item-url'      => '#',
					'menu-item-type'     => 'custom',
					'menu-item-status'   => 'publish',
					'menu-item-position' => $position + 1,
				)
			);
			if ( is_wp_error( $item ) ) {
				throw new \RuntimeException( $item->get_error_message() );
			}
		}
		return (int) $menu_id;
	}

	public static function walk( array $elements, callable $visit ) {
		foreach ( $elements as $element ) {
			if ( ! is_array( $element ) ) {
				continue;
			}
			$visit( $element );
			if ( ! empty( $element['elements'] ) && is_array( $element['elements'] ) ) {
				self::walk( $element['elements'], $visit );
			}
		}
	}

	public static function count_elements( array $elements ) {
		$count = 0;
		self::walk(
			$elements,
			function () use ( &$count ) {
				++$count;
			}
		);
		return $count;
	}

	/** @return array<string,int> widget type => how many times it's used */
	public static function widget_counts( array $elements ) {
		$counts = array();
		self::walk(
			$elements,
			function ( $element ) use ( &$counts ) {
				if ( isset( $element['elType'], $element['widgetType'] ) && 'widget' === $element['elType'] ) {
					$type            = (string) $element['widgetType'];
					$counts[ $type ] = ( $counts[ $type ] ?? 0 ) + 1;
				}
			}
		);
		ksort( $counts );
		return (object) $counts;
	}

	/**
	 * The FigWP conversion an import came from, so figwp.app can verify the
	 * page against its design. Element ids the import had to change are kept
	 * with it.
	 */
	private static function source( array $args ) {
		$source = isset( $args['source'] ) && is_array( $args['source'] ) ? $args['source'] : array();
		$id     = isset( $source['conversionId'] ) ? (string) $source['conversionId'] : '';
		return preg_match( '/^[0-9a-f-]{36}$/i', $id ) ? array( 'conversionId' => strtolower( $id ) ) : null;
	}

	private static function describe_source( $post_id ) {
		$meta = get_post_meta( $post_id, self::META, true );
		if ( ! is_array( $meta ) || empty( $meta['source']['conversionId'] ) ) {
			return null;
		}
		return array(
			'conversionId' => $meta['source']['conversionId'],
			'idMap'        => (object) ( isset( $meta['id_map'] ) && is_array( $meta['id_map'] ) ? $meta['id_map'] : array() ),
		);
	}

	public static function describe( $post_id ) {
		$post     = get_post( $post_id );
		$document = \Elementor\Plugin::$instance->documents->get( $post_id );
		return array(
			'postId'     => $post_id,
			'title'      => get_the_title( $post_id ),
			'status'     => $post ? $post->post_status : null,
			'postType'   => $post ? $post->post_type : null,
			'modifiedAt' => $post ? mysql_to_rfc3339( $post->post_modified_gmt ) : null,
			'editUrl'    => $document ? $document->get_edit_url() : get_edit_post_link( $post_id, 'raw' ),
			'previewUrl' => get_preview_post_link( $post_id ),
			'url'        => get_permalink( $post_id ),
			'source'     => self::describe_source( $post_id ),
		);
	}

	public static function is_elementor_post( $post_id ) {
		return 'builder' === get_post_meta( $post_id, '_elementor_edit_mode', true );
	}

	public static function is_list( array $value ) {
		return array_keys( $value ) === range( 0, count( $value ) - 1 );
	}
}
