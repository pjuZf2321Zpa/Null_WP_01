<?php
namespace Essential_Addons_Elementor\Pro\Classes\FigWP;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * What settings a widget (or the container) accepts on this site, as its
 * installed Elementor and add-ons register them, so an AI app can write
 * settings Elementor will use instead of keys it silently ignores.
 *
 * Read from the element's full control stack, style controls included. Only
 * REST requests get labels and options: on front-end requests Elementor trims
 * them away.
 */
class Widget_Schema {

	/** Controls that only arrange the panel; they store nothing. */
	const UI_TYPES = array( 'section', 'tab', 'tabs', 'heading', 'raw_html', 'divider', 'alert', 'notice', 'deprecated_notice', 'button', 'hidden' );

	const MAX_OPTIONS = 40;

	/** @return array|\WP_Error */
	public static function get( $type ) {
		$type      = sanitize_key( (string) $type );
		$elementor = \Elementor\Plugin::$instance;
		$element   = 'container' === $type
			? $elementor->elements_manager->get_element_types( 'container' )
			: $elementor->widgets_manager->get_widget_types( $type );
		if ( ! $element ) {
			return new \WP_Error( 'figwp_unknown_widget', sprintf( 'This site has no widget "%s".', $type ), array( 'status' => 404 ) );
		}

		$stack    = $element->get_stack();
		$controls = $stack['controls'] + ( isset( $stack['style_controls'] ) && is_array( $stack['style_controls'] ) ? $stack['style_controls'] : array() );

		$sections = array();
		foreach ( $controls as $name => $control ) {
			if ( isset( $control['type'] ) && 'section' === $control['type'] ) {
				$sections[ $name ] = isset( $control['label'] ) ? self::text( $control['label'] ) : $name;
			}
		}

		$out = array();
		foreach ( $controls as $name => $control ) {
			$ctype = isset( $control['type'] ) ? (string) $control['type'] : '';
			if ( '' === $ctype || in_array( $ctype, self::UI_TYPES, true ) ) {
				continue;
			}
			$out[] = self::describe( (string) $name, $control, $sections );
		}

		return array(
			'type'     => $type,
			'title'    => method_exists( $element, 'get_title' ) ? $element->get_title() : $type,
			'versions' => array(
				'elementor' => defined( 'ELEMENTOR_VERSION' ) ? ELEMENTOR_VERSION : null,
				'eael'      => defined( 'EAEL_PLUGIN_VERSION' ) ? EAEL_PLUGIN_VERSION : null,
				'eaelPro'   => defined( 'EAEL_PRO_PLUGIN_VERSION' ) ? EAEL_PRO_PLUGIN_VERSION : null,
			),
			'controls' => $out,
		);
	}

	private static function describe( $name, array $control, array $sections ) {
		$row = array(
			'name' => $name,
			'type' => (string) $control['type'],
		);
		if ( ! empty( $control['label'] ) ) {
			$row['label'] = self::text( $control['label'] );
		}
		if ( ! empty( $control['tab'] ) ) {
			$row['tab'] = (string) $control['tab'];
		}
		if ( ! empty( $control['section'] ) ) {
			$row['section'] = isset( $sections[ $control['section'] ] ) ? $sections[ $control['section'] ] : (string) $control['section'];
		}
		if ( ! empty( $control['is_responsive'] ) ) {
			$row['responsive'] = true;
		}
		if ( isset( $control['default'] ) && '' !== $control['default'] && array() !== $control['default'] ) {
			$row['default'] = $control['default'];
		}
		if ( ! empty( $control['options'] ) && is_array( $control['options'] ) ) {
			$options = array();
			foreach ( array_slice( $control['options'], 0, self::MAX_OPTIONS, true ) as $value => $label ) {
				$options[ (string) $value ] = is_array( $label ) ? ( isset( $label['title'] ) ? (string) $label['title'] : '' ) : self::text( $label );
			}
			$row['options'] = (object) $options;
		}
		if ( ! empty( $control['size_units'] ) ) {
			$row['units'] = array_values( (array) $control['size_units'] );
		}
		if ( ! empty( $control['range'] ) && is_array( $control['range'] ) ) {
			$row['range'] = $control['range'];
		}
		if ( ! empty( $control['condition'] ) ) {
			$row['condition'] = $control['condition'];
		}
		if ( ! empty( $control['groupType'] ) ) {
			$row['group'] = $control['groupType'];
			if ( ! empty( $control['groupPrefix'] ) ) {
				$row['groupPrefix'] = (string) $control['groupPrefix'];
			}
		}
		if ( ! empty( $control['global']['default'] ) ) {
			$row['globalDefault'] = $control['global']['default'];
		}
		if ( 'repeater' === $control['type'] && ! empty( $control['fields'] ) && is_array( $control['fields'] ) ) {
			$fields = array();
			foreach ( $control['fields'] as $field_name => $field ) {
				$field_type = isset( $field['type'] ) ? (string) $field['type'] : '';
				if ( '' === $field_type || in_array( $field_type, self::UI_TYPES, true ) ) {
					continue;
				}
				$fields[] = self::describe( isset( $field['name'] ) ? (string) $field['name'] : (string) $field_name, $field, $sections );
			}
			$row['fields'] = $fields;
		}
		return $row;
	}

	/** Panel text as plain words: no tags, no entities. */
	private static function text( $value ) {
		return html_entity_decode( wp_strip_all_tags( (string) $value ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );
	}
}
