<?php
namespace Essential_Addons_Elementor\Pro\Classes\FigWP;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * This site's link to a FigWP account.
 *
 * Pairing never puts the shared secret in a browser: the admin approves the
 * site on figwp.app, which sends the browser back here with a short-lived,
 * single-use code; this site then trades the code for the secret in a direct
 * server-to-server call.
 */
class Connection {

	const OPTION = 'figwp_connect';

	/** How long the admin has to approve the site on figwp.app. */
	const PAIRING_TTL = 15 * MINUTE_IN_SECONDS;

	/**
	 * The stored connection, or null when the site isn't connected.
	 *
	 * @return array{site_id:string,secret:string,wp_user_id:int,account_email:string,account_name:string,connected_at:int}|null
	 */
	public static function get() {
		$data = get_option( self::OPTION );
		if ( ! is_array( $data ) || empty( $data['site_id'] ) || empty( $data['secret'] ) ) {
			return null;
		}
		return $data;
	}

	public static function is_connected() {
		return null !== self::get();
	}

	/** Remove the connection locally. figwp.app is told separately. */
	public static function forget() {
		delete_option( self::OPTION );
	}

	public static function api_url( $path ) {
		return untrailingslashit( apply_filters( 'eael/figwp/api_url', EAEL_PRO_FIGWP_API_URL ) ) . $path;
	}

	public static function app_url( $path ) {
		return untrailingslashit( apply_filters( 'eael/figwp/app_url', EAEL_PRO_FIGWP_APP_URL ) ) . $path;
	}

	/**
	 * Where to send the admin to approve this site on figwp.app.
	 *
	 * @param \WP_User $user The admin starting the connection.
	 */
	public static function pairing_url( \WP_User $user ) {
		$state = wp_generate_password( 32, false );
		set_transient( self::state_key( $user->ID ), $state, self::PAIRING_TTL );

		return add_query_arg(
			array(
				'site_url'   => rawurlencode( home_url( '/' ) ),
				'site_name'  => rawurlencode( wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ) ),
				'return_url' => rawurlencode( admin_url( 'admin-post.php?action=eael_figwp_finish' ) ),
				'state'      => $state,
			),
			self::app_url( '/sites/connect' )
		);
	}

	/**
	 * Finish pairing: check the state, trade the code for the secret.
	 *
	 * @param \WP_User $user  The admin who started the connection.
	 * @param string  $code  Single-use code from figwp.app.
	 * @param string  $state The state sent with the pairing request.
	 * @return true|\WP_Error
	 */
	public static function finish_pairing( \WP_User $user, $code, $state ) {
		$expected = get_transient( self::state_key( $user->ID ) );
		delete_transient( self::state_key( $user->ID ) );
		if ( ! is_string( $expected ) || '' === $state || ! hash_equals( $expected, $state ) ) {
			return new \WP_Error( 'figwp_state', __( 'This connection request expired or was started in another browser. Start again.', 'essential-addons-elementor' ) );
		}
		if ( '' === $code ) {
			return new \WP_Error( 'figwp_code', __( 'FigWP did not send a connection code. Start again.', 'essential-addons-elementor' ) );
		}

		$response = wp_remote_post(
			self::api_url( '/api/sites/pairing/exchange' ),
			array(
				'timeout' => 20,
				'headers' => array( 'Content-Type' => 'application/json' ),
				'body'    => wp_json_encode(
					array(
						'code'          => $code,
						'siteUrl'       => home_url( '/' ),
						'restUrl'       => rest_url( 'figwp/v1/' ),
						'siteName'      => wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ),
						'wpUserId'      => $user->ID,
						'wpUserLogin'   => $user->user_login,
						'pluginVersion' => EAEL_PRO_PLUGIN_VERSION,
					)
				),
			)
		);
		if ( is_wp_error( $response ) ) {
			return new \WP_Error(
				'figwp_unreachable',
				/* translators: %s: error message */
				sprintf( __( 'Could not reach FigWP: %s', 'essential-addons-elementor' ), $response->get_error_message() )
			);
		}

		$status = wp_remote_retrieve_response_code( $response );
		$body   = json_decode( wp_remote_retrieve_body( $response ), true );
		$data   = isset( $body['data'] ) && is_array( $body['data'] ) ? $body['data'] : array();
		if ( $status < 200 || $status >= 300 || empty( $data['siteId'] ) || empty( $data['secret'] ) ) {
			$message = isset( $body['message'] ) && is_string( $body['message'] ) ? $body['message'] : __( 'FigWP refused the connection. Start again.', 'essential-addons-elementor' );
			return new \WP_Error( 'figwp_exchange', $message );
		}

		update_option(
			self::OPTION,
			array(
				'site_id'       => sanitize_text_field( $data['siteId'] ),
				'secret'        => $data['secret'],
				'wp_user_id'    => $user->ID,
				'account_email' => isset( $data['account']['email'] ) ? sanitize_email( $data['account']['email'] ) : '',
				'account_name'  => isset( $data['account']['name'] ) ? sanitize_text_field( $data['account']['name'] ) : '',
				'connected_at'  => time(),
			),
			false
		);
		return true;
	}

	/**
	 * Disconnect from this side: tell figwp.app (best effort), then forget.
	 * The local connection is removed even if figwp.app can't be reached.
	 */
	public static function disconnect() {
		$connection = self::get();
		if ( $connection ) {
			$route = '/api/sites/self/disconnect';
			$body  = '{}';
			wp_remote_post(
				self::api_url( $route ),
				array(
					'timeout' => 10,
					'headers' => array_merge(
						array( 'Content-Type' => 'application/json' ),
						Signature::headers_for( $connection['site_id'], $connection['secret'], 'POST', $route, $body )
					),
					'body'    => $body,
				)
			);
		}
		self::forget();
	}

	private static function state_key( $user_id ) {
		return 'figwp_pair_' . (int) $user_id;
	}
}
