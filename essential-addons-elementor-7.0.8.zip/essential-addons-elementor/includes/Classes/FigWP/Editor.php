<?php
namespace Essential_Addons_Elementor\Pro\Classes\FigWP;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Small, targeted edits to a page FigWP imported, for the repair loop:
 * read chosen elements, change their settings, replace a section, and undo.
 *
 * Every change first saves a snapshot of the page's elements (the last
 * SNAPSHOTS are kept), so an AI app can try a fix, verify it, and go back to
 * the best version.
 */
class Editor {

	const SNAPSHOTS_META = '_figwp_snapshots';
	const SNAPSHOTS      = 8;
	const MAX_PATCHES    = 200;

	/**
	 * Chosen elements, each without its children (their ids are listed
	 * instead), with the path of ids from the page's top.
	 *
	 * @return array|\WP_Error
	 */
	public static function get_elements( $post_id, array $ids ) {
		$document = self::document( $post_id );
		if ( is_wp_error( $document ) ) {
			return $document;
		}
		$wanted = array_flip( array_slice( array_map( 'strval', $ids ), 0, self::MAX_PATCHES ) );
		$found  = array();
		self::visit(
			$document->get_elements_data(),
			array(),
			function ( $element, $path ) use ( $wanted, &$found ) {
				if ( isset( $wanted[ $element['id'] ] ) ) {
					$found[ $element['id'] ] = self::summary( $element, $path );
				}
			}
		);
		return array(
			'postId'   => (int) $post_id,
			'elements' => (object) $found,
			'missing'  => array_values( array_diff( array_keys( $wanted ), array_keys( $found ) ) ),
		);
	}

	/**
	 * Change elements' settings.
	 *
	 * @param array $patches Each { id, settings?: object merged over the
	 *                       element's (top-level keys replaced), unset?: keys
	 *                       to remove, remove?: true to delete the element }.
	 * @return array|\WP_Error
	 */
	public static function patch( $post_id, array $patches, $label = '' ) {
		$document = self::document( $post_id );
		if ( is_wp_error( $document ) ) {
			return $document;
		}
		if ( ! $patches || count( $patches ) > self::MAX_PATCHES ) {
			return new \WP_Error( 'figwp_bad_patch', sprintf( 'Send 1 to %d patches.', self::MAX_PATCHES ), array( 'status' => 400 ) );
		}
		$by_id = array();
		foreach ( $patches as $patch ) {
			if ( ! is_array( $patch ) || empty( $patch['id'] ) ) {
				return new \WP_Error( 'figwp_bad_patch', 'Every patch needs an element id.', array( 'status' => 400 ) );
			}
			if ( isset( $patch['settings'] ) && ( ! is_array( $patch['settings'] ) || Importer::is_list( $patch['settings'] ) && $patch['settings'] ) ) {
				return new \WP_Error( 'figwp_bad_patch', 'settings must be an object of Elementor control values.', array( 'status' => 400 ) );
			}
			$by_id[ (string) $patch['id'] ] = $patch;
		}

		$elements = $document->get_elements_data();
		$before   = $elements;
		$changed  = array();
		$elements = self::apply_patches( $elements, $by_id, $changed );
		$missing  = array_values( array_diff( array_keys( $by_id ), $changed ) );
		if ( ! $changed ) {
			return new \WP_Error(
				'figwp_not_found',
				'None of those elements are on this page: ' . implode( ', ', $missing ),
				array(
					'status'  => 404,
					'missing' => $missing,
				)
			);
		}

		$snapshot = self::snapshot( $post_id, $before, $label ? $label : sprintf( 'Before patching %d element(s)', count( $changed ) ) );
		$saved    = self::save( $document, $elements );
		if ( is_wp_error( $saved ) ) {
			return $saved;
		}
		return array(
			'postId'   => (int) $post_id,
			'changed'  => $changed,
			'missing'  => $missing,
			'snapshot' => $snapshot,
			'warning'  => self::lock_warning( $post_id ),
		);
	}

	/**
	 * Replace one element (usually a section) with new Elementor content,
	 * imported the same way as a whole page: widgets checked, ids kept unless
	 * they clash, images copied into the media library.
	 *
	 * @return array|\WP_Error
	 */
	public static function replace( $post_id, $element_id, $element, $label = '' ) {
		$document = self::document( $post_id );
		if ( is_wp_error( $document ) ) {
			return $document;
		}
		if ( ! is_array( $element ) || empty( $element['elType'] ) ) {
			return new \WP_Error( 'figwp_bad_content', 'element must be one Elementor element.', array( 'status' => 400 ) );
		}
		$missing = Importer::missing_element_types( array( $element ) );
		if ( $missing ) {
			return new \WP_Error(
				'figwp_missing_widgets',
				'This site does not have these widgets: ' . implode( ', ', $missing ) . '.',
				array(
					'status'  => 422,
					'missing' => $missing,
				)
			);
		}

		$elements = $document->get_elements_data();
		$before   = $elements;

		// Ids already on the page, outside the element being replaced, must
		// not be reused by the new content.
		$seen = array();
		self::visit(
			$elements,
			array(),
			function ( $el, $path ) use ( $element_id, &$seen ) {
				if ( $el['id'] !== $element_id && ! in_array( $element_id, $path, true ) ) {
					$seen[ $el['id'] ] = true;
				}
			}
		);
		$id_map = array();
		$fresh  = Importer::normalize_ids( array( $element ), $id_map, $seen );

		Importer::adopt_local_images( $fresh );
		$elementor = \Elementor\Plugin::$instance;
		$fresh     = $elementor->db->iterate_data(
			$fresh,
			function ( $element_data ) use ( $elementor, $document ) {
				$instance = $elementor->elements_manager->create_element_instance( $element_data );
				return $instance ? $document->process_element_import_export( $instance, 'on_import' ) : null;
			}
		);
		if ( empty( $fresh[0] ) ) {
			return new \WP_Error( 'figwp_bad_content', 'Elementor could not read that element.', array( 'status' => 400 ) );
		}

		$replaced = false;
		$elements = self::replace_in( $elements, (string) $element_id, $fresh[0], $replaced );
		if ( ! $replaced ) {
			return new \WP_Error( 'figwp_not_found', 'No element with that id on this page.', array( 'status' => 404 ) );
		}

		$snapshot = self::snapshot( $post_id, $before, $label ? $label : 'Before replacing ' . $element_id );
		$saved    = self::save( $document, $elements );
		if ( is_wp_error( $saved ) ) {
			return $saved;
		}

		// Keep verification's record of changed ids complete.
		$meta = get_post_meta( $post_id, Importer::META, true );
		if ( is_array( $meta ) && $id_map ) {
			$meta['id_map'] = array_merge( isset( $meta['id_map'] ) && is_array( $meta['id_map'] ) ? $meta['id_map'] : array(), $id_map );
			update_post_meta( $post_id, Importer::META, $meta );
		}

		return array(
			'postId'       => (int) $post_id,
			'replaced'     => (string) $element_id,
			'elementId'    => $fresh[0]['id'],
			'idMap'        => (object) $id_map,
			'remoteImages' => array_slice( Importer::remote_images( $fresh ), 0, 50 ),
			'snapshot'     => $snapshot,
			'warning'      => self::lock_warning( $post_id ),
		);
	}

	/**
	 * Save a page's whole element tree, as an AI app rewrote it (for example
	 * linked to the kit's global colours). Widgets are checked like an
	 * import; ids must stay as they are.
	 *
	 * @return array|\WP_Error
	 */
	public static function save_content( $post_id, $elements, $label = '' ) {
		$document = self::document( $post_id );
		if ( is_wp_error( $document ) ) {
			return $document;
		}
		if ( ! is_array( $elements ) || ! $elements || ! Importer::is_list( $elements ) ) {
			return new \WP_Error( 'figwp_bad_content', 'elements must be the page\'s list of Elementor elements.', array( 'status' => 400 ) );
		}
		$missing = Importer::missing_element_types( $elements );
		if ( $missing ) {
			return new \WP_Error(
				'figwp_missing_widgets',
				'This site does not have these widgets: ' . implode( ', ', $missing ) . '.',
				array(
					'status'  => 422,
					'missing' => $missing,
				)
			);
		}
		$snapshot = self::snapshot( $post_id, $document->get_elements_data(), $label ? $label : 'Before saving new content' );
		$saved    = self::save( $document, $elements );
		if ( is_wp_error( $saved ) ) {
			return $saved;
		}
		return array(
			'postId'       => (int) $post_id,
			'elementCount' => Importer::count_elements( $elements ),
			'snapshot'     => $snapshot,
			'warning'      => self::lock_warning( $post_id ),
		);
	}

	/** Snapshots, newest first, without their content. */
	public static function list_snapshots( $post_id ) {
		$document = self::document( $post_id );
		if ( is_wp_error( $document ) ) {
			return $document;
		}
		return array(
			'postId'    => (int) $post_id,
			'snapshots' => array_map(
				function ( $s ) {
					return array(
						'id'           => $s['id'],
						'label'        => $s['label'],
						'createdAt'    => gmdate( 'c', $s['at'] ),
						'elementCount' => $s['count'],
					);
				},
				array_reverse( self::snapshots( $post_id ) )
			),
		);
	}

	/**
	 * Put a snapshot back. The current content is snapshotted first, so a
	 * restore can be undone too.
	 *
	 * @return array|\WP_Error
	 */
	public static function restore( $post_id, $snapshot_id ) {
		$document = self::document( $post_id );
		if ( is_wp_error( $document ) ) {
			return $document;
		}
		foreach ( self::snapshots( $post_id ) as $s ) {
			if ( $s['id'] === $snapshot_id ) {
				$elements = json_decode( $s['elements'], true );
				if ( ! is_array( $elements ) ) {
					return new \WP_Error( 'figwp_bad_snapshot', 'That snapshot is damaged.', array( 'status' => 500 ) );
				}
				$current = self::snapshot( $post_id, $document->get_elements_data(), 'Before restoring "' . $s['label'] . '"' );
				$saved   = self::save( $document, $elements );
				if ( is_wp_error( $saved ) ) {
					return $saved;
				}
				return array(
					'postId'   => (int) $post_id,
					'restored' => $snapshot_id,
					'snapshot' => $current,
					'warning'  => self::lock_warning( $post_id ),
				);
			}
		}
		return new \WP_Error( 'figwp_not_found', 'No snapshot with that id. They are kept for the last ' . self::SNAPSHOTS . ' changes.', array( 'status' => 404 ) );
	}

	// ── Helpers ────────────────────────────────────────────────────────────

	/**
	 * Someone else editing the page in WordPress right now (its edit lock).
	 * Elementor saves its whole copy of the page, so their next save would
	 * overwrite this change.
	 */
	public static function lock_warning( $post_id ) {
		if ( ! function_exists( 'wp_check_post_lock' ) ) {
			require_once ABSPATH . 'wp-admin/includes/post.php';
		}
		$user_id = wp_check_post_lock( $post_id );
		if ( ! $user_id ) {
			return null;
		}
		$user = get_userdata( $user_id );
		return sprintf(
			'%s has this page open in the editor. If they save, their copy replaces this change: ask them to close the editor or reload it first.',
			$user ? $user->display_name : 'Another user'
		);
	}

	/** @return \Elementor\Core\Base\Document|\WP_Error */
	private static function document( $post_id ) {
		$post = get_post( (int) $post_id );
		if ( ! $post || ! get_post_meta( $post->ID, Importer::META, true ) ) {
			return new \WP_Error( 'figwp_not_found', 'No FigWP import with that id. Only pages FigWP imported can be edited this way.', array( 'status' => 404 ) );
		}
		if ( ! current_user_can( 'edit_post', $post->ID ) ) {
			return new \WP_Error( 'figwp_forbidden', 'The connected WordPress user cannot edit this page.', array( 'status' => 403 ) );
		}
		$document = \Elementor\Plugin::$instance->documents->get( $post->ID, false );
		if ( ! $document ) {
			return new \WP_Error( 'figwp_not_found', 'Elementor cannot open this page.', array( 'status' => 404 ) );
		}
		return $document;
	}

	private static function save( $document, array $elements ) {
		$saved = $document->save( array( 'elements' => $elements ) );
		if ( ! $saved ) {
			return new \WP_Error( 'figwp_save_failed', 'Elementor could not save the page.', array( 'status' => 500 ) );
		}
		Importer::rebuild_css( $document->get_main_id() );
		return true;
	}

	private static function visit( array $elements, array $path, callable $callback ) {
		foreach ( $elements as $element ) {
			if ( ! is_array( $element ) || empty( $element['id'] ) ) {
				continue;
			}
			$callback( $element, $path );
			if ( ! empty( $element['elements'] ) && is_array( $element['elements'] ) ) {
				self::visit( $element['elements'], array_merge( $path, array( $element['id'] ) ), $callback );
			}
		}
	}

	private static function summary( array $element, array $path ) {
		return array(
			'id'         => $element['id'],
			'elType'     => isset( $element['elType'] ) ? $element['elType'] : null,
			'widgetType' => isset( $element['widgetType'] ) ? $element['widgetType'] : null,
			'settings'   => (object) ( isset( $element['settings'] ) && is_array( $element['settings'] ) ? $element['settings'] : array() ),
			'children'   => array_values(
				array_map(
					function ( $child ) {
						return isset( $child['id'] ) ? $child['id'] : null;
					},
					isset( $element['elements'] ) && is_array( $element['elements'] ) ? $element['elements'] : array()
				)
			),
			'path'       => $path,
		);
	}

	private static function apply_patches( array $elements, array $by_id, array &$changed ) {
		$out = array();
		foreach ( $elements as $element ) {
			$id = isset( $element['id'] ) ? (string) $element['id'] : '';
			if ( isset( $by_id[ $id ] ) ) {
				$patch     = $by_id[ $id ];
				$changed[] = $id;
				if ( ! empty( $patch['remove'] ) ) {
					continue;
				}
				$settings = isset( $element['settings'] ) && is_array( $element['settings'] ) ? $element['settings'] : array();
				if ( ! empty( $patch['settings'] ) ) {
					$settings = array_merge( $settings, $patch['settings'] );
				}
				if ( ! empty( $patch['unset'] ) && is_array( $patch['unset'] ) ) {
					foreach ( $patch['unset'] as $key ) {
						unset( $settings[ (string) $key ] );
					}
				}
				$element['settings'] = $settings;
			}
			if ( ! empty( $element['elements'] ) && is_array( $element['elements'] ) ) {
				$element['elements'] = self::apply_patches( $element['elements'], $by_id, $changed );
			}
			$out[] = $element;
		}
		return $out;
	}

	private static function replace_in( array $elements, $id, array $replacement, &$replaced ) {
		foreach ( $elements as $i => $element ) {
			if ( isset( $element['id'] ) && (string) $element['id'] === $id ) {
				$elements[ $i ] = $replacement;
				$replaced       = true;
				return $elements;
			}
			if ( ! empty( $element['elements'] ) && is_array( $element['elements'] ) ) {
				$elements[ $i ]['elements'] = self::replace_in( $element['elements'], $id, $replacement, $replaced );
				if ( $replaced ) {
					return $elements;
				}
			}
		}
		return $elements;
	}

	private static function snapshots( $post_id ) {
		$list = get_post_meta( $post_id, self::SNAPSHOTS_META, true );
		return is_array( $list ) ? $list : array();
	}

	/** Store the page's elements as a snapshot and return its id. */
	private static function snapshot( $post_id, array $elements, $label ) {
		$list   = self::snapshots( $post_id );
		$id     = strtolower( wp_generate_password( 10, false, false ) );
		$list[] = array(
			'id'       => $id,
			'label'    => mb_substr( (string) $label, 0, 120 ),
			'at'       => time(),
			'count'    => Importer::count_elements( $elements ),
			'elements' => wp_json_encode( $elements ),
		);
		update_post_meta( $post_id, self::SNAPSHOTS_META, wp_slash( array_slice( $list, -self::SNAPSHOTS ) ) );
		return $id;
	}
}
