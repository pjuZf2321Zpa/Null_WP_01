<?php
namespace Essential_Addons_Elementor\Pro\Classes\FigWP;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * REST routes figwp.app calls, under /wp-json/figwp/v1.
 *
 * Every route needs a request signed with this site's FigWP secret. A valid
 * request runs as the WordPress user who connected the site, and each action
 * still checks that user's capabilities.
 */
class Rest_Controller {

	const NAMESPACE_V1 = 'figwp/v1';

	public static function register_routes() {
		$signed = array( __CLASS__, 'authorize' );

		register_rest_route(
			self::NAMESPACE_V1,
			'/status',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'status' ),
				'permission_callback' => $signed,
			)
		);
		register_rest_route(
			self::NAMESPACE_V1,
			'/import',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'import' ),
				'permission_callback' => $signed,
			)
		);
		register_rest_route(
			self::NAMESPACE_V1,
			'/media',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'media' ),
				'permission_callback' => $signed,
			)
		);
		register_rest_route(
			self::NAMESPACE_V1,
			'/pages/(?P<id>\d+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'get_page' ),
				'permission_callback' => $signed,
			)
		);
		register_rest_route(
			self::NAMESPACE_V1,
			'/pages/(?P<id>\d+)/publish',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'publish' ),
				'permission_callback' => $signed,
			)
		);
		register_rest_route(
			self::NAMESPACE_V1,
			'/pages/(?P<id>\d+)/preview',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'preview' ),
				'permission_callback' => $signed,
			)
		);
		register_rest_route(
			self::NAMESPACE_V1,
			'/pages/(?P<id>\d+)/elements',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'elements' ),
				'permission_callback' => $signed,
			)
		);
		register_rest_route(
			self::NAMESPACE_V1,
			'/pages/(?P<id>\d+)/patch',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'patch' ),
				'permission_callback' => $signed,
			)
		);
		register_rest_route(
			self::NAMESPACE_V1,
			'/pages/(?P<id>\d+)/replace',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'replace' ),
				'permission_callback' => $signed,
			)
		);
		register_rest_route(
			self::NAMESPACE_V1,
			'/pages/(?P<id>\d+)/snapshots',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'snapshots' ),
				'permission_callback' => $signed,
			)
		);
		register_rest_route(
			self::NAMESPACE_V1,
			'/pages/(?P<id>\d+)/restore',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'restore' ),
				'permission_callback' => $signed,
			)
		);
		register_rest_route(
			self::NAMESPACE_V1,
			'/pages/(?P<id>\d+)/content',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'save_content' ),
				'permission_callback' => $signed,
			)
		);
		register_rest_route(
			self::NAMESPACE_V1,
			'/design-system',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'design_system' ),
				'permission_callback' => $signed,
			)
		);
		register_rest_route(
			self::NAMESPACE_V1,
			'/widget-schema',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'widget_schema' ),
				'permission_callback' => $signed,
			)
		);
		register_rest_route(
			self::NAMESPACE_V1,
			'/fonts',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'fonts' ),
				'permission_callback' => $signed,
			)
		);
		register_rest_route(
			self::NAMESPACE_V1,
			'/forms',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'forms' ),
				'permission_callback' => $signed,
			)
		);
		register_rest_route(
			self::NAMESPACE_V1,
			'/disconnect',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'disconnect' ),
				'permission_callback' => $signed,
			)
		);
	}

	/**
	 * permission_callback: a valid FigWP signature, then act as the user who
	 * connected the site.
	 *
	 * @return true|\WP_Error
	 */
	public static function authorize( \WP_REST_Request $request ) {
		$connection = Connection::get();
		if ( ! $connection ) {
			return new \WP_Error( 'figwp_not_connected', 'This site is not connected to FigWP.', array( 'status' => 401 ) );
		}

		$verified = Signature::verify( $request, $connection['site_id'], $connection['secret'] );
		if ( is_wp_error( $verified ) ) {
			return $verified;
		}

		$user = get_userdata( (int) $connection['wp_user_id'] );
		if ( ! $user || ! user_can( $user, 'edit_pages' ) ) {
			return new \WP_Error(
				'figwp_user_gone',
				'The WordPress user who connected this site can no longer edit pages. Reconnect the site from an administrator account.',
				array( 'status' => 403 )
			);
		}
		wp_set_current_user( $user->ID );
		return true;
	}

	public static function status() {
		return rest_ensure_response( Site_Profile::build() );
	}

	public static function import( \WP_REST_Request $request ) {
		$params = $request->get_json_params();
		if ( ! is_array( $params ) ) {
			return new \WP_Error( 'figwp_bad_json', 'The request body must be JSON.', array( 'status' => 400 ) );
		}
		$args = array(
			'title'           => $params['title'] ?? '',
			'content'         => $params['content'] ?? null,
			'page_settings'   => $params['pageSettings'] ?? array(),
			'target'          => $params['target'] ?? 'page',
			'template_type'   => $params['templateType'] ?? 'page',
			'page_template'   => $params['pageTemplate'] ?? 'canvas',
			'replace_post_id' => $params['replacePostId'] ?? 0,
			'append_to_post_id' => $params['appendToPostId'] ?? 0,
			'append_key'        => $params['appendKey'] ?? '',
			'source'          => $params['source'] ?? null,
		);

		// Image downloads can take a while on a big page.
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 300 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		}

		return rest_ensure_response( Importer::import( $args ) );
	}

	public static function media( \WP_REST_Request $request ) {
		$params = (array) $request->get_json_params();
		$urls   = isset( $params['urls'] ) && is_array( $params['urls'] ) ? $params['urls'] : array();
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 120 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		}
		return rest_ensure_response( Importer::import_media( $urls ) );
	}

	public static function get_page( \WP_REST_Request $request ) {
		return rest_ensure_response( Importer::get_page( (int) $request['id'] ) );
	}

	public static function publish( \WP_REST_Request $request ) {
		return rest_ensure_response( Importer::publish( (int) $request['id'] ) );
	}

	public static function preview( \WP_REST_Request $request ) {
		return rest_ensure_response( Preview::create( (int) $request['id'] ) );
	}

	public static function elements( \WP_REST_Request $request ) {
		$params = (array) $request->get_json_params();
		$ids    = isset( $params['ids'] ) && is_array( $params['ids'] ) ? array_map( 'strval', $params['ids'] ) : array();
		return rest_ensure_response( Editor::get_elements( (int) $request['id'], $ids ) );
	}

	public static function patch( \WP_REST_Request $request ) {
		$params = (array) $request->get_json_params();
		return rest_ensure_response(
			Editor::patch(
				(int) $request['id'],
				isset( $params['patches'] ) && is_array( $params['patches'] ) ? $params['patches'] : array(),
				isset( $params['label'] ) ? sanitize_text_field( (string) $params['label'] ) : ''
			)
		);
	}

	public static function replace( \WP_REST_Request $request ) {
		$params = (array) $request->get_json_params();
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 300 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		}
		return rest_ensure_response(
			Editor::replace(
				(int) $request['id'],
				isset( $params['elementId'] ) ? (string) $params['elementId'] : '',
				isset( $params['element'] ) ? $params['element'] : null,
				isset( $params['label'] ) ? sanitize_text_field( (string) $params['label'] ) : ''
			)
		);
	}

	public static function snapshots( \WP_REST_Request $request ) {
		return rest_ensure_response( Editor::list_snapshots( (int) $request['id'] ) );
	}

	public static function restore( \WP_REST_Request $request ) {
		$params = (array) $request->get_json_params();
		return rest_ensure_response( Editor::restore( (int) $request['id'], isset( $params['snapshotId'] ) ? (string) $params['snapshotId'] : '' ) );
	}

	public static function save_content( \WP_REST_Request $request ) {
		$params = (array) $request->get_json_params();
		return rest_ensure_response(
			Editor::save_content(
				(int) $request['id'],
				isset( $params['elements'] ) ? $params['elements'] : null,
				isset( $params['label'] ) ? sanitize_text_field( (string) $params['label'] ) : ''
			)
		);
	}

	public static function design_system( \WP_REST_Request $request ) {
		$params = (array) $request->get_json_params();
		return rest_ensure_response(
			Design_System::sync(
				isset( $params['colors'] ) && is_array( $params['colors'] ) ? $params['colors'] : array(),
				isset( $params['typography'] ) && is_array( $params['typography'] ) ? $params['typography'] : array(),
				! isset( $params['dryRun'] ) || false !== $params['dryRun']
			)
		);
	}

	public static function widget_schema( \WP_REST_Request $request ) {
		$params = (array) $request->get_json_params();
		return rest_ensure_response( Widget_Schema::get( isset( $params['type'] ) ? (string) $params['type'] : '' ) );
	}

	public static function fonts( \WP_REST_Request $request ) {
		$params = (array) $request->get_json_params();
		return rest_ensure_response( Site_Profile::fonts( isset( $params['families'] ) && is_array( $params['families'] ) ? $params['families'] : array() ) );
	}

	public static function forms() {
		return rest_ensure_response( Forms::inventory() );
	}

	/** figwp.app removed this site; forget the connection here too. */
	public static function disconnect() {
		Connection::forget();
		return rest_ensure_response( array( 'disconnected' => true ) );
	}
}
