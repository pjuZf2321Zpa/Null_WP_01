<?php
/**
 * WIDGET component.
 *
 * @package     Astra Builder
 * @link        https://www.brainstormforce.com
 * @since       Astra 3.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

define( 'ASTRA_BUILDER_HEADER_WIDGET_DIR', ASTRA_THEME_DIR . 'inc/builder/type/header/widget' );
define( 'ASTRA_BUILDER_HEADER_WIDGET_URI', ASTRA_THEME_URI . 'inc/builder/type/header/widget' );

/**
 * Heading Initial Setup
 *
 * @since 3.0.0
 */
class Astra_Header_Widget_Component {
	/**
	 * Constructor function that initializes required actions and hooks
	 */
	public function __construct() {

		// @codingStandardsIgnoreStart WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
		// Include front end files.
		if ( ! is_admin() || Astra_Builder_Customizer::astra_collect_customizer_builder_data() ) {
			require_once ASTRA_BUILDER_HEADER_WIDGET_DIR . '/dynamic-css/dynamic.css.php';
		}
		// @codingStandardsIgnoreEnd WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
	}
}

/**
 *  Kicking this off by creating an object.
 */
new Astra_Header_Widget_Component();
