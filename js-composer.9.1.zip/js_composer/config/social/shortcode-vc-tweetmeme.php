<?php
/**
 * Configuration file for [vc_tweetmeme] shortcode of 'X button' element.
 *
 * @see https://kb.wpbakery.com/docs/inner-api/vc_map/ for more detailed information about element attributes.
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$params = [
	[
		'type' => 'dropdown',
		'param_name' => 'type',
		'heading' => esc_html__( 'Type', 'js_composer' ),
		'value' => [
			esc_html__( 'Share', 'js_composer' ) => 'share',
			esc_html__( 'Follow', 'js_composer' ) => 'follow',
			esc_html__( 'Hashtag', 'js_composer' ) => 'hashtag',
			esc_html__( 'Mention', 'js_composer' ) => 'mention',
		],
		'description' => esc_html__( 'Select type of X button.', 'js_composer' ),
		'section' => 'content',
	],
	// Mention type.
	[
		'type' => 'textfield',
		'heading' => esc_html__( 'X post to @', 'js_composer' ),
		'param_name' => 'mention_tweet_to',
		'value' => '',
		'dependency' => [
			'element' => 'type',
			'value' => 'mention',
		],
		'description' => esc_html__( 'Enter username where you want to send your X post.', 'js_composer' ),
		'section' => 'content',
	],
	[
		'type' => 'toggle',
		'heading' => esc_html__( 'Add default text', 'js_composer' ),
		'param_name' => 'mention_no_default',
		'value' => [ esc_html__( 'Yes', 'js_composer' ) => 'add' ],
		'settings' => [
			'default' => '',
		],
		'dependency' => [
			'element' => 'type',
			'value' => 'mention',
		],
		'description' => esc_html__( 'Add default text to the X post?', 'js_composer' ),
		'section' => 'content',
	],
	[
		'type' => 'textfield',
		'heading' => esc_html__( 'Default text', 'js_composer' ),
		'param_name' => 'mention_custom_tweet_text',
		'value' => '',
		'dependency' => [
			'element' => 'mention_no_default',
			'value' => 'add',
		],
		'description' => esc_html__( 'Enter default text for the X post.', 'js_composer' ),
		'section' => 'content',
	],
	[
		'type' => 'textfield',
		'heading' => esc_html__( 'Recommend @', 'js_composer' ),
		'param_name' => 'mention_recommend_1',
		'value' => '',
		'edit_field_class' => 'vc_col-xs-6',
		'dependency' => [
			'element' => 'type',
			'value' => 'mention',
		],
		'description' => esc_html__( 'Enter username to recommend.', 'js_composer' ),
		'section' => 'content',
	],
	[
		'type' => 'textfield',
		'heading' => esc_html__( 'Recommend @', 'js_composer' ),
		'param_name' => 'mention_recommend_2',
		'value' => '',
		'edit_field_class' => 'vc_col-xs-6',
		'dependency' => [
			'element' => 'type',
			'value' => 'mention',
		],
		'description' => esc_html__( 'Enter username to recommend.', 'js_composer' ),
		'section' => 'content',
	],
	// Hashtag type.
	[
		'type' => 'textfield',
		'heading' => esc_html__( 'Hashtag #', 'js_composer' ),
		'param_name' => 'hashtag_hash',
		'value' => '',
		'dependency' => [
			'element' => 'type',
			'value' => 'hashtag',
		],
		'description' => esc_html__( 'Add hashtag to an X post using the hashtags parameter.', 'js_composer' ),
		'section' => 'content',
	],
	[
		'type' => 'toggle',
		'heading' => esc_html__( 'Add default text', 'js_composer' ),
		'param_name' => 'hashtag_no_default',
		'value' => [ esc_html__( 'Yes', 'js_composer' ) => 'add' ],
		'settings' => [
			'default' => '',
		],
		'dependency' => [
			'element' => 'type',
			'value' => 'hashtag',
		],
		'description' => esc_html__( 'Add default text to the X post?', 'js_composer' ),
		'section' => 'content',
	],
	[
		'type' => 'textfield',
		'heading' => esc_html__( 'Default text', 'js_composer' ),
		'param_name' => 'hashtag_custom_tweet_text',
		'value' => '',
		'dependency' => [
			'element' => 'hashtag_no_default',
			'value' => 'add',
		],
		'description' => esc_html__( 'Enter default text for the X post.', 'js_composer' ),
		'section' => 'content',
	],
	[
		'type' => 'textfield',
		'heading' => esc_html__( 'Recommend @', 'js_composer' ),
		'param_name' => 'hashtag_recommend_1',
		'value' => '',
		'edit_field_class' => 'vc_col-xs-6',
		'dependency' => [
			'element' => 'type',
			'value' => 'hashtag',
		],
		'description' => esc_html__( 'Enter username to be recommended.', 'js_composer' ),
		'section' => 'content',
	],
	[
		'type' => 'textfield',
		'heading' => esc_html__( 'Recommend @', 'js_composer' ),
		'param_name' => 'hashtag_recommend_2',
		'value' => '',
		'edit_field_class' => 'vc_col-xs-6',
		'dependency' => [
			'element' => 'type',
			'value' => 'hashtag',
		],
		'description' => esc_html__( 'Enter username to be recommended.', 'js_composer' ),
		'section' => 'content',
	],
	[
		'type' => 'toggle',
		'heading' => esc_html__( 'Add custom URL', 'js_composer' ),
		'param_name' => 'hashtag_no_url',
		'value' => [ esc_html__( 'Yes', 'js_composer' ) => 'add' ],
		'settings' => [
			'default' => '',
		],
		'dependency' => [
			'element' => 'type',
			'value' => 'hashtag',
		],
		'description' => esc_html__( 'Add a custom URL to the X post?', 'js_composer' ),
		'section' => 'content',
	],
	[
		'type' => 'link',
		'heading' => esc_html__( 'Custom URL', 'js_composer' ),
		'param_name' => 'hashtag_custom_tweet_url',
		'dependency' => [
			'element' => 'hashtag_no_url',
			'value' => 'add',
		],
		'description' => esc_html__( 'Enter custom URL to be used in the X post.', 'js_composer' ),
		'section' => 'content',
	],
	// Follow type.
	[
		'type' => 'textfield',
		'heading' => esc_html__( 'User @', 'js_composer' ),
		'param_name' => 'follow_user',
		'value' => '',
		'dependency' => [
			'element' => 'type',
			'value' => 'follow',
		],
		'description' => esc_html__( 'Enter username to follow.', 'js_composer' ),
		'section' => 'content',
	],
	[
		'type' => 'toggle',
		'heading' => esc_html__( 'Show username', 'js_composer' ),
		'param_name' => 'follow_show_username',
		'value' => [ esc_html__( 'Yes', 'js_composer' ) => 'yes' ],
		'settings' => [
			'default' => 'yes',
		],
		'edit_field_class' => 'vc_col-xs-6',
		'dependency' => [
			'element' => 'type',
			'value' => 'follow',
		],
		'description' => esc_html__( 'Do you want to show username in button?', 'js_composer' ),
		'section' => 'content',
	],
	[
		'type' => 'toggle',
		'heading' => esc_html__( 'Show followers count', 'js_composer' ),
		'param_name' => 'show_followers_count',
		'value' => [ esc_html__( 'Yes', 'js_composer' ) => 'yes' ],
		'settings' => [
			'default' => '',
		],
		'edit_field_class' => 'vc_col-xs-6',
		'dependency' => [
			'element' => 'type',
			'value' => 'follow',
		],
		'description' => esc_html__( 'Do you want to display the follower count in button?', 'js_composer' ),
		'section' => 'content',
	],
	// Share type.
	[
		'type' => 'toggle',
		'heading' => esc_html__( 'Share custom URL', 'js_composer' ),
		'param_name' => 'share_use_page_url',
		'value' => [ esc_html__( 'Yes', 'js_composer' ) => 'use_custom' ],
		'settings' => [
			'default' => '',
		],
		'edit_field_class' => 'vc_col-xs-6',
		'dependency' => [
			'element' => 'type',
			'value' => 'share',
		],
		'description' => esc_html__( 'Share a custom URL instead of the current page URL?', 'js_composer' ),
		'section' => 'content',
	],
	[
		'type' => 'toggle',
		'heading' => esc_html__( 'Share custom title', 'js_composer' ),
		'param_name' => 'share_text_page_title',
		'value' => [ esc_html__( 'Yes', 'js_composer' ) => 'use_custom' ],
		'settings' => [
			'default' => '',
		],
		'edit_field_class' => 'vc_col-xs-6',
		'dependency' => [
			'element' => 'type',
			'value' => 'share',
		],
		'description' => esc_html__( 'Share a custom title instead of the page title?', 'js_composer' ),
		'section' => 'content',
	],
	[
		'type' => 'link',
		'heading' => esc_html__( 'Custom URL', 'js_composer' ),
		'param_name' => 'share_use_custom_url',
		'dependency' => [
			'element' => 'share_use_page_url',
			'value' => 'use_custom',
		],
		'description' => esc_html__( 'Enter custom page URL to share on X.', 'js_composer' ),
		'section' => 'content',
	],
	[
		'type' => 'textfield',
		'heading' => esc_html__( 'Custom text', 'js_composer' ),
		'param_name' => 'share_text_custom_text',
		'value' => '',
		'dependency' => [
			'element' => 'share_text_page_title',
			'value' => 'use_custom',
		],
		'description' => esc_html__( 'Enter the text to be used as an X post.', 'js_composer' ),
		'section' => 'content',
	],
	[
		'type' => 'textfield',
		'heading' => esc_html__( 'Via @', 'js_composer' ),
		'param_name' => 'share_via',
		'value' => '',
		'edit_field_class' => 'vc_col-xs-6',
		'dependency' => [
			'element' => 'type',
			'value' => 'share',
		],
		'description' => esc_html__( 'Enter your X username.', 'js_composer' ),
		'section' => 'content',
	],
	[
		'type' => 'textfield',
		'heading' => esc_html__( 'Recommend @', 'js_composer' ),
		'param_name' => 'share_recommend',
		'value' => '',
		'edit_field_class' => 'vc_col-xs-6',
		'dependency' => [
			'element' => 'type',
			'value' => 'share',
		],
		'description' => esc_html__( 'Enter the X username to be recommended.', 'js_composer' ),
		'section' => 'content',
	],
	[
		'type' => 'textfield',
		'heading' => esc_html__( 'Hashtag #', 'js_composer' ),
		'param_name' => 'share_hashtag',
		'value' => '',
		'dependency' => [
			'element' => 'type',
			'value' => 'share',
		],
		'description' => esc_html__( 'Add a comma-separated list of hashtags to an X post using the hashtags parameter.', 'js_composer' ),
		'section' => 'content',
	],
	// General settings shared across all types.
	[
		'type' => 'toggle',
		'heading' => esc_html__( 'Use large button', 'js_composer' ),
		'param_name' => 'large_button',
		'value' => [ esc_html__( 'Yes', 'js_composer' ) => 'yes' ],
		'settings' => [
			'default' => '',
		],
		'edit_field_class' => 'vc_col-xs-6',
		'description' => esc_html__( 'Do you like to display a larger X button?', 'js_composer' ),
		'section' => 'general',
	],
	[
		'type' => 'toggle',
		'heading' => esc_html__( 'Opt-out of tailoring', 'js_composer' ),
		'param_name' => 'disable_tailoring',
		'value' => [ esc_html__( 'Yes', 'js_composer' ) => 'yes' ],
		'settings' => [
			'default' => '',
		],
		'edit_field_class' => 'vc_col-xs-6',
		'description' => esc_html__( 'Tailored suggestions make building a great timeline. Would you like to disable this feature?', 'js_composer' ),
		'section' => 'general',
	],
	[
		'type' => 'dropdown',
		'heading' => esc_html__( 'Language', 'js_composer' ),
		'param_name' => 'lang',
		'value' => [
			'Automatic' => '',
			'French - français' => 'fr',
			'English' => 'en',
			'Arabic - العربية' => 'ar',
			'Japanese - 日本語' => 'ja',
			'Spanish - Español' => 'es',
			'German - Deutsch' => 'de',
			'Italian - Italiano' => 'it',
			'Indonesian - Bahasa Indonesia' => 'id',
			'Portuguese - Português' => 'pt',
			'Korean - 한국어' => 'ko',
			'Turkish - Türkçe' => 'tr',
			'Russian - Русский' => 'ru',
			'Dutch - Nederlands' => 'nl',
			'Filipino - Filipino' => 'fil',
			'Malay - Bahasa Melayu' => 'msa',
			'Traditional Chinese - 繁體中文' => 'zh-tw',
			'Simplified Chinese - 简体中文' => 'zh-cn',
			'Hindi - हिन्दी' => 'hi',
			'Norwegian - Norsk' => 'no',
			'Swedish - Svenska' => 'sv',
			'Finnish - Suomi' => 'fi',
			'Danish - Dansk' => 'da',
			'Polish - Polski' => 'pl',
			'Hungarian - Magyar' => 'hu',
			'Farsi - فارسی' => 'fa',
			'Hebrew - עִבְרִית' => 'he',
			'Urdu - اردو' => 'ur',
			'Thai - ภาษาไทย' => 'th',
		],
		'description' => esc_html__( 'Select button display language or allow it to be automatically defined by user preferences.', 'js_composer' ),
		'section' => 'general',
	],
];
$params = vc_config()->attach_deprecated_default( $params );

return [
	'name' => esc_html__( 'X button', 'js_composer' ),
	'base' => 'vc_tweetmeme',
	'icon' => 'icon-wpb-tweetme',
	'element_default_class' => 'wpb_content_element',
	'category' => esc_html__( 'Social', 'js_composer' ),
	'description' => esc_html__( 'X post button', 'js_composer' ),
	'params' => vc_config()->merge_default_params(
		$params,
		[ 'margin-bottom' => '35px' ],
		[ 'background_style_default' => 'no-repeat' ]
	),
	'sections' => array_merge(
		[ 'content', 'general' ],
		vc_config()->get_advanced_sections()
	),
];
