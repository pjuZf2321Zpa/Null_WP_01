<?php
/**
 * Class that handles specific [vc_copyright] shortcode.
 *
 * @see js_composer/include/templates/shortcodes/vc_copyright.php
 *
 * @since 8.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/**
 * Class WPBakeryShortCode_Vc_Copyright
 *
 * @since 8.0
 */
class WPBakeryShortCode_Vc_Copyright extends WPBakeryShortCode {
	/**
	 * Template variables.
	 *
	 * @var array
	 * @since 8.0
	 */
	protected array $template_vars = [];

	/**
	 * Build templates vars where we are keeping element optionality
	 *
	 * @since 8.0
	 *
	 * @param array $atts
	 * @throws Exception
	 */
	public function buildTemplate( $atts ) {
		$output = [];
		$inline_css = [];

		$output['css-class'] = $this->get_element_wrapper_classes( 'wpb-copyright', $atts );

		if ( isset( $atts['style'] ) && 'custom' === $atts['style'] ) {
			if ( ! empty( $atts['custom_background'] ) ) {
				$inline_css[] = vc_get_css_color( 'background-color', $atts['custom_background'] );
			}
		}

		$output['inline-css'] = $inline_css;

		$this->template_vars = $output;
	}

	/**
	 * Get certain template variable value.
	 *
	 * @since 8.0
	 *
	 * @param string $var_name
	 * @return mixed|string
	 */
	public function getTemplateVariable( $var_name ) {
		if ( isset( $this->template_vars[ $var_name ] ) ) {
			return $this->template_vars[ $var_name ];
		}

		return '';
	}
}
