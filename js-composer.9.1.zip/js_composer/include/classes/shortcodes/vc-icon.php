<?php
/**
 * Class that handles specific [vc_icon] shortcode.
 *
 * @see js_composer/include/templates/shortcodes/vc_icon.php
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/**
 * Class WPBakeryShortCode_Vc_Icon
 *
 * @since 4.4
 */
class WPBakeryShortCode_Vc_Icon extends WPBakeryShortCode {
	/**
	 * Get CSS file names for vc_icon shortcode.
	 *
	 * @since 9.0
	 * @return string|array
	 */
	public function get_shortcode_css_files() {
		return [ 'vc_icon_element' ];
	}

	/**
	 * Get title without the default element icon.
	 *
	 * @param string $title
	 *
	 * @since 9.1
	 * @return string
	 */
	protected function outputTitle( $title ) {
		return vc_get_template( 'editors/partials/backend_empty_element_image_container.tpl.php', [
			'title_html' => '<div class="wpb_element_title_container">' . vc_get_template( 'editors/partials/backend_element_title.tpl.php', [
				'title' => $title,
			] ) . $this->admin_labels . '</div>',
		] );
	}
}
