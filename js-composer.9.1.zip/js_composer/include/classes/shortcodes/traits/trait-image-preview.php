<?php
/**
 * Shared backend image preview helpers.
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/**
 * Shared backend image preview helpers.
 */
trait Image_Preview {
	/**
	 * Get images preview html.
	 *
	 * @param array $image_ids
	 * @param string $param_name
	 * @return string
	 */
	protected function images_preview_html( $image_ids, $param_name ) {
		$output = '<div class="wpb_element_image_container"><ul class="attachment-thumbnails' . ( empty( $image_ids ) ? ' image-exists' : '' ) . '" data-name="' . esc_attr( $param_name ) . '">';
		foreach ( $image_ids as $image_id ) {
			$img = wpb_getImageBySize( [
				'attach_id' => (int) $image_id,
				'thumb_size' => 'thumbnail',
			] );
			$output .= '<li>' . ( $img ? $img['thumbnail'] : '<img width="150" height="150" src="' . esc_url( vc_asset_url( 'vc/blank.gif' ) ) . '" class="attachment-thumbnail" alt="" title="" />' ) . '</li>';
		}
		$output .= '</ul><a href="#" class="column_edit_trigger' . ( ! empty( $image_ids ) ? ' image-exists' : '' ) . '"><span class="no_image_image vc-composer-icon vc-c-images"></span></a></div>';

		return $output;
	}

	// phpcs:disable Generic.CodeAnalysis.UnusedFunctionParameter.Found
	/**
	 * Hide the default title because image params render the backend title.
	 *
	 * @param string $title
	 * @return string
	 */
	protected function add_element_image_container( $title ) {
		return '';
	}
	// phpcs:enable Generic.CodeAnalysis.UnusedFunctionParameter.Found

	/**
	 * Get title html output.
	 *
	 * @param string $title
	 * @param bool $has_images
	 * @return string
	 */
	protected function output_title_true( $title, $has_images = false ) {
		return $this->settings( 'logo' ) . '<div class="wpb_element_title_container">' . vc_get_template( 'editors/partials/backend_element_title.tpl.php', [
			'title' => $title,
			'title_classes' => $has_images ? ' image-exists' : '',
		] ) . '</div>';
	}
}
