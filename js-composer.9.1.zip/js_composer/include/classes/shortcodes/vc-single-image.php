<?php
/**
 * Class that handles specific [vc_single_image] shortcode.
 *
 * @see js_composer/include/templates/shortcodes/vc_single_image.php
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/**
 * Class WPBakeryShortCode_Vc_Single_image
 */
class WPBakeryShortCode_Vc_Single_Image extends WPBakeryShortCode {
	const ADMIN_LABELS_PLACEHOLDER = '<!-- wpb-single-image-admin-labels -->';

	/**
	 * Admin labels rendered inside the title container.
	 *
	 * @var string
	 */
	protected $admin_labels = '';

	/**
	 * Whether all param holders are currently being rendered.
	 *
	 * @var bool
	 */
	protected $rendering_params_html_holders = false;

	/**
	 * WPBakeryShortCode_Vc_Single_image constructor.
	 *
	 * @param array $settings
	 */
	public function __construct( $settings ) {
		parent::__construct( $settings );

		$this->jsScripts();
	}

	/**
	 * Register scripts.
	 */
	public function jsScripts() {
		wp_register_script( 'zoom', vc_asset_url( 'lib/vendor/dist/jquery-zoom/jquery.zoom.min.js' ), [ 'jquery-core' ], WPB_VC_VERSION, true );

		wp_register_script( 'vc_image_zoom', vc_asset_url( 'lib/vc/vc_image_zoom/vc_image_zoom.min.js' ), [
			'jquery-core',
			'zoom',
		], WPB_VC_VERSION, true );
	}

	/**
	 * Render params and move admin labels into the title container.
	 *
	 * @since 9.1
	 * @param array $atts Shortcode attributes.
	 * @return string Param holder HTML with admin labels injected into the title container.
	 */
	protected function paramsHtmlHolders( $atts ) {
		$this->admin_labels = '';
		$this->rendering_params_html_holders = true;

		try {
			$inner = parent::paramsHtmlHolders( $atts );
		} finally {
			$this->rendering_params_html_holders = false;
		}

		return str_replace( self::ADMIN_LABELS_PLACEHOLDER, $this->admin_labels, $inner );
	}

	/**
	 * Add params html holders.
	 *
	 * @since 9.1
	 * @param array  $param Param settings.
	 * @param string $value Param value.
	 * @return string Param holder HTML.
	 */
	public function singleParamHtmlHolder( $param, $value ) { // phpcs:ignore:Generic.Metrics.CyclomaticComplexity.TooHigh, CognitiveComplexity.Complexity.MaximumComplexity.TooHigh
		$output = '';
		// Compatibility fixes.
		$old_names = [
			'yellow_message',
			'blue_message',
			'green_message',
			'button_green',
			'button_grey',
			'button_yellow',
			'button_blue',
			'button_red',
			'button_orange',
		];
		$new_names = [
			'alert-block',
			'alert-info',
			'alert-success',
			'btn-success',
			'btn',
			'btn-info',
			'btn-primary',
			'btn-danger',
			'btn-warning',
		];
		$value = str_ireplace( $old_names, $new_names, $value );

		$param_name = $param['param_name'] ?? '';
		$type = $param['type'] ?? '';
		$class = $param['class'] ?? '';

		if ( 'attach_image' === $param['type'] && 'image' === $param_name ) {
			$output .= WPB_Form_Field_Hidden::get([
				'name' => $param_name,
				'value' => $value,
				'classes' => 'wpb_vc_param_value ' . $param_name . ' ' . $type . ' ' . $class,
			]);
			$element_icon = $this->settings( 'icon' );
			$img = wpb_getImageBySize( [
				'attach_id' => $this->parseImageValue( $value ),
				'thumb_size' => 'thumbnail',
			] );
			$thumbnail = $img ? $this->addImageDataName( $img['thumbnail'], $param_name ) : '<div class="wpb_element_image_container"><img width="150" height="150" src="' . esc_url( vc_asset_url( 'vc/blank.gif' ) ) . '" class="attachment-thumbnail vc_general vc_element-icon"  data-name="' . $param_name . '" alt="" title="" style="display: none;" />';
			$this->setSettings( 'logo', $thumbnail . '<a href="#" class="column_edit_trigger"><span class="no_image_image vc-composer-icon vc-c-images' . ( ! empty( $element_icon ) ? ' ' . $element_icon : '' ) . '"></span></a></div>' );
			$output .= $this->outputTitleTrue( $this->settings['name'] );
		} elseif ( ! empty( $param['holder'] ) ) {
			if ( 'input' === $param['holder'] ) {
				$output .= '<' . $param['holder'] . ' readonly="true" class="wpb_vc_param_value ' . $param_name . ' ' . $type . ' ' . $class . '" name="' . $param_name . '" value="' . $value . '">';
			} elseif ( in_array( $param['holder'], [
				'img',
				'iframe',
			], true ) ) {
				$output .= '<' . $param['holder'] . ' class="wpb_vc_param_value ' . $param_name . ' ' . $type . ' ' . $class . '" name="' . $param_name . '" src="' . esc_url( $value ) . '">';
			} elseif ( 'hidden' !== $param['holder'] ) {
				$output .= '<' . $param['holder'] . ' class="wpb_vc_param_value ' . $param_name . ' ' . $type . ' ' . $class . '" name="' . $param_name . '">' . $value . '</' . $param['holder'] . '>';
			}
		}

		$this->addAdminLabel( $param, $value );

		if ( ! $this->rendering_params_html_holders ) {
			$output = str_replace( self::ADMIN_LABELS_PLACEHOLDER, $this->admin_labels, $output );
		}

		return $output;
	}

	/**
	 * Collect admin labels for title container output.
	 *
	 * @param array $param
	 * @param string $value
	 */
	protected function addAdminLabel( $param, $value ) {
		if ( empty( $param['admin_label'] ) || true !== $param['admin_label'] ) {
			return;
		}

		$param_name = $param['param_name'] ?? '';

		if ( 'image' === $param_name ) {
			$this->addAdminLabelHtml( $param_name, $this->getImageMetadataLabel( $this->parseImageValue( $value ) ) );
			return;
		}

		$label = '<label>' . esc_html( $param['heading'] ) . '</label>: ';
		$this->addAdminLabelHtml( $param_name, $value, $label );
	}

	/**
	 * Add admin label html.
	 *
	 * @param string $param_name
	 * @param string $value
	 * @param string $label
	 */
	protected function addAdminLabelHtml( $param_name, $value, $label = '' ) {
		$this->admin_labels .= '<span class="vc_admin_label admin_label_' . esc_attr( $param_name ) . ( empty( $value ) ? ' hidden-label' : '' ) . '">' . $label . esc_html( $value ) . '</span>';
	}

	/**
	 * Add data-name attribute to image preview.
	 *
	 * @param string $thumbnail
	 * @param string $param_name
	 * @return string
	 */
	protected function addImageDataName( $thumbnail, $param_name ) {
		return str_replace( '<img ', '<div class="wpb_element_image_container"><img data-name="' . esc_attr( $param_name ) . '" ', $thumbnail );
	}

	/**
	 * Parse image field value into an attachment ID.
	 *
	 * @param string $value
	 * @return int
	 */
	protected function parseImageValue( $value ) {
		$decoded = json_decode( stripslashes( $value ), true );

		if ( is_array( $decoded ) ) {
			return (int) array_key_first( $decoded );
		}

		return (int) preg_replace( '/[^\d]/', '', $value );
	}

	/**
	 * Get image metadata label.
	 *
	 * @param int $attachment_id
	 * @return string
	 */
	protected function getImageMetadataLabel( $attachment_id ) {
		return wpb_get_image_metadata_label( $attachment_id );
	}

	/**
	 * Set image square size.
	 *
	 * @param int $img_id
	 * @param string|array $img_size
	 * @return string
	 */
	public function getImageSquareSize( $img_id, $img_size ) {
		if ( preg_match_all( '/(\d+)x(\d+)/', $img_size, $sizes ) ) {
			$exact_size = [
				'width' => $sizes[1][0],
				'height' => $sizes[2][0],
			];
		} else {
			$image_downsize = image_downsize( $img_id, $img_size );
			$exact_size = [
				'width' => $image_downsize[1],
				'height' => $image_downsize[2],
			];
		}
		$exact_size_int_w = (int) $exact_size['width'];
		$exact_size_int_h = (int) $exact_size['height'];
		if ( $exact_size_int_w !== $exact_size_int_h ) {
			$img_size = $exact_size_int_w > $exact_size_int_h ? $exact_size['height'] . 'x' . $exact_size['height'] : $exact_size['width'] . 'x' . $exact_size['width'];
		}

		return $img_size;
	}

	/**
	 * Get title.
	 *
	 * @param string $title
	 * @return string
	 */
	protected function outputTitle( $title ) {
		return '';
	}

	/**
	 * Get title html output.
	 *
	 * @since 9.1
	 * @param string $title Element title.
	 * @return string Element title HTML with the Single Image preview and admin-label placeholder.
	 */
	protected function outputTitleTrue( $title ) {
		return $this->settings( 'logo' ) . '<div class="wpb_element_title_container">' . vc_get_template( 'editors/partials/backend_element_title.tpl.php', [
			'title' => $title,
		] ) . self::ADMIN_LABELS_PLACEHOLDER . '</div>';
	}

	/**
	 * Get CSS file names for vc_single_image shortcode.
	 *
	 * @since 9.0
	 * @return string|array
	 */
	public function get_shortcode_css_files() {
		return [ 'vc_single_image', 'vc_zoom' ];
	}
}
