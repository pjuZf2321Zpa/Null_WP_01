<?php
/**
 * Class that handles specific [vc_gitem_row] shortcode.
 *
 * @see js_composer/include/templates/shortcodes/vc_row.php
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

require_once vc_path_dir( 'SHORTCODES_DIR', 'vc-row.php' );

/**
 * Class WPBakeryShortCode_Vc_Gitem_Row
 */
class WPBakeryShortCode_Vc_Gitem_Row extends WPBakeryShortCode_Vc_Row {
	/**
	 * Get layout control buttons.
	 *
	 * @return string
	 */
	public function getLayoutsControl() {
		global $vc_row_layouts;
		$controls_layout = '<span class="vc_row_layouts vc_control" title="' . esc_attr__( 'Select row layout', 'js_composer' ) . '">';
		$controls_layout .= '<i class="vc-composer-icon vc-c-layout"></i>';
		$controls_layout .= '<span class="vc_row_layouts-dropdown" role="menu">';
		foreach ( array_slice( $vc_row_layouts, 0, 4 ) as $layout ) {
			$controls_layout .= '<a href="#" class="vc_control-set-column set_columns" data-cells="' . esc_attr( $layout['cells'] ) . '" data-cells-mask="' . esc_attr( $layout['mask'] ) . '" title="' . esc_attr( $layout['title'] ) . '" role="menuitem"><i class="vc-composer-icon vc-c-icon-' . esc_attr( $layout['icon_class'] ) . '"></i></a>';
		}
		$controls_layout .= '</span>';
		$controls_layout .= '</span>';

		return $controls_layout;
	}
}
