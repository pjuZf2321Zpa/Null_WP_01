<?php
/**
 * Service for element assets.
 *
 * @since 9.1
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/**
 * Class Wpb_Element_Assets_Service
 *
 * Reads the CSS/JS asset entries declared in a shortcode's element config
 * (a single URL string or an array of URL/handle/deps/media/args) and
 * registers them with WordPress via wp_enqueue_style()/wp_enqueue_script().
 *
 * @since 9.1
 */
class Wpb_Element_Assets_Service {
	/**
	 * CSS config name.
	 *
	 * @since 9.1
	 * @var string
	 */
	public string $css_config_name;

	/**
	 * JS config name.
	 *
	 * @since 9.1
	 * @var string
	 */
	public string $js_config_name;

	/**
	 * Wpb_Element_Assets_Service constructor.
	 *
	 * @param string $css_config_name
	 * @param string $js_config_name
	 *
	 * @since 9.1
	 */
	public function __construct( string $css_config_name, string $js_config_name ) {
		$this->css_config_name = $css_config_name;
		$this->js_config_name = $js_config_name;
	}

	/**
	 * Process element assets.
	 *
	 * @param array $element
	 * @since 9.1
	 */
	public function process_element_assets( array $element ) {
		if ( ! empty( $element[ $this->css_config_name ] ) ) {
			$this->process_element_asset_type( 'css', $element[ $this->css_config_name ] );
		}
		if ( ! empty( $element[ $this->js_config_name ] ) ) {
			$this->process_element_asset_type( 'js', $element[ $this->js_config_name ] );
		}
	}

	/**
	 * Process element asset type.
	 *
	 * @param string $type
	 * @param mixed $asset_init_data
	 * @since 9.1
	 */
	public function process_element_asset_type( string $type, $asset_init_data ) {
		if ( ! is_string( $asset_init_data ) && ! is_array( $asset_init_data ) ) {
			return;
		}

		$asset_data['type'] = $type;

		if ( is_string( $asset_init_data ) ) {
			$asset_data['url'] = $asset_init_data;
			$this->enqueue_single_asset( $asset_data );
			return;
		}

		// process 2 types of arrays
		// ['foo.com', 'bar.com]
		// [['url' => 'foo.com'], [url => 'bar.com', 'deps' => 'jquery']]
		// full list of params for second type see in wp_enqueue_style and wp_enqueue_script.
		foreach ( $asset_init_data as $data ) {
			if ( is_string( $data ) ) {
				$asset_data['url'] = $data;
				$this->enqueue_single_asset( $asset_data );
				continue;
			}

			if ( is_array( $data ) ) {
				$data['type'] = $type;
				$this->enqueue_single_asset( $data );
			}
		}
	}

	/**
	 * Enqueue single external addon asset.
	 *
	 * @param array $asset_data Asset data containing at least 'type' and 'url'.
	 *
	 * @since 9.1
	 */
	public function enqueue_single_asset( array $asset_data ): void {
		if ( ! isset( $asset_data['type'], $asset_data['url'] ) ) {
			return;
		}

		$type            = $asset_data['type'];
		$url             = $asset_data['url'];

		$this->enqueue_single_asset_with_wp_engine( $type, $url, $asset_data );
	}

	/**
	 * Enqueue a single asset via WordPress enqueue functions.
	 *
	 * @param string $type       Asset type, either 'js' or 'css'.
	 * @param string $url        Asset URL.
	 * @param array  $asset_data Asset data used to derive enqueue options.
	 *
	 * @since 9.1
	 */
	public function enqueue_single_asset_with_wp_engine( string $type, string $url, array $asset_data ): void {
		$options = $this->extract_asset_options( $asset_data, $type );

		if ( 'js' === $type ) {
			wp_enqueue_script( $options['handle'], $url, $options['deps'], WPB_VC_VERSION, $options['args'] );
		} elseif ( 'css' === $type ) {
			wp_enqueue_style( $options['handle'], $url, $options['deps'], WPB_VC_VERSION, $options['media'] );
		}
	}

	/**
	 * Extract asset enqueue arguments from the shortcode configuration settings
	 *
	 * @param array $asset Asset data from the shortcode configuration.
	 * @param string $type
	 *
	 * @return array
	 * @since 9.1
	 */
	private function extract_asset_options( array $asset, string $type ): array {
		$default_handle = md5( $asset['url'] );
		if ( 'css' === $type ) {
			$default_handle = $this->css_config_name . '_' . $default_handle;
		} elseif ( 'js' === $type ) {
			$default_handle = $this->js_config_name . '_' . $default_handle;
		}

		return [
			'deps'   => $asset['deps'] ?? [],
			'args'   => $asset['args'] ?? [],
			'media'  => $asset['media'] ?? 'all',
			'handle' => $asset['handle'] ?? $default_handle,
		];
	}
}
