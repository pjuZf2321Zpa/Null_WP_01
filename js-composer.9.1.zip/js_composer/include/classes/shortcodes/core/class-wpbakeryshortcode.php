<?php
/**
 * Abstract class for managing a shortcodes.
 *
 * Provides methods to handle shortcode settings, assets, templates, and rendering.
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/**
 * Class WPBakeryShortCode
 */
abstract class WPBakeryShortCode {
	/**
	 * Configurations for the shortcode.
	 *
	 * @var array
	 */
	public static $config;

	/**
	 * CSS settings for controls.
	 *
	 * @var string
	 */
	protected $controls_css_settings = 'cc';

	/**
	 * Backend section controls.
	 *
	 * @note For frontend editor section controls, please see
	 * include/templates/editors/partials/frontend_controls.tpl.php
	 *
	 * @var array
	 */
	protected $controls_list = [
		'edit',
		'clone',
		'copy',
		'delete',
	];

	/**
	 * Content of the shortcode.
	 *
	 * @var string
	 */
	protected $shortcode_content = '';

	/**
	 * Tag for the shortcode.
	 *
	 * @var string
	 */
	protected $shortcode;

	/**
	 * HTML template for rendering the shortcode.
	 *
	 * @var null|string
	 */
	protected $html_template;

	/**
	 * Shortcode attributes.
	 *
	 * @var array
	 */
	protected $atts;

	/**
	 * Admin labels rendered inside the title container.
	 *
	 * @var string
	 */
	protected $admin_labels = '';

	/**
	 * Shortcode settings.
	 *
	 * @var array|null
	 */
	protected $settings;

	/**
	 * JavaScript scripts associated with the shortcode.
	 *
	 * @deprecated 9.1
	 * @var array
	 */
	protected static $js_scripts = [];

	/**
	 * CSS scripts associated with the shortcode.
	 *
	 * @deprecated 9.1
	 * @var array
	 */
	protected static $css_scripts = [];

	/**
	 * Flag to check if default scripts have been enqueued.
	 *
	 * @var bool
	 * @since 4.4.3
	 */
	protected static $default_scripts_enqueued = false;

	/**
	 * String representation of the shortcode.
	 *
	 * @var string
	 */
	protected $shortcode_string = '';

	/**
	 * Path to the template file for rendering controls.
	 *
	 * @var string
	 */
	protected $controls_template_file = 'editors/partials/backend_controls.tpl.php';

	/**
	 * CSS class for non-draggable elements.
	 *
	 * @var string
	 */
	public $nonDraggableClass = 'vc-non-draggable'; // phpcs:ignore:WordPress.NamingConventions.ValidVariableName.PropertyNotSnakeCase

	/**
	 * Service for element assets.
	 *
	 * @var Wpb_Element_Assets_Service|null
	 */
	public ?Wpb_Element_Assets_Service $assets_service;

	/**
	 * Constructor.
	 *
	 * @param array $settings
	 */
	public function __construct( $settings ) {
		$this->settings = $settings;
		$this->shortcode = $this->settings['base'];
		$this->assets_service = self::get_shared_assets_service();
	}

	/**
	 * Get shared element assets service instance, created once (config names never vary here).
	 *
	 * @return Wpb_Element_Assets_Service
	 */
	protected static function get_shared_assets_service(): Wpb_Element_Assets_Service {
		static $service = null;

		if ( null === $service ) {
			$service = new Wpb_Element_Assets_Service(
				'view_enqueue_css', 'view_enqueue_js'
			);
		}

		return $service;
	}

	/**
	 * Initialize.
	 *
	 * @param array $settings
	 * @deprecated not used
	 */
	public function init( $settings ) {
		self::$config = (array) $settings;
	}

	/**
	 * Add action.
	 *
	 * @param string $action
	 * @param string $method
	 * @param int $priority
	 * @return true|void
	 * @deprecated 6.0 use native WordPress actions
	 */
	public function addAction( $action, $method, $priority = 10 ) {
		return add_action( $action, [
			$this,
			$method,
		], $priority );
	}

	/**
	 * Remove action.
	 *
	 * @param string $action
	 * @param string $method
	 * @param int $priority
	 *
	 * @return bool
	 * @deprecated 6.0 use native WordPress actions
	 */
	public function removeAction( $action, $method, $priority = 10 ) {
		return remove_action( $action, [
			$this,
			$method,
		], $priority );
	}

	/**
	 * Add filter.
	 *
	 * @param string $filter
	 * @param string $method
	 * @param int $priority
	 *
	 * @return bool|void
	 * @deprecated 6.0 use native WordPress actions
	 */
	public function addFilter( $filter, $method, $priority = 10 ) {
		return add_filter( $filter, [
			$this,
			$method,
		], $priority );
	}

	/**
	 * Remove filter.
	 *
	 * @param string $filter
	 * @param string $method
	 * @param int $priority
	 * @return bool
	 * @deprecated 6.0 use native WordPress
	 */
	public function removeFilter( $filter, $method, $priority = 10 ) {
		return remove_filter( $filter, [
			$this,
			$method,
		], $priority );
	}

	/**
	 * Add shortcode.
	 *
	 * @param string $tag
	 * @param string $func
	 * @deprecated 6.0 not used
	 */
	public function addShortCode( $tag, $func ) {
		// this function is deprecated since 6.0.
	}

	/**
	 * Execute shortcode.
	 *
	 * @param string $content
	 * @deprecated 6.0 not used
	 */
	public function doShortCode( $content ) {
		// this function is deprecated since 6.0.
	}

	/**
	 * Remove shortcode.
	 *
	 * @param string $tag
	 * @deprecated 6.0 not used
	 */
	public function removeShortCode( $tag ) {
		// this function is deprecated since 6.0.
	}

	/**
	 * Post param.
	 *
	 * @param string $param
	 *
	 * @return null
	 * @deprecated 6.0 not used, use vc_post_param
	 */
	public function post( $param ) {
		// this function is deprecated since 6.0.
		return vc_post_param( $param );
	}

	/**
	 * Get param.
	 *
	 * @param string $param
	 *
	 * @return null
	 * @deprecated 6.0 not used, use vc_get_param
	 */
	public function get( $param ) {
		// this function is deprecated since 6.0.

		return vc_get_param( $param );
	}

	/**
	 * Assets url.
	 *
	 * @param string $asset
	 *
	 * @return string
	 * @deprecated 4.5 use vc_asset_url
	 */
	public function assetURL( $asset ) {
		// this function is deprecated since 4.5.

		return vc_asset_url( $asset );
	}

	/**
	 * Assets path.
	 *
	 * @param string $asset
	 *
	 * @return string
	 * @deprecated 6.0 not used
	 */
	public function assetPath( $asset ) {
		// this function is deprecated since 6.0.
		return self::$config['APP_ROOT'] . self::$config['ASSETS_DIR'] . $asset;
	}

	/**
	 * Config.
	 *
	 * @param string $name
	 *
	 * @return null
	 * @deprecated 6.0 not used
	 */
	public static function config( $name ) {
		return self::$config[ $name ] ?? null;
	}

	/**
	 * Get inline anchor.
	 *
	 * @param string $content
	 *
	 * @return string
	 */
	public function addInlineAnchors( $content ) { // phpcs:ignore:WordPress.NamingConventions.ValidFunctionName.MethodNameInvalid
		return ( $this->isInline() || $this->isEditor() && true === $this->settings( 'is_container' ) ? '<span class="vc_container-anchor"></span>' : '' ) . $content;
	}

	/**
	 * Enqueue assets.
	 *
	 * @deprecated 9.1
	 */
	public function enqueueAssets() { // phpcs:ignore:WordPress.NamingConventions.ValidFunctionName.MethodNameInvalid
		_deprecated_function( __METHOD__, '9.1', 'Wpb_Element_Assets_Service::process_element_assets()' );
		if ( ! empty( $this->settings['admin_enqueue_js'] ) ) {
			$this->registerJs( $this->settings['admin_enqueue_js'] );
		}
		if ( ! empty( $this->settings['admin_enqueue_css'] ) ) {
			$this->registerCss( $this->settings['admin_enqueue_css'] );
		}
	}

	/**
	 * Prints out the styles needed to render the element icon for the back end interface.
	 * Only performed if the 'icon' setting is a valid URL.
	 *
	 * @since  4.2
	 * @return void
	 */
	public function printIconStyles() { // phpcs:ignore:WordPress.NamingConventions.ValidFunctionName.MethodNameInvalid
		if ( ! filter_var( $this->settings( 'icon' ), FILTER_VALIDATE_URL ) ) {
			return;
		}

		wp_register_style( 'wpb-register-elements-icons', false, [], WPB_VC_VERSION );
		wp_enqueue_style( 'wpb-register-elements-icons' );

		$style = '.vc_el-container #' . esc_attr( $this->settings['base'] ) . ' .vc_element-icon,
                .wpb_' . esc_attr( $this->settings['base'] ) . ' > .wpb_element_wrapper > .wpb_element_image_container > .vc_element-icon,
                .vc_el-container > #' . esc_attr( $this->settings['base'] ) . ' > .vc_element-icon,
                .vc_el-container > #' . esc_attr( $this->settings['base'] ) . ' > .vc_element-icon[data-is-container="true"],
                .compose_mode .vc_helper.vc_helper-' . esc_attr( $this->settings['base'] ) . ' > .vc_element-icon,
                .vc_helper.vc_helper-' . esc_attr( $this->settings['base'] ) . ' > .vc_element-icon,
                .compose_mode .vc_helper.vc_helper-' . esc_attr( $this->settings['base'] ) . ' > .vc_element-icon[data-is-container="true"],
                .vc_helper.vc_helper-' . esc_attr( $this->settings['base'] ) . ' > .vc_element-icon[data-is-container="true"],
                .wpb_' . esc_attr( $this->settings['base'] ) . ' > .wpb_element_wrapper > .wpb_element_image_container > .vc_element-icon,
                .wpb_' . esc_attr( $this->settings['base'] ) . ' > .wpb_element_wrapper > .wpb_element_image_container > .vc_element-icon[data-is-container="true"],
                [title="' . esc_attr( $this->settings['base'] ) . '"] > .vc_element-icon {
                    background-position: 0 0;
                    background-image: url(' . esc_url( $this->settings['icon'] ) . ');
                    -webkit-background-size: contain;
                    -moz-background-size: contain;
                    -ms-background-size: contain;
                    -o-background-size: contain;
                    background-size: contain;
                }';

		wp_add_inline_style( 'wpb-register-elements-icons', $style );
	}

	/**
	 * Register js.
	 *
	 * @deprecated 9.1
	 * @param mixed $param
	 */
	protected function registerJs( $param ) { // phpcs:ignore:WordPress.NamingConventions.ValidFunctionName.MethodNameInvalid
		_deprecated_function( __METHOD__, '9.1', 'Wpb_Element_Assets_Service::process_element_asset_type()' );
		if ( is_array( $param ) && ! empty( $param ) ) {
			foreach ( $param as $value ) {
				$this->registerJs( $value );
			}
		} elseif ( is_string( $param ) && ! empty( $param ) ) {
			$name = 'admin_enqueue_js_' . md5( $param );
			self::$js_scripts[] = $name;
			wp_register_script( $name, $param, [ 'jquery-core' ], WPB_VC_VERSION, true );
		}
	}

	/**
	 * Register css.
	 *
	 * @deprecated 9.1
	 * @param mixed $param
	 */
	protected function registerCss( $param ) { // phpcs:ignore:WordPress.NamingConventions.ValidFunctionName.MethodNameInvalid
		_deprecated_function( __METHOD__, '9.1', 'Wpb_Element_Assets_Service::process_element_asset_type()' );
		if ( is_array( $param ) && ! empty( $param ) ) {
			foreach ( $param as $value ) {
				$this->registerCss( $value );
			}
		} elseif ( is_string( $param ) && ! empty( $param ) ) {
			$name = 'admin_enqueue_css_' . md5( $param );
			self::$css_scripts[] = $name;
			wp_register_style( $name, $param, [ 'js_composer' ], WPB_VC_VERSION );
		}
	}

	/**
	 * Enqueue css.
	 *
	 * @deprecated 9.1
	 */
	public static function enqueueCss() { // phpcs:ignore:WordPress.NamingConventions.ValidFunctionName.MethodNameInvalid
		_deprecated_function( __METHOD__, '9.1', 'Wpb_Element_Assets_Service::process_element_assets()' );
		if ( ! empty( self::$css_scripts ) ) {
			foreach ( self::$css_scripts as $stylesheet ) {
				wp_enqueue_style( $stylesheet );
			}
		}
	}

	/**
	 * Enqueue js.
	 *
	 * @deprecated 9.1
	 */
	public static function enqueueJs() { // phpcs:ignore:WordPress.NamingConventions.ValidFunctionName.MethodNameInvalid
		_deprecated_function( __METHOD__, '9.1', 'Wpb_Element_Assets_Service::process_element_assets()' );
		if ( ! empty( self::$js_scripts ) ) {
			foreach ( self::$js_scripts as $script ) {
				wp_enqueue_script( $script );
			}
		}
	}

	/**
	 * Get shortcode.
	 *
	 * @param string $shortcode
	 */
	public function shortcode( $shortcode ) {
	}

	/**
	 * Set shortcode template.
	 *
	 * @see include/templates
	 * @param mixed $template
	 *
	 * @return string
	 */
	protected function setTemplate( $template ) { // phpcs:ignore:WordPress.NamingConventions.ValidFunctionName.MethodNameInvalid
		return $this->html_template = apply_filters( 'vc_shortcode_set_template_' . $this->shortcode, $template );
	}

	/**
	 * Get shortcode template.
	 *
	 * @see include/templates
	 * @return string|bool
	 */
	protected function getTemplate() { // phpcs:ignore:WordPress.NamingConventions.ValidFunctionName.MethodNameInvalid
		if ( isset( $this->html_template ) ) {
			return $this->html_template;
		}

		return false;
	}

	/**
	 * Get name.
	 *
	 * @return mixed
	 */
	protected function getFileName() { // phpcs:ignore:WordPress.NamingConventions.ValidFunctionName.MethodNameInvalid
		return $this->shortcode;
	}

	/**
	 * Check if shortcode's mapping settings contain a valid html_template file path.
	 *
	 * @return bool
	 * @version 9.0
	 */
	protected function is_html_template_param() {
		return ! empty( $this->settings['html_template'] ) && is_file( $this->settings( 'html_template' ) );
	}

	/**
	 * Check if a theme template file exists for this shortcode.
	 *
	 * @return bool
	 * @version 9.0
	 */
	protected function is_theme_template() {
		return is_file( vc_shortcodes_theme_templates_dir( $this->getFileName() . '.php' ) );
	}

	/**
	 * Get default template path for this shortcode.
	 *
	 * @return string
	 * @version 9.0
	 */
	protected function get_default_template_path() {
		return vc_manager()->getDefaultShortcodesTemplatesDir() . '/' . $this->getFileName() . '.php';
	}

	/**
	 * Check if a default template file exists for this shortcode.
	 *
	 * @return bool
	 * @version 9.0
	 */
	protected function is_default_template() {
		return is_file( $this->get_default_template_path() );
	}

	/**
	 * Find html template for shortcode output.
	 */
	protected function findShortcodeTemplate() { // phpcs:ignore:WordPress.NamingConventions.ValidFunctionName.MethodNameInvalid
		// Check template path in shortcode's mapping settings.
		if ( $this->is_html_template_param() ) {
			return $this->setTemplate( $this->settings['html_template'] );
		}

		// Check template in theme directory.
		if ( $this->is_theme_template() ) {
			$template = vc_shortcodes_theme_templates_dir( $this->getFileName() . '.php' );
			if ( $this->is_theme_template_version_outdated( $template ) ) {
				$this->trigger_template_version_deprecation( $template );
			}

			if ( ! $this->is_theme_template_critically_outdated( $template ) ) {
				return $this->setTemplate( $template );
			}
		}

		// Check default place.
		if ( $this->is_default_template() ) {
			return $this->setTemplate( $this->get_default_template_path() );
		}

		return $this->setTemplate( '' );
	}


	/**
	 * Compare the @version tag in theme and default templates and output a deprecation warning if needed.
	 *
	 * @param string $template
	 * @return bool
	 * @version 9.0
	 */
	public function is_theme_template_version_outdated( $template ) {
		$default_version = $this->get_template_version_tag( $this->get_default_template_path() );

		if ( '' === $default_version ) {
			return false;
		}

		$theme_version = $this->get_template_version_tag( $template );
		if ( $this->is_template_version_outdated( $default_version, $theme_version ) ) {
			return true;
		}

		return false;
	}

	/**
	 * Extract @version tag value from a template file's doc comment.
	 *
	 * @param string $template Path to template file.
	 * @return string
	 * @version 9.0
	 */
	protected function get_template_version_tag( $template ) {
		if ( ! is_file( $template ) ) {
			return '';
		}

		$contents = vc_file_get_contents( $template );

		if ( ! $contents || ! preg_match( '/@version\s+([0-9]+(?:\.[0-9]+)*)/', $contents, $matches ) ) {
			return '';
		}

		return $matches[1];
	}

	/**
	 * Check if theme template version is outdated compared to default template version.
	 *
	 * @param string $default_version
	 * @param string $theme_version
	 * @return bool
	 * @version 9.0
	 */
	protected function is_template_version_outdated( $default_version, $theme_version ) {
		if ( '' === $theme_version ) {
			return true;
		}

		return version_compare( $theme_version, $default_version, '<' );
	}

	/**
	 * Trigger deprecation warning for an outdated theme template override.
	 *
	 * @param string $template
	 * @version 9.0
	 */
	protected function trigger_template_version_deprecation( $template ) {
		if ( ! function_exists( 'wp_trigger_error' ) ) {
			return;
		}

		$theme_version = $this->get_template_version_tag( $template );
		$default_version = $this->get_template_version_tag( $this->get_default_template_path() );

		$message = sprintf(
		/* translators: 1: theme name, 2: template file name, 3: theme template version, 4: default template version */
			esc_html__( 'Your theme "%1$s" template override for WPBakery template "%2$s" is outdated (version %3$s) compared to the default (version %4$s). Contact theme author update it to avoid compatibility issues.', 'js_composer' ),
			wp_get_theme()->get( 'Name' ),
			basename( $template ),
			'' === $theme_version ? esc_html__( 'not set', 'js_composer' ) : $theme_version,
			$default_version
		);

		wp_trigger_error( '', $message, E_USER_DEPRECATED );
	}

	/**
	 * Here shortcode class can override it to true
	 * and not let theme author template render if it not has
	 * some critical for this element template functionality.
	 *
	 * @since 9.0
	 * @param string $template
	 * @return bool
	 */
	public function is_theme_template_critically_outdated( $template ) { // phpcs:ignore:Generic.CodeAnalysis.UnusedFunctionParameter.Found
		return false;
	}

	/**
	 * Get shortcode content.
	 *
	 * @param array $atts
	 * @param null $content
	 *
	 * @return mixed
	 * @throws Exception
	 */
	protected function content( $atts, $content = null ) {
		return $this->loadTemplate( $atts, $content ); // nosemgrep - escaping handled inside templates.
	}

	/**
	 * Get shortcode output.
	 *
	 * @param array $atts
	 * @param null|string $content
	 *
	 * @see vc_filter: vc_shortcode_content_filter - hook to edit template content
	 * @see vc_filter: vc_shortcode_content_filter_after - hook after template is loaded to override output
	 *
	 * @return mixed
	 * @throws Exception
	 */
	protected function loadTemplate( $atts, $content = null ) { // phpcs:ignore:WordPress.NamingConventions.ValidFunctionName.MethodNameInvalid
		$output = '';
		if ( ! is_null( $content ) ) {
			// string $content.
			$content = apply_filters( 'vc_shortcode_content_filter', $content, $this->shortcode, $atts );
		}
		$this->findShortcodeTemplate();
		if ( $this->html_template && file_exists( $this->html_template ) ) {
			if ( strpos( $this->html_template, WPB_PLUGIN_DIR ) === false ) {
				// Modified or new.
				Vc_Modifications::$modified = true;
			}
			ob_start();
			// @var string $content - used inside template.
			$output = require $this->html_template;
			// Allow return in template files.
			if ( 1 === $output ) {
				$output = ob_get_contents();
			}
			ob_end_clean();
		}

		return apply_filters( 'vc_shortcode_content_filter_after', $output, $this->shortcode, $atts, $content );
	}

	/**
	 * Get admin output.
	 *
	 * @param array $atts
	 * @param null|string $content
	 *
	 * @return string
	 * @throws Exception
	 */
	public function contentAdmin( $atts, $content = null ) { // phpcs:ignore:WordPress.NamingConventions.ValidFunctionName.MethodNameInvalid
		$output = $custom_markup = $width = $el_position = '';
		if ( null !== $content ) {
			$content = wpautop( stripslashes( $content ) );
		}
		$shortcode_attributes = [ 'width' => '1/1' ];
		$atts = vc_map_get_attributes( $this->getShortcode(), $atts ) + $shortcode_attributes;
		$this->atts = $atts;
		$elem = $this->getElementHolder( $width );
		if ( isset( $this->settings['custom_markup'] ) && '' !== $this->settings['custom_markup'] ) {
			$markup = $this->settings['custom_markup'];
			$elem = str_ireplace( '%wpb_element_content%', $this->get_custom_markup( $markup, $content ), $elem );
			$output .= $elem;
		} else {
			$this->admin_labels = '';
			// Param holders collect admin labels used by the title output below.
			$params_html = $this->paramsHtmlHolders( $atts );
			$inner = $this->add_element_image_container( $this->settings['name'] );
			$inner .= $params_html;
			$elem = str_ireplace( '%wpb_element_content%', $inner, $elem );
			$output .= $elem;
		}

		return $output; // nosemgrep - we already escaped everything on this step.
	}

	/**
	 * Check if admin.
	 *
	 * @return bool
	 */
	public function isAdmin() { // phpcs:ignore:WordPress.NamingConventions.ValidFunctionName.MethodNameInvalid
		return apply_filters( 'vc_shortcodes_is_admin', is_admin() );
	}

	/**
	 * Check if inline.
	 *
	 * @return bool
	 */
	public function isInline() { // phpcs:ignore:WordPress.NamingConventions.ValidFunctionName.MethodNameInvalid
		return vc_is_inline();
	}

	/**
	 * Check if editor.
	 *
	 * @return bool
	 */
	public function isEditor() { // phpcs:ignore:WordPress.NamingConventions.ValidFunctionName.MethodNameInvalid
		return vc_is_frontend_editor();
	}

	/**
	 * Get shortcode output.
	 *
	 * @param array $atts
	 * @param null|string $content
	 * @param string $base
	 *
	 * vc_filter: vc_shortcode_output - hook to override output of shortcode
	 *
	 * @return string
	 * @throws Exception
	 */
	public function output( $atts, $content = null, $base = '' ) {
		if ( '' !== $base ) {
			_deprecated_argument( __METHOD__, '7.9', '$base' );
		}
		$this->atts = $prepared_atts = $this->prepareAtts( $atts );
		$this->shortcode_content = $content;
		$output = '';
		$content = empty( $content ) && ! empty( $atts['content'] ) ? $atts['content'] : $content;
		if ( ( $this->isInline() || vc_is_page_editable() ) && method_exists( $this, 'contentInline' ) ) {
			$output .= $this->contentInline( $this->atts, $content );
		} else {
			$this->enqueue_assets();
			$output .= $this->attach_before_shortcode_and_after( $content );
		}
		// Filter for overriding outputs.
		$output = apply_filters( 'vc_shortcode_output', $output, $this, $prepared_atts, $this->shortcode );

		return $output;
	}

	/**
	 * Enqueue shortcode assets.
	 *
	 * @since 9.1
	 */
	protected function enqueue_assets() {
		$this->enqueueDefaultScripts();
		// additional method enqueue css with css strategy settings.
		$this->enqueue_shortcode_css();
		// additional method enqueue js with js strategy settings.
		$this->enqueue_shortcode_js();
		if ( isset( $this->assets_service, $this->settings ) ) {
			$settings = $this->settings;
			$settings = Wpb_Assets_Optimization_Manager::remove_optimized_assets( $settings, 'js', $this->assets_service->js_config_name );
			$settings = Wpb_Assets_Optimization_Manager::remove_optimized_assets( $settings, 'css', $this->assets_service->css_config_name );
			$this->assets_service->process_element_assets( $settings );
		}
	}

	/**
	 * Render the shortcode's before, content and after parts, in order.
	 *
	 * @param string|null $content
	 * @return string
	 * @since 9.1
	 */
	protected function attach_before_shortcode_and_after( ?string $content ): string {
		$custom_output = VC_SHORTCODE_CUSTOMIZE_PREFIX . $this->shortcode;
		$custom_output_before = VC_SHORTCODE_BEFORE_CUSTOMIZE_PREFIX . $this->shortcode; // before shortcode function hook.
		$custom_output_after = VC_SHORTCODE_AFTER_CUSTOMIZE_PREFIX . $this->shortcode; // after shortcode function hook.
		$output = '';

		// Before shortcode.
		if ( function_exists( $custom_output_before ) ) {
			$output .= $custom_output_before( $this->atts, $content );
		} else {
			$output .= $this->beforeShortcode( $this->atts, $content );
		}
		// Shortcode content.
		if ( function_exists( $custom_output ) ) {
			$output .= $custom_output( $this->atts, $content );
		} else {
			$output .= $this->content( $this->atts, $content );
		}
		// After shortcode.
		if ( function_exists( $custom_output_after ) ) {
			$output .= $custom_output_after( $this->atts, $content );
		} else {
			$output .= $this->afterShortcode( $this->atts, $content );
		}

		return $output;
	}

	/**
	 * Enqueue default scripts.
	 */
	public function enqueueDefaultScripts() { // phpcs:ignore:WordPress.NamingConventions.ValidFunctionName.MethodNameInvalid
		if ( false === self::$default_scripts_enqueued ) {
			wp_enqueue_script( 'wpb_composer_front_js' );
			wp_enqueue_style( 'js_composer_front' );
			self::$default_scripts_enqueued = true;
		}
	}

	/**
	 * Enqueue shortcode specific CSS files.
	 * We can define the CSS files to enqueue in the shortcode class method get_shortcode_css_files().
	 *
	 * @since 9.0
	 */
	protected function enqueue_shortcode_css() {
		$css_files = $this->get_shortcode_css_files();
		if ( ! empty( $css_files ) ) {
			foreach ( (array) $css_files as $css_file ) {
				$this->enqueue_shortcode_styles( $css_file );
			}
		}
	}

	/**
	 * Get CSS file names for this shortcode.
	 *
	 * @since 9.0
	 * @return string|array
	 */
	public function get_shortcode_css_files() {
		return $this->shortcode;
	}

	/**
	 * Enqueue shortcode specific styles.
	 *
	 * @since 9.0
	 * @param string $shortcode_name
	 */
	protected function enqueue_shortcode_styles( $shortcode_name ) {
		// Allow frontend AJAX renders (e.g. grid data) to keep their styles (#4165).
		if ( ! Wpb_Assets_Optimization_Manager::should_load_optimized( 'css' ) || ( is_admin() && ! wp_doing_ajax() ) ) {
			return;
		}

		$css_file = 'css/shortcodes/frontend/' . $shortcode_name . '.min.css';
		if ( ! file_exists( vc_path_dir( 'ASSETS_DIR', $css_file ) ) ) {
			return;
		}

		$this->assets_service->process_element_asset_type( 'css', [
			[
				'url' => vc_asset_url( $css_file ),
				'handle' => $shortcode_name . '_style',
			],
		] );
	}

	/**
	 * Enqueue shortcode specific JS files.
	 * We can define the JS files to enqueue in the shortcode class method get_shortcode_js_files().
	 *
	 * @since 9.1
	 */
	protected function enqueue_shortcode_js() {
		$js_files = $this->get_shortcode_js_files();
		if ( ! empty( $js_files ) ) {
			foreach ( (array) $js_files as $js_file ) {
				$this->enqueue_shortcode_scripts( $js_file );
			}
		}
	}

	/**
	 * Get JS file names for this shortcode.
	 *
	 * @since 9.1
	 * @return string|array
	 */
	public function get_shortcode_js_files() {
		return '';
	}

	/**
	 * Enqueue shortcode specific scripts.
	 *
	 * @since 9.1
	 * @param string $shortcode_name
	 */
	protected function enqueue_shortcode_scripts( $shortcode_name ) {
		// Allow frontend AJAX renders (e.g. grid data) to keep their scripts (#4165).
		if ( ! Wpb_Assets_Optimization_Manager::should_load_optimized( 'js' ) || ( is_admin() && ! wp_doing_ajax() ) ) {
			return;
		}

		$js_file = 'js/shortcodes/frontend/' . $shortcode_name . '.min.js';
		if ( ! file_exists( vc_path_dir( 'ASSETS_DIR', $js_file ) ) ) {
			return;
		}

		$this->assets_service->process_element_asset_type( 'js', [
			[
				'url' => vc_asset_url( $js_file ),
				'handle' => $shortcode_name . '_script',
				'args' => [ 'in_footer' => true ],
			],
		] );
	}

	/**
	 * Return shortcode attributes, see \WPBakeryShortCode::output
	 *
	 * @return array
	 * @since 4.4
	 */
	public function getAtts() { // phpcs:ignore:WordPress.NamingConventions.ValidFunctionName.MethodNameInvalid
		return $this->atts;
	}

	/**
	 * Creates html before shortcode html.
	 *
	 * @param array $atts - shortcode attributes list.
	 * @param string $content - shortcode content.
	 *
	 * @return string - html which will be displayed before shortcode html.
	 */
	public function beforeShortcode( $atts, $content ) { // phpcs:ignore:Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed, WordPress.NamingConventions.ValidFunctionName.MethodNameInvalid
		return '';
	}

	/**
	 * Creates html before shortcode html.
	 *
	 * @param array $atts - shortcode attributes list.
	 * @param string $content - shortcode content.
	 *
	 * @return string - html which will be displayed after shortcode html.
	 */
	public function afterShortcode( $atts, $content ) { // phpcs:ignore:Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed, WordPress.NamingConventions.ValidFunctionName.MethodNameInvalid
		return '';
	}

	/**
	 * Add element class.
	 *
	 * @param string $el_class
	 *
	 * @return string
	 */
	public function getExtraClass( $el_class ) { // phpcs:ignore:WordPress.NamingConventions.ValidFunctionName.MethodNameInvalid
		$output = '';
		if ( '' !== $el_class ) {
			$output = ' ' . str_replace( '.', '', $el_class );
		}

		return $output;
	}

	/**
	 * Add css animation.
	 *
	 * @param string $css_animation
	 *
	 * @return string
	 */
	public function getCSSAnimation( $css_animation ) { // phpcs:ignore:WordPress.NamingConventions.ValidFunctionName.MethodNameInvalid
		$output = '';
		if ( '' !== $css_animation && 'none' !== $css_animation ) {
			wp_enqueue_script( 'vc_waypoints' );
			wp_enqueue_script( 'vc_waypoints_init' );
			wp_enqueue_style( 'vc_animate-css' );
			$output = ' wpb_animate_when_almost_visible wpb_' . $css_animation . ' ' . $css_animation;
		}

		return $output;
	}

	/**
	 * Get list of elements classes that we attach to class wrapper tag.
	 * Usually we attach there classes related to animation, default element class and etc
	 *
	 * @since 8.0
	 *
	 * @param string $element_class
	 * @param array $atts
	 *
	 * @return array
	 */
	public function get_element_wrapper_classes( $element_class, $atts ) {
		$main_wrapper_classes = [
			$element_class,
			trim( $this->getExtraClass( $atts['el_class'] ?? '' ) ),
		];

		if ( ! empty( $atts['css_animation'] ) ) {
			$main_wrapper_classes[] = $this->getCSSAnimation( $atts['css_animation'] );
		}

		if ( ! empty( $atts['css'] ) ) {
			$main_wrapper_classes[] = vc_shortcode_custom_css_class( $atts['css'] );
		}

		if ( ! empty( $this->settings['element_default_class'] ) ) {
			$main_wrapper_classes[] = $this->settings['element_default_class'];
		}

		return $main_wrapper_classes;
	}

	/**
	 * Get filtered element wrapper css class.
	 *
	 * @param string $element_class Element base class.
	 * @param array $atts Shortcode attributes.
	 * @return string Wrapper css class.
	 * @since 9.1
	 */
	public function get_element_wrapper_css_class( $element_class, $atts ) {
		return $this->get_filtered_css_class( $this->get_element_wrapper_classes( $element_class, $atts ), $atts );
	}

	/**
	 * Join css classes and pass them through the shortcode custom css filter.
	 *
	 * @param string[] $classes Css classes.
	 * @param array $atts Shortcode attributes.
	 * @return string Filtered css class.
	 * @since 9.1
	 */
	public function get_filtered_css_class( $classes, $atts ) {
		$css_class = implode( ' ', array_filter( array_map( 'trim', $classes ) ) );

		return apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $css_class, $this->settings['base'], $atts );
	}

	/**
	 * Create HTML comment for blocks only if wpb_debug=true
	 *
	 * @param string|null $initial
	 *
	 * @return string
	 * @deprecated 4.7 For debug type html comments use more generic debugComment function.
	 */
	public function endBlockComment( $initial ) {
		if ( null !== $initial ) {
			_deprecated_argument( __METHOD__, '4.7', '$initial' );
		}
		return '';
	}

	/**
	 * If wpb_debug=true return HTML comment
	 *
	 * @param string|null $comment
	 *
	 * @return string
	 * @since 4.7
	 * @deprecated 5.5 no need for extra info in output, use xdebug
	 */
	public function debugComment( $comment ) {
		if ( null !== $comment ) {
			_deprecated_argument( __METHOD__, '7.9', '$comment' );
		}
		return '';
	}

	/**
	 * Get specific settings.
	 *
	 * @param string $name
	 *
	 * @return mixed|null
	 */
	public function settings( $name ) {
		return $this->settings[ $name ] ?? null;
	}

	/**
	 * Set settings.
	 *
	 * @param string $name
	 * @param mixed $value
	 */
	public function setSettings( $name, $value ) { // phpcs:ignore:WordPress.NamingConventions.ValidFunctionName.MethodNameInvalid
		$this->settings[ $name ] = $value;
	}

	/**
	 * Get all settings.
	 *
	 * @return mixed
	 * @since 5.5
	 */
	public function getSettings() { // phpcs:ignore:WordPress.NamingConventions.ValidFunctionName.MethodNameInvalid
		return $this->settings;
	}

	/**
	 * Get shortcode element holder.
	 *
	 * @param string $width
	 *
	 * @return string
	 * @throws Exception
	 */
	public function getElementHolder( $width ) { // phpcs:ignore:WordPress.NamingConventions.ValidFunctionName.MethodNameInvalid
		$output = '';
		$column_controls = $this->getColumnControlsModular();
		$sortable = ( vc_user_access_check_shortcode_all( $this->shortcode ) ? 'wpb_sortable' : $this->nonDraggableClass ); // phpcs:ignore:WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
		$css_class = 'wpb_' . $this->settings['base'] . ' wpb_content_element ' . $sortable . '' . ( ! empty( $this->settings['class'] ) ? ' ' . $this->settings['class'] : '' );
		$output .= '<div data-element_type="' . $this->settings['base'] . '" class="' . $css_class . '">';
		$output .= str_replace( '%column_size%', wpb_translateColumnWidthToFractional( $width ), $column_controls );
		$output .= $this->getCallbacks();
		$output .= '<div class="wpb_element_wrapper ' . $this->settings( 'wrapper_class' ) . '">';
		$output .= '%wpb_element_content%';
		$output .= '</div>';
		$output .= '</div>';

		return $output;
	}

	/**
	 * Get column control settings.
	 *
	 * @since 9.0
	 *
	 * @param string $extended_css
	 * @return array
	 */
	public function get_column_control_settings( $extended_css = '' ) { // phpcs:ignore:Generic.CodeAnalysis.UnusedFunctionParameter.Found
		return [
			'edit' => [
				'title' => sprintf( esc_html__( 'Edit %s', 'js_composer' ), strtolower( $this->settings( 'name' ) ) ),
				'classes' => 'column_edit',
			],
			'delete' => [
				'title' => sprintf( esc_html__( 'Delete %s', 'js_composer' ), strtolower( $this->settings( 'name' ) ) ),
				'classes' => 'column_delete',
			],
		];
	}

	/**
	 * Get html list of column controls.
	 *
	 * @since 9.0
	 * @param string $extended_css
	 * @return array
	 */
	public function get_column_controls_html_list( $extended_css = '' ) {
		$list = [];
		foreach ( $this->get_column_control_settings( $extended_css ) as $slug => $settings ) {
			$settings['slug'] = $slug;
			$list[ $slug ] = str_replace( [ "\r", "\n" ], '', vc_get_template( 'editors/partials/backend_single_control.tpl.php', $settings ) );
		}

		return $list;
	}

	/**
	 * Return block controls.
	 *
	 * @param string $controls
	 * @param string $extended_css
	 *
	 * @return string
	 * @throws Exception
	 */
	public function getColumnControls( $controls, $extended_css = '' ) { // phpcs:ignore:Generic.Metrics.CyclomaticComplexity.TooHigh, CognitiveComplexity.Complexity.MaximumComplexity.TooHigh, WordPress.NamingConventions.ValidFunctionName.MethodNameInvalid
		$controls_start = '<div class="vc_controls controls_element' . ( ! empty( $extended_css ) ? " {$extended_css}" : '' ) . '">';

		$controls_end = '</div>';

		$controls_add = '';
		$control_list = $this->get_column_controls_html_list();

		$column_controls_full = $controls_start . $controls_add . $control_list['edit'] . $control_list['delete'] . $controls_end;
		$column_controls_size_delete = $controls_start . $control_list['delete'] . $controls_end;
		$column_controls_popup_delete = $controls_start . $control_list['delete'] . $controls_end;
		$column_controls_edit_popup_delete = $controls_start . $control_list['edit'] . $control_list['delete'] . $controls_end;
		$column_controls_edit = $controls_start . $control_list['edit'] . $controls_end;

		$edit_access = vc_user_access_check_shortcode_edit( $this->shortcode );
		$all_access = vc_user_access_check_shortcode_all( $this->shortcode );

		if ( 'popup_delete' === $controls ) {
			return $all_access ? $column_controls_popup_delete : '';
		} elseif ( 'edit_popup_delete' === $controls ) {
			return $all_access ? $column_controls_edit_popup_delete : ( $edit_access ? $column_controls_edit : '' );
		} elseif ( 'size_delete' === $controls ) {
			return $all_access ? $column_controls_size_delete : '';
		} elseif ( 'add' === $controls ) {
			return $all_access ? ( $controls_start . $controls_add . $controls_end ) : '';
		} else {
			return $all_access ? $column_controls_full : ( $edit_access ? $column_controls_edit : '' );
		}
	}

	/**
	 * Return list of controls.
	 *
	 * @return array
	 * @throws Exception
	 */
	public function getControlsList() { // phpcs:ignore:CognitiveComplexity.Complexity.MaximumComplexity.TooHigh, WordPress.NamingConventions.ValidFunctionName.MethodNameInvalid
		$edit_access = vc_user_access_check_shortcode_edit( $this->shortcode );
		$all_access = vc_user_access_check_shortcode_all( $this->shortcode );
		if ( $all_access ) {
			return apply_filters( 'vc_wpbakery_shortcode_get_controls_list', $this->controls_list, $this->shortcode );
		} else {
			$controls = apply_filters( 'vc_wpbakery_shortcode_get_controls_list', $this->controls_list, $this->shortcode );
			if ( $edit_access ) {
				foreach ( $controls as $key => $value ) {
					if ( 'edit' !== $value && 'add' !== $value ) {
						unset( $controls[ $key ] );
					}
				}

				return $controls;
			} else {
				return in_array( 'add', $controls, true ) ? [ 'add' ] : [];
			}
		}
	}

	/**
	 * Build new modern controls for shortcode.
	 *
	 * @param string $extended_css
	 *
	 * @return string
	 * @throws Exception
	 */
	public function getColumnControlsModular( $extended_css = '' ) { // phpcs:ignore:WordPress.NamingConventions.ValidFunctionName.MethodNameInvalid
		ob_start();
		vc_include_template( apply_filters( 'vc_wpbakery_shortcode_get_column_controls_modular_template', $this->controls_template_file ), [
			'shortcode' => $this->shortcode,
			'position' => $this->controls_css_settings,
			'extended_css' => $extended_css,
			'name' => $this->settings( 'name' ),
			'controls' => $this->getControlsList(),
			'name_css_class' => $this->getBackendEditorControlsElementCssClass(),
			'add_allowed' => $this->getAddAllowed(),
		] );

		return ob_get_clean();
	}

	/**
	 * Add control classes.
	 *
	 * @return string
	 * @throws Exception
	 */
	public function getBackendEditorControlsElementCssClass() { // phpcs:ignore:WordPress.NamingConventions.ValidFunctionName.MethodNameInvalid
		$move_access = vc_user_access()->part( 'dragndrop' )->checkStateAny( true, null )->get();

		$sortable = ( vc_user_access_check_shortcode_all( $this->shortcode ) && $move_access ? ' vc_element-move' : ' ' . $this->nonDraggableClass ); // phpcs:ignore:WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase

		return 'vc_control-btn vc_element-name' . $sortable;
	}

	/**
	 * This will fire callbacks if they are defined in map.php
	 *
	 * @return string
	 */
	public function getCallbacks() { // phpcs:ignore:WordPress.NamingConventions.ValidFunctionName.MethodNameInvalid
		$output = '';

		if ( isset( $this->settings['js_callback'] ) ) {
			foreach ( $this->settings['js_callback'] as $text_val => $val ) {
				$output .= WPB_Form_Field_Hidden::get([
					'name' => $text_val,
					'value' => $val,
					'classes' => 'wpb_vc_callback wpb_vc_' . $text_val . '_callback',
					'is_value_escape' => false,
				]);
			}
		}

		return $output;
	}

	/**
	 * Add params html holders.
	 *
	 * @param array $param
	 * @param string $value
	 *
	 * vc_filter: vc_wpbakeryshortcode_single_param_html_holder_value - hook to override param value (param type and etc is available in args)
	 *
	 * @return string
	 */
	public function singleParamHtmlHolder( $param, $value ) { // phpcs:ignore:Generic.Metrics.CyclomaticComplexity.TooHigh, WordPress.NamingConventions.ValidFunctionName.MethodNameInvalid
		$value = apply_filters( 'vc_wpbakeryshortcode_single_param_html_holder_value', $value, $param, $this->settings, $this->atts );
		$output = '';
		// Compatibility fixes.
		$old_names = [
			'yellow_message',
			'blue_message',
			'green_message',
			'button_green',
			'button_grey',
			'button_yellow',
			'button_blue',
			'button_red',
			'button_orange',
		];
		$new_names = [
			'alert-block',
			'alert-info',
			'alert-success',
			'btn-success',
			'btn',
			'btn-info',
			'btn-primary',
			'btn-danger',
			'btn-warning',
		];
		$value = str_ireplace( $old_names, $new_names, $value );
		$param_name = $param['param_name'] ?? '';
		$type = $param['type'] ?? '';
		$class = $param['class'] ?? '';
		if ( ! empty( $param['holder'] ) ) {
			if ( 'input' === $param['holder'] ) {
				$output .= '<' . $param['holder'] . ' readonly="true" class="wpb_vc_param_value ' . $param_name . ' ' . $type . ' ' . $class . '" name="' . $param_name . '" value="' . $value . '">';
			} elseif ( in_array( $param['holder'], [
				'img',
				'iframe',
			], true ) ) {
				$output .= '<' . $param['holder'] . ' class="wpb_vc_param_value ' . $param_name . ' ' . $type . ' ' . $class . '" name="' . $param_name . '" src="' . esc_url( $value ) . '">';
			} elseif ( 'hidden' !== $param['holder'] ) {
				$output .= '<' . $param['holder'] . ' class="wpb_vc_param_value ' . $param_name . ' ' . $type . ' ' . $class . '" name="' . $param_name . '">' . $value . '</' . $param['holder'] . '>';
			}
		}
		$this->add_admin_label( $param, $value );

		return $output;
	}

	/**
	 * Collect admin label markup.
	 *
	 * @param array $param
	 * @param string $value
	 *
	 * @since 9.1
	 */
	protected function add_admin_label( $param, $value ) {
		if ( empty( $param['admin_label'] ) || true !== $param['admin_label'] ) {
			return;
		}

		$this->admin_labels .= vc_get_template( 'editors/partials/backend_admin_label.tpl.php', [
			'param' => $param,
			'value' => $value,
		] );
	}

	/**
	 * Retrieve icon.
	 *
	 * @param array $params
	 *
	 * @return string
	 */
	protected function getIcon( $params ) { // phpcs:ignore:WordPress.NamingConventions.ValidFunctionName.MethodNameInvalid
		$data = '';
		if ( isset( $params['is_container'] ) && true === $params['is_container'] ) {
			$data = ' data-is-container="true"';
		}
		$title = '';
		if ( isset( $params['title'] ) ) {
			$title = 'title="' . esc_attr( $params['title'] ) . '" ';
		}

		return '<i ' . $title . ' class="vc_general vc_element-icon' . ( ! empty( $params['icon'] ) ? ' ' . sanitize_text_field( $params['icon'] ) : '' ) . '"' . $data . '></i> ';
	}

	/**
	 * Get the element icon that is only visible in the compact backend view.
	 *
	 * @param string $title
	 * @return string
	 *
	 * @since 9.1
	 */
	protected function output_compact_view_icon( $title = '' ) {
		$icon = $this->settings( 'icon' );
		if ( filter_var( $icon, FILTER_VALIDATE_URL ) ) {
			$icon = '';
		}
		$params = [
			'icon' => $icon,
			'is_container' => $this->settings( 'is_container' ),
			'title' => $title,
		];

		return vc_get_template( 'editors/partials/backend_compact_view_icon.tpl.php', [
			'icon_html' => $this->getIcon( $params ),
		] );
	}

	/**
	 * Get title.
	 *
	 * @param string $title
	 *
	 * @return string
	 */
	protected function outputTitle( $title ) { // phpcs:ignore:WordPress.NamingConventions.ValidFunctionName.MethodNameInvalid
		return '<div class="wpb_element_title_container">' . vc_get_template( 'editors/partials/backend_element_title.tpl.php', [
			'title' => $title,
		] ) . $this->admin_labels . '</div>';
	}

	/**
	 * Get the element's image container with a title.
	 *
	 * @param string $title
	 *
	 * @return string
	 */
	protected function add_element_image_container( $title ) {
		$title_html = $this->outputTitle( $title );
		if ( '' === $title_html || false !== strpos( $title_html, 'wpb_element_image_container' ) ) {
			return $title_html;
		}

		$icon = $this->settings( 'icon' );
		if ( filter_var( $icon, FILTER_VALIDATE_URL ) ) {
			$icon = '';
		}
		$params = [
			'icon' => $icon,
			'is_container' => $this->settings( 'is_container' ),
		];

		return vc_get_template( 'editors/partials/backend_element_image_container.tpl.php', [
			'icon_html' => $this->getIcon( $params ),
			'title_html' => $title_html,
		] );
	}

	/**
	 * Get template.
	 *
	 * @param string $content
	 *
	 * @return string
	 * @throws Exception
	 */
	public function template( $content = '' ) {
		return $this->contentAdmin( $this->atts, $content );
	}

	/**
	 * This functions prepares attributes to use in template.
	 * Converts back escaped characters.
	 *
	 * @param mixed $atts
	 *
	 * @return array
	 */
	protected function prepareAtts( $atts ) { // phpcs:ignore:WordPress.NamingConventions.ValidFunctionName.MethodNameInvalid
		$return_attributes = [];
		if ( is_array( $atts ) ) {
			foreach ( $atts as $key => $val ) {
				$return_attributes[ $key ] = str_replace( [
					'`{`',
					'`}`',
					'``',
				], [
					'[',
					']',
					'"',
				], $val );
			}
		}

		return apply_filters( 'vc_shortcode_prepare_atts', $return_attributes, $this->shortcode, $this->settings );
	}

	/**
	 * Get shortcode.
	 *
	 * @return string
	 */
	public function getShortcode() { // phpcs:ignore:WordPress.NamingConventions.ValidFunctionName.MethodNameInvalid
		return $this->shortcode;
	}

	/**
	 * Get custom markup.
	 *
	 * Possible placeholders:
	 *      {{ content }}
	 *      {{ title }}
	 *      {{ container-class }}
	 *
	 * Possible keys:
	 *  {{
	 *  <%
	 *  %
	 *
	 * @param string $markup
	 * @param string $content
	 *
	 * @return string
	 * @throws Exception
	 * @since 4.5
	 */
	protected function get_custom_markup( $markup, $content = '' ) { // phpcs:ignore:Generic.Metrics.CyclomaticComplexity.TooHigh, CognitiveComplexity.Complexity.MaximumComplexity.TooHigh
		$pattern = '/\{\{([\s\S][^\n]+?)\}\}|<%([\s\S][^\n]+?)%>|%([\s\S][^\n]+?)%/';
		$matches_count = preg_match_all( $pattern, $markup, $matches, PREG_SET_ORDER );
		if ( $matches_count ) {
			foreach ( $matches as $match ) {
				switch ( strtolower( trim( $match[1] ) ) ) {
					case 'content':
						if ( '' !== $content ) {
							$markup = str_replace( $match[0], $content, $markup );
						} elseif ( isset( $this->settings['default_content_in_template'] ) && '' !== $this->settings['default_content_in_template'] ) {
							$markup = str_replace( $match[0], $this->settings['default_content_in_template'], $markup );
						} else {
							$markup = str_replace( $match[0], '', $markup );
						}
						break;
					case 'title':
						$markup = str_replace( $match[0], $this->add_element_image_container( $this->settings['name'] ), $markup );
						break;
					case 'container-class':
						if ( method_exists( $this, 'containerContentClass' ) ) {
							$markup = str_replace( $match[0], $this->containerContentClass(), $markup );
						} else {
							$markup = str_replace( $match[0], '', $markup );
						}
						break;
					case 'editor_controls':
						$markup = str_replace( $match[0], $this->getColumnControls( $this->settings( 'controls' ) ), $markup );
						break;
					case 'editor_controls_bottom_add':
						$markup = str_replace( $match[0], $this->getColumnControls( 'add', 'bottom-controls' ), $markup );
						break;
				}
			}
		}

		return do_shortcode( $markup );
	}

	/**
	 * Get params html holders.
	 *
	 * @param array $atts
	 *
	 * @return string
	 */
	protected function paramsHtmlHolders( $atts ) { // phpcs:ignore:WordPress.NamingConventions.ValidFunctionName.MethodNameInvalid
		$inner = '';
		if ( isset( $this->settings['params'] ) && is_array( $this->settings['params'] ) ) {
			foreach ( $this->settings['params'] as $param ) {
				$param_value = $atts[ $param['param_name'] ] ?? '';
				$inner .= $this->singleParamHtmlHolder( $param, $param_value );
			}
		}

		return $inner;
	}

	/**
	 * Check is allowed to add another element inside current element.
	 *
	 * @return bool
	 * @since 4.8
	 */
	public function getAddAllowed() { // phpcs:ignore:WordPress.NamingConventions.ValidFunctionName.MethodNameInvalid
		return true;
	}
}
