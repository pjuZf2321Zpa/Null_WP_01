<?php
/**
 * Class that handles specific [vc_raw_html] shortcode.
 *
 * @see js_composer/include/templates/shortcodes/vc_raw_html.php
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/**
 * Class WPBakeryShortCode_Vc_Raw_Html
 */
class WPBakeryShortCode_Vc_Raw_Html extends WPBakeryShortCode {

	/**
	 * Add params html holders.
	 *
	 * @param array $param
	 * @param string $value
	 * @return string
	 */
	public function singleParamHtmlHolder( $param, $value ) {
		$output = '';
		// Compatibility fixes
		// TODO: check $old_names & &new_names. Leftover from copypasting?
		$old_names = [
			'yellow_message',
			'blue_message',
			'green_message',
			'button_green',
			'button_grey',
			'button_yellow',
			'button_blue',
			'button_red',
			'button_orange',
		];
		$new_names = [
			'alert-block',
			'alert-info',
			'alert-success',
			'btn-success',
			'btn',
			'btn-info',
			'btn-primary',
			'btn-danger',
			'btn-warning',
		];
		$value = str_ireplace( $old_names, $new_names, $value );

		$param_name = $param['param_name'] ?? '';

		if ( isset( $param['holder'] ) && 'hidden' !== $param['holder'] ) {
			if ( 'textarea_ace' === $param['type'] ) {
				// Only output the hidden field, prevent wpb_vc_param_value from rendering.
				$output .= WPB_Form_Field_Hidden::get([
					'name' => $param_name . '_code',
					'classes' => $param_name . '_code',
					'value' => wp_strip_all_tags( $value ),
					'is_value_escape' => false,
				]);
			}
		}
		return $output;
	}
}
