<?php
/**
 * Class that handles specific [vc_gmaps] shortcode.
 *
 * @see js_composer/include/templates/shortcodes/vc_gmaps.php
 * @deprecated
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/**
 * Class WPBakeryShortCode_Vc_Gmaps
 *
 * @deprecated
 */
class WPBakeryShortCode_Vc_Gmaps extends WPBakeryShortCode {
}
