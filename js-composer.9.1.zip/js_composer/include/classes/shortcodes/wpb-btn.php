<?php
/**
 * Class that handles specific [wpb_btn] shortcode.
 *
 * @see js_composer/include/templates/shortcodes/wpb_btn.php
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/**
 * Class WPBakeryShortCode_Wpb_Btn
 *
 * @since 9.1
 */
class WPBakeryShortCode_Wpb_Btn extends WPBakeryShortCode {
	/**
	 * Get CSS file names for wpb_btn shortcode.
	 *
	 * @since 9.1
	 * @return string[] CSS file names.
	 */
	public function get_shortcode_css_files() {
		return [ 'wpb_button' ];
	}

	/**
	 * Add a CSS variable declaration to the button style list.
	 *
	 * @param array  $styles Button style declarations.
	 * @param string $name CSS variable name without the --wpb-btn- prefix.
	 * @param string|null $value CSS variable value.
	 * @return array Button style declarations.
	 * @since 9.1
	 */
	public function add_css_variable( $styles, $name, $value ) {
		if ( '' !== $value && null !== $value ) {
			$styles[] = '--wpb-btn-' . $name . ': ' . $value . ';';
		}

		return $styles;
	}

	/**
	 * Get button CSS variables for shape, style colors and Design Options padding.
	 *
	 * @param array $atts Shortcode attributes.
	 * @return string[] Button style declarations.
	 * @since 9.1
	 */
	public function get_button_styles( $atts ) {
		$styles = $this->add_css_variable( [], 'border-radius', $this->get_shape_border_radius( $atts['shape'] ) );

		if ( '3d' === $atts['style'] ) {
			$styles = $this->add_3d_style_variables( $styles, $atts );
		} elseif ( 'gradient-custom' === $atts['style'] ) {
			$styles = $this->add_gradient_style_variables( $styles, $atts );
		} else {
			$styles = $this->add_custom_style_variables( $styles, $atts );
		}

		foreach ( $this->get_design_options_padding( $atts['css'] ) as $side => $padding_value ) {
			$styles = $this->add_css_variable( $styles, 'padding-' . $side, $padding_value );
		}

		return $styles;
	}

	/**
	 * Add 3d style CSS variables for custom colors and shadow.
	 *
	 * @param array $styles Button style declarations.
	 * @param array $atts Shortcode attributes.
	 * @return array Button style declarations.
	 * @since 9.1
	 */
	public function add_3d_style_variables( $styles, $atts ) {
		$custom_background = $atts['custom_background'];

		if ( $custom_background ) {
			$styles = $this->add_css_variable( $styles, 'background-color', $custom_background );
		}
		if ( $atts['custom_text'] ) {
			$styles = $this->add_css_variable( $styles, 'color', $atts['custom_text'] );
		}
		$shadow_color = $atts['custom_border'] ?: ( $custom_background ? vc_colorCreator( $custom_background, -11 ) : '' );

		return $this->add_css_variable( $styles, 'shadow-color', $shadow_color );
	}

	/**
	 * Add custom color CSS variables, background for all styles except outline.
	 *
	 * @param array $styles Button style declarations.
	 * @param array $atts Shortcode attributes.
	 * @return array Button style declarations.
	 * @since 9.1
	 */
	public function add_custom_style_variables( $styles, $atts ) {
		if ( 'outline' !== $atts['style'] ) {
			$styles = $this->add_css_variable( $styles, 'background-color', $atts['custom_background'] );
		}
		$styles = $this->add_css_variable( $styles, 'color', $atts['custom_text'] );
		$styles = $this->add_css_variable( $styles, 'hover-background-color', $atts['custom_hover_background'] );
		$styles = $this->add_css_variable( $styles, 'hover-color', $atts['custom_hover_text'] );

		return $this->add_border_style_variables( $styles, $atts );
	}

	/**
	 * Add border CSS variables for custom, modern and outline styles.
	 *
	 * @param array $styles Button style declarations.
	 * @param array $atts Shortcode attributes.
	 * @return array Button style declarations.
	 * @since 9.1
	 */
	public function add_border_style_variables( $styles, $atts ) {
		if ( ! in_array( $atts['style'], [ 'custom', 'modern', 'outline' ], true ) ) {
			return $styles;
		}
		$styles = $this->add_css_variable( $styles, 'border-color', $atts['custom_border'] );

		return $this->add_css_variable( $styles, 'hover-border-color', $atts['custom_hover_border'] );
	}

	/**
	 * Add gradient style CSS variables for gradient and text colors.
	 *
	 * @param array $styles Button style declarations.
	 * @param array $atts Shortcode attributes.
	 * @return array Button style declarations.
	 * @since 9.1
	 */
	public function add_gradient_style_variables( $styles, $atts ) {
		$styles = $this->add_css_variable( $styles, 'gradient-color-1', $atts['gradient_custom_color_1'] );
		$styles = $this->add_css_variable( $styles, 'gradient-color-2', $atts['gradient_custom_color_2'] );

		return $this->add_css_variable( $styles, 'color', $atts['gradient_text_color'] );
	}

	/**
	 * Get gradient button class that links the button to its style tags.
	 *
	 * @param string $uid Unique button id.
	 * @return string Gradient button class.
	 * @since 9.1
	 */
	public function get_gradient_button_class( $uid ) {
		return 'wpb_btn-gradient-btn-' . $uid;
	}

	/**
	 * Output gradient button style tags for its regular and hover states.
	 *
	 * @param string $uid Unique button id.
	 * @param array $atts Shortcode attributes.
	 * @since 9.1
	 */
	public function output_gradient_style_html( $uid, $atts ) {
		if ( 'gradient-custom' !== $atts['style'] ) {
			return;
		}

		$first_tag = 'style';
		$selector = '.' . esc_attr( 'wpb_btn-style-' . $atts['style'] ) . '.' . esc_attr( $this->get_gradient_button_class( $uid ) );

		$output = '<' . $first_tag . '>' . $selector . ':hover{' . esc_attr( implode( ';', $this->get_gradient_hover_css( $atts ) ) ) . ';}</' . $first_tag . '>';
		$output .= '<' . $first_tag . '>' . $selector . '{' . esc_attr( implode( ';', $this->get_gradient_css( $atts ) ) ) . ';}</' . $first_tag . '>';

		echo $output; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/**
	 * Get gradient button CSS declarations for its regular state.
	 *
	 * @param array $atts Shortcode attributes.
	 * @return string[] CSS declarations.
	 * @since 9.1
	 */
	public function get_gradient_css( $atts ) {
		$gradient_color_1 = 'var(--wpb-btn-gradient-color-1, ' . $atts['gradient_custom_color_1'] . ')';
		$gradient_color_2 = 'var(--wpb-btn-gradient-color-2, ' . $atts['gradient_custom_color_2'] . ')';

		return [
			'color: var(--wpb-btn-color, ' . $atts['gradient_text_color'] . ')',
			'border: none',
			'background-color: ' . $gradient_color_1,
			'background-image: -webkit-linear-gradient(left, ' . $gradient_color_1 . ' 0%, ' . $gradient_color_2 . ' 50%,' . $gradient_color_1 . ' 100%)',
			'background-image: linear-gradient(to right, ' . $gradient_color_1 . ' 0%, ' . $gradient_color_2 . ' 50%,' . $gradient_color_1 . ' 100%)',
			'-webkit-transition: all .2s ease-in-out',
			'transition: all .2s ease-in-out',
			'background-size: 200% 100%',
		];
	}

	/**
	 * Get gradient button CSS declarations for its hover state.
	 *
	 * @param array $atts Shortcode attributes.
	 * @return string[] CSS declarations.
	 * @since 9.1
	 */
	public function get_gradient_hover_css( $atts ) {
		return [
			'color: var(--wpb-btn-color, ' . $atts['gradient_text_color'] . ')',
			'background-color: var(--wpb-btn-gradient-color-2, ' . $atts['gradient_custom_color_2'] . ')',
			'border: none',
			'background-position: 100% 0',
		];
	}

	/**
	 * Get gradient button data attributes.
	 *
	 * @param array $atts Shortcode attributes.
	 * @return string[] Html attributes.
	 * @since 9.1
	 */
	public function get_gradient_attributes( $atts ) {
		return [
			'data-wpb-gradient-1="' . esc_attr( $atts['gradient_custom_color_1'] ) . '"',
			'data-wpb-gradient-2="' . esc_attr( $atts['gradient_custom_color_2'] ) . '"',
		];
	}

	/**
	 * Get base button classes for size, style, empty title, block layout and icon alignment.
	 *
	 * @param array $atts Shortcode attributes.
	 * @return string[] Button classes.
	 * @since 9.1
	 */
	public function get_button_classes( $atts ) {
		$button_classes = [
			'wpb_btn',
			'wpb_btn-size-' . $atts['size'],
			'wpb_btn-style-' . $atts['style'],
		];

		if ( '' === trim( $atts['title'] ) ) {
			$button_classes[] = 'wpb_btn-o-empty';
		}
		// inline B.C state prior 9.0.
		if ( 'true' === $atts['button_block'] && 'inline' !== $atts['align'] ) {
			$button_classes[] = 'wpb_btn-block';
		}
		if ( 'true' === $atts['add_icon'] ) {
			$button_classes[] = 'wpb_btn-icon-' . $atts['i_align'];
		}

		return $button_classes;
	}

	/**
	 * Get button icon html and enqueue its icon font.
	 *
	 * @param array $atts Shortcode attributes.
	 * @return string Icon html, empty when the button has no icon.
	 * @since 9.1
	 */
	public function get_button_icon_html( $atts ) {
		if ( 'true' !== $atts['add_icon'] ) {
			return '';
		}

		vc_icon_element_fonts_enqueue( $atts['i_type'] );
		$icon_key = 'i_icon_' . $atts['i_type'];

		if ( ! isset( $atts[ $icon_key ] ) ) {
			return '<i class="wpb_btn-icon fa fa-adjust"></i>';
		}

		$icon_class = esc_attr( $atts[ $icon_key ] );
		if ( 'pixelicons' === $atts['i_type'] ) {
			return '<i class="wpb_btn-icon"><span class="wpb_btn-icon-inner ' . $icon_class . '"></span></i>';
		}

		return '<i class="wpb_btn-icon ' . $icon_class . '"></i>';
	}

	/**
	 * Get button label html with an optional icon placed by alignment.
	 *
	 * @param array $atts Shortcode attributes.
	 * @return string Label html.
	 * @since 9.1
	 */
	public function get_button_label_html( $atts ) {
		$title = $atts['title'];
		$label_html = '' === trim( $title ) ? '<span class="wpb_btn-placeholder">&nbsp;</span>' : wp_kses_post( $title );
		$icon_html = $this->get_button_icon_html( $atts );

		if ( '' === $icon_html ) {
			return $label_html;
		}

		return 'left' === $atts['i_align'] ? $icon_html . ' ' . $label_html : $label_html . ' ' . $icon_html;
	}

	/**
	 * Get button link parts with href and title passed through their filters.
	 *
	 * @param string $link Encoded vc_link param value.
	 * @return array Link href, title, target and rel, empty when the link has no url.
	 * @since 9.1
	 */
	public function get_button_link( $link ) {
		$link = trim( $link );
		$link = vc_build_link( '||' === $link ? '' : $link );

		if ( '' === $link['url'] ) {
			return [];
		}

		return [
			'href' => apply_filters( 'vc_btn_a_href', $link['url'] ),
			'title' => apply_filters( 'vc_btn_a_title', $link['title'] ),
			'target' => $link['target'],
			'rel' => $link['rel'],
		];
	}

	/**
	 * Get button html attributes for gradient, styles, classes, link and onclick.
	 *
	 * @param array $button_link Button link parts, empty when the button has no link.
	 * @param array $atts Shortcode attributes.
	 * @param string $uid Unique button id.
	 * @return string Html attributes.
	 * @since 9.1
	 */
	public function get_button_attributes( $button_link, $atts, $uid ) {
		$styles = $this->get_button_styles( $atts );
		$button_classes = $this->get_button_classes( $atts );
		$attributes = [];
		if ( 'gradient-custom' === $atts['style'] ) {
			$attributes = $this->get_gradient_attributes( $atts );
			$button_classes[] = $this->get_gradient_button_class( $uid );
		}
		if ( $styles ) {
			$attributes[] = 'style="' . esc_attr( implode( ' ', $styles ) ) . '"';
		}
		$attributes[] = 'class="' . trim( esc_attr( $this->get_filtered_css_class( $button_classes, $atts ) ) ) . '"';
		$attributes = array_merge( $attributes, $this->get_button_link_attributes( $button_link ) );

		if ( ! empty( $atts['custom_onclick'] ) && $atts['custom_onclick_code'] ) {
			$attributes[] = 'onclick="' . esc_attr( $atts['custom_onclick_code'] ) . '"';
		}

		return implode( ' ', $attributes );
	}

	/**
	 * Get button link html attributes.
	 *
	 * @param array $button_link Button link parts, empty when the button has no link.
	 * @return string[] Html attributes.
	 * @since 9.1
	 */
	public function get_button_link_attributes( $button_link ) {
		if ( ! $button_link ) {
			return [];
		}

		$attributes = [
			'href="' . esc_url( trim( $button_link['href'] ) ) . '"',
			'title="' . esc_attr( trim( $button_link['title'] ) ) . '"',
		];
		if ( ! empty( $button_link['target'] ) ) {
			$attributes[] = 'target="' . esc_attr( trim( $button_link['target'] ) ) . '"';
		}
		if ( ! empty( $button_link['rel'] ) ) {
			$attributes[] = 'rel="' . esc_attr( trim( $button_link['rel'] ) ) . '"';
		}

		return $attributes;
	}

	/**
	 * Get border radius for a button shape.
	 *
	 * @param string $shape Button shape.
	 * @return string Border radius value.
	 * @since 9.1
	 */
	public function get_shape_border_radius( $shape ) {
		$shape_radius_values = [
			'square' => '0',
			'rounded' => '5px',
			'round' => '2em',
		];

		return $shape_radius_values[ $shape ] ?? $shape_radius_values['rounded'];
	}

	/**
	 * Extract top-level Design Options padding for transfer to the button.
	 *
	 * @param string $css Design Options CSS.
	 * @return array Padding values keyed by side.
	 * @since 9.1
	 */
	public function get_design_options_padding( $css ) {
		$top_level_declarations = $this->get_top_level_design_options_declarations( $css );

		if ( '' === $top_level_declarations ) {
			return [];
		}

		return $this->parse_padding_declarations( $top_level_declarations );
	}

	/**
	 * Get top-level vc_custom declarations from Design Options CSS.
	 *
	 * @param string $css Design Options CSS.
	 * @return string CSS declarations.
	 * @since 9.1
	 */
	protected function get_top_level_design_options_declarations( $css ) {
		$top_level_declarations = '';
		$depth = 0;

		for ( $i = 0, $length = strlen( $css ); $i < $length; $i++ ) {
			$char = $css[ $i ];

			if ( '{' === $char ) {
				$depth++;
				continue;
			}

			if ( '}' === $char ) {
				$depth = max( 0, $depth - 1 );
				continue;
			}

			if ( '.' !== $char || 0 !== $depth ) {
				continue;
			}

			$rule = $this->get_top_level_design_options_rule( $css, $i );
			if ( null === $rule ) {
				break;
			}

			if ( '' !== $rule['declarations'] ) {
				$top_level_declarations .= $rule['declarations'] . ';';
			}
			$i = $rule['closing_brace'];
		}

		return $top_level_declarations;
	}

	/**
	 * Get a top-level vc_custom CSS rule starting at a selector offset.
	 *
	 * @param string $css Design Options CSS.
	 * @param int    $offset Selector offset.
	 * @return array|null Rule declarations and closing brace offset.
	 * @since 9.1
	 */
	protected function get_top_level_design_options_rule( $css, $offset ) {
		$opening_brace = strpos( $css, '{', $offset );
		if ( false === $opening_brace ) {
			return null;
		}

		$selector = trim( substr( $css, $offset, $opening_brace - $offset ) );
		$closing_brace = strpos( $css, '}', $opening_brace );
		if ( false === $closing_brace ) {
			return null;
		}

		return [
			'declarations' => false === strpos( $selector, '.vc_custom_' ) ? '' : substr( $css, $opening_brace + 1, $closing_brace - $opening_brace - 1 ),
			'closing_brace' => $closing_brace,
		];
	}

	/**
	 * Parse padding declarations into side values.
	 *
	 * @param string $declarations CSS declarations.
	 * @return array Padding values keyed by side.
	 * @since 9.1
	 */
	protected function parse_padding_declarations( $declarations ) {
		$padding = [];
		if ( ! preg_match_all( '/(?:^|;)\s*(padding(?:-(top|right|bottom|left))?)\s*:\s*([^;]+)\s*/i', $declarations, $matches, PREG_SET_ORDER ) ) {
			return [];
		}

		foreach ( $matches as $declaration ) {
			$this->apply_padding_declaration( $padding, strtolower( $declaration[1] ), $declaration[3] );
		}

		return $padding;
	}

	/**
	 * Apply a padding declaration to the padding sides.
	 *
	 * @param array  $padding Padding values keyed by side.
	 * @param string $property Padding property name.
	 * @param string $raw_value Raw padding value.
	 * @return void
	 * @since 9.1
	 */
	protected function apply_padding_declaration( &$padding, $property, $raw_value ) {
		$value = trim( preg_replace( '/\s*!important\s*$/i', '', $raw_value ) );

		if ( '' === $value ) {
			return;
		}

		if ( 'padding' !== $property ) {
			$padding[ str_replace( 'padding-', '', $property ) ] = $value;
			return;
		}

		$padding = array_merge( $padding, $this->expand_padding_shorthand( $value ) );
	}

	/**
	 * Expand a padding shorthand value into individual sides.
	 *
	 * @param string $value Padding shorthand value.
	 * @return array Padding values keyed by side.
	 * @since 9.1
	 */
	protected function expand_padding_shorthand( $value ) {
		$values = preg_split( '/\s+/', $value );

		return [
			'top' => $values[0],
			'right' => $values[1] ?? $values[0],
			'bottom' => $values[2] ?? $values[0],
			'left' => $values[3] ?? ( $values[1] ?? $values[0] ),
		];
	}

	/**
	 * Get wrapper styles for alignment and transferred Design Options padding.
	 *
	 * @param array $atts Shortcode attributes.
	 * @return string[] Wrapper style declarations.
	 * @since 9.1
	 */
	public function get_wrapper_styles( $atts ) {
		$align = $atts['align'];
		$wrapper_styles = [];

		if ( 'inline' === $align ) {
			$wrapper_styles[] = '--wpb-btn-container-display: inline-block;';
			$wrapper_styles[] = '--wpb-btn-container-vertical-align: top;';
		} else {
			$wrapper_styles[] = '--wpb-btn-container-text-align: ' . $align . ';';
		}

		$padding = $this->get_design_options_padding( $atts['css'] );
		foreach ( array_keys( $padding ) as $side ) {
			$wrapper_styles[] = 'padding-' . $side . ': 0 !important;';
		}

		return $wrapper_styles;
	}

	/**
	 * Output wrapper style attribute.
	 *
	 * @param array $atts Shortcode attributes.
	 * @since 9.1
	 */
	public function output_wrapper_style( $atts ) {
		$wrapper_styles = $this->get_wrapper_styles( $atts );
		if ( ! $wrapper_styles ) {
			return;
		}

		echo 'style="' . esc_attr( implode( ' ', $wrapper_styles ) ) . '"';
	}

	/**
	 * Convert old attributes to new attributes.
	 *
	 * @param array $atts
	 * @return mixed
	 */
	public static function convertAttributesToButton3( $atts ) { // phpcs:ignore:Generic.Metrics.CyclomaticComplexity.TooHigh, CognitiveComplexity.Complexity.MaximumComplexity.TooHigh
		// size btn1 to size btn2.
		$btn1_sizes = [
			'wpb_regularsize',
			'btn-large',
			'btn-small',
			'btn-mini',
		];
		if ( isset( $atts['size'] ) && in_array( $atts['size'], $btn1_sizes, true ) ) {
			$atts['size'] = str_replace( $btn1_sizes, [
				'md',
				'lg',
				'sm',
				'xs',
			], $atts['size'] );
		}

		// Convert Btn1 href+target attributes to Btn2 `link` attribute.
		if ( ! isset( $atts['link'] ) && isset( $atts['href'] ) && strlen( $atts['href'] ) > 0 ) {
			$link = $atts['href'];
			$target = $atts['target'] ?? '';
			$title = $atts['title'] ?? $link;
			$atts['link'] = 'url:' . rawurlencode( $link ) . '|title:' . $title . ( strlen( $target ) > 0 ? '|target:' . rawurlencode( $target ) : '' );
		}

		if ( ( ! isset( $atts['add_icon'] ) || 'true' !== $atts['add_icon'] ) && isset( $atts['icon'] ) && strlen( $atts['icon'] ) > 0 && 'none' !== $atts['icon'] ) {
			// old icon from btn1 is set, let's convert it to new btn.
			$atts['add_icon'] = 'true';
			$atts['icon_type'] = 'pixelicons';
			$atts['icon_align'] = 'right';
			$atts['icon_pixelicons'] = 'vc_pixel_icon vc_pixel_icon-' . str_replace( 'wpb_', '', $atts['icon'] );
		}
		$haystack = [
			'rounded',
			'square',
			'round',
			'outlined',
			'square_outlined',
		];
		if ( isset( $atts['style'] ) && in_array( $atts['style'], $haystack, true ) ) {
			switch ( $atts['style'] ) {
				case 'rounded':
					$atts['style'] = 'flat';
					$atts['shape'] = 'rounded';
					break;
				case 'square':
					$atts['style'] = 'flat';
					$atts['shape'] = 'square';
					break;
				case 'round':
					$atts['style'] = 'flat';
					$atts['shape'] = 'round';
					break;
				case 'outlined':
					$atts['style'] = 'outline';
					break;
				case 'square_outlined':
					$atts['style'] = 'outline';
					$atts['shape'] = 'square';
					break;
			}
		}

		return $atts;
	}

	/**
	 * Title html output.
	 *
	 * @param string $title
	 *
	 * @return string
	 * @since 4.5
	 */
	protected function outputTitle( $title ) {
		return $this->output_compact_view_icon( $title );
	}

	/**
	 * Resolve link attributes for a custom URL link type.
	 *
	 * @param array $atts
	 * @return array
	 */
	public function resolve_link_custom( $atts ) {
		$atts['link'] = $atts['url'] ?? '';
		return $atts;
	}

	/**
	 * Resolve link attributes for a post permalink link type.
	 *
	 * @param array        $atts
	 * @param WP_Post|null $post
	 * @param string       $target_suffix
	 * @return array
	 */
	public function resolve_link_post_link( $atts, $post, $target_suffix ) {
		if ( $post instanceof WP_Post ) {
			$atts['link'] = 'url:' . rawurlencode( get_permalink( $post->ID ) ) . $target_suffix;
		}
		return $atts;
	}

	/**
	 * Resolve link attributes for a post thumbnail image link type.
	 *
	 * @param array        $atts
	 * @param WP_Post|null $post
	 * @param string       $target_suffix
	 * @return array
	 */
	public function resolve_link_image( $atts, $post, $target_suffix ) {
		$href = vc_gitem_template_attribute_post_image_url( '', [
			'post' => $post,
			'data' => '',
		] );
		if ( ! empty( $href ) ) {
			$atts['link'] = 'url:' . rawurlencode( $href ) . $target_suffix;
		}
		return $atts;
	}

	/**
	 * Resolve link attributes for a full-size post image link type.
	 *
	 * @param array        $atts
	 * @param WP_Post|null $post
	 * @param string       $target_suffix
	 * @return array
	 */
	public function resolve_link_image_full( $atts, $post, $target_suffix ) {
		$href = vc_gitem_template_attribute_post_full_image_url( '', [
			'post' => $post,
			'data' => '',
		] );
		if ( ! empty( $href ) ) {
			$atts['link'] = 'url:' . rawurlencode( $href ) . $target_suffix;
		}
		return $atts;
	}

	/**
	 * Resolve link attributes for a full-size image lightbox link type.
	 *
	 * @param array        $atts
	 * @param WP_Post|null $post
	 * @return array
	 */
	public function resolve_link_image_lightbox( $atts, $post ) {
		$href = vc_gitem_template_attribute_post_full_image_url( '', [
			'post' => $post,
			'data' => '',
		] );
		if ( ! empty( $href ) ) {
			$atts['link']              = 'url:' . rawurlencode( $href );
			$atts['vc_gitem_lightbox'] = 'lightbox[rel-' . md5( vc_request_param( 'shortcode_id' ) ) . ']';
		}
		return $atts;
	}

	/**
	 * Resolve link attributes for a thumbnail image lightbox link type.
	 *
	 * @param array        $atts
	 * @param WP_Post|null $post
	 * @return array
	 */
	public function resolve_link_image_full_lightbox( $atts, $post ) {
		$href = vc_gitem_template_attribute_post_image_url( '', [
			'post' => $post,
			'data' => '',
		] );
		if ( ! empty( $href ) ) {
			$atts['link']              = 'url:' . rawurlencode( $href );
			$atts['vc_gitem_lightbox'] = 'lightbox[rel-' . md5( vc_request_param( 'shortcode_id' ) ) . ']';
		}
		return $atts;
	}
}
