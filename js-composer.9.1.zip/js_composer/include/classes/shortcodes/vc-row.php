<?php
/**
 * Class that handles specific [vc_row] shortcode.
 *
 * @see js_composer/include/templates/shortcodes/vc_row.php
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/**
 * WPBakery Page Builder row
 *
 * @package WPBakeryPageBuilder
 */
class WPBakeryShortCode_Vc_Row extends WPBakeryShortCode {
	/**
	 * Predefined attributes for shortcode.
	 *
	 * @var array
	 */
	protected $predefined_atts = [
		'el_class' => '',
	];

	/**
	 * Non draggable class.
	 *
	 * @var string
	 */
	public $nonDraggableClass = 'vc-non-draggable-row';

	/**
	 * Constructor
	 *
	 * @param array $settings
	 */
	public function __construct( $settings ) {
		parent::__construct( $settings );
		$this->shortcodeScripts();
	}

	/**
	 * Register shortcode scripts.
	 */
	protected function shortcodeScripts() {
		wp_register_script( 'vc_jquery_skrollr_js', vc_asset_url( 'lib/vendor/dist/skrollr/dist/skrollr.min.js' ), [ 'jquery-core' ], WPB_VC_VERSION, true );
		wp_register_script( 'vc_youtube_iframe_api_js', 'https://www.youtube.com/iframe_api', [], WPB_VC_VERSION, true );
		wp_register_script( 'wpb_video_bg_container', vc_asset_url( 'js/shortcodes/frontend/functionality/wpb_video_bg_container.min.js' ), [ 'jquery-core' ], WPB_VC_VERSION, true );
		// wpb_parallax_container relies on window.vc_initVideoBackgrounds running first; depend on it so it's always enqueued alongside.
		wp_register_script( 'wpb_parallax_container', vc_asset_url( 'js/shortcodes/frontend/functionality/wpb_parallax_container.min.js' ), [ 'jquery-core', 'wpb_video_bg_container' ], WPB_VC_VERSION, true );
	}

	/**
	 * Get shortcode output.
	 *
	 * @param array $atts
	 * @param null $content
	 * @return mixed|string
	 */
	protected function content( $atts, $content = null ) {
		$prefix = '';

		return $prefix . $this->loadTemplate( $atts, $content ); // nosemgrep - escaping handled inside templates.
	}

	/**
	 * This returns block controls.
	 */
	public function getLayoutsControl() {
		global $vc_row_layouts;
		$controls_layout = '<span class="vc_row_layouts vc_control" title="' . esc_attr__( 'Select row layout', 'js_composer' ) . '">';
		$controls_layout .= '<i class="vc-composer-icon vc-c-layout"></i>';
		$controls_layout .= '<span class="vc_row_layouts-dropdown" role="menu">';
		foreach ( $vc_row_layouts as $layout ) {
			$controls_layout .= '<a href="#" class="vc_control-set-column set_columns" data-cells="' . esc_attr( $layout['cells'] ) . '" data-cells-mask="' . esc_attr( $layout['mask'] ) . '" title="' . esc_attr( $layout['title'] ) . '" role="menuitem"><i class="vc-composer-icon vc-c-icon-' . esc_attr( $layout['icon_class'] ) . '"></i></a>';
		}
		$controls_layout .= '<a href="#" class="vc_control-set-column set_columns custom_columns" data-cells="custom" data-cells-mask="custom" title="' . esc_attr__( 'Custom layout', 'js_composer' ) . '" role="menuitem"><i class="vc-composer-icon vc-c-edit"></i></a>';
		$controls_layout .= '</span>';
		$controls_layout .= '</span>';

		return $controls_layout;
	}

	/**
	 * Get column control settings.
	 *
	 * @since 9.0
	 *
	 * @param string $extended_css
	 * @return array
	 */
	public function get_column_control_settings( $extended_css = '' ) {
		$settings = [
			'delete' => [
				'classes' => 'column_delete vc_column-delete',
				'title' => __( 'Delete this row', 'js_composer' ),
				'icon' => 'vc-c-trash',
			],
			'clone' => [
				'classes' => 'column_clone vc_column-clone',
				'title' => __( 'Clone this row', 'js_composer' ),
				'icon' => 'vc-c-icon-clone',
			],
			'copy' => [
				'classes' => 'column_copy vc_column-copy',
				'title' => __( 'Copy this row', 'js_composer' ),
				'icon' => 'vc-c-icon-copy',
			],
			'paste' => [
				'classes' => 'column_paste vc_column-paste',
				'title' => __( 'Paste', 'js_composer' ),
				'icon' => 'vc-c-icon-paste',
			],
			'edit' => [
				'classes' => 'column_edit vc_column-edit',
				'title' => __( 'Edit this row', 'js_composer' ),
				'icon' => 'vc-c-edit',
			],
			'toggle' => [
				'classes' => 'column_toggle vc_column-toggle',
				'title' => __( 'Toggle row', 'js_composer' ),
				'icon' => 'vc-c-chevron-down',
			],
		];

		$move_access = vc_user_access()->part( 'dragndrop' )->checkStateAny( true, null )->get();
		if ( $move_access ) {
			$settings['move'] = [
				'classes' => 'column_move vc_column-move',
				'title' => __( 'Drag row to reorder', 'js_composer' ),
				'icon' => 'vc-c-param-group-dragndrop',
			];
		}

		return $settings;
	}

	/**
	 * Get column controls.
	 *
	 * @param mixed $controls
	 * @param string $extended_css
	 * @return string
	 * @throws \Exception
	 */
	public function getColumnControls( $controls, $extended_css = '' ) { // phpcs:ignore:Generic.Metrics.CyclomaticComplexity.TooHigh, CognitiveComplexity.Complexity.MaximumComplexity.TooHigh
		$output = '<div class="vc_controls vc_controls-row controls_row">';
		$controls_end = '</div>';
		// Create columns.
		$controls_layout = $this->getLayoutsControl();

		$control_list = $this->get_column_controls_html_list();
		$controls_move = $control_list['move'] ?? '';

		$editAccess = vc_user_access_check_shortcode_edit( $this->shortcode );
		$allAccess = vc_user_access_check_shortcode_all( $this->shortcode );

		if ( is_array( $controls ) && ! empty( $controls ) ) {
			foreach ( $controls as $control ) {
				$control_var = 'controls_' . $control;
				if ( ( $editAccess && 'edit' === $control ) || $allAccess ) {
					if ( isset( ${$control_var} ) ) {
						$output .= ${$control_var};
					}
				}
			}
			$output .= $controls_end;
		} elseif ( is_string( $controls ) ) {
			$control_var = 'controls_' . $controls;
			if ( ( $editAccess && 'edit' === $controls ) || $allAccess ) {
				if ( isset( ${$control_var} ) ) {
					$output .= ${$control_var} . $controls_end;
				}
			}
		} else {
			// Order: move, edit, layout, clone, copy/paste, toggle, delete.
			if ( $allAccess ) {
				$copypaste = vc_get_template( 'editors/partials/backend_copypaste_control.tpl.php' );
				$output .= $controls_move;
				$output .= $control_list['edit'];
				$output .= $controls_layout;
				$output .= $control_list['clone'];
				$output .= $copypaste;
				$output .= $control_list['toggle'];
				$output .= $control_list['delete'];
			} elseif ( $editAccess ) {
				$output .= $control_list['edit'];
				$output .= $control_list['toggle'];
			} else {
				$output .= $control_list['toggle'];
			}
			$output .= $controls_end;
		}

		return $output;
	}

	/**
	 * Load template.
	 *
	 * @param array $atts
	 * @param null|string $content
	 * @return string
	 * @throws \Exception
	 */
	public function contentAdmin( $atts, $content = null ) {
		$atts = shortcode_atts( $this->predefined_atts, $atts );

		$output = '';

		$column_controls = $this->getColumnControls( $this->settings( 'controls' ) );

		$output .= '<div data-element_type="' . $this->settings['base'] . '" class="' . $this->cssAdminClass() . '">';
		$output .= str_replace( '%column_size%', '1', $column_controls );
		$output .= '<div class="wpb_element_wrapper">';
		$output .= '<div class="vc_row vc_row-fluid wpb_row_container vc_container_for_children">';
		if ( '' === $content && ! empty( $this->settings['default_content_in_template'] ) ) {
			$output .= do_shortcode( shortcode_unautop( $this->settings['default_content_in_template'] ) );
		} else {
			$output .= do_shortcode( shortcode_unautop( $content ) );

		}
		$output .= '</div>';
		if ( isset( $this->settings['params'] ) ) {
			$inner = '';
			foreach ( $this->settings['params'] as $param ) {
				if ( ! isset( $param['param_name'] ) ) {
					continue;
				}
				$param_value = $atts[ $param['param_name'] ] ?? '';
				if ( is_array( $param_value ) ) {
					// Get first element from the array.
					reset( $param_value );
					$first_key = key( $param_value );
					$param_value = $param_value[ $first_key ];
				}
				$inner .= $this->singleParamHtmlHolder( $param, $param_value );
			}
			$output .= $inner;
		}
		$output .= '</div>';
		$output .= '</div>';

		return $output; // nosemgrep - we already escaped everything on this step.
	}

	/**
	 * Add admin class to css.
	 *
	 * @return string
	 * @throws \Exception
	 */
	public function cssAdminClass() {
		$sortable = ( vc_user_access_check_shortcode_all( $this->shortcode ) ? ' wpb_sortable' : ' ' . $this->nonDraggableClass );

		return 'wpb_' . $this->settings['base'] . $sortable . '' . ( ! empty( $this->settings['class'] ) ? ' ' . $this->settings['class'] : '' );
	}

	/**
	 * Custom admin block params.
	 *
	 * @return string
	 * @deprecated 4.5 - due to it is not used anywhere? 4.5
	 * @typo Bock - Block
	 */
	public function customAdminBockParams() {
		// this function is deprecated.

		return '';
	}

	/**
	 * Build additional styles.
	 *
	 * @param string $bg_image
	 * @param string $bg_color
	 * @param string $bg_image_repeat
	 * @param string $font_color
	 * @param string $padding
	 * @param string $margin_bottom
	 *
	 * @return string
	 * @deprecated 4.5
	 */
	public function buildStyle( $bg_image = '', $bg_color = '', $bg_image_repeat = '', $font_color = '', $padding = '', $margin_bottom = '' ) { // phpcs:ignore:Generic.Metrics.CyclomaticComplexity.TooHigh, CognitiveComplexity.Complexity.MaximumComplexity.TooHigh
		// this function is deprecated.

		$has_image = false;
		$style = '';
		$image_url = wp_get_attachment_url( (int) $bg_image );
		if ( $image_url ) {
			$has_image = true;
			$style .= 'background-image: url(' . $image_url . ');';
		}
		if ( ! empty( $bg_color ) ) {
			$style .= vc_get_css_color( 'background-color', $bg_color );
		}
		if ( ! empty( $bg_image_repeat ) && $has_image ) {
			if ( 'cover' === $bg_image_repeat ) {
				$style .= 'background-repeat:no-repeat;background-size: cover;';
			} elseif ( 'contain' === $bg_image_repeat ) {
				$style .= 'background-repeat:no-repeat;background-size: contain;';
			} elseif ( 'no-repeat' === $bg_image_repeat ) {
				$style .= 'background-repeat: no-repeat;';
			}
		}
		if ( ! empty( $font_color ) ) {
			$style .= vc_get_css_color( 'color', $font_color );
		}
		if ( '' !== $padding ) {
			$style .= 'padding: ' . ( preg_match( '/(px|em|\%|pt|cm)$/', $padding ) ? $padding : $padding . 'px' ) . ';';
		}
		if ( '' !== $margin_bottom ) {
			$style .= 'margin-bottom: ' . ( preg_match( '/(px|em|\%|pt|cm)$/', $margin_bottom ) ? $margin_bottom : $margin_bottom . 'px' ) . ';';
		}

		return empty( $style ) ? '' : ' style="' . esc_attr( $style ) . '"';
	}

	/**
	 * Get CSS file names for vc_row shortcode.
	 *
	 * @since 9.0
	 * @return string|array
	 */
	public function get_shortcode_css_files() {
		return [ 'vc_row', 'content_block', 'rows_columns', 'frontend_vc_row' ];
	}

	/**
	 * Add CSS classes for a row column gap.
	 *
	 * @since 9.1
	 * @param float $gap
	 * @param array $css_classes
	 * @return array
	 */
	public function get_column_gap_css_classes( $gap, $css_classes ) {
		if ( $gap <= 0 ) {
			return $css_classes;
		}

		$css_classes[] = 'vc_column-gap-' . $gap; // BC: legacy class.
		$css_classes[] = 'wpb_column-gap';

		return $css_classes;
	}

	/**
	 * Add inline style for a row column gap.
	 *
	 * @since 9.1
	 * @param float $gap
	 * @param string $raw_gap
	 * @param array $inline_styles
	 * @return array
	 */
	public function get_column_gap_inline_styles( $gap, $raw_gap, $inline_styles ) {
		if ( $gap <= 0 ) {
			return $inline_styles;
		}

		$inline_styles[] = '--wpb-column-gap: ' . wpb_format_with_css_unit( $raw_gap );

		return $inline_styles;
	}

	/**
	 * Get the style wrapper attribute built from inline styles.
	 *
	 * @since 9.1
	 * @param array $inline_styles
	 * @return string
	 */
	public function get_inline_style_wrapper_attributes( $inline_styles ) {
		if ( empty( $inline_styles ) ) {
			return '';
		}

		return 'style="' . esc_attr( implode( '; ', $inline_styles ) ) . '"';
	}
}
