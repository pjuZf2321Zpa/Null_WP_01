<?php
/**
 * Class that handles specific [vc_media_grid] shortcode.
 *
 * @see js_composer/include/templates/shortcodes/vc_media_grid.php
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

require_once vc_path_dir( 'SHORTCODES_DIR', 'vc-basic-grid.php' );
require_once vc_path_dir( 'SHORTCODES_DIR', 'traits/trait-image-preview.php' );

/**
 * Class WPBakeryShortCode_Vc_Media_Grid
 */
class WPBakeryShortCode_Vc_Media_Grid extends WPBakeryShortCode_Vc_Basic_Grid {
	use Image_Preview;

	/**
	 * WPBakeryShortCode_Vc_Media_Grid constructor.
	 *
	 * @param array $settings
	 */
	public function __construct( $settings ) {
		parent::__construct( $settings );
		add_filter( $this->shortcode . '_items_list', [
			$this,
			'setItemsIfEmpty',
		] );
	}


	/**
	 * Get name.
	 *
	 * @return mixed|string
	 */
	protected function getFileName() {
		return 'vc_basic_grid';
	}

	/**
	 * Set pagination attr.
	 *
	 * @param int $max_items
	 */
	protected function setPagingAll( $max_items ) {
		$this->atts['items_per_page'] = $this->atts['query_items_per_page'] = apply_filters( 'vc_basic_grid_items_per_page_all_max_items', self::$default_max_items );
	}

	/**
	 * Build WP_Query.
	 *
	 * @param array $atts
	 * @return array
	 */
	public function buildQuery( $atts ) {
		if ( empty( $atts['include'] ) ) {
			$atts['include'] = - 1;
		}
		$settings = [
			'include' => $atts['include'],
			'posts_per_page' => apply_filters( 'vc_basic_grid_max_items', self::$default_max_items ),
			'offset' => 0,
			'post_type' => 'attachment',
			'orderby' => 'post__in',
		];

		return $settings;
	}

	/**
	 * Set grid items.
	 *
	 * @param string $items
	 * @return string
	 */
	public function setItemsIfEmpty( $items ) {

		if ( empty( $items ) ) {
			require_once vc_path_dir( 'PARAMS_DIR', 'vc_grid_item/class-vc-grid-item.php' );
			$grid_item = new Vc_Grid_Item();
			$grid_item->setGridAttributes( $this->atts );
			$grid_item->shortcodes();
			$item = '[vc_gitem]<img src="' . esc_url( vc_asset_url( 'vc/vc_gitem_image.png' ) ) . '">[/vc_gitem]';
			$grid_item->parseTemplate( $item );
			$items = str_repeat( $grid_item->renderItem( get_post( (int) vc_request_param( 'vc_post_id' ) ) ), 3 );
		}

		return $items;
	}

	/**
	 * Set html param holder.
	 *
	 * @param array $param
	 * @param string $value
	 * @return string
	 */
	public function singleParamHtmlHolder( $param, $value ) { // phpcs:ignore:Generic.Metrics.CyclomaticComplexity.TooHigh, CognitiveComplexity.Complexity.MaximumComplexity.TooHigh
		$output = '';
		// Compatibility fixes
		// TODO: check $old_names & &new_names. Leftover from copypasting?
		$old_names = [
			'yellow_message',
			'blue_message',
			'green_message',
			'button_green',
			'button_grey',
			'button_yellow',
			'button_blue',
			'button_red',
			'button_orange',
		];
		$new_names = [
			'alert-block',
			'alert-info',
			'alert-success',
			'btn-success',
			'btn',
			'btn-info',
			'btn-primary',
			'btn-danger',
			'btn-warning',
		];
		$value = str_ireplace( $old_names, $new_names, $value );
		$param_name = $param['param_name'] ?? '';
		$type = $param['type'] ?? '';
		$class = $param['class'] ?? '';

		if ( 'include' === $param_name ) {
			return $this->imagesParamHtmlHolder( $param, $value );
		}

		if ( isset( $param['holder'] ) && 'hidden' !== $param['holder'] ) {
			$output .= '<' . $param['holder'] . ' class="wpb_vc_param_value ' . $param_name . ' ' . $type . ' ' . $class . '" name="' . $param_name . '">' . $value . '</' . $param['holder'] . '>';
		}

		return $output;
	}

	/**
	 * Get images param html holder.
	 *
	 * @param array $param
	 * @param string $value
	 * @return string
	 */
	protected function imagesParamHtmlHolder( $param, $value ) {
		$param_name = $param['param_name'];
		$type = $param['type'] ?? '';
		$class = $param['class'] ?? '';
		$image_ids = empty( $value ) ? [] : explode( ',', trim( $value ) );
		$output = WPB_Form_Field_Hidden::get([
			'name' => $param_name,
			'value' => $value,
			'classes' => 'wpb_vc_param_value ' . $param_name . ' ' . $type . ' ' . $class,
		]);

		$this->setSettings( 'logo', $this->images_preview_html( $image_ids, $param_name ) );

		return $output . $this->output_title_true( $this->settings['name'], ! empty( $image_ids ) );
	}

	/**
	 * Get CSS file names for vc_media_grid shortcode.
	 *
	 * @since 9.0
	 * @return string|array
	 */
	public function get_shortcode_css_files() {
		return [ 'vc_gallery', 'vc_image_gallery', 'wpb_button' ];
	}
}
