<?php
/**
 * Class that handles specific [vc_section] shortcode.
 *
 * @see js_composer/include/templates/shortcodes/vc_section.php
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/**
 * WPBakery Page Builder section
 *
 * @package WPBakeryPageBuilder
 */
class WPBakeryShortCode_Vc_Section extends WPBakeryShortCodesContainer {
	/**
	 * Add container classes.
	 *
	 * @since 9.1 The `$width` and `$i` parameters are deprecated and unused.
	 *
	 * @param string $deprecated Not used.
	 * @param string $deprecated_2 Not used.
	 * @return string
	 */
	public function containerHtmlBlockParams( $deprecated, $deprecated_2 ) {
		if ( '' !== $deprecated ) {
			_deprecated_argument( __METHOD__, '9.1', '$width' );
		}
		if ( '' !== $deprecated_2 ) {
			_deprecated_argument( __METHOD__, '9.1', '$i' );
		}

		return 'class="vc_section_container vc_container_for_children"';
	}

	/**
	 * WPBakeryShortCode_Vc_Section constructor.
	 *
	 * @param array $settings
	 */
	public function __construct( $settings ) {
		parent::__construct( $settings );
		$this->shortcodeScripts();
	}

	/**
	 * Register shortcode scripts.
	 */
	protected function shortcodeScripts() {
		wp_register_script( 'vc_jquery_skrollr_js', vc_asset_url( 'lib/vendor/dist/skrollr/dist/skrollr.min.js' ), [ 'jquery-core' ], WPB_VC_VERSION, true );
		wp_register_script( 'vc_youtube_iframe_api_js', 'https://www.youtube.com/iframe_api', [], WPB_VC_VERSION, true );
		wp_register_script( 'wpb_video_bg_container', vc_asset_url( 'js/shortcodes/frontend/functionality/wpb_video_bg_container.min.js' ), [ 'jquery-core' ], WPB_VC_VERSION, true );
		// wpb_parallax_container relies on window.vc_initVideoBackgrounds running first; depend on it so it's always enqueued alongside.
		wp_register_script( 'wpb_parallax_container', vc_asset_url( 'js/shortcodes/frontend/functionality/wpb_parallax_container.min.js' ), [ 'jquery-core', 'wpb_video_bg_container' ], WPB_VC_VERSION, true );
	}

	/**
	 * Additional CSS class for shortcode in admin.
	 *
	 * @return string
	 * @throws \Exception
	 */
	public function cssAdminClass() {
		$sortable = ( vc_user_access_check_shortcode_all( $this->shortcode ) ? ' wpb_sortable' : ' ' . $this->nonDraggableClass );

		return 'wpb_' . $this->settings['base'] . $sortable . '' . ( ! empty( $this->settings['class'] ) ? ' ' . $this->settings['class'] : '' );
	}

	/**
	 * Get column control settings.
	 *
	 * @since 9.0
	 *
	 * @param string $extended_css
	 * @return array
	 */
	public function get_column_control_settings( $extended_css = '' ) {
		$add_icon = 'vc-c-add-circle';
		$settings = [
			'add' => [
				'classes' => 'column_add vc_column-add',
				'title'   => esc_attr__( 'Add row', 'js_composer' ),
				'icon'    => $add_icon,
			],
			'delete' => [
				'classes' => 'column_delete vc_column-delete',
				'title'   => esc_attr__( 'Delete this section', 'js_composer' ),
				'icon'    => 'vc-c-trash',
			],
			'edit' => [
				'classes' => 'column_edit vc_column-edit',
				'title'   => esc_attr__( 'Edit this section', 'js_composer' ),
				'icon'    => 'vc-c-edit',
			],
			'clone' => [
				'classes' => 'column_clone vc_column-clone',
				'title'   => esc_attr__( 'Clone this section', 'js_composer' ),
				'icon'    => 'vc-c-icon-clone',
			],
			'copy' => [
				'classes' => 'column_copy vc_column-copy',
				'title'   => esc_attr__( 'Copy this section', 'js_composer' ),
				'icon'    => 'vc-c-icon-copy',
			],
			'paste' => [
				'classes' => 'column_paste vc_column-paste',
				'title'   => esc_attr__( 'Paste', 'js_composer' ),
				'icon'    => 'vc-c-icon-paste',
			],
			'toggle' => [
				'classes' => 'column_toggle vc_column-toggle',
				'title'   => esc_attr__( 'Toggle section', 'js_composer' ),
				'icon'    => 'vc-c-chevron-down',
			],
		];
		$move_access = vc_user_access()->part( 'dragndrop' )->checkStateAny( true, null )->get();
		if ( $move_access ) {
			$settings['move'] = [
				'classes' => 'column_move vc_column-move',
				'title' => __( 'Drag section to reorder', 'js_composer' ),
				'icon' => 'vc-c-param-group-dragndrop',
			];
		}

		return $settings;
	}

	/**
	 * Add column controls to shortcode output.
	 *
	 * @param string $controls
	 * @param string $extended_css
	 * @return string
	 * @throws \Exception
	 */
	public function getColumnControls( $controls = 'full', $extended_css = '' ) {
		$controls_start = '<div class="vc_controls vc_controls-visible controls_column' . ( ! empty( $extended_css ) ? " {$extended_css}" : '' ) . '">';

		$output = '<div class="vc_controls vc_controls-row controls_row controls_section">';
		$controls_end = '</div>';
		$control_list = $this->get_column_controls_html_list( $extended_css );
		$controls_move = $control_list['move'] ?? '';

		$editAccess = vc_user_access_check_shortcode_edit( $this->shortcode );
		$allAccess = vc_user_access_check_shortcode_all( $this->shortcode );

		if ( 'add' === $controls ) {
			return $controls_start . $control_list['add'] . $controls_end;
		}

		// Order: move, add, edit, clone, copy/paste, toggle, delete.
		if ( $allAccess ) {
			$copypaste = vc_get_template( 'editors/partials/backend_copypaste_control.tpl.php' );
			$output .= $controls_move;
			$output .= $control_list['add'];
			$output .= $control_list['edit'];
			$output .= $control_list['clone'];
			$output .= $copypaste;
			$output .= $control_list['toggle'];
			$output .= $control_list['delete'];
		} elseif ( $editAccess ) {
			$output .= $control_list['edit'];
			$output .= $control_list['toggle'];
		} else {
			$output .= $control_list['toggle'];
		}
		$output .= $controls_end;

		return $output;
	}

	/**
	 * Get admin output.
	 *
	 * @param array $atts
	 * @param null|string $content
	 *
	 * @return string
	 * @throws \Exception
	 */
	public function contentAdmin( $atts, $content = null ) { // phpcs:ignore:CognitiveComplexity.Complexity.MaximumComplexity.TooHigh
		$atts = shortcode_atts( $this->predefined_atts, $atts );

		$output = '';

		$column_controls = $this->getColumnControls();

		$output .= '<div data-element_type="' . $this->settings['base'] . '" class="' . $this->cssAdminClass() . '">';
		$output .= str_replace( '%column_size%', '1', $column_controls );
		$output .= '<div class="wpb_element_wrapper">';
		if ( isset( $this->settings['custom_markup'] ) && '' !== $this->settings['custom_markup'] ) {
			$markup = $this->settings['custom_markup'];
			$output .= $this->get_custom_markup( $markup );
		} else {
			$output .= '<div ' . $this->containerHtmlBlockParams( '', '' ) . '>';
			$output .= do_shortcode( shortcode_unautop( $content ) );
			$output .= '</div>';
		}
		if ( isset( $this->settings['params'] ) ) {
			$inner = '';
			foreach ( $this->settings['params'] as $param ) {
				if ( ! isset( $param['param_name'] ) ) {
					continue;
				}
				$param_value = $atts[ $param['param_name'] ] ?? '';
				if ( is_array( $param_value ) ) {
					// Get first element from the array.
					reset( $param_value );
					$first_key = key( $param_value );
					$param_value = $param_value[ $first_key ];
				}
				$inner .= $this->singleParamHtmlHolder( $param, $param_value );
			}
			$output .= $inner;
		}
		$output .= '</div>';
		$output .= '</div>';

		return $output; // nosemgrep - we already escaped everything on this step.
	}
}
