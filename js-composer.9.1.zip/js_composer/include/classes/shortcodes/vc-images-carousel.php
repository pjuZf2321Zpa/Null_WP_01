<?php
/**
 * Class that handles specific [vc_images_carousel] shortcode.
 *
 * @see js_composer/include/templates/shortcodes/vc_images_carousel.php
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

require_once vc_path_dir( 'SHORTCODES_DIR', 'vc-gallery.php' );

/**
 * Class WPBakeryShortCode_Vc_images_carousel
 */
class WPBakeryShortCode_Vc_Images_Carousel extends WPBakeryShortCode_Vc_Gallery {

	/**
	 * Carousel index.
	 *
	 * @var int
	 */
	protected static $carousel_index = 1;

	/**
	 * Admin labels rendered inside the title container.
	 *
	 * @var string
	 */
	protected $admin_labels = '';

	/**
	 * WPBakeryShortCode_Vc_images_carousel constructor.
	 *
	 * @param array $settings
	 */
	public function __construct( $settings ) {
		parent::__construct( $settings );
		$this->jsCssScripts();
	}

	/**
	 * Get CSS file names for vc_images_carousel shortcode.
	 *
	 * @since 9.0
	 * @return string|array
	 */
	public function get_shortcode_css_files() {
		return [ 'vc_carousel', 'vc_image_gallery', 'vc_gallery', 'vc_images_carousel' ];
	}

	/**
	 * Register element specific assets.
	 */
	public function jsCssScripts() {
		wp_register_script( 'vc_transition_bootstrap_js', vc_asset_url( 'lib/vc/vc_carousel/js/transition.min.js' ), [ 'jquery-core' ], WPB_VC_VERSION, true );
		wp_register_script( 'vc_carousel_js', vc_asset_url( 'lib/vc/vc_carousel/js/vc_carousel.min.js' ), [ 'vc_transition_bootstrap_js' ], WPB_VC_VERSION, true );
		wp_register_style( 'vc_carousel_css', vc_asset_url( 'lib/vc/vc_carousel/css/vc_carousel.min.css' ), [], WPB_VC_VERSION );
	}

	/**
	 * Render params and move admin labels into the title container.
	 *
	 * @param array $atts
	 * @return string
	 */
	protected function paramsHtmlHolders( $atts ) {
		$inner = parent::paramsHtmlHolders( $atts );

		if ( '' === $this->admin_labels ) {
			return $inner;
		}

		return str_replace( '</h4></div>', '</h4>' . $this->admin_labels . '</div>', $inner );
	}

	/**
	 * Add params html holders.
	 *
	 * @param array $param
	 * @param string $value
	 * @return string
	 */
	public function singleParamHtmlHolder( $param, $value ) {
		$output = parent::singleParamHtmlHolder( $param, $value );
		$this->add_admin_label( $param, $value );

		return $output;
	}

	/**
	 * Get carousel index.
	 *
	 * @return string
	 */
	public static function getCarouselIndex() {
		return ( self::$carousel_index++ ) . '-' . time();
	}

	/**
	 * Get element slider width.
	 *
	 * @param string $size
	 * @return string
	 */
	public function getSliderWidth( $size ) {
		global $_wp_additional_image_sizes;
		$width = '100%';
		if ( in_array( $size, get_intermediate_image_sizes(), true ) ) {
			if ( in_array( $size, [
				'thumbnail',
				'medium',
				'large',
			], true ) ) {
				$width = get_option( $size . '_size_w' ) . 'px';
			} elseif ( isset( $_wp_additional_image_sizes ) && isset( $_wp_additional_image_sizes[ $size ] ) ) {
				$width = $_wp_additional_image_sizes[ $size ]['width'] . 'px';
			}
		} else {
			preg_match_all( '/\d+/', $size, $matches );
			if ( count( $matches[0] ) > 1 ) {
				$width = $matches[0][0] . 'px';
			}
		}

		return $width;
	}
}
