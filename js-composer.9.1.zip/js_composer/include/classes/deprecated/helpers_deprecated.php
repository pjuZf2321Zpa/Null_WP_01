<?php
/**
 * WPBakery Page Builder deprecated helpers functions.
 *
 * Functions of here are deprecated and will be removed in future releases.
 *
 * @deprecated
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

if ( ! function_exists( 'add_shortcode_param' ) ) :
	/**
	 * Helper function to register new shortcode attribute hook.
	 *
	 * @param string $name - attribute name.
	 * @param callable $form_field_callback - hook, will be called when settings form is shown and attribute added to shortcode param list.
	 * @param string $script_url - javascript file url which will be attached at the end of settings form.
	 *
	 * @return bool
	 * @deprecated due to without prefix name 4.4
	 * @since 4.2
	 */
	function add_shortcode_param( $name, $form_field_callback, $script_url = null ) {
		_deprecated_function( 'add_shortcode_param', '4.4', 'vc_add_shortcode_param' );

		return vc_add_shortcode_param( $name, $form_field_callback, $script_url );
	}
endif;
if ( ! function_exists( 'get_row_css_class' ) ) :
	/**
	 * Get row css class.
	 *
	 * @return mixed|string
	 * @since 4.2
	 * @deprecated 4.2
	 */
	function get_row_css_class() {
		_deprecated_function( 'get_row_css_class', '4.2' );
		$custom = vc_settings()->get( 'row_css_class' );

		return ! empty( $custom ) ? $custom : 'vc_row-fluid';
	}
endif;
if ( ! function_exists( 'vc_generate_dependencies_attributes' ) ) :
	/**
	 * Generate dependencies attributes for shortcode.
	 *
	 * @return string
	 * @deprecated 5.2
	 */
	function vc_generate_dependencies_attributes() {
		_deprecated_function( 'vc_generate_dependencies_attributes', '5.1' );

		return '';
	}
endif;
if ( ! function_exists( 'vcExtractDimensions' ) ) :
	/**
	 * Extract width/height from string
	 *
	 * @param string $dimensions WxH.
	 * @return mixed array(width, height) or false.
	 * @since 4.7
	 *
	 * @deprecated since 5.8
	 */
	function vcExtractDimensions( $dimensions ) {
		_deprecated_function( 'vcExtractDimensions', '5.8', 'vc_extract_dimensions' );

		return vc_extract_dimensions( $dimensions );
	}
endif;
if ( ! function_exists( 'fieldAttachedImages' ) ) :
	/**
	 * Get image by attachment id.
	 *
	 * @param array $images IDs or srcs of images.
	 * @return string
	 * @since 4.2
	 * @deprecated since 2019, 5.8
	 */
	function fieldAttachedImages( $images = [] ) {
		_deprecated_function( 'fieldAttachedImages', '5.8', 'vc_field_attached_images' );

		return vc_field_attached_images( $images );
	}
endif;
if ( ! function_exists( 'getVcShared' ) ) :
	/**
	 * Get shared asset.
	 *
	 * @param string $asset
	 *
	 * @return array|string
	 * @deprecated
	 */
	function getVcShared( $asset = '' ) {
		_deprecated_function( 'getVcShared', '5.8', 'vc_get_shared' );

		return vc_get_shared( $asset );
	}
endif;
if ( ! function_exists( 'vc_wp_action' ) ) :
	/**
	 * Return a action param for ajax
	 *
	 * @return bool
	 * @since 4.8
	 * @deprecated 6.1
	 */
	function vc_wp_action() {
		_deprecated_function( 'vc_wp_action', '6.1', 'vc_request_param' );

		return vc_request_param( 'action' );
	}
endif;
if ( ! function_exists( 'set_vc_is_inline' ) ) :
	/**
	 * Set inline mode.
	 *
	 * @param bool $value
	 *
	 * @deprecated 5.2
	 * @since 4.3
	 */
	function set_vc_is_inline( $value = true ) {
		_deprecated_function( 'set_vc_is_inline', '5.2' );
		global $vc_is_inline;
		$vc_is_inline = $value;
	}
endif;
if ( ! function_exists( 'vc_is_editor' ) ) :
	/**
	 * Check is plugin editor;
	 *
	 * @deprecated since 4.8 ( use vc_is_frontend_editor ).
	 * @return bool
	 * @since 4.2
	 */
	function vc_is_editor() {
		_deprecated_function( 'vc_is_editor', '4.8', 'vc_is_frontend_editor' );
		return vc_is_frontend_editor();
	}
endif;
if ( ! function_exists( 'vc_disable_automapper' ) ) :
	/**
	 * Disable automapper.
	 *
	 * @deprecated 7.7 ( use modules settings )
	 * @param bool $disable
	 * @since 4.2
	 */
	function vc_disable_automapper( $disable = true ) {
		_deprecated_function( __FUNCTION__, '7.7', 'Use plugin settings module tab to disable automapper' );
		vc_automapper()->setDisabled( $disable );
	}
endif;
if ( ! function_exists( 'vc_automapper_is_disabled' ) ) :
	/**
	 * Check is automapper disabled.
	 *
	 * @deprecated 7.7 ( use modules settings )
	 * @return bool
	 * @since 4.2
	 */
	function vc_automapper_is_disabled() {
		_deprecated_function( __FUNCTION__, '7.7', 'Use plugin settings module tab to disable automapper' );
		return vc_automapper()->disabled();
	}
endif;
if ( ! function_exists( 'visual_composer' ) ) :
	/**
	 * Alias for wpbakery.
	 *
	 * @return Vc_Base
	 * @since 4.2
	 * @deprecated 5.8, use wpbakery() instead
	 */
	function visual_composer() {
		_deprecated_function( __FUNCTION__, '5.8', 'wpbakery' );
		return wpbakery();
	}
endif;
if ( ! function_exists( 'js_composer_body_class' ) ) :
	/**
	 * Method adds css class to body tag.
	 *
	 * Hooked class method by body_class WP filter. Method adds custom css class to body tag of the page to help
	 * identify and build design specially for VC shortcodes.
	 * Used in wp-content/plugins/js_composer/include/classes/core/class-vc-base.php\Vc_Base\bodyClass.
	 *
	 * @param array $classes
	 *
	 * @return array
	 * @since 4.2
	 * @deprecated 8.5
	 */
	function js_composer_body_class( $classes ) {
		_deprecated_function( __FUNCTION__, '8.5', 'wpb_body_class' );
		return wpb_body_class( $classes );
	}
endif;
if ( ! function_exists( 'vc_set_default_content_for_post_type' ) ) :
	/**
	 * Set default content by post type in editor.
	 *
	 * Data for post type templates stored in settings.
	 *
	 * @param string|null $post_content
	 * @param WP_Post $post
	 * @return string|null
	 * @throws Exception
	 * @deprecated 8.5
	 * @since 4.12
	 */
	function vc_set_default_content_for_post_type( $post_content, $post ) {
		_deprecated_function( __FUNCTION__, '8.5', 'vc_set_default_content_for_post_type_back_editor' );
		return vc_set_default_content_for_post_type_back_editor( $post_content, $post );
	}
endif;
if ( ! function_exists( 'vc_add_css_animation' ) ) :
	/**
	 * Add CSS Animation to element.
	 *
	 * @return mixed|void
	 * @deprecated 4.12
	 */
	function vc_add_css_animation() {
			_deprecated_function( __FUNCTION__, '4.12', 'vc_map_add_css_animation' );
			return vc_map_add_css_animation();
	}
endif;
if ( ! function_exists( 'vc_add_css_animation' ) ) :
	/**
	 * Get configuration for post link controls.
	 *
	 * @return array
	 * @deprecated 8.6
	 */
	function vc_layout_sub_controls() {
		_deprecated_function( __FUNCTION__, '8.6' );
		return [
			[
				'link_post',
				esc_html__( 'Link to post', 'js_composer' ),
			],
			[
				'no_link',
				esc_html__( 'No link', 'js_composer' ),
			],
			[
				'link_image',
				esc_html__( 'Link to bigger image', 'js_composer' ),
			],
		];
	}
endif;
if ( ! function_exists( 'vc_pixel_icons' ) ) :
	/**
	 * Get configuration for pixel_icons shortcode.
	 *
	 * @return array
	 * @deprecated 8.6
	 */
	function vc_pixel_icons() {
		_deprecated_function( __FUNCTION__, '8.6', "vc_get_shared( 'pixel icons' )" );
		return vc_get_shared( 'pixel icons' );
	}
endif;
if ( ! function_exists( 'vc_icons_arr' ) ) :
	/**
	 * Get configuration for icons attribute.
	 *
	 * @return array
	 * @deprecated 8.6
	 */
	function vc_icons_arr() {
		_deprecated_function( __FUNCTION__, '8.6', "vc_get_shared( 'icons arr' )" );
		return vc_get_shared( 'icons arr' );
	}
endif;
if ( ! function_exists( 'vc_size_arr' ) ) :
	/**
	 * Get configuration for sizes attribute.
	 *
	 * @return array
	 * @deprecated 8.6
	 */
	function vc_size_arr() {
		_deprecated_function( __FUNCTION__, '8.6', "vc_get_shared( 'sizes arr' )" );
		return vc_get_shared( 'sizes arr' );
	}
endif;
if ( ! function_exists( 'vc_colors_arr' ) ) :
	/**
	 * Get configuration for colors attribute.
	 *
	 * @return array
	 * @deprecated 8.6
	 */
	function vc_colors_arr() {
		_deprecated_function( __FUNCTION__, '8.6', "vc_get_shared( 'colors arr' )" );
		return vc_get_shared( 'colors arr' );
	}
endif;
if ( ! function_exists( 'vc_target_param_list' ) ) :
	/**
	 * Get configuration for target controls.
	 *
	 * @return array
	 * @deprecated 8.6
	 */
	function vc_target_param_list() {
		_deprecated_function( __FUNCTION__, '8.6', "vc_get_shared( 'target param list' )" );
		return vc_get_shared( 'target param list' );
	}
endif;
if ( ! function_exists( 'vc_siteAttachedImages' ) ) :
	/**
	 *  Helper function which returns list of site attached images, and if image is attached to the current post it adds class 'added'
	 *
	 * @param array $att_ids
	 *
	 * @return string
	 * @since 4.11
	 * @deprecated 8.8
	 */
	function vc_siteAttachedImages( $att_ids = [] ) {
		_deprecated_function( __FUNCTION__, '8.8' );

		$output = '';

		$limit = (int) apply_filters( 'vc_site_attached_images_query_limit', - 1 );
		$media_images = get_posts( [
			'post_type' => 'attachment',
			'orderby' => 'ID',
			'numberposts' => $limit,
		] );
		foreach ( $media_images as $image_post ) {
			$thumb_src = wp_get_attachment_image_src( $image_post->ID );
			$thumb_src = $thumb_src[0];

			$class = ( in_array( $image_post->ID, $att_ids, true ) ) ? ' class="added"' : '';

			$output .= '<li' . $class . '>
						<img rel="' . esc_attr( (string) $image_post->ID ) . '" src="' . esc_url( $thumb_src ) . '" />
						<span class="img-added">' . esc_html__( 'Added', 'js_composer' ) . '</span>
					</li>';
		}

		if ( '' !== $output ) {
			$output = '<ul class="gallery_widget_img_select">' . $output . '</ul>';
		}

		return $output;
	}
endif;
if ( ! function_exists( 'vc_parse_options_string' ) ) :
	/**
	 * String parser for options.
	 *
	 * @param string $initial_string
	 * @param string $tag
	 * @param string $param
	 *
	 * @return array
	 * @throws \Exception
	 * @since 4.2
	 * @deprecated 8.8
	 */
	function vc_parse_options_string( $initial_string, $tag, $param ) { // phpcs:ignore:Generic.Metrics.CyclomaticComplexity.TooHigh, CognitiveComplexity.Complexity.MaximumComplexity.TooHigh
		_deprecated_function( __FUNCTION__, '8.8' );

		$options = [];
		$option_settings_list = [];
		$settings = WPBMap::getParam( $tag, $param );

		foreach ( preg_split( '/\|/', $initial_string ) as $value ) {
			if ( preg_match( '/\:/', $value ) ) {
				$split = preg_split( '/\:/', $value );
				$option_name = $split[0];
				$option_settings = vc_param_options_get_settings( $option_name, $settings['options'] );
				$option_settings_list[ $option_name ] = $option_settings;
				if ( isset( $option_settings['type'] ) && 'checkbox' === $option_settings['type'] ) {
					$option_value = array_map( 'vc_param_options_parse_values', preg_split( '/\,/', $split[1] ) );
				} else {
					$option_value = rawurldecode( $split[1] );
				}
				$options[ $option_name ] = $option_value;
			}
		}
		if ( isset( $settings['options'] ) ) {
			foreach ( $settings['options'] as $setting_option ) {
				if ( 'separator' !== $setting_option['type'] && isset( $setting_option['value'] ) && empty( $options[ $setting_option['name'] ] ) ) {
					$options[ $setting_option['name'] ] = 'checkbox' === $setting_option['type'] ? preg_split( '/\,/', $setting_option['value'] ) : $setting_option['value'];
				}
				if ( isset( $setting_option['name'] ) && isset( $options[ $setting_option['name'] ] ) && isset( $setting_option['value_type'] ) ) {
					if ( 'integer' === $setting_option['value_type'] ) {
						$options[ $setting_option['name'] ] = (int) $options[ $setting_option['name'] ];
					} elseif ( 'float' === $setting_option['value_type'] ) {
						$options[ $setting_option['name'] ] = (float) $options[ $setting_option['name'] ];
					} elseif ( 'boolean' === $setting_option['value_type'] ) {
						$options[ $setting_option['name'] ] = (bool) $options[ $setting_option['name'] ];
					}
				}
			}
		}

		return $options;
	}
endif;
if ( ! function_exists( 'vc_is_responsive_disabled' ) ) :
	/**
	 * Check if plugin no_resonsive_css settings is disabled.
	 *
	 * @return bool
	 * @deprecated 8.8
	 */
	function vc_is_responsive_disabled() {
		_deprecated_function( __FUNCTION__, '8.8' );

		$disable_responsive = vc_settings()->get( 'not_responsive_css' );

		return '1' === $disable_responsive;
	}
endif;
if ( ! function_exists( 'vc_map_integrate_get_atts' ) ) :
	/**
	 * Retrieves and processes default attributes for integrated shortcodes.
	 *
	 * This function fetches the parameters for a base shortcode and an integrated shortcode,
	 * then processes these parameters to generate a default set of attributes.
	 * The resulting associative array of attributes is returned.
	 *
	 * @param string $base_shortcode
	 * @param string $integrated_shortcode
	 * @param string $field_prefix
	 * @return array
	 * @throws Exception
	 * @since 4.5
	 * @deprecated 8.8
	 */
	function vc_map_integrate_get_atts( $base_shortcode, $integrated_shortcode, $field_prefix = '' ) {
		_deprecated_function( __FUNCTION__, '8.8' );

		$params = vc_map_integrate_get_params( $base_shortcode, $integrated_shortcode, $field_prefix );
		$atts = [];
		if ( ! empty( $params ) ) {
			foreach ( $params as $param ) {
				$value = '';
				if ( isset( $param['value'] ) ) {
					if ( isset( $param['settings']['default'] ) ) {
						$value = $param['settings']['default'];
					} elseif ( is_array( $param['value'] ) ) {
						reset( $param['value'] );
						$value = current( $param['value'] );
					} else {
						$value = $param['value'];
					}
				}
				$atts[ $param['param_name'] ] = $value;
			}
		}

		return $atts;
	}
endif;
if ( ! function_exists( 'vc_map_add_css_animation' ) ) :
	/**
	 * Get CSS animation for shortcode params.
	 *
	 * @param bool $label
	 * @return array
	 * @deprecated 9.0 use vc_config()->get_css_animation()
	 */
	function vc_map_add_css_animation( $label = true ) {
		_deprecated_function( __FUNCTION__, '9.0', 'vc_config()->get_css_animation()' );

		return vc_config()->get_css_animation( $label );
	}
endif;
if ( ! function_exists( 'vc_navbar_undoredo' ) ) :
	/**
	 * Undo Redo navbar for frontend editor.
	 *
	 * @deprecated 9.0 without replacement
	 */
	function vc_navbar_undoredo() {
		_deprecated_function( __FUNCTION__, '9.0' );

		/**
		 * Class Vc_Navbar_Undoredo
		 *
		 * @deprecated 9.0
		 */
		class Vc_Navbar_Undoredo {
			/**
			 * Vc_Navbar_Undoredo constructor.
			 */
			public function __construct() {
				// Backend.
				add_filter( 'vc_nav_controls', [
					$this,
					'addControls',
				] );

				// Frontend.
				add_filter( 'vc_nav_front_controls', [
					$this,
					'addControls',
				] );
			}

			/**
			 * Add undo/redo controls.
			 *
			 * @param array $controls
			 * @return array
			 */
			public function addControls( $controls ) { // phpcs:ignore WordPress.NamingConventions.ValidFunctionName.MethodNameInvalid
				$undo_title = esc_attr( wpb_get_title_with_shortcut( 'Undo' ) );
				$redo_title = esc_attr( wpb_get_title_with_shortcut( 'Redo' ) );
				$controls[] = [
					'undo',
					'<li class="vc_hide-mobile vc_hide-desktop-more">
                        <a id="vc_navbar-undo" class="vc_icon-btn vc_undo-redo vc_undo-button vc_hide-mobile" disabled tabindex="0" title="' . $undo_title . '" role="button" aria-label="' . $undo_title . '">
                            <i class="vc-composer-icon vc-c-icon-undo" aria-hidden="true"></i>
                            <p class="vc_hide-desktop" aria-hidden="true">' . __( 'Undo', 'js_composer' ) . '</p>
                        </a>
                    </li>',
				];
				$controls[] = [
					'redo',
					'<li class="vc_hide-mobile vc_hide-desktop-more">
                        <a id="vc_navbar-redo" class="vc_icon-btn vc_undo-redo vc_redo-button vc_hide-mobile" disabled tabindex="0" title="' . $redo_title . '" role="button" aria-label="' . $redo_title . '">
                            <i class="vc-composer-icon vc-c-icon-redo" aria-hidden="true"></i>
                            <p class="vc_hide-desktop" aria-hidden="true">' . __( 'Redo', 'js_composer' ) . '</p>
                        </a>
                    </li>',
				];

				return $controls;
			}
		}
	}
endif;
if ( ! function_exists( 'vc_vc_grid_item_form_field' ) ) :
	/**
	 * Output for grid item form field.
	 *
	 * @param array $settings
	 * @param string $value
	 * @return string
	 * @deprecated 9.1 use Vc_Grid_Item::get_grid_item_form_field()
	 */
	function vc_vc_grid_item_form_field( $settings, $value ) {
		_deprecated_function( 'vc_vc_grid_item_form_field', '9.1', 'Vc_Grid_Item::get_grid_item_form_field' );
		require_once vc_path_dir( 'PARAMS_DIR', 'vc_grid_item/class-vc-grid-item.php' );

		return Vc_Grid_Item::get_grid_item_form_field( $settings, $value );
	}
endif;
if ( ! function_exists( 'vc_load_vc_grid_item_param' ) ) :
	/**
	 * Load vc_grid_item param
	 *
	 * @deprecated 9.1 use Vc_Grid_Item::load_grid_item_param()
	 */
	function vc_load_vc_grid_item_param() {
		_deprecated_function( 'vc_load_vc_grid_item_param', '9.1', 'Vc_Grid_Item::load_grid_item_param' );
		require_once vc_path_dir( 'PARAMS_DIR', 'vc_grid_item/class-vc-grid-item.php' );
		Vc_Grid_Item::load_grid_item_param();
	}
endif;
if ( ! function_exists( 'vc_gitem_post_data_get_link_target_frontend_editor' ) ) :
	/**
	 * Add target attribute to link.
	 *
	 * @param string $target
	 * @return string
	 * @deprecated 9.1 use Vc_Grid_Item::get_link_target_frontend_editor()
	 */
	function vc_gitem_post_data_get_link_target_frontend_editor( $target ) { // phpcs:ignore:Generic.CodeAnalysis.UnusedFunctionParameter.Found
		_deprecated_function( 'vc_gitem_post_data_get_link_target_frontend_editor', '9.1', 'Vc_Grid_Item::get_link_target_frontend_editor' );
		require_once vc_path_dir( 'PARAMS_DIR', 'vc_grid_item/class-vc-grid-item.php' );

		return Vc_Grid_Item::get_link_target_frontend_editor();
	}
endif;
if ( ! function_exists( 'vc_gitem_post_data_get_link_rel_frontend_editor' ) ) :
	/**
	 * Add rel attribute to link.
	 *
	 * @param string $rel
	 * @return string
	 * @deprecated 9.1 use Vc_Grid_Item::get_link_rel_frontend_editor()
	 */
	function vc_gitem_post_data_get_link_rel_frontend_editor( $rel ) {
		_deprecated_function( 'vc_gitem_post_data_get_link_rel_frontend_editor', '9.1', 'Vc_Grid_Item::get_link_rel_frontend_editor' );
		require_once vc_path_dir( 'PARAMS_DIR', 'vc_grid_item/class-vc-grid-item.php' );

		return Vc_Grid_Item::get_link_rel_frontend_editor( $rel );
	}
endif;
if ( ! function_exists( 'vc_gitem_create_link' ) ) :
	/**
	 * Create link.
	 *
	 * @param array $atts
	 * @param string $default_class
	 * @param string $title
	 * @return string
	 * @deprecated 9.1 use Vc_Grid_Item::create_link()
	 */
	function vc_gitem_create_link( $atts, $default_class = '', $title = '' ) {
		_deprecated_function( 'vc_gitem_create_link', '9.1', 'Vc_Grid_Item::create_link' );
		require_once vc_path_dir( 'PARAMS_DIR', 'vc_grid_item/class-vc-grid-item.php' );

		return Vc_Grid_Item::create_link( $atts, $default_class, $title );
	}
endif;
if ( ! function_exists( 'vc_gitem_create_link_real' ) ) :
	/**
	 * Create real link.
	 *
	 * @param array $atts
	 * @param WP_Post $post
	 * @param string $default_class
	 * @param string $title
	 * @return string
	 * @deprecated 9.1 use Vc_Grid_Item::create_link_real()
	 */
	function vc_gitem_create_link_real( $atts, $post, $default_class = '', $title = '' ) {
		_deprecated_function( 'vc_gitem_create_link_real', '9.1', 'Vc_Grid_Item::create_link_real' );
		require_once vc_path_dir( 'PARAMS_DIR', 'vc_grid_item/class-vc-grid-item.php' );

		return Vc_Grid_Item::create_link_real( $atts, $post, $default_class, $title );
	}
endif;
if ( ! function_exists( 'vc_gitem_post_data_get_link_link_frontend_editor' ) ) :
	/**
	 * Get link.
	 *
	 * @param string $link
	 * @return string
	 * @deprecated 9.1 use Vc_Grid_Item::get_link_frontend_editor()
	 */
	function vc_gitem_post_data_get_link_link_frontend_editor( $link ) {
		_deprecated_function( 'vc_gitem_post_data_get_link_link_frontend_editor', '9.1', 'Vc_Grid_Item::get_link_frontend_editor' );
		require_once vc_path_dir( 'PARAMS_DIR', 'vc_grid_item/class-vc-grid-item.php' );

		return Vc_Grid_Item::get_link_frontend_editor( $link );
	}
endif;
if ( ! function_exists( 'wpb_remove_custom_html' ) ) :
	/**
	 * Used to remove raw_html/raw_js elements from content.
	 *
	 * @param string $content
	 * @return string
	 * @since 6.3.0
	 * @deprecated 9.1 use vc_manager()->vc()->postAdmin()->remove_custom_html()
	 */
	function wpb_remove_custom_html( $content ) {
		_deprecated_function( 'wpb_remove_custom_html', '9.1', 'vc_manager()->vc()->postAdmin()->remove_custom_html()' );

		return vc_manager()->vc()->postAdmin()->remove_custom_html( $content );
	}
endif;
if ( ! function_exists( 'wpb_remove_custom_onclick' ) ) :
	/**
	 * Remove custom onclick.
	 *
	 * @param array $match_list
	 * @return string
	 * @deprecated 9.1 use vc_manager()->vc()->postAdmin()->remove_custom_onclick()
	 */
	function wpb_remove_custom_onclick( $match_list ) {
		_deprecated_function( 'wpb_remove_custom_onclick', '9.1', 'vc_manager()->vc()->postAdmin()->remove_custom_onclick()' );

		return vc_manager()->vc()->postAdmin()->remove_custom_onclick( $match_list );
	}
endif;
if ( ! function_exists( 'wpb_get_elements_with_custom_html' ) ) :
	/**
	 * Get elements list that use custom html in our plugin core.
	 *
	 * @return array
	 * @since 7.8
	 * @deprecated 9.1 use vc_manager()->vc()->postAdmin()->get_elements_with_custom_html()
	 */
	function wpb_get_elements_with_custom_html() {
		_deprecated_function( 'wpb_get_elements_with_custom_html', '9.1', 'vc_manager()->vc()->postAdmin()->get_elements_with_custom_html()' );

		return vc_manager()->vc()->postAdmin()->get_elements_with_custom_html();
	}
endif;

/**
 * Shortcode attributes
 *
 * @return array
 */
function vc_btn_element_params() { // phpcs:ignore:CognitiveComplexity.Complexity.MaximumComplexity.TooHigh

	$pixel_icons = vc_get_shared( 'pixel icons' );
	require_once vc_path_dir( 'CONFIG_DIR', 'content/vc-icon-element.php' );

	$icons_params = vc_map_integrate_shortcode(
		vc_icon_element_params(),
		'i_',
		esc_html__( 'Icon', 'js_composer' ),
		[
			'include_only_regex' => '/^(type|icon_\w*)/', // we need only type, icon_fontawesome, icon_blabla..., NOT color and etc.
		],
		[
			'element' => 'add_icon',
			'value' => 'true',
		]
	);
	// populate integrated vc_icons params.
	if ( $icons_params ) {
		foreach ( $icons_params as $key => $param ) {
			if ( is_array( $param ) && ! empty( $param ) ) {
				if ( 'i_type' === $param['param_name'] ) {
					// append pixelicons to dropdown.
					$icons_params[ $key ]['value'][ esc_html__( 'Pixel', 'js_composer' ) ] = 'pixelicons';
				}
				if ( isset( $param['admin_label'] ) ) {
					// remove admin label.
					unset( $icons_params[ $key ]['admin_label'] );
				}
			}
		}
	}
	$params = array_merge( [
		[
			'type' => 'textfield',
			'heading' => esc_html__( 'Text', 'js_composer' ),
			'param_name' => 'title',
			// fully compatible to btn1 and btn2.
			'value' => esc_html__( 'Text on the button', 'js_composer' ),
			'section' => 'general',
		],
		[
			'type' => 'link',
			'heading' => esc_html__( 'URL', 'js_composer' ),
			'param_name' => 'link',
			'section' => 'general',
		],
		[
			'type' => 'dropdown',
			'heading' => esc_html__( 'Shape', 'js_composer' ),
			'param_name' => 'shape',
			// need to be converted.
			'value' => [
				esc_html__( 'Rounded', 'js_composer' ) => 'rounded',
				esc_html__( 'Square', 'js_composer' ) => 'square',
				esc_html__( 'Round', 'js_composer' ) => 'round',
			],
			'edit_field_class' => 'vc_col-xs-6',
			'section' => 'general',
		],
		[
			'type' => 'button_group',
			'heading' => esc_html__( 'Alignment', 'js_composer' ),
			'param_name' => 'align',
			// compatible with btn2, default left to be compatible with btn1.
			'value'       => vc_config()->get_text_align_param_value( [ 'justify' ] ),
			'settings' => [
				'default' => 'left',
			],
			'edit_field_class' => 'vc_col-xs-6',
			'section' => 'general',
		],
		[
			'type' => 'button_group',
			'heading' => esc_html__( 'Size', 'js_composer' ),
			'param_name' => 'size',
			// compatible with btn2, default md, but need to be converted from btn1 to btn2.
			'value' => vc_config()->get_size_param_value( [ 'xs', 'sm', 'md', 'lg' ] ),
			'settings' => [
				'default' => 'md',
			],
			'section' => 'general',
		],
		[
			'type' => 'dropdown',
			'heading' => esc_html__( 'Style', 'js_composer' ),
			'param_name' => 'style',
			'value' => [
				esc_html__( 'Modern', 'js_composer' ) => 'modern',
				esc_html__( 'Classic', 'js_composer' ) => 'classic',
				esc_html__( 'Flat', 'js_composer' ) => 'flat',
				esc_html__( 'Outline', 'js_composer' ) => 'outline',
				esc_html__( '3d', 'js_composer' ) => '3d',
				esc_html__( 'Custom', 'js_composer' ) => 'custom',
				esc_html__( 'Outline custom', 'js_composer' ) => 'outline-custom',
				esc_html__( 'Gradient', 'js_composer' ) => 'gradient-custom',
			],
			'section' => 'general',
		],
		[
			'type' => 'colorpicker',
			'heading' => esc_html__( 'Start color', 'js_composer' ),
			'param_name' => 'gradient_custom_color_1',
			'settings' => [
				'default_colorpicker_color' => '#dd3333',
			],
			'param_holder_class' => 'vc_colored-dropdown vc_btn3-colored-dropdown',
			'value' => '#dd3333',
			'dependency' => [
				'element' => 'style',
				'value' => [ 'gradient-custom' ],
			],
			'edit_field_class' => 'vc_col-xs-6',
			'section' => 'general',
		],
		[
			'type' => 'colorpicker',
			'heading' => esc_html__( 'End color', 'js_composer' ),
			'param_name' => 'gradient_custom_color_2',
			'settings' => [
				'default_colorpicker_color' => '#eeee22',
			],
			'param_holder_class' => 'vc_colored-dropdown vc_btn3-colored-dropdown',
			'value' => '#eeee22',
			'dependency' => [
				'element' => 'style',
				'value' => [ 'gradient-custom' ],
			],
			'edit_field_class' => 'vc_col-xs-6',
			'section' => 'general',
		],
		[
			'type' => 'colorpicker',
			'heading' => esc_html__( 'Text', 'js_composer' ),
			'param_name' => 'gradient_text_color',
			'settings' => [
				'default_colorpicker_color' => '#ffffff',
			],
			'param_holder_class' => 'vc_colored-dropdown vc_btn3-colored-dropdown',
			'value' => '#ffffff',
			// must have default color grey.
			'dependency' => [
				'element' => 'style',
				'value' => [ 'gradient-custom' ],
			],
			'edit_field_class' => 'vc_col-xs-6',
			'section' => 'general',
		],

		[
			'type' => 'colorpicker',
			'heading' => esc_html__( 'Background', 'js_composer' ),
			'param_name' => 'custom_background',
			'settings' => [
				'default_colorpicker_color' => '#ebebeb',
				'default' => '#ebebeb',
			],
			'dependency' => [
				'element' => 'style',
				'value' => [ 'custom', 'modern', 'classic', 'flat', '3d' ],
			],
			'edit_field_class' => 'vc_col-xs-6',
			'section' => 'general',
		],
		[
			'type' => 'colorpicker',
			'heading' => esc_html__( 'Hover background', 'js_composer' ),
			'param_name' => 'custom_hover_background',
			'dependency' => [
				'element' => 'style',
				'value' => [ 'custom', 'modern', 'classic', 'flat', 'outline' ],
			],
			'edit_field_class' => 'vc_col-xs-6',
			'section' => 'general',
		],
		[
			'type' => 'colorpicker',
			'heading' => esc_html__( 'Text', 'js_composer' ),
			'param_name' => 'custom_text',
			'settings' => [
				'default_colorpicker_color' => '#666',
				'default' => '#666',
			],
			'dependency' => [
				'element' => 'style',
				'value' => [ 'custom', 'modern', 'classic', 'flat', 'outline', '3d' ],
			],
			'edit_field_class' => 'vc_col-xs-6',
			'section' => 'general',
		],
		[
			'type' => 'colorpicker',
			'heading' => esc_html__( 'Hover text', 'js_composer' ),
			'param_name' => 'custom_hover_text',
			'dependency' => [
				'element' => 'style',
				'value' => [ 'custom', 'modern', 'classic', 'flat', 'outline' ],
			],
			'edit_field_class' => 'vc_col-xs-6',
			'section' => 'general',
		],
		[
			'type' => 'colorpicker',
			'heading' => esc_html__( 'Border', 'js_composer' ),
			'param_name' => 'custom_border',
			'dependency' => [
				'element' => 'style',
				'value' => [ 'custom', 'modern', 'outline', '3d' ],
			],
			'edit_field_class' => 'vc_col-xs-6',
			'section' => 'general',
		],
		[
			'type' => 'colorpicker',
			'heading' => esc_html__( 'Hover border', 'js_composer' ),
			'param_name' => 'custom_hover_border',
			'dependency' => [
				'element' => 'style',
				'value' => [ 'custom', 'modern', 'outline' ],
			],
			'edit_field_class' => 'vc_col-xs-6',
			'section' => 'general',
		],

		[
			'type' => 'colorpicker',
			'heading' => esc_html__( 'Outline and text', 'js_composer' ),
			'param_name' => 'outline_custom_color',
			'settings' => [
				'default_colorpicker_color' => '#666',
				'default' => '#666',
			],
			'dependency' => [
				'element' => 'style',
				'value' => [ 'outline-custom' ],
			],
			'edit_field_class' => 'vc_col-xs-6',
			'section' => 'general',
		],
		[
			'type' => 'colorpicker',
			'heading' => esc_html__( 'Hover background', 'js_composer' ),
			'param_name' => 'outline_custom_hover_background',
			'settings' => [
				'default_colorpicker_color' => '#666',
				'default' => '#666',
			],
			'dependency' => [
				'element' => 'style',
				'value' => [ 'outline-custom' ],
			],
			'edit_field_class' => 'vc_col-xs-6',
			'section' => 'general',
		],
		[
			'type' => 'colorpicker',
			'heading' => esc_html__( 'Hover text', 'js_composer' ),
			'param_name' => 'outline_custom_hover_text',
			'settings' => [
				'default_colorpicker_color' => '#fff',
				'default' => '#fff',
			],
			'dependency' => [
				'element' => 'style',
				'value' => [ 'outline-custom' ],
			],
			'edit_field_class' => 'vc_col-xs-6',
			'section' => 'general',
		],

		[
			'type' => 'toggle',
			'heading' => esc_html__( 'Full width', 'js_composer' ),
			'param_name' => 'button_block',
			'edit_field_class' => 'vc_col-xs-6',
			'section' => 'secondary',
		],
		[
			'type' => 'toggle',
			'heading' => esc_html__( 'Onclick action', 'js_composer' ),
			'param_name' => 'custom_onclick',
			'description' => esc_html__( 'Insert inline onclick javascript action.', 'js_composer' ),
			'edit_field_class' => 'vc_col-xs-6',
			'section' => 'secondary',
		],
		[
			'type' => 'textfield',
			'heading' => esc_html__( 'On click code', 'js_composer' ),
			'param_name' => 'custom_onclick_code',
			'description' => esc_html__( 'Enter onclick action code.', 'js_composer' ),
			'dependency' => [
				'element' => 'custom_onclick',
				'not_empty' => true,
			],
			'section' => 'secondary',
		],
		[
			'type' => 'toggle',
			'heading' => esc_html__( 'Icon', 'js_composer' ),
			'param_name' => 'add_icon',
			'section' => 'secondary',
		],
		[
			'type' => 'button_group',
			'heading' => esc_html__( 'Alignment', 'js_composer' ),
			'param_name' => 'i_align',
			'value' => vc_config()->get_text_align_param_value( [ 'center', 'justify' ] ),
			'settings' => [
				'default' => 'left',
			],
			'dependency' => [
				'element' => 'add_icon',
				'value' => 'true',
			],
			'group' => esc_html__( 'Icon', 'js_composer' ),
		],
	], $icons_params
	);

	// class WPBakeryShortCode_Vc_Btn.
	return [
		'name' => esc_html__( 'Old Button', 'js_composer' ),
		'base' => 'vc_btn',
		'icon' => 'icon-wpb-ui-button',
		'element_default_class' => 'vc_do_btn',
		'category' => [
			esc_html__( 'Content', 'js_composer' ),
		],
		'description' => esc_html__( 'Eye catching button', 'js_composer' ),
		'params' => array_merge( $params, vc_config()->get_css_animation_config(), vc_config()->get_general_advanced_settings(), vc_config()->get_design_options_tab( [ 'margin-bottom' => '22px' ] ) ),
		'js_view' => 'VcButton3View',
		'custom_markup' => '{{title}}<div class="vc_btn3-container"><button class="vc_general vc_btn3 vc_btn3-size-sm vc_btn3-shape-{{ params.shape }} vc_btn3-style-{{ params.style }} vc_btn3-color-{{ params.color }}">{{{ params.title }}}</button></div>',
		'sections' => array_merge( [ 'general', 'secondary' ], vc_config()->get_advanced_sections() ),
		'deprecated' => '9.1',
	];
}
