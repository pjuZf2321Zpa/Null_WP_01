<?php
/**
 * Manager class for handling assets loading strategies.
 *
 * @since 9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/**
 * Wpb_Assets_Optimization_Manager class.
 *
 * Manages Assets loading strategies and determines which assets files to load
 * based on the configured strategy.
 *
 * @since 9.0
 */
class Wpb_Assets_Optimization_Manager {
	/**
	 * Get the assets loading strategy from settings.
	 *
	 * @since 9.0
	 * @param string $type The assets type to read the strategy for ('css' or 'js').
	 * @return string The loading strategy.
	 */
	public static function get_loading_strategy( $type ) {
		$loading = vc_settings()->get( $type . '_loading', 'hybrid' );
		if ( empty( $loading ) ) {
			return 'hybrid';
		}
		return $loading;
	}

	/**
	 * Check if optimized asset bundles should be loaded for a specific post.
	 *
	 * @since 9.0
	 * @param string   $type The assets type to check ('css' or 'js').
	 * @param int|null $post_id The post ID to check. If null, uses current post.
	 * @return bool True if optimized assets should be loaded, false otherwise.
	 */
	public static function should_load_optimized( $type, $post_id = null ) {
		$strategy = self::get_loading_strategy( $type );

		switch ( $strategy ) {
			case 'optimized':
				return true;

			case 'hybrid':
				return self::should_load_optimized_for_hybrid( $type, $post_id );

			default:
				return false;
		}
	}

	/**
	 * Check if optimized assets should be loaded in hybrid mode.
	 *
	 * @since 9.0
	 * @param string   $type The assets type to check ('css' or 'js').
	 * @param int|null $post_id The post ID to check. If null, uses current post.
	 * @return bool True if optimized assets should be loaded, false otherwise.
	 */
	protected static function should_load_optimized_for_hybrid( $type, $post_id = null ) {
		if ( null === $post_id ) {
			$post_id = get_the_ID();
		}

		if ( ! $post_id ) {
			return false;
		}

		$meta_key = '_wpb_vc_use_optimized_' . $type;

		$post = get_post( $post_id );
		if ( $post && 'auto-draft' === $post->post_status ) {
			update_post_meta( $post_id, $meta_key, '1' );
			return true;
		}

		$use_optimized = get_post_meta( $post_id, $meta_key, true );
		if ( '' === $use_optimized ) {
			return false;
		}

		return '1' === $use_optimized;
	}

	/**
	 * Drop shortcode asset entries that rely on the optimized bundle.
	 *
	 * When the optimized bundle is not in use for the given asset type (legacy
	 * strategy), entries flagged with `is_optimized => true` are removed from the
	 * settings so they are not enqueued separately; every other entry is kept.
	 *
	 * @since 9.1
	 * @param array  $settings Element settings.
	 * @param string $type Asset type, 'js' or 'css'.
	 * @param string $config_name Settings key that holds the asset entries.
	 * @return array
	 */
	public static function remove_optimized_assets( array $settings, string $type, string $config_name ): array {
		if ( self::should_load_optimized( $type ) ) {
			return $settings;
		}
		if ( empty( $settings[ $config_name ] ) || ! is_array( $settings[ $config_name ] ) ) {
			return $settings;
		}

		$kept_entries = [];
		foreach ( $settings[ $config_name ] as $entry ) {
			if ( is_array( $entry ) && ! empty( $entry['is_optimized'] ) ) {
				continue;
			}
			$kept_entries[] = $entry;
		}

		if ( empty( $kept_entries ) ) {
			unset( $settings[ $config_name ] );

			return $settings;
		}

		$settings[ $config_name ] = $kept_entries;

		return $settings;
	}

	/**
	 * Get the appropriate frontend CSS file based on the CSS loading strategy.
	 *
	 * @since 9.0
	 * @param int|null $post_id The post ID to check. If null, uses current post.
	 * @return string The CSS file path.
	 */
	public static function get_frontend_css_file( $post_id = null ) {
		if ( self::should_load_optimized( 'css', $post_id ) ) {
			return vc_asset_url( 'css/js_composer_optimized.min.css' );
		}
		return vc_asset_url( 'css/js_composer.min.css' );
	}

	/**
	 * Get the appropriate backend editor CSS file based on the CSS loading strategy.
	 *
	 * @since 9.0
	 * @param int|null $post_id The post ID to check. If null, uses current post.
	 * @return string The CSS file path.
	 */
	public static function get_backend_editor_css_file( $post_id = null ) {
		if ( self::should_load_optimized( 'css', $post_id ) ) {
			return vc_asset_url( 'css/js_composer_backend_editor_optimized.min.css' );
		}
		return vc_asset_url( 'css/js_composer_backend_editor.min.css' );
	}
}
