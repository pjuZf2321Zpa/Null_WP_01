<?php
/**
 * Plugin version migration class.
 *
 * Runs update callbacks once for every plugin version.
 *
 * @since 9.1
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/**
 * Class Wpb_Plugin_Version_Migration
 *
 * @since 9.1
 */
class Wpb_Plugin_Version_Migration {
	/**
	 * Update callbacks grouped by the plugin version that introduced them.
	 *
	 * @since 9.1
	 * @var array
	 */
	private $updates = [
		'9.1-beta' => [
			'migrate_assets_loading_to_hybrid',
		],
	];

	/**
	 * Option name storing the plugin version the site was last migrated to.
	 *
	 * @since 9.1
	 * @var string
	 */
	private $version_option = 'wpb_plugin_version_migration';

	/**
	 * Init hooks.
	 *
	 * @since 9.1
	 */
	public function init() {
		add_action( 'admin_init', [ $this, 'run_updates' ] );
	}

	/**
	 * Runs the callbacks of every version crossed since the last migration, then stores the current version.
	 *
	 * @since 9.1
	 */
	public function run_updates() {
		if ( wp_doing_ajax() ) {
			return;
		}

		$old_version = get_option( $this->version_option, '0' );

		if ( $this->is_up_to_date( $old_version ) ) {
			return;
		}

		foreach ( $this->updates as $version => $callbacks ) {
			if ( $this->is_version_crossed( $old_version, $version, WPB_VC_VERSION ) ) {
				$this->run_callbacks( $callbacks );
			}
		}

		update_option( $this->version_option, WPB_VC_VERSION );
	}

	/**
	 * Checks whether the site was already migrated to the current plugin version.
	 *
	 * @param string $old_version
	 *
	 * @return bool
	 * @since 9.1
	 */
	private function is_up_to_date( $old_version ) {
		return version_compare( $old_version, WPB_VC_VERSION, '>=' );
	}

	/**
	 * Checks whether the update crosses the given version.
	 *
	 * A version is crossed when the site's last migrated version is older than it
	 * and the current plugin version is at or above it.
	 *
	 * @param string $old_version
	 * @param string $version
	 * @param string $current_version
	 *
	 * @return bool
	 * @since 9.1
	 */
	private function is_version_crossed( $old_version, $version, $current_version ) {
		return version_compare( $old_version, $version, '<' ) && version_compare( $current_version, $version, '>=' );
	}

	/**
	 * Calls each callback in the given list.
	 *
	 * @param string[] $callbacks
	 *
	 * @since 9.1
	 */
	private function run_callbacks( array $callbacks ) {
		foreach ( $callbacks as $callback ) {
			if ( is_callable( [ $this, $callback ] ) ) {
				call_user_func( [ $this, $callback ] );
			}
		}
	}

	/**
	 * Migrates the CSS loading setting from legacy to hybrid mode.
	 *
	 * @since 9.1
	 */
	public function migrate_assets_loading_to_hybrid() {
		if ( 'legacy' === vc_settings()->get( 'css_loading' ) ) {
			vc_settings()->set( 'css_loading', 'hybrid' );
		}
	}
}
