<?php
/**
 * Contract for modules that use the "post-meta" common functionality.
 *
 * @since 9.1
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/**
 * Wpb_Module_Post_Meta_Interface interface.
 *
 * @property string $post_meta_key
 * @property string $post_meta_slug
 *
 * @since 9.1
 */
interface Wpb_Module_Post_Meta_Interface {
	/**
	 * Get module meta value to store in a post custom meta.
	 *
	 * @since 9.1
	 * @param array $post_custom_meta
	 * @param int $post_id
	 * @return mixed
	 */
	public function get_module_meta( $post_custom_meta, $post_id );
}
