<?php
/**
 * Promo popup.
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/**
 * Promo popup class.
 *
 * @since 7.3
 */
class Vc_Promo_Popup {
	/**
	 * Render UI template.
	 */
	public function render_ui_template() {
		$user_id = get_current_user_id();
		$seen_release = $this->get_release_version( get_user_meta( $user_id, '_vc_editor_promo_popup', true ) );
		$current_release = $this->get_release_version( WPB_VC_VERSION );

		if ( version_compare( $current_release, $seen_release, '<=' ) ) {
			return;
		}

		vc_include_template( 'editors/popups/promo/promo-popup.tpl.php', [ 'box' => $this ] );
		update_user_meta( $user_id, '_vc_editor_promo_popup', $current_release );
	}

	/**
	 * Cut version down to its major and minor part, so 8.7.1 becomes 8.7 and 9.0-beta1 becomes 9.0.
	 *
	 * @since 9.1
	 * @param mixed $version Version to cut, e.g. WPB_VC_VERSION or the meta value we saved for the user.
	 * @return string Release the version belongs to, empty string if version does not start with a number.
	 */
	public function get_release_version( $version ) {
		if ( ! is_string( $version ) || ! preg_match( '/^\d+(\.\d+)?/', $version, $matches ) ) {
			return '';
		}

		return $matches[0];
	}
}
