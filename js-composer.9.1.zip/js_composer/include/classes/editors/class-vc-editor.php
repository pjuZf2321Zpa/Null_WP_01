<?php
/**
 * Common class for all editors.
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/**
 * Base functionality for WpBakery editors.
 *
 * @since 7.4
 */
abstract class Vc_Editor {
	/**
	 * Post custom meta.
	 *
	 * @since 7.7
	 * @var array
	 */
	public $post_custom_meta;

	/**
	 * Service for element assets.
	 *
	 * @var Wpb_Element_Assets_Service
	 */
	public Wpb_Element_Assets_Service $assets_service;

	/**
	 * Set post meta related to VC.
	 *
	 * @since 7.4
	 * @param WP_Post | null $post
	 */
	public function set_post_meta( $post ) {
		/**
		 * Filter post custom meta related to our plugin.
		 *
		 * @since 7.7
		 * @param array $post_custom_meta
		 * @param WP_Post $post
		 */
		$this->post_custom_meta = apply_filters( 'wpb_set_post_custom_meta', [], $post );
	}

	/**
	 * We provide some editor enqueue special parameters that helps JS/CSS works properly in the editor.
	 * User can override.
	 *
	 * @param string $type 'js' or 'css'.
	 * @param array  $shortcode
	 * @param array  $additional_params
	 * @return array
	 */
	public function set_special_enqueue_params( string $type, array $shortcode, array $additional_params ) {
		$config_name = 'css' === $type ? $this->assets_service->css_config_name : $this->assets_service->js_config_name;

		if ( ! isset( $shortcode[ $config_name ] ) ) {
			return $shortcode;
		}

		$new_data = [];
		$data = $shortcode[ $config_name ];
		if ( is_string( $data ) ) {
			$new_data[] = array_merge( [ 'url' => $data ], $additional_params );
		}

		if ( is_array( $data ) ) {
			foreach ( $data as $single_data ) {
				if ( is_string( $single_data ) ) {
					$new_data[] = array_merge( [ 'url' => $single_data ], $additional_params );
				} else {
					$new_data[] = $single_data;
				}
			}
		}

		$shortcode[ $config_name ] = $new_data;

		return $shortcode;
	}
}
