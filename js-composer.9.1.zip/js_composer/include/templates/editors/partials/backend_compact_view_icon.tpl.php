<?php
/**
 * Backend editor compact view icon template.
 *
 * @since 9.1
 *
 * @var string $icon_html
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
?>
<div class="wpb_element_image_container wpb-compact-view-icon"><?php echo $icon_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
