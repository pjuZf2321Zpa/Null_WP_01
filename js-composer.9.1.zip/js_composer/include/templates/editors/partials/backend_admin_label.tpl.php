<?php
/**
 * Backend editor admin label template.
 *
 * @since 9.1
 *
 * @var array $param
 * @var string $value
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
?>
<span class="vc_admin_label admin_label_<?php echo esc_attr( $param['param_name'] ); ?><?php echo empty( $value ) ? ' hidden-label' : ''; ?>"><label><?php echo esc_html( $param['heading'] ); ?></label>: <?php echo esc_html( $value ); ?></span>
