<?php
/**
 * Backend editor element title template.
 *
 * @since 9.1
 *
 * @var string $title
 * @var string|null $title_classes
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
?>
<h4 class="wpb_element_title<?php echo empty( $title_classes ) ? '' : esc_attr( $title_classes ); ?>"><?php echo esc_html( $title ); ?></h4>
