<?php
/**
 * Backend editor empty element image container template.
 *
 * @since 9.1
 *
 * @var string $title_html
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
?>
<div class="wpb_element_image_container"></div><?php echo $title_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
