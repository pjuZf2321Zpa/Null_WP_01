<?php
/**
 * Backend editor responsive column controls menu template.
 *
 * @since 9.1
 *
 * @var array $actions
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
?>
<span class="vc_control-btn vc_control-btn-column-menu" title="<?php echo esc_attr__( 'Column controls', 'js_composer' ); ?>">
	<select class="vc_column-controls-select" data-placeholder="<?php echo esc_attr__( 'Column controls', 'js_composer' ); ?>">
		<option></option>
		<?php foreach ( $actions as $action => $action_settings ) : ?>
			<option value="<?php echo esc_attr( $action ); ?>" data-icon="<?php echo esc_attr( $action_settings['icon'] ); ?>"><?php echo esc_html( $action_settings['label'] ); ?></option>
		<?php endforeach; ?>
	</select>
</span>
