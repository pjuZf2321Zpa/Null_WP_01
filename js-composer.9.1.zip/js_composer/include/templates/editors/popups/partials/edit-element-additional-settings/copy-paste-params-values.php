<?php
/**
 * Edit element additional settings popup copy/paste params values template.
 *
 * @var string $shortcode_name
 * @var array $menu_titles
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
?>
<li class="select2-results__option vc_ui-dropdown-item vc_ui-list-bar-item-trigger" data-vc-copy-params-values>
	<?php echo esc_html( $menu_titles['copy'] ); ?>
</li>
<li class="select2-results__option vc_ui-dropdown-item vc_ui-list-bar-item-trigger" data-vc-paste-params-values>
	<?php echo esc_html( $menu_titles['paste'] ); ?>
</li>
