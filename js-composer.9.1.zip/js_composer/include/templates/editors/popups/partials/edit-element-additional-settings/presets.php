<?php
/**
 * Edit element additional settings popup presets template.
 *
 * @var array $list_presets
 * @var string $shortcode_name
 * @var int $default_id
 * @var array $save_as_template_elements
 * @var string $custom_tag
 * @var array $menu_titles
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
?>
<li class="select2-results__option select2-results__option--disabled vc_ui-dropdown-item vc_ui-prompt-close">
	<?php echo esc_html( $menu_titles['edit-element'] ); ?>
</li>
<?php if ( in_array( $shortcode_name, $save_as_template_elements ) && vc_user_access()->part( 'templates' )->checkStateAny( true, null )->get() ) : ?>
<li class="select2-results__option vc_ui-dropdown-item vc_ui-list-bar-item-trigger" data-vc-save-template>
	<?php echo esc_html( $menu_titles['save-as-template'] ); ?>
</li>
<?php endif; ?>
<?php if ( ! in_array( $shortcode_name, $save_as_template_elements ) && vc_user_access()->part( 'presets' )->checkStateAny( true, null )->get() ) : ?>
<li class="select2-results__option vc_ui-dropdown-item vc_ui-list-bar-item-trigger" data-vc-save-settings-preset>
	<?php echo esc_html( $menu_titles['save-as-element-preset'] ); ?>
</li>
<?php endif; ?>
<?php
/**
 * Global `window.vc_presets_data` is no longer read by any JS in the codebase.
 *
 * @deprecated 9.1 Kept for backward compatibility; scheduled for removal.
 */
?>
<<?php echo esc_attr( $custom_tag ); ?>>
	// @deprecated 9.1 unused - kept for backward compatibility, scheduled for removal.
	window.vc_presets_data = {
		"presets": <?php echo wp_json_encode( $list_presets ); ?>,
		"presetsCount": <?php echo count( $list_presets[0] ) + count( $list_presets[1] ); ?>,
		"defaultId": <?php echo (int) $default_id; ?>,
		"can": <?php echo (int) vc_user_access()->part( 'presets' )->can()->get(); ?>,
		"defaultTitle": "<?php esc_attr_e( 'Untitled', 'js_composer' ); ?>"
	}
</<?php echo esc_attr( $custom_tag ); ?>>
