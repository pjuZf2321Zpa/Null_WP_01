<?php
/**
 * Edit element additional settings popup menu template.
 *
 * @var array $list_presets
 * @var string $shortcode_name
 * @var int $default_id
 * @var array $save_as_template_elements
 * @var string $custom_tag
 * @var bool $has_copy_paste_params
 * @var array $menu_titles
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
?>
<div class="wpb-form-select-dropdown select2-dropdown select2-dropdown--below">
	<div class="select2-results">
		<ul class="select2-results__options">
			<?php
			if ( 'vc_column' !== $shortcode_name ) {
				vc_include_template( 'editors/popups/partials/edit-element-additional-settings/presets.php', [
					'list_presets' => $list_presets,
					'shortcode_name' => $shortcode_name,
					'default_id' => $default_id,
					'save_as_template_elements' => $save_as_template_elements,
					'custom_tag' => $custom_tag,
					'menu_titles' => $menu_titles,
				] );
			}
			if ( $has_copy_paste_params ) {
				vc_include_template( 'editors/popups/partials/edit-element-additional-settings/copy-paste-params-values.php', [
					'shortcode_name' => $shortcode_name,
					'menu_titles' => $menu_titles,
				] );
			}
			?>
		</ul>
	</div>
</div>
