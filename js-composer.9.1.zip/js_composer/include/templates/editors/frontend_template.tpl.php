<?php
/**
 * Frontend template.
 *
 * @var Vc_Frontend_Editor $editor
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

?>
<div id="vc_template-html">
	<?php
	print apply_filters( 'vc_frontend_template_the_content', $editor->parseShortcodesString( $editor->getTemplateContent() ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	?>
	<div data-type="files">
		<?php
		wp_print_styles();

		print_head_scripts();
		print_footer_scripts();
		?>
	</div>
</div>
<div id="vc_template-data"><?php echo esc_html( wp_json_encode( $editor->post_shortcodes ) ); ?></div>
