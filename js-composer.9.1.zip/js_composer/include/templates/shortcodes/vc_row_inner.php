<?php
/**
 * The template for displaying [vc_row_inner] shortcode output of 'Row Inner' element.
 *
 * This template can be overridden by copying it to yourtheme/vc_templates/vc_row_inner.php.
 *
 * @see https://kb.wpbakery.com/docs/developers-how-tos/change-shortcodes-html-output
 *
 * @version 9.1
 *
 * @var WPBakeryShortCode_Vc_Row_Inner $this
 * @var array $atts
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$el_class = $equal_height = $content_placement = $css = $el_id = '';
$disable_element = '';
$output = $after_output = '';
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );
/**
 * Shortcode attributes.
 *
 * @var string $disable_element
 * @var string $el_class
 * @var string $css
 * @var string $el_id
 * @var string $equal_height
 * @var string $content_placement
 * @var string $content - shortcode content
 */

$el_class = $this->getExtraClass( $el_class );
$css_classes = [
	'vc_row',
	'wpb_row',
	// deprecated.
	'vc_inner',
	'vc_row-fluid',
	$el_class,
	vc_shortcode_custom_css_class( $css ),
];
if ( 'yes' === $disable_element ) {
	if ( vc_is_page_editable() ) {
		$css_classes[] = 'vc_hidden-xl vc_hidden-lg vc_hidden-xs vc_hidden-sm vc_hidden-md';
	} else {
		return '';
	}
}

if ( vc_shortcode_custom_css_has_property( $css, [
	'border',
	'background',
] ) ) {
	$css_classes[] = 'vc_row-has-fill';
}

$gap = ! empty( $atts['gap'] ) ? (float) $atts['gap'] : 0;
$css_classes = $this->get_column_gap_css_classes( $gap, $css_classes );

if ( ! empty( $equal_height ) ) {
	$flex_row = true;
	$css_classes[] = 'vc_row-o-equal-height';
}

if ( ! empty( $atts['rtl_reverse'] ) ) {
	$css_classes[] = 'vc_rtl-columns-reverse';
}

if ( ! empty( $content_placement ) ) {
	$flex_row = true;
	$css_classes[] = 'vc_row-o-content-' . $content_placement;
}

if ( ! empty( $flex_row ) ) {
	$css_classes[] = 'vc_row-flex';
}

$wrapper_attributes = [];
// build attributes for wrapper.
if ( ! empty( $el_id ) ) {
	$wrapper_attributes[] = 'id="' . esc_attr( $el_id ) . '"';
}

$inline_styles = [];
$inline_styles = $this->get_column_gap_inline_styles( $gap, $atts['gap'] ?? '', $inline_styles );
$style_wrapper_attribute = $this->get_inline_style_wrapper_attributes( $inline_styles );
if ( '' !== $style_wrapper_attribute ) {
	$wrapper_attributes[] = $style_wrapper_attribute;
}

$css_class = preg_replace( '/\s+/', ' ', apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, implode( ' ', array_filter( array_unique( $css_classes ) ) ), $this->getSettings()['base'], $atts ) );
$wrapper_attributes[] = 'class="' . esc_attr( trim( $css_class ) ) . '"';

$output .= '<div ' . implode( ' ', $wrapper_attributes ) . '>';
$output .= wpb_js_remove_wpautop( $content );
$output .= '</div>';
$output .= $after_output;

return $output;
