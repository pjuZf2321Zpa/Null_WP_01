<?php
/**
 * The template for displaying [wpb_btn] shortcode output of 'Button' element.
 *
 * This template can be overridden by copying it to yourtheme/vc_templates/wpb_btn.php.
 *
 * @see https://kb.wpbakery.com/docs/developers-how-tos/change-shortcodes-html-output
 *
 * @since 9.1
 *
 * @var array $atts
 * @var WPBakeryShortCode_Wpb_Btn $this
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
$uid = uniqid();
$css_class = $this->get_element_wrapper_css_class( 'wpb_btn-container', $atts );
$button_link = $this->get_button_link( $atts['link'] );
$attributes = $this->get_button_attributes( $button_link, $atts, $uid );
$button_html = $this->get_button_label_html( $atts );

$this->output_gradient_style_html( $uid, $atts );
// phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped
?>
<div
	class="<?php echo esc_attr( trim( $css_class ) ); ?>"
	<?php $this->output_wrapper_style( $atts ); ?>
	<?php echo empty( $atts['el_id'] ) ? '' : 'id="' . esc_attr( $atts['el_id'] ) . '"'; ?>
>
	<?php if ( $button_link ) : ?>
		<a <?php echo $attributes; ?>>
			<?php echo $button_html; ?>
		</a>
	<?php else : ?>
		<button <?php echo $attributes; ?>>
			<?php echo $button_html; ?>
		</button>
	<?php endif; ?>
</div>
