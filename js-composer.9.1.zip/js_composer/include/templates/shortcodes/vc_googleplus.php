<?php
/**
 * The template for displaying [vc_googleplus] shortcode output of 'Google+ Button' element.
 *
 * This template can be overridden by copying it to yourtheme/vc_templates/vc_googleplus.php
 *
 * @note For a frontend editor this element uses $this::contentInline() method to output template.
 *
 * @see https://kb.wpbakery.com/docs/developers-how-tos/change-shortcodes-html-output
 * @see WPBakeryShortCode_Vc_GooglePlus::contentInline()
 *
 * @deprecated 6.0
 *
 * @var WPBakeryShortCode_Vc_GooglePlus $this
 * @var array $atts
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$type = $annotation = $widget_width = $css = $el_class = $el_id = $css_animation = '';
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );
/**
 * Shortcode attributes.
 *
 * @var string $type
 * @var string $el_class
 * @var string $el_id
 * @var string $annotation
 * @var string $widget_width
 * @var string $css
 * @var string $css_animation
 */

if ( empty( $annotation ) ) {
	$annotation = 'bubble';
}
$params = '';
$params .= ( '' !== $type ) ? ' size="' . esc_attr( $type ) . '"' : '';
$params .= ' annotation="' . esc_attr( $annotation ) . '"';

if ( empty( $type ) ) {
	$type = 'standard';
}
if ( 'inline' === $annotation && strlen( $widget_width ) > 0 ) {
	$params .= ' width="' . (int) $widget_width . '"';
}

$class_to_filter = 'wpb_googleplus wpb_content_element wpb_googleplus_type_' . $type . ' vc_googleplus-annotation-' . $annotation . $this->getCSSAnimation( $css_animation ) . $this->getExtraClass( $el_class );
$class_to_filter .= vc_shortcode_custom_css_class( $css, ' ' );
$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $class_to_filter, $this->getSettings()['base'], $atts );
$wrapper_attributes = [];
if ( ! empty( $el_id ) ) {
	$wrapper_attributes[] = 'id="' . esc_attr( $el_id ) . '"';
}
$output = '<div class="' . esc_attr( $css_class ) . '" ' . implode( ' ', $wrapper_attributes ) . '><g:plusone' . $params . '></g:plusone></div>';

return $output;
