<?php
/**
 * Basic class for vc_grid_item param.
 *
 * @see https://kb.wpbakery.com/docs/inner-api/vc_map/#vc_map()-ParametersofparamsArray
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/**
 * Class Vc_Grid_Item to build grid item.
 */
class Vc_Grid_Item {
	/**
	 * Template for grid item.
	 *
	 * @var string
	 */
	protected $template = '';
	/**
	 * Html template for grid item.
	 *
	 * @var bool|string
	 */
	protected $html_template = false;
	/**
	 * Post object.
	 *
	 * @var bool|WP_Post
	 */
	protected $post = false;
	/**
	 * Grid item attributes.
	 *
	 * @var array
	 */
	protected $grid_atts = [];
	/**
	 * Is end of grid.
	 *
	 * @var bool
	 */
	protected $is_end = false;
	/**
	 * Shortcodes for grid item.
	 *
	 * @var bool
	 */
	protected $shortcodes = false;
	/**
	 * Found variables in template.
	 *
	 * @var bool|array
	 */
	protected $found_variables = false;
	/**
	 * Predefined templates.
	 *
	 * @var bool
	 */
	protected static $predefined_templates = false;
	/**
	 * Template id.
	 *
	 * @var bool|int|string
	 */
	protected $template_id = false;

	/**
	 * Get shortcodes to build vc grid item templates.
	 *
	 * @return bool|mixed
	 */
	public function shortcodes() {
		if ( false === $this->shortcodes ) {
			$this->shortcodes = include vc_path_dir( 'PARAMS_DIR', 'vc_grid_item/shortcodes.php' );
			$this->shortcodes = apply_filters( 'vc_grid_item_shortcodes', $this->shortcodes );
		}
		add_filter( 'vc_shortcode_set_template_vc_icon', [
			$this,
			'addVcIconShortcodesTemplates',
		] );
		add_filter( 'vc_shortcode_set_template_vc_single_image', [
			$this,
			'addVcSingleImageShortcodesTemplates',
		] );
		add_filter( 'vc_shortcode_set_template_vc_custom_heading', [
			$this,
			'addVcCustomHeadingShortcodesTemplates',
		] );
		add_filter( 'vc_shortcode_set_template_vc_btn', [
			$this,
			'addVcBtnShortcodesTemplates',
		] );
		add_filter( 'vc_shortcode_set_template_wpb_btn', [
			$this,
			'addWpbBtnShortcodesTemplates',
		] );

		return $this->shortcodes;
	}

	/**
	 * Used by filter vc_shortcode_set_template_vc_icon to set custom template for vc_icon shortcode.
	 *
	 * @param string $template
	 *
	 * @return string
	 */
	public function addVcIconShortcodesTemplates( $template ) {
		if ( Vc_Grid_Item_Editor::postType() === WPBMap::getScope() ) {
			$file = vc_path_dir( 'TEMPLATES_DIR', 'params/vc_grid_item/shortcodes/vc_icon.php' );
			if ( is_file( $file ) ) {
				return $file;
			}
		}

		return $template;
	}

	/**
	 * Used by filter vc_shortcode_set_template_vc_single_image to set custom template for vc_single_image shortcode.
	 *
	 * @param string $template
	 *
	 * @return string
	 */
	public function addVcSingleImageShortcodesTemplates( $template ) {
		if ( Vc_Grid_Item_Editor::postType() === WPBMap::getScope() ) {
			$file = vc_path_dir( 'TEMPLATES_DIR', 'params/vc_grid_item/shortcodes/vc_single_image.php' );
			if ( is_file( $file ) ) {
				return $file;
			}
		}

		return $template;
	}

	/**
	 * Used by filter vc_shortcode_set_template_vc_custom_heading to set custom template for vc_custom_heading
	 * shortcode.
	 *
	 * @param string $template
	 *
	 * @return string
	 */
	public function addVcCustomHeadingShortcodesTemplates( $template ) {
		if ( Vc_Grid_Item_Editor::postType() === WPBMap::getScope() ) {
			$file = vc_path_dir( 'TEMPLATES_DIR', 'params/vc_grid_item/shortcodes/vc_custom_heading.php' );
			if ( is_file( $file ) ) {
				return $file;
			}
		}

		return $template;
	}

	/**
	 * Used by filter vc_shortcode_set_template_vc_btn to set custom template for vc_btn shortcode.
	 *
	 * @param string $template
	 *
	 * @return string
	 */
	public function addVcBtnShortcodesTemplates( $template ) {
		if ( Vc_Grid_Item_Editor::postType() === WPBMap::getScope() ) {
			$file = vc_path_dir( 'TEMPLATES_DIR', 'params/vc_grid_item/shortcodes/vc_btn.php' );
			if ( is_file( $file ) ) {
				return $file;
			}
		}

		return $template;
	}

	/**
	 * Used by filter vc_shortcode_set_template_wpb_btn to set custom template for wpb_btn shortcode.
	 *
	 * @param string $template
	 *
	 * @return string
	 */
	public function addWpbBtnShortcodesTemplates( $template ) {
		if ( Vc_Grid_Item_Editor::postType() === WPBMap::getScope() ) {
			$file = vc_path_dir( 'TEMPLATES_DIR', 'params/vc_grid_item/shortcodes/wpb_btn.php' );
			if ( is_file( $file ) ) {
				return $file;
			}
		}

		return $template;
	}

	/**
	 * Map shortcodes for vc_grid_item param type.
	 *
	 * @throws \Exception
	 */
	public function mapShortcodes() {
		// @kludge
		// TODO: refactor with with new way of roles for shortcodes.
		// NEW ROLES like post_type for shortcode and access policies.
		$shortcodes = $this->shortcodes();
		foreach ( $shortcodes as $shortcode_settings ) {
			vc_map( $shortcode_settings );
		}
	}

	/**
	 * Get list of predefined templates.
	 *
	 * @return bool|mixed
	 */
	public static function predefinedTemplates() {
		if ( false === self::$predefined_templates ) {
			self::$predefined_templates = apply_filters( 'vc_grid_item_predefined_templates', include vc_path_dir( 'PARAMS_DIR', 'vc_grid_item/templates.php' ) );
		}

		return self::$predefined_templates;
	}

	/**
	 * Get predefined template by id.
	 *
	 * @param string $id - Predefined templates id.
	 *
	 * @return array|bool
	 */
	public static function predefinedTemplate( $id ) {
		$predefined_templates = self::predefinedTemplates();
		if ( $id && isset( $predefined_templates[ $id ]['template'] ) ) {
			return $predefined_templates[ $id ];
		}

		return false;
	}

	/**
	 * Set template which should grid used when vc_grid_item param value is rendered.
	 *
	 * @param string $id
	 *
	 * @return bool
	 * @throws \Exception
	 */
	public function setTemplateById( $id ) {
		require_once vc_path_dir( 'PARAMS_DIR', 'vc_grid_item/templates.php' );
		if ( 0 === strlen( $id ) ) {
			return false;
		}
		if ( preg_match( '/^\d+$/', $id ) ) {
			$post = get_post( (int) $id );
			if ( $post ) {
				$this->setTemplate( $post->post_content, $post->ID );
			}

			return true;
		} else {
			$predefined_template = $this->predefinedTemplate( $id );
			if ( $predefined_template ) {
				$this->setTemplate( $predefined_template['template'], $id );

				return true;
			}
		}

		return false;
	}

	/**
	 * Setter for template attribute.
	 *
	 * @param string $template
	 * @param int|string $template_id
	 * @throws \Exception
	 */
	public function setTemplate( $template, $template_id ) {
		$this->template = $template;
		$this->template_id = $template_id;
		$this->parseTemplate( $template );
	}

	/**
	 * Getter for template attribute.
	 *
	 * @return string
	 */
	public function template() {
		return $this->template;
	}

	/**
	 * Add custom css from shortcodes that were mapped for vc grid item.
	 *
	 * @return string
	 * @throws \Exception
	 */
	public function addShortcodesCustomCss() {
		$output = $shortcodes_custom_css = '';
		$id = $this->template_id;
		if ( preg_match( '/^\d+$/', $id ) ) {
			$shortcodes_custom_css = get_post_meta( $id, '_wpb_shortcodes_custom_css', true );
		} else {
			$predefined_template = $this->predefinedTemplate( $id );
			if ( $predefined_template ) {
				$shortcodes_custom_css = wpbakery()->parseShortcodesCss( $predefined_template['template'], 'custom' );
			}
		}
		if ( ! empty( $shortcodes_custom_css ) ) {
			$shortcodes_custom_css = wp_strip_all_tags( $shortcodes_custom_css );
			$first_tag = 'style';
			$output .= '<' . $first_tag . ' data-type="vc_shortcodes-custom-css">';
			$output .= $shortcodes_custom_css;
			$output .= '</' . $first_tag . '>';
		}

		return $output;
	}

	/**
	 * Generates html with template's variables.
	 *
	 * @param string $template
	 * @return string
	 * @since 7.6
	 */
	public function getParseTemplate( $template ) {
		$this->mapShortcodes();
		WPBMap::addAllMappedShortcodes();
		$attr = ' width="' . $this->gridAttribute( 'element_width', '12' ) . '" is_end="' . ( $this->isEnd() ? 'true' : '' ) . '"';
		$template = preg_replace( '/(\[(\[?)vc_gitem\b)/', '$1' . $attr, $template );
		$template = str_replace( [
			'<p>[vc_gitem',
			'[/vc_gitem]</p>',
		], [
			'[vc_gitem',
			'[/vc_gitem]',
		], $template );

		return do_shortcode( trim( $template ) );
	}

	/**
	 * Set parsed template to html_template attribute.
	 *
	 * @param string $template
	 * @throws \Exception
	 */
	public function parseTemplate( $template ) {
		$this->html_template .= $this->getParseTemplate( $template );
	}

	/**
	 * Regexp for variables.
	 *
	 * @return string
	 */
	public function templateVariablesRegex() {
        // phpcs:ignore:Generic.Strings.UnnecessaryStringConcat.Found
		return '/\{\{' . '\{?' . '\s*' . '([^\}\:]+)(\:([^\}]+))?' . '\s*' . '\}\}' . '\}?/';
	}

	/**
	 * Get default variables.
	 *
	 * @return array|bool
	 */
	public function getTemplateVariables() {
		if ( ! is_array( $this->found_variables ) ) {
			preg_match_all( $this->templateVariablesRegex(), $this->html_template, $this->found_variables, PREG_SET_ORDER );
		}

		return $this->found_variables;
	}

	/**
	 * Render item by replacing template variables for exact post.
	 *
	 * @param WP_Post $post
	 *
	 * @return mixed
	 */
	public function renderItem( WP_Post $post ) {
		$pattern = [];
		$replacement = [];
		$this->addAttributesFilters();
		foreach ( $this->getTemplateVariables() as $var ) {
			$pattern[] = '/' . preg_quote( $var[0], '/' ) . '/';
			$replacement[] = preg_replace( '/\\$/', '\\\$', $this->attribute( $var[1], $post, isset( $var[3] ) ? trim( $var[3] ) : '' ) );
		}

		return preg_replace( $pattern, $replacement, do_shortcode( $this->html_template ) );
	}

	/**
	 * Adds filters to build templates variables values.
	 */
	public function addAttributesFilters() {
		require_once vc_path_dir( 'PARAMS_DIR', 'vc_grid_item/attributes.php' );
	}

	/**
	 * Getter for Grid shortcode attributes.
	 *
	 * @param array $grid_atts
	 */
	public function setGridAttributes( $grid_atts ) {
		$this->grid_atts = $grid_atts;
	}

	/**
	 * Setter for Grid shortcode attributes.
	 *
	 * @param string $name
	 * @param string $initial
	 *
	 * @return string
	 */
	public function gridAttribute( $name, $initial = '' ) {
		return $this->grid_atts[ $name ] ?? $initial;
	}

	/**
	 * Get attribute value for WP_post object.
	 *
	 * @param string $name
	 * @param WP_Post $post
	 * @param string $data
	 *
	 * @return mixed
	 */
	public function attribute( $name, $post, $data = '' ) {
		$data = html_entity_decode( $data, ENT_COMPAT );

		return apply_filters( 'vc_gitem_template_attribute_' . trim( $name ), ( $post->$name ?? '' ), [
			'post' => $post,
			'data' => $data,
		] );
	}

	/**
	 * Set that this is last items in the grid. Used for load more button and lazy loading.
	 *
	 * @param bool $is_end
	 */
	public function setIsEnd( $is_end = true ) {
		$this->is_end = $is_end;
	}

	/**
	 * Checks is the end.
	 *
	 * @return bool
	 */
	public function isEnd() {
		return $this->is_end;
	}

	/**
	 * Output for grid item form field.
	 *
	 * @param array $settings
	 * @param string $value
	 * @return string
	 * @since 9.1
	 */
	public static function get_grid_item_form_field( $settings, $value ) {
		require_once vc_path_dir( 'PARAMS_DIR', 'vc_grid_item/editor/class-vc-grid-item-editor.php' );
		$output = '<div data-vc-grid-element="container"><select data-vc-grid-element="value" type="hidden" name="' . esc_attr( $settings['param_name'] ) . '" class="wpb_vc_param_value wpb-form-select ' . esc_attr( $settings['param_name'] ) . ' ' . esc_attr( $settings['type'] ) . '_field">';
		$vc_grid_item_templates = self::predefinedTemplates();
		if ( is_array( $vc_grid_item_templates ) ) {
			foreach ( $vc_grid_item_templates as $key => $data ) {
				$output .= '<option data-vc-link="' . esc_url( admin_url( 'post-new.php?post_type=vc_grid_item&vc_gitem_template=' . $key ) ) . '" value="' . esc_attr( $key ) . '"' . ( $key === $value ? ' selected="true"' : '' ) . '>' . esc_html( $data['name'] ) . '</option>';
			}
		}

		$grid_item_posts = get_posts( [
			'posts_per_page' => -1,
			'orderby' => 'post_title',
			'post_type' => Vc_Grid_Item_Editor::postType(),
		] );
		foreach ( $grid_item_posts as $post ) {
			$output .= '<option  data-vc-link="' . esc_url( get_edit_post_link( $post->ID ) ) . '"value="' . esc_attr( (string) $post->ID ) . '"' . ( (string) $post->ID === $value ? ' selected="true"' : '' ) . '>' . esc_html( _draft_or_post_title( $post ) ) . '</option>';
		}
		$output .= '</select></div>';

		return $output;
	}

	/**
	 * Load vc_grid_item param
	 *
	 * @since 9.1
	 */
	public static function load_grid_item_param() {
		vc_add_shortcode_param( 'vc_grid_item', [ 'Vc_Grid_Item', 'get_grid_item_form_field' ] );
	}

	/**
	 * Add target attribute to link.
	 *
	 * @return string
	 * @since 9.1
	 */
	public static function get_link_target_frontend_editor() {
		return ' target="_blank"';
	}

	/**
	 * Add rel attribute to link.
	 *
	 * @param string $rel
	 * @return string
	 * @since 9.1
	 */
	public static function get_link_rel_frontend_editor( $rel ) {
		return ' rel="' . esc_attr( $rel ) . '"';
	}

	/**
	 * Create link.
	 *
	 * @param array $atts
	 * @param string $default_class
	 * @param string $title
	 * @return string
	 * @since 9.1
	 */
	public static function create_link( $atts, $default_class = '', $title = '' ) { // phpcs:ignore:Generic.Metrics.CyclomaticComplexity, CognitiveComplexity.Complexity.MaximumComplexity.TooHigh
		$link = '';
		$target = '';
		$rel = '';
		$title_attr = '';
		$css_class = 'vc_gitem-link' . ( strlen( $default_class ) > 0 ? ' ' . $default_class : '' );
		if ( isset( $atts['link'] ) ) {
			if ( 'custom' === $atts['link'] && ! empty( $atts['url'] ) ) {
				$link = vc_build_link( $atts['url'] );
				if ( strlen( $link['target'] ) ) {
					$target = ' target="' . esc_attr( $link['target'] ) . '"';
				}
				if ( strlen( $link['rel'] ) ) {
					$rel = ' rel="' . esc_attr( $link['rel'] ) . '"';
				}
				if ( strlen( $link['title'] ) ) {
					$title = $link['title'];
				}
				$link = 'a href="' . esc_url( $link['url'] ) . '" class="' . esc_attr( $css_class ) . '"';
			} elseif ( 'post_link' === $atts['link'] ) {
				$target = isset( $atts['link_target'] ) && $atts['link_target'] ? ' target="_blank"' : '';
				$link = 'a href="{{ post_link_url }}" class="' . esc_attr( $css_class ) . '"' . $target;
				if ( ! strlen( $title ) ) {
					$title = '{{ post_title }}';
				}
			} elseif ( 'post_author' === $atts['link'] ) {
				$target = isset( $atts['link_target'] ) && $atts['link_target'] ? ' target="_blank"' : '';
				$link = 'a href="{{ post_author_href }}" class="' . esc_attr( $css_class ) . '"' . $target;
				if ( ! strlen( $title ) ) {
					$title = '{{ post_author }}';
				}
			} elseif ( 'image' === $atts['link'] ) {
				$target = isset( $atts['link_target'] ) && $atts['link_target'] ? ' target="_blank"' : '';
				$link = 'a{{ post_image_url_href }} class="' . esc_attr( $css_class ) . '"' . $target;
			} elseif ( 'image_lightbox' === $atts['link'] ) {
				$target = isset( $atts['link_target'] ) && $atts['link_target'] ? ' target="_blank"' : '';
				$link = 'a{{ post_image_url_attr_prettyphoto:' . $css_class . ' }}' . $target;
			} elseif ( 'image_full' === $atts['link'] ) {
				$target = isset( $atts['link_target'] ) && $atts['link_target'] ? ' target="_blank"' : '';
				$link = 'a{{ post_full_image_url_href }} class="' . esc_attr( $css_class ) . '"' . $target;
			} elseif ( 'image_full_lightbox' === $atts['link'] ) {
				$target = isset( $atts['link_target'] ) && $atts['link_target'] ? ' target="_blank"' : '';
				$link = 'a{{ post_full_image_url_attr_prettyphoto:' . $css_class . ' }}' . $target;
			}
		}
		if ( strlen( $title ) > 0 ) {
			$title_attr = ' title="' . esc_attr( $title ) . '"';
		}

		return apply_filters( 'vc_gitem_post_data_get_link_link', $link, $atts, $css_class ) . apply_filters( 'vc_gitem_post_data_get_link_target', $target, $atts ) . apply_filters( 'vc_gitem_post_data_get_link_rel', $rel, $atts ) . apply_filters( 'vc_gitem_post_data_get_link_title', $title_attr, $atts );
	}

	/**
	 * Create real link.
	 *
	 * @param array $atts
	 * @param WP_Post $post
	 * @param string $default_class
	 * @param string $title
	 * @return string
	 * @since 9.1
	 */
	public static function create_link_real( $atts, $post, $default_class = '', $title = '' ) {
		$link = $target = $rel = $title_attr = '';
		$link_css_class = 'vc_gitem-link';
		if ( isset( $atts['link'] ) ) {
			[ $link, $target, $rel, $title, $link_css_class ] = self::build_link_attributes( $atts, $post, $default_class, $title );
		}

		$link = apply_filters( 'vc_gitem_post_data_get_link_real_link', $link, $atts, $post, $link_css_class );
		if ( ! $link ) {
			return '';
		}

		if ( strlen( $title ) > 0 ) {
			$title_attr = ' title="' . esc_attr( $title ) . '"';
			$title_attr = apply_filters( 'vc_gitem_post_data_get_link_real_title', $title_attr, $atts, $post );
		}

		$target = apply_filters( 'vc_gitem_post_data_get_link_real_target', $target, $atts, $post );
		$rel = apply_filters( 'vc_gitem_post_data_get_link_real_rel', $rel, $atts, $post );

		return $link . $target . $rel . $title_attr;
	}

	/**
	 * Build link, target, rel, title and css class for the real link markup.
	 *
	 * @param array $atts
	 * @param WP_Post $post
	 * @param string $default_class
	 * @param string $title
	 * @return array
	 * @since 9.1
	 */
	protected static function build_link_attributes( $atts, $post, $default_class, $title ) { // phpcs:ignore:Generic.Metrics.CyclomaticComplexity.TooHigh, CognitiveComplexity.Complexity.MaximumComplexity.TooHigh
		$link = $target = $rel = '';
		$link_css_class = 'vc_gitem-link' . ( strlen( $default_class ) > 0 ? ' ' . $default_class : '' );
		if ( strlen( $atts['el_class'] ) > 0 ) {
			$link_css_class .= ' ' . $atts['el_class'];
		}
		$link_css_class = trim( preg_replace( '/\s+/', ' ', $link_css_class ) );
		if ( 'custom' === $atts['link'] && ! empty( $atts['url'] ) ) {
			$link = vc_build_link( $atts['url'] );
			if ( strlen( $link['target'] ) ) {
				$target = ' target="' . esc_attr( $link['target'] ) . '"';
			}
			if ( strlen( $link['rel'] ) ) {
				$rel = ' rel="' . esc_attr( $link['rel'] ) . '"';
			}
			if ( strlen( $link['title'] ) ) {
				$title = $link['title'];
			}
			$link = 'a href="' . esc_url( $link['url'] ) . '" class="' . esc_attr( $link_css_class ) . '"';
		} elseif ( 'post_link' === $atts['link'] ) {
			$target = isset( $atts['link_target'] ) && $atts['link_target'] ? ' target="_blank"' : '';
			$link = 'a href="' . esc_url( get_permalink( $post->ID ) ) . '" class="' . esc_attr( $link_css_class ) . '"' . $target;
			if ( ! strlen( $title ) ) {
				$title = the_title( '', '', false );
			}
		} elseif ( 'image' === $atts['link'] ) {
			$target = isset( $atts['link_target'] ) && $atts['link_target'] ? ' target="_blank"' : '';
			$href_link = vc_gitem_template_attribute_post_image_url( '', [
				'post' => $post,
				'data' => '',
			] );
			$link = 'a href="' . esc_url( $href_link ) . '" class="' . esc_attr( $link_css_class ) . '"' . $target;
		} elseif ( 'image_lightbox' === $atts['link'] ) {
			$target = isset( $atts['link_target'] ) && $atts['link_target'] ? ' target="_blank"' : '';
			$link = 'a' . vc_gitem_template_attribute_post_image_url_attr_lightbox( '', [
				'post' => $post,
				'data' => esc_attr( $link_css_class ),
			] ) . $target;
		} elseif ( 'image_full' === $atts['link'] ) {
			$target = isset( $atts['link_target'] ) && $atts['link_target'] ? ' target="_blank"' : '';
			$href_link = vc_gitem_template_attribute_post_full_image_url( '', [
				'post' => $post,
				'data' => '',
			] );
			$link = 'a href="' . esc_url( $href_link ) . '" class="' . esc_attr( $link_css_class ) . '"' . $target;
		} elseif ( 'image_full_lightbox' === $atts['link'] ) {
			$target = isset( $atts['link_target'] ) && $atts['link_target'] ? ' target="_blank"' : '';
			$link = 'a' . vc_gitem_template_attribute_post_full_image_url_attr_lightbox( '', [
				'post' => $post,
				'data' => esc_attr( $link_css_class ),
			] ) . $target;
		}

		return [ $link, $target, $rel, $title, $link_css_class ];
	}

	/**
	 * Get link.
	 *
	 * @param string $link
	 * @return string
	 * @since 9.1
	 */
	public static function get_link_frontend_editor( $link ) {
		return empty( $link ) ? 'a' : $link;
	}
}
