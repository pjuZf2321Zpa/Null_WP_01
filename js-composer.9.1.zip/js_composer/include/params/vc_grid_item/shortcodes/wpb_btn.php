<?php
/**
 * Shortcode wpb_btn integration for vc_grid_item.
 *
 * @since 9.1
 * @var array $list
 * @var array $vc_gitem_add_link_param
 * @var array $vc_gitem_add_link_target_param
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$shortcode_wpb_btn = WPBMap::getShortCode( 'wpb_btn' );
if ( is_array( $shortcode_wpb_btn ) && isset( $shortcode_wpb_btn['base'] ) ) {
	$list['wpb_btn'] = $shortcode_wpb_btn;
	$list['wpb_btn']['post_type'] = Vc_Grid_Item_Editor::postType();
	$remove = [ 'el_id', 'link' ];
	foreach ( $list['wpb_btn']['params'] as $k => $v ) {
		if ( in_array( $v['param_name'], $remove, true ) ) {
			unset( $list['wpb_btn']['params'][ $k ] );
		}
	}
	array_unshift( $list['wpb_btn']['params'], [
		'type' => 'vc_link',
		'heading' => esc_html__( 'URL (Link)', 'js_composer' ),
		'param_name' => 'url',
		'dependency' => [
			'element' => 'link',
			'value' => [ 'custom' ],
		],
		'description' => esc_html__( 'Add custom link.', 'js_composer' ),
	] );
	array_unshift( $list['wpb_btn']['params'], $vc_gitem_add_link_target_param );
	array_unshift( $list['wpb_btn']['params'], $vc_gitem_add_link_param );
}
