<?php
/**
 * Param type 'google_fonts'
 *
 * Container param for a set of fields.
 *
 * @see https://kb.wpbakery.com/docs/inner-api/vc_map/#vc_map()-ParametersofparamsArray
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/**
 * Class Vc_Google_Fonts
 *
 * @since 4.3
 * vc_map examples:
 *      'params' => array(
 *          array(
 *                'type' => 'google_fonts',
 *                'param_name' => 'google_fonts',
 *                'value' => '',// Not recommended, this will override 'settings'. Example:
 *     'font_family:'.rawurlencode('Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic').'|font_style:'.rawurlencode('900
 *     bold italic:900:italic'),
 *                'settings' => array(
 *                    'fields'=>array(
 *                        'font_family'=>'Abril Fatface:regular',//
 *     'Exo:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic',
 *     Default font family and all available styles to fetch
 *                        'font_style'=>'400 regular:400:normal', // Default font style. Name:weight:style, example:
 *     "800 bold regular:800:normal"
 *                        'font_family_description' => esc_html__('Select font family.','js_composer'),
 *                        'font_style_description' => esc_html__('Select font styling.','js_composer')
 *                  )
 *                ),
 *                'description' => esc_html__( 'Description for this group', 'js_composer' ), // Description for field group
 *            ),
 *      )
 */
class Vc_Google_Fonts {
	/**
	 * Google fonts list.
	 *
	 * @var string
	 */
	public $fonts_list;

	/**
	 * Loads the predefined fonts list from its JSON data file.
	 *
	 * @since 9.1
	 */
	public function __construct() {
		$this->fonts_list = $this->read_fonts_list();
	}

	/**
	 * Read the fonts JSON file once per request.
	 *
	 * @return string
	 * @since 9.1
	 */
	private function read_fonts_list() {
		static $fonts_list;
		$fonts_list ??= (string) vc_file_get_contents( vc_path_dir( 'ASSETS_DIR', 'fonts/google_fonts/fonts-list.json' ) );

		return $fonts_list;
	}

	/**
	 * Render google fonts param.
	 *
	 * @param array $settings
	 * @param string|array $value
	 * @param string $param_id since 9.0.
	 * @return string
	 * @since 4.3
	 */
	public function render( $settings, $value, $param_id = '' ) {
		// @var array $fields - used in template.php
		$fields = [];
		// @var array $values - used in template.php
		$values = [];
		$set = isset( $settings['settings'], $settings['settings']['fields'] ) ? $settings['settings']['fields'] : [];
		extract( $this->_vc_google_fonts_parse_attributes( $set, $value ) );

		$fonts = $this->_vc_google_fonts_get_fonts();

		$font_style_options = $this->get_font_style_options( $fonts, $values );

		return vc_get_template( 'params/google_fonts/template.php', [ // nosemgrep.
			'fields' => $fields,
			'values' => $values,
			'settings' => $settings,
			'value' => $value,
			'param_id' => $param_id,
			'font_style_options' => $font_style_options,
		] );
	}

	/**
	 * Get font style options for dropdown.
	 *
	 * @param array $fonts
	 * @param array $values
	 * @return array
	 */
	public function get_font_style_options( $fonts, $values ) {
		$typography_module = vc_modules_manager()->get_module( 'vc-typography' );
		if ( ! $typography_module ) {
			return $fonts;
		}
		$separator_list = [
			$typography_module->adobe_controller->get_adobe_dropdown_separator(),
			$typography_module->get_default_dropdown_separator(),
		];

		$font_style_options = [];
		foreach ( $fonts as $font_data ) {
			$is_separator = in_array( $font_data->font_family, $separator_list );
			$is_disabled = false;
			$font_family_slug = empty( $font_data->font_family_slug ) ? $font_data->font_family : $font_data->font_family_slug;
			// we use Google as default vendor.
			$font_vendor = empty( $font_data->font_vendor ) ? '' : $font_data->font_vendor;
			$font_url = empty( $font_data->font_url ) ? '' : $font_data->font_url;
			if ( $is_separator ) {
				$is_disabled = true;
			}

			$font_family_low_case = strtolower( $font_family_slug );
			$value_family_low_case = strtolower( $values['font_family'] );
			$font_family_low_case_with_style = $font_family_low_case . ':' . $font_data->font_styles;
			$selected =
				$value_family_low_case === $font_family_low_case ||
				$value_family_low_case === $font_family_low_case_with_style;
			$font_style_options[] = [
				'value' => $font_family_slug . ':' . $font_data->font_styles,
				'label' => $font_data->font_family,
				'selected' => $selected,
				'class' => vc_build_safe_css_class( $font_data->font_family ),
				'is_disabled' => $is_disabled,
				'font_data' => [
					'font_types' => $font_data->font_types,
					'font_family' => $font_family_slug,
					'font_styles' => $font_data->font_styles,
					'font_vendor' => $font_vendor,
					'font_url' => $font_url,
					'css' => empty( $font_data->css ) ? '' : $font_data->css,
				],
			];
		}

		return $font_style_options;
	}

	/**
	 * Load google fonts list for param
	 * To change this list use add_filters('vc_google_fonts_get_fonts_filter','your_custom_function'); and change array
	 *
	 * @see vc_filter: vc_google_fonts_get_fonts_filter
	 *
	 * @return array
	 * @since 4.3
	 */
	public function _vc_google_fonts_get_fonts() { // phpcs:ignore:PSR2.Methods.MethodDeclaration.Underscore
		return apply_filters( 'vc_google_fonts_get_fonts_filter', json_decode( $this->fonts_list ) );
	}

	/**
	 * Parse param attributes.
	 *
	 * @param mixed $attr - fields list from param settings, expected to be an array.
	 * @param string|array $value
	 *
	 * @return array
	 * @since 4.3
	 */
	public function _vc_google_fonts_parse_attributes( $attr, $value ) { // phpcs:ignore:PSR2.Methods.MethodDeclaration.Underscore
		$fields = [];
		if ( is_array( $attr ) && ! empty( $attr ) ) {
			foreach ( $attr as $key => $val ) {
				if ( is_numeric( $key ) ) {
					$fields[ $val ] = '';
				} else {
					$fields[ $key ] = $val;
				}
			}
		}

		$values = vc_parse_multi_attribute( $value, [
			'font_family' => $fields['font_family'] ?? '',
			'font_style' => $fields['font_style'] ?? '',
			'font_family_description' => $fields['font_family_description'] ?? '',
			'font_style_description' => $fields['font_style_description'] ?? '',
		] );

		return [
			'fields' => $fields,
			'values' => $values,
		];
	}

	/**
	 * Registers the google_fonts parameter with Visual Composer, including its font preview script.
	 *
	 * @since 9.1
	 */
	public static function load_google_fonts_param() {
		vc_add_shortcode_param( 'google_fonts', 'vc_google_fonts_form_field', vc_asset_url( 'js/dist/google-font-preview.min.js' ) );
	}
}

add_action( 'vc_load_default_params', [ 'Vc_Google_Fonts', 'load_google_fonts_param' ] );

/**
 * Function for rendering param in edit form (add element)
 * Parse settings from vc_map and entered values.
 *
 * @since 4.3
 * @param array $settings
 * @param string|array $value
 * @param string $tag
 * @param string $param_id
 * @return mixed rendered template for params in edit form
 * vc_filter: vc_google_fonts_render_filter
 */
function vc_google_fonts_form_field( $settings, $value, $tag, $param_id ) {
	$google_fonts = new Vc_Google_Fonts();

	return apply_filters( 'vc_google_fonts_render_filter', $google_fonts->render( $settings, $value, $param_id ) );
}
