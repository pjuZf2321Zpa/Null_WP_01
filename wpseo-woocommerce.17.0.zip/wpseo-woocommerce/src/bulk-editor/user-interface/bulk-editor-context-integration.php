<?php

// phpcs:disable Yoast.NamingConventions.NamespaceName.TooLong -- Needed in the folder structure.
// phpcs:disable Yoast.NamingConventions.NamespaceName.MaxExceeded -- Needed in the folder structure.

namespace Yoast\WP\SEO\WooCommerce\Bulk_Editor\User_Interface;

use WC_Product;
use Yoast\WP\SEO\Integrations\Integration_Interface;
use Yoast\WP\SEO\WooCommerce\Conditionals\WooCommerce_Conditional;

/**
 * Adds product-specific context data to the bulk editor's post context.
 *
 * phpcs:disable Yoast.NamingConventions.ObjectNameDepth.MaxExceeded
 */
class Bulk_Editor_Context_Integration implements Integration_Interface {

	/**
	 * Returns the conditionals based on which this loadable should be active.
	 *
	 * @return array<string> The conditionals.
	 */
	public static function get_conditionals(): array {
		return [ WooCommerce_Conditional::class ];
	}

	/**
	 * Registers the hooks.
	 *
	 * @return void
	 */
	public function register_hooks() {
		\add_filter( 'wpseo_bulk_editor_post_context', [ $this, 'add_product_context' ], 10, 3 );
	}

	/**
	 * Adds product-specific context to the bulk editor post data.
	 *
	 * For products, this adds the short description so the bulk editor can display
	 * it alongside the SEO fields as additional context.
	 *
	 * @param array<string, string> $context      The context data, empty by default.
	 * @param int                   $post_id      The post ID.
	 * @param string                $content_type The post type.
	 *
	 * @return array<string, string> The context data, extended with the product short description for products.
	 */
	public function add_product_context( $context, $post_id, $content_type ): array {
		if ( $content_type !== 'product' ) {
			return $context;
		}

		$product = \wc_get_product( $post_id );
		if ( ! $product instanceof WC_Product ) {
			return $context;
		}

		$context['short_description'] = $product->get_short_description();

		return $context;
	}
}
