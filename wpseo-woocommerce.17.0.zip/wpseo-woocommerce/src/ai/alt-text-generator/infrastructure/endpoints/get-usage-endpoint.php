<?php
// phpcs:disable Yoast.NamingConventions.NamespaceName.TooLong -- Needed in the folder structure.
// phpcs:disable Yoast.NamingConventions.NamespaceName.MaxExceeded -- Needed in the folder structure.
namespace Yoast\WP\SEO\WooCommerce\AI\Alt_Text_Generator\Infrastructure\Endpoints;

use Yoast\WP\SEO\AI\Generator\Infrastructure\Endpoints\Get_Usage_Endpoint as Free_Get_Usage_Endpoint;

/**
 * Describes the get-usage REST endpoint towards the JavaScript client.
 *
 * @phpcs:disable Yoast.NamingConventions.ObjectNameDepth.MaxExceeded
 */
class Get_Usage_Endpoint extends Free_Get_Usage_Endpoint implements Alt_Text_Generator_Endpoint_Interface {}
