<?php
// phpcs:disable Yoast.NamingConventions.NamespaceName.TooLong -- Needed in the folder structure.
// phpcs:disable Yoast.NamingConventions.NamespaceName.MaxExceeded -- Needed in the folder structure.
namespace Yoast\WP\SEO\WooCommerce\AI\Alt_Text_Generator\Infrastructure\Endpoints;

use Yoast\WP\SEO\AI\Consent\Infrastructure\Endpoints\Consent_Endpoint as Free_Consent_Endpoint;

/**
 * Describes the AI consent REST endpoint towards the JavaScript client.
 *
 * @phpcs:disable Yoast.NamingConventions.ObjectNameDepth.MaxExceeded
 */
class Consent_Endpoint extends Free_Consent_Endpoint implements Alt_Text_Generator_Endpoint_Interface {}
