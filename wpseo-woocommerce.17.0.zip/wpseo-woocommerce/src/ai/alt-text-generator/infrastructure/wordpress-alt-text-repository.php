<?php
// phpcs:disable Yoast.NamingConventions.NamespaceName.TooLong
// phpcs:disable Yoast.NamingConventions.NamespaceName.MaxExceeded
namespace Yoast\WP\SEO\WooCommerce\AI\Alt_Text_Generator\Infrastructure;

use Yoast\WP\SEO\WooCommerce\AI\Alt_Text_Generator\Application\Alt_Text_Repository_Interface;

/**
 * Persists the alt text of an image in the attachment meta WordPress reads it from.
 *
 * @phpcs:disable Yoast.NamingConventions.ObjectNameDepth.MaxExceeded
 */
class WordPress_Alt_Text_Repository implements Alt_Text_Repository_Interface {

	/**
	 * The meta key WordPress itself reads the alt text of an attachment from.
	 *
	 * @var string
	 */
	public const ALT_TEXT_META_KEY = '_wp_attachment_image_alt';

	/**
	 * Saves the alt text of the given attachment.
	 *
	 * @param int    $attachment_id The attachment ID of the image.
	 * @param string $alt_text      The unslashed alt text to save.
	 *
	 * @return bool Whether the image has the given alt text afterwards.
	 */
	public function save( int $attachment_id, string $alt_text ): bool {
		// If the alt text is unchanged, report success immediately (update_post_meta returns false when the value is unchanged).
		if ( \get_post_meta( $attachment_id, self::ALT_TEXT_META_KEY, true ) === $alt_text ) {
			return true;
		}

		// Slash the alt text, because update_post_meta unslashes the value it is passed.
		return \update_post_meta( $attachment_id, self::ALT_TEXT_META_KEY, \wp_slash( $alt_text ) ) !== false;
	}
}
