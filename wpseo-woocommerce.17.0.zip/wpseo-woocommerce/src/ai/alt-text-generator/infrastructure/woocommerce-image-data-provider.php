<?php

// phpcs:disable Yoast.NamingConventions.NamespaceName.TooLong -- Needed in the folder structure.
// phpcs:disable Yoast.NamingConventions.NamespaceName.MaxExceeded -- Needed in the folder structure.

namespace Yoast\WP\SEO\WooCommerce\AI\Alt_Text_Generator\Infrastructure;

use WC_Product;
use WC_Product_Variable;
use Yoast\WP\SEO\WooCommerce\AI\Alt_Text_Generator\Application\Image_Data_Provider_Interface;

/**
 * Provides the image data from WooCommerce and WordPress.
 *
 * phpcs:disable Yoast.NamingConventions.ObjectNameDepth.MaxExceeded
 */
class WooCommerce_Image_Data_Provider implements Image_Data_Provider_Interface {

	/**
	 * The meta key the retired Additional Variation Images extension stored variation galleries in.
	 *
	 * @var string
	 */
	private const LEGACY_VARIATION_GALLERY_META_KEY = '_wc_additional_variation_images';

	/**
	 * The meta key WooCommerce sets on a variation once its gallery is managed by core, which stops
	 * the fallback to the legacy meta.
	 *
	 * @var string
	 */
	private const LEGACY_VARIATION_GALLERY_FALLBACK_DISABLED_META_KEY = '_wc_variation_gallery_legacy_fallback_disabled';

	/**
	 * The filter WooCommerce hooks its fallback to the legacy meta into. It only registers that
	 * fallback when its variation gallery feature is on.
	 *
	 * @var string
	 */
	private const VARIATION_GALLERY_FILTER = 'woocommerce_product_variation_get_gallery_image_ids';

	/**
	 * The retrieved products, keyed by product ID. Null when the ID is not a product's.
	 *
	 * @var array<int, WC_Product|null>
	 */
	private $products = [];

	/**
	 * Retrieves the attachment ID of the product image (the featured image).
	 *
	 * @param int $product_id The product ID.
	 *
	 * @return int The attachment ID. Zero when there is none or the ID is not a product's.
	 */
	public function get_featured_image_id( int $product_id ): int {
		$product = $this->get_product( $product_id );
		if ( $product === null ) {
			return 0;
		}

		return (int) $product->get_image_id();
	}

	/**
	 * Retrieves the attachment IDs of the product gallery images.
	 *
	 * @param int $product_id The product ID.
	 *
	 * @return array<int> The attachment IDs, without gallery entries that do not resolve to an
	 *                    attachment ID. Empty when the ID is not a product's.
	 */
	public function get_gallery_image_ids( int $product_id ): array {
		$product = $this->get_product( $product_id );
		if ( $product === null ) {
			return [];
		}

		// Gallery meta can hold stale or non-numeric tokens (importers, filters); drop what intval() zeroes out.
		return \array_filter( \array_map( 'intval', $product->get_gallery_image_ids() ) );
	}

	/**
	 * Retrieves the attachment IDs of the variations' own images, keyed by variation ID.
	 *
	 * A variation can hold several images: its own featured image (`_thumbnail_id`) plus its
	 * gallery (`_product_image_gallery`, the same meta key parent products use), which
	 * WooCommerce added in the variation gallery feature. Both are read directly from the
	 * bulk-primed post meta, so the gallery costs no extra queries.
	 *
	 * The featured image comes first, mirroring how WooCommerce presents the variation's images
	 * as one ordered list with the first as its primary. Variations sharing an attachment each
	 * keep their own entry, so consumers can reconcile per-variation changes.
	 *
	 * The featured image is read from the raw `_thumbnail_id` meta, which avoids the fallback to the
	 * parent product's image that `WC_Product_Variation::get_image_id()` applies in view context. That
	 * image is already reported as the featured image.
	 *
	 * @param int $product_id The product ID.
	 *
	 * @return array<int, array<int>> The attachment IDs, keyed by variation ID. Only variations with at
	 *                                least one image are included. Empty when the product is not a
	 *                                variable product.
	 */
	public function get_variation_image_map( int $product_id ): array {
		$product = $this->get_product( $product_id );
		if ( ! $product instanceof WC_Product_Variable ) {
			return [];
		}

		$variation_ids = $product->get_children();
		if ( $variation_ids === [] ) {
			return [];
		}

		// Only the meta cache is primed; the loop reads nothing but meta, so fetching full post rows would be wasted.
		\update_meta_cache( 'post', $variation_ids );

		$image_ids = [];
		foreach ( $variation_ids as $variation_id ) {
			$variation_image_ids = \array_merge(
				[ (int) \get_post_meta( $variation_id, '_thumbnail_id', true ) ],
				$this->get_variation_gallery_image_ids( (int) $variation_id ),
			);

			// A variation without an own image has no `_thumbnail_id`, which casts to zero. The gallery can repeat that image.
			$variation_image_ids = \array_values( \array_unique( \array_filter( $variation_image_ids ) ) );
			if ( $variation_image_ids !== [] ) {
				$image_ids[ (int) $variation_id ] = $variation_image_ids;
			}
		}

		return $image_ids;
	}

	/**
	 * Retrieves the attachment IDs of a single variation's gallery images.
	 *
	 * The meta holds a comma-separated list, the same format parent products use. Reading the meta
	 * rather than `WC_Product_Variation::get_gallery_image_ids()` keeps this on the primed meta
	 * cache: instantiating every variation would undo the bulk priming.
	 *
	 * Skipping that getter also skips its filter, so the fallback WooCommerce hooks into it is copied
	 * here: while a variation's gallery is empty and core has not taken it over yet, the gallery the
	 * Additional Variation Images extension stored is used. The editor's gallery input shows that
	 * fallback too, so without it the images would only start counting once the Variations tab loads.
	 * The fallback only applies while that filter has a callback: without the variation gallery
	 * feature (before WooCommerce 11.0, or with it switched off), the rows only hold the variation's
	 * own image, so counting the legacy gallery would drop images once the Variations tab loads.
	 *
	 * @param int $variation_id The variation ID.
	 *
	 * @return array<int> The attachment IDs, in their stored order.
	 */
	private function get_variation_gallery_image_ids( int $variation_id ): array {
		$gallery_image_ids = $this->get_id_list_meta( $variation_id, '_product_image_gallery' );
		if ( $gallery_image_ids !== [] ) {
			return $gallery_image_ids;
		}

		if ( ! \has_filter( self::VARIATION_GALLERY_FILTER )
			|| \metadata_exists( 'post', $variation_id, self::LEGACY_VARIATION_GALLERY_FALLBACK_DISABLED_META_KEY )
		) {
			return [];
		}

		return $this->get_id_list_meta( $variation_id, self::LEGACY_VARIATION_GALLERY_META_KEY );
	}

	/**
	 * Retrieves a comma-separated list of attachment IDs stored in a post meta.
	 *
	 * The list is parsed the way WooCommerce parses it, with `wp_parse_id_list()`: it can hold stale
	 * or non-numeric tokens (importers, filters), which end up as zero and are dropped.
	 *
	 * @param int    $post_id  The post ID.
	 * @param string $meta_key The meta key.
	 *
	 * @return array<int> The attachment IDs, in their stored order and without duplicates. Empty when
	 *                    the meta is not a string.
	 */
	private function get_id_list_meta( int $post_id, string $meta_key ): array {
		$ids = \get_post_meta( $post_id, $meta_key, true );
		if ( ! \is_string( $ids ) || $ids === '' ) {
			return [];
		}

		return \array_values( \array_filter( \wp_parse_id_list( $ids ) ) );
	}

	/**
	 * Resolves the URL and alt text of the given attachments in bulk.
	 *
	 * Every given attachment ID gets an entry — one that no longer resolves to an image gets an
	 * empty url — so consumers can index into the result without checking.
	 *
	 * @param array<int> $attachment_ids The attachment IDs.
	 *
	 * @return array<int, array<string, string>> The src and alt, keyed by attachment ID.
	 */
	public function get_attachment_data( array $attachment_ids ): array {
		if ( $attachment_ids === [] ) {
			return [];
		}

		\_prime_post_caches( $attachment_ids, false, true );

		$data = [];
		foreach ( $attachment_ids as $attachment_id ) {
			$data[ $attachment_id ] = [
				// The AI service has to make out the details of the image, which a thumbnail is too small to show.
				'src' => (string) \wp_get_attachment_image_url( $attachment_id, 'large' ),
				'alt' => (string) \get_post_meta( $attachment_id, '_wp_attachment_image_alt', true ),
			];
		}

		return $data;
	}

	/**
	 * Retrieves a product, memoized as the getters are called back-to-back for the same product.
	 *
	 * WooCommerce's factory does not cache by default, so without this every getter would run a
	 * full product read.
	 *
	 * @param int $product_id The product ID.
	 *
	 * @return WC_Product|null The product. Null when the ID is not a product's.
	 */
	private function get_product( int $product_id ): ?WC_Product {
		if ( ! \array_key_exists( $product_id, $this->products ) ) {
			$product = \wc_get_product( $product_id );

			$this->products[ $product_id ] = ( $product instanceof WC_Product ) ? $product : null;
		}

		return $this->products[ $product_id ];
	}
}
