<?php
// phpcs:disable Yoast.NamingConventions.NamespaceName.TooLong -- Needed in the folder structure.

namespace Yoast\WP\SEO\WooCommerce\AI\Alt_Text_Generator\Domain;

/**
 * This class holds the rule for how many product attributes are sent to the AI API.
 */
class Attribute_Limit {

	/**
	 * The maximum number of product attributes sent to the AI API.
	 *
	 * @var int
	 */
	public const MAX_ATTRIBUTES = 10;

	/**
	 * Whether the given number of attributes is within the limit.
	 *
	 * @param int $count The number of attributes.
	 *
	 * @return bool Whether the given number of attributes is within the limit.
	 */
	public static function is_within_limit( int $count ): bool {
		return $count <= self::MAX_ATTRIBUTES;
	}
}
