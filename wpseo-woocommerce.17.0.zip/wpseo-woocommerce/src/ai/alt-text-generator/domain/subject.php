<?php

// phpcs:disable Yoast.NamingConventions.NamespaceName.TooLong -- Needed in the folder structure.
// phpcs:disable Yoast.NamingConventions.NamespaceName.MaxExceeded -- Needed in the folder structure.

namespace Yoast\WP\SEO\WooCommerce\AI\Alt_Text_Generator\Domain;

/**
 * Represents a single image to request alt text for, along with the context of the product it belongs to.
 */
class Subject {

	/**
	 * The attachment ID of the image, echoed back by the AI service.
	 *
	 * @var string
	 */
	private $id = '';

	/**
	 * The URL of the image.
	 *
	 * @var string
	 */
	private $image_url = '';

	/**
	 * All the places the image is used for the product.
	 *
	 * @var array<string>
	 */
	private $image_types = [];

	/**
	 * The language the product description is written in.
	 *
	 * @var string
	 */
	private $language = '';

	/**
	 * The focus keyphrase associated to the product.
	 *
	 * @var string
	 */
	private $focus_keyphrase = '';

	/**
	 * The title of the product.
	 *
	 * @var string
	 */
	private $product_title = '';

	/**
	 * The short description of the product.
	 *
	 * @var string
	 */
	private $product_short_description = '';

	/**
	 * The attributes of the product.
	 *
	 * @var array<string>
	 */
	private $attributes = [];

	/**
	 * The existing alt text of the image.
	 *
	 * @var string
	 */
	private $existing_alt_text = '';

	/**
	 * The attributes shared by every variation the image is used for.
	 *
	 * @var array<string, string>
	 */
	private $variation_attributes = [];

	/**
	 * Sets the attachment ID of the image.
	 *
	 * @param string $id The attachment ID of the image.
	 *
	 * @return void
	 */
	public function set_id( string $id ): void {
		$this->id = $id;
	}

	/**
	 * Sets the URL of the image.
	 *
	 * @param string $image_url The URL of the image.
	 *
	 * @return void
	 */
	public function set_image_url( string $image_url ): void {
		$this->image_url = $image_url;
	}

	/**
	 * Sets all the places the image is used for the product.
	 *
	 * @param array<string> $image_types All the places the image is used for the product.
	 *
	 * @return void
	 */
	public function set_image_types( array $image_types ): void {
		$this->image_types = $image_types;
	}

	/**
	 * Sets the language the product description is written in.
	 *
	 * @param string $language The language the product description is written in.
	 *
	 * @return void
	 */
	public function set_language( string $language ): void {
		$this->language = $language;
	}

	/**
	 * Sets the focus keyphrase associated to the product.
	 *
	 * @param string $focus_keyphrase The focus keyphrase associated to the product.
	 *
	 * @return void
	 */
	public function set_focus_keyphrase( string $focus_keyphrase ): void {
		$this->focus_keyphrase = $focus_keyphrase;
	}

	/**
	 * Sets the title of the product.
	 *
	 * @param string $product_title The title of the product.
	 *
	 * @return void
	 */
	public function set_product_title( string $product_title ): void {
		$this->product_title = $product_title;
	}

	/**
	 * Sets the short description of the product.
	 *
	 * @param string $product_short_description The short description of the product.
	 *
	 * @return void
	 */
	public function set_product_short_description( string $product_short_description ): void {
		$this->product_short_description = $product_short_description;
	}

	/**
	 * Sets the attributes of the product.
	 *
	 * @param array<string> $attributes The attributes of the product.
	 *
	 * @return void
	 */
	public function set_attributes( array $attributes ): void {
		$this->attributes = $attributes;
	}

	/**
	 * Sets the existing alt text of the image.
	 *
	 * @param string $existing_alt_text The existing alt text of the image.
	 *
	 * @return void
	 */
	public function set_existing_alt_text( string $existing_alt_text ): void {
		$this->existing_alt_text = $existing_alt_text;
	}

	/**
	 * Sets the attributes shared by every variation the image is used for.
	 *
	 * @param array<string, string> $variation_attributes The attributes shared by every variation.
	 *
	 * @return void
	 */
	public function set_variation_attributes( array $variation_attributes ): void {
		$this->variation_attributes = $variation_attributes;
	}

	/**
	 * Returns the subject as the AI API payload expects it.
	 *
	 * Context that carries no value is left out, so the AI service is not given empty context to work with.
	 *
	 * @return array<string, string|array> The subject.
	 */
	public function to_array(): array {
		$subject = [
			'language'        => $this->language,
			'focus_keyphrase' => $this->focus_keyphrase,
		];

		$optional_fields = [
			'product_title'             => $this->product_title,
			'product_short_description' => $this->product_short_description,
			'attributes'                => $this->attributes,
		];
		foreach ( $optional_fields as $field => $value ) {
			if ( $value !== '' && $value !== [] ) {
				$subject[ $field ] = $value;
			}
		}

		$subject['id']          = $this->id;
		$subject['image_url']   = $this->image_url;
		$subject['image_types'] = $this->image_types;

		if ( $this->existing_alt_text !== '' ) {
			$subject['existing_alt_text'] = $this->existing_alt_text;
		}

		if ( $this->variation_attributes !== [] ) {
			$subject['variation_attributes'] = $this->variation_attributes;
		}

		return $subject;
	}
}
