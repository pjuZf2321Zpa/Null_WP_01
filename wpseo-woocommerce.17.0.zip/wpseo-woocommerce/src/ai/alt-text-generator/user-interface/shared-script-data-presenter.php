<?php

// phpcs:disable Yoast.NamingConventions.NamespaceName.TooLong -- Needed in the folder structure.
// phpcs:disable Yoast.NamingConventions.NamespaceName.MaxExceeded -- Needed in the folder structure.

namespace Yoast\WP\SEO\WooCommerce\AI\Alt_Text_Generator\User_Interface;

use WPSEO_Addon_Manager;
use Yoast\WP\SEO\Helpers\Options_Helper;
use Yoast\WP\SEO\Helpers\Short_Link_Helper;
use Yoast\WP\SEO\Helpers\User_Helper;
use Yoast\WP\SEO\WooCommerce\Infrastructure\Plugin_URL_Provider;

/**
 * Presents the script data shared by both alt text generator integrations.
 *
 * @phpcs:disable Yoast.NamingConventions.ObjectNameDepth.MaxExceeded
 */
class Shared_Script_Data_Presenter {

	/**
	 * The user helper.
	 *
	 * @var User_Helper
	 */
	private $user_helper;

	/**
	 * The short link helper.
	 *
	 * @var Short_Link_Helper
	 */
	private $short_link_helper;

	/**
	 * The plugin URL provider.
	 *
	 * @var Plugin_URL_Provider
	 */
	private $plugin_url_provider;

	/**
	 * The options helper.
	 *
	 * @var Options_Helper
	 */
	private $options_helper;

	/**
	 * The addon manager.
	 *
	 * @var WPSEO_Addon_Manager
	 */
	private $addon_manager;

	/**
	 * Constructs the presenter.
	 *
	 * @param User_Helper         $user_helper         The user helper.
	 * @param Short_Link_Helper   $short_link_helper   The short link helper.
	 * @param Plugin_URL_Provider $plugin_url_provider The plugin URL provider.
	 * @param Options_Helper      $options_helper      The options helper.
	 * @param WPSEO_Addon_Manager $addon_manager       The addon manager.
	 */
	public function __construct(
		User_Helper $user_helper,
		Short_Link_Helper $short_link_helper,
		Plugin_URL_Provider $plugin_url_provider,
		Options_Helper $options_helper,
		WPSEO_Addon_Manager $addon_manager
	) {
		$this->user_helper         = $user_helper;
		$this->short_link_helper   = $short_link_helper;
		$this->plugin_url_provider = $plugin_url_provider;
		$this->options_helper      = $options_helper;
		$this->addon_manager       = $addon_manager;
	}

	/**
	 * Returns the script data shared by both alt text generator integrations.
	 *
	 * @return array<string, string|bool|array<string, string>> The shared script data.
	 */
	public function present(): array {
		return [
			'isAiFeatureEnabled'   => $this->options_helper->get( 'enable_ai_generator', false ),
			'hasConsent'           => $this->user_helper->get_meta( $this->user_helper->get_current_user_id(), '_yoast_wpseo_ai_consent', true ),
			'pluginUrl'            => $this->plugin_url_provider->get(),
			'linkParams'           => $this->short_link_helper->get_query_params(),
			'hasValidSubscription' => $this->addon_manager->has_valid_subscription( WPSEO_Addon_Manager::WOOCOMMERCE_SLUG ),
			'adminUrl'             => \admin_url( 'admin.php' ),
		];
	}
}
