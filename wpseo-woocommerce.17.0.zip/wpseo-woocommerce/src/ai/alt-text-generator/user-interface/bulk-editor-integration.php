<?php

// phpcs:disable Yoast.NamingConventions.NamespaceName.TooLong -- Needed in the folder structure.
// phpcs:disable Yoast.NamingConventions.NamespaceName.MaxExceeded -- Needed in the folder structure.

namespace Yoast\WP\SEO\WooCommerce\AI\Alt_Text_Generator\User_Interface;

use Yoast\WP\SEO\Bulk_Editor\User_Interface\Bulk_Editor_Integration as Free_Bulk_Editor_Integration;
use Yoast\WP\SEO\Helpers\Current_Page_Helper;
use Yoast\WP\SEO\Integrations\Integration_Interface;
use Yoast\WP\SEO\WooCommerce\AI\Alt_Text_Generator\Application\Alt_Text_Generator_Endpoints_Repository;
use Yoast\WP\SEO\WooCommerce\AI\Alt_Text_Generator\Application\Product_Images_Repository;
use Yoast\WP\SEO\WooCommerce\AI\Alt_Text_Generator\Domain\Image_Collection;
use Yoast\WP\SEO\WooCommerce\Application\Assets_Manager;
use Yoast\WP\SEO\WooCommerce\Conditionals\WooCommerce_Conditional;
use Yoast\WP\SEO\WooCommerce\Infrastructure\WordPress_Assets_Manager;
use Yoast\WP\SEO\WooCommerce\Infrastructure\WordPress_Translations_Manager;

/**
 * Adds the product specific images to the images the bulk editor can generate alt text for,
 * and enqueues the WooCommerce image alt text fill on the bulk editor page.
 */
class Bulk_Editor_Integration implements Integration_Interface {

	/**
	 * The handle of the script enqueued on the bulk editor page.
	 *
	 * @var string
	 */
	public const SCRIPT_HANDLE = 'bulk-editor-image-alt-text';

	/**
	 * The name of the global object the script data is exposed on.
	 *
	 * @var string
	 */
	public const SCRIPT_DATA_NAME = 'wpseoWooBulkEditorData';

	/**
	 * The product images repository.
	 *
	 * @var Product_Images_Repository
	 */
	private $product_images_repository;

	/**
	 * The assets manager of this plugin.
	 *
	 * @var Assets_Manager
	 */
	private $assets_manager;

	/**
	 * Localizes a script with the JS translations of this plugin.
	 *
	 * @var WordPress_Translations_Manager
	 */
	private $translations_manager;

	/**
	 * The current page helper.
	 *
	 * @var Current_Page_Helper
	 */
	private $current_page_helper;

	/**
	 * The shared script data presenter.
	 *
	 * @var Shared_Script_Data_Presenter
	 */
	private $shared_script_data_presenter;

	/**
	 * The alt text generator endpoints repository.
	 *
	 * @var Alt_Text_Generator_Endpoints_Repository
	 */
	private $endpoints_repository;

	/**
	 * Constructs the integration.
	 *
	 * @param Product_Images_Repository               $product_images_repository    The product images repository.
	 * @param Assets_Manager                          $assets_manager               The assets manager of this plugin.
	 * @param WordPress_Translations_Manager          $translations_manager         Localizes a script with the JS translations
	 *                                                                               of this plugin.
	 * @param Current_Page_Helper                     $current_page_helper          The current page helper.
	 * @param Shared_Script_Data_Presenter            $shared_script_data_presenter The shared script data presenter.
	 * @param Alt_Text_Generator_Endpoints_Repository $endpoints_repository         The alt text generator endpoints repository.
	 */
	public function __construct(
		Product_Images_Repository $product_images_repository,
		Assets_Manager $assets_manager,
		WordPress_Translations_Manager $translations_manager,
		Current_Page_Helper $current_page_helper,
		Shared_Script_Data_Presenter $shared_script_data_presenter,
		Alt_Text_Generator_Endpoints_Repository $endpoints_repository
	) {
		$this->product_images_repository    = $product_images_repository;
		$this->assets_manager               = $assets_manager;
		$this->translations_manager         = $translations_manager;
		$this->current_page_helper          = $current_page_helper;
		$this->shared_script_data_presenter = $shared_script_data_presenter;
		$this->endpoints_repository         = $endpoints_repository;
	}

	/**
	 * Returns the conditionals based on which this loadable should be active.
	 *
	 * @return array<string> The conditionals.
	 */
	public static function get_conditionals(): array {
		return [ WooCommerce_Conditional::class ];
	}

	/**
	 * Registers the hooks.
	 *
	 * @return void
	 */
	public function register_hooks() {
		\add_filter( 'wpseo_bulk_editor_post_images', [ $this, 'add_alt_text_generator_data' ], 10, 3 );

		if ( $this->current_page_helper->get_current_yoast_seo_page() === Free_Bulk_Editor_Integration::PAGE ) {
			\add_action( 'admin_init', [ $this->assets_manager, 'register_assets' ] );
			\add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_assets' ] );
		}
	}

	/**
	 * Enqueues the WooCommerce image alt text fill script on the bulk editor page.
	 *
	 * @return void
	 */
	public function enqueue_assets() {
		$this->assets_manager->enqueue_script( self::SCRIPT_HANDLE, self::SCRIPT_DATA_NAME, $this->get_script_data() );
		$this->assets_manager->enqueue_style( 'bulk-editor' );
		$this->translations_manager->localize_script( WordPress_Assets_Manager::PREFIX . self::SCRIPT_HANDLE );
	}

	/**
	 * Returns the script data for the bulk editor image alt text fill.
	 *
	 * @return array<string, string|bool|array<string>|array<array<string, int|string>>> The script data.
	 */
	public function get_script_data(): array {
		return \array_merge(
			$this->shared_script_data_presenter->present(),
			[
				'endpoints'            => $this->endpoints_repository->get_all_endpoints()->to_paths_array(),
			],
		);
	}

	/**
	 * Adds the product images to the images of the bulk editor.
	 *
	 * @param array<string, array<array<string, int|string>>> $image_list   The images the bulk editor already knows
	 *                                          about. Ignored for now.
	 * @param int                                             $product_id   The ID of the post the images belong to.
	 * @param string                                          $content_type The post type of the post the images belong
	 *                                                                      to.
	 *
	 * @return array<array<string, int|string>>
	 */
	public function add_alt_text_generator_data( $image_list, $product_id, $content_type ): array {
		if ( $content_type === 'product' ) {
			return $this->product_images_repository->get_images( $product_id )->to_array();
		}

		return ( new Image_Collection() )->to_array();
	}
}
