<?php

// phpcs:disable Yoast.NamingConventions.NamespaceName.TooLong -- Needed in the folder structure.
// phpcs:disable Yoast.NamingConventions.NamespaceName.MaxExceeded -- Needed in the folder structure.

namespace Yoast\WP\SEO\WooCommerce\AI\Alt_Text_Generator\User_Interface;

use Throwable;
use WC_Product_Variable;
use Yoast\WP\SEO\Helpers\Current_Page_Helper;
use Yoast\WP\SEO\Integrations\Integration_Interface;
use Yoast\WP\SEO\WooCommerce\AI\Alt_Text_Generator\Application\Alt_Text_Generator_Endpoints_Repository;
use Yoast\WP\SEO\WooCommerce\AI\Alt_Text_Generator\Application\Product_Images_Repository;
use Yoast\WP\SEO\WooCommerce\Application\Assets_Manager;
use Yoast\WP\SEO\WooCommerce\Conditionals\Product_Editor_Conditional;
use Yoast\WP\SEO\WooCommerce\Conditionals\WooCommerce_Conditional;
use Yoast\WP\SEO\WooCommerce\Infrastructure\WordPress_Assets_Manager;
use Yoast\WP\SEO\WooCommerce\Infrastructure\WordPress_Translations_Manager;

/**
 * Exposes the script data used by the AI alt text generator on product editor pages.
 *
 * phpcs:disable Yoast.NamingConventions.ObjectNameDepth.MaxExceeded
 */
class Alt_Text_Generator_Integration implements Integration_Interface {

	/**
	 * The handle of the script the data is attached to.
	 *
	 * @var string
	 */
	public const SCRIPT_HANDLE = 'alt-text-generator';

	/**
	 * The name of the global object the script data is exposed on.
	 *
	 * @var string
	 */
	public const SCRIPT_OBJECT_NAME = 'wpseoWooAltTextGenerator';

	/**
	 * The current page helper.
	 *
	 * @var Current_Page_Helper
	 */
	private $current_page_helper;

	/**
	 * The product images repository.
	 *
	 * @var Product_Images_Repository
	 */
	private $product_images_repository;

	/**
	 * The assets manager of this plugin.
	 *
	 * @var Assets_Manager
	 */
	private $assets_manager;

	/**
	 * Localizes a script with the JS translations of this plugin.
	 *
	 * @var WordPress_Translations_Manager
	 */
	private $translations_manager;

	/**
	 * The shared script data presenter.
	 *
	 * @var Shared_Script_Data_Presenter
	 */
	private $shared_script_data_presenter;

	/**
	 * The alt text generator endpoints repository.
	 *
	 * @var Alt_Text_Generator_Endpoints_Repository
	 */
	private $endpoints_repository;

	/**
	 * Returns the conditionals based on which this loadable should be active.
	 *
	 * @return array<string> The conditionals.
	 */
	public static function get_conditionals(): array {
		// No AI conditional: the analysis reads this data too, so it must be present regardless of the AI features.
		return [ WooCommerce_Conditional::class, Product_Editor_Conditional::class ];
	}

	/**
	 * Constructs the integration.
	 *
	 * @param Current_Page_Helper                     $current_page_helper          The current page helper.
	 * @param Product_Images_Repository               $product_images_repository    The product images repository.
	 * @param Assets_Manager                          $assets_manager               The assets manager of this plugin.
	 * @param WordPress_Translations_Manager          $translations_manager         Localizes a script with the JS translations
	 *                                                                               of this plugin.
	 * @param Shared_Script_Data_Presenter            $shared_script_data_presenter The shared script data presenter.
	 * @param Alt_Text_Generator_Endpoints_Repository $endpoints_repository         The alt text generator endpoints repository.
	 */
	public function __construct(
		Current_Page_Helper $current_page_helper,
		Product_Images_Repository $product_images_repository,
		Assets_Manager $assets_manager,
		WordPress_Translations_Manager $translations_manager,
		Shared_Script_Data_Presenter $shared_script_data_presenter,
		Alt_Text_Generator_Endpoints_Repository $endpoints_repository
	) {
		$this->current_page_helper          = $current_page_helper;
		$this->product_images_repository    = $product_images_repository;
		$this->assets_manager               = $assets_manager;
		$this->translations_manager         = $translations_manager;
		$this->shared_script_data_presenter = $shared_script_data_presenter;
		$this->endpoints_repository         = $endpoints_repository;
	}

	/**
	 * Registers the hooks.
	 *
	 * @return void
	 */
	public function register_hooks() {
		\add_action( 'admin_init', [ $this->assets_manager, 'register_assets' ] );
		\add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_assets' ] );
	}

	/**
	 * Enqueues the script that feeds the product images into the SEO analysis, with its data.
	 *
	 * @return void
	 */
	public function enqueue_assets() {
		$this->assets_manager->enqueue_script( self::SCRIPT_HANDLE, self::SCRIPT_OBJECT_NAME, $this->get_script_data() );
		$this->assets_manager->enqueue_style( 'tailwind' );
		$this->translations_manager->localize_script( WordPress_Assets_Manager::PREFIX . self::SCRIPT_HANDLE );
	}

	/**
	 * Returns the script data for the alt text generator.
	 *
	 * @return array<string, string|bool|array<string>|array<array<string, int|string>>> The script data.
	 */
	public function get_script_data(): array {
		$post_id = $this->current_page_helper->get_current_post_id();

		return \array_merge(
			[
				'images'                  => $this->get_images( $post_id ),
				'variableProductTypes'    => $this->get_variable_product_types(),
				'productShortDescription' => $this->get_product_short_description( $post_id ),
				'endpoints'               => $this->endpoints_repository->get_all_endpoints()->to_paths_array(),
			],
			$this->shared_script_data_presenter->present(),
		);
	}

	/**
	 * Retrieves the slugs of the product types whose registered class makes them variable products.
	 *
	 * Derived from the classes rather than the slugs, as extensions register the slug independently
	 * of the class — a WC_Product_Variable subclass is not required to use a "variable"-prefixed slug.
	 *
	 * @return array<string> The product type slugs.
	 */
	private function get_variable_product_types(): array {
		$types = [];
		foreach ( \array_keys( \wc_get_product_types() ) as $type ) {
			try {
				if ( \wc_get_product_object( $type ) instanceof WC_Product_Variable ) {
					$types[] = $type;
				}
			} catch ( Throwable $e ) {
				// A product class that cannot be instantiated without data cannot be checked; skip it.
				continue;
			}
		}

		return $types;
	}

	/**
	 * Retrieves the data of the images to possibly generate alt text for.
	 *
	 * @param int $post_id The ID of the current post.
	 *
	 * @return array<array<string, int|string>> The image data.
	 */
	private function get_images( int $post_id ): array {
		// On new product pages there is no post ID, and thus no images, yet.
		if ( $post_id === 0 ) {
			return [];
		}

		return $this->product_images_repository->get_images( $post_id )->to_array();
	}

	/**
	 * Retrieves the product short description for the current product.
	 *
	 * @param int $post_id The ID of the current post.
	 *
	 * @return string The short description, or an empty string when there is no current post or product.
	 */
	private function get_product_short_description( int $post_id ): string {
		if ( $post_id === 0 ) {
			return '';
		}

		$product = \wc_get_product( $post_id );
		if ( ! $product ) {
			return '';
		}

		return $product->get_short_description();
	}
}
