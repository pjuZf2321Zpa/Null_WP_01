<?php
// phpcs:disable Yoast.NamingConventions.NamespaceName.TooLong
// phpcs:disable Yoast.NamingConventions.NamespaceName.MaxExceeded
namespace Yoast\WP\SEO\WooCommerce\AI\Alt_Text_Generator\Application;

use WP_User;
use Yoast\WP\SEO\WooCommerce\AI\Alt_Text_Generator\Domain\Image_Validation_Exception;

/**
 * Validates an image attachment before its alt text is edited, or before alt text is generated for it.
 *
 * Two rules: an alt text written by hand is accepted for any image; a generated one only for the formats the
 * AI API can read. Generation only produces a suggestion; applying it saves through the same route, and the
 * same check, as an alt text typed by hand.
 */
interface Image_Validator_Interface {

	/**
	 * Validates that the given attachment is an image and that the user may edit it.
	 *
	 * @param WP_User $user          The user editing the image.
	 * @param int     $attachment_id The attachment ID of the image.
	 *
	 * @return void
	 *
	 * @throws Image_Validation_Exception When the attachment cannot be found, is not an image or the user may
	 *                                   not edit it.
	 */
	public function validate( WP_User $user, int $attachment_id ): void;

	/**
	 * Validates the given attachment for alt text generation: everything `validate` checks, plus that the
	 * image is in a format the AI service can read.
	 *
	 * @param WP_User $user          The user requesting the generation.
	 * @param int     $attachment_id The attachment ID of the image.
	 *
	 * @return void
	 *
	 * @throws Image_Validation_Exception When the attachment cannot be found, is not an image, the user may not
	 *                                   edit it or its format is not one the AI service can read.
	 */
	public function validate_for_generation( WP_User $user, int $attachment_id ): void;
}
