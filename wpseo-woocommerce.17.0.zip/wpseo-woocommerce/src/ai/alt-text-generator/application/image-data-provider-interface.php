<?php

// phpcs:disable Yoast.NamingConventions.NamespaceName.TooLong -- Needed in the folder structure.
// phpcs:disable Yoast.NamingConventions.NamespaceName.MaxExceeded -- Needed in the folder structure.

namespace Yoast\WP\SEO\WooCommerce\AI\Alt_Text_Generator\Application;

/**
 * Describes the image data the application layer needs from the infrastructure.
 *
 * phpcs:disable Yoast.NamingConventions.ObjectNameDepth.MaxExceeded
 */
interface Image_Data_Provider_Interface {

	/**
	 * Retrieves the attachment ID of the product image (the featured image).
	 *
	 * @param int $product_id The product ID.
	 *
	 * @return int The attachment ID. Zero when there is none or the ID is not a product's.
	 */
	public function get_featured_image_id( int $product_id ): int;

	/**
	 * Retrieves the attachment IDs of the product gallery images.
	 *
	 * @param int $product_id The product ID.
	 *
	 * @return array<int> The attachment IDs, non-zero — gallery entries that do not resolve to an
	 *                     attachment ID are dropped. Empty when the ID is not a product's.
	 */
	public function get_gallery_image_ids( int $product_id ): array;

	/**
	 * Retrieves the attachment IDs of the variations' own images, keyed by variation ID.
	 *
	 * A variation can hold several images: its own featured image plus its gallery, which
	 * WooCommerce added in the variation gallery feature. They are returned as one ordered list
	 * per variation, the primary first, deduplicated within the variation.
	 *
	 * Variations sharing an attachment each keep their own entry, so consumers can
	 * reconcile per-variation changes.
	 *
	 * @param int $product_id The product ID.
	 *
	 * @return array<int, array<int>> The attachment IDs, keyed by variation ID. Only variations with at
	 *                                least one image are included. Empty when the product is not a
	 *                                variable product.
	 */
	public function get_variation_image_map( int $product_id ): array;

	/**
	 * Resolves the URL and alt text of the given attachments in bulk.
	 *
	 * Every given attachment ID gets an entry — one that no longer resolves to an image gets an
	 * empty url — so consumers can index into the result without checking.
	 *
	 * @param array<int> $attachment_ids The attachment IDs.
	 *
	 * @return array<int, array<string, string>> The src and alt, keyed by attachment ID.
	 */
	public function get_attachment_data( array $attachment_ids ): array;
}
