<?php
// phpcs:disable Yoast.NamingConventions.NamespaceName.TooLong -- Needed in the folder structure.

namespace Yoast\WP\SEO\WooCommerce\AI\Alt_Text_Generator\Application;

use WP_User;
use Yoast\WP\SEO\WooCommerce\AI\Alt_Text_Generator\Domain\Product_Attributes;

/**
 * Command for requesting alt text generation for product images.
 *
 * @phpcs:disable Yoast.NamingConventions.ObjectNameDepth.MaxExceeded
 */
class Alt_Text_Generator_Command {

	/**
	 * The user.
	 *
	 * @var WP_User
	 */
	private $user;

	/**
	 * The images to generate alt text for. Each image holds its attachment ID, URL, the places it is used,
	 * its existing alt text and, for variation images, the attributes of each variation using it.
	 *
	 * @var array<int, array<string, int|string|array>>
	 */
	private $images;

	/**
	 * The focus keyphrase associated to the product.
	 *
	 * @var string
	 */
	private $focus_keyphrase;

	/**
	 * The title of the product the images belong to.
	 *
	 * @var string
	 */
	private $product_title;

	/**
	 * The short description of the product, if it exists.
	 *
	 * @var string
	 */
	private $product_short_description;

	/**
	 * The attributes of the product.
	 *
	 * @var Product_Attributes
	 */
	private $attributes;

	/**
	 * The language the site is written in.
	 *
	 * @var string
	 */
	private $language;

	/**
	 * The constructor.
	 *
	 * @param WP_User                                     $user                      The user.
	 * @param array<int, array<string, int|string|array>> $images                    The images to generate alt text for.
	 * @param string                                      $focus_keyphrase           The focus keyphrase associated to the product.
	 * @param string                                      $product_title             The title of the product the images belong to.
	 * @param string                                      $product_short_description The short description of the product, if it exists.
	 * @param Product_Attributes                          $attributes                The attributes of the product.
	 * @param string                                      $language                  The language the site is written in.
	 */
	public function __construct(
		WP_User $user,
		array $images,
		string $focus_keyphrase,
		string $product_title,
		string $product_short_description,
		Product_Attributes $attributes,
		string $language
	) {
		$this->user                      = $user;
		$this->images                    = $images;
		$this->focus_keyphrase           = $focus_keyphrase;
		$this->product_title             = $product_title;
		$this->product_short_description = $product_short_description;
		$this->attributes                = $attributes;
		$this->language                  = $language;
	}

	/**
	 * Returns the user.
	 *
	 * @return WP_User The user.
	 */
	public function get_user(): WP_User {
		return $this->user;
	}

	/**
	 * Returns the images to generate alt text for.
	 *
	 * @return array<int, array<string, int|string|array>> The images.
	 */
	public function get_images(): array {
		return $this->images;
	}

	/**
	 * Returns the focus keyphrase associated to the product.
	 *
	 * @return string The focus keyphrase.
	 */
	public function get_focus_keyphrase(): string {
		return $this->focus_keyphrase;
	}

	/**
	 * Returns the title of the product the images belong to.
	 *
	 * @return string The product title.
	 */
	public function get_product_title(): string {
		return $this->product_title;
	}

	/**
	 * Returns the short description of the product, if it exists.
	 *
	 * @return string The product short description.
	 */
	public function get_product_short_description(): string {
		return $this->product_short_description;
	}

	/**
	 * Returns the attributes of the product.
	 *
	 * @return Product_Attributes The attributes.
	 */
	public function get_attributes(): Product_Attributes {
		return $this->attributes;
	}

	/**
	 * Returns the language the site is written in.
	 *
	 * @return string The language.
	 */
	public function get_language(): string {
		return $this->language;
	}
}
