<?php
// phpcs:disable Yoast.NamingConventions.NamespaceName.TooLong -- Needed in the folder structure.
// phpcs:disable Yoast.NamingConventions.NamespaceName.MaxExceeded -- Needed in the folder structure.
namespace Yoast\WP\SEO\WooCommerce\AI\Alt_Text_Generator\Application;

use Yoast\WP\SEO\Routes\Endpoint\Endpoints_Repository;
use Yoast\WP\SEO\WooCommerce\AI\Alt_Text_Generator\Infrastructure\Endpoints\Alt_Text_Generator_Endpoint_Interface;

/**
 * Repository for the alt text generator REST endpoints.
 *
 * @phpcs:disable Yoast.NamingConventions.ObjectNameDepth.MaxExceeded
 */
class Alt_Text_Generator_Endpoints_Repository extends Endpoints_Repository {

	/**
	 * Constructs the repository.
	 *
	 * @param Alt_Text_Generator_Endpoint_Interface ...$endpoints The endpoints.
	 */
	public function __construct( Alt_Text_Generator_Endpoint_Interface ...$endpoints ) {
		parent::__construct( ...$endpoints );
	}
}
