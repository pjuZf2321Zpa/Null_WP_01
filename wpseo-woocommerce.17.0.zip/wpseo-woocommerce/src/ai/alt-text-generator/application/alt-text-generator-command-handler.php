<?php
// phpcs:disable Yoast.NamingConventions.NamespaceName.TooLong -- Needed in the folder structure.

namespace Yoast\WP\SEO\WooCommerce\AI\Alt_Text_Generator\Application;

use RuntimeException;
use Yoast\WP\SEO\AI\HTTP_Request\Domain\Exceptions\Forbidden_Exception;
use Yoast\WP\SEO\AI\HTTP_Request\Domain\Exceptions\Insufficient_Scope_Exception;
use Yoast\WP\SEO\WooCommerce\AI\Alt_Text_Generator\Domain\Image_Validation_Exception;
use Yoast\WP\SEO\WooCommerce\AI\Alt_Text_Generator\Domain\Subject;

/**
 * Handles the alt text generator command.
 *
 * @phpcs:disable Yoast.NamingConventions.ObjectNameDepth.MaxExceeded
 */
class Alt_Text_Generator_Command_Handler {

	/**
	 * The request sender.
	 *
	 * @var Alt_Text_Generator_Request_Sender
	 */
	private $request_sender;

	/**
	 * The image validator.
	 *
	 * @var Image_Validator_Interface
	 */
	private $image_validator;

	/**
	 * The constructor.
	 *
	 * @param Alt_Text_Generator_Request_Sender $request_sender  The request sender.
	 * @param Image_Validator_Interface         $image_validator The image validator.
	 */
	public function __construct(
		Alt_Text_Generator_Request_Sender $request_sender,
		Image_Validator_Interface $image_validator
	) {
		$this->request_sender  = $request_sender;
		$this->image_validator = $image_validator;
	}

	// phpcs:disable Squiz.Commenting.FunctionCommentThrowTag.WrongNumber -- PHPCS doesn't track exceptions thrown by called services.

	/**
	 * Handles the alt text generator command by requesting alt texts for the product images from the AI API.
	 *
	 * Images that fail locally (unknown attachment, no edit capability) are excluded from the AI request and
	 * returned as per-item error results; the remaining images are sent to the AI service in a single request.
	 *
	 * @param Alt_Text_Generator_Command $command The alt text generator command.
	 *
	 * @throws Insufficient_Scope_Exception When the OAuth path's token is missing the required scope.
	 * @throws Forbidden_Exception          When consent has been revoked.
	 * @throws RuntimeException             When the AI service response is malformed.
	 *
	 * @return array<string, array|null> The response envelope: summary, results and usage.
	 */
	public function handle( Alt_Text_Generator_Command $command ): array {
		$local_errors = $this->validate_images( $command );
		$subjects     = $this->build_subjects( $command, $local_errors );

		if ( $subjects === [] ) {
			return $this->envelope( \array_values( $local_errors ), null );
		}

		$envelope = $this->request_sender->send( $command->get_user(), $subjects );

		return $this->merge_results( $envelope, $subjects, $local_errors );
	}

	/**
	 * Builds the subjects sent to the AI API, one for every image that passed validation.
	 *
	 * @param Alt_Text_Generator_Command            $command      The command holding the images and product context.
	 * @param array<int, array<string, string|int>> $local_errors The images that failed validation, keyed by their
	 *                                                            position in the command's images.
	 *
	 * @return array<int, Subject> The subjects, keyed by the position of their image.
	 */
	private function build_subjects( Alt_Text_Generator_Command $command, array $local_errors ): array {
		$subjects = [];
		foreach ( $command->get_images() as $index => $image ) {
			if ( isset( $local_errors[ $index ] ) ) {
				continue;
			}

			$subjects[ $index ] = $this->build_subject( $image, $command );
		}

		return $subjects;
	}

	/**
	 * Builds the subject of a single image, on top of the context of the product it belongs to.
	 *
	 * @param array<string, int|string|array> $image   The image to build the subject for.
	 * @param Alt_Text_Generator_Command      $command The command holding the product context.
	 *
	 * @return Subject The subject of the image.
	 */
	private function build_subject( array $image, Alt_Text_Generator_Command $command ): Subject {
		$subject = new Subject();
		$subject->set_id( (string) $image['id'] );
		$subject->set_image_url( $image['url'] );
		$subject->set_image_types( $image['image_types'] );
		$subject->set_language( $command->get_language() );
		$subject->set_focus_keyphrase( $command->get_focus_keyphrase() );
		$subject->set_product_title( $command->get_product_title() );
		$subject->set_product_short_description( $command->get_product_short_description() );
		$subject->set_attributes( $command->get_attributes()->to_array() );
		$subject->set_existing_alt_text( ( $image['alt_text'] ?? '' ) );
		$subject->set_variation_attributes(
			$this->shared_variation_attributes( ( $image['attributes_per_variation'] ?? [] ) ),
		);

		return $subject;
	}

	/**
	 * Validates the images of the given command.
	 *
	 * @param Alt_Text_Generator_Command $command The command holding the images to validate.
	 *
	 * @return array<int, array<string, string|int>> The error entries of the images that failed validation, keyed by
	 *                                              their position in the command's images.
	 */
	private function validate_images( Alt_Text_Generator_Command $command ): array {
		$errors = [];
		foreach ( $command->get_images() as $index => $image ) {
			try {
				$this->image_validator->validate_for_generation( $command->get_user(), (int) $image['id'] );
			} catch ( Image_Validation_Exception $exception ) {
				$errors[ $index ] = [
					'id'         => (string) $image['id'],
					'index'      => $index,
					'status'     => 'error',
					'error_code' => $exception->get_error_code(),
					'message'    => $exception->getMessage(),
				];
			}
		}

		return $errors;
	}

	/**
	 * Returns the attributes shared by every variation the image is used for.
	 *
	 * An image can be used by multiple variations. Only the attributes that are identical across all of
	 * them actually describe what the image shows: an image used for "Color: Red, Size: S", "Color: Red,
	 * Size: M" and "Color: Red, Size: L" depicts the red product, not any particular size, so only
	 * "Color: Red" is kept.
	 *
	 * @param array<int, array<string, string>> $variations The attributes of each variation the image is used for.
	 *
	 * @return array<string, string> The attributes shared across all variations.
	 */
	private function shared_variation_attributes( array $variations ): array {
		$shared = null;
		foreach ( $variations as $variation ) {
			if ( $shared === null ) {
				$shared = $variation;
				continue;
			}

			$shared = \array_intersect_assoc( $shared, $variation );
		}

		return ( $shared ?? [] );
	}

	/**
	 * Merges the remote results with the locally rejected images into a single envelope.
	 *
	 * @param array<string, array|null>               $envelope     The decoded response envelope from the AI service.
	 * @param array<int, array<string, string|array>> $subjects     The subjects sent to the AI service, keyed by their original request index.
	 * @param array<int, array<string, int|string>>   $local_errors The locally rejected images, keyed by their original request index.
	 *
	 * @throws RuntimeException When a result entry from the AI service is malformed.
	 *
	 * @return array<string, array|null> The response envelope: summary, results and usage.
	 */
	private function merge_results( array $envelope, array $subjects, array $local_errors ): array {
		$remote_results  = \array_values( $envelope['results'] );
		$subject_indices = \array_keys( $subjects );

		// The local errors are already keyed by their original request index; slot the remote results back in
		// by the original index of the subject that was sent at the same position.
		$results = $local_errors;
		foreach ( $remote_results as $position => $result ) {
			if ( ! \is_array( $result ) ) {
				throw new RuntimeException( 'Malformed result entry from the AI service' );
			}
			$index             = $subject_indices[ $position ];
			$result['index']   = $index;
			$results[ $index ] = $result;
		}

		\ksort( $results );

		return $this->envelope( \array_values( $results ), ( $envelope['usage'] ?? null ) );
	}

	/**
	 * Builds the response envelope for the given results.
	 *
	 * Locally rejected images carry a non-'success' status just like the ones the AI service rejected, so a
	 * single pass over the results counts both error sources.
	 *
	 * @param array<int, array<string, string|array>> $results The results, ordered by the position of their image.
	 * @param array<string, int>|null                 $usage   The usage reported by the AI service, if any.
	 *
	 * @return array<string, array|null> The response envelope: summary, results and usage.
	 */
	private function envelope( array $results, $usage ): array {
		$failed = 0;
		foreach ( $results as $result ) {
			if ( ( $result['status'] ?? '' ) !== 'success' ) {
				++$failed;
			}
		}

		$total = \count( $results );

		return [
			'summary' => [
				'total'     => $total,
				'succeeded' => ( $total - $failed ),
				'failed'    => $failed,
			],
			'results' => $results,
			'usage'   => $usage,
		];
	}
}
