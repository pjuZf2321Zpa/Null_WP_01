<?php

namespace Yoast\WP\SEO\WooCommerce\Infrastructure;

/**
 * Provides the URL of this plugin.
 */
class Plugin_URL_Provider {

	/**
	 * Gets the URL of this plugin.
	 *
	 * @return string The plugin URL.
	 */
	public function get(): string {
		return \plugins_url( '', \WPSEO_WOO_PLUGIN_FILE );
	}
}
