<?php
/**
 * Zoom API Request Handle
 *
 * @package TutorPro\Addons
 * @subpackage Zoom\Interfaces
 * @author Themeum <support@themeum.com>
 * @link https://themeum.com
 * @since 2.0.0
 */

namespace Zoom\Interfaces;

use Tutor\Helpers\HttpHelper;
use TUTOR_ZOOM\Zoom;

class Request {

	/**
	 * API key
	 *
	 * @var string
	 */
	protected $apiKey;

	/**
	 * API secret
	 *
	 * @var string
	 */
	protected $apiSecret;

	/**
	 * API point
	 *
	 * @var string
	 */
	public $apiPoint = 'https://api.zoom.us/v2/';

	/**
	 * Access token transient key
	 *
	 * Store access token as transient data.
	 *
	 * Key will be appended by user id to make it unique
	 *
	 * @since 2.2.0
	 *
	 * @var string
	 */
	const ACCESS_TOKEN_KEY = 'tutor_zoom_access_token';

	/**
	 * Access token expire time in seconds
	 *
	 * @var int
	 *
	 * @since 2.2.0
	 */
	const TOKEN_EXP_TIME = 60 * 50; // 50min

	/**
	 * API request timeout in seconds
	 *
	 * @since 4.2.0
	 *
	 * @var int
	 */
	const REQUEST_TIMEOUT = 30;

	/**
	 * Request constructor.
	 *
	 * @since 4.2.0 Guzzle client removed.
	 *
	 * @param string $apiKey api key.
	 * @param string $apiSecret api secret.
	 */
	public function __construct( $apiKey, $apiSecret ) {
		$this->apiKey = $apiKey;

		$this->apiSecret = $apiSecret;
	}

	/**
	 * Headers
	 *
	 * JWT token replaced by server to server oauth
	 * access token
	 *
	 * @since 2.2.0
	 *
	 * @return array
	 */
	protected function headers(): array {

		$user_id = get_current_user_id();

		$access_token = $this->get_access_token( $user_id );

		return array(
			'Authorization' => 'Bearer ' . $access_token,
			'Content-Type'  => 'application/json',
			'Accept'        => 'application/json',
		);
	}


	/**
	 * Get Method.
	 *
	 * @since 4.2.0 Sends the request through HttpHelper instead of Guzzle.
	 *
	 * @param string $method api endpoint.
	 * @param array  $fields query string fields.
	 *
	 * @return array|mixed
	 */
	protected function get( $method, $fields = array() ) {
		$response = HttpHelper::get( $this->apiPoint . $method, urlencode_deep( $fields ), $this->headers(), $this->request_args() );

		return $this->prepare_result( $response );
	}

	/**
	 * Post
	 *
	 * @since 4.2.0 Sends the request through HttpHelper instead of Guzzle.
	 *
	 * @param string $method api endpoint.
	 * @param array  $fields form fields.
	 *
	 * @return array|mixed
	 */
	protected function post( $method, $fields ) {
		$response = HttpHelper::post( $this->apiPoint . $method, wp_json_encode( $fields ), $this->headers(), $this->request_args() );

		return $this->prepare_result( $response );
	}

	/**
	 * Patch
	 *
	 * @since 4.2.0 Sends the request through HttpHelper instead of Guzzle.
	 *
	 * @param string $method api endpoint.
	 * @param array  $fields form fields.
	 *
	 * @return array|mixed
	 */
	protected function patch( $method, $fields ) {
		$response = HttpHelper::patch( $this->apiPoint . $method, wp_json_encode( $fields ), $this->headers(), $this->request_args() );

		return $this->prepare_result( $response );
	}

	/**
	 * Put
	 *
	 * @since 4.2.0 Sends the request through HttpHelper instead of Guzzle.
	 *
	 * @param string $method api endpoint.
	 * @param array  $fields form fields.
	 *
	 * @return array|mixed
	 */
	protected function put( $method, $fields ) {
		$response = HttpHelper::put( $this->apiPoint . $method, wp_json_encode( $fields ), $this->headers(), $this->request_args() );

		return $this->prepare_result( $response );
	}

	/**
	 * Delete
	 *
	 * @since 4.2.0 Sends the request through HttpHelper instead of Guzzle.
	 *
	 * @param string $method variable name is method but it's taking api endpoint string.
	 * @param array  $fields form fields array.
	 *
	 * @return array|mixed
	 */
	protected function delete( $method, $fields = array() ) {
		$response = HttpHelper::delete( $this->apiPoint . $method, wp_json_encode( $fields ), $this->headers(), $this->request_args() );

		return $this->prepare_result( $response );
	}

	/**
	 * Extra wp_remote_request() arguments.
	 *
	 * @since 4.2.0
	 *
	 * @return array
	 */
	protected function request_args(): array {
		return array( 'timeout' => self::REQUEST_TIMEOUT );
	}

	/**
	 * Convert an HttpHelper response to the array the Zoom endpoints return.
	 *
	 * On success, returns the decoded JSON body with the HTTP status under `code`.
	 * On failure, returns an array with `code` and `message`, which is Zoom's
	 * error body for 4xx/5xx responses.
	 *
	 * @since 4.2.0
	 *
	 * @param HttpHelper $response HTTP response.
	 *
	 * @return array
	 */
	protected function prepare_result( HttpHelper $response ): array {
		if ( $response->has_error() ) {
			return array(
				'code'    => 0,
				'message' => $response->get_error_message(),
			);
		}

		$status = (int) $response->get_status_code();
		$result = $response->get_json( true );
		$result = is_array( $result ) ? $result : array();

		if ( $status >= 400 ) {
			$result['code'] = $result['code'] ?? $status;

			if ( empty( $result['message'] ) ) {
				/* translators: %d: HTTP status code */
				$result['message'] = sprintf( __( 'Zoom API request failed with HTTP status %d.', 'tutor-pro' ), $status );
			}

			return $result;
		}

		$result['code'] = $status;

		return $result;
	}

	/**
	 * Get user's access token
	 *
	 * It will first try to get existing token if token not exists then
	 * it will generate a new token
	 *
	 * @since 2.2.0
	 *
	 * @param integer $user_id user id.
	 *
	 * @return string
	 */
	protected function get_access_token( int $user_id ) {
		$access_token = get_transient( self::ACCESS_TOKEN_KEY . $user_id );

		// If access token not exists generate one.
		if ( false === $access_token ) {
			$generate_token = $this->generate_access_token();

			if ( is_object( $generate_token ) && property_exists( $generate_token, 'access_token' ) ) {
				$access_token = $generate_token->access_token;

				// Set token in transient data.
				set_transient( self::ACCESS_TOKEN_KEY . $user_id, $access_token, self::TOKEN_EXP_TIME );
			}
		}
		return $access_token;
	}

	/**
	 * Since Zoom JWT Authenticated has become deprecated(from Jun 2023)
	 *
	 * To authenticate API request this method added. It will create
	 * server to server Oauth access token.
	 *
	 * Access token is valid for 1 hour & there is no refresh token. Once
	 * token expire it need to generate again.
	 *
	 * @since 2.2.0
	 * @since 4.2.0 Sends the request through HttpHelper and fixes the Authorization and Content-Type headers.
	 *
	 * @return mixed object on success | false on failure
	 */
	private function generate_access_token() {
		$zoom_obj = new Zoom( false );

		$account_id = $zoom_obj->get_api( 'account_id' );

		$client_id     = $this->apiKey;
		$client_secret = $this->apiSecret;

		if ( ! $account_id || ! $client_id || ! $client_secret ) {
			return false;
		}

		$url = add_query_arg(
			array(
				'grant_type' => 'account_credentials',
				'account_id' => rawurlencode( $account_id ),
			),
			'https://zoom.us/oauth/token'
		);

		$response = HttpHelper::post(
			$url,
			array(),
			array(
				'Content-Type'  => 'application/x-www-form-urlencoded',
				'Authorization' => 'Basic ' . base64_encode( $client_id . ':' . $client_secret ), // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
			),
			array( 'timeout' => 60 )
		);

		if ( $response->has_error() ) {
			return false;
		}

		return $response->get_json();
	}
}
