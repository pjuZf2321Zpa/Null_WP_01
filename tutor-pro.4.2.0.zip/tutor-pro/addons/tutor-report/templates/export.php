<?php
/**
 * Export Template
 *
 * @package TutorPro\Report
 * @author Themeum <support@themeum.com>
 * @link https://themeum.com
 * @since 1.9.9
 */

defined( 'ABSPATH' ) || exit;

use TUTOR\Icon;
use Tutor\Components\Button;
use Tutor\Components\Constants\Size;
use Tutor\Components\Constants\Variant;
use Tutor\Components\SvgIcon;
use TUTOR_REPORT\Analytics;

$analytics = new Analytics( false );

/**
 * Check if there are any records in the database.
 */
$limit = 1;
$data  = $analytics->analytics_data( $limit );

$students  = $data['students'];
$earnings  = $data['earnings'];
$discounts = $data['discounts'];
$refunds   = $data['refunds'];

$disabled = ( empty( $students ) && empty( $earnings ) && empty( $discounts ) && empty( $refunds ) ) ? ' disabled' : '';

?>
<div class="tutor-surface-l1 tutor-mt-7 tutor-border tutor-rounded-2xl" x-data="tutorExportAnalytics">
	<div class="tutor-flex tutor-justify-between tutor-items-center tutor-sm-flex-column tutor-sm-items-start tutor-p-9 tutor-sm-p-6 tutor-gap-12 tutor-sm-gap-10">
		<div class="tutor-export-content-col">
			<h4 class="tutor-h4 tutor-font-medium tutor-export-title">
				<?php esc_html_e( 'Detailed Report of Your Sales & Students', 'tutor-pro' ); ?>
			</h4>
			<div class="tutor-p2 tutor-text-secondary tutor-mt-4">
				<?php esc_html_e( 'Export to keep a copy of your analytics data.', 'tutor-pro' ); ?>
			</div>

			<div class="tutor-mt-8 tutor-export-actions">
				<div class="tutor-export-row">
					<!-- Primary Action Button: Idle, Loading, or Success -->
					<div
						x-show="state !== 'failed'"
						x-transition:enter="tutor-fade-enter"
						x-transition:enter-start="tutor-fade-from"
						x-transition:enter-end="tutor-fade-to"
						x-transition:leave="tutor-fade-leave"
						x-transition:leave-start="tutor-fade-to"
						x-transition:leave-end="tutor-fade-from"
						class="tutor-export-btn-wrap"
					>
						<button
							type="button"
							class="tutor-btn tutor-btn-primary tutor-btn-sm tutor-export-btn"
							:class="{
								'is-loading': state === 'loading',
								'is-success': state === 'success'
							}"
							:style="{ '--export-progress': progressPercent }"
							<?php echo esc_attr( $disabled ); ?>
							:disabled="<?php echo ! empty( $disabled ) ? 'true' : "state === 'loading'"; ?>"
							@click="if (state === 'idle') startExport()"
						>
							<!-- Border Progress Ring (Active during loading) -->
							<svg
								x-show="state === 'loading'"
								x-cloak
								class="tutor-export-ring"
								aria-hidden="true"
							>
								<rect
									class="tutor-export-track"
									x="1.75"
									y="1.75"
									width="calc(100% - 3.5px)"
									height="calc(100% - 3.5px)"
									rx="4.25"
									ry="4.25"
									pathLength="100"
								/>
							</svg>

							<!-- State 1: Idle -->
							<span
								x-show="state === 'idle'"
								x-transition:enter="tutor-fade-enter"
								x-transition:enter-start="tutor-fade-from"
								x-transition:enter-end="tutor-fade-to"
								x-transition:leave="tutor-fade-leave"
								x-transition:leave-start="tutor-fade-to"
								x-transition:leave-end="tutor-fade-from"
								class="tutor-export-btn-label"
							>
								<?php
									SvgIcon::make()
										->name( Icon::DOWNLOAD_2 )
										->attr( 'class', 'tutor-mr-2' )
										->render();
								?>
								<span><?php esc_html_e( 'Download CSV', 'tutor-pro' ); ?></span>
							</span>

							<!-- State 2 & 3: Loading (Percentage) -->
							<span
								x-show="state === 'loading'"
								x-cloak
								x-transition:enter="tutor-fade-enter"
								x-transition:enter-start="tutor-fade-from"
								x-transition:enter-end="tutor-fade-to"
								x-transition:leave="tutor-fade-leave"
								x-transition:leave-start="tutor-fade-to"
								x-transition:leave-end="tutor-fade-from"
								class="tutor-export-btn-label"
								aria-live="polite"
							>
								<span x-text="`${progressPercent}%`"></span>
							</span>

							<!-- State 4: Success -->
							<span
								x-show="state === 'success'"
								x-cloak
								x-transition:enter="tutor-fade-enter"
								x-transition:enter-start="tutor-fade-from"
								x-transition:enter-end="tutor-fade-to"
								x-transition:leave="tutor-fade-leave"
								x-transition:leave-start="tutor-fade-to"
								x-transition:leave-end="tutor-fade-from"
								class="tutor-export-btn-label"
							>
								<?php
									SvgIcon::make()
										->name( Icon::LESSON_COMPLETED )
										->attr( 'class', 'tutor-mr-2' )
										->render();
								?>
								<span><?php esc_html_e( 'Download Successful', 'tutor-pro' ); ?></span>
							</span>
						</button>
					</div>

					<!-- State 5: Failed Group (Danger Button + Try Again Action) -->
					<div
						x-show="state === 'failed'"
						x-cloak
						x-transition:enter="tutor-fade-enter"
						x-transition:enter-start="tutor-fade-from"
						x-transition:enter-end="tutor-fade-to"
						x-transition:leave="tutor-fade-leave"
						x-transition:leave-start="tutor-fade-to"
						x-transition:leave-end="tutor-fade-from"
						class="tutor-export-failed"
					>
						<?php
						Button::make()
							->label( __( 'Failed', 'tutor-pro' ) )
							->icon( Icon::INFO_OCTAGON )
							->variant( Variant::DESTRUCTIVE_SOFT )
							->size( Size::SMALL )
							->disabled( true )
							->attr( 'class', 'tutor-export-btn-failed' )
							->render();

						Button::make()
							->label( __( 'Try Again', 'tutor-pro' ) )
							->variant( Variant::LINK )
							->size( Size::SMALL )
							->attr( 'class', 'tutor-export-btn-retry' )
							->attr( '@click', 'retryExport()' )
							->render();
						?>
					</div>
				</div>

				<!-- Expandable Section for Dynamic Info below the button -->
				<div
					class="tutor-export-info"
					:class="{ 'is-expanded': state === 'loading' || state === 'failed' }"
				>
					<div class="tutor-export-info-inner">
						<!-- Status Text (Loading state) -->
						<div
							x-show="state === 'loading'"
							x-cloak
							x-transition:enter="tutor-slide-enter"
							x-transition:enter-start="tutor-slide-from"
							x-transition:enter-end="tutor-slide-to"
							x-transition:leave="tutor-slide-leave"
							x-transition:leave-start="tutor-slide-to"
							x-transition:leave-end="tutor-slide-from"
							class="tutor-export-status tutor-mt-2"
							x-text="statusText"
							aria-live="polite"
						></div>

						<!-- Slow Export Notice -->
						<div
							x-show="state === 'loading' && showHelperNotice"
							x-cloak
							x-transition:enter="tutor-slide-enter"
							x-transition:enter-start="tutor-slide-from"
							x-transition:enter-end="tutor-slide-to"
							x-transition:leave="tutor-slide-leave"
							x-transition:leave-start="tutor-slide-to"
							x-transition:leave-end="tutor-slide-from"
							class="tutor-export-notice tutor-mt-3"
						>
							<span class="tutor-export-dot" aria-hidden="true"></span>
							<span class="tutor-export-notice-text">
								<?php esc_html_e( 'Hang tight, large exports take a moment and download automatically once complete.', 'tutor-pro' ); ?>
							</span>
						</div>

						<!-- Failed State Text -->
						<div
							x-show="state === 'failed'"
							x-cloak
							x-transition:enter="tutor-slide-enter"
							x-transition:enter-start="tutor-slide-from"
							x-transition:enter-end="tutor-slide-to"
							class="tutor-export-failed-text tutor-mt-3"
						>
							<?php esc_html_e( "We couldn't prepare your CSV. Your data hasn't been changed.", 'tutor-pro' ); ?>
						</div>
					</div>
				</div>
			</div>
		</div>

		<div class="tutor-surface-brand-tertiary tutor-rounded-lg">
			<?php tutor_utils()->render_themed_svg( 'images/illustrations/detailed-report.svg' ); ?>
		</div>
	</div>
</div>
