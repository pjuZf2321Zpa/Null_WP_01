(()=>{"use strict";var e={};// The module cache
var t={};// The require function
function r(i){// Check if module is in cache
var s=t[i];if(s!==undefined){return s.exports}// Create a new module (and put it into the cache)
var n=t[i]={exports:{}};// Execute the module function
e[i](n,n.exports,r);// Return the exports of the module
return n.exports}// webpack/runtime/rspack_version
(()=>{r.rv=()=>"1.6.5"})();// webpack/runtime/rspack_unique_id
(()=>{r.ruid="bundler=rspack@1.6.5"})();// UNUSED EXPORTS: default
;// CONCATENATED MODULE: ./node_modules/.pnpm/@swc+helpers@0.5.17/node_modules/@swc/helpers/esm/_async_to_generator.js
function i(e,t,r,i,s,n,o){try{var a=e[n](o);var l=a.value}catch(e){r(e);return}if(a.done)t(l);else Promise.resolve(l).then(i,s)}function s(e){return function(){var t=this,r=arguments;return new Promise(function(s,n){var o=e.apply(t,r);function a(e){i(o,s,n,a,l,"next",e)}function l(e){i(o,s,n,a,l,"throw",e)}a(undefined)})}};// CONCATENATED MODULE: external "wp.i18n"
const n=wp.i18n;// CONCATENATED MODULE: ../tutor/assets/core/ts/utils/security.ts
/**
 * Security utilities for escaping HTML and attributes
 *
 * @since 4.0.0
 *//**
 * Escape HTML and return safe HTML
 *
 * @param unsafeText - HTML string to escape
 * @returns Escaped HTML string
 *
 * @since 4.0.0
 */function o(e){var t=document.createElement("div");/**
   * When set an HTML string to an element's innerText
   * the browser automatically escapes any HTML tags and
   * treats the content as plain text.
   */t.innerText=e;var r=t.innerHTML;t.remove();return r}/**
 * Escape attribute value for safe usage in HTML attributes
 *
 * @param str - String to escape
 * @returns Escaped attribute string
 *
 * @since 4.0.0
 */function a(e){return e.replace(/&/g,"&amp;").replace(/"/g,"&quot;").replace(/'/g,"&#039;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}/**
 * Formula injection prevention prefixes (OWASP / CWE-1236)
 */var l=["=","+","-","@","	","\r"];/**
 * Sanitizes a single cell value for CSV export to prevent formula injection (OWASP / CWE-1236)
 * and properly escape commas, double quotes, and newlines.
 *
 * @param rawVal - The raw value to sanitize
 * @returns The sanitized cell string
 *
 * @since 4.2.0
 */function c(e){if(e===null||e===undefined){return""}var t=String(e);if(l.some(e=>t.startsWith(e))){t="'".concat(t)}if(t.includes(",")||t.includes('"')||t.includes("\n")||t.includes("\r")){return'"'.concat(t.replace(/"/g,'""'),'"')}return t};// CONCATENATED MODULE: ./addons/tutor-report/assets/src/js/export.ts
var h="analytics-data.zip";var u=3500;var p=1e3;var d=15e3;var m=350;var T=300;var v=180;var g=e=>new Promise(t=>window.setTimeout(t,e));var w={IDLE:"idle",LOADING:"loading",SUCCESS:"success",FAILED:"failed"};var f=[{type:"students",statusText:(0,n.__)("Collecting student data...","tutor-pro")},{type:"earnings",statusText:(0,n.__)("Collecting earnings data...","tutor-pro")},{type:"discounts",statusText:(0,n.__)("Collecting discounts data...","tutor-pro")},{type:"refunds",statusText:(0,n.__)("Collecting refunds data...","tutor-pro")}];var y=e=>{if(!Array.isArray(e)||e.length===0){return""}var t=Object.keys(e[0]);var r=t.map(c).join(",");var i=e.map(e=>t.map(t=>c(e[t])).join(","));return[r,...i].join("\n")};var x=()=>{var{query:e,endpoints:t}=window.TutorCore;var{wpPost:r}=window.TutorCore.api;var i=e.useMutation(e=>r(t.EXPORT_ANALYTICS,e));return{isOpen:false,state:w.IDLE,showHelperNotice:false,completedCount:0,progressPercent:0,statusText:"",errorMessage:"",dismissTimer:null,helperNoticeTimer:null,progressTickerTimer:null,clearTimer:null,exportStartTime:0,checkHelperNotice(){if(this.showHelperNotice||this.state!==w.LOADING){return}var e=Date.now()-this.exportStartTime;if(e>=d&&this.progressPercent<100){this.showHelperNotice=true}},stopProgressTicker(){if(this.progressTickerTimer!==null){window.clearInterval(this.progressTickerTimer);this.progressTickerTimer=null}},startProgressTicker(e){this.stopProgressTicker();var t=Math.max(e===0?4:0,Math.round(e/f.length*100));var r=Math.round((e+.85)/f.length*100);var i=Math.round((e+.95)/f.length*100);if(this.progressPercent<t){this.progressPercent=t}var s=0;this.progressTickerTimer=window.setInterval(()=>{if(this.state!==w.LOADING){this.stopProgressTicker();return}s++;var e=r-this.progressPercent;if(e>0){var t=Math.max(1,Math.round(e*.12));this.progressPercent=Math.min(r,this.progressPercent+t)}else if(s%5===0&&this.progressPercent<i){// Continuous micro-creep if the network request takes longer, keeping the UI alive
this.progressPercent+=1}this.checkHelperNotice()},v)},resetState(){this.stopProgressTicker();this.state=w.IDLE;this.showHelperNotice=false;this.exportStartTime=0;this.completedCount=0;this.progressPercent=0;this.statusText="";this.errorMessage=""},clear(){this.stopProgressTicker();if(this.dismissTimer!==null){window.clearTimeout(this.dismissTimer);this.dismissTimer=null}if(this.helperNoticeTimer!==null){window.clearTimeout(this.helperNoticeTimer);this.helperNoticeTimer=null}if(this.clearTimer!==null){window.clearTimeout(this.clearTimer);this.clearTimer=null}this.isOpen=false;// Defer resetting state to idle until after the exit animation completes (180ms transition).
// Keeping the view mounted and in-flow prevents height collapse and visual stutter on dismiss.
this.clearTimer=window.setTimeout(()=>{if(!this.isOpen){this.resetState()}this.clearTimer=null},250)},startExport(){return s(function*(){if(this.state===w.LOADING){return}if(this.dismissTimer!==null){window.clearTimeout(this.dismissTimer);this.dismissTimer=null}if(this.helperNoticeTimer!==null){window.clearTimeout(this.helperNoticeTimer);this.helperNoticeTimer=null}if(this.clearTimer!==null){window.clearTimeout(this.clearTimer);this.clearTimer=null}this.resetState();this.isOpen=true;this.state=w.LOADING;this.exportStartTime=Date.now();this.helperNoticeTimer=window.setTimeout(()=>{this.checkHelperNotice()},d);var e=new JSZip;try{for(var t=0;t<f.length;t++){var r;var s=f[t];this.statusText=s.statusText;this.startProgressTicker(t);var o=yield i.mutateAsync({type:s.type});var a;var l=(a=o===null||o===void 0?void 0:(r=o.data)===null||r===void 0?void 0:r[s.type])!==null&&a!==void 0?a:[];var c=y(l);if(c){e.file("".concat(s.type,".csv"),new Blob([c],{type:"text/csv;charset=utf-8;"}))}this.stopProgressTicker();this.completedCount=t+1;this.progressPercent=Math.round(this.completedCount/f.length*100);this.checkHelperNotice()}this.statusText=(0,n.__)("Finalizing export...","tutor-pro");var v=yield e.generateAsync({type:"blob"});var x=new Blob([v],{type:"application/zip"});var N=URL.createObjectURL(x);var P=document.createElement("a");P.href=N;P.download=h;document.body.appendChild(P);P.click();document.body.removeChild(P);window.setTimeout(()=>{URL.revokeObjectURL(N)},p);// Allow 100% progress animation (250ms) to settle and register before state change
yield g(m);this.state=w.SUCCESS;this.dismissTimer=window.setTimeout(()=>{if(this.state===w.SUCCESS){this.clear()}},u)}catch(e){this.stopProgressTicker();this.errorMessage=e instanceof Error?e.message:"";// Brief settle delay before showing failure state to avoid jarring snap
yield g(T);this.state=w.FAILED}finally{this.stopProgressTicker();if(this.helperNoticeTimer!==null){window.clearTimeout(this.helperNoticeTimer);this.helperNoticeTimer=null}}}).call(this)},retryExport(){void this.startExport()}}};var N=()=>{window.TutorComponentRegistry.register({type:"component",meta:{name:"exportAnalytics",component:x}});window.TutorComponentRegistry.initWithAlpine(window.Alpine)};document.addEventListener("alpine:init",N);/* export default */const P=/* unused pure expression or super */null&&x})();