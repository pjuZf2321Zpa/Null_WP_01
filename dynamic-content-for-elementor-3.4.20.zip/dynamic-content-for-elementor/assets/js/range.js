"use strict";

function initializeRangeField(wrapper, widget) {
	let range = wrapper.getElementsByTagName("input")[0];
	let showValue = range.dataset.showValue;

	if (showValue) {
		let rangeValue = wrapper.getElementsByClassName("range-value")[0];
		if (!rangeValue) {
			return;
		}
		let textBefore = dceSanitizeHtml(range.dataset.textBefore || "");
		let textAfter = dceSanitizeHtml(range.dataset.textAfter || "");
		let toFragment = function (html) {
			let template = document.createElement("template");
			template.innerHTML = html;
			return template.content;
		};
		let before = toFragment(textBefore);
		let after = toFragment(textAfter);
		let render = function (value) {
			let valueSpan = document.createElement("span");
			valueSpan.textContent = value;
			rangeValue.textContent = "";
			rangeValue.appendChild(before.cloneNode(true));
			rangeValue.appendChild(document.createTextNode(" "));
			rangeValue.appendChild(valueSpan);
			rangeValue.appendChild(document.createTextNode(" "));
			rangeValue.appendChild(after.cloneNode(true));
		};
		render(range.value);

		range.oninput = function () {
			render(this.value);
		};
	}
}

function initializeAllRangeFields($scope) {
	$scope
		.find(".elementor-field-type-dce_range")
		.each((_, w) => initializeRangeField(w, $scope[0]));
}

jQuery(window).on("elementor/frontend/init", function () {
	elementorFrontend.hooks.addAction(
		"frontend/element_ready/form.default",
		initializeAllRangeFields,
	);
});
