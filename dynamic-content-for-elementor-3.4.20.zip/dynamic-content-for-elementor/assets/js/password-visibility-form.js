jQuery(window).on('elementor/frontend/init', function() {
    function escapeSelector(value) {
        value = String(value);
        if (window.CSS && typeof window.CSS.escape === 'function') {
            return window.CSS.escape(value);
        }
        return jQuery.escapeSelector ? jQuery.escapeSelector(value) : value.replace(/[^a-zA-Z0-9_-]/g, '\\$&');
    }

    elementorFrontend.hooks.addAction('frontend/element_ready/form.default', function($scope) {
        var configStr = $scope.attr('data-dce-password-visibility');
        if (!configStr) {
            return;
        }

        var config = JSON.parse(configStr);
        if (!config.fields || config.fields.length === 0) {
            return;
        }

        // Prevent multiple initializations
        if ($scope.data('dce-psw-set') === 'yes') {
            return;
        }
        $scope.data('dce-psw-set', 'yes');

        var widgetId = $scope.data('id');

        config.fields.forEach(function(customId) {
            customId = String(customId);
            var $field = jQuery('.elementor-element-' + escapeSelector(widgetId) + ' #' + escapeSelector('form-field-' + customId));
            if ($field.length === 0) {
                return;
            }

            $field.addClass('dce-form-password-toggle');
            $field.wrap(jQuery('<div></div>').addClass('dce-field-input-wrapper').addClass('dce-field-input-wrapper-' + customId));
            $field.parent().append(jQuery('<span></span>').addClass('fa far fa-eye-slash field-icon dce-toggle-password'));
            
            $field.next('.dce-toggle-password').on('click', function() {
                var $inputPsw = jQuery(this).prev();
                if ($inputPsw.attr('type') === 'password') {
                    $inputPsw.attr('type', 'text');
                } else {
                    $inputPsw.attr('type', 'password');
                }
                jQuery(this).toggleClass('fa-eye').toggleClass('fa-eye-slash');
            });
        });
    });
});
