"use strict";

jQuery(function () {
	jQuery(".js-dce-select").select2();
});
