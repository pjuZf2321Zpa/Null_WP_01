jQuery(window).on('elementor/frontend/init', function() {
    var tooltipPositions = ['top', 'left', 'bottom', 'right'];

    function escapeSelector(value) {
        value = String(value);
        if (window.CSS && typeof window.CSS.escape === 'function') {
            return window.CSS.escape(value);
        }
        return jQuery.escapeSelector ? jQuery.escapeSelector(value) : value.replace(/[^a-zA-Z0-9_-]/g, '\\$&');
    }

    elementorFrontend.hooks.addAction('frontend/element_ready/form.default', function($scope) {
        var widgetId = $scope.data('id');
        var config = (window.dceFieldDescriptions || {})[widgetId];
        if (!config || !config.fields || !config.fields.length) {
            return;
        }

        config.fields.forEach(function(field) {
            var customId = String(field.custom_id);
            var groupSelector = '.elementor-field-group-' + escapeSelector(customId);
            if (field.position === 'elementor-field-label') {
                var $label = $scope.find(groupSelector + ' .elementor-field-label');
                if (field.tooltip) {
                    $label.addClass('dce-tooltip').addClass('elementor-field-label-description');
                    var tooltipPos = tooltipPositions.indexOf(field.tooltip_position) !== -1 ? field.tooltip_position : 'top';
                    var $tooltip = jQuery('<span></span>').addClass('dce-tooltiptext dce-tooltip-' + tooltipPos);
                    $tooltip.html(field.description);
                    $label.append($tooltip);
                } else {
                    var $abbr = jQuery('<abbr></abbr>').addClass('elementor-field-label-description').addClass('elementor-field-label-description-' + customId);
                    $abbr.attr('title', field.description_text);
                    $label.wrap($abbr);
                }
            } else if (field.position === 'elementor-field') {
                var $fieldGroup = $scope.find(groupSelector);
                var $desc = jQuery('<div></div>').addClass('elementor-field-input-description').addClass('elementor-field-input-description-' + customId);
                $desc.html(field.description);
                $fieldGroup.append($desc);
            }
        });
    });
});
