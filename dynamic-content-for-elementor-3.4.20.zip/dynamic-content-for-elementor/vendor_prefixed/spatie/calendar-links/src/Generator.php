<?php

namespace DynamicContentForElementorVendor\Spatie\CalendarLinks;

interface Generator
{
    /**
     * Generate an URL to add event to calendar.
     * @param \DynamicContentForElementorVendor\Spatie\CalendarLinks\Link $link
     * @return string
     */
    public function generate(Link $link) : string;
}
