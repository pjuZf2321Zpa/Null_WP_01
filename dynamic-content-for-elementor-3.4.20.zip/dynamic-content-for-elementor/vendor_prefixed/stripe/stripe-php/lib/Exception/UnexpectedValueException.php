<?php

namespace DynamicContentForElementorVendor\Stripe\Exception;

class UnexpectedValueException extends \UnexpectedValueException implements ExceptionInterface
{
}
