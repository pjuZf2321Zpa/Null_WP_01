<?php

namespace DynamicContentForElementorVendor\Stripe\Exception;

class BadMethodCallException extends \BadMethodCallException implements ExceptionInterface
{
}
