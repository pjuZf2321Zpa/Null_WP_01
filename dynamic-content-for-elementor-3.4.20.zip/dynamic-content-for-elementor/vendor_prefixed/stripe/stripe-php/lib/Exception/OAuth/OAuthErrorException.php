<?php

namespace DynamicContentForElementorVendor\Stripe\Exception\OAuth;

/**
 * Implements properties and methods common to all (non-SPL) Stripe OAuth
 * exceptions.
 */
abstract class OAuthErrorException extends \DynamicContentForElementorVendor\Stripe\Exception\ApiErrorException
{
    protected function constructErrorObject()
    {
        if (null === $this->jsonBody) {
            return null;
        }
        return \DynamicContentForElementorVendor\Stripe\OAuthErrorObject::constructFrom($this->jsonBody);
    }
}
