<?php

namespace DynamicContentForElementorVendor\Stripe\Exception\OAuth;

/**
 * The base interface for all Stripe OAuth exceptions.
 */
interface ExceptionInterface extends \DynamicContentForElementorVendor\Stripe\Exception\ExceptionInterface
{
}
