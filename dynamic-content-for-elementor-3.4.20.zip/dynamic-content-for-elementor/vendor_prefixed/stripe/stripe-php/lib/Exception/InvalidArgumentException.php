<?php

namespace DynamicContentForElementorVendor\Stripe\Exception;

class InvalidArgumentException extends \InvalidArgumentException implements ExceptionInterface
{
}
