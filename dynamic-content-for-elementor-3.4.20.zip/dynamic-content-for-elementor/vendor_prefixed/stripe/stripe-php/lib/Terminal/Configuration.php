<?php

// File generated from our OpenAPI spec
namespace DynamicContentForElementorVendor\Stripe\Terminal;

/**
 * A Configurations object represents how features should be configured for terminal readers.
 *
 * @property string $id Unique identifier for the object.
 * @property string $object String representing the object's type. Objects of the same type share the same value.
 * @property null|\DynamicContentForElementorVendor\Stripe\StripeObject $bbpos_wisepos_e
 * @property null|bool $is_account_default Whether this Configuration is the default for your account
 * @property bool $livemode Has the value <code>true</code> if the object exists in live mode or the value <code>false</code> if the object exists in test mode.
 * @property null|\DynamicContentForElementorVendor\Stripe\StripeObject $tipping
 * @property null|\DynamicContentForElementorVendor\Stripe\StripeObject $verifone_p400
 */
class Configuration extends \DynamicContentForElementorVendor\Stripe\ApiResource
{
    const OBJECT_NAME = 'terminal.configuration';
    use \DynamicContentForElementorVendor\Stripe\ApiOperations\All;
    use \DynamicContentForElementorVendor\Stripe\ApiOperations\Create;
    use \DynamicContentForElementorVendor\Stripe\ApiOperations\Delete;
    use \DynamicContentForElementorVendor\Stripe\ApiOperations\Retrieve;
    use \DynamicContentForElementorVendor\Stripe\ApiOperations\Update;
}
