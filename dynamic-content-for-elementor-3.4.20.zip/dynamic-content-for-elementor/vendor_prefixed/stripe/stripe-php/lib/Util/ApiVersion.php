<?php

// File generated from our OpenAPI spec
namespace DynamicContentForElementorVendor\Stripe\Util;

class ApiVersion
{
    const CURRENT = '2023-08-16';
}
