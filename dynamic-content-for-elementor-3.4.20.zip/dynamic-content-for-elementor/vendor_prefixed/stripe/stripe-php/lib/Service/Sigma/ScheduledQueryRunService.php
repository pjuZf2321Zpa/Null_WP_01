<?php

// File generated from our OpenAPI spec
namespace DynamicContentForElementorVendor\Stripe\Service\Sigma;

class ScheduledQueryRunService extends \DynamicContentForElementorVendor\Stripe\Service\AbstractService
{
    /**
     * Returns a list of scheduled query runs.
     *
     * @param null|array $params
     * @param null|array|\DynamicContentForElementorVendor\Stripe\Util\RequestOptions $opts
     *
     * @throws \DynamicContentForElementorVendor\Stripe\Exception\ApiErrorException if the request fails
     *
     * @return \DynamicContentForElementorVendor\Stripe\Collection<\DynamicContentForElementorVendor\Stripe\Sigma\ScheduledQueryRun>
     */
    public function all($params = null, $opts = null)
    {
        return $this->requestCollection('get', '/v1/sigma/scheduled_query_runs', $params, $opts);
    }
    /**
     * Retrieves the details of an scheduled query run.
     *
     * @param string $id
     * @param null|array $params
     * @param null|array|\DynamicContentForElementorVendor\Stripe\Util\RequestOptions $opts
     *
     * @throws \DynamicContentForElementorVendor\Stripe\Exception\ApiErrorException if the request fails
     *
     * @return \DynamicContentForElementorVendor\Stripe\Sigma\ScheduledQueryRun
     */
    public function retrieve($id, $params = null, $opts = null)
    {
        return $this->request('get', $this->buildPath('/v1/sigma/scheduled_query_runs/%s', $id), $params, $opts);
    }
}
