<?php

// File generated from our OpenAPI spec
namespace DynamicContentForElementorVendor\Stripe\Service;

class MandateService extends \DynamicContentForElementorVendor\Stripe\Service\AbstractService
{
    /**
     * Retrieves a Mandate object.
     *
     * @param string $id
     * @param null|array $params
     * @param null|array|\DynamicContentForElementorVendor\Stripe\Util\RequestOptions $opts
     *
     * @throws \DynamicContentForElementorVendor\Stripe\Exception\ApiErrorException if the request fails
     *
     * @return \DynamicContentForElementorVendor\Stripe\Mandate
     */
    public function retrieve($id, $params = null, $opts = null)
    {
        return $this->request('get', $this->buildPath('/v1/mandates/%s', $id), $params, $opts);
    }
}
