<?php

// File generated from our OpenAPI spec
namespace DynamicContentForElementorVendor\Stripe\Service\Treasury;

class ReceivedCreditService extends \DynamicContentForElementorVendor\Stripe\Service\AbstractService
{
    /**
     * Returns a list of ReceivedCredits.
     *
     * @param null|array $params
     * @param null|array|\DynamicContentForElementorVendor\Stripe\Util\RequestOptions $opts
     *
     * @throws \DynamicContentForElementorVendor\Stripe\Exception\ApiErrorException if the request fails
     *
     * @return \DynamicContentForElementorVendor\Stripe\Collection<\DynamicContentForElementorVendor\Stripe\Treasury\ReceivedCredit>
     */
    public function all($params = null, $opts = null)
    {
        return $this->requestCollection('get', '/v1/treasury/received_credits', $params, $opts);
    }
    /**
     * Retrieves the details of an existing ReceivedCredit by passing the unique
     * ReceivedCredit ID from the ReceivedCredit list.
     *
     * @param string $id
     * @param null|array $params
     * @param null|array|\DynamicContentForElementorVendor\Stripe\Util\RequestOptions $opts
     *
     * @throws \DynamicContentForElementorVendor\Stripe\Exception\ApiErrorException if the request fails
     *
     * @return \DynamicContentForElementorVendor\Stripe\Treasury\ReceivedCredit
     */
    public function retrieve($id, $params = null, $opts = null)
    {
        return $this->request('get', $this->buildPath('/v1/treasury/received_credits/%s', $id), $params, $opts);
    }
}
