<?php

namespace DynamicContentForElementorVendor\Stripe;

/**
 * Client used to send requests to Stripe's API.
 *
 * @property \DynamicContentForElementorVendor\Stripe\Service\OAuthService $oauth
 * // The beginning of the section generated from our OpenAPI spec
 * @property \DynamicContentForElementorVendor\Stripe\Service\AccountLinkService $accountLinks
 * @property \DynamicContentForElementorVendor\Stripe\Service\AccountService $accounts
 * @property \DynamicContentForElementorVendor\Stripe\Service\AccountSessionService $accountSessions
 * @property \DynamicContentForElementorVendor\Stripe\Service\ApplePayDomainService $applePayDomains
 * @property \DynamicContentForElementorVendor\Stripe\Service\ApplicationFeeService $applicationFees
 * @property \DynamicContentForElementorVendor\Stripe\Service\Apps\AppsServiceFactory $apps
 * @property \DynamicContentForElementorVendor\Stripe\Service\BalanceService $balance
 * @property \DynamicContentForElementorVendor\Stripe\Service\BalanceTransactionService $balanceTransactions
 * @property \DynamicContentForElementorVendor\Stripe\Service\BillingPortal\BillingPortalServiceFactory $billingPortal
 * @property \DynamicContentForElementorVendor\Stripe\Service\ChargeService $charges
 * @property \DynamicContentForElementorVendor\Stripe\Service\Checkout\CheckoutServiceFactory $checkout
 * @property \DynamicContentForElementorVendor\Stripe\Service\CountrySpecService $countrySpecs
 * @property \DynamicContentForElementorVendor\Stripe\Service\CouponService $coupons
 * @property \DynamicContentForElementorVendor\Stripe\Service\CreditNoteService $creditNotes
 * @property \DynamicContentForElementorVendor\Stripe\Service\CustomerService $customers
 * @property \DynamicContentForElementorVendor\Stripe\Service\DisputeService $disputes
 * @property \DynamicContentForElementorVendor\Stripe\Service\EphemeralKeyService $ephemeralKeys
 * @property \DynamicContentForElementorVendor\Stripe\Service\EventService $events
 * @property \DynamicContentForElementorVendor\Stripe\Service\ExchangeRateService $exchangeRates
 * @property \DynamicContentForElementorVendor\Stripe\Service\FileLinkService $fileLinks
 * @property \DynamicContentForElementorVendor\Stripe\Service\FileService $files
 * @property \DynamicContentForElementorVendor\Stripe\Service\FinancialConnections\FinancialConnectionsServiceFactory $financialConnections
 * @property \DynamicContentForElementorVendor\Stripe\Service\Identity\IdentityServiceFactory $identity
 * @property \DynamicContentForElementorVendor\Stripe\Service\InvoiceItemService $invoiceItems
 * @property \DynamicContentForElementorVendor\Stripe\Service\InvoiceService $invoices
 * @property \DynamicContentForElementorVendor\Stripe\Service\Issuing\IssuingServiceFactory $issuing
 * @property \DynamicContentForElementorVendor\Stripe\Service\MandateService $mandates
 * @property \DynamicContentForElementorVendor\Stripe\Service\PaymentIntentService $paymentIntents
 * @property \DynamicContentForElementorVendor\Stripe\Service\PaymentLinkService $paymentLinks
 * @property \DynamicContentForElementorVendor\Stripe\Service\PaymentMethodConfigurationService $paymentMethodConfigurations
 * @property \DynamicContentForElementorVendor\Stripe\Service\PaymentMethodDomainService $paymentMethodDomains
 * @property \DynamicContentForElementorVendor\Stripe\Service\PaymentMethodService $paymentMethods
 * @property \DynamicContentForElementorVendor\Stripe\Service\PayoutService $payouts
 * @property \DynamicContentForElementorVendor\Stripe\Service\PlanService $plans
 * @property \DynamicContentForElementorVendor\Stripe\Service\PriceService $prices
 * @property \DynamicContentForElementorVendor\Stripe\Service\ProductService $products
 * @property \DynamicContentForElementorVendor\Stripe\Service\PromotionCodeService $promotionCodes
 * @property \DynamicContentForElementorVendor\Stripe\Service\QuoteService $quotes
 * @property \DynamicContentForElementorVendor\Stripe\Service\Radar\RadarServiceFactory $radar
 * @property \DynamicContentForElementorVendor\Stripe\Service\RefundService $refunds
 * @property \DynamicContentForElementorVendor\Stripe\Service\Reporting\ReportingServiceFactory $reporting
 * @property \DynamicContentForElementorVendor\Stripe\Service\ReviewService $reviews
 * @property \DynamicContentForElementorVendor\Stripe\Service\SetupAttemptService $setupAttempts
 * @property \DynamicContentForElementorVendor\Stripe\Service\SetupIntentService $setupIntents
 * @property \DynamicContentForElementorVendor\Stripe\Service\ShippingRateService $shippingRates
 * @property \DynamicContentForElementorVendor\Stripe\Service\Sigma\SigmaServiceFactory $sigma
 * @property \DynamicContentForElementorVendor\Stripe\Service\SourceService $sources
 * @property \DynamicContentForElementorVendor\Stripe\Service\SubscriptionItemService $subscriptionItems
 * @property \DynamicContentForElementorVendor\Stripe\Service\SubscriptionService $subscriptions
 * @property \DynamicContentForElementorVendor\Stripe\Service\SubscriptionScheduleService $subscriptionSchedules
 * @property \DynamicContentForElementorVendor\Stripe\Service\Tax\TaxServiceFactory $tax
 * @property \DynamicContentForElementorVendor\Stripe\Service\TaxCodeService $taxCodes
 * @property \DynamicContentForElementorVendor\Stripe\Service\TaxRateService $taxRates
 * @property \DynamicContentForElementorVendor\Stripe\Service\Terminal\TerminalServiceFactory $terminal
 * @property \DynamicContentForElementorVendor\Stripe\Service\TestHelpers\TestHelpersServiceFactory $testHelpers
 * @property \DynamicContentForElementorVendor\Stripe\Service\TokenService $tokens
 * @property \DynamicContentForElementorVendor\Stripe\Service\TopupService $topups
 * @property \DynamicContentForElementorVendor\Stripe\Service\TransferService $transfers
 * @property \DynamicContentForElementorVendor\Stripe\Service\Treasury\TreasuryServiceFactory $treasury
 * @property \DynamicContentForElementorVendor\Stripe\Service\WebhookEndpointService $webhookEndpoints
 * // The end of the section generated from our OpenAPI spec
 */
class StripeClient extends BaseStripeClient
{
    /**
     * @var \DynamicContentForElementorVendor\Stripe\Service\CoreServiceFactory
     */
    private $coreServiceFactory;
    public function __get($name)
    {
        return $this->getService($name);
    }
    public function getService($name)
    {
        if (null === $this->coreServiceFactory) {
            $this->coreServiceFactory = new \DynamicContentForElementorVendor\Stripe\Service\CoreServiceFactory($this);
        }
        return $this->coreServiceFactory->getService($name);
    }
}
