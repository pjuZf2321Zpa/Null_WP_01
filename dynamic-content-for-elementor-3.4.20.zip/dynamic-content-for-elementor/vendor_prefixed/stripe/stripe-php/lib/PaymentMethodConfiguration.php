<?php

// File generated from our OpenAPI spec
namespace DynamicContentForElementorVendor\Stripe;

/**
 * An object detailing payment method configurations.
 *
 * @property string $id Unique identifier for the object.
 * @property string $object String representing the object's type. Objects of the same type share the same value.
 * @property null|\DynamicContentForElementorVendor\Stripe\StripeObject $acss_debit
 * @property bool $active Whether the configuration can be used for new payments.
 * @property null|\DynamicContentForElementorVendor\Stripe\StripeObject $affirm
 * @property null|\DynamicContentForElementorVendor\Stripe\StripeObject $afterpay_clearpay
 * @property null|\DynamicContentForElementorVendor\Stripe\StripeObject $alipay
 * @property null|\DynamicContentForElementorVendor\Stripe\StripeObject $apple_pay
 * @property null|string $application The Connect application associated with this configuration.
 * @property null|\DynamicContentForElementorVendor\Stripe\StripeObject $au_becs_debit
 * @property null|\DynamicContentForElementorVendor\Stripe\StripeObject $bacs_debit
 * @property null|\DynamicContentForElementorVendor\Stripe\StripeObject $bancontact
 * @property null|\DynamicContentForElementorVendor\Stripe\StripeObject $blik
 * @property null|\DynamicContentForElementorVendor\Stripe\StripeObject $boleto
 * @property null|\DynamicContentForElementorVendor\Stripe\StripeObject $card
 * @property null|\DynamicContentForElementorVendor\Stripe\StripeObject $cartes_bancaires
 * @property null|\DynamicContentForElementorVendor\Stripe\StripeObject $cashapp
 * @property null|\DynamicContentForElementorVendor\Stripe\StripeObject $eps
 * @property null|\DynamicContentForElementorVendor\Stripe\StripeObject $fpx
 * @property null|\DynamicContentForElementorVendor\Stripe\StripeObject $giropay
 * @property null|\DynamicContentForElementorVendor\Stripe\StripeObject $google_pay
 * @property null|\DynamicContentForElementorVendor\Stripe\StripeObject $grabpay
 * @property null|\DynamicContentForElementorVendor\Stripe\StripeObject $id_bank_transfer
 * @property null|\DynamicContentForElementorVendor\Stripe\StripeObject $ideal
 * @property bool $is_default The default configuration is used whenever no payment method configuration is specified.
 * @property null|\DynamicContentForElementorVendor\Stripe\StripeObject $jcb
 * @property null|\DynamicContentForElementorVendor\Stripe\StripeObject $klarna
 * @property null|\DynamicContentForElementorVendor\Stripe\StripeObject $konbini
 * @property null|\DynamicContentForElementorVendor\Stripe\StripeObject $link
 * @property bool $livemode Has the value <code>true</code> if the object exists in live mode or the value <code>false</code> if the object exists in test mode.
 * @property null|\DynamicContentForElementorVendor\Stripe\StripeObject $multibanco
 * @property string $name Configuration name.
 * @property null|\DynamicContentForElementorVendor\Stripe\StripeObject $netbanking
 * @property null|\DynamicContentForElementorVendor\Stripe\StripeObject $oxxo
 * @property null|\DynamicContentForElementorVendor\Stripe\StripeObject $p24
 * @property null|string $parent The configuration's parent configuration.
 * @property null|\DynamicContentForElementorVendor\Stripe\StripeObject $pay_by_bank
 * @property null|\DynamicContentForElementorVendor\Stripe\StripeObject $paynow
 * @property null|\DynamicContentForElementorVendor\Stripe\StripeObject $paypal
 * @property null|\DynamicContentForElementorVendor\Stripe\StripeObject $promptpay
 * @property null|\DynamicContentForElementorVendor\Stripe\StripeObject $sepa_debit
 * @property null|\DynamicContentForElementorVendor\Stripe\StripeObject $sofort
 * @property null|\DynamicContentForElementorVendor\Stripe\StripeObject $upi
 * @property null|\DynamicContentForElementorVendor\Stripe\StripeObject $us_bank_account
 * @property null|\DynamicContentForElementorVendor\Stripe\StripeObject $wechat_pay
 */
class PaymentMethodConfiguration extends ApiResource
{
    const OBJECT_NAME = 'payment_method_configuration';
    use ApiOperations\All;
    use ApiOperations\Create;
    use ApiOperations\Retrieve;
    use ApiOperations\Update;
}
