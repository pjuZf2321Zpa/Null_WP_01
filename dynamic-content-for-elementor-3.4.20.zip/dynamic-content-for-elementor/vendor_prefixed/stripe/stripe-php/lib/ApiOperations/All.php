<?php

namespace DynamicContentForElementorVendor\Stripe\ApiOperations;

/**
 * Trait for listable resources. Adds a `all()` static method to the class.
 *
 * This trait should only be applied to classes that derive from StripeObject.
 */
trait All
{
    /**
     * @param null|array $params
     * @param null|array|string $opts
     *
     * @throws \DynamicContentForElementorVendor\Stripe\Exception\ApiErrorException if the request fails
     *
     * @return \DynamicContentForElementorVendor\Stripe\Collection of ApiResources
     */
    public static function all($params = null, $opts = null)
    {
        self::_validateParams($params);
        $url = static::classUrl();
        list($response, $opts) = static::_staticRequest('get', $url, $params, $opts);
        $obj = \DynamicContentForElementorVendor\Stripe\Util\Util::convertToStripeObject($response->json, $opts);
        if (!$obj instanceof \DynamicContentForElementorVendor\Stripe\Collection) {
            throw new \DynamicContentForElementorVendor\Stripe\Exception\UnexpectedValueException('Expected type ' . \DynamicContentForElementorVendor\Stripe\Collection::class . ', got "' . \get_class($obj) . '" instead.');
        }
        $obj->setLastResponse($response);
        $obj->setFilters($params);
        return $obj;
    }
}
