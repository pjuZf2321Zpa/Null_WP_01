<?php

declare (strict_types=1);
namespace PYS_PRO_GLOBAL\WP\McpSchema\Common\Tasks\DTO;

use PYS_PRO_GLOBAL\WP\McpSchema\Common\AbstractDataTransferObject;
use PYS_PRO_GLOBAL\WP\McpSchema\Common\Traits\ValidatesRequiredFields;
/**
 * @mcp-domain Common
 * @mcp-subdomain Tasks
 * @mcp-version 2025-11-25
 */
class GetTaskRequestParams extends AbstractDataTransferObject
{
    use ValidatesRequiredFields;
    /**
     * The task identifier to query.
     *
     * @var string
     */
    protected string $taskId;
    /**
     * @param string $taskId
     */
    public function __construct(string $taskId)
    {
        $this->taskId = $taskId;
    }
    /**
     * Creates an instance from an array.
     *
     * @param array{
     *     taskId: string
     * } $data
     * @phpstan-param array<string, mixed> $data
     * @return self
     */
    public static function fromArray(array $data): self
    {
        self::assertRequired($data, ['taskId']);
        return new self(self::asString($data['taskId']));
    }
    /**
     * Converts the instance to an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(): array
    {
        $result = [];
        $result['taskId'] = $this->taskId;
        return $result;
    }
    /**
     * @return string
     */
    public function getTaskId(): string
    {
        return $this->taskId;
    }
}
