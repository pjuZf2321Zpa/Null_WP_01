<?php

declare (strict_types=1);
namespace PYS_PRO_GLOBAL\WP\McpSchema\Common\Protocol\DTO;

use PYS_PRO_GLOBAL\WP\McpSchema\Common\JsonRpc\DTO\JSONRPCRequest;
use PYS_PRO_GLOBAL\WP\McpSchema\Common\Protocol\Union\ClientRequestInterface;
use PYS_PRO_GLOBAL\WP\McpSchema\Common\Protocol\Union\ServerRequestInterface;
use PYS_PRO_GLOBAL\WP\McpSchema\Common\Traits\ValidatesRequiredFields;
/**
 * A request to retrieve the result of a completed task.
 *
 * @since 2025-11-25
 *
 * @mcp-domain Common
 * @mcp-subdomain Protocol
 * @mcp-version 2025-11-25
 */
class GetTaskPayloadRequest extends JSONRPCRequest implements ClientRequestInterface, ServerRequestInterface
{
    use ValidatesRequiredFields;
    public const METHOD = 'tasks/result';
    public const DISCRIMINATOR_FIELD = 'method';
    public const DISCRIMINATOR_VALUE = 'tasks/result';
    /**
     * @var \WP\McpSchema\Common\Protocol\DTO\GetTaskPayloadRequestParams
     */
    protected GetTaskPayloadRequestParams $typedParams;
    /**
     * @param '2.0' $jsonrpc @since 2025-11-25
     * @param string|number $id @since 2025-11-25
     * @param \WP\McpSchema\Common\Protocol\DTO\GetTaskPayloadRequestParams $params @since 2025-11-25
     */
    public function __construct(string $jsonrpc, $id, GetTaskPayloadRequestParams $params)
    {
        parent::__construct(self::METHOD, $jsonrpc, $id, null);
        $this->typedParams = $params;
    }
    /**
     * Creates an instance from an array.
     *
     * @param array{
     *     jsonrpc: '2.0',
     *     id: string|number,
     *     method: 'tasks/result',
     *     params: array<string, mixed>|\WP\McpSchema\Common\Protocol\DTO\GetTaskPayloadRequestParams
     * } $data
     * @phpstan-param array<string, mixed> $data
     * @return self
     */
    public static function fromArray(array $data): self
    {
        self::assertRequired($data, ['jsonrpc', 'id', 'params']);
        /** @var '2.0' $jsonrpc */
        $jsonrpc = self::asString($data['jsonrpc']);
        /** @var string|number $id */
        $id = self::asStringOrNumber($data['id']);
        /** @var \WP\McpSchema\Common\Protocol\DTO\GetTaskPayloadRequestParams $params */
        $params = is_array($data['params']) ? GetTaskPayloadRequestParams::fromArray(self::asArray($data['params'])) : $data['params'];
        return new self($jsonrpc, $id, $params);
    }
    /**
     * Converts the instance to an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(): array
    {
        $result = parent::toArray();
        $result['params'] = $this->typedParams->toArray();
        return $result;
    }
    /**
     * @return \WP\McpSchema\Common\Protocol\DTO\GetTaskPayloadRequestParams
     */
    public function getTypedParams(): GetTaskPayloadRequestParams
    {
        return $this->typedParams;
    }
}
