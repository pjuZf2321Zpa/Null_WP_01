<?php

namespace PixelYourSite;

/**
 * Per-order "don't send the purchase" switches for orders created by hand in
 * wp-admin (WooCommerce and EDD).
 *
 * Two groups:
 *  - 'ads': server Purchase to Meta, TikTok, OpenAI and Pinterest, and POAS to Meta and TikTok.
 *  - 'ga':  GA4 server Purchase, GA4 POAS and the GA4 refund of the order.
 *
 * pys_order_purchase_blocked() is the only read; the browser Purchase does not
 * call it yet, a later filter there can use the same group names.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * @param string $group 'ads' or 'ga'
 * @return string Meta key, '' for an unknown group
 */
function pys_order_purchase_block_meta_key( $group ) {
    $keys = array(
        'ads' => '_pys_block_ads_purchase',
        'ga'  => '_pys_block_ga_purchase',
    );

    return isset( $keys[ $group ] ) ? $keys[ $group ] : '';
}

/**
 * Read a meta value of a Woo order (object or id) or an EDD order (id).
 */
function pys_order_purchase_read_meta( $type, $order_or_id, $key ) {
    if ( 'woo' === $type ) {
        $order = is_object( $order_or_id ) ? $order_or_id : ( function_exists( 'wc_get_order' ) ? wc_get_order( $order_or_id ) : false );

        return $order ? $order->get_meta( $key, true ) : '';
    }

    if ( 'edd' === $type && function_exists( 'edd_get_payment_meta' ) ) {
        $id = is_object( $order_or_id ) ? ( isset( $order_or_id->id ) ? $order_or_id->id : 0 ) : $order_or_id;

        return $id ? edd_get_payment_meta( (int) $id, $key, true ) : '';
    }

    return '';
}

/**
 * Is the group locked in the UI? Once the purchase handler has processed the
 * order (outer fired flag) both groups are; before that GA locks on its own flag.
 */
function pys_order_purchase_sent( $type, $order_or_id, $group ) {
    if ( pys_order_purchase_read_meta( $type, $order_or_id, '_pys_advance_purchase_event_fired' ) ) {
        return true;
    }

    return 'ga' === $group && (bool) pys_order_purchase_read_meta( $type, $order_or_id, '_pys_ga_advance_purchase_event_fired' );
}

/**
 * The persisted switch only (no request, no filter).
 */
function pys_order_purchase_block_stored( $type, $order_or_id, $group ) {
    $key = pys_order_purchase_block_meta_key( $group );

    return '' !== $key && (bool) pys_order_purchase_read_meta( $type, $order_or_id, $key );
}

/**
 * Is the request the posted wp-admin form of a manual order, from a user who may
 * use it? Checks our nonce and both capabilities.
 *
 * @param string $store_cap Capability of the store: edit_shop_orders / edit_shop_payments
 */
function pys_manual_order_request_allowed( $store_cap ) {
    if ( empty( $_POST['pys_manual_order_nonce'] ) || ! is_string( $_POST['pys_manual_order_nonce'] ) ) {
        return false;
    }

    if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['pys_manual_order_nonce'] ) ), 'pys_manual_order' ) ) {
        return false;
    }

    return current_user_can( 'manage_pys' ) && current_user_can( $store_cap );
}

/**
 * Value of one posted checkbox: true / false, or null if the form did not offer it.
 */
function pys_manual_order_posted_group( $group ) {
    if ( empty( $_POST['pys_mo_present'][ $group ] ) ) {
        return null;
    }

    return ! empty( $_POST['pys_mo_block'][ $group ] );
}

/**
 * EDD completes a manual order inside the add-order POST, before anything could
 * save our meta in a later hook: the form itself decides until it is persisted.
 */
function pys_edd_add_order_request_blocks( $group ) {
    if ( ! function_exists( 'doing_action' ) || ! doing_action( 'edd_add_order' ) ) {
        return false;
    }

    if ( ! pys_manual_order_request_allowed( 'edit_shop_payments' ) ) {
        return false;
    }

    return true === pys_manual_order_posted_group( $group );
}

/**
 * Should the purchase of this group be skipped for the order?
 *
 * @param string         $type        'woo' or 'edd'
 * @param \WC_Order|int  $order_or_id Woo order or id; EDD order id
 * @param string         $group       'ads' or 'ga'
 * @return bool
 */
function pys_order_purchase_blocked( $type, $order_or_id, $group ) {
    $blocked = pys_order_purchase_block_stored( $type, $order_or_id, $group );

    if ( ! $blocked && 'edd' === $type ) {
        $blocked = pys_edd_add_order_request_blocks( $group );
    }

    $order_id = is_object( $order_or_id )
        ? ( method_exists( $order_or_id, 'get_id' ) ? $order_or_id->get_id() : ( isset( $order_or_id->id ) ? $order_or_id->id : 0 ) )
        : (int) $order_or_id;

    return (bool) apply_filters( 'pys_order_purchase_blocked', $blocked, $type, $order_id, $group );
}

/**
 * Applies the posted checkboxes through $write( $meta_key, $block ). A group that
 * already went out, or that the form did not offer, is left alone.
 */
function pys_manual_order_apply_posted( $type, $order_or_id, $write ) {
    foreach ( array( 'ads', 'ga' ) as $group ) {
        $posted = pys_manual_order_posted_group( $group );

        if ( null === $posted || pys_order_purchase_sent( $type, $order_or_id, $group ) ) {
            continue;
        }

        $write( pys_order_purchase_block_meta_key( $group ), $posted );
    }
}

class ManualOrderPurchaseBlock {

    public static function init() {
        // Woo: add_meta_boxes registers early so the box sits above "Order data".
        add_action( 'add_meta_boxes', array( __CLASS__, 'woo_add_meta_box' ), 1, 2 );
        // WC_Meta_Box_Order_Data::save changes the status (and fires our purchase
        // hooks) at priority 40: the flags have to be stored before that.
        add_action( 'woocommerce_process_shop_order_meta', array( __CLASS__, 'woo_save' ), 5, 1 );

        // EDD: the add-order action completes the order before
        // edd_post_add_manual_order, so store on edd_complete_purchase first.
        add_action( 'edd_add_order_details_main_before', array( __CLASS__, 'edd_render_add' ) );
        add_action( 'edd_view_order_details_main_before', array( __CLASS__, 'edd_render_view' ) );
        add_action( 'edd_complete_purchase', array( __CLASS__, 'edd_persist_new_order' ), 1, 1 );
        add_action( 'edd_post_add_manual_order', array( __CLASS__, 'edd_persist_new_order' ), 10, 1 );
        // EDD's own handler (10) may complete the order.
        add_action( 'edd_update_payment_details', array( __CLASS__, 'edd_save_view' ), 5, 1 );
    }

    /* ---------- WooCommerce ---------- */

    public static function woo_order_is_manual( $order, $saving = false ) {
        if ( ! $order instanceof \WC_Order || 'shop_order' !== $order->get_type() ) {
            return false;
        }

        // Legacy storage, saving a new order: the post is already a draft and WC
        // sets created_via only at priority 40, from this same POST field.
        if ( $saving && isset( $_POST['original_post_status'] ) && 'auto-draft' === $_POST['original_post_status'] ) {
            return true;
        }

        // Legacy storage: a fresh "Add order" screen is an auto-draft, created_via is set on save.
        return 'admin' === $order->get_created_via() || in_array( $order->get_status(), array( 'auto-draft', 'new' ), true );
    }

    public static function woo_add_meta_box( $screen_or_type, $object = null ) {
        if ( ! current_user_can( 'manage_pys' ) || ! current_user_can( 'edit_shop_orders' ) ) {
            return;
        }

        $screen = isWooUseHPStorage() ? wc_get_page_screen_id( 'shop-order' ) : 'shop_order';
        if ( $screen !== $screen_or_type ) {
            return;
        }

        $order = self::woo_resolve_order( $object );
        if ( ! self::woo_order_is_manual( $order ) ) {
            return;
        }

        add_meta_box( 'pys_manual_order_tracking', __( 'PixelYourSite Pro: Purchase events', 'pys' ),
            array( __CLASS__, 'woo_render' ), $screen, 'normal', 'high' );
    }

    private static function woo_resolve_order( $object ) {
        if ( $object instanceof \WC_Order ) {
            return $object;
        }
        if ( $object instanceof \WP_Post ) {
            return wc_get_order( $object->ID );
        }

        return wc_get_order( isset( $GLOBALS['theorder'] ) ? $GLOBALS['theorder'] : 0 );
    }

    public static function woo_render( $object ) {
        $order = self::woo_resolve_order( $object );
        if ( ! $order ) {
            return;
        }

        self::render_fields( 'woo', $order );
    }

    public static function woo_save( $order_id ) {
        $order = wc_get_order( $order_id );

        if ( ! self::woo_order_is_manual( $order, true ) || ! pys_manual_order_request_allowed( 'edit_shop_orders' ) ) {
            return;
        }

        $changed = false;
        pys_manual_order_apply_posted( 'woo', $order, function ( $key, $block ) use ( $order, &$changed ) {
            if ( $block ) {
                $order->update_meta_data( $key, '1' );
            } else {
                $order->delete_meta_data( $key );
            }
            $changed = true;
        } );

        if ( $changed ) {
            $order->save();
        }
    }

    /* ---------- EDD ---------- */

    public static function edd_render_add() {
        if ( current_user_can( 'manage_pys' ) && current_user_can( 'edit_shop_payments' ) ) {
            self::render_fields( 'edd', 0, true );
        }
    }

    public static function edd_render_view( $order_id ) {
        if ( current_user_can( 'manage_pys' ) && current_user_can( 'edit_shop_payments' )
            && pys_order_purchase_read_meta( 'edd', (int) $order_id, '_pys_manual_order' ) ) {
            self::render_fields( 'edd', (int) $order_id, true );
        }
    }

    private static function edd_write( $order_id ) {
        return function ( $key, $block ) use ( $order_id ) {
            if ( $block ) {
                edd_update_payment_meta( $order_id, $key, '1' );
            } elseif ( function_exists( 'edd_delete_order_meta' ) ) {
                edd_delete_order_meta( $order_id, $key );
            } else {
                edd_update_payment_meta( $order_id, $key, '' );
            }
        };
    }

    /**
     * Runs twice for a complete order (edd_complete_purchase, then
     * edd_post_add_manual_order); both only inside the add-order request.
     */
    public static function edd_persist_new_order( $order_id ) {
        if ( ! function_exists( 'doing_action' ) || ! doing_action( 'edd_add_order' )
            || ! pys_manual_order_request_allowed( 'edit_shop_payments' ) ) {
            return;
        }

        $order_id = (int) $order_id;
        edd_update_payment_meta( $order_id, '_pys_manual_order', '1' );
        pys_manual_order_apply_posted( 'edd', $order_id, self::edd_write( $order_id ) );
    }

    public static function edd_save_view( $data ) {
        $order_id = isset( $data['edd_payment_id'] ) ? absint( $data['edd_payment_id'] ) : 0;

        if ( ! $order_id || ! pys_manual_order_request_allowed( 'edit_shop_payments' )
            || ! pys_order_purchase_read_meta( 'edd', $order_id, '_pys_manual_order' ) ) {
            return;
        }

        pys_manual_order_apply_posted( 'edd', $order_id, self::edd_write( $order_id ) );
    }

    /* ---------- Output ---------- */

    /**
     * @param string          $type
     * @param \WC_Order|int   $order_or_id Order, or 0 on the EDD add screen
     * @param bool            $edd_box     Wrap in an EDD postbox
     */
    private static function render_fields( $type, $order_or_id, $edd_box = false ) {
        $rows = array(
            'ads' => __( "Don't send an advertising purchase event for this order", 'pys' ),
            'ga'  => __( "Don't send a Google Analytics purchase event for this order", 'pys' ),
        );

        if ( $edd_box ) {
            echo '<div class="postbox"><h2 class="hndle">' . esc_html__( 'PixelYourSite Pro: Purchase events', 'pys' ) . '</h2><div class="inside">';
        }

        wp_nonce_field( 'pys_manual_order', 'pys_manual_order_nonce', false );

        foreach ( $rows as $group => $label ) {
            $has_order = (bool) $order_or_id;
            $blocked   = $has_order && pys_order_purchase_block_stored( $type, $order_or_id, $group );
            $sent      = $has_order && pys_order_purchase_sent( $type, $order_or_id, $group );

            echo '<p style="font-size:14px;font-weight:600;margin:8px 0;">';
            if ( $sent ) {
                echo esc_html( $label ) . ' &mdash; <em style="font-weight:400;">'
                    . esc_html( $blocked ? __( 'Blocked for this order', 'pys' ) : __( 'Purchase event already sent', 'pys' ) )
                    . '</em>';
            } else {
                echo '<label><input type="hidden" name="pys_mo_present[' . esc_attr( $group ) . ']" value="1">'
                    . '<input type="checkbox" name="pys_mo_block[' . esc_attr( $group ) . ']" value="1"' . checked( $blocked, true, false ) . '> '
                    . esc_html( $label ) . '</label>';
            }
            echo '</p>';
        }

        if ( $edd_box ) {
            echo '</div></div>';
        }
    }
}
