<?php
namespace PixelYourSite;

use Exception;

defined('ABSPATH') or die('Direct access not allowed');

/**
 * Queue system for server events
 * Replaces async tasks with queue system + WP Cron
 */
class EventsQueue {

    /**
     * Bump this constant whenever the table schema changes.
     * createTableIfNeeded() then runs on the next request: CREATE TABLE for a
     * fresh site, ensureColumns() for an existing table.
     *
     * 1.1 — claim_token / claimed_at: a worker claims a row before sending it.
     */
    const DB_VERSION = '1.1';

    /**
     * Set when ensureColumns() could not bring the table up to DB_VERSION
     * (typically a DB user without ALTER TABLE on a managed host). Holds the
     * error text; shown in the Cron health report and stops processQueue(),
     * which would otherwise fail on every claim with "unknown column" and
     * look like an empty queue. Cleared once the upgrade succeeds.
     */
    const SCHEMA_ERROR_OPTION = 'pys_queue_schema_error';

    /** Throttles the upgrade attempt after a failure: once an hour, not every request. */
    const SCHEMA_RETRY_TRANSIENT = 'pys_queue_schema_retry';

    /**
     * A row claimed this long ago and still 'processing' belongs to a worker
     * that died mid-send (fatal, killed PHP, lost connection). It goes back
     * to 'pending' so the next run picks it up. Generous on purpose: a single
     * row is one event per pixel, each bounded by the connect + request
     * timeouts, so a live worker never holds a claim anywhere near this long.
     */
    const STALE_CLAIM_SECONDS = 900;

    /**
     * Fallback draining, for when WP-Cron is not running.
     *
     * Since server-side events on the add-to-cart path go through the queue, a
     * dead cron means they are never delivered and eventually deleted by the
     * pending cleanup. If the oldest pending row is far older than the processing
     * interval, we drain a small batch on a normal front-end request — but only
     * after the response has been handed to the visitor, so nobody waits for it.
     *
     * Both markers are autoloaded options: reading them costs no extra query.
     */
    const SELF_HEAL_CHECK_OPTION    = 'pys_queue_selfheal_checked_at';
    const SELF_HEAL_LAST_RUN_OPTION = 'pys_queue_selfheal_last_run';
    const SELF_HEAL_BATCH           = 20;
    const SELF_HEAL_TIME_BUDGET     = 20; // seconds

    private static $_instance;
    private $table_name;
    private $max_events_per_batch;
    // Note: there is no $processing_interval property. It used to be assigned in
    // the constructor with a 300 fallback that contradicted the 60 in
    // options_defaults.json, and nothing ever read it. Read the option directly.
    private $cached_stats = null;
    private $stats_cache_time = 0;
    private $cache_duration = 30; // Cache for 30 seconds
    private $table_exists_cache = null; // Cache table existence for current request
    private $pending_count_cache = null; // Cache pending count for current request

    public static function instance() {
        if (is_null(self::$_instance)) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    public function __construct() {
        global $wpdb;
        $this->table_name = $wpdb->prefix . 'pys_events_queue';
        
        // Default settings
        $this->max_events_per_batch = PYS()->getOption('queue_max_events_per_batch', 500);

        // Priority 9, after PYS::init() has located the options and before the
        // servers' own 'init' at 10: they decide there whether to register
        // their async task, and need to know if the table upgrade just failed.
        add_action('init', array($this, 'init'), 9);
        add_action('pys_process_events_queue', array($this, 'processQueue'));
        add_action('pys_cleanup_events_queue', array($this, 'runScheduledCleanup'));
        add_action('wp_ajax_pys_process_queue_manual', array($this, 'processQueueManual'));
        add_action('wp_ajax_pys_cleanup_queue', array($this, 'cleanupQueueAjax'));
        add_action('wp_ajax_pys_refresh_queue_stats', array($this, 'refreshQueueStatsAjax'));
        add_action('wp_ajax_pys_reset_failed_events', array($this, 'resetFailedEventsAjax'));

        // Last thing in the request, so the response is already complete.
        add_action('shutdown', array($this, 'maybeSelfHeal'), PHP_INT_MAX);
    }

    public function init() {
        $this->createTableIfNeeded();
        $this->scheduleCron();
        $this->scheduleCleanupCron();
    }

    /**
     * Whether the table is short of the columns processQueue() relies on.
     *
     * The schema version is asked first: it is autoloaded, the error is not,
     * and on a healthy site the error option does not exist — reading a
     * missing option costs a query on every request that sends an event.
     *
     * Static so the Pinterest add-on can ask without creating the instance
     * earlier than 'init' priority 5.
     *
     * @return bool
     */
    public static function hasSchemaError() {
        if ( get_option( 'pys_queue_db_version' ) === self::DB_VERSION ) {
            return false;
        }

        return '' !== (string) get_option( self::SCHEMA_ERROR_OPTION, '' );
    }

    /**
     * Whether an event may be handed to the queue: switched on, and able to
     * deliver. A row added while the schema error is set is never claimed, so
     * senders must treat that state as "queue off" and send directly.
     *
     * @return bool
     */
    public static function isUsable() {
        return (bool) PYS()->getOption( 'queue_enabled', true ) && ! self::hasSchemaError();
    }

    /**
     * Create table only when the schema version has changed or the option is missing.
     * get_option() is served from the in-memory autoloaded options cache, so this
     * costs zero extra DB queries on every normal request.
     */
    private function createTableIfNeeded() {
        if ( get_option( 'pys_queue_db_version' ) === self::DB_VERSION ) {
            return;
        }
        if ( get_transient( self::SCHEMA_RETRY_TRANSIENT ) ) {
            return; // a recent attempt failed; see SCHEMA_RETRY_TRANSIENT
        }

        $this->createTable();
        $error = $this->ensureColumns();

        if ( '' === $error ) {
            // The version is recorded only once the table really has every
            // column this code relies on. Recording it on a failed ALTER used
            // to leave the queue silently unable to claim a single row.
            update_option( 'pys_queue_db_version', self::DB_VERSION );
            delete_option( self::SCHEMA_ERROR_OPTION );
            delete_transient( self::SCHEMA_RETRY_TRANSIENT );
            return;
        }

        update_option( self::SCHEMA_ERROR_OPTION, $error, false );
        set_transient( self::SCHEMA_RETRY_TRANSIENT, 1, HOUR_IN_SECONDS );
        PYS()->getLog()->error( 'Queue table upgrade failed: ' . $error );
    }

    /**
     * Columns added after the table first shipped. CREATE TABLE IF NOT EXISTS
     * leaves an existing table alone, so they are added here.
     *
     * The ALTER is not trusted: the column list is read again afterwards, and
     * the columns still missing are reported so the caller does not record a
     * schema version the table does not have.
     *
     * @return string '' when every column is present, otherwise what is wrong.
     */
    private function ensureColumns() {
        global $wpdb;

        $required = array(
            'claim_token' => "ALTER TABLE {$this->table_name} ADD COLUMN claim_token varchar(40) NULL, ADD KEY claim_token (claim_token)",
            'claimed_at'  => "ALTER TABLE {$this->table_name} ADD COLUMN claimed_at datetime NULL",
        );

        $columns = $wpdb->get_col( "SHOW COLUMNS FROM {$this->table_name}", 0 );
        if ( ! is_array( $columns ) ) {
            return sprintf( 'could not read the columns of %s%s', $this->table_name,
                $wpdb->last_error ? ' (' . $wpdb->last_error . ')' : '' );
        }

        $alter_errors = array();
        foreach ( $required as $column => $sql ) {
            if ( in_array( $column, $columns, true ) ) {
                continue;
            }
            if ( false === $wpdb->query( $sql ) && $wpdb->last_error ) {
                $alter_errors[] = $wpdb->last_error;
            }
        }

        $columns = $wpdb->get_col( "SHOW COLUMNS FROM {$this->table_name}", 0 );
        $missing = is_array( $columns )
            ? array_values( array_diff( array_keys( $required ), $columns ) )
            : array_keys( $required );

        if ( empty( $missing ) ) {
            return '';
        }

        return sprintf( '%s is missing column(s) %s and they could not be added%s. Grant the database user ALTER TABLE, or add the columns by hand',
            $this->table_name,
            implode( ', ', $missing ),
            $alter_errors ? ' (' . implode( '; ', array_unique( $alter_errors ) ) . ')' : ''
        );
    }

    /**
     * Create table for events queue
     */
    private function createTable() {
        global $wpdb;

        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE IF NOT EXISTS {$this->table_name} (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            pixel_type varchar(50) NOT NULL,
            event_name varchar(191) NULL,
            event_id varchar(191) NULL,
            event_data longtext NOT NULL,
            created_at datetime NULL,
            processed_at datetime NULL,
            retry_count int(11) DEFAULT 0,
            status varchar(20) DEFAULT 'pending',
            error_message text NULL,
            claim_token varchar(40) NULL,
            claimed_at datetime NULL,
            PRIMARY KEY (id),
            KEY pixel_type (pixel_type),
            KEY status (status),
            KEY created_at (created_at),
            KEY claim_token (claim_token)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        $wpdb->query($sql);
    }

    /**
     * Schedule WP Cron task for queue processing
     */
    private function scheduleCron() {
        if (!wp_next_scheduled('pys_process_events_queue')) {
            wp_schedule_event(time(), 'pys_queue_interval', 'pys_process_events_queue');
        }
    }

    /**
     * Schedule WP Cron task for automatic cleanup
     */
    private function scheduleCleanupCron() {
        if (!wp_next_scheduled('pys_cleanup_events_queue')) {
            wp_schedule_event(time(), 'daily', 'pys_cleanup_events_queue');
        }
    }

    /**
     * Run scheduled cleanup task
     */
    public function runScheduledCleanup() {
        $this->cleanupOldEvents();
        $this->cleanupStuckPendingEvents();
    }

    /**
     * Cleanup pending events that are stuck for too long
     */
    public function cleanupStuckPendingEvents() {
        global $wpdb;

        $cleanup_days = PYS()->getOption('queue_pending_cleanup_days', 1);

        if ($cleanup_days <= 0) {
            return 0;
        }

        // Nothing is stuck: processQueue() is refusing to run. No new rows are
        // added in this state, so what waits is bounded, and it is delivered
        // once the table upgrade succeeds.
        if (self::hasSchemaError()) {
            return 0;
        }

        $cutoff_date = date('Y-m-d H:i:s', current_time('timestamp') - ($cleanup_days * DAY_IN_SECONDS));

        $deleted = $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM {$this->table_name}
                 WHERE status IN (%s, %s)
                 AND created_at < %s",
                'pending', 'processing', $cutoff_date
            )
        );

        if ($deleted > 0) {
            PYS()->getLog()->debug('Cleaned up ' . $deleted . ' stuck pending events from queue (older than ' . $cleanup_days . ' days)');
            $this->pending_count_cache = null;
            $this->clearStatsCache();
        }

        return $deleted;
    }

    /**
     * Extract event information
     */
    private function extractEventInfo($pixel_type, $event_data) {
        $event_names = array();
        $event_ids = array();

        try {
            // Process array of events
            if (is_array($event_data)) {
                foreach ($event_data as $event_item) {
                    if ($pixel_type === 'facebook' && isset($event_item['event'])) {
                        $event = $event_item['event'];
                        // For Facebook SDK use getEventName and getEventId methods
                        if (is_object($event)) {
                            if (method_exists($event, 'getEventName')) {
                                $event_name = $event->getEventName();
                                if ($event_name) {
                                    $event_names[] = $event_name;
                                }
                            }
                            if (method_exists($event, 'getEventId')) {
                                $event_id = $event->getEventId();
                                if ($event_id) {
                                    $event_ids[] = $event_id;
                                }
                            }
                        }
                    } elseif ($pixel_type === 'tiktok' && isset($event_item['event'])) {
                        $event = $event_item['event'];
                        if (isset($event->event)) {
                            $event_names[] = $event->event;
                        }
                        if (isset($event->event_id)) {
                            $event_ids[] = $event->event_id;
                        }
                    } elseif ($pixel_type === 'openai' && isset($event_item['event'])) {
                        $event = $event_item['event'];
                        if (isset($event->type)) {
                            $event_names[] = $event->type;
                        }
                        if (isset($event->id)) {
                            $event_ids[] = $event->id;
                        }
                    } elseif ($pixel_type === 'pinterest' && isset($event_item['event'])) {
                        $event = $event_item['event'];
                        if (isset($event->event_name)) {
                            $event_names[] = $event->event_name;
                        }
                        if (isset($event->event_id)) {
                            $event_ids[] = $event->event_id;
                        }
                    }
                }
            }
            // Process single event (for backward compatibility)
            elseif ($pixel_type === 'facebook' && isset($event_data['event'])) {
                $event = $event_data['event'];

                // For Facebook SDK use getEventName and getEventId methods
                if (is_object($event)) {
                    if (method_exists($event, 'getEventName')) {
                        $event_name = $event->getEventName();
                        if ($event_name) {
                            $event_names[] = $event_name;
                        }
                    }
                    if (method_exists($event, 'getEventId')) {
                        $event_id = $event->getEventId();
                        if ($event_id) {
                            $event_ids[] = $event_id;
                        }
                    }
                }
            } elseif ($pixel_type === 'tiktok' && isset($event_data['event'])) {
                $event = $event_data['event'];
                if (isset($event->event)) {
                    $event_names[] = $event->event;
                }
                if (isset($event->event_id)) {
                    $event_ids[] = $event->event_id;
                }
            } elseif ($pixel_type === 'pinterest' && isset($event_data['event'])) {
                $event = $event_data['event'];
                if (isset($event->event_name)) {
                    $event_names[] = $event->event_name;
                }
                if (isset($event->event_id)) {
                    $event_ids[] = $event->event_id;
                }
            }
        } catch (Exception $e) {
            PYS()->getLog()->debug('Failed to extract event info: ' . $e->getMessage());
        }
        return array(
            'event_name' => implode(', ', array_filter($event_names)),
            'event_id' => implode(', ', array_filter($event_ids))
        );
    }

    /**
     * Add event to queue
     */
    public function addEvent($pixel_type, $event_data) {
        global $wpdb;

        // Check queue limits
        if ($this->isQueueOverloaded()) {
            return false;
        }

        // Extract event information
        $event_info = $this->extractEventInfo($pixel_type, $event_data);
        // Use PHP serialize to save objects in original form
        $serialized_data = base64_encode(serialize($event_data));
        PYS()->getLog()->debug('Adding event to queue: ' . $event_info['event_name'] . ' (' . $pixel_type . ')');
        $result = $wpdb->insert(
            $this->table_name,
            array(
                'pixel_type' => sanitize_text_field($pixel_type),
                'event_name' => sanitize_text_field($event_info['event_name']),
                'event_id' => sanitize_text_field($event_info['event_id']),
                'event_data' => $serialized_data,
                'created_at' => current_time('mysql'),
                'status' => 'pending'
            ),
            array('%s', '%s', '%s', '%s', '%s', '%s')
        );

        if ($result === false) {
            PYS()->getLog()->error('Failed to add event to queue: ' . $wpdb->last_error);
            return false;
        }

        // Keep the cached pending count in step instead of re-counting on the
        // next insert — one add-to-cart enqueues one event per server pixel.
        if ($this->pending_count_cache !== null) {
            $this->pending_count_cache++;
        }

        // Clear cache when data changes
        $this->clearStatsCache();

        return $wpdb->insert_id;
    }


    /**
     * Batch processing of events from queue
     *
     * Rows are claimed one at a time with an atomic UPDATE (pending → processing
     * with this worker's token), and only a claimed row is sent. Two runs that
     * overlap — cron and the self-heal path, cron and the manual button, two
     * cron hits on a busy site — therefore never send the same row. The
     * transient lock below is just a throttle: it keeps a second run from
     * spinning while the first one is busy, it is not what protects the rows.
     *
     * @param int|null $limit       Rows to take. Defaults to queue_max_events_per_batch.
     * @param int|null $max_seconds Stop claiming new rows once this much time has
     *                              passed; unclaimed rows stay pending for the next
     *                              run. Defaults to the processing interval, so a
     *                              batch of slow sends cannot pile up behind the
     *                              next cron tick. Cron passes nothing here.
     */
    public function processQueue($limit = null, $max_seconds = null) {
        global $wpdb;

        // Check if processing is already running
        $lock_key = 'pys_queue_processing_lock';
        if (get_transient($lock_key)) {
            return;
        }

        // Without the claim columns every claimNextRow() fails with "unknown
        // column" and the queue would look empty. The error is already in the
        // log and the Cron health report; rows stay pending for when it is fixed.
        if (self::hasSchemaError()) {
            return;
        }

        $limit = $limit === null ? $this->max_events_per_batch : (int) $limit;
        $limit = max(1, $limit);

        if ($max_seconds === null) {
            $max_seconds = max(30, (int) PYS()->getOption('queue_processing_interval', 60));
        }

        // The lock outlives the time budget by a minute at most. A worker that
        // dies mid-run never reaches the finally below, and a 10-minute lock
        // used to stall every run for that long.
        set_transient($lock_key, true, $max_seconds + 60);

        try {
            $this->releaseStaleClaims();

            $processed_count = 0;
            $failed_count = 0;
            $started = microtime(true);

            while ($processed_count + $failed_count < $limit) {
                if ($max_seconds && (microtime(true) - $started) > $max_seconds) {
                    PYS()->getLog()->debug(sprintf(
                        'Queue batch stopped after %ds: %d rows handled, the rest stay pending',
                        $max_seconds, $processed_count + $failed_count
                    ));
                    break;
                }

                $event = $this->claimNextRow();
                if (!$event) {
                    break;
                }

                if ($this->processEvent($event)) {
                    $processed_count++;
                } else {
                    $failed_count++;
                }
            }

            if ($processed_count + $failed_count > 0) {
                // Clear cache when data changes
                $this->pending_count_cache = null;
                $this->clearStatsCache();
            }

        // Throwable, not Exception: a TypeError or a call on an incomplete object
        // is an Error, and it used to take the whole worker down with the row
        // still claimed -- no message, no retry, re-claimed every minute.
        } catch (\Throwable $e) {
            PYS()->getLog()->error('Queue processing error: ' . $e->getMessage());
        } finally {
            // Remove lock
            delete_transient($lock_key);
        }
    }

    /**
     * Claim the oldest pending row for this worker.
     *
     * The UPDATE is the whole point: it flips exactly one pending row to
     * 'processing' and stamps it with a fresh token in a single statement,
     * so two workers running the same statement at the same time get two
     * different rows. The SELECT that follows only reads back what this
     * worker won. Before this, rows were read with a plain SELECT and stayed
     * 'pending' until after the send, so any overlap sent them twice.
     *
     * @return object|null The claimed row, or null when nothing is pending
     */
    private function claimNextRow() {
        global $wpdb;

        $token = wp_generate_password(32, false, false);

        $claimed = $wpdb->query($wpdb->prepare(
            "UPDATE {$this->table_name}
             SET status = 'processing', claim_token = %s, claimed_at = %s
             WHERE status = 'pending'
             ORDER BY created_at ASC, id ASC
             LIMIT 1",
            $token, current_time('mysql')
        ));

        if (!$claimed) {
            return null;
        }

        $row = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$this->table_name} WHERE claim_token = %s AND status = 'processing' LIMIT 1",
            $token
        ));

        return $row ?: null;
    }

    /**
     * Hand rows back whose worker died mid-send. See STALE_CLAIM_SECONDS.
     */
    private function releaseStaleClaims() {
        global $wpdb;

        $cutoff = date('Y-m-d H:i:s', current_time('timestamp') - self::STALE_CLAIM_SECONDS);

        $released = $wpdb->query($wpdb->prepare(
            "UPDATE {$this->table_name}
             SET status = 'pending', claim_token = NULL, claimed_at = NULL
             WHERE status = 'processing' AND (claimed_at IS NULL OR claimed_at < %s)",
            $cutoff
        ));

        if ($released > 0) {
            PYS()->getLog()->debug(sprintf(
                'Queue: %d row(s) were still processing after %d s, handed back to pending',
                $released, self::STALE_CLAIM_SECONDS
            ));
        }
    }

    /**
     * Get allowed classes for unserialize based on pixel type
     */
    private function getAllowedClassesForPixelType($pixel_type) {
        switch ($pixel_type) {
            case 'facebook':
                return [
                    'stdClass',
                    // What mapEventToServerEvent() actually builds. Left out, it
                    // revives as __PHP_Incomplete_Class and the first method call
                    // on it raises an Error -- see tools/tests/queue-unserialize.
                    'PixelYourSite\PysServerEvent',
                    'PYS_PRO_GLOBAL\FacebookAds\Object\ServerSide\Event',
                    'PYS_PRO_GLOBAL\FacebookAds\Object\ServerSide\UserData',
                    'PYS_PRO_GLOBAL\FacebookAds\Object\ServerSide\CustomData',
                    'PYS_PRO_GLOBAL\FacebookAds\Object\ServerSide\Content',
                ];
            default:
                // TikTok, Pinterest and others use plain stdClass objects
                return [ 'stdClass' ];
        }
    }

    /**
     * Process single event
     */
    private function processEvent($event) {
        global $wpdb;

        $remaining = null;

        try {
            // Deserialize data - allowed classes depend on pixel type
            $allowed_classes = $this->getAllowedClassesForPixelType($event->pixel_type);
            if ( $event->pixel_type === 'facebook' ) {
                ServerEventHelper::requireServerSideClasses();
            }
            $event_data = unserialize(
                base64_decode($event->event_data),
                [ 'allowed_classes' => $allowed_classes ]
            );

            if (!$event_data) {
                throw new Exception('Invalid event data');
            }

            // Send event to appropriate server module
            $result  = $this->sendEventToServer($event->pixel_type, $event_data);
            $status  = isset($result['status']) ? $result['status'] : AbstractServerEvents::SEND_SENT;
            $message = isset($result['message']) ? (string) $result['message'] : '';

            // Delivered, or there was nothing to deliver: the row is done either way.
            if ($status === AbstractServerEvents::SEND_SENT || $status === AbstractServerEvents::SEND_SKIPPED) {
                $wpdb->update(
                    $this->table_name,
                    array(
                        'status' => 'processed',
                        'processed_at' => current_time('mysql'),
                        'claim_token' => null
                    ),
                    array('id' => $event->id),
                    array('%s', '%s', '%s'),
                    array('%d')
                );

                return true;
            }

            // Rejected by the platform — a bad token or an invalid payload will be
            // rejected again, so fail the row now instead of burning every retry.
            if ($status === AbstractServerEvents::SEND_FAILED) {
                $wpdb->update(
                    $this->table_name,
                    array(
                        'status' => 'failed',
                        'error_message' => $message,
                        'processed_at' => current_time('mysql'),
                        'claim_token' => null
                    ),
                    array('id' => $event->id),
                    array('%s', '%s', '%s', '%s'),
                    array('%d')
                );

                PYS()->getLog()->error('Event rejected by platform, not retrying', array(
                    'queue_id'   => $event->id,
                    'pixel_type' => $event->pixel_type,
                    'event_name' => $event->event_name,
                    'event_id'   => $event->event_id,
                    'error'      => $message
                ));

                return false;
            }

            // Transient problem: fall through to the retry accounting below.
            // Whatever the senders reported as already done is dropped from the
            // row first, so the retry only carries what still has to go out.
            if (isset($result['remaining']) && is_array($result['remaining'])) {
                $remaining = $result['remaining'];
            }
            throw new Exception($message !== '' ? $message : 'Failed to send event to server');

        // Throwable: an Error here skipped the retry accounting entirely and
        // left the row claimed, so the queue looked alive and delivered nothing.
        } catch (\Throwable $e) {
            // Increment retry counter
            $retry_count = $event->retry_count + 1;
            $max_retries = PYS()->getOption('queue_max_retries', 3);

            if ($retry_count >= $max_retries) {
                // Mark as failed after maximum retry attempts
                $wpdb->update(
                    $this->table_name,
                    array(
                        'status' => 'failed',
                        'error_message' => $e->getMessage(),
                        'retry_count' => $retry_count,
                        'claim_token' => null
                    ),
                    array('id' => $event->id),
                    array('%s', '%s', '%d', '%s'),
                    array('%d')
                );
                
                PYS()->getLog()->error('Event failed after max retries', array(
                    'queue_id' => $event->id,
                    'pixel_type' => $event->pixel_type,
                    'event_name' => $event->event_name,
                    'event_id' => $event->event_id,
                    'retry_count' => $retry_count,
                    'error' => $e->getMessage()
                ));
            } else {
                // Schedule retry: back to pending, claim released. When the
                // senders told us which pixels are already done, the row is
                // rewritten without them (see collectSendResults()).
                $data   = array(
                    'status'        => 'pending',
                    'claim_token'   => null,
                    'retry_count'   => $retry_count,
                    'error_message' => $e->getMessage()
                );
                $format = array('%s', '%s', '%d', '%s');

                if (!empty($remaining)) {
                    $data['event_data'] = base64_encode(serialize(array_values($remaining)));
                    $format[]           = '%s';
                }

                $wpdb->update(
                    $this->table_name,
                    $data,
                    array('id' => $event->id),
                    $format,
                    array('%d')
                );
            }

            PYS()->getLog()->error('Failed to process event', array(
                'event_id' => $event->id,
                'pixel_type' => $event->pixel_type,
                'error' => $e->getMessage(),
                'retry_count' => $retry_count
            ));

            return false;
        }
    }


    /**
     * Send event to appropriate server module
     */
    private function sendEventToServer($pixel_type, $event_data) {
        // Agency Mode Hard block: rows enqueued before the block must not go out
        // either, otherwise tracking data keeps reaching the platform after the
        // site was told it had stopped. SKIPPED closes the row instead of
        // retrying it until the attempts run out. The pixel type is the pixel
        // slug, which is what the block state is keyed by.
        if ( pys_tracking_hard_blocked( $pixel_type ) ) {
            return array(
                'status'  => AbstractServerEvents::SEND_SKIPPED,
                'message' => 'Agency Mode hard block',
            );
        }

        switch ($pixel_type) {
            case 'facebook':
                if (class_exists('PixelYourSite\FacebookServer')) {
                    return $this->collectSendResults($event_data, function ($event) {
                        return FacebookServer()->sendEvent($event['pixelIds'], $event['event']);
                    });
                }
                break;

            case 'tiktok':
                if (class_exists('PixelYourSite\TikTokServer')) {
                    return $this->collectSendResults($event_data, function ($event) {
                        return TikTokServer()->sendEvent($event['pixelIds'], $event['event']);
                    });
                }
                break;

            case 'openai':
                if (class_exists('PixelYourSite\OpenAIServer')) {
                    return $this->collectSendResults($event_data, function ($event) {
                        return OpenAIServer()->sendEvent($event['pixelIds'], $event['event']);
                    });
                }
                break;

            case 'pinterest':
                if (class_exists('PixelYourSite\PinterestServer')) {
                    return $this->collectSendResults($event_data, function ($event) {
                        return PinterestServer()->sendEvent($event['pixelIds'], $event['event']);
                    });
                }
                break;

            default:
                PYS()->getLog()->error('Unknown pixel type: ' . $pixel_type);
                return array('status' => AbstractServerEvents::SEND_FAILED, 'message' => 'Unknown pixel type: ' . $pixel_type);
        }

        return array(
            'status'  => AbstractServerEvents::SEND_FAILED,
            'message' => 'Server class for ' . $pixel_type . ' is not available',
        );
    }

    /**
     * Run a queue row's events through a sender and reduce the outcomes to one.
     *
     * A row may hold several events. The strictest outcome wins, in the order
     * retry > failed > sent > skipped: a transient problem must not be buried by
     * a sibling event that happened to go through, and a rejection must not be
     * reported as success.
     *
     * On a retry outcome the result also carries 'remaining': the row's events
     * with every pixel the sender reported as done ('done' in its result)
     * removed, and events with no pixel left dropped. Events the sender
     * rejected for good (SEND_FAILED) are dropped too: only transient
     * failures are worth another attempt. The retry then sends only what has
     * not been accepted yet. A sender that reports no 'done' keeps its event
     * whole, as before.
     *
     * @param array    $event_data Events stored in the row
     * @param callable $sender     Receives one event, returns a SEND_* result array
     * @return array{status:string,message:string,remaining?:array}
     */
    private function collectSendResults($event_data, callable $sender) {
        $sent = false;
        $skipped = false;
        $retry_message = '';
        $failed_message = '';
        $remaining = array();

        foreach ($event_data as $event) {
            $result = $sender($event);

            // Back-compat: an add-on built against an older core returns nothing.
            // Assume it delivered, which is exactly how the queue behaved before.
            if ($result === null) {
                $sent = true;
                continue;
            }

            $status  = is_array($result) && isset($result['status']) ? $result['status'] : AbstractServerEvents::SEND_SENT;
            $message = is_array($result) && isset($result['message']) ? (string) $result['message'] : '';

            switch ($status) {
                case AbstractServerEvents::SEND_RETRY:
                    $retry_message = $message;
                    break;
                case AbstractServerEvents::SEND_FAILED:
                    $failed_message = $message;
                    break;
                case AbstractServerEvents::SEND_SKIPPED:
                    $skipped = true;
                    break;
                default:
                    $sent = true;
            }

            if ($status !== AbstractServerEvents::SEND_RETRY) {
                // Delivered, nothing to deliver, or rejected for good — none of
                // these gets another attempt, so none of them stays in the row.
                continue;
            }

            if (is_array($result) && isset($result['done']) && is_array($result['done']) && is_array($event) && isset($event['pixelIds'])) {
                $left = array_values(array_filter((array) $event['pixelIds'], function ($id) use ($result) {
                    return !in_array((string) $id, $result['done'], true);
                }));
                if (empty($left)) {
                    continue;
                }
                $event['pixelIds'] = $left;
            }

            $remaining[] = $event;
        }

        if ($retry_message !== '') {
            return array(
                'status'    => AbstractServerEvents::SEND_RETRY,
                'message'   => $failed_message !== '' ? $retry_message . '; ' . $failed_message : $retry_message,
                'remaining' => $remaining,
            );
        }
        if ($failed_message !== '') {
            return array('status' => AbstractServerEvents::SEND_FAILED, 'message' => $failed_message);
        }
        if ($sent) {
            return array('status' => AbstractServerEvents::SEND_SENT, 'message' => '');
        }

        return array(
            'status'  => $skipped ? AbstractServerEvents::SEND_SKIPPED : AbstractServerEvents::SEND_SENT,
            'message' => '',
        );
    }

    /**
     * Check queue overload
     *
     * The pending count is cached for the current request: addEvent() is called
     * once per server-side pixel, and an uncached COUNT(*) per insert was pure
     * overhead inside latency-sensitive requests such as a checkout AJAX call.
     */
    private function isQueueOverloaded() {
        global $wpdb;

        if ($this->pending_count_cache === null) {
            $this->pending_count_cache = (int) $wpdb->get_var(
                "SELECT COUNT(*) FROM {$this->table_name} WHERE status IN ('pending', 'processing')"
            );
        }

        $max_queue_size = PYS()->getOption('queue_max_size', 10000);
        return $this->pending_count_cache >= $max_queue_size;
    }

    /**
     * Cleanup old processed/failed events
     */
    public function cleanupOldEvents() {
        global $wpdb;

        $retention_days = PYS()->getOption('queue_retention_days', 7);
        $cutoff_date = date('Y-m-d H:i:s', current_time('timestamp') - ($retention_days * DAY_IN_SECONDS));

        $deleted = $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM {$this->table_name}
                 WHERE status IN (%s, %s)
                 AND created_at < %s",
                'processed', 'failed', $cutoff_date
            )
        );

        if ($deleted > 0) {
            PYS()->getLog()->debug('Cleaned up ' . $deleted . ' old processed/failed events from queue (older than ' . $retention_days . ' days)');
            $this->clearStatsCache();
        }

        return $deleted;
    }

    /**
     * Get recent events
     */
    public function getRecentEvents($limit = 10) {
        global $wpdb;
        
        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT id, pixel_type, event_name, event_id, status, created_at, processed_at, retry_count, error_message 
             FROM {$this->table_name} 
             ORDER BY created_at DESC 
             LIMIT %d",
            $limit
        ));
        
        return $results;
    }

    /**
     * Check if queue table exists (cached for current request)
     */
    private function tableExists() {
        // Return cached result if available
        if ($this->table_exists_cache !== null) {
            return $this->table_exists_cache;
        }
        
        global $wpdb;
        $this->table_exists_cache = $wpdb->get_var("SHOW TABLES LIKE '{$this->table_name}'") == $this->table_name;
        
        return $this->table_exists_cache;
    }

    /**
     * Clear statistics cache
     */
    public function clearStatsCache() {
        $this->cached_stats = null;
        $this->stats_cache_time = 0;
    }

    /**
     * Get all queue statistics in one optimized call
     */
    public function getAllQueueStats() {
        // Check cache first
        if ($this->cached_stats !== null && (time() - $this->stats_cache_time) < $this->cache_duration) {
            return $this->cached_stats;
        }

        global $wpdb;

        // Check if table exists
        if (!$this->tableExists()) {
            $this->cached_stats = array(
                'pending' => 0,
                'processed' => 0,
                'failed' => 0,
                'total' => 0,
                'last_processed' => __('Never', 'pys'),
                'queue_status' => 'idle',
                'queue_status_text' => __('Idle', 'pys'),
                'processing_rate' => '0',
                'success_rate' => '100'
            );
            $this->stats_cache_time = time();
            return $this->cached_stats;
        }

        // Get WordPress time references (using WordPress timezone consistently)
        $now          = current_time('timestamp');
        $one_hour_ago = date('Y-m-d H:i:s', $now - HOUR_IN_SECONDS);
        $today_start  = date('Y-m-d', $now) . ' 00:00:00';
        // Get all statistics in one query
        $stats = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT
                    COUNT(*) as total,
                    SUM(CASE WHEN status IN ('pending', 'processing') THEN 1 ELSE 0 END) as pending,
                    SUM(CASE WHEN status = 'processed' THEN 1 ELSE 0 END) as processed_all,
                    SUM(CASE WHEN status = 'processed' AND processed_at >= %s THEN 1 ELSE 0 END) as processed_today,
                    SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed,
                    MAX(CASE WHEN status = 'processed' AND processed_at IS NOT NULL THEN processed_at END) as last_processed_at,
                    SUM(CASE WHEN status = 'processed' AND processed_at >= %s THEN 1 ELSE 0 END) as processed_last_hour
                 FROM {$this->table_name}",
                $today_start,
                $one_hour_ago
            ),
            ARRAY_A
        );

        // Calculate additional metrics
        $pending         = (int) ($stats['pending'] ?? 0);
        $processed_today = (int) ($stats['processed_today'] ?? 0);
        $processed_all   = (int) ($stats['processed_all'] ?? 0);
        $failed          = (int) ($stats['failed'] ?? 0);
        $total           = (int) ($stats['total'] ?? 0);
        $processed_last_hour = (int) ($stats['processed_last_hour'] ?? 0);

        // Determine queue status
        if ($pending > 100) {
            $queue_status = 'overloaded';
            $queue_status_text = __('Overloaded', 'pys');
        } elseif ($pending > 0) {
            $queue_status = 'processing';
            $queue_status_text = __('Processing', 'pys');
        } else {
            $queue_status = 'idle';
            $queue_status_text = __('Idle', 'pys');
        }

        // Calculate processing rate
        $processing_rate = ceil($processed_last_hour / 60 * 10) / 10;

        // Calculate success rate (based on all processed events, not just today)
        $total_processed = $processed_all + $failed;
        $success_rate = $total_processed > 0 ? round(($processed_all / $total_processed) * 100, 1) : 100;

        // Format last processed time
        $last_processed = __('Never', 'pys');
        if ($stats['last_processed_at']) {
            $last_processed = date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($stats['last_processed_at']));
        }

        // Cache the results
        $this->cached_stats = array(
            'pending' => $pending,
            'processed' => $processed_today,
            'failed' => $failed,
            'total' => $total,
            'last_processed' => $last_processed,
            'queue_status' => $queue_status,
            'queue_status_text' => $queue_status_text,
            'processing_rate' => $processing_rate,
            'success_rate' => $success_rate
        );
        $this->stats_cache_time = time();

        return $this->cached_stats;
    }

    /**
     * How stale the oldest pending row may get before we call the queue stalled.
     *
     * @param int $interval Processing interval in seconds
     * @return int
     */
    private function getStallThreshold( $interval ) {
        return max( 3 * (int) $interval, 15 * MINUTE_IN_SECONDS );
    }

    /**
     * Age of the oldest pending row, in seconds, or null when nothing is pending.
     *
     * created_at is written with current_time('mysql'), i.e. site time, so it is
     * compared against current_time('timestamp') to stay in the same frame — the
     * way cleanupOldEvents() already does.
     *
     * @return int|null
     */
    private function getOldestPendingAge() {
        global $wpdb;

        if ( ! $this->tableExists() ) {
            return null;
        }

        $oldest = $wpdb->get_var( "SELECT MIN(created_at) FROM {$this->table_name} WHERE status = 'pending'" );

        if ( empty( $oldest ) ) {
            return null;
        }

        return max( 0, current_time( 'timestamp' ) - strtotime( $oldest ) );
    }

    /**
     * Drain a small batch on a front-end request when WP-Cron is clearly not running.
     *
     * Runs on 'shutdown', after the response has been handed to the visitor, so it
     * adds nothing to the page they waited for. Refuses to do anything when the
     * response cannot be detached — making a visitor wait for Meta or TikTok is the
     * problem this whole change set removed.
     *
     * This is a safety net, not a replacement for cron: it only fires while the
     * site gets traffic, and getCronHealth() reports whenever it has been used so
     * the underlying cron problem stays visible.
     */
    public function maybeSelfHeal() {

        if ( is_admin() || PHP_SAPI === 'cli' ) {
            return;
        }
        if ( function_exists( 'wp_doing_cron' ) && wp_doing_cron() ) {
            return; // cron is working here by definition
        }
        if ( defined( 'DOING_CRON' ) && DOING_CRON ) {
            return;
        }
        if ( ! self::isUsable() ) {
            return;
        }
        if ( ! function_exists( 'fastcgi_finish_request' ) && ! defined( 'PYS_RESPONSE_DETACHED' ) ) {
            return; // cannot detach, so we would be charging the visitor for this
        }

        $interval = max( 60, (int) PYS()->getOption( 'queue_processing_interval', 60 ) );

        // Autoloaded, so on a normal request this is served from cache and the
        // whole check costs nothing.
        $checked_at = (int) get_option( self::SELF_HEAL_CHECK_OPTION, 0 );
        if ( $checked_at && ( time() - $checked_at ) < $interval ) {
            return;
        }
        update_option( self::SELF_HEAL_CHECK_OPTION, time(), true );

        if ( get_transient( 'pys_queue_processing_lock' ) ) {
            return;
        }

        $age = $this->getOldestPendingAge();
        if ( $age === null || $age < $this->getStallThreshold( $interval ) ) {
            return; // nothing waiting, or cron is keeping up
        }

        PYS()->getLog()->debug( sprintf(
            'Queue looks stalled (oldest pending row is %ds old) — draining up to %d events on this request',
            $age, self::SELF_HEAL_BATCH
        ) );

        if ( ! defined( 'PYS_RESPONSE_DETACHED' ) && function_exists( 'fastcgi_finish_request' ) ) {
            fastcgi_finish_request();
            define( 'PYS_RESPONSE_DETACHED', true );
        }

        ignore_user_abort( true );
        if ( ! ini_get( 'safe_mode' ) ) {
            @set_time_limit( 60 );
        }

        update_option( self::SELF_HEAL_LAST_RUN_OPTION, time(), true );

        $this->processQueue( self::SELF_HEAL_BATCH, self::SELF_HEAL_TIME_BUDGET );
    }

    /**
     * Assess whether the queue is actually being drained.
     *
     * Since server-side events on the add-to-cart path go through the queue
     * instead of being sent inside the request, WP-Cron is the only thing that
     * delivers them. When it is not running, events pile up silently and are
     * eventually deleted by the pending cleanup — so this has to be visible.
     *
     * The strongest signal is not what WP thinks it scheduled, but the age of
     * the oldest pending row: if it is much older than the processing interval,
     * nothing is draining the queue whatever the schedule claims.
     *
     * @return array
     */
    public function getCronHealth() {
        global $wpdb;

        $interval = (int) PYS()->getOption( 'queue_processing_interval', 60 );
        if ( $interval < 60 ) {
            $interval = 60;
        }

        $next     = wp_next_scheduled( 'pys_process_events_queue' );
        $now      = time();
        $enabled  = (bool) PYS()->getOption( 'queue_enabled', true );

        $pending = 0;
        $failed  = 0;
        $oldest_age = null;

        if ( $this->tableExists() ) {
            $row = $wpdb->get_row(
                "SELECT
                    SUM(CASE WHEN status IN ('pending', 'processing') THEN 1 ELSE 0 END) AS pending,
                    SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) AS failed,
                    MIN(CASE WHEN status = 'pending' THEN created_at END) AS oldest
                 FROM {$this->table_name}"
            );

            $pending = (int) ( $row->pending ?? 0 );
            $failed  = (int) ( $row->failed ?? 0 );

            if ( ! empty( $row->oldest ) ) {
                // created_at is written with current_time('mysql'), i.e. site time;
                // comparing against current_time('timestamp') keeps both in the same
                // frame, the way cleanupOldEvents() already does.
                $oldest_age = max( 0, current_time( 'timestamp' ) - strtotime( $row->oldest ) );
            }
        }

        // A row older than a few intervals means nothing is processing the queue.
        $stall_threshold = $this->getStallThreshold( $interval );

        $level    = 'ok';
        $messages = array();

        $raise = function ( $new ) use ( &$level ) {
            if ( $new === 'error' || ( $new === 'warning' && $level === 'ok' ) ) {
                $level = $new;
            }
        };

        if ( ! $enabled ) {
            $messages[] = array(
                'level' => 'info',
                'text'  => __( 'The queue is disabled, so events are sent during the request instead. Nothing below applies.', 'pys' ),
            );

            return array(
                'level' => 'info', 'messages' => $messages, 'enabled' => false,
                'next_run' => $next, 'interval' => $interval, 'pending' => $pending,
                'failed' => $failed, 'oldest_pending_age' => $oldest_age,
                'disable_wp_cron' => defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON,
                'alternate_wp_cron' => defined( 'ALTERNATE_WP_CRON' ) && ALTERNATE_WP_CRON,
                'cleanup_days' => (int) PYS()->getOption( 'queue_pending_cleanup_days', 1 ),
            );
        }

        $schema_error = self::hasSchemaError() ? (string) get_option( self::SCHEMA_ERROR_OPTION, '' ) : '';
        if ( '' !== $schema_error ) {
            $raise( 'error' );
            $messages[] = array(
                'level' => 'error',
                'text'  => sprintf(
                    /* translators: %s: database error text */
                    __( 'The queue table could not be upgraded, so the queue is out of service and events are sent during the request instead: %s. The upgrade is retried once an hour; events already waiting are kept and delivered once it succeeds.', 'pys' ),
                    $schema_error
                ),
            );
        }

        if ( ! $next ) {
            $raise( 'error' );
            $messages[] = array(
                'level' => 'error',
                'text'  => __( 'The queue processing task is not scheduled, so no events are being delivered. Deactivating and reactivating the plugin re-creates the schedule.', 'pys' ),
            );
        } elseif ( $pending > 0 && $now - $next > 2 * $interval ) {
            // Only worth mentioning when something is actually waiting: on a
            // low-traffic site WP-Cron is often late with nothing to deliver,
            // and warning about that would be pure noise.
            $raise( 'warning' );
            $messages[] = array(
                'level' => 'warning',
                'text'  => sprintf(
                    /* translators: %s: human readable duration */
                    __( 'The queue task was due %s ago and has not run. WP-Cron only fires when someone visits the site — on low-traffic sites a real server cron is more reliable.', 'pys' ),
                    human_time_diff( $next, $now )
                ),
            );
        }

        if ( $oldest_age !== null && $oldest_age > $stall_threshold ) {
            $raise( 'error' );
            $messages[] = array(
                'level' => 'error',
                'text'  => sprintf(
                    /* translators: 1: number of events, 2: human readable duration */
                    __( 'The queue is not being processed: %1$d event(s) are waiting and the oldest has been pending for %2$s.', 'pys' ),
                    $pending,
                    human_time_diff( $now - $oldest_age, $now )
                ),
            );
        }

        $cleanup_days = (int) PYS()->getOption( 'queue_pending_cleanup_days', 1 );
        // Not while the schema error is set: the cleanup is paused then.
        if ( $level === 'error' && $pending > 0 && $cleanup_days > 0 && '' === $schema_error ) {
            $messages[] = array(
                'level' => 'warning',
                'text'  => sprintf(
                    /* translators: %d: number of days */
                    _n(
                        'Undelivered events are deleted after %d day, so this is losing data. Raise "Pending Events Cleanup Days" until the cause is fixed.',
                        'Undelivered events are deleted after %d days, so this is losing data. Raise "Pending Events Cleanup Days" until the cause is fixed.',
                        $cleanup_days, 'pys'
                    ),
                    $cleanup_days
                ),
            );
        }

        $max_size = (int) PYS()->getOption( 'queue_max_size', 10000 );
        if ( $max_size > 0 && $pending >= $max_size ) {
            $raise( 'error' );
            $messages[] = array(
                'level' => 'error',
                'text'  => __( 'The queue has reached its maximum size, so new events are being dropped instead of queued.', 'pys' ),
            );
        }

        // Self-healing must not hide the cause: if page requests are draining the
        // queue, cron is broken even though the backlog looks under control.
        $self_heal_last_run = (int) get_option( self::SELF_HEAL_LAST_RUN_OPTION, 0 );
        if ( $self_heal_last_run && ( $now - $self_heal_last_run ) < DAY_IN_SECONDS ) {
            $raise( 'warning' );
            $messages[] = array(
                'level' => 'warning',
                'text'  => sprintf(
                    /* translators: %s: human readable duration */
                    __( 'WP-Cron does not appear to be running: %s ago the queue had to be drained by a page request instead. That fallback only works while the site gets traffic, so the cron setup still needs fixing.', 'pys' ),
                    human_time_diff( $self_heal_last_run, $now )
                ),
            );
        }

        if ( defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ) {
            $raise( 'warning' );
            $messages[] = array(
                'level' => 'warning',
                'text'  => __( 'DISABLE_WP_CRON is enabled in wp-config.php. Event delivery depends entirely on the server cron that calls wp-cron.php — check that it is configured and running.', 'pys' ),
            );
        }

        if ( defined( 'ALTERNATE_WP_CRON' ) && ALTERNATE_WP_CRON ) {
            $messages[] = array(
                'level' => 'info',
                'text'  => __( 'ALTERNATE_WP_CRON is enabled: cron runs through a visitor redirect, which can be skipped by page caching.', 'pys' ),
            );
        }

        if ( $failed > 0 ) {
            $messages[] = array(
                'level' => 'info',
                'text'  => sprintf(
                    /* translators: %d: number of events */
                    __( '%d event(s) were rejected by a platform or ran out of retries. Open Recent Events to see the reason.', 'pys' ),
                    $failed
                ),
            );
        }

        if ( $level === 'ok' && empty( $messages ) ) {
            $messages[] = array(
                'level' => 'success',
                'text'  => $pending > 0
                    ? __( 'The queue is being processed normally.', 'pys' )
                    : __( 'The queue is empty and being processed normally.', 'pys' ),
            );
        }

        return array(
            'level'              => $level,
            'messages'           => $messages,
            'enabled'            => true,
            'next_run'           => $next,
            'interval'           => $interval,
            'pending'            => $pending,
            'failed'             => $failed,
            'oldest_pending_age' => $oldest_age,
            'disable_wp_cron'    => defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON,
            'alternate_wp_cron'  => defined( 'ALTERNATE_WP_CRON' ) && ALTERNATE_WP_CRON,
            'cleanup_days'       => $cleanup_days,
        );
    }

    /**
     * Manual queue processing (for AJAX)
     */
    public function processQueueManual() {
        check_ajax_referer( 'pys_save_settings', '_wpnonce' );
        if (!current_user_can('manage_options')) {
            wp_die('Insufficient permissions');
        }

        $this->processQueue();
        
        wp_send_json_success(array(
            'message' => 'Queue processing completed',
            'stats' => $this->getAllQueueStats()
        ));
    }

    /**
     * AJAX handler for queue cleanup
     */
    public function cleanupQueueAjax() {
        check_ajax_referer( 'pys_save_settings', '_wpnonce' );
        if (!current_user_can('manage_options')) {
            wp_die('Insufficient permissions');
        }

        $deleted = $this->cleanupOldEvents();
        
        wp_send_json_success(array(
            'message' => 'Cleanup completed',
            'deleted_count' => $deleted
        ));
    }

    /**
     * AJAX handler for queue statistics refresh
     */
    public function refreshQueueStatsAjax() {
        check_ajax_referer( 'pys_save_settings', '_wpnonce' );
        if (!current_user_can('manage_options')) {
            wp_die('Insufficient permissions');
        }

        $stats = $this->getAllQueueStats();

        wp_send_json_success($stats);
    }

    /**
     * AJAX handler for resetting failed events
     */
    public function resetFailedEventsAjax() {
        check_ajax_referer( 'pys_save_settings', '_wpnonce' );
        if (!current_user_can('manage_options')) {
            wp_die('Insufficient permissions');
        }

        global $wpdb;
        
        $updated = $wpdb->query($wpdb->prepare(
            "UPDATE {$this->table_name} SET status = %s, retry_count = 0, error_message = NULL WHERE status = %s",
            'pending', 'failed'
        ));

        // Clear cache when data changes
        $this->pending_count_cache = null;
        $this->clearStatsCache();

        wp_send_json_success(array(
            'message' => sprintf(__('Reset %d failed events to pending', 'pys'), $updated),
            'reset_count' => $updated
        ));
    }

    /**
     * Get last processed time
     */
    public function getLastProcessedTime() {
        global $wpdb;
        
        if (!$this->tableExists()) {
            return __('Never', 'pys');
        }
        
        $last_processed = $wpdb->get_var($wpdb->prepare(
            "SELECT MAX(processed_at) FROM {$this->table_name} WHERE status = %s AND processed_at IS NOT NULL",
            'processed'
        ));
        
        if ($last_processed) {
            // Use server time for formatting
            $timestamp = strtotime($last_processed);
            return date_i18n(get_option('date_format') . ' ' . get_option('time_format'), $timestamp);
        }
        
        return __('Never', 'pys');
    }

    /**
     * Get queue status
     */
    public function getQueueStatus() {
        $stats = $this->getAllQueueStats();
        
        if ($stats['pending'] > 100) {
            return 'overloaded';
        } elseif ($stats['pending'] > 0) {
            return 'processing';
        } else {
            return 'idle';
        }
    }

    /**
     * Get queue status text
     */
    public function getQueueStatusText() {
        $status = $this->getQueueStatus();
        
        switch ($status) {
            case 'overloaded':
                return __('Overloaded', 'pys');
            case 'processing':
                return __('Processing', 'pys');
            case 'idle':
            default:
                return __('Idle', 'pys');
        }
    }

    /**
     * Get processing rate (events per minute)
     */
    public function getProcessingRate() {
        global $wpdb;
        
        if (!$this->tableExists()) {
            return '0';
        }

        // Get WordPress time one hour ago
        $one_hour_ago = date('Y-m-d H:i:s', current_time('timestamp') - HOUR_IN_SECONDS);

        // Get events processed in the last hour
        $processed_last_hour = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$this->table_name} WHERE status = %s AND processed_at >= %s",
            'processed', $one_hour_ago
        ));

        return round($processed_last_hour / 60, 1);
    }

    /**
     * Get success rate percentage
     */
    public function getSuccessRate() {
        global $wpdb;
        
        if (!$this->tableExists()) {
            return '100';
        }
        
        $total_processed = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$this->table_name} WHERE status IN (%s, %s)",
            'processed', 'failed'
        ));
        
        if ($total_processed == 0) {
            return '100';
        }
        
        $successful = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$this->table_name} WHERE status = %s",
            'processed'
        ));
        
        return round(($successful / $total_processed) * 100, 1);
    }

    /**
     * Deactivate queue system
     */
    public function deactivate() {
        // Remove scheduled tasks
        wp_clear_scheduled_hook('pys_process_events_queue');
        wp_clear_scheduled_hook('pys_cleanup_events_queue');

        // Autoloaded markers: no reason to keep them in alloptions.
        delete_option(self::SELF_HEAL_CHECK_OPTION);
        delete_option(self::SELF_HEAL_LAST_RUN_OPTION);
        delete_option(self::SCHEMA_ERROR_OPTION);
        delete_transient(self::SCHEMA_RETRY_TRANSIENT);

        // Drop table (optional)
        if (PYS()->getOption('queue_drop_table_on_deactivate', false)) {
            global $wpdb;
            $wpdb->query("DROP TABLE IF EXISTS {$this->table_name}");
            delete_option('pys_queue_db_version');
        }
    }
}

/**
 * Add interval for WP Cron
 */
add_filter('cron_schedules', function($schedules) {
    // Fallback matches options_defaults.json ("queue_processing_interval": 60).
    // It used to be 300 here, so an install whose stored options predate the key
    // got a five-minute schedule while the UI showed one minute.
    $schedules['pys_queue_interval'] = array(
        'interval' => max(60, (int) PYS()->getOption('queue_processing_interval', 60)),
        'display' => __('PixelYourSite Queue Interval', 'pys')
    );
    return $schedules;
});

/**
 * @return EventsQueue
 */
function EventsQueue() {
    return EventsQueue::instance();
}
