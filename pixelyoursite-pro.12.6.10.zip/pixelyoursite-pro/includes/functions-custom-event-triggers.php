<?php

namespace PixelYourSite;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Order parameters asked for by a custom event's WooCommerce purchase trigger.
 *
 * The purchase trigger carries two switches, "Track value and currency" and
 * "Track transaction ID". Every sender that builds a custom event reads them here
 * so the Google Ads conversion, the GA4 event, the GTM data layer and the Meta
 * event all carry the same value, currency and transaction_id for the same order.
 *
 * @param CustomEvent   $customEvent The event being built.
 * @param callable|null $get_order   Returns the order on this page, or false. Defaults to
 *                                   EventsWoo()->getOrder(); tests pass a stub.
 *
 * @return array Subset of value / currency / transaction_id, or [] when the event has no
 *               purchase trigger, both switches are off, or there is no order.
 */
function getCustomEventPurchaseTriggerParams( $customEvent, $get_order = null ) {

	$purchase_trigger = null;
	foreach ( $customEvent->getTriggers() as $trigger ) {
		if ( $trigger->getTriggerType() === 'purchase' ) {
			$purchase_trigger = $trigger;
			break;
		}
	}
	if ( ! $purchase_trigger ) {
		return array();
	}

	$track_value = (bool) $purchase_trigger->getTrackValueAndCurrency();
	$track_id    = (bool) $purchase_trigger->getTrackTransactionID();
	if ( ! $track_value && ! $track_id ) {
		return array();
	}

	$order = $get_order ? call_user_func( $get_order ) : EventsWoo()->getOrder();
	if ( ! $order ) {
		return array();
	}

	$params = array();
	if ( $track_value ) {
		$params['value']    = $order->get_total();
		$params['currency'] = $order->get_currency();
	}
	if ( $track_id ) {
		$params['transaction_id'] = wooMapOrderId( $order->get_id() );
	}

	return $params;
}

/**
 * One custom-parameter row of a custom event, as the admin form, the EST and the MCP
 * ability post it: {name, value, selector?, dynamic?}.
 *
 * A static row needs a value. A dynamic row reads the page through its selector and may
 * leave the value empty — the form hides the value input when "Use dynamic value from
 * page" is ticked, and the row used to be dropped on save for that (task 44417493).
 *
 * @param mixed $row
 * @return array|null Sanitised {name, value, selector?, dynamic?}, or null to skip the row.
 */
function sanitizeCustomEventCustomParam( $row ) {

	if ( ! is_array( $row ) ) {
		return null;
	}

	$name     = isset( $row['name'] ) ? sanitize_text_field( $row['name'] ) : '';
	$value    = isset( $row['value'] ) ? sanitize_text_field( $row['value'] ) : '';
	$selector = isset( $row['selector'] ) ? sanitize_text_field( $row['selector'] ) : '';
	$dynamic  = ! empty( $row['dynamic'] );

	if ( $name === '' ) {
		return null;
	}

	if ( $value === '' && ! ( $dynamic && $selector !== '' ) ) {
		return null;
	}

	$param = array(
		'name'  => $name,
		'value' => $value,
	);

	if ( $selector !== '' ) {
		$param['selector'] = $selector;
	}

	// The checkbox is only posted when ticked; keep the key only when it was posted.
	if ( array_key_exists( 'dynamic', $row ) ) {
		$param['dynamic'] = $dynamic;
	}

	return $param;
}
