/**
 * Ambient types for the components this island consumes from
 * @thrive-themes/ui-components (#4047).
 *
 * DO NOT DELETE THIS FILE without re-running the measurement below. It looks
 * like dead weight and is not: on the pnpm install path, which is the one the
 * release pipeline and every local checkout use, removing it takes the island
 * from 0 type errors to 8 (TS7016 on each library import, then cascading
 * implicit-any on every callback parameter). Verified 2026-08-28 on the
 * develop merge (#3535).
 *
 * Why it is load-bearing, precisely:
 *
 * - The library's package.json declares `types: "dist/index.d.ts"`, but its
 *   webpack build is babel-only with no declaration emit, so dist/ contains
 *   just main.js. That advertised .d.ts has never existed. This is a defect in
 *   the library, tracked to go upstream; when the library really does emit
 *   declarations, delete this file.
 * - The library's package.json also sets `files: ["dist", "src"]`, which
 *   EXCLUDES its root index.tsx barrel.
 * - pnpm installs a `file:` dependency as a COPY honouring that allowlist. So
 *   index.tsx is absent from the installed copy, TypeScript falls back to
 *   `dist/main.js`, finds no declarations, and every import is an error.
 * - npm installs the same `file:` dependency as a SYMLINK, so index.tsx IS
 *   visible and TypeScript resolves real types from the library's source. That
 *   is why this file looks unnecessary if you only ever measure under npm -
 *   and measuring under npm is what nearly got it deleted during the develop
 *   merge.
 *
 * Each signature below mirrors the package source
 * (src/components/{Modal,Button,Input,Select}) - keep them in sync when the
 * library's props change.
 */
declare module '@thrive-themes/ui-components' {
	import type { ReactNode, HTMLAttributes, ButtonHTMLAttributes, InputHTMLAttributes } from 'react';

	export interface ModalProps extends HTMLAttributes<HTMLDivElement> {
		open: boolean;
		onClose: () => void;
		children: ReactNode;
		container?: Element | null;
		size?: 'sm' | 'md' | 'lg';
	}

	export interface ModalSectionProps extends HTMLAttributes<HTMLDivElement> {
		children: ReactNode;
		className?: string;
	}

	export const Modal: React.FC<ModalProps> & {
		Header: React.FC<ModalSectionProps & { closeButton?: ReactNode }>;
		Body: React.FC<ModalSectionProps>;
		Footer: React.FC<ModalSectionProps>;
	};

	export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
		children: ReactNode;
		size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
		fullWidth?: boolean;
		variant?: 'solid' | 'outline' | 'text' | 'surface' | 'surfaceSecondary';
		color?: 'primary' | 'neutral' | 'danger' | 'success';
		rounded?: boolean;
		iconOnly?: boolean;
		loading?: boolean;
		inactive?: boolean;
	}

	export const Button: React.FC<ButtonProps>;

	interface InputBaseProps {
		label?: ReactNode;
		status?: 'default' | 'success' | 'error';
		errorMessage?: string;
		icon?: ReactNode;
		iconPosition?: 'left' | 'right';
		iconSeparator?: boolean;
		value?: string;
		onChange?: ( value: string ) => void;
	}

	export interface InputProps
		extends InputBaseProps,
			Omit<InputHTMLAttributes<HTMLInputElement>, 'onChange' | 'value' | 'size'> {
		as: 'input';
		type?: string;
		size?: 'md' | 'lg' | 'xl';
	}

	export const Input: React.FC<InputProps>;

	export interface NumberInputProps
		extends Omit<InputProps, 'as' | 'onChange' | 'value' | 'type'> {
		value?: string | number;
		onChange?: ( value: string ) => void;
		allowDecimals?: boolean;
		min?: number;
		max?: number;
		step?: number;
	}

	export const NumberInput: React.FC<NumberInputProps>;

	export interface SelectProps extends Omit<HTMLAttributes<HTMLDivElement>, 'onChange' | 'prefix'> {
		options: string[];
		multiple?: boolean;
		placeholder?: string;
		label?: string;
		value: string[];
		onChange: ( selected: string[] ) => void;
		disabled?: boolean;
		prefix?: ReactNode;
		variant?: 'input' | 'text';
		size?: 'md' | 'lg' | 'xl';
		reverseArrow?: boolean;
	}

	export const Select: React.FC<SelectProps>;

	/** The library's icon-name union; the island never renders library icons
	 * (it uses the design's brand PNGs), so a widened alias is enough here. */
	export type IconName = string;
}
