/**
 * The email-tag configure form (#4058): ESP select → mailing list (+ refresh)
 * → multi-tag chip input with provider-inventory autocomplete. Ported 1:1
 * from the Apprentice Triggers dev handoff (index.html `data-config=
 * "email_tag"`, prototype.js commitTag/renderTagAutocomplete). Renders only
 * when the host supplies the ESP adapter trio - see
 * `ConfiguratorAdapters.getEspOptions`.
 *
 * Wire shape (matches the TQB #4068 convention, so the shared
 * `TTA_Email_Tag_Action` executor runs unchanged): the chips join into
 * `config.target.id`/`label` as a `', '`-separated string - one
 * `update_tags()` call sends every tag - and the picks land in
 * `config.extra.autoresponder` / `config.extra.list_identifier`, with
 * `_label` twins carried for the saved-row summary.
 */
import { useEffect, useMemo, useRef, useState } from 'react';
import type { ClipboardEvent, Dispatch, KeyboardEvent, SetStateAction } from 'react';
import { __, sprintf } from '@wordpress/i18n';
import { Select } from '@thrive-themes/ui-components';
import type { ActionConfig, ConfiguratorAdapters, TargetOption } from './types';

/** Which required field failed validation - owned by the parent's save(). */
export type EmailTagErrorField = 'esp' | 'list' | 'tags';

/** extra values are strings for this form; the webhook rows (KvRow[]) never appear under its keys. */
function extraString ( value: string | { key: string; value: string }[] | undefined ): string {
	return typeof value === 'string' ? value : '';
}

/** The parsed chip list - `', '` join/split is the storage convention. */
export function splitTags ( id: string | number | null | undefined ): string[] {
	return String( id ?? '' )
		.split( ',' )
		.map( ( t ) => t.trim() )
		.filter( Boolean );
}

/**
 * Saved-summary line per the handoff ("Tag enrolled-photo, paid-customer in
 * ActiveCampaign (Main list)") - shared by the configurator's live preview
 * and the host's saved-row summary so the two can never drift. Null while no
 * tag is committed yet, so callers keep their own fallback.
 */
export function emailTagSummary ( config: ActionConfig ): string | null {
	const tags = splitTags( config.target?.id );
	if ( ! tags.length ) {
		return null;
	}
	const joined = tags.join( ', ' );
	const espLabel = extraString( config.extra?.autoresponder_label );
	const listLabel = extraString( config.extra?.list_label );
	if ( espLabel && listLabel ) {
		/* translators: 1: the tag names, 2: the email service, 3: the mailing list */
		return sprintf( __( 'Tag %1$s in %2$s (%3$s)', 'thrive-cb' ), joined, espLabel, listLabel );
	}
	if ( espLabel ) {
		/* translators: 1: the tag names, 2: the email service */
		return sprintf( __( 'Tag %1$s in %2$s', 'thrive-cb' ), joined, espLabel );
	}
	/* translators: %s: the tag names */
	return sprintf( __( 'Tag %s', 'thrive-cb' ), joined );
}

const MAX_SUGGESTIONS = 8;

export default function EmailTagFields ( {
	config,
	setConfig,
	adapters,
	errorField,
	clearError,
	onToast,
}: {
	config: ActionConfig;
	setConfig: Dispatch<SetStateAction<ActionConfig>>;
	adapters: ConfiguratorAdapters;
	/** Field flagged by the parent's save-time validation, or null. */
	errorField: EmailTagErrorField | null;
	/** Any user input on a flagged field clears the flag. */
	clearError: () => void;
	onToast?: ( message: string, kind?: 'error' | 'success' ) => void;
} ) {
	const esp = extraString( config.extra?.autoresponder );
	const list = extraString( config.extra?.list_identifier );
	const tags = useMemo( () => splitTags( config.target?.id ), [ config.target ] );

	const [ espOptions, setEspOptions ] = useState<TargetOption[]>( [] );
	const [ espLoading, setEspLoading ] = useState( true );
	const [ lists, setLists ] = useState<TargetOption[]>( [] );
	const [ listsLoading, setListsLoading ] = useState( false );
	const [ listsError, setListsError ] = useState( false );
	const [ listsRetry, setListsRetry ] = useState( 0 );
	const [ refreshing, setRefreshing ] = useState( false );
	const [ inventory, setInventory ] = useState<string[]>( [] );
	/* Bumped by a successful list refresh so the inventory effect re-runs even
	 * though the (esp, list) picks are unchanged - the refresh cleared the
	 * host's tag cache, and stale suggestions would defeat its purpose. */
	const [ inventoryNonce, setInventoryNonce ] = useState( 0 );

	const [ query, setQuery ] = useState( '' );
	const [ acOpen, setAcOpen ] = useState( false );
	const [ acIndex, setAcIndex ] = useState( -1 );
	/* Bumped on a duplicate commit so the existing chip remounts and its pop
	 * animation replays - the prototype's "flash" (prototype.js commitTag). */
	const [ flash, setFlash ] = useState<{ tag: string; nonce: number } | null>( null );

	const espFieldRef = useRef<HTMLDivElement>( null );
	const listFieldRef = useRef<HTMLDivElement>( null );
	const chipFieldRef = useRef<HTMLDivElement>( null );
	const inputRef = useRef<HTMLInputElement>( null );

	/* Connected tag-capable ESPs - loaded once per mount. */
	useEffect( () => {
		let alive = true;
		adapters.getEspOptions?.()
			.then( ( options ) => {
				if ( alive ) {
					setEspOptions( options );
				}
			} )
			.catch( () => {
				/* Free typing still works without the select being populated;
				 * validation catches the missing pick. */
			} )
			.finally( () => {
				if ( alive ) {
					setEspLoading( false );
				}
			} );
		return () => {
			alive = false;
		};
	}, [ adapters ] );

	/* Mailing lists follow the ESP pick (and rehydrate a saved edit). */
	useEffect( () => {
		if ( ! esp ) {
			setLists( [] );
			setListsError( false );
			return;
		}
		let alive = true;
		setListsLoading( true );
		setListsError( false );
		adapters.getEspLists?.( esp )
			.then( ( options ) => {
				if ( alive ) {
					setLists( options );
				}
			} )
			.catch( () => {
				/* Distinct from a genuine empty list - the field shows the same
				 * fetch-error + Retry treatment the target picker uses. */
				if ( alive ) {
					setLists( [] );
					setListsError( true );
				}
			} )
			.finally( () => {
				if ( alive ) {
					setListsLoading( false );
				}
			} );
		return () => {
			alive = false;
		};
	}, [ esp, adapters, listsRetry ] );

	/* Tag inventory for the autocomplete - re-read when the ESP (or, on
	 * per-list providers, the list) changes. Empty inventory is fine: the
	 * dropdown then only offers the "create" hint. */
	useEffect( () => {
		if ( ! esp ) {
			setInventory( [] );
			return;
		}
		let alive = true;
		adapters.getEspTags?.( esp, list || undefined )
			.then( ( names ) => {
				if ( alive ) {
					setInventory( names );
				}
			} )
			.catch( () => {
				if ( alive ) {
					setInventory( [] );
				}
			} );
		return () => {
			alive = false;
		};
	}, [ esp, list, adapters, inventoryNonce ] );

	/* Save-time validation flagged a field: focus it (prototype scroll+focus). */
	useEffect( () => {
		if ( ! errorField ) {
			return;
		}
		const wrap = errorField === 'esp' ? espFieldRef.current : errorField === 'list' ? listFieldRef.current : chipFieldRef.current;
		const focusable = errorField === 'tags'
			? inputRef.current
			: wrap?.querySelector<HTMLElement>( 'input, button, select, [tabindex]' );
		wrap?.scrollIntoView( { behavior: 'smooth', block: 'center' } );
		focusable?.focus();
	}, [ errorField ] );

	const writeTags = ( next: string[] ) => {
		const joined = next.join( ', ' );
		setConfig( ( c ) => ( { ...c, target: next.length ? { id: joined, label: joined } : null } ) );
	};

	const pickEsp = ( picked: TargetOption | null ) => {
		clearError();
		setConfig( ( c ) => ( {
			...c,
			extra: {
				...c.extra,
				autoresponder: picked ? String( picked.id ) : '',
				autoresponder_label: picked?.label ?? '',
				/* A different provider has different lists - reset (prototype
				 * populateEmailLists). */
				list_identifier: '',
				list_label: '',
			},
		} ) );
	};

	const pickList = ( picked: TargetOption | null ) => {
		clearError();
		setConfig( ( c ) => ( {
			...c,
			extra: {
				...c.extra,
				list_identifier: picked ? String( picked.id ) : '',
				list_label: picked?.label ?? '',
			},
		} ) );
	};

	const refreshLists = () => {
		if ( ! esp || refreshing ) {
			return;
		}
		setRefreshing( true );
		adapters.getEspLists?.( esp, true )
			.then( ( options ) => {
				setLists( options );
				setListsError( false );
				/* Keep the pick when the provider still has it; drop it otherwise. */
				if ( list && ! options.some( ( o ) => String( o.id ) === list ) ) {
					pickList( null );
				}
				/* The forced fetch also cleared the host's tag cache - reload the
				 * autocomplete inventory along with the lists. */
				setInventoryNonce( ( n ) => n + 1 );
				onToast?.( __( 'Refreshed — pulled the latest mailing lists from your provider.', 'thrive-cb' ), 'success' );
			} )
			.catch( () => {
				onToast?.( __( "Couldn't refresh the mailing lists - the request failed.", 'thrive-cb' ) );
			} )
			.finally( () => setRefreshing( false ) );
	};

	/* ---- chips ---------------------------------------------------------- */

	const commitTag = ( raw: string ): boolean => {
		const tag = raw.trim().replace( /,$/, '' );
		if ( ! tag ) {
			return false;
		}
		clearError();
		const lc = tag.toLowerCase();
		const dupe = tags.find( ( t ) => t.toLowerCase() === lc );
		if ( dupe ) {
			/* Case-insensitive dedup: flash the existing chip, add nothing. */
			setFlash( ( f ) => ( { tag: dupe, nonce: ( f?.nonce ?? 0 ) + 1 } ) );
			return false;
		}
		writeTags( [ ...tags, tag ] );
		return true;
	};

	const removeTag = ( tag: string ) => {
		clearError();
		writeTags( tags.filter( ( t ) => t !== tag ) );
	};

	const closeAc = () => {
		setAcOpen( false );
		setAcIndex( -1 );
	};

	const suggestions = useMemo( () => {
		const q = query.trim().toLowerCase();
		if ( ! q ) {
			return [];
		}
		const used = new Set( tags.map( ( t ) => t.toLowerCase() ) );
		return inventory
			.filter( ( t ) => ! used.has( t.toLowerCase() ) )
			.filter( ( t ) => t.toLowerCase().includes( q ) )
			.slice( 0, MAX_SUGGESTIONS );
	}, [ query, tags, inventory ] );

	const onInput = ( value: string ) => {
		setQuery( value );
		setAcOpen( value.trim().length > 0 );
		setAcIndex( value.trim() && suggestionsFor( value, tags, inventory ).length ? 0 : -1 );
	};

	const commitFromInput = () => {
		/* A highlighted suggestion wins; otherwise the typed value commits
		 * (prototype.js keydown handler). */
		if ( acOpen && acIndex >= 0 && suggestions[ acIndex ] ) {
			if ( commitTag( suggestions[ acIndex ] ) ) {
				setQuery( '' );
				closeAc();
			}
			return;
		}
		commitTag( query );
		setQuery( '' );
		closeAc();
	};

	const onKeyDown = ( event: KeyboardEvent<HTMLInputElement> ) => {
		if ( event.key === 'Enter' || event.key === ',' ) {
			event.preventDefault();
			commitFromInput();
		} else if ( event.key === 'ArrowDown' && acOpen && suggestions.length ) {
			event.preventDefault();
			setAcIndex( ( i ) => ( i + 1 + suggestions.length ) % suggestions.length );
		} else if ( event.key === 'ArrowUp' && acOpen && suggestions.length ) {
			event.preventDefault();
			setAcIndex( ( i ) => ( i - 1 + suggestions.length ) % suggestions.length );
		} else if ( event.key === 'Escape' && acOpen ) {
			event.preventDefault();
			closeAc();
		} else if ( event.key === 'Backspace' && ! query ) {
			/* Backspace on an empty input pops the last chip. */
			writeTags( tags.slice( 0, -1 ) );
		}
	};

	const onPaste = ( event: ClipboardEvent<HTMLInputElement> ) => {
		const text = event.clipboardData.getData( 'text' );
		if ( ! text.includes( ',' ) ) {
			return;
		}
		event.preventDefault();
		/* Accumulate into ONE next array and write once - a commitTag() per
		 * part would close over the same pre-paste `tags`, and the queued
		 * writes would clobber each other, keeping only the LAST pasted tag.
		 * Dedup is case-insensitive against existing chips and within the
		 * pasted text itself. */
		const next = [ ...tags ];
		const seen = new Set( next.map( ( t ) => t.toLowerCase() ) );
		text.split( ',' ).forEach( ( part ) => {
			const tag = part.trim().replace( /,$/, '' );
			if ( tag && ! seen.has( tag.toLowerCase() ) ) {
				seen.add( tag.toLowerCase() );
				next.push( tag );
			}
		} );
		if ( next.length !== tags.length ) {
			clearError();
			writeTags( next );
		}
		setQuery( '' );
		closeAc();
	};

	/* Click-outside closes the dropdown (prototype's document handler). */
	useEffect( () => {
		if ( ! acOpen ) {
			return;
		}
		const onDocClick = ( event: MouseEvent ) => {
			if ( ! chipFieldRef.current?.contains( event.target as Node ) ) {
				closeAc();
			}
		};
		document.addEventListener( 'click', onDocClick );
		return () => document.removeEventListener( 'click', onDocClick );
	}, [ acOpen ] );

	/* Label-keyed Select mapping with the same duplicate-label disambiguation
	 * the target picker uses (two lists can share a name). */
	const displaysFor = ( options: TargetOption[] ) => {
		const counts = new Map<string, number>();
		options.forEach( ( o ) => counts.set( o.label, ( counts.get( o.label ) ?? 0 ) + 1 ) );
		return options.map( ( o ) => ( ( counts.get( o.label ) ?? 0 ) > 1 ? `${ o.label } (ID ${ o.id })` : o.label ) );
	};
	const espDisplays = displaysFor( espOptions );
	const listDisplays = displaysFor( lists );
	const selectedEspIndex = espOptions.findIndex( ( o ) => String( o.id ) === esp );
	const selectedListIndex = lists.findIndex( ( o ) => String( o.id ) === list );
	/* A saved pick whose provider was disconnected (or list deleted) since is
	 * no longer among the options - display its stored label rather than a
	 * placeholder implying nothing is saved, mirroring displayForTarget()'s
	 * stale-target fallback in the generic picker. */
	const savedEspLabel = extraString( config.extra?.autoresponder_label );
	const savedListLabel = extraString( config.extra?.list_label );
	const espValue = selectedEspIndex >= 0
		? [ espDisplays[ selectedEspIndex ] ]
		: ( esp && savedEspLabel ? [ savedEspLabel ] : [] );
	const listValue = selectedListIndex >= 0
		? [ listDisplays[ selectedListIndex ] ]
		: ( list && savedListLabel ? [ savedListLabel ] : [] );

	return (
		<>
			<div className={ `tta-cfg-field${ errorField === 'esp' ? ' is-error' : '' }` } ref={ espFieldRef }>
				<label className="tta-cfg-label">{ __( 'Email service provider', 'thrive-cb' ) }</label>
				<Select
					label=""
					options={ espDisplays }
					value={ espValue }
					placeholder={ espLoading ? __( 'Loading…', 'thrive-cb' ) : __( 'Select an email service provider…', 'thrive-cb' ) }
					disabled={ espLoading }
					onChange={ ( selected ) => {
						const index = espDisplays.indexOf( selected[ 0 ] ?? '' );
						pickEsp( index >= 0 ? espOptions[ index ] : null );
					} }
				/>
			</div>

			<div className={ `tta-cfg-field${ errorField === 'list' ? ' is-error' : '' }` } ref={ listFieldRef }>
				<label className="tta-cfg-label">{ __( 'Choose your mailing list', 'thrive-cb' ) }</label>
				<div className="tta-cfg-list-row">
					{ listsError && (
						<div className="tta-cfg-fetch-error" role="alert">
							<span>{ __( "Couldn't load the options - the request failed.", 'thrive-cb' ) }</span>
							<button type="button" className="tta-cfg-retry" onClick={ () => setListsRetry( ( n ) => n + 1 ) }>
								{ __( 'Retry', 'thrive-cb' ) }
							</button>
						</div>
					) }
					{ ! listsError && <Select
						label=""
						options={ listDisplays }
						value={ listValue }
						placeholder={
							! esp
								? __( 'Pick an email service provider first', 'thrive-cb' )
								: listsLoading ? __( 'Loading…', 'thrive-cb' ) : __( 'Select a mailing list…', 'thrive-cb' )
						}
						disabled={ ! esp || listsLoading }
						onChange={ ( selected ) => {
							const index = listDisplays.indexOf( selected[ 0 ] ?? '' );
							pickList( index >= 0 ? lists[ index ] : null );
						} }
					/> }
					<button
						type="button"
						className={ `tta-cfg-list-refresh${ refreshing ? ' is-spinning' : '' }` }
						title={ __( 'Refresh mailing lists', 'thrive-cb' ) }
						aria-label={ __( 'Refresh mailing lists', 'thrive-cb' ) }
						disabled={ ! esp || refreshing }
						onClick={ refreshLists }
					>
						<svg viewBox="0 0 24 24" aria-hidden="true">
							<path d="M21 12a9 9 0 1 1-2.64-6.36M21 3v6h-6" stroke="currentColor" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round" />
						</svg>
					</button>
				</div>
			</div>

			<div className={ `tta-cfg-field${ errorField === 'tags' ? ' is-error' : '' }` }>
				<label className="tta-cfg-label" htmlFor="tta-cfg-tag-input">{ __( 'Tags', 'thrive-cb' ) }</label>
				{ /* The whole box focuses the input - it reads as one text field. */ }
				{ /* eslint-disable-next-line jsx-a11y/click-events-have-key-events, jsx-a11y/no-static-element-interactions */ }
				<div className="tta-cfg-tag-input" ref={ chipFieldRef } onClick={ () => inputRef.current?.focus() }>
					<div className="tta-cfg-tag-chips">
						{ tags.map( ( tag ) => (
							<span
								className="tta-cfg-tag-chip"
								key={ flash?.tag === tag ? `${ tag }#${ flash.nonce }` : tag }
							>
								{ tag }
								<button
									type="button"
									className="tta-cfg-tag-chip__x"
									aria-label={ sprintf( /* translators: %s: the tag being removed */ __( 'Remove tag %s', 'thrive-cb' ), tag ) }
									onClick={ ( event ) => {
										event.stopPropagation();
										removeTag( tag );
									} }
								>
									×
								</button>
							</span>
						) ) }
					</div>
					<input
						id="tta-cfg-tag-input"
						ref={ inputRef }
						type="text"
						value={ query }
						placeholder={ __( 'Type a tag and press Enter…', 'thrive-cb' ) }
						autoComplete="off"
						role="combobox"
						aria-autocomplete="list"
						aria-expanded={ acOpen }
						aria-controls="tta-cfg-tag-listbox"
						aria-activedescendant={ acOpen && acIndex >= 0 ? `tta-cfg-tag-opt-${ acIndex }` : undefined }
						onChange={ ( event ) => onInput( event.target.value ) }
						onKeyDown={ onKeyDown }
						onPaste={ onPaste }
					/>
					{ acOpen && (
						<div className="tta-cfg-tag-autocomplete" id="tta-cfg-tag-listbox" role="listbox">
							{ ! esp && (
								<div className="tta-cfg-tag-autocomplete__empty">
									{ sprintf(
										/* translators: %s: the typed tag */
										__( 'Pick an email service provider above to see existing tags. Press Enter to add "%s" as a new tag.', 'thrive-cb' ),
										query.trim()
									) }
								</div>
							) }
							{ esp && suggestions.length === 0 && (
								<div className="tta-cfg-tag-autocomplete__empty">
									{ sprintf(
										/* translators: %s: the typed tag */
										__( 'No matching tags in your connected provider. Press Enter to create "%s".', 'thrive-cb' ),
										query.trim()
									) }
								</div>
							) }
							{ esp && suggestions.map( ( tag, index ) => (
								<button
									key={ tag }
									id={ `tta-cfg-tag-opt-${ index }` }
									type="button"
									role="option"
									aria-selected={ index === acIndex }
									className={ `tta-cfg-tag-autocomplete__item${ index === acIndex ? ' is-active' : '' }` }
									onClick={ () => {
										if ( commitTag( tag ) ) {
											setQuery( '' );
											closeAc();
											inputRef.current?.focus();
										}
									} }
								>
									<code>{ tag }</code>
									<span>{ __( 'existing', 'thrive-cb' ) }</span>
								</button>
							) ) }
						</div>
					) }
				</div>
				<div className="tta-cfg-tag-help">{ __( 'Press Enter or comma to add a tag. All tags are sent in a single API call.', 'thrive-cb' ) }</div>
			</div>
		</>
	);
}

/* Pure twin of the `suggestions` memo for the synchronous highlight decision
 * inside onInput (state updates in the same tick can't read the memo). */
function suggestionsFor ( value: string, tags: string[], inventory: string[] ): string[] {
	const q = value.trim().toLowerCase();
	if ( ! q ) {
		return [];
	}
	const used = new Set( tags.map( ( t ) => t.toLowerCase() ) );
	return inventory.filter( ( t ) => ! used.has( t.toLowerCase() ) && t.toLowerCase().includes( q ) ).slice( 0, MAX_SUGGESTIONS );
}
