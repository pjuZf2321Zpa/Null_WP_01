/**
 * The condition operators' human labels - one source for the configure step,
 * the saved card and the Submission Log (#4052 QA: the card said "not
 * equals" where the dropdown and the log said "does not equal").
 *
 * Which operators a field offers, and how they read, follow its type (#4052,
 * approved by Saif): a checkbox group can have several options ticked, so its
 * `equals` / `not_equals` read "includes" / "does not include" (any ticked
 * option matches / none does - what tta_evaluate() already does for lists);
 * fields with a fixed set of options drop "contains", which could match the
 * wrong option ("Option A" inside "Option AB"). The stored op never changes.
 * Hosts that send no `fieldType` (Apprentice Triggers) keep all three
 * operators with the plain labels.
 */
import { __ } from '@wordpress/i18n';
import type { ConditionConfig } from './types';

/** Field types whose value is one of a fixed set of options. */
const OPTION_FIELD_TYPES = [ 'checkbox', 'radio', 'dropdown' ];

export function conditionOpLabel( op: ConditionConfig[ 'op' ] | string, fieldType?: string ): string {
	if ( fieldType === 'checkbox' ) {
		if ( op === 'equals' ) {
			return __( 'includes', 'thrive-cb' );
		}
		if ( op === 'not_equals' ) {
			return __( 'does not include', 'thrive-cb' );
		}
	}
	switch ( op ) {
		case 'equals':
			return __( 'equals', 'thrive-cb' );
		case 'not_equals':
			return __( 'does not equal', 'thrive-cb' );
		case 'contains':
			return __( 'contains', 'thrive-cb' );
		default:
			return String( op );
	}
}

export const CONDITION_OP_VALUES: ConditionConfig[ 'op' ][] = [ 'equals', 'not_equals', 'contains' ];

/** The operators a field of this type offers for a new rule. */
export function conditionOpsFor( fieldType?: string ): ConditionConfig[ 'op' ][] {
	return fieldType && OPTION_FIELD_TYPES.includes( fieldType ) ? [ 'equals', 'not_equals' ] : CONDITION_OP_VALUES;
}
