import { act, fireEvent } from '@testing-library/react';
import {
	advancedPanel,
	baseConfig,
	cardByTitle,
	installFrameQueue,
	renderConfigurator,
} from '../test/configuratorFixture';

describe( 'ActionConfigurator revealAdvanced() (#4061 review)', () => {
	let frames: ReturnType<typeof installFrameQueue>;

	beforeEach( () => {
		frames = installFrameQueue();
		( Element.prototype.scrollIntoView as ReturnType<typeof vi.fn> ).mockClear();
	} );

	afterEach( () => {
		frames.restore();
	} );

	test.each( [
		[ 'condition', 'Add a condition' ],
		[ 'timing', 'Time delay' ],
	] as [ 'timing' | 'condition', string ][] )( 'revealAdvanced( %j ) opens the panel and scrolls that card after two frames', async ( card, title ) => {
		/* No timing, no condition in value: the panel starts closed. */
		const { ref, onToast, container } = await renderConfigurator( baseConfig() );
		expect( advancedPanel( container ).open ).toBe( false );

		act( () => {
			ref.current?.revealAdvanced( card );
		} );

		expect( advancedPanel( container ).open ).toBe( true );
		expect( onToast ).not.toHaveBeenCalled();

		const scroll = Element.prototype.scrollIntoView as ReturnType<typeof vi.fn>;
		frames.flush();
		expect( scroll ).not.toHaveBeenCalled();
		frames.flush();
		expect( scroll ).toHaveBeenCalledTimes( 1 );
		expect( scroll.mock.contexts[ 0 ] ).toBe( cardByTitle( container, title ) );
	} );

	// Locks the onToggle guard as a whole, not the openedBySaveRef term specifically:
	// by the time the toggle event is dispatched, advancedOpen is already true.
	test( "a programmatic open scrolls only the card; the panel's own summary scroll stays quiet", async () => {
		const { ref, container } = await renderConfigurator( baseConfig() );
		act( () => {
			ref.current?.revealAdvanced( 'timing' );
		} );

		/* jsdom does not fire `toggle` on a programmatic `open` change the way
		 * a browser does, so dispatch it by hand to run the handler's guard
		 * ( nowOpen && ! advancedOpen && ! openedBySaveRef.current ) against
		 * the real post-open state. */
		fireEvent( advancedPanel( container ), new Event( 'toggle' ) );

		frames.flush();
		frames.flush();

		const scroll = Element.prototype.scrollIntoView as ReturnType<typeof vi.fn>;
		const targets = scroll.mock.contexts as unknown[];
		expect( targets ).not.toContain( advancedPanel( container ) );
		expect( targets ).toEqual( [ cardByTitle( container, 'Time delay' ) ] );
	} );

	test( 'the pending frame is cancelled if the component unmounts before it paints', async () => {
		const { ref, unmount } = await renderConfigurator( baseConfig() );
		act( () => {
			ref.current?.revealAdvanced( 'condition' );
		} );
		expect( frames.pending() ).toBe( 1 );
		unmount();
		expect( frames.pending() ).toBe( 0 );
	} );

	test( 'the inner frame is cancelled too when the component unmounts after the first frame ran', async () => {
		const { ref, unmount } = await renderConfigurator( baseConfig() );
		act( () => {
			ref.current?.revealAdvanced( 'condition' );
		} );
		frames.flush();
		expect( frames.pending() ).toBe( 1 );
		unmount();
		expect( frames.pending() ).toBe( 0 );
		const scroll = Element.prototype.scrollIntoView as ReturnType<typeof vi.fn>;
		expect( scroll ).not.toHaveBeenCalled();
	} );
} );
