/**
 * Props contract for the shared action configurator - see
 * docs/automator-retirement-phase2/contracts/configurator-props.md (#4047).
 */
export interface SubOperation {
	id: string;
	label: string;
	description: string;
	/** Visual tone of the sub-operation card. */
	tone: 'positive' | 'negative';
	/** Brand icon (data URI) for the sub-op card — 60px pastel tile per the design. */
	image?: string;
}

export interface ActionDescriptor {
	id: string;
	label: string;
	description: string;
	/** Brand icon (data URI) shown on picker cards and the modal header. */
	image?: string;
	/** Present when the owning plugin is not active - row renders locked. */
	locked?: boolean;
	lockedReason?: string;
	/** Why a locked action can't run - the saved card's info tooltip. */
	lockedTip?: string;
	/** Where to fix it (Thrive Product Manager) - the saved card's warning link. */
	lockedUrl?: string;
	/** Hidden from the picker but kept in the catalog so forms that already
	 * configured it still render and edit correctly. */
	hidden?: boolean;
	/** Empty for single-operation actions. */
	subOperations?: SubOperation[];
	/** Prompt above the target picker; keyed by sub-op when the verb changes ("Grant access to"). */
	targetPrompt: string;
	targetPromptByOp?: Record<string, string>;
	/** Modal-header display name for the configure step, keyed by sub-op ("Grant Apprentice access"). */
	displayNameByOp?: Record<string, string>;
	/** Helper line under the prompt. */
	targetHelp?: string;
	/** Helper line keyed by sub-op (Ultimatum start vs stop differ). Wins over targetHelp. */
	targetHelpByOp?: Record<string, string>;
	targetPlaceholder: string;
	/** No target picker (Ovation: uses the default template). Shows helper + optional link instead. */
	noTarget?: boolean;
	noTargetLink?: { label: string; href: string };
	/** Implicit target saved when noTarget (e.g. the default template). */
	implicitTarget?: TargetOption;
	/** Live summary template; `%target%` replaced by the picked label. Keyed by sub-op or '' for none. */
	summaryByOp: Record<string, string>;
	/** Prompt shown in the summary slot until a target is picked. */
	summaryPrompt?: string;
	/** THEN-row fragment templates for the condition card ("grant them access to %target%"). */
	thenByOp?: Record<string, string>;
	/** Target label used in the THEN fragment while none is picked ("the selected product"). */
	thenFallbackTarget?: string;
	/** Actions whose timing is locked to the trigger moment hide the Timing block. */
	hideTiming?: boolean;
	/** Optional per-action inputs rendered on the configure step, stored under config.extra. */
	extraFields?: ExtraField[];
	/**
	 * Sub-ops that can register a WP account for a submitted address (Apprentice
	 * grant). Keyed by sub-op id, or '' for actions with none. When true and the
	 * host reports spam protection off, the configure step shows the signup
	 * guardrail notice.
	 */
	createsAccountsByOp?: Record<string, boolean>;
}

export interface ExtraField {
	key: string;
	label: string;
	type: 'text' | 'number';
	placeholder?: string;
}

export interface TimingConfig {
	amount: number;
	unit: 'minutes' | 'hours' | 'days' | 'weeks' | 'months';
}

export interface ConditionConfig {
	field: string;
	op: 'equals' | 'not_equals' | 'contains';
	value: string;
	/**
	 * The field's human label when the rule was saved (#4052 QA). Written by
	 * the Architect host so Submission Log rows can still name a field that
	 * has since left the form. Optional; the evaluator ignores it.
	 */
	fieldLabel?: string;
}

export interface TargetOption {
	/** Backend identifier the executor acts on (product term id, campaign post id...). */
	id: string | number;
	label: string;
}

/** One fields/headers repeater row of the webhook form (#4059). */
export interface KvRow {
	key: string;
	value: string;
}

/** Diagnostics returned by the host's sendWebhookTest adapter (#4059). */
export interface WebhookTestResult {
	status_code: number;
	duration_ms: number;
	method: string;
	request_format: string;
	endpoint: string;
	body_excerpt?: string;
}

export interface ActionConfig {
	actionId: string;
	subOperation: string | null;
	target: TargetOption | null;
	timing: TimingConfig | null;
	condition: ConditionConfig | null;
	/** Values for the action's extraFields, keyed by field key. The email-tag
	 * form (#4058) also stores its picks here without declaring extraFields:
	 * `autoresponder`/`list_identifier` (what the executor validates) plus
	 * their display-only `autoresponder_label`/`list_label` twins. The
	 * webhook form (#4059) stores `method`/`request_format` as strings and
	 * `fields`/`headers` as `KvRow[]` - hence the union. */
	extra?: Record<string, string | KvRow[]> | null;
}

/**
 * A condition-field choice. A plain string is both the stored/evaluated value
 * and the displayed label. An `{ value, label }` pair stores/round-trips
 * `value` in `ConditionConfig.field` while the Select displays `label` - the
 * Architect host sends pairs so a custom input reads "Source", not
 * `mapping_text_174` (#4052 QA).
 */
export type ConditionFieldOption = string | {
	value: string;
	label: string;
	/** The host's field kind ('checkbox', 'radio', 'dropdown', 'text'...), when it knows it. */
	fieldType?: string;
	/** The field's own choices, for fields that have them (checkbox, radio, dropdown). */
	options?: { value: string; label: string }[];
};

export interface ConfiguratorAdapters {
	/** Target options for the configure step (products, campaigns, templates...). */
	getTargets: ( actionId: string, subOperation: string | null ) => Promise<TargetOption[]>;
	/**
	 * Field choices for the Condition block (#4052). The hosting surface owns
	 * the vocabulary: TAR offers the form's field names, trigger surfaces offer
	 * trigger-context paths. Optional - when absent the field is typed freely.
	 * Each entry is either a plain string (stored value === displayed label)
	 * or an `{ value, label }` pair - see `ConditionFieldOption`.
	 */
	getConditionFields?: ( actionId: string ) => Promise<ConditionFieldOption[]>;
	/**
	 * Whether the hosting form already blocks automated submissions. Only hosts
	 * that own a form implement this pair; when either is absent the signup
	 * guardrail notice never renders, so trigger surfaces that have no form are
	 * unaffected.
	 */
	isSpamProtectionEnabled?: () => boolean;
	/** Turn the host form's spam protection on. Returns false when it could not. */
	enableSpamProtection?: () => boolean;
	/**
	 * Email-tag data trio (#4058). When ALL THREE are present the configure
	 * step for `email_tag` renders the full form from the Apprentice Triggers
	 * handoff (ESP select → mailing list + refresh → tag chips with inventory
	 * autocomplete) instead of the bare noTarget paragraph. Hosts that pass
	 * none of them (the TAR modal today) are byte-for-byte unaffected.
	 *
	 * Connected, tag-capable ESPs, as `{ id: connection key, label: title }`.
	 */
	getEspOptions?: () => Promise<TargetOption[]>;
	/**
	 * Mailing lists of one connection. `force` bypasses the provider cache -
	 * wired to the form's refresh button.
	 */
	getEspLists?: ( esp: string, force?: boolean ) => Promise<TargetOption[]>;
	/**
	 * Tag inventory of one connection for the autocomplete dropdown; `list`
	 * narrows it on providers whose tags are per-list (Mailchimp). An empty
	 * array is a fine answer - free-typed tags are always accepted.
	 */
	getEspTags?: ( esp: string, list?: string ) => Promise<string[]>;
	/**
	 * Webhook send-test (#4059). When present the configure step for `webhook`
	 * renders the full form (URL/method/format, fields+headers repeaters with
	 * the {{token}} picker, Send test with diagnostics) instead of the bare
	 * noTarget paragraph. Fires the REAL request for the unsaved draft.
	 */
	sendWebhookTest?: ( config: ActionConfig ) => Promise<WebhookTestResult>;
}

/**
 * Imperative handle exposed via `ref` (#4055 Task 10 QA fix - hideFooter
 * hosts need to trigger the same validate-and-save flow the component's own
 * footer Save button runs, from a footer bar the host renders itself).
 * Passing no ref is a no-op - existing mounts are unaffected.
 */
export interface ActionConfiguratorHandle {
	/** Runs exactly the footer Save button's flow: validation, toasts, onSave. */
	submit: () => void;
	/**
	 * Sets `config.subOperation` on the live config (#4060). For inline hosts
	 * that own the sub-op step in their own wizard chrome: the host seeds the
	 * initial value in `value` and pushes later flips through here, so the rest
	 * of the config survives. Optional to call - hosts that never do are unchanged.
	 */
	setSubOperation: ( subOperation: string | null ) => void;
	/** Opens the Advanced panel (inline hosts) and scrolls to the given card,
	 * for hosts routing a server-side `timing` / `condition` field error. */
	revealAdvanced: ( card: 'timing' | 'condition' ) => void;
}

/** Live snapshot a hideFooter host needs to compose its own preview line. */
export interface ConfiguratorSummary {
	text: string;
	timing: TimingConfig | null;
	condition: ConditionConfig | null;
	/** The live target pick and sub-op (#4060), so a hideFooter host can compose
	 * its own action phrase ("Start the X campaign") without parsing `text`. */
	target?: TargetOption | null;
	subOperation?: string | null;
}

export interface ActionConfiguratorProps {
	open: boolean;
	actions: ActionDescriptor[];
	adapters: ConfiguratorAdapters;
	/** Existing config when editing; null when adding. */
	value: ActionConfig | null;
	/** Action ids already saved on this form - one action per plugin (Design Decision #7). */
	usedActionIds?: string[];
	onSave: ( config: ActionConfig ) => void;
	onCancel: () => void;
	/**
	 * Portal container for the modal. Hosts pass their island root so the
	 * host-bleed overrides scoped to it apply (default: document.body).
	 */
	container?: HTMLElement;
	/**
	 * Height of the Time delay and Add a condition controls: 'md' (36px) or
	 * 'lg' (40px). Default: undefined, so every control keeps its own default
	 * size. The Architect editor passes 'md' to match the #3535 design (#4051
	 * QA, Finding 4).
	 */
	controlSize?: 'md' | 'lg';
	/**
	 * 'modal' (default, the editor's behavior) or 'inline' - renders the same
	 * header/body/footer content as plain divs in the host page instead of a
	 * Modal portal, for surfaces that own a full page (#4055).
	 */
	presentation?: 'modal' | 'inline';
	/**
	 * Whether this session is adding a new action or editing a saved one, for
	 * the configure step's header wording. Default: inferred from `value` (a
	 * non-null value means editing). Hosts that own the action pick themselves
	 * and therefore always seed `value` (the trigger surfaces, #4055) pass
	 * 'add' so a brand-new action isn't titled "Edit — <action>".
	 */
	mode?: 'add' | 'edit';
	/**
	 * Mutually exclusive action pairs, listed in both directions, e.g.
	 * `{ email_tag: 'webhook', webhook: 'email_tag' }`. When an action's partner
	 * is in usedActionIds its card shows a "Conflicts" pill and is not
	 * selectable. Default: no pairs, so nothing conflicts.
	 */
	mutexPairs?: Record<string, string>;
	/** Host-specific copy overrides; every default preserves today's string. */
	copy?: {
		/**
		 * Help line under the delay inputs. Default: 'after form submission'.
		 * Pass '' (empty string, NOT undefined) to render no helper line at
		 * all - undefined keeps the default text.
		 */
		timingHelp?: string;
		/**
		 * Turns on the check that the rule's field is still among the host's
		 * condition fields (the input may have been deleted from the form): the
		 * field Select is marked invalid, and this text is the toast when Save
		 * is refused for it (#4052 QA). Only checked once
		 * the host's field list has loaded and is non-empty. Default:
		 * undefined, so no check - hosts with free-form fields are unchanged.
		 */
		conditionFieldMissing?: string;
		/** Condition card sub-line. Default: 'Only fire when a form field matches a value'. */
		conditionSub?: string;
		/**
		 * sprintf template (%1$d amount, %2$s plain unit word e.g. "days")
		 * rendered as TimingCard's sub-line instead of the static text, but
		 * ONLY while timing is on. Default: undefined, so the sub-line stays
		 * static regardless of state (#4055 QA fix).
		 */
		timingActiveSub?: string;
		/**
		 * Display labels for the delay-unit Select, e.g.
		 * `{ days: 'Days' }`. Selection still round-trips to the plain
		 * `TimingConfig['unit']` value. Default: undefined, so the Select keeps
		 * its plain unit words (#4051 QA, Finding 4).
		 */
		timingUnitLabels?: Record<TimingConfig[ 'unit' ], string>;
		/**
		 * sprintf template (%1$s field, %2$s operator label e.g. "equals",
		 * %3$s value) rendered as ConditionCard's sub-line instead of the
		 * static text, but ONLY once a condition is on AND its field is set.
		 * Default: undefined, so the sub-line stays static (#4055 QA fix).
		 */
		conditionActiveSub?: string;
		/** Tooltip on the "Conflicts" pill. */
		conflictTooltip?: string;
		/** Final-stage save button label. Default: 'Save changes' / 'Continue'. */
		saveLabel?: string;
		/**
		 * INLINE PRESENTATION ONLY (#4055 Task 10 QA fix). Replaces the configure
		 * step's header title (normally the action's display name) with a
		 * host-composed string, e.g. "Configure apply email tag". Ignored for
		 * `presentation: 'modal'` - the editor keeps today's action-name header.
		 */
		configureTitle?: string;
		/**
		 * INLINE PRESENTATION ONLY, paired with `configureTitle` - replaces the
		 * header sub-line. Default (when `configureTitle` is set but this isn't):
		 * falls back to the same sub-line modal would show.
		 */
		configureSub?: string;
		/**
		 * INLINE PRESENTATION ONLY. Sub-line under the collapsed "Advanced
		 * settings" accordion while both Timing and Condition are off. Default:
		 * 'Optional — add a time delay or a condition before this action fires.'
		 * Once either is on, the accordion composes its own state summary
		 * ("Delayed 2 days · Condition added") regardless of this override.
		 */
		advancedSub?: string;
	};
	/**
	 * When true, the component renders NO footer of its own in either
	 * presentation - the host supplies its own footer bar and drives Save via
	 * the `ref` handle's `submit()`. Default false (today's behavior: the
	 * component's own footer renders as always). #4055 Task 10 QA fix - the
	 * trigger surfaces need one sticky footer shared with their select phase,
	 * which a footer nested inside this component's own box could never be
	 * (`position: sticky` can't escape its scrolling ancestor).
	 */
	hideFooter?: boolean;
	/**
	 * Fires with the current live summary text (the same string the
	 * component's own footer would show, including timing/condition) whenever
	 * it changes. Optional - absent is a no-op, so existing mounts are
	 * unaffected. Meant for `hideFooter` hosts that render their own preview
	 * pill outside this component.
	 */
	onSummaryChange?: ( summary: ConfiguratorSummary ) => void;
	/**
	 * Fires with the live ActionConfig on every change (#4060): lets a host that
	 * unmounts the component between wizard phases hand the same config back
	 * through `value` when it remounts, so unsaved edits survive. Optional;
	 * hosts that never pass it are unchanged.
	 */
	onConfigChange?: ( config: ActionConfig ) => void;
	/**
	 * Takes over DISPLAYING validation errors (e.g. "Missing required field")
	 * - when set, the component skips its own centered `.tta-cfg-toast` box
	 * and hands the message to the host, which shows it in its own toast
	 * system. Field highlighting and focus behavior are unchanged. Optional -
	 * absent keeps the internal toast box (the modal/editor path).
	 *
	 * `kind` (#4058): 'success' marks the few non-error notices (the email-tag
	 * form's list refresh); absent/'error' keeps today's meaning, so existing
	 * hosts that ignore the second argument behave exactly as before.
	 */
	onToast?: ( message: string, kind?: 'error' | 'success' ) => void;
}
