/**
 * The webhook configure form (#4059): URL → method/format → fields repeater
 * (pre-filled with the trigger-context projection) → optional custom headers
 * → Send test with inline status + diagnostics panel. Renders only when the
 * host supplies the sendWebhookTest adapter - see
 * `ConfiguratorAdapters.sendWebhookTest` and configurator-props.md.
 *
 * Wire shape (matches the shared TTA_Webhook_Action executor schema, so it
 * runs unchanged): the URL is `config.target.id`/`label`; method, format and
 * the two row lists land under `config.extra`. Tokens are the engine's
 * `{{token}}` syntax - the legacy %token% form is deliberately absent (the
 * sender blanks it).
 */
import { useEffect, useRef, useState } from 'react';
import type { Dispatch, KeyboardEvent as ReactKeyboardEvent, SetStateAction } from 'react';
import { __, sprintf } from '@wordpress/i18n';
import { Select } from '@thrive-themes/ui-components';
import type { ActionConfig, ConfiguratorAdapters, KvRow, WebhookTestResult } from './types';

/** Which required field failed validation - owned by the parent's save(). */
export type WebhookErrorField = 'url' | 'headers';

export const WEBHOOK_METHODS = [ 'POST', 'GET', 'PUT', 'PATCH', 'DELETE' ] as const;
export const WEBHOOK_FORMATS: Record<string, string> = {
	json: 'JSON',
	form: __( 'Form (URL-encoded)', 'thrive-cb' ),
	xml: 'XML',
};

/**
 * The dynamic-value catalog, grouped the way the handoff popover groups it
 * (User data / Event data). Tokens are the five the executor resolves for
 * Apprentice (#4059 decision) - the popover only DESCRIBES them here.
 */
const TOKEN_GROUPS: { group: string; tokens: { token: string; hint: string }[] }[] = [
	{
		group: __( 'User data', 'thrive-cb' ),
		tokens: [
			{ token: 'email', hint: __( "Student's email", 'thrive-cb' ) },
			{ token: 'name', hint: __( "Student's full name", 'thrive-cb' ) },
		],
	},
	{
		group: __( 'Event data', 'thrive-cb' ),
		tokens: [
			{ token: 'product', hint: __( "The trigger's target name", 'thrive-cb' ) },
			{ token: 'event', hint: __( 'Trigger event type', 'thrive-cb' ) },
			{ token: 'source', hint: __( 'Source of the event', 'thrive-cb' ) },
		],
	},
];
const TOKENS = [ 'email', 'name', 'product', 'event', 'source' ] as const;

/** Row cap, mirrored from the save sanitizer (Store::sanitize_kv_rows) so the
 * UI can never build a list the server would silently truncate. */
const MAX_ROWS = 50;

/** String value under config.extra, '' when absent or a row list. */
export function webhookExtraString ( extra: ActionConfig[ 'extra' ], key: string ): string {
	const value = extra?.[ key ];
	return typeof value === 'string' ? value : '';
}

/** Row-list value under config.extra, [] when absent or a string. */
export function webhookExtraRows ( extra: ActionConfig[ 'extra' ], key: string ): KvRow[] {
	const value = extra?.[ key ];
	return Array.isArray( value ) ? value : [];
}

/**
 * Saved-summary line ("Send a POST webhook to https://…") - shared by the
 * configurator's live preview and the host's saved-row summary so the two can
 * never drift. Null while no URL is entered, so callers keep their fallback.
 */
export function webhookSummary ( config: ActionConfig ): string | null {
	if ( config.actionId !== 'webhook' ) {
		return null;
	}
	const url = String( config.target?.id ?? '' ).trim();
	if ( ! url ) {
		return null;
	}
	const method = ( webhookExtraString( config.extra, 'method' ) || 'POST' ).toUpperCase();
	/* translators: 1: the HTTP method (POST, GET...), 2: the webhook URL */
	return sprintf( __( 'Send a %1$s webhook to %2$s', 'thrive-cb' ), method, url );
}

/** The prefilled fields list - the trigger-context projection (#4059). */
const defaultFields = (): KvRow[] => TOKENS.map( ( token ) => ( { key: token, value: `{{${ token }}}` } ) );

export default function WebhookFields ( {
	config,
	setConfig,
	adapters,
	errorField,
	clearError,
	onToast,
}: {
	config: ActionConfig;
	setConfig: Dispatch<SetStateAction<ActionConfig>>;
	adapters: ConfiguratorAdapters;
	errorField: WebhookErrorField | null;
	clearError: () => void;
	onToast?: ( message: string, kind?: 'error' | 'success' ) => void;
} ) {
	const url = String( config.target?.id ?? '' );
	const method = ( webhookExtraString( config.extra, 'method' ) || 'POST' ).toUpperCase();
	const format = ( webhookExtraString( config.extra, 'request_format' ) || 'json' ).toLowerCase();
	/* A brand-new draft has no extra at all - seed the prefill exactly once so
	 * removing every row on purpose is never undone by a re-render. */
	const fields = config.extra ? webhookExtraRows( config.extra, 'fields' ) : defaultFields();
	const headers = webhookExtraRows( config.extra, 'headers' );
	const [ headersMode, setHeadersMode ] = useState<'none' | 'custom'>( headers.length ? 'custom' : 'none' );

	/* Saved headers must never be hidden behind a "None" radio: if the host
	 * swaps `config` without remounting, re-sync the mode the moment headers
	 * show up while it's still 'none'. The reverse (headers cleared while
	 * 'custom' is selected) is a legitimate user state and is left alone. */
	useEffect( () => {
		if ( headers.length && headersMode === 'none' ) {
			setHeadersMode( 'custom' );
		}
	}, [ headers.length, headersMode ] );

	const [ test, setTest ] = useState<WebhookTestResult | null>( null );
	const [ testError, setTestError ] = useState<string | null>( null );
	const [ testing, setTesting ] = useState( false );
	const [ detailsOpen, setDetailsOpen ] = useState( false );

	/* The diagnostics modal closes on Escape, like the handoff's tva-modal. */
	useEffect( () => {
		if ( ! detailsOpen ) {
			return;
		}
		const onKey = ( event: KeyboardEvent ) => {
			if ( event.key === 'Escape' ) {
				setDetailsOpen( false );
			}
		};
		document.addEventListener( 'keydown', onKey );
		return () => document.removeEventListener( 'keydown', onKey );
	}, [ detailsOpen ] );

	/* Modal focus management: focus moves INTO the dialog on open and returns
	 * to whatever opened it on close; Tab/Shift+Tab cycle inside the dialog. */
	const dialogRef = useRef<HTMLDivElement>( null );
	const restoreFocusRef = useRef<HTMLElement | null>( null );
	useEffect( () => {
		if ( ! detailsOpen ) {
			return;
		}
		restoreFocusRef.current = document.activeElement instanceof HTMLElement ? document.activeElement : null;
		dialogRef.current?.focus();
		return () => restoreFocusRef.current?.focus();
	}, [ detailsOpen ] );

	const trapDialogTab = ( event: ReactKeyboardEvent<HTMLDivElement> ) => {
		if ( event.key !== 'Tab' ) {
			return;
		}
		const focusables = dialogRef.current?.querySelectorAll<HTMLElement>( 'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])' );
		if ( ! focusables?.length ) {
			event.preventDefault();
			return;
		}
		const first = focusables[ 0 ];
		const last = focusables[ focusables.length - 1 ];
		if ( event.shiftKey && ( document.activeElement === first || document.activeElement === dialogRef.current ) ) {
			event.preventDefault();
			last.focus();
		} else if ( ! event.shiftKey && ( document.activeElement === last || document.activeElement === dialogRef.current ) ) {
			event.preventDefault();
			first.focus();
		}
	};

	/* One open token dropdown at a time, addressed as "<list>:<row index>". */
	const [ pickerAt, setPickerAt ] = useState<string | null>( null );
	const valueInputRefs = useRef<Map<string, HTMLInputElement>>( new Map() );

	/* Click-outside closes the popover (handoff picker.js document handler);
	 * clicks on any {·} button are its own toggle and are left alone. */
	useEffect( () => {
		if ( ! pickerAt ) {
			return;
		}
		const onDocClick = ( event: MouseEvent ) => {
			const target = event.target as HTMLElement | null;
			if ( ! target?.closest( '.tta-cfg-dynvalue' ) && ! target?.closest( '.tta-cfg-kv-picker' ) ) {
				setPickerAt( null );
			}
		};
		document.addEventListener( 'click', onDocClick );
		return () => document.removeEventListener( 'click', onDocClick );
	}, [ pickerAt ] );

	const urlFieldRef = useRef<HTMLDivElement>( null );

	/* Monotonic revision: bumped by every config edit so an in-flight test
	 * response can never resurrect after touch() invalidated it (the fields
	 * stay editable while a test runs). */
	const testSeq = useRef( 0 );

	/* EVERY config edit invalidates a previous test - a stale "200 OK" must
	 * never vouch for a config it did not see (#4059 scope). */
	const touch = ( mutate: ( c: ActionConfig ) => ActionConfig ) => {
		clearError();
		testSeq.current += 1;
		setTest( null );
		setTestError( null );
		/* row indexes shift under an open token menu (add/remove above it), so
		 * close it on every mutation rather than leaving it pinned to whichever
		 * row slides into that "<list>:<index>" slot. */
		setPickerAt( null );
		setConfig( ( c ) => mutate( c ) );
	};

	const writeExtra = ( patch: Record<string, string | KvRow[]> ) =>
		touch( ( c ) => ( {
			...c,
			extra: { method, request_format: format, fields, headers, ...( c.extra ?? {} ), ...patch },
		} ) );

	const writeUrl = ( next: string ) =>
		touch( ( c ) => ( {
			...c,
			target: next.trim() ? { id: next.trim(), label: next.trim() } : null,
			/* materialise the prefill alongside the first real input */
			extra: c.extra ?? { method, request_format: format, fields, headers },
		} ) );

	const writeRows = ( listKey: 'fields' | 'headers', rows: KvRow[] ) => writeExtra( { [ listKey ]: rows } );

	const updateRow = ( listKey: 'fields' | 'headers', index: number, patch: Partial<KvRow> ) => {
		const rows = listKey === 'fields' ? fields : headers;
		writeRows( listKey, rows.map( ( row, i ) => ( i === index ? { ...row, ...patch } : row ) ) );
	};

	const removeRow = ( listKey: 'fields' | 'headers', index: number ) => {
		const rows = listKey === 'fields' ? fields : headers;
		writeRows( listKey, rows.filter( ( _, i ) => i !== index ) );
	};

	const addRow = ( listKey: 'fields' | 'headers' ) => {
		const rows = listKey === 'fields' ? fields : headers;
		if ( rows.length >= MAX_ROWS ) {
			return;
		}
		writeRows( listKey, [ ...rows, { key: '', value: '' } ] );
	};

	const insertToken = ( listKey: 'fields' | 'headers', index: number, token: string ) => {
		const refKey = `${ listKey }:${ index }`;
		const input = valueInputRefs.current.get( refKey );
		const rows = listKey === 'fields' ? fields : headers;
		const current = rows[ index ]?.value ?? '';
		const chunk = `{{${ token }}}`;
		/* real caret insertion; falls back to append when the input never focused */
		const start = input?.selectionStart ?? current.length;
		const end = input?.selectionEnd ?? current.length;
		updateRow( listKey, index, { value: current.slice( 0, start ) + chunk + current.slice( end ) } );
		/* touch() (via updateRow) already clears pickerAt - no explicit call needed. */
		requestAnimationFrame( () => {
			input?.focus();
			input?.setSelectionRange( start + chunk.length, start + chunk.length );
		} );
	};

	const sendTest = () => {
		if ( testing || ! adapters.sendWebhookTest ) {
			return;
		}
		if ( ! url.trim() || ! url.trim().startsWith( 'https://' ) ) {
			onToast?.( __( 'Enter an https:// webhook URL first.', 'thrive-cb' ) );
			return;
		}
		setTesting( true );
		setTest( null );
		setTestError( null );
		const seq = testSeq.current;
		adapters.sendWebhookTest( config )
			.then( ( result ) => {
				if ( seq === testSeq.current ) {
					setTest( result );
				}
			} )
			.catch( ( error: Error ) => {
				if ( seq === testSeq.current ) {
					setTestError( error.message || __( 'The test request failed.', 'thrive-cb' ) );
				}
			} )
			.finally( () => setTesting( false ) );
	};

	const testOk = !! test && test.status_code >= 200 && test.status_code < 400;
	/* Result strip copy per the handoff prototype (runWebhookTest):
	 * "Webhook sent successfully (200 · 240ms)" / "Webhook failed (502 · 240ms)". */
	const statusLine = test
		? test.status_code > 0
			? testOk
				/* translators: 1: the HTTP status code, 2: request duration in milliseconds */
				? sprintf( __( 'Webhook sent successfully (%1$d · %2$dms)', 'thrive-cb' ), test.status_code, test.duration_ms )
				/* translators: 1: the HTTP status code, 2: request duration in milliseconds */
				: sprintf( __( 'Webhook failed (%1$d · %2$dms)', 'thrive-cb' ), test.status_code, test.duration_ms )
			: __( 'Webhook failed — no response received', 'thrive-cb' )
		: null;

	/* One kv repeater (Fields / Headers) per the handoff: [ key ] = [ value
	 * with the {·} picker INSIDE the input ] [ × ], then a link-style
	 * "+ Add …" button below. */
	const rowList = ( listKey: 'fields' | 'headers', rows: KvRow[], addLabel: string, keyPlaceholder: string, valuePlaceholder: string ) => (
		<>
			<div className="tta-cfg-kv-list">
				{ rows.map( ( row, index ) => {
					const refKey = `${ listKey }:${ index }`;
					return (
						<div className="tta-cfg-kv-row" key={ refKey }>
							<input
								type="text"
								className="tta-cfg-kv-key"
								value={ row.key }
								placeholder={ keyPlaceholder }
								aria-label={ __( 'Key', 'thrive-cb' ) }
								onChange={ ( event ) => updateRow( listKey, index, { key: event.target.value } ) }
							/>
							<span className="tta-cfg-kv-eq" aria-hidden="true">=</span>
							<div className="tta-cfg-kv-value-wrap">
								<input
									type="text"
									className="tta-cfg-kv-value"
									value={ row.value }
									placeholder={ valuePlaceholder }
									aria-label={ __( 'Value', 'thrive-cb' ) }
									ref={ ( el ) => {
										if ( el ) {
											valueInputRefs.current.set( refKey, el );
										} else {
											valueInputRefs.current.delete( refKey );
										}
									} }
									onChange={ ( event ) => updateRow( listKey, index, { value: event.target.value } ) }
								/>
								<button
									type="button"
									className="tta-cfg-kv-picker"
									title={ __( 'Insert dynamic value', 'thrive-cb' ) }
									aria-label={ __( 'Insert dynamic value', 'thrive-cb' ) }
									aria-expanded={ pickerAt === refKey }
									onClick={ () => setPickerAt( ( at ) => ( at === refKey ? null : refKey ) ) }
								>
									{ '{·}' }
								</button>
								{ pickerAt === refKey && (
									<div className="tta-cfg-dynvalue" role="menu" aria-label={ __( 'Insert dynamic value', 'thrive-cb' ) }>
										<div className="tta-cfg-dynvalue__head">{ __( 'Insert dynamic value', 'thrive-cb' ) }</div>
										<div className="tta-cfg-dynvalue__scroll">
											{ TOKEN_GROUPS.map( ( { group, tokens } ) => (
												<div key={ group }>
													<div className="tta-cfg-dynvalue__group">{ group }</div>
													{ tokens.map( ( { token, hint } ) => (
														<button
															key={ token }
															type="button"
															role="menuitem"
															className="tta-cfg-dynvalue__item"
															onClick={ () => insertToken( listKey, index, token ) }
														>
															<code>{ `{{${ token }}}` }</code>
															<span>{ hint }</span>
														</button>
													) ) }
												</div>
											) ) }
										</div>
									</div>
								) }
							</div>
							<button
								type="button"
								className="tta-cfg-kv-remove"
								aria-label={ __( 'Remove row', 'thrive-cb' ) }
								onClick={ () => removeRow( listKey, index ) }
							>
								×
							</button>
						</div>
					);
				} ) }
			</div>
			<button
				type="button"
				className="tta-cfg-kv-add"
				disabled={ rows.length >= MAX_ROWS }
				title={ rows.length >= MAX_ROWS
					/* translators: %d: the maximum number of rows */
					? sprintf( __( 'Maximum of %d rows reached.', 'thrive-cb' ), MAX_ROWS )
					: undefined }
				onClick={ () => addRow( listKey ) }
			>
				<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5v14M5 12h14" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" /></svg>
				{ addLabel }
			</button>
		</>
	);

	/* Layout per the handoff (Figma 5528:603 section rhythm): URL / method+
	 * format grid / Fields / Custom-headers toggle / Test-before-saving, each
	 * a hairline-divided section inside one 20px-gap column. */
	return (
		<div className="tta-cfg-wh">
			<div className={ `tta-cfg-wh-section${ errorField === 'url' ? ' is-error' : '' }` } ref={ urlFieldRef }>
				<label className="tta-cfg-label" htmlFor="tta-cfg-webhook-url">{ __( 'Webhook URL', 'thrive-cb' ) }</label>
				<input
					id="tta-cfg-webhook-url"
					type="url"
					className="tta-cfg-input tta-cfg-input--mono"
					value={ url }
					placeholder="https://example.com/hook"
					onChange={ ( event ) => writeUrl( event.target.value ) }
				/>
			</div>

			<div className="tta-cfg-wh-section">
				<div className="tta-cfg-wh-grid-2">
					<div>
						<label className="tta-cfg-label">{ __( 'Request type', 'thrive-cb' ) }</label>
						<Select
							label=""
							options={ [ ...WEBHOOK_METHODS ] }
							value={ [ method ] }
							onChange={ ( selected ) => writeExtra( { method: selected[ 0 ] ?? 'POST' } ) }
						/>
					</div>
					<div>
						<label className="tta-cfg-label">{ __( 'Request format', 'thrive-cb' ) }</label>
						<Select
							label=""
							options={ Object.values( WEBHOOK_FORMATS ) }
							value={ [ WEBHOOK_FORMATS[ format ] ?? 'JSON' ] }
							onChange={ ( selected ) => {
								const picked = Object.keys( WEBHOOK_FORMATS ).find( ( k ) => WEBHOOK_FORMATS[ k ] === selected[ 0 ] ) ?? 'json';
								writeExtra( { request_format: picked } );
							} }
						/>
					</div>
				</div>
			</div>

			<div className="tta-cfg-wh-section tta-cfg-wh-section--fields">
				<label className="tta-cfg-label">{ __( 'Fields', 'thrive-cb' ) }</label>
				{ rowList( 'fields', fields, __( 'Add field', 'thrive-cb' ), __( 'Key', 'thrive-cb' ), __( 'Value', 'thrive-cb' ) ) }
			</div>

			<div className={ `tta-cfg-wh-section tta-cfg-wh-section--headers${ errorField === 'headers' ? ' is-error' : '' }` }>
				{ /* The design's slide checkbox (thrive-ds .tva-slide-checkbox), the
				 * same lever every Triggers page uses: 30x14 track, 16px thumb with
				 * the check glyph when on. */ }
				<label className="tta-cfg-wh-switch">
					<span className="tta-cfg-wh-switch__label">{ __( 'Custom headers', 'thrive-cb' ) }</span>
					<input
						type="checkbox"
						checked={ headersMode === 'custom' }
						onChange={ () => {
							if ( headersMode === 'custom' ) {
								setHeadersMode( 'none' );
								writeRows( 'headers', [] );
							} else {
								setHeadersMode( 'custom' );
								/* the design opens the section ready to type - seed one
								 * empty row (an empty key never reaches the wire; the
								 * sanitizer drops keyless rows) */
								if ( ! headers.length ) {
									writeRows( 'headers', [ { key: '', value: '' } ] );
								}
							}
						} }
					/>
					<span className="tta-cfg-wh-switch__lever" aria-hidden="true" />
				</label>
				<p className="tta-cfg-wh-hint">
					{ __( 'Add HTTP headers your endpoint expects — e.g.', 'thrive-cb' ) }
					{ ' ' }
					<code>Authorization: Bearer …</code>
				</p>
				{ headersMode === 'custom' && rowList( 'headers', headers, __( 'Add header', 'thrive-cb' ), __( 'Header name', 'thrive-cb' ), __( 'Header value', 'thrive-cb' ) ) }
			</div>

			<div className="tta-cfg-wh-section tta-cfg-wh-section--test">
				<div className="tta-cfg-wh-test-head">
					<div className="tta-cfg-wh-test-head__text">
						<span className="tta-cfg-label">{ __( 'Test before saving', 'thrive-cb' ) }</span>
						<p className="tta-cfg-wh-hint">{ __( 'Confirm your endpoint can receive this payload before you save.', 'thrive-cb' ) }</p>
					</div>
					<button type="button" className="tta-cfg-wh-test-btn" disabled={ testing } onClick={ sendTest }>
						<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M13 2 3 14h7l-1 8 12-14h-8l1-6z" fill="none" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" /></svg>
						{ testing ? __( 'Sending…', 'thrive-cb' ) : __( 'Send test request', 'thrive-cb' ) }
					</button>
				</div>
				{ ( statusLine || testError ) && (
					<div className={ `tta-cfg-wh-test-result${ testOk ? '' : ' is-err' }` } role="status">
						<span className="tta-cfg-wh-test-result__status">{ statusLine ?? testError }</span>
						{ test && (
							<button type="button" className="tta-cfg-wh-test-result__details" onClick={ () => setDetailsOpen( true ) }>
								{ __( 'View response', 'thrive-cb' ) }
							</button>
						) }
					</div>
				) }
			</div>

			{ /* Diagnostics modal per the handoff (#webhookTestModal): a plain
			 * fixed overlay owned by this component - the ui-components Modal
			 * needs the host island's `container` prop, which the *Fields shape
			 * (matching EmailTagFields) does not receive. */ }
			{ detailsOpen && test && (
				<div className="tta-cfg-wh-modal">
					{ /* backdrop click closes, like the handoff's tva-modal; Escape is handled by the effect above */ }
					<div className="tta-cfg-wh-modal__backdrop" onClick={ () => setDetailsOpen( false ) } />
					{ /* keyboard handler = Tab containment for the asserted modal */ }
					<div
						className="tta-cfg-wh-modal__dialog"
						role="dialog"
						aria-modal="true"
						aria-label={ __( 'Webhook test diagnostics', 'thrive-cb' ) }
						ref={ dialogRef }
						tabIndex={ -1 }
						onKeyDown={ trapDialogTab }
					>
						<h3 className="tta-cfg-wh-modal__title">{ __( 'Webhook test diagnostics', 'thrive-cb' ) }</h3>
						<dl className="tta-cfg-wh-diag">
							<dt>{ __( 'Status', 'thrive-cb' ) }</dt>
							<dd className={ testOk ? 'is-ok' : 'is-err' }>{ test.status_code > 0 ? test.status_code : __( 'No response', 'thrive-cb' ) }</dd>
							<dt>{ __( 'Duration', 'thrive-cb' ) }</dt>
							<dd>{ `${ test.duration_ms }ms` }</dd>
							<dt>{ __( 'Method', 'thrive-cb' ) }</dt>
							<dd>{ test.method }</dd>
							<dt>{ __( 'Format', 'thrive-cb' ) }</dt>
							<dd>{ test.request_format }</dd>
							<dt>{ __( 'Endpoint', 'thrive-cb' ) }</dt>
							<dd>{ test.endpoint }</dd>
							<dt>{ __( 'Response body', 'thrive-cb' ) }</dt>
							<dd className="is-body">{ test.body_excerpt || __( '(empty)', 'thrive-cb' ) }</dd>
						</dl>
						<div className="tta-cfg-wh-modal__actions">
							<button type="button" className="tta-cfg-wh-test-btn" onClick={ () => setDetailsOpen( false ) }>
								{ __( 'Close', 'thrive-cb' ) }
							</button>
						</div>
					</div>
				</div>
			) }
		</div>
	);
}
