import { act, fireEvent, within } from '@testing-library/react';
import { baseConfig, cardByTitle, renderConfigurator } from '../test/configuratorFixture';

/* Proves the shared configurator still routes the Time delay input through
 * clampDelayAmount (#4061) - a regression here would silently let the
 * NumberInput hand a raw, unclamped amount straight to onSave. */
describe( 'ActionConfigurator delay clamp wiring', () => {
	test( 'typing past the 9999 ceiling saves the clamped amount, not the raw input', async () => {
		const { ref, onSave, container } = await renderConfigurator(
			baseConfig( { timing: { amount: 2, unit: 'days' } } )
		);
		const card = cardByTitle( container, 'Time delay' );
		const input = within( card ).getByRole( 'textbox' );

		act( () => {
			fireEvent.change( input, { target: { value: '10000' } } );
		} );
		act( () => {
			ref.current?.submit();
		} );

		expect( onSave.mock.calls[ 0 ][ 0 ].timing ).toEqual( { amount: 9999, unit: 'days' } );
	} );
} );
