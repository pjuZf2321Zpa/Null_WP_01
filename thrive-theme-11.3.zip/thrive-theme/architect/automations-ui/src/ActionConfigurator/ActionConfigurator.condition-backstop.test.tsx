import { act, fireEvent } from '@testing-library/react';
import {
	advancedPanel,
	baseConfig,
	cardByTitle,
	installFrameQueue,
	renderConfigurator,
} from '../test/configuratorFixture';

/* The component opens the Advanced panel at mount when `value` already
 * carries a condition (the edit case). Closing it through the DOM and firing
 * `toggle` runs the component's own onToggle, so save() then has to open it. */
function closeAdvanced( container: HTMLElement ) {
	const details = advancedPanel( container );
	details.open = false;
	fireEvent( details, new Event( 'toggle' ) );
	expect( details.open ).toBe( false );
}

describe( 'ActionConfigurator condition backstop (#4061)', () => {
	let frames: ReturnType<typeof installFrameQueue>;

	beforeEach( () => {
		frames = installFrameQueue();
		( Element.prototype.scrollIntoView as ReturnType<typeof vi.fn> ).mockClear();
	} );

	afterEach( () => {
		frames.restore();
	} );

	test( 'refuses a switched-on condition with an empty value: toast, panel opens, card scrolls after two frames', async () => {
		const { ref, onSave, onToast, container } = await renderConfigurator(
			baseConfig( { condition: { field: 'email', op: 'equals', value: '' } } )
		);
		closeAdvanced( container );

		act( () => {
			ref.current?.submit();
		} );

		expect( onToast ).toHaveBeenCalledWith( "Fill in the condition's field and value, or switch it off.", 'error' );
		expect( onSave ).not.toHaveBeenCalled();
		expect( advancedPanel( container ).open ).toBe( true );

		const conditionCard = cardByTitle( container, 'Add a condition' );
		const scroll = Element.prototype.scrollIntoView as ReturnType<typeof vi.fn>;

		/* Frame 1 only schedules frame 2 - nothing scrolls yet. */
		expect( frames.pending() ).toBe( 1 );
		frames.flush();
		expect( scroll ).not.toHaveBeenCalled();

		/* Frame 2 scrolls the condition card, centred. */
		frames.flush();
		expect( scroll ).toHaveBeenCalledTimes( 1 );
		expect( scroll.mock.contexts[ 0 ] ).toBe( conditionCard );
		expect( scroll ).toHaveBeenCalledWith( { behavior: 'smooth', block: 'center' } );
	} );

	test( 'refuses a condition with an empty field the same way', async () => {
		const { ref, onSave, onToast } = await renderConfigurator(
			baseConfig( { condition: { field: '', op: 'equals', value: 'x' } } )
		);
		act( () => {
			ref.current?.submit();
		} );
		expect( onToast ).toHaveBeenCalledWith( "Fill in the condition's field and value, or switch it off.", 'error' );
		expect( onSave ).not.toHaveBeenCalled();
	} );

	test( 'a missing target wins over the incomplete condition, matching the Store 422 order', async () => {
		const { ref, onSave, onToast, container } = await renderConfigurator(
			baseConfig( { target: null, condition: { field: 'email', op: 'equals', value: '' } } )
		);
		closeAdvanced( container );

		act( () => {
			ref.current?.submit();
		} );

		expect( onToast ).toHaveBeenCalledTimes( 1 );
		expect( onToast.mock.calls[ 0 ][ 0 ] ).toBe( 'Missing required field: "Grant access to"' );
		expect( onSave ).not.toHaveBeenCalled();
		expect( advancedPanel( container ).open ).toBe( false );
		expect( frames.pending() ).toBe( 0 );
	} );

	test( 'a complete condition saves without a toast', async () => {
		const { ref, onSave, onToast } = await renderConfigurator(
			baseConfig( { condition: { field: 'email', op: 'equals', value: 'a@b.c' } } )
		);
		act( () => {
			ref.current?.submit();
		} );
		expect( onToast ).not.toHaveBeenCalled();
		expect( onSave ).toHaveBeenCalledTimes( 1 );
		expect( onSave.mock.calls[ 0 ][ 0 ].condition ).toEqual( { field: 'email', op: 'equals', value: 'a@b.c' } );
	} );
} );

/* Which control turns red (#4055 QA follow-up): the target field's highlight
 * used to key off "any toast is showing", so the condition backstop painted
 * the (valid) target label red while the empty condition inputs stayed
 * plain. The highlight must follow the field the message is about. */
describe( 'ActionConfigurator validation highlight targets the field the toast names', () => {
	/* The field cell is a Select (aria-invalid lands on its combobox root) when
	 * the fixture supplies condition fields, which it does; the value cell is a
	 * plain <input>. */
	function conditionControls( card: HTMLElement ): { field: HTMLElement; value: HTMLElement } {
		const field = card.querySelector<HTMLElement>( '.tta-cond-grid [role="combobox"]' );
		const value = card.querySelector<HTMLElement>( '.tta-cond-grid input[placeholder$="value"]' );
		if ( ! field || ! value ) {
			throw new Error( 'Condition controls not rendered' );
		}
		return { field, value };
	}

	function targetField( container: HTMLElement ): HTMLElement {
		const field = Array.from( container.querySelectorAll<HTMLElement>( '.tta-cfg-field' ) )
			.find( ( el ) => el.querySelector( '.tta-cfg-label' )?.textContent === 'Grant access to' );
		if ( ! field ) {
			throw new Error( 'Target field not rendered' );
		}
		return field;
	}

	test( 'an incomplete condition highlights the condition card, not the target field', async () => {
		const { ref, container } = await renderConfigurator(
			baseConfig( { condition: { field: 'email', op: 'equals', value: '' } } )
		);
		act( () => {
			ref.current?.submit();
		} );
		const card = cardByTitle( container, 'Add a condition' );
		expect( card.classList.contains( 'is-error' ) ).toBe( true );
		expect( conditionControls( card ).value.getAttribute( 'aria-invalid' ) ).toBe( 'true' );
		expect( conditionControls( card ).field.hasAttribute( 'aria-invalid' ) ).toBe( false );
		expect( targetField( container ).classList.contains( 'is-error' ) ).toBe( false );
	} );

	test( 'an empty condition field flags only that cell', async () => {
		const { ref, container } = await renderConfigurator(
			baseConfig( { condition: { field: '', op: 'equals', value: 'x' } } )
		);
		act( () => {
			ref.current?.submit();
		} );
		const card = cardByTitle( container, 'Add a condition' );
		expect( conditionControls( card ).field.getAttribute( 'aria-invalid' ) ).toBe( 'true' );
		expect( conditionControls( card ).value.hasAttribute( 'aria-invalid' ) ).toBe( false );
	} );

	test( 'a missing target highlights the target field and leaves the condition card alone', async () => {
		const { ref, container } = await renderConfigurator(
			baseConfig( { target: null, condition: { field: 'email', op: 'equals', value: '' } } )
		);
		act( () => {
			ref.current?.submit();
		} );
		expect( targetField( container ).classList.contains( 'is-error' ) ).toBe( true );
		expect( cardByTitle( container, 'Add a condition' ).classList.contains( 'is-error' ) ).toBe( false );
	} );

	test( 'picking a target clears the target highlight with its toast, before the timer', async () => {
		const { ref, container } = await renderConfigurator( baseConfig( { target: null } ) );
		act( () => {
			ref.current?.submit();
		} );
		expect( targetField( container ).classList.contains( 'is-error' ) ).toBe( true );

		/* The picker's onChange clears the toast, which cancels the 4s auto-clear -
		 * the highlight must go with it rather than wait on a timer that never fires. */
		const combobox = targetField( container ).querySelector<HTMLElement>( '[role="combobox"] [role="button"]' );
		if ( ! combobox ) {
			throw new Error( 'Target picker not rendered' );
		}
		fireEvent.click( combobox );
		const option = Array.from( document.querySelectorAll<HTMLElement>( '[role="option"]' ) )
			.find( ( el ) => el.textContent?.includes( 'Course A' ) );
		if ( ! option ) {
			throw new Error( 'Target option not rendered' );
		}
		fireEvent.click( option );

		expect( targetField( container ).classList.contains( 'is-error' ) ).toBe( false );
	} );

	test( 'the highlight clears with the toast', async () => {
		vi.useFakeTimers();
		try {
			const { ref, container } = await renderConfigurator(
				baseConfig( { condition: { field: 'email', op: 'equals', value: '' } } )
			);
			act( () => {
				ref.current?.submit();
			} );
			expect( cardByTitle( container, 'Add a condition' ).classList.contains( 'is-error' ) ).toBe( true );
			act( () => {
				vi.advanceTimersByTime( 4000 );
			} );
			expect( cardByTitle( container, 'Add a condition' ).classList.contains( 'is-error' ) ).toBe( false );
		} finally {
			vi.useRealTimers();
		}
	} );
} );
