import { clampDelayAmount } from './ActionConfigurator';

describe( 'clampDelayAmount', () => {
	test.each( [
		[ '', 1 ],
		[ '0', 1 ],
		[ '-5', 1 ],
		[ '2.7', 2 ],
		[ '30', 30 ],
		[ '9999', 9999 ],
		[ '10000', 9999 ],
	] )( 'clamps %j to %i', ( raw, expected ) => {
		expect( clampDelayAmount( raw ) ).toBe( expected );
	} );

	/* parseInt( 'abc', 10 ) is NaN and NaN survives both Math.max and Math.min.
	 * The NumberInput never hands over non-numeric text, so the inline
	 * expression this replaced never met it; the test records the behaviour
	 * so the extraction is provably a pure move. */
	test( 'passes NaN through for non-numeric input', () => {
		expect( clampDelayAmount( 'abc' ) ).toBeNaN();
	} );
} );
