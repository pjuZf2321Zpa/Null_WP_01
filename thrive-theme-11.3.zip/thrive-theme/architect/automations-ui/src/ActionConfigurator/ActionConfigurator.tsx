/**
 * The shared action configurator: pick an action -> choose sub-operation ->
 * configure it. Built once here (#4047), mounted by the Apprentice, Quiz and
 * Ultimatum surfaces with their own catalogs and adapters.
 *
 * Flow follows the #3535 dev handoff (FEATURE-LOGIC.md sections 3-8, STATES.md).
 * The visual layer is ported 1:1 from the design prototype
 * (phase2-estimate-audit/inputs/3535/handoff/source) - card grids, toggle
 * cards, footer Back/Continue - with ui-components supplying only the modal
 * shell and the input primitives.
 */
import { forwardRef, useEffect, useImperativeHandle, useMemo, useRef, useState, type CSSProperties, type RefObject } from 'react';
import { __, sprintf } from '@wordpress/i18n';
import {
	Input,
	Modal,
	NumberInput,
	Select,
} from '@thrive-themes/ui-components';
import { conditionOpLabel, conditionOpsFor } from './conditionOps';
import type {
	ActionConfig,
	ActionConfiguratorHandle,
	ActionConfiguratorProps,
	ActionDescriptor,
	ConditionConfig,
	ConditionFieldOption,
	TargetOption,
	TimingConfig,
} from './types';
import EmailTagFields, { emailTagSummary, splitTags } from './EmailTagFields';
import type { EmailTagErrorField } from './EmailTagFields';
import WebhookFields, { webhookExtraRows, webhookSummary } from './WebhookFields';
import type { WebhookErrorField } from './WebhookFields';

type Stage = 'pick' | 'subop' | 'configure';

const TIMING_UNITS: TimingConfig[ 'unit' ][] = [ 'minutes', 'hours', 'days', 'weeks', 'months' ];
const TIMING_UNIT_LABELS: Record<string, string> = {
	minutes: __( 'minutes', 'thrive-cb' ),
	hours: __( 'hours', 'thrive-cb' ),
	days: __( 'days', 'thrive-cb' ),
	weeks: __( 'weeks', 'thrive-cb' ),
	months: __( 'months', 'thrive-cb' ),
};
/**
 * `sprintf()`'s TS overloads infer their rest-arg shape by parsing the
 * format string's LITERAL type for %1$d/%2$s tokens - a host-supplied
 * `copy.timingActiveSub`/`conditionActiveSub` template is just a plain
 * `string`, so TS can't derive that shape from it and rejects the extra
 * args. This narrows the same function back to a plain
 * `(format, ...args) => string` signature for those two dynamic-template
 * call sites; `sprintf()` does no compile-time validation of its own, so
 * runtime behaviour is unaffected (#4055 QA fix).
 */
const formatDynamic = sprintf as unknown as ( format: string, ...args: Array<string | number> ) => string;

const emptyConfig = ( actionId = '' ): ActionConfig => ( {
	actionId,
	subOperation: null,
	target: null,
	timing: null,
	condition: null,
	extra: null,
} );

const ActionConfigurator = forwardRef<ActionConfiguratorHandle, ActionConfiguratorProps>( function ActionConfigurator( {
	open,
	actions,
	adapters,
	value,
	usedActionIds = [],
	onSave,
	onCancel,
	container,
	controlSize,
	presentation = 'modal',
	mode,
	mutexPairs = {},
	copy = {},
	hideFooter = false,
	onSummaryChange,
	onConfigChange,
	onToast,
}, ref ) {
	const editing = value !== null;
	/* A host that owns the action pick itself (the trigger surfaces, #4055) always
	 * seeds `value` with the chosen action, so `editing` above - which exists to
	 * skip the pick stage - can't also decide the wording. `mode` lets such a host
	 * say which it is; without it, behaviour is unchanged. */
	const headerEditing = mode ? mode === 'edit' : editing;
	const [ stage, setStage ] = useState<Stage>( editing ? 'configure' : 'pick' );
	const [ config, setConfig ] = useState<ActionConfig>( value ?? emptyConfig() );
	const [ targets, setTargets ] = useState<TargetOption[]>( [] );
	const [ targetsLoading, setTargetsLoading ] = useState( false );
	const [ targetsError, setTargetsError ] = useState( false );
	const [ targetsRetry, setTargetsRetry ] = useState( 0 );
	const [ conditionFields, setConditionFields ] = useState<ConditionFieldOption[]>( [] );
	const [ saving, setSaving ] = useState( false );
	/* Inline-only "Advanced settings" accordion (#4055 Task 10 QA fix): starts
	 * open when the incoming value already carries a timing or condition (the
	 * edit case), collapsed otherwise. Deliberately keyed off the incoming
	 * `value` prop, not the live `config` - opening once on load, not every
	 * time the user toggles a card inside it. */
	const [ advancedOpen, setAdvancedOpen ] = useState( () => !! ( value?.timing || value?.condition ) );
	/* #4061 QA fix: scrolling to a card must wait for the setAdvancedOpen( true )
	 * below to commit and paint - see the effect further down that consumes
	 * this flag. Generalised (#4061 review) beyond the Condition card so a
	 * host can also route a server-side `timing` field error here through
	 * `revealAdvanced()` on the imperative handle. */
	const [ scrollToCard, setScrollToCard ] = useState<'timing' | 'condition' | null>( null );

	const action: ActionDescriptor | undefined = useMemo(
		() => actions.find( ( a ) => a.id === config.actionId ),
		[ actions, config.actionId ]
	);

	/* The email-tag form (#4058) renders only when the host wires up the ESP
	 * adapter trio - a host without them (the TAR modal) keeps the plain
	 * noTarget rendering, byte-for-byte. */
	const emailTagActive =
		action?.id === 'email_tag' &&
		!! adapters.getEspOptions && !! adapters.getEspLists && !! adapters.getEspTags;
	const [ emailTagError, setEmailTagError ] = useState<EmailTagErrorField | null>( null );

	/* The webhook form (#4059) renders only when the host wires the send-test
	 * adapter - a host without it (the TAR modal) keeps the plain noTarget
	 * rendering, byte-for-byte. Same gating idea as emailTagActive above. */
	const webhookActive = action?.id === 'webhook' && !! adapters.sendWebhookTest;
	const [ webhookError, setWebhookError ] = useState<WebhookErrorField | null>( null );

	/* Reset on every open so a previous session never leaks in. */
	useEffect( () => {
		if ( open ) {
			setStage( value ? 'configure' : 'pick' );
			setConfig( value ?? emptyConfig() );
			setSaving( false );
			setErrorField( null );
			setAdvancedOpen( !! ( value?.timing || value?.condition ) );
			setEmailTagError( null );
			setWebhookError( null );
			setErrorField( null );
		}
	}, [ open, value ] );

	/* Targets load per (action, sub-operation) - adapters own the data. */
	useEffect( () => {
		if ( ! open || stage !== 'configure' || ! action || action.noTarget ) {
			return;
		}
		let alive = true;
		setTargetsLoading( true );
		setTargetsError( false );
		adapters
			.getTargets( action.id, config.subOperation )
			.then( ( options ) => {
				if ( alive ) {
					setTargets( options );
				}
			} )
			.catch( () => {
				/* Distinct from a genuine empty list - see the field markup. */
				if ( alive ) {
					setTargetsError( true );
				}
			} )
			.finally( () => {
				if ( alive ) {
					setTargetsLoading( false );
				}
			} );
		return () => {
			alive = false;
		};
	}, [ open, stage, action, config.subOperation, adapters, targetsRetry ] );

	/* Condition field choices come from the hosting surface (#4052). */
	useEffect( () => {
		if ( ! open || stage !== 'configure' || ! action || ! adapters.getConditionFields ) {
			return;
		}
		let alive = true;
		adapters.getConditionFields( action.id ).then( ( fields ) => {
			if ( alive ) {
				setConditionFields( fields );
			}
		} ).catch( () => {
			/* Field choices are a convenience - a failed read leaves the list
			 * empty rather than blocking the configurator. */
		} );
		return () => {
			alive = false;
		};
	}, [ open, stage, action, adapters ] );

	/* Two products or campaigns can share a title - they are post titles - and
	 * a label-keyed Select resolves both to the first match, so the executor
	 * acts on the wrong target.
	 *
	 * The clean fix is an id-valued Select, which the shared ui-components
	 * Select cannot express today: options, value and onChange are all plain
	 * strings, so a click reports only the option TEXT - with two identical
	 * labels the island cannot tell which row was picked. Disambiguating the
	 * display string is therefore the only correct resolution available here.
	 * Extending the shared Select to accept { value, label } pairs is the real
	 * answer (and fixes the same latent bug for every product that lists post
	 * titles); deferred deliberately rather than changing a cross-product
	 * package that every Thrive plugin builds against. */
	const targetDisplays = useMemo( () => {
		const labelCounts = new Map<string, number>();
		targets.forEach( ( t ) => labelCounts.set( t.label, ( labelCounts.get( t.label ) ?? 0 ) + 1 ) );
		return targets.map( ( t ) => ( ( labelCounts.get( t.label ) ?? 0 ) > 1 ? `${ t.label } (ID ${ t.id })` : t.label ) );
	}, [ targets ] );

	/* Signup guardrail (#3535): an action that can register a WP account turns
	 * the form into a signup surface, so an unprotected form lets a bot mint
	 * accounts silently. Read on each render of the configure step rather than
	 * cached - the user can switch the Spam Protection dropdown in the sidebar
	 * while this modal is open, and the notice must reflect that. */
	const [ spamEnabledAt, setSpamEnabledAt ] = useState( 0 );
	const createsAccounts = !! action?.createsAccountsByOp?.[ config.subOperation ?? '' ];
	const showSpamNotice =
		stage === 'configure' &&
		createsAccounts &&
		!! adapters.isSpamProtectionEnabled &&
		!! adapters.enableSpamProtection &&
		! adapters.isSpamProtectionEnabled();
	/* spamEnabledAt is read so enabling re-renders the notice away; the value
	 * itself is unused. */
	void spamEnabledAt;

	/* #4053: Save stays clickable; a missing required target shows a toast
	 * naming the field and focuses it instead of silently doing nothing. */
	const [ toast, setToast ] = useState<string | null>( null );
	/* 'success' exists for the email-tag form's refresh notice (#4058) - every
	 * validation path resets it to 'error' so a later error never renders green. */
	const [ toastKind, setToastKind ] = useState<'error' | 'success'>( 'error' );
	/* Which control the current toast is about (#4055 QA follow-up). Drives
	 * the red is-error highlight: the target field used to key off "any toast
	 * is showing", so the condition backstop below painted the valid target
	 * label red while the empty condition inputs stayed plain. Read through
	 * `highlightedField` below so it only ever shows while the toast does -
	 * every path that clears the toast (the 4s timer, picking a target) then
	 * clears the highlight too. Child-form notices (email tag, webhook) own
	 * their own field highlight through their errorField props and pass
	 * nothing here. */
	const [ errorField, setErrorField ] = useState<'target' | 'condition' | null>( null );
	const highlightedField = toast ? errorField : null;
	const targetFieldRef = useRef<HTMLDivElement>( null );
	/* #4061: a condition switched on with an empty field or value is refused
	 * at save (toast + scroll to the card) - the Store answers a 422 for it,
	 * and the footer CTA must keep its "toast the missing field" behaviour. */
	const conditionCardRef = useRef<HTMLDivElement>( null );
	/* #4061 review: same idea for the Timing card, so a host-routed `timing`
	 * field error (revealAdvanced()) can land on it too. */
	const timingCardRef = useRef<HTMLDivElement>( null );
	/* #4061: set by save() when it opens the Advanced panel itself, so the
	 * panel's own "scroll the summary into view" on user-toggle stays quiet
	 * and the card scroll below is the only one that runs. */
	const openedBySaveRef = useRef( false );

	/* #4061: runs after the commit that opened the Advanced panel, so the
	 * target card has layout when we scroll to it. The flag is reset inside
	 * the frame callback, AFTER the scroll - resetting it here would re-run
	 * this effect and its cleanup would cancel the pending frame. */
	useEffect( () => {
		if ( ! scrollToCard ) {
			return;
		}
		const cardRef = scrollToCard === 'timing' ? timingCardRef : conditionCardRef;
		/* Both ids are kept: once the outer frame has run, cancelling only it
		 * would leave the inner frame to fire after unmount (#4671 review). */
		let innerFrame = 0;
		const outerFrame = window.requestAnimationFrame( () => {
			innerFrame = window.requestAnimationFrame( () => {
				cardRef.current?.scrollIntoView( { behavior: 'smooth', block: 'center' } );
				setScrollToCard( null );
			} );
		} );
		return () => {
			window.cancelAnimationFrame( outerFrame );
			window.cancelAnimationFrame( innerFrame );
		};
	}, [ scrollToCard ] );

	/* One notice channel for save-time validation and child forms (#4058):
	 * internal state always tracks the message (it drives the visible box when
	 * no host handler takes over, plus the 4s auto-clear), and the host
	 * callback - when present - owns the display. `field` names the control the
	 * notice is about, for the red is-error highlight. */
	const notify = ( message: string, kind: 'error' | 'success' = 'error', field: 'target' | 'condition' | null = null ) => {
		setToastKind( kind );
		setToast( message );
		setErrorField( field );
		onToast?.( message, kind );
	};

	useEffect( () => {
		if ( ! toast ) {
			return;
		}
		const t = setTimeout( () => {
			setToast( null );
			setErrorField( null );
		}, 4000 );
		return () => clearTimeout( t );
	}, [ toast ] );

	const pickAction = ( a: ActionDescriptor, unavailable: boolean ) => {
		if ( a.locked || unavailable ) {
			return;
		}
		setConfig( { ...emptyConfig( a.id ), target: a.implicitTarget ?? null } );
		setStage( a.subOperations?.length ? 'subop' : 'configure' );
	};

	const pickSubOp = ( id: string ) => {
		setConfig( ( c ) => ( { ...c, subOperation: id } ) );
		setStage( 'configure' );
	};

	const displayForTarget = ( target: TargetOption | null ): string[] => {
		if ( ! target ) {
			return [];
		}
		const index = targets.findIndex( ( t ) => String( t.id ) === String( target.id ) );
		return [ index >= 0 ? targetDisplays[ index ] : target.label ];
	};

	const canContinue = !! action && ( !! action.noTarget || !! config.target );

	const save = () => {
		if ( saving ) {
			return;
		}
		/* Email-tag required fields, validated in the handoff's order: ESP →
		 * mailing list → at least one tag (prototype.js saveAutomation). Same
		 * contract the shared executor's validate() re-checks server-side. */
		if ( emailTagActive ) {
			const missing: EmailTagErrorField | null = ! config.extra?.autoresponder
				? 'esp'
				: ! config.extra?.list_identifier
					? 'list'
					: splitTags( config.target?.id ).length === 0 ? 'tags' : null;
			if ( missing ) {
				const message = missing === 'esp'
					? __( 'Pick an email service provider.', 'thrive-cb' )
					: missing === 'list'
						? __( 'Pick a mailing list.', 'thrive-cb' )
						: __( 'Add at least one tag.', 'thrive-cb' );
				notify( message );
				setEmailTagError( missing );
				return;
			}
		}
		/* Webhook required fields (#4059): an https URL, and no header row
		 * carrying a value without a key. Same contract the shared executor's
		 * validate() + the Apprentice store re-check server-side. */
		if ( webhookActive ) {
			const url = String( config.target?.id ?? '' ).trim();
			const orphanHeader = webhookExtraRows( config.extra, 'headers' )
				.some( ( row ) => row.value.trim() !== '' && row.key.trim() === '' );
			const missing: WebhookErrorField | null = ! url || ! url.startsWith( 'https://' )
				? 'url'
				: orphanHeader ? 'headers' : null;
			if ( missing ) {
				const message = missing === 'url'
					? __( 'Enter an https:// webhook URL.', 'thrive-cb' )
					: __( 'Every header with a value needs a key.', 'thrive-cb' );
				notify( message );
				setWebhookError( missing );
				return;
			}
		}
		/* Sub-op backstop (#4060): an action that declares sub-operations must
		 * carry one - the executor's validate() rejects null. The modal's sub-op
		 * stage guarantees it; an inline host owns its own sub-op step and drives
		 * the value through the handle's setSubOperation(), so this only fires if
		 * a host forgot to seed. */
		if ( action?.subOperations?.length && ! config.subOperation ) {
			notify( __( 'Pick an operation for this action.', 'thrive-cb' ) );
			return;
		}
		if ( ! canContinue ) {
			if ( action && ! action.noTarget ) {
				/* translators: %s: the missing field's label */
				const message = sprintf( __( 'Missing required field: "%s"', 'thrive-cb' ), targetPrompt( action, config.subOperation ) );
				/* Internal state always tracks the error (it drives the field's
				 * is-error highlight + the 4s auto-clear); the visible toast box
				 * only renders when no host handler takes over the display. */
				notify( message, 'error', 'target' );
				const focusable = targetFieldRef.current?.querySelector<HTMLElement>( 'input, button, select, [tabindex]' );
				focusable?.focus();
			}
			return;
		}
		/* Condition backstop (#4061): the card is on but the rule is not
		 * complete. Same order as the Store's 422s - target first. */
		if ( config.condition && ( String( config.condition.field ?? '' ).trim() === '' || String( config.condition.value ?? '' ).trim() === '' ) ) {
			notify( __( "Fill in the condition's field and value, or switch it off.", 'thrive-cb' ), 'error', 'condition' );
			/* Open the Advanced panel (inline hosts) and ask the effect above to
			 * scroll once that open state has committed - a frame callback here
			 * can run while the <details> is still closed in the DOM, and Chrome
			 * skips scrollIntoView on hidden content. For modal hosts the cards
			 * are always visible and setAdvancedOpen is inert. */
			openedBySaveRef.current = true;
			setAdvancedOpen( true );
			setScrollToCard( 'condition' );
			return;
		}
		/* A rule on a field that has left the host's form can never fire
		 * (#4052 QA) - refuse it, but only for hosts that ask for the check.
		 * The field is already marked red; the toast says why. */
		if ( copy.conditionFieldMissing && config.condition && isConditionFieldMissing( config.condition, conditionFields ) ) {
			notify( copy.conditionFieldMissing );
			openedBySaveRef.current = true;
			setAdvancedOpen( true );
			setScrollToCard( 'condition' );
			return;
		}
		setSaving( true );
		onSave( config );
	};

	const back = () => {
		if ( stage === 'configure' ) {
			setStage( action?.subOperations?.length ? 'subop' : 'pick' );
		} else if ( stage === 'subop' ) {
			setStage( 'pick' );
		}
	};

	/* Imperative handle (#4055 Task 10 QA fix): a `hideFooter` host renders its
	 * own footer bar and drives Save through `ref.current.submit()`, which runs
	 * exactly this same validate-and-save flow - same toasts, same focus. A host
	 * that never passes a ref never triggers this; behaviour is unchanged. */
	useImperativeHandle( ref, () => ( {
		submit: save,
		/* Inline hosts render the sub-op step themselves (the Apprentice
		 * Triggers "Start or stop the campaign?" cards, #4060) and push the pick
		 * in here, so the live config changes without a `value` reset wiping
		 * the target/timing/condition the user already filled in. */
		setSubOperation: ( subOperation: string | null ) => setConfig( ( c ) => ( { ...c, subOperation } ) ),
		/* #4061 review: lets a host route a server-side `timing` / `condition`
		 * field error (a 422 the client-side backstops above never triggered
		 * for) here - same "open the Advanced panel, then scroll" path save()
		 * takes for its own condition backstop. */
		revealAdvanced: ( card: 'timing' | 'condition' ) => {
			openedBySaveRef.current = true;
			setAdvancedOpen( true );
			setScrollToCard( card );
		},
	} ), [ save ] );

	/* Same fix: a `hideFooter` host needs the live summary text (the same
	 * string the component's own footer would show) to render in its own
	 * preview pill. Fires only while there is a summary to show; a host that
	 * never passes `onSummaryChange` never triggers this. */
	useEffect( () => {
		if ( ! onSummaryChange || ! open || stage !== 'configure' || ! action ) {
			return;
		}
		onSummaryChange( {
			text: summaryText( action, config, emailTagActive, webhookActive ),
			timing: config.timing,
			condition: config.condition,
			target: config.target,
			subOperation: config.subOperation,
		} );
	}, [ onSummaryChange, open, stage, action, config ] );

	/* Same idea one level down (#4060): a host that UNMOUNTS this component
	 * between its own wizard phases (the Apprentice Triggers "Change" chips)
	 * keeps the live config so it can hand it straight back through `value` on
	 * the remount - otherwise the frozen seed wins and unsaved campaign/timing/
	 * condition edits are lost. Absent handler = no-op. */
	useEffect( () => {
		if ( open && stage === 'configure' ) {
			onConfigChange?.( config );
		}
	}, [ onConfigChange, open, stage, config ] );

	if ( ! open ) {
		return null;
	}

	/* Header per prototype renderModalHeader(): picker = feature title; the
	 * sub-op and configure steps carry the plugin icon + action context. */
	let headerIcon: string | undefined;
	let headerTitle: string = __( 'Thrive Actions', 'thrive-cb' );
	let headerSub: string = __( 'Trigger a Thrive plugin action when this form is submitted.', 'thrive-cb' );
	if ( stage === 'subop' && action ) {
		headerIcon = action.image;
		headerTitle = action.label;
		headerSub = action.description;
	} else if ( stage === 'configure' && action ) {
		headerIcon = action.image;
		const dispName =
			( config.subOperation && action.displayNameByOp?.[ config.subOperation ] ) || action.label;
		const defaultSub = headerEditing
			? __( 'Update the configuration and save your changes.', 'thrive-cb' )
			: subOpDesc( action, config.subOperation ) ?? action.description;
		/* Inline hosts that own the action pick (the trigger surfaces, #4055)
		 * want a "Configure <action>" step heading instead of the bare action
		 * name - modal keeps today's wording regardless of this copy prop. */
		if ( presentation === 'inline' && copy.configureTitle ) {
			headerTitle = copy.configureTitle;
			headerSub = copy.configureSub ?? defaultSub;
		} else {
			/* translators: %s: the action name */
			headerTitle = headerEditing ? sprintf( __( 'Edit — %s', 'thrive-cb' ), dispName ) : dispName;
			headerSub = defaultSub;
		}
	}

	/* What the picker actually renders: hidden cards are out, except the one a
	 * saved action already points at, so an existing config stays editable. */
	const pickable = actions.filter( ( a ) => ! a.hidden || a.id === config.actionId );

	/* The three regions are built once and rendered by either presentation, so
	 * the modal (editor) and inline (full-page host) branches can never drift. */
	const headerContent = (
				<div className="tta-cfg-header">
					{ headerIcon && (
						<span className="tta-cfg-header-icon">
							<img src={ headerIcon } alt="" />
						</span>
					) }
					<div className="tta-cfg-header-text">
						<strong>{ headerTitle }</strong>
						<span className="tta-cfg-sub">{ headerSub }</span>
					</div>
				</div>
	);

	const bodyContent = (
		<>
				{ stage === 'pick' && (
					<div
						className="tta-cfg-grid"
						role="list"
						style={ { '--tta-cfg-cols': Math.min( 3, Math.max( 1, pickable.length ) ) } as CSSProperties }
					>
						{ pickable.map( ( a ) => {
							const used = usedActionIds.includes( a.id );
							/* Mutex partner already added for this target - selecting this
							 * action would produce a contradictory pair. */
							const conflictsWith = mutexPairs[ a.id ];
							const conflicted = !! conflictsWith && usedActionIds.includes( conflictsWith ) && ! used;
							const disabled = !! a.locked || used || conflicted;
							return (
								<button
									key={ a.id }
									type="button"
									role="listitem"
									className={ `tta-cfg-card${ a.locked ? ' is-locked' : '' }${ used ? ' is-added' : '' }${ conflicted ? ' is-conflicted' : '' }` }
									onClick={ () => pickAction( a, used || conflicted ) }
									disabled={ disabled }
								>
									{ used && <span className="tta-cfg-card-pill">{ __( 'Added', 'thrive-cb' ) }</span> }
									{ conflicted && (
										<span
											className="tta-cfg-card-pill is-warn"
											title={ copy.conflictTooltip ?? __( 'Conflicts with an action already added for this target.', 'thrive-cb' ) }
										>
											{ __( 'Conflicts', 'thrive-cb' ) }
										</span>
									) }
									<span className="tta-cfg-card-icon">
										<img src={ a.image } alt="" />
									</span>
									<span className="tta-cfg-card-body">
										<span className="tta-cfg-card-name">{ a.label }</span>
										<span className="tta-cfg-card-desc">{ a.description }</span>
										{ a.locked && (
											<span className="tta-cfg-card-lock">🔒 { a.lockedReason }</span>
										) }
									</span>
								</button>
							);
						} ) }
					</div>
				) }

				{ stage === 'subop' && action?.subOperations && (
					<div className="tta-cfg-subop">
						<button type="button" className="tta-cfg-backlink" onClick={ back }>
							← Back
						</button>
						<div className="tta-cfg-subop-grid" role="list">
							{ action.subOperations.map( ( op ) => (
								<button
									key={ op.id }
									type="button"
									role="listitem"
									className={ `tta-cfg-subop-card is-${ op.tone }` }
									onClick={ () => pickSubOp( op.id ) }
								>
									<span className="tta-cfg-subop-icon" aria-hidden="true">
										{ op.image && <img src={ op.image } alt="" /> }
									</span>
									<span className="tta-cfg-card-body">
										<span className="tta-cfg-card-name">{ op.label }</span>
										<span className="tta-cfg-card-desc">{ op.description }</span>
									</span>
								</button>
							) ) }
						</div>
					</div>
				) }

				{ stage === 'configure' && action && (
					<div className="tta-cfg-form">
						{ action.noTarget ? (
							/* An action with no help text and no link (email_tag, webhook)
							 * has nothing to say here - rendering the paragraph anyway used
							 * to leave a stray "." behind (the trailing full stop below,
							 * with no preceding text or link to terminate). */
							( action.targetHelp || action.noTargetLink ) && (
								<p className="tta-cfg-desc">
									{ action.targetHelp }
									{ action.targetHelp && action.noTargetLink && ' ' }
									{ action.noTargetLink && (
										<a
											href={ action.noTargetLink.href }
											target="_blank"
											rel="noreferrer"
											className="tta-cfg-link"
										>
											{ action.noTargetLink.label } ↗
										</a>
									) }
									{ action.targetHelp && '.' }
								</p>
							)
						) : (
							<div className={ `tta-cfg-field${ highlightedField === 'target' ? ' is-error' : '' }` } ref={ targetFieldRef }>
								<label className="tta-cfg-label">
									{ targetPrompt( action, config.subOperation ) }
								</label>
								{ targetsError && (
									<div className="tta-cfg-fetch-error" role="alert">
										<span>{ __( "Couldn't load the options - the request failed.", 'thrive-cb' ) }</span>
										<button type="button" className="tta-cfg-retry" onClick={ () => setTargetsRetry( ( n ) => n + 1 ) }>
											{ __( 'Retry', 'thrive-cb' ) }
										</button>
									</div>
								) }
								{ ! targetsError && <Select
									label=""
									options={ targetDisplays }
									value={ displayForTarget( config.target ) }
									placeholder={ targetsLoading ? __( 'Loading…', 'thrive-cb' ) : action.targetPlaceholder }
									disabled={ targetsLoading }
									onChange={ ( selected ) => {
										const index = targetDisplays.indexOf( selected[ 0 ] ?? '' );
										const picked = index >= 0 ? targets[ index ] : null;
										setToast( null );
										setErrorField( null );
										setConfig( ( c ) => ( { ...c, target: picked } ) );
									} }
								/> }
								{ targetHelp( action, config.subOperation ) && (
									<span className="tta-cfg-help">{ targetHelp( action, config.subOperation ) }</span>
								) }
							</div>
						) }

						{ emailTagActive && (
							<EmailTagFields
								config={ config }
								setConfig={ setConfig }
								adapters={ adapters }
								errorField={ emailTagError }
								clearError={ () => setEmailTagError( null ) }
								onToast={ notify }
							/>
						) }

						{ webhookActive && (
							<WebhookFields
								config={ config }
								setConfig={ setConfig }
								adapters={ adapters }
								errorField={ webhookError }
								clearError={ () => setWebhookError( null ) }
								onToast={ notify }
							/>
						) }

						{ action.extraFields?.map( ( field ) => (
							<div className="tta-cfg-field" key={ field.key }>
								<label className="tta-cfg-label">{ field.label }</label>
								{ field.type === 'number' ? (
									<NumberInput
										value={ typeof config.extra?.[ field.key ] === 'string' ? config.extra[ field.key ] as string : '' }
										min={ 0 }
										size="md"
										placeholder={ field.placeholder }
										onChange={ ( v: string ) =>
											setConfig( ( c ) => ( { ...c, extra: { ...c.extra, [ field.key ]: v } } ) )
										}
									/>
								) : (
									<Input
										as="input"
										placeholder={ field.placeholder }
										value={ typeof config.extra?.[ field.key ] === 'string' ? config.extra[ field.key ] as string : '' }
										onChange={ ( v: string ) =>
											setConfig( ( c ) => ( { ...c, extra: { ...c.extra, [ field.key ]: v } } ) )
										}
									/>
								) }
							</div>
						) ) }

						{ presentation === 'inline' ? (
							/* Inline-only: Time delay + Condition render in the standalone
							 * "Advanced settings" accordion PANEL below the card (see
							 * inlineAdvancedContent) - nothing to render inside the form.
							 * The modal path below keeps both cards always-visible, unchanged. */
							null
						) : (
							<>
								{ ! action.hideTiming && (
									<TimingCard
										cardRef={ timingCardRef }
										timing={ config.timing }
										help={ copy.timingHelp }
										activeSub={ copy.timingActiveSub }
										unitLabels={ copy.timingUnitLabels }
										controlSize={ controlSize }
										onChange={ ( timing ) => setConfig( ( c ) => ( { ...c, timing } ) ) }
									/>
								) }
								<ConditionCard
									cardRef={ conditionCardRef }
									error={ highlightedField === 'condition' }
									condition={ config.condition }
									fields={ conditionFields }
									controlSize={ controlSize }
									missingFieldText={ copy.conditionFieldMissing }
									sub={ copy.conditionSub }
									activeSub={ copy.conditionActiveSub }
									actionLabel={ action.label }
									thenLabel={ thenText( action, config, emailTagActive, webhookActive ) }
									onChange={ ( condition ) => setConfig( ( c ) => ( { ...c, condition } ) ) }
								/>
							</>
						) }
						{ showSpamNotice && (
							<div className="tta-cfg-spam-notice" role="status">
								<span className="tta-cfg-spam-notice-icon" aria-hidden="true">⚠</span>
								<span className="tta-cfg-spam-notice-text">
									{ __( 'This form can create accounts. Enable spam protection to block automated signups, bad bots.', 'thrive-cb' ) }
								</span>
								<button
									type="button"
									className="tta-cfg-spam-notice-btn"
									onClick={ () => {
										/* Dismissal is the state changing, not a
										 * flag: if enabling fails the notice is
										 * still true and must stay put. */
										if ( adapters.enableSpamProtection?.() ) {
											setSpamEnabledAt( ( n ) => n + 1 );
										}
									} }
								>
									{ __( 'Enable spam protection', 'thrive-cb' ) }
								</button>
							</div>
						) }
					</div>
				) }
		</>
	);

	const toastContent = toast && ! onToast ? (
				<div className={ `tta-cfg-toast${ toastKind === 'success' ? ' is-success' : '' }` } role="alert">
					{ toast }
				</div>
	) : null;

	const footerActionsContent = (
		<div className="tta-cfg-footer-actions">
			<button
				type="button"
				className="tta-btn tta-btn--ghost"
				onClick={ editing ? onCancel : back }
			>
				{ editing ? __( 'Cancel', 'thrive-cb' ) : __( '← Back', 'thrive-cb' ) }
			</button>
			{ /* Always clickable (#4053): a missing target answers with the toast, not a dead button. */ }
			<button
				type="button"
				className={ `tta-btn tta-btn--primary${ canContinue ? '' : ' is-disabled' }` }
				onClick={ save }
			>
				{ copy.saveLabel ?? ( editing ? __( 'Save changes', 'thrive-cb' ) : __( 'Continue', 'thrive-cb' ) ) }
			</button>
		</div>
	);

	/* Inline presentation restyles the live Summary line as a "Preview:" pill
	 * matching the host page's own footer chrome (#4055 Task 10 QA fix) - the
	 * modal keeps today's stacked summary-bar-then-actions layout untouched. */
	const footerContent = stage === 'configure' && action ? (
		presentation === 'inline' ? (
			<>
				<div className="tta-cfg-preview-pill">
					<span className="tta-cfg-preview-pill__label">{ __( 'Preview:', 'thrive-cb' ) }</span>
					<span className="tta-cfg-preview-pill__text">{ summaryText( action, config, emailTagActive, webhookActive ) }</span>
				</div>
				{ footerActionsContent }
			</>
		) : (
			<div className="tta-cfg-footer">
				<p className="tta-cfg-summary">
					<strong>{ __( 'Summary:', 'thrive-cb' ) }</strong> { summaryText( action, config, emailTagActive, webhookActive ) }
				</p>
				{ footerActionsContent }
			</div>
		)
	) : null;

	/* Inline-only: Time delay + Condition fold into one collapsed "Advanced
	 * settings" accordion (#4055 Task 10 QA fix), rendered as its OWN panel
	 * below the configure card - the handoff shows Advanced settings as a
	 * separate step card in the wizard's card rhythm, not a box nested inside
	 * the configure form. */
	const inlineAdvancedContent = presentation === 'inline' && stage === 'configure' && action ? (
		<details
			className="tta-cfg-advanced"
			open={ advancedOpen }
			onToggle={ ( event ) => {
				const nowOpen = event.currentTarget.open;
				/* User-opened (state was closed): scroll the expanded options
				 * into view so they aren't below the fold (handoff §8). Mount-
				 * time auto-opens (editing with a delay/condition on) don't
				 * pass this guard, so they never yank the scroll position. A
				 * programmatic open from save() or revealAdvanced() (#4061,
				 * #4061 review) also skips this, so its own card scroll below
				 * isn't overridden. */
				if ( nowOpen && ! advancedOpen && ! openedBySaveRef.current ) {
					event.currentTarget.scrollIntoView( { behavior: 'smooth', block: 'start' } );
				}
				openedBySaveRef.current = false;
				setAdvancedOpen( nowOpen );
			} }
		>
			<summary className="tta-cfg-advanced__summary">
				<span className="tta-cfg-advanced__summary-text">
					<span className="tta-cfg-advanced__summary-title">{ __( 'Advanced settings', 'thrive-cb' ) }</span>
					<span className="tta-cfg-advanced__summary-sub">{ advancedSubText( config, copy.advancedSub ) }</span>
				</span>
				<svg className="tta-cfg-advanced__chev" viewBox="0 0 24 24" fill="none" aria-hidden="true">
					<path d="m6 9 6 6 6-6" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
				</svg>
			</summary>
			<div className="tta-cfg-advanced__body">
				{ ! action.hideTiming && (
					<TimingCard
						cardRef={ timingCardRef }
						timing={ config.timing }
						help={ copy.timingHelp }
						activeSub={ copy.timingActiveSub }
						unitLabels={ copy.timingUnitLabels }
						onChange={ ( timing ) => setConfig( ( c ) => ( { ...c, timing } ) ) }
					/>
				) }
				<ConditionCard
					cardRef={ conditionCardRef }
					error={ highlightedField === 'condition' }
					condition={ config.condition }
					fields={ conditionFields }
					sub={ copy.conditionSub }
					activeSub={ copy.conditionActiveSub }
					actionLabel={ action.label }
					thenLabel={ thenText( action, config, emailTagActive, webhookActive ) }
					onChange={ ( condition ) => setConfig( ( c ) => ( { ...c, condition } ) ) }
				/>
			</div>
		</details>
	) : null;

	if ( presentation === 'inline' ) {
		/* The stack wrapper scopes the inline-only design deltas (island.css)
		 * for BOTH the card and the sibling Advanced panel. */
		return (
			<div className="tta-cfg-inline-stack">
				<div className="tta-cfg-inline">
					<div className="tta-cfg-inline-header">{ headerContent }</div>
					<div className="tta-cfg-inline-body">{ bodyContent }</div>
					{ toastContent }
					{ ! hideFooter && footerContent && (
						<div className="tta-cfg-inline-footer">{ footerContent }</div>
					) }
				</div>
				{ inlineAdvancedContent }
			</div>
		);
	}

	return (
		<Modal open={ open } onClose={ onCancel } size="lg" container={ container }>
			<Modal.Header>{ headerContent }</Modal.Header>
			<Modal.Body>{ bodyContent }</Modal.Body>
			{ toastContent }
			{ ! hideFooter && footerContent && <Modal.Footer>{ footerContent }</Modal.Footer> }
		</Modal>
	);
} );

export default ActionConfigurator;

function subOpDesc( action: ActionDescriptor, id: string | null ) {
	return action.subOperations?.find( ( o ) => o.id === id )?.description ?? null;
}

/**
 * Delay amount as the TimingCard stores it: whole number, floored at 1 and
 * capped at 9999 (#4061). Exported for the unit test (#4671); behaviour is
 * the inline expression it replaced, including NaN for non-numeric input
 * the NumberInput never produces.
 */
export function clampDelayAmount( raw: string ): number {
	return Math.min( 9999, Math.max( 1, parseInt( raw || '1', 10 ) ) );
}

function targetPrompt( action: ActionDescriptor | undefined, subOp: string | null ) {
	if ( ! action ) {
		return __( 'Pick a target first.', 'thrive-cb' );
	}
	return ( subOp && action.targetPromptByOp?.[ subOp ] ) || action.targetPrompt;
}

function targetHelp( action: ActionDescriptor, subOp: string | null ) {
	return ( subOp && action.targetHelpByOp?.[ subOp ] ) || action.targetHelp;
}

/** THEN-row fragment ("grant them access to X") - prototype ifThenActionLabel(). */
function thenText( action: ActionDescriptor, config: ActionConfig, composeEmailTag = false, composeWebhook = false ) {
	const template = action.thenByOp?.[ config.subOperation ?? '' ];
	if ( ! template ) {
		return summaryText( action, config, composeEmailTag, composeWebhook );
	}
	return template.replace(
		'%target%',
		config.target?.label ?? action.thenFallbackTarget ?? __( 'the selected target', 'thrive-cb' )
	);
}

/**
 * Normalizes a `getConditionFields` result to `{ value, label }` pairs - a
 * plain string entry becomes its own label; an already-labeled pair passes
 * through.
 */
function normalizeFieldOptions( fields: ConditionFieldOption[] ): Exclude<ConditionFieldOption, string>[] {
	return fields.map( ( f ) => ( typeof f === 'string' ? { value: f, label: f } : f ) );
}

/** The rule names a field the host's (loaded, non-empty) field list no longer has. */
function isConditionFieldMissing( condition: ConditionConfig, fields: ConditionFieldOption[] ): boolean {
	const field = String( condition.field ?? '' ).trim();
	return fields.length > 0 && field !== '' && ! normalizeFieldOptions( fields ).some( ( o ) => o.value === field );
}

/**
 * Bolds the action's own name inside the THEN fragment when the catalog
 * template embeds it literally rather than via `%target%` (e.g. "Run Apply
 * email tag.") - #4055 QA fix. Deliberately minimal: a plain substring
 * search, no marker syntax. Templates that reference the target instead
 * (Ultimatum/Grant Apprentice access) simply don't match and render as
 * plain text, same as before.
 */
function boldenLabel( text: string, label: string ) {
	const index = label ? text.indexOf( label ) : -1;
	if ( index === -1 ) {
		return text;
	}
	return (
		<>
			{ text.slice( 0, index ) }
			<strong>{ label }</strong>
			{ text.slice( index + label.length ) }
		</>
	);
}

/**
 * Collapsed-state sub-line for the inline "Advanced settings" accordion
 * (#4055 Task 10 QA fix): once either card is on, compose a short recap
 * ("Delayed 2 days · Condition added") instead of the generic invite text.
 */
function advancedSubText( config: ActionConfig, hostSub?: string ): string {
	const parts: string[] = [];
	if ( config.timing ) {
		/* translators: 1: a number of time units, 2: the unit name (days, hours...) */
		parts.push( sprintf( __( 'Delayed %1$d %2$s', 'thrive-cb' ), config.timing.amount, TIMING_UNIT_LABELS[ config.timing.unit ] ) );
	}
	if ( config.condition ) {
		parts.push( __( 'Condition added', 'thrive-cb' ) );
	}
	if ( parts.length ) {
		return parts.join( ' · ' );
	}
	return hostSub ?? __( 'Optional — add a time delay or a condition before this action fires.', 'thrive-cb' );
}

/** Live readout - the test-without-executing affordance (Design Decision #4). */
function summaryText( action: ActionDescriptor, config: ActionConfig, composeEmailTag = false, composeWebhook = false ) {
	/* Email tag composes its own line ("Tag a, b in ESP (list)", #4058) once a
	 * tag is committed; before that it falls through to the catalog template.
	 * Gated on the same adapter-trio flag that renders EmailTagFields - a host
	 * without the form (the TAR modal) keeps its own template verbatim. */
	if ( composeEmailTag && action.id === 'email_tag' ) {
		const composed = emailTagSummary( config );
		if ( composed ) {
			return composed;
		}
	}
	/* Webhook composes its own line ("Send a POST webhook to https://…",
	 * #4059) once a URL is entered; same gating idea as email-tag above. */
	if ( composeWebhook && action.id === 'webhook' ) {
		const composed = webhookSummary( config );
		if ( composed ) {
			return composed;
		}
	}
	if ( ! action.noTarget && ! config.target ) {
		return action.summaryPrompt ?? __( 'Pick a target to see the preview.', 'thrive-cb' );
	}
	const template = action.summaryByOp[ config.subOperation ?? '' ] ?? '';
	return template.replace( '%target%', config.target?.label ?? '' );
}

/** Prototype toggle switch (40x20) with the uppercase Off/On state label. */
function ToggleSwitch( { on, onToggle, label }: { on: boolean; onToggle: () => void; label: string } ) {
	return (
		<span className="tta-tcard-switch-group">
			<span className="tta-tcard-state-label">{ on ? __( 'On', 'thrive-cb' ) : __( 'Off', 'thrive-cb' ) }</span>
			<button
				type="button"
				role="switch"
				aria-checked={ on }
				aria-label={ label }
				className={ `tta-toggle-switch${ on ? ' is-on' : '' }` }
				onClick={ onToggle }
			>
				<span className="tta-toggle-switch-knob">
					<svg width="9" height="9" viewBox="0 0 9 9" fill="none">
						<path d="M1.2 4.6L3.6 7L7.8 2" stroke="#4bb35e" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
					</svg>
				</span>
			</button>
		</span>
	);
}

function TimingCard( {
	cardRef,
	timing,
	help,
	unitLabels,
	controlSize,
	activeSub,
	onChange,
}: {
	/** #4061 review: lets a host route a server-side `timing` field error to
	 * this card, mirroring `ConditionCard`'s `cardRef`. */
	cardRef?: RefObject<HTMLDivElement | null>;
	timing: TimingConfig | null;
	/** Host copy override for the line under the delay inputs. Empty string
	 * ('' - not undefined) suppresses the line entirely; undefined keeps the
	 * default 'after form submission'. */
	help?: string;
	/**
	 * Host copy override: display labels for the unit Select (e.g.
	 * { days: 'Days' }) instead of the component's plain unit words. The
	 * round-trip (label -> unit) still resolves against this map. Undefined
	 * keeps the plain-word options.
	 */
	unitLabels?: Record<TimingConfig[ 'unit' ], string>;
	/** See ActionConfiguratorProps.controlSize. */
	controlSize?: 'md' | 'lg';
	/**
	 * Host copy override (#4055 QA fix): sprintf template with %1$d the
	 * amount and %2$s the plain unit word (TIMING_UNIT_LABELS, e.g. 'days') -
	 * rendered instead of the static sub-line while timing is on. Undefined
	 * keeps today's static sub-line regardless of state.
	 */
	activeSub?: string;
	onChange: ( t: TimingConfig | null ) => void;
} ) {
	const on = !! timing;
	const unitWord = ( u: TimingConfig[ 'unit' ] ) => unitLabels?.[ u ] ?? TIMING_UNIT_LABELS[ u ];
	const sub = ( on && activeSub && timing )
		? formatDynamic( activeSub, timing.amount, TIMING_UNIT_LABELS[ timing.unit ] )
		: __( 'Wait a set amount of time before the action fires', 'thrive-cb' );
	return (
		<div ref={ cardRef } className={ `tta-tcard${ on ? '' : ' is-off' }` }>
			<div className="tta-tcard-head">
				<div className="tta-tcard-labels">
					<span className="tta-tcard-title">{ __( 'Time delay', 'thrive-cb' ) }</span>
					<span className="tta-tcard-sub">{ sub }</span>
				</div>
				<ToggleSwitch
					on={ on }
					label={ __( 'Time delay', 'thrive-cb' ) }
					onToggle={ () => onChange( on ? null : { amount: 2, unit: 'days' } ) }
				/>
			</div>
			{ timing && (
				<div className="tta-tcard-body">
					<label className="tta-cfg-label">{ __( 'When should this fire?', 'thrive-cb' ) }</label>
					<div className="tta-delay-grid">
						<NumberInput
							value={ timing.amount }
							min={ 1 }
							max={ 9999 }
							size="md"
							onChange={ ( v ) => onChange( { ...timing, amount: clampDelayAmount( v ) } ) }
						/>
						<Select
							size={ controlSize }
							options={ TIMING_UNITS.map( ( u ) => unitWord( u ) ) }
							value={ [ unitWord( timing.unit ) ] }
							onChange={ ( sel ) => {
								const unit = TIMING_UNITS.find( ( u ) => unitWord( u ) === sel[ 0 ] ) ?? 'hours';
								onChange( { ...timing, unit: unit as TimingConfig[ 'unit' ] } );
							} }
						/>
					</div>
					{ help !== '' && (
						<span className="tta-cfg-help">{ help ?? __( 'after form submission', 'thrive-cb' ) }</span>
					) }
				</div>
			) }
		</div>
	);
}

function ConditionCard( {
	cardRef,
	error = false,
	condition,
	fields,
	controlSize,
	missingFieldText,
	sub,
	activeSub,
	actionLabel,
	thenLabel,
	onChange,
}: {
	/** Lets save() scroll the card into view when it refuses the rule. */
	cardRef?: RefObject<HTMLDivElement | null>;
	/** #4055 QA follow-up: save() refused the rule as incomplete - the card
	 * takes is-error (title colour) and the empty field / value control gets
	 * aria-invalid, which the CSS keys its red border off. */
	error?: boolean;
	condition: ConditionConfig | null;
	/** Plain strings or `{ value, label }` pairs - see `ConditionFieldOption`. */
	fields: ConditionFieldOption[];
	/** See ActionConfiguratorProps.controlSize. */
	controlSize?: 'md' | 'lg';
	/** See copy.conditionFieldMissing. Set: a field that left the form is
	 * marked invalid (no message under the row). Undefined: no check. */
	missingFieldText?: string;
	/** Host copy override for the card's sub-line. */
	sub?: string;
	/**
	 * Host copy override (#4055 QA fix): sprintf template with %1$s the
	 * field, %2$s the operator's human label ("equals", "contains"...) and
	 * %3$s the value - rendered instead of the static sub-line once a
	 * condition is on AND its field is set. Undefined, or a condition with no
	 * field yet, keeps today's static sub-line.
	 */
	activeSub?: string;
	/** The picked action's catalog label - used only to bold its occurrence
	 * inside `thenLabel`, see `boldenLabel()`. */
	actionLabel: string;
	thenLabel: string;
	onChange: ( c: ConditionConfig | null ) => void;
} ) {
	const on = !! condition;
	/* Round-trip: the Select displays/picks LABELS, `condition.field` always
	 * stores the evaluable VALUE. A stored value with no matching option (e.g.
	 * a field the host later removed) falls back to the label saved with the
	 * rule, then to the raw value itself, same as a plain-string option would
	 * (#4052 QA). */
	const fieldOptions = normalizeFieldOptions( fields );
	const fieldLabelFor = ( value: string ) =>
		fieldOptions.find( ( o ) => o.value === value )?.label ??
		( value === condition?.field && condition?.fieldLabel ? condition.fieldLabel : value );
	const fieldValueFor = ( label: string ) => fieldOptions.find( ( o ) => o.label === label )?.value ?? label;
	/* Operators follow the picked field's type (#4052, see conditionOps.ts):
	 * a checkbox group reads includes / does not include, option fields drop
	 * "contains". A rule saved before that with "contains" keeps it on the list,
	 * so opening it changes nothing. Hosts without fieldType keep all three. */
	const fieldTypeOf = ( value: string ) => fieldOptions.find( ( o ) => o.value === value )?.fieldType;
	const opFieldType = condition ? fieldTypeOf( condition.field ) : undefined;
	const opValues = conditionOpsFor( opFieldType );
	const offeredOps = condition && ! opValues.includes( condition.op ) ? [ ...opValues, condition.op ] : opValues;
	const opOf = ( label: string ) => offeredOps.find( ( op ) => conditionOpLabel( op, opFieldType ) === label ) ?? 'equals';
	const opLabel = conditionOpLabel( condition?.op ?? 'equals', opFieldType );
	/* A field with its own choices (checkbox, radio, dropdown) picks the value
	 * from them (#4052 QA, Finding 5) - except for "contains", which matches
	 * part of a value and stays free text. Fields without choices, and every
	 * host that sends none, keep the text box. */
	const pickedField = condition ? fieldOptions.find( ( o ) => o.value === condition.field ) : undefined;
	const valueOptions = condition && condition.op !== 'contains' && pickedField?.options?.length ? pickedField.options : null;
	const valueLabelFor = ( value: string ) => valueOptions?.find( ( o ) => o.value === value )?.label ?? value;
	const valueFor = ( label: string ) => valueOptions?.find( ( o ) => o.label === label )?.value ?? label;
	const fieldMissing = !! missingFieldText && !! condition && isConditionFieldMissing( condition, fields );
	const sublineText = ( on && activeSub && condition?.field )
		? formatDynamic( activeSub, fieldLabelFor( condition.field ), opLabel, condition.value )
		: ( sub ?? __( 'Only fire when a form field matches a value', 'thrive-cb' ) );
	const fieldEmpty = error && String( condition?.field ?? '' ).trim() === '';
	const valueEmpty = error && String( condition?.value ?? '' ).trim() === '';
	const cardClass = [ 'tta-tcard', on ? '' : 'is-off', error ? 'is-error' : '' ].filter( Boolean ).join( ' ' );
	return (
		<div ref={ cardRef } className={ cardClass }>
			<div className="tta-tcard-head">
				<div className="tta-tcard-labels">
					<span className="tta-tcard-title">{ __( 'Add a condition', 'thrive-cb' ) }</span>
					<span className="tta-tcard-sub">{ sublineText }</span>
				</div>
				<ToggleSwitch
					on={ on }
					label={ __( 'Add a condition', 'thrive-cb' ) }
					onToggle={ () => onChange( on ? null : { field: '', op: 'equals', value: '' } ) }
				/>
			</div>
			{ condition && (
				<div className="tta-tcard-body">
					<div className="tta-ifthen-row">
						<span className="tta-ifthen-kw">{ __( 'IF', 'thrive-cb' ) }</span>
						<div className="tta-cond-grid">
							{ fields.length ? (
								<Select
									size={ controlSize }
									options={ fieldOptions.map( ( o ) => o.label ) }
									value={ condition.field ? [ fieldLabelFor( condition.field ) ] : [] }
									placeholder={ __( 'field', 'thrive-cb' ) }
									aria-invalid={ fieldMissing || fieldEmpty || undefined }
									onChange={ ( sel ) =>
										/* Changing the field resets the value (STATES.md condition edge case).
										 * The Select reports the picked LABEL - resolve it back to the stored
										 * VALUE before writing config.field. */
									{
										const field = sel[ 0 ] ? fieldValueFor( sel[ 0 ] ) : '';
										/* An operator the new field doesn't offer (e.g. "contains"
										 * moving to a checkbox) falls back to equals. */
										const op = conditionOpsFor( fieldTypeOf( field ) ).includes( condition.op ) ? condition.op : 'equals';
										onChange( { ...condition, field, op, value: '' } );
									}
									}
								/>
							) : (
								<Input
									as="input"
									size={ controlSize }
									placeholder={ __( 'field', 'thrive-cb' ) }
									aria-invalid={ fieldEmpty || undefined }
									value={ condition.field }
									onChange={ ( v: string ) => onChange( { ...condition, field: v } ) }
								/>
							) }
							<Select
								size={ controlSize }
								options={ offeredOps.map( ( op ) => conditionOpLabel( op, opFieldType ) ) }
								value={ [ opLabel ] }
								onChange={ ( sel ) =>
									onChange( { ...condition, op: opOf( sel[ 0 ] ?? '' ), value: '' } )
								}
							/>
							{ valueOptions ? (
								<Select
									size={ controlSize }
									options={ valueOptions.map( ( o ) => o.label ) }
									value={ condition.value ? [ valueLabelFor( condition.value ) ] : [] }
									placeholder={ __( 'value', 'thrive-cb' ) }
									aria-invalid={ valueEmpty || undefined }
									/* Show the option's label, store its submitted value. */
									onChange={ ( sel ) => onChange( { ...condition, value: sel[ 0 ] ? valueFor( sel[ 0 ] ) : '' } ) }
								/>
							) : (
								<Input
									as="input"
									size={ controlSize }
									placeholder={ __( 'value', 'thrive-cb' ) }
									aria-invalid={ valueEmpty || undefined }
									value={ condition.value }
									onChange={ ( v: string ) => onChange( { ...condition, value: v } ) }
								/>
							) }
						</div>
					</div>
					<div className="tta-ifthen-row">
						<span className="tta-ifthen-kw tta-ifthen-kw--then">{ __( 'THEN', 'thrive-cb' ) }</span>
						<div className="tta-ifthen-then">{ boldenLabel( thenLabel, actionLabel ) }</div>
					</div>
				</div>
			) }
		</div>
	);
}
