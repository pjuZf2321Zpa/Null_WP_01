/**
 * Editor-side data access for the Thrive Actions island (#3535/#4047).
 *
 * The action catalog is NOT defined here: every registered executor describes
 * itself in PHP (TTA_Action::get_presentation()) and TAR serves the assembled
 * list, inlined into TTA_EDITOR_BOOT. This module only attaches the bundled
 * brand artwork - design assets that belong in the bundle, not in a REST
 * payload - and exposes the REST adapters.
 */
import type { ActionDescriptor, ConfiguratorAdapters, SubOperation, TargetOption } from './ActionConfigurator/types';
import apprenticeCard from './assets/ta-apprentice-card.png';
import optimizeCard from './assets/ta-optimize-card.png';
import ultimatumCard from './assets/ta-ultimatum-card.png';
import ovationCard from './assets/ta-ovation-card.png';
import subopGrant from './assets/subop-grant.png';
import subopRevoke from './assets/subop-revoke.png';
import subopStart from './assets/subop-start.png';
import subopStop from './assets/subop-stop.png';

export interface EditorBoot {
	restBase: string;
	nonce: string;
	plugins: { apprentice: boolean; ultimatum: boolean; ovation: boolean; optimize: boolean };
	/** Action descriptors from the executor registry, minus the artwork. */
	catalog?: ActionDescriptor[];
	/** The site's time zone: IANA name ('' on offset-only sites) and UTC offset in hours. */
	timezone?: { string: string; offset: number };
	/** The editing user's WordPress locale, e.g. 'en_US'. */
	locale?: string;
	/** Submission Log row count per form settings id, for the forms the edited page owns. Forms with no rows are absent. */
	logCounts?: Record<string, number>;
}

function getBoot(): EditorBoot | null {
	return window.TTA_EDITOR_BOOT ?? null;
}

/**
 * The row count the editor boot data carries for a form, or 0 when it has
 * none listed (no history, or a form the page does not own).
 */
export function bootLogCount( formSettingsId: number ): number {
	return Number( getBoot()?.logCounts?.[ formSettingsId ] ) || 0;
}

/* Brand artwork stays client-side, keyed by action id: it is design asset,
 * not action data, and the executors have no business shipping base64 PNGs. */
const ACTION_IMAGES: Record<string, string> = {
	apprentice_access: apprenticeCard,
	ultimatum_campaign: ultimatumCard,
	ovation_request: ovationCard,
	optimize_conversion: optimizeCard,
};

const SUB_OP_IMAGES: Record<string, string> = {
	'apprentice_access:grant': subopGrant,
	'apprentice_access:revoke': subopRevoke,
	'ultimatum_campaign:start': subopStart,
	'ultimatum_campaign:stop': subopStop,
};

/**
 * The catalog the configurator renders: PHP decides what exists, what is
 * locked and what is hidden; the bundle only dresses it with artwork.
 * Synchronous by design - saved cards and log rows resolve action names while
 * rendering, and a fetch here would flash raw action ids on first paint.
 */
export function getCatalog(): ActionDescriptor[] {
	const boot = getBoot();

	return ( boot?.catalog ?? [] ).map( ( action ) => ( {
		...action,
		image: ACTION_IMAGES[ action.id ],
		subOperations: action.subOperations?.map( ( subOp: SubOperation ) => ( {
			...subOp,
			image: SUB_OP_IMAGES[ `${ action.id }:${ subOp.id }` ],
		} ) ),
	} ) );
}

/* --------------------------------------------------------- real adapters */

async function fetchTargets( actionId: string ): Promise<TargetOption[]> {
	const boot = getBoot();
	if ( ! boot ) {
		return [];
	}
	const response = await fetch(
		`${ boot.restBase }/form-actions/targets?action_id=${ encodeURIComponent( actionId ) }`,
		{ headers: { 'X-WP-Nonce': boot.nonce }, credentials: 'same-origin' }
	);
	/* A rejected request must surface as an error state, never as the same
	 * empty list a target-less install produces. */
	if ( ! response.ok ) {
		throw new Error( `targets request failed (${ response.status })` );
	}
	const body = await response.json();
	return Array.isArray( body.items ) ? body.items : [];
}

export const restAdapters: ConfiguratorAdapters = {
	getTargets: ( actionId: string ) => fetchTargets( actionId ),
};

/**
 * The per-row detail written by the dispatcher and executors. Every field is
 * optional: each outcome contributes its own keys (condition values on a skip,
 * fire_at on a scheduled row, message/data on a run), and the drawer renders
 * whichever are present.
 */
export interface LogDetail {
	message?: string;
	/** Failure follow-up copy, when the executor supplies one. */
	next?: string;
	/** Scheduled run cancelled because its action was edited or removed. */
	cancelled?: boolean;
	/** Unix seconds a scheduled run is due to fire. */
	fire_at?: number;
	/** Evaluated condition values on a skipped row (#4052). */
	field?: string;
	/** The field's label when the rule was saved (#4052 QA). */
	field_label?: string;
	op?: string;
	expected?: string;
	/** null when the field was not submitted; a list for checkbox groups. */
	actual?: string | number | boolean | null | Array<string | number>;
	/** Apprentice grant created the WP user from the submitted email. */
	user_created?: boolean;
	/** The run succeeded but changed nothing - the state it asked for already
	 * held (#4047 QA). A fired row must not claim work it did not do. */
	no_change?: boolean;
	/** Config snapshot taken at dispatch, so rows survive edits/removals. */
	_action?: {
		sub_operation?: string | null;
		target_label?: string;
		timing?: { amount: number; unit: string } | null;
	};
}

/* Submission-log rows for one form (#4053). Shape mirrors the REST route. */
export interface LogEntry {
	id: number;
	ts: number;
	outcome: 'scheduled' | 'fired' | 'skipped' | 'failed';
	action: string;
	email: string;
	wp_user: string;
	detail: LogDetail;
}

export async function fetchLogs( formSettingsId: number ): Promise<{ entries: LogEntry[]; cap: number }> {
	const boot = getBoot();
	if ( ! boot || ! formSettingsId ) {
		return { entries: [], cap: 100 };
	}
	const response = await fetch(
		`${ boot.restBase }/form-actions/logs?form_settings_id=${ formSettingsId }`,
		{ headers: { 'X-WP-Nonce': boot.nonce }, credentials: 'same-origin' }
	);
	if ( ! response.ok ) {
		throw new Error( `logs request failed (${ response.status })` );
	}
	const body = await response.json();
	return { entries: Array.isArray( body.entries ) ? body.entries : [], cap: body.cap ?? 100 };
}
