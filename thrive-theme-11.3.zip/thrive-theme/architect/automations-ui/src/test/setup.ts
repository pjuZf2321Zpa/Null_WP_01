import { expect, afterEach, vi } from 'vitest';
import { cleanup } from '@testing-library/react';
import * as matchers from '@testing-library/jest-dom/matchers';

expect.extend( matchers );

afterEach( () => {
	cleanup();
} );

/* jsdom implements neither. The configurator's save() and revealAdvanced()
 * scroll a card into view; ui-components controls may read matchMedia. */
Element.prototype.scrollIntoView = vi.fn();

Object.defineProperty( window, 'matchMedia', {
	writable: true,
	value: vi.fn().mockImplementation( ( query: string ) => ( {
		matches: false,
		media: query,
		onchange: null,
		addListener: vi.fn(),
		removeListener: vi.fn(),
		addEventListener: vi.fn(),
		removeEventListener: vi.fn(),
		dispatchEvent: vi.fn(),
	} ) ),
} );
