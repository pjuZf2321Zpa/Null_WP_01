import { createRef } from 'react';
import { act, render } from '@testing-library/react';
import { vi } from 'vitest';
import ActionConfigurator from '../ActionConfigurator/ActionConfigurator';
import type {
	ActionConfig,
	ActionConfiguratorHandle,
	ActionDescriptor,
	ConfiguratorAdapters,
	TargetOption,
} from '../ActionConfigurator/types';

export const TARGET: TargetOption = { id: 7, label: 'Course A' };

/* A minimal single-operation action with a target picker, so canContinue()
 * depends only on config.target. */
export const ACTION: ActionDescriptor = {
	id: 'grant',
	label: 'Grant access',
	description: 'Grant a product',
	targetPrompt: 'Grant access to',
	targetPlaceholder: 'Pick a product',
	summaryByOp: { '': 'Grant access to %target%' },
};

export function baseConfig( overrides: Partial<ActionConfig> = {} ): ActionConfig {
	return {
		actionId: ACTION.id,
		subOperation: null,
		target: TARGET,
		timing: null,
		condition: null,
		extra: null,
		...overrides,
	};
}

/* Inline presentation + hideFooter + ref: the Apprentice Triggers island's
 * mount shape, where save() runs through the imperative handle. `getTargets`
 * and `getConditionFields` resolve after mount, so the state updates they
 * drive land on the microtask queue after render() returns - flush them
 * inside act() here rather than leaving every caller to trip over "not
 * wrapped in act(...)" warnings. Two ticks, not one: getTargets and
 * getConditionFields each resolve in their own microtask, and their .then
 * state updates each need a further tick to land, so a single flush only
 * catches the first of the two. */
export async function renderConfigurator( value: ActionConfig ) {
	const ref = createRef<ActionConfiguratorHandle>();
	const onSave = vi.fn();
	const onToast = vi.fn();
	const adapters: ConfiguratorAdapters = {
		getTargets: () => Promise.resolve( [ TARGET ] ),
		getConditionFields: () => Promise.resolve( [ 'email', 'user_id' ] ),
	};
	const result = render(
		<ActionConfigurator
			ref={ ref }
			open
			presentation="inline"
			hideFooter
			mode="add"
			actions={ [ ACTION ] }
			adapters={ adapters }
			value={ value }
			onSave={ onSave }
			onCancel={ () => {} }
			onToast={ onToast }
		/>
	);
	await act( async () => {
		await Promise.resolve();
	} );
	await act( async () => {
		await Promise.resolve();
	} );
	return { ref, onSave, onToast, ...result };
}

/* Replaces requestAnimationFrame with a queue the test drains by hand, so the
 * configurator's two-frame "open the panel, then scroll" ordering is asserted
 * rather than waited on. cancelAnimationFrame removes a queued callback. */
export function installFrameQueue() {
	const queue = new Map<number, FrameRequestCallback>();
	let nextId = 1;
	const raf = vi.spyOn( window, 'requestAnimationFrame' ).mockImplementation( ( cb ) => {
		const id = nextId++;
		queue.set( id, cb );
		return id;
	} );
	const caf = vi.spyOn( window, 'cancelAnimationFrame' ).mockImplementation( ( id ) => {
		queue.delete( id );
	} );
	return {
		flush: () => {
			const callbacks = Array.from( queue.values() );
			queue.clear();
			act( () => {
				callbacks.forEach( ( cb ) => cb( 0 ) );
			} );
		},
		pending: () => queue.size,
		restore: () => {
			raf.mockRestore();
			caf.mockRestore();
		},
	};
}

export function cardByTitle( container: HTMLElement, title: string ): HTMLElement {
	const card = Array.from( container.querySelectorAll<HTMLElement>( '.tta-tcard' ) )
		.find( ( el ) => el.querySelector( '.tta-tcard-title' )?.textContent === title );
	if ( ! card ) {
		throw new Error( `No .tta-tcard titled "${ title }"` );
	}
	return card;
}

export function advancedPanel( container: HTMLElement ): HTMLDetailsElement {
	const details = container.querySelector<HTMLDetailsElement>( 'details.tta-cfg-advanced' );
	if ( ! details ) {
		throw new Error( 'Advanced panel not rendered' );
	}
	return details;
}
