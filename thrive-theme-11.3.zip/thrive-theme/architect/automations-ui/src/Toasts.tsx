/**
 * Toast surfaces (#3535 design parity).
 *
 * The prototype has one toast system: a dark pill fixed to the bottom of the
 * viewport, used for save confirmations, validation refusals and the undo
 * offer after a removal. The build had none of it - successes were silent,
 * validation errors rendered as a red box absolutely positioned inside the
 * configurator, and the undo offer was an inline block in the sidebar panel.
 *
 * Markup and class names are kept 1:1 with the prototype (see island.css),
 * so a designer can diff the two side by side.
 */
import { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import { __ } from '@wordpress/i18n';

/* Prototype: toast(msg, kind, duration = 2400), fade-out over 220ms. */
const TOAST_MS = 2400;
const FADE_MS = 220;
/* "You'll have 8 seconds to undo right after." - the remove-confirm copy. */
const UNDO_MS = 8000;

/** Drives the prototype's `--in` class: mount transparent, fade in next frame. */
function useFadeIn( active: boolean ) {
	const [ shown, setShown ] = useState( false );
	useEffect( () => {
		if ( ! active ) {
			setShown( false );
			return;
		}
		const raf = requestAnimationFrame( () => setShown( true ) );
		return () => cancelAnimationFrame( raf );
	}, [ active ] );
	return shown;
}

interface ToastProps {
	message: string;
	/** Defaults to 'error', matching ActionConfiguratorProps.onToast. */
	kind?: 'error' | 'success';
	onDone: () => void;
}

/**
 * A single transient notice. The prototype styles every kind identically
 * (only `--in` exists in its CSS), so there is no per-kind variant here -
 * but a validation refusal still has to reach assistive tech as an alert
 * rather than a passive status, so `kind` drives the role (#4047 review).
 */
export function Toast( { message, kind = 'error', onDone }: ToastProps ) {
	const shown = useFadeIn( true );
	const [ leaving, setLeaving ] = useState( false );

	useEffect( () => {
		const hide = setTimeout( () => setLeaving( true ), TOAST_MS );
		const drop = setTimeout( onDone, TOAST_MS + FADE_MS );
		return () => {
			clearTimeout( hide );
			clearTimeout( drop );
		};
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [] );

	return createPortal(
		<div
			className={ `tcb-ta-toast${ shown && ! leaving ? ' tcb-ta-toast--in' : '' }` }
			role={ kind === 'success' ? 'status' : 'alert' }
		>
			{ message }
		</div>,
		document.body
	);
}

interface UndoToastProps {
	onUndo: () => void;
	onDismiss: () => void;
}

/**
 * The undo offer after a removal. Floating and dismissible per the design -
 * the build previously rendered this inline in the sidebar panel with no way
 * to dismiss it.
 */
export function UndoToast( { onUndo, onDismiss }: UndoToastProps ) {
	const shown = useFadeIn( true );

	useEffect( () => {
		const t = setTimeout( onDismiss, UNDO_MS );
		return () => clearTimeout( t );
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [] );

	return createPortal(
		<div className={ `tcb-ta-undo${ shown ? ' tcb-ta-undo--in' : '' }` } role="status">
			<span>{ __( 'Action removed.', 'thrive-cb' ) }</span>
			<button type="button" className="tcb-ta-undo__link" onClick={ onUndo }>
				{ __( 'Undo', 'thrive-cb' ) }
			</button>
			<button
				type="button"
				className="tcb-ta-undo__close"
				onClick={ onDismiss }
				aria-label={ __( 'Dismiss', 'thrive-cb' ) }
			>
				&times;
			</button>
		</div>,
		document.body
	);
}
