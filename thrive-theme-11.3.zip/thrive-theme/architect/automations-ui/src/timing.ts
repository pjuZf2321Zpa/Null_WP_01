/**
 * "1 minute", "3 days" - a delay as a translated phrase (#4051 QA, Finding 3:
 * the Submission Log read "1 minutes"). Whole-phrase plurals rather than a
 * pluralised unit word, so languages that inflect around the number get it
 * right.
 */
import { _n, sprintf } from '@wordpress/i18n';

export function delayPhrase( amount: number, unit: string ): string {
	switch ( unit ) {
		case 'minutes':
			/* translators: %d: number of minutes */
			return sprintf( _n( '%d minute', '%d minutes', amount, 'thrive-cb' ), amount );
		case 'hours':
			/* translators: %d: number of hours */
			return sprintf( _n( '%d hour', '%d hours', amount, 'thrive-cb' ), amount );
		case 'days':
			/* translators: %d: number of days */
			return sprintf( _n( '%d day', '%d days', amount, 'thrive-cb' ), amount );
		case 'weeks':
			/* translators: %d: number of weeks */
			return sprintf( _n( '%d week', '%d weeks', amount, 'thrive-cb' ), amount );
		case 'months':
			/* translators: %d: number of months */
			return sprintf( _n( '%d month', '%d months', amount, 'thrive-cb' ), amount );
		default:
			/* Log rows are snapshots - an unknown unit is shown as stored. */
			return `${ amount } ${ unit }`;
	}
}

/**
 * The bare unit word for an amount - "day" for 1, "days" otherwise - for
 * templates that place the number themselves ("Delayed by %1$d %2$s"). Prefer
 * delayPhrase() for new copy; this keeps existing host templates working
 * without "1 days" (#4055 surface, #4051 QA Finding 3).
 */
export function delayUnitWord( amount: number, unit: string ): string {
	switch ( unit ) {
		case 'minutes':
			return _n( 'minute', 'minutes', amount, 'thrive-cb' );
		case 'hours':
			return _n( 'hour', 'hours', amount, 'thrive-cb' );
		case 'days':
			return _n( 'day', 'days', amount, 'thrive-cb' );
		case 'weeks':
			return _n( 'week', 'weeks', amount, 'thrive-cb' );
		case 'months':
			return _n( 'month', 'months', amount, 'thrive-cb' );
		default:
			return unit;
	}
}
