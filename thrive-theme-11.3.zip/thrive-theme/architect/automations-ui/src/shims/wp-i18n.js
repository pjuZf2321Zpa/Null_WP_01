// Demo-only shim for the ui-components bundle's @wordpress/i18n external.
export const __ = ( s ) => s;
export const _x = ( s ) => s;
export const _n = ( single, plural, n ) => ( n === 1 ? single : plural );
export const sprintf = ( fmt, ...args ) => fmt.replace( /%[sd]/g, () => String( args.shift() ) );
