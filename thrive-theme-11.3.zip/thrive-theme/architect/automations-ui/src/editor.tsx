/**
 * Editor island entry (#4047): the Thrive Actions tab experience inside TAR.
 *
 * Persistence follows the house pattern (webhooks settings-adapter): the
 * config lives in a hidden input inside the form element, so it saves with
 * the post content and the frontend/submit handler can read it server-side.
 *
 * Boundary: Backbone owns the panel and tab switching (untouched); this file
 * owns the pane's list UI and the configurator modal. Data lives on the form
 * element, never in Backbone models or React state between sessions.
 */
import { StrictMode, useEffect, useId, useRef, useState, type KeyboardEvent as ReactKeyboardEvent, type ReactNode } from 'react';
import { createPortal } from 'react-dom';
import { createRoot, type Root } from 'react-dom/client';
import { __, sprintf } from '@wordpress/i18n';
import { delayPhrase } from './timing';
import { conditionOpLabel } from './ActionConfigurator/conditionOps';
import { Button } from '@thrive-themes/ui-components';
import ActionConfigurator from './ActionConfigurator/ActionConfigurator';
import SubmissionLog from './SubmissionLog';
import { Toast, UndoToast } from './Toasts';
import type { ActionConfig, ConditionFieldOption } from './ActionConfigurator/types';
import { getCatalog, restAdapters, fetchLogs, bootLogCount, type EditorBoot } from './catalog';
import './island.css';
import './architect-overrides.css';

declare global {
	interface Window {
		/* Architect's editor global: a Backbone/jQuery surface with no types
		 * of its own. Narrowing it here would be fiction - every access below
		 * is optional-chained and guarded instead. */
		// eslint-disable-next-line @typescript-eslint/no-explicit-any
		TVE: any;
		/* Server-rendered boot payload (see class-tcb-editor.php). */
		TTA_EDITOR_BOOT?: EditorBoot;
	}
}

const SETTINGS_KEY = 'tta_actions';

/* ------------------------------------------------------------------ store */

/**
 * Actions persist inside the form-settings JSON (the `data-form-settings`
 * blob the editor extracts into the `_tcb_form_settings` post on save). That
 * store is server-authoritative: the frontend submit handler reads it via
 * FormSettings::get_one(), so a visitor cannot tamper with the action list
 * the way they could with a hidden input in the form markup.
 */
// eslint-disable-next-line @typescript-eslint/no-explicit-any -- jQuery collection from the untyped TVE global
function getFormWrapper(): any | null {
	try {
		/* getWrapper throws internally while no LG element is selected. */
		const $form = window.TVE?.Components?.lead_generation?.getWrapper?.( 'form' );
		return $form && $form.length ? $form : null;
	} catch {
		return null;
	}
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any -- Backbone view from the untyped TVE global
function getSettingsView(): any | null {
	try {
		/* The Backbone view bound to the active LG element owns the settings
		 * JSON (its write-sections read-modify-write, preserving foreign keys). */
		const view = window.TVE?.Components?.lead_generation?.leadGenerationView;
		return view && typeof view.__getSettings === 'function' && view.$el?.length ? view : null;
	} catch {
		return null;
	}
}

/**
 * The FormSettings post id backing the selected form (#4053 log scope) -
 * the same `data-settings-id` the frontend submits as `_tcb_id`.
 */
function getFormSettingsId(): number {
	const view = getSettingsView();
	const fromView = Number( view?.$el?.attr?.( 'data-settings-id' ) ) || 0;
	if ( fromView ) {
		return fromView;
	}
	const $form = getFormWrapper();
	return Number( $form?.closest?.( '[data-settings-id]' )?.attr?.( 'data-settings-id' ) ) || 0;
}

function readActions(): ActionConfig[] {
	const view = getSettingsView();
	if ( ! view ) {
		return [];
	}
	const list = view.__getSettings()?.[ SETTINGS_KEY ];
	return Array.isArray( list ) ? list : [];
}

function writeActions( list: ActionConfig[] ) {
	const view = getSettingsView();
	if ( ! view ) {
		return;
	}

	/* Legacy LG markup (pre-FormSettings, __tcb_lg_fc era) has no
	 * data-settings-id. The save-time stamp in models/lead-generation.js
	 * lands on the live DOM only - Leads' clean-content clone is taken
	 * before it, so the attribute never reaches the stored variation and
	 * the frontend submit carries no _tcb_id (actions silently never run).
	 * Stamping here, at action-write time, upgrades legacy markup while
	 * the user is still editing, so every later serialization includes it. */
	if ( view.$el?.length && ! view.$el.attr( 'data-settings-id' ) ) {
		const generated = window.TVE?.CSS_Rule_Cache?.generate_id?.( 'tve-form-' )
			?? `tve-form-${ Math.random().toString( 36 ).slice( 2, 10 ) }`;
		view.$el.attr( 'data-settings-id', generated );
	}

	const settings = view.__getSettings() || {};
	if ( list.length ) {
		settings[ SETTINGS_KEY ] = list;
	} else {
		delete settings[ SETTINGS_KEY ];
	}
	view.__setSettings( settings );
}

/* ------------------------------------------------------- saved-cards list */

function fireLine( config: ActionConfig ): string {
	let when: string = __( 'Fires immediately on submission', 'thrive-cb' );
	if ( config.timing ) {
		/* translators: %s: delay, e.g. "2 days" */
		when = sprintf( __( 'Fires %s after submission', 'thrive-cb' ), delayPhrase( config.timing.amount, config.timing.unit ) );
	}
	const cond = config.condition
		/* translators: 1: form field name, 2: operator (equals/does not equal/contains/includes/does not include), 3: compared value */
		? sprintf( __( 'when %1$s %2$s "%3$s"', 'thrive-cb' ), conditionFieldLabel( config.condition.field, config.condition.fieldLabel ), conditionOpLabel( config.condition.op, conditionFieldType( config.condition.field ) ), config.condition.value )
		: __( 'on every submission', 'thrive-cb' );
	return `${ when } \u00b7 ${ cond }`;
}

/** Card title per the handoff: "Grant Apprentice Access", "End Ultimatum Campaign", "Ovation request". */
function cardTitle( config: ActionConfig ): string {
	const titles: Record<string, string> = {
		'apprentice_access:grant': __( 'Grant Apprentice Access', 'thrive-cb' ),
		'apprentice_access:revoke': __( 'Revoke Apprentice Access', 'thrive-cb' ),
		'ultimatum_campaign:start': __( 'Start Ultimatum Campaign', 'thrive-cb' ),
		'ultimatum_campaign:stop': __( 'End Ultimatum Campaign', 'thrive-cb' ),
		'ovation_request:': __( 'Ovation request', 'thrive-cb' ),
		'optimize_conversion:': __( 'Optimize conversion', 'thrive-cb' ),
	};
	return titles[ `${ config.actionId }:${ config.subOperation ?? '' }` ] ?? config.actionId;
}

interface ListProps {
	onEdit: ( config: ActionConfig, index: number ) => void;
}

/**
 * A saved card's "can't run" line (#4047, Rijul's "Won't run" design, also
 * used for #4052's missing field): the fix is a link inside the sentence.
 * With `url` it leaves the editor (Thrive Product Manager) in a new tab, so
 * the editor - possibly with unsaved changes - stays put, and carries the
 * arrow. With `onClick` it stays in the editor (opens the configure step).
 * The sentence is one translatable string split on its %s, so translators
 * keep the whole sentence and the link lands where they put the placeholder.
 */
function LockedWarning( { reason, url, onClick }: { reason: string; url?: string; onClick?: () => void } ) {
	/* translators: %s: how to fix it, e.g. "Activate Thrive Ovation" or "Pick another field" */
	const sentence = __( '%s: until then this action will not run.', 'thrive-cb' );
	/* A translation may use %1$s, or drop the placeholder altogether. With
	 * none, the fix goes before the whole sentence rather than vanishing. */
	const parts = sentence.split( /%(?:1\$)?s/ );
	const [ before, after ] = parts.length > 1 ? [ parts[ 0 ], parts.slice( 1 ).join( '' ) ] : [ '', ' ' + sentence ];

	let fix: ReactNode = reason;
	if ( url ) {
		fix = (
			<a className="tta-locked-link" href={ url } target="_blank" rel="noopener noreferrer">
				{ reason }
				<svg viewBox="0 0 10 10" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
					<path d="M2.5 7.5 7.5 2.5M3.5 2.5h4v4" />
				</svg>
			</a>
		);
	} else if ( onClick ) {
		fix = <button type="button" className="tta-locked-link" onClick={ onClick }>{ reason }</button>;
	}

	return (
		<>
			{ before }
			{ fix }
			{ after }
		</>
	);
}

/**
 * Info icon inside the "Won't run" pill, with a tooltip saying why
 * (#4047). The tip is portalled to <body> and placed from the icon's rect,
 * so the Architect sidebar's overflow can't clip it (the prototype's
 * .tcb-tip approach). Opens on hover and on keyboard focus, closes on
 * Escape (WCAG 1.4.13), and is announced through aria-describedby.
 */
function LockedInfo( { tip }: { tip: string } ) {
	const tipId = useId();
	const btnRef = useRef<HTMLButtonElement>( null );
	const tipRef = useRef<HTMLDivElement>( null );
	const [ open, setOpen ] = useState( false );
	const [ pos, setPos ] = useState<{ left: number; top: number; arrow: number } | null>( null );

	useEffect( () => {
		if ( ! open ) {
			setPos( null );
			return;
		}
		const place = () => {
			const btn = btnRef.current;
			const el = tipRef.current;
			if ( ! btn || ! el ) {
				return;
			}
			const r = btn.getBoundingClientRect();
			const cx = r.left + r.width / 2;
			const left = Math.min( Math.max( 8, cx - el.offsetWidth / 2 ), window.innerWidth - el.offsetWidth - 8 );
			setPos( { left, top: r.top - el.offsetHeight - 8, arrow: cx - left } );
		};
		place();
		window.addEventListener( 'resize', place );
		window.addEventListener( 'scroll', place, true );
		return () => {
			window.removeEventListener( 'resize', place );
			window.removeEventListener( 'scroll', place, true );
		};
	}, [ open ] );

	return (
		<>
			<button
				ref={ btnRef }
				type="button"
				className="tta-locked-info"
				aria-label={ __( "Why this action won't run", 'thrive-cb' ) }
				aria-describedby={ open ? tipId : undefined }
				onMouseEnter={ () => setOpen( true ) }
				onMouseLeave={ () => setOpen( false ) }
				onFocus={ () => setOpen( true ) }
				onBlur={ () => setOpen( false ) }
				onKeyDown={ ( e ) => {
					if ( e.key === 'Escape' && open ) {
						/* Only the tooltip - the modal / pane must not see this Escape. */
						e.stopPropagation();
						setOpen( false );
					}
				} }
			>
				<svg viewBox="0 0 10 10" aria-hidden="true">
					<path fill="currentColor" d="M5.00977 0.9375C3.54492 0.9375 2.2168 1.71875 1.47461 2.96875C0.751953 4.23828 0.751953 5.78125 1.47461 7.03125C2.2168 8.30078 3.54492 9.0625 5.00977 9.0625C6.45508 9.0625 7.7832 8.30078 8.52539 7.03125C9.24805 5.78125 9.24805 4.23828 8.52539 2.96875C7.7832 1.71875 6.45508 0.9375 5.00977 0.9375ZM5.00977 10C3.21289 10 1.57227 9.0625 0.673828 7.5C-0.224609 5.95703 -0.224609 4.0625 0.673828 2.5C1.57227 0.957031 3.21289 0 5.00977 0C6.78711 0 8.42773 0.957031 9.32617 2.5C10.2246 4.0625 10.2246 5.95703 9.32617 7.5C8.42773 9.0625 6.78711 10 5.00977 10ZM4.22852 6.5625H4.69727V5.3125H4.22852C3.95508 5.3125 3.75977 5.11719 3.75977 4.84375C3.75977 4.58984 3.95508 4.375 4.22852 4.375H5.16602C5.41992 4.375 5.63477 4.58984 5.63477 4.84375V6.5625H5.79102C6.04492 6.5625 6.25977 6.77734 6.25977 7.03125C6.25977 7.30469 6.04492 7.5 5.79102 7.5H4.22852C3.95508 7.5 3.75977 7.30469 3.75977 7.03125C3.75977 6.77734 3.95508 6.5625 4.22852 6.5625ZM5.00977 3.75C4.6582 3.75 4.38477 3.47656 4.38477 3.125C4.38477 2.79297 4.6582 2.5 5.00977 2.5C5.3418 2.5 5.63477 2.79297 5.63477 3.125C5.63477 3.47656 5.3418 3.75 5.00977 3.75Z" />
				</svg>
			</button>
			{ open && createPortal(
				<div
					ref={ tipRef }
					id={ tipId }
					role="tooltip"
					className={ `tta-locked-tip${ pos ? ' is-in' : '' }` }
					style={ pos ? { left: pos.left, top: pos.top, [ '--tip-arrow' as string ]: `${ pos.arrow }px` } : { left: -9999, top: -9999 } }
				>
					{ tip }
				</div>,
				document.body
			) }
		</>
	);
}

/* Exported for the island tests; the editor entry mounts it via mountListIfVisible(). */
export function SavedActionsList( { onEdit }: ListProps ) {
	const [ actions, setActions ] = useState<ActionConfig[]>( readActions );
	/* `seq` exists only to key the UndoToast. Its 8s timer is a mount-only
	 * effect, and removing a second action moves this state object straight
	 * from one value to the next - React reconciles the same element, the
	 * effect never re-runs, and the second removal inherits whatever was left
	 * of the first one's window, sometimes under a second. A changing key
	 * remounts it so each removal gets its own 8s (#5481 review). */
	const [ removed, setRemoved ] = useState<{ config: ActionConfig; index: number; seq: number } | null>( null );
	const [ confirming, setConfirming ] = useState<number | null>( null );
	/* Fade state for the confirm modal, same two-flag shape as SubmissionLog. */
	const [ confirmEntering, setConfirmEntering ] = useState( false );
	const confirmDialogRef = useRef<HTMLDivElement>( null );
	const confirmRestoreRef = useRef<HTMLElement | null>( null );

	/* Which form the list shows. Not readable on the first mount after an
	 * editor reload (the LG view does not exist yet), and the list root is
	 * reused when another form is selected - so it is state, refreshed with
	 * the actions, not read once. */
	const [ formId, setFormId ] = useState( getFormSettingsId );

	/* Other parts of the island announce data changes with this event. */
	useEffect( () => {
		const refresh = () => {
			setActions( readActions() );
			setFormId( getFormSettingsId() );
		};
		document.addEventListener( 'tta:actions-changed', refresh );
		return () => document.removeEventListener( 'tta:actions-changed', refresh );
	}, [] );

	/* The undo toast owns its own 8s lifetime (see UndoToast) and reports
	 * expiry through onDismiss, so there is no second timer here. */

	/* Escape closes the confirm, and the overlay fades in on the next frame -
	 * like the prototype's openRemoveModal. The backdrop click is wired in the
	 * JSX below. */
	useEffect( () => {
		if ( confirming === null ) {
			setConfirmEntering( false );
			return;
		}
		const raf = requestAnimationFrame( () => setConfirmEntering( true ) );
		const onEsc = ( e: KeyboardEvent ) => {
			if ( e.key === 'Escape' ) {
				setConfirming( null );
			}
		};
		document.addEventListener( 'keydown', onEsc );
		return () => {
			cancelAnimationFrame( raf );
			document.removeEventListener( 'keydown', onEsc );
		};
	}, [ confirming ] );

	/* Focus moves into the dialog on open and back to the Remove link on close. */
	useEffect( () => {
		if ( confirming === null ) {
			return;
		}
		confirmRestoreRef.current = document.activeElement instanceof HTMLElement ? document.activeElement : null;
		confirmDialogRef.current?.focus();
		return () => confirmRestoreRef.current?.focus();
	}, [ confirming ] );

	/* Tab containment, required of a modal by STATES.md ("Modal traps focus").
	 * Same shape as WebhookFields' diagnostics dialog. */
	const trapConfirmTab = ( event: ReactKeyboardEvent<HTMLDivElement> ) => {
		if ( event.key !== 'Tab' ) {
			return;
		}
		const focusables = confirmDialogRef.current?.querySelectorAll<HTMLElement>( 'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])' );
		if ( ! focusables?.length ) {
			event.preventDefault();
			return;
		}
		const first = focusables[ 0 ];
		const last = focusables[ focusables.length - 1 ];
		if ( event.shiftKey && ( document.activeElement === first || document.activeElement === confirmDialogRef.current ) ) {
			event.preventDefault();
			last.focus();
		} else if ( ! event.shiftKey && ( document.activeElement === last || document.activeElement === confirmDialogRef.current ) ) {
			event.preventDefault();
			first.focus();
		}
	};

	const remove = ( index: number ) => {
		const list = readActions();
		const [ config ] = list.splice( index, 1 );
		writeActions( list );
		setActions( list );
		setConfirming( null );
		setRemoved( ( prev ) => ( { config, index, seq: ( prev?.seq ?? 0 ) + 1 } ) );
		document.dispatchEvent( new CustomEvent( 'tta:actions-changed' ) );
	};

	const undo = () => {
		if ( ! removed ) {
			return;
		}
		const list = readActions();
		list.splice( removed.index, 0, removed.config );
		writeActions( list );
		setActions( list );
		setRemoved( null );
		document.dispatchEvent( new CustomEvent( 'tta:actions-changed' ) );
		/* 'success' explicitly: Toast defaults to 'error', so omitting the kind
		 * announced this confirmation as role="alert" (#5481 review). */
		showToast( __( 'Action restored.', 'thrive-cb' ), 'success' );
	};

	const catalog = getCatalog();
	/* Read on every render: the list re-renders on tta:actions-changed, which
	 * fires each time the pane is shown, so a field deleted on the canvas is
	 * picked up when the user comes back to this tab. */
	const formFields = getFormFields();
	const unlockedCount = catalog.filter( ( a ) => ! a.locked && ! a.hidden ).length;
	/* Drives the empty state's copy only - see the comment there. */
	const offersOvation = catalog.some( ( a ) => a.id === 'ovation_request' && ! a.locked && ! a.hidden );
	/* Saved rows whose action left the catalog or sits on
	 * a locked/hidden card must not eat a real slot - unlockedCount excludes
	 * those, so counting them here would hide "+ Add" prematurely. */
	const resolvedCount = actions.filter( ( c ) => catalog.some( ( a ) => a.id === c.actionId && ! a.locked && ! a.hidden ) ).length;
	const atCap = resolvedCount >= unlockedCount;

	/* History outlives the actions that produced it - keep the log reachable
	 * after the last action is removed (design M2). The boot data's count
	 * shows the link at once; the request only refreshes it (#4053 QA). A
	 * form the boot data does not list starts at 0, so no stale count
	 * carries over from the previous form. */
	const [ logCount, setLogCount ] = useState( () => bootLogCount( formId ) );
	useEffect( () => {
		setLogCount( bootLogCount( formId ) );
		if ( actions.length || ! formId ) {
			return;
		}
		/* A slow answer for the previous form must not land on this one. A
		 * failed request keeps the boot count. */
		let current = true;
		fetchLogs( formId )
			.then( ( r ) => current && setLogCount( r.entries.length ) )
			.catch( () => undefined );
		return () => {
			current = false;
		};
	}, [ actions.length, formId ] );

	/* Empty state - copy from STATES.md. */
	if ( ! actions.length && ! removed ) {
		return (
			<div className="tta-actions-empty">
				{ /* Title and body sit 4px apart inside their own copy block; the
				   12px column gap separates that block from the CTA (design's
				   .tcb-ta-panel-empty__copy). Flat siblings gave both 12px. */ }
				<div className="tta-actions-empty__copy">
					<strong>{ __( 'Trigger another Thrive plugin when this form is submitted', 'thrive-cb' ) }</strong>
					{ /* The Ovation card is hidden until the active Ovation carries its
					   template surface, so this list follows the catalog instead of
					   naming a card the user cannot see. Two whole sentences rather
					   than a joined list, so each one stays translatable. */ }
					<span>{ offersOvation
						? __( 'Apprentice access, Ultimatum campaigns, Ovation requests.', 'thrive-cb' )
						: __( 'Apprentice access, Ultimatum campaigns.', 'thrive-cb' ) }</span>
				</div>
				<button type="button" className="tta-actions-cta" onClick={ () => openConfigurator( null, null ) }>
					{ __( '+ Add Thrive Action', 'thrive-cb' ) }
				</button>
				{ logCount > 0 && (
					<button type="button" className="tcb-ta-panel-head__logs" onClick={ openLog }>
						{ __( 'View submission log', 'thrive-cb' ) }<span className="tcb-ta-log-link__count">{ logCount }</span>
					</button>
				) }
			</div>
		);
	}

	return (
		<div className="tta-actions-cards">
			<div className="tcb-ta-panel-head">
				<span className="tcb-ta-panel-head__title">{ __( 'All actions', 'thrive-cb' ) }</span>
				<button type="button" className="tcb-ta-panel-head__logs" onClick={ openLog }>{ __( 'All logs', 'thrive-cb' ) }</button>
			</div>
			{ actions.map( ( config, index ) => {
				const action = catalog.find( ( a ) => a.id === config.actionId );
				/* #4052 QA: deleting the input a rule uses leaves the action
				 * unable to ever fire - say so instead of showing it Active. */
				const fieldMissing = isSavedFieldMissing( config, formFields );
				/* #4047 QA: a locked descriptor still resolves above - the
				 * catalog keeps a placeholder for every action so the picker can
				 * offer the locked state at all - so `action` being truthy says
				 * nothing about whether the action can run. No executor is
				 * registered, and the dispatcher writes a failed row for it
				 * (tta_execute_config). Say so here instead of on submit only. */
				const locked = !! action?.locked;
				return (
					<div className="tta-actions-saved" key={ `${ config.actionId }-${ index }` }>
						<span className="tta-actions-saved-head">
							<span className="tta-actions-saved-icon">
								{ action?.image && <img src={ action.image } alt="" /> }
							</span>
							<span className="tta-actions-saved-titles">
								<strong>{ cardTitle( config ) }</strong>
								<span className="tta-actions-saved-sub">{ config.target?.label }</span>
							</span>
						</span>
						<span className="tta-actions-saved-meta">{ fireLine( config ) }</span>
						{ locked ? (
							<span className="tta-actions-saved-warning tta-actions-saved-warning--locked">
								{ action?.lockedReason
									? <LockedWarning reason={ action.lockedReason } url={ action.lockedUrl } />
									: __( 'The plugin that runs this action is not active - this action will not run.', 'thrive-cb' ) }
							</span>
						) : action && fieldMissing && (
							/* Same shape as the locked card (#4052): the fix is the link,
							 * and it opens the configure step like Edit does. */
							<span className="tta-actions-saved-warning tta-actions-saved-warning--locked">
								<LockedWarning reason={ __( 'Pick another field', 'thrive-cb' ) } onClick={ () => onEdit( config, index ) } />
							</span>
						) }
						<span className="tta-actions-saved-divider" />
						<span className="tta-actions-saved-foot">
							{ ! action ? (
								<span className="tta-actions-saved-status tta-actions-saved-status--unavailable">{ __( 'Not available', 'thrive-cb' ) }</span>
							) : locked ? (
								/* Amber, not the grey of an action that left the catalog:
								 * this one is fixable from here (activate/update the plugin)
								 * and the card says how, like the #4052 field warning. */
								<span className="tta-actions-saved-status tta-actions-saved-status--warning">
									{ __( "Won't run", 'thrive-cb' ) }
									{ action?.lockedTip && <LockedInfo tip={ action.lockedTip } /> }
								</span>
							) : fieldMissing ? (
								<span className="tta-actions-saved-status tta-actions-saved-status--warning">
									{ __( 'Field missing', 'thrive-cb' ) }
									<LockedInfo
										tip={ config.condition?.fieldLabel
											/* translators: %s: the form field's name, e.g. "Source" */
											? sprintf( __( "%s was removed from the form, so this action can't run. Pick another field and the action resumes.", 'thrive-cb' ), config.condition.fieldLabel )
											: __( "This condition's field was removed from the form, so this action can't run. Pick another field and the action resumes.", 'thrive-cb' ) }
									/>
								</span>
							) : (
								<span className="tta-actions-saved-status">{ __( 'Active', 'thrive-cb' ) }</span>
							) }
							<span className="tta-actions-saved-tools">
								{ /* No Edit for an action that left the catalog - the
								   configurator has nothing to render for it, only Remove works.
								   Same for a locked one (#4047 QA): its placeholder descriptor
								   carries no targetPrompt and no sub-operations, so the configure
								   screen would open with nothing to configure. */ }
								{ action && ! locked && <button type="button" className="is-edit" onClick={ () => onEdit( config, index ) }>{ __( 'Edit', 'thrive-cb' ) }</button> }
								<button type="button" className="is-remove" onClick={ () => setConfirming( index ) }>{ __( 'Remove', 'thrive-cb' ) }</button>
							</span>
						</span>
						{ /* Remove confirmation - a centered modal per the prototype
						   (Figma 12570:247), not an inline card. Portaled to the
						   body because this list mounts inside the Architect
						   sidebar pane, which would clip a fixed overlay. */ }
						{ confirming === index && createPortal(
							<div className={ `tcb-ta-modal tcb-ta-remove-modal${ confirmEntering ? ' tcb-ta-modal--in' : '' }` }>
								<div className="tcb-ta-modal__backdrop" onClick={ () => setConfirming( null ) } />
								<div
									className="tcb-ta-remove-modal__dialog"
									role="dialog"
									aria-modal="true"
									aria-labelledby="tcbTaRemoveTitle"
									ref={ confirmDialogRef }
									tabIndex={ -1 }
									onKeyDown={ trapConfirmTab }
								>
									<div className="tcb-ta-remove-modal__content">
										<div className="tcb-ta-remove-modal__icon">
											<svg width="20" height="22" viewBox="0 0 20 22" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
												<path d="M10 2L1 19h18L10 2z" stroke="#ff7100" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
												<path d="M10 9v4" stroke="#ff7100" strokeWidth="1.8" strokeLinecap="round" />
												<circle cx="10" cy="16" r="1" fill="#ff7100" />
											</svg>
										</div>
										<div className="tcb-ta-remove-modal__text">
											<h3 className="tcb-ta-remove-modal__title" id="tcbTaRemoveTitle">{ __( 'Remove this Thrive Action?', 'thrive-cb' ) }</h3>
											<p className="tcb-ta-remove-modal__body">
												{ /* translators: %s: the action name */ }
												{ sprintf( __( 'This form will no longer fire %s on submission.', 'thrive-cb' ), cardTitle( config ) ) }{ ' ' }
												{ __( "You'll have 8 seconds to undo right after.", 'thrive-cb' ) }
											</p>
										</div>
									</div>
									{ /* Design-system Button rather than hand-rolled markup, so these two
									   track the shared control as it changes (#4047 review). The 50/50
									   split comes from `.tcb-ta-remove-modal__actions > *`, because the
									   Buttons carry none of our classes - the earlier claim that the
									   layout class alone supplied it was wrong (#5481 review). */ }
									<div className="tcb-ta-remove-modal__actions">
										<Button variant="outline" color="neutral" onClick={ () => setConfirming( null ) }>
											{ __( 'Keep action', 'thrive-cb' ) }
										</Button>
										<Button variant="solid" color="danger" onClick={ () => remove( index ) }>
											{ __( 'Remove action', 'thrive-cb' ) }
										</Button>
									</div>
								</div>
							</div>,
							document.body
						) }
					</div>
				);
			} ) }
			{ atCap ? (
				<p className="tta-actions-cap">{ sprintf( /* translators: %d: number of available actions */ __( 'All plugins added (max %d)', 'thrive-cb' ), unlockedCount ) }</p>
			) : (
				<button type="button" className="tta-actions-addmore" onClick={ () => openConfigurator( null, null ) }>
					{ __( '+ Add another action', 'thrive-cb' ) }
				</button>
			) }
			{ /* Floating, dismissible toast per the design - this was an inline
			   block in the panel with no way to dismiss it. */ }
			{ removed && (
				<UndoToast key={ removed.seq } onUndo={ undo } onDismiss={ () => setRemoved( null ) } />
			) }
		</div>
	);
}

/* ---------------------------------------------------------------- adapters */

/**
 * The name of Thrive spam protection's honeypot input, or '' when spam
 * protection is off.
 *
 * The honeypot is minted client-side with a randomised name built from a real
 * field name plus a suffix - `message_wymvm`, `phone_i9qxq` - and deliberately
 * rendered as a visible-to-bots text input, hidden only by CSS. So it looks
 * exactly like one of the form's own fields and no name pattern can safely
 * identify it. The authoritative name is the one the minting code wrote to the
 * LG model (`lead-generation.js`, `sp_field`), which is also what the server
 * strips from submitted data via the internal-keys list in `form-hooks.php`.
 */
function getHoneypotFieldName(): string {
	/* Two sources on purpose. The LG model is the live one - it holds the name
	 * the SPTools control just minted, before any save. But `captcha` is a
	 * computed attribute: if it is not populated yet when the configurator
	 * opens, reading only the model yields '' and, since no real field is named
	 * '', the exclusion matches nothing and the honeypot is offered again - the
	 * very bug this guards (#4047 review). The saved settings carry the last
	 * persisted `sp_field`, so they answer for that window. */
	try {
		const captcha = window.TVE?.Components?.lead_generation?.leadGenerationModel?.get?.( 'captcha' );
		if ( captcha && captcha.enabled && captcha.name !== 'disabled' ) {
			const live = String( captcha.sp_field || '' );
			if ( live ) {
				return live;
			}
		}
	} catch {
		/* Fall through to the saved settings. */
	}

	try {
		const saved = getSettingsView()?.__getSettings?.() || {};
		return String( ( saved as Record< string, unknown > ).sp_field || '' );
	} catch {
		return '';
	}
}

/* Inputs a condition can never usefully address: consent checkboxes (the
 * server drops `user_consent` / `gdpr` from the submitted data), file uploads,
 * hidden mapping fields. */
const UNCONDITIONABLE = /^(user_consent|gdpr|mapping_hidden_\d+)$/;

/**
 * Condition field choices (#4052), read live from the canvas so added and
 * removed fields show up without a save.
 *
 * One entry per field wrapper, labelled the way Architect's own Fields list
 * labels it (`data-name`, then the placeholder, then the name - the chain in
 * lead-generation.js getApiFields()), so a custom input reads "Source", not
 * `mapping_text_174` (#4052 QA, Bug 2). Values are the submitted key: a
 * checkbox group's `name[]` loses its `[]`, which PHP strips when it parses
 * the POST (#4052 QA, Bug 1). Fields with choices carry them as `options`.
 *
 * The spam-protection honeypot is never a field wrapper, and is also excluded
 * by name (#4047 QA): a condition on it could never match a real submitter.
 */
function getFormFields(): ConditionFieldOption[] {
	const $form = getFormWrapper();
	const root: HTMLElement | undefined = $form?.[ 0 ];
	if ( ! root || typeof root.querySelectorAll !== 'function' ) {
		return [];
	}
	const honeypot = getHoneypotFieldName();
	const seen = new Set<string>();
	const fields: Array<{ value: string; label: string; fieldType: string; options?: { value: string; label: string }[] }> = [];

	root.querySelectorAll<HTMLElement>( '.tve_lg_input_container:not(.tve_submit_container)' ).forEach( ( wrapper ) => {
		const inputs = Array.from( wrapper.querySelectorAll<HTMLInputElement>( 'input, select, textarea' ) )
			.filter( ( el ) => !! el.getAttribute( 'name' ) );
		const first = inputs[ 0 ];
		if ( ! first ) {
			return;
		}
		const raw = first.getAttribute( 'name' ) as string;
		const name = raw.replace( /\[\]$/, '' );
		if ( name.startsWith( '_' ) || first.type === 'hidden' || first.type === 'file' || /captcha/i.test( name )
			|| name === honeypot || UNCONDITIONABLE.test( name ) || seen.has( name ) ) {
			return;
		}
		seen.add( name );

		const label = first.getAttribute( 'data-name' ) || first.getAttribute( 'data-placeholder' ) || first.getAttribute( 'placeholder' ) || name;
		let fieldType = first.type || 'text';
		let options: { value: string; label: string }[] | undefined;

		if ( wrapper.classList.contains( 'tve_lg_dropdown' ) ) {
			fieldType = 'dropdown';
			options = Array.from( wrapper.querySelectorAll<HTMLElement>( 'li.tve-lg-dropdown-option[data-value]' ) )
				.map( ( li ) => ( { value: li.getAttribute( 'data-value' ) as string, label: li.textContent?.trim() || ( li.getAttribute( 'data-value' ) as string ) } ) );
		} else if ( first.type === 'checkbox' || first.type === 'radio' ) {
			fieldType = first.type;
			options = inputs
				.filter( ( el ) => el.getAttribute( 'name' ) === raw && el.value !== '' )
				.map( ( el ) => {
					const text = el.closest( '.tve_lg_checkbox_wrapper, .tve_lg_radio_wrapper' )?.querySelector( '.tve-input-option-text' )?.textContent?.trim();
					return { value: el.value, label: text || el.value };
				} );
		}

		fields.push( { value: name, label, fieldType, ...( options && options.length ? { options } : {} ) } );
	} );

	/* The configurator's field Select is keyed by label - two fields sharing a
	 * label get their name appended so both stay pickable. */
	const counts = new Map<string, number>();
	fields.forEach( ( f ) => counts.set( f.label, ( counts.get( f.label ) ?? 0 ) + 1 ) );
	return fields.map( ( f ) => ( ( counts.get( f.label ) ?? 0 ) > 1 ? { ...f, label: `${ f.label } (${ f.value })` } : f ) );
}

/**
 * A saved rule whose field is not on the form any more (#4052 QA). An empty
 * field list means the form could not be read - never warn on that.
 */
function isSavedFieldMissing( config: ActionConfig, fields: ConditionFieldOption[] ): boolean {
	const field = config.condition?.field?.replace( /\[\]$/, '' ) ?? '';
	return field !== '' && fields.length > 0 && ! fields.some( ( f ) => ( typeof f === 'string' ? f : f.value ) === field );
}

/** A condition field's display label: live from the form, else the snapshot, else the name. */
function conditionFieldLabel( field: string, snapshot?: string ): string {
	const name = field.replace( /\[\]$/, '' );
	const live = getFormFields().find( ( f ) => typeof f !== 'string' && f.value === name );
	return ( live && typeof live !== 'string' ? live.label : '' ) || snapshot || field;
}

/** A condition field's type on the form ('checkbox', 'dropdown'...), or undefined once it has left. */
function conditionFieldType( field: string ): string | undefined {
	const name = field.replace( /\[\]$/, '' );
	const live = getFormFields().find( ( f ) => typeof f !== 'string' && f.value === name );
	return live && typeof live !== 'string' ? live.fieldType : undefined;
}

/**
 * Spam protection state for the selected form (#3535 signup guardrail). It
 * lives on the LG model's `captcha` object, not in the saved settings JSON, so
 * the editor's own dropdown and this notice read the same unsaved value.
 * `disabled` is the product's off state.
 */
function isSpamProtectionEnabled(): boolean {
	try {
		const captcha = window.TVE?.Components?.lead_generation?.leadGenerationModel?.get?.( 'captcha' );
		return !! captcha && !! captcha.enabled && captcha.name !== 'disabled';
	} catch {
		/* No form selected, or an editor build without the control - reporting
		 * "enabled" keeps the notice hidden rather than nagging about a form we
		 * cannot actually read. */
		return true;
	}
}

/**
 * Turn on Thrive's own spam protection - the one tool that needs no connected
 * credentials, so it is the only one a single click can switch on.
 *
 * Routed through the SPTools control's own input handler rather than writing
 * the model directly: that handler also mints the randomised honeypot field
 * name and calls write('captcha'), and going through it keeps the sidebar
 * dropdown showing the change.
 */
function enableSpamProtection(): boolean {
	try {
		const component = window.TVE?.Components?.lead_generation;
		const control = component?.controls?.SPTools;
		if ( ! control || typeof control.input !== 'function' ) {
			return false;
		}
		control.input.call( control, null, { value: 'thrive-sp' } );
		control.update?.call( control );
		return isSpamProtectionEnabled();
	} catch {
		return false;
	}
}

/* Exported for tests: this object is the contract the configurator consumes,
 * so asserting against it exercises the same path the UI takes. */
export const editorAdapters = {
	...restAdapters,
	getConditionFields: () => Promise.resolve( getFormFields() ),
	isSpamProtectionEnabled,
	enableSpamProtection,
};

/* -------------------------------------------------------------- toast root */

let toastRoot: Root | null = null;
/* Bumped per notice so each one mounts a fresh Toast - see showToast. */
let toastSeq = 0;

/**
 * Show a transient notice the way the prototype does - one dark pill at the
 * bottom of the viewport. Used for save confirmations and for the
 * configurator's validation refusals, which previously rendered as a red box
 * inside the modal (.tta-cfg-toast, still the fallback for hosts that pass no
 * onToast).
 *
 * `kind` comes straight from ActionConfiguratorProps.onToast and only steers
 * the ARIA role; the prototype styles every kind the same (#4047 review).
 */
function showToast( message: string, kind?: 'error' | 'success' ) {
	if ( ! toastRoot ) {
		const el = document.createElement( 'div' );
		el.id = 'tta-toast-island';
		document.body.appendChild( el );
		toastRoot = createRoot( el );
	}
	/* A changing key is what remounts the Toast, so a second notice restarts
	 * the timer instead of inheriting the first one's remaining time. Calling
	 * render(null) first does NOT achieve that: two synchronous render() calls
	 * are batched into one commit, React reconciles the same element type in
	 * the same position, and the timers in Toast's mount effect keep running
	 * (#4047 review). */
	toastSeq += 1;
	toastRoot.render(
		<StrictMode>
			<Toast
				key={ toastSeq }
				message={ message }
				kind={ kind }
				onDone={ () => toastRoot?.render( null ) }
			/>
		</StrictMode>
	);
}

/* -------------------------------------------------------------- modal root */

let modalRoot: Root | null = null;
let modalContainer: HTMLElement | null = null;

function openConfigurator( saved: ActionConfig | null, index: number | null ) {
	/* Rules saved before #4052 QA stored a checkbox group as `name[]`; the
	 * picker now offers the submitted key without it, so match it up. */
	const savedField = saved?.condition?.field;
	const value = saved?.condition && typeof savedField === 'string' && savedField.endsWith( '[]' )
		? { ...saved, condition: { ...saved.condition, field: savedField.slice( 0, -2 ) } }
		: saved;
	if ( ! modalRoot ) {
		const el = document.createElement( 'div' );
		el.id = 'tta-automations-island';
		/* The design's unit dropdown reads "days  after form submission": the
		 * phrase sits inside the closed control, in grey, and the open list
		 * shows only the units. architect-overrides.css draws it from this
		 * variable so the phrase stays translatable (#4051 QA, Finding 4). */
		el.style.setProperty( '--tta-delay-suffix', JSON.stringify( __( 'after form submission', 'thrive-cb' ) ) );
		/* The design lowercases the chosen unit ("days after..."), which is
		 * only right in English - "Tage" must stay capitalised in German. The
		 * editor page has no lang attribute, so say it on the island root. */
		el.classList.toggle( 'tta-lowercase-units', /^en(_|$)/.test( window.TTA_EDITOR_BOOT?.locale ?? '' ) );
		document.body.appendChild( el );
		modalContainer = el;
		modalRoot = createRoot( el );
	}
	const close = () => modalRoot?.render( null );
	modalRoot.render(
		<StrictMode>
			<ActionConfigurator
				open
				actions={ getCatalog() }
				adapters={ editorAdapters }
				value={ value }
				usedActionIds={ readActions()
					.map( ( a ) => a.actionId )
					.filter( ( id, i ) => index === null || i !== index ) }
				onSave={ ( next ) => {
					/* Snapshot the field's label with the rule, so log rows can
					 * still name it after the field leaves the form (#4052 QA).
					 * An unchanged field keeps its old label when the form can't
					 * be read. The server ignores the label when deciding whether
					 * an edit cancels queued runs (tta_comparable_config). */
					const previousLabel = next.condition && value?.condition?.field === next.condition.field ? value.condition.fieldLabel : undefined;
					const config = next.condition
						? { ...next, condition: { ...next.condition, fieldLabel: conditionFieldLabel( next.condition.field, previousLabel ) } }
						: next;
					const list = readActions();
					if ( index === null ) {
						list.push( config );
					} else {
						list[ index ] = config;
					}
					writeActions( list );
					document.dispatchEvent( new CustomEvent( 'tta:actions-changed' ) );
					close();
					showToast( __( 'Thrive Action saved.', 'thrive-cb' ), 'success' );
				} }
				onCancel={ close }
				/* Route the configurator's notices to the design's toast instead
				 * of its in-modal fallback box. */
				onToast={ showToast }
				container={ modalContainer ?? undefined }
				/* #3535 design: every Time delay / condition control is 36px, the
				 * delay phrase lives inside the unit dropdown (no caption), and the
				 * open list shows capitalised units (#4051 QA, Finding 4). */
				controlSize="md"
				copy={ {
					timingHelp: '',
					conditionFieldMissing: __( 'This field is no longer on the form. Pick a field that is, or switch the condition off.', 'thrive-cb' ),
					timingUnitLabels: {
						minutes: __( 'Minutes', 'thrive-cb' ),
						hours: __( 'Hours', 'thrive-cb' ),
						days: __( 'Days', 'thrive-cb' ),
						weeks: __( 'Weeks', 'thrive-cb' ),
						months: __( 'Months', 'thrive-cb' ),
					},
				} }
			/>
		</StrictMode>
	);
}

/* ------------------------------------------------------- submission log */

let logRoot: Root | null = null;

function openLog() {
	let el = document.getElementById( 'tta-log-island' );
	if ( ! el ) {
		el = document.createElement( 'div' );
		el.id = 'tta-log-island';
		document.body.appendChild( el );
		logRoot = createRoot( el );
	}
	logRoot?.render(
		<StrictMode>
			<SubmissionLog
				formSettingsId={ getFormSettingsId() }
				savedActions={ readActions() }
				fieldLabels={ Object.fromEntries( getFormFields().map( ( f ) => ( typeof f === 'string' ? [ f, f ] : [ f.value, f.label ] ) ) ) }
				onClose={ () => logRoot?.render( null ) }
			/>
		</StrictMode>
	);
}

/* ------------------------------------------------------------- pane mount */

let listRoot: Root | null = null;
let listContainer: Element | null = null;

function mountListIfVisible() {
	const container = document.querySelector(
		'.connection-controls[data-connection="thrive-actions"]:not(.tcb-hidden) .tta-actions-list'
	);
	if ( ! container ) {
		/* Pane hidden or panel re-rendered: drop the stale root. */
		if ( listRoot && listContainer && ! document.contains( listContainer ) ) {
			listRoot = null;
			listContainer = null;
		}
		return;
	}
	if ( container === listContainer && listRoot ) {
		/* Already mounted - the pane may have re-opened for a different (or
		 * freshly selected) element, so re-read from the current form. */
		document.dispatchEvent( new CustomEvent( 'tta:actions-changed' ) );
		return;
	}
	listContainer = container;
	listRoot = createRoot( container );
	listRoot.render(
		<StrictMode>
			<SavedActionsList onEdit={ ( config, index ) => openConfigurator( config, index ) } />
		</StrictMode>
	);
	/* First mount can race the LG Backbone view (it's created during element
	 * selection, our observer can fire first) - re-read once it exists. */
	window.setTimeout( () => document.dispatchEvent( new CustomEvent( 'tta:actions-changed' ) ), 200 );
}

/* ---------------------------------------------------------------- tab badge */

/**
 * Configured-item counts on the Connection tab buttons. Backbone owns the
 * buttons; we only decorate them, and re-decorate after every panel re-render.
 * The handoff renders API/Webhooks badges as static placeholders and notes
 * they "bind to the real configured-item counts" in production (#4054).
 */
function decorateTab( value: string, count: number ) {
	const tab = document.querySelector( `[data-value="${ value }"]` );
	if ( ! tab ) {
		return;
	}
	let badge = tab.querySelector( '.tta-tab-count' );
	if ( ! badge ) {
		badge = document.createElement( 'span' );
		badge.className = 'tta-tab-count';
		tab.appendChild( badge );
	}
	badge.textContent = String( count );
	/* Design: badge hidden at 0 (tcb-conn-tab__badge[data-ta-count="0"]). */
	( badge as HTMLElement ).style.display = count ? '' : 'none';
}

function updateTabBadge() {
	decorateTab( 'thrive-actions', readActions().length );

	const settings = getSettingsView()?.__getSettings?.() || {};
	/* One badge unit per connected service ("API 2" = two autoresponders). */
	const apis = settings.apis && typeof settings.apis === 'object' ? Object.keys( settings.apis ) : [];
	decorateTab( 'api', apis.length );
	/* Webhooks are one-per-form; the badge is 0/1 on a saved URL. */
	const webhookUrl = settings.webhook?.url || settings.webhook_draft?.url;
	decorateTab( 'webhook', webhookUrl ? 1 : 0 );
}

document.addEventListener( 'tta:actions-changed', updateTabBadge );

/* The components panel re-renders on every element select / tab switch;
 * observe it and (re)mount when our pane becomes visible. Scoped to
 * #tve-components (the per-element settings container) rather than
 * document.body - Architect mutates the canvas DOM on every interaction and
 * body-wide observation made this the broadest trigger in the editor.
 * Debounced - the observer still fires in bursts during panel renders. */
let debounce: number | undefined;
let observedScope: Element | null = null;

const panelObserver = new MutationObserver( () => {
	window.clearTimeout( debounce );
	debounce = window.setTimeout( () => {
		rescopeObserver();
		mountListIfVisible();
		updateTabBadge();
	}, 100 );
} );

/* The panel container can render after this bundle runs - observe body only
 * until it exists, then narrow to it. */
function rescopeObserver() {
	const scope = document.getElementById( 'tve-components' ) ?? document.body;
	if ( scope === observedScope ) {
		return;
	}
	observedScope = scope;
	panelObserver.disconnect();
	panelObserver.observe( scope, { subtree: true, childList: true, attributes: true, attributeFilter: [ 'class' ] } );
}

rescopeObserver();

window.addEventListener( 'pagehide', () => {
	panelObserver.disconnect();
	window.clearTimeout( debounce );
} );

