/**
 * Submission Log drawer (#4053) - ported 1:1 from the design handoff
 * ("Thrive Actions 3535.html", Submission Log section; reference snapshot in
 * docs/automator-retirement-phase2/design-refs/). Same markup, class names,
 * copy and filter semantics as the prototype's renderLogModal(); the only
 * change is the data source - rows come from the thrive_tta_log table via
 * the form-actions/logs REST route instead of the prototype's seeded state.
 */
import { useEffect, useRef, useState } from 'react';
import { __, sprintf } from '@wordpress/i18n';
import { delayPhrase } from './timing';
import { conditionOpLabel } from './ActionConfigurator/conditionOps';
import { getCatalog, fetchLogs, type LogEntry } from './catalog';
import type { ActionConfig, ActionDescriptor } from './ActionConfigurator/types';

type Outcome = LogEntry[ 'outcome' ];

interface Props {
	formSettingsId: number;
	savedActions: ActionConfig[];
	/** Submitted field name -> its label on the form today (#4052 QA). */
	fieldLabels?: Record<string, string>;
	onClose: () => void;
}

/* ── Icons - exact symbol paths from the design file ─────────────────── */

function IconSearch() {
	return (
		<svg width="13" height="13" viewBox="0 0 24 24">
			<circle cx="11" cy="11" r="6" fill="none" stroke="currentColor" strokeWidth="1.6" />
			<path stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" d="M16 16l4 4" />
		</svg>
	);
}
function IconChevD() {
	return (
		<svg width="10" height="10" viewBox="0 0 24 24">
			<path fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" d="M6 9l6 6 6-6" />
		</svg>
	);
}
function IconBolt( { size = 22 }: { size?: number } ) {
	return (
		<svg width={ size } height={ size } viewBox="0 0 24 24">
			<path fill="currentColor" d="M13 2L4 14h7l-1 8 9-12h-7z" />
		</svg>
	);
}

/* ── Formatting - verbatim ports of the design helpers ───────────────── */

function outcomeLabel( o: string ): string {
	return ( {
		scheduled: __( 'Scheduled', 'thrive-cb' ),
		fired: __( 'Fired', 'thrive-cb' ),
		skipped: __( 'Skipped', 'thrive-cb' ),
		failed: __( 'Failed', 'thrive-cb' ),
	} as Record<string, string> )[ o ] || o;
}

function relTime( minsAgo: number ): string {
	if ( minsAgo < 1 ) {
		return __( 'Just now', 'thrive-cb' );
	}
	if ( minsAgo < 60 ) {
		/* translators: %d: minutes */
		return sprintf( __( '%d min ago', 'thrive-cb' ), Math.round( minsAgo ) );
	}
	if ( minsAgo < 60 * 24 ) {
		const h = Math.round( minsAgo / 60 );
		/* translators: %d: hours */
		return h > 1 ? sprintf( __( '%d hrs ago', 'thrive-cb' ), h ) : __( '1 hr ago', 'thrive-cb' );
	}
	const d = Math.round( minsAgo / ( 60 * 24 ) );
	/* translators: %d: days */
	return d === 1 ? __( 'Yesterday', 'thrive-cb' ) : sprintf( __( '%d days ago', 'thrive-cb' ), d );
}

/**
 * The zone absolute times render in: the WordPress site's, labelled "site
 * time" below (#4051 QA). Timestamps are real UTC epochs, so formatting
 * without a zone would show the viewer's browser time instead.
 *
 * Offset-only sites ("UTC+3" in Settings > General) have no IANA name; those
 * shift the epoch by the offset and format as UTC - exact, because an offset
 * zone has no DST. Offset strings like '+03:00' are not used as `timeZone`
 * because browser support for them is uneven.
 */
function siteZone(): { timeZone?: string; shiftMs: number } {
	const tz = window.TTA_EDITOR_BOOT?.timezone;
	if ( tz?.string ) {
		try {
			new Intl.DateTimeFormat( undefined, { timeZone: tz.string } );
			return { timeZone: tz.string, shiftMs: 0 };
		} catch {
			/* Unknown to this browser - fall back to the offset. */
		}
	}
	if ( tz && typeof tz.offset === 'number' && Number.isFinite( tz.offset ) ) {
		return { timeZone: 'UTC', shiftMs: tz.offset * 3600000 };
	}
	return { shiftMs: 0 };
}

/* Absolute timestamp, in the site's time zone. */
function fmtAbs( ts?: number ): string {
	if ( ! ts ) {
		return '';
	}
	const { timeZone, shiftMs } = siteZone();
	const d = new Date( ts + shiftMs );
	return d.toLocaleDateString( undefined, { day: 'numeric', month: 'short', year: 'numeric', timeZone } )
		+ ', ' + d.toLocaleTimeString( undefined, { hour: 'numeric', minute: '2-digit', timeZone } );
}

function minsAgoOf( e: LogEntry ): number {
	return Math.max( 0, ( Date.now() - e.ts ) / 60000 );
}

/* Design subOpDisplayName() verbatim - the log names its rows with these
 * exact strings ("Grant Apprentice Access", not the picker's sentence case). */
const SUB_OP_DISPLAY: Record<string, string> = {
	'apprentice_access:grant': __( 'Grant Apprentice Access', 'thrive-cb' ),
	'apprentice_access:revoke': __( 'Revoke Apprentice Access', 'thrive-cb' ),
	'ultimatum_campaign:start': __( 'Start Ultimatum Campaign', 'thrive-cb' ),
	'ultimatum_campaign:stop': __( 'End Ultimatum Campaign', 'thrive-cb' ),
};

function nameFor( catalog: ActionDescriptor[], actionId: string, subOperation: string | null ): string {
	const bySubOp = SUB_OP_DISPLAY[ `${ actionId }:${ subOperation ?? '' }` ];
	if ( bySubOp ) {
		return bySubOp;
	}
	const a = catalog.find( ( x ) => x.id === actionId );
	return a ? a.label : actionId;
}

function subOpOf( e: LogEntry ): string | null {
	return e.detail?._action?.sub_operation ?? null;
}

function timingText( e: LogEntry ): string {
	const timing = e.detail?._action?.timing;
	return timing && timing.amount
		/* translators: %s: delay, e.g. "2 days" */
		? sprintf( __( 'fired %s after submission', 'thrive-cb' ), delayPhrase( timing.amount, timing.unit ) )
		: __( 'fired immediately', 'thrive-cb' );
}

/* The design's firedDetailFor() - one plain-English line per action shape,
 * built from the row's snapshot so it survives edits/removals. */
function firedText( e: LogEntry ): string {
	const target = e.detail?._action?.target_label || '';
	const sub = subOpOf( e );
	/* A run can succeed without changing anything - the submitter already had
	 * the access a grant asked for, or had none for a revoke to take away. Both
	 * are fired rows, and before #4047 both read as though the work happened,
	 * so a repeat submission was indistinguishable from a real grant. The
	 * executor reports the fact; the wording stays here with the rest of the
	 * localized copy. */
	const noChange = !! e.detail?.no_change;
	switch ( e.action ) {
		case 'apprentice_access':
			if ( noChange ) {
				return sub === 'revoke'
					/* translators: %s: product name */
					? sprintf( __( 'No access to %s to revoke - nothing changed', 'thrive-cb' ), target )
					/* translators: %s: product name */
					: sprintf( __( 'Already had access to %s - nothing changed', 'thrive-cb' ), target );
			}
			return sub === 'revoke'
				/* translators: %s: product name */
				? sprintf( __( 'Revoked access to %s - progress preserved', 'thrive-cb' ), target )
				/* translators: %s: product name */
				: sprintf( __( 'Granted access to %s', 'thrive-cb' ), target );
		case 'ultimatum_campaign':
			return sub === 'stop'
				/* translators: %s: campaign name */
				? sprintf( __( 'Ended the %s campaign for this user', 'thrive-cb' ), target )
				/* translators: %s: campaign name */
				: sprintf( __( 'Started the %s campaign for this user', 'thrive-cb' ), target );
		case 'ovation_request':
			return __( 'Sent the default testimonial-request email', 'thrive-cb' );
		default:
			return e.detail?.message || __( 'Action fired', 'thrive-cb' );
	}
}

/* ── Detail blocks - copy verbatim from logDetailHTML() ──────────────── */

function StampLine( { e }: { e: LogEntry } ) {
	return (
		<div className="tcb-ta-log__stamp">
			{ fmtAbs( e.ts ) } <span className="tcb-ta-log__stamp-tz">{ __( 'site time', 'thrive-cb' ) }</span>
		</div>
	);
}

/**
 * Whether the submitter left the field blank, or it carried nothing at all.
 *
 * A missing key is not the only empty: a text input submitted blank is logged
 * as `""` and a checkbox group with nothing ticked as `[""]` (#4052 retest,
 * Bug 1), and both used to fall through to the spacing line. Trimmed, because
 * `tta_evaluate` trims before comparing, so " " never matched anything either.
 *
 * @param actual The `actual` value the skip row recorded.
 */
function isEmptyActual( actual: LogEntry[ 'detail' ][ 'actual' ] ): boolean {
	if ( actual === null || actual === undefined ) {
		return true;
	}
	if ( Array.isArray( actual ) ) {
		return actual.every( ( item ) => String( item ?? '' ).trim() === '' );
	}

	return String( actual ).trim() === '';
}

/**
 * Why a condition skipped the run (#4052 QA, Finding 3). The prototype's
 * one line is kept for equals / contains, where it is true. It said "this
 * value genuinely didn't match" even when a "does not equal" rule skipped
 * because the value DID match, and blamed spacing when nothing was sent -
 * those two get the same sentence shape, worded for what happened.
 */
function skipHint( d: LogEntry[ 'detail' ] ): string {
	if ( isEmptyActual( d.actual ) ) {
		return __( 'No value was submitted - the field was left empty or is no longer on the form.', 'thrive-cb' );
	}
	if ( d.op === 'not_equals' ) {
		return __( 'Spacing and capitalisation are ignored when matching - this value is the one the rule excludes.', 'thrive-cb' );
	}
	return __( "Spacing and capitalisation are ignored when matching - this value genuinely didn't match.", 'thrive-cb' );
}

function DetailBlock( { e, fieldLabels = {} }: { e: LogEntry; fieldLabels?: Record<string, string> } ) {
	const d = e.detail || {};

	if ( e.outcome === 'scheduled' ) {
		const timing = d._action?.timing;
		const delayText = timing ? delayPhrase( timing.amount, timing.unit ) : '';
		return (
			<div className="tcb-ta-log__detail-block">
				<div className="tcb-ta-log__detail-title">{ __( "Waiting - this action hasn't run yet", 'thrive-cb' ) }</div>
				<div>{ __( 'Scheduled to fire', 'thrive-cb' ) } <strong>{ fmtAbs( ( d.fire_at ?? 0 ) * 1000 ) }</strong>{ delayText ? sprintf( /* translators: %s: delay, e.g. "2 days" */ __( ' (%s after submission)', 'thrive-cb' ), delayText ) : '' }.</div>
				<div className="tcb-ta-log__hint">{ __( 'The row updates to Fired or Failed once it runs. Removing or editing the action cancels anything still waiting.', 'thrive-cb' ) }</div>
				<StampLine e={ e } />
			</div>
		);
	}

	/* A scheduled run cancelled by removing/editing its action (#4053). */
	if ( e.outcome === 'skipped' && d.cancelled ) {
		return (
			<div className="tcb-ta-log__detail-block">
				<div className="tcb-ta-log__detail-title">{ __( 'Cancelled - this run never fired', 'thrive-cb' ) }</div>
				<div>{ d.message || __( 'The action was removed or edited before this run fired.', 'thrive-cb' ) }</div>
				<StampLine e={ e } />
			</div>
		);
	}

	if ( e.outcome === 'skipped' && d.field ) {
		/* A checkbox group is logged as a list, so its rule reads "includes" /
		 * "does not include" here too, like the configure step (#4052). */
		const op = conditionOpLabel( d.op ?? '', Array.isArray( d.actual ) ? 'checkbox' : undefined );
		const expected = d.expected === '' ? __( '(empty)', 'thrive-cb' ) : String( d.expected );
		return (
			<div className="tcb-ta-log__detail-block">
				<div className="tcb-ta-log__detail-title">{ __( 'Condition not met - the action did not fire', 'thrive-cb' ) }</div>
				<div className="tcb-ta-log__cond">
					<span className="tcb-ta-log__cond-kw">IF</span> { fieldLabels[ d.field.replace( /\[\]$/, '' ) ] || d.field_label || d.field } <em>{ op }</em> <code>&quot;{ expected }&quot;</code>
				</div>
				<div className="tcb-ta-log__cond tcb-ta-log__cond--got">
					<span className="tcb-ta-log__cond-kw tcb-ta-log__cond-kw--got">GOT</span> <code>&quot;{ Array.isArray( d.actual ) ? d.actual.join( ', ' ) : String( d.actual ?? '' ) }&quot;</code>
				</div>
				<div className="tcb-ta-log__hint">{ skipHint( d ) }</div>
				<StampLine e={ e } />
			</div>
		);
	}

	if ( e.outcome === 'failed' ) {
		return (
			<div className="tcb-ta-log__detail-block tcb-ta-log__detail-block--error">
				<div className="tcb-ta-log__detail-title">{ __( 'Action failed', 'thrive-cb' ) }</div>
				<div className="tcb-ta-log__error-msg">{ d.message || __( 'The action returned an error.', 'thrive-cb' ) }</div>
				{ d.next ? <div className="tcb-ta-log__next">{ d.next }</div> : null }
				{ /* A failed run can still have registered an account before the
				   failure - the executor records it and a reader has to be told,
				   otherwise the row reads as though nothing happened (#4048). */ }
				{ d.user_created ? (
					<div className="tcb-ta-log__next">
						{ __( 'A WordPress user was created from the submitted email before this failed, and still exists.', 'thrive-cb' ) }
					</div>
				) : null }
				<div className="tcb-ta-log__hint">{ __( "Not retried automatically. The submitter still saw the form's success message, and other connections were not affected.", 'thrive-cb' ) }</div>
				<StampLine e={ e } />
			</div>
		);
	}

	if ( e.outcome === 'fired' ) {
		return (
			<div className="tcb-ta-log__detail-block">
				<div className="tcb-ta-log__detail-title">{ firedText( e ) }</div>
				<div className="tcb-ta-log__hint">
					{ timingText( e ) }{ d.user_created ? ' · ' + __( 'new WordPress user created from the submitted email', 'thrive-cb' ) : '' }
				</div>
				<StampLine e={ e } />
			</div>
		);
	}

	/* Any other outcome - today a skipped run with neither `cancelled` nor
	 * `field`. States what happened instead of narrating the action as if it ran;
	 * firedText() ignores detail.message, so it cannot speak for these. */
	return (
		<div className="tcb-ta-log__detail-block">
			<div className="tcb-ta-log__detail-title">{ __( 'Action skipped - it did not fire', 'thrive-cb' ) }</div>
			<div>{ d.message || __( 'The action was skipped for this submission.', 'thrive-cb' ) }</div>
			<StampLine e={ e } />
		</div>
	);
}

/* ── The drawer ──────────────────────────────────────────────────────── */

const CHIP_DEFS: Array<[ 'all' | Outcome, string ]> = [
	[ 'all', __( 'All', 'thrive-cb' ) ],
	[ 'scheduled', __( 'Scheduled', 'thrive-cb' ) ],
	[ 'fired', __( 'Fired', 'thrive-cb' ) ],
	[ 'skipped', __( 'Skipped', 'thrive-cb' ) ],
	[ 'failed', __( 'Failed', 'thrive-cb' ) ],
];

function tally( rows: LogEntry[] ) {
	return {
		all: rows.length,
		scheduled: rows.filter( ( e ) => e.outcome === 'scheduled' ).length,
		fired: rows.filter( ( e ) => e.outcome === 'fired' ).length,
		skipped: rows.filter( ( e ) => e.outcome === 'skipped' ).length,
		failed: rows.filter( ( e ) => e.outcome === 'failed' ).length,
	};
}

export default function SubmissionLog( { formSettingsId, savedActions, fieldLabels = {}, onClose }: Props ) {
	const catalog = getCatalog();
	const [ entries, setEntries ] = useState<LogEntry[]>( [] );
	const [ cap, setCap ] = useState( 100 );
	const [ loaded, setLoaded ] = useState( false );
	const [ loadError, setLoadError ] = useState( false );
	/* Always opens unfiltered - scope with the in-drawer controls. */
	const [ filter, setFilter ] = useState<'all' | Outcome>( 'all' );
	const [ actionFilter, setActionFilter ] = useState( 'all' );
	const [ search, setSearch ] = useState( '' );
	const [ expanded, setExpanded ] = useState<number[]>( [] );
	const [ entering, setEntering ] = useState( false );
	const [ closing, setClosing ] = useState( false );
	const dialogRef = useRef<HTMLDivElement>( null );

	const [ retry, setRetry ] = useState( 0 );
	useEffect( () => {
		setLoadError( false );
		fetchLogs( formSettingsId ).then( ( r ) => {
			setEntries( r.entries );
			setCap( r.cap );
			setLoaded( true );
		} ).catch( () => {
			/* Without this the drawer sticks on "Loading…" forever. */
			setLoadError( true );
			setLoaded( true );
		} );
	}, [ formSettingsId, retry ] );

	/* .tcb-ta-modal--in on the next frame - same fade/slide as the design. */
	useEffect( () => {
		const raf = requestAnimationFrame( () => setEntering( true ) );
		return () => cancelAnimationFrame( raf );
	}, [] );

	const close = () => {
		setClosing( true );
		setTimeout( onClose, 220 );
	};

	useEffect( () => {
		const onEsc = ( e: KeyboardEvent ) => {
			if ( e.key === 'Escape' ) {
				close();
			}
		};
		document.addEventListener( 'keydown', onEsc );
		return () => document.removeEventListener( 'keydown', onEsc );
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [] );

	/* Two scopes, deliberately different (design comment): action scope
	 * decides which chips EXIST; search scope decides rows + chip counts. */
	const actionScoped = entries.filter( ( e ) => actionFilter === 'all' || e.action === actionFilter );
	const q = search.trim().toLowerCase();
	const searchScoped = actionScoped.filter( ( e ) => ! q || ( e.email || '' ).toLowerCase().includes( q ) );

	const counts = tally( searchScoped );
	const presence = tally( actionScoped );
	const shownChips = CHIP_DEFS.filter( ( [ k ] ) => k === 'all' || presence[ k ] > 0 );
	/* Active outcome vanished (search / action filter change) - fall back. */
	const activeFilter = shownChips.some( ( [ k ] ) => k === filter ) ? filter : 'all';
	/* One outcome type only -> nothing to filter, hide the chip row. */
	const showChips = shownChips.length > 2;

	const visible = searchScoped
		.filter( ( e ) => activeFilter === 'all' || e.outcome === activeFilter )
		.slice()
		.sort( ( a, b ) => minsAgoOf( a ) - minsAgoOf( b ) );

	/* Actions still on the form, plus any that only exist in history - a
	 * removed action's rows must stay isolatable (M2). */
	const savedKeys = savedActions.map( ( s ) => s.actionId );
	const historicKeys = [ ...new Set( entries.map( ( e ) => e.action ) ) ].filter( ( k ) => ! savedKeys.includes( k ) );

	const hasAny = entries.length > 0;

	return (
		<div className={ `tcb-ta-modal tcb-ta-log-modal${ entering && ! closing ? ' tcb-ta-modal--in' : '' }` }>
			<div className="tcb-ta-modal__backdrop" onClick={ close } />
			<div className="tcb-ta-modal__dialog tcb-ta-log-modal__dialog" role="dialog" aria-labelledby="tcbTaLogTitle" ref={ dialogRef }>
				<header className="tcb-ta-modal__header">
					<span className="tcb-ta-modal__icon tcb-ta-log-modal__hdr-icon"><IconBolt size={ 20 } /></span>
					<div className="tcb-ta-modal__title-wrap">
						<h2 className="tcb-ta-modal__title" id="tcbTaLogTitle">{ __( 'Submission Log', 'thrive-cb' ) }</h2>
						<p className="tcb-ta-modal__sub">{ __( 'Every Thrive Action run for this form - scheduled, fired, skipped or failed.', 'thrive-cb' ) }</p>
					</div>
					<button className="tcb-ta-modal__close" onClick={ close } aria-label={ __( 'Close', 'thrive-cb' ) }>×</button>
				</header>
				<div className="tcb-ta-modal__divider" />
				<div className="tcb-ta-modal__body">
					<div className="tcb-ta-log__toolbar">
						{ showChips && (
							<div className="tcb-ta-log__chips">
								{ shownChips.map( ( [ k, l ] ) => (
									<button
										key={ k }
										className={ `tcb-ta-log__chip ${ activeFilter === k ? 'tcb-ta-log__chip--active' : '' }` }
										onClick={ () => setFilter( k ) }
									>
										{ l }<span className="tcb-ta-log__chip-count">{ counts[ k ] }</span>
									</button>
								) ) }
							</div>
						) }
						<div className="tcb-ta-log__toolbar-right">
							<label className="tcb-ta-log__search">
								<span className="tcb-ta-log__search-icon"><IconSearch /></span>
								<input
									type="search"
									className="tcb-ta-log__search-input"
									placeholder={ __( 'Search by email', 'thrive-cb' ) }
									value={ search }
									aria-label={ __( 'Search the log by submitter email', 'thrive-cb' ) }
									onChange={ ( ev ) => setSearch( ev.target.value ) }
								/>
							</label>
							<select
								className="tcb-input tcb-input--select tcb-ta-log__action-filter"
								value={ actionFilter }
								onChange={ ( ev ) => setActionFilter( ev.target.value ) }
							>
								<option value="all">{ __( 'All actions', 'thrive-cb' ) }</option>
								{ savedActions.map( ( s ) => (
									<option key={ s.actionId } value={ s.actionId }>
										{ nameFor( catalog, s.actionId, s.subOperation ) }
									</option>
								) ) }
								{ historicKeys.map( ( k ) => (
									<option key={ k } value={ k }>
										{ nameFor( catalog, k, subOpOf( entries.find( ( e ) => e.action === k )! ) ) } { __( '(removed)', 'thrive-cb' ) }
									</option>
								) ) }
							</select>
						</div>
					</div>
					<div className="tcb-ta-log__list">
						{ loadError ? (
							<div className="tcb-ta-log__empty">
								<div className="tcb-ta-log__empty-icon"><IconBolt /></div>
								<p className="tcb-ta-log__empty-title">{ __( "Couldn't load the log", 'thrive-cb' ) }</p>
								<p className="tcb-ta-log__empty-text">{ __( 'The request failed - your session may have expired, or the server returned an error.', 'thrive-cb' ) }</p>
								<button type="button" className="tcb-ta-log__retry" onClick={ () => setRetry( ( n ) => n + 1 ) }>{ __( 'Retry', 'thrive-cb' ) }</button>
							</div>
						) : visible.length ? visible.map( ( e ) => {
							const a = catalog.find( ( x ) => x.id === e.action );
							const open = expanded.includes( e.id );
							return (
								<div key={ e.id } className={ `tcb-ta-log__row-wrap ${ open ? 'tcb-ta-log__row-wrap--open' : '' }` }>
									<button
										className="tcb-ta-log__row"
										aria-expanded={ open }
										onClick={ () => setExpanded( ( x ) => open ? x.filter( ( i ) => i !== e.id ) : [ ...x, e.id ] ) }
									>
										<span className="tcb-ta-log__cell tcb-ta-log__cell--time" title={ sprintf( /* translators: %s: absolute date/time */ __( '%s (site time)', 'thrive-cb' ), fmtAbs( e.ts ) ) }>{ relTime( minsAgoOf( e ) ) }</span>
										<span className="tcb-ta-log__cell tcb-ta-log__cell--email">
											{ e.email || ( e.wp_user ? e.wp_user : <span className="tcb-ta-log__anon">{ __( 'Anonymous submission', 'thrive-cb' ) }</span> ) }
										</span>
										<span className="tcb-ta-log__cell tcb-ta-log__cell--action">
											{ a?.image && <img src={ a.image } alt="" className="tcb-ta-log__action-icon" /> }
											<span className="tcb-ta-log__action-name">{ nameFor( catalog, e.action, subOpOf( e ) ) }</span>
										</span>
										<span className="tcb-ta-log__cell tcb-ta-log__cell--outcome">
											<span className={ `tcb-ta-log__pill tcb-ta-log__pill--${ e.outcome }` }>{ outcomeLabel( e.outcome ) }</span>
										</span>
										<span className="tcb-ta-log__cell tcb-ta-log__cell--chev"><IconChevD /></span>
									</button>
									{ open && <DetailBlock e={ e } fieldLabels={ fieldLabels } /> }
								</div>
							);
						} ) : (
							<div className="tcb-ta-log__empty">
								<div className="tcb-ta-log__empty-icon"><IconBolt /></div>
								<p className="tcb-ta-log__empty-title">{ hasAny ? __( 'Nothing matches this filter', 'thrive-cb' ) : ( loaded ? __( 'No submissions yet', 'thrive-cb' ) : __( 'Loading…', 'thrive-cb' ) ) }</p>
								{ loaded && (
									<p className="tcb-ta-log__empty-text">
										{ hasAny
											? __( 'Try a different outcome, action, or email search.', 'thrive-cb' )
											: __( 'Submit your live form once and every Thrive Action run - scheduled, fired, skipped or failed - appears here.', 'thrive-cb' ) }
									</p>
								) }
							</div>
						) }
					</div>
					<div className="tcb-ta-log__capnote">{ sprintf( /* translators: %d: max log entries kept */ __( 'Shows up to the last %d log entries for this form - older entries are trimmed automatically.', 'thrive-cb' ), cap ) }</div>
				</div>
			</div>
		</div>
	);
}