/**
 * Demo-page fixtures. The editor's catalog is served by the executor registry
 * through PHP (see class-tcb-automations-rest.php); the standalone demo runs
 * outside WordPress with no registry to ask, so it renders these instead.
 * They exist to exercise the configurator, not to define product behaviour -
 * the shipped strings live in each plugin's executor.
 */
import { __ } from '@wordpress/i18n';
import type { ActionDescriptor, ConfiguratorAdapters, TargetOption } from '../src/ActionConfigurator/types';
import apprenticeCard from '../src/assets/ta-apprentice-card.png';
import optimizeCard from '../src/assets/ta-optimize-card.png';
import ultimatumCard from '../src/assets/ta-ultimatum-card.png';
import ovationCard from '../src/assets/ta-ovation-card.png';
import subopGrant from '../src/assets/subop-grant.png';
import subopRevoke from '../src/assets/subop-revoke.png';
import subopStart from '../src/assets/subop-start.png';
import subopStop from '../src/assets/subop-stop.png';

export const DEMO_CATALOG: ActionDescriptor[] = [
	{
		id: 'apprentice_access',
		label: __( 'Apprentice access', 'thrive-cb' ),
		description: __( 'Grant or revoke access to a course or bundle', 'thrive-cb' ),
		image: apprenticeCard,
		targetPrompt: __( 'Which Apprentice product?', 'thrive-cb' ),
		targetPromptByOp: { grant: __( 'Grant access to', 'thrive-cb' ), revoke: __( 'Revoke access to', 'thrive-cb' ) },
		displayNameByOp: { grant: __( 'Grant Apprentice access', 'thrive-cb' ), revoke: __( 'Revoke Apprentice access', 'thrive-cb' ) },
		/* Grant-only: revoke never creates users, so no helper there. */
		targetHelpByOp: { grant: __( 'Apprentice creates a WP user from the email if one doesn’t exist yet.', 'thrive-cb' ) },
		targetPlaceholder: __( 'Choose a product…', 'thrive-cb' ),
		summaryByOp: {
			grant: __( 'Apprentice will grant them access to %target%.', 'thrive-cb' ),
			revoke: __( 'Apprentice will revoke their access to %target%.', 'thrive-cb' ),
		},
		thenByOp: {
			grant: __( 'grant them access to %target%', 'thrive-cb' ),
			revoke: __( 'revoke their access to %target%', 'thrive-cb' ),
		},
		thenFallbackTarget: __( 'the selected product', 'thrive-cb' ),
		summaryPrompt: __( 'pick a product to see the preview', 'thrive-cb' ),
		subOperations: [
			{ id: 'grant', label: __( 'Grant access', 'thrive-cb' ), description: __( 'Give them access to a course or bundle', 'thrive-cb' ), tone: 'positive', image: subopGrant },
			{ id: 'revoke', label: __( 'Revoke access', 'thrive-cb' ), description: __( 'Remove access — their progress is preserved', 'thrive-cb' ), tone: 'negative', image: subopRevoke },
		],
	},
	{
		id: 'ultimatum_campaign',
		label: __( 'Ultimatum campaign', 'thrive-cb' ),
		description: __( 'Start or end a scarcity countdown for this user', 'thrive-cb' ),
		image: ultimatumCard,
		targetPrompt: __( 'Which campaign?', 'thrive-cb' ),
		targetPromptByOp: { start: __( 'Start campaign', 'thrive-cb' ), stop: __( 'End campaign', 'thrive-cb' ) },
		displayNameByOp: { start: __( 'Start Ultimatum campaign', 'thrive-cb' ), stop: __( 'End Ultimatum campaign', 'thrive-cb' ) },
		targetPlaceholder: __( 'Choose a campaign…', 'thrive-cb' ),
		targetHelpByOp: {
			start: __( 'Only evergreen campaigns currently running are listed.', 'thrive-cb' ),
			stop: __( 'Ends the selected evergreen campaign for this user. Mirrors the in-product "Conversion Events → End Campaign" behaviour.', 'thrive-cb' ),
		},
		summaryByOp: {
			start: __( 'Ultimatum will start %target% campaign for the submitter.', 'thrive-cb' ),
			stop: __( 'Ultimatum will end the running %target% campaign for the submitter.', 'thrive-cb' ),
		},
		thenByOp: {
			start: __( 'start %target% campaign', 'thrive-cb' ),
			stop: __( 'end the running %target% campaign', 'thrive-cb' ),
		},
		thenFallbackTarget: __( 'the selected campaign', 'thrive-cb' ),
		summaryPrompt: __( 'pick a campaign to see the preview', 'thrive-cb' ),
		subOperations: [
			{ id: 'start', label: __( 'Start campaign', 'thrive-cb' ), description: __( 'Start the campaign clock', 'thrive-cb' ), tone: 'positive', image: subopStart },
			{ id: 'stop', label: __( 'End campaign', 'thrive-cb' ), description: __( 'End an in-progress campaign', 'thrive-cb' ), tone: 'negative', image: subopStop },
		],
	},
	{
		id: 'ovation_request',
		label: __( 'Ovation request', 'thrive-cb' ),
		description: __( 'Email the submitter asking for a testimonial', 'thrive-cb' ),
		image: ovationCard,
		targetPrompt: __( 'Testimonial request email', 'thrive-cb' ),
		targetHelp: __( 'Sends the user your default Ovation testimonial-request email — the same one configured under', 'thrive-cb' ),
		targetPlaceholder: '',
		noTarget: true,
		/* #4080's deep-link route: opens the Customer Experience section with the request-template modal. */
		noTargetLink: { label: __( 'Ovation → Testimonial Request Template', 'thrive-cb' ), href: '/wp-admin/admin.php?page=tvo_admin_dashboard#settings/request' },
		implicitTarget: { id: 'default', label: __( 'Default template', 'thrive-cb' ) },
		summaryByOp: { '': 'Ovation will email the submitter your default testimonial-request template.' },
		thenByOp: { '': 'email the submitter a testimonial request' },
	},
	{
		id: 'optimize_conversion',
		label: __( 'Optimize conversion', 'thrive-cb' ),
		description: __( 'Count this submission as an A/B test conversion', 'thrive-cb' ),
		image: optimizeCard,
		/* Not part of the visual design handoff (3 cards) - hidden from the
		 * picker, not removed: executor, boot flag and tests stay intact, and
		 * forms that already configured it keep rendering. Unhide by deleting
		 * this flag. */
		hidden: true,
		targetPrompt: __( 'Record a conversion', 'thrive-cb' ),
		targetHelp: __( 'Counts this submission as a conversion for the A/B test running on this page, attributed to the variation the visitor saw', 'thrive-cb' ),
		targetPlaceholder: '',
		noTarget: true,
		implicitTarget: { id: 'page_test', label: __( 'A/B test on this page', 'thrive-cb' ) },
		/* Conversion must be locked to the submission moment for correct attribution. */
		hideTiming: true,
		extraFields: [
			{ key: 'goal_name', label: __( 'Custom goal name (optional)', 'thrive-cb' ), type: 'text', placeholder: __( 'e.g. newsletter-signup', 'thrive-cb' ) },
			{ key: 'revenue', label: __( 'Conversion value in $ (optional)', 'thrive-cb' ), type: 'number', placeholder: __( '0', 'thrive-cb' ) },
		],
		summaryByOp: { '': 'Optimize will record a conversion for the A/B test running on this page.' },
		thenByOp: { '': 'record an Optimize conversion' },
	},
];

/* Mock target options - the demo has no WordPress to ask. */

const MOCK_TARGETS: Record<string, TargetOption[]> = {
	apprentice_access: [
		{ id: 1, label: 'Photography Masterclass' },
		{ id: 2, label: 'Lightroom Basics' },
		{ id: 3, label: 'Pro Bundle' },
	],
	ultimatum_campaign: [
		{ id: 11, label: 'Spring Sale 72h' },
		{ id: 12, label: 'Webinar Follow-up' },
		{ id: 13, label: 'Black Friday' },
	],
	ovation_request: [
		{ id: 'default', label: 'Default request template' },
		{ id: 'short', label: 'Short & friendly' },
		{ id: 'post-course', label: 'Post-course ask' },
	],
};

export const demoAdapters: ConfiguratorAdapters = {
	getTargets: ( actionId: string ) =>
		new Promise<TargetOption[]>( ( resolve ) =>
			setTimeout( () => resolve( MOCK_TARGETS[ actionId ] ?? [] ), 250 )
		),
};
