/**
 * Standalone demo for the shared action configurator (#4047).
 * Mock catalog + adapters; no persistence. Open demo/index.html after build.
 */
import { useState } from 'react';
import { createRoot } from 'react-dom/client';
import { Button } from '@thrive-themes/ui-components';
import ActionConfigurator from '../src/ActionConfigurator/ActionConfigurator';
import { DEMO_CATALOG, demoAdapters } from './catalog-fixtures';
import type { ActionConfig } from '../src/ActionConfigurator/types';
import './demo.css';

function Demo() {
	const [ open, setOpen ] = useState( true );
	const [ saved, setSaved ] = useState<ActionConfig | null>( null );

	return (
		<div style={ { padding: 24 } }>
			<Button color="primary" onClick={ () => setOpen( true ) }>
				Add a Thrive Action
			</Button>
			{ saved && (
				<pre style={ { marginTop: 16, background: '#fff', padding: 12, fontSize: 12, borderRadius: 6, border: '1px solid #dcdcde' } }>
					{ JSON.stringify( saved, null, 2 ) }
				</pre>
			) }
			<ActionConfigurator
				open={ open }
				actions={ DEMO_CATALOG }
				adapters={ demoAdapters }
				value={ null }
				onSave={ ( config ) => {
					setSaved( config );
					setOpen( false );
				} }
				onCancel={ () => setOpen( false ) }
			/>
		</div>
	);
}

createRoot( document.getElementById( 'demo-root' )! ).render( <Demo /> );
