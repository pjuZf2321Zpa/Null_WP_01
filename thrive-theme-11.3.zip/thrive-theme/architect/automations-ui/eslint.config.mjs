/**
 * Island lint config (#4047). Borrowed from packages/thrive-ui-components with
 * one deliberate omission: no eslint-plugin-prettier. The island follows the
 * repo's WordPress-style spacing (`__( 'x' )`), which Prettier would reformat
 * wholesale - a diff that would bury the actual review. Correctness rules only;
 * formatting stays the reviewer's call.
 */
import globals from 'globals';
import pluginJs from '@eslint/js';
import tseslint from 'typescript-eslint';
import pluginReact from 'eslint-plugin-react';
import pluginReactHooks from 'eslint-plugin-react-hooks';

export default [
	{ files: [ '**/*.{js,mjs,cjs,ts,jsx,tsx}' ] },
	{ ignores: [ '**/node_modules/**', '**/dist/**', '**/scripts/**' ] },
	{ languageOptions: { globals: { ...globals.browser, ...globals.node } } },
	pluginJs.configs.recommended,
	...tseslint.configs.recommended,
	pluginReact.configs.flat.recommended,
	{
		plugins: { 'react-hooks': pluginReactHooks },
		rules: {
			...pluginReactHooks.configs.recommended.rules,
			/* The island uses the automatic JSX runtime. */
			'react/react-in-jsx-scope': 'off',
			'react/prop-types': 'off',
			'no-console': 'error',
		},
		settings: { react: { version: 'detect' } },
	},
];
