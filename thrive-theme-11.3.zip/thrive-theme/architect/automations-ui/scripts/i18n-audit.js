/**
 * Flags user-facing strings in src/ that are not wrapped in __().
 *
 * Exists because a partial wrap shipped once already: a sweep that stopped
 * early left fireLine(), the card titles and the whole empty state in English
 * while the file still looked translated (it had other __() calls in it), and
 * counting calls could not tell the difference. Run this instead - it reads
 * what is NOT wrapped.
 *
 * Heuristic by nature: JSX text nodes and capitalised string literals. Exits
 * non-zero when it finds something, so it can gate a build later, but it is
 * deliberately not chained into `build` today - a false positive should not
 * block shipping. Add a genuine non-string exception to ALLOW below.
 */
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname( fileURLToPath( import.meta.url ) );
const srcDir = path.resolve( __dirname, '../src' );

/** Values that look like copy but are not: DOM keys, CSS, wire values. */
const ALLOW = new Set( [ 'Escape', 'Enter', 'Tab', 'ArrowUp', 'ArrowDown' ] );

const JSX_TEXT = />([A-Z][^<>{}\n]{3,})</g;
const LITERAL = /(?:return|=|\?|:)\s*'([A-Z][^']{4,})'/g;

function walk( dir ) {
	return fs.readdirSync( dir, { withFileTypes: true } ).flatMap( ( entry ) => {
		const full = path.join( dir, entry.name );
		if ( entry.isDirectory() ) {
			return walk( full );
		}
		return /\.tsx?$/.test( entry.name ) ? [ full ] : [];
	} );
}

let findings = 0;

for ( const file of walk( srcDir ) ) {
	const content = fs.readFileSync( file, 'utf8' );
	const hits = [];

	for ( const re of [ JSX_TEXT, LITERAL ] ) {
		for ( const match of content.matchAll( re ) ) {
			const text = match[ 1 ].trim();
			if ( ! ALLOW.has( text ) ) {
				hits.push( text );
			}
		}
	}

	if ( hits.length ) {
		findings += hits.length;
		console.log( `\n${ path.relative( srcDir, file ) }` );
		hits.forEach( ( hit ) => console.log( `  untranslated: ${ hit }` ) );
	}
}

if ( findings ) {
	console.log( `\n${ findings } untranslated string(s). Wrap them: __( '...', 'thrive-cb' )` );
	process.exit( 1 );
}

console.log( 'i18n audit: no untranslated strings in src/' );
