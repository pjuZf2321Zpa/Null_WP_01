import { defineConfig } from 'vitest/config';
import react from '@vitejs/plugin-react';
import path from 'path';

/**
 * One runner for the shared configurator AND the Apprentice Triggers island
 * (#4671). The island already reaches into this package's source through the
 * `@automations-ui` alias (see thrive-apprentice/admin/src/webpack.config.js
 * and its tsconfig `paths`), so the two form one source graph and the tests
 * for both live under this config. The island's own test file is type-checked
 * separately, through tsconfig.island-tests.json (`npm run typecheck:island`),
 * because the island itself has no vitest types. `npm run check` runs both
 * typechecks and the suite; the build scripts stay self-contained because the
 * release workspaces and their Node runtimes cannot run vitest (#4671 review).
 */
export default defineConfig( {
	plugins: [ react( { jsxRuntime: 'automatic' } ) ],
	/* Aliasing @thrive-themes/ui-components to its source entry (below) pulls
	 * in its generated icon components, which are JSX but keep a plain .js
	 * extension - esbuild's default loader for .js is not jsx. Mirrors
	 * packages/thrive-ui-components/vitest.config.ts. `vitest` is pinned to an
	 * exact 4.0.18 in package.json (rather than the brief's `^4.0.18`) so its
	 * `vite` peer stays on the ^7.0.0 line: vite 8 defaults its JS/JSX
	 * transform to Oxc, which has no per-file loader override, can't be told
	 * `.js` here means JSX, and can't be turned off from this file - the
	 * react plugin injects its own `oxc` config unconditionally whenever it
	 * detects a vite build that carries `rolldownVersion` (true for vite 8),
	 * overriding anything set here. */
	esbuild: {
		include: /\.(tsx?|jsx?)$/,
		exclude: [],
		loader: 'tsx',
	},
	test: {
		globals: true,
		environment: 'jsdom',
		setupFiles: './src/test/setup.ts',
		include: [
			'src/**/*.test.{ts,tsx}',
			'../../thrive-apprentice/admin/src/triggers/**/*.test.{ts,tsx}',
		],
	},
	resolve: {
		/* The ui-components alias below points at that package's SOURCE, which
		 * lives in a sibling package with its own installed `react` copy - a
		 * separate module instance from the one this package's own
		 * node_modules resolves. React's hook dispatcher lives on the specific
		 * `react` instance react-dom was given, so a ui-components component
		 * (Select) that resolves the OTHER copy breaks its own hooks
		 * ("Cannot read properties of null (reading 'useState')"). Dedupe
		 * collapses both back to one instance. Same story for
		 * `@wordpress/i18n`: the island, this package, and ui-components
		 * each carry their own copy, and its setLocaleData/__ calls need
		 * to land on one shared module instance rather than three. */
		dedupe: [ 'react', 'react-dom', '@wordpress/i18n', '@testing-library/react' ],
		alias: {
			'@automations-ui': path.resolve( __dirname, './src' ),
			/* The published dist/main.js UMD bundle fails to parse under Vite's
			 * esbuild transform when run through vitest ("): )" not found" at the
			 * bundle's own line 8, unrelated to any file we authored). Point at
			 * the package's source entry instead so it goes through the same
			 * React/esbuild pipeline as our own files. Because this loads
			 * ui-components' real source rather than its built dist, that
			 * package's own node_modules must be installed too (pnpm install
			 * at the repo root) - the two hard-coded paths below (index.tsx,
			 * src/scss/abstracts) follow that package's layout. */
			'@thrive-themes/ui-components': path.resolve( __dirname, '../../packages/thrive-ui-components/index.tsx' ),
		},
	},
	css: {
		preprocessorOptions: {
			scss: {
				additionalData: `@use "${ path.resolve( __dirname, '../../packages/thrive-ui-components/src/scss/abstracts' ) }" as *;`,
				quietDeps: true,
				silenceDeprecations: [ 'legacy-js-api' ],
			},
		},
	},
} );
