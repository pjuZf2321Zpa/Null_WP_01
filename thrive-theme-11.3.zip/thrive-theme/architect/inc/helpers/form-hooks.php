<?php

use TCB\inc\helpers\FormSettings;

/**
 * Processes each form settings instance, saving it to the database
 *
 * @param array $forms array of form settings
 * @param int   $post_parent
 *
 * @return array map of replacements
 */
function tve_save_form_settings( $forms, $post_parent ) {
	$replaced   = [];
	$post_title = 'Form settings' . ( $post_parent ? ' for content ' . $post_parent : '' );

	foreach ( $forms as $form ) {
		$id       = ! empty( $form['id'] ) ? (int) $form['id'] : 0;
		$instance = FormSettings::get_one( $form['id'], $post_parent );

		/* Thrive Actions (#4053): removing or editing an action cancels its
		 * still-waiting scheduled jobs - the pending job carries the old
		 * config, which the user just replaced. */
		$old_actions = is_array( $instance->tta_actions ) ? $instance->tta_actions : [];

		$instance->set_config( wp_unslash( $form['settings'] ) )
		         ->save( $post_title, empty( $post_parent ) ? null : [ 'post_parent' => $post_parent ] );

		if ( function_exists( 'tta_cancel_pending' ) && $old_actions ) {
			$new_actions = is_array( $instance->tta_actions ) ? $instance->tta_actions : [];
			$changed     = tta_changed_action_ids( $old_actions, $new_actions );
			if ( $changed ) {
				tta_cancel_pending( $instance->ID, $changed );
			}
		}

		if ( $instance->ID !== $id ) {
			$replaced[ $form['id'] ] = $instance->ID;
		}
	}

	return $replaced;
}

/**
 * Delete one or multiple form settings
 *
 * @param array|int|string $id
 */
function tve_delete_form_settings( $id ) {
	if ( empty( $id ) ) {
		return;
	}

	if ( ! is_array( $id ) ) {
		$id = [ $id ];
	}

	/* Pending Thrive Actions are cancelled by FormSettings::delete() itself
	 * (#3535). It lives there, not here: this function covers the editor's
	 * deleted_forms list, page deletion and Leads, but the editor's
	 * action_form_settings_delete() AJAX endpoint deletes the settings post
	 * without coming through here at all. */
	foreach ( $id as $form_id ) {
		FormSettings::get_one( (int) $form_id )->delete();
	}
}

/**
 * Whether the current user may write to or delete a stored form-settings record through an editor request.
 *
 * The editor dispatcher authorises a single post id - the request's `post_id` - and then hands the whole
 * request body to this filter, so a record named by any other field in that body has had no check of its
 * own. This is that check, and it is bound to the record rather than to the request.
 *
 * The capability is tested against the record's parent, which is the post the form lives on, so editing a
 * form is governed by the same capability as editing the page that renders it.
 *
 * Records with no parent are the ones saved from a symbol or a content template, and every file-upload
 * config, which is always stored without a parent. Those are authorised by authorship instead: whoever
 * created the record may edit it, and so may any role that can edit other people's posts. `edit_post` is
 * deliberately not used for them, because `_tcb_form_settings` is never passed to register_post_type(),
 * and a meta capability check against an unregistered post type is unreliable and emits a
 * _doing_it_wrong notice on every call.
 *
 * This deliberately lives at the write boundary rather than inside `FormSettings::get_one()`, which the
 * audit proposed: `get_one()` is also the read path used by `tve_api_form_submit()` and by the file-upload
 * validators while an anonymous visitor submits a form, and a capability check there would fail for every
 * logged-out submission.
 *
 * @param int|string $id        record id.
 * @param string     $post_type expected post type; defaults to form settings.
 *
 * @return bool true when the record exists, is of the expected type, and the caller may edit it.
 */
function tve_user_can_edit_form_settings( $id, $post_type = '' ) {
	$post      = get_post( (int) $id );
	$post_type = $post_type ?: FormSettings::POST_TYPE;

	if ( ! $post || $post->post_type !== $post_type ) {
		return false;
	}

	$parent = (int) $post->post_parent;

	if ( $parent > 0 ) {
		return current_user_can( 'edit_post', $parent );
	}

	$user_id = get_current_user_id();

	return ( $user_id > 0 && (int) $post->post_author === $user_id ) || current_user_can( 'edit_others_posts' );
}

/**
 * Delete all forms specific to a post
 *
 * @param $post_id
 *
 * @return void
 */
function tve_delete_post_form_settings( $post_id ) {
	foreach ( tve_form_owner_settings_ids( $post_id ) as $id ) {
		tve_delete_form_settings( $id );
	}
}

/**
 * The form settings posts a page owns (its own forms - not forms it merely
 * displays, whose settings belong to another post).
 *
 * @param int $post_id
 *
 * @return int[]
 */
function tve_post_form_settings_ids( $post_id ) {
	$query = new \WP_Query( [
			'post_type'      => [
				FormSettings::POST_TYPE,
			],
			/* Settings posts are saved without a status, so WordPress stores
			 * them as drafts - without this the query defaults to `publish`,
			 * matches nothing, and deleting a page neither removes its form
			 * settings nor cancels the Thrive Actions still waiting to fire. */
			'post_status'    => 'any',
			'fields'         => 'ids',
			'post_parent'    => $post_id,
			'posts_per_page' => '-1',
		]
	);

	return array_map( 'intval', $query->posts );
}

/**
 * The post types that hold a form for OTHER posts to display: Thrive Symbols,
 * Thrive Lightboxes, and Theme Builder templates and sections. A form in one of
 * these exists nowhere but the container, while the runs it queues always record
 * the page the visitor submitted on - so ownership and "the post the run came
 * from" are never the same post (#4051 QA).
 *
 * String literals, not THRIVE_TEMPLATE / THRIVE_SECTION: Thrive Theme Builder is
 * a theme, so its constants are undefined when this file is required at plugin
 * load.
 *
 * @return string[]
 */
function tve_form_owner_container_post_types() {
	/**
	 * Post types whose forms they own outright, wherever those forms are shown.
	 *
	 * @param string[] $types
	 */
	return (array) apply_filters( 'tve_form_owner_container_post_types', array(
		'tcb_symbol',
		'tcb_lightbox',
		'thrive_template',
		'thrive_section',
	) );
}

/**
 * @param int $post_id
 *
 * @return bool
 */
function tve_form_owner_is_container( $post_id ) {
	return in_array( (string) get_post_type( $post_id ), tve_form_owner_container_post_types(), true );
}

/**
 * The form-settings posts a container holds in its own content.
 *
 * Needed because a Symbol's settings post has no parent at all: symbol edit mode
 * saves with `ignore_post_parent`, so tve_post_form_settings_ids() finds nothing
 * for it and trashing or deleting a Symbol used to cancel nothing. The content
 * reference is the same ground truth tve_form_settings_in_use_elsewhere() already
 * trusts, read the other way round.
 *
 * @param int $post_id
 *
 * @return int[]
 */
function tve_form_settings_ids_in_content( $post_id ) {
	$post = get_post( $post_id );

	if ( ! $post ) {
		return array();
	}

	/* Architect keeps its markup in POSTMETA - tve_updated_post and
	 * tve_content_before_more - and leaves post_content empty, which is why
	 * tve_form_settings_in_use_elsewhere() scans postmeta as well. Reading only
	 * post_content finds nothing on a real Architect post. */
	$haystack = (string) $post->post_content;
	foreach ( get_post_meta( $post->ID ) as $values ) {
		foreach ( (array) $values as $value ) {
			if ( is_string( $value ) && false !== strpos( $value, 'data-settings-id' ) ) {
				$haystack .= ' ' . $value;
			}
		}
	}

	if ( ! preg_match_all( '/data-settings-id="(\d+)"/', $haystack, $matches ) ) {
		return array();
	}

	$ids = array();
	foreach ( array_unique( $matches[1] ) as $id ) {
		$settings = get_post( (int) $id );

		if ( ! $settings || FormSettings::POST_TYPE !== $settings->post_type ) {
			continue;
		}

		/* Claim it when it is ours by parent, or when no OTHER live content
		 * references it once this container is excluded.
		 *
		 * post_parent alone is not ownership: a form built on a page and then
		 * turned into a Symbol keeps post_parent pointing at the page while only
		 * the Symbol still holds the markup, so the page becomes a stale owner.
		 * Conversely a form genuinely shared with a page that still has its own
		 * copy must NOT be cancelled by trashing the Symbol. That is exactly
		 * what tve_form_settings_in_use_elsewhere() answers, with revisions and
		 * auto-drafts already discounted. */
		if ( (int) $settings->post_parent === (int) $post->ID
			|| ! tve_form_settings_in_use_elsewhere( $settings->ID, 0, (int) $post->ID ) ) {
			$ids[] = (int) $settings->ID;
		}
	}

	return $ids;
}

/**
 * Is this form held by a CONTAINER other than the given post? Narrower than
 * tve_form_settings_in_use_elsewhere(): only the post types that own a form
 * outright count, and nothing outside wp_posts is consulted.
 *
 * Used to decide whether a `post_parent` claim has gone stale. The wider check
 * cannot answer that, because a Thrive Leads form's markup lives in the
 * tve_leads_form_variations table, which it matches without being able to
 * exclude the form's own row - so a TL form type would always look like
 * somebody else's (#4051 QA).
 *
 * @param int|string $settings_id
 * @param int        $exclude_post_id the post whose claim is being judged
 *
 * @return bool
 */
function tve_form_settings_held_by_container( $settings_id, $exclude_post_id = 0 ) {
	global $wpdb;

	$types = tve_form_owner_container_post_types();

	if ( empty( $types ) || ! (int) $settings_id ) {
		return false;
	}

	$needle       = '%' . $wpdb->esc_like( 'data-settings-id="' . (int) $settings_id . '"' ) . '%';
	$placeholders = implode( ', ', array_fill( 0, count( $types ), '%s' ) );
	$args         = array_merge( array( $needle ), array_values( $types ), array( (int) $exclude_post_id ) );

	/* Revisions are excluded for free: their post_type is `revision`, never a
	 * container type. */
	if ( $wpdb->get_var( $wpdb->prepare(
		"SELECT ID FROM {$wpdb->posts} WHERE post_content LIKE %s AND post_type IN ( {$placeholders} ) AND post_status <> 'auto-draft' AND ID <> %d LIMIT 1",
		$args
	) ) ) {
		return true;
	}

	return (bool) $wpdb->get_var( $wpdb->prepare(
		"SELECT m.meta_id FROM {$wpdb->postmeta} m INNER JOIN {$wpdb->posts} p ON p.ID = m.post_id WHERE m.meta_value LIKE %s AND p.post_type IN ( {$placeholders} ) AND p.post_status <> 'auto-draft' AND m.post_id <> %d LIMIT 1",
		$args
	) );
}

/**
 * Every form-settings post this post speaks for: the ones it parents, plus - for
 * a container - the ones its own content references.
 *
 * @param int $post_id
 *
 * @return int[]
 */
function tve_form_owner_settings_ids( $post_id ) {
	$parented     = tve_post_form_settings_ids( $post_id );
	$is_container = tve_form_owner_is_container( $post_id );

	/* Nothing parented here and nothing a container could hold, so there is
	 * nothing for the content scan to decide. Worth the early return because
	 * that scan reads every meta row on the post and then runs a LIKE query per
	 * reference, and this function is reached from five hook registrations for
	 * every post type - emptying a large trash used to pay it per post. */
	if ( ! $parented && ! $is_container ) {
		return array();
	}

	$own = tve_form_settings_ids_in_content( $post_id );
	$ids = array();

	foreach ( $parented as $id ) {
		/* post_parent records who CREATED the settings post, which stops being
		 * ownership the moment the form moves. Build a form on a page and turn
		 * it into a Symbol and the parent still says "page", while only the
		 * Symbol holds the markup - trashing the page then cancelled runs for a
		 * form that is still live inside the Symbol.
		 *
		 * Only drop it when this post no longer holds the form AND a container
		 * does - a container being the only thing that can take ownership away.
		 * Judging it by "anything else references it" would strip a Thrive Leads
		 * form type of its own form, since TL markup lives in a table that
		 * cannot be excluded by post id. A post whose content this cannot read
		 * keeps its claim either way, so the failure mode stays "cancels"
		 * rather than "keeps firing". */
		if ( ! in_array( (int) $id, $own, true ) && tve_form_settings_held_by_container( $id, (int) $post_id ) ) {
			continue;
		}

		$ids[] = (int) $id;
	}

	if ( $is_container ) {
		$ids = array_merge( $ids, $own );
	}

	return array_values( array_unique( $ids ) );
}

/**
 * Is a form-settings post still referenced by content OTHER than the post
 * being saved? Checks post content (pages, posts), postmeta (Optimize
 * variations store TAR content in tve_updated_post), and the Thrive Leads
 * variations table. Runs only when the editor asks to delete a form - rare.
 *
 * @param int|string $settings_id
 * @param int        $exclude_post_id      the post whose save requested the delete
 *                                         (its stored copy still holds the old markup).
 * @param int        $exclude_variation_key the Thrive Leads variation being saved.
 *                                          Its row is rewritten AFTER this pre-save
 *                                          runs, so it still holds the form just
 *                                          removed - the same stale copy the page and
 *                                          the container are excluded for. Excluded by
 *                                          `key` rather than `post_parent` so a sibling
 *                                          variation's own copy still counts (#4051
 *                                          review).
 * @param int        $exclude_container_id the Symbol / template / section being
 *                                         saved, when the delete came from editing
 *                                         one inside a page. Its content is written
 *                                         AFTER this pre-save runs, so it still
 *                                         holds the markup of the form just removed
 *                                         - the same stale copy the page is excluded
 *                                         for (#4051 QA).
 *
 * @return bool
 */
function tve_form_settings_in_use_elsewhere( $settings_id, $exclude_post_id = 0, $exclude_container_id = 0, $exclude_variation_key = 0 ) {
	global $wpdb;

	$settings_id = (int) $settings_id;
	if ( ! $settings_id ) {
		return false;
	}

	$needle = '%' . $wpdb->esc_like( 'data-settings-id="' . $settings_id . '"' ) . '%';

	// Revisions and auto-drafts hold the page's OLD content, which still carries
	// the just-removed form markup - they are not independent references.
	// (revision is a post_type; auto-draft is a post_status.)
	if ( $wpdb->get_var( $wpdb->prepare( "SELECT ID FROM {$wpdb->posts} WHERE post_content LIKE %s AND post_type <> 'revision' AND post_status <> 'auto-draft' AND ID <> %d AND ID <> %d LIMIT 1", $needle, $exclude_post_id, $exclude_container_id ) ) ) {
		return true;
	}

	if ( $wpdb->get_var( $wpdb->prepare( "SELECT m.meta_id FROM {$wpdb->postmeta} m INNER JOIN {$wpdb->posts} p ON p.ID = m.post_id WHERE m.meta_value LIKE %s AND p.post_type <> 'revision' AND p.post_status <> 'auto-draft' AND m.post_id <> %d AND m.post_id <> %d LIMIT 1", $needle, $exclude_post_id, $exclude_container_id ) ) ) {
		return true;
	}

	/* `key` is the table's primary key, and it is a reserved word so it has to
	 * be quoted. This selected a non-existent `id` column until #4051 QA, which
	 * made the query error out and the whole branch silently answer "not in
	 * use" - so a form-settings post that only a Thrive Leads variation still
	 * referenced was deleted anyway. */
	$tl_table = $wpdb->prefix . 'tve_leads_form_variations';
	if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $tl_table ) ) === $tl_table
		&& $wpdb->get_var( $wpdb->prepare( "SELECT `key` FROM `{$tl_table}` WHERE content LIKE %s AND `key` <> %d LIMIT 1", $needle, (int) $exclude_variation_key ) ) ) {
		return true;
	}

	return false;
}

/**
 * Dispatch configured Thrive Actions (#3535) when a Lead Generation form is
 * submitted. The action list comes from the stored FormSettings post - never
 * from the request - so visitors cannot inject or alter actions.
 *
 * @param array $post sanitized submission data (includes _tcb_id).
 */
function tve_dispatch_thrive_actions( $post ) {
	if ( ! function_exists( 'tta_dispatch' ) || ! class_exists( 'TTA_Trigger_Context' ) || empty( $post['_tcb_id'] ) ) {
		return;
	}

	$settings = FormSettings::get_one( $post['_tcb_id'] );
	$actions  = $settings->tta_actions;

	if ( empty( $actions ) || ! is_array( $actions ) ) {
		/* Defensive trace: a submit that carries a _tcb_id but
		 * resolves to no actions is invisible otherwise - this is exactly the
		 * signature of stale markup pointing at a deleted/foreign settings
		 * post (cloned variations, deleted_forms) or of actions lost on save. */
		if ( function_exists( 'tve_dash_debug_log' ) ) {
			tve_dash_debug_log( sprintf(
				'TTA dispatch: no actions for _tcb_id=%d%s',
				(int) $post['_tcb_id'],
				null === $settings->ID ? ' (settings post missing, foreign, or unreadable)' : ''
			) );
		}

		return;
	}

	/* Condition fields address the visitor-submitted inputs only - internal
	 * request keys (tokens, connection configs, routing) stay out of context. */
	$internal = array( 'action', 'tcb_token', 'post_id', 'url', 'page_slug', 'tool', 'sp_field', 'form_identifier', 'consent_config', 'user_consent', 'gdpr', 'tve_labels', 'tve_mapping', 'thrive_leads' );
	$fields   = array();
	foreach ( $post as $key => $value ) {
		if ( strpos( $key, '_' ) === 0 || in_array( $key, $internal, true ) ) {
			continue;
		}
		/* A ticked checkbox group arrives as a list (`name[]` in the form).
		 * Keep it, so a condition on the group can see what was ticked
		 * (#4052 QA, Bug 1). Only Architect's own checkbox fields - any other
		 * list stays out, since every other consumer of this data (webhook
		 * tokens, email tags) expects scalars. */
		if ( is_scalar( $value ) || ( preg_match( '/^mapping_checkbox_\d+$/', $key ) && is_array( $value ) && $value && array_values( $value ) === $value && count( array_filter( $value, 'is_scalar' ) ) === count( $value ) ) ) {
			$fields[ $key ] = $value;
		}
	}

	$context = TTA_Trigger_Context::from_array( array(
		'user_id'    => (int) get_current_user_id(),
		'email'      => isset( $post['email'] ) ? (string) $post['email'] : '',
		'trigger'    => 'form_submitted',
		'source'     => 'architect_form',
		'entity_ids' => array(
			'form_settings_id' => (int) $post['_tcb_id'],
			'post_id'          => isset( $post['post_id'] ) ? (int) $post['post_id'] : 0,
		),
		'data'       => $fields,
	) );

	tta_dispatch( $context, $actions );
}
/* Priority 5: Optimize's own optin-conversion listener runs at 10 and sets the
 * conversion cookie with no revenue attached - a configured Optimize action
 * must record first so its revenue/goal win and the builtin dedups instead. */
add_action( 'tcb_api_form_submit', 'tve_dispatch_thrive_actions', 5 );

/**
 * Once a page is deleted remove also forms associated
 */
add_action( 'before_delete_post', static function ( $post_id, $post ) {
	if ( $post->post_type !== FormSettings::POST_TYPE ) {
		tve_delete_post_form_settings( $post_id );
	}
}, 10, 2 );

add_action( 'tve_leads_delete_post', 'tve_delete_post_form_settings', 10, 1 );

add_action( 'after_delete_post', 'tve_delete_post_form_settings' );

/**
 * #4051: Thrive Leads taking a form out of rotation - deleted, trashed or
 * archived - must cancel its queued Thrive Actions. Trashing and archiving
 * fire nothing else, so a form parked in Archived Forms kept granting access
 * and emailing visitors days later.
 *
 * Cancel only. The form settings stay, because a trashed or archived form is
 * restorable and a restored form whose settings are gone rejects every
 * submission. (A delete destroys them through Leads' own cascade, which runs
 * after this.)
 *
 * Unscoped: a Leads form's runs record the page its popup appeared on, never
 * the form type, so narrowing by post would match none of them.
 */
add_action( 'tve_leads_form_deactivated', static function ( $form_type_id, $reason = 'deleted', $subject = 'form' ) {
	if ( ! function_exists( 'tta_cancel_pending' ) ) {
		return;
	}

	$message = tve_run_cancelled_message( $reason, $subject );

	foreach ( tve_post_form_settings_ids( $form_type_id ) as $settings_id ) {
		tta_cancel_pending( $settings_id, array(), $message );
	}
}, 10, 3 );

/**
 * Why a queued run was cancelled, as the Submission Log shows it.
 *
 * One place for these: four paths cancel runs - a Lead Group form type, a
 * single form variation, and a page or container being trashed or deleted -
 * and they used to carry their own copies of the same sentences, so a reworded
 * one drifted out of step with the rest and translators saw near-duplicates.
 *
 * Naming what the user actually did matters: an archived form reading as
 * deleted sent QA looking for a delete that never happened (#4051 review).
 *
 * @param string $reason  deleted | trashed | archived. Honoured for the form
 *                        and page subjects. The container subjects below ignore
 *                        it and always say "deleted", because deleting the
 *                        container is the only thing that reaches them - Lead
 *                        Shortcodes and ThriveBoxes have no trash or archive of
 *                        their own, only their forms do. A caller that ever
 *                        needs another reason for a container should add the
 *                        sentence here rather than pass one that is ignored
 *                        (Aslam's review on PR #5617).
 * @param string $subject What the user acted on: form, page, or the Thrive
 *                        Leads container that held the form - shortcode or
 *                        thrivebox. A container is named rather than called
 *                        "the form", because deleting one takes every form
 *                        inside it and "the form was deleted" sends the reader
 *                        looking for a form they never touched (#5606).
 *                        Signup Segues are absent deliberately: they have no
 *                        variations and no form, so nothing queues a run.
 *
 * @return string
 */
function tve_run_cancelled_message( $reason, $subject = 'form' ) {
	switch ( $subject ) {
		case 'page':
			return 'trashed' === $reason
				? __( 'The page was moved to the Trash before this run fired.', 'thrive-cb' )
				: __( 'The page was deleted before this run fired.', 'thrive-cb' );
		case 'shortcode':
			return __( 'The Lead Shortcode was deleted before this run fired.', 'thrive-cb' );
		case 'thrivebox':
			return __( 'The ThriveBox was deleted before this run fired.', 'thrive-cb' );
	}

	switch ( $reason ) {
		case 'trashed':
			return __( 'The form was moved to the Trash before this run fired.', 'thrive-cb' );
		case 'archived':
			return __( 'The form was archived before this run fired.', 'thrive-cb' );
		default:
			return __( 'The form was deleted before this run fired.', 'thrive-cb' );
	}
}

/**
 * #5606: a single form variation going away must cancel its queued runs too.
 *
 * The listener above speaks for a Lead Group form, whose form type is a post
 * that parents its form settings. A Lead Shortcode or ThriveBox form has no
 * such post - the form IS the variation - so deleting one cancelled nothing and
 * the run fired for a form the user had deleted, creating the account and
 * sending the welcome email.
 *
 * Resolved from the variation's own markup rather than from the shortcode that
 * parents the form settings, which would take every other form in that
 * shortcode with it. The variation itself is excluded by key, since a trashed
 * row keeps its content - and a form still shown by a page or a Symbol is left
 * alone, because those runs belong to the copy that is still live.
 */
add_action( 'tve_leads_form_variation_deactivated', static function ( $variation_key, $markup, $reason = 'deleted' ) {
	if ( ! function_exists( 'tta_cancel_pending' ) || ! is_string( $markup ) || '' === $markup ) {
		return;
	}

	if ( ! preg_match_all( '/data-settings-id="(\d+)"/', $markup, $matches ) ) {
		return;
	}

	$message = tve_run_cancelled_message( $reason );

	foreach ( array_unique( $matches[1] ) as $settings_id ) {
		$settings_id = (int) $settings_id;
		$settings    = get_post( $settings_id );

		if ( ! $settings || FormSettings::POST_TYPE !== $settings->post_type ) {
			continue;
		}

		/* Still live somewhere else - another variation, a page, a Symbol - so
		 * the runs belong to that copy and must survive. */
		if ( tve_form_settings_in_use_elsewhere( $settings_id, 0, 0, (int) $variation_key ) ) {
			continue;
		}

		tta_cancel_pending( $settings_id, array(), $message );
	}
}, 10, 3 );

/**
 * Whether trashing / deleting this post should speak for its forms' queued
 * runs: public content only (pages, posts, landing pages). Uses the post
 * type's registered `public` flag, not is_post_type_viewable(), which
 * depends on the current user for types like Thrive Leads forms - and those
 * keep their own trash handling (#4051 QA).
 *
 * @param int $post_id
 *
 * @return bool
 */
function tve_form_owner_is_public_content( $post_id ) {
	$type = get_post_type_object( (string) get_post_type( $post_id ) );

	return $type && ! empty( $type->public ) && FormSettings::POST_TYPE !== $type->name;
}

/**
 * #3535 / #4051: trashing a page cancels its pending delayed Thrive Actions,
 * the same as deleting it - otherwise a trashed page keeps granting access,
 * starting campaigns and emailing visitors until the Trash is emptied.
 *
 * Only the queued runs are cancelled. The form settings stay, so a restored
 * page's form keeps its actions for new submissions; the cancelled runs do
 * not come back.
 *
 * Ownership decides, never the request (#4047 review). The page a visitor
 * submitted on is whatever page displayed the form - for a form in a Theme
 * Builder template or a Symbol, that is any post it appears on - so judging
 * by it would let an unrelated post's trashing cancel a site-wide form's
 * runs. The trade is that a page which only displays someone else's form
 * cancels nothing when trashed; its queued runs still fire.
 */
add_action( 'trashed_post', static function ( $post_id ) {
	if ( ! function_exists( 'tta_cancel_pending' )
		|| ( ! tve_form_owner_is_public_content( $post_id ) && ! tve_form_owner_is_container( $post_id ) ) ) {
		return;
	}

	$is_container = tve_form_owner_is_container( $post_id );

	foreach ( tve_form_owner_settings_ids( $post_id ) as $settings_id ) {
		/* For a page, only the runs submitted on THIS page: a copy made outside
		 * Architect keeps the original's form settings, and its runs must
		 * survive the original going to the Trash.
		 *
		 * A container has no such copy to protect - its form exists nowhere
		 * else once it is in the Trash - and its runs never record the
		 * container anyway, so narrowing by post would match none of them. */
		tta_cancel_pending(
			$settings_id,
			array(),
			tve_run_cancelled_message( 'trashed', $is_container ? 'form' : 'page' ),
			$is_container ? 0 : (int) $post_id
		);
	}
} );

/**
 * Deleting a page: say so on the cancelled runs. Runs before the delete hook
 * above, which would otherwise cancel them with the generic "removed or
 * edited" reason (FormSettings::delete()).
 */
add_action( 'before_delete_post', static function ( $post_id, $post ) {
	if ( ! function_exists( 'tta_cancel_pending' )
		|| ( ! tve_form_owner_is_public_content( $post_id ) && ! tve_form_owner_is_container( $post_id ) ) ) {
		return;
	}

	$is_container = tve_form_owner_is_container( $post_id );

	foreach ( tve_form_owner_settings_ids( $post_id ) as $settings_id ) {
		tta_cancel_pending(
			$settings_id,
			array(),
			tve_run_cancelled_message( 'deleted', $is_container ? 'form' : 'page' )
		);
	}
}, 9, 2 );

/**
 * Read the value of one hidden input out of a form's markup.
 *
 * Attributes are matched from their start (preceded by whitespace), never on a word boundary, so that
 * `data-name="…"` or `data-value="…"` cannot stand in for the real attribute.
 *
 * @param string $markup the form's markup
 * @param string $name   the input's name attribute
 *
 * @return string|null the value as the browser will submit it (entities decoded), or null when the input is not there
 */
function tve_form_hidden_field_value( $markup, $name ) {
	if ( ! preg_match( '#<input\s[^>]*?\sname="' . preg_quote( $name, '#' ) . '"[^>]*>#i', $markup, $input ) ) {
		return null;
	}

	return preg_match( '#\svalue="([^"]*)"#i', $input[0], $value ) ? trim( html_entity_decode( $value[1], ENT_QUOTES ) ) : '';
}

/**
 * Remove every form signature from content.
 *
 * @param string $content
 *
 * @return string
 */
function tve_form_strip_signatures( $content ) {
	if ( ! is_string( $content ) || strpos( $content, '_tcb_form_sig' ) === false ) {
		return $content;
	}

	$stripped = preg_replace( '#<input\s[^>]*?\sname="_tcb_form_sig"[^>]*>#i', '', $content );

	/* on a PCRE failure leave the content as it was rather than blanking it */
	return $stripped === null ? $content : $stripped;
}

/**
 * Sign the ids a rendered form is allowed to act on.
 *
 * A Lead Generation form carries, as hidden fields, the asset group it delivers and the webhook it fires.
 * Both travel with the submission, and the listeners on `tcb_api_form_submit` act on whatever ids arrive,
 * so a hand-built request could name any asset group or any webhook on the site. The form's stored settings
 * record cannot arbitrate this: it does not record the asset group, a form placed inside a post list never
 * receives a record at all, and a newly bound webhook only reaches the record one save later.
 *
 * So the binding is made where the form is produced. On every frontend render, each form carrying either
 * field is given a hidden signature over ( settings id, asset group, webhook id, consent configuration ), and the submission
 * handlers recompute it and drop both fields when it does not match. The value derives from the markup and
 * the site's salt, so it is deterministic and cached pages stay valid, it needs no stored record, so forms
 * without one are covered, and it needs no migration.
 *
 * Frontend renders only (see tve_form_is_editor_render()): in the editor the markup is what gets saved back,
 * and a signature must never be persisted into content. Any stale copy that does reach a render is removed
 * before re-signing, so content that passes through this filter more than once ends up signed exactly once.
 *
 * @param string $content rendered content
 *
 * @return string
 */
function tve_form_sign_bound_fields( $content ) {
	if ( ! is_string( $content ) || ( strpos( $content, 'name="_asset_group"' ) === false && strpos( $content, 'name="_td_webhook_id"' ) === false ) ) {
		return $content;
	}

	$content = tve_form_strip_signatures( $content );

	/*
	 * Each target is [ offset, markup, insert at ]. A <form> is signed just before its closing tag. Legacy content
	 * may have no <form> at all: lead-generation.js then wraps the container's children in one on the client, so
	 * such a container is signed right after its opening tag, where the wrapped form will contain the signature.
	 */
	$targets = [];

	if ( preg_match_all( '#<form(?:\s[^>]*)?>.*?</form>#is', $content, $forms, PREG_OFFSET_CAPTURE ) ) {
		foreach ( $forms[0] as $form ) {
			list( $markup, $offset ) = $form;

			$targets[] = [ $offset, $markup, $offset + strlen( $markup ) - strlen( '</form>' ) ];
		}
	}

	if ( preg_match_all( '#<(div)(?=\s)[^<>]*?\sclass="(?:[^"]*\s)?thrv_lead_generation_container(?:\s[^"]*)?"[^<>]*>#i', $content, $containers, PREG_OFFSET_CAPTURE ) ) {
		foreach ( $containers[0] as $index => $container ) {
			list( $opening, $offset ) = $container;

			$markup = tve_form_element_markup( $content, $offset, $opening, $containers[1][ $index ][0] );

			/* a container that holds its own <form>, or sits inside one, is covered by that form */
			if ( $markup === '' || preg_match( '#<form[\s>]#i', $markup ) || tve_form_offset_in_targets( $offset, $targets ) ) {
				continue;
			}

			$targets[] = [ $offset, $markup, $offset + strlen( $opening ) ];
		}
	}

	/* insert from the end of the content backwards, so no pending offset moves */
	usort( $targets, static function ( $a, $b ) {
		return $b[2] - $a[2];
	} );

	foreach ( $targets as $target ) {
		list( $offset, $markup, $insert_at ) = $target;

		$asset_group = (string) tve_form_hidden_field_value( $markup, '_asset_group' );
		$webhook_id  = (string) tve_form_hidden_field_value( $markup, '_td_webhook_id' );

		if ( $asset_group === '' && $webhook_id === '' ) {
			continue;
		}

		/* the settings id sits on the element wrapping the form, which is also what the frontend script sends as `_tcb_id` */
		$settings_id = '';
		if ( preg_match_all( '#<[a-z][^<>]*?\sclass="(?:[^"]*\s)?(?:thrv_lead_generation|tcb-registration-form)(?:\s[^"]*)?"[^<>]*>#i', substr( $content, 0, $offset ), $wrappers ) && ! empty( $wrappers[0] ) ) {
			if ( preg_match( '#\sdata-settings-id="([^"]*)"#i', end( $wrappers[0] ), $id ) ) {
				$settings_id = trim( $id[1] );
			}
		}

		$consent_config = tve_form_hidden_field_value( $markup, 'consent_config' );

		$field = '<input type="hidden" name="_tcb_form_sig" value="' . esc_attr( tve_form_bound_fields_signature( $settings_id, $asset_group, $webhook_id, $consent_config ) ) . '">';

		$content = substr_replace( $content, $field, $insert_at, 0 );
	}

	return $content;
}

/**
 * Whether an offset falls inside one of the targets collected so far.
 *
 * @param int   $offset
 * @param array $targets [ offset, markup, insert at ] each
 *
 * @return bool
 */
function tve_form_offset_in_targets( $offset, $targets ) {
	foreach ( $targets as $target ) {
		if ( $offset > $target[0] && $offset < $target[0] + strlen( $target[1] ) ) {
			return true;
		}
	}

	return false;
}

/**
 * The full markup of the element whose opening tag starts at $offset, up to and including its matching closing tag.
 *
 * @param string $content
 * @param int    $offset  where the opening tag starts
 * @param string $opening the opening tag
 * @param string $tag     the tag name
 *
 * @return string the element's markup, or an empty string when it is never closed
 */
function tve_form_element_markup( $content, $offset, $opening, $tag ) {
	$start = $offset + strlen( $opening );

	if ( ! preg_match_all( '#<(/?)' . preg_quote( $tag, '#' ) . '(?=[\s>/])[^>]*>#i', $content, $tags, PREG_OFFSET_CAPTURE, $start ) ) {
		return '';
	}

	$depth = 1;

	foreach ( $tags[0] as $index => $tag_match ) {
		$depth += $tags[1][ $index ][0] === '/' ? - 1 : 1;

		if ( $depth === 0 ) {
			return substr( $content, $offset, $tag_match[1] + strlen( $tag_match[0] ) - $offset );
		}
	}

	return '';
}

/**
 * Whether the content being rendered is headed for the editor, where it can be saved back.
 *
 * Deliberately not the second argument of `tve_thrive_shortcodes`: that is `$keep_config`, and frontend
 * renders pass `true` as well, e.g. every symbol rendered through TCB_Symbol_Template::symbol_render_shortcode(),
 * which defaults it to `true`. Nor wp_doing_ajax() or a REST request on their own: forms loaded over ajax or
 * REST on the frontend (Thrive Leads, post list pagination, conditional display) must be signed too.
 * The editor page, and every ajax / REST request it makes (they all carry `tar_editor_page`), are recognised here.
 *
 * Getting this wrong in the frontend direction silently breaks delivery for good, while signing an editor
 * render only persists a hidden input that every frontend render strips and recomputes, so only positive
 * evidence of the editor counts.
 *
 * @return bool
 */
function tve_form_is_editor_render() {
	return is_editor_page_raw( true ) || is_editor_page();
}

/**
 * On frontend contexts, always remove form settings from content, and sign what each form is allowed to act on
 */
add_filter( 'tve_thrive_shortcodes', static function ( $content, $keep_config ) {
	if ( ! $keep_config && strpos( $content, FormSettings::SEP ) !== false ) {
		$content = preg_replace( FormSettings::pattern( true ), '', $content );
	}

	/* most content holds no delivery form: leave it before asking whether this is the editor */
	if ( ! is_string( $content ) || ( strpos( $content, '_asset_group' ) === false && strpos( $content, '_td_webhook_id' ) === false && strpos( $content, '_tcb_form_sig' ) === false ) ) {
		return $content;
	}

	if ( tve_form_is_editor_render() ) {
		/* never let a signature be saved back into content */
		return tve_form_strip_signatures( $content );
	}

	return tve_form_sign_bound_fields( $content );
}, 10, 2 );

/**
 * Process content pre-save
 */
add_filter( 'tcb.content_pre_save', static function ( $response, $post_data ) {
	/**
	 * Allows skipping the process of saving form settings to database
	 *
	 * @param bool $skip whether or not to skip
	 *
	 * @return bool
	 */
	$process_form_settings = apply_filters( 'tcb_process_form_settings', true );

	if ( $process_form_settings && ! empty( $post_data['forms'] ) ) {
		/**
		 * save form settings to the database
		 */
		$post_id = isset( $post_data['post_id'] ) ? (int) $post_data['post_id'] : 0;
		if ( ! empty( $post_data['ignore_post_parent'] ) ) {
			$post_id = null;
		}

		/*
		 * A form naming an existing record the caller may not edit is not dropped: its id is cleared, so
		 * the save below treats it as a new form and creates a fresh record under the post being saved,
		 * returning the replacement id the editor then writes back into the content. That is the same
		 * thing `FormSettings::get_one()` already does when a posted id belongs to a different parent,
		 * which is how a form element copied from another post gets its own record.
		 *
		 * Clearing the id rather than skipping the form is what keeps `ignore_post_parent` safe: nulling
		 * the parent above still skips the parent comparison inside `get_one()`, but a request can no
		 * longer overwrite a record belonging to a post the caller cannot edit, and no legitimate save
		 * silently loses its form settings.
		 */
		$forms      = [];
		$forced_new = [];
		foreach ( (array) $post_data['forms'] as $form ) {
			$form_id = ! empty( $form['id'] ) && is_numeric( $form['id'] ) ? (int) $form['id'] : 0;

			if ( $form_id && get_post( $form_id ) && ! tve_user_can_edit_form_settings( $form_id ) ) {
				/* a non-numeric id is what `get_one()` treats as "no record yet", which is how a new form is saved */
				$forced_new[ 'tve-form-' . $form_id ] = $form_id;
				$form['id']                           = 'tve-form-' . $form_id;
			}

			$forms[] = $form;
		}

		$replaced = tve_save_form_settings( $forms, $post_id );

		/* report the replacements against the ids the content actually carries, so the editor rewrites them */
		foreach ( $forced_new as $placeholder => $original_id ) {
			if ( isset( $replaced[ $placeholder ] ) ) {
				$replaced[ $original_id ] = $replaced[ $placeholder ];
				unset( $replaced[ $placeholder ] );
			}
		}

		$response['forms'] = $replaced;

		// generate response list of lead gen forms.
		$lead_gen_forms = [];
		foreach ( $forms as $form ) {
			if ( $form['settings'] ) {
				$form_attributes = ! empty( $form['settings'] ) ? json_decode( stripslashes( $form['settings'] ) ) : null;
				if ( ! is_null( $form_attributes ) && 'lead_generation' === $form_attributes->form_type ) {
					$lead_gen_forms[] = array(
						'form_identifier' => $form_attributes->form_identifier,
						'apis'            => $form_attributes->apis ? array_keys( (array) $form_attributes->apis ) : array(),
						'inputs'          => $form_attributes->inputs,
					);
				}
			}
		}

		$response['lead_gen_forms'] = $lead_gen_forms;
	}

	if ( $process_form_settings && ! empty( $post_data['deleted_forms'] ) ) {
		/*
		 * Deletion is permanent here: this post type is registered without trash support, so a removed
		 * record cannot be restored and has no admin screen to restore it from. Each id is therefore
		 * checked against the record it names before anything is removed.
		 */
		$deleted_forms = array_filter( (array) $post_data['deleted_forms'], 'tve_user_can_edit_form_settings' );

		/* #4053: settings posts can be referenced by content copies the editor
		 * never sees (Optimize variations, TL variations, duplicated pages).
		 * The editor's deleted_forms list only knows the root being saved -
		 * deleting a still-referenced post makes the other copy's Thrive
		 * Actions die silently (stale _tcb_id -> empty settings -> no log).
		 * Keep any settings post another piece of content still points at. */
		$exclude_post_id = isset( $post_data['post_id'] ) ? (int) $post_data['post_id'] : 0;
		/* #4051: editing a Symbol / template / section happens inside a page, so
		 * post_id above is the PAGE. The container's own content is written after
		 * this pre-save, so it still holds the form the user just deleted - its
		 * stale copy must not veto the delete any more than the page's does. */
		$exclude_container_id = isset( $post_data['container_id'] ) ? (int) $post_data['container_id'] : 0;
		/* Same stale copy, one layer out: a Thrive Leads form is edited inside the
		 * Leads editor, whose variation row is rewritten only after this pre-save
		 * returns. Without this the row still holds the form just removed and every
		 * Leads form looks "still in use" (#4051 review). */
		$exclude_variation_key = isset( $post_data['variation_key'] ) ? (int) $post_data['variation_key'] : 0;
		$deletable             = array();
		foreach ( $deleted_forms as $form_id ) {
			if ( ! tve_form_settings_in_use_elsewhere( $form_id, $exclude_post_id, $exclude_container_id, $exclude_variation_key ) ) {
				$deletable[] = $form_id;
			} elseif ( function_exists( 'tve_dash_debug_log' ) ) {
				tve_dash_debug_log( 'TTA: kept form settings ' . (int) $form_id . ' - still referenced by other content' );
			}
		}
		if ( $deletable ) {
			tve_delete_form_settings( array_values( $deletable ) );
		}
	}

	return $response;
}, 10, 2 );

