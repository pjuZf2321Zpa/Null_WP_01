<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

#[\AllowDynamicProperties]

/**
 * Affiliate Signup Widget class.
 *
 * @since 2.18.0
 */
class Affiliate_Signup_Widget {

	/**
	 * The ID of the affiliate widget container.
	 *
	 * @var string
	 */
	private $widget_container_class = 'affiliate-signup';

	/**
	 * Admin constructor.
	 *
	 * @since 2.18.0
	 */
	public function __construct() {
		// Display widget preview in admin.
		add_action( 'affwp_admin_affiliate_signup_widget_preview', [ $this, 'display' ] );

		// Register the customer as an affiliate.
		add_action( 'wp_ajax_affiliate_signup', [ $this, 'affiliate_signup' ] );
		add_action( 'wp_ajax_nopriv_affiliate_signup', [ $this, 'affiliate_signup' ] );

		// Enqueue scripts.
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_admin_scripts' ], 10, 1 );
		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_frontend_scripts' ], 10, 1 );

		/*
		 * Store hooks wait for init.
		 *
		 * They ask whether AffiliateWP has the integration *enabled*, not merely whether
		 * the plugin is loaded, and that answer needs the integration registry — which is
		 * not ready this early. It also has to be the same question the settings screen
		 * asks, or the widget renders on a storefront whose settings are hidden in admin.
		 *
		 * Being enabled is what makes AffiliateWP track that store's sales, so it is also
		 * the honest test: on a store we do not track, a customer who joined here would
		 * earn nothing from buying there.
		 */
		add_action( 'init', [ $this, 'register_store_hooks' ] );
	}

	/**
	 * Register the per-store display hooks.
	 *
	 * @since 2.35.4
	 */
	public function register_store_hooks() {

		/**
		 * WooCommerce
		 */
		if ( affwp_is_integration_active( 'woocommerce' ) ) {
			// Add the widget to the WooCommerce My Account page.
			add_action( 'woocommerce_account_dashboard', [ $this, 'maybe_display_account_dashboard' ] );

			// Maybe display widget on WooCommerce order confirmation page.
			add_action( 'woocommerce_thankyou', [ $this, 'maybe_display_order_confirmation' ] );

			// Maybe display widget on WooCommerce order details page.
			add_action( 'woocommerce_after_order_details', [ $this, 'maybe_display_order_details' ] );
		}

		/**
		 * Easy Digital Downloads.
		 *
		 * The same two moments WooCommerce gets: the purchase confirmation, and the
		 * customer's own purchase history. Deliberately not checkout — the customer is
		 * mid-purchase there, and asking them to join a program is a distraction from
		 * paying. EDD does expose checkout hooks if that changes.
		 *
		 * Hooked at priority 20 so anything the receipt template's own callbacks print
		 * lands first, and the widget reads as an addition rather than an interruption.
		 */
		if ( affwp_is_integration_active( 'edd' ) ) {
			/*
			 * One hook covers every way EDD renders a receipt: the confirmation block a
			 * customer lands on after paying, the separate receipt block behind "View Order
			 * Details", and the classic [edd_receipt] shortcode — all three include the same
			 * totals view, which fires this before printing the order table.
			 *
			 * It also lands in the right place. Firing before the totals means the widget
			 * sits between what they bought and the order details, inside the block's own
			 * container, so it inherits the theme's content width. Appending after the whole
			 * block instead put it below "View Order Details" and let it run full-bleed.
			 */
			add_action( 'edd_order_receipt_before_table', [ $this, 'maybe_display_order_confirmation' ], 20 );

			// Above the customer's purchase history — the legacy [purchase_history] shortcode.
			add_action( 'edd_pre_order_history', [ $this, 'maybe_display_account_dashboard' ], 20 );

			/*
			 * The order-history *block*, which is what EDD 3.x actually puts on the page
			 * it creates. Its render callback fires no action at all — edd_pre_order_history
			 * lives only in the legacy shortcode template — so filtering the block's output
			 * is the one seam it offers.
			 */
			add_filter( 'render_block_edd/order-history', [ $this, 'prepend_to_edd_order_history_block' ] );
		}

		/*
		 * MemberPress.
		 *
		 * The same two moments again: the purchase confirmation and the member's own
		 * account page. Both are ordinary WordPress pages configured in MeprOptions
		 * rather than templates with display hooks, so the widget rides their
		 * content instead of hooking a template action.
		 *
		 * Priority 120, because MemberPress builds these pages inside the_content
		 * itself: page_route() renders the account UI at 100 and the ReadyLaunch
		 * thank-you view lands at 99. Running earlier puts the widget into the
		 * content those callbacks replace, and it never reaches the page.
		 */
		if ( affwp_is_integration_active( 'memberpress' ) && class_exists( 'MeprOptions' ) ) {
			add_filter( 'the_content', [ $this, 'maybe_render_on_memberpress_page' ], 120 );
		}
	}

	/**
	 * Render the widget above EDD's order-history block.
	 *
	 * @since 2.35.4
	 *
	 * @param string $block_content The block's rendered output.
	 * @return string
	 */
	public function prepend_to_edd_order_history_block( $block_content ) {

		/*
		 * An empty block means EDD chose to render nothing — a logged-out visitor.
		 * A pitch there would front an empty page for someone who cannot claim
		 * anyway: with no session and no order key there is no purchase to verify.
		 */
		if ( '' === trim( (string) $block_content ) ) {
			return $block_content;
		}

		ob_start();
		$this->maybe_display_widget();

		return ob_get_clean() . $block_content;
	}

	/**
	 * Render the widget on MemberPress's thank-you and account pages.
	 *
	 * @since 2.35.4
	 *
	 * @param string $content The page content.
	 * @return string
	 */
	public function maybe_render_on_memberpress_page( $content ) {

		// MemberPress has no guest checkout, so only a logged-in member can ever claim.
		if ( ! is_user_logged_in() ) {
			return $content;
		}

		/*
		 * The page's own render only, not excerpts, widgets or secondary queries.
		 * ReadyLaunch — MemberPress's default look on new installs — replaces the
		 * whole page template and calls the_content() outside any loop, so
		 * in_the_loop() alone would veto exactly the mode most installs run. Its
		 * layout fires mepr_rl_before_main before rendering, which tells the two
		 * apart from an excerpt built ahead of the template.
		 */
		if ( ! in_the_loop() && ! did_action( 'mepr_rl_before_main' ) ) {
			return $content;
		}

		if ( ! is_main_query() || ! is_page() ) {
			return $content;
		}

		$mepr_options = MeprOptions::fetch();

		$thankyou_page_id = ! empty( $mepr_options->thankyou_page_id ) ? (int) $mepr_options->thankyou_page_id : 0;
		$account_page_id  = ! empty( $mepr_options->account_page_id ) ? (int) $mepr_options->account_page_id : 0;

		$page_id = get_the_ID();

		if ( ! in_array( $page_id, array_filter( [ $thankyou_page_id, $account_page_id ] ), true ) ) {
			return $content;
		}

		/*
		 * Account page: the home tab only, mirroring the WooCommerce placement on the
		 * dashboard tab. MemberPress routes its account tabs through an `action` query
		 * var, and a member reading their payments or changing their password is not in
		 * a moment to be pitched.
		 */
		if ( $page_id === $account_page_id ) {
			$action = isset( $_GET['action'] ) ? sanitize_key( wp_unslash( $_GET['action'] ) ) : 'home'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only routing check.

			if ( 'home' !== $action ) {
				return $content;
			}
		}

		ob_start();
		$this->maybe_display_widget();
		$widget = ob_get_clean();

		/*
		 * Position follows the template. The classic account home is a long profile
		 * form — appended there, the invite sits below the fold where nobody scrolls,
		 * so it leads instead (the EDD history surface makes the same call).
		 * ReadyLaunch's account is a compact profile card that keeps a trailing widget
		 * on screen, so it stays after the member's own content there. The thank-you
		 * page is a short receipt either way, and receipt-then-invite is the order
		 * every other store's confirmation uses.
		 */
		if ( $page_id === $account_page_id && ! did_action( 'mepr_rl_before_main' ) ) {
			return $widget . $content;
		}

		return $content . $widget;
	}

	/**
	 * Display the widget on the WooCommerce purchase confirmation page.
	 *
	 * @param int $order_id Order ID.
	 *
	 * @since 2.18.0
	 */
	public function maybe_display_order_confirmation( $order_id ) {
		$this->maybe_display_widget();
	}

	/**
	 * Hooks onto the woocommerce_after_order_details action to maybe display the widget.
	 *
	 * @param WC_Order $order The WooCommerce order object.
	 *
	 * @since 2.18.0
	 */
	public function maybe_display_order_details( $order ) {
		// Check if on the My Account page's Order details pages.
		if ( is_account_page() && is_wc_endpoint_url( 'view-order' ) ) {
			$this->maybe_display_widget();
		}
	}

	/**
	 * Display the widget on the WooCommerce My Account Dashboard tab.
	 *
	 * @since 2.18.0
	 */
	public function maybe_display_account_dashboard() {
		return $this->maybe_display_widget();
	}


	/**
	 * Calculate how many hours since the affiliate registered.
	 *
	 * @since 2.18.0
	 */
	private function hours_since_registration() {
		$date_registered = affwp_get_affiliate_date_registered( affwp_get_affiliate_id() );

		$now                      = new DateTime();
		$registration_date        = new DateTime( $date_registered );
		$interval                 = $now->diff( $registration_date );
		$hours_since_registration = $interval->h + ( $interval->days * 24 );

		return $hours_since_registration;
	}

	/**
	 * Maybe show the widget.
	 *
	 * @since 2.18.0
	 */
	public function maybe_display_widget() {

		if ( 'affiliate_signup_widget' !== affiliate_wp()->settings->get( 'additional_registration_modes' ) ) {
			return;
		}

		if ( is_user_logged_in() && affwp_is_affiliate() ) {

			// Prevent widget from showing for any other registration method.
			if ( 'affiliate_signup_widget' !== affwp_get_affiliate_meta( affwp_get_affiliate()->affiliate_id, 'registration_method', true ) ) {
				return;
			}

			/**
			 * If an affiliate has been registered for less than 24 hours, keep
			 * showing the widget. The confirmation view will be shown.
			 */
			if ( $this->hours_since_registration() < 24 ) {
				return $this->display();
			}

			// Otherwise, don't show it.
			return;
		}

		// The pitch is "you bought, now earn" — so it needs a purchase behind it.
		if ( is_user_logged_in() && ! $this->has_completed_purchase( get_current_user_id() ) ) {
			return;
		}

		// If all conditions pass, display the widget.
		return $this->display();
	}

	/**
	 * The status a widget claim should be created with.
	 *
	 * require_approval is a *program policy* — a merchant screening who joins. Enabling this
	 * widget is a *display* decision. Overriding the former because of the latter would
	 * change established behaviour behind an existing install's back, so an install that
	 * screens keeps screening until it says otherwise.
	 *
	 * What makes auto-approval defensible when they do opt in: a widget claimant is a paying
	 * customer with a completed order, not a stranger who filled in a form, which is most of
	 * what approval screens for. Left pending they are a *customer* made to wait in a queue
	 * nobody may ever read — roughly 28% of affiliate records across the fleet sit pending.
	 *
	 * @since 2.35.4
	 *
	 * @return string 'active' or 'pending'.
	 */
	public static function claim_status() {

		if ( ! affiliate_wp()->settings->get( 'require_approval' ) ) {
			return 'active';
		}

		// Only an explicit yes overrides the program's own policy.
		return '1' === (string) affiliate_wp()->settings->get( 'affiliate_signup_widget_auto_approve' )
			? 'active'
			: 'pending';
	}

	/**
	 * Whether the approval choice is worth putting to the merchant.
	 *
	 * Only when the program actually screens. With approval off there is nothing to override
	 * and the control would be a setting about nothing.
	 *
	 * @since 2.35.4
	 *
	 * @return bool
	 */
	public static function approval_choice_applies() {
		return (bool) affiliate_wp()->settings->get( 'require_approval' );
	}

	/**
	 * The pending state's copy.
	 *
	 * Customisable like the signup and confirmation copy, because a merchant who screens
	 * deliberately has a reason for it and may want to say so in their own words — "we check
	 * every affiliate's site first" reassures where a generic line does not.
	 *
	 * Not called an application: the customer pressed a button, they did not fill anything in.
	 *
	 * First person, because the signup state one beat earlier says "our affiliate program".
	 * "This program reviews…" is how the plugin describes a store; "we review…" is how the
	 * store speaks to its own customer, and switching between them mid-flow reads as two
	 * different authors. Merchant-facing copy in the settings stays "your program" for the
	 * same reason: that reader is the merchant.
	 *
	 * @since 2.35.4
	 *
	 * @return array Heading and text.
	 */
	public static function pending_copy() {

		$heading = (string) affiliate_wp()->settings->get(
			'affiliate_signup_widget_pending_heading_text',
			__( 'Thanks for signing up', 'affiliate-wp' )
		);

		$text = (string) affiliate_wp()->settings->get(
			'affiliate_signup_widget_pending_text',
			__( 'We review new affiliates before they start earning. You will get your referral link by email once you are approved.', 'affiliate-wp' )
		);

		return [
			'heading' => '' !== $heading ? $heading : __( 'Thanks for signing up', 'affiliate-wp' ),
			'text'    => '' !== $text ? $text : __( 'We review new affiliates before they start earning. You will get your referral link by email once you are approved.', 'affiliate-wp' ),
		];
	}

	/**
	 * Record that the customer accepted the program's terms.
	 *
	 * The widget shows the disclosure — the "By joining you agree to…" line renders whenever a
	 * terms page is configured — but stored nothing, so the same program had an audit trail for
	 * registration-form signups and none for widget signups. `tos_acceptance_date` is the key
	 * the registration form already writes, reused deliberately so one query answers both.
	 *
	 * The revision is recorded alongside it because the date alone does not establish what they
	 * agreed to: a merchant can edit that page afterwards, and proving assent means naming the
	 * text as it stood. The surface needs no key of its own — the affiliate already carries
	 * `registration_method`.
	 *
	 * Nothing is written when no terms page is configured, because nothing was shown.
	 *
	 * @since 2.35.4
	 *
	 * @param int $affiliate_id Affiliate that just claimed.
	 */
	private function record_terms_acceptance( $affiliate_id ) {

		$page_id = (int) affiliate_wp()->settings->get( 'terms_of_use', 0 );

		if ( empty( $affiliate_id ) || empty( $page_id ) ) {
			return;
		}

		/*
		 * A UTC timestamp, the same value the registration form's
		 * strtotime( gmdate( 'Y-m-d H:i:s' ) ) produces: WordPress sets PHP's default timezone
		 * to UTC, so that round trip formats UTC and reads it back as UTC. It looks like a
		 * timezone bug and is not one. Written plainly here so nobody has to re-derive that.
		 */
		affwp_update_affiliate_meta( $affiliate_id, 'tos_acceptance_date', time() );

		affwp_update_affiliate_meta(
			$affiliate_id,
			'tos_acceptance_revision',
			[
				'page_id'  => $page_id,
				'modified' => get_post_field( 'post_modified_gmt', $page_id ),
			]
		);
	}

	/**
	 * EDD order statuses that mean the customer paid, and kept what they bought.
	 *
	 * EDD has no equivalent of WooCommerce's wc_get_is_paid_statuses(); its own status sets
	 * are built for revenue reporting and none of them answers this question. Asking for
	 * "complete" statuses would accept `refunded` and `revoked`, and the "net" set would
	 * accept `on_hold`, which has not been paid at all.
	 *
	 * partially_refunded counts: they paid, and part of the purchase stands.
	 *
	 * @since 2.35.4
	 *
	 * @return string[]
	 */
	public static function paid_edd_statuses() {

		/**
		 * Filters the EDD order statuses that qualify a customer for the signup widget.
		 *
		 * @since 2.35.4
		 *
		 * @param string[] $statuses Order statuses.
		 */
		return (array) apply_filters(
			'affwp_signup_widget_paid_edd_statuses',
			[ 'complete', 'partially_refunded' ]
		);
	}

	/**
	 * MemberPress transaction statuses that mean the member paid.
	 *
	 * 'confirmed' counts alongside 'complete' because AffiliateWP's own MemberPress
	 * integration treats both as commissionable — it marks referrals complete on the
	 * mepr-txn-status-complete and mepr-txn-status-confirmed hooks alike.
	 *
	 * @since 2.35.4
	 *
	 * @return string[]
	 */
	public static function paid_memberpress_statuses() {

		/**
		 * Filters the MemberPress transaction statuses that qualify a customer for the signup widget.
		 *
		 * @since 2.35.4
		 *
		 * @param string[] $statuses Transaction statuses.
		 */
		return (array) apply_filters(
			'affwp_signup_widget_paid_memberpress_statuses',
			[ 'complete', 'confirmed' ]
		);
	}

	/**
	 * Whether a customer has completed at least one purchase.
	 *
	 * Asked of every store the widget supports, not just WooCommerce. Before this the
	 * check was `function_exists( 'wc_get_orders' )`, which on a store without
	 * WooCommerce silently passed — so the gate the widget's whole premise depends on
	 * was not applied at all.
	 *
	 * Returns true when no supported store can answer, which keeps the previous
	 * behaviour for anything unrecognised rather than hiding the widget outright.
	 *
	 * @since 2.35.4
	 *
	 * @param int $user_id User to check.
	 * @return bool
	 */
	private function has_completed_purchase( $user_id ) {

		$asked = false;

		if ( function_exists( 'wc_get_orders' ) ) {
			$asked = true;

			$orders = wc_get_orders(
				[
					'customer' => $user_id,
					'status'   => wc_get_is_paid_statuses(),
					'return'   => 'ids',
					// One is enough; this only answers whether any exist.
					'limit'    => 1,
				]
			);

			if ( ! empty( $orders ) ) {
				return true;
			}
		}

		// EDD 3.x.
		if ( function_exists( 'edd_count_orders' ) ) {
			$asked = true;

			$count = edd_count_orders(
				[
					'user_id'    => $user_id,
					'status__in' => self::paid_edd_statuses(),
				]
			);

			if ( $count > 0 ) {
				return true;
			}
		}

		// MemberPress. Members always have accounts — there is no guest checkout.
		if ( class_exists( 'MeprDb' ) ) {
			$asked = true;

			global $wpdb;

			/*
			 * Straight SQL on MemberPress's own table, because MeprTransaction's static
			 * helpers vary by version and none answers "any paid transaction for this
			 * user". The table name comes from MeprDb so a custom prefix still resolves.
			 */
			$statuses     = self::paid_memberpress_statuses();
			$placeholders = implode( ',', array_fill( 0, count( $statuses ), '%s' ) );

			$txn_id = $wpdb->get_var(
				$wpdb->prepare(
					'SELECT id FROM ' . esc_sql( MeprDb::fetch()->transactions ) . " WHERE user_id = %d AND status IN ({$placeholders}) LIMIT 1", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name from MeprDb, statuses are placeholders.
					array_merge( [ $user_id ], $statuses )
				)
			);

			if ( ! empty( $txn_id ) ) {
				return true;
			}
		}

		return ! $asked;
	}

	/**
	 * Generate the shades.
	 *
	 * @since 2.18.0
	 *
	 * @param string $brand_color The brand color.
	 */
	public function generate_shades( $brand_color ) {
		// Calculate luminance.
		list( $r, $g, $b ) = sscanf( $brand_color, '#%02x%02x%02x' );
		$luminance         = ( 0.2126 * $r + 0.7152 * $g + 0.0722 * $b ) / 255;

		// Determine whether the color is dark or light.
		$isDark = $luminance < 0.5;

		// Generate shades based on whether the color is dark or light.
		$shades = $isDark ? $this->generate_dark_shades( $brand_color ) : $this->generate_light_shades( $brand_color );

		$cssVariables = '';
		foreach ( $shades as $key => $value ) {
			$cssVariables .= "--brand-{$key}: {$value}; ";
		}

		return $cssVariables;
	}

	/**
	 * Generate dark shades.
	 *
	 * @since 2.18.0
	 *
	 * @param string $color The brand color.
	 */
	private function generate_dark_shades( $color ) {
		return [
			'100' => "color-mix(in srgb, $color 15%, white 85%)",
			'105' => "color-mix(in srgb, $color 15%, white 85%)",
			'110' => "color-mix(in srgb, $color 60%, white 40%)",
			'115' => "color-mix(in srgb, $color 70%, white 30%)",
			'120' => "color-mix(in srgb, $color 10%, white 90%)",
			'125' => "color-mix(in srgb, $color 10%, white 90%)",
			'130' => "color-mix(in srgb, $color 10%, white 90%)",
			'200' => "color-mix(in srgb, $color 15%, white 85%)",
			'205' => "color-mix(in srgb, $color 15%, white 85%)",
			'210' => "color-mix(in srgb, $color 10%, white 90%)",
			'215' => "color-mix(in srgb, $color 10%, white 90%)",
			'220' => "color-mix(in srgb, $color 30%, black 70%)",
			'225' => "color-mix(in srgb, $color 10%, white 90%)",
			'230' => "color-mix(in srgb, $color 70%, black 30%)",
			'235' => "color-mix(in srgb, $color 90%, black 10%)",
			'240' => "color-mix(in srgb, $color 10%, white 90%)",
			'300' => "color-mix(in srgb, $color 10%, white 90%)",
			'305' => "color-mix(in srgb, $color 10%, white 90%)",
			'500' => $color,
		];
	}

	/**
	 * Generate light shades.
	 *
	 * @since 2.18.0
	 *
	 * @param string $color The brand color.
	 */
	private function generate_light_shades( $color ) {
		return [
			'100' => "color-mix(in srgb, $color 30%, black 70%)",
			'105' => "color-mix(in srgb, $color 30%, black 70%)",
			'110' => "color-mix(in srgb, $color 30%, black 70%)",
			'115' => "color-mix(in srgb, $color 30%, black 70%)",
			'120' => "color-mix(in srgb, $color 10%, white 90%)",
			'125' => "color-mix(in srgb, $color 30%, black 70%)",
			'130' => "color-mix(in srgb, $color 30%, black 70%)",
			'200' => "color-mix(in srgb, $color 30%, black 70%)",
			'205' => "color-mix(in srgb, $color 30%, black 70%)",
			'210' => "color-mix(in srgb, $color 10%, white 90%)",
			'215' => "color-mix(in srgb, $color 10%, white 90%)",
			'216' => "color-mix(in srgb, $color 80%, black 20%)",
			'220' => "color-mix(in srgb, $color 30%, black 70%)",
			'225' => "color-mix(in srgb, $color 10%, white 90%)",
			'230' => "color-mix(in srgb, $color 20%, black 80%)",
			'235' => "color-mix(in srgb, $color 30%, black 70%)",
			'240' => "color-mix(in srgb, $color 10%, white 90%)",
			'300' => "color-mix(in srgb, $color 30%, black 70%)",
			'305' => "color-mix(in srgb, $color 30%, black 70%)",
			'500' => $color,
		];
	}

	/**
	 * Get host styles.
	 *
	 * @since 2.18.0
	 *
	 * @return string
	 */
	public function get_host_styles() {
		$brand_color = affiliate_wp()->settings->get( 'affiliate_signup_widget_brand_color', '#4b64e2' );

		// Get the CSS variables string for the brand color
		$css_variables = $this->generate_shades( $brand_color );

		// Build the output string
		$output  = '<style id="brand-colors">:host {';
		$output .= $css_variables;
		$output .= '}</style>';

		return $output;
	}

	/**
	 * Get the data for the widget.
	 *
	 * @since 2.18.0
	 *
	 * @return array
	 */
	public function data() {
		$image                = affiliate_wp()->settings->get( 'affiliate_signup_widget_image', '' );
		$heading              = affiliate_wp()->settings->get( 'affiliate_signup_widget_heading_text', __( 'Earn with every referral!', 'affiliate-wp' ) );
		$text                 = affiliate_wp()->settings->get( 'affiliate_signup_widget_text', __( 'Join our affiliate program and earn commission on every sale you refer', 'affiliate-wp' ) );
		$button_text          = affiliate_wp()->settings->get( 'affiliate_signup_widget_button_text', __( 'Start Earning Today', 'affiliate-wp' ) );
		$button_text_loading  = __( 'Signing up...', 'affiliate-wp' );
		$button_color         = affiliate_wp()->settings->get( 'affiliate_signup_widget_button_color', '#ffffff' );
		$button_copy_text     = __( 'Copy', 'affiliate-wp' );
		$button_copied_text   = __( 'Link Copied!', 'affiliate-wp' );
		$button_id            = is_admin() ? 'signup-affiliate-preview' : 'signup-affiliate';
		$confirmation_heading = affiliate_wp()->settings->get( 'affiliate_signup_widget_confirmation_heading_text', 'Congrats, you\'re in! Start earning now' );
		$confirmation_text    = affiliate_wp()->settings->get( 'affiliate_signup_widget_confirmation_text', __( 'Share your affiliate link below with friends. When they buy, you earn!', 'affiliate-wp' ) );
		$terms_of_use_page_id = affiliate_wp()->settings->get( 'terms_of_use', '' );
		$error_heading        = __( 'Oops! We\'re Sorry', 'affiliate-wp' );
		$error_text           = __( 'There was a problem registering your affiliate account. Please try again later or contact our team.', 'affiliate-wp' );

		$affiliate = is_user_logged_in() && affwp_is_affiliate();

		// Withholding depends on status, not merely on being an affiliate.
		$pending = $affiliate && 'pending' === affwp_get_affiliate_status( affwp_get_affiliate_id() );

		return [
			'image'                => $image,
			'heading'              => $heading,
			'text'                 => nl2br( $text ),
			'button_text'          => $button_text,
			'button_text_loading'  => $button_text_loading,
			'button_color'         => $button_color,
			'button_id'            => $button_id,
			'terms_of_use_page_id' => $terms_of_use_page_id,
			'confirmation_heading' => $confirmation_heading,
			'confirmation_text'    => nl2br( $confirmation_text ),
			'button_copy_text'     => $button_copy_text,
			'button_copied_text'   => $button_copied_text,
			/*
			 * A pending affiliate gets the pending state, not the confirmation.
			 *
			 * The AJAX response already withholds the link on claim, but this is the *render*
			 * path — reloading the page rebuilt the confirmation view server-side, congrats
			 * heading and link included, because the template had no pending branch. Same lie,
			 * one refresh later. A pending affiliate's link records no visits, so it is
			 * withheld here too.
			 */
			'affiliate_link'       => $affiliate && ! $pending ? $this->get_affiliate_link( affwp_get_affiliate_id() ) : '{affiliateLink}',
			/*
			 * An explicit flag, because the template used to infer this from affiliate_link
			 * still holding its placeholder. Withholding a pending affiliate's link set that
			 * placeholder back, which the template read as "not an affiliate yet" — so it
			 * rendered the signup pitch and the pending notice together. One value cannot be
			 * both the link and the answer to whether they have joined.
			 */
			'display_signup'       => ! $affiliate,
			'display_confirmation' => $affiliate && ! $pending && $this->hours_since_registration() < 24,
			'display_pending'      => $affiliate && $pending && $this->hours_since_registration() < 24,
			'pending_heading'      => self::pending_copy()['heading'],
			'pending_text'         => self::pending_copy()['text'],
			'error_text'           => $error_text,
			'error_heading'        => $error_heading,
		];
	}

	/**
	 * Enqueue scripts within admin.
	 *
	 * @since 2.18.0
	 */
	public function enqueue_admin_scripts() {

		// Determine if user is on the Settings -> Affiliates page.
		$is_settings_affiliates_page = isset( $_GET['page'] ) && 'affiliate-wp-settings' === sanitize_text_field( $_GET['page'] ) && isset( $_GET['tab'] ) && 'affiliates' === sanitize_text_field( $_GET['tab'] );

		if ( ! $is_settings_affiliates_page ) {
			return;
		}

		/*
		 * Only when an enabled integration supports the widget — the same registry
		 * question the settings screen asks before showing the section. Gating on
		 * WooCommerce alone left an EDD or MemberPress store with the section visible
		 * and a preview pane that never loads its script: an empty box.
		 */
		$supported = affiliate_wp()->integrations->query(
			[
				'supports' => 'affiliate_signup_widget',
				'status'   => 'enabled',
				'fields'   => [ 'ids', 'name' ],
			]
		);

		if ( is_wp_error( $supported ) || empty( $supported ) ) {
			return;
		}

		$suffix = ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ? '' : '.min';

		wp_enqueue_script( 'affiliate-signup-widget-admin', AFFILIATEWP_PLUGIN_URL . 'assets/js/admin-affiliate-signup-widget' . $suffix . '.js', [], AFFILIATEWP_VERSION, true );

		$admin_script_data = [
			'affiliateLinkPreview' => $this->affiliate_link_preview(),
		];

		$data = array_merge( $admin_script_data, $this->get_script_data() );

		wp_localize_script( 'affiliate-signup-widget-admin', 'affiliateWidgetParams', $data );
	}

	/**
	 * Determine if scripts should be enqueued.
	 *
	 * @since 2.18.0
	 */
	private function should_enqueue_scripts() {
		$enqueue = false;

		// Check for WooCommerce pages.
		if (
			class_exists( 'WooCommerce' ) &&
			(
				is_order_received_page() || // Purchase confirmation page.
				( is_account_page() && ! is_wc_endpoint_url() ) || // Dashboard tab only.
				( is_account_page() && is_wc_endpoint_url( 'view-order' ) ) // Order details page only.
			)
		) {
			$enqueue = true;
		}

		/*
		 * Easy Digital Downloads: the purchase confirmation and the purchase history page.
		 *
		 * Named here as well as loading on render, because render-time enqueuing depends on
		 * the widget printing before wp_footer — true today, but it is the kind of ordering
		 * that breaks quietly and leaves an element on the page with nothing to initialise
		 * it. Asking at wp_enqueue_scripts is the reliable path; the render-time call is the
		 * safety net for surfaces not named here.
		 */
		if ( function_exists( 'edd_is_success_page' ) ) {

			$history_page = (int) edd_get_option( 'purchase_history_page', 0 );

			if ( edd_is_success_page() || ( $history_page && is_page( $history_page ) ) ) {
				$enqueue = true;
			}
		}

		// MemberPress: the thank-you page and the member's account page.
		if ( class_exists( 'MeprOptions' ) ) {

			$mepr_options = MeprOptions::fetch();

			if (
				( ! empty( $mepr_options->thankyou_page_id ) && is_page( (int) $mepr_options->thankyou_page_id ) ) ||
				( ! empty( $mepr_options->account_page_id ) && is_page( (int) $mepr_options->account_page_id ) )
			) {
				$enqueue = true;
			}
		}

		return $enqueue;
	}

	/**
	 * Enqueue scripts
	 *
	 * @since 2.18.0
	 */
	public function enqueue_frontend_scripts() {

		if ( ! $this->should_enqueue_scripts() ) {
			return;
		}

		$this->enqueue_widget_assets();
	}

	/**
	 * Load the widget's script, once, wherever it is needed.
	 *
	 * Called on render as well as from wp_enqueue_scripts, because should_enqueue_scripts()
	 * enumerates WooCommerce pages and therefore answers "no" everywhere else. Adding the
	 * EDD hooks without this printed the element onto an EDD receipt with nothing to
	 * initialise it — a custom element that upgrades into an empty box.
	 *
	 * Enqueuing at render is safe here: the script is registered for the footer, and every
	 * surface the widget renders on does so well before wp_footer.
	 *
	 * @since 2.35.4
	 */
	private function enqueue_widget_assets() {

		// wp_enqueue_script is idempotent; wp_localize_script is not, so guard the pair.
		if ( wp_script_is( 'affiliate-signup-widget', 'enqueued' ) ) {
			return;
		}

		$suffix = ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ? '' : '.min';

		wp_enqueue_script( 'affiliate-signup-widget', AFFILIATEWP_PLUGIN_URL . 'assets/js/affiliate-signup-widget' . $suffix . '.js', [], AFFILIATEWP_VERSION, true );

		wp_localize_script( 'affiliate-signup-widget', 'affiliateWidgetParams', $this->get_script_data() );
	}

	/**
	 * Prepares the script data for use in various places.
	 *
	 * @since 2.18.0
	 */
	protected function get_script_data() {
		$suffix = ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ? '' : '.min';
		$data   = $this->data();
		extract( $data );
		ob_start();

		echo $this->get_host_styles();
		include AFFILIATEWP_PLUGIN_DIR . 'includes/affiliate-signup-widget/template/index.php';
		$widget_html = ob_get_clean();

		return [
			'cssUrl'     => AFFILIATEWP_PLUGIN_URL . 'assets/css/affiliate-signup-widget' . $suffix . '.css',
			'ajaxUrl'    => admin_url( 'admin-ajax.php' ),
			'nonce'      => wp_create_nonce( 'affwp_affiliate_signup' ),
			'widgetHtml' => $widget_html,
			'data'       => $data,
		];
	}

	/**
	 * Admin link preview.
	 *
	 * @since 2.18.0
	 * @todo The demo link should check pretty referral URLs so it's more accurate.
	 */
	public function affiliate_link_preview() {

		if ( affwp_is_affiliate() ) {
			$link = esc_url( urldecode( affwp_get_affiliate_referral_url( [ 'affiliate_id' => affwp_is_affiliate() ] ) ) );
		} else {
			// Create a demo link
			$link = esc_url( add_query_arg( affiliate_wp()->tracking->get_referral_var(), '123', home_url( '/' ) ) );
		}

		return $link;
	}

	/**
	 * Display the Affiliate Signup Widget.
	 *
	 * @since 2.18.0
	 */
	public function display( $order_id = '' ) {

		// Whatever surface called this, make sure the script that renders it is present.
		if ( ! is_admin() ) {
			$this->enqueue_widget_assets();
		}

		if ( is_admin() ) : ?>
		<div class="affwp-toggle">
			<label class="affwp-toggle__switch">
				<span class="affwp-toggle__label-text">
					<?php _e( 'Preview Affiliate Signup Confirmation', 'affiliate-wp' ); ?>
				</span>
				<input type="checkbox" id="viewToggle" class="affwp-toggle__input">
				<span class="affwp-toggle__slider affwp-toggle__slider--round"></span>
			</label>
		</div>
		<?php endif; ?>

		<div class="<?php echo esc_attr( $this->widget_container_class ); ?>"></div>
		<?php
	}

	/**
	 * Resolve the customer behind a guest purchase.
	 *
	 * A logged-out customer can only be signed up if we can prove which order they just
	 * placed and read the email from it — inventing an account from a posted address would
	 * let anyone create one. The order key is that proof.
	 *
	 * This was WooCommerce-only, and the key was read from `?key=` in the URL, which is a
	 * WooCommerce URL shape. On EDD the parameter is absent and the lookup functions do not
	 * exist, so a guest could never be resolved and every signup failed with "There was a
	 * problem registering your affiliate account".
	 *
	 * EDD is asked two ways: the key if one was posted, otherwise the purchase session,
	 * which is what its confirmation page relies on and needs no key in the URL at all.
	 *
	 * @since 2.35.4
	 *
	 * @param string $order_key Order key posted with the request, if any.
	 * @return array {
	 *     @type string $email      Guest email, empty when unresolved.
	 *     @type string $first_name Guest first name, may be empty.
	 *     @type string $last_name  Guest last name, may be empty.
	 * }
	 */
	private function guest_purchaser( $order_key ) {

		$none = [
			'email'      => '',
			'first_name' => '',
			'last_name'  => '',
		];

		// WooCommerce.
		if ( $order_key && function_exists( 'wc_get_order' ) ) {
			$order = wc_get_order( $this->get_order_id_by_order_key( $order_key ) );

			/*
			 * A guest order has no user attached to it, and must have been paid: the logged-in
			 * path applies that test through has_completed_purchase(), so without it here a
			 * guest holding the key to a failed or unpaid order could claim on the strength of
			 * an order that was never paid for.
			 */
			if ( $order && ! $order->get_user_id() && $order->is_paid() ) {
				return [
					'email'      => $order->get_billing_email(),
					'first_name' => $order->get_billing_first_name(),
					'last_name'  => $order->get_billing_last_name(),
				];
			}
		}

		// Easy Digital Downloads.
		if ( function_exists( 'edd_get_order_by' ) ) {

			$key = $order_key;

			if ( ! $key && function_exists( 'edd_get_purchase_session' ) ) {
				$session = edd_get_purchase_session();
				$key     = ! empty( $session['purchase_key'] ) ? $session['purchase_key'] : '';
			}

			if ( $key ) {
				$order = edd_get_order_by( 'payment_key', $key );

				// Paid, for the same reason as WooCommerce above. EDD's own is_complete()
				// would accept a refunded or revoked order, so test the paid set directly.
				if ( $order && empty( $order->user_id ) && in_array( $order->status, self::paid_edd_statuses(), true ) ) {

					// Names live on the order's address, and are not always collected.
					$address = method_exists( $order, 'get_address' ) ? $order->get_address() : null;

					return [
						'email'      => (string) $order->email,
						'first_name' => $address && ! empty( $address->first_name ) ? (string) $address->first_name : '',
						'last_name'  => $address && ! empty( $address->last_name ) ? (string) $address->last_name : '',
					];
				}
			}
		}

		return $none;
	}

	/**
	 * Get the order ID from the order key.
	 *
	 * @since 2.18.0
	 */
	private function get_order_id_by_order_key( $order_key ) {
		// Get an instance of the WC_Order_Data_Store
		$order_data_store = WC_Data_Store::load( 'order' );

		// Use the data store to get the order ID from the order key
		$order_id = $order_data_store->get_order_id_by_order_key( $order_key );

		return $order_id;
	}

	/**
	 * Get an affiliate's link.
	 *
	 * @since 2.18.0
	 */
	private function get_affiliate_link( $affiliate_id ) {
		return esc_url( urldecode( affwp_get_affiliate_referral_url( [ 'affiliate_id' => $affiliate_id ] ) ) );
	}

	/**
	 * Affiliate Signup.
	 *
	 * @since 2.18.0
	 */
	public function affiliate_signup() {

		// Bail if the signup widget registration mode is not the active one.
		if ( 'affiliate_signup_widget' !== affiliate_wp()->settings->get( 'additional_registration_modes' ) ) {
			wp_send_json_error( [ 'message' => __( 'Affiliate signup widget is not enabled.', 'affiliate-wp' ) ] );
		}

		// Verify the request nonce (works for both logged-in users and guests).
		if ( ! check_ajax_referer( 'affwp_affiliate_signup', 'nonce', false ) ) {
			wp_send_json_error( [ 'message' => __( 'Security check failed.', 'affiliate-wp' ) ] );
		}

		/*
		 * Already an affiliate: report their real state instead of registering again.
		 *
		 * Registering again would re-fire affwp_register_user — re-sending the
		 * registration emails — and re-enable referral notifications over the
		 * affiliate's own opt-out. The response mirrors what the render path shows
		 * them, so a replayed request changes nothing.
		 */
		if ( is_user_logged_in() && affwp_is_affiliate() ) {

			$affiliate_id = affwp_get_affiliate_id();
			$affiliate_status = affwp_get_affiliate_status( $affiliate_id );

			if ( 'pending' === $affiliate_status ) {

				$copy = self::pending_copy();

				wp_send_json_success(
					[
						'status'  => 'pending',
						'heading' => $copy['heading'],
						'message' => $copy['text'],
					]
				);
			}

			if ( 'active' === $affiliate_status ) {
				wp_send_json_success(
					[
						'status'         => 'active',
						'affiliate_link' => $this->get_affiliate_link( $affiliate_id ),
					]
				);
			}

			// Rejected or inactive affiliates cannot rejoin through the widget.
			wp_send_json_error( [ 'message' => __( 'Your affiliate account cannot be registered again.', 'affiliate-wp' ) ] );
		}

		/*
		 * The purchase gate, enforced where it counts. The render path already checks
		 * this before showing the widget, but the endpoint is reachable by anyone on a
		 * page carrying the nonce — without this, any logged-in visitor could post
		 * directly and become an affiliate with no purchase behind them.
		 */
		if ( is_user_logged_in() && ! $this->has_completed_purchase( get_current_user_id() ) ) {
			wp_send_json_error( [ 'message' => __( 'A completed purchase is required to join.', 'affiliate-wp' ) ] );
		}

		// Access the post ID from the form data.
		$post_id = isset( $_POST['post_id'] ) ? intval( $_POST['post_id'] ) : 0;

		// Get the order key from the query string.
		$order_key = isset( $_POST['order_key'] ) ? sanitize_text_field( $_POST['order_key'] ) : '';

		/*
		 * "null" and "undefined" are not keys. FormData stringifies whatever it is handed,
		 * so a page with no key in its URL used to post the literal text "null" — truthy
		 * here, and enough to stop the store-specific fallbacks from ever being reached.
		 * The script no longer sends it, but a browser holding the previous copy still will.
		 */
		if ( in_array( strtolower( $order_key ), [ 'null', 'undefined', 'false' ], true ) ) {
			$order_key = '';
		}

		$guest = $this->guest_purchaser( $order_key );

		$guest_email      = $guest['email'];
		$guest_first_name = $guest['first_name'];
		$guest_last_name  = $guest['last_name'];

		// Guest purchases.
		if ( ! is_user_logged_in() ) {

			// Never create + auto-login an account without a verified guest order email.
			if ( empty( $guest_email ) || ! is_email( $guest_email ) ) {
				wp_send_json_error( [ 'message' => __( 'A valid order is required to sign up.', 'affiliate-wp' ) ] );
			}

			$new_user = true;

			$user_email = $guest_email;
			$user_login = $user_email;
			$user_pass  = wp_generate_password( 24 );

			$user_first = $guest_first_name;
			$user_last  = $guest_last_name;

			$random_pass = true;

			$args = [
				'user_login'   => $user_email,
				'user_email'   => $user_email,
				'user_pass'    => $user_pass,
				'first_name'   => $user_first,
				'last_name'    => $user_last,
				'display_name' => trim( $user_first . ' ' . $user_last ),
			];

			$user_id = wp_insert_user( $args );

			if ( is_wp_error( $user_id ) ) {
				wp_send_json_error( [ 'message' => __( 'Could not create the affiliate account.', 'affiliate-wp' ) ] );
			}

			if ( $random_pass ) {
				// Remember that we generated the password for the user.
				update_user_meta( $user_id, 'affwp_generated_pass', true );
			}
		} else {
			// Logged in users.
			$new_user = false;
			$user_id  = get_current_user_id();
			$user     = (array) get_userdata( $user_id );

			if ( isset( $user['data'] ) ) {
				$args = (array) $user['data'];
			} else {
				$args = [];
			}
		}

		$status = self::claim_status();

		$added = affwp_add_affiliate(
			[
				'user_id'             => $user_id,
				'status'              => $status,
				/*
				 * Only when a dynamic coupon can actually be minted: a capable integration
				 * enabled and a coupon template chosen. Passing 1 unconditionally made
				 * Coupons_DB::add() bail and log "Coupon could not be added" on every claim
				 * from a store without a template — which is every EDD and MemberPress
				 * store, since only WooCommerce supports dynamic coupons.
				 */
				'dynamic_coupon'      => affwp_dynamic_coupons_is_setup() ? 1 : 0,
				'registration_method' => 'affiliate_signup_widget',
				'registration_url'    => esc_url_raw( get_permalink( $post_id ) ),
			]
		);

		/*
		 * Surface the failure instead of carrying on. The code below used to run
		 * regardless: it logged the visitor in, fired affwp_register_user, and sent a
		 * success response for an affiliate that was never created.
		 */
		if ( empty( $added ) ) {
			wp_send_json_error( [ 'message' => __( 'Could not create the affiliate account.', 'affiliate-wp' ) ] );
		}

		if ( ! is_user_logged_in() ) {
			$this->log_user_in( $user_id, $user_login );
		}

		// Retrieve affiliate ID. Resolves issues with caching on some hosts, such as GoDaddy
		$affiliate_id = affwp_get_affiliate_id( $user_id );

		if ( true === $new_user ) {
			// Enable referral notifications by default for new users.
			affwp_update_affiliate_meta( $affiliate_id, 'referral_notifications', true );
		}

		// Before the pending branch below returns: a pending affiliate accepted the terms too.
		$this->record_terms_acceptance( $affiliate_id );

		/**
		 * Fires immediately after registering a user.
		 *
		 * @since 2.18.0
		 *
		 * @param int    $affiliate_id Affiliate ID.
		 * @param string $status       Affiliate status.
		 * @param array  $args         Data arguments used when registering the user.
		 */
		do_action( 'affwp_register_user', $affiliate_id, $status, $args );

		/*
		 * A pending affiliate gets told they are pending, and gets no link.
		 *
		 * Affiliate_WP_Tracking::is_valid_affiliate() requires 'active', so a pending
		 * affiliate's link records no visit and creates no referral. Handing one over under
		 * a success heading meant a customer could share it, send real traffic, and have
		 * every click and sale silently discarded — including sales the merchant would have
		 * paid for. Withholding it is the honest answer; the link appears once approved.
		 */
		if ( 'pending' === $status ) {

			$copy = self::pending_copy();

			wp_send_json_success(
				[
					'status'  => 'pending',
					'heading' => $copy['heading'],
					'message' => $copy['text'],
				]
			);
		}

		$affiliate_link = $this->get_affiliate_link( $affiliate_id );

		wp_send_json_success(
			[
				'status'         => 'active',
				'affiliate_link' => $affiliate_link,
			]
		);
	}

	/**
	 * Logs the user in.
	 * Duplicate of log_user_in() from class-register.php.
	 *
	 * @since 2.18.0
	 * @todo Move to separate class so we can re-use it
	 *
	 * @param  $user_id    The user ID.
	 * @param  $user_login The `user_login` for the user.
	 * @param  $remember   Whether or not the browser should remember the user login.
	 */
	private function log_user_in( $user_id = 0, $user_login = '', $remember = false ) {

		$user = get_userdata( $user_id );
		if ( ! $user ) {
			return;
		}

		wp_set_auth_cookie( $user_id, $remember );
		wp_set_current_user( $user_id, $user_login );

		/**
		 * The `wp_login` action is fired here to maintain compatibility and stability of
		 * any WordPress core features, plugins, or themes hooking onto it.
		 *
		 * @param  string   $user_login The `user_login` for the user.
		 * @param  stdClass $user       The user object.
		 */
		do_action( 'wp_login', $user_login, $user );
	}
}
new Affiliate_Signup_Widget();
