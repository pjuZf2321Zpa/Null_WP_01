<?php
/**
 * Admin: Referrals Overview
 *
 * @package     AffiliateWP
 * @subpackage  Admin/Referrals
 * @copyright   Copyright (c) 2014, Sandhills Development, LLC
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       1.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

include AFFILIATEWP_PLUGIN_DIR . 'includes/admin/referrals/screen-options.php';
include AFFILIATEWP_PLUGIN_DIR . 'includes/admin/referrals/contextual-help.php';
require_once AFFILIATEWP_PLUGIN_DIR . 'includes/admin/referrals/class-list-table.php';

/**
 * Loads the Referrals admin screen.
 *
 * @since 1.0
 */
function affwp_referrals_admin() {

	$action = isset( $_REQUEST['action'] ) ? sanitize_text_field( $_REQUEST['action'] ) : null;

	$referral_id = isset( $_REQUEST['referral_id'] ) ? absint( $_REQUEST['referral_id'] ) : 0;
	$referral    = affwp_get_referral( $referral_id );

	if ( 'edit_referral' === $action && $referral ) {

		include AFFILIATEWP_PLUGIN_DIR . 'includes/admin/referrals/edit.php';

	} elseif ( 'add_referral' === $action ) {

		include AFFILIATEWP_PLUGIN_DIR . 'includes/admin/referrals/new.php';

	} else {

		/*
		 * The referral drawer mirrors the open referral into the URL as
		 * ?referral_id=X (for deep-linking / refresh-persistence). WP_List_Table
		 * builds its pagination and sortable-column links from $_SERVER['REQUEST_URI'],
		 * so without this that param leaks into every page/sort link — paging then
		 * re-opens the same referral on each navigation. Strip it from the request
		 * URI before the table renders; the drawer reads referral_id client-side
		 * from the address bar, so deep-linking is unaffected.
		 */
		if ( isset( $_GET['referral_id'] ) && ! empty( $_SERVER['REQUEST_URI'] ) ) {
			$_SERVER['REQUEST_URI'] = remove_query_arg( 'referral_id', $_SERVER['REQUEST_URI'] );
		}

		$referrals_table = new AffWP_Referrals_Table();
		$referrals_table->prepare_items();
		?>
		<div class="wrap">
			<h1>
				<?php _e( 'Referrals', 'affiliate-wp' ); ?>
				<a href="<?php echo esc_url( add_query_arg( 'action', 'add_referral' ) ); ?>" class="button action button-small"><?php _e( 'Add New', 'affiliate-wp' ); ?></a>
				<?php

				/**
				 * Add actions to the Referrals screen.
				 *
				 * @since 2.14.0
				 */
				do_action( 'affwp_referral_admin_page_actions' );

				?>
				<?php if ( current_user_can( 'view_affiliate_reports' ) ) : ?>
					<a href="<?php echo esc_url( add_query_arg( array( 'page' => 'affiliate-wp-reports', 'tab' => 'referrals' ) ) ); ?>" class="button action button-small"><?php _ex( 'Reports', 'referrals', 'affiliate-wp' ); ?></a>
				<?php endif; ?>
				<?php if ( current_user_can( 'manage_payouts' ) ) : ?>
					<a href="<?php echo esc_url( affwp_admin_url( 'payouts', array( 'action' => 'new_payout' ) ) ); ?>" class="button action button-primary button-small"><?php _e( 'Pay Affiliates', 'affiliate-wp' ); ?></a>
				<?php endif; // manage_payouts ?>
			</h1>

			<?php
			/**
			 * Fires at the top of the referrals list-table admin screen.
			 *
			 * @since 1.0
			 */
			do_action( 'affwp_referrals_page_top' );
			?>

			<?php if ( current_user_can( 'manage_payouts' ) ) : ?>
				<div id="affwp-referrals-export-wrap">

					<?php
					/**
					 * Fires in the action buttons area of the referrals list-table admin screen.
					 *
					 * @since 1.0
					 */
					do_action( 'affwp_referrals_page_buttons' );
					?>

				</div>
			<?php endif; // manage_payouts ?>

			<?php
			// The filter box below is the input only: it shows the username, not the name clicked, and clearing it means emptying a field.
			affwp_affiliate_filter_chip( isset( $_GET['affiliate_id'] ) ? wp_unslash( $_GET['affiliate_id'] ) : '' ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- escaped in the renderer.
			?>

			<form id="affwp-referrals-filter-form" method="get" action="<?php echo esc_url( affwp_admin_url( 'referrals' ) ); ?>">

				<?php $referrals_table->search_box( __( 'Search', 'affiliate-wp' ), 'affwp-referrals' ); ?>

				<input type="hidden" name="page" value="affiliate-wp-referrals" />

				<?php $referrals_table->views() ?>
				<?php $referrals_table->display() ?>
			</form>
			<?php
			/**
			 * Fires at the bottom of the referrals list table admin screen.
			 *
			 * @since 1.0
			 */
			do_action( 'affwp_referrals_page_bottom' );
			?>
		</div>
	<?php
	}

}
