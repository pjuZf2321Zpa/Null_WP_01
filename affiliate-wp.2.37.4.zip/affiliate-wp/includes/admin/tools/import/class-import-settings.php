<?php
/**
 * Tools: Settings Import Batch Processor
 *
 * @package     AffiliateWP
 * @subpackage  Tools/Import
 * @copyright   Copyright (c) 2016, Sandhills Development, LLC
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.0
 */

namespace AffWP\Utils\Importer;

use AffWP\Utils\Importer;

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

#[\AllowDynamicProperties]

/**
 * Implements an importer for AffiliateWP settings.
 *
 * @since 2.0
 */
class Settings implements Importer\Base {

	/**
	 * File contents to import.
	 *
	 * @access public
	 * @since  2.0
	 * @var    null|string
	 */
	public $file = null;

	/**
	 * Import type.
	 *
	 * Used for import-type specific filters/actions
	 *
	 * @access public
	 * @since  2.0
	 * @var    string
	 */
	public $import_type = 'settings';

	/**
	 * Instantiates the settings importer.
	 *
	 * @access public
	 * @since  2.0
	 *
	 * @param null|string $file Settings file data to import.
	 */
	public function __construct( $file = null ) {
		$this->file = $file;
	}

	/**
	 * Determines whether the current user can initiate an import of settings.
	 *
	 * @access public
	 * @since  2.0
	 *
	 * @return bool True if the user can import, otherwise false.
	 */
	public function can_import() {
		return current_user_can( 'manage_affiliate_options' );
	}

	/**
	 * Retrieves the settings data to import.
	 *
	 * @access public
	 * @since  2.0
	 *
	 * @return string Settings import file contents.
	 */
	public function get_data() {
		return affwp_object_to_array( json_decode( file_get_contents( $this->file ) ) );
	}

	/**
	 * Import the settings data.
	 *
	 * @access public
	 * @since  2.0
	 */
	public function import() {
		$data = $this->get_data();

		// Restore payout method picker-visibility to its own option, then strip it
		// so it isn't double-stored into affwp_settings. Absent on legacy exports.
		if ( is_array( $data ) && array_key_exists( 'affwp_hidden_affiliate_payout_methods', $data ) ) {
			update_option( 'affwp_hidden_affiliate_payout_methods', array_values( (array) $data['affwp_hidden_affiliate_payout_methods'] ) );
			unset( $data['affwp_hidden_affiliate_payout_methods'] );
		}

		/*
		 * Never import license state. Activation is bound to the site it was performed on, so
		 * another site's license is never applicable, and get_data() has already flattened the
		 * exported `license_status` object into an array via affwp_object_to_array() — importing
		 * that shape used to leave a valid Pro license failing every tier gate. The site keeps
		 * whatever license fields it already has.
		 */
		if ( is_array( $data ) ) {
			unset( $data['license_status'], $data['license_key'] );
		}

		affiliate_wp()->settings->set( $data, $save = true );
	}
}
