<?php
/**
 * Admin: Tools > AI MCP tab.
 *
 * Explains the WordPress Abilities API integration, offers the WPVibe connector,
 * and holds the write-access toggle for AI abilities.
 *
 * @package     AffiliateWP
 * @subpackage  Admin/Tools
 * @copyright   Copyright (c) 2026, Awesome Motive, Inc.
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.37.0
 */

use AffWP\Abilities\Abilities;
use AffiliateWP\Utils\Icons;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Whether the current user can see the AI MCP tab.
 *
 * @since 2.37.0
 *
 * @return bool
 */
function affwp_ai_mcp_tab_available() {
	return Abilities::is_supported() && current_user_can( 'manage_affiliate_options' );
}

/**
 * Works out whether a connector plugin is active, installed, or absent.
 *
 * @since 2.37.0
 *
 * @param string $basename Plugin basename.
 * @return string 'active', 'installed_inactive', or 'not_installed'.
 */
function affwp_ai_mcp_get_connector_state( $basename ) {
	if ( ! function_exists( 'is_plugin_active' ) ) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
	}

	if ( is_plugin_active( $basename ) ) {
		return 'active';
	}

	return file_exists( WP_PLUGIN_DIR . '/' . $basename ) ? 'installed_inactive' : 'not_installed';
}

/**
 * Retrieves the AI connector plugins the tab offers.
 *
 * StoreAgent only appears when WooCommerce is active because it requires it.
 *
 * @since 2.37.0
 *
 * @return array<string, array> Connectors keyed by slug.
 */
function affwp_ai_mcp_get_connectors() {
	$connectors = array(
		'wpvibe' => array(
			'name'         => 'WPVibe',
			'tagline'      => __( 'A free plugin that connects your AI assistant to AffiliateWP in one click.', 'affiliate-wp' ),
			'basename'     => 'vibe-ai/vibe-ai.php',
			'download_url' => 'https://downloads.wordpress.org/plugin/vibe-ai.latest-stable.zip',
			'setup_url'    => admin_url( 'admin.php?page=vibe-ai' ),
			'setup_label'  => __( 'Set Up WPVibe', 'affiliate-wp' ),
			'manage_label' => __( 'Manage WPVibe', 'affiliate-wp' ),
			'is_connected' => 'affwp_ai_mcp_wpvibe_connected',
			'logo'         => 'wpvibe.svg',
			'recommended'  => true,
			'wporg_url'    => 'https://wordpress.org/plugins/vibe-ai/',
			'site_url'     => affwp_outbound_url( 'wpvibe' ),
		),
	);

	if ( class_exists( 'WooCommerce' ) ) {
		$settings_ready = affwp_ai_mcp_storeagent_settings_ready();

		$connectors['storeagent'] = array(
			'name'         => 'StoreAgent',
			'tagline'      => __( 'A free plugin that connects your AI assistant to your WooCommerce store and AffiliateWP.', 'affiliate-wp' ),
			'basename'     => 'storeagent-ai-for-woocommerce/storeagent-ai-for-woocommerce.php',
			'download_url' => 'https://downloads.wordpress.org/plugin/storeagent-ai-for-woocommerce.latest-stable.zip',
			// StoreAgent only registers its Settings page once connected, so setup starts on its dashboard.
			'setup_url'    => admin_url( 'admin.php?page=storeagent-dashboard' ),
			// Its dashboard sends a connected store with onboarding left to the wizard.
			'manage_url'   => $settings_ready ? admin_url( 'admin.php?page=storeagent-settings&tab=mcp&subtab=general' ) : admin_url( 'admin.php?page=storeagent-dashboard' ),
			'setup_label'  => __( 'Connect StoreAgent', 'affiliate-wp' ),
			'manage_label' => $settings_ready ? __( 'Manage StoreAgent', 'affiliate-wp' ) : __( 'Finish StoreAgent Setup', 'affiliate-wp' ),
			'is_connected' => 'affwp_ai_mcp_storeagent_connected',
			'logo'         => 'storeagent.svg',
			'wporg_url'    => 'https://wordpress.org/plugins/storeagent-ai-for-woocommerce/',
			'site_url'     => affwp_outbound_url( 'storeagent' ),
		);
	}

	/**
	 * Filters the AI connector plugins offered on the AI MCP tab.
	 *
	 * @since 2.37.0
	 *
	 * @param array<string, array> $connectors Connectors keyed by slug.
	 */
	$connectors = apply_filters( 'affwp_ai_mcp_connectors', $connectors );

	foreach ( $connectors as $slug => $connector ) {
		$state = affwp_ai_mcp_get_connector_state( $connector['basename'] );

		$connectors[ $slug ]['state']     = $state;
		$connectors[ $slug ]['connected'] = 'active' === $state
			&& ! empty( $connector['is_connected'] )
			&& is_callable( $connector['is_connected'] )
			&& (bool) call_user_func( $connector['is_connected'] );
	}

	return $connectors;
}

/**
 * Whether WPVibe has a working connection, by the rule its own admin page uses.
 *
 * @since 2.37.0
 *
 * @return bool True when WPVibe received an authenticated request for this site in the last 30 days.
 */
function affwp_ai_mcp_wpvibe_connected() {
	return class_exists( 'WPVibe_Connection_Status' )
		&& method_exists( 'WPVibe_Connection_Status', 'recently_active' )
		&& \WPVibe_Connection_Status::recently_active();
}

/**
 * Whether StoreAgent is connected to its account, by the check its own plugin uses.
 *
 * @since 2.37.0
 *
 * @return bool True when StoreAgent holds the API keys from a completed connection.
 */
function affwp_ai_mcp_storeagent_connected() {
	return class_exists( 'SAAI\\Helpers\\Connect' )
		&& method_exists( 'SAAI\\Helpers\\Connect', 'is_connected' )
		&& \SAAI\Helpers\Connect::is_connected();
}

/**
 * Whether StoreAgent's Settings page exists, which it registers only once connected
 * and through its onboarding wizard.
 *
 * @since 2.37.1
 *
 * @return bool True when StoreAgent is connected and its onboarding wizard is done.
 */
function affwp_ai_mcp_storeagent_settings_ready() {
	return affwp_ai_mcp_storeagent_connected()
		&& class_exists( 'SAAI\\Classes\\Onboarding_Wizard' )
		&& method_exists( 'SAAI\\Classes\\Onboarding_Wizard', 'should_show_wizard' )
		&& ! \SAAI\Classes\Onboarding_Wizard::should_show_wizard();
}

/**
 * Renders a connector's primary action: install, activate, set up, or manage.
 *
 * @since 2.37.0
 *
 * @param string $slug      Connector slug.
 * @param array  $connector Connector from affwp_ai_mcp_get_connectors().
 * @param array  $strings   Install and activate label formats.
 */
function affwp_ai_mcp_connector_action( $slug, $connector, $strings ) {
	$js_slug = esc_js( $slug );
	$primary = ! empty( $connector['recommended'] );

	if ( 'not_installed' === $connector['state'] && ! current_user_can( 'install_plugins' ) ) {
		affwp_button(
			array(
				'text'       => __( 'Install from WordPress.org', 'affiliate-wp' ),
				'variant'    => 'secondary',
				'href'       => $connector['wporg_url'],
				'icon'       => array(
					'name'     => 'share-up-right',
					'position' => 'right',
				),
				'attributes' => array(
					'target' => '_blank',
					'rel'    => 'noopener noreferrer',
				),
			)
		);

		return;
	}

	if ( 'installed_inactive' === $connector['state'] && ! current_user_can( 'activate_plugins' ) ) {
		return;
	}
	?>
	<template x-if="connectors.<?php echo $js_slug; ?>.state !== 'active'">
		<?php
		affwp_button(
			array(
				'text'         => sprintf( 'not_installed' === $connector['state'] ? $strings['install'] : $strings['activate'], $connector['name'] ),
				'variant'      => $primary ? 'primary' : 'secondary',
				'alpine_text'  => "buttonLabel( '{$js_slug}' )",
				'dynamic_icon' => array(
					'name'           => 'loading',
					'show_condition' => "busy === '{$js_slug}'",
					'position'       => 'left',
				),
				'attributes'   => array(
					'@click'    => "connect( '{$js_slug}' )",
					':disabled' => 'busy !== \'\'',
				),
			)
		);
		?>
	</template>
	<template x-if="connectors.<?php echo $js_slug; ?>.state === 'active'">
		<?php
		affwp_button(
			array(
				'text'    => $connector['connected'] && ! empty( $connector['manage_label'] ) ? $connector['manage_label'] : $connector['setup_label'],
				'variant' => $primary && ! $connector['connected'] ? 'primary' : 'secondary',
				'href'    => $connector['connected'] && ! empty( $connector['manage_url'] ) ? $connector['manage_url'] : $connector['setup_url'],
				'icon'    => array(
					'name'     => 'chevron-right',
					'position' => 'right',
				),
			)
		);
		?>
	</template>
	<?php
}

/**
 * Renders one connector as a row: logo, name, status, description, and action.
 *
 * Mirrors the payout method rows on the Payouts settings tab.
 *
 * @since 2.37.0
 *
 * @param string $slug      Connector slug.
 * @param array  $connector Connector from affwp_ai_mcp_get_connectors().
 * @param array  $strings   Install and activate label formats.
 */
function affwp_ai_mcp_connector_row( $slug, $connector, $strings ) {
	$js_slug = esc_js( $slug );
	?>
	<div class="p-4 sm:p-5 lg:p-6">
		<div class="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
			<div class="flex flex-1 items-center gap-3 sm:gap-4 min-w-0">
				<?php if ( ! empty( $connector['mark'] ) ) : ?>
					<span class="flex shrink-0 justify-center items-center text-white bg-gray-900 rounded-lg size-10 sm:size-12" aria-hidden="true">
						<img src="<?php echo esc_url( AFFILIATEWP_PLUGIN_URL . 'assets/images/ai-mcp/' . $connector['mark'] ); ?>" alt="" class="size-6 invert" />
					</span>
				<?php elseif ( ! empty( $connector['logo'] ) ) : ?>
					<img src="<?php echo esc_url( AFFILIATEWP_PLUGIN_URL . 'assets/images/ai-mcp/' . $connector['logo'] ); ?>" alt="" class="object-contain shrink-0 rounded-lg size-10 sm:size-12" />
				<?php endif; ?>
				<div class="flex-1 min-w-0">
					<div class="flex flex-wrap gap-2 items-center mb-1">
						<h3 class="m-0 text-sm font-semibold text-gray-900 sm:text-base"><?php echo esc_html( $connector['name'] ); ?></h3>
						<?php
						if ( $connector['connected'] ) {
							affwp_status_badge( 'connected' );
						}
						?>
					</div>
					<p class="m-0 max-w-prose text-xs text-gray-600 sm:text-sm">
						<?php echo esc_html( $connector['tagline'] ); ?>
						<?php affwp_external_link( $connector['site_url'], __( 'Learn more', 'affiliate-wp' ) ); ?>
					</p>
					<p class="m-0 mt-2 text-sm text-red-600" x-show="connectors.<?php echo $js_slug; ?>.error" x-text="connectors.<?php echo $js_slug; ?>.error" x-cloak></p>
				</div>
			</div>
			<div class="flex shrink-0 items-center self-start sm:self-center">
				<?php affwp_ai_mcp_connector_action( $slug, $connector, $strings ); ?>
			</div>
		</div>
	</div>
	<?php
}

/**
 * Capability cards shown on the tab.
 *
 * Bullets that need write access carry `write => true`.
 *
 * @since 2.37.0
 *
 * @return array[]
 */
function affwp_ai_mcp_get_cards() {
	return array(
		array(
			'icon'    => 'chart-bar-trend-up',
			'title'   => __( 'Program & Reports', 'affiliate-wp' ),
			'bullets' => array(
				array( 'text' => __( 'Get totals for affiliates, referrals, earnings, and visits', 'affiliate-wp' ) ),
				array( 'text' => __( 'Compare any date range, such as this month against last', 'affiliate-wp' ) ),
				array( 'text' => __( 'Check the conversion rate across the whole program', 'affiliate-wp' ) ),
				array( 'text' => __( 'Read the default rate and cookie duration', 'affiliate-wp' ) ),
				array( 'text' => __( 'See which campaigns convert and what they earned', 'affiliate-wp' ) ),
			),
		),
		array(
			'icon'    => 'users',
			'title'   => __( 'Affiliates', 'affiliate-wp' ),
			'bullets' => array(
				array( 'text' => __( 'Find affiliates by name, email, or status', 'affiliate-wp' ) ),
				array( 'text' => __( 'Look up an affiliate\'s referral URL, group, and notes', 'affiliate-wp' ) ),
				array( 'text' => __( 'Find the coupon codes that credit an affiliate', 'affiliate-wp' ) ),
				array( 'text' => __( 'See how an affiliate performed in a date range', 'affiliate-wp' ) ),
				array( 'text' => __( 'Rank affiliates by who earned the most this month', 'affiliate-wp' ) ),
				array( 'text' => __( 'List affiliate groups and their rates', 'affiliate-wp' ) ),
				array(
					'text'  => __( 'Approve, reject, or pause an affiliate', 'affiliate-wp' ),
					'write' => true,
				),
				array(
					'text'  => __( 'Add a new affiliate by name and email', 'affiliate-wp' ),
					'write' => true,
				),
				array(
					'text'  => __( 'Update an affiliate\'s name, rate, or group', 'affiliate-wp' ),
					'write' => true,
				),
			),
		),
		array(
			'icon'    => 'coins',
			'title'   => __( 'Referrals & Payouts', 'affiliate-wp' ),
			'bullets' => array(
				array( 'text' => __( 'List referrals by affiliate, status, integration, or date', 'affiliate-wp' ) ),
				array( 'text' => __( 'Review payouts and the referrals each one covered', 'affiliate-wp' ) ),
				array(
					'text'  => __( 'Credit a missed sale with a manual referral', 'affiliate-wp' ),
					'write' => true,
				),
				array(
					'text'  => __( 'Correct a referral\'s amount or details', 'affiliate-wp' ),
					'write' => true,
				),
				array(
					'text'  => __( 'Change a referral\'s status', 'affiliate-wp' ),
					'write' => true,
				),
			),
		),
		array(
			'icon'    => 'cursor-rays',
			'title'   => __( 'Visits & Creatives', 'affiliate-wp' ),
			'bullets' => array(
				array( 'text' => __( 'See which visits converted and where they came from', 'affiliate-wp' ) ),
				array( 'text' => __( 'Filter visits by affiliate or campaign', 'affiliate-wp' ) ),
				array( 'text' => __( 'List creatives and the pages they link to', 'affiliate-wp' ) ),
				array(
					'text'  => __( 'Add a text link, image, or QR code creative', 'affiliate-wp' ),
					'write' => true,
				),
			),
		),
	);
}

/**
 * Renders the AI MCP tab.
 *
 * @since 2.37.0
 */
function affwp_ai_mcp_tab() {
	if ( ! affwp_ai_mcp_tab_available() ) {
		return;
	}

	$connectors    = affwp_ai_mcp_get_connectors();
	$write_enabled = Abilities::write_enabled();
	$can_install   = current_user_can( 'install_plugins' );
	$ai_clients    = array(
		'claude'  => 'Claude',
		'chatgpt' => 'ChatGPT',
		'cursor'  => 'Cursor',
	);

	$strings = array(
		/* translators: %s: connector plugin name. */
		'install'    => __( 'Install & Activate %s', 'affiliate-wp' ),
		'installing' => __( 'Installing...', 'affiliate-wp' ),
		/* translators: %s: connector plugin name. */
		'activate'   => __( 'Activate %s', 'affiliate-wp' ),
		'activating' => __( 'Activating...', 'affiliate-wp' ),
		'saving'     => __( 'Saving...', 'affiliate-wp' ),
		'saved'      => __( 'Saved', 'affiliate-wp' ),
		'error'      => __( 'Something went wrong. Please try again.', 'affiliate-wp' ),
	);

	$alpine = array(
		'connectors'   => array(),
		'busy'         => '',
		'writeEnabled' => $write_enabled,
		'writeStatus'  => '',
		'error'        => '',
		'strings'      => $strings,
		'ajaxUrl'      => admin_url( 'admin-ajax.php' ),
		'nonce'        => wp_create_nonce( 'affiliate-wp-admin' ),
	);

	foreach ( $connectors as $slug => $connector ) {
		$alpine['connectors'][ $slug ] = array(
			'name'        => $connector['name'],
			'state'       => $connector['state'],
			'downloadUrl' => $connector['download_url'],
			'basename'    => $connector['basename'],
			'error'       => '',
		);
	}
	?>
	<div class="relative py-8 max-w-4xl space-y-6 affwp-ui" x-data="affwpAiMcp(<?php echo esc_attr( wp_json_encode( $alpine ) ); ?>)">

		<?php // Connect: the recommended connector and the write-access setting. ?>
		<div class="p-1 bg-affwp-admin-bg rounded-xl border border-affwp-admin-border">
			<div class="px-5 pt-4 pb-4 sm:px-7">
				<h2 class="m-0 text-lg font-semibold text-gray-900 sm:text-xl"><?php esc_html_e( 'Use AffiliateWP With Your Favorite AI', 'affiliate-wp' ); ?></h2>
				<p class="m-0 mt-1 max-w-prose text-sm text-gray-600"><?php esc_html_e( 'Ask an AI assistant to find your top affiliates, review pending applications, or credit a missed referral in plain English. No copy-pasting, no exports.', 'affiliate-wp' ); ?></p>
				<ul class="flex flex-wrap gap-2 items-center p-0 m-0 mt-3 list-none" aria-label="<?php esc_attr_e( 'Supported AI clients', 'affiliate-wp' ); ?>">
					<?php foreach ( $ai_clients as $client_slug => $client ) : ?>
						<li class="inline-flex gap-1.5 items-center py-1 pr-2.5 pl-1.5 m-0 text-xs font-medium text-gray-700 bg-white rounded-full border border-gray-200">
							<img src="<?php echo esc_url( AFFILIATEWP_PLUGIN_URL . 'assets/images/ai-mcp/' . $client_slug . '.svg' ); ?>" alt="" class="size-4" />
							<?php echo esc_html( $client ); ?>
						</li>
					<?php endforeach; ?>
					<li class="m-0 text-xs text-gray-500"><?php esc_html_e( '+ any MCP client', 'affiliate-wp' ); ?></li>
				</ul>
			</div>

			<div class="overflow-hidden bg-white rounded-lg border divide-y divide-gray-200 border-gray-900/10">
				<?php foreach ( $connectors as $slug => $connector ) : ?>
					<?php affwp_ai_mcp_connector_row( $slug, $connector, $strings ); ?>
				<?php endforeach; ?>
			</div>
		</div>

		<?php // Permissions: the one setting on the tab, covering every AI connection. ?>
		<div class="p-1 bg-affwp-admin-bg rounded-xl border border-affwp-admin-border">
			<div class="px-5 pt-4 pb-4 sm:px-7">
				<h2 class="m-0 text-lg font-semibold text-gray-900 sm:text-xl"><?php esc_html_e( 'AI Permissions', 'affiliate-wp' ); ?></h2>
				<p class="m-0 mt-1 max-w-prose text-sm text-gray-600"><?php esc_html_e( 'AI assistants can always read your program data. Choose whether they can also make changes.', 'affiliate-wp' ); ?></p>
			</div>
			<div class="flex gap-6 justify-between items-center p-4 bg-white rounded-lg border sm:p-5 lg:p-6 border-gray-900/10">
				<div class="flex-1 min-w-0">
					<span class="block mb-1 text-base font-medium text-gray-900">
						<label id="affwp-ai-mcp-write-label" for="affwp-ai-mcp-write-toggle" class="cursor-pointer"><?php esc_html_e( 'Enable MCP Write Access', 'affiliate-wp' ); ?></label>
					</span>
					<p id="affwp-ai-mcp-write-help" class="m-0 max-w-prose text-sm text-gray-600">
						<?php esc_html_e( 'Applies to every AI connection, including WPVibe and StoreAgent. Assistants act as the connected WordPress user and can make mistakes, so only turn this on when you need it.', 'affiliate-wp' ); ?>
					</p>
					<p class="m-0 mt-2 text-sm text-red-600" x-show="error" x-text="error" x-cloak></p>
				</div>
				<div class="flex shrink-0 gap-3 items-center">
					<span class="text-sm text-gray-500" x-text="writeStatus" x-cloak></span>
					<?php
					affwp_toggle(
						array(
							'name'         => 'affwp_abilities_write_enabled',
							'id'           => 'affwp-ai-mcp-write-toggle',
							'labelledby'   => 'affwp-ai-mcp-write-label',
							'describedby'  => 'affwp-ai-mcp-write-help',
							'label'        => __( 'Enable MCP Write Access', 'affiliate-wp' ),
							'checked'      => $write_enabled,
							'size'         => 'sm',
							'color'        => 'blue',
							'alpine_model' => 'writeEnabled',
							'attributes'   => array(
								'@change' => 'saveWriteAccess()',
							),
						)
					);
					?>
				</div>
			</div>
		</div>

		<?php // Capabilities. ?>
		<div class="p-1 bg-affwp-admin-bg rounded-xl border border-affwp-admin-border">
			<div class="flex flex-wrap gap-3 justify-between items-start px-5 pt-4 pb-4 sm:px-7">
				<div class="min-w-0">
					<h2 class="m-0 text-lg font-semibold text-gray-900 sm:text-xl"><?php esc_html_e( 'Everything AffiliateWP Can Do With AI', 'affiliate-wp' ); ?></h2>
					<p class="m-0 mt-1 max-w-prose text-sm text-gray-600"><?php esc_html_e( 'Actions marked Write need MCP write access turned on.', 'affiliate-wp' ); ?></p>
				</div>
				<?php
				affwp_doc_link(
					'using-affiliatewp-with-ai-assistants',
					__( 'View Abilities API Documentation', 'affiliate-wp' ),
					array(
						'utm' => array(
							'source'  => 'plugin',
							'medium'  => 'tools-ai-mcp',
							'content' => 'view-abilities-api-documentation',
						),
					)
				);
				?>
			</div>

			<div class="grid gap-1 md:grid-cols-2">
				<?php foreach ( affwp_ai_mcp_get_cards() as $card ) : ?>
					<div class="p-4 bg-white rounded-lg border sm:p-5 border-gray-900/10">
						<div class="flex gap-2.5 items-center">
							<?php echo Icons::generate( $card['icon'], array( 'class' => 'size-5 text-gray-500' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG. ?>
							<h3 class="m-0 text-base font-semibold text-gray-900"><?php echo esc_html( $card['title'] ); ?></h3>
						</div>
						<ul class="flex flex-col gap-3 p-0 m-0 mt-4 list-none">
							<?php foreach ( $card['bullets'] as $bullet ) : ?>
								<li class="flex gap-2 items-start m-0 text-sm text-gray-700">
									<?php echo Icons::generate( 'check', array( 'class' => 'mt-0.5 size-4 shrink-0 text-gray-400' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG. ?>
									<span class="flex-1"><?php echo esc_html( $bullet['text'] ); ?></span>
									<?php
									if ( ! empty( $bullet['write'] ) ) {
										affwp_badge(
											array(
												'text'    => __( 'Write', 'affiliate-wp' ),
												'variant' => 'neutral',
												'size'    => 'xs',
												'class'   => 'shrink-0',
											)
										);
									}
									?>
								</li>
							<?php endforeach; ?>
						</ul>
					</div>
				<?php endforeach; ?>
			</div>
		</div>

		<?php if ( ! $can_install ) : ?>
			<p class="m-0 text-sm text-gray-500"><?php esc_html_e( 'Your site does not allow plugin installation from the dashboard.', 'affiliate-wp' ); ?></p>
		<?php endif; ?>
	</div>

	<script>
		document.addEventListener( 'alpine:init', () => {
			Alpine.data( 'affwpAiMcp', ( config ) => ( {
				...config,

				buttonLabel( slug ) {
					const connector  = this.connectors[ slug ];
					const installing = 'not_installed' === connector.state;

					if ( this.busy === slug ) {
						return installing ? this.strings.installing : this.strings.activating;
					}

					return ( installing ? this.strings.install : this.strings.activate ).replace( '%s', connector.name );
				},

				async post( action, fields ) {
					const response = await fetch( this.ajaxUrl, {
						method: 'POST',
						headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
						body: new URLSearchParams( { action, nonce: this.nonce, ...fields } ),
					} );

					return response.json();
				},

				async connect( slug ) {
					const connector = this.connectors[ slug ];

					if ( this.busy || ! connector ) {
						return;
					}

					this.busy       = slug;
					connector.error = '';

					try {
						if ( 'not_installed' === connector.state ) {
							const result = await this.post( 'affwp_install_plugin', { plugin: connector.downloadUrl } );

							if ( ! result.success ) {
								throw new Error( result.data?.msg || result.data || this.strings.error );
							}

							connector.state = result.data.is_activated ? 'active' : 'installed_inactive';

							// Attribution only; failures here must not block the flow.
							this.post( 'affwp_ai_mcp_connector_installed', { connector: slug } ).catch( () => {} );
						}

						if ( 'installed_inactive' === connector.state ) {
							const result = await this.post( 'affwp_activate_plugin', { plugin: connector.basename } );

							if ( ! result.success ) {
								throw new Error( result.data || this.strings.error );
							}

							connector.state = 'active';
						}
					} catch ( err ) {
						connector.error = err.message || this.strings.error;
					}

					this.busy = '';
				},

				async saveWriteAccess() {
					this.writeStatus = this.strings.saving;
					this.error       = '';

					try {
						const result = await this.post( 'affwp_ai_mcp_toggle_write', { enabled: this.writeEnabled ? 1 : 0 } );

						if ( ! result.success ) {
							throw new Error( result.data || this.strings.error );
						}

						this.writeEnabled = !! result.data.enabled;
						this.writeStatus  = this.strings.saved;
						setTimeout( () => { this.writeStatus = ''; }, 2000 );
					} catch ( err ) {
						this.writeEnabled = ! this.writeEnabled;
						this.writeStatus  = '';
						this.error        = err.message || this.strings.error;
					}
				},
			} ) );
		} );
	</script>
	<?php
}
add_action( 'affwp_tools_tab_ai_mcp', 'affwp_ai_mcp_tab' );

/**
 * Saves the write-access toggle over AJAX.
 *
 * @since 2.37.0
 */
function affwp_ai_mcp_toggle_write() {
	check_ajax_referer( 'affiliate-wp-admin', 'nonce' );

	if ( ! affwp_ai_mcp_tab_available() ) {
		wp_send_json_error( __( 'You do not have permission to change this setting.', 'affiliate-wp' ), 403 );
	}

	$enabled = ! empty( $_POST['enabled'] ) && '0' !== $_POST['enabled'];

	affiliate_wp()->settings->set( array( Abilities::WRITE_SETTING => $enabled ? 1 : 0 ), true );

	wp_send_json_success( array( 'enabled' => $enabled ) );
}
add_action( 'wp_ajax_affwp_ai_mcp_toggle_write', 'affwp_ai_mcp_toggle_write' );

/**
 * Records AffiliateWP as the install source of a connector plugin.
 *
 * StoreAgent reads `storeagentai_installed_by` into its outbound UTM content.
 *
 * @since 2.37.0
 */
function affwp_ai_mcp_connector_installed() {
	check_ajax_referer( 'affiliate-wp-admin', 'nonce' );

	if ( ! affwp_ai_mcp_tab_available() ) {
		wp_send_json_error( __( 'You do not have permission to do this.', 'affiliate-wp' ), 403 );
	}

	$connector = isset( $_POST['connector'] ) ? sanitize_key( wp_unslash( $_POST['connector'] ) ) : '';

	if ( 'storeagent' === $connector ) {
		add_option( 'storeagentai_installed_by', 'affiliatewp', '', false );
	}

	wp_send_json_success();
}
add_action( 'wp_ajax_affwp_ai_mcp_connector_installed', 'affwp_ai_mcp_connector_installed' );
