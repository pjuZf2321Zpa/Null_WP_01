<?php
/**
 * Admin: Payout Submitted router stub.
 *
 * The dedicated post-submit landing page was replaced in 2.33.0 by the batches
 * tab + batch drawer: same data, same live updates, one fewer single-use
 * surface. The full original implementation is preserved as a feature-doc
 * reference at content/affiliatewp/features/payouts-redesign/archived-submitted-page.php
 * (outside the plugin tree — never loaded).
 *
 * Two reasons this stub still exists:
 *
 * 1. Legacy Payouts Service URLs. Pre-2.33.0 callers used the old single-payout
 *    flow that lands here via `?payouts_service_payout_id=X` (no batch_id). The
 *    Payouts Service add-on continues to depend on this entry point, so we
 *    include `submitted-legacy.php` for those requests untouched.
 *
 * 2. Bookmarked URLs. Anyone with a stored `?action=payout_submitted&batch_id=N`
 *    URL gets a clean redirect to the batches drawer rather than a broken page.
 *
 * @package    AffiliateWP
 * @subpackage Admin/Payouts
 * @copyright  Copyright (c) 2019, Sandhills Development, LLC
 * @license    http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since      2.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! empty( $_REQUEST['payouts_service_payout_id'] ) ) {
	include AFFILIATEWP_PLUGIN_DIR . 'includes/admin/payouts/submitted-legacy.php';
	return;
}

$batch_id = isset( $_REQUEST['batch_id'] ) ? absint( $_REQUEST['batch_id'] ) : 0;

if ( $batch_id <= 0 ) {
	wp_safe_redirect( affwp_admin_url( 'payouts', array( 'tab' => 'batches' ) ) );
	exit;
}

wp_safe_redirect(
	affwp_admin_url(
		'payouts',
		array(
			'tab'      => 'batches',
			'batch_id' => $batch_id,
		)
	)
);
exit;
