<?php
/**
 * Admin: Pay Affiliates action bar shell.
 *
 * Shared chrome for the fixed bottom bar on both the New Payout (configure) and
 * Preview screens, so the two never drift apart on alignment again.
 *
 * The gutter padding (22px left / 20px right mirroring WP admin's wrap gutters)
 * lives on the outer wrapper, and `max-w-5xl` constrains the inner row only.
 * That keeps the bar's column tracking the form/preview panels above it: same
 * left edge after the gutter, same right edge at the panel boundary. Putting
 * `max-w-5xl` on the padded element instead shrinks the button column by 42px.
 *
 * Expected variables (set by the including page):
 * - $action_bar_status (string) Pre-rendered HTML for the left status block.
 * - $action_bar_action (string) Pre-rendered HTML for the right action control.
 * - $action_bar_bands  (string) Optional pre-rendered alert bands, rendered
 *                               full-bleed above the row. Defaults to ''.
 *
 * @package    AffiliateWP
 * @subpackage Admin/Payouts
 * @since      2.33.0
 */

if ( ! isset( $action_bar_bands ) ) {
	$action_bar_bands = '';
}
?>
<div class="affwp-ui affwp-payout-action-bar" x-data>
	<?php echo $action_bar_bands; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- caller-rendered markup. ?>
	<div class="pl-[22px] pr-[20px]">
		<div class="max-w-5xl flex flex-col items-stretch gap-3 sm:flex-row sm:items-center sm:justify-between sm:gap-6 px-6 py-3">
			<?php echo $action_bar_status; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- caller-rendered markup. ?>
			<?php echo $action_bar_action; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- caller-rendered markup. ?>
		</div>
	</div>
</div>
