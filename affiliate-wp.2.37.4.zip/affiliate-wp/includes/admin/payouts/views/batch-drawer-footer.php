<?php
/**
 * Batch Drawer — Footer
 *
 * The footer is a *status surface*, not an action surface. Most failures
 * self-resolve via Phase D's daily auto-retry sweep and Phase C's affiliate
 * notification email, so for the dominant case the footer simply communicates
 * what the system has already handled. CTAs only appear when there's an
 * admin-side action that would actually change the outcome.
 *
 * Modes (computed server-side, see affwp_build_batch_drawer_payload):
 *   - processing   : batch in flight, "Safe to close" caption, Done only
 *   - done         : terminal + clean, no caption, Done only
 *   - self_healing : terminal with system-handled failures, calm caption,
 *                    no CTA (the system already emailed + will auto-retry)
 *   - needs_review : terminal with admin-blocking failures, caption + a
 *                    secondary "Review failures" CTA that filters the list
 *   - mixed        : terminal with both classes; caption surfaces both,
 *                    CTA gates on the admin-required count
 *
 * @package     AffiliateWP
 * @subpackage  Admin/Payouts
 * @since       2.33.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>
<div x-data="{ get drawer() { return $store.batchDrawer; } }"
	class="flex items-center gap-3">

	<!--
		Caption sits on the left, paired with a mode-appropriate icon.
		Hidden when there's nothing to say (terminal + clean batch).
	-->
	<template x-if="drawer.batch && drawer.batch.footer_caption">
		<p class="text-xs text-gray-500 m-0 flex items-center gap-1.5 min-w-0">

			<!-- Processing: spinner-ish info icon. -->
			<template x-if="drawer.batch.footer_mode === 'processing'">
				<svg class="w-3.5 h-3.5 shrink-0" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
					<path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd"/>
				</svg>
			</template>

			<!--
				Self-healing: circle-check, in the same brand tint as the
				badge so the surface reads as "handled" rather than "alert."
			-->
			<template x-if="drawer.batch.footer_mode === 'self_healing'">
				<svg class="w-3.5 h-3.5 shrink-0 text-green-600" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
					<path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
				</svg>
			</template>

			<!-- needs_review / mixed: alert icon. -->
			<template x-if="drawer.batch.footer_mode === 'needs_review' || drawer.batch.footer_mode === 'mixed'">
				<svg class="w-3.5 h-3.5 shrink-0 text-orange-600" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
					<path fill-rule="evenodd" d="M8.485 2.495c.673-1.167 2.357-1.167 3.03 0l6.28 10.875c.673 1.167-.17 2.625-1.516 2.625H3.72c-1.347 0-2.189-1.458-1.515-2.625L8.485 2.495zM10 6a1 1 0 011 1v3a1 1 0 11-2 0V7a1 1 0 011-1zm0 8a1 1 0 100-2 1 1 0 000 2z" clip-rule="evenodd"/>
				</svg>
			</template>

			<span class="truncate" x-text="drawer.batch.footer_caption"></span>
		</p>
	</template>

	<!--
		No CTAs in the footer. The status filter tabs in the drawer body
		already let admins focus on failures; a "Review failures" button
		here was duplicate UI. Close is owned by the X-icon and Escape.
	-->

</div>
