<?php
/**
 * Payout Drawer — Timeline
 *
 * One spine, nodes sitting on it. The rail is a single 2px stroke
 * behind the 12px circles (white fill punches the line). No gap
 * between circle and stem. The line stops at the last node.
 *
 * Expects the parent `x-data="{ drawer: $store.payoutDrawer }"` scope
 * (see drawer.php content_callback).
 *
 * @package     AffiliateWP
 * @subpackage  Admin/Payouts
 * @since       2.36.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>

<template x-if="drawer.payout && drawer.payout.timeline && drawer.payout.timeline.length > 0">
	<section class="flex flex-col gap-4">

		<div class="flex items-baseline justify-between gap-3">
			<h3 class="text-lg font-semibold text-gray-900 m-0"><?php esc_html_e( 'Timeline', 'affiliate-wp' ); ?></h3>
			<?php
			/*
			 * Manual refresh for an in-flight Global payout: polls Stripe (the only party that
			 * can answer) instead of waiting on the webhook or the twice-daily reconciler.
			 * The nonce doubles as the visibility gate — see the drawer payload builder.
			 */
			?>
			<template x-if="drawer.payout.stripe_global_recheck_nonce">
				<button type="button"
					@click="drawer.recheckGlobalPayout()"
					:disabled="drawer.isRecheckingGlobal"
					class="cursor-pointer whitespace-nowrap bg-transparent border-0 p-0 text-sm font-medium text-affwp-link hover:text-affwp-link-hover focus:outline-none focus-visible:underline rounded disabled:opacity-50 disabled:cursor-not-allowed">
					<span x-text="drawer.isRecheckingGlobal ? '<?php echo esc_js( __( 'Checking…', 'affiliate-wp' ) ); ?>' : '<?php echo esc_js( __( 'Check with Stripe', 'affiliate-wp' ) ); ?>'"></span>
				</button>
			</template>
		</div>

		<ol class="m-0 p-0 list-none">
			<template x-for="(event, index) in drawer.payout.timeline" :key="event.key">
				<li class="flex gap-3">
					<div class="relative w-3 shrink-0 self-stretch">
						<span class="absolute left-1/2 -translate-x-1/2 w-0.5 bg-gray-300"
							aria-hidden="true"
							:class="{
								'top-2.5 bottom-0': index === 0,
								'inset-y-0': index > 0 && index < drawer.payout.timeline.length - 1,
								'top-0 h-2.5': index === drawer.payout.timeline.length - 1
							}"></span>
						<span class="relative z-10 mt-1 mx-auto block size-3 rounded-full border bg-white"
							:class="{
								'border-red-400': event.tone === 'danger',
								'border-gray-300': event.tone === 'upcoming',
								'border-gray-400': event.tone === 'done'
							}"></span>
					</div>
					<div class="min-w-0"
						:class="index < drawer.payout.timeline.length - 1 ? 'pb-4' : ''">
						<p class="text-sm font-semibold m-0"
							:class="{
								'text-red-700': event.tone === 'danger',
								'text-gray-500': event.tone === 'upcoming',
								'text-gray-900': event.tone === 'done'
							}"
							x-text="event.label"></p>
						<p class="mt-0.5 mb-0 text-xs text-gray-500" x-show="event.at" x-text="event.at"></p>
					</div>
				</li>
			</template>
		</ol>

	</section>
</template>
