<?php
/**
 * Payout Drawer — Header (amount + status + recipient)
 *
 * Stripe's payout drawer stack, under our "Payout #N" title:
 *
 *   $14.00  [Paid]
 *   Payout to Affiliate Name
 *
 * Amount and status are one statement. The name is a caption.
 * Sent / paid / arrival live on the Timeline. No avatar here.
 *
 * Rendered via the drawer trait's `header_callback` slot.
 *
 * @package     AffiliateWP
 * @subpackage  Admin/Payouts
 * @since       2.33.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>
<!--
	Pager sits *on the title row*, to the left of the close-X button.

	The trait renders the title (<h2 x-text="title">) above the header_callback
	slot, with a close-X button on the far right. Neither is directly reachable
	from our callback. We anchor the pager absolutely against the drawer shell
	(`relative` class on the outer drawer panel in trait-drawers.php) so it
	drops into the visual slot between "Payout #X" and the close-X.

	Tuning: top-5 (20px) vertically centers the 24px pager bar against the
	32px close-X (header row is items-start, so top-4 would align TOPS and
	leave the pager's center 4px above X's). right-20 (80px) clears the
	close-X button (p-1.5 on a 20px icon ≈ 32px wide + 24px right
	padding ≈ 56px from drawer edge) with a comfortable ~24px breathing gap.
-->
<div x-show="$store.payoutDrawer.payout && $store.payoutDrawer.showPager"
	x-cloak
	class="absolute right-20 top-5 flex items-center gap-2 text-xs text-gray-500 z-10">
		<span x-text="$store.payoutDrawer.listPosition + ' of ' + $store.payoutDrawer.listTotal"></span>
		<span class="text-gray-300" aria-hidden="true">·</span>
		<div class="inline-flex items-center gap-0.5">
			<button type="button"
				@click="$store.payoutDrawer.goPrev()"
				:disabled="! $store.payoutDrawer.hasPrev"
				class="inline-flex items-center justify-center size-6 rounded bg-transparent border-0 text-gray-500 hover:text-gray-900 hover:bg-gray-100 disabled:opacity-30 disabled:pointer-events-none focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-1 focus-visible:ring-affwp-brand-500 cursor-pointer transition-colors"
				data-tooltip-html="<?php echo esc_attr( affwp_dark_tooltip_html( __( 'Prev', 'affiliate-wp' ), '', '↑' ) ); ?>"
				data-tooltip-placement="bottom"
				data-tooltip-arrow="false"
				data-tooltip-interactive="false">
				<span class="sr-only"><?php esc_html_e( 'Previous payout', 'affiliate-wp' ); ?></span>
				<?php \AffiliateWP\Utils\Icons::render( 'chevron-up', [ 'class' => 'size-4' ] ); ?>
			</button>
			<button type="button"
				@click="$store.payoutDrawer.goNext()"
				:disabled="! $store.payoutDrawer.hasNext"
				class="inline-flex items-center justify-center size-6 rounded bg-transparent border-0 text-gray-500 hover:text-gray-900 hover:bg-gray-100 disabled:opacity-30 disabled:pointer-events-none focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-1 focus-visible:ring-affwp-brand-500 cursor-pointer transition-colors"
				data-tooltip-html="<?php echo esc_attr( affwp_dark_tooltip_html( __( 'Next', 'affiliate-wp' ), '', '↓' ) ); ?>"
				data-tooltip-placement="bottom"
				data-tooltip-arrow="false"
				data-tooltip-interactive="false">
				<span class="sr-only"><?php esc_html_e( 'Next payout', 'affiliate-wp' ); ?></span>
				<?php \AffiliateWP\Utils\Icons::render( 'chevron-down', [ 'class' => 'size-4' ] ); ?>
			</button>
		</div>
</div>

<template x-if="$store.payoutDrawer.payout">
<div>

	<!--
		Breadcrumb: "← Back to Batch #N" — only renders when this drawer was
		opened via a drawer-to-drawer swap from the batch drawer (returnTo
		is set by batchDrawer.openPayout()). Clicking closes this drawer
		and re-opens the batch drawer. Cleared on close + on keyboard
		navigation (arrow keys) because once the admin starts walking the
		list, the "came from batch" origin is no longer meaningful.
	-->
	<!--
		@click.stop is essential on both breadcrumb buttons. goBack()
		clears `returnTo`, which causes the x-if to remove the button
		from the DOM. Without .stop the click event keeps bubbling up
		to the drawer wrapper's outside-click handler in trait-drawers.php,
		which calls event.target.closest('[data-affwp-drawer-panel]') —
		gets null on the now-detached button — and concludes the click
		was outside the drawer, closing it. Same trap we hit on the
		Resend reminder; flagged here for the next person.
	-->
	<template x-if="$store.payoutDrawer.returnTo && $store.payoutDrawer.returnTo.type === 'batch'">
		<button type="button"
			@click.stop="$store.payoutDrawer.goBack()"
			class="mt-1 inline-flex items-center gap-1 text-xs text-gray-500 hover:text-gray-900 bg-transparent border-0 cursor-pointer focus:outline-none focus:ring-2 focus:ring-affwp-brand-500 rounded">
			<svg class="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
				<path d="M15 18l-6-6 6-6"/>
			</svg>
			<span>
				<?php echo esc_html_x( 'Back to Batch', 'drawer breadcrumb', 'affiliate-wp' ); ?>
				#<span x-text="$store.payoutDrawer.returnTo.id"></span>
			</span>
		</button>
	</template>

	<!--
		Breadcrumb: "← Back to #N" — renders when this drawer was opened
		from another payout's drawer via the supersession card's "View
		active payout #N" CTA. Same affordance + visual treatment as the
		batch breadcrumb above; the switchyard in goBack() routes to the
		correct openFor call based on returnTo.type.
	-->
	<template x-if="$store.payoutDrawer.returnTo && $store.payoutDrawer.returnTo.type === 'payout'">
		<button type="button"
			@click.stop="$store.payoutDrawer.goBack()"
			class="mt-1 inline-flex items-center gap-1 text-xs text-gray-500 hover:text-gray-900 bg-transparent border-0 cursor-pointer focus:outline-none focus:ring-2 focus:ring-affwp-brand-500 rounded">
			<svg class="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
				<path d="M15 18l-6-6 6-6"/>
			</svg>
			<span>
				<?php echo esc_html_x( 'Back to', 'drawer breadcrumb', 'affiliate-wp' ); ?>
				#<span x-text="$store.payoutDrawer.returnTo.id"></span>
			</span>
		</button>
	</template>

	<!--
		Breadcrumb: "← Back to selection" — renders when this drawer was opened from the
		Referrals bulk-pay drawer's "View payout" link (returnTo.type === 'bulkPay').
		goBack() re-opens the bulk-pay drawer with the same hand-picked selection.
	-->
	<template x-if="$store.payoutDrawer.returnTo && $store.payoutDrawer.returnTo.type === 'bulkPay'">
		<button type="button"
			@click.stop="$store.payoutDrawer.goBack()"
			class="mt-1 inline-flex items-center gap-1 text-xs text-gray-500 hover:text-gray-900 bg-transparent border-0 cursor-pointer focus:outline-none focus:ring-2 focus:ring-affwp-brand-500 rounded">
			<svg class="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
				<path d="M15 18l-6-6 6-6"/>
			</svg>
			<span><?php echo esc_html_x( 'Back to selection', 'drawer breadcrumb', 'affiliate-wp' ); ?></span>
		</button>
	</template>

	<!--
		Amount + status + recipient dim during in-drawer navigation.
		Pager chevrons above stay at full opacity so the nav controls
		never feel unresponsive.
	-->
	<div class="mt-3 min-w-0 transition-opacity duration-200"
		:class="{ 'opacity-60': $store.payoutDrawer.isNavigating }">

		<div class="flex items-center gap-2.5">
			<p class="text-3xl font-semibold tracking-tight text-gray-900 m-0"
				x-text="$store.payoutDrawer.payout.amount_formatted"></p>
			<span :class="$store.payoutDrawer.badgeClass( $store.payoutDrawer.badgeVariantForPayoutStatus( $store.payoutDrawer.status ) )"
				x-text="$store.payoutDrawer.payout.status_label"></span>
		</div>

		<p class="mt-1 mb-0 text-sm text-gray-600">
			<?php esc_html_e( 'Payout to', 'affiliate-wp' ); ?>
			<span class="font-medium text-gray-700"
				x-text="$store.payoutDrawer.payout.affiliate_name"></span>
		</p>

	</div>

</div>
</template>
