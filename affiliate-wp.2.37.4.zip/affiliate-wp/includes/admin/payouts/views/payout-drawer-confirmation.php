<?php
/**
 * Payout Drawer — Delivery confirmation
 *
 * Expected-arrival fallback for payouts without a rail Timeline. The
 * credited view owns the receives amount and the Stripe exit links;
 * arrival on a timelined payout is that Timeline's last node, so this
 * renders only when there is no timeline to carry it.
 *
 * Expects the parent `x-data="{ drawer: $store.payoutDrawer }"` scope
 * (see drawer.php content_callback).
 *
 * @package     AffiliateWP
 * @subpackage  Admin/Payouts
 * @since       2.36.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>

<?php
/*
 * Arrival is a Timeline fact when a timeline exists, so the whole view gates on its
 * absence — an empty wrapper would still claim a section slot in the drawer's gap-12
 * stack and read as a dead gap between the receives block and the status card.
 */
?>
<template x-if="drawer.payout && drawer.hasStripeConfirmation && drawer.payout.stripe_delivery_arrival && ! ( drawer.payout.timeline && drawer.payout.timeline.length )">
	<div class="flex flex-col gap-0.5">
		<span class="text-sm font-semibold text-gray-900"><?php esc_html_e( 'Expected delivery date', 'affiliate-wp' ); ?></span>
		<span class="text-sm text-gray-700" x-text="drawer.payout.stripe_delivery_arrival"></span>
	</div>
</template>
