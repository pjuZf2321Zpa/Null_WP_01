<?php
/**
 * Payout Drawer — Summary Card
 *
 * Unclassified-failure safety rail. PayPal bookkeeping (sender batch ID,
 * PayPal batch ID, last poll) lives in Details. Stripe hops live on the
 * Timeline. This card only renders when a failed payout has a raw reason
 * and no Next Steps payload.
 *
 * Hidden entirely for simple methods (manual, store_credit) where there's no
 * method-specific state worth showing — the header already has amount +
 * status + affiliate, and a near-empty card there would be noise.
 *
 * Expects the parent `x-data="{ drawer: $store.payoutDrawer }"` scope
 * (see drawer.php content_callback).
 *
 * @package     AffiliateWP
 * @subpackage  Admin/Payouts
 * @since       2.33.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>

<?php
/*
 * Connect link row. A payout holds one transfer per referral, so there is no
 * payout-level Stripe object to describe — a card around a single link only
 * restated the method name and a count the Referrals list already shows.
 */
?>
<template x-if="drawer.payout && 'stripe' === drawer.method && drawer.hasStripeTransfers">
	<div class="flex flex-col gap-1">
		<template x-if="drawer.stripeDashboardUrl">
			<div class="flex flex-wrap items-center gap-x-4 gap-y-1">
				<a :href="drawer.stripeDashboardUrl"
			target="_blank"
			rel="noopener noreferrer"
			class="inline-flex items-center gap-1.5 text-sm text-affwp-link hover:text-affwp-link-hover"
			title="<?php echo esc_attr__( 'View in Stripe (opens in a new tab)', 'affiliate-wp' ); ?>">
				<span><?php esc_html_e( 'View in Stripe', 'affiliate-wp' ); ?></span>
				<svg class="w-3.5 h-3.5 shrink-0" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true"><path d="M11 3a1 1 0 100 2h2.586l-6.293 6.293a1 1 0 101.414 1.414L15 6.414V9a1 1 0 102 0V4a1 1 0 00-1-1h-5z"/><path d="M5 5a2 2 0 00-2 2v8a2 2 0 002 2h8a2 2 0 002-2v-3a1 1 0 10-2 0v3H5V7h3a1 1 0 000-2H5z"/></svg>
				</a>
			</div>
		</template>

		<?php /* Recovery belongs where the admin already is when it went wrong, one click from the transfer. */ ?>
		<p class="m-0 text-xs text-gray-500"><?php esc_html_e( 'Reversible in Stripe until it reaches their bank.', 'affiliate-wp' ); ?></p>
	</div>
</template>

<template x-if="drawer.payout && drawer.showSummaryCard">
	<div class="affwp-card rounded-lg border border-gray-200 bg-white overflow-hidden">

		<div class="flex flex-col gap-4 p-4">

			<?php
			/*
			 * The stripe-global "Sent…" note card lived here until the Timeline learned to tell
			 * the same story (Sent to Stripe → Sent to the bank → Expected arrival). The manual
			 * "Check with Stripe" affordance moved to the Timeline heading with it. Connect's
			 * transfer link sits above this card, so the incoming Stripe Transfers block is
			 * not restored here.
			 */
			?>

			<!--
				Supersession banner. Sits ABOVE the failure block because
				it's the more actionable signal: when this payout has been
				replaced by another (via Switch method), the admin's
				attention should go to the replacement, not the historical
				failure. Click-through opens the replacement payout in the
				drawer (via the drawer's openFor() — same single-drawer
				invariant the rest of the navigation uses).
			-->
			<!--
				Supersession banner was previously here. Promoted in 2.33.0
				to a standalone card rendered above this summary card (see
				payout-drawer-supersession.php), with the active-replacement
				link as a prominent CTA. The original-failure messaging
				below is also suppressed for superseded payouts (closed-
				book state, no useful re-diagnosis).
			-->

			<!--
				Failed state: surface the raw error reason ONLY when no
				Next Steps card is taking over AND the payout isn't
				superseded.

				Next Steps card: carries the human-readable diagnosis +
				the recommended action for every classified failure
				(affiliate_action_required, transient, admin_action_required,
				data_error). Showing the red block alongside it is
				diagnosis-twice → resolution.

				Superseded: the failure is closed-book and the drawer is
				retrospective audit. Showing a red "This payout failed"
				banner sends the wrong emotional signal for a resolved
				state. The error string survives in the Details panel
				for power users who need the raw text.

				Unclassified + active failures (failure_class empty or
				'unknown', not superseded) still fall through to this
				block as the safety rail.
			-->
			<!--
				Failure card error rendering. The headline reads the
				human-readable sentence (PayPal: parsed `error` field;
				other methods: the plain error_message string). The raw
				provider payload — when one exists — lives inside a
				collapsible disclosure so support can still inspect it
				without dumping JSON into the card by default.

				Inline `overflow-wrap: anywhere; white-space: pre-wrap`
				on the headline + `<pre>` keep long JSON-style tokens
				inside the red card instead of punching through the
				right edge. These went in inline when the utilities
				weren't compiled yet; `wrap-anywhere` and
				`whitespace-pre-wrap` ARE generated now, so new markup
				uses the utilities.
				The leftovers here also carry `bg-white/60`, which is NOT
				compiled, so converting this block means a CSS rebuild:
				worth doing, but as its own change rather than silently
				inside a PayPal fix.
				`min-w-0` on the flex child is what lets the wrap
				actually take effect inside the icon+text row.
			-->
			<template x-if="drawer.isFailed
				&& ! drawer.isSuperseded
				&& ! ( drawer.payout && drawer.payout.next_steps )
				&& (
					(drawer.paypalData && (drawer.paypalData.error_headline || drawer.paypalData.error))
					|| (drawer.payout && drawer.payout.error_message)
				)">
				<div class="rounded-md bg-red-50 border border-red-100 p-3 flex gap-2 items-start">
					<?php \AffiliateWP\Utils\Icons::render( 'circle-warning', '', [ 'class' => 'size-4 mt-0.5 text-red-500 shrink-0' ] ); ?>
					<div class="text-xs min-w-0 flex-1">
						<p class="font-medium text-red-800 m-0"><?php esc_html_e( 'This payout failed', 'affiliate-wp' ); ?></p>
						<p class="text-red-700 m-0 mt-1 break-words"
							style="overflow-wrap: anywhere; word-break: break-word;"
							x-text="(drawer.paypalData && (drawer.paypalData.error_headline || drawer.paypalData.error)) || drawer.payout.error_message"></p>

						<template x-if="drawer.paypalData && drawer.paypalData.error_raw">
							<details class="mt-2">
								<summary class="cursor-pointer select-none text-red-700"
									style="opacity: 0.85;">
									<?php esc_html_e( 'Show raw provider response', 'affiliate-wp' ); ?>
								</summary>
								<pre class="mt-1 p-2 border border-red-100 rounded text-red-900 break-words select-all m-0"
									style="background: rgba(255,255,255,0.6); font-size: 11px; white-space: pre-wrap; overflow-wrap: anywhere; word-break: break-word; max-width: 100%;"
									x-text="drawer.paypalData.error_raw"></pre>
							</details>
						</template>
					</div>
				</div>
			</template>

		</div>
	</div>
</template>
