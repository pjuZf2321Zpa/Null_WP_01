<?php
/**
 * Payout Drawer — Details
 *
 * One heading, one stacked list. Bookkeeping only — confirmation
 * (credited amount, Stripe exits) renders above this section from
 * drawer.php. Never a card, never a disclosure.
 *
 * Fires the classic `affwp_edit_payout_*` hooks so integrators continue
 * to work without a migration — context change for `_end` is documented
 * in the changelog (block context, not table rows).
 *
 * Expects the parent `x-data="{ drawer: $store.payoutDrawer }"` scope
 * (see drawer.php content_callback).
 *
 * @package     AffiliateWP
 * @subpackage  Admin/Payouts
 * @since       2.33.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>

<template x-if="drawer.payout">
	<section class="space-y-4">

		<h3 class="text-lg font-semibold text-gray-900"><?php esc_html_e( 'Details', 'affiliate-wp' ); ?></h3>

		<?php
		/*
		 * Stacked definition list (bold label over value, left-aligned).
		 * Section title is text-lg; labels stay text-sm font-semibold
		 * so the heading outranks the fields. Money-table alignment
		 * (label left / value right) is reserved for actual fee line
		 * items; these rows are facts, not figures.
		 */
		?>
		<div class="flex flex-col gap-4">

			<dl class="flex flex-col gap-4">

			<template x-if="drawer.payout.batch_id && drawer.payout.batch_id > 0">
				<div class="flex flex-col gap-0.5">
					<dt class="text-sm font-semibold text-gray-900"><?php esc_html_e( 'Batch', 'affiliate-wp' ); ?></dt>
					<?php
					/*
					 * Click swaps drawers (payout closes, batch opens) when
					 * the batch drawer is registered on this page. On pages
					 * without the batch drawer, the link navigates normally
					 * to the batches tab with ?batch_id=X — the batch
					 * drawer auto-opens there from the URL param. Either
					 * path lands the admin on the same state; the drawer
					 * swap is just the smoother variant.
					 */
					?>
					<dd>
						<a :href="drawer.payout.batch_url"
							@click="if ( drawer.openBatch( drawer.payout.batch_id ) ) $event.preventDefault()"
							class="text-affwp-link hover:text-affwp-link-hover"
							x-text="'#' + drawer.payout.batch_id"></a>
					</dd>
				</div>
			</template>

			<?php
			/*
			 * Retry-chain lineage. When this payout replaced an earlier attempt
			 * (hidden from the list because chains collapse to their current
			 * tail), surface the link back here as provenance — alongside Batch,
			 * where the other relational facts live. Clicking swaps the drawer
			 * to the previous attempt, with returnTo so the back-breadcrumb works.
			 */
			?>
			<template x-if="drawer.payout.previous_payout_id && drawer.payout.previous_payout_id > 0">
				<div class="flex flex-col gap-0.5">
					<dt class="text-sm font-semibold text-gray-900"><?php esc_html_e( 'Previous attempt', 'affiliate-wp' ); ?></dt>
					<dd>
						<a href="#"
							@click.prevent="drawer.openFor( drawer.payout.previous_payout_id, { returnTo: { type: 'payout', id: drawer.payoutId } } )"
							class="text-affwp-link hover:text-affwp-link-hover"
							x-text="'#' + drawer.payout.previous_payout_id"></a>
					</dd>
				</div>
			</template>

			<?php
			/*
			 * Header already named the affiliate. This row is the
			 * profile deep link — ID only, so the name is not restated.
			 */
			?>
			<div class="flex flex-col gap-0.5">
				<dt class="text-sm font-semibold text-gray-900"><?php esc_html_e( 'Affiliate', 'affiliate-wp' ); ?></dt>
				<dd>
					<a :href="drawer.payout.affiliate_url"
						class="text-affwp-link hover:text-affwp-link-hover"
						x-text="'#' + drawer.payout.affiliate_id"></a>
				</dd>
			</div>

			<?php
			/*
			 * Selectable text, not mailto. The admin is reconciling a
			 * payout, not composing mail. Failure contact lives on Next
			 * Steps; the affiliate name already goes to the profile.
			 * select-all lets them copy the address if they need it.
			 */
			?>
			<template x-if="drawer.payout.payout_email || drawer.payout.affiliate_email">
				<div class="flex flex-col gap-0.5">
					<dt class="text-sm font-semibold text-gray-900"><?php esc_html_e( 'Payout email', 'affiliate-wp' ); ?></dt>
					<dd class="text-sm text-gray-700 break-all select-all"
						x-text="drawer.payout.payout_email || drawer.payout.affiliate_email"></dd>
				</div>
			</template>

			<div class="flex flex-col gap-0.5">
				<dt class="text-sm font-semibold text-gray-900"><?php esc_html_e( 'Payout method', 'affiliate-wp' ); ?></dt>
				<?php
				/*
				 * Uses payout_method_label (properly-cased "PayPal" etc.)
				 * rather than the slug + CSS capitalize hack.
				 *
				 * The Stripe rail rides along in brackets — "Stripe (Global
				 * Payouts)" — rather than as its own row: the method reads
				 * plainly "Stripe" for both rails, and the rail only ever
				 * qualifies that one value, so it belongs with it. Only the
				 * Global rail is marked (unmarked Stripe is Connect), which
				 * is enough for the admin to reconcile / handle 1099s. The
				 * bracket is appended here, NOT baked into
				 * payout_method_label — that label also drives the "Stripe
				 * fees" row below and both list tables.
				 */
				?>
				<dd class="text-sm text-gray-700">
					<span x-text="drawer.payout.payout_method_label || '—'"></span><template x-if="drawer.payout.stripe_rail_label"><span x-text="' (' + drawer.payout.stripe_rail_label + ')'"></span></template>
				</dd>
			</div>

			<?php
			/*
			 * Row-created stamp. The Timeline already has sent / paid.
			 * Those can disagree with this value (Stripe clock vs WP
			 * row). Keep the row only when there is no rail.
			 */
			?>
			<template x-if="! ( drawer.payout.timeline && drawer.payout.timeline.length )">
				<div class="flex flex-col gap-0.5">
					<dt class="text-sm font-semibold text-gray-900"><?php esc_html_e( 'Payout date', 'affiliate-wp' ); ?></dt>
					<dd class="text-sm text-gray-700" x-text="drawer.payout.date_formatted"></dd>
				</div>
			</template>

			<?php
			/*
			 * Delivery method, Global rail only. Stripe shows the method on the RECIPIENT page,
			 * never the payout, so an admin asking "why is this taking four days?" would
			 * otherwise go looking. Label is Stripe's own ("Standard"/"Wire"); the row hides
			 * when empty, so Connect rows add nothing.
			 */
			?>
			<template x-if="drawer.payout.stripe_delivery_label">
				<div class="flex flex-col gap-0.5">
					<dt class="text-sm font-semibold text-gray-900"><?php esc_html_e( 'Delivery', 'affiliate-wp' ); ?></dt>
					<dd class="text-sm text-gray-700" x-text="drawer.payout.stripe_delivery_label"></dd>
				</div>
			</template>

			<?php
			/*
			 * Bank trace ID (Global rail). Stripe assigns it when the transfer posts, so the
			 * row appears only then. It's the reference the affiliate gives THEIR bank to
			 * locate the incoming transfer — the one recipient-side lookup that exists.
			 */
			?>
			<template x-if="drawer.payout.stripe_delivery_trace_id">
				<div class="flex flex-col gap-0.5">
					<dt class="text-sm font-semibold text-gray-900"><?php esc_html_e( 'Bank trace ID', 'affiliate-wp' ); ?></dt>
					<dd class="text-sm text-gray-700 break-all" x-text="drawer.payout.stripe_delivery_trace_id"></dd>
				</div>
			</template>

			<?php
			/*
			 * Provider fees row. Label is method-named ("PayPal fees" /
			 * "Stripe fees") so the provider is explicit — "Total fees"
			 * on its own didn't say WHO charged or WHO paid. The fees
			 * are deducted from the site owner's provider balance when
			 * the payout is sent (affiliate's payout amount is gross,
			 * not net of fees), but that's implicit in the admin-panel
			 * context. Title attribute spells it out for hover.
			 *
			 * Hidden when no fee data is recorded (manual / store-
			 * credit / Stripe-before-transfer cases) so the row doesn't
			 * render "—" needlessly. The Global rail cannot produce a
			 * number (fee transactions carry no payment reference); that
			 * case is a "View in Stripe" action above, not a hollow
			 * "Fee breakdown" row here.
			 */
			?>
			<template x-if="drawer.payout.total_fees_formatted">
				<div class="flex flex-col gap-0.5">
					<dt class="text-sm font-semibold text-gray-900"
						:title="'Charged to your ' + ( drawer.payout.payout_method_label || 'provider' ) + ' account when this payout was sent.'">
						<span x-text="( drawer.payout.payout_method_label || '' ) + ' '"></span><?php esc_html_e( 'fees', 'affiliate-wp' ); ?>
					</dt>
					<dd class="text-sm text-gray-700" x-text="drawer.payout.total_fees_formatted"></dd>
				</div>
			</template>

			<?php
			/*
			 * PayPal bookkeeping. These IDs used to live on a method card
			 * at the top of the drawer. They are facts, not a story, so
			 * they sit with the other stacked metadata. Sender batch ID
			 * is our idempotency key (no PayPal batch ID yet). PayPal
			 * batch ID is what PayPal assigned after it accepted the
			 * submission. Both render as copyable text — PayPal has no
			 * stable per-batch UI URL, so a link would lie.
			 */
			?>
			<template x-if="drawer.payout.stripe_conflict_transfer_id">
				<div class="flex flex-col gap-0.5">
					<dt class="text-sm font-semibold text-gray-900"><?php esc_html_e( 'Stripe transfer', 'affiliate-wp' ); ?></dt>
					<dd class="text-sm text-gray-700">
						<template x-if="drawer.payout.stripe_conflict_transfer_url">
							<a :href="drawer.payout.stripe_conflict_transfer_url"
								target="_blank"
								rel="noopener noreferrer"
								class="font-mono text-xs text-affwp-link hover:text-affwp-link-hover break-all select-all"
								x-text="drawer.payout.stripe_conflict_transfer_id"></a>
						</template>
						<template x-if="! drawer.payout.stripe_conflict_transfer_url">
							<span class="font-mono text-xs select-all wrap-anywhere"
								x-text="drawer.payout.stripe_conflict_transfer_id"></span>
						</template>
					</dd>
				</div>
			</template>

			<template x-if="drawer.paypalData && drawer.paypalData.sender_batch_id">
				<div class="flex flex-col gap-0.5">
					<dt class="text-sm font-semibold text-gray-900"><?php esc_html_e( 'Sender batch ID', 'affiliate-wp' ); ?></dt>
					<dd class="text-sm text-gray-700 font-mono text-xs select-all wrap-anywhere" x-text="drawer.paypalData.sender_batch_id"></dd>
				</div>
			</template>

			<template x-if="drawer.paypalData && drawer.paypalData.paypal_batch_id">
				<div class="flex flex-col gap-0.5">
					<dt class="text-sm font-semibold text-gray-900"><?php esc_html_e( 'PayPal batch ID', 'affiliate-wp' ); ?></dt>
					<dd class="text-sm text-gray-700 font-mono text-xs select-all" x-text="drawer.paypalData.paypal_batch_id"></dd>
				</div>
			</template>

			<template x-if="drawer.paypalData && drawer.paypalData.last_checked_human">
				<div class="flex flex-col gap-0.5">
					<?php
					/*
					 * "Last checked" alone is ambiguous: admin reads it as
					 * "we last checked the affiliate's PayPal email." It's
					 * actually "our system last polled PayPal's API to ask
					 * for the batch's current status." Disambiguated label:
					 * "PayPal status checked" puts the object of the check
					 * (PayPal's API status response) in the label itself.
					 */
					?>
					<dt class="text-sm font-semibold text-gray-900"><?php esc_html_e( 'PayPal status checked', 'affiliate-wp' ); ?></dt>
					<dd class="flex flex-wrap items-center gap-2 text-sm text-gray-700">
						<span x-text="drawer.paypalData.last_checked_human + ' (' + (drawer.paypalData.poll_count || 0) + ' check' + ((drawer.paypalData.poll_count || 0) === 1 ? '' : 's') + ')'"></span>
						<template x-if="drawer.isProcessing">
							<button type="button"
								@click="drawer.checkStatus()"
								:disabled="drawer.isChecking"
								class="cursor-pointer bg-transparent border-0 p-0 font-medium text-affwp-link hover:text-affwp-link-hover focus:outline-none focus-visible:underline rounded disabled:opacity-50 disabled:cursor-not-allowed">
								<span x-text="drawer.isChecking ? '<?php echo esc_js( __( 'Checking…', 'affiliate-wp' ) ); ?>' : '<?php echo esc_js( __( 'Check now', 'affiliate-wp' ) ); ?>'"></span>
							</button>
						</template>
					</dd>
				</div>
			</template>

			<?php
			/*
			 * Raw failure reason for power users. Most admins read the
			 * Next Steps card and never need this string. The minority
			 * debugging an unfamiliar failure mode (or filing a support
			 * ticket) can copy the verbatim error here.
			 *
			 * D20: the row used to render the raw PayPal JSON blob
			 * verbatim, which broke the layout (long unbroken strings)
			 * and read as hostile to admins. Now mirrors the Summary
			 * card: a parsed headline (paypalData.error_headline /
			 * payout.error_message) on the row, and the structured
			 * payload tucked into a sibling `<details>` block for
			 * support investigations. `wrap-anywhere` + `break-words`
			 * are required because JSON has no natural break points.
			 */
			?>
			<?php
			/*
			 * The Error row stands down when the failure card already leads with the same message — one
			 * failure, one sentence, one place. The raw-payload expander below is separate data and stays.
			 */
			?>
			<template x-if="drawer.isFailed && ! ( drawer.payout.next_steps && drawer.payout.next_steps.provider_message ) && ( ( drawer.paypalData && ( drawer.paypalData.error_headline || drawer.paypalData.error ) ) || drawer.payout.error_message )">
				<div class="flex flex-col gap-0.5">
					<dt class="text-sm font-semibold text-gray-900"><?php esc_html_e( 'Error', 'affiliate-wp' ); ?></dt>
					<dd class="text-sm text-gray-700 break-words"
						style="overflow-wrap: anywhere; word-break: break-word;"
						x-text="( drawer.paypalData && ( drawer.paypalData.error_headline || drawer.paypalData.error ) ) || drawer.payout.error_message"></dd>
				</div>
			</template>

			<template x-if="drawer.isFailed && drawer.paypalData && drawer.paypalData.error_raw">
				<div class="flex flex-col gap-1">
					<template x-if="true">
						<details style="max-width: 100%;">
							<summary class="cursor-pointer text-gray-500 hover:text-gray-700 select-none"
								style="font-size: 11px;">
								<?php esc_html_e( 'Show raw provider response', 'affiliate-wp' ); ?>
							</summary>
							<pre class="mt-1 p-2 bg-gray-50 border border-gray-200 rounded text-gray-800 break-words select-all m-0"
								style="font-size: 11px; white-space: pre-wrap; overflow-wrap: anywhere; word-break: break-word; max-width: 100%;"
								x-text="drawer.paypalData.error_raw"></pre>
						</details>
					</template>
				</div>
			</template>

			<template x-if="drawer.payout.service_account">
				<div class="flex flex-col gap-0.5">
					<dt class="text-sm font-semibold text-gray-900"><?php esc_html_e( 'Payout account', 'affiliate-wp' ); ?></dt>
					<dd class="text-sm text-gray-700" x-text="drawer.payout.service_account"></dd>
				</div>
			</template>

			<template x-if="drawer.payout.service_invoice_link">
				<div class="flex flex-col gap-0.5">
					<dt class="text-sm font-semibold text-gray-900"><?php esc_html_e( 'Invoice link', 'affiliate-wp' ); ?></dt>
					<dd>
						<a :href="drawer.payout.service_invoice_link"
							target="_blank"
							rel="noopener noreferrer"
							class="text-affwp-link hover:text-affwp-link-hover break-all"
							x-text="drawer.payout.service_invoice_link"></a>
					</dd>
				</div>
			</template>

			</dl>
		</div>

	</section>
</template>

<?php
/*
 * Integrator-hook output (`affwp_edit_payout_top/end/bottom`) plus any
 * future core "extras" are captured server-side by the AJAX handler and
 * shipped in drawer.payout.details_extras_html. Rendered as a bare
 * vertical stack so the contributor chooses its own framing — emit
 * affwp_card() for a framed card, affwp_property_list() to add label/value
 * rows in the drawer's native stacked style, or affwp_data_table() for
 * tabular content. Legacy <tr>-only output from _end is auto-wrapped
 * server-side (see affwp_wrap_legacy_payout_end_rows) so unupdated addons
 * still render.
 */
?>
<template x-if="drawer.payout && drawer.payout.details_extras_html">
	<div class="space-y-3" x-html="drawer.payout.details_extras_html"></div>
</template>
