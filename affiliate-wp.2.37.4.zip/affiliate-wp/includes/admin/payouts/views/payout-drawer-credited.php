<?php
/**
 * Payout Drawer — What the affiliate receives, with the Stripe exits
 *
 * The converted amount is a money fact, not a delivery confirmation: it pairs with the
 * total in the header. On a failed payout the heading is "Would have received" so we
 * do not claim the affiliate got the money. Receipt/dashboard links live here because
 * they belong to that money fact — named links, not printed URLs.
 *
 * Expects the parent `x-data="{ drawer: $store.payoutDrawer }"` scope
 * (see drawer.php content_callback).
 *
 * @package     AffiliateWP
 * @subpackage  Admin/Payouts
 * @since       2.37.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>

<template x-if="drawer.payout && ( drawer.payout.stripe_delivery_credited || drawer.payout.stripe_delivery_receipt || drawer.payout.stripe_dashboard_url )">
	<div class="flex flex-col gap-4">
		<template x-if="drawer.payout.stripe_delivery_credited">
			<div class="flex flex-col gap-0.5">
				<span class="text-sm font-semibold text-gray-900">
					<template x-if="drawer.isFailed"><span><?php esc_html_e( 'Would have received', 'affiliate-wp' ); ?></span></template>
					<template x-if="! drawer.isFailed"><span><?php esc_html_e( 'Affiliate receives', 'affiliate-wp' ); ?></span></template>
				</span>
				<span>
					<span class="text-sm text-gray-700" x-text="drawer.payout.stripe_delivery_credited"></span>
					<template x-if="drawer.payout.stripe_delivery_fx_rate">
						<span class="block text-xs text-gray-500" x-text="drawer.payout.stripe_delivery_fx_rate"></span>
					</template>
				</span>
			</div>
		</template>
		<template x-if="drawer.payout.stripe_delivery_receipt || drawer.payout.stripe_dashboard_url">
			<div class="flex flex-wrap items-center gap-x-4 gap-y-1">
				<template x-if="drawer.payout.stripe_delivery_receipt">
					<a :href="drawer.payout.stripe_delivery_receipt"
						target="_blank"
						rel="noopener noreferrer"
						class="inline-flex items-center gap-1.5 text-sm text-affwp-link hover:text-affwp-link-hover"
						title="<?php echo esc_attr__( 'View receipt (opens in a new tab)', 'affiliate-wp' ); ?>">
						<span><?php esc_html_e( 'View receipt', 'affiliate-wp' ); ?></span>
						<svg class="w-3.5 h-3.5 shrink-0" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true"><path d="M11 3a1 1 0 100 2h2.586l-6.293 6.293a1 1 0 101.414 1.414L15 6.414V9a1 1 0 102 0V4a1 1 0 00-1-1h-5z"/><path d="M5 5a2 2 0 00-2 2v8a2 2 0 002 2h8a2 2 0 002-2v-3a1 1 0 10-2 0v3H5V7h3a1 1 0 000-2H5z"/></svg>
					</a>
				</template>
				<template x-if="drawer.payout.stripe_dashboard_url">
					<a :href="drawer.payout.stripe_dashboard_url"
						target="_blank"
						rel="noopener noreferrer"
						class="inline-flex items-center gap-1.5 text-sm text-affwp-link hover:text-affwp-link-hover"
						title="<?php echo esc_attr__( 'View in Stripe (opens in a new tab)', 'affiliate-wp' ); ?>">
						<span><?php esc_html_e( 'View in Stripe', 'affiliate-wp' ); ?></span>
						<svg class="w-3.5 h-3.5 shrink-0" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true"><path d="M11 3a1 1 0 100 2h2.586l-6.293 6.293a1 1 0 101.414 1.414L15 6.414V9a1 1 0 102 0V4a1 1 0 00-1-1h-5z"/><path d="M5 5a2 2 0 00-2 2v8a2 2 0 002 2h8a2 2 0 002-2v-3a1 1 0 10-2 0v3H5V7h3a1 1 0 000-2H5z"/></svg>
					</a>
				</template>
			</div>
		</template>
	</div>
</template>
