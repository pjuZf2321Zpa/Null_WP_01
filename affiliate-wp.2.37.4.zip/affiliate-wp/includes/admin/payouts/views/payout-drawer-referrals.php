<?php
/**
 * Payout Drawer — Referrals Section
 *
 * Invoice line items: always visible, never a card, never a disclosure.
 * Details already sits above this list, so length cannot hide the receipt.
 * A row is ID + amount. Status and transaction ID appear only when they
 * add a fact the header does not already state. Two or more rows close
 * with a Total that sums the visible amounts.
 *
 * Exception rows keep a status pill and, when the processor left a
 * reason, one muted line under the transaction ID. No banners, no
 * row washes — those restated the pills.
 *
 * Expects the parent `x-data="{ drawer: $store.payoutDrawer }"` scope
 * (see drawer.php content_callback).
 *
 * @package     AffiliateWP
 * @subpackage  Admin/Payouts
 * @since       2.33.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>

<template x-if="drawer.referrals && drawer.referrals.length > 0">
	<section class="flex flex-col gap-4">

		<h3 class="text-lg font-semibold text-gray-900 m-0"><?php esc_html_e( 'Referrals', 'affiliate-wp' ); ?></h3>

		<!--
			Click target is the #ID link, not the whole row. Transaction
			IDs stay selectable and the provider deep-link stays a real
			link. A stretched-link row would fight both.
		-->
		<div class="flex flex-col divide-y divide-gray-100">
			<template x-for="referral in drawer.referrals" :key="referral.referral_id">

				<article class="py-2">

					<div class="flex items-start gap-3">

						<div class="min-w-0 grow">
							<a :href="referral.edit_url"
								:aria-label="'Edit referral #' + referral.referral_id"
								class="text-sm text-affwp-link hover:text-affwp-link-hover"
								x-text="'#' + referral.referral_id"></a>

							<template x-if="referral.item_transaction_id && referral.item_transaction_url">
								<a :href="referral.item_transaction_url"
									target="_blank"
									rel="noopener noreferrer"
									class="mt-0.5 block text-xs font-mono text-gray-500 hover:text-gray-700 truncate"
									:title="referral.item_transaction_label"
									x-text="referral.item_transaction_id"></a>
							</template>

							<template x-if="referral.item_transaction_id && ! referral.item_transaction_url">
								<p class="mt-0.5 mb-0 text-xs font-mono text-gray-500 truncate"
									:title="referral.item_transaction_label"
									x-text="referral.item_transaction_id"></p>
							</template>

							<template x-if="drawer.referralWarningText( referral )">
								<p class="mt-0.5 mb-0 text-xs text-gray-500" x-text="drawer.referralWarningText( referral )"></p>
							</template>
						</div>

						<!--
							Status is exception-only. A paid payout of paid
							referrals already said Paid in the header. Show
							the lifecycle pill when it is not the implied
							status (paid on a paid payout, unpaid otherwise).
							Show the processor chip when it is not SUCCESS.
							Method name is already in Details — the pill
							is just Failed / Reversed / Unclaimed.
						-->
						<!--
							Two or more rows: reserved badge column then
							amount so figures share one right edge. A
							singleton only spends width on a pill that
							is actually showing.
						-->
						<div class="shrink-0 flex items-center justify-end gap-1.5"
							:class="drawer.referrals.length > 1 ? 'w-24' : ''"
							x-show="drawer.referrals.length > 1 || drawer.showReferralLifecycleStatus( referral ) || drawer.showReferralItemStatus( referral )">
							<template x-if="drawer.showReferralLifecycleStatus( referral )">
								<span :class="drawer.badgeClass( drawer.badgeVariantForReferralStatus( referral.status ) ) + ' capitalize'"
									:title="drawer.isSuperseded && drawer.payout.superseded_by_payout_id && referral.status === 'paid' ? 'Paid via the replacement payout #' + drawer.payout.superseded_by_payout_id : ''"
									x-text="referral.status"></span>
							</template>
							<template x-if="drawer.showReferralItemStatus( referral )">
								<span :class="drawer.badgeClass( drawer.badgeVariantForItemStatus( referral.item_status ) )"
									x-text="drawer.formatStatusLabel( referral.item_status )"></span>
							</template>
						</div>
						<span class="shrink-0 text-right text-sm text-gray-900 tabular-nums"
							:class="drawer.referrals.length > 1 ? 'w-24' : ''"
							x-text="referral.amount_formatted"></span>

					</div>

				</article>

			</template>

			<template x-if="drawer.showReferralsTotal">
				<div class="py-2 flex items-baseline gap-3">
					<span class="grow text-sm font-semibold text-gray-900"><?php esc_html_e( 'Total', 'affiliate-wp' ); ?></span>
					<span class="w-24 shrink-0" aria-hidden="true"></span>
					<span class="w-24 shrink-0 text-right text-sm font-semibold text-gray-900 tabular-nums" x-text="drawer.payout.referrals_total_formatted"></span>
				</div>
			</template>
		</div>

	</section>
</template>

<!--
	Empty state. Two flavors:

	  - The payout's `referrals` column points at IDs that don't exist
	    in the referrals table (deleted out from under the payout).
	    Surface the IDs so the admin sees "what was there got deleted"
	    rather than misreading the row as having never had referrals.
	    Common cause: an admin deletes a referral from the Referrals
	    list table after the payout was processed. The payout row stays
	    intact (it was Paid), the referral is gone.

	  - Genuinely no referrals on the payout row (created empty / all
	    cleared somehow). Fall back to the original copy.
-->
<template x-if="drawer.payout && drawer.referrals && drawer.referrals.length === 0">
	<section class="rounded-lg border border-dashed border-gray-200 bg-gray-50 px-5 py-6 text-center">
		<template x-if="drawer.payout.deleted_referral_ids && drawer.payout.deleted_referral_ids.length > 0">
			<div class="flex flex-col gap-1.5">
				<p class="text-sm font-medium text-gray-700 m-0">
					<span x-text="drawer.payout.deleted_referral_ids.length === 1 ? '<?php echo esc_js( __( 'Referral no longer exists', 'affiliate-wp' ) ); ?>' : '<?php echo esc_js( __( 'Referrals no longer exist', 'affiliate-wp' ) ); ?>'"></span>
				</p>
				<p class="text-xs text-gray-500 m-0">
					<span x-text="drawer.payout.deleted_referral_ids.map(function(id){return '#'+id}).join(', ')"></span>
					<span x-text="drawer.payout.deleted_referral_ids.length === 1 ? '<?php echo esc_js( __( 'was attached to this payout but has since been deleted.', 'affiliate-wp' ) ); ?>' : '<?php echo esc_js( __( 'were attached to this payout but have since been deleted.', 'affiliate-wp' ) ); ?>'"></span>
				</p>
			</div>
		</template>
		<template x-if="! drawer.payout.deleted_referral_ids || drawer.payout.deleted_referral_ids.length === 0">
			<p class="text-sm text-gray-500 m-0">
				<?php esc_html_e( 'No referrals are attached to this payout.', 'affiliate-wp' ); ?>
			</p>
		</template>
	</section>
</template>
