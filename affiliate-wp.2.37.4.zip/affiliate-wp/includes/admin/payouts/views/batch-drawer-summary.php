<?php
/**
 * Batch Drawer — Summary Card
 *
 * Batch-level metadata: progress counters, totals, creator, PayPal batch ID
 * when present. Mirrors the style of the payout drawer's Summary card so the
 * two drawers feel like one family.
 *
 * Expects the parent `x-data="{ drawer: $store.batchDrawer }"` scope.
 *
 * @package     AffiliateWP
 * @subpackage  Admin/Payouts
 * @since       2.33.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>
<template x-if="drawer.batch">
	<section class="space-y-4">

		<h3 class="text-lg font-semibold text-gray-900"><?php esc_html_e( 'Details', 'affiliate-wp' ); ?></h3>

		<dl class="flex flex-col gap-4">

			<div class="flex flex-col gap-0.5">
				<dt class="text-sm font-semibold text-gray-900"><?php esc_html_e( 'Progress', 'affiliate-wp' ); ?></dt>
				<!--
					Status breakdown as badges, so counts and state read together.
					Each is hidden at zero, so a healthy batch shows one green badge.
				-->
				<dd class="flex flex-wrap items-center gap-1.5">
					<template x-if="drawer.batch.processed_count > 0">
						<span :class="drawer.batch.badge_class_paid"
							x-text="drawer.batch.processed_count + ' <?php echo esc_js( __( 'paid', 'affiliate-wp' ) ); ?>'"></span>
					</template>
					<template x-if="(drawer.batch.total_count - drawer.batch.processed_count - drawer.batch.failed_count) > 0">
						<span :class="drawer.batch.badge_class_pending"
							x-text="(drawer.batch.total_count - drawer.batch.processed_count - drawer.batch.failed_count) + ' <?php echo esc_js( __( 'pending', 'affiliate-wp' ) ); ?>'"></span>
					</template>
					<template x-if="drawer.batch.failed_count > 0">
						<span :class="drawer.batch.badge_class_failed"
							x-text="drawer.batch.failed_count + ' <?php echo esc_js( __( 'failed', 'affiliate-wp' ) ); ?>'"></span>
					</template>
				</dd>
			</div>

			<div class="flex flex-col gap-0.5">
				<dt class="text-sm font-semibold text-gray-900"><?php esc_html_e( 'Method', 'affiliate-wp' ); ?></dt>
				<!--
					For mixed batches, show the per-method breakdown below the
					main label on its own muted line so the opaque "Mixed"
					string becomes actionable context at a glance.
				-->
				<dd>
					<span class="text-sm text-gray-700" x-text="drawer.batch.payout_method_label"></span>
					<template x-if="drawer.batch.method_breakdown">
						<span class="block text-xs text-gray-500" x-text="drawer.batch.method_breakdown"></span>
					</template>
				</dd>
			</div>

			<div class="flex flex-col gap-0.5">
				<dt class="text-sm font-semibold text-gray-900"><?php esc_html_e( 'Generated', 'affiliate-wp' ); ?></dt>
				<dd class="text-sm text-gray-700" x-text="drawer.batch.generated_label"></dd>
			</div>

			<?php
			/*
			 * Provenance for automatic runs; schedule_url is empty when the
			 * schedule was deleted. min-w-0 + truncate: long names otherwise
			 * stretch the row (255 chars max); the title carries the full name.
			 */
			?>
			<template x-if="drawer.batch.schedule_label">
				<div class="flex flex-col gap-0.5">
					<dt class="text-sm font-semibold text-gray-900"><?php esc_html_e( 'Schedule', 'affiliate-wp' ); ?></dt>
					<dd class="min-w-0 truncate text-sm text-gray-700" :title="drawer.batch.schedule_label">
						<template x-if="drawer.batch.schedule_url">
							<a :href="drawer.batch.schedule_url"
								class="text-affwp-link hover:text-affwp-link-hover"
								x-text="drawer.batch.schedule_label"></a>
						</template>
						<template x-if="! drawer.batch.schedule_url">
							<span x-text="drawer.batch.schedule_label"></span>
						</template>
					</dd>
				</div>
			</template>

			<template x-if="drawer.batch.provider_batch_id">
				<div class="flex flex-col gap-0.5">
					<dt class="text-sm font-semibold text-gray-900"><?php esc_html_e( 'PayPal Batch ID', 'affiliate-wp' ); ?></dt>
					<dd class="flex items-center gap-2 font-mono text-xs text-gray-700">
						<span x-text="drawer.batch.provider_batch_id"></span>
						<template x-if="drawer.batch.provider_dashboard_url">
							<a :href="drawer.batch.provider_dashboard_url"
								target="_blank"
								rel="noopener noreferrer"
								class="text-affwp-link hover:text-affwp-link-hover"
								title="<?php echo esc_attr__( 'Open in PayPal (new tab)', 'affiliate-wp' ); ?>">
								<span class="sr-only"><?php esc_html_e( 'Open in PayPal', 'affiliate-wp' ); ?></span>
								<svg class="w-3.5 h-3.5 inline" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true"><path d="M11 3a1 1 0 100 2h2.586l-6.293 6.293a1 1 0 101.414 1.414L15 6.414V9a1 1 0 102 0V4a1 1 0 00-1-1h-5z"/><path d="M5 5a2 2 0 00-2 2v8a2 2 0 002 2h8a2 2 0 002-2v-3a1 1 0 10-2 0v3H5V7h3a1 1 0 000-2H5z"/></svg>
							</a>
						</template>
					</dd>
				</div>
			</template>

		</dl>

		<?php
		/*
		 * Manual-payout file, bound to the Summary card as the direct consequence of
		 * Method = Manual. The drawer auto-downloads it once on batch completion (see
		 * affwp-batch-drawer.js); this button covers re-downloads, regenerated on demand.
		 */
		?>
		<template x-if="drawer.batch.csv_download_url">
			<div class="flex flex-col gap-2">
				<a :href="drawer.batch.csv_download_url"
					class="cursor-pointer inline-flex w-fit items-center rounded-md border border-transparent bg-affwp-brand-500 px-3 py-1.5 text-sm font-medium text-white shadow-sm hover:bg-affwp-brand-600 focus:outline-none focus-visible:ring-2 focus-visible:ring-affwp-brand-500 focus-visible:ring-offset-2 transition-colors">
					<?php esc_html_e( 'Download CSV', 'affiliate-wp' ); ?>
				</a>
				<p class="m-0 text-xs text-gray-500" x-text="drawer.batch.csv_scope_label"></p>
			</div>
		</template>
	</section>
</template>
