<?php
/**
 * Payout Drawer — Footer
 *
 * Drastically simplified in 2.33.0:
 *
 *   - Retry Payout button removed: it was disabled for the majority of
 *     failures (everything non-transient) and the disabled state lied
 *     about what would happen if you clicked it. Retry now lives inside
 *     the Next Steps card as a class-aware primary action, only present
 *     when retry would actually succeed.
 *   - Switch method picker removed: relocated into the Next Steps card
 *     as a secondary ghost link beneath the primary CTA. Pairs the
 *     resolution paths together rather than splitting them across two
 *     surfaces.
 *
 * What remains: a single right-slot button whose label is state-driven.
 *   - Processing payout → Check Status (resumes the long-poll the
 *     drawer would otherwise need a refresh to trigger).
 *   - Anything else (failed, paid, superseded, etc.) → Close.
 *
 * @package     AffiliateWP
 * @subpackage  Admin/Payouts
 * @since       2.33.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>

<div class="flex items-center justify-end"
	x-data="{ get drawer() { return $store.payoutDrawer; } }">

	<!--
		Footer is always just Close. The "Check Status" primary that used
		to live here for processing payouts implied that polling PayPal was
		the drawer's primary action — but the actual primary path is
		either (a) the Next Steps card's email-affiliate action when the
		payout is stuck on affiliate-side action, or (b) waiting for the
		system's automatic polling to land. Manual Check Status survives
		as an inline "Check now" link inside the Summary card (see
		payout-drawer-summary.php) for admins who want to force a poll.
	-->
	<button type="button"
		@click="drawer.close()"
		class="cursor-pointer inline-flex items-center rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus-visible:ring-2 focus-visible:ring-affwp-brand-500 focus-visible:ring-offset-2 transition-colors">
		<?php esc_html_e( 'Close', 'affiliate-wp' ); ?>
	</button>

</div>
