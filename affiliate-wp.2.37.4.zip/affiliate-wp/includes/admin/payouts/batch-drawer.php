<?php
/**
 * Batch Detail Drawer
 *
 * Renders the batch drawer shell. Alpine store + row-click intercept live in
 * `assets/js/affwp-batch-drawer.js`. PHP-computed data (nonce, ajax URL, list
 * URL) hands through `wp_localize_script()`. Guarded so the markup emits
 * once per request.
 *
 * Mirrors the payout drawer contract (see drawer.php).
 *
 * @package     AffiliateWP
 * @subpackage  Admin/Payouts
 * @copyright   Copyright (c) 2026, Sandhills Development, LLC
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.33.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Render the batch detail drawer markup.
 *
 * @since 2.33.0
 */
function affwp_render_batch_drawer() {

	static $rendered = false;

	if ( $rendered ) {
		return;
	}

	$rendered = true;

	affwp_drawer( [
		'id'                   => 'batch-drawer',
		'alpine_store'         => 'batchDrawer',
		'width'                => '2xl',
		'header_style'         => 'flat',
		'close_on_backdrop'    => true,
		'close_on_escape'      => true,
		'loading_x_show'       => '$store.batchDrawer.isLoading && ! $store.batchDrawer.batch',
		'header_callback'   => function () {
			require __DIR__ . '/views/batch-drawer-header.php';
		},
		'content_callback'  => function () {
			?>
			<div x-data="{ get drawer() { return $store.batchDrawer; } }"
				class="flex flex-col gap-12 transition-opacity duration-200"
				:class="{ 'opacity-60': drawer.isNavigating }">
				<?php
				require __DIR__ . '/views/batch-drawer-summary.php';
				require __DIR__ . '/views/batch-drawer-payouts.php';
				?>
			</div>
			<?php
		},
		'footer_callback'   => function () {
			require __DIR__ . '/views/batch-drawer-footer.php';
		},
		/*
		 * Footer band only renders when there's a caption to display.
		 * Captions live in modes that carry unique system-state info
		 * (Processing safe-to-close, Self-healing "affiliates notified",
		 * Mixed breakdown). On Done/clean and pure needs-review batches
		 * the band is suppressed entirely. X-icon and Escape own close.
		 */
		'footer_x_show'     => '$store.batchDrawer.batch && $store.batchDrawer.batch.footer_caption',
	] );

	// Toasts are safe to call multiple times (self-guarded).
	affwp_toast();
}
