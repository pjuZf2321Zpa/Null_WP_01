<?php
/**
 * Admin: Preview Payout View
 *
 * @package    AffiliateWP
 * @subpackage Admin/Payouts
 * @copyright  Copyright (c) 2019, Sandhills Development, LLC
 * @license    http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since      2.4
 */

// Multi-select inputs (2.33.0+). Each accepts an array of IDs/keys.
$include_affiliates    = isset( $_REQUEST['include_affiliates'] ) && is_array( $_REQUEST['include_affiliates'] )
	? array_values( array_filter( array_map( 'absint', $_REQUEST['include_affiliates'] ) ) )
	: array();
$include_groups        = isset( $_REQUEST['include_groups'] ) && is_array( $_REQUEST['include_groups'] )
	? array_values( array_filter( array_map( 'absint', $_REQUEST['include_groups'] ) ) )
	: array();
$payout_methods_filter = isset( $_REQUEST['payout_methods'] ) && is_array( $_REQUEST['payout_methods'] )
	? array_values( array_filter( array_map( 'sanitize_key', $_REQUEST['payout_methods'] ) ) )
	: array();

$start = ! empty( $_REQUEST['from'] ) ? sanitize_text_field( $_REQUEST['from'] ) : false;
$end   = ! empty( $_REQUEST['to'] ) ? sanitize_text_field( $_REQUEST['to'] ) : false;

// Legacy single-affiliate field — only used when the new arrays are empty.
$user_name = ! empty( $_REQUEST['user_name'] ) ? sanitize_text_field( $_REQUEST['user_name'] ) : false;
if ( $user_name && empty( $include_affiliates ) ) {
	$legacy_affiliate = affwp_get_affiliate( $user_name );
	if ( $legacy_affiliate ) {
		$include_affiliates[] = (int) $legacy_affiliate->ID;
	}
}

/*
 * Plural `payout_methods[]` (the canonical 2.33.0+ input from the chips) always means filter by
 * each affiliate's configured method, never a batch-level override.
 *
 * Singular `payout_method` is the legacy entry point (custom integrations, saved bookmarks,
 * older addons). It still means override: fire the per-method addon hooks and treat the whole
 * batch as that method. We only honor it when the plural array is absent, so a new-form
 * submission with one chip selected stays in filter mode.
 */
$legacy_method = ( empty( $payout_methods_filter ) && ! empty( $_REQUEST['payout_method'] ) )
	? strtolower( sanitize_text_field( $_REQUEST['payout_method'] ) )
	: '';

if ( '' !== $legacy_method ) {
	$payout_method         = array_key_exists( $legacy_method, affwp_get_payout_methods() ) ? $legacy_method : 'manual';
	$per_affiliate_routing = false;
} else {
	$payout_method         = '';
	$per_affiliate_routing = true;
}

$payout_method_label = $per_affiliate_routing
	? __( "Each affiliate's configured method", 'affiliate-wp' )
	: affwp_get_payout_method_display_label( $payout_method );

$include_scope = affwp_get_payout_include_affiliate_ids(
	array(
		'include_affiliates' => $include_affiliates,
		'include_groups'     => $include_groups,
		'user_name'          => $user_name,
	)
);

// A selection that matches no affiliate (an empty group) previews no one, as the payout pays no one: no affiliate has ID 0.
$affiliate_id_filter = false === $include_scope ? array() : ( $include_scope ? $include_scope : array( 0 ) );
$affiliate_id_arg    = ! empty( $affiliate_id_filter ) ? $affiliate_id_filter : false;

// The minimum payout amount.
$minimum = ! empty( $_REQUEST['minimum'] ) ? sanitize_text_field( affwp_sanitize_amount( $_REQUEST['minimum'] ) ) : 0;

$bypass_holding = absint( filter_input( INPUT_GET, 'bypass_holding', FILTER_SANITIZE_NUMBER_INT ) );

$preview_data = affwp_build_payout_preview_data(
	array(
		'affiliate_id'          => $affiliate_id_arg,
		'date'                  => array(
			'start' => $start,
			'end'   => $end,
		),
		'minimum'               => (float) $minimum,
		'bypass_holding'        => (bool) $bypass_holding,
		'apply_addon_filters'   => true,
		/*
		 * 'id' (integer IDs) instead of 'full' (4-key arrays per referral). The only render-site
		 * consumer is `count( $payout['referrals'] )` in affwp_render_preview_payout_row(), which works
		 * on either shape. 'full' would attach date_i18n() and wp_trim_words() per referral on every
		 * page load, a hot path on large datasets.
		 */
		'referral_shape'        => 'id',
		'per_affiliate_routing' => $per_affiliate_routing,
		'payout_method'         => $payout_method,
		'method_filter'         => $payout_methods_filter,
	)
);

$payouts             = $preview_data['payouts'];
$invalid_affiliates  = $preview_data['invalid_affiliates'];
$referrals_total     = $preview_data['referrals_total'];
$payouts_by_method   = $preview_data['payouts_by_method'];
$payouts_count       = $preview_data['payouts_count'];
$going_out_total     = $preview_data['going_out_total'];
$going_out_count     = $preview_data['going_out_count'];
$grand_ready_count   = $preview_data['grand_ready_count'];
$grand_invite_count  = $preview_data['grand_invite_count'];
$grand_blocked_count = $preview_data['grand_blocked_count'];
$grand_blocked_total = $preview_data['grand_blocked_total'];

// Per-method liquidity pre-flight (Stripe balance). Shared with the bulk-pay drawer.
$method_warnings = affwp_get_payout_preview_method_warnings( $payouts_by_method );

// $method_warnings maps a method key to a LIST of warnings (a shared "stripe" group can carry
// both a blocking Connect-balance warning and an amber Global-balance one), so scan each list.
$has_blocking_warning = false;
foreach ( $method_warnings as $warnings ) {
	foreach ( (array) $warnings as $w ) {
		if ( isset( $w['severity'] ) && 'blocking' === $w['severity'] ) {
			$has_blocking_warning = true;
			break 2;
		}
	}
}

/*
 * First-row cap before the "Show more" expander kicks in. A section at or under the cap (plus a
 * few rows of `$preview_row_snap` headroom) renders in full with no button; a larger section
 * starts with this many rows server-rendered and loads the rest on demand via AJAX in batches of
 * `$method_load_more_batch`. Capping the initial render avoids a multi-second freeze on large
 * datasets where Alpine init over tens of thousands of hidden DOM nodes blocks the main thread.
 */
$method_row_cap         = 25;
$method_load_more_batch = 100;

// Same cap for the "Cannot be paid this run" section, which previously rendered every invalid affiliate up-front (unbounded).
$invalid_row_cap         = 25;
$invalid_load_more_batch = 100;

// Render a section in full when at most this many rows would otherwise hide behind the button.
$preview_row_snap = 3;

$invalid_count = count( $invalid_affiliates );

// Prefetch all server-rendered affiliates in a single query, cutting the initial render from N+1 to roughly two queries (affiliates table plus users via cache_users()).
$initial_render_ids = array();
foreach ( $payouts_by_method as $m ) {
	$visible_count      = affwp_get_preview_visible_count( count( $m['payouts'] ), $method_row_cap, $preview_row_snap );
	$visible_for_method = array_slice( $m['payouts'], 0, $visible_count, true );
	foreach ( array_keys( $visible_for_method ) as $aid ) {
		$initial_render_ids[] = (int) $aid;
	}
}
$initial_invalid_count = affwp_get_preview_visible_count( count( $invalid_affiliates ), $invalid_row_cap, $preview_row_snap );
$initial_invalid_ids   = array_slice( array_keys( $invalid_affiliates ), 0, $initial_invalid_count, true );
$preview_lookup        = affwp_preload_preview_payout_affiliates(
	array_merge( $initial_render_ids, $initial_invalid_ids )
);

$start_display = $start ? affwp_date_i18n( strtotime( $start ) ) : __( 'Earliest unpaid', 'affiliate-wp' );
$end_display   = $end ? affwp_date_i18n( strtotime( $end ) ) : affwp_date_i18n( strtotime( gmdate( 'm/d/Y' ) ) );

$edit_filters_args = array( 'action' => 'new_payout' );

if ( $start ) {
	$edit_filters_args['from'] = $start;
}
if ( $end ) {
	$edit_filters_args['to'] = $end;
}
if ( $user_name ) {
	$edit_filters_args['user_name'] = $user_name;
}
if ( ! empty( $include_affiliates ) ) {
	$edit_filters_args['include_affiliates'] = $include_affiliates;
}
if ( ! empty( $include_groups ) ) {
	$edit_filters_args['include_groups'] = $include_groups;
}
if ( ! empty( $payout_methods_filter ) ) {
	$edit_filters_args['payout_methods'] = $payout_methods_filter;
}
if ( '' !== $legacy_method ) {
	$edit_filters_args['payout_method'] = $legacy_method;
}
if ( $minimum ) {
	$edit_filters_args['minimum'] = $minimum;
}
if ( $bypass_holding ) {
	$edit_filters_args['bypass_holding'] = 1;
}

$edit_filters_url = affwp_admin_url( 'payouts', $edit_filters_args );

$async_capable = $per_affiliate_routing || 'manual' === $payout_method;
?>

<div class="wrap affwp-payout-page">

	<div class="affwp-ui">

		<header class="my-6 max-w-5xl flex flex-wrap items-end justify-between gap-6">
			<div>
				<?php
				/*
				 * Step rail: numbered indicator that previews the two-step flow at a glance.
				 * Step 1 (Configure) is checked-out and gray. Step 2 (Preview) is current —
				 * filled brand circle, brand-colored label.
				 */
				?>
				<nav aria-label="<?php esc_attr_e( 'Payout steps', 'affiliate-wp' ); ?>" class="inline-flex items-center gap-3 text-xs font-semibold uppercase tracking-wide">
					<a href="<?php echo esc_url( $edit_filters_url ); ?>" class="group inline-flex items-center gap-1.5 text-gray-500 hover:text-gray-900 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-affwp-brand-500 rounded-sm">
						<span class="inline-flex size-5 items-center justify-center rounded-full ring-1 ring-gray-300 text-[11px] font-bold leading-5 tabular-nums group-hover:ring-gray-400">1</span>
						<?php esc_html_e( 'Configure', 'affiliate-wp' ); ?>
					</a>
					<span class="text-gray-300" aria-hidden="true">→</span>
					<span class="inline-flex items-center gap-1.5 text-affwp-brand-700">
						<span aria-current="step" class="inline-flex size-5 items-center justify-center rounded-full bg-affwp-brand-500 text-white text-[11px] font-bold leading-5 tabular-nums">2</span>
						<?php esc_html_e( 'Preview', 'affiliate-wp' ); ?>
					</span>
				</nav>
				<h1 class="mt-3 text-3xl font-semibold tracking-tight m-0">
					<?php
					if ( $payouts_count > 0 ) {
						printf(
							esc_html(
								/* translators: %d: number of affiliates to be paid */
								_n( 'Pay %d affiliate', 'Pay %d affiliates', $payouts_count, 'affiliate-wp' )
							),
							(int) $payouts_count
						);
					} else {
						esc_html_e( 'Preview payout', 'affiliate-wp' );
					}
					?>
				</h1>
				<?php
				/*
				 * Filter summary: the commission window this payout covers, muted under
				 * the heading (a caption, not a control). "Edit" returns to step 1 — the
				 * same target as the Configure step in the rail above. "Save as schedule"
				 * now lives in the action bar beside "Pay affiliates", where the two
				 * commit choices belong together.
				 */
				?>
				<p class="mt-2 m-0 text-sm/6 text-gray-500">
					<?php
					echo esc_html(
						sprintf(
							/* translators: 1: commission period start, 2: commission period end */
							__( 'Commissions %1$s → %2$s', 'affiliate-wp' ),
							$start_display,
							$end_display
						)
					);
					?>
					<span class="mx-1 text-gray-300" aria-hidden="true">·</span>
					<a href="<?php echo esc_url( $edit_filters_url ); ?>" class="font-medium text-affwp-link hover:text-affwp-link-hover"><?php esc_html_e( 'Edit', 'affiliate-wp' ); ?></a>
				</p>
			</div>
		</header>

		<?php if ( ! empty( $payouts ) ) : ?>

			<?php
			echo affwp_render_payout_preview_body(
				$preview_data,
				array(
					'context'                 => 'page',
					'deep_link'               => true,
					'row_cap'                 => $method_row_cap,
					'load_more_batch'         => $method_load_more_batch,
					'invalid_row_cap'         => $invalid_row_cap,
					'row_snap'                => $preview_row_snap,
					'load_more'               => true,
					'method_warnings'         => $method_warnings,
					'lookup'                  => $preview_lookup,
					'after_total_hook_method' => $payout_method,
				)
			); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- renderer outputs escaped markup.
			?>

		<?php else : ?>

			<?php
			/*
			 * Stuck-referrals hint: when nothing's eligible and no invalid set, explain the empty
			 * result. Failed payouts get the actionable amber notice; in-flight (processing) payouts
			 * get a quiet informational line — money already moving, nothing to resolve.
			 */
			$stuck_referrals_count     = 0;
			$stuck_payouts_count       = 0;
			$in_flight_referrals_count = 0;
			$in_flight_payouts_count   = 0;
			if ( empty( $payouts ) && empty( $invalid_affiliates ) ) {
				global $wpdb;
				$referrals_table = affiliate_wp()->referrals->table_name;
				$payouts_table   = affiliate_wp()->affiliates->payouts->table_name;

				$where  = array( 'r.status = %s', 'r.payout_id != 0', 'p.status IN (%s, %s)' );
				$params = array( 'unpaid', 'processing', 'failed' );

				if ( ! empty( $affiliate_id_filter ) ) {
					$placeholders = implode( ',', array_fill( 0, count( $affiliate_id_filter ), '%d' ) );
					$where[]      = "r.affiliate_id IN ({$placeholders})";
					foreach ( $affiliate_id_filter as $aid ) {
						$params[] = (int) $aid;
					}
				}

				if ( ! empty( $start ) ) {
					$where[]  = 'r.date >= %s';
					$params[] = gmdate( 'Y-m-d 00:00:00', strtotime( $start ) );
				}

				if ( ! empty( $end ) ) {
					$where[]  = 'r.date <= %s';
					$params[] = gmdate( 'Y-m-d 23:59:59', strtotime( $end ) );
				}

				$sql = sprintf(
					"SELECT SUM( p.status = 'failed' ) AS stuck_referrals, COUNT( DISTINCT CASE WHEN p.status = 'failed' THEN r.payout_id END ) AS stuck_payouts, SUM( p.status = 'processing' ) AS in_flight_referrals, COUNT( DISTINCT CASE WHEN p.status = 'processing' THEN r.payout_id END ) AS in_flight_payouts FROM %s r INNER JOIN %s p ON r.payout_id = p.payout_id WHERE %s",
					$referrals_table,
					$payouts_table,
					implode( ' AND ', $where )
				);

				$row = $wpdb->get_row(
					// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table names hard-coded; param placeholders bound below.
					$wpdb->prepare( $sql, $params )
				);

				if ( $row ) {
					$stuck_referrals_count     = (int) $row->stuck_referrals;
					$stuck_payouts_count       = (int) $row->stuck_payouts;
					$in_flight_referrals_count = (int) $row->in_flight_referrals;
					$in_flight_payouts_count   = (int) $row->in_flight_payouts;
				}
			}
			?>

			<?php if ( $stuck_referrals_count > 0 ) : ?>
				<?php
				$stuck_payouts_url_args = array( 'status' => 'failed' );
				// Propagate the single-affiliate filter when applicable; the list table only accepts one.
				if ( count( $affiliate_id_filter ) === 1 ) {
					$stuck_payouts_url_args['affiliate_id'] = (int) $affiliate_id_filter[0];
				}
				$stuck_payouts_url = affwp_admin_url( 'payouts', $stuck_payouts_url_args );
				?>
				<div class="max-w-5xl mb-4 rounded-md bg-amber-50 ring-1 ring-amber-200 px-4 py-3 text-sm/6 text-amber-900">
					<p class="m-0">
						<strong>
							<?php
							printf(
								esc_html(
									/* translators: 1: number of stuck referrals, 2: number of failed payouts */
									_n(
										'%1$d referral is stuck in %2$d failed payout.',
										'%1$d referrals are stuck in %2$d failed payouts.',
										$stuck_referrals_count,
										'affiliate-wp'
									)
								),
								(int) $stuck_referrals_count,
								(int) $stuck_payouts_count
							);
							?>
						</strong>
						<?php
						printf(
							/* translators: %s: link to the Payouts list filtered by failed status */
							wp_kses(
								__( 'Resolve them from the <a href="%s">Payouts list</a> to free them for the next batch.', 'affiliate-wp' ),
								array( 'a' => array( 'href' => array() ) )
							),
							esc_url( $stuck_payouts_url )
						);
						?>
					</p>
				</div>
			<?php endif; ?>

			<?php if ( $in_flight_referrals_count > 0 ) : ?>
				<div class="max-w-5xl mb-4 rounded-md bg-gray-50 ring-1 ring-gray-200 px-4 py-3 text-sm/6 text-gray-700">
					<p class="m-0">
						<?php
						printf(
							esc_html(
								/* translators: 1: number of referrals, 2: number of processing payouts */
								_n(
									'%1$d referral is already in %2$d payout that is still processing.',
									'%1$d referrals are already in %2$d payouts that are still processing.',
									$in_flight_referrals_count,
									'affiliate-wp'
								)
							),
							(int) $in_flight_referrals_count,
							(int) $in_flight_payouts_count
						);
						?>
						<?php
						printf(
							/* translators: %s: link to the Payouts list filtered by processing status */
							wp_kses(
								__( 'AffiliateWP marks them paid when the payout completes — track them in the <a href="%s">Payouts list</a>.', 'affiliate-wp' ),
								array( 'a' => array( 'href' => array() ) )
							),
							esc_url( affwp_admin_url( 'payouts', array( 'status' => 'processing' ) ) )
						);
						?>
					</p>
				</div>
			<?php endif; ?>

			<div class="max-w-5xl rounded-xl bg-white ring-1 ring-gray-200 px-6 py-12 text-center">
				<?php if ( ! empty( $invalid_affiliates ) ) : ?>
					<h2 class="text-base/6 font-semibold tracking-tight m-0"><?php esc_html_e( 'No affiliates can be paid this run', 'affiliate-wp' ); ?></h2>
					<p class="mt-2 text-sm/5 text-gray-600 m-0">
						<?php
						echo esc_html(
							sprintf(
								/* translators: %d: number of affiliates */
								_n( '%d affiliate is blocked. Review the reasons below and edit the filters to retry.', '%d affiliates are blocked. Review the reasons below and edit the filters to retry.', $invalid_count, 'affiliate-wp' ),
								(int) $invalid_count
							)
						);
						?>
					</p>
				<?php else : ?>
					<h2 class="text-base/6 font-semibold tracking-tight m-0"><?php esc_html_e( 'No referrals match these filters', 'affiliate-wp' ); ?></h2>
					<p class="mt-2 text-sm/5 text-gray-600 m-0">
						<?php
						printf(
							/* translators: %s: link to referrals screen */
							esc_html__( 'Adjust the period or filters and try again, or view all %s.', 'affiliate-wp' ),
							'<a class="text-gray-700 underline underline-offset-2 hover:no-underline" href="' . esc_url( affwp_admin_url( 'referrals' ) ) . '">' . esc_html__( 'referrals', 'affiliate-wp' ) . '</a>'
						);
						?>
					</p>
				<?php endif; ?>
			</div>

			<?php if ( ! empty( $invalid_affiliates ) ) : ?>
				<?php
				$invalid_visible_count = affwp_get_preview_visible_count( $invalid_count, $invalid_row_cap, $preview_row_snap );
				$invalid_visible       = array_slice( $invalid_affiliates, 0, $invalid_visible_count, true );
				$invalid_overflow      = max( 0, $invalid_count - $invalid_visible_count );
				// The empty-state branch has no prior prefetch, so warm just the affiliates the visible cap will render.
				$empty_state_lookup    = affwp_preload_preview_payout_affiliates( array_keys( $invalid_visible ) );
				?>
				<section id="affwp-invalid-affiliates" data-deeplink-highlight="ring-2! ring-affwp-brand-500! ring-offset-2 transition-all" class="mt-6 max-w-5xl rounded-xl bg-white ring-1 ring-gray-200 overflow-hidden scroll-mt-24">
					<div role="table" class="text-sm/6" aria-label="<?php esc_attr_e( 'Affiliates that cannot be paid this run', 'affiliate-wp' ); ?>">
						<div role="rowgroup" class="divide-y divide-gray-200" data-affwp-preview-rows>
							<?php foreach ( $invalid_visible as $affiliate_id => $status ) : ?>
								<?php echo affwp_render_preview_invalid_row( $affiliate_id, $status, $empty_state_lookup ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- helper outputs escaped markup. ?>
							<?php endforeach; ?>
						</div>

						<?php if ( $invalid_overflow > 0 ) : ?>
							<button
								type="button"
								class="affwp-preview-load-more w-full bg-gray-50 hover:bg-gray-100 px-6 py-2 text-center cursor-pointer transition-colors border-t border-gray-200 disabled:cursor-wait disabled:opacity-60"
								data-section="invalid"
								data-offset="<?php echo esc_attr( (int) $invalid_visible_count ); ?>"
								data-remaining="<?php echo esc_attr( (int) $invalid_overflow ); ?>"
								data-batch="<?php echo esc_attr( (int) $invalid_load_more_batch ); ?>"
								aria-busy="false"
							>
								<span class="inline-flex items-center gap-1.5 text-sm/5 font-medium text-gray-600">
									<?php \AffiliateWP\Utils\Icons::render( 'chevron-down', [ 'class' => 'size-3.5 text-gray-400 shrink-0' ] ); ?>
									<span data-affwp-load-more-label>
										<?php echo esc_html( affwp_get_preview_load_more_label( $invalid_overflow, $invalid_load_more_batch ) ); ?>
									</span>
									<span data-affwp-load-more-busy hidden><?php esc_html_e( 'Loading…', 'affiliate-wp' ); ?></span>
								</span>
							</button>
						<?php endif; ?>
					</div>
				</section>
			<?php endif; ?>

		<?php endif; ?>

	</div>

	<?php if ( ! empty( $payouts ) ) : ?>
		<?php
		$submit_form_id = $async_capable ? 'affwp-process-payout-async-form' : 'affwp-new-payout-form';
		?>
		<?php // Forms with hidden inputs sit outside the bar (zero visual footprint) so the bar's button can submit either via the `form=` attribute. Keeping the markup unchanged from the dark-island version. ?>
		<?php if ( $async_capable ) : ?>
			<form method="post" action="<?php echo esc_url( affwp_admin_url( 'payouts' ) ); ?>" id="<?php echo esc_attr( $submit_form_id ); ?>" class="hidden">
				<input type="hidden" name="affwp_action" value="process_payout_async" />
				<input type="hidden" name="user_name" value="<?php echo esc_attr( $user_name ); ?>" />
				<input type="hidden" name="from" value="<?php echo esc_attr( $start ); ?>" />
				<input type="hidden" name="to" value="<?php echo esc_attr( $end ); ?>" />
				<input type="hidden" name="bypass_holding" value="<?php echo esc_attr( $bypass_holding ); ?>" />
				<input type="hidden" name="minimum" value="<?php echo esc_attr( $minimum ); ?>" />
				<?php foreach ( $include_affiliates as $aff_id ) : ?>
					<input type="hidden" name="include_affiliates[]" value="<?php echo (int) $aff_id; ?>" />
				<?php endforeach; ?>
				<?php foreach ( $include_groups as $grp_id ) : ?>
					<input type="hidden" name="include_groups[]" value="<?php echo (int) $grp_id; ?>" />
				<?php endforeach; ?>
				<?php foreach ( $payout_methods_filter as $m_key ) : ?>
					<input type="hidden" name="payout_methods[]" value="<?php echo esc_attr( $m_key ); ?>" />
				<?php endforeach; ?>
				<?php if ( '' !== $payout_method ) : ?>
					<?php // Batch-level override ("Pay everyone via X"). Carry the singular method through so the async batch records it instead of falling back to per-affiliate routing. ?>
					<input type="hidden" name="payout_method" value="<?php echo esc_attr( $payout_method ); ?>" />
				<?php endif; ?>
				<?php wp_nonce_field( 'affwp_process_payout_async', 'affwp_process_payout_async_nonce' ); ?>
			</form>
		<?php else : ?>
			<form method="post" id="<?php echo esc_attr( $submit_form_id ); ?>" class="hidden">
				<input type="hidden" name="user_name" value="<?php echo esc_attr( $user_name ); ?>" />
				<input type="hidden" name="from" value="<?php echo esc_attr( $start ); ?>" />
				<input type="hidden" name="to" value="<?php echo esc_attr( $end ); ?>" />
				<input type="hidden" name="minimum" value="<?php echo esc_attr( $minimum ); ?>" />
				<input type="hidden" name="payout_method" value="<?php echo esc_attr( $payout_method ); ?>" />
				<input type="hidden" name="bypass_holding" value="<?php echo esc_attr( $bypass_holding ); ?>" />
				<?php foreach ( $include_affiliates as $aff_id ) : ?>
					<input type="hidden" name="include_affiliates[]" value="<?php echo (int) $aff_id; ?>" />
				<?php endforeach; ?>
				<?php foreach ( $include_groups as $grp_id ) : ?>
					<input type="hidden" name="include_groups[]" value="<?php echo (int) $grp_id; ?>" />
				<?php endforeach; ?>
				<input type="hidden" name="affwp_action" value="new_payout" />
				<?php wp_nonce_field( 'affwp_new_payout_nonce', 'affwp_new_payout_nonce' ); ?>
			</form>
		<?php endif; ?>

		<?php
		/*
		 * Full-width white sticky bar (Step 2). Mirrors the Step 1 treatment:
		 * fixed to viewport bottom across the WP admin content column, status on
		 * the left, primary action on the right. Status reads "<total> · N
		 * affiliates" (this run's summary). The button branches three ways:
		 *
		 *   - blocking warning (e.g. Stripe shortfall): red "Resolve issue to
		 *     continue" anchor that scrolls to the offending method section.
		 *   - async-capable batches: opens the confirm-payout modal, which then
		 *     POSTs to the hidden process_payout_async form above.
		 *   - sync batches: same modal flow, hidden new_payout form gets submitted.
		 */
		?>
		<?php
		/*
		 * Pay Affiliates action bar. The shell (gutters, max-w-5xl column, fixed positioning, shadow)
		 * comes from partials/payout-action-bar.php, shared with the New Payout screen. Render the
		 * status and action regions, then hand them to the shell.
		 */
		ob_start();
		?>
				<div class="text-sm/5 min-w-0">
					<p class="m-0 tabular-nums">
						<span class="font-medium text-gray-900">
							<?php
							echo esc_html(
								sprintf(
									/* translators: 1: total amount, 2: number of affiliates going out */
									_n(
										'%1$s · %2$d affiliate',
										'%1$s · %2$d affiliates',
										$going_out_count,
										'affiliate-wp'
									),
									affwp_currency_filter( affwp_format_amount( $going_out_total ) ),
									(int) $going_out_count
								)
							);
							?>
						</span>
					</p>
					<?php if ( $has_blocking_warning ) : ?>
						<p class="mt-0.5 m-0 text-xs text-red-800">
							<?php esc_html_e( "Payments balance shortfall — top up in Stripe before processing this batch.", 'affiliate-wp' ); ?>
						</p>
					<?php endif; ?>
				</div>
		<?php
		$action_bar_status = ob_get_clean();

		/*
		 * Method buckets. store_credit and manual are reversible from inside AffiliateWP: store_credit
		 * adjusts balances, manual marks referrals Paid and generates a CSV (the admin can undo by
		 * deleting the payout until the money is sent externally). PayPal and Stripe move money via API
		 * at confirmation, so they can't be reversed from the admin. The slug is store_credit
		 * (underscore), matching affwp_get_affiliate_payout_method(), not the store-credit (hyphen)
		 * settings option key. Computed before the action bar so the trigger can share the modal's verb.
		 */
		$reversible_methods = array( 'store_credit', 'manual' );
		$method_keys        = array_keys( $payouts_by_method );
		$has_irreversible   = (bool) array_diff( $method_keys, $reversible_methods );
		$only_store_credit  = ( array( 'store_credit' ) === $method_keys );
		$only_manual        = ( array( 'manual' ) === $method_keys );

		ob_start();
		// Seeds only durable criteria (who + minimum): date range and method are point-in-time, irrelevant to a recurring schedule.

		// Selected affiliates + groups as {id,name} lists so the drawer's picker pre-fills its chips.
		$picker_affiliates = array();
		foreach ( (array) $include_affiliates as $aff_id ) {
			$picker_affiliates[] = array( 'id' => (int) $aff_id, 'name' => affwp_affiliate_picker_label( (int) $aff_id ) );
		}
		$picker_groups = array();
		foreach ( (array) $include_groups as $grp_id ) {
			$grp     = affiliate_wp()->groups->get_group( (int) $grp_id );
			$members = affiliate_wp()->connections->get_connected( 'affiliate', 'group', (int) $grp_id );
			$picker_groups[] = array(
				'id'              => (int) $grp_id,
				'name'            => $grp ? $grp->get_title() : '',
				'type'            => 'group',
				'affiliate_count' => is_array( $members ) ? count( $members ) : 0,
			);
		}
		?>
				<div class="flex flex-col-reverse gap-2 sm:flex-row sm:items-center sm:gap-3 shrink-0">
					<?php if ( current_user_can( 'manage_payouts' ) ) : ?>
						<button type="button"
							data-new-schedule="1"
							data-picker-affiliates="<?php echo esc_attr( wp_json_encode( $picker_affiliates ) ); ?>"
							data-picker-groups="<?php echo esc_attr( wp_json_encode( $picker_groups ) ); ?>"
							<?php echo $minimum ? ' data-minimum="' . esc_attr( $minimum ) . '"' : ''; ?>
							<?php echo $bypass_holding ? ' data-bypass-holding="1"' : ''; ?>
							class="inline-flex w-full sm:w-auto justify-center items-center gap-1.5 rounded-md bg-white px-5 py-2.5 text-base font-semibold text-gray-700 ring-1 ring-inset ring-gray-300 hover:bg-gray-50 cursor-pointer whitespace-nowrap">
							<?php esc_html_e( 'Save as schedule', 'affiliate-wp' ); ?>
							<?php
							// Inline gating marker: non-Pro plans see the gate before the click (the drawer carries the full upsell).
							if ( function_exists( 'affwp_can_access_pro_features' ) && ! affwp_can_access_pro_features() ) {
								echo affwp_get_pro_badge( array( 'icon' => '', 'class' => 'text-[11px] uppercase tracking-wide' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- badge helper returns trusted HTML.
							}
							?>
						</button>
					<?php endif; ?>
					<?php if ( $has_blocking_warning ) : ?>
						<a href="#affwp-method-<?php echo esc_attr( sanitize_html_class( array_key_first( $method_warnings ) ) ?: 'method' ); ?>" class="inline-flex w-full justify-center sm:w-auto sm:justify-start shrink-0 items-center gap-1.5 rounded-md bg-red-600 px-5 py-2.5 text-base font-semibold text-white hover:bg-red-700 cursor-pointer whitespace-nowrap">
							<?php esc_html_e( 'Resolve issue to continue', 'affiliate-wp' ); ?>
						</a>
					<?php else : ?>
						<button type="button" @click="$store.modals.open('affwp-confirm-payout-modal')" class="inline-flex w-full justify-center sm:w-auto sm:justify-start shrink-0 items-center gap-1.5 rounded-md bg-affwp-brand-500 px-5 py-2.5 text-base font-semibold text-white hover:bg-affwp-brand-600 cursor-pointer whitespace-nowrap">
							<?php $only_manual ? esc_html_e( 'Record as paid', 'affiliate-wp' ) : esc_html_e( 'Pay affiliates', 'affiliate-wp' ); ?>
							<?php echo \AffiliateWP\Utils\Icons::get( 'chevron-right', [ 'class' => 'size-4' ] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						</button>
					<?php endif; ?>
				</div>
		<?php
		$action_bar_action = ob_get_clean();

		require __DIR__ . '/partials/payout-action-bar.php';
		?>

		<?php
		/*
		 * Minimal confirmation: amount and affiliate count form the title question; irreversibility is
		 * inlined only when the run includes external transfers (PayPal/Stripe/manual). Store-credit-only
		 * runs are adjustable in-AffiliateWP, so the warning is dropped there. Conditional callouts
		 * (PayPal invites' 30-day clawback, blocked affiliates) stay either way.
		 */
		$confirm_modal_title_id = 'modal-affwp-confirm-payout-modal-title';

		// Manual sends nothing, so an all-manual run asks to record, not to pay (mirrors the bulk-pay drawer and the single-referral modal).
		$confirm_modal_title = sprintf(
			$only_manual
				/* translators: 1: total payout amount with currency, 2: formatted affiliate count */
				? _n(
					'Record %1$s as paid for %2$s affiliate?',
					'Record %1$s as paid for %2$s affiliates?',
					$going_out_count,
					'affiliate-wp'
				)
				/* translators: 1: total payout amount with currency, 2: formatted affiliate count */
				: _n(
					'Pay %1$s to %2$s affiliate?',
					'Pay %1$s to %2$s affiliates?',
					$going_out_count,
					'affiliate-wp'
				),
			affwp_currency_filter( affwp_format_amount( $going_out_total ) ),
			number_format_i18n( $going_out_count )
		);

		ob_start();
		?>
		<div>
			<p class="m-0 text-sm/6 text-gray-600">
				<?php
				if ( $only_store_credit ) {
					esc_html_e( 'Affiliate balances update and referrals are marked Paid.', 'affiliate-wp' );
				} elseif ( $only_manual ) {
					esc_html_e( "Referrals are marked Paid and you'll have a CSV ready to send the money.", 'affiliate-wp' );
				} elseif ( ! $has_irreversible ) {
					// store_credit + manual mix: both reversible, but the action differs per method, so describe both.
					esc_html_e( "Affiliate balances update and you'll have a CSV ready for the manual payouts. Referrals are marked Paid.", 'affiliate-wp' );
				} else {
					// External transfers in the run (PayPal / Stripe, alone or mixed with reversible methods).
					echo esc_html(
						_n(
							'Your affiliate receives their payout and referrals are marked Paid.',
							'Your affiliates receive their payouts and referrals are marked Paid.',
							$going_out_count,
							'affiliate-wp'
						)
					);
				}
				?>
			</p>

			<?php if ( $has_irreversible ) : ?>
				<p class="mt-2 text-sm/6 font-medium text-gray-900">
					<?php esc_html_e( "Once paid, AffiliateWP can't reverse this.", 'affiliate-wp' ); ?>
				</p>
			<?php endif; ?>

			<?php if ( $grand_blocked_count > 0 ) : ?>
				<div class="mt-7 rounded-md bg-gray-50 p-4 space-y-3.5">
					<div class="flex items-start gap-3 text-sm/6 text-gray-700">
						<?php echo \AffiliateWP\Utils\Icons::get( 'circle-warning', [ 'class' => 'size-4 mt-1 text-amber-600 shrink-0' ] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Icons::get returns sanitized SVG. ?>
						<span>
							<?php
							echo esc_html(
								sprintf(
									/* translators: 1: amount held back, 2: formatted affiliate count */
									_n(
										"%1\$s for %2\$s affiliate isn't deliverable this run, their referrals stay unpaid until the setup is fixed.",
										"%1\$s for %2\$s affiliates isn't deliverable this run, their referrals stay unpaid until the setup is fixed.",
										$grand_blocked_count,
										'affiliate-wp'
									),
									affwp_currency_filter( affwp_format_amount( $grand_blocked_total ) ),
									number_format_i18n( $grand_blocked_count )
								)
							);
							?>
						</span>
					</div>
				</div>
			<?php endif; ?>
		</div>
		<?php
		$confirm_modal_content = ob_get_clean();

		/*
		 * custom_header replaces the trait's default centered/icon header so the title can be
		 * left-aligned without warning-icon chrome. The close button lives here because custom_header
		 * short-circuits the trait's default header.
		 */
		ob_start();
		?>
		<div class="mb-5 pr-8">
			<h3 class="text-lg font-semibold text-gray-900 m-0 leading-snug" id="<?php echo esc_attr( $confirm_modal_title_id ); ?>">
				<?php echo $confirm_modal_title; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- composed from translation + entity-encoded currency, both safe. ?>
			</h3>
		</div>
		<button type="button" @click="close()" class="cursor-pointer absolute right-0 top-0 p-4 text-gray-400 hover:text-gray-500">
			<span class="sr-only"><?php esc_html_e( 'Close', 'affiliate-wp' ); ?></span>
			<?php echo \AffiliateWP\Utils\Icons::get( 'x-mark', [ 'class' => 'size-6', 'aria-hidden' => 'true' ] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Icons::get returns sanitized SVG. ?>
		</button>
		<?php
		$confirm_modal_header = ob_get_clean();

		/*
		 * Footer: both actions right-aligned with Cancel as a quiet link so the primary action keeps the
		 * gravity, instead of the 2-col grid (Cancel left / primary right) other AffWP modals use.
		 */
		ob_start();
		?>
		<?php
		// The submit navigates, which can take seconds; the busy overlay stops the modal reading as dead (and re-clicks double-submitting) without shifting the button.
		$confirm_verb = $only_manual ? __( 'Record as paid', 'affiliate-wp' ) : __( 'Pay', 'affiliate-wp' );
		?>
		<div class="mt-6 flex items-center justify-end gap-5" x-data="{ submitting: false }">
			<button type="button" @click="close()" :disabled="submitting" class="cursor-pointer text-sm font-medium text-gray-600 hover:text-gray-900 hover:underline disabled:opacity-50 disabled:cursor-not-allowed">
				<?php esc_html_e( 'Cancel', 'affiliate-wp' ); ?>
			</button>
			<?php
			echo affwp_render_primary_button( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- component returns escaped markup.
				$confirm_verb,
				array(
					'size'              => 'md',
					'no_alpine_wrapper' => true,
					'loading_state'     => 'submitting',
					'attributes'        => array(
						'type'      => 'button',
						'autofocus' => 'autofocus',
						':disabled' => 'submitting',
						'@click'    => "if ( submitting ) return; submitting = true; document.getElementById('" . esc_js( $submit_form_id ) . "').submit()",
					),
				)
			);
			?>
		</div>
		<?php
		$confirm_modal_footer = ob_get_clean();

		affwp_modal( [
			'id'                => 'affwp-confirm-payout-modal',
			'size'              => 'md',
			'variant'           => 'default',
			'custom_header'     => $confirm_modal_header,
			'content'           => $confirm_modal_content,
			'custom_footer'     => $confirm_modal_footer,
			'close_on_backdrop' => true,
			'close_on_escape'   => true,
		] );
		?>
	<?php endif; ?>

</div>

<?php if ( ! empty( $payouts ) ) : ?>
	<script>
	/*
	 * Anchor .affwp-payout-action-bar to the WP admin sidebar's actual right edge.
	 * Mirrors the same shim used on the Pay Affiliates form (Step 1); WP admin's
	 * body.auto-fold class doesn't reliably reflect sidebar width on resize-up,
	 * so we measure the sidebar directly via ResizeObserver + window resize.
	 */
	( function () {
		var bar = document.querySelector( '.affwp-payout-action-bar' );
		var sidebar = document.getElementById( 'adminmenuwrap' );
		if ( ! bar || ! sidebar ) {
			return;
		}
		var sync = function () {
			var right = Math.max( 0, sidebar.getBoundingClientRect().right );
			bar.style.setProperty( '--affwp-bar-left', right + 'px' );
		};
		sync();
		window.addEventListener( 'resize', sync );
		if ( window.ResizeObserver ) {
			new ResizeObserver( sync ).observe( sidebar );
		}
	} )();
	</script>

	<?php
	/*
	 * Create/edit schedule slide-over. Rendering it here lets "Save as schedule"
	 * (in the action bar) open the drawer in place over this preview, rather than
	 * navigating to the Schedules tab just to show it. The seeded new_schedule=1
	 * link is intercepted client-side by assets/js/affwp-schedule-drawer.js.
	 */
	if ( current_user_can( 'manage_payouts' ) ) {
		affwp_render_schedule_drawer();
	}

	/*
	 * "Save as schedule" returns here (not the Schedules tab) so the admin can
	 * finish the payout. Confirm the new schedule + its next run in a toast, then
	 * scrub the params so a refresh doesn't re-toast. The toast container ships
	 * with the drawer rendered above.
	 */
	$affwp_notice = isset( $_GET['affwp_notice'] ) ? sanitize_key( $_GET['affwp_notice'] ) : '';
	if ( in_array( $affwp_notice, array( 'schedule_created', 'schedule_updated', 'schedule_save_failed' ), true ) ) :
		$affwp_new_schedule_id = isset( $_GET['affwp_new_schedule_id'] ) ? absint( $_GET['affwp_new_schedule_id'] ) : 0;
		if ( 'schedule_created' === $affwp_notice && $affwp_new_schedule_id ) {
			$affwp_toast = array( affwp_payout_schedule_created_message( $affwp_new_schedule_id ), 'success' );
		} elseif ( 'schedule_updated' === $affwp_notice ) {
			$affwp_toast = array( __( 'Schedule updated.', 'affiliate-wp' ), 'success' );
		} else {
			$affwp_toast = array( __( 'Could not save the schedule. Please give it a name and try again.', 'affiliate-wp' ), 'error' );
		}
		?>
		<script>
			( function () {
				var fire = function () {
					if ( ! window.affwpToast ) {
						return;
					}
					window.affwpToast( { message: <?php echo wp_json_encode( $affwp_toast[0] ); ?>, type: <?php echo wp_json_encode( $affwp_toast[1] ); ?> } );
					try {
						var url = new URL( window.location.href );
						url.searchParams.delete( 'affwp_notice' );
						url.searchParams.delete( 'affwp_new_schedule_id' );
						window.history.replaceState( {}, '', url.toString() );
					} catch ( e ) { /* History API unavailable. */ }
				};
				if ( document.readyState === 'loading' ) {
					document.addEventListener( 'DOMContentLoaded', fire );
				} else {
					fire();
				}
			} )();
		</script>
		<?php
	endif;
	?>
<?php endif; ?>
