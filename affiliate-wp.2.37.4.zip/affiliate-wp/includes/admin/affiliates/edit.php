<?php
/**
 * Admin: Edit Affiliate View
 *
 * @package     AffiliateWP
 * @subpackage  Admin/Affiliates
 * @copyright   Copyright (c) 2014, Sandhills Development, LLC
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       1.0
 */

$affiliate                    = affwp_get_affiliate( absint( $_GET['affiliate_id'] ) );
$user_info                    = get_userdata( $affiliate->user_id );
$rate_type                    = ! empty( $affiliate->rate_type ) ? $affiliate->rate_type : '';
$flat_rate_basis              = ! empty( $affiliate->flat_rate_basis ) ? $affiliate->flat_rate_basis : 'per_product';
$rate                         = isset( $affiliate->rate ) ? $affiliate->rate : null;
$rate                         = affwp_abs_number_round( $affiliate->rate );
$default_rate                 = affiliate_wp()->settings->get( 'referral_rate', 20 );
$default_rate                 = affwp_abs_number_round( $default_rate );
$email                        = ! empty( $affiliate->payment_email ) ? $affiliate->payment_email : '';
$reason                       = affwp_get_affiliate_meta( $affiliate->affiliate_id, '_rejection_reason', true );
$promotion_method             = get_user_meta( $affiliate->user_id, 'affwp_promotion_method', true );
$notes                        = affwp_get_affiliate_meta( $affiliate->affiliate_id, 'notes', true );
$payout_service_account       = affwp_get_affiliate_meta( $affiliate->affiliate_id, 'payouts_service_account', true );
$payout_service_payout_method = affwp_get_affiliate_meta( $affiliate->affiliate_id, 'payouts_service_payout_method', true );
$payout_method_override       = affwp_get_affiliate_payout_method_override( $affiliate->affiliate_id );
$dynamic_coupons              = affwp_get_dynamic_affiliate_coupons( $affiliate->ID, false );
$custom_fields                = affwp_get_custom_registration_fields( $affiliate->ID, true );
$summary_suppressed           = affwp_is_affiliate_email_summary_suppressed( $affiliate->ID );
$summaries_deliverable        = affwp_can_send_affiliate_email_summaries();
$summary_last_sent            = affwp_get_affiliate_meta( $affiliate->ID, 'last_email_summary_sent', true );

if ( isset( $_REQUEST['delete_coupon'] ) && 1 == absint( $_REQUEST['delete_coupon'] ) && isset( $_REQUEST['coupon_id'] ) && absint( $_REQUEST['coupon_id'] ) > 0 ) {

	$coupon_id = absint( $_REQUEST['coupon_id'] );

	if ( ! current_user_can( 'manage_affiliates' ) ) {
		wp_die( esc_html__( 'You do not have permission to manage affiliates', 'affiliate-wp' ), esc_html__( 'Error', 'affiliate-wp' ), [ 'response' => 403 ] );
	}

	// The nonce is bound to the affiliate and the coupon.
	if ( ! isset( $_REQUEST['_wpnonce'] ) || ! wp_verify_nonce( $_REQUEST['_wpnonce'], 'affwp_delete_coupon_' . $affiliate->ID . '_' . $coupon_id ) ) {
		wp_die( esc_html__( 'Security check failed', 'affiliate-wp' ), esc_html__( 'Error', 'affiliate-wp' ), [ 'response' => 403 ] );
	}

	$coupon = affwp_get_affiliate_coupon( $affiliate->ID, $coupon_id );
	if ( ! is_wp_error( $coupon ) ) {
		$coupon_deleted = affiliate_wp()->affiliates->coupons->delete( $coupon->ID );
		if ( $coupon_deleted ) {
			wp_safe_redirect(
				affwp_admin_url(
					'affiliates',
					[
						'affiliate_id' => $affiliate->ID,
						'action'       => 'edit_affiliate',
						'affwp_notice' => 'dynamic_coupon_deleted',
					]
				)
			);
			exit;
		} else {
			wp_safe_redirect(
				affwp_admin_url(
					'affiliates',
					[
						'affiliate_id' => $affiliate->ID,
						'action'       => 'edit_affiliate',
						'affwp_notice' => 'dynamic_coupon_delete_failed',
					]
				)
			);
			exit;
		}
	}
}

if ( isset( $_REQUEST['generate_coupon'] ) && 1 == absint( $_REQUEST['generate_coupon'] ) ) {

	if ( ! current_user_can( 'manage_affiliates' ) ) {
		wp_die( esc_html__( 'You do not have permission to manage affiliates', 'affiliate-wp' ), esc_html__( 'Error', 'affiliate-wp' ), [ 'response' => 403 ] );
	}

	// The nonce is bound to the affiliate.
	if ( ! isset( $_REQUEST['_wpnonce'] ) || ! wp_verify_nonce( $_REQUEST['_wpnonce'], 'affwp_generate_coupon_' . $affiliate->ID ) ) {
		wp_die( esc_html__( 'Security check failed', 'affiliate-wp' ), esc_html__( 'Error', 'affiliate-wp' ), [ 'response' => 403 ] );
	}

	$coupon_created = affiliate_wp()->affiliates->coupons->add( [ 'affiliate_id' => $affiliate->ID ] );
	if ( $coupon_created ) {
		wp_safe_redirect(
			affwp_admin_url(
				'affiliates',
				[
					'affiliate_id' => $affiliate->ID,
					'action'       => 'edit_affiliate',
					'affwp_notice' => 'dynamic_coupon_created',
				]
			)
		);
		exit;
	} else {
		wp_safe_redirect(
			affwp_admin_url(
				'affiliates',
				[
					'affiliate_id' => $affiliate->ID,
					'action'       => 'edit_affiliate',
					'affwp_notice' => 'dynamic_coupon_create_failed',
				]
			)
		);
		exit;
	}
}

?>
<div class="wrap">

	<h2><?php _e( 'Edit Affiliate', 'affiliate-wp' ); ?></h2>

	<form method="post" id="affwp_edit_affiliate">

		<?php
		/**
		 * Fires at the top of the edit-affiliate admin screen, just inside of the form element.
		 *
		 * @since 1.0
		 *
		 * @param \AffWP\Affiliate $affiliate The affiliate object being edited.
		 */
		do_action( 'affwp_edit_affiliate_top', $affiliate );
		?>

		<table class="form-table">

			<tr class="form-row form-required">

				<th scope="row">
					<label for="affiliate_first_last"><?php _e( 'Affiliate Name', 'affiliate-wp' ); ?></label>
				</th>

				<td>
					<input class="regular-text" type="text" name="affiliate_first_last" id="affiliate_first_last" value="<?php echo esc_attr( affwp_get_affiliate_name( $affiliate->affiliate_id ) ); ?>" disabled="1" />
					<p class="description">
						<?php
						/* translators: 1: edit user link for the affiliate, 2: descriptive alt text for the user edit link */
						printf(
							__( 'The affiliate&#8217;s first and/or last name. Will be empty if no name is specified. This can be changed on the <a href="%1$s" alt="%2$s">user edit screen</a>.', 'affiliate-wp' ),
							esc_url( get_edit_user_link( $affiliate->user_id ) ),
							esc_attr__( 'A link to the user edit screen for this user.', 'affiliate-wp' )
						);
						?>
					</p>
				</td>

			</tr>

			<tr class="form-row form-required">

				<th scope="row">
					<label for="affiliate_id"><?php _e( 'Affiliate ID', 'affiliate-wp' ); ?></label>
				</th>

				<td>
					<input class="medium-text" type="text" name="affiliate_id" id="affiliate_id" value="<?php echo esc_attr( $affiliate->affiliate_id ); ?>" disabled="1" />
					<p class="description"><?php _e( 'The affiliate&#8217;s ID. This cannot be changed.', 'affiliate-wp' ); ?></p>
				</td>

			</tr>

			<tr class="form-row form-required">

				<th scope="row">
					<label for="affiliate_id"><?php _e( 'Affiliate URL', 'affiliate-wp' ); ?></label>
				</th>

				<td>
					<input class="large-text" type="text" name="affiliate_url" id="affiliate_url" value="<?php echo esc_attr( affwp_get_affiliate_referral_url( [ 'affiliate_id' => $affiliate->affiliate_id ] ) ); ?>" disabled="1" />
					<p class="description"><?php _e( 'The affiliate&#8217;s referral URL. This is based on global settings.', 'affiliate-wp' ); ?></p>
				</td>

			</tr>

			<tr class="form-row form-required">

				<th scope="row">
					<label for="user_id"><?php _e( 'User ID', 'affiliate-wp' ); ?></label>
				</th>

				<td>
					<input class="medium-text" type="text" name="user_id" id="user_id" value="<?php echo esc_attr( $affiliate->user_id ); ?>" disabled="1" />
					<p class="description"><?php _e( 'The affiliate&#8217;s user ID. This cannot be changed.', 'affiliate-wp' ); ?></p>
				</td>

			</tr>

			<tr class="form-row form-required">

				<th scope="row">
					<label for="user_login"><?php _e( 'Username', 'affiliate-wp' ); ?></label>
				</th>

				<td>
					<input class="regular-text" type="text" name="user_login" id="user_login" value="<?php echo esc_attr( $user_info->user_login ); ?>" disabled="1" />
					<p class="description"><?php _e( 'The affiliate&#8217;s username. This cannot be changed.', 'affiliate-wp' ); ?></p>
				</td>

			</tr>

			<tr class="form-row form-required">

				<th scope="row">
					<label for="date_registered"><?php _e( 'Registration Date', 'affiliate-wp' ); ?></label>
				</th>

				<td>
					<input class="medium-text" type="text" name="date_registered" id="date_registered" value="<?php echo esc_attr( $affiliate->date_i18n( 'datetime' ) ); ?>" disabled="1" />
					<p class="description"><?php _e( 'The affiliate&#8217;s registration date. This cannot be changed.', 'affiliate-wp' ); ?></p>
				</td>

			</tr>

			<tr class="form-row">

				<th scope="row">
					<label for="status"><?php _e( 'Affiliate Status', 'affiliate-wp' ); ?></label>
				</th>

				<td>
					<select name="status" id="status">
						<?php
						$statuses = affwp_get_affiliate_statuses();

						/*
						 * Only include and display the Rejected status if that's the current
						 * status, otherwise hide it as it's part of the approval process.
						 */
						if ( 'rejected' !== $affiliate->status ) {
							unset( $statuses['rejected'] );
						}
						?>

						<?php foreach ( $statuses as $status => $label ) : ?>
							<option value="<?php echo esc_attr( $status ); ?>" <?php selected( $affiliate->status, $status ); ?>>
								<?php echo esc_html( $label ); ?>
							</option>
						<?php endforeach; ?>
					</select>
					<p class="description"><?php _e( 'The status assigned to the affiliate&#8217;s account. Updating the status could trigger account related events, such as email notifications.', 'affiliate-wp' ); ?></p>
				</td>

			</tr>

			<?php
			/**
			 * Fires at the 8th position of the edit affiliate form.
			 *
			 * @param mixed Affiliate Object.
			 *
			 * @since 2.13.0
			 */
			do_action( 'affwp_edit_affiliate_after_status', $affiliate );
			?>

			<tr class="form-row warning">

				<th scope="row">
					<label for="website"><?php _e( 'Website', 'affiliate-wp' ); ?></label>
				</th>

				<td>
					<input class="medium-text" type="text" name="website" id="website" value="<?php echo esc_attr( $user_info->user_url ); ?>" disabled="disabled" />
					<p class="description">
						<?php
						/* translators: 1: edit user link for the affiliate, 2: descriptive alt text for the user edit link */
						echo wp_sprintf(
							__( 'The affiliate&#8217;s website. Will be empty if no website is specified. This can be changed on the <a href="%1$s" alt="%2$s">user edit screen</a>.', 'affiliate-wp' ),
							esc_url( get_edit_user_link( $affiliate->user_id ) ),
							esc_attr__( 'A link to the user edit screen for this user.', 'affiliate-wp' )
						);
						?>
					</p>
				</td>
			</tr>

			<!-- Rate Settings -->

			<!-- Referral rate type -->
			<tr class="form-row">

				<th scope="row">
					<label for="rate_type_default"><?php esc_html_e( 'Referral Rate Type', 'affiliate-wp' ); ?></label>

					<?php if ( affwp_affiliate_has_affiliate_group_overrides( $affiliate->affiliate_id, 'rate-type' ) ) : ?>
						<?php
						$tooltip_html = affwp_tooltip(
							[
								'content' => __( 'This affiliate is in an affiliate group that has a custom rate type setting which will override this as long as they remain in that affiliate group.', 'affiliate-wp' ),
								'type'    => 'warning',
							]
						);
						?>
					<span class="dashicons dashicons-warning cursor-help" data-tooltip-html="<?php echo esc_attr( $tooltip_html ); ?>"></span>
					<?php endif; ?>
				</th>

				<td>
					<fieldset id="rate_type">
						<legend class="screen-reader-text"><?php esc_html_e( 'Referral Rate Type', 'affiliate-wp' ); ?></legend>
						<label for="rate_type_default">
							<input type="radio" name="rate_type" id="rate_type_default" value="" <?php checked( $rate_type, '' ); ?>/> <?php esc_html_e( 'Site Default', 'affiliate-wp' ); ?>
						</label>
						<br/>
						<?php foreach ( affwp_get_affiliate_rate_types() as $key => $type ) : // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- Legacy code. ?>
							<?php $value = esc_attr( $key ); ?>
							<label for="rate_type_<?php echo esc_attr( $value ); ?>">
								<input type="radio" name="rate_type" id="rate_type_<?php echo esc_attr( $value ); ?>" value="<?php echo esc_attr( $value ); ?>"<?php checked( $rate_type, $key ); ?>> <?php echo esc_html( $type ); ?>
							</label>
							<br/>
						<?php endforeach; ?>
					<p class="description"><?php esc_html_e( 'The affiliate&#8217;s referral rate type.', 'affiliate-wp' ); ?></p>
					</fieldset>
				</td>

			</tr>

			<!-- Flat Rate: Referral Basis -->
			<tr class="<?php echo esc_attr( 'flat' !== $affiliate->rate_type ? 'form-row affwp-hidden' : 'form-row' ); ?>">

				<th scope="row">
					<?php esc_html_e( 'Flat Rate Referral Basis', 'affiliate-wp' ); ?>

					<?php if ( affwp_affiliate_has_affiliate_group_overrides( $affiliate->affiliate_id, 'flat-rate-basis' ) ) : ?>
						<?php
						$tooltip_html = affwp_tooltip(
							[
								'content' => __( 'This affiliate is in an affiliate group that has a custom flat rate basis setting which will override this as long as they remain in that affiliate group.', 'affiliate-wp' ),
								'type'    => 'warning',
							]
						);
						?>
					<span class="dashicons dashicons-warning cursor-help" data-tooltip-html="<?php echo esc_attr( $tooltip_html ); ?>"></span>
					<?php endif; ?>
				</th>

				<td>
					<fieldset id="flat_rate_basis">
						<legend class="screen-reader-text"><?php esc_html_e( 'Flat Rate Referral Basis', 'affiliate-wp' ); ?></legend>
						<?php foreach ( affwp_get_affiliate_flat_rate_basis_types() as $key => $type ) : // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- Legacy code. ?>
							<?php $value = esc_attr( $key ); ?>
							<label for="rate_type_<?php echo esc_attr( $value ); ?>">
								<input type="radio" name="flat_rate_basis" id="rate_type_<?php echo esc_attr( $value ); ?>" value="<?php echo esc_attr( $value ); ?>" <?php checked( $flat_rate_basis, $key ); ?>> <?php echo esc_html( $type ); ?>
							</label>
							<br/>
						<?php endforeach; ?>
					<p class="description"><?php esc_html_e( 'The affiliate&#8217;s flat rate referral basis.', 'affiliate-wp' ); ?></p>
					</fieldset>
				</td>

			</tr>

			<!-- Referral Rate -->
			<tr class="form-row">

				<th scope="row">
					<label for="rate"><?php esc_html_e( 'Referral Rate', 'affiliate-wp' ); ?></label>

					<?php if ( affwp_affiliate_has_affiliate_group_overrides( $affiliate->affiliate_id, 'rate' ) ) : ?>
						<?php
						$tooltip_html = affwp_tooltip(
							[
								'content' => __( 'This affiliate is in an affiliate group that has a custom rate setting which will override this as long as they remain in that affiliate group.', 'affiliate-wp' ),
								'type'    => 'warning',
							]
						);
						?>
					<span class="dashicons dashicons-warning cursor-help" data-tooltip-html="<?php echo esc_attr( $tooltip_html ); ?>"></span>
					<?php endif; ?>
				</th>

				<td>
					<input class="regular-text" type="number" name="rate" id="rate" step="0.01" min="0" max="999999999" placeholder="<?php echo esc_attr( $default_rate ); ?>" value="<?php echo esc_attr( $rate ); ?>"/>
					<p class="description"><?php esc_html_e( 'The affiliate&#8217;s referral rate, such as 20 for 20%. If left blank, the site default will be used.', 'affiliate-wp' ); ?></p>
				</td>

			</tr>

			<!-- / Rate Settings -->

			<?php if ( affwp_dynamic_coupons_is_setup() ) : ?>

				<tr class="form-row affwp-coupon-code-wrap">

					<th scope="row">
						<label for="dynamic_coupon"><?php esc_html_e( 'Dynamic Coupon', 'affiliate-wp' ); ?></label>
					</th>

					<td>

						<?php if ( ! empty( $dynamic_coupons ) ) : ?>
							<?php foreach ( $dynamic_coupons as $coupon ) : ?>
								<p class="flex items-center gap-2">
									<input class="medium-text" type="text" name="dynamic_coupon" id="dynamic_coupon" readonly value="<?php echo esc_attr( $coupon->coupon_code ); ?>" />
									<?php echo affwp_admin_link( 'affiliates', __( 'Delete Coupon', 'affiliate-wp' ), [ 'affiliate_id' => $affiliate->ID, 'action' => 'edit_affiliate', 'coupon_id' => $coupon->ID, 'delete_coupon' => 1, '_wpnonce' => wp_create_nonce( 'affwp_delete_coupon_' . $affiliate->ID . '_' . $coupon->ID ) ], [ 'class' => 'button' ] ); ?>
								</p>
							<?php endforeach; ?>
						<?php else : ?>
							<?php echo affwp_admin_link( 'affiliates', __( 'Generate Coupon', 'affiliate-wp' ), [ 'affiliate_id' => $affiliate->ID, 'action' => 'edit_affiliate', 'generate_coupon' => 1, '_wpnonce' => wp_create_nonce( 'affwp_generate_coupon_' . $affiliate->ID ) ], [ 'class' => 'button' ] ); ?>
						<?php endif; ?>

						<p class="description">
							<?php
							/* translators: Coupon settings tab URL */
							printf( __( 'The affiliate&#8217;s dynamic coupon will use the settings from the selected <a href="%s">coupon template</a>.', 'affiliate-wp' ), esc_url( affwp_admin_url( 'settings', [ 'tab' => 'coupons' ] ) ) );
							?>
						</p>

					</td>

				</tr>

			<?php endif; ?>

			<tr class="form-row">

				<th scope="row">
					<label for="account-email"><?php _e( 'Account Email', 'affiliate-wp' ); ?></label>
				</th>

				<td>
					<input class="regular-text" type="text" name="account_email" id="account-email" value="<?php echo esc_attr( $user_info->user_email ); ?>" />
					<p class="description"><?php _e( 'The affiliate&#8217;s account email. Updating this will change the email address shown on the user&#8217;s profile page.', 'affiliate-wp' ); ?></p>
				</td>

			</tr>

			<tr class="form-row">

				<th scope="row">
					<label for="send-email-summary"><?php esc_html_e( 'Emails', 'affiliate-wp' ); ?></label>
				</th>

				<td>
					<?php /* Marks this screen as the submitter, so an unticked box elsewhere never clears the value. */ ?>
					<input type="hidden" name="email_summary_submitted" value="1" />

					<label for="send-email-summary">
						<input type="checkbox" name="send_email_summary" id="send-email-summary" value="1" <?php checked( ! $summary_suppressed ); ?> />
						<?php esc_html_e( 'Send monthly email summaries', 'affiliate-wp' ); ?>
					</label>

					<p class="description">
						<?php esc_html_e( 'Turn this off to stop this affiliate&#8217;s monthly performance summary.', 'affiliate-wp' ); ?>

						<?php
						echo is_numeric( $summary_last_sent )
							? esc_html(
								sprintf(
									// Translators: %s is the date the last summary was sent to this affiliate.
									__( 'Last sent %s.', 'affiliate-wp' ),
									// The stamp is UTC (time()); wp_date() renders it in the site timezone.
									wp_date( get_option( 'date_format' ), (int) $summary_last_sent )
								)
							)
							: esc_html__( 'None sent yet.', 'affiliate-wp' );
						?>

						<?php if ( ! $summaries_deliverable ) : ?>
							<br />
							<?php
							printf(
								// Translators: %s is a link to the email settings tab.
								esc_html__( 'Summaries are not sending on this site. %s', 'affiliate-wp' ),
								sprintf(
									'<a href="%1$s">%2$s</a>',
									esc_url( affwp_admin_url( 'settings', array( 'tab' => 'emails' ) ) ),
									esc_html__( 'Review email settings', 'affiliate-wp' )
								)
							);
							?>
						<?php endif; ?>
					</p>
				</td>

			</tr>

			<tr class="form-row form-required">

				<th scope="row">
					<label for="payment_email"><?php _e( 'Payment Email', 'affiliate-wp' ); ?></label>
				</th>

				<td>
					<input class="regular-text" type="text" name="payment_email" id="payment_email" value="<?php echo esc_attr( $email ); ?>"/>
					<p class="description"><?php _e( 'Affiliate&#8217;s payment email for systems such as PayPal, Moneybookers, or others. Leave blank to use the affiliate&#8217;s user email.', 'affiliate-wp' ); ?></p>
				</td>

			</tr>

			<tr class="form-row">

				<th scope="row">
					<label for="payout_method_override"><?php _e( 'Payout Method', 'affiliate-wp' ); ?></label>
				</th>

				<td>
					<?php
					$display_methods = affwp_get_payout_methods_for_display();

					/*
					 * Preserve the override as a selectable option even if its method add-on was
					 * disabled since the admin set it, so the admin's choice isn't silently rewritten.
					 */
					if ( ! empty( $payout_method_override ) && ! isset( $display_methods[ $payout_method_override ] ) ) {
						$display_methods[ $payout_method_override ] = affwp_get_payout_method_display_label( $payout_method_override );
					}

					// Usable method vs stored pick/override — see affwp_get_affiliate_payout_method_admin_status_html().
					$resolved_line = affwp_get_affiliate_payout_method_admin_status_html( $affiliate->affiliate_id );
					?>

					<p style="margin: 0 0 0.5em;"><?php echo $resolved_line; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- pre-escaped above ?></p>

					<select name="payout_method_override" id="payout_method_override">
						<option value=""<?php selected( '', $payout_method_override ); ?>><?php esc_html_e( 'No override', 'affiliate-wp' ); ?></option>
						<?php foreach ( $display_methods as $method_key => $method_label ) : ?>
							<option value="<?php echo esc_attr( $method_key ); ?>"<?php selected( $method_key, $payout_method_override ); ?>>
								<?php echo esc_html( $method_label ); ?>
							</option>
						<?php endforeach; ?>
					</select>

					<p class="description"><?php esc_html_e( 'Override this affiliate&#8217;s payout method. They can&#8217;t change it while it&#8217;s set.', 'affiliate-wp' ); ?></p>
				</td>

			</tr>

			<?php if ( affiliate_wp()->settings->get( 'enable_payouts_service' ) ) : ?>

				<tr class="form-row form-required">

					<th scope="row">
						<label for="payment_email"><?php _e( 'Payout Method', 'affiliate-wp' ); ?></label>
					</th>
					<td>
						<?php if ( $payout_service_payout_method ) : ?>

							<?php if ( 'bank_account' === $payout_service_payout_method['payout_method'] ) : ?>

								<p>
									<?php
									/* translators: Bank name */
									printf( __( '<strong>Bank Name: </strong> %s', 'affiliate-wp' ), $payout_service_payout_method['bank_name'] );
									?>
								</p>
								<p>
									<?php
									/* translators: Account name */
									printf( __( '<strong>Account Holder Name: </strong> %s', 'affiliate-wp' ), $payout_service_payout_method['account_name'] );
									?>
								</p>
								<p>
									<?php
									/* translators: Account number */
									printf( __( '<strong>Account Number: </strong> %s', 'affiliate-wp' ), $payout_service_payout_method['account_no'] );
									?>
								</p>

							<?php else : ?>

								<p>
									<?php
									/* translators: Credit card used */
									printf( __( '<strong>Card: </strong> %s', 'affiliate-wp' ), $payout_service_payout_method['card'] );
									?>
								</p>
								<p>
									<?php
									/* translators: Credit card expiration date */
									printf( __( '<strong>Expiry: </strong> %s', 'affiliate-wp' ), $payout_service_payout_method['expiry'] );
									?>
								</p>

							<?php endif; ?>

						<?php endif; ?>
						<p class="description"><?php _e( 'Affiliate&#8217;s payout method details on the Payouts Service.', 'affiliate-wp' ); ?></p>
					</td>

				</tr>

				<tr class="form-row form-required">

					<th scope="row">
						<label for="kyc_status"><?php _e( 'Identity Verification', 'affiliate-wp' ); ?></label>
					</th>

					<td>
						<?php
						$value = '';
						if ( $payout_service_account && isset( $payout_service_account['kyc_status'] ) ) {
							$value = ucfirst( $payout_service_account['kyc_status'] );
						}
						echo esc_attr( $value );
						?>
						<p class="description"><?php _e( 'Affiliate&#8217;s identity verification status on the Payouts Service.', 'affiliate-wp' ); ?></p>
					</td>

				</tr>

				<tr class="form-row form-required">

					<th scope="row">
						<label for="kyc_link"><?php _e( 'Identity Verification Link', 'affiliate-wp' ); ?></label>
					</th>

					<td>
						<?php
						if ( $payout_service_account && isset( $payout_service_account['kyc_link'] ) ) {
							$kyc_link = $payout_service_account['kyc_link'];

							/* translators: 1: KYC URL, 2: descriptive alt text for the KYC link, 3: KYC link URL to be displayed */
							echo wp_sprintf(
								__( '<a href="%1$s" target="_blank" alt="%2$s">%3$s</a>', 'affiliate-wp' ),
								esc_url( $kyc_link ),
								esc_attr__( 'A link to the identity verification page on the Payouts Service', 'affiliate-wp' ),
								esc_url( $kyc_link )
							);
						}
						?>

						<p class="description"><?php _e( 'Affiliate&#8217;s identity verification link on the Payouts Service.', 'affiliate-wp' ); ?></p>
					</td>

				</tr>
			<?php endif; ?>

			<tr class="form-row form-required">

				<th scope="row">
					<label for="promotion_methods"><?php _e( 'Promotion Methods', 'affiliate-wp' ); ?></label>
				</th>

				<td>
					<textarea name="promotion_methods" rows="5" cols="50" id="promotion_methods" class="large-text" disabled="disabled"><?php echo esc_html( $promotion_method ); ?></textarea>
					<p class="description"><?php _e( 'Promotion methods entered by the affiliate during registration.', 'affiliate-wp' ); ?></p>
				</td>

			</tr>

			<?php if ( ! empty( $custom_fields ) ) : ?>

				<tr>

					<th scope="row">
						<label><?php esc_html_e( 'Additional Registration Info', 'affiliate-wp' ); ?></label>
					</th>

					<td>
						<table class="widefat striped affwp-table-additional-registration-info">
							<tbody>
								<?php foreach ( $custom_fields as $custom_field ) : ?>
									<?php
									// The block-based form fields are returned as an array, so we need to implode the values if the type is checkbox_multiple.
									if ( 'checkbox_multiple' === $custom_field['type'] ) {
										$custom_field['meta_value'] = implode( ', ', $custom_field['meta_value'] );
									}

									// The block-based form's checkbox fields return a string '1' if checked, so we need to convert that to a "Yes" string.
									if ( 'checkbox' === $custom_field['type'] || 'terms_of_use' === $custom_field['type'] ) {
										if ( '1' === $custom_field['meta_value'] ) {
											$custom_field['meta_value'] = _x( 'Yes', 'checkbox enabled', 'affiliate-wp' );
										}
									}
									?>
									<tr class="form-row">
										<td>
											<?php echo esc_html( wp_strip_all_tags( $custom_field['name'] ) ); ?>
										</td>
										<td>
											<?php
											$value = $custom_field['meta_value'];
											if ( empty( $value ) ) {
												echo '<em>' . esc_html__( 'Empty', 'affiliate-wp' ) . '</em>';
											} else {
												echo nl2br( make_clickable( esc_html( $value ) ) );
											}
											?>
										</td>
									</tr>
								<?php endforeach; ?>
							</tbody>
						</table>
					</td>

				</tr>
			<?php endif; // $custom_fields ?>

			<tr class="form-row">

				<th scope="row">
					<label for="notes"><?php esc_html_e( 'Notes', 'affiliate-wp' ); ?></label>
				</th>

				<td>
					<textarea name="notes" rows="5" cols="50" id="notes" class="large-text"><?php echo esc_html( $notes ); ?></textarea>
					<p class="description"><?php esc_html_e( 'Enter any notes for this affiliate. Notes are only visible to an affiliate manager.', 'affiliate-wp' ); ?></p>
				</td>

			</tr>

			<?php if ( 'rejected' == $affiliate->status && ! empty( $reason ) ) : ?>
				<tr class="form-row">

					<th scope="row">
						<label><?php _e( 'Rejection Reason', 'affiliate-wp' ); ?></label>
					</th>

					<td>
						<div class="description"><?php echo wpautop( $reason ); ?></div>
					</td>

				</tr>
			<?php endif; ?>

			<?php
			/**
			 * Fires at the end of the edit-affiliate admin screen form area, below form fields.
			 *
			 * @since 1.0
			 *
			 * @param \AffWP\Affiliate $affiliate The affiliate object being edited.
			 */
			do_action( 'affwp_edit_affiliate_end', $affiliate );
			?>

		</table>

		<?php
		/**
		 * Fires at the bottom of the edit-affiliate admin screen, just before the submit button.
		 *
		 * @since 1.0
		 *
		 * @param \AffWP\Affiliate $affiliate The affiliate object being edited.
		 */
		do_action( 'affwp_edit_affiliate_bottom', $affiliate );
		?>

		<input type="hidden" name="affwp_action" value="update_affiliate" />

		<?php wp_nonce_field( 'affwp_update_affiliate_nonce', 'affwp_update_affiliate_nonce' ); ?>

		<?php submit_button( __( 'Update Affiliate', 'affiliate-wp' ) ); ?>

	</form>

</div>
