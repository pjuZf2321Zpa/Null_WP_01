<?php
/**
 * Admin: View Affiliate View
 *
 * @package     AffiliateWP
 * @subpackage  Admin/Affiliates
 * @copyright   Copyright (c) 2014, Sandhills Development, LLC
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       1.2
 */

$affiliate_id = isset( $_GET['affiliate_id'] ) ? absint( $_GET['affiliate_id'] ) : 0;

?>
<div class="wrap">
	<h2>
		<?php
		/* translators: 1: Affiliate ID, 2: Affiliate name */
		printf( __( 'Affiliate: #%1$d %2$s', 'affiliate-wp' ), $affiliate_id, esc_html( affiliate_wp()->affiliates->get_affiliate_name( $affiliate_id ) ) );
		?>
	</h2>

	<?php
	/**
	 * Fires at the top of the view-affiliate report admin screen.
	 *
	 * @since 1.9
	 */
	do_action( 'affwp_view_affiliate_report_top' );
	?>

	<?php
	/*
	 * The Recent Payouts table re-uses AffWP_Payouts_Table and this screen
	 * renders the payout drawer (below), which mirrors the open payout into the
	 * URL as ?payout_id=X. WP_List_Table builds its pagination and sortable-column
	 * links from $_SERVER['REQUEST_URI'], so after a reload with that param present
	 * every page/sort link inherits it — paging then re-opens the same payout on
	 * each navigation. Strip it before the table renders; the drawer reads
	 * payout_id client-side from the address bar, so deep-linking is unaffected.
	 */
	if ( isset( $_GET['payout_id'] ) && ! empty( $_SERVER['REQUEST_URI'] ) ) {
		$_SERVER['REQUEST_URI'] = remove_query_arg( 'payout_id', $_SERVER['REQUEST_URI'] );
	}

	/*
	 * The checkbox column goes with the hidden bulk options — checkboxes that
	 * apply to nothing read as broken. Bulk work happens on the Payouts list
	 * filtered to this affiliate, which the status-view links lead to.
	 */
	$payouts_table = new AffWP_Payouts_Table( array(
		'query_args' => array(
			'affiliate_id' => $affiliate_id
		),
		'display_args' => array(
			'hide_bulk_options'    => true,
			'columns_to_hide'      => array( 'status', 'cb' ),
			'hide_column_controls' => true,
		),
	) );
	$payouts_table->prepare_items();
	?>
	<h2><?php _e( 'Recent Payouts', 'affiliate-wp' ); ?></h2>

	<?php $payouts_table->views(); ?>
	<?php $payouts_table->display(); ?>

	<?php
	/*
	 * Render the payout detail drawer markup on this screen too. The
	 * Recent Payouts table re-uses AffWP_Payouts_Table; each row's
	 * View link points at the payout detail drawer (intercepted client-
	 * side by affwp-payout-drawer.js when the drawer DOM is present on
	 * the same page). Without this call, the View link falls through
	 * as a regular navigation to the Payouts page, which then opens
	 * the drawer there — a two-step "navigate, then open" experience
	 * the admin doesn't want. The function is guarded by a static
	 * flag against double-rendering, so it's safe to call here.
	 */
	if ( function_exists( 'affwp_render_payout_drawer' ) ) {
		affwp_render_payout_drawer();
	}

	/**
	 * Fires at the bottom of view-affiliate-report screens.
	 *
	 * @since 1.9
	 */
	do_action( 'affwp_view_affiliate_report_bottom' );
	?>

</div>
