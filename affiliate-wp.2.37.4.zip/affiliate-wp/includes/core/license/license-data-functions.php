<?php
/**
 * License Functions
 *
 * @package     AffiliateWP
 * @subpackage  Core/Functions
 * @copyright   Copyright (c) 2023, Sandhills Development, LLC
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.15.0
 */
use AffWP\Core\License\License_Data;

/**
 * Checks if a license upgrade is required.
 *
 * @since 2.15.0
 *
 * @param string $license_level Minimum license level required. Default is 'plus'.
 * @return bool True if upgrade is required, false otherwise. Default is true.
 */
function affwp_is_upgrade_required( $license_level = 'plus' ) {
    // Get license data.
    $license_data = new License_Data();

    // Get license ID.
    $license_id = $license_data->get_license_id();

    if ( is_null( $license_id ) ) {
        return true;
    }

    // Get license type.
    $license_type = strtolower( $license_data->get_license_type( $license_id ) );

    // Check if license upgrade is required.
    if ( 'plus' === $license_level ) {
        return ! ( 'plus' === $license_type || 'professional' === $license_type || 'ultimate' === $license_type );
    } elseif ( 'professional' === $license_level || 'pro' === $license_level ) {
        return ! ( 'professional' === $license_type || 'ultimate' === $license_type );
    } elseif ( 'ultimate' === $license_level ) {
        return ! ( 'ultimate' === $license_type );
    }

    return true;
}

/**
 * Retrieve the license status.
 *
 * @since 2.17.0
 * @since 2.18.1 License_Data can return false, so removed string string return type.
 *
 * @return string|bool|mixed|void The license status (expired, invalid, valid)
 */
function affwp_get_license_status() {
	return ( new License_Data() )->check_status();
}

/**
 * Determines whether the user has access to the PRO features.
 *
 * This function not only checks if the user has a PRO license installed but also validates if it is currently valid.
 *
 * @since 2.17.0
 *
 * @return bool Whether the user has access to PRO features or not.
 */
function affwp_can_access_pro_features() : bool {
	return true !== affwp_is_upgrade_required( 'pro' ) && affwp_get_license_status() === 'valid';
}

/**
 * Determines whether the user has access to the Plus features.
 *
 * This function not only checks if the user has a Plus license installed but also validates if it is currently valid.
 *
 * @since 2.26.1
 *
 * @return bool Whether the user has access to PRO features or not.
 */
function affiliatewp_can_access_plus_features() : bool {
	return true !== affwp_is_upgrade_required() && affwp_get_license_status() === 'valid';
}

/**
 * Explains why the license server refused to activate a license key.
 *
 * @since 2.37.1
 *
 * @param string $error Error code from the license server's activation response.
 * @return string Message, with links to where the customer can act on it.
 */
function affiliatewp_get_license_error_message( string $error ) : string {

	$account_url = 'https://affiliatewp.com/account/?utm_campaign=admin&utm_source=licenses&utm_medium=' . rawurlencode( $error ? $error : 'missing' );

	switch ( $error ) {

		case 'no_activations_left':
			return sprintf(
				/* translators: %s: AffiliateWP account URL */
				__( 'This license key has reached its activation limit. Deactivate it on a site you no longer use, or manage your sites in your <a href="%s" target="_blank" rel="noopener noreferrer">AffiliateWP account</a>, then try again.', 'affiliate-wp' ),
				esc_url( $account_url )
			);

		case 'expired':
			return sprintf(
				/* translators: %s: License renewal URL */
				__( 'This license key has expired. <a href="%s" target="_blank" rel="noopener noreferrer">Renew your license</a> to activate it.', 'affiliate-wp' ),
				esc_url(
					add_query_arg(
						array(
							'edd_license_key' => License_Data::get_license_key(),
							'download_id'     => 17,
						),
						'https://affiliatewp.com/checkout'
					)
				)
			);

		case 'disabled':
		case 'revoked':
			return sprintf(
				/* translators: %s: AffiliateWP support URL */
				__( 'This license key has been disabled. <a href="%s" target="_blank" rel="noopener noreferrer">Contact support</a> for help.', 'affiliate-wp' ),
				esc_url( 'https://affiliatewp.com/contact/?utm_campaign=admin&utm_source=licenses&utm_medium=disabled' )
			);

		default:
			return sprintf(
				/* translators: %s: AffiliateWP account URL */
				__( 'This license key couldn&#8217;t be activated. Check that it matches the key in your <a href="%s" target="_blank" rel="noopener noreferrer">AffiliateWP account</a>, then try again.', 'affiliate-wp' ),
				esc_url( $account_url )
			);
	}
}

add_action( 'delete_transient_affwp_license_check', array( License_Data::class, 'forget_unsaved_status' ) );
