<?php
/**
 * License
 *
 * Handles the license functionality.
 *
 * @package     AffiliateWP
 * @subpackage  Core
 * @copyright   Copyright (c) 2021, Sandhills Development, LLC
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.9
 */

namespace AffWP\Core\License;

require_once AFFILIATEWP_PLUGIN_DIR . 'includes/core/license/license-data-functions.php';

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

#[\AllowDynamicProperties]

/**
 * Core class used to handle the License functionality from EDD.
 *
 * @since 2.9
 */
class License_Data {

	/**
	 * Statuses the license server gives about the license itself.
	 *
	 * The status check stores these, and an inconclusive check can fall back to them. Anything else
	 * describes the request (item_name_mismatch, invalid_item_id) rather than the license.
	 *
	 * @since 2.37.1
	 *
	 * @var string[]
	 */
	const KNOWN_STATUSES = array( 'valid', 'invalid', 'expired', 'disabled', 'site_inactive', 'inactive' );

	/**
	 * Status the license check settled on when it couldn't be cached.
	 *
	 * The transient fails to save when a concurrent request stored it first, or when the object cache
	 * is down, and every gate call would then ask the server again. Kept with the blog it belongs to
	 * and the time the transient would have expired.
	 *
	 * @since 2.37.1
	 *
	 * @var array|null
	 */
	private static $unsaved_status = null;

	/**
	 * Forgets a status that couldn't be cached, so the next check reads the transient again.
	 *
	 * @since 2.37.1
	 */
	public static function forget_unsaved_status() {
		self::$unsaved_status = null;
	}

	/**
	 * Caches a checked status, keeping it in memory when the transient can't be saved.
	 *
	 * @since 2.37.1
	 *
	 * @param string $status     License status, or '' when there is none.
	 * @param int    $expiration Seconds to cache it for.
	 */
	private static function cache_status( $status, $expiration ) {

		self::$unsaved_status = set_transient( 'affwp_license_check', $status, $expiration )
			? null
			: array(
				'status' => $status,
				'blog'   => get_current_blog_id(),
				'until'  => time() + $expiration,
			);
	}

	/**
	 * Returns the status kept in memory for this blog, if it hasn't expired.
	 *
	 * @since 2.37.1
	 *
	 * @return string|false
	 */
	private static function get_unsaved_status() {

		$unsaved = self::$unsaved_status;

		if ( ! is_array( $unsaved ) || get_current_blog_id() !== $unsaved['blog'] || time() >= $unsaved['until'] ) {
			return false;
		}

		return $unsaved['status'];
	}

	/**
	 * Returns the license ID if it was verified recently.
	 *
	 * @since 2.9.5
	 *
	 * @return int|null
	 */
	public function get_license_id() {
		// Get license data.
		$license_data = affiliate_wp()->settings->get( 'license_status', array() );

		if ( empty( $license_data ) ) {
			return null;
		}

		/*
		 * Settings::get() already normalizes this to an object, but stay tolerant of the
		 * array shape here too: this is the reader every tier gate funnels through, and
		 * reading price_id with object syntax only is what silently downgraded valid Pro
		 * licenses to Personal. See Affiliate_WP_Settings::normalize_license_status().
		 */
		$license_data = is_array( $license_data ) ? (object) $license_data : $license_data;

		if ( ! is_object( $license_data ) ) {
			return null;
		}

		$license_id = isset( $license_data->price_id ) ? intval( $license_data->price_id ) : null;

		return $license_id;
	}

	/**
	 * Returns the activation status for the given license key.
	 *
	 * @since 2.9 Adapted from the Settings class, save functionality extracted to other functions, and added license key param.
	 * @since 2.21.1 Added $force parameter.
	 *
	 * @param string $license_key License key.
	 * @return array Returns status with error info or license data.
	 */
	public function activation_status( string $license_key, bool $force = false ) {

		if ( ! $force ) {

			// Retrieve the license status from the database.
			$status = affiliate_wp()->settings->get( 'license_status' );

			if ( isset( $status->license ) ) {
				$status = $status->license;
			}

			if ( 'valid' === $status ) {
				return false; // License already activated and valid.
			}
		}

		$license_key = sanitize_text_field( $license_key );

		// Data to send in our API request.
		$api_params = array(
			'edd_action' => 'activate_license',
			'license'    => $license_key,
			'item_name'  => 'AffiliateWP',
			'url'        => home_url()
		);

		// Call the custom API.
		$response = wp_remote_get( 'https://affiliatewp.com/edd-sl-api', array(
			'timeout'   => 35,
			'sslverify' => affwp_sslverify(),
			'body'      => $api_params,
		) );

		$response_code = wp_remote_retrieve_response_code( $response );

		// Make sure the response came back okay.
		if ( is_wp_error( $response ) ) {
			return array(
				'license_status' => false,
				'affwp_notice'   => 'license-http-failure',
				'affwp_message'  => $response->get_error_message(),
			);
		}

		// Check response error code.
		if ( 200 !== $response_code ) {
			return array(
				'license_status' => false,
				'affwp_notice'   => 'license-http-failure',
				'affwp_message'  => wp_remote_retrieve_response_message( $response ),
			);
		}

		// Decode the license data.
		$license_data = json_decode( wp_remote_retrieve_body( $response ) );

		// A body without a status or an error (a firewall page, a bare message) says nothing about the license; saving it would wipe the activation.
		if ( ! is_object( $license_data ) || ( ! isset( $license_data->license ) && ! isset( $license_data->error ) ) ) {
			return array(
				'license_status' => false,
				'affwp_notice'   => 'license-http-failure',
				'affwp_message'  => __( 'The license server sent an unexpected response. Please try again later.', 'affiliate-wp' ),
			);
		}

		// Default to invalid when there is an error and license status isn't set.
		if ( isset( $license_data->error ) && ! isset( $license_data->license ) ) {

			// The license server words some refusals (a key that doesn't exist) instead of giving an error code; keep its words to show them.
			if ( ! is_string( $license_data->error ) || ! preg_match( '/^[a-z_]+$/', $license_data->error ) ) {
				$license_data->error_message = is_string( $license_data->error ) ? $license_data->error : '';
				$license_data->error         = 'item_name_mismatch';
			}

			$license_data->license = 'invalid';
		}

		// Save license data and key.
		affiliate_wp()->settings->set( array(
			'license_status' => $license_data,
			'license_key'    => $license_key,
		), true );

		// Set license check transient.
		if ( isset( $license_data->license ) ) {
			set_transient( 'affwp_license_check', $license_data->license, DAY_IN_SECONDS );
		}

		self::forget_unsaved_status();

		// Return license data.
		return array(
			'license_status' => true,
			'license_data'   => $license_data,
			'license_key'    => $license_key,
		);
	}

	/**
	 * Returns the deactivation status for the given license key.
	 *
	 * @since 2.9 Adapted from the Settings class and save functionality extracted to other functions.
	 * @return bool|array Returns true or array with error info.
	 */
	public function deactivation_status() {
		// Retrieve the license status from the database.
		$status = affiliate_wp()->settings->get( 'license_status' );

		if ( isset( $status->license ) ) {
			$status = $status->license;
		}

		if ( 'valid' !== $status ) {
			return false; // License already deactivated.
		}

		$license_key = self::get_license_key();

		// Data to send in our API request.
		$api_params = array(
			'edd_action' => 'deactivate_license',
			'license'    => $license_key,
			'item_name'  => 'AffiliateWP',
			'url'        => home_url(),
		);

		// Call the custom API.
		$response = wp_remote_get( 'https://affiliatewp.com/edd-sl-api', array(
			'timeout'   => 35,
			'sslverify' => affwp_sslverify(),
			'body'      => $api_params,
		) );

		// Make sure the response came back okay.
		if ( is_wp_error( $response ) ) {
			return array(
				'license_status' => false,
				'message'        => $response->get_error_message(),
			);
		}

		// Save updated license status.
		affiliate_wp()->settings->set( array( 'license_status' => 0 ), true );

		set_transient( 'affwp_license_check', 'deactivated', DAY_IN_SECONDS );

		self::forget_unsaved_status();

		return true;
	}

	/**
	 * Return if the license is active (saved) in our setting and is active.
	 *
	 * When using $this->check_status() the license will return as valid, even if
	 * the license is not saved. This method is an extra validation, so we can ensure
	 * that the license is actually saved in our DB.
	 *
	 * @since 2.21.1
	 *
	 * @return bool Whether the license is activated on this site or not.
	 */
	public function is_license_site_activated() : bool {

		$status = affiliate_wp()->settings->get( 'license_status' );

		/*
		 * Test the value, not just the key. The licensing API returns `success => false`
		 * alongside an error for a key that failed to activate, so `isset()` alone reported
		 * those as activated.
		 */
		return is_object( $status ) && ! empty( $status->success );
	}

	/**
	 * Retrieves the license key.
	 *
	 * If the `AFFILIATEWP_LICENSE_KEY` constant is defined, it will override values
	 * stored in the database.
	 *
	 * @since 1.9
	 * @access public
	 * @static
	 *
	 * @param string $key    Optional. License key to check. Default empty.
	 * @param bool   $saving Optional. Whether a saving operation is being performed. If true,
	 *                       the already-saved key value will be ignored. Default false.
	 * @return string License key.
	 */
	public static function get_license_key( $key = '', $saving = false ) {
		if ( defined( 'AFFILIATEWP_LICENSE_KEY' ) && AFFILIATEWP_LICENSE_KEY ) {
			$license = AFFILIATEWP_LICENSE_KEY;
		} elseif ( ! empty( $key ) || true === $saving ) {
			$license = $key;
		} else {
			$license = affiliate_wp()->settings->get( 'license_key' );
		}

		return trim( $license );
	}

	/**
	 * Checks validity of the license key.
	 *
	 * Only updates the stored license status if the response carries a status about the license itself.
	 * This prevents accidental license deactivation due to network issues or unexpected API responses.
	 *
	 * @since 1.0.0
	 * @since 2.9.0  Extracted this from the Settings class and updated name.
	 * @since 2.24.2 If the response fails, resulting in a `\WP_Error`, we've
	 *               fixed the transient for checking again to not store the
	 *               `\WP_Error` object, but store the current status until the
	 *               site finally responds.
	 * @since 2.27.2 Added HTTP response code check and status validation to prevent
	 *               accidental license deactivation during network issues.
	 * @since 2.37.1 An inconclusive check keeps the last status the license server gave this
	 *               site, and a response without a license level keeps the stored one.
	 *
	 * @param bool $force Optional. Whether to force checking the license (bypass caching).
	 * @return bool|mixed|void
	 */
	public function check_status( $force = false ) {
		$status = get_transient( 'affwp_license_check' );

		if ( false === $status && ! $force ) {
			$status = self::get_unsaved_status();
		}

		$request_url = 'https://affiliatewp.com/edd-sl-api';

		// Run the license check a maximum of once per day.
		if ( ( false === $status || $force ) && site_url() !== $request_url ) {

			// data to send in our API request.
			$api_params = array(
				'edd_action' => 'check_license',
				'license'    => self::get_license_key(),
				'item_name'  => 'AffiliateWP',
				'url'        => home_url(),
			);

			// Call the custom API.
			$response = wp_remote_get( $request_url, array(
				'timeout'   => 15,
				'sslverify' => affwp_sslverify(),
				'body'      => $api_params,
			) );

			$response_code = wp_remote_retrieve_response_code( $response );

			// Handle request errors or invalid response codes.
			if ( is_wp_error( $response ) || 200 !== $response_code ) {
				return $this->keep_last_known_status( $status );
			}

			$license_data = json_decode( wp_remote_retrieve_body( $response ) );

			$new_status = isset( $license_data->license ) ? $license_data->license : '';

			// No status about the license itself (a firewall page, an empty body, item_name_mismatch) says nothing about it.
			if ( ! in_array( $new_status, self::KNOWN_STATUSES, true ) ) {
				return $this->keep_last_known_status( $status );
			}

			$status = $new_status;

			$stored = affiliate_wp()->settings->get( 'license_status' );

			// A valid or expired check response can leave out the license level; dropping it would read as Personal after a renewal.
			if ( in_array( $status, array( 'valid', 'expired' ), true ) && ! is_numeric( $license_data->price_id ?? null ) && is_numeric( $stored->price_id ?? null ) ) {
				$license_data->price_id = $stored->price_id;
			}

			affiliate_wp()->settings->set( array( 'license_status' => $license_data ), true );

			self::cache_status( $status, DAY_IN_SECONDS );
		}

		return '' === $status ? false : $status;
	}

	/**
	 * Falls back to the last status the license server gave this site when a check is inconclusive.
	 *
	 * A failed request, a non-200 response or a body without a status about the license says nothing about it,
	 * so the site keeps the status the License screen already shows (the cached check, else the
	 * stored activation) instead of losing access to its features. The result is cached for three
	 * hours, an empty string when there is nothing to keep, so every caller doesn't retry the request.
	 *
	 * @since 2.37.1
	 *
	 * @param string|false $cached Cached status, set only when the check was forced.
	 * @return string|false The last known status, or false when there is none.
	 */
	private function keep_last_known_status( $cached ) {

		$stored = affiliate_wp()->settings->get( 'license_status' );
		$status = $cached;

		if ( ! in_array( $status, self::KNOWN_STATUSES, true ) ) {
			$status = is_object( $stored ) && in_array( $stored->license ?? '', self::KNOWN_STATUSES, true )
				? $stored->license
				: '';
		}

		// A valid status the server never confirmed for this site, or for no key at all, isn't worth keeping.
		if ( 'valid' === $status && ( ! $this->is_license_site_activated() || '' === self::get_license_key() ) ) {
			$status = '';
		}

		// Past the expiry date the server last gave, keep the features locked, but quietly: the customer may have renewed since.
		if ( 'valid' === $status && $this->has_expired( $stored->expires ?? '' ) ) {
			$status = '';
		}

		self::cache_status( $status, 3 * HOUR_IN_SECONDS );

		return '' === $status ? false : $status;
	}

	/**
	 * Whether a license expiry date from the license server has passed.
	 *
	 * Activation returns 'lifetime' or a date string, the status check a Unix timestamp.
	 *
	 * @since 2.37.1
	 *
	 * @param mixed $expires Expiry from the stored license status.
	 * @return bool True when the date is known and in the past.
	 */
	private function has_expired( $expires ) {

		if ( is_numeric( $expires ) ) {
			$timestamp = (int) $expires;
		} elseif ( is_string( $expires ) && '' !== $expires && 'lifetime' !== strtolower( $expires ) ) {
			$date      = date_create( $expires, new \DateTimeZone( 'UTC' ) );
			$timestamp = $date ? $date->getTimestamp() : 0;
		} else {
			return false;
		}

		// Zero, the Unix epoch or an all-zero date means no date was set.
		return $timestamp > 0 && $timestamp < time();
	}

	/**
	 * Returns whether the license key is valid or not.
	 *
	 * @since 2.9 Extracted this from the Settings class.
	 * @return bool
	 */
	public function is_license_valid() {
		return 'valid' === $this->check_status();
	}

	/**
	 * Returns the type of the license.
	 *
	 * @since 2.9
	 *
	 * @param int $license_id License id.
	 * @return string Personal, Plus, Professional, or Ultimate
	 */
	public function get_license_type( $license_id ) {
		if ( 0 === $license_id ) {
			$license_type = 'Personal';
		} elseif ( 1 === $license_id ) {
			$license_type = 'Plus';
		} elseif ( 2 === $license_id ) {
			$license_type = 'Professional';
		} elseif ( 3 === $license_id ) {
			$license_type = 'Ultimate';
		} else {
			$license_type = '';
		}

		return $license_type;
	}

}
