<?php
/**
 * Emails: Action Callbacks
 *
 * @package     AffiliateWP
 * @subpackage  Emails
 * @copyright   Copyright (c) 2015, Sandhills Development, LLC
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       1.6
 */

// phpcs:disable PEAR.Functions.FunctionCallSignature.EmptyLine -- Formatting this was is ok here.
// phpcs:disable PEAR.Functions.FunctionCallSignature.FirstArgumentPosition -- Formatting this was is ok here.

// Exit if accessed directly
if( ! defined( 'ABSPATH' ) ) exit;

/**
 * Sends an admin email on affiliate registration
 *
 * @since 1.6
 * @param int $affiliate_id The ID of the registered affiliate
 * @param string $status
 * @param array $args
 * @return void
 */
function affwp_notify_on_registration( $affiliate_id = 0, $status = '', $args = array() ) {

	if ( ! affwp_email_notification_enabled( 'admin_affiliate_registration_email' ) ) {
		return;
	}

	if( empty( $affiliate_id ) || empty( $status ) ) {
		return;
	}

	$emails           = new Affiliate_WP_Emails;
	$emails->__set( 'affiliate_id', $affiliate_id );

	$admin_email      = affiliate_wp()->settings->get( 'affiliate_manager_email', get_option( 'admin_email' ) );

	/**
	 * Filters the registration admin email address.
	 *
	 * @since 1.6
	 *
	 * @param string $admin_email Admin email address.
	 */
	$email            = apply_filters( 'affwp_registration_admin_email', $admin_email );
	$subject          = affiliate_wp()->settings->get( 'registration_subject', affwp_get_email_default( 'registration' )['subject'] );
	$message          = affiliate_wp()->settings->get( 'registration_email', affwp_get_email_default( 'registration' )['body'] );

	// $args is setup for backwards compatibility with < 1.6
	$args    = array( 'affiliate_id' => $affiliate_id, 'name' => $args['display_name'] );

	/**
	 * Filters the registration email subject.
	 *
	 * @since 1.6
	 *
	 * @param string $subject Email subject.
	 * @param array  $args    Arguments for sending the registration email.
	 */
	$subject = apply_filters( 'affwp_registration_subject', $subject, $args );

	/**
	 * Filters the registration email message.
	 *
	 * @since 1.6
	 *
	 * @param string $message Email message.
	 * @param array  $args    Arguments for sending the registration email.
	 */
	$message = apply_filters( 'affwp_registration_email', $message, $args );

	$emails->send( $email, $subject, $message );

}
add_action( 'affwp_register_user', 'affwp_notify_on_registration', 10, 3 );
add_action( 'affwp_auto_register_user', 'affwp_notify_on_registration', 10, 3 );


/**
 * Sends affiliate an email on affiliate approval
 *
 * @since 1.6
 * @param int $affiliate_id The ID of the registered affiliate
 * @param string $status
 * @param string $old_status
 */
function affwp_notify_on_approval( $affiliate_id = 0, $status = '', $old_status = '' ) {

	if ( ! affwp_email_notification_enabled( 'affiliate_application_accepted_email' ) ) {
		return;
	}

	if( empty( $affiliate_id ) || 'active' !== $status ) {
		return;
	}

	/*
	 * Skip sending the acceptance email for a now-'active' affiliate under
	 * certain conditions:
	 *
	 * 1. The affiliate was previously of 'inactive' or 'rejected' status.
	 * 2. The affiliate was previously of 'pending' status, where the status
	 *    transition wasn't triggered by a registration.
	 * 3. The affiliate's 'active' status didn't change, and the status
	 *    "transition" wasn't triggered by a registration, i.e. the affiliate
	 *    was updated in a bulk action and the 'active' status didn't change.
	 */
	if ( ! in_array( $old_status, array( 'active', 'pending' ), true )
		&& ! did_action( 'affwp_affiliate_register' )
	) {
		return;
	}

	if( doing_action( 'affwp_add_affiliate' ) && empty( $_POST['welcome_email'] ) ) {
		return;
	}

	$emails       = new Affiliate_WP_Emails;
	$emails->__set( 'affiliate_id', $affiliate_id );

	$email        = affwp_get_affiliate_email( $affiliate_id );
	$subject      = affiliate_wp()->settings->get( 'accepted_subject', affwp_get_email_default( 'accepted' )['subject'] );
	$message      = affiliate_wp()->settings->get( 'accepted_email', affwp_get_email_default( 'accepted' )['body'] );

	// $args is setup for backwards compatibility with < 1.6
	$args        = array( 'affiliate_id' => $affiliate_id );

	/**
	 * Filters the Application Accepted email subject.
	 *
	 * @since 1.6
	 *
	 * @param string $subject Email subject.
	 * @param array  $args    Arguments for sending the email.
	 */
	$subject     = apply_filters( 'affwp_application_accepted_subject', $subject, $args );

	/**
	 * Filters the Application Accepted email message.
	 *
	 * @since 1.6
	 *
	 * @param string $message Email message contents.
	 * @param array  $args    Arguments for sending the email.
	 */
	$message     = apply_filters( 'affwp_application_accepted_email', $message, $args );
	$user_id     = affwp_get_affiliate_user_id( $affiliate_id );

	/*
	 * Link accounts created with the affiliate in this request: by affwp_add_affiliate() from
	 * any caller (admin form, abilities), or by a signup-widget claim, which logs guests in once.
	 */
	$is_widget_claim = doing_action( 'wp_ajax_affiliate_signup' ) || doing_action( 'wp_ajax_nopriv_affiliate_signup' );

	if ( true === (bool) get_user_meta( $user_id, 'affwp_generated_pass', true )
		&& ( affwp_affiliate_user_created_in_request( $user_id ) || $is_widget_claim )
	) {

		$key        = get_password_reset_key( get_user_by( 'id', $user_id ) );
		$user_login = affwp_get_affiliate_username( $affiliate_id );

		if ( ! is_wp_error( $key ) ) {
			$message .= "\r\n\r\n" . __( 'To set your password, visit the following address:', 'affiliate-wp' ) . "\r\n\r\n";
			$message .= affiliate_wp()->login->get_reset_password_url( $key, $user_login ) . "\r\n";
		}

	}

	if ( true === (bool) get_user_meta( $user_id, 'affwp_generated_pass', true ) && affiliate_wp()->settings->get( 'allow_affiliate_registration' ) && doing_action( 'affwp_affiliate_register' ) ) {

		$key                          = get_password_reset_key( get_user_by( 'id', $user_id ) );
		$user_login                   = affwp_get_affiliate_username( $affiliate_id );
		$required_registration_fields = affiliate_wp()->settings->get( 'required_registration_fields' );

		if ( ! is_wp_error( $key ) && ! isset( $required_registration_fields['password'] ) ) {
			$message .= "\r\n\r\n" . __( 'To set your password, visit the following address:', 'affiliate-wp' ) . "\r\n\r\n";
			$message .= affiliate_wp()->login->get_reset_password_url( $key, $user_login ) . "\r\n";
		}

	}

	/**
	 * Filters whether to notify an affiliate upon approval of their application.
	 *
	 * @since 1.6
	 *
	 * @param bool $notify Whether to notify the affiliate upon approval. Default true.
	 */
	if ( apply_filters( 'affwp_notify_on_approval', true ) && ! get_user_meta( $user_id, 'affwp_disable_affiliate_email', true ) ) {
		$emails->send( $email, $subject, $message );
	}

}
add_action( 'affwp_set_affiliate_status', 'affwp_notify_on_approval', 10, 3 );

/**
 * Sends affiliate an email on pending affiliate registration
 *
 * @since 1.6.1
 * @param int $affiliate_id The ID of the registered affiliate
 * @param string $status
 * @param array $args
 */
function affwp_notify_on_pending_affiliate_registration( $affiliate_id, $status, $args ) {

	if ( ! affwp_email_notification_enabled( 'affiliate_application_pending_email' ) ) {
		return;
	}

	if ( empty( $affiliate_id ) || empty( $status ) ) {
		return;
	}

	if ( 'pending' != $status ) {
		return;
	}

	$emails       = new Affiliate_WP_Emails;
	$emails->__set( 'affiliate_id', $affiliate_id );

	$email        = affwp_get_affiliate_email( $affiliate_id );
	$subject      = affiliate_wp()->settings->get( 'pending_subject', affwp_get_email_default( 'pending' )['subject'] );
	$message      = affiliate_wp()->settings->get( 'pending_email', affwp_get_email_default( 'pending' )['body'] );

	$required_registration_fields = affiliate_wp()->settings->get( 'required_registration_fields' );

	$user_id     = affwp_get_affiliate_user_id( $affiliate_id );
	$key         = get_password_reset_key( get_user_by( 'id', $user_id ) );
	$user_login  = affwp_get_affiliate_username( $affiliate_id );

	if ( true === (bool) get_user_meta( $user_id, 'affwp_generated_pass', true ) && ! is_wp_error( $key ) && ! isset( $required_registration_fields['password'] ) ) {
		$message .= "\r\n\r\n" . __( 'To set your password, visit the following address:', 'affiliate-wp' ) . "\r\n\r\n";
		$message .= affiliate_wp()->login->get_reset_password_url( $key, $user_login ) . "\r\n";
	}

	/**
	 * Filters whether to notify the affiliate upon pending registration.
	 *
	 * @since 1.6.1
	 *
	 * @param bool $send Whether to send the pending affiliate registration email.
	 */
	if ( apply_filters( 'affwp_notify_on_pending_affiliate_registration', true ) ) {
		$emails->send( $email, $subject, $message );
	}

}
add_action( 'affwp_register_user', 'affwp_notify_on_pending_affiliate_registration', 10, 3 );
add_action( 'affwp_auto_register_user', 'affwp_notify_on_pending_affiliate_registration', 10, 3 );

/**
 * Sends affiliate an email on rejected affiliate registration
 *
 * @since 1.6.1
 * @param int $affiliate_id The ID of the registered affiliate
 * @param string $status
 * @param string $old_status
 */
function affwp_notify_on_rejected_affiliate_registration( $affiliate_id = 0, $status = '', $old_status = '' ) {

	if ( ! affwp_email_notification_enabled( 'affiliate_application_rejected_email' ) ) {
		return;
	}

	if ( empty( $affiliate_id ) ) {
		return;
	}

	if ( 'rejected' != $status || 'pending' != $old_status ) {
		return;
	}

	$emails       = new Affiliate_WP_Emails;
	$emails->__set( 'affiliate_id', $affiliate_id );

	$email        = affwp_get_affiliate_email( $affiliate_id );
	$subject      = affiliate_wp()->settings->get( 'rejection_subject', affwp_get_email_default( 'rejection' )['subject'] );
	$message      = affiliate_wp()->settings->get( 'rejection_email', affwp_get_email_default( 'rejection' )['body'] );

	/**
	 * Filters whether to notify the affiliate upon rejected registration.
	 *
	 * @since 1.6.1
	 *
	 * @param bool $send Whether to send the rejected affiliate registration email.
	 */
	if ( apply_filters( 'affwp_notify_on_rejected_affiliate_registration', true ) ) {
		$emails->send( $email, $subject, $message );
	}

}
add_action( 'affwp_set_affiliate_status', 'affwp_notify_on_rejected_affiliate_registration', 10, 3 );

/**
 * Sends affiliate an email on new referrals
 *
 * @since 1.6
 * @param int $affiliate_id The ID of the registered affiliate
 * @param array $referral
 */
function affwp_notify_on_new_referral( $affiliate_id, $referral ) {

	if( empty( $affiliate_id ) ) {
		return;
	}

	if( empty( $referral ) ) {
		return;
	}

	if ( ! affwp_email_notification_enabled( 'affiliate_new_referral_email', $affiliate_id ) ) {
		return;
	}

	$user_id = affwp_get_affiliate_user_id( $affiliate_id );

	if( ! get_user_meta( $user_id, 'affwp_referral_notifications', true ) ) {
		return;
	}

	$emails  = new Affiliate_WP_Emails;
	$emails->__set( 'affiliate_id', $affiliate_id );
	$emails->__set( 'referral', $referral );

	$email   = affwp_get_affiliate_email( $affiliate_id );
	$subject = affiliate_wp()->settings->get( 'referral_subject', affwp_get_email_default( 'referral' )['subject'] );
	$message = affiliate_wp()->settings->get( 'referral_email', affwp_get_email_default( 'referral' )['body'] );

	// $args is setup for backwards compatibility with < 1.6
	$args    = array( 'affiliate_id' => $affiliate_id, 'amount' => $referral->amount, 'referral' => $referral );

	/**
	 * Filters the subject for the New Referral email.
	 *
	 * @since 1.6
	 *
	 * @param string $subject Email subject.
	 * @param array  $args    Arguments for sending the email.
	 */
	$subject = apply_filters( 'affwp_new_referral_subject', $subject, $args );

	/**
	 * Filters the message contents for the New Referral email.
	 *
	 * @since 1.6
	 *
	 * @param string $message Email subject.
	 * @param array  $args    Arguments for sending the email.
	 */
	$message = apply_filters( 'affwp_new_referral_email', $message, $args );

	/**
	 * Filters whether to notify the affiliate with the New Referral email.
	 *
	 * @since 1.6
	 *
	 * @param bool            $send     Whether to send the email.
	 * @param \AffWP\Referral $referral Referral object.
	 */
	if ( apply_filters( 'affwp_notify_on_new_referral', true, $referral ) ) {
		$emails->send( $email, $subject, $message );
	}


}
add_action( 'affwp_referral_accepted', 'affwp_notify_on_new_referral', 10, 2 );

/**
 * Sends an email to admins on when a new referral is generated.
 *
 * @since 2.1.7
 *
 * @param int             $affiliate_id The ID of the registered affiliate
 * @param \AffWP\Referral $referral     Referral object.
 */
function affwp_notify_admin_on_new_referral( $affiliate_id, $referral ) {

	if( empty( $affiliate_id ) ) {
		return;
	}

	if( empty( $referral ) ) {
		return;
	}

	$send = affwp_email_notification_enabled( 'admin_new_referral_email', $affiliate_id );

	/**
	 * Filters whether to notify admins when a new referral is generated.
	 *
	 * @since 2.1.7
	 *
	 * @param bool            $send     Whether to send the email. Default false.
	 * @param \AffWP\Referral $referral Referral object.
	 */
	if( true !== apply_filters( 'affwp_notify_admin_on_new_referral', $send, $referral ) ) {
		return;
	}

	$emails  = new Affiliate_WP_Emails;
	$emails->__set( 'affiliate_id', $affiliate_id );
	$emails->__set( 'referral', $referral );

	$subject = affiliate_wp()->settings->get( 'new_admin_referral_subject', affwp_get_email_default( 'new_admin_referral' )['subject'] );
	$message = affiliate_wp()->settings->get( 'new_admin_referral_email', affwp_get_email_default( 'new_admin_referral' )['body'] );

	/**
	 * Filters the subject field for the email sent to admins when a new referral is generated.
	 *
	 * @since 2.1.7
	 *
	 * @param string          $subject      Email subject.
	 * @param int             $affiliate_id Affiliate ID.
	 * @param \AffWP\Referral $referral     Referral object.
	 */
	$subject = apply_filters( 'affwp_new_admin_referral_subject', $subject, $affiliate_id, $referral );

	/**
	 * Filters the message body for the email sent to admins when a new referral is generated.
	 *
	 * @since 2.1.7
	 *
	 * @param string          $message      Email message body.
	 * @param int             $affiliate_id Affiliate ID.
	 * @param \AffWP\Referral $referral     Referral object.
	 */
	$message = apply_filters( 'affwp_new_admin_referral_email', $message, $affiliate_id, $referral );

	$admin_email = affiliate_wp()->settings->get( 'affiliate_manager_email', get_option( 'admin_email' ) );

	/**
	 * Filters the recipient email address for the email sent to admins when a new referral is generated.
	 *
	 * @since 2.1.7
	 *
	 * @param string          $admin_email  Recipient email. Default is the value of the 'admin_email' option.
	 * @param int             $affiliate_id Affiliate ID.
	 * @param \AffWP\Referral $referral     Referral object.
	 */
	$to_email = apply_filters( 'affwp_new_admin_referral_email_to', $admin_email, $affiliate_id, $referral );

	$emails->send( $to_email, $subject, $message );

}
add_action( 'affwp_referral_accepted', 'affwp_notify_admin_on_new_referral', 10, 2 );

/**
 * Have we checked referrals once for the first Email Summary?
 *
 * @since 2.10.0
 *
 * @return bool
 */
function affwp_monthly_email_summary_referral_checkonce() {

	$option_key = 'affwp_email_summary_referral_checkonce';

	// Note, if you want to filter this, use the option_{$option} filter.
	$check = get_option( $option_key, false );

	if ( false === $check ) {

		// Note we checked it once with a timestamp.
		update_option( $option_key, time(), false );

		return false;
	}

	return true; // Our option was not false, so we must have checked referral count at least once.
}

/**
 * Monthly Email Summary.
 *
 * @since 2.9.6
 *
 * @param bool $preview Set to true to build email instead of send (for previewing).
 *
 * @see affwp_get_monthly_email_summary_content() For Email Content Body.
 *
 * @return void
 */
function affwp_notify_monthly_email_summary( $preview = false ) {

	if ( ! $preview && false !== affiliate_wp()->settings->get( 'disable_monthly_email_summaries', false ) ) {
		return; // You are wanting to email this summary, but a setting has disabled it.
	}

	// Don't schedule until they have at least one referral.
	if (

		// This function will return false only the first time it's ever run, after that we won't care if they have no referrals.
		false === affwp_monthly_email_summary_referral_checkonce() &&

		// We don't have any referrals yet.
		0 === affiliate_wp()->referrals->get_referrals(
			array(
				'number' => 1,
				'fields' => 'ids',
			),
			true
		)
	) {
		return;
	}

	// Send the email...
	affwp_email_summary(

		// Name of summary.
		'monthly_email',

		// To.
		affiliate_wp()->settings->get( 'affiliate_manager_email', get_option( 'admin_email' ) ),

		// Translators: This is the subject of the email, %1$s is url of the website (note to developers, this subject may not work in Mailhog, see: https://github.com/awesomemotive/AffiliateWP/pull/4410#issuecomment-1226079496 ).
		sprintf( __( 'Your Monthly AffiliateWP Summary for %s', 'affiliate-wp' ), str_replace( array( 'https://', 'http://' ), '', get_option( 'home', 'your site' ) ) ),

		// Content.
		affwp_get_monthly_email_summary_content(

			/**
			 * Filter the time frame for the data we are emailing.
			 *
			 * @since 2.9.6
			 *
			 * @param array $timeframe {
			 *    Arguments for start/end timeframe.
			 *
			 *    @type string $start Start in Y-m-d format.
			 *    @type string $end   End in Y-m-d format.
			 * }
			 */
			apply_filters(
				'affwp_notify_monthly_email_summary_timeframe',
				array(

					// Note, with AFFILIATE_WP_DEBUG enabled, you can override the YYYY-MM-DD format here using "?start=&end=", e.g. &start=2021-01-01&end=2022-08-05.
					'start' => ( isset( $_GET['start'] ) && defined( 'AFFILIATE_WP_DEBUG' ) && AFFILIATE_WP_DEBUG ) ? $_GET['start'] : gmdate( 'Y-m-d', strtotime( '-30 days' ) ), // phpcs:ignore WordPress.Security.NonceVerification.Recommended  -- No sanitization necessary here, just for development.
					'end'   => ( isset( $_GET['end'] ) && defined( 'AFFILIATE_WP_DEBUG' ) && AFFILIATE_WP_DEBUG ) ? $_GET['end'] : gmdate( 'Y-m-d', strtotime( 'today' ) ), // phpcs:ignore WordPress.Security.NonceVerification.Recommended  -- No sanitization necessary here, just for development.
				)
			)
		),

		// Data.
		array(

			// Note the DYK blurb we send with this email (a hook later will remember it was sent when email sends).
			'dyk_blurb' => affwp_get_latest_unsent_dyk_blurb_for_my_license(),
		),

		// Preview (false sends the email, true does not).
		$preview
	);
}
add_action(

	// Send the Summary email.
	'affwp_monthly_email_summaries', // See includes/class-affwp-scheduler.php.
	'affwp_notify_monthly_email_summary'
);

/**
 * Preview the Monthly Summary email.
 *
 * @since 2.9.6
 *
 * @return void
 */
function affwp_preview_monthly_email_summary() {

	if ( ! affwp_is_summary_email_preview( 'monthly_email' ) ) {
		return; // We are not requesting a preview of the monthly admin performance email.
	}

	// Preview the email.
	affwp_notify_monthly_email_summary( true );
}
add_action( 'admin_init', 'affwp_preview_monthly_email_summary' );

/**
 * Don't send DYK blurb again.
 *
 * @since 2.9.6
 *
 * @param  bool  $sent If we sent the email (with a blurb).
 * @param  array $data Data (that has the blurb sent in it).
 * @return void
 */
function affwp_remember_sent_dyk_blurb( $sent, $data ) {

	if ( ! $sent || ! isset( $data['dyk_blurb']['id'] ) ) {
		return; // No blurb with this email.
	}

	// If we had a blurb sent along with it, remember that we sent it.
	affwp_add_sent_dyk_blurb( $data['dyk_blurb']['id'] );
}
add_action( 'affwp_notify_monthly_email_summary_email_sent', 'affwp_remember_sent_dyk_blurb', 10, 2 );

/**
 * Preview the Monthly Affiliate Summary email.
 *
 * @since 2.9.7
 *
 * @return void
 */
function affwp_preview_monthly_affiliate_email_summary() {

	if ( ! affwp_is_summary_email_preview( 'monthly_affiliate_email' ) ) {
		return; // We are not requesting a preview of the monthly admin performance email.
	}

	// Preview the email.
	affwp_notify_monthly_affiliate_email_summary( true );
}
add_action( 'admin_init', 'affwp_preview_monthly_affiliate_email_summary' );

/**
 * Monthly Affiliate Email Summary.
 *
 * @since 2.9.7
 *
 * @param bool $preview Set to true to build email instead of send (for previewing).
 *
 * @return void
 */
function affwp_notify_monthly_affiliate_email_summary( $preview = false ) {

	if ( $preview ) {

		// Preview the first affiliate and stop (will die()).
		affwp_email_summary(

			// Name of summary.
			'monthly_affiliate_email',

			// To.
			'nobody@example.com',

			// Subject.
			sprintf(
				// Translators: %1$s is the site.
				__( 'Your Monthly Summary for %1$s', 'affiliate-wp' ),
				// Show the site label for %1$s (the site).
				str_replace(
					array( 'https://', 'http://' ),
					'', // Replace with nothing.
					get_option( 'home' )
				)
			),

			// Content.
			affwp_get_monthly_affiliate_email_summary_content( -1, array() ),

			// Data (none).
			array(),

			// Preview.
			true,

			// Template.
			'affiliate-summary'
		);

		return;
	}

	if ( is_multisite() ) {

		affiliate_wp()->utils->log(
			__( 'Cound not send affiliate email summaries because it is not supported on multisite.', 'affiliate-wp' )
		);

		return;
	}

	if ( true !== affwp_is_affiliate_email_summaries_enabled() ) {

		affiliate_wp()->utils->log(
			__( 'Cound not send affiliate email summaries because it has not been enabled.', 'affiliate-wp' )
		);

		return; // You are wanting to email this summary, but a setting is not enabled.
	}

	if ( false === affwp_is_outgoing_mail_configured() ) {

		affiliate_wp()->utils->log(
			__( 'Could not send affiliate email summaries because no configured SMTP or email service plugin was found to send them.', 'affiliate-wp' )
		);

		return; // Summaries need a configured mailer, not PHP mail().
	}

	if ( affwp_affiliate_email_summaries_awaiting_confirmation() ) {

		affiliate_wp()->utils->log(
			__( 'Could not send affiliate email summaries because they are paused until an admin starts them.', 'affiliate-wp' )
		);

		return;
	}

	// Start sending email now, plus an offset to give them a chance to cancel.
	$timing = time() +
		absint(
			/**
			 * Filter the initial offset before sending individual affiliate email summaries.
			 *
			 * @since 2.9.7
			 *
			 * @param int Offset in seconds.
			 */
			apply_filters(
				'monthly_affiliate_email_summary_initial_timing_offset',
				MINUTE_IN_SECONDS * 15
			)
		);

	// Loop over all the affiliates and schedule/send emails (or maybe preview one)...
	foreach (

		// Affiliates...
		affiliate_wp()->affiliates->get_affiliates(
			array(
				'number' => -1,
				'status' => 'active',
				'fields' => 'ids',
			)
		)
	as $affiliate_id ) {

		// Skip before the timing offset advances, so a skipped affiliate never holds a send slot.
		if ( ! affwp_is_affiliate_due_email_summary( $affiliate_id, true ) ) {
			continue;
		}

		$subject = sprintf(
			// Translators: %1$s is the site.
			__( 'Your Monthly Summary for %1$s', 'affiliate-wp' ),
			// Show the site label for %1$s (the site).
			str_replace(
				array( 'https://', 'http://' ),
				'', // Replace with nothing.
				get_option( 'home' )
			)
		);

		$content = affwp_get_monthly_affiliate_email_summary_content(
			$affiliate_id,

			/**
			 * Filter the time frame for the data we are emailing.
			 *
			 * @since 2.9.7
			 *
			 * @param array $timeframe {
			 *    Arguments for start/end timeframe.
			 *
			 *    @type string $start Start in Y-m-d format.
			 *    @type string $end   End in Y-m-d format.
			 * }
			 */
			apply_filters(
				'affwp_notify_monthly_affiliate_email_summary_timeframe',
				array(

					// Note, with AFFILIATE_WP_DEBUG enabled, you can override the YYYY-MM-DD format here using "?start=&end=", e.g. &start=2021-01-01&end=2022-08-05.
					'start' => ( isset( $_GET['start'] ) && defined( 'AFFILIATE_WP_DEBUG' ) && AFFILIATE_WP_DEBUG ) ? $_GET['start'] : gmdate( 'Y-m-d', strtotime( '-30 days' ) ), // phpcs:ignore WordPress.Security.NonceVerification.Recommended  -- No sanitization necessary here, just for development.
					'end'   => ( isset( $_GET['end'] ) && defined( 'AFFILIATE_WP_DEBUG' ) && AFFILIATE_WP_DEBUG ) ? $_GET['end'] : gmdate( 'Y-m-d', strtotime( 'today' ) ), // phpcs:ignore WordPress.Security.NonceVerification.Recommended  -- No sanitization necessary here, just for development.
				)
			)
		);

		if ( empty( $content ) ) {
			continue; // Need something to send them, we must not have been able to determine an affiliate.
		}

		/**
		 * Filter the interval for sending each affiliate their email summary.
		 *
		 * @since 2.9.7
		 *
		 * @param string $interval Defaults to MINUTE_IN_SECONDS (60 seconds).
		 */
		$timing = $timing + apply_filters( 'monthly_affiliate_email_summary_interval', MINUTE_IN_SECONDS );

		$affiliate_email = affwp_get_affiliate_email( $affiliate_id );

		// Schedule each affiliates email to send...
		affwp_schedule_summary(
			'monthly_affiliate_email',
			$affiliate_email,
			$subject,
			$content,

			// Data.
			array(
				'affiliate_id' => $affiliate_id, // Used to keep track of sent email summaries.
			),

			// Template.
			'affiliate-summary',
			$timing
		);
	}
}
add_action(
	'affwp_monthly_affiliate_email_summaries', // See includes/class-affwp-scheduler.php.
	'affwp_notify_monthly_affiliate_email_summary'
);

/**
 * Send scheduled email summaries.
 *
 * @since 2.9.7
 *
 * @param  string $name       See affwp_email_summary().
 * @param  string $to         See affwp_email_summary().
 * @param  string $subject    See affwp_email_summary().
 * @param  string $email_body See affwp_email_summary().
 * @param  string $data       See affwp_email_summary().
 * @param  string $template   See affwp_email_summary().
 * @return bool               See affwp_email_summary().
 */
function affwp_send_scheduled_summary(
	$name,
	$to,
	$subject,
	$email_body,
	$data,
	$template
) {

	// Preview the first affiliate and stop (will die()).
	return affwp_email_summary(
		$name,
		$to,
		$subject,
		$email_body,
		$data,
		false, // Never previewing here.
		$template
	);
}
add_action(
	'affwp_send_scheduled_summary',
	'affwp_send_scheduled_summary',
	10,
	6
);

/**
 * Ends the pause on affiliate email summaries when the setting is turned off or on.
 *
 * Saving the Emails tab without changing the setting is not a choice to start them.
 *
 * @since 2.37.3
 *
 * @param mixed $old_value Previous `affwp_settings` value.
 * @param mixed $value     New `affwp_settings` value.
 * @return void
 */
function affwp_end_affiliate_email_summaries_pause_on_toggle( $old_value, $value ) {

	$was_on = is_array( $old_value ) && ! empty( $old_value['affiliate_email_summaries'] );
	$is_on  = is_array( $value ) && ! empty( $value['affiliate_email_summaries'] );

	if ( $was_on !== $is_on ) {
		affwp_set_affiliate_email_summaries_awaiting_confirmation( false );
	}
}
add_action( 'update_option_affwp_settings', 'affwp_end_affiliate_email_summaries_pause_on_toggle', 10, 2 );

/**
 * Log when we sent an email summary to an affiliate.
 *
 * @since 2.9.7
 *
 * @param  bool  $sent Whether the email was successfully sent or noy.
 * @param  array $data Data about the email.
 * @return bool        Whether the email was sent (unchanged).
 */
function affwp_log_affiliate_email_summary_last_sent_time( $sent, $data ) {

	if ( ! $sent ) {
		return $sent; // Don't log anything, it didn't send.
	}

	if ( ! isset( $data['affiliate_id'] ) || ! is_numeric( $data['affiliate_id'] ) ) {
		return $sent; // We need this to track what affiliate we sent this to.
	}

	// Log that we sent the email summary right now.
	affwp_update_affiliate_meta( $data['affiliate_id'], 'last_email_summary_sent', time() );

	return $sent;
}
add_action(
	'affwp_notify_monthly_affiliate_email_summary_email_sent',
	'affwp_log_affiliate_email_summary_last_sent_time',
	10,
	2
);

/**
 * Make sure certain email summaries always use HTML templates when previewing them.
 *
 * @since 2.9.7
 *
 * @param  string $template The selected template from Settings.
 * @return string           Selected template, unless previewing an email summary
 *                          which returns an HTML template.
 */
function affwp_use_html_templates_for_previewing_email_summaries( $template ) {

	foreach ( array(

		// Email summaries...
		'monthly_affiliate_email' => 'affiliate-summary',
		'monthly_email'           => 'summaries',
	) as $summary => $html_template ) {
		if ( affwp_is_summary_email_preview( $summary ) ) {
			return $html_template;
		}
	}

	return $template; // We're not previewing any of these, so just use the selected template.
}
add_action( 'affwp_email_template', 'affwp_use_html_templates_for_previewing_email_summaries' );
