<?php
/**
 * Emails: Functions
 *
 * @package     AffiliateWP
 * @subpackage  Emails
 * @copyright   Copyright (c) 2015, Sandhills Development, LLC
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       1.6
 */

// phpcs:disable PEAR.Functions.FunctionCallSignature.EmptyLine -- Formatting this was is ok here.
// phpcs:disable PEAR.Functions.FunctionCallSignature.FirstArgumentPosition -- Formatting this was is ok here.
// phpcs:disable WordPress.Arrays.MultipleStatementAlignment.DoubleArrowNotAligned -- WPCS is throwing this warning inaccurately.

// Exit if accessed directly
if( ! defined( 'ABSPATH' ) ) exit;

/**
 * Get a list of available email templates
 *
 * @since 1.6
 * @return array
 */
function affwp_get_email_templates() {
	return affiliate_wp()->emails->get_templates();
}

/**
 * Get a formatted HTML list of all available tags
 *
 * @since 1.6
 * @return string $list HTML formated list
 */
function affwp_get_emails_tags_list() {
	// The list
	$list = '';

	// Get all tags
	$email_tags = affiliate_wp()->emails->get_tags();

	// Check
	if( count( $email_tags ) > 0 ) {
		foreach( $email_tags as $email_tag ) {
			$list .= '{' . $email_tag['tag'] . '} - ' . $email_tag['description'] . '<br />';
		}
	}

	// Return the list
	return $list;
}


/**
 * Email template tag: name
 * The affiliate's name
 *
 * @param int $affiliate_id
 * @return string name
 */
function affwp_email_tag_name( $affiliate_id = 0 ) {
	return affiliate_wp()->affiliates->get_affiliate_name( $affiliate_id );
}


/**
 * Email template tag: username
 * The affiliate's username on the site
 *
 * @param int $affiliate_id
 * @return string username
 */
function affwp_email_tag_user_name( $affiliate_id = 0 ) {
	$user_info = get_userdata( affwp_get_affiliate_user_id( $affiliate_id ) );

	return $user_info->user_login;
}


/**
 * Email template tag: user_email
 * The affiliate's email
 *
 * @param int $affiliate_id
 * @return string email
 */
function affwp_email_tag_user_email( $affiliate_id = 0 ) {
	return affwp_get_affiliate_email( $affiliate_id );
}


/**
 * Email template tag: website
 * The affiliate's website
 *
 * @param int $affiliate_id
 * @return string website
 */
function affwp_email_tag_website( $affiliate_id = 0 ) {
	$user_info = get_userdata( affwp_get_affiliate_user_id( $affiliate_id ) );

	return $user_info->user_url;
}


/**
 * Email template tag: promo_method
 * The affiliate promo method
 *
 * @param int $affiliate_id
 * @return string promo_method
 */
function affwp_email_tag_promo_method( $affiliate_id = 0 ) {
	return get_user_meta( affwp_get_affiliate_user_id( $affiliate_id ), 'affwp_promotion_method', true );
}

/**
 * Email template tag: affwp_email_tag_rejection_reason
 * The affiliate rejection reason
 *
 * @param int $affiliate_id Affiliate ID.
 * @return string rejection_reason
 */
function affwp_email_tag_rejection_reason( $affiliate_id ) {
	$reason = affwp_get_affiliate_meta( $affiliate_id, '_rejection_reason', true );
	if( empty( $reason ) ) {
		$reason = '';
	}
	return $reason;
}


/**
 * Email template tag: login_url
 * The affiliate login URL
 *
 * @return string login_url
 */
function affwp_email_tag_login_url() {
	return esc_url( affiliate_wp()->login->get_login_url() );
}


/**
 * Email template tag: amount
 * The amount of an affiliate transaction
 *
 * @return string amount
 */
function affwp_email_tag_amount( $affiliate_id, $referral ) {
	// Check for Stripe email data first
	if ( has_filter( 'affwp_stripe_email_tag_data' ) ) {
		$email_data = apply_filters( 'affwp_stripe_email_tag_data', [] );
		if ( isset( $email_data['amount'] ) ) {
			// Amount is stored in Stripe's smallest unit; decode per currency
			// (zero-decimal currencies such as JPY are not divided by 100).
			$currency = isset( $email_data['currency'] ) ? $email_data['currency'] : null;
			$amount   = function_exists( 'affwp_stripe_payouts_unformat_amount' )
				? affwp_stripe_payouts_unformat_amount( $email_data['amount'], $currency )
				: $email_data['amount'] / 100;
			return html_entity_decode( affwp_currency_filter( affwp_format_amount( $amount ) ), ENT_COMPAT, 'UTF-8' );
		}
	}
	
	// Fallback to referral amount
	if ( $referral && isset( $referral->amount ) ) {
		return html_entity_decode( affwp_currency_filter( $referral->amount ), ENT_COMPAT, 'UTF-8' );
	}
	
	return '';
}


/**
 * Email template tag: sitename
 * Your site name
 *
 * @return string sitename
 */
function affwp_email_tag_site_name() {
	return wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
}

/**
 * Email template tag: referral URL
 * Affiliate's referral URL
 *
 * @return string referral_url
 */
function affwp_email_tag_referral_url( $affiliate_id = 0 ) {
	return affwp_get_affiliate_referral_url( array( 'affiliate_id' => $affiliate_id ) );
}

/**
 * Email template tag: affiliate ID
 * Affiliate's ID
 *
 * @return int affiliate ID
 */
function affwp_email_tag_affiliate_id( $affiliate_id = 0 ) {
	return $affiliate_id;
}

/**
 * Email template tag: referral rate
 * The affiliate's referral rate as shown from Affiliate -> Affiliates
 *
 * @since 1.9
 * @return string referral_rate
 */
function affwp_email_tag_referral_rate( $affiliate_id = 0 ) {
	return affwp_get_affiliate_rate( $affiliate_id, true );
}

/**
 * Is Affiliate Email Summaries enabled without a configured mailer to send them?
 *
 * @since 2.9.7
 * @since 2.37.3 Any configured mailer counts, see affwp_is_outgoing_mail_configured().
 *
 * @return bool
 */
function affwp_affiliate_email_summaries_enabled_without_wp_mail_smtp() {
	return true === affwp_is_affiliate_email_summaries_enabled()
		&& true !== affwp_is_outgoing_mail_configured();
}

/**
 * Is the setting for Affiliate Email Summaries enabled (checked)?
 *
 * @since 2.9.7
 *
 * @return bool
 */
function affwp_is_affiliate_email_summaries_enabled() {

	$settings = get_option( 'affwp_settings', false );

	if ( ! is_array( $settings ) ) {
		return false;
	}

	return isset( $settings['affiliate_email_summaries'] ) &&
		true === (bool) $settings['affiliate_email_summaries'];
}

/**
 * Has an admin stopped this affiliate's monthly email summary?
 *
 * Stores only the exception, so an absent value means "send" and no existing
 * affiliate needs backfilling.
 *
 * @since 2.36.1
 *
 * @param int $affiliate_id Affiliate ID.
 * @return bool True when this affiliate must not be sent summaries.
 */
function affwp_is_affiliate_email_summary_suppressed( $affiliate_id ) {
	return (bool) affwp_get_affiliate_meta( absint( $affiliate_id ), 'disable_email_summary', true );
}

/**
 * Would the monthly send queue a summary for this affiliate right now?
 *
 * The monthly sender asks this for each active affiliate, so anything that counts
 * recipients gets the same answer as the send.
 *
 * @since 2.37.3
 *
 * @param int|object $affiliate Affiliate ID, or an affiliate object or row with
 *                              `affiliate_id`, `user_id` and `date_registered`.
 * @param bool       $log       Whether to log why the affiliate is skipped.
 * @return bool
 */
function affwp_is_affiliate_due_email_summary( $affiliate, $log = false ) {

	if ( ! isset( $affiliate->affiliate_id, $affiliate->user_id, $affiliate->date_registered ) ) {
		$affiliate_id = absint( is_object( $affiliate ) ? ( $affiliate->affiliate_id ?? 0 ) : $affiliate );
		$affiliate    = $affiliate_id ? affwp_get_affiliate( $affiliate_id ) : false;
	}

	if ( ! $affiliate ) {
		return false;
	}

	$affiliate_id = (int) $affiliate->affiliate_id;

	$skip = static function ( $message ) use ( $log ) {

		if ( $log ) {
			affiliate_wp()->utils->log( $message );
		}

		return false;
	};

	if ( affwp_is_affiliate_email_summary_suppressed( $affiliate_id ) ) {
		return $skip(
			sprintf(
				// Translators: %1$s is the Affiliate's ID.
				__( 'Affiliate monthly summary for affiliate with ID %1$s was not sent because an admin turned summaries off for them.', 'affiliate-wp' ),
				$affiliate_id
			)
		);
	}

	$user            = get_userdata( (int) $affiliate->user_id );
	$affiliate_email = ( $user && is_email( $user->user_email ) ) ? $user->user_email : false;

	if ( false === $affiliate_email || ! filter_var( $affiliate_email, FILTER_VALIDATE_EMAIL ) ) {
		return $skip(
			sprintf(
				// Translators: %1$s is the Affiliate's ID and %2$s the email that was not valid.
				__( 'Affiliate monthly summary for affiliate with ID %1$s with email %2$s was not sent because it is not a valid email.', 'affiliate-wp' ),
				$affiliate_id,
				$affiliate_email
			)
		);
	}

	$date_registered = is_string( $affiliate->date_registered ) ? $affiliate->date_registered : '';

	if ( empty( $date_registered ) ) {
		return $skip(
			sprintf(
				// Translators: %1$s is the Affiliates ID and %2$s is the bad registration date.
				__( 'Affiliate monthly summary for affiliate with ID %1$s with registered_date of %2$s was not sent because it is not a valid registration date.', 'affiliate-wp' ),
				$affiliate_id,
				$date_registered
			)
		);
	}

	$registered = date_create( $date_registered );
	$date_diff  = $registered ? date_diff( $registered, date_create( gmdate( 'Y-m-d', time() ) ) ) : false;

	if ( ! $date_diff ) {
		return $skip(
			sprintf(
				// Translators: %1$s is the Affiliates ID.
				__( 'Affiliate with ID %1$s could not be sent their email because we could not determine how many days they had been registered.', 'affiliate-wp' ),
				$affiliate_id
			)
		);
	}

	if ( $date_diff->days < 30 ) {
		return $skip(
			sprintf(
				// Translators: %1$s is the Affiliates ID and %2$s is their registration date.
				__( 'Affiliate with ID %1$s (registered on %2$s) was not sent their monthly email summary because they were registered within the last 30 days.', 'affiliate-wp' ),
				$affiliate_id,
				$date_registered
			)
		);
	}

	$last_sent = affwp_get_affiliate_meta( $affiliate_id, 'last_email_summary_sent', true );

	if ( is_numeric( $last_sent ) ) {

		$sent_date_diff = date_diff(
			date_create( gmdate( 'Y-m-d', $last_sent ) ),
			date_create( gmdate( 'Y-m-d', time() ) )
		);

		if ( false !== $sent_date_diff && $sent_date_diff->days < 27 ) {
			return $skip(
				sprintf(
					// Translators: %1$s is the Affiliates ID and %2$s is the date they were last sent an email.
					__( 'Affiliate with ID %1$s was not sent their email summary because they were sent one already on %2$s.', 'affiliate-wp' ),
					$affiliate_id,
					gmdate( 'Y-m-d', $last_sent )
				)
			);
		}
	}

	return true;
}

/**
 * How many active affiliates the monthly send would queue a summary for right now.
 *
 * @since 2.37.3
 *
 * @return int
 */
function affwp_count_affiliates_due_email_summary() {

	$affiliates = affiliate_wp()->affiliates->get_affiliates(
		array(
			'number' => -1,
			'status' => 'active',
			'fields' => array( 'affiliate_id', 'user_id', 'date_registered' ),
		)
	);

	if ( empty( $affiliates ) ) {
		return 0;
	}

	// A few queries for the whole list, not a few per affiliate, so a notice can show this on every screen.
	update_meta_cache( 'affiliate', array_map( 'intval', wp_list_pluck( $affiliates, 'affiliate_id' ) ) );
	cache_users( array_values( array_unique( array_map( 'intval', wp_list_pluck( $affiliates, 'user_id' ) ) ) ) );

	return count( array_filter( $affiliates, 'affwp_is_affiliate_due_email_summary' ) );
}

/**
 * Can this site send affiliate email summaries at all?
 *
 * The per-affiliate control is a preference, so it saves either way. This only
 * reports whether anything would currently be delivered.
 *
 * @since 2.36.1
 * @since 2.37.3 Not while summaries wait for an admin to start them.
 *
 * @return bool
 */
function affwp_can_send_affiliate_email_summaries() {
	return ! is_multisite()
		&& affwp_is_affiliate_email_summaries_enabled()
		&& affwp_is_outgoing_mail_configured()
		&& ! affwp_affiliate_email_summaries_awaiting_confirmation();
}

/**
 * Would affiliate email summaries have been sent before 2.37.3?
 *
 * Until 2.37.3 they only went out through WP Mail SMTP, or when the
 * `affwp_is_wp_mail_smtp_configured` filter allowed them.
 *
 * @since 2.37.3
 *
 * @return bool
 */
function affwp_wp_mail_smtp_sends_affiliate_email_summaries() {

	/** This filter is documented in includes/emails/functions.php */
	$filtered = apply_filters( 'affwp_is_wp_mail_smtp_configured', null );

	if ( is_bool( $filtered ) ) {
		return $filtered;
	}

	try {
		return affwp_is_wp_mail_smtp_plugin_configured();
	} catch ( \Throwable $e ) {
		return false;
	}
}

/**
 * Are affiliate email summaries paused until an admin starts them?
 *
 * Stores that turned summaries on while they still needed WP Mail SMTP are paused by the
 * 2.37.3 upgrade, so no affiliate is emailed without a choice. Setting up WP Mail SMTP sent
 * them without asking before, so it still ends the pause.
 *
 * @since 2.37.3
 *
 * @return bool
 */
function affwp_affiliate_email_summaries_awaiting_confirmation() {

	if ( '1' !== get_option( 'affwp_affiliate_email_summaries_awaiting_confirmation' ) ) {
		return false;
	}

	if ( affwp_wp_mail_smtp_sends_affiliate_email_summaries() ) {
		affwp_set_affiliate_email_summaries_awaiting_confirmation( false );

		return false;
	}

	return true;
}

/**
 * Pauses affiliate email summaries until an admin starts them, or ends the pause.
 *
 * @since 2.37.3
 *
 * @param bool $awaiting Whether summaries wait for an admin to start them.
 * @return void
 */
function affwp_set_affiliate_email_summaries_awaiting_confirmation( $awaiting ) {
	update_option( 'affwp_affiliate_email_summaries_awaiting_confirmation', $awaiting ? '1' : '0', true );
}

/**
 * Should the admin be asked to start affiliate email summaries?
 *
 * Only while summaries are on and paused, and a configured mailer can send them.
 * Without a mailer they stay blocked, and the WP Mail SMTP notice says so.
 *
 * @since 2.37.3
 *
 * @return bool
 */
function affwp_should_ask_to_start_affiliate_email_summaries() {
	return ! is_multisite()
		&& affwp_is_affiliate_email_summaries_enabled()
		&& affwp_affiliate_email_summaries_awaiting_confirmation()
		&& affwp_is_outgoing_mail_configured();
}

/**
 * URL that starts or turns off paused affiliate email summaries.
 *
 * @since 2.37.3
 *
 * @param string $action `start` or `turn_off`.
 * @return string Nonced URL, as wp_nonce_url() returns it.
 */
function affwp_get_affiliate_email_summaries_action_url( $action ) {

	$action = 'turn_off' === $action ? 'turn_off' : 'start';

	return wp_nonce_url(
		add_query_arg(
			'affwp_action',
			"{$action}_affiliate_email_summaries",
			affwp_admin_url( 'settings', array( 'tab' => 'emails' ) )
		),
		"affwp_{$action}_affiliate_email_summaries",
		'affwp_summaries_nonce'
	);
}

/**
 * Email template tag: review URL
 * Affiliate's review page URL
 *
 * @since 1.9
 * @return string URL to the review page
 */
function affwp_email_tag_review_url( $affiliate_id = 0 ) {
	return affwp_admin_url( 'affiliates', array( 'affiliate_id' => absint( $affiliate_id ), 'action' => 'review_affiliate' ) );
}

/**
 * Email template tag: registration_coupon
 * The affiliate's registration coupon
 *
 * @since 2.6
 *
 * @param int $affiliate_id Affiliate ID.
 * @return string Affiliate registration coupon, or empty string if none.
 */
function affwp_email_tag_registration_coupon( $affiliate_id = 0 ) {
	$coupon_code = '';

	$coupons = affwp_get_dynamic_affiliate_coupons( $affiliate_id, false );

	if ( ! empty( $coupons ) ) {
		$coupon = reset( $coupons );

		$coupon_code = affwp_get_affiliate_coupon_code( $affiliate_id, $coupon->coupon_id );
	}

	return $coupon_code;
}

/**
 * Get the landing page of the referral
 *
 * @since 1.9
 * @return string URL to the landing page
 */
function affwp_email_tag_get_landing_page( $affiliate_id, $referral ) {
    return esc_url( affiliate_wp()->visits->get_column_by( 'url', 'visit_id', $referral->visit_id ) );
}

/**
 * Gets the campaign (if set) of the referral.
 *
 * @since 1.9.4
 *
 * @param int             $affiliate_id Affiliate ID.
 * @param \AffWP\Referral $referral     Referral object.
 * @return string Referral campaign, or (no campaign) if none.
 */
function affwp_email_tag_campaign_name( $affiliate_id, $referral ) {
	return empty( $referral->campaign ) ? __( '(no campaign)', 'affiliate-wp' ) : esc_html( $referral->campaign );
}

/**
 * Default subject and body for the Payout Setup Reminder email.
 *
 * Method-agnostic on purpose: the copy names no payout method, so any method
 * (Stripe today, others later) can send it, and every send links the affiliate
 * to the same payout settings screen. `{affiliate_payout_settings_url}` keeps
 * the link portal-aware; never hardcode the URL or a fragment (fragments are
 * dropped by the login redirect).
 *
 * @since 2.36.0
 *
 * @return array{subject:string,body:string}
 */
function affwp_get_payout_setup_reminder_email_content() {

	return array(
		'subject' => __( 'Set up your payouts for {site_name}', 'affiliate-wp' ),
		'body'    => __(
			"Hi {name},\n\n"
			. "We can't send you payouts from {site_name} yet because your payout details aren't set up. It only takes a few minutes to finish.\n\n"
			. "Set up your payouts here:\n{affiliate_payout_settings_url}\n\n"
			. "Questions? Just reply to this email.\n\n"
			. "Thanks,\n{site_name}",
			'affiliate-wp'
		),
	);
}

/**
 * The Payout Setup Reminder's body variants, keyed by why setup is outstanding.
 *
 * One email, one subject, one body per reason — the same shape "Payout Failed — Action
 * Required" already uses, except its axis is the payout method and this one's is the
 * reason. Both audiences need the identical link and the identical action; only the
 * sentence explaining why differs, and telling someone who finished Stripe onboarding
 * that their details "aren't set up" is the fastest route to a support ticket.
 *
 * The copy stays method-agnostic inside each variant, as it always has. The link lands
 * the affiliate on their payout settings, where whichever rail they are on renders its
 * own CTA — so reason x method never becomes a grid of bodies nobody maintains.
 *
 * `first_time` keeps the original `payout_setup_reminder_body` field on purpose, so copy
 * a merchant wrote against 2.36.0 keeps applying untouched.
 *
 * Each variant carries its own `description`: both are sent by the same button, so the
 * label alone leaves the merchant guessing which body a given affiliate receives.
 *
 * @since 2.36.1
 *
 * @return array<string,array{label:string,description:string,field:string,body:string}> Reason => variant.
 */
function affwp_get_payout_setup_reminder_email_variants() {

	$defaults = affwp_get_payout_setup_reminder_email_content();

	return array(
		'first_time'     => array(
			'label'       => __( 'First-time setup', 'affiliate-wp' ),
			'description' => __( 'Sent when the affiliate has never set up a payout method.', 'affiliate-wp' ),
			'field'       => 'payout_setup_reminder_body',
			'body'        => $defaults['body'],
		),
		'method_changed' => array(
			'label'       => __( 'Payout method change', 'affiliate-wp' ),
			'description' => __( 'Sent when a change to your payout settings moves an affiliate who was already set up onto a method they have not set up yet.', 'affiliate-wp' ),
			/*
			 * Names no setting, no country, and nobody to blame. The affiliate cannot see the
			 * merchant's payout configuration, and the reasons vary — a rail switched off, a
			 * coverage group narrowed, a new Stripe platform account — so anything more specific
			 * would be wrong on some of the paths that send this.
			 *
			 * "You'll need to set up payouts", not "we need your payout details": the second is
			 * how a phishing email asks, and it is not even true, since the details go to Stripe's
			 * hosted form rather than to the merchant. It also matches the button they land on.
			 */
			'field'       => 'payout_setup_reminder_changed_body',
			'body'        => __(
				"Hi {name},\n\n"
				. "The way we send payouts has changed, so you'll need to set up payouts again before we can pay you. Nothing you've earned is affected.\n\n"
				. "Set up your payouts here:\n{affiliate_payout_settings_url}\n\n"
				. "Questions? Just reply to this email.\n\n"
				. "Thanks,\n{site_name}",
				'affiliate-wp'
			),
		),
	);
}

/**
 * Determine if New Referral Notifications can be sent to the affiliate
 *
 * @since 2.2
 * @uses affwp_email_notification_enabled()
 * @param int $affiliate_id The affiliate's ID
 *
 * @return boolean True if new referral notifications are enabled, false otherwise.
 */
function affwp_email_referral_notifications( $affiliate_id = 0 ) {

	$enabled = false;

	if ( true === affwp_email_notification_enabled( 'affiliate_new_referral_email', $affiliate_id ) ) {
		$enabled = true;
	}

	return (bool) $enabled;

}

/**
 * Determine if a specific email notification is enabled.
 *
 * @since 2.2
 * @param string $email_notification The email notification to check.
 * @param int $affiliate_id The affiliate's ID
 *
 * @return boolean True if the email notification is enabled, false otherwise.
 */
function affwp_email_notification_enabled( $email_notification = '', $affiliate_id = 0 ) {

	$enabled = false;

	if ( array_key_exists( $email_notification, affwp_get_enabled_email_notifications() ) ) {
		$enabled = true;
	}

	/**
	 * Filters whether the email notification is enabled.
	 *
	 * @since 2.2
	 *
	 * @param bool   $enabled            Whether the email notification is enabled.
	 * @param string $email_notification Email notification slug.
	 * @param int    $affiliate_id       Affiliate ID.
	 */
	return (bool) apply_filters( 'affwp_email_notification_enabled', $enabled, $email_notification, $affiliate_id );
}

/**
 * Get the email notifications settings array.
 *
 * @since 2.2
 *
 * @return array $email_notifications
 */
function affwp_get_enabled_email_notifications() {

	$email_notifications = affiliate_wp()->settings->get( 'email_notifications' );

	if ( is_array( $email_notifications ) ) {
		return $email_notifications;
	}

	// Return empty array.
	return array();

}

/**
 * Get the latest unsent DYK blurb.
 *
 * @since 2.9.6
 *
 * @return array Empty if we could not get them.
 *
 * @TODO Cache this data so we can send unsent blurbs in the case of
 *       it not being available.
 */
function affwp_get_latest_unsent_dyk_blurb_for_my_license() {

	$response = wp_remote_get(
		defined( 'AFFWP_EMAIL_SUMMARIES_JSON' )
			? esc_url( AFFWP_EMAIL_SUMMARIES_JSON )
			: 'https://affiliatewp.com/wp-content/email-summaries.json',
		array(
			'sslverify' => affwp_sslverify(),
		)
	);

	if ( is_wp_error( $response ) ) {
		return array();
	}

	if ( 200 !== absint( wp_remote_retrieve_response_code( $response ) ) ) {
		return array();
	};

	$json = wp_remote_retrieve_body( $response );

	if ( ! is_string( $json ) || empty( $json ) ) {
		return array();
	}

	$blurbs = json_decode( $json, true );

	if ( ! is_array( $blurbs ) ) {
		return array();
	}

	// Get ready to sort them by ID...
	$blurbs_by_id = array();

	// We'll need sent blurbs so we don't re-send any...
	$sent_blurbs = affwp_get_sent_dyk_blurbs();

	// We also want to just send blurbs important for that user's license...
	$license = new AffWP\Core\License\License_Data();

	foreach ( $blurbs as $blurb ) {

		if ( ! isset(

			// These are required at a minimum.
			$blurb['id'],
			$blurb['title']
		) ) {
			continue;
		}

		if (

			// You are trying to focus this DYK blurb to a license(s).
			isset( $blurb['type'] ) && is_array( $blurb['type'] ) && ! empty( $blurb['type'] ) &&

			// And your license is not in the array.
			! in_array( strtolower( $license->get_license_type( $license->get_license_id() ) ), $blurb['type'], true )
		) {
			continue; // Not for you.
		}

		if ( in_array( absint( $blurb['id'] ), $sent_blurbs, true ) ) {
			continue; // Already sent this one.
		}

		// Not a sent blurb.
		$blurbs_by_id[ $blurb['id'] ] = $blurb;
	}

	// Sort by ID so we get the latest...
	ksort( $blurbs_by_id );

	// Send back the top-most.
	return current( $blurbs_by_id );
}

/**
 * Get sent DYK Blurbs.
 *
 * @since 2.9.6
 *
 * @return array
 */
function affwp_get_sent_dyk_blurbs() {

	$sent_blurbs = get_option( 'affwp_emailed_dyk_blurbs', array() );

	if ( ! is_array( $sent_blurbs ) ) {
		return array(); // Something broke, reset blurbs.
	}

	// Sanitize blurbs (list of ID's).
	return array_map(
		function( $blurb_id ) {
			return absint( $blurb_id );
		},
		$sent_blurbs
	);
}

/**
 * Remember a DYK blurb that we sent.
 *
 * @since 2.9.6
 *
 * @param  int $blurb_id The Blurb ID from JSON.
 * @return bool          False if you didn't pass a proper ID.
 */
function affwp_add_sent_dyk_blurb( $blurb_id ) {

	$blurb_id = absint( $blurb_id );

	if ( 0 === $blurb_id ) {
		return false; // Can't add a nothing blurb.
	}

	$sent_blurbs = affwp_get_sent_dyk_blurbs();

	$sent_blurbs[] = absint( $blurb_id );

	/*
	 * We should always send a DYK blurb that isn't in this option (array),
	 * so update_option() should always return true (new value added).
	 */
	return update_option(
		'affwp_emailed_dyk_blurbs',
		array_map(
			// Sanitize (out) blurbs (list of ID's).
			function( $blurb_id ) {
				return absint( $blurb_id );
			},
			$sent_blurbs
		),
		false
	);
}

/**
 * Schedule an email summary.
 *
 * @since 2.9.7
 *
 * @param  string $name       See affwp_email_summary().
 * @param  string $to         See affwp_email_summary().
 * @param  string $subject    See affwp_email_summary().
 * @param  string $email_body See affwp_email_summary().
 * @param  string $data       See affwp_email_summary().
 * @param  string $template   See affwp_email_summary().
 * @param  string $timestamp  Timestamp of when to send it with Action Scheduler.
 * @return bool               See affwp_email_summary().
 */
function affwp_schedule_summary(
	$name,
	$to,
	$subject,
	$email_body,
	$data = null,
	$template = 'summaries',
	$timestamp = 0
) {

	if ( ! function_exists( 'as_schedule_single_action' ) ) {

		affiliate_wp()->utils->log(
			sprintf(

				// Translators: %1$s is the name of the summary.
				__( 'Could not schedule %1$s email summary because we could not find the function as_schedule_single_action().' ),
				$name
			)
		);

		return false;
	}

	// Schedule a one-time summary to be send when indicated, and return if it was scheduled or not.
	return 0 === as_schedule_single_action(
		0 === $timestamp
			? time() // Send now.
			: $timestamp, // Send when scheduled.
		'affwp_send_scheduled_summary',
		array(
			$name,
			$to,
			$subject,
			$email_body,
			$data,
			$template,
		),
		'affiliatewp' // Action scheduler group.
	)
		? false // It wasn't scheduled for some reason.
		: true; // It was scheduled.
}

/**
 * Send an email summary.
 *
 * @param  string $name       Name of the email summary.
 * @param  string $to         To.
 * @param  string $subject    Subject.
 * @param  string $email_body Content.
 * @param  mixed  $data       Any data associated with the email.
 * @param  bool   $preview    Set to true to preview email instead.
 * @param  string $template   Template.
 * @return bool               True if it was emailed.
 */
function affwp_email_summary(
	$name,
	$to,
	$subject,
	$email_body,
	$data = null,
	$preview = false,
	$template = 'summaries'
) {

	if ( $preview ) {
		check_admin_referer( 'preview_email_summary', '_wpnonce' );
	}

	$emailer = new Affiliate_WP_Emails();

	$emailer->template = $template;

	// Send context to our template filters.
	set_query_var(
		'context',
		array(
			'name'     => $name, // The most important part.
			'to'       => $to,
			'template' => $template,
			'data'     => $data,
		)
	);

	if ( $preview ) {

		/**
		 * This filter is documented below (same as filtering the email body below).
		 *
		 * @since 2.9.6
		 */
		die( apply_filters( "affwp_notify_{$name}_summary_body", $emailer->build_email( $email_body ) ) ); // phpcs:ignore -- Okay to die here without escaping.
	}

	$sent = $emailer->send(

		/**
		 * Filter who the Monthly Summary Emails are sent to.
		 *
		 * Default to admin email if they haven't set a separate manager email set.
		 *
		 * @since 2.9.6
		 *
		 * @param string $email The email address.
		 */
		apply_filters( "affwp_notify_{$name}_summary_to_email", $to ),

		/**
		 * Filter the subject of the Monthly Summary Report.
		 *
		 * @since 2.9.6
		 *
		 * @param string $subject Subject.
		 */
		apply_filters( "affwp_notify_{$name}_summary_email_subject", $subject ),

		/**
		 * Filter the content of the Monthly Summary.
		 *
		 * @since 2.9.6
		 *
		 * @param string $body Email body.
		 */
		apply_filters( "affwp_notify_{$name}_summary_email_body", $email_body )
	);

	/**
	 * When the Sumamry Email is sent.
	 *
	 * @since 2.9.6
	 *
	 * @param string $sent Sent status.
	 * @param mixed  $data Any data related to this email.
	 */
	do_action( "affwp_notify_{$name}_summary_email_sent", $sent, $data );

	return $sent;
}

/**
 * Are we previewing an email summary?
 *
 * @param  string $name Name of email summary.
 * @return bool
 */
function affwp_is_summary_email_preview( $name ) {

	if ( ! is_string( $name ) ) {
		return false;
	}

	return (
		is_admin() && // Within the admin.
		isset( $_GET['preview'] ) && // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- We're not using the data.
		isset( $_GET[ "affwp_notify_{$name}_summary" ] ) && // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- We're not using the data.
		isset( $_GET['_wpnonce'] ) && // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- We're not using the data.
		current_user_can( 'manage_affiliate_options' ) // Only admins can see the preview.
	);
}

if ( ! function_exists( 'affwp_get_monthly_affiliate_email_summary_content' ) ) :

	/**
	 * Get the Monthly Affiliate Report Markup (Content).
	 *
	 * If you want to custimize anything here, simply create this function elsewhere and
	 * override it with your own content.
	 *
	 * @since 2.9.7
	 *
	 * @param  int   $affiliate_id The affiliate to show data for,
	 *                             -1 means we must be previewing the content.
	 * @param  array $timeframe {
	 *     Timeframe.
	 *     @type string $start Start time in Y-m-d format.
	 *     @type string $end   End time in Y-m-d format.
	 *
	 *     Might look like:
	 *      'start' => string '2022-08-15'
	 *      'end' => string '2022-09-14'
	 * }
	 * @return string HTML Markup for email body.
	 *
	 * @see templates/dashboard-tab-stats.php Will present similar data here.
	 */
	function affwp_get_monthly_affiliate_email_summary_content( $affiliate_id, $timeframe ) {

		if ( ! is_numeric( $affiliate_id ) ) {

			affiliate_wp()->utils->log(
				sprintf(

					// Translators: %1$s is the ID that is bad.
					__( 'Affiliate monthly summary content for affiliate with ID %1$s was not sent because it is not a valid Affiliate ID.' ),
					$affiliate_id
				)
			);

			return ''; // Can't send anything to an affiliate w/out an ID.
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- We're just accessing it.
		if ( isset( $_GET['affiliate_id'] ) && is_numeric( $_GET['affiliate_id'] ) ) {

			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- For debugging only, might remove later.
			$affiliate_id = absint( $_GET['affiliate_id'] ); // Used to preview a specific affiliate's data.
		}

		// Affiliate name for the email content.
		$affiliate_name = -1 === $affiliate_id
			? __( 'John', 'affiliate-wp' ) // For previewing.
			: affwp_get_affiliate_first_name( $affiliate_id );

		// Get the user's top converting URLs.
		$top_converted_visits = affwp_get_affiliate_top_visit_urls(
			$affiliate_id,
			$timeframe,
			'converted',
			10
		);

		$intro = sprintf(

			// Translators: %1$s is the display-name of the affiliate.
			__( 'Hi %1$s,', 'affiliate-wp' ),

			// %$1s
			empty( $affiliate_name )

				// There is a chance the affiliate hasn't set their first name yet, show "Hi there," instead.
				? _x( 'there', 'affiliate-wp' )
				: $affiliate_name
		);

		$intro2 = sprintf(

			// Translators: %1$s is the name of this website.
			__( 'Here\'s how you\'ve performed on %1$s in the last 30 days.', 'affiliate-wp' ),
			sprintf(
				'<strong>%1$s</strong>',
				str_replace(
					array( 'https://', 'http://' ),
					'', // Replace with nothing.
					get_option( 'home' )
				)
			)
		);

		$total_earnings = affwp_currency_filter(
			affwp_format_amount(

				// Unpaid earnings.
				affiliate_wp()->referrals->unpaid_earnings(
					$timeframe,
					$affiliate_id,
					false
				)
				+

				// Plus Paid earnings.
				affiliate_wp()->referrals->paid_earnings(
					$timeframe,
					$affiliate_id,
					false
				)
			)
		);

		$total_referrals = affiliate_wp()->referrals->get_referrals(
			array(
				'number'       => -1,
				'affiliate_id' => $affiliate_id,
				'date'         => $timeframe,
				'fields'       => 'ids',
				'status'       => array(
					'paid',
					'unpaid',
				),
			),
			true // Just the count.
		);

		$total_visits = affwp_count_visits( $affiliate_id, $timeframe );

		$conversion_rate = affwp_get_affiliate_conversion_rate(
			$affiliate_id,
			$timeframe
		);

		if (

			// If they selected none, use plain text...
			'none' === affiliate_wp()->settings->get( 'email_template' ) &&

			// But never use this content when previewing.
			! affwp_is_summary_email_preview( 'monthly_affiliate_email' )
		) {

			/*
			 * Plain Text Version
			 *
			 * Note, spacing is important here.
			 */
			ob_start();

			?>

			<?php echo esc_html( $intro ); ?>


			<?php echo esc_html( $intro2 ); ?>


			Total Earnings: <?php echo esc_html( $total_earnings ); ?>

			Total Referrals: <?php echo esc_html( $total_referrals ); ?>

			Total Visits: <?php echo esc_html( $total_visits ); ?>

			Conversion Rate: <?php echo esc_html( $conversion_rate ); ?>


			<?php if ( ! empty( $top_converted_visits ) || -1 === $affiliate_id ) : ?>

				<?php echo esc_html( __( 'Top 10 Highest Converting URLs:', 'affiliate-wp' ) ); ?>

				<?php foreach ( $top_converted_visits as $url => $row ) : ?>

					<?php echo empty( $url ) ? esc_html__( 'Unknown', 'affiliate-wp' ) : esc_url( $url ); ?>

					Referrals: <?php echo isset( $row['visits'] ) ? absint( $row['visits'] ) : 0; ?>

					Visits: <?php echo absint( affwp_get_affiliate_total_visits_to_url( $url, $affiliate_id, 'today - 30 days' ) ); ?>

				<?php endforeach; ?>
			<?php endif; // Top Visits. ?>
			<?php

			return mb_convert_encoding(
				str_replace( "\t", '', ob_get_clean() ),
				'UTF-8',
				'HTML-ENTITIES'
			);
		}

		/*
		 * HTML Version.
		 */
		ob_start();

		?>

		<div class="content">

			<p style="text-align: left; font-weight: bold;">
				<?php

				echo esc_html(
					$intro
				);

				?>
			</p>

			<p style="text-align: left; margin-bottom: 30px;">
				<?php

				echo wp_kses(
					$intro2,
					array(
						'strong' => true,
					)
				);

				?>
			</p>

			<h2 style="margin-bottom: 25px; text-align: center;">
				<strong>
					<?php esc_html_e( 'Total Earnings', 'affiliate-wp' ); ?>
				</strong>
			</h2>

			<p style="font-size: 24px; margin-top: 10px; text-align: center;">
				<strong>
					<?php if ( -1 === $affiliate_id ) : ?>
						$150.56
					<?php else : ?>
						<?php

						// Unpaid + Paid earnings.
						echo esc_html(
							$total_earnings
						);

						?>
					<?php endif; ?>
				</strong>
			</p>

			<table class="data" style="border-collapse: collapse; margin: 20px 0;table-layout: fixed; width: 100%;">
				<tbody>
					<tr style="text-align: center">

						<td style="padding: 10px; width: 33%;">
							<p style="margin-bottom: 0;">
								<strong>
									<?php esc_html_e( 'Total Referrals', 'affiliate-wp' ); ?>
								</strong>
							</p>

							<p style="font-size: 24px; margin-top: 10px;">
								<strong>
									<?php if ( -1 === $affiliate_id ) : ?>
										12
									<?php else : ?>
										<?php

										// Count of paid and unpaid referrals.
										echo absint(
											$total_referrals
										);

										?>
									<?php endif; ?>
								</strong>
							</p>
						</td>

						<td style="padding: 10px; width: 33%;">
							<p style="margin-bottom: 0;">
								<strong>
									<?php esc_html_e( 'Total Visits', 'affiliate-wp' ); ?>
								</strong>
							</p>

							<p style="font-size: 24px; margin-top: 10px;">
								<strong>
									<?php if ( -1 === $affiliate_id ) : ?>
										18
									<?php else : ?>
										<?php echo absint( $total_visits ); ?>
									<?php endif; ?>
								</strong>
							</p>
						</td>

						<td style="padding: 10px; width: 33%;">
							<p style="margin-bottom: 0;">
								<strong>
									<?php esc_html_e( 'Conversion Rate', 'affiliate-wp' ); ?>
								</strong>
							</p>

							<p style="font-size: 24px; margin-top: 10px;">
								<strong>
									<?php if ( -1 === $affiliate_id ) : ?>
										66% <!-- // Preview data. -->
									<?php else : ?>
										<?php

										echo absint(
											affwp_get_affiliate_conversion_rate(
												$affiliate_id,
												$timeframe
											)
										);

										// Yes we just echo it here, because sprintf seems to break.
										echo '%';

										?>
									<?php endif; ?>
								</strong>
							</p>
						</td>
					</tr>
				</tbody>
			</table>

			<?php if ( ! empty( $top_converted_visits ) || -1 === $affiliate_id ) : ?>

				<h2 style="text-align: center; margin-top: 50px; margin-bottom: 25px;">
					<strong>
						<?php esc_html_e( 'Top 10 Highest Converting URLs', 'affiliate-wp' ); ?>
					</strong>
				</h2>

				<table class="top-urls" style="border-collapse: collapse; border: 1px solid #eee; margin: 20px 0; width: 100%;">
					<tbody>

						<tr style="background-color: #eee; font-weight: bold; border-bottom: 1px solid #eee;">
							<td style="text-align: center;"><?php esc_html_e( 'URL', 'affiliate-wp' ); ?></td>
							<td style="text-align: center;"><?php esc_html_e( 'Referrals', 'affiliate-wp' ); ?></td>
							<td style="text-align: center;"><?php esc_html_e( 'Total Visits', 'affiliate-wp' ); ?></td>
						</tr>

						<?php if ( -1 === $affiliate_id ) : ?>

							<?php for ( $i = 1; $i <= 10; $i++ ) : ?>

								<tr style="border-bottom: 1px solid #eee;">
									<td style="text-align: center; text-align: left; border-right: 1px solid #eee;"><?php echo esc_url( home_url( "/product/{$i}" ) ); ?></td>
									<td style="text-align: center;"><?php echo absint( wp_rand( 0, 30 ) ); ?></td>
									<td style="text-align: center; border-left: 1px solid #eee;"><?php echo absint( wp_rand( 30, 60 ) ); ?></td>
								</tr>

							<?php endfor; ?>


						<?php else : ?>

							<?php foreach ( $top_converted_visits as $url => $row ) : ?>
								<tr style="border-bottom: 1px solid #eee;">

									<td style="text-align: center; text-align: left; border-right: 1px solid #eee;">
										<?php

										echo empty( $url )
											? esc_html__( 'Unknown', 'affiliate-wp' )
											: esc_url( $url );
										?>
									</td>

									<td style="text-align: center;">
										<?php echo isset( $row['visits'] ) ? absint( $row['visits'] ) : 0; ?>
									</td>

									<td style="text-align: center; border-left: 1px solid #eee;">
										<?php echo absint( affwp_get_affiliate_total_visits_to_url( $url, $affiliate_id, 'today - 30 days' ) ); ?>
									</td>

								</tr>
							<?php endforeach; ?>

						<?php endif; ?>
					</tbody>
				</table>

			<?php endif; // Top Visits. ?>

		</div>

		<?php

		return ob_get_clean();
	}
endif;

/**
 * Get the v6 or v5 Mailer.
 *
 * @since 2.9.7
 *
 * @return mixed Mailer.
 */
function affwp_get_phpmailer() {

	if ( version_compare( get_bloginfo( 'version' ), '5.5-alpha', '<' ) ) {
		return affwp_get_phpmailer_v5();
	}

	return affwp_get_phpmailer_v6();
}

/**
 * Get the v5 Mailer.
 *
 * @since 2.9.7
 *
 * @return mixed Mailer.
 */
function affwp_get_phpmailer_v5() {

	global $phpmailer;

	if ( ! ( $phpmailer instanceof \PHPMailer ) ) {

		require_once ABSPATH . WPINC . '/class-phpmailer.php';
		require_once ABSPATH . WPINC . '/class-smtp.php';

		$phpmailer = new \PHPMailer( true ); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
	}

	return $phpmailer;
}

/**
 * Get the v6 Mailer.
 *
 * @since 2.9.7
 *
 * @return mixed Mailer.
 */
function affwp_get_phpmailer_v6() {

	global $phpmailer;

	if ( ! ( $phpmailer instanceof \PHPMailer\PHPMailer\PHPMailer ) ) {

		require_once ABSPATH . WPINC . '/PHPMailer/PHPMailer.php';
		require_once ABSPATH . WPINC . '/PHPMailer/SMTP.php';
		require_once ABSPATH . WPINC . '/PHPMailer/Exception.php';

		$phpmailer = new \PHPMailer\PHPMailer\PHPMailer( true ); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
	}

	return $phpmailer;
}


/**
 * Is WP Mail SMTP Pro (or lite) configured?
 *
 * Kept for back-compat. It answers whether this site sends email through any
 * configured mailer, which is what its callers gate on.
 *
 * @since 2.9.7
 * @since 2.37.3 Any configured mailer counts, see affwp_is_outgoing_mail_configured().
 *
 * @return bool
 */
function affwp_is_wp_mail_smtp_configured() {
	return affwp_is_outgoing_mail_configured();
}

/**
 * Does this site send email through a configured mailer rather than PHP's mail()?
 *
 * Affiliate email summaries go to every affiliate at once, so they only go out
 * through a configured SMTP or email service plugin, or through a wp_mail()
 * the site replaced. PHP's mail() alone does not count.
 *
 * @since 2.37.3
 *
 * @return bool
 */
function affwp_is_outgoing_mail_configured() {

	/**
	 * Filters whether WP Mail SMTP is configured.
	 *
	 * A boolean still decides the whole check, so existing overrides keep working.
	 *
	 * @since 2.9.7
	 *
	 * @param null|bool $configured Leave null to let us figure it out,
	 *                              otherwise set to true or false to use your determination.
	 */
	$filtered = apply_filters( 'affwp_is_wp_mail_smtp_configured', null );

	$source     = is_bool( $filtered ) ? '' : affwp_get_configured_mailer_file();
	$configured = is_bool( $filtered ) ? $filtered : '' !== $source;

	/**
	 * Filters whether this site's email goes out through a configured mailer.
	 *
	 * Affiliate email summaries only send when this is true.
	 *
	 * @since 2.37.3
	 *
	 * @param bool   $configured Whether a configured mailer was found.
	 * @param string $source     File of the plugin or code that sends the site's email, or an empty string.
	 */
	return (bool) apply_filters( 'affwp_is_outgoing_mail_configured', $configured, $source );
}

/**
 * Name of the mailer that sends this site's email, for display.
 *
 * @since 2.37.3
 *
 * @return string The mailer's plugin name, or an empty string when it is unknown or none is configured.
 */
function affwp_get_configured_mailer() {

	$file = affwp_get_configured_mailer_file();

	return '' === $file ? '' : affwp_get_mailer_name( $file );
}

/**
 * File of the plugin or code that sends this site's email, when a mailer is configured.
 *
 * Recognized SMTP and email service plugins answer with their own setup state.
 * Otherwise a wp_mail() replaced outside WordPress core, or a `pre_wp_mail`
 * callback, counts. A `phpmailer_init` callback alone does not: many plugins
 * hook it without sending mail. Cheap enough for every request: no plugin
 * headers are read.
 *
 * @since 2.37.3
 *
 * @return string File path, or an empty string when email goes out through PHP's mail().
 */
function affwp_get_configured_mailer_file() {

	$plugins = affwp_get_mail_plugins();

	foreach ( $plugins as $plugin ) {
		if ( $plugin['configured'] ) {
			return $plugin['file'];
		}
	}

	// A recognized plugin that isn't set up still hooks mail, and falls back to PHP's mail().
	$skip = [ affwp_get_mailer_root( AFFILIATEWP_PLUGIN_FILE ) ];

	foreach ( $plugins as $plugin ) {
		$skip[] = affwp_get_mailer_root( $plugin['file'] );
	}

	if ( function_exists( 'wp_mail' ) ) {
		$file = (string) ( new ReflectionFunction( 'wp_mail' ) )->getFileName();

		if (
			realpath( $file ) !== realpath( ABSPATH . WPINC . '/pluggable.php' )
			&& ! affwp_is_mailer_file_in( $file, $skip )
		) {
			return $file;
		}
	}

	global $wp_filter;

	if ( isset( $wp_filter['pre_wp_mail'] ) && $wp_filter['pre_wp_mail'] instanceof WP_Hook ) {
		foreach ( $wp_filter['pre_wp_mail']->callbacks as $callbacks ) {
			foreach ( $callbacks as $callback ) {
				$file = affwp_get_callback_file( $callback['function'] );

				if ( '' !== $file && ! affwp_is_mailer_file_in( $file, $skip ) ) {
					return $file;
				}
			}
		}
	}

	return '';
}

/**
 * The active SMTP and email service plugins AffiliateWP recognizes.
 *
 * Each reports whether it is set up to send, using the plugin's own setting,
 * because several replace wp_mail() or hook `pre_wp_mail` even before they are
 * set up, and send through PHP's mail() until then.
 *
 * @since 2.37.3
 *
 * @return array[] {
 *     @type string $file       A file of the plugin, for its folder and name.
 *     @type bool   $configured Whether the plugin is set up to send email.
 * }
 */
function affwp_get_mail_plugins() {

	$checks = [];

	if ( function_exists( 'wp_mail_smtp' ) ) {
		$checks[] = [ new ReflectionFunction( 'wp_mail_smtp' ), 'affwp_is_wp_mail_smtp_plugin_configured' ];
	}

	if ( function_exists( 'easy_wp_smtp' ) && class_exists( '\EasyWPSMTP\Options' ) ) {
		$checks[] = [
			new ReflectionFunction( 'easy_wp_smtp' ),
			function () {
				$mailer = \EasyWPSMTP\Options::init()->get( 'mail', 'mailer' );

				if ( empty( $mailer ) || 'mail' === $mailer ) {
					return false;
				}

				$provider = easy_wp_smtp()->get_providers()->get_mailer( $mailer, easy_wp_smtp()->get_processor()->get_phpmailer() );

				return ! empty( $provider ) && $provider->is_mailer_complete();
			},
		];
	}

	if ( function_exists( 'fluentMailDefaultConnection' ) ) {
		$checks[] = [
			new ReflectionFunction( 'fluentMailDefaultConnection' ),
			function () {
				$connection = fluentMailDefaultConnection();

				return ! empty( $connection['provider'] ) && 'default' !== $connection['provider'];
			},
		];
	}

	if ( class_exists( 'PostmanTransportRegistry' ) ) {
		$checks[] = [
			new ReflectionClass( 'PostmanTransportRegistry' ),
			function () {
				$transport = PostmanTransportRegistry::getInstance()->getActiveTransport();

				return is_object( $transport ) && 'default' !== $transport->getSlug();
			},
		];
	}

	if ( class_exists( 'SIB_Manager' ) ) {
		$checks[] = [
			new ReflectionClass( 'SIB_Manager' ),
			function () {
				$settings = get_option( 'sib_home_option', [] );

				return isset( $settings['activate_email'] ) && 'yes' === $settings['activate_email'];
			},
		];
	}

	if ( class_exists( '\SureMails\Inc\Settings' ) ) {
		$checks[] = [
			new ReflectionClass( '\SureMails\Inc\Settings' ),
			function () {
				foreach ( (array) \SureMails\Inc\Settings::instance()->get_settings( 'connections', [] ) as $connection ) {
					if ( isset( $connection['type'] ) && ! in_array( strtolower( (string) $connection['type'] ), [ 'phpmail', 'simulator' ], true ) ) {
						return true;
					}
				}

				return false;
			},
		];
	}

	if ( class_exists( '\SolidWP\Mail\Repository\ProvidersRepository' ) ) {
		$checks[] = [
			new ReflectionClass( '\SolidWP\Mail\Repository\ProvidersRepository' ),
			function () {
				foreach ( (array) get_option( 'solid_smtp_providers', [] ) as $provider ) {
					if ( ! empty( $provider['is_active'] ) && filter_var( $provider['is_active'], FILTER_VALIDATE_BOOLEAN ) ) {
						return true;
					}
				}

				return false;
			},
		];
	}

	if ( function_exists( 'gosmtp_load_phpmailer' ) ) {
		$checks[] = [
			new ReflectionFunction( 'gosmtp_load_phpmailer' ),
			function () {
				$options = get_option( 'gosmtp_options', [] );
				$type    = isset( $options['mailer'][0]['mail_type'] ) ? $options['mailer'][0]['mail_type'] : '';

				return '' !== $type && 'mail' !== $type;
			},
		];
	}

	if ( class_exists( '\YaySMTP\Helper\Utils' ) ) {
		$checks[] = [
			new ReflectionClass( '\YaySMTP\Helper\Utils' ),
			function () {
				return 'mail' !== \YaySMTP\Helper\Utils::getCurrentMailer() && \YaySMTP\Helper\Utils::isMailerComplete();
			},
		];
	}

	if ( function_exists( 'is_gmail_smtp_configured' ) ) {
		$checks[] = [ new ReflectionFunction( 'is_gmail_smtp_configured' ), 'is_gmail_smtp_configured' ];
	}

	if ( class_exists( '\SiteMailer\Modules\Connect\Module' ) ) {
		$checks[] = [
			new ReflectionClass( '\SiteMailer\Modules\Connect\Module' ),
			function () {
				return \SiteMailer\Modules\Connect\Module::is_connected();
			},
		];
	}

	if ( function_exists( 'smtp_mailer_get_option' ) ) {
		$checks[] = [
			new ReflectionFunction( 'smtp_mailer_get_option' ),
			function () {
				$options = smtp_mailer_get_option();

				return ! empty( $options['smtp_host'] );
			},
		];
	}

	$plugins = [];

	foreach ( $checks as $check ) {
		try {
			$configured = (bool) call_user_func( $check[1] );
		} catch ( \Throwable $e ) {
			$configured = false;
		}

		$plugins[] = [
			'file'       => (string) $check[0]->getFileName(),
			'configured' => $configured,
		];
	}

	return $plugins;
}

/**
 * Is the WP Mail SMTP plugin itself set to send through a mailer other than PHP's mail()?
 *
 * @since 2.37.3
 *
 * @return bool
 */
function affwp_is_wp_mail_smtp_plugin_configured() {

	if ( ! function_exists( 'wp_mail_smtp' ) || ! class_exists( '\WPMailSMTP\Options' ) ) {
		return false;
	}

	$mailer = \WPMailSMTP\Options::init()->get( 'mail', 'mailer' );

	if ( empty( $mailer ) || 'mail' === $mailer ) {
		return false; // No mailer, or the default PHP mailer, which we don't consider configured.
	}

	$provider = wp_mail_smtp()->get_providers()->get_mailer( $mailer, affwp_get_phpmailer() );

	return ! empty( $provider ) && $provider->is_mailer_complete();
}

/**
 * The plugin a file belongs to, or its directory outside the plugin folders.
 *
 * @since 2.37.3
 *
 * @param string $file File path.
 * @return string `mu:<entry>` for a must-use plugin, `plugin:<folder>` for a plugin's file,
 *                otherwise the file's directory.
 */
function affwp_get_mailer_root( $file ) {

	$file = wp_normalize_path( (string) $file );
	$mu   = trailingslashit( wp_normalize_path( WPMU_PLUGIN_DIR ) );

	if ( 0 === strpos( $file, $mu ) ) {
		return 'mu:' . strtok( substr( $file, strlen( $mu ) ), '/' );
	}

	$basename = plugin_basename( $file );

	if ( trim( $file, '/' ) !== $basename && false !== strpos( $basename, '/' ) ) {
		return 'plugin:' . strtok( $basename, '/' );
	}

	return dirname( $file );
}

/**
 * Whether a file belongs to one of the given mailer roots.
 *
 * @since 2.37.3
 *
 * @param string   $file  File path.
 * @param string[] $roots Roots from affwp_get_mailer_root().
 * @return bool
 */
function affwp_is_mailer_file_in( $file, $roots ) {

	$root = affwp_get_mailer_root( $file );

	if ( in_array( $root, $roots, true ) ) {
		return true;
	}

	$file = wp_normalize_path( (string) $file );

	foreach ( $roots as $candidate ) {
		if ( 0 !== strpos( $candidate, 'plugin:' ) && 0 === strpos( $file, trailingslashit( $candidate ) ) ) {
			return true;
		}
	}

	return false;
}

/**
 * Display name of the mailer a file belongs to.
 *
 * Reads one plugin header: the active plugin's main file for a plugin folder, or
 * the file itself for a must-use plugin or other code.
 *
 * @since 2.37.3
 *
 * @param string $file File path.
 * @return string The plugin's name without its tagline, or an empty string when unknown.
 */
function affwp_get_mailer_name( $file ) {

	if ( ! function_exists( 'get_plugin_data' ) ) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
	}

	$root        = affwp_get_mailer_root( $file );
	$header_file = $file;

	if ( 0 === strpos( $root, 'plugin:' ) ) {
		$folder      = substr( $root, 7 ) . '/';
		$header_file = '';
		$active      = array_merge(
			(array) get_option( 'active_plugins', [] ),
			array_keys( is_multisite() ? (array) get_site_option( 'active_sitewide_plugins', [] ) : [] )
		);

		foreach ( $active as $basename ) {
			if ( is_string( $basename ) && 0 === strpos( $basename, $folder ) ) {
				$header_file = WP_PLUGIN_DIR . '/' . $basename;
				break;
			}
		}
	}

	if ( '' === $header_file || ! is_readable( $header_file ) ) {
		return '';
	}

	$data = get_plugin_data( $header_file, false, false );
	$name = isset( $data['Name'] ) ? trim( (string) $data['Name'] ) : '';

	if ( '' === $name ) {
		return '';
	}

	// "Brevo - Email, SMS, Web Push, Chat, and more." reads as "Brevo".
	$name = preg_split( '/(?:\s+[-\x{2013}\x{2014}|]|:)\s+/u', $name );

	return trim( $name[0] );
}

/**
 * File that defines a hook callback.
 *
 * @since 2.37.3
 *
 * @param callable $callback Hook callback.
 * @return string File path, or an empty string when it can't be found.
 */
function affwp_get_callback_file( $callback ) {

	try {
		if ( is_string( $callback ) && false !== strpos( $callback, '::' ) ) {
			$callback = explode( '::', $callback, 2 );
		}

		if ( is_array( $callback ) && 2 === count( $callback ) ) {
			$reflection = new ReflectionMethod( $callback[0], $callback[1] );
		} elseif ( is_string( $callback ) || $callback instanceof Closure ) {
			$reflection = new ReflectionFunction( $callback );
		} elseif ( is_object( $callback ) && method_exists( $callback, '__invoke' ) ) {
			$reflection = new ReflectionMethod( $callback, '__invoke' );
		} else {
			return '';
		}

		return (string) $reflection->getFileName();

	} catch ( \ReflectionException $e ) {
		return '';
	}
}

/**
 * Get an affiliate's total visits for a URL.
 *
 * @param  string $url          URL.
 * @param  int    $affiliate_id Affiliate ID.
 * @param  string $date         Since when, defaults to all time (epoch).
 * @return int                  Number of visits to a url.
 */
function affwp_get_affiliate_total_visits_to_url( $url, $affiliate_id, $date = '1970-01-01' ) {

	global $wpdb;

	$count = $wpdb->get_var(
		$wpdb->prepare(
			"SELECT
				COUNT(visit_id)
				FROM {$wpdb->prefix}affiliate_wp_visits WHERE
					url = %s AND
					affiliate_id = %d AND
					date >= %s",
			$url,
			absint( $affiliate_id ),
			gmdate(
				'Y-m-d',
				strtotime( $date )
			)
		)
	);

	return is_numeric( $count )
		? absint( $count )
		: 0;
}

/**
 * Get the top converting visits for an affiliate by timeframe.
 *
 * @since 2.9.7
 *
 * @param int    $affiliate_id Affiliate ID.
 * @param array  $date {
 *     Timeframe.
 *     @type string start Start date.
 *     @type string end   End date.
 * }
 * @param string $referral_status Status of visits, defaults to converted.
 * @param int    $number          How many to retrieve.
 * @param array  $args            Arguments to merge or override.
 * @return array                  Array grouped by URL with visits and referrals.
 */
function affwp_get_affiliate_top_visit_urls(
	$affiliate_id,
	$date,
	$referral_status = 'converted',
	$number = -1,
	$args = array()
) {

	$urls = array();

	foreach ( affiliate_wp()->visits->get_visits(
		array_merge(
			array(
				'number'          => absint( $number ),
				'affiliate_id'    => absint( $affiliate_id ),
				'date'            => is_array( $date ) ? $date : array(),
				'order_by'        => 'date',
				'referral_status' => is_string( $referral_status ) ? $referral_status : 'converted',
				'fields' => array(
					'url',
					'referral_id',
				),
			),
			$args
		)
	) as $visit ) {

		// Group them by URL.
		$urls[ $visit->url ][] = $visit;
	}

	$top_urls = array();

	// Count visits and referrals for URLs.
	foreach ( $urls as $url => $visits ) {

		$top_urls[ $url ] = array(
			'visits'    => count( $visits ),

			// Log all the referrals.
			'referrals' => array_filter(
				$visits,
				function( $visit ) {
					return isset( $visit->referral_id );
				}
			),
		);
	}

	return $top_urls;
}

/**
 * Get the Monthly Email summary Markup (Content).
 *
 * @since 2.9.6
 * @since 2.9.7 Added plain text support.
 *
 * @param  array $timeframe {
 *     Timeframe.
 *     @type string $start Start time in Y-m-d format.
 *     @type string $end   End time in Y-m-d format.
 * }
 * @return string            HTML Markup for email body.
 */
function affwp_get_monthly_email_summary_content( $timeframe ) {

	if ( ! is_array( $timeframe ) ) {
		return __( 'Invalid timeframe.', 'affiliate-wp' );
	}

	// Based on includes/admin/reports/tabs/class-sales-reports-tab.php::active_integration_supports_sales().
	$has_active_integration_supports_sales_repoorting = in_array(
		true,
		array_map(
			function( $supported_integration_id ) {

				$integration_data = affiliate_wp()->integrations->get( $supported_integration_id );

				// If active, will return true and will be at least one integration that is active that supports sales reporting.
				return method_exists( $integration_data, 'is_active' )
					&& $integration_data->is_active();

			},
			affiliate_wp()->integrations->query(
				array(
					'supports' => 'sales_reporting',
					'status'   => 'enabled',
					'fields'   => 'ids',
				)
			)
		),
		true
	);

	$intro  = __( 'Hey there!', 'affiliate-wp' );
	$intro2 = __( "Let's see how your affiliate program has performed over the last 30 days.", 'affiliate-wp' );

	$total_program_revenue = affwp_currency_filter(
		affwp_format_amount(
			affiliate_wp()->referrals->sales->get_revenue_by_referral_status(
				array(
					'paid',
					'unpaid',
				),
				null,
				$timeframe
			)
		)
	);

	$new_approved_affiliates = affiliate_wp()->affiliates->count(
		array(
			'date'   => $timeframe,
			'status' => 'active',
		)
	);

	$unpaid_earnings = affwp_currency_filter(
		affwp_format_amount( affiliate_wp()->referrals->unpaid_earnings( $timeframe, 0, false ) )
	);

	$paid_earnings = affwp_currency_filter(
		affwp_format_amount( affiliate_wp()->referrals->paid_earnings( $timeframe, 0, false ) )
	);

	$top_affiliates = affwp_get_top_earning_affiliates(
		5,
		array(
			'date'   => $timeframe,
			'fields' => 'ids',
		)
	);

	/*
	 * Preview Version
	 */
	if (

		// If they selected none, use plain text...
		'none' === affiliate_wp()->settings->get( 'email_template' ) &&

		// But never use this content when previewing.
		! affwp_is_summary_email_preview( 'monthly_email' )
	) {

		ob_start();

		?>

		<?php echo esc_html( $intro ); ?>


		<?php echo esc_html( $intro2 ); ?>

		<?php if ( $has_active_integration_supports_sales_repoorting ) : // Only if there is an integration active that supports sales. ?>

			<?php esc_html_e( 'Total Program Revenue', 'affiliate-wp' ); ?>: <?php echo esc_html( $total_program_revenue ); ?>
		<?php endif; ?>

		<?php esc_html_e( 'New Approved Affiliates', 'affiliate-wp' ); ?>: <?php echo absint( $new_approved_affiliates ); ?>

		<?php echo esc_html( __( 'Unpaid Earnings', 'affiliate-wp' ) ); ?>: <?php echo esc_html( $unpaid_earnings ); ?>

		<?php echo esc_html( __( 'Paid Earnings', 'affiliate-wp' ) ); ?>: <?php echo esc_html( $paid_earnings ); ?>

		<?php if ( ! empty( $top_affiliates ) ) : ?>

			<?php echo esc_html( sprintf( __( 'Top %1$s Most Valuable Affiliates', 'affiliate-wp' ), count( $top_affiliates ) ) ); ?>:
			<?php foreach ( $top_affiliates as $top_affiliate_id ) : ?>

				<?php echo esc_html( affwp_get_affiliate_full_name_or_display_name( $top_affiliate_id ) ); ?>

				<?php esc_html_e( 'Earnings', 'affiliate-wp' ); ?>: <?php echo esc_html( affwp_currency_filter( affwp_format_amount( affiliate_wp()->referrals->get_earnings_by_status( array( 'paid', 'unpaid' ), $top_affiliate_id, $timeframe ) ) ) ); ?>

				<?php esc_html_e( 'Referrals', 'affiliate-wp' ); ?>: <?php echo esc_html( affiliate_wp()->referrals->count_by_status( array( 'paid', 'unpaid' ), $top_affiliate_id, $timeframe ) ); ?>

				<?php esc_html_e( 'Visits', 'affiliate-wp' ); ?>: <?php echo esc_html( affwp_count_visits( $top_affiliate_id, $timeframe ) ); ?>

			<?php endforeach ?>
		<?php endif; ?>

		<?php

		return mb_convert_encoding(
			str_replace( "\t", '', ob_get_clean() ),
			'UTF-8',
			'HTML-ENTITIES'
		);
	}

	/*
	 * HTML Version.
	 */
	ob_start();

	?>

	<div>

		<h3 style="margin-bottom: 9px; color: #1F2937;">
			<strong><?php echo esc_html( $intro ); ?></strong>
		</h3>

		<p style="margin-top: 0; margin-bottom: 20px; font-style: normal; font-weight: 400; font-size: 13px; line-height: 18px;"><?php echo esc_html( $intro2 ); ?></p>

		<div class="data" style="margin: 30px 0; width: 100%;">
			<div style="text-align: center;">

				<?php if ( $has_active_integration_supports_sales_repoorting ) : // Only if there is an integration active that supports sales. ?>
					<div style="height: 150px; width: 250px; display: inline-table;">

						<p style="text-align: center; margin-bottom: 0;">
							<img style="display: inline-block;" src="<?php echo esc_url( AFFILIATEWP_PLUGIN_URL . 'assets/images/summaries/total-program-revenue-icon.png' ); ?>" height="28" width="28" align="center" alt=" ">
						</p>
						<p style="margin-bottom: 0; margin-top: 5px; font-size: 14px; line-height: 18px;">
							<strong style="font-weight: 500;">
								<?php esc_html_e( 'Total Program Revenue', 'affiliate-wp' ); ?>
							</strong>
						</p>

						<p style="font-size: 32px; color: #000000; line-height: 32px; margin-top: 5px;">
							<strong>
								<?php

								// Data.
								echo esc_html(
									$total_program_revenue
								);

								?>
							</strong>
						</p>
					</div>
				<?php endif; ?>

				<div style="height: 150px; width: <?php echo esc_attr( $has_active_integration_supports_sales_repoorting ? '250px' : '160px' ); ?>; display: inline-table;">

					<p style="text-align: center; margin-bottom: 0;">
						<img style="display: inline-block;" src="<?php echo esc_url( AFFILIATEWP_PLUGIN_URL . 'assets/images/summaries/new-affiliates-icon.png' ); ?>" height="28" width="28" align="center" alt=" ">
					</p>
					<p style="margin-bottom: 0; margin-top: 5px; font-size: 14px; line-height: 18px;">
						<strong style="font-weight: 500;">
							<?php echo wp_kses_post( __( 'New Approved Affiliates', 'affiliate-wp' ) ); ?>
						</strong>
					</p>

					<p style="font-size: 32px; color: #000000; line-height: 32px; margin-top: 10px;">
						<strong>
							<?php

								// Data.
								echo absint(
									$new_approved_affiliates
								);

							?>
						</strong>
					</p>
				</div>

				<div style="height: 150px; width: <?php echo esc_attr( $has_active_integration_supports_sales_repoorting ? '250px' : '160px' ); ?>; display: inline-table;">

					<p style="text-align: center; margin-bottom: 0;">
						<img style="display: inline-block;" src="<?php echo esc_url( AFFILIATEWP_PLUGIN_URL . 'assets/images/summaries/unpaid-earnings-icon.png' ); ?>" height="28" width="28" align="center" alt=" ">
					</p>
					<p style="margin-bottom: 0; margin-top: 5px; font-size: 14px; line-height: 18px;">
						<strong style="font-weight: 500;">
							<?php echo wp_kses_post( __( 'Unpaid Earnings', 'affiliate-wp' ) ); ?>
						</strong>
					</p>

					<p style="font-size: 32px; color: #000000; line-height: 32px; margin-top: 10px;">
						<strong>
							<?php

							// Data.
							echo esc_html(
								$unpaid_earnings
							);

							?>
						</strong>
					</p>
				</div>

				<div style="height: 150px; width: <?php echo esc_attr( $has_active_integration_supports_sales_repoorting ? '250px' : '160px' ); ?>; display: inline-table;">

					<p style="text-align: center; margin-bottom: 0;">
						<img style="display: inline-block;" src="<?php echo esc_url( AFFILIATEWP_PLUGIN_URL . 'assets/images/summaries/paid-earnings-icon.png' ); ?>" height="28" width="28" align="center" alt=" ">
					</p>
					<p style="margin-bottom: 0; margin-top: 5px; font-size: 14px; line-height: 18px;">
						<strong style="font-weight: 500;">
							<?php echo wp_kses_post( __( 'Paid Earnings', 'affiliate-wp' ) ); ?>
						</strong>
					</p>

					<p style="font-size: 32px; color: #000000; line-height: 32px; margin-top: 10px;">
						<strong>
							<?php

							// Data.
							echo esc_html(
								$paid_earnings
							);

							?>
						</strong>
					</p>
				</div>
			</div>
		</div>

	</div>

	<?php if ( ! empty( $top_affiliates ) ) : ?>
		<div style="border-top: 1px solid #eee; padding-top: 20px; margin-bottom: 40px;">
			<div style="text-align: center; margin-bottom: 30px;">
				<p style="text-align: center; margin-bottom: 0;">
					<img style="display: inline-block;" src="<?php echo esc_url( AFFILIATEWP_PLUGIN_URL . 'assets/images/summaries/top-affiliates-icon.png' ); ?>" height="28" width="28" align="center" alt=" ">
				</p>
				<p style="margin-bottom: 0; margin-top: 5px; font-size: 14px; line-height: 18px;">
					<strong style="font-weight: 500;">
						<?php echo esc_html( sprintf( __( 'Top %1$s Most Valuable Affiliates', 'affiliate-wp' ), count( $top_affiliates ) ) ); ?>
					</strong>
				</p>
			</div>
			<table style="width: 100%; border-collapse: collapse; font-size: 12px; line-height: 12px; color: #000000;" cellpadding="10">
				<tbody>
					<tr>
						<td><strong style="font-weight: 500;"><?php esc_html_e( 'Affiliate', 'affiliate-wp' ); ?></strong></td>
						<td><strong style="font-weight: 500;"><?php esc_html_e( 'Earnings', 'affiliate-wp' ); ?></strong></td>
						<td><strong style="font-weight: 500;"><?php esc_html_e( 'Referrals', 'affiliate-wp' ); ?></strong></td>
						<td><strong style="font-weight: 500;"><?php esc_html_e( 'Visits', 'affiliate-wp' ); ?></strong></td>
					</tr>

					<?php foreach ( $top_affiliates as $top_affiliate_id ) : ?>
						<tr style="border-top: 1px solid #eee;">
							<td>
								<?php echo esc_html( affwp_get_affiliate_full_name_or_display_name( $top_affiliate_id ) ); ?>
							</td>

							<td>
								<?php echo esc_html( affwp_currency_filter( affwp_format_amount( affiliate_wp()->referrals->get_earnings_by_status( array( 'paid', 'unpaid' ), $top_affiliate_id, $timeframe ) ) ) ); ?>
							</td>
							<td>
								<?php echo esc_html( affiliate_wp()->referrals->count_by_status( array( 'paid', 'unpaid' ), $top_affiliate_id, $timeframe ) ); ?>
							</td>
							<td>
								<?php echo esc_html( affwp_count_visits( $top_affiliate_id, $timeframe ) ); ?>
							</td>
						</tr>
					<?php endforeach ?>

				</tbody>
			</table>
		</div>
	<?php endif; ?>

	<?php
	/*
	 * Did you Know Blurb...
	 */

	$dyk_blurb = isset( $_GET['no_dyk'] ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- We're not using the data.
		? array() // Never show a DYK blurb when previewing.
		: affwp_get_latest_unsent_dyk_blurb_for_my_license();

	// Only if we got a valid DYK blurb from above...
	if ( isset( $dyk_blurb['id'] ) ) {
		?>

		<div style="margin: 30px 0 0; clear: both;">

			<div style="padding: 32px 40px; background: #ECF6F6; border-radius: 10px;">

				<table style="font-style: normal; font-weight: 500; font-size: 17px; line-height: 24px; color: #368286; min-height: 24px;">
					<tr>
						<td width="25" style="vertical-align: top;"><img src="<?php echo esc_url( AFFILIATEWP_PLUGIN_URL . 'assets/images/summaries/megaphone-icon.png' ); ?>" height="24" width="24" alt="📣"></td>
						<td style="vertical-align: top;"><span style="display: inline-block; line-height: 21px; padding-left: 5px;"><?php esc_html_e( 'Pro tip from our expert:', 'affiliate-wp' ); ?></span></td>
					</tr>
				</table>

				<p style="margin-top: 20px; font-size: 18px; color: #17243B;"><strong><?php echo esc_html( $dyk_blurb['title'] ); ?></strong></p>
				<p><?php echo esc_html( wp_strip_all_tags( $dyk_blurb['content'] ) ); ?></p>

				<?php if ( isset( $dyk_blurb['url'] ) ) : ?>
					<p style="margin-bottom: -10px; margin-top: 18px;">
						<a style="display: inline-block; text-align: center; padding: 7.31469px 21.9441px; background: #F63F3A; border-radius: 32.9161px; color: #fff; text-decoration: none;" href="<?php echo esc_url( $dyk_blurb['url'] ); ?>" rel="noopener noreferrer"><?php echo esc_html( ( isset( $dyk_blurb['button'] ) && ! empty( $dyk_blurb['button'] ) ) ? $dyk_blurb['button'] : __( 'Learn More', 'affiliate-wp' ) ); ?></a>
					</p>
				<?php endif; ?>
			</div>
		</div>

		<?php
	}

	/*
	 * Collect the content and preview or email...
	 */

	return ob_get_clean();
}

/**
 * Use the Administrator's desired logo on Affiliate Summaries, if there is one.
 *
 * @since 2.9.7
 *
 * @param  string $header_img The header image used by default: AffiliateWP.
 * @param  mixed  $context    The context from get_query_var( 'context' ) in the template, null if none.
 * @return string             The default one if the Administrator hasn't selected a customized logo,
 *                            or the customized logo from the Emails setting tab.
 *
 * @see affwp_notify_monthly_affiliate_perf_summary() where this is used.
 */
function affwp_notify_monthly_affiliate_summary_header_img( $header_img, $context = null ) {

	$customized_logo = affiliate_wp()->settings->get( 'email_logo', '' );

	if ( ! filter_var( $customized_logo, FILTER_SANITIZE_URL ) ) {
		return $header_img; // Use AffiliateWP by default.
	}

	return $customized_logo; // Use the customers logo.
}
add_filter(
	'affwp_email_template_affiliate_summary_header_img',
	'affwp_notify_monthly_affiliate_summary_header_img',
	10,
	2
);
