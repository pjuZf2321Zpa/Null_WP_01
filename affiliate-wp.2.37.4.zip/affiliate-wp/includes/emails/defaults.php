<?php
/**
 * Emails: Default content
 *
 * One default per email, read by both the settings editor and the send path.
 *
 * These six emails predate the per-family defaults helpers (Stripe, payout
 * failure, batch failure, setup reminder) and each carried two defaults: one
 * inline in the Emails tab and a different one inline on its send path. What
 * an admin previewed was not what sent, and saving the tab silently pinned
 * the editor's version. This file is the send path's and the editor's single
 * source, in the same shape as affwp_get_stripe_email_content().
 *
 * @package     AffiliateWP
 * @subpackage  Emails
 * @copyright   Copyright (c) 2026, Awesome Motive, Inc.
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.36.1
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Retrieves the default subject and body for one of the core emails.
 *
 * Bodies are merge-tag templates: the send path parses tags with the affiliate
 * in context, exactly as it already does for a merchant-customised body.
 *
 * @since 2.36.1
 *
 * @param string $email Email identifier: registration, new_admin_referral,
 *                      referral, accepted, pending, or rejection.
 * @return array{subject: string, body: string} Empty strings for an unknown email.
 */
function affwp_get_email_default( $email ) {

	$defaults = array(
		'registration'       => array(
			'subject' => __( 'New Affiliate Registration', 'affiliate-wp' ),
			'body'    => __( 'A new affiliate has registered on your site, {site_name}.', 'affiliate-wp' ) . "\n\n" .
				__( 'Name: {name}', 'affiliate-wp' ) . "\n" .
				__( 'Website: {website}', 'affiliate-wp' ) . "\n" .
				__( 'Promotion method: {promo_method}', 'affiliate-wp' ) . "\n\n" .
				__( 'Review the application: {review_url}', 'affiliate-wp' ),
		),
		'new_admin_referral' => array(
			'subject' => __( 'New referral on {site_name}', 'affiliate-wp' ),
			'body'    => __( "A new referral has been recorded on {site_name}.\n\nAffiliate: {name}\nAmount: {amount}\nReferral URL: {referral_url}\n\nLog in to your dashboard to review this referral.", 'affiliate-wp' ),
		),
		'referral'           => array(
			'subject' => __( 'Referral Awarded!', 'affiliate-wp' ),
			'body'    => __( 'Congratulations {name}!', 'affiliate-wp' ) . "\n\n" .
				__( 'You have been awarded a new referral of {amount} on {site_name}!', 'affiliate-wp' ) . "\n\n" .
				__( 'Log into your affiliate area to view your earnings or disable these notifications:', 'affiliate-wp' ) . ' {login_url}',
		),
		'accepted'           => array(
			'subject' => __( 'Affiliate Application Accepted', 'affiliate-wp' ),
			'body'    => __( 'Congratulations {name}!', 'affiliate-wp' ) . "\n\n" .
				__( 'Your affiliate application on {site_name} has been accepted!', 'affiliate-wp' ) . "\n\n" .
				__( 'Log into your affiliate area at', 'affiliate-wp' ) . ' {login_url}',
		),
		'pending'            => array(
			'subject' => __( 'Your Affiliate Application Is Being Reviewed', 'affiliate-wp' ),
			'body'    => __( 'Hi {name}!', 'affiliate-wp' ) . "\n\n" .
				__( 'Thanks for your recent affiliate registration on {site_name}.', 'affiliate-wp' ) . "\n\n" .
				__( 'We&#8217;re currently reviewing your affiliate application and will be in touch soon!', 'affiliate-wp' ),
		),
		'rejection'          => array(
			'subject' => __( 'Your Affiliate Application Has Been Rejected', 'affiliate-wp' ),
			'body'    => __( 'Hi {name},', 'affiliate-wp' ) . "\n\n" .
				__( 'We regret to inform you that your recent affiliate registration on {site_name} was rejected.', 'affiliate-wp' ),
		),
	);

	return isset( $defaults[ $email ] ) ? $defaults[ $email ] : array( 'subject' => '', 'body' => '' );
}

/**
 * Reduces an email body to comparable text.
 *
 * A stored default is almost never byte-identical to the default it came from:
 * the rich editor wraps lines in paragraph tags, entities get decoded, older
 * defaults interpolated home_url() so the site's own address is baked in, and
 * whitespace varies. The question this supports is "is there anything bespoke
 * here to lose", so markup is deliberately dropped.
 *
 * @since 2.36.1
 *
 * @param string $text Raw body, stored or default.
 * @return string Normalized visible text.
 */
function affwp_normalize_email_body_text( $text ) {

	$text = wp_strip_all_tags( (string) $text );
	$text = html_entity_decode( $text, ENT_QUOTES | ENT_HTML5, 'UTF-8' );

	$home = untrailingslashit( home_url() );
	if ( '' !== $home ) {
		$text = str_ireplace( array( trailingslashit( $home ), $home ), '{home}', $text );
	}

	return trim( preg_replace( '/\s+/u', ' ', $text ) );
}

/**
 * The current default body for a stored email body field, or null when the
 * field is not one this file knows how to resolve.
 *
 * @since 2.36.1
 *
 * @param string $field Settings field name.
 * @return string|null
 */
function affwp_get_email_body_default_for_field( $field ) {

	// The six core emails.
	$core = array(
		'registration_email'       => 'registration',
		'new_admin_referral_email' => 'new_admin_referral',
		'referral_email'           => 'referral',
		'accepted_email'           => 'accepted',
		'pending_email'            => 'pending',
		'rejection_email'          => 'rejection',
	);
	if ( isset( $core[ $field ] ) ) {
		return affwp_get_email_default( $core[ $field ] )['body'];
	}

	// The Stripe payout-method emails. stripe_payout_paid_affiliate_body is the
	// field the 2.36.0 editor mistakenly saved the affiliate body under; a
	// default snapshot stored there resolves the same way.
	$stripe = array(
		'stripe_transfer_created_body'                         => 'transfer_created_affiliate',
		'stripe_transfer_created_admin_body'                   => 'transfer_created_admin',
		'stripe_transfer_failed_affiliate_body'                => 'transfer_failed_affiliate',
		'stripe_transfer_failed_admin_body'                    => 'transfer_failed_admin',
		'stripe_transfer_reversed_admin_body'                  => 'transfer_reversed_admin',
		'stripe_payout_completed_affiliate_body'               => 'payout_completed_affiliate',
		'stripe_payout_paid_affiliate_body'                    => 'payout_completed_affiliate',
		'stripe_payout_completed_admin_body'                   => 'payout_completed_admin',
		'stripe_payout_failed_affiliate_body'                  => 'payout_failed_affiliate',
		'stripe_payout_failed_admin_body'                      => 'payout_failed_admin',
		'stripe_account_verification_required_affiliate_body'  => 'account_verification_required_affiliate',
		'stripe_account_verification_required_admin_body'      => 'account_verification_required_admin',
		'stripe_account_connected_affiliate_body'              => 'account_connected_affiliate',
		'stripe_account_connected_admin_body'                  => 'account_connected_admin',
	);
	if ( isset( $stripe[ $field ] ) && function_exists( 'affwp_get_stripe_email_content' ) ) {
		$content = affwp_get_stripe_email_content( $stripe[ $field ] );
		return isset( $content['body'] ) ? $content['body'] : null;
	}

	// One body per payout method.
	if ( preg_match( '/^payout_failure_([a-z0-9\-]+)_body$/', $field, $m )
		&& class_exists( '\AffWP\Payouts\Failure_Email_Registry' )
		&& \AffWP\Payouts\Failure_Email_Registry::has_template( $m[1] ) ) {
		return \AffWP\Payouts\Failure_Email_Registry::get_body_default( $m[1] );
	}

	/*
	 * Setup-reminder variants and the admin batch-failure email. Their
	 * subjects are already mapped; without these, suppress cannot
	 * recognise the editor's visible default after a reset, and the
	 * next save re-pins stock copy over the merchant backup.
	 */
	if ( function_exists( 'affwp_get_payout_setup_reminder_email_variants' ) ) {
		foreach ( affwp_get_payout_setup_reminder_email_variants() as $variant ) {
			if ( $field === $variant['field'] ) {
				return $variant['body'];
			}
		}
	}

	if ( 'admin_payout_batch_failed_email' === $field
		&& function_exists( 'affwp_get_admin_batch_failure_email_defaults' ) ) {
		$d = affwp_get_admin_batch_failure_email_defaults();
		return isset( $d['body'] ) ? $d['body'] : null;
	}

	return null;
}

/**
 * The current default subject for a stored email subject field, or null when
 * the field is not one this file knows how to resolve.
 *
 * @since 2.36.1
 *
 * @param string $field Settings field name.
 * @return string|null
 */
function affwp_get_email_subject_default_for_field( $field ) {

	$core = array(
		'registration_subject'       => 'registration',
		'new_admin_referral_subject' => 'new_admin_referral',
		'referral_subject'           => 'referral',
		'accepted_subject'           => 'accepted',
		'pending_subject'            => 'pending',
		'rejection_subject'          => 'rejection',
	);
	if ( isset( $core[ $field ] ) ) {
		return affwp_get_email_default( $core[ $field ] )['subject'];
	}

	$stripe = array(
		'stripe_transfer_created_subject'                        => 'transfer_created_affiliate',
		'stripe_transfer_created_admin_subject'                  => 'transfer_created_admin',
		'stripe_transfer_failed_affiliate_subject'               => 'transfer_failed_affiliate',
		'stripe_transfer_failed_admin_subject'                   => 'transfer_failed_admin',
		'stripe_transfer_reversed_admin_subject'                 => 'transfer_reversed_admin',
		'stripe_payout_completed_affiliate_subject'              => 'payout_completed_affiliate',
		'stripe_payout_completed_admin_subject'                  => 'payout_completed_admin',
		'stripe_payout_failed_affiliate_subject'                 => 'payout_failed_affiliate',
		'stripe_payout_failed_admin_subject'                     => 'payout_failed_admin',
		'stripe_account_verification_required_affiliate_subject' => 'account_verification_required_affiliate',
		'stripe_account_verification_required_admin_subject'     => 'account_verification_required_admin',
		'stripe_account_connected_affiliate_subject'             => 'account_connected_affiliate',
		'stripe_account_connected_admin_subject'                 => 'account_connected_admin',
	);
	if ( isset( $stripe[ $field ] ) && function_exists( 'affwp_get_stripe_email_content' ) ) {
		$content = affwp_get_stripe_email_content( $stripe[ $field ] );
		return isset( $content['subject'] ) ? $content['subject'] : null;
	}

	// Emails whose variants share one subject.
	if ( 'payout_failure_action_subject' === $field && function_exists( 'affwp_get_payout_failure_email_defaults' ) ) {
		$d = affwp_get_payout_failure_email_defaults();
		return isset( $d['subject'] ) ? $d['subject'] : null;
	}
	if ( 'payout_setup_reminder_subject' === $field && function_exists( 'affwp_get_payout_setup_reminder_email_content' ) ) {
		$d = affwp_get_payout_setup_reminder_email_content();
		return isset( $d['subject'] ) ? $d['subject'] : null;
	}
	if ( 'admin_payout_batch_failed_subject' === $field && function_exists( 'affwp_get_admin_batch_failure_email_defaults' ) ) {
		$d = affwp_get_admin_batch_failure_email_defaults();
		return isset( $d['subject'] ) ? $d['subject'] : null;
	}

	return null;
}

/**
 * Defaults that shipped and were later improved: the population a stored
 * snapshot can actually match. When a default changes, its old body is added
 * here in the same commit, because after that commit the old string exists
 * nowhere else to compare against.
 *
 * @since 2.36.1
 *
 * @param string $field Settings field name.
 * @return string[]
 */
function affwp_get_historical_email_body_defaults( $field ) {

	$home = untrailingslashit( home_url() );

	$historical = array(
		// Pre-2.36.1 editor defaults, which saving the tab persisted verbatim.
		'registration_email'                     => array(
			"A new affiliate has registered on your site, {$home}\n\nName: {name}\n\n{website}\n\n{promo_method}",
		),
		'referral_email'                         => array(
			"Congratulations {name}!\n\nYou have been awarded a new referral of {amount} on {$home}!\n\nLog into your affiliate area to view your earnings or disable these notifications: {login_url}",
		),
		'accepted_email'                         => array(
			"Congratulations {name}!\n\nYour affiliate application on {$home} has been accepted!\n\nLog into your affiliate area at {login_url}",
		),
		// The pre-2026-08-27 Stripe payout notifications, which claimed arrival.
		'stripe_payout_completed_affiliate_body' => array(
			"Hi {name},\n\nGood news, your payout has arrived!\n\nAmount: <strong>{amount}</strong>\nCompleted: {payout_date}\n\nThe funds are now in your bank account.\n\nThanks for being an amazing affiliate!",
		),
		'stripe_payout_completed_admin_body'     => array(
			"Payout <strong>completed</strong> to bank.\n\nAffiliate: {name}\nAmount: <strong>{amount}</strong>\nCompleted: {payout_date}\n\nFunds have been deposited to affiliate's bank account.\n\nView in Stripe: {stripe_dashboard_url}",
		),
	);

	// The wrong-key field can hold the same old affiliate snapshot.
	$historical['stripe_payout_paid_affiliate_body'] = $historical['stripe_payout_completed_affiliate_body'];

	// The pre-2026-08-27 subjects of the same two emails.
	$historical['stripe_payout_completed_affiliate_subject'] = array( '{site_name}: Your {amount} payout has arrived!' );
	$historical['stripe_payout_completed_admin_subject']     = array( 'Payout completed - {amount}' );

	return isset( $historical[ $field ] ) ? $historical[ $field ] : array();
}

/**
 * Whether a stored body or subject is a default someone saved rather than wording someone wrote.
 *
 * @since 2.36.1
 *
 * @param string $body  Stored body.
 * @param string $field Settings field name.
 * @return bool
 */
function affwp_email_body_is_default( $body, $field ) {

	$normalized = affwp_normalize_email_body_text( $body );
	if ( '' === $normalized ) {
		return false;
	}

	/* A historical match is checked even when the current default is unknowable
	   (the family's file not loaded): an old shipped default is not bespoke
	   wording, whichever modules this request happens to have. */
	$current = substr( $field, -8 ) === '_subject'
		? affwp_get_email_subject_default_for_field( $field )
		: affwp_get_email_body_default_for_field( $field );

	if ( null !== $current && $normalized === affwp_normalize_email_body_text( $current ) ) {
		return true;
	}

	foreach ( affwp_get_historical_email_body_defaults( $field ) as $old ) {
		if ( $normalized === affwp_normalize_email_body_text( $old ) ) {
			return true;
		}
	}

	return false;
}

/**
 * Read-time resolution: a stored body that matches a current or historical
 * default reads as empty, and empty already resolves to the current default
 * everywhere. Nothing is written, so a wrong comparison costs nothing and a
 * historical default added later fixes old installs on their next page load.
 *
 * Runs on `option_affwp_settings`, the one point every reader passes: the
 * Settings class primes its cache from get_option(), and raw get_option()
 * callers get the same view.
 *
 * The defaults are translated, so reads before `init` pass through untouched.
 * The Settings class resolves the copy it cached then on the first email read
 * after `init` (Affiliate_WP_Settings::get()).
 *
 * @since 2.36.1
 * @since 2.37.3 Reads before `init` are left unresolved.
 *
 * @param mixed $value Option value being read.
 * @return mixed
 */
function affwp_resolve_stored_email_bodies( $value ) {

	// A default getter below may itself read this option; give re-entrant
	// reads the raw array rather than recursing.
	static $resolving = false;
	static $memo_in = null, $memo_out = null;

	if ( $resolving || ! is_array( $value ) || ! function_exists( 'affiliate_wp' ) || ! did_action( 'init' ) ) {
		return $value;
	}

	if ( $memo_in !== null && $memo_in === $value ) {
		return $memo_out;
	}

	$resolving = true;
	$in        = $value;

	foreach ( $value as $field => $body ) {
		if ( ! is_string( $body ) || '' === $body || ( substr( $field, -5 ) !== '_body' && substr( $field, -6 ) !== '_email' && substr( $field, -8 ) !== '_subject' ) ) {
			continue;
		}
		if ( affwp_email_body_is_default( $body, $field ) ) {
			$value[ $field ] = '';
		}
	}

	$resolving = false;
	$memo_in   = $in;
	$memo_out  = $value;

	return $value;
}
add_filter( 'option_affwp_settings', 'affwp_resolve_stored_email_bodies' );

/**
 * Write-time suppression: never persist a body equal to its default. The tidy-up
 * half of the mechanism above; correctness lives on the read side.
 *
 * Runs on `pre_update_option_affwp_settings`, after sanitization, so it sees the
 * final array and covers every writer.
 *
 * @since 2.36.1
 * @since 2.37.3 Skipped before init, when translations aren't loaded yet.
 *
 * @param mixed $value Option value about to be written.
 * @return mixed
 */
function affwp_suppress_default_email_bodies( $value ) {

	static $suppressing = false;

	// The defaults are translated, so a save before init (the daily license check) keeps bodies as they are.
	if ( $suppressing || ! is_array( $value ) || ! function_exists( 'affiliate_wp' ) || ! did_action( 'init' ) ) {
		return $value;
	}

	$suppressing = true;

	foreach ( $value as $field => $body ) {
		if ( ! is_string( $body ) || '' === $body || ( substr( $field, -5 ) !== '_body' && substr( $field, -6 ) !== '_email' && substr( $field, -8 ) !== '_subject' ) ) {
			continue;
		}
		if ( affwp_email_body_is_default( $body, $field ) ) {
			unset( $value[ $field ] );
		}
	}

	$suppressing = false;

	return $value;
}
add_filter( 'pre_update_option_affwp_settings', 'affwp_suppress_default_email_bodies', 20 );

/**
 * The settings fields a reset of this email may touch, or null for an unknown field.
 *
 * The rule is exclusive ownership: a single-body email resets subject and body
 * together, because the row's offer reads as "this email"; a variant body
 * (payout failure per method, setup reminder per reason) resets itself only,
 * because its subject is shared with variants the merchant is not looking at.
 *
 * @since 2.36.1
 *
 * @param string $body_field The body field the row renders under.
 * @return string[]|null Fields to reset, body first.
 */
function affwp_get_email_reset_fields( $body_field ) {

	$pairs = array(
		'registration_email'                                   => 'registration_subject',
		'new_admin_referral_email'                             => 'new_admin_referral_subject',
		'referral_email'                                       => 'referral_subject',
		'accepted_email'                                       => 'accepted_subject',
		'pending_email'                                        => 'pending_subject',
		'rejection_email'                                      => 'rejection_subject',
		'admin_payout_batch_failed_email'                      => 'admin_payout_batch_failed_subject',
		'stripe_transfer_created_body'                         => 'stripe_transfer_created_subject',
		'stripe_transfer_created_admin_body'                   => 'stripe_transfer_created_admin_subject',
		'stripe_transfer_failed_affiliate_body'                => 'stripe_transfer_failed_affiliate_subject',
		'stripe_transfer_failed_admin_body'                    => 'stripe_transfer_failed_admin_subject',
		'stripe_transfer_reversed_admin_body'                  => 'stripe_transfer_reversed_admin_subject',
		'stripe_payout_completed_affiliate_body'               => 'stripe_payout_completed_affiliate_subject',
		'stripe_payout_completed_admin_body'                   => 'stripe_payout_completed_admin_subject',
		'stripe_payout_failed_affiliate_body'                  => 'stripe_payout_failed_affiliate_subject',
		'stripe_payout_failed_admin_body'                      => 'stripe_payout_failed_admin_subject',
		'stripe_account_verification_required_affiliate_body'  => 'stripe_account_verification_required_affiliate_subject',
		'stripe_account_verification_required_admin_body'      => 'stripe_account_verification_required_admin_subject',
		'stripe_account_connected_affiliate_body'              => 'stripe_account_connected_affiliate_subject',
		'stripe_account_connected_admin_body'                  => 'stripe_account_connected_admin_subject',
	);

	if ( isset( $pairs[ $body_field ] ) ) {
		$fields = array( $body_field, $pairs[ $body_field ] );

		/*
		 * 2.36.0 saved this email under stripe_payout_paid_affiliate_body.
		 * Send and the editor still read that orphan when the completed
		 * key is empty, so reset must own it or "Use the latest default"
		 * leaves the old copy sending.
		 */
		if ( 'stripe_payout_completed_affiliate_body' === $body_field ) {
			$fields[] = 'stripe_payout_paid_affiliate_body';
		}

		return $fields;
	}

	// Variant bodies own no subject: payout_failure_{method}_body and the two
	// setup-reminder bodies share theirs across versions.
	if ( preg_match( '/^payout_failure_[a-z0-9\-]+_body$/', $body_field )
		|| in_array( $body_field, array( 'payout_setup_reminder_body', 'payout_setup_reminder_changed_body', 'payout_failure_action_email' ), true ) ) {
		return array( $body_field );
	}

	return null;
}

/**
 * Resets an email's wording to the current defaults, keeping what was stored.
 *
 * Writes empty values rather than removing keys, because the settings
 * sanitiser merges over what is stored, and empty already resolves to the
 * current default everywhere.
 *
 * @since 2.36.1
 *
 * @param string $body_field The body field the row renders under.
 * @return string[]|\WP_Error The fields cleared, or why nothing was.
 */
function affwp_reset_email_wording( $body_field ) {

	$fields = affwp_get_email_reset_fields( $body_field );
	if ( null === $fields ) {
		return new \WP_Error( 'unknown_email_field', __( 'Unknown email field.', 'affiliate-wp' ) );
	}

	$options = get_option( 'affwp_settings', array() );
	$kept    = array();
	foreach ( $fields as $field ) {
		if ( isset( $options[ $field ] ) && is_string( $options[ $field ] ) && '' !== trim( $options[ $field ] ) ) {
			$kept[ $field ] = $options[ $field ];
		}
	}

	if ( empty( $kept ) ) {
		return new \WP_Error( 'already_default', __( 'This email already uses the default wording.', 'affiliate-wp' ) );
	}

	$backups                = get_option( 'affwp_email_body_backups', array() );
	$backups[ $body_field ] = array(
		'fields' => $kept,
		'time'   => time(),
	);
	update_option( 'affwp_email_body_backups', $backups, false );

	affiliate_wp()->settings->set( array_fill_keys( array_keys( $kept ), '' ), true );

	return array_keys( $kept );
}

/**
 * Puts back the wording a reset saved.
 *
 * @since 2.36.1
 *
 * @param string $body_field The body field the row renders under.
 * @return true|\WP_Error
 */
function affwp_restore_email_wording( $body_field ) {

	if ( null === affwp_get_email_reset_fields( $body_field ) ) {
		return new \WP_Error( 'unknown_email_field', __( 'Unknown email field.', 'affiliate-wp' ) );
	}

	$backups = get_option( 'affwp_email_body_backups', array() );
	if ( empty( $backups[ $body_field ]['fields'] ) ) {
		return new \WP_Error( 'no_backup', __( 'No saved wording to restore for this email.', 'affiliate-wp' ) );
	}

	$restore = array();
	foreach ( $backups[ $body_field ]['fields'] as $field => $value ) {
		$restore[ $field ] = wp_kses_post( $value );
	}

	// The suppressor would eat a restored value that happens to match a default;
	// a restore is an explicit request for exactly what was saved.
	remove_filter( 'pre_update_option_affwp_settings', 'affwp_suppress_default_email_bodies', 20 );
	affiliate_wp()->settings->set( $restore, true );
	add_filter( 'pre_update_option_affwp_settings', 'affwp_suppress_default_email_bodies', 20 );

	unset( $backups[ $body_field ] );
	update_option( 'affwp_email_body_backups', $backups, false );

	return true;
}
