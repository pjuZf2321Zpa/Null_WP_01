<?php
/**
 * User Login Bootstrap
 *
 * @package     AffiliateWP
 * @subpackage  Core
 * @copyright   Copyright (c) 2014, Sandhills Development, LLC
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       1.0
 */

#[\AllowDynamicProperties]

class Affiliate_WP_Login {

	private $errors;

	/**
	 * Get things started
	 *
	 * @since 1.0
	 */
	public function __construct() {

		add_action( 'affwp_user_login', [ $this, 'process_login' ] );
		add_action( 'affwp_lost_password', [ $this, 'process_lost_password' ] );
		add_action( 'affwp_reset_password', [ $this, 'process_reset_password' ] );
		add_action( 'template_redirect', [ $this, 'redirect_out_from_login_page_when_logged' ] );
	}

	/**
	 * Prevents users from direct accessing the Login page if they are already logged.
	 *
	 * @since 2.25.0
	 * @return void
	 */
	public function redirect_out_from_login_page_when_logged() {

		if ( ! is_user_logged_in() ) {
			return; // Bail if the user is not logged.
		}

		if ( 'login' !== $this->get_form_state() ) {
			return; // A logged-in user can still open a set-password or lost-password link.
		}

		$affiliate_area_page_id = affwp_get_affiliate_area_page_id();
		$login_page_id          = affiliatewp_get_affiliate_login_page_id();

		if ( $affiliate_area_page_id === $login_page_id ) {
			return; // Bail since the login page is the same as the Affiliate Area page.
		}

		if ( is_page( $login_page_id ) && ! empty( $affiliate_area_page_id ) ) {
			wp_safe_redirect(
				get_permalink( $affiliate_area_page_id )
			);
			exit;
		}
	}

	/**
	 * Login Form
	 *
	 * @since 1.2
	 * @global $affwp_login_redirect
	 * @param string $redirect Redirect page URL
	 * @return string Login form
	 */
	public function login_form( $redirect = '' ) {
		global $affwp_login_redirect;

		if ( empty( $redirect ) ) {
			$redirect = affiliate_wp()->tracking->get_current_page_url();
		}

		$affwp_login_redirect = $redirect;

		ob_start();

		$this->render();

		/**
		 * Filters the output for the AffiliateWP login form.
		 *
		 * @since 1.2
		 *
		 * @param string $output Output for the login form.
		 */
		return apply_filters( 'affwp_login_form', ob_get_clean() );
	}

	/**
	 * Process the loginform submission
	 *
	 * @since 1.0
	 */
	public function process_login( $data ) {

		if ( ! isset( $_POST['affwp_login_nonce'] ) || ! wp_verify_nonce( $_POST['affwp_login_nonce'], 'affwp-login-nonce' ) ) {
			return;
		}

		/**
		 * Fires immediately prior to processing the affiliate login form.
		 *
		 * @since 1.0
		 */
		do_action( 'affwp_pre_process_login_form' );

		// CAPTCHA first: nothing about the credentials is computed or reported until it passes, so the
		// form cannot be used as a username/password oracle while the CAPTCHA stays unsolved (audit #15a).
		if ( AffWP_Captcha_Manager::is_login_enabled() ) {
			if ( ! AffWP_Captcha_Manager::validate_response( $data, 'login' ) ) {
				$active_type = AffWP_Captcha_Manager::get_active_type();
				$this->add_error( $active_type . '_required', AffWP_Captcha_Manager::get_error_message( $active_type ) );

				return;
			}
		}

		// Honour an optional third-party login throttle before touching credentials.
		if ( function_exists( 'is_limit_login_ok' ) && ! is_limit_login_ok() ) {
			$this->add_error( 'limit_login_failed', limit_login_error_msg() );

			return;
		}

		$user_login = isset( $data['affwp_user_login'] ) ? sanitize_text_field( $data['affwp_user_login'] ) : '';
		$user_pass  = isset( $data['affwp_user_pass'] ) ? $data['affwp_user_pass'] : '';

		// One message for every credential failure, so the response never distinguishes "no such user"
		// from "wrong password" (audit #15a).
		if ( '' === $user_login || '' === $user_pass ) {
			$this->add_error( 'invalid_credentials', __( 'Incorrect username or password', 'affiliate-wp' ) );

			return;
		}

		$user = get_user_by( 'login', $user_login );

		if ( ! $user ) {
			$user = get_user_by( 'email', $user_login );
		}

		/**
		 * Filters whether to perform the password check on affiliate login.
		 *
		 * @since 2.0.6
		 *
		 * @param bool     $check Whether to check the password or not.
		 * @param \WP_User $user  The WordPress user whose password is being checked.
		 */
		if ( true === apply_filters( 'affwp_login_check_password', true, $user ) ) {

			// Authenticate through WordPress so the authenticate filter chain applies: two-factor
			// challenges and brute-force throttles that hook `authenticate`/`wp_login_failed` now run, and
			// the affiliate login form is no longer a second, unguarded front door (audit #15a).
			$authenticated = wp_authenticate( $user_login, $user_pass );

			if ( is_wp_error( $authenticated ) ) {

				// WordPress's own credential errors share one message so the form does not reveal which
				// accounts exist. Any other error comes from a plugin (two-factor, lockout, account
				// approval) and is shown, so the affiliate knows why they cannot sign in.
				$credential_errors = array( 'invalid_username', 'invalid_email', 'incorrect_password', 'empty_username', 'empty_password' );
				$plugin_message    = in_array( $authenticated->get_error_code(), $credential_errors, true )
					? ''
					: trim( wp_strip_all_tags( $authenticated->get_error_message() ) );

				$this->add_error( 'invalid_credentials', '' !== $plugin_message ? $plugin_message : __( 'Incorrect username or password', 'affiliate-wp' ) );

				return;
			}

			$user = $authenticated;

		} elseif ( ! $user ) {

			// The password check was waived by the filter, but a real user is still required to log in.
			$this->add_error( 'invalid_credentials', __( 'Incorrect username or password', 'affiliate-wp' ) );

			return;
		}

		/**
		 * Fires immediately after processing an affiliate login form.
		 *
		 * @since 1.0
		 */
		do_action( 'affwp_process_login_form' );

		// only log the user in if there are no errors
		if ( empty( $this->errors ) ) {

			$remember = ! empty( $data['affwp_user_remember'] );

			// Use the resolved account's real login (the submitted value may have been an email address).
			$this->log_user_in( $user->ID, $user->user_login, $remember );

			$redirect = empty( $data['affwp_redirect'] ) ? affwp_get_affiliate_area_page_url() : $data['affwp_redirect'];

			/**
			 * Filters the redirect URL used after a successful login via the AffiliateWP login form.
			 *
			 * @since 1.0
			 *
			 * @param string $redirect Login redirect URL.
			 */
			$redirect = apply_filters( 'affwp_login_redirect', $redirect );

			if ( $redirect ) {
				wp_safe_redirect( wp_validate_redirect( $redirect, home_url() ) );
				exit;
			}
		} elseif ( function_exists( 'limit_login_failed' ) ) {

				limit_login_failed( $user_login );
		}
	}

	/**
	 * Process a lost-password request from an AffiliateWP login surface.
	 *
	 * Origin-scoped, not role-scoped. Only this form (and generated-password
	 * emails that use get_reset_password_url()) complete in the affiliate area.
	 * Do not filter login_redirect by affiliate role: dual-role users who reset
	 * from EDD, Woo, or wp-login.php must stay on those products.
	 *
	 * @since 2.36.2
	 *
	 * @param array $data Request data from affwp_do_actions().
	 */
	public function process_lost_password( $data ) {

		$this->errors = [];

		if ( ! isset( $_POST['affwp_lost_password_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['affwp_lost_password_nonce'] ) ), 'affwp-lost-password-nonce' ) ) {
			return;
		}

		if ( empty( $data['affwp_user_login'] ) ) {
			$this->add_error( 'empty_username', __( 'Please enter a username or email', 'affiliate-wp' ) );
			return;
		}

		if ( AffWP_Captcha_Manager::is_login_enabled() ) {
			$captcha_valid = AffWP_Captcha_Manager::validate_response( $data, 'login' );

			if ( ! $captcha_valid ) {
				$active_type   = AffWP_Captcha_Manager::get_active_type();
				$error_message = AffWP_Captcha_Manager::get_error_message( $active_type );
				$this->add_error( $active_type . '_required', $error_message );
				return;
			}
		}

		$user_login = sanitize_text_field( $data['affwp_user_login'] );
		$user       = get_user_by( 'login', $user_login );

		if ( ! $user ) {
			$user = get_user_by( 'email', $user_login );
		}

		if ( $user ) {
			$key = get_password_reset_key( $user );

			if ( is_wp_error( $key ) ) {
				$this->add_error( 'password_reset_not_allowed', __( 'Password reset is not available for this account.', 'affiliate-wp' ) );
				return;
			}

			$this->send_lost_password_email( $user, $key );
		}

		// Known and unknown accounts share this success path so the form cannot be used to enumerate users.
		$this->redirect_to_login(
			[
				'affwp_notice' => 'lost-password-sent',
			]
		);
	}

	/**
	 * Process a set-new-password submission from an AffiliateWP login surface.
	 *
	 * @since 2.36.2
	 *
	 * @param array $data Request data from affwp_do_actions().
	 */
	public function process_reset_password( $data ) {

		$this->errors = [];

		if ( ! isset( $_POST['affwp_reset_password_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['affwp_reset_password_nonce'] ) ), 'affwp-reset-password-nonce' ) ) {
			return;
		}

		$user = $this->get_reset_user();

		if ( is_wp_error( $user ) ) {
			$this->add_error( $user->get_error_code(), $user->get_error_message() );
			return;
		}

		$password         = isset( $data['affwp_user_pass'] ) ? wp_unslash( $data['affwp_user_pass'] ) : '';
		$password_confirm = isset( $data['affwp_user_pass_confirm'] ) ? wp_unslash( $data['affwp_user_pass_confirm'] ) : '';

		if ( '' === $password ) {
			$this->add_error( 'empty_password', __( 'Please enter a password', 'affiliate-wp' ) );
		}

		if ( $password !== $password_confirm ) {
			$this->add_error( 'password_mismatch', __( 'The passwords do not match.', 'affiliate-wp' ) );
		}

		if ( ! empty( $this->errors ) ) {
			return;
		}

		reset_password( $user, $password );

		$this->log_user_in( $user->ID, $user->user_login );

		$redirect = empty( $data['affwp_redirect'] ) ? affwp_get_affiliate_area_page_url() : $data['affwp_redirect'];

		/** This filter is documented in includes/class-login.php */
		$redirect = apply_filters( 'affwp_login_redirect', $redirect );

		$redirect = add_query_arg( 'affwp_notice', 'password-updated', $redirect );

		wp_safe_redirect( wp_validate_redirect( $redirect, home_url() ) );
		exit;
	}

	/**
	 * Send the affiliate password-reset email.
	 *
	 * @since 2.36.2
	 *
	 * @param WP_User $user User requesting the reset.
	 * @param string  $key  Password reset key from get_password_reset_key().
	 * @return bool Whether the email was sent.
	 */
	public function send_lost_password_email( WP_User $user, $key ) {

		$reset_url = $this->get_reset_password_url( $key, $user->user_login );

		$subject = __( 'Reset your password', 'affiliate-wp' );

		$message  = __( 'Someone requested a password reset for the following account:', 'affiliate-wp' ) . "\r\n\r\n";
		$message .= sprintf(
			/* translators: %s: Username. */
			__( 'Username: %s', 'affiliate-wp' ),
			$user->user_login
		) . "\r\n\r\n";
		$message .= __( 'If this was a mistake, ignore this email and nothing will happen.', 'affiliate-wp' ) . "\r\n\r\n";
		$message .= __( 'To reset your password, visit the following address:', 'affiliate-wp' ) . "\r\n\r\n";
		$message .= $reset_url . "\r\n";

		/**
		 * Filters the lost-password email subject.
		 *
		 * @since 2.36.2
		 *
		 * @param string  $subject Email subject.
		 * @param WP_User $user    User requesting the reset.
		 */
		$subject = apply_filters( 'affwp_lost_password_email_subject', $subject, $user );

		/**
		 * Filters the lost-password email message.
		 *
		 * @since 2.36.2
		 *
		 * @param string  $message   Email message.
		 * @param WP_User $user      User requesting the reset.
		 * @param string  $reset_url Reset URL.
		 */
		$message = apply_filters( 'affwp_lost_password_email_message', $message, $user, $reset_url );

		$emails = new Affiliate_WP_Emails();

		$affiliate_id = affwp_get_affiliate_id( $user->ID );

		if ( $affiliate_id ) {
			$emails->__set( 'affiliate_id', $affiliate_id );
		}

		return (bool) $emails->send( $user->user_email, $subject, $message );
	}

	/**
	 * Current login-page form state.
	 *
	 * @since 2.36.2
	 *
	 * @return string One of login, lost_password, lost_password_sent, reset_password.
	 */
	public function get_form_state() {

		if ( $this->request_has_reset_password() ) {
			return 'reset_password';
		}

		if ( 'lost-password-sent' === $this->get_query_arg( 'affwp_notice' ) ) {
			return 'lost_password_sent';
		}

		if ( $this->request_has_lost_password() ) {
			return 'lost_password';
		}

		return 'login';
	}

	/**
	 * Render the current login-page state.
	 *
	 * Reset markup lives here so it is not a theme-overridable template.
	 * Copied login.php files only need the lost-password href updated.
	 * Email set-password links still work even if that file is outdated.
	 *
	 * @since 2.36.2
	 */
	public function render() {

		$state = $this->get_form_state();

		if ( 'login' !== $state ) {
			echo $this->get_password_reset_markup( $state ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			return;
		}

		affiliate_wp()->templates->get_template_part( 'login' );
	}

	/**
	 * Markup for request-reset, sent, and set-password states.
	 *
	 * @since 2.36.2
	 *
	 * @param string|null $state Form state. Default current state.
	 * @return string
	 */
	public function get_password_reset_markup( $state = null ) {

		if ( null === $state ) {
			$state = $this->get_form_state();
		}

		ob_start();

		if ( 'lost_password_sent' === $state ) {
			$this->render_lost_password_sent();
		} elseif ( 'lost_password' === $state ) {
			$this->render_lost_password_request();
		} elseif ( 'reset_password' === $state ) {
			$this->render_reset_password();
		}

		return ob_get_clean();
	}

	/**
	 * Confirmation after a reset email was requested.
	 *
	 * @since 2.36.2
	 */
	private function render_lost_password_sent() {
		?>
		<div class="affwp-form affwp-lost-password-form">
			<p class="affwp-notice">
				<?php esc_html_e( 'If an account exists for that username or email, we have sent a password reset link. It may take a few minutes to arrive.', 'affiliate-wp' ); ?>
			</p>
			<p class="affwp-login-link">
				<a href="<?php echo esc_url( $this->get_login_url() ); ?>"><?php esc_html_e( 'Back to log in', 'affiliate-wp' ); ?></a>
			</p>
		</div>
		<?php
	}

	/**
	 * Request-reset form.
	 *
	 * @since 2.36.2
	 */
	private function render_lost_password_request() {

		$this->print_errors();
		$form_id_suffix = wp_rand( 1000, 9999 );
		?>
		<form id="affwp-login-form-<?php echo esc_attr( $form_id_suffix ); ?>" class="affwp-form affwp-lost-password-form" action="" method="post">
			<fieldset>
				<legend><?php esc_html_e( 'Reset your password', 'affiliate-wp' ); ?></legend>

				<p>
					<?php esc_html_e( 'Enter your username or email. We will send a link to choose a new password.', 'affiliate-wp' ); ?>
				</p>

				<p>
					<label for="affwp-lost-password-user-login"><?php esc_html_e( 'Username or email', 'affiliate-wp' ); ?></label>
					<input id="affwp-lost-password-user-login" class="required" type="text" name="affwp_user_login" title="<?php esc_attr_e( 'Username or email', 'affiliate-wp' ); ?>" />
				</p>

				<p>
					<input type="hidden" name="affwp_lost_password_nonce" value="<?php echo esc_attr( wp_create_nonce( 'affwp-lost-password-nonce' ) ); ?>" />
					<input type="hidden" name="affwp_action" value="lost_password" />

					<?php
					// Render CAPTCHA field and submit button using the login context.
					echo AffWP_Captcha_Manager::render_captcha_field( 'login', $form_id_suffix, __( 'Send reset link', 'affiliate-wp' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					?>
				</p>

				<p class="affwp-login-link">
					<a href="<?php echo esc_url( $this->get_login_url() ); ?>"><?php esc_html_e( 'Back to log in', 'affiliate-wp' ); ?></a>
				</p>
			</fieldset>
		</form>
		<?php
	}

	/**
	 * Set-password form, or an invalid-key message.
	 *
	 * @since 2.36.2
	 */
	private function render_reset_password() {

		$user  = $this->get_reset_user();
		$key   = $this->get_requested_reset_key();
		$login = $this->get_requested_reset_login();

		if ( is_wp_error( $user ) ) {
			?>
			<div class="affwp-form affwp-reset-password-form">
				<div class="affwp-errors">
					<p class="affwp-error"><?php echo esc_html( $user->get_error_message() ); ?></p>
				</div>
				<p class="affwp-lost-password">
					<a href="<?php echo esc_url( $this->get_lost_password_url() ); ?>"><?php esc_html_e( 'Request a new reset link', 'affiliate-wp' ); ?></a>
				</p>
			</div>
			<?php
			return;
		}

		$this->print_errors();
		$form_id_suffix = wp_rand( 1000, 9999 );
		?>
		<form id="affwp-reset-password-form-<?php echo esc_attr( $form_id_suffix ); ?>" class="affwp-form affwp-reset-password-form" action="" method="post">
			<fieldset>
				<legend><?php esc_html_e( 'Choose a new password', 'affiliate-wp' ); ?></legend>

				<p>
					<label for="affwp-reset-user-pass"><?php esc_html_e( 'New password', 'affiliate-wp' ); ?></label>
					<input id="affwp-reset-user-pass" class="password required" type="password" name="affwp_user_pass" autocomplete="new-password" />
				</p>

				<p>
					<label for="affwp-reset-user-pass-confirm"><?php esc_html_e( 'Confirm password', 'affiliate-wp' ); ?></label>
					<input id="affwp-reset-user-pass-confirm" class="password required" type="password" name="affwp_user_pass_confirm" autocomplete="new-password" />
				</p>

				<p>
					<input type="hidden" name="affwp_reset_key" value="<?php echo esc_attr( $key ); ?>" />
					<input type="hidden" name="affwp_reset_login" value="<?php echo esc_attr( $login ); ?>" />
					<input type="hidden" name="affwp_redirect" value="<?php echo esc_url( affwp_get_affiliate_area_page_url() ); ?>" />
					<input type="hidden" name="affwp_reset_password_nonce" value="<?php echo esc_attr( wp_create_nonce( 'affwp-reset-password-nonce' ) ); ?>" />
					<input type="hidden" name="affwp_action" value="reset_password" />
					<input type="submit" class="button" value="<?php esc_attr_e( 'Update password', 'affiliate-wp' ); ?>" />
				</p>
			</fieldset>
		</form>
		<?php
	}

	/**
	 * Lost-password URL for the affiliate login page (request-reset state).
	 *
	 * Never calls wp_lostpassword_url(). Woo/EDD filters on that function
	 * must not capture this path.
	 *
	 * @since 2.36.2
	 *
	 * @return string
	 */
	public function get_lost_password_url() {

		return add_query_arg( 'affwp_lost_password', '1', $this->get_login_base_url() );
	}

	/**
	 * Set-password URL for an email link (key + login on the affiliate login page).
	 *
	 * @since 2.36.2
	 *
	 * @param string $key   Password reset key.
	 * @param string $login User login.
	 * @return string
	 */
	public function get_reset_password_url( $key, $login ) {

		return add_query_arg(
			[
				'affwp_reset' => '1',
				'key'         => $key,
				'login'       => rawurlencode( $login ),
			],
			$this->get_login_base_url()
		);
	}

	/**
	 * Validate the reset key from the current request.
	 *
	 * @since 2.36.2
	 *
	 * @return WP_User|WP_Error
	 */
	public function get_reset_user() {

		$key   = $this->get_requested_reset_key();
		$login = $this->get_requested_reset_login();

		if ( '' === $key || '' === $login ) {
			return new WP_Error( 'invalid_key', __( 'This password reset link is invalid or has expired.', 'affiliate-wp' ) );
		}

		$user = check_password_reset_key( $key, $login );

		if ( is_wp_error( $user ) ) {
			return new WP_Error( 'invalid_key', __( 'This password reset link is invalid or has expired.', 'affiliate-wp' ) );
		}

		return $user;
	}

	/**
	 * Reset key from GET or POST.
	 *
	 * @since 2.36.2
	 *
	 * @return string
	 */
	public function get_requested_reset_key() {

		if ( isset( $_POST['affwp_reset_key'] ) ) {
			return sanitize_text_field( wp_unslash( $_POST['affwp_reset_key'] ) );
		}

		return $this->get_query_arg( 'key' );
	}

	/**
	 * Reset login from GET or POST.
	 *
	 * @since 2.36.2
	 *
	 * @return string
	 */
	public function get_requested_reset_login() {

		if ( isset( $_POST['affwp_reset_login'] ) ) {
			return sanitize_user( wp_unslash( $_POST['affwp_reset_login'] ) );
		}

		if ( isset( $_GET['login'] ) ) {
			return sanitize_user( wp_unslash( $_GET['login'] ) );
		}

		return '';
	}

	/**
	 * Log the user in
	 *
	 * Reused after a successful affiliate password reset so the same auth
	 * cookies are set and wp_login still fires. The reset handler redirects
	 * immediately to the affiliate area so a later login_redirect (EDD/Woo)
	 * cannot win.
	 *
	 * @since 1.0
	 * @since 2.36.2 Reused after password reset.
	 */
	private function log_user_in( $user_id = 0, $user_login = '', $remember = false ) {

		$user = get_userdata( $user_id );
		if ( ! $user ) {
			return;
		}

		wp_set_auth_cookie( $user_id, $remember );
		wp_set_current_user( $user_id, $user_login );
		/**
		 * The `wp_login` action is fired here to maintain compatibility and stability of
		 * any WordPress core features, plugins, or themes hooking onto it.
		 */
		do_action( 'wp_login', $user_login, $user );
	}

	/**
	 * Register a submission error
	 *
	 * @since 1.0
	 */
	public function add_error( $error_id, $message = '' ) {
		$this->errors[ $error_id ] = $message;
	}

	/**
	 * Print errors
	 *
	 * @since 1.0
	 */
	public function print_errors() {

		if ( empty( $this->errors ) ) {
			return;
		}

		echo '<div class="affwp-errors">';

		foreach ( $this->errors as $error_id => $error ) {

			echo '<p class="affwp-error">' . esc_html( $error ) . '</p>';

		}

		echo '</div>';
	}

	/**
	 * Get errors
	 *
	 * @since 2.36.2
	 *
	 * @return array
	 */
	public function get_errors() {

		if ( empty( $this->errors ) ) {
			return [];
		}

		return $this->errors;
	}

	/**
	 * Retrieves the login URL
	 *
	 * @since 1.1
	 * @since 2.25.0 The new Affiliate Login page is used instead of the Affiliate Area page to return the login URL.
	 */
	function get_login_url() {
		/**
		 * Filters the AffiliateWP login URL.
		 *
		 * @since 1.1
		 *
		 * @param string $url Login URL.
		 */
		return apply_filters( 'affwp_login_url', get_permalink( affiliatewp_get_affiliate_login_page_id() ) );
	}

	/**
	 * Login URL with Affiliate Area / home fallbacks.
	 *
	 * @since 2.36.2
	 *
	 * @return string
	 */
	private function get_login_base_url() {

		$url = $this->get_login_url();

		if ( empty( $url ) ) {
			$url = affwp_get_affiliate_area_page_url();
		}

		if ( empty( $url ) ) {
			$url = home_url( '/' );
		}

		return $url;
	}

	/**
	 * Redirect back to the affiliate login URL.
	 *
	 * @since 2.36.2
	 *
	 * @param array $args Query args to add.
	 */
	private function redirect_to_login( $args = [] ) {

		$url = add_query_arg( $args, $this->get_login_base_url() );

		wp_safe_redirect( wp_validate_redirect( $url, home_url() ) );
		exit;
	}

	/**
	 * Whether the request should show or process the set-password form.
	 *
	 * @since 2.36.2
	 *
	 * @return bool
	 */
	private function request_has_reset_password() {

		if ( '1' === $this->get_query_arg( 'affwp_reset' ) ) {
			return true;
		}

		return isset( $_POST['affwp_action'] ) && 'reset_password' === sanitize_key( wp_unslash( $_POST['affwp_action'] ) );
	}

	/**
	 * Whether the request should show or process the request-reset form.
	 *
	 * @since 2.36.2
	 *
	 * @return bool
	 */
	private function request_has_lost_password() {

		if ( '1' === $this->get_query_arg( 'affwp_lost_password' ) ) {
			return true;
		}

		return isset( $_POST['affwp_action'] ) && 'lost_password' === sanitize_key( wp_unslash( $_POST['affwp_action'] ) );
	}

	/**
	 * Sanitized GET value.
	 *
	 * @since 2.36.2
	 *
	 * @param string $key Query arg name.
	 * @return string
	 */
	private function get_query_arg( $key ) {

		if ( ! isset( $_GET[ $key ] ) ) {
			return '';
		}

		return sanitize_text_field( wp_unslash( $_GET[ $key ] ) );
	}
}
