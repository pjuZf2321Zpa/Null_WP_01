<?php
/**
 * Objects: Payout Schedule
 *
 * @package     AffiliateWP
 * @subpackage  Database
 * @copyright   Copyright (c) 2026, Awesome Motive, Inc
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.35.0
 */

namespace AffWP\Affiliate;

#[\AllowDynamicProperties]

/**
 * Implements a payout schedule object.
 *
 * @since 2.35.0
 *
 * @see AffWP\Base_Object
 *
 * @property-read int $ID Alias for `$schedule_id`.
 */
final class PayoutSchedule extends \AffWP\Base_Object {

	/**
	 * Schedule ID.
	 *
	 * @since 2.35.0
	 * @var   int
	 */
	public $schedule_id = 0;

	/**
	 * Schedule name.
	 *
	 * @since 2.35.0
	 * @var   string
	 */
	public $name = '';

	/**
	 * Frequency: 'weekly' or 'monthly'.
	 *
	 * @since 2.35.0
	 * @var   string
	 */
	public $frequency = 'monthly';

	/**
	 * Day of week (1=Mon-7=Sun) or month (1-28, 99=last day).
	 *
	 * @since 2.35.0
	 * @var   int
	 */
	public $frequency_day = 1;

	/**
	 * JSON-encoded array of affiliate group IDs to include. Null/empty means no group filter.
	 * Combined (union) with $affiliate_ids; when both are empty the schedule targets all affiliates.
	 *
	 * @since 2.35.0
	 * @var   string|null
	 */
	public $affiliate_group_ids = null;

	/**
	 * JSON-encoded array of affiliate IDs to include. Null/empty means no affiliate filter.
	 * Combined (union) with $affiliate_group_ids; when both are empty the schedule targets all affiliates.
	 *
	 * @since 2.35.0
	 * @var   string|null
	 */
	public $affiliate_ids = null;

	/**
	 * Minimum payout amount.
	 *
	 * @since 2.35.0
	 * @var   float
	 */
	public $minimum_amount = 0;

	/**
	 * Whether to bypass the holding period.
	 *
	 * @since 2.35.0
	 * @var   int
	 */
	public $bypass_holding_period = 0;

	/**
	 * Schedule status: 'active' or 'paused'.
	 *
	 * @since 2.35.0
	 * @var   string
	 */
	public $status = 'active';

	/**
	 * Last run datetime.
	 *
	 * @since 2.35.0
	 * @var   string
	 */
	public $last_run = '';

	/**
	 * Next run datetime.
	 *
	 * @since 2.35.0
	 * @var   string
	 */
	public $next_run = '';

	/**
	 * User ID who created the schedule.
	 *
	 * @since 2.35.0
	 * @var   int
	 */
	public $created_by = 0;

	/**
	 * Date created.
	 *
	 * @since 2.35.0
	 * @var   string
	 */
	public $date = '';

	/**
	 * Token to use for generating cache keys.
	 *
	 * @since  2.35.0
	 * @var    string
	 * @static
	 */
	public static $cache_token = 'affwp_payout_schedules';

	/**
	 * Database group.
	 *
	 * @since  2.35.0
	 * @var    string
	 */
	public static $db_group = 'affiliates:payout_schedules';

	/**
	 * Object type.
	 *
	 * @since  2.35.0
	 * @var    string
	 * @static
	 */
	public static $object_type = 'payout_schedules';

	/**
	 * Sanitizes a payout schedule object field.
	 *
	 * @since 2.35.0
	 * @static
	 *
	 * @param string $field Object field.
	 * @param mixed  $value Field value.
	 * @return mixed Sanitized field value.
	 */
	public static function sanitize_field( $field, $value ) {
		if ( in_array( $field, array( 'schedule_id', 'ID', 'frequency_day', 'created_by', 'bypass_holding_period' ), true ) ) {
			$value = (int) $value;
		}

		if ( 'minimum_amount' === $field ) {
			$value = floatval( $value );
		}

		return $value;
	}
}
