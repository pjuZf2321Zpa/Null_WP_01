<?php
/**
 * Objects: Payout Schedule Log
 *
 * @package     AffiliateWP
 * @subpackage  Database
 * @copyright   Copyright (c) 2026, Awesome Motive, Inc
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.35.0
 */

namespace AffWP\Affiliate;

#[\AllowDynamicProperties]

/**
 * Implements a payout schedule log object.
 *
 * @since 2.35.0
 *
 * @see AffWP\Base_Object
 *
 * @property-read int $ID Alias for `$log_id`.
 */
final class PayoutScheduleLog extends \AffWP\Base_Object {

	/**
	 * Log ID.
	 *
	 * @since 2.35.0
	 * @var   int
	 */
	public $log_id = 0;

	/**
	 * Schedule ID.
	 *
	 * @since 2.35.0
	 * @var   int
	 */
	public $schedule_id = 0;

	/**
	 * Run timestamp.
	 *
	 * @since 2.35.0
	 * @var   string
	 */
	public $run_at = '';

	/**
	 * Dispatch status: 'processing', 'success', 'partial', 'failed', 'skipped'.
	 *
	 * Records how the run dispatched. For a run that produced a batch, the
	 * payment outcome is read live from that batch ({@see $batch_id}), not from
	 * this frozen value — so async settlement is always reflected.
	 *
	 * @since 2.35.0
	 * @var   string
	 */
	public $status = 'processing';

	/**
	 * ID of the payout batch this run produced (0 if none — e.g. nothing eligible).
	 *
	 * The batch is the live record of what was paid; paid/failed/amount are read
	 * from it rather than stored here, so counts never go stale.
	 *
	 * @since 2.35.0
	 * @var   int
	 */
	public $batch_id = 0;

	/**
	 * Error details (JSON).
	 *
	 * Dispatch-time errors that never became a payout row (e.g. a record that
	 * couldn't be created).
	 *
	 * @since 2.35.0
	 * @var   string
	 */
	public $errors = '';

	/**
	 * Token to use for generating cache keys.
	 *
	 * @since  2.35.0
	 * @var    string
	 * @static
	 */
	public static $cache_token = 'affwp_payout_schedule_logs';

	/**
	 * Database group.
	 *
	 * @since  2.35.0
	 * @var    string
	 */
	public static $db_group = 'affiliates:payout_schedule_logs';

	/**
	 * Object type.
	 *
	 * @since  2.35.0
	 * @var    string
	 * @static
	 */
	public static $object_type = 'payout_schedule_logs';

	/**
	 * Sanitizes a payout schedule log object field.
	 *
	 * @since 2.35.0
	 * @static
	 *
	 * @param string $field Object field.
	 * @param mixed  $value Field value.
	 * @return mixed Sanitized field value.
	 */
	public static function sanitize_field( $field, $value ) {
		if ( in_array( $field, array( 'log_id', 'ID', 'schedule_id', 'batch_id' ), true ) ) {
			$value = (int) $value;
		}

		return $value;
	}
}
