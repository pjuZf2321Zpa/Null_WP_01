<?php
/**
 * Payout Meta Database Abstraction Layer
 *
 * @package     AffiliateWP
 * @subpackage  Database
 * @copyright   Copyright (c) 2026, Awesome Motive, Inc.
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.36.0
 */

#[\AllowDynamicProperties]

/**
 * Core class used to implement payout meta.
 *
 * Payouts previously had no meta store, so per-payout facts were written to every
 * referral in the payout instead — duplicating one value N times and losing it if
 * the referrals were removed.
 *
 * @since 2.36.0
 *
 * @see Affiliate_WP_Meta_DB
 */
class Affiliate_WP_Payout_Meta_DB extends Affiliate_WP_Meta_DB {

	/**
	 * Represents the meta table database version.
	 *
	 * @since 2.36.0
	 * @var   string
	 */
	public $version = '1.0';

	/**
	 * Database group value.
	 *
	 * @since 2.36.0
	 * @var string
	 */
	public $db_group = 'payout_meta';

	/**
	 * Retrieves the table columns and data types.
	 *
	 * @since 2.36.0
	 *
	 * @return array List of payout meta table columns and their respective types.
	 */
	public function get_columns() {
		return array(
			'meta_id'    => '%d',
			'payout_id'  => '%d',
			'meta_key'   => '%s',
			'meta_value' => '%s',
		);
	}

	/**
	 * Retrieves the meta type.
	 *
	 * @since 2.36.0
	 *
	 * @return string Meta type.
	 */
	public function get_meta_type() {
		return 'payout';
	}

	/**
	 * Creates the table.
	 *
	 * @since 2.36.0
	 *
	 * @see dbDelta()
	 */
	public function create_table() {
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$sql = "CREATE TABLE {$this->table_name} (
			meta_id bigint(20) NOT NULL AUTO_INCREMENT,
			payout_id bigint(20) NOT NULL DEFAULT '0',
			meta_key varchar(255) DEFAULT NULL,
			meta_value longtext,
			PRIMARY KEY  (meta_id),
			KEY payout_id (payout_id),
			KEY meta_key (meta_key(191))
			) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;";

		dbDelta( $sql );

		update_option( $this->table_name . '_db_version', $this->version );
	}
}
