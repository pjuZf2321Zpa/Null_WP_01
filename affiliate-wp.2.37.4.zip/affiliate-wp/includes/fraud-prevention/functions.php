<?php
/**
 * Fraud Detection Helper Functions
 *
 * @package     AffiliateWP
 * @subpackage  Fraud Detection
 * @copyright   Copyright (c) 2025, Awesome Motive Inc
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.28.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Get the IP address of the current visitor.
 *
 * Respects the 'disable_ip_logging' setting for GDPR compliance.
 *
 * @since 2.28.0
 * @since 2.37.2 Applies the `affwp_get_ip` filter, so fraud checks see the address visits record.
 *
 * @return string IP address or empty string if IP logging is disabled.
 */
function affwp_fraud_get_ip() {
	// Respect GDPR setting.
	if ( affiliate_wp()->settings->get( 'disable_ip_logging' ) ) {
		return '';
	}

	/** This filter is documented in includes/class-tracking.php */
	return apply_filters( 'affwp_get_ip', affwp_get_trusted_client_ip() );
}

/**
 * Derives the client IP address, believing a forwarded address only from a proxy the site trusts.
 *
 * REMOTE_ADDR is the only address the web server can vouch for. When it is a configured trusted
 * proxy, the right-most X-Forwarded-For entry that is not itself a trusted proxy is used instead, so
 * entries a client prepends are never reached. While no proxy is configured, a request from a
 * Cloudflare edge uses the CF-Connecting-IP address Cloudflare sets.
 *
 * @since 2.37.2
 *
 * @return string The client IP address, or an empty string if none could be validated.
 */
function affwp_get_trusted_client_ip() {

	$remote = affwp_get_remote_ip();

	if ( '' === $remote ) {
		return '';
	}

	$trusted = affwp_get_trusted_proxies();

	if ( empty( $trusted ) ) {
		$cloudflare = affwp_get_cloudflare_connecting_ip( $remote );

		return '' !== $cloudflare ? $cloudflare : $remote;
	}

	return affwp_resolve_forwarded_ip( $remote, $trusted, affwp_get_forwarded_for_header() );
}

/**
 * Returns the validated, normalized REMOTE_ADDR of the current request.
 *
 * @since 2.37.2
 *
 * @return string The connecting IP address, or an empty string if it is missing or invalid.
 */
function affwp_get_remote_ip() {
	return isset( $_SERVER['REMOTE_ADDR'] ) ? affwp_normalize_ip( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
}

/**
 * Returns the raw X-Forwarded-For header of the current request.
 *
 * @since 2.37.2
 *
 * @return string The header value, or an empty string when it is not set.
 */
function affwp_get_forwarded_for_header() {
	return isset( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ? (string) wp_unslash( $_SERVER['HTTP_X_FORWARDED_FOR'] ) : '';
}

/**
 * Returns the visitor address Cloudflare sets, when the request comes from a Cloudflare edge.
 *
 * Only CF-Connecting-IP is read: Cloudflare overwrites it on every request, while X-Forwarded-For
 * keeps whatever the client sent.
 *
 * @since 2.37.2
 *
 * @param string $remote The normalized REMOTE_ADDR.
 * @return string The visitor IP address, or an empty string when the request is not from Cloudflare.
 */
function affwp_get_cloudflare_connecting_ip( $remote ) {

	if ( empty( $_SERVER['HTTP_CF_CONNECTING_IP'] ) || ! affwp_ip_in_ranges( $remote, affwp_trusted_proxy_preset( 'cloudflare' ) ) ) {
		return '';
	}

	return affwp_normalize_ip( wp_unslash( $_SERVER['HTTP_CF_CONNECTING_IP'] ) );
}

/**
 * Resolves the client address behind a chain of trusted proxies.
 *
 * Walks X-Forwarded-For from the right and returns the first entry that is not a trusted proxy. An
 * entry that cannot be parsed stops the walk, because everything to its left may come from the client.
 *
 * @since 2.37.2
 *
 * @param string   $remote    The normalized REMOTE_ADDR.
 * @param string[] $trusted   Trusted proxy IP addresses or CIDR ranges.
 * @param string   $forwarded The raw X-Forwarded-For header.
 * @return string The client IP address, or `$remote` when it cannot be resolved.
 */
function affwp_resolve_forwarded_ip( $remote, $trusted, $forwarded ) {

	if ( ! affwp_ip_in_ranges( $remote, $trusted ) ) {
		return $remote;
	}

	foreach ( array_reverse( explode( ',', (string) $forwarded ) ) as $entry ) {

		if ( '' === trim( $entry ) ) {
			continue;
		}

		$hop = affwp_normalize_ip( $entry );

		if ( '' === $hop ) {
			return $remote;
		}

		if ( ! affwp_ip_in_ranges( $hop, $trusted ) ) {
			return $hop;
		}
	}

	return $remote;
}

/**
 * Normalizes an IP address for comparison and storage.
 *
 * Strips a port (`203.0.113.7:443`, `[2001:db8::1]:443`), validates the address, maps an
 * IPv4-mapped IPv6 address (`::ffff:203.0.113.7`) to IPv4, and returns IPv6 in its canonical form.
 *
 * @since 2.37.2
 *
 * @param string $value A raw IP address.
 * @return string The normalized IP address, or an empty string if it is not a valid IP address.
 */
function affwp_normalize_ip( $value ) {

	$value = trim( (string) $value );

	if ( preg_match( '/^\[([^\]]+)\](?::\d{1,5})?$/', $value, $matches ) ) {
		$value = $matches[1];
	} elseif ( preg_match( '/^(\d{1,3}(?:\.\d{1,3}){3}):\d{1,5}$/', $value, $matches ) ) {
		$value = $matches[1];
	}

	if ( false === filter_var( $value, FILTER_VALIDATE_IP ) ) {
		return '';
	}

	$binary = inet_pton( $value );

	if ( 16 === strlen( $binary ) && 0 === strncmp( $binary, str_repeat( "\0", 10 ) . "\xff\xff", 12 ) ) {
		$binary = substr( $binary, 12 );
	}

	return (string) inet_ntop( $binary );
}

/**
 * Whether an IP address is publicly routable (not private, carrier-grade NAT, loopback or reserved).
 *
 * @since 2.37.2
 *
 * @param string $ip A normalized IP address.
 * @return bool True for a public IP address.
 */
function affwp_is_public_ip( $ip ) {

	// PHP's flags count carrier-grade NAT (100.64.0.0/10) as public, though it never reaches a site from the internet.
	return false !== filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE )
		&& ! affwp_ip_in_range( $ip, '100.64.0.0/10' );
}

/**
 * Splits a Trusted Proxies value into its entries.
 *
 * @since 2.37.2
 *
 * @param string|string[] $value Entries separated by commas or whitespace, or a list of entries.
 * @return string[] The non-empty entries.
 */
function affwp_split_trusted_proxies( $value ) {

	// A value saved or filtered as a list, rather than typed into the field.
	if ( is_array( $value ) ) {
		$value = implode( ',', array_filter( $value, 'is_scalar' ) );
	}

	return array_values( array_filter( array_map( 'trim', preg_split( '/[\s,]+/', (string) $value ) ), 'strlen' ) );
}

/**
 * Whether a Trusted Proxies entry is a preset keyword, an IP address or a CIDR range.
 *
 * @since 2.37.2
 *
 * @param string $entry A single entry.
 * @return bool True if the entry is valid.
 */
function affwp_is_valid_trusted_proxy_entry( $entry ) {
	return ! empty( affwp_trusted_proxy_preset( $entry ) ) || null !== affwp_parse_ip_range( $entry );
}

/**
 * Expands Trusted Proxies entries into IP addresses and CIDR ranges, dropping invalid entries.
 *
 * @since 2.37.2
 *
 * @param string|string[] $value Entries separated by commas or whitespace, or a list of entries.
 * @return string[] IP addresses and CIDR ranges.
 */
function affwp_expand_trusted_proxies( $value ) {

	$proxies = array();

	foreach ( affwp_split_trusted_proxies( $value ) as $entry ) {
		$preset = affwp_trusted_proxy_preset( $entry );

		if ( ! empty( $preset ) ) {
			$proxies = array_merge( $proxies, $preset );
		} elseif ( null !== affwp_parse_ip_range( $entry ) ) {
			$proxies[] = $entry;
		}
	}

	return array_values( array_unique( $proxies ) );
}

/**
 * Returns the trusted proxy IPs/CIDR ranges whose forwarded headers may be believed.
 *
 * Reads the `trusted_proxies` setting and passes it through the `affwp_trusted_proxies` filter,
 * expanding the preset keywords `cloudflare`, `sucuri` and `private` (alias `lb`) and dropping
 * empty or invalid entries from both.
 *
 * @since 2.37.2
 *
 * @return string[] Trusted proxy IP addresses or CIDR ranges.
 */
function affwp_get_trusted_proxies() {

	$proxies = affwp_expand_trusted_proxies( affiliate_wp()->settings->get( 'trusted_proxies', '' ) );

	/**
	 * Filters the proxy addresses whose X-Forwarded-For header is trusted.
	 *
	 * Accepts individual IPs, CIDR ranges (IPv4 and IPv6) and preset keywords. Any entry turns
	 * off the automatic Cloudflare handling, so include `cloudflare` when it is in front too.
	 *
	 * @since 2.37.2
	 *
	 * @param string[] $proxies Trusted proxy IPs/CIDR ranges.
	 */
	return affwp_expand_trusted_proxies( (array) apply_filters( 'affwp_trusted_proxies', $proxies ) );
}

/**
 * Sanitizes the Trusted Proxies setting, keeping only valid entries.
 *
 * @since 2.37.2
 *
 * @param string $value The submitted value.
 * @param string $key   The setting key.
 * @return string Valid entries, one per line.
 */
function affwp_sanitize_trusted_proxies_setting( $value, $key = '' ) {

	$valid   = array();
	$invalid = array();

	foreach ( affwp_split_trusted_proxies( $value ) as $entry ) {
		if ( ! affwp_is_valid_trusted_proxy_entry( $entry ) ) {
			$invalid[] = $entry;
		} elseif ( ! empty( affwp_trusted_proxy_preset( $entry ) ) ) {
			$valid[] = strtolower( $entry );
		} else {
			$valid[] = $entry;
		}
	}

	if ( ! empty( $invalid ) && function_exists( 'add_settings_error' ) ) {
		add_settings_error(
			'affwp-notices',
			'trusted_proxies',
			sprintf(
				/* translators: %s: The ignored Trusted Proxies entries. */
				__( 'Trusted Proxies ignored %s. Each entry must be an IP address, a CIDR range such as 10.0.0.0/8, or one of the keywords cloudflare, sucuri and private.', 'affiliate-wp' ),
				'<code>' . esc_html( implode( ', ', $invalid ) ) . '</code>'
			),
			'error'
		);
	}

	return implode( "\n", array_unique( $valid ) );
}

/**
 * Returns the IP addresses and CIDR ranges for a named trusted-proxy preset.
 *
 * @since 2.37.2
 *
 * @param string $name Preset name: `cloudflare`, `sucuri`, or `private` (alias `lb`).
 * @return string[] CIDR ranges for the preset, or an empty array if the name is not a preset.
 */
function affwp_trusted_proxy_preset( $name ) {

	$presets = array(
		// Cloudflare's published ranges, https://www.cloudflare.com/ips/.
		'cloudflare' => array(
			'173.245.48.0/20', '103.21.244.0/22', '103.22.200.0/22', '103.31.4.0/22',
			'141.101.64.0/18', '108.162.192.0/18', '190.93.240.0/20', '188.114.96.0/20',
			'197.234.240.0/22', '198.41.128.0/17', '162.158.0.0/15', '104.16.0.0/13',
			'104.24.0.0/14', '172.64.0.0/13', '131.0.72.0/22',
			'2400:cb00::/32', '2606:4700::/32', '2803:f800::/32', '2405:b500::/32',
			'2405:8100::/32', '2a06:98c0::/29', '2c0f:f248::/32',
		),
		// Sucuri firewall ranges, https://docs.sucuri.net/website-firewall/troubleshooting/same-ip-for-all-users/.
		'sucuri'     => array(
			'192.88.134.0/23', '185.93.228.0/22', '66.248.200.0/22', '208.109.0.0/22', '2a02:fe80::/29',
		),
		// Addresses that never reach a site from the internet: private, carrier-grade NAT, loopback and link-local.
		'private'    => array(
			'10.0.0.0/8', '172.16.0.0/12', '192.168.0.0/16', '100.64.0.0/10', '127.0.0.0/8', '169.254.0.0/16',
			'::1/128', 'fc00::/7', 'fe80::/10',
		),
	);

	/**
	 * Filters the trusted proxy presets, the ranges each Trusted Proxies keyword stands for.
	 *
	 * Lets a site update Cloudflare's ranges, or add its own keyword, without waiting for a release.
	 *
	 * @since 2.37.2
	 *
	 * @param array $presets Preset name => list of IP addresses or CIDR ranges.
	 */
	$presets = (array) apply_filters( 'affwp_trusted_proxy_presets', $presets );

	$name = strtolower( trim( (string) $name ) );

	if ( 'lb' === $name ) {
		$name = 'private';
	}

	return isset( $presets[ $name ] ) ? array_values( (array) $presets[ $name ] ) : array();
}

/**
 * Detects which trusted-proxy preset the current request arrived through, if any.
 *
 * Used only to suggest a Trusted Proxies value. `private` requires a public address somewhere to the
 * left of the private hops, so local development, where every hop is private, is not reported.
 *
 * @since 2.37.2
 *
 * @return string `cloudflare`, `sucuri`, `cloudflare, sucuri`, `private`, `cloudflare, private`, or an
 *                empty string when no proxy is detected.
 */
function affwp_detect_trusted_proxy_preset() {

	$remote = affwp_get_remote_ip();

	if ( '' === $remote ) {
		return '';
	}

	$cloudflare_header = ! empty( $_SERVER['HTTP_CF_CONNECTING_IP'] );

	if ( $cloudflare_header && affwp_ip_in_ranges( $remote, affwp_trusted_proxy_preset( 'cloudflare' ) ) ) {
		return 'cloudflare';
	}

	if ( ! empty( $_SERVER['HTTP_X_SUCURI_CLIENTIP'] ) && affwp_ip_in_ranges( $remote, affwp_trusted_proxy_preset( 'sucuri' ) ) ) {
		$hops = explode( ',', affwp_get_forwarded_for_header() );

		// Cloudflare in front of Sucuri: Sucuri appends the Cloudflare edge it received the request from.
		return $cloudflare_header && affwp_ip_in_ranges( affwp_normalize_ip( end( $hops ) ), affwp_trusted_proxy_preset( 'cloudflare' ) )
			? 'cloudflare, sucuri'
			: 'sucuri';
	}

	if ( ! affwp_ip_in_ranges( $remote, affwp_trusted_proxy_preset( 'private' ) ) ) {
		return '';
	}

	foreach ( array_reverse( explode( ',', affwp_get_forwarded_for_header() ) ) as $entry ) {

		if ( '' === trim( $entry ) ) {
			continue;
		}

		$hop = affwp_normalize_ip( $entry );

		if ( '' === $hop ) {
			return '';
		}

		if ( affwp_ip_in_ranges( $hop, affwp_trusted_proxy_preset( 'private' ) ) ) {
			continue;
		}

		if ( ! affwp_is_public_ip( $hop ) ) {
			return '';
		}

		// Cloudflare in front of a private load balancer: both have to be trusted to reach the visitor.
		if ( $cloudflare_header && affwp_ip_in_ranges( $hop, affwp_trusted_proxy_preset( 'cloudflare' ) ) ) {
			return 'cloudflare, private';
		}

		return 'private';
	}

	return '';
}

/**
 * Detects a public proxy or CDN in front of the current request that no preset covers.
 *
 * Its addresses can't be trusted from one request: a CDN answers from many edge addresses, and
 * the admin might be behind a proxy of their own. Used only to ask the admin to add its ranges.
 *
 * @since 2.37.2
 *
 * @return string The CDN's name when one of its headers identifies it, `proxy` when none does, or
 *                an empty string when the request did not come through an unrecognized public proxy.
 */
function affwp_detect_public_proxy() {

	$remote = affwp_get_remote_ip();

	if ( '' === $remote || ! affwp_is_public_ip( $remote ) || affwp_ip_in_ranges( $remote, affwp_get_trusted_proxies() ) ) {
		return '';
	}

	$cloudflare = empty( $_SERVER['HTTP_CF_CONNECTING_IP'] ) ? '' : affwp_normalize_ip( wp_unslash( $_SERVER['HTTP_CF_CONNECTING_IP'] ) );

	// Cloudflare itself is handled; a host that already put Cloudflare's visitor in REMOTE_ADDR needs nothing.
	if ( '' !== $cloudflare && ( $cloudflare === $remote || affwp_ip_in_ranges( $remote, affwp_trusted_proxy_preset( 'cloudflare' ) ) ) ) {
		return '';
	}

	$hops = array_filter( array_map( 'affwp_normalize_ip', explode( ',', affwp_get_forwarded_for_header() ) ) );

	// A host that rewrites REMOTE_ADDR takes it from X-Forwarded-For, and with no public hop no proxy reported a visitor.
	if ( in_array( $remote, $hops, true ) || ! array_filter( $hops, 'affwp_is_public_ip' ) ) {
		return '';
	}

	$names = array(
		'HTTP_X_SUCURI_CLIENTIP' => 'Sucuri',
		'HTTP_CDN_SERVERID'      => 'Bunny',
		'HTTP_FASTLY_CLIENT_IP'  => 'Fastly',
		'HTTP_X_AMZ_CF_ID'       => 'CloudFront',
		'HTTP_X_AZURE_FDID'      => 'Azure Front Door',
	);

	foreach ( $names as $header => $name ) {
		if ( ! empty( $_SERVER[ $header ] ) ) {
			return $name;
		}
	}

	return 'proxy';
}

/**
 * Whether a resolved client IP address is a visitor rather than a proxy in front of the site.
 *
 * It is not when it is the connecting address itself, a private or reserved address, a Cloudflare
 * edge on a request that came through Cloudflare, or when another public address sits to its left in
 * X-Forwarded-For (a CDN in front of a load balancer). The address Cloudflare reports in
 * CF-Connecting-IP always counts as a visitor.
 *
 * @since 2.37.2
 *
 * @param string $client The resolved client IP address.
 * @param string $remote The normalized REMOTE_ADDR.
 * @return bool True if the address belongs to a visitor.
 */
function affwp_is_visitor_ip( $client, $remote ) {

	if ( $client === $remote ) {
		return false;
	}

	$cloudflare = empty( $_SERVER['HTTP_CF_CONNECTING_IP'] ) ? '' : affwp_normalize_ip( wp_unslash( $_SERVER['HTTP_CF_CONNECTING_IP'] ) );

	// Including the reserved 240.x address Cloudflare's Pseudo IPv4 gives an IPv6 visitor.
	if ( '' !== $cloudflare && $cloudflare === $client ) {
		return true;
	}

	if ( ! affwp_is_public_ip( $client ) ) {
		return false;
	}

	if ( '' !== $cloudflare && affwp_ip_in_ranges( $client, affwp_trusted_proxy_preset( 'cloudflare' ) ) ) {
		return false;
	}

	$public_before = false;

	foreach ( explode( ',', affwp_get_forwarded_for_header() ) as $entry ) {
		$hop = affwp_normalize_ip( $entry );

		if ( $hop === $client ) {
			return ! $public_before;
		}

		if ( '' !== $hop && affwp_is_public_ip( $hop ) ) {
			$public_before = true;
		}
	}

	return true;
}

/**
 * Works out what the Trusted Proxies notice should offer for the current request.
 *
 * @since 2.37.2
 *
 * @return array {
 *     @type string $state  `suggest` (one click reaches the visitor), `partial` (one click trusts the
 *                          detected proxy, another proxy remains), `public` (a public proxy or CDN no
 *                          preset covers, whose ranges the admin adds), `review` (configured proxies
 *                          don't cover this request), or an empty string when nothing needs to change.
 *     @type string $preset The detected preset, or an empty string.
 *     @type string $proxy  The public proxy's name, `proxy` when unknown, or an empty string.
 * }
 */
function affwp_get_trusted_proxy_advice() {

	$none   = array( 'state' => '', 'preset' => '', 'proxy' => '' );
	$remote = affwp_get_remote_ip();

	/** This filter is documented in includes/class-tracking.php */
	$client = (string) apply_filters( 'affwp_get_ip', affwp_get_trusted_client_ip() );

	if ( '' === $remote || affwp_is_visitor_ip( $client, $remote ) ) {
		return $none;
	}

	$preset = affwp_detect_trusted_proxy_preset();
	$proxy  = '' === $preset ? affwp_detect_public_proxy() : '';

	if ( ! empty( affwp_get_trusted_proxies() ) ) {
		// A listed proxy handed over another proxy's address, or the request came through an unlisted one.
		$missing = '' !== $preset || '' !== $proxy || $client !== $remote;

		return $missing ? array( 'state' => 'review', 'preset' => $preset, 'proxy' => $proxy ) : $none;
	}

	if ( '' !== $proxy ) {
		return array( 'state' => 'public', 'preset' => '', 'proxy' => $proxy );
	}

	if ( '' === $preset ) {
		return $none;
	}

	$client = affwp_resolve_forwarded_ip( $remote, affwp_expand_trusted_proxies( $preset ), affwp_get_forwarded_for_header() );

	return array(
		'state'  => affwp_is_visitor_ip( $client, $remote ) ? 'suggest' : 'partial',
		'preset' => $preset,
		'proxy'  => '',
	);
}

/**
 * Whether an IP address falls within any of the given IPs or CIDR ranges.
 *
 * @since 2.37.2
 *
 * @param string   $ip     The IP address to test.
 * @param string[] $ranges IPs or CIDR ranges.
 * @return bool True if the IP matches any range.
 */
function affwp_ip_in_ranges( $ip, $ranges ) {

	foreach ( (array) $ranges as $range ) {
		if ( affwp_ip_in_range( $ip, $range ) ) {
			return true;
		}
	}

	return false;
}

/**
 * Parses an IP address or CIDR range into its binary network address and prefix length.
 *
 * @since 2.37.2
 *
 * @param string $range An IP address or CIDR range.
 * @return array|null Array of the binary address and the prefix length, or null if the range is invalid.
 */
function affwp_parse_ip_range( $range ) {

	$parts = explode( '/', trim( (string) $range ), 2 );

	if ( 1 === count( $parts ) ) {
		$ip = affwp_normalize_ip( $parts[0] );

		if ( '' === $ip ) {
			return null;
		}

		$binary = inet_pton( $ip );

		return array( $binary, strlen( $binary ) * 8 );
	}

	if ( ! preg_match( '/^\d{1,3}$/', $parts[1] ) || false === filter_var( $parts[0], FILTER_VALIDATE_IP ) ) {
		return null;
	}

	$binary = inet_pton( $parts[0] );
	$bits   = (int) $parts[1];

	if ( $bits > strlen( $binary ) * 8 ) {
		return null;
	}

	return array( $binary, $bits );
}

/**
 * Whether an IP address falls within a single IP or CIDR range (IPv4 and IPv6).
 *
 * @since 2.37.2
 *
 * @param string $ip    The IP address to test.
 * @param string $range An IP address or CIDR range.
 * @return bool True if the IP is within the range.
 */
function affwp_ip_in_range( $ip, $range ) {

	$ip    = affwp_normalize_ip( $ip );
	$range = affwp_parse_ip_range( $range );

	if ( '' === $ip || null === $range ) {
		return false;
	}

	list( $subnet, $bits ) = $range;

	$ip = inet_pton( $ip );

	if ( strlen( $ip ) !== strlen( $subnet ) ) {
		return false;
	}

	$whole_bytes = intdiv( $bits, 8 );
	$rem_bits    = $bits % 8;

	if ( $whole_bytes > 0 && 0 !== substr_compare( $ip, $subnet, 0, $whole_bytes ) ) {
		return false;
	}

	if ( $rem_bits > 0 ) {
		$mask = ( 0xff << ( 8 - $rem_bits ) ) & 0xff;

		if ( ( ord( $ip[ $whole_bytes ] ) & $mask ) !== ( ord( $subnet[ $whole_bytes ] ) & $mask ) ) {
			return false;
		}
	}

	return true;
}

/**
 * Calculate time delta between two timestamps.
 *
 * @since 2.28.0
 *
 * @param int $timestamp1 First timestamp.
 * @param int $timestamp2 Second timestamp.
 * @return array {
 *     Time delta information.
 *
 *     @type int    $seconds Time difference in seconds.
 *     @type string $human   Human-readable time difference.
 * }
 */
function affwp_fraud_calculate_time_delta( $timestamp1, $timestamp2 ) {
	$seconds = abs( $timestamp2 - $timestamp1 );

	return array(
		'seconds' => $seconds,
		'human'   => human_time_diff( $timestamp1, $timestamp2 ),
	);
}

/**
 * Get human-readable label for a fraud flag type.
 *
 * @since 2.28.0
 *
 * @param string $flag_type Flag type (e.g., 'self_referral', 'ppc_traffic').
 * @return string Human-readable label.
 */
function affwp_fraud_get_flag_label( $flag_type ) {
	$labels = array(
		'self_referral'   => __( 'Self-Referral (Email Match)', 'affiliate-wp' ),
		'self_referral_ip' => __( 'Self-Referral (IP Address Match)', 'affiliate-wp' ),
		'ppc_traffic'     => __( 'PPC Traffic Detected', 'affiliate-wp' ),
		'referring_site'  => __( 'Referring Site Mismatch', 'affiliate-wp' ),
		'conversion_rate' => __( 'Conversion Rate Out of Range', 'affiliate-wp' ),
		'ip_velocity'     => __( 'IP Velocity Exceeded', 'affiliate-wp' ),
	);

	return isset( $labels[ $flag_type ] ) ? $labels[ $flag_type ] : $flag_type;
}

/**
 * Get detailed description for a fraud flag type.
 *
 * @since 2.28.0
 *
 * @param string $flag_type Flag type.
 * @param array  $meta      Optional. Additional metadata about the flag.
 * @return string Detailed description.
 */
function affwp_fraud_get_flag_description( $flag_type, $meta = array() ) {
	switch ( $flag_type ) {
		case 'self_referral':
			return __( 'This referral was flagged because the customer email matches the affiliate email.', 'affiliate-wp' );

		case 'self_referral_ip':
			if ( ! empty( $meta['registration_ip'] ) && ! empty( $meta['purchase_ip'] ) ) {
				return sprintf(
					/* translators: 1: Registration IP, 2: Purchase IP, 3: Time delta */
					__( 'This referral was flagged because the purchase IP (%1$s) matches the affiliate registration IP (%2$s). Time since registration: %3$s', 'affiliate-wp' ),
					$meta['purchase_ip'],
					$meta['registration_ip'],
					$meta['time_delta_human'] ?? __( 'unknown', 'affiliate-wp' )
				);
			}
			return __( 'This referral was flagged because the purchase IP matches the affiliate registration IP.', 'affiliate-wp' );

		case 'ppc_traffic':
			if ( ! empty( $meta['platform'] ) ) {
				return sprintf(
					/* translators: %s: PPC platform name */
					__( 'This referral was flagged because it originated from paid advertising traffic (%s).', 'affiliate-wp' ),
					$meta['platform']
				);
			}
			return __( 'This referral was flagged because it originated from paid advertising traffic.', 'affiliate-wp' );

		case 'referring_site':
			return __( 'This referral was flagged because the referring site does not match the URL listed in the affiliate\'s application.', 'affiliate-wp' );

		case 'conversion_rate':
			return __( 'This referral was flagged because the affiliate conversion rate was outside of the defined limits.', 'affiliate-wp' );

		case 'ip_velocity':
			if ( ! empty( $meta['count'] ) && ! empty( $meta['threshold'] ) ) {
				return sprintf(
					/* translators: 1: Number of registrations, 2: Threshold count */
					__( 'This affiliate was flagged because %1$d registrations from the same IP were detected (threshold: %2$d).', 'affiliate-wp' ),
					$meta['count'],
					$meta['threshold']
				);
			}
			return __( 'This affiliate was flagged due to multiple registrations from the same IP address.', 'affiliate-wp' );

		default:
			return $flag_type;
	}
}
