<?php
/**
 * Tracking Bootstrap
 *
 * @package     AffiliateWP
 * @subpackage  Core
 * @copyright   Copyright (c) 2014, Sandhills Development, LLC
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       1.0
 */

#[\AllowDynamicProperties]

/**
 * The Affiliate_WP_Tracking class.
 *
 * This class defines all primary methods by which
 * AffiliateWP tracks referral activity.
 *
 * @since  1.0
 * @uses   Affiliate_WP_Logging  Logs activity.
 */
class Affiliate_WP_Tracking {

	private $referral_var;

	private $expiration_time;

	public $referral;

	/**
	 * Is on Pantheon platform?
	 *
	 * @since 2.7.1
	 * @var   bool
	 */
	public $is_pantheon = false;

	/**
	 * Whether to enable 'compat mode' for cookie names.
	 *
	 * @since 2.7.8
	 * @var   bool
	 */
	public $cookie_compat_mode = false;

	private $debug;

	/**
	 * Logger instance.
	 *
	 * @access protected
	 * @deprecated 2.0.2
	 *
	 * @var Affiliate_WP_Logging
	 */
	protected $logs;

	/**
	 * Get things started
	 *
	 * @since 1.0
	 */
	public function __construct() {

		$this->is_pantheon = isset( $_ENV['PANTHEON_ENVIRONMENT'] );

		$this->set_expiration_time();
		$this->set_referral_var();

		/*
		 * Recorded on the first request this version serves, so that every visit created from
		 * here on is known to have been handed out with a signature. See get_visit_token().
		 */
		$this->get_visit_token_cutover();

		/*
		 * Referrals are tracked via javascript by default
		 * This fails on sites that have jQuery errors, so a fallback method is available
		 * With the fallback, the template_redirect action is used
		 */

		if ( ! $this->use_fallback_method() ) {

			add_action( 'wp_enqueue_scripts', [ $this, 'load_scripts' ] );
			add_action( 'wp_ajax_nopriv_affwp_track_visit', [ $this, 'track_visit' ] );
			add_action( 'wp_ajax_affwp_track_visit', [ $this, 'track_visit' ] );
			add_action( 'wp_ajax_affwp_get_affiliate_id', [ $this, 'ajax_get_affiliate_id_from_login' ] );
			add_action( 'wp_ajax_nopriv_affwp_get_affiliate_id', [ $this, 'ajax_get_affiliate_id_from_login' ] );

		} else {

			add_action( 'template_redirect', [ $this, 'fallback_track_visit' ], -9999 );

		}

		add_action( 'wp_head', [ $this, 'header_scripts' ] );
		add_action( 'wp_ajax_nopriv_affwp_track_conversion', [ $this, 'track_conversion' ] );
		add_action( 'wp_ajax_affwp_track_conversion', [ $this, 'track_conversion' ] );
		add_action( 'wp_ajax_affwp_check_js', [ $this, 'check_js' ] );
		add_action( 'wp_ajax_nopriv_affwp_check_js', [ $this, 'check_js' ] );

		add_filter( 'paginate_links', [ $this, 'strip_referral_from_paged_urls' ], 100 );

		add_filter( 'wp_redirect', [ $this, 'redirect_with_referral_link' ], 100, 2 );
	}

	/**
	 * Determine if jQuery is loaded.
	 *
	 * @access public
	 * @since  2.11.0
	 */
	public function is_jquery() {
		return wp_script_is( 'jquery', 'enqueued' ) || wp_script_is( 'jquery', 'to_do' ) || wp_script_is( 'jquery', 'done' );
	}

	/**
	 * Attempts to enqueue header scripts alongside jQuery.
	 *
	 * If the 'jquery' handle is not set for enqueue as of {@see 'wp_head'} at priority 10,
	 * then set header scripts to print via {@see 'wp_footer'}.
	 *
	 * @access public
	 * @since  1.0
	 * @since  2.0.10 Converted to a wrapper for a new protected print_header_script() helper.
	 */
	public function header_scripts() {

		// Back-compat for direct calls.
		if ( 'wp_head' !== current_action() ) {
			$this->print_header_script();

			return;
		}

		if ( $this->is_jquery() ) {
			$this->print_header_script();
		} else {
			add_action( 'wp_footer', [ $this, 'header_scripts' ] );
		}
	}

	/**
	 * Outputs header scripts.
	 *
	 * @access protected
	 * @since  2.0.10
	 *
	 * @see header_scripts()
	 */
	protected function print_header_script() {
		$referral_credit_last = affiliate_wp()->settings->get( 'referral_credit_last', 0 );
		?>
		<script type="text/javascript">
		var AFFWP = AFFWP || {};
		AFFWP.referral_var = '<?php echo $this->get_referral_var(); ?>';
		AFFWP.expiration = <?php echo $this->get_expiration_time(); ?>;
		AFFWP.debug = <?php echo absint( $this->debug ); ?>;

		<?php if ( $cookie_domain = $this->get_cookie_domain() ) : ?>
		AFFWP.cookie_domain = '<?php echo esc_js( $cookie_domain ); ?>';
<?php endif; ?>

		<?php if ( $this->is_jquery() && 1 !== (int) get_option( 'affwp_js_works' ) ) : ?>
		jQuery(document).ready(function($) {
			// Check if JS is working properly. If it is, we update an update in the DB
			$.ajax({
				type: "POST",
				data: {
					action: 'affwp_check_js'
				},
				url: '<?php echo admin_url( 'admin-ajax.php' ); ?>'
			});
		});
<?php endif; ?>
		AFFWP.referral_credit_last = <?php echo absint( $referral_credit_last ); ?>;
		</script>
		<?php
	}

	/**
	 * Output the conversion tracking script
	 *
	 * @since 1.0
	 * @since 2.35.3 Writes the values into the inline script as JSON, and canonicalizes the
	 *               request values so they match the signature they are sent with.
	 */
	public function conversion_script( $args = [] ) {

		$defaults = [
			'amount'      => '',
			'description' => '',
			'reference'   => '',
			'context'     => '',
			'campaign'    => '',
			'status'      => '',
			'type'        => 'sale',
		];

		$args = wp_parse_args( $args, $defaults );

		/*
		 * Read the request values as unslashed scalars. WordPress slashes the request, while
		 * shortcode attributes arrive unslashed, so without this the same value signed below
		 * would be a different string depending on where it came from. Non-scalars are dropped
		 * rather than passed on, because urldecode() on an array is a fatal error.
		 */
		$requested = [];

		foreach ( [ 'amount', 'reference', 'context', 'description', 'campaign' ] as $key ) {
			$requested[ $key ] = isset( $_REQUEST[ $key ] ) && is_scalar( $_REQUEST[ $key ] )
				? wp_unslash( (string) $_REQUEST[ $key ] )
				: '';
		}

		if ( empty( $args['amount'] ) && '' !== $requested['amount'] && 0 !== $args['amount'] ) {
			// Allow the amount to be passed via a query string or post request
			$args['amount'] = affwp_sanitize_amount( sanitize_text_field( urldecode( $requested['amount'] ) ) );
		}

		if ( empty( $args['reference'] ) && '' !== $requested['reference'] ) {
			// Allow the reference to be passed via a query string or post request
			$args['reference'] = sanitize_text_field( $requested['reference'] );
		}

		if ( empty( $args['context'] ) && '' !== $requested['context'] ) {
			$args['context'] = sanitize_text_field( $requested['context'] );
		}

		if ( empty( $args['description'] ) && '' !== $requested['description'] ) {
			$args['description'] = sanitize_text_field( $requested['description'] );
		}

		/*
		 * The status is deliberately not read from the request. It decides whether the
		 * commission is immediately payable, and a visitor must not be able to approve
		 * their own conversion by adding a query argument. The request may describe the
		 * order; it may not approve the commission.
		 */

		if ( empty( $args['campaign'] ) && '' !== $requested['campaign'] ) {
			$args['campaign'] = sanitize_text_field( $requested['campaign'] );
		}

		$md5 = $this->get_conversion_hash(
			$args['amount'],
			$args['description'],
			$args['reference'],
			$args['context'],
			$args['status'],
			$args['campaign'],
			$args['type']
		);

		/**
		 * Fires before the JavaScript that maybe fires off a conversion creation is triggered via the [affiliate_conversion_script] shortcode.
		 *
		 * @since 2.2.4
		 *
		 * @param array  $args The arguments passed to the track_conversion() method.
		 * @param string $md5  The integrity hash of the amount, description, reference, context, status, campaign and type arguments.
		 */
		do_action( 'affwp_before_conversion_tracking_script', $args, $md5 );

		$ref_cookie   = $this->get_cookie_name( 'referral' );
		$visit_cookie = $this->get_cookie_name( 'visit' );

		?>
		<script type="text/javascript">
		jQuery(document).ready(function($) {

			var ref   = $.cookie( '<?php echo esc_js( $ref_cookie ); ?>' );
			var visit = $.cookie( '<?php echo esc_js( $visit_cookie ); ?>' );

			// If a referral var is present and a referral cookie is not already set
			if( ref && visit ) {

				// Fire an ajax request to log the hit
				$.ajax({
					type: "POST",
					data: {
						/*
						 * Written with wp_json_encode(), which supplies its own quotes. It has to be
						 * this and not esc_js(): esc_js() HTML-encodes the value, and an inline script
						 * is raw text, so the browser would post "Tea &amp; Coffee" where the server
						 * signed "Tea & Coffee" and the conversion would fail its own integrity check.
						 */
						action      : 'affwp_track_conversion',
						affiliate   : ref,
						amount      : <?php echo wp_json_encode( $args['amount'] ); ?>,
						status      : <?php echo wp_json_encode( $args['status'] ); ?>,
						description : <?php echo wp_json_encode( $args['description'] ); ?>,
						context     : <?php echo wp_json_encode( $args['context'] ); ?>,
						reference   : <?php echo wp_json_encode( $args['reference'] ); ?>,
						campaign    : <?php echo wp_json_encode( $args['campaign'] ); ?>,
						type        : <?php echo wp_json_encode( $args['type'] ); ?>,
						md5         : <?php echo wp_json_encode( $md5 ); ?>
					},
					url: affwp_scripts.ajaxurl,
					success: function (response) {
						if ( window.console && window.console.log ) {
							console.log( response );
						}
					}

				}).fail(function (response) {
					if ( window.console && window.console.log ) {
						console.log( response );
					}
				}).done(function (response) {
				});

			}

		});
		</script>
		<?php
	}

	/**
	 * Load JS files
	 *
	 * @since 1.0
	 */
	public function load_scripts() {

		$suffix = ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ? '' : '.min';

		wp_enqueue_script( 'jquery-cookie', AFFILIATEWP_PLUGIN_URL . 'assets/js/jquery.cookie' . $suffix . '.js', [ 'jquery' ], '1.4.0' );
		wp_enqueue_script( 'affwp-tracking', AFFILIATEWP_PLUGIN_URL . 'assets/js/tracking' . $suffix . '.js', [ 'jquery-cookie' ], AFFILIATEWP_VERSION );
		wp_localize_script( 'jquery-cookie', 'affwp_scripts', [ 'ajaxurl' => admin_url( 'admin-ajax.php' ) ] );
		wp_localize_script( 'affwp-tracking', 'affwp_debug_vars', $this->js_debug_data() );
	}

	/**
	 * Retrieves debug data strings for use in tracking.js.
	 *
	 * @access public
	 * @since  2.0
	 *
	 * @return array Array of debug data strings.
	 */
	public function js_debug_data() {

		$integrations    = affiliate_wp()->integrations->get_enabled_integrations();
		$affwp_version   = defined( 'AFFILIATEWP_VERSION' ) ? AFFILIATEWP_VERSION : 'undefined';
		$currency        = affwp_get_currency();
		$ref_cookie      = $this->get_cookie_name( 'referral' );
		$visit_cookie    = $this->get_cookie_name( 'visit' );
		$campaign_cookie = $this->get_cookie_name( 'campaign' );

		$data = [
			'integrations'    => $integrations,
			'version'         => $affwp_version,
			'currency'        => $currency,
			'ref_cookie'      => $ref_cookie,
			'visit_cookie'    => $visit_cookie,
			'campaign_cookie' => $campaign_cookie,
		];

		/**
		 * JavaScript debug data to make available in AffiliateWP.
		 *
		 * @since 2.0
		 *
		 * @param array $data {
		 *     An array of data to pass to the AffiliateWP tracking.js file.
		 *
		 *     @type array  $integrations List of enabled integrations.
		 *     @type string $version      AffiliateWP version.
		 *     @type string $currency     Currency setting.
		 * }
		 */
		return apply_filters( 'affwp_js_debug_data', (array) $data );
	}

	/**
	 * Record referral visit via ajax
	 *
	 * @since 1.0
	 */
	public function track_visit() {

		$affiliate_id = isset( $_POST['affiliate'] ) ? absint( $_POST['affiliate'] ) : 0;
		$is_valid     = $this->is_valid_affiliate( $affiliate_id );
		$referrer     = isset( $_POST['referrer'] ) ? sanitize_text_field( $_POST['referrer'] ) : '';

		/**
		 * Filters whether to completely short-circuit tracking a visit.
		 *
		 * An explicitly true value must be passed back to the filter to execute the short-circuit.
		 *
		 * Example:
		 *
		 *     add_filter( 'affwp_tracking_skip_track_visit', '__return_true' );
		 *
		 * @since 2.1
		 *
		 * @param bool                   $skip_visit   Whether to skip tracking a visit. Default false.
		 * @param int                    $affiliate_id Affiliate ID.
		 * @param bool                   $is_valid     Whether the affiliate is valid.
		 * @param string                 $referrer     Visit referrer.
		 * @param \Affiliate_WP_Tracking $this         Tracking class instance.
		 */
		if ( true === apply_filters( 'affwp_tracking_skip_track_visit', false, $affiliate_id, $is_valid, $referrer, $this ) ) {

			affiliate_wp()->utils->log( 'Visit creation skipped during track_visit() via the affwp_tracking_skip_track_visit hook.' );

			die( '-3' );

		} elseif ( ! empty( $affiliate_id ) && $is_valid ) {

			if ( ! affwp_is_url_banned( $referrer ) ) {
				// Store the visit in the DB
				$visit_id = affiliate_wp()->visits->add(
					[
						'affiliate_id' => $affiliate_id,
						'ip'           => $this->get_ip(),
						'url'          => sanitize_text_field( $_POST['url'] ),
						// Sanitized just before saving.
						'campaign'     => ! empty( $_POST['campaign'] ) ? $_POST['campaign'] : '',
						'referrer'     => $referrer,
					]
				);

				affiliate_wp()->utils->log( sprintf( 'Visit #%d recorded for affiliate #%d in track_visit()', $visit_id, $affiliate_id ) );

				// The signature goes back with the ID so the script can store both in the cookie.
				echo esc_html( $this->get_visit_token( $visit_id ) );

				exit;

			} else {

				affiliate_wp()->utils->log( sprintf( '"%s" is a banned URL. A visit was not recorded.', $referrer ) );

				die( '-2' );
			}
		} elseif ( ! $is_valid ) {

			affiliate_wp()->utils->log( 'Invalid affiliate ID during track_visit()' );

			die( '-2' );

		} else {

			affiliate_wp()->utils->log( 'Affiliate ID missing during track_visit()' );

			die( '-2' );

		}
	}

	/**
	 * Generate the integrity hash used to verify conversion tracking parameters.
	 *
	 * The hash is a keyed HMAC that incorporates a server-side secret (the site's
	 * auth salt). Because the secret never leaves the server, the hash cannot be
	 * forged offline by a client, which prevents attackers from crafting arbitrary
	 * conversion (referral) parameters. See CVE / Wordfence report on referral
	 * forgery via the affwp_track_conversion AJAX action.
	 *
	 * The affiliate is deliberately not signed here. It is not taken from the request at
	 * all: track_conversion() reads it from the visit the conversion is recorded against,
	 * so there is no client-supplied affiliate left to bind. Signing it would also make
	 * this markup specific to one visitor, and a success page served from a page cache
	 * would then carry one visitor's affiliate to everyone else.
	 *
	 * @since 2.35.0
	 * @since 2.35.3 Added the $type parameter, and length-prefixed the signed values so that
	 *               two different sets of arguments cannot produce one hash.
	 *
	 * @param string $amount      Referral amount.
	 * @param string $description Referral description.
	 * @param string $reference   Referral reference.
	 * @param string $context     Referral context.
	 * @param string $status      Referral status.
	 * @param string $campaign    Referral campaign.
	 * @param string $type        Optional. Referral type. Default 'sale', matching the default
	 *                           the conversion script itself sends.
	 * @return string Hex-encoded HMAC-SHA256 hash of the given arguments.
	 */
	public function get_conversion_hash( $amount, $description, $reference, $context, $status, $campaign, $type = 'sale' ) {

		$values = [
			(string) $amount,
			(string) $description,
			(string) $reference,
			(string) $context,
			(string) $status,
			(string) $campaign,
			(string) $type,
		];

		/*
		 * Each value is prefixed with its own length, so the signed string can only be read
		 * back as the one set of values that produced it.
		 *
		 * Joining the values, with a separator or without, is not enough. Plain concatenation
		 * lets an amount of '1' and a description of '23' sign the same string as an amount of
		 * '12' and a description of '3'. A separator only moves the problem: because these
		 * values can themselves contain the separator, a value ending in one shifts every
		 * boundary after it, and a signature taken over a harmless campaign of "unpaid|"
		 * would also verify a status of "unpaid" — handing the caller the payable status this
		 * hash exists to protect. Counting the bytes leaves no boundary to move.
		 */
		$data = '';

		foreach ( $values as $value ) {
			$data .= strlen( $value ) . ':' . $value . '|';
		}

		return hash_hmac( 'sha256', $data, wp_salt( 'auth' ) );
	}

	/**
	 * Record referral conversion via ajax
	 *
	 * This is called anytime a referred visitor lands on a success page, defined by the [affiliate_conversion_script] shortcode
	 *
	 * Dies with a negative code the calling script logs to the console: -2 (missing or invalid
	 * affiliate), -3 (integrity hash mismatch), -4 (visit already converted), -5 (zero amount
	 * ignored), -6 (short-circuited by a filter), -7 (the visit is missing, unknown, or not
	 * shown to belong to this visitor).
	 *
	 * @since 1.0
	 * @since 2.35.3 The affiliate is read from the visit being converted rather than from the
	 *               request, and the visit has to exist and to have been handed to this
	 *               visitor. See get_visit_token().
	 */
	public function track_conversion() {

		/*
		 * Unslashed scalars, matching how conversion_script() canonicalized the same values
		 * before signing them. Comparing a slashed value against a signature taken over the
		 * unslashed one would fail on any value containing a quote or a backslash.
		 */
		$posted = [];
		$raw    = [];

		foreach ( [ 'amount', 'description', 'reference', 'context', 'status', 'campaign', 'type' ] as $key ) {
			$raw[ $key ]    = isset( $_POST[ $key ] ) && is_scalar( $_POST[ $key ] ) ? (string) $_POST[ $key ] : '';
			$posted[ $key ] = wp_unslash( $raw[ $key ] );
		}

		$visit_id = $this->get_visit_id();
		$visit    = affwp_validate_visit_id( $visit_id ) ? affwp_get_visit( $visit_id ) : false;

		/*
		 * The commission belongs to the affiliate who earned the visit, so take the affiliate
		 * from the visit record rather than from the request. A request that names a different
		 * affiliate would otherwise route the commission to an account that never referred
		 * this visitor.
		 */
		$requested_affiliate_id = isset( $_POST['affiliate'] ) ? absint( $_POST['affiliate'] ) : 0;
		$affiliate_id           = $visit ? absint( $visit->affiliate_id ) : 0;

		if ( $visit && $requested_affiliate_id !== $affiliate_id ) {
			affiliate_wp()->utils->log(
				sprintf(
					'Conversion for visit #%1$d requested affiliate #%2$d but the visit was earned by affiliate #%3$d, which is the one credited.',
					$visit_id,
					$requested_affiliate_id,
					$affiliate_id
				)
			);
		}

		$is_valid = ! empty( $affiliate_id ) && $this->is_valid_affiliate( $affiliate_id );

		$expected_hash = $this->get_conversion_hash(
			$posted['amount'],
			$posted['description'],
			$posted['reference'],
			$posted['context'],
			$posted['status'],
			$posted['campaign'],
			$posted['type']
		);
		$posted_hash   = isset( $_POST['md5'] ) && is_scalar( $_POST['md5'] ) ? (string) $_POST['md5'] : '';

		/**
		 * Filters whether to completely short-circuit tracking a conversion.
		 *
		 * An explicitly true value must be passed back to the filter to execute the short-circuit.
		 *
		 * Example:
		 *
		 *     add_filter( 'affwp_tracking_skip_track_conversion', '__return_true' );
		 *
		 * @since 2.1
		 *
		 * @param bool                   $skip_visit   Whether to skip tracking the conversion. Default false.
		 * @param int                    $affiliate_id Affiliate ID taken from the visit being converted, or 0 if
		 *                                             there is no such visit.
		 * @param bool                   $is_valid     Whether the affiliate is valid.
		 * @param int|false              $visit_id     Visit ID derived from the cookie, otherwise false.
		 * @param \Affiliate_WP_Tracking $this         Tracking class instance.
		 */
		if ( true === apply_filters( 'affwp_tracking_skip_track_conversion', false, $affiliate_id, $is_valid, $visit_id, $this ) ) {

			affiliate_wp()->utils->log( 'Conversion handling skipped during track_conversion() via the affwp_tracking_skip_track_conversion hook.' );

			die( '-6' );

		} elseif ( ! hash_equals( $expected_hash, $posted_hash ) ) {

			/*
			 * Checked before the visit is looked at, so that the response cannot be used to
			 * tell an existing visit ID from a missing one without a valid hash.
			 */
			affiliate_wp()->utils->log( sprintf( 'Invalid conversion hash in track_conversion(). Needed: %s. Posted: %s', $expected_hash, $posted_hash ) );

			die( '-3' ); // The args were modified or the integrity hash could not be verified.

		} elseif ( ! $visit ) {

			/*
			 * The visit has to be a real record. Without this the "already converted" check
			 * below can be sidestepped indefinitely by sending a visit ID that has never
			 * existed, since no referral can ever be found for it.
			 */
			affiliate_wp()->utils->log( sprintf( 'Referral not created because visit "%s" is missing or does not exist.', $visit_id ? $visit_id : '' ) );

			die( '-7' ); // Ignore a referral without a visit to record it against.

		} elseif ( $this->visit_id_is_from_cookie( $visit_id )
			&& ! $this->visit_predates_signed_cookies( $visit_id, $visit )
			&& ! $this->visit_id_is_signed( $visit_id )
		) {

			/*
			 * This visit was handed out with a signature, so a cookie naming it has to carry
			 * one. Without this the visit ID is a bearer token anyone can guess: another
			 * visitor's pending visit could be converted, crediting a conversion that never
			 * happened and using up the visit so their real one is turned away as a duplicate.
			 *
			 * Answered with the same code as a missing visit, so that the response does not
			 * reveal which visit IDs exist.
			 */
			affiliate_wp()->utils->log( sprintf( 'Referral not created because the cookie for visit #%d is not signed by this site.', $visit_id ) );

			die( '-7' ); // Ignore a referral whose visit cannot be shown to belong to this visitor.

		} elseif ( $is_valid ) {

			affiliate_wp()->utils->log( sprintf( 'Valid affiliate ID, %d, in track_conversion()', $affiliate_id ) );

			$referral = affwp_get_referral_by( 'visit_id', $visit_id );

			if ( ! is_wp_error( $referral ) ) {

				affiliate_wp()->utils->log( sprintf( 'Referral already generated for visit #%d.', $visit_id ) );

				die( '-4' ); // This visit has already generated a referral
			}

			$status = '' !== $posted['status'] ? sanitize_text_field( $posted['status'] ) : 'unpaid';
			$amount = sanitize_text_field( urldecode( $posted['amount'] ) );

			/*
			 * Only a real referral status can be applied below. Anything else would be written
			 * to the referral as-is, leaving a record no screen or report knows how to treat.
			 */
			if ( ! array_key_exists( $status, affwp_get_referral_statuses() ) ) {

				affiliate_wp()->utils->log( sprintf( 'Conversion status "%s" is not a referral status, using pending instead.', $status ) );

				$status = 'pending';
			}

			$type = sanitize_text_field( $posted['type'] );

			// Same reasoning as the status above: only a registered type can reach the referral.
			if ( ! array_key_exists( $type, affwp_get_referral_types() ) ) {

				affiliate_wp()->utils->log( sprintf( 'Conversion type "%s" is not a referral type, using sale instead.', $type ) );

				$type = 'sale';
			}

			if ( 0 == $amount && affiliate_wp()->settings->get( 'ignore_zero_referrals' ) ) {

				affiliate_wp()->utils->log( 'Referral not created due to 0.00 amount.' );

				die( '-5' ); // Ignore a zero amount referral
			}

			$amount = $amount > 0 ? affwp_calc_referral_amount( $amount, $affiliate_id ) : 0;

			/*
			 * Taken from the request as it arrived, still slashed, because the database layer
			 * unslashes what it is given. The unslashed copy above exists only so the signature
			 * covers the same bytes the page signed; passing that on would strip a second level
			 * and store "C:\path" where the order said "C:\\path".
			 */
			$description = sanitize_text_field( $raw['description'] );
			$context     = sanitize_text_field( $raw['context'] );
			$campaign    = sanitize_text_field( $raw['campaign'] );
			$reference   = sanitize_text_field( $raw['reference'] );

			// Create a new referral
			$referral_id = affiliate_wp()->referrals->add(
				apply_filters(
					'affwp_insert_pending_referral',
					[
						'affiliate_id' => $affiliate_id,
						'amount'       => $amount,
						'status'       => 'pending',
						'description'  => $description,
						'context'      => $context,
						'campaign'     => $campaign,
						'reference'    => $reference,
						'type'         => $type,
						'visit_id'     => $visit_id,
					],
					$amount,
					$reference,
					$description,
					$affiliate_id,
					$visit_id,
					[],
					$context
				)
			);

			affiliate_wp()->utils->log( sprintf( 'Referral created for visit #%d.', $visit_id ) );

			// Update the referral status.
			affwp_set_referral_status( $referral_id, $status );

			affiliate_wp()->utils->log( sprintf( 'Referral #%d set to %s for visit #%d.', $referral_id, $status, $visit_id ) );

			// Update the visit.
			affiliate_wp()->visits->update( $visit_id, [ 'referral_id' => $referral_id ], '', 'visit' );

			affiliate_wp()->utils->log( sprintf( 'Visit #%d marked as converted.', $visit_id ) );

			echo $referral_id;
			exit;

		} else {

			affiliate_wp()->utils->log( 'Affiliate ID missing or invalid during track_conversion()' );

			die( '-2' );

		}
	}

	/**
	 * Record referral visit via template_redirect
	 *
	 * @since 1.0
	 */
	public function fallback_track_visit() {

		$affiliate_id = $this->referral;

		if ( empty( $affiliate_id ) ) {

			$affiliate_id = $this->get_fallback_affiliate_id();

		}

		if ( empty( $affiliate_id ) ) {
			return;
		}

		if ( ! is_numeric( $affiliate_id ) ) {
			$affiliate_id = $this->get_affiliate_id_from_login( $affiliate_id );
		}

		$affiliate_id = absint( $affiliate_id );
		$is_valid     = $this->is_valid_affiliate( $affiliate_id );
		$visit_id     = $this->get_visit_id();
		$campaign     = $this->get_campaign();
		$referrer     = ! empty( $_SERVER['HTTP_REFERER'] ) ? sanitize_text_field( $_SERVER['HTTP_REFERER'] ) : '';

		/** This filter is documented in includes/class-tracking.php. */
		if ( true === apply_filters( 'affwp_tracking_skip_track_visit', false, $affiliate_id, $is_valid, $referrer, $this ) ) {

			affiliate_wp()->utils->log( 'Visit creation skipped during fallback_track_visit() via the affwp_tracking_skip_track_visit hook.' );

		} elseif ( $is_valid && ( ! $visit_id || affiliate_wp()->settings->get( 'referral_credit_last' ) ) ) {

			if ( ( ! empty( $referrer ) && ! affwp_is_url_banned( $referrer ) ) || empty( $referrer ) ) {

				if ( $this->get_affiliate_id() === $affiliate_id && affiliate_wp()->settings->get( 'referral_credit_last' ) ) {
					affiliate_wp()->utils->log( 'Visit creation skipped during fallback_track_visit() with Credit Last Referrer enabled because ID already tracked.' );
					return;
				}

				$this->set_affiliate_id( $affiliate_id );

				// Store the visit in the DB
				$visit_id = affiliate_wp()->visits->add(
					[
						'affiliate_id' => $affiliate_id,
						'ip'           => $this->get_ip(),
						'url'          => $this->get_current_page_url(),
						'campaign'     => $campaign,
						'referrer'     => $referrer,
					]
				);

				$this->set_visit_id( $visit_id );

				$this->set_campaign( $campaign );
			}
		} elseif ( ! $is_valid ) {

			affiliate_wp()->utils->log( 'Invalid affiliate ID during fallback_track_visit()' );

		} elseif ( ! $visit_id ) {

			affiliate_wp()->utils->log( 'Missing visit ID during fallback_track_visit()' );

		} elseif ( $visit_id ) {

			affiliate_wp()->utils->log( 'Visit already logged during fallback_track_visit()' );

		} else {

			affiliate_wp()->utils->log( 'Invalid affiliate ID during fallback_track_visit()' );

		}
	}

	/**
	 * Get the affiliate ID when using fallback tracking method
	 *
	 * @since 1.7.11
	 */
	public function get_fallback_affiliate_id() {

		$affiliate_id = ! empty( $_GET[ $this->get_referral_var() ] ) ? $_GET[ $this->get_referral_var() ] : false;

		if ( empty( $affiliate_id ) ) {

			$path = ! empty( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : '';

			if ( false !== strpos( $path, $this->get_referral_var() . '/' ) ) {

				$pieces = explode( '/', str_replace( '?', '/', $path ) );
				$key    = array_search( $this->get_referral_var(), $pieces );

				$pieces[ $key + 1 ] = strtolower( sanitize_user( $pieces[ $key + 1 ] ) );

				if ( $key ) {

					$key         += 1;
					$affiliate_id = isset( $pieces[ $key ] ) ? $pieces[ $key ] : false;

					// Look for affiliate ID by username
					if ( intval( $affiliate_id ) < 1 || ! is_numeric( $affiliate_id ) ) {

						$affiliate_id = $this->get_affiliate_id_from_login( $affiliate_id );

						if ( empty( $affiliate_id ) ) {

							affiliate_wp()->utils->log( 'No user account found for given affiliate ID or login during get_fallback_affiliate_id()' );

							$affiliate_id = false;

						}
					}
				}
			}
		}

		return $affiliate_id;
	}


	/**
	 * Get the referral campaign
	 *
	 * @since 1.7
	 */
	public function get_campaign() {
		$campaign_cookie = $this->get_cookie_name( 'campaign' );
		$campaign        = isset( $_COOKIE[ $campaign_cookie ] ) ? sanitize_text_field( $_COOKIE[ $campaign_cookie ] ) : '';

		if ( empty( $campaign ) ) {

			$campaign = isset( $_REQUEST['campaign'] ) ? sanitize_text_field( $_REQUEST['campaign'] ) : '';

		}

		/**
		 * Filters the campaign for the current referral.
		 *
		 * @Since 1.7
		 *
		 * @param string                 $campaign Campaign name.
		 * @param \Affiliate_WP_Tracking $this     Tracking class instance.
		 */
		return apply_filters( 'affwp_get_campaign', $campaign, $this );
	}

	/**
	 * Get the referral variable
	 *
	 * @since 1.0
	 */
	public function get_referral_var() {
		return $this->referral_var;
	}

	/**
	 * Set the referral variable
	 *
	 * @since 1.0
	 */
	public function set_referral_var() {
		$var = affiliate_wp()->settings->get( 'referral_var', 'ref' );

		/**
		 * Filters the referral var for the current request.
		 *
		 * @since 1.0
		 *
		 * @param string $var Referral var.
		 */
		$this->referral_var = apply_filters( 'affwp_referral_var', $var );
	}

	/**
	 * Set the cookie expiration time
	 *
	 * @since 1.0
	 */
	public function set_expiration_time() {

		// Default time is 1 day
		$days = affiliate_wp()->settings->get( 'cookie_exp', 1 );

		// Cannot permit cookies to go past 2038
		$max  = ( 2038 - date( 'Y' ) ) * 365;
		$days = $days > $max ? $max : $days;

		/**
		 * Filters the cookie expiration time (in days).
		 *
		 * @since 1.0
		 *
		 * @param int $days How many days to set the tracking cookie for. Default 1 (day).
		 */
		$this->expiration_time = apply_filters( 'affwp_cookie_expiration_time', $days );
	}

	/**
	 * Get the cookie expiration time in days
	 *
	 * @since 1.0
	 */
	public function get_expiration_time() {
		return $this->expiration_time;
	}

	/**
	 * Determine if current visit was referred
	 *
	 * @since 1.0
	 */
	public function was_referred() {
		$ref_cookie   = $this->get_cookie_name( 'referral' );
		$was_referred = isset( $_COOKIE[ $ref_cookie ] ) && $this->is_valid_affiliate( $_COOKIE[ $ref_cookie ] );

		/**
		 * Filters whether the current visit was referred.
		 *
		 * @since 1.0
		 *
		 * @param bool                   $was_referred Whether the current visit was referred.
		 * @param \Affiliate_WP_Tracking $this         Tracking class instance.
		 */
		return (bool) apply_filters( 'affwp_was_referred', $was_referred, $this );
	}

	/**
	 * Builds the value stored in the visit cookie: the visit ID and a keyed signature of it.
	 *
	 * The visit decides which affiliate a conversion is credited to, so the browser must not
	 * be able to name a visit it was never given. Signing the ID with the site's auth salt
	 * means only a visit this server handed out can be presented back to it.
	 *
	 * The signature travels in the cookie rather than in the page, so it stays per-visitor
	 * and page caching is unaffected.
	 *
	 * @since 2.35.3
	 *
	 * @param int $visit_id Visit ID.
	 * @return string "{id}.{signature}", or an empty string when there is no visit to sign.
	 */
	public function get_visit_token( $visit_id ) {

		$visit_id = intval( $visit_id );

		/*
		 * A failed visit creation has nothing to sign. Answering with an empty string keeps the
		 * cookie empty, so the conversion script's own guard stops rather than firing a request
		 * that can only be turned away.
		 */
		if ( $visit_id < 1 ) {
			return '';
		}

		/*
		 * Scoped to the site, because subsites of a multisite share the auth salt while each
		 * keeps its own visits table, and the tracking script writes this cookie at the root
		 * path — so without the blog ID a token minted on one subsite would verify against
		 * another's visit of the same number.
		 *
		 * Except when the network shares one visits table, where a visit ID means the same
		 * thing everywhere and a visitor is meant to be able to convert on another subsite.
		 * Scoping to the blog there would refuse the conversions that configuration exists for.
		 */
		$scope = defined( 'AFFILIATE_WP_NETWORK_WIDE' ) && AFFILIATE_WP_NETWORK_WIDE
			? 0
			: get_current_blog_id();

		$data = sprintf( 'affwp_visit:%d:%d', $scope, $visit_id );

		return $visit_id . '.' . hash_hmac( 'sha256', $data, wp_salt( 'auth' ) );
	}

	/**
	 * Retrieves the raw value of the visit cookie.
	 *
	 * @since 2.35.3
	 *
	 * @return string Cookie value, or an empty string when it is not set.
	 */
	private function get_visit_cookie() {

		$visit_cookie = $this->get_cookie_name( 'visit' );

		return isset( $_COOKIE[ $visit_cookie ] ) && is_scalar( $_COOKIE[ $visit_cookie ] )
			? (string) $_COOKIE[ $visit_cookie ]
			: '';
	}

	/**
	 * Retrieves the visit ID the cookie names, read from the front of the value.
	 *
	 * The digits are matched rather than cast. intval() on "{id}.{signature}" reads the dot
	 * and the signature as a float, and the hex alphabet contains "e", so intval() on a
	 * signature beginning "5e1..." returns the wrong visit entirely: intval( '67.5e1f32' )
	 * is 675, not 67. Roughly one signature in ten begins that way.
	 *
	 * @since 2.35.3
	 *
	 * @return int|false Visit ID named by the cookie, or false when it names none.
	 */
	private function get_visit_cookie_id() {

		if ( ! preg_match( '/^\s*(\d+)/', $this->get_visit_cookie(), $matches ) ) {
			return false;
		}

		return intval( $matches[1] );
	}

	/**
	 * Determines whether the visit cookie carries this site's signature for a given visit.
	 *
	 * @since 2.35.3
	 *
	 * @param int $visit_id The visit the signature has to cover.
	 * @return bool True when the cookie holds that visit ID and its valid signature.
	 */
	public function visit_id_is_signed( $visit_id ) {

		/*
		 * Matched rather than split, and only the signature is compared, so that stray bytes
		 * around the value do not make the cookie unverifiable for good. The tracking script
		 * stores the AJAX response verbatim, and anything else that prints on that request
		 * (a profiler, a debug bar, a stray newline) ends up inside the cookie.
		 */
		if ( ! preg_match( '/^(\d+)\.([0-9a-f]{64})/', trim( $this->get_visit_cookie() ), $matches ) ) {
			return false;
		}

		list( , $signed_id, $signature ) = $matches;

		/*
		 * The signature has to cover the visit being credited. Checking only that the cookie
		 * agrees with itself would leave the signed ID free to drift from the one used.
		 */
		if ( intval( $signed_id ) !== intval( $visit_id ) ) {
			return false;
		}

		return hash_equals( $this->get_visit_token( $signed_id ), $signed_id . '.' . $signature );
	}

	/**
	 * Determines whether a visit ID is the one the visit cookie names.
	 *
	 * A visit ID can also reach us from the {@see 'affwp_tracking_get_visit_id'} filter. The
	 * cookie-consent integration serves one from the session while cookies are blocked, and
	 * there is no cookie signature to expect in that case.
	 *
	 * @since 2.35.3
	 * @since 2.37.1 Public, so integrations that convert outside track_conversion() apply the same rule.
	 *
	 * @param int $visit_id Visit ID.
	 * @return bool True when the cookie is set and names this visit.
	 */
	public function visit_id_is_from_cookie( $visit_id ) {

		$cookie_id = $this->get_visit_cookie_id();

		return false !== $cookie_id && $cookie_id === intval( $visit_id );
	}

	/**
	 * Retrieves the marker describing which visits predate signed visit cookies.
	 *
	 * Visits recorded before this version was installed were handed out unsigned, so a cookie
	 * naming one cannot be expected to prove itself and is still accepted. The marker records
	 * the highest visit ID at that moment, and when it was taken.
	 *
	 * A visit ID rather than a visit date, because it is monotonic and needs no timezone
	 * reasoning. Stored on the first request this version serves rather than by an upgrade
	 * routine, so that a missed upgrade cannot leave the check unable to tell a legacy visit
	 * from a new one. The cookie lifetime is recorded alongside it, so that changing the
	 * setting afterwards cannot reopen a window that has already closed.
	 *
	 * @since 2.35.3
	 *
	 * @return array {
	 *     @type int $visit_id Highest visit ID recorded before this version, or 0 if none.
	 *     @type int $time     Unix timestamp the marker was taken.
	 *     @type int $days     Cookie lifetime in days as it stood then, or 0 if unknown.
	 * }
	 */
	public function get_visit_token_cutover() {

		/*
		 * Network-wide installs share one visits table, so the marker has to be shared too.
		 * Held per site, a subsite serving its first request later would take a marker that
		 * already covered every signed visit on the network and grandfather all of them.
		 */
		$network_wide = defined( 'AFFILIATE_WP_NETWORK_WIDE' ) && AFFILIATE_WP_NETWORK_WIDE;

		/*
		 * Read with a sentinel rather than the usual false default, because a stored false is
		 * indistinguishable from an absent option otherwise, and the two must not be treated
		 * alike: one means this is the first request, the other means the marker was tampered
		 * with or truncated.
		 */
		$missing  = '__affwp_unset__';
		$cutover  = $network_wide
			? get_site_option( 'affwp_visit_token_cutover', $missing )
			: get_option( 'affwp_visit_token_cutover', $missing );

		/*
		 * Derived on the first request that finds no marker at all. Anything else stored under
		 * the key — a truncated value, a string, a stored false — is treated as no
		 * grandfathering, because deriving it again from the table as it stands would hand
		 * every visit recorded since a fresh window.
		 */
		if ( $missing !== $cutover && ! is_array( $cutover ) ) {
			return [
				'visit_id' => 0,
				'time'     => 0,
				'days'     => 0,
			];
		}

		if ( $missing === $cutover ) {

			global $wpdb;

			$table = affiliate_wp()->visits->table_name;

			/*
			 * On the activation request this runs before the tables are created, so check
			 * first: an error from a missing table would be printed during plugin load.
			 */
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery -- One-time marker, no cache to prime.
			$installed = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $table ) ) ) === $table;

			/*
			 * Without the table there is no way to tell a legacy visit from a new one yet.
			 * Answer for this request only and store nothing, rather than persisting a marker
			 * that would turn every pre-upgrade visitor away for good.
			 */
			if ( ! $installed ) {
				return [
					'visit_id' => 0,
					'time'     => time(),
					'days'     => 0,
				];
			}

			$cutover = [
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL -- Table name, one-time marker.
				'visit_id' => intval( $wpdb->get_var( "SELECT MAX(visit_id) FROM {$table}" ) ),
				'time'     => time(),
				// intval, not absint: a negative lifetime should close the window, not mirror into one.
				'days'     => min( max( intval( $this->get_expiration_time() ), 0 ), 365 ),
			];

			if ( $network_wide ) {
				add_site_option( 'affwp_visit_token_cutover', $cutover );
			} else {
				add_option( 'affwp_visit_token_cutover', $cutover );
			}
		}

		return [
			'visit_id' => isset( $cutover['visit_id'] ) ? intval( $cutover['visit_id'] ) : 0,
			// Never later than now, so a marker dated in the future cannot widen anything.
			'time'     => isset( $cutover['time'] ) ? min( intval( $cutover['time'] ), time() ) : 0,
			'days'     => isset( $cutover['days'] ) ? min( max( intval( $cutover['days'] ), 0 ), 365 ) : 0,
		];
	}

	/**
	 * Determines whether a visit may be converted with an unsigned cookie.
	 *
	 * Only the visits that predate this version, and only for as long as a cookie naming one
	 * could still legitimately be held. Past that every outstanding cookie has expired and
	 * been reissued signed, so the exception closes itself.
	 *
	 * @since 2.35.3
	 *
	 * @param int          $visit_id Visit ID.
	 * @param \AffWP\Visit $visit    The visit itself, so its age can be considered.
	 * @return bool True when the visit predates signed cookies and the grace period is open.
	 */
	public function visit_predates_signed_cookies( $visit_id, $visit ) {

		$cutover = $this->get_visit_token_cutover();

		// Recorded before signing began, by ID.
		if ( intval( $visit_id ) > $cutover['visit_id'] ) {
			return false;
		}

		// A marker without a recorded cookie lifetime grandfathers nothing.
		if ( $cutover['days'] < 1 ) {
			return false;
		}

		$date     = isset( $visit->date ) ? trim( (string) $visit->date ) : '';
		$recorded = '' !== $date ? strtotime( $date . ' UTC' ) : false;

		// Visit dates are stored in UTC. An unreadable one grandfathers nothing.
		if ( false === $recorded ) {
			return false;
		}

		$window = ( $cutover['days'] + 1 ) * DAY_IN_SECONDS;

		/*
		 * And recorded before signing began, by date, which is what bounds a marker whose
		 * visit_id cannot be trusted. A day of slack keeps this off the exact boundary.
		 */
		if ( $recorded > $cutover['time'] + DAY_IN_SECONDS ) {
			return false;
		}

		/*
		 * Finally, the visit's own cookie has to be one that could still be held. Measuring from
		 * the visit rather than from the marker is what makes the exception close continuously:
		 * each visit drops out as its own cookie expires, instead of the whole pre-upgrade table
		 * staying open for one shared window. The lifetime comes from the marker, not from the
		 * setting as it stands now, so raising Cookie Expiration later cannot reopen it.
		 */
		return time() < $recorded + $window;
	}

	/**
	 * Retrieves the visit ID from the affwp_ref_visit_id cookie (if set).
	 *
	 * The cookie holds "{id}.{signature}" since 2.35.3. Only the ID is returned, so callers
	 * are unaffected by the format; use visit_id_is_signed() where the ID has to be trusted.
	 *
	 * @access public
	 * @since  1.0
	 *
	 * @return int|false Visit ID from the cookie or false.
	 */
	public function get_visit_id() {
		/*
		 * Read through get_visit_cookie_id(), which drops a non-scalar value and parses the ID
		 * rather than casting it. intval() on an array is 1 with no warning, so an
		 * "affwp_ref_visit_id[]=" cookie would otherwise name visit #1 while reading as no
		 * cookie at all, and the signature check would be skipped as though the ID had come
		 * from a filter.
		 */
		$visit_id = $this->get_visit_cookie_id();
		$visit_id = ! empty( $visit_id ) ? $visit_id : false;

		/**
		 * Filters the visit ID retrieved from the tracking cookie.
		 *
		 * @since 2.32.0
		 *
		 * @param int|false              $visit_id Visit ID, or false if not set.
		 * @param \Affiliate_WP_Tracking $this     Tracking class instance.
		 */
		return apply_filters( 'affwp_tracking_get_visit_id', $visit_id, $this );
	}

	/**
	 * Set the visit ID
	 *
	 * @since 1.0
	 * @since 2.35.3 Stores the visit ID with a signature. See get_visit_token().
	 */
	public function set_visit_id( $visit_id = 0 ) {
		$visit_cookie = $this->get_cookie_name( 'visit' );
		setcookie( $visit_cookie, $this->get_visit_token( $visit_id ), strtotime( '+' . $this->get_expiration_time() . ' days' ), COOKIEPATH, $this->get_cookie_domain() );

		/**
		 * Fires immediately after the affwp_ref_visit_id cookie is set
		 *
		 * @since 2.1.17
		 *
		 * @param int                    $visit_id Visit ID.
		 * @param \Affiliate_WP_Tracking $this     Tracking class instance.
		 */
		do_action( 'affwp_tracking_set_visit_id', $visit_id, $this );
	}

	/**
	 * Get the referring affiliate ID
	 *
	 * @since 1.0
	 */
	public function get_affiliate_id() {

		$ref_cookie = $this->get_cookie_name( 'referral' );

		$affiliate_id = ! empty( $_COOKIE[ $ref_cookie ] ) ? $_COOKIE[ $ref_cookie ] : false;

		if ( ! empty( $affiliate_id ) ) {

			$affiliate_id = absint( $affiliate_id );

		}

		/**
		 * Filters the affiliate ID for the current referral.
		 *
		 * @since 1.0
		 *
		 * @param int $affiliate_id Affiliate ID.
		 */
		return apply_filters( 'affwp_tracking_get_affiliate_id', $affiliate_id );
	}

	/**
	 * Get the affiliate's ID from their user login
	 *
	 * @since 1.3
	 */
	public function get_affiliate_id_from_login( $login = '' ) {

		$affiliate_id = 0;

		if ( $affiliate = affwp_get_affiliate( urldecode( $login ) ) ) {
			$affiliate_id = $affiliate->ID;
		}

		/**
		 * Filters the affiliate ID retrieved from login in Affiliate_WP_Tracking.
		 *
		 * @since 1.3
		 *
		 * @param int    $affiliate_id Affiliate ID or 0 if no matching affiliate was found.
		 * @param string $login
		 */
		return apply_filters( 'affwp_tracking_get_affiliate_id', $affiliate_id, $login );
	}

	/**
	 * Get the affiliate's ID from their user login
	 *
	 * @since 1.3
	 */
	public function ajax_get_affiliate_id_from_login() {

		$success      = 0;
		$affiliate_id = 0;

		if ( ! empty( $_POST['affiliate'] ) ) {

			$affiliate_id = $this->get_affiliate_id_from_login( $_POST['affiliate'] );

			if ( ! empty( $affiliate_id ) ) {

				$success = 1;

			}
		}

		$return = [
			'success'      => $success,
			'affiliate_id' => $affiliate_id,
		];

		wp_send_json_success( $return );
	}

	/**
	 * Set the referring affiliate ID
	 *
	 * @since 1.0
	 */
	public function set_affiliate_id( $affiliate_id = 0 ) {
		$ref_cookie = $this->get_cookie_name( 'referral' );
		setcookie( $ref_cookie, $affiliate_id, strtotime( '+' . $this->get_expiration_time() . ' days' ), COOKIEPATH, $this->get_cookie_domain() );

		/**
		 * Fires immediately after the affwp_ref cookie is set
		 *
		 * @since 2.1.17
		 *
		 * @param int                    $affiliate_id Affiliate ID.
		 * @param \Affiliate_WP_Tracking $this         Tracking class instance.
		 */
		do_action( 'affwp_tracking_set_affiliate_id', $affiliate_id, $this );
	}

	/**
	 * Set the campaign
	 *
	 * @since 2.1.15
	 */
	public function set_campaign( $campaign = '' ) {
		$campaign_cookie = $this->get_cookie_name( 'campaign' );
		setcookie( $campaign_cookie, $campaign, strtotime( '+' . $this->get_expiration_time() . ' days' ), COOKIEPATH, $this->get_cookie_domain() );

		/**
		 * Fires immediately after the affwp_campaign cookie is set
		 *
		 * @since 2.1.17
		 *
		 * @param string                 $campaign Campaign.
		 * @param \Affiliate_WP_Tracking $this     Tracking class instance.
		 */
		do_action( 'affwp_tracking_set_campaign', $campaign, $this );
	}

	/**
	 * Get the cookie domain.
	 *
	 * @since 2.1.10
	 * @return bool|string false if a cookie domain isn't set, string hostname (host.tld) otherwise
	 */
	public function get_cookie_domain() {

		// COOKIE_DOMAIN is false by default
		$cookie_domain = COOKIE_DOMAIN;

		$share_cookies = affiliate_wp()->settings->get( 'cookie_sharing', false );

		// providing a domain to jQuery.cookie or PHP's setcookie results prefixes the cookie domain
		// with a dot, indicating it should be shared with sub-domains
		if ( ! $cookie_domain && $share_cookies ) {
			$cookie_domain = parse_url( get_home_url(), PHP_URL_HOST );
		}

		/**
		 * Filters the tracking cookie domain.
		 *
		 * @since 2.1.10
		 *
		 * @param string $cookie_domain cookie domain
		 */
		return apply_filters( 'affwp_tracking_cookie_domain', $cookie_domain );
	}

	/**
	 * Gets the cookie name.
	 *
	 * @since 2.7.1
	 *
	 * @param string $cookie_type Optional. The cookie type. Accepts 'referral', 'visit', 'campaign',
	 *                            or a custom type handled by setting a cookie name for the type
	 *                            via the {@see 'affwp_get_cookie_name'} filter. Default 'referral'.
	 * @return string The cookie name to use. If the Pantheon network is detected, the cookie name will
	 *                be prefixed with 'wp_'.
	 */
	public function get_cookie_name( $cookie_type = 'referral' ) {

		/**
		 * Whether to use compat mode for cookie handling.
		 *
		 * If enabled, cooke names will be prefixed with 'wp-'.
		 *
		 * @since 2.7.8
		 *
		 * @param bool                   $enable Whether to enable cookie compat mode. Default false.
		 * @param \Affiliate_WP_Tracking $this   Tracking class instance.
		 */
		$cookie_compat_mode = (bool) apply_filters( 'affwp_tracking_cookie_compat_mode', false, $this );

		// Determine whether to enable cookie compat mode.
		if ( true === $this->is_pantheon || true === $cookie_compat_mode ) {
			$this->cookie_compat_mode = true;
		}

		// Get cookie name from cookie type.
		$cookie_name = '';

		switch ( $cookie_type ) {
			case 'referral':
				$cookie_name = 'affwp_ref';
				break;

			case 'visit':
				$cookie_name = 'affwp_ref_visit_id';
				break;

			case 'campaign':
				$cookie_name = 'affwp_campaign';
				break;

			default:
				/**
				 * Filters the cookie name for custom cookie types.
				 *
				 * @since 2.7.1
				 *
				 * @param string $cookie_name The cookie name.
				 * @param string $cookie_type The cookie type.
				 */
				$cookie_name = apply_filters( 'affwp_get_cookie_name', $cookie_name, $cookie_type );
		}

		// Check if using cookie compat mode.
		if ( $this->cookie_compat_mode && ! empty( $cookie_name ) ) {
			$cookie_name = 'wp-' . $cookie_name;
		}

		return $cookie_name;
	}

	/**
	 * Check if it is a valid affiliate
	 *
	 * @since 1.0
	 */
	public function is_valid_affiliate( $affiliate_id = 0 ) {

		if ( empty( $affiliate_id ) ) {
			$affiliate_id = $this->get_affiliate_id();
		}

		$valid     = false;
		$affiliate = affwp_get_affiliate( $affiliate_id );

		if ( $affiliate ) {

			$is_self = is_user_logged_in() && get_current_user_id() == $affiliate->user_id;
			$active  = 'active' === $affiliate->status;
			$valid   = ! $is_self && $active;
		}

		/**
		 * Filters whether the affiliate for the current referral is valid.
		 *
		 * @since 1.0
		 *
		 * @param bool $valid        Whether the affiliate is valid.
		 * @param int  $affiliate_id Affiliate ID.
		 */
		return apply_filters( 'affwp_tracking_is_valid_affiliate', $valid, $affiliate_id );
	}

	/**
	 * Get the visitor's IP address
	 *
	 * @since 1.0
	 */
	public function get_ip() {

		$ip = affwp_get_trusted_client_ip();

		/**
		 * Filters the IP address for the current visitor.
		 *
		 * @since 1.0
		 *
		 * @param string $ip IP address of the current visitor.
		 */
		return apply_filters( 'affwp_get_ip', $ip );
	}

	/**
	 * Get the current page URL
	 *
	 * @since  1.0
	 * @global $post
	 * @return string $page_url Current page URL
	 */
	public function get_current_page_url() {
		global $post;

		if ( is_front_page() ) {

			$page_url = home_url();

		} else {

			$host = $_SERVER['SERVER_NAME'];
			$home = wp_parse_url( home_url() );

			// SERVER_NAME has no port and the Host header is client-supplied, so a non-standard port comes from the home URL.
			if ( isset( $home['host'], $home['port'] ) && ! in_array( $home['port'], array( 80, 443 ), true ) && 0 === strcasecmp( $home['host'], $host ) ) {
				$host .= ':' . $home['port'];
			}

			$page_url = set_url_scheme( 'http://' . $host . $_SERVER['REQUEST_URI'] );

		}

		/**
		 * Filters the current page URL used as part of the visit record.
		 *
		 * @since 1.0
		 *
		 * @param string $page_url Visit page URL.
		 */
		return apply_filters( 'affwp_get_current_page_url', $page_url );
	}

	/**
	 * Determine if we need to use the fallback tracking method
	 *
	 * @since 1.0
	 */
	public function use_fallback_method() {

		$use_fallback = affiliate_wp()->settings->get( 'tracking_fallback', false );
		$js_works     = (int) get_option( 'affwp_js_works' );
		$use_fallback = $use_fallback || 1 !== $js_works;

		/**
		 * Filters whether to use fallback tracking for the current referral request.
		 *
		 * @since 1.0
		 *
		 * @param bool $use_fallback Whether to use fallback tracking for the current request.
		 */
		return apply_filters( 'affwp_use_fallback_tracking_method', $use_fallback );
	}

	/**
	 * Set whether JS works or not. This is called via ajax.
	 *
	 * @since 1.7
	 */
	public function check_js() {

		update_option( 'affwp_js_works', 1 );

		die( '1' );
	}

	/**
	 * Strips pretty referral bits from pagination links.
	 *
	 * @since 1.9
	 * @access public
	 *
	 * @param string $link Pagination link.
	 * @return string (Maybe) filtered pagination link.
	 */
	public function strip_referral_from_paged_urls( $link ) {
		// Only mess with $link if there's pagination.
		preg_match( '/page\/\d\/?/', $link, $matches );

		if ( ! empty( $matches[0] ) ) {
			$referral_var = $this->get_referral_var();

			// Remove a non-pretty referral ID.
			$link = remove_query_arg( $referral_var, $link );

			// Remove a pretty referral ID or username.
			preg_match( "/\/$referral_var\/(\w+)\//", $link, $pretty_matches );

			if ( ! empty( $pretty_matches[0] ) ) {
				$link = str_replace( $pretty_matches[0], '/', $link );
			}
		}

		return $link;
	}

	/**
	 * Appends the referral variable and value after a redirect.
	 *
	 * @since 2.3
	 *
	 * @param string $location The redirect path.
	 * @param int    $status   The status code.
	 *
	 * @return string The path to redirect to.
	 */
	public function redirect_with_referral_link( $location, $status ) {

		if ( is_admin() ) {
			return $location;
		}

		// Get the referral variable being used in AffiliateWP.
		$referral_var = $this->get_referral_var();

			// Bail early if the location already has the referral var set.
		if ( false !== strpos( $location, '/' . $referral_var . '/' ) ) {
			return $location;
		}

			$path = ! empty( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : '';

		if ( false !== strpos( $path, '/' . $referral_var . '/' ) ) {

			$pieces = explode( '/', str_replace( '?', '/', $path ) );
			$key    = array_search( $referral_var, $pieces );

			$pieces[ $key + 1 ] = strtolower( sanitize_user( $pieces[ $key + 1 ] ) );

			if ( $key ) {

				$key         += 1;
				$affiliate_id = isset( $pieces[ $key ] ) ? $pieces[ $key ] : false;

				// Append the referral variable and value to the URL after the redirect.
				$processed_location  = trailingslashit( strtok( $location, '?' ) );
				$processed_location .= trailingslashit( $referral_var );
				$processed_location .= trailingslashit( $affiliate_id );

				// If the location has a querystring, append that to the URL.
				$querystring_position = strpos( $location, '?' );
				if ( false !== $querystring_position ) {
					$processed_location .= substr( $location, $querystring_position );
				}

				$location = $processed_location;
			}
		} elseif ( isset( $_GET[ $referral_var ] ) ) {

			// Append the referral variable and value to the URL after the redirect.
			$location = add_query_arg( $referral_var, $_GET[ $referral_var ], $location );

		}

		return $location;
	}

	/**
	 * Writes a debug log message.
	 *
	 * @access private
	 * @since  1.8
	 * @deprecated 2.0.2 Use affiliate_wp()->utils->log() instead
	 *
	 * @see affiliate_wp()->utils->log()
	 */
	private function log( $message = '' ) {
		_deprecated_function( __METHOD__, '2.0.2', 'affiliate_wp()->utils->log()' );

		affiliate_wp()->utils->log( $message );
	}
}
