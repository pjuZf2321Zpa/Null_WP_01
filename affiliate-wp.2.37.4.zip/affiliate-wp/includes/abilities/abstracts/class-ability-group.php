<?php
/**
 * Abilities API: base ability group.
 *
 * @package     AffiliateWP
 * @subpackage  Abilities
 * @copyright   Copyright (c) 2026, Awesome Motive, Inc.
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.37.0
 */

namespace AffWP\Abilities;

/**
 * Shared helpers for a set of related abilities.
 *
 * @since 2.37.0
 */
abstract class Ability_Group {

	/**
	 * Largest page size an ability returns in one call.
	 *
	 * @since 2.37.0
	 * @var int
	 */
	const MAX_NUMBER = 100;

	/**
	 * Calendar date in YYYY-MM-DD format.
	 *
	 * @since 2.37.0
	 *
	 * @var string
	 */
	const DATE_PATTERN = '^\\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12]\\d|3[01])$';

	/**
	 * Retrieves ability definitions keyed by unprefixed name.
	 *
	 * @since 2.37.0
	 *
	 * @return array<string, array>
	 */
	abstract public function get_definitions();

	/**
	 * Builds a read-only ability definition.
	 *
	 * @since 2.37.0
	 *
	 * @param array $args Ability arguments without `meta`.
	 * @return array
	 */
	protected function read( array $args ) {
		return $this->with_meta( $args, true, false, true, true );
	}

	/**
	 * Builds a write ability definition.
	 *
	 * @since 2.37.0
	 *
	 * @param array $args        Ability arguments without `meta`.
	 * @param bool  $destructive Whether the ability changes or removes existing data.
	 * @param bool  $idempotent  Whether repeating the call with the same input has no extra effect.
	 * @return array
	 */
	protected function write( array $args, $destructive, $idempotent ) {
		$permission = $args['permission_callback'];

		/*
		 * Writes stay registered but are hidden from MCP and refused until the admin turns write
		 * access on. Core treats a WP_Error here as a bug, so the reason is added via
		 * Abilities::explain_write_denial() instead.
		 */
		$args['permission_callback'] = static function ( $input = null ) use ( $permission ) {
			return Abilities::write_enabled() && call_user_func( $permission, $input );
		};

		return $this->with_meta( $args, false, $destructive, $idempotent, Abilities::write_enabled() );
	}

	/**
	 * Adds the `meta` block to an ability definition.
	 *
	 * `show_in_rest` is set explicitly because WordPress 6.9 has no `public` flag, and `mcp.public`
	 * is what the MCP Adapter reads.
	 *
	 * @since 2.37.0
	 *
	 * @param array $args        Ability arguments.
	 * @param bool  $readonly    Readonly annotation.
	 * @param bool  $destructive Destructive annotation.
	 * @param bool  $idempotent  Idempotent annotation.
	 * @param bool  $mcp_public  Whether MCP clients may see the ability.
	 * @return array
	 */
	private function with_meta( array $args, $readonly, $destructive, $idempotent, $mcp_public ) {
		$args['meta'] = array(
			'public'       => true,
			'show_in_rest' => true,
			'annotations'  => array(
				'readonly'    => $readonly,
				'destructive' => $destructive,
				'idempotent'  => $idempotent,
			),
			'mcp'          => array(
				'public' => (bool) $mcp_public,
			),
		);

		return $args;
	}

	/**
	 * Returns a permission callback for one AffiliateWP capability.
	 *
	 * @since 2.37.0
	 *
	 * @param string $capability Capability name.
	 * @return callable
	 */
	protected function can( $capability ) {
		return static function () use ( $capability ) {
			return current_user_can( $capability );
		};
	}

	/**
	 * Wraps object properties in an object input schema.
	 *
	 * Defaults to an empty object so a call with no input still validates.
	 * An empty `properties` list is stored as an empty object so JSON encoding
	 * emits `{}` rather than `[]`, which MCP clients reject.
	 *
	 * @since 2.37.0
	 *
	 * @param array $properties Property schemas.
	 * @param array $required   Required property names.
	 * @return array
	 */
	protected function object_schema( array $properties, array $required = array() ) {
		$empty = array() === $properties;

		$schema = array(
			'type'                 => 'object',
			'properties'           => $empty ? new \stdClass() : $properties,
			'additionalProperties' => false,
		);

		if ( ! empty( $required ) ) {
			$schema['required'] = $required;
		} else {
			$schema['default'] = $empty ? new \stdClass() : array();
		}

		return $schema;
	}

	/**
	 * Pagination property schemas shared by list abilities.
	 *
	 * @since 2.37.0
	 *
	 * @return array
	 */
	protected function pagination_properties() {
		return array(
			'number' => array(
				'type'        => 'integer',
				'description' => __( 'How many records to return.', 'affiliate-wp' ),
				'default'     => 20,
				'minimum'     => 1,
				'maximum'     => self::MAX_NUMBER,
			),
			'offset' => array(
				'type'        => 'integer',
				'description' => __( 'How many records to skip, for paging.', 'affiliate-wp' ),
				'default'     => 0,
				'minimum'     => 0,
			),
		);
	}

	/**
	 * Sort property schemas shared by list abilities.
	 *
	 * @since 2.37.0
	 *
	 * @param array  $orderby_options Allowed orderby values.
	 * @param string $default_orderby Default orderby value.
	 * @return array
	 */
	protected function sort_properties( array $orderby_options, $default_orderby ) {
		return array(
			'orderby' => array(
				'type'        => 'string',
				'description' => __( 'Column to sort by.', 'affiliate-wp' ),
				'enum'        => $orderby_options,
				'default'     => $default_orderby,
			),
			'order'   => array(
				'type'        => 'string',
				'description' => __( 'Sort direction.', 'affiliate-wp' ),
				'enum'        => array( 'ASC', 'DESC' ),
				'default'     => 'DESC',
			),
		);
	}

	/**
	 * Date range property schema shared by list and summary abilities.
	 *
	 * @since 2.37.0
	 *
	 * @param string $description What the range filters.
	 * @return array
	 */
	protected function date_range_property( $description ) {
		return array(
			'type'                 => 'object',
			'description'          => $description,
			'properties'           => array(
				'start' => array(
					'type'        => 'string',
					'description' => __( 'Inclusive start date in YYYY-MM-DD format.', 'affiliate-wp' ),
					'pattern'     => self::DATE_PATTERN,
				),
				'end'   => array(
					'type'        => 'string',
					'description' => __( 'Inclusive end date in YYYY-MM-DD format.', 'affiliate-wp' ),
					'pattern'     => self::DATE_PATTERN,
				),
			),
			'additionalProperties' => false,
		);
	}

	/**
	 * Schema for a list result: total count plus items.
	 *
	 * @since 2.37.0
	 *
	 * @param string $items_key   Key holding the items.
	 * @param array  $item_schema Schema for one item.
	 * @return array
	 */
	protected function list_schema( $items_key, array $item_schema ) {
		return array(
			'type'       => 'object',
			'properties' => array(
				'total'    => array(
					'type'        => 'integer',
					'description' => __( 'Total records matching the filters, ignoring paging.', 'affiliate-wp' ),
				),
				$items_key => array(
					'type'  => 'array',
					'items' => $item_schema,
				),
			),
			'required'   => array( 'total', $items_key ),
		);
	}

	/**
	 * Copies pagination, sorting, and date range input into query arguments.
	 *
	 * @since 2.37.0
	 *
	 * @param array $input Ability input.
	 * @return array Query arguments.
	 */
	protected function base_query_args( array $input ) {
		$args = array(
			'number' => isset( $input['number'] ) ? min( absint( $input['number'] ), self::MAX_NUMBER ) : 20,
			'offset' => isset( $input['offset'] ) ? absint( $input['offset'] ) : 0,
		);

		if ( ! empty( $input['orderby'] ) ) {
			$args['orderby'] = sanitize_key( $input['orderby'] );
		}

		if ( ! empty( $input['order'] ) ) {
			$args['order'] = 'ASC' === strtoupper( $input['order'] ) ? 'ASC' : 'DESC';
		}

		if ( ! empty( $input['date'] ) && is_array( $input['date'] ) ) {
			$args['date'] = array_filter(
				array(
					'start' => isset( $input['date']['start'] ) ? sanitize_text_field( $input['date']['start'] ) : '',
					'end'   => isset( $input['date']['end'] ) ? sanitize_text_field( $input['date']['end'] ) : '',
				)
			);
		}

		return $args;
	}

	/**
	 * Affiliate identifier properties shared by get, update, and performance abilities.
	 *
	 * @since 2.37.0
	 *
	 * @return array
	 */
	protected function affiliate_identifier_properties() {
		return array(
			'affiliate_id' => array(
				'type'        => 'integer',
				'description' => __( 'Affiliate ID.', 'affiliate-wp' ),
				'minimum'     => 1,
			),
			'username'     => array(
				'type'        => 'string',
				'description' => __( 'WordPress username of the affiliate. Used when affiliate_id is not given.', 'affiliate-wp' ),
			),
			'email'        => array(
				'type'        => 'string',
				'description' => __( 'Account email of the affiliate. Used when neither affiliate_id nor username is given.', 'affiliate-wp' ),
				'format'      => 'email',
			),
		);
	}

	/**
	 * Date range from ability input, or an empty string when none was given.
	 *
	 * @since 2.37.0
	 *
	 * @param array $input Ability input.
	 * @return array|string
	 */
	protected function date_arg( array $input ) {
		$args = $this->base_query_args( $input );

		return ! empty( $args['date'] ) ? $args['date'] : '';
	}

	/**
	 * Referral, earnings, and visit totals for one affiliate, optionally in a date range.
	 *
	 * @since 2.37.0
	 *
	 * @param int          $affiliate_id Affiliate ID.
	 * @param array|string $date         Date range or empty for all time.
	 * @return array
	 */
	protected function period_stats( $affiliate_id, $date = '' ) {
		$referral_args = array( 'affiliate_id' => absint( $affiliate_id ) );
		$visit_args    = array( 'affiliate_id' => absint( $affiliate_id ) );

		if ( ! empty( $date ) ) {
			$referral_args['date'] = $date;
			$visit_args['date']    = $date;
		}

		$referrals = array(
			'total' => (int) affiliate_wp()->referrals->count( $referral_args ),
		);

		foreach ( array( 'paid', 'unpaid', 'pending', 'rejected' ) as $status ) {
			$referrals[ $status ] = (int) affiliate_wp()->referrals->count( array_merge( $referral_args, array( 'status' => $status ) ) );
		}

		$visits    = (int) affiliate_wp()->visits->count( $visit_args );
		$converted = (int) affiliate_wp()->visits->count( array_merge( $visit_args, array( 'referral_status' => 'converted' ) ) );

		return array(
			'referrals' => $referrals,
			'earnings'  => array(
				'paid'   => Formatter::amount( affiliate_wp()->referrals->paid_earnings( $date, $affiliate_id, false ) ),
				'unpaid' => Formatter::amount( affiliate_wp()->referrals->unpaid_earnings( $date, $affiliate_id, false ) ),
			),
			'visits'    => array(
				'total'           => $visits,
				'converted'       => $converted,
				'conversion_rate' => $visits > 0 ? round( ( $converted / $visits ) * 100, 2 ) : 0.0,
			),
		);
	}

	/**
	 * Resolves the affiliate group ID for an affiliate.
	 *
	 * @since 2.37.0
	 *
	 * @param int $affiliate_id Affiliate ID.
	 * @return int Group ID, or 0 when the affiliate is not in a group.
	 */
	protected function affiliate_group_id( $affiliate_id ) {
		try {
			$group_id = affwp_get_affiliate_group_id( (int) $affiliate_id );
		} catch ( \Exception $e ) {
			return 0;
		}

		return $group_id ? (int) $group_id : 0;
	}

	/**
	 * Resolves an affiliate from an ID, username, or email in ability input.
	 *
	 * @since 2.37.0
	 *
	 * @param array $input Ability input with optional `affiliate_id`, `username`, or `email`.
	 * @return \AffWP\Affiliate|\WP_Error
	 */
	protected function resolve_affiliate( array $input ) {
		if ( ! empty( $input['affiliate_id'] ) ) {
			$affiliate = affwp_get_affiliate( absint( $input['affiliate_id'] ) );

			return $affiliate ? $affiliate : $this->not_found( __( 'No affiliate exists with that ID.', 'affiliate-wp' ) );
		}

		if ( ! empty( $input['username'] ) ) {
			$user = get_user_by( 'login', sanitize_user( $input['username'] ) );
		} elseif ( ! empty( $input['email'] ) ) {
			$user = get_user_by( 'email', sanitize_email( $input['email'] ) );
		} else {
			return $this->invalid( 'affwp_ability_missing_identifier', __( 'Provide an affiliate_id, username, or email.', 'affiliate-wp' ) );
		}

		$affiliate = $user ? affwp_get_affiliate_by( 'user_id', $user->ID ) : false;

		if ( ! $affiliate || is_wp_error( $affiliate ) ) {
			return $this->not_found( __( 'No affiliate matches that user.', 'affiliate-wp' ) );
		}

		return $affiliate;
	}

	/**
	 * Builds a not-found error.
	 *
	 * @since 2.37.0
	 *
	 * @param string $message Error message.
	 * @return \WP_Error
	 */
	protected function not_found( $message ) {
		return new \WP_Error( 'affwp_ability_not_found', $message, array( 'status' => 404 ) );
	}

	/**
	 * Builds an error for a request the caller has to change, so clients do not read it as a server fault.
	 *
	 * @since 2.37.0
	 *
	 * @param string $code    Error code.
	 * @param string $message Error message.
	 * @param int    $status  HTTP status. Default 400.
	 * @return \WP_Error
	 */
	protected function invalid( $code, $message, $status = 400 ) {
		return new \WP_Error( $code, $message, array( 'status' => $status ) );
	}
}
