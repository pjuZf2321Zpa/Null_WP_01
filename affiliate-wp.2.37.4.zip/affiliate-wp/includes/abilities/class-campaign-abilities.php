<?php
/**
 * Abilities API: campaigns.
 *
 * @package     AffiliateWP
 * @subpackage  Abilities
 * @copyright   Copyright (c) 2026, Awesome Motive, Inc.
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.37.0
 */

namespace AffWP\Abilities;

/**
 * Abilities for reading campaign performance.
 *
 * @since 2.37.0
 */
class Campaign_Abilities extends Ability_Group {

	/**
	 * {@inheritDoc}
	 */
	public function get_definitions() {
		return array(
			'list-campaigns' => $this->read(
				array(
					'label'               => __( 'List campaigns', 'affiliate-wp' ),
					'description'         => __( 'Lists lifetime campaign performance: visits, unique visits, referrals, conversion rate, and earnings. Each row is one campaign slug for one affiliate. Filter by affiliate or campaign slug, and sort by visits, referrals, or conversion rate. Use this to see which campaigns convert. Date-scoped campaign stats are not stored; filter list-visits or list-referrals by campaign for a date range.', 'affiliate-wp' ),
					'permission_callback' => $this->can( 'view_affiliate_reports' ),
					'execute_callback'    => array( $this, 'list_campaigns' ),
					'input_schema'        => $this->object_schema(
						array_merge(
							array(
								'affiliate_id' => array(
									'type'        => 'integer',
									'description' => __( 'Only campaigns for this affiliate.', 'affiliate-wp' ),
									'minimum'     => 1,
								),
								'campaign'     => array(
									'type'        => 'string',
									'description' => __( 'Only this campaign slug, e.g. spring-sale.', 'affiliate-wp' ),
								),
							),
							$this->sort_properties( array( 'visits', 'unique_visits', 'referrals', 'conversion_rate', 'affiliate_id', 'campaign_id' ), 'visits' ),
							$this->pagination_properties()
						)
					),
					'output_schema'       => $this->list_schema( 'campaigns', Formatter::campaign_schema() ),
				)
			),
		);
	}

	/**
	 * Lists campaigns.
	 *
	 * @since 2.37.0
	 *
	 * @param array|null $input Ability input.
	 * @return array
	 */
	public function list_campaigns( $input = null ) {
		$input = is_array( $input ) ? $input : array();
		$args  = $this->base_query_args( $input );

		if ( empty( $input['orderby'] ) ) {
			$args['orderby'] = 'visits';
		}

		if ( ! empty( $input['affiliate_id'] ) ) {
			$args['affiliate_id'] = absint( $input['affiliate_id'] );
		}

		if ( ! empty( $input['campaign'] ) ) {
			$args['campaign'] = sanitize_text_field( $input['campaign'] );
		}

		$campaigns = affiliate_wp()->campaigns->get_campaigns( $args );
		$total     = affiliate_wp()->campaigns->count( array_diff_key( $args, array_flip( array( 'number', 'offset', 'orderby', 'order' ) ) ) );
		$items     = array();

		foreach ( (array) $campaigns as $campaign ) {
			if ( ! $campaign instanceof \AffWP\Campaign ) {
				continue;
			}

			$items[] = Formatter::campaign( $campaign, $this->campaign_earnings( $campaign ) );
		}

		return array(
			'total'     => (int) $total,
			'campaigns' => $items,
		);
	}

	/**
	 * Sums paid and unpaid referral amounts for a campaign.
	 *
	 * @since 2.37.0
	 *
	 * @param \AffWP\Campaign $campaign Campaign object.
	 * @return float
	 */
	private function campaign_earnings( $campaign ) {
		if ( empty( $campaign->campaign ) ) {
			return 0.0;
		}

		$rows = affiliate_wp()->referrals->get_referrals(
			array(
				'affiliate_id' => (int) $campaign->affiliate_id,
				'campaign'     => $campaign->campaign,
				'status'       => array( 'paid', 'unpaid' ),
				'fields'       => array( 'affiliate_id' ),
				'sum_fields'   => array( 'amount' ),
				'number'       => 1,
			)
		);

		if ( empty( $rows[0] ) || ! isset( $rows[0]->amount_sum ) ) {
			return 0.0;
		}

		return Formatter::amount( $rows[0]->amount_sum );
	}
}
