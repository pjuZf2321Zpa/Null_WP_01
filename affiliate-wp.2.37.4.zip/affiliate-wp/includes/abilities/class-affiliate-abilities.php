<?php
/**
 * Abilities API: affiliates.
 *
 * @package     AffiliateWP
 * @subpackage  Abilities
 * @copyright   Copyright (c) 2026, Awesome Motive, Inc.
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.37.0
 */

namespace AffWP\Abilities;

/**
 * Abilities for reading and managing affiliates.
 *
 * @since 2.37.0
 */
class Affiliate_Abilities extends Ability_Group {

	/**
	 * {@inheritDoc}
	 */
	public function get_definitions() {
		$statuses   = array_keys( affwp_get_affiliate_statuses() );
		$identifier = $this->affiliate_identifier_properties();
		$name       = array(
			'first_name' => array(
				'type'        => 'string',
				'description' => __( 'First name on the affiliate\'s WordPress account.', 'affiliate-wp' ),
			),
			'last_name'  => array(
				'type'        => 'string',
				'description' => __( 'Last name on the affiliate\'s WordPress account.', 'affiliate-wp' ),
			),
		);

		return array(
			'list-affiliates'      => $this->read(
				array(
					'label'               => __( 'List affiliates', 'affiliate-wp' ),
					'description'         => __( 'Lists affiliates with their status, rate, earnings, referral and visit counts, and referral URL. Filter by status, search by name or email, and page through results.', 'affiliate-wp' ),
					'permission_callback' => $this->can( 'manage_affiliates' ),
					'execute_callback'    => array( $this, 'list_affiliates' ),
					'input_schema'        => $this->object_schema(
						array_merge(
							array(
								'search' => array(
									'type'        => 'string',
									'description' => __( 'Match against the affiliate name, username, or email.', 'affiliate-wp' ),
								),
								'status' => array(
									'type'        => 'string',
									'description' => __( 'Only affiliates with this status.', 'affiliate-wp' ),
									'enum'        => $statuses,
								),
								'date'   => $this->date_range_property( __( 'Only affiliates registered in this date range.', 'affiliate-wp' ) ),
							),
							$this->sort_properties( array( 'affiliate_id', 'date', 'status', 'earnings', 'unpaid_earnings', 'referrals', 'visits', 'name', 'username' ), 'affiliate_id' ),
							$this->pagination_properties()
						)
					),
					'output_schema'       => $this->list_schema( 'affiliates', Formatter::affiliate_schema() ),
				)
			),
			'get-affiliate'        => $this->read(
				array(
					'label'               => __( 'Get affiliate', 'affiliate-wp' ),
					'description'         => __( 'Returns one affiliate by ID, username, or email, including their rate, group, notes, lifetime earnings, counts, and referral URL.', 'affiliate-wp' ),
					'permission_callback' => $this->can( 'manage_affiliates' ),
					'execute_callback'    => array( $this, 'get_affiliate' ),
					'input_schema'        => $this->object_schema( $identifier ),
					'output_schema'       => Formatter::affiliate_schema(),
				)
			),
			'get-affiliate-performance' => $this->read(
				array(
					'label'               => __( 'Get affiliate performance', 'affiliate-wp' ),
					'description'         => __( 'Returns one affiliate plus their referrals, paid and unpaid earnings, visits, and conversion rate. Optionally limited to a date range. Use this to answer how an affiliate did this week or this month. Lifetime totals stay on get-affiliate.', 'affiliate-wp' ),
					'permission_callback' => $this->can( 'manage_affiliates' ),
					'execute_callback'    => array( $this, 'get_performance' ),
					'input_schema'        => $this->object_schema(
						array_merge(
							$identifier,
							array(
								'date' => $this->date_range_property( __( 'Limit referrals, earnings, and visits to this date range. Omit for all time.', 'affiliate-wp' ) ),
							)
						)
					),
					'output_schema'       => array(
						'type'       => 'object',
						'properties' => array(
							'affiliate' => Formatter::affiliate_schema(),
							'period'    => Formatter::period_stats_schema(),
						),
					),
				)
			),
			'list-affiliate-coupons' => $this->read(
				array(
					'label'               => __( 'List affiliate coupons', 'affiliate-wp' ),
					'description'         => __( 'Lists the coupon codes that credit one affiliate, with the discount each gives and its integration. Covers coupons assigned by hand and coupons AffiliateWP generates. Coupons only come from integrations that are on, and the result names any that are off.', 'affiliate-wp' ),
					'permission_callback' => $this->can( 'manage_affiliates' ),
					'execute_callback'    => array( $this, 'list_coupons' ),
					'input_schema'        => $this->object_schema( $identifier ),
					'output_schema'       => array(
						'type'       => 'object',
						'properties' => array(
							'affiliate_id'          => array( 'type' => 'integer' ),
							'total'                 => array( 'type' => 'integer' ),
							'coupons'               => array(
								'type'  => 'array',
								'items' => Formatter::coupon_schema(),
							),
							'disabled_integrations' => array(
								'type'        => 'array',
								'description' => __( 'Integrations that can provide coupons but are turned off in AffiliateWP, so their coupons are not listed.', 'affiliate-wp' ),
								'items'       => array( 'type' => 'string' ),
							),
							'notice'                => array(
								'type'        => 'string',
								'description' => __( 'Tell the user this when it is not empty.', 'affiliate-wp' ),
							),
						),
					),
				)
			),
			'list-top-affiliates'  => $this->read(
				array(
					'label'               => __( 'List top affiliates', 'affiliate-wp' ),
					'description'         => __( 'Ranks affiliates by earnings in a date range, with their referrals and visits for the same period. Use this to answer who earned the most this month. Without a date range, it ranks by lifetime paid earnings.', 'affiliate-wp' ),
					'permission_callback' => $this->can( 'manage_affiliates' ),
					'execute_callback'    => array( $this, 'list_top_affiliates' ),
					'input_schema'        => $this->object_schema(
						array_merge(
							array(
								'status' => array(
									'type'        => 'string',
									'description' => __( 'Only affiliates with this status.', 'affiliate-wp' ),
									'enum'        => $statuses,
								),
								'date'   => $this->date_range_property( __( 'Rank by earnings in this date range. Omit to rank by lifetime paid earnings.', 'affiliate-wp' ) ),
							),
							$this->pagination_properties()
						)
					),
					'output_schema'       => $this->list_schema(
						'affiliates',
						array(
							'type'       => 'object',
							'properties' => array(
								'affiliate_id'    => array( 'type' => 'integer' ),
								'name'            => array( 'type' => 'string' ),
								'username'        => array( 'type' => 'string' ),
								'email'           => array( 'type' => 'string' ),
								'status'          => array( 'type' => 'string' ),
								'earnings'        => array(
									'type'        => 'number',
									'description' => __( 'Lifetime paid earnings. Ranks the list when no date range is given.', 'affiliate-wp' ),
								),
								'unpaid_earnings' => array(
									'type'        => 'number',
									'description' => __( 'Lifetime unpaid earnings.', 'affiliate-wp' ),
								),
								'period'          => Formatter::period_stats_schema(),
							),
						)
					),
				)
			),
			'list-affiliate-groups' => $this->read(
				array(
					'label'               => __( 'List affiliate groups', 'affiliate-wp' ),
					'description'         => __( 'Lists affiliate groups, including any group rate that overrides the program default and how many affiliates are in each group.', 'affiliate-wp' ),
					'permission_callback' => $this->can( 'manage_affiliates' ),
					'execute_callback'    => array( $this, 'list_groups' ),
					'input_schema'        => $this->object_schema(
						array_merge(
							array(
								'search' => array(
									'type'        => 'string',
									'description' => __( 'Match against the group name.', 'affiliate-wp' ),
								),
							),
							$this->pagination_properties()
						)
					),
					'output_schema'       => $this->list_schema( 'groups', Formatter::affiliate_group_schema() ),
				)
			),
			'add-affiliate'        => $this->write(
				array(
					'label'               => __( 'Add affiliate', 'affiliate-wp' ),
					'description'         => __( 'Registers an existing WordPress user as an affiliate, or creates a new user from an email address and registers them. Pass first_name and last_name to name the affiliate. Percentage rates use the percent value, e.g. 20 for 20%. Fails if the user is already an affiliate.', 'affiliate-wp' ),
					'permission_callback' => $this->can( 'manage_affiliates' ),
					'execute_callback'    => array( $this, 'add_affiliate' ),
					'input_schema'        => $this->object_schema(
						$name + array(
							'user_id'         => array(
								'type'        => 'integer',
								'description' => __( 'Existing WordPress user ID to register as an affiliate.', 'affiliate-wp' ),
								'minimum'     => 1,
							),
							'email'           => array(
								'type'        => 'string',
								'description' => __( 'Email of the user to register. If no user has this email, a new user is created.', 'affiliate-wp' ),
								'format'      => 'email',
							),
							'status'          => array(
								'type'        => 'string',
								'description' => __( 'Initial status.', 'affiliate-wp' ),
								'enum'        => $statuses,
								'default'     => 'active',
							),
							'rate'            => array(
								'type'        => 'string',
								'description' => __( 'Custom referral rate, e.g. 20 for 20% or 5 for a flat 5.00. Leave empty to use the program default.', 'affiliate-wp' ),
							),
							'rate_type'       => array(
								'type'        => 'string',
								'description' => __( 'Custom rate type. Leave empty to use the program default.', 'affiliate-wp' ),
								'enum'        => array_keys( affwp_get_affiliate_rate_types() ),
							),
							'payment_email'   => array(
								'type'        => 'string',
								'description' => __( 'Payment email, if different from the account email.', 'affiliate-wp' ),
								'format'      => 'email',
							),
							'notes'           => array(
								'type'        => 'string',
								'description' => __( 'Private admin notes about the affiliate.', 'affiliate-wp' ),
							),
							'send_welcome_email' => array(
								'type'        => 'boolean',
								'description' => __( 'Send the affiliate welcome email.', 'affiliate-wp' ),
								'default'     => false,
							),
						)
					),
					'output_schema'       => Formatter::affiliate_schema(),
				),
				false,
				false
			),
			'set-affiliate-status' => $this->write(
				array(
					'label'               => __( 'Set affiliate status', 'affiliate-wp' ),
					'description'         => __( 'Changes an affiliate\'s status. Use active to approve a pending application, rejected to decline it, and inactive to pause an affiliate without deleting them.', 'affiliate-wp' ),
					'permission_callback' => $this->can( 'manage_affiliates' ),
					'execute_callback'    => array( $this, 'set_status' ),
					'input_schema'        => $this->object_schema(
						array_merge(
							$identifier,
							array(
								'status' => array(
									'type'        => 'string',
									'description' => __( 'New status.', 'affiliate-wp' ),
									'enum'        => $statuses,
								),
							)
						),
						array( 'status' )
					),
					'output_schema'       => array(
						'type'       => 'object',
						'properties' => array(
							'affiliate_id'    => array( 'type' => 'integer' ),
							'previous_status' => array( 'type' => 'string' ),
							'status'          => array( 'type' => 'string' ),
						),
					),
				),
				true,
				true
			),
			'update-affiliate'     => $this->write(
				array(
					'label'               => __( 'Update affiliate', 'affiliate-wp' ),
					'description'         => __( 'Updates an affiliate\'s first or last name, personal referral rate, rate type, payment email, admin notes, or affiliate group. Percentage rates use the percent value, e.g. 20 for 20%. Leave rate empty to fall back to the program default. Set group_id to 0 to remove the affiliate from their group. Use set-affiliate-status to approve, reject, or pause.', 'affiliate-wp' ),
					'permission_callback' => $this->can( 'manage_affiliates' ),
					'execute_callback'    => array( $this, 'update_affiliate' ),
					'input_schema'        => $this->object_schema(
						array_merge(
							$identifier,
							$name,
							array(
								'rate'          => array(
									'type'        => 'string',
									'description' => __( 'Personal referral rate, e.g. 20 for 20%. Empty string clears it so the program default applies.', 'affiliate-wp' ),
								),
								'rate_type'     => array(
									'type'        => 'string',
									'description' => __( 'Personal rate type. Empty string clears it so the program default applies.', 'affiliate-wp' ),
									'enum'        => array_merge( array( '' ), array_keys( affwp_get_affiliate_rate_types() ) ),
								),
								'payment_email' => array(
									'type'        => 'string',
									'description' => __( 'Payment email, if different from the account email.', 'affiliate-wp' ),
									'format'      => 'email',
								),
								'notes'         => array(
									'type'        => 'string',
									'description' => __( 'Private admin notes. Replaces the existing notes.', 'affiliate-wp' ),
								),
								'group_id'      => array(
									'type'        => 'integer',
									'description' => __( 'Affiliate group to assign. 0 removes the affiliate from their current group.', 'affiliate-wp' ),
									'minimum'     => 0,
								),
							)
						)
					),
					'output_schema'       => Formatter::affiliate_schema(),
				),
				true,
				true
			),
		);
	}

	/**
	 * Lists affiliates.
	 *
	 * @since 2.37.0
	 *
	 * @param array|null $input Ability input.
	 * @return array
	 */
	public function list_affiliates( $input = null ) {
		$input = is_array( $input ) ? $input : array();
		$args  = $this->base_query_args( $input );

		if ( ! empty( $input['search'] ) ) {
			$args['search'] = sanitize_text_field( $input['search'] );
		}

		if ( ! empty( $input['status'] ) ) {
			$args['status'] = sanitize_key( $input['status'] );
		}

		$affiliates = affiliate_wp()->affiliates->get_affiliates( $args );
		$total      = affiliate_wp()->affiliates->count( array_diff_key( $args, array_flip( array( 'number', 'offset', 'orderby', 'order' ) ) ) );

		return array(
			'total'      => (int) $total,
			'affiliates' => array_map( array( Formatter::class, 'affiliate' ), $affiliates ),
		);
	}

	/**
	 * Gets one affiliate.
	 *
	 * @since 2.37.0
	 *
	 * @param array|null $input Ability input.
	 * @return array|\WP_Error
	 */
	public function get_affiliate( $input = null ) {
		$affiliate = $this->resolve_affiliate( is_array( $input ) ? $input : array() );

		return is_wp_error( $affiliate ) ? $affiliate : Formatter::affiliate( $affiliate );
	}

	/**
	 * Adds an affiliate.
	 *
	 * @since 2.37.0
	 *
	 * @param array|null $input Ability input.
	 * @return array|\WP_Error
	 */
	public function add_affiliate( $input = null ) {
		$input = is_array( $input ) ? $input : array();
		$data  = array(
			'status'              => ! empty( $input['status'] ) ? sanitize_key( $input['status'] ) : 'active',
			'rate'                => isset( $input['rate'] ) ? $input['rate'] : '',
			'rate_type'           => isset( $input['rate_type'] ) ? $input['rate_type'] : '',
			'payment_email'       => isset( $input['payment_email'] ) ? $input['payment_email'] : '',
			'notes'               => isset( $input['notes'] ) ? $input['notes'] : '',
			'registration_method' => 'abilities_api',
		);

		if ( ! empty( $input['user_id'] ) ) {
			$user = get_user_by( 'id', absint( $input['user_id'] ) );
		} elseif ( ! empty( $input['email'] ) ) {
			$user = get_user_by( 'email', sanitize_email( $input['email'] ) );

			if ( ! $user ) {
				$data['user_email'] = sanitize_email( $input['email'] );
			}
		} else {
			return $this->invalid( 'affwp_ability_missing_identifier', __( 'Provide a user_id or an email.', 'affiliate-wp' ) );
		}

		if ( ! empty( $input['user_id'] ) && ! $user ) {
			return $this->not_found( __( 'No user exists with that ID.', 'affiliate-wp' ) );
		}

		$name = $this->user_name_fields( $input, $user ? $user : null );

		if ( $user ) {
			if ( affwp_is_affiliate( $user->ID ) ) {
				return $this->invalid( 'affwp_ability_already_affiliate', __( 'That user is already an affiliate.', 'affiliate-wp' ), 409 );
			}

			$renamed = $this->update_user_name( $user->ID, $name );

			if ( is_wp_error( $renamed ) ) {
				return $renamed;
			}

			$data['user_id'] = $user->ID;
		}

		$add_name = static function ( $user_args ) use ( $name ) {
			return array_merge( $user_args, $name );
		};

		add_filter( 'affwp_add_affiliate_user_args', $add_name );

		// The approval email only checks the admin form's POST data, so suppress it here instead.
		$suppress_email = empty( $input['send_welcome_email'] );

		if ( $suppress_email ) {
			add_filter( 'affwp_notify_on_approval', '__return_false', 99 );
		}

		$affiliate_id = affwp_add_affiliate( $data );

		remove_filter( 'affwp_add_affiliate_user_args', $add_name );

		if ( $suppress_email ) {
			remove_filter( 'affwp_notify_on_approval', '__return_false', 99 );
		}

		if ( ! $affiliate_id ) {
			return new \WP_Error( 'affwp_ability_add_failed', __( 'The affiliate could not be added.', 'affiliate-wp' ) );
		}

		return Formatter::affiliate( affwp_get_affiliate( $affiliate_id ) );
	}

	/**
	 * Sets an affiliate's status.
	 *
	 * @since 2.37.0
	 *
	 * @param array|null $input Ability input.
	 * @return array|\WP_Error
	 */
	public function set_status( $input = null ) {
		$input     = is_array( $input ) ? $input : array();
		$affiliate = $this->resolve_affiliate( $input );

		if ( is_wp_error( $affiliate ) ) {
			return $affiliate;
		}

		$previous = $affiliate->status;
		$status   = sanitize_key( $input['status'] );

		if ( $previous !== $status && ! affwp_set_affiliate_status( $affiliate, $status ) ) {
			return new \WP_Error( 'affwp_ability_status_failed', __( 'The affiliate status could not be changed.', 'affiliate-wp' ) );
		}

		return array(
			'affiliate_id'    => (int) $affiliate->ID,
			'previous_status' => (string) $previous,
			'status'          => $status,
		);
	}

	/**
	 * Returns one affiliate with period-scoped performance.
	 *
	 * @since 2.37.0
	 *
	 * @param array|null $input Ability input.
	 * @return array|\WP_Error
	 */
	public function get_performance( $input = null ) {
		$input     = is_array( $input ) ? $input : array();
		$affiliate = $this->resolve_affiliate( $input );

		if ( is_wp_error( $affiliate ) ) {
			return $affiliate;
		}

		return array(
			'affiliate' => Formatter::affiliate( $affiliate ),
			'period'    => $this->period_stats( $affiliate->ID, $this->date_arg( $input ) ),
		);
	}

	/**
	 * Lists the coupons that credit one affiliate.
	 *
	 * @since 2.37.0
	 *
	 * @param array|null $input Ability input.
	 * @return array|\WP_Error
	 */
	public function list_coupons( $input = null ) {
		$affiliate = $this->resolve_affiliate( is_array( $input ) ? $input : array() );

		if ( is_wp_error( $affiliate ) ) {
			return $affiliate;
		}

		$coupons = array();

		foreach ( affwp_get_affiliate_coupons( $affiliate ) as $type => $type_coupons ) {
			foreach ( (array) $type_coupons as $coupon_id => $details ) {
				if ( is_array( $details ) && ! empty( $details['code'] ) ) {
					$coupons[] = Formatter::coupon( $coupon_id, $type, $details );
				}
			}
		}

		$disabled = $this->disabled_coupon_integrations();

		return array(
			'affiliate_id'          => (int) $affiliate->ID,
			'total'                 => count( $coupons ),
			'coupons'               => $coupons,
			'disabled_integrations' => $disabled,
			'notice'                => $disabled
				? sprintf(
					/* translators: %s: comma-separated integration names. */
					__( 'Coupons from integrations that are turned off are not listed: %s. If the store uses one of them, turn it on under AffiliateWP > Settings > Integrations.', 'affiliate-wp' ),
					implode( ', ', $disabled )
				)
				: '',
		);
	}

	/**
	 * Names of the integrations that can provide coupons but are turned off.
	 *
	 * @since 2.37.0
	 *
	 * @return string[]
	 */
	private function disabled_coupon_integrations() {
		$supported = array();
		$enabled   = array();

		foreach ( array( 'manual_coupons', 'dynamic_coupons' ) as $support ) {
			foreach ( array( 'enabled', 'disabled' ) as $status ) {
				$found = affiliate_wp()->integrations->query(
					array(
						'supports' => $support,
						'status'   => $status,
						'fields'   => array( 'ids', 'name' ),
					)
				);

				if ( ! is_array( $found ) ) {
					continue;
				}

				$supported = array_merge( $supported, $found );

				if ( 'enabled' === $status ) {
					$enabled = array_merge( $enabled, $found );
				}
			}
		}

		return array_values( array_diff_key( $supported, $enabled ) );
	}

	/**
	 * Ranks affiliates by earnings.
	 *
	 * @since 2.37.0
	 *
	 * @param array|null $input Ability input.
	 * @return array
	 */
	public function list_top_affiliates( $input = null ) {
		$input  = is_array( $input ) ? $input : array();
		$args   = $this->base_query_args( $input );
		$date   = $this->date_arg( $input );
		$status = ! empty( $input['status'] ) ? sanitize_key( $input['status'] ) : '';
		$number = isset( $args['number'] ) ? (int) $args['number'] : 20;
		$offset = isset( $args['offset'] ) ? (int) $args['offset'] : 0;

		if ( ! $date ) {
			$query = array(
				'number'  => $number,
				'offset'  => $offset,
				'orderby' => 'earnings',
				'order'   => 'DESC',
			);

			if ( $status ) {
				$query['status'] = $status;
			}

			$affiliates = affiliate_wp()->affiliates->get_affiliates( $query );
			$total      = affiliate_wp()->affiliates->count( array_diff_key( $query, array_flip( array( 'number', 'offset', 'orderby', 'order' ) ) ) );

			return array(
				'total'      => (int) $total,
				'affiliates' => $this->format_ranked_affiliates( $affiliates, '' ),
			);
		}

		$ranked = $this->rank_affiliates_for_period( $date );

		if ( $status ) {
			$ranked = array_values(
				array_filter(
					$ranked,
					static function ( $affiliate_id ) use ( $status ) {
						$affiliate = affwp_get_affiliate( $affiliate_id );

						return $affiliate && $status === $affiliate->status;
					}
				)
			);
		}

		$total = count( $ranked );
		$page  = array_slice( $ranked, $offset, $number );

		return array(
			'total'      => $total,
			'affiliates' => $this->format_ranked_affiliates( $page, $date ),
		);
	}

	/**
	 * Lists affiliate groups.
	 *
	 * @since 2.37.0
	 *
	 * @param array|null $input Ability input.
	 * @return array|\WP_Error
	 */
	public function list_groups( $input = null ) {
		$input  = is_array( $input ) ? $input : array();
		$args   = $this->base_query_args( $input );
		$query  = array(
			'type'   => 'affiliate-group',
			'fields' => 'objects',
			'number' => -1,
			'order'  => 'ASC',
		);

		if ( ! empty( $input['search'] ) ) {
			$query['search'] = sanitize_text_field( $input['search'] );
		}

		try {
			$groups = affiliate_wp()->groups->get_groups( $query );
		} catch ( \Exception $e ) {
			return new \WP_Error(
				'affwp_ability_groups_failed',
				__( 'Affiliate groups could not be listed.', 'affiliate-wp' )
			);
		}

		if ( is_wp_error( $groups ) ) {
			return new \WP_Error(
				'affwp_ability_groups_failed',
				__( 'Affiliate groups could not be listed.', 'affiliate-wp' )
			);
		}

		$groups = array_values(
			array_filter(
				is_array( $groups ) ? $groups : array(),
				static function ( $group ) {
					return $group instanceof \AffiliateWP\Groups\Group;
				}
			)
		);
		$total  = count( $groups );
		$page   = array_slice( $groups, (int) $args['offset'], (int) $args['number'] );

		return array(
			'total'  => $total,
			'groups' => array_map( array( Formatter::class, 'affiliate_group' ), $page ),
		);
	}

	/**
	 * Updates an affiliate's rate, notes, payment email, or group.
	 *
	 * @since 2.37.0
	 *
	 * @param array|null $input Ability input.
	 * @return array|\WP_Error
	 */
	public function update_affiliate( $input = null ) {
		$input     = is_array( $input ) ? $input : array();
		$affiliate = $this->resolve_affiliate( $input );

		if ( is_wp_error( $affiliate ) ) {
			return $affiliate;
		}

		// Renaming runs first because it is the only change that can fail on a capability check.
		$renamed = $this->update_user_name( $affiliate->user_id, $this->user_name_fields( $input, get_userdata( $affiliate->user_id ) ?: null ) );

		if ( is_wp_error( $renamed ) ) {
			return $renamed;
		}

		if ( array_key_exists( 'group_id', $input ) ) {
			$assigned = $this->assign_group( $affiliate->ID, absint( $input['group_id'] ) );

			if ( is_wp_error( $assigned ) ) {
				return $assigned;
			}
		}

		$fields = array_intersect_key( $input, array_flip( array( 'rate', 'rate_type', 'payment_email' ) ) );

		if ( ! empty( $fields ) ) {
			// affwp_update_affiliate() clears flat_rate_basis when the key is missing.
			$fields['affiliate_id']    = $affiliate->ID;
			$fields['flat_rate_basis'] = $affiliate->flat_rate_basis;

			affwp_update_affiliate( $fields );
		}

		if ( array_key_exists( 'notes', $input ) ) {
			affwp_update_affiliate_meta( $affiliate->ID, 'notes', wp_kses_post( $input['notes'] ) );
		}

		$updated = affwp_get_affiliate( $affiliate->ID );

		return $updated ? Formatter::affiliate( $updated ) : $this->not_found( __( 'No affiliate exists with that ID.', 'affiliate-wp' ) );
	}

	/**
	 * Name fields from ability input, plus a display name built from the given parts.
	 *
	 * @since 2.37.0
	 *
	 * @param array         $input Ability input.
	 * @param \WP_User|null $user  Existing user, whose name fills any part not given.
	 * @return array User fields for wp_insert_user() or wp_update_user(), empty when no name was given.
	 */
	private function user_name_fields( array $input, $user = null ) {
		$fields = array();

		foreach ( array( 'first_name', 'last_name' ) as $key ) {
			if ( isset( $input[ $key ] ) && is_string( $input[ $key ] ) ) {
				$fields[ $key ] = sanitize_text_field( $input[ $key ] );
			}
		}

		if ( empty( $fields ) ) {
			return $fields;
		}

		$first = isset( $fields['first_name'] ) ? $fields['first_name'] : ( $user ? $user->first_name : '' );
		$last  = isset( $fields['last_name'] ) ? $fields['last_name'] : ( $user ? $user->last_name : '' );
		$full  = trim( $first . ' ' . $last );

		if ( '' !== $full ) {
			$fields['display_name'] = $full;
		}

		return $fields;
	}

	/**
	 * Saves name fields on an existing user.
	 *
	 * @since 2.37.0
	 *
	 * @param int   $user_id User ID.
	 * @param array $fields  Fields from user_name_fields().
	 * @return true|\WP_Error
	 */
	private function update_user_name( $user_id, array $fields ) {
		if ( empty( $fields ) ) {
			return true;
		}

		if ( ! current_user_can( 'edit_user', $user_id ) ) {
			return $this->invalid( 'affwp_ability_cannot_edit_user', __( 'You do not have permission to change this user\'s name.', 'affiliate-wp' ), 403 );
		}

		if ( is_wp_error( wp_update_user( array( 'ID' => $user_id ) + $fields ) ) ) {
			return new \WP_Error( 'affwp_ability_name_failed', __( 'The affiliate\'s name could not be updated.', 'affiliate-wp' ) );
		}

		return true;
	}

	/**
	 * Ranks affiliates by paid plus unpaid earnings in a date range.
	 *
	 * @since 2.37.0
	 *
	 * @param array $date Date range.
	 * @return int[]
	 */
	private function rank_affiliates_for_period( array $date ) {
		$rows = affiliate_wp()->referrals->get_referrals(
			array(
				'groupby'    => 'affiliate_id',
				'fields'     => array( 'affiliate_id' ),
				'sum_fields' => array( 'amount' ),
				'status'     => array( 'paid', 'unpaid' ),
				'date'       => $date,
				'orderby'    => 'amount_sum',
				'order'      => 'DESC',
				'number'     => -1,
			)
		);

		$ranked = array();

		foreach ( (array) $rows as $row ) {
			if ( empty( $row->affiliate_id ) ) {
				continue;
			}

			$ranked[] = (int) $row->affiliate_id;
		}

		return $ranked;
	}

	/**
	 * Formats ranked affiliates with period stats.
	 *
	 * @since 2.37.0
	 *
	 * @param array        $affiliates Affiliate objects or affiliate IDs.
	 * @param array|string $date       Date range or empty for all time.
	 * @return array
	 */
	private function format_ranked_affiliates( $affiliates, $date ) {
		$items = array();

		foreach ( (array) $affiliates as $affiliate ) {
			if ( ! $affiliate instanceof \AffWP\Affiliate ) {
				$affiliate = affwp_get_affiliate( $affiliate );
			}

			if ( ! $affiliate ) {
				continue;
			}

			$items[] = array(
				'affiliate_id'    => (int) $affiliate->ID,
				'name'            => (string) affwp_get_affiliate_name( $affiliate ),
				'username'        => (string) affwp_get_affiliate_username( $affiliate ),
				'email'           => (string) affwp_get_affiliate_email( $affiliate ),
				'status'          => (string) $affiliate->status,
				'earnings'        => Formatter::amount( $affiliate->earnings ),
				'unpaid_earnings' => Formatter::amount( $affiliate->unpaid_earnings ),
				'period'          => $this->period_stats( $affiliate->ID, $date ),
			);
		}

		return $items;
	}

	/**
	 * Assigns an affiliate to a group, or removes them when $group_id is 0.
	 *
	 * @since 2.37.0
	 *
	 * @param int $affiliate_id Affiliate ID.
	 * @param int $group_id     Group ID, or 0 to unassign.
	 * @return true|\WP_Error
	 */
	private function assign_group( $affiliate_id, $group_id ) {
		$current = $this->affiliate_group_id( $affiliate_id );

		if ( $current === $group_id ) {
			return true;
		}

		if ( $group_id && ! affiliate_wp()->groups->group_exists( $group_id ) ) {
			return $this->not_found( __( 'No affiliate group exists with that ID.', 'affiliate-wp' ) );
		}

		if ( $group_id && 'affiliate-group' !== affiliate_wp()->groups->get_group_type( $group_id ) ) {
			return $this->invalid( 'affwp_ability_invalid_group', __( 'That group is not an affiliate group.', 'affiliate-wp' ) );
		}

		if ( $current ) {
			try {
				$disconnected = affiliate_wp()->connections->disconnect(
					array(
						'affiliate' => $affiliate_id,
						'group'     => $current,
					)
				);
			} catch ( \Exception $e ) {
				return new \WP_Error(
					'affwp_ability_group_failed',
					__( 'The affiliate group could not be updated.', 'affiliate-wp' )
				);
			}

			if ( is_wp_error( $disconnected ) ) {
				return new \WP_Error(
					'affwp_ability_group_failed',
					__( 'The affiliate group could not be updated.', 'affiliate-wp' )
				);
			}
		}

		if ( ! $group_id ) {
			return true;
		}

		try {
			$connected = affiliate_wp()->connections->connect(
				array(
					'affiliate' => $affiliate_id,
					'group'     => $group_id,
				)
			);
		} catch ( \Exception $e ) {
			return new \WP_Error(
				'affwp_ability_group_failed',
				__( 'The affiliate group could not be updated.', 'affiliate-wp' )
			);
		}

		if ( is_wp_error( $connected ) ) {
			return new \WP_Error(
				'affwp_ability_group_failed',
				__( 'The affiliate group could not be updated.', 'affiliate-wp' )
			);
		}

		return true;
	}
}
