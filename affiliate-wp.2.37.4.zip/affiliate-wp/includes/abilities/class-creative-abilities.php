<?php
/**
 * Abilities API: creatives.
 *
 * @package     AffiliateWP
 * @subpackage  Abilities
 * @copyright   Copyright (c) 2026, Awesome Motive, Inc.
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.37.0
 */

namespace AffWP\Abilities;

/**
 * Abilities for reading and adding creatives.
 *
 * @since 2.37.0
 */
class Creative_Abilities extends Ability_Group {

	/**
	 * {@inheritDoc}
	 */
	public function get_definitions() {
		return array(
			'list-creatives' => $this->read(
				array(
					'label'               => __( 'List creatives', 'affiliate-wp' ),
					'description'         => __( 'Lists the banners, text links, and other creatives affiliates can use to promote the site, with the page each one links to and its status.', 'affiliate-wp' ),
					'permission_callback' => $this->can( 'manage_creatives' ),
					'execute_callback'    => array( $this, 'list_creatives' ),
					'input_schema'        => $this->object_schema(
						array_merge(
							array(
								'status' => array(
									'type'        => 'string',
									'description' => __( 'Only creatives with this status.', 'affiliate-wp' ),
									'enum'        => array_keys( affwp_get_creative_statuses() ),
								),
								'type'   => array(
									'type'        => 'string',
									'description' => __( 'Only creatives of this type.', 'affiliate-wp' ),
									'enum'        => array_keys( affwp_get_creative_types() ),
								),
							),
							$this->sort_properties( array( 'creative_id', 'name', 'date', 'status' ), 'creative_id' ),
							$this->pagination_properties()
						)
					),
					'output_schema'       => $this->list_schema( 'creatives', Formatter::creative_schema() ),
				)
			),
			'add-creative'   => $this->write(
				array(
					'label'               => __( 'Add creative', 'affiliate-wp' ),
					'description'         => __( 'Adds a text link, image banner, or QR code that affiliates can use to promote the site. Each affiliate\'s copy carries their own referral link to the url. An image creative needs the URL of an image already in the media library or elsewhere.', 'affiliate-wp' ),
					'permission_callback' => $this->can( 'manage_creatives' ),
					'execute_callback'    => array( $this, 'add_creative' ),
					'input_schema'        => $this->object_schema(
						array(
							'name'        => array(
								'type'        => 'string',
								'description' => __( 'Name affiliates see in their list of creatives.', 'affiliate-wp' ),
								'minLength'   => 1,
							),
							'type'        => array(
								'type'        => 'string',
								'description' => __( 'Kind of creative.', 'affiliate-wp' ),
								'enum'        => array_keys( affwp_get_creative_types() ),
								'default'     => 'text_link',
							),
							'url'         => array(
								'type'        => 'string',
								'description' => __( 'Page the creative links to. Defaults to the site home page.', 'affiliate-wp' ),
								'format'      => 'uri',
							),
							'text'        => array(
								'type'        => 'string',
								'description' => __( 'Link text for a text link, or alt text for an image. Defaults to the site name.', 'affiliate-wp' ),
							),
							'image'       => array(
								'type'        => 'string',
								'description' => __( 'Image URL. Required when type is image.', 'affiliate-wp' ),
								'format'      => 'uri',
							),
							'description' => array(
								'type'        => 'string',
								'description' => __( 'Description shown to affiliates.', 'affiliate-wp' ),
							),
							'status'      => array(
								'type'        => 'string',
								'description' => __( 'Inactive creatives are hidden from affiliates.', 'affiliate-wp' ),
								'enum'        => array( 'active', 'inactive' ),
								'default'     => 'active',
							),
							'notes'       => array(
								'type'        => 'string',
								'description' => __( 'Private admin notes about the creative.', 'affiliate-wp' ),
							),
						),
						array( 'name' )
					),
					'output_schema'       => Formatter::creative_schema(),
				),
				false,
				false
			),
		);
	}

	/**
	 * Lists creatives.
	 *
	 * @since 2.37.0
	 *
	 * @param array|null $input Ability input.
	 * @return array
	 */
	public function list_creatives( $input = null ) {
		$input = is_array( $input ) ? $input : array();
		$args  = $this->base_query_args( $input );

		foreach ( array( 'status', 'type' ) as $key ) {
			if ( ! empty( $input[ $key ] ) ) {
				$args[ $key ] = sanitize_key( $input[ $key ] );
			}
		}

		$creatives = affiliate_wp()->creatives->get_creatives( $args );
		$total     = affiliate_wp()->creatives->count( array_diff_key( $args, array_flip( array( 'number', 'offset', 'orderby', 'order' ) ) ) );

		return array(
			'total'     => (int) $total,
			'creatives' => array_map( array( Formatter::class, 'creative' ), $creatives ),
		);
	}

	/**
	 * Adds a creative.
	 *
	 * @since 2.37.0
	 *
	 * @param array|null $input Ability input.
	 * @return array|\WP_Error
	 */
	public function add_creative( $input = null ) {
		$input = is_array( $input ) ? $input : array();
		$type  = ! empty( $input['type'] ) ? sanitize_key( $input['type'] ) : 'text_link';

		if ( 'image' === $type && empty( $input['image'] ) ) {
			return $this->invalid( 'affwp_ability_missing_image', __( 'An image creative needs an image URL.', 'affiliate-wp' ) );
		}

		$creative_id = affwp_add_creative(
			array_merge(
				array_intersect_key( $input, array_flip( array( 'name', 'url', 'text', 'image', 'description', 'notes' ) ) ),
				array(
					'type'   => $type,
					'status' => ! empty( $input['status'] ) ? sanitize_key( $input['status'] ) : 'active',
				)
			)
		);

		if ( ! $creative_id ) {
			return new \WP_Error( 'affwp_ability_add_failed', __( 'The creative could not be added.', 'affiliate-wp' ) );
		}

		return Formatter::creative( affwp_get_creative( $creative_id ) );
	}
}
