<?php
/**
 * Abilities API bootstrap.
 *
 * Registers AffiliateWP abilities with the WordPress Abilities API (core since 6.9) so
 * MCP clients and AI agents can read program data and act on it with the connected
 * user's permissions.
 *
 * @package     AffiliateWP
 * @subpackage  Abilities
 * @copyright   Copyright (c) 2026, Awesome Motive, Inc.
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.37.0
 */

namespace AffWP\Abilities;

/**
 * Registers the AffiliateWP ability category and abilities.
 *
 * @since 2.37.0
 */
final class Abilities {

	/**
	 * Ability namespace prefix, e.g. `affiliatewp/list-affiliates`.
	 *
	 * @since 2.37.0
	 * @var string
	 */
	const PREFIX = 'affiliatewp';

	/**
	 * Ability category slug.
	 *
	 * @since 2.37.0
	 * @var string
	 */
	const CATEGORY = 'affiliatewp';

	/**
	 * Option storing per-ability run counts for usage tracking.
	 *
	 * @since 2.37.0
	 * @var string
	 */
	const USAGE_OPTION = 'affwp_abilities_usage';

	/**
	 * Settings key for the write-access toggle.
	 *
	 * @since 2.37.0
	 * @var string
	 */
	const WRITE_SETTING = 'abilities_write_enabled';

	/**
	 * Sets up hooks.
	 *
	 * @since 2.37.0
	 */
	public function __construct() {
		if ( ! self::is_supported() ) {
			return;
		}

		add_action( 'wp_abilities_api_categories_init', array( $this, 'register_category' ) );
		add_action( 'wp_abilities_api_init', array( $this, 'register_abilities' ) );
		add_action( 'wp_after_execute_ability', array( $this, 'record_run' ), 10, 3 );
		add_filter( 'wp_pre_execute_ability', array( $this, 'explain_write_denial' ), 10, 4 );
	}

	/**
	 * Stops a write ability before it runs, with the reason, while write access is off.
	 *
	 * The permission callback already denies it. This short-circuit only swaps the generic
	 * denial for a message that tells the caller where to turn writes on.
	 *
	 * @since 2.37.0
	 *
	 * @param mixed       $pre     Sentinel value, or a result to short-circuit with.
	 * @param string      $name    Ability name.
	 * @param mixed       $input   Ability input.
	 * @param \WP_Ability $ability Ability instance.
	 * @return mixed
	 */
	public function explain_write_denial( $pre, $name, $input, $ability ) {
		if ( 0 !== strpos( $name, self::PREFIX . '/' ) || self::write_enabled() ) {
			return $pre;
		}

		$annotations = $ability->get_meta_item( 'annotations', array() );

		if ( ! empty( $annotations['readonly'] ) ) {
			return $pre;
		}

		return new \WP_Error(
			'affwp_abilities_write_disabled',
			__( 'AffiliateWP does not allow AI to make changes. Turn on Enable MCP Write Access under Affiliates > Tools > AI MCP.', 'affiliate-wp' ),
			array( 'status' => 403 )
		);
	}

	/**
	 * Whether the running WordPress ships the Abilities API.
	 *
	 * @since 2.37.0
	 *
	 * @return bool
	 */
	public static function is_supported() {
		return function_exists( 'wp_register_ability' );
	}

	/**
	 * Whether abilities that change data may run.
	 *
	 * @since 2.37.0
	 *
	 * @return bool
	 */
	public static function write_enabled() {
		$enabled = (bool) affiliate_wp()->settings->get( self::WRITE_SETTING, false );

		/**
		 * Filters whether AI abilities may change data.
		 *
		 * @since 2.37.0
		 *
		 * @param bool $enabled Whether write abilities are allowed. Defaults to the Tools > AI MCP toggle.
		 */
		return (bool) apply_filters( 'affwp_abilities_allow_write', $enabled );
	}

	/**
	 * Registers the AffiliateWP ability category.
	 *
	 * @since 2.37.0
	 */
	public function register_category() {
		wp_register_ability_category(
			self::CATEGORY,
			array(
				'label'       => __( 'AffiliateWP', 'affiliate-wp' ),
				'description' => __( 'Read affiliate program data and manage affiliates, referrals, payouts, visits, campaigns, and creatives in AffiliateWP.', 'affiliate-wp' ),
			)
		);
	}

	/**
	 * Retrieves the ability groups.
	 *
	 * @since 2.37.0
	 *
	 * @return Ability_Group[]
	 */
	public function get_groups() {
		$groups = array(
			new Program_Abilities(),
			new Affiliate_Abilities(),
			new Referral_Abilities(),
			new Payout_Abilities(),
			new Visit_Abilities(),
			new Creative_Abilities(),
			new Campaign_Abilities(),
		);

		/**
		 * Filters the ability groups AffiliateWP registers.
		 *
		 * @since 2.37.0
		 *
		 * @param Ability_Group[] $groups Ability group instances.
		 */
		$groups = apply_filters( 'affwp_abilities_groups', $groups );

		return array_filter(
			$groups,
			static function ( $group ) {
				return $group instanceof Ability_Group;
			}
		);
	}

	/**
	 * Retrieves every ability definition keyed by its unprefixed name.
	 *
	 * @since 2.37.0
	 *
	 * @return array<string, array>
	 */
	public function get_definitions() {
		$definitions = array();

		foreach ( $this->get_groups() as $group ) {
			$definitions = array_merge( $definitions, $group->get_definitions() );
		}

		/**
		 * Filters the AffiliateWP ability definitions before registration.
		 *
		 * Keys are unprefixed ability names (e.g. `list-affiliates`), values are the
		 * argument arrays passed to `wp_register_ability()`.
		 *
		 * @since 2.37.0
		 *
		 * @param array<string, array> $definitions Ability definitions.
		 */
		return apply_filters( 'affwp_abilities', $definitions );
	}

	/**
	 * Registers all abilities with WordPress.
	 *
	 * @since 2.37.0
	 */
	public function register_abilities() {
		foreach ( $this->get_definitions() as $name => $args ) {
			$args['category'] = self::CATEGORY;

			wp_register_ability( self::PREFIX . '/' . $name, $args );
		}
	}

	/**
	 * Retrieves the registered AffiliateWP abilities.
	 *
	 * @since 2.37.0
	 *
	 * @return \WP_Ability[]
	 */
	public function get_registered() {
		if ( ! self::is_supported() ) {
			return array();
		}

		return wp_get_abilities( array( 'namespace' => self::PREFIX ) );
	}

	/**
	 * Records a successful ability run for usage tracking.
	 *
	 * @since 2.37.0
	 *
	 * @param string $name   Ability name.
	 * @param mixed  $input  Ability input.
	 * @param mixed  $result Ability result.
	 */
	public function record_run( $name, $input, $result ) {
		if ( 0 !== strpos( $name, self::PREFIX . '/' ) || is_wp_error( $result ) ) {
			return;
		}

		$usage = self::get_usage();

		$usage[ $name ] = array(
			'count'    => isset( $usage[ $name ]['count'] ) ? absint( $usage[ $name ]['count'] ) + 1 : 1,
			'last_run' => gmdate( 'Y-m-d H:i:s' ),
		);

		update_option( self::USAGE_OPTION, $usage, false );
	}

	/**
	 * Retrieves per-ability run counts.
	 *
	 * @since 2.37.0
	 *
	 * @return array<string, array{count: int, last_run: string}>
	 */
	public static function get_usage() {
		$usage = get_option( self::USAGE_OPTION, array() );

		return is_array( $usage ) ? $usage : array();
	}
}
