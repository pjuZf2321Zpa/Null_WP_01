<?php
/**
 * Abilities API: program summary.
 *
 * @package     AffiliateWP
 * @subpackage  Abilities
 * @copyright   Copyright (c) 2026, Awesome Motive, Inc.
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.37.0
 */

namespace AffWP\Abilities;

/**
 * Program-wide reporting abilities.
 *
 * @since 2.37.0
 */
class Program_Abilities extends Ability_Group {

	/**
	 * {@inheritDoc}
	 */
	public function get_definitions() {
		return array(
			'get-program-summary' => $this->read(
				array(
					'label'               => __( 'Get program summary', 'affiliate-wp' ),
					'description'         => __( 'Returns totals for the affiliate program: affiliates by status, referrals by status, paid and unpaid earnings, and visits. Optionally limited to a date range. Use this first to understand the size and health of the program.', 'affiliate-wp' ),
					'permission_callback' => $this->can( 'view_affiliate_reports' ),
					'execute_callback'    => array( $this, 'get_summary' ),
					'input_schema'        => $this->object_schema(
						array(
							'date' => $this->date_range_property( __( 'Limit referrals, earnings, and visits to this date range. Affiliate counts are always program-wide.', 'affiliate-wp' ) ),
						)
					),
					'output_schema'       => array(
						'type'       => 'object',
						'properties' => array(
							'currency'   => array( 'type' => 'string' ),
							'affiliates' => array(
								'type'       => 'object',
								'properties' => array(
									'total'    => array( 'type' => 'integer' ),
									'active'   => array( 'type' => 'integer' ),
									'pending'  => array( 'type' => 'integer' ),
									'inactive' => array( 'type' => 'integer' ),
									'rejected' => array( 'type' => 'integer' ),
								),
							),
							'referrals'  => array(
								'type'       => 'object',
								'properties' => array(
									'total'    => array( 'type' => 'integer' ),
									'paid'     => array( 'type' => 'integer' ),
									'unpaid'   => array( 'type' => 'integer' ),
									'pending'  => array( 'type' => 'integer' ),
									'rejected' => array( 'type' => 'integer' ),
								),
							),
							'earnings'   => array(
								'type'       => 'object',
								'properties' => array(
									'paid'   => array( 'type' => 'number' ),
									'unpaid' => array( 'type' => 'number' ),
								),
							),
							'visits'     => array(
								'type'       => 'object',
								'properties' => array(
									'total'           => array( 'type' => 'integer' ),
									'converted'       => array( 'type' => 'integer' ),
									'conversion_rate' => array(
										'type'        => 'number',
										'description' => __( 'Converted visits as a percentage of all visits.', 'affiliate-wp' ),
									),
								),
							),
						),
					),
				)
			),
			'get-program-settings' => $this->read(
				array(
					'label'               => __( 'Get program settings', 'affiliate-wp' ),
					'description'         => __( 'Returns the affiliate program rules: default referral rate and type, cookie duration, currency, whether new affiliates need approval, and which integrations are enabled. Use this to interpret rates and explain how tracking works. Does not include secrets, API keys, or email templates.', 'affiliate-wp' ),
					'permission_callback' => $this->can( 'view_affiliate_reports' ),
					'execute_callback'    => array( $this, 'get_settings' ),
					'input_schema'        => $this->object_schema( array() ),
					'output_schema'       => array(
						'type'       => 'object',
						'properties' => array(
							'currency'                     => array( 'type' => 'string' ),
							'currency_position'            => array( 'type' => 'string' ),
							'referral_rate'                => array(
								'type'        => 'string',
								'description' => __( 'Default referral rate. A percentage when referral_rate_type is percentage, otherwise a flat amount.', 'affiliate-wp' ),
							),
							'referral_rate_type'           => array( 'type' => 'string' ),
							'flat_rate_basis'              => array( 'type' => 'string' ),
							'cookie_expiration_days'       => array(
								'type'        => 'integer',
								'description' => __( 'How many days the referral tracking cookie lasts.', 'affiliate-wp' ),
							),
							'require_approval'             => array(
								'type'        => 'boolean',
								'description' => __( 'True when new affiliates stay pending until an admin approves them.', 'affiliate-wp' ),
							),
							'allow_affiliate_registration' => array( 'type' => 'boolean' ),
							'default_referral_url'         => array( 'type' => 'string' ),
							'exclude_shipping'             => array( 'type' => 'boolean' ),
							'exclude_tax'                  => array( 'type' => 'boolean' ),
							'credit_last_referrer'         => array( 'type' => 'boolean' ),
							'pretty_affiliate_urls'        => array( 'type' => 'boolean' ),
							'integrations'                 => array(
								'type'        => 'array',
								'description' => __( 'Enabled integrations, e.g. WooCommerce.', 'affiliate-wp' ),
								'items'       => array(
									'type'       => 'object',
									'properties' => array(
										'slug' => array( 'type' => 'string' ),
										'name' => array( 'type' => 'string' ),
									),
								),
							),
						),
					),
				)
			),
		);
	}

	/**
	 * Builds the program summary.
	 *
	 * @since 2.37.0
	 *
	 * @param array|null $input Ability input.
	 * @return array
	 */
	public function get_summary( $input = null ) {
		$input = is_array( $input ) ? $input : array();
		$args  = $this->base_query_args( $input );
		$date  = isset( $args['date'] ) ? $args['date'] : '';

		$affiliates = array( 'total' => affiliate_wp()->affiliates->count() );

		foreach ( array( 'active', 'pending', 'inactive', 'rejected' ) as $status ) {
			$affiliates[ $status ] = affiliate_wp()->affiliates->count( array( 'status' => $status ) );
		}

		$referral_args = $date ? array( 'date' => $date ) : array();
		$referrals     = array( 'total' => affiliate_wp()->referrals->count( $referral_args ) );

		foreach ( array( 'paid', 'unpaid', 'pending', 'rejected' ) as $status ) {
			$referrals[ $status ] = affiliate_wp()->referrals->count( array_merge( $referral_args, array( 'status' => $status ) ) );
		}

		$visit_args = $date ? array( 'date' => $date ) : array();
		$total      = affiliate_wp()->visits->count( $visit_args );
		$converted  = affiliate_wp()->visits->count( array_merge( $visit_args, array( 'referral_status' => 'converted' ) ) );

		return array(
			'currency'   => affwp_get_currency(),
			'affiliates' => array_map( 'intval', $affiliates ),
			'referrals'  => array_map( 'intval', $referrals ),
			'earnings'   => array(
				'paid'   => Formatter::amount( affiliate_wp()->referrals->paid_earnings( $date, 0, false ) ),
				'unpaid' => Formatter::amount( affiliate_wp()->referrals->unpaid_earnings( $date, 0, false ) ),
			),
			'visits'     => array(
				'total'           => (int) $total,
				'converted'       => (int) $converted,
				'conversion_rate' => $total > 0 ? round( ( $converted / $total ) * 100, 2 ) : 0.0,
			),
		);
	}

	/**
	 * Returns the safe subset of program settings.
	 *
	 * @since 2.37.0
	 *
	 * @param array|null $input Ability input.
	 * @return array
	 */
	public function get_settings( $input = null ) {
		unset( $input );

		$settings = affiliate_wp()->settings;
		$enabled  = affiliate_wp()->integrations->get_enabled_integrations();
		$items    = array();

		if ( is_array( $enabled ) ) {
			foreach ( $enabled as $slug => $name ) {
				$items[] = array(
					'slug' => (string) $slug,
					'name' => (string) $name,
				);
			}
		}

		return array(
			'currency'                     => affwp_get_currency(),
			'currency_position'            => (string) $settings->get( 'currency_position', 'before' ),
			'referral_rate'                => (string) $settings->get( 'referral_rate', 20 ),
			'referral_rate_type'           => (string) $settings->get( 'referral_rate_type', 'percentage' ),
			'flat_rate_basis'              => (string) $settings->get( 'flat_rate_basis', 'per_product' ),
			'cookie_expiration_days'       => (int) $settings->get( 'cookie_exp', 30 ),
			'require_approval'             => (bool) $settings->get( 'require_approval' ),
			'allow_affiliate_registration' => (bool) $settings->get( 'allow_affiliate_registration' ),
			'default_referral_url'         => (string) $settings->get( 'default_referral_url', '' ),
			'exclude_shipping'             => (bool) $settings->get( 'exclude_shipping' ),
			'exclude_tax'                  => (bool) $settings->get( 'exclude_tax' ),
			'credit_last_referrer'         => (bool) $settings->get( 'referral_credit_last' ),
			'pretty_affiliate_urls'        => (bool) $settings->get( 'referral_pretty_urls' ),
			'integrations'                 => $items,
		);
	}
}
