<?php
/**
 * Abilities API: payouts.
 *
 * @package     AffiliateWP
 * @subpackage  Abilities
 * @copyright   Copyright (c) 2026, Awesome Motive, Inc.
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.37.0
 */

namespace AffWP\Abilities;

/**
 * Abilities for reading payouts.
 *
 * @since 2.37.0
 */
class Payout_Abilities extends Ability_Group {

	/**
	 * {@inheritDoc}
	 */
	public function get_definitions() {
		return array(
			'list-payouts' => $this->read(
				array(
					'label'               => __( 'List payouts', 'affiliate-wp' ),
					'description'         => __( 'Lists payouts made to affiliates, with amount, payout method, status, and the referrals each payout covered. Filter by affiliate, status, payout method, or date range.', 'affiliate-wp' ),
					'permission_callback' => $this->can( 'manage_payouts' ),
					'execute_callback'    => array( $this, 'list_payouts' ),
					'input_schema'        => $this->object_schema(
						array_merge(
							array(
								'payout_id'     => array(
									'type'        => 'integer',
									'description' => __( 'Return only this payout.', 'affiliate-wp' ),
									'minimum'     => 1,
								),
								'affiliate_id'  => array(
									'type'        => 'integer',
									'description' => __( 'Only payouts to this affiliate.', 'affiliate-wp' ),
									'minimum'     => 1,
								),
								'status'        => array(
									'type'        => 'string',
									'description' => __( 'Only payouts with this status. Defaults to all statuses.', 'affiliate-wp' ),
									'enum'        => array_keys( affwp_get_payout_statuses() ),
								),
								'payout_method' => array(
									'type'        => 'string',
									'description' => __( 'Only payouts sent with this method, e.g. manual, paypal, stripe.', 'affiliate-wp' ),
								),
								'date'          => $this->date_range_property( __( 'Only payouts made in this date range.', 'affiliate-wp' ) ),
							),
							$this->sort_properties( array( 'payout_id', 'date', 'amount', 'status', 'affiliate_id' ), 'payout_id' ),
							$this->pagination_properties()
						)
					),
					'output_schema'       => $this->list_schema( 'payouts', Formatter::payout_schema() ),
				)
			),
		);
	}

	/**
	 * Lists payouts.
	 *
	 * @since 2.37.0
	 *
	 * @param array|null $input Ability input.
	 * @return array
	 */
	public function list_payouts( $input = null ) {
		$input = is_array( $input ) ? $input : array();
		$args  = $this->base_query_args( $input );

		// The query defaults to paid only, so ask for every status unless one was given.
		$args['status'] = ! empty( $input['status'] ) ? sanitize_key( $input['status'] ) : array_keys( affwp_get_payout_statuses() );

		foreach ( array( 'payout_id', 'affiliate_id' ) as $key ) {
			if ( ! empty( $input[ $key ] ) ) {
				$args[ $key ] = absint( $input[ $key ] );
			}
		}

		if ( ! empty( $input['payout_method'] ) ) {
			$args['payout_method'] = sanitize_key( $input['payout_method'] );
		}

		$payouts = affiliate_wp()->affiliates->payouts->get_payouts( $args );
		$total   = affiliate_wp()->affiliates->payouts->count( array_diff_key( $args, array_flip( array( 'number', 'offset', 'orderby', 'order' ) ) ) );

		return array(
			'total'   => (int) $total,
			'payouts' => array_map( array( Formatter::class, 'payout' ), $payouts ),
		);
	}
}
