<?php
/**
 * Abilities API: visits.
 *
 * @package     AffiliateWP
 * @subpackage  Abilities
 * @copyright   Copyright (c) 2026, Awesome Motive, Inc.
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.37.0
 */

namespace AffWP\Abilities;

/**
 * Abilities for reading visits.
 *
 * @since 2.37.0
 */
class Visit_Abilities extends Ability_Group {

	/**
	 * {@inheritDoc}
	 */
	public function get_definitions() {
		return array(
			'list-visits' => $this->read(
				array(
					'label'               => __( 'List visits', 'affiliate-wp' ),
					'description'         => __( 'Lists tracked visits from affiliate links, with the landing URL, referrer, campaign, and whether the visit converted into a referral. Visitor IP addresses are not included.', 'affiliate-wp' ),
					'permission_callback' => $this->can( 'manage_visits' ),
					'execute_callback'    => array( $this, 'list_visits' ),
					'input_schema'        => $this->object_schema(
						array_merge(
							array(
								'affiliate_id' => array(
									'type'        => 'integer',
									'description' => __( 'Only visits from this affiliate\'s links.', 'affiliate-wp' ),
									'minimum'     => 1,
								),
								'converted'    => array(
									'type'        => 'boolean',
									'description' => __( 'True for visits that produced a referral, false for visits that did not. Omit for both.', 'affiliate-wp' ),
								),
								'campaign'     => array(
									'type'        => 'string',
									'description' => __( 'Only visits attributed to this campaign.', 'affiliate-wp' ),
								),
								'date'         => $this->date_range_property( __( 'Only visits in this date range.', 'affiliate-wp' ) ),
							),
							$this->sort_properties( array( 'visit_id', 'date', 'affiliate_id', 'referral_id' ), 'visit_id' ),
							$this->pagination_properties()
						)
					),
					'output_schema'       => $this->list_schema( 'visits', Formatter::visit_schema() ),
				)
			),
		);
	}

	/**
	 * Lists visits.
	 *
	 * @since 2.37.0
	 *
	 * @param array|null $input Ability input.
	 * @return array
	 */
	public function list_visits( $input = null ) {
		$input = is_array( $input ) ? $input : array();
		$args  = $this->base_query_args( $input );

		if ( ! empty( $input['affiliate_id'] ) ) {
			$args['affiliate_id'] = absint( $input['affiliate_id'] );
		}

		if ( isset( $input['converted'] ) ) {
			$args['referral_status'] = $input['converted'] ? 'converted' : 'unconverted';
		}

		if ( ! empty( $input['campaign'] ) ) {
			$args['campaign'] = sanitize_text_field( $input['campaign'] );
		}

		$visits = affiliate_wp()->visits->get_visits( $args );
		$total  = affiliate_wp()->visits->count( array_diff_key( $args, array_flip( array( 'number', 'offset', 'orderby', 'order' ) ) ) );

		return array(
			'total'  => (int) $total,
			'visits' => array_map( array( Formatter::class, 'visit' ), $visits ),
		);
	}
}
