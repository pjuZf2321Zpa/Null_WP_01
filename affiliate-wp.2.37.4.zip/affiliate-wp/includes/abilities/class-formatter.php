<?php
/**
 * Abilities API: output formatting and schemas.
 *
 * @package     AffiliateWP
 * @subpackage  Abilities
 * @copyright   Copyright (c) 2026, Awesome Motive, Inc.
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.37.0
 */

namespace AffWP\Abilities;

/**
 * Turns AffiliateWP objects into plain arrays that match their output schemas.
 *
 * @since 2.37.0
 */
final class Formatter {

	/**
	 * Rounds a money value to the store's decimal places, dropping float noise.
	 *
	 * @since 2.37.0
	 *
	 * @param mixed $amount Raw amount.
	 * @return float
	 */
	public static function amount( $amount ) {
		return round( (float) $amount, (int) affwp_get_decimal_count() );
	}

	/**
	 * Formats an affiliate.
	 *
	 * @since 2.37.0
	 *
	 * @param \AffWP\Affiliate $affiliate Affiliate object.
	 * @return array
	 */
	public static function affiliate( $affiliate ) {
		$email    = affwp_get_affiliate_email( $affiliate );
		$username = (string) affwp_get_affiliate_username( $affiliate );
		$name     = (string) affwp_get_affiliate_name( $affiliate );
		$notes    = affwp_get_affiliate_meta( $affiliate->ID, 'notes', true );
		$group_id = 0;

		try {
			$resolved = affwp_get_affiliate_group_id( (int) $affiliate->ID );
			$group_id = $resolved ? (int) $resolved : 0;
		} catch ( \Exception $e ) {
			$group_id = 0;
		}

		$group_name = '';
		$rate_type  = (string) affwp_get_affiliate_rate_type( $affiliate );
		$rate       = affwp_get_affiliate_rate( $affiliate );

		// affwp_get_affiliate_rate() returns percentages as a fraction; inputs take the percent value.
		if ( 'percentage' === $rate_type && is_numeric( $rate ) ) {
			$rate = round( (float) $rate * 100, 4 );
		}

		if ( $group_id && affiliate_wp()->groups->group_exists( $group_id ) ) {
			$title      = affiliate_wp()->groups->get_group_title( $group_id );
			$group_name = is_string( $title ) ? $title : '';
		}

		return array(
			'affiliate_id'     => (int) $affiliate->ID,
			'user_id'          => (int) $affiliate->user_id,
			'name'             => '' !== $name ? $name : $username,
			'username'         => $username,
			'email'            => $email ? (string) $email : '',
			'payment_email'    => (string) $affiliate->payment_email,
			'status'           => (string) $affiliate->status,
			'rate'             => (string) $rate,
			'rate_type'        => $rate_type,
			'has_custom_rate'  => (bool) affwp_affiliate_has_custom_rate( $affiliate ),
			'group_id'         => $group_id,
			'group_name'       => $group_name,
			'notes'            => is_string( $notes ) ? $notes : '',
			'earnings'         => self::amount( $affiliate->earnings ),
			'unpaid_earnings'  => self::amount( $affiliate->unpaid_earnings ),
			'referrals'        => (int) $affiliate->referrals,
			'visits'           => (int) $affiliate->visits,
			'referral_url'     => (string) affwp_get_affiliate_referral_url( array( 'affiliate_id' => $affiliate->ID ) ),
			'date_registered'  => (string) $affiliate->date_registered,
		);
	}

	/**
	 * Output schema for one affiliate.
	 *
	 * @since 2.37.0
	 *
	 * @return array
	 */
	public static function affiliate_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'affiliate_id'    => array( 'type' => 'integer' ),
				'user_id'         => array( 'type' => 'integer' ),
				'name'            => array( 'type' => 'string' ),
				'username'        => array( 'type' => 'string' ),
				'email'           => array( 'type' => 'string' ),
				'payment_email'   => array( 'type' => 'string' ),
				'status'          => array( 'type' => 'string' ),
				'rate'            => array(
					'type'        => 'string',
					'description' => __( 'Referral rate. The percent value when rate_type is percentage, e.g. 20 for 20%, otherwise a flat amount in the store currency.', 'affiliate-wp' ),
				),
				'rate_type'       => array( 'type' => 'string' ),
				'has_custom_rate' => array(
					'type'        => 'boolean',
					'description' => __( 'True when this affiliate has a personal rate instead of the program default.', 'affiliate-wp' ),
				),
				'group_id'        => array(
					'type'        => 'integer',
					'description' => __( 'Affiliate group ID, or 0 when the affiliate is not in a group.', 'affiliate-wp' ),
				),
				'group_name'      => array( 'type' => 'string' ),
				'notes'           => array(
					'type'        => 'string',
					'description' => __( 'Private admin notes about the affiliate.', 'affiliate-wp' ),
				),
				'earnings'        => array(
					'type'        => 'number',
					'description' => __( 'Paid earnings in the store currency.', 'affiliate-wp' ),
				),
				'unpaid_earnings' => array(
					'type'        => 'number',
					'description' => __( 'Unpaid earnings in the store currency.', 'affiliate-wp' ),
				),
				'referrals'       => array(
					'type'        => 'integer',
					'description' => __( 'Number of paid referrals.', 'affiliate-wp' ),
				),
				'visits'          => array( 'type' => 'integer' ),
				'referral_url'    => array( 'type' => 'string' ),
				'date_registered' => array(
					'type'        => 'string',
					'description' => __( 'UTC datetime in YYYY-MM-DD HH:MM:SS format.', 'affiliate-wp' ),
				),
			),
		);
	}

	/**
	 * Formats a referral.
	 *
	 * @since 2.37.0
	 *
	 * @param \AffWP\Referral $referral Referral object.
	 * @return array
	 */
	public static function referral( $referral ) {
		return array(
			'referral_id'    => (int) $referral->ID,
			'affiliate_id'   => (int) $referral->affiliate_id,
			'affiliate_name' => (string) affwp_get_affiliate_name( $referral->affiliate_id ),
			'visit_id'       => (int) $referral->visit_id,
			'customer_id'    => (int) $referral->customer_id,
			'parent_id'      => (int) $referral->parent_id,
			'description'    => (string) $referral->description,
			'status'         => (string) $referral->status,
			'type'           => (string) $referral->type,
			'amount'         => self::amount( $referral->amount ),
			'currency'       => (string) $referral->currency,
			'context'        => (string) $referral->context,
			'campaign'       => (string) $referral->campaign,
			'reference'      => (string) $referral->reference,
			'date'           => (string) $referral->date,
		);
	}

	/**
	 * Output schema for one referral.
	 *
	 * @since 2.37.0
	 *
	 * @return array
	 */
	public static function referral_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'referral_id'    => array( 'type' => 'integer' ),
				'affiliate_id'   => array( 'type' => 'integer' ),
				'affiliate_name' => array( 'type' => 'string' ),
				'visit_id'       => array( 'type' => 'integer' ),
				'customer_id'    => array( 'type' => 'integer' ),
				'parent_id'      => array(
					'type'        => 'integer',
					'description' => __( 'Parent referral ID for multi-tier commissions, otherwise 0.', 'affiliate-wp' ),
				),
				'description'    => array( 'type' => 'string' ),
				'status'         => array( 'type' => 'string' ),
				'type'           => array( 'type' => 'string' ),
				'amount'         => array(
					'type'        => 'number',
					'description' => __( 'Commission amount.', 'affiliate-wp' ),
				),
				'currency'       => array( 'type' => 'string' ),
				'context'        => array(
					'type'        => 'string',
					'description' => __( 'Integration that created the referral, e.g. woocommerce.', 'affiliate-wp' ),
				),
				'campaign'       => array( 'type' => 'string' ),
				'reference'      => array(
					'type'        => 'string',
					'description' => __( 'Order or entry reference in the integration.', 'affiliate-wp' ),
				),
				'date'           => array(
					'type'        => 'string',
					'description' => __( 'UTC datetime in YYYY-MM-DD HH:MM:SS format.', 'affiliate-wp' ),
				),
			),
		);
	}

	/**
	 * Formats a payout.
	 *
	 * @since 2.37.0
	 *
	 * @param \AffWP\Affiliate\Payout $payout Payout object.
	 * @return array
	 */
	public static function payout( $payout ) {
		return array(
			'payout_id'      => (int) $payout->ID,
			'affiliate_id'   => (int) $payout->affiliate_id,
			'affiliate_name' => (string) affwp_get_affiliate_name( $payout->affiliate_id ),
			'referrals'      => array_values( wp_parse_id_list( $payout->referrals ) ),
			'amount'         => self::amount( $payout->amount ),
			'payout_method'  => (string) $payout->payout_method,
			'status'         => (string) $payout->status,
			'failure_class'  => (string) $payout->failure_class,
			'date'           => (string) $payout->date,
		);
	}

	/**
	 * Output schema for one payout.
	 *
	 * @since 2.37.0
	 *
	 * @return array
	 */
	public static function payout_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'payout_id'      => array( 'type' => 'integer' ),
				'affiliate_id'   => array( 'type' => 'integer' ),
				'affiliate_name' => array( 'type' => 'string' ),
				'referrals'      => array(
					'type'        => 'array',
					'description' => __( 'IDs of the referrals this payout covers.', 'affiliate-wp' ),
					'items'       => array( 'type' => 'integer' ),
				),
				'amount'         => array( 'type' => 'number' ),
				'payout_method'  => array( 'type' => 'string' ),
				'status'         => array( 'type' => 'string' ),
				'failure_class'  => array(
					'type'        => 'string',
					'description' => __( 'Why the payout failed, empty unless status is failed.', 'affiliate-wp' ),
				),
				'date'           => array(
					'type'        => 'string',
					'description' => __( 'UTC datetime in YYYY-MM-DD HH:MM:SS format.', 'affiliate-wp' ),
				),
			),
		);
	}

	/**
	 * Formats a visit. The visitor IP is deliberately left out.
	 *
	 * @since 2.37.0
	 *
	 * @param \AffWP\Visit $visit Visit object.
	 * @return array
	 */
	public static function visit( $visit ) {
		return array(
			'visit_id'     => (int) $visit->ID,
			'affiliate_id' => (int) $visit->affiliate_id,
			'referral_id'  => (int) $visit->referral_id,
			'converted'    => (int) $visit->referral_id > 0,
			'url'          => (string) $visit->url,
			'referrer'     => (string) $visit->referrer,
			'campaign'     => (string) $visit->campaign,
			'context'      => (string) $visit->context,
			'date'         => (string) $visit->date,
		);
	}

	/**
	 * Output schema for one visit.
	 *
	 * @since 2.37.0
	 *
	 * @return array
	 */
	public static function visit_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'visit_id'     => array( 'type' => 'integer' ),
				'affiliate_id' => array( 'type' => 'integer' ),
				'referral_id'  => array(
					'type'        => 'integer',
					'description' => __( 'Referral created from this visit, otherwise 0.', 'affiliate-wp' ),
				),
				'converted'    => array( 'type' => 'boolean' ),
				'url'          => array( 'type' => 'string' ),
				'referrer'     => array( 'type' => 'string' ),
				'campaign'     => array( 'type' => 'string' ),
				'context'      => array( 'type' => 'string' ),
				'date'         => array(
					'type'        => 'string',
					'description' => __( 'UTC datetime in YYYY-MM-DD HH:MM:SS format.', 'affiliate-wp' ),
				),
			),
		);
	}

	/**
	 * Formats a creative.
	 *
	 * @since 2.37.0
	 *
	 * @param \AffWP\Creative $creative Creative object.
	 * @return array
	 */
	public static function creative( $creative ) {
		return array(
			'creative_id' => (int) $creative->ID,
			'name'        => (string) $creative->name,
			'type'        => (string) $creative->type,
			'description' => (string) $creative->description,
			'url'         => (string) $creative->url,
			'text'        => (string) $creative->text,
			'image'       => (string) $creative->image,
			'status'      => (string) $creative->status,
			'date'        => (string) $creative->date,
		);
	}

	/**
	 * Output schema for one creative.
	 *
	 * @since 2.37.0
	 *
	 * @return array
	 */
	public static function creative_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'creative_id' => array( 'type' => 'integer' ),
				'name'        => array( 'type' => 'string' ),
				'type'        => array( 'type' => 'string' ),
				'description' => array( 'type' => 'string' ),
				'url'         => array(
					'type'        => 'string',
					'description' => __( 'Landing page the creative links to.', 'affiliate-wp' ),
				),
				'text'        => array( 'type' => 'string' ),
				'image'       => array( 'type' => 'string' ),
				'status'      => array( 'type' => 'string' ),
				'date'        => array(
					'type'        => 'string',
					'description' => __( 'UTC datetime in YYYY-MM-DD HH:MM:SS format.', 'affiliate-wp' ),
				),
			),
		);
	}

	/**
	 * Formats a campaign.
	 *
	 * @since 2.37.0
	 *
	 * @param \AffWP\Campaign $campaign Campaign object.
	 * @param float           $earnings Paid plus unpaid referral amount for this campaign.
	 * @return array
	 */
	public static function campaign( $campaign, $earnings = 0.0 ) {
		return array(
			'campaign_id'     => (int) $campaign->campaign_id,
			'campaign'        => (string) $campaign->campaign,
			'affiliate_id'    => (int) $campaign->affiliate_id,
			'affiliate_name'  => (string) affwp_get_affiliate_name( $campaign->affiliate_id ),
			'visits'          => (int) $campaign->visits,
			'unique_visits'   => (int) $campaign->unique_visits,
			'referrals'       => (int) $campaign->referrals,
			'conversion_rate' => round( (float) $campaign->conversion_rate, 2 ),
			'earnings'        => self::amount( $earnings ),
		);
	}

	/**
	 * Output schema for one campaign.
	 *
	 * @since 2.37.0
	 *
	 * @return array
	 */
	public static function campaign_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'campaign_id'     => array( 'type' => 'integer' ),
				'campaign'        => array(
					'type'        => 'string',
					'description' => __( 'Campaign slug from the affiliate link, e.g. spring-sale.', 'affiliate-wp' ),
				),
				'affiliate_id'    => array( 'type' => 'integer' ),
				'affiliate_name'  => array( 'type' => 'string' ),
				'visits'          => array( 'type' => 'integer' ),
				'unique_visits'   => array( 'type' => 'integer' ),
				'referrals'       => array( 'type' => 'integer' ),
				'conversion_rate' => array(
					'type'        => 'number',
					'description' => __( 'Converted visits as a percentage of all visits for this campaign.', 'affiliate-wp' ),
				),
				'earnings'        => array(
					'type'        => 'number',
					'description' => __( 'Paid plus unpaid commission amount attributed to this campaign.', 'affiliate-wp' ),
				),
			),
		);
	}

	/**
	 * Formats an affiliate group.
	 *
	 * @since 2.37.0
	 *
	 * @param \AffiliateWP\Groups\Group $group Group object.
	 * @return array
	 */
	public static function affiliate_group( $group ) {
		$rate      = $group->get_meta( 'rate', '' );
		$rate_type = $group->get_meta( 'rate-type', '' );
		$default   = $group->get_meta( 'default-group', false );
		$count     = 0;

		try {
			$connected = affiliate_wp()->connections->get_connected( 'affiliate', 'group', $group->get_id(), 'count' );
			$count     = is_numeric( $connected ) ? (int) $connected : 0;
		} catch ( \Exception $e ) {
			$count = 0;
		}

		return array(
			'group_id'        => (int) $group->get_id(),
			'name'            => (string) $group->get_title(),
			'rate'            => is_scalar( $rate ) ? (string) $rate : '',
			'rate_type'       => is_string( $rate_type ) ? $rate_type : '',
			'has_custom_rate' => '' !== ( is_scalar( $rate ) ? (string) $rate : '' ),
			'is_default'      => (bool) $default,
			'affiliates'      => $count,
		);
	}

	/**
	 * Output schema for one affiliate group.
	 *
	 * @since 2.37.0
	 *
	 * @return array
	 */
	public static function affiliate_group_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'group_id'        => array( 'type' => 'integer' ),
				'name'            => array( 'type' => 'string' ),
				'rate'            => array(
					'type'        => 'string',
					'description' => __( 'Group referral rate when the group overrides the program default. Empty otherwise.', 'affiliate-wp' ),
				),
				'rate_type'       => array( 'type' => 'string' ),
				'has_custom_rate' => array( 'type' => 'boolean' ),
				'is_default'      => array(
					'type'        => 'boolean',
					'description' => __( 'True when new affiliates are placed in this group.', 'affiliate-wp' ),
				),
				'affiliates'      => array(
					'type'        => 'integer',
					'description' => __( 'Number of affiliates currently in this group.', 'affiliate-wp' ),
				),
			),
		);
	}

	/**
	 * Formats one affiliate coupon from the details an integration reports.
	 *
	 * @since 2.37.0
	 *
	 * @param int    $coupon_id Coupon ID: a post ID for manual coupons, an AffiliateWP coupon ID for dynamic ones.
	 * @param string $type      Coupon type, manual or dynamic.
	 * @param array  $details   Coupon details with code, amount, and integration keys.
	 * @return array
	 */
	public static function coupon( $coupon_id, $type, array $details ) {
		$amount = isset( $details['amount'] ) ? (string) $details['amount'] : '';

		return array(
			'coupon_id'   => (int) $coupon_id,
			'code'        => (string) $details['code'],
			'type'        => (string) $type,
			// Integrations format the amount as display HTML, e.g. wc_price() markup.
			'discount'    => trim( html_entity_decode( wp_strip_all_tags( $amount ), ENT_QUOTES, get_bloginfo( 'charset' ) ) ),
			'integration' => isset( $details['integration'] ) ? (string) $details['integration'] : '',
		);
	}

	/**
	 * Output schema for one affiliate coupon.
	 *
	 * @since 2.37.0
	 *
	 * @return array
	 */
	public static function coupon_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'coupon_id'   => array( 'type' => 'integer' ),
				'code'        => array( 'type' => 'string' ),
				'type'        => array(
					'type'        => 'string',
					'description' => __( 'manual for a store coupon assigned to the affiliate, dynamic for one AffiliateWP generated for them.', 'affiliate-wp' ),
					'enum'        => affwp_get_coupon_types(),
				),
				'discount'    => array(
					'type'        => 'string',
					'description' => __( 'Discount the coupon gives, formatted for display, e.g. 20% or $10.00.', 'affiliate-wp' ),
				),
				'integration' => array(
					'type'        => 'string',
					'description' => __( 'Integration the coupon belongs to, e.g. woocommerce.', 'affiliate-wp' ),
				),
			),
		);
	}

	/**
	 * Output schema for date-scoped referral, earnings, and visit totals.
	 *
	 * @since 2.37.0
	 *
	 * @return array
	 */
	public static function period_stats_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'referrals' => array(
					'type'       => 'object',
					'properties' => array(
						'total'    => array( 'type' => 'integer' ),
						'paid'     => array( 'type' => 'integer' ),
						'unpaid'   => array( 'type' => 'integer' ),
						'pending'  => array( 'type' => 'integer' ),
						'rejected' => array( 'type' => 'integer' ),
					),
				),
				'earnings'  => array(
					'type'       => 'object',
					'properties' => array(
						'paid'   => array( 'type' => 'number' ),
						'unpaid' => array( 'type' => 'number' ),
					),
				),
				'visits'    => array(
					'type'       => 'object',
					'properties' => array(
						'total'           => array( 'type' => 'integer' ),
						'converted'       => array( 'type' => 'integer' ),
						'conversion_rate' => array(
							'type'        => 'number',
							'description' => __( 'Converted visits as a percentage of all visits.', 'affiliate-wp' ),
						),
					),
				),
			),
		);
	}
}
