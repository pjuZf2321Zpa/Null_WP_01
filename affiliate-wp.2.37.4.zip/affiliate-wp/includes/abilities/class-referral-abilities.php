<?php
/**
 * Abilities API: referrals.
 *
 * @package     AffiliateWP
 * @subpackage  Abilities
 * @copyright   Copyright (c) 2026, Awesome Motive, Inc.
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.37.0
 */

namespace AffWP\Abilities;

/**
 * Abilities for reading and managing referrals.
 *
 * @since 2.37.0
 */
class Referral_Abilities extends Ability_Group {

	/**
	 * {@inheritDoc}
	 */
	public function get_definitions() {
		$statuses = array_keys( affwp_get_referral_statuses() );
		$types    = affwp_get_referral_types( true );

		return array(
			'list-referrals'      => $this->read(
				array(
					'label'               => __( 'List referrals', 'affiliate-wp' ),
					'description'         => __( 'Lists referrals (commissions) with their amount, status, type, and the affiliate who earned them. Filter by affiliate, status, type, integration, campaign, order reference, or date range.', 'affiliate-wp' ),
					'permission_callback' => $this->can( 'manage_referrals' ),
					'execute_callback'    => array( $this, 'list_referrals' ),
					'input_schema'        => $this->object_schema(
						array_merge(
							array(
								'referral_id'  => array(
									'type'        => 'integer',
									'description' => __( 'Return only this referral.', 'affiliate-wp' ),
									'minimum'     => 1,
								),
								'affiliate_id' => array(
									'type'        => 'integer',
									'description' => __( 'Only referrals earned by this affiliate.', 'affiliate-wp' ),
									'minimum'     => 1,
								),
								'status'       => array(
									'type'        => 'string',
									'description' => __( 'Only referrals with this status.', 'affiliate-wp' ),
									'enum'        => $statuses,
								),
								'type'         => array(
									'type'        => 'string',
									'description' => __( 'Only referrals of this type.', 'affiliate-wp' ),
									'enum'        => $types,
								),
								'context'      => array(
									'type'        => 'string',
									'description' => __( 'Only referrals from this integration, e.g. woocommerce.', 'affiliate-wp' ),
								),
								'campaign'     => array(
									'type'        => 'string',
									'description' => __( 'Only referrals attributed to this campaign.', 'affiliate-wp' ),
								),
								'reference'    => array(
									'type'        => 'string',
									'description' => __( 'Only referrals with this order or entry reference.', 'affiliate-wp' ),
								),
								'search'       => array(
									'type'        => 'string',
									'description' => __( 'Partial match against the referral description. Also makes the type, integration, campaign, and reference filters partial matches.', 'affiliate-wp' ),
								),
								'date'         => $this->date_range_property( __( 'Only referrals created in this date range.', 'affiliate-wp' ) ),
							),
							$this->sort_properties( array( 'referral_id', 'date', 'amount', 'status', 'affiliate_id' ), 'referral_id' ),
							$this->pagination_properties()
						)
					),
					'output_schema'       => $this->list_schema( 'referrals', Formatter::referral_schema() ),
				)
			),
			'add-referral'        => $this->write(
				array(
					'label'               => __( 'Add referral', 'affiliate-wp' ),
					'description'         => __( 'Creates a manual referral (commission) for an affiliate. Use this to credit an affiliate for a sale or lead that was not tracked automatically.', 'affiliate-wp' ),
					'permission_callback' => $this->can( 'manage_referrals' ),
					'execute_callback'    => array( $this, 'add_referral' ),
					'input_schema'        => $this->object_schema(
						array(
							'affiliate_id' => array(
								'type'        => 'integer',
								'description' => __( 'Affiliate who earns the commission.', 'affiliate-wp' ),
								'minimum'     => 1,
							),
							'amount'       => array(
								'type'        => 'number',
								'description' => __( 'Commission amount in the store currency.', 'affiliate-wp' ),
								'minimum'     => 0,
							),
							'description'  => array(
								'type'        => 'string',
								'description' => __( 'What the referral is for, shown to the affiliate.', 'affiliate-wp' ),
							),
							'reference'    => array(
								'type'        => 'string',
								'description' => __( 'Order number or other external reference.', 'affiliate-wp' ),
							),
							'status'       => array(
								'type'        => 'string',
								'description' => __( 'Initial status.', 'affiliate-wp' ),
								'enum'        => array( 'unpaid', 'pending', 'rejected' ),
								'default'     => 'unpaid',
							),
							'type'         => array(
								'type'        => 'string',
								'description' => __( 'Referral type.', 'affiliate-wp' ),
								'enum'        => $types,
								'default'     => 'sale',
							),
							'campaign'     => array(
								'type'        => 'string',
								'description' => __( 'Campaign to attribute the referral to.', 'affiliate-wp' ),
							),
						),
						array( 'affiliate_id', 'amount' )
					),
					'output_schema'       => Formatter::referral_schema(),
				),
				false,
				false
			),
			'update-referral'     => $this->write(
				array(
					'label'               => __( 'Update referral', 'affiliate-wp' ),
					'description'         => __( 'Changes a referral\'s amount, description, order reference, or campaign. The affiliate\'s paid or unpaid earnings follow the new amount. The amount cannot change once the referral is part of a payout. To cancel a commission, use set-referral-status to reject it.', 'affiliate-wp' ),
					'permission_callback' => $this->can( 'manage_referrals' ),
					'execute_callback'    => array( $this, 'update_referral' ),
					'input_schema'        => $this->object_schema(
						array(
							'referral_id' => array(
								'type'        => 'integer',
								'description' => __( 'Referral ID.', 'affiliate-wp' ),
								'minimum'     => 1,
							),
							'amount'      => array(
								'type'             => 'number',
								'description'      => __( 'New commission amount in the store currency.', 'affiliate-wp' ),
								'minimum'          => 0,
								'exclusiveMinimum' => true,
							),
							'description' => array(
								'type'        => 'string',
								'description' => __( 'What the referral is for, shown to the affiliate.', 'affiliate-wp' ),
								'minLength'   => 1,
							),
							'reference'   => array(
								'type'        => 'string',
								'description' => __( 'Order number or other external reference.', 'affiliate-wp' ),
								'minLength'   => 1,
							),
							'campaign'    => array(
								'type'        => 'string',
								'description' => __( 'Campaign to attribute the referral to.', 'affiliate-wp' ),
								'minLength'   => 1,
							),
						),
						array( 'referral_id' )
					),
					'output_schema'       => Formatter::referral_schema(),
				),
				true,
				true
			),
			'set-referral-status' => $this->write(
				array(
					'label'               => __( 'Set referral status', 'affiliate-wp' ),
					'description'         => __( 'Changes a referral\'s status. Marking a referral paid adds its amount to the affiliate\'s paid earnings; marking it rejected removes it from what they are owed. Prefer paying affiliates through the Payouts screen so a payout record is created.', 'affiliate-wp' ),
					'permission_callback' => $this->can( 'manage_referrals' ),
					'execute_callback'    => array( $this, 'set_status' ),
					'input_schema'        => $this->object_schema(
						array(
							'referral_id' => array(
								'type'        => 'integer',
								'description' => __( 'Referral ID.', 'affiliate-wp' ),
								'minimum'     => 1,
							),
							'status'      => array(
								'type'        => 'string',
								'description' => __( 'New status.', 'affiliate-wp' ),
								'enum'        => $statuses,
							),
						),
						array( 'referral_id', 'status' )
					),
					'output_schema'       => array(
						'type'       => 'object',
						'properties' => array(
							'referral_id'     => array( 'type' => 'integer' ),
							'previous_status' => array( 'type' => 'string' ),
							'status'          => array( 'type' => 'string' ),
						),
					),
				),
				true,
				true
			),
		);
	}

	/**
	 * Lists referrals.
	 *
	 * @since 2.37.0
	 *
	 * @param array|null $input Ability input.
	 * @return array
	 */
	public function list_referrals( $input = null ) {
		$input = is_array( $input ) ? $input : array();
		$args  = $this->base_query_args( $input );

		foreach ( array( 'referral_id', 'affiliate_id' ) as $key ) {
			if ( ! empty( $input[ $key ] ) ) {
				$args[ $key ] = absint( $input[ $key ] );
			}
		}

		foreach ( array( 'status', 'type', 'context', 'campaign', 'reference' ) as $key ) {
			if ( ! empty( $input[ $key ] ) ) {
				$args[ $key ] = sanitize_text_field( $input[ $key ] );
			}
		}

		// The query's `search` is a flag that turns string filters into partial matches.
		if ( ! empty( $input['search'] ) ) {
			$args['description'] = sanitize_text_field( $input['search'] );
			$args['search']      = true;
		}

		$referrals = affiliate_wp()->referrals->get_referrals( $args );
		$total     = affiliate_wp()->referrals->count( array_diff_key( $args, array_flip( array( 'number', 'offset', 'orderby', 'order' ) ) ) );

		return array(
			'total'     => (int) $total,
			'referrals' => array_map( array( Formatter::class, 'referral' ), $referrals ),
		);
	}

	/**
	 * Adds a manual referral.
	 *
	 * @since 2.37.0
	 *
	 * @param array|null $input Ability input.
	 * @return array|\WP_Error
	 */
	public function add_referral( $input = null ) {
		$input     = is_array( $input ) ? $input : array();
		$affiliate = affwp_get_affiliate( absint( $input['affiliate_id'] ) );

		if ( ! $affiliate ) {
			return $this->not_found( __( 'No affiliate exists with that ID.', 'affiliate-wp' ) );
		}

		$referral_id = affwp_add_referral(
			array(
				'affiliate_id' => $affiliate->ID,
				'amount'       => affwp_sanitize_amount( $input['amount'] ),
				'description'  => isset( $input['description'] ) ? $input['description'] : '',
				'reference'    => isset( $input['reference'] ) ? $input['reference'] : '',
				'campaign'     => isset( $input['campaign'] ) ? $input['campaign'] : '',
				'status'       => ! empty( $input['status'] ) ? sanitize_key( $input['status'] ) : 'unpaid',
				'type'         => ! empty( $input['type'] ) ? sanitize_key( $input['type'] ) : 'sale',
				'context'      => 'abilities_api',
			)
		);

		if ( ! $referral_id ) {
			return new \WP_Error( 'affwp_ability_add_failed', __( 'The referral could not be added.', 'affiliate-wp' ) );
		}

		return Formatter::referral( affwp_get_referral( $referral_id ) );
	}

	/**
	 * Updates a referral's amount or details.
	 *
	 * @since 2.37.0
	 *
	 * @param array|null $input Ability input.
	 * @return array|\WP_Error
	 */
	public function update_referral( $input = null ) {
		$input    = is_array( $input ) ? $input : array();
		$referral = affwp_get_referral( absint( $input['referral_id'] ) );

		if ( ! $referral ) {
			return $this->not_found( __( 'No referral exists with that ID.', 'affiliate-wp' ) );
		}

		$data = array_intersect_key( $input, array_flip( array( 'amount', 'description', 'reference', 'campaign' ) ) );

		if ( empty( $data ) ) {
			return $this->invalid( 'affwp_ability_nothing_to_update', __( 'Provide an amount, description, reference, or campaign to change.', 'affiliate-wp' ) );
		}

		// Matches the referral edit screen, which locks the amount once a payout includes it.
		if ( isset( $data['amount'] ) && affwp_get_payout( $referral->payout_id ) ) {
			return $this->invalid( 'affwp_ability_referral_in_payout', __( 'The amount cannot change because this referral is part of a payout.', 'affiliate-wp' ), 409 );
		}

		if ( ! affiliate_wp()->referrals->update_referral( $referral->ID, $data ) ) {
			return new \WP_Error( 'affwp_ability_update_failed', __( 'The referral could not be updated.', 'affiliate-wp' ) );
		}

		return Formatter::referral( affwp_get_referral( $referral->ID ) );
	}

	/**
	 * Sets a referral's status.
	 *
	 * @since 2.37.0
	 *
	 * @param array|null $input Ability input.
	 * @return array|\WP_Error
	 */
	public function set_status( $input = null ) {
		$input    = is_array( $input ) ? $input : array();
		$referral = affwp_get_referral( absint( $input['referral_id'] ) );

		if ( ! $referral ) {
			return $this->not_found( __( 'No referral exists with that ID.', 'affiliate-wp' ) );
		}

		$previous = $referral->status;
		$status   = sanitize_key( $input['status'] );

		if ( 'paid' === $status && $previous !== $status ) {
			affwp_reattach_referral_to_detached_payout( $referral );
		}

		if ( $previous !== $status && ! affwp_set_referral_status( $referral, $status ) ) {
			return new \WP_Error( 'affwp_ability_status_failed', __( 'The referral status could not be changed.', 'affiliate-wp' ) );
		}

		return array(
			'referral_id'     => (int) $referral->ID,
			'previous_status' => (string) $previous,
			'status'          => $status,
		);
	}
}
