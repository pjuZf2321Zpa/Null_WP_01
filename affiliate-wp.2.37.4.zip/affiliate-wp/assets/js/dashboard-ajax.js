jQuery(document).ready(function($){

  if($('#affwp_dashboard_overview').length){
    $.ajax({
      type: 'GET',
      data: {
        action: 'affwp_dashboard_overview',
        nonce: ( typeof affwpDashboardAjax !== 'undefined' ) ? affwpDashboardAjax.nonce : '',
      },
      url: ajaxurl,
      success: function(response){
        $('#affwp_dashboard_overview .inside').html(response);
      }
    });
  }
});