document.addEventListener("DOMContentLoaded", function() {

	const widgetContainers = document.querySelectorAll('.affiliate-signup');

	widgetContainers.forEach(function(widgetContainer) {
		widgetContainer.shadowReadyDispatched = false;
		setupWidget(widgetContainer);
	});

	function setupWidget(widgetContainer) {
		if (!widgetContainer.shadowRoot) {
			let shadow = widgetContainer.attachShadow({ mode: 'open' });
			loadInitialWidget(shadow, widgetContainer);
		}
	}

	function loadInitialWidget(shadow, widgetContainer) {

		fetch(affiliateWidgetParams.cssUrl)
			.then(res => res.text())
			.then((css) => {
				const style = document.createElement('style');
				style.textContent = css;
				shadow.appendChild(style);

				const container = document.createElement('div');
				container.innerHTML = affiliateWidgetParams.widgetHtml;
				shadow.appendChild(container);
				widgetAttachFormSubmitEvent(shadow);

				/*
				 * The confirmation view can arrive already rendered by the server — a new
				 * affiliate reloading within their 24-hour window — and until now only the
				 * AJAX path attached the Copy handler, leaving that button dead on reload.
				 */
				attachCopyLinkButtonEventListener(shadow);

			})
			.then(() => {
				if (!widgetContainer.shadowReadyDispatched) {
					window.dispatchEvent(new Event('shadowReady'));
					widgetContainer.shadowReadyDispatched = true;
				}
			});
	}

	function widgetAttachFormSubmitEvent(shadow) {
		const formInsideShadow = shadow.querySelector('form');
		if (formInsideShadow) {
			formInsideShadow.addEventListener('submit', function (e) {
				e.preventDefault();
				const ctaButtonInsideShadow = shadow.querySelector('#signup-affiliate');
				if (ctaButtonInsideShadow) {
					buttonLoadingState(ctaButtonInsideShadow);
					registerAffiliate(shadow);
				}
			});
		}
	}

	/**
	 * Button Loading State.
	 */
	function buttonLoadingState(ctaButtonInsideShadow) {
		const svgSpinner = ctaButtonInsideShadow.querySelector('svg');
		const originalButtonText = ctaButtonInsideShadow.querySelector('#originalButtonText');
		const processingText = ctaButtonInsideShadow.querySelector('#processingText');

		if (svgSpinner) {
			svgSpinner.removeAttribute('hidden');
		}

		if (processingText) {
			processingText.removeAttribute('hidden');
		}

		if (originalButtonText) {
			originalButtonText.setAttribute('hidden', true);
		}

		ctaButtonInsideShadow.disabled = true;
		ctaButtonInsideShadow.classList.add('cursor-not-allowed');
	}

	/**
	 * Register new affiliate via AJAX.
	 */
	function registerAffiliate(shadow) {
		const formInsideShadow = shadow.querySelector('form');
		const formData = new FormData(formInsideShadow);

		// Get the order key from the URL
		const orderKey = getOrderKeyFromURL();

		formData.append('action', 'affiliate_signup');

		/*
		 * Only when there is one. FormData stringifies whatever it is given, so appending a
		 * null key sent the literal text "null" — which the server read as a real key, and
		 * then looked up an order that could not exist. On EDD that suppressed the fallback
		 * to the purchase session, which is the only way a confirmation page identifies the
		 * order, so every guest signup failed.
		 */
		if (orderKey) {
			formData.append('order_key', orderKey);
		}
		formData.append('nonce', affiliateWidgetParams.nonce);

		fetch(affiliateWidgetParams.ajaxUrl, {
			method: 'POST',
			body: formData,
		})
		.then(response => {
			if (!response.ok) {
				showError(shadow);
				throw new Error('Network response was not ok.');
			}
			return response.json();
		})
		.then(data => {
			if (data.success) {
				// A pending claim has no link to show, so it gets its own state.
				if (data.data && 'pending' === data.data.status) {
					showPending(shadow, data.data);
				} else {
					showConfirmation(data, shadow);
				}
			} else {
				showError(shadow, data && data.data ? data.data.message : '');
			}
		})
		.catch(error => {
			console.error('Error during registration:', error);
			showError(shadow);
		});
	}

	/**
	 * Show the pending state.
	 *
	 * The claim succeeded, but the program reviews affiliates before they can earn — and a
	 * pending affiliate's link records no visits, so there is deliberately no link here.
	 *
	 * @param {ShadowRoot} shadow The widget's shadow root.
	 * @param {Object}     data   Response data carrying the heading and message.
	 */
	function showPending(shadow, data) {
		const initialView = shadow.querySelector('#initial-view');
		if (initialView) {
			initialView.style.display = 'none';
		}

		const heading = shadow.querySelector('[data-affwp-field="pending-heading"]');
		if (heading && data.heading) {
			heading.textContent = data.heading;
		}

		const message = shadow.querySelector('[data-affwp-field="pending-text"]');
		if (message && data.message) {
			message.textContent = data.message;
		}

		const pendingView = shadow.querySelector('#pending-view');
		if (pendingView) {
			pendingView.style.display = 'block';
		}
	}

	/**
	 * Show the error state.
	 *
	 * The server says why it refused — the order could not be verified, the nonce failed,
	 * the mode is off — and that was being thrown away in favour of one generic sentence.
	 * A customer cannot act on "there was a problem", and nor can anyone debugging it.
	 *
	 * @param {ShadowRoot} shadow The widget's shadow root.
	 * @param {string}     reason Optional message from the server.
	 */
	function showError(shadow, reason) {
		const initialViewElement = shadow.querySelector('#initial-view');
		if (initialViewElement) {
			initialViewElement.style.display = 'none';
		}

		const errorViewElement = shadow.querySelector('#error-view');
		if (errorViewElement) {
			errorViewElement.style.display = 'block';
		}

		const messageElement = shadow.querySelector('#error-message');
		if (messageElement && reason) {
			messageElement.textContent = reason;
		}
	}

	/**
	 * Extract the order key from the URL.
	 */
	function getOrderKeyFromURL() {
		const urlParams = new URLSearchParams(window.location.search);
		return urlParams.get('key');
	}

	/**
	 * Show Confirmation
	 */
	function showConfirmation(response, shadowRoot) {

		if (!shadowRoot) {
			console.error("shadowRoot is undefined in showConfirmation");
			return;
		}

		// Make sure the data property exists and contains the expected affiliate_link
		if (response && response.data && response.data.affiliate_link) {
			// Show the Confirmation and hide the initial view.
			const confirmationView = shadowRoot.querySelector('#confirmation-view');
			if (confirmationView) {
				// Replace the placeholder with the actual affiliate link
				confirmationView.innerHTML = confirmationView.innerHTML.replace('{affiliateLink}', response.data.affiliate_link);
				confirmationView.style.display = 'block';
			}

			const initialView = shadowRoot.querySelector('#initial-view');
			if (initialView) {
				initialView.style.display = 'none';
			}
		} else {
			// If the affiliate_link is not in the expected format, handle it accordingly (e.g., show an error message)
			console.error("The affiliate_link is not available in the response data:", response);
		}

		// Attach the copy link button event listener
		attachCopyLinkButtonEventListener(shadowRoot);
	};

	/**
	 * Attach event listener to the copy link button
	 */
	function attachCopyLinkButtonEventListener(shadow) {

		// Copy the affiliate link
		function copyAffiliateLink() {
			const affiliateLinkInput = shadow.querySelector('#affiliateLink');
			if (affiliateLinkInput) {
				const affiliateLink = affiliateLinkInput.value;
				navigator.clipboard.writeText(affiliateLink).then(function() {
					affiliateLinkInput.select();
				}).catch(function(error) {
					console.error('Copy failed', error);
				});
			}
		}

		const copyLinkButton = shadow.querySelector('#copyLinkButton');
		if (copyLinkButton) {
			copyLinkButton.addEventListener('click', function() {
				copyAffiliateLink();
				const originalText = copyLinkButton.textContent;
				copyLinkButton.textContent = affiliateWidgetParams.data.button_copied_text;

				setTimeout(() => {
					copyLinkButton.textContent = originalText;
				}, 3000);
			});
		}
	}

	function handleShadowReady(event) {
		widgetContainers.forEach(function(widgetContainer) {
			if (widgetContainer.shadowRoot && !widgetContainer.shadowReadyDispatched) {
				widgetContainer.shadowReadyDispatched = true;
			}
		});
	}

	widgetContainers.forEach(function(widgetContainer) {
		if (!widgetContainer.shadowReadyDispatched) {
			window.addEventListener('shadowReady', () => handleShadowReady(null, widgetContainer));
		} else {
			handleShadowReady(null, widgetContainer);
		}
	});

});