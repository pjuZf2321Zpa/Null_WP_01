<?php
namespace ElementsKit;

defined( 'ABSPATH' ) || exit;

class ElementsKit_HeaderFooterBuilder_Api extends \ElementsKit_Lite\Core\Handler_Api {

	public function config(){
		$this->prefix = 'my-template';
		$this->param  = "/(?P<id>\w+)/";
	}

	public function get_update(){

		if( !current_user_can( 'manage_options' ) ){
			return;
		}

		$id = $this->request['id'];
		$open_editor = $this->request['open_editor'];

		$title = ($this->request['title'] == '') ? ('ElementsKit Template #' . time()) : $this->request['title'];
		$activation = $this->request['activation'];
		$type = $this->request['type'];
		$condition_a = ($type == 'section') ? '' : $this->request['condition_a'];

		// singular conditions
		$condition_singular = ($type == 'section') ? '' : $this->request['condition_singular'];
		$condition_singular_id = ($type == 'section') ? '' : (is_array($this->request['condition_singular_id']) ? implode(',', $this->request['condition_singular_id']) : $this->request['condition_singular_id']);

		// archive conditions
		$condition_archive = ($type == 'section') ? '' : $this->request['condition_archive'];
		$condition_archive_id = ($type == 'section') ? '' : (is_array($this->request['condition_archive_id']) ? implode(',', $this->request['condition_archive_id']) : $this->request['condition_archive_id']);

		$post_data = array(
			'post_title' => $title,
			'post_status' => 'publish',
			'post_type' => 'elementskit_template',
		);

		$post = get_post($id);

		if($post == null) {
			// $post_data['post_author'] = $this->request['post_author'];
			$id = wp_insert_post($post_data);
		} else{
			$post_data['ID'] = $id;
			wp_update_post( $post_data );
		}

		update_post_meta( $id, '_wp_page_template', 'elementor_canvas' );
		update_post_meta( $id, 'elementskit_template_activation', $activation );
		update_post_meta( $id, 'elementskit_template_type', $type );
		update_post_meta( $id, 'elementskit_template_condition_a', $condition_a );

		// entire site condition has no extra metas
		if($condition_a === 'entire_site' || $condition_a === 'entire_shop') {
			// clear singular metas if not singular condition
			update_post_meta( $id, 'elementskit_template_condition_singular', '' );
			update_post_meta( $id, 'elementskit_template_condition_singular_id', '' );

			// clear archive metas if not archive condition
			update_post_meta( $id, 'elementskit_template_condition_archive', '' );
			update_post_meta( $id, 'elementskit_template_condition_archive_id', '' );
		}

		// singular condition metas
		if($condition_a === 'singular') {
			update_post_meta( $id, 'elementskit_template_condition_singular', $condition_singular );
			update_post_meta( $id, 'elementskit_template_condition_singular_id', $condition_singular_id );
		} else {
			// clear singular metas if not singular condition
			update_post_meta( $id, 'elementskit_template_condition_singular', '' );
			update_post_meta( $id, 'elementskit_template_condition_singular_id', '' );
		}

		// archive condition metas
		if($condition_a === 'archive') {
			update_post_meta( $id, 'elementskit_template_condition_archive', $condition_archive );
			update_post_meta( $id, 'elementskit_template_condition_archive_id', $condition_archive_id );
		} else {
			// clear archive metas if not archive condition
			update_post_meta( $id, 'elementskit_template_condition_archive', '' );
			update_post_meta( $id, 'elementskit_template_condition_archive_id', '' );
		}

		// if wpml is active and wpml not set for this post
		if ( defined( 'ICL_SITEPRESS_VERSION' ) ) {
			global $sitepress;
			$wpml_element_type = apply_filters( 'wpml_element_type', 'elementskit_template' );
			$sitepress->set_element_language_details( $id, $wpml_element_type, false, $sitepress->get_current_language(), null, false );
		}

		if($open_editor == 'true') {
			$url = get_admin_url() . '/post.php?post='.$id.'&action=elementor';
			wp_safe_redirect( $url );
			exit;
		} else {
			$condition_label = $condition_a;
			if ( $condition_label == 'singular' && $condition_singular != '' ) {
				$condition_label .= ' > ' . $condition_singular;
				if ( $condition_singular_id != '' && in_array( $condition_singular, [ 'selective' ] ) ) {
					$condition_label .= ' > ' . $condition_singular_id;
				}
			}

			if ( $condition_label == 'archive' && $condition_archive != '' ) {
				$condition_label .= ' > ' . $condition_archive;
				$alloed_archive_types = [ 'category', 'post_tag', 'product_brand', 'product_cat', 'product_tag' ];
				if ( $condition_archive_id != '' && in_array( $condition_archive, $alloed_archive_types ) ) {
					$condition_label .= ' > ' . $condition_archive_id;
				}
			}

			$cond_text = ucwords( str_replace('_', ' ', $condition_label ));

			return [
				'saved' => true,
				'data' => [
					'id' => $id,
					'title' => $title,
					'type' => $type,
					'activation' => $activation,
					'cond_text' => $cond_text,
					'type_html' => (ucfirst($type) . (($activation == 'yes')
						? ( '<span class="ekit-headerfooter-status ekit-headerfooter-status-active">'. esc_html__('Active', 'elementskit') .'</span>' )
						: ( '<span class="ekit-headerfooter-status ekit-headerfooter-status-inactive">'. esc_html__('Inactive', 'elementskit') .'</span>' ))),
				]
			];
		}
	}

	public function get_get(){
		if( !current_user_can( 'manage_options' ) ){
			return;
		}
		$id = $this->request['id'];
		$post = get_post($id);
		if($post != null){
			return [
				'title' => $post->post_title,
				'status' => $post->post_status,
				'activation' => get_post_meta($post->ID, 'elementskit_template_activation', true),
				'type' => get_post_meta($post->ID, 'elementskit_template_type', true),
				'condition_a' => get_post_meta($post->ID, 'elementskit_template_condition_a', true),
				'condition_singular' => get_post_meta($post->ID, 'elementskit_template_condition_singular', true),
				'condition_singular_id' => get_post_meta($post->ID, 'elementskit_template_condition_singular_id', true),
				'condition_archive' => get_post_meta($post->ID, 'elementskit_template_condition_archive', true),
				'condition_archive_id' => get_post_meta($post->ID, 'elementskit_template_condition_archive_id', true),
			];
		}
		return true;
	}

}
new ElementsKit_HeaderFooterBuilder_Api();
