<?php
/*
Plugin Name: Premium Addons PRO
Description: Premium Addons PRO Plugin Includes 36+ premium widgets & addons for Elementor Page Builder.
Plugin URI: https://premiumaddons.com
Version: 2.9.69
Author: Leap13
Elementor tested up to: 4.3
Elementor Pro tested up to: 4.3
Author URI: https://leap13.com/
Text Domain: premium-addons-pro
Domain Path: /languages
Requires at least: 6.6
Requires PHP: 7.4
*/

/**
 * Checking if WordPress is installed
 */
if ( ! function_exists( 'add_action' ) ) {
	die( 'WordPress not Installed' ); // if WordPress not installed kill the page.
}

if ( ! defined( 'ABSPATH' ) ) {
	exit; // No access of directly access.
}

update_option( 'papro_license_status', 'valid' );
update_option( 'papro_license_key', 'B5E0B5F8DD8689E6ACA49DD6E6E1A930' );
add_filter('pre_http_request', function($preempt, $args, $url) {
    if (strpos($url, 'premiumtemplates.io/wp-json/patemp/v2/template/') !== false) {
        $new_url = str_replace('premiumtemplates.io', 'premiumtemplates.gpltimes.com', $url);
        return wp_remote_request($new_url, $args);
    }   
    return $preempt;
}, 10, 3);

add_action('wp_ajax_get_papro_license_status66', function() {
    wp_send_json_success('valid');
}, 0);

define( 'PREMIUM_PRO_ADDONS_VERSION', '2.9.69' );
define( 'PREMIUM_PRO_ADDONS_STABLE_VERSION', '2.9.68' );
define( 'PREMIUM_PRO_ADDONS_URL', plugins_url( '/', __FILE__ ) );
define( 'PREMIUM_PRO_ADDONS_PATH', trailingslashit( plugin_dir_path( __FILE__ ) ) );
define( 'PREMIUM_PRO_ADDONS_FILE', __FILE__ );
define( 'PREMIUM_PRO_ADDONS_BASENAME', plugin_basename( PREMIUM_PRO_ADDONS_FILE ) );
define( 'PAPRO_ITEM_NAME', 'Premium Addons PRO' );
define( 'PAPRO_STORE_URL', 'https://my.leap13.com' );
define( 'PAPRO_ITEM_ID', 361 );

/*
 * Load plugin core file.
 */
require_once PREMIUM_PRO_ADDONS_PATH . 'includes/class-papro-core.php';
