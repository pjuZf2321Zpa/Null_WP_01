<?php
/**
 * License tab while Premium Addons Pro is active.
 *
 * Activation with inline errors, then the plan card and the upgrades left
 * for that plan. Styles live in the free plugin's admin.css under
 * #pa-license-settings.
 *
 * @package PremiumAddonsPro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use PremiumAddonsPro\Admin\Includes\Admin_Helper;
use PremiumAddons\Includes\Helper_Functions;

$offer_label = __( '30% OFF', 'premium-addons-pro' );

$upgrade_coupons = array(
	'unlimited-annual'   => 'SUMMER26UA',
	'single-lifetime'    => 'SUMMER26SL',
	'unlimited-lifetime' => 'SUMMER26UL',
);

$status     = Admin_Helper::get_license_status();
$is_active  = 'valid' === $status;
$plan       = $is_active ? Admin_Helper::get_license_plan() : null;
$plan_key   = $plan ? $plan['scope'] . '-' . $plan['term'] : '';
$last_error = isset( $_GET['sl_error'] ) ? sanitize_key( wp_unslash( $_GET['sl_error'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

if ( '' === $last_error && 'expired' === $status ) {
	$last_error = 'expired';
}

$error_message = isset( $_GET['message'] ) ? sanitize_text_field( wp_unslash( $_GET['message'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

$account_link = Helper_Functions::get_campaign_link( 'https://clients.leap13.com/', 'license-page', 'wp-dash', 'account', $plan_key ? $plan_key : 'inactive' );
$get_pro_link = Helper_Functions::get_campaign_link( 'https://premiumaddons.com/pro/#get-pa-pro', 'license-page', 'wp-dash', 'get-pro', 'inactive' );
$upgrade_link = Helper_Functions::get_campaign_link( 'https://premiumaddons.com/docs/upgrade-premium-addons-license/', 'license-page', 'wp-dash', 'upgrade-pro', $plan_key ? $plan_key : 'inactive' );

$plan_names = array(
	'single-annual'      => __( 'Single Site', 'premium-addons-pro' ),
	'unlimited-annual'   => __( 'Unlimited Sites', 'premium-addons-pro' ),
	'single-lifetime'    => __( 'Single Site Lifetime', 'premium-addons-pro' ),
	'unlimited-lifetime' => __( 'Unlimited Sites Lifetime', 'premium-addons-pro' ),
);

$upgrade_tiles = array(
	'unlimited-annual'   => array(
		'title' => __( 'Unlimited Sites', 'premium-addons-pro' ),
		'desc'  => __( 'Use this key on every site you build. Same key, no reactivation.', 'premium-addons-pro' ),
		'cta'   => __( 'Upgrade to Unlimited', 'premium-addons-pro' ),
	),
	'single-lifetime'    => array(
		'title' => __( 'Single Site Lifetime', 'premium-addons-pro' ),
		'desc'  => __( 'One payment, updates and support for good. No more renewals.', 'premium-addons-pro' ),
		'cta'   => __( 'Upgrade to Lifetime', 'premium-addons-pro' ),
	),
	'unlimited-lifetime' => array(
		'title' => __( 'Unlimited Sites Lifetime', 'premium-addons-pro' ),
		'desc'  => __( 'Every site you build, updates and support for good. No more renewals.', 'premium-addons-pro' ),
		'cta'   => __( 'Upgrade to Unlimited Lifetime', 'premium-addons-pro' ),
	),
);

$upgrade_paths = array(
	'single-annual'      => array( 'unlimited-annual', 'single-lifetime' ),
	'unlimited-annual'   => array( 'unlimited-lifetime' ),
	'single-lifetime'    => array( 'unlimited-lifetime' ),
	'unlimited-lifetime' => array(),
);

$tiles = isset( $upgrade_paths[ $plan_key ] ) ? $upgrade_paths[ $plan_key ] : array();

?>

<div class="pa-section-content">
	<div class="row">
		<div class="col-full">
			<div id="pa-license-settings" class="pa-settings-tab">

				<?php if ( ! $is_active ) : ?>

					<form class="pa-section-info-wrap pa-license-activate<?php echo in_array( $last_error, array( 'no_activations_left', 'expired' ), true ) ? ' pa-license-full' : ''; ?>" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<?php settings_fields( 'papro_license' ); ?>
						<?php wp_nonce_field( 'papro_nonce', 'papro_nonce' ); ?>
						<input type="hidden" name="action" value="papro_license_activate" />

						<div class="pa-section-info">
							<h4><?php esc_html_e( 'Activate Premium Addons Pro', 'premium-addons-pro' ); ?></h4>
							<p>
								<?php
								printf(
									/* translators: %s: link to the customer account. */
									esc_html__( 'Paste the license key from %s → License Keys. Activation turns on updates, the Premium Templates library and support for this site.', 'premium-addons-pro' ),
									'<a href="' . esc_url( $account_link ) . '" target="_blank">' . esc_html__( 'your account', 'premium-addons-pro' ) . '</a>'
								);
								?>
							</p>
							<label for="papro-license-key"><?php esc_html_e( 'License key', 'premium-addons-pro' ); ?></label>
							<div class="pa-license-field">
								<input id="papro-license-key" name="papro_license_key" type="text" class="regular-text<?php echo $last_error ? ' pa-license-input-error' : ''; ?>" placeholder="<?php esc_attr_e( 'Paste your license key', 'premium-addons-pro' ); ?>" <?php echo $last_error ? 'aria-describedby="pa-license-error"' : ''; ?> />
								<?php submit_button( __( 'Activate', 'premium-addons-pro' ), 'pa-btn', 'submit', false ); ?>
							</div>

							<?php if ( 'no_activations_left' === $last_error ) : ?>
								<div id="pa-license-error" class="pa-license-alert" role="alert">
									<strong><?php esc_html_e( 'This key is already active on its maximum number of sites', 'premium-addons-pro' ); ?></strong>
									<span><?php esc_html_e( 'Free a site from your account, or move to a license without a site limit.', 'premium-addons-pro' ); ?></span>
								</div>
							<?php elseif ( 'expired' === $last_error ) : ?>
								<div id="pa-license-error" class="pa-license-alert" role="alert">
									<strong><?php esc_html_e( 'This license has expired', 'premium-addons-pro' ); ?></strong>
									<span><?php esc_html_e( 'Pro keeps working, but updates, Premium Templates and support have stopped.', 'premium-addons-pro' ); ?></span>
								</div>
							<?php elseif ( $last_error && $error_message ) : ?>
								<div id="pa-license-error" class="pa-license-alert" role="alert">
									<strong><?php echo esc_html( $error_message ); ?></strong>
								</div>
							<?php endif; ?>
						</div>

						<?php if ( ! $last_error ) : ?>
							<div class="pa-section-info-cta">
								<span class="pa-section-info-label">
									<?php esc_html_e( 'No license yet?', 'premium-addons-pro' ); ?>
									<a href="<?php echo esc_url( $get_pro_link ); ?>" target="_blank"><?php esc_html_e( 'Get Premium Addons Pro', 'premium-addons-pro' ); ?></a>
								</span>
								<span class="pa-license-offer"><?php echo esc_html( $offer_label ); ?></span>
							</div>
						<?php endif; ?>
					</form>

					<?php if ( 'no_activations_left' === $last_error ) : ?>

						<div class="pa-section-info-wrap pa-license-tiles">
							<div class="pa-license-tile">
								<div class="pa-license-heading">
									<h4><?php echo esc_html( $upgrade_tiles['unlimited-annual']['title'] ); ?></h4>
									<span class="pa-license-offer"><?php echo esc_html( sprintf( /* translators: %s: offer label. */ __( '%s upgrades', 'premium-addons-pro' ), $offer_label ) ); ?></span>
								</div>
								<p><?php esc_html_e( 'Activate this key on every site you build. You pay only the difference from your current plan.', 'premium-addons-pro' ); ?></p>
								<a class="button pa-btn" href="<?php echo esc_url( $upgrade_link ); ?>" target="_blank"><?php echo esc_html( $upgrade_tiles['unlimited-annual']['cta'] ); ?></a>
							</div>
							<div class="pa-license-tile">
								<h4><?php esc_html_e( 'Keep the Single Site plan', 'premium-addons-pro' ); ?></h4>
								<p><?php esc_html_e( 'Deactivate the key on the other site from your account, then activate it here.', 'premium-addons-pro' ); ?></p>
								<a class="button pa-btn pa-btn-secondary" href="<?php echo esc_url( $account_link ); ?>" target="_blank"><?php esc_html_e( 'Manage active sites', 'premium-addons-pro' ); ?></a>
							</div>
						</div>

					<?php elseif ( 'expired' === $last_error ) : ?>

						<div class="pa-section-info-wrap pa-license-tiles">
							<div class="pa-license-tile">
								<h4><?php esc_html_e( 'Renew your license', 'premium-addons-pro' ); ?></h4>
								<p><?php esc_html_e( 'Same key, same plan. Updates and templates resume as soon as the renewal goes through.', 'premium-addons-pro' ); ?></p>
								<a class="button pa-btn" href="<?php echo esc_url( $account_link ); ?>" target="_blank"><?php esc_html_e( 'Renew now', 'premium-addons-pro' ); ?></a>
							</div>
							<div class="pa-license-tile">
								<div class="pa-license-heading">
									<h4><?php esc_html_e( 'Or switch to Lifetime', 'premium-addons-pro' ); ?></h4>
									<span class="pa-license-offer"><?php echo esc_html( sprintf( /* translators: %s: offer label. */ __( '%s upgrades', 'premium-addons-pro' ), $offer_label ) ); ?></span>
								</div>
								<p><?php esc_html_e( 'One payment, no more renewals. You pay the difference from your current plan instead of a renewal fee.', 'premium-addons-pro' ); ?></p>
								<a class="button pa-btn pa-btn-secondary" href="<?php echo esc_url( $upgrade_link ); ?>" target="_blank"><?php esc_html_e( 'Upgrade to Lifetime', 'premium-addons-pro' ); ?></a>
							</div>
						</div>

					<?php else : ?>

						<div class="pa-section-info-wrap">
							<div class="pa-section-info">
								<h4><?php esc_html_e( 'Activation unlocks', 'premium-addons-pro' ); ?></h4>
								<ul class="pa-license-list pa-license-checks">
									<li><svg class="pa-license-check" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><path d="M5 12l5 5L20 7"/></svg><?php esc_html_e( 'Plugin updates for Pro', 'premium-addons-pro' ); ?></li>
									<li><svg class="pa-license-check" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><path d="M5 12l5 5L20 7"/></svg><?php esc_html_e( 'Premium Templates library', 'premium-addons-pro' ); ?></li>
									<li><svg class="pa-license-check" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><path d="M5 12l5 5L20 7"/></svg><?php esc_html_e( 'White labeling', 'premium-addons-pro' ); ?></li>
									<li><svg class="pa-license-check" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><path d="M5 12l5 5L20 7"/></svg><?php esc_html_e( 'Priority support', 'premium-addons-pro' ); ?></li>
								</ul>
							</div>
							<div class="pa-section-info-cta">
								<span class="pa-section-info-label"><?php esc_html_e( 'Pro widgets already show in the editor; templates and updates wait for a valid key.', 'premium-addons-pro' ); ?></span>
							</div>
						</div>

					<?php endif; ?>

				<?php else : ?>

					<form class="pa-section-info-wrap pa-license-plan" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<?php settings_fields( 'papro_license' ); ?>
						<?php wp_nonce_field( 'papro_nonce', 'papro_nonce' ); ?>
						<input type="hidden" name="action" value="papro_license_deactivate" />

						<div class="pa-license-kv">
							<span class="pa-license-kv-label"><?php esc_html_e( 'Your plan', 'premium-addons-pro' ); ?></span>
							<span class="pa-license-kv-value">
								<?php
								echo esc_html( isset( $plan_names[ $plan_key ] ) ? sprintf( 'Premium Addons Pro · %s', $plan_names[ $plan_key ] ) : 'Premium Addons Pro' );
								?>
							</span>
							<span class="pa-license-status"><?php esc_html_e( 'Active', 'premium-addons-pro' ); ?></span>
						</div>
						<div class="pa-license-kv pa-license-kv-key">
							<span class="pa-license-kv-label"><?php esc_html_e( 'License key', 'premium-addons-pro' ); ?></span>
							<span class="pa-license-kv-value pa-license-key"><?php echo esc_html( Admin_Helper::get_encrypted_key() ); ?></span>
							<span class="pa-license-kv-sub"><?php esc_html_e( 'Activated on this site', 'premium-addons-pro' ); ?></span>
						</div>
						<?php submit_button( __( 'Deactivate', 'premium-addons-pro' ), 'pa-btn pa-btn-secondary', 'submit', false ); ?>
					</form>

					<?php if ( $tiles ) : ?>

						<div class="pa-section-info-wrap pa-license-upgrades">
							<div class="pa-license-heading">
								<h4><?php esc_html_e( 'Upgrade your license — pay only the difference', 'premium-addons-pro' ); ?></h4>
								<span class="pa-license-offer"><?php echo esc_html( sprintf( /* translators: %s: offer label. */ __( '%s upgrades', 'premium-addons-pro' ), $offer_label ) ); ?></span>
							</div>
							<div class="pa-license-tiles">
								<?php foreach ( $tiles as $tile_key ) : ?>
									<div class="pa-license-tile">
										<h4><?php echo esc_html( $upgrade_tiles[ $tile_key ]['title'] ); ?></h4>
										<p><?php echo esc_html( $upgrade_tiles[ $tile_key ]['desc'] ); ?></p>
										<a class="button pa-btn" href="<?php echo esc_url( $upgrade_link ); ?>" target="_blank"><?php echo esc_html( $upgrade_tiles[ $tile_key ]['cta'] ); ?></a>
										<span class="pa-license-coupon">
											<?php
											printf(
												/* translators: %s: coupon code. */
												esc_html__( 'Code %s at checkout', 'premium-addons-pro' ),
												'<strong>' . esc_html( $upgrade_coupons[ $tile_key ] ) . '</strong>'
											);
											?>
										</span>
									</div>
								<?php endforeach; ?>
							</div>
							<?php if ( 'single-annual' === $plan_key ) : ?>
								<p class="pa-license-more">
									<?php esc_html_e( 'Want both?', 'premium-addons-pro' ); ?>
									<a href="<?php echo esc_url( $upgrade_link ); ?>" target="_blank"><?php echo esc_html( $upgrade_tiles['unlimited-lifetime']['title'] ); ?></a>
									<?php
									printf(
										/* translators: %s: coupon code. */
										esc_html__( '— code %s at checkout.', 'premium-addons-pro' ),
										'<strong>' . esc_html( $upgrade_coupons['unlimited-lifetime'] ) . '</strong>'
									);
									?>
								</p>
							<?php endif; ?>
							<p class="pa-license-more"><?php esc_html_e( 'Upgrades happen in your account under License Keys → View Upgrades.', 'premium-addons-pro' ); ?></p>
						</div>

					<?php elseif ( 'unlimited-lifetime' === $plan_key ) : ?>

						<div class="pa-license-tiles pa-license-included">
							<div class="pa-section-info-wrap">
								<div class="pa-section-info">
									<h4><?php esc_html_e( 'Premium Templates', 'premium-addons-pro' ); ?></h4>
									<p><?php esc_html_e( 'Open the library from any Elementor page, or ask your AI client to insert a template through the MCP tools.', 'premium-addons-pro' ); ?></p>
								</div>
							</div>
							<div class="pa-section-info-wrap">
								<div class="pa-section-info">
									<h4><?php esc_html_e( 'White labeling', 'premium-addons-pro' ); ?></h4>
									<p><?php esc_html_e( 'Rename the plugin and hide this dashboard from clients.', 'premium-addons-pro' ); ?></p>
								</div>
							</div>
							<div class="pa-section-info-wrap">
								<div class="pa-section-info">
									<h4><?php esc_html_e( 'Priority support', 'premium-addons-pro' ); ?></h4>
									<p><?php esc_html_e( 'Support stays included. Open a ticket from your account when you need us.', 'premium-addons-pro' ); ?></p>
								</div>
								<div class="pa-section-info-cta">
									<a href="<?php echo esc_url( $account_link ); ?>" target="_blank"><?php esc_html_e( 'Contact support', 'premium-addons-pro' ); ?></a>
								</div>
							</div>
						</div>

					<?php else : ?>

						<div class="pa-section-info-wrap">
							<div class="pa-section-info">
								<h4><?php esc_html_e( 'Upgrade your license — pay only the difference', 'premium-addons-pro' ); ?></h4>
								<p><?php esc_html_e( 'Move to more sites or to a lifetime license from your account under License Keys → View Upgrades.', 'premium-addons-pro' ); ?></p>
							</div>
							<div class="pa-section-info-cta">
								<a class="button pa-btn" href="<?php echo esc_url( $upgrade_link ); ?>" target="_blank"><?php esc_html_e( 'See upgrade options', 'premium-addons-pro' ); ?></a>
							</div>
						</div>

					<?php endif; ?>

				<?php endif; ?>

			</div>
		</div>
	</div>
</div> <!-- End Section Content -->
