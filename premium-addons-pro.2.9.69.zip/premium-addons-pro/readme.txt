=== Premium Addons PRO ===
Contributors: leap13
Tags: elementor, elements, addons, elementor addon, elementor widget, elementor extensions, page builder, builder, visual editor, wordpress page builder
Requires at least: 6.6
Tested Up To: 7.1
Requires PHP: 7.4
Stable tag: 2.9.69
License: GPL v3.0
License URI: https://opensource.org/licenses/GPL-3.0

This is the PRO extension of Premium Addons for Elementor Plugin that includes Pro widgets and Addons for Elementor Page Builder.

== Description ==
This plugin is an extension to Premium Addons for Elementor Plugin that includes Pro Elementor widgets and Addons for Elementor Page Builder. Visit [Premium Addons Website](https://www.premiumaddons.com/) to check widgets and addons demos.

Premium Addons PRO plugin’s widgets are cross browser compatible and also fully responsive, Your website will rock on all browsers as well as tables and mobile devices.

When using Premium Addons’ widgets you will notice that it has more customization options than any other widget in other plugin.

Premium Addons PRO can be used only as a complement of Elementor page builder plugin as it’s not a standalone plugin.


### Features

* Fully Customizable Elements.
* Options panel for enabling desired elements only for faster performance.
* Free Support through online forums.


### Available Elements

1. [Premium Alert Box](https://premiumaddons.com/alert-box-widget-for-elementor-page-builder/)
2. [Premium Animated Container Gradient](https://premiumaddons.com/animated-section-gradients-for-elementor-page-builder/)
3. [Premium Behance Feed](https://premiumaddons.com/behance-feed-widget-for-elementor-page-builder/)
4. [Premium Charts](https://premiumaddons.com/elementor-charts-widget/)
5. [Premium Content Toggle](https://premiumaddons.com/elementor-content-toggle-widget/)
6. [Premium Divider](https://premiumaddons.com/dual-header-widget-for-elementor-page-builder/)
7. [Premium Facebook Feed](https://premiumaddons.com/facebook-feed-widget-for-elementor-page-builder-2/)
9. [Premium Facebook Reviews](https://premiumaddons.com/facebook-reviews-widget-for-elementor-page-builder/)
10. [Premium Flip Box](https://premiumaddons.com/flip-box-widget-for-elementor-page-builder/)
11. [Premium Google Reviews](https://premiumaddons.com/google-reviews-for-elementor-page-builder/)
12. [Premium Icon Box](https://premiumaddons.com/icon-box-widget-for-elementor-page-builder/)
13. [Premium iHover](https://premiumaddons.com/ihover-widget-for-elementor-page-builder/)
14. [Premium Image Accordion](https://premiumaddons.com/elementor-image-accordion-widget/)
15. [Premium Image Comparison](https://premiumaddons.com/image-comparison-widget-for-elementor-page-builder/)
16. [Premium Image Hotspots](https://premiumaddons.com/image-hotspots-widget-for-elementor-page-builder/)
17. [Premium Image Layers](https://premiumaddons.com/image-layers-widget-for-elementor-page-builder/)
18. [Premium Instagram Feed](https://premiumaddons.com/instagram-feed-widget-for-elementor-page-builder/)
19. [Premium Ken Burns](https://premiumaddons.com/ken-burns-section-addon-for-elementor-page-builder/)
20. [Premium Magic Section](https://premiumaddons.com/magic-section-widget-for-elementor-page-builder/)
21. [Premium Multi Scroll](https://premiumaddons.com/multi-scroll-widget-for-elementor-page-builder/)
22. [Premium Parallax](https://premiumaddons.com/parallax-section-addon-for-elementor-page-builder/)
23. [Premium Particles](https://premiumaddons.com/particles-section-addon-for-elementor-page-builder/)
24. [Premium Preview Window](https://premiumaddons.com/preview-window-widget-for-elementor-page-builder/)
25. [Premium Tables](https://premiumaddons.com/table-widget-for-elementor-page-builder/)
26. [Premium Twitter Feed](https://premiumaddons.com/twitter-feed-widget-for-elementor-page-builder/)
27. [Premium Tabs](https://premiumaddons.com/tabs-widget-for-elementor-page-builder-2/)
28. [Premium Unfold](https://premiumaddons.com/unfold-widget-for-elementor-page-builder/)
29. [Premium WhatsApp Chat](https://premiumaddons.com/whatsapp-widget-for-elementor-page-builder/)
30. [Premium Yelp Reviews](https://premiumaddons.com/elementor-yelp-reviews-widget/)

== Installation ==

- First make sure that Elementor Page Builder and Premium Addons for Elementor are installed, As this plugin works only with both of them.
- Download the plugin then Upload it to the plugin folder: /wp-content/plugins/ or install it through the WordPress plugins screen directly.
- Activate the plugin through the ‘Plugins’ screen in WordPress
- You can find Premium Addons Elements under the category “Premium Addons” on your Elementor element/widget list.

== Frequently Asked Questions ==
= Is this a standalone Plugin? =

No. You cannot use Premium Addons PRO without Elementor and Premium Addons for Elementor.

= Does it work with any WordPress theme? =

Yes, it will work with any WordPress theme as long as you are using Elementor as a page builder.

= Will this plugin slow down my website speed? =

Premium Addons for Elementor is light weight and we also gave you the control to enable only the elements you actually use on your website for faster performance.

== Changelog ==

= 2.9.69 =

- Tweak: Improved security in Table widget and Custom Mouse Cursor addon.
- Tweak: Code improvements in Global Badge, Custom Mouse Cursor, Magic Scroll, Particles, Ken Burns, Parallax and Lottie addons for better performance.
- Fixed: Anchor navigation not scrolling to the correct offset in Horizontal Scroll widget.
- Fixed: PHP error when Elementor MCP abilities read widget settings in Horizontal Scroll, Image Accordion, Image Hotspots, Magic Section, Alert Box, Preview Window, Tabs and Unfold widgets.

= 2.9.68 =

- Tweak: Added Fold Content per device, Scroll Back on Fold and Hide Button After Unfolding options in Unfold widget.
- Tweak: Added Lines option to Fold Height unit in Unfold widget.
- Tweak: Improved Unfold widget accessibility and removed layout shift on page load.
- Tweak: Improved translation support across all widgets and addons.
- Fixed: Legacy particles JSON options not working in Particles addon.
- Fixed: Card, Banner and On Side layouts not available in TikTok Feed widget.
- Fixed: Categories to Scroll responsive value not applied in Woo Categories widget.
- Fixed: Profile style options not showing correctly in Pinterest and TikTok Feed widgets.
- Fixed: Back side style options depending on front side settings in Flip Box widget.
- Fixed: PHP warning when both side separators are disabled in Divider widget.
- Fixed: Load More button loading duplicated projects in Behance Feed widget.

= 2.9.67 =

- New: Added Media Type option to show images, videos or both in Instagram Feed widget.
- New: Added Image Size option in Image Hotspots widget.
- Tweak: Improved License tab with plan-aware details and inline activation errors.
- Fixed: Icon styling applied on Lottie animations in Icon Box widget.
- Fixed: Editor error when no access token is added in Facebook Feed widget.
- Fixed: Height changes on hover in vertical Image Accordion widget.

= 2.9.66 =

- New: Added Fill on Scroll effect in Heading, Dual Heading and Textual Showcase widgets.

= 2.9.65 =

- New: Added Throwable Effect option in Tags Cloud widget - [here](https://premiumaddons.com/elementor-tags-cloud-widget/).
- Tweak: Improved hover transition speed in Icon Box widget.
- Fixed: Broken shapes rendered when gradient options are empty in Blob Generator addon.
- Fixed: Gradient Angle option not working in Animated Shape Divider addon.
- Fixed: Anchor links not working with Force Scroll to First Slide on Scroll option in Horizontal Scroll widget.
- Fixed: Facebook Feed widget not loading posts in some cases.
- Fixed: Main CSS file loaded even when Dynamic Assets option is enabled.

= 2.9.64 =

- Fixed: Duplicate CSS rules applied.

= 2.9.63 =

- Fixed: Anchoring section in a page with Horizontal Scroll not working.
- Fixed: Animated Gradient addon not working in some cases.

= 2.9.62 =

- Tweak: Minor improvements in Global Badge addon for better usability.

= 2.9.61 =

- New: Added CSS Selector option in Global Badge addon to display badges on custom elements.
- New: Added Display Per Item option in Global Badge addon for listing widgets.
- New: Added Title Vertical Alignment option in Icon Box widget.
- Tweak: Added Overflow option in Icon Box widget for better compatibility with Global Badge addon.
- Tweak: Added Border Radius option for Ribbon style badge in Global Badge addon.
- Tweak: Added a waiting time notice in Instagram Feed widget.
- Tweak: Improved content labels in Content Toggle widget.
- Tweak: Lowered the minimum value of the Size control in Content Toggle widget.
- Fixed: Badge banner top position in Global Badge addon.
- Fixed: Vertical offset not working on all badges in Global Badge addon.
- Fixed: Text decoration not inheriting text color in Global Badge addon.
- Fixed: "undefined" text shown when Image URL is empty in Global Badge addon.
- Fixed: Animated Gradient option applied to all child badges in Global Badge addon.
- Fixed: Per-item badges not working with Load More, Pagination and Load on Scroll options.
- Fixed: Z-index not working on custom CSS selector badges in Global Badge addon.
- Fixed: Conflict between Global Badge addon and Pricing Table widget Lottie icon.
- Fixed: Button alignment not working when position is set to outside in Unfold widget.
- Fixed: Magic Scroll not working with widgets inside Elementor V4 Flexbox container.
- Fixed: Content height not working on nested content in Content Toggle widget.

= 2.9.60 =

- New: Content Toggle widget rebuilt - [here](https://premiumaddons.com/elementor-content-toggle-widget/).
- Tweak: Code refactored for better performance and security.

= 2.9.59 =

- Tweak: Added Box Shadow control for images in Image Accordion.
- Fixed: Border Radius not applied on Flipped style Tabs widget.
- Fixed: Default width not applied on Bookmark type badge.

= 2.9.58 =

- Tweak: Added new presets for Global Badge addon.
- Tweak: Added Load More button in Instagram Feed widget.
- Tweak: Added Lightbox compatibility with videos in Instagram Feed widget.
- Tweak: Added alt text attribute for images in Instagram Feed widget.
- Fixed: Back icon size control not working in Icon Box widget.
- Fixed: Margin not applied correctly on mobile in Tabs widget.
- Fixed: Navigation from other pages not working in Tabs widget.
- Fixed: Elements styling broken in editor on first-time activation.
- Fixed: Icon Position control not working with SVG icons in Icon Box widget.
- Fixed: Duplicate initialization of Behance Feed widget.

= 2.9.57 =

- Tweak: Added Get Reviews by Language option in Yelp Reviews widget.
- Tweak: Core improved for better performance and loading speed.
- Fixed: Stripe badge not showing in RTL mode.
- Fixed: Team Members widget not working inside Tabs widget.

= 2.9.56 =

- Tweak: Added Container ID option in Image Accordion, Off Canvas, Alert Box and Tabs widgets to get slides from containers on the same page for better usability.
- Tweak: Added Hover Color and Background Color for navigation arrows in social reviews widget.
- Tweak: Border radius option added in Divider widget.
- Tweak: Added Image Fit control for icon in Icon Box widget.
- Tweak: Improved RTL compatibility in Smart Post Listing widget.
- Tweak: Improved compatibility between Unfold and Tabs widgets.
- Fixed: Jittering issues with Snappy effect in Horizontal Scroll widget.

= 2.9.55 =

- New: Animated Gradient and Ken Burns addons are now applicable on widgets.
- Tweak: Opacity Scroll effect in Horizontal Scroll widget improved.
- Fixed: Blob not removed after disabling Animated Blob addon switcher.

= 2.9.54 =

- Tweak: Improved compatibility between Dynamic Assets and Elementor Elements Cache.
- Fixed: Arrow position when Accordion option is enabled in Tabs widget.

= 2.9.53 =

- Tweak: Facebook and Behance Feed widgets improved.
- Tweak: Core improved for better performance and loading speed.

= 2.9.52 =

- Tweak: Added Suffix option in Charts widget to add text after value on hover.
- Tweak: Core improved for better performance and loading speed.

= 2.9.51 =

- Tweak: API endpoint usage improved in Behance Feed widget.
- Fixed: Horizontal Scroll issues after scene ends.

= 2.9.50 =

- New: Added Animated Gradient option to the badge text in Badge Global addon.
- Tweak: Improved Font Size and Color effects in Magic Scroll addon.

= 2.9.49 =

- Tweak: Added Clipped Background option in Global Badge addon.
- Tweak: Added "p" and "span" options for HTML Tag control in Divider widget.
- Fixed: Image Layers widget not showing when Container Direction is set to row.
- Fixed: Text is showing in multiple lines in Divider widget.

= 2.9.48 =

- New: Load JS libraries only when needed to improve loading speed.

= 2.9.47 =

- Fixed: Fatal error in some widgets after v2.9.46.

= 2.9.46 =

- Tweak: Code improvements in social reviews widgets for better performance and faster loading speed.
- Tweak: Improved accessibility in all widgets.
- Fixed: Jittering issue in Custom Mouse Cursor addon.
- Fixed: Console JS error when delay option is empty in Custom Mouse Cursor addon.
- Fixed: CSS Selector option not working in Custom Mouse Cursor addon.

= 2.9.45 =

- Tweak: Code improvements in all widgets for better performance and faster loading speed.
- Fixed: RTL Mode option not working correctly in Horizontal Scroll widget.

= 2.9.44 =

- Tweak: Code improvements in Global Badge and Custom Mouse Cursor addons for better performance and faster loading speed.
- Tweak: Added Videos Behavior option in Instagram Feed widget.
- Fixed: Multiple placeholder images are inserted in Media when a template is imported.

= 2.9.43 =

- Tweak: Improve Background Transition option in Horizontal Scroll widget.
- Fixed: Horizontal Scroll widget not working correctly on RTL sites.
- Fixed: Console error in Tabs widget.
- Fixed: Rating Schema not working in Google Reviews widget.
- Fixed: Compatibility issues with WPML plugin.

= 2.9.42 =

- Tweak: Added Change Color on Hover in Charts widget.
- Tweak: Added Liquid Glass effect option in Custom Mouse Cursor addon.
- Tweak: Added Moving background option in Tabs widget Style 1.
- Tweak: Added button to filter pre-made blocks by widget.

= 2.9.41 =

- Tweak: Custom Mouse Cursor addon controls rearranged for better UX.
- Tweak: Entrance Animation improved in Image Layers widget.
- Tweak: Plugin size minimized for faster installation.

= 2.9.40 =

- Tweak: Added Color option for switcher in inactive state in Content Toggle.
- Fixed: Entrance Animation option not working in Image Layers widget.
- Fixed: Arrow position issue in Image Compare widget.

= 2.9.39 =

- Fixed: Plugin settings dashboard page not loading in some cases.
- Fixed: Put Sections Next to Each Other not working with Elementor Sections in Horizontal Scroll widget.
- Fixed: Arrow Pointer not showing when Accordion option is enabled in Tabs widget.
- Fixed: PHP warnings when global addons are enabled.

= 2.9.38 =

- Tweak: Unfold widget not working correctly with Elementor Gallery widget.
- Fixed: Disable Horizontal Scroll on specific devices option not working.
- Fixed: Console error in editor page for a not found CSS file.

= 2.9.37 =

- Tweak: Improved compatibility with RTL sites.
- Tweak: Plugin size decreased by improving Dynamic CSS generating.
- Fixed: Push/Slide effects not working on RTL in Hover Box widget.

= 2.9.36 =

- Fixed: Fatal error in Google Reviews widget after v2.9.35.

= 2.9.35 =

- Tweak: Improved Twitter Feed to use Bearer Token.
- Tweak: RTL Mode option improved in Horizontal Scroll widget.
- Tweak: Close Off Canvas when escape keyboard button is hit.
- Fixed: PHP warning in Google Reviews widget.

= 2.9.34 =

- Tweak: Added Counting Effect in Woo Mini Cart widget.
- Tweak: Added Coupon Form in Woo Mini Cart widget.
- Tweak: Added Free Shipping progress bar in Woo Mini Cart widget.
- Tweak: Show date in current site language in all Social Feed/Reviews widgets.
- Tweak: Added Shape option for navigation dots in Multi Scroll widget.
- Tweak: Code improvements for better performance and loading speed.
- Fixed: Instagram Access Token is not automatically renewed.
- Fixed: Icon Position option not working correctly for body cells in Table widget.
- Fixed: PHP warning when Rating Schema option is enabled in Google Reviews widget.
- Fixed: PHP warning when background image is not set in Parallax addon.
- Fixed: Off Canvas content not showing correctly when set to Text Editor.

= 2.9.33 =

- Tweak: Added Delay option in Lottie Background addon.
- Tweak: Code improvements for better performance.
- Tweak: Google Reviews widget loading speed improved.
- Tweak: Install free version directly without redirection to another page.
- Fixed: Free-hand design not working in Image Hotspots and Image Layers widgets.
- Fixed: Read more text not changing in Facebook Feed widget.
- Fixed: SVG Code option not working in Site Logo widget.

= 2.9.32 =

- Tweak: Compatibility with Google Places API (New) in Google Reviews widget.
- Tweak: JS files separated for better performance.
- Tweak: Added Refresh Layout button in Horizontal Scroll and Image Layers.
- Fixed: Put Columns/Containers Next to Each Other option not working in Horizontal Scroll widget.
- Fixed: Content not showing when Ken Burns addon is enabled.
- Fixed: Blob addon is not working on inner containers while in editor.
- Fixed: On Page Load trigger not working in Off Canvas widget.

= 2.9.31 =

- Tweak: Apply Icon size control on image icon in Icon Box widget.
- Fixed: Size control for Lottie Background addon not working on editor.
- Fixed: Instagram access token not generated.

= 2.9.30 =

- Tweak: Added "On Page Load" trigger in Off Canvas widget.
- Tweak: Core improved for better editor loading.
- Fixed: Navigate to Multi Scroll sides using elements not working.

= 2.9.29 =

- Fixed: Tabs widget not activating the correct tab on page load.
- Fixed: Hover effects not working in Smart Post Listing when featured image is disabled.

= 2.9.28 =

- Fixed: Off-Canvas widget not working correctly after v2.9.27
- Fixed: Image dimensions issue in Site Logo widget.

= 2.9.27 =

- Tweak: Improved compatibility with Optimize Markup Elementor feature.
- Tweak: SVG Draw Icon option improved for better loading speed.
- Fixed: Controls for global addons not being added in correct tabs.

= 2.9.26 =

- Fixed: Layout issues with Fixed Content option in Multi Scroll widget.
- Fixed: Lottie animation icons not working correctly in Icon Box widget.
- Fixed: Global badge adds a spacing while in editor.

= 2.9.25 =

- Tweak: Plugin core enhancements to improve plugin performance.
- Fixed: Table not showing data from CSV files.
- Fixed: Global Cursor SVG icon style not working.

= 2.9.24 =

- Tweak: Plugin core enhancements to improve plugin performance.
- Tweak: Added No Cache option in Table widget.
- Fixed: Issues when Blog and Smart Post Listing widgets are added in one page.

= 2.9.23 =

- Deprecated: Facebook Messenger Chat widget as it has been deprecated by Facebook.

= 2.9.22 =

- Fixed: Background Transition widget is not working after Elementor 3.24.0.

= 2.9.21 =

- Tweak: Pause videos in Tabs widget on switching tabs.
- Fixed: Conflict with Elementor v3.24.0.
- Fixed: Elementor entrance animations not working with Infinite Scroll option in Smart Post Listing widget.

= 2.9.20 =

- Fixed: Background Transition widget not working when Scroll Up background is not set.
- Fixed: Scroll effects in Image Layers not working inside Horizontal Scroll widget.
- Fixed: Number of Columns not working on mobile devices in Smart Post Listing widget.

= 2.9.19 =

- Tweak: Use IntersectionObserver API instead of waypoints.js to improve performance.
- Fixed: Scroll effects in Image Layers widget not working when added with Magic Scroll on same page.
- Fixed: Icon Color not working in WhatsApp Chat widget.

= 2.9.18 =

- Fixed: Entrance animations in Image Layers widget not working within Horizontal Scroll widget.
- Fixed: Close icon not showing when logged out in Alert Box widget.
- Fixed: PHP warning in Google Reviews widget.
- Fixed: Instagram Feed layout broken while on editor page.

= 2.9.17 =

- Tweak: Code improved for better performance and security.
- Fixed: Tabs widget not working in some cases.
- Fixed: PHP warnings on customizer page when Particles or Custom Mouse Cursor addons are enabled.

= 2.9.16 =

- Tweak: Added HTML Tag option for text in Image Layers widget.
- Tweak: Code improved for better performance and security.
- Fixed: Smart Post Listing conflict with Elementor Flexbox Containers.
- Fixed: PHP warning in Facebook, Google and Yelp Reviews widgets.

= 2.9.15 =

- Tweak: Code improved for better performance and security.
- Tweak: Added Z-index option for Custom Mouse Cursor addon.
- Fixed: PHP warnings in Yelp Reviews and Hover Box widgets.
- Fixed: Icon Color option not working correctly in some cases in WhatsApp Chat widget.
- Fixed: Console error thrown by Global Mouse Cursor addon.

= 2.9.14 =

- Tweak: Code improved for better performance and security.
- Tweak: Improved compatibility between Horizontal and Magic Scroll elements.
- Fixed: Flickering issue in Magic Scroll addon.

= 2.9.13 =

- Tweak: Code improved for better performance and security.
- Fixed: Off-canvas widget layout broken on RTL sites.

= 2.9.12 =

- New: Magic Section widget rebuilt. It's now Off-Canvas - [here](https://premiumaddons.com/elementor-off-canvas-widget).
- Tweak: Added Fixed Content Template option in Multi Scroll widget - [here](https://premiumaddons.com/multi-scroll-widget-for-elementor-page-builder/).
- Fixed: Icon hover styling options not working in Icon Box widget.

= 2.9.11 =

- New: Added new hover effects to all the buttons all over the plugin - [here](https://premiumaddons.com/elementor-button-widget/).
- Tweak: Alert Box widget rebuilt - [here](https://premiumaddons.com/alert-box-widget-for-elementor-page-builder/).
- Fixed: Social icons not showing in Image Hotspots widget.

= 2.9.10 =

- Tweak: Added option to apply Particles addon on whole page through Elementor page settings.
- Tweak: Added responsive controls to Display option in Content Toggle widget.
- Fixed: Disable Snappy Effect on Touch Devices in Horizontal Scroll widget not working.
- Fixed: Flickering issue with Image Sequence effect in Magic Scroll addon.

= 2.9.9 =

- Tweak: Divider widget rebuilt - [here](https://premiumaddons.com/divider-widget-for-elementor-page-builder/).
- Tweak: Option to Disable Scroll on Accordion Item Click added in in Tabs widget.

= 2.9.8 =

- Tweak: Added option to hide Horizontal Scroll widget slides on desktop devices.
- Fixed: Unnecessary HTML markup rendered in the table widget.
- Fixed: Feed is duplicated in Facebook and Behance Feed widgets.
- Fixed: Facebook and Behance Feed widgets not working on the frontend.

= 2.9.7 =

- Tweak: Added SVG Code option in Site Logo widget.
- Tweak: Gold API error messages handled in News Ticker widget.

= 2.9.6 =

- Tweak: Added Option to enable US numbers sorting in Table widget.
- Tweak: Compatibility between Hide Slide On option in Multi Scroll widget and Elementor custom breakpoints.

= 2.9.5 =

- Fixed: Fatal error when Premium Addons Pro is activated without the free version.
- Fixed: Masonry effect not working correctly on editor page in Instagram Feed widget.

= 2.9.4 =

- Tweak: Added Custom Navigation Element Selector option in Multi Scroll to be used to navigate to Multi Scroll slides.
- Fixed: Ratings values between .7 and .9 are rendered as half star in Social Reviews widgets.

= 2.9.3 =

- Fixed: PHP Error when Image Accordion widget is used.
- Fixed: Elementor asks to run Safe Mode with Magic Scroll addon.

= 2.9.2 =

- Tweak: Added Alternative Gold API key option in News Ticker widget.
- Tweak: Added Load More option in Smart Post Listing widget.
- Tweak: Added more styling controls in Smart Post Listing widget.

= 2.9.1 =

- Tweak: Code improved for better performance and security.

= 2.9.0 =

- New: Added Smart Post Listing widget - [here](https://premiumaddons.com/elementor-smart-post-listing-widget/).
- Tweak: Show Alt text for the images in Ken Burns addon.

= 2.8.27 =

- Fixed: Twitter Feed widget not working.

= 2.8.26 =

- Tweak: Code refactored for better performance and security.
- Fixed: Numbers showing on hover not formatted in Charts widget.

= 2.8.25 =

- Tweak: Removed Twitter Feed credentials section.

= 2.8.24 =

- Tweak: Added custom position options for tooltips in Image Hotspots widget.
- Fixed: Multi Scroll widget not working when elements with entrance animations used in it.
- Fixed: Twitter Feed widget not working in some cases.
- Fixed: Image Comparison widget handle not working on RTL sites.

= 2.8.23 =

- Tweak: Added caching options in Facebook and Behance Feed widgets.
- Tweak: Multi Scroll widget improved to trigger entrance animations on slide change.
- Fixed: Button showing in back side in 3D Hover Box widget.
- Fixed: Horizontal Scroll issues on mobile devices.
- Fixed: Hide Empty Reviews option not working correctly in Google Reviews widget.

= 2.8.22 =

- Tweak: Added custom size unit for range controls in some widgets.
- Tweak: Load posts only if they have body text in Facebook Feed widget.
- Fixed: Load Chart On option not working in Charts widget.
- Fixed: Fatal error in Tabs widget when an image icon with empty image is added.

= 2.8.21 =

- New: Added Magnet Effect in Custom Mouse Cursor addon - [here](https://premiumaddons.com/elementor-custom-mouse-cursor-global-addon/).
- Tweak: Magic Scroll addon performance improved.

= 2.8.20 =

- Tweak: CSS files size minimized for better performance.
- Fixed: Custom link attributes not working in Icon Box widget.
- Fixed: Console error in Horizontal Scroll widget.

= 2.8.19 =

- Tweak: Added option to load Magic Scroll addon on page load, not when the section is reached.
- Fixed: Image Comparison widget not working when used inside Tabs widget.
- Fixed: Lock Page Scroll option in Magic Scroll addon causing a blank area while scrolling on mobile devices.
- Fixed: PHP warning in Parallax addon when no layers are added.
- Fixed: Console error with Horizontal Scroll widget.

= 2.8.18 =

- Tweak: Added Text Shadow and Box Shadow scroll effects in Magic Scroll addon.
- Tweak: Added Sort Reviews by date option in Google Reviews widget.
- Tweak: Show/hide images by hashtags in Instagram Feed widget.

= 2.8.17 =

- Tweak: Sticky effect behavior improved in Magic Scroll addon.
- Tweak: Added option to trigger entrance animations once for Snappy scroll in Horizontal Scroll widget.
- Fixed: Sticky effect not working on the editor page in Magic Scroll addon.

= 2.8.16 =

- Fixed: Draw SVG not working on the editor page with multiple SVGs in Magic Scroll addon.
- Fixed: Transition is added to Icon Box widget when used with Magic Scroll addon.

= 2.8.15 =

- Fixed: Elements with entrance animation flash in Horizontal Scroll widget.
- Fixed: Icons not showing in some controls.

= 2.8.14 =

- New: Added Magic Scroll addon - [here](https://premiumaddons.com/elementor-magic-scroll-global-addon/).

= 2.8.13 =

- Fixed: Compatibility issues with Elementor v3.8.0
- Fixed: Ken Burns container addon not working with recent Elementor versions.

= 2.8.12 =

- New: Added Site Logo widget - [here](https://premiumaddons.com/elementor-site-logo-widget/).

= 2.8.11 =

- Tweak: Added caching option in Instagram Feed widget to improve the feed performance and loading speed.
- Tweak: Added Close On Click Outside option in Magic Section widget.
- Fixed: Icon styling not applied properly on SVG icons in Divider widget.
- Fixed: Mouse tilt option not working since Premium Addons for Elementor v4.9.35.
- Fixed: Feed is not showing if Posts/Account option value is larger than the posts returned by Facebook.
- Fixed: Alignment option not working properly for multi-line values in Table widget.

= 2.8.10 =

- New: Added Random Badges option in Mega Menu widget - [here](https://premiumaddons.com/elementor-mega-menu-widget/).
- Fixed: PHP warnings in Google Reviews widget.

= 2.8.9 =

- Fixed: Console error when SVG Draw option is disabled for Parallax addon.
- Fixed: SVG Draw option not working for Font Awesome icons in Icon Box widget.
- Fixed: Applying global background colors not working in Magic Section widget.
- Fixed: Icon color applied on Lottie animation in Hover Box widget.

= 2.8.8 =

- Tweak: Behance Feed widget now loads feed on scroll, not on page load.
- Fixed: PHP warning after v2.8.7.

= 2.8.7 =

- Tweak: Make sure Custom Mouse Cursor addon JS files are loaded only if the addon is used on a page.
- Fixed: Navigation Arrows/Dots not working properly on touch devices in Horizontal Scroll widget.

= 2.8.6 =

- Fixed: Fatal error due to Image Accordion widget since v2.8.4.

= 2.8.5 =

- Fixed: Icons in Icon Box widget always disappear if Draw SVG option is disabled.

= 2.8.4 =

- New: Added Draw Icon option in all widgets that has Icon option in them.
- Tweak: Added Horizontal/Vertical Alignment options for multi-layers in Parallax addon.
- Fixed: Conflict between Custom Mouse Cursor addon and WP Rocket Defer JS files option.

= 2.8.3 =

- Fixed: Compatibility issues with Elementor v3.7.0.
- Fixed: Freehand Positioning feature not working when the device mode is changed in the editor page.

= 2.8.2 =

- Tweak: Facebook Feed widget styling improved for RTL sites.
- Fixed: Conflict with Elementor Pro templates.
- Fixed: Even layout not working with Carousel Infinite Autoplay in social reviews widgets.
- Fixed: Carousel Navigation Arrows color/size controls not working in Instagram Feed widget.

= 2.8.1 =

- Fixed: PHP warning since v2.8.0

= 2.8.0 =

- Tweak: Apply Custom Mouse Cursor on full page or the entire website - [here](https://premiumaddons.com/elementor-custom-mouse-cursor-global-addon/).
- Tweak: Added responsive controls to Number of Columns option in Behance Feed widget.
- Fixed: Carousel Tabs option applied on nested tabs.
- Fixed: Unnecessary Elementor placeholder images added to the Media Library after importing templates.
- Fixed: Multi Scroll widget not working with Elementor custom breakpoints.
- Fixed: Ken Burns addon not showing images properly on small screens.
- Fixed: Hover Box widget not working properly on iOS devices.

= 2.7.9 =

- Tweak: Add responsive controls for image control in Ken Burns container addon.
- Fixed: Horizontal/Vertical Offset option not working for social icon in all Social Reviews widgets.
- Fixed: Horizontal Offset and z-index options not working for Fixed Content template in Horizontal Scroll widget.
- Fixed: Console error in Charts widget.

= 2.7.8 =

- Tweak: Code improvements for better performance and loading speed.

= 2.7.7 =

- Tweak: Load Custom Mouse Cursor addon when the element is visible on viewport to improve performance and page loading speed.
- Tweak: Added Cover Image size option in Behance Feed widget.

= 2.7.6 =

- Tweak: Add Mask Image option in Image Layers widget.
- Tweak: Add Render As SVG/Canvas option for Lottie Animation icons in Hover Box widget.
- Tweak: HTML markup optimized for Image Hotspots and Twitter Feed widgets for better performance.
- Fixed: Accordion Tabs option not working in Tabs widget.

= 2.7.5 =

- New: Added URL String, Shortcode and WooCommerce Products in Cart options in Display Conditions.
- Tweak: HTML markup optimized for Hover Box, Image Accordion, Instagram Feed, Tabs, Unfold widgets for better performance.
- Tweak: Added Disable Floating Effects on Safari option in widgets have floating effects.
- Tweak: Trigger Particles and Badge addons JS code when visible on viewport to improve page loading speed.
- Tweak: Added compatibility Charts and Horizontal Scroll widgets.
- Fixed: Change Colors As Gradient option not working in Background Transition widget.
- Fixed: Profile Header image not showing properly on small devices in Twitter Feed widget.
- Fixed: Right Side Template option not showing in Multi Scroll widget.

= 2.7.4 =

- Tweak: Added compatibility between Badge Global Addon and Elementor Container element - [here](https://elementor.com/help/container-element/).
- Fixed: Horizontal Scroll jittering issue on touch devices.

= 2.7.3 =

- New: Added Create/Edit Live Templates feature in all widgets that support Elementor Templates.

= 2.7.2 =

- Tweak: Added support for future features compatibility
- Fixed: Button Trigger Size option not working on frontend in Magic Section widget.
- Fixed: Alignment issue in Icon Box widget when description is short.
- Fixed: Invalid CSS added in the editor when Badge Addon is enabled.

= 2.7.1 =

- Fixed: Fatal error with some PHP versions after v2.7.0

= 2.7.0 =

- New: Added Premium Badge global addon - [here](https://premiumaddons.com/elementor-badge-global-addon/).

= 2.6.9 =

- Tweak: HTML markup optimized for Table widget for better performance.
- Tweak: Added Icon Color and Text Color/Typography options for each repeater cell in Table widget.
- Fixed: Hover Color and Padding options not working for Read More link in Icon Box widget.

= 2.6.8 =

- New: Added five new skins in Elementor WooCommerce Products Listing widget - [here](https://premiumaddons.com/elementor-woocommerce-products/).
- Tweak: Added compatibility between section/column addons and Elementor Container element - [here](https://elementor.com/help/container-element/).
- Tweak: Widgets code refactored to improve performance and loading speed.
- Tweak: Added Hover Box Shadow option in Lottie Animation container addon.
- Fixed: PHP warning when Follow Delay option value is not set in Custom Mouse Cursor addon.
- Fixed: Image with Size option set to custom not rendered in Image Layers and Icon Box widgets.

= 2.6.7 =

- New: Added Custom Mouse Cursor global addon - [here](https://premiumaddons.com/elementor-custom-mouse-cursor-global-addon).
- Tweak: Added Auto Change Tabs option in Tabs widget.
- Tweak: HTML markup for images in Icon Box widget.
- Tweak: Make sure images in Image Layers and Tabs widgets are lazyloaded to improve loading speed.
- Fixed: Container addons not working on editor when used inside widgets using Elementor templates.

= 2.6.6 =

- Fixed: Box shadow and Background Color options overridden by default values in CSS in Preview Window widget.
- Fixed: Charts widget not working in some cases inside Tabs widget.
- Fixed: Animated Gradient and Blob Generator addons not working in Tabs widget.
- Fixed: Ken Burns addon Infinite option always disabled when the editor page is reloaded.

= 2.6.5 =

- Tweak: Load the main CSS file only when required.
- Fixed: Tabs widget not working properly with some themes.
- Fixed: Compatibility between Carousel option in Social Reviews widgets and RTL sites.
- Fixed: Keyboard Scrolling still works even when the control is disabled in Horizontal Scroll widget.

= 2.6.4 =

- Fixed: Compatibility issues with Elementor v3.5.0.

= 2.6.3 =

- Tweak: Added options to control Scroll Offset for each section individually in Color Transition widget.
- Tweak: Javascript loading method improved for Animated Gradient, Particles container addons for better performance.
- Fixed: Styling options not working for SVG icons in Magic Section widget.

= 2.6.2 =

- Tweak: Added WooCommerce Total Amount In Cart and Current Product Stock options in Display Conditions feature.
- Fixed: Console error when videos are inserted in Tabs widget.

= 2.6.1 =

- Fixed: Undefined variable $dir_class in Image Layers widget when Text option is used.
- Fixed: Button Size option not working in WhatsApp Chat widget.

= 2.6.0 =

- New: Added Animated Blob Generator container addon - [here](https://premiumaddons.com/elementor-animated-blob-generator/).
- Tweak: Added Radar Style option in Image Hotspots widget.
- Tweak: Added div, p and span HTML tag options for heading in Hover Box widget.
- Fixed: Default icon size changed in Hover Box widget.
- Fixed: Background Color not changing when multiple Background Transition widgets are used on the same page.

= 2.5.5 =

- Fixed: Background is not changed on scroll up in Background Transition widget.
- Fixed: Nested tabs styling overwrite issue in Tabs widget.

= 2.5.4 =

- Tweak: Tabs widget rebuilt for better usability and editing experience.
- Tweak: Control number of carousel slides to show in Instagram Feed widget.
- Tweak: Prevent Background Transition widget from changing color when up/down backgrounds are the same.
- Fixed: Line height not working for Business/Place Name, Reviewer Name and Review Text in Social Reviews widgets.
- Fixed: Entrance Animations not working on for the first in Horizontal Scroll widget.
- Fixed: Premium Parallax not working for Elementor columns.
- Fixed: Tabs widget not working when shortcodes are used in tabs content.

= 2.5.3 =

- Tweak: Added Heroes Flying-Left effect in iHover widget.
- Tweak: Remove any duplicate content when Accordion Tabs option is enabled in Tabs widget.
- Tweak: Added Tab ID option in Tabs widget.
- Fixed: Animation issues for Flash Rotation, Flip Door, and Magic Door effects in iHover widget.
- Fixed: Charts not working on the editor page on Chrome browser.
- Fixed: Color option not applied on links in Table widget when CSV file is used.

= 2.5.2 =

- Tweak: Save all the plugin settings on change without need to click "Save Settings" button.
- Tweak: Compatibility with Elementor v3.4.4.
- Fixed: Snappy scroll stability issues in Horizontal Scroll issues.
- Fixed: Compatibility issues between Elementor custom breakpoints and Horizontal Scroll widget.

= 2.5.1 =

- Tweak: iHover widget code refactored for faster editing speed..
- Tweak: Added Image Hover Effect in Image Layers widget.
- Tweak: Added compatibility between Multiscroll widget and sticky headers.
- Fixed: Premium Parallax not working for Elementor columns.
- Fixed: Premium Particles not working on some devices in editor page.
- Fixed: Premium Parallax not working for Elementor columns.
- Fixed: Content is not fully rendered issue in Unfold widget.
- Fixed: Removed Unnecessary requests made in Instagram Feed widget.
- Fixed: Hide Slide On and Disable Horizontal Scroll On options not working together in Horizontal Scroll widget.
- Fixed: Carousel not working in Facebook Feed widget when `Only Show Admin Posts` option is enabled.
- Fixed: Fold Height option not working when set to `0` in Unfold widget.
- Fixed: Console error in Multi Scroll widget.
- Fixed: Admin notices not showing when Premium Addons for Elementor is not installed.

= 2.5.0 =

- Tweak: JS code refactored for better performance and faster editing speed.
- Tweak: Compatibility with Elementor v3.4.2.
- Fixed: Emojis not showing in Twitter Feed widget.
- Fixed: Slides overlapping issue on touch devices in Horizontal Scroll widget.
- Fixed: Image Hotspots colors not working in editor page.

= 2.4.9 =

- New: Added Advanced Border Radius option to improve the normal Border Radius option - [here](https://9elements.github.io/fancy-border-radius/).
- Fixed: Particles overlapping issue when browser active tab is changed.
- Fixed: Alignment controls icons not showing in editor panel.
- Fixed: Tabs widget style conflict with LearnDash plugin.

= 2.4.8 =

- Tweak: Added option to control `Based on Number of Reviews` string in all social reviews widgets.
- Fixed: Expired access token is not refreshed in Instagram Feed widget.
- Fixed: Image appears before entrance animation starts in Image Layers widget.
- Fixed: Facebook Feed widget conflict with Complianz | GDPR/CCPA Cookie Consent plugin.
- Fixed: Pagination not working in the editor in Table widget.
- Fixed: Tabs widget conflict with some themes.

= 2.4.7 =

- Tweak: Added `Change Tabs to Accordion On Small Screens` option in Tabs widget.
- Tweak: Improved compatibility with Elementor new version.

= 2.4.6 =

- Tweak: Improved Social Reviews widgets compatibility for RTL sites.
- Tweak: Improved WPML compatibility with all widgets.
- Tweak: Added Icon Spacing option in Unfold widget.
- Fixed: SVGs icons not showing on button in Unfold widget.

= 2.4.5 =

- Fixed: Code improvements for better performance.

= 2.4.4 =

- Fixed: Console error in Parallax addon issue.

= 2.4.3 =

- Tweak: Added Infinite Autoplay for carousel in social reviews widgets.
- Tweak: Added Navigation Type Dots/Arrows option in social reviews widgets.
- Tweak: Added Show Number of Reviews option in social reviews widgets.
- Tweak: Added Put Place/Business Info next to reviews option in social reviews widgets.
- Fixed: Console error `$ is not defined` since v2.4.2.

= 2.4.2 =

- Tweak: Added Clear Cached Data button to Facebook, Google and Yelp Reviews widgets.
- Tweak: Added Carousel Arrows option for Carousel Tabs option in Tabs widget.
- Tweak: Snap Scroll improved in Horizontal Scroll widget.

= 2.4.1 =

- Fixed: Horizontal Scroll slides anchoring not working since v2.4.0
- Fixed: Lightbox option issue in Instagram Feed widget.

= 2.4.0 =

- Tweak: Feed Media Height control added to work all time in Facebook/Twitter Feed widgets.
- Tweak: Container addons code refactored to improve editing speed.

= 2.3.9 =

- Tweak: Added Hovered Image Width control option in Image Accordion widget.
- Tweak: Javascript Code refactored for better performance and security.
- Fixed: Lottie Animation icon size option not working on Chrome in WhatsApp Chat widget.

= 2.3.8 =

- Tweak: Added Spacing Color option in Image Accordion widget.
- Fixed: Horizontal Scroll anchor links not working with Elementor popups.
- Fixed: Images Spacing option not working with horizontal direction in Image Accordion widget.

= 2.3.7 =

- Tweak: Added Minimal Mask effect for Text in Image Layers widget.
- Tweak: Added Image Spacing option in Image Accordion widget.
- Fixed: Icon Color option not applied on SVGs in all widgets.

= 2.3.6 =

- Fixed: Hide Section option not working after v2.3.5 in Horizontal Scroll widget.

= 2.3.5 =

- Tweak: Added Disable Horizontal Scroll On Tablet/Mobile devices option in Horizontal Scroll widget.
- Tweak: Added Wave Effect option in Animated Gradient addon.
- Tweak: Added Change Legend to Circles option in Charts widget.
- Tweak: Added Maximum Height control in Magic Section.
- Fixed: Equal Height option not working when Carousel is enabled in Social Feed and Reviews widgets.

= 2.3.4 =

- Tweak: Code refactored for better performance and security.
- Fixed: Live Search option shows results only from current page in Table widget.
- Fixed: Icon Hover Animation not working with Whole Box Link in Icon Box widget.

= 2.3.3 =

- Tweak: Added Pull Data from CSV file in Charts widget.
- Fixed: Some Particles effects not working.
- Fixed: Template style is rendered in Content Toggle widget.

= 2.3.2 =

- Tweak: Added Lottie Animations, Icon and Text Trigger options in Preview Window widget.
- Tweak: Added Show/Hide Reviewer Image option in Social Reviews widgets.
- Tweak: Added Show/Hide Place Rating Stars option in Social Reviews widgets.
- Tweak: Code refactored for better performance and security.

= 2.3.1 =

- Tweak: Compatibility with Elementor PRO 3.2.0.

= 2.3.0 =

- Tweak: Code refactored for better performance and faster editor loading.
- Tweak: Font Awesome 5 compatibility for Magic Section widget.
- Tweak: Added option to enable cookies for logged in users in Alert Box widget.
- Tweak: Added Hover Image option in Preview Window widget.
- Tweak: Added responsive controls for Fold Height and Fade Height options in Unfold widget.
- Tweak: Added Icon Spacing option for Link in Icon Box widget.
- Fixed: Icon Spacing not working on RTL sites in WhatsApp Chat widget.
- Fixed: Tooltips height issue in Image Hotspots widget.

= 2.2.9 =

- Tweak: Added option to hide specific sections on different devices in Horizontal Scroll widget.
- Fixed: Content alignment responsive controls not working in Icon Box widget.

= 2.2.8 =

- New: Apply Animated Gradient, Ken Burns, Parallax and Particles addon on columns.
- Fixed: Global Colors not working for Animated Gradient addon.
- Fixed: Spinner effect text link not working in iHover widget.

= 2.2.7 =

- Tweak: Added Text option in Image Layers widget.
- Tweak: Code refactored for better performance.

= 2.2.6 =

- Tweak: Added Show Admin Posts Only option in Facebook Feed widget.
- Tweak: Added Data Format Locale option to format numbers in Charts widget.
- Tweak: Number formatting in Twitter Feed widget.

= 2.2.5 =

- Tweak: Added Horizontal Scroll Parallax option in Parallax container addon.
- Tweak: Added Profile Header and Tweet Information options in Twitter Feed widget.
- Tweak: Added Cube effect in Hover Box widget.
- Tweak: Added Profile Header in Instagram Feed widget.
- Tweak: Added Feed Share button in Instagram Feed widget.
- Tweak: WPML Compatibility for Horizontal Scroll widget.
- Tweak: Reload data every Minute option changed to Five Minutes to prevent API block in Table widget.

= 2.2.4 =

- Tweak: Added Show/Hide Profile Name and Feed Content option in Facebook/Twitter Feed widget.
- Tweak: Added Feed Media Image Height option in Facebook/Twitter Feed widget.
- Tweak: Added CSS ID option for hotspots in Image Hotspots widget.
- Fixed: All RTL issues in Facebook/Twitter Feed widget.

= 2.2.3 =

- Tweak: Added Custom Navigation option to Tabs widget.
- Tweak: Added Back To Initial Position for Parallax Mouse Interactivity in Image Layers widget.
- Fixed: Icon Spacing option not working when direction option is set to RTL in Table widget.
- Fixed: Google Sheets not working in Table widget.
- Fixed: Left Margin/Padding option not working for Title/Link in Hover Box widget.

= 2.2.2 =

- Tweak: Now you can load more than 25 feed posts in Instagram Feed widget.
- Fixed: Google Sheets not working in Table widget.
- Fixed: Carousel swipes in opposite direction in all social feed/reviews widgets.
- Fixed: Duplicated Premium Addons icon in container addons after WordPress v5.6.

= 2.2.1 =

- Fixed: Description not showing issue in Icon Box widget.
- Fixed: Font Awesome icons not showing in Image Hotspots widget.
- Fixed: Inline editing not working for content in Tabs widget.

= 2.2.0 =

- Tweak: Added two new styles to Hover Box widget - [here](https://premiumaddons.com/flip-box-widget-for-elementor-page-builder/).
- Tweak: Added Carousel option in Facebook/Instagram Feed widgets.
- Tweak: Added Equal Height option in Facebook/Twitter Feed widgets.
- Tweak: Added Lottie Animation Icon option in Tabs widget.
- Tweak: Added Whole Box Link and Link Position options in Icon Box widget.
- Tweak: Added responsive controls for Carousel Tabs option in Tabs widget.
- Tweak: Added slides spacing for Carousel Tabs option in Tabs widget.
- Tweak: Added Rotate option to back icon in Icon Box widget.
- Tweak: Hotspots Image render function code refactored to improve for site performance.
- Tweak: Removed API Key option in Behance Feed widget.
- Fixed: List layout width issue in Facebook/Twitter Feed widgets.
- Fixed: Multi Scroll widget console error with some themes.
- Fixed: Horizontal Scroll widget issues on browser window resize.
- Fixed: Tabs widget spacing issues on small screens.
- Fixed: Default padding given to content in Content Toggle widget.
- Fixed: Widgets Badge White Labeling option not working.
- Fixed: Warning `Trying to access array offset on value of type null` when Navigation Arrows option is disabled in Horizontal Scroll widget.

= 2.1.4 =

- Tweak: Added WPML Compatibility for Table widget.
- Fixed: Bounce image issue in Parallax container addon.
- Fixed: Font Awesome icons not showing in social feed widgets.

= 2.1.3 =

- Tweak: Alt attribute is now reading from Media library for images in Image Layers widget.
- Tweak: Unnecessary code removed for better performance.

= 2.1.2 =

- Tweak: Added Text Editor/Template Content Type option in Unfold widget.
- Tweak: Added Interactive option for tooltips in Image Hotspots widget.
- Tweak: Added File Source (URL/File Upload) option in Lottie Animations container addon.
- Fixed: Images Alt attribute not added in multi-layered Parallax addon.
- Fixed: Images stretch issue in Image Comparison widget.
- Fixed: Handle not moving in RTL sites issue in Image Comparison widget.
- Fixed: Responsive controls for section background not applied on Parallax addon.
- Fixed: Custom Data table not pulling data after the file URL is changed in Table widget.
- Fixed: Instagram video not showing in RTL sites in Instagram Feed widget.

= 2.1.1 =

- Tweak: Added new skin Cards in Facebook, Google and Yelp Reviews widgets.
- Tweak: Added Maximum Words Number option for image caption in Instagram Feed widget.
- Fixed: Icon Color option not applied on SVGs in Tabs widget.
- Fixed: Place/Page avatar alignment issue on Twenty Twenty theme in Facebook, Google and Yelp Reviews widgets.

= 2.1.0 =

- Fixed: Icon Spacing option not working on RTL sites in WhatsApp Chat widget.
- Fixed: Icon Spacing option not working when Icon Position is set to After in Magic Section widget.
- Fixed: Freehand design option not working in Image Layers, Hotspots and Parallax container addon after Elementor 3.0.0.
- Fixed: Page update button is disabled after using Freehand position/resize feature.

= 2.0.9 =

- Fixed: Compatibility issues with Elementor v3.0.0.
- Fixed: Particles addon appears below section in RTL sites issue.
- Fixed: Undefined 'open_graph_story' in Facebook Reviews widget.
- Fixed: Icon Size option not working with SVG icons in Icon Box widget.

= 2.0.8 =

- Tweak: Add different color to each dataset value in bar Chart widget.
- Fixed: WhatsApp Chat widget group option not working on mobile devices.
- Fixed: Hotspots Horizontal Position option not working for RTL sites in Image Hotspots widget.
- Fixed: Compatibility issues with WordPress 5.5.

= 2.0.7 =

- Tweak: Added Change Colors As Gradient option in Background Transition widget.
- Tweak: API Version updated for Facebook Reviews/Feed widgets.
- Fixed: Filter by Tags option letter case sensitive in Instagram Feed widget.

= 2.0.6 =

- Tweak: Added caching option for remote CSV files in Table widget.
- Tweak: Added Filter by Tags option in Instagram Feed widget.

= 2.0.5 =

- Tweak: Instagram deprecated API replaced with Facebook API in Instagram Feed widget.
- Tweak: Added Color options for feed links in Twitter/Facebook Feed widgets.
- Tweak: Added Background Color, Margin and Padding option for readmore link in Twitter/Facebook Feed widgets.
- Fixed: Widgets with entrance animations not showing on tablet/mobile devices in Horizontal Scroll widget.

= 2.0.4 =

- Tweak: Premium Instagram Feed widget now supports Instagram videos.
- Tweak: Added RTL Mode option in Horizontal Scroll widget.
- Tweak: Added Image icon option in Tabs widget.
- Tweak: Added Carousel Tabs option in Tabs widget.
- Tweak: Added Change Readmore text option in social reviews widgets.
- Tweak: Added Render Type option in Lottie Animations container addon.
- Tweak: Added Speed option in Flip Box widget.
- Fixed: Facebook Feed widget date not showing in Safari.
- Fixed: Social reviews carousel issue in RTL sites.
- Fixed: Vertical Image Comparison widget not working when label option is disabled.

= 2.0.3 =

- Fixed: container addon and some widgets not working since v2.0.2

= 2.0.3 =

- Fixed: container addon and some widgets not working since v2.0.2

= 2.0.2 =

- Fixed: Image Layers scroll effects not working since v2.0.0
- Fixed: Premium Lottie container addon editor overloading issue.
- Fixed: WhatsApp button not working on iOS mobile devices.

= 2.0.1 =

- Fixed: Freehand positioning conflict in Lottie Animations container addon.
- Fixed: Entrance animation duplicate issue in Horizontal Scroll widget.

= 2.0.0 =

- New: Introducing Lottie Animations Integration for all the widgets including icon options.
- New: Added Premium Lottie Animations container addon.
- Tweak: Added Overlay Background option to Alert Box widget.
- Tweak: Added Default Tab Index option to Tabs widget.
- Tweak: Added Border Radius option for button in Content Switcher widget.
- Tweak: Added Show/hide layers on different devices option in Parallax addon multi layers.
- Tweak: Added Floating Effects in Image Hotspots and Preview Window widgets.
- Fixed: Horizontal Scroll not scrolling below last slide on Snappy effect.
- Fixed: Widgets masonry layout issues on the editor on Chrome browser.
- Fixed: Table widget responsive option not working on tablets.
- Fixed: Instagram Feed new API not working for logged out users.
- Fixed: Instagram login button not working when Facebook Reviews widget is disabled.
- Fixed: Conflict with Pinpoint Booking System Plugin shortcodes.
- Fixed: Multi Scroll widget Left/Right Section Width option override previous widgets.
- Fixed: PHP error `Trying to access array offer on value of type bool` in /white-label/admin.php.
- Fixed: Console error `jQuery is not defined` in Image Hotspots widget.
- Fixed: Compatibility errors with PHP v7.0

= 1.9.3 =

- Tweak: Added new API options for Instagram Feed widget.
- Fixed: Horizontal Scroll widget not working on RTL sites.
- Fixed: Opacity floating effect now working in Image Layers widget.

= 1.9.2 =

- Tweak: Added Hover Text/Icon Color option for Trigger Button in Magic Section widget.
- Tweak: Added Opacity to Float Effects in Image Layers widget.
- Tweak: Change "Read More" link text option added in Facebook/Twitter Feed widgets.
- Tweak: Added `Mouse Tilt` option in Icon Box widget.
- Tweak: Get 'alt' attribute for images in iHover widget.
- Fixed: Dynamic links not working for some elements.
- Fixed: Warning `Trying to access array offset on value of type bool` in container addons.

= 1.9.1 =

- Tweak: Added support for dynamic fields in all social media widgets.
- Fixed: Scrolling issues in Horizontal Scroll widget.
- Fixed: Console error `ReferenceError: module is not defined`

= 1.9.0 =

- New: Added Horizontal Scroll widget.
- Tweak: Added `Animation Duration` option in Animated Gradient container addon.
- Tweak: Added Chinese to Language option for Facebook Messenger Chat widget.
- Tweak: Added `Whole Box Link` option in Icon Box widget.

= 1.8.9 =

- Tweak: Added `Load Chart on Scroll/Page Load` option in Charts widget.
- Tweak: Added `Animation Duration` option in Charts widget.
- Fixed: Filters by rating not working properly when review rating is not set in Facebook Reviews widget.

= 1.8.8 =

- Tweak: Improved `Filter By Language` option in Google Reviews widget.
- Fixed: Spacings not applied on tooltips templates in Image Hotspots widget.
- Fixed: Colors applied on `Whole Box Link` in iHover widget.
- Fixed: Rating Schema in Google Reviews widget.

= 1.8.7 =

- Tweak: Added `Pagination` options in Table widget.
- Tweak: Added `Carousel` options in Twitter Feed widget.

= 1.8.6 =

- Tweak: Now, you can remove all header cells in Table widget.
- Tweak: Added `Hover Text Animation` switcher option in Flip Box widget.

= 1.8.5 =

- Tweak: Added new effects for Ken Burns addon.
- Tweak: Added `Reverse Direction` for mousemove parallax in Image Layers widget.

= 1.8.4 =

- Tweak: Added `Link` option for header cells in Table widget.
- Fixed: `Transition Speed` option not working in Ken Burns container addon.

= 1.8.3 =

- Tweak: Added `Padding` option for container in Facebook Reviews widget.

= 1.8.2 =

- Tweak: Added `Blend Mode` option to iHover, Image Hotspots and Image Layers widgets.
- Tweak: Added `Filter by Tags` option to Instagram Feed widget.
- Fixed: Lightbox not working in Instagram Feed widget.
- Fixed: Console errors on IE due to Background Transition widget.

= 1.8.1 =

- Tweak: Added `Floating Effects` to Image Layers widget.
- Tweak: Added `Zoom In/Out` option for each layer in Ken Burns addon.

= 1.8.0 =

- Tweak: Added four new effects to Flip Box widget.
- Tweak: 3D flip effect animation enhanced in Flip Box widget.

= 1.7.9 =

- Tweak: Now you can set different style to each hotspot item in Image Hotspots widget.
- Tweak: Added link option for Button in Alert Box widget.
- Tweak: Added Hover Background Color option Alert Box widget.
- Fixed: Not all ratings are pulled in Facebook Reviews widget.

= 1.7.8 =

- Tweak: Added Spinner styling option for loading spinner in Instagram Feed widget.
- Fixed: `$` is not defined in Facebook Reviews and Feed widgets.

= 1.7.7 =

- Tweak: Added `Button` option to iHover widget.
- Tweak: Added `Hide Plugin Row Meta` and `Hide Plugin Changelog Link` to plugin White Labeling options.
- Fixed: Background Transition widget not working with `RGB` colors.
- Fixed: Console errors with invalid sections CSS IDs in Background Transition widget.

= 1.7.6 =

- Tweak: Added `CSS Filter` for normal/hover state in Image Hotspots widget.
- Fixed: Grey line appears by default in Image Layers widget.
- Fixed: Even Layout not working with Carousel option enabled in all Reviews widgets.
- Fixed: Carousel slides not appearing on RTL sites in all Reviews widgets.
- Fixed: SVG icons size option not working in all widgets.
- Fixed: Link title and icon are not aligned in Icon Box widget.

= 1.7.5 =

- Tweak: Premium Background Transition widget improved.
- Fixed: Caching is not applied on place data in Yelp Reviews widget.
- Fixed: Nested Premium Tabs not appearing.
- Fixed: Active Tab box shadow option not applied on the same selector in normal/hover in Tabs widget.

= 1.7.4 =

- Tweak: Added caching option `Reload Reviews Once Every` in Facebook, Google and Yelp Reviews widgets.

= 1.7.3 =

- Fixed: Instagram Feed widget not working on IE browsers.

= 1.7.2 =

- Tweak: Added `Render First Row As` option in Table widget.
- Fixed: Flipbox widget `Whole Box` link option is not working.
- Fixed: Default icon is not working in iHover widget.

= 1.7.1 =

- New: Added Color Transition widget.
- Tweak: Get Instagram feed by Access Token only.
- Tweak: Added dynamic field support for CSV file in Table widget.

= 1.7.0 =

- Fixed: Instagram Feed loading spinner does not appear on preview page.

= 1.6.9 =

- Tweak: Added `Hover Color` option for title/icon in Tabs widget.
- Fixed: Active tab Margin/Padding issue in Tabs widget.
- Fixed: Vertical Tabs widget alignment issue.
- Fixed: Security bugs fixed.

= 1.6.8 =

- Tweak: Added `Schema Support` option for all Reviews widgets.
- Tweak: Font Awesome 5 compatibility for all widgets.

= 1.6.7 =

- Tweak: Added `Minimum Value` option in Charts widget.

= 1.6.6 =

- Tweak: Added `Line Width` option for grid lines in Charts widget.
- Tweak: Added transition for Image Accordion overlay color.
- Fixed: Parallax container addon does not work on frontend pages.

= 1.6.5 =

- Tweak: Load assets files for container addons only when needed to improve performance.
- Tweak: Added `Step Size` option for Radar type Charts.
- Fixed: Tabs nav container changed to div to prevent styling issues.

= 1.6.4 =

- Fixed: `Reviews Word Length` option does not work for non-latin characters in all reviews widgets.
- Fixed: `Notice: Undefined variable: tool_tips_image_url` in Preview Window widget.

= 1.6.3 =

- Tweak: Added responsive controls for `Alignment` option in iHover widget.
- Fixed: `Border Color` option missing for `Style 3` in Tabs widget.
- Fixed: Bottom positioned Magic Section appears after page load.

= 1.6.2 =

- Tweak: Added `Facebook Login` Button to Premium Facebook Feed widget for easier feed pull.
- Fixed: `Maximum Value` option added to Radar chat type in Charts widget.
- Fixed: `Carousel Arrows Position` option shows when `Autoplay` option is enabled in Yelp Reviews widget.
- Fixed: Loader spinner not showing on the preview page in Facebook/Twitter Feed.

= 1.6.1 =

- Tweak: Added `RTL Mode` option for Facebook, Google and Yelp Reviews widgets.
- Fixed: `Transition Speed` option not working for Ken Burns container addon.
- Fixed: Image Layers `Freehand` reposition not working if page contains Premium Carousel widget.

= 1.6.0 =

- Tweak: Added `Review Length` option to Facebook Reviews widget.
- Fixed: Images pixelated when size is increased in Facebook Reviews widget.
- Fixed: Messenger Chat icon not showing on mobile devices.
- Fixed: Cells alignment issue with multi-line text in Table widget.
- Fixed: Blank line below Instagram images for some themes.

= 1.5.9 =

- New: Added Yelp Reviews widget.
- Tweak: Added `Facebook Login` Button to Premium Facebook Reviews widget for easier reviews pull.
- Tweak: Added `Review Length` option in Google Reviews widget.
- Tweak: Added `Responsive Controls` for Premium Particles container addon.
- Tweak: Added `Table Layout` option in Premium Table widget.
- Fixed: Divider and text in Premium Divider widget are not centered in some themes.
- Fixed: `Button Size` in Unfold widget not applied on the front-end.
- Fixed: Back side `Link`  unclickable on Microsoft Edge in Flip Box widget.
- Fixed: Twitter/Facebook Feed time elapsed Singular/Plural issue.
- Fixed: Clipped reviewer profile picture in Google Reviews widget.

= 1.5.8 =

- New: Added Image Accordion widget.
- Fixed: Title/Icon are not horizontally centered in styles 3,4 in Tabs widget.

= 1.5.7 =

- Tweak: `Read More` button redirects to post instead of page in Facebook Feed widget.
- Fixed: Carousel arrows styling only works on the editor page in Google/Facebook Reviews widget.
- Tweak: Added `Theme` option for lightbox in Instagram widget.
- Tweak: Added `Date Format` option in Facebook Reviews widget.

= 1.5.6 =

- Tweak: Added `Fade Speed` option for Ken Burns container addon.
- Fixed: Posts` images don't appear in Facebook Feed widget.

= 1.5.5 =

- Fixed: Reviews date doesn't appear with `Place Info` option disabled.
- Fixed: Right templates shift to left by `1px` in Multi Scroll widget.
- Fixed: Facebook Feed widget doesn't work with APIs v3.3.

= 1.5.4 =

- Tweak: Plugin core refactored to improve performance.

= 1.5.3 =

- Fixed: Charts animation doesn't work when height option is set.
- Fixed: `Tabs Background` overrides lists background for `Style 3` in Tabs widget.

= 1.5.2 =

- Fixed: `Dynamic Content` doesn't work when `ACF Field` is selected in Table widget.

= 1.5.1 =

- Tweak: `Tilt Mouse Interactivity` doesn't work on IE for Image Layers widget.

= 1.5.0 =

- Fixed: Image Comparison broken on IE with Section Vertical Parallax enabled.

= 1.4.9 =

- Tweak: Added `Outer Background Color` option for container in Preview Window widget.
- Fixed: Magic Section content appears until page is loaded.
- Fixed: Image Comparison broken on IE with Image Layers scroll effects enabled.

= 1.4.8 =

- Tweak: `WPML Compatibility` for all widgets.
- Fixed: License deactivation issues.
- Fixed: Google reCaptcha doesn't work after v1.4.8
- Fixed: Particles are stretched on small screens.
- Fixed: Elements don't load with `MyListing` theme.

= 1.4.7 =

- Tweak: Added `Stretch Image` option for background image in Image Hotspots widget.
- Fixed: Console error `UniversalTilt undefined` on IE browser with Image Layers widget.

= 1.4.6 =

- Tweak: Added `Dynamic Field` support for Instagram widget.
- Fixed: `Invalid Character on line 3361` after v1.3.5

= 1.4.5 =

- Tweak: Added `Scroll Effects` for images in Image Layers widget.
- Tweak: Added `Freehand` positioning, resizing features for layers in Image Layers widget and Multi Layer Parallax.
- Tweak: Added `Freehand` positioning feature for Image Hotspots widget.
- Tweak: Added `Date Format` option for Google Reviews widget.
- Tweak: Added `Dynamic Field` support for all `URL` fields.
- Fixed: Content Switcher widget button issue when browse back page button is clicked.
- Fixed: `Save Settings` button doesn't work in White Labeling Dashboard submenu.
* **Important: This update includes deep enhancements for Image Hotspots, Image Layers widgets and Parallax addon. So, please review your existing pages.**

= 1.4.4 =

- Tweak: Added `Data Separator` option for CSV files in Table widget.
- Fixed: Layout issues on Microsoft IE browser.
- Fixed: `Notice: Undefined index: premium_parallax_android_support` , `premium_parallax_ios_support` in Parallax addon.

= 1.4.3 =

- Tweak: Prevent adding inline styles/scripts for container addons.
- Tweak: Changed Particles addon `JSON` code area from `TEXTAREA` to `CODE`
- Tweak: Ability to change `Live Search` and `Show Records` strings in Table widget.
- Tweak: Wait images to load before triggering `Masonry` layout in Facebook Feed widget.
- Fixed: Cells align right issue on Google Chrome in Table widget.
- Fixed: Premium Divider issues with `Elementor Custom Positioning` option.

= 1.4.2 =

- Tweak: Added `Show Records` option in Table widget.
- Tweak: Added `Blur On Hover` effect in Table widget.
- Tweak: Added `responsive controls` for Search field in Table widget.
- Tweak: Added `Text Color` option for Search field in Table widget.
- Tweak: Added `Settings` to plugin action links on `Plugins` page.

= 1.4.1 =

- Tweak: Added `Left/Right Section Width` option to control width ratio in Multi Scroll widget.
- Tweak: Added `Show Caption` option to show photo caption in Instagram widget.
- Tweak: Added `CSS Filters` options group for hover state in Instagram widget.

= 1.4.0 =

- Fixed: Premium Twitter Feed does not work.

= 1.3.9 =

- Tweak: Premium Parallax background position, repeat and size inherit from Elementor responsive background options.
- Tweak: Added responsive controls for `Arrow Size` option in Premium Facebook/Google Reviews widgets.
- Tweak: Added `CSS Filters` option for images for trigger and preview images in Preview Image widget.
- Tweak: Code refactor to enhance plugin performance speed.

= 1.3.8 =

- Tweak: Added responsive controls for `Number of Columns` option in Premium Facebook/Google Review and Facebook/Twitter widgets.
- Tweak: Added `CSS Filters` option for images in Premium Behance/Instagram Feed and iHover widgets.

= 1.3.7 =

- Tweak: Added responsive controls for `Images per Row` option in Premium Instagram widget.
- Tweak: Added `Widgets Badge` option to white labeling to change widgets` icons badge text.
- Fixed: Enable Parallax on Android/iOS does not work for Parallax container addon.
- Fixed: Different images height when `Masonry` option is disabled in Premium Instagram widget.

= 1.3.6 =

- Fixed: Warning: require_once(/premium-addons-pro-includes/deps/json.php): failed to open stream: No such file or directory.
- Fixed: Images order when `Masonry` option is disabled in Premium Instagram Feed widget.

= 1.3.5 =

- Tweak: JS enhancements in Facebook, Twitter and Instagram elements to improve plugin performance.
- Tweak: Added `Infinite` option for single image in Ken Burns addon.
- Fixed: Set Tabs content to Full Width issue.
- Fixed: Posts overlapping when masonry option enabled in Premium Facebook Feed widget.

= 1.3.4 =

- Tweak: JS enhancements in Charts, Facebook/Google Reviews, Image layers, Multi Scroll , and Tabs elements to improve plugin performance.
- Tweak: Dynamic data support for `Image` in Premium Divider widget.

= 1.3.3 =

- Tweak: Dynamic data support in Premium Ken Burns addon.
- Fixed: Image Hotspots widget issue on preview page.

= 1.3.2 =

- Fixed: Pointer cursor for cells with `Link` option disabled in Premium Table widget.
- Fixed: overlapping issue when iHover widget `Link` option is enabled.
- Fixed: Tabs widget layout issue on iOS devices.

= 1.3.1 =

- Tweak: Added `Border Width` option for each dataset in Premium Charts widget.
- Fixed: `Warning: Creating default object from empty value` in Premium Google Reviews widget.


= 1.3.0 =

- Tweak: Unnecessary `esc_html()` function removed.
- Tweak: Unnecessary conditions removed to enhance editor page loading speed.

= 1.2.9 =

- Tweak: Added `Second Fill Color` option to create gradients in Line, Bar and Horizontal Bar charts.
- Tweak: Unnecessary functions removed from Facebook Feed, Charts, Behance and Image Comparison widgets to enhance performance.


= 1.2.8 =

- Tweak: CSS files loaded only when required to enhance plugin performance.
- Tweak: Show label next to value on Pie/Doughnut Premium Chart hover.

= 1.2.7 =

- Tweak: Added `Show Values on Chart` option to Pie/Doughnut chart in Premium Charts widget.

= 1.2.6 =

- Tweak: Added language option to Premium Messenger Chat widget.
- Fixed: `View Details` link appears for Premium Addons for Elementor with White Labeling enabled.

= 1.2.5 =

- Tweak: Formatting Y-Axis labels numbers in Premium Charts widget.
- Tweak: Ken Burns can now be used with only one image.
- Fixed: Charts not visible when inserted in Elementor Accordion widget.
- Fixed: CSV files don't appear in Media in Premium Tables widget.


= 1.2.4 =

- Tweak: Added Overlay Color option to Premium Ken Burns container addon.
- Fixed: `Detected usage of deprecated noAndroid` with Premium Parallax container addon.
- Fixed: Premium Messenger Chat not working after Facebook latest Apps update.

= 1.2.3 =

- Tweak: Added vertical tabs sections width option in Premium Tabs widget.
- Tweak: Added Filter by language option in Premium Google Reviews widget.

= 1.2.2 =

- Tweak: Added arrow size and padding options to carousel arrows in Premium Facebook/Google reviews widget.
- Tweak: Dynamic data support in Premium Charts widget.
- Tweak: Shortcodes support using text editor in Premium Content Switcher widget.
- Fixed: Charts issue when inserted inside Premium Modal Box widget.

= 1.2.1 =

- Fixed: Projects with grid images in Premium Behance widget.

= 1.2.0 =

- Tweak: Added Column Width option in Premium Charts widget.
- Tweak: Added Carousel Autoplay speed option in Premium Facebook/Google reviews widget.
- Tweak: Added Carousel Arrows position option in Premium Facebook/Google reviews widget.
- Fixed: Carousel responsive issues in Premium Facebook/Google reviews widget.
- Fixed: Reviews issue when no stars is returned with review.

= 1.1.9 =

- Tweak: Hide specific sections on mobiles/tables option added to Multi Scroll widget.

= 1.1.8 =

- Fixed: Sections order on mobile/tablets in Multi Scroll widget.

= 1.1.7 =

- Fixed: Responsive issues in Premium Multi Scroll widget.

= 1.1.6 =

- New: Added Multi Scroll widget.
- Tweak: Added Margin Option for Magic Section widget in active case.
- Fixed: Google Reviews unloaded place image.
- Fixed: Tabs background/arrow color issue.

= 1.1.5 =

- Tweak: Premium Table widget performance enhanced.
- Tweak: Added Dynamic Images option for all widgets.
- Tweak: Added Dynamic place id option for Premium Google Reviews widget.
- Tweak: Added Carousel option for Premium Facebook/Google reviews widget.

= 1.1.4 =

- Fixed: Premium Tabs conflict issue.
- Fixed: Facebook/Twitter Feed read more issue.

= 1.1.3 =

- Fixed: Facebook Feed widget conflict issue.

= 1.1.2 =

- Tweak: Added convert values to percentage in Premium Charts widget.
- Fixed: Call to a member function get_error_message() on array after license activation.

= 1.1.1 =

- Tweak: Plugin core enhancement for faster performance.
- Tweak: Premium Divider widget performance enhanced.
- Tweak: Premium Flip Box widget performance enhanced.
- Tweak: Premium Icon Box widget performance enhanced.
- Tweak: Premium Image Layers widget performance enhanced.
- Tweak: Premium iHover widget performance enhanced.

= 1.1.0 =

- Fixed: Tabs issue on IE browser.
- Fixed: Group Control issue in Premium Facebook/Twitter widgets.

= 1.0.9 =

- Fixed: Warning "Invalid argument supplied for foreach() in /premium-addons-pro/widgets/premium-tables.php on line 1567".

= 1.0.8 =

- Fixed: License not Valid after trying to activate license.

= 1.0.7 =

- New: Added WhatsApp Chat widget.

= 1.0.6 =

- Fixed: Image size issue in Premium Parallax addon.
- Fixed: Transparent images grey background issue.
- Fixed: Invisible charts issue.

= 1.0.5 =

- Tweak: App ID and App secret are changed to Access Token in Facebook Feed widget.

= 1.0.4 =

- Tweak: Animations starts on scrolling in Premium Charts widget.

= 1.0.3 =

- New: Added Facebook Feed element.

= 1.0.2 =

- Tweak: Added Background Size/Position options in Premium Section Parallax.
- Fixed: Instagram Feed grid issue when Masonry is disabled.
- Fixed: Fatal error: Can't use function return value in write context for PHP versions below 5.5

= 1.0.1 =

- Tweak: Added URLs option to each dataset in Premium Charts widget.
- Tweak: Added image fill option in Premium Ken Burns.

= 1.0.0 =

- Initial stable release.