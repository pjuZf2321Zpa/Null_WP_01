<?php
/**
 * Yith Wcan Compatibility class
 *
 * @since 7.5.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

class Porto_Yith_Wcan_Compatibility {
	/**
	 * Constructor
	 *
	 * @since 7.5.0
	 */
	public function __construct() {
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ), 999 );
		add_filter( 'yith_woocommerce_reset_filters_attributes', array( $this, 'add_brand_to_reset_filters' ) );
	}

	/**
	 * Count the WooCommerce brand filter as an active filter of the Yith "Reset Filters" widget
	 *
	 * Yith decides whether to show the widget from the chosen attributes of
	 * WC_Query::get_layered_nav_chosen_attributes(), which only collects the product attribute
	 * taxonomies. The brand filter of WooCommerce travels in "filter_product_brand" and never
	 * reaches that list, so the widget stayed hidden and a shop filtered by brand had no way back.
	 *
	 * @since 7.8.0
	 *
	 * @param array $attributes Chosen attributes, as taxonomy => array( terms, query_type ).
	 * @return array
	 */
	public function add_brand_to_reset_filters( $attributes ) {
		if ( empty( $_GET['filter_product_brand'] ) || ! is_string( $_GET['filter_product_brand'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return $attributes;
		}

		$terms = array_filter( explode( ',', wc_clean( wp_unslash( $_GET['filter_product_brand'] ) ) ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		if ( empty( $terms ) ) {
			return $attributes;
		}

		if ( ! is_array( $attributes ) ) {
			$attributes = array();
		}

		$query_type = ! empty( $_GET['query_type_product_brand'] ) ? wc_clean( wp_unslash( $_GET['query_type_product_brand'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		$attributes['product_brand'] = array(
			'terms'      => array_map( 'sanitize_title', $terms ),
			'query_type' => 'or' === $query_type ? 'or' : 'and',
		);

		return $attributes;
	}

	/**
	 * Enqueue scripts
	 *
	 * @since 7.5.0
	 */
	public function enqueue_scripts() {
        global $porto_settings_optimize;
		if ( porto_is_shop() || porto_is_product_archive() ) { // product archive page and single product page
			return;
		}
        if ( ! empty( $porto_settings_optimize['optimize_yith_wcan'] ) ) {
    		wp_dequeue_style( 'yith-wcan-shortcodes' );
			wp_dequeue_script( 'yith-wcan-shortcodes' );
        }
	}

}

new Porto_Yith_Wcan_Compatibility();
