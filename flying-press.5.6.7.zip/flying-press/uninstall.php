<?php

defined('WP_UNINSTALL_PLUGIN') or die();

require_once __DIR__ . '/vendor/autoload.php';

delete_option('FLYING_PRESS_CONFIG');
delete_option('FLYING_PRESS_VERSION');
FlyingPress\Translations::delete_files();
FlyingPress\Queue::delete_table();
