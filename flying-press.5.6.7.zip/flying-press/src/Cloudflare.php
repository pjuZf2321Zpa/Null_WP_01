<?php

namespace FlyingPress;

use FlyingPress\{Config, Caching};

class Cloudflare
{
  // Increment when Cloudflare rule definitions change
  private const RULES_VERSION = 3;

  private static $host;

  public static function init()
  {
    self::$host = parse_url(site_url(), PHP_URL_HOST);

    add_action('activated_plugin', [__CLASS__, 'on_activation']);
    add_action('deactivate_' . FLYING_PRESS_FILE_NAME, [__CLASS__, 'on_deactivation']);
    add_action('flying_press_upgraded', [__CLASS__, 'on_upgrade']);
    add_action('flying_press_update_config:after', [__CLASS__, 'on_config_updated'], 10, 2);

    add_action('flying_press_purge_urls:before', [__CLASS__, 'purge_urls']);
    add_action('flying_press_purge_pages:before', [__CLASS__, 'purge_pages']);
    add_action('flying_press_purge_everything:before', [__CLASS__, 'purge_everything']);
  }

  public static function on_activation($plugin)
  {
    if (strpos($plugin, FLYING_PRESS_FILE_NAME) === false) {
      return;
    }
    self::sync_rules();
  }

  public static function on_deactivation()
  {
    self::delete_rules();
  }

  public static function on_upgrade()
  {
    if (!self::is_configured()) {
      return;
    }
    if ((Config::$config['cf_rules_version'] ?? 0) === self::RULES_VERSION) {
      return;
    }
    self::sync_rules();
  }

  public static function on_config_updated($new, $prev)
  {
    $creds_changed =
      ($prev['cf_email'] ?? '') !== ($new['cf_email'] ?? '') ||
      ($prev['cf_api_key'] ?? '') !== ($new['cf_api_key'] ?? '');

    if ($creds_changed) {
      Config::update_config([
        'cf_zone_id' => '',
        'cf_zone_domain' => '',
        'cf_host_signature' => '',
      ]);
      if (!empty($new['cf_api_key'])) {
        self::resolve_zone_id();
      }
    }

    $keys = ['cdn', 'cdn_type', 'cf_page_caching', 'cache_mobile', 'cache_bypass_cookies'];
    foreach ($keys as $key) {
      if (($prev[$key] ?? null) !== ($new[$key] ?? null)) {
        self::sync_rules();
        return;
      }
    }

    if ($creds_changed) {
      self::sync_rules();
    }
  }

  public static function sync_rules()
  {
    if (self::has_credentials() && !self::has_valid_zone()) {
      Config::update_config([
        'cf_zone_id' => '',
        'cf_zone_domain' => '',
        'cf_host_signature' => '',
      ]);

      self::resolve_zone_id();
    }

    if (!self::is_active()) {
      if ((Config::$config['cf_status'] ?? 'not_setup') !== 'api_error') {
        Config::update_config(['cf_status' => 'not_setup']);
      }
      self::delete_rules();
      return;
    }

    $refs = self::rule_refs();
    $ids = [];

    foreach (['http_request_cache_settings', 'http_request_transform'] as $phase) {
      $ruleset = self::api('GET', "/rulesets/phases/{$phase}/entrypoint");

      if (empty($ruleset['id'])) {
        $ruleset = self::api('POST', '/rulesets', [
          'kind' => 'zone',
          'phase' => $phase,
          'name' => "FlyingPress {$phase}",
        ]);
      }

      if (empty($ruleset['id'])) {
        return;
      }

      foreach ($ruleset['rules'] ?? [] as $rule) {
        $is_ours =
          in_array($rule['ref'] ?? '', $refs, true) ||
          ((Config::$config['cf_host_signature'] ?? '') === md5(self::$host) &&
            strpos($rule['description'] ?? '', 'FlyingPress') === 0);
        if ($is_ours) {
          self::api('DELETE', "/rulesets/{$ruleset['id']}/rules/{$rule['id']}", [], false);
        }
      }

      $ids[$phase] = $ruleset['id'];
    }

    $results = [
      self::api(
        'POST',
        "/rulesets/{$ids['http_request_cache_settings']}/rules",
        self::cache_rule_payload()
      ),
      self::api(
        'POST',
        "/rulesets/{$ids['http_request_cache_settings']}/rules",
        self::cache_file_rule_payload()
      ),
      self::api(
        'POST',
        "/rulesets/{$ids['http_request_transform']}/rules",
        self::rewrite_rule_payload()
      ),
    ];

    if (!in_array(null, $results, true)) {
      Config::update_config([
        'cf_rules_version' => self::RULES_VERSION,
        'cf_status' => 'success',
      ]);
    }
  }

  public static function purge_urls($urls)
  {
    $files = [];
    foreach ($urls as $url) {
      foreach (['desktop', 'mobile', 'tablet'] as $device) {
        $files[] = ['url' => $url, 'headers' => ['CF-Device-Type' => $device]];
      }
    }

    foreach (array_chunk($files, 100) as $batch) {
      self::api('POST', '/purge_cache', ['files' => $batch], false);
    }
  }

  public static function purge_pages()
  {
    self::api('POST', '/purge_cache', ['tags' => [self::$host]], false);
  }

  public static function purge_everything()
  {
    self::api('POST', '/purge_cache', ['purge_everything' => true], false);
  }

  private static function is_active()
  {
    return self::is_configured() && self::has_valid_zone();
  }

  private static function is_configured()
  {
    $config = Config::$config;
    return !empty($config['cdn']) &&
      ($config['cdn_type'] ?? '') === 'cloudflare' &&
      !empty($config['cf_page_caching']) &&
      self::has_credentials();
  }

  private static function has_credentials()
  {
    $config = Config::$config;
    if (empty($config['cf_api_key'])) {
      return false;
    }
    // API Token auth needs only the key; Global API Key auth also needs email.
    return self::is_api_token($config['cf_api_key']) || !empty($config['cf_email']);
  }

  private static function zone_matches_host($host, $zone)
  {
    $host = strtolower(rtrim($host, '.'));
    $zone = strtolower(rtrim($zone, '.'));

    return $host === $zone || substr($host, -strlen('.' . $zone)) === '.' . $zone;
  }

  private static function has_valid_zone()
  {
    $config = Config::$config;

    return !empty($config['cf_zone_id']) &&
      !empty($config['cf_zone_domain']) &&
      self::zone_matches_host(self::$host, $config['cf_zone_domain']);
  }

  private static function is_api_token($key)
  {
    $key = trim($key);

    if (strpos($key, 'cfut_') === 0 || strpos($key, 'cfat_') === 0) {
      return true;
    }
    if (strpos($key, 'cfk_') === 0) {
      return false;
    }
    // Legacy formats: Global API Key is lowercase hex (37–45 chars).
    return !preg_match('/^[a-f0-9]{37,45}$/', $key);
  }

  private static function delete_rules()
  {
    $refs = self::rule_refs();

    foreach (['http_request_cache_settings', 'http_request_transform'] as $phase) {
      $ruleset = self::api('GET', "/rulesets/phases/{$phase}/entrypoint");
      if (empty($ruleset['id'])) {
        continue;
      }

      foreach ($ruleset['rules'] ?? [] as $rule) {
        $is_ours =
          in_array($rule['ref'] ?? '', $refs, true) ||
          ((Config::$config['cf_host_signature'] ?? '') === md5(self::$host) &&
            strpos($rule['description'] ?? '', 'FlyingPress') === 0);
        if ($is_ours) {
          self::api('DELETE', "/rulesets/{$ruleset['id']}/rules/{$rule['id']}", [], false);
        }
      }
    }
  }

  private static function resolve_zone_id()
  {
    if (!self::has_credentials()) {
      return null;
    }

    $page = 1;
    do {
      $resp = wp_remote_get("https://api.cloudflare.com/client/v4/zones?per_page=50&page={$page}", [
        'headers' => self::headers(),
      ]);

      if (is_wp_error($resp) || wp_remote_retrieve_response_code($resp) !== 200) {
        error_log('Cloudflare zone list failed: ' . wp_remote_retrieve_body($resp));
        Config::update_config(['cf_status' => 'api_error', 'cf_page_caching' => false]);
        return null;
      }

      $json = json_decode(wp_remote_retrieve_body($resp), true);
      foreach ($json['result'] ?? [] as $zone) {
        $name = $zone['name'] ?? '';
        if ($name && self::zone_matches_host(self::$host, $name)) {
          Config::update_config([
            'cf_zone_id' => $zone['id'],
            'cf_zone_domain' => $name,
            'cf_host_signature' => md5(self::$host),
            'cf_status' => 'not_setup',
          ]);
          return $zone['id'];
        }
      }

      $total_pages = $json['result_info']['total_pages'] ?? 1;
      $page++;
    } while ($page <= $total_pages);

    Config::update_config(['cf_status' => 'api_error', 'cf_page_caching' => false]);
    return null;
  }

  private static function api($method, $endpoint, $body = [], $blocking = true)
  {
    $config = Config::$config;
    if (!self::has_valid_zone() || !self::has_credentials()) {
      return null;
    }

    $url = "https://api.cloudflare.com/client/v4/zones/{$config['cf_zone_id']}{$endpoint}";
    $resp = wp_remote_request($url, [
      'method' => $method,
      'blocking' => $blocking,
      'headers' => self::headers(),
      'body' => $body ? wp_json_encode($body) : null,
    ]);

    if (!$blocking) {
      return null;
    }

    if (is_wp_error($resp) || wp_remote_retrieve_response_code($resp) !== 200) {
      error_log("Cloudflare API error [{$method} {$endpoint}]: " . wp_remote_retrieve_body($resp));
      Config::update_config(['cf_status' => 'api_error', 'cf_page_caching' => false]);
      return null;
    }

    $json = json_decode(wp_remote_retrieve_body($resp), true);
    return $json['result'] ?? null;
  }

  private static function headers()
  {
    $config = Config::$config;
    $headers = ['Content-Type' => 'application/json'];
    $api_key = trim($config['cf_api_key'] ?? '');

    if (self::is_api_token($api_key)) {
      $headers['Authorization'] = 'Bearer ' . $api_key;
    } else {
      $headers['X-Auth-Email'] = $config['cf_email'];
      $headers['X-Auth-Key'] = $api_key;
    }

    return $headers;
  }

  private static function rule_refs()
  {
    $suffix = md5(self::$host);
    return [
      'cache' => "flying_press_cache_{$suffix}",
      'cache_file' => "flying_press_cache_file_{$suffix}",
      'rewrite' => "flying_press_rewrite_{$suffix}",
    ];
  }

  private static function cache_rule_payload()
  {
    $config = Config::$config;
    $cookies = array_values(
      array_unique(
        array_filter(['wordpress_logged_in', ...((array) ($config['cache_bypass_cookies'] ?? []))])
      )
    );
    $expr = array_map(fn($c) => ' not http.cookie contains "' . $c . '"', $cookies);

    return [
      'ref' => self::rule_refs()['cache'],
      'action' => 'set_cache_settings',
      'expression' =>
        '(http.host eq "' .
        self::$host .
        '" and http.request.uri contains "/" and' .
        implode(' and', $expr) .
        ')',
      'description' => 'FlyingPress cache page',
      'enabled' => true,
      'position' => ['index' => 1],
      'action_parameters' => [
        'cache' => true,
        'browser_ttl' => ['mode' => 'respect_origin'],
        'edge_ttl' => ['mode' => 'bypass_by_default'],
        'cache_key' => [
          'cache_by_device_type' => !empty($config['cache_mobile']),
          'cache_deception_armor' => true,
        ],
      ],
    ];
  }

  private static function cache_file_rule_payload()
  {
    return [
      'ref' => self::rule_refs()['cache_file'],
      'action' => 'set_cache_settings',
      'expression' =>
        '(http.host eq "' .
        self::$host .
        '" and http.request.uri.path.extension in {"7z" "avi" "avif" "apk" "bin" "bmp" "bz2" "class" "css" "csv" "doc" "docx" "dmg" "ejs" "eot" "eps" "exe" "flac" "gif" "gz" "ico" "iso" "jar" "jpg" "jpeg" "js" "mid" "midi" "mkv" "mp3" "mp4" "ogg" "otf" "pdf" "pict" "pls" "png" "ppt" "pptx" "ps" "rar" "svg" "svgz" "swf" "tar" "tif" "tiff" "ttf" "webm" "webp" "woff" "woff2" "xls" "xlsx" "zip" "zst"})',
      'description' => 'FlyingPress cache static files',
      'enabled' => true,
      'action_parameters' => [
        'cache' => true,
        'browser_ttl' => ['mode' => 'override_origin', 'default' => 31536000],
        'edge_ttl' => ['mode' => 'override_origin', 'default' => 31536000],
      ],
    ];
  }

  private static function rewrite_rule_payload()
  {
    $params = apply_filters('flying_press_ignore_queries', Caching::$default_ignore_queries);
    $params = array_map(fn($p) => '"' . addcslashes((string) $p, "\\\"") . '"', $params);
    $expr = array_map(fn($p) => "(http.request.uri.query contains {$p})", $params);

    return [
      'ref' => self::rule_refs()['rewrite'],
      'action' => 'rewrite',
      'action_parameters' => [
        'uri' => [
          'query' => [
            'expression' => $params
              ? 'remove_query_args(http.request.uri.query, ' . implode(', ', $params) . ')'
              : 'http.request.uri.query',
          ],
        ],
      ],
      'description' => 'FlyingPress cache ignore query params',
      'enabled' => true,
      'position' => ['index' => 1],
      'expression' =>
        '(http.host eq "' .
        self::$host .
        '" and (' .
        ($expr ? implode(' or ', $expr) : 'false') .
        '))',
    ];
  }
}
