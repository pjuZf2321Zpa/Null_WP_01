<?php
/**
 * Divi integration module.
 */

namespace Smush\Core\Integrations;

use Smush\Core\Controller;
use Smush\Core\Settings;

if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Class Divi
 */
class Divi extends Controller {
	/**
	 * Constructor to initialize the Divi integration.
	 */
	public function __construct() {
		// Delay hook registration until Divi is fully available.
		$this->register_action( 'after_setup_theme', array( $this, 'register_hooks' ) );
	}

	/**
	 * Register Divi-specific hooks.
	 *
	 * - Always register Divi 4 hook
	 * - Register Divi 5 hook only when active
	 *
	 * @return void
	 */
	public function register_hooks() {
		// Divi 5 support.
		if ( function_exists( 'et_builder_d5_enabled' ) && et_builder_d5_enabled() ) {
			$this->register_action(
				'divi_module_library_modules_dependency_tree',
				array( $this, 'handle_divi_image_sizes_hook' )
			);
		}

		// Divi 4 (and fallback).
		$this->register_action(
			'et_builder_modules_loaded',
			array( $this, 'handle_divi_image_sizes_hook' )
		);
	}

	/**
	 * Handles the removal of Divi's image size calculation hook.
	 *
	 * Removes the `wp_calculate_image_sizes` filter added by Divi when responsive images are disabled
	 * and Smush's CDN with auto-resize is enabled.
	 *
	 * @return void
	 */
	public function handle_divi_image_sizes_hook() {

		if ( ! function_exists( 'et_get_option' ) ) {
			return;
		}

		$smush_settings = Settings::get_instance();
		if (
			'on' !== et_get_option( 'divi_enable_responsive_images' ) &&
			$smush_settings->is_lazyload_active() &&
			$smush_settings->is_auto_resizing_active()
		) {
			remove_filter( 'wp_calculate_image_sizes', 'et_filter_wp_calculate_image_sizes' );
		}
	}
}
