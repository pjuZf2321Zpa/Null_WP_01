<?php
/**
 * Adds / removes server rules.
 *
 * @author     ThemeFusion
 * @copyright  (c) Copyright by ThemeFusion
 * @link       https://classic.avada.com
 * @package    Avada
 * @subpackage Core
 * @since      7.4
 */

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'Direct script access denied.' );
}

define( 'AVADA_MARKER_BEGIN_GZIP_OUTPUT', '# BEGIN_AVADA_GZIP_OUTPUT' );
define( 'AVADA_MARKER_END_GZIP_OUTPUT', '# END_AVADA_GZIP_OUTPUT' );

define( 'AVADA_MARKER_BEGIN_COMPRESSION', '# BEGIN_AVADA_GZIP_COMPRESSION' );
define( 'AVADA_MARKER_END_COMPRESSION', '# END_AVADA_GZIP_COMPRESSION' );

/**
 * Adds / removes server rules.
 */
class Avada_Server_Rules {

	/**
	 * The revision of the rule blocks this class writes.
	 *
	 * Bump this whenever the output of get_gzip_htaccess() or get_mod_rewrite()
	 * changes. Blocks already in the .htaccess file that carry a different
	 * revision are replaced instead of being left alone.
	 *
	 * @since 7.16.2
	 * @var int
	 */
	const RULES_REVISION = 2;

	/**
	 * Name of the option holding the revision that was last written out.
	 *
	 * @since 7.16.2
	 * @var string
	 */
	const REVISION_OPTION = 'avada_server_rules_revision';

	/**
	 * The one, true instance of this object.
	 *
	 * @static
	 * @access private
	 * @since 6.2
	 * @var object
	 */
	private static $instance;

	/**
	 * WP Filesystem object.
	 *
	 * Lazily created, see get_filesystem(). Instantiating this class has to stay
	 * cheap, it happens on admin page loads that never touch the file.
	 *
	 * @access private
	 * @since 7.4
	 * @var object
	 */
	private $wp_filesystem;

	/**
	 * The class constructor.
	 *
	 * @access public
	 * @since 7.4
	 * @return void
	 */
	private function __construct() {
		add_action( 'updated_option', [ $this, 'maybe_change_server_rules' ], 10, 3 );
		add_action( 'added_option', [ $this, 'maybe_change_server_rules_on_add' ], 10, 2 );
	}

	/**
	 * Creates or returns an instance of this class.
	 *
	 * @static
	 * @access public
	 * @since 7.4
	 */
	public static function get_instance() {

		// If an instance hasn't been created and set to $instance create an instance and set it to $instance.
		if ( null === self::$instance ) {
			self::$instance = new Avada_Server_Rules();
		}
		return self::$instance;
	}

	/**
	 * Boots the object and runs the one-time rules upgrade.
	 *
	 * Hooked on admin_init and rest_api_init from bootstrap.php. Both fire
	 * before any option save, and late enough for REST_REQUEST to be defined.
	 *
	 * @static
	 * @access public
	 * @since 7.16.2
	 * @return void
	 */
	public static function init() {
		$instance = self::get_instance();

		// Kept off ajax, so that a heartbeat cannot race a page load for the
		// one-time rewrite. Any normal admin page load will pick it up.
		if ( is_admin() && ! wp_doing_ajax() ) {
			$instance->maybe_upgrade_rules();
		}
	}

	/**
	 * Whether this request is allowed to touch the .htaccess file.
	 *
	 * Options can be written from the front-end too, and a page view is no
	 * place to be rewriting the site root .htaccess.
	 *
	 * @access private
	 * @since 7.16.2
	 * @return bool
	 */
	private function is_allowed_context() {
		if ( is_admin() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
			return true;
		}
		return defined( 'WP_CLI' ) && WP_CLI;
	}

	/**
	 * Lazily initializes and returns the WP Filesystem object.
	 *
	 * @access private
	 * @since 7.16.2
	 * @return object WP_Filesystem.
	 */
	private function get_filesystem() {
		if ( null === $this->wp_filesystem ) {
			$this->wp_filesystem = Fusion_Helper::init_filesystem();
		}
		return $this->wp_filesystem;
	}

	/**
	 * Adds / Removes server rules based on GO value.
	 *
	 * @access public
	 * @since 7.4
	 * @param string $option    Name of the updated option.
	 * @param mixed  $old_value The old option value.
	 * @param mixed  $value     The new option value.
	 * @return void
	 */
	public function maybe_change_server_rules( $option, $old_value, $value ) {

		if ( ! $this->is_allowed_context() ) {
			return;
		}

		if ( ! $this->is_our_option( $option ) || ! is_array( $value ) || ! isset( $value['gzip_status'] ) ) {
			return;
		}

		$this->rewrite_htaccess( ! $this->is_enabled_for_any_language() );
	}

	/**
	 * Whether the given option name is one of ours.
	 *
	 * Covers the language suffixed variants, so that saving the options of a
	 * secondary language takes effect too. The prefix test is only a cheap
	 * reject, because this runs on every option update; the options table also
	 * holds unrelated keys that share the prefix, such as the transients cache
	 * stored as <base>_<lang>-transients, so a match is confirmed against the
	 * actual list of option names.
	 *
	 * @access private
	 * @since 7.16.2
	 * @param string $option Name of the updated option.
	 * @return bool
	 */
	private function is_our_option( $option ) {
		$base = Avada::get_original_option_name();

		if ( $option === $base ) {
			return true;
		}

		if ( 0 !== strpos( $option, $base . '_' ) ) {
			return false;
		}

		return in_array( $option, $this->get_option_names(), true );
	}

	/**
	 * All Global Options names, including the language suffixed variants.
	 *
	 * @access private
	 * @since 7.16.2
	 * @return array
	 */
	private function get_option_names() {
		$base  = Avada::get_original_option_name();
		$names = [ $base ];

		if ( ! class_exists( 'Fusion_Multilingual' ) ) {
			return $names;
		}

		$languages = Fusion_Multilingual::get_available_languages();

		if ( ! is_array( $languages ) ) {
			return $names;
		}

		foreach ( $languages as $language ) {
			if ( '' === $language ) {
				continue;
			}
			$names[] = $base . '_' . $language;
		}

		return $names;
	}

	/**
	 * Whether compression is switched on for any language.
	 *
	 * There is one .htaccess file for the whole server, but on a multilingual
	 * site the option is stored once per language. Rather than letting the most
	 * recently saved language win, the rules are written when any language asks
	 * for them and only removed once none do.
	 *
	 * @access private
	 * @since 7.16.2
	 * @return bool
	 */
	private function is_enabled_for_any_language() {
		foreach ( $this->get_option_names() as $option_name ) {
			$options = get_option( $option_name, [] );

			if ( is_array( $options ) && $this->is_enabled( $options ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Adds server rules when the options are saved for the very first time.
	 *
	 * updated_option does not fire when the option did not exist yet, which is
	 * the case on a fresh install where the first save turns compression on.
	 *
	 * @access public
	 * @since 7.16.2
	 * @param string $option Name of the added option.
	 * @param mixed  $value  The option value.
	 * @return void
	 */
	public function maybe_change_server_rules_on_add( $option, $value ) {
		$this->maybe_change_server_rules( $option, null, $value );
	}

	/**
	 * Whether Gzip compression is switched on in the given options array.
	 *
	 * @access private
	 * @since 7.16.2
	 * @param array $options The theme options.
	 * @return bool
	 */
	private function is_enabled( $options ) {
		if ( ! isset( $options['gzip_status'] ) ) {
			return false;
		}
		return '0' !== $options['gzip_status'] && '' !== $options['gzip_status'] && false !== $options['gzip_status'];
	}

	/**
	 * Refreshes rules that were written by an earlier Avada version.
	 *
	 * Rule blocks are not rewritten on every save, so a site that switched
	 * compression on years ago still carries the block from back then. This
	 * replaces it once per revision bump.
	 *
	 * @access public
	 * @since 7.16.2
	 * @return bool Whether the file was changed.
	 */
	public function maybe_upgrade_rules() {

		if ( self::RULES_REVISION === (int) get_option( self::REVISION_OPTION, 0 ) ) {
			return false;
		}

		// Leave the stamp alone, so this is retried once the file can be written.
		if ( ! $this->is_htaccess_writable() ) {
			return false;
		}

		// Writing the site root .htaccess twice at once would corrupt it.
		if ( get_transient( 'avada_server_rules_lock' ) ) {
			return false;
		}
		set_transient( 'avada_server_rules_lock', 1, MINUTE_IN_SECONDS );

		// When the option is off for every language this clears any block left
		// behind by an earlier version rather than leaving it to rot.
		$changed = $this->rewrite_htaccess( ! $this->is_enabled_for_any_language() );

		update_option( self::REVISION_OPTION, self::RULES_REVISION, false );
		delete_transient( 'avada_server_rules_lock' );

		return $changed;
	}

	/**
	 * Checks if the server reads .htaccess files.
	 *
	 * LiteSpeed and OpenLiteSpeed are Apache compatible and honour .htaccess,
	 * so they are treated the same way here.
	 *
	 * @since 7.4
	 * @return bool
	 */
	public function is_apache() {

		// Assume Apache when can't be detected, since it is most common.
		if ( empty( $_SERVER['SERVER_SOFTWARE'] ) ) {
			return true;
		}

		$server_software = (string) $_SERVER['SERVER_SOFTWARE']; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.MissingUnslash, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized

		foreach ( [ 'Apache', 'LiteSpeed' ] as $needle ) {
			if ( false !== stristr( $server_software, $needle ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Modify .htaccess file
	 *
	 * Our own blocks are always stripped first, so adding is idempotent and an
	 * out of date revision gets replaced rather than skipped.
	 *
	 * @since 7.4
	 * @param bool $remove Whether to remove or add rules.
	 * @return bool Whether file changed or not. On failure also false is returned.
	 */
	public function rewrite_htaccess( $remove = false ) {

		if ( ! $this->is_htaccess_writable() ) {
			return false;
		}

		$htaccess_file = $this->get_htaccess_file();
		$original      = (string) $this->get_filesystem()->get_contents( $htaccess_file );
		$rules         = $this->remove_avada_rules( $original );

		// A begin marker without its end marker means the file was hand edited
		// and we cannot tell where our block stops. Adding another one would
		// duplicate the rules, so bail out rather than make it worse.
		if ( null === $rules ) {
			return false;
		}

		if ( ! $remove ) {
			$rules = trim( $rules ) . $this->normalize_eol( $this->get_gzip_htaccess() . $this->get_mod_rewrite() );
		}

		$rules = trim( $rules ) . PHP_EOL;

		if ( $rules === $original ) {
			return false;
		}

		$this->backup_htaccess( $original );

		return $this->get_filesystem()->put_contents( $htaccess_file, $rules, defined( 'FS_CHMOD_FILE' ) ? FS_CHMOD_FILE : false );
	}

	/**
	 * Strips both Avada rule blocks out of the given .htaccess contents.
	 *
	 * @access private
	 * @since 7.16.2
	 * @param string $rules The current .htaccess contents.
	 * @return string|null The contents without our blocks, or null if a block is malformed.
	 */
	private function remove_avada_rules( $rules ) {

		$blocks = [
			[ AVADA_MARKER_BEGIN_GZIP_OUTPUT, AVADA_MARKER_END_GZIP_OUTPUT ],
			[ AVADA_MARKER_BEGIN_COMPRESSION, AVADA_MARKER_END_COMPRESSION ],
		];

		foreach ( $blocks as $block ) {
			list( $begin, $end ) = $block;

			if ( false === strpos( $rules, $begin ) ) {
				continue;
			}

			if ( false === strpos( $rules, $end ) ) {
				return null;
			}

			$stripped = preg_replace( '/\R*' . preg_quote( $begin, '/' ) . '.*?' . preg_quote( $end, '/' ) . '/s', '', $rules );

			if ( null === $stripped ) {
				return null;
			}

			$rules = $stripped;
		}

		return $rules;
	}

	/**
	 * Keeps a copy of the .htaccess file before it is written to.
	 *
	 * Apache refuses to serve anything matching ^\.ht by default, so the backup
	 * is not publicly readable.
	 *
	 * @access private
	 * @since 7.16.2
	 * @param string $contents The contents to back up.
	 * @return void
	 */
	private function backup_htaccess( $contents ) {
		if ( '' === trim( $contents ) ) {
			return;
		}
		$this->get_filesystem()->put_contents( $this->get_htaccess_file() . '.avada-bak', $contents, defined( 'FS_CHMOD_FILE' ) ? FS_CHMOD_FILE : false );
	}

	/**
	 * Checks if .htaccess file is writable.
	 *
	 * @since 7.4
	 * @return bool
	 */
	public function is_htaccess_writable() {

		if ( ! $this->is_apache() ) {
			return false;
		}

		$htaccess_file = $this->get_htaccess_file();
		return $this->get_filesystem()->exists( $htaccess_file ) && $this->get_filesystem()->is_writable( $htaccess_file );
	}

	/**
	 * Get .htaccess path.
	 *
	 * @since 7.4
	 * @return string
	 */
	public function get_htaccess_file() {

		// get_home_path() lives in the admin, it is not loaded on the front-end.
		if ( ! function_exists( 'get_home_path' ) ) {
			require_once wp_normalize_path( ABSPATH . '/wp-admin/includes/file.php' );
		}

		return get_home_path() . '.htaccess';
	}

	/**
	 * Normalizes the line endings of a generated rule block.
	 *
	 * The rule blocks are literals in this file, so they carry whatever line
	 * endings the checkout has. Without this a file edited on Windows would
	 * write CRLF bodies between LF markers.
	 *
	 * @access private
	 * @since 7.16.2
	 * @param string $block The rule block.
	 * @return string
	 */
	private function normalize_eol( $block ) {
		return preg_replace( '/\R/', PHP_EOL, $block );
	}

	/**
	 * The comment that stamps the revision onto a rule block.
	 *
	 * @access private
	 * @since 7.16.2
	 * @return string
	 */
	private function get_revision_comment() {
		return '# Avada rules revision ' . self::RULES_REVISION . ' - managed by Avada, manual edits are overwritten.';
	}

	/**
	 * Get pre-compressed asset htaccess rules.
	 *
	 * Serves foo.css.br / foo.css.gz when the client accepts that encoding and
	 * the pre-compressed twin exists on disk.
	 *
	 * @since 7.4
	 * @return string
	 */
	private function get_gzip_htaccess() {
		return PHP_EOL . AVADA_MARKER_BEGIN_GZIP_OUTPUT . PHP_EOL . $this->get_revision_comment() . PHP_EOL .
		'<IfModule mod_mime.c>
    # Report the type of the inner extension (.css, .js) and describe the outer
    # one as a transfer encoding instead of a content type of its own. Scoped to
    # asset extensions so that real .tar.gz downloads are left alone.
    <FilesMatch "\.(css|js|mjs|svg|json|xml|txt|html|vtt)\.gz$">
        RemoveType .gz
        AddEncoding gzip .gz
    </FilesMatch>
    <FilesMatch "\.(css|js|mjs|svg|json|xml|txt|html|vtt)\.br$">
        RemoveType .br
        AddEncoding br .br
    </FilesMatch>
</IfModule>
<IfModule mod_rewrite.c>
    # Needed in case no other block in this file switched the engine on.
    RewriteEngine On

    # Brotli first, it is the smaller of the two when the client takes it.
    # no-gzip / no-brotli stop the output filters compressing this a second time.
    RewriteCond %{HTTP:Accept-Encoding} \bbr\b
    RewriteCond %{REQUEST_FILENAME}\.br -f
    RewriteRule ^(.*)$ $1.br [QSA,L,E=no-gzip:1,E=no-brotli:1]

    RewriteCond %{HTTP:Accept-Encoding} \bgzip\b
    RewriteCond %{REQUEST_FILENAME}\.gz -f
    RewriteRule ^(.*)$ $1.gz [QSA,L,E=no-gzip:1,E=no-brotli:1]
</IfModule>
<IfModule mod_headers.c>
    # Proxies have to key these on the encoding that was negotiated.
    <FilesMatch "\.(gz|br)$">
        Header append Vary Accept-Encoding
    </FilesMatch>
</IfModule>'
		. PHP_EOL . AVADA_MARKER_END_GZIP_OUTPUT . PHP_EOL;
	}

	/**
	 * Get compression and caching htaccess rules.
	 *
	 * @since 7.4
	 * @return string
	 */
	private function get_mod_rewrite() {

		return PHP_EOL . AVADA_MARKER_BEGIN_COMPRESSION . PHP_EOL . $this->get_revision_comment() . PHP_EOL .
		'<IfModule mod_brotli.c>
    AddOutputFilterByType BROTLI_COMPRESS text/plain text/html text/xml text/css text/javascript
    AddOutputFilterByType BROTLI_COMPRESS application/xml application/xhtml+xml application/rss+xml application/atom+xml
    AddOutputFilterByType BROTLI_COMPRESS application/javascript application/x-javascript
    AddOutputFilterByType BROTLI_COMPRESS application/json application/ld+json application/manifest+json
    AddOutputFilterByType BROTLI_COMPRESS image/svg+xml image/x-icon image/vnd.microsoft.icon
    AddOutputFilterByType BROTLI_COMPRESS font/ttf font/otf application/vnd.ms-fontobject
</IfModule>

<IfModule mod_deflate.c>
    # text/javascript is the type that current Apache builds map .js to,
    # application/javascript is what older ones still use.
    AddOutputFilterByType DEFLATE text/plain text/html text/xml text/css text/javascript
    AddOutputFilterByType DEFLATE application/xml application/xhtml+xml application/rss+xml application/atom+xml
    AddOutputFilterByType DEFLATE application/javascript application/x-javascript
    AddOutputFilterByType DEFLATE application/json application/ld+json application/manifest+json
    AddOutputFilterByType DEFLATE image/svg+xml image/x-icon image/vnd.microsoft.icon
    AddOutputFilterByType DEFLATE font/ttf font/otf application/vnd.ms-fontobject
</IfModule>

<IfModule mod_expires.c>
    ExpiresActive On

    # There is deliberately no ExpiresDefault here. It would cover text/html as
    # well, and mod_expires replaces Cache-Control, which would override the
    # no-cache headers WordPress and WooCommerce send for logged in users, carts
    # and checkout. Only the types listed below are given a lifetime.

    # Images.
    ExpiresByType image/jpeg "access plus 1 year"
    ExpiresByType image/png "access plus 1 year"
    ExpiresByType image/gif "access plus 1 year"
    ExpiresByType image/webp "access plus 1 year"
    ExpiresByType image/avif "access plus 1 year"
    ExpiresByType image/x-icon "access plus 1 year"
    ExpiresByType image/vnd.microsoft.icon "access plus 1 year"
    ExpiresByType image/svg+xml "access plus 1 month"

    # Fonts.
    ExpiresByType font/woff2 "access plus 1 year"
    ExpiresByType font/woff "access plus 1 year"
    ExpiresByType font/ttf "access plus 1 year"
    ExpiresByType font/otf "access plus 1 year"
    ExpiresByType application/vnd.ms-fontobject "access plus 1 year"

    # Styles and scripts.
    ExpiresByType text/css "access plus 1 month"
    ExpiresByType text/javascript "access plus 1 month"
    ExpiresByType application/javascript "access plus 1 month"
    ExpiresByType application/x-javascript "access plus 1 month"

    # Media.
    ExpiresByType audio/mpeg "access plus 1 month"
    ExpiresByType audio/ogg "access plus 1 month"
    ExpiresByType video/mp4 "access plus 1 month"
    ExpiresByType video/ogg "access plus 1 month"
    ExpiresByType video/webm "access plus 1 month"

    # Documents.
    ExpiresByType application/pdf "access plus 1 month"
    ExpiresByType text/plain "access plus 1 month"

    # Feeds.
    ExpiresByType application/atom+xml "access plus 1 hour"
    ExpiresByType application/rss+xml "access plus 1 hour"

    # Data that has to stay fresh.
    ExpiresByType application/xml "access plus 0 seconds"
    ExpiresByType text/xml "access plus 0 seconds"
    ExpiresByType application/json "access plus 0 seconds"
    ExpiresByType application/ld+json "access plus 0 seconds"
    ExpiresByType application/manifest+json "access plus 0 seconds"
    ExpiresByType application/x-web-app-manifest+json "access plus 0 seconds"
    ExpiresByType text/cache-manifest "access plus 0 seconds"
</IfModule>'
		. PHP_EOL . AVADA_MARKER_END_COMPRESSION . PHP_EOL;
	}

}

/* Omit closing PHP tag to avoid "Headers already sent" issues. */
