<?php
/**
 * Handles custom auth pages.
 *
 * @author     ThemeFusion
 * @copyright  (c) Copyright by ThemeFusion
 * @link       https://classic.avada.com
 * @package    Avada
 * @subpackage Core
 * @since      7.14.1
 */

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'Direct script access denied.' );
}

/**
 * Handles custom auth pages.
 */
class AWB_Custom_Auth_Pages {

	/**
	 * The one, true instance of this object.
	 *
	 * @static
	 * @since 7.14.1
	 * @access private
	 * @var object
	 */
	private static $instance;

	/**
	 * The bypass cookie name.
	 *
	 * @since 7.14.1
	 * @access protected
	 * @var string
	 */
	protected $bypass_cookie_name = 'awb_bypass_wp_login';

	/**
	 * The constructor.
	 *
	 * @since 7.14.1
	 * @access private
	 * @return void
	 */
	private function __construct() {
		add_action( 'wp_loaded', [ $this, 'do_auth_redirects' ], 20 );
		add_action( 'template_redirect', [ $this, 'hide_reset_password_key' ], 1 );
		add_action( 'wp_login', [ $this, 'clear_bypass_cookie' ] );
		add_filter( 'logout_redirect', [ $this, 'do_logout_redirect' ], 10, 3 );

		add_filter( 'retrieve_password_message', [ $this, 'ajust_reset_password_email' ], 10, 4 );
	}

	/**
	 * Performs the redirects away from the default WordPress authentication pages.
	 *
	 * @since 7.14.1
	 * @access public
	 * @return void
	 */
	public function do_auth_redirects() {

		// The feature is switched off.
		if ( ! $this->is_enabled() ) {
			return;
		}

		// Redirecting a POST discards its data, which breaks the forms that submit to wp-login.php.
		// Those are let through, while anything else, e.g. credentials posted straight to
		// wp-login.php, is handled like a page request below.
		if ( ! $this->is_get_request() && $this->is_allowed_post_request() ) {
			return;
		}

		// We don't interfere with WooCommerce authentication pages.
		if ( $this->is_woocommerce_auth_page() ) {
			return;
		}

		$bypass_param = Avada()->settings->get( 'auth_pages_bypass_param' );

		// Clear the bypass cookie, if we no longer have a bypass query arg set in GO.
		if ( empty( $bypass_param ) ) {
			$this->clear_bypass_cookie();
		}

		// If we have a bypass query arg set in GO and it is used in the current request, set the cookie and bypass.
		if ( ! empty( $bypass_param ) && isset( $_GET[ $bypass_param ] ) ) {
			$this->set_bypass_cookie( $bypass_param );
			return;
		}

		// If a valid cookie is set, bypass redirects.
		if ( ! empty( $bypass_param ) && $this->has_valid_bypass_cookie( $bypass_param ) ) {
			return;
		}

		$current_request_uri       = $_SERVER['REQUEST_URI'] ? esc_url_raw( $_SERVER['REQUEST_URI'] ) : '';
		$current_url_path          = rtrim( (string) wp_parse_url( $current_request_uri, PHP_URL_PATH ), '/' );
		$action                    = isset( $_GET['action'] ) ? sanitize_key( $_GET['action'] ) : false;
		$wp_auth_page_match        = false;

		$wp_login_url_path         = rtrim( (string) wp_parse_url( wp_login_url(), PHP_URL_PATH ), '/'  );
		$wp_registration_url_path  = rtrim( (string) wp_parse_url( wp_registration_url(), PHP_URL_PATH ), '/'  );
		$wp_lost_password_url_path = rtrim( (string) wp_parse_url( wp_lostpassword_url(), PHP_URL_PATH ), '/'  );

		// Check if we have a match.
		if ( $current_url_path === $wp_login_url_path ) {
			$wp_auth_page_match = 'wp_login';
		} else if ( $current_url_path === $wp_registration_url_path ) {
			$wp_auth_page_match = 'wp_registration';
		} else if ( $current_url_path === $wp_lost_password_url_path ) {
			$wp_auth_page_match = 'wp_lost_password';
		}

		// We need to redirect.
		if ( $wp_auth_page_match ) {
			$redirect_action = Avada()->settings->get( 'auth_pages_custom_redirect' );

			// A custom action was set.
			if ( 'auth_pages' !== $redirect_action ) {

				// Only the entry points may be redirected away. Every other action carries a key, a
				// nonce or a cookie that only wp-login.php itself is able to validate.
				if ( $this->is_auth_entry_action( $action ) ) {
					$this->do_custom_redirect( $redirect_action );
				}

				return;
			}

			// Redirect to the corresponding set auth page.
			if ( 'wp_login' === $wp_auth_page_match ) {
				$skipped_args = [];

				switch ( $action ) {
					case 'login':
					case false:
						$redirection_page = apply_filters( 'awb_auth_pages_login_redirect', Avada()->settings->get( 'auth_pages_login_page' ) );
						break;
					case 'register':
						$redirection_page = apply_filters( 'awb_auth_pages_registratio_redirect', Avada()->settings->get( 'auth_pages_registration_page' ) );
						break;
					case 'lostpassword':
					case 'retrievepassword':
						$redirection_page = apply_filters( 'awb_auth_pages_lost_password_redirect', Avada()->settings->get( 'auth_pages_lost_password_page' ) );
						break;
					case 'rp': // Reset password.
					case 'resetpass':
					case 'resetpassword':
						$redirection_page = apply_filters( 'awb_auth_pages_reset_password_redirect', Avada()->settings->get( 'auth_pages_reset_password_page' ) );

						// WordPress sets the reset password cookie while processing the action, which we
						// never reach when redirecting. Forms reading it instead of the query string
						// would show the lost password form again, sending users into a loop. With the
						// key in the cookie, it stays out of the reset page URL.
						if ( $redirection_page && 'publish' === get_post_status( $redirection_page ) ) {
							$this->set_reset_password_cookie( $redirection_page );

							$skipped_args = [ 'key', 'login' ];
						}
						break;
					default:

						// Anything else, e.g. logout, postpass or confirmaction, is left to WordPress.
						return;
				}

				$this->do_redirect( $redirection_page, true, $skipped_args );
			}
		}
	}

	/**
	 * Checks if the custom auth pages feature is active at all.
	 *
	 * @since 7.16.2
	 * @access private
	 * @return bool
	 */
	private function is_enabled() {
		return (bool) apply_filters( 'awb_custom_auth_pages_enabled', true );
	}

	/**
	 * Checks if the current request is a plain page request.
	 *
	 * @since 7.16.2
	 * @access private
	 * @return bool
	 */
	private function is_get_request() {
		$request_method = isset( $_SERVER['REQUEST_METHOD'] ) ? strtoupper( sanitize_text_field( wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) ) : 'GET';

		return in_array( $request_method, [ 'GET', 'HEAD' ], true );
	}

	/**
	 * Checks if a form submission to the WordPress authentication pages has to reach WordPress.
	 *
	 * That is the case for the steps within an authentication flow, for the Avada User Login,
	 * Register and Lost Password elements, and for forms on the site's own pages, e.g. those of
	 * third party form plugins. A submission from wp-login.php itself can only come from someone
	 * who was never redirected away from it, which the bypass cookie covers.
	 *
	 * @since 7.16.2
	 * @access private
	 * @return bool
	 */
	private function is_allowed_post_request() {
		$action = isset( $_GET['action'] ) ? sanitize_key( $_GET['action'] ) : false; // phpcs:ignore WordPress.Security.NonceVerification

		// Steps like resetpass or postpass carry a key, a nonce or a cookie that wp-login.php validates.
		$allowed = ! $this->is_auth_entry_action( $action );

		// The Avada elements. Their nonce is loaded via AJAX, so it also works on cached pages.
		if ( ! $allowed && isset( $_POST['fusion_login_box'] ) && isset( $_POST['_wpnonce'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			$allowed = (bool) wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ), 'fusion-login' );
		}

		if ( ! $allowed ) {
			$allowed = $this->is_submitted_from_site_page();
		}

		/**
		 * Filters whether a form submission to the WordPress authentication pages is let through.
		 *
		 * @since 7.16.2
		 * @param bool        $allowed Whether the submission is let through.
		 * @param string|bool $action  The auth action of the request.
		 */
		return (bool) apply_filters( 'awb_custom_auth_pages_allow_post', $allowed, $action );
	}

	/**
	 * Checks if the request was submitted from a page of this site, other than wp-login.php.
	 *
	 * @since 7.16.2
	 * @access private
	 * @return bool
	 */
	private function is_submitted_from_site_page() {
		$referer = isset( $_SERVER['HTTP_REFERER'] ) ? esc_url_raw( wp_unslash( $_SERVER['HTTP_REFERER'] ) ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput

		if ( '' === $referer || ! wp_validate_redirect( $referer, false ) ) {
			return false;
		}

		$referer_path  = rtrim( (string) wp_parse_url( $referer, PHP_URL_PATH ), '/' );
		$wp_login_path = rtrim( (string) wp_parse_url( wp_login_url(), PHP_URL_PATH ), '/' );

		return $referer_path !== $wp_login_path;
	}

	/**
	 * Checks if the given action is an authentication entry point.
	 *
	 * Only entry points may be redirected away from wp-login.php wholesale. The remaining
	 * actions are steps within an authentication flow and must reach WordPress.
	 *
	 * @since 7.16.2
	 * @access private
	 * @param string|bool $action The current auth action.
	 * @return bool
	 */
	private function is_auth_entry_action( $action ) {
		return ! $action || in_array( $action, [ 'login', 'register', 'lostpassword', 'retrievepassword' ], true );
	}

	/**
	 * Sets the reset password cookie WordPress would normally set in wp-login.php.
	 *
	 * WordPress scopes it to wp-login.php; here it is scoped to the custom reset password
	 * page instead, the only place that needs to read it.
	 *
	 * @since 7.16.2
	 * @access private
	 * @param int $page_id The reset password page ID.
	 * @return void
	 */
	private function set_reset_password_cookie( $page_id ) {
		if ( ! isset( $_GET['key'] ) || ! isset( $_GET['login'] ) ) {
			return;
		}

		setcookie(
			$this->get_reset_password_cookie_name(),
			sprintf( '%s:%s', wp_unslash( $_GET['login'] ), wp_unslash( $_GET['key'] ) ),
			[
				'expires'  => 0,
				'path'     => $this->get_reset_password_cookie_path( $page_id ),
				'domain'   => COOKIE_DOMAIN,
				'secure'   => is_ssl(),
				'httponly' => true,
				'samesite' => 'Lax',
			]
		);
	}

	/**
	 * Clears the reset password cookie, once the password was reset.
	 *
	 * @since 7.16.2
	 * @access public
	 * @return void
	 */
	public function clear_reset_password_cookie() {
		$page_id = $this->get_reset_password_page_id();

		if ( $page_id && ! headers_sent() ) {
			setcookie( $this->get_reset_password_cookie_name(), ' ', time() - YEAR_IN_SECONDS, $this->get_reset_password_cookie_path( $page_id ), COOKIE_DOMAIN, is_ssl(), true );
		}
	}

	/**
	 * Moves the reset key and login out of the reset password page URL into the reset
	 * password cookie, like wp-login.php does. In the URL, the key would reach analytics,
	 * server logs and the Referer header of every third party resource on the page.
	 *
	 * @since 7.16.2
	 * @access public
	 * @return void
	 */
	public function hide_reset_password_key() {
		$page_id = $this->is_enabled() ? $this->get_reset_password_page_id() : 0;

		if ( ! $page_id || (int) get_queried_object_id() !== $page_id ) {
			return;
		}

		if ( isset( $_GET['key'] ) && isset( $_GET['login'] ) ) {
			$this->set_reset_password_cookie( $page_id );

			wp_safe_redirect( remove_query_arg( [ 'key', 'login' ] ) );
			exit;
		}

		// The reset form prints the key from the cookie, so the page must not be cached.
		if ( isset( $_COOKIE[ $this->get_reset_password_cookie_name() ] ) ) {
			nocache_headers();

			if ( ! defined( 'DONOTCACHEPAGE' ) ) {
				define( 'DONOTCACHEPAGE', true );
			}
		}
	}

	/**
	 * Gets the reset key and login for a reset password form, from the query string if a
	 * link carries them, or else from the reset password cookie. Both are checked by
	 * check_password_reset_key() on submit, and must be escaped for output.
	 *
	 * @since 7.16.2
	 * @access public
	 * @return array { key, login }
	 */
	public function get_reset_password_credentials() {
		if ( isset( $_GET['key'] ) && isset( $_GET['login'] ) ) {
			return [
				'key'   => wp_unslash( $_GET['key'] ),
				'login' => wp_unslash( $_GET['login'] ),
			];
		}

		$cookie_name = $this->get_reset_password_cookie_name();
		if ( ! empty( $_COOKIE[ $cookie_name ] ) && false !== strpos( $_COOKIE[ $cookie_name ], ':' ) ) {
			list( $login, $key ) = explode( ':', wp_unslash( $_COOKIE[ $cookie_name ] ), 2 );

			return [
				'key'   => $key,
				'login' => $login,
			];
		}

		return [
			'key'   => '',
			'login' => '',
		];
	}

	/**
	 * Gets the published custom reset password page ID.
	 *
	 * @since 7.16.2
	 * @access private
	 * @return int The page ID, 0 if none is set.
	 */
	private function get_reset_password_page_id() {
		$page_id = apply_filters( 'awb_auth_pages_reset_password_redirect', Avada()->settings->get( 'auth_pages_reset_password_page' ) );

		return $page_id && 'publish' === get_post_status( $page_id ) ? (int) $page_id : 0;
	}

	/**
	 * Gets the reset password cookie name, the one WordPress uses.
	 *
	 * @since 7.16.2
	 * @access private
	 * @return string
	 */
	private function get_reset_password_cookie_name() {
		return 'wp-resetpass-' . COOKIEHASH;
	}

	/**
	 * Gets the path the reset password cookie is scoped to, that of the reset password page.
	 *
	 * @since 7.16.2
	 * @access private
	 * @param int $page_id The reset password page ID.
	 * @return string
	 */
	private function get_reset_password_cookie_path( $page_id ) {
		$path = wp_parse_url( get_permalink( $page_id ), PHP_URL_PATH );

		return $path ? $path : COOKIEPATH;
	}

	/**
	 * Checks if the page request matches a WooCommerce authentication page.
	 *
	 * @since 7.14.1
	 * @access private
	 * @return bool
	 */
	private function is_woocommerce_auth_page() {
		if ( class_exists( 'WooCommerce' ) ) {
			$current_request_uri = $_SERVER['REQUEST_URI'] ? esc_url_raw( $_SERVER['REQUEST_URI'] ) : '';
			$current_url_path    = rtrim( (string) wp_parse_url( $current_request_uri, PHP_URL_PATH ), '/' );
			$woo_endpoints       = [
				wc_get_account_endpoint_url( 'lost-password' ),
				add_query_arg( [ 'show-reset-form' => 'true' ], wc_get_account_endpoint_url( 'lost-password' ) ),
				wc_get_account_endpoint_url( 'customer-logout' )
			];

			foreach ( $woo_endpoints as $woo_endpoint ) {
				$woo_endpoint_path = rtrim( (string) wp_parse_url( $woo_endpoint, PHP_URL_PATH ), '/' );
				if ( $woo_endpoint_path && 0 === strpos( $current_url_path, $woo_endpoint_path ) ) {
					return true;
				}
			}
		}

		return false;
	}	

	/**
	 * Sets the bypass cookie.
	 *
	 * @since 7.14.1
	 * @access private
	 * @param string $bypass_param The bypass query arg set in GO.
	 * @return void
	 */
	private function set_bypass_cookie( $bypass_param ) {
		setcookie(
			$this->bypass_cookie_name,
			$this->get_bypass_cookie_value( $bypass_param ),
			$this->get_bypass_cookie_args( time() + 5 * 60 ) // Valid for 5mins.
		);
	}

	/**
	 * Returns the bypass cookie value.
	 * It is derived from the bypass query arg, so the cookie can't be forged without knowing it.
	 *
	 * @since 7.16.2
	 * @access private
	 * @param string $bypass_param The bypass query arg set in GO.
	 * @return string
	 */
	private function get_bypass_cookie_value( $bypass_param ) {
		return wp_hash( 'awb_bypass_wp_login_' . $bypass_param );
	}

	/**
	 * Checks if the bypass cookie is set and valid.
	 *
	 * @since 7.16.2
	 * @access private
	 * @param string $bypass_param The bypass query arg set in GO.
	 * @return bool
	 */
	private function has_valid_bypass_cookie( $bypass_param ) {
		if ( ! isset( $_COOKIE[ $this->bypass_cookie_name ] ) || ! is_string( $_COOKIE[ $this->bypass_cookie_name ] ) ) {
			return false;
		}

		return hash_equals( $this->get_bypass_cookie_value( $bypass_param ), wp_unslash( $_COOKIE[ $this->bypass_cookie_name ] ) );
	}

	/**
	 * Clears the bypass cookie.
	 *
	 * @since 7.14.1
	 * @access public
	 * @return void
	 */
	public function clear_bypass_cookie() {
		if ( isset( $_COOKIE ) && isset( $_COOKIE[ $this->bypass_cookie_name ] ) ) {
			setcookie(
				$this->bypass_cookie_name,
				'',
				$this->get_bypass_cookie_args( time() - 3600 )
			);

			unset( $_COOKIE[ $this->bypass_cookie_name ] );
		}
	}

	/**
	 * Returns the cookie args.
	 *
	 * @since 7.14.1
	 * @access private
	 * @param int $expires The expiry timestamp.
	 * @return array The cookie args.
	 */
	private function get_bypass_cookie_args( $expires ) {
		return [
			'expires'  => $expires,
			'path'     => COOKIEPATH,
			'domain'   => COOKIE_DOMAIN,
			'secure'   => is_ssl(),
			'httponly' => true,
			'samesite' => 'Strict',
		];
	}

	/**
	 * Performs the redirects to the customarily chosen endpoints.
	 *
	 * @since 7.14.1
	 * @access private
	 * @param string $redirect_action The desired redirection action.
	 * @return void
	 */
	private function do_custom_redirect( $redirect_action ) {
		switch ( $redirect_action ) {
			case 'homepage':
				wp_safe_redirect( home_url() );
				exit;
			case '404':

				// Need a full redirect here because of the layout builder.
				wp_safe_redirect( home_url( '/error-404' ) );
				exit;
			case 'custom_page':
				$custom_redirect_page = Avada()->settings->get( 'auth_pages_custom_redirect_page' );

				if ( ! $this->do_redirect( $custom_redirect_page ) ) {
					wp_safe_redirect( home_url() );
					exit;
				}
		}
	}	

	/**
	 * Performs the actual redirects.
	 *
	 * @since 7.14.1
	 * @access private
	 * @param string|int $page_id The ID of the page to redirct to.
	 * @param bool $add_query_string A flag deciding if the query string should be appended.
	 * @param array $skipped_args Query args that must not be appended.
	 * @return void|bool Only returns false, if a redirect can't be performed.
	 */
	private function do_redirect( $page_id, $add_query_string = true, $skipped_args = [] ) {
		if ( $page_id && 'publish' === get_post_status( $page_id ) ) {
			$redirect_url = get_permalink( $page_id );
			$query_string = array_diff_key( $_GET, array_flip( $skipped_args ) );

			if ( $redirect_url ) {
				if ( $add_query_string && is_array( $query_string ) ) {
					foreach ( $query_string as $key => $value ) {
						$redirect_url = add_query_arg( $key, rawurlencode( sanitize_text_field( $value ) ), $redirect_url );
					}
				}

				wp_safe_redirect( $redirect_url );
				exit;
			}
		}

		return false;
	}

	/**
	 * Performs redirect after successful logout to custom login page.
	 *
	 * @since 7.14.1
	 * @access public
	 * @param string  $redirect_to           The redirect destination URL.
	 * @param string  $requested_redirect_to The requested redirect destination URL passed as a parameter.
	 * @param WP_User $user                  The WP_User object for the user that's logging out.
	 * @return string
	 */
	public function do_logout_redirect( $redirect_to, $requested_redirect_to, $user ) {

		// The feature is switched off.
		if ( ! $this->is_enabled() ) {
			return $redirect_to;
		}

		// By default WordPress tries to rediret to the login URL, which means we must cover that.
		$wp_login_url = wp_login_url();
		if ( 0 === strpos( $redirect_to, $wp_login_url ) ) {
			$redirection_page = apply_filters( 'awb_auth_pages_login_redirect', Avada()->settings->get( 'auth_pages_login_page' ) );

			if ( $redirection_page && 'publish' === get_post_status( $redirection_page ) ) {
				$redirect_to = get_permalink( $redirection_page ) . '?logged_out=true';
			}
		}

		return $redirect_to;
	}

	/**
	 * Make sure that also the reset password email uses rge custom reset password page URL.
	 *
	 * @since 7.14.1
	 * @access public
	 * @param string  $message    Email message.
	 * @param string  $key        The activation key.
	 * @param string  $user_login The username for the user.
	 * @param WP_User $user_data  WP_User object.
	 * @return string The modified email message.
	 */
	public function ajust_reset_password_email( $message, $key, $user_login, $user_data ) {

		// The feature is switched off.
		if ( ! $this->is_enabled() ) {
			return $message;
		}

		$redirection_page = apply_filters( 'awb_auth_pages_reset_password_redirect', Avada()->settings->get( 'auth_pages_reset_password_page' ) );

		if ( $redirection_page && 'publish' === get_post_status( $redirection_page ) ) {
			$redirect_url = get_permalink( $redirection_page );
			$network_url  = network_site_url( 'wp-login.php' );

			$message      = str_replace( $network_url, $redirect_url, $message );
		}

		return $message;
	}	

	/**
	 * Creates or returns an instance of this class.
	 *
	 * @static
	 * @since 7.14.1
	 * @access public
	 * @return object AWB_Custom_Auth_Pages
	 */
	public static function get_instance() {

		// If an instance hasn't been created and set to $instance create an instance and set it to $instance.
		if ( null === self::$instance ) {
			self::$instance = new AWB_Custom_Auth_Pages();
		}
		return self::$instance;
	}
}

/**
 * Instantiates the AWB_Custom_Auth_Pages class.
 * Make sure the class is properly set-up.
 *
 * @since 7.14.1
 * @return object AWB_Custom_Auth_Pages
 */
function AWB_Custom_Auth_Pages() { // phpcs:ignore WordPress.NamingConventions
	return AWB_Custom_Auth_Pages::get_instance();
}
AWB_Custom_Auth_Pages();
