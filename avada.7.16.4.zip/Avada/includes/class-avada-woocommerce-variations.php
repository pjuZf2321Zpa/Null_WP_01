<?php
/**
 * Modifications for WooCommerce variations.
 *
 * @author     ThemeFusion
 * @link       https://classic.avada.com
 * @package    Avada
 * @subpackage Core
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	die;
}

/**
 * Class to apply woocommerce variations.
 *
 * @since 7.2
 */
class Avada_Woocommerce_Variations {

	/**
	 * The one, true instance of this object.
	 *
	 * @static
	 * @access private
	 * @since 7.2
	 * @var object
	 */
	private static $instance;

	/**
	 * Array of taxonomies.
	 *
	 * @access private
	 * @since 7.2
	 * @var object
	 */
	public $taxonomies = null;

	/**
	 * Option name the per-attribute icons are stored under.
	 *
	 * WooCommerce attributes are rows in the wc_attribute_taxonomies table and have
	 * no meta of their own, so the icons live in a single option keyed by attribute ID.
	 *
	 * @access public
	 * @since 7.16.1
	 * @var string
	 */
	public $icons_option = 'awb_product_attribute_icons';

	/**
	 * Class constructor.
	 *
	 * @since 7.2
	 * @access private
	 */
	private function __construct() {
		add_action( 'init', [ $this, 'init' ] );
		add_action( 'admin_init', [ $this, 'admin_init' ] );
	}

	/**
	 * Creates or returns an instance of this class.
	 *
	 * @static
	 * @access public
	 * @since 7.2
	 */
	public static function get_instance() {

		// If an instance hasn't been created and set to $instance create an instance and set it to $instance.
		if ( null === self::$instance ) {
			self::$instance = new Avada_Woocommerce_Variations();
		}
		return self::$instance;
	}

	/**
	 * Init.
	 *
	 * @static
	 * @access public
	 * @since 7.2
	 */
	public function init() {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return;
		}

		// The attribute icon is not a swatch feature - elements can use it whether or not
		// the swatch types are enabled, so it is registered independently of that setting.
		add_action( 'woocommerce_after_add_attribute_fields', [ $this, 'attribute_icon_field_add' ] );
		add_action( 'woocommerce_after_edit_attribute_fields', [ $this, 'attribute_icon_field_edit' ] );
		add_action( 'woocommerce_attribute_added', [ $this, 'save_attribute_icon' ], 10, 2 );
		add_action( 'woocommerce_attribute_updated', [ $this, 'save_attribute_icon' ], 10, 2 );
		add_action( 'woocommerce_attribute_deleted', [ $this, 'delete_attribute_icon' ] );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_attribute_icon_assets' ] );

		if ( '0' !== Avada()->settings->get( 'woocommerce_variations' ) ) {
			add_filter( 'product_attributes_type_selector', [ $this, 'add_attribute_types' ] );
			add_filter( 'fusion_tax_meta_allowed_screens', [ $this, 'add_taxonomy_options' ] );
			add_filter( 'before_avada_taxonomy_map', [ $this, 'term_options' ] );
			add_filter( 'woocommerce_dropdown_variation_attribute_options_html', [ $this, 'variation_markup' ], 10, 2 );
			add_action( 'wp', [ $this, 'enqueue_assets' ] );
			add_action( 'woocommerce_product_option_terms', [ $this, 'option_terms' ], 20, 3 );
			add_filter( 'woocommerce_layered_nav_term_html', [ $this, 'layered_nav_list_links' ], 10, 4 );
		}
	}

	/**
	 * Function that gets called at 'admin_init' action.
	 *
	 * @static
	 * @access public
	 * @since 7.5
	 */
	public function admin_init() {
		$attribute_taxonomies = wc_get_attribute_taxonomies();
		if ( $attribute_taxonomies ) {
			foreach ( $attribute_taxonomies as $tax ) {
				$product_attr = wc_attribute_taxonomy_name( $tax->attribute_name );
				add_filter( 'manage_edit-' . $product_attr . '_columns', [ $this, 'add_custom_attribute_type_preview' ] );
				add_filter( 'manage_' . $product_attr . '_custom_column', [ $this, 'create_preview_column_for_custom_attribute_type' ], 10, 3 );
			}
		}
	}

	/**
	 * Allow selection of terms on product page.
	 *
	 * @access public
	 * @since 7.2
	 * @param object $attribute_taxonomy Taxonomy object.
	 * @param int    $i                  Number.
	 * @param object $attribute          Attributes object.
	 * @return void
	 */
	public function option_terms( $attribute_taxonomy, $i, $attribute = '' ) {
		if ( false !== strpos( $attribute_taxonomy->attribute_type, 'avada_' ) ) {
			?>
			<select multiple="multiple" data-placeholder="<?php esc_attr_e( 'Select terms', 'woocommerce' ); ?>" class="multiselect attribute_values wc-enhanced-select" name="attribute_values[<?php echo esc_attr( $i ); ?>][]">
			<?php
			$args      = [
				'orderby'    => ! empty( $attribute_taxonomy->attribute_orderby ) ? $attribute_taxonomy->attribute_orderby : 'name',
				'hide_empty' => 0,
			];
			$all_terms = get_terms( $attribute->get_taxonomy(), apply_filters( 'woocommerce_product_attribute_terms', $args ) );
			if ( $all_terms ) {
				foreach ( $all_terms as $term ) {
					$options = $attribute->get_options();
					$options = ! empty( $options ) ? $options : [];
					echo '<option value="' . esc_attr( $term->term_id ) . '"' . wc_selected( $term->term_id, $options ) . '>' . esc_html( apply_filters( 'woocommerce_product_attribute_term_name', $term->name, $term ) ) . '</option>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				}
			}
			?>
		</select>
		<button class="button plus select_all_attributes"><?php esc_html_e( 'Select all', 'woocommerce' ); ?></button>
		<button class="button minus select_no_attributes"><?php esc_html_e( 'Select none', 'woocommerce' ); ?></button>
			<?php
		}
	}

	/**
	 * Enqueue variation assets.
	 *
	 * @access public
	 * @since 7.2
	 */
	public function enqueue_assets() {
		$version          = Avada::get_theme_version();
		$js_folder_suffix = AVADA_DEV_MODE ? '/assets/js' : '/assets/min/js';
		$js_folder_url    = Avada::$template_dir_url . $js_folder_suffix;
		$js_folder_path   = Avada::$template_dir_path . $js_folder_suffix;

		Fusion_Dynamic_CSS::enqueue_style( Avada::$template_dir_path . '/assets/css/dynamic/woocommerce/woo-variations.min.css', Avada::$template_dir_url . '/assets/css/dynamic/woocommerce/woo-variations.min.css' );
		Fusion_Dynamic_JS::enqueue_script(
			'avada-woo-product-variations',
			$js_folder_url . '/general/avada-woo-variations.js',
			$js_folder_path . '/general/avada-woo-variations.js',
			[ 'jquery' ],
			$version,
			true
		);
	}

	/**
	 * Works out attrybute type.
	 *
	 * @access public
	 * @param string $attribute Attribute name.
	 * @return mixed Attribute type or false if not custom.
	 * @since 7.2
	 */
	public function custom_attribute_type( $attribute = '' ) {
		if ( null === $this->taxonomies ) {
			$this->set_taxonomies();
		}

		$attribute = str_replace( 'pa_', '', $attribute );

		foreach ( (array) $this->taxonomies as $taxonomy ) {
			if ( str_replace( 'pa_', '', $taxonomy->attribute_name ) === $attribute ) {
				return $taxonomy->attribute_type;
			}
		}

		return false;
	}

	/**
	 * Output different markup for attibute type.
	 *
	 * @access public
	 * @param string $html HTML markup.
	 * @param array  $args Variation arguments.
	 * @since 7.2
	 */
	public function variation_markup( $html = '', $args = [] ) {

		// Get attribute type if it is custom.
		$custom_attribute_type = apply_filters( 'avada_custom_variation', $this->custom_attribute_type( $args['attribute'] ) );

		// Not custom, no need to change the markup.
		if ( ! $custom_attribute_type ) {
			return $html;
		}

		// Get selected value.
		if ( false === $args['selected'] && $args['attribute'] && $args['product'] instanceof WC_Product ) {
			$selected_key = 'attribute_' . sanitize_title( $args['attribute'] );
			// phpcs:disable WordPress.Security.NonceVerification.Recommended
			$args['selected'] = isset( $_REQUEST[ $selected_key ] ) ? wc_clean( wp_unslash( $_REQUEST[ $selected_key ] ) ) : $args['product']->get_variation_default_attribute( $args['attribute'] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			// phpcs:enable WordPress.Security.NonceVerification.Recommended
		}

		$options               = $args['options'];
		$product               = $args['product'];
		$attribute             = $args['attribute'];
		$name                  = $args['name'] ? $args['name'] : 'attribute_' . sanitize_title( $attribute );
		$id                    = $args['id'] ? $args['id'] : sanitize_title( $attribute );
		$class                 = $args['class'];
		$show_option_none      = (bool) $args['show_option_none'];
		$show_option_none_text = $args['show_option_none'] ? $args['show_option_none'] : __( 'Choose an option', 'woocommerce' ); // We'll do our best to hide the placeholder, but we'll need to show something when resetting options.

		if ( empty( $options ) && ! empty( $product ) && ! empty( $attribute ) ) {
			$attributes = $product->get_variation_attributes();
			$options    = $attributes[ $attribute ];
		}

		$custom_attribute_type = str_replace( 'avada_', '', $custom_attribute_type );
		$html                  = '<div class="avada-select-wrapper" data-type="' . esc_attr( $custom_attribute_type ) . '">' . $html;
		if ( ! empty( $options ) ) {
			if ( $product && taxonomy_exists( $attribute ) ) {
				// Get terms if this is a taxonomy - ordered. We need the names too.
				$terms = wc_get_product_terms(
					$product->get_id(),
					$attribute,
					[
						'fields' => 'all',
					]
				);

				foreach ( $terms as $term ) {
					if ( in_array( $term->slug, $options, true ) ) {

						$args = [
							'id'       => $term->term_id,
							'value'    => $term->slug,
							'name'     => $name,
							'selected' => $args['selected'],
							'title'    => apply_filters( 'woocommerce_variation_option_name', $term->name, $term, $attribute, $product ),
						];

						$html .= $this->variation_swatch( $custom_attribute_type, $args );
					}
				}
			} else {
				foreach ( $options as $option ) {
					$args = [
						'id'       => 0,
						'value'    => $option,
						'name'     => $name,
						'selected' => $args['selected'],
						'title'    => apply_filters( 'woocommerce_variation_option_name', $option, null, $attribute, $product ),
					];

					$html .= $this->variation_swatch( $custom_attribute_type, $args );
				}
			}
		}

		$html .= '</div>';

		return $html;
	}

	/**
	 * Picks the variation markup for an attribute type.
	 *
	 * @access private
	 * @since 7.16.1
	 * @param string $type The attribute type, without the avada_ prefix.
	 * @param array  $args The option arguments.
	 * @return string
	 */
	private function variation_swatch( $type, $args ) {
		if ( 'color' === $type ) {
			return $this->color_select( $args );
		}

		if ( 'image' === $type ) {
			return $this->image_select( $args );
		}

		return $this->button_select( $args );
	}

	/**
	 * Markup for a color variation.
	 *
	 * @access public
	 * @param array $args Color field arguments.
	 * @since 7.2
	 */
	public function color_select( $args = [] ) {
		$color   = $args['id'] ? $this->get_term_color( $args['id'] ) : '#ddd';
		$id      = esc_attr( $args['name'] . '_' . $args['value'] );
		$checked = sanitize_title( $args['value'] ) === sanitize_title( $args['selected'] ) ? ' data-checked="true" ' : '';

		$html = '<a href="#" class="avada-color-select" role="button" tabindex="0" aria-label="' . esc_html( $args['title'] ) . '" title="' . esc_html( $args['title'] ) . '" data-value="' . esc_attr( $args['value'] ) . '"' . $checked . '><span style="background-color: ' . esc_attr( $color ) . '"></span></a>';
		return $html;
	}

	/**
	 * Markup for a image variation.
	 *
	 * @access public
	 * @param array $args Image field arguments.
	 * @since 7.2
	 */
	public function image_select( $args = [] ) {
		$id           = esc_attr( $args['name'] . '_' . $args['value'] );
		$checked      = sanitize_title( $args['value'] ) === sanitize_title( $args['selected'] ) ? ' data-checked="true" ' : '';
		$image_output = $args['id'] ? $this->get_term_image_html( $args['id'] ) : '';

		$html = '<a href="#" class="avada-image-select" tabindex="0" aria-label="' . esc_html( $args['title'] ) . '" title="' . esc_html( $args['title'] ) . '" data-value="' . esc_attr( $args['value'] ) . '"' . $checked . '>' . $image_output . '</a>';

		return $html;
	}

	/**
	 * Markup for a button variation.
	 *
	 * @access public
	 * @param array $args Image field arguments.
	 * @since 7.2
	 */
	public function button_select( $args = [] ) {
		$id      = esc_attr( $args['name'] . '_' . $args['value'] );
		$checked = sanitize_title( $args['value'] ) === sanitize_title( $args['selected'] ) ? ' data-checked="true" ' : '';

		$html = '<a href="#" class="avada-button-select" tabindex="0" data-value="' . esc_attr( $args['value'] ) . '"' . $checked . '>' . esc_html( $args['title'] ) . '</a>';

		return $html;
	}

	/**
	 * Swatches for a product attribute, to show what the terms look like outside of the
	 * variation form, ex: in the Woo Additional Information element.
	 *
	 * These do not reuse the markup above on purpose: those are links that the variation
	 * script binds to site wide, while these only have to be looked at.
	 *
	 * @access public
	 * @since 7.16.1
	 * @param WC_Product_Attribute $attribute The product attribute.
	 * @param WC_Product           $product   The product it belongs to, for term order.
	 * @return string The swatches, or an empty string if the attribute has no Avada type.
	 */
	public function attribute_swatches( $attribute, $product = null ) {
		if ( ! is_object( $attribute ) || ! method_exists( $attribute, 'is_taxonomy' ) || ! $attribute->is_taxonomy() ) {
			return '';
		}

		// With the Avada attribute types switched off, the styling for these is not loaded
		// either, so callers are better off with the plain text they already have.
		if ( '0' === Avada()->settings->get( 'woocommerce_variations' ) ) {
			return '';
		}

		$type = $this->custom_attribute_type( $attribute->get_name() );

		// Attributes on one of WooCommerce's own types have nothing to show.
		if ( ! $type ) {
			return '';
		}

		// The same call WooCommerce makes for the text values, so that the swatches come
		// out in the order the shop is set to sort attribute terms in.
		$terms = $product instanceof WC_Product
			? wc_get_product_terms( $product->get_id(), $attribute->get_name(), [ 'fields' => 'all' ] )
			: $attribute->get_terms();

		if ( empty( $terms ) ) {
			return '';
		}

		$type = str_replace( 'avada_', '', $type );
		$html = '';

		foreach ( (array) $terms as $term ) {
			$html .= $this->term_swatch_markup( $term, $type );
		}

		return '<span class="awb-attribute-swatches" data-type="' . esc_attr( $type ) . '">' . $html . '</span>';
	}

	/**
	 * Markup for a single swatch of the set above.
	 *
	 * A term whose colour or image was never set falls back to the button swatch, so that
	 * it stays readable instead of becoming an empty box.
	 *
	 * @access public
	 * @since 7.16.1
	 * @param WP_Term $term The attribute term.
	 * @param string  $type The attribute type, without the avada_ prefix.
	 * @return string
	 */
	public function term_swatch_markup( $term, $type ) {
		if ( ! is_object( $term ) || ! isset( $term->term_id ) ) {
			return '';
		}

		$name = esc_attr( $term->name );

		if ( 'color' === $type ) {
			$color = $this->get_term_color( $term->term_id );

			if ( '' !== $color ) {
				// Named for screen readers as well as on hover, as the colour alone does
				// not say which term it is.
				return '<span class="awb-attribute-swatch awb-attribute-swatch-color" title="' . $name . '" role="img" aria-label="' . $name . '"><span style="background-color:' . esc_attr( $color ) . '"></span></span>';
			}
		}

		if ( 'image' === $type ) {
			$img = $this->get_term_image_html( $term->term_id, [ 'alt' => $name ] );

			if ( '' !== $img ) {
				return '<span class="awb-attribute-swatch awb-attribute-swatch-image" title="' . $name . '">' . $img . '</span>';
			}
		}

		return '<span class="awb-attribute-swatch awb-attribute-swatch-button">' . esc_html( $term->name ) . '</span>';
	}

	/**
	 * An attribute label with its icon, for the label display modes the elements offer.
	 *
	 * @access public
	 * @since 7.16.1
	 * @param string     $label       The attribute label.
	 * @param string|int $attribute   The attribute name, in either form, or its ID.
	 * @param string     $mode        icon for the icon on its own, both for icon and label.
	 * @param string     $placeholder Markup for attributes with no icon, so that labels can
	 *                                still be kept in line with the ones that have one.
	 * @return string The label to show, unchanged when there is no icon to add.
	 */
	public function attribute_label_markup( $label, $attribute, $mode, $placeholder = '' ) {
		$icon = $this->attribute_icon_markup( $attribute );

		return $this->attribute_heading_markup( '' === $icon ? $placeholder : $icon, $label, $mode );
	}

	/**
	 * Combines an icon and a label, according to the display mode.
	 *
	 * Takes the icon as markup rather than looking it up, because not every row an element
	 * shows is an attribute: the weight and dimensions of the Woo Additional Information
	 * element take their icons from the Global Options instead.
	 *
	 * @access public
	 * @since 7.16.1
	 * @param string $icon  The icon markup, empty when there is none.
	 * @param string $label The label.
	 * @param string $mode  icon for the icon on its own, both for icon and label.
	 * @return string The label to show, unchanged when there is no icon.
	 */
	public function attribute_heading_markup( $icon, $label, $mode ) {
		if ( ( 'icon' !== $mode && 'both' !== $mode ) || '' === $icon ) {
			return $label;
		}

		$label = esc_html( $label );

		// The label is still the row's accessible name when only the icon shows.
		$label = 'icon' === $mode
			? '<span class="screen-reader-text">' . $label . '</span>'
			: '<span class="awb-attribute-label">' . $label . '</span>';

		return '<span class="awb-attribute-heading">' . $icon . $label . '</span>';
	}

	/**
	 * The colour stored on an attribute term.
	 *
	 * @access public
	 * @since 7.16.1
	 * @param int $term_id The term ID.
	 * @return string Empty if the term has no colour set.
	 */
	public function get_term_color( $term_id ) {
		if ( ! $term_id ) {
			return '';
		}

		$color = fusion_data()->term_meta( $term_id )->get( 'attribute_color' );

		return is_string( $color ) ? $color : '';
	}

	/**
	 * The image stored on an attribute term, as markup.
	 *
	 * @access public
	 * @since 7.16.1
	 * @param int   $term_id The term ID.
	 * @param array $attr    Attributes for the img tag.
	 * @return string Empty if the term has no image, or if it no longer exists.
	 */
	public function get_term_image_html( $term_id, $attr = [] ) {
		if ( ! $term_id ) {
			return '';
		}

		$image = fusion_data()->term_meta( $term_id )->get( 'attribute_image' );
		$id    = isset( $image['id'] ) ? $image['id'] : '';
		$url   = isset( $image['url'] ) ? $image['url'] : '';

		if ( ! $id && ! $url ) {
			return '';
		}

		$data = fusion_library()->images->get_attachment_data_by_helper( $id, $url );
		$size = isset( $image['size'] ) && $image['size'] ? $image['size'] : 'full';

		return (string) wp_get_attachment_image( $data['id'], $size, false, $attr );
	}

	/**
	 * Adds term option for the attributes.
	 *
	 * @access public
	 * @param array $sections Sections to add options to.
	 * @since 7.2
	 */
	public function term_options( $sections = [] ) {
		$taxonomy = false;
		// phpcs:disable WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing
		if ( isset( $_GET['taxonomy'] ) ) {
			$taxonomy = wp_unslash( $_GET['taxonomy'] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		}

		if ( isset( $_POST ) && ! empty( $_POST ) && isset( $_POST['taxonomy'] ) ) {
			$taxonomy = wp_unslash( $_POST['taxonomy'] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		}
		// phpcs:enable WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing

		if ( ! $taxonomy ) {
			return $sections;
		}

		$taxonomy = sanitize_text_field( wp_unslash( $taxonomy ) );
		$type     = $this->custom_attribute_type( $taxonomy );

		if ( ! $type ) {
			return $sections;
		}

		if ( 'avada_button' === $type ) {
			return false;
		}

		$sections['taxonomy_options'] = [
			'label'  => __( 'Avada Product Attribute Options', 'fusion-builder' ),
			'id'     => 'taxonomy_options',
			'class'  => 'avada-tax-heading avada-tax-heading-edit',
			'icon'   => 'fusiona-page-options',
			'fields' => [
				'fusion_tax_heading' => [
					'id'    => 'fusion_tax_heading',
					'label' => __( 'Avada Product Attribute Options', 'fusion-builder' ),
					'class' => 'avada-tax-heading avada-tax-heading-edit',
					'type'  => 'header',
				],
			],
		];

		if ( 'avada_image' === $type ) {
			$sections['taxonomy_options']['fields']['attribute_image'] = [
				'id'          => 'attribute_image',
				'label'       => __( 'Image', 'fusion-builder' ),
				'description' => esc_html__( 'Select an image to use for the attribute.', 'fusion-builder' ),
				'type'        => 'media',
				'location'    => 'TAXO',
			];
		} elseif ( 'avada_color' === $type ) {
			$sections['taxonomy_options']['fields']['attribute_color'] = [
				'id'          => 'attribute_color',
				'label'       => __( 'Color', 'fusion-builder' ),
				'description' => esc_html__( 'Controls the color preview for the attribute. Hex code or rgba value, ex: #000.', 'fusion-builder' ),
				'type'        => 'color-alpha',
				'location'    => 'TAXO',
			];
		}

		return $sections;
	}

	/**
	 * Sets taxonomies we want to add options to.
	 *
	 * @access public
	 * @param array $taxonomies Taxonomies to add options to.
	 * @since 7.2
	 */
	public function add_taxonomy_options( $taxonomies = [] ) {
		if ( null === $this->taxonomies ) {
			$this->set_taxonomies();
		}

		foreach ( (array) $this->taxonomies as $taxonomy ) {
			$taxonomies[] = 'pa_' . $taxonomy->attribute_name;
		}
		return $taxonomies;
	}

	/**
	 * Sets taxonomies we want to add options to.
	 *
	 * @access public
	 * @since 7.2
	 */
	public function set_taxonomies() {
		$this->taxonomies = [];
		if ( function_exists( 'wc_get_attribute_taxonomies' ) ) {

			$attribute_taxonomies = wc_get_attribute_taxonomies();
			if ( ! $attribute_taxonomies ) {
				return;
			}

			foreach ( $attribute_taxonomies as $taxonomy ) {
				if ( false !== strpos( $taxonomy->attribute_type, 'avada_' ) ) {
					$this->taxonomies[] = $taxonomy;
				}
			}
		}
	}

	/**
	 * Gets all stored attribute icons, keyed by attribute ID.
	 *
	 * @access public
	 * @since 7.16.1
	 * @return array
	 */
	public function get_attribute_icons() {
		$icons = get_option( $this->icons_option, [] );

		return is_array( $icons ) ? $icons : [];
	}

	/**
	 * Gets the icon stored on an attribute.
	 *
	 * @access public
	 * @since 7.16.1
	 * @param int|string $attribute Attribute ID, or attribute taxonomy name with or without the pa_ prefix.
	 * @return string The stored icon name, or an empty string.
	 */
	public function get_attribute_icon( $attribute ) {

		// wc_attribute_taxonomy_id_by_name() takes the name in either form.
		$attribute_id = is_numeric( $attribute ) ? (int) $attribute : (int) wc_attribute_taxonomy_id_by_name( $attribute );

		if ( ! $attribute_id ) {
			return '';
		}

		$icons = $this->get_attribute_icons();

		return isset( $icons[ $attribute_id ] ) && is_string( $icons[ $attribute_id ] ) ? $icons[ $attribute_id ] : '';
	}

	/**
	 * Gets the icon set for one of WooCommerce's own rows in the attributes table.
	 *
	 * Weight and dimensions are not attributes and have no attributes screen to set an icon
	 * on, so they use a global option instead. They are the same thing on every product.
	 *
	 * @access public
	 * @since 7.16.1
	 * @param string $row The row key, weight or dimensions.
	 * @return string The stored icon name, or an empty string.
	 */
	public function get_detail_row_icon( $row ) {
		$options = [
			'weight'     => 'woocommerce_weight_icon',
			'dimensions' => 'woocommerce_dimensions_icon',
		];

		if ( ! isset( $options[ $row ] ) ) {
			return '';
		}

		$icon = Avada()->settings->get( $options[ $row ] );

		return is_string( $icon ) ? $icon : '';
	}

	/**
	 * Markup for an attribute icon.
	 *
	 * @access public
	 * @since 7.16.1
	 * @param int|string $attribute   Attribute ID, or attribute taxonomy name.
	 * @param string     $extra_class Additional classes for the icon element.
	 * @return string The icon markup, or an empty string if the attribute has no icon.
	 */
	public function attribute_icon_markup( $attribute, $extra_class = '' ) {
		return $this->icon_markup( $this->get_attribute_icon( $attribute ), $extra_class );
	}

	/**
	 * Markup for a weight or dimensions icon.
	 *
	 * @access public
	 * @since 7.16.1
	 * @param string $row         The row key, weight or dimensions.
	 * @param string $extra_class Additional classes for the icon element.
	 * @return string The icon markup, or an empty string if no icon is set.
	 */
	public function detail_row_icon_markup( $row, $extra_class = '' ) {
		return $this->icon_markup( $this->get_detail_row_icon( $row ), $extra_class );
	}

	/**
	 * Builds the icon markup for a stored icon name.
	 *
	 * @access public
	 * @since 7.16.1
	 * @param string $icon        The stored icon name.
	 * @param string $extra_class Additional classes for the icon element.
	 * @return string The icon markup, or an empty string if there is no icon.
	 */
	public function icon_markup( $icon, $extra_class = '' ) {
		if ( ! is_string( $icon ) || '' === $icon ) {
			return '';
		}

		$classes = 'awb-attribute-icon ' . fusion_font_awesome_name_handler( $icon );

		if ( $extra_class ) {
			$classes .= ' ' . $extra_class;
		}

		return '<i class="' . esc_attr( trim( $classes ) ) . '" aria-hidden="true"></i>';
	}

	/**
	 * Adds the icon field to the "Add new attribute" form.
	 *
	 * @access public
	 * @since 7.16.1
	 * @return void
	 */
	public function attribute_icon_field_add() {
		?>
		<div class="form-field">
			<label for="awb_attribute_icon"><?php esc_html_e( 'Icon', 'Avada' ); ?></label>
			<?php $this->attribute_icon_picker(); ?>
			<p class="description"><?php esc_html_e( 'Select an icon to represent this attribute. Elements which support it can display the icon instead of, or next to, the attribute name.', 'Avada' ); ?></p>
		</div>
		<?php
	}

	/**
	 * Adds the icon field to the "Edit attribute" form.
	 *
	 * @access public
	 * @since 7.16.1
	 * @return void
	 */
	public function attribute_icon_field_edit() {

		// The edit form is reached with the attribute ID in the URL; WooCommerce reads it the same way.
		$attribute_id = isset( $_GET['edit'] ) ? absint( $_GET['edit'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification
		?>
		<tr class="form-field">
			<th scope="row" valign="top">
				<label for="awb_attribute_icon"><?php esc_html_e( 'Icon', 'Avada' ); ?></label>
			</th>
			<td>
				<?php $this->attribute_icon_picker( $attribute_id ); ?>
				<p class="description"><?php esc_html_e( 'Select an icon to represent this attribute. Elements which support it can display the icon instead of, or next to, the attribute name.', 'Avada' ); ?></p>
			</td>
		</tr>
		<?php
	}

	/**
	 * The icon picker itself, shared by both attribute forms.
	 *
	 * The markup mirrors the page options icon picker in includes/metaboxes/metaboxes.php,
	 * so that the behaviour in assets/admin/js/fusion-menu-options.js applies as it is.
	 * The page options picker styling lives in the Avada Builder admin stylesheet, which is
	 * not loaded here, so the .nav-menus-php class pulls in the theme's own copy of it -
	 * see the .awb-attribute-icon-field block in admin.less for why it has to be that way.
	 *
	 * @access public
	 * @since 7.16.1
	 * @param int $attribute_id The attribute ID, 0 on the add form.
	 * @return void
	 */
	public function attribute_icon_picker( $attribute_id = 0 ) {
		$icon = $attribute_id ? $this->get_attribute_icon( $attribute_id ) : '';
		?>
		<div class="nav-menus-php awb-attribute-icon-field awb-standalone-iconpicker">
			<div class="option-field fusion-iconpicker">
				<div class="fusion-iconpicker-preview">
					<input type="text" class="fusion-icon-search" placeholder="<?php esc_attr_e( 'Search Icons', 'Avada' ); ?>" />
					<span class="input-icon fusiona-search"></span>
					<span class="add-custom-icons">
						<a href="<?php echo esc_url( admin_url( 'post-new.php?post_type=fusion_icons' ) ); ?>" target="_blank" class="fusiona-plus" title="<?php esc_attr_e( 'Add Custom Icon Set', 'Avada' ); ?>"></a>
					</span>
				</div>
				<div class="fusion-iconselect-wrapper">
					<div class="icon_select_container"></div>
					<?php // The picker writes the selected icon to the input it finds in the icon container's parent, so it has to live in here. ?>
					<input type="hidden" id="awb_attribute_icon" class="fusion-iconpicker-input" name="awb_attribute_icon" value="<?php echo esc_attr( $icon ); ?>" />
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Stores the icon for an attribute, on both add and update.
	 *
	 * Runs on woocommerce_attribute_added / woocommerce_attribute_updated, which fire after
	 * WooCommerce has already verified the form nonce in WC_Admin_Attributes.
	 *
	 * @access public
	 * @since 7.16.1
	 * @param int   $id   The attribute ID.
	 * @param array $data The attribute data.
	 * @return void
	 */
	public function save_attribute_icon( $id, $data = [] ) {
		if ( ! isset( $_POST['awb_attribute_icon'] ) || ! current_user_can( 'manage_product_terms' ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			return;
		}

		$icon  = sanitize_text_field( wp_unslash( $_POST['awb_attribute_icon'] ) ); // phpcs:ignore WordPress.Security.NonceVerification
		$icons = $this->get_attribute_icons();

		// Attributes without an icon are not stored at all, rather than stored empty.
		if ( '' === $icon ) {
			unset( $icons[ (int) $id ] );
		} else {
			$icons[ (int) $id ] = $icon;
		}

		$this->store_attribute_icons( $icons );
	}

	/**
	 * Writes the icons back, or drops the option entirely once it would be empty.
	 *
	 * Nothing is written when no attribute has an icon, so a store which never uses the
	 * feature keeps no row at all. update_option() itself is a no-op when unchanged.
	 *
	 * @access public
	 * @since 7.16.1
	 * @param array $icons Icons keyed by attribute ID.
	 * @return void
	 */
	public function store_attribute_icons( $icons ) {
		if ( empty( $icons ) ) {
			delete_option( $this->icons_option );
			return;
		}

		update_option( $this->icons_option, $icons, false );
	}

	/**
	 * Removes the stored icon when an attribute is deleted.
	 *
	 * @access public
	 * @since 7.16.1
	 * @param int $id The attribute ID.
	 * @return void
	 */
	public function delete_attribute_icon( $id ) {
		$icons = $this->get_attribute_icons();

		if ( ! isset( $icons[ (int) $id ] ) ) {
			return;
		}

		unset( $icons[ (int) $id ] );
		$this->store_attribute_icons( $icons );
	}

	/**
	 * Enqueues the icon picker assets on the product attributes screen.
	 *
	 * The picker lives in assets/admin/js/fusion-menu-options.js, which renders the icon
	 * markup on document ready and initialises anything marked .awb-standalone-iconpicker.
	 *
	 * @access public
	 * @since 7.16.1
	 * @return void
	 */
	public function enqueue_attribute_icon_assets() {
		global $pagenow, $fusion_library_latest_version;

		if ( 'edit.php' !== $pagenow || ! isset( $_GET['page'] ) || 'product_attributes' !== $_GET['page'] ) { // phpcs:ignore WordPress.Security.NonceVerification
			return;
		}

		$version = Avada::get_theme_version();

		// The picker styling comes from admin.css, which is loaded on all admin screens.
		wp_enqueue_style( 'fontawesome', Fusion_Font_Awesome::get_backend_css_url(), [], $version );

		/*
		 * Custom icon sets are handed to the picker below, but their webfonts are not:
		 * Fusion_Custom_Icon_Set::enqueue_admin_scripts() only loads them on the post editing
		 * screens, nav-menus and the Global Options, so here every custom glyph would come out
		 * blank. Its enqueue_scripts() is exactly the loop that is needed.
		 */
		if ( class_exists( 'Fusion_Custom_Icon_Set' ) ) {
			Fusion_Custom_Icon_Set::get_instance()->enqueue_scripts();
		}

		wp_enqueue_script( 'fuse-script', FUSION_LIBRARY_URL . '/assets/min/js/library/fuse.js', [], $fusion_library_latest_version, false );
		wp_enqueue_script( 'fontawesome-search-script', FUSION_LIBRARY_URL . '/assets/fonts/fontawesome/js/icons-search-free.js', [], $fusion_library_latest_version, false );

		wp_enqueue_script(
			'fusion-menu-options',
			trailingslashit( Avada::$template_dir_url ) . 'assets/admin/js/fusion-menu-options.js',
			[ 'jquery', 'underscore' ],
			$version,
			true
		);

		wp_localize_script(
			'fusion-menu-options',
			'fusionMenuConfig',
			[
				'fontawesomeicons'   => fusion_get_icons_array(),
				'fontawesomesubsets' => Avada()->settings->get( 'status_fontawesome' ),
				'customIcons'        => fusion_get_custom_icons_array(),

				/* translators: The iconset name. */
				'no_results_in'      => esc_html__( 'No Results in "%s"', 'Avada' ),
			]
		);
	}

	/**
	 * Adds new attribute types to the selection.
	 *
	 * @static
	 * @access public
	 * @param array $attributes Attributes array.
	 * @since 7.2
	 */
	public function add_attribute_types( $attributes = [] ) {
		$attributes['avada_color']  = __( 'Avada Color', 'fusion-builder' );
		$attributes['avada_image']  = __( 'Avada Image', 'fusion-builder' );
		$attributes['avada_button'] = __( 'Avada Button', 'fusion-builder' );
		return $attributes;
	}

	/**
	 * Add columns for custom attribute types in the WooCommerce attributes table, if needed.
	 *
	 * @param array $columns The previous columns.
	 * @return array The new columns.
	 * @since 7.2
	 */
	public function add_custom_attribute_type_preview( $columns ) {

		if ( ! wp_doing_ajax() ) {
			$screen = get_current_screen();
			if ( ! $screen instanceof WP_Screen ) {
				return $columns;
			}
			$taxonomy_slug = $screen->taxonomy;
		} else {
			// We are in AJAX, try to determine the taxonomy from http referer.
			$params         = [];
			$url            = wp_get_referer();
			$url_components = wp_parse_url( $url );

			if ( ! is_array( $url_components ) && ! isset( $url_components['query'] ) ) {
				return $columns;
			}

			parse_str( $url_components['query'], $params );
			$taxonomy_slug = '';
			if ( isset( $params['taxonomy'] ) ) {
				$taxonomy_slug = $params['taxonomy'];
			}
		}

		if ( ! $taxonomy_slug ) {
			return $columns;
		}

		$attribute_id = wc_attribute_taxonomy_id_by_name( $taxonomy_slug );

		if ( ! $attribute_id ) {
			return $columns;
		}

		$attribute = wc_get_attribute( $attribute_id );
		if ( ! $attribute ) {
			return $columns;
		}
		$type = $attribute->type;

		if ( 'avada_color' === $type ) {
			$new_column = [ 'avada_color' => '' ];
			$columns    = array_merge( array_slice( $columns, 0, 2, true ), $new_column, array_slice( $columns, 2, null, true ) );
		}

		if ( 'avada_image' === $type ) {
			$new_column = [ 'avada_image' => '' ];
			$columns    = array_merge( array_slice( $columns, 0, 2, true ), $new_column, array_slice( $columns, 2, null, true ) );
		}

		return $columns;
	}

	/**
	 * Create the preview columns, for custom avada attributes types.
	 *
	 * @access public
	 * @since 7.7 
	 * @param string     $content The previews content.
	 * @param string     $column_id The column Id.
	 * @param int|string $term_id The term Id.
	 * @return string The content.
	 */
	public function create_preview_column_for_custom_attribute_type( $content, $column_id, $term_id ) {
		if ( 'avada_color' === $column_id ) {
			$color = fusion_data()->term_meta( $term_id )->get( 'attribute_color' );
			if ( ! $color ) {
				$color = 'transparent';
			}
			return '<div class="avada-color-column-preview" style="background-color:' . $color . '"></div>';
		}

		if ( 'avada_image' === $column_id ) {
			$image = fusion_data()->term_meta( intval( $term_id ) )->get( 'attribute_image' );

			$image_id = '';
			if ( is_array( $image ) && isset( $image['id'] ) ) {
				$image_id = $image['id'];
			}

			$image_url = '';
			if ( ! empty( $image_id ) ) {
				$image_url = wp_get_attachment_image_url( $image_id, 'thumbnail' );

				if ( ! is_string( $image_url ) ) {
					$image_url = '';
				}
			}

			return '<img class="avada-image-column-preview" src="' . esc_attr( $image_url ) . '" alt="">';
		}

		return $content;
	}

	/**
	 * Filters the link markup for the WooCommerce layered nav list widgets.
	 *
	 * @access public
	 * @since 7.7
	 * @param string $term_html HTML of the term link.
	 * @param object $term The term object.
	 * @param string $link The link URL.
	 * @param string $count Number of products matching the attribute.
	 * @return string The content.
	 */
	public function layered_nav_list_links( $term_html, $term, $link, $count ) {
		$attribute = wc_get_attribute( wc_attribute_taxonomy_id_by_name( $term->taxonomy ) );
		$attr_type = $attribute->type;

		switch ( $attr_type ) {
			case 'avada_color':
				$color     = fusion_data()->term_meta( $term->term_id )->get( 'attribute_color' );
				$term_html = '<a class="awb-woo-attr" rel="nofollow" href="' . esc_url( $link ) . '"><span class="awb-woo-attr-wrapper"><span class="avada-color-select"><span style="background-color: ' . esc_attr( $color ) . '"></span></span><span class="awb-woo-attr-name">' . esc_html( $term->name ) . '</span></span><span class="awb-woo-attr-count">(' . esc_html( $count ) . ')</span></a>';
				break;
			case 'avada_image':
				$image        = fusion_data()->term_meta( $term->term_id )->get( 'attribute_image' );
				$image_id     = isset( $image['id'] ) ? $image['id'] : '';
				$image_url    = isset( $image['url'] ) ? $image['url'] : '';
				$image_size   = isset( $image['size'] ) ? $image['size'] : 'full';
				$image_data   = fusion_library()->images->get_attachment_data_by_helper( $image_id, $image_url );
				$image_output = is_array( $image_data ) ? wp_get_attachment_image( $image_data['id'], $image_size ) : '';
				$term_html    = '<a class="awb-woo-attr" rel="nofollow" href="' . esc_url( $link ) . '"><span class="awb-woo-attr-wrapper"><span class="avada-image-select">' . $image_output . '</span><span class="awb-woo-attr-name">' . esc_html( $term->name ) . '</span></span><span class="awb-woo-attr-count">(' . esc_html( $count ) . ')</span></a>';              
				break;
			case 'avada_button':
				$term_html = '<a class="awb-woo-attr" rel="nofollow" href="' . esc_url( $link ) . '"><span class="awb-woo-attr-wrapper"><span class="avada-button-select">' . esc_html( $term->name ) . '</span></span><span class="awb-woo-attr-count">(' . esc_html( $count ) . ')</span></a>';
				break;
		}

		return $term_html;
	}
}

/**
 * Instantiates the Avada_Woocommerce_Variations class.
 * Make sure the class is properly set-up.
 *
 * @since object 7.2
 * @return object Avada_Woocommerce_Variations
 */
function Avada_Woocommerce_Variations() { // phpcs:ignore WordPress.NamingConventions
	return Avada_Woocommerce_Variations::get_instance();
}
Avada_Woocommerce_Variations();
