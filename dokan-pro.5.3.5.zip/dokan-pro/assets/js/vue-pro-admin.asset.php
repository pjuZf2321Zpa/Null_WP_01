<?php return array('dependencies' => array('jquery', 'wp-i18n'), 'version' => '55e45dda45272f0bb03e');
