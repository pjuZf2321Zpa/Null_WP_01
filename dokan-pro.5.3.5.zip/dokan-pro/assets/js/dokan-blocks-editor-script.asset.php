<?php return array('dependencies' => array(), 'version' => 'ae5ec48055407b887a5b');
