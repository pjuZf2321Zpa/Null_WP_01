<?php return array('dependencies' => array(), 'version' => '7cea10fd2841db033d17');
