<?php return array('dependencies' => array('react', 'react-jsx-runtime', 'wp-date', 'wp-dom-ready', 'wp-element', 'wp-i18n'), 'version' => '0d8b540c0de9a5bb0c4d');
