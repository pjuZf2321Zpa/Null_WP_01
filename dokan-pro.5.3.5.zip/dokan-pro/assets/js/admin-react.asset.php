<?php return array('dependencies' => array('lodash', 'react-jsx-runtime', 'wc-settings', 'wp-api-fetch', 'wp-hooks', 'wp-html-entities', 'wp-i18n', 'wp-url'), 'version' => '13fa675828ef50e7f779');
