<?php

namespace WeDevs\DokanPro\CLI;

use WP_CLI;

/**
 * Registers Dokan Pro WP-CLI commands.
 *
 * @since 5.0.17
 */
class Manager {

    /**
     * Contributes the Dokan Pro commands to Dokan Lite's shared registry.
     *
     * @since 5.0.17
     */
    public function __construct() {
        // Bail if Dokan Lite's shared CLI registry is missing (older Lite); otherwise contribute to it.
        if ( ! class_exists( \WeDevs\Dokan\CLI\Manager::class ) ) {
            WP_CLI::debug( 'Dokan Pro CLI commands not registered: this Dokan Lite has no CLI registry.', 'dokan' );

            return;
        }

        add_filter( 'dokan_cli_commands', [ $this, 'register_commands' ] );
    }

    /**
     * Adds the Dokan Pro command classes to the shared registry map.
     *
     * @since 5.0.17
     *
     * @param array $commands Existing command map keyed by command name.
     *
     * @return array
     */
    public function register_commands( $commands ) {
        // An earlier contributor may have returned a non-array; never subscript it blindly.
        $commands = (array) $commands;

        $commands['dokan license'] = LicenseCommand::class;
        $commands['dokan module']  = ModuleCommand::class;

        return $commands;
    }
}
