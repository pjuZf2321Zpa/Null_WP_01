<?php

namespace WeDevs\DokanPro\CLI\Traits;

use WP_CLI\Formatter;

/**
 * Shared single-item rendering for Dokan Pro WP-CLI commands.
 *
 * @since 5.0.17
 */
trait FieldFormatter {

    /**
     * Render an associative array as a single WP-CLI item.
     *
     * @since 5.0.17
     *
     * @param array $fields     Field => value pairs to display.
     * @param array $assoc_args Command assoc args, read for the --format and --field flags.
     *
     * @return void
     */
    protected function render_fields( array $fields, array $assoc_args ) {
        // Formatter keeps the field/value table for table|csv and emits a plain object for json|yaml.
        $formatter = new Formatter( $assoc_args, array_keys( $fields ) );

        $formatter->display_item( (object) $fields );
    }
}
