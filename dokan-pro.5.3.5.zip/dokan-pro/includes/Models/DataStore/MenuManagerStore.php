<?php

namespace WeDevs\DokanPro\Models\DataStore;

use WeDevs\Dokan\Models\BaseModel;
use WeDevs\Dokan\Models\DataStore\BaseDataStore;
use WeDevs\DokanPro\MenuManager\Constants;
use WeDevs\DokanPro\MenuManager\Admin\Settings;

/**
 * Menu Manager Data Store Class
 *
 * @since 5.2.0
 */
class MenuManagerStore extends BaseDataStore {

    /**
     * Get the fields with format as an array where key is the db field name and value is the format.
     *
     * @since 5.2.0
     *
     * @return array
     */
    protected function get_fields_with_format(): array {
        return [
            'left_menus'        => '%s',
            'settings_sub_menu' => '%s',
        ];
    }

    /**
     * Get the table name. Since we're using options, we return a dummy name.
     *
     * @since 5.2.0
     *
     * @return string
     */
    public function get_table_name(): string {
        return 'menu_manager_options'; // Fake name for options-based storage
    }

    /**
     * Create a new menu manager record (options-based).
     *
     * @since 5.2.0
     *
     * @param BaseModel $model The model object containing the data to be inserted.
     *
     * @return int
     */
    public function create( BaseModel &$model ) {
        $data = $this->map_model_to_db_data( $model );

        // Get existing options or create a new structure
        $menu_manager_options = get_option( Constants::DOKAN_MENU_MANAGER, [] );
        $menu_manager_options[ Constants::MENU_MANAGER_OPTIONS ] = $data;

        /**
         * Fires before saving menu manager settings.
         *
         * @since 5.2.0
         */
        do_action( 'dokan_menu_manager_before_save', $menu_manager_options );

        // This may return false if the data is unchanged; this is not an error for us.
        update_option( Constants::DOKAN_MENU_MANAGER, $menu_manager_options );

        // Assign a synthetic stable ID so BaseModel::save() returns > 0.
        $model->set_id( 1 );
        $model->apply_changes();

        do_action( $this->get_hook_prefix() . 'created', 1, $data );

        // Return a positive integer to mimic an inserted row ID.
        return 1;
    }

    /**
     * Read menu manager data from options.
     *
     * @since 5.2.0
     *
     * @param BaseModel $model BaseModel object.
     *
     * @throws \Exception If an invalid entity is passed.
     */
    public function read( BaseModel &$model ) {
        $model->set_defaults();

        // Get menu manager settings from options
        $menu_manager_settings = dokan_get_option(
            Constants::MENU_MANAGER_OPTIONS,
            Constants::DOKAN_MENU_MANAGER,
            Settings::get_processed_menu_data()
        );

        // Apply menu restrictions based on settings
        $processed_data = Settings::apply_menu_restrictions( $menu_manager_settings );

        // Map the data to model format
        $model_data = $this->map_db_raw_to_model_data( (object) $processed_data );

        $model->set_props( $model_data );
        $model->set_object_read( true );

        return $processed_data;
    }

    /**
     * Update menu manager data in options.
     *
     * @since 5.2.0
     *
     * @param BaseModel $model MenuManager object.
     *
     * @return bool
     */
    public function update( BaseModel &$model ) {
        $data = $this->map_model_to_db_data( $model );

        // Get existing options
        $menu_manager_options = get_option( Constants::DOKAN_MENU_MANAGER, [] );
        $menu_manager_options[ Constants::MENU_MANAGER_OPTIONS ] = $data;

        /**
         * Fires before saving menu manager settings.
         *
         * @since 5.2.0
         */
        do_action( 'dokan_menu_manager_before_save', $menu_manager_options );

        // May return false on identical data; treat as success.
        update_option( Constants::DOKAN_MENU_MANAGER, $menu_manager_options );

        // Ensure the model keeps a non-zero ID for subsequent saves.
        if ( ! $model->get_id() ) {
            $model->set_id( 1 );
        }

        $model->apply_changes();

        return true;
    }

    /**
     * Delete menu manager data (reset to defaults).
     *
     * @since 5.2.0
     *
     * @param BaseModel $model BaseModel object.
     * @param array     $args  Array of args to pass to the delete method.
     */
    public function delete( BaseModel &$model, $args = [] ) {
        // Reset options to empty an array
        $current_settings = get_option( Constants::DOKAN_MENU_MANAGER, [] );
        $current_settings[ Constants::MENU_MANAGER_OPTIONS ] = [];

        update_option( Constants::DOKAN_MENU_MANAGER, $current_settings );

        do_action( $this->get_hook_prefix() . 'deleted', 0, [] );
    }

    /**
     * Maps database raw data to model data.
     *
     * @since 5.2.0
     *
     * @param object $raw_data The raw data object retrieved from the database.
     *
     * @return array An array of model data mapped from the database fields.
     */
    protected function map_db_raw_to_model_data( $raw_data ): array {
        $data = [];

        foreach ( $this->get_fields() as $db_field_name ) {
            $data[ $db_field_name ] = $raw_data->{$db_field_name} ?? [];
        }

        return apply_filters( $this->get_hook_prefix() . 'map_db_raw_to_model_data', $data, $raw_data );
    }

    /**
     * Get menu settings with applied restrictions.
     *
     * @since 5.2.0
     *
     * @return array
     */
    public function get_menu_settings_with_restrictions(): array {
        // Get the current menu manager settings
        $menu_manager_settings = dokan_get_option( Constants::MENU_MANAGER_OPTIONS, Constants::DOKAN_MENU_MANAGER, [] );

        if ( empty( $menu_manager_settings ) ) {
            $menu_manager_settings = Settings::get_processed_menu_data();
        }

        // Apply menu restrictions based on settings
        return Settings::apply_menu_restrictions( $menu_manager_settings );
    }

    /**
     * Override the hook prefix for menu manager.
     *
     * @since 5.2.0
     *
     * @return string
     */
    protected function get_hook_prefix(): string {
        return 'dokan_menu_manager_';
    }
}
