<?php

namespace WeDevs\DokanPro\Models;

use WeDevs\Dokan\Models\BaseModel;
use WeDevs\DokanPro\Models\DataStore\MenuManagerStore;

/**
 * Menu Manager Model Class
 *
 * @since 5.2.0
 */
class MenuManager extends BaseModel {

    /**
     * This is the name of this object type.
     *
     * @since 5.2.0
     *
     * @var string
     */
    protected $object_type = 'menu_manager';

    /**
     * Default data for the menu manager.
     *
     * @since 5.2.0
     *
     * @var array
     */
    protected $data = [
        'left_menus'        => [],
        'settings_sub_menu' => [],
    ];

    /**
     * Cache group.
     *
     * @since 5.2.0
     *
     * @var string
     */
    protected $cache_group = 'dokan_menu_manager';

    /**
     * Constructor.
     *
     * @since 5.2.0
     *
     * @param int $id ID to load from the DB (optional).
     */
    public function __construct( int $id = 0 ) {
        parent::__construct( $id );
        $this->set_id( $id );

        // Load data from the database.
        $this->data_store = apply_filters( $this->get_hook_prefix() . 'data_store', new MenuManagerStore() );

        // Read data from the database.
        if ( $this->data_store ) {
            $this->data_store->read( $this );
        }
    }

    /**
     * Get left menus configuration.
     *
     * @since 5.2.0
     *
     * @param string $context Context for getting the data.
     *
     * @return array
     */
    public function get_left_menus( $context = 'view' ) {
        return $this->get_prop( 'left_menus', $context );
    }

    /**
     * Set left menus configuration.
     *
     * @since 5.2.0
     *
     * @param array $left_menus Left menus configuration.
     */
    public function set_left_menus( $left_menus ) {
        $this->set_prop( 'left_menus', $left_menus );
    }

    /**
     * Get settings sub menu configuration.
     *
     * @since 5.2.0
     *
     * @param string $context Context for getting the data.
     *
     * @return array
     */
    public function get_settings_sub_menu( $context = 'view' ) {
        return $this->get_prop( 'settings_sub_menu', $context );
    }

    /**
     * Set settings sub menu configuration.
     *
     * @since 5.2.0
     *
     * @param array $settings_sub_menu Settings sub menu configuration.
     */
    public function set_settings_sub_menu( $settings_sub_menu ) {
        $this->set_prop( 'settings_sub_menu', $settings_sub_menu );
    }

    /**
     * Get menu manager settings.
     *
     * @since 5.2.0
     *
     * @return array Menu manager settings.
     */
    public static function get_menu_settings(): array {
        $menu_manager = new static();
        return [
            'left_menus'        => $menu_manager->get_left_menus(),
            'settings_sub_menu' => $menu_manager->get_settings_sub_menu(),
        ];
    }

    /**
     * Update menu manager settings.
     *
     * @since 5.2.0
     *
     * @param array $left_menus        Left menus configuration.
     * @param array $settings_sub_menu Settings sub menu configuration.
     *
     * @return bool True on success, false on failure.
     */
    public static function update_menu_settings( array $left_menus = [], array $settings_sub_menu = [] ): bool {
        $menu_manager = new static();

        // Get current settings and merge with updates
        if ( ! empty( $left_menus ) ) {
            $current_left_menus = $menu_manager->get_left_menus();
            $merged_left_menus  = self::merge_menu_updates( $current_left_menus, $left_menus );

            $menu_manager->set_left_menus( $merged_left_menus );
        }

        if ( ! empty( $settings_sub_menu ) ) {
            $current_settings_menus = $menu_manager->get_settings_sub_menu();
            $merged_settings_menus  = self::merge_menu_updates( $current_settings_menus, $settings_sub_menu );

            $menu_manager->set_settings_sub_menu( $merged_settings_menus );
        }

        return ( $menu_manager->save() > 0 );
    }

    /**
     * Merge user updates with existing menu structure.
     *
     * @since 5.2.0
     *
     * @param array $current_menus Current menu structure.
     * @param array $user_updates  User-provided updates.
     *
     * @return array Merged menu data.
     */
    public static function merge_menu_updates( array $current_menus, array $user_updates ): array {
        foreach ( $current_menus as $key => $menu_item ) {
            if ( ! isset( $user_updates[ $key ] ) ) {
                continue;
            }

            $user_item = $user_updates[ $key ];

            // Update only the 4 user-editable fields
            $current_menus[ $key ]['is_switched_on'] = wc_string_to_bool(
                $user_item['is_switched_on'] ?? $menu_item['is_switched_on'] ?? true
            );

            $current_menus[ $key ]['menu_manager_position'] = intval(
                $user_item['menu_manager_position'] ?? $menu_item['menu_manager_position'] ?? 0
            );

            $current_menus[ $key ]['menu_manager_title'] = sanitize_text_field(
                $user_item['menu_manager_title'] ?? $menu_item['menu_manager_title'] ?? ''
            );

            $current_menus[ $key ]['previous_title'] = sanitize_text_field(
                $user_item['previous_title'] ?? $menu_item['previous_title'] ?? ''
            );

            $current_menus[ $key ]['pos'] = intval(
                $user_item['pos'] ?? $menu_item['pos'] ?? 1
            );

            $current_menus[ $key ]['static_pos'] = intval(
                $user_item['static_pos'] ?? $menu_item['static_pos'] ?? 20
            );
        }

        return $current_menus;
    }
}
