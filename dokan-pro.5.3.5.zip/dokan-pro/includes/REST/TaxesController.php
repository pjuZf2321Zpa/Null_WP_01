<?php

namespace WeDevs\DokanPro\REST;

use WC_REST_Taxes_Controller;
use WP_Error;
use WP_REST_Request;
use WeDevs\DokanPro\Dashboard\ManualOrders\Manager;

defined( 'ABSPATH' ) || exit;

/**
 * Dokan REST API Taxes controller class.
 *
 * @since 4.0.0
 *
 * @package WeDevs\DokanPro\REST
 */
class TaxesController extends WC_REST_Taxes_Controller {

    /**
     * Endpoint namespace.
     *
     * @var string
     */
    protected $namespace = 'dokan/v1';

    /**
     * Check if a given request has access to read taxes.
     *
     * @param  WP_REST_Request $request Full details about the request.
     * @return WP_Error|boolean
     */
    public function get_items_permissions_check( $request ) {
        if ( ! $this->check_permission() ) {
            return new WP_Error(
                'dokan_rest_cannot_view',
                esc_html__( 'Sorry, you cannot list resources.', 'dokan' ),
                array( 'status' => rest_authorization_required_code() )
            );
        }
        return true;
    }

    /**
     * Check if a given request has access to read a tax.
     *
     * @param  WP_REST_Request $request Full details about the request.
     * @return WP_Error|boolean
     */
    public function get_item_permissions_check( $request ) {
        if ( ! $this->check_permission() ) {
            return new WP_Error(
                'dokan_rest_cannot_view',
                esc_html__( 'Sorry, you cannot view this resource.', 'dokan' ),
                array( 'status' => rest_authorization_required_code() )
            );
        }
        return true;
    }

    /**
     * Check vendor permission.
     *
     * @return bool
     */
    protected function check_permission(): bool {
        return Manager::current_user_can_manage();
    }
}
