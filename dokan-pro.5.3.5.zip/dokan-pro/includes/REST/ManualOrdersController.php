<?php // phpcs:disable WordPress.DB.SlowDBQuery.slow_db_query_meta_query, Universal.NamingConventions.NoReservedKeywordParameterNames.objectFound

namespace WeDevs\DokanPro\REST;

use WC_Data;
use WC_Data_Exception;
use WC_Order;
use WC_REST_Exception;
use WC_REST_Orders_Controller;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;
use WeDevs\Dokan\Utilities\OrderUtil;
use WeDevs\DokanPro\Dashboard\ManualOrders\Manager;

/**
 * REST API Orders controller for Dokan
 *
 * Handles requests to the /manual-orders endpoint.
 *
 * @since 4.0.0
 */
class ManualOrdersController extends WC_REST_Orders_Controller {

    /**
     * Endpoint namespace.
     *
     * @var string
     */
    protected $namespace = 'dokan/v1';

    /**
     * Route base.
     *
     * @var string
     */
    protected $rest_base = 'manual-orders';

    /**
     * Check if a given request has access to perform an action.
     *
     * @param WP_REST_Request $request Full details about the request.
     *
     * @return WP_Error|boolean
     */
    public function get_items_permissions_check( $request ) {
        return $this->check_permission( $request, 'view' );
    }

    /**
     * Check if a given request has access to perform an action.
     *
     * @param WP_REST_Request $request Full details about the request.
     *
     * @return WP_Error|boolean
     */
    public function create_item_permissions_check( $request ) {
        return $this->check_permission( $request, 'create' );
    }

    /**
     * Check if a given request has access to perform an action.
     *
     * @param WP_REST_Request $request Full details about the request.
     *
     * @return WP_Error|boolean
     */
    public function get_item_permissions_check( $request ) {
        $result = $this->check_order_authorization( (int) $request['id'] );
        if ( is_wp_error( $result ) ) {
            return $result;
        }

        return $this->check_permission( $request, 'view' );
    }

    /**
     * Check if a given request has access to perform an action.
     *
     * @param WP_REST_Request $request Full details about the request.
     *
     * @return WP_Error|boolean
     */
    public function update_item_permissions_check( $request ) {
        $result = $this->check_order_authorization( (int) $request['id'] );
        if ( is_wp_error( $result ) ) {
            return $result;
        }

        return $this->check_permission( $request, 'edit' );
    }

    /**
     * Check if a given request has access to perform an action.
     *
     * @param WP_REST_Request $request Full details about the request.
     *
     * @return WP_Error|boolean
     */
    public function delete_item_permissions_check( $request ) {
        $result = $this->check_order_authorization( (int) $request['id'] );
        if ( is_wp_error( $result ) ) {
            return $result;
        }

        return $this->check_permission( $request, 'delete' );
    }

    /**
     * Get formatted item data.
     *
     * @since 4.0.0
     *
     * @param WC_Order $order WC_Data instance.
     *
     * @return array
     * @see   \WC_REST_Orders_V2_Controller::get_formatted_item_data
     * @see   \WC_Order::get_formatted_billing_address
     * @see   \WC_Order::get_formatted_shipping_address
     */
    protected function get_formatted_item_data( $order ) {
        $item_data = parent::get_formatted_item_data( $order );

        $billing_address  = $order->get_formatted_billing_address();
        $shipping_address = $order->get_formatted_shipping_address();

        $item_data['formatted_billing_address']  = $billing_address;
        $item_data['formatted_shipping_address'] = $shipping_address;

        return $item_data;
    }

    /**
     * Get all orders
     *
     * @param WP_REST_Request $request Full details about the request.
     *
     * @return WP_REST_Response
     */
    public function get_items( $request ): WP_REST_Response {
        return $this->perform_vendor_action(
            function () use ( $request ) {
                return parent::get_items( $request );
            }
        );
    }

    /**
     * Get a single item.
     *
     * @param WP_REST_Request $request Full details about the request.
     *
     * @return WP_Error|WP_REST_Response
     */
    public function get_item( $request ) {
        $order_id = (int) $request['id'];
        $result   = $this->check_order_authorization( $order_id );
        if ( is_wp_error( $result ) ) {
            return $result;
        }

        return $this->perform_vendor_action(
            function () use ( $request ) {
                return parent::get_item( $request );
            }
        );
    }

    /**
     * Create a single order.
     *
     * @param WP_REST_Request $request Full details about the request.
     *
     * @return WP_Error|WP_REST_Response
     */
    public function create_item( $request ) {
        return $this->perform_vendor_action(
            function () use ( $request ) {
                return parent::create_item( $request );
            }
        );
    }

    /**
     * Update a single post.
     *
     * @param WP_REST_Request $request Full details about the request.
     *
     * @return WP_Error|WP_REST_Response
     */
    public function update_item( $request ) {
        $order_id = (int) $request['id'];
        $result   = $this->check_order_authorization( $order_id );
        if ( is_wp_error( $result ) ) {
            return $result;
        }

        return $this->perform_vendor_action(
            function () use ( $request ) {
                return parent::update_item( $request );
            }
        );
    }

    /**
     * Delete a single item.
     *
     * @param WP_REST_Request $request Full details about the request.
     *
     * @return WP_REST_Response|WP_Error
     */
    public function delete_item( $request ) {
        $order_id = (int) $request['id'];
        $result   = $this->check_order_authorization( $order_id );
        if ( is_wp_error( $result ) ) {
            return $result;
        }

        return $this->perform_vendor_action(
            function () use ( $request ) {
                return parent::delete_item( $request );
            }
        );
    }

    /**
     * Prepare a single order for create or update.
     *
     * @param WP_REST_Request $request  Request object.
     * @param bool            $creating If is creating a new object.
     *
     * @return WP_Error|WC_Data
     * @throws WC_REST_Exception When an invalid parameter is found.
     * @throws WC_Data_Exception When an invalid parameter is found.
     */
    protected function prepare_object_for_database( $request, $creating = false ) {
        $customer_check = $this->validate_customer( $request, $creating );
        if ( is_wp_error( $customer_check ) ) {
            return $customer_check;
        }

        $this->drop_protected_meta( $request, $creating );

        $order = parent::prepare_object_for_database( $request, $creating );

        if ( is_wp_error( $order ) ) {
            return $order;
        }

        if ( ! $order instanceof WC_Order ) {
            return new WP_Error( 'dokan_rest_invalid_order', esc_html__( 'Invalid order.', 'dokan' ), [ 'status' => 400 ] );
        }

        if ( $creating ) {
            $order->update_meta_data( '_dokan_vendor_id', dokan_get_current_user_id() );
            $order->update_meta_data( '_wc_order_attribution_source_type', 'vendor' );
            $order->update_meta_data( '_wc_order_attribution_utm_source', 'typein' );
        }

        return apply_filters( "dokan_rest_pre_insert_{$this->post_type}_object", $order, $request, $creating );
    }

    /**
     * Drop protected meta (e.g. _dokan_vendor_id, _dokan_commission_rate) from the order and its items in the request.
     *
     * The editor sends existing meta back on every save, so it is dropped rather than rejected.
     *
     * @since 5.3.5
     *
     * @param WP_REST_Request $request  Request object.
     * @param bool            $creating If is creating a new object.
     *
     * @return void
     */
    protected function drop_protected_meta( WP_REST_Request $request, bool $creating ): void {
        $order = $creating ? null : wc_get_order( (int) $request['id'] );
        $order = $order instanceof WC_Order ? $order : null;

        $meta_data = $request->get_param( 'meta_data' );
        if ( is_array( $meta_data ) ) {
            $request->set_param( 'meta_data', $this->filter_protected_meta( $meta_data, $order ) );
        }

        foreach ( [ 'line_items', 'shipping_lines', 'fee_lines', 'coupon_lines' ] as $item_type ) {
            $items = $request->get_param( $item_type );
            if ( ! is_array( $items ) ) {
                continue;
            }

            foreach ( $items as $index => $item ) {
                if ( ! is_array( $item ) || ! isset( $item['meta_data'] ) || ! is_array( $item['meta_data'] ) ) {
                    continue;
                }

                $existing_item = $order && ! empty( $item['id'] ) ? $order->get_item( absint( $item['id'] ), false ) : null;

                $items[ $index ]['meta_data'] = $this->filter_protected_meta( $item['meta_data'], $existing_item ? $existing_item : null );
            }

            $request->set_param( $item_type, $items );
        }
    }

    /**
     * Keep only meta entries that neither use a protected key nor target an existing protected row by id.
     *
     * @since 5.3.5
     *
     * @param array        $meta_data Request meta entries.
     * @param WC_Data|null $target    Existing order or item the entries apply to, if any.
     *
     * @return array
     */
    protected function filter_protected_meta( array $meta_data, ?WC_Data $target ): array {
        $protected_ids = [];
        if ( $target ) {
            foreach ( $target->get_meta_data() as $meta ) {
                if ( $this->is_protected_order_meta( (string) $meta->key ) ) {
                    $protected_ids[] = (int) $meta->id;
                }
            }
        }

        return array_values(
            array_filter(
                $meta_data,
                function ( $meta ) use ( $protected_ids ) {
                    if ( ! is_array( $meta ) || ! isset( $meta['key'] ) || $this->is_protected_order_meta( (string) $meta['key'] ) ) {
                        return false;
                    }

                    // WooCommerce overwrites the key and value of the row an id points to.
                    return ! ( isset( $meta['id'] ) && in_array( absint( $meta['id'] ), $protected_ids, true ) );
                }
            )
        );
    }

    /**
     * Whether a vendor must not write this order or item meta key: `_`-prefixed, `dokan_`-prefixed, a fee recipient, or `has_sub_order`.
     *
     * @since 5.3.5
     *
     * @param string $key Meta key.
     *
     * @return bool
     */
    protected function is_protected_order_meta( string $key ): bool {
        // The meta_key collation ignores case, accents, full-width forms and invisible characters in SQL lookups, so fold the key the same way first.
        if ( class_exists( 'Normalizer' ) ) {
            $folded = \Normalizer::normalize( $key, \Normalizer::FORM_KD );

            // Invalid UTF-8 can't be folded, and $wpdb strips the bad bytes on save, so the stored key could still collide.
            if ( false === $folded ) {
                return true;
            }

            // remove_accents() also maps letters with no decomposition (ø, đ, ł, ß); control characters are ignorable in the collation.
            $normalized = strtolower( trim( remove_accents( (string) preg_replace( '/[\p{Mn}\p{Me}\p{Cf}\p{Cc}]/u', '', $folded ) ) ) );
        } else {
            $normalized = strtolower( trim( remove_accents( $key ) ) );

            // Without intl, only a plain ASCII key can be told apart from a protected one.
            if ( preg_match( '/[^\x20-\x7E]/', $normalized ) ) {
                return true;
            }
        }

        // No PHP fold matches the collation exactly, so for non-ASCII keys MySQL itself decides whether the key equals one Dokan looks up.
        if ( preg_match( '/[^\x20-\x7E]/', $key ) && $this->collates_to_dokan_meta_key( $key ) ) {
            return true;
        }

        // Dokan's accounting meta (fees, discounts, commission, fee recipients) has no `_` prefix, so block it by pattern.
        return is_protected_meta( $key, 'post' )
            || '_' === substr( $normalized, 0, 1 )
            || 0 === strpos( $normalized, 'dokan_' )
            || '_fee_recipient' === substr( $normalized, -14 )
            || 'has_sub_order' === $normalized;
    }

    /**
     * Whether MySQL, under the order meta table's collation, reads the key as `_`- or `dokan_`-prefixed, `_fee_recipient`-suffixed, or `has_sub_order`.
     *
     * @since 5.3.5
     *
     * @param string $key Meta key.
     *
     * @return bool
     */
    protected function collates_to_dokan_meta_key( string $key ): bool {
        global $wpdb;
        static $collation = null;

        if ( null === $collation ) {
            $found     = (string) $wpdb->get_var(
                $wpdb->prepare(
                    'SELECT COLLATION_NAME FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = %s AND COLUMN_NAME = %s',
                    OrderUtil::get_table_for_order_meta(),
                    'meta_key'
                )
            );
            $collation = preg_match( '/^[a-z0-9_]+$/', $found ) ? $found : 'utf8mb4_unicode_520_ci';
        }

        $charset = substr( $collation, 0, (int) strpos( $collation, '_' ) );
        $value   = "CONVERT( %s USING {$charset} ) COLLATE {$collation}";

        // WEIGHT_STRING applies the collation's own rules to the prefix and suffix checks, which LIKE would not do for ignorable characters.
        // No FROM clause on purpose: $wpdb's invalid-text check would otherwise parse a derived table as a table name.
        // phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
        $equal = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT LEFT( WEIGHT_STRING( {$value} ), LENGTH( WEIGHT_STRING( {$value} ) ) ) = WEIGHT_STRING( {$value} )
                    OR LEFT( WEIGHT_STRING( {$value} ), LENGTH( WEIGHT_STRING( {$value} ) ) ) = WEIGHT_STRING( {$value} )
                    OR RIGHT( WEIGHT_STRING( {$value} ), LENGTH( WEIGHT_STRING( {$value} ) ) ) = WEIGHT_STRING( {$value} )
                    OR {$value} = {$value}",
                [ $key, '_', '_', $key, 'dokan_', 'dokan_', $key, '_fee_recipient', '_fee_recipient', $key, 'has_sub_order' ]
            )
        );
        // phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare

        // A failed comparison (e.g. unsupported collation) fails closed.
        return null === $equal || (bool) $equal;
    }

    /**
     * Only allow a customer the vendor already has an order from, so a manual order can't grant access to any customer.
     *
     * @since 5.3.5
     *
     * @param WP_REST_Request $request  Request object.
     * @param bool            $creating If is creating a new object.
     *
     * @return true|WP_Error
     */
    protected function validate_customer( WP_REST_Request $request, bool $creating ) {
        $customer_id = absint( $request['customer_id'] ?? 0 );
        if ( ! $customer_id ) {
            return true;
        }

        if ( ! $creating ) {
            $order = wc_get_order( (int) $request['id'] );
            if ( $order && $order->get_customer_id() === $customer_id ) {
                return true;
            }
        }

        if ( dokan_customer_has_order_from_this_seller( $customer_id, dokan_get_current_user_id() ) ) {
            return true;
        }

        return new WP_Error( 'dokan_rest_invalid_customer_id', esc_html__( 'Invalid customer ID.', 'dokan' ), [ 'status' => 400 ] );
    }

    /**
     * Save an object data.
     *
     * @param WP_REST_Request $request  Full details about the request.
     * @param bool            $creating If is creating a new object.
     *
     * @return WC_Data|WP_Error
     * @throws WC_REST_Exception When an invalid parameter is found.
     */
    protected function save_object( $request, $creating = false ) {
        $order = parent::save_object( $request, $creating );

        if ( is_wp_error( $order ) ) {
            return $order;
        }

        $vendor_id = $order->get_meta( '_dokan_vendor_id' );
        if ( ! $vendor_id || dokan_get_current_user_id() !== (int) $vendor_id ) {
            return new WP_Error(
                'dokan_rest_cannot_edit_order',
                esc_html__( 'Sorry, you are not allowed to edit this resource.', 'dokan' ),
                [ 'status' => 403 ]
            );
        }

        if ( $creating && $order instanceof WC_Order && 'dokan-rest-api' !== $order->get_created_via() ) {
            $order->set_created_via( 'dokan-rest-api' );
            $order->save();
        }

        $this->sync_order_and_balance( $order );

        /**
         * Fires after an order is saved via the REST API.
         *
         * @since 4.0.0
         *
         * @param WC_Order        $order    The order object.
         * @param WP_REST_Request $request  The request object.
         * @param bool            $creating If is creating a new object.
         */
        do_action( 'woocommerce_process_shop_order_meta', $order->get_id(), $order );

        return $order;
    }

    /**
     * Prepare objects query.
     *
     * @param WP_REST_Request $request Full details about the request.
     *
     * @return array
     */
    protected function prepare_objects_query( $request ): array {
        $args = parent::prepare_objects_query( $request );
        $user = dokan_get_current_user_id();

        if ( ! dokan_is_user_seller( $user ) ) {
            return $args;
        }

        $args['meta_query']   = $args['meta_query'] ?? [];
        $args['meta_query'][] = [
            'key'     => '_dokan_vendor_id',
            'value'   => $user,
            'compare' => '=',
        ];

        return apply_filters( 'dokan_rest_orders_prepare_object_query', $args, $request );
    }

    /**
     * Prepare a single order output for response.
     *
     * @param WC_Data         $object  Object data.
     * @param WP_REST_Request $request Request object.
     *
     * @return WP_REST_Response
     */

    /**
     * Sync order and balance
     *
     * @param WC_Data|WP_Error $order
     *
     * @return void
     */
    private function sync_order_and_balance( $order ): void {
        if ( is_wp_error( $order ) ) {
            return;
        }

        $vendor_id = $order->get_meta( '_dokan_vendor_id' );
        $vendor    = dokan()->vendor->get( $vendor_id );

        if ( ! $vendor ) {
            return;
        }

        dokan_sync_insert_order( $order->get_id() );
    }

    public function prepare_object_for_response( $object, $request ): WP_REST_Response {
        $response = parent::prepare_object_for_response( $object, $request );

        if ( ! $object instanceof \WC_Order ) {
            return $response;
        }

        $response->data['subtotal']  = (string) $object->get_subtotal();
        $response->data['fee_total'] = (string) $object->get_total_fees();

        return $response;
    }

    /**
     * Check if a given request has access to perform an action.
     *
     * @param WP_REST_Request $request Full details about the request.
     * @param string          $action  The action to check (view, create, edit, delete).
     *
     * @return WP_Error|boolean
     */
    protected function check_permission( WP_REST_Request $request, string $action ) {
        if ( ! $this->check_vendor_permission() ) {
            $messages = [
                'view'   => esc_html__( 'Sorry, you cannot list resources.', 'dokan' ),
                'create' => esc_html__( 'Sorry, you are not allowed to create resources.', 'dokan' ),
                'edit'   => esc_html__( 'Sorry, you are not allowed to edit this resource.', 'dokan' ),
                'delete' => esc_html__( 'Sorry, you are not allowed to delete this resource.', 'dokan' ),
            ];

            return new WP_Error( "dokan_rest_cannot_$action", $messages[ $action ], [ 'status' => rest_authorization_required_code() ] );
        }

        return true;
    }

    /**
     * Check if the current user has authorization for a specific order.
     *
     * @param int $order_id The order ID to check authorization for.
     *
     * @return bool|WP_Error True if authorized, WP_Error if not.
     */
    protected function check_order_authorization( int $order_id ) {
        $order = wc_get_order( $order_id );
        if ( ! $order instanceof \WC_Order || $order->get_status() === 'trash' ) {
            return new WP_Error(
                'dokan_rest_invalid_order',
                esc_html__( 'Invalid order.', 'dokan' ),
                [ 'status' => 404 ]
            );
        }

        $vendor_id = dokan_get_seller_id_by_order( $order_id );
        if ( $vendor_id !== dokan_get_current_user_id() ) {
            return new WP_Error(
                'dokan_rest_unauthorized_order',
                esc_html__( 'You do not have permission to this order', 'dokan' ),
                array( 'status' => rest_authorization_required_code() )
            );
        }

        return true;
    }

    /**
     * Check if the current user has vendor permissions.
     *
     * @return bool
     */
    public function check_vendor_permission(): bool {
        return Manager::current_user_can_manage();
    }

    /**
     * Perform an action with vendor permission check.
     *
     * @param callable $action The action to perform.
     *
     * @return mixed The result of the action.
     */
    private function perform_vendor_action( callable $action ) {
        add_filter( 'woocommerce_rest_check_permissions', [ $this, 'check_vendor_permission' ] );
        $result = $action();
        remove_filter( 'woocommerce_rest_check_permissions', [ $this, 'check_vendor_permission' ] );

        return $result;
    }
}
