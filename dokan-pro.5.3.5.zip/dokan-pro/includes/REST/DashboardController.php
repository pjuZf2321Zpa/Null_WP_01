<?php

namespace WeDevs\DokanPro\REST;

use WP_Error;
use WP_REST_Server;
use WP_REST_Request;
use WP_REST_Response;
use WeDevs\Dokan\Abstracts\DokanRESTController;
use WeDevs\DokanPro\Dashboard\ProfileProgress;

/**
 * Dashboard API controller
 *
 * @package dokan
 * @since 3.7.13
 *
 * @author weDevs
 */
class DashboardController extends DokanRESTController {

    /**
     * Endpoint namespace.
     *
     * @var string
     */
    protected $namespace = 'dokan/v1';

    /**
     * Route name
     *
     * @var string
     */
    protected $base = 'vendor-dashboard';

    /**
     * Register all routes related with dashboard.
     *
     * @since 3.7.13
     *
     * @return void
     */
    public function register_routes() {
        register_rest_route(
            $this->namespace, '/' . $this->base . '/profile-progressbar', [
                [
                    'methods'             => WP_REST_Server::READABLE,
                    'callback'            => [ $this, 'get_profile_progressbar' ],
                    'permission_callback' => [ $this, 'permission_check_to_get_profile_progressbar' ],
                    'args'                => [],
                ],
            ]
        );

        register_rest_route(
            $this->namespace, '/' . $this->base . '/profile-progressbar/dismiss', [
                [
                    'methods'             => WP_REST_Server::CREATABLE,
                    'callback'            => [ $this, 'dismiss_profile_progressbar' ],
                    'permission_callback' => [ $this, 'permission_check_to_get_profile_progressbar' ],
                    'args'                => [],
                ],
            ]
        );

        register_rest_route(
            $this->namespace, '/' . $this->base . '/profile-progressbar/complete', [
                [
                    'methods'             => WP_REST_Server::CREATABLE,
                    'callback'            => [ $this, 'complete_profile_progressbar' ],
                    'permission_callback' => [ $this, 'permission_check_to_get_profile_progressbar' ],
                    'args'                => [],
                ],
            ]
        );

        register_rest_route(
            $this->namespace, '/' . $this->base . '/profile-progressbar/celebrated', [
                [
                    'methods'             => WP_REST_Server::CREATABLE,
                    'callback'            => [ $this, 'mark_profile_progressbar_celebrated' ],
                    'permission_callback' => [ $this, 'permission_check_to_get_profile_progressbar' ],
                    'args'                => [],
                ],
            ]
        );
    }

    /**
     * Check permission if the current user can see profile progress bar data.
     *
     * Only seller will get the access to get profile progressbar.
     *
     * @since 3.7.13
     *
     * @return boolean
     */
    public function permission_check_to_get_profile_progressbar() {
        return dokan_is_user_seller( get_current_user_id() );
    }

    /**
     * Get profile progressbar data.
     *
     * @since 3.7.13
     *
     * @param WP_REST_Request $request
     *
     * @return WP_REST_Response
     */
    public function get_profile_progressbar( $request ) {
        $profile_progress = new ProfileProgress();

        return rest_ensure_response( $profile_progress->get( true, true ) );
    }

    /**
     * Record that this vendor has seen the completion celebration.
     *
     * @since 5.3.2
     *
     * @param WP_REST_Request $request
     *
     * @return WP_REST_Response
     */
    public function mark_profile_progressbar_celebrated( $request ) {
        // The vendor id, not the signed-in one — staff see their vendor's progress.
        ( new ProfileProgress() )->mark_celebrated( dokan_get_current_user_id() );

        return rest_ensure_response( [ 'celebrated' => true ] );
    }

    /**
     * Hide the profile progressbar / completion card for 24 hours.
     *
     * Reuses the legacy 24h transient so the new card and the legacy bar share
     * the same "hide for a day" state.
     *
     * @since 5.3.2
     *
     * @param WP_REST_Request $request
     *
     * @return WP_REST_Response
     */
    public function dismiss_profile_progressbar( $request ) {
        ( new ProfileProgress() )->dismiss_for_a_day( get_current_user_id() );

        return rest_ensure_response( [ 'dismissed' => true ] );
    }

    /**
     * Permanently close the profile progressbar / completion card once complete.
     *
     * Reuses the legacy `closed_by_user` flag, gated on the card's own completeness
     * check rather than the legacy bar's `progress >= 100` — see
     * `ProfileProgress::is_setup_complete()`.
     *
     * @since 5.3.2
     *
     * @param WP_REST_Request $request
     *
     * @return WP_REST_Response|WP_Error
     */
    public function complete_profile_progressbar( $request ) {
        // The vendor id, not the signed-in one — the flag lives on the vendor's profile.
        $closed = ( new ProfileProgress() )->close_permanently( dokan_get_current_user_id() );

        if ( ! $closed ) {
            return new WP_Error(
                'dokan_profile_incomplete',
                __( 'Profile is not complete yet.', 'dokan' ),
                [ 'status' => 400 ]
            );
        }

        return rest_ensure_response( [ 'completed' => true ] );
    }
}
