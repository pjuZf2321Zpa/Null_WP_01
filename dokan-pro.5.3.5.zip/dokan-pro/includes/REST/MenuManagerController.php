<?php

namespace WeDevs\DokanPro\REST;

use WeDevs\Dokan\REST\DokanBaseAdminController;
use WeDevs\DokanPro\Models\MenuManager;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;
use WP_Error;

/**
 * Menu Manager REST Controller
 *
 * @since 5.2.0
 */
class MenuManagerController extends DokanBaseAdminController {

    /**
     * The namespace of this controller's route.
     *
     * @var string $rest_base The base URL for the REST API.
     */
    protected $rest_base = 'menu-manager';

    /**
     * Register all routes.
     *
     * @since 5.2.0
     *
     * @return void
     */
    public function register_routes() {
        register_rest_route(
            $this->namespace,
            '/' . $this->rest_base,
            [
                [
                    'methods'             => WP_REST_Server::READABLE,
                    'callback'            => [ $this, 'get_items' ],
                    'permission_callback' => [ $this, 'check_permission' ],
                ],
                [
                    'methods'             => WP_REST_Server::CREATABLE,
                    'callback'            => [ $this, 'create_item' ],
                    'permission_callback' => [ $this, 'check_permission' ],
                    'args'                => $this->get_endpoint_args_for_item_schema(),
                ],
                'schema' => [ $this, 'get_public_item_schema' ],
            ]
        );
    }

    /**
     * Get menu manager settings.
     *
     * @since 5.2.0
     *
     * @param WP_REST_Request $request Request object.
     *
     * @return WP_Error|WP_REST_Response
     */
    public function get_items( $request ) {
        try {
            // Use the MenuManager model to get settings
            $menu_manager_settings = MenuManager::get_menu_settings();

            // Ensure the structure is correct and return the data.
            return rest_ensure_response(
                $this->prepare_item_for_response(
                    $menu_manager_settings,
                    $request
                )
            );
        } catch ( \Exception $e ) {
            return new WP_Error( 'dokan_menu_manager_get_error', $e->getMessage(), [ 'status' => 500 ] );
        }
    }

    /**
     * Update menu manager settings.
     *
     * @since 5.2.0
     *
     * @param WP_REST_Request $request Request object.
     *
     * @return WP_Error|WP_REST_Response
     */
    public function create_item( $request ) {
        try {
            $params = $request->get_params();

            // Validate required parameters
            if ( empty( $params['left_menus'] ) && empty( $params['settings_sub_menu'] ) ) {
                return new WP_Error(
                    'dokan_menu_manager_invalid_data',
                    esc_html__( 'Invalid menu data provided.', 'dokan' ),
                    [ 'status' => 400 ]
                );
            }

            // Use the MenuManager model to update settings
            $result = MenuManager::update_menu_settings(
                $params['left_menus'] ?? [],
                $params['settings_sub_menu'] ?? []
            );

            if ( ! $result ) {
                return new WP_Error(
                    'dokan_menu_manager_save_failed',
                    esc_html__( 'Failed to save menu manager settings.', 'dokan' ),
                    [ 'status' => 500 ]
                );
            }

            // Return updated data
            return $this->get_items( $request );
        } catch ( \Exception $e ) {
            return new WP_Error( 'dokan_menu_manager_save_error', $e->getMessage(), [ 'status' => 500 ] );
        }
    }

    /**
     * Prepares the item for the REST response.
     *
     * @since 5.2.0
     *
     * @param mixed           $item    WordPress representation of the item.
     * @param WP_REST_Request $request Request object.
     *
     * @return array|WP_Error Response data array on success, or WP_Error object on failure.
     */
    public function prepare_item_for_response( $item, $request ) {
        // Ensure we have the expected structure
        if ( ! is_array( $item ) || ! isset( $item['left_menus'] ) ) {
            return new WP_Error(
                'dokan_menu_manager_invalid_structure',
                esc_html__( 'Invalid menu data structure.', 'dokan' ),
                [ 'status' => 500 ]
            );
        }

        // Prepare response with complete menu data structure
        $data = [
            'left_menus'        => $this->prepare_menu_items_for_response( $item['left_menus'] ?? [] ),
            'settings_sub_menu' => $this->prepare_menu_items_for_response( $item['settings_sub_menu'] ?? [] ),
        ];

        /**
         * Filter the menu manager response data.
         *
         * @since 5.2.0
         *
         * @param array           $data    The response data array.
         * @param mixed           $item    The original item.
         * @param WP_REST_Request $request Request used to generate the response.
         */
        return apply_filters( 'dokan_rest_prepare_menu_manager', $data, $item, $request );
    }

    /**
     * Prepare menu items for response, ensuring proper field types.
     *
     * @since 5.2.0
     *
     * @param array $menu_items Menu items to prepare
     *
     * @return array Prepared menu items
     */
    protected function prepare_menu_items_for_response( $menu_items ) {
        $prepared_items = [];

        foreach ( $menu_items as $key => $menu_item ) {
            $prepared_items[ $key ] = $menu_item;

            // Ensure numeric fields are properly typed
            $prepared_items[ $key ]['menu_manager_position'] = intval( $menu_item['menu_manager_position'] ?? 0 );
            $prepared_items[ $key ]['pos']                   = intval( $menu_item['pos'] ?? 0 );
            $prepared_items[ $key ]['static_pos']            = intval( $menu_item['static_pos'] ?? 0 );

            // Ensure boolean fields are properly typed
            $prepared_items[ $key ]['is_sortable']            = wc_string_to_bool( $menu_item['is_sortable'] ?? true );
            $prepared_items[ $key ]['editable']               = wc_string_to_bool( $menu_item['editable'] ?? true );
            $prepared_items[ $key ]['switchable']             = wc_string_to_bool( $menu_item['switchable'] ?? true );
            $prepared_items[ $key ]['is_switched_on']         = wc_string_to_bool( $menu_item['is_switched_on'] ?? true );
            $prepared_items[ $key ]['edit_now']               = wc_string_to_bool( $menu_item['edit_now'] ?? false );
            $prepared_items[ $key ]['temporary_disable_edit'] = wc_string_to_bool( $menu_item['temporary_disable_edit'] ?? false );

            // Ensure string fields are properly sanitized
            $prepared_items[ $key ]['menu_manager_title'] = sanitize_text_field( $menu_item['menu_manager_title'] ?? '' );
            $prepared_items[ $key ]['previous_title']     = sanitize_text_field( $menu_item['previous_title'] ?? '' );
            $prepared_items[ $key ]['title']              = sanitize_text_field( $menu_item['title'] ?? '' );
            $prepared_items[ $key ]['icon']               = wp_kses(
                $menu_item['icon'] ?? '',
                [
                    'i'    => [
                        'class'       => [],
                        'aria-hidden' => [],
                    ],
                    'span' => [ 'class' => [] ],
                ]
            );
            $prepared_items[ $key ]['url']         = esc_url_raw( $menu_item['url'] ?? '' );
            $prepared_items[ $key ]['permission']  = sanitize_text_field( $menu_item['permission'] ?? '' );
            $prepared_items[ $key ]['react_route'] = sanitize_text_field( $menu_item['react_route'] ?? '' );

            // Handle counts field (can be integer or null)
            if ( isset( $menu_item['counts'] ) ) {
                $prepared_items[ $key ]['counts'] = is_numeric( $menu_item['counts'] ) ? intval( $menu_item['counts'] ) : null;
            } else {
                $prepared_items[ $key ]['counts'] = null;
            }
        }

        /**
         * Filter the menu items for the response.
         *
         * @since 5.2.0
         *
         * @param array $prepared_items Prepared menu items.
         * @param array $menu_items     Original menu items.
         */
        return apply_filters(
            'dokan_menu_manager_prepare_menu_items_for_response',
            $prepared_items,
            $menu_items
        );
    }

    /**
     * Get the schema for the endpoint.
     *
     * @since 5.2.0
     *
     * @return array
     */
    public function get_public_item_schema() {
        $menu_item_properties = [
            'menu_key' => [
                'description' => esc_html__( 'Unique identifier for the menu item.', 'dokan' ),
                'type'        => 'string',
                'context'     => [ 'view', 'edit' ],
                'readonly'    => true,
            ],
            'is_sortable' => [
                'description' => esc_html__( 'Whether the menu item can be reordered.', 'dokan' ),
                'type'        => 'boolean',
                'context'     => [ 'view' ],
                'readonly'    => true,
            ],
            'previous_title' => [
                'description' => esc_html__( 'Previous title of the menu item.', 'dokan' ),
                'type'        => 'string',
                'context'     => [ 'view', 'edit' ],
            ],
            'menu_manager_title' => [
                'description' => esc_html__( 'Custom title set by the menu manager.', 'dokan' ),
                'type'        => 'string',
                'context'     => [ 'view', 'edit' ],
            ],
            'edit_now' => [
                'description' => esc_html__( 'Whether the menu item is currently being edited.', 'dokan' ),
                'type'        => 'boolean',
                'context'     => [ 'view' ],
                'readonly'    => true,
            ],
            'editable' => [
                'description' => esc_html__( 'Whether the menu item can be edited.', 'dokan' ),
                'type'        => 'boolean',
                'context'     => [ 'view' ],
                'readonly'    => true,
            ],
            'temporary_disable_edit' => [
                'description' => esc_html__( 'Whether editing is temporarily disabled for this menu item.', 'dokan' ),
                'type'        => 'boolean',
                'context'     => [ 'view' ],
                'readonly'    => true,
            ],
            'switchable' => [
                'description' => esc_html__( 'Whether the menu item can be enabled/disabled.', 'dokan' ),
                'type'        => 'boolean',
                'context'     => [ 'view' ],
                'readonly'    => true,
            ],
            'is_switched_on' => [
                'description' => esc_html__( 'Whether the menu item is enabled.', 'dokan' ),
                'type'        => 'boolean',
                'context'     => [ 'view', 'edit' ],
            ],
            'menu_manager_position' => [
                'description' => esc_html__( 'Position of the menu item in the menu manager.', 'dokan' ),
                'type'        => 'integer',
                'context'     => [ 'view', 'edit' ],
                'minimum'     => 0,
            ],
            'title' => [
                'description' => esc_html__( 'Original title of the menu item.', 'dokan' ),
                'type'        => 'string',
                'context'     => [ 'view' ],
                'readonly'    => true,
            ],
            'icon' => [
                'description' => esc_html__( 'HTML icon for the menu item.', 'dokan' ),
                'type'        => 'string',
                'context'     => [ 'view' ],
                'readonly'    => true,
            ],
            'url' => [
                'description' => esc_html__( 'URL for the menu item.', 'dokan' ),
                'type'        => 'string',
                'format'      => 'uri',
                'context'     => [ 'view' ],
                'readonly'    => true,
            ],
            'pos' => [
                'description' => esc_html__( 'Original position of the menu item.', 'dokan' ),
                'type'        => 'integer',
                'context'     => [ 'view' ],
                'readonly'    => true,
            ],
            'permission' => [
                'description' => esc_html__( 'Permission required to access the menu item.', 'dokan' ),
                'type'        => 'string',
                'context'     => [ 'view' ],
                'readonly'    => true,
            ],
            'static_pos' => [
                'description' => esc_html__( 'Static position used for sorting.', 'dokan' ),
                'type'        => 'integer',
                'context'     => [ 'view' ],
                'readonly'    => true,
            ],
            'counts' => [
                'description' => esc_html__( 'Count indicator for the menu item.', 'dokan' ),
                'type'        => [ 'integer', 'null' ],
                'context'     => [ 'view' ],
                'readonly'    => true,
            ],
            'react_route' => [
                'description' => esc_html__( 'React route for SPA navigation.', 'dokan' ),
                'type'        => [ 'string', 'null' ],
                'context'     => [ 'view' ],
                'readonly'    => true,
            ],
            'submenu' => [
                'description' => esc_html__( 'Submenu items for this menu item.', 'dokan' ),
                'type'        => [ 'object', 'null' ],
                'context'     => [ 'view' ],
                'readonly'    => true,
                'properties'  => [
                    'additionalProperties' => [
                        'type'       => 'object',
                        'properties' => [
                            'title'       => [ 'type' => 'string' ],
                            'icon'        => [ 'type' => 'string' ],
                            'url'         => [ 'type' => 'string', 'format' => 'uri' ],
                            'pos'         => [ 'type' => 'integer' ],
                            'permission'  => [ 'type' => 'string' ],
                            'react_route' => [ 'type' => [ 'string', 'null' ] ],
                        ],
                    ],
                ],
            ],
        ];

        $schema = [
            '$schema'    => 'http://json-schema.org/draft-04/schema#',
            'title'      => 'menu_manager',
            'type'       => 'object',
            'properties' => [
                'left_menus' => [
                    'description' => esc_html__( 'Left menu items configuration.', 'dokan' ),
                    'type'        => 'object',
                    'context'     => [ 'view', 'edit' ],
                    'properties'  => [
                        'additionalProperties' => [
                            'type'       => 'object',
                            'properties' => $menu_item_properties,
                        ],
                    ],
                ],
                'settings_sub_menu' => [
                    'description' => esc_html__( 'Settings sub menu items configuration.', 'dokan' ),
                    'type'        => 'object',
                    'context'     => [ 'view', 'edit' ],
                    'properties'  => [
                        'additionalProperties' => [
                            'type'       => 'object',
                            'properties' => $menu_item_properties,
                        ],
                    ],
                ],
            ],
        ];

        return $schema;
    }
}
