<?php

namespace WeDevs\DokanPro;

use WeDevs\DokanPro\Admin\ShortcodesButton;

class BlockEditorBlockTypes {

    /**
     * Class constructor
     *
     * @since 2.9.16
     *
     * @return void
     */
    public function __construct() {
        add_filter( 'block_categories_all', [ $this, 'add_block_category' ], 10, 2 );
        add_action( 'admin_enqueue_scripts', [ $this, 'register_scripts' ], 9 );
        add_action( 'init', [ $this, 'register_block_types' ] );
    }

    /**
     * Add Dokan Block category
     *
     * @since 2.9.16
     *
     * @param array $block_categories
     * @param mixed $block_editor_context
     *
     * @return array
     */
    public function add_block_category( $block_categories, $block_editor_context ) {
        // Guards against non-core callers that pass something other than an editor context.
        if ( ! ( $block_editor_context instanceof \WP_Block_Editor_Context ) ) {
            return $block_categories;
        }

        return array_merge(
            $block_categories,
            [
                [
                    'slug'  => 'dokan',
                    'title' => __( 'Dokan', 'dokan' ),
                    'icon'  => 'wordpress',
                ],
			]
        );
    }

    /**
     * Register block scripts
     *
     * @since 2.9.16
     *
     * @return void
     */
    public function register_scripts() {
        list( $suffix, $version ) = dokan_get_script_suffix_and_version();

        // The block is registered for every post type, so its script has to be available on every editor screen too.
        wp_register_script(
            'dokan-blocks-editor-script',
            DOKAN_PRO_PLUGIN_ASSEST . '/js/dokan-blocks-editor-script' . $suffix . '.js',
            [ 'wp-blocks', 'wp-block-editor', 'wp-i18n', 'wp-element', 'wp-components' ],
            $version,
            true
        );

        // The block's edit view reads this global, so it has to travel with the block's own handle.
        wp_localize_script( 'dokan-blocks-editor-script', 'dokan_shortcodes', ShortcodesButton::get_shortcodes() );
    }

    /**
     * Register block types
     *
     * @since 2.9.16
     *
     * @return void
     */
    public function register_block_types() {
        $args = [
            'api_version'     => 3,
            'editor_script'   => 'dokan-blocks-editor-script',
            'render_callback' => [ $this, 'render_shortcode' ],
        ];

        // Core documents `api_version` as a string, but WP_Block_Type::$api_version and the REST schema are integers.
        register_block_type( 'dokan/shortcode', $args ); // @phpstan-ignore argument.type
    }

    /**
     * Render shortcode block content
     *
     * @since 2.9.16
     *
     * @param array  $attributes
     * @param string $content
     *
     * @return string
     */
    public function render_shortcode( $attributes, $content ) {
        if ( ! empty( $content ) ) {
            return wpautop( trim( $content ) );
        }

        return '';
    }
}
