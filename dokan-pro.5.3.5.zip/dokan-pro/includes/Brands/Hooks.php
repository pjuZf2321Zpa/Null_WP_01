<?php

namespace WeDevs\DokanPro\Brands;

/**
 * Class responsible for managing hooks for product brands
 */
class Hooks {

    public function __construct() {
        // REST API: filter products by product_brand taxonomy in React vendor dashboard.
        add_filter( 'dokan_rest_pre_product_listing_args', [ $this, 'filter_products_by_brand_for_api' ], 10, 2 );
    }

    /**
     * Add product_brand taxonomy filter to the REST API product listing args.
     *
     * @since 5.0.0
     *
     * @param array           $args    WP_Query args.
     * @param WP_REST_Request $request REST request.
     *
     * @return array
     */
    public function filter_products_by_brand_for_api( array $args, $request ): array {
        $brand_id = absint( $request->get_param( 'product_brand' ) );

        if ( ! $brand_id ) {
            return $args;
        }

        $args['tax_query'][] = [
            'taxonomy'         => 'product_brand',
            'field'            => 'term_id',
            'terms'            => $brand_id,
            'include_children' => false,
        ];

        return $args;
    }
}
