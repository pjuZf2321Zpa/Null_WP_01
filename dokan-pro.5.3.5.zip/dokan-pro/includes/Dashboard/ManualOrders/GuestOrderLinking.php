<?php

namespace WeDevs\DokanPro\Dashboard\ManualOrders;

use WC_Data_Store;
use WC_Order;
use WP_User;

/**
 * Class GuestOrderLinking
 *
 * Keeps a vendor's guest manual order from becoming a vendor–customer relationship when WooCommerce links past guest orders to an account.
 *
 * @since 5.3.5
 */
class GuestOrderLinking {

    /**
     * Constructor.
     *
     * Loaded for every request, since customers verify their email (or reset their password) while logged out.
     */
    public function __construct() {
        add_action( 'woocommerce_update_new_customer_past_order', [ $this, 'keep_vendor_guest_order' ], 10, 2 );
    }

    /**
     * Undo the link when a vendor-created guest order would be the vendor's only order from this customer.
     *
     * @since 5.3.5
     *
     * @param int     $order_id Order ID WooCommerce just linked.
     * @param WP_User $customer Customer the order was linked to.
     *
     * @return void
     */
    public function keep_vendor_guest_order( $order_id, $customer ): void {
        $order = wc_get_order( $order_id );
        if ( ! $order instanceof WC_Order || ! $customer instanceof WP_User ) {
            return;
        }

        // An admin linking past orders from the customer report is a deliberate choice; the customer-side triggers never carry this capability.
        if ( current_user_can( 'manage_woocommerce' ) ) {
            return;
        }

        $vendor_id = absint( $order->get_meta( '_dokan_vendor_id', true ) );
        if ( ! $vendor_id || ! $this->is_created_by_vendor( $order ) ) {
            return;
        }

        $other_orders = dokan()->order->all(
            [
                'seller_id'   => $vendor_id,
                'customer_id' => $customer->ID,
                'exclude'     => [ $order->get_id() ],
                'return'      => 'count',
                'limit'       => 1,
            ]
        );

        // The vendor already sold to this customer, so the link grants nothing new.
        if ( $other_orders > 0 || $this->has_unlinked_guest_checkout( $order, $vendor_id, $customer ) ) {
            return;
        }

        $order->set_customer_id( 0 );
        $order->save();

        // WooCommerce granted the account the order's downloads while linking; tie them back to the guest order.
        if ( $order->has_downloadable_item() ) {
            WC_Data_Store::load( 'customer-download' )->delete_by_order_id( $order->get_id() ); // @phpstan-ignore method.notFound (WC_Data_Store forwards to the loaded store via __call.)
            wc_downloadable_product_permissions( $order->get_id(), true );
        }
    }

    /**
     * Whether the vendor has a real (non-manual) guest order with this email that WooCommerce hasn't linked yet in the same pass.
     *
     * @since 5.3.5
     *
     * @param WC_Order $order     Manual order being linked.
     * @param int      $vendor_id Vendor ID.
     * @param WP_User  $customer  Customer the order was linked to.
     *
     * @return bool
     */
    protected function has_unlinked_guest_checkout( WC_Order $order, int $vendor_id, WP_User $customer ): bool {
        // WooCommerce links matching guest orders one by one, so the result must not depend on which comes first.
        $guest_orders = wc_get_orders(
            [
                'limit'    => -1,
                'customer' => [ [ 0, $customer->user_email ] ],
                'exclude'  => [ $order->get_id() ],
            ]
        );

        foreach ( $guest_orders as $guest_order ) {
            if ( $guest_order instanceof WC_Order && absint( $guest_order->get_meta( '_dokan_vendor_id', true ) ) === $vendor_id && ! $this->is_created_by_vendor( $guest_order ) ) {
                return true;
            }
        }

        return false;
    }

    /**
     * Whether the order was created by a vendor through manual orders.
     *
     * @since 5.3.5
     *
     * @param WC_Order $order Order.
     *
     * @return bool
     */
    protected function is_created_by_vendor( WC_Order $order ): bool {
        // created_via covers older manual orders whose attribution stamp was skipped by a forged _dokan_vendor_id.
        return 'dokan-rest-api' === $order->get_created_via() || 'vendor' === strtolower( (string) $order->get_meta( '_wc_order_attribution_source_type', true ) );
    }
}
