<?php

namespace WeDevs\DokanPro\Dashboard;

use WeDevs\DokanPro\MenuManager\AccessRestriction;

/**
 * Profile Progressbar Class.
 *
 * @since 3.7.13
 *
 * @author weDevs <info@wedevs.com>
 */
class ProfileProgress {

    /**
     * Prefix of the transient that hides the progressbar / completion card for a day.
     *
     * Shared with the legacy admin-ajax dismiss handler.
     *
     * @since 5.3.2
     */
    const DISMISS_TRANSIENT_PREFIX = 'dokan_dashboard_closed_progressbar_';

    /**
     * SPA routes that carry the card, mirroring where the legacy bar renders.
     *
     * The shell prints one mount node for every route, so the card filters client-side.
     * Payment is absent because it has no React page.
     *
     * @since 5.3.2
     */
    const SPA_ROUTES = [ '/', 'settings/store', 'settings/social' ];

    /**
     * Get the SPA routes the card renders on.
     *
     * @since 5.3.2
     *
     * @return array
     */
    public static function get_spa_routes() {
        /**
         * Filters the SPA routes the profile-completion card renders on.
         *
         * A module shipping a new React settings page opts in here — `settings/payment`
         * once one exists, for instance.
         *
         * @since 5.3.2
         *
         * @param array $routes Route slugs, without the leading `#`.
         */
        return (array) apply_filters( 'dokan_profile_completion_spa_routes', self::SPA_ROUTES );
    }

    /**
     * Memoized payment markers, so the filter runs once per instance.
     *
     * @since 5.3.2
     *
     * @var array|null
     */
    protected $payment_markers = null;

    /**
     * Get the 24h dismiss transient key for a user.
     *
     * Same key the legacy bar has always used, so both UIs share one hide state.
     *
     * @since 5.3.2
     *
     * @param int $user_id
     *
     * @return string
     */
    public static function get_dismiss_transient_key( $user_id ) {
        return self::DISMISS_TRANSIENT_PREFIX . $user_id;
    }

    /**
     * Hide the progressbar / completion card for 24 hours.
     *
     * @since 5.3.2
     *
     * @param int $user_id
     *
     * @return void
     */
    public function dismiss_for_a_day( $user_id ) {
        set_transient( self::get_dismiss_transient_key( $user_id ), true, DAY_IN_SECONDS );
    }

    /**
     * Permanently close the progressbar / completion card once setup is complete.
     *
     * @since 5.3.2
     *
     * @param int $user_id
     *
     * @return bool Whether the card was closed.
     */
    public function close_permanently( $user_id ) {
        $settings = get_user_meta( $user_id, 'dokan_profile_settings', true );
        $settings = is_array( $settings ) ? $settings : [];

        $profile_completion = $this->extract_profile_completion( $settings );

        if ( ! $this->is_setup_complete( $profile_completion ) ) {
            return false;
        }

        // Remember which steps "Done" covered — see stays_closed().
        $settings['profile_completion']['closed_by_user'] = true;
        $settings['profile_completion']['closed_steps']   = array_column( $this->get_steps( $profile_completion ), 'key' );
        update_user_meta( $user_id, 'dokan_profile_settings', $settings );

        return true;
    }

    /**
     * Whether a card the vendor closed with "Done" stays closed.
     *
     * Only the steps "Done" covered count: a step the admin switches on later is new work, not a
     * regression. A card closed before the snapshot existed reopens by every available step.
     * See docs/adr/0015-profile-completion-follows-the-dashboard-menu-manager.md.
     *
     * @since 5.3.4
     *
     * @param array $profile_completion The `profile_completion` sub-array of `dokan_profile_settings`.
     *
     * @return bool
     */
    public function stays_closed( array $profile_completion ) {
        $covered = $profile_completion['closed_steps'] ?? null;

        return $this->steps_complete( $profile_completion, is_array( $covered ) ? $covered : null );
    }

    /**
     * Record that this vendor has seen the completion celebration.
     *
     * Kept on the vendor's own `profile_completion` rather than in the browser: the
     * celebration is the vendor's, so it must not be spent by whoever else signs in on the
     * same machine, nor replay when they move to another one.
     *
     * @since 5.3.2
     *
     * @param int $user_id
     *
     * @return void
     */
    public function mark_celebrated( $user_id ) {
        $settings = get_user_meta( $user_id, 'dokan_profile_settings', true );
        $settings = is_array( $settings ) ? $settings : [];

        if ( ! empty( $settings['profile_completion']['celebrated'] ) ) {
            return;
        }

        $settings['profile_completion']['celebrated'] = true;
        update_user_meta( $user_id, 'dokan_profile_settings', $settings );
    }

    /**
     * Whether store setup counts as finished, i.e. "Done" may permanently close the card.
     *
     * The card's steps deliberately leave out the map location and three of the four social
     * networks, which still carry weight (see the grouping in `get_steps()`). A vendor with
     * every step done therefore tops out at 79% — 94% with no Maps API key — so gating this
     * on `progress >= 100` like the legacy bar did would reject every "Done" click the card
     * can produce. The card's own completion signal is the authority; a 100% profile still
     * qualifies, which keeps vendors whose steps were reshaped by
     * `dokan_profile_completion_steps` working. Only the steps the vendor can reach count:
     * a settings page switched off in the Menu Manager is not a step (see `get_steps()`).
     *
     * @since 5.3.2
     *
     * @param array $profile_completion The `profile_completion` sub-array of `dokan_profile_settings`.
     *
     * @return bool
     */
    public function is_setup_complete( array $profile_completion ) {
        return $this->steps_complete( $profile_completion );
    }

    /**
     * Whether the steps — or only the given ones — are all complete. A 100% profile always is.
     *
     * @since 5.3.4
     *
     * @param array      $profile_completion The `profile_completion` sub-array of `dokan_profile_settings`.
     * @param array|null $only_keys          Step keys to check; null means every available step.
     *
     * @return bool
     */
    protected function steps_complete( array $profile_completion, ?array $only_keys = null ) {
        if ( absint( $profile_completion['progress'] ?? 0 ) >= 100 ) {
            return true;
        }

        $steps = $this->get_steps( $profile_completion );

        // Nothing to do is not "done" — unless "Done" was clicked and none of its steps is left to regress.
        if ( null === $only_keys && empty( $steps ) ) {
            return false;
        }

        foreach ( $steps as $step ) {
            if ( null !== $only_keys && ! in_array( $step['key'], $only_keys, true ) ) {
                continue;
            }

            if ( empty( $step['completed'] ) ) {
                return false;
            }
        }

        return true;
    }

    /**
     * Pull the `profile_completion` sub-array out of a `dokan_profile_settings` value.
     *
     * @since 5.3.2
     *
     * @param array $settings
     *
     * @return array
     */
    protected function extract_profile_completion( array $settings ) {
        return isset( $settings['profile_completion'] ) && is_array( $settings['profile_completion'] )
            ? $settings['profile_completion']
            : [];
    }

    /**
     * Print the mount node the React completion card renders into.
     *
     * The `.dokan-layout` wrapper supplies the Tailwind scope.
     *
     * @since 5.3.2
     *
     * @param bool $in_spa Whether this is the SPA shell, whose single node serves every route.
     *
     * @return void
     */
    public static function render_mount_point( $in_spa = false ) {
        // "Hide for 24 hrs" is the signed-in person's own; "Done" is the vendor's profile state.
        if ( get_transient( self::get_dismiss_transient_key( get_current_user_id() ) ) ) {
            return;
        }

        if ( ( new self() )->is_permanently_closed( dokan_get_current_user_id() ) ) {
            return;
        }

        // Enqueued here so the script ships exactly where the node prints; the handle loads in the footer.
        wp_enqueue_script( 'dokan-pro-profile-completion' );
        wp_set_script_translations( 'dokan-pro-profile-completion', 'dokan' );

        $routes = $in_spa ? sprintf( ' data-spa-routes="%s"', esc_attr( implode( ',', self::get_spa_routes() ) ) ) : '';

        /**
         * Fires before the profile-completion card's mount node is printed.
         *
         * @since 5.3.2
         *
         * @param bool $in_spa Whether this is the SPA shell.
         */
        do_action( 'dokan_profile_completion_before_mount_point', $in_spa );

        echo '<div class="dokan-layout"><div id="dokan-profile-completion-root"' . $routes . '></div></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    }

    /**
     * Get profile progressbar data.
     *
     * @since 3.7.13
     * @since 5.3.2 Added the `$with_steps` flag, plus `steps`, `completed_steps`,
     *                        `total_steps`, `store_name` and `dismissed` payload keys.
     *
     * @param bool $new_dashboard
     * @param bool $with_steps Whether to build the grouped checklist steps. Only the
     *                         completion-card REST endpoint needs them; the legacy bar
     *                         must not pay the dashboard-nav resolution they require.
     *
     * @return array
     */
    public function get( $new_dashboard = false, $with_steps = false ) {
        $data = [
            'progress'           => 0,
            'next_todo'          => '',
            'next_todo_slug'     => $new_dashboard ? 'settings' : 'settings/store',
            // translators: %s: URL to the store banner setting.
            'next_progress_text' => sprintf( __( 'Start with <a href="%s">adding a Banner</a> to gain profile progress', 'dokan' ), untrailingslashit( dokan_get_navigation_url( 'settings/store#dokan-banner-wrapper' ) ) ),
            'progress_vals'      => 15,
            'progresses'         => [],
            'closed_by_user'     => false,
            'steps'              => [],
            'completed_steps'    => 0,
            'total_steps'        => 0,
            'store_name'         => '',
            'dismissed'          => false,
            'celebrated'         => false,
        ];

        $profile_info          = dokan_get_store_info( dokan_get_current_user_id() );
        $data['celebrated']    = ! empty( $profile_info['profile_completion']['celebrated'] );
        $data['store_name']    = isset( $profile_info['store_name'] ) ? (string) $profile_info['store_name'] : '';
        $data['dismissed']     = (bool) get_transient( self::get_dismiss_transient_key( get_current_user_id() ) );
        $data['progress']      = isset( $profile_info['profile_completion']['progress'] ) ? $profile_info['profile_completion']['progress'] : 0;
        $data['next_todo']     = isset( $profile_info['profile_completion']['next_todo'] ) ? $profile_info['profile_completion']['next_todo'] : '';
        $data['progress_vals'] = isset( $profile_info['profile_completion']['progress_vals'] ) ? $profile_info['profile_completion']['progress_vals'] : 0;
        $data['progress']      = $data['progress'] > 100 ? 100 : $data['progress'];

        $is_closed_by_user      = isset( $profile_info['profile_completion']['closed_by_user'] ) ? $profile_info['profile_completion']['closed_by_user'] : false;
        $data['closed_by_user'] = $is_closed_by_user;

        $profile_completion = $this->extract_profile_completion( $profile_info );

        if ( $with_steps ) {
            $data['steps']           = $this->get_steps( $profile_completion );
            $data['completed_steps'] = count( array_filter( array_column( $data['steps'], 'completed' ) ) );
            $data['total_steps']     = count( $data['steps'] );
        }

        // Both UIs close through close_permanently(), so both reopen by stays_closed().
        if ( $is_closed_by_user && $this->stays_closed( $profile_completion ) ) {
            return $data;
        }

        if ( $is_closed_by_user ) {
            $profile_info['profile_completion']['closed_by_user'] = false;
            // Back to the profile it was read from — writing to the signed-in id would copy
            // the whole vendor profile onto a staff account.
            update_user_meta( dokan_get_current_user_id(), 'dokan_profile_settings', $profile_info );

            // The card renders off this flag, so it reopens now; the bar keeps its one-load lag.
            if ( $with_steps ) {
                $data['closed_by_user'] = false;
            }
        }

        if ( strpos( $data['next_todo'], '-' ) !== false ) {
            $data['next_todo']     = substr( $data['next_todo'], strpos( $data['next_todo'], '-' ) + 1 );
            $data['progress_vals'] = isset( $profile_info['profile_completion']['progress_vals'] ) ? $profile_info['profile_completion']['progress_vals'] : 0;
            $data['progress_vals'] = isset( $data['progress_vals']['social_val'][ $data['next_todo'] ] ) ? $data['progress_vals']['social_val'][ $data['next_todo'] ] : 0;
        } else {
            $data['progress_vals'] = isset( $data['progress_vals'][ $data['next_todo'] ] ) ? $data['progress_vals'][ $data['next_todo'] ] : 15;
        }

        $data['progresses'] = $this->get_progresses_with_completions( $profile_info );
        $data               = $this->restrict_legacy_progress( $data );

        $progress_info = $this->get_progress_info_by_key( $data['next_todo'] );

        if ( 100 === absint( $data['progress'] ) ) {
            $data['next_progress_text'] = __( 'Congratulation, your profile is fully completed', 'dokan' );
        } else {
            $data['next_progress_text'] = sprintf(
                // translators: 1) Next progress bar title 2) Next progress bar value
                __( 'Add %1$s to gain %2$s%% progress', 'dokan' ),
                $progress_info['title'],
                number_format_i18n( $data['progress_vals'] )
            );
        }

        $data['next_todo_slug'] = $progress_info['slug'];

        if ( ! $new_dashboard ) {
            $data['next_todo_slug'] = dokan_get_navigation_url( $data['next_todo_slug'] );
        }

        return $data;
    }

    /**
     * Get the grouped profile-completion steps for the checklist card.
     *
     * These four groups are a presentation layer over the existing granular
     * `profile_completion` markers — there is no data-structure change. Each group reads the
     * markers that are actually stored (e.g. `gravatar`, `location`, `Bank`/`bank`), so
     * completion is detected correctly regardless of the legacy weight keys used elsewhere.
     *
     * @since 5.3.2
     * @since 5.3.4 Steps carry `menu` and follow the Menu Manager — see reachable().
     *
     * @param array $profile_completion The `profile_completion` sub-array of `dokan_profile_settings`.
     *
     * @return array
     */
    public function get_steps( array $profile_completion ) {
        $has = function ( ...$keys ) use ( $profile_completion ) {
            return $this->has_any_marker( $profile_completion, $keys );
        };

        $store_settings_url = $this->get_step_url( 'settings/store' );

        // Phone lives on the General tab and the address on Location — open whichever is missing.
        $store_information_url = $this->with_settings_tab(
            $store_settings_url,
            $has( 'phone' ) ? 'tab_location' : 'tab_general'
        );

        $payment_markers = $this->get_payment_markers();

        $steps = [
            [
                'key'          => 'store_assets',
                'menu'         => 'store',
                'title'        => __( 'Upload Store Logo and Banner', 'dokan' ),
                'description'  => __( "These build your customer's trust layer", 'dokan' ),
                'action_label' => __( 'Upload', 'dokan' ),
                'done_label'   => __( 'Uploaded', 'dokan' ),
                // Name the tab: from another Store tab the bare URL equals the current hash, so the click does nothing.
                'url'          => $this->with_settings_tab( $store_settings_url, 'tab_general' ),
                'completed'    => $has( 'banner' ) && $has( 'gravatar' ),
            ],
            [
                'key'          => 'store_information',
                'menu'         => 'store',
                'title'        => __( 'Store Information', 'dokan' ),
                'description'  => __( 'Add phone and Address to your store', 'dokan' ),
                'action_label' => __( 'Add', 'dokan' ),
                'done_label'   => __( 'Added', 'dokan' ),
                'url'          => $store_information_url,
                'completed'    => $has( 'phone' ) && $has( 'address' ),
            ],
            [
                'key'          => 'payment_method',
                'menu'         => 'payment',
                'title'        => __( 'Payment Method', 'dokan' ),
                'description'  => __( 'Any payment method for ease receipt from admin and customer.', 'dokan' ),
                'action_label' => __( 'Add Payment', 'dokan' ),
                'done_label'   => __( 'Added Payment', 'dokan' ),
                'url'          => $this->get_step_url( 'settings/payment' ),
                'completed'    => $has( ...$payment_markers ),
            ],
            [
                'key'          => 'social_profile',
                'menu'         => 'social',
                'title'        => __( 'Social profile', 'dokan' ),
                'description'  => __( 'Add any social profile to complete.', 'dokan' ),
                'action_label' => __( 'Add Social Links', 'dokan' ),
                'done_label'   => __( 'Added Social Links', 'dokan' ),
                // Social has a React page only — no legacy form to fall back to.
                'url'          => dokan_get_navigation_url( 'settings/social', true ),
                'completed'    => $has( 'fb', 'twitter', 'youtube', 'linkedin' ),
            ],
        ];

        /**
         * Filters the grouped profile-completion steps shown in the checklist card.
         *
         * A step carrying a `menu` key (its settings submenu slug, e.g. `social`) is dropped
         * when the admin switched that submenu off in the Menu Manager.
         *
         * @since 5.3.2
         * @since 5.3.4 Steps carry a `menu` key.
         *
         * @param array $steps
         * @param array $profile_completion
         */
        $steps = apply_filters( 'dokan_profile_completion_steps', $steps, $profile_completion );

        // Filtered after the hook so a third-party step on a switched-off page is dropped too.
        return $this->reachable( is_array( $steps ) ? $steps : [] );
    }

    /**
     * Drop the rows whose settings submenu (`menu`) the admin switched off in the Menu Manager.
     *
     * Rows without a `menu` are kept — there is nothing to switch off.
     *
     * @since 5.3.4
     *
     * @param array $rows Checklist steps or legacy weight rows.
     *
     * @return array
     */
    protected function reachable( array $rows ) {
        $restricted = AccessRestriction::get_restricted_keys();

        return array_values(
            array_filter(
                $rows,
                static function ( $row ) use ( $restricted ) {
                    return empty( $row['menu'] ) || ! in_array( $row['menu'], $restricted, true );
                }
            )
        );
    }

    /**
     * Whether any of the given markers is present in the completion data.
     *
     * @since 5.3.2
     *
     * @param array $profile_completion
     * @param array $keys
     *
     * @return bool
     */
    protected function has_any_marker( array $profile_completion, array $keys ) {
        foreach ( $keys as $key ) {
            if ( ! empty( $profile_completion[ $key ] ) ) {
                return true;
            }
        }

        return false;
    }

    /**
     * Whether the vendor permanently closed the card / progressbar.
     *
     * A closed card comes back if the profile regressed since — matching the legacy bar,
     * which reopened itself through the reset in `get()`. Both PHP mounts short-circuit on
     * this before `get()` ever runs, so the reopen has to be decided here too.
     *
     * @since 5.3.2
     * @since 5.3.4 Reopens by `stays_closed()`, so a step switched on later does not reopen it.
     *
     * @param int $user_id
     *
     * @return bool
     */
    public function is_permanently_closed( $user_id ) {
        $profile_info = dokan_get_store_info( $user_id );

        if ( empty( $profile_info['profile_completion']['closed_by_user'] ) ) {
            return false;
        }

        return $this->stays_closed( $this->extract_profile_completion( $profile_info ) );
    }

    /**
     * Get the marker keys that count the payment step as complete.
     *
     * The setup wizard stores lowercase `bank` while a settings save stores `Bank`;
     * payment-gateway modules add their own ids (e.g. `dokan_razorpay`). Any present
     * marker completes the step.
     *
     * @since 5.3.2
     *
     * @return array
     */
    protected function get_payment_markers() {
        if ( null !== $this->payment_markers ) {
            return $this->payment_markers;
        }

        /**
         * Filters the markers that mark the "Payment Method" step complete.
         *
         * @since 5.3.2
         *
         * @param array $payment_markers
         */
        $this->payment_markers = (array) apply_filters(
            'dokan_profile_completion_payment_markers',
            [
                'Bank',
                'bank',
                'paypal',
                'skrill',
                'stripe',
                'dokan_stripe_express',
                'dokan_custom',
                'dokan_razorpay',
                'dokan_mangopay',
                'dokan_paypal_marketplace',
            ]
        );

        return $this->payment_markers;
    }

    /**
     * Resolve the destination URL for a checklist step.
     *
     * The card only renders inside the React dashboard, whose settings routes are
     * registered unconditionally, so its steps stay in the SPA. Payment is the exception:
     * it has no React page yet, so that step leaves for the legacy form.
     *
     * @since 5.3.2
     *
     * @param string $route Route slug shared by the legacy page and the React nav route.
     *
     * @return string
     */
    protected function get_step_url( $route ) {
        return dokan_get_navigation_url( $route, 'settings/payment' !== $route );
    }

    /**
     * Point a step URL at a specific tab of the React settings page.
     *
     * The page reads the tab from the route's query (`#settings/store?tab=…`) and
     * activates it, whether it is already open or loading fresh. Legacy URLs have
     * no tabs, so they are returned untouched.
     *
     * @since 5.3.2
     *
     * @param string $url Step URL.
     * @param string $tab Tab id, e.g. `tab_location`.
     *
     * @return string
     */
    protected function with_settings_tab( $url, $tab ) {
        $hash_at = strpos( $url, '#' );

        if ( false === $hash_at ) {
            return $url;
        }

        // Only the fragment's own query counts — a plain-permalink dashboard URL
        // (`?page_id=…#settings/store/`) already carries a `?` before the `#`.
        $separator = strpos( $url, '?', $hash_at ) === false ? '?' : '&';

        return $url . $separator . 'tab=' . rawurlencode( $tab );
    }

    /**
     * Process progress info data by key value.
     *
     * This will modify the $data array and
     * add next step message, URL slug etc.
     *
     * @since 3.7.13
     * @since 5.3.4 Carries the stored key (`todo`) and the settings submenu the row lives on (`menu`).
     *
     * @param string $key_value
     *
     * @return array $data
     */
    protected function get_progress_info_by_key( $key_value ) {
        $info = [
            'key'   => str_replace( '_val', '', $key_value ), // Remove _val from key_value
            'todo'  => $key_value,
            'title' => '',
            'slug'  => 'settings/store',
            'menu'  => 'store',
        ];

        switch ( $key_value ) {
            case 'profile_picture_val':
                $info['title'] = __( 'Profile Picture', 'dokan' );
                break;

            case 'phone_val':
                $info['title'] = __( 'Phone', 'dokan' );
                break;

            case 'banner_val':
                $info['title'] = __( 'Banner', 'dokan' );
                break;

            case 'store_name_val':
                $info['title'] = __( 'Store Name', 'dokan' );
                break;

            case 'address_val':
                $info['title'] = __( 'Address', 'dokan' );
                break;

            case 'payment_method_val':
                $info['title'] = __( 'A Payment method', 'dokan' );
                $info['slug']  = 'settings/payment';
                $info['menu']  = 'payment';
                break;

            case 'map_val':
                $info['title'] = __( 'Map location', 'dokan' );
                break;

            case 'fb':
                $info['title'] = __( 'Facebook', 'dokan' );
                $info['menu']  = 'social';
                break;

            case 'twitter':
                $info['title'] = __( 'X', 'dokan' );
                $info['menu']  = 'social';
                break;

            case 'youtube':
                $info['title'] = __( 'Youtube', 'dokan' );
                $info['menu']  = 'social';
                break;

            case 'linkedin':
                $info['title'] = __( 'LinkedIn', 'dokan' );
                $info['menu']  = 'social';
                break;

            default:
                break;
        }

        return $info;
    }

    /**
     * Rescale the legacy bar to the settings pages the vendor can reach.
     *
     * The stored `progress` / `next_todo` keep every weight, so a switched-off page would keep
     * the bar below 100% and keep being asked for. Applied at read time, like the card's steps;
     * with nothing switched off the stored values pass through untouched.
     * See docs/adr/0015-profile-completion-follows-the-dashboard-menu-manager.md.
     *
     * @since 5.3.4
     *
     * @param array $data The payload being built by get(), with `progresses` filled.
     *
     * @return array
     */
    protected function restrict_legacy_progress( array $data ) {
        $available = $this->reachable( $data['progresses'] );

        if ( count( $available ) === count( $data['progresses'] ) ) {
            return $data;
        }

        $data['progresses'] = $available;
        $total              = array_sum( array_column( $available, 'value' ) );

        if ( $total <= 0 ) {
            return $data;
        }

        $earned = 0;
        $next   = null;

        foreach ( $available as $progress ) {
            if ( $progress['completed'] ) {
                $earned += $progress['value'];
            } elseif ( null === $next ) {
                $next = $progress;
            }
        }

        $data['progress'] = (int) round( $earned / $total * 100 );

        if ( null === $next ) {
            return $data;
        }

        $data['next_todo']     = $next['todo'];
        $data['progress_vals'] = (int) round( $next['value'] / $total * 100 );

        return $data;
    }

    /**
     * Get Progress lists of a vendor profile with completed or not status.
     *
     * @since 3.7.13
     * @since 5.3.2 Completion is read from the markers actually stored in
     *                        `profile_completion` — the weight keys `profile_picture`,
     *                        `map` and `payment_method` are saved as `gravatar`,
     *                        `location` and a gateway id, so checking them literally
     *                        always reported those rows as incomplete.
     * @since 5.3.4 Rows carry `todo` and `menu` from get_progress_info_by_key().
     *
     * @param array $profile_info
     *
     * @return array
     */
    protected function get_progresses_with_completions( $profile_info ) {
        $profile_completions = isset( $profile_info['profile_completion'] ) ? $profile_info['profile_completion'] : [];

        if ( ! count( $profile_completions ) ) {
            return [];
        }

        $marker_map = [
            'profile_picture' => [ 'gravatar' ],
            'map'             => [ 'location' ],
            'payment_method'  => $this->get_payment_markers(),
        ];

        $progress_values = isset( $profile_completions['progress_vals'] ) ? $profile_completions['progress_vals'] : [];
        $progresses      = [];

        foreach ( $progress_values as $key => $progress_value ) {
            $progress = $this->get_progress_info_by_key( $key );

            if ( 'social_val' === $key ) {
                foreach ( $progress_value as $social_key => $social_value ) {
                    $social_progress              = $this->get_progress_info_by_key( $social_key );
                    $social_progress['value']     = $social_value;
                    $social_progress['completed'] = empty( $profile_completions[ $social_key ] ) ? 0 : 1;

                    $progresses[] = $social_progress;
                }
            } else {
                $markers = isset( $marker_map[ $progress['key'] ] ) ? $marker_map[ $progress['key'] ] : [ $progress['key'] ];

                $progress['value']     = $progress_value;
                $progress['completed'] = $this->has_any_marker( $profile_completions, $markers ) ? 1 : 0;

                $progresses[] = $progress;
            }
        }

        return $progresses;
    }
}
