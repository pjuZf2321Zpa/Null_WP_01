<?php

namespace WeDevs\DokanPro\Dashboard;

use WeDevs\Dokan\Cache;
use WeDevs\Dokan\Dashboard\Templates\Dashboard as DokanDashboard;
use WeDevs\Dokan\Utilities\ReportUtil;

/**
 * Dashboard Template Class.
 *
 * A template for frontend dashboard rendering items
 *
 * @since 2.4
 *
 * @author weDevs <info@wedevs.com>
 */
class Dashboard extends DokanDashboard {

    /**
     * Constructor for the WeDevs_Dokan class
     *
     * Sets up all the appropriate hooks and actions
     * within our plugin.
     *
     * @uses add_action()
     */
    public function __construct() {
        $this->user_id = dokan_get_current_user_id();

        // Whichever UI the dashboard home is showing gets its own progress UI; each bails on the other's.
        add_action( 'dokan_dashboard_before_widgets', array( $this, 'show_profile_progressbar' ) );
        add_action( 'dokan_dashboard_before_widgets', array( $this, 'render_profile_completion_card' ), 11 );

        if ( ! ( class_exists( ReportUtil::class ) && ReportUtil::is_analytics_enabled() ) ) {
            add_action( 'dokan_dashboard_left_widgets', array( $this, 'get_review_widget' ), 16 );
            add_action( 'dokan_dashboard_right_widgets', array( $this, 'get_announcement_widget' ), 12 );
        }
    }

    /**
     * Render the React mount node for the profile-completion card.
     *
     * Only for a React dashboard home — the analytics/reports panel or the SPA shell.
     * Skipped entirely while the card is hidden — the 24h dismiss transient or the
     * permanent "Done" flag — so no empty wrapper is left in the page flow.
     *
     * @since 5.3.2
     *
     * @return void
     */
    public function render_profile_completion_card() {
        if ( ! $this->dashboard_renders_react() ) {
            return;
        }

        if ( current_user_can( 'dokan_view_overview_menu' ) ) {
            ProfileProgress::render_mount_point( $this->is_react_dashboard() );
        }
    }

    /**
     * Show Profile progressbar.
     *
     * @since 2.4
     * @since 5.3.2 Limited to the plain dashboard home, i.e. WooCommerce Analytics off.
     *                    A React home renders the profile-completion card instead.
     *
     * @return void
     */
    public function show_profile_progressbar() {
        if ( $this->dashboard_renders_react() ) {
            return;
        }

        if ( get_transient( ProfileProgress::get_dismiss_transient_key( get_current_user_id() ) ) ) {
            return;
        }

        if ( current_user_can( 'dokan_view_overview_menu' ) ) {
            echo dokan_get_profile_progressbar();
        }
    }

    /**
     * Whether this dashboard home is a React one.
     *
     * The SPA shell always is; the classic home is once WooCommerce Analytics replaces its
     * widgets with the reports panel.
     *
     * @since 5.3.2
     *
     * @return bool
     */
    protected function dashboard_renders_react() {
        $is_react = $this->is_react_dashboard() || ( class_exists( ReportUtil::class ) && ReportUtil::is_analytics_enabled() );

        /**
         * Filters whether the dashboard home shows the profile-completion card or the legacy bar.
         *
         * @since 5.3.2
         *
         * @param bool $is_react True renders the card, false the striped progress bar.
         */
        return (bool) apply_filters( 'dokan_profile_completion_render_card_on_dashboard', $is_react );
    }

    /**
     * Whether the current request is the React dashboard (SPA) shell.
     *
     * @since 5.3.2
     *
     * @return bool
     */
    protected function is_react_dashboard() {
        global $wp;

        return isset( $wp->query_vars['new'] );
    }

    /**
     * Get Review Widget
     *
     * @return void
     */
    public function get_review_widget() {
        if ( ! apply_filters( 'dokan_dashboard_widget_applicable', true, 'reviews' ) ) {
            return;
        }

        if ( ! current_user_can( 'dokan_view_overview_menu' ) ) {
            return;
        }

        if ( ! current_user_can( 'dokan_view_review_reports' ) ) {
            return;
        }

        // Check if product review is disabled from WooCommerce's setting.
        if ( 'yes' !== get_option( 'woocommerce_enable_reviews' ) ) {
            return;
        }

        dokan_get_template_part(
            'dashboard/review-widget', '', array(
				'pro'            => true,
				'comment_counts' => $this->get_comment_counts(),
				'reviews_url'    => dokan_get_navigation_url( 'reviews' ),
			)
        );
    }

    /**
     * Get announcement widget
     *
     * @return void
     */
    public function get_announcement_widget() {
        if ( ! apply_filters( 'dokan_dashboard_widget_applicable', true, 'announcement' ) ) {
            return;
        }

        if ( ! current_user_can( 'dokan_view_overview_menu' ) ) {
            return;
        }

        if ( ! current_user_can( 'dokan_view_announcement' ) ) {
            return;
        }

        $announcement = dokan_pro()->announcement->manager;
        $args         = [
            'per_page'  => apply_filters( 'dokan_dashboard_widget_announcement_list_number', 3 ),
            'vendor_id' => dokan_get_current_user_id(),
        ];
        $notices      = $announcement->all( $args );

        dokan_get_template_part(
            'dashboard/announcement-widget', '', array(
				'pro'              => true,
				'notices'          => $notices,
				'announcement_url' => dokan_get_navigation_url( 'announcement' ),
			)
        );
    }
}
