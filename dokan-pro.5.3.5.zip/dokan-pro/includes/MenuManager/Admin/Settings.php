<?php
namespace WeDevs\DokanPro\MenuManager\Admin;

defined( 'ABSPATH' ) || exit;

use WeDevs\DokanPro\MenuManager\Constants;

/**
 * Handles Menu manager admin settings configurations
 *
 * @since 3.10.0
 */
class Settings {

    /**
     * Initializes all hooks
     *
     * @since 3.10.0
     *
     * @return void
     */
    public function __construct() {
        add_filter( 'dokan_settings_sections', [ $this, 'add_menu_manager_section' ], 11 );
        add_filter( 'dokan_settings_fields', [ $this, 'add_menu_manager_section_fields' ], 99 );
    }

    /**
     * Adds menu manager section in dokan admin dashboard settings
     *
     * @since 3.10.0
     *
     * @param array $settings_sections
     *
     * @return array
     */
    public function add_menu_manager_section( array $settings_sections ): array {
        $menu_manager_section = [
            'id'                   => Constants::DOKAN_MENU_MANAGER,
            'title'                => __( 'Menu Manager', 'dokan' ),
            'icon_url'             => DOKAN_PRO_PLUGIN_ASSEST . '/images/admin-settings-icons/menu-manager.svg',
            'description'          => __( 'Vendor Dashboard Menu Appearance', 'dokan' ),
            'document_link'        => 'https://dokan.co/docs/wordpress/dokan-dashboard/vendor-dashboard-menu-manager/',
            'settings_title'       => __( 'Menu Manager Settings', 'dokan' ),
            'settings_description' => __( 'Reorder, Rename, Activate, and Deactivate menus for your vendor dashboard.', 'dokan' ),
        ];

        // Adding Menu Manager after Appearance Settings
        $new_settings = [];
        foreach ( $settings_sections as $value ) {
            $new_settings[] = $value;
            if ( Constants::APPEARANCE === $value['id'] ) {
                $new_settings[] = $menu_manager_section;
            }
        }

        return $new_settings;
    }

    /**
     * Adds Fields under menu manager settings fields
     *
     * @since 3.10.0
     *
     * @param array $settings_fields
     *
     * @return array
     */
    public function add_menu_manager_section_fields( array $settings_fields ): array {
        // Process and handle restricted menu data using the common method.
        $processed_menus = self::get_processed_menu_data();
        $processed_menus = self::apply_menu_restrictions( $processed_menus );

        // Get the left menu and settings submenu lists.
        $left_menu_list     = $processed_menus['left_menus'];
        $settings_menu_list = $processed_menus['settings_sub_menu'];

        $settings_fields[ Constants::DOKAN_MENU_MANAGER ] = [
            'menu_manager_menu_tab' => [
                'name'               => 'menu_manager_menu_tab',
                'type'               => 'sub_tab',
                'content_class'      => 'sub-tab-styles',
                'tabs'               => [
                    'left_menus'        => [
                        'name'     => 'left_menus',
                        'label'    => __( 'Left Menu', 'dokan' ),
                        'selected' => true,
                        'fields'   => $left_menu_list,

                    ],
                    'settings_sub_menu' => [
                        'name'     => 'settings_sub_menu',
                        'label'    => __( 'Settings Sub Menu', 'dokan' ),
                        'selected' => false,
                        'fields'   => $settings_menu_list,
                    ],
                ],
                'refresh_after_save' => true,
            ],
        ];

        return apply_filters( 'dashboard_menu_manager_before_admin_settings', $settings_fields );
    }

    /**
     * Process menu data for both admin settings and REST API
     *
     * @since 5.2.0
     *
     * @return array Processed menu data with left_menus and settings_sub_menu
     */
    public static function get_processed_menu_data(): array {
        // Enable seller temporarily to get all navigation items.
        $filter = function ( bool $status ) {
            return true;
        };

        add_filter( 'dokan_is_seller_enabled', $filter );
        $nav_menu_list = dokan_get_dashboard_nav();
        remove_filter( 'dokan_is_seller_enabled', $filter );

        // Extract settings submenu and left menu
        $settings_menu_list = $nav_menu_list['settings'][ Constants::SUBMENU ] ?? [];
        $left_menu_list     = $nav_menu_list;

        // Remove settings submenu and left menu.
        unset( $left_menu_list[ Constants::SUBMENU ] );
        unset( $left_menu_list['settings'] );

        return [
            'left_menus'        => $left_menu_list,
            'settings_sub_menu' => $settings_menu_list,
        ];
    }

    /**
     * Apply default restrictions to menu items
     *
     * @since 5.2.0
     *
     * @param array $processed_menus Array containing left_menus and settings_sub_menu
     *
     * @return array Array with restrictions applied
     */
    public static function apply_menu_restrictions( array $processed_menus ): array {
        // Dashboard is not switchable or sortable
        $processed_menus['left_menus']['dashboard']['switchable']  = false;
        $processed_menus['left_menus']['dashboard']['is_sortable'] = false;

        // Settings/Store is not switchable or sortable
        $processed_menus['settings_sub_menu']['store']['switchable']  = false;
        $processed_menus['settings_sub_menu']['store']['is_sortable'] = false;

        return apply_filters(
            'dokan_menu_manager_restricted_menus',
            $processed_menus
        );
    }
}
