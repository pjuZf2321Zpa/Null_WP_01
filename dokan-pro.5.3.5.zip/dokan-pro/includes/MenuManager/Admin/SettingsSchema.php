<?php

namespace WeDevs\DokanPro\MenuManager\Admin;

use WeDevs\DokanPro\MenuManager\Constants;

defined( 'ABSPATH' ) || exit;

/**
 * Dashboard Menu Manager — flat-array settings integration.
 *
 * Renders the Menu Manager inside the new flat settings (Appearance page) using
 * a tabbed subpage (Left Menu / Settings Sub Menu), each tab holding a
 * `repeater` field — reusing the shared repeater (drag-reorder, inline rename,
 * per-row activate/deactivate toggle).
 *
 * The menu config is NOT kept in the flat `dokan_admin_settings` option: on save
 * each tab's rows are projected back onto the canonical `dokan_menu_manager`
 * option (the same store the legacy DataSource writes) and then stripped from the
 * flat option — full legacy parity. Both display and save source the live,
 * fully-merged menu set ({@see Settings::get_processed_menu_data()}), so menus
 * registered by modules after the last save are never dropped.
 *
 * @since 5.2.0
 */
class SettingsSchema {

    const FIELD_LEFT = 'menu_manager_left_menus';
    const FIELD_SUB  = 'menu_manager_settings_sub_menu';

    public function __construct() {
        add_filter( 'dokan_get_admin_settings_schema', [ $this, 'append_schema' ], 20 );
        add_filter( 'dokan_rest_admin_settings_response', [ $this, 'populate_menu_rows' ] );
        add_filter( 'dokan_rest_admin_settings_sanitize_field', [ $this, 'sanitize_field' ], 10, 3 );
        add_action( 'dokan_rest_after_saving_settings', [ $this, 'forward_to_store' ], 10, 3 );
    }

    /**
     * Append the tabbed Menu Manager subpage + repeater fields.
     *
     * @param array $elements
     *
     * @return array
     */
    public function append_schema( array $elements ): array {
        $elements[] = [
            'id'            => 'dashboard-menu-manager',
            'type'          => 'subpage',
            'page_id'       => 'appearance',
            'title'         => esc_html__( 'Dashboard Menu Manager', 'dokan' ),
            'description'   => esc_html__( 'Reorder, Rename, Activate, and Deactivate menus for your vendor dashboard.', 'dokan' ),
            'doc_link'      => 'https://dokan.co/docs/wordpress/settings/dokan-menu-manager/',
            'doc_link_text' => esc_html__( 'Doc', 'dokan' ),
            'priority'      => 200,
        ];

        // Two tabs under the subpage.
        $elements[] = [
            'id'         => 'mm_tab_left',
            'type'       => 'tab',
            'subpage_id' => 'dashboard-menu-manager',
            'label'      => esc_html__( 'Left Menu', 'dokan' ),
            'priority'   => 10,
        ];
        $elements[] = [
            'id'         => 'mm_tab_sub',
            'type'       => 'tab',
            'subpage_id' => 'dashboard-menu-manager',
            'label'      => esc_html__( 'Settings Sub Menu', 'dokan' ),
            'priority'   => 20,
        ];

        // Section per tab.
        $elements[] = [
            'id'     => 'mm_section_left',
            'type'   => 'section',
            'tab_id' => 'mm_tab_left',
        ];
        $elements[] = [
            'id'     => 'mm_section_sub',
            'type'   => 'section',
            'tab_id' => 'mm_tab_sub',
        ];

        // Repeater field per tab — reorder/rename/toggle, no add/delete.
        // Rows are filled in populate_menu_rows(), so building the schema on every request stays cheap.
        $elements[] = $this->repeater_field( self::FIELD_LEFT, 'mm_section_left', [] );
        $elements[] = $this->repeater_field( self::FIELD_SUB, 'mm_section_sub', [] );

        return $elements;
    }

    /**
     * Fill the repeater rows from the live dashboard menu for the admin settings REST response.
     *
     * @since 5.2.0
     *
     * @param array $schema
     *
     * @return array
     */
    public function populate_menu_rows( $schema ) {
        if ( ! is_array( $schema ) ) {
            return $schema;
        }

        // Live, fully-merged menu set — the same source the legacy admin field uses.
        $data = Settings::apply_menu_restrictions( Settings::get_processed_menu_data() );
        $rows = [
            self::FIELD_LEFT => $this->map_to_rows( $data['left_menus'] ?? [] ),
            self::FIELD_SUB  => $this->map_to_rows( $data['settings_sub_menu'] ?? [] ),
        ];

        foreach ( $schema as &$element ) {
            $id = $element['id'] ?? '';
            if ( isset( $rows[ $id ] ) ) {
                $element['value']   = $rows[ $id ];
                $element['default'] = $rows[ $id ];
            }
        }
        unset( $element );

        return $schema;
    }

    /**
     * Build a menu-manager repeater field definition.
     *
     * @param string $id
     * @param string $section_id
     * @param array  $rows
     *
     * @return array
     */
    private function repeater_field( string $id, string $section_id, array $rows ): array {
        return [
            'id'         => $id,
            'type'       => 'field',
            'variant'    => 'repeater',
            'section_id' => $section_id,
            'value'      => $rows,
            'default'    => $rows,
            // Reuse the shared repeater with a per-row toggle, no add/delete.
            'row_toggle' => true,
            'addable'    => false,
            'deletable'  => false,
        ];
    }

    /**
     * Map a `{ menu_key => item }` group into repeater rows, ordered by position.
     *
     * @param array $menus
     *
     * @return array<int,array<string,mixed>>
     */
    private function map_to_rows( array $menus ): array {
        uasort(
            $menus,
            static function ( $a, $b ) {
                return intval( $a['menu_manager_position'] ?? 0 ) <=> intval( $b['menu_manager_position'] ?? 0 );
            }
        );

        $rows  = [];
        $order = 0;
        foreach ( $menus as $key => $item ) {
            $rows[] = [
                'id'           => (string) $key,
                'title'        => (string) ( $item['menu_manager_title'] ?? $item['title'] ?? $key ),
                'order'        => $order++,
                'enabled'      => function_exists( 'wc_string_to_bool' )
                    ? wc_string_to_bool( $item['is_switched_on'] ?? true )
                    : ! empty( $item['is_switched_on'] ),
                // Non-switchable menus (Dashboard, Store) lock only the toggle.
                'toggleLocked' => function_exists( 'wc_string_to_bool' )
                    ? ! wc_string_to_bool( $item['switchable'] ?? true )
                    : empty( $item['switchable'] ),
            ];
        }

        return $rows;
    }

    /**
     * Keep repeater array values intact through sanitization.
     *
     * @param mixed  $value
     * @param array  $field
     * @param string $variant
     *
     * @return mixed
     */
    public function sanitize_field( $value, $field, $variant ) {
        if ( 'repeater' !== $variant ) {
            return $value;
        }
        $id = $field['id'] ?? '';
        if ( self::FIELD_LEFT !== $id && self::FIELD_SUB !== $id ) {
            return $value;
        }

        return is_array( $value ) ? $value : [];
    }

    /**
     * On save, project both tabs' rows onto the canonical `dokan_menu_manager`
     * option and strip them from the flat option.
     *
     * Writes the full live menu set with the row overrides applied (rather than
     * merging onto the stored blob via {@see MenuManager::update_menu_settings()},
     * whose merge only carries keys present at the previous save and would drop
     * menus registered by modules since then). Targets the same option the legacy
     * DataSource writes, so legacy and new stay in lock-step.
     *
     * @param string $page_id
     * @param array  $sanitized
     * @param string $option_key
     *
     * @return void
     */
    public function forward_to_store( $page_id, $sanitized, $option_key ) {
        $has_left = isset( $sanitized[ self::FIELD_LEFT ] ) && is_array( $sanitized[ self::FIELD_LEFT ] );
        $has_sub  = isset( $sanitized[ self::FIELD_SUB ] ) && is_array( $sanitized[ self::FIELD_SUB ] );

        if ( ! $has_left && ! $has_sub ) {
            return;
        }

        // Existing stored overrides — used to preserve the tab that isn't part of this save.
        $menu_manager_options = get_option( Constants::DOKAN_MENU_MANAGER, [] );
        if ( ! is_array( $menu_manager_options ) ) {
            $menu_manager_options = [];
        }
        $stored = isset( $menu_manager_options[ Constants::MENU_MANAGER_OPTIONS ] ) && is_array( $menu_manager_options[ Constants::MENU_MANAGER_OPTIONS ] )
            ? $menu_manager_options[ Constants::MENU_MANAGER_OPTIONS ]
            : [];

        // Full live base so a save can never drop a menu; rows override on top.
        $base = Settings::apply_menu_restrictions( Settings::get_processed_menu_data() );

        // Only rebuild a tab from its submitted rows. For an absent tab, keep the
        // previously-stored overrides instead of resetting it to bare base (which
        // would wipe the other tab's saved toggle/order/title on a partial save).
        $left = $has_left
            ? $this->apply_row_overrides( $base['left_menus'] ?? [], $sanitized[ self::FIELD_LEFT ] )
            : ( $stored['left_menus'] ?? $base['left_menus'] ?? [] );
        $sub  = $has_sub
            ? $this->apply_row_overrides( $base['settings_sub_menu'] ?? [], $sanitized[ self::FIELD_SUB ] )
            : ( $stored['settings_sub_menu'] ?? $base['settings_sub_menu'] ?? [] );

        $menu_manager_options[ Constants::MENU_MANAGER_OPTIONS ] = [
            'left_menus'        => $left,
            'settings_sub_menu' => $sub,
        ];

        /** This action is documented in includes/Models/DataStore/MenuManagerStore.php */
        do_action( 'dokan_menu_manager_before_save', $menu_manager_options );
        update_option( Constants::DOKAN_MENU_MANAGER, $menu_manager_options );

        // Keep the menu blob out of the flat option — the menu store is canonical.
        $flat = get_option( $option_key, [] );
        if ( is_array( $flat ) ) {
            unset( $flat[ self::FIELD_LEFT ], $flat[ self::FIELD_SUB ] );
            update_option( $option_key, $flat );
        }
    }

    /**
     * Apply repeater-row overrides (toggle / order / title) onto the full base
     * menu set, preserving every base menu and its non-editable fields. Rows
     * whose key is absent from the base are ignored.
     *
     * @param array $base Full menu set keyed by menu key.
     * @param array $rows Repeater rows in display order.
     *
     * @return array<string,array<string,mixed>>
     */
    private function apply_row_overrides( array $base, array $rows ): array {
        foreach ( array_values( $rows ) as $index => $row ) {
            $key = isset( $row['id'] ) ? (string) $row['id'] : '';
            if ( '' === $key || ! isset( $base[ $key ] ) ) {
                continue;
            }

            $base[ $key ]['is_switched_on']        = ! empty( $row['enabled'] );
            $base[ $key ]['menu_manager_position'] = $index;
            $base[ $key ]['pos']                   = $index;

            $title = sanitize_text_field( $row['title'] ?? '' );
            if ( '' !== $title ) {
                $base[ $key ]['menu_manager_title'] = $title;
            }
        }

        return $base;
    }
}
