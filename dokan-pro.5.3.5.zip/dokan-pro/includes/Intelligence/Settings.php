<?php

namespace WeDevs\DokanPro\Intelligence;

use WeDevs\Dokan\Intelligence\Manager;
use WeDevs\Dokan\Intelligence\Services\Model;

/**
 * Settings class for AI product info generator.
 *
 * This class adds settings fields for configuring the AI product info generator
 * in the Dokan settings.
 *
 * @since 4.1.0
 */
class Settings {
    public function __construct() {
        add_filter( 'dokan_ai_settings_fields', [ $this, 'add_settings_fields' ] );
        add_filter( 'dokan_get_settings_values', [ $this, 'remap_unavailable_image_engine' ], 10, 2 );
        add_filter( 'dokan_ai_image_active_engine', [ $this, 'resolve_image_engine' ] );
    }

    /**
     * Add settings fields for AI product info generator.
     *
     * @since 4.1.0
     *
     * @param array $settings_fields The existing settings fields.
     *
     * @return array Modified settings fields with AI product info generator options.
     */
    public function add_settings_fields( array $settings_fields ) {
        $image_providers = dokan()->get_container()->get( Manager::class )->get_image_supported_providers();

        // Derive the default from the same registry that builds the options below.
        // A hardcoded id silently rots when a provider's registration changes —
        // OpenAI's image models are instantiated but never registered, so 'openai'
        // was a default this field could not offer. Prefer Gemini when present so
        // the default stays stable, and fall back to whatever is registered.
        $default_image_engine = isset( $image_providers['gemini'] )
            ? 'gemini'
            : (string) ( array_key_first( $image_providers ) ?? '' );

        $image_fields = [
            'dokan_ai_image_gen'              => [
                'name'          => 'dokan_ai_image_gen',
                'type'          => 'sub_section',
                'label'         => __( 'AI Product Image Enhance', 'dokan' ),
                'description'   => __( 'Enable AI Image Enhancement mode for vendors to enhance product images.', 'dokan' ),
                'content_class' => 'sub-section-styles',
            ],
            'dokan_ai_image_gen_availability'              => [
                'name'          => 'dokan_ai_image_gen_availability',
                'type'          => 'switcher',
                'label'         => __( 'Enable AI Image Enhancer', 'dokan' ),
                'description'   => __( 'Control marketplace vendors get this feature or not.', 'dokan' ),
                'default'       => 'off',
            ],
            'dokan_ai_image_engine' => [
                'name'    => 'dokan_ai_image_engine',
                'label'   => __( 'Engine', 'dokan' ),
                'type'    => 'select',
                'options' => array_map(
                    fn( $provider ) => $provider->get_title(),
                    $image_providers
                ),
                'desc'    => __( 'Select which AI provider to use for generating content.', 'dokan' ),
                'show_if' => [
                    'dokan_ai_image_gen_availability' => [
                        'equal' => 'on',
                    ],
                ],
                'default' => $default_image_engine,
            ],
        ];

        $settings_fields['dokan_ai'] = array_merge( $settings_fields['dokan_ai'], $image_fields );

        foreach ( $image_providers as $provider_id => $provider ) {
            // Resolve the default against the image type. A provider serving both
            // text and image cannot express one default valid for both, and the
            // untyped getter returns a text model id, which is never among the
            // image options — so a provider predating the typed getter offers no
            // default rather than a wrong one.
            $default_image_model = method_exists( $provider, 'get_default_model_id_by_type' )
                ? $provider->get_default_model_id_by_type( Model::SUPPORTS_IMAGE )
                : '';

            $settings_fields['dokan_ai'][ 'dokan_ai_image_' . $provider_id . '_api_key' ] = [
                'name'    => 'dokan_ai_image_' . $provider_id . '_api_key',
                // translators: %s is the provider name, e.g., OpenAI
                'label'   => sprintf( __( '%s API Key', 'dokan' ), $provider->get_title() ),
                'type'    => 'text',
                /* translators: 1: OpenAi Link */
                'desc'    => sprintf( __( 'You can get your API Keys in your <a href="%1$s" target="_blank">%2$s Account.</a>', 'dokan' ), $provider->get_api_key_url(), $provider->get_title() ),
                'default' => '',
                'secret_text' => true,
                'show_if' => [
                    'dokan_ai_image_gen_availability' => [
                        'equal' => 'on',
                    ],
                    'dokan_ai_image_engine' => [
                        'equal' => $provider_id,
                    ],
                ],
                'tooltip' => __( 'Your API key provides secure access to the AI service. Usage costs will be charged to the connected account.', 'dokan' ),
            ];

            $settings_fields['dokan_ai'][ 'dokan_ai_image_' . $provider_id . '_model' ] = [
                'name'    => 'dokan_ai_image_' . $provider_id . '_model',
                'label'   => __( 'Model', 'dokan' ),
                'type'    => 'select',
                'options' => array_map( fn( $model ) => $model->get_title(), $provider->get_models_by_type( Model::SUPPORTS_IMAGE ) ),
                'desc'    => __( 'More advanced models provide higher quality output but may cost more per generation.', 'dokan' ),
                'default' => $default_image_model,
                'show_if' => [
                    'dokan_ai_image_gen_availability' => [
                        'equal' => 'on',
                    ],
                    'dokan_ai_image_engine' => [
                        'equal' => $provider_id,
                    ],
                ],
            ];
        }

        return $settings_fields;
    }

    /**
     * Replace a stored image engine that ships no image model.
     *
     * The field default only applies while the key is absent, and the AI section saves as a
     * whole, so a site saved while the engine was hardcoded to `openai` holds an id that is
     * not among the select options and renders blank.
     *
     * @since 5.1.2
     *
     * @param mixed  $values     Section setting values.
     * @param string $section_id Section id.
     *
     * @return mixed Untouched unless the AI section holds an unavailable image engine.
     */
    public function remap_unavailable_image_engine( $values, $section_id ) {
        if ( 'dokan_ai' === $section_id && is_array( $values ) && ! empty( $values['dokan_ai_image_engine'] ) ) {
            $values['dokan_ai_image_engine'] = $this->resolve_image_engine( $values['dokan_ai_image_engine'] );
        }

        return $values;
    }

    /**
     * Point image generation at a provider that ships an image model.
     *
     * `Manager::active_engine()` falls back to `openai` for every generation type, so without
     * this the request reports the marketplace unconfigured until an admin re-saves settings.
     *
     * @since 5.1.2
     *
     * @param mixed $engine The stored image engine id.
     *
     * @return string Empty string when no provider ships an image model.
     */
    public function resolve_image_engine( $engine ): string {
        $providers = dokan()->get_container()->get( Manager::class )->get_image_supported_providers();
        $engine    = is_scalar( $engine ) ? (string) $engine : '';

        return isset( $providers[ $engine ] ) ? $engine : (string) array_key_first( $providers );
    }
}
