<?php

namespace WeDevs\DokanPro\Admin\Settings;

/**
 * Class AdminSettings.
 *
 * Previously loaded OOP settings pages and element classes.
 * Now a no-op shell; flat-array schema classes handle settings registration.
 *
 * @since 5.2.0
 */
class AdminSettings {

	/**
	 * Constructor.
	 *
	 * @since 5.2.0
	 *
	 * @return void
	 */
	public function __construct() {
		// No-op: settings are now registered via flat-array *SettingsSchema classes.
	}
}
