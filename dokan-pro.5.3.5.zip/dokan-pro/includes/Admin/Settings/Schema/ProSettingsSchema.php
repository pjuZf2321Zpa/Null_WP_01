<?php

namespace WeDevs\DokanPro\Admin\Settings\Schema;

/**
 * Pro core flat array settings schema.
 *
 * Hooks into Lite's `dokan_get_admin_settings_schema` filter to append:
 * - Fields injected into Lite pages (GeneralSettings, VendorSettings, WithdrawSettings)
 * - Pro-owned pages (ShipmentPage, EmailVerificationPage)
 *
 * @since 5.2.0
 */
class ProSettingsSchema {

    /**
     * Register the filter.
     */
    public function register(): void {
        add_filter( 'dokan_get_admin_settings_schema', [ $this, 'append_pro_schema' ] );
    }

    /**
     * Append Pro elements to the schema.
     *
     * @param array $elements Lite schema elements.
     *
     * @return array
     */
    public function append_pro_schema( array $elements ): array {

        $extended_elements = array_map(
            function ( $element ) {
                return $this->extend_lite_schema( $element['id'], $element );
            },
            $elements
        );

        return array_merge(
            $extended_elements,
            self::general_settings(),
            self::vendor_settings(),
            self::withdraw_settings(),
            self::vendor_social_onboarding_settings(),
            self::shipment_page(),
            self::email_verification_page(),
            self::reverse_withdraw_settings(),
            self::ai_assist_settings(),
        );
    }

    /**
     * Extend Lite schema definitions for shared fields.
     * This method is called for each schema element defined by Lite. It allows
     * Pro to inject additional options or legacy keys into existing definitions.
     *
     * @param string $schema_id
     * @param array $definition
     * @return array
     */
    public function extend_lite_schema( string $schema_id, array $definition ): array {
        if ( $schema_id === 'single_product_page_appearance' ) {
            $definition['options'][] = [
				'value' => 'shipping_tab',
				'label' => esc_html__( 'Shipping tab', 'dokan' ),
			];
            $definition['legacy_key']['shipping_tab'] = [
				'option' => 'dokan_selling',
				'field'  => 'disable_shipping_tab',
			];
        }

        return $definition;
    }

    /**
     * GeneralSettings: fields injected into Lite's General > Marketplace.
     * Replaces: dokan_settings_general_marketplace_marketplace_settings_children
     *           dokan_settings_general_marketplace_children
     *
     * @return array
     */
    private static function general_settings(): array {
        return [
            // Fields into General > Marketplace > marketplace_settings section
            [
                'id'            => 'enable_single_seller_mode',
                'legacy_key' => [
                    'option' => 'dokan_general',
                    'field'  => 'enable_single_seller_mode',
                ],
                'type'          => 'field',
                'variant'       => 'switch',
                'section_id'    => 'marketplace_settings',
                'title'         => esc_html__( 'Enable Single Seller Mode', 'dokan' ),
                'description'   => esc_html__( 'Restrict customers from purchasing products from multiple vendors in a single order.', 'dokan' ),
                'default'       => 'off',
                'enable_state'  => [
					'label' => esc_html__( 'Enabled', 'dokan' ),
					'value' => 'on',
				],
                'disable_state' => [
					'label' => esc_html__( 'Disabled', 'dokan' ),
					'value' => 'off',
				],
            ],
            [
                'id'          => 'store_category_mode',
                'type'        => 'field',
                'variant'     => 'radio_capsule',
                'section_id'  => 'marketplace_settings',
                'title'       => esc_html__( 'Store Category', 'dokan' ),
                'description' => esc_html__( 'Configure how store categories are handled in your marketplace.', 'dokan' ),
                'default'     => 'none',
                'options'     => [
                    [
						'title' => esc_html__( 'None', 'dokan' ),
						'value' => 'none',
					],
                    [
						'title' => esc_html__( 'Single', 'dokan' ),
						'value' => 'single',
					],
                    [
						'title' => esc_html__( 'Multiple', 'dokan' ),
						'value' => 'multiple',
					],
                ],
                'legacy_key' => [
                    'option' => 'dokan_general',
                    'field' => 'store_category_type',
                ],
            ],
            [
                'id'                 => 'show_customer_details_to_vendors',
                'legacy_key'         => [
                    'option' => 'dokan_selling',
                    'field'  => 'hide_customer_info',
                ],
                // Inverse semantics: new 'on' (show customer details) corresponds
                // to legacy 'off' (don't hide customer info), and vice versa.
                'legacy_transformer' => \WeDevs\Dokan\Admin\Settings\Migration\Transformer\InvertOnOffTransformer::class,
                'type'               => 'field',
                'variant'            => 'switch',
                'section_id'         => 'marketplace_settings',
                'title'              => esc_html__( 'Show Customer Details to Vendors', 'dokan' ),
                'description'        => esc_html__( 'Allow vendors to view customer shipping and contact information for orders.', 'dokan' ),
                'tooltip'            => __( 'It will show customer information from the "General Details" section of the single order details page.', 'dokan' ),
                'default'            => 'on',
                'enable_state'       => [
					'label' => esc_html__( 'Enabled', 'dokan' ),
					'value' => 'on',
				],
                'disable_state'      => [
					'label' => esc_html__( 'Disabled', 'dokan' ),
					'value' => 'off',
				],
            ],
            [
                'id'            => 'guest_product_enquiry',
                'type'          => 'field',
                'variant'       => 'switch',
                'section_id'    => 'marketplace_settings',
                'title'         => esc_html__( 'Guest Product Enquiry', 'dokan' ),
                'description'   => esc_html__( 'Guest customers can submit product enquiries without logging in.', 'dokan' ),
                'tooltip'       => esc_html__( 'When checked, user can inquire about products from the product page without signing in.', 'dokan' ),
                'default'       => 'on',
                'enable_state'  => [
					'label' => esc_html__( 'Enabled', 'dokan' ),
					'value' => 'on',
				],
                'disable_state' => [
					'label' => esc_html__( 'Disabled', 'dokan' ),
					'value' => 'off',
				],
                'legacy_key'    => [
                    'option' => 'dokan_selling',
                    'field'  => 'enable_guest_user_enquiry',
                ],
            ],
        ];
    }

    /**
     * VendorSettings: fields injected into Lite's Vendor page.
     * Replaces: dokan_settings_vendor_vendor_onboarding_children
     *           dokan_settings_vendor_vendor_capabilities_vendor_capabilities_children
     *           dokan_settings_vendor_children
     *
     * @return array
     */
    private static function vendor_settings(): array {
        return [
            // Into Vendor > Onboarding subpage
            [
                'id'            => 'terms_conditions',
                'type'          => 'field',
                'variant'       => 'switch',
                'subpage_id'    => 'vendor_onboarding',
                'title'         => esc_html__( 'Terms and Condition', 'dokan' ),
                'description'   => esc_html__( 'Enable the terms & conditions checkbox on vendor registration form.', 'dokan' ),
                'tooltip'       => esc_html__( 'Prompt terms and condition check for vendors when creating store on your site', 'dokan' ),
                'default'       => 'on',
                'enable_state'  => [
					'label' => esc_html__( 'Enabled', 'dokan' ),
					'value' => 'on',
				],
                'disable_state' => [
					'label' => esc_html__( 'Disabled', 'dokan' ),
					'value' => 'off',
				],
                'legacy_key'    => [
                    'option' => 'dokan_general',
                    'field'  => 'enable_tc_on_reg',
                ],
            ],

            // Into Vendor > Capabilities > vendor_capabilities section
            [
                'id'         => 'vendor_product_type_mode',
                'legacy_key' => [
                    'option' => 'dokan_general',
                    'field'  => 'global_digital_mode',
                ],
                // Option values match the legacy storage (`sell_physical` /
                // `sell_digital` / `sell_both`) so no value-translation
                // transformer is needed — the bridge passes values through
                // both directions unchanged.
                'type'       => 'field',
                'variant'    => 'radio_capsule',
                'section_id' => 'vendor_capabilities',
                'title'      => esc_html__( 'Selling Product Type', 'dokan' ),
                'default'    => 'sell_both',
                'options'    => [
                    [
						'title' => esc_html__( 'Physical', 'dokan' ),
						'value' => 'sell_physical',
					],
                    [
						'title' => esc_html__( 'Digital', 'dokan' ),
						'value' => 'sell_digital',
					],
                    [
						'title' => esc_html__( 'Both', 'dokan' ),
						'value' => 'sell_both',
					],
                ],
            ],
            [
                'id'          => 'product_status',
                'type'        => 'field',
                'variant'     => 'radio_capsule',
                'section_id'  => 'vendor_capabilities',
                'title'       => esc_html__( 'Product Status', 'dokan' ),
                'description' => esc_html__( 'The status of a product when a vendor creates or updates it.', 'dokan' ),
                'tooltip'     => esc_html__( 'The status of a product when a vendor creates or updates it.', 'dokan' ),
                'default'     => 'pending',
                'options'     => [
                    [
						'title' => esc_html__( 'Published', 'dokan' ),
						'value' => 'publish',
					],
                    [
						'title' => esc_html__( 'Pending Review', 'dokan' ),
						'value' => 'pending',
					],
                ],
                'legacy_key'  => [
                    'option' => 'dokan_selling',
                    'field'  => 'product_status',
                ],
            ],
            [
                'id'            => 'vendor_can_duplicate_products',
                'type'          => 'field',
                'variant'       => 'switch',
                'section_id'    => 'vendor_capabilities',
                'title'         => esc_html__( 'Duplicate Product', 'dokan' ),
                'description'   => esc_html__( 'Allow vendor to duplicate their product.', 'dokan' ),
                'default'       => 'on',
                'enable_state'  => [
					'label' => esc_html__( 'Enabled', 'dokan' ),
					'value' => 'on',
				],
                'disable_state' => [
					'label' => esc_html__( 'Disabled', 'dokan' ),
					'value' => 'off',
				],
                'legacy_key'    => [
                    'option' => 'dokan_selling',
                    'field'  => 'vendor_duplicate_product',
                ],
            ],
            [
                'id'            => 'allow_vendor_create_manual_order',
                'type'          => 'field',
                'variant'       => 'switch',
                'section_id'    => 'vendor_capabilities',
                'title'         => esc_html__( 'Allow Vendor to Create Manual Order', 'dokan' ),
                'description'   => esc_html__( 'Enable vendors to create orders manually from their dashboard.', 'dokan' ),
                'tooltip'       => esc_html__( 'When enabled, vendors can create manual orders directly from their dashboard for direct sales.', 'dokan' ),
                'default'       => 'off',
                'enable_state'  => [
					'label' => esc_html__( 'Enabled', 'dokan' ),
					'value' => 'on',
				],
                'disable_state' => [
					'label' => esc_html__( 'Disabled', 'dokan' ),
					'value' => 'off',
				],
                'legacy_key'    => [
                    'option' => 'dokan_selling',
                    'field'  => 'allow_vendor_create_manual_order',
                ],
            ],
            [
                'id'          => 'vendor_product_category_selection_mode',
                'legacy_key'  => [
                    'option' => 'dokan_selling',
                    'field'  => 'product_category_style',
                ],
                'type'        => 'field',
                'variant'     => 'radio_capsule',
                'section_id'  => 'vendor_capabilities',
                'title'       => esc_html__( 'Category Selection', 'dokan' ),
                'description' => esc_html__( 'Control how vendors assign categories to their products.', 'dokan' ),
                'default'     => 'single',
                'options'     => [
                    [
						'title' => esc_html__( 'Single', 'dokan' ),
						'value' => 'single',
					],
                    [
						'title' => esc_html__( 'Multiple', 'dokan' ),
						'value' => 'multiple',
					],
                ],
            ],
            [
                'id'            => 'vendor_can_create_product_tags',
                'legacy_key' => [
                    'option' => 'dokan_selling',
                    'field'  => 'product_vendors_can_create_tags',
                ],
                'type'          => 'field',
                'variant'       => 'switch',
                'section_id'    => 'vendor_capabilities',
                'title'         => esc_html__( 'Vendors Can Create Tags', 'dokan' ),
                'description'   => esc_html__( 'Allow vendors to create new product tags from vendor dashboard.', 'dokan' ),
                'default'       => 'off',
                'enable_state'  => [
					'label' => esc_html__( 'Enabled', 'dokan' ),
					'value' => 'on',
				],
                'disable_state' => [
					'label' => esc_html__( 'Disabled', 'dokan' ),
					'value' => 'off',
				],
            ],
            [
                'id'            => 'add_new_attribute_values',
                'type'          => 'field',
                'variant'       => 'switch',
                'section_id'    => 'vendor_capabilities',
                'title'         => esc_html__( 'Add New Attribute Values', 'dokan' ),
                'description'   => esc_html__( 'Allow vendors to add new values to predefined attribute.', 'dokan' ),
                'default'       => 'off',
                'enable_state'  => [
					'label' => esc_html__( 'Enabled', 'dokan' ),
					'value' => 'on',
				],
                'disable_state' => [
					'label' => esc_html__( 'Disabled', 'dokan' ),
					'value' => 'off',
				],
                'legacy_key'    => [
                    'option' => 'dokan_selling',
                    'field'  => 'add_new_attribute',
                ],
            ],
            [
                'id'            => 'vendor_can_manage_product_reviews',
                'legacy_key' => [
                    'option' => 'dokan_selling',
                    'field'  => 'seller_review_manage',
                ],
                'type'          => 'field',
                'variant'       => 'switch',
                'section_id'    => 'vendor_capabilities',
                'title'         => esc_html__( 'Product Review Management by Vendors', 'dokan' ),
                'description'   => esc_html__( 'Allow vendors to manage product review status changes from their dashboard.', 'dokan' ),
                'default'       => 'on',
                'enable_state'  => [
					'label' => esc_html__( 'Enabled', 'dokan' ),
					'value' => 'on',
				],
                'disable_state' => [
					'label' => esc_html__( 'Disabled', 'dokan' ),
					'value' => 'off',
				],
            ],
            [
                'id'         => 'discount_settings',
                'type'       => 'field',
                'variant'    => 'multicheck',
                'section_id' => 'vendor_capabilities',
                'title'      => esc_html__( 'Discount Editing', 'dokan' ),
                'description' => esc_html__( 'Vendor can add order and product quantity discount.', 'dokan' ),
                'default'    => [],
                'options'    => [
                    [
						'title' => esc_html__( 'Order Discount', 'dokan' ),
						'value' => 'order-discount',
					],
                    [
						'title' => esc_html__( 'Product Quantity Discount', 'dokan' ),
						'value' => 'product-discount',
					],
                ],
                'legacy_key'         => [
                    'order-discount'   => 'dokan_selling.discount_edit.order-discount',
                    'product-discount' => 'dokan_selling.discount_edit.product-discount',
                ],
                'legacy_transformer' => \WeDevs\Dokan\Admin\Settings\Migration\Transformer\MulticheckArrayTransformer::for_slots(
                    [ 'order-discount', 'product-discount' ]
                ),
            ],
        ];
    }

    /**
     * WithdrawSettings: fields injected into Lite's Transaction > Withdraw.
     * Replaces: dokan_settings_transaction_withdraw_charge_children
     *           dokan_settings_transaction_withdraw_charge_section_withdraw_charge_children
     *
     * @return array
     */
    private static function withdraw_settings(): array {
        $withdraw_fields = [
            // Withdraw threshold
            [
                'id'         => 'withdraw_threshold_section',
                'type'       => 'section',
                'subpage_id' => 'withdraw_charge',
            ],
            [
                'id'          => 'withdraw_threshold',
                'type'        => 'field',
                'variant'     => 'number',
                'section_id'  => 'withdraw_threshold_section',
                'title'       => esc_html__( 'Withdraw Threshold', 'dokan' ),
                'description' => esc_html__( 'Number of days to wait after order completion before allowing withdrawal.', 'dokan' ),
                'default'     => '0',
                'postfix'     => esc_html__( 'Days', 'dokan' ),
                'legacy_key'  => [
                    'option' => 'dokan_withdraw',
                    'field'  => 'withdraw_date_limit',
                ],
            ],

            // Withdraw visibility
            [
                'id'         => 'withdraw_option_visibility_section',
                'type'       => 'section',
                'subpage_id' => 'withdraw_charge',
            ],
            [
                'id'            => 'withdraw_option_visibility',
                'type'          => 'field',
                'variant'       => 'switch',
                'section_id'    => 'withdraw_option_visibility_section',
                'title'         => esc_html__( 'Withdraw Option Visibility', 'dokan' ),
                'description'   => esc_html__( 'Hide the withdraw option from vendors.', 'dokan' ),
                'default'       => 'off',
                'enable_state'  => [
					'label' => esc_html__( 'Enabled', 'dokan' ),
					'value' => 'on',
				],
                'disable_state' => [
					'label' => esc_html__( 'Disabled', 'dokan' ),
					'value' => 'off',
				],
                'legacy_key'    => [
                    'option' => 'dokan_withdraw',
                    'field'  => 'hide_withdraw_option',
                ],
            ],
            // Withdraw Disbursement — two independent toggles matching the
            // design's two-switch layout. Together these map onto the legacy
            // `dokan_withdraw.disbursement` array (`['manual' => 'manual',
            // 'schedule' => 'schedule']`) via two N→1 slots, wired below with
            // WithdrawMethodToggleTransformer. Note: the legacy consumer must
            // read this by key (e.g. $disbursement['schedule']); an off toggle
            // stores '' at that key, which an in_array() check would mis-read
            // as enabled.
            [
                'id'         => 'disbursement_methods_group',
                'type'       => 'fieldgroup',
                'section_id' => 'withdraw_option_visibility_section',
            ],
            [
                'id'                 => 'manual_withdraw_enabled',
                'type'               => 'field',
                'variant'            => 'switch',
                'field_group_id'     => 'disbursement_methods_group',
                'title'              => esc_html__( 'Manual Withdraw', 'dokan' ),
                'description'        => esc_html__( 'Allow vendors to request withdrawals manually.', 'dokan' ),
                'default'            => 'on',
                'enable_state'       => [
					'label' => esc_html__( 'Enabled', 'dokan' ),
					'value' => 'on',
				],
                'disable_state'      => [
					'label' => esc_html__( 'Disabled', 'dokan' ),
					'value' => 'off',
				],
                'legacy_key'         => 'dokan_withdraw.disbursement.manual',
                'legacy_transformer' => \WeDevs\Dokan\Admin\Settings\Migration\Transformer\WithdrawMethodToggleTransformer::for_method( 'manual' ),
            ],
            [
                'id'                 => 'schedule_disbursement_enabled',
                'type'               => 'field',
                'variant'            => 'switch',
                'field_group_id'     => 'disbursement_methods_group',
                'title'              => esc_html__( 'Schedule Disbursement or Auto Withdraw Process for Vendors', 'dokan' ),
                'description'        => esc_html__( 'Admin can make multiple schedules but vendor can choose any one.', 'dokan' ),
                'default'            => 'off',
                'enable_state'       => [
					'label' => esc_html__( 'Enabled', 'dokan' ),
					'value' => 'on',
				],
                'disable_state'      => [
					'label' => esc_html__( 'Disabled', 'dokan' ),
					'value' => 'off',
				],
                'legacy_key'         => 'dokan_withdraw.disbursement.schedule',
                'legacy_transformer' => \WeDevs\Dokan\Admin\Settings\Migration\Transformer\WithdrawMethodToggleTransformer::for_method( 'schedule' ),
            ],

            // Weekly withdraw schedule
            [
                'id'           => 'weekly_withdraw_group',
                'type'         => 'fieldgroup',
                'section_id'   => 'withdraw_option_visibility_section',
                'dependencies' => self::schedule_disbursement_dependency(),
            ],
            [
                'id'                 => 'weekly_withdraw',
                'type'               => 'field',
                'variant'            => 'switch',
                'field_group_id'     => 'weekly_withdraw_group',
                'title'              => esc_html__( 'Weekly', 'dokan' ),
                'default'            => 'off',
                'enable_state'       => [
					'label' => esc_html__( 'Enabled', 'dokan' ),
					'value' => 'on',
				],
                'disable_state'      => [
					'label' => esc_html__( 'Disabled', 'dokan' ),
					'value' => 'off',
				],
                'legacy_key'         => 'dokan_withdraw.disbursement_schedule.weekly',
                'legacy_transformer' => \WeDevs\Dokan\Admin\Settings\Migration\Transformer\WithdrawMethodToggleTransformer::for_method( 'weekly' ),
            ],
            [
                'id'             => 'weekly_withdraw_day',
                'type'           => 'field',
                'variant'        => 'select',
                'field_group_id' => 'weekly_withdraw_group',
                'title'          => esc_html__( 'Day of Week', 'dokan' ),
                'default'        => 'monday',
                'options'        => self::day_of_week_options(),
                'dependencies'   => [
                    [
						'key' => 'weekly_withdraw',
						'value' => 'on',
						'to_self' => true,
						'attribute' => 'display',
						'effect' => 'show',
						'comparison' => '===',
					],
                ],
                'legacy_key'     => [
                    'option' => 'dokan_withdraw',
                    'field'  => 'weekly_schedule',
                ],
            ],
            // Monthly withdraw schedule
            [
                'id'           => 'monthly_withdraw_group',
                'type'         => 'fieldgroup',
                'section_id'   => 'withdraw_option_visibility_section',
                'dependencies' => self::schedule_disbursement_dependency(),
            ],
            [
                'id'                 => 'monthly_withdraw',
                'type'               => 'field',
                'variant'            => 'switch',
                'field_group_id'     => 'monthly_withdraw_group',
                'title'              => esc_html__( 'Monthly', 'dokan' ),
                'default'            => 'off',
                'enable_state'       => [
					'label' => esc_html__( 'Enabled', 'dokan' ),
					'value' => 'on',
				],
                'disable_state'      => [
					'label' => esc_html__( 'Disabled', 'dokan' ),
					'value' => 'off',
				],
                'legacy_key'         => 'dokan_withdraw.disbursement_schedule.monthly',
                'legacy_transformer' => \WeDevs\Dokan\Admin\Settings\Migration\Transformer\WithdrawMethodToggleTransformer::for_method( 'monthly' ),
            ],
            [
                'id'             => 'monthly_withdraw_week_of_month',
                'type'           => 'field',
                'variant'        => 'select',
                'field_group_id' => 'monthly_withdraw_group',
                'title'          => esc_html__( 'Week', 'dokan' ),
                'default'        => '1',
                'options'        => self::week_of_month_options(),
                'dependencies'   => [
                    [
						'key' => 'monthly_withdraw',
						'value' => 'on',
						'to_self' => true,
						'attribute' => 'display',
						'effect' => 'show',
						'comparison' => '===',
					],
                ],
                'legacy_key'     => 'dokan_withdraw.monthly_schedule.week',
            ],
            [
                'id'             => 'monthly_withdraw_day_of_week',
                'type'           => 'field',
                'variant'        => 'select',
                'field_group_id' => 'monthly_withdraw_group',
                'title'          => esc_html__( 'Day', 'dokan' ),
                'default'        => 'monday',
                'options'        => self::day_of_week_options(),
                'dependencies'   => [
                    [
						'key' => 'monthly_withdraw',
						'value' => 'on',
						'to_self' => true,
						'attribute' => 'display',
						'effect' => 'show',
						'comparison' => '===',
					],
                ],
                'legacy_key'     => 'dokan_withdraw.monthly_schedule.days',
            ],

            // Biweekly withdraw schedule
            [
                'id'           => 'biweekly_withdraw_group',
                'type'         => 'fieldgroup',
                'section_id'   => 'withdraw_option_visibility_section',
                'dependencies' => self::schedule_disbursement_dependency(),
            ],
            [
                'id'                 => 'biweekly_withdraw',
                'type'               => 'field',
                'variant'            => 'switch',
                'field_group_id'     => 'biweekly_withdraw_group',
                'title'              => esc_html__( 'Biweekly', 'dokan' ),
                'default'            => 'off',
                'enable_state'       => [
					'label' => esc_html__( 'Enabled', 'dokan' ),
					'value' => 'on',
				],
                'disable_state'      => [
					'label' => esc_html__( 'Disabled', 'dokan' ),
					'value' => 'off',
				],
                'legacy_key'         => 'dokan_withdraw.disbursement_schedule.biweekly',
                'legacy_transformer' => \WeDevs\Dokan\Admin\Settings\Migration\Transformer\WithdrawMethodToggleTransformer::for_method( 'biweekly' ),
            ],
            // Biweekly first/second week pair — single field, rendered by a
            // Pro custom variant (`biweekly_week_pair`) that lays out two
            // dropdowns side-by-side. First is editable (weeks 1 or 2);
            // Second is a disabled display showing First + 2 (so First=1 →
            // Second=Third week (3); First=2 → Second=Fourth week (4)).
            //
            // Bridge wiring stays 1:1 — only the First slot round-trips to
            // legacy `dokan_withdraw.biweekly_schedule.week`. The legacy
            // `Helper::get_biweekly_schedule_weeks()` already computes the
            // second occurrence at runtime, so we do not need to persist it.
            [
                'id'             => 'biweekly_withdraw_first_week',
                'type'           => 'field',
                'variant'        => 'biweekly_week_pair',
                'field_group_id' => 'biweekly_withdraw_group',
                'title'          => esc_html__( 'Week', 'dokan' ),
                'default'        => '1',
                'options'        => [
                    [
						'title' => esc_html__( 'First week', 'dokan' ),
						'value' => '1',
					],
                    [
						'title' => esc_html__( 'Second week', 'dokan' ),
						'value' => '2',
					],
                ],
                'dependencies'   => [
                    [
						'key' => 'biweekly_withdraw',
						'value' => 'on',
						'to_self' => true,
						'attribute' => 'display',
						'effect' => 'show',
						'comparison' => '===',
					],
                ],
                'legacy_key'     => 'dokan_withdraw.biweekly_schedule.week',
            ],
            [
                'id'             => 'biweekly_withdraw_day_of_week',
                'type'           => 'field',
                'variant'        => 'select',
                'field_group_id' => 'biweekly_withdraw_group',
                'title'          => esc_html__( 'Day', 'dokan' ),
                'default'        => 'monday',
                'options'        => self::day_of_week_options(),
                'dependencies'   => [
                    [
						'key' => 'biweekly_withdraw',
						'value' => 'on',
						'to_self' => true,
						'attribute' => 'display',
						'effect' => 'show',
						'comparison' => '===',
					],
                ],
                'legacy_key'     => 'dokan_withdraw.biweekly_schedule.days',
            ],

            // Quarterly withdraw schedule
            [
                'id'           => 'quarterly_withdraw_group',
                'type'         => 'fieldgroup',
                'section_id'   => 'withdraw_option_visibility_section',
                'dependencies' => self::schedule_disbursement_dependency(),
            ],
            [
                'id'                 => 'quarterly_withdraw',
                'type'               => 'field',
                'variant'            => 'switch',
                'field_group_id'     => 'quarterly_withdraw_group',
                'title'              => esc_html__( 'Quarterly', 'dokan' ),
                'default'            => 'off',
                'enable_state'       => [
					'label' => esc_html__( 'Enabled', 'dokan' ),
					'value' => 'on',
				],
                'disable_state'      => [
					'label' => esc_html__( 'Disabled', 'dokan' ),
					'value' => 'off',
				],
                'legacy_key'         => 'dokan_withdraw.disbursement_schedule.quarterly',
                'legacy_transformer' => \WeDevs\Dokan\Admin\Settings\Migration\Transformer\WithdrawMethodToggleTransformer::for_method( 'quarterly' ),
            ],
            // Quarterly anchor month — single field, rendered by a Pro
            // custom variant (`quarter_anchor_month`) which lays out four
            // month dropdowns in a horizontal grid. Q1 is editable; Q2/Q3/Q4
            // are auto-derived from Q1 by advancing 3, 6, and 9 months
            // (Q1=January → Q2=April, Q3=July, Q4=October;
            //  Q1=February → Q2=May, Q3=August, Q4=November; etc.).
            //
            // Bridge wiring stays 1:1 — only the anchor month round-trips
            // to legacy `dokan_withdraw.quarterly_schedule.month`. The other
            // three quarters are purely presentational.
            [
                'id'             => 'quarterly_withdraw_q1_month',
                'type'           => 'field',
                'variant'        => 'quarter_anchor_month',
                'field_group_id' => 'quarterly_withdraw_group',
                'title'          => esc_html__( 'First Quarter', 'dokan' ),
                'default'        => 'january',
                'options'        => self::quarter_month_options( 1 ),
                'dependencies'   => self::quarterly_dependency(),
                'legacy_key'     => 'dokan_withdraw.quarterly_schedule.month',
            ],
            [
                'id'             => 'quarterly_withdraw_week_of_month',
                'type'           => 'field',
                'variant'        => 'select',
                'field_group_id' => 'quarterly_withdraw_group',
                'title'          => esc_html__( 'Week', 'dokan' ),
                'default'        => '1',
                'options'        => self::week_of_month_options(),
                'dependencies'   => self::quarterly_dependency(),
                'legacy_key'     => 'dokan_withdraw.quarterly_schedule.week',
            ],
            [
                'id'             => 'quarterly_withdraw_day_of_week',
                'type'           => 'field',
                'variant'        => 'select',
                'field_group_id' => 'quarterly_withdraw_group',
                'title'          => esc_html__( 'Day', 'dokan' ),
                'default'        => 'monday',
                'options'        => self::day_of_week_options(),
                'dependencies'   => self::quarterly_dependency(),
                'legacy_key'     => 'dokan_withdraw.quarterly_schedule.days',
            ],

            // Note: bank_transfer_withdraw_charges is defined in Lite's TransactionPage schema, not here
            // Note: gateway methods (Razorpay, Stripe, Paystack, MangoPay, …) register
            // their own withdraw toggle from their own module schema class.

            // Custom method
            [
                'id'         => 'withdraw_methods_group_custom',
                'type'       => 'fieldgroup',
                'section_id' => 'section_withdraw_charge',
            ],
            [
                'id'             => 'custom_withdraw',
                'type'           => 'field',
                'variant'        => 'switch',
                'field_group_id' => 'withdraw_methods_group_custom',
                'title'          => esc_html__( 'Custom', 'dokan' ),
                'default'        => 'on',
                'image_url'      => DOKAN_PRO_PLUGIN_ASSEST . '/images/admin-settings-icons/transaction/custom.png',
                'enable_state'   => [
					'label' => esc_html__( 'Enabled', 'dokan' ),
					'value' => 'on',
				],
                'disable_state'  => [
					'label' => esc_html__( 'Disabled', 'dokan' ),
					'value' => 'off',
				],
                'legacy_key'         => 'dokan_withdraw.withdraw_methods.dokan_custom',
                'legacy_transformer' => \WeDevs\Dokan\Admin\Settings\Migration\Transformer\WithdrawMethodToggleTransformer::for_method( 'dokan_custom' ),
            ],
            [
                'id'             => 'custom_method_name',
                'type'           => 'field',
                'variant'        => 'text',
                'field_group_id' => 'withdraw_methods_group_custom',
                'title'          => esc_html__( 'Custom Method Name', 'dokan' ),
                'dependencies'   => [
                    [
						'key' => 'custom_withdraw',
						'value' => 'on',
						'to_self' => true,
						'attribute' => 'display',
						'effect' => 'show',
						'comparison' => '===',
					],
                ],
                'legacy_key'     => [
                    'option' => 'dokan_withdraw',
                    'field'  => 'withdraw_method_name',
                ],
            ],
            [
                'id'             => 'custom_method_type',
                'type'           => 'field',
                'variant'        => 'text',
                'field_group_id' => 'withdraw_methods_group_custom',
                'title'          => esc_html__( 'Custom Method Type', 'dokan' ),
                'dependencies'   => [
                    [
						'key' => 'custom_withdraw',
						'value' => 'on',
						'to_self' => true,
						'attribute' => 'display',
						'effect' => 'show',
						'comparison' => '===',
					],
                ],
                'legacy_key'     => [
                    'option' => 'dokan_withdraw',
                    'field'  => 'withdraw_method_type',
                ],
            ],
            [
                'id'                 => 'custom_withdraw_charges',
                'type'               => 'field',
                'variant'            => 'combine_input',
                'field_group_id'     => 'withdraw_methods_group_custom',
                'title'              => esc_html__( 'Withdraw charges', 'dokan' ),
                'tooltip'            => esc_html__( 'Set withdrawal charges for the Custom method.', 'dokan' ),
                'admin_percentage'   => '0.00',
                'additional_fee'     => '0.00',
                'dependencies'       => [
                    [
                        'key'        => 'custom_withdraw',
                        'value'      => 'on',
                        'to_self'    => true,
                        'attribute'  => 'display',
                        'effect'     => 'show',
                        'comparison' => '===',
                    ],
                    [
                        'key'        => 'custom_withdraw',
                        'value'      => 'off',
                        'to_self'    => true,
                        'attribute'  => 'display',
                        'effect'     => 'hide',
                        'comparison' => '===',
                    ],
                ],
                'legacy_key'         => 'dokan_withdraw.withdraw_charges.dokan_custom',
                'legacy_transformer' => \WeDevs\Dokan\Admin\Settings\Migration\Transformer\WithdrawChargeTransformer::class,
            ],
        ];

        // Skrill is a Pro-core withdraw method (not a module): toggle + editable
        // charge, bridge-mapped to legacy `dokan_withdraw.withdraw_methods.skrill`
        // and `dokan_withdraw.withdraw_charges.skrill`.
        $withdraw_fields[] = [
            'id'         => 'withdraw_methods_group_skrill',
            'type'       => 'fieldgroup',
            'section_id' => 'section_withdraw_charge',
        ];
        $withdraw_fields[] = [
            'id'                 => 'withdraw_method_skrill',
            'type'               => 'field',
            'variant'            => 'switch',
            'field_group_id'     => 'withdraw_methods_group_skrill',
            'title'              => esc_html__( 'Skrill', 'dokan' ),
            'default'            => 'off',
            'image_url'          => DOKAN_PRO_PLUGIN_ASSEST . '/images/admin-settings-icons/transaction/skrill.png',
            'enable_state'       => [
                'label' => esc_html__( 'Enabled', 'dokan' ),
                'value' => 'on',
            ],
            'disable_state'      => [
                'label' => esc_html__( 'Disabled', 'dokan' ),
                'value' => 'off',
            ],
            'legacy_key'         => 'dokan_withdraw.withdraw_methods.skrill',
            'legacy_transformer' => \WeDevs\Dokan\Admin\Settings\Migration\Transformer\WithdrawMethodToggleTransformer::for_method( 'skrill' ),
        ];
        $withdraw_fields[] = [
            'id'                 => 'withdraw_method_skrill_charges',
            'type'               => 'field',
            'variant'            => 'combine_input',
            'field_group_id'     => 'withdraw_methods_group_skrill',
            'title'              => esc_html__( 'Withdraw charges', 'dokan' ),
            'tooltip'            => esc_html__( 'Set withdrawal charges for Skrill method.', 'dokan' ),
            'admin_percentage'   => '0.00',
            'additional_fee'     => '0.00',
            'dependencies'       => [
                [
                    'key'        => 'withdraw_method_skrill',
                    'value'      => 'on',
                    'to_self'    => true,
                    'attribute'  => 'display',
                    'effect'     => 'show',
                    'comparison' => '===',
                ],
                [
                    'key'        => 'withdraw_method_skrill',
                    'value'      => 'off',
                    'to_self'    => true,
                    'attribute'  => 'display',
                    'effect'     => 'hide',
                    'comparison' => '===',
                ],
            ],
            'legacy_key'         => 'dokan_withdraw.withdraw_charges.skrill',
            'legacy_transformer' => \WeDevs\Dokan\Admin\Settings\Migration\Transformer\WithdrawChargeTransformer::class,
        ];

        return $withdraw_fields;
    }

    /**
     * Get the reverse withdraw settings.
     *
     * @return array
     */
    public static function reverse_withdraw_settings(): array {
		return [
			[
				'id'            => 'send_announcement',
				'legacy_key'    => [
					'option' => 'dokan_reverse_withdrawal',
					'field'  => 'send_announcement',
				],
				'type'          => 'field',
				'variant'       => 'switch',
				'section_id'    => 'reverse_withdrawal_section',
				'title'         => esc_html__( 'Send Announcement', 'dokan' ),
				'description'   => esc_html__( 'Send platform announcements to vendors during the grace period. Limited to one announcement per billing period.', 'dokan' ),
				'default'       => 'off',
				'enable_state'  => [
					'label' => esc_html__( 'Enabled', 'dokan' ),
					'value' => 'on',
				],
				'disable_state' => [
					'label' => esc_html__( 'Disabled', 'dokan' ),
					'value' => 'off',
				],
			],
		];
    }

    /**
     * Vendor Social Onboarding: Pro-owned subpage under the Vendors page.
     *
     * Bridges the legacy `dokan_social_api` wp_option (social-login providers)
     * into the new flat-array schema so upgraded sites migrate through the
     * LegacySettingsBridge. Mirrors the Vendor Verification "Social Connect"
     * pattern: one collapsible_switch card per provider, with a nested help
     * notice and credential fields.
     *
     * Field ids are prefixed `vso_` so they stay globally unique.
     *
     * @since 5.2.0
     *
     * @return array
     */
    private static function vendor_social_onboarding_settings(): array {
        $icon_base = DOKAN_PRO_PLUGIN_ASSEST . '/images/scl-icons/';

        // Shared OAuth callback URL surfaced read-only on every provider so admins
        // can copy it into the provider's developer console. Mirrors the legacy
        // SocialLogin::$callback (the WooCommerce my-account page).
        $callback = function_exists( 'dokan_get_page_url' ) ? dokan_get_page_url( 'myaccount', 'woocommerce' ) : '';

        // Provider definitions. Each maps onto the flat keys stored in the legacy
        // `dokan_social_api` wp_option. The redirect/callback URL is display-only
        // (no legacy storage); it defaults to the shared $callback.
        $providers = [
            'facebook' => [
                'name'          => esc_html__( 'Facebook', 'dokan' ),
                'title'         => esc_html__( 'Connect to Facebook', 'dokan' ),
                'icon'          => 'fb.svg',
                'help_url'      => 'https://dokan.co/docs/wordpress/settings/dokan-social-login/configuring-facebook/',
                'enable_legacy' => 'fb_enable_status',
                'notice_text'   => esc_html__( 'If you don\'t have one, create an App and fill in the App ID and Secret below.', 'dokan' ),
                'create_url'    => 'https://developers.facebook.com/apps/',
                'fields'        => [
                    [
						'suffix' => 'redirect_url',
						'variant' => 'copy_field',
						'title' => esc_html__( 'Site URL', 'dokan' ),
					],
                    [
						'suffix' => 'app_id',
						'variant' => 'show_hide',
						'title' => esc_html__( 'App ID', 'dokan' ),
						'legacy' => 'fb_app_id',
					],
                    [
						'suffix' => 'app_secret',
						'variant' => 'show_hide',
						'title' => esc_html__( 'App Secret', 'dokan' ),
						'legacy' => 'fb_app_secret',
					],
                ],
            ],
            'x' => [
                'name'          => esc_html__( 'X', 'dokan' ),
                'title'         => esc_html__( 'Connect to X', 'dokan' ),
                'icon'          => 'twt.svg',
                'help_url'      => 'https://dokan.co/docs/wordpress/settings/dokan-social-login/configuring-twitter/',
                'enable_legacy' => 'twitter_enable_status',
                'notice_text'   => esc_html__( 'If you don\'t have one, create an App and fill in the Consumer Key and Secret below.', 'dokan' ),
                'create_url'    => 'https://apps.twitter.com/',
                'fields'        => [
                    [
						'suffix' => 'redirect_url',
						'variant' => 'copy_field',
						'title' => esc_html__( 'Callback URL', 'dokan' ),
					],
                    [
						'suffix' => 'api_key',
						'variant' => 'show_hide',
						'title' => esc_html__( 'Consumer Key', 'dokan' ),
						'legacy' => 'twitter_app_id',
					],
                    [
						'suffix' => 'api_secret',
						'variant' => 'show_hide',
						'title' => esc_html__( 'Consumer Secret', 'dokan' ),
						'legacy' => 'twitter_app_secret',
					],
                ],
            ],
            'google' => [
                'name'          => esc_html__( 'Google', 'dokan' ),
                'title'         => esc_html__( 'Connect to Google', 'dokan' ),
                'icon'          => 'google.svg',
                'help_url'      => 'https://dokan.co/docs/wordpress/settings/dokan-social-login/configuring-google/',
                'enable_legacy' => 'google_enable_status',
                'notice_text'   => esc_html__( 'If you don\'t have one, create an App and fill in the Client ID and Secret below.', 'dokan' ),
                'create_url'    => 'https://console.developers.google.com/project',
                'fields'        => [
                    [
						'suffix' => 'redirect_url',
						'variant' => 'copy_field',
						'title' => esc_html__( 'Redirect URL', 'dokan' ),
					],
                    [
						'suffix' => 'client_id',
						'variant' => 'show_hide',
						'title' => esc_html__( 'Client ID', 'dokan' ),
						'legacy' => 'google_app_id',
					],
                    [
						'suffix' => 'client_secret',
						'variant' => 'show_hide',
						'title' => esc_html__( 'Client Secret', 'dokan' ),
						'legacy' => 'google_app_secret',
					],
                ],
            ],
            'linkedin' => [
                'name'          => esc_html__( 'LinkedIn', 'dokan' ),
                'title'         => esc_html__( 'Connect to LinkedIn', 'dokan' ),
                'icon'          => 'linkedin.svg',
                'help_url'      => 'https://dokan.co/docs/wordpress/settings/dokan-social-login/configuring-linkedin/',
                'enable_legacy' => 'linkedin_enable_status',
                'notice_text'   => esc_html__( 'If you don\'t have one, create an App and fill in the Client ID and Secret below.', 'dokan' ),
                'create_url'    => 'https://www.linkedin.com/developer/apps',
                'fields'        => [
                    [
						'suffix' => 'redirect_url',
						'variant' => 'copy_field',
						'title' => esc_html__( 'Redirect URL', 'dokan' ),
					],
                    [
						'suffix' => 'client_id',
						'variant' => 'show_hide',
						'title' => esc_html__( 'Client ID', 'dokan' ),
						'legacy' => 'linkedin_app_id',
					],
                    [
						'suffix' => 'client_secret',
						'variant' => 'show_hide',
						'title' => esc_html__( 'Client Secret', 'dokan' ),
						'legacy' => 'linkedin_app_secret',
					],
                ],
            ],
            'apple' => [
                'name'          => esc_html__( 'Apple', 'dokan' ),
                'title'         => esc_html__( 'Connect to Apple', 'dokan' ),
                'icon'          => 'apple.svg',
                'help_url'      => 'https://dokan.co/docs/wordpress/settings/dokan-social-login/configuring-apple/',
                'enable_legacy' => 'apple_enable_status',
                'notice_text'   => esc_html__( 'You can successfully connect to your Apple account and log in from here.', 'dokan' ),
                'create_url'    => 'https://appleid.apple.com/',
                'fields'        => [
                    [
						'suffix' => 'redirect_url',
						'variant' => 'copy_field',
						'title' => esc_html__( 'Redirect URL', 'dokan' ),
					],
                    [
						'suffix' => 'service_id',
						'variant' => 'show_hide',
						'title' => esc_html__( 'Apple Service ID', 'dokan' ),
						'legacy' => 'apple_service_id',
					],
                    [
						'suffix' => 'team_id',
						'variant' => 'show_hide',
						'title' => esc_html__( 'Apple Team ID', 'dokan' ),
						'legacy' => 'apple_team_id',
					],
                    [
						'suffix' => 'key_id',
						'variant' => 'show_hide',
						'title' => esc_html__( 'Apple Key ID', 'dokan' ),
						'legacy' => 'apple_key_id',
					],
                    [
						'suffix' => 'key_content',
						'variant' => 'textarea',
						'title' => esc_html__( 'Apple Key Content (including BEGIN and END lines)', 'dokan' ),
						'legacy' => 'apple_key_content',
						'placeholder' => esc_html__( 'Write here', 'dokan' ),
					],
                ],
            ],
        ];

        $elements = [
            [
                'id'          => 'vendor_social_onboarding',
                'type'        => 'subpage',
                'page_id'     => 'vendor',
                'title'       => esc_html__( 'Social Onboarding', 'dokan' ),
                'description' => esc_html__( 'Define settings to allow vendors to use their social profiles to register or log in to the marketplace.', 'dokan' ),
                'priority'    => 200,
                'doc_link'    => 'https://dokan.co/docs/wordpress/settings/dokan-social-login/',
                'doc_link_text' => esc_html__( 'Doc', 'dokan' ),
            ],
            [
                'id'         => 'vendor_social_onboarding_section',
                'type'       => 'section',
                'subpage_id' => 'vendor_social_onboarding',
            ],
            [
                'id'            => 'vso_social_login',
                'legacy_key'    => 'dokan_social_api.enabled',
                'type'          => 'field',
                'variant'       => 'switch',
                'section_id'    => 'vendor_social_onboarding_section',
                'title'         => esc_html__( 'Social Login', 'dokan' ),
                'description'   => esc_html__( 'Enabling this will add Social Icons under registration form to allow users to login or register using Social Profiles.', 'dokan' ),
                'tooltip'       => esc_html__( 'Check this to allow social login/signup for customers and vendors.', 'dokan' ),
                'default'       => 'off',
                'enable_state'  => [
					'label' => esc_html__( 'Enabled', 'dokan' ),
					'value' => 'on',
				],
                'disable_state' => [
					'label' => esc_html__( 'Disabled', 'dokan' ),
					'value' => 'off',
				],
            ],
        ];

        foreach ( $providers as $provider_id => $provider ) {
            $enable_id = 'vso_' . $provider_id . '_enabled';
            $group_id  = 'vso_' . $provider_id . '_group';

            // Provider card — collapsible switch (toggle + chevron header with
            // icon). Credential fields nest below and reveal when expanded. Maps
            // to the legacy `<provider>_enable_status` flag (legacy default 'on').
            $elements[] = [
                'id'            => $enable_id,
                'legacy_key'    => 'dokan_social_api.' . $provider['enable_legacy'],
                'type'          => 'field',
                'variant'       => 'collapsible_switch',
                'section_id'    => 'vendor_social_onboarding_section',
                'title'         => $provider['title'],
                'description'   => sprintf(
                    /* translators: 1: provider name, 2: opening anchor tag, 3: closing anchor tag */
                    esc_html__( 'Configure your %1$s API settings. %2$sGet Help%3$s', 'dokan' ),
                    $provider['name'],
                    '<a href="' . esc_url( $provider['help_url'] ) . '" target="_blank" rel="noopener noreferrer">',
                    '</a>'
                ),
                'image_url'     => $icon_base . $provider['icon'],
                'collapsed'     => true,
                'default'       => 'on',
                'enable_state'  => [
					'label' => esc_html__( 'Enabled', 'dokan' ),
					'value' => 'on',
				],
                'disable_state' => [
					'label' => esc_html__( 'Disabled', 'dokan' ),
					'value' => 'off',
				],
            ];

            // Group container for the card's nested fields. A dedicated
            // `fieldgroup` (not the switch field itself) so `field_group_id`
            // resolves to a real group element; the switch stays `type: field`
            // to keep its legacy_key bridging and single-option storage.
            $elements[] = [
                'id'         => $group_id,
                'type'       => 'fieldgroup',
                'section_id' => 'vendor_social_onboarding_section',
            ];

            // Help notice — nested under the card; revealed when the provider
            // card's own toggle is enabled.
            $elements[] = [
                'id'             => 'vso_' . $provider_id . '_notice',
                'type'           => 'field',
                'variant'        => 'info',
                'field_group_id' => $group_id,
                'show_icon'      => true,
                'title'          => $provider['notice_text'],
                'link_title'     => esc_html__( 'Create an App', 'dokan' ),
                'link_url'       => $provider['create_url'],
                'dependencies'   => self::social_provider_field_dependency( $enable_id ),
            ];

            // Credential fields — nested under the card. Visible only when the
            // provider card's own toggle is enabled. The read-only redirect URL
            // is display-only (no legacy_key); it defaults to the shared OAuth
            // callback so admins can copy it into the provider console.
            foreach ( $provider['fields'] as $field ) {
                $element = [
                    'id'             => 'vso_' . $provider_id . '_' . $field['suffix'],
                    'type'           => 'field',
                    'variant'        => $field['variant'],
                    'field_group_id' => $group_id,
                    'title'          => $field['title'],
                    'dependencies'   => self::social_provider_field_dependency( $enable_id ),
                ];

                if ( ! empty( $field['legacy'] ) ) {
                    $element['legacy_key'] = 'dokan_social_api.' . $field['legacy'];
                }

                if ( ! empty( $field['placeholder'] ) ) {
                    $element['placeholder'] = $field['placeholder'];
                }

                if ( 'redirect_url' === $field['suffix'] ) {
                    $element['readonly'] = true;
                    $element['default']  = $callback;
                }

                $elements[] = $element;
            }
        }

        return $elements;
    }

    /**
     * ShipmentPage: Pro-owned page.
     *
     * @return array
     */
    private static function shipment_page(): array {
        $providers = [
            'sp-australia-post' => [
				'title' => esc_html__( 'Australia Post', 'dokan' ),
				'default' => '',
			],
            'sp-canada-post'    => [
				'title' => esc_html__( 'Canada Post', 'dokan' ),
				'default' => '',
			],
            'sp-city-link'      => [
				'title' => esc_html__( 'City Link', 'dokan' ),
				'default' => '',
			],
            'sp-dhl'            => [
				'title' => esc_html__( 'DHL', 'dokan' ),
				'default' => 'sp-dhl',
			],
            'sp-dpd'            => [
				'title' => esc_html__( 'DPD', 'dokan' ),
				'default' => 'sp-dpd',
			],
            'sp-fastway-south-africa' => [
				'title' => esc_html__( 'Fastway South Africa', 'dokan' ),
				'default' => '',
			],
            'sp-fedex'          => [
				'title' => esc_html__( 'FedEx', 'dokan' ),
				'default' => 'sp-fedex',
			],
            'sp-ontrac'         => [
				'title' => esc_html__( 'OnTrac', 'dokan' ),
				'default' => '',
			],
            'sp-parcelforce'    => [
				'title' => esc_html__( 'Parcelforce', 'dokan' ),
				'default' => '',
			],
            'sp-polish-shipping-providers' => [
				'title' => esc_html__( 'Polish Shipping Providers', 'dokan' ),
				'default' => 'sp-polish-shipping-providers',
			],
            'sp-royal-mail'     => [
				'title' => esc_html__( 'Royal Mail', 'dokan' ),
				'default' => '',
			],
            'sp-tnt-express-consignment' => [
				'title' => esc_html__( 'TNT Express (Consignment)', 'dokan' ),
				'default' => '',
			],
            'sp-tnt-express-reference'   => [
				'title' => esc_html__( 'TNT Express (Reference)', 'dokan' ),
				'default' => '',
			],
            'sp-fedex-sameday'  => [
				'title' => esc_html__( 'FedEx Sameday', 'dokan' ),
				'default' => '',
			],
            'sp-ups'            => [
				'title' => esc_html__( 'UPS', 'dokan' ),
				'default' => 'sp-ups',
			],
            'sp-usps'           => [
				'title' => esc_html__( 'USPS', 'dokan' ),
				'default' => 'sp-usps',
			],
            'sp-dhl-us'         => [
				'title' => esc_html__( 'DHL US', 'dokan' ),
				'default' => '',
			],
            'sp-other'          => [
				'title' => esc_html__( 'Other', 'dokan' ),
				'default' => 'sp-other',
			],
        ];

        // Brand logo per provider (falls back to a generic mark). Files live in
        // assets/src/images/shipping-provider-img/.
        $logo_base      = DOKAN_PRO_PLUGIN_ASSEST . '/src/images/shipping-provider-img/';
        $provider_logos = [
            'sp-australia-post'            => 'aus-post.svg',
            'sp-canada-post'               => 'canada-post.svg',
            'sp-city-link'                 => 'city-link.svg',
            'sp-dhl'                       => 'dhl.svg',
            'sp-dpd'                       => 'dpd.svg',
            'sp-fastway-south-africa'      => 'fastway.svg',
            'sp-fedex'                     => 'fedex.svg',
            'sp-ontrac'                    => 'on-trac.svg',
            'sp-parcelforce'               => 'parcel-force.svg',
            'sp-polish-shipping-providers' => 'postal-service.svg',
            'sp-royal-mail'                => 'royal-mail.svg',
            'sp-tnt-express-consignment'   => 'tnt.svg',
            'sp-tnt-express-reference'     => 'tnt.svg',
            'sp-fedex-sameday'             => 'fedex.svg',
            'sp-ups'                       => 'ups.svg',
            'sp-usps'                      => 'usps.svg',
            'sp-dhl-us'                    => 'dhl.svg',
            'sp-other'                     => 'others.svg',
        ];

        $elements = [
            [
                'id'          => 'shipment',
                'type'        => 'page',
                'title'       => esc_html__( 'Shipment', 'dokan' ),
                'icon'        => 'Truck',
                'priority'    => 800,
                'storage_key' => 'dokan_settings_shipment',
            ],
            [
                'id'         => 'shipment-setting-page',
                'type'       => 'subpage',
                'page_id'    => 'shipment',
                'title'      => esc_html__( 'Shipment Settings', 'dokan' ),
                'description' => esc_html__( 'Configure shipment tracking, integrations, and delivery options for your marketplace.', 'dokan' ),
                'priority'   => 100,
            ],
            [
                'id'         => 'shipment-settings',
                'type'       => 'section',
                'subpage_id' => 'shipment-setting-page',
            ],
            [
                'id'            => 'allows_shipment_tracking',
                'legacy_key'    => [
                    'option' => 'dokan_shipping_status_setting',
                    'field'  => 'enabled',
                ],
                'type'          => 'field',
                'variant'       => 'switch',
                'section_id'    => 'shipment-settings',
                'title'         => esc_html__( 'Allow Shipment Tracking', 'dokan' ),
                'description'   => esc_html__( 'Allow vendors to provide tracking information for customer orders.', 'dokan' ),
                'default'       => 'off',
                'enable_state'  => [
					'label' => esc_html__( 'Enabled', 'dokan' ),
					'value' => 'on',
				],
                'disable_state' => [
					'label' => esc_html__( 'Disabled', 'dokan' ),
					'value' => 'off',
				],
            ],
            [
                'id'            => 'enable_shipstation_logging',
                'legacy_key' => [
                    'option' => 'dokan_general',
                    'field'  => 'enable_shipstation_logging',
                ],
                'type'          => 'field',
                'variant'       => 'switch',
                'section_id'    => 'shipment-settings',
                'title'         => esc_html__( 'Log ShipStation API Request', 'dokan' ),
                'description'   => esc_html__( 'Record all API requests and responses from ShipStation integration.', 'dokan' ),
                'tooltip'       => esc_html__( 'Stores ShipStation API traffic to help debug sync issues.', 'dokan' ),
                'default'       => 'off',
                'enable_state'  => [
					'label' => esc_html__( 'Enabled', 'dokan' ),
					'value' => 'on',
				],
                'disable_state' => [
					'label' => esc_html__( 'Disabled', 'dokan' ),
					'value' => 'off',
				],
            ],
            [
                'id'            => 'allow_mark_received',
                'legacy_key' => [
                    'option' => 'dokan_shipping_status_setting',
                    'field'  => 'allow_mark_received',
                ],
                'type'          => 'field',
                'variant'       => 'switch',
                'section_id'    => 'shipment-settings',
                'title'         => esc_html__( 'Allow Mark as Received', 'dokan' ),
                'description'   => esc_html__( 'Permit customers to confirm delivery completion.', 'dokan' ),
                'tooltip'       => esc_html__( 'Lets customers confirm they received their order.', 'dokan' ),
                'default'       => 'off',
                'enable_state'  => [
					'label' => esc_html__( 'Enabled', 'dokan' ),
					'value' => 'on',
				],
                'disable_state' => [
					'label' => esc_html__( 'Disabled', 'dokan' ),
					'value' => 'off',
				],
                'dependencies'  => [
                    [
						'key' => 'allows_shipment_tracking',
						'value' => 'on',
						'to_self' => true,
						'attribute' => 'display',
						'effect' => 'show',
						'comparison' => '===',
					],
                ],
            ],
            [
                'id'          => 'shipment-provider',
                'type'        => 'section',
                'subpage_id'  => 'shipment-setting-page',
                'title'       => esc_html__( 'Shipping Providers', 'dokan' ),
                'description' => esc_html__( 'Select shipping providers that vendors can offer to customers.', 'dokan' ),
                'tooltip'     => esc_html__( 'Toggle the carriers vendors can pick when adding tracking.', 'dokan' ),
            ],
        ];
        // Provider toggles
        foreach ( $providers as $id => $provider ) {
            $elements[] = [
                'id'                 => $id,
                // Dotted string form so the bridge nests into the legacy
                // `shipping_status_provider` map (the struct form keeps the dot
                // as a literal key instead of splitting the path).
                'legacy_key'         => 'dokan_shipping_status_setting.shipping_status_provider.' . $id,
                'legacy_transformer' => \WeDevs\Dokan\Admin\Settings\Migration\Transformer\WithdrawMethodToggleTransformer::for_method( $id ),
                'type'               => 'field',
                'variant'            => 'switch',
                'section_id'         => 'shipment-provider',
                'image_url'          => $logo_base . ( $provider_logos[ $id ] ?? 'others.svg' ),
                'title'              => esc_html( $provider['title'] ),
                'default'            => '' !== $provider['default'] ? 'on' : 'off',
                'enable_state'       => [
					'label' => esc_html__( 'Enabled', 'dokan' ),
					'value' => 'on',
				],
                'disable_state'      => [
					'label' => esc_html__( 'Disabled', 'dokan' ),
					'value' => 'off',
				],
            ];
        }

        // Shipment status repeater
        $elements[] = [
            'id'          => 'shipment-status',
            'type'        => 'section',
            'subpage_id'  => 'shipment-setting-page',
            'title'       => esc_html__( 'Shipping Status', 'dokan' ),
            'description' => esc_html__( 'Define shipping statuses that vendors can use to update customers.', 'dokan' ),
            'tooltip'     => esc_html__( 'These statuses appear when a vendor updates an order shipment.', 'dokan' ),
        ];
        $elements[] = [
            'id'                 => 'shipping_status_list',
            'legacy_key'         => [
                'option' => 'dokan_shipping_status_setting',
                'field'  => 'shipping_status_list',
            ],
            'legacy_transformer' => \WeDevs\DokanPro\Admin\Settings\Migration\Transformer\ShippingStatusListTransformer::class,
            'type'               => 'field',
            'variant'            => 'repeater',
            'section_id'         => 'shipment-status',
            // Heading lives on the parent section; keep the field chrome-less.
            'title'          => '',
            'new_title'      => esc_html__( 'Add New Shipping Status', 'dokan' ),
            'required_label' => esc_html__( 'Must Have', 'dokan' ),
            'default'        => [
                [
					'id' => 'ss_delivered',
					'title' => esc_html__( 'Delivered', 'dokan' ),
					'required' => 1,
				],
                [
					'id' => 'ss_cancelled',
					'title' => esc_html__( 'Cancelled', 'dokan' ),
					'required' => 1,
				],
                [
					'id' => 'ss_procressing',
					'title' => esc_html__( 'Processing', 'dokan' ),
				],
                [
					'id' => 'ss_ready_for_pickup',
					'title' => esc_html__( 'Ready for Pickup', 'dokan' ),
				],
                [
					'id' => 'ss_pickedup',
					'title' => esc_html__( 'Picked Up', 'dokan' ),
				],
                [
					'id' => 'ss_on_the_way',
					'title' => esc_html__( 'On the way', 'dokan' ),
				],
            ],
        ];

        return $elements;
    }

    /**
     * EmailVerificationPage: Pro-owned page.
     *
     * @return array
     */
    private static function email_verification_page(): array {
        return [
            [
                'id'          => 'verification',
                'type'        => 'page',
                'title'       => esc_html__( 'Verification', 'dokan' ),
                'icon'        => 'Shield',
                'priority'    => 500,
                'storage_key' => 'dokan_verification',
            ],
            [
                'id'         => 'email-verification-page',
                'type'       => 'subpage',
                'page_id'    => 'verification',
                'title'      => esc_html__( 'Email Verification', 'dokan' ),
                'priority'   => 200,
            ],
            [
                'id'         => 'email-verification',
                'type'       => 'section',
                'subpage_id' => 'email-verification-page',
            ],
            [
                'id'            => 'email_verification_enabled',
                'legacy_key'    => [
                    'option' => 'dokan_email_verification',
                    'field'  => 'enabled',
                ],
                'type'          => 'field',
                'variant'       => 'switch',
                'section_id'    => 'email-verification',
                'title'         => esc_html__( 'Email Verification', 'dokan' ),
                'description'   => esc_html__( 'Requiring email verification after registration helps reduce fraudulent accounts.', 'dokan' ),
                'default'       => 'off',
                'enable_state'  => [
					'label' => esc_html__( 'Enabled', 'dokan' ),
					'value' => 'on',
				],
                'disable_state' => [
					'label' => esc_html__( 'Disabled', 'dokan' ),
					'value' => 'off',
				],
            ],
            [
                'id'         => 'registration-notice',
                'type'       => 'section',
                'subpage_id' => 'email-verification-page',
            ],
            [
                'id'          => 'registration_notice',
                'legacy_key' => [
                    'option' => 'dokan_email_verification',
                    'field'  => 'registration_notice',
                ],
                'type'        => 'field',
                'variant'     => 'textarea',
                'section_id'  => 'registration-notice',
                'title'       => esc_html__( 'Registration Notice', 'dokan' ),
                'placeholder' => esc_html__( 'Enter notice text...', 'dokan' ),
                'default'     => esc_html__( 'Please check your email and complete email verification to login.', 'dokan' ),
            ],
            [
                'id'         => 'login-notice',
                'type'       => 'section',
                'subpage_id' => 'email-verification-page',
            ],
            [
                'id'          => 'login_notice',
                'legacy_key' => [
                    'option' => 'dokan_email_verification',
                    'field'  => 'login_notice',
                ],
                'type'        => 'field',
                'variant'     => 'textarea',
                'section_id'  => 'login-notice',
                'title'       => esc_html__( 'Login Notice', 'dokan' ),
                'placeholder' => esc_html__( 'Enter notice text...', 'dokan' ),
                'default'     => esc_html__( 'Please check your email and complete email verification to login.', 'dokan' ),
            ],
        ];
    }

    /**
     * AiAssistSettings: Product Image Enhancement, injected into Lite's
     * AI Assist > Content Generation subpage (`product_generation`).
     *
     * Moved out of Lite's `SettingsSchema::ai_assist_page()`: the image engine
     * and per-provider API key/model fields depend on image providers that
     * only Pro registers. Reuses Lite's shared provider-group builder
     * (`SettingsSchema::ai_provider_group()`) so the per-provider shape stays
     * in lock-step with the Lite text-provider groups. Renders only when image
     * providers are registered.
     *
     * @return array
     */
    private static function ai_assist_settings(): array {
        $image_providers = \WeDevs\Dokan\Admin\Settings\Schema\SettingsSchema::resolve_ai_providers( 'image' );
        if ( empty( $image_providers ) ) {
            return [];
        }

        $on_enhance = [
            [
                'key'        => 'ai_product_image_enhancement',
                'value'      => 'on',
                'to_self'    => true,
                'attribute'  => 'display',
                'effect'     => 'show',
                'comparison' => '===',
            ],
            [
                'key'        => 'ai_product_image_enhancement',
                'value'      => 'on',
                'to_self'    => true,
                'attribute'  => 'display',
                'effect'     => 'hide',
                'comparison' => '!==',
            ],
        ];

        $when_engine = static function ( string $engine_key, string $value ): array {
            return [
                [
                    'key'        => $engine_key,
                    'value'      => $value,
                    'to_self'    => true,
                    'attribute'  => 'display',
                    'effect'     => 'show',
                    'comparison' => '===',
                ],
                [
                    'key'        => $engine_key,
                    'value'      => $value,
                    'to_self'    => true,
                    'attribute'  => 'display',
                    'effect'     => 'hide',
                    'comparison' => '!==',
                ],
            ];
        };

        $provider_options = [];
        foreach ( $image_providers as $id => $provider ) {
            $provider_options[] = [
                'title' => $provider->get_title(),
                'value' => (string) $id,
            ];
        }

        // Derive the default from the same registry that builds the options above.
        // A hardcoded id silently rots when a provider's registration changes —
        // OpenAI's image models are instantiated but never registered, so 'openai'
        // was a default this field could not offer. Prefer Gemini when present so
        // the default stays stable, and fall back to whatever is registered.
        $default_image_engine = isset( $image_providers['gemini'] )
            ? 'gemini'
            : (string) ( array_key_first( $image_providers ) ?? '' );

        $elements = [
            [
                'id'         => 'product_description_section',
                'type'       => 'section',
                'subpage_id' => 'product_generation',
            ],
            [
                'id'            => 'ai_product_image_enhancement',
                'type'          => 'field',
                'variant'       => 'switch',
                'section_id'    => 'product_description_section',
                'title'         => esc_html__( 'Product Image Enhancement', 'dokan' ),
                'description'   => esc_html__( 'Allow vendors to enhance and generate professional product images using AI.', 'dokan' ),
                'default'       => 'off',
                'enable_state'  => [
					'label' => esc_html__( 'Enabled', 'dokan' ),
					'value' => 'on',
				],
                'disable_state' => [
					'label' => esc_html__( 'Disabled', 'dokan' ),
					'value' => 'off',
				],
                'legacy_key'    => 'dokan_ai.dokan_ai_image_gen_availability',
            ],
            [
                'id'           => 'ai_product_image_engine',
                'type'         => 'field',
                'variant'      => 'select',
                'section_id'   => 'product_description_section',
                'title'        => esc_html__( 'Engine', 'dokan' ),
                'description'  => esc_html__( 'Select your AI provider for image processing and generation.', 'dokan' ),
                'default'      => $default_image_engine,
                'options'      => $provider_options,
                'legacy_key'   => 'dokan_ai.dokan_ai_image_engine',
                'dependencies' => $on_enhance,
            ],
        ];

        foreach ( $image_providers as $provider_id => $provider ) {
            $pid      = (string) $provider_id;
            $elements = array_merge(
                $elements,
                \WeDevs\Dokan\Admin\Settings\Schema\SettingsSchema::ai_provider_group(
                    [
                        'provider_id'     => $pid,
                        'provider'        => $provider,
                        'section_id'      => 'product_description_section',
                        'engine_field_id' => 'ai_product_image_engine',
                        'toggle_deps'     => $on_enhance,
                        'engine_deps'     => $when_engine( 'ai_product_image_engine', $pid ),
                        'api_key_legacy'  => 'dokan_ai.dokan_ai_image_' . $pid . '_api_key',
                        'model_legacy'    => 'dokan_ai.dokan_ai_image_' . $pid . '_model',
                        'model_kind'      => 'image',
                        'id_prefix'       => 'image',
                    ]
                )
            );
        }

        return $elements;
    }

    /**
     * Day-of-week select options, ordered to match the legacy admin UI.
     *
     * @return array<int,array{title:string,value:string}>
     */
    private static function day_of_week_options(): array {
        return [
            [
				'title' => esc_html__( 'Saturday', 'dokan' ),
				'value' => 'saturday',
			],
            [
				'title' => esc_html__( 'Sunday', 'dokan' ),
				'value' => 'sunday',
			],
            [
				'title' => esc_html__( 'Monday', 'dokan' ),
				'value' => 'monday',
			],
            [
				'title' => esc_html__( 'Tuesday', 'dokan' ),
				'value' => 'tuesday',
			],
            [
				'title' => esc_html__( 'Wednesday', 'dokan' ),
				'value' => 'wednesday',
			],
            [
				'title' => esc_html__( 'Thursday', 'dokan' ),
				'value' => 'thursday',
			],
            [
				'title' => esc_html__( 'Friday', 'dokan' ),
				'value' => 'friday',
			],
        ];
    }

    /**
     * Week-of-month select options used by monthly/quarterly schedules.
     *
     * Values match the legacy `dokan_withdraw.*_schedule.week` storage shape
     * (`1`..`4` or `L` for last week of month).
     *
     * @return array<int,array{title:string,value:string}>
     */
    private static function week_of_month_options(): array {
        return [
            [
				'title' => esc_html__( 'First week', 'dokan' ),
				'value' => '1',
			],
            [
				'title' => esc_html__( 'Second week', 'dokan' ),
				'value' => '2',
			],
            [
				'title' => esc_html__( 'Third week', 'dokan' ),
				'value' => '3',
			],
            [
				'title' => esc_html__( 'Fourth week', 'dokan' ),
				'value' => '4',
			],
            [
				'title' => esc_html__( 'Last week', 'dokan' ),
				'value' => 'L',
			],
        ];
    }

    /**
     * Month options scoped to a single calendar quarter (1..4).
     *
     * Values use lowercase month names to match the legacy
     * `dokan_withdraw.quarterly_schedule.month` enum.
     *
     * @param int $quarter 1, 2, 3, or 4.
     * @return array<int,array{title:string,value:string}>
     */
    private static function quarter_month_options( int $quarter ): array {
        $quarters = [
            1 => [
                'january'  => esc_html__( 'January', 'dokan' ),
                'february' => esc_html__( 'February', 'dokan' ),
                'march'    => esc_html__( 'March', 'dokan' ),
            ],
            2 => [
                'april' => esc_html__( 'April', 'dokan' ),
                'may'   => esc_html__( 'May', 'dokan' ),
                'june'  => esc_html__( 'June', 'dokan' ),
            ],
            3 => [
                'july'      => esc_html__( 'July', 'dokan' ),
                'august'    => esc_html__( 'August', 'dokan' ),
                'september' => esc_html__( 'September', 'dokan' ),
            ],
            4 => [
                'october'  => esc_html__( 'October', 'dokan' ),
                'november' => esc_html__( 'November', 'dokan' ),
                'december' => esc_html__( 'December', 'dokan' ),
            ],
        ];

        $months = $quarters[ $quarter ] ?? [];

        return array_values(
            array_map(
                static fn( $value, $title ) => [
					'title' => $title,
					'value' => $value,
				],
                array_keys( $months ),
                array_values( $months )
            )
        );
    }

    /**
     * Standard dependency clause: visible only when `quarterly_withdraw === on`.
     *
     * Returned fresh on each call so the resulting structure can be safely
     * embedded in multiple field declarations without aliasing.
     *
     * @return array<int,array<string,mixed>>
     */
    private static function quarterly_dependency(): array {
        return [
            [
                'key'        => 'quarterly_withdraw',
                'value'      => 'on',
                'to_self'    => true,
                'attribute'  => 'display',
                'effect'     => 'show',
                'comparison' => '===',
            ],
        ];
    }

    /**
     * Dependency clause shared by the 4 schedule fieldgroups (Weekly, Monthly,
     * Biweekly, Quarterly): the whole group is visible only when the parent
     * "Schedule Disbursement" toggle is enabled.
     *
     * @return array<int,array<string,mixed>>
     */
    private static function schedule_disbursement_dependency(): array {
        return [
            [
                'key'        => 'schedule_disbursement_enabled',
                'value'      => 'on',
                'to_self'    => true,
                'attribute'  => 'display',
                'effect'     => 'show',
                'comparison' => '===',
            ],
        ];
    }

    /**
     * Dependency clause for a social login provider's nested fields: each
     * credential/notice field inside a provider card is visible only when that
     * provider's own enable toggle is on (e.g. Facebook fields show when the
     * Facebook card is enabled).
     *
     * Returned fresh on each call so the resulting structure can be safely
     * embedded in multiple field declarations without aliasing.
     *
     * @param string $enable_id Provider enable toggle field id (e.g. vso_facebook_enabled).
     *
     * @return array<int,array<string,mixed>>
     */
    private static function social_provider_field_dependency( string $enable_id ): array {
        return [
            [
                'key'        => $enable_id,
                'value'      => 'on',
                'to_self'    => true,
                'attribute'  => 'display',
                'effect'     => 'show',
                'comparison' => '===',
            ],
        ];
    }
}
