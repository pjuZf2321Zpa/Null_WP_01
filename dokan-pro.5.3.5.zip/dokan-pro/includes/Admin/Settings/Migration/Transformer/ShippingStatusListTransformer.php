<?php

namespace WeDevs\DokanPro\Admin\Settings\Migration\Transformer;

use WeDevs\Dokan\Admin\Settings\Migration\Transformer\TransformerInterface;

/**
 * Reshapes the shipment status list between the new repeater rows and the legacy
 * `shipping_status_list` shape.
 *
 * Legacy rows: `[ 'id' => <slug>, 'value' => <label>, 'must_use' => true, 'desc' => ... ]`
 * (the consumer reads `id` + `value`; `must_use`/`desc` mark protected rows).
 *
 * New repeater rows: `[ 'id' => <slug>, 'title' => <label>, 'order' => <int>, 'required' => bool ]`.
 *
 * The label lives under `value` legacy-side and `title` new-side, so without this
 * transform edits/adds made in the new UI never reach the `value` the frontend
 * reads. `required` ⇄ `must_use` keeps the must-have rows locked.
 *
 * @since 5.2.0
 */
final class ShippingStatusListTransformer implements TransformerInterface {

    /**
     * {@inheritDoc}
     *
     * @param mixed $legacy_value Array of `[ 'id', 'value', 'must_use'?, 'desc'? ]` rows.
     *
     * @return array<int,array{id:string,title:string,order:int,required:bool}>
     */
    public function to_new( $legacy_value ) {
        if ( ! is_array( $legacy_value ) ) {
            return [];
        }

        $out   = [];
        $order = 1;
        foreach ( $legacy_value as $row ) {
            if ( ! is_array( $row ) ) {
                continue;
            }
            $label = (string) ( $row['value'] ?? $row['title'] ?? '' );
            $out[] = [
                'id'       => (string) ( $row['id'] ?? sanitize_title( $label ) ),
                'title'    => $label,
                'order'    => $order++,
                'required' => $this->is_required( $row ),
            ];
        }

        return $out;
    }

    /**
     * {@inheritDoc}
     *
     * @param mixed $new_value Array of `[ 'id', 'title', 'order', 'required' ]` rows.
     *
     * @return array<int,array{id:string,value:string,must_use?:bool,desc?:string}>
     */
    public function to_legacy( $new_value ) {
        if ( ! is_array( $new_value ) ) {
            return [];
        }

        // Decorate with the array position so the sort is stable on PHP 7.4.
        $decorated = [];
        $position  = 0;
        foreach ( $new_value as $row ) {
            if ( ! is_array( $row ) ) {
                continue;
            }
            $decorated[] = [
                'order' => isset( $row['order'] ) ? (int) $row['order'] : $position,
                'pos'   => $position,
                'row'   => $row,
            ];
            ++$position;
        }

        usort(
            $decorated,
            static function ( $a, $b ) {
                return [ $a['order'], $a['pos'] ] <=> [ $b['order'], $b['pos'] ];
            }
        );

        $out = [];
        foreach ( $decorated as $item ) {
            $row   = $item['row'];
            $label = (string) ( $row['title'] ?? $row['value'] ?? '' );
            $leg   = [
                'id'    => (string) ( $row['id'] ?? sanitize_title( $label ) ),
                'value' => $label,
            ];
            if ( $this->is_required( $row ) ) {
                $leg['must_use'] = true;
                $leg['desc']     = __( '(This is must use item)', 'dokan' );
            }
            $out[] = $leg;
        }

        return $out;
    }

    /**
     * Whether a row is a protected ("must use") status, reading either shape.
     *
     * @param array<string,mixed> $row
     *
     * @return bool
     */
    private function is_required( array $row ): bool {
        if ( ! empty( $row['required'] ) ) {
            return true;
        }
        return ! empty( $row['must_use'] ) && 'false' !== $row['must_use'];
    }
}
