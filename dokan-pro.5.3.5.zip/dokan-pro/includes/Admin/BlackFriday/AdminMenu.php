<?php

namespace WeDevs\DokanPro\Admin\BlackFriday;

use WeDevs\Dokan\Admin\Dashboard\Pages\AbstractPage;
use WeDevs\Dokan\Admin\Dashboard\Pages\BlackFriday;

/**
 * Black Friday / Cyber Monday upgrade page for Pro customers.
 *
 * Dokan Lite owns the "Black Friday" submenu entry (see {@see BlackFriday}); this page swaps the
 * Lite "buy Pro" content for the Pro upgrade and add-on offers on the same `#/black-friday` route.
 *
 * @since 5.3.5
 *
 * @todo BFCM-2026-REMOVE: seasonal Black Friday / Cyber Monday page. Remove manually after the campaign ends (Dec 5, 2026); nothing switches itself off.
 */
class AdminMenu extends AbstractPage {

    /**
     * Script and style handle.
     *
     * @since 5.3.5
     */
    const HANDLE = 'dokan-pro-black-friday';

    /**
     * Register hooks.
     *
     * @since 5.3.5
     *
     * @return void
     */
    public function register_hooks(): void {
        // Older Lite builds have no campaign page to replace.
        if ( ! class_exists( BlackFriday::class ) ) {
            return;
        }

        parent::register_hooks();

        add_filter( 'dokan_black_friday_pro_page', '__return_true' );
        add_filter( 'dokan_admin_submenu_tail_routes', [ $this, 'add_tail_route' ] );
    }

    /**
     * Keep the entry right above "Settings" when Pro reorders the Dokan submenu.
     *
     * @since 5.3.5
     *
     * @param string[] $routes URL fragments moved to the submenu tail, in order.
     *
     * @return string[]
     */
    public function add_tail_route( array $routes ): array {
        $settings = array_search( '#/settings', $routes, true );

        array_splice( $routes, false === $settings ? count( $routes ) : $settings, 0, [ '#/' . BlackFriday::ROUTE ] );

        return $routes;
    }

    /**
     * @inheritDoc
     */
    public function get_id(): string {
        return 'black-friday-pro';
    }

    /**
     * The submenu entry comes from Lite.
     *
     * @inheritDoc
     */
    public function menu( string $capability, string $position ): array {
        return [];
    }

    /**
     * @inheritDoc
     */
    public function settings(): array {
        $mobile_app_url = 'https://dokan.co/wordpress/dokan-mobile-app/';

        return [
            'assets_url' => DOKAN_PLUGIN_ASSEST . '/images/black-friday',
            'urls'       => [
                'upgrade'      => BlackFriday::cta_url( 'upgrade-' . dokan_pro()->license->get_plan(), 'https://dokan.co/wordpress/pro-user-vip-deals/' ),
                'customer_app' => BlackFriday::cta_url( 'customer-app', $mobile_app_url ),
                'vendor_app'   => BlackFriday::cta_url( 'vendor-app', 'https://dokan.co/vendor-mobile-app/pricing/' ),
                'wepos'        => BlackFriday::cta_url( 'wepos', 'https://wedevs.com/wepos/pricing/' ),
                'book_call'    => BlackFriday::cta_url( 'book-a-call', 'https://calendly.com/dokan-support/30min?back=1' ),
            ],
        ];
    }

    /**
     * @inheritDoc
     */
    public function scripts(): array {
        return [ self::HANDLE ];
    }

    /**
     * @inheritDoc
     */
    public function styles(): array {
        return [ self::HANDLE ];
    }

    /**
     * Register the page script and stylesheet.
     *
     * @since 5.3.5
     *
     * @return void
     */
    public function register(): void {
        $asset_file = DOKAN_PRO_DIR . '/assets/js/admin-black-friday.asset.php';

        if ( ! file_exists( $asset_file ) ) {
            return;
        }

        $asset = include $asset_file;

        wp_register_script(
            self::HANDLE,
            DOKAN_PRO_PLUGIN_ASSEST . '/js/admin-black-friday.js',
            $asset['dependencies'],
            $asset['version'],
            [
                'strategy'  => 'defer',
                'in_footer' => true,
            ]
        );

        wp_set_script_translations( self::HANDLE, 'dokan' );

        wp_register_style(
            self::HANDLE,
            DOKAN_PRO_PLUGIN_ASSEST . '/js/admin-black-friday.css',
            [ 'dokan-pro-tailwind' ],
            $asset['version']
        );
        wp_style_add_data( self::HANDLE, 'rtl', 'replace' );
    }
}
