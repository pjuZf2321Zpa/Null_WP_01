<?php

namespace WeDevs\DokanPro\Admin;

/**
 * Dokan tinyMce Shortcode Button class
 *
 * @since 2.4.12
 */
class ShortcodesButton {

    /**
     * Constructor for shortcode class
     */
    public function __construct() {
        add_filter( 'mce_external_plugins', array( $this, 'enqueue_plugin_scripts' ) );
        add_filter( 'mce_buttons', array( $this, 'register_buttons_editor' ) );

        add_action( 'admin_enqueue_scripts', array( $this, 'localize_shortcodes' ), 90 );
    }

    /**
     * Get the Dokan shortcodes offered by the editor button and the shortcode block.
     *
     * @since 5.0.14
     *
     * @return array
     */
    public static function get_shortcodes() {
        $shortcodes = array(
            'dokan-dashboard'            => array(
                'title'   => __( 'Vendor Dasboard', 'dokan' ),
                'content' => '[dokan-dashboard]',
            ),
            'vendor-registration' => array(
                'title'   => __( 'Vendor Registration Form', 'dokan' ),
                'content' => '[dokan-vendor-registration]',
            ),
            'dokan-stores'               => array(
                'title'   => __( 'Stores List', 'dokan' ),
                'content' => '[dokan-stores]',
            ),
            'dokan-best-selling-product' => array(
                'title'   => __( 'Best Selling Product', 'dokan' ),
                'content' => '[dokan-best-selling-product no_of_product="5" seller_id="" ]',
            ),
            'dokan-top-rated-product'    => array(
                'title'   => __( 'Top Rated Products', 'dokan' ),
                'content' => '[dokan-top-rated-product]',
            ),
            'dokan-my-orders' => array(
                'title'   => __( 'Dokan My Orders', 'dokan' ),
                'content' => '[dokan-my-orders]',
            ),
            'dokan-customer-migration' => array(
                'title'   => __( 'Customer Migration Form', 'dokan' ),
                'content' => '[dokan-customer-migration]',
            ),
            'dokan-vendor-onboarding-registration' => array(
                'title'   => __( 'Vendor Onboarding', 'dokan' ),
                'content' => '[dokan-vendor-onboarding-registration]',
            ),
        );

        // Filtered here so every consumer shares one list instead of repeating the filter call.
        $shortcodes = apply_filters( 'dokan_button_shortcodes', $shortcodes );

        return $shortcodes;
    }

    /**
     * Localize the shortcode list for the classic editor button.
     *
     * @since 2.4.12
     */
    public function localize_shortcodes() {
        $screen = get_current_screen();

        if ( $screen && ( 'page' === $screen->post_type || 'product' === $screen->post_type ) ) {
            $assets_url = DOKAN_PRO_PLUGIN_ASSEST;

            wp_localize_script( 'dokan_pro_admin', 'dokan_shortcodes', self::get_shortcodes() );
            wp_add_inline_script( 'dokan_pro_admin', "var dokan_assets_url = \"{$assets_url}\";" );
        }
    }

    /**
     * * Singleton object
     *
     * @staticvar boolean $instance
     *
     * @return \self
     */
    public static function init() {
        static $instance = false;

        if ( ! $instance ) {
            $instance = new ShortcodesButton();
        }

        return $instance;
    }

    /**
     * Add button on Post Editor
     *
     * @since 2.4.12
     *
     * @param array $plugin_array
     *
     * @return array
     */
    public function enqueue_plugin_scripts( $plugin_array ) {
        //enqueue TinyMCE plugin script with its ID.
        $screen = get_current_screen();

        list( $suffix ) = dokan_get_script_suffix_and_version();

        if ( $screen && ( 'page' === $screen->post_type || 'product' === $screen->post_type ) ) {
            $plugin_array['dokan_button'] = DOKAN_PRO_PLUGIN_ASSEST . '/js/dokan-tinymce-button' . $suffix . '.js';
        }

        return $plugin_array;
    }

    /**
     * Register tinyMce button
     *
     * @since 2.4.12
     *
     * @param array $buttons
     *
     * @return array
     */
    public function register_buttons_editor( $buttons ) {
        //register buttons with their id.
        array_push( $buttons, 'dokan_button' );

        return $buttons;
    }
}
