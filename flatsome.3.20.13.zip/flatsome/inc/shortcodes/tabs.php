<?php
// [tabgroup]
function ux_tabgroup( $params, $content = null, $tag = '' ) {
	$GLOBALS['tabs'] = array();
	$GLOBALS['tab_count'] = 0;
	$i = 1;

	extract(shortcode_atts(array(
		'id' => 'panel-'.rand(),
		'title' => '',
		'style' => 'line',
		'align' => 'left',
		'class' => '',
		'visibility' => '',
		'type' => '', // horizontal, vertical
		'nav_style' => 'uppercase',
		'nav_size' => 'normal',
		'history' => 'false',
		'event' => '',
	), $params));

	if($tag == 'tabgroup_vertical'){
		$type = 'vertical';
	}

	$content = do_shortcode( $content );

	$wrapper_class[] = 'tabbed-content';
	if ( $class ) $wrapper_class[] = $class;
  if ( $visibility ) $wrapper_class[] = $visibility;

	$classes[] = 'nav';

	if($style) $classes[] = 'nav-'.$style;
	if($type == 'vertical') $classes[] = 'nav-vertical';
	if($nav_style) $classes[] = 'nav-'.$nav_style;
	if($nav_size) $classes[] = 'nav-size-'.$nav_size;
	if($align) $classes[] = 'nav-'.$align;
	if($event) $classes[] = 'active-on-' . $event;


	$classes = implode(' ', $classes);

	$return = '';

	if( is_array( $GLOBALS['tabs'] )){

		$tabs  = array();
		$panes = array();

		foreach( $GLOBALS['tabs'] as $key => $tab ){
			if ( ! empty( $tab['anchor'] ) ) {
				$id = flatsome_to_dashed( $tab['anchor'] );
				$anchor = rawurlencode( $tab['anchor'] );
			} else {
				$id = $tab['title'] ? flatsome_to_dashed( $tab['title'] ) : wp_rand();
				$anchor = "tab_$id";
			}
			$active = $key == 0 ? ' active' : ''; // Set first tab active by default.
			$tabs[] = '<li id="' . esc_attr( 'tab-' . $id ) . '" class="tab' . $active . ' has-icon" role="presentation"><a href="#' . esc_attr( $anchor ) . '"' . ( $key != 0 ? ' tabindex="-1"' : '' ) . ' role="tab" aria-selected="' . ( $key == 0 ? 'true' : 'false' ) . '" aria-controls="' . esc_attr( 'tab_' . $id ) . '"><span>' . wp_kses_post( $tab['title'] ) . '</span></a></li>';
			$panes[] = '<div id="' . esc_attr( 'tab_' . $id ) . '" class="panel' . $active . ' entry-content" role="tabpanel" aria-labelledby="' . esc_attr( 'tab-' . $id ) . '">' . do_shortcode( $tab['content'] ) . '</div>';
			$i++;
		}
			if($title) $title = '<h4 class="uppercase text-' . esc_attr( $align ) . '">' . wp_kses_post( $title ) . '</h4>';
			$return = '
		<div class="' . esc_attr( implode( ' ', $wrapper_class ) ) . '">
			'.$title.'
			<ul class="' . esc_attr( $classes ) . '" role="tablist">'.implode( "\n", $tabs ).'</ul><div class="tab-panels">'.implode( "\n", $panes ).'</div></div>';
	}


	return $return;
}

function ux_tab( $params, $content = null) {
	extract(shortcode_atts(array(
			'title' => '',
			'anchor' => ''
	), $params));

	$x = $GLOBALS['tab_count'];
	$GLOBALS['tabs'][ $x ] = array( 'title' => $title, 'anchor' => $anchor, 'content' => $content );
	$GLOBALS['tab_count']++;
}


add_shortcode('tabgroup', 'ux_tabgroup');
add_shortcode('tabgroup_vertical', 'ux_tabgroup');
add_shortcode('tab', 'ux_tab' );
