<?php

// Remove Default links
remove_action( 'woocommerce_before_shop_loop_item','woocommerce_template_loop_product_link_open', 10);
remove_action( 'woocommerce_after_shop_loop_item','woocommerce_template_loop_product_link_close', 5);


/* Move Sale Flash */
remove_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_show_product_loop_sale_flash', 10);
add_action( 'woocommerce_before_shop_loop_item', 'woocommerce_show_product_loop_sale_flash', 10);


/**
 * Gets products per page count from theme settings.
 */
function flatsome_product_pr_page() {
	return get_theme_mod( 'products_pr_page', 12 );
}
add_filter( 'loop_shop_per_page', 'flatsome_product_pr_page', 20 );

/**
 * Gets base desktop row count from theme settings.
 */
function flatsome_category_row_count() {
	return get_theme_mod( 'category_row_count', 3 );
}
add_filter( 'loop_shop_columns', 'flatsome_category_row_count', 20 );


/* Set WooCommerce product loop classes */
function flatsome_product_row_classes($cols = null){
    $classes = array('row','row-small');

	$category_grid_style = get_theme_mod( 'category_grid_style', 'grid' );

    if($category_grid_style == 'masonry'){
      wp_enqueue_script('flatsome-masonry-js');
      $classes[] = 'row-masonry has-packery';
    }

    if(get_theme_mod('category_grid_style') == 'list'){
        $classes[] = 'has-box-vertical';
    }

	$columns = get_theme_mod( 'category_row_count', 3 );

    if($cols) $columns = $cols;
	if ( is_cart() ) $columns = apply_filters( 'woocommerce_cross_sells_columns', 4 );

    $classes[] = 'large-columns-'.$columns;
	$classes[] = 'medium-columns-' . get_theme_mod( 'category_row_count_tablet', 3 );
	$classes[] = 'small-columns-' . get_theme_mod( 'category_row_count_mobile', 2 );

	$shadow       = get_theme_mod( 'category_shadow', 0 );
	$shadow_hover = get_theme_mod( 'category_shadow_hover', 0 );

    if($shadow || $shadow_hover) $classes[] = 'has-shadow';
    if($shadow) $classes[] = 'row-box-shadow-'.$shadow;
    if($shadow_hover) $classes[] = 'row-box-shadow-'.$shadow_hover.'-hover';

    // Custom heights
    if(get_theme_mod('category_force_image_height')) {
      $classes[] = 'has-equal-box-heights';
    }

	if ( get_theme_mod( 'equalize_product_box' ) ) {
		$classes[] = 'equalize-box';
	}

    return implode(' ', $classes);
}

function flatsome_products_footer_content(){
    if(is_product_category() || is_product_tag()){
      $queried_object = get_queried_object();
      $content = get_term_meta($queried_object->term_id, 'cat_meta');
        if(!empty($content[0]['cat_footer'])){
            echo '<hr/>';
            echo do_shortcode($content[0]['cat_footer']);
        }
    }
}
add_action('flatsome_products_after','flatsome_products_footer_content');


/* Add Custom Meta to Category */
if(is_admin()){
    if(function_exists('get_term_meta')){
    function top_text_taxonomy_edit_meta_field($term) {
        // put the term ID into a variable
        $t_id = $term->term_id;
        // retrieve the existing value(s) for this meta field. This returns an array
        $term_meta = get_term_meta($t_id,'cat_meta');
        if(!$term_meta){$term_meta = add_term_meta($t_id, 'cat_meta', '');}
         ?>
        <tr class="form-field">
        <th scope="row" valign="top"><label for="term_meta[cat_header]"><?php _e( 'Top Content', 'flatsome' ); ?></label></th>
            <td>
                    <?php
                    $content = esc_attr( isset($term_meta[0]['cat_header']) ) ? esc_attr( $term_meta[0]['cat_header'] ) : '';
                    echo '<textarea id="term_meta[cat_header]" name="term_meta[cat_header]">'.$content.'</textarea>'; ?>
                <p class="description"><?php _e( 'Enter a value for this field. Shortcodes are allowed. This will be displayed at top of the category.','flatsome' ); ?></p>
            </td>
        </tr>
    <?php
    }
    add_action( 'product_cat_edit_form_fields', 'top_text_taxonomy_edit_meta_field', 10, 2 );
    add_action( 'product_tag_edit_form_fields', 'top_text_taxonomy_edit_meta_field', 10, 2 );

    /* ADD CUSTOM META BOX TO CATEGORY PAGES */
    function bottom_text_taxonomy_edit_meta_field($term) {
      // put the term ID into a variable
      $t_id = $term->term_id;
      // retrieve the existing value(s) for this meta field. This returns an array
      $term_meta = get_term_meta($t_id,'cat_meta');
      if(!$term_meta){$term_meta = add_term_meta($t_id, 'cat_meta', '');}
       ?>
      <tr class="form-field">
      <th scope="row" valign="top"><label for="term_meta[cat_footer]"><?php _e( 'Bottom Content', 'flatsome' ); ?></label></th>
        <td>
            <?php
            $content = isset($term_meta[0]['cat_footer']) ? esc_attr( $term_meta[0]['cat_footer'] ) : '';
            echo '<textarea id="term_meta[cat_footer]" name="term_meta[cat_footer]">'.$content.'</textarea>'; ?>
          <p class="description"><?php _e( 'Enter a value for this field. Shortcodes are allowed. This will be displayed at bottom of the category.','flatsome' ); ?></p>
        </td>
      </tr>
    <?php
    }
    add_action( 'product_cat_edit_form_fields', 'bottom_text_taxonomy_edit_meta_field', 10, 2 );
    add_action( 'product_tag_edit_form_fields', 'bottom_text_taxonomy_edit_meta_field', 10, 2 );

	    function flatsome_custom_product_page_taxonomy_edit_meta_field( $term ) {
		    $t_id = $term->term_id;
		    // retrieve the existing value(s) for this meta field. This returns an array
		    $term_meta = get_term_meta( $t_id, 'cat_meta' );
		    if ( ! $term_meta ) {
			    $term_meta = add_term_meta( $t_id, 'cat_meta', '' );
		    }
		    ?>
		    <tr class="form-field">
			    <th scope="row" valign="top"><label for="term_meta[cat_product_block]"><?php _e( 'Custom product layout', 'flatsome' ); ?></label></th>
			    <td>
				    <?php
				    $selected = esc_attr( isset( $term_meta[0]['cat_product_block'] ) ) ? esc_attr( $term_meta[0]['cat_product_block'] ) : 0;
				    wp_dropdown_pages( array(
					    'id'               => 'term_meta[cat_product_block]',
					    'name'             => 'term_meta[cat_product_block]',
					    'post_type'        => 'blocks',
					    'show_option_none' => '-- None --',
					    'selected'         => $selected,
				    ) ); ?>
				    <p class="description"><?php _e( 'Choose a custom product block layout for this category.', 'flatsome' ); ?></p>
			    </td>
		    </tr>
		    <?php

	    }

	    add_action( 'product_cat_edit_form_fields', 'flatsome_custom_product_page_taxonomy_edit_meta_field', 10 );

    /* SAVE CUSTOM META*/
    function fl_save_taxonomy_custom_meta( $term_id ) {
        if ( isset( $_POST['term_meta'] ) ) {
            $t_id = $term_id;
            $cat_keys = array_keys( $_POST['term_meta'] );
            foreach ( $cat_keys as $key ) {
                if ( isset ( $_POST['term_meta'][$key] ) ) {
                    $term_meta[$key] = $_POST['term_meta'][$key];
                }
            }
            // Save the option array.
            update_term_meta($term_id, 'cat_meta', $term_meta);
        }
    }
    add_action( 'edited_product_cat', 'fl_save_taxonomy_custom_meta', 10, 2 );
    add_action( 'edited_product_tag', 'fl_save_taxonomy_custom_meta', 10, 2 );

    }
} // is_admin
