<?php
/**
 * Checkout terms and conditions area.
 *
 * @package          WooCommerce/Templates
 * @version          3.4.0
 * @flatsome-version 3.18.0
 */

defined( 'ABSPATH' ) || exit;

if ( apply_filters( 'woocommerce_checkout_show_terms', true ) && function_exists( 'wc_terms_and_conditions_checkbox_enabled' ) ) {
	do_action( 'woocommerce_checkout_before_terms_and_conditions' );

	?>
	<div class="woocommerce-terms-and-conditions-wrapper mb-half">
		<?php
		/**
		 * Terms and conditions hook used to inject content.
		 *
		 * @since 3.4.0.
		 * @hooked wc_checkout_privacy_policy_text() Shows custom privacy policy text. Priority 20.
		 * @hooked wc_terms_and_conditions_page_content() Shows t&c page content. Priority 30.
		 */
		do_action( 'woocommerce_checkout_terms_and_conditions' );
		?>

		<?php if ( wc_terms_and_conditions_checkbox_enabled() ) : ?>
			<p class="form-row validate-required">
				<label class="woocommerce-form__label woocommerce-form__label-for-checkbox checkbox">
				<input type="checkbox" class="woocommerce-form__input woocommerce-form__input-checkbox input-checkbox" name="terms" <?php checked( apply_filters( 'woocommerce_terms_is_checked_default', isset( $_POST['terms'] ) ), true ); // phpcs:ignore WordPress.Security.NonceVerification.Missing, WooCommerce.Commenting.CommentHooks.MissingHookComment -- Presence check only, used to re-render the checkbox; WC_Checkout::process_checkout() verifies the checkout nonce. A docblock cannot precede this inline call without changing the rendered markup. ?> id="terms" />
					<?php if ( $link_style = get_theme_mod( 'checkout_terms_and_conditions' ) ) : ?>
						<span class="woocommerce-terms-and-conditions-checkbox-text"><?php flatsome_terms_and_conditions_checkbox_text( $link_style ); ?></span>&nbsp;<span class="required">*</span>
					<?php else : ?>
						<span class="woocommerce-terms-and-conditions-checkbox-text"><?php wc_terms_and_conditions_checkbox_text(); ?></span>&nbsp;<span class="required">*</span>
					<?php endif; ?>
				</label>
				<input type="hidden" name="terms-field" value="1" />
			</p>
		<?php endif; ?>
	</div>
	<?php

	do_action( 'woocommerce_checkout_after_terms_and_conditions' );
}
