<?php
/**
 * Popup Dynamic Link compatibility
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

if ( ! class_exists( 'Jet_Engine_Popup_Dynamic_Link' ) ) {

	/**
	 * Define Jet_Engine_Popup_Dynamic_Link class
	 */
	class Jet_Engine_Popup_Dynamic_Link {

		private $dynamic_link_source = 'open_jet_popup';
		private $dynamic_link_popups = array();

		public function __construct() {

			add_action( 'jet-engine/listings/dynamic-link/source-controls', array( $this, 'link_controls' ) );

			add_filter( 'jet-engine/listings/dynamic-link/custom-attrs', array( $this, 'add_custom_dynlink_attrs' ), 10, 2 );

			add_filter( 'jet-popup/popup-generator/defined-popup-list', array( $this, 'ensure_popups' ) );

			add_filter( 'jet-popup/ajax-request/post-data', array( $this, 'maybe_apply_query_vars' ) );

			add_filter( 'jet-engine/listings/dynamic-link/custom-url', array( $this, 'dynamic_link_url' ), 10, 3 );

			add_filter( 'jet-engine/blocks-views/editor-data', array( $this, 'block_editor_data' ) );

			add_filter( 'jet-engine/blocks-views/block-types/attributes/dynamic-link', array( $this, 'block_attributes' ) );

		}

		public function block_attributes( $attrs ) {
			$attrs['open_jet_popup_popup_id'] = array(
				'type'    => 'string',
				'default' => '',
			);

			return $attrs;
		}

		public function dynamic_link_url( $url, $settings, $link ) {
			$source = $settings['dynamic_link_source'] ?? '';

			if ( $source !== $this->dynamic_link_source ) {
				return $url;
			}

			$settings['dynamic_link_source'] = '_permalink';

			return $link->get_link_url( $settings );
		}

		public function ensure_popups( $popups ) {
			$popups = array_merge( $popups, $this->dynamic_link_popups );
			return $popups;
		}

		public function add_custom_dynlink_attrs( $attrs, $link ) {
			$settings = $link->get_settings();

			$source = $settings['dynamic_link_source'] ?? '';

			if ( $source !== $this->dynamic_link_source ) {
				return $attrs;
			}

			$popup_id = $settings['open_jet_popup_popup_id'] ?? '';

			if ( ! $popup_id || ! get_post( $popup_id ) ) {
				return $attrs;
			}

			$new_attrs = array(
				'data-popup-instance' => $popup_id,
				'data-popup-trigger-type' => 'click-self',
				'data-is-dynamic-link-popup' => 1,
				'data-popup-is-jet-engine' => 1,
			);

			$query_args = ! empty( $settings['add_query_args'] ) ? ( $settings['query_args'] ?? '' ) : '';

			if ( ! isset( $this->dynamic_link_popups[ $popup_id ] ) ) {
				$popup_settings = jet_popup()->settings->get_popup_settings( $popup_id );

				if ( ! empty( $query_args ) ) {
					$popup_settings['jet_popup_use_ajax'] = true;
					$popup_settings['jet_popup_force_ajax'] = true;
				}
				
				$this->dynamic_link_popups[ $popup_id ] = array(
					'id'       => $popup_id,
					'settings' => $popup_settings,
				);
			}

			$attr_string = '';

			foreach ( $new_attrs as $key => $value ) {
				$attr_string .= sprintf( '%s="%s"', $key, $value );
			}

			return $attrs . $attr_string;
		}

		public function link_controls( $widget ) {

			$this->add_control( $widget, array(
				'group'     => 'links',
				'condition' => array(
					'dynamic_link_source' => $this->dynamic_link_source,
				),
				'id' => 'open_jet_popup_popup_id',
			) );

		}

		public function add_control( $widget = null, $args = array() ) {

			$group     = isset( $args['group'] ) ? $args['group'] : 'fields';
			$condition = isset( $args['condition'] ) ? $args['condition'] : array();
			$id        = isset( $args['id'] ) ? $args['id'] : 'mb_field_key';

			$popups = \Jet_Popup_Utils::get_posts_by_type( 'jet-popup', '', [], false );
			array_unshift( $popups, array( 'value' => '', 'label' => 'Select...' ) );
			
			$popups = array_column( $popups, 'label', 'value' );

			$widget->add_control(
				$id,
				array(
					'label'     => __( 'Popup', 'jet-engine' ),
					'type'      => 'select',
					'default'   => '',
					'options'    => $popups,
					'condition' => $condition,
				)
			);

		}

		public function block_editor_data( $data ) {
			$popups = \Jet_Popup_Utils::get_posts_by_type( 'jet-popup', '', [], false );
			array_unshift( $popups, array( 'value' => '', 'label' => 'Select...' ) );

			$data['popupList'] = $popups;
			return $data;
		}

		public function maybe_apply_query_vars( $popup_data ) {
			
			if ( empty( $popup_data['dynlink_url'] ) ) {
				return $popup_data;
			}

			$url = $popup_data['dynlink_url'];
			$query = parse_url($url, PHP_URL_QUERY);
			parse_str($query, $params);

			foreach ( $params as $name => $value ) {
				if ( ! isset( $_REQUEST[ $name ] ) ) {
					$_REQUEST[ $name ] = $value;
				}

				if ( ! isset( $_GET[ $name ] ) ) {
					$_GET[ $name ] = $value;
				}
			}

			return $popup_data;
		}

	}

}
