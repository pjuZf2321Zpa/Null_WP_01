<?php
/**
 * Shared separate-field mirrors for repeater values.
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

if ( ! class_exists( 'Jet_Engine_Repeater_Utils' ) ) {
	require_once jet_engine()->plugin_path( 'includes/components/meta-boxes/repeater-utils.php' );
}

if ( ! class_exists( 'Jet_Engine_Repeater_Separate_Fields' ) ) {

	class Jet_Engine_Repeater_Separate_Fields {

		public static function get_field_key( $path, $args = array() ) {

			$args = wp_parse_args( $args, array(
				'host'          => '',
				'object_id'     => 0,
				'top_key'       => isset( $path[0] ) ? $path[0] : '',
				'leaf_key'      => ! empty( $path ) ? end( $path ) : '',
				'field'         => array(),
				'legacy_filter' => '',
			) );

			$key = implode( '_', $path );

			if ( 2 === count( $path ) && ! empty( $args['legacy_filter'] ) ) {
				$key = apply_filters( $args['legacy_filter'], $key, $args['top_key'], $args['leaf_key'] );
			}

			return apply_filters(
				'jet-engine/repeater/separate-field-key',
				$key,
				$path,
				$args['host'],
				$args['object_id'],
				$args['top_key'],
				$args['leaf_key'],
				$args['field']
			);
		}

		public static function delete( $object_id, $top_key, $field, $delete_callback, $args = array() ) {

			if ( ! is_callable( $delete_callback ) ) {
				return;
			}

			$leaves = Jet_Engine_Repeater_Utils::collect_scalar_leaf_values_from_schema( $field, $top_key );

			foreach ( $leaves as $leaf ) {
				call_user_func(
					$delete_callback,
					$object_id,
					self::get_field_key( $leaf['path'], array_merge( $args, array(
						'object_id' => $object_id,
						'top_key'   => $top_key,
						'leaf_key'  => end( $leaf['path'] ),
						'field'     => $leaf['field'],
					) ) )
				);
			}
		}

		public static function save( $object_id, $top_key, $value, $field, $delete_callback, $add_callback, $args = array() ) {

			self::delete( $object_id, $top_key, $field, $delete_callback, $args );

			if ( empty( $value ) || ! is_array( $value ) || ! is_callable( $add_callback ) ) {
				return;
			}

			$leaf_values = Jet_Engine_Repeater_Utils::collect_scalar_leaf_values( $value, $field, $top_key );

			foreach ( $leaf_values as $leaf ) {
				$key = self::get_field_key( $leaf['path'], array_merge( $args, array(
					'object_id' => $object_id,
					'top_key'   => $top_key,
					'leaf_key'  => end( $leaf['path'] ),
					'field'     => $leaf['field'],
				) ) );

				foreach ( $leaf['value'] as $leaf_value ) {
					call_user_func( $add_callback, $object_id, $key, $leaf_value );
				}
			}
		}
	}
}
