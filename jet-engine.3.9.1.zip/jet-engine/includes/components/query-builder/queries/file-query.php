<?php
namespace Jet_Engine\Query_Builder\Queries;

use Jet_Engine\Query_Builder\File_Query\Parser;
use Jet_Engine\Query_Builder\Manager;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

require_once Manager::instance()->component_path( 'file-query/parser.php' );

class File_Query extends Repeater_Query {

	public $_instance_fields = null;
	protected $runtime_error    = null;
	protected $parsed_data      = null;

	/**
	 * Normalize query after setup, before parsing and execution.
	 */
	public function after_query_setup() {
		$this->final_query = Parser::normalize_query( $this->final_query );
	}

	/**
	 * Reset query data, so it will be parsed again on the next request.
	 * This is required when we need to reset pagination or apply new meta query clause.
	 */
	public function reset_query() {
		$this->parsed_data   = null;
		$this->runtime_error = null;
		$this->_instance_fields = null;
	}

	/**
	 * Get queried items
	 *
	 * @param bool $count Whether to return count of items or the items themselves.
	 *
	 * @return array
	 */
	public function _get_items( $count = false ) {
		return $this->get_filtered_items( $count, true );
	}

	/**
	 * Get items per page for pagination
	 *
	 * @return int
	 */
	public function get_items_per_page() {
		$this->setup_query();

		return ! empty( $this->final_query['items_per_page'] ) ? absint( $this->final_query['items_per_page'] ) : 0;
	}

	/**
	 * Get instance fields, available for meta query and sorting.
	 *
	 * @return array
	 */
	public function get_instance_fields() {
		if ( null !== $this->_instance_fields ) {
			return $this->_instance_fields;
		}

		$query = null !== $this->final_query
			? $this->final_query
			: Parser::normalize_query( $this->query );

		$validation = Parser::validate_query( $query, array(
			'validate_source'    => true,
			'validate_orderby'   => false,
			'validate_id_column' => false,
		) );
		$props = ! empty( $validation['props'] ) ? $validation['props'] : array();
		$this->_instance_fields = ! empty( $props ) ? array_combine( $props, $props ) : array();

		return $this->_instance_fields;
	}

	/**
	 * Get a single runtime item by its stable public ID.
	 *
	 * @param string $item_id Stable runtime item ID.
	 *
	 * @return object|false
	 */
	public function get_item_by_stable_id( $item_id ) {
		$item_id = is_scalar( $item_id ) ? (string) $item_id : '';

		if ( '' === $item_id ) {
			return false;
		}

		$items = $this->get_filtered_items( false, false );

		$lookup_ids = $this->get_lookup_item_ids( $item_id );

		foreach ( $items as $item ) {
			if ( ! isset( $item->{ Parser::item_id_key() } ) ) {
				continue;
			}

			if ( in_array( $item->{ Parser::item_id_key() }, $lookup_ids, true ) ) {
				return $item;
			}
		}

		return false;
	}

	/**
	 * Set filtered query property, applied by the editor component controls.
	 * For example, when we need to set page number for pagination or add meta query clause for meta query
	 * filter control.
	 *
	 * @param string $prop  Property name.
	 * @param mixed  $value Property value.
	 * @return void
	 */
	public function set_filtered_prop( $prop = '', $value = null ) {
		switch ( $prop ) {
			case '_page':
				$this->final_query['page'] = absint( $value );
				break;

			case '_items_per_page':
				$this->final_query['items_per_page'] = absint( $value );
				break;

			case 'meta_query':
				$this->replace_meta_query_row( $value );
				break;

			case 'orderby':
				$allowed = $this->get_parsed_props();

				if ( empty( $value ) ) {
					$this->final_query['orderby'] = '';
				} elseif ( in_array( $value, $allowed, true ) ) {
					$this->final_query['orderby'] = $value;
				}
				break;

			case 'meta_key':
				$allowed = $this->get_parsed_props();

				if ( in_array( $value, $allowed, true ) ) {
					$this->final_query['orderby'] = $value;
				}
				break;

			case 'order':
				$value = strtolower( (string) $value );

				if ( in_array( $value, array( 'asc', 'desc' ), true ) ) {
					$this->final_query['order'] = $value;
				}
				break;

			default:
				$this->merge_default_props( $prop, $value );
				break;
		}
	}

	/**
	 * Show runtime error, occurred during query
	 * parsing or execution, in the preview.
	 *
	 * @return void
	 */
	public function before_preview_body() {
		if ( ! empty( $this->runtime_error ) ) {
			printf( "%s\n\n", esc_html( $this->runtime_error ) );
		}
	}

	/**
	 * Get debug info for the query,
	 * to show it in the editor component debug panel.
	 *
	 * @return array
	 */
	public function _debug_info() {
		$parsed = $this->get_parsed_data();

		if ( is_wp_error( $parsed ) ) {
			$validation = Parser::validate_query( $this->final_query, array(
				'validate_source'    => true,
				'validate_orderby'   => false,
				'validate_id_column' => false,
			) );

			return array_filter( array(
				'file_query_error' => $parsed->get_error_message(),
				'file_query_props' => ! empty( $validation['props'] ) ? $validation['props'] : array(),
				'file_query_id_mode' => ! empty( $this->final_query['id_column'] ) ? 'explicit' : '',
				'file_query_resolved_id_column' => ! empty( $this->final_query['id_column'] ) ? $this->final_query['id_column'] : '',
			) );
		}

		return array(
			'file_query_rows'  => ! empty( $parsed['rows'] ) ? count( $parsed['rows'] ) : 0,
			'file_query_props' => ! empty( $parsed['props'] ) ? $parsed['props'] : array(),
			'file_query_id_mode' => ! empty( $parsed['id_mode'] ) ? $parsed['id_mode'] : '',
			'file_query_resolved_id_column' => ! empty( $parsed['resolved_id_column'] ) ? $parsed['resolved_id_column'] : '',
		);
	}

	/**
	 * Get parsed data from the query, with caching.
	 *
	 * @return array|WP_Error
	 */
	protected function get_parsed_data() {
		if ( null !== $this->parsed_data ) {
			return $this->parsed_data;
		}

		$this->setup_query();
		$this->parsed_data = Parser::parse( $this->final_query );

		return $this->parsed_data;
	}

	/**
	 * Get parsed props from the query, with caching.
	 *
	 * @return array
	 */
	protected function get_parsed_props() {
		$parsed = $this->get_parsed_data();

		if ( is_wp_error( $parsed ) ) {
			return array();
		}

		return ! empty( $parsed['props'] ) ? $parsed['props'] : array();
	}

	/**
	 * Build runtime items after filtering, sorting, and optional pagination.
	 *
	 * @param bool $count            Whether items are requested for total counting.
	 * @param bool $apply_pagination Whether page slicing should be applied.
	 *
	 * @return array
	 */
	protected function get_filtered_items( $count = false, $apply_pagination = true ) {
		$parsed = $this->get_parsed_data();

		if ( is_wp_error( $parsed ) ) {
			$this->set_runtime_error( $parsed->get_error_message() );
			return array();
		}

		$args  = $this->final_query;
		$rows  = ! empty( $parsed['rows'] ) ? $parsed['rows'] : array();
		$props = ! empty( $parsed['props'] ) ? $parsed['props'] : array();

		$this->_instance_fields = ! empty( $props ) ? array_combine( $props, $props ) : array();

		if ( ! empty( $args['meta_query'] ) ) {
			$args['meta_query'] = $this->prepare_meta_query_args( $args );
			$args['meta_query'] = $this->sanitize_meta_query_for_props( $args['meta_query'], $props );
		}

		$items = array_values( array_filter( array_map( function( $row ) use ( $args, $parsed ) {
			$item = $this->prepare_runtime_item( $row, $parsed );

			if ( ! $this->is_item_met_requested_args( $item, $args ) ) {
				return false;
			}

			return $item;
		}, $rows ) ) );

		$this->apply_file_sorting( $items );

		if ( ! $apply_pagination ) {
			return array_values( $items );
		}

		return $this->apply_pagination_to_items( $items, $count );
	}

	/**
	 * Convert a normalized row array into a runtime object item.
	 *
	 * @param array $row Normalized row.
	 *
	 * @return object
	 */
	protected function prepare_runtime_item( $row, $parsed = array() ) {
		$row        = is_array( $row ) ? $row : array();
		$public_id  = $this->build_public_item_id( $row, $parsed );

		$row[ Parser::item_id_key() ] = $public_id;
		$row['_query_id']             = $this->id;
		$row['ID']                    = $public_id;

		return (object) $row;
	}

	/**
	 * Build the public runtime item ID from a normalized row payload.
	 *
	 * @param array $row    Normalized row payload.
	 * @param array $parsed Parsed file-query metadata.
	 *
	 * @return string
	 */
	protected function build_public_item_id( $row, $parsed = array() ) {
		$configured_id = $this->get_configured_item_id_value( $row, $parsed );

		if ( null !== $configured_id ) {
			return $configured_id;
		}

		$internal_id = isset( $row[ Parser::item_id_key() ] ) ? $row[ Parser::item_id_key() ] : '';
		$internal_id = is_scalar( $internal_id ) ? (string) $internal_id : '';

		return $this->id . '-' . $internal_id;
	}

	/**
	 * Get the configured row ID value for explicit/autodetected modes.
	 *
	 * @param array $row    Normalized row payload.
	 * @param array $parsed Parsed file-query metadata.
	 *
	 * @return string|null
	 */
	protected function get_configured_item_id_value( $row, $parsed = array() ) {
		$row    = is_array( $row ) ? $row : array();
		$parsed = is_array( $parsed ) ? $parsed : array();
		$mode   = ! empty( $parsed['id_mode'] ) ? $parsed['id_mode'] : '';

		if ( ! in_array( $mode, array( 'explicit', 'autodetected' ), true ) ) {
			return null;
		}

		$column = ! empty( $parsed['resolved_id_column'] ) ? $parsed['resolved_id_column'] : '';

		if ( ! $column || ! array_key_exists( $column, $row ) ) {
			return null;
		}

		return Parser::normalize_item_id_value( $row[ $column ] );
	}

	/**
	 * Get accepted lookup IDs for a runtime item.
	 *
	 * @param string $item_id Requested item ID.
	 *
	 * @return array
	 */
	protected function get_lookup_item_ids( $item_id ) {
		$item_id = is_scalar( $item_id ) ? (string) $item_id : '';

		if ( '' === $item_id ) {
			return array();
		}

		$lookup_ids = array( $item_id );
		$prefix     = $this->id . '-';

		if ( 0 === strpos( $item_id, $prefix ) ) {
			$lookup_ids[] = substr( $item_id, strlen( $prefix ) );
		}

		return array_values( array_unique( array_filter( $lookup_ids, 'strlen' ) ) );
	}

	/**
	 * Apply offset/page slicing to a prepared items list.
	 *
	 * @param array $items Prepared runtime items.
	 * @param bool  $count Whether the call comes from total-count handling.
	 *
	 * @return array
	 */
	protected function apply_pagination_to_items( $items, $count = false ) {
		$limit  = $this->get_items_per_page();
		$offset = ! empty( $this->final_query['offset'] ) ? absint( $this->final_query['offset'] ) : 0;

		if ( ! $count && $limit ) {
			$page   = $this->get_current_items_page();
			$offset = $offset + ( $page - 1 ) * $limit;
		}

		if ( ! $count && $limit ) {
			$items = array_slice( $items, $offset, $limit );
		} elseif ( $offset ) {
			$items = array_slice( $items, $offset );
		}

		return array_values( $items );
	}

	/**
	 * Sanitize meta query args, removing clauses with keys that are not in the query props.
	 *
	 * @param array $meta_query Meta query args.
	 * @param array $props      Query props, available for meta query clauses.
	 *
	 * @return array
	 */
	protected function sanitize_meta_query_for_props( $meta_query, $props ) {
		if ( ! is_array( $meta_query ) ) {
			return array();
		}

		$result = array();

		if ( ! empty( $meta_query['relation'] ) ) {
			$result['relation'] = $meta_query['relation'];
			unset( $meta_query['relation'] );
		}

		foreach ( $meta_query as $key => $clause ) {
			if ( ! is_array( $clause ) ) {
				continue;
			}

			if ( ! empty( $clause['relation'] ) ) {
				$nested = $this->sanitize_meta_query_for_props( $clause, $props );

				if ( ! empty( $nested ) ) {
					$result[] = $nested;
				}

				continue;
			}

			$prop = ! empty( $clause['key'] ) ? Parser::sanitize_property_key( $clause['key'] ) : '';

			if ( ! $prop || ! in_array( $prop, $props, true ) ) {
				continue;
			}

			$clause['key'] = $prop;
			$result[ $key ] = $clause;
		}

		return $result;
	}

	/**
	 * Apply sorting to the queried items, based on the query orderby and order args.
	 *
	 * @param array $items Items to sort.
	 * @return void
	 */
	protected function apply_file_sorting( &$items ) {
		$orderby = ! empty( $this->final_query['orderby'] ) ? $this->final_query['orderby'] : '';

		if ( ! $orderby ) {
			return;
		}

		$order = ! empty( $this->final_query['order'] ) ? strtolower( $this->final_query['order'] ) : 'asc';

		usort( $items, function( $a, $b ) use ( $orderby, $order ) {
			$value_a = isset( $a->$orderby ) ? $a->$orderby : null;
			$value_b = isset( $b->$orderby ) ? $b->$orderby : null;

			$result = $this->compare_values( $value_a, $value_b );

			if ( 0 !== $result ) {
				return ( 'desc' === $order ) ? $result * -1 : $result;
			}

			return $this->compare_values(
				isset( $a->__file_query_index ) ? $a->__file_query_index : 0,
				isset( $b->__file_query_index ) ? $b->__file_query_index : 0
			);
		} );
	}

	/**
	 * Compare two values for sorting.
	 *
	 * @param mixed $value_a First value.
	 * @param mixed $value_b Second value.
	 *
	 * @return int Returns -1 if $value_a is less than $value_b, 1 if greater, or 0 if equal.
	 */
	protected function compare_values( $value_a, $value_b ) {
		if ( null === $value_a && null === $value_b ) {
			return 0;
		}

		if ( null === $value_a ) {
			return -1;
		}

		if ( null === $value_b ) {
			return 1;
		}

		if ( is_numeric( $value_a ) && is_numeric( $value_b ) ) {
			$value_a = (float) $value_a;
			$value_b = (float) $value_b;

			if ( $value_a === $value_b ) {
				return 0;
			}

			return ( $value_a < $value_b ) ? -1 : 1;
		}

		$value_a = is_bool( $value_a ) ? ( $value_a ? '1' : '0' ) : (string) $value_a;
		$value_b = is_bool( $value_b ) ? ( $value_b ? '1' : '0' ) : (string) $value_b;

		return strcmp( $value_a, $value_b );
	}

	/**
	 * Set error message, occurred during query parsing or execution, to show it in the preview.
	 *
	 * @param string $message Error message.
	 * @return void
	 */
	protected function set_runtime_error( $message ) {
		if ( ! empty( $message ) ) {
			$this->runtime_error = $message;
		}
	}
}
