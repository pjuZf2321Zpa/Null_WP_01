<?php
namespace Jet_Engine\Query_Builder\File_Query;

use WP_Error;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * CSV-specific file query parser.
 */
class CSV_Parser extends Base_Parser {

	/**
	 * Parse CSV content into normalized rows and properties.
	 *
	 * @param array $source Resolved source payload.
	 * @param array $query  Normalized file query arguments.
	 * @param array $limits Parsing limits.
	 *
	 * @return array|WP_Error
	 */
	public static function parse( $source, $query, $limits ) {
		$content       = self::strip_utf8_bom( $source['content'] );
		$row_delimiter = self::decode_delimiter( $query['csv']['row_delimiter'] );
		$column_delim  = self::decode_delimiter( $query['csv']['column_delimiter'], false );
		$has_header    = ! empty( $query['csv']['has_header'] );
		$rows          = array();

		if ( '' === $row_delimiter ) {
			$row_delimiter = "\n";
		}

		if ( '' === $column_delim ) {
			$column_delim = ',';
		}

		if ( in_array( $row_delimiter, array( "\n", "\r\n", "\r" ), true ) ) {
			$stream = fopen( 'php://temp', 'r+' );

			if ( ! $stream ) {
				return new WP_Error( 'file_query_csv_stream', __( 'Failed to initialize CSV parser.', 'jet-engine' ) );
			}

			fwrite( $stream, str_replace( array( "\r\n", "\r" ), "\n", $content ) );
			rewind( $stream );

			while ( false !== ( $row = fgetcsv( $stream, 0, $column_delim, '"', '\\' ) ) ) {
				$rows[ count( $rows ) + 1 ] = $row;
			}

			fclose( $stream );
		} else {
			$raw_rows = explode( $row_delimiter, $content );

			foreach ( $raw_rows as $row ) {
				$rows[ count( $rows ) + 1 ] = str_getcsv( $row, $column_delim, '"', '\\' );
			}
		}

		return self::normalize_tabular_rows( $rows, array(
			'has_header' => $has_header,
			'header_row' => 1,
			'limits'     => $limits,
		) );
	}
}
