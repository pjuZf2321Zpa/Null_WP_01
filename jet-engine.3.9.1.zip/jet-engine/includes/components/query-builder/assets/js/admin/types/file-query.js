( function( $ ) {

	'use strict';

	Vue.component( 'jet-file-query-media', {
		template: '<div class="jet-engine-media"><div class="jet-engine-media__name" v-if="fileData.name">{{ fileData.name }}</div><cx-vui-button button-style="accent" size="mini" @click="selectFile"><span slot="label">Select file</span></cx-vui-button></div>',
		props: [ 'value', 'data-type' ],
		data: function() {
			return {
				fileData: {},
				mediaFrame: null,
			};
		},
		computed: {
			allowedFileTypes: function() {
				const allowedMimes = window.jet_query_component_file_query?.allowed_mimes || {};

				if ( ! this.dataType || ! allowedMimes[ this.dataType ] ) {
					return {
						extensions: [],
						mimes: [],
					};
				}

				return allowedMimes[ this.dataType ];
			},
		},
		created: function() {
			this.fileData = this.value && this.value.id ? { ...this.value } : {
				id: 0,
				name: '',
				url: '',
			};

			this.createMediaFrame();
		},
		methods: {
			getMediaLibraryConfig: function() {
				const mimes = Array.isArray( this.allowedFileTypes.mimes ) ? this.allowedFileTypes.mimes.filter( Boolean ) : [];
				const library = {};

				if ( mimes.length ) {
					library.type = mimes;
				}

				return {
					title: 'Select file',
					button: {
						text: 'Use this file',
					},
					library: library,
					multiple: false,
				};
			},
			getAttachmentExtension: function( attachment ) {
				const filename = attachment?.filename || attachment?.name || '';
				const parts = filename.toLowerCase().split( '.' );

				if ( 2 > parts.length ) {
					return '';
				}

				return parts.pop();
			},
			isAllowedAttachment: function( attachment ) {
				const allowedExtensions = Array.isArray( this.allowedFileTypes.extensions ) ? this.allowedFileTypes.extensions : [];

				if ( ! allowedExtensions.length ) {
					return true;
				}

				return allowedExtensions.includes( this.getAttachmentExtension( attachment ) );
			},
			showUnsupportedTypeNotice: function() {
				const extensions = Array.isArray( this.allowedFileTypes.extensions ) ? this.allowedFileTypes.extensions : [];

				if ( this.$CXNotice && extensions.length ) {
					this.$CXNotice.add( {
						message: 'Please select a supported file type: ' + extensions.map( ( extension ) => extension.toUpperCase() ).join( ', ' ) + '.',
						type: 'error',
						duration: 7000,
					} );
					return;
				}

				window.alert( 'Please select a supported file type.' );
			},
			createMediaFrame: function() {
				this.mediaFrame = window.wp.media( this.getMediaLibraryConfig() );

				this.mediaFrame.on( 'select', () => {
					var attachment = this.mediaFrame.state().get( 'selection' ).first().toJSON();

					if ( ! this.isAllowedAttachment( attachment ) ) {
						this.showUnsupportedTypeNotice();
						return;
					}

					this.fileData = {
						id: attachment.id,
						name: attachment.filename,
						url: attachment.url,
					};

					this.$emit( 'input', this.fileData );
				} );
			},
			selectFile: function() {
				this.mediaFrame.open();
			},
		},
		watch: {
			dataType: function() {
				this.createMediaFrame();
			},
			value: {
				handler: function( newValue ) {
					if ( newValue && newValue.id ) {
						this.fileData = { ...newValue };
					}
				},
				deep: true,
			},
		},
	} );

	Vue.component( 'jet-file-query-meta-field', {
		extends: window.JetEngineQueryMetaField,
		template: '#jet-file-query-meta-field',
		data: function() {
			return {
				operators: window.JetEngineQueryConfig.operators_list,
				dataTypes: window.JetEngineQueryConfig.data_types,
				showPopup: false,
				currentField: { ...this.field },
				relationOptions: [
					{
						value: 'and',
						label: 'And',
					},
					{
						value: 'or',
						label: 'Or',
					},
				],
			};
		},
	} );

	Vue.component( 'jet-file-query', {
		template: '#jet-file-query',
		mixins: [
			window.JetQueryRepeaterMixin,
			window.JetQueryMetaParamsMixin,
		],
		props: [ 'value', 'dynamic-value', 'query-debug' ],
		data: function() {
			return {
				query: {},
				dynamicQuery: {},
				syncingParentValue: false,
				syncingParentDynamicValue: false,
				operators: window.JetEngineQueryConfig.operators_list,
				dataValueTypes: window.JetEngineQueryConfig.data_types,
				dataTypes: window.jet_query_component_file_query.data_types,
				inputModes: window.jet_query_component_file_query.input_modes,
				orderOptions: window.jet_query_component_file_query.order_options,
				defaults: window.jet_query_component_file_query.defaults,
				queryDebugData: this.queryDebug && 'object' === typeof this.queryDebug ? this.queryDebug : {},
				relationOptions: [
					{
						value: 'and',
						label: 'And',
					},
					{
						value: 'or',
						label: 'Or',
					},
				],
			};
		},
		computed: {
			isUploadMode: function() {
				return 'upload' === this.query.source_type || 'xlsx' === this.query.data_type;
			},
			isTextMode: function() {
				return ! this.isUploadMode;
			},
			currentQueryDebug: function() {
				return this.queryDebugData && 'object' === typeof this.queryDebugData ? this.queryDebugData : {};
			},
			parsedProps: function() {
				const props = Array.isArray( this.currentQueryDebug.file_query_props ) ? this.currentQueryDebug.file_query_props : [];

				return props.filter( ( prop ) => {
					return 'string' === typeof prop && 0 !== prop.indexOf( '__file_query_' );
				} );
			},
			idColumnPropsListId: function() {
				return 'jet-file-query-id-column-props-' + this._uid;
			},
			orderbyPropsListId: function() {
				return 'jet-file-query-orderby-props-' + this._uid;
			},
			idModeLabel: function() {
				switch ( this.currentQueryDebug.file_query_id_mode ) {
					case 'explicit':
						return this.currentQueryDebug.file_query_resolved_id_column
							? 'Explicit column: ' + this.currentQueryDebug.file_query_resolved_id_column
							: 'Explicit column';

					case 'autodetected':
						return this.currentQueryDebug.file_query_resolved_id_column
							? 'Auto-detected column: ' + this.currentQueryDebug.file_query_resolved_id_column
							: 'Auto-detected column';

					case 'synthetic':
						return 'Synthetic fallback ID';
				}

				return '';
			},
			idFallbackDescription: function() {
				return 'Leave empty to auto-detect a unique id/item_id/uuid/guid column when possible, or generate a deterministic synthetic ID from the file source and normalized row data. Exact duplicate rows still require an explicit ID column.';
			},
			fileQueryError: function() {
				return this.currentQueryDebug.file_query_error || '';
			},
		},
		methods: {
			normalizeQueryState: function( value ) {
				const query = value && 'object' === typeof value ? value : {};
				const normalized = {
					...this.defaults,
					...query,
				};

				normalized.source_file = {
					...this.defaults.source_file,
					...( query.source_file && 'object' === typeof query.source_file ? query.source_file : {} ),
				};
				normalized.json = {
					...this.defaults.json,
					...( query.json && 'object' === typeof query.json ? query.json : {} ),
				};
				normalized.csv = {
					...this.defaults.csv,
					...( query.csv && 'object' === typeof query.csv ? query.csv : {} ),
				};
				normalized.xlsx = {
					...this.defaults.xlsx,
					...( query.xlsx && 'object' === typeof query.xlsx ? query.xlsx : {} ),
				};

				if ( 'xlsx' === normalized.data_type ) {
					normalized.source_type = 'upload';
				}

				return normalized;
			},
			normalizeDynamicState: function( value ) {
				const dynamic = value && 'object' === typeof value ? value : {};

				return {
					...dynamic,
					source_file: {
						id: '',
						...( dynamic.source_file && 'object' === typeof dynamic.source_file ? dynamic.source_file : {} ),
					},
					json: dynamic.json && 'object' === typeof dynamic.json ? { ...dynamic.json } : {},
					csv: dynamic.csv && 'object' === typeof dynamic.csv ? { ...dynamic.csv } : {},
					xlsx: dynamic.xlsx && 'object' === typeof dynamic.xlsx ? { ...dynamic.xlsx } : {},
				};
			},
			syncQueryFromValue: function( value ) {
				const normalized = this.normalizeQueryState( value );

				if ( JSON.stringify( normalized ) === JSON.stringify( this.query ) ) {
					return;
				}

				this.syncingParentValue = true;
				this.query = normalized;
				this.ensureNestedState();
			},
			syncDynamicQueryFromValue: function( value ) {
				const normalized = this.normalizeDynamicState( value );

				if ( JSON.stringify( normalized ) === JSON.stringify( this.dynamicQuery ) ) {
					return;
				}

				this.syncingParentDynamicValue = true;
				this.dynamicQuery = normalized;
				this.ensureNestedState();
			},
			emitNormalizedState: function() {
				this.$emit( 'input', this.query );
				this.$emit( 'dynamic-input', this.dynamicQuery );
			},
			initEditor: function( controlName, prop ) {
				if ( ! wp.codeEditor || ! JetEngineQueryConfig.use_CodeMirror ) {
					return;
				}

				let codeEditorArea = this.$refs?.[ controlName ]?.$el?.querySelector( 'textarea' );

				if ( ! codeEditorArea ) {
					return;
				}

				const codeMirrorConfig = JetEngineQueryConfig.CodeMirror_config;

				if ( codeMirrorConfig.jeReplaceTabs ) {
					codeMirrorConfig.extraKeys ??= {};
					codeMirrorConfig.extraKeys.Tab = function( cm ) {
						let spaces = Array( cm.getOption( "tabSize" ) + 1 ).join( " " );
						cm.replaceSelection( spaces, "end", "+input" );
					};
				}

				const mode = 'json' === this.query.data_type ? 'application/json' : 'text/plain';

				const wpCodeMirror = wp.codeEditor.initialize(
					codeEditorArea,
					{
						codemirror: { ...codeMirrorConfig, ...{
							mode: mode,
							lineWrapping: true,
						} },
					}
				);

				const codeMirror = wpCodeMirror.codemirror;

				if ( codeMirrorConfig.jeCustomHeight ) {
					let size = codeMirrorConfig.jeCustomHeight.toString().match( /(^\d+)(px)?/ );

					if ( size ) {
						let lineHeight = codeMirror.defaultTextHeight();
						let height = size[ 2 ] ? size[ 1 ] : size[ 1 ] * lineHeight;
						codeMirror.setSize( null, height );
					}
				}

				codeMirror.on( 'change', ( event ) => {
					this.$set( this.query, prop, event.getValue() );
				} )
			},
			ensureNestedState: function() {
				if ( ! this.query.source_file ) {
					this.$set( this.query, 'source_file', { ...this.defaults.source_file } );
				}

				if ( ! this.query.json ) {
					this.$set( this.query, 'json', { ...this.defaults.json } );
				}

				if ( ! this.query.csv ) {
					this.$set( this.query, 'csv', { ...this.defaults.csv } );
				}

				if ( ! this.query.xlsx ) {
					this.$set( this.query, 'xlsx', { ...this.defaults.xlsx } );
				}

				if ( ! this.dynamicQuery.source_file ) {
					this.$set( this.dynamicQuery, 'source_file', { id: '' } );
				}

				if ( ! this.dynamicQuery.json ) {
					this.$set( this.dynamicQuery, 'json', {} );
				}

				if ( ! this.dynamicQuery.csv ) {
					this.$set( this.dynamicQuery, 'csv', {} );
				}

				if ( ! this.dynamicQuery.xlsx ) {
					this.$set( this.dynamicQuery, 'xlsx', {} );
				}
			},
			setCsvHeader: function( value ) {
				this.$set( this.query.csv, 'has_header', value );
			},
		},
		created: function() {
			this.query = this.normalizeQueryState( this.value );
			this.dynamicQuery = this.normalizeDynamicState( this.dynamicValue );

			this.ensureNestedState();
			this.presetMeta();

			if ( ! this.query.meta_query_relation ) {
				this.$set( this.query, 'meta_query_relation', 'and' );
			}

			if ( 'xlsx' === this.query.data_type ) {
				this.$set( this.query, 'source_type', 'upload' );
			}

			this.emitNormalizedState();
		},
		mounted: function() {
			this.emitNormalizedState();
		},
		watch: {
			value: {
				handler: function( value ) {
					this.syncQueryFromValue( value );
				},
				deep: true,
			},
			dynamicValue: {
				handler: function( value ) {
					this.syncDynamicQueryFromValue( value );
				},
				deep: true,
			},
			queryDebug: {
				handler: function( value ) {
					this.queryDebugData = value && 'object' === typeof value ? value : {};
				},
				deep: true,
			},
			'query.data_type': function( value ) {
				if ( 'xlsx' === value ) {
					this.$set( this.query, 'source_type', 'upload' );
				}
			},
			query: {
				handler: function ( newVal ) {
					if ( this.syncingParentValue ) {
						this.syncingParentValue = false;
						return;
					}

					this.$emit( 'input', newVal );
				},
				deep: true,
			},
			dynamicQuery: {
				handler: function ( newVal ) {
					if ( this.syncingParentDynamicValue ) {
						this.syncingParentDynamicValue = false;
						return;
					}

					this.$emit( 'dynamic-input', newVal );
				},
				deep: true,
			},
		},
	} );

} )( jQuery );
