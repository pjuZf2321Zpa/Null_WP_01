<?php
namespace Jet_Engine\Query_Builder\Listings;

use Jet_Engine\Query_Builder\Manager as Query_Manager;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

class Query {

	public $source;
	public $source_meta;

	/**
	 * Constructor for the class
	 */
	public function __construct() {

		$this->source      = Query_Manager::instance()->listings->source;
		$this->source_meta = Query_Manager::instance()->listings->source_meta;

		add_filter( 'jet-engine/listing/grid/query/' . $this->source, array( $this, 'query_items' ), 10, 3 );

		add_action( 'jet-engine/listings/frontend/reset-data', function( $data ) {

			if ( $this->source !== $data->get_listing_source() ) {
				return;
			}

			$current_obj = $data->get_current_object();

			if ( $current_obj && 'WP_Post' === get_class( $current_obj ) ) {
				wp_reset_postdata();
			}

		} );

		add_action( 'jet-engine/query-builder/query/after-query-setup', array( $this, 'maybe_setup_load_more_prop' ) );

		add_filter( 'jet-engine/listing/grid/nav-widget-settings', array( $this, 'update_listing_nav_post_num' ), 10, 3 );
		add_filter( 'jet-engine/listing/grid/add-query-data', array( $this, 'add_custom_query_data' ), 10, 2 );

	}

	/**
	 * Expose the signed query binding required to fully reload a custom-query grid.
	 *
	 * @param bool   $add_query_data Whether query data is already required.
	 * @param object $render         Listing Grid render instance.
	 * @return bool
	 */
	public function add_custom_query_data( $add_query_data, $render ) {

		if ( $add_query_data ) {
			return true;
		}

		$settings        = $render->get_settings();
		$is_custom_query = ! empty( $settings['custom_query'] )
			? filter_var( $settings['custom_query'], FILTER_VALIDATE_BOOLEAN )
			: false;
		$query_id        = ! empty( $settings['custom_query_id'] ) ? absint( $settings['custom_query_id'] ) : 0;
		$request         = ! empty( $render->query_vars['request'] ) && is_array( $render->query_vars['request'] )
			? $render->query_vars['request']
			: array();

		if ( ! $is_custom_query || ! $query_id || absint( $render->listing_query_id ) !== $query_id ) {
			return false;
		}

		return ! empty( $request['query_id'] )
			&& ! empty( $request['custom_query_id'] )
			&& absint( $request['query_id'] ) === $query_id
			&& absint( $request['custom_query_id'] ) === $query_id;
	}

	public function query_items( $items, $settings, $widget ) {

		$listing_id = jet_engine()->listings->data->get_listing()->get_main_id();

		if ( ! $listing_id ) {
			return array();
		}

		$query_id = Query_Manager::instance()->listings->get_query_id( $listing_id, $settings );
		$query_id = apply_filters( 'jet-engine/query-builder/listings/query-id', $query_id, $listing_id, $settings );

		if ( ! $query_id ) {
			return array();
		}

		$query_context = array(
			'type'       => jet_engine()->listings->is_listing_ajax() ? 'listing_ajax' : 'listing',
			'query_id'   => $query_id,
			'listing_id' => $listing_id,
			'settings'   => $settings,
		);

		$query = Query_Manager::instance()->get_query_by_id_for_context( $query_id, $query_context );

		if ( ! $query ) {
			return array();
		}

		$jsf_context = $this->maybe_restore_jsf_query_context_for_load_more( $query, $settings );

		try {
			$query->setup_query();

			do_action( 'jet-engine/query-builder/listings/on-query', $query, $settings, $widget, $this );

			$request = array( 'query_id' => $query_id );
			$request = $this->maybe_add_load_more_query_args( $request, $query, $settings );
			$request = apply_filters( 'jet-engine/listing/grid/query-args', $request, $widget, $settings, $query );

			$widget->query_vars['page']    = $query->get_current_items_page();
			$widget->query_vars['pages']   = $query->get_items_pages_count();
			$widget->query_vars['request'] = $request;
			$widget->query_vars['request']['posts_per_page'] = $query->get_items_per_page();

			// Added for correctly setup and reset global $post in nested listings.
			if ( 'posts' === $query->query_type ) {
				$widget->posts_query = $query->get_current_wp_query();
			}

			if ( 'sql' === $query->query_type && ! empty( $query->query['cast_object_to'] ) && 'WP_Post' === $query->query['cast_object_to'] ) {
				$widget->posts_query = new \WP_Query();
			}

			return $query->get_items();
		} finally {
			$this->restore_jsf_query_context_for_load_more( $jsf_context );
		}

	}

	/**
	 * Maybe setup load more-related props for the query.
	 *
	 * @param \Jet_Engine\Query_Builder\Listings\Query $query
	 */
	public function maybe_setup_load_more_prop( $query ) {

		if ( ! jet_engine()->listings->is_listing_ajax() ) {
			return;
		}

		if ( empty( $_REQUEST['handler'] ) || 'listing_load_more' !== $_REQUEST['handler'] ) {
			return;
		}

		if ( empty( $_REQUEST['query'] ) || empty( $_REQUEST['query']['query_id'] ) ) {
			return;
		}

		$l_query_id = intval( $_REQUEST['query']['query_id'] );
		$query_id   = intval( $query->id );

		if ( $l_query_id !== $query_id ) {
			return;
		}

		if ( ! empty( $_REQUEST['page'] ) ) {
			$query->set_filtered_prop( '_page', absint( $_REQUEST['page'] ) );
		}

		do_action( 'jet-engine/query-builder/listings/on-load-more-props-setup', $query );

		if ( ! empty( $_REQUEST['query']['filtered_query'] ) ) {
			$filtered_query = $this->sanitize_filtered_query_args( $_REQUEST['query']['filtered_query'], $query );

			foreach ( $filtered_query as $prop => $value ) {

				/**
				 * Ensure slashes removed from regex meta-query
				 *
				 * @see https://github.com/Crocoblock/issues-tracker/issues/17351 (item #3)
				 */
				if ( 'meta_query' === $prop ) {
					$value = wp_unslash( $value );
				}

				$query->set_filtered_prop( $prop, $value );
			}
		}

		add_filter( 'jet-engine/ajax/listing_load_more/response', function ( $response ) use ( $query, $query_id ) {

			if ( ! isset( $response['fragments'] ) ) {
				$response['fragments'] = array();
			}

			$page  = absint( $_REQUEST['page'] );
			$pages = absint( $query->get_items_pages_count() );

			if ( $page === $pages ) {
				$visible_items_count = $query->get_items_total_count();
			} else {
				$visible_items_count = $page * $query->get_items_per_page();
			}

			$response['fragments'][ '.jet-engine-query-count.count-type-visible.query-' . $query_id ] = $visible_items_count;
			$response['fragments'][ '.jet-engine-query-count.count-type-end-item.query-' . $query->id ] = $query->get_end_item_index_on_page();

			return $response;
		} );
	}

	public function maybe_add_load_more_query_args( $request, $query, $settings ) {

		$use_load_more = ! empty( $settings['use_load_more'] ) ? $settings['use_load_more'] : false;
		$use_load_more = filter_var( $use_load_more, FILTER_VALIDATE_BOOLEAN );
		$is_custom_query = ! empty( $settings['custom_query'] ) ? filter_var( $settings['custom_query'], FILTER_VALIDATE_BOOLEAN ) : false;

		// Add `orderby random seed` to the request if use random order
		if ( $use_load_more && ! empty( $query->final_query['_random_seed'] ) ) {
			$request['filtered_query']['_random_seed'] = $query->final_query['_random_seed'];
		}

		if ( $is_custom_query && ! empty( $settings['custom_query_id'] ) ) {
			$request['custom_query_id'] = absint( $settings['custom_query_id'] );
		}

		return $request;
	}

	protected function maybe_restore_jsf_query_context_for_load_more( $query, $settings ) {

		if ( ! function_exists( 'jet_smart_filters' ) ) {
			return false;
		}

		if ( ! jet_engine()->listings->is_listing_ajax( 'listing_load_more' ) ) {
			return false;
		}

		$request_query = ! empty( $_REQUEST['query'] ) && is_array( $_REQUEST['query'] )
			? wp_unslash( $_REQUEST['query'] ) // phpcs:ignore
			: array();

		if ( empty( $request_query['query_id'] ) || absint( $request_query['query_id'] ) !== absint( $query->id ) ) {
			return false;
		}

		if ( empty( $request_query['filtered_query'] ) || ! is_array( $request_query['filtered_query'] ) ) {
			return false;
		}

		if (
			empty( jet_engine()->listings->ajax_handlers )
			|| ! method_exists( jet_engine()->listings->ajax_handlers, 'query_has_valid_mutable_signature' )
		) {
			return false;
		}

		if ( ! jet_engine()->listings->ajax_handlers->query_has_valid_mutable_signature( $request_query, $settings ) ) {
			return false;
		}

		$filtered_query = $request_query['filtered_query'];

		if ( empty( $filtered_query['jet_smart_filters'] ) || ! is_scalar( $filtered_query['jet_smart_filters'] ) ) {
			return false;
		}

		$jsf = jet_smart_filters();

		if (
			empty( $jsf->query )
			|| ! is_object( $jsf->query )
			|| ! method_exists( $jsf->query, 'decode_provider_data' )
			|| ! method_exists( $jsf->query, 'get_current_provider' )
			|| ! method_exists( $jsf->query, 'set_provider' )
		) {
			return false;
		}

		$jsf_query_manager = $jsf->query;
		$provider          = (string) $filtered_query['jet_smart_filters'];
		$provider_data     = $jsf_query_manager->decode_provider_data( $provider );

		if ( ! $this->is_valid_jsf_load_more_provider( $query, $provider_data ) ) {
			return false;
		}

		$context = array(
			'query_manager'     => $jsf_query_manager,
			'previous_query'    => $jsf_query_manager->_query,
			'previous_provider' => $jsf_query_manager->get_current_provider( 'raw' ),
		);

		$jsf_query_manager->set_provider( $provider );
		$jsf_query_manager->_query = $filtered_query;

		return $context;
	}

	protected function restore_jsf_query_context_for_load_more( $context ) {

		if ( empty( $context ) || empty( $context['query_manager'] ) ) {
			return;
		}

		$context['query_manager']->_query = $context['previous_query'];
		$context['query_manager']->set_provider( $context['previous_provider'] ? $context['previous_provider'] : '' );
	}

	protected function is_valid_jsf_load_more_provider( $query, $provider_data ) {

		if ( empty( $provider_data ) || ! is_array( $provider_data ) ) {
			return false;
		}

		$provider = ! empty( $provider_data['provider'] ) && is_scalar( $provider_data['provider'] )
			? (string) $provider_data['provider']
			: '';
		$query_id = ! empty( $provider_data['query_id'] ) && is_scalar( $provider_data['query_id'] )
			? (string) $provider_data['query_id']
			: '';

		if ( ! $provider || ! $query_id ) {
			return false;
		}

		$filters = ! empty( Query_Manager::instance()->listings->filters ) ? Query_Manager::instance()->listings->filters : false;

		if ( ! $filters || ! method_exists( $filters, 'is_current_provider_query' ) ) {
			return false;
		}

		return $filters->is_current_provider_query( $query, $query_id, $provider );
	}

	protected function sanitize_filtered_query_args( $filtered_query, $query = null ) {

		if ( ! is_array( $filtered_query ) ) {
			return [];
		}

		if ( $query && 'sql' === $query->query_type ) {
			return array_intersect_key(
				$filtered_query,
				array(
					'meta_query'   => true,
					'orderby'      => true,
					'order'        => true,
					'meta_key'     => true,
					'_random_seed' => true,
				)
			);
		}

		$disallowed_arguments = array(
			'custom_table_query',
			'fields',
			'suppress_filters',
			'cache_results',
		);

		foreach ( $disallowed_arguments as $argument ) {
			if ( isset( $filtered_query[ $argument ] ) ) {
				unset( $filtered_query[ $argument ] );
			}
		}

		return $filtered_query;
	}

	public function update_listing_nav_post_num( $result, $settings, $render ) {

		if ( empty( $render->listing_query_id ) ) {
			return $result;
		}

		$query = Query_Manager::instance()->get_query_by_id( $render->listing_query_id );

		if ( ! $query ) {
			return $result;
		}

		$result['posts_num'] = $query->get_items_per_page();

		return $result;
	}

}
