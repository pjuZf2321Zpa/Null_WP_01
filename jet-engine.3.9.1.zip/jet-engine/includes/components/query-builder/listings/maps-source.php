<?php
namespace Jet_Engine\Query_Builder\Listings;

use Jet_Engine\Query_Builder\Manager as Query_Manager;
use Jet_Engine\Modules\Maps_Listings\Source\Base;

class File_Query_Maps_Source extends Base {

	/**
	 * Returns source ID
	 *
	 * @return string
	 */
	public function get_id() {
		return 'file_query';
	}

	public function get_obj_by_id( $id ) {

		$query = $this->get_query_for_item_id( $id );

		if ( ! $query || ! method_exists( $query, 'get_item_by_stable_id' ) ) {
			return false;
		}

		$query->setup_query();

		return $query->get_item_by_stable_id( (string) $id );
	}

	public function get_field_value( $obj, $field ) {
		return isset( $obj->$field ) ? $obj->$field : false;
	}

	public function delete_field_value( $obj, $field ) {}

	public function update_field_value( $obj, $field, $value ) {}

	public function get_failure_key( $obj ) {
		$item_id = isset( $obj->__file_query_item_id ) ? $obj->__file_query_item_id : '';
		return 'File Query Item #' . $item_id;
	}

	public function get_field_coordinates( $obj, $location_string = '', $field_name = null ) {

		if ( ! $field_name ) {
			$field_name = $this->lat_lng->meta_key;
		}

		$location_hash = $this->get_field_value( $obj, $field_name . '_hash' );

		if ( ! $location_hash ) {
			$field_hash    = $this->get_field_prefix( $field_name );
			$location_hash = $this->get_field_value( $obj, $field_hash . '_hash' );
		}

		if ( ! $location_hash ) {
			$coord = $this->lat_lng->get_from_transient( $location_string );

			return array(
				'key'   => md5( $location_string ),
				'coord' => $coord,
			);
		}

		return array(
			'key'   => $location_hash,
			'coord' => array(
				'lat' => $this->get_field_value( $obj, $field_name . '_lat' ),
				'lng' => $this->get_field_value( $obj, $field_name . '_lng' ),
			),
		);
	}

	protected function get_query_for_item_id( $item_id ) {
		$manager  = Query_Manager::instance()->listings;
		$query_id = $manager->extract_query_id_from_item_id( $item_id );

		if ( ! $query_id ) {
			$listing = jet_engine()->listings->data->get_listing();
			$query_id = $listing ? absint( $listing->get_settings( '_query_id' ) ) : 0;
		}

		if ( ! $query_id ) {
			return false;
		}

		$query = Query_Manager::instance()->get_query_by_id( $query_id );

		if ( ! $query || 'file-query' !== $query->get_query_type() ) {
			return false;
		}

		return $query;
	}
}
