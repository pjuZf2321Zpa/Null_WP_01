<?php return array('dependencies' => array('react', 'react-dom'), 'version' => 'e3996e217d5969d6545f');
