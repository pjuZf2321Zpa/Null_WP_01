<?php
/**
 * SVG Morphing integration
 */
namespace Happy_Addons_Pro\Wpml;

defined( 'ABSPATH' ) || die();

class Svg_Morphing extends \WPML_Elementor_Module_With_Items {

	/**
	 * @return string
	 */
	public function get_items_field() {
		return 'morph_shapes';
	}

	/**
	 * @return array
	 */
	public function get_fields() {
		return [
			'svg_name',
		];
	}

	/**
	 * @param string $field
	 *
	 * @return string
	 */
	protected function get_title( $field ) {
		switch ( $field ) {
			case 'svg_name':
				return __( 'SVG Morphing: SVG Name', 'happy-addons-pro' );
			default:
				return '';
		}
	}

	/**
	 * @param string $field
	 *
	 * @return string
	 */
	protected function get_editor_type( $field ) {
		switch ( $field ) {
			case 'svg_name':
				return 'LINE';
			default:
				return '';
		}
	}
}
