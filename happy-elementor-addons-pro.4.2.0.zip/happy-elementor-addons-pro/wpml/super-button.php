<?php
/**
 * Super Button integration
 */
namespace Happy_Addons_Pro\Wpml;

defined( 'ABSPATH' ) || die();

class Super_Button extends \Happy_Addons_Pro\Classes\WPML_Module_With_Items {

	/**
	 * @return string
	 */
	public function get_items_field() {
		return 'btn_list';
	}

	/**
	 * @return array
	 */
	public function get_fields() {
		return [
			'option_text',
			'option_link' => [ 'url' ],
		];
	}

	/**
	 * @param string $field
	 *
	 * @return string
	 */
	protected function get_title( $field ) {
		switch ( $field ) {
			case 'option_text':
				return __( 'Super Button: Option Text', 'happy-addons-pro' );
			case 'option_link':
				return __( 'Super Button: Option Link', 'happy-addons-pro' );
			default:
				return '';
		}
	}

	/**
	 * @param string $field
	 *
	 * @return string
	 */
	protected function get_editor_type( $field ) {
		switch ( $field ) {
			case 'option_text':
				return 'LINE';
			case 'option_link':
				return 'LINK';
			default:
				return '';
		}
	}
}
