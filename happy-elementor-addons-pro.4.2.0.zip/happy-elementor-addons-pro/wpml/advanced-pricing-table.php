<?php
/**
 * Advanced Pricing Table integration
 */
namespace Happy_Addons_Pro\Wpml;

defined( 'ABSPATH' ) || die();

class Advanced_Pricing_Table extends \WPML_Elementor_Module_With_Items {

	/**
	 * @return string
	 */
	public function get_items_field() {
		return 'price_data';
	}

	/**
	 * @return array
	 */
	public function get_fields() {
		return [
			'plan_name',
			'price',
			'original_price',
			'period',
			'plan_related_text',
			'features_desc',
			'button_text',
			'button_link' => [ 'url' ],
		];
	}

	/**
	 * @param string $field
	 *
	 * @return string
	 */
	protected function get_title( $field ) {
		switch ( $field ) {
			case 'plan_name':
				return __( 'Advanced Pricing Table: Plan Name', 'happy-addons-pro' );
			case 'price':
				return __( 'Advanced Pricing Table: Price', 'happy-addons-pro' );
			case 'original_price':
				return __( 'Advanced Pricing Table: Original Price', 'happy-addons-pro' );
			case 'period':
				return __( 'Advanced Pricing Table: Period', 'happy-addons-pro' );
			case 'plan_related_text':
				return __( 'Advanced Pricing Table: Plan Tips', 'happy-addons-pro' );
			case 'features_desc':
				return __( 'Advanced Pricing Table: Features', 'happy-addons-pro' );
			case 'button_text':
				return __( 'Advanced Pricing Table: Button Title', 'happy-addons-pro' );
			case 'url':
				return __( 'Advanced Pricing Table: Button Link', 'happy-addons-pro' );
			default:
				return '';
		}
	}

	/**
	 * @param string $field
	 *
	 * @return string
	 */
	protected function get_editor_type( $field ) {
		switch ( $field ) {
			case 'plan_name':
			case 'price':
			case 'original_price':
			case 'period':
			case 'plan_related_text':
			case 'button_text':
				return 'LINE';
			case 'features_desc':
				return 'AREA';
			case 'url':
				return 'LINK';
			default:
				return '';
		}
	}
}
