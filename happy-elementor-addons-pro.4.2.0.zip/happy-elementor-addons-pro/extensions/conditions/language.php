<?php
namespace Happy_Addons_Pro\Extensions\Conditions;

use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Class Language
 * contain all element of current language (WPML) condition
 * @package Happy_Addons_Pro\Extensions\Conditions
 */
class Language extends Condition {

	/**
	 * Get Condition Key
	 *
	 * @return string|void
	 */
	public function get_key_name() {
		return 'language';
	}

	/**
	 * Get Condition Title
	 *
	 * @return string|void
	 */
	public function get_title() {
		return __( 'Language', 'happy-addons-pro' );
	}

	/**
	 * Get Repeater Control Field Value
	 *
	 * @param array $condition
	 * @return array|void
	 */
	public function get_repeater_control(array $condition) {
		return [
			'label'       => $this->get_title(),
			'show_label'  => false,
			'type'        => Controls_Manager::SELECT,
			'label_block' => true,
			'options'     => $this->get_active_languages(),
			'description' => __( 'Requires WPML. Lists site languages added in WPML.', 'happy-addons-pro' ),
			'condition'   => $condition,
		];
	}

	/**
	 * Compare Condition value
	 *
	 * @param $settings
	 * @param $operator
	 * @param $value
	 * @return bool|void
	 */
	public function compare_value( $settings, $operator, $value ) {
		$current_language = apply_filters( 'wpml_current_language', '' );

		return hapro_compare( $current_language, $value, $operator );
	}

	/**
	 * Active site languages from WPML
	 *
	 * @return array
	 */
	protected function get_active_languages() {
		$languages = apply_filters( 'wpml_active_languages', [] );

		if ( empty( $languages ) || ! is_array( $languages ) ) {
			return [];
		}

		$options = [];
		foreach ( $languages as $code => $language ) {
			$options[ $code ] = isset( $language['native_name'] ) && $language['native_name'] !== ''
				? $language['native_name']
				: $code;
		}

		return $options;
	}
}
