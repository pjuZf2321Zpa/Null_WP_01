"use strict";

function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
function _superPropGet(t, o, e, r) { var p = _get(_getPrototypeOf(1 & r ? t.prototype : t), o, e); return 2 & r && "function" == typeof p ? function (t) { return p.apply(e, t); } : p; }
function _get() { return _get = "undefined" != typeof Reflect && Reflect.get ? Reflect.get.bind() : function (e, t, r) { var p = _superPropBase(e, t); if (p) { var n = Object.getOwnPropertyDescriptor(p, t); return n.get ? n.get.call(arguments.length < 3 ? e : r) : n.value; } }, _get.apply(null, arguments); }
function _superPropBase(t, o) { for (; !{}.hasOwnProperty.call(t, o) && null !== (t = _getPrototypeOf(t));); return t; }
function _classCallCheck(a, n) { if (!(a instanceof n)) throw new TypeError("Cannot call a class as a function"); }
function _defineProperties(e, r) { for (var t = 0; t < r.length; t++) { var o = r[t]; o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(e, _toPropertyKey(o.key), o); } }
function _createClass(e, r, t) { return r && _defineProperties(e.prototype, r), t && _defineProperties(e, t), Object.defineProperty(e, "prototype", { writable: !1 }), e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == _typeof(i) ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != _typeof(t) || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != _typeof(i)) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
function _callSuper(t, o, e) { return o = _getPrototypeOf(o), _possibleConstructorReturn(t, _isNativeReflectConstruct() ? Reflect.construct(o, e || [], _getPrototypeOf(t).constructor) : o.apply(t, e)); }
function _possibleConstructorReturn(t, e) { if (e && ("object" == _typeof(e) || "function" == typeof e)) return e; if (void 0 !== e) throw new TypeError("Derived constructors may only return object or undefined"); return _assertThisInitialized(t); }
function _assertThisInitialized(e) { if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); return e; }
function _isNativeReflectConstruct() { try { var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); } catch (t) {} return (_isNativeReflectConstruct = function _isNativeReflectConstruct() { return !!t; })(); }
function _getPrototypeOf(t) { return _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function (t) { return t.__proto__ || Object.getPrototypeOf(t); }, _getPrototypeOf(t); }
function _inherits(t, e) { if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function"); t.prototype = Object.create(e && e.prototype, { constructor: { value: t, writable: !0, configurable: !0 } }), Object.defineProperty(t, "prototype", { writable: !1 }), e && _setPrototypeOf(t, e); }
function _setPrototypeOf(t, e) { return _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function (t, e) { return t.__proto__ = e, t; }, _setPrototypeOf(t, e); }
!function () {
  "use strict";

  var registered = false;
  var REPEATER_ROW_SELECTORS = ['.elementor-repeater-row-item-title', '.e-repeater-row-item-title', '.elementor-repeater-row-tools', '.elementor-repeater-row-handle', '.e-repeater-row-title'];
  function getRepeaterControlView(controlName) {
    try {
      var page = elementor.getPanelView && elementor.getPanelView().getCurrentPageView && elementor.getPanelView().getCurrentPageView();
      if (!page) {
        return null;
      }
      if (typeof page.getControlViewByName === 'function') {
        var direct = page.getControlViewByName(controlName);
        if (direct) {
          return direct;
        }
      }
      var views = page.children && page.children._views;
      if (views) {
        for (var key in views) {
          if (!Object.prototype.hasOwnProperty.call(views, key)) {
            continue;
          }
          var view = views[key];
          if (view && view.model && view.model.get('name') === controlName) {
            return view;
          }
        }
      }
    } catch (e) {}
    return null;
  }
  function findRepeaterRows($scope) {
    for (var i = 0; i < REPEATER_ROW_SELECTORS.length; i++) {
      var $rows = $scope.find(REPEATER_ROW_SELECTORS[i]);
      if ($rows.length) {
        return $rows;
      }
    }
    return jQuery();
  }
  function expandRepeaterRow($rows, memberId) {
    $rows.filter('.elementor-active').trigger('click');
    setTimeout(function () {
      var $target = $rows.eq(Number(memberId));
      if (!$target.length) {
        return;
      }
      $target.trigger('click');
      setTimeout(function () {
        var $scrollParent = $target.parents().filter(function () {
          var oy = jQuery(this).css('overflow-y');
          return oy === 'auto' || oy === 'scroll';
        }).first();
        if (!$scrollParent.length) {
          $scrollParent = $target.parents().filter(function () {
            return this.scrollHeight > this.clientHeight;
          }).first();
        }
        if ($scrollParent.length) {
          var headerHeight = jQuery('#elementor-panel-header').outerHeight() || 60;
          var containerTop = $scrollParent[0].getBoundingClientRect().top;
          var targetTop = $target[0].getBoundingClientRect().top;
          var currentScroll = $scrollParent.scrollTop();
          $scrollParent.scrollTop(currentScroll + (targetTop - containerTop) - headerHeight + 55);
        }
      }, 400);
    }, 300);
  }
  function activateRepeaterItem(memberId, controlName, sectionName, attempt, sectionOpened) {
    attempt = attempt || 0;
    var controlView = getRepeaterControlView(controlName);
    var $scope = controlView ? controlView.$el : jQuery('#elementor-panel-content-wrapper');
    var $rows = findRepeaterRows($scope);
    if ($rows.length) {
      expandRepeaterRow($rows, memberId);
      return;
    }
    if (!sectionOpened && sectionName) {
      var sectionView = getRepeaterControlView(sectionName);
      if (sectionView && !sectionView.$el.hasClass('elementor-open')) {
        var $heading = sectionView.$el.find('.elementor-panel-heading');
        ($heading.length ? $heading : sectionView.$el).trigger('click');
      }
      sectionOpened = true;
    }
    if (attempt < 12) {
      setTimeout(function () {
        activateRepeaterItem(memberId, controlName, sectionName, attempt + 1, sectionOpened);
      }, 150);
    } else if (window.console) {
      window.console.warn('Happy Visual Tabs: repeater rows not found for "' + controlName + '".');
    }
  }
  function register() {
    if (registered) {
      return true;
    }
    if (typeof elementor === "undefined" || typeof $e === "undefined") {
      return false;
    }
    var component = $e.components && ($e.components.get("nested-elements/nested-repeater") || $e.components.get("nested-elements"));
    var nestedModule = component && component.exports ? component.exports : null;
    if (!nestedModule || !nestedModule.NestedViewBase || !nestedModule.NestedModelBase) {
      return false;
    }
    var NestedElementBase = elementor.modules && elementor.modules.elements && elementor.modules.elements.types && elementor.modules.elements.types.NestedElementBase;
    if (typeof NestedElementBase !== "function") {
      return false;
    }
    var NestedViewBase = nestedModule.NestedViewBase;
    var HappyVisualTabsServiceListView = /*#__PURE__*/function (_NestedViewBase) {
      function HappyVisualTabsServiceListView() {
        _classCallCheck(this, HappyVisualTabsServiceListView);
        return _callSuper(this, HappyVisualTabsServiceListView, arguments);
      }
      _inherits(HappyVisualTabsServiceListView, _NestedViewBase);
      return _createClass(HappyVisualTabsServiceListView, [{
        key: "events",
        value: function events() {
          var parentEvents = typeof NestedViewBase.prototype.events === "function" ? NestedViewBase.prototype.events.call(this) : {};
          return Object.assign({}, parentEvents, {
            "click .ha-v-tabs-title-wrap": "onTitleClick",
            "keydown .ha-v-tabs-title-wrap": "onTitleKeydown"
          });
        }
      }, {
        key: "onRender",
        value: function onRender() {
          if (typeof NestedViewBase.prototype.onRender === "function") {
            NestedViewBase.prototype.onRender.apply(this, arguments);
          }
          this.haSetupHeightSync();
        }
      }, {
        key: "onDestroy",
        value: function onDestroy() {
          if (typeof NestedViewBase.prototype.onDestroy === "function") {
            NestedViewBase.prototype.onDestroy.apply(this, arguments);
          }
          this.haTeardownHeightSync();
        }
      }, {
        key: "onTitleClick",
        value: function onTitleClick(event) {
          var $title = jQuery(event.currentTarget);
          var $clickedItem = $title.closest(".ha-v-tabs-item");
          var $list = $title.closest(".ha-v-tabs-list");
          var wasActive = $clickedItem.hasClass('e-active');
          $list.children(".ha-v-tabs-item").each(function () {
            var $item = jQuery(this);
            if ($item.hasClass('e-active')) {
              $item.removeClass('e-active');
            }
          });
          if (!wasActive) {
            $clickedItem.addClass('e-active');
          }
          this.haScheduleHeightSync();
          this.openItemSettings($clickedItem);
        }
      }, {
        key: "haSetupHeightSync",
        value: function haSetupHeightSync() {
          this.haTeardownHeightSync();
          var root = this.el;
          if (!root) {
            return;
          }
          var self = this;
          var mo = null;
          if (typeof MutationObserver !== 'undefined') {
            mo = new MutationObserver(function () {
              self.haScheduleHeightSync();
            });
            mo.observe(root, {
              childList: true,
              subtree: true,
              characterData: true,
              attributeFilter: ['style', 'class']
            });
          }
          var ro = null;
          var observed = typeof WeakSet !== 'undefined' ? new WeakSet() : null;
          if (typeof ResizeObserver !== 'undefined') {
            ro = new ResizeObserver(function () {
              self.haScheduleHeightSync();
            });
          }
          this._haHeightSync = {
            mo: mo,
            ro: ro,
            observed: observed,
            pending: false
          };
          this.haMeasureContentHeight();
        }
      }, {
        key: "haTeardownHeightSync",
        value: function haTeardownHeightSync() {
          var state = this._haHeightSync;
          if (!state) {
            return;
          }
          if (state.mo) {
            state.mo.disconnect();
          }
          if (state.ro) {
            state.ro.disconnect();
          }
          this._haHeightSync = null;
        }
      }, {
        key: "haIsAttached",
        value: function haIsAttached() {
          return !!this.el && !!this.el.isConnected;
        }
      }, {
        key: "haScheduleHeightSync",
        value: function haScheduleHeightSync() {
          var state = this._haHeightSync;
          if (!state || state.pending) {
            return;
          }
          state.pending = true;
          var self = this;
          requestAnimationFrame(function () {
            if (self._haHeightSync) {
              self._haHeightSync.pending = false;
            }
            if (self.haIsAttached()) {
              self.haMeasureContentHeight();
            }
          });
        }
      }, {
        key: "haMeasureContentHeight",
        value: function haMeasureContentHeight() {
          if (!this.haIsAttached() || !this.$el) {
            return;
          }
          var $list = this.$el.find('.ha-v-tabs-list').first();
          if (!$list.length) {
            return;
          }
          var list = $list[0];
          var state = this._haHeightSync;
          var ro = state && state.ro || null;
          var observed = state && state.observed || null;
          var track = function track(el) {
            if (ro && observed && el && !observed.has(el)) {
              observed.add(el);
              ro.observe(el);
            }
          };
          var maxH = 0;
          $list.children('.ha-v-tabs-item').each(function () {
            var wrap = this.querySelector(':scope > .ha-v-tabs-sticky-container');
            var host = wrap || this;
            var content = host.querySelector(':scope > .e-con, :scope > .elementor-element');
            if (!content) {
              return;
            }
            track(content);
            var st = content.style;
            var saved = {
              bottom: st.bottom,
              height: st.height,
              maxHeight: st.maxHeight
            };
            st.bottom = 'auto';
            st.height = 'auto';
            st.maxHeight = 'none';
            var h = content.offsetHeight;
            st.bottom = saved.bottom;
            st.height = saved.height;
            st.maxHeight = saved.maxHeight;
            if (h > maxH) {
              maxH = h;
            }
          });
          if (ro) {
            track(list);
            $list.find('.elementor-widget-container').each(function () {
              track(this);
            });
          }
          var stagePadTop = parseFloat(getComputedStyle(list).paddingTop) || 0;
          var next = Math.ceil(maxH + stagePadTop) + 'px';
          if (list.style.getPropertyValue('--ha-v-tabs-content-height') !== next) {
            list.style.setProperty('--ha-v-tabs-content-height', next);
          }
          if (list.classList.contains('ha-v-tabs-zoom')) {
            $list.children('.ha-v-tabs-item').each(function () {
              var titleWrap = this.querySelector(':scope > .ha-v-tabs-title-wrap');
              if (!titleWrap) {
                return;
              }
              var titleEl = titleWrap.querySelector(':scope > .ha-v-tabs-service-title');
              var w = titleEl ? Math.round(titleEl.offsetWidth) + 'px' : '0px';
              if (titleWrap.style.getPropertyValue('--ha-v-tabs-title-w') !== w) {
                titleWrap.style.setProperty('--ha-v-tabs-title-w', w);
              }
            });
          }
          if (state && state.mo) {
            state.mo.takeRecords();
          }
        }
      }, {
        key: "openItemSettings",
        value: function openItemSettings($clickedItem) {
          try {
            if (typeof $e === 'undefined') {
              return;
            }
            var widgetContainer = this.container;
            if (!widgetContainer) {
              return;
            }
            var itemIndex = $clickedItem.index();
            $e.run('document/elements/select', {
              container: widgetContainer
            });
            if (itemIndex >= 0) {
              activateRepeaterItem(itemIndex, 'items', 'section_items');
            }
          } catch (e) {}
        }
      }, {
        key: "onTitleKeydown",
        value: function onTitleKeydown(event) {
          if ("Enter" !== event.key && " " !== event.key) {
            return;
          }
          event.preventDefault();
          jQuery(event.currentTarget).trigger("click");
        }
      }]);
    }(NestedViewBase);
    var HappyVisualTabsServiceListElement = /*#__PURE__*/function (_NestedElementBase) {
      function HappyVisualTabsServiceListElement() {
        _classCallCheck(this, HappyVisualTabsServiceListElement);
        return _callSuper(this, HappyVisualTabsServiceListElement, arguments);
      }
      _inherits(HappyVisualTabsServiceListElement, _NestedElementBase);
      return _createClass(HappyVisualTabsServiceListElement, [{
        key: "getType",
        value: function getType() {
          return "ha-visual-tabs";
        }
      }, {
        key: "getView",
        value: function getView() {
          return HappyVisualTabsServiceListView;
        }
      }, {
        key: "getModel",
        value: function getModel() {
          return nestedModule.NestedModelBase;
        }
      }, {
        key: "getInitialConfig",
        value: function getInitialConfig() {
          return Object.assign({}, _superPropGet(HappyVisualTabsServiceListElement, "getInitialConfig", this, 3)([]), {
            defaults: {
              repeater_title_setting: "service_title"
            }
          });
        }
      }]);
    }(NestedElementBase);
    elementor.elementsManager.registerElementType(new HappyVisualTabsServiceListElement());
    registered = true;
    return true;
  }
  if (window.elementorCommon && elementorCommon.elements && elementorCommon.elements.$window) {
    elementorCommon.elements.$window.on("elementor/nested-element-type-loaded", register);
  }
  jQuery(function () {
    if (registered) {
      return;
    }
    var attempts = 0;
    var interval = setInterval(function () {
      if (register() || ++attempts > 60) {
        clearInterval(interval);
      }
    }, 150);
  });
}();