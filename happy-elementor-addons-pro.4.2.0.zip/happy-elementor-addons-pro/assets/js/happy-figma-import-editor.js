"use strict";

function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
/**
 * Happy Widget from Figma - editor handler
 *
 * Imports a Figma design (FigWP JSON) as Elementor elements
 * into the currently open document.
 */

(function (window) {
  'use strict';

  var localize = window.HappyFigmaImport || {};
  var ajaxUrl = localize.ajax_url || window.ajaxurl;
  var nonce = localize.nonce || '';

  /**
   * Upload remote Figma images to the WordPress media library.
   *
   * @param {Array} figmaUrls List of remote image URLs.
   * @return {Promise} Resolves with {url: {id, url}} map or null on failure.
   */
  function uploadFigmaImages(figmaUrls) {
    return fetch(ajaxUrl, {
      method: 'POST',
      body: new URLSearchParams({
        action: 'ha_upload_figma_images',
        nonce: nonce,
        figma_urls: JSON.stringify(figmaUrls)
      })
    }).then(function (response) {
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      return response.json();
    }).then(function (data) {
      if (!data.success) {
        throw new Error(data.data || 'Failed to upload images');
      }
      return data.data.images;
    })["catch"](function (error) {
      console.error('Error uploading images:', error);
      return null;
    });
  }

  /**
   * Upload a single inline base64 data image (data:image/...;base64,...)
   * to the WordPress media library.
   *
   * @param {string} dataUri Image data URI.
   * @return {Promise} Resolves with {id, url} or null on failure.
   */
  function uploadFigmaDataImage(dataUri) {
    return fetch(ajaxUrl, {
      method: 'POST',
      body: new URLSearchParams({
        action: 'ha_upload_figma_data_image',
        nonce: nonce,
        figma_data_image: dataUri
      })
    }).then(function (response) {
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      return response.json();
    }).then(function (data) {
      if (!data.success) {
        throw new Error(data.data || 'Failed to upload image');
      }
      return data.data.image;
    })["catch"](function (error) {
      console.error('Error uploading data image:', error);
      return null;
    });
  }

  /**
   * Upload inline data images one by one to keep every request small.
   *
   * @param {Array} dataUris List of image data URIs.
   * @return {Promise} Resolves with {dataUri: {id, url}} map or null.
   */
  function uploadFigmaDataImages(dataUris) {
    var uploadedImages = {};
    return dataUris.reduce(function (chain, dataUri) {
      return chain.then(function () {
        return uploadFigmaDataImage(dataUri).then(function (image) {
          if (image) {
            uploadedImages[dataUri] = image;
          }
        });
      });
    }, Promise.resolve()).then(function () {
      return Object.keys(uploadedImages).length ? uploadedImages : null;
    });
  }

  /**
   * Find every http URL stored under a *url* key inside the content.
   *
   * @param {Array|Object} content Elementor elements.
   * @return {Array} List of URLs.
   */
  function findUrlsInContent(content) {
    var urls = [];
    function traverse(obj) {
      if (!obj || _typeof(obj) !== 'object') {
        return;
      }
      for (var key in obj) {
        if (key.toLowerCase().indexOf('url') !== -1 && typeof obj[key] === 'string' && obj[key].indexOf('http') === 0) {
          urls.push(obj[key]);
        }
      }
      for (var childKey in obj) {
        if (Array.isArray(obj[childKey])) {
          obj[childKey].forEach(traverse);
        } else if (obj[childKey] && _typeof(obj[childKey]) === 'object') {
          traverse(obj[childKey]);
        }
      }
    }
    if (Array.isArray(content)) {
      content.forEach(traverse);
    } else {
      traverse(content);
    }
    return urls;
  }

  /**
   * Replace remote Figma URLs with the freshly uploaded media URLs.
   *
   * @param {Object} obj            Element settings.
   * @param {Object} uploadedImages {remoteUrl: {id, url}} map.
   */
  function replaceUrlsInContent(obj, uploadedImages) {
    if (!obj || _typeof(obj) !== 'object') {
      return;
    }
    for (var key in obj) {
      if (key.toLowerCase().indexOf('url') !== -1 && typeof obj[key] === 'string' && obj[key].indexOf('http') === 0 && uploadedImages[obj[key]]) {
        obj[key] = uploadedImages[obj[key]].url;
      }
    }
    for (var childKey in obj) {
      if (Array.isArray(obj[childKey])) {
        obj[childKey].forEach(function (item) {
          replaceUrlsInContent(item, uploadedImages);
        });
      } else if (obj[childKey] && _typeof(obj[childKey]) === 'object') {
        replaceUrlsInContent(obj[childKey], uploadedImages);
      }
    }
  }

  /**
   * Find every inline base64 data image in the content, including
   * URIs embedded inside HTML strings (e.g. <img src="data:...">).
   *
   * @param {Array|Object} content Elementor elements.
   * @return {Array} List of unique data URIs.
   */
  function findDataImagesInContent(content) {
    var pattern = /data:image\/(?:png|jpe?g|webp|gif);base64,[A-Za-z0-9+/=]+/g;
    var seen = {};
    var uris = [];
    function scanValue(value) {
      var match;
      pattern.lastIndex = 0;
      while ((match = pattern.exec(value)) !== null) {
        if (!seen[match[0]]) {
          seen[match[0]] = true;
          uris.push(match[0]);
        }
      }
    }
    function traverse(obj) {
      if (!obj || _typeof(obj) !== 'object') {
        return;
      }
      for (var key in obj) {
        var value = obj[key];
        if (typeof value === 'string' && value.indexOf('data:image/') !== -1) {
          scanValue(value);
        } else if (Array.isArray(value)) {
          value.forEach(traverse);
        } else if (value && _typeof(value) === 'object') {
          traverse(value);
        }
      }
    }
    traverse(content);
    return uris;
  }

  /**
   * Replace uploaded data URIs (including occurrences inside HTML
   * strings) with the freshly uploaded media URLs.
   *
   * @param {Object} obj            Element settings.
   * @param {Object} uploadedImages {dataUri: {id, url}} map.
   */
  function replaceDataImagesInContent(obj, uploadedImages) {
    if (!obj || _typeof(obj) !== 'object') {
      return;
    }
    for (var key in obj) {
      var value = obj[key];
      if (typeof value === 'string' && value.indexOf('data:image/') !== -1) {
        for (var dataUri in uploadedImages) {
          if (value.indexOf(dataUri) !== -1) {
            value = value.split(dataUri).join(uploadedImages[dataUri].url);
          }
        }
        obj[key] = value;
      } else if (Array.isArray(value)) {
        value.forEach(function (item) {
          replaceDataImagesInContent(item, uploadedImages);
        });
      } else if (value && _typeof(value) === 'object') {
        replaceDataImagesInContent(value, uploadedImages);
      }
    }
  }

  /**
   * FigWP exports Figma component instances as elType: "widget" with no
   * widgetType and nested elements. Elementor can't render those and fatals
   * on save, so turn them into containers, or drop them when childless.
   *
   * @param {Array} elements Elements to sanitize.
   * @return {Array} Sanitized elements.
   */
  function sanitizeElements(elements) {
    if (!Array.isArray(elements)) {
      return [];
    }
    return elements.reduce(function (result, element) {
      if (!element || _typeof(element) !== 'object') {
        return result;
      }
      var children = sanitizeElements(element.elements);
      if (element.elType === 'widget' && !element.widgetType) {
        if (!children.length) {
          return result;
        }
        element.elType = 'container';
        delete element.widgetType;
      }

      // PHP serializes empty settings as an array, Elementor expects an object.
      if (Array.isArray(element.settings)) {
        element.settings = {};
      }
      element.elements = children;
      result.push(element);
      return result;
    }, []);
  }
  function figmaRgba(color) {
    if (!color) {
      return '';
    }
    var r = Math.round(color.r * 255);
    var g = Math.round(color.g * 255);
    var b = Math.round(color.b * 255);
    var a = color.a === undefined ? 1 : color.a;
    return 'rgba(' + r + ', ' + g + ', ' + b + ', ' + a + ')';
  }
  function figmaSolidFill(node) {
    var fills = node && node.fills;
    if (!Array.isArray(fills)) {
      return '';
    }
    for (var i = 0; i < fills.length; i++) {
      var fill = fills[i];
      if (fill && fill.visible !== false && fill.type === 'SOLID' && fill.color) {
        return figmaRgba(fill.color);
      }
    }
    return '';
  }
  function figmaBox(node) {
    return node && node.absoluteBoundingBox ? node.absoluteBoundingBox : null;
  }
  function coversParent(box, parentBox) {
    var tolerance = 2;
    return !!(box && parentBox && Math.abs(box.x - parentBox.x) <= tolerance && Math.abs(box.y - parentBox.y) <= tolerance && Math.abs(box.x + box.width - parentBox.x - parentBox.width) <= tolerance && Math.abs(box.y + box.height - parentBox.y - parentBox.height) <= tolerance);
  }
  function pxDimension(value) {
    return {
      unit: 'px',
      size: Math.round(value),
      isLinked: true
    };
  }
  function cornerDimension(radius) {
    var value = String(Math.round(radius));
    return {
      unit: 'px',
      top: value,
      right: value,
      bottom: value,
      left: value,
      isLinked: true
    };
  }
  function marginDimension(top, left) {
    return {
      unit: 'px',
      top: Math.round(top),
      right: '',
      bottom: '',
      left: Math.round(left),
      isLinked: false
    };
  }
  function relativeCenter(box, parentBox, axis) {
    var start = axis === 'x' ? box.x : box.y;
    var size = axis === 'x' ? box.width : box.height;
    var parentStart = axis === 'x' ? parentBox.x : parentBox.y;
    var parentSize = axis === 'x' ? parentBox.width : parentBox.height;
    if (!parentSize) {
      return 0.5;
    }
    return (start + size / 2 - parentStart) / parentSize;
  }
  function centerToEdge(value) {
    if (value < 0.34) {
      return 'start';
    }
    return value > 0.66 ? 'end' : 'center';
  }
  function mapTextAlign(align) {
    if (align === 'CENTER') {
      return 'center';
    }
    if (align === 'RIGHT') {
      return 'right';
    }
    if (align === 'JUSTIFIED') {
      return 'justify';
    }
    return 'left';
  }
  function headerSizeFor(fontSize) {
    if (fontSize >= 40) {
      return 'h1';
    }
    if (fontSize >= 28) {
      return 'h2';
    }
    if (fontSize >= 20) {
      return 'h3';
    }
    return 'h4';
  }
  function buildTextWidget(node, parentBox) {
    var style = node.style || {};
    var box = figmaBox(node);
    var fontSize = style.fontSize || 16;
    var settings = {
      title: node.characters || '',
      header_size: headerSizeFor(fontSize),
      align: mapTextAlign(style.textAlignHorizontal),
      typography_typography: 'custom',
      typography_font_family: style.fontFamily || '',
      typography_font_size: {
        unit: 'px',
        size: Math.round(fontSize)
      },
      typography_font_weight: String(Math.round(style.fontWeight || 400))
    };
    var color = figmaSolidFill(node);
    if (color) {
      settings.title_color = color;
    }
    if (parentBox && box) {
      settings.margin = marginDimension(box.y - parentBox.y, box.x - parentBox.x);
    }
    return {
      elType: 'widget',
      widgetType: 'heading',
      settings: settings,
      elements: []
    };
  }
  function buildBoxContainer(node, parentBox) {
    var box = figmaBox(node);
    if (!box) {
      return null;
    }
    var settings = {
      content_width: 'boxed',
      width: pxDimension(box.width),
      height: 'min-height',
      min_height: pxDimension(box.height)
    };
    var color = figmaSolidFill(node);
    if (color) {
      settings.background_background = 'classic';
      settings.background_color = color;
    }
    if (node.cornerRadius) {
      settings.border_radius = cornerDimension(node.cornerRadius);
    }
    if (parentBox) {
      settings.margin = marginDimension(box.y - parentBox.y, box.x - parentBox.x);
    }
    return {
      elType: 'container',
      settings: settings,
      elements: []
    };
  }
  function buildFrameContainer(node, parentBox) {
    var box = figmaBox(node);
    if (!box) {
      return null;
    }
    var settings = {
      content_width: 'boxed',
      width: pxDimension(box.width),
      height: 'min-height',
      min_height: pxDimension(box.height)
    };
    var children = node.children || [];
    var rest = [];
    var i;
    var child;
    var backgroundColor = '';
    var radius = 0;
    for (i = 0; i < children.length; i++) {
      child = children[i];
      if (child.type === 'RECTANGLE' && !backgroundColor && coversParent(figmaBox(child), box)) {
        backgroundColor = figmaSolidFill(child);
        radius = child.cornerRadius || 0;
      } else {
        rest.push(child);
      }
    }
    if (backgroundColor) {
      settings.background_background = 'classic';
      settings.background_color = backgroundColor;
    }
    if (radius) {
      settings.border_radius = cornerDimension(radius);
    }
    var elements = [];
    if (rest.length === 1 && rest[0].type === 'TEXT') {
      var textBox = figmaBox(rest[0]);
      var horizontal = centerToEdge(relativeCenter(textBox, box, 'x'));
      var vertical = centerToEdge(relativeCenter(textBox, box, 'y'));
      settings.flex_direction = 'column';
      settings.align_items = horizontal === 'start' ? 'flex-start' : horizontal === 'end' ? 'flex-end' : 'center';
      settings.justify_content = vertical === 'start' ? 'flex-start' : vertical === 'end' ? 'flex-end' : 'center';
      elements.push(buildTextWidget(rest[0], null));
    } else {
      settings.flex_direction = 'column';
      settings.align_items = 'flex-start';
      settings.gap = {
        unit: 'px',
        size: 0
      };
      var bands = groupNodesIntoRows(rest);
      var prevBottom = box.y;
      for (i = 0; i < bands.length; i++) {
        var band = bands[i];
        var bandElement = band.nodes.length === 1 ? convertFigmaNode(band.nodes[0], box) : buildRowContainer(band);
        if (bandElement) {
          bandElement.settings.margin = marginDimension(band.box.y - prevBottom, band.box.x - box.x);
          elements.push(bandElement);
          prevBottom = Math.max(prevBottom, band.box.y + band.box.height);
        }
      }
    }
    if (parentBox) {
      settings.margin = marginDimension(box.y - parentBox.y, box.x - parentBox.x);
    }
    return {
      elType: 'container',
      settings: settings,
      elements: elements
    };
  }
  function convertFigmaNode(node, parentBox) {
    if (!node || node.visible === false) {
      return null;
    }
    if (node.type === 'TEXT') {
      return buildTextWidget(node, parentBox);
    }
    if (node.type === 'RECTANGLE') {
      return buildBoxContainer(node, parentBox);
    }
    if (node.type === 'FRAME' || node.type === 'GROUP' || node.type === 'COMPONENT' || node.type === 'INSTANCE') {
      return buildFrameContainer(node, parentBox);
    }
    return null;
  }

  /**
   * Group nodes into horizontal bands (visual rows) so content that
   * sits side by side in Figma stays side by side after import.
   *
   * Nodes whose top edge starts more than 10px above the current
   * band's bottom edge belong to the same visual row.
   *
   * @param {Array} nodes Figma nodes.
   * @return {Array} Bands: {box: {x, y, width, height}, nodes: []}.
   */
  function groupNodesIntoRows(nodes) {
    var boxed = nodes.filter(function (node) {
      return figmaBox(node);
    }).sort(function (a, b) {
      var boxA = figmaBox(a);
      var boxB = figmaBox(b);
      return boxA.y - boxB.y || boxA.x - boxB.x;
    });
    var bands = [];
    for (var i = 0; i < boxed.length; i++) {
      var box = figmaBox(boxed[i]);
      var band = bands[bands.length - 1];
      if (band && box.y < band.box.y + band.box.height - 10) {
        if (box.x < band.box.x) {
          band.box.width += band.box.x - box.x;
          band.box.x = box.x;
        }
        if (box.x + box.width > band.box.x + band.box.width) {
          band.box.width = box.x + box.width - band.box.x;
        }
        if (box.y + box.height > band.box.y + band.box.height) {
          band.box.height = box.y + box.height - band.box.y;
        }
        band.nodes.push(boxed[i]);
      } else {
        bands.push({
          box: {
            x: box.x,
            y: box.y,
            width: box.width,
            height: box.height
          },
          nodes: [boxed[i]]
        });
      }
    }
    return bands;
  }

  /**
   * Build a flex row container for a band of side-by-side nodes.
   *
   * Children margins are computed relative to the previous sibling
   * so the horizontal gaps from Figma are preserved in flex flow.
   *
   * @param {Object} band {box, nodes} band from groupNodesIntoRows().
   * @return {Object|null} Container element.
   */
  function buildRowContainer(band) {
    var sorted = band.nodes.slice().sort(function (a, b) {
      return figmaBox(a).x - figmaBox(b).x;
    });
    var elements = [];
    var prevRight = band.box.x;
    for (var i = 0; i < sorted.length; i++) {
      var childBox = figmaBox(sorted[i]);
      var child = convertFigmaNode(sorted[i], band.box);
      if (child) {
        child.settings.margin = marginDimension(childBox.y - band.box.y, childBox.x - prevRight);
        elements.push(child);
        prevRight = childBox.x + childBox.width;
      }
    }
    if (!elements.length) {
      return null;
    }
    return {
      elType: 'container',
      settings: {
        flex_direction: 'row',
        flex_wrap: 'nowrap',
        align_items: 'flex-start',
        gap: {
          unit: 'px',
          size: 0
        },
        width: pxDimension(band.box.width),
        height: 'min-height',
        min_height: pxDimension(band.box.height)
      },
      elements: elements
    };
  }
  function findFirstCanvas(document) {
    if (!document || !Array.isArray(document.children)) {
      return null;
    }
    for (var i = 0; i < document.children.length; i++) {
      var child = document.children[i];
      if (child.type === 'CANVAS' && Array.isArray(child.children) && child.children.length) {
        return child;
      }
    }
    return null;
  }
  function normalizeImportJson(jsonData) {
    if (jsonData && Array.isArray(jsonData.content) && jsonData.content.length) {
      return jsonData;
    }
    if (!(jsonData && jsonData.document && jsonData.document.type === 'DOCUMENT')) {
      return null;
    }
    var canvas = findFirstCanvas(jsonData.document);
    if (!canvas) {
      return null;
    }
    var sorted = canvas.children.slice().sort(function (a, b) {
      var boxA = figmaBox(a);
      var boxB = figmaBox(b);
      var topA = boxA ? boxA.y : 0;
      var topB = boxB ? boxB.y : 0;
      if (topA !== topB) {
        return topA - topB;
      }
      var leftA = boxA ? boxA.x : 0;
      var leftB = boxB ? boxB.x : 0;
      return leftA - leftB;
    });
    var originX = Infinity;
    for (var j = 0; j < sorted.length; j++) {
      var canvasBox = figmaBox(sorted[j]);
      if (canvasBox) {
        originX = Math.min(originX, canvasBox.x);
      }
    }
    if (originX === Infinity) {
      originX = 0;
    }
    var bands = groupNodesIntoRows(sorted);
    var content = [];
    var prevBottom = null;
    for (var i = 0; i < bands.length; i++) {
      var band = bands[i];
      var element = band.nodes.length === 1 ? convertFigmaNode(band.nodes[0], null) : buildRowContainer(band);
      if (!element) {
        continue;
      }
      element.settings.margin = marginDimension(prevBottom === null ? 0 : band.box.y - prevBottom, band.box.x - originX);
      content.push(element);
      prevBottom = prevBottom === null ? band.box.y + band.box.height : Math.max(prevBottom, band.box.y + band.box.height);
    }
    return content.length ? {
      content: content
    } : null;
  }

  /**
   * Insert the template content into the document, then remove
   * the import widget itself.
   *
   * @param {string} elementId Import widget element id.
   * @param {Object} template  FigWP template JSON.
   * @return {Promise} Resolves with bool success.
   */
  function insertElementorTemplate(elementId, template) {
    template.content = sanitizeElements(template.content);
    if (!template.content.length) {
      return Promise.resolve(false);
    }
    var figmaUrls = findUrlsInContent(template.content);
    var figmaDataImages = findDataImagesInContent(template.content);
    var uploadPromise = Promise.all([figmaUrls.length > 0 ? uploadFigmaImages(figmaUrls) : Promise.resolve(null), uploadFigmaDataImages(figmaDataImages)]);
    return uploadPromise.then(function (uploads) {
      var uploadedImages = uploads[0];
      var uploadedDataImages = uploads[1];
      if (uploadedImages) {
        template.content.forEach(function (item) {
          replaceUrlsInContent(item, uploadedImages);
        });
      }
      if (uploadedDataImages) {
        template.content.forEach(function (item) {
          replaceDataImagesInContent(item, uploadedDataImages);
        });
      }
      var elementor = window.elementor;
      if (typeof elementor === 'undefined') {
        return false;
      }
      var $e = window.parent.$e || window.$e;
      if (typeof $e === 'undefined') {
        return false;
      }
      var insertIndex = window.TemplatelyIndex;
      for (var i = 0; i < template.content.length; i++) {
        $e.run('document/elements/create', {
          container: elementor.getPreviewContainer(),
          model: template.content[i],
          options: insertIndex >= 0 ? {
            at: insertIndex++
          } : {}
        });
      }

      // Remove the import widget after a successful import.
      try {
        var container = elementor.getPreviewView().getContainer();
        var targetElement = container.findChildrenRecursive(function (child) {
          return child.id === elementId;
        });
        if (targetElement) {
          var deleteElement = targetElement.parent && targetElement.parent.children && targetElement.parent.children.length === 1 ? targetElement.parent : targetElement;
          $e.run('document/elements/delete', {
            container: deleteElement
          });
        }
      } catch (error) {
        console.error('Error deleting element:', error);
      }
      return true;
    });
  }

  /**
   * Read the template JSON from the uploaded media file.
   *
   * @param {number} fileId Attachment id.
   * @return {Promise} Resolves with the parsed template JSON.
   */
  function fetchFileContent(fileId) {
    return fetch(ajaxUrl, {
      method: 'POST',
      body: new URLSearchParams({
        action: 'ha_get_figma_file_content',
        nonce: nonce,
        file_id: fileId
      })
    }).then(function (response) {
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      return response.json();
    }).then(function (data) {
      if (!data.success) {
        throw new Error(data.data || 'Failed to load file content');
      }
      return JSON.parse(data.data);
    });
  }

  /**
   * Bind the import buttons inside the widget panel.
   *
   * @param {Object} panel Editor panel.
   * @param {Object} model Widget model.
   * @param {Object} view  Widget view.
   */
  function initPanel(panel, model, view) {
    var elementId = view.container.args.id;
    panel.content.el.onclick = function (event) {
      var eventName = event.target && event.target.dataset ? event.target.dataset.event : '';
      if (!eventName || eventName.indexOf('happy:figmajson') !== 0) {
        return;
      }
      var button = event.target;
      var originalText = button.innerHTML;
      button.innerHTML = 'Importing...';
      button.disabled = true;
      var jsonPromise;
      if (eventName === 'happy:figmajson:import') {
        var jsonString = panel.content.el.querySelector('.ha-figma-import-json').value;
        jsonPromise = new Promise(function (resolve, reject) {
          try {
            resolve(JSON.parse(jsonString));
          } catch (error) {
            reject(error);
          }
        });
      } else {
        var settings = model && model.attributes && model.attributes.settings ? model.attributes.settings.attributes : {};
        var fileId = settings.figma_file ? settings.figma_file.id : null;
        if (!fileId) {
          jsonPromise = Promise.reject(new Error('Please upload a JSON file first.'));
        } else {
          jsonPromise = fetchFileContent(fileId);
        }
      }
      jsonPromise.then(function (jsonData) {
        if (!jsonData || !elementId) {
          throw new Error('Something went wrong! Please reload the page and try again.');
        }
        var template = normalizeImportJson(jsonData);
        if (!template) {
          throw new Error('Unrecognized JSON. Paste a FigWP template or a Figma file export (document > canvas > frames).');
        }
        return insertElementorTemplate(elementId, template);
      }).then(function (result) {
        if (!result) {
          throw new Error('Failed to import Figma content. Please try again.');
        }
        window.elementor.notifications.showToast({
          message: 'Figma content imported successfully!',
          type: 'success'
        });
      })["catch"](function (error) {
        window.elementor.notifications.showToast({
          message: error.message,
          type: 'error',
          sticky: error.message.indexOf('reload the page') !== -1
        });
        button.innerHTML = originalText;
        button.disabled = false;
      });
    };
  }
  if (window.elementor && window.elementor.hooks) {
    window.elementor.hooks.addAction('panel/open_editor/widget/ha-figma-import', initPanel);
  }
})(window);