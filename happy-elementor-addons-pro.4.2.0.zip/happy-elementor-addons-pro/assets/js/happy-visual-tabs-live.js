"use strict";

function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
!function () {
  "use strict";

  var WIDGET_TYPE = 'ha-visual-tabs';
  var LIVE_CONTROLS = ['service_title', 'prefix_text', 'prefix_position', 'title_zoom', 'title_zoom_scale', 'title_zoom_duration', 'title_zoom_easing', 'title_icon', 'title_icon_icon', 'title_icon_size', 'title_icon_spacing', 'title_icon_vertical_position'];
  var ZOOM_VAR_CONTROLS = {
    'title_zoom_scale': '--ha-v-tabs-title-zoom-scale',
    'title_zoom_duration': '--ha-v-tabs-title-zoom-duration',
    'title_zoom_easing': '--ha-v-tabs-title-zoom-easing'
  };
  var TITLE_ICON_VAR_CONTROLS = {
    'title_icon_size': '--ha-v-tabs-title-icon-size',
    'title_icon_spacing': '--ha-v-tabs-title-icon-gap',
    'title_icon_vertical_position': '--ha-v-tabs-title-icon-v-align'
  };
  function inList(controlName) {
    return -1 !== LIVE_CONTROLS.indexOf(controlName);
  }
  function getWidgetRoot(view) {
    if (!view || !view.$el || !view.$el.length) {
      return null;
    }
    var $root = view.$el.closest('.elementor-widget-ha-visual-tabs');
    if (!$root.length) {
      $root = view.$el.find('.elementor-widget-ha-visual-tabs');
    }
    return $root.length ? $root : null;
  }
  function patchPrefixPosition($root, value) {
    if (!$root || !$root.length) {
      return;
    }
    $root.find('.ha-v-tabs-title-wrap').attr('data-prefix-position', value);
  }
  function patchZoomControl($root, controlName, value) {
    if (!$root || !$root.length) {
      return;
    }
    var root = $root[0];
    if ('title_zoom' === controlName) {
      $root.find('.ha-v-tabs-list').first().toggleClass('ha-v-tabs-zoom', 'yes' === value);
      return;
    }
    var prop = ZOOM_VAR_CONTROLS[controlName];
    if (!prop) {
      return;
    }
    var cssValue;
    if ('title_zoom_scale' === controlName) {
      cssValue = value && 'object' === _typeof(value) ? value.size : value;
      if (cssValue) {
        cssValue = String(cssValue);
      }
    } else if ('title_zoom_duration' === controlName) {
      cssValue = value && 'object' === _typeof(value) ? value.size : value;
      if (cssValue) {
        cssValue += 'ms';
      }
    } else {
      cssValue = value;
    }
    if (cssValue) {
      root.style.setProperty(prop, cssValue);
    } else {
      root.style.removeProperty(prop);
    }
  }
  function renderIconHtml(view, icon) {
    if (!icon || !icon.value) {
      return '';
    }
    try {
      var rendered = elementor.helpers.renderIcon(view, icon, {
        'aria-hidden': true
      }, 'i', 'object');
      return typeof rendered === 'string' ? rendered : rendered && rendered.value || '';
    } catch (e) {
      return '';
    }
  }
  function settingsValue(settingsModel, name) {
    if (settingsModel && typeof settingsModel.get === 'function') {
      var value = settingsModel.get(name);
      if ('undefined' !== typeof value) {
        return value;
      }
    }
    return null;
  }
  function injectTitleIcons($root, html) {
    $root.find('.ha-v-tabs-title-wrap').each(function () {
      var $wrap = jQuery(this);
      var $title = $wrap.children('.ha-v-tabs-service-title').first();
      if (!$title.length) {
        return;
      }
      var $icon = $wrap.children('.ha-v-tabs-title-active-icon').first();
      if ($icon.length) {
        $icon.html(html);
      } else {
        jQuery('<span class="ha-v-tabs-title-active-icon" aria-hidden="true"></span>').html(html).insertBefore($title);
      }
    });
  }
  function patchTitleIcon(view, $root, controlName, value, settingsModel) {
    if (!$root || !$root.length) {
      return;
    }
    var $list = $root.find('.ha-v-tabs-list').first();
    if (!$list.length) {
      return;
    }
    if ('title_icon' === controlName) {
      if ('yes' !== value) {
        $list.removeClass('ha-v-tabs-has-icon');
        $root.find('.ha-v-tabs-title-active-icon').remove();
        return;
      }
      var html = renderIconHtml(view, settingsValue(settingsModel, 'title_icon_icon'));
      if (!html) {
        return;
      }
      $list.addClass('ha-v-tabs-has-icon');
      injectTitleIcons($root, html);
      return;
    }
    if ('title_icon_icon' === controlName) {
      var iconHtml = renderIconHtml(view, value);
      if (!iconHtml) {
        $root.find('.ha-v-tabs-title-active-icon').remove();
        return;
      }
      if ('yes' !== settingsValue(settingsModel, 'title_icon')) {
        return;
      }
      $list.addClass('ha-v-tabs-has-icon');
      injectTitleIcons($root, iconHtml);
      return;
    }
    var prop = TITLE_ICON_VAR_CONTROLS[controlName];
    if (!prop) {
      return;
    }
    var cssValue;
    if (value && 'object' === _typeof(value)) {
      cssValue = value.size ? value.size + (value.unit || 'em') : '';
    } else {
      cssValue = value;
    }
    var root = $root[0];
    if (cssValue) {
      root.style.setProperty(prop, cssValue);
    } else {
      root.style.removeProperty(prop);
    }
  }
  function getEditedItem(view, $root) {
    var activeIndex = 0;
    try {
      activeIndex = view.container.model.get('editSettings').get('activeItemIndex');
      activeIndex = typeof activeIndex !== 'undefined' ? parseInt(activeIndex, 10) - 1 : 0;
    } catch (e) {
      activeIndex = 0;
    }
    var $items = $root.find('.ha-v-tabs-item');
    if (activeIndex >= 0 && activeIndex < $items.length) {
      return $items.eq(activeIndex);
    }
    var $active = $root.find('.ha-v-tabs-item.e-active');
    return $active.length ? $active : $items.first();
  }
  function isShowNumberEnabled(view, settingsModel) {
    var candidates = [];
    if (view && view.container) {
      candidates.push(view.container.settings);
      if (view.container.model) {
        candidates.push(view.container.model.get('settings'));
      }
    }
    candidates.push(settingsModel);
    for (var i = 0; i < candidates.length; i++) {
      if (candidates[i] && typeof candidates[i].get === 'function') {
        var value = candidates[i].get('show_number');
        if ('undefined' !== typeof value) {
          return 'yes' === value;
        }
      }
    }
    return true;
  }
  function patchActiveItemText(view, controlName, value, settingsModel) {
    var $root = getWidgetRoot(view);
    if (!$root || !$root.length) {
      return;
    }
    var $activeItem = getEditedItem(view, $root);
    if (!$activeItem.length) {
      return;
    }
    var $titleWrap = $activeItem.find('.ha-v-tabs-title-wrap').first();
    if (!controlName) {
      return;
    }
    if ('service_title' === controlName) {
      var titleText = String(value == null ? '' : value).trim();
      $titleWrap.find('.ha-v-tabs-service-title').text(titleText);
    } else if ('prefix_text' === controlName) {
      if (!isShowNumberEnabled(view, settingsModel)) {
        $titleWrap.find('.ha-v-tabs-service-number').remove();
        return;
      }
      var $number = $titleWrap.find('.ha-v-tabs-service-number');
      if (value) {
        if (!$number.length) {
          $number = jQuery('<span class="ha-v-tabs-service-number"></span>');
          $titleWrap.prepend($number);
        }
        $number.text(value);
      } else if ($number.length) {
        $number.remove();
      }
    }
  }
  function applyLive(view, controlName, value, settingsModel) {
    var $root = getWidgetRoot(view);
    if (!$root || !$root.length) {
      return;
    }
    switch (controlName) {
      case 'prefix_position':
        patchPrefixPosition($root, value);
        break;
      case 'service_title':
      case 'prefix_text':
        patchActiveItemText(view, controlName, value, settingsModel);
        break;
      case 'title_zoom':
      case 'title_zoom_scale':
      case 'title_zoom_duration':
      case 'title_zoom_easing':
        patchZoomControl($root, controlName, value);
        break;
      case 'title_icon':
      case 'title_icon_icon':
      case 'title_icon_size':
      case 'title_icon_spacing':
      case 'title_icon_vertical_position':
        patchTitleIcon(view, $root, controlName, value, settingsModel);
        break;
    }
  }
  function patchView() {
    var manager = elementor && elementor.elementsManager;
    if (!manager || !manager.elementTypes || !manager.elementTypes[WIDGET_TYPE]) {
      return false;
    }
    var elementClass = manager.elementTypes[WIDGET_TYPE];
    var ViewClass = elementClass.getView && elementClass.getView();
    if (!ViewClass || !ViewClass.prototype || typeof ViewClass.prototype.renderChanges !== 'function') {
      return false;
    }
    if (ViewClass.prototype.__haNslLivePatched) {
      return true;
    }
    var originalRenderChanges = ViewClass.prototype.renderChanges;
    ViewClass.prototype.renderChanges = function (settings) {
      try {
        if (!settings || typeof settings.changedAttributes !== 'function') {
          return originalRenderChanges.apply(this, arguments);
        }
        var changed = settings.changedAttributes();
        var changedKeys = Object.keys(changed);
        if (!changedKeys.length) {
          return originalRenderChanges.apply(this, arguments);
        }
        var hasLive = false;
        var hasOther = false;
        changedKeys.forEach(function (key) {
          if (inList(key)) {
            hasLive = true;
          } else {
            hasOther = true;
          }
        });
        if (hasLive && !hasOther) {
          var self = this;
          changedKeys.forEach(function (key) {
            applyLive(self, key, changed[key], settings);
          });
          return;
        }
      } catch (e) {
        return originalRenderChanges.apply(this, arguments);
      }
      return originalRenderChanges.apply(this, arguments);
    };
    ViewClass.prototype.__haNslLivePatched = true;
    return true;
  }
  function init() {
    if (typeof elementor === 'undefined') {
      return;
    }
    if (!patchView()) {
      setTimeout(init, 300);
    }
  }
  if (window.elementorCommon && elementorCommon.elements && elementorCommon.elements.$window) {
    elementorCommon.elements.$window.on('elementor:init', init);
  } else {
    jQuery(init);
  }
}();