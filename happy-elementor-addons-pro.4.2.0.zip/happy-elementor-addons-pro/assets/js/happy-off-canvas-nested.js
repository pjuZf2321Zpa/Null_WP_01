"use strict";

function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
function _classCallCheck(a, n) { if (!(a instanceof n)) throw new TypeError("Cannot call a class as a function"); }
function _defineProperties(e, r) { for (var t = 0; t < r.length; t++) { var o = r[t]; o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(e, _toPropertyKey(o.key), o); } }
function _createClass(e, r, t) { return r && _defineProperties(e.prototype, r), t && _defineProperties(e, t), Object.defineProperty(e, "prototype", { writable: !1 }), e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == _typeof(i) ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != _typeof(t) || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != _typeof(i)) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
function _callSuper(t, o, e) { return o = _getPrototypeOf(o), _possibleConstructorReturn(t, _isNativeReflectConstruct() ? Reflect.construct(o, e || [], _getPrototypeOf(t).constructor) : o.apply(t, e)); }
function _possibleConstructorReturn(t, e) { if (e && ("object" == _typeof(e) || "function" == typeof e)) return e; if (void 0 !== e) throw new TypeError("Derived constructors may only return object or undefined"); return _assertThisInitialized(t); }
function _assertThisInitialized(e) { if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); return e; }
function _isNativeReflectConstruct() { try { var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); } catch (t) {} return (_isNativeReflectConstruct = function _isNativeReflectConstruct() { return !!t; })(); }
function _getPrototypeOf(t) { return _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function (t) { return t.__proto__ || Object.getPrototypeOf(t); }, _getPrototypeOf(t); }
function _inherits(t, e) { if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function"); t.prototype = Object.create(e && e.prototype, { constructor: { value: t, writable: !0, configurable: !0 } }), Object.defineProperty(t, "prototype", { writable: !1 }), e && _setPrototypeOf(t, e); }
function _setPrototypeOf(t, e) { return _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function (t, e) { return t.__proto__ = e, t; }, _setPrototypeOf(t, e); }
/**
 * Off Canvas widget - nested content editor handler.
 *
 * Registers the "ha-off-canvas" widget as a nested element type so dropped
 * widgets (locked containers) render inside the ".ha-offcanvas-body"
 * placeholder, and makes sure a content container exists when the
 * "Nested Content (Drop Widgets)" type is selected on existing widgets.
 */
!function () {
  "use strict";

  var registered = false;
  function register() {
    if (registered) {
      return true;
    }
    if (typeof elementor === "undefined" || typeof $e === "undefined") {
      return false;
    }
    var repeaterComponent = $e.components && $e.components.get("nested-elements/nested-repeater");
    var nestedComponent = $e.components && $e.components.get("nested-elements");
    var repeaterExports = repeaterComponent && repeaterComponent.exports ? repeaterComponent.exports : null;
    var nestedExports = nestedComponent && nestedComponent.exports ? nestedComponent.exports : null;

    // NestedModelBase / NestedViewBase live on the "nested-repeater" component
    // exports; the final NestedView lives on the "nested-elements" component.
    var NestedViewBase = repeaterExports && repeaterExports.NestedViewBase;
    var NestedModelBase = repeaterExports && repeaterExports.NestedModelBase;
    var NestedView = nestedExports && nestedExports.NestedView || NestedViewBase;
    if (typeof NestedViewBase !== "function" || typeof NestedModelBase !== "function" || typeof NestedView !== "function") {
      return false;
    }
    var NestedElementBase = elementor.modules && elementor.modules.elements && elementor.modules.elements.types && elementor.modules.elements.types.NestedElementBase;
    if (typeof NestedElementBase !== "function") {
      return false;
    }
    function getContainer(view) {
      if (!view) {
        return null;
      }
      if (typeof view.getContainer === "function") {
        try {
          return view.getContainer();
        } catch (e) {
          /* fall through */
        }
      }
      return view.container || null;
    }
    function ensureNestedContainer(view) {
      var container = getContainer(view);
      if (!container || !container.settings) {
        return;
      }
      try {
        if ("nested" !== container.settings.get("content_type")) {
          return;
        }
      } catch (e) {
        return;
      }
      if (container.children && container.children.length) {
        return;
      }
      if (view._haOffcanvasEnsuring) {
        return;
      }
      view._haOffcanvasEnsuring = true;
      setTimeout(function () {
        try {
          $e.run("document/elements/create", {
            container: container,
            model: {
              elType: "container",
              isLocked: true,
              _title: "Off-Canvas Content",
              settings: {
                content_width: "full"
              }
            },
            options: {
              edit: false
            }
          });
        } catch (e) {
          if (window.console) {
            window.console.warn("Happy Off Canvas: unable to create the nested content container.", e);
          }
        }
        view._haOffcanvasEnsuring = false;
      }, 50);
    }

    /**
     * Restore the editor open state on a freshly rendered view, before
     * the browser paints. Without this, an editor re-render (e.g. the
     * first selection of the widget) replaces the open content with a
     * closed copy for one frame - perceived as a show/hide flicker.
     */
    function restoreOpenState(view) {
      try {
        var $content = view.$el.find(".ha-offcanvas-content.ha-offcanvas-type-nested");
        if (!$content.length) {
          return;
        }
        var $wrap = view.$el.find(".ha-offcanvas-content-wrap");
        var settings = {};
        try {
          settings = JSON.parse($wrap.attr("data-settings") || "{}");
        } catch (e) {
          /* ignore */
        }
        var id = settings.content_id;
        if (!id) {
          return;
        }
        var doc = view.el.ownerDocument;
        var isOpen = jQuery(doc.documentElement).hasClass("ha-offcanvas-content-" + id + "-open");
        if (!isOpen) {
          return;
        }
        var transition = settings.transition || "slide";
        if ("reveal" === transition || "push" === transition) {
          $content.addClass("ha-offcanvas-editor-slide");
        }
        $content.addClass("ha-offcanvas-content-visible ha-offcanvas-editor-open ha-offcanvas-editor-no-anim");
        view.$el.find(".ha-offcanvas-toggle").addClass("ha-is-active");
        $wrap.addClass("ha-offcanvas-wrap-editor-open");

        // Re-enable transitions after the restored frame has painted.
        requestAnimationFrame(function () {
          requestAnimationFrame(function () {
            $content.removeClass("ha-offcanvas-editor-no-anim");
          });
        });
      } catch (e) {
        /* ignore */
      }
    }
    var HappyOffCanvasView = /*#__PURE__*/function (_NestedView) {
      function HappyOffCanvasView() {
        _classCallCheck(this, HappyOffCanvasView);
        return _callSuper(this, HappyOffCanvasView, arguments);
      }
      _inherits(HappyOffCanvasView, _NestedView);
      return _createClass(HappyOffCanvasView, [{
        key: "getTemplateType",
        value:
        /**
         * Nested content renders via the widget JS template; every other
         * content type (sidebar, custom, saved templates...) keeps the
         * legacy "remote" server rendering in the editor.
         */
        function getTemplateType() {
          try {
            var container = getContainer(this);
            if (container && container.settings && "nested" === container.settings.get("content_type")) {
              return "js";
            }
          } catch (e) {
            /* fall through */
          }
          return "remote";
        }

        /**
         * The nested view chain renders an empty template for "remote"
         * widgets and never injects the fetched server HTML (unlike the
         * legacy widget view), which blanks the widget - e.g. the burger
         * toggle disappeared when switching to a legacy content type.
         * Mirror the legacy behavior: defer the attach and inject the
         * model html cache for remote rendering; keep the synchronous
         * base behavior for the nested (js template) rendering.
         */
      }, {
        key: "getHTMLContent",
        value: function getHTMLContent(html) {
          try {
            return this.getEditModel().getHtmlCache() || html;
          } catch (e) {
            return html;
          }
        }
      }, {
        key: "attachElContent",
        value: function attachElContent(html) {
          if ("remote" !== this.getTemplateType()) {
            return NestedView.prototype.attachElContent.call(this, html);
          }
          var view = this;
          _.defer(function () {
            elementorFrontend.elements.window.jQuery(view.el).empty().append(view.getHandlesOverlay(), view.getHTMLContent(html));
            view.bindUIElements();
          });
          return this;
        }
      }, {
        key: "onRender",
        value: function onRender() {
          if (typeof NestedView.prototype.onRender === "function") {
            NestedView.prototype.onRender.call(this);
          }
          restoreOpenState(this);
          ensureNestedContainer(this);
        }
      }]);
    }(NestedView);
    var HappyOffCanvasElement = /*#__PURE__*/function (_NestedElementBase) {
      function HappyOffCanvasElement() {
        _classCallCheck(this, HappyOffCanvasElement);
        return _callSuper(this, HappyOffCanvasElement, arguments);
      }
      _inherits(HappyOffCanvasElement, _NestedElementBase);
      return _createClass(HappyOffCanvasElement, [{
        key: "getType",
        value: function getType() {
          return "ha-off-canvas";
        }
      }, {
        key: "getView",
        value: function getView() {
          return HappyOffCanvasView;
        }
      }, {
        key: "getModel",
        value: function getModel() {
          return NestedModelBase;
        }
      }]);
    }(NestedElementBase);
    elementor.elementsManager.registerElementType(new HappyOffCanvasElement());
    registered = true;
    return true;
  }
  if (window.elementorCommon && elementorCommon.elements && elementorCommon.elements.$window) {
    elementorCommon.elements.$window.on("elementor/nested-element-type-loaded", register);
  }
  jQuery(function () {
    if (registered) {
      return;
    }
    var attempts = 0;
    var interval = setInterval(function () {
      if (register() || ++attempts > 60) {
        clearInterval(interval);
        if (!registered && window.console) {
          window.console.warn("Happy Off Canvas: nested elements module not available, the nested content drop zone is disabled.");
        }
      }
    }, 150);
  });
}();