<?php
/**
 * @wordpress-plugin
 * Plugin Name:       WhatsApp Chat by NinjaTeam
 * Plugin URI:        https://ninjateam.org/whatsapp-chat-wordpress/
 * Description:       Integrate your WhatsApp experience directly into your website. This is one of the best way to connect and interact with your customer.
 * Version:           3.8.3
 * Author:            NinjaTeam
 * Author URI:        https://ninjateam.org
 * Text Domain:       ninjateam-whatsapp
 * Domain Path:       /languages
 */
namespace NTA_WhatsApp;

defined( 'ABSPATH' ) || exit;

if ( function_exists( 'NTA_WhatsApp\\init' ) ) {
	require_once plugin_dir_path( __FILE__ ) . 'includes/Fallback.php';
	add_action(
		'admin_init',
		function () {
			deactivate_plugins( plugin_basename( __FILE__ ) );
		}
	);
	return;
}

if ( ! defined( 'NTA_WHATSAPP_VERSION' ) ) {
	define( 'NTA_WHATSAPP_VERSION', '3.8.3' );
}

if ( ! defined( 'NTA_WHATSAPP_PLUGIN_URL' ) ) {
	define( 'NTA_WHATSAPP_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
}

if ( ! defined( 'NTA_WHATSAPP_PLUGIN_DIR' ) ) {
	define( 'NTA_WHATSAPP_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
}

if ( ! defined( 'NTA_WHATSAPP_BASE_NAME' ) ) {
	define( 'NTA_WHATSAPP_BASE_NAME', plugin_basename( __FILE__ ) );
}

$GLOBALS['yay_reviews_plugins'][] = [
	'slug' => 'whatsapp_wp',
	'name' => 'WhatsApp WP',
	'textdomain' => 'wp-whatsapp',
	'option_name' => 'wa_review',
	'display_time' => 3, // after 3 days
	'review_link' => 'https://wordpress.org/support/plugin/wp-whatsapp/reviews/#new-post',
	'display_pages' => function (){
		$include_pages = ['whatsapp-accounts', 'edit-whatsapp-accounts', 'whatsapp_page_nta_whatsapp_floating_widget', 'whatsapp_page_nta_whatsapp_setting'];
		$current_screen_id = get_current_screen()->id;
		
		return in_array($current_screen_id, $include_pages);
	},
];

if ( file_exists( __DIR__ . '/recommended-modules/loader.php' ) ) {
	require_once __DIR__ . '/recommended-modules/loader.php';
}

// Register this consumer's ad-module slugs for the shared ads-toggle module (see
// recommended-modules/ads-toggle). Per-consumer, AND-aggregated: an ad only fully disappears
// once every consumer that registered it has toggled it off — a different consumer bundling
// the same ad_slug is unaffected by this plugin's own toggle state. Must run AFTER the loader
// require above — Registry only exists once recommended-modules/registry.php has loaded.
if ( class_exists( '\YayRecommendedModules\Registry' ) ) {
	foreach ( [ 'filebird-dashboard-widget', 'filebird-plugins-page-notification', 'filebird-sidebar-popup' ] as $njt_ad_slug ) {
		\YayRecommendedModules\Registry::register_ads_consumer( 'whatsapp-wp', $njt_ad_slug );
	}
}

spl_autoload_register(
	function ( $class ) {
		$prefix   = __NAMESPACE__; // project-specific namespace prefix
		$base_dir = __DIR__ . '/includes'; // base directory for the namespace prefix

		$len = strlen( $prefix );
		if ( strncmp( $prefix, $class, $len ) !== 0 ) { // does the class use the namespace prefix?
			return; // no, move to the next registered autoloader
		}

		$relative_class_name = substr( $class, $len );

		// replace the namespace prefix with the base directory, replace namespace
		// separators with directory separators in the relative class name, append
		// with .php
		$file = $base_dir . str_replace( '\\', '/', $relative_class_name ) . '.php';

		if ( file_exists( $file ) ) {
			require $file;
		}
	}
);

require_once __DIR__ . '/vendor/autoload.php';

spl_autoload_register(function ( $class ) {
	$prefix   = 'WhatsappScoped\\YayCommerce\\AdminShell\\';
	$base_dir = __DIR__ . '/vendor-prefixed/src/';
	$len      = strlen( $prefix );
	if ( strncmp( $prefix, $class, $len ) !== 0 ) {
		return;
	}
	$file = $base_dir . str_replace( '\\', '/', substr( $class, $len ) ) . '.php';
	if ( file_exists( $file ) ) {
		require $file;
	}
});

require_once __DIR__ . '/WhatsappPluginAdapter.php';

add_action( 'plugins_loaded', function() {
	( new \WhatsappPluginAdapter() )->init();
}, 5 );

if ( ! function_exists( 'NTA_WhatsApp\\init' ) ) {
	function init() {
		Plugin::getInstance();
		PostType::getInstance();
		I18n::loadPluginTextdomain();
		Shortcode::getInstance();
		Popup::getInstance();
		Settings::getInstance();
		Upgrade::getInstance();
		Support\WPML::getInstance();
		Support\Woocommerce::getInstance();
		Support\Dokan\Dokan::getInstance();
		if ( function_exists( 'register_block_type' ) ) {
			require_once __DIR__ . '/blocks/src/init.php';
		}
	}
}

add_action( 'plugins_loaded', 'NTA_WhatsApp\\init' );

register_activation_hook( __FILE__, array( 'NTA_WhatsApp\\Plugin', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'NTA_WhatsApp\\Plugin', 'deactivate' ) );
