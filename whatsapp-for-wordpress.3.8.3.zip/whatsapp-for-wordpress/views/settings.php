<?php
if ( isset( $_GET['tab'] ) ) {
	$active_tab = sanitize_text_field( $_GET['tab'] );
} else {
	$active_tab = 'tab_one';
}
?>
<div class="wrap">
	<h1><?php echo esc_html__( 'Settings', 'ninjateam-whatsapp' ); ?></h1>

	<?php settings_errors(); ?>

	<?php if ( function_exists( 'njt_ads_toggle_consumer_is_enabled' ) ) : ?>
	<div class="notice notice-info" style="padding: 12px 16px;">
		<div id="njt-ads-toggle-whatsapp-wp"></div>
	</div>
	<script>
	jQuery(function ($) {
		if (typeof njtAdsToggleRender === 'function') {
			njtAdsToggleRender('#njt-ads-toggle-whatsapp-wp', {
				consumerSlug: 'whatsapp-wp',
				title: '<?php echo esc_js( __( 'Show ads', 'ninjateam-whatsapp' ) ); ?>',
				description: '<?php echo esc_js( __( 'Show partner recommendations (FileBird, etc.) in your admin area.', 'ninjateam-whatsapp' ) ); ?>',
				checked: <?php echo njt_ads_toggle_consumer_is_enabled( 'whatsapp-wp' ) ? 'true' : 'false'; ?>
			});
		}
	});
	</script>
	<?php endif; ?>

	<div id="njt-tabs">
		<ul class="nav-tab-wrapper nta-tab-wrapper">
			<li><a href="#tabs-1" class="nav-tab nta-selected-tab" data-action="njt_wa_save_woocommerce_setting"><?php echo esc_html__( 'WooCommerce Button', 'ninjateam-whatsapp' ); ?></a></li>
			<li><a href="#tabs-2" class="nav-tab" data-action="njt_wa_save_analytics_setting"><?php echo esc_html__( 'Analytics', 'ninjateam-whatsapp' ); ?></a></li>
			<li><a href="#tabs-3" class="nav-tab" data-action="njt_wa_save_url_setting"><?php echo esc_html__( 'WhatsApp URL', 'ninjateam-whatsapp' ); ?></a></li>
			<li><a href="#tabs-4" class="nav-tab" data-action="njt_wa_save_accounts_setting"><?php echo esc_html__( 'Accounts', 'ninjateam-whatsapp' ); ?></a></li>
			<li><a href="#tabs-5" class="nav-tab" data-action="njt_wa_save_user_role_setting"><?php echo esc_html__( 'User Role', 'ninjateam-whatsapp' ); ?></a></li>
		</ul>
		<div class="nta-tabs-content">
			<form method="post" action="options.php">
				<div id="form-selected-account" autocomplete="off">
					<div id="tabs-1">
						<?php do_settings_sections( 'settings-whatsapp-1' ); ?>
					</div>
					<div id="tabs-2" style="display: none;">
						<?php do_settings_sections( 'settings-whatsapp-2' ); ?>
					</div>
					<div id="tabs-3" style="display: none;">
						<?php do_settings_sections( 'settings-whatsapp-3' ); ?>
					</div>
					<div id="tabs-4" style="display: none;">
						<?php do_settings_sections( 'settings-whatsapp-4' ); ?>
					</div>
					<div id="tabs-5" style="display: none;">
						<?php do_settings_sections( 'settings-whatsapp-5' ); ?>
					</div>
				</div>
			</form>
		</div>
	</div>
</div>
