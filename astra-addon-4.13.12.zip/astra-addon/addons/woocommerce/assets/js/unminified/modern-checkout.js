function slideInAndOutContent(trigger, triggerContent) {
    const collapseToggle  = document.querySelector( trigger );
    const orderReviewText = document.querySelector( '.ast-order-review-toggle-text' );
    let releaseTimer;

    if( collapseToggle ) {

        collapseToggle.addEventListener( 'click', function( e ) {
            const collapseContentWrapper = document.querySelector( triggerContent );
            const collapseContent = collapseContentWrapper.querySelector('*');

            if( collapseContentWrapper ) {

                if( ! e.currentTarget.classList.contains( 'active' ) ) {
                    if( collapseContent ) {
                        e.currentTarget.classList.add( 'active' );
                        collapseContentWrapper.style.display = 'block';
                        collapseContentWrapper.style.maxHeight = `${collapseContentWrapper.scrollHeight}px`;

                        // Keep the pixel height only for the open animation, so content added later is not clipped.
                        const releaseHeight = () => {
                            if( collapseToggle.classList.contains( 'active' ) ) {
                                collapseContentWrapper.style.maxHeight = 'none';
                            }
                        };
                        collapseContentWrapper.addEventListener( 'transitionend', function onOpenEnd( ev ) {
                            if( ev.propertyName !== 'max-height' ) {
                                return;
                            }
                            collapseContentWrapper.removeEventListener( 'transitionend', onOpenEnd );
                            releaseHeight();
                        } );
                        // Fallback for when transitionend does not fire, e.g. no transition or reduced motion.
                        clearTimeout( releaseTimer );
                        releaseTimer = setTimeout( releaseHeight, 350 );

                        if( orderReviewText && '#ast-order-review-toggle' === trigger ) {
                            orderReviewText.textContent = astraAddon.order_review_toggle_texts.toggle_hide_text;
                        }
                    }
                } else {
                    e.currentTarget.classList.remove( 'active' );
                    clearTimeout( releaseTimer );
                    // Restore a pixel height first so the collapse still animates.
                    collapseContentWrapper.style.maxHeight = `${collapseContentWrapper.scrollHeight}px`;
                    void collapseContentWrapper.offsetHeight;
                    collapseContentWrapper.style.maxHeight = 0;
                    setTimeout(() => {
                        collapseContentWrapper.style.display = 'none';
                    }, 300);
                    if( orderReviewText && '#ast-order-review-toggle' === trigger ) {
                        orderReviewText.textContent = astraAddon.order_review_toggle_texts.toggle_show_text;
                    }
                }
            }
        } )
    }
}

// Update checkout when something is changed in the mobile order review, e.g. the shipping method.
function mobileShippingMethodChange() {
    const mobileOrderReviewWrap = document.querySelector( '#ast-order-review-content' );

    if( ! mobileOrderReviewWrap ) {
        return;
    }

    mobileOrderReviewWrap.addEventListener( 'change', function ( e ) {
        if( e.target.matches( 'select.shipping_method, input[name^="shipping_method"]' ) ) {
            /**
             * Uncheck the desktop radio buttons of the same shipping package. Those will be auto updated by update_checkout action.
             * While performing the update checkout, it searches for the selected shipping method in whole page.
             */
            const changedName = e.target.name;
            document.querySelectorAll( '#order_review input[name^="shipping_method"][type="radio"]:checked' ).forEach( checkedInput => {
                if( checkedInput.name === changedName ) {
                    checkedInput.removeAttribute( 'checked' );
                }
            } );
        }

        document.querySelector( 'body' ).dispatchEvent( new CustomEvent( "update_checkout", { "detail": { update_shipping_method: true } } ) );
    } );
}

/**
 * The order review is printed twice, in the mobile summary and in #order_review, and CSS shows one of them.
 * Keep the ids and label targets only on the visible copy, so labels bind to the radio buttons next to them.
 */
function dedupeOrderReviewIds() {
    const mobileSummary = document.querySelector( '.ast-mobile-order-review-wrap' );
    const mobileWrap    = document.querySelector( '#ast-order-review-content' );
    const desktopWrap   = document.querySelector( '#order_review' );

    if( ! mobileSummary || ! mobileWrap || ! desktopWrap ) {
        return;
    }

    const isMobileVisible = window.getComputedStyle( mobileSummary ).display !== 'none';
    const visibleWrap     = isMobileVisible ? mobileWrap : desktopWrap;
    const hiddenWrap      = isMobileVisible ? desktopWrap : mobileWrap;

    visibleWrap.querySelectorAll( '[data-ast-id]' ).forEach( element => {
        element.id = element.getAttribute( 'data-ast-id' );
        element.removeAttribute( 'data-ast-id' );
    } );
    visibleWrap.querySelectorAll( '[data-ast-for]' ).forEach( element => {
        element.htmlFor = element.getAttribute( 'data-ast-for' );
        element.removeAttribute( 'data-ast-for' );
    } );

    const removedIds = new Set();
    hiddenWrap.querySelectorAll( '[id]' ).forEach( element => {
        if( visibleWrap.querySelector( `#${ CSS.escape( element.id ) }` ) ) {
            removedIds.add( element.id );
            element.setAttribute( 'data-ast-id', element.id );
            element.removeAttribute( 'id' );
        }
    } );
    hiddenWrap.querySelectorAll( 'label[for]' ).forEach( label => {
        if( removedIds.has( label.htmlFor ) ) {
            label.setAttribute( 'data-ast-for', label.htmlFor );
            label.removeAttribute( 'for' );
        }
    } );
}

function initOrderReviewIds() {
    if( ! document.querySelector( '#ast-order-review-content' ) ) {
        return;
    }

    let frame;
    dedupeOrderReviewIds();

    // WooCommerce replaces the order review fragments with ids on both copies after every refresh.
    if( window.jQuery ) {
        window.jQuery( document.body ).on( 'updated_checkout', dedupeOrderReviewIds );
    }

    // The visible copy changes when the screen crosses the breakpoint.
    window.addEventListener( 'resize', function () {
        cancelAnimationFrame( frame );
        frame = requestAnimationFrame( dedupeOrderReviewIds );
    } );
}

let xhrCountEmail = 0;
let delayTimerEmail;

/**
 * Parse an admin-ajax reply, returning null unless it is a wp_send_json_success() payload
 * (a failed nonce check answers "-1" or "0").
 *
 * @param {XMLHttpRequest} xhrRequest Completed request.
 * @return {Object|null} Parsed payload with a `data` object, or null.
 */
function parseAjaxResponse( xhrRequest ) {
    if ( 200 !== xhrRequest.status ) {
        return null;
    }

    try {
        const jsonResponse = JSON.parse( xhrRequest.responseText );
        return jsonResponse?.data ? jsonResponse : null;
    } catch ( error ) {
        return null;
    }
}

function validateInlineEmail() {

    const emailInput = document.querySelector( '#billing_email' );

    if( emailInput ) {
        // Email or username value.
        const emailText = emailInput.value;

        if ( 'undefined' === typeof emailText || astraAddon.is_logged_in ) {
			return;
		}

        const createAccountSection  = document.querySelector( '.ast-create-account-section' );
        const loginLabel            = document.querySelector( '.woocommerce-billing-fields__customer-login-label' );
        const validationMsgWrap     = document.querySelector( '.ast-email-validation-block' );
        const isLoginActive         = document.querySelector( '#ast-customer-login-url' );

        if ( '' !== emailText ) {

            if( validationMsgWrap ) {
                validationMsgWrap.remove();
            }

            clearTimeout( delayTimerEmail );

			const seqNumber = ++xhrCountEmail;

			delayTimerEmail = setTimeout( async function () {

                let xhrRequest = new XMLHttpRequest();
                xhrRequest.open( 'POST', astra.ajax_url, true );

                // Send the proper header information along with the request
                xhrRequest.setRequestHeader( "Content-Type", "application/x-www-form-urlencoded" );

                xhrRequest.send( 'action=astra_woo_check_user_exist&user_name_email=' + encodeURIComponent( emailText ) + '&security=' + encodeURIComponent( astraAddon.check_user_exist_nonce ) );
                
                xhrRequest.onload = function () {
                    if ( xhrRequest.readyState == XMLHttpRequest.DONE ) {   // XMLHttpRequest.DONE == 4
                        if ( 200 <= xhrRequest.status || 400 <= xhrRequest.status ) {

							document.cookie = "ast_modern_checkout_useremail=" + emailText;

                            // A failed call (expired nonce, vetoed lookup) is treated as "no account" so the shopper can still register.
                            const jsonResponse = parseAjaxResponse( xhrRequest ) || { data: { success: false } };

                            if ( seqNumber !== xhrCountEmail ) {
                                return;
                            }

                            if( validationMsgWrap ) {
                                validationMsgWrap.remove();
                            }

                            if (
                                jsonResponse.data.success &&
                                isLoginActive &&
                                isLoginActive.classList.contains( 'active' )
                            ) {
                                emailInput.insertAdjacentHTML(
                                    'afterend',
                                    '<span class="ast-email-validation-block success">' +
                                        astraAddon.user_validation_msgs
                                            .success_msg +
                                        '</span>'
                                );
                                return;
                            }

                            if ( jsonResponse.data.success ) {
                                if ( jsonResponse.data.is_login_allowed ) {

                                    emailInput.insertAdjacentHTML(
                                        'afterend',
                                        '<span class="ast-email-validation-block success">' +
                                            astraAddon.user_validation_msgs
                                                .success_msg +
                                            '</span>'
                                    );

                                    if( isLoginActive && ! isLoginActive.classList.contains( 'active' ) ) {
                                        isLoginActive.click();
                                    }
                                }

                                if( createAccountSection ) {
                                    createAccountSection.style.display = 'none';
                                }

                                if( loginLabel ) {
                                    loginLabel.style.display = 'block';
                                }

                            } else {
                                if( isLoginActive && isLoginActive.classList.contains( 'active' ) ) {
                                    isLoginActive.click();
                                }

                                if( createAccountSection ) {

                                    const createAccountCheckbox = createAccountSection.querySelector( '.create-account label.checkbox' );

                                    // LearnDash fix.
                                    if( createAccountCheckbox ) {
                                        createAccountCheckbox.style.display = 'block';
                                    }

                                    createAccountSection.style.display = 'block';
                                }

                                // if( loginLabel && '' == emailText ){
                                //     loginLabel.style.display = 'none';
                                // }

                            }
                        }
                    }
                }

            }, 300 );


        } else {

            if( isLoginActive && isLoginActive.classList.contains( 'active' ) ) {
                isLoginActive.click();
            }

            if( validationMsgWrap ) {
                validationMsgWrap.style.display = 'none';
            }

            if( loginLabel ) {
                loginLabel.style.display = 'block';
            }

            if( createAccountSection ) {
                createAccountSection.style.display = 'none';
            }
        }
    }

    return false;
}

function supportNativeEmailFunctionality() {

	const emailInput = document.querySelector( '#billing_email' );

	if( emailInput ) {
		// Email or username value.
		const emailText = emailInput.value;

		if ( 'undefined' === typeof emailText || astraAddon.is_logged_in ) {
			return;
		}

		const createAccountSection  = document.querySelector( '.ast-create-account-section' );

		if ( createAccountSection ) {
			if ( '' !== emailText ) {
				createAccountSection.style.display = 'block';
			} else {
				createAccountSection.style.display = 'none';
			}
		}
	}

	return false;
}

function woocommerceUserLogin() {
    const loginButton = document.querySelector( '.ast-customer-login-section__login-button' );

    if( ! loginButton ) {
        return;
    }

    loginButton.addEventListener( 'click' , function() {
        const emailAddress = document.querySelector( '#billing_email' );
        const password     = document.querySelector( '#billing_password' );

        if( ! emailAddress && password ) {
            return;
        }

        let xhrRequest = new XMLHttpRequest();

        xhrRequest.open( 'POST', astra.ajax_url, true );

        // Send the proper header information along with the request
        xhrRequest.setRequestHeader( "Content-Type", "application/x-www-form-urlencoded" );

        // Fix: AST-3495 - Added "encodeURIComponent" so that can we encode the special symbols in payload.
        xhrRequest.send( 'action=astra_woocommerce_login_user&user_name_email=' + encodeURIComponent( emailAddress.value ) + '&password=' + encodeURIComponent( password.value ) + '&security=' + encodeURIComponent( astraAddon.woocommerce_login_nonce ) );

        xhrRequest.onload = () => {
            const responseData = parseAjaxResponse( xhrRequest )?.data;

            if ( responseData?.success ) {
                location.reload();
                return;
            }

            const customerInfoNotice = document.querySelector( '.ast-customer-info__notice' );

            if ( customerInfoNotice ) {
                customerInfoNotice.classList.add( 'active' );
                customerInfoNotice.innerHTML = DOMPurify.sanitize( responseData?.error || astraAddon.user_validation_msgs.login_failed_msg );
            }
        };
    } );
}

document.addEventListener("DOMContentLoaded", function (event) {
    const body = document.querySelector('body');
    if (!astraAddon.cartflows_version && body && body.classList.contains('woocommerce-checkout')) {
        const isNotWPComPackage = astraAddon.is_complete_package;
        const emailInput = document.querySelector('#billing_email');

        if (emailInput) {
            if (isNotWPComPackage) {
                emailInput.addEventListener('input', validateInlineEmail);
                validateInlineEmail();
            } else {
                emailInput.addEventListener('input', supportNativeEmailFunctionality);
                supportNativeEmailFunctionality();
            }
        }

        if (body && !body.classList.contains('ast-woo-two-step-modern-checkout')) {
            slideInAndOutContent('#ast-order-review-toggle', '#ast-order-review-content');
            mobileShippingMethodChange();
            initOrderReviewIds();
        }

        if (isNotWPComPackage) {
            slideInAndOutContent('#ast-customer-login-url', '#ast-customer-login-section');
            woocommerceUserLogin();
        }
    }
});

// Stripe Express Checkout Element Positioning in Modern Checkout Layout compatibility.
document.addEventListener( 'DOMContentLoaded', function () {
    if ( document.body.classList.contains( 'ast-modern-checkout' ) ) {
        const stripeElement = document.getElementById( 'wc-stripe-express-checkout-element' );
        const orderAttribution = document.querySelector( '.wc-order-attribution-inputs' );
        const buttonSeparator = document.getElementById( 'wc-stripe-express-checkout-button-separator' );
        const checkoutForm = document.querySelector( 'form.checkout' );

        if ( checkoutForm ) {
            if ( stripeElement ) {
                checkoutForm.parentNode.insertBefore( stripeElement, checkoutForm );
            }
            if ( orderAttribution ) {
                checkoutForm.parentNode.insertBefore( orderAttribution, checkoutForm );
            }
            if ( buttonSeparator ) {
                checkoutForm.parentNode.insertBefore( buttonSeparator, checkoutForm );
            }
        }
    }
} );

