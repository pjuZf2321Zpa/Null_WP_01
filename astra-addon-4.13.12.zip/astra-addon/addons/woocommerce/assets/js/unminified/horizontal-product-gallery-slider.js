// Horizontal gallery slider.
const horizontalGallerySliderOptions = {
    animation: "slide",
    controlNav: false,
    animationLoop: false,
    slideshow: false,
    itemWidth: 80,
    itemMargin: 15,
    maxItems: 4,
    asNavFor: '.woocommerce-product-gallery',
    selector: '.woocommerce-product-gallery-thumbnails__wrapper > div',
};

const horizontalProductGallerySlider = jQuery('.ast-single-product-thumbnails').flexslider(horizontalGallerySliderOptions);

window.addEventListener("resize", function() {
    horizontalProductGallerySlider.resize();
});

// Select the thumbnail that matches the variation image the main gallery switched to.
let variationThumbObserver = null;

function observeVariationThumbnail() {
    // Drop the observer bound to a gallery that has been replaced.
    if (variationThumbObserver) {
        variationThumbObserver.disconnect();
    }

    const articleSingle = document.querySelector('.ast-article-single');

    if (articleSingle && articleSingle.classList.contains('ast-product-single-variable')) {
        const img = document.querySelector(".woocommerce-product-gallery .woocommerce-product-gallery__image");
        const thumbnail_images = document.querySelectorAll('.woocommerce-product-gallery .ast-woocommerce-product-gallery__image img');

        if (img && thumbnail_images) {
            variationThumbObserver = new MutationObserver((changes) => {
                changes.forEach(change => {
                    if (change.attributeName.includes('data-thumb')) {
                        if (thumbnail_images !== null) {
                            thumbnail_images.forEach(element => {
                                if (element.getAttribute('srcset') !== null && element.getAttribute('srcset').includes(img.getAttribute('data-thumb'))) {
                                    element.click();
                                }
                            });
                        }
                    }
                });
            });
            variationThumbObserver.observe(img, { attributes: true });
        }
    }
}

observeVariationThumbnail();

// WooCommerce replaces the whole gallery when a variation has its own images, so set the new one up again.
jQuery(document).on('wc-product-gallery-after-init', '.woocommerce-product-gallery', function (event, gallery) {
    const rail = jQuery(gallery).find('.ast-single-product-thumbnails');

    if (rail.length && !rail.data('flexslider')) {
        rail.flexslider(horizontalGallerySliderOptions);
        observeVariationThumbnail();
    }
});
