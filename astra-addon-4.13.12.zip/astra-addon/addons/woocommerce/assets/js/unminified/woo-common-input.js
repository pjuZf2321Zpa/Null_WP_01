/**
 * Initialize WooCommerce form inputs.
 */
const modernLayoutInputs = () => {
	document
		.querySelectorAll('.woocommerce input, .woocommerce select, .woocommerce textarea')
		.forEach((element) => {
			element.addEventListener('input', ({ currentTarget }) => {
				addAnimateClass(currentTarget);
			});

			setupPlaceholder(element);
			addAnimateClass(element);
		});
};


/**
 * Add/remove the animation class based on the field value.
 */
const addAnimateClass = (element) => {
	const fieldRow = element.closest('.form-row');

	if (!fieldRow) {
		return;
	}

	fieldRow.classList.toggle('ast-animate-input', element.value !== '');
};


/**
 * Set the placeholder based on the field label and required state.
 */
const setupPlaceholder = (element) => {
	const fieldRow = element.closest('.form-row');

	if (!fieldRow) {
		return;
	}

	let placeholder = element.getAttribute('placeholder');

	if (!placeholder) {
		const label = fieldRow.querySelector('label');

		if (label) {
			placeholder = label.textContent.trim();
			element.setAttribute('placeholder', placeholder);
		}
	}

	if (
		fieldRow.classList.contains('validate-required') &&
		placeholder &&
		!placeholder.includes('*')
	) {
		placeholder += ' *';
		element.setAttribute('placeholder', placeholder);
	}
};


/**
 * Sync the state field placeholder with its label after a country change.
 *
 * WooCommerce updates the label text and required/optional state when the
 * country changes, but the existing placeholder may retain the previous
 * locale's text.
 *
 * @since x.x.x
 */
const syncStateField = (wrapper) => {
	jQuery(wrapper)
		.find('#billing_state_field, #shipping_state_field')
		.each(function () {
			const fieldRow = jQuery(this);
			const label = fieldRow.find('label').first().clone();

			label.children('.required, .optional').remove();

			let placeholder = label.text().trim();

			if (!placeholder) {
				return;
			}

			if (fieldRow.hasClass('validate-required')) {
				placeholder += ' *';
			}

			const fields = fieldRow.find(
				'select, input:not([type="hidden"])'
			);

			fields.attr({
				placeholder,
				'data-placeholder': placeholder,
			});

			fieldRow
				.find('.select2-selection__placeholder')
				.text(placeholder);

			fields.each(function () {
				addAnimateClass(this);
			});
		});
};


/**
 * WooCommerce/Select2 events.
 *
 * Select2 triggers jQuery events, so native event listeners aren't enough.
 */
if (typeof jQuery !== 'undefined') {
	jQuery(document.body).on(
		'change',
		'.woocommerce select, .woocommerce input, .woocommerce textarea',
		function () {
			addAnimateClass(this);
		}
	);

	jQuery(document.body).on(
		'country_to_state_changed',
		function (event, country, wrapper) {
			// Run after WooCommerce address-i18n.js updates the label.
			setTimeout(() => {
				syncStateField(wrapper);
			}, 0);
		}
	);
}


/**
 * Initialize on DOM ready.
 */
document.addEventListener('DOMContentLoaded', () => {
	const body = document.body;

	if (body && !body.classList.contains('cartflows_step-template')) {
		modernLayoutInputs();
	}
});