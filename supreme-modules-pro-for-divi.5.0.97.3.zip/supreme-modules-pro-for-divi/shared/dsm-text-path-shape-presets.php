<?php
/**
 * Extra Supreme Text Path presets (path `d` + viewBox).
 *
 * Legacy shapes (wave, arc, circle, line, oval, spiral) stay defined in module renderers.
 *
 * @package dsm-supreme-modules-pro-for-divi
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Additional path types: view_box and SVG path `d` attribute.
 *
 * @return array<string, array{view_box: string, path_d: string}>
 */
function dsm_get_text_path_extra_shape_presets(): array {
	return array(
		'heart'         => array(
			'view_box' => '0 0 500 450',
			'path_d'   => 'M 250 400 C 250 400, 50 280, 50 180 C 50 80, 150 50, 250 150 C 350 50, 450 80, 450 180 C 450 280, 250 400, 250 400',
		),
		'triangle'      => array(
			'view_box' => '0 0 500 450',
			'path_d'   => 'M 250 0 L 500 433 L 0 433 Z',
		),
		'zigzag'        => array(
			'view_box' => '0 0 500 50',
			'path_d'   => 'M 0 50 L 62.5 0 L 125 50 L 187.5 0 L 250 50 L 312.5 0 L 375 50 L 437.5 0 L 500 50',
		),
		'figure-eight'  => array(
			'view_box' => '0 0 500 500',
			'path_d'   => 'M 250 250 C 250 150, 450 150, 450 250 C 450 350, 250 350, 250 250 C 250 150, 50 150, 50 250 C 50 350, 250 350, 250 250',
		),
		'parabola'      => array(
			'view_box' => '0 0 500 450',
			'path_d'   => 'M 0 400 Q 250 0, 500 400',
		),
		'diamond'       => array(
			'view_box' => '0 0 500 500',
			'path_d'   => 'M 250 0 L 500 250 L 250 500 L 0 250 Z',
		),
		'star'          => array(
			'view_box' => '0 0 500 450',
			'path_d'   => 'M 250 0 L 298 154 L 460 154 L 330 248 L 378 402 L 250 308 L 122 402 L 170 248 L 40 154 L 202 154 Z',
		),
		'cross'         => array(
			'view_box' => '0 0 500 500',
			'path_d'   => 'M 167 0 L 333 0 L 333 167 L 500 167 L 500 333 L 333 333 L 333 500 L 167 500 L 167 333 L 0 333 L 0 167 L 167 167 Z',
		),
		'staircase'     => array(
			'view_box' => '0 -100 500 600',
			'path_d'   => 'M 0 400 L 0 300 L 100 300 L 100 200 L 200 200 L 200 100 L 300 100 L 300 0 L 400 0 L 400 -100 L 500 -100',
		),
		'semicircle'    => array(
			'view_box' => '0 0 500 250',
			'path_d'   => 'M 0 250 A 250 250 0 0 1 500 250',
		),
		'double-arch'   => array(
			'view_box' => '0 0 500 350',
			'path_d'   => 'M 0 300 C 0 100, 125 0, 125 150 C 125 0, 250 100, 250 300 C 250 100, 375 0, 375 150 C 375 0, 500 100, 500 300',
		),
		'crown'         => array(
			'view_box' => '0 0 500 450',
			'path_d'   => 'M 0 400 L 0 150 L 125 300 L 250 50 L 375 300 L 500 150 L 500 400 Z',
		),
		'lightning'     => array(
			'view_box' => '0 0 500 500',
			'path_d'   => 'M 300 0 L 150 250 L 280 250 L 200 500 L 350 200 L 220 200 Z',
		),
		'arrow'         => array(
			'view_box' => '0 0 500 500',
			'path_d'   => 'M 0 200 L 350 200 L 350 100 L 500 250 L 350 400 L 350 300 L 0 300 Z',
		),
		'speech-bubble' => array(
			'view_box' => '0 0 500 500',
			'path_d'   => 'M 50 0 Q 0 0, 0 50 L 0 300 Q 0 350, 50 350 L 150 350 L 200 450 L 250 350 L 450 350 Q 500 350, 500 300 L 500 50 Q 500 0, 450 0 Z',
		),
		'cloud'         => array(
			'view_box' => '0 0 560 400',
			'path_d'   => 'M 100 350 Q 20 350, 20 270 Q 20 210, 80 200 Q 60 120, 140 100 Q 180 40, 260 60 Q 300 20, 360 40 Q 430 20, 460 80 Q 520 90, 510 160 Q 560 180, 540 250 Q 530 330, 440 340 Z',
		),
		'smile'         => array(
			'view_box' => '0 0 500 450',
			'path_d'   => 'M 50 150 Q 250 400, 450 150',
		),
	);
}

/**
 * Ordered allowlist for `dsm_path_type` (D4, D5, migrator).
 *
 * @return list<string>
 */
function dsm_get_text_path_allowed_types(): array {
	return array_merge(
		array( 'wave', 'arc', 'circle', 'line', 'oval', 'spiral' ),
		array_keys( dsm_get_text_path_extra_shape_presets() ),
		array( 'custom' ),
	);
}
