<?php
/**
 * Divi Supreme Pro plugin updater: post-upgrade cache busting and version helpers.
 *
 * @package dsm-supreme-modules-pro-for-divi
 */

declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( function_exists( 'dsm_is_marketplace_build' ) && dsm_is_marketplace_build() ) {
	return;
}

/**
 * Site transient prefix used by {@see Woo_DS_PluginUpdate::get_remote_api_response()}.
 */
const DSM_PLUGIN_UPDATER_HTTP_CACHE_PREFIX = 'divisupremepro-check_for_plugin_update_';

/**
 * Register hooks that clear stale update state after this plugin is upgraded.
 *
 * @return void
 */
function dsm_plugin_updater_register_post_upgrade_hooks(): void {
	add_action( 'upgrader_process_complete', 'dsm_plugin_updater_on_upgrader_process_complete', 5, 2 );
}

add_action( 'plugins_loaded', 'dsm_plugin_updater_register_post_upgrade_hooks', 15 );

/**
 * Clear cached update-check data after a successful upgrade of this plugin.
 *
 * @param \WP_Upgrader|\Plugin_Upgrader $upgrader   Upgrader instance.
 * @param array<string, mixed>          $hook_extra Hook extra arguments.
 * @return void
 */
function dsm_plugin_updater_on_upgrader_process_complete( $upgrader, array $hook_extra ): void {
	unset( $upgrader );

	if (
		! isset( $hook_extra['action'], $hook_extra['type'] )
		|| 'update' !== $hook_extra['action']
		|| 'plugin' !== $hook_extra['type']
	) {
		return;
	}

	if ( ! dsm_plugin_updater_hook_extra_includes_this_plugin( $hook_extra ) ) {
		return;
	}

	dsm_plugin_updater_clear_all_update_caches();
}

/**
 * Whether the upgrader hook extra targets this plugin.
 *
 * @param array<string, mixed> $hook_extra Hook extra arguments.
 * @return bool
 */
function dsm_plugin_updater_hook_extra_includes_this_plugin( array $hook_extra ): bool {
	$basename = dsm_plugin_updater_plugin_basename();

	if ( '' === $basename ) {
		return false;
	}

	if ( isset( $hook_extra['plugin'] ) && is_string( $hook_extra['plugin'] ) && $hook_extra['plugin'] === $basename ) {
		return true;
	}

	if ( ! isset( $hook_extra['plugins'] ) || ! is_array( $hook_extra['plugins'] ) ) {
		return false;
	}

	foreach ( $hook_extra['plugins'] as $plugin ) {
		if ( is_string( $plugin ) && $plugin === $basename ) {
			return true;
		}
	}

	return false;
}

/**
 * Plugin basename for this package (cached).
 *
 * @return string Relative plugin file, e.g. `supreme-modules-pro-for-divi/supreme-modules-pro-for-divi.php`.
 */
function dsm_plugin_updater_plugin_basename(): string {
	static $cache = null;

	if ( null !== $cache ) {
		return $cache;
	}

	if ( ! defined( 'DSM_DIR_PATH' ) ) {
		return '';
	}

	$cache = plugin_basename( DSM_DIR_PATH . 'supreme-modules-pro-for-divi.php' );

	return $cache;
}

/**
 * Remove leading `V` / `v` and surrounding whitespace for version_compare().
 *
 * @param string $version Raw version string.
 * @return string Normalized version.
 */
function dsm_plugin_updater_normalize_version_string( string $version ): string {
	$trimmed = trim( $version );

	return ltrim( $trimmed, "vV \t\n\r\0\x0B" );
}

/**
 * Installed plugin version read from the main plugin file header (not the boot-time constant).
 *
 * Ensures comparisons stay accurate in the same request as an upgrade completes.
 *
 * @return string Normalized semver-ish string.
 */
function dsm_plugin_updater_get_installed_version_normalized(): string {
	if ( ! defined( 'DSM_DIR_PATH' ) ) {
		return '0';
	}

	$main_file = DSM_DIR_PATH . 'supreme-modules-pro-for-divi.php';

	if ( ! is_readable( $main_file ) ) {
		return dsm_plugin_updater_normalize_version_string(
			defined( 'DSM_PRO_VERSION' ) ? (string) DSM_PRO_VERSION : '0'
		);
	}

	if ( ! function_exists( 'get_file_data' ) ) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
	}

	$header = get_file_data(
		$main_file,
		array(
			'Version' => 'Version',
		),
		'plugin'
	);

	$from_header = isset( $header['Version'] ) ? trim( (string) $header['Version'] ) : '';

	if ( '' !== $from_header ) {
		return dsm_plugin_updater_normalize_version_string( $from_header );
	}

	return dsm_plugin_updater_normalize_version_string(
		defined( 'DSM_PRO_VERSION' ) ? (string) DSM_PRO_VERSION : '0'
	);
}

/**
 * Whether the remote version should be offered as an update over the installed copy.
 *
 * @param string $remote_version   Latest version from API / manifest / Update URI.
 * @param string $installed_version Installed version (defaults to live header read).
 * @return bool True when remote is strictly newer.
 */
function dsm_plugin_updater_remote_is_newer_than_installed( string $remote_version, string $installed_version = '' ): bool {
	$remote = dsm_plugin_updater_normalize_version_string( $remote_version );
	$local  = '' !== $installed_version
		? dsm_plugin_updater_normalize_version_string( $installed_version )
		: dsm_plugin_updater_get_installed_version_normalized();

	if ( '' === $remote || '' === $local || '0' === $local ) {
		return false;
	}

	return version_compare( $remote, $local, '>' );
}

/**
 * Drop this plugin from `response` on the update_plugins transient object.
 *
 * @param object $transient Update plugins transient.
 * @param string $basename  Plugin basename key.
 * @return void
 */
function dsm_plugin_updater_strip_response_entry( object $transient, string $basename ): void {
	if ( isset( $transient->response[ $basename ] ) ) {
		unset( $transient->response[ $basename ] );
	}
}

/**
 * Delete all DSM updater caches so the next check refetches remote data.
 *
 * @return void
 */
function dsm_plugin_updater_clear_all_update_caches(): void {
	delete_site_transient( 'update_plugins' );

	if ( defined( 'DSM_BETA_MANIFEST_TRANSIENT' ) ) {
		delete_site_transient( DSM_BETA_MANIFEST_TRANSIENT );
	} else {
		delete_site_transient( 'dsm_beta_update_manifest' );
	}

	dsm_plugin_updater_delete_http_response_transients();

	if ( class_exists( 'Woo_DS_PluginUpdate', false ) ) {
		Woo_DS_PluginUpdate::clear_request_cache();
	}
}

/**
 * Remove cached stable-channel HTTP responses (`divisupremepro-check_for_plugin_update_*`).
 *
 * @return void
 */
function dsm_plugin_updater_delete_http_response_transients(): void {
	global $wpdb;

	if ( ! isset( $wpdb ) || ! is_object( $wpdb ) ) {
		return;
	}

	$like = $wpdb->esc_like( '_site_transient_' . DSM_PLUGIN_UPDATER_HTTP_CACHE_PREFIX ) . '%';
	$like_timeout = $wpdb->esc_like( '_site_transient_timeout_' . DSM_PLUGIN_UPDATER_HTTP_CACHE_PREFIX ) . '%';

	if ( is_multisite() ) {
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Targeted transient purge.
		$wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$wpdb->sitemeta} WHERE meta_key LIKE %s",
				$like
			)
		);

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Targeted transient purge.
		$wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$wpdb->sitemeta} WHERE meta_key LIKE %s",
				$like_timeout
			)
		);

		return;
	}

	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Targeted transient purge.
	$wpdb->query(
		$wpdb->prepare(
			"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s",
			$like
		)
	);

	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Targeted transient purge.
	$wpdb->query(
		$wpdb->prepare(
			"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s",
			$like_timeout
		)
	);
}
