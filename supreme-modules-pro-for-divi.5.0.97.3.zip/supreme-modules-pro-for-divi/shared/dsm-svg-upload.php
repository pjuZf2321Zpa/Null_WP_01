<?php
/**
 * Shared SVG and SVGZ upload sanitizer for Divi 4 and Divi 5.
 *
 * Bundles enshrined/svg-sanitize 1.1.1 (commit 1976ff93) under shared/vendor.
 * The allowlist reads the whole document. A prefix regex is not used.
 *
 * @package dsm-supreme-modules-pro-for-divi
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Register the bundled sanitizer autoloader once.
 *
 * @return void
 */
function dsm_svg_upload_register_sanitizer_autoload() {
	static $registered = false;

	if ( $registered ) {
		return;
	}

	$registered = true;

	spl_autoload_register(
		static function ( $class ) {
			$prefix = 'enshrined\\svgSanitize\\';
			if ( 0 !== strpos( (string) $class, $prefix ) ) {
				return;
			}

			$relative = substr( (string) $class, strlen( $prefix ) );
			$relative = str_replace( '\\', '/', $relative );
			$path     = __DIR__ . '/vendor/enshrined/svg-sanitize/src/' . $relative . '.php';

			if ( is_readable( $path ) ) {
				require_once $path;
			}
		}
	);
}

/**
 * One megabyte, using the WordPress constant when it exists.
 *
 * @return int
 */
function dsm_svg_upload_megabyte() {
	if ( defined( 'MB_IN_BYTES' ) ) {
		return (int) MB_IN_BYTES;
	}

	return 1048576;
}

/**
 * Clamp an upload size cap.
 *
 * @param string $filter_name Filter that receives the default byte count.
 * @param int    $default     Default cap in bytes.
 * @return int
 */
function dsm_svg_upload_byte_cap( $filter_name, $default ) {
	$cap = (int) $default;

	if ( function_exists( 'apply_filters' ) ) {
		/**
		 * Filters an SVG upload size cap in bytes.
		 *
		 * @param int $default Default cap.
		 */
		$cap = (int) apply_filters( $filter_name, $default );
	}

	$floor = 1024;
	$ceil  = 20 * dsm_svg_upload_megabyte();

	if ( $cap < $floor ) {
		return $floor;
	}

	if ( $cap > $ceil ) {
		return $ceil;
	}

	return $cap;
}

/**
 * Whether this path is an attachment already stored under uploads.
 *
 * HTTP upload temp files stay eligible for sanitizing, including when PHP's
 * upload tmp directory sits inside the uploads folder.
 *
 * @param string $absolute_path Absolute path.
 * @return bool
 */
function dsm_svg_upload_is_stored_attachment( $absolute_path ) {
	if ( function_exists( 'is_uploaded_file' ) && is_uploaded_file( $absolute_path ) ) {
		return false;
	}

	if ( ! function_exists( 'wp_get_upload_dir' ) || ! function_exists( 'wp_normalize_path' ) ) {
		return false;
	}

	$uploads = wp_get_upload_dir();
	if ( ! is_array( $uploads ) || empty( $uploads['basedir'] ) || ! is_string( $uploads['basedir'] ) ) {
		return false;
	}

	$base = rtrim( wp_normalize_path( $uploads['basedir'] ), '/' );
	$path = wp_normalize_path( $absolute_path );

	if ( '' === $base || '' === $path ) {
		return false;
	}

	return $path === $base || 0 === strpos( $path, $base . '/' );
}

/**
 * Read a gzip SVG with a hard output cap.
 *
 * @param string $absolute_path Absolute path to the SVGZ file.
 * @return string Decompressed document, or an empty string when unsafe.
 */
function dsm_svg_upload_read_svgz( $absolute_path ) {
	if ( ! function_exists( 'gzopen' ) ) {
		return '';
	}

	$max_out = dsm_svg_upload_byte_cap( 'dsm_svg_upload_max_decompressed_bytes', 12 * dsm_svg_upload_megabyte() );
	$handle  = gzopen( $absolute_path, 'rb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_gzopen -- Bounded read of an upload temp file before it is stored.

	if ( false === $handle ) {
		return '';
	}

	$document = '';

	while ( ! gzeof( $handle ) ) {
		$chunk = gzread( $handle, 8192 );
		if ( false === $chunk || '' === $chunk ) {
			gzclose( $handle );
			return '';
		}

		$document .= $chunk;

		if ( strlen( $document ) > $max_out ) {
			gzclose( $handle );
			return '';
		}
	}

	gzclose( $handle );

	return $document;
}

/**
 * Read the full SVG or decompressed SVGZ document.
 *
 * @param string $absolute_path Absolute path.
 * @param string $ext           svg or svgz.
 * @return string
 */
function dsm_svg_upload_read_document( $absolute_path, $ext ) {
	$ext = strtolower( (string) $ext );

	if ( 'svg' !== $ext && 'svgz' !== $ext ) {
		return '';
	}

	if ( ! is_readable( $absolute_path ) ) {
		return '';
	}

	$size = filesize( $absolute_path );
	if ( false === $size || $size < 1 ) {
		return '';
	}

	$max_file = dsm_svg_upload_byte_cap( 'dsm_svg_upload_max_bytes', 8 * dsm_svg_upload_megabyte() );
	if ( (int) $size > $max_file ) {
		return '';
	}

	if ( 'svgz' === $ext ) {
		return dsm_svg_upload_read_svgz( $absolute_path );
	}

	// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- The whole upload temp file must be sanitized before WordPress stores it.
	$contents = file_get_contents( $absolute_path );
	if ( ! is_string( $contents ) || '' === $contents ) {
		return '';
	}

	return $contents;
}

/**
 * Sanitize one SVG document with the bundled allowlist.
 *
 * @param string $document Raw SVG XML.
 * @return string Sanitized document, or an empty string when it cannot be made safe.
 */
function dsm_svg_sanitize_markup( $document ) {
	$document = (string) $document;

	if ( 0 === strncmp( $document, "\xEF\xBB\xBF", 3 ) ) {
		$document = substr( $document, 3 );
	}

	if ( '' === trim( $document ) ) {
		return '';
	}

	dsm_svg_upload_register_sanitizer_autoload();

	if ( ! class_exists( '\enshrined\svgSanitize\Sanitizer' ) ) {
		return '';
	}

	$sanitizer = new \enshrined\svgSanitize\Sanitizer();
	$sanitizer->removeRemoteReferences( true );
	$sanitizer->minify( false );
	$sanitizer->setAllowHugeFiles( false );

	$clean = $sanitizer->sanitize( $document );
	if ( ! is_string( $clean ) ) {
		return '';
	}

	$clean = trim( $clean );
	if ( '' === $clean || false === stripos( $clean, '<svg' ) ) {
		return '';
	}

	return $clean;
}

/**
 * Replace an upload temp file with gzip-compressed or plain sanitized XML.
 *
 * @param string $absolute_path Absolute path.
 * @param string $ext           svg or svgz.
 * @param string $markup        Sanitized SVG XML.
 * @return bool
 */
function dsm_svg_upload_write_document( $absolute_path, $ext, $markup ) {
	$payload = $markup;

	if ( 'svgz' === $ext ) {
		if ( ! function_exists( 'gzencode' ) ) {
			return false;
		}

		$encoded = gzencode( $markup, 6 );
		if ( ! is_string( $encoded ) || '' === $encoded ) {
			return false;
		}

		$payload = $encoded;
	}

	$temporary = $absolute_path . '.dsm-svg-tmp';
	// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- Atomic replace of the upload temp file with sanitized bytes.
	$written = file_put_contents( $temporary, $payload, LOCK_EX );
	if ( false === $written ) {
		return false;
	}

	// phpcs:ignore WordPress.WP.AlternativeFunctions.rename_rename -- Replace the upload temp file in place.
	$moved = rename( $temporary, $absolute_path );
	if ( ! $moved ) {
		if ( is_file( $temporary ) ) {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.unlink_unlink -- Remove the failed temp write.
			unlink( $temporary );
		}
		return false;
	}

	return true;
}

/**
 * Sanitize an SVG or SVGZ upload and overwrite the temp file with the result.
 *
 * Files already stored in the uploads directory are left unchanged so a later
 * filetype check does not rewrite the media library. Callers must reject the
 * upload when this returns false.
 *
 * @param string $absolute_path Absolute path to the temp file.
 * @param string $ext           File extension, svg or svgz.
 * @return bool True when the file may be stored as image/svg+xml.
 */
function dsm_svg_prepare_upload_file( $absolute_path, $ext ) {
	$absolute_path = (string) $absolute_path;
	$ext           = strtolower( (string) $ext );

	if ( 'svg' !== $ext && 'svgz' !== $ext ) {
		return false;
	}

	if ( '' === $absolute_path || ! is_readable( $absolute_path ) ) {
		return false;
	}

	if ( dsm_svg_upload_is_stored_attachment( $absolute_path ) ) {
		return true;
	}

	$document = dsm_svg_upload_read_document( $absolute_path, $ext );
	if ( '' === $document ) {
		return false;
	}

	$clean = dsm_svg_sanitize_markup( $document );
	if ( '' === $clean ) {
		return false;
	}

	$max_out = dsm_svg_upload_byte_cap( 'dsm_svg_upload_max_decompressed_bytes', 12 * dsm_svg_upload_megabyte() );
	if ( strlen( $clean ) > $max_out ) {
		return false;
	}

	return dsm_svg_upload_write_document( $absolute_path, $ext, $clean );
}

/**
 * Sanitize a temporary SVG before a later upload prefilter reads the original bytes.
 *
 * Divi Icon Manager sanitizes on wp_handle_upload_prefilter at PHP_INT_MAX and
 * rejects the original file when its sanitizer returns an empty string. Call
 * this at an earlier priority. SVGZ stays on the filetype check so Divi's
 * compressed-SVG response is unchanged.
 *
 * @param array<string, mixed> $file One element from $_FILES.
 * @return array<string, mixed>
 */
function dsm_svg_upload_prefilter( $file ) {
	if ( ! is_array( $file ) ) {
		return array();
	}

	$name = isset( $file['name'] ) && is_string( $file['name'] ) ? $file['name'] : '';
	$tmp  = isset( $file['tmp_name'] ) && is_string( $file['tmp_name'] ) ? $file['tmp_name'] : '';
	$ext  = strtolower( pathinfo( $name, PATHINFO_EXTENSION ) );

	if ( 'svg' !== $ext ) {
		return $file;
	}

	$rejected = false;
	if ( '' === $tmp || ! is_readable( $tmp ) || ! dsm_svg_prepare_upload_file( $tmp, 'svg' ) ) {
		$rejected = true;
	}

	if ( $rejected ) {
		$file['error'] = __( 'This SVG could not be sanitized.', 'dsm-supreme-modules-pro-for-divi' );
		return $file;
	}

	$size = filesize( $tmp );
	if ( false !== $size ) {
		$file['size'] = (int) $size;
	}

	return $file;
}
