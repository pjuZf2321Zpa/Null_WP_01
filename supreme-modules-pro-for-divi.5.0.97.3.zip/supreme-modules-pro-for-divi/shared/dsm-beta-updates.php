<?php
/**
 * Beta update channel: optional override of production Update URI when enabled under
 * Divi Supreme Pro → Miscellaneous → "Allow Beta Updates" (valid license required).
 *
 * Resolved version + package URL order:
 * 1. Cached manifest (see {@see DSM_BETA_MANIFEST_CACHE_SECONDS}, default 48 hours). Cleared when the admin
 *    uses Dashboard → Updates → **Check again** (`?force-check=1`) and beta opt-in is on, so divisupreme is queried immediately.
 * 2. Stable channel: the same **Check again** request clears the `update_plugins` site transient early so core
 *    refetches all plugin data (including {@see Update URI}) on that load.
 * 3. Fresh GET {@see DSM_BETA_MANIFEST_URL} with licence + domain (server-side only).
 * 4. Fallback: {@see DSM_BETA_REMOTE_VERSION} + {@see DSM_BETA_PACKAGE_URL}.
 *
 * @package dsm-supreme-modules-pro-for-divi
 */

declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( function_exists( 'dsm_is_marketplace_build' ) && dsm_is_marketplace_build() ) {
	return;
}

/**
 * Site transient name for cached beta manifest JSON.
 */
const DSM_BETA_MANIFEST_TRANSIENT = 'dsm_beta_update_manifest';

/**
 * Option key under {@see get_option()} `dsm_settings_misc` for beta update opt-in.
 */
const DSM_BETA_OPT_IN_OPTION_KEY = 'dsm_allow_beta_updates';

/**
 * Whether the site has opted in to the beta update channel (Miscellaneous setting).
 *
 * @return bool
 */
function dsm_beta_updates_opt_in_is_enabled(): bool {
	$opts = get_option( 'dsm_settings_misc', array() );

	if ( ! is_array( $opts ) ) {
		return false;
	}

	$raw = isset( $opts[ DSM_BETA_OPT_IN_OPTION_KEY ] ) ? (string) $opts[ DSM_BETA_OPT_IN_OPTION_KEY ] : '';

	/**
	 * Filter whether beta updates are opted in via settings.
	 *
	 * @param bool $enabled Whether opt-in is on (`dsm_settings_misc` value `on`).
	 */
	return (bool) apply_filters( 'dsm_beta_updates_opt_in_is_enabled', 'on' === $raw );
}

/**
 * Register WordPress update filters when the beta channel is opted in.
 *
 * @return void
 */
function dsm_beta_register_update_hooks(): void {
	if ( ! is_admin() && ! wp_doing_cron() ) {
		return;
	}

	if ( ! dsm_beta_updates_opt_in_is_enabled() ) {
		return;
	}

	add_filter( 'site_transient_update_plugins', 'dsm_beta_filter_site_transient_update_plugins', 99 );
	add_filter( 'pre_set_site_transient_update_plugins', 'dsm_beta_filter_pre_set_update_plugins', 99, 3 );
	add_filter( 'plugins_api', 'dsm_beta_filter_plugins_api_plugin_information', 20, 3 );
}

add_action( 'plugins_loaded', 'dsm_beta_register_update_hooks', 20 );

/**
 * Register early cache busting for Dashboard → Updates → **Check again** (`?force-check=1`).
 *
 * Clears the `update_plugins` site transient so WordPress refetches plugin updates (Update URI + .org) on this request.
 * When beta opt-in is enabled, also clears the cached beta manifest.
 *
 * @return void
 */
function dsm_register_force_check_update_cache_hooks(): void {
	if ( ! is_admin() ) {
		return;
	}

	add_action( 'load-update-core.php', 'dsm_clear_update_checks_on_force_check', 0 );
	add_action( 'admin_init', 'dsm_clear_update_checks_on_force_check', 0 );
}

add_action( 'plugins_loaded', 'dsm_register_force_check_update_cache_hooks', 19 );

/**
 * On forced update check: drop `update_plugins` so the stable Update URI flow can pull fresh data; optionally clear beta manifest.
 *
 * @return void
 */
function dsm_clear_update_checks_on_force_check(): void {
	static $cleared_this_request = false;

	if ( $cleared_this_request ) {
		return;
	}

	if ( wp_doing_ajax() ) {
		return;
	}

	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Core uses plain GET ?force-check=1 for this screen.
	if ( ! isset( $_GET['force-check'] ) ) {
		return;
	}

	// phpcs:ignore WordPress.Security.NonceVerification.Recommended
	$raw = sanitize_text_field( wp_unslash( (string) $_GET['force-check'] ) );

	if ( '1' !== $raw ) {
		return;
	}

	if ( ! current_user_can( 'update_core' ) && ! current_user_can( 'update_plugins' ) ) {
		return;
	}

	delete_site_transient( 'update_plugins' );

	if ( function_exists( 'dsm_plugin_updater_delete_http_response_transients' ) ) {
		dsm_plugin_updater_delete_http_response_transients();
	}

	if ( class_exists( 'Woo_DS_PluginUpdate', false ) ) {
		Woo_DS_PluginUpdate::clear_request_cache();
	}

	if ( dsm_beta_updates_opt_in_is_enabled() ) {
		delete_site_transient( DSM_BETA_MANIFEST_TRANSIENT );
	}

	$cleared_this_request = true;
}

/**
 * Plugin basename for this package (cached).
 *
 * @return string Relative plugin file, e.g. `supreme-modules-pro-for-divi/supreme-modules-pro-for-divi.php`.
 */
function dsm_beta_plugin_basename(): string {
	static $cache = null;

	if ( null !== $cache ) {
		return $cache;
	}

	if ( ! defined( 'DSM_DIR_PATH' ) ) {
		return '';
	}

	$cache = plugin_basename( DSM_DIR_PATH . 'supreme-modules-pro-for-divi.php' );

	return $cache;
}

/**
 * Remove leading `V` / `v` for version_compare().
 *
 * @param string $version Raw version string.
 * @return string Normalized version.
 */
function dsm_beta_normalize_version_string( string $version ): string {
	if ( function_exists( 'dsm_plugin_updater_normalize_version_string' ) ) {
		return dsm_plugin_updater_normalize_version_string( $version );
	}

	$trimmed = trim( $version );

	return ltrim( $trimmed, "vV \t\n\r\0\x0B" );
}

/**
 * Installed plugin version for comparison.
 *
 * @return string
 */
function dsm_beta_get_installed_version_normalized(): string {
	if ( function_exists( 'dsm_plugin_updater_get_installed_version_normalized' ) ) {
		return dsm_plugin_updater_get_installed_version_normalized();
	}

	if ( ! defined( 'DSM_PRO_VERSION' ) ) {
		return '0';
	}

	return dsm_beta_normalize_version_string( (string) DSM_PRO_VERSION );
}

/**
 * Remove production / Update URI entry for this plugin so it can be replaced or omitted for beta builds.
 *
 * @param object $transient Update plugins transient.
 * @param string $basename  Plugin basename key.
 * @return void
 */
function dsm_beta_strip_plugin_entry_from_transient( object $transient, string $basename ): void {
	if ( isset( $transient->response[ $basename ] ) ) {
		unset( $transient->response[ $basename ] );
	}

	if ( isset( $transient->no_update[ $basename ] ) ) {
		unset( $transient->no_update[ $basename ] );
	}
}

/**
 * Whether stored `expiry_date` is absent (lifetime / unknown), valid, and not in the past.
 *
 * @param array<string, mixed> $license Row from {@see get_site_option()} `dsm_pro_license`.
 * @return bool
 */
function dsm_beta_stored_license_not_expired( array $license ): bool {
	$exp = isset( $license['expiry_date'] ) ? trim( (string) $license['expiry_date'] ) : '';

	if ( '' === $exp ) {
		return true;
	}

	$exp_ts = strtotime( $exp );

	if ( false === $exp_ts ) {
		return false;
	}

	return $exp_ts >= time();
}

/**
 * Licence status saved on activation (e.g. Woo `licence_status`). Empty or missing = legacy rows (eligible if not expired).
 *
 * @param array<string, mixed> $license Row from `dsm_pro_license`.
 * @return bool True if legacy/blank or explicitly `active`.
 */
function dsm_beta_stored_license_marked_active( array $license ): bool {
	if ( ! isset( $license['license_status'] ) ) {
		return true;
	}

	$status = strtolower( trim( (string) $license['license_status'] ) );

	if ( '' === $status ) {
		return true;
	}

	return 'active' === $status;
}

/**
 * Whether stored licence data indicates an active, non-expired key (beta updates only).
 *
 * Does not grant beta updates on unlicensed localhost; uses the same stored option as production licensing.
 *
 * @return bool
 */
function dsm_beta_current_user_has_valid_license_for_updates(): bool {
	$license = get_site_option( 'dsm_pro_license', array() );

	if ( ! is_array( $license ) ) {
		return false;
	}

	$key = isset( $license['key'] ) ? trim( (string) $license['key'] ) : '';

	if ( '' === $key ) {
		return false;
	}

	$allowed = dsm_beta_stored_license_marked_active( $license )
		&& dsm_beta_stored_license_not_expired( $license );

	/**
	 * Whether this site may receive beta update offers (manifest / package).
	 *
	 * @param bool                 $allowed Current result.
	 * @param array<string, mixed> $license Normalized `dsm_pro_license` row.
	 */
	return (bool) apply_filters( 'dsm_beta_license_allows_updates', $allowed, $license );
}

/**
 * Stored licence key for remote manifest requests (never output).
 *
 * @return string Sanitized key or empty.
 */
function dsm_beta_get_license_key_for_request(): string {
	$license = get_site_option( 'dsm_pro_license', array() );

	if ( ! is_array( $license ) || empty( $license['key'] ) ) {
		return '';
	}

	return sanitize_text_field( (string) $license['key'] );
}

/**
 * Domain string sent to the licensing / manifest server (matches DSM_PRO_INSTANCE when defined).
 *
 * @return string
 */
function dsm_beta_get_request_domain(): string {
	if ( defined( 'DSM_PRO_INSTANCE' ) && is_string( DSM_PRO_INSTANCE ) && '' !== DSM_PRO_INSTANCE ) {
		return DSM_PRO_INSTANCE;
	}

	return str_replace(
		array( 'https://', 'http://' ),
		'',
		trim( (string) network_site_url(), '/' )
	);
}

/**
 * Cache TTL for successful manifest payloads.
 *
 * @return int Seconds, minimum 60.
 */
function dsm_beta_get_manifest_cache_ttl(): int {
	$ttl = defined( 'DSM_BETA_MANIFEST_CACHE_SECONDS' ) ? (int) DSM_BETA_MANIFEST_CACHE_SECONDS : 48 * ( defined( 'HOUR_IN_SECONDS' ) ? HOUR_IN_SECONDS : 3600 );

	if ( $ttl < 60 ) {
		return 60;
	}

	return $ttl;
}

/**
 * Validate and normalize a resolved offer array.
 *
 * @param array<string, string> $row Raw row with version and package_url keys.
 * @return array<string, string>|null
 */
function dsm_beta_normalize_offer_row( array $row ): ?array {
	$version = isset( $row['version'] ) ? dsm_beta_normalize_version_string( sanitize_text_field( (string) $row['version'] ) ) : '';
	$raw_pkg = isset( $row['package_url'] ) ? (string) $row['package_url'] : '';

	if ( '' === $version || '' === $raw_pkg ) {
		return null;
	}

	$package = esc_url_raw( $raw_pkg, array( 'http', 'https' ) );

	if ( '' === $package || ! preg_match( '#^https?://#i', $package ) ) {
		return null;
	}

	/**
	 * Filter the beta distribution ZIP URL after manifest / fallback resolution (server-side only).
	 *
	 * @param string $package Sanitized URL.
	 */
	$filtered = apply_filters( 'dsm_beta_package_url', $package );

	if ( ! is_string( $filtered ) || '' === $filtered ) {
		return null;
	}

	$filtered = esc_url_raw( $filtered, array( 'http', 'https' ) );

	if ( '' === $filtered || ! preg_match( '#^https?://#i', $filtered ) ) {
		return null;
	}

	return array(
		'version'     => $version,
		'package_url' => $filtered,
	);
}

/**
 * Parse JSON body from divisupreme manifest endpoint.
 *
 * Expected shape: `{"success":true,"version":"…","package_url":"https://…"}` (or `package` instead of `package_url`).
 *
 * @param string $body Raw response body.
 * @return array<string, string>|null Normalized offer or null.
 */
function dsm_beta_parse_manifest_json_body( string $body ): ?array {
	$body = trim( $body );

	if ( '' === $body ) {
		return null;
	}

	$data = json_decode( $body, true );

	if ( ! is_array( $data ) ) {
		return null;
	}

	if ( isset( $data['success'] ) && false === $data['success'] ) {
		return null;
	}

	$version_raw = isset( $data['version'] ) ? (string) $data['version'] : '';
	$pkg_raw     = '';

	if ( isset( $data['package_url'] ) && '' !== (string) $data['package_url'] ) {
		$pkg_raw = (string) $data['package_url'];
	} elseif ( isset( $data['package'] ) && '' !== (string) $data['package'] ) {
		$pkg_raw = (string) $data['package'];
	}

	$row = array(
		'version'     => $version_raw,
		'package_url' => $pkg_raw,
	);

	return dsm_beta_normalize_offer_row( $row );
}

/**
 * HTTP GET the manifest from {@see DSM_BETA_MANIFEST_URL}. Does not read cache.
 *
 * @return array<string, string>|null
 */
function dsm_beta_http_fetch_manifest(): ?array {
	if ( ! defined( 'DSM_BETA_MANIFEST_URL' ) || '' === trim( (string) DSM_BETA_MANIFEST_URL ) ) {
		return null;
	}

	$base = esc_url_raw( (string) DSM_BETA_MANIFEST_URL, array( 'http', 'https' ) );

	if ( '' === $base || ! preg_match( '#^https?://#i', $base ) ) {
		return null;
	}

	$key = dsm_beta_get_license_key_for_request();

	if ( '' === $key ) {
		return null;
	}

	$product = defined( 'DSM_PRODUCT_ID' ) ? (string) DSM_PRODUCT_ID : 'DSM-PRO';

	$request_url = add_query_arg(
		array(
			'dsm_beta_manifest' => '1',
			'licence_key'       => $key,
			'domain'            => dsm_beta_get_request_domain(),
			'product_unique_id' => $product,
		),
		$base
	);

	/**
	 * Filter the full beta manifest request URL (server-side only).
	 *
	 * @param string $request_url URL after default args are merged.
	 */
	$filtered = apply_filters( 'dsm_beta_manifest_request_url', $request_url );

	if ( ! is_string( $filtered ) || '' === $filtered ) {
		return null;
	}

	$filtered = esc_url_raw( $filtered, array( 'http', 'https' ) );

	if ( '' === $filtered ) {
		return null;
	}

	$response = wp_remote_get(
		$filtered,
		array(
			'timeout'     => 20,
			'redirection' => 2,
			'sslverify'   => true,
			'user-agent'  => 'WordPress/' . get_bloginfo( 'version' ) . '; ' . dsm_beta_get_request_domain(),
			'headers'     => array(
				'Accept' => 'application/json',
			),
		)
	);

	if ( is_wp_error( $response ) ) {
		return null;
	}

	$code = (int) wp_remote_retrieve_response_code( $response );

	if ( 200 !== $code ) {
		return null;
	}

	$body_raw = wp_remote_retrieve_body( $response );

	return dsm_beta_parse_manifest_json_body( (string) $body_raw );
}

/**
 * Fallback offer from wp-config / plugin constants when manifest is unavailable.
 *
 * @return array<string, string>|null
 */
function dsm_beta_get_constant_fallback_offer(): ?array {
	if ( ! defined( 'DSM_BETA_REMOTE_VERSION' ) || '' === (string) DSM_BETA_REMOTE_VERSION ) {
		return null;
	}

	if ( ! defined( 'DSM_BETA_PACKAGE_URL' ) || '' === (string) DSM_BETA_PACKAGE_URL ) {
		return null;
	}

	$row = array(
		'version'     => (string) DSM_BETA_REMOTE_VERSION,
		'package_url' => (string) DSM_BETA_PACKAGE_URL,
	);

	return dsm_beta_normalize_offer_row( $row );
}

/**
 * Resolved beta version + package URL for the current site (manifest + cache + constant fallback).
 *
 * @return array{version: string, package_url: string}|null
 */
function dsm_beta_get_resolved_update_offer(): ?array {
	if ( ! dsm_beta_current_user_has_valid_license_for_updates() ) {
		return null;
	}

	$cached = get_site_transient( DSM_BETA_MANIFEST_TRANSIENT );

	if ( is_array( $cached ) && isset( $cached['version'], $cached['package_url'] ) ) {
		$normalized = dsm_beta_normalize_offer_row(
			array(
				'version'     => (string) $cached['version'],
				'package_url' => (string) $cached['package_url'],
			)
		);

		if ( null !== $normalized ) {
			$still_newer = function_exists( 'dsm_plugin_updater_remote_is_newer_than_installed' )
				? dsm_plugin_updater_remote_is_newer_than_installed( $normalized['version'] )
				: version_compare( $normalized['version'], dsm_beta_get_installed_version_normalized(), '>' );

			if ( $still_newer ) {
				return $normalized;
			}

			delete_site_transient( DSM_BETA_MANIFEST_TRANSIENT );
		}
	}

	if ( defined( 'DSM_BETA_MANIFEST_URL' ) && '' !== trim( (string) DSM_BETA_MANIFEST_URL ) ) {
		$remote = dsm_beta_http_fetch_manifest();

		if ( null !== $remote ) {
			set_site_transient( DSM_BETA_MANIFEST_TRANSIENT, $remote, dsm_beta_get_manifest_cache_ttl() );

			return $remote;
		}
	}

	return dsm_beta_get_constant_fallback_offer();
}

/**
 * Apply beta-channel rules to the update_plugins transient value.
 *
 * @param \stdClass|mixed $transient Value being filtered.
 * @return \stdClass|mixed
 */
function dsm_beta_apply_beta_channel_to_transient( $transient ) {
	if ( ! is_object( $transient ) ) {
		return $transient;
	}

	if ( ! dsm_beta_updates_opt_in_is_enabled() ) {
		return $transient;
	}

	$basename = dsm_beta_plugin_basename();

	if ( '' === $basename ) {
		return $transient;
	}

	$current = dsm_beta_get_installed_version_normalized();

	$offer = dsm_beta_get_resolved_update_offer();

	if ( null === $offer ) {
		dsm_beta_strip_plugin_entry_from_transient( $transient, $basename );

		return $transient;
	}

	$new_version = $offer['version'];
	$package     = $offer['package_url'];

	$is_newer = function_exists( 'dsm_plugin_updater_remote_is_newer_than_installed' )
		? dsm_plugin_updater_remote_is_newer_than_installed( $new_version, $current )
		: ( '' !== $current && version_compare( $new_version, $current, '>' ) );

	dsm_beta_strip_plugin_entry_from_transient( $transient, $basename );

	if ( ! $is_newer ) {
		return $transient;
	}

	$transient->response[ $basename ] = (object) array(
		'id'          => 'divisupreme.com/supreme-modules-pro-for-divi-beta',
		'slug'        => 'supreme-modules-pro-for-divi',
		'plugin'      => $basename,
		'new_version' => $new_version,
		'url'         => 'https://divisupreme.com/',
		'package'     => $package,
		'tested'      => get_bloginfo( 'version' ),
	);

	return $transient;
}

/**
 * Filter cached `update_plugins` transient.
 *
 * @param \stdClass|mixed $transient Current transient value.
 * @return \stdClass|mixed
 */
function dsm_beta_filter_site_transient_update_plugins( $transient ) {
	return dsm_beta_apply_beta_channel_to_transient( $transient );
}

/**
 * Filter `update_plugins` transient before it is saved.
 *
 * @param \stdClass|mixed $transient   Prepared transient.
 * @param int|null        $expiration  TTL (unused).
 * @param string          $name        Transient name (unused).
 * @return \stdClass|mixed
 */
function dsm_beta_filter_pre_set_update_plugins( $transient, $expiration = null, $name = '' ) {
	return dsm_beta_apply_beta_channel_to_transient( $transient );
}

/**
 * Provide minimal plugin information in the thick-box when the core API has nothing (beta-only).
 *
 * Does not expose the package URL in this payload.
 *
 * @param false|object|array $result  Result.
 * @param string             $action  API action.
 * @param object             $args    Request args.
 * @return false|object|array
 */
function dsm_beta_filter_plugins_api_plugin_information( $result, string $action, $args ) {
	if ( 'plugin_information' !== $action ) {
		return $result;
	}

	if ( ! is_object( $args ) || empty( $args->slug ) ) {
		return $result;
	}

	if ( 'supreme-modules-pro-for-divi' !== (string) $args->slug ) {
		return $result;
	}

	if ( ! dsm_beta_updates_opt_in_is_enabled() ) {
		return $result;
	}

	$offer = dsm_beta_get_resolved_update_offer();

	if ( null === $offer ) {
		return $result;
	}

	$new_version = $offer['version'];

	return (object) array(
		'name'          => 'Divi Supreme Pro',
		'slug'          => 'supreme-modules-pro-for-divi',
		'version'       => $new_version,
		'author'        => '<a href="https://divisupreme.com/">Divi Supreme</a>',
		'homepage'      => 'https://divisupreme.com/',
		'download_link' => '',
		'sections'      => array(
			'description' => __( 'Beta release channel. Updates are provided to valid license holders only.', 'dsm-supreme-modules-pro-for-divi' ),
		),
		'banners'       => array(),
		'icons'         => array(),
	);
}

/**
 * Hostnames whose plugin ZIP URLs must not be echoed in core’s “Downloading update from %s…” progress line.
 *
 * Used when beta opt-in is enabled (see {@see dsm_register_upgrader_masked_package_download}).
 * Display hardening only — real protection is time-limited / signed download URLs on divisupreme.com.
 *
 * @return list<string> Lowercase hosts.
 */
function dsm_mask_plugin_download_feedback_hosts(): array {
	$hosts = array( 'd5.divisupreme.com' );

	/**
	 * Add hostnames (lowercase) whose package URLs should trigger a generic Divi Supreme download message.
	 *
	 * @param list<string> $hosts Host names.
	 */
	$filtered = apply_filters( 'dsm_mask_plugin_download_feedback_hosts', $hosts );

	if ( ! is_array( $filtered ) ) {
		return $hosts;
	}

	$out = array();

	foreach ( $filtered as $h ) {
		$h = strtolower( trim( (string) $h ) );
		if ( '' !== $h ) {
			$out[] = $h;
		}
	}

	return array_values( array_unique( $out ) );
}

/**
 * Whether this upgrader operation is our plugin from a masked host.
 *
 * @param string               $package    Package URL.
 * @param array<string, mixed> $hook_extra Hook extra.
 * @return bool
 */
function dsm_mask_should_intercept_plugin_package_download( string $package, array $hook_extra ): bool {
	$plugin = isset( $hook_extra['plugin'] ) ? (string) $hook_extra['plugin'] : '';

	if ( '' === $plugin || $plugin !== dsm_beta_plugin_basename() ) {
		return false;
	}

	if ( ! preg_match( '#^https?://#i', $package ) ) {
		return false;
	}

	$host = wp_parse_url( $package, PHP_URL_HOST );

	if ( ! is_string( $host ) || '' === $host ) {
		return false;
	}

	$host = strtolower( $host );

	foreach ( dsm_mask_plugin_download_feedback_hosts() as $allowed ) {
		if ( $host === $allowed ) {
			return true;
		}
	}

	return false;
}

/**
 * Pre-download: perform the download ourselves so core never prints the raw package URL, only a generic line.
 *
 * Runs only when beta opt-in is enabled; the filter is not registered otherwise.
 *
 * @param false|string|\WP_Error $reply      Short-circuit reply.
 * @param string                 $package    Remote package URL.
 * @param \WP_Upgrader           $upgrader   Upgrader instance.
 * @param array<string, mixed>    $hook_extra Context.
 * @return false|string|\WP_Error
 */
function dsm_filter_upgrader_pre_download_mask_package_url( $reply, string $package, $upgrader, array $hook_extra ) {
	if ( ! dsm_beta_updates_opt_in_is_enabled() ) {
		return $reply;
	}

	if ( false !== $reply ) {
		return $reply;
	}

	if ( ! dsm_mask_should_intercept_plugin_package_download( $package, $hook_extra ) ) {
		return $reply;
	}

	if ( ! function_exists( 'download_url' ) ) {
		require_once ABSPATH . 'wp-admin/includes/file.php';
	}

	if (
		is_object( $upgrader )
		&& isset( $upgrader->skin )
		&& is_object( $upgrader->skin )
		&& method_exists( $upgrader->skin, 'feedback' )
	) {
		/**
		 * Notice without exposing the signed or static ZIP path.
		 *
		 * @since 1.0.0
		 */
		$upgrader->skin->feedback(
			(string) apply_filters(
				'dsm_masked_plugin_download_feedback_message',
				__( 'Downloading Divi Supreme Pro update…', 'dsm-supreme-modules-pro-for-divi' )
			)
		);
	}

	return download_url( $package, 300 );
}

/**
 * Register masked download feedback when beta opt-in is enabled.
 *
 * Stable channel (opt-in off) uses Update URI without this interceptor so core shows the normal package line.
 *
 * @return void
 */
function dsm_register_upgrader_masked_package_download(): void {
	if ( ! dsm_beta_updates_opt_in_is_enabled() ) {
		return;
	}

	add_filter( 'upgrader_pre_download', 'dsm_filter_upgrader_pre_download_mask_package_url', 10, 4 );
}

add_action( 'plugins_loaded', 'dsm_register_upgrader_masked_package_download', 25 );

/**
 * Supplemental HTML for the Misc → Allow Beta Updates field (channel line + warning).
 *
 * @param string $stored_checkbox_value Saved value (`on` or empty / `off`).
 * @return string HTML fragment (escaped).
 */
function dsm_beta_misc_settings_allow_beta_extra_html( string $stored_checkbox_value ): string {
	$opt_in       = ( 'on' === $stored_checkbox_value );
	$license_ok   = dsm_beta_current_user_has_valid_license_for_updates();
	$effective    = $opt_in && $license_ok;
	$channel_text = $effective
		? __( 'Beta', 'dsm-supreme-modules-pro-for-divi' )
		: __( 'Stable', 'dsm-supreme-modules-pro-for-divi' );

	$license_note = '';
	if ( $opt_in && ! $license_ok ) {
		$license_note = ' ' . __( 'Activate a valid license key to receive beta updates.', 'dsm-supreme-modules-pro-for-divi' );
	}

	$channel_detail = '<span class="dsm-beta-alert__title">'
		. esc_html__( 'Current update channel', 'dsm-supreme-modules-pro-for-divi' )
		. '</span> '
		. '<span class="dsm-beta-alert__body">'
		. esc_html( $channel_text )
		. esc_html( $license_note )
		. '</span>';

	$warning_detail = '<span class="dsm-beta-alert__title">'
		. esc_html__( 'Warning', 'dsm-supreme-modules-pro-for-divi' )
		. '</span> '
		. '<span class="dsm-beta-alert__body">'
		. esc_html__( 'Beta releases may be unstable or incompatible with some setups. Enable only if you accept that risk.', 'dsm-supreme-modules-pro-for-divi' )
		. '</span>';

	return '<div class="dsm-beta-update-channel-notice" role="region" aria-label="'
		. esc_attr__( 'Beta update channel', 'dsm-supreme-modules-pro-for-divi' )
		. '">'
		. '<div class="dsm-beta-alert dsm-beta-alert--info" role="status">'
		. '<span class="dsm-beta-alert__glyph dsm-beta-alert__glyph--info" aria-hidden="true"></span>'
		. '<div class="dsm-beta-alert__content">' . $channel_detail . '</div>'
		. '</div>'
		. '<div class="dsm-beta-alert dsm-beta-alert--warning" role="alert">'
		. '<span class="dsm-beta-alert__glyph dsm-beta-alert__glyph--warning" aria-hidden="true"></span>'
		. '<div class="dsm-beta-alert__content">' . $warning_detail . '</div>'
		. '</div>'
		. '</div>';
}

