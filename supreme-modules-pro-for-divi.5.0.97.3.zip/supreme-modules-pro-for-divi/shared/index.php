<?php
/**
 * Shared functionality loader for Divi Supreme Modules.
 *
 * This file loads all shared functionality that can be used across different versions.
 *
 * @since 1.0.0
 * @package dsm-supreme-modules-pro-for-divi
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Require attachment fields functionality.
if ( ! dsm_require_plugin_file( plugin_dir_path( __FILE__ ) . 'dsm-attachment-fields.php' ) ) {
	return;
}

// SVG and SVGZ upload sanitizer (Divi 4 and Divi 5).
if ( ! dsm_require_plugin_file( plugin_dir_path( __FILE__ ) . 'dsm-svg-upload.php' ) ) {
	return;
}

// Default WordPress admin menu mark (D4 / D5).
if ( ! dsm_require_plugin_file( plugin_dir_path( __FILE__ ) . 'dsm-admin-menu-icon.php' ) ) {
	return;
}

// Enable Dynamic Assets option helper (`dsm_settings_misc`).
if ( ! dsm_require_plugin_file( plugin_dir_path( __FILE__ ) . 'dsm-dynamic-assets-option.php' ) ) {
	return;
}

// Shared text path extra shape presets (D4 / D5).
if ( ! dsm_require_plugin_file( plugin_dir_path( __FILE__ ) . 'dsm-text-path-shape-presets.php' ) ) {
	return;
}

// Theme Builder editor preview trail for Breadcrumbs (D4 + D5).
if ( ! dsm_require_plugin_file( plugin_dir_path( __FILE__ ) . 'dsm-breadcrumbs-theme-builder-preview.php' ) ) {
	return;
}

// Persist dismissible admin notices (D4 / D5).
if ( ! dsm_require_plugin_file( plugin_dir_path( __FILE__ ) . 'persist-admin-notices-dismissal/persist-admin-notices-dismissal.php' ) ) {
	return;
}

if ( class_exists( 'DSM_NOTICE' ) ) {
	add_action( 'admin_init', array( 'DSM_NOTICE', 'init' ) );
}

if ( ! function_exists( 'dsm_is_marketplace_build' ) || ! dsm_is_marketplace_build() ) {
	// Shared remote licensing (deactivate API; uninstall + settings).
	if ( ! dsm_require_plugin_file( plugin_dir_path( __FILE__ ) . 'dsm-license-remote.php' ) ) {
		return;
	}

	// Post-upgrade update transient / HTTP cache busting + version helpers.
	if ( ! dsm_require_plugin_file( plugin_dir_path( __FILE__ ) . 'dsm-plugin-updater-cache.php' ) ) {
		return;
	}

	// Beta update channel (optional; gated by Misc → Allow Beta Updates + licence checks).
	if ( ! dsm_require_plugin_file( plugin_dir_path( __FILE__ ) . 'dsm-beta-updates.php' ) ) {
		return;
	}

	// Stable channel: same license API updater as Divi 4 (Divi 5 does not load it from the D4 bootstrap).
	if ( ! dsm_require_plugin_file( plugin_dir_path( __FILE__ ) . 'dsm-stable-plugin-updater-loader.php' ) ) {
		return;
	}
}
