<?php
/**
 * Default WordPress admin menu mark for Divi Supreme Pro.
 *
 * @package supreme-modules-pro-for-divi
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Dotted D mark used when Miscellaneous → menu icon is empty.
 *
 * Returned as a base64 SVG data URI so WordPress paints it as a menu background
 * at full opacity. A plain SVG file URL is rendered as an img and faded to 60%.
 *
 * @return string Menu icon for add_menu_page().
 */
function dsm_default_admin_menu_icon(): string {
	$path = DSM_DIR_PATH . 'divi-5/assets/static/admin-menu-icon.svg';
	if ( ! is_readable( $path ) ) {
		return 'dashicons-admin-generic';
	}

	$svg = file_get_contents( $path );
	if ( ! is_string( $svg ) || '' === $svg ) {
		return 'dashicons-admin-generic';
	}

	return 'data:image/svg+xml;base64,' . base64_encode( $svg );
}
