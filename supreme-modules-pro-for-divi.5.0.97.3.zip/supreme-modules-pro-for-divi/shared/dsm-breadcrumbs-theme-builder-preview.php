<?php
/**
 * Theme Builder editor preview trail for Supreme Breadcrumbs (D4 + D5).
 *
 * Matches Divi’s native Breadcrumbs module: a fixed sample trail in the builder.
 * Front end must not use this unless the current document is a Theme Builder
 * layout CPT in the builder.
 *
 * @package dsm-supreme-modules-pro-for-divi
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Whether a post type is a Theme Builder header/body/footer layout.
 *
 * @param string $post_type Post type slug.
 * @return bool
 */
function dsm_breadcrumbs_is_layout_post_type( string $post_type ): bool {
	if ( '' === $post_type ) {
		return false;
	}

	if ( function_exists( 'et_theme_builder_is_layout_post_type' ) ) {
		return et_theme_builder_is_layout_post_type( $post_type );
	}

	$types = array( 'et_header_layout', 'et_body_layout', 'et_footer_layout' );

	if ( function_exists( 'et_theme_builder_get_layout_post_types' ) ) {
		$from_divi = et_theme_builder_get_layout_post_types();
		if ( is_array( $from_divi ) && array() !== $from_divi ) {
			$types = $from_divi;
		}
	}

	return in_array( $post_type, $types, true );
}

/**
 * Resolve the Theme Builder layout post ID being edited, if any.
 *
 * @param int $hint Optional ID from a computed callback / queried object.
 * @return int
 */
function dsm_breadcrumbs_get_theme_builder_layout_post_id( int $hint = 0 ): int {
	if ( $hint > 0 && dsm_breadcrumbs_is_layout_post_type( (string) get_post_type( $hint ) ) ) {
		return $hint;
	}

	if ( function_exists( 'dsm_get_vb_builder_edited_post_id' ) ) {
		$edited = dsm_get_vb_builder_edited_post_id();
		if ( $edited > 0 && dsm_breadcrumbs_is_layout_post_type( (string) get_post_type( $edited ) ) ) {
			return $edited;
		}
	}

	// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only post ID for builder preview.
	if ( isset( $_GET['post'] ) ) {
		$from_get = absint( wp_unslash( $_GET['post'] ) );
		if ( $from_get > 0 && dsm_breadcrumbs_is_layout_post_type( (string) get_post_type( $from_get ) ) ) {
			return $from_get;
		}
	}
	// phpcs:enable WordPress.Security.NonceVerification.Recommended

	$queried = get_queried_object();
	if ( $queried instanceof WP_Post && dsm_breadcrumbs_is_layout_post_type( $queried->post_type ) ) {
		return (int) $queried->ID;
	}

	global $post;
	if ( $post instanceof WP_Post && dsm_breadcrumbs_is_layout_post_type( $post->post_type ) ) {
		return (int) $post->ID;
	}

	return 0;
}

/**
 * Whether breadcrumbs should use a Theme Builder editor preview trail.
 *
 * Uses existing DSP/Divi builder flags only. Never true for a normal front-end
 * post/page (those are not layout CPTs).
 *
 * @param int $hint Optional layout post ID hint.
 * @return bool
 */
function dsm_breadcrumbs_should_use_theme_builder_preview( int $hint = 0 ): bool {
	$layout_id = dsm_breadcrumbs_get_theme_builder_layout_post_id( $hint );
	if ( $layout_id <= 0 ) {
		return false;
	}

	$in_builder = false;

	if ( function_exists( 'et_builder_tb_enabled' ) && et_builder_tb_enabled() ) {
		$in_builder = true;
	} elseif ( class_exists( '\ET\Builder\Framework\Utility\Conditions' ) && \ET\Builder\Framework\Utility\Conditions::is_tb_enabled() ) {
		$in_builder = true;
	} elseif ( function_exists( 'et_core_is_fb_enabled' ) && et_core_is_fb_enabled() ) {
		$in_builder = true;
	} elseif ( function_exists( 'et_fb_is_enabled' ) && et_fb_is_enabled() ) {
		$in_builder = true;
	} elseif ( is_admin() ) {
		$in_builder = true;
	}

	/**
	 * Filter whether the Breadcrumbs module should render a Theme Builder preview trail.
	 *
	 * @param bool $in_builder Whether the current request is a TB/VB editor context for a layout CPT.
	 * @param int  $layout_id  Layout post ID.
	 */
	return (bool) apply_filters( 'dsm_breadcrumbs_should_use_theme_builder_preview', $in_builder, $layout_id );
}

/**
 * Divi-style sample crumbs after Home (builder only).
 *
 * @return list<array{text: string, url: string}>
 */
function dsm_breadcrumbs_theme_builder_sample_crumbs(): array {
	return array(
		array(
			'text' => __( 'Parent Page', 'dsm-supreme-modules-pro-for-divi' ),
			'url'  => '',
		),
		array(
			'text' => __( 'Your Current Page Title', 'dsm-supreme-modules-pro-for-divi' ),
			'url'  => '',
		),
	);
}

/**
 * Full preview trail including Home for Theme Builder editor.
 *
 * Always the Divi sample (Home → Parent Page → Your Current Page Title).
 * Does not read template assignment conditions.
 *
 * @param array<string, mixed> $args {
 *     @type string $home_text      Home crumb label.
 *     @type string $home_url       Home crumb URL.
 *     @type int    $layout_post_id Optional layout post ID hint (unused for labels).
 * }
 * @return list<array{text: string, url: string}>
 */
function dsm_breadcrumbs_get_theme_builder_preview_trail( array $args = array() ): array {
	$home_text = isset( $args['home_text'] ) && is_string( $args['home_text'] ) && '' !== $args['home_text']
		? $args['home_text']
		: __( 'Home', 'dsm-supreme-modules-pro-for-divi' );
	$home_url = isset( $args['home_url'] ) && is_string( $args['home_url'] ) ? $args['home_url'] : home_url();

	$trail = array(
		array(
			'text' => $home_text,
			'url'  => $home_url,
		),
	);

	$trail = array_merge( $trail, dsm_breadcrumbs_theme_builder_sample_crumbs() );

	/**
	 * Filter the Theme Builder editor breadcrumb preview trail.
	 *
	 * @param list<array{text: string, url: string}> $trail Trail including Home.
	 * @param array<string, mixed>                   $args  Parsed args.
	 */
	return apply_filters( 'dsm_breadcrumbs_theme_builder_preview_trail', $trail, $args );
}

/**
 * Payload for Visual Builder `edit.js` (`window.diviSupreme5.breadcrumbsThemeBuilderPreview`).
 *
 * @return array{active: bool, crumbs: list<array{text: string, url: string}>}
 */
function dsm_breadcrumbs_get_theme_builder_preview_js_payload(): array {
	$active = dsm_breadcrumbs_should_use_theme_builder_preview();
	$crumbs = array();

	if ( $active ) {
		$trail = dsm_breadcrumbs_get_theme_builder_preview_trail();
		if ( count( $trail ) > 1 ) {
			$crumbs = array_slice( $trail, 1 );
		}
	}

	return array(
		'active' => $active,
		'crumbs' => $crumbs,
	);
}
