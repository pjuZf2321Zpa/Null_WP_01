<?php
/**
 * Divi Supreme DiviExtension.
 *
 * @since 1.0.0
 */
class DSM_SupremeModulesProForDivi extends DiviExtension {

	/**
	 * The gettext domain for the extension's translations.
	 *
	 * @since 1.0.0
	 *
	 * @var string
	 */
	public $gettext_domain = 'dsm-supreme-modules-pro-for-divi';

	/**
	 * The extension's WP Plugin name.
	 *
	 * @since 1.0.0
	 *
	 * @var string
	 */
	public $name = 'supreme-modules-pro-for-divi';

	/**
	 * The extension's version
	 *
	 * @since 1.0.0
	 *
	 * @var string
	 */
	public $version = DSM_PRO_VERSION;

	/**
	 * Base URL for compiled divi-scripts bundles (`scripts/` at plugin root).
	 *
	 * @since 4.9.97
	 *
	 * @var string
	 */
	private $scripts_dir_url = '';

	/**
	 * DSM_SupremeModulesProForDivi constructor.
	 *
	 * @param string $name Plugin Name.
	 * @param array  $args Args.
	 */
	public function __construct( $name = 'supreme-modules-pro-for-divi', $args = array() ) {
		$this->plugin_dir      = plugin_dir_path( __FILE__ );
		$this->plugin_dir_url  = plugin_dir_url( $this->plugin_dir );
		$this->scripts_dir_url = plugin_dir_url( __FILE__ ) . '../scripts/';

		parent::__construct( $name, $args );
	}

	/**
	 * Builder bundle loads Swiper 12 from the shared frontend script handle.
	 *
	 * @since 4.9.97
	 */
	protected function _set_bundle_dependencies() {
		parent::_set_bundle_dependencies();

		$this->_bundle_dependencies['builder'][] = 'dsm-swiper';
	}

	/**
	 * Register Swiper 12 for Visual Builder when the public class has not already.
	 *
	 * @since 4.9.97
	 */
	protected function dsm_register_builder_swiper_script() {
		if ( wp_script_is( 'dsm-swiper', 'registered' ) ) {
			return;
		}

		wp_register_script(
			'dsm-swiper',
			plugin_dir_url( __FILE__ ) . '../public/js/swiper-bundle.min.js',
			array(),
			$this->version,
			true
		);
	}

	/**
	 * Enqueues minified, production javascript bundles.
	 *
	 * @since 4.9.97
	 */
	protected function _enqueue_bundles() {
		wp_enqueue_script(
			"{$this->name}-frontend-bundle",
			$this->scripts_dir_url . 'frontend-bundle.min.js',
			$this->_bundle_dependencies['frontend'],
			$this->version,
			true
		);

		if ( et_core_is_fb_enabled() ) {
			$this->dsm_register_builder_swiper_script();
			wp_enqueue_script( 'dsm-swiper' );

			wp_enqueue_script(
				"{$this->name}-builder-bundle",
				$this->scripts_dir_url . 'builder-bundle.min.js',
				$this->_bundle_dependencies['builder'],
				$this->version,
				true
			);
		}
	}

	/**
	 * Enqueues non-minified, hot reloaded javascript bundles.
	 *
	 * @since 4.9.97
	 */
	protected function _enqueue_debug_bundles() {
		$site_url       = wp_parse_url( get_site_url() );
		$hot_bundle_url = "{$site_url['scheme']}://{$site_url['host']}:3000/static/js/frontend-bundle.js";

		wp_enqueue_script(
			"{$this->name}-frontend-bundle",
			$hot_bundle_url,
			$this->_bundle_dependencies['frontend'],
			$this->version,
			true
		);

		if ( et_core_is_fb_enabled() ) {
			$this->dsm_register_builder_swiper_script();
			wp_enqueue_script( 'dsm-swiper' );

			$hot_bundle_url = "{$site_url['scheme']}://{$site_url['host']}:3000/static/js/builder-bundle.js";

			wp_enqueue_script(
				"{$this->name}-builder-bundle",
				$hot_bundle_url,
				$this->_bundle_dependencies['builder'],
				$this->version,
				true
			);
		}
	}
}

new DSM_SupremeModulesProForDivi();
