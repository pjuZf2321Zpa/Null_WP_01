<?php
/**
 * Allow sanitized SVG and SVGZ uploads when the Media Library setting is on.
 *
 * @package dsm-supreme-modules-pro-for-divi
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'DSM_SVG_Handler' ) ) {
	/**
	 * Registers the SVG MIME type and rejects unsanitized documents.
	 */
	class DSM_SVG_Handler {
		const MIME_TYPE = 'image/svg+xml';

		/**
		 * Add SVG and SVGZ to allowed file uploads.
		 *
		 * @since 3.3.8
		 *
		 * @param array<string, string> $mimes Mime types keyed by extension.
		 * @return array<string, string>
		 */
		public function dsm_mime_types( $mimes ) {
			if ( ! is_array( $mimes ) ) {
				$mimes = array();
			}

			$mimes['svg']  = self::MIME_TYPE;
			$mimes['svgz'] = self::MIME_TYPE;

			return $mimes;
		}

		/**
		 * Accept SVG or SVGZ only after the shared allowlist sanitizer rewrites the temp file.
		 *
		 * @since 3.3.8
		 *
		 * @param array<string, mixed> $types    Filetype data.
		 * @param string               $file     Absolute path to the temp file.
		 * @param string               $filename Original filename.
		 * @param array<string, mixed> $mimes    Mime map.
		 * @return array<string, mixed>
		 */
		public function dsm_check_filetype_and_ext( $types, $file, $filename, $mimes ) {
			unset( $mimes );

			if ( ! is_array( $types ) ) {
				$types = array();
			}

			if ( ! is_string( $filename ) || '' === $filename ) {
				return $types;
			}

			$ext = strtolower( pathinfo( $filename, PATHINFO_EXTENSION ) );
			if ( 'svg' !== $ext && 'svgz' !== $ext ) {
				return $types;
			}

			if ( ! is_string( $file ) || '' === $file || ! is_readable( $file ) ) {
				return $types;
			}

			if ( ! function_exists( 'dsm_svg_prepare_upload_file' ) || ! dsm_svg_prepare_upload_file( $file, $ext ) ) {
				$types['ext']             = false;
				$types['type']            = false;
				$types['proper_filename'] = false;

				return $types;
			}

			$types['ext']  = $ext;
			$types['type'] = self::MIME_TYPE;

			return $types;
		}

		/**
		 * Sanitize an SVG temp file before Divi reads the original bytes.
		 *
		 * @param array<string, mixed> $file One element from $_FILES.
		 * @return array<string, mixed>
		 */
		public function dsm_upload_prefilter( $file ) {
			if ( ! function_exists( 'dsm_svg_upload_prefilter' ) ) {
				return is_array( $file ) ? $file : array();
			}

			return dsm_svg_upload_prefilter( $file );
		}

		/**
		 * Hook the Media Library MIME filters.
		 *
		 * The caller constructs this class only when SVG uploads are enabled.
		 * The prefilter priority stays below PHP_INT_MAX so it runs before Divi
		 * Icon Manager's upload gate.
		 */
		public function __construct() {
			add_filter( 'upload_mimes', array( $this, 'dsm_mime_types' ) );
			add_filter( 'wp_handle_upload_prefilter', array( $this, 'dsm_upload_prefilter' ), 10, 1 );
			add_filter( 'wp_handle_sideload_prefilter', array( $this, 'dsm_upload_prefilter' ), 10, 1 );
			add_filter( 'wp_check_filetype_and_ext', array( $this, 'dsm_check_filetype_and_ext' ), 10, 4 );
		}
	}
}
