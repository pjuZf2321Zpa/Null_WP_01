<?php
/**
 * Fired during plugin deactivation
 *
 * @link       https://divisupreme.com
 * @since      1.0.0
 * @package    Dsm_Supreme_Modules_Pro_For_Divi
 * @subpackage Dsm_Supreme_Modules_Pro_For_Divi/includes
 */

declare(strict_types=1);

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Dsm_Supreme_Modules_Pro_For_Divi
 * @subpackage Dsm_Supreme_Modules_Pro_For_Divi/includes
 * @author     Divi Supreme <hello@divisupreme.com>
 */
class Dsm_Supreme_Modules_Pro_For_Divi_Deactivator {

	/**
	 * Remove temporary support access so deactivation cannot leave an account behind.
	 *
	 * A network deactivation clears every site. A single-site deactivation clears only that site.
	 *
	 * @since 1.0.0
	 * @param bool $network_deactivating Whether WordPress is deactivating the plugin for the whole network.
	 * @return void
	 */
	public static function deactivate( $network_deactivating = false ) {
		if ( PHP_VERSION_ID < 70000 ) {
			return;
		}

		$file = dirname( __DIR__, 2 ) . '/divi-5/app/Includes/Support/TemporaryAccess.php';

		if ( ! class_exists( \DiviSupreme\Includes\Support\TemporaryAccess::class, false ) && is_readable( $file ) ) {
			require_once $file;
		}

		if ( ! class_exists( \DiviSupreme\Includes\Support\TemporaryAccess::class ) ) {
			return;
		}

		$revoke = static function () {
			\DiviSupreme\Includes\Support\TemporaryAccess::revoke( 'deactivated' );
		};

		if ( ! $network_deactivating || ! is_multisite() ) {
			$revoke();
			return;
		}

		$offset     = 0;
		$batch_size = 200;

		while ( true ) {
			$site_ids = get_sites(
				array(
					'fields' => 'ids',
					'number' => $batch_size,
					'offset' => $offset,
				)
			);

			if ( array() === $site_ids ) {
				break;
			}

			foreach ( $site_ids as $dsm_blog_id ) {
				switch_to_blog( (int) $dsm_blog_id );
				$revoke();
				restore_current_blog();
			}

			$offset += $batch_size;
			if ( count( $site_ids ) < $batch_size ) {
				break;
			}
		}
	}
}
