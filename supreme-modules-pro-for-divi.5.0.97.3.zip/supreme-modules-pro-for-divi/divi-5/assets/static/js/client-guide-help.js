/**
 * Live search for the Client Guide Help screen.
 * The form still submits when JavaScript is unavailable.
 */
( function () {
	var root = document.querySelector( '.dsm-client-guide-help' );

	if ( ! root ) {
		return;
	}

	var input = document.getElementById( 'dsm-client-guide-help-search' );
	var main = root.querySelector( '.dsm-client-guide-help__main' );
	var form = input ? input.form : null;

	if ( ! input || ! main || ! form ) {
		return;
	}

	var timer = 0;

	input.addEventListener( 'input', function () {
		window.clearTimeout( timer );
		timer = window.setTimeout( function () {
			var params = new URLSearchParams( new FormData( form ) );
			var term = input.value.trim();

			if ( term ) {
				params.set( 's', term );
			} else {
				params.delete( 's' );
			}

			params.delete( 'doc' );

			var url = form.getAttribute( 'action' ) + '?' + params.toString();

			window.fetch( url, { credentials: 'same-origin' } )
				.then( function ( response ) {
					if ( ! response.ok ) {
						throw new Error( 'search failed' );
					}

					return response.text();
				} )
				.then( function ( html ) {
					var parsed = new DOMParser().parseFromString( html, 'text/html' );
					var next = parsed.querySelector( '.dsm-client-guide-help__main' );

					if ( ! next ) {
						return;
					}

					main.innerHTML = next.innerHTML;

					if ( window.history && window.history.replaceState ) {
						window.history.replaceState( null, '', url );
					}

					root.querySelectorAll( '.dsm-help-nav__link[aria-current]' ).forEach( function ( link ) {
						link.removeAttribute( 'aria-current' );
					} );
				} )
				.catch( function () {} );
		}, 250 );
	} );
}() );
