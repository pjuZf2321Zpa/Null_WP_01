/**
 * Text Notation frontend: Rough Notation + in-viewport trigger (no jQuery).
 */
( function () {
	'use strict';

	/**
	 * @param {string|null} raw
	 * @return {number}
	 */
	function parseDelayMs( raw ) {
		if ( raw == null || raw === '' ) {
			return 0;
		}
		const m = String( raw ).match( /^(\d+)\s*ms$/i );
		if ( m ) {
			return parseInt( m[ 1 ], 10 );
		}
		const n = parseInt( raw, 10 );
		return Number.isNaN( n ) ? 0 : n;
	}

	/**
	 * Waypoints-style `offset` as percent of viewport height from top (e.g. "80%").
	 *
	 * @param {string|null} offsetStr
	 * @return {number} 0–1
	 */
	function viewportOffsetFraction( offsetStr ) {
		const m = String( offsetStr || '' ).match(
			/^(\d+(?:\.\d+)?)\s*%$/
		);
		if ( m ) {
			const p = parseFloat( m[ 1 ] );
			if ( ! Number.isNaN( p ) ) {
				return Math.min( 1, Math.max( 0, p / 100 ) );
			}
		}
		return 0.8;
	}

	/**
	 * When the element's top crosses the trigger line (fraction * innerHeight), run callback once.
	 *
	 * @param {Element} el
	 * @param {number}  triggerFraction
	 * @param {() => void} callback
	 */
	function onViewportCross( el, triggerFraction, callback ) {
		let fired = false;
		const run = () => {
			if ( fired ) {
				return;
			}
			const thresholdY = window.innerHeight * triggerFraction;
			const rect = el.getBoundingClientRect();
			if ( rect.top <= thresholdY && rect.bottom >= 0 ) {
				fired = true;
				callback();
				window.removeEventListener( 'scroll', onScroll );
				window.removeEventListener( 'resize', onScroll );
			}
		};
		const onScroll = () => window.requestAnimationFrame( run );
		window.addEventListener( 'scroll', onScroll, { passive: true } );
		window.addEventListener( 'resize', onScroll, { passive: true } );
		onScroll();
	}

	/**
	 * @param {Element} el
	 */
	function initNotationEl( el ) {
		const RN = window.RoughNotation;
		if ( ! RN || typeof RN.annotate !== 'function' ) {
			return;
		}

		const type = el.getAttribute( 'data-type' ) || 'underline';
		const color = el.getAttribute( 'data-color' ) || '';
		const width = el.getAttribute( 'data-width' ) || '1';
		const iterations = el.getAttribute( 'data-iterations' ) || '2';
		const bracketStyle =
			el.getAttribute( 'data-bracket-style' ) || 'left|right';
		const viewport = el.getAttribute( 'data-viewport' );
		const delayRaw = el.getAttribute( 'data-delay' );

		let stroke = parseFloat( width );
		if ( Number.isNaN( stroke ) ) {
			stroke = 1;
		}
		let iter = parseInt( iterations, 10 );
		if ( Number.isNaN( iter ) ) {
			iter = 2;
		}
		const delayMs = parseDelayMs( delayRaw );
		const triggerFraction = viewportOffsetFraction( viewport );

		const annotation = RN.annotate( el, {
			type,
			color,
			strokeWidth: stroke,
			iterations: iter,
			brackets: bracketStyle.split( '|' ),
		} );

		onViewportCross( el, triggerFraction, () => {
			window.setTimeout( () => {
				annotation.show();
			}, delayMs );
		} );
	}

	function initAll() {
		const nodes = document.querySelectorAll( '.dsm-text-notation-middle' );
		if ( ! nodes.length ) {
			return;
		}
		nodes.forEach( initNotationEl );
	}

	function boot() {
		if ( document.fonts && document.fonts.ready ) {
			document.fonts.ready.then( initAll );
			return;
		}
		initAll();
	}

	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', boot );
	} else {
		boot();
	}
} )();
