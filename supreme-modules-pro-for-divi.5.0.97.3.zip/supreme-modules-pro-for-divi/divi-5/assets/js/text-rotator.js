jQuery( function ( $ ) {
	$( '.dsm-rotate-text' ).each( function ( index, item ) {
		let word = $( this ).attr( 'data-word' );
		let animation = $( this ).attr( 'data-animation' );
		let pause = $( this ).attr( 'data-pause' );
		let click = $( this ).attr( 'data-click' );
		let speed = $( this ).attr( 'data-speed' );

		var replace = new ReplaceMe( this, {
			word: word,
			animation: 'animated ' + animation,
			speed: parseFloat( speed, 10 ),
			separator: '|',
			hoverStop: '1' === pause ? true : false,
			clickChange: '1' === click ? true : false,
			loopCount: 'infinite',
			autoRun: false,
			onInit: false,
			onChange: false,
			onComplete: false,
		} );

		var waypointTyped = $( this ).waypoint( {
			handler: function ( direction ) {
				if ( direction === 'down' ) {
					replace.start();
				} else {
					replace.stop();
				}
			},
			offset: '100%',
		} );
	} );
} );
