/**
 * Shared Visual Builder / library-preview module re-init helpers.
 *
 * @package DiviSupreme
 */
( function ( window ) {
	'use strict';

	/**
	 * Divi builder global inits after library HTML is injected (popup-open parity).
	 *
	 * @param {HTMLElement|null|undefined} rootEl Optional subtree that became visible.
	 * @return {void}
	 */
	function dsmKickDiviLibraryModuleScripts( rootEl ) {
		if ( typeof window.jQuery === 'function' ) {
			window.jQuery( window ).trigger( 'resize' );
			if ( rootEl ) {
				window.jQuery( rootEl ).trigger( 'resize' );
			}
		}

		if ( typeof window.et_reinit_waypoint_modules === 'function' ) {
			window.et_reinit_waypoint_modules();
		}

		if ( typeof window.et_pb_reinit_waypoint_modules === 'function' ) {
			window.et_pb_reinit_waypoint_modules();
		}

		if ( typeof window.et_pb_init_modules === 'function' ) {
			window.et_pb_init_modules();
		}

		if ( typeof window.et_process_animation_data === 'function' ) {
			window.et_process_animation_data( true );
		}
	}

	window.dsmKickDiviLibraryModuleScripts = dsmKickDiviLibraryModuleScripts;

	/**
	 * @param {string} eventName
	 * @param {function(HTMLElement): void} handler
	 * @return {void}
	 */
	function bindLibraryReinitEvent( eventName, handler ) {
		window.addEventListener( eventName, function ( event ) {
			var root = event && event.detail ? event.detail.root : null;
			if ( ! root ) {
				return;
			}
			handler( root );
		} );
	}

	/**
	 * Generic boot: run `window[bootName]()` when root contains `selector`.
	 *
	 * @param {string} bootName  Global boot function name.
	 * @param {string} selector  Module root selector scoped to `root`.
	 * @return {void}
	 */
	function registerScopedDocumentBoot( bootName, selector ) {
		var boot = window[ bootName ];
		if ( typeof boot !== 'function' ) {
			return;
		}

		var run = function ( root ) {
			if ( ! root.querySelector( selector ) ) {
				return;
			}
			boot();
		};

		bindLibraryReinitEvent( 'dsm:reinit-library-modules-in-root', run );
		bindLibraryReinitEvent( 'dsm:reinit-carousels-in-root', run );
	}

	registerScopedDocumentBoot( 'dsmImageHoverRevealBoot', '.dsm_image_hover_reveal' );
	registerScopedDocumentBoot( 'dsmSupremeSvgAnimationBoot', '.dsm_svg_animation' );
	registerScopedDocumentBoot( 'dsmInitBeforeAfterImageCompare', '.dsm-before-after-image' );
} )( window );
