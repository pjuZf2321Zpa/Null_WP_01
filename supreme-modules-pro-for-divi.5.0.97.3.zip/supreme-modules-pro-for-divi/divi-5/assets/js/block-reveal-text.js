/**
 * Supreme Block Reveal Text — init RevealFx on `.dsm_block_reveal_text_wrapper.dsm-block-reveal-frontend`.
 *
 * @package DiviSupreme
 */
( function () {
	'use strict';

	/**
	 * Remove server-rendered FOUC guard (inline opacity) after RevealFx reveals content.
	 *
	 * @param {Element | null} root Content root from RevealFx.
	 * @return {void}
	 */
	function clearBlockRevealFePreinit( root ) {
		if ( ! root || ! root.querySelectorAll ) {
			return;
		}
		root.querySelectorAll( '.dsm_block_reveal_fe_preinit' ).forEach( function ( node ) {
			node.classList.remove( 'dsm_block_reveal_fe_preinit' );
			node.style.removeProperty( 'opacity' );
		} );
	}

	/**
	 * Run callback when element enters viewport (Waypoint-compatible offset or IO fallback).
	 *
	 * @param {Element} el       Target element.
	 * @param {string}  offset   Waypoint offset (e.g. `80%`).
	 * @param {function(): void} onEnter Called once.
	 * @return {function(): void} Cleanup (disconnect observer / destroy waypoint).
	 */
	function bindRevealTrigger( el, offset, onEnter ) {
		const runOnce = ( function () {
			let done = false;
			return function () {
				if ( done ) {
					return;
				}
				done = true;
				onEnter();
			};
		} )();

		// Prefer IntersectionObserver: Divi 5 may register `jQuery.fn.waypoint` with a different API than
		// legacy Waypoints 0.x — using it first could throw or never fire, leaving content hidden.
		if ( typeof IntersectionObserver !== 'undefined' ) {
			let rootMargin = '0px 0px -15% 0px';
			const m = String( offset || '' ).match( /^(\d+)%$/ );
			if ( m ) {
				const p = Math.max( 0, Math.min( 100, parseInt( m[ 1 ], 10 ) ) );
				rootMargin = '0px 0px -' + ( 100 - p ) + '% 0px';
			}
			const obs = new IntersectionObserver(
				function ( entries, o ) {
					entries.forEach( function ( e ) {
						if ( e.isIntersecting ) {
							runOnce();
							o.unobserve( e.target );
						}
					} );
				},
				{ root: null, rootMargin: rootMargin, threshold: 0 }
			);
			obs.observe( el );
			return function () {
				obs.disconnect();
			};
		}

		if ( typeof jQuery !== 'undefined' && jQuery.fn.waypoint ) {
			try {
				const $el = jQuery( el );
				$el.waypoint(
					function () {
						runOnce();
						if ( this && typeof this.destroy === 'function' ) {
							this.destroy();
						}
					},
					{
						offset: offset || '80%',
						triggerOnce: true,
					}
				);
				return function () {
					try {
						$el.waypoint( 'destroy' );
					} catch ( err ) {
						/* noop — API/version differences */
					}
				};
			} catch ( e ) {
				/* Fall through to immediate reveal. */
			}
		}

		runOnce();
		return function () {};
	}

	/**
	 * Initialize RevealFx on a single text wrapper (Visual Builder + programmatic use).
	 *
	 * @param {Element|null} wrap Root `.dsm_block_reveal_text_wrapper`.
	 * @return {undefined|function(): void} Cleanup, or undefined if nothing was set up.
	 */
	function initBlockRevealTextWrap( wrap ) {
		if ( ! wrap || wrap.getAttribute( 'data-dsm-block-reveal-init' ) ) {
			return undefined;
		}

		if ( typeof RevealFx === 'undefined' ) {
			wrap
				.querySelectorAll( '.dsm_block_reveal_fe_preinit' )
				.forEach( function ( node ) {
					node.classList.remove( 'dsm_block_reveal_fe_preinit' );
					node.style.removeProperty( 'opacity' );
				} );
			return undefined;
		}

		wrap.setAttribute( 'data-dsm-block-reveal-init', '1' );
		const animation =
			wrap.getAttribute( 'data-dsm-block-reveal-animation' ) || 'lr';
		const delay = wrap.getAttribute( 'data-dsm-block-reveal-delay' ) || '0.1';
		const viewport =
			wrap.getAttribute( 'data-dsm-block-reveal-viewport' ) || '80%';

		const fx = new RevealFx( wrap, {
			revealSettings: {
				delay: delay,
				direction: animation,
				onCover: function ( contentEl ) {
					if ( contentEl && contentEl.style ) {
						contentEl.style.opacity = '1';
					}
					clearBlockRevealFePreinit( contentEl );
				},
			},
		} );

		const stopTrigger = bindRevealTrigger( wrap, viewport, function () {
			if ( fx && typeof fx.reveal === 'function' ) {
				fx.reveal();
			}
		} );

		return function () {
			wrap.removeAttribute( 'data-dsm-block-reveal-init' );
			if ( typeof stopTrigger === 'function' ) {
				stopTrigger();
			}
		};
	}

	function initBlockRevealText() {
		if ( typeof RevealFx === 'undefined' ) {
			document
				.querySelectorAll(
					'.dsm_block_reveal_text_wrapper.dsm-block-reveal-frontend .dsm_block_reveal_fe_preinit'
				)
				.forEach( function ( node ) {
					node.classList.remove( 'dsm_block_reveal_fe_preinit' );
					node.style.removeProperty( 'opacity' );
				} );
			return;
		}

		document
			.querySelectorAll(
				'.dsm_block_reveal_text_wrapper.dsm-block-reveal-frontend:not([data-dsm-block-reveal-init])'
			)
			.forEach( function ( wrap ) {
				initBlockRevealTextWrap( wrap );
			} );
	}

	window.dsmBlockRevealInitTextWrap = initBlockRevealTextWrap;

	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', initBlockRevealText );
	} else {
		initBlockRevealText();
	}
} )();
