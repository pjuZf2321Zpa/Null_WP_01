/**
 * Post Carousel frontend (`dsm/post-carousel`).
 */
( function () {
	'use strict';

	if ( typeof window.dsmRegisterPostBlogCarouselModule !== 'function' ) {
		return;
	}

	window.dsmRegisterPostBlogCarouselModule( {
		rootSelector: '.dsm_post_carousel',
		carouselRootSelector: '.dsm-post-carousel',
		containerSelector: '.swiper-container.dsm-post-carousel-container',
		slideClass: 'dsm-post-carousel-item',
		wrapperClass: 'dsm-post-carousel-wrapper',
		reinitGlobalName: 'dsmReinitPostCarouselsInRoot',
	} );
} )();
