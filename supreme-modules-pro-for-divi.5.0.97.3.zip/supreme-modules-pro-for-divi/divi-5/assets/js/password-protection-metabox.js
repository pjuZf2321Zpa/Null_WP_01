/**
 * Divi Supreme Protection — per-page metabox row UI.
 *
 * @package DiviSupreme
 */
( function () {
	'use strict';

	function ready( fn ) {
		if ( document.readyState !== 'loading' ) {
			fn();
		} else {
			document.addEventListener( 'DOMContentLoaded', fn );
		}
	}

	function syncBypassRolesVisibility() {
		var modeSelect = document.getElementById( 'dsm_pp_page_bypass_mode' );
		var rolesWrap = document.getElementById( 'dsm-pp-page-bypass-roles' );
		if ( ! modeSelect || ! rolesWrap ) {
			return;
		}
		rolesWrap.hidden = modeSelect.value !== 'roles';
	}

	ready( function () {
		var modeSelect = document.getElementById( 'dsm_pp_page_bypass_mode' );
		if ( modeSelect ) {
			modeSelect.addEventListener( 'change', syncBypassRolesVisibility );
			syncBypassRolesVisibility();
		}

		var root = document.getElementById( 'dsm-pp-page-entries' );
		var template = document.getElementById( 'dsm-pp-page-entry-template' );
		if ( ! root || ! template ) {
			return;
		}

		var list = root.querySelector( '.dsm-pp-page-entries__list' );
		var addBtn = root.querySelector( '.dsm-pp-page-entries__add' );
		if ( ! list || ! addBtn ) {
			return;
		}

		var nextIndex = parseInt( root.getAttribute( 'data-next-index' ) || '0', 10 );
		if ( isNaN( nextIndex ) ) {
			nextIndex = list.children.length;
		}

		addBtn.addEventListener( 'click', function ( event ) {
			event.preventDefault();
			var html = template.innerHTML.split( '__INDEX__' ).join( String( nextIndex ) );
			nextIndex += 1;
			root.setAttribute( 'data-next-index', String( nextIndex ) );
			list.insertAdjacentHTML( 'beforeend', html );
		} );

		list.addEventListener( 'click', function ( event ) {
			var target = event.target;
			if ( ! target || ! target.classList || ! target.classList.contains( 'dsm-pp-page-entries__remove' ) ) {
				return;
			}
			event.preventDefault();
			var row = target.closest( '.dsm-pp-page-entry' );
			if ( row ) {
				row.remove();
			}
		} );
	} );
} )();
