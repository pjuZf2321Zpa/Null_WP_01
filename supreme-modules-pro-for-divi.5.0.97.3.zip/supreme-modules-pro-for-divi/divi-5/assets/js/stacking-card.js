class DSMStackingCard {
	/**
	 * @param {HTMLElement} element
	 * @param {object} config
	 */
	constructor( element, config ) {
		this.element = element;
		this.config = config;
		this.cards = this.element.querySelectorAll(
			'.dsm_stacking_card_child'
		);

		this.scrollTriggerInstance = null;
		this.currentDirection = null;

		this.init();
		this.handleResize();
	}

	getResponsiveSetting( setting ) {
		const width = window.innerWidth;

		if ( typeof setting !== 'object' || setting === null ) {
			return setting;
		}

		if ( width <= 472 ) {
			if ( setting.phone !== undefined && setting.phone !== '' )
				return setting.phone;

			if ( setting.tablet !== undefined && setting.tablet !== '' )
				return setting.tablet;
		} else if ( width <= 908 ) {
			if ( setting.tablet !== undefined && setting.tablet !== '' )
				return setting.tablet;
		}

		return setting.desktop !== undefined ? setting.desktop : setting;
	}

	getCurrentDirection() {
		const dir = this.getResponsiveSetting( this.config.direction );
		return dir || 'vertical';
	}

	getAnimationProperties( index ) {
		const animationType = this.config.animation_type || 'none';
		switch ( animationType ) {
			case 'fade':
				return {
					initial: { opacity: index === 0 ? 1 : 0 },
					animate: { opacity: 1 },
				};
			case 'scale':
				return {
					initial: { opacity: 1, scale: 1 },
					animate: { opacity: 1, scale: 1 },
				};
			default:
				return {
					initial: { opacity: 1 },
					animate: { opacity: 1 },
				};
		}
	}

	isScaleStackAnimation() {
		return ( this.config.animation_type || 'none' ) === 'scale';
	}

	/**
	 * Shrink cards already in the stack as a new card lands (depth stack effect).
	 *
	 * @param {object} timeline GSAP timeline
	 * @param {HTMLElement[]} cards
	 * @param {number} activeIndex  Index of the card that just finished flying in
	 * @param {'vertical'|'horizontal'} axis
	 */
	appendScaleDepthTweens( timeline, cards, activeIndex, axis ) {
		if ( ! this.isScaleStackAnimation() || activeIndex < 1 ) {
			return;
		}
		const step = 0.048;
		const minScale = 0.78;
		const tPos = activeIndex * 0.5;
		const origin =
			axis === 'vertical' ? '50% 0%' : '0% 50%';

		for ( let j = 0; j < activeIndex; j++ ) {
			const depth = activeIndex - j;
			const targetScale = Math.max( minScale, 1 - depth * step );
			timeline.to(
				cards[ j ],
				{
					scale: targetScale,
					transformOrigin: origin,
					ease: 'power2.out',
					duration: 0.6,
				},
				tPos
			);
		}
	}

	init() {
		if ( ! this.cards || ! this.cards.length ) return;

		if (
			typeof ScrollTrigger !== 'undefined' &&
			gsap &&
			! gsap.core.globals()[ 'ScrollTrigger' ]
		) {
			gsap.registerPlugin( ScrollTrigger );
		}

		this.element.style.position = this.element.style.position || 'relative';

		this.currentDirection = this.getCurrentDirection();

		if ( this.currentDirection === 'horizontal' ) {
			this.initHorizontal();
		} else {
			this.initVertical();
		}
	}

	destroy() {
		if ( this.scrollTriggerInstance ) {
			this.scrollTriggerInstance.kill();
			this.scrollTriggerInstance = null;
		}

		gsap.set( this.cards, { clearProps: 'all' } );
		gsap.set( this.element, { clearProps: 'all' } );

		const container = this.element.parentElement.parentElement;
		if ( container ) {
			gsap.set( container, { clearProps: 'all' } );
		}
	}

	handleResize() {
		window.addEventListener( 'resize', () => {
			const newDirection = this.getCurrentDirection();

			this.destroy();
			this.init();
		} );
	}

	prepareContainer() {
		const container = this.element.parentElement.parentElement;
		if ( container ) container.style.display = 'block';
	}

	initVertical() {
		this.prepareContainer();
		const cards = Array.from( this.cards );
		const spacing = parseInt( this.config?.stack_spacing || 100, 10 );

		const isStackingDisabled = this.config.disable_stacking_offset === 'on';

		const stackOffset = isStackingDisabled
			? 0
			: parseInt( this.config.stack_offset || 40, 10 );

		const viewportHeight = window.innerHeight;

		const rawStartOffset = this.getResponsiveSetting(
			this.config.start_offset
		);
		const startOffset = Number( rawStartOffset ) || 0;

		const timeline = gsap.timeline();
		const useScaleStack = this.isScaleStackAnimation();

		cards.forEach( ( card, index ) => {
			card.style.width = '100%';
			card.style.position = 'absolute';

			card.style.top = `${ startOffset + stackOffset * index }px`;

			card.style.left = '0';
			card.style.right = '0';
			card.style.margin = '0 auto';
			card.style.zIndex = index;

			const initialY = index === 0 ? 0 : viewportHeight + spacing * index;
			const animationProps = this.getAnimationProperties( index );

			const setProps = {
				y: initialY - stackOffset * index,
				...animationProps.initial,
			};
			if ( useScaleStack ) {
				setProps.transformOrigin = '50% 0%';
				setProps.scale = 1;
			}
			gsap.set( card, setProps );

			if ( index > 0 ) {
				const tPos = index * 0.5;
				timeline.to(
					card,
					{
						y: 0,
						...animationProps.animate,
						ease: 'power2.out',
						duration: 0.6,
					},
					tPos
				);
				this.appendScaleDepthTweens(
					timeline,
					cards,
					index,
					'vertical'
				);
			}
		} );

		const totalScrollHeight = ( cards.length - 1 ) * viewportHeight * 0.6;

		this.scrollTriggerInstance = ScrollTrigger.create( {
			trigger: this.element,
			animation: timeline,
			start: 'top top',
			end: `+=${ totalScrollHeight }`,
			scrub: 0.3,
			pin: true,
			invalidateOnRefresh: true,
		} );
	}

	initHorizontal() {
		this.prepareContainer();
		const cards = Array.from( this.cards );
		const isStackingDisabled = this.config.disable_stacking_offset === 'on';
		const stackOffset = isStackingDisabled
			? 0
			: parseInt( this.config.stack_offset || 40, 10 );
		const viewportWidth = window.innerWidth;
		const offset = 0;

		const timeline = gsap.timeline();
		const cardWidth = cards[ 0 ].offsetWidth;
		const useScaleStack = this.isScaleStackAnimation();

		const horizontalStart = this.getResponsiveSetting(
			this.config.start_horizontal_offset
		);

		cards.forEach( ( card, index ) => {
			card.style.width = `${ cardWidth }px`;
			card.style.position = 'absolute';
			card.style.left = `${ offset + stackOffset * index }px`;

			card.style.top = `${ Number( horizontalStart ) }%`;

			card.style.zIndex = index;

			const initialX = index === 0 ? 0 : viewportWidth - offset;
			const animationProps = this.getAnimationProperties( index );
			const dynamicYPercent =
				Number( this.config.start_horizontal_offset ) === 50 ? -50 : 0;

			const setProps = {
				x: initialX - stackOffset * index,
				yPercent: dynamicYPercent,
				...animationProps.initial,
			};
			if ( useScaleStack ) {
				setProps.transformOrigin = '0% 50%';
				setProps.scale = 1;
			}
			gsap.set( card, setProps );

			if ( index > 0 ) {
				const tPos = index * 0.5;
				timeline.to(
					card,
					{
						x: 0,
						...animationProps.animate,
						ease: 'power2.out',
						duration: 0.6,
					},
					tPos
				);
				this.appendScaleDepthTweens(
					timeline,
					cards,
					index,
					'horizontal'
				);
			}
		} );

		const totalScrollWidth = ( cards.length - 1 ) * viewportWidth * 0.6;

		this.scrollTriggerInstance = ScrollTrigger.create( {
			trigger: this.element,
			animation: timeline,
			start: 'top top',
			end: `+=${ totalScrollWidth }`,
			scrub: 0.3,
			pin: true,
			invalidateOnRefresh: true,
		} );
	}
}

document.addEventListener( 'DOMContentLoaded', function () {
	const containers = document.querySelectorAll(
		'.dsm_stacking_card_container'
	);
	containers.forEach( ( container ) => {
		try {
			const options = JSON.parse( container.dataset.options );
			new DSMStackingCard( container, options );
		} catch ( e ) {
			console.error( 'Error parsing stacking card options', e );
		}
	} );
} );
