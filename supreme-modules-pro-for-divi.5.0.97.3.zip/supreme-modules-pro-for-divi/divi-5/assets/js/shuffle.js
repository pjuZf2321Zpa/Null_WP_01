jQuery( function ( $ ) {
	var shuffleElement = $( '.dsm-shuffle-text' );

	$( shuffleElement ).each( function ( index, value ) {
		var randomText = $( this ).data( 'dsm-shuffle-text' ),
			speed =
				parseFloat( $( this ).data( 'dsm-shuffle-speed' ), 10 ) * 1000,
			duration =
				parseFloat( $( this ).data( 'dsm-shuffle-duration' ), 10 ) *
				1000,
			element = $( this );

		if (
			randomText === undefined ||
			randomText === null ||
			randomText === ''
		) {
			randomText =
				'AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz~!@#$%^&*()-+=[]{}|;:,./<>?';
		}
		let shuffleDOM = baffle( this, {
			characters: randomText,
			speed: speed,
		} );
		$( this ).waypoint(
			function () {
				shuffleDOM.start().reveal( 0, duration );
			},
			{
				offset: '100%',
			}
		);
	} );
} );
