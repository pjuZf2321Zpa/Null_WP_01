const socialShareButtons = document.querySelectorAll(
	'.dsm-social-share-button-inner-wrapper'
);
let windowFeatures = 'left=500,top=250,width=600,height=300';

socialShareButtons.forEach( ( button ) => {
	button.addEventListener( 'click', () => {
		if ( button.classList.contains( 'dsm-print' ) ) {
			print();
		} else if ( button.classList.contains( 'dsm-email' ) ) {
			window.open( button.dataset.share_url );
		} else {
			window.open(
				button.dataset.share_url,
				'mozillaWindow',
				windowFeatures
			);
		}
	} );
} );
