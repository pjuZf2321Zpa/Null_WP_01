jQuery( function ( $ ) {
	function dsm_icon_list_init_tooltip() {
		dsm_icon_list_init( $( this ) );
	}

	window.dsm_icon_list_init = function ( $this ) {
		$( '.dsm_icon_list_tooltip.dsm-frontend' ).each( function () {
			let placement = $( this ).data( 'dsm-tooltip-placement' );
			const orderClass =
				$( this ).attr( 'data-order-class' ) ||
				$( this ).data( 'orderClass' ) ||
				'';

			tippy( this, {
				appendTo: document.body,
				duration: 300,
				maxWidth: 'none',
				delay: [ 50, 50 ],
				trigger: 'mouseenter focus',
				interactive: true,
				animation: 'fade',
				distance: 10,
				zIndex: 99999,
				placement: placement,
				content: this.nextElementSibling,
				allowHTML: true,
				onCreate( instance ) {
					const tooltipId = instance.reference.getAttribute(
						'data-dsm-icon-list-tooltip-id'
					);
					if ( tooltipId ) {
						instance.popper.setAttribute(
							'data-dsm-icon-list-tooltip-id',
							tooltipId
						);
					}
					instance.popper.classList.add( 'tippy-popper' );
					instance.popper.firstChild.classList.add( 'tippy-tooltip' );
					instance.popper.firstChild.classList.add(
						'dsm_icon_list_child_tooltip_wrapper'
					);
					if ( orderClass ) {
						instance.popper.firstChild.classList.add( orderClass );
					}
				},
				onShow( instance ) {},
			} );
		} );
	};

	dsm_icon_list_init_tooltip();
} );
