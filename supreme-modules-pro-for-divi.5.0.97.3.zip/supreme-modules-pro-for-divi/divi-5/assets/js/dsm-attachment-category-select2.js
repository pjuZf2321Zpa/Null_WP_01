/**
 * Select2 multi-select for DSM attachment categories in the Media Library.
 *
 * Attachment details markup is injected after DOM ready (upload.php sidebar
 * and the media modal), so we observe the DOM and hook wp.media views.
 *
 * @package DiviSupreme
 */

( function ( $ ) {
	'use strict';

	let initScheduled = false;

	/**
	 * @return {boolean}
	 */
	function select2Ready() {
		return typeof $.fn.select2 === 'function';
	}

	/**
	 * Locate the native WP compat text field for this taxonomy.
	 *
	 * AttachmentCompat.serializeArray() last-value-wins on `name="…[]"`.
	 * Selected slugs are copied into this single-value field instead.
	 *
	 * @param {JQuery} $select Select2 element.
	 * @return {{ $root: JQuery, $input: JQuery }}
	 */
	function findNativeTermControl( $select ) {
		const $scope = $select.closest(
			'form.compat-item, form#post, .attachment-details, .media-sidebar, .compat-attachment-fields'
		);
		let $root = $scope.find( '.compat-field-dsm-attachment-category' );

		if ( ! $root.length ) {
			$root = $select
				.closest( 'form' )
				.find( '.compat-field-dsm-attachment-category' );
		}

		return {
			$root: $root,
			$input: $root.find( 'input[type="text"], textarea' ),
		};
	}

	/**
	 * Write Select2 slugs into the native comma-separated compat field.
	 *
	 * @param {JQuery} $select Select2 element.
	 * @param {JQuery} $input  Native taxonomy text input.
	 * @return {void}
	 */
	function syncNativeTermControl( $select, $input ) {
		if ( ! $input.length ) {
			return;
		}

		const newValue = $select.val() || [];

		$input.val(
			Array.isArray( newValue ) ? newValue.join( ',' ) : newValue
		);
	}

	/**
	 * Usable vertical band for the body-attached dropdown.
	 *
	 * Viewport space below a media-sidebar field is often large (dark overlay
	 * under the modal). The real floor is the media toolbar / VB footer.
	 *
	 * @param {JQuery} $select Select2 element.
	 * @return {{ top: number, bottom: number }}
	 */
	function getDsmCategoryDropdownBand( $select ) {
		const pad = 8;
		let top = pad;
		let bottom = window.innerHeight - pad;
		const $frame = $select.closest( '.media-modal, .media-frame' );

		if ( $frame.length ) {
			const contentEl =
				$frame.find( '.media-modal-content' ).get( 0 ) || $frame.get( 0 );
			const contentRect = contentEl.getBoundingClientRect();

			top = Math.max( top, contentRect.top + pad );
			bottom = Math.min( bottom, contentRect.bottom - pad );

			const toolbarEl =
				$frame.find( '.media-frame-toolbar .media-toolbar:visible' ).get( 0 ) ||
				$frame.find( '.media-frame-toolbar:visible' ).get( 0 );

			if ( toolbarEl ) {
				const toolbarRect = toolbarEl.getBoundingClientRect();

				if ( toolbarRect.height > 0 ) {
					bottom = Math.min( bottom, toolbarRect.top - 4 );
				}
			}
		}

		return { top: top, bottom: bottom };
	}

	/**
	 * Pin the body-attached dropdown to the field using viewport coordinates.
	 *
	 * Select2's AttachBody uses `offset()` + `position:absolute`. That breaks
	 * when a Visual Builder ancestor has `transform`, and clips the list when
	 * the dropdown lives inside the field wrap / media sidebar.
	 *
	 * Size to the list (capped), then hug the field. A fixed 240px panel
	 * leaves empty space and makes an above-flip look detached. Inner
	 * `.select2-dropdown` is `position:relative` so `bottom` can grow up
	 * without covering the trigger.
	 *
	 * @param {JQuery} $select Select2 element.
	 * @return {void}
	 */
	function pinDsmCategoryDropdown( $select ) {
		const instance = $select.data( 'select2' );

		if ( ! instance || ! instance.dropdown || ! instance.$selection ) {
			return;
		}

		const $selection = instance.$selection;
		const $dropdownContainer = instance.dropdown.$dropdownContainer;

		if ( ! $selection.length || ! $dropdownContainer || ! $dropdownContainer.length ) {
			return;
		}

		const $dropdown = $dropdownContainer.find( '.select2-dropdown' );
		const $search = $dropdownContainer.find( '.select2-search--dropdown' );
		const $results = $dropdownContainer.find( '.select2-results__options' );
		const rect = $selection[ 0 ].getBoundingClientRect();
		const band = getDsmCategoryDropdownBand( $select );
		const gap = 4;
		const preferred = 240;
		const minHeight = 80;
		const width = Math.max( rect.width, 160 );
		const spaceBelow = band.bottom - rect.bottom - gap;
		const spaceAbove = rect.top - band.top - gap;

		$dropdownContainer.addClass( 'dsm-attachment-category-dropdown-container' );
		$dropdown.addClass( 'dsm-attachment-category-dropdown' );
		$dropdownContainer.css( {
			position: 'fixed',
			left: rect.left + 'px',
			width: width + 'px',
			height: 'auto',
			maxHeight: 'none',
			zIndex: 10000050,
		} );
		$dropdown.css( {
			position: 'relative',
			left: 0,
			top: 0,
			width: '100%',
			height: 'auto',
			zIndex: 10000050,
		} );
		$results.css( {
			maxHeight: preferred + 'px',
			overflowY: 'auto',
		} );

		const contentHeight = Math.max(
			minHeight,
			Math.min( preferred, $dropdown.outerHeight() || preferred )
		);
		const openAbove =
			spaceBelow < contentHeight && spaceAbove > spaceBelow;
		const available = Math.max(
			minHeight,
			openAbove ? spaceAbove : spaceBelow
		);
		const height = Math.min( contentHeight, available );
		const searchHeight = $search.outerHeight() || 0;

		$dropdown
			.toggleClass( 'select2-dropdown--above', openAbove )
			.toggleClass( 'select2-dropdown--below', ! openAbove );

		if ( openAbove ) {
			$dropdownContainer.css( {
				top: 'auto',
				bottom: window.innerHeight - rect.top + gap + 'px',
				height: 'auto',
				maxHeight: height + 'px',
			} );
		} else {
			$dropdownContainer.css( {
				top: rect.bottom + gap + 'px',
				bottom: 'auto',
				height: 'auto',
				maxHeight: height + 'px',
			} );
		}

		$results.css( {
			maxHeight: Math.max( 40, height - searchHeight ) + 'px',
			overflowY: 'auto',
		} );
	}

	/**
	 * @param {JQuery} $select Select2 element.
	 * @return {void}
	 */
	function bindDsmCategoryDropdownPin( $select ) {
		const instance = $select.data( 'select2' );
		const pin = function () {
			pinDsmCategoryDropdown( $select );
		};
		const $scrollParents = $select.closest(
			'.media-sidebar, .media-frame-content, .attachment-details, .compat-attachment-fields'
		);

		if ( instance && instance.dropdown && ! instance.dropdown.__dsmAcPinWrapped ) {
			[ '_positionDropdown', '_resizeDropdown' ].forEach( function ( method ) {
				if ( 'function' !== typeof instance.dropdown[ method ] ) {
					return;
				}

				const original = instance.dropdown[ method ].bind( instance.dropdown );

				instance.dropdown[ method ] = function () {
					original();
					pin();
				};
			} );
			instance.dropdown.__dsmAcPinWrapped = true;
		}

		$select
			.off( '.dsmAcPin' )
			.on( 'select2:open.dsmAcPin', function () {
				const $openDropdown = instance && instance.dropdown
					? instance.dropdown.$dropdown
					: $();
				const $openContainer = instance && instance.dropdown
					? instance.dropdown.$dropdownContainer
					: $();

				$openContainer.addClass( 'dsm-attachment-category-dropdown-container' );
				$openDropdown.addClass( 'dsm-attachment-category-dropdown' );
				window.requestAnimationFrame( pin );
				window.setTimeout( pin, 0 );
				window.setTimeout( pin, 50 );
				$( window ).on( 'scroll.dsmAcPin resize.dsmAcPin', pin );
				$scrollParents.on( 'scroll.dsmAcPin', pin );
			} )
			.on( 'select2:close.dsmAcPin', function () {
				$( window ).off( '.dsmAcPin' );
				$scrollParents.off( 'scroll.dsmAcPin' );
			} );
	}

	/**
	 * Initialize Select2 on DSM attachment category pickers.
	 *
	 * @return {void}
	 */
	function initDsmAttachmentCategorySelect() {
		if ( ! select2Ready() ) {
			scheduleInit();
			return;
		}

		$( 'select.dsm-attachment-categories-select' ).each( function () {
			const $select = $( this );

			if ( $select.hasClass( 'select2-hidden-accessible' ) ) {
				return;
			}

			const native = findNativeTermControl( $select );
			const $actualTermControlRoot = native.$root;
			const $actualTermControl = native.$input;

			$select.select2( {
				width: '100%',
				placeholder: $select.data( 'placeholder' ) || '',
				allowClear: true,
				closeOnSelect: false,
				dropdownCssClass: 'dsm-attachment-category-dropdown',
				dropdownParent: $( document.body ),
			} );

			bindDsmCategoryDropdownPin( $select );
			$select.select2( 'close' );

			syncNativeTermControl( $select, $actualTermControl );

			$select.off( 'change.dsmAttachmentCategory' ).on(
				'change.dsmAttachmentCategory',
				function () {
					syncNativeTermControl( $( this ), $actualTermControl );
				}
			);

			if ( $actualTermControlRoot.length ) {
				$actualTermControlRoot.hide();
			}
		} );
	}

	/**
	 * @return {void}
	 */
	function scheduleInit() {
		if ( initScheduled ) {
			return;
		}

		initScheduled = true;

		window.requestAnimationFrame( function () {
			initScheduled = false;
			initDsmAttachmentCategorySelect();
		} );
	}

	window.dsmInitAttachmentCategorySelect = initDsmAttachmentCategorySelect;

	/**
	 * @param {string}   viewKey  Key on wp.media.view.
	 * @param {Function} BaseView Constructor to extend.
	 * @return {void}
	 */
	function patchMediaViewRender( viewKey, BaseView ) {
		if ( ! BaseView || BaseView.__dsmAttachmentCategoryPatched ) {
			return;
		}

		wp.media.view[ viewKey ] = BaseView.extend( {
			render() {
				const rendered = BaseView.prototype.render.apply(
					this,
					arguments
				);
				scheduleInit();
				return rendered;
			},
		} );

		wp.media.view[ viewKey ].__dsmAttachmentCategoryPatched = true;
	}

	/**
	 * @return {void}
	 */
	function extendWpMediaViews() {
		if ( typeof wp === 'undefined' || ! wp.media || ! wp.media.view ) {
			return;
		}

		patchMediaViewRender(
			'AttachmentCompat',
			wp.media.view.AttachmentCompat
		);
	}

	$( document ).ready( function () {
		scheduleInit();
		extendWpMediaViews();
	} );

	$( document ).on( 'submit', 'form#post, form.compat-item', function () {
		$( this )
			.find( 'select.dsm-attachment-categories-select' )
			.each( function () {
				const native = findNativeTermControl( $( this ) );
				syncNativeTermControl( $( this ), native.$input );
			} );
	} );

	$( document ).ajaxComplete( function () {
		scheduleInit();
	} );

	$( document ).on(
		'click',
		'.attachment, .edit-attachment',
		function () {
			window.setTimeout( scheduleInit, 0 );
		}
	);

	if ( typeof MutationObserver !== 'undefined' && document.body ) {
		const observer = new MutationObserver( function ( mutations ) {
			for ( const mutation of mutations ) {
				if ( mutation.addedNodes && mutation.addedNodes.length ) {
					scheduleInit();
					break;
				}
			}
		} );

		observer.observe( document.body, {
			childList: true,
			subtree: true,
		} );
	}
}( jQuery ) );
