/**
 * Supreme Marquee frontend runtime (vanilla IIFE).
 *
 * Keep in sync with `packages/module-library/marquee/marquee-runtime.js`.
 *
 * @package DiviSupreme
 */
( function () {
	'use strict';

	var SOURCE_SEL = '.dsm_marquee_list:not([aria-hidden="true"])';
	var CLONE_SEL = '.dsm_marquee_list[aria-hidden="true"]';
	var VIEWPORT_SEL = '.dsm_marquee_viewport';
	var TRACK_SEL = '.dsm_marquee_track';

	function isVertical( root ) {
		return (
			root.classList.contains( 'dsm_marquee_dir_up' ) ||
			root.classList.contains( 'dsm_marquee_dir_down' )
		);
	}

	function readAttr( root, name ) {
		var viewport = root.querySelector( VIEWPORT_SEL );
		return (
			root.getAttribute( name ) ||
			( viewport ? viewport.getAttribute( name ) : '' ) ||
			''
		);
	}

	function getSpeedPxPerSec( root ) {
		var desktop = parseFloat( readAttr( root, 'data-dsm-marquee-speed' ) );
		var tablet = parseFloat(
			readAttr( root, 'data-dsm-marquee-speed-tablet' )
		);
		var phone = parseFloat(
			readAttr( root, 'data-dsm-marquee-speed-phone' )
		);
		var speed = Number.isFinite( desktop ) && desktop > 0 ? desktop : 40;

		if (
			window.matchMedia &&
			window.matchMedia( '(max-width: 767px)' ).matches &&
			Number.isFinite( phone ) &&
			phone > 0
		) {
			speed = phone;
		} else if (
			window.matchMedia &&
			window.matchMedia( '(max-width: 980px)' ).matches &&
			Number.isFinite( tablet ) &&
			tablet > 0
		) {
			speed = tablet;
		}

		return speed;
	}

	function measureSize( el, vertical ) {
		return vertical ? el.scrollHeight : el.scrollWidth;
	}

	function measureFlexSeamGap( el, vertical ) {
		var style;
		var raw;
		var value;

		if ( ! el || typeof window.getComputedStyle !== 'function' ) {
			return 0;
		}

		style = window.getComputedStyle( el );
		raw = vertical
			? style.rowGap || style.gap
			: style.columnGap || style.gap;

		if ( ! raw || 'normal' === raw ) {
			return 0;
		}

		value = parseFloat( raw );

		return Number.isFinite( value ) ? value : 0;
	}

	function applyAutoViewportHeight( root, viewport, source ) {
		var mode = readAttr( root, 'data-dsm-marquee-height' ) || 'auto';
		var items;
		var max = 0;
		var next;

		if ( ! isVertical( root ) || 'auto' !== mode ) {
			if ( viewport.style.height ) {
				viewport.style.removeProperty( 'height' );
			}
			return;
		}

		items = source.querySelectorAll( '.dsm_marquee_child' );
		items.forEach( function ( el ) {
			var height = el.getBoundingClientRect().height;
			if ( height > max ) {
				max = height;
			}
		} );

		if ( max < 1 && source.firstElementChild ) {
			max = source.firstElementChild.getBoundingClientRect().height;
		}

		if ( max >= 1 ) {
			next = Math.ceil( max ) + 'px';
			if ( viewport.style.height !== next ) {
				viewport.style.height = next;
			}
		}
	}

	function injectSeparators( root, source ) {
		var type = readAttr( root, 'data-dsm-marquee-sep' ) || 'none';
		var text;

		source.querySelectorAll( '.dsm_marquee_sep' ).forEach( function ( node ) {
			node.remove();
		} );

		if ( [ 'dot', 'icon', 'text' ].indexOf( type ) === -1 ) {
			return;
		}

		text =
			'dot' === type
				? '·'
				: readAttr( root, 'data-dsm-marquee-sep-text' ) || '·';

		source.querySelectorAll( '.dsm_marquee_child' ).forEach( function ( item ) {
			var sep = document.createElement( 'li' );
			var mark;
			sep.className = 'dsm_marquee_sep';
			sep.setAttribute( 'aria-hidden', 'true' );

			if ( 'icon' === type ) {
				mark = document.createElement( 'span' );
				mark.className = 'dsm_marquee_sep_icon';
				mark.setAttribute( 'aria-hidden', 'true' );
			} else {
				mark = document.createElement( 'span' );
				mark.className = 'dsm_marquee_sep_text';
				mark.textContent = text;
			}

			sep.appendChild( mark );
			item.after( sep );
		} );
	}

	function neededCloneCount( sourceSize, viewportSize ) {
		var clones = 0;

		while ( ( clones + 1 ) * sourceSize < 2 * Math.max( viewportSize, 1 ) ) {
			clones += 1;
		}

		return Math.max( clones, 1 );
	}

	function sourceItemCount( source ) {
		var count = 0;
		var index;

		for ( index = 0; index < source.children.length; index += 1 ) {
			if (
				source.children[ index ].classList.contains(
					'dsm_marquee_child'
				) ||
				source.children[ index ].classList.contains( 'dsm_marquee_sep' )
			) {
				count += 1;
			}
		}

		return count;
	}

	function setupViewport( root, viewport, track, source, measuredSourceSize ) {
		var vertical;
		var sourceSize;
		var viewportSize;
		var clones;
		var clone;
		var pxPerSec;
		var duration;
		var distanceValue;
		var durationValue;

		applyAutoViewportHeight( root, viewport, source );

		vertical = isVertical( root );
		sourceSize =
			'number' === typeof measuredSourceSize && measuredSourceSize > 0
				? measuredSourceSize
				: measureSize( source, vertical ) +
					measureFlexSeamGap( track, vertical );
		viewportSize = vertical
			? viewport.clientHeight
			: viewport.clientWidth;

		if ( sourceSize < 1 ) {
			track.style.removeProperty( '--dsm-marquee-distance' );
			track.style.removeProperty( '--dsm-marquee-duration' );
			return;
		}

		clones = 0;
		while ( ( clones + 1 ) * sourceSize < 2 * Math.max( viewportSize, 1 ) ) {
			clone = source.cloneNode( true );
			clone.setAttribute( 'aria-hidden', 'true' );
			track.appendChild( clone );
			clones += 1;
		}

		if ( 0 === clones ) {
			clone = source.cloneNode( true );
			clone.setAttribute( 'aria-hidden', 'true' );
			track.appendChild( clone );
		}

		pxPerSec = getSpeedPxPerSec( root );
		duration = sourceSize / Math.max( pxPerSec, 1 );
		distanceValue = sourceSize + 'px';
		durationValue = duration + 's';

		if (
			track.style.getPropertyValue( '--dsm-marquee-distance' ) !==
			distanceValue
		) {
			track.style.setProperty( '--dsm-marquee-distance', distanceValue );
		}
		if (
			track.style.getPropertyValue( '--dsm-marquee-duration' ) !==
			durationValue
		) {
			track.style.setProperty( '--dsm-marquee-duration', durationValue );
		}
	}

	function setupMarquee( root ) {
		var viewports;
		var primary;
		var primaryTrack;
		var primarySource;
		var vertical;
		var sourceSize;
		var viewportSize;
		var pxPerSec;
		var clonesNeeded;
		var signature;
		var layoutMatches;

		if ( ! root || ! root.querySelector ) {
			return;
		}

		root.setAttribute( 'data-dsm-marquee-mutating', 'true' );

		viewports = root.querySelectorAll( VIEWPORT_SEL );
		primary = viewports[ 0 ];
		if ( ! primary ) {
			root.removeAttribute( 'data-dsm-marquee-mutating' );
			return;
		}

		primaryTrack = primary.querySelector( TRACK_SEL );
		primarySource = primary.querySelector( SOURCE_SEL );

		if ( ! primaryTrack || ! primarySource ) {
			root.removeAttribute( 'data-dsm-marquee-mutating' );
			return;
		}

		injectSeparators( root, primarySource );

		vertical = isVertical( root );
		sourceSize =
			measureSize( primarySource, vertical ) +
			measureFlexSeamGap( primaryTrack, vertical );
		viewportSize = vertical ? primary.clientHeight : primary.clientWidth;
		pxPerSec = getSpeedPxPerSec( root );
		clonesNeeded =
			sourceSize >= 1 ? neededCloneCount( sourceSize, viewportSize ) : 0;
		signature = [
			Math.round( sourceSize ),
			Math.round( viewportSize ),
			pxPerSec,
			clonesNeeded,
		].join( '|' );

		viewports.forEach( function ( viewport, index ) {
			var source;

			if ( 0 === index ) {
				return;
			}

			source = viewport.querySelector( SOURCE_SEL );
			if ( ! source ) {
				return;
			}

			if (
				sourceItemCount( source ) !== sourceItemCount( primarySource )
			) {
				source.innerHTML = primarySource.innerHTML;
			}
		} );

		layoutMatches = Array.prototype.every.call(
			viewports,
			function ( viewport ) {
				var track = viewport.querySelector( TRACK_SEL );
				var clones = viewport.querySelectorAll( CLONE_SEL ).length;
				var distance = track
					? parseFloat(
							track.style.getPropertyValue(
								'--dsm-marquee-distance'
							)
					  )
					: 0;

				return (
					clones >= clonesNeeded &&
					Number.isFinite( distance ) &&
					Math.abs( distance - sourceSize ) < 1
				);
			}
		);

		if (
			layoutMatches &&
			root.getAttribute( 'data-dsm-marquee-sig' ) === signature
		) {
			root.removeAttribute( 'data-dsm-marquee-mutating' );
			return;
		}

		viewports.forEach( function ( viewport ) {
			viewport.querySelectorAll( CLONE_SEL ).forEach( function ( node ) {
				node.remove();
			} );
		} );

		viewports.forEach( function ( viewport ) {
			var track = viewport.querySelector( TRACK_SEL );
			var source = viewport.querySelector( SOURCE_SEL );
			if ( ! track || ! source ) {
				return;
			}
			setupViewport( root, viewport, track, source, sourceSize );
		} );

		root.setAttribute( 'data-dsm-marquee-sig', signature );

		window.requestAnimationFrame( function () {
			root.removeAttribute( 'data-dsm-marquee-mutating' );
		} );
	}

	function bindMarquee( root ) {
		var rafId = 0;
		var source;
		var viewport;
		var mutationObserver;
		var resizeObserver;
		var intersectionObserver;
		var pauseOffscreen;
		var userPaused;
		var control;

		if ( ! root || root.getAttribute( 'data-dsm-marquee-bound' ) === 'true' ) {
			return;
		}

		root.setAttribute( 'data-dsm-marquee-bound', 'true' );

		function schedule() {
			if ( rafId ) {
				return;
			}
			rafId = window.requestAnimationFrame( function () {
				rafId = 0;
				setupMarquee( root );
			} );
		}

		function gatedSchedule() {
			if ( root.getAttribute( 'data-dsm-marquee-mutating' ) === 'true' ) {
				return;
			}
			schedule();
		}

		setupMarquee( root );

		source = root.querySelector( SOURCE_SEL );
		viewport = root.querySelector( VIEWPORT_SEL );

		if ( typeof MutationObserver === 'function' && source ) {
			mutationObserver = new MutationObserver( gatedSchedule );
			mutationObserver.observe( source, {
				childList: true,
				subtree: true,
				characterData: true,
			} );
		}

		if ( typeof ResizeObserver === 'function' ) {
			resizeObserver = new ResizeObserver( gatedSchedule );
			resizeObserver.observe( root );
			if ( viewport ) {
				resizeObserver.observe( viewport );
			}
			if ( source ) {
				resizeObserver.observe( source );
			}
		}

		window.addEventListener( 'resize', gatedSchedule );
		root.addEventListener( 'load', gatedSchedule, true );
		root.addEventListener( 'error', gatedSchedule, true );

		pauseOffscreen =
			'off' !== readAttr( root, 'data-dsm-marquee-pause-offscreen' );

		userPaused =
			root.getAttribute( 'data-dsm-marquee-user-paused' ) === 'true';
		control = root.querySelector( '.dsm_marquee_control' );

		function syncControl() {
			var pauseLabel;
			var playLabel;
			if ( ! control ) {
				return;
			}
			pauseLabel =
				control.getAttribute( 'data-dsm-marquee-label-pause' ) ||
				'Pause marquee';
			playLabel =
				control.getAttribute( 'data-dsm-marquee-label-play' ) ||
				'Play marquee';
			control.setAttribute(
				'aria-pressed',
				userPaused ? 'true' : 'false'
			);
			control.setAttribute(
				'aria-label',
				userPaused ? playLabel : pauseLabel
			);
		}

		function onControlClick( event ) {
			event.preventDefault();
			userPaused = ! userPaused;
			if ( userPaused ) {
				root.setAttribute( 'data-dsm-marquee-user-paused', 'true' );
				root.setAttribute( 'data-dsm-marquee-paused', 'true' );
			} else {
				root.removeAttribute( 'data-dsm-marquee-user-paused' );
				root.removeAttribute( 'data-dsm-marquee-paused' );
			}
			syncControl();
		}

		if ( control ) {
			control.addEventListener( 'click', onControlClick );
			syncControl();
		}

		if (
			pauseOffscreen &&
			typeof IntersectionObserver === 'function'
		) {
			intersectionObserver = new IntersectionObserver(
				function ( entries ) {
					entries.forEach( function ( entry ) {
						if ( entry.target !== root ) {
							return;
						}
						if ( entry.isIntersecting ) {
							if ( ! userPaused ) {
								root.removeAttribute( 'data-dsm-marquee-paused' );
							}
						} else {
							root.setAttribute(
								'data-dsm-marquee-paused',
								'true'
							);
						}
					} );
				},
				{ threshold: 0 }
			);
			intersectionObserver.observe( root );
		}
	}

	function initAll() {
		document.querySelectorAll( '.dsm_marquee' ).forEach( bindMarquee );
	}

	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', initAll );
	} else {
		initAll();
	}

	document.addEventListener( 'divi-supreme-reinit', initAll );
} )();
