( function ( $ ) {
	'use strict';

	/**
	 * Detect mobile UA (matches legacy script; used only for "disable on mobile").
	 *
	 * @return {boolean}
	 */
	function dsmTiltIsMobileUa() {
		return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(
			navigator.userAgent || ''
		);
	}

	/**
	 * Initialize VanillaTilt on Supreme Tilt Image wrappers (D5 + D4 markup).
	 *
	 * @return {void}
	 */
	function dsmInitSupremeTiltImage() {
		if ( typeof VanillaTilt === 'undefined' || ! VanillaTilt.init ) {
			return;
		}

		var mobileUa = dsmTiltIsMobileUa();

		$( '.dsm-tilt-image-wrapper[data-tilt]' ).each( function () {
			var el = this;
			// Use the attribute string, not jQuery .data() (camelCase cache can mismatch).
			var mobileDisable = el.getAttribute( 'data-tilt-mobile-disable' );

			if ( mobileUa && mobileDisable === 'on' ) {
				if ( el.vanillaTilt ) {
					el.vanillaTilt.destroy();
				}
				return;
			}

			VanillaTilt.init( el );
		} );
	}

	window.dsmInitSupremeTiltImage = dsmInitSupremeTiltImage;

	$( dsmInitSupremeTiltImage );
	$( window ).on( 'load', dsmInitSupremeTiltImage );

	// Divi classic / partial refresh after AJAX (if present).
	$( window ).on( 'et_pb_after_init_modules', dsmInitSupremeTiltImage );
} )( jQuery );
