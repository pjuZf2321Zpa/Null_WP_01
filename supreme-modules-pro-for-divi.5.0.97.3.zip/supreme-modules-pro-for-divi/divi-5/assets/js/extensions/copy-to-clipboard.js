/**
 * Copy to Clipboard — bind per-field targets → clipboard + Tippy “Copied” feedback.
 *
 * Payload: `data-dsm-copy-to-clipboard-entries` (legacy `data-dsm-click-to-copy-entries` still read).
 *
 * @package DiviSupreme
 */
( function () {
	'use strict';

	if (
		! document.getElementById( 'dsm-copy-to-clipboard-style' ) &&
		! document.getElementById( 'dsm-click-to-copy-style' )
	) {
		var style = document.createElement( 'style' );
		style.id = 'dsm-copy-to-clipboard-style';
		style.textContent =
			'.dsm-click-to-copy-trigger,.dsm-copy-to-clipboard-trigger{cursor:pointer;}' +
			'.dsm-ctc-copied-tip{display:inline-flex;align-items:center;gap:6px;}' +
			'.dsm-ctc-copied-tip .dsm-ctc-copied-icon,' +
			'.dsm-ctc-copied-tip .et-pb-icon,' +
			'.dsm-ctc-copied-tip .dsm-native-icon-glyph{font-size:1em;line-height:1;display:inline-flex;align-items:center;}' +
			'.dsm-ctc-copied-tip .dsm-ctc-copied-label{line-height:1.2;}' +
			'.dsm-ctc-copied-tip .dsm-native-icon-glyph{speak:none;-webkit-font-smoothing:antialiased;}' +
			/* Copy-affordance badge (beside trigger text — not the success tip icon). */ +
			'.dsm-click-to-copy-trigger .dsm-ctc-copy-badge,.dsm-copy-to-clipboard-trigger .dsm-ctc-copy-badge{display:inline-flex;align-items:center;justify-content:center;line-height:1;vertical-align:middle;pointer-events:none;user-select:none;color:var(--dsm-ctc-badge-color,currentColor);font-size:var(--dsm-ctc-badge-size,14px);}' +
			'.dsm-click-to-copy-trigger .dsm-ctc-copy-badge .et-pb-icon,' +
			'.dsm-click-to-copy-trigger .dsm-ctc-copy-badge .dsm-native-icon-glyph,' +
			'.dsm-click-to-copy-trigger .dsm-ctc-copy-badge .dsm-ctc-copy-badge__glyph,' +
			'.dsm-click-to-copy-trigger .dsm-ctc-copy-badge .dsm-webfont-icon-glyph,' +
			'.dsm-copy-to-clipboard-trigger .dsm-ctc-copy-badge .et-pb-icon,' +
			'.dsm-copy-to-clipboard-trigger .dsm-ctc-copy-badge .dsm-native-icon-glyph,' +
			'.dsm-copy-to-clipboard-trigger .dsm-ctc-copy-badge .dsm-ctc-copy-badge__glyph,' +
			'.dsm-copy-to-clipboard-trigger .dsm-ctc-copy-badge .dsm-webfont-icon-glyph{font-size:1em;line-height:1;color:var(--dsm-ctc-badge-color,inherit)!important;fill:currentColor;}' +
			'.dsm-click-to-copy-trigger .dsm-ctc-copy-badge--after,.dsm-copy-to-clipboard-trigger .dsm-ctc-copy-badge--after{margin-inline-start:var(--dsm-ctc-badge-gap,6px);}' +
			'.dsm-click-to-copy-trigger .dsm-ctc-copy-badge--before,.dsm-copy-to-clipboard-trigger .dsm-ctc-copy-badge--before{margin-inline-end:var(--dsm-ctc-badge-gap,6px);}' +
			/* Tippy arrow (explicit — do not rely solely on tippy.js inject). */ +
			'.tippy-box.dsm-ctc-tippy{position:relative;outline:0;}' +
			'.tippy-box.dsm-ctc-tippy>.tippy-arrow{width:16px;height:16px;color:var(--dsm-ctc-tip-bg,#333);}' +
			'.tippy-box.dsm-ctc-tippy>.tippy-arrow::before{content:"";position:absolute;border-color:transparent;border-style:solid;}' +
			'.tippy-box.dsm-ctc-tippy[data-placement^="top"]>.tippy-arrow{bottom:0;}' +
			'.tippy-box.dsm-ctc-tippy[data-placement^="top"]>.tippy-arrow::before{bottom:-7px;left:0;border-width:8px 8px 0;border-top-color:var(--dsm-ctc-tip-bg,currentColor);}' +
			'.tippy-box.dsm-ctc-tippy[data-placement^="bottom"]>.tippy-arrow{top:0;}' +
			'.tippy-box.dsm-ctc-tippy[data-placement^="bottom"]>.tippy-arrow::before{top:-7px;left:0;border-width:0 8px 8px;border-bottom-color:var(--dsm-ctc-tip-bg,currentColor);}' +
			'.tippy-box.dsm-ctc-tippy[data-placement^="left"]>.tippy-arrow{right:0;}' +
			'.tippy-box.dsm-ctc-tippy[data-placement^="left"]>.tippy-arrow::before{right:-7px;border-width:8px 0 8px 8px;border-left-color:var(--dsm-ctc-tip-bg,currentColor);}' +
			'.tippy-box.dsm-ctc-tippy[data-placement^="right"]>.tippy-arrow{left:0;}' +
			'.tippy-box.dsm-ctc-tippy[data-placement^="right"]>.tippy-arrow::before{left:-7px;border-width:8px 8px 8px 0;border-right-color:var(--dsm-ctc-tip-bg,currentColor);}' +
			'.tippy-box.dsm-ctc-tippy[data-dsm-ctc-arrow="off"]>.tippy-arrow{display:none!important;visibility:hidden!important;}';
		document.head.appendChild( style );
	}

	/**
	 * @param {string} text
	 * @return {Promise<boolean>}
	 */
	function copyText( text ) {
		if (
			navigator.clipboard &&
			typeof navigator.clipboard.writeText === 'function'
		) {
			return navigator.clipboard.writeText( text ).then(
				function () {
					return true;
				},
				function () {
					return fallbackCopy( text );
				}
			);
		}
		return Promise.resolve( fallbackCopy( text ) );
	}

	/**
	 * @param {string} text
	 * @return {boolean}
	 */
	function fallbackCopy( text ) {
		try {
			var ta = document.createElement( 'textarea' );
			ta.value = text;
			ta.setAttribute( 'readonly', '' );
			ta.style.position = 'fixed';
			ta.style.left = '-9999px';
			document.body.appendChild( ta );
			ta.select();
			var ok = document.execCommand( 'copy' );
			document.body.removeChild( ta );
			return !! ok;
		} catch ( e ) {
			return false;
		}
	}

	/**
	 * @param {Element} el
	 * @return {Element|null}
	 */
	function resolveModuleRoot( el ) {
		var prev = el.previousElementSibling;
		if ( ! prev ) {
			return null;
		}
		if ( prev.classList && prev.classList.contains( 'et_pb_module' ) ) {
			return prev;
		}
		var nested = prev.querySelector
			? prev.querySelector( '.et_pb_module' )
			: null;
		return nested || prev;
	}

	/**
	 * @param {Element} moduleRoot
	 * @param {string}  selector
	 * @return {Element|null}
	 */
	function resolveClickTarget( moduleRoot, selector ) {
		if ( ! moduleRoot ) {
			return null;
		}
		if ( ! selector ) {
			return moduleRoot;
		}
		if ( ! moduleRoot.querySelector ) {
			return null;
		}
		try {
			return moduleRoot.querySelector( selector );
		} catch ( e ) {
			return null;
		}
	}

	/**
	 * @param {Object} entry
	 * @return {string}
	 */
	function buildTipContent( entry ) {
		var label = entry.success_text || 'Copied';
		var showIcon = entry.success_show_icon !== 'off';
		var iconHtml =
			showIcon && entry.success_icon_html ? entry.success_icon_html : '';
		var labelHtml =
			'<span class="dsm-ctc-copied-label">' + escapeHtml( label ) + '</span>';

		return (
			'<span class="dsm-ctc-copied-tip">' +
			iconHtml +
			labelHtml +
			'</span>'
		);
	}

	/**
	 * @param {string} str
	 * @return {string}
	 */
	function escapeHtml( str ) {
		return String( str )
			.replace( /&/g, '&amp;' )
			.replace( /</g, '&lt;' )
			.replace( />/g, '&gt;' )
			.replace( /"/g, '&quot;' );
	}

	/**
	 * Divi-like viewport mode (desktop > 980, tablet 768–980, phone ≤ 767).
	 *
	 * @return {'desktop'|'tablet'|'phone'}
	 */
	function getViewportBreakpoint() {
		var w = window.innerWidth || 1200;
		if ( w <= 767 ) {
			return 'phone';
		}
		if ( w <= 980 ) {
			return 'tablet';
		}
		return 'desktop';
	}

	/**
	 * Pick flat tip style for current viewport from nested or legacy payload.
	 *
	 * @param {Object|null} tipStyle
	 * @return {Object|null}
	 */
	function pickTipStyleForViewport( tipStyle ) {
		if ( ! tipStyle || typeof tipStyle !== 'object' ) {
			return null;
		}

		var nestedDesktop = tipStyle.desktop;
		var isNested =
			nestedDesktop &&
			typeof nestedDesktop === 'object' &&
			( 'backgroundColor' in nestedDesktop ||
				'fontSize' in nestedDesktop ||
				'showArrow' in nestedDesktop );

		if ( ! isNested ) {
			return Object.assign( {}, tipStyle );
		}

		var mode = getViewportBreakpoint();
		var order =
			mode === 'phone'
				? [ 'phone', 'tablet', 'desktop' ]
				: mode === 'tablet'
					? [ 'tablet', 'desktop' ]
					: [ 'desktop' ];

		for ( var i = 0; i < order.length; i++ ) {
			var slice = tipStyle[ order[ i ] ];
			if (
				slice &&
				typeof slice === 'object' &&
				( 'backgroundColor' in slice ||
					'fontSize' in slice ||
					'showArrow' in slice )
			) {
				return Object.assign( {}, slice );
			}
		}

		return null;
	}

	/**
	 * @param {Object|null} tipStyle
	 * @param {object}      tip Tippy instance.
	 */
	function applyTipStyle( tipStyle, tip ) {
		if ( ! tip || ! tip.popper ) {
			return;
		}
		tip.popper.classList.add( 'dsm-ctc-tippy-popper' );
		var box =
			tip.popper.querySelector( '.tippy-box' ) ||
			tip.popper.firstElementChild;
		if ( ! box || ! tipStyle ) {
			return;
		}
		box.classList.add( 'dsm-ctc-tippy' );
		if ( tipStyle.backgroundColor ) {
			box.style.backgroundColor = tipStyle.backgroundColor;
			box.style.setProperty( '--dsm-ctc-tip-bg', tipStyle.backgroundColor );
		}
		if ( tipStyle.color ) {
			box.style.color = tipStyle.color;
		}
		if ( tipStyle.fontSize ) {
			box.style.fontSize = tipStyle.fontSize;
		}
		if ( tipStyle.borderRadius ) {
			box.style.borderRadius = tipStyle.borderRadius;
		}
		box.style.boxShadow = tipStyle.boxShadow || 'none';
		var content = box.querySelector( '.tippy-content' );
		if ( content && tipStyle.padding ) {
			content.style.padding = tipStyle.padding;
		}
		// Explicit false hides; missing showArrow defaults to visible (legacy payloads).
		var showArrow = tipStyle.showArrow !== false && tipStyle.showArrow !== 'off';
		box.setAttribute( 'data-dsm-ctc-arrow', showArrow ? 'on' : 'off' );
		var arrow = box.querySelector( '.tippy-arrow' );
		if ( arrow ) {
			if ( showArrow ) {
				arrow.style.removeProperty( 'display' );
				arrow.style.removeProperty( 'visibility' );
				arrow.style.removeProperty( 'pointer-events' );
			} else {
				arrow.style.display = 'none';
				arrow.style.visibility = 'hidden';
				arrow.style.pointerEvents = 'none';
			}
			if ( tipStyle.backgroundColor ) {
				arrow.style.color = tipStyle.backgroundColor;
			}
		}
		var iconColor = tipStyle.iconColor || tipStyle.color;
		if ( iconColor ) {
			box
				.querySelectorAll(
					'.dsm-ctc-copied-icon, .dsm-native-icon-glyph, .et-pb-icon'
				)
				.forEach( function ( el ) {
					el.style.color = iconColor;
				} );
		}
	}

	/**
	 * Tippy reference: click point, else text content box (not full block width).
	 *
	 * @param {Element}              element
	 * @param {{ x: number, y: number }|null} point
	 * @return {Object}
	 */
	function getTipReferenceRect( element, point ) {
		if (
			point &&
			typeof point.x === 'number' &&
			typeof point.y === 'number' &&
			! isNaN( point.x ) &&
			! isNaN( point.y )
		) {
			return {
				width: 0,
				height: 0,
				top: point.y,
				bottom: point.y,
				left: point.x,
				right: point.x,
			};
		}

		try {
			var range = element.ownerDocument.createRange();
			range.selectNodeContents( element );
			var rects = range.getClientRects();
			var top = Infinity;
			var left = Infinity;
			var right = -Infinity;
			var bottom = -Infinity;
			var found = false;
			var i;
			for ( i = 0; i < rects.length; i++ ) {
				var r = rects[ i ];
				if ( ! r || ( r.width === 0 && r.height === 0 ) ) {
					continue;
				}
				found = true;
				top = Math.min( top, r.top );
				left = Math.min( left, r.left );
				right = Math.max( right, r.right );
				bottom = Math.max( bottom, r.bottom );
			}
			if ( found ) {
				return {
					top: top,
					left: left,
					right: right,
					bottom: bottom,
					width: right - left,
					height: bottom - top,
				};
			}
		} catch ( e ) {
			// Fall through.
		}

		return element.getBoundingClientRect();
	}

	/**
	 * @param {Element}      trigger
	 * @param {Object}       entry
	 * @param {Object|null}  tipStyle
	 * @param {{ x: number, y: number }|null} [point]
	 */
	function showCopiedTip( trigger, entry, tipStyle, point ) {
		var prevAria = trigger.getAttribute( 'aria-label' ) || 'Copy to clipboard';
		var label = entry.success_text || 'Copied';
		trigger.setAttribute( 'aria-label', label );

		var duration = parseInt( entry.success_duration, 10 );
		if ( ! duration || duration < 500 ) {
			duration = 1500;
		}

		var placement = entry.success_placement || 'top';
		var tippyFn = typeof window.tippy === 'function' ? window.tippy : null;
		var resolvedTipStyle = pickTipStyleForViewport( tipStyle );

		if ( ! tippyFn ) {
			window.setTimeout( function () {
				trigger.setAttribute( 'aria-label', prevAria );
			}, duration );
			return;
		}

		var existing = trigger._dsmCtcTippy;
		if ( existing && typeof existing.destroy === 'function' ) {
			existing.destroy();
		}

		var refPoint = point || null;

		var instance = tippyFn( trigger, {
			content: buildTipContent( entry ),
			allowHTML: true,
			trigger: 'manual',
			placement: placement,
			interactive: false,
			hideOnClick: false,
			appendTo: document.body,
			animation: 'fade',
			duration: 200,
			// Always create arrow; visibility comes from applyTipStyle(showArrow).
			arrow: true,
			zIndex: 999999,
			getReferenceClientRect: function () {
				return getTipReferenceRect( trigger, refPoint );
			},
			onCreate: function ( tip ) {
				applyTipStyle( resolvedTipStyle, tip );
			},
			onShow: function ( tip ) {
				applyTipStyle( resolvedTipStyle, tip );
			},
		} );

		if ( Array.isArray( instance ) ) {
			instance = instance[ 0 ];
		}

		trigger._dsmCtcTippy = instance;

		if ( instance && typeof instance.show === 'function' ) {
			instance.show();
		}

		window.setTimeout( function () {
			if ( instance && typeof instance.hide === 'function' ) {
				instance.hide();
			}
			trigger.setAttribute( 'aria-label', prevAria );
			window.setTimeout( function () {
				if (
					trigger._dsmCtcTippy === instance &&
					instance &&
					typeof instance.destroy === 'function'
				) {
					instance.destroy();
					trigger._dsmCtcTippy = null;
				}
			}, 250 );
		}, duration );
	}

	/**
	 * Visible trigger text without the copy-affordance badge glyph.
	 *
	 * @param {Element} trigger
	 * @return {string}
	 */
	function triggerTextWithoutBadge( trigger ) {
		if ( ! trigger ) {
			return '';
		}
		var clone = trigger.cloneNode( true );
		if ( clone && clone.querySelectorAll ) {
			Array.prototype.forEach.call(
				clone.querySelectorAll( '.dsm-ctc-copy-badge' ),
				function ( node ) {
					if ( node.parentNode ) {
						node.parentNode.removeChild( node );
					}
				}
			);
		}
		return String( ( clone && clone.textContent ) || '' )
			.replace( /\s+/g, ' ' )
			.replace( /^\s+|\s+$/g, '' );
	}

	/**
	 * Prefer configured clipboard text; else the visible field content.
	 *
	 * @param {Object}  entry
	 * @param {Element} trigger
	 * @return {string}
	 */
	function resolveCopyText( entry, trigger ) {
		if (
			entry &&
			typeof entry.text === 'string' &&
			entry.text.replace( /^\s+|\s+$/g, '' )
		) {
			return entry.text;
		}
		return triggerTextWithoutBadge( trigger );
	}

	/**
	 * Prefer last/first text-bearing block inside the trigger so the badge sits
	 * inline (e.g. Divi Text `.et_pb_text_inner` > `p`), not as a block sibling.
	 *
	 * @param {Element}            trigger
	 * @param {'before'|'after'} placement
	 * @return {Element}
	 */
	function resolveBadgeInsertParent( trigger, placement ) {
		if ( ! trigger || ! trigger.querySelectorAll ) {
			return trigger;
		}

		var selector =
			'p, h1, h2, h3, h4, h5, h6, li, td, th, label, blockquote, figcaption';
		var blocks = Array.prototype.filter.call(
			trigger.querySelectorAll( selector ),
			function ( el ) {
				var text = String( el.textContent || '' )
					.replace( /\s+/g, ' ' )
					.trim();
				if ( ! text ) {
					return false;
				}
				var nested = el.querySelector( selector );
				if (
					nested &&
					String( nested.textContent || '' )
						.replace( /\s+/g, ' ' )
						.trim()
				) {
					return false;
				}
				return true;
			}
		);

		if ( ! blocks.length ) {
			return trigger;
		}

		return placement === 'before'
			? blocks[ 0 ]
			: blocks[ blocks.length - 1 ];
	}

	/**
	 * Inject / refresh copy-affordance badge beside trigger text.
	 *
	 * @param {Element} trigger
	 * @param {Object}  entry
	 * @return {void}
	 */
	function applyCopyBadge( trigger, entry ) {
		if ( ! trigger || ! entry ) {
			return;
		}

		Array.prototype.forEach.call(
			trigger.querySelectorAll
				? trigger.querySelectorAll( '.dsm-ctc-copy-badge' )
				: [],
			function ( node ) {
				if ( node.parentNode ) {
					node.parentNode.removeChild( node );
				}
			}
		);
		trigger.classList.remove( 'dsm-ctc-copy-badge-host' );
		if ( trigger.style ) {
			trigger.style.removeProperty( '--dsm-ctc-badge-gap' );
			trigger.style.removeProperty( '--dsm-ctc-badge-size' );
			trigger.style.removeProperty( '--dsm-ctc-badge-color' );
		}

		if ( String( entry.badge_show || 'off' ) !== 'on' ) {
			return;
		}

		var html =
			typeof entry.badge_html === 'string' ? entry.badge_html : '';
		if ( ! html ) {
			html =
				'<span class="dsm-ctc-copy-badge__glyph" aria-hidden="true">⧉</span>';
		}

		var placement =
			String( entry.badge_placement || 'after' ) === 'before'
				? 'before'
				: 'after';
		var badge = document.createElement( 'span' );
		badge.className =
			'dsm-ctc-copy-badge dsm-ctc-copy-badge--' + placement;
		badge.setAttribute( 'aria-hidden', 'true' );
		badge.innerHTML = html;

		trigger.classList.add(
			'dsm-ctc-copy-badge-host',
			'dsm-click-to-copy-trigger',
			'dsm-copy-to-clipboard-trigger'
		);

		var gap =
			typeof entry.badge_gap === 'string' && entry.badge_gap
				? entry.badge_gap
				: '6px';
		var size =
			typeof entry.badge_size === 'string' && entry.badge_size
				? entry.badge_size
				: '14px';
		var color =
			typeof entry.badge_color === 'string' ? entry.badge_color.trim() : '';

		// Vars + inline color on the badge (not the host). Divi module CSS often
		// sets `.et-pb-icon { color: … }` with higher specificity than inherit.
		badge.style.setProperty( '--dsm-ctc-badge-gap', gap );
		badge.style.setProperty( '--dsm-ctc-badge-size', size );
		if ( color ) {
			badge.style.setProperty( '--dsm-ctc-badge-color', color );
			badge.style.color = color;
			Array.prototype.forEach.call(
				badge.querySelectorAll(
					'.et-pb-icon, .dsm-native-icon-glyph, .dsm-ctc-copy-badge__glyph, .dsm-webfont-icon-glyph, i, svg'
				),
				function ( el ) {
					el.style.color = color;
					if ( el.style && typeof el.style.setProperty === 'function' ) {
						el.style.setProperty( 'fill', 'currentColor' );
					}
				}
			);
		}

		var host = resolveBadgeInsertParent( trigger, placement );
		if ( placement === 'before' ) {
			host.insertBefore( badge, host.firstChild );
		} else {
			host.appendChild( badge );
		}
	}

	/**
	 * @param {Element}     trigger
	 * @param {Object}      entry
	 * @param {boolean}     isFieldScoped
	 * @param {Object|null} tipStyle
	 */
	function bindTrigger( trigger, entry, isFieldScoped, tipStyle ) {
		if ( ! trigger || ! entry ) {
			return;
		}

		trigger.classList.add(
			'dsm-click-to-copy-trigger',
			'dsm-copy-to-clipboard-trigger'
		);
		if ( ! trigger.getAttribute( 'aria-label' ) ) {
			trigger.setAttribute( 'aria-label', 'Copy to clipboard' );
		}
		if ( ! trigger.hasAttribute( 'tabindex' ) ) {
			trigger.setAttribute( 'tabindex', '0' );
		}

		applyCopyBadge( trigger, entry );

		var onActivate = function ( event ) {
			var target = event.target;
			var text = resolveCopyText( entry, trigger );

			if ( ! text ) {
				return;
			}

			if ( ! isFieldScoped ) {
				if (
					target &&
					target.closest &&
					target.closest(
						'a, button, input, textarea, select, label, [contenteditable="true"]'
					)
				) {
					return;
				}
			} else {
				event.preventDefault();
				event.stopPropagation();
			}

			var point =
				typeof event.clientX === 'number' &&
				typeof event.clientY === 'number'
					? { x: event.clientX, y: event.clientY }
					: null;

			copyText( text ).then( function ( ok ) {
				if ( ok ) {
					showCopiedTip( trigger, entry, tipStyle, point );
				}
			} );
		};

		trigger.addEventListener( 'click', onActivate );
		trigger.addEventListener( 'keydown', function ( event ) {
			if ( event.key === 'Enter' || event.key === ' ' ) {
				onActivate( event );
			}
		} );
	}

	/**
	 * @param {Element} dataEl
	 * @return {Array<Object>}
	 */
	/**
	 * @param {Element} dataEl
	 * @param {string}  name
	 * @param {string}  legacyName
	 * @return {string}
	 */
	function readDataAttr( dataEl, name, legacyName ) {
		return (
			dataEl.getAttribute( name ) ||
			dataEl.getAttribute( legacyName ) ||
			''
		);
	}

	function parseEntries( dataEl ) {
		var raw = readDataAttr(
			dataEl,
			'data-dsm-copy-to-clipboard-entries',
			'data-dsm-click-to-copy-entries'
		);
		if ( raw ) {
			try {
				var parsed = JSON.parse( raw );
				if ( Array.isArray( parsed ) ) {
					return parsed.filter( function ( entry ) {
						return (
							entry &&
							typeof entry.selector === 'string' &&
							entry.selector &&
							( typeof entry.text === 'string' ||
								entry.text == null )
						);
					} );
				}
			} catch ( e ) {
				// Fall through to legacy.
			}
		}

		var legacyText =
			readDataAttr(
				dataEl,
				'data-dsm-copy-to-clipboard-text',
				'data-dsm-click-to-copy-text'
			) || '';
		if ( ! legacyText ) {
			return [];
		}

		return [
			{
				selector:
					readDataAttr(
						dataEl,
						'data-dsm-copy-to-clipboard-target',
						'data-dsm-click-to-copy-target'
					) || '',
				text: legacyText,
				success_text: 'Copied',
				success_show_icon: 'on',
				success_icon_html:
					'<span class="et-pb-icon dsm-ctc-copied-icon" aria-hidden="true">✓</span>',
				success_duration: 1500,
				success_placement: 'top',
			},
		];
	}

	/**
	 * @param {Element} dataEl
	 * @return {Object|null}
	 */
	function parseTipStyle( dataEl ) {
		var raw = readDataAttr(
			dataEl,
			'data-dsm-copy-to-clipboard-tip-style',
			'data-dsm-click-to-copy-tip-style'
		);
		if ( ! raw ) {
			return null;
		}
		try {
			var parsed = JSON.parse( raw );
			return parsed && typeof parsed === 'object' ? parsed : null;
		} catch ( e ) {
			return null;
		}
	}

	/**
	 * @param {Element} dataEl
	 */
	function bindOne( dataEl ) {
		var moduleRoot = resolveModuleRoot( dataEl );
		if ( ! moduleRoot ) {
			return;
		}

		var moduleTipStyle = parseTipStyle( dataEl );
		var entries = parseEntries( dataEl );
		entries.forEach( function ( entry ) {
			var trigger = resolveClickTarget( moduleRoot, entry.selector );
			var isFieldScoped = !! entry.selector && trigger !== moduleRoot;
			// Prefer per-entry tip_style (already merged in PHP). Clone so one
			// field’s tip chrome cannot leak into another trigger’s closure.
			var tipStyle =
				entry.tip_style && typeof entry.tip_style === 'object'
					? entry.tip_style
					: moduleTipStyle;
			bindTrigger(
				trigger,
				entry,
				isFieldScoped,
				tipStyle && typeof tipStyle === 'object'
					? JSON.parse( JSON.stringify( tipStyle ) )
					: null
			);
		} );
	}

	function init() {
		document
			.querySelectorAll(
				'.dsm-click-to-copy-data, .dsm-copy-to-clipboard-data'
			)
			.forEach( bindOne );
	}

	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', init );
	} else {
		init();
	}
}() );
