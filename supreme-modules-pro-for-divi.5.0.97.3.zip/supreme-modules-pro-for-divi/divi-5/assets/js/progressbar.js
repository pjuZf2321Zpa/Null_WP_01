/**
 * Supreme Progress Bar – front-end scroll reading progress (vanilla JS).
 *
 * @package DiviSupreme
 */
( function () {
	'use strict';

	/**
	 * @param {number} n
	 * @param {number} min
	 * @param {number} max
	 * @returns {number}
	 */
	function clamp( n, min, max ) {
		return Math.min( max, Math.max( min, n ) );
	}

	/**
	 * @param {Window} win
	 * @returns {number}
	 */
	function getDocumentScrollY( win ) {
		const d = win.document.documentElement;
		const b = win.document.body;
		return win.scrollY ?? d.scrollTop ?? b.scrollTop ?? 0;
	}

	/**
	 * Reading progress for the full document (0–100).
	 *
	 * @param {Window} win
	 * @returns {number}
	 */
	function entirePageProgress( win ) {
		const docEl = win.document.documentElement;
		const body = win.document.body;
		const scrollTop = getDocumentScrollY( win );
		const scrollHeight = Math.max(
			body.scrollHeight,
			body.offsetHeight,
			docEl.scrollHeight,
			docEl.offsetHeight,
			docEl.clientHeight
		);
		const clientHeight = win.innerHeight || docEl.clientHeight;
		const maxScroll = scrollHeight - clientHeight;
		if ( maxScroll <= 0 ) {
			return 100;
		}
		const pct = Math.ceil( ( scrollTop / maxScroll ) * 100 );
		return clamp( pct, 0, 100 );
	}

	/**
	 * Percentage of a target element that has entered the viewport (0–100).
	 *
	 * @param {Element|null} el
	 * @param {Window} win
	 * @returns {number}
	 */
	function percentageSeen( el, win ) {
		if ( ! el || ! ( el instanceof Element ) ) {
			return 0;
		}
		const viewportH = win.innerHeight;
		const scrollY = getDocumentScrollY( win );
		const rect = el.getBoundingClientRect();
		const elementTop = scrollY + rect.top;
		const elementHeight = rect.height || el.offsetHeight || 1;
		const distance = scrollY + viewportH - elementTop;
		const denom = ( viewportH + elementHeight ) / 100;
		const percentage = denom > 0 ? Math.round( distance / denom ) : 0;
		return clamp( percentage, 0, 100 );
	}

	/**
	 * Sets `--dsm-progress-bar-fixed-offset` on the document root (admin bar + Divi headers).
	 * Keep aligned with `packages/module-library/progress-bar/progress-bar-sync-top-offset.js`.
	 *
	 * @param {Document|null} rootDocument
	 * @returns {void}
	 */
	function syncProgressBarFixedTopOffset( rootDocument ) {
		const doc =
			rootDocument ||
			( typeof document !== 'undefined' ? document : null );
		if ( ! doc || ! doc.documentElement ) {
			return;
		}

		/** @param {string} id */
		var resolveEl = function ( id ) {
			var el = doc.getElementById( id );
			if (
				! el &&
				typeof window !== 'undefined' &&
				window.parent !== window
			) {
				try {
					el = window.parent.document.getElementById( id );
				} catch ( err ) {
					// Cross-origin parent.
				}
			}
			return el;
		};

		var offsetPx = 0;

		var admin = resolveEl( 'wpadminbar' );
		if ( admin ) {
			var adminWin = admin.ownerDocument.defaultView;
			if ( adminWin ) {
				var adminSt = adminWin.getComputedStyle( admin );
				if (
					adminSt.display !== 'none' &&
					adminSt.visibility !== 'hidden'
				) {
					var ah = admin.getBoundingClientRect().height;
					if ( ah > 0 ) {
						offsetPx += Math.round( ah );
					}
				}
			}
		}

		var body = doc.body;
		var etFixedNav =
			body && body.classList.contains( 'et_fixed_nav' );
		if (
			! etFixedNav &&
			typeof window !== 'undefined' &&
			window.parent !== window
		) {
			try {
				var parentBody = window.parent.document.body;
				etFixedNav =
					parentBody &&
					parentBody.classList.contains( 'et_fixed_nav' );
			} catch ( err ) {
				// Cross-origin parent.
			}
		}
		var headerIds = [ 'top-header', 'main-header' ];

		for ( var hi = 0; hi < headerIds.length; hi++ ) {
			var hdr = resolveEl( headerIds[ hi ] );
			if ( ! hdr ) {
				continue;
			}
			var hdrWin = hdr.ownerDocument.defaultView;
			if ( ! hdrWin ) {
				continue;
			}
			var st = hdrWin.getComputedStyle( hdr );
			if ( st.display === 'none' || st.visibility === 'hidden' ) {
				continue;
			}
			var pos = st.position;
			var fixedLike = pos === 'fixed' || pos === 'sticky';
			var hid = headerIds[ hi ];
			if (
				fixedLike ||
				hdr.classList.contains( 'et-fixed-header' ) ||
				( etFixedNav &&
					( hid === 'main-header' || hid === 'top-header' ) )
			) {
				offsetPx += hdr.offsetHeight;
			}
		}

		doc.documentElement.style.setProperty(
			'--dsm-progress-bar-fixed-offset',
			offsetPx + 'px'
		);
	}

	/**
	 * @param {SVGGeometryElement} circle
	 * @param {number} w
	 * @param {string} progressDirection
	 * @returns {void}
	 */
	function applyCircularProgress( circle, w, progressDirection ) {
		const r =
			circle && circle.r && circle.r.baseVal
				? circle.r.baseVal.value
				: 0;
		if ( ! r ) {
			return;
		}
		const circumference = 2 * Math.PI * r;
		circle.style.strokeDasharray = String( circumference );
		const p = clamp( w, 0, 100 );
		const offset = circumference * ( 1 - p / 100 );
		if ( progressDirection === 'left' ) {
			circle.style.transformOrigin = 'center';
			circle.style.transform = 'scaleX(-1)';
		} else {
			circle.style.transform = '';
		}
		circle.style.strokeDashoffset = String( offset );
	}

	/**
	 * @param {HTMLElement} container
	 * @param {Window} win
	 * @returns {void}
	 */
	function updateContainer( container, win ) {
		const relativeTo = container.dataset.relative || 'entire_page';
		const showPercentage = container.dataset.show_percentage || 'off';
		const trackerType = container.dataset.tracker_type || 'horizontal';
		const progressDirection = container.dataset.direction || 'left';
		const progressSelector = container.dataset.selector || '';

		let w = 0;

		if ( relativeTo === 'entire_page' ) {
			w = entirePageProgress( win );
		} else if ( relativeTo === 'selector' ) {
			const target = progressSelector
				? win.document.querySelector( progressSelector )
				: null;
			w = percentageSeen( target, win );
		}

		const progressEl =
			trackerType === 'horizontal'
				? container.querySelector( '.dsm-current-progress' )
				: null;
		const pctEl = container.querySelector(
			'.dsm-current-progress-percentage'
		);

		if ( trackerType === 'horizontal' && progressEl ) {
			progressEl.style.setProperty( 'width', w + '%' );
		}

		if ( trackerType === 'circular' ) {
			const circle = container.querySelector(
				'.dsm-progressbar-circular svg circle.current-progress'
			);
			if ( circle ) {
				applyCircularProgress( circle, w, progressDirection );
			}
		}

		if ( showPercentage === 'on' && pctEl ) {
			pctEl.textContent = Math.floor( w ) + '%';
		}
	}

	function init() {
		const containers = document.querySelectorAll(
			'.dsm-progress-bar-container'
		);
		if ( ! containers.length ) {
			return;
		}

		document.documentElement.classList.add( 'dsm-has-progress-bar' );
		syncProgressBarFixedTopOffset( document );

		const win = window;
		let ticking = false;

		function onScrollOrResize() {
			if ( ticking ) {
				return;
			}
			ticking = true;
			win.requestAnimationFrame( function () {
				ticking = false;
				syncProgressBarFixedTopOffset( document );
				containers.forEach( function ( c ) {
					updateContainer( c, win );
				} );
			} );
		}

		containers.forEach( function ( c ) {
			updateContainer( c, win );
		} );

		win.addEventListener( 'scroll', onScrollOrResize, { passive: true } );
		win.addEventListener( 'resize', onScrollOrResize, { passive: true } );
	}

	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', init );
	} else {
		init();
	}
} )();
