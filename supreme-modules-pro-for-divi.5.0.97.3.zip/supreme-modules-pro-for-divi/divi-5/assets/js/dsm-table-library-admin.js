/**
 * Table library CPT — add/remove rows and columns, drag-reorder, merge/split.
 *
 * Writes the same POST field names DsmTableLibraryAdmin persists through
 * Table::sanitize_grid. Cell colspan/rowspan match table-grid-model.js
 * (dsmTableMergeCells / dsmTableSplitCell). Does not boot Visual Builder.
 *
 * @package DiviSupreme
 */
(function () {
	'use strict';

	function ready(fn) {
		if (document.readyState !== 'loading') {
			fn();
		} else {
			document.addEventListener('DOMContentLoaded', fn);
		}
	}

	function limits() {
		var raw =
			typeof window.dsmTableLibraryAdmin === 'object' &&
			window.dsmTableLibraryAdmin
				? window.dsmTableLibraryAdmin
				: {};
		var maxCols = parseInt(raw.maxCols, 10);
		var maxRows = parseInt(raw.maxRows, 10);
		return {
			maxCols: maxCols > 0 ? maxCols : 20,
			maxRows: maxRows > 0 ? maxRows : 100,
			i18n: raw.i18n && typeof raw.i18n === 'object' ? raw.i18n : {},
		};
	}

	function parseStoredRows(name) {
		var el = document.querySelector('textarea[name="' + name + '"]');
		if (!el || !el.value) {
			return [];
		}
		try {
			var data = JSON.parse(el.value);
			return Array.isArray(data) ? data : [];
		} catch (e) {
			return [];
		}
	}

	function offPageRowCount() {
		return (
			parseStoredRows('dsm_table_lib_row_before').length +
			parseStoredRows('dsm_table_lib_row_after').length +
			parseStoredRows('dsm_table_lib_row_rest').length
		);
	}

	function totalDataRowCount(tbody) {
		return tbody.querySelectorAll('tr').length + offPageRowCount();
	}

	var richEditorTd = null;

	function i18n(key, fallback) {
		var pack = limits().i18n;
		var value = pack[key];
		return 'string' === typeof value && value ? value : fallback;
	}

	function bindCsvImport() {
		var file = document.getElementById('dsm_table_lib_csv');
		var btn = document.getElementById('dsm_table_lib_import_csv');
		var status = document.getElementById('dsm_table_lib_import_status');
		var header = document.getElementById('dsm_table_lib_csv_header');
		if (!file || !btn) {
			return;
		}

		function setStatus(message) {
			if (!status) {
				return;
			}
			if (!message) {
				status.textContent = '';
				status.hidden = true;
				return;
			}
			status.textContent = message;
			status.hidden = false;
		}

		function syncButton() {
			btn.disabled = !file.files || !file.files.length;
		}

		file.addEventListener('change', function () {
			setStatus('');
			syncButton();
		});
		syncButton();

		btn.addEventListener('click', function () {
			if (!file.files || !file.files[0]) {
				return;
			}

			var cfg =
				typeof window.dsmTableLibraryAdmin === 'object' &&
				window.dsmTableLibraryAdmin
					? window.dsmTableLibraryAdmin
					: {};
			var ajaxUrl = typeof cfg.ajaxUrl === 'string' ? cfg.ajaxUrl : '';
			var ajaxNonce = typeof cfg.ajaxNonce === 'string' ? cfg.ajaxNonce : '';
			var postId = parseInt(cfg.postId, 10);
			if (!ajaxUrl || !ajaxNonce || !(postId > 0)) {
				setStatus(i18n('importFail', 'Could not import the CSV.'));
				return;
			}

			var data = new FormData();
			data.append('action', 'dsm_table_lib_import_csv');
			data.append('_ajax_nonce', ajaxNonce);
			data.append('post_id', String(postId));
			data.append('dsm_table_lib_csv', file.files[0]);
			if (header && header.checked) {
				data.append('dsm_table_lib_csv_header', 'on');
			}

			btn.disabled = true;
			setStatus(i18n('importing', 'Importing…'));

			fetch(ajaxUrl, {
				method: 'POST',
				body: data,
				credentials: 'same-origin',
			})
				.then(function (response) {
					return response
						.json()
						.then(function (payload) {
							return payload;
						})
						.catch(function () {
							return null;
						});
				})
				.then(function (payload) {
					if (!payload || !payload.success) {
						var message =
							payload &&
							payload.data &&
							typeof payload.data.message === 'string'
								? payload.data.message
								: i18n('importFail', 'Could not import the CSV.');
						setStatus(message);
						syncButton();
						return;
					}
					var reload =
						payload.data &&
						typeof payload.data.reload === 'string' &&
						payload.data.reload
							? payload.data.reload
							: '';
					window.location.href = reload || window.location.href.split('#')[0];
				})
				.catch(function () {
					setStatus(i18n('importFail', 'Could not import the CSV.'));
					syncButton();
				});
		});
	}

	function richEditorId() {
		return 'dsm_table_library_rich_editor';
	}

	function getRichEditorHtml() {
		var textarea = document.getElementById(richEditorId());
		var fallback = textarea ? textarea.value : '';
		try {
			if (window.tinyMCE) {
				var editor = window.tinyMCE.get(richEditorId());
				if (editor) {
					return editor.getContent() || fallback;
				}
			}
		} catch (err) {
			return fallback;
		}
		return fallback;
	}

	function setRichEditorHtml(html) {
		var textarea = document.getElementById(richEditorId());
		if (textarea) {
			textarea.value = html || '';
		}
		if (window.tinyMCE) {
			var editor = window.tinyMCE.get(richEditorId());
			if (editor) {
				editor.setContent(html || '');
			}
		}
	}

	function setRichPreview(td, html) {
		var preview = td.querySelector('.dsm-table-library-rich-preview');
		if (!preview) {
			return;
		}
		var trimmed = String(html || '').trim();
		preview.innerHTML = '';
		if (!trimmed) {
			var placeholder = document.createElement('span');
			placeholder.className = 'dsm-table-library-rich-placeholder';
			placeholder.textContent = i18n(
				'addFormatted',
				'Click to add formatted text'
			);
			preview.appendChild(placeholder);
			return;
		}
		preview.innerHTML = trimmed;
	}

	function promoteToRich(td) {
		var text = td.querySelector(
			'input[type="text"].dsm-table-library-cell-value'
		);
		var html = text ? text.value : '';
		if (text) {
			text.type = 'hidden';
		}
		if (!td.querySelector('.dsm-table-library-rich-preview')) {
			var edit = document.createElement('button');
			edit.type = 'button';
			edit.className = 'dsm-table-library-rich-edit';
			edit.setAttribute('data-dsm-table-rich-edit', '');
			edit.textContent = i18n('editRich', 'Edit formatted text');
			var preview = document.createElement('div');
			preview.className = 'dsm-table-library-rich-preview';
			preview.setAttribute('data-dsm-table-rich-edit', '');
			var value = td.querySelector('.dsm-table-library-cell-value');
			if (value) {
				td.insertBefore(edit, value);
				td.insertBefore(preview, value);
			} else {
				td.appendChild(edit);
				td.appendChild(preview);
			}
		}
		setRichPreview(td, html);
		var hidden = td.querySelector('.dsm-table-library-cell-value');
		if (hidden) {
			hidden.value = html;
		}
	}

	function demoteToText(td) {
		var hidden = td.querySelector(
			'input.dsm-table-library-cell-value'
		);
		var html = hidden ? hidden.value : '';
		var tmp = document.createElement('div');
		tmp.innerHTML = html;
		var plain = tmp.textContent || tmp.innerText || '';
		td.querySelectorAll('.dsm-table-library-rich-preview').forEach(
			function (node) {
				node.remove();
			}
		);
		td.querySelectorAll('.dsm-table-library-rich-edit').forEach(
			function (node) {
				node.remove();
			}
		);
		if (hidden) {
			hidden.type = 'text';
			hidden.value = plain;
		}
	}

	function cellTypeField(td) {
		return td.querySelector('[data-dsm-table-cell-type]');
	}

	function getCellType(td) {
		var field = cellTypeField(td);
		var type = field ? String(field.value || '') : '';
		return type || 'text';
	}

	function typeLabel(type) {
		if (type === 'text') {
			return i18n('typeText', 'Text');
		}
		if (type === 'rich_text') {
			return i18n('typeRich', 'Rich text');
		}
		return type;
	}

	function canApplyType(td, type) {
		if (type === 'text' || type === 'rich_text') {
			return true;
		}
		return getCellType(td) === type;
	}

	function applyTypeToCell(td, type) {
		if (!canApplyType(td, type)) {
			return false;
		}
		var field = cellTypeField(td);
		if (field) {
			field.value = type;
		}
		if (type === 'rich_text') {
			promoteToRich(td);
		} else if (type === 'text') {
			demoteToText(td);
		}
		return true;
	}

	function appendTypeOption(select, type) {
		var option = document.createElement('option');
		option.value = type;
		option.textContent = typeLabel(type);
		select.appendChild(option);
	}

	function rebuildToolbarTypeSelect(select, cells) {
		var types = {};
		var extras = [];
		var mixed = false;
		var shared = '';

		select.innerHTML = '';

		if (!cells.length) {
			var none = document.createElement('option');
			none.value = '';
			none.textContent = i18n('typeNone', 'Select a cell');
			select.appendChild(none);
			appendTypeOption(select, 'text');
			appendTypeOption(select, 'rich_text');
			select.value = '';
			select.disabled = true;
			return;
		}

		cells.forEach(function (td) {
			var type = getCellType(td);
			types[type] = true;
			if (type !== 'text' && type !== 'rich_text' && extras.indexOf(type) === -1) {
				extras.push(type);
			}
		});

		var keys = Object.keys(types);
		mixed = keys.length > 1;
		shared = mixed ? '' : keys[0];

		if (mixed) {
			var mixedOpt = document.createElement('option');
			mixedOpt.value = '';
			mixedOpt.textContent = i18n('typeMixed', 'Mixed');
			select.appendChild(mixedOpt);
		}

		appendTypeOption(select, 'text');
		appendTypeOption(select, 'rich_text');
		extras.forEach(function (type) {
			appendTypeOption(select, type);
		});

		select.disabled = false;
		select.value = shared;
	}

	function syncToolbarCellType(root, tbody) {
		var select = (root || document).querySelector(
			'[data-dsm-table-toolbar-type]'
		);
		if (!select) {
			return;
		}
		rebuildToolbarTypeSelect(select, selectedCells(tbody));
	}

	function openRichEditor(td) {
		var modal = document.getElementById('dsm-table-library-rich-modal');
		var hidden = td.querySelector('.dsm-table-library-cell-value');
		if (!modal || !hidden) {
			return;
		}
		richEditorTd = td;
		modal.hidden = false;
		modal.classList.add('is-open');
		modal.style.display = 'flex';
		document.body.classList.add('dsm-table-library-rich-open');
		setRichEditorHtml(hidden.value || '');
		window.setTimeout(function () {
			if (!window.tinyMCE) {
				var textarea = document.getElementById(richEditorId());
				if (textarea) {
					textarea.focus();
				}
				return;
			}
			var editor = window.tinyMCE.get(richEditorId());
			if (editor) {
				editor.show();
				editor.setContent(hidden.value || '');
				sizeRichEditor();
				editor.focus();
			}
			sizeRichEditor();
		}, 50);
	}

	function closeRichEditor() {
		var modal = document.getElementById('dsm-table-library-rich-modal');
		if (modal) {
			modal.classList.remove('is-open');
			modal.hidden = true;
			modal.style.display = 'none';
		}
		document.body.classList.remove('dsm-table-library-rich-open');
		richEditorTd = null;
	}

	function applyRichEditor() {
		var td = richEditorTd;
		var html = '';
		try {
			html = getRichEditorHtml();
		} catch (err) {
			html = '';
		}
		closeRichEditor();
		if (!td) {
			return;
		}
		var hidden = td.querySelector('.dsm-table-library-cell-value');
		if (hidden) {
			hidden.value = html;
		}
		setRichPreview(td, html);
	}

	function onRichChromePointer(event) {
		var hit = event.target;
		if (!hit || !hit.closest) {
			return;
		}
		if (hit.closest('[data-dsm-table-rich-apply]')) {
			event.preventDefault();
			event.stopPropagation();
			applyRichEditor();
			return;
		}
		if (hit.closest('[data-dsm-table-rich-cancel]')) {
			event.preventDefault();
			event.stopPropagation();
			closeRichEditor();
		}
	}

	document.addEventListener('pointerdown', onRichChromePointer, true);
	document.addEventListener('click', onRichChromePointer, true);

	window.dsmTableLibraryRichApply = applyRichEditor;
	window.dsmTableLibraryRichClose = closeRichEditor;

	function sizeRichEditor() {
		var iframe = document.querySelector(
			'#wp-dsm_table_library_rich_editor-wrap iframe'
		);
		if (iframe) {
			iframe.style.height = '240px';
		}
		if (!window.tinyMCE) {
			return;
		}
		var editor = window.tinyMCE.get(richEditorId());
		if (editor && editor.theme && typeof editor.theme.resizeTo === 'function') {
			try {
				editor.theme.resizeTo(null, 240);
			} catch (err) {
				/* Some TinyMCE builds omit resizeTo. */
			}
		}
	}

	function allowedRole(role) {
		return 'footer' === role || 'cta' === role ? role : 'body';
	}

	function dataHeaders(theadRow) {
		return theadRow.querySelectorAll('th:not(.dsm-table-library-rowmeta)');
	}

	function dataCells(tr) {
		return tr.querySelectorAll('td.dsm-table-library-cell');
	}

	function spanValue(root, which) {
		var input = root.querySelector(
			'input[name*="dsm_table_lib_' + which + '"]'
		);
		var n = input ? parseInt(input.value, 10) : 1;
		return n > 0 ? n : 1;
	}

	function setSpanValue(root, which, value) {
		var input = root.querySelector(
			'input[name*="dsm_table_lib_' + which + '"]'
		);
		if (input) {
			input.value = String(value > 0 ? value : 1);
		}
	}

	function badgeText(colspan, rowspan) {
		return String(colspan) + '×' + String(rowspan);
	}

	function syncBadge(root, colspan, rowspan) {
		var badge = root.querySelector('.dsm-table-library-merge-badge');
		if (colspan < 2 && rowspan < 2) {
			if (badge) {
				badge.remove();
			}
			return;
		}
		if (!badge) {
			badge = document.createElement('span');
			badge.className = 'dsm-table-library-merge-badge';
			root.appendChild(badge);
		}
		badge.textContent = badgeText(colspan, rowspan);
	}

	function applyCoveredStyles(theadRow, tbody) {
		var headers = dataHeaders(theadRow);
		var rows = tbody.querySelectorAll('tr');
		var colCount = headers.length;
		var rowCount = rows.length;
		var covered = {};
		var rr;
		var cc;
		var cs;
		var rs;
		var key;

		headers.forEach(function (th, col) {
			th.classList.remove('is-covered');
			cs = spanValue(th, 'header_colspan');
			rs = spanValue(th, 'header_rowspan');
			syncBadge(th, cs, rs);
			if (cs < 2 && rs < 2) {
				return;
			}
			for (rr = 0; rr < rs; rr++) {
				for (cc = col; cc < col + cs && cc < colCount; cc++) {
					if (0 === rr && cc === col) {
						continue;
					}
					if (0 === rr) {
						covered['h:' + String(cc)] = 'h:' + String(col);
					} else if (rr - 1 < rowCount) {
						covered[String(rr - 1) + ':' + String(cc)] =
							'h:' + String(col);
					}
				}
			}
		});

		rows.forEach(function (tr, row) {
			dataCells(tr).forEach(function (td, col) {
				td.classList.remove('is-covered');
				cs = spanValue(td, 'colspan');
				rs = spanValue(td, 'rowspan');
				syncBadge(td, cs, rs);
				if (cs < 2 && rs < 2) {
					return;
				}
				for (rr = row; rr < row + rs && rr < rowCount; rr++) {
					for (cc = col; cc < col + cs && cc < colCount; cc++) {
						if (rr === row && cc === col) {
							continue;
						}
						covered[String(rr) + ':' + String(cc)] =
							String(row) + ':' + String(col);
					}
				}
			});
		});

		headers.forEach(function (th, col) {
			if (covered['h:' + String(col)]) {
				th.classList.add('is-covered');
			}
		});

		rows.forEach(function (tr, row) {
			dataCells(tr).forEach(function (td, col) {
				key = String(row) + ':' + String(col);
				if (covered[key]) {
					td.classList.add('is-covered');
				}
			});
		});
	}

	function reindexRows(tbody, theadRow) {
		var rows = tbody.querySelectorAll('tr');
		rows.forEach(function (tr, rowIndex) {
			dataCells(tr).forEach(function (td, colIndex) {
				td.setAttribute('data-dsm-row', String(rowIndex));
				td.setAttribute('data-dsm-col', String(colIndex));
				var text = td.querySelector(
					'input.dsm-table-library-cell-value, input[name*="dsm_table_lib_cell"]'
				);
				if (text) {
					text.name =
						'dsm_table_lib_cell[' + String(rowIndex) + '][]';
				}
				var typeField = td.querySelector('[data-dsm-table-cell-type]');
				if (typeField) {
					typeField.name =
						'dsm_table_lib_cell_type[' + String(rowIndex) + '][]';
				}
				var colspan = td.querySelector(
					'input[name*="dsm_table_lib_colspan"]'
				);
				if (colspan) {
					colspan.name =
						'dsm_table_lib_colspan[' + String(rowIndex) + '][]';
				}
				var rowspan = td.querySelector(
					'input[name*="dsm_table_lib_rowspan"]'
				);
				if (rowspan) {
					rowspan.name =
						'dsm_table_lib_rowspan[' + String(rowIndex) + '][]';
				}
			});
			syncRowRole(tr);
			var select = tr.querySelector(
				'select[name="dsm_table_lib_row_role[]"]'
			);
			if (select) {
				select.id = 'dsm_table_lib_row_role_' + String(rowIndex);
			}
			var label = tr.querySelector(
				'label[for^="dsm_table_lib_row_role_"]'
			);
			if (label) {
				label.setAttribute(
					'for',
					'dsm_table_lib_row_role_' + String(rowIndex)
				);
			}
		});
		if (theadRow) {
			applyCoveredStyles(theadRow, tbody);
		}
	}

	function demoteRichPreview(root) {
		root.querySelectorAll('.dsm-table-library-rich-preview').forEach(
			function (preview) {
				preview.remove();
			}
		);
		root.querySelectorAll('.dsm-table-library-rich-edit').forEach(
			function (button) {
				button.remove();
			}
		);
		root.querySelectorAll(
			'input[type="hidden"].dsm-table-library-cell-value'
		).forEach(function (hidden) {
			hidden.type = 'text';
			hidden.value = '';
		});
	}

	function clearInputs(root) {
		demoteRichPreview(root);
		root.querySelectorAll('input').forEach(function (input) {
			if (input.type === 'checkbox') {
				input.checked = false;
				return;
			}
			if (input.name && input.name.indexOf('colspan') !== -1) {
				input.value = '1';
				return;
			}
			if (input.name && input.name.indexOf('rowspan') !== -1) {
				input.value = '1';
				return;
			}
			if (input.type === 'hidden') {
				if (
					input.hasAttribute('data-dsm-table-cell-type') ||
					input.classList.contains('dsm-table-library-cell-type')
				) {
					input.value = 'text';
					return;
				}
				if (
					input.classList.contains('dsm-table-library-cell-value')
				) {
					input.value = '';
					return;
				}
				if (
					input.name &&
					(input.name.indexOf('dsm_table_lib_col_id') !== -1 ||
						input.name.indexOf('dsm_table_lib_row_id') !== -1)
				) {
					input.value = '';
				}
				return;
			}
			input.value = '';
		});
		root.querySelectorAll('select').forEach(function (select) {
			if (select.hasAttribute('data-dsm-table-toolbar-type')) {
				return;
			}
			select.value = 'body';
		});
		root.classList.remove('is-selected', 'is-covered');
		var badge = root.querySelector('.dsm-table-library-merge-badge');
		if (badge) {
			badge.remove();
		}
	}

	function setRowRole(tr, role) {
		var next = allowedRole(role);
		var select = tr.querySelector('select[name="dsm_table_lib_row_role[]"]');
		if (select) {
			select.value = next;
		}
	}

	function selectedCells(tbody) {
		return Array.prototype.slice.call(
			tbody.querySelectorAll('td.dsm-table-library-cell.is-selected')
		);
	}

	function clearSelection(tbody) {
		tbody
			.querySelectorAll('td.dsm-table-library-cell.is-selected')
			.forEach(function (td) {
				td.classList.remove('is-selected');
			});
	}

	function selectRange(tbody, fromTd, toTd) {
		var row = parseInt(fromTd.getAttribute('data-dsm-row'), 10);
		if (row !== parseInt(toTd.getAttribute('data-dsm-row'), 10)) {
			clearSelection(tbody);
			toTd.classList.add('is-selected');
			return;
		}
		var a = parseInt(fromTd.getAttribute('data-dsm-col'), 10);
		var b = parseInt(toTd.getAttribute('data-dsm-col'), 10);
		var start = Math.min(a, b);
		var end = Math.max(a, b);
		var tr = tbody.querySelectorAll('tr')[row];
		if (!tr) {
			return;
		}
		clearSelection(tbody);
		dataCells(tr).forEach(function (td, col) {
			if (col >= start && col <= end) {
				td.classList.add('is-selected');
			}
		});
	}

	function mergeSelected(tbody, theadRow) {
		var picked = selectedCells(tbody);
		if (picked.length < 2) {
			return;
		}
		var row = parseInt(picked[0].getAttribute('data-dsm-row'), 10);
		var cols = [];
		var valid = picked.every(function (td) {
			if (parseInt(td.getAttribute('data-dsm-row'), 10) !== row) {
				return false;
			}
			cols.push(parseInt(td.getAttribute('data-dsm-col'), 10));
			return true;
		});
		if (!valid) {
			return;
		}
		cols.sort(function (a, b) {
			return a - b;
		});
		var i;
		for (i = 1; i < cols.length; i++) {
			if (cols[i] !== cols[i - 1] + 1) {
				return;
			}
		}
		var tr = tbody.querySelectorAll('tr')[row];
		if (!tr) {
			return;
		}
		var cells = dataCells(tr);
		var origin = cells[cols[0]];
		var colspan = cols[cols.length - 1] - cols[0] + 1;
		if (!origin || colspan < 2) {
			return;
		}
		setSpanValue(origin, 'colspan', colspan);
		setSpanValue(origin, 'rowspan', 1);
		for (i = 1; i < cols.length; i++) {
			var covered = cells[cols[i]];
			if (!covered) {
				continue;
			}
			setSpanValue(covered, 'colspan', 1);
			setSpanValue(covered, 'rowspan', 1);
			var text = covered.querySelector('input[type="text"]');
			if (text) {
				text.value = '';
			}
		}
		clearSelection(tbody);
		applyCoveredStyles(theadRow, tbody);
	}

	function splitSelected(tbody, theadRow) {
		var picked = selectedCells(tbody);
		if (!picked.length) {
			return;
		}
		picked.forEach(function (td) {
			var row = parseInt(td.getAttribute('data-dsm-row'), 10);
			var col = parseInt(td.getAttribute('data-dsm-col'), 10);
			var origin = td;
			var cs = spanValue(td, 'colspan');
			var rs = spanValue(td, 'rowspan');
			if (cs < 2 && rs < 2 && td.classList.contains('is-covered')) {
				var trs = tbody.querySelectorAll('tr');
				var rr;
				var cc;
				for (rr = 0; rr <= row; rr++) {
					var cells = dataCells(trs[rr]);
					for (cc = 0; cc < cells.length; cc++) {
						var cand = cells[cc];
						var spanC = spanValue(cand, 'colspan');
						var spanR = spanValue(cand, 'rowspan');
						if (
							spanC > 1 ||
							spanR > 1
						) {
							if (
								rr <= row &&
								row < rr + spanR &&
								cc <= col &&
								col < cc + spanC
							) {
								origin = cand;
							}
						}
					}
				}
			}
			setSpanValue(origin, 'colspan', 1);
			setSpanValue(origin, 'rowspan', 1);
		});
		clearSelection(tbody);
		applyCoveredStyles(theadRow, tbody);
	}

	function selectedColIndexes(theadRow) {
		var out = [];
		dataHeaders(theadRow).forEach(function (th, index) {
			var check = th.querySelector('.dsm-table-library-col-check');
			if (check && check.checked) {
				out.push(index);
			}
		});
		return out;
	}

	function selectedRowIndexes(tbody) {
		var out = [];
		tbody.querySelectorAll('tr').forEach(function (tr, index) {
			var check = tr.querySelector('.dsm-table-library-row-check');
			if (check && check.checked) {
				out.push(index);
			}
		});
		return out;
	}

	function removeAtIndexes(list, indexes) {
		indexes
			.slice()
			.sort(function (a, b) {
				return b - a;
			})
			.forEach(function (index) {
				if (list[index]) {
					list[index].remove();
				}
			});
	}

	function removeSelected(theadRow, tbody) {
		var colIndexes = selectedColIndexes(theadRow);
		var rowIndexes = selectedRowIndexes(tbody);
		if (!colIndexes.length && !rowIndexes.length) {
			return;
		}

		var colCount = dataHeaders(theadRow).length;
		var rowCount = tbody.querySelectorAll('tr').length;
		if (colIndexes.length >= colCount) {
			colIndexes.shift();
		}
		if (rowIndexes.length >= rowCount) {
			rowIndexes.shift();
		}

		removeAtIndexes(dataHeaders(theadRow), colIndexes);
		tbody.querySelectorAll('tr').forEach(function (tr) {
			removeAtIndexes(dataCells(tr), colIndexes);
		});
		removeAtIndexes(tbody.querySelectorAll('tr'), rowIndexes);

		shrinkOverflowingSpans(theadRow, tbody);
		reindexRows(tbody, theadRow);
	}

	function shrinkOverflowingSpans(theadRow, tbody) {
		var colCount = dataHeaders(theadRow).length;
		var rowCount = tbody.querySelectorAll('tr').length;
		dataHeaders(theadRow).forEach(function (th, col) {
			var cs = spanValue(th, 'header_colspan');
			var rs = spanValue(th, 'header_rowspan');
			if (col + cs > colCount) {
				setSpanValue(th, 'header_colspan', Math.max(1, colCount - col));
			}
			if (rs > 1 && rs - 1 > rowCount) {
				setSpanValue(th, 'header_rowspan', rowCount + 1);
			}
		});
		tbody.querySelectorAll('tr').forEach(function (tr, row) {
			dataCells(tr).forEach(function (td, col) {
				var cs = spanValue(td, 'colspan');
				var rs = spanValue(td, 'rowspan');
				if (col + cs > colCount) {
					setSpanValue(td, 'colspan', Math.max(1, colCount - col));
				}
				if (row + rs > rowCount) {
					setSpanValue(td, 'rowspan', Math.max(1, rowCount - row));
				}
			});
		});
	}

	function formatCount(count, one, many) {
		var tmpl = 1 === count ? one : many;
		return tmpl.replace('%d', String(count));
	}

	function syncRowRole(tr) {
		var select = tr.querySelector(
			'select[name="dsm_table_lib_row_role[]"]'
		);
		tr.setAttribute(
			'data-dsm-row-role',
			select ? allowedRole(select.value) : 'body'
		);
	}

	function updateSelectionChrome(theadRow, tbody, root) {
		var status = (root || document).querySelector(
			'[data-dsm-table-selection-status]'
		);
		var mergeBtn = (root || document).querySelector(
			'[data-dsm-table-merge]'
		);
		var splitBtn = (root || document).querySelector(
			'[data-dsm-table-split]'
		);
		var removeBtn = (root || document).querySelector(
			'[data-dsm-table-remove-selected]'
		);
		var cells = selectedCells(tbody).length;
		var rows = selectedRowIndexes(tbody).length;
		var cols = selectedColIndexes(theadRow).length;
		var labels = limits().i18n;
		var parts = [];

		var checkedCols = selectedColIndexes(theadRow);
		dataHeaders(theadRow).forEach(function (th) {
			var check = th.querySelector('.dsm-table-library-col-check');
			th.classList.toggle(
				'is-col-checked',
				!!(check && check.checked)
			);
		});
		tbody.querySelectorAll('tr').forEach(function (tr) {
			var check = tr.querySelector('.dsm-table-library-row-check');
			tr.classList.toggle(
				'is-row-checked',
				!!(check && check.checked)
			);
			dataCells(tr).forEach(function (td, col) {
				td.classList.toggle(
					'is-col-checked',
					checkedCols.indexOf(col) !== -1
				);
			});
			syncRowRole(tr);
		});
		tbody.querySelectorAll('td.dsm-table-library-cell').forEach(function (td) {
			var pick = td.querySelector('.dsm-table-library-cell-pick');
			if (pick) {
				pick.setAttribute(
					'aria-pressed',
					td.classList.contains('is-selected') ? 'true' : 'false'
				);
			}
		});

		if (cells) {
			parts.push(
				formatCount(
					cells,
					labels.cellOne || '%d cell selected',
					labels.cellMany || '%d cells selected'
				)
			);
		}
		if (rows) {
			parts.push(
				formatCount(
					rows,
					labels.rowOne || '%d row selected',
					labels.rowMany || '%d rows selected'
				)
			);
		}
		if (cols) {
			parts.push(
				formatCount(
					cols,
					labels.colOne || '%d column selected',
					labels.colMany || '%d columns selected'
				)
			);
		}

		if (status) {
			if (!parts.length) {
				status.hidden = true;
				status.textContent = '';
			} else {
				status.hidden = false;
				status.textContent = parts.join(' · ');
			}
		}
		if (mergeBtn) {
			mergeBtn.disabled = cells < 2;
		}
		if (splitBtn) {
			splitBtn.disabled = cells < 1;
		}
		if (removeBtn) {
			removeBtn.disabled = !rows && !cols;
		}
		syncToolbarCellType(root, tbody);
	}

	function insertColumnAfter(theadRow, tbody, index, cap) {
		var headers = dataHeaders(theadRow);
		if (headers.length >= cap.maxCols || !headers[index]) {
			return;
		}
		var newTh = headers[headers.length - 1].cloneNode(true);
		clearInputs(newTh);
		headers[index].after(newTh);
		tbody.querySelectorAll('tr').forEach(function (tr) {
			var cells = dataCells(tr);
			if (!cells[index]) {
				return;
			}
			var newTd = cells[cells.length - 1].cloneNode(true);
			clearInputs(newTd);
			cells[index].after(newTd);
		});
		reindexRows(tbody, theadRow);
	}

	function insertRowAfter(tbody, theadRow, index, role, cap) {
		var rows = tbody.querySelectorAll('tr');
		if (totalDataRowCount(tbody) >= cap.maxRows || !rows[index]) {
			return;
		}
		var newTr = rows[rows.length - 1].cloneNode(true);
		clearInputs(newTr);
		newTr.querySelectorAll('td.dsm-table-library-cell').forEach(
			function (cell) {
				clearInputs(cell);
			}
		);
		setRowRole(newTr, role);
		syncRowRole(newTr);
		rows[index].after(newTr);
		reindexRows(tbody, theadRow);
	}

	function bindSortable(tbody, theadRow) {
		if (!window.jQuery || !window.jQuery.fn || !window.jQuery.fn.sortable) {
			return;
		}
		window.jQuery(tbody).sortable({
			items: '> tr',
			handle: '.dsm-table-library-row-handle',
			axis: 'y',
			cancel: 'input, select, textarea, button, a',
			placeholder: 'dsm-table-library-row-placeholder',
			helper: 'clone',
			update: function () {
				reindexRows(tbody, theadRow);
			},
		});
	}

	ready(function () {
		bindCsvImport();

		var wrap = document.getElementById('dsm-table-library-editor');
		if (!wrap) {
			return;
		}

		var table = wrap.querySelector('.dsm-table-library-editor');
		if (!table) {
			return;
		}

		var theadRow = table.querySelector('thead tr');
		var tbody = table.querySelector('tbody');
		if (!theadRow || !tbody) {
			return;
		}

		var cap = limits();
		var root = wrap.parentElement || document;
		var lastPick = null;

		bindSortable(tbody, theadRow);
		applyCoveredStyles(theadRow, tbody);
		updateSelectionChrome(theadRow, tbody, root);

		function applyPick(td, event) {
			if (event.shiftKey && lastPick) {
				selectRange(tbody, lastPick, td);
			} else if (event.metaKey || event.ctrlKey) {
				td.classList.toggle('is-selected');
			} else if (td.classList.contains('is-selected')) {
				td.classList.remove('is-selected');
			} else {
				clearSelection(tbody);
				td.classList.add('is-selected');
			}
			lastPick = td;
			updateSelectionChrome(theadRow, tbody, root);
		}

		root.addEventListener('change', function (event) {
			var target = event.target;
			if (!target || !target.closest) {
				return;
			}
			if (
				target.classList.contains('dsm-table-library-row-check') ||
				target.classList.contains('dsm-table-library-col-check') ||
				target.classList.contains('dsm-table-library-role')
			) {
				updateSelectionChrome(theadRow, tbody, root);
			}
			if (target.hasAttribute('data-dsm-table-toolbar-type')) {
				var nextType = target.value;
				if (!nextType) {
					return;
				}
				var selected = selectedCells(tbody);
				selected.forEach(function (td) {
					applyTypeToCell(td, nextType);
				});
				if (
					nextType === 'rich_text' &&
					selected.length === 1 &&
					canApplyType(selected[0], 'rich_text')
				) {
					openRichEditor(selected[0]);
				}
				syncToolbarCellType(root, tbody);
			}
		});

		document.addEventListener('click', function (event) {
			var hit = event.target;
			if (!hit || !hit.closest) {
				return;
			}

			var apply = hit.closest('[data-dsm-table-rich-apply]');
			if (apply) {
				event.preventDefault();
				applyRichEditor();
				return;
			}

			var cancel = hit.closest('[data-dsm-table-rich-cancel]');
			if (cancel) {
				event.preventDefault();
				closeRichEditor();
				return;
			}

			var modal = document.getElementById(
				'dsm-table-library-rich-modal'
			);
			if (modal && !modal.hidden && hit === modal) {
				closeRichEditor();
				return;
			}

			var openRich = hit.closest('[data-dsm-table-rich-edit]');
			if (openRich) {
				event.preventDefault();
				var richTd = openRich.closest('td.dsm-table-library-cell');
				if (richTd) {
					openRichEditor(richTd);
				}
			}
		});

		document.addEventListener('keydown', function (event) {
			if (event.key !== 'Escape') {
				return;
			}
			var openModal = document.getElementById(
				'dsm-table-library-rich-modal'
			);
			if (openModal && !openModal.hidden) {
				event.preventDefault();
				closeRichEditor();
			}
		});

		var postForm = document.getElementById('post');
		if (postForm) {
			postForm.addEventListener('submit', function () {
				closeRichEditor();
				var scratch = document.getElementById(richEditorId());
				if (scratch) {
					scratch.disabled = true;
					scratch.name = '';
				}
			});
		}

		root.addEventListener('click', function (event) {
			var target = event.target;
			if (!target || !target.closest) {
				return;
			}

			if (
				target.closest('[data-dsm-table-rich-edit]') ||
				target.closest('[data-dsm-table-toolbar-type]') ||
				target.closest('.dsm-table-library-cell-type')
			) {
				return;
			}

			var pick = target.closest('.dsm-table-library-cell-pick');
			if (pick) {
				event.preventDefault();
				var td = pick.closest('td.dsm-table-library-cell');
				if (!td) {
					return;
				}
				applyPick(td, event);
				return;
			}

			var cellHit = target.closest('td.dsm-table-library-cell');
			if (
				cellHit &&
				target.closest('.dsm-table-library-editor') &&
				(event.shiftKey || event.metaKey || event.ctrlKey) &&
				!target.closest('button')
			) {
				event.preventDefault();
				applyPick(cellHit, event);
				return;
			}

			var insertCol = target.closest('[data-dsm-table-insert-col]');
			if (insertCol) {
				event.preventDefault();
				var insertTh = insertCol.closest(
					'th.dsm-table-library-header-cell'
				);
				if (!insertTh) {
					return;
				}
				var colIndex = Array.prototype.indexOf.call(
					dataHeaders(theadRow),
					insertTh
				);
				if (colIndex >= 0) {
					insertColumnAfter(theadRow, tbody, colIndex, cap);
					updateSelectionChrome(theadRow, tbody, root);
				}
				return;
			}

			var insertRow = target.closest('[data-dsm-table-insert-row]');
			if (insertRow) {
				event.preventDefault();
				var insertTr = insertRow.closest('tr');
				if (!insertTr || !tbody.contains(insertTr)) {
					return;
				}
				var rowIndex = Array.prototype.indexOf.call(
					tbody.querySelectorAll('tr'),
					insertTr
				);
				if (rowIndex >= 0) {
					insertRowAfter(
						tbody,
						theadRow,
						rowIndex,
						insertRow.getAttribute('data-dsm-table-row-role'),
						cap
					);
					updateSelectionChrome(theadRow, tbody, root);
				}
				return;
			}

			var addCol = target.closest('[data-dsm-table-add-col]');
			if (addCol) {
				event.preventDefault();
				if (dataHeaders(theadRow).length >= cap.maxCols) {
					return;
				}
				var lastTh = theadRow.querySelector(
					'th:not(.dsm-table-library-rowmeta):last-of-type'
				);
				if (!lastTh) {
					return;
				}
				var newTh = lastTh.cloneNode(true);
				clearInputs(newTh);
				theadRow.appendChild(newTh);
				tbody.querySelectorAll('tr').forEach(function (tr) {
					var lastTd = tr.querySelector(
						'td.dsm-table-library-cell:last-of-type'
					);
					if (!lastTd) {
						return;
					}
					var newTd = lastTd.cloneNode(true);
					clearInputs(newTd);
					tr.appendChild(newTd);
				});
				reindexRows(tbody, theadRow);
				updateSelectionChrome(theadRow, tbody, root);
				return;
			}

			var removeCol = target.closest('[data-dsm-table-remove-col]');
			if (removeCol) {
				event.preventDefault();
				if (dataHeaders(theadRow).length <= 1) {
					return;
				}
				var removeTh = theadRow.querySelector(
					'th:not(.dsm-table-library-rowmeta):last-of-type'
				);
				if (removeTh) {
					removeTh.remove();
				}
				tbody.querySelectorAll('tr').forEach(function (tr) {
					var removeTd = tr.querySelector(
						'td.dsm-table-library-cell:last-of-type'
					);
					if (removeTd) {
						removeTd.remove();
					}
				});
				shrinkOverflowingSpans(theadRow, tbody);
				reindexRows(tbody, theadRow);
				updateSelectionChrome(theadRow, tbody, root);
				return;
			}

			var addRow = target.closest('[data-dsm-table-add-row]');
			if (addRow) {
				event.preventDefault();
				if (totalDataRowCount(tbody) >= cap.maxRows) {
					return;
				}
				var lastTr = tbody.querySelector('tr:last-of-type');
				if (!lastTr) {
					return;
				}
				var newTr = lastTr.cloneNode(true);
				clearInputs(newTr);
				newTr.querySelectorAll('td.dsm-table-library-cell').forEach(
					function (cell) {
						clearInputs(cell);
					}
				);
				setRowRole(
					newTr,
					addRow.getAttribute('data-dsm-table-row-role')
				);
				tbody.appendChild(newTr);
				syncRowRole(newTr);
				reindexRows(tbody, theadRow);
				updateSelectionChrome(theadRow, tbody, root);
				return;
			}

			var removeRow = target.closest('[data-dsm-table-remove-row]');
			if (removeRow) {
				event.preventDefault();
				if (tbody.querySelectorAll('tr').length <= 1) {
					return;
				}
				var removeTr = tbody.querySelector('tr:last-of-type');
				if (removeTr) {
					removeTr.remove();
				}
				shrinkOverflowingSpans(theadRow, tbody);
				reindexRows(tbody, theadRow);
				updateSelectionChrome(theadRow, tbody, root);
				return;
			}

			var removeSelectedBtn = target.closest(
				'[data-dsm-table-remove-selected]'
			);
			if (removeSelectedBtn) {
				event.preventDefault();
				removeSelected(theadRow, tbody);
				updateSelectionChrome(theadRow, tbody, root);
				return;
			}

			var mergeBtn = target.closest('[data-dsm-table-merge]');
			if (mergeBtn) {
				event.preventDefault();
				mergeSelected(tbody, theadRow);
				updateSelectionChrome(theadRow, tbody, root);
				return;
			}

			var splitBtn = target.closest('[data-dsm-table-split]');
			if (splitBtn) {
				event.preventDefault();
				splitSelected(tbody, theadRow);
				updateSelectionChrome(theadRow, tbody, root);
			}
		});
	});
})();
