window.addEventListener( 'DOMContentLoaded', () => {
	jQuery( function ( $ ) {
		const gsap = window.gsap;
		if ( ! gsap ) {
			return;
		}

		/**
		 * Sync with `packages/module-library/image-reveal/overlay-wipe.js`.
		 *
		 * @param {string|undefined} direction Raw attr value.
		 * @return {object}
		 */
		function getOverlayWipePlan( direction ) {
			const d =
				direction != null && String( direction ).trim() !== ''
					? String( direction ).trim()
					: 'lr';

			switch ( d ) {
				case 'rl':
					return {
						initialSet: {
							scaleX: 0,
							scaleY: 1,
							visibility: 'hidden',
							transformOrigin: 'right top',
						},
						showFrom: {
							scaleX: 0,
							scaleY: 1,
							transformOrigin: 'right top',
							visibility: 'visible',
						},
						showTo: { scaleX: 1 },
						onShowCompleteSetOrigin: 'left top',
						hideTo: { scaleX: 0, transformOrigin: 'left top' },
					};
				case 'tb':
					return {
						initialSet: {
							scaleX: 1,
							scaleY: 0,
							visibility: 'hidden',
							transformOrigin: 'left top',
						},
						showFrom: {
							scaleX: 1,
							scaleY: 0,
							transformOrigin: 'left top',
							visibility: 'visible',
						},
						showTo: { scaleY: 1 },
						onShowCompleteSetOrigin: 'left bottom',
						hideTo: { scaleY: 0, transformOrigin: 'left bottom' },
					};
				case 'bt':
					return {
						initialSet: {
							scaleX: 1,
							scaleY: 0,
							visibility: 'hidden',
							transformOrigin: 'left bottom',
						},
						showFrom: {
							scaleX: 1,
							scaleY: 0,
							transformOrigin: 'left bottom',
							visibility: 'visible',
						},
						showTo: { scaleY: 1 },
						onShowCompleteSetOrigin: 'left top',
						hideTo: { scaleY: 0, transformOrigin: 'left top' },
					};
				case 'center':
					return {
						initialSet: {
							scaleX: 0,
							scaleY: 0,
							visibility: 'hidden',
							transformOrigin: 'center center',
						},
						showFrom: {
							scaleX: 0,
							scaleY: 0,
							transformOrigin: 'center center',
							visibility: 'visible',
						},
						showTo: { scaleX: 1, scaleY: 1 },
						onShowCompleteSetOrigin: 'center center',
						hideTo: {
							scaleX: 0,
							scaleY: 0,
							transformOrigin: 'center center',
						},
					};
				case 'lr':
				default:
					return {
						initialSet: {
							scaleX: 0,
							scaleY: 1,
							visibility: 'hidden',
							transformOrigin: 'left top',
						},
						showFrom: {
							scaleX: 0,
							scaleY: 1,
							transformOrigin: 'left top',
							visibility: 'visible',
						},
						showTo: { scaleX: 1 },
						onShowCompleteSetOrigin: 'right top',
						hideTo: { scaleX: 0, transformOrigin: 'right top' },
					};
			}
		}

		function normalizeOverlayDirection( raw ) {
			const allowed = {
				lr: true,
				rl: true,
				tb: true,
				bt: true,
				center: true,
			};
			const s =
				raw != null && String( raw ).trim() !== ''
					? String( raw ).trim()
					: 'lr';
			return allowed[ s ] ? s : 'lr';
		}

		function normalizeRevealTrigger( raw ) {
			const allowed = { hover: true, click: true, scroll: true };
			const s =
				raw != null && String( raw ).trim() !== ''
					? String( raw ).trim()
					: 'hover';
			return allowed[ s ] ? s : 'hover';
		}

		function rangeOrCssToSeconds( raw ) {
			if ( raw == null || raw === '' ) {
				return 0;
			}
			const s = String( raw ).trim().replace( /\s+/g, '' );
			if ( /^[\d.]+ms$/i.test( s ) ) {
				const n = parseFloat( s );
				return window.isNaN( n ) ? 0 : n / 1000;
			}
			if ( /^[\d.]+s$/i.test( s ) ) {
				const n = parseFloat( s );
				return window.isNaN( n ) ? 0 : n;
			}
			if ( /^[\d.]+$/.test( s ) ) {
				const n = parseFloat( s );
				return window.isNaN( n ) ? 0 : n;
			}
			const n = parseFloat( s );
			return window.isNaN( n ) ? 0 : n;
		}

		function rangeOrCssToCssTimeString( raw, fallbackSec ) {
			if ( raw == null || String( raw ).trim() === '' ) {
				return `${ fallbackSec }s`;
			}
			const s = String( raw ).trim().replace( /\s+/g, '' );
			if ( /^[\d.]+ms$/i.test( s ) ) {
				return s.toLowerCase();
			}
			if ( /^[\d.]+s$/i.test( s ) ) {
				return s;
			}
			if ( /^[\d.]+$/.test( s ) ) {
				return `${ s }s`;
			}
			const n = parseFloat( s );
			return window.isNaN( n ) ? `${ fallbackSec }s` : `${ n }s`;
		}

		Splitting();

		$( '.dsm_image_text_reveal' ).each( function () {
			const $container = $( this );
			const $wrap = $container.find( '.dsm-image-wrapper' ).first();
			if ( ! $wrap.length ) {
				return;
			}

			const overlayDirRaw = $wrap.attr( 'data-overlay-direction' );
			const triggerRaw = $wrap.attr( 'data-reveal-trigger' );
			const overlayDir = normalizeOverlayDirection( overlayDirRaw );
			const triggerMode = normalizeRevealTrigger( triggerRaw );

			const $overlay = $wrap.find( '.dsm-image-reveal-overlay' );
			const overlayEl = $overlay[ 0 ];
			let revealDelayTimer = null;
			let clickOpen = false;
			let io = null;

			if ( ! overlayEl ) {
				return;
			}

			const animationName = $wrap.attr( 'data-reveal-animation' );
			const animationDurationRaw = $wrap.attr( 'data-duration-animation' );
			const animationDelayRaw = $wrap.attr( 'data-delay-animation' );

			const durationCss = rangeOrCssToCssTimeString(
				animationDurationRaw,
				0.5
			);
			const delaySec = rangeOrCssToSeconds( animationDelayRaw );

			function showOverlay( plan, callback = () => {} ) {
				const delayMs = delaySec * 1000;
				gsap.fromTo(
					overlayEl,
					plan.showFrom,
					Object.assign( {}, plan.showTo, {
						ease: 'expo.inOut',
						duration: 0.4,
						delay: 0.1,
						onStart: () =>
							$container.addClass( 'dsm-image-reveal-hover' ),
						onComplete: () => {
							if ( plan.onShowCompleteSetOrigin ) {
								overlayEl.style.transformOrigin =
									plan.onShowCompleteSetOrigin;
							}
							if ( revealDelayTimer !== null ) {
								window.clearTimeout( revealDelayTimer );
							}
							revealDelayTimer = window.setTimeout( () => {
								revealDelayTimer = null;
								$container.addClass( 'dsm-image-revealed' );
								window.requestAnimationFrame( () => {
									callback();
								} );
							}, delayMs );
						},
					} )
				);
			}

			function hideOverlay( plan ) {
				if ( revealDelayTimer !== null ) {
					window.clearTimeout( revealDelayTimer );
					revealDelayTimer = null;
				}
				const hideOrigin = plan.hideTo.transformOrigin;
				const hideTween = Object.assign( {}, plan.hideTo );
				delete hideTween.transformOrigin;
				gsap.set( overlayEl, { transformOrigin: hideOrigin } );
				gsap.to(
					overlayEl,
					Object.assign( {}, hideTween, {
						ease: 'expo.inOut',
						duration: 0.4,
						onComplete: () => {
							$container.removeClass( 'dsm-image-revealed' );
							$container.removeClass( 'dsm-image-reveal-hover' );
						},
					} )
				);
			}

			function resetOverlayHidden( plan ) {
				gsap.killTweensOf( overlayEl );
				gsap.set( overlayEl, { clearProps: 'transform,transformOrigin' } );
				gsap.set( overlayEl, plan.initialSet );
				$container.removeClass(
					'dsm-image-revealed dsm-image-reveal-hover'
				);
				if ( revealDelayTimer !== null ) {
					window.clearTimeout( revealDelayTimer );
					revealDelayTimer = null;
				}
			}

			function playIn() {
				const plan = getOverlayWipePlan( overlayDir );
				resetOverlayHidden( plan );
				showOverlay( plan, () => {
					animateCharsIn();
				} );
			}

			function playOut() {
				const plan = getOverlayWipePlan( overlayDir );
				animateCharsOut();
				hideOverlay( plan );
			}

			function animateCharsIn() {
				const $chars = $container.find( '.char' );
				$chars.each( function ( i, el ) {
					const $char = $( el );

					$char.removeClass( `animated ${ animationName }` );
					void el.offsetWidth;

					$char.css( {
						'animation-name': animationName,
						'animation-duration': durationCss,
						'animation-delay': `${ delaySec + i * 0.05 }s`,
						'animation-fill-mode': 'both',
					} );

					$char.addClass( 'animated' );
				} );
			}

			function animateCharsOut() {
				const $chars = $container.find( '.char' );
				$chars.each( function ( i, el ) {
					const $char = $( el );
					$char.removeClass( `animated ${ animationName }` );
					void el.offsetWidth;

					$char.css( {
						'animation-name': 'fadeOut',
						'animation-duration': durationCss,
						'animation-delay': `${ i * 0.05 }s`,
						'animation-fill-mode': 'both',
					} );

					$char.addClass( 'animated' );
				} );
			}

			if ( triggerMode === 'hover' ) {
				$container.on( 'mouseenter', function () {
					if ( revealDelayTimer !== null ) {
						window.clearTimeout( revealDelayTimer );
						revealDelayTimer = null;
					}
					const plan = getOverlayWipePlan( overlayDir );
					resetOverlayHidden( plan );
					showOverlay( plan, () => {
						animateCharsIn();
					} );
				} );
				$container.on( 'mouseleave', function () {
					animateCharsOut();
					hideOverlay( getOverlayWipePlan( overlayDir ) );
				} );
				return;
			}

			if ( triggerMode === 'click' ) {
				$wrap.on( 'click', function ( ev ) {
					if ( $( ev.target ).closest( 'a.dsm-image-reveal-link' ).length ) {
						return;
					}
					ev.preventDefault();
					if ( clickOpen ) {
						clickOpen = false;
						playOut();
					} else {
						clickOpen = true;
						playIn();
					}
				} );
				return;
			}

			if ( triggerMode === 'scroll' ) {
				const startHidden = getOverlayWipePlan( overlayDir );
				resetOverlayHidden( startHidden );
				if ( ! window.IntersectionObserver ) {
					playIn();
					return;
				}
				io = new IntersectionObserver(
					( entries ) => {
						entries.forEach( ( entry ) => {
							if ( entry.isIntersecting ) {
								if ( io ) {
									io.disconnect();
									io = null;
								}
								playIn();
							}
						} );
					},
					{ threshold: 0.15, rootMargin: '0px 0px -5% 0px' }
				);
				io.observe( $container[ 0 ] );
			}
		} );
	} );
} );
