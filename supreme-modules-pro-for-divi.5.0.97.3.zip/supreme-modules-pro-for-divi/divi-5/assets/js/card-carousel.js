/**
 * Card Carousel: Swiper + lightbox. Magnific Popup requires jQuery; all other logic is plain DOM.
 */
( function () {
	'use strict';

	var cardCarouselSwipers = [];
	var resizeScheduled = false;
	var resizeListenerBound = false;

	function scheduleAllSwipersResize() {
		if ( resizeScheduled ) {
			return;
		}
		resizeScheduled = true;
		requestAnimationFrame( function () {
			resizeScheduled = false;
			for ( var i = 0; i < cardCarouselSwipers.length; i++ ) {
				var s = cardCarouselSwipers[ i ];
				if ( s && s.el ) {
					syncCardCarouselEqualHeightClass( s.el, s.el._dsmCardParams );
				}
				if ( s && typeof s.updateSize === 'function' ) {
					try {
						s.updateSize();
						s.update();
					} catch ( e ) {
						// Swiper may be destroyed.
					}
				}
			}
		} );
	}

	/**
	 * @param {*} value
	 * @return {boolean}
	 */
	function isEmptyResponsiveLeaf( value ) {
		return (
			value === undefined ||
			value === null ||
			value === '' ||
			( typeof value === 'string' && '' === value.trim() )
		);
	}

	/**
	 * Inherit on/off across desktop → tablet → phone.
	 *
	 * @param {*} desktop
	 * @param {*} tablet
	 * @param {*} phone
	 * @return {{ desktop: boolean, tablet: boolean, phone: boolean }}
	 */
	function inheritToggleAcrossBreakpoints( desktop, tablet, phone ) {
		var d =
			desktop === true ||
			desktop === 'on' ||
			desktop === 'true' ||
			desktop === 1 ||
			desktop === '1';
		var t = isEmptyResponsiveLeaf( tablet )
			? d
			: tablet === true ||
			  tablet === 'on' ||
			  tablet === 'true' ||
			  tablet === 1 ||
			  tablet === '1';
		var p = isEmptyResponsiveLeaf( phone )
			? t
			: phone === true ||
			  phone === 'on' ||
			  phone === 'true' ||
			  phone === 1 ||
			  phone === '1';

		return { desktop: d, tablet: t, phone: p };
	}

	/**
	 * Inherit a positive integer across desktop → tablet → phone.
	 *
	 * @param {*}    desktop
	 * @param {*}    tablet
	 * @param {*}    phone
	 * @param {number} fallback
	 * @return {{ desktop: number, tablet: number, phone: number }}
	 */
	function inheritNumberAcrossBreakpoints( desktop, tablet, phone, fallback ) {
		var d = parseInt( desktop, 10 );
		if ( isNaN( d ) ) {
			d = fallback;
		}
		var t = isEmptyResponsiveLeaf( tablet ) ? d : parseInt( tablet, 10 );
		if ( isNaN( t ) ) {
			t = d;
		}
		var p = isEmptyResponsiveLeaf( phone ) ? t : parseInt( phone, 10 );
		if ( isNaN( p ) ) {
			p = t;
		}

		return { desktop: d, tablet: t, phone: p };
	}

	/**
	 * Configured Swiper min-widths (phone is the default / root params).
	 *
	 * @param {Record<string, *>} params
	 * @return {{ tabletMin: number, desktopMin: number }}
	 */
	function getCardCarouselBreakpointMins( params ) {
		var tabletMin = parseInt( params && params.bp_tablet_min, 10 );
		var desktopMin = parseInt( params && params.bp_desktop_min, 10 );

		return {
			tabletMin: ! isNaN( tabletMin ) && tabletMin > 0 ? tabletMin : 768,
			desktopMin:
				! isNaN( desktopMin ) && desktopMin > 0 ? desktopMin : 981,
		};
	}

	/**
	 * Toggle the equal-height class to match the active viewport (existing SCSS).
	 *
	 * @param {Element}           wrap
	 * @param {Record<string, *>} params
	 * @return {void}
	 */
	function syncCardCarouselEqualHeightClass( wrap, params ) {
		if ( ! wrap || ! params ) {
			return;
		}

		var moduleEl =
			typeof wrap.closest === 'function'
				? wrap.closest( '.dsm_card_carousel' )
				: null;
		if ( ! moduleEl || ! moduleEl.classList ) {
			return;
		}

		if ( 'on' === params.multiple_slide_row ) {
			moduleEl.classList.remove( 'dsm_card_carousel_equal_height' );
			return;
		}

		var eq = inheritToggleAcrossBreakpoints(
			params.equal_height,
			params.equal_height_tablet,
			params.equal_height_phone
		);
		var mins = getCardCarouselBreakpointMins( params );
		var width = window.innerWidth;
		var on =
			width >= mins.desktopMin
				? eq.desktop
				: width >= mins.tabletMin
				? eq.tablet
				: eq.phone;

		moduleEl.classList.toggle( 'dsm_card_carousel_equal_height', on );
	}

	function bindGlobalResizeOnce() {
		if ( resizeListenerBound ) {
			return;
		}
		resizeListenerBound = true;
		window.addEventListener( 'resize', scheduleAllSwipersResize, {
			passive: true,
		} );
	}

	var DSM_CARD_CAROUSEL_LOOP_MINIMUM_CLONE_CLASS =
		'dsm-card-carousel-loop-minimum-clone';

	/**
	 * Swiper 12 loop requires slide count >= slidesPerView + slidesPerGroup (+1 when centered).
	 *
	 * @param {number}  slidesPerView
	 * @param {number}  slidesPerGroup
	 * @param {boolean} centeredSlides
	 * @return {number}
	 */
	function getDsmSwiperLoopMinimumSlideCount(
		slidesPerView,
		slidesPerGroup,
		centeredSlides
	) {
		var spv = Math.max( 1, Number( slidesPerView ) || 1 );
		var spg = Math.max( 1, Number( slidesPerGroup ) || 1 );
		var centeredExtra = centeredSlides ? 1 : 0;

		return spv + spg + centeredExtra;
	}

	/**
	 * Slide count Swiper loop needs so it does not insert `.swiper-slide-blank`.
	 *
	 * Swiper 12 `loopAddBlankSlides` (default on) pads empty slides when
	 * `slideCount % slidesPerGroup !== 0` (7 cards / group 3 → 2 blanks).
	 *
	 * @param {number}  slideCount
	 * @param {number}  slidesPerView
	 * @param {number}  slidesPerGroup
	 * @param {boolean} centeredSlides
	 * @return {number}
	 */
	function getDsmSwiperLoopTargetSlideCount(
		slideCount,
		slidesPerView,
		slidesPerGroup,
		centeredSlides
	) {
		var group = Math.max( 1, Number( slidesPerGroup ) || 1 );
		var count = Math.max( 0, Number( slideCount ) || 0 );
		var target = Math.max(
			count,
			getDsmSwiperLoopMinimumSlideCount(
				slidesPerView,
				group,
				centeredSlides
			)
		);
		var remainder = target % group;

		if ( 0 !== remainder ) {
			target += group - remainder;
		}

		return target;
	}

	/**
	 * @param {Element} wrapper Swiper wrapper element.
	 * @return {HTMLElement[]}
	 */
	function getDsmCarouselRealSlideElements( wrapper ) {
		if ( ! wrapper || typeof wrapper.children === 'undefined' ) {
			return [];
		}

		return Array.prototype.filter.call( wrapper.children, function ( slide ) {
			return (
				slide.nodeType === 1 &&
				! slide.classList.contains( 'swiper-slide-duplicate' ) &&
				! slide.classList.contains( 'swiper-slide-blank' ) &&
				! slide.classList.contains(
					DSM_CARD_CAROUSEL_LOOP_MINIMUM_CLONE_CLASS
				)
			);
		} );
	}

	/**
	 * Remove pre-init clones added so Swiper loop can activate when slide count == perView.
	 *
	 * @param {Element|null|undefined} swiperRoot `.swiper` element or wrapper parent.
	 * @return {void}
	 */
	function removeDsmCardCarouselLoopMinimumClones( swiperRoot ) {
		if ( ! swiperRoot || typeof swiperRoot.querySelector !== 'function' ) {
			return;
		}

		var wrapper = swiperRoot.classList.contains( 'swiper-wrapper' )
			? swiperRoot
			: swiperRoot.querySelector( '.swiper-wrapper' );

		if ( ! wrapper ) {
			return;
		}

		wrapper
			.querySelectorAll(
				'.' +
					DSM_CARD_CAROUSEL_LOOP_MINIMUM_CLONE_CLASS +
					', .swiper-slide-blank'
			)
			.forEach( function ( node ) {
				if ( node.parentNode ) {
					node.parentNode.removeChild( node );
				}
			} );
	}

	/**
	 * Strip Swiper runtime classes/attrs from a pre-init loop pad clone.
	 *
	 * @param {HTMLElement} clone Cloned slide element.
	 * @return {void}
	 */
	function sanitizeDsmCardCarouselLoopMinimumClone( clone ) {
		[
			'swiper-slide-active',
			'swiper-slide-next',
			'swiper-slide-prev',
			'swiper-slide-fully-visible',
			'swiper-slide-visible',
		].forEach( function ( cls ) {
			clone.classList.remove( cls );
		} );

		clone.removeAttribute( 'data-swiper-slide-index' );
		clone.classList.add( DSM_CARD_CAROUSEL_LOOP_MINIMUM_CLONE_CLASS );
		clone.setAttribute( 'aria-hidden', 'true' );
	}

	/**
	 * Clone real slides until Swiper loop can fill every visible column.
	 *
	 * Append full cycles of the real slide list (not a lone first-slide pad).
	 * Also reach a multiple of slidesPerGroup so Swiper 12 does not insert
	 * `.swiper-slide-blank` (7 cards / group 3 → empty columns).
	 *
	 * @param {Element|null|undefined} swiperRoot `.swiper` module root.
	 * @param {{ loop?: boolean, slidesPerView?: number, slidesPerGroup?: number, centeredSlides?: boolean }} options
	 * @return {void}
	 */
	function ensureDsmCardCarouselLoopMinimumSlides( swiperRoot, options ) {
		if ( ! swiperRoot || ! options || ! options.loop ) {
			return;
		}

		var wrapper = swiperRoot.querySelector( '.swiper-wrapper' );
		if ( ! wrapper ) {
			return;
		}

		removeDsmCardCarouselLoopMinimumClones( swiperRoot );

		var realSlides = getDsmCarouselRealSlideElements( wrapper );
		var slideCount = realSlides.length;

		if ( slideCount === 0 ) {
			return;
		}

		var group = Math.max( 1, Number( options.slidesPerGroup ) || 1 );
		var targetSlides = getDsmSwiperLoopTargetSlideCount(
			slideCount,
			options.slidesPerView,
			group,
			!! options.centeredSlides
		);

		if ( slideCount >= targetSlides && 0 === slideCount % group ) {
			return;
		}

		var totalSlides = slideCount;
		var maxSlides = targetSlides + slideCount * group;

		while (
			( totalSlides < targetSlides || 0 !== totalSlides % group ) &&
			totalSlides < maxSlides
		) {
			for ( var i = 0; i < slideCount; i++ ) {
				var source = realSlides[ i ];
				if ( ! source ) {
					continue;
				}

				var clone = source.cloneNode( true );
				sanitizeDsmCardCarouselLoopMinimumClone( clone );
				wrapper.appendChild( clone );
				totalSlides += 1;
			}
		}
	}

	/**
	 * @param {import('swiper').Swiper} swiperInstance Swiper instance.
	 * @return {{ realCount: number, activeIndex: number }}
	 */
	function getDsmCardCarouselPaginationIndexState( swiperInstance ) {
		if ( ! swiperInstance || ! swiperInstance.el ) {
			return { realCount: 0, activeIndex: 0 };
		}

		var wrapper = swiperInstance.el.querySelector( '.swiper-wrapper' );
		var realSlides = getDsmCarouselRealSlideElements( wrapper );
		var realCount = realSlides.length;
		if ( realCount <= 0 ) {
			return { realCount: 0, activeIndex: 0 };
		}

		var realIndex =
			typeof swiperInstance.realIndex === 'number'
				? swiperInstance.realIndex
				: 0;

		return {
			realCount: realCount,
			activeIndex: ( ( realIndex % realCount ) + realCount ) % realCount,
		};
	}

	/**
	 * Custom pagination: one bullet per real child (excludes loop pad clones).
	 *
	 * @param {import('swiper').Swiper} swiperInstance Swiper instance.
	 * @return {string}
	 */
	function renderDsmCardCarouselPaginationHtml( swiperInstance ) {
		var state = getDsmCardCarouselPaginationIndexState( swiperInstance );
		var realCount = state.realCount;
		var activeIndex = state.activeIndex;
		if ( realCount <= 0 ) {
			return '';
		}

		var bulletClass =
			( swiperInstance.params &&
				swiperInstance.params.pagination &&
				swiperInstance.params.pagination.bulletClass ) ||
			'swiper-pagination-bullet';
		var activeClass =
			( swiperInstance.params &&
				swiperInstance.params.pagination &&
				swiperInstance.params.pagination.bulletActiveClass ) ||
			'swiper-pagination-bullet-active';
		var html = '';
		var i;

		for ( i = 0; i < realCount; i++ ) {
			html +=
				'<span class="' +
				bulletClass +
				( i === activeIndex ? ' ' + activeClass : '' ) +
				'"></span>';
		}

		return html;
	}

	/**
	 * Custom dynamic-style bullets (real children only) when loop pads block
	 * Swiper's native dynamicBullets.
	 *
	 * @param {import('swiper').Swiper} swiperInstance Swiper instance.
	 * @return {string}
	 */
	function renderDsmCardCarouselDynamicPaginationHtml( swiperInstance ) {
		var state = getDsmCardCarouselPaginationIndexState( swiperInstance );
		var realCount = state.realCount;
		var activeIndex = state.activeIndex;
		if ( realCount <= 0 ) {
			return '';
		}

		var bulletClass =
			( swiperInstance.params &&
				swiperInstance.params.pagination &&
				swiperInstance.params.pagination.bulletClass ) ||
			'swiper-pagination-bullet';
		var activeClass =
			( swiperInstance.params &&
				swiperInstance.params.pagination &&
				swiperInstance.params.pagination.bulletActiveClass ) ||
			'swiper-pagination-bullet-active';
		var html = '';
		var i;
		var dist;
		var classes;

		for ( i = 0; i < realCount; i++ ) {
			dist = Math.abs( i - activeIndex );
			classes = bulletClass;
			if ( 0 === dist ) {
				classes += ' ' + activeClass + ' ' + activeClass + '-main';
			} else if ( 1 === dist ) {
				classes +=
					' ' +
					activeClass +
					( i < activeIndex ? '-prev' : '-next' );
			} else if ( 2 === dist ) {
				classes +=
					' ' +
					activeClass +
					( i < activeIndex ? '-prev-prev' : '-next-next' );
			}
			html += '<span class="' + classes + '"></span>';
		}

		return html;
	}

	/**
	 * Custom progressbar sized by real children (excludes loop pad clones).
	 *
	 * @param {import('swiper').Swiper} swiperInstance Swiper instance.
	 * @return {string}
	 */
	function renderDsmCardCarouselProgressbarHtml( swiperInstance ) {
		var state = getDsmCardCarouselPaginationIndexState( swiperInstance );
		var realCount = state.realCount;
		var activeIndex = state.activeIndex;
		var fillClass =
			( swiperInstance.params &&
				swiperInstance.params.pagination &&
				swiperInstance.params.pagination.progressbarFillClass ) ||
			'swiper-pagination-progressbar-fill';
		var progress = realCount > 0 ? ( activeIndex + 1 ) / realCount : 0;
		var isHorizontal =
			! swiperInstance ||
			typeof swiperInstance.isHorizontal !== 'function' ||
			swiperInstance.isHorizontal();
		var scaleX = isHorizontal ? progress : 1;
		var scaleY = isHorizontal ? 1 : progress;
		var speed =
			swiperInstance.params &&
			typeof swiperInstance.params.speed === 'number'
				? swiperInstance.params.speed
				: 300;

		return (
			'<span class="' +
			fillClass +
			'" style="transform: translate3d(0px, 0, 0) scaleX(' +
			scaleX +
			') scaleY(' +
			scaleY +
			'); transition-duration: ' +
			speed +
			'ms;"></span>'
		);
	}

	/**
	 * Build Swiper pagination options for Card Carousel pagi_style.
	 *
	 * @param {HTMLElement} paginationEl Pagination container.
	 * @param {string}      pagiStyle    bullets | dynamic | progressbar.
	 * @param {Element}     wrap         Swiper root.
	 * @return {Record<string, *>}
	 */
	function getDsmCardCarouselPaginationParams(
		paginationEl,
		pagiStyle,
		wrap
	) {
		var style = pagiStyle || 'bullets';
		var hasPadClones = !! (
			wrap &&
			wrap.querySelector(
				'.' + DSM_CARD_CAROUSEL_LOOP_MINIMUM_CLONE_CLASS
			)
		);

		paginationEl.classList.remove(
			'swiper-pagination-bullets',
			'swiper-pagination-bullets-dynamic',
			'swiper-pagination-progressbar',
			'swiper-pagination-clickable',
			'swiper-pagination-custom'
		);
		// Dynamic mode leaves inline width/left/transform on the el.
		paginationEl.removeAttribute( 'style' );
		paginationEl.classList.add( 'swiper-pagination-clickable' );

		if ( 'progressbar' === style ) {
			paginationEl.classList.add( 'swiper-pagination-progressbar' );
			return {
				el: paginationEl,
				type: 'custom',
				clickable: true,
				renderCustom: function ( swiperInstance ) {
					return renderDsmCardCarouselProgressbarHtml(
						swiperInstance
					);
				},
			};
		}

		if ( 'dynamic' === style ) {
			paginationEl.classList.add(
				'swiper-pagination-bullets',
				'swiper-pagination-bullets-dynamic'
			);

			// Native dynamicBullets only when pads are not inflating slide count.
			if ( ! hasPadClones ) {
				return {
					el: paginationEl,
					type: 'bullets',
					clickable: true,
					dynamicBullets: true,
				};
			}

			return {
				el: paginationEl,
				type: 'custom',
				clickable: true,
				renderCustom: function ( swiperInstance ) {
					return renderDsmCardCarouselDynamicPaginationHtml(
						swiperInstance
					);
				},
			};
		}

		paginationEl.classList.add( 'swiper-pagination-bullets' );
		return {
			el: paginationEl,
			type: 'custom',
			clickable: true,
			renderCustom: function ( swiperInstance ) {
				return renderDsmCardCarouselPaginationHtml( swiperInstance );
			},
		};
	}

	/**
	 * Max slidesPerView / slidesPerGroup / centeredSlides across breakpoints for loop clones.
	 *
	 * @param {Record<string, *>} params Parsed `data-params` object.
	 * @return {{ slidesPerView: number, slidesPerGroup: number, centeredSlides: boolean }}
	 */
	function getMaxLoopSlidesConfigFromParams( params ) {
		var isSingle =
			'cube' === params.effect || 'flip' === params.effect;

		var spv = inheritNumberAcrossBreakpoints(
			params.slide_to_show,
			params.slide_to_show_tablet,
			params.slide_to_show_phone,
			1
		);
		var spg = inheritNumberAcrossBreakpoints(
			params.slide_to_scroll,
			params.slide_to_scroll_tablet,
			params.slide_to_scroll_phone,
			1
		);
		var centered = inheritToggleAcrossBreakpoints(
			params.centered_slides,
			params.centered_slides_tablet,
			params.centered_slides_phone
		);

		return {
			slidesPerView: isSingle
				? 1
				: Math.max( spv.desktop, spv.tablet, spv.phone ),
			slidesPerGroup: Math.max( spg.desktop, spg.tablet, spg.phone ),
			centeredSlides: centered.desktop || centered.tablet || centered.phone,
		};
	}

	/**
	 * @param {Element} wrap Carousel root (.dsm_card_carousel_wrapper).
	 * @param {string}    selector Sibling selector (e.g. .swiper-button-prev).
	 * @return {Element|null}
	 */
	function getSibling( wrap, selector ) {
		var parent = wrap.parentElement;
		if ( ! parent ) {
			return null;
		}
		var found = parent.querySelectorAll( ':scope > ' + selector );
		return found.length ? found[ 0 ] : null;
	}

	/**
	 * Magnific Popup (jQuery plugin API only).
	 */
	function initMagnificPopup() {
		if ( typeof jQuery === 'undefined' || ! jQuery.fn.magnificPopup ) {
			return;
		}
		var $ = jQuery;
		var nodes = document.querySelectorAll(
			'.dsm_card_carousel .dsm_card_carousel_child_image_wrapper'
		);
		if ( ! nodes.length ) {
			return;
		}

		var videoRe =
			/(youtube\.com|youtu\.be|vimeo\.com|dailymotion\.com)/i;

		nodes.forEach( function ( el ) {
			el.addEventListener( 'click', function () {
				var itemsSrc = el.getAttribute( 'data-mfp-src' );
				if (
					! itemsSrc ||
					itemsSrc === 'undefined' ||
					itemsSrc === ''
				) {
					return;
				}

				var type = videoRe.test( itemsSrc ) ? 'iframe' : 'image';
				var classes = '';

				$.magnificPopup.open( {
					delegate: 'a',
					items: {
						src: itemsSrc,
					},
					type: type,
					iframe: {
						markup:
							'<div class="mfp-iframe-scaler dsm-video-popup">' +
							'<div class="mfp-close"></div>' +
							'<iframe class="mfp-iframe" frameborder="0" allowfullscreen allow="autoplay"></iframe>' +
							'</div>',
						patterns: {
							youtube: {
								index: 'youtube.com/',
								id: 'v=',
								src: '//www.youtube.com/embed/%id%?autoplay=1&rel=0',
							},
							youtu_be: {
								index: 'youtu.be',
								id: '/',
								src: '//www.youtube.com/embed/%id%?autoplay=1&rel=0',
							},
							vimeo: {
								index: 'vimeo.com/',
								id: '/',
								src: '//player.vimeo.com/video/%id%?autoplay=1',
							},
							dailymotion: {
								index: 'dailymotion.com',
								id: function ( url ) {
									var m = url.match(
										/^.+dailymotion.com\/(video|hub)\/([^_]+)[^#]*(#video=([^_&]+))?/
									);
									if ( m !== null ) {
										if ( m[ 4 ] !== undefined ) {
											return m[ 4 ];
										}
										return m[ 2 ];
									}
									return null;
								},
								src: 'https://www.dailymotion.com/embed/video/%id%',
							},
						},
						srcAction: 'iframe_src',
					},
					removalDelay: 500,
					mainClass: classes + 'mfp-fade',
				} );
			} );
		} );
	}

	function startCardAutoplay( swiper ) {
		if (
			swiper &&
			swiper.autoplay &&
			typeof swiper.autoplay.start === 'function'
		) {
			swiper.autoplay.start();
		}
	}

	function destroyCardAutoplayWaypoint( wrap ) {
		if (
			wrap._dsmAutoplayWaypoint &&
			typeof wrap._dsmAutoplayWaypoint.destroy === 'function'
		) {
			wrap._dsmAutoplayWaypoint.destroy();
		}
		wrap._dsmAutoplayWaypoint = null;
	}

	function refreshCardSwiperInstance( wrap ) {
		var instance = wrap && wrap.swiper ? wrap.swiper : null;
		if ( ! instance || typeof instance.updateSize !== 'function' ) {
			return false;
		}

		try {
			syncCardCarouselEqualHeightClass( wrap, wrap._dsmCardParams );
			instance.updateSize();
			instance.update();
			if ( typeof instance.slideTo === 'function' ) {
				instance.slideTo( instance.realIndex, 0 );
			}
		} catch ( err ) {
			return false;
		}

		return true;
	}

	function initSingleCardCarousel( wrap ) {
		if ( refreshCardSwiperInstance( wrap ) ) {
			return;
		}

		var rawParams = wrap.getAttribute( 'data-params' );
			if (
				! rawParams ||
				typeof rawParams !== 'string' ||
				'' === rawParams.trim()
			) {
				return;
			}

			var parsedParams;
			try {
				parsedParams = JSON.parse( rawParams );
			} catch ( err ) {
				return;
			}
			if (
				! parsedParams ||
				typeof parsedParams !== 'object' ||
				! parsedParams[ 0 ]
			) {
				return;
			}

			var params = parsedParams[ 0 ];

			var prevButton = getSibling( wrap, '.swiper-button-prev' );
			var nextButton = getSibling( wrap, '.swiper-button-next' );
			var paginationEl = getSibling(
				wrap,
				'.swiper-pagination.dsm_card_carousel_pagination'
			);
			if ( ! paginationEl ) {
				paginationEl = getSibling( wrap, '.swiper-pagination' );
			}

			var isLoop = true === params.loop;
			var maxLoopSlides = getMaxLoopSlidesConfigFromParams( params );
			var isSingleEffect =
				'cube' === params.effect || 'flip' === params.effect;
			var isMultiRow = 'on' === params.multiple_slide_row;
			var bpMins = getCardCarouselBreakpointMins( params );
			var centeredByBp = inheritToggleAcrossBreakpoints(
				params.centered_slides,
				params.centered_slides_tablet,
				params.centered_slides_phone
			);
			var slidesPerViewByBp = inheritNumberAcrossBreakpoints(
				params.slide_to_show,
				params.slide_to_show_tablet,
				params.slide_to_show_phone,
				1
			);
			var slidesPerGroupByBp = inheritNumberAcrossBreakpoints(
				params.slide_to_scroll,
				params.slide_to_scroll_tablet,
				params.slide_to_scroll_phone,
				1
			);
			var spaceBetweenByBp = inheritNumberAcrossBreakpoints(
				params.space_between,
				params.space_between_tablet,
				params.space_between_phone,
				15
			);
			var slideRowByBp = inheritNumberAcrossBreakpoints(
				isMultiRow ? params.slide_row : 1,
				isMultiRow ? params.slide_row_tablet : 1,
				isMultiRow ? params.slide_row_phone : 1,
				1
			);
			var equalHeightByBp = inheritToggleAcrossBreakpoints(
				params.equal_height,
				params.equal_height_tablet,
				params.equal_height_phone
			);
			var autoHeightToggleByBp = inheritToggleAcrossBreakpoints(
				false !== params.auto_height && params.auto_height !== 'off',
				params.auto_height_tablet,
				params.auto_height_phone
			);

			/**
			 * @param {'desktop'|'tablet'|'phone'} bp
			 * @return {{ slidesPerView: number, slidesPerGroup: number, spaceBetween: number, grid: { rows: number, fill: string }, autoHeight: boolean, centeredSlides: boolean }}
			 */
			function swiperParamsForBreakpoint( bp ) {
				var autoHeightOn = isMultiRow
					? false
					: equalHeightByBp[ bp ]
					? false
					: autoHeightToggleByBp[ bp ];

				return {
					slidesPerView: isSingleEffect
						? 1
						: slidesPerViewByBp[ bp ],
					slidesPerGroup: isSingleEffect
						? 1
						: slidesPerGroupByBp[ bp ],
					spaceBetween: isSingleEffect
						? 0
						: spaceBetweenByBp[ bp ],
					grid: {
						rows: slideRowByBp[ bp ],
						fill: 'row',
					},
					autoHeight: autoHeightOn,
					centeredSlides: centeredByBp[ bp ],
				};
			}

			var phoneSwiperParams = swiperParamsForBreakpoint( 'phone' );
			var tabletSwiperParams = swiperParamsForBreakpoint( 'tablet' );
			var desktopSwiperParams = swiperParamsForBreakpoint( 'desktop' );
			var swiperBreakpoints = {};
			/*
			 * Swiper breakpoints are min-width only. After a tablet/desktop
			 * match, shrinking below tabletMin returns no key and setBreakpoint
			 * bails — desktop centeredSlides (and slidesPerView) stick. A 1px
			 * phone bucket (not 0: `!0` is true in Swiper's `if (!c)` guard)
			 * lets the phone settings re-apply. VB avoids this by destroying
			 * and recreating Swiper on the preview tab.
			 */
			swiperBreakpoints[ 1 ] = phoneSwiperParams;
			swiperBreakpoints[ bpMins.tabletMin ] = tabletSwiperParams;
			swiperBreakpoints[ bpMins.desktopMin ] = desktopSwiperParams;

			wrap._dsmCardParams = params;
			syncCardCarouselEqualHeightClass( wrap, params );

			var swiperOptions = {
				resizeObserver: true,
				observer: true,
				observeParents: true,
				observeSlideChildren: true,
				direction: params.direction,
				effect: params.effect,
				coverflowEffect: {
					slideShadows: params.slider_effect_shadows,
					rotate: params.slider_effect_coverflow_rotate,
					depth: params.slider_effect_coverflow_depth,
				},
				flipEffect: {
					rotate: 30,
					slideShadows: params.slider_effect_shadows,
				},
				cubeEffect: {
					slideShadows: params.slider_effect_shadows,
					shadow: params.slider_effect_shadows,
					shadowOffset: 20,
					shadowScale: 0.94,
				},
				centeredSlides: phoneSwiperParams.centeredSlides,
				speed: parseInt( params.speed, 10 ),
				loop: params.loop,
				loopAddBlankSlides: false,
				watchOverflow: ! isLoop,
				preventInteractionOnTransition: false,
				autoplay: {
					enabled: params.autoplay,
					delay:
						params.infinite_smooth_scrolling === true &&
						params.slide_to_show < 6
							? 1
							: parseInt( params.autoplay_speed, 10 ),
					disableOnInteraction: false,
				},
				mousewheel: params.mousewheel,
				grabCursor:
					false === params.touch_move ? false : params.grab,
				preloadImages: false,
				lazy: {
					loadPrevNext: true,
				},
				allowTouchMove: params.touch_move,
				a11y: {
					enabled: false,
					slideRole: 'group',
				},
				slidesPerView: phoneSwiperParams.slidesPerView,
				slidesPerGroup: phoneSwiperParams.slidesPerGroup,
				spaceBetween: phoneSwiperParams.spaceBetween,
				grid: phoneSwiperParams.grid,
				autoHeight: phoneSwiperParams.autoHeight,
				breakpoints: swiperBreakpoints,
				on: {
					breakpoint: function () {
						syncCardCarouselEqualHeightClass( wrap, params );
					},
				},
			};

			ensureDsmCardCarouselLoopMinimumSlides( wrap, {
				loop: isLoop,
				slidesPerView: maxLoopSlides.slidesPerView,
				slidesPerGroup: maxLoopSlides.slidesPerGroup,
				centeredSlides: maxLoopSlides.centeredSlides,
			} );

			if ( paginationEl ) {
				swiperOptions.pagination = getDsmCardCarouselPaginationParams(
					paginationEl,
					params.pagi_style || 'bullets',
					wrap
				);
			}

			if ( prevButton && nextButton ) {
				swiperOptions.navigation = {
					nextEl: nextButton,
					prevEl: prevButton,
				};
			}

			var DSM_CardSwiper = new Swiper( wrap, swiperOptions );
			cardCarouselSwipers.push( DSM_CardSwiper );

			if ( params.pause_on_hover === true ) {
				wrap.addEventListener( 'mouseenter', function () {
					if (
						wrap.swiper &&
						wrap.swiper.autoplay &&
						typeof wrap.swiper.autoplay.stop === 'function'
					) {
						wrap.swiper.autoplay.stop();
					}
				} );
				wrap.addEventListener( 'mouseleave', function () {
					startCardAutoplay( wrap.swiper );
				} );
			}

			var tabsRoot = wrap.closest( '.et_pb_tabs' );
			if ( tabsRoot ) {
				tabsRoot.querySelectorAll( 'a' ).forEach( function ( a ) {
					a.addEventListener( 'click', function () {
						DSM_CardSwiper.slideTo(
							DSM_CardSwiper.realIndex,
							0
						);
					} );
				} );
			}

			var advTabs = wrap.closest( '.dsm_advanced_tabs' );
			if ( advTabs ) {
				advTabs.querySelectorAll( '.dsm-tab' ).forEach( function ( tab ) {
					tab.addEventListener( 'click', function () {
						window.requestAnimationFrame( function () {
							window.requestAnimationFrame( function () {
								if ( ! refreshCardSwiperInstance( wrap ) ) {
									initSingleCardCarousel( wrap );
								}
							} );
						} );
					} );
				} );
			}

			if ( params.autoplay === true ) {
				destroyCardAutoplayWaypoint( wrap );

				if ( typeof Waypoint === 'undefined' ) {
					startCardAutoplay( DSM_CardSwiper );
				} else {
					wrap._dsmAutoplayWaypoint = new Waypoint( {
						element: wrap,
						handler: function () {
							startCardAutoplay( wrap.swiper );
							this.destroy();
							wrap._dsmAutoplayWaypoint = null;
						},
						offset: params.autoplay_viewport,
					} );
				}
			}
	}

	function initSwipers( root ) {
		if ( typeof Swiper === 'undefined' ) {
			return;
		}

		var scope = root && root.querySelectorAll ? root : document;
		var wrappers = scope.querySelectorAll(
			'.dsm_card_carousel .dsm_card_carousel_wrapper'
		);
		if ( ! wrappers.length ) {
			return;
		}

		bindGlobalResizeOnce();
		wrappers.forEach( initSingleCardCarousel );
	}

	function refreshOrInitCardCarouselsInRoot( root ) {
		if ( ! root || typeof root.querySelectorAll !== 'function' ) {
			return;
		}

		if ( typeof Swiper === 'undefined' ) {
			return;
		}

		var wrappers = root.querySelectorAll(
			'.dsm_card_carousel .dsm_card_carousel_wrapper'
		);
		if ( ! wrappers.length ) {
			return;
		}

		bindGlobalResizeOnce();
		wrappers.forEach( function ( wrap ) {
			destroyCardAutoplayWaypoint( wrap );
			removeDsmCardCarouselLoopMinimumClones( wrap );

			if ( wrap.swiper && typeof wrap.swiper.destroy === 'function' ) {
				try {
					wrap.swiper.destroy( true, true );
				} catch ( err ) {
					// Stale instance during VB remounts.
				}
			}
			initSingleCardCarousel( wrap );
		} );
	}

	window.dsmReinitCardCarouselsInRoot = refreshOrInitCardCarouselsInRoot;

	[ 'dsm:reinit-library-modules-in-root', 'dsm:reinit-carousels-in-root' ].forEach(
		function ( eventName ) {
			window.addEventListener( eventName, function ( event ) {
				var eventRoot = event && event.detail ? event.detail.root : null;
				if (
					! eventRoot ||
					typeof eventRoot.querySelector !== 'function' ||
					! eventRoot.querySelector( '.dsm_card_carousel' )
				) {
					return;
				}
				refreshOrInitCardCarouselsInRoot( eventRoot );
			} );
		}
	);

	function init() {
		if ( document.querySelector( '.dsm_card_carousel' ) ) {
			initMagnificPopup();
		}
		initSwipers();
	}

	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', init );
	} else {
		init();
	}
} )();
