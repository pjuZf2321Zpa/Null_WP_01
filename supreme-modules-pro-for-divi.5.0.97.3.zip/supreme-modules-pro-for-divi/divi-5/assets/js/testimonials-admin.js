/**
 * Testimonials CPT metabox — WordPress core jQuery UI datepicker.
 *
 * Display format comes from wp_localize_jquery_ui_datepicker() (site date_format).
 * The named field stays Y-m-d for save.
 *
 * @package DiviSupreme
 */
(function ($) {
	'use strict';

	$(function () {
		var $display = $('#dsm_review_date_display');
		var $hidden = $('#dsm_review_date');

		if (
			!$display.length ||
			!$hidden.length ||
			typeof $display.datepicker !== 'function'
		) {
			return;
		}

		var localized =
			typeof window.dsmTestimonialsAdmin === 'object' &&
			window.dsmTestimonialsAdmin &&
			typeof window.dsmTestimonialsAdmin.datepicker === 'object'
				? window.dsmTestimonialsAdmin.datepicker
				: {};

		$display.datepicker(
			$.extend(
				{
					altField: '#dsm_review_date',
					altFormat: 'yy-mm-dd',
					changeMonth: true,
					changeYear: true,
					constrainInput: false,
					showButtonPanel: true,
				},
				localized
			)
		);

		$display.on('change', function () {
			var value = $.trim($display.val());
			if ('' === value) {
				$hidden.val('');
				return;
			}

			var date = $display.datepicker('getDate');
			if (date) {
				$hidden.val($.datepicker.formatDate('yy-mm-dd', date));
			}
		});
	});
})(jQuery);
