( function ( window, document ) {
	var id = 'facebook-jssdk';
	if ( document.getElementById( id ) ) {
		return;
	}

	var rawId =
		typeof facebookAppId !== 'undefined' &&
		facebookAppId &&
		facebookAppId.appId
			? String( facebookAppId.appId ).trim()
			: '';
	var appId = rawId !== '' ? rawId : '252971358753113';

	var prevAsyncInit = window.fbAsyncInit;
	window.fbAsyncInit = function () {
		if ( typeof prevAsyncInit === 'function' ) {
			prevAsyncInit();
		}
		if ( typeof FB === 'undefined' ) {
			return;
		}
		try {
			FB.init( {
				appId: appId,
				cookie: true,
				xfbml: true,
				version: 'v21.0',
			} );
		} catch ( err ) {
			// Another plugin may have already called FB.init via a chained fbAsyncInit.
		}

		function parseXFBML() {
			if ( typeof FB === 'undefined' || ! FB.XFBML ) {
				return;
			}
			try {
				FB.XFBML.parse();
			} catch ( err2 ) {
				// Safe to ignore if parse was already run.
			}
		}

		parseXFBML();
		if ( document.readyState === 'loading' ) {
			document.addEventListener( 'DOMContentLoaded', parseXFBML );
		}
		window.addEventListener( 'load', parseXFBML );
	};

	var js = document.createElement( 'script' );
	var fjs = document.getElementsByTagName( 'script' )[ 0 ];
	js.id = id;
	js.async = true;
	js.defer = true;
	js.crossOrigin = 'anonymous';
	js.src = 'https://connect.facebook.net/en_GB/sdk.js';
	fjs.parentNode.insertBefore( js, fjs );
} )( window, document );
