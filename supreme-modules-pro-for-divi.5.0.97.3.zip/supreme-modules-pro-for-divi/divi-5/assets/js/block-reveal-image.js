/**
 * Supreme Block Reveal Image — RevealFx on `.et_pb_image_wrap` + Magnific Popup for lightbox/video.
 *
 * @package DiviSupreme
 */
( function () {
	'use strict';

	/**
	 * @param {Element | null} root RevealFx content root.
	 * @return {void}
	 */
	function clearBlockRevealFePreinit( root ) {
		if ( ! root || ! root.querySelectorAll ) {
			return;
		}
		root.querySelectorAll( '.dsm_block_reveal_fe_preinit' ).forEach( function ( node ) {
			node.classList.remove( 'dsm_block_reveal_fe_preinit' );
			node.style.removeProperty( 'opacity' );
		} );
	}

	/**
	 * Prefer the module root for viewport checks: the inner `.et_pb_image_wrap` is often 0×0 until
	 * the image loads, so IntersectionObserver may never fire for the wrap alone on the frontend.
	 *
	 * @param {Element} wrap `.et_pb_image_wrap` with reveal attrs.
	 * @return {Element}
	 */
	function getBlockRevealImageViewportTarget( wrap ) {
		if ( wrap && typeof wrap.closest === 'function' ) {
			const moduleRoot = wrap.closest( '.dsm_block_reveal_image' );
			if ( moduleRoot ) {
				return moduleRoot;
			}
		}
		return wrap;
	}

	/**
	 * Rough “in viewport” check after layout (e.g. image loaded).
	 *
	 * @param {Element} el
	 * @return {boolean}
	 */
	function isRoughlyInViewport( el ) {
		const r = el.getBoundingClientRect();
		const vh = window.innerHeight || 0;
		return r.bottom > 0 && r.top < vh;
	}

	/**
	 * @param {Element} el             Element to observe (module or wrap).
	 * @param {string} offset         Waypoint / IO-style offset (e.g. `80%`).
	 * @param {function(): void} onEnter Fired at most once.
	 * @return {{ stop: function(): void, run: function(): void }}
	 */
	function bindRevealTrigger( el, offset, onEnter ) {
		const runOnce = ( function () {
			let done = false;
			return function () {
				if ( done ) {
					return;
				}
				done = true;
				onEnter();
			};
		} )();

		if ( typeof IntersectionObserver !== 'undefined' ) {
			let rootMargin = '0px 0px -15% 0px';
			const m = String( offset || '' ).match( /^(\d+)%$/ );
			if ( m ) {
				const p = Math.max( 0, Math.min( 100, parseInt( m[ 1 ], 10 ) ) );
				rootMargin = '0px 0px -' + ( 100 - p ) + '% 0px';
			}
			const obs = new IntersectionObserver(
				function ( entries, o ) {
					entries.forEach( function ( e ) {
						if ( e.isIntersecting ) {
							runOnce();
							o.unobserve( e.target );
						}
					} );
				},
				{ root: null, rootMargin: rootMargin, threshold: 0 }
			);
			obs.observe( el );
			return {
				stop: function () {
					obs.disconnect();
				},
				run: runOnce,
			};
		}

		if ( typeof jQuery !== 'undefined' && jQuery.fn.waypoint ) {
			try {
				const $el = jQuery( el );
				$el.waypoint(
					function () {
						runOnce();
						if ( this && typeof this.destroy === 'function' ) {
							this.destroy();
						}
					},
					{
						offset: offset || '80%',
						triggerOnce: true,
					}
				);
				return {
					stop: function () {
						try {
							$el.waypoint( 'destroy' );
						} catch ( err ) {
							/* noop */
						}
					},
					run: runOnce,
				};
			} catch ( e ) {
				/* Fall through. */
			}
		}

		runOnce();
		return {
			stop: function () {},
			run: runOnce,
		};
	}

	/**
	 * @param {Element|null} wrap `.et_pb_image_wrap` with data-dsm-block-reveal-* attrs.
	 * @return {undefined|function(): void}
	 */
	function initBlockRevealImageWrap( wrap ) {
		if ( ! wrap || wrap.getAttribute( 'data-dsm-block-reveal-init' ) ) {
			return undefined;
		}

		if ( typeof RevealFx === 'undefined' ) {
			wrap
				.querySelectorAll( '.dsm_block_reveal_fe_preinit' )
				.forEach( function ( node ) {
					node.classList.remove( 'dsm_block_reveal_fe_preinit' );
					node.style.removeProperty( 'opacity' );
				} );
			return undefined;
		}

		wrap.setAttribute( 'data-dsm-block-reveal-init', '1' );
		const animation =
			wrap.getAttribute( 'data-dsm-block-reveal-animation' ) || 'lr';
		const delay =
			wrap.getAttribute( 'data-dsm-block-reveal-delay' ) || '0.1';
		const viewport =
			wrap.getAttribute( 'data-dsm-block-reveal-viewport' ) || '80%';

		const fx = new RevealFx( wrap, {
			revealSettings: {
				delay: delay,
				direction: animation,
				onCover: function ( contentEl ) {
					if ( contentEl && contentEl.style ) {
						contentEl.style.opacity = '1';
					}
					clearBlockRevealFePreinit( contentEl );
				},
			},
		} );

		const viewportTarget = getBlockRevealImageViewportTarget( wrap );
		const triggerBinding = bindRevealTrigger( viewportTarget, viewport, function () {
			if ( fx && typeof fx.reveal === 'function' ) {
				fx.reveal();
			}
		} );

		/**
		 * When the image finishes loading the wrap gets height; IO may have missed intersecting on a 0×0 box.
		 * One-shot: if already visible, run the same reveal as the observer.
		 */
		function afterImageLayoutMaybeReveal() {
			window.requestAnimationFrame( function () {
				if ( wrap.getAttribute( 'data-dsm-block-reveal-init' ) !== '1' ) {
					return;
				}
				if ( isRoughlyInViewport( viewportTarget ) || isRoughlyInViewport( wrap ) ) {
					triggerBinding.run();
				}
			} );
		}

		wrap.querySelectorAll( 'img' ).forEach( function ( img ) {
			if ( img.complete ) {
				afterImageLayoutMaybeReveal();
			} else {
				img.addEventListener( 'load', afterImageLayoutMaybeReveal, { once: true } );
				img.addEventListener( 'error', afterImageLayoutMaybeReveal, { once: true } );
			}
		} );

		return function () {
			wrap.removeAttribute( 'data-dsm-block-reveal-init' );
			if ( triggerBinding && typeof triggerBinding.stop === 'function' ) {
				triggerBinding.stop();
			}
		};
	}

	/**
	 * Find image wraps for this module (server markup uses `.dsm_block_reveal_image_wrapper` around the stack).
	 * Prefer that inner wrapper over `.dsm_block_reveal_image` on the outer module (markup/wrappers can differ on FE vs VB).
	 *
	 * @return {NodeListOf<Element>}
	 */
	function queryUninitializedBlockRevealImageWraps() {
		const primary =
			'.dsm_block_reveal_image_wrapper .et_pb_image_wrap[data-dsm-block-reveal-animation]:not([data-dsm-block-reveal-init])';
		const fallback =
			'.dsm_block_reveal_image .et_pb_image_wrap[data-dsm-block-reveal-animation]:not([data-dsm-block-reveal-init])';
		let list = document.querySelectorAll( primary );
		if ( ! list.length ) {
			list = document.querySelectorAll( fallback );
		}
		return list;
	}

	function initRevealFx() {
		if ( typeof RevealFx === 'undefined' ) {
			document
				.querySelectorAll(
					'.dsm_block_reveal_image_wrapper .et_pb_image_wrap[data-dsm-block-reveal-animation] .dsm_block_reveal_fe_preinit'
				)
				.forEach( function ( node ) {
					node.classList.remove( 'dsm_block_reveal_fe_preinit' );
					node.style.removeProperty( 'opacity' );
				} );
			return;
		}

		queryUninitializedBlockRevealImageWraps().forEach( function ( wrap ) {
			initBlockRevealImageWrap( wrap );
		} );
	}

	window.dsmBlockRevealInitImageWrap = initBlockRevealImageWrap;

	function initImageLightbox() {
		if ( typeof jQuery === 'undefined' || ! jQuery.fn.magnificPopup ) {
			return;
		}

		jQuery( document ).on(
			'click',
			'.dsm_block_reveal_image .dsm-image-lightbox',
			function ( e ) {
				e.preventDefault();
				const $t = jQuery( this );
				const orderClass = $t.data( 'order-class' ) || '';
				const imageUrl = $t.data( 'image-url' ) || $t.attr( 'href' ) || '';

				jQuery.magnificPopup.open( {
					type: 'image',
					items: { src: imageUrl },
					removalDelay: 500,
					mainClass: 'mfp-fade',
					callbacks: {
						open: function () {
							if ( this.container && orderClass ) {
								this.container.addClass(
									orderClass + ' dsm-lightbox-custom'
								);
							}
						},
					},
				} );
			}
		);
	}

	function initVideoLightbox() {
		if ( typeof jQuery === 'undefined' || ! jQuery.fn.magnificPopup ) {
			return;
		}

		jQuery( '.dsm_block_reveal_image a.dsm-video-lightbox' ).each(
			function () {
				const $a = jQuery( this );
				const orderClass = $a.data( 'order-class' ) || '';

				$a.magnificPopup( {
					type: 'iframe',
					removalDelay: 500,
					iframe: {
						markup:
							'<div class="mfp-iframe-scaler dsm-video-popup">' +
							'<div class="mfp-close"></div>' +
							'<iframe class="mfp-iframe" frameborder="0" allowfullscreen allow="autoplay"></iframe>' +
							'</div>',
						patterns: {
							youtube: {
								index: 'youtube.com/',
								id: 'v=',
								src: '//www.youtube.com/embed/%id%?autoplay=1&rel=0',
							},
							youtu_be: {
								index: 'youtu.be',
								id: '/',
								src: '//www.youtube.com/embed/%id%?autoplay=1&rel=0',
							},
							vimeo: {
								index: 'vimeo.com/',
								id: '/',
								src: '//player.vimeo.com/video/%id%?autoplay=1',
							},
							dailymotion: {
								index: 'dailymotion.com',
								id: function ( url ) {
									const match = url.match(
										/^.+dailymotion.com\/(video|hub)\/([^_]+)[^#]*(#video=([^_&]+))?/
									);
									if ( match !== null ) {
										if ( match[ 4 ] !== undefined ) {
											return match[ 4 ];
										}
										return match[ 2 ];
									}
									return null;
								},
								src: 'https://www.dailymotion.com/embed/video/%id%',
							},
						},
						srcAction: 'iframe_src',
					},
					mainClass: 'dsm-video-popup-wrap mfp-fade',
					callbacks: {
						open: function () {
							if ( this.container && orderClass ) {
								this.container.addClass(
									orderClass + ' dsm-lightbox-custom'
								);
							}
						},
					},
				} );
			}
		);
	}

	function init() {
		initRevealFx();
		initImageLightbox();
		initVideoLightbox();
	}

	function scheduleInit() {
		if ( document.readyState === 'loading' ) {
			document.addEventListener( 'DOMContentLoaded', init );
		} else {
			init();
		}
		// Divi / deferred layout can paint module HTML after DOMContentLoaded; second pass is cheap (init guard).
		window.addEventListener( 'load', function () {
			initRevealFx();
		} );
	}

	scheduleInit();
} )();
