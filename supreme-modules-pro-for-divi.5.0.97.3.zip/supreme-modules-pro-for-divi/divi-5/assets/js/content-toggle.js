( function () {
	'use strict';

	/**
	 * @param {HTMLElement} el
	 */
	function hidePane( el ) {
		el.style.display = 'none';
	}

	/**
	 * @param {HTMLElement} el
	 */
	function showPane( el ) {
		el.style.removeProperty( 'display' );
	}

	/**
	 * Divi's gallery init expects a jQuery collection; wrap each node when jQuery is present.
	 *
	 * @param {ParentNode} container
	 */
	function maybeInitDiviGalleries( container ) {
		if ( typeof window.et_pb_gallery_init !== 'function' ) {
			return;
		}
		const jq = window.jQuery;
		if ( ! jq ) {
			return;
		}
		container.querySelectorAll( '.et_pb_gallery' ).forEach( function ( gallery ) {
			window.et_pb_gallery_init( jq( gallery ) );
		} );
	}

	function initContentToggles() {
		document.querySelectorAll( '.dsm-toggle-btn .dsm-input' ).forEach( function ( input ) {
			const root = input.closest( '.dsm-content-toggle' );
			if ( ! root ) {
				return;
			}
			const back = root.querySelector( '.dsm-content-toggle-back' );
			const front = root.querySelector( '.dsm-content-toggle-front' );
			if ( ! back || ! front ) {
				return;
			}

			if ( input.checked ) {
				hidePane( front );
				showPane( back );
			} else {
				hidePane( back );
				showPane( front );
			}

			input.addEventListener( 'change', function () {
				if ( input.checked ) {
					maybeInitDiviGalleries( back );
					hidePane( front );
					showPane( back );
				} else {
					maybeInitDiviGalleries( front );
					hidePane( back );
					showPane( front );
				}
			} );
		} );
	}

	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', initContentToggles );
	} else {
		initContentToggles();
	}
} )();
