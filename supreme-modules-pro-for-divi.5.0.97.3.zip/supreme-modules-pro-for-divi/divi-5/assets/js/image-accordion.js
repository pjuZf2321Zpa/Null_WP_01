/**
 * Image Accordion — expand items by hover, click, or touch.
 */
( function () {
	'use strict';

	/**
	 * @return {boolean}
	 */
	function prefersHoverInteraction() {
		if ( ! window.matchMedia ) {
			return true;
		}

		return window.matchMedia( '(hover: hover) and (pointer: fine)' ).matches;
	}

	/**
	 * @param {HTMLElement} accordion
	 * @return {() => void}
	 */
	function bindAccordion( accordion ) {
		if ( accordion.dataset.dsmImageAccordionBound === '1' ) {
			return function () {};
		}

		const wrapper = accordion.querySelector(
			'.dsm_image_accordion_wrapper'
		);
		const children = Array.from(
			accordion.querySelectorAll( '.dsm_image_accordion_child' )
		);

		if ( ! wrapper || ! children.length ) {
			return function () {};
		}

		accordion.dataset.dsmImageAccordionBound = '1';

		const defaultActive = new Set(
			children.filter( function ( child ) {
				return child.classList.contains(
					'dsm_image_accordion_active_item'
				);
			} )
		);

		const cleanups = [];

		const clearActive = function () {
			children.forEach( function ( child ) {
				child.classList.remove( 'dsm_image_accordion_active_item' );
			} );
		};

		const restoreDefaultActive = function () {
			clearActive();
			defaultActive.forEach( function ( child ) {
				child.classList.add( 'dsm_image_accordion_active_item' );
			} );
		};

		const setActiveChild = function ( child ) {
			clearActive();
			child.classList.add( 'dsm_image_accordion_active_item' );
		};

		const isHoverMode = wrapper.classList.contains(
			'dsm_image_accordion_trigger_on_hover'
		);
		const isClickMode = wrapper.classList.contains(
			'dsm_image_accordion_trigger_on_click'
		);
		const prefersHover = prefersHoverInteraction();

		children.forEach( function ( child ) {
			if ( ! child.hasAttribute( 'tabindex' ) ) {
				child.setAttribute( 'tabindex', '0' );
			}
			if ( ! child.hasAttribute( 'role' ) ) {
				child.setAttribute( 'role', 'button' );
			}

			const onKeyDown = function ( event ) {
				if ( event.key !== 'Enter' && event.key !== ' ' ) {
					return;
				}
				event.preventDefault();
				setActiveChild( child );
			};

			child.addEventListener( 'keydown', onKeyDown );
			cleanups.push( function () {
				child.removeEventListener( 'keydown', onKeyDown );
			} );
		} );

		if ( isHoverMode && prefersHover ) {
			children.forEach( function ( child ) {
				const onEnter = function () {
					setActiveChild( child );
				};
				const onLeave = function () {
					restoreDefaultActive();
				};

				child.addEventListener( 'mouseenter', onEnter );
				child.addEventListener( 'mouseleave', onLeave );
				cleanups.push( function () {
					child.removeEventListener( 'mouseenter', onEnter );
					child.removeEventListener( 'mouseleave', onLeave );
				} );
			} );
		} else if ( isHoverMode ) {
			children.forEach( function ( child ) {
				const onTap = function ( event ) {
					if (
						child.classList.contains(
							'dsm_image_accordion_active_item'
						) &&
						! defaultActive.has( child )
					) {
						event.preventDefault();
						restoreDefaultActive();
						return;
					}

					if (
						child.classList.contains(
							'dsm_image_accordion_active_item'
						)
					) {
						return;
					}

					event.preventDefault();
					setActiveChild( child );
				};

				child.addEventListener( 'click', onTap );
				cleanups.push( function () {
					child.removeEventListener( 'click', onTap );
				} );
			} );
		}

		if ( isClickMode ) {
			accordion.classList.add( 'dsm_image_accordion_click_item' );
			children.forEach( function ( child ) {
				const onClick = function () {
					if (
						child.classList.contains(
							'dsm_image_accordion_active_item'
						)
					) {
						return;
					}
					setActiveChild( child );
				};

				child.addEventListener( 'click', onClick );
				cleanups.push( function () {
					child.removeEventListener( 'click', onClick );
				} );
			} );
		}

		return function () {
			delete accordion.dataset.dsmImageAccordionBound;
			cleanups.forEach( function ( fn ) {
				fn();
			} );
		};
	}

	function boot( root ) {
		var scope = root && root.querySelectorAll ? root : document;
		scope.querySelectorAll( '.dsm_image_accordion' ).forEach( bindAccordion );
	}

	function dsmReinitImageAccordionInRoot( root ) {
		if ( ! root || ! root.querySelectorAll ) {
			return;
		}

		root.querySelectorAll( '.dsm_image_accordion' ).forEach( function ( accordion ) {
			delete accordion.dataset.dsmImageAccordionBound;
		} );

		boot( root );
	}

	window.dsmReinitImageAccordionInRoot = dsmReinitImageAccordionInRoot;

	[ 'dsm:reinit-library-modules-in-root', 'dsm:reinit-carousels-in-root' ].forEach(
		function ( eventName ) {
			window.addEventListener( eventName, function ( event ) {
				var eventRoot = event && event.detail ? event.detail.root : null;
				if ( eventRoot ) {
					dsmReinitImageAccordionInRoot( eventRoot );
				}
			} );
		}
	);

	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', function () {
			boot( document );
		} );
	} else {
		boot( document );
	}
} )();
