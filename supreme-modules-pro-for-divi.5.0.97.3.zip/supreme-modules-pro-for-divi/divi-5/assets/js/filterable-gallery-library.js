function ownKeys( object, enumerableOnly ) {
	var keys = Object.keys( object );
	if ( Object.getOwnPropertySymbols ) {
		var symbols = Object.getOwnPropertySymbols( object );
		enumerableOnly &&
			( symbols = symbols.filter( function ( sym ) {
				return Object.getOwnPropertyDescriptor( object, sym )
					.enumerable;
			} ) ),
			keys.push.apply( keys, symbols );
	}
	return keys;
}

function _objectSpread( target ) {
	for ( var i = 1; i < arguments.length; i++ ) {
		var source = null != arguments[ i ] ? arguments[ i ] : {};
		i % 2
			? ownKeys( Object( source ), ! 0 ).forEach( function ( key ) {
					_defineProperty( target, key, source[ key ] );
			  } )
			: Object.getOwnPropertyDescriptors
			? Object.defineProperties(
					target,
					Object.getOwnPropertyDescriptors( source )
			  )
			: ownKeys( Object( source ) ).forEach( function ( key ) {
					Object.defineProperty(
						target,
						key,
						Object.getOwnPropertyDescriptor( source, key )
					);
			  } );
	}
	return target;
}

function _defineProperty( obj, key, value ) {
	if ( key in obj ) {
		Object.defineProperty( obj, key, {
			value: value,
			enumerable: true,
			configurable: true,
			writable: true,
		} );
	} else {
		obj[ key ] = value;
	}
	return obj;
}

/**
 *
 *
 * shuffle library
 *
 *
 *
 */
! ( function ( t, e ) {
	'object' == typeof exports && 'undefined' != typeof module
		? ( module.exports = e() )
		: 'function' == typeof define && define.amd
		? define( e )
		: ( ( t =
				'undefined' != typeof globalThis
					? globalThis
					: t || self ).Shuffle = e() );
} )( void 0, function () {
	'use strict';

	var t = {
		exports: {},
	};

	function e() {}

	( e.prototype = {
		on: function ( t, e, i ) {
			var s = this.e || ( this.e = {} );
			return (
				( s[ t ] || ( s[ t ] = [] ) ).push( {
					fn: e,
					ctx: i,
				} ),
				this
			);
		},
		once: function ( t, e, i ) {
			var s = this;

			function n() {
				s.off( t, n ), e.apply( i, arguments );
			}

			return ( n._ = e ), this.on( t, n, i );
		},
		emit: function ( t ) {
			for (
				var e = [].slice.call( arguments, 1 ),
					i = ( ( this.e || ( this.e = {} ) )[ t ] || [] ).slice(),
					s = 0,
					n = i.length;
				s < n;
				s++
			)
				i[ s ].fn.apply( i[ s ].ctx, e );

			return this;
		},
		off: function ( t, e ) {
			var i = this.e || ( this.e = {} ),
				s = i[ t ],
				n = [];
			if ( s && e )
				for ( var o = 0, r = s.length; o < r; o++ )
					s[ o ].fn !== e && s[ o ].fn._ !== e && n.push( s[ o ] );
			return n.length ? ( i[ t ] = n ) : delete i[ t ], this;
		},
	} ),
		( t.exports = e ),
		( t.exports.TinyEmitter = e );

	function i() {}

	function s( t ) {
		return parseFloat( t ) || 0;
	}

	class n {
		constructor( t, e ) {
			( this.x = s( t ) ), ( this.y = s( e ) );
		}

		static equals( t, e ) {
			return t.x === e.x && t.y === e.y;
		}
	}

	class o {
		constructor( t, e, i, s, n ) {
			( this.id = n ),
				( this.left = t ),
				( this.top = e ),
				( this.width = i ),
				( this.height = s );
		}

		static intersects( t, e ) {
			return (
				t.left < e.left + e.width &&
				e.left < t.left + t.width &&
				t.top < e.top + e.height &&
				e.top < t.top + t.height
			);
		}
	}

	var r = {
		BASE: 'shuffle',
		SHUFFLE_ITEM: 'shuffle-item',
		VISIBLE: 'shuffle-item--visible',
		HIDDEN: 'shuffle-item--hidden',
	};
	let h = 0;

	class l {
		constructor( t, e ) {
			( h += 1 ),
				( this.id = h ),
				( this.element = t ),
				( this.isRTL = e ),
				( this.isVisible = ! 0 ),
				( this.isHidden = ! 1 );
		}

		show() {
			( this.isVisible = ! 0 ),
				this.element.classList.remove( r.HIDDEN ),
				this.element.classList.add( r.VISIBLE ),
				this.element.removeAttribute( 'aria-hidden' );
		}

		hide() {
			( this.isVisible = ! 1 ),
				this.element.classList.remove( r.VISIBLE ),
				this.element.classList.add( r.HIDDEN ),
				this.element.setAttribute( 'aria-hidden', ! 0 );
		}

		init() {
			this.addClasses( [ r.SHUFFLE_ITEM, r.VISIBLE ] ),
				this.applyCss( l.Css.INITIAL ),
				this.applyCss(
					this.isRTL ? l.Css.DIRECTION.rtl : l.Css.DIRECTION.ltr
				),
				( this.scale = l.Scale.VISIBLE ),
				( this.point = new n() );
		}

		addClasses( t ) {
			t.forEach( ( t ) => {
				this.element.classList.add( t );
			} );
		}

		removeClasses( t ) {
			t.forEach( ( t ) => {
				this.element.classList.remove( t );
			} );
		}

		applyCss( t ) {
			Object.keys( t ).forEach( ( e ) => {
				this.element.style[ e ] = t[ e ];
			} );
		}

		dispose() {
			this.removeClasses( [ r.HIDDEN, r.VISIBLE, r.SHUFFLE_ITEM ] ),
				this.element.removeAttribute( 'style' ),
				( this.element = null );
		}
	}

	( l.Css = {
		INITIAL: {
			position: 'absolute',
			top: 0,
			visibility: 'visible',
			willChange: 'transform',
		},
		DIRECTION: {
			ltr: {
				left: 0,
			},
			rtl: {
				right: 0,
			},
		},
		VISIBLE: {
			before: {
				opacity: 1,
				visibility: 'visible',
			},
			after: {
				transitionDelay: '',
			},
		},
		HIDDEN: {
			before: {
				opacity: 0,
			},
			after: {
				visibility: 'hidden',
				transitionDelay: '',
			},
		},
	} ),
		( l.Scale = {
			VISIBLE: 1,
			HIDDEN: 0.001,
		} );
	let a = null;

	var d = () => {
		if ( null !== a ) return a;
		const t = document.body || document.documentElement,
			e = document.createElement( 'div' );
		( e.style.cssText = 'width:10px;padding:2px;box-sizing:border-box;' ),
			t.appendChild( e );
		const { width: i } = window.getComputedStyle( e, null );
		return ( a = 10 === Math.round( s( i ) ) ), t.removeChild( e ), a;
	};

	function u( t, e ) {
		let i =
				arguments.length > 2 && void 0 !== arguments[ 2 ]
					? arguments[ 2 ]
					: window.getComputedStyle( t, null ),
			n = s( i[ e ] );
		return (
			d() || 'width' !== e
				? d() ||
				  'height' !== e ||
				  ( n +=
						s( i.paddingTop ) +
						s( i.paddingBottom ) +
						s( i.borderTopWidth ) +
						s( i.borderBottomWidth ) )
				: ( n +=
						s( i.paddingLeft ) +
						s( i.paddingRight ) +
						s( i.borderLeftWidth ) +
						s( i.borderRightWidth ) ),
			n
		);
	}

	const m = {
		reverse: ! 1,
		by: null,
		compare: null,
		randomize: ! 1,
		key: 'element',
	};

	function c( t, e ) {
		const i = _objectSpread( _objectSpread( {}, m ), e ),
			s = Array.from( t );

		let n = ! 1;
		return t.length
			? i.randomize
				? ( function ( t ) {
						let e = t.length;

						for ( ; e;  ) {
							e -= 1;
							const i = Math.floor( Math.random() * ( e + 1 ) ),
								s = t[ i ];
							( t[ i ] = t[ e ] ), ( t[ e ] = s );
						}

						return t;
				  } )( t )
				: ( 'function' == typeof i.by
						? t.sort( ( t, e ) => {
								if ( n ) return 0;
								const s = i.by( t[ i.key ] ),
									o = i.by( e[ i.key ] );
								return void 0 === s && void 0 === o
									? ( ( n = ! 0 ), 0 )
									: s < o ||
									  'sortFirst' === s ||
									  'sortLast' === o
									? -1
									: s > o ||
									  'sortLast' === s ||
									  'sortFirst' === o
									? 1
									: 0;
						  } )
						: 'function' == typeof i.compare && t.sort( i.compare ),
				  n ? s : ( i.reverse && t.reverse(), t ) )
			: [];
	}

	const p = {},
		f = 'transitionend';
	let g = 0;

	function _( t ) {
		return (
			!! p[ t ] &&
			( p[ t ].element.removeEventListener( f, p[ t ].listener ),
			( p[ t ] = null ),
			! 0 )
		);
	}

	function y( t, e ) {
		const i = ( ( g += 1 ), f + g ),
			s = ( t ) => {
				t.currentTarget === t.target && ( _( i ), e( t ) );
			};

		return (
			t.addEventListener( f, s ),
			( p[ i ] = {
				element: t,
				listener: s,
			} ),
			i
		);
	}

	function I( t ) {
		return Math.max( ...t );
	}

	function E( t, e, i, s ) {
		let n = t / e;
		return (
			Math.abs( Math.round( n ) - n ) < s && ( n = Math.round( n ) ),
			Math.min( Math.ceil( n ), i )
		);
	}

	function v( t, e, i ) {
		if ( 1 === e ) return t;
		const s = [];

		for ( let n = 0; n <= i - e; n++ ) s.push( I( t.slice( n, n + e ) ) );

		return s;
	}

	function b( t, e ) {
		const i = ( ( s = t ), Math.min( ...s ) );
		var s;

		for ( let s = 0, n = t.length; s < n; s++ )
			if ( t[ s ] >= i - e && t[ s ] <= i + e ) return s;

		return 0;
	}

	function T( t, e ) {
		const i = {};
		t.forEach( ( t ) => {
			i[ t.top ] ? i[ t.top ].push( t ) : ( i[ t.top ] = [ t ] );
		} );
		let s = [];
		const r = [],
			h = [];
		return (
			Object.keys( i ).forEach( ( t ) => {
				const n = i[ t ];
				r.push( n );
				const l = n[ n.length - 1 ],
					a = l.left + l.width,
					d = Math.round( ( e - a ) / 2 );
				let u = n,
					m = ! 1;

				if ( d > 0 ) {
					const t = [];
					( m = n.every( ( e ) => {
						const i = new o(
								e.left + d,
								e.top,
								e.width,
								e.height,
								e.id
							),
							n = ! s.some( ( t ) => o.intersects( i, t ) );
						return t.push( i ), n;
					} ) ),
						m && ( u = t );
				}

				if ( ! m ) {
					let t;

					if (
						n.some( ( e ) =>
							s.some( ( i ) => {
								const s = o.intersects( e, i );
								return s && ( t = i ), s;
							} )
						)
					) {
						const e = h.findIndex( ( e ) => e.includes( t ) );
						h.splice( e, 1, r[ e ] );
					}
				}

				( s = s.concat( u ) ), h.push( u );
			} ),
			h
				.flat()
				.sort( ( t, e ) => t.id - e.id )
				.map( ( t ) => new n( t.left, t.top ) )
		);
	}

	function S( t ) {
		return Array.from( new Set( t ) );
	}

	let C = 0;

	class L extends t.exports {
		constructor( t ) {
			let e =
				arguments.length > 1 && void 0 !== arguments[ 1 ]
					? arguments[ 1 ]
					: {};
			super(),
				( this.options = _objectSpread(
					_objectSpread( {}, L.options ),
					e
				) ),
				( this.lastSort = {} ),
				( this.group = L.ALL_ITEMS ),
				( this.lastFilter = L.ALL_ITEMS ),
				( this.isEnabled = ! 0 ),
				( this.isDestroyed = ! 1 ),
				( this.isInitialized = ! 1 ),
				( this._transitions = [] ),
				( this.isTransitioning = ! 1 ),
				( this._queue = [] );

			const i = this._getElementOption( t );

			if ( ! i )
				throw new TypeError(
					'Shuffle needs to be initialized with an element.'
				);
			( this.element = i ),
				( this.id = `shuffle_${ C }` ),
				( C += 1 ),
				this._init(),
				( this.isInitialized = ! 0 );
		}

		_init() {
			if (
				( ( this.items = this._getItems() ),
				( this.sortedItems = this.items ),
				( this.options.sizer = this._getElementOption(
					this.options.sizer
				) ),
				this.element.classList.add( L.Classes.BASE ),
				this._initItems( this.items ),
				'complete' !== document.readyState )
			) {
				const t = this.layout.bind( this );
				window.addEventListener( 'load', function e() {
					window.removeEventListener( 'load', e ), t();
				} );
			}

			const t = window.getComputedStyle( this.element, null ),
				e = L.getSize( this.element ).width;
			this._validateStyles( t ),
				this._setColumns( e ),
				this.filter( this.options.group, this.options.initialSort ),
				( this._rafId = null ),
				'ResizeObserver' in window &&
					( ( this._resizeObserver = new ResizeObserver(
						this._handleResizeCallback.bind( this )
					) ),
					this._resizeObserver.observe( this.element ) ),
				this.element.offsetWidth,
				this.setItemTransitions( this.items ),
				( this.element.style.transition = `height ${ this.options.speed }ms ${ this.options.easing }` );
		}

		_getElementOption( t ) {
			return 'string' == typeof t
				? this.element.querySelector( t )
				: t && t.nodeType && 1 === t.nodeType
				? t
				: t && t.jquery
				? t[ 0 ]
				: null;
		}

		_validateStyles( t ) {
			'static' === t.position &&
				( this.element.style.position = 'relative' ),
				'hidden' !== t.overflow &&
					( this.element.style.overflow = 'hidden' );
		}

		_filter() {
			let t =
					arguments.length > 0 && void 0 !== arguments[ 0 ]
						? arguments[ 0 ]
						: this.lastFilter,
				e =
					arguments.length > 1 && void 0 !== arguments[ 1 ]
						? arguments[ 1 ]
						: this.items;

			const i = this._getFilteredSets( t, e );

			return (
				this._toggleFilterClasses( i ),
				( this.lastFilter = t ),
				'string' == typeof t && ( this.group = t ),
				i
			);
		}

		_getFilteredSets( t, e ) {
			let i = [];
			const s = [];
			return (
				t === L.ALL_ITEMS
					? ( i = e )
					: e.forEach( ( e ) => {
							this._doesPassFilter( t, e.element )
								? i.push( e )
								: s.push( e );
					  } ),
				{
					visible: i,
					hidden: s,
				}
			);
		}

		_doesPassFilter( t, e ) {
			if ( 'function' == typeof t ) return t.call( e, e, this );
			const i = e.dataset[ L.FILTER_ATTRIBUTE_KEY ],
				s = this.options.delimiter
					? i.split( this.options.delimiter )
					: JSON.parse( i );

			function n( t ) {
				return s.includes( t );
			}

			return Array.isArray( t )
				? this.options.filterMode === L.FilterMode.ANY
					? t.some( n )
					: t.every( n )
				: s.includes( t );
		}

		_toggleFilterClasses( t ) {
			let { visible: e, hidden: i } = t;
			e.forEach( ( t ) => {
				t.show();
			} ),
				i.forEach( ( t ) => {
					t.hide();
				} );
		}

		_initItems( t ) {
			t.forEach( ( t ) => {
				t.init();
			} );
		}

		_disposeItems( t ) {
			t.forEach( ( t ) => {
				t.dispose();
			} );
		}

		_updateItemCount() {
			this.visibleItems = this._getFilteredItems().length;
		}

		setItemTransitions( t ) {
			const { speed: e, easing: i } = this.options,
				s = this.options.useTransforms
					? [ 'transform' ]
					: [ 'top', 'left' ],
				n = Object.keys( l.Css.HIDDEN.before ).map( ( t ) =>
					t.replace( /([A-Z])/g, ( t, e ) => `-${ e.toLowerCase() }` )
				),
				o = s.concat( n ).join();
			t.forEach( ( t ) => {
				( t.element.style.transitionDuration = `${ e }ms` ),
					( t.element.style.transitionTimingFunction = i ),
					( t.element.style.transitionProperty = o );
			} );
		}

		_getItems() {
			return Array.from( this.element.children )
				.filter( ( t ) => t.matches( this.options.itemSelector ) )
				.map( ( t ) => new l( t, this.options.isRTL ) );
		}

		_mergeNewItems( t ) {
			const e = Array.from( this.element.children );
			return c( this.items.concat( t ), {
				by: ( t ) => e.indexOf( t ),
			} );
		}

		_getFilteredItems() {
			return this.items.filter( ( t ) => t.isVisible );
		}

		_getConcealedItems() {
			return this.items.filter( ( t ) => ! t.isVisible );
		}

		_getColumnSize( t, e ) {
			let i;
			return (
				( i =
					'function' == typeof this.options.columnWidth
						? this.options.columnWidth( t )
						: this.options.sizer
						? L.getSize( this.options.sizer ).width
						: this.options.columnWidth
						? this.options.columnWidth
						: this.items.length > 0
						? L.getSize( this.items[ 0 ].element, ! 0 ).width
						: t ),
				0 === i && ( i = t ),
				i + e
			);
		}

		_getGutterSize( t ) {
			let e;
			return (
				( e =
					'function' == typeof this.options.gutterWidth
						? this.options.gutterWidth( t )
						: this.options.sizer
						? u( this.options.sizer, 'marginLeft' )
						: this.options.gutterWidth ),
				e
			);
		}

		_setColumns() {
			let t =
				arguments.length > 0 && void 0 !== arguments[ 0 ]
					? arguments[ 0 ]
					: L.getSize( this.element ).width;

			const e = this._getGutterSize( t ),
				i = this._getColumnSize( t, e );

			let s = ( t + e ) / i;
			Math.abs( Math.round( s ) - s ) < this.options.columnThreshold &&
				( s = Math.round( s ) ),
				( this.cols = Math.max( Math.floor( s || 0 ), 1 ) ),
				( this.containerWidth = t ),
				( this.colWidth = i );
		}

		_setContainerSize() {
			this.element.style.height = `${ this._getContainerSize() }px`;
		}

		_getContainerSize() {
			return I( this.positions );
		}

		_getStaggerAmount( t ) {
			return Math.min(
				t * this.options.staggerAmount,
				this.options.staggerAmountMax
			);
		}

		_dispatch( t ) {
			let e =
				arguments.length > 1 && void 0 !== arguments[ 1 ]
					? arguments[ 1 ]
					: {};
			this.isDestroyed || ( ( e.shuffle = this ), this.emit( t, e ) );
		}

		_resetCols() {
			let t = this.cols;

			for ( this.positions = []; t;  )
				( t -= 1 ), this.positions.push( 0 );
		}

		_layout( t ) {
			const e = this._getNextPositions( t );

			let i = 0;
			t.forEach( ( t, s ) => {
				function o() {
					t.applyCss( l.Css.VISIBLE.after );
				}

				if ( n.equals( t.point, e[ s ] ) && ! t.isHidden )
					return t.applyCss( l.Css.VISIBLE.before ), void o();
				( t.point = e[ s ] ),
					( t.scale = l.Scale.VISIBLE ),
					( t.isHidden = ! 1 );
				const r = this.getStylesForTransition(
					t,
					l.Css.VISIBLE.before
				);
				( r.transitionDelay = `${ this._getStaggerAmount( i ) }ms` ),
					this._queue.push( {
						item: t,
						styles: r,
						callback: o,
					} ),
					( i += 1 );
			} );
		}

		_getNextPositions( t ) {
			if ( this.options.isCentered ) {
				const e = t.map( ( t, e ) => {
					const i = L.getSize( t.element, ! 0 ),
						s = this._getItemPosition( i );

					return new o( s.x, s.y, i.width, i.height, e );
				} );
				return this.getTransformedPositions( e, this.containerWidth );
			}

			return t.map( ( t ) =>
				this._getItemPosition( L.getSize( t.element, ! 0 ) )
			);
		}

		_getItemPosition( t ) {
			return ( function ( t ) {
				let {
					itemSize: e,
					positions: i,
					gridSize: s,
					total: o,
					threshold: r,
					buffer: h,
				} = t;
				const l = E( e.width, s, o, r ),
					a = v( i, l, o ),
					d = b( a, h ),
					u = new n( s * d, a[ d ] ),
					m = a[ d ] + e.height;

				for ( let t = 0; t < l; t++ ) i[ d + t ] = m;

				return u;
			} )( {
				itemSize: t,
				positions: this.positions,
				gridSize: this.colWidth,
				total: this.cols,
				threshold: this.options.columnThreshold,
				buffer: this.options.buffer,
			} );
		}

		getTransformedPositions( t, e ) {
			return T( t, e );
		}

		_shrink() {
			let t =
					arguments.length > 0 && void 0 !== arguments[ 0 ]
						? arguments[ 0 ]
						: this._getConcealedItems(),
				e = 0;
			t.forEach( ( t ) => {
				function i() {
					t.applyCss( l.Css.HIDDEN.after );
				}

				if ( t.isHidden )
					return t.applyCss( l.Css.HIDDEN.before ), void i();
				( t.scale = l.Scale.HIDDEN ), ( t.isHidden = ! 0 );
				const s = this.getStylesForTransition( t, l.Css.HIDDEN.before );
				( s.transitionDelay = `${ this._getStaggerAmount( e ) }ms` ),
					this._queue.push( {
						item: t,
						styles: s,
						callback: i,
					} ),
					( e += 1 );
			} );
		}

		_handleResizeCallback( t ) {
			if ( this.isEnabled && ! this.isDestroyed )
				for ( const e of t )
					Math.round( e.contentRect.width ) !==
						Math.round( this.containerWidth ) &&
						( cancelAnimationFrame( this._rafId ),
						( this._rafId = requestAnimationFrame(
							this.update.bind( this )
						) ) );
		}

		getStylesForTransition( t, e ) {
			const i = _objectSpread( {}, e );

			if ( this.options.useTransforms ) {
				const e = this.options.isRTL ? '-' : '',
					s = this.options.roundTransforms
						? Math.round( t.point.x )
						: t.point.x,
					n = this.options.roundTransforms
						? Math.round( t.point.y )
						: t.point.y;
				i.transform = `translate(${ e }${ s }px, ${ n }px) scale(${ t.scale })`;
			} else
				this.options.isRTL
					? ( i.right = `${ t.point.x }px` )
					: ( i.left = `${ t.point.x }px` ),
					( i.top = `${ t.point.y }px` );

			return i;
		}

		_whenTransitionDone( t, e, i ) {
			const s = y( t, ( t ) => {
				e(), i( null, t );
			} );

			this._transitions.push( s );
		}

		_getTransitionFunction( t ) {
			return ( e ) => {
				t.item.applyCss( t.styles ),
					this._whenTransitionDone( t.item.element, t.callback, e );
			};
		}

		_processQueue() {
			this.isTransitioning && this._cancelMovement();
			const t = this.options.speed > 0,
				e = this._queue.length > 0;
			e && t && this.isInitialized
				? this._startTransitions( this._queue )
				: e
				? ( this._styleImmediately( this._queue ),
				  this._dispatch( L.EventType.LAYOUT ) )
				: this._dispatch( L.EventType.LAYOUT ),
				( this._queue.length = 0 );
		}

		_startTransitions( t ) {
			this.isTransitioning = ! 0;
			! ( function ( t, e, s ) {
				s ||
					( 'function' == typeof e
						? ( ( s = e ), ( e = null ) )
						: ( s = i ) );
				var n = t && t.length;
				if ( ! n ) return s( null, [] );
				var o = ! 1,
					r = new Array( n );

				function h( t ) {
					return function ( e, i ) {
						if ( ! o ) {
							if ( e ) return s( e, r ), void ( o = ! 0 );
							( r[ t ] = i ), --n || s( null, r );
						}
					};
				}

				t.forEach(
					e
						? function ( t, i ) {
								t.call( e, h( i ) );
						  }
						: function ( t, e ) {
								t( h( e ) );
						  }
				);
			} )(
				t.map( ( t ) => this._getTransitionFunction( t ) ),
				this._movementFinished.bind( this )
			);
		}

		_cancelMovement() {
			this._transitions.forEach( _ ),
				( this._transitions.length = 0 ),
				( this.isTransitioning = ! 1 );
		}

		_styleImmediately( t ) {
			if ( t.length ) {
				const e = t.map( ( t ) => t.item.element );

				L._skipTransitions( e, () => {
					t.forEach( ( t ) => {
						t.item.applyCss( t.styles ), t.callback();
					} );
				} );
			}
		}

		_movementFinished() {
			( this._transitions.length = 0 ),
				( this.isTransitioning = ! 1 ),
				this._dispatch( L.EventType.LAYOUT );
		}

		filter( t, e ) {
			this.isEnabled &&
				( ( ! t || ( t && 0 === t.length ) ) && ( t = L.ALL_ITEMS ),
				this._filter( t ),
				this._shrink(),
				this._updateItemCount(),
				this.sort( e ) );
		}

		sort() {
			let t =
				arguments.length > 0 && void 0 !== arguments[ 0 ]
					? arguments[ 0 ]
					: this.lastSort;
			if ( ! this.isEnabled ) return;

			this._resetCols();

			const e = c( this._getFilteredItems(), t );
			( this.sortedItems = e ),
				this._layout( e ),
				this._processQueue(),
				this._setContainerSize(),
				( this.lastSort = t );
		}

		update() {
			let { recalculateSizes: t = ! 0, force: e = ! 1 } =
				arguments.length > 0 && void 0 !== arguments[ 0 ]
					? arguments[ 0 ]
					: {};
			( this.isEnabled || e ) && ( t && this._setColumns(), this.sort() );
		}

		layout() {
			this.update( {
				recalculateSizes: ! 0,
			} );
		}

		add( t ) {
			const e = S( t ).map( ( t ) => new l( t, this.options.isRTL ) );
			this._initItems( e ), this._resetCols();

			const i = c( this._mergeNewItems( e ), this.lastSort ),
				s = this._filter( this.lastFilter, i ),
				n = ( t ) => e.includes( t ),
				o = ( t ) => {
					( t.scale = l.Scale.HIDDEN ),
						( t.isHidden = ! 0 ),
						t.applyCss( l.Css.HIDDEN.before ),
						t.applyCss( l.Css.HIDDEN.after );
				},
				r = this._getNextPositions( s.visible );

			s.visible.forEach( ( t, e ) => {
				n( t ) &&
					( ( t.point = r[ e ] ),
					o( t ),
					t.applyCss( this.getStylesForTransition( t, {} ) ) );
			} ),
				s.hidden.forEach( ( t ) => {
					n( t ) && o( t );
				} ),
				this.element.offsetWidth,
				this.setItemTransitions( e ),
				( this.items = this._mergeNewItems( e ) ),
				this.filter( this.lastFilter );
		}

		disable() {
			this.isEnabled = ! 1;
		}

		enable() {
			let t =
				! ( arguments.length > 0 && void 0 !== arguments[ 0 ] ) ||
				arguments[ 0 ];
			( this.isEnabled = ! 0 ), t && this.update();
		}

		remove( t ) {
			if ( ! t.length ) return;
			const e = S( t ),
				i = e
					.map( ( t ) => this.getItemByElement( t ) )
					.filter( ( t ) => !! t );
			this._toggleFilterClasses( {
				visible: [],
				hidden: i,
			} ),
				this._shrink( i ),
				this.sort(),
				( this.items = this.items.filter(
					( t ) => ! i.includes( t )
				) ),
				this._updateItemCount(),
				this.once( L.EventType.LAYOUT, () => {
					this._disposeItems( i ),
						e.forEach( ( t ) => {
							t.parentNode.removeChild( t );
						} ),
						this._dispatch( L.EventType.REMOVED, {
							collection: e,
						} );
				} );
		}

		getItemByElement( t ) {
			return this.items.find( ( e ) => e.element === t );
		}

		resetItems() {
			this._disposeItems( this.items ),
				( this.isInitialized = ! 1 ),
				( this.items = this._getItems() ),
				this._initItems( this.items ),
				this.once( L.EventType.LAYOUT, () => {
					this.setItemTransitions( this.items ),
						( this.isInitialized = ! 0 );
				} ),
				this.filter( this.lastFilter );
		}

		destroy() {
			this._cancelMovement(),
				this._resizeObserver &&
					( this._resizeObserver.unobserve( this.element ),
					( this._resizeObserver = null ) ),
				this.element.classList.remove( 'shuffle' ),
				this.element.removeAttribute( 'style' ),
				this._disposeItems( this.items ),
				( this.items.length = 0 ),
				( this.sortedItems.length = 0 ),
				( this._transitions.length = 0 ),
				( this.options.sizer = null ),
				( this.element = null ),
				( this.isDestroyed = ! 0 ),
				( this.isEnabled = ! 1 );
		}

		static getSize( t ) {
			let e =
				arguments.length > 1 &&
				void 0 !== arguments[ 1 ] &&
				arguments[ 1 ];
			const i = window.getComputedStyle( t, null );
			let s = u( t, 'width', i ),
				n = u( t, 'height', i );

			if ( e ) {
				( s += u( t, 'marginLeft', i ) + u( t, 'marginRight', i ) ),
					( n += u( t, 'marginTop', i ) + u( t, 'marginBottom', i ) );
			}

			return {
				width: s,
				height: n,
			};
		}

		static _skipTransitions( t, e ) {
			const i = t.map( ( t ) => {
				const { style: e } = t,
					i = e.transitionDuration,
					s = e.transitionDelay;
				return (
					( e.transitionDuration = '0ms' ),
					( e.transitionDelay = '0ms' ),
					{
						duration: i,
						delay: s,
					}
				);
			} );
			e(),
				t[ 0 ].offsetWidth,
				t.forEach( ( t, e ) => {
					( t.style.transitionDuration = i[ e ].duration ),
						( t.style.transitionDelay = i[ e ].delay );
				} );
		}
	}

	return (
		( L.ShuffleItem = l ),
		( L.ALL_ITEMS = 'all' ),
		( L.FILTER_ATTRIBUTE_KEY = 'groups' ),
		( L.EventType = {
			LAYOUT: 'shuffle:layout',
			REMOVED: 'shuffle:removed',
		} ),
		( L.Classes = r ),
		( L.FilterMode = {
			ANY: 'any',
			ALL: 'all',
		} ),
		( L.options = {
			group: L.ALL_ITEMS,
			speed: 250,
			easing: 'cubic-bezier(0.4, 0.0, 0.2, 1)',
			itemSelector: '*',
			sizer: null,
			gutterWidth: 0,
			columnWidth: 0,
			delimiter: null,
			buffer: 0,
			columnThreshold: 0.01,
			initialSort: null,
			staggerAmount: 15,
			staggerAmountMax: 150,
			useTransforms: ! 0,
			filterMode: L.FilterMode.ANY,
			isCentered: ! 1,
			isRTL: ! 1,
			roundTransforms: ! 0,
		} ),
		( L.Point = n ),
		( L.Rect = o ),
		( L.__sorter = c ),
		( L.__getColumnSpan = E ),
		( L.__getAvailablePositions = v ),
		( L.__getShortColumn = b ),
		( L.__getCenteredPositions = T ),
		L
	);
} );
