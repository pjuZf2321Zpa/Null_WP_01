<?php
/**
 * Plugin file.
 *
 * @package DiviSupreme
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

// Setup constants.
define( 'DSM_DIR_URL', plugin_dir_url( __FILE__ ) );

if ( ! class_exists( 'Divi_Supreme_5' ) ) {
	/**
	 * Main Divi Supreme Class.
	 */
	class Divi_Supreme_5 {



		/**
		 * Registered module instances.
		 *
		 * @var array
		 */
		private $modules = array();

		/**
		 * Frontend / Visual Builder asset registration.
		 *
		 * @var \DiviSupreme\Core\Supreme5FrontendAssets
		 */
		private $frontend_assets;

		/**
		 * Constructor.
		 *
		 * @return void
		 */
		public function __construct() {

			$dsm_autoload_app = DSM_DIR_PATH . 'divi-5/app/autoload.php';
			if ( is_readable( $dsm_autoload_app ) ) {
				require_once $dsm_autoload_app;
			} elseif ( is_readable( DSM_DIR_PATH . 'divi-5/vendor/autoload.php' ) ) {
				require_once DSM_DIR_PATH . 'divi-5/vendor/autoload.php';
			}

			// Divi `has_value()` + a string leaf fatals the request. Coerce before render.
			if ( class_exists( \DiviSupreme\Includes\HasValueStringLeafGuard::class ) ) {
				\DiviSupreme\Includes\HasValueStringLeafGuard::register();
			}

			// Support access must load even when other extensions are off.
			$this->load_class_file( 'divi-5/app/Includes/Support/SystemStatus.php', \DiviSupreme\Includes\Support\SystemStatus::class );
			if ( $this->load_class_file( 'divi-5/app/Includes/Support/TemporaryAccess.php', \DiviSupreme\Includes\Support\TemporaryAccess::class ) ) {
				\DiviSupreme\Includes\Support\TemporaryAccess::register();
			}
			$this->require_if_readable( 'divi-5/app/Includes/dsm-supreme-popup-enabled.php' );
			$this->require_if_readable( 'divi-5/app/Includes/dsm-supreme-line-hover-animation-extension-enabled.php' );
			$this->require_if_readable( 'divi-5/app/Includes/dsm-supreme-parallax-extension-enabled.php' );
			$this->require_if_readable( 'divi-5/app/Includes/dsm-image-parallax-extension-enabled.php' );
			$this->require_if_readable( 'divi-5/app/Includes/dsm-custom-cursor-extension-enabled.php' );
			$this->require_if_readable( 'divi-5/app/Includes/dsm-preloader-extension-enabled.php' );
			$this->require_if_readable( 'divi-5/app/Includes/dsm-dark-mode-extension-enabled.php' );
			$this->require_if_readable( 'divi-5/app/Includes/dsm-copy-to-clipboard-enabled.php' );
			$this->require_if_readable( 'divi-5/app/Includes/dsm-tooltip-extension-enabled.php' );
			$this->require_if_readable( 'divi-5/app/Includes/dsm-page-tour-extension-enabled.php' );
			$this->require_if_readable( 'divi-5/app/Includes/dsm-password-protection-extension-enabled.php' );
			$this->require_if_readable( 'divi-5/app/Includes/dsm-client-handoff-extension-enabled.php' );
			$this->require_if_readable( 'divi-5/app/Includes/dsm-contact-form-entries-extension-enabled.php' );
			$this->require_if_readable( 'divi-5/app/Includes/dsm-loop-filter-extension-enabled.php' );
			if ( function_exists( 'dsm_maybe_migrate_loop_filter_extension_option_to_modules' ) ) {
				dsm_maybe_migrate_loop_filter_extension_option_to_modules();
			}
			$this->require_if_readable( 'divi-5/app/extensions/IconLibraries/ExtensionSettings.php' );
			$this->require_if_readable( 'divi-5/app/extensions/MaskPatternLibrary/ExtensionSettings.php' );
			if ( class_exists( \DiviSupreme\Includes\Divi5Conversion\Orchestrator::class ) ) {
				\DiviSupreme\Includes\Divi5Conversion\Orchestrator::register();
			}

			$this->modules = array();
			if ( $this->load_class_file( 'divi-5/app/Core/ModuleRegistry.php', \DiviSupreme\Core\ModuleRegistry::class ) ) {
				$this->modules = \DiviSupreme\Core\ModuleRegistry::get_enabled_module_classes();
			}

			// Includes.
			$this->require_if_readable( 'divi-5/app/Includes/dsm-rest-extend.php' );
			$this->require_if_readable( 'divi-5/app/Includes/dsm-post-format-taxonomy-rest.php' );
			$this->require_if_readable( 'divi-5/app/Includes/dsm-magnific-popup-assets.php' );
			$this->require_if_readable( 'divi-5/app/Includes/dsm-divi-icon-font-assets.php' );
			$this->require_if_readable( 'divi-5/app/Includes/dsm-media-rest-extend.php' );
			$this->require_if_readable( 'divi-5/app/Includes/dsm-attachment-taxonomy.php' );
			$this->require_if_readable( 'divi-5/app/Includes/dsm-attachment-category-fields.php' );
			$this->require_if_readable( 'divi-5/app/Includes/dsm-dynamic-assets-loader.php' );
			$this->require_if_readable( 'divi-5/app/Includes/dsm-dynamic-assets-library-supplement.php' );
			$this->require_if_readable( 'divi-5/app/Includes/dsm-library-layout-preview-rest.php' );
			$this->require_if_readable( 'divi-5/app/Includes/dsm-shortcode-preview-rest.php' );
			$this->require_if_readable( 'divi-5/app/Includes/dsm-nav-menus-rest.php' );
			$this->require_if_readable( 'divi-5/app/Includes/DiviShopBuilderAjaxCompat.php' );
			$this->load_class_file( 'divi-5/app/Includes/DsmDiviShortcode.php', \DiviSupreme\Includes\DsmDiviShortcode::class );
			if ( function_exists( 'dsm_is_supreme_popup_extension_enabled' ) && dsm_is_supreme_popup_extension_enabled() ) {
				$this->require_if_readable( 'divi-5/app/Includes/dsm-popup-visual-preview-rest.php' );
			}

			if ( class_exists( \DiviSupreme\Includes\DsmVbRestSave::class ) ) {
				\DiviSupreme\Includes\DsmVbRestSave::register_hooks();
			}

			if ( class_exists( \DiviSupreme\Includes\DsmVbSettingsDataRest::class ) ) {
				\DiviSupreme\Includes\DsmVbSettingsDataRest::register_hooks();
			}

			if ( class_exists( \DiviSupreme\Includes\DsmTableLibrary::class ) ) {
				\DiviSupreme\Includes\DsmTableLibrary::register();
			}

			if ( class_exists( \DiviSupreme\Includes\DsmTestimonials::class ) ) {
				\DiviSupreme\Includes\DsmTestimonials::register();
			}

			if ( class_exists( \DiviSupreme\Includes\DsmFrontendDynamicAssets::class ) ) {
				\DiviSupreme\Includes\DsmFrontendDynamicAssets::register_hooks();
			}

			if ( class_exists( \DiviSupreme\Includes\DsmDiviBuilderCssScope::class ) ) {
				\DiviSupreme\Includes\DsmDiviBuilderCssScope::register_hooks();
			}

			if ( class_exists( \DiviSupreme\Includes\DsmDeferFrontendScripts::class ) ) {
				\DiviSupreme\Includes\DsmDeferFrontendScripts::register_hooks();
			}

			if ( class_exists( \DiviSupreme\Includes\DiviShopBuilderAjaxCompat::class ) ) {
				\DiviSupreme\Includes\DiviShopBuilderAjaxCompat::register_hooks();
			}

			if ( class_exists( \DiviSupreme\Includes\DsmWebpackScriptOptimizerCompat::class ) ) {
				\DiviSupreme\Includes\DsmWebpackScriptOptimizerCompat::register_hooks();
			}

			if ( function_exists( 'dsm_is_supreme_popup_extension_enabled' ) && dsm_is_supreme_popup_extension_enabled() ) {
				$this->require_if_readable( 'divi-5/app/extensions/Popup.php' );
			}

			if ( function_exists( 'dsm_is_tooltip_extension_enabled' ) && dsm_is_tooltip_extension_enabled() ) {
				$this->require_if_readable( 'divi-5/app/extensions/Tooltip.php' );
			}

			if ( function_exists( 'dsm_is_page_tour_extension_enabled' ) && dsm_is_page_tour_extension_enabled() ) {
				// Instantiated at file load (`$GLOBALS['dsm_page_tour_extension']`).
				$this->load_class_file( 'divi-5/app/extensions/PageTour.php', \DiviSupreme\Extensions\PageTour::class );
			}

			if ( function_exists( 'dsm_is_line_hover_animation_extension_enabled' ) && dsm_is_line_hover_animation_extension_enabled() ) {
				$this->require_if_readable( 'divi-5/app/extensions/LineHoverAnimation.php' );
			}

			if ( function_exists( 'dsm_is_supreme_parallax_extension_enabled' ) && dsm_is_supreme_parallax_extension_enabled() ) {
				$this->require_if_readable( 'divi-5/app/extensions/SupremeParallax.php' );
			}

			if ( function_exists( 'dsm_is_image_parallax_extension_enabled' ) && dsm_is_image_parallax_extension_enabled() ) {
				$this->require_if_readable( 'divi-5/app/extensions/ImageParallax.php' );
			}

			if ( function_exists( 'dsm_is_custom_cursor_extension_enabled' ) && dsm_is_custom_cursor_extension_enabled() ) {
				$this->require_if_readable( 'divi-5/app/extensions/CustomCursor.php' );
				$this->require_if_readable( 'divi-5/app/Includes/dsm-custom-cursor-settings-rest.php' );
				$this->require_if_readable( 'divi-5/app/Includes/dsm-custom-cursor-scope-posts-rest.php' );
				$this->require_if_readable( 'divi-5/app/Includes/dsm-custom-cursor-scope-quick-picks.php' );
			}

			if ( function_exists( 'dsm_is_preloader_extension_enabled' )
				&& dsm_is_preloader_extension_enabled()
				&& $this->load_class_file( 'divi-5/app/extensions/Preloader.php', \DiviSupreme\Extensions\Preloader::class ) ) {
				new \DiviSupreme\Extensions\Preloader();
				$this->require_if_readable( 'divi-5/app/Includes/dsm-preloader-settings-rest.php' );
				// Scope picker REST / quick picks (shared with Custom Cursor when that extension is off).
				if ( ! class_exists( 'DSM_Custom_Cursor_Scope_Posts_REST', false ) ) {
					$this->require_if_readable( 'divi-5/app/Includes/dsm-custom-cursor-scope-posts-rest.php' );
				}
				if ( ! function_exists( 'dsm_get_custom_cursor_scope_quick_picks' ) ) {
					$this->require_if_readable( 'divi-5/app/Includes/dsm-custom-cursor-scope-quick-picks.php' );
				}
			}

			if ( function_exists( 'dsm_is_dark_mode_extension_enabled' ) && dsm_is_dark_mode_extension_enabled() ) {
				$this->require_if_readable( 'divi-5/app/extensions/DarkMode.php' );
				$this->require_if_readable( 'divi-5/app/extensions/DarkModeOverrides.php' );
				$this->require_if_readable( 'divi-5/app/extensions/DarkModeAutoRemap.php' );
				$this->require_if_readable( 'divi-5/app/Includes/dsm-dark-mode-settings-rest.php' );
				// Scope picker REST / quick picks (shared with Custom Cursor when that extension is off).
				if ( ! class_exists( 'DSM_Custom_Cursor_Scope_Posts_REST', false ) ) {
					$this->require_if_readable( 'divi-5/app/Includes/dsm-custom-cursor-scope-posts-rest.php' );
				}
				if ( ! function_exists( 'dsm_get_custom_cursor_scope_quick_picks' ) ) {
					$this->require_if_readable( 'divi-5/app/Includes/dsm-custom-cursor-scope-quick-picks.php' );
				}
				// Do not class_exists() this module here — it implements a Divi
				// interface and autoload would fatal before the theme is loaded.
				$this->modules[] = \DiviSupreme\Modules\DarkModeToggle::class;
			}

			// PHP-only: Maintenance & Coming Soon (settings under Miscellaneous; no VB package).
			if ( $this->load_class_file( 'divi-5/app/extensions/MaintenanceMode.php', \DiviSupreme\Extensions\MaintenanceMode::class ) ) {
				new \DiviSupreme\Extensions\MaintenanceMode();
			}

			// PHP-only: Custom 404 Page (settings under Miscellaneous; no VB package).
			if ( $this->load_class_file( 'divi-5/app/extensions/Custom404.php', \DiviSupreme\Extensions\Custom404::class ) ) {
				new \DiviSupreme\Extensions\Custom404();
			}

			if ( function_exists( 'dsm_is_copy_to_clipboard_extension_enabled' )
				&& dsm_is_copy_to_clipboard_extension_enabled()
				&& $this->load_class_file( 'divi-5/app/extensions/CopyToClipboard.php', \DiviSupreme\Extensions\CopyToClipboard::class ) ) {
				new \DiviSupreme\Extensions\CopyToClipboard();
			}

			if ( function_exists( 'dsm_is_contact_form_entries_extension_enabled' ) && dsm_is_contact_form_entries_extension_enabled()
				&& $this->load_class_file( 'divi-5/app/extensions/ContactFormEntries.php', \DiviSupreme\Extensions\ContactFormEntries::class ) ) {
				new \DiviSupreme\Extensions\ContactFormEntries();
			}

			if ( function_exists( 'dsm_is_loop_filter_module_enabled' ) && dsm_is_loop_filter_module_enabled() ) {
				$this->require_if_readable( 'divi-5/app/Utils/loop-filter-meta-keys.php' );
				$this->require_if_readable( 'divi-5/app/extensions/LoopFilter.php' );
				if ( class_exists( \DiviSupreme\Extensions\LoopFilter::class ) ) {
					new \DiviSupreme\Extensions\LoopFilter();
				}
			}

			// PHP + Password Form module: sitewide Protection (settings under Protection tab).
			$this->load_class_file( 'divi-5/app/extensions/PasswordProtectionBlock.php', \DiviSupreme\Extensions\PasswordProtectionBlock::class );
			$this->load_class_file( 'divi-5/app/extensions/PasswordProtectionMetabox.php', \DiviSupreme\Extensions\PasswordProtectionMetabox::class );
			if ( $this->load_class_file( 'divi-5/app/extensions/PasswordProtection.php', \DiviSupreme\Extensions\PasswordProtection::class ) ) {
				new \DiviSupreme\Extensions\PasswordProtection();
			}

			if ( $this->load_class_file( 'divi-5/app/extensions/ClientHandoff.php', \DiviSupreme\Extensions\ClientHandoff::class ) ) {
				new \DiviSupreme\Extensions\ClientHandoff();
			}

			if ( $this->load_class_file( 'divi-5/app/extensions/ClientGuide.php', \DiviSupreme\Extensions\ClientGuide::class ) ) {
				new \DiviSupreme\Extensions\ClientGuide();
			}

			$this->require_if_readable( 'divi-5/app/extensions/IconLibraries/load-always.php' );

			if ( function_exists( 'dsm_is_icon_libraries_extension_enabled' )
				&& dsm_is_icon_libraries_extension_enabled()
				&& $this->load_class_file( 'divi-5/app/extensions/IconLibraries.php', \DiviSupreme\Extensions\IconLibraries::class ) ) {
				new \DiviSupreme\Extensions\IconLibraries();
			}

			if ( function_exists( 'dsm_is_mask_pattern_library_extension_enabled' )
				&& dsm_is_mask_pattern_library_extension_enabled()
				&& $this->load_class_file( 'divi-5/app/extensions/MaskPatternLibrary.php', \DiviSupreme\Extensions\MaskPatternLibrary::class ) ) {
				new \DiviSupreme\Extensions\MaskPatternLibrary();
			}

			// Core.
			$this->require_if_readable( 'divi-5/app/Core/Assets.php' );
			if ( ! function_exists( 'dsm_is_marketplace_build' ) || ! dsm_is_marketplace_build() ) {
				$this->require_if_readable( 'divi-5/app/Core/License.php' );
			}
			$this->require_if_readable( 'divi-5/app/Core/SettingsApi.php' );
			$this->require_if_readable( 'divi-5/app/Core/Settings.php' );
			$this->require_if_readable( 'divi-5/app/Includes/dsm-divi-cache-clear-enabled.php' );

			if ( class_exists( \DiviSupreme\Includes\DiviCacheClear::class ) ) {
				\DiviSupreme\Includes\DiviCacheClear::register();
			}

			if ( $this->load_class_file( 'divi-5/app/Core/Supreme5FrontendAssets.php', \DiviSupreme\Core\Supreme5FrontendAssets::class ) ) {
				$this->frontend_assets = new \DiviSupreme\Core\Supreme5FrontendAssets( $this );
			}

			add_action(
				'divi_module_library_modules_dependency_tree',
				function ( $dependency_tree ) {

					// Utils.
					$this->require_if_readable( 'divi-5/app/Utils/is-cf7-active.php' );
					$this->require_if_readable( 'divi-5/app/Utils/get-image-sizes.php' );
					$this->require_if_readable( 'divi-5/app/Utils/get-post-type-taxonomies.php' );
					$this->require_if_readable( 'divi-5/app/Utils/loop-filter-meta-keys.php' );
					$this->require_if_readable( 'divi-5/app/Utils/get-post-types.php' );

					foreach ( $this->modules as $module ) {
						if ( ! is_string( $module ) || ! class_exists( $module ) ) {
							continue;
						}
						$dependency_tree->add_dependency(
							new $module()
						);
					}

					return $dependency_tree;
				}
			);

			// Initialising modules.
			if ( $this->frontend_assets ) {
				add_action(
					'divi_visual_builder_assets_before_enqueue_scripts',
					array( $this->frontend_assets, 'load_vb_assets' )
				);

				// Swiper in top-window VB (Divi Library layout editor canvas iframe).
				add_action(
					'divi_visual_builder_assets_before_enqueue_top_window_scripts',
					array( $this->frontend_assets, 'load_vb_top_window_swiper_assets' ),
					5
				);

				add_action(
					'divi_visual_builder_assets_before_enqueue_top_window_scripts',
					array( $this->frontend_assets, 'load_vb_top_window_icon_libraries_assets' ),
					100
				);

				// Swiper in app-window VB before the full modules bundle.
				add_action(
					'divi_visual_builder_assets_before_enqueue_app_window_scripts',
					array( $this->frontend_assets, 'load_vb_top_window_swiper_assets' ),
					5
				);

				// Popup Customiser: `divi-modal-library` snapshots `divi.modalLibrary.modalMapping` once;
				// ensure extensions (which registers the filter) loads first even if Divi registers modal-library early.
				add_action(
					'wp_print_scripts',
					array( $this->frontend_assets, 'dsm_ensure_extensions_before_divi_modal_library' ),
					1
				);

				add_action(
					'wp_print_scripts',
					array( $this->frontend_assets, 'dsm_ensure_icon_libraries_hooks_before_divi_icon_library' ),
					1
				);

				add_action(
					'wp_print_scripts',
					array( $this->frontend_assets, 'dsm_ensure_mask_pattern_library_hooks_before_divi_library' ),
					1
				);

				add_action(
					'divi_visual_builder_assets_after_enqueue_scripts',
					array( $this->frontend_assets, 'finalize_icon_libraries_vb_script_dependencies' ),
					999
				);

				// Divi_visual_builder_assets_before_enqueue_packages.
				add_action(
					'init',
					array( $this->frontend_assets, 'load_frontend_assets' )
				);

				add_action(
					'init',
					array( $this->frontend_assets, 'register_supreme_lightbox_assets' ),
					99
				);

				// After Divi 5 registers `divi-script-library-ext-waypoint` (priority 10).
				add_action(
					'wp_enqueue_scripts',
					array( $this->frontend_assets, 'register_shuffle_letters_assets' ),
					11
				);

				add_action(
					'wp_enqueue_scripts',
					array( $this->frontend_assets, 'register_text_rotator_assets' ),
					11
				);

				add_action(
					'wp_enqueue_scripts',
					array( $this->frontend_assets, 'register_text_notation_assets' ),
					11
				);

				add_action(
					'wp_enqueue_scripts',
					array( $this->frontend_assets, 'register_progress_bar_assets' ),
					11
				);

				add_action(
					'wp_enqueue_scripts',
					array( $this->frontend_assets, 'register_block_reveal_assets' ),
					11
				);
			}

			add_action(
				'widgets_init',
				array( $this, 'register_divi_library_widget' )
			);

			// `[divi_shortcode id="…"]` (+ alias `divi_library_layout`) — D4 registers in D4 bootstrap only; mirror for D5.
			add_action(
				'init',
				static function (): void {
					if ( ! function_exists( 'et_builder_d5_enabled' ) || ! et_builder_d5_enabled() ) {
						return;
					}

					if ( class_exists( \DiviSupreme\Includes\DsmDiviShortcode::class ) ) {
						\DiviSupreme\Includes\DsmDiviShortcode::register();
					}
				},
				20
			);
		}

		/**
		 * Checks if the DIVI 5 theme is installed and active.
		 *
		 * @return bool - True if active, otherwise false.
		 */
		public function is_divi_5_installed_and_active() {
			return function_exists( 'et_builder_d5_enabled' ) && et_builder_d5_enabled();
		}

		/**
		 * Registers the Divi Library widget (id `dsm_widget_library`) when enabled in Supreme settings.
		 *
		 * Output uses {@see \DiviSupreme\Includes\DiviLibraryLayoutRenderer::render_layout()} (Divi 5 layout pipeline).
		 *
		 * @return void
		 */
		public function register_divi_library_widget() {
			if ( ! $this->is_divi_5_installed_and_active() ) {
				return;
			}

			$dsm_general = get_option( 'dsm_general', array() );

			if ( ! is_array( $dsm_general ) ) {
				$dsm_general = array();
			}

			$enabled = isset( $dsm_general['dsm_use_library_widget'] ) && 'on' === $dsm_general['dsm_use_library_widget'];

			if ( ! $enabled ) {
				return;
			}

			if ( $this->load_class_file( 'divi-5/app/Includes/Dsm_Widget_Library.php', \DiviSupreme\Includes\Dsm_Widget_Library::class ) ) {
				register_widget( \DiviSupreme\Includes\Dsm_Widget_Library::class );
			}
		}

		/**
		 * Require a PHP file when readable. Never fatals if the file is missing.
		 *
		 * @param string $relative Path under DSM_DIR_PATH.
		 * @return bool True when the file was loaded.
		 */
		private function require_if_readable( string $relative ): bool {
			$path = DSM_DIR_PATH . $relative;
			if ( ! is_readable( $path ) ) {
				return false;
			}

			require_once $path;

			return true;
		}

		/**
		 * Require a class file when readable. Never fatals if the file is missing.
		 *
		 * @param string $relative Path under DSM_DIR_PATH.
		 * @param string $fqcn     Fully-qualified class name.
		 * @return bool
		 */
		private function load_class_file( string $relative, string $fqcn ): bool {
			$this->require_if_readable( $relative );

			// false = do not autoload. Module classes implement Divi interfaces
			// and must not be loaded before the theme registers ET\Builder\*.
			return class_exists( $fqcn, false );
		}
	}

	new Divi_Supreme_5();
}
