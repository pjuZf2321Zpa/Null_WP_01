<?php
/**
 * Contact Form 7 detection.
 *
 * @package DiviSupreme
 */

/**
 * Whether the Contact Form 7 plugin is active.
 *
 * @return bool
 */
function dsm_is_cf7_active() {
	return class_exists( 'WPCF7_ContactForm' );
}
