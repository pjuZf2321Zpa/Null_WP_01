<?php
/**
 * Shared allowlist for heading tags printed from `headingLevel`.
 *
 * Matches the Divi 5.18 Tabs stored-XSS fix: only h1–h6, p, div, and span
 * may be used as an HTML element name.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Utils;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Sanitize a Divi `headingLevel` before it is printed as a tag name.
 */
final class HeadingLevel {

	/**
	 * Hard allowlist. Filters may only narrow this set.
	 *
	 * @var list<string>
	 */
	private const ALLOWED_TAGS = array(
		'h1',
		'h2',
		'h3',
		'h4',
		'h5',
		'h6',
		'p',
		'div',
		'span',
	);

	/**
	 * Tags a module may print as an HTML element name.
	 *
	 * @return list<string>
	 */
	public static function allowed_tags(): array {
		$allowed = self::ALLOWED_TAGS;

		if ( ! function_exists( 'apply_filters' ) ) {
			return $allowed;
		}

		/**
		 * Filter heading tags Supreme modules may print as an HTML element name.
		 *
		 * Values outside h1–h6, p, div, and span are ignored so the filter
		 * cannot introduce a tag name.
		 *
		 * @param array<int, string> $allowed Allowlisted tag names.
		 */
		$filtered = apply_filters( 'dsm_allowed_heading_tags', $allowed );

		if ( ! is_array( $filtered ) ) {
			return $allowed;
		}

		$out = array();
		foreach ( $filtered as $tag ) {
			if ( ! is_string( $tag ) ) {
				continue;
			}
			$tag = strtolower( trim( $tag ) );
			if ( in_array( $tag, self::ALLOWED_TAGS, true ) ) {
				$out[] = $tag;
			}
		}

		$out = array_values( array_unique( $out ) );

		return array() === $out ? $allowed : $out;
	}

	/**
	 * Whether a raw heading level is on the shared allowlist.
	 *
	 * @param mixed $heading_level Raw `headingLevel` value.
	 * @return bool
	 */
	public static function is_allowed( $heading_level ): bool {
		if ( ! is_string( $heading_level ) ) {
			return false;
		}

		$tag = strtolower( trim( $heading_level ) );

		return '' !== $tag && in_array( $tag, self::allowed_tags(), true );
	}

	/**
	 * Return an allowlisted heading tag.
	 *
	 * @param mixed  $heading_level Raw `headingLevel` value.
	 * @param string $fallback      Tag used when the value is empty or not allowlisted.
	 * @return string
	 */
	public static function sanitize( $heading_level, string $fallback = 'h2' ): string {
		$allowed      = self::allowed_tags();
		$fallback_tag = strtolower( trim( $fallback ) );
		if ( ! in_array( $fallback_tag, $allowed, true ) ) {
			$fallback_tag = in_array( 'h2', $allowed, true ) ? 'h2' : $allowed[0];
		}

		if ( ! is_string( $heading_level ) ) {
			return $fallback_tag;
		}

		$tag = strtolower( trim( $heading_level ) );
		if ( '' === $tag || ! in_array( $tag, $allowed, true ) ) {
			return $fallback_tag;
		}

		return $tag;
	}
}
