<?php
/**
 * Taxonomies exposed per post type for Visual Builder controls (e.g. Post Carousel).
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

/**
 * Map taxonomy name → REST base (collection route segment and posts/pages filter parameter).
 *
 * @return array<string, string>
 */
function dsm_get_taxonomy_rest_base_map(): array {
	$map = array();

	foreach ( get_taxonomies( array( 'show_in_rest' => true ), 'objects' ) as $tax_object ) {
		if ( ! $tax_object instanceof WP_Taxonomy ) {
			continue;
		}

		$base = $tax_object->rest_base;
		if ( ! is_string( $base ) || '' === $base ) {
			$base = $tax_object->name;
		}

		$map[ $tax_object->name ] = $base;
	}

	return $map;
}

/**
 * Retrieve taxonomies associated with a post type for module settings (name + label).
 *
 * Post Carousel uses Divi {@see \ET\Builder\Packages\ModuleUtils\ModuleUtils::add_category_query_args()}
 * for the `page` post type (All Categories / Current Category) instead of per-term controls.
 *
 * @param string $post_type_slug The slug of the post type.
 * @return array<int, array{name: string, label: string}>
 */
function dsm_get_post_type_taxonomies( string $post_type_slug ): array {
	if ( ! post_type_exists( $post_type_slug ) ) {
		return array();
	}

	$taxonomies = get_object_taxonomies( $post_type_slug, 'objects' );

	$result = array();

	foreach ( $taxonomies as $taxonomy ) {
		$result[] = array(
			'name'  => $taxonomy->name,
			'label' => $taxonomy->label,
		);
	}

	return $result;
}

/**
 * Human-readable taxonomy label (plural name preferred).
 *
 * @param WP_Taxonomy $taxonomy Taxonomy object.
 * @return string
 */
function dsm_get_taxonomy_display_label( WP_Taxonomy $taxonomy ): string {
	$label = '';
	if ( isset( $taxonomy->labels ) && is_object( $taxonomy->labels ) ) {
		$label = (string) ( $taxonomy->labels->name ?? '' );
	}
	if ( '' === $label ) {
		$label = (string) $taxonomy->label;
	}
	if ( '' === $label ) {
		$label = (string) $taxonomy->name;
	}

	return $label;
}

/**
 * Disambiguate taxonomy labels that collide (e.g. Categories → Categories (category)).
 *
 * @param array<int, array{name: string, label: string, objectTypes?: list<string>}> $items Taxonomies.
 * @return array<int, array{name: string, label: string, objectTypes?: list<string>}>
 */
function dsm_disambiguate_taxonomy_labels( array $items ): array {
	$label_counts = array();
	foreach ( $items as $item ) {
		$key = isset( $item['label'] ) ? (string) $item['label'] : '';
		if ( '' === $key ) {
			continue;
		}
		$label_counts[ $key ] = ( $label_counts[ $key ] ?? 0 ) + 1;
	}

	foreach ( $items as $index => $item ) {
		$name  = isset( $item['name'] ) ? (string) $item['name'] : '';
		$label = isset( $item['label'] ) ? (string) $item['label'] : '';
		if ( '' === $name || '' === $label ) {
			continue;
		}
		if ( ( $label_counts[ $label ] ?? 0 ) > 1 ) {
			$items[ $index ]['label'] = sprintf( '%1$s (%2$s)', $label, $name );
		}
	}

	return $items;
}

/**
 * Whether a taxonomy may appear in Supreme Loop Filter taxonomy pickers.
 *
 * Public taxonomies are always eligible. When WooCommerce is active, also allow
 * non-public product taxonomies that still expose an admin UI (`show_ui`), most
 * notably global attribute taxonomies (`pa_*`) whose archives are disabled
 * (`attribute_public = 0` -> `public = false`). Divi's Post Filter lists those via
 * `get_object_taxonomies()` without a public-only gate.
 *
 * Internal Woo taxonomies without UI (`product_type`, `product_visibility`, etc.)
 * stay excluded.
 *
 * @param WP_Taxonomy $taxonomy Taxonomy object.
 * @return bool
 */
function dsm_is_taxonomy_eligible_for_loop_filter( WP_Taxonomy $taxonomy ): bool {
	if ( $taxonomy->public ) {
		return true;
	}

	if ( ! $taxonomy->show_ui ) {
		return false;
	}

	if ( ! class_exists( 'WooCommerce' ) ) {
		return false;
	}

	$name = (string) $taxonomy->name;
	if ( 0 === strpos( $name, 'pa_' ) ) {
		return true;
	}

	$object_types = array();
	if ( isset( $taxonomy->object_type ) && is_array( $taxonomy->object_type ) ) {
		foreach ( $taxonomy->object_type as $object_type ) {
			if ( is_string( $object_type ) && '' !== $object_type ) {
				$object_types[] = sanitize_key( $object_type );
			}
		}
	}

	return in_array( 'product', $object_types, true );
}

/**
 * Public (and Woo-eligible) taxonomies for Supreme Loop Filter VB picker / FE UI.
 *
 * When `$post_types` is provided, only taxonomies whose `object_type` intersects
 * those post types are returned (excludes noise like Module Width / layout taxonomies
 * unless the nested Loop actually queries that post type).
 *
 * Pass `null` to return the full catalog for VB client-side filtering.
 * Pass an empty array to return an empty list.
 *
 * @param list<string>|null $post_types Optional post type slugs to scope by.
 * @return array<int, array{name: string, label: string, objectTypes: list<string>}>
 */
function dsm_get_public_taxonomies_for_loop_filter( ?array $post_types = null ): array {
	$scoped_post_types = null;
	if ( null !== $post_types ) {
		$scoped_post_types = array_values(
			array_unique(
				array_filter(
					array_map(
						static function ( $post_type ) {
							return is_string( $post_type ) ? sanitize_key( $post_type ) : '';
						},
						$post_types
					)
				)
			)
		);
	}

	if ( is_array( $scoped_post_types ) && empty( $scoped_post_types ) ) {
		return array();
	}

	$taxonomies_by_slug = array();

	if ( is_array( $scoped_post_types ) ) {
		foreach ( $scoped_post_types as $post_type ) {
			if ( ! post_type_exists( $post_type ) ) {
				continue;
			}
			$for_type = get_object_taxonomies( $post_type, 'objects' );
			if ( ! is_array( $for_type ) ) {
				continue;
			}
			foreach ( $for_type as $taxonomy_slug => $taxonomy ) {
				if ( ! $taxonomy instanceof WP_Taxonomy || ! dsm_is_taxonomy_eligible_for_loop_filter( $taxonomy ) ) {
					continue;
				}
				$taxonomies_by_slug[ (string) $taxonomy_slug ] = $taxonomy;
			}
		}
	} else {
		// Public taxonomies + Woo show_ui product/attribute taxonomies (may be non-public).
		$candidates = get_taxonomies( array(), 'objects' );
		if ( is_array( $candidates ) ) {
			foreach ( $candidates as $taxonomy_slug => $taxonomy ) {
				if ( ! $taxonomy instanceof WP_Taxonomy || ! dsm_is_taxonomy_eligible_for_loop_filter( $taxonomy ) ) {
					continue;
				}
				$taxonomies_by_slug[ (string) $taxonomy_slug ] = $taxonomy;
			}
		}
	}

	$result = array();

	foreach ( $taxonomies_by_slug as $taxonomy ) {
		if ( ! $taxonomy instanceof WP_Taxonomy ) {
			continue;
		}

		$object_types = array();
		if ( isset( $taxonomy->object_type ) && is_array( $taxonomy->object_type ) ) {
			foreach ( $taxonomy->object_type as $object_type ) {
				if ( is_string( $object_type ) && '' !== $object_type ) {
					$object_types[] = sanitize_key( $object_type );
				}
			}
		}

		$result[] = array(
			'name'        => (string) $taxonomy->name,
			'label'       => dsm_get_taxonomy_display_label( $taxonomy ),
			'objectTypes' => array_values( array_unique( $object_types ) ),
		);
	}

	$result = dsm_disambiguate_taxonomy_labels( $result );

	usort(
		$result,
		static function ( array $a, array $b ): int {
			return strcasecmp( $a['label'], $b['label'] );
		}
	);

	/**
	 * Filter public taxonomies offered by Supreme Loop Filter.
	 *
	 * @param array<int, array{name: string, label: string, objectTypes: list<string>}> $result     Taxonomies.
	 * @param list<string>|null                                                           $post_types Scoped post types, or null for full catalog.
	 */
	$filtered = apply_filters( 'dsm_loop_filter_public_taxonomies', $result, $scoped_post_types );

	return is_array( $filtered ) ? $filtered : $result;
}

/**
 * Public post type slug → plural label for Loop Filter Field Option groups.
 *
 * @return array<string, string>
 */
function dsm_get_loop_filter_post_type_labels(): array {
	$out = array();

	foreach ( get_post_types( array( 'public' => true ), 'objects' ) as $slug => $post_type ) {
		if ( ! $post_type instanceof WP_Post_Type ) {
			continue;
		}
		$label = '';
		if ( isset( $post_type->labels ) && is_object( $post_type->labels ) ) {
			$label = (string) ( $post_type->labels->name ?? '' );
		}
		if ( '' === $label ) {
			$label = (string) $post_type->label;
		}
		if ( '' === $label ) {
			$label = (string) $slug;
		}
		$out[ sanitize_key( (string) $slug ) ] = $label;
	}

	/**
	 * Filter post type labels used to group Loop Filter Field Option taxonomies.
	 *
	 * @param array<string, string> $out Slug → plural label.
	 */
	$filtered = apply_filters( 'dsm_loop_filter_post_type_labels', $out );

	return is_array( $filtered ) ? $filtered : $out;
}
