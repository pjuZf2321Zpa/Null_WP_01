<?php
/**
 * Registered image sizes.
 *
 * @package DiviSupreme
 */

/**
 * Registered intermediate image sizes and their dimensions.
 *
 * @return array<string, array<string, int>>
 */
function dsm_get_all_image_sizes() {
	global $_wp_additional_image_sizes;

	$sizes = array();

	foreach ( get_intermediate_image_sizes() as $_size ) {
		if ( in_array( $_size, array( 'thumbnail', 'medium', 'medium_large', 'large' ), true ) ) {
			$sizes[ $_size ]['width']  = get_option( "{$_size}_size_w" );
			$sizes[ $_size ]['height'] = get_option( "{$_size}_size_h" );
			$sizes[ $_size ]['crop']   = (bool) get_option( "{$_size}_crop" );
		} elseif ( isset( $_wp_additional_image_sizes[ $_size ] ) ) {
			$sizes[ $_size ] = array(
				'width'  => $_wp_additional_image_sizes[ $_size ]['width'],
				'height' => $_wp_additional_image_sizes[ $_size ]['height'],
				'crop'   => $_wp_additional_image_sizes[ $_size ]['crop'],
			);
		}
	}

	$image_sizes = array(
		'full' => esc_html__( 'Full Size', 'dsm-supreme-modules-pro-for-divi' ),
	);

	foreach ( $sizes as $size_key => $size_value ) {
		$size_key_title           = str_replace( '_', ' ', $size_key );
		$size_key_title           = str_replace( '-', ' ', $size_key_title );
		$image_sizes[ $size_key ] = sprintf(
			'%1$s (W: %2$s x H: %3$s,%4$s Cropped)',
			ucfirst( $size_key_title ),
			$size_value['width'],
			$size_value['height'],
			( false === $size_value['crop'] ? ' Not' : '' )
		);
	}

	return $image_sizes;
}
