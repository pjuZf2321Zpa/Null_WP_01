<?php
/**
 * Localized post meta keys for Loop Filter Item Custom Field picker.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

/**
 * Meta keys that must never appear as filter sources.
 *
 * @return list<string>
 */
function dsm_loop_filter_denied_meta_keys(): array {
	$denied = array(
		'_edit_lock',
		'_edit_last',
		'_wp_trash_meta_status',
		'_wp_trash_meta_time',
		'_wp_desired_post_slug',
		'_wp_old_slug',
		'_wp_old_date',
	);

	/**
	 * Filter meta keys excluded from Supreme Loop Filter Custom Field options.
	 *
	 * @param array<int, string> $denied Denied keys.
	 */
	$filtered = apply_filters( 'dsm_loop_filter_denied_meta_keys', $denied );

	if ( ! is_array( $filtered ) ) {
		return $denied;
	}

	$out = array();
	foreach ( $filtered as $key ) {
		if ( is_string( $key ) && '' !== $key ) {
			$out[] = $key;
		}
	}

	return $out;
}

/**
 * Whether a meta key may be offered or queried.
 *
 * @param string $meta_key Raw meta key.
 * @return bool
 */
function dsm_loop_filter_is_allowed_meta_key( string $meta_key ): bool {
	$key = dsm_loop_filter_sanitize_meta_key( $meta_key );
	if ( '' === $key ) {
		return false;
	}

	if ( in_array( $key, dsm_loop_filter_denied_meta_keys(), true ) ) {
		return false;
	}

	if ( 0 === strpos( $key, '_edit_' ) ) {
		return false;
	}

	return true;
}

/**
 * Sanitize a post meta key for Loop Filter storage and queries.
 *
 * @param string $meta_key Raw key.
 * @return string
 */
function dsm_loop_filter_sanitize_meta_key( string $meta_key ): string {
	$key = sanitize_text_field( $meta_key );
	if ( '' === $key || strlen( $key ) > 191 ) {
		return '';
	}

	if ( ! preg_match( '/^[A-Za-z0-9_\-\.]+$/', $key ) ) {
		return '';
	}

	return $key;
}

/**
 * ACF field names registered for posts (empty when ACF is inactive).
 *
 * @return list<string>
 */
function dsm_loop_filter_acf_meta_keys(): array {
	if ( ! function_exists( 'acf_get_field_groups' ) || ! function_exists( 'acf_get_fields' ) ) {
		return array();
	}

	$groups = acf_get_field_groups();
	if ( ! is_array( $groups ) ) {
		return array();
	}

	$out = array();
	foreach ( $groups as $group ) {
		if ( ! is_array( $group ) ) {
			continue;
		}
		$fields = acf_get_fields( $group );
		if ( ! is_array( $fields ) ) {
			continue;
		}
		foreach ( $fields as $field ) {
			if ( ! is_array( $field ) ) {
				continue;
			}
			$name      = isset( $field['name'] ) && is_string( $field['name'] )
				? $field['name']
				: '';
			$sanitized = dsm_loop_filter_sanitize_meta_key( $name );
			if ( '' !== $sanitized && dsm_loop_filter_is_allowed_meta_key( $sanitized ) ) {
				$out[] = $sanitized;
			}
		}
	}

	return array_values( array_unique( $out ) );
}

/**
 * Most-used post meta keys (cached). Does not include denied internals.
 *
 * @return list<string>
 */
function dsm_loop_filter_most_used_meta_keys(): array {
	$cached = get_transient( 'dsm_lf_meta_keys' );
	if ( is_array( $cached ) ) {
		$out = array();
		foreach ( $cached as $key ) {
			if ( is_string( $key ) && dsm_loop_filter_is_allowed_meta_key( $key ) ) {
				$out[] = $key;
			}
		}
		return array_values( array_unique( $out ) );
	}

	global $wpdb;

	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Aggregated catalog; cached via transient.
	$rows = $wpdb->get_col(
		"SELECT meta_key FROM {$wpdb->postmeta} WHERE meta_key NOT LIKE '\\_edit\\_%' GROUP BY meta_key ORDER BY COUNT(*) DESC LIMIT 80"
	);

	$out = array();
	if ( is_array( $rows ) ) {
		foreach ( $rows as $row ) {
			if ( ! is_string( $row ) ) {
				continue;
			}
			$sanitized = dsm_loop_filter_sanitize_meta_key( $row );
			if ( '' !== $sanitized && dsm_loop_filter_is_allowed_meta_key( $sanitized ) ) {
				$out[] = $sanitized;
			}
		}
	}

	set_transient( 'dsm_lf_meta_keys', $out, HOUR_IN_SECONDS );

	return $out;
}

/**
 * Grouped meta-key catalog for the Visual Builder Custom Field picker.
 *
 * @return array{standard: list<array{key: string, label: string}>, nonStandard: list<array{key: string, label: string}>}
 */
function dsm_get_loop_filter_meta_key_options(): array {
	$keys = array_values(
		array_unique(
			array_merge(
				dsm_loop_filter_most_used_meta_keys(),
				dsm_loop_filter_acf_meta_keys()
			)
		)
	);

	sort( $keys, SORT_NATURAL | SORT_FLAG_CASE );

	$standard     = array();
	$non_standard = array();

	foreach ( $keys as $key ) {
		$row = array(
			'key'   => $key,
			'label' => $key,
		);
		if ( 0 === strpos( $key, '_' ) ) {
			$non_standard[] = $row;
		} else {
			$standard[] = $row;
		}
	}

	$catalog = array(
		'standard'    => $standard,
		'nonStandard' => $non_standard,
	);

	/**
	 * Filter localized Custom Field meta key groups for Supreme Loop Filter.
	 *
	 * @param array{standard: list<array{key: string, label: string}>, nonStandard: list<array{key: string, label: string}>} $catalog Groups.
	 */
	$filtered = apply_filters( 'dsm_loop_filter_meta_key_options', $catalog );

	if ( ! is_array( $filtered ) ) {
		return $catalog;
	}

	return array(
		'standard'    => isset( $filtered['standard'] ) && is_array( $filtered['standard'] )
			? $filtered['standard']
			: $standard,
		'nonStandard' => isset( $filtered['nonStandard'] ) && is_array( $filtered['nonStandard'] )
			? $filtered['nonStandard']
			: $non_standard,
	);
}

/**
 * Normalize Custom Field UI (text | checkbox | radio | select).
 *
 * @param string $raw Raw value.
 * @return string
 */
function dsm_loop_filter_normalize_custom_field_ui( string $raw ): string {
	$ui = sanitize_key( $raw );
	if ( in_array( $ui, array( 'text', 'checkbox', 'radio', 'select' ), true ) ) {
		return $ui;
	}

	return 'text';
}

/**
 * ACF choice list for a field name (empty when ACF is inactive or has no choices).
 *
 * @param string $meta_key Sanitized meta key.
 * @return list<array{value: string, label: string}>
 */
function dsm_loop_filter_acf_field_choices( string $meta_key ): array {
	if ( ! function_exists( 'acf_get_field' ) ) {
		return array();
	}

	$field = acf_get_field( $meta_key );
	if ( ! is_array( $field ) || empty( $field['choices'] ) || ! is_array( $field['choices'] ) ) {
		return array();
	}

	$out = array();
	foreach ( $field['choices'] as $value => $label ) {
		$value = sanitize_text_field( (string) $value );
		$label = sanitize_text_field( (string) $label );
		if ( '' === $value ) {
			continue;
		}
		$out[] = array(
			'value' => $value,
			'label' => '' !== $label ? $label : $value,
		);
	}

	return $out;
}

/**
 * Distinct stored values (or ACF choices) for a known custom-field key.
 *
 * @param string             $meta_key   Meta key (sanitized internally).
 * @param array<int, string> $post_types Nested Loop post types (public types when empty).
 * @return list<array{value: string, label: string}>
 */
function dsm_loop_filter_get_meta_value_options( string $meta_key, array $post_types = array() ): array {
	$key = dsm_loop_filter_sanitize_meta_key( $meta_key );
	if ( '' === $key || ! dsm_loop_filter_is_allowed_meta_key( $key ) ) {
		return array();
	}

	$acf_choices = dsm_loop_filter_acf_field_choices( $key );
	if ( ! empty( $acf_choices ) ) {
		/**
		 * Filter Custom Field list options for Supreme Loop Filter.
		 *
		 * @param array<int, array{value: string, label: string}> $acf_choices Options.
		 * @param string                                    $key         Meta key.
		 * @param array<int, string>                              $post_types  Post types.
		 */
		$filtered = apply_filters( 'dsm_loop_filter_meta_value_options', $acf_choices, $key, $post_types );

		return is_array( $filtered ) ? $filtered : $acf_choices;
	}

	$types = array();
	foreach ( $post_types as $post_type ) {
		$post_type = sanitize_key( (string) $post_type );
		if ( '' !== $post_type && post_type_exists( $post_type ) ) {
			$types[] = $post_type;
		}
	}
	$types = array_values( array_unique( $types ) );
	if ( empty( $types ) ) {
		$public = get_post_types( array( 'public' => true ), 'names' );
		$types  = is_array( $public ) ? array_values( $public ) : array( 'post' );
	}

	$cache_key = 'dsm_lf_mv_' . md5( $key . '|' . implode( ',', $types ) );
	$cached    = get_transient( $cache_key );
	if ( is_array( $cached ) ) {
		return $cached;
	}

	global $wpdb;

	$placeholders = implode( ', ', array_fill( 0, count( $types ), '%s' ) );
	$params       = array_merge( array( $key ), $types );

	// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- IN placeholders from count; $sql is $wpdb->prepare() output; cached via transient.
	$sql  = $wpdb->prepare(
		"SELECT DISTINCT pm.meta_value FROM {$wpdb->postmeta} pm
		INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
		WHERE pm.meta_key = %s
		AND p.post_status = 'publish'
		AND p.post_type IN ({$placeholders})
		AND pm.meta_value != ''
		LIMIT 150",
		...$params
	);
	$rows = $wpdb->get_col( $sql );
	// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

	$out  = array();
	$seen = array();
	if ( is_array( $rows ) ) {
		foreach ( $rows as $row ) {
			if ( ! is_string( $row ) && ! is_numeric( $row ) ) {
				continue;
			}
			$raw = (string) $row;
			if ( is_serialized( $raw ) ) {
				continue;
			}
			$value = sanitize_text_field( $raw );
			if ( '' === $value || isset( $seen[ $value ] ) ) {
				continue;
			}
			$seen[ $value ] = true;
			$out[]          = array(
				'value' => $value,
				'label' => $value,
			);
			if ( count( $out ) >= 80 ) {
				break;
			}
		}
	}

	usort(
		$out,
		static function ( $a, $b ) {
			return strnatcasecmp( (string) $a['label'], (string) $b['label'] );
		}
	);

	set_transient( $cache_key, $out, 10 * MINUTE_IN_SECONDS );

	/**
	 * Filter Custom Field list options for Supreme Loop Filter.
	 *
	 * @param array<int, array{value: string, label: string}> $out        Options.
	 * @param string                                    $key        Meta key.
	 * @param array<int, string>                              $post_types Post types.
	 */
	$filtered = apply_filters( 'dsm_loop_filter_meta_value_options', $out, $key, $types );

	return is_array( $filtered ) ? $filtered : $out;
}
