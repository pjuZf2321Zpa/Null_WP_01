<?php
/**
 * A utility method to provide all the available post types in the site.
 *
 * @package DiviSupreme
 */

if ( ! function_exists( 'dsm_get_post_type_taxonomies' ) ) {
	require_once __DIR__ . '/get-post-type-taxonomies.php';
}

/**
 * Dsm get post types.
 */
function dsm_get_post_types() {
	if ( ! function_exists( 'et_builder_get_blocklisted_post_types' ) ) {
		return;
	}

	$blocklist = et_builder_get_blocklisted_post_types();
	$allowlist = et_builder_get_third_party_post_types();

	$blocklist = array_merge(
		$blocklist,
		array(
			'et_pb_layout',
			'layout',
			'attachment',
		)
	);

	$blocklist = apply_filters( 'et_builder_post_type_options_blocklist', $blocklist );

	$raw_post_types = get_post_types(
		array(
			'show_ui' => true,
		),
		'objects'
	);

	$post_types = array();

	foreach ( $raw_post_types as $post_type ) {
		$is_allowlisted = in_array( $post_type->name, $allowlist, true );
		$is_blocklisted = in_array( $post_type->name, $blocklist, true );
		$is_public      = et_builder_is_post_type_public( $post_type->name );

		if ( ! $is_allowlisted && ( $is_blocklisted || ! $is_public ) ) {
			continue;
		}

		$post_types[] = $post_type;
	}

	usort(
		$post_types,
		static function ( $a, $b ) {
			$priority = static function ( $name ) {
				if ( 'page' === $name ) {
					return 0;
				}
				if ( 'post' === $name ) {
					return 1;
				}

				return 100;
			};

			$diff = $priority( $a->name ) <=> $priority( $b->name );
			if ( 0 !== $diff ) {
				return $diff;
			}

			return strcasecmp( $a->label, $b->label );
		}
	);

	// Only providing useful info.
	return array_map(
		static function ( $current_post_type ) {
			$label = $current_post_type->label;
			if ( 'post' === $current_post_type->name ) {
				$label = __( 'Blog', 'dsm-supreme-modules-pro-for-divi' );
			}

			return array(
				'label'        => $label,
				'name'         => $current_post_type->name,
				'taxonomies'   => function_exists( 'dsm_get_post_type_taxonomies' )
					? dsm_get_post_type_taxonomies( $current_post_type->name )
					: array(),
				'rest_base'    => dsm_get_post_type_rest_collection_path( $current_post_type ),
				'show_in_rest' => (bool) $current_post_type->show_in_rest,
			);
		},
		$post_types
	);
}

/**
 * REST API collection path segment for a post type (e.g. `posts`, `pages`, `my_cpt`).
 *
 * @param \WP_Post_Type $post_type Post type object.
 * @return string
 */
function dsm_get_post_type_rest_collection_path( $post_type ) {
	$base = $post_type->rest_base;
	if ( is_string( $base ) && '' !== $base ) {
		return $base;
	}

	return $post_type->name;
}

/**
 * Map post type slug => REST collection path for types that expose the REST API.
 * Used by the Visual Builder to call `/wp/v2/{path}` (see `usePosts`).
 *
 * @return array<string, string>
 */
function dsm_get_post_type_rest_base_map() {
	$map = array();

	foreach ( get_post_types( array(), 'objects' ) as $post_type ) {
		if ( ! $post_type instanceof \WP_Post_Type || ! $post_type->show_in_rest ) {
			continue;
		}
		$map[ $post_type->name ] = dsm_get_post_type_rest_collection_path( $post_type );
	}

	return $map;
}
