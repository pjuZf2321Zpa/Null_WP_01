<?php
/**
 * Client Handoff — writes Divi Role Editor (`et_pb_role_settings`).
 *
 * Does not invent a parallel capability matrix. Apply snapshots the whole
 * Role Editor option, overlays one role (a dedicated client role, or Editor),
 * and never writes Administrator. A custom role is a WordPress role cloned
 * from Editor so it keeps `edit_posts` and appears in Divi Role Editor.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Extensions;

use DiviSupreme\Core\Assets;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Apply / Exit Handoff against Divi's Role Editor option.
 */
class ClientHandoff {

	/**
	 * Dashboard section id.
	 */
	public const SECTION_ID = 'dsm_handoff';

	/**
	 * Extensions toggle field under `dsm_general`.
	 */
	public const EXTENSION_FIELD = 'dsm_use_client_handoff';

	/**
	 * Persisted Handoff state (snapshot + applied flag).
	 */
	public const STATE_OPTION = 'dsm_handoff_state';

	/**
	 * Divi Role Editor option.
	 */
	public const ROLE_SETTINGS_OPTION = 'et_pb_role_settings';

	/**
	 * WordPress role used when custom-role mode is off (v1).
	 */
	public const TARGET_ROLE = 'editor';

	/**
	 * Slug prefix for Handoff-created WordPress roles.
	 */
	private const CUSTOM_ROLE_PREFIX = 'dsm_';

	/**
	 * Roles Handoff must never create or overlay, besides the explicit Editor fallback.
	 *
	 * @var list<string>
	 */
	private const BLOCKED_TARGET_ROLES = array(
		'administrator',
		'author',
		'contributor',
		'subscriber',
	);

	/**
	 * Builder-bar tools the Handoff checklist can hide.
	 *
	 * A missing state list hides every key. CamelCase is required; `sanitize_key()` would lowercase them.
	 *
	 * @var list<string>
	 */
	private const BAR_TOOL_KEYS = array(
		'layers',
		'inspector',
		'aiAgent',
		'wireframeView',
		'actionIconsOnHover',
		'parentActionIconsOnHover',
		'xRay',
		'workspace',
		'help',
		'announcements',
	);

	/**
	 * Supreme sidebar buttons, in left-bar order.
	 *
	 * Each callback is the extension’s own settings flag. The checklist shows a row only while that flag is on.
	 *
	 * @var array<string, string>
	 */
	private const EXTENSION_BAR_TOOLS = array(
		'dsmPopup'        => 'dsm_is_supreme_popup_extension_enabled',
		'dsmCustomCursor' => 'dsm_is_custom_cursor_extension_enabled',
		'dsmPreloader'    => 'dsm_is_preloader_extension_enabled',
		'dsmDarkMode'     => 'dsm_is_dark_mode_extension_enabled',
		'dsmPageTour'     => 'dsm_is_page_tour_extension_enabled',
	);

	/**
	 * AJAX action.
	 */
	public const AJAX_ACTION = 'dsm_client_handoff';

	/**
	 * AJAX nonce action.
	 */
	public const AJAX_NONCE = 'dsm_client_handoff';

	/**
	 * Role Editor keys that must stay on for content-only VB editing.
	 *
	 * @var list<string>
	 */
	private const CAPS_ON = array(
		'use_visual_builder',
		'edit_module',
		'general_settings',
		'edit_content',
		'page_options',
	);

	/**
	 * Role Editor keys that must be off (structure, chrome, site-wide).
	 *
	 * @var list<string>
	 */
	private const CAPS_OFF = array(
		'add_module',
		'move_module',
		'disable_module',
		'lock_module',
		'divi_builder_control',
		'load_layout',
		'theme_builder',
		'theme_options',
		'theme_customizer',
		'divi_library',
		'save_library',
		'add_library',
		'edit_global_library',
		'portability',
		'divi_ai',
		'variables_manager',
		'ab_testing',
		'support_center',
		'et_support_center',
		'et_support_center_system',
		'et_support_center_remote_access',
		'et_support_center_documentation',
		'et_support_center_safe_mode',
		'et_support_center_logs',
		'et_onboarding_quick_sites',
		'custom_fonts_management',
		'read_dynamic_content_custom_fields',
		'advanced_settings',
		'custom_css_settings',
		'edit_colors',
		'edit_fonts',
		'edit_buttons',
		'edit_layout',
		'edit_borders',
		'edit_configuration',
	);

	/**
	 * Divi Module Use keys disabled by default (raw HTML/JS).
	 *
	 * @var list<string>
	 */
	private const DIVI_MODULE_USE_OFF = array(
		'et_pb_code',
		'et_pb_fullwidth_code',
	);

	/**
	 * Register AJAX.
	 */
	public function __construct() {
		add_action( 'wp_ajax_' . self::AJAX_ACTION, array( $this, 'handle_ajax' ) );
		add_action(
			'divi_visual_builder_assets_before_enqueue_scripts',
			array( $this, 'enqueue_vb_content_group_lock' ),
			1
		);
		add_filter(
			'divi_visual_builder_preferences_data',
			array( $this, 'filter_vb_preferences_data' )
		);
		ClientHandoffAccess::register();
	}

	/**
	 * Register the official Divi group/attribute filters before module-library.
	 *
	 * Role Editor cannot hide Elements / Background / Loop. ET’s documented
	 * registration-time hooks must run in the VB app window before core
	 * modules register (`divi.moduleLibrary.moduleSettings.groups`).
	 */
	public function enqueue_vb_content_group_lock(): void {
		if ( ! function_exists( 'et_builder_d5_enabled' ) || ! et_builder_d5_enabled() ) {
			return;
		}

		if ( ! function_exists( 'et_core_is_fb_enabled' ) || ! et_core_is_fb_enabled() ) {
			return;
		}

		$lock    = self::should_lock_editor_content_groups();
		$lock_js = $lock ? 'true' : 'false';
		$path    = dirname( __DIR__, 2 ) . '/packages/extensions/client-handoff/content-groups-early.js';
		$src     = defined( 'DSM_DIR_URL' )
			? DSM_DIR_URL . 'packages/extensions/client-handoff/content-groups-early.js'
			: '';

		if ( '' === $src || ! is_readable( $path ) ) {
			return;
		}

		$version = defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';

		if ( '' !== $path && is_readable( $path ) ) {
			$version .= '-' . (string) filemtime( $path );
		}

		$flag_js = 'window.__dsmClientHandoffLockContentGroups=' . $lock_js . ';' . self::hidden_bar_tools_inline_assignment();

		wp_register_script( 'dsm-client-handoff-content-groups-flag', false, array(), $version, false );
		wp_add_inline_script( 'dsm-client-handoff-content-groups-flag', $flag_js, 'after' );
		wp_enqueue_script( 'dsm-client-handoff-content-groups-flag' );

		if ( wp_script_is( 'divi-vendor-wp-hooks', 'registered' ) ) {
			wp_add_inline_script( 'divi-vendor-wp-hooks', $flag_js, 'after' );
		}

		if ( class_exists( \ET\Builder\VisualBuilder\Assets\PackageBuildManager::class ) ) {
			\ET\Builder\VisualBuilder\Assets\PackageBuildManager::register_package_build(
				array(
					'name'    => 'dsm-client-handoff-content-groups',
					'version' => $version,
					'script'  => array(
						'src'                => $src,
						'deps'               => array(
							'dsm-client-handoff-content-groups-flag',
							'lodash',
							'divi-vendor-wp-hooks',
						),
						'data_app_window'    => array(
							'lock' => $lock ? 'on' : 'off',
						),
						'enqueue_top_window' => false,
						'enqueue_app_window' => true,
						'args'               => array(
							'in_footer' => false,
						),
					),
				)
			);
			return;
		}

		wp_enqueue_script(
			'dsm-client-handoff-content-groups',
			$src,
			array(
				'dsm-client-handoff-content-groups-flag',
				'lodash',
			),
			$version,
			false
		);
	}

	/**
	 * Hide structure builder-bar tools when Handoff locks Editor.
	 *
	 * Role Editor has no keys for Layers, Inspector, Wireframe, or hover
	 * action icons. Divi’s `divi_visual_builder_preferences_data` filter
	 * is the preferences payload — this does not persist a second ACL or
	 * write the user’s saved prefs.
	 *
	 * @param array<string, mixed> $preferences Preferences payload.
	 * @return array<string, mixed>
	 */
	public function filter_vb_preferences_data( array $preferences ): array {
		if ( ! self::should_lock_editor_content_groups() ) {
			return $preferences;
		}

		$hidden = array_fill_keys( self::get_effective_hidden_bar_tools(), true );
		$icons  = isset( $preferences['builderBarIcons'] ) && is_array( $preferences['builderBarIcons'] )
			? $preferences['builderBarIcons']
			: array();

		foreach ( self::BAR_TOOL_KEYS as $icon_key ) {
			if ( isset( $hidden[ $icon_key ] ) ) {
				$icons[ $icon_key ] = false;
			}
		}

		$preferences['builderBarIcons'] = $icons;

		if ( isset( $hidden['wireframeView'] ) ) {
			$preferences['toolbarWireframe'] = false;

			if ( isset( $preferences['viewMode'] ) && 'wireframe' === $preferences['viewMode'] ) {
				$preferences['viewMode'] = 'desktop';
			}
		}

		$touch_layers = isset( $hidden['actionIconsOnHover'] ) || isset( $hidden['parentActionIconsOnHover'] ) || isset( $hidden['xRay'] );

		if ( $touch_layers ) {
			$layers = isset( $preferences['appInteractionLayers'] ) && is_array( $preferences['appInteractionLayers'] )
				? $preferences['appInteractionLayers']
				: array();

			if ( isset( $hidden['actionIconsOnHover'] ) ) {
				$layers['actionOnHover'] = false;
			}

			if ( isset( $hidden['parentActionIconsOnHover'] ) ) {
				$layers['parentActionOnHover'] = false;
			}

			if ( isset( $hidden['xRay'] ) ) {
				$layers['xRay'] = false;
			}

			$preferences['appInteractionLayers'] = $layers;
		}

		return $preferences;
	}

	/**
	 * Whether Handoff overlay is currently applied.
	 *
	 * @return bool
	 */
	public static function is_applied(): bool {
		$state = self::get_state();

		return ! empty( $state['applied'] );
	}

	/**
	 * Whether the Visual Builder should omit Elements, Background, Loop,
	 * Meta, Order, presets, and structure builder-bar tools.
	 *
	 * Role Editor has no keys for those Content-tab groups, presets, Layers,
	 * Inspector, Wireframe, or hover actions. Apply still writes Design /
	 * Settings Types off; this flag gates Divi’s official JS group /
	 * right-click filters and `divi_visual_builder_preferences_data` for
	 * Editor only. Administrator is never locked. Exit and extension-off
	 * clear `applied`, so the filters no-op.
	 *
	 * @return bool
	 */
	public static function should_lock_editor_content_groups(): bool {
		if ( ! function_exists( 'dsm_is_client_handoff_extension_enabled' ) || ! dsm_is_client_handoff_extension_enabled() ) {
			return false;
		}

		if ( ! self::is_applied() ) {
			return false;
		}

		if ( ! is_user_logged_in() ) {
			return false;
		}

		$user = wp_get_current_user();

		if ( in_array( 'administrator', (array) $user->roles, true ) ) {
			return false;
		}

		if ( user_can( $user, 'manage_options' ) ) {
			return false;
		}

		return in_array( self::get_state()['target_role'], (array) $user->roles, true );
	}

	/**
	 * Restore the Role Editor snapshot when the Extensions toggle is turned off.
	 *
	 * @param array<string, mixed> $merged_general Saved `dsm_general` values.
	 */
	public static function maybe_restore_on_extension_disable( array $merged_general ): void {
		$previous = get_option( 'dsm_general', array() );
		$was_on   = is_array( $previous ) && isset( $previous[ self::EXTENSION_FIELD ] ) && 'on' === $previous[ self::EXTENSION_FIELD ];
		$now_on   = isset( $merged_general[ self::EXTENSION_FIELD ] ) && 'on' === $merged_general[ self::EXTENSION_FIELD ];

		if ( $was_on && ! $now_on && self::is_applied() ) {
			self::exit_handoff();
		}
	}

	/**
	 * Localized payload for the settings dashboard.
	 *
	 * @return array<string, mixed>
	 */
	public static function get_localize_payload(): array {
		$status = self::get_status();
		$state  = self::get_state();

		return array(
			'nonce'             => wp_create_nonce( self::AJAX_NONCE ),
			'action'            => self::AJAX_ACTION,
			'targetRole'        => $state['target_role'],
			'targetRoleLabel'   => self::get_target_role_label(),
			'defaultRoleName'   => __( 'Client Editor', 'dsm-supreme-modules-pro-for-divi' ),
			'roleDisplayName'   => '' !== $state['target_role_name']
				? $state['target_role_name']
				: __( 'Client Editor', 'dsm-supreme-modules-pro-for-divi' ),
			'useCustomRole'     => self::ui_prefers_custom_role( $state ),
			'roleEditorUrl'     => self::get_role_editor_url(),
			'usersUrl'          => self::get_users_screen_url( $state ),
			'assignableUsers'   => self::get_assignable_users( $state['target_role'] ),
			'status'            => $status,
			'hiddenBarTools'    => self::get_effective_hidden_bar_tools(),
			'extensionBarTools' => self::get_enabled_extension_bar_tools(),
			'strings'           => self::get_strings(),
			'pages'             => ClientHandoffAccess::pages_payload(),
			'adminTrim'         => ClientHandoffAccess::admin_payload(),
			'previewUsers'      => ClientHandoffAccess::preview_users(),
			'userSwitching'     => ClientHandoffAccess::user_switching_plugin_active(),
			'settingsUrl'       => self::get_settings_url(),
			'icons'             => array(
				'status' => Assets::getAssetPath( 'dashboard/rows/person.svg' ),
			),
		);
	}

	/**
	 * AJAX: apply, exit, update_snapshot.
	 */
	public function handle_ajax(): void {
		if ( ! check_ajax_referer( self::AJAX_NONCE, 'nonce', false ) ) {
			wp_send_json_error(
				array(
					'message' => __( 'Security check failed.', 'dsm-supreme-modules-pro-for-divi' ),
				)
			);
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error(
				array(
					'message' => __( 'You do not have permission to change Role Editor settings.', 'dsm-supreme-modules-pro-for-divi' ),
				)
			);
		}

		if ( ! function_exists( 'dsm_is_client_handoff_extension_enabled' ) || ! dsm_is_client_handoff_extension_enabled() ) {
			wp_send_json_error(
				array(
					'message' => __( 'Turn on Client Handoff under Extensions first.', 'dsm-supreme-modules-pro-for-divi' ),
				)
			);
		}

		$op = isset( $_POST['op'] ) ? sanitize_key( wp_unslash( (string) $_POST['op'] ) ) : '';

		if ( 'apply' === $op ) {
			$use_custom = self::request_flag( 'use_custom_role' );
			$move       = self::request_flag( 'move_from_editor' );
			$role_name  = self::request_text( 'role_display_name' );
			$result     = self::apply_from_request( $use_custom, $role_name, $move );

			if ( is_wp_error( $result ) ) {
				wp_send_json_error(
					array(
						'message' => $result->get_error_message(),
					)
				);
			}

			wp_send_json_success( self::ajax_success_payload( $result['message'], $result ) );
		}

		if ( 'exit' === $op ) {
			$result = self::exit_handoff();

			if ( is_wp_error( $result ) ) {
				wp_send_json_error(
					array(
						'message' => $result->get_error_message(),
					)
				);
			}

			wp_send_json_success( self::ajax_success_payload( $result['message'] ) );
		}

		if ( 'update_snapshot' === $op ) {
			$result = self::update_snapshot_from_current();

			if ( is_wp_error( $result ) ) {
				wp_send_json_error(
					array(
						'message' => $result->get_error_message(),
					)
				);
			}

			wp_send_json_success( self::ajax_success_payload( $result['message'] ) );
		}

		if ( 'save_bar_tools' === $op ) {
			$posted = self::hidden_bar_tools_from_request();
			$result = self::save_hidden_bar_tools( is_array( $posted ) ? $posted : array() );

			wp_send_json_success( self::ajax_success_payload( $result['message'] ) );
		}

		if ( 'assign_users' === $op ) {
			$result = self::assign_users_to_target_role( self::sanitize_user_ids_from_request() );

			if ( is_wp_error( $result ) ) {
				wp_send_json_error(
					array(
						'message' => $result->get_error_message(),
					)
				);
			}

			wp_send_json_success( self::ajax_success_payload( $result['message'], $result ) );
		}

		$access = ClientHandoffAccess::handle_ajax_op( $op );

		if ( null !== $access ) {
			if ( is_wp_error( $access ) ) {
				wp_send_json_error(
					array(
						'message' => $access->get_error_message(),
					)
				);
			}

			$message = isset( $access['message'] ) ? (string) $access['message'] : '';
			unset( $access['message'] );
			wp_send_json_success( array_merge( self::ajax_success_payload( $message ), $access ) );
		}

		wp_send_json_error(
			array(
				'message' => __( 'Unknown Handoff action.', 'dsm-supreme-modules-pro-for-divi' ),
			)
		);
	}

	/**
	 * Snapshot Role Editor (once) and overlay one role’s caps.
	 *
	 * Custom-role mode never writes the `editor` map. Administrator is never written.
	 *
	 * @param bool   $replace_snapshot  When true, replace the stored snapshot first.
	 * @param string $target_role       Role slug to overlay. Empty uses Editor.
	 * @param bool   $use_custom_role   Whether this Apply is custom-role mode.
	 * @param string $role_display_name Display name stored for the custom role.
	 * @return array{message: string, promptAssign?: bool, roleCreated?: bool, roleReused?: bool}|\WP_Error
	 */
	public static function apply_handoff( bool $replace_snapshot = false, string $target_role = '', bool $use_custom_role = false, string $role_display_name = '' ) {
		$target_role = sanitize_key( $target_role );

		if ( '' === $target_role ) {
			$target_role     = self::TARGET_ROLE;
			$use_custom_role = false;
		}

		if ( self::is_blocked_target_role( $target_role ) ) {
			return new \WP_Error(
				'dsm_handoff_admin_blocked',
				__( 'Client Handoff never writes the Administrator role.', 'dsm-supreme-modules-pro-for-divi' )
			);
		}

		if ( $use_custom_role && ( self::TARGET_ROLE === $target_role || ! str_starts_with( $target_role, self::CUSTOM_ROLE_PREFIX ) ) ) {
			return new \WP_Error(
				'dsm_handoff_custom_role_required',
				__( 'Custom-role Handoff cannot write the default Editor role.', 'dsm-supreme-modules-pro-for-divi' )
			);
		}

		if ( $use_custom_role && ! get_role( $target_role ) ) {
			return new \WP_Error(
				'dsm_handoff_role_missing',
				__( 'The client role does not exist yet. Apply again to create it.', 'dsm-supreme-modules-pro-for-divi' )
			);
		}

		$current = self::get_role_settings();
		$state   = self::get_state();

		if ( $replace_snapshot || empty( $state['has_snapshot'] ) ) {
			$state['snapshot']     = $current;
			$state['has_snapshot'] = true;
		}

		$next = $current;
		$seed = array();

		if ( isset( $next[ $target_role ] ) && is_array( $next[ $target_role ] ) && array() !== $next[ $target_role ] ) {
			$seed = $next[ $target_role ];
		} elseif ( $use_custom_role && isset( $next[ self::TARGET_ROLE ] ) && is_array( $next[ self::TARGET_ROLE ] ) ) {
			$seed = $next[ self::TARGET_ROLE ];
		}

		$seed = self::sanitize_role_caps( $seed );

		if ( isset( $state['snapshot'][ $target_role ] ) && is_array( $state['snapshot'][ $target_role ] ) ) {
			$seed = self::restore_supreme_module_use_from_snapshot(
				$seed,
				self::sanitize_role_caps( $state['snapshot'][ $target_role ] )
			);
		}

		$next[ $target_role ] = self::overlay_editor_caps( $seed );

		$written = self::write_role_settings( $next );

		if ( is_wp_error( $written ) ) {
			return $written;
		}

		$state['applied']         = true;
		$state['target_role']     = $target_role;
		$state['use_custom_role'] = $use_custom_role;
		$state['has_custom_flag'] = true;
		$state['applied_at']      = time();
		$state['applied_hash']    = self::hash_role_settings( $next );
		unset( $state['disabled_modules'] );

		if ( '' !== $role_display_name ) {
			$state['target_role_name'] = $role_display_name;
		}

		$posted_bar_tools = self::hidden_bar_tools_from_request();

		if ( is_array( $posted_bar_tools ) ) {
			$state['hidden_bar_tools'] = $posted_bar_tools;
		}

		self::save_state( $state );
		ClientHandoffAccess::sync_trimmed_caps();

		/**
		 * Fires after Client Handoff writes one role’s Role Editor caps.
		 *
		 * @param array<string, mixed> $next Written `et_pb_role_settings`.
		 */
		do_action( 'dsm_client_handoff_applied', $next );

		$label = self::get_target_role_label();

		if ( $use_custom_role ) {
			$message = sprintf(
				/* translators: %s: WordPress role display name. */
				__( 'Handoff applied. %s now uses the content-only Role Editor profile. The default Editor role was not changed.', 'dsm-supreme-modules-pro-for-divi' ),
				$label
			);
		} else {
			$message = __( 'Handoff applied. Editor now uses the content-only Role Editor profile.', 'dsm-supreme-modules-pro-for-divi' );
		}

		return array(
			'message' => $message,
		);
	}

	/**
	 * Restore the snapshotted `et_pb_role_settings` option in full.
	 *
	 * @return array{message: string}|\WP_Error
	 */
	public static function exit_handoff() {
		ClientHandoffAccess::restore_trimmed_caps();
		$state = self::get_state();

		if ( empty( $state['has_snapshot'] ) ) {
			return new \WP_Error(
				'dsm_handoff_no_snapshot',
				__( 'No restore point was found. Nothing was restored.', 'dsm-supreme-modules-pro-for-divi' )
			);
		}

		$snapshot = isset( $state['snapshot'] ) && is_array( $state['snapshot'] )
			? self::sanitize_role_settings( $state['snapshot'] )
			: array();

		$written = self::write_role_settings( $snapshot );

		if ( is_wp_error( $written ) ) {
			return $written;
		}

		$kept_role   = $state['target_role'];
		$kept_custom = ! empty( $state['use_custom_role'] );
		$kept_name   = $state['target_role_name'];
		$kept_flag   = ! empty( $state['has_custom_flag'] );
		$kept_bar    = $state['hidden_bar_tools'];

		$state['applied']          = false;
		$state['applied_at']       = 0;
		$state['applied_hash']     = '';
		$state['has_snapshot']     = false;
		$state['snapshot']         = array();
		$state['target_role']      = $kept_role;
		$state['use_custom_role']  = $kept_custom;
		$state['target_role_name'] = $kept_name;
		$state['has_custom_flag']  = $kept_flag;
		$state['hidden_bar_tools'] = $kept_bar;

		self::save_state( $state );
		$cleanup = ClientHandoffAccess::delete_generated_preview_users();

		/**
		 * Fires after Client Handoff restores the Role Editor snapshot.
		 *
		 * @param array<string, array<string, string>> $snapshot Restored option.
		 */
		do_action( 'dsm_client_handoff_exited', $snapshot );

		$message = __( 'Handoff exited. The saved restore point was restored.', 'dsm-supreme-modules-pro-for-divi' );

		if ( $cleanup['deleted'] > 0 ) {
			$message .= ' ' . __( 'The generated preview user was removed.', 'dsm-supreme-modules-pro-for-divi' );
		} elseif ( $cleanup['kept'] > 0 ) {
			$message .= ' ' . __( 'A generated preview user was kept because they own content.', 'dsm-supreme-modules-pro-for-divi' );
		}

		return array(
			'message' => $message,
		);
	}

	/**
	 * Replace the restore snapshot with the current Role Editor option.
	 *
	 * Does not change the Applied overlay. Use after the designer saves Role
	 * Editor while Handoff is on and wants Exit to keep those edits.
	 *
	 * @return array{message: string}|\WP_Error
	 */
	public static function update_snapshot_from_current() {
		$current = self::get_role_settings();
		$state   = self::get_state();

		$state['snapshot']     = $current;
		$state['has_snapshot'] = true;
		$state['applied_hash'] = self::is_applied()
			? self::hash_role_settings( $current )
			: (string) ( $state['applied_hash'] ?? '' );

		self::save_state( $state );

		return array(
			'message' => __( 'Restore point saved from the current Role Editor settings.', 'dsm-supreme-modules-pro-for-divi' ),
		);
	}

	/**
	 * Status for the dashboard panel.
	 *
	 * @return array<string, mixed>
	 */
	public static function get_status(): array {
		$state    = self::get_state();
		$applied  = ! empty( $state['applied'] );
		$current  = self::get_role_settings();
		$expected = isset( $state['applied_hash'] ) ? (string) $state['applied_hash'] : '';
		$dirty    = $applied && '' !== $expected && self::hash_role_settings( $current ) !== $expected;
		$role     = self::get_target_role_label();

		$applied_at = isset( $state['applied_at'] ) ? (int) $state['applied_at'] : 0;

		if ( $applied && $dirty ) {
			$label = ! empty( $state['legacy_editor_apply'] )
				? __( 'Applied to Editor', 'dsm-supreme-modules-pro-for-divi' )
				: __( 'Applied', 'dsm-supreme-modules-pro-for-divi' );
			$tone  = 'warning';
			$desc  = __( 'Handoff is on, but Role Editor no longer matches the last Apply. Exit will restore the saved restore point and discard Role Editor edits made since then. Save restore point first if you want to keep those edits.', 'dsm-supreme-modules-pro-for-divi' );
		} elseif ( $applied && ! empty( $state['legacy_editor_apply'] ) ) {
			$label = __( 'Applied to Editor', 'dsm-supreme-modules-pro-for-divi' );
			$tone  = 'warning';
			$desc  = __( 'Handoff is applied to the default Editor role from an earlier version. Exit restores Editor. Move to a custom role restores Editor first, then writes the content-only profile only on the new role.', 'dsm-supreme-modules-pro-for-divi' );
		} elseif ( $applied ) {
			$label = __( 'Applied', 'dsm-supreme-modules-pro-for-divi' );
			$tone  = 'success';
			if ( ! empty( $state['use_custom_role'] ) ) {
				$desc = sprintf(
					/* translators: %s: WordPress role display name. */
					__( '%s uses the content-only Role Editor profile: text, images, and links. The default Editor role is unchanged. Elements, Background, Loop, Meta, Order, presets, Layers, Inspector, Wireframe, and hover action icons stay off for that role. Exit restores the saved restore point and leaves the WordPress role in place.', 'dsm-supreme-modules-pro-for-divi' ),
					$role
				);
			} else {
				$desc = __( 'Editor uses the content-only Role Editor profile: text, images, and links. Elements, Background, Loop, Meta, Order, Element Presets, option-group presets, right-click preset / Inspect / Go To Layer actions, Layers, Inspector, Wireframe, and hover action icons stay off. Exit restores the restore point taken at first Apply (or the last Save restore point).', 'dsm-supreme-modules-pro-for-divi' );
			}
		} else {
			$label = __( 'Ready', 'dsm-supreme-modules-pro-for-divi' );
			$tone  = 'neutral';
			$desc  = __( 'Handoff is not applied. Apply can create a dedicated client role (default) or use Editor. Administrator is never changed.', 'dsm-supreme-modules-pro-for-divi' );
		}

		return array(
			'applied'           => $applied,
			'dirty'             => $dirty,
			'hasSnapshot'       => ! empty( $state['has_snapshot'] ),
			'tone'              => $tone,
			'label'             => $label,
			'description'       => $desc,
			'appliedAt'         => $applied_at,
			'appliedAtDisplay'  => $applied_at > 0
				? wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $applied_at )
				: '',
			'targetRole'        => $state['target_role'],
			'targetRoleLabel'   => $role,
			'useCustomRole'     => self::ui_prefers_custom_role( $state ),
			'legacyEditorApply' => ! empty( $state['legacy_editor_apply'] ),
			'roleExists'        => self::custom_role_exists( $state ),
		);
	}

	/**
	 * Overlay Handoff caps onto an Editor Role Editor map.
	 *
	 * @param array<string, string> $editor Existing Editor caps.
	 * @return array<string, string>
	 */
	private static function overlay_editor_caps( array $editor ): array {
		$on  = apply_filters( 'dsm_client_handoff_caps_on', self::CAPS_ON );
		$off = apply_filters( 'dsm_client_handoff_caps_off', self::CAPS_OFF );

		if ( ! is_array( $on ) ) {
			$on = self::CAPS_ON;
		}

		if ( ! is_array( $off ) ) {
			$off = self::CAPS_OFF;
		}

		foreach ( $on as $cap ) {
			if ( is_string( $cap ) && '' !== $cap ) {
				$editor[ sanitize_key( $cap ) ] = 'on';
			}
		}

		foreach ( $off as $cap ) {
			if ( is_string( $cap ) && '' !== $cap ) {
				$editor[ sanitize_key( $cap ) ] = 'off';
			}
		}

		foreach ( $editor as $cap => $value ) {
			if ( is_string( $cap ) && str_ends_with( $cap, '_portability' ) ) {
				$editor[ $cap ] = 'off';
			}
		}

		$divi_off = apply_filters( 'dsm_client_handoff_divi_module_use_off', self::DIVI_MODULE_USE_OFF );

		if ( ! is_array( $divi_off ) ) {
			$divi_off = self::DIVI_MODULE_USE_OFF;
		}

		foreach ( $divi_off as $slug ) {
			if ( is_string( $slug ) && '' !== $slug ) {
				$editor[ sanitize_key( $slug ) ] = 'off';
			}
		}

		return $editor;
	}

	/**
	 * Copy Supreme Module Use for this role from the pre-overlay snapshot.
	 *
	 * A key stored on the snapshot is copied, including off. A key the snapshot
	 * does not have is removed so a previous module checklist cannot leave it off.
	 * Missing keys are not set to on.
	 *
	 * @param array<string, string> $editor         Role caps about to be overlaid.
	 * @param array<string, string> $snapshot_role  Snapshot caps for the same role.
	 * @return array<string, string>
	 */
	private static function restore_supreme_module_use_from_snapshot( array $editor, array $snapshot_role ): array {
		foreach ( self::get_supreme_role_editor_keys() as $slug ) {
			if ( array_key_exists( $slug, $snapshot_role ) ) {
				$editor[ $slug ] = ( 'off' === $snapshot_role[ $slug ] ) ? 'off' : 'on';
				continue;
			}

			unset( $editor[ $slug ] );
		}

		return $editor;
	}

	/**
	 * Persist Role Editor option using Divi's save side-effects.
	 *
	 * Cited path: `et_pb_save_role_settings()` in Divi `includes/builder/core.php`.
	 *
	 * @param array<string, array<string, string>> $settings Full option.
	 * @return true|\WP_Error
	 */
	private static function write_role_settings( array $settings ) {
		$settings = self::sanitize_role_settings( $settings );

		update_option( self::ROLE_SETTINGS_OPTION, $settings );
		self::flush_divi_role_caches();

		return true;
	}

	/**
	 * Current Role Editor option (empty array if never saved).
	 *
	 * @return array<string, array<string, string>>
	 */
	private static function get_role_settings(): array {
		if ( function_exists( 'et_pb_get_role_settings' ) ) {
			$saved = et_pb_get_role_settings();
		} else {
			$saved = get_option( self::ROLE_SETTINGS_OPTION, array() );
		}

		if ( ! is_array( $saved ) ) {
			return array();
		}

		return self::sanitize_role_settings( $saved );
	}

	/**
	 * Restrict stored Role Editor values to role → cap → on|off.
	 *
	 * @param array<mixed> $settings Raw option.
	 * @return array<string, array<string, string>>
	 */
	private static function sanitize_role_settings( array $settings ): array {
		$out = array();

		foreach ( $settings as $role => $caps ) {
			if ( ! is_string( $role ) || '' === $role || ! is_array( $caps ) ) {
				continue;
			}

			$role_key = sanitize_key( $role );

			if ( '' === $role_key ) {
				continue;
			}

			$out[ $role_key ] = self::sanitize_role_caps( $caps );
		}

		return $out;
	}

	/**
	 * Restrict a role map to sanitized keys with on|off values.
	 *
	 * @param array<mixed> $caps Raw caps.
	 * @return array<string, string>
	 */
	private static function sanitize_role_caps( array $caps ): array {
		$out = array();

		foreach ( $caps as $cap => $value ) {
			if ( ! is_string( $cap ) || '' === $cap ) {
				continue;
			}

			$key = sanitize_key( $cap );

			if ( '' === $key ) {
				continue;
			}

			$out[ $key ] = ( 'off' === $value ) ? 'off' : 'on';
		}

		return $out;
	}

	/**
	 * Stable hash of Role Editor settings for dirty detection.
	 *
	 * @param array<string, array<string, string>> $settings Role settings.
	 */
	private static function hash_role_settings( array $settings ): string {
		$encoded = wp_json_encode( $settings );

		return is_string( $encoded ) ? md5( $encoded ) : '';
	}

	/**
	 * Persisted Handoff snapshot and applied flags.
	 *
	 * @return array<string, mixed>
	 */
	private static function get_state(): array {
		$state = get_option( self::STATE_OPTION, array() );

		if ( ! is_array( $state ) ) {
			$state = array();
		}

		$snapshot = isset( $state['snapshot'] ) && is_array( $state['snapshot'] )
			? self::sanitize_role_settings( $state['snapshot'] )
			: array();

		$has_custom_flag = array_key_exists( 'use_custom_role', $state );
		$use_custom_role = $has_custom_flag && ! empty( $state['use_custom_role'] );
		$target_role     = isset( $state['target_role'] ) ? sanitize_key( (string) $state['target_role'] ) : '';

		if ( '' === $target_role || self::is_blocked_target_role( $target_role ) ) {
			$target_role = self::TARGET_ROLE;
		}

		$role_name = isset( $state['target_role_name'] ) ? sanitize_text_field( (string) $state['target_role_name'] ) : '';
		$applied   = ! empty( $state['applied'] );
		$bar_tools = array_key_exists( 'hidden_bar_tools', $state ) && is_array( $state['hidden_bar_tools'] )
			? self::sanitize_hidden_bar_tools( $state['hidden_bar_tools'] )
			: self::all_bar_tool_keys();

		return array(
			'applied'             => $applied,
			'has_snapshot'        => ! empty( $state['has_snapshot'] ),
			'snapshot'            => $snapshot,
			'target_role'         => $target_role,
			'target_role_name'    => $role_name,
			'use_custom_role'     => $use_custom_role,
			'has_custom_flag'     => $has_custom_flag,
			'legacy_editor_apply' => $applied && self::TARGET_ROLE === $target_role && ! $has_custom_flag,
			'applied_at'          => isset( $state['applied_at'] ) ? absint( $state['applied_at'] ) : 0,
			'applied_hash'        => isset( $state['applied_hash'] ) ? sanitize_text_field( (string) $state['applied_hash'] ) : '',
			'hidden_bar_tools'    => $bar_tools,
			'pages_mode'          => ClientHandoffAccess::sanitize_pages_mode( $state['pages_mode'] ?? 'all' ),
			'page_ids'            => ClientHandoffAccess::sanitize_page_ids( $state['page_ids'] ?? array() ),
			'allow_create'        => ! empty( $state['allow_create'] ),
			'admin_trim_enabled'  => array_key_exists( 'admin_trim_enabled', $state ) ? ! empty( $state['admin_trim_enabled'] ) : true,
			'hidden_menus'        => ClientHandoffAccess::sanitize_hidden_menus(
				array_key_exists( 'hidden_menus', $state ) && is_array( $state['hidden_menus'] )
					? $state['hidden_menus']
					: ClientHandoffAccess::default_hidden_menus()
			),
			'admin_cap_backup'    => ClientHandoffAccess::sanitize_cap_names( $state['admin_cap_backup'] ?? array() ),
			'admin_cap_role'      => isset( $state['admin_cap_role'] ) ? sanitize_key( (string) $state['admin_cap_role'] ) : '',
		);
	}

	/**
	 * Handoff settings screen URL.
	 *
	 * @param string $section Inner section slug. Empty is Overview.
	 * @return string
	 */
	public static function get_settings_url( string $section = '' ): string {
		$args = array(
			'page' => 'divi_supreme_settings',
			'tab'  => self::SECTION_ID,
		);

		$section = sanitize_key( $section );

		if ( 'modules' === $section ) {
			$section = 'builder';
		}

		if ( in_array( $section, array( 'pages', 'admin', 'builder', 'guide' ), true ) ) {
			$args['section'] = $section;
		}

		return add_query_arg( $args, admin_url( 'admin.php' ) );
	}

	/**
	 * Access slice used by pages, admin trim, and preview.
	 *
	 * @return array<string, mixed>
	 */
	public static function get_access_state(): array {
		$state = self::get_state();

		return array(
			'applied'            => ! empty( $state['applied'] ),
			'target_role'        => (string) $state['target_role'],
			'use_custom_role'    => ! empty( $state['use_custom_role'] ),
			'pages_mode'         => (string) $state['pages_mode'],
			'page_ids'           => $state['page_ids'],
			'allow_create'       => ! empty( $state['allow_create'] ),
			'admin_trim_enabled' => ! empty( $state['admin_trim_enabled'] ),
			'hidden_menus'       => $state['hidden_menus'],
			'admin_cap_backup'   => $state['admin_cap_backup'],
			'admin_cap_role'     => (string) $state['admin_cap_role'],
		);
	}

	/**
	 * Merge access keys into persisted Handoff state.
	 *
	 * @param array<string, mixed> $patch Keys already sanitized.
	 */
	public static function merge_access_state( array $patch ): void {
		$state = self::get_state();

		foreach ( $patch as $key => $value ) {
			$state[ $key ] = $value;
		}

		self::save_state( $state );
	}

	/**
	 * Persist Handoff state without autoload.
	 *
	 * @param array<string, mixed> $state State to persist.
	 */
	private static function save_state( array $state ): void {
		update_option( self::STATE_OPTION, $state, false );
	}

	/**
	 * Supreme modules that appear in Role Editor Module Use (`d4Shortcode`).
	 *
	 * @return list<array{name: string, shortcode: string, title: string}>
	 */
	public static function get_supreme_module_catalog(): array {
		$rows = array();

		foreach ( self::read_module_json_catalog() as $row ) {
			if ( '' === $row['shortcode'] ) {
				continue;
			}

			$rows[] = $row;
		}

		usort(
			$rows,
			static function ( array $a, array $b ): int {
				return strcasecmp( $a['title'], $b['title'] );
			}
		);

		return $rows;
	}

	/**
	 * Supreme `d4Shortcode` keys that Role Editor can toggle.
	 *
	 * @return string[]
	 */
	private static function get_supreme_role_editor_keys(): array {
		$keys = array();

		foreach ( self::get_supreme_module_catalog() as $row ) {
			$keys[] = $row['shortcode'];
		}

		return $keys;
	}

	/**
	 * Parse `module.json` files under the Divi 5 module library.
	 *
	 * @return list<array{name: string, shortcode: string, title: string}>
	 */
	private static function read_module_json_catalog(): array {
		static $cache = null;

		if ( is_array( $cache ) ) {
			return $cache;
		}

		$cache   = array();
		$base    = defined( 'DSM_DIR_PATH' ) ? DSM_DIR_PATH . 'divi-5/packages/module-library' : '';
		$pattern = '' !== $base ? trailingslashit( $base ) . '*/module.json' : '';

		if ( '' === $pattern ) {
			return $cache;
		}

		foreach ( (array) glob( $pattern ) as $file ) {
			if ( ! is_string( $file ) || ! is_readable( $file ) ) {
				continue;
			}

			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- local plugin module.json.
			$json = json_decode( (string) file_get_contents( $file ), true );

			if ( ! is_array( $json ) || empty( $json['name'] ) || ! is_string( $json['name'] ) ) {
				continue;
			}

			if ( ! str_starts_with( $json['name'], 'dsm/' ) ) {
				continue;
			}

			$shortcode = isset( $json['d4Shortcode'] ) && is_string( $json['d4Shortcode'] )
				? sanitize_key( $json['d4Shortcode'] )
				: '';
			$title     = isset( $json['title'] ) && is_string( $json['title'] ) && '' !== $json['title']
				? $json['title']
				: $json['name'];

			$cache[] = array(
				'name'      => $json['name'],
				'shortcode' => $shortcode,
				'title'     => $title,
			);
		}

		return $cache;
	}

	/**
	 * Localized WordPress role name for the Handoff target.
	 *
	 * @return string
	 */
	private static function get_target_role_label(): string {
		$state = self::get_state();
		$slug  = $state['target_role'];

		if ( function_exists( 'wp_roles' ) ) {
			$names = wp_roles()->get_names();
			$name  = $names[ $slug ] ?? '';

			if ( is_string( $name ) && '' !== $name ) {
				return translate_user_role( $name );
			}
		}

		if ( '' !== $state['target_role_name'] ) {
			return $state['target_role_name'];
		}

		return __( 'Editor', 'dsm-supreme-modules-pro-for-divi' );
	}

	/**
	 * Whether the dashboard should offer a dedicated client role.
	 *
	 * @param array<string, mixed> $state Normalized Handoff state.
	 * @return bool
	 */
	private static function ui_prefers_custom_role( array $state ): bool {
		if ( ! empty( $state['legacy_editor_apply'] ) ) {
			return true;
		}

		if ( ! empty( $state['applied'] ) ) {
			return ! empty( $state['use_custom_role'] );
		}

		if ( empty( $state['has_custom_flag'] ) ) {
			return true;
		}

		return ! empty( $state['use_custom_role'] );
	}

	/**
	 * Whether a Handoff custom role slug is registered.
	 *
	 * @param array<string, mixed> $state Normalized Handoff state.
	 * @return bool
	 */
	private static function custom_role_exists( array $state ): bool {
		$slug = isset( $state['target_role'] ) ? (string) $state['target_role'] : '';

		return str_starts_with( $slug, self::CUSTOM_ROLE_PREFIX ) && get_role( $slug ) instanceof \WP_Role;
	}

	/**
	 * Users screen, filtered to the custom role when one exists.
	 *
	 * @param array<string, mixed> $state Normalized Handoff state.
	 * @return string
	 */
	private static function get_users_screen_url( array $state ): string {
		$args = array();

		if ( self::custom_role_exists( $state ) ) {
			$args['role'] = (string) $state['target_role'];
		}

		return add_query_arg( $args, admin_url( 'users.php' ) );
	}

	/**
	 * Apply from the dashboard request.
	 *
	 * When Handoff is already applied to Editor, `move_from_editor` restores
	 * that snapshot before creating the custom role and applying again.
	 *
	 * @param bool   $use_custom_role  Create or reuse a dedicated role.
	 * @param string $role_name        Display name for the custom role.
	 * @param bool   $move_from_editor Restore Editor before switching.
	 * @return array{message: string, promptAssign?: bool, roleCreated?: bool, roleReused?: bool}|\WP_Error
	 */
	private static function apply_from_request( bool $use_custom_role, string $role_name, bool $move_from_editor ) {
		$state = self::get_state();

		if ( $move_from_editor ) {
			if ( empty( $state['applied'] ) || self::TARGET_ROLE !== $state['target_role'] ) {
				return new \WP_Error(
					'dsm_handoff_move_unavailable',
					__( 'Move to a custom role is only available while Handoff is applied to the default Editor role.', 'dsm-supreme-modules-pro-for-divi' )
				);
			}

			$exited = self::exit_handoff();

			if ( is_wp_error( $exited ) ) {
				return $exited;
			}

			$use_custom_role = true;
			$state           = self::get_state();
		}

		if ( ! empty( $state['applied'] ) ) {
			$stored_custom = ! empty( $state['use_custom_role'] );

			if ( $use_custom_role !== $stored_custom ) {
				return new \WP_Error(
					'dsm_handoff_role_locked',
					__( 'Exit Handoff before switching roles.', 'dsm-supreme-modules-pro-for-divi' )
				);
			}

			return self::apply_handoff(
				false,
				(string) $state['target_role'],
				! empty( $state['use_custom_role'] ),
				(string) $state['target_role_name']
			);
		}

		if ( ! $use_custom_role ) {
			return new \WP_Error(
				'dsm_handoff_editor_blocked',
				__( 'Apply Handoff to a dedicated client role. Applying to the default Editor role would change Role Editor for the whole team.', 'dsm-supreme-modules-pro-for-divi' )
			);
		}

		if ( '' === $role_name ) {
			$role_name = __( 'Client Editor', 'dsm-supreme-modules-pro-for-divi' );
		}

		$ensured = self::ensure_custom_role( $role_name );

		if ( is_wp_error( $ensured ) ) {
			return $ensured;
		}

		$result = self::apply_handoff( false, $ensured['slug'], true, $ensured['name'] );

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		if ( $ensured['created'] ) {
			$result['message'] = sprintf(
				/* translators: %s: WordPress role display name. */
				__( 'Created the %s role and applied the content-only Role Editor profile to it. The default Editor role was not changed. Assign client users below.', 'dsm-supreme-modules-pro-for-divi' ),
				$ensured['name']
			);
		} else {
			$result['message'] = sprintf(
				/* translators: %s: WordPress role display name. */
				__( 'Reused the existing %s role and applied the content-only Role Editor profile to it. The default Editor role was not changed. Assign client users below.', 'dsm-supreme-modules-pro-for-divi' ),
				$ensured['name']
			);
		}

		$result['promptAssign'] = true;
		$result['roleCreated']  = $ensured['created'];
		$result['roleReused']   = ! $ensured['created'];

		return $result;
	}

	/**
	 * Create a WordPress role cloned from Editor, or reuse the same slug.
	 *
	 * @param string $display_name Role label entered in the dashboard.
	 * @return array{slug: string, name: string, created: bool}|\WP_Error
	 */
	private static function ensure_custom_role( string $display_name ) {
		$display_name = sanitize_text_field( $display_name );
		$display_name = trim( $display_name );

		if ( function_exists( 'mb_substr' ) ) {
			$display_name = mb_substr( $display_name, 0, 80 );
		} else {
			$display_name = substr( $display_name, 0, 80 );
		}

		if ( '' === $display_name ) {
			return new \WP_Error(
				'dsm_handoff_role_name',
				__( 'Enter a name for the client role.', 'dsm-supreme-modules-pro-for-divi' )
			);
		}

		$slug = self::derive_role_slug( $display_name );

		/**
		 * Filters the WordPress role slug Handoff will create or reuse.
		 *
		 * Must stay a `dsm_` slug. Administrator and Editor are rejected.
		 *
		 * @param string $slug         Proposed role slug.
		 * @param string $display_name Role label.
		 */
		$filtered = apply_filters( 'dsm_client_handoff_custom_role_slug', $slug, $display_name );
		$slug     = is_string( $filtered ) ? sanitize_key( $filtered ) : $slug;

		if (
			! str_starts_with( $slug, self::CUSTOM_ROLE_PREFIX ) ||
			strlen( $slug ) <= strlen( self::CUSTOM_ROLE_PREFIX ) ||
			self::is_blocked_target_role( $slug ) ||
			self::TARGET_ROLE === $slug
		) {
			$slug = self::derive_role_slug( $display_name );
		}

		$existing = get_role( $slug );

		if ( $existing instanceof \WP_Role ) {
			if ( empty( $existing->capabilities['edit_posts'] ) ) {
				$existing->add_cap( 'edit_posts' );
			}

			self::flush_divi_role_caches();

			return array(
				'slug'    => $slug,
				'name'    => self::role_display_name( $slug, $display_name ),
				'created' => false,
			);
		}

		$caps   = self::editor_capabilities_for_clone( $slug, $display_name );
		$added  = add_role( $slug, $display_name, $caps );
		$exists = $added instanceof \WP_Role || get_role( $slug ) instanceof \WP_Role;

		if ( ! $exists ) {
			return new \WP_Error(
				'dsm_handoff_role_create_failed',
				__( 'The client role could not be created.', 'dsm-supreme-modules-pro-for-divi' )
			);
		}

		self::flush_divi_role_caches();

		return array(
			'slug'    => $slug,
			'name'    => $display_name,
			'created' => $added instanceof \WP_Role,
		);
	}

	/**
	 * Slug for a display name. Existing slugs are reused by the caller.
	 *
	 * @param string $display_name Role label.
	 * @return string
	 */
	private static function derive_role_slug( string $display_name ): string {
		$stem = sanitize_title( $display_name );
		$stem = sanitize_key( $stem );

		if ( '' === $stem ) {
			$stem = 'client';
		}

		$slug = self::CUSTOM_ROLE_PREFIX . $stem;

		if ( strlen( $slug ) > 60 ) {
			$slug = rtrim( substr( $slug, 0, 60 ), '-_' );
		}

		if ( ! str_starts_with( $slug, self::CUSTOM_ROLE_PREFIX ) || self::is_blocked_target_role( $slug ) ) {
			$slug = self::CUSTOM_ROLE_PREFIX . 'client';
		}

		return $slug;
	}

	/**
	 * Editor capabilities for a new client role, without site-admin caps.
	 *
	 * @param string $slug         Role slug.
	 * @param string $display_name Role label.
	 * @return array<string, bool>
	 */
	private static function editor_capabilities_for_clone( string $slug, string $display_name ): array {
		$caps   = array();
		$editor = get_role( self::TARGET_ROLE );

		if ( $editor instanceof \WP_Role ) {
			foreach ( $editor->capabilities as $cap => $grant ) {
				if ( ! is_string( $cap ) || '' === $cap || ! $grant ) {
					continue;
				}

				$caps[ $cap ] = true;
			}
		}

		$caps['read']       = true;
		$caps['edit_posts'] = true;

		foreach ( array( 'manage_options', 'activate_plugins', 'edit_users', 'promote_users', 'remove_users', 'delete_users', 'create_users' ) as $denied ) {
			unset( $caps[ $denied ] );
		}

		/**
		 * Filters capabilities copied from Editor onto a new Handoff role.
		 *
		 * `edit_posts` is forced on after this filter. `manage_options` is forced off.
		 *
		 * @param array<string, bool> $caps         Capability map.
		 * @param string              $slug         Role slug.
		 * @param string              $display_name Role label.
		 */
		$filtered = apply_filters( 'dsm_client_handoff_custom_role_caps', $caps, $slug, $display_name );

		if ( ! is_array( $filtered ) ) {
			$filtered = $caps;
		}

		$clean = array();

		foreach ( $filtered as $cap => $grant ) {
			if ( ! is_string( $cap ) || ! $grant ) {
				continue;
			}

			$key = sanitize_key( $cap );

			if ( '' !== $key ) {
				$clean[ $key ] = true;
			}
		}

		unset( $clean['manage_options'] );
		$clean['read']       = true;
		$clean['edit_posts'] = true;

		return $clean;
	}

	/**
	 * Display name for a registered role.
	 *
	 * @param string $slug     Role slug.
	 * @param string $fallback Name to use when WordPress has none.
	 * @return string
	 */
	private static function role_display_name( string $slug, string $fallback ): string {
		if ( function_exists( 'wp_roles' ) ) {
			$names = wp_roles()->get_names();
			$name  = $names[ $slug ] ?? '';

			if ( is_string( $name ) && '' !== $name ) {
				return translate_user_role( $name );
			}
		}

		return $fallback;
	}

	/**
	 * Whether Handoff must refuse this role slug.
	 *
	 * @param string $role Role slug.
	 * @return bool
	 */
	private static function is_blocked_target_role( string $role ): bool {
		return in_array( $role, self::BLOCKED_TARGET_ROLES, true );
	}

	/**
	 * Clear Divi’s in-request Role Editor cache and template assets.
	 *
	 * Same side-effects as `et_pb_save_role_settings()`.
	 */
	private static function flush_divi_role_caches(): void {
		unset( $GLOBALS['et_pb_role_settings'] );

		$wp_roles = function_exists( 'wp_roles' ) ? wp_roles() : null;

		if ( $wp_roles instanceof \WP_Roles && method_exists( $wp_roles, 'init_roles' ) ) {
			$wp_roles->init_roles();
		}

		if ( function_exists( 'et_update_option' ) ) {
			et_update_option( 'et_pb_clear_templates_cache', true );
		}

		if ( function_exists( 'et_fb_delete_builder_assets' ) ) {
			et_fb_delete_builder_assets();
		}
	}

	/**
	 * Move selected non-admin users onto the Handoff custom role.
	 *
	 * Does not change Administrators or anyone who can `manage_options`.
	 *
	 * @param int[] $user_ids User IDs from the dashboard.
	 * @return array{message: string}|\WP_Error
	 */
	private static function assign_users_to_target_role( array $user_ids ) {
		$state = self::get_state();

		if ( ! self::custom_role_exists( $state ) ) {
			return new \WP_Error(
				'dsm_handoff_assign_no_role',
				__( 'Create the client role with Apply before assigning users.', 'dsm-supreme-modules-pro-for-divi' )
			);
		}

		$slug     = (string) $state['target_role'];
		$assigned = 0;
		$skipped  = 0;

		foreach ( $user_ids as $user_id ) {
			$user = get_userdata( $user_id );

			if ( ! $user instanceof \WP_User ) {
				++$skipped;
				continue;
			}

			if ( in_array( 'administrator', (array) $user->roles, true ) || user_can( $user, 'manage_options' ) ) {
				++$skipped;
				continue;
			}

			$user->set_role( $slug );
			++$assigned;
		}

		$label = self::role_display_name( $slug, self::get_target_role_label() );

		if ( 0 === $assigned ) {
			return new \WP_Error(
				'dsm_handoff_assign_none',
				__( 'No users were assigned. Administrators are skipped.', 'dsm-supreme-modules-pro-for-divi' )
			);
		}

		return array(
			'message' => sprintf(
				/* translators: 1: number of users, 2: role display name, 3: number skipped. */
				__( 'Moved %1$d users onto %2$s. %3$d skipped (missing or administrators).', 'dsm-supreme-modules-pro-for-divi' ),
				$assigned,
				$label,
				$skipped
			),
		);
	}

	/**
	 * Non-admin users the dashboard can assign (capped).
	 *
	 * @param string $target_role Role slug used to mark current members.
	 * @return list<array{id: int, name: string, email: string, onRole: bool}>
	 */
	private static function get_assignable_users( string $target_role ): array {
		if ( ! function_exists( 'get_users' ) ) {
			return array();
		}

		$users = get_users(
			array(
				'number'       => 100,
				'orderby'      => 'display_name',
				'order'        => 'ASC',
				'role__not_in' => array( 'administrator' ),
			)
		);

		$rows = array();

		foreach ( $users as $user ) {
			if ( ! $user instanceof \WP_User ) {
				continue;
			}

			if ( user_can( $user, 'manage_options' ) ) {
				continue;
			}

			$rows[] = array(
				'id'     => (int) $user->ID,
				'name'   => $user->display_name,
				'email'  => $user->user_email,
				'onRole' => in_array( $target_role, (array) $user->roles, true ),
			);
		}

		return $rows;
	}

	/**
	 * Read a 0/1 flag from the current AJAX request.
	 *
	 * Caller must verify the nonce first.
	 *
	 * @param string $key POST key.
	 * @return bool
	 */
	private static function request_flag( string $key ): bool {
		if ( ! isset( $_POST[ $key ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- handle_ajax() verifies the nonce.
			return false;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- handle_ajax() verifies the nonce.
		$value = sanitize_text_field( wp_unslash( (string) $_POST[ $key ] ) );

		return '1' === $value || 'true' === $value;
	}

	/**
	 * Read a text field from the current AJAX request.
	 *
	 * Caller must verify the nonce first.
	 *
	 * @param string $key POST key.
	 * @return string
	 */
	private static function request_text( string $key ): string {
		if ( ! isset( $_POST[ $key ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- handle_ajax() verifies the nonce.
			return '';
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- handle_ajax() verifies the nonce.
		return sanitize_text_field( wp_unslash( (string) $_POST[ $key ] ) );
	}

	/**
	 * User IDs posted by the assign control.
	 *
	 * @return int[]
	 */
	private static function sanitize_user_ids_from_request(): array {
		$raw = isset( $_POST['user_ids'] ) ? wp_unslash( $_POST['user_ids'] ) : '[]'; // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, ET.Sniffs.ValidatedSanitizedInput.InputNotSanitized -- handle_ajax() verifies the nonce; JSON is absint-filtered.

		if ( is_string( $raw ) ) {
			$decoded = json_decode( $raw, true );
		} elseif ( is_array( $raw ) ) {
			$decoded = $raw;
		} else {
			$decoded = array();
		}

		if ( ! is_array( $decoded ) ) {
			return array();
		}

		$ids = array();

		foreach ( $decoded as $id ) {
			$user_id = absint( $id );

			if ( $user_id > 0 ) {
				$ids[] = $user_id;
			}
		}

		return array_values( array_unique( $ids ) );
	}

	/**
	 * Builder-bar tools currently hidden for the Handoff role.
	 *
	 * A missing stored list hides every allowlisted tool. The filter runs on the sanitized list.
	 *
	 * @return list<string>
	 */
	public static function get_effective_hidden_bar_tools(): array {
		$state = self::get_state();
		$tools = isset( $state['hidden_bar_tools'] ) && is_array( $state['hidden_bar_tools'] )
			? $state['hidden_bar_tools']
			: self::all_bar_tool_keys();

		/**
		 * Filters the builder-bar tools Handoff hides for the target role.
		 *
		 * Keys must match the allowlist. Unknown keys are dropped.
		 *
		 * @param list<string> $tools Sanitized tool keys.
		 */
		$filtered = apply_filters( 'dsm_client_handoff_hidden_bar_tools', $tools );

		if ( ! is_array( $filtered ) ) {
			return self::sanitize_hidden_bar_tools( $tools );
		}

		return self::sanitize_hidden_bar_tools( $filtered );
	}

	/**
	 * Inline assignment for `window.__dsmClientHandoffHiddenBarTools`.
	 *
	 * @return string
	 */
	public static function hidden_bar_tools_inline_assignment(): string {
		$json = wp_json_encode( self::get_effective_hidden_bar_tools() );

		if ( ! is_string( $json ) ) {
			$json = '[]';
		}

		return 'window.__dsmClientHandoffHiddenBarTools=' . $json . ';';
	}

	/**
	 * Keep only allowlisted builder-bar keys, in checklist order.
	 *
	 * @param array<mixed> $raw Posted or stored keys.
	 * @return list<string>
	 */
	private static function sanitize_hidden_bar_tools( array $raw ): array {
		$selected = array();

		foreach ( $raw as $key ) {
			if ( ! is_string( $key ) ) {
				continue;
			}

			if ( in_array( $key, self::all_bar_tool_keys(), true ) ) {
				$selected[ $key ] = true;
			}
		}

		$ordered = array();

		foreach ( self::all_bar_tool_keys() as $key ) {
			if ( isset( $selected[ $key ] ) ) {
				$ordered[] = $key;
			}
		}

		return $ordered;
	}

	/**
	 * Posted builder-bar checklist, or null when the request omitted it.
	 *
	 * Caller must verify the nonce first. An empty JSON array is a saved choice to hide nothing.
	 *
	 * @return list<string>|null
	 */
	private static function hidden_bar_tools_from_request(): ?array {
		if ( ! isset( $_POST['hidden_bar_tools'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- handle_ajax() verifies the nonce.
			return null;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, ET.Sniffs.ValidatedSanitizedInput.InputNotSanitized -- JSON decoded then allowlisted.
		$raw = wp_unslash( $_POST['hidden_bar_tools'] );

		if ( is_string( $raw ) ) {
			$decoded = json_decode( $raw, true );
			$raw     = is_array( $decoded ) ? $decoded : array();
		}

		if ( ! is_array( $raw ) ) {
			return array();
		}

		return self::sanitize_hidden_bar_tools( $raw );
	}

	/**
	 * Store the builder-bar checklist without writing Role Editor.
	 *
	 * @param string[] $tools Allowlisted tool keys.
	 * @return array{message: string}
	 */
	private static function save_hidden_bar_tools( array $tools ): array {
		$state                     = self::get_state();
		$state['hidden_bar_tools'] = self::sanitize_hidden_bar_tools( $tools );
		self::save_state( $state );

		return array(
			'message' => __( 'Builder bar choices saved. Role Editor was not changed.', 'dsm-supreme-modules-pro-for-divi' ),
		);
	}

	/**
	 * Divi / Extra Role Editor admin URL.
	 *
	 * @return string
	 */
	private static function get_role_editor_url(): string {
		global $shortname;

		$slug = ( is_string( $shortname ) && '' !== $shortname ) ? $shortname : 'divi';

		return add_query_arg(
			array(
				'page' => 'et_' . sanitize_key( $slug ) . '_role_editor',
			),
			admin_url( 'admin.php' )
		);
	}

	/**
	 * Shared AJAX success payload after Apply, Exit, assign, or Update snapshot.
	 *
	 * @param string               $message Success notice.
	 * @param array<string, mixed> $flags   Optional prompt flags.
	 * @return array<string, mixed>
	 */
	private static function ajax_success_payload( string $message, array $flags = array() ): array {
		$state = self::get_state();

		return array(
			'message'           => $message,
			'status'            => self::get_status(),
			'assignableUsers'   => self::get_assignable_users( $state['target_role'] ),
			'usersUrl'          => self::get_users_screen_url( $state ),
			'targetRole'        => $state['target_role'],
			'targetRoleLabel'   => self::get_target_role_label(),
			'promptAssign'      => ! empty( $flags['promptAssign'] ),
			'roleCreated'       => ! empty( $flags['roleCreated'] ),
			'roleReused'        => ! empty( $flags['roleReused'] ),
			'hiddenBarTools'    => self::get_effective_hidden_bar_tools(),
			'extensionBarTools' => self::get_enabled_extension_bar_tools(),
			'pages'             => ClientHandoffAccess::pages_payload(),
			'adminTrim'         => ClientHandoffAccess::admin_payload(),
			'previewUsers'      => ClientHandoffAccess::preview_users(),
		);
	}

	/**
	 * Divi preference keys plus Supreme sidebar buttons.
	 *
	 * @return list<string>
	 */
	private static function all_bar_tool_keys(): array {
		return array_merge( self::BAR_TOOL_KEYS, array_keys( self::EXTENSION_BAR_TOOLS ) );
	}

	/**
	 * Supreme sidebar buttons whose extension is on in Divi Supreme settings.
	 *
	 * @return list<string>
	 */
	public static function get_enabled_extension_bar_tools(): array {
		$enabled = array();

		foreach ( self::EXTENSION_BAR_TOOLS as $key => $callback ) {
			if ( function_exists( $callback ) && $callback() ) {
				$enabled[] = $key;
			}
		}

		return $enabled;
	}

	/**
	 * Dashboard copy.
	 *
	 * @return array<string, string>
	 */
	private static function get_strings(): array {
		return array(
			'statusTitle'          => __( 'Status', 'dsm-supreme-modules-pro-for-divi' ),
			'howTitle'             => __( 'How this works', 'dsm-supreme-modules-pro-for-divi' ),
			'howBody'              => __( 'Apply writes Divi Role Editor for one role so clients can edit text, images, and links only. The default is a dedicated WordPress role cloned from Editor (it keeps edit_posts, so it appears in Divi Role Editor). That path does not change the Editor role. Design and Advanced tabs, colors, fonts, spacing, CSS, and add / move / delete stay off. Elements, Background, Loop, Meta, and Order stay off — Role Editor has no keys for those groups, so Apply uses Divi’s settings-group filters. Element Presets, option-group presets, and right-click preset actions stay off the same way. The Builder bar checklist chooses which of Layers, Inspector, AI Agent, Wireframe, hover actions, X-Ray, Workspace, Help, and Product Updates stay hidden. Popup, Cursor, Preloader, Dark Mode, and Page Tour appear on that list only while the matching extension is enabled. That uses Divi’s Visual Builder preferences filter and does not write Role Editor. Administrator still sees every group. Exit restores the saved restore point and leaves the WordPress role in place.', 'dsm-supreme-modules-pro-for-divi' ),
			'howHide'              => __( 'Hide details', 'dsm-supreme-modules-pro-for-divi' ),
			'howEditTitle'         => __( 'What clients can edit', 'dsm-supreme-modules-pro-for-divi' ),
			'howEditBody'          => __( 'Text, images and links. Design and Advanced tabs, colors, fonts, spacing, CSS, and add / move / delete stay off.', 'dsm-supreme-modules-pro-for-divi' ),
			'howHiddenTitle'       => __( 'What stays hidden', 'dsm-supreme-modules-pro-for-divi' ),
			'howHiddenBody'        => __( 'Elements, Background, Loop, Meta, Order, presets and right-click preset actions. The Builder bar tab picks which builder-bar tools are hidden.', 'dsm-supreme-modules-pro-for-divi' ),
			'howUndoTitle'         => __( 'Undo', 'dsm-supreme-modules-pro-for-divi' ),
			'howUndoBody'          => __( 'Exit restores the saved restore point and leaves the WordPress role in place. Turning Client Handoff off under Extensions does the same. A dedicated role keeps the default Editor profile unchanged.', 'dsm-supreme-modules-pro-for-divi' ),
			'notAppliedLabel'      => __( 'Handoff not applied', 'dsm-supreme-modules-pro-for-divi' ),
			'roleHelpShort'        => __( 'Cloned from Editor, including edit_posts. Administrator is never assigned.', 'dsm-supreme-modules-pro-for-divi' ),
			'roleLockedHelp'       => __( 'Locked while Handoff is applied.', 'dsm-supreme-modules-pro-for-divi' ),
			'previewHelpShort'     => __( 'Switch into a Handoff user for one hour. Exit from the admin bar.', 'dsm-supreme-modules-pro-for-divi' ),
			'assignHelpShort'      => __( 'Moves users onto this role; their other roles are replaced. Admins are skipped.', 'dsm-supreme-modules-pro-for-divi' ),
			'assignShort'          => __( 'Assign selected', 'dsm-supreme-modules-pro-for-divi' ),
			'saveBeforeApply'      => __( 'save before applying', 'dsm-supreme-modules-pro-for-divi' ),
			'barTitle'             => __( 'Builder bar', 'dsm-supreme-modules-pro-for-divi' ),
			'barHelp'              => __( 'Checked tools are hidden for the Handoff role. Unchecked tools stay available. Popup, Cursor, Preloader, Dark Mode, and Page Tour appear here only while that extension is enabled. Save updates only this list. Reload the Visual Builder to see it. Role Editor is not changed.', 'dsm-supreme-modules-pro-for-divi' ),
			'barLayers'            => __( 'Layers', 'dsm-supreme-modules-pro-for-divi' ),
			'barInspector'         => __( 'Inspector', 'dsm-supreme-modules-pro-for-divi' ),
			'barAiAgent'           => __( 'AI Agent', 'dsm-supreme-modules-pro-for-divi' ),
			'barWireframe'         => __( 'Wireframe', 'dsm-supreme-modules-pro-for-divi' ),
			'barHover'             => __( 'Hover actions', 'dsm-supreme-modules-pro-for-divi' ),
			'barParentHover'       => __( 'Parent hover actions', 'dsm-supreme-modules-pro-for-divi' ),
			'barXRay'              => __( 'X-Ray', 'dsm-supreme-modules-pro-for-divi' ),
			'barWorkspace'         => __( 'Workspace', 'dsm-supreme-modules-pro-for-divi' ),
			'barHelpItem'          => __( 'Help', 'dsm-supreme-modules-pro-for-divi' ),
			'barProductUpdates'    => __( 'Product Updates', 'dsm-supreme-modules-pro-for-divi' ),
			'barPopup'             => __( 'Popup', 'dsm-supreme-modules-pro-for-divi' ),
			'barCustomCursor'      => __( 'Cursor', 'dsm-supreme-modules-pro-for-divi' ),
			'barPreloader'         => __( 'Preloader', 'dsm-supreme-modules-pro-for-divi' ),
			'barDarkMode'          => __( 'Dark Mode', 'dsm-supreme-modules-pro-for-divi' ),
			'barPageTour'          => __( 'Page Tour', 'dsm-supreme-modules-pro-for-divi' ),
			'barSave'              => __( 'Save builder bar', 'dsm-supreme-modules-pro-for-divi' ),
			'targetLabel'          => __( 'Target role', 'dsm-supreme-modules-pro-for-divi' ),
			'targetHelp'           => __( 'A dedicated role keeps the default Editor profile unchanged. Uncheck it only if the client should use Editor itself. The role is not deleted on Exit.', 'dsm-supreme-modules-pro-for-divi' ),
			'assignUsers'          => __( 'Open Users', 'dsm-supreme-modules-pro-for-divi' ),
			'roleTitle'            => __( 'Client role', 'dsm-supreme-modules-pro-for-divi' ),
			'roleHelp'             => __( 'Apply creates this WordPress role by cloning Editor capabilities, including edit_posts. If the slug already exists, it is reused. Administrator is never assigned or written.', 'dsm-supreme-modules-pro-for-divi' ),
			'useCustomRoleLabel'   => __( 'Use a dedicated client role', 'dsm-supreme-modules-pro-for-divi' ),
			'roleNameLabel'        => __( 'Role name', 'dsm-supreme-modules-pro-for-divi' ),
			'roleSlugLabel'        => __( 'Role slug', 'dsm-supreme-modules-pro-for-divi' ),
			'moveToCustomRole'     => __( 'Move to custom role', 'dsm-supreme-modules-pro-for-divi' ),
			'legacyLead'           => __( 'Applied to the default Editor role', 'dsm-supreme-modules-pro-for-divi' ),
			'legacyBody'           => __( 'Exit restores Editor. Move to a custom role restores Editor first, then applies the content-only profile only to the new role.', 'dsm-supreme-modules-pro-for-divi' ),
			'assignTitle'          => __( 'Assign client users', 'dsm-supreme-modules-pro-for-divi' ),
			'assignHelp'           => __( 'Selected users are moved onto this role (their other roles are replaced). Administrators are skipped and are not listed. You can also assign the role on the Users screen.', 'dsm-supreme-modules-pro-for-divi' ),
			'assignButton'         => __( 'Assign selected users', 'dsm-supreme-modules-pro-for-divi' ),
			'assignEmpty'          => __( 'No non-admin users were found. Create a user, then assign this role on the Users screen.', 'dsm-supreme-modules-pro-for-divi' ),
			'assignConfirm'        => __( 'Move the selected users onto this role? Their other WordPress roles will be replaced. Administrators are skipped.', 'dsm-supreme-modules-pro-for-divi' ),
			'applyConfirmCustom'   => __( 'This snapshots Role Editor and restricts only the client role named below. The default Editor role is not changed. Continue?', 'dsm-supreme-modules-pro-for-divi' ),
			'moveConfirm'          => __( 'This restores the default Editor Role Editor profile, then applies the content-only profile only to the client role named below. Continue?', 'dsm-supreme-modules-pro-for-divi' ),
			'openRoleEditor'       => __( 'Open Divi Role Editor', 'dsm-supreme-modules-pro-for-divi' ),
			'applyLabel'           => __( 'Apply Handoff', 'dsm-supreme-modules-pro-for-divi' ),
			'exitLabel'            => __( 'Exit Handoff', 'dsm-supreme-modules-pro-for-divi' ),
			'advancedLabel'        => __( 'Advanced', 'dsm-supreme-modules-pro-for-divi' ),
			'updateSnapshotLabel'  => __( 'Save restore point', 'dsm-supreme-modules-pro-for-divi' ),
			'restorePointHelp'     => __( 'Saves the current Divi Role Editor settings for this handoff role. Exit (and turning Handoff off) will put these settings back.', 'dsm-supreme-modules-pro-for-divi' ),
			'restorePointHint'     => __( 'Use this if you changed Role Editor after Apply.', 'dsm-supreme-modules-pro-for-divi' ),
			'applyConfirm'         => __( 'This will snapshot the current Role Editor settings (if none exists) and restrict the Editor role. Continue?', 'dsm-supreme-modules-pro-for-divi' ),
			'exitConfirm'          => __( 'This restores the Role Editor settings saved before Apply. Role Editor edits made while Handoff was on will be discarded unless you saved a restore point. Continue?', 'dsm-supreme-modules-pro-for-divi' ),
			'snapshotConfirm'      => __( 'Save the current Divi Role Editor settings as the restore point? Exit and turning Handoff off will put these settings back.', 'dsm-supreme-modules-pro-for-divi' ),
			'dirtyLead'            => __( 'Role Editor changed', 'dsm-supreme-modules-pro-for-divi' ),
			'appliedAtLabel'       => __( 'Applied', 'dsm-supreme-modules-pro-for-divi' ),
			'selectAll'            => __( 'Select all', 'dsm-supreme-modules-pro-for-divi' ),
			'selectNone'           => __( 'Select none', 'dsm-supreme-modules-pro-for-divi' ),
			'hideAllLabel'         => __( 'Hide all', 'dsm-supreme-modules-pro-for-divi' ),
			'hiddenCount'          =>
				/* translators: 1: number of hidden builder-bar tools, 2: total builder-bar tools. */
				__( '%1$d of %2$d hidden', 'dsm-supreme-modules-pro-for-divi' ),
			'working'              => __( 'Working…', 'dsm-supreme-modules-pro-for-divi' ),
			'confirmContinue'      => __( 'Continue', 'dsm-supreme-modules-pro-for-divi' ),
			'confirmCancel'        => __( 'Cancel', 'dsm-supreme-modules-pro-for-divi' ),
			'extensionOffNote'     => __( 'Turning Client Handoff off under Extensions restores the saved restore point if Handoff is applied.', 'dsm-supreme-modules-pro-for-divi' ),
			'navOverview'          => __( 'Overview', 'dsm-supreme-modules-pro-for-divi' ),
			'navPages'             => __( 'Pages', 'dsm-supreme-modules-pro-for-divi' ),
			'navAdmin'             => __( 'Admin', 'dsm-supreme-modules-pro-for-divi' ),
			'navModules'           => __( 'Builder bar', 'dsm-supreme-modules-pro-for-divi' ),
			'navGuide'             => __( 'Client Guide', 'dsm-supreme-modules-pro-for-divi' ),
			'pagesTitle'           => __( 'Pages allowlist', 'dsm-supreme-modules-pro-for-divi' ),
			'pagesHelp'            => __( 'Limits which pages and posts the Handoff role can edit while Handoff is applied. Administrators and other roles are not filtered. Exit stops enforcement and keeps this list.', 'dsm-supreme-modules-pro-for-divi' ),
			'pagesModeAll'         => __( 'All pages and posts', 'dsm-supreme-modules-pro-for-divi' ),
			'pagesModeOnly'        => __( 'Only selected', 'dsm-supreme-modules-pro-for-divi' ),
			'pagesModeExcept'      => __( 'All except selected', 'dsm-supreme-modules-pro-for-divi' ),
			'pagesSearch'          => __( 'Search pages and posts', 'dsm-supreme-modules-pro-for-divi' ),
			'pagesSearchHint'      => __( 'Type at least two characters. Selected items stay as chips.', 'dsm-supreme-modules-pro-for-divi' ),
			'pagesEmpty'           => __( 'No matches.', 'dsm-supreme-modules-pro-for-divi' ),
			'pagesAllowCreate'     => __( 'Allow creating new pages and posts', 'dsm-supreme-modules-pro-for-divi' ),
			'pagesAllowCreateHelp' => __( 'Off while Applied blocks the new page and new post screens for the Handoff role.', 'dsm-supreme-modules-pro-for-divi' ),
			'pagesFront'           => __( 'Front page', 'dsm-supreme-modules-pro-for-divi' ),
			'pagesPosts'           => __( 'Posts page', 'dsm-supreme-modules-pro-for-divi' ),
			'pagesSave'            => __( 'Save pages allowlist', 'dsm-supreme-modules-pro-for-divi' ),
			'pagesSaved'           => __( 'Pages allowlist saved. It is enforced only while Handoff is applied.', 'dsm-supreme-modules-pro-for-divi' ),
			'adminTitle'           => __( 'Admin trim', 'dsm-supreme-modules-pro-for-divi' ),
			'adminHelp'            => __( 'Hides the checked wp-admin menus for the Handoff role while Applied, and blocks those screens by URL. Administrators are never trimmed. The default Editor role is not changed when a dedicated client role is in use.', 'dsm-supreme-modules-pro-for-divi' ),
			'adminToggle'          => __( 'Simplify wp-admin for the Handoff role', 'dsm-supreme-modules-pro-for-divi' ),
			'adminSave'            => __( 'Save admin trim', 'dsm-supreme-modules-pro-for-divi' ),
			'adminSaved'           => __( 'Admin trim saved.', 'dsm-supreme-modules-pro-for-divi' ),
			'previewTitle'         => __( 'Preview as client', 'dsm-supreme-modules-pro-for-divi' ),
			'previewHelp'          => __( 'Switches you into a user on the Handoff role for one hour. Exit preview in the admin bar returns you to this account. Preview ends on logout.', 'dsm-supreme-modules-pro-for-divi' ),
			'previewButton'        => __( 'Preview as client', 'dsm-supreme-modules-pro-for-divi' ),
			'previewNeedApply'     => __( 'Apply Handoff before previewing.', 'dsm-supreme-modules-pro-for-divi' ),
			'previewNeedUser'      => __( 'Assign at least one user to the Handoff role, or create a preview user.', 'dsm-supreme-modules-pro-for-divi' ),
			'previewCreate'        => __( 'Create preview user', 'dsm-supreme-modules-pro-for-divi' ),
			'previewExit'          => __( 'Exit preview', 'dsm-supreme-modules-pro-for-divi' ),
			'modulesTitle'         => __( 'Builder bar', 'dsm-supreme-modules-pro-for-divi' ),
			'modulesHelp'          => __( 'Divi and Supreme module use stays in Divi Role Editor. This list only hides Builder bar tools for the Handoff role.', 'dsm-supreme-modules-pro-for-divi' ),
			'removeChip'           => __( 'Remove', 'dsm-supreme-modules-pro-for-divi' ),
			'discard'              => __( 'Discard', 'dsm-supreme-modules-pro-for-divi' ),
			'saveChanges'          => __( 'Save changes', 'dsm-supreme-modules-pro-for-divi' ),
			'saving'               => __( 'Saving…', 'dsm-supreme-modules-pro-for-divi' ),
			'unsavedOne'           => __( '1 unsaved change', 'dsm-supreme-modules-pro-for-divi' ),
			'unsavedMany'          =>
				/* translators: %d: number of unsaved changes. */
				__( '%d unsaved changes', 'dsm-supreme-modules-pro-for-divi' ),
			'unsavedGuide'         => __( 'Unsaved changes', 'dsm-supreme-modules-pro-for-divi' ),
			'note'                 => __( 'Note', 'dsm-supreme-modules-pro-for-divi' ),
			'warning'              => __( 'Warning', 'dsm-supreme-modules-pro-for-divi' ),
			'handoffApplied'       => __( 'Handoff applied', 'dsm-supreme-modules-pro-for-divi' ),
			'handoffAppliedAt'     =>
				/* translators: %s: date and time Handoff was applied. */
				__( 'Handoff applied · %s', 'dsm-supreme-modules-pro-for-divi' ),
			'editorApplyWarning'   => __( 'Applying without a dedicated role changes Divi’s Role Editor for the default Editor role and can affect the whole team. Move to a custom role so Editor stays unchanged.', 'dsm-supreme-modules-pro-for-divi' ),
			'pagesOnlyEmpty'       => __( 'Only selected with no pages blocks the Handoff role from every existing page and post. Pages they create stay editable only while “Allow creating new pages and posts” is on.', 'dsm-supreme-modules-pro-for-divi' ),
			'previewModeSwitching' => __( 'Using User Switching', 'dsm-supreme-modules-pro-for-divi' ),
			'previewModeCookie'    => __( 'Using built-in preview', 'dsm-supreme-modules-pro-for-divi' ),
		);
	}
}
