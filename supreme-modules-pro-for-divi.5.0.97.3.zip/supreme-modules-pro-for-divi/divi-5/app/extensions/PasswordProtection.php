<?php
/**
 * Sitewide Password Protection — multi-password gate with Library layout + form.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Extensions;

use DiviSupreme\Includes\DiviLibraryLayoutRenderer;
use DiviSupreme\Includes\DsmLibraryLayoutSelectOptions;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Sitewide + per-page password gate with Library layout + form.
 */
class PasswordProtection {

	/**
	 * Settings section option key.
	 */
	public const OPTION_SECTION = 'dsm_settings_protection';

	/**
	 * Option: enable sitewide gate (`on`|`off`).
	 */
	public const OPTION_ENABLED = 'dsm_password_protection_enabled';

	/**
	 * Option: Divi Library layout post ID or `none`.
	 */
	public const OPTION_LAYOUT_ID = 'dsm_password_protection_layout_id';

	/**
	 * Option: allow logged-in users to bypass (`on`|`off`).
	 *
	 * Legacy — kept in sync from {@see OPTION_BYPASS_MODE} for older readers.
	 */
	public const OPTION_BYPASS_LOGGED_IN = 'dsm_password_protection_bypass_logged_in';

	/**
	 * Option: sitewide bypass mode (`none`|`logged_in`|`roles`).
	 */
	public const OPTION_BYPASS_MODE = 'dsm_password_protection_bypass_mode';

	/**
	 * Option: sitewide bypass role slugs (associative map for multicheck).
	 */
	public const OPTION_BYPASS_ROLES = 'dsm_password_protection_bypass_roles';

	/**
	 * Option: cookie TTL in days (`1`|`7`|`14`|`30`).
	 */
	public const OPTION_COOKIE_TTL_DAYS = 'dsm_password_protection_cookie_ttl_days';

	/**
	 * Option: password entries JSON (hashes only after save).
	 */
	public const OPTION_ENTRIES = 'dsm_password_protection_entries';

	/**
	 * Option: IP allowlist (one IP/CIDR per line).
	 */
	public const OPTION_IP_ALLOWLIST = 'dsm_password_protection_ip_allowlist';

	/**
	 * Option: list version — bumped when password hashes/list change (invalidates cookies).
	 */
	public const OPTION_LIST_VERSION = 'dsm_password_protection_list_version';

	/**
	 * Unlock cookie name.
	 */
	public const COOKIE_NAME = 'dsm_pp_unlocked';

	/**
	 * POST action field value.
	 */
	public const POST_ACTION = 'dsm_pp_unlock';

	/**
	 * Token used in legacy editors to keep an existing hash.
	 */
	public const KEEP_TOKEN = 'KEEP';

	/**
	 * Phase 2: post meta key for per-page enable (`on`|`off`).
	 */
	public const META_PAGE_ENABLED = '_dsm_password_protection_page_enabled';

	/**
	 * Phase 2: post meta key for per-page password entries JSON.
	 */
	public const META_PAGE_ENTRIES = '_dsm_password_protection_page_entries';

	/**
	 * Phase 2: post meta key for per-page list version (invalidates page cookies).
	 */
	public const META_PAGE_LIST_VERSION = '_dsm_password_protection_page_list_version';

	/**
	 * Per-page bypass mode (`none`|`logged_in`|`roles`).
	 */
	public const META_PAGE_BYPASS_MODE = '_dsm_password_protection_page_bypass_mode';

	/**
	 * Per-page bypass role slugs (array or JSON list).
	 */
	public const META_PAGE_BYPASS_ROLES = '_dsm_password_protection_page_bypass_roles';

	/**
	 * Gate mode for the current request: ``, `sitewide`, or `page`.
	 *
	 * @var string
	 */
	private string $gate_mode = '';

	/**
	 * Post ID when gate_mode is `page`.
	 *
	 * @var int
	 */
	private int $gate_post_id = 0;

	/**
	 * Cached gate evaluation for this request.
	 *
	 * @var bool|null
	 */
	private ?bool $gate_should_intercept = null;

	/**
	 * Whether the main query was hijacked for a layout this request.
	 *
	 * @var bool
	 */
	private bool $query_hijacked = false;

	/**
	 * Layout ID used for the hijacked query (0 if none).
	 *
	 * @var int
	 */
	private int $hijacked_layout_id = 0;

	/**
	 * Block-level Section/Row/Column gate helper.
	 *
	 * @var PasswordProtectionBlock|null
	 */
	private ?PasswordProtectionBlock $block_support = null;

	/**
	 * Constructor.
	 */
	public function __construct() {
		$GLOBALS['dsm_password_protection_extension'] = $this;

		add_action( 'init', array( $this, 'maybe_handle_unlock_request' ), 1 );
		add_action( 'pre_get_posts', array( $this, 'maybe_hijack_main_query' ), 2 );
		add_filter( 'template_include', array( $this, 'maybe_use_protection_template' ), 98 );
		add_action( 'template_redirect', array( $this, 'maybe_send_headers_or_fallback' ), 2 );
		add_action( 'admin_bar_menu', array( $this, 'maybe_add_admin_bar_notice' ), 101 );
		add_filter( 'body_class', array( $this, 'filter_body_class' ) );
		add_shortcode( 'dsm_password_form', array( $this, 'render_password_form_shortcode' ) );

		if ( $this->is_extension_enabled() ) {
			PasswordProtectionMetabox::register();
		}

		if ( $this->is_extension_enabled() && class_exists( PasswordProtectionBlock::class ) ) {
			$this->block_support = new PasswordProtectionBlock( $this );
		}
	}

	/**
	 * Whether Divi Supreme → Extensions → Password Protection is enabled.
	 *
	 * @return bool
	 */
	private function is_extension_enabled(): bool {
		return function_exists( 'dsm_is_password_protection_extension_enabled' )
			&& dsm_is_password_protection_extension_enabled();
	}

	/**
	 * Whether the current request should bypass Protection (public for block gate).
	 *
	 * @return bool
	 */
	public function should_bypass_protection(): bool {
		return $this->should_bypass();
	}

	/**
	 * Bypass rules for Section/Row/Column gates.
	 *
	 * Administrators (`manage_options`) always bypass. Per-block logged-in / role
	 * bypass is handled separately via {@see user_bypasses_block_attrs()}.
	 *
	 * @return bool
	 */
	public function should_bypass_block_gate(): bool {
		if ( is_admin() ) {
			return true;
		}

		if ( wp_doing_ajax() || wp_doing_cron() ) {
			return true;
		}

		if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
			return true;
		}

		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			return true;
		}

		if ( $this->is_login_or_system_request() ) {
			return true;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only presence checks.
		if ( isset( $_GET['et_fb'] ) || isset( $_GET['et_tb'] ) ) {
			return true;
		}

		if ( function_exists( 'et_core_is_fb_enabled' ) && et_core_is_fb_enabled() ) {
			return true;
		}

		// Admins always see locked block content (sitewide gate uses the same rule).
		if ( current_user_can( 'manage_options' ) ) {
			return true;
		}

		// Sitewide logged-in / role bypass also unlocks block gates (legacy parity).
		if ( $this->user_bypasses_sitewide_gate() ) {
			return true;
		}

		if ( $this->client_ip_is_allowlisted() ) {
			return true;
		}

		/**
		 * Filters whether the current request bypasses block-level Password Protection.
		 *
		 * @param bool $bypass Whether to bypass.
		 */
		return (bool) apply_filters( 'dsm_password_protection_should_bypass_block', false );
	}

	/**
	 * Per-block logged-in / role bypass (after system + admin gate checks).
	 *
	 * @param array<string,mixed> $attrs Block attrs.
	 * @return bool
	 */
	public function user_bypasses_block_attrs( array $attrs ): bool {
		if ( current_user_can( 'manage_options' ) ) {
			return true;
		}

		$mode = 'none';
		if (
			isset( $attrs['dsm_pp_bypass_mode']['innerContent']['desktop']['value'] )
			&& is_scalar( $attrs['dsm_pp_bypass_mode']['innerContent']['desktop']['value'] )
		) {
			$mode = sanitize_key( (string) $attrs['dsm_pp_bypass_mode']['innerContent']['desktop']['value'] );
		}

		$roles = $attrs['dsm_pp_bypass_roles']['innerContent']['desktop']['value'] ?? array();

		return self::user_matches_bypass_mode( $mode, $roles );
	}

	/**
	 * Whether the current user matches a bypass mode + role list.
	 *
	 * Administrators are handled by callers via `manage_options` (always bypass).
	 *
	 * @param string                          $mode  `none`|`logged_in`|`roles`.
	 * @param array<int|string, mixed>|string $roles Selected roles.
	 * @return bool
	 */
	public static function user_matches_bypass_mode( string $mode, $roles ): bool {
		$mode = self::sanitize_bypass_mode_option( $mode );

		if ( 'logged_in' === $mode ) {
			return is_user_logged_in();
		}

		if ( 'roles' !== $mode || ! is_user_logged_in() ) {
			return false;
		}

		$selected = self::normalize_bypass_role_slugs( $roles );
		if ( array() === $selected ) {
			return false;
		}

		$user = wp_get_current_user();
		if ( ! $user instanceof \WP_User || array() === (array) $user->roles ) {
			return false;
		}

		return array() !== array_intersect( $selected, (array) $user->roles );
	}

	/**
	 * Role options for the Visual Builder bypass checkboxes (excludes administrator).
	 *
	 * @return array<int, array{label: string, value: string}>
	 */
	public static function get_bypass_role_options_for_js(): array {
		$out = array();
		foreach ( self::get_bypass_role_options_for_settings() as $slug => $label ) {
			$out[] = array(
				'label' => (string) $label,
				'value' => (string) $slug,
			);
		}

		/**
		 * Filters role options shown in block Password Protection bypass settings.
		 *
		 * @param array<int, array{label: string, value: string}> $out Role options.
		 */
		return (array) apply_filters( 'dsm_password_protection_bypass_role_options', $out );
	}

	/**
	 * Role options for settings multicheck / metabox (slug => label, excludes administrator).
	 *
	 * @return array<string, string>
	 */
	public static function get_bypass_role_options_for_settings(): array {
		if ( ! function_exists( 'wp_roles' ) ) {
			return array();
		}

		$out = array();
		foreach ( wp_roles()->role_names as $slug => $name ) {
			$slug = sanitize_key( (string) $slug );
			if ( '' === $slug || 'administrator' === $slug ) {
				continue;
			}
			$out[ $slug ] = translate_user_role( (string) $name );
		}

		/**
		 * Filters role options shown in sitewide / per-page Password Protection bypass settings.
		 *
		 * @param array<string, string> $out Role slug => label.
		 */
		return (array) apply_filters( 'dsm_password_protection_bypass_role_options_settings', $out );
	}

	/**
	 * Sanitize bypass mode option.
	 *
	 * @param mixed $value Raw value.
	 * @return string `none`|`logged_in`|`roles`.
	 */
	public static function sanitize_bypass_mode_option( $value ): string {
		$mode = sanitize_key( is_scalar( $value ) ? (string) $value : '' );

		return in_array( $mode, array( 'none', 'logged_in', 'roles' ), true ) ? $mode : 'none';
	}

	/**
	 * Sanitize bypass roles for settings storage (associative multicheck map).
	 *
	 * @param mixed $value Raw value.
	 * @return array<string, string>
	 */
	public static function sanitize_bypass_roles_option( $value ): array {
		$slugs = self::normalize_bypass_role_slugs( $value );
		$out   = array();
		foreach ( $slugs as $slug ) {
			$out[ $slug ] = $slug;
		}

		return $out;
	}

	/**
	 * Effective sitewide bypass mode (honors legacy logged-in checkbox).
	 *
	 * @return string `none`|`logged_in`|`roles`.
	 */
	public static function get_sitewide_bypass_mode(): string {
		$options = get_option( self::OPTION_SECTION, array() );
		if ( ! is_array( $options ) ) {
			$options = array();
		}

		if (
			isset( $options[ self::OPTION_BYPASS_MODE ] )
			&& is_scalar( $options[ self::OPTION_BYPASS_MODE ] )
			&& '' !== (string) $options[ self::OPTION_BYPASS_MODE ]
		) {
			$mode = self::sanitize_bypass_mode_option( (string) $options[ self::OPTION_BYPASS_MODE ] );
		} elseif (
			isset( $options[ self::OPTION_BYPASS_LOGGED_IN ] )
			&& 'on' === $options[ self::OPTION_BYPASS_LOGGED_IN ]
		) {
			$mode = 'logged_in';
		} else {
			$mode = 'none';
		}

		/**
		 * Filters the sitewide Password Protection bypass mode.
		 *
		 * @param string $mode Bypass mode.
		 */
		return self::sanitize_bypass_mode_option(
			(string) apply_filters( 'dsm_password_protection_sitewide_bypass_mode', $mode )
		);
	}

	/**
	 * Selected sitewide bypass role slugs.
	 *
	 * @return array<int, string>
	 */
	public static function get_sitewide_bypass_roles(): array {
		$options = get_option( self::OPTION_SECTION, array() );
		$raw     = ( is_array( $options ) && isset( $options[ self::OPTION_BYPASS_ROLES ] ) )
			? $options[ self::OPTION_BYPASS_ROLES ]
			: array();

		$roles = self::normalize_bypass_role_slugs( $raw );

		/**
		 * Filters sitewide Password Protection bypass roles.
		 *
		 * @param array<int, string> $roles Role slugs.
		 */
		return self::normalize_bypass_role_slugs(
			apply_filters( 'dsm_password_protection_sitewide_bypass_roles', $roles )
		);
	}

	/**
	 * Multicheck value map for the settings dashboard.
	 *
	 * @return array<string, string>
	 */
	public static function get_sitewide_bypass_roles_for_settings_multicheck(): array {
		return self::sanitize_bypass_roles_option( self::get_sitewide_bypass_roles() );
	}

	/**
	 * Whether the current user bypasses the sitewide password gate via mode/roles.
	 *
	 * @return bool
	 */
	public function user_bypasses_sitewide_gate(): bool {
		if ( current_user_can( 'manage_options' ) ) {
			return true;
		}

		$bypass = self::user_matches_bypass_mode(
			self::get_sitewide_bypass_mode(),
			self::get_sitewide_bypass_roles()
		);

		/**
		 * Filters whether the current user bypasses sitewide Password Protection via mode/roles.
		 *
		 * @param bool $bypass Whether to bypass.
		 */
		return (bool) apply_filters( 'dsm_password_protection_user_bypasses_sitewide', $bypass );
	}

	/**
	 * Per-page bypass mode.
	 *
	 * @param int $post_id Post ID.
	 * @return string `none`|`logged_in`|`roles`.
	 */
	public static function get_page_bypass_mode( int $post_id ): string {
		$mode = 'none';
		if ( $post_id > 0 ) {
			$mode = self::sanitize_bypass_mode_option(
				(string) get_post_meta( $post_id, self::META_PAGE_BYPASS_MODE, true )
			);
		}

		/**
		 * Filters per-page Password Protection bypass mode.
		 *
		 * @param string $mode    Bypass mode.
		 * @param int    $post_id Post ID.
		 */
		return self::sanitize_bypass_mode_option(
			(string) apply_filters( 'dsm_password_protection_page_bypass_mode', $mode, $post_id )
		);
	}

	/**
	 * Per-page bypass role slugs.
	 *
	 * @param int $post_id Post ID.
	 * @return array<int, string>
	 */
	public static function get_page_bypass_roles( int $post_id ): array {
		$raw = array();
		if ( $post_id > 0 ) {
			$raw = get_post_meta( $post_id, self::META_PAGE_BYPASS_ROLES, true );
		}

		$roles = self::normalize_bypass_role_slugs( $raw );

		/**
		 * Filters per-page Password Protection bypass roles.
		 *
		 * @param array<int, string> $roles   Role slugs.
		 * @param int                $post_id Post ID.
		 */
		return self::normalize_bypass_role_slugs(
			apply_filters( 'dsm_password_protection_page_bypass_roles', $roles, $post_id )
		);
	}

	/**
	 * Whether the current user bypasses the per-page password gate via mode/roles.
	 *
	 * @param int $post_id Post ID.
	 * @return bool
	 */
	public static function user_bypasses_page_gate( int $post_id ): bool {
		if ( current_user_can( 'manage_options' ) ) {
			return true;
		}

		$bypass = self::user_matches_bypass_mode(
			self::get_page_bypass_mode( $post_id ),
			self::get_page_bypass_roles( $post_id )
		);

		/**
		 * Filters whether the current user bypasses per-page Password Protection via mode/roles.
		 *
		 * @param bool $bypass  Whether to bypass.
		 * @param int  $post_id Post ID.
		 */
		return (bool) apply_filters( 'dsm_password_protection_user_bypasses_page', $bypass, $post_id );
	}

	/**
	 * Persist per-page bypass mode + roles from the editor metabox.
	 *
	 * @param int   $post_id Post ID.
	 * @param mixed $mode    Posted mode.
	 * @param mixed $roles   Posted roles (array map or list).
	 * @return void
	 */
	public static function save_page_bypass_from_request( int $post_id, $mode, $roles ): void {
		if ( $post_id <= 0 ) {
			return;
		}

		update_post_meta(
			$post_id,
			self::META_PAGE_BYPASS_MODE,
			self::sanitize_bypass_mode_option( $mode )
		);
		update_post_meta(
			$post_id,
			self::META_PAGE_BYPASS_ROLES,
			self::normalize_bypass_role_slugs( $roles )
		);
	}

	/**
	 * Normalize checkbox / legacy role values to role slugs.
	 *
	 * @param mixed $raw Attr value.
	 * @return array<int, string>
	 */
	public static function normalize_bypass_role_slugs( $raw ): array {
		if ( is_string( $raw ) ) {
			$raw = trim( $raw );
			if ( '' === $raw ) {
				return array();
			}
			$decoded = json_decode( $raw, true );
			$raw     = is_array( $decoded ) ? $decoded : array_map( 'trim', explode( ',', $raw ) );
		}

		if ( ! is_array( $raw ) ) {
			return array();
		}

		$out = array();
		foreach ( $raw as $key => $value ) {
			// Object map: { editor: 'on' } or settings multicheck { editor: 'editor' }.
			if ( is_string( $key ) && ! is_numeric( $key ) ) {
				$slug = sanitize_key( $key );
				if ( '' === $slug || 'administrator' === $slug ) {
					continue;
				}

				$enabled = false;
				if ( true === $value || 1 === $value || '1' === $value || 'on' === $value ) {
					$enabled = true;
				} elseif ( is_scalar( $value ) && sanitize_key( (string) $value ) === $slug ) {
					// Settings multicheck stores { editor: 'editor' }.
					$enabled = true;
				}

				if ( $enabled ) {
					$out[] = $slug;
				}
				continue;
			}

			if ( ! is_scalar( $value ) ) {
				continue;
			}
			$slug = sanitize_key( (string) $value );
			if ( '' !== $slug && 'administrator' !== $slug ) {
				$out[] = $slug;
			}
		}

		return array_values( array_unique( $out ) );
	}

	/**
	 * Normalize entries array (public for block attrs).
	 *
	 * @param array<int, mixed> $decoded Raw rows.
	 * @return array<int, array{id: string, label: string, hash: string, enabled: string}>
	 */
	public static function normalize_entries_public( array $decoded ): array {
		return self::normalize_entries_array( $decoded, array() );
	}

	/**
	 * Layout select options for the settings dashboard (layout-type items only).
	 *
	 * @return array<string, string> Value => label.
	 */
	public static function get_layout_select_options(): array {
		$raw = DsmLibraryLayoutSelectOptions::get_options();
		$out = array(
			'none' => __( '— Select Library Layout —', 'dsm-supreme-modules-pro-for-divi' ),
		);

		foreach ( $raw as $id => $title ) {
			if ( 'none' === (string) $id ) {
				continue;
			}

			$post_id = absint( $id );
			if ( $post_id <= 0 ) {
				continue;
			}

			if ( 'layout' !== DsmLibraryLayoutSelectOptions::get_layout_type_slug( $post_id ) ) {
				continue;
			}

			$label = is_string( $title ) ? $title : '';
			if ( '' === $label ) {
				$label = sprintf(
					/* translators: %d: library post ID */
					__( 'Untitled Layout %d', 'dsm-supreme-modules-pro-for-divi' ),
					$post_id
				);
			}

			$out[ (string) $post_id ] = sprintf(
				/* translators: 1: layout title, 2: post ID */
				__( '%1$s (#%2$d)', 'dsm-supreme-modules-pro-for-divi' ),
				$label,
				$post_id
			);
		}

		return $out;
	}

	/**
	 * Sanitize stored layout option value.
	 *
	 * @param mixed $value Raw option value.
	 * @return string `none` or numeric post ID string.
	 */
	public static function sanitize_layout_option( $value ): string {
		$value = sanitize_text_field( (string) $value );

		if ( '' === $value || 'none' === $value || '0' === $value ) {
			return 'none';
		}

		$post_id = absint( $value );
		if ( $post_id <= 0 ) {
			return 'none';
		}

		$post = get_post( $post_id );
		if ( ! $post instanceof \WP_Post ) {
			return 'none';
		}

		$layout_type = defined( 'ET_BUILDER_LAYOUT_POST_TYPE' ) ? ET_BUILDER_LAYOUT_POST_TYPE : 'et_pb_layout';
		if ( $layout_type !== $post->post_type ) {
			return 'none';
		}

		return (string) $post_id;
	}

	/**
	 * Sanitize cookie TTL days.
	 *
	 * @param mixed $value Raw value.
	 * @return string
	 */
	public static function sanitize_cookie_ttl_option( $value ): string {
		$value = sanitize_text_field( (string) $value );

		return in_array( $value, array( '1', '7', '14', '30' ), true ) ? $value : '14';
	}

	/**
	 * Sanitize IP allowlist textarea (preserve newlines).
	 *
	 * @param mixed $value Raw value.
	 * @return string
	 */
	public static function sanitize_ip_allowlist_option( $value ): string {
		$text  = is_string( $value ) ? $value : '';
		$text  = sanitize_textarea_field( $text );
		$lines = preg_split( '/\r\n|\r|\n/', $text );
		if ( ! is_array( $lines ) ) {
			return '';
		}

		$clean = array();
		foreach ( $lines as $line ) {
			$line = trim( (string) $line );
			if ( '' === $line || 0 === strpos( $line, '#' ) ) {
				continue;
			}
			// Strip optional trailing notes after whitespace or `#`.
			$parts     = preg_split( '/\s+#|\s{2,}/', $line, 2 );
			$candidate = is_array( $parts ) ? trim( (string) $parts[0] ) : $line;
			if ( '' === $candidate ) {
				continue;
			}
			if ( self::is_valid_ip_or_cidr( $candidate ) ) {
				$clean[] = $candidate;
			}
		}

		return implode( "\n", $clean );
	}

	/**
	 * Sanitize password entries from UI JSON / legacy textarea → store JSON of hashed entries.
	 *
	 * UI payload (preferred): JSON array of `{ id?, label, password?, enabled }`.
	 * Empty `password` keeps the existing hash for that `id`. New rows need a password.
	 *
	 * @param mixed                                                                            $value    Raw editor JSON, UI array, or legacy pipe text.
	 * @param array<int, array{id: string, label: string, hash: string, enabled: string}>|null $previous Optional previous entries (defaults to sitewide stored).
	 * @return string JSON array.
	 */
	public static function sanitize_entries_option( $value, ?array $previous = null ): string {
		$previous = null !== $previous ? $previous : self::get_stored_entries();

		if ( is_array( $value ) ) {
			$decoded = $value;
		} else {
			$text    = is_string( $value ) ? $value : '';
			$decoded = json_decode( $text, true );
			if ( ! is_array( $decoded ) ) {
				return self::sanitize_entries_from_legacy_textarea( $text, $previous );
			}
		}

		if ( self::looks_like_storage_entries_array( $decoded ) ) {
			$normalized = self::normalize_entries_array( $decoded, $previous );
			return wp_json_encode( array_values( $normalized ) );
		}

		if ( self::looks_like_ui_entries_array( $decoded ) ) {
			return self::sanitize_entries_from_ui_rows( $decoded, $previous );
		}

		return self::sanitize_entries_from_legacy_textarea( is_string( $value ) ? $value : '', $previous );
	}

	/**
	 * Dashboard rows for the password entries UI (never includes hashes).
	 *
	 * @param string $stored JSON string from options.
	 * @return array<int, array{id: string, label: string, enabled: string, hasPassword: bool}>
	 */
	public static function entries_for_dashboard_ui( string $stored ): array {
		$entries = self::decode_entries_json( $stored );
		$out     = array();

		foreach ( $entries as $entry ) {
			$out[] = array(
				'id'          => isset( $entry['id'] ) ? (string) $entry['id'] : '',
				'label'       => isset( $entry['label'] ) ? (string) $entry['label'] : '',
				'enabled'     => ( isset( $entry['enabled'] ) && 'on' === $entry['enabled'] ) ? 'on' : 'off',
				'hasPassword' => ! empty( $entry['hash'] ),
			);
		}

		return $out;
	}

	/**
	 * Format stored entries for the legacy settings textarea (never expose hashes).
	 *
	 * @param string $stored JSON string.
	 * @return string
	 */
	public static function entries_to_editor_value( string $stored ): string {
		$entries = self::decode_entries_json( $stored );
		if ( array() === $entries ) {
			return '';
		}

		$lines = array();
		foreach ( $entries as $entry ) {
			$id      = isset( $entry['id'] ) ? (string) $entry['id'] : '';
			$label   = isset( $entry['label'] ) ? (string) $entry['label'] : '';
			$enabled = isset( $entry['enabled'] ) && 'on' === $entry['enabled'] ? 'on' : 'off';
			$lines[] = sprintf( '%s | %s | %s | %s', $id, $label, self::KEEP_TOKEN, $enabled );
		}

		return implode( "\n", $lines );
	}

	/**
	 * Sanitize UI rows into stored JSON.
	 *
	 * @param array<int, mixed>                                                           $rows     UI rows.
	 * @param array<int, array{id: string, label: string, hash: string, enabled: string}> $previous Previous entries.
	 * @return string
	 */
	private static function sanitize_entries_from_ui_rows( array $rows, array $previous ): string {
		$prev_by_id = array();
		foreach ( $previous as $entry ) {
			if ( isset( $entry['id'] ) && is_string( $entry['id'] ) && '' !== $entry['id'] ) {
				$prev_by_id[ $entry['id'] ] = $entry;
			}
		}

		$out = array();

		foreach ( $rows as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}

			$id       = isset( $row['id'] ) ? sanitize_key( (string) $row['id'] ) : '';
			$label    = isset( $row['label'] ) ? sanitize_text_field( (string) $row['label'] ) : '';
			$password = isset( $row['password'] ) ? (string) $row['password'] : '';
			$enabled  = ( isset( $row['enabled'] ) && 'on' === $row['enabled'] ) ? 'on' : 'off';

			// Client may send temporary ids for new rows.
			if ( '' !== $id && 0 === strpos( $id, 'new' ) ) {
				$id = '';
			}

			if ( '' === $label ) {
				continue;
			}

			$hash = '';
			if ( '' !== $password ) {
				$hash = wp_hash_password( $password );
			} elseif ( '' !== $id && isset( $prev_by_id[ $id ]['hash'] ) ) {
				$hash = (string) $prev_by_id[ $id ]['hash'];
			} else {
				// New row without a password — skip.
				continue;
			}

			if ( '' === $id || ! isset( $prev_by_id[ $id ] ) ) {
				$id = self::generate_entry_id();
			}

			$out[] = array(
				'id'      => $id,
				'label'   => $label,
				'hash'    => $hash,
				'enabled' => $enabled,
			);
		}

		return wp_json_encode( array_values( $out ) );
	}

	/**
	 * Legacy pipe-delimited textarea parser.
	 *
	 * @param string                                                                      $text     Raw textarea.
	 * @param array<int, array{id: string, label: string, hash: string, enabled: string}> $previous Previous entries.
	 * @return string
	 */
	private static function sanitize_entries_from_legacy_textarea( string $text, array $previous ): string {
		$lines = preg_split( '/\r\n|\r|\n/', sanitize_textarea_field( $text ) );
		if ( ! is_array( $lines ) ) {
			$lines = array();
		}

		$prev_by_id = array();
		foreach ( $previous as $entry ) {
			if ( isset( $entry['id'] ) && is_string( $entry['id'] ) && '' !== $entry['id'] ) {
				$prev_by_id[ $entry['id'] ] = $entry;
			}
		}

		$out = array();

		foreach ( $lines as $line ) {
			$line = trim( (string) $line );
			if ( '' === $line || 0 === strpos( $line, '#' ) ) {
				continue;
			}

			$parts = array_map( 'trim', explode( '|', $line ) );
			if ( count( $parts ) < 3 ) {
				continue;
			}

			if ( 3 === count( $parts ) ) {
				$id       = '';
				$label    = $parts[0];
				$password = $parts[1];
				$enabled  = $parts[2];
			} else {
				$id       = $parts[0];
				$label    = $parts[1];
				$password = $parts[2];
				$enabled  = $parts[3];
			}

			$label   = sanitize_text_field( $label );
			$enabled = ( 'on' === strtolower( $enabled ) || '1' === $enabled || 'yes' === strtolower( $enabled ) ) ? 'on' : 'off';

			if ( '' === $label ) {
				continue;
			}

			$hash = '';
			if ( self::KEEP_TOKEN === strtoupper( $password ) && '' !== $id && isset( $prev_by_id[ $id ]['hash'] ) ) {
				$hash = (string) $prev_by_id[ $id ]['hash'];
			} elseif ( '' !== $password && self::KEEP_TOKEN !== strtoupper( $password ) ) {
				$hash = wp_hash_password( $password );
			} elseif ( '' !== $id && isset( $prev_by_id[ $id ]['hash'] ) ) {
				$hash = (string) $prev_by_id[ $id ]['hash'];
			} else {
				continue;
			}

			if ( '' === $id || ! isset( $prev_by_id[ $id ] ) ) {
				$id = self::generate_entry_id();
			}

			$out[] = array(
				'id'      => $id,
				'label'   => $label,
				'hash'    => $hash,
				'enabled' => $enabled,
			);
		}

		return wp_json_encode( array_values( $out ) );
	}

	/**
	 * Whether decoded JSON is already stored shape (has hashes).
	 *
	 * @param array<int, mixed> $decoded Decoded.
	 * @return bool
	 */
	private static function looks_like_storage_entries_array( array $decoded ): bool {
		if ( array() === $decoded ) {
			return false;
		}
		$first = reset( $decoded );
		return is_array( $first ) && isset( $first['hash'] ) && is_string( $first['hash'] ) && '' !== $first['hash'];
	}

	/**
	 * Whether decoded JSON is dashboard UI payload.
	 *
	 * @param array<int, mixed> $decoded Decoded.
	 * @return bool
	 */
	private static function looks_like_ui_entries_array( array $decoded ): bool {
		if ( array() === $decoded ) {
			return true;
		}
		$first = reset( $decoded );
		return is_array( $first ) && ( array_key_exists( 'password', $first ) || array_key_exists( 'label', $first ) ) && ! isset( $first['hash'] );
	}

	/**
	 * Normalize Protection options after AJAX merge (entries + version + IP).
	 *
	 * @param array<string, mixed> $options Section options.
	 * @return array<string, mixed>
	 */
	public static function normalize_options_after_save( array $options ): array {
		$previous_entries = self::get_stored_entries();
		$previous_json    = wp_json_encode( array_values( $previous_entries ) );

		if ( isset( $options[ self::OPTION_ENTRIES ] ) ) {
			$options[ self::OPTION_ENTRIES ] = self::sanitize_entries_option( $options[ self::OPTION_ENTRIES ] );
		} else {
			$options[ self::OPTION_ENTRIES ] = $previous_json ? $previous_json : '[]';
		}

		if ( isset( $options[ self::OPTION_IP_ALLOWLIST ] ) ) {
			$options[ self::OPTION_IP_ALLOWLIST ] = self::sanitize_ip_allowlist_option( $options[ self::OPTION_IP_ALLOWLIST ] );
		}

		if ( isset( $options[ self::OPTION_LAYOUT_ID ] ) ) {
			$options[ self::OPTION_LAYOUT_ID ] = self::sanitize_layout_option( $options[ self::OPTION_LAYOUT_ID ] );
		}

		if ( isset( $options[ self::OPTION_COOKIE_TTL_DAYS ] ) ) {
			$options[ self::OPTION_COOKIE_TTL_DAYS ] = self::sanitize_cookie_ttl_option( $options[ self::OPTION_COOKIE_TTL_DAYS ] );
		}

		if ( isset( $options[ self::OPTION_BYPASS_MODE ] ) ) {
			$options[ self::OPTION_BYPASS_MODE ] = self::sanitize_bypass_mode_option( $options[ self::OPTION_BYPASS_MODE ] );
		} else {
			$options[ self::OPTION_BYPASS_MODE ] = self::get_sitewide_bypass_mode();
		}

		$posted_roles = self::sanitize_bypass_roles_option(
			$options[ self::OPTION_BYPASS_ROLES ] ?? array()
		);
		// Roles UI is hidden unless mode=roles; preserve prior selections when not submitted.
		if ( 'roles' !== $options[ self::OPTION_BYPASS_MODE ] && array() === $posted_roles ) {
			$previous_options                     = get_option( self::OPTION_SECTION, array() );
			$previous_roles                       = ( is_array( $previous_options ) && isset( $previous_options[ self::OPTION_BYPASS_ROLES ] ) )
				? $previous_options[ self::OPTION_BYPASS_ROLES ]
				: array();
			$options[ self::OPTION_BYPASS_ROLES ] = self::sanitize_bypass_roles_option( $previous_roles );
		} else {
			$options[ self::OPTION_BYPASS_ROLES ] = $posted_roles;
		}

		// Keep legacy checkbox in sync for any older readers.
		$options[ self::OPTION_BYPASS_LOGGED_IN ] = ( 'logged_in' === $options[ self::OPTION_BYPASS_MODE ] )
			? 'on'
			: 'off';

		$new_json = isset( $options[ self::OPTION_ENTRIES ] ) ? (string) $options[ self::OPTION_ENTRIES ] : '[]';
		if ( $new_json !== (string) $previous_json ) {
			$version                              = absint( self::get_option_raw( self::OPTION_LIST_VERSION, '1' ) );
			$options[ self::OPTION_LIST_VERSION ] = (string) max( 1, $version + 1 );
		} elseif ( ! isset( $options[ self::OPTION_LIST_VERSION ] ) ) {
			$options[ self::OPTION_LIST_VERSION ] = (string) max( 1, absint( self::get_option_raw( self::OPTION_LIST_VERSION, '1' ) ) );
		}

		return $options;
	}

	/**
	 * Human-readable status for the settings dashboard.
	 *
	 * @return array{status: string, label: string, description: string, tone: string}
	 */
	public function get_status_for_settings(): array {
		$enabled = $this->is_enabled();
		$entries = self::get_stored_entries();
		$active  = 0;
		foreach ( $entries as $entry ) {
			if ( isset( $entry['enabled'] ) && 'on' === $entry['enabled'] && ! empty( $entry['hash'] ) ) {
				++$active;
			}
		}

		$mm_active = $this->is_maintenance_mode_serving();

		if ( ! $enabled ) {
			return array(
				'status'      => 'off',
				'label'       => __( 'Password Protection is off', 'dsm-supreme-modules-pro-for-divi' ),
				'description' => __( 'Sitewide Password Protection is disabled. You can still protect individual pages from the editor sidebar (Divi Supreme Password Protection).', 'dsm-supreme-modules-pro-for-divi' ),
				'tone'        => 'neutral',
			);
		}

		if ( $mm_active ) {
			return array(
				'status'      => 'deferred',
				'label'       => __( 'Password Protection is paused (Maintenance Mode)', 'dsm-supreme-modules-pro-for-divi' ),
				'description' => __( 'Maintenance Mode is currently serving visitors, so Password Protection does not run until Maintenance ends.', 'dsm-supreme-modules-pro-for-divi' ),
				'tone'        => 'warning',
			);
		}

		if ( $active < 1 ) {
			return array(
				'status'      => 'incomplete',
				'label'       => __( 'Password Protection is on — no passwords', 'dsm-supreme-modules-pro-for-divi' ),
				'description' => __( 'Password Protection is enabled but no enabled passwords are configured. Visitors will not be gated until you add one.', 'dsm-supreme-modules-pro-for-divi' ),
				'tone'        => 'warning',
			);
		}

		return array(
			'status'      => 'active',
			'label'       => __( 'Password Protection is on', 'dsm-supreme-modules-pro-for-divi' ),
			'tone'        => 'success',
			'description' => sprintf(
				/* translators: %d: number of enabled passwords */
				_n(
					'Sitewide Password Protection is on. %d password can unlock the site (plus IP allowlist bypasses).',
					'Sitewide Password Protection is on. %d passwords can unlock the site (plus IP allowlist bypasses).',
					$active,
					'dsm-supreme-modules-pro-for-divi'
				),
				$active
			),
		);
	}

	/**
	 * Whether the master Enable toggle is on.
	 *
	 * @return bool
	 */
	public function is_enabled(): bool {
		return 'on' === $this->get_section_option( self::OPTION_ENABLED, 'off' );
	}

	/**
	 * Whether the current visitor is unlocked via cookie.
	 *
	 * @return bool
	 */
	public function is_unlocked(): bool {
		$unlocked = $this->cookie_is_valid();

		/**
		 * Filters whether the current request is considered unlocked for Protection.
		 *
		 * @param bool $unlocked Whether unlocked.
		 */
		return (bool) apply_filters( 'dsm_password_protection_is_unlocked', $unlocked );
	}

	/**
	 * Assigned Divi Library layout ID (0 when none / invalid).
	 *
	 * @return int
	 */
	public function get_layout_id(): int {
		$raw = $this->get_section_option( self::OPTION_LAYOUT_ID, 'none' );
		$id  = DiviLibraryLayoutRenderer::normalize_post_id( $raw );

		/**
		 * Filters the Password Protection library layout post ID.
		 *
		 * @param int $id Layout post ID (0 = none).
		 */
		return (int) apply_filters( 'dsm_password_protection_layout_id', $id );
	}

	/**
	 * Handle unlock POST (frontend form / module).
	 *
	 * @return void
	 */
	public function maybe_handle_unlock_request(): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified immediately below after action gate.
		$action = isset( $_POST['dsm_pp_action'] ) ? sanitize_text_field( wp_unslash( $_POST['dsm_pp_action'] ) ) : '';
		if ( self::POST_ACTION !== $action ) {
			return;
		}

		$nonce = isset( $_POST['dsm_pp_nonce'] ) ? sanitize_text_field( wp_unslash( (string) $_POST['dsm_pp_nonce'] ) ) : '';
		if ( ! wp_verify_nonce( $nonce, 'dsm_password_protection_unlock' ) ) {
			$this->redirect_with_error( 'nonce' );
		}

		if ( $this->is_rate_limited() ) {
			$this->redirect_with_error( 'rate' );
		}

		$password = isset( $_POST['dsm_pp_password'] ) ? sanitize_text_field( wp_unslash( $_POST['dsm_pp_password'] ) ) : '';
		if ( '' === $password ) {
			$this->record_failed_attempt();
			$this->redirect_with_error( 'empty' );
		}

		$scope     = isset( $_POST['dsm_pp_scope'] ) ? sanitize_key( wp_unslash( (string) $_POST['dsm_pp_scope'] ) ) : 'sitewide';
		$post_id   = isset( $_POST['dsm_pp_post_id'] ) ? absint( wp_unslash( (string) $_POST['dsm_pp_post_id'] ) ) : 0;
		$target_id = isset( $_POST['dsm_pp_target_id'] ) ? sanitize_key( wp_unslash( (string) $_POST['dsm_pp_target_id'] ) ) : '';

		if ( 'block' === $scope && '' !== $target_id ) {
			$lookup_post_id = $post_id > 0 ? $post_id : (int) get_queried_object_id();
			if ( $lookup_post_id <= 0 && isset( $_POST['dsm_pp_redirect'] ) ) {
				$redirect_probe = esc_url_raw( wp_unslash( (string) $_POST['dsm_pp_redirect'] ) );
				$lookup_post_id = (int) url_to_postid( $redirect_probe );
			}

			$found = PasswordProtectionBlock::lookup_target_on_post( $lookup_post_id, $target_id );
			$ok    = false;
			if ( null !== $found ) {
				if ( ! empty( $found['attrs'] ) && is_array( $found['attrs'] ) ) {
					$ok = PasswordProtectionBlock::password_matches_attrs( $password, $found['attrs'], $this );
				} elseif ( ! empty( $found['entries'] ) && is_array( $found['entries'] ) ) {
					$ok = $this->password_matches_entries( $password, $found['entries'] );
				}
			}
			if ( ! $ok ) {
				$this->record_failed_attempt();
				$this->redirect_with_error( 'invalid' );
			}
			$this->clear_failed_attempts();
			$this->set_block_unlock_cookie( $target_id, $found['version'] );
		} elseif ( 'page' === $scope && $post_id > 0 ) {
			if (
				! $this->is_extension_enabled()
				|| ! self::is_page_protection_enabled( $post_id )
				|| ! $this->password_matches_page_entries( $password, $post_id )
			) {
				$this->record_failed_attempt();
				$this->redirect_with_error( 'invalid' );
			}
			$this->clear_failed_attempts();
			$this->set_page_unlock_cookie( $post_id );
		} else {
			if ( ! $this->password_matches_any_enabled( $password ) ) {
				$this->record_failed_attempt();
				$this->redirect_with_error( 'invalid' );
			}
			$this->clear_failed_attempts();
			$this->set_unlock_cookie();
		}

		$redirect = isset( $_POST['dsm_pp_redirect'] ) ? esc_url_raw( wp_unslash( (string) $_POST['dsm_pp_redirect'] ) ) : '';
		if ( '' === $redirect ) {
			$redirect = home_url( '/' );
		}

		wp_safe_redirect( $redirect );
		exit;
	}

	/**
	 * Swap the main query to the assigned Library layout when gating.
	 *
	 * @param \WP_Query $query Query.
	 * @return void
	 */
	public function maybe_hijack_main_query( $query ): void {
		if ( ! $query instanceof \WP_Query || ! $query->is_main_query() ) {
			return;
		}

		if ( is_admin() || ! $this->should_intercept_frontend( $query ) ) {
			return;
		}

		$layout_id = $this->get_layout_id();
		if ( $layout_id <= 0 || ! $this->is_layout_servable( $layout_id ) ) {
			return;
		}

		$layout_type = defined( 'ET_BUILDER_LAYOUT_POST_TYPE' ) ? ET_BUILDER_LAYOUT_POST_TYPE : 'et_pb_layout';

		$query->set( 'post_type', $layout_type );
		$query->set( 'p', $layout_id );
		$query->set( 'page_id', 0 );
		$query->set( 'pagename', '' );
		$query->set( 'name', '' );
		$query->set( 'post_status', 'publish' );
		$query->set( 'posts_per_page', 1 );
		$query->set( 'ignore_sticky_posts', true );

		$query->is_home              = false;
		$query->is_front_page        = false;
		$query->is_posts_page        = false;
		$query->is_singular          = true;
		$query->is_single            = true;
		$query->is_page              = false;
		$query->is_archive           = false;
		$query->is_category          = false;
		$query->is_tag               = false;
		$query->is_tax               = false;
		$query->is_author            = false;
		$query->is_date              = false;
		$query->is_search            = false;
		$query->is_404               = false;
		$query->is_post_type_archive = false;

		$this->query_hijacked     = true;
		$this->hijacked_layout_id = $layout_id;
	}

	/**
	 * Use the Protection blank template when the query was hijacked.
	 *
	 * @param string $template Template path.
	 * @return string
	 */
	public function maybe_use_protection_template( string $template ): string {
		if ( ! $this->query_hijacked ) {
			return $template;
		}

		$path = __DIR__ . '/templates/password-protection.php';
		if ( is_readable( $path ) ) {
			return $path;
		}

		return $template;
	}

	/**
	 * Send 401 + nocache headers, or serve fallback form when no layout.
	 *
	 * @return void
	 */
	public function maybe_send_headers_or_fallback(): void {
		if ( ! $this->should_intercept_frontend() ) {
			return;
		}

		status_header( 401 );
		nocache_headers();

		if ( $this->query_hijacked ) {
			return;
		}

		$this->render_fallback_page();
		exit;
	}

	/**
	 * Body classes for Library gate pages.
	 *
	 * @param string[] $classes Body classes.
	 * @return string[]
	 */
	public function filter_body_class( array $classes ): array {
		if ( ! $this->query_hijacked ) {
			return $classes;
		}

		$classes[] = 'dsm-password-protection';
		$classes[] = 'et_pb_pagebuilder_layout';
		$classes[] = 'et_no_sidebar';
		$classes[] = 'et-db';

		return array_values( array_unique( $classes ) );
	}

	/**
	 * Admin bar notice when sitewide Protection is enabled.
	 *
	 * @param \WP_Admin_Bar $wp_admin_bar Admin bar.
	 * @return void
	 */
	public function maybe_add_admin_bar_notice( $wp_admin_bar ): void {
		if ( ! $this->is_enabled() || ! current_user_can( 'manage_options' ) ) {
			return;
		}

		if ( ! $wp_admin_bar instanceof \WP_Admin_Bar ) {
			return;
		}

		$status_info = $this->get_status_for_settings();

		$wp_admin_bar->add_node(
			array(
				'id'    => 'dsm-password-protection',
				'title' => esc_html__( 'Protection ON', 'dsm-supreme-modules-pro-for-divi' ),
				'href'  => esc_url(
					admin_url( 'admin.php?page=divi_supreme_settings&tab=dsm_settings_protection' )
				),
				'meta'  => array(
					'class' => 'dsm-password-protection-admin-bar dsm-password-protection-admin-bar--' . sanitize_html_class( $status_info['status'] ),
					'title' => esc_attr( $status_info['description'] ),
				),
			)
		);
	}

	/**
	 * Shortcode / shared markup for the Password Form.
	 *
	 * @param array<string, mixed>|string $atts Shortcode attributes.
	 * @return string
	 */
	public function render_password_form_shortcode( $atts = array() ): string {
		$atts = shortcode_atts(
			array(
				'title'       => __( 'This site is password protected', 'dsm-supreme-modules-pro-for-divi' ),
				'button_text' => __( 'Unlock', 'dsm-supreme-modules-pro-for-divi' ),
				'placeholder' => __( 'Enter password', 'dsm-supreme-modules-pro-for-divi' ),
			),
			is_array( $atts ) ? $atts : array(),
			'dsm_password_form'
		);

		return self::render_password_form_html(
			(string) $atts['title'],
			(string) $atts['button_text'],
			(string) $atts['placeholder'],
			$this->get_form_scope(),
			$this->get_form_post_id()
		);
	}

	/**
	 * Active gate scope for Password Form markup.
	 *
	 * @return string `sitewide`|`page`
	 */
	public function get_form_scope(): string {
		return 'page' === $this->gate_mode ? 'page' : 'sitewide';
	}

	/**
	 * Active gate post ID for Password Form markup (0 when sitewide).
	 *
	 * @return int
	 */
	public function get_form_post_id(): int {
		return 'page' === $this->gate_mode ? $this->gate_post_id : 0;
	}

	/**
	 * Shared password form HTML (module + shortcode + fallback + block gate).
	 *
	 * @param string               $title               Heading text (may be empty).
	 * @param string               $button_text         Submit label.
	 * @param string               $placeholder         Input placeholder.
	 * @param string               $scope               `sitewide`, `page`, or `block`.
	 * @param int                  $post_id             Protected post ID when scope is page (also sent for block lookup).
	 * @param string               $layout              `inline` or `stacked` (module Design/Content layout).
	 * @param string               $alignment           Button alignment: `left`, `center`, or `right`.
	 * @param string               $target_id           Block target id when scope is `block`.
	 * @param array<string, mixed> $button_module_attrs Optional attrs with `button` key for `data-icon` (Card pattern).
	 * @return string
	 */
	public static function render_password_form_html( string $title, string $button_text, string $placeholder, string $scope = 'sitewide', int $post_id = 0, string $layout = 'stacked', string $alignment = 'left', string $target_id = '', array $button_module_attrs = array() ): string {
		$error_code = isset( $_GET['dsm_pp_error'] ) ? sanitize_key( wp_unslash( (string) $_GET['dsm_pp_error'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only display.
		$error_msg  = '';
		if ( 'invalid' === $error_code || 'empty' === $error_code ) {
			$error_msg = __( 'Incorrect password. Please try again.', 'dsm-supreme-modules-pro-for-divi' );
		} elseif ( 'rate' === $error_code ) {
			$error_msg = __( 'Too many attempts. Please wait a few minutes and try again.', 'dsm-supreme-modules-pro-for-divi' );
		} elseif ( 'nonce' === $error_code ) {
			$error_msg = __( 'Your session expired. Please try again.', 'dsm-supreme-modules-pro-for-divi' );
		}

		if ( '' === $title && 'page' === $scope ) {
			$title = __( 'This page is password protected', 'dsm-supreme-modules-pro-for-divi' );
		}
		if ( '' === $title && 'block' === $scope ) {
			$title = __( 'This content is password protected', 'dsm-supreme-modules-pro-for-divi' );
		}

		$redirect = ( is_ssl() ? 'https://' : 'http://' ) . ( isset( $_SERVER['HTTP_HOST'] ) ? sanitize_text_field( wp_unslash( (string) $_SERVER['HTTP_HOST'] ) ) : '' );
		$uri      = isset( $_SERVER['REQUEST_URI'] ) ? esc_url_raw( wp_unslash( (string) $_SERVER['REQUEST_URI'] ) ) : '/';
		$path     = (string) wp_parse_url( $uri, PHP_URL_PATH );
		$query    = (string) wp_parse_url( $uri, PHP_URL_QUERY );
		$redirect = $redirect . ( '' !== $path ? $path : '/' );
		if ( '' !== $query ) {
			parse_str( $query, $qargs );
			unset( $qargs['dsm_pp_error'] );
			if ( array() !== $qargs ) {
				$redirect .= '?' . http_build_query( $qargs );
			}
		}

		$scope = sanitize_key( $scope );
		if ( ! in_array( $scope, array( 'sitewide', 'page', 'block' ), true ) ) {
			$scope = 'sitewide';
		}
		$target_id = sanitize_key( $target_id );
		if ( 'block' === $scope && $post_id <= 0 ) {
			$post_id = (int) get_queried_object_id();
		}

		$layout    = 'inline' === sanitize_key( $layout ) ? 'inline' : 'stacked';
		$alignment = sanitize_key( $alignment );
		if ( ! in_array( $alignment, array( 'left', 'center', 'right' ), true ) ) {
			$alignment = 'left';
		}

		$input_id   = 'block' === $scope && '' !== $target_id
			? 'dsm-pp-password-' . $target_id
			: 'dsm-pp-password';
		$root_class = 'dsm-password-form dsm-password-form--' . $layout;
		$form_class = 'dsm-password-form__form dsm-password-form__form--align-' . $alignment;

		ob_start();
		?>
		<div class="<?php echo esc_attr( $root_class ); ?>">
			<?php if ( '' !== trim( $title ) ) : ?>
				<h2 class="dsm-password-form__title"><?php echo esc_html( $title ); ?></h2>
			<?php endif; ?>
			<?php if ( '' !== $error_msg ) : ?>
				<p class="dsm-password-form__error" role="alert"><?php echo esc_html( $error_msg ); ?></p>
			<?php endif; ?>
			<form class="<?php echo esc_attr( $form_class ); ?>" method="post" action="">
				<input type="hidden" name="dsm_pp_action" value="<?php echo esc_attr( self::POST_ACTION ); ?>" />
				<input type="hidden" name="dsm_pp_nonce" value="<?php echo esc_attr( wp_create_nonce( 'dsm_password_protection_unlock' ) ); ?>" />
				<input type="hidden" name="dsm_pp_redirect" value="<?php echo esc_url( $redirect ); ?>" />
				<input type="hidden" name="dsm_pp_scope" value="<?php echo esc_attr( $scope ); ?>" />
				<input type="hidden" name="dsm_pp_post_id" value="<?php echo esc_attr( (string) max( 0, $post_id ) ); ?>" />
				<?php if ( 'block' === $scope && '' !== $target_id ) : ?>
					<input type="hidden" name="dsm_pp_target_id" value="<?php echo esc_attr( $target_id ); ?>" />
				<?php endif; ?>
				<label class="dsm-password-form__label screen-reader-text" for="<?php echo esc_attr( $input_id ); ?>"><?php echo esc_html( $placeholder ); ?></label>
				<input
					class="input dsm-password-form__input"
					id="<?php echo esc_attr( $input_id ); ?>"
					type="password"
					name="dsm_pp_password"
					placeholder="<?php echo esc_attr( $placeholder ); ?>"
					autocomplete="current-password"
					required
				/>
				<?php
				$button_icon_html = self::render_button_icon_data_attributes_html( $button_module_attrs );
				$button_class     = '' !== trim( $button_icon_html )
					? 'et_pb_button et_pb_bg_layout_light et_pb_custom_button_icon dsm-password-form__submit'
					: 'et_pb_button et_pb_bg_layout_light dsm-password-form__submit';
				?>
				<button class="<?php echo esc_attr( $button_class ); ?>" type="submit"<?php echo $button_icon_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in helper. ?>><?php echo esc_html( $button_text ); ?></button>
			</form>
		</div>
		<?php
		return (string) ob_get_clean();
	}

	/**
	 * Space-prefixed `data-icon` / `data-icon-*` for the submit button (matches core ButtonModule).
	 *
	 * @param array<string, mixed> $attrs Attrs containing a `button` key (or empty).
	 * @return string HTML attribute fragment (leading space), or empty string.
	 */
	private static function render_button_icon_data_attributes_html( array $attrs ): string {
		$button = $attrs['button'] ?? null;
		if ( ! is_array( $button ) ) {
			return '';
		}

		$icon_enable_raw   = $button['decoration']['button']['desktop']['value']['icon']['enable'] ?? 'on';
		$is_icon_enabled   = 'off' !== strtolower( (string) $icon_enable_raw );
		$button_decoration = $button['decoration']['button'] ?? array();
		if ( ! is_array( $button_decoration ) || ! $is_icon_enabled ) {
			return '';
		}

		if ( ! class_exists( Utils::class ) ) {
			return '';
		}

		$parts = array();
		foreach ( $button_decoration as $breakpoint => $breakpoint_value ) {
			if ( ! is_array( $breakpoint_value ) ) {
				continue;
			}
			$icon_settings = $breakpoint_value['value']['icon']['settings'] ?? null;
			if ( ! isset( $icon_settings ) || ! is_array( $icon_settings ) ) {
				continue;
			}
			$processed_icon = Utils::process_font_icon( $icon_settings );
			if ( '' === $processed_icon || null === $processed_icon ) {
				continue;
			}
			$bp = is_string( $breakpoint ) ? $breakpoint : (string) $breakpoint;
			if ( 'desktop' === $bp ) {
				$data_attr_name = 'data-icon';
			} else {
				$data_attr_name = 'data-icon-' . strtolower( (string) preg_replace( '/([A-Z])/', '-$1', $bp ) );
			}
			$parts[] = sprintf( '%s="%s"', esc_attr( $data_attr_name ), esc_attr( (string) $processed_icon ) );
		}

		if ( array() === $parts ) {
			return '';
		}

		return ' ' . implode( ' ', $parts );
	}

	/**
	 * Whether this frontend request should see the Protection gate.
	 *
	 * @param \WP_Query|null $query Optional main query (pre_get_posts).
	 * @return bool
	 */
	private function should_intercept_frontend( $query = null ): bool {
		// Do not permanently cache "false" from early pre_get_posts before the singular post is known.
		if ( null !== $this->gate_should_intercept && true === $this->gate_should_intercept ) {
			return true;
		}

		$this->gate_mode    = '';
		$this->gate_post_id = 0;

		if ( $this->is_maintenance_mode_serving() ) {
			$this->gate_should_intercept = false;
			return false;
		}

		// System / admin / IP bypass (not sitewide or per-page user-group rules).
		if ( $this->should_bypass() ) {
			$this->gate_should_intercept = false;
			return false;
		}

		// 1) Sitewide gate.
		if (
			$this->is_enabled()
			&& $this->has_enabled_password()
			&& ! $this->user_bypasses_sitewide_gate()
			&& ! $this->is_unlocked()
		) {
			$this->gate_mode             = 'sitewide';
			$this->gate_should_intercept = true;
			return true;
		}

		// 2) Per-page gate (sitewide unlock / sitewide role bypass do not unlock the page).
		if ( $this->is_extension_enabled() ) {
			$post_id = $this->resolve_content_post_id( $query );
			if (
				$post_id > 0
				&& self::is_page_protection_enabled( $post_id )
				&& $this->page_has_enabled_password( $post_id )
				&& ! self::user_bypasses_page_gate( $post_id )
				&& ! $this->page_cookie_is_valid( $post_id )
			) {
				$this->gate_mode             = 'page';
				$this->gate_post_id          = $post_id;
				$this->gate_should_intercept = true;
				return true;
			}
		}

		$this->gate_should_intercept = false;
		return false;
	}

	/**
	 * Whether Maintenance Mode is currently serving visitors.
	 *
	 * @return bool
	 */
	private function is_maintenance_mode_serving(): bool {
		if (
			isset( $GLOBALS['dsm_maintenance_mode_extension'] )
			&& $GLOBALS['dsm_maintenance_mode_extension'] instanceof MaintenanceMode
		) {
			return $GLOBALS['dsm_maintenance_mode_extension']->is_currently_serving();
		}

		return false;
	}

	/**
	 * Whether the current request/user should skip the gate.
	 *
	 * @return bool
	 */
	private function should_bypass(): bool {
		$bypass = $this->should_bypass_unfiltered();

		/**
		 * Filters whether the current request bypasses Password Protection.
		 *
		 * @param bool $bypass Whether to bypass.
		 */
		return (bool) apply_filters( 'dsm_password_protection_should_bypass', $bypass );
	}

	/**
	 * Internal bypass rules (before filter).
	 *
	 * @return bool
	 */
	private function should_bypass_unfiltered(): bool {
		if ( is_admin() ) {
			return true;
		}

		if ( wp_doing_ajax() || wp_doing_cron() ) {
			return true;
		}

		if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
			return true;
		}

		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			return true;
		}

		if ( $this->is_login_or_system_request() ) {
			return true;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only presence checks.
		if ( isset( $_GET['et_fb'] ) || isset( $_GET['et_tb'] ) ) {
			return true;
		}

		if ( function_exists( 'et_core_is_fb_enabled' ) && et_core_is_fb_enabled() ) {
			return true;
		}

		if ( current_user_can( 'manage_options' ) ) {
			return true;
		}

		if ( $this->client_ip_is_allowlisted() ) {
			return true;
		}

		return false;
	}

	/**
	 * Login / feed / system endpoints that must stay reachable.
	 *
	 * @return bool
	 */
	private function is_login_or_system_request(): bool {
		if ( isset( $GLOBALS['pagenow'] ) && 'wp-login.php' === $GLOBALS['pagenow'] ) {
			return true;
		}

		$request_uri = isset( $_SERVER['REQUEST_URI'] )
			? esc_url_raw( wp_unslash( (string) $_SERVER['REQUEST_URI'] ) )
			: '';
		$path        = (string) wp_parse_url( $request_uri, PHP_URL_PATH );
		$login_path  = (string) wp_parse_url( wp_login_url(), PHP_URL_PATH );

		if ( '' !== $login_path && false !== strpos( $path, $login_path ) ) {
			return true;
		}

		if ( function_exists( 'is_feed' ) && did_action( 'parse_query' ) && is_feed() ) {
			return true;
		}

		if ( function_exists( 'is_robots' ) && did_action( 'parse_query' ) && is_robots() ) {
			return true;
		}

		if ( function_exists( 'is_favicon' ) && did_action( 'parse_query' ) && is_favicon() ) {
			return true;
		}

		return false;
	}

	/**
	 * Whether a library layout can be shown to visitors (published).
	 *
	 * @param int $layout_id Layout post ID.
	 * @return bool
	 */
	private function is_layout_servable( int $layout_id ): bool {
		$post = get_post( $layout_id );
		if ( ! $post instanceof \WP_Post ) {
			return false;
		}

		$layout_type = defined( 'ET_BUILDER_LAYOUT_POST_TYPE' ) ? ET_BUILDER_LAYOUT_POST_TYPE : 'et_pb_layout';
		if ( $layout_type !== $post->post_type ) {
			return false;
		}

		return 'publish' === $post->post_status;
	}

	/**
	 * Whether at least one enabled password exists.
	 *
	 * @return bool
	 */
	private function has_enabled_password(): bool {
		foreach ( self::get_stored_entries() as $entry ) {
			if ( isset( $entry['enabled'] ) && 'on' === $entry['enabled'] && ! empty( $entry['hash'] ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Check plaintext against any enabled password hash.
	 *
	 * @param string $password Plaintext password.
	 * @return bool
	 */
	private function password_matches_any_enabled( string $password ): bool {
		foreach ( self::get_stored_entries() as $entry ) {
			if ( ! isset( $entry['enabled'] ) || 'on' !== $entry['enabled'] ) {
				continue;
			}
			$hash = isset( $entry['hash'] ) ? (string) $entry['hash'] : '';
			if ( '' === $hash ) {
				continue;
			}
			if ( wp_check_password( $password, $hash ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Whether the unlock cookie is present and valid for the current list version.
	 *
	 * @return bool
	 */
	private function cookie_is_valid(): bool {
		if ( empty( $_COOKIE[ self::COOKIE_NAME ] ) ) {
			return false;
		}

		$raw   = sanitize_text_field( wp_unslash( (string) $_COOKIE[ self::COOKIE_NAME ] ) );
		$parts = explode( '|', $raw );
		if ( 3 !== count( $parts ) ) {
			return false;
		}

		list( $version, $expiry, $sig ) = $parts;
		$version                        = absint( $version );
		$expiry                         = absint( $expiry );

		if ( $version < 1 || $expiry < time() ) {
			return false;
		}

		$expected_version = absint( $this->get_section_option( self::OPTION_LIST_VERSION, '1' ) );
		if ( $version !== $expected_version ) {
			return false;
		}

		$payload  = $version . '|' . $expiry;
		$expected = hash_hmac( 'sha256', $payload, wp_salt( 'auth' ) );

		return hash_equals( $expected, $sig );
	}

	/**
	 * Set a signed HttpOnly unlock cookie.
	 *
	 * @return void
	 */
	private function set_unlock_cookie(): void {
		$days    = (int) self::sanitize_cookie_ttl_option( $this->get_section_option( self::OPTION_COOKIE_TTL_DAYS, '14' ) );
		$expiry  = time() + ( $days * DAY_IN_SECONDS );
		$version = max( 1, absint( $this->get_section_option( self::OPTION_LIST_VERSION, '1' ) ) );
		$payload = $version . '|' . $expiry;
		$sig     = hash_hmac( 'sha256', $payload, wp_salt( 'auth' ) );
		$value   = $payload . '|' . $sig;

		$secure   = is_ssl();
		$httponly = true;
		$path     = defined( 'COOKIEPATH' ) && COOKIEPATH ? COOKIEPATH : '/';
		$domain   = defined( 'COOKIE_DOMAIN' ) ? COOKIE_DOMAIN : '';

		if ( PHP_VERSION_ID >= 70300 ) {
			setcookie(
				self::COOKIE_NAME,
				$value,
				array(
					'expires'  => $expiry,
					'path'     => $path,
					'domain'   => $domain,
					'secure'   => $secure,
					'httponly' => $httponly,
					'samesite' => 'Lax',
				)
			);
		} else {
			setcookie( self::COOKIE_NAME, $value, $expiry, $path, $domain, $secure, $httponly );
		}

		$_COOKIE[ self::COOKIE_NAME ] = $value;
	}

	/**
	 * Whether the client IP matches the allowlist.
	 *
	 * @return bool
	 */
	private function client_ip_is_allowlisted(): bool {
		$raw = $this->get_section_option( self::OPTION_IP_ALLOWLIST, '' );
		if ( '' === trim( $raw ) ) {
			return false;
		}

		$ip = $this->get_client_ip();
		if ( '' === $ip ) {
			return false;
		}

		$lines = preg_split( '/\r\n|\r|\n/', $raw );
		if ( ! is_array( $lines ) ) {
			return false;
		}

		foreach ( $lines as $line ) {
			$line = trim( (string) $line );
			if ( '' === $line || 0 === strpos( $line, '#' ) ) {
				continue;
			}
			if ( self::ip_matches_rule( $ip, $line ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Best-effort client IP (respects common proxy headers only when trusted by host config — uses REMOTE_ADDR).
	 *
	 * @return string
	 */
	private function get_client_ip(): string {
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( (string) $_SERVER['REMOTE_ADDR'] ) ) : '';
		return filter_var( $ip, FILTER_VALIDATE_IP ) ? $ip : '';
	}

	/**
	 * Rate limit failed unlock attempts by IP.
	 *
	 * @return bool True when limited.
	 */
	private function is_rate_limited(): bool {
		$key   = $this->rate_limit_key();
		$count = (int) get_transient( $key );
		return $count >= 10;
	}

	/**
	 * Record a failed unlock attempt.
	 *
	 * @return void
	 */
	private function record_failed_attempt(): void {
		$key   = $this->rate_limit_key();
		$count = (int) get_transient( $key );
		set_transient( $key, $count + 1, 15 * MINUTE_IN_SECONDS );
	}

	/**
	 * Clear failed attempts after a successful unlock.
	 *
	 * @return void
	 */
	private function clear_failed_attempts(): void {
		delete_transient( $this->rate_limit_key() );
	}

	/**
	 * Transient key for rate limiting.
	 *
	 * @return string
	 */
	private function rate_limit_key(): string {
		$ip = $this->get_client_ip();
		return 'dsm_pp_rl_' . md5( '' !== $ip ? $ip : 'unknown' );
	}

	/**
	 * Redirect back with an error query arg.
	 *
	 * @param string $code Error code.
	 * @return void
	 */
	private function redirect_with_error( string $code ): void {
		$redirect = isset( $_POST['dsm_pp_redirect'] ) ? esc_url_raw( wp_unslash( (string) $_POST['dsm_pp_redirect'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified before callers reach here.
		if ( '' === $redirect ) {
			$redirect = home_url( '/' );
		}
		$redirect = add_query_arg( 'dsm_pp_error', sanitize_key( $code ), $redirect );
		wp_safe_redirect( $redirect );
		exit;
	}

	/**
	 * Fallback gate page when no Library layout is assigned.
	 *
	 * @return void
	 */
	private function render_fallback_page(): void {
		$title = get_bloginfo( 'name' );
		$scope = $this->get_form_scope();
		$form  = self::render_password_form_html(
			'page' === $scope
				? __( 'This page is password protected', 'dsm-supreme-modules-pro-for-divi' )
				: __( 'This site is password protected', 'dsm-supreme-modules-pro-for-divi' ),
			__( 'Unlock', 'dsm-supreme-modules-pro-for-divi' ),
			__( 'Enter password', 'dsm-supreme-modules-pro-for-divi' ),
			$scope,
			$this->get_form_post_id()
		);
		?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="robots" content="noindex, nofollow">
	<title><?php echo esc_html( (string) $title ); ?></title>
	<style>
		.dsm-password-protection-fallback{min-height:100vh;display:flex;align-items:center;justify-content:center;padding:2rem;font-family:system-ui,sans-serif;background:#f6f7f9;}
		.dsm-password-form{max-width:28rem;width:100%;background:#ffffff;padding:2rem;border-radius:12px;box-shadow:0px 8px 30px 0px rgba(0,0,0,0.08);box-sizing:border-box;text-align:left;}
		.dsm-password-form__title{margin:0 0 1.25rem;font-size:1.25rem;line-height:1.4;font-weight:600;color:#333;}
		.dsm-password-form__error{color:#b32d2e;margin:0 0 1rem;}
		.dsm-password-form__form{display:flex;gap:.75rem;align-items:stretch;}
		.dsm-password-form--stacked .dsm-password-form__form{flex-direction:column;}
		.dsm-password-form--inline .dsm-password-form__form{flex-direction:row;flex-wrap:nowrap;align-items:stretch;}
		.dsm-password-form input.input.dsm-password-form__input,.dsm-password-form input.dsm-password-form__input{flex:1 1 auto;min-width:0;max-width:100%;width:auto;box-sizing:border-box;-webkit-appearance:none;appearance:none;background-color:#eee;border:0;border-radius:0;color:#999;font-size:14px;padding:16px;}
		.dsm-password-form--stacked input.input.dsm-password-form__input,.dsm-password-form--stacked input.dsm-password-form__input{flex:0 0 auto;width:100%;}
		.dsm-password-form__submit.et_pb_button,.dsm-password-form__submit{flex:0 0 auto;margin:0;cursor:pointer;color:#2ea3f2;background:transparent;border:2px solid currentColor;border-radius:3px;padding:.3em 1em;font-size:20px;line-height:1.7em;font-family:inherit;box-sizing:border-box;position:relative;transition-duration:.2s;transition-property:all;}
		.dsm-password-form__submit.et_pb_button:hover,.dsm-password-form__submit:hover{padding:.3em 2em .3em .7em;}
		.et_button_icon_visible .dsm-password-form__submit.et_pb_button,.et_button_icon_visible .dsm-password-form__submit{padding-right:2em;padding-left:.7em;}
		.rtl .dsm-password-form__submit.et_pb_button:hover,.rtl .dsm-password-form__submit:hover{padding:.3em .7em .3em 2em;}
		.dsm-password-form--stacked .dsm-password-form__submit{align-self:flex-start;}
		.screen-reader-text{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);border:0;}
	</style>
		<?php wp_head(); ?>
</head>
<body <?php body_class( 'dsm-password-protection dsm-password-protection--fallback' ); ?>>
	<main class="dsm-password-protection-fallback">
		<?php echo $form; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built via escaped helpers in render_password_form_html(). ?>
	</main>
		<?php wp_footer(); ?>
</body>
</html>
		<?php
	}

	/**
	 * Read a Protection settings value.
	 *
	 * @param string $key           Option field name.
	 * @param string $default_value Default when missing.
	 * @return string
	 */
	private function get_section_option( string $key, string $default_value = '' ): string {
		return self::get_option_raw( $key, $default_value );
	}

	/**
	 * Static option reader.
	 *
	 * @param string $key           Option field name.
	 * @param string $default_value Default.
	 * @return string
	 */
	private static function get_option_raw( string $key, string $default_value = '' ): string {
		$options = get_option( self::OPTION_SECTION, array() );
		if ( ! is_array( $options ) || ! array_key_exists( $key, $options ) ) {
			return $default_value;
		}

		return is_scalar( $options[ $key ] ) ? (string) $options[ $key ] : $default_value;
	}

	/**
	 * Decoded password entries from storage.
	 *
	 * @return array<int, array{id: string, label: string, hash: string, enabled: string}>
	 */
	public static function get_stored_entries(): array {
		return self::decode_entries_json( self::get_option_raw( self::OPTION_ENTRIES, '[]' ) );
	}

	/**
	 * Decode entries JSON.
	 *
	 * @param string $json JSON string.
	 * @return array<int, array{id: string, label: string, hash: string, enabled: string}>
	 */
	private static function decode_entries_json( string $json ): array {
		$decoded = json_decode( $json, true );
		if ( ! is_array( $decoded ) ) {
			return array();
		}

		return self::normalize_entries_array( $decoded, array() );
	}

	/**
	 * Normalize a raw entries array.
	 *
	 * @param array<int, mixed>                                                               $decoded  Raw.
	 * @param array<int, array{id?: string, label?: string, hash?: string, enabled?: string}> $previous Previous for KEEP (unused here).
	 * @return array<int, array{id: string, label: string, hash: string, enabled: string}>
	 */
	private static function normalize_entries_array( array $decoded, array $previous ): array {
		unset( $previous );
		$out = array();
		foreach ( $decoded as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$id   = isset( $row['id'] ) ? sanitize_key( (string) $row['id'] ) : '';
			$hash = isset( $row['hash'] ) ? (string) $row['hash'] : '';
			if ( '' === $id || '' === $hash ) {
				continue;
			}
			$out[] = array(
				'id'      => $id,
				'label'   => isset( $row['label'] ) ? sanitize_text_field( (string) $row['label'] ) : '',
				'hash'    => $hash,
				'enabled' => ( isset( $row['enabled'] ) && 'on' === $row['enabled'] ) ? 'on' : 'off',
			);
		}
		return $out;
	}

	/**
	 * Generate a short entry id.
	 *
	 * @return string
	 */
	private static function generate_entry_id(): string {
		try {
			return substr( bin2hex( random_bytes( 8 ) ), 0, 12 );
		} catch ( \Exception $e ) {
			return substr( md5( uniqid( (string) wp_rand(), true ) ), 0, 12 );
		}
	}

	/**
	 * Validate IPv4/IPv6 or CIDR notation.
	 *
	 * @param string $value Candidate.
	 * @return bool
	 */
	private static function is_valid_ip_or_cidr( string $value ): bool {
		if ( false !== strpos( $value, '/' ) ) {
			$parts = explode( '/', $value, 2 );
			if ( 2 !== count( $parts ) ) {
				return false;
			}
			$ip     = $parts[0];
			$prefix = absint( $parts[1] );
			if ( ! filter_var( $ip, FILTER_VALIDATE_IP ) ) {
				return false;
			}
			$max = filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 ) ? 32 : 128;
			return $prefix >= 0 && $prefix <= $max;
		}

		return (bool) filter_var( $value, FILTER_VALIDATE_IP );
	}

	/**
	 * Whether an IP matches a single allowlist rule.
	 *
	 * @param string $ip   Client IP.
	 * @param string $rule IP or CIDR.
	 * @return bool
	 */
	private static function ip_matches_rule( string $ip, string $rule ): bool {
		if ( $ip === $rule ) {
			return true;
		}

		if ( false === strpos( $rule, '/' ) ) {
			return false;
		}

		list( $subnet, $prefix ) = array_pad( explode( '/', $rule, 2 ), 2, '' );
		$prefix                  = absint( $prefix );

		if ( filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 ) && filter_var( $subnet, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 ) ) {
			$ip_long     = ip2long( $ip );
			$subnet_long = ip2long( $subnet );
			if ( false === $ip_long || false === $subnet_long || $prefix < 0 || $prefix > 32 ) {
				return false;
			}
			$mask = 0 === $prefix ? 0 : ( -1 << ( 32 - $prefix ) );
			return ( $ip_long & $mask ) === ( $subnet_long & $mask );
		}

		if ( filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6 ) && filter_var( $subnet, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6 ) ) {
			$ip_bin     = inet_pton( $ip );
			$subnet_bin = inet_pton( $subnet );
			if ( false === $ip_bin || false === $subnet_bin || $prefix < 0 || $prefix > 128 ) {
				return false;
			}
			$bytes = intdiv( $prefix, 8 );
			$bits  = $prefix % 8;
			if ( $bytes > 0 && substr( $ip_bin, 0, $bytes ) !== substr( $subnet_bin, 0, $bytes ) ) {
				return false;
			}
			if ( 0 === $bits ) {
				return true;
			}
			$mask = chr( 0xFF << ( 8 - $bits ) );
			return ( $ip_bin[ $bytes ] & $mask ) === ( $subnet_bin[ $bytes ] & $mask );
		}

		return false;
	}

	/**
	 * Whether a post has per-page Protection enabled.
	 *
	 * @param int $post_id Post ID.
	 * @return bool
	 */
	public static function is_page_protection_enabled( int $post_id ): bool {
		if ( $post_id <= 0 ) {
			return false;
		}

		$enabled = 'on' === get_post_meta( $post_id, self::META_PAGE_ENABLED, true );

		/**
		 * Filters whether per-page Protection is enabled for a post.
		 *
		 * @param bool $enabled Whether enabled.
		 * @param int  $post_id Post ID.
		 */
		return (bool) apply_filters( 'dsm_password_protection_page_enabled', $enabled, $post_id );
	}

	/**
	 * Page password entries (hashed).
	 *
	 * @param int $post_id Post ID.
	 * @return array<int, array{id: string, label: string, hash: string, enabled: string}>
	 */
	public static function get_page_entries( int $post_id ): array {
		if ( $post_id <= 0 ) {
			return array();
		}

		$raw = get_post_meta( $post_id, self::META_PAGE_ENTRIES, true );
		return self::decode_entries_json( is_string( $raw ) ? $raw : '[]' );
	}

	/**
	 * Persist page entries from metabox POST rows and bump list version when needed.
	 *
	 * @param int               $post_id Post ID.
	 * @param array<int, mixed> $rows    Posted rows.
	 * @return void
	 */
	public static function save_page_entries_from_request( int $post_id, array $rows ): void {
		if ( $post_id <= 0 ) {
			return;
		}

		$ui_rows = array();
		foreach ( $rows as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$ui_rows[] = array(
				'id'       => isset( $row['id'] ) ? sanitize_key( (string) $row['id'] ) : '',
				'label'    => isset( $row['label'] ) ? sanitize_text_field( (string) $row['label'] ) : '',
				'password' => isset( $row['password'] ) ? (string) $row['password'] : '',
				'enabled'  => ( isset( $row['enabled'] ) && 'on' === $row['enabled'] ) ? 'on' : 'off',
			);
		}

		$previous  = self::get_page_entries( $post_id );
		$json      = self::sanitize_entries_option( wp_json_encode( $ui_rows ), $previous );
		$prev_json = wp_json_encode( array_values( $previous ) );

		update_post_meta( $post_id, self::META_PAGE_ENTRIES, $json );

		if ( $json !== (string) $prev_json ) {
			$version = absint( get_post_meta( $post_id, self::META_PAGE_LIST_VERSION, true ) );
			update_post_meta( $post_id, self::META_PAGE_LIST_VERSION, (string) max( 1, $version + 1 ) );
		} elseif ( '' === (string) get_post_meta( $post_id, self::META_PAGE_LIST_VERSION, true ) ) {
			update_post_meta( $post_id, self::META_PAGE_LIST_VERSION, '1' );
		}
	}

	/**
	 * Resolve the content post ID for the current request / query.
	 *
	 * @param \WP_Query|null $query Optional main query.
	 * @return int
	 */
	private function resolve_content_post_id( $query = null ): int {
		if ( $query instanceof \WP_Query ) {
			$page_id = absint( $query->get( 'page_id' ) );
			if ( $page_id > 0 ) {
				return $page_id;
			}

			$p = absint( $query->get( 'p' ) );
			if ( $p > 0 ) {
				return $p;
			}

			$pagename = (string) $query->get( 'pagename' );
			if ( '' !== $pagename ) {
				$page = get_page_by_path( $pagename );
				if ( $page instanceof \WP_Post ) {
					return (int) $page->ID;
				}
			}

			$name = (string) $query->get( 'name' );
			if ( '' !== $name ) {
				$post_type = $query->get( 'post_type' );
				$types     = is_array( $post_type ) ? $post_type : array( $post_type ? (string) $post_type : 'post' );
				$found     = get_posts(
					array(
						'name'             => $name,
						'post_type'        => $types,
						'post_status'      => 'publish',
						'posts_per_page'   => 1,
						'suppress_filters' => true,
					)
				);
				if ( isset( $found[0] ) && $found[0] instanceof \WP_Post ) {
					return (int) $found[0]->ID;
				}
			}

			// Front page often arrives as is_home/is_front_page without page_id early — skip unreliable guess here.

			return 0;
		}

		if ( did_action( 'wp' ) || did_action( 'template_redirect' ) || did_action( 'parse_query' ) ) {
			if ( function_exists( 'is_singular' ) && is_singular() ) {
				$qid = (int) get_queried_object_id();
				if ( $qid > 0 ) {
					return $qid;
				}
			}

			if ( function_exists( 'is_front_page' ) && is_front_page() && 'page' === get_option( 'show_on_front' ) ) {
				$front_id = absint( get_option( 'page_on_front' ) );
				if ( $front_id > 0 ) {
					return $front_id;
				}
			}
		}

		return 0;
	}

	/**
	 * Whether the page has at least one enabled password.
	 *
	 * @param int $post_id Post ID.
	 * @return bool
	 */
	private function page_has_enabled_password( int $post_id ): bool {
		foreach ( self::get_page_entries( $post_id ) as $entry ) {
			if ( isset( $entry['enabled'] ) && 'on' === $entry['enabled'] && ! empty( $entry['hash'] ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Match plaintext against enabled page passwords.
	 *
	 * @param string $password Plaintext.
	 * @param int    $post_id  Post ID.
	 * @return bool
	 */
	private function password_matches_page_entries( string $password, int $post_id ): bool {
		return $this->password_matches_entries( $password, self::get_page_entries( $post_id ) );
	}

	/**
	 * Match plaintext against a list of hashed entries.
	 *
	 * @param string                                                                          $password Plaintext.
	 * @param array<int, array{id?: string, label?: string, hash?: string, enabled?: string}> $entries Entries.
	 * @return bool
	 */
	public function password_matches_entries( string $password, array $entries ): bool {
		foreach ( $entries as $entry ) {
			if ( ! isset( $entry['enabled'] ) || 'on' !== $entry['enabled'] ) {
				continue;
			}
			$hash = isset( $entry['hash'] ) ? (string) $entry['hash'] : '';
			if ( '' !== $hash && wp_check_password( $password, $hash ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Whether a block unlock cookie is valid.
	 *
	 * @param string $target_id Target id.
	 * @param int    $version   Current list version.
	 * @return bool
	 */
	public function block_cookie_is_valid( string $target_id, int $version ): bool {
		$target_id = sanitize_key( $target_id );
		if ( '' === $target_id ) {
			return false;
		}

		$name = 'dsm_pp_block_' . $target_id;
		if ( empty( $_COOKIE[ $name ] ) ) {
			return false;
		}

		$raw   = sanitize_text_field( wp_unslash( (string) $_COOKIE[ $name ] ) );
		$parts = explode( '|', $raw );
		if ( 3 !== count( $parts ) ) {
			return false;
		}

		list( $cookie_version, $expiry, $sig ) = $parts;
		$cookie_version                        = absint( $cookie_version );
		$expiry                                = absint( $expiry );

		if ( $cookie_version < 1 || $expiry < time() ) {
			return false;
		}

		if ( max( 1, $version ) !== $cookie_version ) {
			return false;
		}

		$payload  = 'block|' . $target_id . '|' . $cookie_version . '|' . $expiry;
		$expected = hash_hmac( 'sha256', $payload, wp_salt( 'auth' ) );
		$unlocked = hash_equals( $expected, $sig );

		/**
		 * Filters whether a block target is unlocked for Protection.
		 *
		 * @param bool   $unlocked  Whether unlocked.
		 * @param string $target_id Target id.
		 */
		return (bool) apply_filters( 'dsm_password_protection_block_is_unlocked', $unlocked, $target_id );
	}

	/**
	 * Set signed HttpOnly unlock cookie for a block target.
	 *
	 * @param string $target_id Target id.
	 * @param int    $version   List version.
	 * @return void
	 */
	public function set_block_unlock_cookie( string $target_id, int $version ): void {
		$target_id = sanitize_key( $target_id );
		if ( '' === $target_id ) {
			return;
		}

		$days    = (int) self::sanitize_cookie_ttl_option( $this->get_section_option( self::OPTION_COOKIE_TTL_DAYS, '14' ) );
		$expiry  = time() + ( $days * DAY_IN_SECONDS );
		$version = max( 1, $version );
		$payload = 'block|' . $target_id . '|' . $version . '|' . $expiry;
		$sig     = hash_hmac( 'sha256', $payload, wp_salt( 'auth' ) );
		$value   = $version . '|' . $expiry . '|' . $sig;
		$name    = 'dsm_pp_block_' . $target_id;

		$secure   = is_ssl();
		$httponly = true;
		$path     = defined( 'COOKIEPATH' ) && COOKIEPATH ? COOKIEPATH : '/';
		$domain   = defined( 'COOKIE_DOMAIN' ) ? COOKIE_DOMAIN : '';

		if ( PHP_VERSION_ID >= 70300 ) {
			setcookie(
				$name,
				$value,
				array(
					'expires'  => $expiry,
					'path'     => $path,
					'domain'   => $domain,
					'secure'   => $secure,
					'httponly' => $httponly,
					'samesite' => 'Lax',
				)
			);
		} else {
			setcookie( $name, $value, $expiry, $path, $domain, $secure, $httponly );
		}

		$_COOKIE[ $name ] = $value;
	}

	/**
	 * Cookie name for a page unlock.
	 *
	 * @param int $post_id Post ID.
	 * @return string
	 */
	private function page_cookie_name( int $post_id ): string {
		return 'dsm_pp_page_' . absint( $post_id );
	}

	/**
	 * Whether the page unlock cookie is valid.
	 *
	 * @param int $post_id Post ID.
	 * @return bool
	 */
	private function page_cookie_is_valid( int $post_id ): bool {
		$name = $this->page_cookie_name( $post_id );
		if ( empty( $_COOKIE[ $name ] ) ) {
			return false;
		}

		$raw   = sanitize_text_field( wp_unslash( (string) $_COOKIE[ $name ] ) );
		$parts = explode( '|', $raw );
		if ( 3 !== count( $parts ) ) {
			return false;
		}

		list( $version, $expiry, $sig ) = $parts;
		$version                        = absint( $version );
		$expiry                         = absint( $expiry );

		if ( $version < 1 || $expiry < time() ) {
			return false;
		}

		$expected_version = max( 1, absint( get_post_meta( $post_id, self::META_PAGE_LIST_VERSION, true ) ) );
		if ( $version !== $expected_version ) {
			return false;
		}

		$payload  = 'page|' . $post_id . '|' . $version . '|' . $expiry;
		$expected = hash_hmac( 'sha256', $payload, wp_salt( 'auth' ) );

		$unlocked = hash_equals( $expected, $sig );

		/**
		 * Filters whether a page is unlocked for Protection.
		 *
		 * @param bool $unlocked Whether unlocked.
		 * @param int  $post_id  Post ID.
		 */
		return (bool) apply_filters( 'dsm_password_protection_page_is_unlocked', $unlocked, $post_id );
	}

	/**
	 * Set signed HttpOnly unlock cookie for a page.
	 *
	 * @param int $post_id Post ID.
	 * @return void
	 */
	private function set_page_unlock_cookie( int $post_id ): void {
		$days    = (int) self::sanitize_cookie_ttl_option( $this->get_section_option( self::OPTION_COOKIE_TTL_DAYS, '14' ) );
		$expiry  = time() + ( $days * DAY_IN_SECONDS );
		$version = max( 1, absint( get_post_meta( $post_id, self::META_PAGE_LIST_VERSION, true ) ) );
		$payload = 'page|' . $post_id . '|' . $version . '|' . $expiry;
		$sig     = hash_hmac( 'sha256', $payload, wp_salt( 'auth' ) );
		// Cookie value keeps 3 segments like sitewide: version|expiry|sig (post id is in HMAC payload via separate signing string).
		$value = $version . '|' . $expiry . '|' . $sig;
		$name  = $this->page_cookie_name( $post_id );

		$secure   = is_ssl();
		$httponly = true;
		$path     = defined( 'COOKIEPATH' ) && COOKIEPATH ? COOKIEPATH : '/';
		$domain   = defined( 'COOKIE_DOMAIN' ) ? COOKIE_DOMAIN : '';

		if ( PHP_VERSION_ID >= 70300 ) {
			setcookie(
				$name,
				$value,
				array(
					'expires'  => $expiry,
					'path'     => $path,
					'domain'   => $domain,
					'secure'   => $secure,
					'httponly' => $httponly,
					'samesite' => 'Lax',
				)
			);
		} else {
			setcookie( $name, $value, $expiry, $path, $domain, $secure, $httponly );
		}

		$_COOKIE[ $name ] = $value;
	}
}
