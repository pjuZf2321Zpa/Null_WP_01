<?php
/**
 * Maintenance Mode — serve a Divi Library layout to site visitors.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Extensions;

use DiviSupreme\Includes\DiviLibraryLayoutRenderer;
use DiviSupreme\Includes\DsmLibraryLayoutSelectOptions;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Site-wide maintenance gate powered by an assigned Divi Library layout.
 *
 * When a published layout is assigned, the main query is swapped to that
 * `et_pb_layout` post before Divi’s Dynamic Assets / Static CSS run on `wp`,
 * then a Divi-compatible blank template renders `#et-boc` + `the_content()`.
 */
class MaintenanceMode {

	/**
	 * Settings section option key (Miscellaneous).
	 */
	public const OPTION_SECTION = 'dsm_settings_misc';

	/**
	 * Option: enable flag (`on`|`off`).
	 */
	public const OPTION_ENABLED = 'dsm_maintenance_mode_enabled';

	/**
	 * Option: Divi Library layout post ID or `none`.
	 */
	public const OPTION_LAYOUT_ID = 'dsm_maintenance_mode_layout_id';

	/**
	 * Option: allow any logged-in user to bypass (`on`|`off`).
	 */
	public const OPTION_BYPASS_LOGGED_IN = 'dsm_maintenance_mode_bypass_logged_in';

	/**
	 * Option: HTTP status code (`503`|`200`).
	 */
	public const OPTION_HTTP_STATUS = 'dsm_maintenance_mode_http_status';

	/**
	 * Option: optional schedule start (`Y-m-d H:i` in site timezone, or empty).
	 */
	public const OPTION_START = 'dsm_maintenance_mode_start';

	/**
	 * Option: optional schedule end (`Y-m-d H:i` in site timezone, or empty = until turned off).
	 */
	public const OPTION_END = 'dsm_maintenance_mode_end';

	/**
	 * Schedule status: master toggle off.
	 */
	public const STATUS_OFF = 'off';

	/**
	 * Schedule status: enabled but start is in the future.
	 */
	public const STATUS_SCHEDULED = 'scheduled';

	/**
	 * Schedule status: currently serving visitors.
	 */
	public const STATUS_ACTIVE = 'active';

	/**
	 * Schedule status: enabled but end is in the past.
	 */
	public const STATUS_ENDED = 'ended';

	/**
	 * Whether the main query was hijacked for a layout this request.
	 *
	 * @var bool
	 */
	private bool $query_hijacked = false;

	/**
	 * Layout ID used for the hijacked query (0 if none).
	 *
	 * @var int
	 */
	private int $hijacked_layout_id = 0;

	/**
	 * Constructor.
	 */
	public function __construct() {
		$GLOBALS['dsm_maintenance_mode_extension'] = $this;

		// Before Divi DynamicAssets::pre_initial_setup (wp priority 0).
		add_action( 'pre_get_posts', array( $this, 'maybe_hijack_main_query' ), 1 );
		add_filter( 'template_include', array( $this, 'maybe_use_maintenance_template' ), 99 );
		add_action( 'template_redirect', array( $this, 'maybe_send_headers_or_fallback' ), 1 );
		add_action( 'admin_bar_menu', array( $this, 'maybe_add_admin_bar_notice' ), 100 );
		add_filter( 'body_class', array( $this, 'filter_body_class' ) );
	}

	/**
	 * Layout select options for the settings dashboard (layout-type items only).
	 *
	 * @return array<string, string> Value => label.
	 */
	public static function get_layout_select_options(): array {
		$raw = DsmLibraryLayoutSelectOptions::get_options();
		$out = array(
			'none' => __( '— Select Library Layout —', 'dsm-supreme-modules-pro-for-divi' ),
		);

		foreach ( $raw as $id => $title ) {
			if ( 'none' === (string) $id ) {
				continue;
			}

			$post_id = absint( $id );
			if ( $post_id <= 0 ) {
				continue;
			}

			if ( 'layout' !== DsmLibraryLayoutSelectOptions::get_layout_type_slug( $post_id ) ) {
				continue;
			}

			$label = is_string( $title ) ? $title : '';
			if ( '' === $label ) {
				$label = sprintf(
					/* translators: %d: library post ID */
					__( 'Untitled Layout %d', 'dsm-supreme-modules-pro-for-divi' ),
					$post_id
				);
			}

			$out[ (string) $post_id ] = sprintf(
				/* translators: 1: layout title, 2: post ID */
				__( '%1$s (#%2$d)', 'dsm-supreme-modules-pro-for-divi' ),
				$label,
				$post_id
			);
		}

		return $out;
	}

	/**
	 * Sanitize stored layout option value.
	 *
	 * @param mixed $value Raw option value.
	 * @return string `none` or numeric post ID string.
	 */
	public static function sanitize_layout_option( $value ): string {
		$value = sanitize_text_field( (string) $value );

		if ( '' === $value || 'none' === $value || '0' === $value ) {
			return 'none';
		}

		$post_id = absint( $value );
		if ( $post_id <= 0 ) {
			return 'none';
		}

		$post = get_post( $post_id );
		if ( ! $post instanceof \WP_Post ) {
			return 'none';
		}

		$layout_type = defined( 'ET_BUILDER_LAYOUT_POST_TYPE' ) ? ET_BUILDER_LAYOUT_POST_TYPE : 'et_pb_layout';
		if ( $layout_type !== $post->post_type ) {
			return 'none';
		}

		return (string) $post_id;
	}

	/**
	 * Sanitize HTTP status option.
	 *
	 * @param mixed $value Raw value.
	 * @return string
	 */
	public static function sanitize_http_status_option( $value ): string {
		$value = sanitize_text_field( (string) $value );

		return in_array( $value, array( '503', '200' ), true ) ? $value : '503';
	}

	/**
	 * Sanitize a schedule datetime from settings (`datetime-local` or `Y-m-d H:i`).
	 *
	 * Stored as `Y-m-d H:i` in the site timezone. Empty string clears the field.
	 *
	 * @param mixed $value Raw value.
	 * @return string
	 */
	public static function sanitize_datetime_option( $value ): string {
		$value = sanitize_text_field( (string) $value );
		$value = trim( $value );

		if ( '' === $value ) {
			return '';
		}

		$value = str_replace( 'T', ' ', $value );
		// Allow optional seconds from some browsers.
		if ( preg_match( '/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', $value ) ) {
			$value = substr( $value, 0, 16 );
		}

		$timezone = function_exists( 'wp_timezone' ) ? wp_timezone() : new \DateTimeZone( 'UTC' );
		$parsed   = \DateTimeImmutable::createFromFormat( 'Y-m-d H:i', $value, $timezone );

		if ( ! $parsed instanceof \DateTimeImmutable ) {
			return '';
		}

		$errors = \DateTimeImmutable::getLastErrors();
		if ( is_array( $errors ) && ( ( $errors['warning_count'] ?? 0 ) > 0 || ( $errors['error_count'] ?? 0 ) > 0 ) ) {
			return '';
		}

		return $parsed->format( 'Y-m-d H:i' );
	}

	/**
	 * Convert stored `Y-m-d H:i` to `datetime-local` input value.
	 *
	 * @param string $stored Stored datetime.
	 * @return string
	 */
	public static function stored_datetime_to_input_value( string $stored ): string {
		$stored = self::sanitize_datetime_option( $stored );
		if ( '' === $stored ) {
			return '';
		}

		return str_replace( ' ', 'T', $stored );
	}

	/**
	 * Normalize start/end after a settings save (clears end when it is not after start).
	 *
	 * @param array<string, mixed> $options Section options.
	 * @return array<string, mixed>
	 */
	public static function normalize_schedule_in_options( array $options ): array {
		$start = self::sanitize_datetime_option( isset( $options[ self::OPTION_START ] ) ? (string) $options[ self::OPTION_START ] : '' );
		$end   = self::sanitize_datetime_option( isset( $options[ self::OPTION_END ] ) ? (string) $options[ self::OPTION_END ] : '' );

		$options[ self::OPTION_START ] = $start;
		$options[ self::OPTION_END ]   = $end;

		if ( '' === $start || '' === $end ) {
			return $options;
		}

		$timezone = function_exists( 'wp_timezone' ) ? wp_timezone() : new \DateTimeZone( 'UTC' );
		$start_dt = \DateTimeImmutable::createFromFormat( 'Y-m-d H:i', $start, $timezone );
		$end_dt   = \DateTimeImmutable::createFromFormat( 'Y-m-d H:i', $end, $timezone );

		if (
			$start_dt instanceof \DateTimeImmutable
			&& $end_dt instanceof \DateTimeImmutable
			&& $end_dt <= $start_dt
		) {
			$options[ self::OPTION_END ] = '';
		}

		return $options;
	}

	/**
	 * Whether the master Enable toggle is on (ignores schedule window).
	 *
	 * @return bool
	 */
	public function is_enabled(): bool {
		return 'on' === $this->get_misc_option( self::OPTION_ENABLED, 'off' );
	}

	/**
	 * Whether visitors should currently see the maintenance page (enable + schedule).
	 *
	 * @return bool
	 */
	public function is_currently_serving(): bool {
		$serving = $this->is_enabled() && self::STATUS_ACTIVE === $this->get_schedule_status();

		/**
		 * Filters whether Maintenance Mode is actively serving visitors right now.
		 *
		 * @param bool $serving Whether visitors see the maintenance page.
		 */
		return (bool) apply_filters( 'dsm_maintenance_mode_is_active', $serving );
	}

	/**
	 * Resolve schedule status: off | scheduled | active | ended.
	 *
	 * @return string
	 */
	public function get_schedule_status(): string {
		if ( ! $this->is_enabled() ) {
			$status = self::STATUS_OFF;
		} else {
			$now   = $this->get_now();
			$start = $this->get_schedule_datetime( self::OPTION_START );
			$end   = $this->get_schedule_datetime( self::OPTION_END );

			if ( $end instanceof \DateTimeImmutable && $now >= $end ) {
				$status = self::STATUS_ENDED;
			} elseif ( $start instanceof \DateTimeImmutable && $now < $start ) {
				$status = self::STATUS_SCHEDULED;
			} else {
				$status = self::STATUS_ACTIVE;
			}
		}

		/**
		 * Filters the Maintenance Mode schedule status slug.
		 *
		 * @param string $status off|scheduled|active|ended.
		 */
		$filtered = apply_filters( 'dsm_maintenance_mode_schedule_status', $status );

		return is_string( $filtered ) && '' !== $filtered ? $filtered : $status;
	}

	/**
	 * Human-readable status line for the settings dashboard (includes site timezone + “now”).
	 *
	 * @return array{status: string, label: string, description: string, tone: string}
	 */
	public function get_status_for_settings(): array {
		$status    = $this->get_schedule_status();
		$tz_label  = $this->get_timezone_label();
		$now_fmt   = $this->format_now_for_display();
		$start     = $this->get_misc_option( self::OPTION_START, '' );
		$end       = $this->get_misc_option( self::OPTION_END, '' );
		$start_fmt = '' !== $start ? $this->format_datetime_for_display( $start ) : '';
		$end_fmt   = '' !== $end ? $this->format_datetime_for_display( $end ) : '';
		$clock     = sprintf(
			/* translators: 1: current site datetime, 2: timezone label */
			__( 'Site time now: %1$s (%2$s).', 'dsm-supreme-modules-pro-for-divi' ),
			$now_fmt,
			$tz_label
		);

		switch ( $status ) {
			case self::STATUS_SCHEDULED:
				$label       = __( 'Maintenance Mode is scheduled', 'dsm-supreme-modules-pro-for-divi' );
				$tone        = 'warning';
				$description = sprintf(
					/* translators: %s: start datetime in site timezone */
					__( 'Visitors will see the assigned layout starting %s.', 'dsm-supreme-modules-pro-for-divi' ),
					$start_fmt
				);
				break;

			case self::STATUS_ACTIVE:
				$label = __( 'Maintenance Mode is showing', 'dsm-supreme-modules-pro-for-divi' );
				$tone  = 'success';
				if ( '' !== $end_fmt ) {
					$description = sprintf(
						/* translators: %s: end datetime in site timezone */
						__( 'Visitors currently see the assigned layout until %s.', 'dsm-supreme-modules-pro-for-divi' ),
						$end_fmt
					);
				} else {
					$description = __( 'Visitors currently see the assigned layout. No end time is set.', 'dsm-supreme-modules-pro-for-divi' );
				}
				break;

			case self::STATUS_ENDED:
				$label       = __( 'Maintenance Mode has ended', 'dsm-supreme-modules-pro-for-divi' );
				$tone        = 'warning';
				$description = sprintf(
					/* translators: %s: end datetime in site timezone */
					__( 'The scheduled window ended %s. Visitors see the normal site. Disable or set a new schedule to continue.', 'dsm-supreme-modules-pro-for-divi' ),
					$end_fmt
				);
				break;

			case self::STATUS_OFF:
			default:
				$label       = __( 'Maintenance Mode is off', 'dsm-supreme-modules-pro-for-divi' );
				$tone        = 'neutral';
				$description = __( 'Visitor page is disabled. Enable it above to show the assigned layout to visitors.', 'dsm-supreme-modules-pro-for-divi' );
				break;
		}

		$description = trim( $description . ' ' . $clock );

		return array(
			'status'      => $status,
			'label'       => $label,
			'description' => $description,
			'tone'        => $tone,
		);
	}

	/**
	 * Payload so the dashboard can recompute Status when the enable toggle or schedule changes.
	 *
	 * @return array<string, mixed>
	 */
	public function get_status_live_payload(): array {
		return array(
			'kind'       => 'maintenance',
			'enableName' => self::OPTION_ENABLED,
			'startName'  => self::OPTION_START,
			'endName'    => self::OPTION_END,
			'now'        => $this->get_now()->format( 'Y-m-d\TH:i' ),
			'nowDisplay' => $this->format_now_for_display(),
			'tzLabel'    => $this->get_timezone_label(),
			'strings'    => array(
				'offLabel'        => __( 'Maintenance Mode is off', 'dsm-supreme-modules-pro-for-divi' ),
				'offDesc'         => __( 'Visitor page is disabled. Enable it above to show the assigned layout to visitors.', 'dsm-supreme-modules-pro-for-divi' ),
				'scheduledLabel'  => __( 'Maintenance Mode is scheduled', 'dsm-supreme-modules-pro-for-divi' ),
				// translators: %s: scheduled start time.
				'scheduledDesc'   => __( 'Visitors will see the assigned layout starting %s.', 'dsm-supreme-modules-pro-for-divi' ),
				'activeLabel'     => __( 'Maintenance Mode is showing', 'dsm-supreme-modules-pro-for-divi' ),
				// translators: %s: scheduled end time.
				'activeUntilDesc' => __( 'Visitors currently see the assigned layout until %s.', 'dsm-supreme-modules-pro-for-divi' ),
				'activeNoEndDesc' => __( 'Visitors currently see the assigned layout. No end time is set.', 'dsm-supreme-modules-pro-for-divi' ),
				'endedLabel'      => __( 'Maintenance Mode has ended', 'dsm-supreme-modules-pro-for-divi' ),
				// translators: %s: time the scheduled window ended.
				'endedDesc'       => __( 'The scheduled window ended %s. Visitors see the normal site. Disable or set a new schedule to continue.', 'dsm-supreme-modules-pro-for-divi' ),
				// translators: %1$s: current site time, %2$s: timezone label.
				'clock'           => __( 'Site time now: %1$s (%2$s).', 'dsm-supreme-modules-pro-for-divi' ),
			),
		);
	}

	/**
	 * Help HTML for start/end fields (timezone + current site clock + settings link).
	 *
	 * @return string Safe HTML.
	 */
	public static function get_schedule_timezone_help_html(): string {
		$tz_label = self::build_timezone_label();
		$now_fmt  = self::build_now_display_string();
		$link     = admin_url( 'options-general.php' );

		return wp_kses_post(
			sprintf(
				/* translators: 1: current site datetime, 2: timezone label, 3: settings URL */
				__( 'Uses your WordPress site timezone: <strong>%2$s</strong>. Site time now: <strong>%1$s</strong>. Change timezone under <a href="%3$s">Settings → General</a>.', 'dsm-supreme-modules-pro-for-divi' ),
				esc_html( $now_fmt ),
				esc_html( $tz_label ),
				esc_url( $link )
			)
		);
	}

	/**
	 * Assigned Divi Library layout ID (0 when none / invalid).
	 *
	 * @return int
	 */
	public function get_layout_id(): int {
		$raw = $this->get_misc_option( self::OPTION_LAYOUT_ID, 'none' );
		$id  = DiviLibraryLayoutRenderer::normalize_post_id( $raw );

		/**
		 * Filters the Maintenance Mode library layout post ID.
		 *
		 * @param int $id Layout post ID (0 = none).
		 */
		return (int) apply_filters( 'dsm_maintenance_mode_layout_id', $id );
	}

	/**
	 * Swap the main query to the assigned Library layout before Divi asset setup.
	 *
	 * @param \WP_Query $query Query.
	 * @return void
	 */
	public function maybe_hijack_main_query( $query ): void {
		if ( ! $query instanceof \WP_Query || ! $query->is_main_query() ) {
			return;
		}

		if ( is_admin() || ! $this->should_intercept_frontend() ) {
			return;
		}

		$layout_id = $this->get_layout_id();
		if ( $layout_id <= 0 || ! $this->is_layout_servable( $layout_id ) ) {
			return;
		}

		$layout_type = defined( 'ET_BUILDER_LAYOUT_POST_TYPE' ) ? ET_BUILDER_LAYOUT_POST_TYPE : 'et_pb_layout';

		$query->set( 'post_type', $layout_type );
		$query->set( 'p', $layout_id );
		$query->set( 'page_id', 0 );
		$query->set( 'pagename', '' );
		$query->set( 'name', '' );
		$query->set( 'post_status', 'publish' );
		$query->set( 'posts_per_page', 1 );
		$query->set( 'ignore_sticky_posts', true );

		$query->is_home              = false;
		$query->is_front_page        = false;
		$query->is_posts_page        = false;
		$query->is_singular          = true;
		$query->is_single            = true;
		$query->is_page              = false;
		$query->is_archive           = false;
		$query->is_category          = false;
		$query->is_tag               = false;
		$query->is_tax               = false;
		$query->is_author            = false;
		$query->is_date              = false;
		$query->is_search            = false;
		$query->is_404               = false;
		$query->is_post_type_archive = false;

		$this->query_hijacked     = true;
		$this->hijacked_layout_id = $layout_id;
	}

	/**
	 * Use the Maintenance Mode blank template when the query was hijacked.
	 *
	 * @param string $template Template path.
	 * @return string
	 */
	public function maybe_use_maintenance_template( string $template ): string {
		if ( ! $this->query_hijacked ) {
			return $template;
		}

		$path = __DIR__ . '/templates/maintenance-mode.php';
		if ( is_readable( $path ) ) {
			return $path;
		}

		return $template;
	}

	/**
	 * Send maintenance HTTP headers, or serve fallback when enabled without a layout.
	 *
	 * @return void
	 */
	public function maybe_send_headers_or_fallback(): void {
		if ( ! $this->should_intercept_frontend() ) {
			return;
		}

		$status = (int) self::sanitize_http_status_option(
			$this->get_misc_option( self::OPTION_HTTP_STATUS, '503' )
		);

		status_header( $status );
		nocache_headers();

		if ( 503 === $status ) {
			header( 'Retry-After: ' . (string) $this->get_retry_after_seconds() );
		}

		if ( $this->query_hijacked ) {
			return;
		}

		// Serving but no valid published layout — safe fallback (never white-screen).
		$this->render_fallback_page();
		exit;
	}

	/**
	 * Ensure body classes help Divi layout CSS apply.
	 *
	 * @param string[] $classes Body classes.
	 * @return string[]
	 */
	public function filter_body_class( array $classes ): array {
		if ( ! $this->query_hijacked ) {
			return $classes;
		}

		$classes[] = 'dsm-maintenance-mode';
		$classes[] = 'et_pb_pagebuilder_layout';
		$classes[] = 'et_no_sidebar';
		$classes[] = 'et-db';

		return array_values( array_unique( $classes ) );
	}

	/**
	 * Admin bar notice when Maintenance Mode is enabled (any schedule state).
	 *
	 * @param \WP_Admin_Bar $wp_admin_bar Admin bar.
	 * @return void
	 */
	public function maybe_add_admin_bar_notice( $wp_admin_bar ): void {
		if ( ! $this->is_enabled() || ! current_user_can( 'manage_options' ) ) {
			return;
		}

		if ( ! $wp_admin_bar instanceof \WP_Admin_Bar ) {
			return;
		}

		$status_info = $this->get_status_for_settings();
		$title_map   = array(
			self::STATUS_ACTIVE    => __( 'Visitor page ON', 'dsm-supreme-modules-pro-for-divi' ),
			self::STATUS_SCHEDULED => __( 'Visitor page scheduled', 'dsm-supreme-modules-pro-for-divi' ),
			self::STATUS_ENDED     => __( 'Visitor page ended', 'dsm-supreme-modules-pro-for-divi' ),
			self::STATUS_OFF       => __( 'Visitor page', 'dsm-supreme-modules-pro-for-divi' ),
		);
		$title       = $title_map[ $status_info['status'] ] ?? $title_map[ self::STATUS_OFF ];

		$wp_admin_bar->add_node(
			array(
				'id'    => 'dsm-maintenance-mode',
				'title' => esc_html( $title ),
				'href'  => esc_url(
					admin_url(
						'admin.php?page=divi_supreme_settings&tab=dsm_settings_misc#dsm_misc_group_site_maintenance'
					)
				),
				'meta'  => array(
					'class' => 'dsm-maintenance-mode-admin-bar dsm-maintenance-mode-admin-bar--' . sanitize_html_class( $status_info['status'] ),
					'title' => esc_attr( $status_info['description'] ),
				),
			)
		);
	}

	/**
	 * Whether this frontend request should see Maintenance Mode (serving + not bypassed).
	 *
	 * @return bool
	 */
	private function should_intercept_frontend(): bool {
		if ( ! $this->is_currently_serving() ) {
			return false;
		}

		return ! $this->should_bypass();
	}

	/**
	 * Whether the current request/user should skip the maintenance page.
	 *
	 * @return bool
	 */
	private function should_bypass(): bool {
		$bypass = $this->should_bypass_unfiltered();

		/**
		 * Filters whether the current request bypasses Maintenance Mode.
		 *
		 * @param bool $bypass Whether to bypass.
		 */
		return (bool) apply_filters( 'dsm_maintenance_mode_should_bypass', $bypass );
	}

	/**
	 * Internal bypass rules (before filter).
	 *
	 * @return bool
	 */
	private function should_bypass_unfiltered(): bool {
		if ( is_admin() ) {
			return true;
		}

		if ( wp_doing_ajax() || wp_doing_cron() ) {
			return true;
		}

		if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
			return true;
		}

		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			return true;
		}

		if ( $this->is_login_or_system_request() ) {
			return true;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only presence checks.
		if ( isset( $_GET['et_fb'] ) || isset( $_GET['et_tb'] ) ) {
			return true;
		}

		if ( function_exists( 'et_core_is_fb_enabled' ) && et_core_is_fb_enabled() ) {
			return true;
		}

		if ( current_user_can( 'manage_options' ) ) {
			return true;
		}

		if (
			'on' === $this->get_misc_option( self::OPTION_BYPASS_LOGGED_IN, 'off' )
			&& is_user_logged_in()
		) {
			return true;
		}

		return false;
	}

	/**
	 * Login, feed, and similar system endpoints that must stay reachable.
	 *
	 * @return bool
	 */
	private function is_login_or_system_request(): bool {
		if ( isset( $GLOBALS['pagenow'] ) && 'wp-login.php' === $GLOBALS['pagenow'] ) {
			return true;
		}

		$request_uri = isset( $_SERVER['REQUEST_URI'] )
			? esc_url_raw( wp_unslash( (string) $_SERVER['REQUEST_URI'] ) )
			: '';
		$path        = (string) wp_parse_url( $request_uri, PHP_URL_PATH );
		$login_path  = (string) wp_parse_url( wp_login_url(), PHP_URL_PATH );

		if ( '' !== $login_path && false !== strpos( $path, $login_path ) ) {
			return true;
		}

		// Avoid breaking feeds/robots when those conditionals are available.
		if ( function_exists( 'is_feed' ) && did_action( 'parse_query' ) && is_feed() ) {
			return true;
		}

		if ( function_exists( 'is_robots' ) && did_action( 'parse_query' ) && is_robots() ) {
			return true;
		}

		if ( function_exists( 'is_favicon' ) && did_action( 'parse_query' ) && is_favicon() ) {
			return true;
		}

		return false;
	}

	/**
	 * Whether a library layout can be shown to visitors (published).
	 *
	 * @param int $layout_id Layout post ID.
	 * @return bool
	 */
	private function is_layout_servable( int $layout_id ): bool {
		$post = get_post( $layout_id );
		if ( ! $post instanceof \WP_Post ) {
			return false;
		}

		$layout_type = defined( 'ET_BUILDER_LAYOUT_POST_TYPE' ) ? ET_BUILDER_LAYOUT_POST_TYPE : 'et_pb_layout';
		if ( $layout_type !== $post->post_type ) {
			return false;
		}

		return 'publish' === $post->post_status;
	}

	/**
	 * Read a Miscellaneous settings value.
	 *
	 * @param string $key           Option field name.
	 * @param string $default_value Default when missing.
	 * @return string
	 */
	private function get_misc_option( string $key, string $default_value = '' ): string {
		$options = get_option( self::OPTION_SECTION, array() );
		if ( ! is_array( $options ) || ! array_key_exists( $key, $options ) ) {
			return $default_value;
		}

		return is_scalar( $options[ $key ] ) ? (string) $options[ $key ] : $default_value;
	}

	/**
	 * Current time in the site timezone.
	 *
	 * @return \DateTimeImmutable
	 */
	private function get_now(): \DateTimeImmutable {
		$timezone = function_exists( 'wp_timezone' ) ? wp_timezone() : new \DateTimeZone( 'UTC' );

		return new \DateTimeImmutable( 'now', $timezone );
	}

	/**
	 * Parse a stored schedule field into a DateTimeImmutable (site timezone).
	 *
	 * @param string $option_key Option key.
	 * @return \DateTimeImmutable|null
	 */
	private function get_schedule_datetime( string $option_key ): ?\DateTimeImmutable {
		$raw = self::sanitize_datetime_option( $this->get_misc_option( $option_key, '' ) );
		if ( '' === $raw ) {
			return null;
		}

		$timezone = function_exists( 'wp_timezone' ) ? wp_timezone() : new \DateTimeZone( 'UTC' );
		$parsed   = \DateTimeImmutable::createFromFormat( 'Y-m-d H:i', $raw, $timezone );

		return $parsed instanceof \DateTimeImmutable ? $parsed : null;
	}

	/**
	 * Format stored datetime for admin copy.
	 *
	 * @param string $stored Stored `Y-m-d H:i`.
	 * @return string
	 */
	private function format_datetime_for_display( string $stored ): string {
		$stored = self::sanitize_datetime_option( $stored );
		if ( '' === $stored ) {
			return '';
		}

		$timezone = function_exists( 'wp_timezone' ) ? wp_timezone() : new \DateTimeZone( 'UTC' );
		$parsed   = \DateTimeImmutable::createFromFormat( 'Y-m-d H:i', $stored, $timezone );
		if ( ! $parsed instanceof \DateTimeImmutable ) {
			return $stored;
		}

		if ( function_exists( 'wp_date' ) ) {
			return (string) wp_date(
				get_option( 'date_format' ) . ' ' . get_option( 'time_format' ),
				$parsed->getTimestamp()
			);
		}

		return $parsed->format( 'Y-m-d H:i' );
	}

	/**
	 * Current site time formatted for admin copy.
	 *
	 * @return string
	 */
	private function format_now_for_display(): string {
		return self::build_now_display_string();
	}

	/**
	 * Site timezone label for settings help text.
	 *
	 * @return string
	 */
	private function get_timezone_label(): string {
		return self::build_timezone_label();
	}

	/**
	 * Human timezone label (named zone, or “UTC” / “UTC±offset” when WP uses a manual offset).
	 *
	 * @return string
	 */
	private static function build_timezone_label(): string {
		$named = get_option( 'timezone_string', '' );
		if ( is_string( $named ) && '' !== $named ) {
			return $named;
		}

		$offset = (float) get_option( 'gmt_offset', 0 );
		if ( 0.0 === $offset ) {
			return 'UTC';
		}

		$hours   = (int) $offset;
		$minutes = (int) round( abs( $offset - $hours ) * 60 );
		$sign    = $offset >= 0 ? '+' : '-';

		return sprintf( 'UTC%s%02d:%02d', $sign, abs( $hours ), $minutes );
	}

	/**
	 * Current site clock using WP date/time formats.
	 *
	 * @return string
	 */
	private static function build_now_display_string(): string {
		if ( function_exists( 'wp_date' ) ) {
			return (string) wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ) );
		}

		$timezone = function_exists( 'wp_timezone' ) ? wp_timezone() : new \DateTimeZone( 'UTC' );
		$now      = new \DateTimeImmutable( 'now', $timezone );

		return $now->format( 'Y-m-d H:i' );
	}

	/**
	 * Retry-After seconds for 503 responses (until schedule end, or 1 hour default).
	 *
	 * @return int
	 */
	private function get_retry_after_seconds(): int {
		$end = $this->get_schedule_datetime( self::OPTION_END );
		if ( $end instanceof \DateTimeImmutable ) {
			$delta = $end->getTimestamp() - $this->get_now()->getTimestamp();
			if ( $delta > 0 ) {
				return min( $delta, WEEK_IN_SECONDS );
			}
		}

		return HOUR_IN_SECONDS;
	}

	/**
	 * Minimal fallback when mode is on but no valid layout is assigned.
	 *
	 * @return void
	 */
	private function render_fallback_page(): void {
		$message = __( 'This site is currently undergoing maintenance. Please check back soon.', 'dsm-supreme-modules-pro-for-divi' );
		$title   = get_bloginfo( 'name' );
		?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="robots" content="noindex, nofollow">
	<title><?php echo esc_html( (string) $title ); ?></title>
		<?php wp_head(); ?>
</head>
<body <?php body_class( 'dsm-maintenance-mode dsm-maintenance-mode--fallback' ); ?>>
	<main class="dsm-maintenance-mode-fallback" style="min-height:100vh;display:flex;align-items:center;justify-content:center;padding:2rem;font-family:system-ui,sans-serif;text-align:center;">
		<p style="max-width:36rem;font-size:1.125rem;line-height:1.6;margin:0;"><?php echo esc_html( $message ); ?></p>
	</main>
		<?php wp_footer(); ?>
</body>
</html>
		<?php
	}
}
