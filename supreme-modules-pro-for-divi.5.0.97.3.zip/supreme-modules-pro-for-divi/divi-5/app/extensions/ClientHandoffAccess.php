<?php
/**
 * Client Handoff pages allowlist, admin trim, and preview switch.
 *
 * WordPress-layer rules only. Divi content locks stay on Role Editor.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Extensions;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Enforce Handoff page and admin limits, and switch an admin into a client user.
 */
class ClientHandoffAccess {

	/**
	 * Signed cookie that remembers the administrator to restore.
	 */
	private const PREVIEW_COOKIE = 'dsm_handoff_preview';

	/**
	 * Preview lifetime in seconds.
	 */
	private const PREVIEW_TTL = HOUR_IN_SECONDS;

	/**
	 * Usermeta set on accounts this screen created for preview.
	 */
	private const PREVIEW_USER_META = 'dsm_handoff_preview_user';

	/**
	 * Post types the allowlist covers.
	 *
	 * @var list<string>
	 */
	private const POST_TYPES = array( 'page', 'post' );

	/**
	 * Meta caps blocked outside the allowlist.
	 *
	 * @var list<string>
	 */
	private const POST_META_CAPS = array(
		'edit_post',
		'delete_post',
		'publish_post',
		'edit_post_meta',
		'delete_post_meta',
	);

	/**
	 * WordPress admin menus the agency can hide.
	 *
	 * @var array<string, array{label: string, menu: string, pages: list<string>}>
	 */
	private const MENUS = array(
		'themes'   => array(
			'label' => 'Themes',
			'menu'  => 'themes.php',
			'pages' => array( 'themes.php', 'theme-install.php', 'theme-editor.php', 'site-editor.php', 'customize.php' ),
		),
		'plugins'  => array(
			'label' => 'Plugins',
			'menu'  => 'plugins.php',
			'pages' => array( 'plugins.php', 'plugin-install.php', 'plugin-editor.php' ),
		),
		'tools'    => array(
			'label' => 'Tools',
			'menu'  => 'tools.php',
			'pages' => array( 'tools.php', 'import.php', 'export.php', 'site-health.php', 'export-personal-data.php', 'erase-personal-data.php' ),
		),
		'settings' => array(
			'label' => 'Settings',
			'menu'  => 'options-general.php',
			'pages' => array( 'options-general.php', 'options-writing.php', 'options-reading.php', 'options-discussion.php', 'options-media.php', 'options-permalink.php', 'options-privacy.php' ),
		),
		'comments' => array(
			'label' => 'Comments',
			'menu'  => 'edit-comments.php',
			'pages' => array( 'edit-comments.php', 'comment.php' ),
		),
	);

	/**
	 * Capabilities removed from the custom Handoff role while admin trim is on.
	 *
	 * @var list<string>
	 */
	private const NOISY_CAPS = array(
		'moderate_comments',
		'edit_theme_options',
		'switch_themes',
		'edit_themes',
		'install_themes',
		'update_themes',
		'delete_themes',
		'install_plugins',
		'activate_plugins',
		'edit_plugins',
		'update_plugins',
		'delete_plugins',
		'manage_options',
		'update_core',
	);

	/**
	 * Register runtime hooks.
	 */
	public static function register(): void {
		add_filter( 'map_meta_cap', array( self::class, 'filter_map_meta_cap' ), 10, 4 );
		add_action( 'load-post-new.php', array( self::class, 'block_new_post_screen' ) );
		add_filter( 'wp_insert_post_data', array( self::class, 'block_disallowed_write' ), 1, 2 );
		add_filter( 'rest_pre_insert_post', array( self::class, 'block_rest_write' ), 10, 2 );
		add_filter( 'rest_pre_insert_page', array( self::class, 'block_rest_write' ), 10, 2 );
		add_action( 'template_redirect', array( self::class, 'block_visual_builder' ) );
		add_action( 'admin_menu', array( self::class, 'hide_admin_menus' ), 999 );
		add_action( 'current_screen', array( self::class, 'block_admin_screens' ) );
		add_action( 'init', array( self::class, 'maybe_expire_preview' ), 1 );
		add_action( 'admin_bar_menu', array( self::class, 'preview_admin_bar' ), 9999 );
		add_action( 'admin_bar_menu', array( self::class, 'add_visual_builder_admin_bar_link' ), 1000 );
		add_action( 'edit_form_after_title', array( self::class, 'add_visual_builder_editor_link' ) );
		add_action( 'admin_enqueue_scripts', array( self::class, 'enqueue_existing_builder_link' ) );
		add_action( 'enqueue_block_editor_assets', array( self::class, 'enqueue_existing_builder_link' ) );
		add_action( 'enqueue_block_assets', array( self::class, 'enqueue_existing_builder_link' ) );
		add_filter( 'page_row_actions', array( self::class, 'add_edit_with_divi_row_action' ), 20, 2 );
		add_filter( 'post_row_actions', array( self::class, 'add_edit_with_divi_row_action' ), 20, 2 );
		add_filter( 'show_admin_bar', array( self::class, 'force_admin_bar_during_preview' ), 999 );
		add_action( 'wp_logout', array( self::class, 'restore_on_logout' ), 1 );
		add_action( 'admin_post_dsm_handoff_exit_preview', array( self::class, 'handle_exit_preview' ) );
	}

	/**
	 * Whether this user should receive Handoff page and admin limits.
	 *
	 * Administrators are never limited. Preview works because the switched
	 * account has the target role.
	 *
	 * @param int $user_id User ID. 0 is the current user.
	 */
	public static function is_restricted_user( int $user_id = 0 ): bool {
		if ( ! self::extension_is_on() || ! ClientHandoff::is_applied() ) {
			return false;
		}

		$user = $user_id > 0 ? get_userdata( $user_id ) : wp_get_current_user();

		if ( ! $user instanceof \WP_User || 0 === (int) $user->ID ) {
			return false;
		}

		$roles = (array) $user->roles;

		if ( in_array( 'administrator', $roles, true ) ) {
			return false;
		}

		$target = (string) ClientHandoff::get_access_state()['target_role'];

		$restricted = '' !== $target && in_array( $target, $roles, true );

		/**
		 * Filters whether Handoff page and admin limits apply to this user.
		 *
		 * @param bool    $restricted Current decision.
		 * @param WP_User $user       User being checked.
		 */
		return (bool) apply_filters( 'dsm_handoff_restricted_user', $restricted, $user );
	}

	/**
	 * AJAX operations owned by this class.
	 *
	 * @param string $op Operation slug. Nonce and manage_options are already checked.
	 * @return array<string, mixed>|\WP_Error|null Null when this class does not handle the op.
	 */
	public static function handle_ajax_op( string $op ) {
		if ( 'save_pages' === $op ) {
			return self::save_pages_from_request();
		}

		if ( 'search_pages' === $op ) {
			return array(
				'message' => '',
				'items'   => self::search_posts( self::request_text( 'search' ) ),
			);
		}

		if ( 'save_admin' === $op ) {
			return self::save_admin_from_request();
		}

		if ( 'start_preview' === $op ) {
			return self::start_preview( absint( self::request_text( 'preview_user_id' ) ) );
		}

		if ( 'create_preview_user' === $op ) {
			return self::create_preview_user();
		}

		return null;
	}

	/**
	 * Pages section payload.
	 *
	 * @return array<string, mixed>
	 */
	public static function pages_payload(): array {
		$state = ClientHandoff::get_access_state();
		$ids   = is_array( $state['page_ids'] ) ? $state['page_ids'] : array();
		$mode  = (string) $state['pages_mode'];

		return array(
			'mode'        => $mode,
			'ids'         => $ids,
			'items'       => self::describe_posts( $ids ),
			'allowCreate' => ! empty( $state['allow_create'] ),
			'summary'     => self::pages_summary( $mode, $ids ),
			'quickPicks'  => self::quick_picks(),
		);
	}

	/**
	 * Admin section payload.
	 *
	 * @return array<string, mixed>
	 */
	public static function admin_payload(): array {
		$state = ClientHandoff::get_access_state();
		$menus = array();

		$labels = array(
			'themes'   => __( 'Themes', 'dsm-supreme-modules-pro-for-divi' ),
			'plugins'  => __( 'Plugins', 'dsm-supreme-modules-pro-for-divi' ),
			'tools'    => __( 'Tools', 'dsm-supreme-modules-pro-for-divi' ),
			'settings' => __( 'Settings', 'dsm-supreme-modules-pro-for-divi' ),
			'comments' => __( 'Comments', 'dsm-supreme-modules-pro-for-divi' ),
		);

		foreach ( self::MENUS as $key => $menu ) {
			unset( $menu );
			$menus[] = array(
				'key'   => $key,
				'label' => $labels[ $key ] ?? $key,
			);
		}

		return array(
			'enabled'     => ! empty( $state['admin_trim_enabled'] ),
			'hiddenMenus' => is_array( $state['hidden_menus'] ) ? array_values( $state['hidden_menus'] ) : array(),
			'menus'       => $menus,
		);
	}

	/**
	 * Users who already have the Handoff target role.
	 *
	 * @return list<array{id: int, name: string, email: string}>
	 */
	public static function preview_users(): array {
		$role = (string) ClientHandoff::get_access_state()['target_role'];

		if ( '' === $role || 'administrator' === $role ) {
			return array();
		}

		$query = new \WP_User_Query(
			array(
				'role'   => $role,
				'number' => 50,
			)
		);

		$rows = array();

		foreach ( $query->get_results() as $user ) {
			if ( ! $user instanceof \WP_User ) {
				continue;
			}

			if ( in_array( 'administrator', (array) $user->roles, true ) ) {
				continue;
			}

			$rows[] = array(
				'id'        => (int) $user->ID,
				'name'      => $user->display_name,
				'email'     => $user->user_email,
				'canSwitch' => self::can_user_switch_to( (int) $user->ID ),
			);
		}

		return $rows;
	}

	/**
	 * Allowlist mode.
	 *
	 * @param mixed $mode Raw mode.
	 */
	public static function sanitize_pages_mode( $mode ): string {
		$mode = is_string( $mode ) ? sanitize_key( $mode ) : 'all';

		return in_array( $mode, array( 'all', 'only', 'except' ), true ) ? $mode : 'all';
	}

	/**
	 * Page and post IDs.
	 *
	 * @param mixed $ids Raw IDs.
	 * @return list<int>
	 */
	public static function sanitize_page_ids( $ids ): array {
		if ( is_string( $ids ) ) {
			$decoded = json_decode( $ids, true );
			$ids     = is_array( $decoded ) ? $decoded : array();
		}

		if ( ! is_array( $ids ) ) {
			return array();
		}

		$clean = array();

		foreach ( $ids as $id ) {
			$id = absint( $id );

			if ( $id > 0 ) {
				$clean[ $id ] = $id;
			}

			if ( count( $clean ) >= 500 ) {
				break;
			}
		}

		return array_values( $clean );
	}

	/**
	 * Menu keys the checklist may store.
	 *
	 * @return list<string>
	 */
	public static function default_hidden_menus(): array {
		return array_keys( self::MENUS );
	}

	/**
	 * Keep known menu keys, in checklist order.
	 *
	 * @param mixed $raw Raw keys.
	 * @return list<string>
	 */
	public static function sanitize_hidden_menus( $raw ): array {
		if ( is_string( $raw ) ) {
			$decoded = json_decode( $raw, true );
			$raw     = is_array( $decoded ) ? $decoded : array();
		}

		if ( ! is_array( $raw ) ) {
			return array();
		}

		$selected = array();

		foreach ( $raw as $key ) {
			if ( is_string( $key ) && isset( self::MENUS[ $key ] ) ) {
				$selected[ $key ] = true;
			}
		}

		$ordered = array();

		foreach ( array_keys( self::MENUS ) as $key ) {
			if ( isset( $selected[ $key ] ) ) {
				$ordered[] = $key;
			}
		}

		return $ordered;
	}

	/**
	 * Capability names stored in the trim backup.
	 *
	 * @param mixed $raw Raw names.
	 * @return list<string>
	 */
	public static function sanitize_cap_names( $raw ): array {
		if ( ! is_array( $raw ) ) {
			return array();
		}

		$names = array();

		foreach ( $raw as $name ) {
			if ( ! is_string( $name ) ) {
				continue;
			}

			$name = sanitize_key( $name );

			if ( '' !== $name && in_array( $name, self::NOISY_CAPS, true ) ) {
				$names[ $name ] = $name;
			}
		}

		return array_values( $names );
	}

	/**
	 * Remove noisy caps from the custom role while trim is on.
	 */
	public static function sync_trimmed_caps(): void {
		$state = ClientHandoff::get_access_state();

		if ( empty( $state['applied'] ) || empty( $state['admin_trim_enabled'] ) || empty( $state['use_custom_role'] ) ) {
			self::restore_trimmed_caps();
			return;
		}

		$role_name = (string) $state['target_role'];

		if ( ! self::is_custom_handoff_role( $role_name ) ) {
			return;
		}

		$role = get_role( $role_name );

		if ( ! $role instanceof \WP_Role ) {
			return;
		}

		$backup = self::sanitize_cap_names( $state['admin_cap_backup'] );

		foreach ( self::NOISY_CAPS as $cap ) {
			if ( empty( $role->capabilities[ $cap ] ) ) {
				continue;
			}

			$role->remove_cap( $cap );
			$backup[] = $cap;
		}

		ClientHandoff::merge_access_state(
			array(
				'admin_cap_backup' => self::sanitize_cap_names( $backup ),
				'admin_cap_role'   => $role_name,
			)
		);
	}

	/**
	 * Put trimmed caps back on the custom role.
	 */
	public static function restore_trimmed_caps(): void {
		$state     = ClientHandoff::get_access_state();
		$role_name = (string) $state['admin_cap_role'];
		$backup    = self::sanitize_cap_names( $state['admin_cap_backup'] );

		if ( self::is_custom_handoff_role( $role_name ) && array() !== $backup ) {
			$role = get_role( $role_name );

			if ( $role instanceof \WP_Role ) {
				foreach ( $backup as $cap ) {
					$role->add_cap( $cap );
				}
			}
		}

		if ( '' === $role_name && array() === $backup ) {
			return;
		}

		ClientHandoff::merge_access_state(
			array(
				'admin_cap_backup' => array(),
				'admin_cap_role'   => '',
			)
		);
	}

	/**
	 * Deny edit and delete outside the allowlist.
	 *
	 * WordPress passes null for the capability when an admin submenu row omits it,
	 * and the other arguments are not guaranteed to be an int and an array.
	 * A TypeError here takes down every wp-admin screen, so unexpected input is ignored.
	 *
	 * @param mixed $caps    Primitive caps.
	 * @param mixed $cap     Meta cap being checked. Null when the menu item omitted it.
	 * @param mixed $user_id User ID.
	 * @param mixed $args    Extra arguments. Post ID is first when present.
	 * @return mixed Primitive caps, or do_not_allow when the post is outside the allowlist.
	 */
	public static function filter_map_meta_cap( $caps, $cap, $user_id, $args ) {
		if ( ! is_array( $caps ) || ! is_string( $cap ) || '' === $cap || ! in_array( $cap, self::POST_META_CAPS, true ) ) {
			return $caps;
		}

		if ( is_int( $user_id ) ) {
			$checked_user_id = $user_id;
		} elseif ( is_string( $user_id ) && is_numeric( $user_id ) ) {
			$checked_user_id = (int) $user_id;
		} else {
			return $caps;
		}

		if ( ! is_array( $args ) ) {
			$args = array();
		}

		if ( ! self::is_restricted_user( $checked_user_id ) ) {
			return $caps;
		}

		$post_id = isset( $args[0] ) ? absint( $args[0] ) : 0;

		if ( $post_id <= 0 || self::post_is_allowed( $post_id, $checked_user_id ) ) {
			return $caps;
		}

		$post = get_post( $post_id );

		if ( ! $post instanceof \WP_Post || ! in_array( $post->post_type, self::POST_TYPES, true ) ) {
			return $caps;
		}

		return array( 'do_not_allow' );
	}

	/**
	 * Block the classic new post and new page screens.
	 */
	public static function block_new_post_screen(): void {
		if ( ! self::create_is_blocked() ) {
			return;
		}

		$type = isset( $_GET['post_type'] ) ? sanitize_key( wp_unslash( (string) $_GET['post_type'] ) ) : 'post'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only screen gate.

		if ( ! in_array( $type, self::POST_TYPES, true ) ) {
			return;
		}

		wp_die(
			esc_html__( 'Handoff does not allow creating new pages or posts.', 'dsm-supreme-modules-pro-for-divi' ),
			esc_html__( 'Not allowed', 'dsm-supreme-modules-pro-for-divi' ),
			array( 'response' => 403 )
		);
	}

	/**
	 * Stop inserts and edits the allowlist does not permit.
	 *
	 * @param array<string, mixed> $data    Slashed post data.
	 * @param array<string, mixed> $postarr Raw post array.
	 * @return array<string, mixed>
	 */
	public static function block_disallowed_write( array $data, array $postarr ): array {
		if ( ! self::is_restricted_user() ) {
			return $data;
		}

		$type = isset( $data['post_type'] ) ? (string) $data['post_type'] : 'post';

		if ( ! in_array( $type, self::POST_TYPES, true ) ) {
			return $data;
		}

		$post_id = isset( $postarr['ID'] ) ? absint( $postarr['ID'] ) : 0;
		$status  = $post_id > 0 ? get_post_status( $post_id ) : false;
		$is_new  = $post_id <= 0 || 'auto-draft' === $status;

		if ( $is_new && ! self::create_is_blocked() ) {
			return $data;
		}

		if ( ! $is_new && self::post_is_allowed( $post_id ) ) {
			return $data;
		}

		if ( $is_new && self::allows_create() ) {
			return $data;
		}

		wp_die(
			esc_html__( 'Handoff does not allow this page or post change.', 'dsm-supreme-modules-pro-for-divi' ),
			esc_html__( 'Not allowed', 'dsm-supreme-modules-pro-for-divi' ),
			array( 'response' => 403 )
		);
	}

	/**
	 * Block REST creates and edits outside the allowlist.
	 *
	 * @param \WP_Post|\WP_Error|mixed $prepared Prepared post.
	 * @param \WP_REST_Request         $request  Request.
	 * @return \WP_Post|\WP_Error|mixed
	 */
	public static function block_rest_write( $prepared, $request ) {
		if ( ! self::is_restricted_user() || ! $request instanceof \WP_REST_Request ) {
			return $prepared;
		}

		$post_id = absint( $request->get_param( 'id' ) );

		if ( $post_id <= 0 && self::create_is_blocked() ) {
			return new \WP_Error(
				'dsm_handoff_create_blocked',
				__( 'Handoff does not allow creating new pages or posts.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 403 )
			);
		}

		if ( $post_id > 0 && ! self::post_is_allowed( $post_id ) ) {
			return new \WP_Error(
				'dsm_handoff_page_blocked',
				__( 'Handoff does not allow editing this page or post.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 403 )
			);
		}

		return $prepared;
	}

	/**
	 * Keep the Visual Builder off posts outside the allowlist.
	 */
	public static function block_visual_builder(): void {
		if ( ! isset( $_GET['et_fb'] ) || '1' !== sanitize_text_field( wp_unslash( (string) $_GET['et_fb'] ) ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Presence check only.
			return;
		}

		if ( ! is_singular( self::POST_TYPES ) || ! self::is_restricted_user() ) {
			return;
		}

		$post_id = get_queried_object_id();

		if ( self::post_is_allowed( $post_id ) ) {
			return;
		}

		wp_safe_redirect( home_url( '/' ) );
		exit;
	}

	/**
	 * Remove checked menus for the restricted user.
	 */
	public static function hide_admin_menus(): void {
		if ( ! self::trim_is_active() ) {
			return;
		}

		foreach ( self::active_hidden_menus() as $key ) {
			remove_menu_page( self::MENUS[ $key ]['menu'] );
		}
	}

	/**
	 * Block direct visits to hidden admin screens.
	 *
	 * @param \WP_Screen $screen Current screen.
	 */
	public static function block_admin_screens( $screen ): void {
		unset( $screen );

		if ( ! self::trim_is_active() ) {
			return;
		}

		global $pagenow;

		$page = is_string( $pagenow ) ? $pagenow : '';

		foreach ( self::active_hidden_menus() as $key ) {
			if ( in_array( $page, self::MENUS[ $key ]['pages'], true ) ) {
				wp_die(
					esc_html__( 'Handoff hides this admin screen for the client role.', 'dsm-supreme-modules-pro-for-divi' ),
					esc_html__( 'Not allowed', 'dsm-supreme-modules-pro-for-divi' ),
					array( 'response' => 403 )
				);
			}
		}
	}

	/**
	 * Return the administrator when the preview cookie expires.
	 */
	public static function maybe_expire_preview(): void {
		$cookie = self::read_preview_cookie();

		if ( null === $cookie ) {
			return;
		}

		$current = get_current_user_id();

		if ( $cookie['exp'] >= time() && $current === $cookie['switched'] ) {
			return;
		}

		if ( $cookie['exp'] < time() && $current === $cookie['switched'] ) {
			self::restore_original_user( $cookie['old'] );
			wp_safe_redirect( ClientHandoff::get_settings_url() );
			exit;
		}

		self::clear_preview_cookie();
	}

	/**
	 * Frontend “Edit with Divi” for a Handoff user when the page already uses the builder.
	 *
	 * Divi’s own admin-bar link also requires `divi_builder_control`. Handoff turns that
	 * off so the client cannot enable the builder on a classic page, which also hid the
	 * link on pages that already use Divi.
	 *
	 * @param \WP_Admin_Bar $bar Admin bar.
	 */
	public static function add_visual_builder_admin_bar_link( $bar ): void {
		if ( ! $bar instanceof \WP_Admin_Bar ) {
			return;
		}

		if ( function_exists( 'et_fb_is_enabled' ) && et_fb_is_enabled() ) {
			return;
		}

		if ( is_admin() && ! self::is_post_editor_screen() ) {
			return;
		}

		$post_id = is_admin() ? self::edited_admin_post_id() : (int) get_queried_object_id();

		if ( ! self::handoff_user_can_open_existing_builder( $post_id ) ) {
			return;
		}

		$url = self::visual_builder_url( $post_id );

		if ( '' === $url ) {
			return;
		}

		$bar->add_node(
			array(
				'id'    => 'dsm-handoff-edit-with-divi',
				'title' => esc_html__( 'Edit with Divi', 'dsm-supreme-modules-pro-for-divi' ),
				'href'  => esc_url( $url ),
			)
		);
	}

	/**
	 * Classic editor link into the Visual Builder for an existing Divi page.
	 *
	 * @param \WP_Post $post Post being edited.
	 */
	public static function add_visual_builder_editor_link( $post ): void {
		if ( ! $post instanceof \WP_Post || ! self::handoff_user_can_open_existing_builder( (int) $post->ID ) ) {
			return;
		}

		$url = self::visual_builder_url( (int) $post->ID );

		if ( '' === $url ) {
			return;
		}

		printf(
			'<p class="dsm-handoff-edit-divi"><a class="button button-primary button-large" href="%1$s">%2$s</a></p>',
			esc_url( $url ),
			esc_html__( 'Edit with Divi', 'dsm-supreme-modules-pro-for-divi' )
		);
	}

	/**
	 * Pages-list action for a layout that already uses Divi.
	 *
	 * Divi’s own “Edit With Divi” row action requires `divi_builder_control`.
	 *
	 * @param array<string, string> $actions Row actions.
	 * @param \WP_Post              $post    Post row.
	 * @return array<string, string>
	 */
	public static function add_edit_with_divi_row_action( $actions, $post ) {
		if ( ! is_array( $actions ) || ! $post instanceof \WP_Post ) {
			return is_array( $actions ) ? $actions : array();
		}

		if ( ! self::handoff_user_can_open_existing_builder( (int) $post->ID ) ) {
			return $actions;
		}

		$url = self::visual_builder_url( (int) $post->ID );

		if ( '' === $url ) {
			return $actions;
		}

		$title = wp_strip_all_tags( get_the_title( $post ) );

		$actions['dsm_edit_with_divi'] = sprintf(
			'<a href="%1$s" aria-label="%2$s">%3$s</a>',
			esc_url( $url ),
			esc_attr(
				sprintf(
					/* translators: %s: page or post title. */
					__( 'Edit “%s” with Divi', 'dsm-supreme-modules-pro-for-divi' ),
					$title
				)
			),
			esc_html__( 'Edit with Divi', 'dsm-supreme-modules-pro-for-divi' )
		);

		return $actions;
	}

	/**
	 * Button on the block editor placeholder and the classic-editor overlay.
	 *
	 * Divi prints “This Layout Is Built With Divi” and only adds “Edit With The Divi Builder”
	 * when `divi_builder_control` is on. That capability also lets the client turn the builder off.
	 */
	public static function enqueue_existing_builder_link(): void {
		if ( ! is_admin() ) {
			return;
		}

		$post_id = self::edited_admin_post_id();

		if ( ! self::handoff_user_can_open_existing_builder( $post_id ) ) {
			return;
		}

		$url = self::visual_builder_url( $post_id );

		if ( '' === $url ) {
			return;
		}

		$handle  = 'dsm-handoff-edit-divi';
		$version = defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';

		if ( ! wp_script_is( $handle, 'registered' ) ) {
			wp_register_script( $handle, false, array(), $version, true );
			wp_add_inline_script( $handle, self::existing_builder_link_script( $url ) );
		}

		if ( ! wp_style_is( $handle, 'registered' ) ) {
			wp_register_style( $handle, false, array(), $version );
			wp_add_inline_style( $handle, self::existing_builder_link_css() );
		}

		wp_enqueue_script( $handle );
		wp_enqueue_style( $handle );
	}

	/**
	 * Script that inserts the Visual Builder link into Divi’s editor placeholder.
	 *
	 * @param string $url Visual Builder URL. Escaped at output.
	 */
	private static function existing_builder_link_script( string $url ): string {
		$settings = wp_json_encode(
			array(
				'url'   => $url,
				'label' => __( 'Edit with Divi', 'dsm-supreme-modules-pro-for-divi' ),
			)
		);

		if ( ! is_string( $settings ) ) {
			return '';
		}

		return 'window.dsmHandoffEditDivi=' . $settings . ';(function(){var cfg=window.dsmHandoffEditDivi||{};if(!cfg.url){return;}function link(doc){var node=doc.createElement("a");node.className="components-button is-button is-primary is-large dsm-handoff-edit-divi";node.href=cfg.url;node.textContent=cfg.label;return node;}function mount(doc){var boxes=doc.querySelectorAll(".wp-block-divi-placeholder,.et-fb-app__overlay-content");Array.prototype.forEach.call(boxes,function(box){if(box.querySelector(".dsm-handoff-edit-divi")){return;}var controls=box.querySelector(".et-controls,.et-fb-app__overlay-buttons");if(!controls){controls=doc.createElement("div");controls.className="et-controls dsm-handoff-edit-divi-controls";box.appendChild(controls);}controls.insertBefore(link(doc),controls.firstChild);});var header=doc.querySelector(".editor-header__settings,.edit-post-header__settings");if(header&&!header.querySelector(".dsm-handoff-edit-divi-header")){var item=link(doc);item.className+=" dsm-handoff-edit-divi-header";header.insertBefore(item,header.firstChild);}}var timer=0;function scan(){mount(document);}var observer=new MutationObserver(function(){window.clearTimeout(timer);timer=window.setTimeout(scan,50);});function start(){scan();if(document.documentElement){observer.observe(document.documentElement,{childList:true,subtree:true});}}if(document.readyState==="loading"){document.addEventListener("DOMContentLoaded",start);}else{start();}})();';
	}

	/**
	 * Styles for the injected Visual Builder link.
	 */
	private static function existing_builder_link_css(): string {
		return '.wp-block-divi-placeholder .dsm-handoff-edit-divi-controls,.et-fb-app__overlay-content .dsm-handoff-edit-divi-controls{display:flex;justify-content:center;margin-top:16px;}a.dsm-handoff-edit-divi.components-button{background:#326bff;border:1px solid #326bff;border-radius:3px;color:#fff;text-decoration:none;}a.dsm-handoff-edit-divi.components-button:hover,a.dsm-handoff-edit-divi.components-button:focus{background:#1d4fe0;border-color:#1d4fe0;color:#fff;}.editor-header__settings .dsm-handoff-edit-divi-header,.edit-post-header__settings .dsm-handoff-edit-divi-header{margin-right:8px;}';
	}

	/**
	 * Whether the current admin screen is the page or post editor.
	 */
	private static function is_post_editor_screen(): bool {
		if ( ! function_exists( 'get_current_screen' ) ) {
			return false;
		}

		$screen = get_current_screen();

		return $screen instanceof \WP_Screen && 'post' === $screen->base;
	}

	/**
	 * Post being edited in wp-admin.
	 */
	private static function edited_admin_post_id(): int {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only post ID of the screen being edited.
		if ( isset( $_GET['post'] ) ) {
			$post_id = absint( wp_unslash( (string) $_GET['post'] ) );
			// phpcs:enable WordPress.Security.NonceVerification.Recommended
			return $post_id;
		}

		$post = get_post();

		return $post instanceof \WP_Post ? (int) $post->ID : 0;
	}

	/**
	 * Whether this Handoff user may open the Visual Builder for a page that already uses it.
	 *
	 * @param int $post_id Post ID.
	 */
	private static function handoff_user_can_open_existing_builder( int $post_id ): bool {
		if ( $post_id <= 0 || ! self::is_restricted_user() ) {
			return false;
		}

		if ( ! function_exists( 'et_pb_is_allowed' ) || ! et_pb_is_allowed( 'use_visual_builder' ) ) {
			return false;
		}

		if ( et_pb_is_allowed( 'divi_builder_control' ) ) {
			return false;
		}

		if ( ! function_exists( 'et_pb_is_pagebuilder_used' ) || ! et_pb_is_pagebuilder_used( $post_id ) ) {
			return false;
		}

		$post = get_post( $post_id );

		if ( ! $post instanceof \WP_Post || ! in_array( $post->post_type, self::POST_TYPES, true ) ) {
			return false;
		}

		if ( ! current_user_can( 'edit_post', $post_id ) || ! self::post_is_allowed( $post_id ) ) {
			return false;
		}

		return true;
	}

	/**
	 * Visual Builder URL for a published page or post.
	 *
	 * @param int $post_id Post ID.
	 */
	private static function visual_builder_url( int $post_id ): string {
		if ( ! function_exists( 'et_fb_get_builder_url' ) ) {
			return '';
		}

		$permalink = get_permalink( $post_id );

		if ( ! is_string( $permalink ) || '' === $permalink ) {
			return '';
		}

		$url = et_fb_get_builder_url( $permalink );

		return is_string( $url ) ? $url : '';
	}

	/**
	 * Admin bar item while previewing.
	 *
	 * @param \WP_Admin_Bar $bar Admin bar.
	 */
	public static function preview_admin_bar( $bar ): void {
		if ( ! $bar instanceof \WP_Admin_Bar || ( ! self::is_previewing() && ! self::is_user_switching_preview() ) ) {
			return;
		}

		$user       = wp_get_current_user();
		$name       = $user instanceof \WP_User ? $user->display_name : '';
		$roles      = $user instanceof \WP_User ? array_values( (array) $user->roles ) : array();
		$role_label = self::role_display_name( isset( $roles[0] ) ? (string) $roles[0] : '' );

		if ( '' !== $role_label && '' !== $name ) {
			$name = $name . ' (' . $role_label . ')';
		} elseif ( '' !== $role_label ) {
			$name = $role_label;
		}

		$switch_back = self::user_switching_back_url();
		$url         = '' !== $switch_back
		? $switch_back
		: wp_nonce_url(
			admin_url( 'admin-post.php?action=dsm_handoff_exit_preview' ),
			'dsm_handoff_exit_preview'
		);

		$bar->add_node(
			array(
				'id'    => 'dsm-handoff-preview',
				'title' => sprintf(
					/* translators: %s: preview user display name. */
					__( 'Previewing as %s — Exit preview', 'dsm-supreme-modules-pro-for-divi' ),
					$name
				),
				'href'  => $url,
				'meta'  => array(
					'class' => 'dsm-handoff-preview-exit',
				),
			)
		);
	}

	/**
	 * Keep the exit link visible on the front end.
	 *
	 * @param bool $show Whether the admin bar shows.
	 */
	public static function force_admin_bar_during_preview( bool $show ): bool {
		return ( self::is_previewing() || self::is_user_switching_preview() ) ? true : $show;
	}

	/**
	 * Logging out of a preview returns the original administrator.
	 *
	 * @param int $user_id User that logged out.
	 */
	public static function restore_on_logout( $user_id ): void {
		$cookie = self::read_preview_cookie();

		if ( null === $cookie || (int) $user_id !== $cookie['switched'] ) {
			self::clear_preview_cookie();
			return;
		}

		$old = $cookie['old'];
		self::clear_preview_cookie();
		wp_set_current_user( $old );
		wp_set_auth_cookie( $old );
		wp_safe_redirect( ClientHandoff::get_settings_url() );
		exit;
	}

	/**
	 * Exit preview from the admin bar.
	 */
	public static function handle_exit_preview(): void {
		check_admin_referer( 'dsm_handoff_exit_preview' );

		$switch_back = self::user_switching_back_url();

		if ( '' !== $switch_back && ! self::is_previewing() ) {
			wp_safe_redirect( $switch_back );
			exit;
		}

		$cookie = self::read_preview_cookie();

		if ( null === $cookie || get_current_user_id() !== $cookie['switched'] ) {
			self::clear_preview_cookie();
			wp_safe_redirect( ClientHandoff::get_settings_url() );
			exit;
		}

		self::restore_original_user( $cookie['old'] );
		wp_safe_redirect( ClientHandoff::get_settings_url() );
		exit;
	}

	/**
	 * Whether the current request is an active preview.
	 */
	public static function is_previewing(): bool {
		$cookie = self::read_preview_cookie();

		return null !== $cookie
		&& $cookie['exp'] >= time()
		&& get_current_user_id() === $cookie['switched'];
	}

	/**
	 * Save the pages allowlist.
	 *
	 * @return array<string, string>
	 */
	private static function save_pages_from_request(): array {
		$mode = self::sanitize_pages_mode( self::request_text( 'pages_mode' ) );
		$ids  = self::sanitize_page_ids( self::request_text( 'page_ids' ) );

		ClientHandoff::merge_access_state(
			array(
				'pages_mode'   => $mode,
				'page_ids'     => $ids,
				'allow_create' => self::request_flag( 'allow_create' ),
			)
		);

		return array(
			'message' => __( 'Pages allowlist saved. It is enforced only while Handoff is applied.', 'dsm-supreme-modules-pro-for-divi' ),
		);
	}

	/**
	 * Save admin trim and apply or restore caps immediately.
	 *
	 * @return array<string, string>
	 */
	private static function save_admin_from_request(): array {
		ClientHandoff::merge_access_state(
			array(
				'admin_trim_enabled' => self::request_flag( 'admin_trim_enabled' ),
				'hidden_menus'       => self::sanitize_hidden_menus( self::request_text( 'hidden_menus' ) ),
			)
		);
		self::sync_trimmed_caps();

		return array(
			'message' => __( 'Admin trim saved.', 'dsm-supreme-modules-pro-for-divi' ),
		);
	}

	/**
	 * Switch the current administrator into a target-role user.
	 *
	 * @param int $user_id Preview user.
	 * @return array<string, string>|\WP_Error
	 */
	private static function start_preview( int $user_id ) {
		if ( ! ClientHandoff::is_applied() ) {
			return new \WP_Error(
				'dsm_handoff_preview_inactive',
				__( 'Apply Handoff before previewing.', 'dsm-supreme-modules-pro-for-divi' )
			);
		}

		$current = wp_get_current_user();

		if ( ! $current instanceof \WP_User || ! in_array( 'administrator', (array) $current->roles, true ) ) {
			return new \WP_Error(
				'dsm_handoff_preview_admin',
				__( 'Only an administrator can preview as the client.', 'dsm-supreme-modules-pro-for-divi' )
			);
		}

		if ( self::is_previewing() || self::is_user_switching_preview() ) {
			return new \WP_Error(
				'dsm_handoff_preview_active',
				__( 'Exit the current preview before starting another.', 'dsm-supreme-modules-pro-for-divi' )
			);
		}

		$user = get_userdata( $user_id );

		if ( ! $user instanceof \WP_User || in_array( 'administrator', (array) $user->roles, true ) ) {
			return new \WP_Error(
				'dsm_handoff_preview_user',
				__( 'Choose a user on the Handoff role.', 'dsm-supreme-modules-pro-for-divi' )
			);
		}

		$target = (string) ClientHandoff::get_access_state()['target_role'];

		if ( ! in_array( $target, (array) $user->roles, true ) ) {
			return new \WP_Error(
				'dsm_handoff_preview_role',
				__( 'That user is not on the Handoff role.', 'dsm-supreme-modules-pro-for-divi' )
			);
		}

		$old = get_current_user_id();

		if ( $old === $user_id ) {
			return new \WP_Error(
				'dsm_handoff_preview_self',
				__( 'Choose a different user to preview.', 'dsm-supreme-modules-pro-for-divi' )
			);
		}

		$switch_url = self::user_switching_switch_url( $user_id, self::preview_redirect_url() );

		if ( '' !== $switch_url ) {
			return array(
				'message'     => __( 'Preview started.', 'dsm-supreme-modules-pro-for-divi' ),
				'redirect'    => $switch_url,
				'previewMode' => 'user_switching',
			);
		}

		self::write_preview_cookie( $old, $user_id );
		wp_clear_auth_cookie();
		wp_set_current_user( $user_id );
		wp_set_auth_cookie( $user_id, false );

		return array(
			'message'     => __( 'Preview started.', 'dsm-supreme-modules-pro-for-divi' ),
			'redirect'    => self::preview_redirect_url(),
			'previewMode' => 'cookie',
		);
	}

	/**
	 * Create or reuse a dedicated preview account on the target role.
	 *
	 * @return array<string, mixed>|\WP_Error
	 */
	private static function create_preview_user() {
		$target = (string) ClientHandoff::get_access_state()['target_role'];

		if ( ! self::is_custom_handoff_role( $target ) && ClientHandoff::TARGET_ROLE !== $target ) {
			return new \WP_Error(
				'dsm_handoff_preview_role_missing',
				__( 'Apply Handoff before creating a preview user.', 'dsm-supreme-modules-pro-for-divi' )
			);
		}

		if ( ! get_role( $target ) ) {
			return new \WP_Error(
				'dsm_handoff_preview_role_missing',
				__( 'The Handoff role does not exist yet.', 'dsm-supreme-modules-pro-for-divi' )
			);
		}

		$role_object = get_role( $target );

		if ( 'administrator' === $target || ( $role_object instanceof \WP_Role && ! empty( $role_object->capabilities['manage_options'] ) ) ) {
			return new \WP_Error(
				'dsm_handoff_preview_admin',
				__( 'The preview user cannot be an administrator.', 'dsm-supreme-modules-pro-for-divi' )
			);
		}

		$login = self::unique_preview_login();
		$email = self::unique_preview_email( $login );

		if ( '' === $login || '' === $email ) {
			return new \WP_Error(
				'dsm_handoff_preview_identity',
				__( 'Could not create a unique preview user.', 'dsm-supreme-modules-pro-for-divi' )
			);
		}

		$created = wp_insert_user(
			array(
				'user_login'   => $login,
				'user_pass'    => wp_generate_password( 24, true, true ),
				'user_email'   => $email,
				'display_name' => __( 'Handoff preview', 'dsm-supreme-modules-pro-for-divi' ),
				'role'         => $target,
			)
		);

		if ( is_wp_error( $created ) ) {
			return $created;
		}

		$user_id = (int) $created;
		$user    = get_userdata( $user_id );

		if (
		! $user instanceof \WP_User
		|| in_array( 'administrator', (array) $user->roles, true )
		|| user_can( $user, 'manage_options' )
		) {
			require_once ABSPATH . 'wp-admin/includes/user.php';
			wp_delete_user( $user_id );

			return new \WP_Error(
				'dsm_handoff_preview_admin',
				__( 'The preview user cannot be an administrator.', 'dsm-supreme-modules-pro-for-divi' )
			);
		}

		update_user_meta( $user_id, self::PREVIEW_USER_META, '1' );

		return array(
			'message'       => __( 'Preview user created on the Handoff role.', 'dsm-supreme-modules-pro-for-divi' ),
			'previewUserId' => $user_id,
			'previewUsers'  => self::preview_users(),
		);
	}

	/**
	 * Search pages and posts for the chip picker.
	 *
	 * @param string $term Search text.
	 * @return list<array{id: int, title: string, type: string}>
	 */
	private static function search_posts( string $term ): array {
		$term = trim( $term );

		if ( strlen( $term ) < 2 ) {
			return array();
		}

		$query = new \WP_Query(
			array(
				'post_type'              => self::POST_TYPES,
				'post_status'            => array( 'publish', 'private', 'draft', 'pending', 'future' ),
				's'                      => $term,
				'posts_per_page'         => 20,
				'orderby'                => 'title',
				'order'                  => 'ASC',
				'no_found_rows'          => true,
				'update_post_meta_cache' => false,
				'update_post_term_cache' => false,
			)
		);

		return self::format_posts( $query->posts );
	}

	/**
	 * Titles for stored IDs.
	 *
	 * @param int[] $ids Post IDs.
	 * @return list<array{id: int, title: string, type: string}>
	 */
	private static function describe_posts( array $ids ): array {
		$ids = self::sanitize_page_ids( $ids );

		if ( array() === $ids ) {
			return array();
		}

		$query = new \WP_Query(
			array(
				'post_type'              => self::POST_TYPES,
				'post_status'            => array( 'publish', 'private', 'draft', 'pending', 'future', 'inherit' ),
				'post__in'               => $ids,
				'posts_per_page'         => count( $ids ),
				'orderby'                => 'post__in',
				'no_found_rows'          => true,
				'update_post_meta_cache' => false,
				'update_post_term_cache' => false,
			)
		);

		return self::format_posts( $query->posts );
	}

	/**
	 * Compact post rows for the dashboard.
	 *
	 * @param mixed[] $posts Query posts.
	 * @return list<array{id: int, title: string, type: string}>
	 */
	private static function format_posts( array $posts ): array {
		$rows = array();

		foreach ( $posts as $post ) {
			if ( ! $post instanceof \WP_Post ) {
				continue;
			}

			$rows[] = array(
				'id'    => (int) $post->ID,
				'title' => html_entity_decode( get_the_title( $post ), ENT_QUOTES, 'UTF-8' ),
				'type'  => $post->post_type,
			);
		}

		return $rows;
	}

	/**
	 * Front page and posts page shortcuts.
	 *
	 * @return array<string, array{id: int, title: string}>
	 */
	private static function quick_picks(): array {
		$front = absint( get_option( 'page_on_front' ) );
		$posts = absint( get_option( 'page_for_posts' ) );

		return array(
			'front' => array(
				'id'    => $front,
				'title' => $front > 0 ? html_entity_decode( get_the_title( $front ), ENT_QUOTES, 'UTF-8' ) : '',
			),
			'posts' => array(
				'id'    => $posts,
				'title' => $posts > 0 ? html_entity_decode( get_the_title( $posts ), ENT_QUOTES, 'UTF-8' ) : '',
			),
		);
	}

	/**
	 * Overview sentence when the allowlist is not "all".
	 *
	 * @param string $mode Mode.
	 * @param int[]  $ids  Selected IDs.
	 */
	private static function pages_summary( string $mode, array $ids ): string {
		$count = count( $ids );

		if ( 'only' === $mode ) {
			return sprintf(
			/* translators: %d: number of pages or posts. */
				_n( '%d page allowed', '%d pages allowed', $count, 'dsm-supreme-modules-pro-for-divi' ),
				$count
			);
		}

		if ( 'except' === $mode ) {
			return sprintf(
			/* translators: %d: number of pages or posts. */
				_n( '%d page excluded', '%d pages excluded', $count, 'dsm-supreme-modules-pro-for-divi' ),
				$count
			);
		}

		return '';
	}

	/**
	 * Whether this post may be edited by the restricted user.
	 *
	 * @param int $post_id Post ID.
	 * @param int $user_id User ID. 0 is the current user.
	 */
	private static function post_is_allowed( int $post_id, int $user_id = 0 ): bool {
		$state = ClientHandoff::get_access_state();
		$mode  = (string) $state['pages_mode'];
		$ids   = is_array( $state['page_ids'] ) ? $state['page_ids'] : array();
		$ids   = array_map( 'absint', $ids );

		if ( 'all' === $mode ) {
			$allowed = true;
		} else {
			$listed = in_array( $post_id, $ids, true );

			if ( 'only' === $mode ) {
				$allowed = $listed || self::author_created_while_create_allowed( $post_id, $user_id );
			} else {
				$allowed = ! $listed;
			}
		}

		/**
		 * Filters whether a restricted Handoff user may edit this page or post.
		 *
		 * @param bool $allowed Whether the post is editable.
		 * @param int  $post_id Post ID.
		 * @param int  $user_id User ID. 0 is the current user.
		 */
		return (bool) apply_filters( 'dsm_handoff_post_allowed', $allowed, $post_id, $user_id );
	}

	/**
	 * Pages created by this user stay editable when create is allowed.
	 *
	 * The agency allowlist is not rewritten.
	 *
	 * @param int $post_id Post ID.
	 * @param int $user_id User ID. 0 is the current user.
	 */
	private static function author_created_while_create_allowed( int $post_id, int $user_id ): bool {
		if ( ! self::allows_create() ) {
			return false;
		}

		$post = get_post( $post_id );

		if ( ! $post instanceof \WP_Post || ! in_array( $post->post_type, self::POST_TYPES, true ) ) {
			return false;
		}

		$user_id = $user_id > 0 ? $user_id : get_current_user_id();

		return $user_id > 0 && (int) $post->post_author === $user_id;
	}

	/**
	 * Translated role name.
	 *
	 * @param string $role Role slug.
	 */
	private static function role_display_name( string $role ): string {
		$wp_roles = wp_roles();

		if ( '' === $role || ! isset( $wp_roles->roles[ $role ]['name'] ) ) {
			return '';
		}

		return translate_user_role( (string) $wp_roles->roles[ $role ]['name'] );
	}

	/**
	 * Whether new pages and posts are blocked.
	 */
	private static function create_is_blocked(): bool {
		return self::is_restricted_user() && ! self::allows_create();
	}

	/**
	 * Stored create flag.
	 */
	private static function allows_create(): bool {
		return ! empty( ClientHandoff::get_access_state()['allow_create'] );
	}

	/**
	 * Whether menu hiding should run.
	 */
	private static function trim_is_active(): bool {
		$state = ClientHandoff::get_access_state();

		return self::is_restricted_user() && ! empty( $state['admin_trim_enabled'] );
	}

	/**
	 * Menu keys to hide for this request.
	 *
	 * @return list<string>
	 */
	private static function active_hidden_menus(): array {
		$state = ClientHandoff::get_access_state();
		$menus = self::sanitize_hidden_menus( $state['hidden_menus'] ?? array() );

		/**
		 * Filters admin menus Handoff hides for the target role.
		 *
		 * @param list<string> $menus Menu keys.
		 */
		$filtered = apply_filters( 'dsm_handoff_hidden_menus', $menus );

		return self::sanitize_hidden_menus( is_array( $filtered ) ? $filtered : $menus );
	}

	/**
	 * Admin dashboard, so preview opens the trimmed wp-admin screen.
	 */
	private static function preview_redirect_url(): string {
		return admin_url();
	}

	/**
	 * Custom Handoff roles use the dsm_ prefix and are never Editor or Administrator.
	 *
	 * @param string $role Role slug.
	 */
	private static function is_custom_handoff_role( string $role ): bool {
		return '' !== $role
		&& str_starts_with( $role, 'dsm_' )
		&& ClientHandoff::TARGET_ROLE !== $role
		&& 'administrator' !== $role;
	}

	/**
	 * Extension toggle.
	 */
	private static function extension_is_on(): bool {
		return function_exists( 'dsm_is_client_handoff_extension_enabled' ) && dsm_is_client_handoff_extension_enabled();
	}

	/**
	 * Posted text. Caller has verified the nonce.
	 *
	 * @param string $key Request key.
	 */
	private static function request_text( string $key ): string {
		if ( ! isset( $_POST[ $key ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- handle_ajax() verifies the nonce.
			return '';
		}

		return sanitize_text_field( wp_unslash( (string) $_POST[ $key ] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- handle_ajax() verifies the nonce.
	}

	/**
	 * Posted boolean flag.
	 *
	 * @param string $key Request key.
	 */
	private static function request_flag( string $key ): bool {
		return '1' === self::request_text( $key );
	}

	/**
	 * Log the original administrator back in and drop the preview cookie.
	 *
	 * @param int $user_id Original user.
	 */
	private static function restore_original_user( int $user_id ): void {
		self::clear_preview_cookie();

		$user = get_userdata( $user_id );

		if ( ! $user instanceof \WP_User || ! in_array( 'administrator', (array) $user->roles, true ) ) {
			return;
		}

		wp_clear_auth_cookie();
		wp_set_current_user( $user_id );
		wp_set_auth_cookie( $user_id );
	}

	/**
	 * Store the signed return cookie.
	 *
	 * @param int $old      Administrator ID.
	 * @param int $switched Preview user ID.
	 */
	private static function write_preview_cookie( int $old, int $switched ): void {
		$exp   = time() + self::PREVIEW_TTL;
		$value = $old . '|' . $switched . '|' . $exp . '|' . self::sign_preview( $old, $switched, $exp );
		$paths = array_unique( array( COOKIEPATH, SITECOOKIEPATH ) );

		foreach ( $paths as $path ) {
			setcookie(
				self::PREVIEW_COOKIE,
				$value,
				array(
					'expires'  => $exp,
					'path'     => $path,
					'domain'   => COOKIE_DOMAIN,
					'secure'   => is_ssl(),
					'httponly' => true,
					'samesite' => 'Lax',
				)
			);
		}

		$_COOKIE[ self::PREVIEW_COOKIE ] = $value;
	}

	/**
	 * Drop the preview cookie.
	 */
	private static function clear_preview_cookie(): void {
		$paths = array_unique( array( COOKIEPATH, SITECOOKIEPATH ) );

		foreach ( $paths as $path ) {
			setcookie(
				self::PREVIEW_COOKIE,
				'',
				array(
					'expires'  => time() - HOUR_IN_SECONDS,
					'path'     => $path,
					'domain'   => COOKIE_DOMAIN,
					'secure'   => is_ssl(),
					'httponly' => true,
					'samesite' => 'Lax',
				)
			);
		}

		unset( $_COOKIE[ self::PREVIEW_COOKIE ] );
	}

	/**
	 * Valid preview cookie, or null.
	 *
	 * @return array{old: int, switched: int, exp: int}|null
	 */
	private static function read_preview_cookie(): ?array {
		if ( ! isset( $_COOKIE[ self::PREVIEW_COOKIE ] ) ) {
			return null;
		}

		$raw   = sanitize_text_field( wp_unslash( (string) $_COOKIE[ self::PREVIEW_COOKIE ] ) );
		$parts = explode( '|', $raw );

		if ( 4 !== count( $parts ) ) {
			return null;
		}

		$old      = absint( $parts[0] );
		$switched = absint( $parts[1] );
		$exp      = absint( $parts[2] );
		$sig      = $parts[3];

		if ( $old <= 0 || $switched <= 0 || $exp <= 0 ) {
			return null;
		}

		$expected = self::sign_preview( $old, $switched, $exp );

		if ( ! hash_equals( $expected, $sig ) ) {
			return null;
		}

		return array(
			'old'      => $old,
			'switched' => $switched,
			'exp'      => $exp,
		);
	}

	/**
	 * HMAC for the preview cookie.
	 *
	 * @param int $old      Administrator ID.
	 * @param int $switched Preview user ID.
	 * @param int $exp      Unix expiry.
	 */
	private static function sign_preview( int $old, int $switched, int $exp ): string {
		return hash_hmac( 'sha256', $old . '|' . $switched . '|' . $exp, wp_salt( 'auth' ) );
	}

	/**
	 * Whether the User Switching plugin is loaded.
	 */
	public static function user_switching_plugin_active(): bool {
		return class_exists( '\user_switching' );
	}

	/**
	 * Whether User Switching would allow this administrator to switch to the user.
	 *
	 * @param int $user_id Target user.
	 */
	public static function can_user_switch_to( int $user_id ): bool {
		return '' !== self::user_switching_switch_url( $user_id, '' );
	}

	/**
	 * Current request is a User Switching session into the Handoff role.
	 */
	private static function is_user_switching_preview(): bool {
		$old = self::user_switching_old_user();

		return $old instanceof \WP_User && self::is_restricted_user();
	}

	/**
	 * Account User Switching switched away from, when that plugin is active.
	 */
	private static function user_switching_old_user(): ?\WP_User {
		if ( ! self::user_switching_plugin_active() ) {
			return null;
		}

		$old = false;

		if ( function_exists( 'current_user_switched' ) ) {
			$old = current_user_switched();
		} else {
			$instance = \user_switching::get_instance();

			if ( is_object( $instance ) && method_exists( $instance, 'current_user_switched' ) ) {
				$old = $instance->current_user_switched();
			}
		}

		return $old instanceof \WP_User ? $old : null;
	}

	/**
	 * User Switching login URL, or an empty string when that path is unavailable.
	 *
	 * @param int    $user_id     User to become.
	 * @param string $redirect_to URL after the switch.
	 */
	private static function user_switching_switch_url( int $user_id, string $redirect_to ): string {
		if ( $user_id <= 0 || ! self::user_switching_plugin_active() || ! current_user_can( 'switch_to_user', $user_id ) ) {
			return '';
		}

		$instance = \user_switching::get_instance();

		if ( ! is_object( $instance ) || ! method_exists( $instance, 'switch_to_url' ) ) {
			return '';
		}

		$url = self::invoke_user_switching( $instance, 'switch_to_url', array( $user_id, $redirect_to ) );

		return is_string( $url ) ? $url : '';
	}

	/**
	 * User Switching switch-back URL for the current session.
	 */
	private static function user_switching_back_url(): string {
		$old = self::user_switching_old_user();

		if ( ! $old instanceof \WP_User ) {
			return '';
		}

		$instance = \user_switching::get_instance();

		if ( ! is_object( $instance ) || ! method_exists( $instance, 'switch_back_url' ) ) {
			return '';
		}

		$url = self::invoke_user_switching(
			$instance,
			'switch_back_url',
			array( $old, ClientHandoff::get_settings_url() )
		);

		return is_string( $url ) ? $url : '';
	}

	/**
	 * Call a User Switching method with only as many arguments as it accepts.
	 *
	 * @param object $instance Plugin instance.
	 * @param string $method   Method name.
	 * @param array  $args     Arguments, longest form first.
	 * @return mixed
	 */
	private static function invoke_user_switching( $instance, string $method, array $args ) {
		try {
			$reflection = new \ReflectionMethod( $instance, $method );
		} catch ( \ReflectionException $exception ) {
			unset( $exception );
			return '';
		}

		$accepted = $reflection->getNumberOfParameters();

		return $reflection->invokeArgs( $instance, array_slice( $args, 0, $accepted ) );
	}

	/**
	 * Login that is not already registered.
	 */
	private static function unique_preview_login(): string {
		for ( $attempt = 0; $attempt < 8; $attempt++ ) {
			$login = 'dsm_preview_' . strtolower( wp_generate_password( 8, false, false ) );

			if ( strlen( $login ) > 60 ) {
				$login = substr( $login, 0, 60 );
			}

			if ( ! username_exists( $login ) ) {
				return $login;
			}
		}

		return '';
	}

	/**
	 * Site-host email that is not already registered.
	 *
	 * @param string $login Login used as the local part.
	 */
	private static function unique_preview_email( string $login ): string {
		$host = wp_parse_url( home_url(), PHP_URL_HOST );
		$host = is_string( $host ) ? strtolower( $host ) : '';
		$host = preg_replace( '/[^a-z0-9.-]/', '', $host );
		$host = is_string( $host ) ? $host : '';

		if ( '' === $host ) {
			$host = 'localhost.local';
		} elseif ( ! str_contains( $host, '.' ) ) {
			$host .= '.local';
		}

		for ( $attempt = 0; $attempt < 8; $attempt++ ) {
			$local = 0 === $attempt ? $login : $login . $attempt;
			$email = $local . '@' . $host;

			if ( is_email( $email ) && ! email_exists( $email ) ) {
				return $email;
			}
		}

		return '';
	}

	/**
	 * Remove generated preview users that own no content.
	 *
	 * Users with posts, pages, or other content stay in place.
	 *
	 * @return array{deleted: int, kept: int}
	 */
	public static function delete_generated_preview_users(): array {
		$query = new \WP_User_Query(
			array(
				'meta_key'   => self::PREVIEW_USER_META,
				'meta_value' => '1', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
			'number'         => 50,
			'fields'         => 'ID',
			)
		);

		$deleted = 0;
		$kept    = 0;
		$types   = array_values( get_post_types() );

		require_once ABSPATH . 'wp-admin/includes/user.php';

		foreach ( $query->get_results() as $user_id ) {
			$user_id = (int) $user_id;
			$user    = get_userdata( $user_id );

			if ( ! $user instanceof \WP_User ) {
				continue;
			}

			if (
			get_current_user_id() === $user_id
			|| in_array( 'administrator', (array) $user->roles, true )
			|| user_can( $user, 'manage_options' )
			) {
				++$kept;
				continue;
			}

			$owns = count_user_posts( $user_id, $types, false ) > 0;

			/**
			 * Filters whether Exit may delete a Handoff-created preview user.
			 *
			 * @param bool $delete  Whether to delete the user.
			 * @param int  $user_id User ID.
			 */
			$delete = (bool) apply_filters( 'dsm_handoff_delete_preview_user', ! $owns, $user_id );

			if ( ! $delete || $owns ) {
				++$kept;
				continue;
			}

			if ( wp_delete_user( $user_id ) ) {
				++$deleted;
			} else {
				++$kept;
			}
		}

		return array(
			'deleted' => $deleted,
			'kept'    => $kept,
		);
	}
}

require_once __DIR__ . '/dsm-is-handoff-restricted-user.php';
