<?php
/**
 * Custom Cursor extension — site-wide cursor styles with scope rules.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Extensions;

use DiviSupreme\Includes\DsmFrontendAssetRegistry;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Custom Cursor extension bootstrap.
 */
class CustomCursor {

	/**
	 * Wp_options key for global cursor settings.
	 */
	public const OPTION_KEY = 'dsm_custom_cursor_settings';

	/**
	 * Post meta key for per-page enable flag.
	 */
	public const PAGE_META_KEY = 'dsm-custom-cursor-page-enabled';

	/**
	 * Default settings.
	 *
	 * @var array<string, mixed>
	 */
	private array $default_settings = array(
		'is_enabled'               => true,
		'cursor_style'             => 'filled_circle',
		'primary_color'            => '#4161d4',
		'secondary_color'          => '#ffffff',
		'cursor_size'              => '40px',
		'trail_size'               => '72px',
		'animation_speed'          => '0.2',
		'opacity'                  => '1',
		'blend_mode'               => 'normal',
		'hover_scale'              => '2',
		'hover_color'              => '',
		'hover_target_selector'    => 'a, button, [role="button"], #submit',
		'hide_default_cursor'      => 'on',
		'cursor_scope'             => 'entire_site',
		'cursor_scope_include_ids' => '',
		'cursor_scope_exclude_ids' => '',
		'cursor_scope_page_ids'    => '',
	);

	/**
	 * Constructor.
	 */
	public function __construct() {
		$GLOBALS['dsm_custom_cursor_extension'] = $this;

		add_action( 'wp_enqueue_scripts', array( $this, 'maybe_enqueue_frontend_assets' ), 20 );
		add_action(
			'divi_visual_builder_rest_save_post',
			array( $this, 'save_page_settings_from_rest' ),
			10,
			2
		);
	}

	/**
	 * Default settings shape.
	 *
	 * @return array<string, mixed>
	 */
	public function get_default_settings(): array {
		return $this->default_settings;
	}

	/**
	 * Get settings.
	 *
	 * @return array<string, mixed>
	 */
	public function get_settings(): array {
		$saved = get_option( self::OPTION_KEY, array() );

		if ( ! is_array( $saved ) ) {
			$saved = array();
		}

		$settings = wp_parse_args( $saved, $this->default_settings );

		return $this->normalize_scope_list_settings( $settings );
	}

	/**
	 * Save settings.
	 *
	 * @param array<string, mixed> $settings Raw settings from REST/modal.
	 * @return bool
	 */
	public function save_settings( array $settings ): bool {
		$existing = get_option( self::OPTION_KEY, array() );

		if ( ! is_array( $existing ) ) {
			$existing = array();
		}

		$merged = wp_parse_args( $settings, wp_parse_args( $existing, $this->default_settings ) );

		$merged['is_enabled']            = $this->normalize_bool_flag( $merged['is_enabled'] ?? false );
		$merged['cursor_style']          = $this->sanitize_style( (string) $merged['cursor_style'] );
		$merged['primary_color']         = $this->sanitize_color(
			$this->color_value_to_string( $merged['primary_color'] ?? '' ),
			(string) $this->default_settings['primary_color']
		);
		$merged['secondary_color']       = $this->sanitize_color(
			$this->color_value_to_string( $merged['secondary_color'] ?? '' ),
			(string) $this->default_settings['secondary_color']
		);
		$merged['cursor_size']           = sanitize_text_field( (string) $merged['cursor_size'] );
		$merged['trail_size']            = sanitize_text_field( (string) $merged['trail_size'] );
		$merged['animation_speed']       = sanitize_text_field( (string) $merged['animation_speed'] );
		$merged['opacity']               = sanitize_text_field( (string) $merged['opacity'] );
		$merged['blend_mode']            = $this->sanitize_blend_mode( (string) $merged['blend_mode'] );
		$merged['hover_scale']           = sanitize_text_field( (string) $merged['hover_scale'] );
		$merged['hover_color']           = $this->sanitize_color(
			$this->color_value_to_string( $merged['hover_color'] ?? '' ),
			''
		);
		$merged['hover_target_selector'] = sanitize_text_field( (string) $merged['hover_target_selector'] );
		$merged['hide_default_cursor']   = 'on' === $merged['hide_default_cursor'] ? 'on' : 'off';
		$merged['cursor_scope']          = $this->sanitize_scope( (string) $merged['cursor_scope'] );

		$merged = $this->normalize_scope_list_settings( $merged );

		$merged['cursor_scope_include_ids'] = $this->sanitize_page_ids(
			(string) ( $merged['cursor_scope_include_ids'] ?? '' )
		);
		$merged['cursor_scope_exclude_ids'] = $this->sanitize_page_ids(
			(string) ( $merged['cursor_scope_exclude_ids'] ?? '' )
		);
		$merged['cursor_scope_page_ids']    = '';

		update_option( self::OPTION_KEY, $merged );

		return true;
	}

	/**
	 * Normalize on/off, bool, and numeric flags from REST/modal payloads.
	 *
	 * @param mixed $value Raw value.
	 * @return bool
	 */
	private function normalize_bool_flag( $value ): bool {
		if ( is_bool( $value ) ) {
			return $value;
		}

		if ( is_int( $value ) ) {
			return 1 === $value;
		}

		if ( is_string( $value ) ) {
			$normalized = strtolower( trim( $value ) );

			if ( in_array( $normalized, array( '1', 'on', 'true', 'yes' ), true ) ) {
				return true;
			}

			if ( in_array( $normalized, array( '0', 'off', 'false', 'no', '' ), true ) ) {
				return false;
			}
		}

		return ! empty( $value );
	}

	/**
	 * Whether saved settings should activate the cursor on the frontend.
	 *
	 * @param array<string, mixed> $settings Merged settings.
	 * @return bool
	 */
	private function is_cursor_active_for_frontend( array $settings ): bool {
		return $this->normalize_bool_flag( $settings['is_enabled'] ?? false );
	}

	/**
	 * Sanitize style.
	 *
	 * @param string $style Cursor style slug.
	 * @return string
	 */
	private function sanitize_style( string $style ): string {
		$allowed = array(
			'filter_glow_6',
			'filter_glow_5',
			'filter_glow_4',
			'filter_glow_3',
			'filter_glow_2',
			'filter_glow_1',
			'filled_circle',
			'two_circles',
			'svg_emitter',
		);
		$style   = sanitize_key( $style );

		return in_array( $style, $allowed, true ) ? $style : 'filled_circle';
	}

	/**
	 * Sanitize blend mode.
	 *
	 * @param string $blend CSS mix-blend-mode value.
	 * @return string
	 */
	private function sanitize_blend_mode( string $blend ): string {
		$allowed = array(
			'normal',
			'multiply',
			'screen',
			'overlay',
			'darken',
			'lighten',
			'color-dodge',
			'color-burn',
			'hard-light',
			'soft-light',
			'difference',
			'exclusion',
			'hue',
			'saturation',
			'color',
			'luminosity',
		);
		$blend   = sanitize_key( $blend );

		return in_array( $blend, $allowed, true ) ? $blend : 'normal';
	}

	/**
	 * Sanitize scope.
	 *
	 * @param string $scope Scope slug.
	 * @return string
	 */
	private function sanitize_scope( string $scope ): string {
		$allowed = array( 'entire_site', 'include_pages', 'exclude_pages', 'per_page' );
		$scope   = sanitize_key( $scope );

		return in_array( $scope, $allowed, true ) ? $scope : 'entire_site';
	}

	/**
	 * Sanitize page IDs.
	 *
	 * @param string $raw Comma-separated post IDs.
	 * @return string
	 */
	private function sanitize_page_ids( string $raw ): string {
		$parts = array_filter(
			array_map(
				static function ( $id ) {
					$id = absint( trim( (string) $id ) );
					return $id > 0 ? (string) $id : '';
				},
				explode( ',', $raw )
			)
		);

		return implode( ',', array_unique( $parts ) );
	}

	/**
	 * Migrate legacy single list into separate include/exclude keys when needed.
	 *
	 * @param array<string, mixed> $settings Settings array.
	 * @return array<string, mixed>
	 */
	private function normalize_scope_list_settings( array $settings ): array {
		$include = (string) ( $settings['cursor_scope_include_ids'] ?? '' );
		$exclude = (string) ( $settings['cursor_scope_exclude_ids'] ?? '' );
		$legacy  = (string) ( $settings['cursor_scope_page_ids'] ?? '' );

		if ( '' === trim( $include ) && '' === trim( $exclude ) && '' !== trim( $legacy ) ) {
			$scope = $this->sanitize_scope( (string) ( $settings['cursor_scope'] ?? 'entire_site' ) );

			if ( 'exclude_pages' === $scope ) {
				$exclude = $legacy;
			} elseif ( 'include_pages' === $scope ) {
				$include = $legacy;
			}
		}

		$settings['cursor_scope_include_ids'] = $this->sanitize_page_ids( $include );
		$settings['cursor_scope_exclude_ids'] = $this->sanitize_page_ids( $exclude );

		return $settings;
	}

	/**
	 * Parse comma-separated post IDs into int list.
	 *
	 * @param string $raw Comma-separated IDs.
	 * @return int[]
	 */
	private function parse_page_ids_string( string $raw ): array {
		if ( '' === trim( $raw ) ) {
			return array();
		}

		return array_values(
			array_filter(
				array_map(
					'absint',
					explode( ',', $raw )
				)
			)
		);
	}

	/**
	 * Scope IDs for the active display mode.
	 *
	 * @param array<string, mixed> $settings Settings array.
	 * @return int[]
	 */
	private function get_scope_ids_for_active_mode( array $settings ): array {
		$scope = $this->sanitize_scope( (string) ( $settings['cursor_scope'] ?? 'entire_site' ) );

		if ( 'include_pages' === $scope ) {
			return $this->parse_page_ids_string(
				(string) ( $settings['cursor_scope_include_ids'] ?? '' )
			);
		}

		if ( 'exclude_pages' === $scope ) {
			return $this->parse_page_ids_string(
				(string) ( $settings['cursor_scope_exclude_ids'] ?? '' )
			);
		}

		return array();
	}

	/**
	 * Whether the cursor should load on the current frontend request.
	 *
	 * @return bool
	 */
	public function should_load_on_current_request(): bool {
		if ( ! function_exists( 'dsm_is_custom_cursor_extension_enabled' )
			|| ! dsm_is_custom_cursor_extension_enabled() ) {
			return false;
		}

		if ( is_admin() ) {
			return false;
		}

		// Visual Builder canvas iframe: preview lives only in the modal pane (app window).
		if ( function_exists( 'et_core_is_fb_enabled' ) && et_core_is_fb_enabled() ) {
			return false;
		}

		$settings = $this->get_settings();

		if ( ! $this->is_cursor_active_for_frontend( $settings ) ) {
			return false;
		}

		$post_id = (int) get_queried_object_id();
		$scope   = $this->sanitize_scope( (string) ( $settings['cursor_scope'] ?? 'entire_site' ) );
		$ids     = $this->get_scope_ids_for_active_mode( $settings );

		switch ( $scope ) {
			case 'include_pages':
				return $post_id > 0 && in_array( $post_id, $ids, true );

			case 'exclude_pages':
				return $post_id <= 0 || ! in_array( $post_id, $ids, true );

			case 'per_page':
				if ( $post_id <= 0 ) {
					return false;
				}
				$page_flag = get_post_meta( $post_id, self::PAGE_META_KEY, true );
				return 'on' === $page_flag;

			case 'entire_site':
			default:
				return true;
		}
	}

	/**
	 * Persist per-page enable flag from Visual Builder save payload.
	 *
	 * @param int                  $post_id Post ID.
	 * @param array<string, mixed> $data    REST save payload.
	 * @return void
	 */
	public function save_page_settings_from_rest( int $post_id, array $data ): void {
		if ( $post_id <= 0 ) {
			return;
		}

		$page_settings = $data['pageSettings'] ?? array();
		if ( ! is_array( $page_settings ) ) {
			return;
		}

		if ( ! array_key_exists( 'dsm_custom_cursor_page_enabled', $page_settings ) ) {
			return;
		}

		$value = 'on' === $page_settings['dsm_custom_cursor_page_enabled'] ? 'on' : 'off';
		update_post_meta( $post_id, self::PAGE_META_KEY, $value );
	}

	/**
	 * Per-page enable flag for scope `per_page`.
	 *
	 * @param int $post_id Post ID.
	 * @return string `on` or `off`.
	 */
	public function get_page_enabled( int $post_id ): string {
		if ( $post_id <= 0 ) {
			return 'off';
		}

		$flag = get_post_meta( $post_id, self::PAGE_META_KEY, true );

		return 'on' === $flag ? 'on' : 'off';
	}

	/**
	 * Frontend script config for wp_localize_script.
	 *
	 * @return array<string, mixed>
	 */
	public function get_frontend_config(): array {
		$settings = $this->get_settings();

		return array(
			'cursor_style'          => (string) $settings['cursor_style'],
			'style'                 => (string) $settings['cursor_style'],
			'primary_color'         => $this->color_for_css(
				$settings['primary_color'] ?? '',
				(string) $this->default_settings['primary_color']
			),
			'secondary_color'       => $this->color_for_css(
				$settings['secondary_color'] ?? '',
				(string) $this->default_settings['secondary_color']
			),
			'cursor_size'           => (string) $settings['cursor_size'],
			'trail_size'            => (string) $settings['trail_size'],
			'animation_speed'       => (string) $settings['animation_speed'],
			'opacity'               => (string) $settings['opacity'],
			'blend_mode'            => (string) $settings['blend_mode'],
			'hover_scale'           => (string) $settings['hover_scale'],
			'hover_color'           => $this->color_for_css(
				$settings['hover_color'] ?? '',
				''
			),
			'hover_target_selector' => (string) $settings['hover_target_selector'],
			'hide_default_cursor'   => (string) $settings['hide_default_cursor'],
		);
	}

	/**
	 * Flatten a ColorPicker leaf to a persistable string (hex / `$variable` / gcid).
	 *
	 * @param mixed $raw Raw color (string or ColorPicker object).
	 * @return string
	 */
	private function color_value_to_string( $raw ): string {
		if ( is_string( $raw ) ) {
			return trim( $raw );
		}

		if ( ! is_array( $raw ) ) {
			return '';
		}

		$type = isset( $raw['type'] ) ? strtolower( (string) $raw['type'] ) : '';
		$name = '';
		if ( isset( $raw['value']['name'] ) && is_string( $raw['value']['name'] ) ) {
			$name = trim( $raw['value']['name'] );
		}

		if ( '' !== $name && ( '' === $type || 'color' === $type || 'variable' === $type ) ) {
			$encoded = wp_json_encode(
				array(
					'type'  => 'color',
					'value' => array(
						'name' => $name,
					),
				)
			);

			return is_string( $encoded ) ? '$variable(' . $encoded . ')$' : '';
		}

		if ( isset( $raw['hex'] ) && is_string( $raw['hex'] ) ) {
			return trim( $raw['hex'] );
		}

		if ( isset( $raw['cssVariable'] ) && is_string( $raw['cssVariable'] ) ) {
			return trim( $raw['cssVariable'] );
		}

		if ( isset( $raw['value'] ) && is_string( $raw['value'] ) ) {
			return trim( $raw['value'] );
		}

		return '';
	}

	/**
	 * Sanitize a hex, rgba, or Divi variable color.
	 *
	 * @param string $color          Raw color.
	 * @param string $fallback_color Fallback (empty allowed for optional hover).
	 * @return string
	 */
	private function sanitize_color( string $color, string $fallback_color ): string {
		$color = trim( $color );

		if ( '' === $color ) {
			return $fallback_color;
		}

		if ( strlen( $color ) > 800 ) {
			return $fallback_color;
		}

		if ( preg_match( '/[<>`]|(\x00)/', $color ) ) {
			return $fallback_color;
		}

		if ( preg_match( '/\b(?:expression|behavior|javascript|@import)\b/i', $color ) ) {
			return $fallback_color;
		}

		if ( function_exists( 'sanitize_hex_color' ) ) {
			$hex = sanitize_hex_color( $color );
			if ( is_string( $hex ) && '' !== $hex ) {
				return $hex;
			}
		}

		if ( preg_match( '/^(#([0-9a-fA-F]{3}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})|rgba?\([^;{}]+\)|hsla?\([^;{}]+\)|var\(--[a-zA-Z0-9_-]+(?:,\s*[^;{}]+)?\))$/', $color ) ) {
			return $color;
		}

		if ( preg_match( '/^gcid-[a-zA-Z0-9_-]+$/', $color ) ) {
			return $color;
		}

		$variable_name = $this->extract_divi_color_variable_name( $color );
		if ( is_string( $variable_name ) && '' !== $variable_name ) {
			return $color;
		}

		return $fallback_color;
	}

	/**
	 * Extract a safe CSS custom-property name from a Divi `$variable({…})$` token.
	 *
	 * @param string $color Raw ColorPicker value.
	 * @return string|null
	 */
	private function extract_divi_color_variable_name( string $color ): ?string {
		$color = trim( $color );
		if ( ! str_starts_with( $color, '$variable(' ) || ! str_ends_with( $color, ')$' ) ) {
			return null;
		}

		$payload = substr( $color, strlen( '$variable(' ), -2 );
		$decoded = json_decode( $payload, true );
		if ( ! is_array( $decoded ) ) {
			$decoded = json_decode( stripslashes( $payload ), true );
		}
		if ( ! is_array( $decoded ) ) {
			return null;
		}

		$type = isset( $decoded['type'] ) ? strtolower( (string) $decoded['type'] ) : '';
		if ( '' !== $type && 'color' !== $type && 'variable' !== $type ) {
			return null;
		}

		$name = '';
		if ( isset( $decoded['value']['name'] ) && is_string( $decoded['value']['name'] ) ) {
			$name = $decoded['value']['name'];
		} elseif ( isset( $decoded['value'] ) && is_string( $decoded['value'] ) ) {
			$name = $decoded['value'];
		}

		$name = ltrim( trim( $name ), '-' );
		if ( '' === $name || ! preg_match( '/^[a-zA-Z0-9_-]+$/', $name ) ) {
			return null;
		}

		return $name;
	}

	/**
	 * CSS paint for cursor SVG / CSS (`var(--gcid-…)` or concrete hex/rgba).
	 *
	 * @param mixed  $raw      Stored color.
	 * @param string $fallback Fallback paint.
	 * @return string
	 */
	private function color_for_css( $raw, string $fallback ): string {
		$normalized = $this->normalize_color_for_css( $this->color_value_to_string( $raw ) );

		return '' !== $normalized ? $normalized : $fallback;
	}

	/**
	 * Soft-migrate a stored ColorPicker value to a CSS paint string.
	 *
	 * @param string $color Sanitized stored color.
	 * @return string
	 */
	private function normalize_color_for_css( string $color ): string {
		$color = trim( $color );
		if ( '' === $color ) {
			return '';
		}

		$variable_name = $this->extract_divi_color_variable_name( $color );
		if ( ! is_string( $variable_name ) || '' === $variable_name ) {
			if ( preg_match( '/^gcid-[a-zA-Z0-9_-]+$/', $color ) ) {
				$variable_name = $color;
			}
		}

		if ( is_string( $variable_name ) && '' !== $variable_name ) {
			$resolved = $this->resolve_divi_global_color_paint( $color, $variable_name );
			if ( '' !== $resolved ) {
				return $resolved;
			}

			return 'var(--' . $variable_name . ')';
		}

		if ( class_exists( '\ET\Builder\Packages\GlobalData\GlobalData' )
			&& 0 === stripos( $color, 'var(' )
		) {
			$gcid = \ET\Builder\Packages\GlobalData\GlobalData::get_global_color_id_from_value( $color );
			if ( is_string( $gcid ) && '' !== $gcid ) {
				$resolved = $this->resolve_divi_global_color_paint( $color, $gcid );
				if ( '' !== $resolved ) {
					return $resolved;
				}
			}

			return $color;
		}

		if ( false !== strpos( $color, '$variable(' ) ) {
			return '';
		}

		return $color;
	}

	/**
	 * Resolve a Divi global colour id / `$variable` token to a concrete CSS paint.
	 *
	 * @param string $raw  Original stored value.
	 * @param string $gcid Normalised `gcid-…` id.
	 * @return string Concrete hex/rgba/hsl, or empty when unresolvable.
	 */
	private function resolve_divi_global_color_paint( string $raw, string $gcid ): string {
		if ( ! class_exists( '\ET\Builder\Packages\GlobalData\GlobalData' ) ) {
			return '';
		}

		$global_colors = \ET\Builder\Packages\GlobalData\GlobalData::get_global_colors();
		$candidates    = array( $raw, $gcid );

		foreach ( $candidates as $candidate ) {
			if ( ! is_string( $candidate ) || '' === trim( $candidate ) ) {
				continue;
			}

			$resolved = \ET\Builder\Packages\GlobalData\GlobalData::resolve_global_color_variable(
				$candidate,
				$global_colors
			);

			$paint = $this->concrete_css_paint_from_resolved( is_string( $resolved ) ? $resolved : '' );
			if ( '' !== $paint ) {
				return $paint;
			}
		}

		$color_data = \ET\Builder\Packages\GlobalData\GlobalData::get_global_color_by_id( $gcid );
		$palette    = is_array( $color_data ) ? ( $color_data['color'] ?? '' ) : '';
		if ( ! is_string( $palette ) || '' === trim( $palette ) ) {
			return '';
		}

		$nested = \ET\Builder\Packages\GlobalData\GlobalData::resolve_global_color_variable(
			trim( $palette ),
			$global_colors
		);

		$paint = $this->concrete_css_paint_from_resolved( is_string( $nested ) ? $nested : '' );
		if ( '' !== $paint ) {
			return $paint;
		}

		return $this->concrete_css_paint_from_resolved( trim( $palette ) );
	}

	/**
	 * Accept only concrete CSS colour paints (reject leftover tokens / var()).
	 *
	 * @param string $value Resolved candidate.
	 * @return string
	 */
	private function concrete_css_paint_from_resolved( string $value ): string {
		$value = trim( $value );
		if ( '' === $value ) {
			return '';
		}

		if ( false !== strpos( $value, '$variable(' ) ) {
			return '';
		}

		if ( 0 === stripos( $value, 'var(' ) ) {
			return '';
		}

		if ( preg_match( '/^gcid-[a-zA-Z0-9_-]+$/', $value ) ) {
			return '';
		}

		if ( function_exists( 'sanitize_hex_color' ) ) {
			$hex = sanitize_hex_color( $value );
			if ( is_string( $hex ) && '' !== $hex ) {
				return $hex;
			}
		}

		if ( preg_match( '/^(#([0-9a-fA-F]{3}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})|rgba?\([^;{}]+\)|hsla?\([^;{}]+\))$/', $value ) ) {
			return $value;
		}

		return '';
	}

	/**
	 * Enqueue frontend bundle when scope matches.
	 *
	 * @return void
	 */
	public function maybe_enqueue_frontend_assets(): void {
		if ( ! $this->should_load_on_current_request() ) {
			return;
		}

		if ( ! wp_script_is( 'dsm-custom-cursor-frontend', 'registered' ) ) {
			return;
		}

		// CSS: merged into Divi's dynamic bundle when the pipeline is active.
		if ( ! DsmFrontendAssetRegistry::should_use_divi_dynamic_assets_pipeline() ) {
			wp_enqueue_style( 'dsm-custom-cursor-frontend' );
		}

		// JS: always wp_enqueue (Divi Dynamic Assets does not merge scripts).
		wp_enqueue_script( 'dsm-custom-cursor-frontend' );

		wp_localize_script(
			'dsm-custom-cursor-frontend',
			'dsmCustomCursorConfig',
			$this->get_frontend_config()
		);
	}
}

new CustomCursor();
