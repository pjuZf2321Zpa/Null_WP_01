<?php
/**
 * Dark Mode per-element background overrides (section / row / column).
 *
 * Emits FE CSS under html.dsm-dark with enough specificity to beat Divi's
 * layout-scoped section/row/column background !important rules.
 * Full BackgroundStyle (color / gradient / image) via twin attr
 * dsm_dm_background.decoration.background. Soft-migrates legacy
 * dsm_dm_background_color. Does not mutate module.decoration.background.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Extensions;

use DiviSupreme\Includes\DsmDiviBuilderCssScope;
use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\Module\Options\Background\BackgroundStyle;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Frontend style bag for Dark Mode Overrides on structural Divi blocks.
 */
class DarkModeOverrides {

	/**
	 * Structural blocks that support overrides.
	 *
	 * @var array<int, string>
	 */
	public const TARGET_BLOCKS = array(
		'divi/section',
		'divi/row',
		'divi/row-inner',
		'divi/column',
		'divi/column-inner',
	);

	/**
	 * Module name → FE structural class (paired with order class for specificity).
	 *
	 * @var array<string, string>
	 */
	private const STRUCTURAL_BASE_CLASS = array(
		'divi/section'      => '.et_pb_section',
		'divi/row'          => '.et_pb_row',
		'divi/row-inner'    => '.et_pb_row_inner',
		'divi/column'       => '.et_pb_column',
		'divi/column-inner' => '.et_pb_column_inner',
	);

	/**
	 * Constructor.
	 */
	public function __construct() {
		if ( ! function_exists( 'dsm_is_dark_mode_extension_enabled' ) || ! dsm_is_dark_mode_extension_enabled() ) {
			return;
		}

		add_filter( 'divi_module_wrapper_render', array( $this, 'filter_wrapper_render_styles' ), 12, 2 );
	}

	/**
	 * Is target block.
	 *
	 * @param string $module_name Module name.
	 * @return bool
	 */
	public static function is_target_block( string $module_name ): bool {
		return in_array( $module_name, self::TARGET_BLOCKS, true );
	}

	/**
	 * Build a FE selector that beats Divi critical background rules.
	 *
	 * Divi emits e.g. `.et-l--post>.et_builder_inner_content .et_pb_section.et_pb_section_0`
	 * at (0,4,0) + !important. Plain `html.dsm-dark .et_pb_section_0` is (0,2,1) and loses.
	 * Scoping under `.et-l .et_builder_inner_content` plus the structural class yields (0,5,1).
	 *
	 * Also includes Theme Builder layout areas and VB `#et-fb-app-*-root` mount points so
	 * header/footer sections match when they are not under the usual inner-content path.
	 *
	 * @param string $order_class Module order class (may include TB/CPT prefix).
	 * @param string $module_name Module name (e.g. divi/section).
	 * @return string Comma-separated selector list.
	 */
	public static function build_background_selector( string $order_class, string $module_name ): string {
		$order_class = trim( $order_class );
		if ( '' === $order_class ) {
			return '';
		}

		if ( class_exists( DsmDiviBuilderCssScope::class ) ) {
			$order_class = DsmDiviBuilderCssScope::strip_builder_css_prefix_from_order_class( $order_class );
		}

		$order_class = trim( $order_class );
		if ( '' === $order_class ) {
			return '';
		}

		if ( '.' !== $order_class[0] ) {
			$order_class = '.' . ltrim( $order_class, '.' );
		}

		$base = self::STRUCTURAL_BASE_CLASS[ $module_name ] ?? '';
		$leaf = '' !== $base ? $base . $order_class : $order_class;

		$selectors = array(
			'html.dsm-dark .et-l .et_builder_inner_content ' . $leaf,
		);

		if ( class_exists( DsmDiviBuilderCssScope::class ) && DsmDiviBuilderCssScope::needs_builder_css_prefix() ) {
			// CPT/TB: Divi backgrounds are often under `.et-db #et-boc .et-l …`.
			array_unshift(
				$selectors,
				'html.dsm-dark ' . trim( DsmDiviBuilderCssScope::SELECTOR_PREFIX ) . ' .et_builder_inner_content ' . $leaf
			);
		}

		// Theme Builder layout wrappers (header/body/footer) — same leaf, area-scoped.
		foreach ( array( 'header', 'body', 'footer' ) as $area ) {
			$selectors[] = 'html.dsm-dark .et-l--' . $area . ' ' . $leaf;
		}

		// Visual Builder portals TB areas into `#et-fb-app-*-root` (may omit `.et_builder_inner_content`).
		foreach ( array( 'header', 'body', 'footer' ) as $area ) {
			$selectors[] = 'html.dsm-dark #et-fb-app-' . $area . '-root ' . $leaf;
		}

		$selectors = array_values( array_unique( array_filter( array_map( 'trim', $selectors ) ) ) );

		return implode( ', ', $selectors );
	}

	/**
	 * Selector that clears opaque Menu module backgrounds inside a section override.
	 *
	 * Uses :where() so specificity stays low — a future per-menu dark override can win.
	 *
	 * @param string $section_selector Output of {@see build_background_selector()} for a section.
	 * @return string
	 */
	public static function build_nested_menu_transparent_selector( string $section_selector ): string {
		$section_selector = trim( $section_selector );
		if ( '' === $section_selector ) {
			return '';
		}

		$parts = preg_split( '/\s*,\s*/', $section_selector );
		if ( ! is_array( $parts ) ) {
			$parts = array();
		}
		$out = array();

		foreach ( $parts as $part ) {
			$part = trim( (string) $part );
			if ( '' === $part ) {
				continue;
			}
			$out[] = ':where(' . $part . ') .et_pb_menu';
		}

		return implode( ', ', $out );
	}

	/**
	 * Soft-migrate legacy solid color into twin decoration.background (in-memory).
	 *
	 * Keeps `dsm_dm_background_color`. Skips when non-color layers already present
	 * or an explicit color already exists on the twin attr.
	 *
	 * @param array<string, mixed> $attrs Module attrs reference.
	 * @return void
	 */
	public static function soft_migrate_legacy_background_color( array &$attrs ): void {
		if ( empty( $attrs['dsm_dm_background_color'] ) || ! is_array( $attrs['dsm_dm_background_color'] ) ) {
			return;
		}

		$legacy = $attrs['dsm_dm_background_color']['innerContent'] ?? null;
		if ( ! is_array( $legacy ) ) {
			return;
		}

		if ( ! isset( $attrs['dsm_dm_background'] ) || ! is_array( $attrs['dsm_dm_background'] ) ) {
			$attrs['dsm_dm_background'] = array();
		}

		if ( ! isset( $attrs['dsm_dm_background']['decoration'] ) || ! is_array( $attrs['dsm_dm_background']['decoration'] ) ) {
			$attrs['dsm_dm_background']['decoration'] = array();
		}

		if ( ! isset( $attrs['dsm_dm_background']['decoration']['background'] ) || ! is_array( $attrs['dsm_dm_background']['decoration']['background'] ) ) {
			$attrs['dsm_dm_background']['decoration']['background'] = array();
		}

		$background = &$attrs['dsm_dm_background']['decoration']['background'];

		foreach ( array( 'desktop', 'tablet', 'phone' ) as $bp ) {
			$bp_legacy = $legacy[ $bp ] ?? null;
			if ( ! is_array( $bp_legacy ) ) {
				continue;
			}

			$color = self::extract_legacy_inner_color_string( $bp_legacy['value'] ?? null );
			if ( '' === $color ) {
				continue;
			}

			$existing_val = array();
			if ( isset( $background[ $bp ]['value'] ) && is_array( $background[ $bp ]['value'] ) ) {
				$existing_val = $background[ $bp ]['value'];
			}

			if ( self::background_value_has_non_color_layers( $existing_val ) ) {
				continue;
			}

			$existing_color = isset( $existing_val['color'] ) && is_string( $existing_val['color'] )
				? trim( $existing_val['color'] )
				: '';
			if ( '' !== $existing_color ) {
				continue;
			}

			$background[ $bp ] = array(
				'value' => array_merge(
					$existing_val,
					array(
						'color'       => $color,
						'enableColor' => 'on',
					)
				),
			);
		}
	}

	/**
	 * Extract legacy inner color string.
	 *
	 * @param mixed $raw Value at innerContent.{bp}.value.
	 * @return string
	 */
	public static function extract_legacy_inner_color_string( $raw ): string {
		if ( is_string( $raw ) ) {
			return trim( $raw );
		}

		if ( is_array( $raw ) ) {
			foreach ( array( 'hex', 'rgba', 'color', 'value' ) as $color_key ) {
				$piece = $raw[ $color_key ] ?? null;
				if ( is_string( $piece ) && '' !== trim( $piece ) ) {
					return trim( $piece );
				}
			}
		}

		if ( is_scalar( $raw ) ) {
			return trim( (string) $raw );
		}

		return '';
	}

	/**
	 * Background value has non color layers.
	 *
	 * @param array<string, mixed> $val decoration.background.*.value node.
	 * @return bool
	 */
	public static function background_value_has_non_color_layers( array $val ): bool {
		if ( isset( $val['gradient'] ) && is_array( $val['gradient'] ) && array() !== $val['gradient'] ) {
			return true;
		}

		if ( isset( $val['video'] ) && is_array( $val['video'] ) && array() !== $val['video'] ) {
			return true;
		}

		if ( isset( $val['pattern'] ) && is_array( $val['pattern'] ) && array() !== $val['pattern'] ) {
			return true;
		}

		if ( isset( $val['mask'] ) && is_array( $val['mask'] ) && array() !== $val['mask'] ) {
			return true;
		}

		$image = $val['image'] ?? null;
		if ( is_array( $image ) ) {
			foreach ( array( 'url', 'src' ) as $image_key ) {
				$url = $image[ $image_key ] ?? '';
				if ( is_string( $url ) && '' !== trim( $url ) ) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Whether twin background attr has any paint (color / gradient / image).
	 *
	 * @param array<string, mixed> $attrs Attrs (after soft-migrate).
	 * @return bool
	 */
	public static function attrs_have_background_paint( array $attrs ): bool {
		$bg = $attrs['dsm_dm_background']['decoration']['background'] ?? null;
		if ( ! is_array( $bg ) ) {
			return false;
		}

		foreach ( array( 'desktop', 'tablet', 'phone' ) as $bp ) {
			$val = $bg[ $bp ]['value'] ?? null;
			if ( ! is_array( $val ) ) {
				continue;
			}

			$color = isset( $val['color'] ) && is_string( $val['color'] ) ? trim( $val['color'] ) : '';
			if ( '' !== $color ) {
				return true;
			}

			if ( self::background_value_has_non_color_layers( $val ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Emit dark-mode background override via Divi Style bag.
	 *
	 * @param string               $module_wrapper Wrapper HTML.
	 * @param array<string, mixed> $args           Wrapper filter args.
	 * @return string
	 */
	public function filter_wrapper_render_styles( $module_wrapper, $args ): string {
		if ( ! is_string( $module_wrapper ) ) {
			$module_wrapper = '';
		}

		if ( ! is_array( $args ) ) {
			return $module_wrapper;
		}

		$module_name = isset( $args['name'] ) ? (string) $args['name'] : '';
		if ( ! self::is_target_block( $module_name ) ) {
			return $module_wrapper;
		}

		$attrs = isset( $args['attrs'] ) && is_array( $args['attrs'] ) ? $args['attrs'] : array();
		if ( ! self::attrs_enabled( $attrs ) ) {
			return $module_wrapper;
		}

		self::soft_migrate_legacy_background_color( $attrs );

		$elements = $args['elements'] ?? null;
		if ( ! is_object( $elements ) ) {
			return $module_wrapper;
		}

		if ( ! class_exists( Style::class ) ) {
			return $module_wrapper;
		}

		$order_class = isset( $elements->order_class ) ? (string) $elements->order_class : '';
		if ( '' === $order_class ) {
			return $module_wrapper;
		}

		$selector = self::build_background_selector( $order_class, $module_name );

		/**
		 * Filter the CSS selector used for Dark Mode background overrides.
		 *
		 * @param string               $selector    Full selector including html.dsm-dark.
		 * @param string               $order_class Module order class.
		 * @param string               $module_name Module name.
		 * @param array<string, mixed> $attrs       Module attrs.
		 */
		$selector = (string) apply_filters(
			'dsm_dark_mode_overrides_background_selector',
			$selector,
			$order_class,
			$module_name,
			$attrs
		);

		if ( '' === trim( $selector ) ) {
			return $module_wrapper;
		}

		$has_full_bg = self::attrs_have_background_paint( $attrs );
		$bg_attr     = $attrs['dsm_dm_background']['decoration']['background'] ?? null;
		$style_id    = (string) ( $args['id'] ?? '' );
		$order_index = (int) ( $args['orderIndex'] ?? 0 );
		$store_inst  = (int) ( $args['storeInstance'] ?? 0 );

		// Prefer BackgroundStyle with soft-migrated twin attr (color / gradient / image).
		// Do not rely on elements->style — structural modules omit dsm_dm_* from metadata.
		if ( $has_full_bg && is_array( $bg_attr ) && array() !== $bg_attr && class_exists( BackgroundStyle::class ) ) {
			Style::add(
				array(
					'id'            => $style_id,
					'name'          => $module_name,
					'orderIndex'    => $order_index,
					'storeInstance' => $store_inst,
					'styles'        => array(
						BackgroundStyle::style(
							array(
								'selector'  => $selector,
								'attr'      => $bg_attr,
								'important' => true,
							)
						),
					),
				)
			);

			self::maybe_add_nested_menu_transparent_style(
				$module_name,
				$selector,
				$style_id,
				$order_index,
				$store_inst
			);
		} else {
			// Legacy solid-only fallback (pre-BackgroundGroup layouts).
			$color_inner = isset( $attrs['dsm_dm_background_color']['innerContent'] ) && is_array( $attrs['dsm_dm_background_color']['innerContent'] )
				? $attrs['dsm_dm_background_color']['innerContent']
				: array();

			if ( ! isset( $color_inner['desktop']['value'] ) ) {
				$twin_color = $attrs['dsm_dm_background']['decoration']['background']['desktop']['value']['color'] ?? '';
				if ( is_string( $twin_color ) && '' !== trim( $twin_color ) ) {
					$color_inner = array(
						'desktop' => array(
							'value' => $twin_color,
						),
					);
				}
			}

			$color_raw = isset( $color_inner['desktop']['value'] )
				? self::stringify_color_leaf( $color_inner['desktop']['value'] )
				: '';
			if ( '' !== trim( $color_raw ) ) {
				$is_dynamic = false !== strpos( $color_raw, '$variable(' );
				if ( ( $is_dynamic || '' !== self::sanitize_override_color( $color_raw ) ) && class_exists( CommonStyle::class ) ) {
					Style::add(
						array(
							'id'            => $style_id,
							'name'          => $module_name,
							'orderIndex'    => $order_index,
							'storeInstance' => $store_inst,
							'styles'        => array(
								CommonStyle::style(
									array(
										'selector'  => $selector,
										'attr'      => $color_inner,
										'property'  => 'background-color',
										'important' => true,
									)
								),
							),
						)
					);

					self::maybe_add_nested_menu_transparent_style(
						$module_name,
						$selector,
						$style_id,
						$order_index,
						$store_inst
					);
				}
			}
		}

		// Text / heading / link / border colour overrides (independent of background paint).
		self::maybe_add_color_override_styles(
			$attrs,
			$selector,
			$module_name,
			$style_id,
			$order_index,
			$store_inst
		);

		return $module_wrapper;
	}

	/**
	 * Emit optional text / heading / link / border colour overrides under html.dsm-dark.
	 *
	 * @param array<string, mixed> $attrs       Module attrs.
	 * @param string               $selector    Background selector list.
	 * @param string               $module_name Module name.
	 * @param string               $style_id    Style bag id.
	 * @param int                  $order_index Order index.
	 * @param int                  $store_inst  Store instance.
	 * @return void
	 */
	private static function maybe_add_color_override_styles(
		array $attrs,
		string $selector,
		string $module_name,
		string $style_id,
		int $order_index,
		int $store_inst
	): void {
		if ( ! class_exists( CommonStyle::class ) || ! class_exists( Style::class ) ) {
			return;
		}

		self::maybe_add_one_color_override_style(
			$attrs,
			'dsm_dm_text_color',
			$selector,
			'color',
			$module_name,
			$style_id,
			$order_index,
			$store_inst
		);
		self::maybe_add_one_color_override_style(
			$attrs,
			'dsm_dm_border_color',
			$selector,
			'border-color',
			$module_name,
			$style_id,
			$order_index,
			$store_inst
		);
		self::maybe_add_one_color_override_style(
			$attrs,
			'dsm_dm_heading_color',
			self::descendant_selector(
				$selector,
				array( ' h1', ' h2', ' h3', ' h4', ' h5', ' h6' )
			),
			'color',
			$module_name,
			$style_id,
			$order_index,
			$store_inst
		);
		self::maybe_add_one_color_override_style(
			$attrs,
			'dsm_dm_link_color',
			self::descendant_selector( $selector, array( ' a' ) ),
			'color',
			$module_name,
			$style_id,
			$order_index,
			$store_inst
		);
		self::maybe_add_one_color_override_style(
			$attrs,
			'dsm_dm_link_hover_color',
			self::descendant_selector(
				$selector,
				array( ' a:hover', ' a:focus-visible' )
			),
			'color',
			$module_name,
			$style_id,
			$order_index,
			$store_inst
		);
	}

	/**
	 * Append descendant suffixes to each comma-separated parent selector.
	 *
	 * @param string             $selector Parent selector list.
	 * @param array<int, string> $suffixes Descendants such as ' h1' or ' a:hover'.
	 * @return string
	 */
	private static function descendant_selector( string $selector, array $suffixes ): string {
		$out   = array();
		$parts = preg_split( '/\s*,\s*/', $selector );
		if ( ! is_array( $parts ) ) {
			$parts = array();
		}

		foreach ( $parts as $part ) {
			$part = trim( (string) $part );
			if ( '' === $part ) {
				continue;
			}

			foreach ( $suffixes as $suffix ) {
				$out[] = $part . $suffix;
			}
		}

		return implode( ', ', $out );
	}

	/**
	 * Emit a colour override when the attr has a usable value.
	 *
	 * @param array<string, mixed> $attrs       Module attrs.
	 * @param string               $attr_key    Colour attr key.
	 * @param string               $selector    Target selector list.
	 * @param string               $property    CSS property.
	 * @param string               $module_name Module name.
	 * @param string               $style_id    Style bag id.
	 * @param int                  $order_index Order index.
	 * @param int                  $store_inst  Store instance.
	 * @return void
	 */
	private static function maybe_add_one_color_override_style(
		array $attrs,
		string $attr_key,
		string $selector,
		string $property,
		string $module_name,
		string $style_id,
		int $order_index,
		int $store_inst
	): void {
		if ( '' === $selector ) {
			return;
		}

		$inner = isset( $attrs[ $attr_key ]['innerContent'] ) && is_array( $attrs[ $attr_key ]['innerContent'] )
			? $attrs[ $attr_key ]['innerContent']
			: null;
		if ( ! is_array( $inner ) || ! isset( $inner['desktop']['value'] ) ) {
			return;
		}

		$raw = self::stringify_color_leaf( $inner['desktop']['value'] );
		if ( '' === trim( $raw ) ) {
			return;
		}

		$is_dynamic = false !== strpos( $raw, '$variable(' );
		if ( ! $is_dynamic && '' === self::sanitize_override_color( $raw ) ) {
			return;
		}

		Style::add(
			array(
				'id'            => $style_id,
				'name'          => $module_name,
				'orderIndex'    => $order_index,
				'storeInstance' => $store_inst,
				'styles'        => array(
					CommonStyle::style(
						array(
							'selector'  => $selector,
							'attr'      => $inner,
							'property'  => $property,
							'important' => true,
						)
					),
				),
			)
		);
	}

	/**
	 * TB headers often put an opaque Menu module over the section — clear it in dark mode
	 * so the section Dark Mode Override background is visible.
	 *
	 * @param string $module_name  Module name.
	 * @param string $selector     Section background selector list.
	 * @param string $style_id     Style bag id.
	 * @param int    $order_index  Order index.
	 * @param int    $store_inst   Store instance.
	 * @return void
	 */
	private static function maybe_add_nested_menu_transparent_style(
		string $module_name,
		string $selector,
		string $style_id,
		int $order_index,
		int $store_inst
	): void {
		if ( 'divi/section' !== $module_name || ! class_exists( CommonStyle::class ) || ! class_exists( Style::class ) ) {
			return;
		}

		$menu_selector = self::build_nested_menu_transparent_selector( $selector );
		if ( '' === $menu_selector ) {
			return;
		}

		Style::add(
			array(
				'id'            => $style_id,
				'name'          => $module_name,
				'orderIndex'    => $order_index,
				'storeInstance' => $store_inst,
				'styles'        => array(
					CommonStyle::style(
						array(
							'selector'  => $menu_selector,
							'attr'      => array(
								'desktop' => array(
									'value' => 'transparent',
								),
							),
							'property'  => 'background-color',
							'important' => true,
						)
					),
				),
			)
		);
	}

	/**
	 * Attrs enabled.
	 *
	 * @param array<string, mixed> $attrs Attrs.
	 * @return bool
	 */
	public static function attrs_enabled( array $attrs ): bool {
		return 'on' === strtolower( self::attrs_scalar( $attrs, 'dsm_dm_overrides_enabled', 'off' ) );
	}

	/**
	 * Attrs scalar.
	 *
	 * @param array<string, mixed> $attrs   Attrs.
	 * @param string               $key     Attr key.
	 * @param string               $default Default.
	 * @return string
	 */
	public static function attrs_scalar( array $attrs, string $key, string $default = '' ): string {
		if ( empty( $attrs[ $key ] ) || ! is_array( $attrs[ $key ] ) ) {
			return $default;
		}

		$value = $attrs[ $key ]['innerContent']['desktop']['value'] ?? $default;

		if ( is_array( $value ) && isset( $value['text'] ) ) {
			return (string) $value['text'];
		}

		if ( is_array( $value ) && isset( $value['value'] ) ) {
			return self::stringify_color_leaf( $value );
		}

		return is_scalar( $value ) ? (string) $value : $default;
	}

	/**
	 * Normalize Color control leaf to string.
	 *
	 * @param mixed $leaf Stored value.
	 * @param int   $depth Recursion guard.
	 * @return string
	 */
	public static function stringify_color_leaf( $leaf, int $depth = 0 ): string {
		if ( $depth > 8 ) {
			return '';
		}

		if ( is_string( $leaf ) ) {
			return $leaf;
		}

		if ( is_int( $leaf ) || is_float( $leaf ) ) {
			return (string) $leaf;
		}

		if ( is_array( $leaf ) && isset( $leaf['value'] ) ) {
			return self::stringify_color_leaf( $leaf['value'], $depth + 1 );
		}

		return '';
	}

	/**
	 * Sanitize solid color for CSS (hex / rgb(a) / hsl(a) / var() / keywords).
	 *
	 * @param string $color Raw color.
	 * @return string Empty string when rejected.
	 */
	public static function sanitize_override_color( string $color ): string {
		$color = trim( wp_strip_all_tags( $color ) );

		if ( '' === $color || strlen( $color ) > 350 ) {
			return '';
		}

		if ( preg_match( '/[<>"`\\\\]|\x00|;|}/', $color ) ) {
			return '';
		}

		if ( preg_match( '/\b(?:expression|behavior|javascript|@import)\b/i', $color ) ) {
			return '';
		}

		if ( function_exists( 'sanitize_hex_color' ) ) {
			$hex = sanitize_hex_color( $color );
			if ( is_string( $hex ) && '' !== $hex ) {
				return $hex;
			}
		}

		if ( preg_match( '/^(?:currentcolor|inherit|transparent)$/i', $color ) ) {
			return $color;
		}

		if (
			preg_match( '/^(#([0-9a-fA-F]{3}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})|rgba?\([^)]+\)|hsla?\([^)]+\)|var\(--[a-zA-Z0-9_-]+(?:,\s*[^)]+)?\))$/', $color )
		) {
			return sanitize_text_field( $color );
		}

		return '';
	}
}

new DarkModeOverrides();
