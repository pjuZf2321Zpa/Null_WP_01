<?php
/**
 * Section / Row / Column password protection (block-level gate).
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Extensions;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * FE gate + read-only block index for structural Divi blocks.
 *
 * Never rewrite `post_content` with parse_blocks/serialize_blocks — that corrupts
 * Divi 5 dynamic content (`$variable`) and can fail Visual Builder saves.
 * Hashing / target_id assignment happens in the VB via REST before save.
 */
class PasswordProtectionBlock {

	/**
	 * Post meta: map of target_id => { entries, version, blockName }.
	 */
	public const META_BLOCK_INDEX = '_dsm_pp_block_index';

	/**
	 * Block names that support Protection in Phase A.
	 *
	 * @var array<int, string>
	 */
	public const TARGET_BLOCKS = array(
		'divi/section',
		'divi/row',
		'divi/row-inner',
		'divi/column',
		'divi/column-inner',
	);

	/**
	 * Whether nocache headers were sent for a protected block this request.
	 *
	 * @var bool
	 */
	private bool $sent_nocache = false;

	/**
	 * Whether block-gate form styles were printed this request.
	 *
	 * @var bool
	 */
	private bool $printed_form_styles = false;

	/**
	 * Parent PasswordProtection instance.
	 *
	 * @var PasswordProtection
	 */
	private PasswordProtection $protection;

	/**
	 * Constructor.
	 *
	 * @param PasswordProtection $protection Parent gate.
	 */
	public function __construct( PasswordProtection $protection ) {
		$this->protection = $protection;

		add_filter( 'render_block', array( $this, 'filter_render_block' ), 22, 2 );
		add_filter( 'divi_module_wrapper_render', array( $this, 'filter_wrapper_render_styles' ), 10, 2 );
		add_action( 'save_post', array( $this, 'maybe_rebuild_block_index_on_save' ), 20, 2 );
		add_action( 'rest_api_init', array( $this, 'register_rest_routes' ) );
	}

	/**
	 * Emit Design-tab form styles (title / field / button) for protected structural blocks.
	 *
	 * Section/Row/Column stylesComponent does not call elements->style() for dsm_pp_* attrs.
	 * Core block metadata also omits those attrs, so selectors/styleProps are passed explicitly.
	 *
	 * @param string              $module_wrapper Wrapper HTML.
	 * @param array<string,mixed> $args           Wrapper filter args.
	 * @return string
	 */
	public function filter_wrapper_render_styles( $module_wrapper, $args ): string {
		if ( ! is_string( $module_wrapper ) ) {
			$module_wrapper = '';
		}

		if ( ! is_array( $args ) ) {
			return $module_wrapper;
		}

		$module_name = isset( $args['name'] ) ? (string) $args['name'] : '';
		if ( ! self::is_target_block( $module_name ) ) {
			return $module_wrapper;
		}

		$attrs = isset( $args['attrs'] ) && is_array( $args['attrs'] ) ? $args['attrs'] : array();
		if ( ! self::attrs_enabled( $attrs ) ) {
			return $module_wrapper;
		}

		$elements = $args['elements'] ?? null;
		if ( ! is_object( $elements ) || ! method_exists( $elements, 'style' ) ) {
			return $module_wrapper;
		}

		if ( ! class_exists( '\ET\Builder\FrontEnd\Module\Style' ) ) {
			return $module_wrapper;
		}

		$order_class = isset( $elements->order_class ) ? (string) $elements->order_class : '';
		if ( '' === $order_class ) {
			return $module_wrapper;
		}

		$card_sel   = $order_class . ' .dsm-password-form';
		$title_sel  = $order_class . ' .dsm-password-form__title';
		$input_sel  = $order_class . ' input.input.dsm-password-form__input, ' . $order_class . ' .dsm-password-form__input';
		$button_sel = $order_class . ' .et_pb_button.dsm-password-form__submit';

		\ET\Builder\FrontEnd\Module\Style::add(
			array(
				'id'            => (string) ( $args['id'] ?? '' ),
				'name'          => $module_name,
				'orderIndex'    => (int) ( $args['orderIndex'] ?? 0 ),
				'storeInstance' => (int) ( $args['storeInstance'] ?? 0 ),
				'styles'        => array(
					$elements->style(
						array(
							'attrName'   => 'dsm_pp_form_card',
							'styleProps' => array(
								'selector'                 => $card_sel,
								'defaultPrintedStyleAttrs' => self::form_card_default_printed_style_attrs(),
								'background'               => array(
									'selector' => $card_sel,
								),
								'spacing'                  => array(
									'selector'  => $card_sel,
									'important' => true,
								),
								'border'                   => array(
									'selector' => $card_sel,
								),
								'boxShadow'                => array(
									'selector' => $card_sel,
								),
							),
						)
					),
					$elements->style(
						array(
							'attrName'   => 'dsm_pp_form_title_font',
							'styleProps' => array(
								'selector' => $title_sel,
								'font'     => array(
									'selectors' => array(
										'desktop' => array(
											'value' => $title_sel,
											'hover' => $title_sel,
										),
									),
								),
							),
						)
					),
					$elements->style(
						array(
							'attrName'   => 'dsm_pp_password_input',
							'styleProps' => array(
								'selector'   => $input_sel,
								'background' => array(
									'selector' => $input_sel,
								),
								'spacing'    => array(
									'selector'  => $input_sel,
									'important' => true,
								),
								'sizing'     => array(
									'selector' => $input_sel,
								),
								'border'     => array(
									'selector'  => $input_sel,
									'important' => true,
								),
								'boxShadow'  => array(
									'selector'   => $input_sel,
									'useOverlay' => true,
								),
								'font'       => array(
									'selector' => $input_sel,
								),
							),
						)
					),
					$elements->style(
						array(
							'attrName'   => 'dsm_pp_button',
							'styleProps' => array(
								'selector' => $button_sel,
								'type'     => 'button',
								'font'     => array(
									'important' => array(
										'font' => array(
											'desktop' => array(
												'value' => array(
													'color'          => true,
													'font-size'      => true,
													'letter-spacing' => true,
												),
											),
										),
									),
								),
								'spacing'  => array(
									'important' => true,
								),
							),
						)
					),
				),
			)
		);

		return $module_wrapper;
	}

	/**
	 * Register VB helpers for hashing passwords without mutating post_content.
	 *
	 * @return void
	 */
	public function register_rest_routes(): void {
		register_rest_route(
			'dsm/v1',
			'/password-protection/prepare-block',
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'rest_prepare_block' ),
				'permission_callback' => static function (): bool {
					return current_user_can( 'edit_posts' );
				},
				'args'                => array(
					'passwords'          => array(
						'required'          => false,
						'type'              => 'string',
						'sanitize_callback' => static function ( $value ): string {
							return is_string( $value ) ? $value : '';
						},
					),
					'existing_version'   => array(
						'required'          => false,
						'type'              => 'integer',
						'sanitize_callback' => 'absint',
						'default'           => 1,
					),
					'existing_target_id' => array(
						'required'          => false,
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_key',
						'default'           => '',
					),
					'force_new_target'   => array(
						'required' => false,
						'type'     => 'boolean',
						'default'  => false,
					),
				),
			)
		);
	}

	/**
	 * Hash plaintext password lines and ensure a target id for VB attrs.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function rest_prepare_block( $request ) {
		$passwords_raw = (string) $request->get_param( 'passwords' );
		$lines         = self::parse_password_lines( $passwords_raw );
		$version       = max( 1, absint( $request->get_param( 'existing_version' ) ) );
		$target_id     = sanitize_key( (string) $request->get_param( 'existing_target_id' ) );
		$force_new     = (bool) $request->get_param( 'force_new_target' );

		if ( $force_new || '' === $target_id ) {
			$target_id = self::generate_target_id();
		}

		$entries = array();
		if ( array() !== $lines ) {
			foreach ( $lines as $line ) {
				$entries[] = array(
					'id'      => self::generate_entry_id(),
					'label'   => '',
					'hash'    => wp_hash_password( $line ),
					'enabled' => 'on',
				);
			}
			++$version;
		}

		return rest_ensure_response(
			array(
				'target_id'    => $target_id,
				'list_version' => (string) max( 1, $version ),
				'entries'      => $entries,
				'entries_json' => wp_json_encode( $entries ),
				'hashed'       => array() !== $entries,
			)
		);
	}

	/**
	 * Whether a block name is a Phase A protection target.
	 *
	 * @param string $block_name Block name.
	 * @return bool
	 */
	public static function is_target_block( string $block_name ): bool {
		return in_array( $block_name, self::TARGET_BLOCKS, true );
	}

	/**
	 * Replace locked structural block output with the unlock form.
	 *
	 * @param string              $block_content Rendered HTML.
	 * @param array<string,mixed> $block         Parsed block.
	 * @return string
	 */
	public function filter_render_block( $block_content, $block ): string {
		if ( ! is_string( $block_content ) ) {
			$block_content = '';
		}

		if ( ! is_array( $block ) ) {
			return $block_content;
		}

		$block_name = isset( $block['blockName'] ) ? (string) $block['blockName'] : '';
		if ( ! self::is_target_block( $block_name ) ) {
			return $block_content;
		}

		if ( $this->should_skip_frontend_gate() ) {
			return $block_content;
		}

		$attrs = isset( $block['attrs'] ) && is_array( $block['attrs'] ) ? $block['attrs'] : array();
		if ( ! self::attrs_enabled( $attrs ) ) {
			return $block_content;
		}

		// Require hashed entries and/or plaintext lines (VB may not have hashed yet).
		if ( array() === self::attrs_entries( $attrs ) && array() === self::attrs_password_lines( $attrs ) ) {
			return $block_content;
		}

		if ( $this->protection->should_bypass_block_gate() ) {
			return $block_content;
		}

		if ( $this->protection->user_bypasses_block_attrs( $attrs ) ) {
			return $block_content;
		}

		$post_id = (int) get_the_ID();
		if ( $post_id <= 0 ) {
			$post_id = (int) get_queried_object_id();
		}

		$target_id = self::resolve_target_id( $attrs, $post_id );
		$version   = self::attrs_list_version( $attrs );

		if ( $this->protection->block_cookie_is_valid( $target_id, $version ) ) {
			return $block_content;
		}

		if ( ! $this->sent_nocache ) {
			nocache_headers();
			$this->sent_nocache = true;
		}

		$title       = self::resolve_dynamic_text( self::attrs_scalar( $attrs, 'dsm_pp_form_title', __( 'This content is password protected', 'dsm-supreme-modules-pro-for-divi' ) ) );
		$button_text = self::resolve_dynamic_text( self::attrs_scalar( $attrs, 'dsm_pp_button_text', __( 'Unlock', 'dsm-supreme-modules-pro-for-divi' ) ) );
		$placeholder = self::resolve_dynamic_text( self::attrs_scalar( $attrs, 'dsm_pp_placeholder', __( 'Enter password', 'dsm-supreme-modules-pro-for-divi' ) ) );
		$layout      = 'inline' === self::attrs_scalar( $attrs, 'dsm_pp_form_layout', 'stacked' ) ? 'inline' : 'stacked';
		$alignment   = self::attrs_scalar( $attrs, 'dsm_pp_button_alignment', 'left' );
		if ( ! in_array( $alignment, array( 'left', 'center', 'right' ), true ) ) {
			$alignment = 'left';
		}

		$form = PasswordProtection::render_password_form_html(
			$title,
			$button_text,
			$placeholder,
			'block',
			$post_id,
			$layout,
			$alignment,
			$target_id,
			array(
				'button' => is_array( $attrs['dsm_pp_button'] ?? null ) ? $attrs['dsm_pp_button'] : array(),
			)
		);

		$inner = '<div class="dsm-password-protection-block dsm-password-protection-block--locked" data-dsm-pp-target="' . esc_attr( $target_id ) . '">' . $form . '</div>';

		// Keep the structural root (order class) so Design styleProps on {{selector}} still apply.
		return $this->maybe_form_styles_html() . self::replace_block_inner_html( $block_content, $inner );
	}

	/**
	 * Replace a block’s inner HTML while preserving the opening root tag/attributes.
	 *
	 * @param string $block_content Original rendered HTML.
	 * @param string $inner_html    Replacement children.
	 * @return string
	 */
	private static function replace_block_inner_html( string $block_content, string $inner_html ): string {
		$trimmed = trim( $block_content );
		if ( '' === $trimmed ) {
			return $inner_html;
		}

		if ( ! preg_match( '/^<([a-zA-Z][\w:-]*)(\s[^>]*)?>/s', $trimmed, $open ) ) {
			return $inner_html;
		}

		$tag = $open[1];
		if ( ! preg_match( '/<\/' . preg_quote( $tag, '/' ) . '>\s*$/i', $trimmed ) ) {
			return $inner_html;
		}

		$open_tag = $open[0];
		if ( preg_match( '/\bclass=(["\'])(.*?)\1/i', $open_tag, $class_match ) ) {
			$quote    = $class_match[1];
			$classes  = trim( $class_match[2] . ' dsm-password-protection-block--host' );
			$open_tag = preg_replace(
				'/\bclass=(["\'])(.*?)\1/i',
				'class=' . $quote . esc_attr( $classes ) . $quote,
				$open_tag,
				1
			);
		} else {
			$open_tag = preg_replace(
				'/^<([a-zA-Z][\w:-]*)/',
				'<$1 class="dsm-password-protection-block--host"',
				$open_tag,
				1
			);
		}

		return $open_tag . $inner_html . '</' . $tag . '>';
	}

	/**
	 * Rebuild unlock lookup index from saved attrs (read-only — never rewrite post_content).
	 *
	 * @param int      $post_id Post ID.
	 * @param \WP_Post $post    Post.
	 * @return void
	 */
	public function maybe_rebuild_block_index_on_save( int $post_id, $post ): void {
		if ( $post_id <= 0 || ! $post instanceof \WP_Post ) {
			return;
		}

		if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
			return;
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		$content = (string) $post->post_content;
		if ( '' === $content || false === strpos( $content, 'dsm_pp_' ) ) {
			delete_post_meta( $post_id, self::META_BLOCK_INDEX );
			return;
		}

		$blocks = parse_blocks( $content );
		if ( array() === $blocks ) {
			return;
		}

		$index = array();
		$this->collect_block_index( $blocks, $index, $post_id );
		update_post_meta( $post_id, self::META_BLOCK_INDEX, wp_json_encode( $index ) );
	}

	/**
	 * Recursively collect protection targets into the meta index.
	 *
	 * @param array<int, array<string,mixed>>    $blocks Blocks.
	 * @param array<string, array<string,mixed>> $index  Index accumulator.
	 * @param int                                $post_id Post id.
	 * @return void
	 */
	private function collect_block_index( array $blocks, array &$index, int $post_id = 0 ): void {
		foreach ( $blocks as $block ) {
			if ( ! is_array( $block ) ) {
				continue;
			}

			$name = isset( $block['blockName'] ) ? (string) $block['blockName'] : '';
			if ( self::is_target_block( $name ) ) {
				$attrs = isset( $block['attrs'] ) && is_array( $block['attrs'] ) ? $block['attrs'] : array();
				if ( self::attrs_enabled( $attrs ) ) {
					$target_id = self::resolve_target_id( $attrs, $post_id );
					$entries   = self::entries_for_index( $attrs );
					if ( '' !== $target_id && array() !== $entries ) {
						$index[ $target_id ] = array(
							'entries' => $entries,
							'version' => self::attrs_list_version( $attrs ),
						);
					}
				}
			}

			if ( ! empty( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ) {
				$this->collect_block_index( $block['innerBlocks'], $index, $post_id );
			}
		}
	}

	/**
	 * Return a one-time style tag for the locked-block unlock form (render_block is late for head enqueue).
	 *
	 * @return string
	 */
	private function maybe_form_styles_html(): string {
		if ( $this->printed_form_styles ) {
			return '';
		}
		$this->printed_form_styles = true;

		// Keep in sync with packages/module-library/password-form/common.scss (inline for late render_block).
		$css = '.dsm-password-protection-block{max-width:28rem;margin:1.5rem auto;padding:0 1rem;box-sizing:border-box;}' .
			'.dsm-password-protection-block .dsm-password-form{width:100%;max-width:none;margin:0;background:#ffffff;padding:2rem;border-radius:12px;box-shadow:0px 8px 30px 0px rgba(0,0,0,0.08);box-sizing:border-box;text-align:left;}' .
			'.dsm-password-protection-block .dsm-password-form__title{margin:0 0 1.25rem;font-size:1.25rem;line-height:1.4;font-weight:600;color:#333;}' .
			'.dsm-password-protection-block .dsm-password-form__error{color:#b32d2e;margin:0 0 1rem;}' .
			'.dsm-password-protection-block .dsm-password-form__form{display:flex;align-items:stretch;gap:.75rem;}' .
			'.dsm-password-protection-block .dsm-password-form--stacked .dsm-password-form__form{flex-direction:column;align-items:stretch;}' .
			'.dsm-password-protection-block .dsm-password-form--inline .dsm-password-form__form{flex-direction:row;flex-wrap:nowrap;align-items:stretch;}' .
			'.dsm-password-protection-block .dsm-password-form input.input.dsm-password-form__input,.dsm-password-protection-block .dsm-password-form input.dsm-password-form__input{display:block;flex:1 1 auto;min-width:0;max-width:100%;width:auto;box-sizing:border-box;-webkit-appearance:none;appearance:none;background-color:#eee;border:0;border-radius:0;color:#999;font-size:14px;padding:16px;}' .
			'.dsm-password-protection-block .dsm-password-form--stacked input.input.dsm-password-form__input,.dsm-password-protection-block .dsm-password-form--stacked input.dsm-password-form__input{flex:0 0 auto;width:100%;}' .
			'.dsm-password-protection-block .dsm-password-form__submit.et_pb_button,.dsm-password-protection-block .dsm-password-form__submit{flex:0 0 auto;max-width:100%;margin:0;cursor:pointer;color:#2ea3f2;background-color:transparent;border:2px solid currentColor;border-radius:3px;padding:.3em 1em;font-size:20px;line-height:1.7em;font-family:inherit;text-decoration:none;box-sizing:border-box;}' .
			'.dsm-password-protection-block .dsm-password-form--stacked .dsm-password-form__submit{align-self:flex-start;}' .
			'.dsm-password-protection-block .dsm-password-form--stacked .dsm-password-form__form--align-center .dsm-password-form__submit{align-self:center;}' .
			'.dsm-password-protection-block .dsm-password-form--stacked .dsm-password-form__form--align-right .dsm-password-form__submit{align-self:flex-end;}' .
			'.dsm-password-protection-block .dsm-password-form--inline .dsm-password-form__form--align-center{justify-content:center;}' .
			'.dsm-password-protection-block .dsm-password-form--inline .dsm-password-form__form--align-right{justify-content:flex-end;}';

		return '<style id="dsm-password-protection-block-css">' . $css . '</style>';
	}

	/**
	 * Form Card Design defaults — keep in sync with `form-card-defaults.js` / `.dsm-password-form` CSS.
	 *
	 * @return array<string,mixed>
	 */
	public static function form_card_default_printed_style_attrs(): array {
		return array(
			'decoration' => array(
				'background' => array(
					'desktop' => array(
						'value' => array(
							'color'       => '#ffffff',
							'enableColor' => 'on',
						),
					),
				),
				'spacing'    => array(
					'desktop' => array(
						'value' => array(
							'padding' => array(
								'top'            => '2rem',
								'right'          => '2rem',
								'bottom'         => '2rem',
								'left'           => '2rem',
								'syncHorizontal' => 'on',
								'syncVertical'   => 'on',
							),
						),
					),
				),
				'border'     => array(
					'desktop' => array(
						'value' => array(
							'radius' => array(
								'sync'        => 'on',
								'topLeft'     => '12px',
								'topRight'    => '12px',
								'bottomLeft'  => '12px',
								'bottomRight' => '12px',
							),
						),
					),
				),
				'boxShadow'  => array(
					'desktop' => array(
						'value' => array(
							'style'      => 'preset1',
							'horizontal' => '0px',
							'vertical'   => '8px',
							'blur'       => '30px',
							'spread'     => '0px',
							'color'      => 'rgba(0,0,0,0.08)',
							'position'   => 'outer',
						),
					),
				),
			),
		);
	}

	/**
	 * Skip gate in admin / builder contexts.
	 *
	 * @return bool
	 */
	private function should_skip_frontend_gate(): bool {
		if ( is_admin() ) {
			return true;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only presence checks.
		if ( isset( $_GET['et_fb'] ) || isset( $_GET['et_tb'] ) ) {
			return true;
		}

		if ( function_exists( 'et_core_is_fb_enabled' ) && et_core_is_fb_enabled() ) {
			return true;
		}

		if ( function_exists( 'et_builder_d5_enabled' ) && et_builder_d5_enabled()
			&& function_exists( 'et_core_is_fb_enabled' ) && et_core_is_fb_enabled() ) {
			return true;
		}

		return false;
	}

	/**
	 * Attrs enabled.
	 *
	 * @param array<string,mixed> $attrs Attrs.
	 * @return bool
	 */
	public static function attrs_enabled( array $attrs ): bool {
		return 'on' === strtolower( self::attrs_scalar( $attrs, 'dsm_pp_enabled', 'off' ) );
	}

	/**
	 * Attrs target ID.
	 *
	 * @param array<string,mixed> $attrs Attrs.
	 * @return string
	 */
	public static function attrs_target_id( array $attrs ): string {
		return sanitize_key( self::attrs_scalar( $attrs, 'dsm_pp_target_id', '' ) );
	}

	/**
	 * Stable target id from attrs, or a deterministic fallback when VB has not written one yet.
	 *
	 * @param array<string,mixed> $attrs   Attrs.
	 * @param int                 $post_id Post ID.
	 * @return string
	 */
	public static function resolve_target_id( array $attrs, int $post_id = 0 ): string {
		$existing = self::attrs_target_id( $attrs );
		if ( '' !== $existing ) {
			return $existing;
		}

		if ( $post_id <= 0 ) {
			$post_id = (int) get_queried_object_id();
		}

		$fingerprint = self::attrs_scalar( $attrs, 'dsm_pp_passwords_lines', '' ) . '|' . self::attrs_scalar( $attrs, 'dsm_pp_entries', '[]' );

		return 'pp' . substr( md5( (string) $post_id . '|dsm_pp|' . $fingerprint ), 0, 14 );
	}

	/**
	 * Attrs list version.
	 *
	 * @param array<string,mixed> $attrs Attrs.
	 * @return int
	 */
	public static function attrs_list_version( array $attrs ): int {
		return max( 1, absint( self::attrs_scalar( $attrs, 'dsm_pp_list_version', '1' ) ) );
	}

	/**
	 * Attrs entries.
	 *
	 * @param array<string,mixed> $attrs Attrs.
	 * @return array<int, array{id: string, label: string, hash: string, enabled: string}>
	 */
	public static function attrs_entries( array $attrs ): array {
		$json = self::attrs_scalar( $attrs, 'dsm_pp_entries', '[]' );
		if ( '' === $json || '[]' === $json ) {
			return array();
		}
		$decoded = json_decode( $json, true );
		if ( ! is_array( $decoded ) ) {
			return array();
		}
		return PasswordProtection::normalize_entries_public( $decoded );
	}

	/**
	 * Plaintext password lines still present in attrs (pre-hash / VB prepare pending).
	 *
	 * @param array<string,mixed> $attrs Attrs.
	 * @return array<int, string>
	 */
	public static function attrs_password_lines( array $attrs ): array {
		return self::parse_password_lines( self::attrs_scalar( $attrs, 'dsm_pp_passwords_lines', '' ) );
	}

	/**
	 * Hashed entries for the unlock index (hashes plaintext lines when entries are missing).
	 *
	 * @param array<string,mixed> $attrs Attrs.
	 * @return array<int, array{id: string, label: string, hash: string, enabled: string}>
	 */
	public static function entries_for_index( array $attrs ): array {
		$entries = self::attrs_entries( $attrs );
		if ( array() !== $entries ) {
			return $entries;
		}

		$out = array();
		foreach ( self::attrs_password_lines( $attrs ) as $line ) {
			$out[] = array(
				'id'      => substr( md5( $line ), 0, 12 ),
				'label'   => '',
				'hash'    => wp_hash_password( $line ),
				'enabled' => 'on',
			);
		}

		return $out;
	}

	/**
	 * Whether a password unlocks this block's attrs (hashes and/or plaintext lines).
	 *
	 * @param string              $password Plaintext.
	 * @param array<string,mixed> $attrs    Block attrs.
	 * @param PasswordProtection  $protection Protection helper.
	 * @return bool
	 */
	public static function password_matches_attrs( string $password, array $attrs, PasswordProtection $protection ): bool {
		$entries = self::attrs_entries( $attrs );
		if ( array() !== $entries && $protection->password_matches_entries( $password, $entries ) ) {
			return true;
		}

		foreach ( self::attrs_password_lines( $attrs ) as $line ) {
			if ( hash_equals( $line, $password ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Read scalar innerContent desktop value.
	 *
	 * @param array<string,mixed> $attrs   Attrs.
	 * @param string              $key     Attr key.
	 * @param string              $default Default.
	 * @return string
	 */
	public static function attrs_scalar( array $attrs, string $key, string $default = '' ): string {
		if ( empty( $attrs[ $key ] ) || ! is_array( $attrs[ $key ] ) ) {
			return $default;
		}
		$value = $attrs[ $key ]['innerContent']['desktop']['value'] ?? $default;
		if ( is_array( $value ) && isset( $value['text'] ) ) {
			return (string) $value['text'];
		}
		return is_scalar( $value ) ? (string) $value : $default;
	}

	/**
	 * Resolve Divi Dynamic Content / `$variable(…)$` tokens for form copy fields.
	 *
	 * Used for Form Title, Button Text, and Input Placeholder only — never for
	 * password secret lists (`dsm_pp_passwords_lines` / entries).
	 *
	 * @param string $raw Raw attr value (may include `$variable(…)$`).
	 * @return string
	 */
	public static function resolve_dynamic_text( string $raw ): string {
		$text = $raw;

		if ( class_exists( \ET\Builder\Packages\StyleLibrary\Utils\Utils::class ) ) {
			$resolved = \ET\Builder\Packages\StyleLibrary\Utils\Utils::resolve_dynamic_variable( $text );
			if ( is_string( $resolved ) ) {
				$text = $resolved;
			}
		}

		/**
		 * Filters resolved Password Protection form copy (title / button / placeholder).
		 *
		 * @param string $text Resolved text.
		 * @param string $raw  Original stored value.
		 */
		return (string) apply_filters( 'dsm_pp_resolve_dynamic_text', $text, $raw );
	}

	/**
	 * Set scalar innerContent desktop value.
	 *
	 * @param array<string,mixed> $attrs Attrs.
	 * @param string              $key   Key.
	 * @param string              $value Value.
	 * @return array<string,mixed>
	 */
	public static function set_inner_desktop_value( array $attrs, string $key, string $value ): array {
		if ( ! isset( $attrs[ $key ] ) || ! is_array( $attrs[ $key ] ) ) {
			$attrs[ $key ] = array();
		}
		if ( ! isset( $attrs[ $key ]['innerContent'] ) || ! is_array( $attrs[ $key ]['innerContent'] ) ) {
			$attrs[ $key ]['innerContent'] = array();
		}
		if ( ! isset( $attrs[ $key ]['innerContent']['desktop'] ) || ! is_array( $attrs[ $key ]['innerContent']['desktop'] ) ) {
			$attrs[ $key ]['innerContent']['desktop'] = array();
		}
		$attrs[ $key ]['innerContent']['desktop']['value'] = $value;
		return $attrs;
	}

	/**
	 * Parse password lines.
	 *
	 * @param string $raw Textarea.
	 * @return array<int, string>
	 */
	public static function parse_password_lines( string $raw ): array {
		$raw = str_replace( array( "\r\n", "\r" ), "\n", $raw );
		$out = array();
		foreach ( explode( "\n", $raw ) as $line ) {
			$line = trim( $line );
			if ( '' !== $line ) {
				$out[] = $line;
			}
		}
		return $out;
	}

	/**
	 * Generate target ID.
	 *
	 * @return string
	 */
	public static function generate_target_id(): string {
		try {
			return 'pp' . substr( bin2hex( random_bytes( 8 ) ), 0, 14 );
		} catch ( \Exception $e ) {
			return 'pp' . substr( md5( uniqid( (string) wp_rand(), true ) ), 0, 14 );
		}
	}

	/**
	 * Generate entry ID.
	 *
	 * @return string
	 */
	private static function generate_entry_id(): string {
		try {
			return substr( bin2hex( random_bytes( 8 ) ), 0, 12 );
		} catch ( \Exception $e ) {
			return substr( md5( uniqid( (string) wp_rand(), true ) ), 0, 12 );
		}
	}

	/**
	 * Lookup unlock material for a target from post meta index (or content fallback).
	 *
	 * @param int    $post_id   Current post ID.
	 * @param string $target_id Target id.
	 * @return array{entries: array<int, array{id: string, label: string, hash: string, enabled: string}>, version: int, attrs?: array<string,mixed>}|null
	 */
	public static function lookup_target_on_post( int $post_id, string $target_id ): ?array {
		$target_id = sanitize_key( $target_id );
		if ( $post_id <= 0 || '' === $target_id ) {
			return null;
		}

		$raw = get_post_meta( $post_id, self::META_BLOCK_INDEX, true );
		if ( is_string( $raw ) && '' !== $raw ) {
			$decoded = json_decode( $raw, true );
			if ( is_array( $decoded ) && ! empty( $decoded[ $target_id ] ) && is_array( $decoded[ $target_id ] ) ) {
				$row     = $decoded[ $target_id ];
				$entries = isset( $row['entries'] ) && is_array( $row['entries'] )
					? PasswordProtection::normalize_entries_public( $row['entries'] )
					: array();
				$version = isset( $row['version'] ) ? max( 1, absint( $row['version'] ) ) : 1;

				if ( array() !== $entries ) {
					return array(
						'entries' => $entries,
						'version' => $version,
					);
				}
			}
		}

		return self::lookup_target_from_content( $post_id, $target_id );
	}

	/**
	 * Fallback: scan post_content for target attrs.
	 *
	 * @param int    $post_id   Post ID.
	 * @param string $target_id Target.
	 * @return array{entries: array<int, array{id: string, label: string, hash: string, enabled: string}>, version: int, attrs: array<string,mixed>}|null
	 */
	private static function lookup_target_from_content( int $post_id, string $target_id ): ?array {
		$post = get_post( $post_id );
		if ( ! $post instanceof \WP_Post ) {
			return null;
		}

		$blocks = parse_blocks( (string) $post->post_content );
		return self::find_target_in_blocks( $blocks, $target_id, $post_id );
	}

	/**
	 * Find target in blocks.
	 *
	 * @param array<int, array<string,mixed>> $blocks    Blocks.
	 * @param string                          $target_id Target.
	 * @param int                             $post_id   Post ID.
	 * @return array{entries: array<int, array{id: string, label: string, hash: string, enabled: string}>, version: int, attrs: array<string,mixed>}|null
	 */
	private static function find_target_in_blocks( array $blocks, string $target_id, int $post_id ): ?array {
		foreach ( $blocks as $block ) {
			if ( ! is_array( $block ) ) {
				continue;
			}
			$name  = isset( $block['blockName'] ) ? (string) $block['blockName'] : '';
			$attrs = isset( $block['attrs'] ) && is_array( $block['attrs'] ) ? $block['attrs'] : array();
			if ( self::is_target_block( $name ) && self::attrs_enabled( $attrs ) ) {
				$resolved = self::resolve_target_id( $attrs, $post_id );
				if ( $resolved === $target_id ) {
					$entries = self::entries_for_index( $attrs );
					if ( array() === $entries && array() === self::attrs_password_lines( $attrs ) ) {
						return null;
					}
					return array(
						'entries' => $entries,
						'version' => self::attrs_list_version( $attrs ),
						'attrs'   => $attrs,
					);
				}
			}
			if ( ! empty( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ) {
				$nested = self::find_target_in_blocks( $block['innerBlocks'], $target_id, $post_id );
				if ( null !== $nested ) {
					return $nested;
				}
			}
		}
		return null;
	}
}
