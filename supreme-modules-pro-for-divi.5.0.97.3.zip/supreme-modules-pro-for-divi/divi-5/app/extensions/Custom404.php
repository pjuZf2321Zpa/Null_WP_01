<?php
/**
 * Custom 404 Page — serve a Divi Library layout on HTTP 404 responses.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Extensions;

use DiviSupreme\Includes\DiviLibraryLayoutRenderer;
use DiviSupreme\Includes\DsmLibraryLayoutSelectOptions;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * 404 takeover powered by an assigned Divi Library layout.
 *
 * After WordPress marks the request as a 404 (and before Divi Dynamic Assets
 * run on `wp` priority 0), the main query is swapped to the assigned
 * `et_pb_layout` post, then a Divi-compatible blank template renders
 * `#et-boc` + `the_content()`. HTTP 404 is re-asserted on `template_redirect`.
 *
 * An enabled Theme Builder template assigned to 404 wins; this feature defers.
 */
class Custom404 {

	/**
	 * Settings section option key (Miscellaneous).
	 */
	public const OPTION_SECTION = 'dsm_settings_misc';

	/**
	 * Option: enable flag (`on`|`off`).
	 */
	public const OPTION_ENABLED = 'dsm_custom_404_enabled';

	/**
	 * Option: Divi Library layout post ID or `none`.
	 */
	public const OPTION_LAYOUT_ID = 'dsm_custom_404_layout_id';

	/**
	 * Status: master toggle off.
	 */
	public const STATUS_OFF = 'off';

	/**
	 * Status: enabled and serving 404s.
	 */
	public const STATUS_ACTIVE = 'active';

	/**
	 * Status: enabled but no valid layout assigned.
	 */
	public const STATUS_INCOMPLETE = 'incomplete';

	/**
	 * Status: Theme Builder 404 template is active.
	 */
	public const STATUS_DEFERRED_TB = 'deferred_tb';

	/**
	 * Status: Maintenance Mode is currently serving visitors.
	 */
	public const STATUS_DEFERRED_MM = 'deferred_mm';

	/**
	 * Whether the main query was hijacked for a layout this request.
	 *
	 * @var bool
	 */
	private bool $query_hijacked = false;

	/**
	 * Layout ID used for the hijacked query (0 if none).
	 *
	 * @var int
	 */
	private int $hijacked_layout_id = 0;

	/**
	 * Constructor.
	 */
	public function __construct() {
		$GLOBALS['dsm_custom_404_extension'] = $this;

		// After handle_404(), before Divi DynamicAssets::pre_initial_setup (wp priority 0).
		add_action( 'wp', array( $this, 'maybe_hijack_main_query' ), -1 );
		add_filter( 'template_include', array( $this, 'maybe_use_custom_404_template' ), 99 );
		add_action( 'template_redirect', array( $this, 'maybe_send_404_headers' ), 1 );
		add_filter( 'body_class', array( $this, 'filter_body_class' ) );
	}

	/**
	 * Layout select options for the settings dashboard (layout-type items only).
	 *
	 * @return array<string, string> Value => label.
	 */
	public static function get_layout_select_options(): array {
		$raw = DsmLibraryLayoutSelectOptions::get_options();
		$out = array(
			'none' => __( '— Select Library Layout —', 'dsm-supreme-modules-pro-for-divi' ),
		);

		foreach ( $raw as $id => $title ) {
			if ( 'none' === (string) $id ) {
				continue;
			}

			$post_id = absint( $id );
			if ( $post_id <= 0 ) {
				continue;
			}

			if ( 'layout' !== DsmLibraryLayoutSelectOptions::get_layout_type_slug( $post_id ) ) {
				continue;
			}

			$label = is_string( $title ) ? $title : '';
			if ( '' === $label ) {
				$label = sprintf(
					/* translators: %d: library post ID */
					__( 'Untitled Layout %d', 'dsm-supreme-modules-pro-for-divi' ),
					$post_id
				);
			}

			$out[ (string) $post_id ] = sprintf(
				/* translators: 1: layout title, 2: post ID */
				__( '%1$s (#%2$d)', 'dsm-supreme-modules-pro-for-divi' ),
				$label,
				$post_id
			);
		}

		return $out;
	}

	/**
	 * Sanitize stored layout option value.
	 *
	 * @param mixed $value Raw option value.
	 * @return string `none` or numeric post ID string.
	 */
	public static function sanitize_layout_option( $value ): string {
		$value = sanitize_text_field( (string) $value );

		if ( '' === $value || 'none' === $value || '0' === $value ) {
			return 'none';
		}

		$post_id = absint( $value );
		if ( $post_id <= 0 ) {
			return 'none';
		}

		$post = get_post( $post_id );
		if ( ! $post instanceof \WP_Post ) {
			return 'none';
		}

		$layout_type = defined( 'ET_BUILDER_LAYOUT_POST_TYPE' ) ? ET_BUILDER_LAYOUT_POST_TYPE : 'et_pb_layout';
		if ( $layout_type !== $post->post_type ) {
			return 'none';
		}

		return (string) $post_id;
	}

	/**
	 * Whether the master Enable toggle is on.
	 *
	 * @return bool
	 */
	public function is_enabled(): bool {
		return 'on' === $this->get_misc_option( self::OPTION_ENABLED, 'off' );
	}

	/**
	 * Assigned Divi Library layout ID (0 when none / invalid).
	 *
	 * @return int
	 */
	public function get_layout_id(): int {
		$raw = $this->get_misc_option( self::OPTION_LAYOUT_ID, 'none' );
		$id  = DiviLibraryLayoutRenderer::normalize_post_id( $raw );

		/**
		 * Filters the Custom 404 library layout post ID.
		 *
		 * @param int $id Layout post ID (0 = none).
		 */
		return (int) apply_filters( 'dsm_custom_404_layout_id', $id );
	}

	/**
	 * Human-readable status line for the settings dashboard.
	 *
	 * @return array{status: string, label: string, description: string, tone: string}
	 */
	public function get_status_for_settings(): array {
		if ( ! $this->is_enabled() ) {
			return array(
				'status'      => self::STATUS_OFF,
				'label'       => __( 'Custom 404 Page is off', 'dsm-supreme-modules-pro-for-divi' ),
				'description' => __( 'Custom 404 Page is disabled. Enable it above and assign a Divi Library layout to replace the default 404 page.', 'dsm-supreme-modules-pro-for-divi' ),
				'tone'        => 'neutral',
			);
		}

		if ( $this->is_maintenance_mode_serving() ) {
			return array(
				'status'      => self::STATUS_DEFERRED_MM,
				'label'       => __( 'Custom 404 Page is paused (Maintenance Mode)', 'dsm-supreme-modules-pro-for-divi' ),
				'description' => __( 'Maintenance & Coming Soon is currently serving visitors, so Custom 404 Page does not run until Maintenance ends.', 'dsm-supreme-modules-pro-for-divi' ),
				'tone'        => 'warning',
			);
		}

		if ( self::has_theme_builder_404_template() ) {
			return array(
				'status'      => self::STATUS_DEFERRED_TB,
				'label'       => __( 'Custom 404 Page is paused (Theme Builder)', 'dsm-supreme-modules-pro-for-divi' ),
				'description' => self::get_theme_builder_defer_notice_html(),
				'tone'        => 'warning',
			);
		}

		if ( $this->get_layout_id() <= 0 ) {
			return array(
				'status'      => self::STATUS_INCOMPLETE,
				'label'       => __( 'Custom 404 Page is on — no layout', 'dsm-supreme-modules-pro-for-divi' ),
				'description' => __( 'Custom 404 Page is enabled but no published Divi Library layout is assigned. Visitors still see the theme or Theme Builder 404 until you choose a layout.', 'dsm-supreme-modules-pro-for-divi' ),
				'tone'        => 'warning',
			);
		}

		return array(
			'status'      => self::STATUS_ACTIVE,
			'label'       => __( 'Custom 404 Page is on', 'dsm-supreme-modules-pro-for-divi' ),
			'description' => __( 'Missing URLs show the assigned Divi Library layout with an HTTP 404 status.', 'dsm-supreme-modules-pro-for-divi' ),
			'tone'        => 'success',
		);
	}

	/**
	 * Notice HTML when a Theme Builder 404 template is active (settings dashboard).
	 *
	 * @return string Safe HTML.
	 */
	public static function get_theme_builder_defer_notice_html(): string {
		$tb_url = admin_url( 'admin.php?page=et_theme_builder' );

		return wp_kses_post(
			sprintf(
				/* translators: %s: Theme Builder admin URL */
				__( 'A Divi Theme Builder 404 template is active. Custom 404 Page will not run so Theme Builder can render. <a href="%s">Open Theme Builder</a> and disable or delete that 404 template to use this layout instead.', 'dsm-supreme-modules-pro-for-divi' ),
				esc_url( $tb_url )
			)
		);
	}

	/**
	 * Whether an enabled Theme Builder template is assigned to 404.
	 *
	 * @return bool
	 */
	public static function has_theme_builder_404_template(): bool {
		static $resolved = null;

		if ( is_bool( $resolved ) ) {
			return $resolved;
		}

		$resolved = self::query_theme_builder_404_template();

		return $resolved;
	}

	/**
	 * Query enabled Theme Builder templates for a 404 assignment.
	 *
	 * @return bool
	 */
	private static function query_theme_builder_404_template(): bool {
		$template_type = defined( 'ET_THEME_BUILDER_TEMPLATE_POST_TYPE' )
			? ET_THEME_BUILDER_TEMPLATE_POST_TYPE
			: 'et_template';

		if ( ! post_type_exists( $template_type ) ) {
			return false;
		}

		$ids = get_posts(
			array(
				'post_type'              => $template_type,
				'post_status'            => 'publish',
				'posts_per_page'         => 50,
				'fields'                 => 'ids',
				'no_found_rows'          => true,
				'update_post_meta_cache' => true,
				'update_post_term_cache' => false,
				'suppress_filters'       => true,
				// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Small et_template set; admin + 404 only.
				'meta_query'             => array(
					array(
						'key'   => '_et_enabled',
						'value' => '1',
					),
				),
			)
		);

		if ( ! is_array( $ids ) || array() === $ids ) {
			return false;
		}

		update_meta_cache( 'post', $ids );

		foreach ( $ids as $template_id ) {
			$template_id = absint( $template_id );
			if ( $template_id <= 0 ) {
				continue;
			}

			$use_on = get_post_meta( $template_id, '_et_use_on', false );
			if ( ! is_array( $use_on ) ) {
				continue;
			}

			$use_on = array_map( 'strval', $use_on );
			if ( in_array( '404', $use_on, true ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Swap the main query to the assigned Library layout after WordPress sets 404.
	 *
	 * @return void
	 */
	public function maybe_hijack_main_query(): void {
		if ( is_admin() || ! is_404() ) {
			return;
		}

		if ( ! $this->should_intercept_frontend() ) {
			return;
		}

		$layout_id = $this->get_layout_id();
		if ( $layout_id <= 0 || ! $this->is_layout_servable( $layout_id ) ) {
			return;
		}

		$layout_type = defined( 'ET_BUILDER_LAYOUT_POST_TYPE' ) ? ET_BUILDER_LAYOUT_POST_TYPE : 'et_pb_layout';

		$new_query = new \WP_Query(
			array(
				'post_type'              => $layout_type,
				'p'                      => $layout_id,
				'post_status'            => 'publish',
				'posts_per_page'         => 1,
				'no_found_rows'          => true,
				'ignore_sticky_posts'    => true,
				'update_post_meta_cache' => true,
				'update_post_term_cache' => false,
			)
		);

		if ( ! $new_query instanceof \WP_Query || ! $new_query->have_posts() ) {
			return;
		}

		$new_query->is_404               = false;
		$new_query->is_home              = false;
		$new_query->is_front_page        = false;
		$new_query->is_posts_page        = false;
		$new_query->is_singular          = true;
		$new_query->is_single            = true;
		$new_query->is_page              = false;
		$new_query->is_archive           = false;
		$new_query->is_search            = false;
		$new_query->is_post_type_archive = false;

		// phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- Replace 404 query so Divi assets attach to the layout post.
		$GLOBALS['wp_query'] = $new_query;
		// phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- Keep the canonical query pointer in sync.
		$GLOBALS['wp_the_query'] = $new_query;

		if ( $new_query->post instanceof \WP_Post ) {
			// phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- register_globals already ran with a 404.
			$GLOBALS['post'] = $new_query->post;
			setup_postdata( $new_query->post );
		}

		$this->query_hijacked     = true;
		$this->hijacked_layout_id = $layout_id;
	}

	/**
	 * Use the Custom 404 blank template when the query was hijacked.
	 *
	 * @param string $template Template path.
	 * @return string
	 */
	public function maybe_use_custom_404_template( string $template ): string {
		if ( ! $this->query_hijacked ) {
			return $template;
		}

		$path = __DIR__ . '/templates/custom-404.php';
		if ( is_readable( $path ) ) {
			return $path;
		}

		return $template;
	}

	/**
	 * Re-assert HTTP 404 after the query swap (Divi / WP may send 200 once is_404 is cleared).
	 *
	 * @return void
	 */
	public function maybe_send_404_headers(): void {
		if ( ! $this->query_hijacked ) {
			return;
		}

		status_header( 404 );
		nocache_headers();
	}

	/**
	 * Ensure body classes help Divi layout CSS apply.
	 *
	 * @param string[] $classes Body classes.
	 * @return string[]
	 */
	public function filter_body_class( array $classes ): array {
		if ( ! $this->query_hijacked ) {
			return $classes;
		}

		$classes[] = 'dsm-custom-404';
		$classes[] = 'et_pb_pagebuilder_layout';
		$classes[] = 'et_no_sidebar';
		$classes[] = 'et-db';

		return array_values( array_unique( $classes ) );
	}

	/**
	 * Whether this frontend request should use Custom 404 (enabled, not bypassed, not deferred).
	 *
	 * @return bool
	 */
	private function should_intercept_frontend(): bool {
		if ( ! $this->is_enabled() ) {
			return false;
		}

		if ( $this->should_bypass() ) {
			return false;
		}

		if ( $this->is_maintenance_mode_serving() ) {
			return false;
		}

		if ( $this->should_defer_to_theme_builder() ) {
			return false;
		}

		$serving = true;

		/**
		 * Filters whether Custom 404 is actively taking over this request.
		 *
		 * @param bool $serving Whether Custom 404 should run.
		 */
		return (bool) apply_filters( 'dsm_custom_404_is_active', $serving );
	}

	/**
	 * Whether an enabled Theme Builder 404 template should win.
	 *
	 * @return bool
	 */
	private function should_defer_to_theme_builder(): bool {
		$defer = self::has_theme_builder_404_template();

		/**
		 * Filters whether Custom 404 defers to a Theme Builder 404 template.
		 *
		 * A Default Website Template body override does not count — only an
		 * enabled Theme Builder template assigned to 404.
		 *
		 * @param bool $defer Whether to defer.
		 */
		return (bool) apply_filters( 'dsm_custom_404_should_defer_to_theme_builder', $defer );
	}

	/**
	 * Whether Maintenance Mode is currently serving visitors.
	 *
	 * @return bool
	 */
	private function is_maintenance_mode_serving(): bool {
		if (
			isset( $GLOBALS['dsm_maintenance_mode_extension'] )
			&& $GLOBALS['dsm_maintenance_mode_extension'] instanceof MaintenanceMode
		) {
			return $GLOBALS['dsm_maintenance_mode_extension']->is_currently_serving();
		}

		return false;
	}

	/**
	 * Whether the current request/user should skip Custom 404.
	 *
	 * @return bool
	 */
	private function should_bypass(): bool {
		$bypass = $this->should_bypass_unfiltered();

		/**
		 * Filters whether the current request bypasses Custom 404.
		 *
		 * @param bool $bypass Whether to bypass.
		 */
		return (bool) apply_filters( 'dsm_custom_404_should_bypass', $bypass );
	}

	/**
	 * Internal bypass rules (before filter). Administrators are not bypassed so they can preview.
	 *
	 * @return bool
	 */
	private function should_bypass_unfiltered(): bool {
		if ( is_admin() ) {
			return true;
		}

		if ( wp_doing_ajax() || wp_doing_cron() ) {
			return true;
		}

		if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
			return true;
		}

		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			return true;
		}

		if ( $this->is_login_or_system_request() ) {
			return true;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only presence checks.
		if ( isset( $_GET['et_fb'] ) || isset( $_GET['et_tb'] ) ) {
			return true;
		}

		if ( function_exists( 'et_core_is_fb_enabled' ) && et_core_is_fb_enabled() ) {
			return true;
		}

		return false;
	}

	/**
	 * Login, feed, and similar system endpoints that must stay reachable.
	 *
	 * @return bool
	 */
	private function is_login_or_system_request(): bool {
		if ( isset( $GLOBALS['pagenow'] ) && 'wp-login.php' === $GLOBALS['pagenow'] ) {
			return true;
		}

		$request_uri = isset( $_SERVER['REQUEST_URI'] )
			? esc_url_raw( wp_unslash( (string) $_SERVER['REQUEST_URI'] ) )
			: '';
		$path        = (string) wp_parse_url( $request_uri, PHP_URL_PATH );
		$login_path  = (string) wp_parse_url( wp_login_url(), PHP_URL_PATH );

		if ( '' !== $login_path && false !== strpos( $path, $login_path ) ) {
			return true;
		}

		if ( function_exists( 'is_feed' ) && did_action( 'parse_query' ) && is_feed() ) {
			return true;
		}

		if ( function_exists( 'is_robots' ) && did_action( 'parse_query' ) && is_robots() ) {
			return true;
		}

		if ( function_exists( 'is_favicon' ) && did_action( 'parse_query' ) && is_favicon() ) {
			return true;
		}

		return false;
	}

	/**
	 * Whether a library layout can be shown (published).
	 *
	 * @param int $layout_id Layout post ID.
	 * @return bool
	 */
	private function is_layout_servable( int $layout_id ): bool {
		$post = get_post( $layout_id );
		if ( ! $post instanceof \WP_Post ) {
			return false;
		}

		$layout_type = defined( 'ET_BUILDER_LAYOUT_POST_TYPE' ) ? ET_BUILDER_LAYOUT_POST_TYPE : 'et_pb_layout';
		if ( $layout_type !== $post->post_type ) {
			return false;
		}

		return 'publish' === $post->post_status;
	}

	/**
	 * Read a Miscellaneous settings value.
	 *
	 * @param string $key           Option field name.
	 * @param string $default_value Default when missing.
	 * @return string
	 */
	private function get_misc_option( string $key, string $default_value = '' ): string {
		$options = get_option( self::OPTION_SECTION, array() );
		if ( ! is_array( $options ) || ! array_key_exists( $key, $options ) ) {
			return $default_value;
		}

		return is_scalar( $options[ $key ] ) ? (string) $options[ $key ] : $default_value;
	}
}
