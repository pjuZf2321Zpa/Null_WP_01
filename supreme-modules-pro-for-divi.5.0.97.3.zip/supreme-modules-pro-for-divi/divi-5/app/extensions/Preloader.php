<?php
/**
 * Preloader — branded page-load overlay with presets, scope, and failsafe dismiss.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Extensions;

use DiviSupreme\Core\Assets;
use DiviSupreme\Includes\DsmVbRestSave;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Sitewide preloader overlay (Divi 5).
 */
class Preloader {

	/**
	 * Settings API section / option key.
	 */
	public const OPTION_KEY = 'dsm_settings_preloader';

	/**
	 * Per-page enable flag for scope `per_page`.
	 */
	public const PAGE_META_KEY = 'dsm-preloader-page-enabled';

	/**
	 * Divi 5 breakpoint service (when the Visual Builder / frontend kit is loaded).
	 */
	private const DSM_ET_BREAKPOINT_CLASS = '\\ET\\Builder\\Framework\\Breakpoint\\Breakpoint';

	/**
	 * Keys owned by the slim dashboard tab (scope and design stay in Visual Builder).
	 *
	 * @var string[]
	 */
	private const OPERATIONAL_KEYS = array(
		'failsafe_ms',
		'hide_logged_in',
		'hide_on_mobile',
		'mobile_max_width',
		'exclude_woo_checkout',
	);

	/**
	 * Default option values.
	 *
	 * @var array<string, mixed>
	 */
	private array $default_settings = array(
		'is_enabled'              => true,
		'preset'                  => 'ring',
		'primary_color'           => '#4161d4',
		'secondary_color'         => '#ffffff',
		'animation_size'          => '48',
		'background_color'        => '#ffffff',
		'background_color_2'      => '',
		'overlay_background'      => array(
			'desktop' => array(
				'value' => array(
					'color'       => '#ffffff',
					'enableColor' => 'on',
				),
			),
		),
		'logo_url'                => '',
		'logo_max_width'          => '160',
		'loading_text'            => '',
		'text_color'              => '#1a1a1a',
		'text_size'               => '14',
		'text_font_family'        => '',
		'text_font_weight'        => '400',
		'text_line_height'        => '1.4em',
		'text_letter_spacing'     => '0px',
		'text_align'              => 'center',
		'text_capitalization'     => '',
		'text_style'              => array(),
		'intro_recipe'            => 'logo_hold_curtain',
		'enter_ms'                => '450',
		'min_hold_ms'             => '1000',
		'exit_style'              => 'curtain',
		'exit_ms'                 => '450',
		'progress_mode'           => 'off',
		'progress_color'          => '',
		'progress_thickness'      => '3',
		'progress_position'       => 'top',
		'page_transitions'        => 'on',
		'transition_out_style'    => 'curtain',
		'first_arrival_frequency' => 'every_load',
		'failsafe_ms'             => '8000',
		'allow_visitor_skip'      => 'on',
		'hide_logged_in'          => 'off',
		'homepage_only'           => 'off',
		'hide_on_mobile'          => 'off',
		'mobile_max_width'        => '767',
		'display_scope'           => 'entire_site',
		'scope_include_ids'       => '',
		'scope_exclude_ids'       => '',
		'exclude_post_types'      => array(),
		'exclude_woo_checkout'    => 'on',
		'reduce_motion_mode'      => 'static_logo',
	);

	/**
	 * Constructor.
	 *
	 * @param bool $register_hooks Whether to register frontend hooks.
	 */
	public function __construct( bool $register_hooks = true ) {
		if ( ! $register_hooks ) {
			return;
		}

		$GLOBALS['dsm_preloader_extension'] = $this;

		add_action( 'wp_head', array( $this, 'print_critical_head' ), PHP_INT_MIN );
		add_action( 'wp_head', array( $this, 'print_skip_comment' ), 1 );
		add_action( 'wp_body_open', array( $this, 'print_overlay_markup' ), 0 );
		add_action( 'wp_footer', array( $this, 'maybe_print_overlay_in_footer' ), 0 );
		add_action( 'wp_footer', array( $this, 'print_markup_debug_comment' ), 99 );
		add_action( 'wp_enqueue_scripts', array( $this, 'maybe_enqueue_frontend_assets' ), 20 );
		add_action(
			'divi_visual_builder_rest_save_post',
			array( $this, 'save_page_settings_from_rest' ),
			10,
			2
		);
	}

	/**
	 * Default settings snapshot.
	 *
	 * @return array<string, mixed>
	 */
	public function get_default_settings(): array {
		return $this->default_settings;
	}

	/**
	 * Allowed preset slugs.
	 *
	 * @return string[]
	 */
	public static function get_preset_slugs(): array {
		return array(
			'ring',
			'ring-dashed',
			'dual-ring',
			'nested-rings',
			'opposing-rings',
			'arc',
			'dots-bounce',
			'dots-pulse',
			'dots-fade',
			'dots-orbit',
			'dots-typing',
			'dots-collision',
			'bars-equalizer',
			'bars-wave',
			'bars-mini',
			'bars-slide',
			'pulse-ripple',
			'pulse-double',
			'pulse-scale',
			'pulse-breathe',
			'grid',
			'cube-grid',
			'flower',
			'satellite',
			'path-circle',
			'path-tail',
			'path-blocks',
			'logo-ring',
			'logo-pulse',
			'logo-only',
		);
	}

	/**
	 * Merged saved settings.
	 *
	 * @return array<string, mixed>
	 */
	public function get_settings(): array {
		$saved = get_option( self::OPTION_KEY, array() );
		if ( ! is_array( $saved ) ) {
			$saved = array();
		}

		$settings                       = wp_parse_args( $saved, $this->default_settings );
		$settings['is_enabled']         = $this->normalize_bool_flag( $settings['is_enabled'] ?? true );
		$settings['animation_size']     = $this->sanitize_responsive_px_map( $settings['animation_size'] ?? '48', 0, 120, 48 );
		$settings                       = $this->migrate_legacy_overlay_background( $settings );
		$settings['overlay_background'] = $this->sanitize_overlay_background( $settings['overlay_background'] ?? array() );
		$settings['logo_max_width']     = $this->sanitize_responsive_px_map( $settings['logo_max_width'] ?? '160', 40, 400, 160 );
		$settings['text_size']          = $this->sanitize_responsive_px_map( $settings['text_size'] ?? '14', 10, 28, 14 );
		$settings                       = $this->sanitize_responsive_typography_maps( $settings );
		$settings['enter_ms']           = $this->sanitize_int_range( (string) ( $settings['enter_ms'] ?? '450' ), 0, 2000, 450 );
		$settings['progress_color']     = $this->sanitize_color( $this->color_value_to_string( $settings['progress_color'] ?? '' ), '' );
		$settings['progress_thickness'] = $this->sanitize_int_range( (string) ( $settings['progress_thickness'] ?? '3' ), 1, 16, 3 );
		$settings['progress_position']  = $this->sanitize_key_in(
			(string) ( $settings['progress_position'] ?? 'top' ),
			array( 'top', 'bottom' ),
			'top'
		);
		$settings['allow_visitor_skip'] = 'on' === $this->on_off( $settings['allow_visitor_skip'] ?? 'on' ) ? 'on' : 'off';

		/**
		 * Filters Preloader settings after they are loaded.
		 *
		 * @param array<string, mixed> $settings Settings.
		 */
		return apply_filters( 'dsm_preloader_settings', $settings );
	}

	/**
	 * Persist customiser settings.
	 *
	 * @param array<string, mixed> $settings Raw settings.
	 * @return bool
	 */
	public function save_settings( array $settings ): bool {
		$existing = get_option( self::OPTION_KEY, array() );
		if ( ! is_array( $existing ) ) {
			$existing = array();
		}

		$merged = wp_parse_args( $settings, wp_parse_args( $existing, $this->default_settings ) );
		update_option( self::OPTION_KEY, $this->sanitize_settings( $merged ) );

		return true;
	}

	/**
	 * Merge slim-tab save onto the full option so visual keys survive.
	 *
	 * @param array<string, mixed> $merged Posted operational fields.
	 * @return array<string, mixed>
	 */
	public static function normalize_options_after_save( array $merged ): array {
		$existing = get_option( self::OPTION_KEY, array() );
		if ( ! is_array( $existing ) ) {
			$existing = array();
		}

		foreach ( $existing as $key => $value ) {
			if ( ! in_array( (string) $key, self::OPERATIONAL_KEYS, true ) && ! array_key_exists( $key, $merged ) ) {
				$merged[ $key ] = $value;
			}
		}

		if ( isset( $GLOBALS['dsm_preloader_extension'] ) && $GLOBALS['dsm_preloader_extension'] instanceof self ) {
			return $GLOBALS['dsm_preloader_extension']->sanitize_settings( $merged );
		}

		$tmp = new self( false );
		return $tmp->sanitize_settings( $merged );
	}

	/**
	 * Sanitize a full settings array.
	 *
	 * @param array<string, mixed> $settings Settings.
	 * @return array<string, mixed>
	 */
	public function sanitize_settings( array $settings ): array {
		$out = wp_parse_args( $settings, $this->default_settings );

		$out['is_enabled']              = $this->normalize_bool_flag( $out['is_enabled'] ?? true );
		$out['preset']                  = $this->sanitize_preset( (string) $out['preset'] );
		$out['primary_color']           = $this->sanitize_color( $this->color_value_to_string( $out['primary_color'] ), '#4161d4' );
		$out['secondary_color']         = $this->sanitize_color( $this->color_value_to_string( $out['secondary_color'] ), '#ffffff' );
		$out['animation_size']          = $this->sanitize_responsive_px_map( $out['animation_size'] ?? '48', 0, 120, 48 );
		$out['background_color']        = $this->sanitize_color( $this->color_value_to_string( $out['background_color'] ), '#ffffff' );
		$out['background_color_2']      = $this->sanitize_color( $this->color_value_to_string( $out['background_color_2'] ), '' );
		$out                            = $this->migrate_legacy_overlay_background( $out );
		$out['overlay_background']      = $this->sanitize_overlay_background( $out['overlay_background'] ?? array() );
		$out                            = $this->sync_legacy_background_colors_from_overlay( $out );
		$out['logo_url']                = esc_url_raw( $this->normalize_logo_url_value( $out['logo_url'] ?? '' ) );
		$out['logo_max_width']          = $this->sanitize_responsive_px_map( $out['logo_max_width'] ?? '160', 40, 400, 160 );
		$out['loading_text']            = sanitize_text_field( (string) $out['loading_text'] );
		$out['text_size']               = $this->sanitize_responsive_px_map( $out['text_size'] ?? '14', 10, 28, 14 );
		$out['text_font_family']        = $this->sanitize_text_font_family( (string) ( $out['text_font_family'] ?? '' ) );
		$out                            = $this->sanitize_responsive_typography_maps( $out );
		$out['text_style']              = $this->sanitize_text_style_flags( $out['text_style'] ?? array() );
		$out['intro_recipe']            = $this->sanitize_key_in(
			(string) $out['intro_recipe'],
			array( 'logo_hold_curtain', 'wordmark_spinner', 'progress_fade' ),
			'logo_hold_curtain'
		);
		$out['enter_ms']                = $this->sanitize_int_range( (string) $out['enter_ms'], 0, 2000, 450 );
		$out['min_hold_ms']             = $this->sanitize_int_range( (string) $out['min_hold_ms'], 0, 4000, 1000 );
		$out['exit_style']              = $this->sanitize_key_in(
			(string) $out['exit_style'],
			array( 'fade', 'fade-up', 'wipe-up', 'scale', 'curtain' ),
			'curtain'
		);
		$out['exit_ms']                 = $this->sanitize_int_range( (string) $out['exit_ms'], 150, 2000, 450 );
		$out['progress_mode']           = $this->sanitize_key_in(
			(string) $out['progress_mode'],
			array( 'off', 'indeterminate', 'determinate' ),
			'off'
		);
		$out['progress_color']          = $this->sanitize_color( $this->color_value_to_string( $out['progress_color'] ?? '' ), '' );
		$out['progress_thickness']      = $this->sanitize_int_range( (string) ( $out['progress_thickness'] ?? '3' ), 1, 16, 3 );
		$out['progress_position']       = $this->sanitize_key_in(
			(string) ( $out['progress_position'] ?? 'top' ),
			array( 'top', 'bottom' ),
			'top'
		);
		$out['page_transitions']        = 'on' === $this->on_off( $out['page_transitions'] ?? 'on' ) ? 'on' : 'off';
		$out['transition_out_style']    = $this->sanitize_key_in(
			(string) $out['transition_out_style'],
			array( 'fade', 'fade-up', 'wipe-up', 'scale', 'curtain' ),
			'curtain'
		);
		$out['first_arrival_frequency'] = $this->sanitize_key_in(
			(string) $out['first_arrival_frequency'],
			array( 'every_load', 'once_per_session' ),
			'every_load'
		);
		$out['failsafe_ms']             = $this->sanitize_int_range( (string) $out['failsafe_ms'], 2000, 15000, 8000 );
		$out['allow_visitor_skip']      = 'on' === $this->on_off( $out['allow_visitor_skip'] ?? 'on' ) ? 'on' : 'off';
		$out['hide_logged_in']          = $this->on_off( $out['hide_logged_in'] ?? 'off' );
		$out['homepage_only']           = $this->on_off( $out['homepage_only'] ?? 'off' );
		$out['hide_on_mobile']          = $this->on_off( $out['hide_on_mobile'] ?? 'off' );
		$out['mobile_max_width']        = $this->sanitize_int_range( (string) $out['mobile_max_width'], 320, 1200, 767 );
		$out['display_scope']           = $this->sanitize_key_in(
			(string) $out['display_scope'],
			array( 'entire_site', 'include_pages', 'exclude_pages', 'per_page' ),
			'entire_site'
		);
		$out['scope_include_ids']       = $this->sanitize_page_ids( (string) $out['scope_include_ids'] );
		$out['scope_exclude_ids']       = $this->sanitize_page_ids( (string) $out['scope_exclude_ids'] );
		$out['exclude_woo_checkout']    = $this->on_off( $out['exclude_woo_checkout'] ?? 'on' );
		$out['reduce_motion_mode']      = $this->sanitize_key_in(
			(string) $out['reduce_motion_mode'],
			array( 'static_logo', 'disable' ),
			'static_logo'
		);
		$out['exclude_post_types']      = $this->sanitize_post_type_list( $out['exclude_post_types'] ?? array() );

		return $out;
	}

	/**
	 * Slim dashboard field rows.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public static function get_dashboard_fields(): array {
		return array(
			array(
				'type'    => 'settings_group',
				'name'    => 'dsm_preloader_group_overview',
				'label'   => __( 'Overview', 'dsm-supreme-modules-pro-for-divi' ),
				'desc'    => __( 'Design and scope this in Visual Builder → Preloader. This tab is operational only: failsafe, logged-in hide, small screens, and WooCommerce checkout. The overlay never runs in the builder — open the published page, or add ?dsm_pl=1 to force one view.', 'dsm-supreme-modules-pro-for-divi' ),
				'variant' => 'accent',
			),
			array(
				'type'  => 'subheading',
				'name'  => 'dsm_preloader_status',
				'icon'  => Assets::getAssetPath( 'dashboard/extensions/preloader.svg' ),
				'label' => __( 'Status: Preloader extension is off', 'dsm-supreme-modules-pro-for-divi' ),
				'desc'  => __( 'Turn on Preloader under Extensions. Visitors will not see a preloader until the extension is on and “Show on the frontend” is enabled in Visual Builder → Preloader → Settings.', 'dsm-supreme-modules-pro-for-divi' ),
			),
			array(
				'name'              => 'failsafe_ms',
				'icon'              => Assets::getAssetPath( 'dashboard/rows/timer.svg' ),
				'label'             => __( 'Failsafe timeout (ms)', 'dsm-supreme-modules-pro-for-divi' ),
				'desc'              => __( 'Hard maximum. The overlay dismisses even if the load event never fires. 2000–15000.', 'dsm-supreme-modules-pro-for-divi' ),
				'type'              => 'number',
				'default'           => '8000',
				'min'               => 2000,
				'max'               => 15000,
				'sanitize_callback' => 'absint',
			),
			array(
				'name'    => 'hide_logged_in',
				'icon'    => Assets::getAssetPath( 'dashboard/rows/person-off.svg' ),
				'class'   => 'dsm-settings-checkbox',
				'label'   => __( 'Hide for logged-in users', 'dsm-supreme-modules-pro-for-divi' ),
				'type'    => 'checkbox',
				'default' => 'off',
			),
			array(
				'name'    => 'hide_on_mobile',
				'icon'    => Assets::getAssetPath( 'dashboard/rows/smartphone.svg' ),
				'class'   => 'dsm-settings-checkbox',
				'label'   => __( 'Hide on small screens', 'dsm-supreme-modules-pro-for-divi' ),
				'type'    => 'checkbox',
				'default' => 'off',
			),
			array(
				'name'              => 'mobile_max_width',
				'icon'              => Assets::getAssetPath( 'dashboard/rows/width.svg' ),
				'label'             => __( 'Mobile max width (px)', 'dsm-supreme-modules-pro-for-divi' ),
				'desc'              => __( 'Used when Hide on small screens is on.', 'dsm-supreme-modules-pro-for-divi' ),
				'type'              => 'number',
				'default'           => '767',
				'min'               => 320,
				'max'               => 1200,
				'sanitize_callback' => 'absint',
			),
			array(
				'name'    => 'exclude_woo_checkout',
				'icon'    => Assets::getAssetPath( 'dashboard/rows/cart-off.svg' ),
				'class'   => 'dsm-settings-checkbox',
				'label'   => __( 'Exclude WooCommerce cart, checkout, and account', 'dsm-supreme-modules-pro-for-divi' ),
				'type'    => 'checkbox',
				'default' => 'on',
			),
		);
	}

	/**
	 * Status copy for the dashboard subheading.
	 *
	 * @return array{label: string, description: string, tone: string}
	 */
	public function get_status_for_settings(): array {
		if ( ! function_exists( 'dsm_is_preloader_extension_enabled' ) || ! dsm_is_preloader_extension_enabled() ) {
			return array(
				'label'       => __( 'Preloader extension is off', 'dsm-supreme-modules-pro-for-divi' ),
				'description' => __( 'Turn on Preloader under Extensions. Visitors will not see a preloader until the extension is on and “Show on the frontend” is enabled in Visual Builder → Preloader → Settings.', 'dsm-supreme-modules-pro-for-divi' ),
				'tone'        => 'neutral',
			);
		}

		$settings = $this->get_settings();
		if ( ! $this->normalize_bool_flag( $settings['is_enabled'] ?? false ) ) {
			return array(
				'label'       => __( 'Preloader is not showing', 'dsm-supreme-modules-pro-for-divi' ),
				'description' => __( 'The Preloader extension is turned on, but the preloader is not in use. Visitors will not see it until you turn on “Show on the frontend” in Visual Builder → Preloader → Settings.', 'dsm-supreme-modules-pro-for-divi' ),
				'tone'        => 'warning',
			);
		}

		return array(
			'label'       => __( 'Preloader is showing', 'dsm-supreme-modules-pro-for-divi' ),
			'description' => __( 'The Preloader extension is on and the overlay is in use on the frontend. It never runs inside Visual Builder — open the published page, or add ?dsm_pl=1 to force one preview (this also bypasses once-per-session and hide-for-logged-in).', 'dsm-supreme-modules-pro-for-divi' ),
			'tone'        => 'success',
		);
	}

	/**
	 * Whether the overlay should run on this frontend request.
	 *
	 * @return bool
	 */
	public function should_load_on_current_request(): bool {
		if ( ! function_exists( 'dsm_is_preloader_extension_enabled' ) || ! dsm_is_preloader_extension_enabled() ) {
			return false;
		}

		if ( is_admin() || wp_doing_ajax() || wp_doing_cron() ) {
			return false;
		}

		if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
			return false;
		}

		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			return false;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only presence checks.
		if ( isset( $_GET['et_fb'] ) || isset( $_GET['et_tb'] ) ) {
			return false;
		}

		if ( function_exists( 'et_core_is_fb_enabled' ) && et_core_is_fb_enabled() ) {
			return false;
		}

		$settings = $this->get_settings();

		if ( ! $this->normalize_bool_flag( $settings['is_enabled'] ?? false ) ) {
			return false;
		}

		if ( $this->is_force_preview_request() ) {
			/**
			 * Filters whether the preloader overlay should run on this request.
			 *
			 * @param bool                 $should   Whether to load.
			 * @param array<string, mixed> $settings Settings.
			 */
			return (bool) apply_filters( 'dsm_preloader_should_load', true, $settings );
		}

		if ( 'on' === ( $settings['hide_logged_in'] ?? 'off' ) && is_user_logged_in() ) {
			return false;
		}

		if ( 'on' === ( $settings['homepage_only'] ?? 'off' ) && ! is_front_page() ) {
			return false;
		}

		if ( $this->is_excluded_woo_request( $settings ) ) {
			return false;
		}

		$post_id   = (int) get_queried_object_id();
		$post_type = $post_id > 0 ? (string) get_post_type( $post_id ) : '';
		$excluded  = $settings['exclude_post_types'] ?? array();
		if ( is_array( $excluded ) && '' !== $post_type && isset( $excluded[ $post_type ] ) && '' !== (string) $excluded[ $post_type ] ) {
			return false;
		}

		$scope = (string) ( $settings['display_scope'] ?? 'entire_site' );
		$ids   = $this->parse_page_ids_string(
			'include_pages' === $scope
				? (string) ( $settings['scope_include_ids'] ?? '' )
				: (string) ( $settings['scope_exclude_ids'] ?? '' )
		);

		switch ( $scope ) {
			case 'include_pages':
				$should = $post_id > 0 && in_array( $post_id, $ids, true );
				break;

			case 'exclude_pages':
				$should = $post_id <= 0 || ! in_array( $post_id, $ids, true );
				break;

			case 'per_page':
				$should = $post_id > 0 && 'on' === get_post_meta( $post_id, self::PAGE_META_KEY, true );
				break;

			case 'entire_site':
			default:
				$should = true;
				break;
		}

		/**
		 * Filters whether the preloader overlay should run on this request.
		 *
		 * @param bool                 $should   Whether to load.
		 * @param array<string, mixed> $settings Settings.
		 */
		return (bool) apply_filters( 'dsm_preloader_should_load', $should, $settings );
	}

	/**
	 * Print critical CSS + failsafe script as early as possible.
	 *
	 * @return void
	 */
	public function print_critical_head(): void {
		if ( ! $this->should_load_on_current_request() ) {
			return;
		}

		$settings = $this->get_settings();
		$paint_bg = $this->get_paint_lock_background_color( $settings );

		// First bytes: hide body until the overlay is on <html>. Cached refresh otherwise
		// paints page content, then #dsm-preloader mounts (flash).
		echo '<style id="dsm-preloader-paint-lock"';
		$this->print_critical_inline_tag_attrs();
		echo '>html{background-color:' . esc_html( $paint_bg ) . '}html.dsm-pl-wait body{visibility:hidden!important}</style>' . "\n";
		echo '<script id="dsm-preloader-paint-lock-js"';
		$this->print_critical_inline_tag_attrs();
		echo '>document.documentElement.classList.add("dsm-pl-wait");</script>' . "\n";

		$css_file = __DIR__ . '/Preloader/critical.scss';
		$css      = is_readable( $css_file ) ? (string) file_get_contents( $css_file ) : ''; // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- local plugin CSS.

		echo "<!-- dsm-preloader: critical CSS — do not defer, delay, combine, or strip -->\n";
		echo '<style id="dsm-preloader-critical"';
		$this->print_critical_inline_tag_attrs();
		$responsive_css = $this->build_responsive_size_css( $settings );
		if ( '' !== $responsive_css ) {
			$css .= $responsive_css;
		}

		$overlay_bg_css = $this->build_overlay_background_css( $settings );
		if ( '' !== $overlay_bg_css ) {
			$css .= $overlay_bg_css;
		}

		$hide_mobile_css = $this->build_hide_on_mobile_css( $settings );
		if ( '' !== $hide_mobile_css ) {
			$css .= $hide_mobile_css;
		}

		$view_transition_css = $this->get_view_transition_css( $settings );
		if ( '' !== $view_transition_css ) {
			$css .= $view_transition_css;
		}

		echo '>' . $css . '</style>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static plugin CSS + sanitized size maps.

		$logo = esc_url( $this->normalize_logo_url_value( $settings['logo_url'] ?? '' ) );
		if ( '' !== $logo ) {
			printf(
				'<link rel="preload" as="image" href="%1$s" id="dsm-preloader-logo-preload" />' . "\n",
				esc_url( $logo )
			);
		}

		$overlay_image = $this->get_overlay_background_image_url( $settings );
		if ( '' !== $overlay_image ) {
			printf(
				'<link rel="preload" as="image" href="%1$s" id="dsm-preloader-overlay-image-preload" />' . "\n",
				esc_url( $overlay_image )
			);
		}

		$this->print_failsafe_script( $settings );
	}

	/**
	 * HTML comment when the extension is on but this request is skipped.
	 *
	 * @return void
	 */
	public function print_skip_comment(): void {
		if ( ! function_exists( 'dsm_is_preloader_extension_enabled' ) || ! dsm_is_preloader_extension_enabled() ) {
			return;
		}

		if ( $this->should_load_on_current_request() ) {
			return;
		}

		printf(
			"\n<!-- dsm-preloader: skipped (%s). Overlay never runs in Visual Builder. Open the published page with ?dsm_pl=1 to force one view. -->\n",
			esc_html( $this->get_skip_reason() )
		);
	}

	/**
	 * Overlay markup at the start of the body.
	 *
	 * @return void
	 */
	public function print_overlay_markup(): void {
		if ( ! $this->should_load_on_current_request() ) {
			return;
		}

		if ( ! empty( $GLOBALS['dsm_preloader_markup_printed'] ) ) {
			return;
		}

		$GLOBALS['dsm_preloader_markup_printed'] = true;
		$settings                                = $this->get_settings();
		$html                                    = '<noscript><style>#dsm-preloader{display:none!important}</style></noscript>' . "\n";
		$html                                   .= $this->get_overlay_element_markup( $settings );

		/**
		 * Filters the preloader overlay markup.
		 *
		 * @param string               $html     Markup.
		 * @param array<string, mixed> $settings Settings.
		 */
		echo apply_filters( 'dsm_preloader_markup', $html, $settings ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above; filter may add trusted markup.
	}

	/**
	 * Overlay element HTML (no noscript wrapper).
	 *
	 * @param array<string, mixed> $settings Settings.
	 * @return string
	 */
	public function get_overlay_element_markup( array $settings ): string {
		$preset = $this->sanitize_preset( (string) $settings['preset'] );
		$recipe = $this->sanitize_key_in(
			(string) ( $settings['intro_recipe'] ?? 'logo_hold_curtain' ),
			array( 'logo_hold_curtain', 'wordmark_spinner', 'progress_fade' ),
			'logo_hold_curtain'
		);
		/**
		 * Filters the first-arrival intro recipe.
		 *
		 * @param string               $recipe   Recipe slug.
		 * @param array<string, mixed> $settings Settings.
		 */
		$recipe  = (string) apply_filters( 'dsm_preloader_intro_recipe', $recipe, $settings );
		$logo    = $this->normalize_logo_url_value( $settings['logo_url'] ?? '' );
		$text    = (string) $settings['loading_text'];
		$classes = array(
			'dsm-preloader',
			'dsm-preloader--exit-' . sanitize_html_class( (string) $settings['exit_style'] ),
			'dsm-preloader--stage-enter',
		);

		$progress = (string) $settings['progress_mode'];
		if ( in_array( $progress, array( 'indeterminate', 'determinate' ), true ) ) {
			$classes[] = 'dsm-preloader--progress-' . $progress;
		} elseif ( 'progress_fade' === $recipe ) {
			$classes[] = 'dsm-preloader--progress-indeterminate';
		}

		if ( in_array( $preset, array( 'logo-ring', 'logo-pulse' ), true ) ) {
			$classes[] = 'dsm-preloader--logo-mark';
		}

		if ( '' !== $logo || '' !== $text ) {
			$classes[] = 'dsm-preloader--has-brand';
		}

		$progress_position = $this->sanitize_key_in(
			(string) ( $settings['progress_position'] ?? 'top' ),
			array( 'top', 'bottom' ),
			'top'
		);
		if ( 'bottom' === $progress_position ) {
			$classes[] = 'dsm-preloader--progress-bottom';
		}

		$overlay_bg = $this->get_overlay_background_inline_style( $settings );
		$bg_vars    = $this->get_overlay_background_css_vars( $settings );

		$text_typo = $this->get_text_typography_static_css_vars( $settings );
		$enter_ms  = (int) $settings['enter_ms'];

		// Size + responsive typography live in #dsm-preloader-critical
		// (desktop + @media). Inline --dsm-pl-text / weight / align would beat
		// those media queries on published pages.
		$style = sprintf(
			'--dsm-pl-color:%1$s;--dsm-pl-color-2:%2$s;--dsm-pl-enter-ms:%3$sms;%4$s%5$s%6$s%7$s',
			esc_attr( $this->color_for_css( $settings['primary_color'] ?? '', '#4161d4' ) ),
			esc_attr( $this->color_for_css( $settings['secondary_color'] ?? '', '#ffffff' ) ),
			esc_attr( (string) $enter_ms ),
			$bg_vars,
			$text_typo,
			$overlay_bg,
			$this->get_progress_style_css( $settings )
		);

		$hide_mobile = 'on' === ( $settings['hide_on_mobile'] ?? 'off' )
			? (int) $settings['mobile_max_width']
			: 0;
		$allow_skip  = 'on' === $this->on_off( $settings['allow_visitor_skip'] ?? 'on' ) ? '1' : '0';

		/**
		 * Filters whether visitors may dismiss the overlay with click or Escape.
		 *
		 * @param bool                 $allow    Whether skip is allowed.
		 * @param array<string, mixed> $settings Settings.
		 */
		$allow_skip = apply_filters( 'dsm_preloader_allow_visitor_skip', '1' === $allow_skip, $settings ) ? '1' : '0';

		$html  = '<div id="dsm-preloader" class="' . esc_attr( implode( ' ', $classes ) ) . '" style="' . esc_attr( $style ) . '" data-dsm-preset="' . esc_attr( $preset ) . '" data-dsm-recipe="' . esc_attr( $recipe ) . '" data-dsm-enter-ms="' . esc_attr( (string) $enter_ms ) . '" data-dsm-exit-ms="' . esc_attr( (string) $settings['exit_ms'] ) . '" data-dsm-transitions="' . esc_attr( (string) $settings['page_transitions'] ) . '" data-dsm-out-style="' . esc_attr( (string) $settings['transition_out_style'] ) . '" data-dsm-hide-mobile="' . esc_attr( (string) $hide_mobile ) . '" data-dsm-allow-skip="' . esc_attr( $allow_skip ) . '" role="status" aria-live="polite" aria-busy="true" inert>';
		$html .= '<div class="dsm-preloader__progress" aria-hidden="true"></div>';
		$html .= '<div class="dsm-preloader__inner">';

		if ( '' !== $logo ) {
			$html .= sprintf(
				'<img class="dsm-preloader__logo" src="%1$s" alt="" />',
				esc_url( $logo )
			);
		}

		$html .= '<div class="dsm-preloader__anim" data-preset="' . esc_attr( $preset ) . '">' . $this->get_preset_inner_html( $preset ) . '</div>';

		if ( '' !== $text ) {
			$html .= '<p class="dsm-preloader__text">' . esc_html( $text ) . '</p>';
		}

		$html .= '</div></div>';

		return $html;
	}

	/**
	 * Inline failsafe: skip rules, mount overlay on <html>, hard dismiss.
	 *
	 * Mounts on documentElement (not body) so Divi 5 hydration cannot wipe it.
	 *
	 * @param array<string, mixed> $settings Settings.
	 * @return void
	 */
	private function print_failsafe_script( array $settings ): void {
		$failsafe       = (int) $settings['failsafe_ms'];
		$min_hold       = (int) $settings['min_hold_ms'];
		$exit_ms        = (int) $settings['exit_ms'];
		$freq           = (string) $settings['first_arrival_frequency'];
		$reduce         = (string) $settings['reduce_motion_mode'];
		$markup         = $this->get_overlay_element_markup( $settings );
		$hide_mobile    = 'on' === ( $settings['hide_on_mobile'] ?? 'off' )
			? (int) $settings['mobile_max_width']
			: 0;
		$allow_skip     = apply_filters(
			'dsm_preloader_allow_visitor_skip',
			'on' === $this->on_off( $settings['allow_visitor_skip'] ?? 'on' ),
			$settings
		);
		$transitions_on = 'on' === $this->on_off( $settings['page_transitions'] ?? 'on' );

		echo '<script id="dsm-preloader-failsafe"';
		$this->print_critical_inline_tag_attrs();
		echo '>(function(){try{';
		echo 'var f=' . wp_json_encode( $failsafe ) . ',m=' . wp_json_encode( $min_hold ) . ',x=' . wp_json_encode( $exit_ms ) . ',freq=' . wp_json_encode( $freq ) . ',rm=' . wp_json_encode( $reduce ) . ',mk=' . wp_json_encode( $markup ) . ',hideM=' . wp_json_encode( $hide_mobile ) . ',allowSkip=' . wp_json_encode( (bool) $allow_skip ) . ',transitionsOn=' . wp_json_encode( $transitions_on ) . ';';
		echo 'var KEY="dsm_pl_seen",NAV="dsm_pl_nav",FORCE="dsm_pl_force",root=document.documentElement;';
		echo 'var q=location.search||"",force=/(?:^|[?&])dsm_pl=1(?:&|$)/.test(q);';
		echo 'try{if(sessionStorage.getItem(FORCE)==="1"){force=true;sessionStorage.removeItem(FORCE);}}catch(e0){}';
		echo 'if(force){root.setAttribute("data-dsm-pl-force","1");}';
		echo 'var reduced=window.matchMedia&&window.matchMedia("(prefers-reduced-motion: reduce)").matches;';
		echo 'function releaseWait(){root.classList.remove("dsm-pl-wait");}';
		echo 'if(!force&&reduced&&rm==="disable"){root.setAttribute("data-dsm-pl-skip","1");root.setAttribute("data-dsm-pl-state","skipped-reduced-motion");releaseWait();return;}';
		echo 'if(!force&&hideM>0&&window.innerWidth<=hideM){root.setAttribute("data-dsm-pl-skip","1");root.setAttribute("data-dsm-pl-state","skipped-mobile");releaseWait();document.addEventListener("DOMContentLoaded",function(){var n=document.getElementById("dsm-preloader");if(n&&n.parentNode){n.parentNode.removeChild(n);}});return;}';
		echo 'var nav=false;try{nav=sessionStorage.getItem(NAV)==="1";sessionStorage.removeItem(NAV);}catch(e){}';
		echo 'if(!force&&!nav&&freq==="once_per_session"){try{if(sessionStorage.getItem(KEY)==="1"){root.setAttribute("data-dsm-pl-skip","1");root.setAttribute("data-dsm-pl-state","skipped-session");releaseWait();return;}}catch(e2){}}';
		$paint_bg = $this->get_paint_lock_background_color( $settings );

		echo 'root.setAttribute("data-dsm-pl","1");';
		echo 'root.style.setProperty("--dsm-pl-bg",' . wp_json_encode( $paint_bg ) . ');';
		echo 'if(nav){root.setAttribute("data-dsm-pl-nav","1");}';
		echo 'function setBodyInert(on){if(!document.body)return;if(on){document.body.setAttribute("inert","");}else{document.body.removeAttribute("inert");}}';
		echo 'function setOverlayInert(el,on){if(!el)return;if(on){el.setAttribute("inert","");}else{el.removeAttribute("inert");}}';
		echo 'function hideEl(el){if(!el)return;el.classList.add("dsm-preloader--hidden");el.setAttribute("hidden","hidden");el.setAttribute("aria-busy","false");el.setAttribute("aria-hidden","true");setOverlayInert(el,false);setBodyInert(false);releaseWait();}';
		echo 'if(window.addEventListener){window.addEventListener("pagereveal",function(e){if(!e||!e.viewTransition)return;root.setAttribute("data-dsm-pl-vt","1");},true);}';
		echo 'function skipNow(){var el=document.getElementById("dsm-preloader");if(!el||el.hasAttribute("hidden")||el.classList.contains("dsm-preloader--leaving")||el.classList.contains("dsm-preloader--covering"))return;el.classList.add("dsm-preloader--leaving");window.setTimeout(function(){hideEl(el);},Math.max(150,x||450));}';
		echo 'function place(){if(root.getAttribute("data-dsm-pl-skip")==="1"){releaseWait();return false;}var all=document.querySelectorAll("#dsm-preloader"),el=null,i;for(i=0;i<all.length;i++){if(all[i].parentNode===root){el=all[i];break;}}if(!el){el=document.getElementById("dsm-preloader");}if(!el&&mk){var w=document.createElement("div");w.innerHTML=mk;el=w.querySelector("#dsm-preloader");}if(!el){return false;}if(el.hasAttribute("hidden")||el.classList.contains("dsm-preloader--hidden")||el.classList.contains("dsm-preloader--leaving")){setBodyInert(false);releaseWait();return false;}all=document.querySelectorAll("#dsm-preloader");for(i=0;i<all.length;i++){if(all[i]!==el&&all[i].parentNode){all[i].parentNode.removeChild(all[i]);}}if(nav){el.classList.remove("dsm-preloader--stage-enter");}if(el.parentNode!==root){root.appendChild(el);}setOverlayInert(el,true);setBodyInert(true);root.setAttribute("data-dsm-pl-state","mounted");releaseWait();return true;}';
		echo 'place();document.addEventListener("DOMContentLoaded",place);';
		echo 'if(transitionsOn){document.addEventListener("click",function(e){if(e.button!==0||e.metaKey||e.ctrlKey||e.shiftKey||e.altKey)return;var t=e.target&&e.target.closest?e.target.closest("a[href]"):null;if(!t||t.getAttribute("target")==="_blank"||t.hasAttribute("download"))return;var h=t.getAttribute("href")||"";if(!h||h==="#"||/^(mailto|tel|javascript|sms):/i.test(h))return;try{var u=new URL(h,location.href);if(u.origin!==location.origin)return;if(u.hash&&u.pathname===location.pathname&&u.search===location.search)return;sessionStorage.setItem(NAV,"1");}catch(eNav){}},true);}';
		echo 'var obs=new MutationObserver(function(){place();});obs.observe(root,{childList:true});';
		echo 'if(allowSkip){document.addEventListener("keydown",function(e){if(e.key==="Escape"||e.key==="Esc")skipNow();});document.addEventListener("click",function(e){var t=e.target&&e.target.closest?e.target.closest("a[href]"):null;if(t)return;var el=document.getElementById("dsm-preloader");if(!el||el.hasAttribute("hidden")||el.classList.contains("dsm-preloader--leaving")||el.classList.contains("dsm-preloader--covering"))return;skipNow();},true);}';
		echo 'window.dsmPreloaderBoot={start:Date.now(),failsafe:f,minHold:m,isNav:nav,freq:freq,force:force};';
		echo 'window.setTimeout(function(){if(obs){obs.disconnect();}var el=document.getElementById("dsm-preloader");if(!el||el.hasAttribute("hidden"))return;el.classList.add("dsm-preloader--leaving");window.setTimeout(function(){hideEl(el);},500);},f);';
		echo '}catch(err){try{document.documentElement.classList.remove("dsm-pl-wait");}catch(e3){}}})();</script>' . "\n";
	}

	/**
	 * View-source hint after PHP had a chance to print body markup.
	 *
	 * @return void
	 */
	public function print_markup_debug_comment(): void {
		if ( ! function_exists( 'dsm_is_preloader_extension_enabled' ) || ! dsm_is_preloader_extension_enabled() ) {
			return;
		}

		if ( ! $this->should_load_on_current_request() ) {
			return;
		}

		$state = ! empty( $GLOBALS['dsm_preloader_markup_printed'] ) ? 'php-printed' : 'php-missing-js-should-mount';
		printf(
			"\n<!-- dsm-preloader: %s. Inspect <html data-dsm-pl-state> (mounted | skipped-session | skipped-reduced-motion | skipped-mobile). Force with ?dsm_pl=1. -->\n",
			esc_html( $state )
		);
	}

	/**
	 * Fallback when the theme skips wp_body_open.
	 *
	 * @return void
	 */
	public function maybe_print_overlay_in_footer(): void {
		if ( empty( $GLOBALS['dsm_preloader_markup_printed'] ) ) {
			$this->print_overlay_markup();
		}
	}

	/**
	 * Enqueue dismiss / transition script.
	 *
	 * @return void
	 */
	public function maybe_enqueue_frontend_assets(): void {
		if ( ! $this->should_load_on_current_request() ) {
			return;
		}

		if ( ! wp_script_is( 'dsm-preloader-frontend', 'registered' ) ) {
			return;
		}

		wp_enqueue_script( 'dsm-preloader-frontend' );
		wp_localize_script(
			'dsm-preloader-frontend',
			'dsmPreloaderConfig',
			$this->get_frontend_config()
		);

		$family = $this->sanitize_text_font_family( (string) ( $this->get_settings()['text_font_family'] ?? '' ) );
		if ( '' !== $family && function_exists( 'et_builder_enqueue_font' ) ) {
			et_builder_enqueue_font( $family );
		}
	}

	/**
	 * Localized runtime config for the dismiss / transition script.
	 *
	 * @return array<string, mixed>
	 */
	public function get_frontend_config(): array {
		$settings = $this->get_settings();
		$skip     = $this->get_transition_skip_prefixes( $settings );

		return array(
			'minHold'                     => (int) $settings['min_hold_ms'],
			'enterMs'                     => (int) $settings['enter_ms'],
			'exitMs'                      => (int) $settings['exit_ms'],
			'failsafeMs'                  => (int) $settings['failsafe_ms'],
			'frequency'                   => (string) $settings['first_arrival_frequency'],
			'recipe'                      => (string) $settings['intro_recipe'],
			'transitions'                 => 'on' === $settings['page_transitions'],
			'preferNativeViewTransitions' => (bool) apply_filters(
				'dsm_preloader_prefer_native_view_transitions',
				true,
				$settings
			),
			'progressMode'                => (string) $settings['progress_mode'],
			'outStyle'                    => (string) $settings['transition_out_style'],
			'allowSkip'                   => (bool) apply_filters(
				'dsm_preloader_allow_visitor_skip',
				'on' === $this->on_off( $settings['allow_visitor_skip'] ?? 'on' ),
				$settings
			),
			'homeUrl'                     => home_url( '/' ),
			'skipPrefixes'                => $skip,
		);
	}

	/**
	 * URL prefixes that must never start a page transition.
	 *
	 * @param array<string, mixed> $settings Settings.
	 * @return string[]
	 */
	public function get_transition_skip_prefixes( array $settings ): array {
		$prefixes = array();

		if ( 'on' === ( $settings['exclude_woo_checkout'] ?? 'on' ) ) {
			if ( function_exists( 'wc_get_cart_url' ) ) {
				$prefixes[] = (string) wc_get_cart_url();
			}
			if ( function_exists( 'wc_get_checkout_url' ) ) {
				$prefixes[] = (string) wc_get_checkout_url();
			}
			if ( function_exists( 'wc_get_page_permalink' ) ) {
				$account = (string) wc_get_page_permalink( 'myaccount' );
				if ( '' !== $account ) {
					$prefixes[] = $account;
				}
			}
		}

		$prefixes = array_values(
			array_filter(
				array_map(
					static function ( $url ) {
						return untrailingslashit( esc_url_raw( (string) $url ) );
					},
					$prefixes
				)
			)
		);

		/**
		 * Filters URL prefixes that skip page-to-page transitions.
		 *
		 * @param string[]             $prefixes Prefixes.
		 * @param array<string, mixed> $settings Settings.
		 */
		return apply_filters( 'dsm_preloader_skip_url_prefixes', $prefixes, $settings );
	}

	/**
	 * Whether an internal href should play a page transition (PHP extensibility).
	 *
	 * @param string        $href Href.
	 * @param \WP_Post|null $post Current post, if any.
	 * @return bool
	 */
	public static function should_transition_link( string $href, $post = null ): bool {
		/**
		 * Filters whether a link should start a preloader page transition.
		 *
		 * @param bool          $ok   Whether to transition.
		 * @param \WP_Post|null $post Post.
		 * @param string        $href Href.
		 */
		return (bool) apply_filters( 'dsm_preloader_should_transition_link', true, $post, $href );
	}

	/**
	 * Persist the per-page enable flag from Visual Builder save.
	 *
	 * Current Divi 5 `divi_visual_builder_rest_save_post` only passes loop context
	 * as the second argument — not `pageSettings`. Read the already-parsed
	 * Visual Builder REST request, including `pageSettingsByLayout.postContent`.
	 *
	 * @param int                  $post_id Post ID.
	 * @param array<string, mixed> $data    Hook context (not the save payload).
	 * @return void
	 */
	public function save_page_settings_from_rest( int $post_id, array $data = array() ): void {
		if ( $post_id <= 0 ) {
			return;
		}

		$page_settings = $this->get_page_settings_from_vb_save( $data );
		if ( ! array_key_exists( 'dsm_preloader_page_enabled', $page_settings ) ) {
			return;
		}

		$this->set_page_enabled( $post_id, (string) $page_settings['dsm_preloader_page_enabled'] );
	}

	/**
	 * Write the per-page enable flag.
	 *
	 * @param int    $post_id Post ID.
	 * @param string $value   `on` or `off`.
	 * @return string Stored value.
	 */
	public function set_page_enabled( int $post_id, string $value ): string {
		$normalized = 'on' === $value ? 'on' : 'off';

		if ( $post_id > 0 ) {
			update_post_meta( $post_id, self::PAGE_META_KEY, $normalized );
		}

		return $normalized;
	}

	/**
	 * Per-page enable flag.
	 *
	 * @param int $post_id Post ID.
	 * @return string
	 */
	public function get_page_enabled( int $post_id ): string {
		if ( $post_id <= 0 ) {
			return 'off';
		}

		return 'on' === get_post_meta( $post_id, self::PAGE_META_KEY, true ) ? 'on' : 'off';
	}

	/**
	 * Page settings from a VB save hook or the current REST request body.
	 *
	 * @param mixed $data Hook payload.
	 * @return array<string, mixed>
	 */
	private function get_page_settings_from_vb_save( $data ): array {
		$from_hook = $this->extract_page_settings_array( $data );
		if ( array_key_exists( 'dsm_preloader_page_enabled', $from_hook ) ) {
			return $from_hook;
		}

		$from_rest = DsmVbRestSave::get_page_settings();
		if ( array_key_exists( 'dsm_preloader_page_enabled', $from_rest ) ) {
			return $from_rest;
		}

		$from_layout = DsmVbRestSave::get_page_settings_by_layout_post_content();
		if ( array_key_exists( 'dsm_preloader_page_enabled', $from_layout ) ) {
			return $from_layout;
		}

		return $from_hook;
	}

	/**
	 * Pull the page-settings object out of a VB save payload.
	 *
	 * @param mixed $data Decoded REST body or hook args.
	 * @return array<string, mixed>
	 */
	private function extract_page_settings_array( $data ): array {
		if ( ! is_array( $data ) ) {
			return array();
		}

		if ( isset( $data['pageSettings'] ) && is_array( $data['pageSettings'] ) ) {
			return $data['pageSettings'];
		}

		if ( isset( $data['pageSettingsByLayout']['postContent'] ) && is_array( $data['pageSettingsByLayout']['postContent'] ) ) {
			return $data['pageSettingsByLayout']['postContent'];
		}

		if ( array_key_exists( 'dsm_preloader_page_enabled', $data ) ) {
			return $data;
		}

		return array();
	}

	/**
	 * Static inner HTML for a preset.
	 *
	 * @param string $preset Preset slug.
	 * @return string
	 */
	public function get_preset_inner_html( string $preset ): string {
		$preset = $this->sanitize_preset( $preset );

		$map = array(
			'nested-rings'   => '<i></i><i></i>',
			'opposing-rings' => '<i></i><i></i>',
			'arc'            => '<i></i>',
			'dots-bounce'    => '<i></i><i></i><i></i>',
			'dots-pulse'     => '<i></i><i></i><i></i>',
			'dots-fade'      => '<i></i><i></i><i></i>',
			'dots-orbit'     => '<i></i>',
			'dots-typing'    => '<i></i><i></i><i></i>',
			'dots-collision' => '<i></i><i></i><i></i>',
			'bars-equalizer' => '<i></i><i></i><i></i><i></i>',
			'bars-wave'      => '<i></i><i></i><i></i><i></i>',
			'bars-mini'      => '<i></i><i></i><i></i>',
			'bars-slide'     => '<i></i>',
			'grid'           => '<i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i>',
			'cube-grid'      => '<i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i>',
			'flower'         => '<i></i><i></i><i></i><i></i><i></i>',
			'satellite'      => '<i></i>',
			'path-circle'    => '<svg viewBox="0 0 32 32" aria-hidden="true"><circle cx="16" cy="16" r="10"></circle></svg>',
			'path-tail'      => '<svg viewBox="0 0 32 32" aria-hidden="true"><circle cx="16" cy="16" r="10"></circle></svg>',
			'path-blocks'    => '<svg viewBox="0 0 32 32" aria-hidden="true"><rect x="4" y="12" width="6" height="8"></rect><rect x="13" y="8" width="6" height="16"></rect><rect x="22" y="12" width="6" height="8"></rect></svg>',
		);

		return $map[ $preset ] ?? '';
	}

	/**
	 * Whether this request asked to force one overlay view (`?dsm_pl=1`).
	 *
	 * @return bool
	 */
	private function is_force_preview_request(): bool {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only preview flag.
		if ( ! isset( $_GET['dsm_pl'] ) ) {
			return false;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only preview flag.
		return '1' === sanitize_text_field( wp_unslash( (string) $_GET['dsm_pl'] ) );
	}

	/**
	 * Short reason the overlay is not printed on this request.
	 *
	 * @return string
	 */
	private function get_skip_reason(): string {
		if ( is_admin() || wp_doing_ajax() || wp_doing_cron() ) {
			return 'admin-or-async';
		}

		if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
			return 'rest';
		}

		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			return 'cli';
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only presence checks.
		if ( isset( $_GET['et_fb'] ) || isset( $_GET['et_tb'] ) ) {
			return 'visual-builder';
		}

		if ( function_exists( 'et_core_is_fb_enabled' ) && et_core_is_fb_enabled() ) {
			return 'visual-builder';
		}

		$settings = $this->get_settings();

		if ( ! $this->normalize_bool_flag( $settings['is_enabled'] ?? false ) ) {
			return 'frontend-toggle-off';
		}

		if ( 'on' === ( $settings['hide_logged_in'] ?? 'off' ) && is_user_logged_in() ) {
			return 'hide-logged-in';
		}

		if ( 'on' === ( $settings['homepage_only'] ?? 'off' ) && ! is_front_page() ) {
			return 'homepage-only';
		}

		if ( $this->is_excluded_woo_request( $settings ) ) {
			return 'woo-exclude';
		}

		return 'display-rules';
	}

	/**
	 * Normalize a checkbox / toggle to bool.
	 *
	 * @param mixed $value Raw.
	 * @return bool
	 */
	private function normalize_bool_flag( $value ): bool {
		if ( is_bool( $value ) ) {
			return $value;
		}
		if ( is_int( $value ) ) {
			return 1 === $value;
		}
		if ( is_string( $value ) ) {
			$normalized = strtolower( trim( $value ) );
			if ( in_array( $normalized, array( '1', 'on', 'true', 'yes' ), true ) ) {
				return true;
			}
			if ( in_array( $normalized, array( '0', 'off', 'false', 'no', '' ), true ) ) {
				return false;
			}
		}

		return ! empty( $value );
	}

	/**
	 * Normalize a checkbox / toggle to on/off.
	 *
	 * @param mixed $value Raw.
	 * @return string
	 */
	private function on_off( $value ): string {
		return $this->normalize_bool_flag( $value ) ? 'on' : 'off';
	}

	/**
	 * Sanitize a preset slug.
	 *
	 * @param string $preset Slug.
	 * @return string
	 */
	private function sanitize_preset( string $preset ): string {
		$preset = sanitize_key( $preset );
		$preset = str_replace( '_', '-', $preset );

		return in_array( $preset, self::get_preset_slugs(), true ) ? $preset : 'ring';
	}

	/**
	 * Normalize logo setting to a URL string (string or Upload-shaped `{ src }` array).
	 *
	 * @param mixed $value Raw logo value from REST/modal.
	 * @return string
	 */
	private function normalize_logo_url_value( $value ): string {
		if ( is_string( $value ) ) {
			return $value;
		}

		if ( is_array( $value ) && isset( $value['src'] ) && is_string( $value['src'] ) ) {
			return $value['src'];
		}

		return '';
	}

	/**
	 * Flatten a ColorPicker leaf to a string.
	 *
	 * @param mixed $raw Raw color (string or ColorPicker object).
	 * @return string
	 */
	private function color_value_to_string( $raw ): string {
		if ( is_string( $raw ) ) {
			return trim( $raw );
		}

		if ( ! is_array( $raw ) ) {
			return '';
		}

		$type = isset( $raw['type'] ) ? strtolower( (string) $raw['type'] ) : '';
		$name = '';
		if ( isset( $raw['value']['name'] ) && is_string( $raw['value']['name'] ) ) {
			$name = trim( $raw['value']['name'] );
		}

		if ( '' !== $name && ( '' === $type || 'color' === $type || 'variable' === $type ) ) {
			$encoded = wp_json_encode(
				array(
					'type'  => 'color',
					'value' => array(
						'name' => $name,
					),
				)
			);

			return is_string( $encoded ) ? '$variable(' . $encoded . ')$' : '';
		}

		if ( isset( $raw['hex'] ) && is_string( $raw['hex'] ) ) {
			return trim( $raw['hex'] );
		}

		if ( isset( $raw['cssVariable'] ) && is_string( $raw['cssVariable'] ) ) {
			return trim( $raw['cssVariable'] );
		}

		if ( isset( $raw['value'] ) && is_string( $raw['value'] ) ) {
			return trim( $raw['value'] );
		}

		return '';
	}

	/**
	 * Sanitize a hex, rgba, or Divi variable color.
	 *
	 * Divi Global / Variable colours arrive as `$variable({"type":"color",…})$`
	 * or bare `gcid-*`. Hex-only sanitizing was stripping them to the fallback.
	 *
	 * @param string $color          Raw color.
	 * @param string $fallback_color Fallback.
	 * @return string
	 */
	private function sanitize_color( string $color, string $fallback_color ): string {
		$color = trim( $color );

		if ( '' === $color ) {
			return $fallback_color;
		}

		if ( strlen( $color ) > 800 ) {
			return $fallback_color;
		}

		if ( preg_match( '/[<>`]|(\x00)/', $color ) ) {
			return $fallback_color;
		}

		if ( preg_match( '/\b(?:expression|behavior|javascript|@import)\b/i', $color ) ) {
			return $fallback_color;
		}

		if ( function_exists( 'sanitize_hex_color' ) ) {
			$hex = sanitize_hex_color( $color );
			if ( is_string( $hex ) && '' !== $hex ) {
				return $hex;
			}
		}

		if ( preg_match( '/^(#([0-9a-fA-F]{3}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})|rgba?\([^;{}]+\)|hsla?\([^;{}]+\)|var\(--[a-zA-Z0-9_-]+(?:,\s*[^;{}]+)?\))$/', $color ) ) {
			return $color;
		}

		if ( preg_match( '/^gcid-[a-zA-Z0-9_-]+$/', $color ) ) {
			return $color;
		}

		$variable_name = $this->extract_divi_color_variable_name( $color );
		if ( is_string( $variable_name ) && '' !== $variable_name ) {
			return $color;
		}

		return $fallback_color;
	}

	/**
	 * Extract a safe CSS custom-property name from a Divi `$variable({…})$` token.
	 *
	 * @param string $color Raw ColorPicker value.
	 * @return string|null
	 */
	private function extract_divi_color_variable_name( string $color ): ?string {
		$color = trim( $color );
		if ( ! str_starts_with( $color, '$variable(' ) || ! str_ends_with( $color, ')$' ) ) {
			return null;
		}

		$payload = substr( $color, strlen( '$variable(' ), -2 );
		$decoded = json_decode( $payload, true );
		if ( ! is_array( $decoded ) ) {
			$decoded = json_decode( stripslashes( $payload ), true );
		}
		if ( ! is_array( $decoded ) ) {
			return null;
		}

		$type = isset( $decoded['type'] ) ? strtolower( (string) $decoded['type'] ) : '';
		if ( '' !== $type && 'color' !== $type && 'variable' !== $type ) {
			return null;
		}

		$name = '';
		if ( isset( $decoded['value']['name'] ) && is_string( $decoded['value']['name'] ) ) {
			$name = $decoded['value']['name'];
		} elseif ( isset( $decoded['value'] ) && is_string( $decoded['value'] ) ) {
			$name = $decoded['value'];
		}

		$name = ltrim( trim( $name ), '-' );
		if ( '' === $name || ! preg_match( '/^[a-zA-Z0-9_-]+$/', $name ) ) {
			return null;
		}

		return $name;
	}

	/**
	 * CSS paint for overlay emission (`var(--gcid-…)` or concrete hex/rgba).
	 *
	 * @param mixed  $raw      Stored color.
	 * @param string $fallback Fallback paint.
	 * @return string
	 */
	private function color_for_css( $raw, string $fallback ): string {
		$normalized = $this->normalize_color_for_css( $this->color_value_to_string( $raw ) );

		return '' !== $normalized ? $normalized : $fallback;
	}

	/**
	 * Soft-migrate a stored ColorPicker value to a CSS paint string.
	 *
	 * @param string $color Sanitized stored color.
	 * @return string
	 */
	private function normalize_color_for_css( string $color ): string {
		$color = trim( $color );
		if ( '' === $color ) {
			return '';
		}

		$variable_name = $this->extract_divi_color_variable_name( $color );
		if ( ! is_string( $variable_name ) || '' === $variable_name ) {
			if ( preg_match( '/^gcid-[a-zA-Z0-9_-]+$/', $color ) ) {
				$variable_name = $color;
			}
		}

		if ( is_string( $variable_name ) && '' !== $variable_name ) {
			$resolved = $this->resolve_divi_global_color_paint( $color, $variable_name );
			if ( '' !== $resolved ) {
				return $resolved;
			}

			return 'var(--' . $variable_name . ')';
		}

		if ( class_exists( '\ET\Builder\Packages\GlobalData\GlobalData' )
			&& 0 === stripos( $color, 'var(' )
		) {
			$gcid = \ET\Builder\Packages\GlobalData\GlobalData::get_global_color_id_from_value( $color );
			if ( is_string( $gcid ) && '' !== $gcid ) {
				$resolved = $this->resolve_divi_global_color_paint( $color, $gcid );
				if ( '' !== $resolved ) {
					return $resolved;
				}
			}

			return $color;
		}

		if ( false !== strpos( $color, '$variable(' ) ) {
			return '';
		}

		return $color;
	}

	/**
	 * Resolve a Divi global colour id / `$variable` token to a concrete CSS paint.
	 *
	 * @param string $raw  Original stored value.
	 * @param string $gcid Normalised `gcid-…` id.
	 * @return string Concrete hex/rgba/hsl, or empty when unresolvable.
	 */
	private function resolve_divi_global_color_paint( string $raw, string $gcid ): string {
		if ( ! class_exists( '\ET\Builder\Packages\GlobalData\GlobalData' ) ) {
			return '';
		}

		$global_colors = \ET\Builder\Packages\GlobalData\GlobalData::get_global_colors();
		$candidates    = array( $raw, $gcid );

		foreach ( $candidates as $candidate ) {
			if ( ! is_string( $candidate ) || '' === trim( $candidate ) ) {
				continue;
			}

			$resolved = \ET\Builder\Packages\GlobalData\GlobalData::resolve_global_color_variable(
				$candidate,
				$global_colors
			);

			$paint = $this->concrete_css_paint_from_resolved( is_string( $resolved ) ? $resolved : '' );
			if ( '' !== $paint ) {
				return $paint;
			}
		}

		$color_data = \ET\Builder\Packages\GlobalData\GlobalData::get_global_color_by_id( $gcid );
		$palette    = is_array( $color_data ) ? ( $color_data['color'] ?? '' ) : '';
		if ( ! is_string( $palette ) || '' === trim( $palette ) ) {
			return '';
		}

		$nested = \ET\Builder\Packages\GlobalData\GlobalData::resolve_global_color_variable(
			trim( $palette ),
			$global_colors
		);

		$paint = $this->concrete_css_paint_from_resolved( is_string( $nested ) ? $nested : '' );
		if ( '' !== $paint ) {
			return $paint;
		}

		return $this->concrete_css_paint_from_resolved( trim( $palette ) );
	}

	/**
	 * Accept only concrete CSS colour paints (reject leftover tokens / var()).
	 *
	 * @param string $value Resolved candidate.
	 * @return string
	 */
	private function concrete_css_paint_from_resolved( string $value ): string {
		$value = trim( $value );
		if ( '' === $value ) {
			return '';
		}

		if ( false !== strpos( $value, '$variable(' ) ) {
			return '';
		}

		if ( 0 === stripos( $value, 'var(' ) ) {
			return '';
		}

		if ( preg_match( '/^gcid-[a-zA-Z0-9_-]+$/', $value ) ) {
			return '';
		}

		if ( function_exists( 'sanitize_hex_color' ) ) {
			$hex = sanitize_hex_color( $value );
			if ( is_string( $hex ) && '' !== $hex ) {
				return $hex;
			}
		}

		if ( preg_match( '/^(#([0-9a-fA-F]{3}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})|rgba?\([^;{}]+\)|hsla?\([^;{}]+\))$/', $value ) ) {
			return $value;
		}

		return '';
	}

	/**
	 * Whether a decoration.background value has gradient or image paint.
	 *
	 * @param array<string, mixed> $value Desktop value node.
	 * @return bool
	 */
	private function overlay_background_has_non_color_layers( array $value ): bool {
		$gradient = isset( $value['gradient'] ) && is_array( $value['gradient'] ) ? $value['gradient'] : array();
		if ( isset( $gradient['enabled'] ) && 'on' === $gradient['enabled'] ) {
			return true;
		}

		$image = isset( $value['image'] ) && is_array( $value['image'] ) ? $value['image'] : array();
		$url   = isset( $image['url'] ) && is_string( $image['url'] ) ? trim( $image['url'] ) : '';

		return '' !== $url;
	}

	/**
	 * Soft-migrate legacy solid / two-colour settings into overlay_background.
	 *
	 * @param array<string, mixed> $settings Settings.
	 * @return array<string, mixed>
	 */
	private function migrate_legacy_overlay_background( array $settings ): array {
		$existing       = isset( $settings['overlay_background'] ) && is_array( $settings['overlay_background'] )
			? $settings['overlay_background']
			: array();
		$existing_value = isset( $existing['desktop']['value'] ) && is_array( $existing['desktop']['value'] )
			? $existing['desktop']['value']
			: array();

		$existing_color = isset( $existing_value['color'] ) && is_string( $existing_value['color'] )
			? trim( $existing_value['color'] )
			: '';

		if ( '' !== $existing_color || $this->overlay_background_has_non_color_layers( $existing_value ) ) {
			return $settings;
		}

		$color_1 = $this->sanitize_color( $this->color_value_to_string( $settings['background_color'] ?? '' ), '#ffffff' );
		$color_2 = $this->sanitize_color( $this->color_value_to_string( $settings['background_color_2'] ?? '' ), '' );

		$value = array(
			'color'       => $color_1,
			'enableColor' => 'on',
		);

		if ( '' !== $color_2 ) {
			$value['gradient'] = array(
				'enabled'         => 'on',
				'type'            => 'linear',
				'direction'       => '160deg',
				'directionRadial' => 'center',
				'length'          => '100%',
				'repeat'          => 'off',
				'overlaysImage'   => 'off',
				'stops'           => array(
					array(
						'position' => '0',
						'color'    => $color_1,
					),
					array(
						'position' => '100',
						'color'    => $color_2,
					),
				),
			);
		}

		$settings['overlay_background'] = array(
			'desktop' => array(
				'value' => $value,
			),
		);

		return $settings;
	}

	/**
	 * Keep legacy colour keys in sync with overlay_background after sanitize.
	 *
	 * @param array<string, mixed> $settings Settings.
	 * @return array<string, mixed>
	 */
	private function sync_legacy_background_colors_from_overlay( array $settings ): array {
		$value = isset( $settings['overlay_background']['desktop']['value'] ) && is_array( $settings['overlay_background']['desktop']['value'] )
			? $settings['overlay_background']['desktop']['value']
			: array();

		$color = $this->sanitize_color( $this->color_value_to_string( $value['color'] ?? '' ), '#ffffff' );
		$end   = '';
		if ( isset( $value['gradient']['enabled'] ) && 'on' === $value['gradient']['enabled']
			&& isset( $value['gradient']['stops'][1]['color'] ) ) {
			$end = $this->sanitize_color( $this->color_value_to_string( $value['gradient']['stops'][1]['color'] ), '' );
		}

		$settings['background_color']   = $color;
		$settings['background_color_2'] = $end;

		return $settings;
	}

	/**
	 * Overlay background image URL when enabled.
	 *
	 * @param array<string, mixed> $settings Settings.
	 * @return string
	 */
	private function get_overlay_background_image_url( array $settings ): string {
		$value = $this->get_overlay_background_value( $settings );
		$image = isset( $value['image'] ) && is_array( $value['image'] ) ? $value['image'] : array();
		if ( isset( $image['enabled'] ) && 'off' === $image['enabled'] ) {
			return '';
		}

		return isset( $image['url'] ) ? esc_url( (string) $image['url'] ) : '';
	}

	/**
	 * Sanitize a Divi decoration.background attr (desktop only).
	 *
	 * @param mixed $raw Raw overlay_background.
	 * @return array<string, mixed>
	 */
	private function sanitize_overlay_background( $raw ): array {
		$attr  = is_array( $raw ) ? $raw : array();
		$value = isset( $attr['desktop']['value'] ) && is_array( $attr['desktop']['value'] )
			? $attr['desktop']['value']
			: array();

		$color = $this->sanitize_color( $this->color_value_to_string( $value['color'] ?? '' ), '#ffffff' );

		$out = array(
			'color'       => $color,
			'enableColor' => 'on',
		);

		if ( isset( $value['gradient'] ) && is_array( $value['gradient'] ) ) {
			$gradient = $value['gradient'];
			$stops    = array();
			if ( isset( $gradient['stops'] ) && is_array( $gradient['stops'] ) ) {
				foreach ( $gradient['stops'] as $stop ) {
					if ( ! is_array( $stop ) ) {
						continue;
					}
					$stop_color = $this->sanitize_color( $this->color_value_to_string( $stop['color'] ?? '' ), '' );
					if ( '' === $stop_color ) {
						continue;
					}
					$position = isset( $stop['position'] ) ? (string) $stop['position'] : '0';
					$position = preg_replace( '/[^\d.]/', '', $position );
					$stops[]  = array(
						'position' => is_string( $position ) && '' !== $position ? $position : '0',
						'color'    => $stop_color,
					);
				}
			}

			$out['gradient'] = array(
				'enabled'         => 'on' === ( $gradient['enabled'] ?? 'off' ) ? 'on' : 'off',
				'type'            => $this->sanitize_key_in(
					(string) ( $gradient['type'] ?? 'linear' ),
					array( 'linear', 'radial', 'circular', 'conic' ),
					'linear'
				),
				'direction'       => $this->sanitize_css_length_token( (string) ( $gradient['direction'] ?? '180deg' ), '180deg', array( 'deg' ) ),
				'directionRadial' => sanitize_text_field( (string) ( $gradient['directionRadial'] ?? 'center' ) ),
				'length'          => $this->sanitize_css_length_token( (string) ( $gradient['length'] ?? '100%' ), '100%', array( '%' ) ),
				'repeat'          => 'on' === ( $gradient['repeat'] ?? 'off' ) ? 'on' : 'off',
				'overlaysImage'   => 'on' === ( $gradient['overlaysImage'] ?? 'off' ) ? 'on' : 'off',
				'stops'           => $stops,
			);
		}

		if ( isset( $value['image'] ) && is_array( $value['image'] ) ) {
			$image        = $value['image'];
			$url          = isset( $image['url'] ) ? esc_url_raw( (string) $image['url'] ) : '';
			$out['image'] = array(
				'url'      => $url,
				'enabled'  => '' !== $url && 'off' !== ( $image['enabled'] ?? 'on' ) ? 'on' : 'off',
				'size'     => $this->sanitize_key_in(
					(string) ( $image['size'] ?? 'cover' ),
					array( 'cover', 'contain', 'initial', 'stretch', 'custom' ),
					'cover'
				),
				'position' => sanitize_text_field( (string) ( $image['position'] ?? 'center' ) ),
				'repeat'   => $this->sanitize_key_in(
					(string) ( $image['repeat'] ?? 'no-repeat' ),
					array( 'no-repeat', 'repeat', 'repeat-x', 'repeat-y', 'space', 'round' ),
					'no-repeat'
				),
				'blend'    => sanitize_text_field( (string) ( $image['blend'] ?? 'normal' ) ),
			);
		}

		return array(
			'desktop' => array(
				'value' => $out,
			),
		);
	}

	/**
	 * Desktop overlay background value after migrate + sanitize.
	 *
	 * @param array<string, mixed> $settings Settings.
	 * @return array<string, mixed>
	 */
	private function get_overlay_background_value( array $settings ): array {
		$settings = $this->migrate_legacy_overlay_background( $settings );
		$attr     = $this->sanitize_overlay_background( $settings['overlay_background'] ?? array() );

		return isset( $attr['desktop']['value'] ) && is_array( $attr['desktop']['value'] )
			? $attr['desktop']['value']
			: array(
				'color'       => '#ffffff',
				'enableColor' => 'on',
			);
	}

	/**
	 * Solid overlay colour for the early html/body paint lock.
	 *
	 * @param array<string, mixed> $settings Settings.
	 * @return string
	 */
	private function get_paint_lock_background_color( array $settings ): string {
		return $this->color_for_css(
			( $this->get_overlay_background_value( $settings )['color'] ?? '' ),
			'#ffffff'
		);
	}

	/**
	 * CSS custom properties for leftover SCSS fallbacks.
	 *
	 * @param array<string, mixed> $settings Settings.
	 * @return string
	 */
	private function get_overlay_background_css_vars( array $settings ): string {
		$value = $this->get_overlay_background_value( $settings );
		$color = $this->color_for_css( $value['color'] ?? '', '#ffffff' );
		$end   = $color;

		if ( isset( $value['gradient']['stops'][1]['color'] ) ) {
			$end = $this->color_for_css( $value['gradient']['stops'][1]['color'], $color );
		}

		return sprintf(
			'--dsm-pl-bg:%1$s;--dsm-pl-bg-2:%2$s;',
			esc_attr( $color ),
			esc_attr( $end )
		);
	}

	/**
	 * Inline background longhands for #dsm-preloader.
	 *
	 * @param array<string, mixed> $settings Settings.
	 * @return string
	 */
	private function get_overlay_background_inline_style( array $settings ): string {
		$decls = $this->build_overlay_background_declarations( $settings );
		if ( array() === $decls ) {
			return '';
		}

		$parts = array();
		foreach ( $decls as $prop => $val ) {
			$parts[] = $prop . ':' . $val;
		}

		return implode( ';', $parts ) . ';';
	}

	/**
	 * Progress bar CSS variables (thickness + optional colour override).
	 *
	 * Empty colour keeps `var(--dsm-pl-color)` from critical CSS.
	 *
	 * @param array<string, mixed> $settings Settings.
	 * @return string
	 */
	private function get_progress_style_css( array $settings ): string {
		$thickness = (int) $this->sanitize_int_range(
			(string) ( $settings['progress_thickness'] ?? '3' ),
			1,
			16,
			3
		);
		$color     = $this->color_for_css( $settings['progress_color'] ?? '', '' );
		$css       = sprintf( '--dsm-pl-progress-thickness:%dpx;', $thickness );

		if ( '' !== $color ) {
			$css .= sprintf( '--dsm-pl-progress-color:%s;', $color );
		}

		/**
		 * Filters progress-bar CSS custom properties on the overlay.
		 *
		 * @param string               $css      Custom-property declarations.
		 * @param array<string, mixed> $settings Settings.
		 */
		return (string) apply_filters( 'dsm_preloader_progress_style', $css, $settings );
	}

	/**
	 * Critical @media hide so small viewports never paint the overlay.
	 *
	 * Viewport is unknown in PHP; this CSS-first hide avoids a JS-after-paint flash.
	 * Visual Builder preview is not targeted.
	 *
	 * @param array<string, mixed> $settings Settings.
	 * @return string
	 */
	private function build_hide_on_mobile_css( array $settings ): string {
		if ( 'on' !== ( $settings['hide_on_mobile'] ?? 'off' ) ) {
			return '';
		}

		$max = (int) $settings['mobile_max_width'];
		if ( $max < 320 ) {
			$max = 767;
		}

		$css = sprintf(
			'@media (max-width:%dpx){html:not([data-dsm-pl-force="1"]) #dsm-preloader{display:none!important}}',
			$max
		);

		/**
		 * Filters the hide-on-mobile critical CSS rule.
		 *
		 * @param string               $css      Media-query rule.
		 * @param array<string, mixed> $settings Settings.
		 * @param int                  $max      Max width in px.
		 */
		return (string) apply_filters( 'dsm_preloader_hide_on_mobile_css', $css, $settings, $max );
	}

	/**
	 * Opt in to cross-document View Transitions when page transitions are on.
	 *
	 * Reloads and typed-URL navigations stay excluded by the browser.
	 * Reduced-motion visitors get navigation: none. Unsupported browsers ignore the at-rule.
	 *
	 * @param array<string, mixed> $settings Settings.
	 * @return string
	 */
	private function get_view_transition_css( array $settings ): string {
		$enabled = 'on' === $this->on_off( $settings['page_transitions'] ?? 'on' );

		/**
		 * Filters whether to print @view-transition { navigation: auto }.
		 *
		 * @param bool                 $enabled  Whether to opt in.
		 * @param array<string, mixed> $settings Settings.
		 */
		$enabled = (bool) apply_filters( 'dsm_preloader_print_view_transitions', $enabled, $settings );

		if ( ! $enabled ) {
			return '';
		}

		$css = '@view-transition{navigation:auto}@media (prefers-reduced-motion:reduce){@view-transition{navigation:none}}';

		/**
		 * Filters the View Transition critical CSS.
		 *
		 * @param string               $css      At-rules.
		 * @param array<string, mixed> $settings Settings.
		 */
		return (string) apply_filters( 'dsm_preloader_view_transition_css', $css, $settings );
	}

	/**
	 * Full-rule overlay background CSS for the critical stylesheet.
	 *
	 * @param array<string, mixed> $settings Settings.
	 * @return string
	 */
	private function build_overlay_background_css( array $settings ): string {
		$decls = $this->build_overlay_background_declarations( $settings );
		if ( array() === $decls ) {
			return '';
		}

		$parts = array();
		foreach ( $decls as $prop => $val ) {
			$parts[] = $prop . ':' . $val;
		}

		$css = ':is(#dsm-preloader,#dsm-preloader-vb-preview){' . implode( ';', $parts ) . ';}';

		/**
		 * Filters generated Preloader overlay background CSS.
		 *
		 * @param string               $css      CSS rule.
		 * @param array<string, mixed> $settings Settings.
		 */
		return (string) apply_filters( 'dsm_preloader_overlay_background_css', $css, $settings );
	}

	/**
	 * Sanitized CSS declarations for the overlay background.
	 *
	 * @param array<string, mixed> $settings Settings.
	 * @return array<string, string>
	 */
	private function build_overlay_background_declarations( array $settings ): array {
		$value = $this->get_overlay_background_value( $settings );
		$color = $this->color_for_css( $value['color'] ?? '', '#ffffff' );

		$decls = array(
			'background-color' => $color,
		);

		$images    = array();
		$image     = isset( $value['image'] ) && is_array( $value['image'] ) ? $value['image'] : array();
		$image_on  = ! isset( $image['enabled'] ) || 'off' !== $image['enabled'];
		$image_url = $image_on && isset( $image['url'] ) ? esc_url( (string) $image['url'] ) : '';
		if ( '' !== $image_url ) {
			$images[] = 'url("' . $image_url . '")';
		}

		$gradient_css = $this->overlay_gradient_css(
			isset( $value['gradient'] ) && is_array( $value['gradient'] ) ? $value['gradient'] : array()
		);
		if ( '' !== $gradient_css ) {
			$overlays = isset( $value['gradient']['overlaysImage'] ) && 'on' === $value['gradient']['overlaysImage'];
			if ( $overlays ) {
				array_unshift( $images, $gradient_css );
			} else {
				$images[] = $gradient_css;
			}
		}

		if ( array() !== $images ) {
			$decls['background-image']    = implode( ', ', $images );
			$decls['background-repeat']   = $this->sanitize_key_in(
				(string) ( $image['repeat'] ?? 'no-repeat' ),
				array( 'no-repeat', 'repeat', 'repeat-x', 'repeat-y', 'space', 'round' ),
				'no-repeat'
			);
			$decls['background-size']     = $this->overlay_image_size_css( (string) ( $image['size'] ?? 'cover' ) );
			$decls['background-position'] = $this->overlay_image_position_css( (string) ( $image['position'] ?? 'center' ) );
		}

		return $decls;
	}

	/**
	 * CSS gradient from a Divi gradient value node.
	 *
	 * @param array<string, mixed> $gradient Gradient node.
	 * @return string
	 */
	private function overlay_gradient_css( array $gradient ): string {
		if ( 'on' !== ( $gradient['enabled'] ?? 'off' ) ) {
			return '';
		}

		$stops = isset( $gradient['stops'] ) && is_array( $gradient['stops'] ) ? $gradient['stops'] : array();
		$parts = array();
		foreach ( $stops as $stop ) {
			if ( ! is_array( $stop ) ) {
				continue;
			}
			$stop_color = $this->color_for_css( $stop['color'] ?? '', '' );
			if ( '' === $stop_color ) {
				continue;
			}
			$position = isset( $stop['position'] ) ? preg_replace( '/[^\d.]/', '', (string) $stop['position'] ) : '';
			$parts[]  = ( is_string( $position ) && '' !== $position ) ? $stop_color . ' ' . $position . '%' : $stop_color;
		}

		if ( array() === $parts ) {
			return '';
		}

		$stop_css  = implode( ', ', $parts );
		$type      = (string) ( $gradient['type'] ?? 'linear' );
		$direction = (string) ( $gradient['direction'] ?? '180deg' );
		$radial    = sanitize_text_field( (string) ( $gradient['directionRadial'] ?? 'center' ) );

		if ( 'radial' === $type || 'circular' === $type ) {
			return 'radial-gradient(circle at ' . $radial . ', ' . $stop_css . ')';
		}

		if ( 'conic' === $type ) {
			return 'conic-gradient(from ' . $direction . ' at ' . $radial . ', ' . $stop_css . ')';
		}

		return 'linear-gradient(' . $direction . ', ' . $stop_css . ')';
	}

	/**
	 * Map a Divi image size token to CSS background-size.
	 *
	 * @param string $size Divi image size token.
	 * @return string
	 */
	private function overlay_image_size_css( string $size ): string {
		if ( 'contain' === $size ) {
			return 'contain';
		}
		if ( 'initial' === $size ) {
			return 'auto';
		}
		if ( 'stretch' === $size ) {
			return '100% 100%';
		}

		return 'cover';
	}

	/**
	 * Map a Divi image position token to CSS background-position.
	 *
	 * @param string $position Divi image position token.
	 * @return string
	 */
	private function overlay_image_position_css( string $position ): string {
		$position = str_replace( '_', ' ', sanitize_text_field( $position ) );

		return '' !== $position ? $position : 'center';
	}

	/**
	 * Sanitize one px size leaf (Range string, number, or `{ value, unit }`).
	 *
	 * @param mixed $leaf        Raw leaf.
	 * @param int   $min         Min px.
	 * @param int   $max         Max px.
	 * @param int   $fallback    Fallback px.
	 * @param bool  $allow_empty Omit empty tablet/phone leaves.
	 * @return string CSS length or empty string.
	 */
	private function sanitize_px_leaf( $leaf, int $min, int $max, int $fallback, bool $allow_empty = false ): string {
		if ( is_array( $leaf ) && isset( $leaf['value'] ) ) {
			$leaf = $leaf['value'];
		}

		if ( null === $leaf || false === $leaf ) {
			return $allow_empty ? '' : $fallback . 'px';
		}

		if ( is_string( $leaf ) ) {
			$leaf = trim( $leaf );
			if ( '' === $leaf ) {
				return $allow_empty ? '' : $fallback . 'px';
			}
		}

		if ( is_string( $leaf ) && preg_match( '/-?\d+/', $leaf, $matches ) ) {
			$n = (int) $matches[0];
		} elseif ( is_numeric( $leaf ) ) {
			$n = (int) $leaf;
		} else {
			return $allow_empty ? '' : $fallback . 'px';
		}

		// 0 is empty only when the floor is above 0 (logo / text). Animation size min is 0.
		if ( 0 === $n && $min > 0 ) {
			return $allow_empty ? '' : $fallback . 'px';
		}

		if ( $n < $min ) {
			$n = $min;
		} elseif ( $n > $max ) {
			$n = $max;
		}

		return $n . 'px';
	}

	/**
	 * Sanitize a responsive px map. Legacy unitless `"48"` becomes `{ desktop: "48px" }`.
	 *
	 * @param mixed $raw      Map, string, or numeric.
	 * @param int   $min      Min px.
	 * @param int   $max      Max px.
	 * @param int   $fallback Desktop fallback px.
	 * @return array<string, string>
	 */
	private function sanitize_responsive_px_map( $raw, int $min, int $max, int $fallback ): array {
		$fallback_css = $fallback . 'px';

		if ( is_string( $raw ) || is_numeric( $raw ) ) {
			return array(
				'desktop' => $this->sanitize_px_leaf( $raw, $min, $max, $fallback ),
			);
		}

		if ( ! is_array( $raw ) ) {
			return array(
				'desktop' => $fallback_css,
			);
		}

		$allowed_bp = array( 'desktop', 'tablet', 'tabletWide', 'phone', 'phoneWide' );
		$out        = array();

		foreach ( $allowed_bp as $bp ) {
			if ( ! array_key_exists( $bp, $raw ) ) {
				continue;
			}

			$allow_empty = 'desktop' !== $bp;
			$leaf        = $this->sanitize_px_leaf( $raw[ $bp ], $min, $max, $fallback, $allow_empty );
			if ( '' !== $leaf ) {
				$out[ $bp ] = $leaf;
			}
		}

		if ( ! isset( $out['desktop'] ) ) {
			$out['desktop'] = $fallback_css;
		}

		return $out;
	}

	/**
	 * Resolve a size CSS length at a breakpoint (phone ← tablet ← desktop).
	 *
	 * @param array<string, mixed> $settings   Settings.
	 * @param string               $key        Size key.
	 * @param string               $breakpoint Breakpoint name.
	 * @param int                  $min        Min px.
	 * @param int                  $max        Max px.
	 * @param int                  $fallback   Desktop fallback px.
	 * @return string
	 */
	private function resolve_size_css( array $settings, string $key, string $breakpoint, int $min, int $max, int $fallback ): string {
		$map = $this->sanitize_responsive_px_map( $settings[ $key ] ?? $fallback, $min, $max, $fallback );

		$normalized = $breakpoint;
		if ( 'tabletWide' === $breakpoint ) {
			$normalized = 'tablet';
		} elseif ( 'phoneWide' === $breakpoint ) {
			$normalized = 'phone';
		}

		$ladder = array( 'desktop' );
		if ( 'tablet' === $normalized ) {
			$ladder = array( 'tablet', 'tabletWide', 'desktop' );
		} elseif ( 'phone' === $normalized ) {
			$ladder = array( 'phone', 'phoneWide', 'tablet', 'tabletWide', 'desktop' );
		}

		foreach ( $ladder as $bp ) {
			if ( isset( $map[ $bp ] ) && is_string( $map[ $bp ] ) && '' !== $map[ $bp ] ) {
				return $map[ $bp ];
			}
		}

		return $fallback . 'px';
	}

	/**
	 * Whether any size map has an explicit tablet/phone leaf.
	 *
	 * @param array<string, mixed> $settings Settings.
	 * @return bool
	 */
	private function has_size_breakpoint_overrides( array $settings ): bool {
		$keys = array(
			'animation_size',
			'logo_max_width',
			'text_size',
			'text_color',
			'text_font_weight',
			'text_line_height',
			'text_letter_spacing',
			'text_align',
			'text_capitalization',
		);

		foreach ( $keys as $key ) {
			$map = $settings[ $key ] ?? null;
			if ( ! is_array( $map ) ) {
				continue;
			}

			foreach ( array( 'tablet', 'tabletWide', 'phone', 'phoneWide' ) as $bp ) {
				if ( isset( $map[ $bp ] ) && '' !== (string) $map[ $bp ] ) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Enabled Divi breakpoints, or desktop/tablet/phone fallbacks.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	private function get_enabled_breakpoints(): array {
		$class = self::DSM_ET_BREAKPOINT_CLASS;
		if ( class_exists( $class ) && method_exists( $class, 'get_enabled_breakpoints' ) ) {
			$enabled = call_user_func( array( $class, 'get_enabled_breakpoints' ) );
			if ( is_array( $enabled ) && array() !== $enabled ) {
				return $enabled;
			}
		}

		return $this->get_fallback_enabled_breakpoints();
	}

	/**
	 * Default desktop / tablet (980) / phone (767) breakpoints.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	private function get_fallback_enabled_breakpoints(): array {
		return array(
			array(
				'order'  => 50,
				'enable' => true,
				'name'   => 'desktop',
			),
			array(
				'order'    => 30,
				'enable'   => true,
				'name'     => 'tablet',
				'maxWidth' => array(
					'value'   => '980px',
					'default' => 980,
				),
			),
			array(
				'order'    => 10,
				'enable'   => true,
				'name'     => 'phone',
				'maxWidth' => array(
					'value'   => '767px',
					'default' => 767,
				),
			),
		);
	}

	/**
	 * Max-width in px for a non-desktop breakpoint.
	 *
	 * @param array<string, mixed> $breakpoint Breakpoint entry.
	 * @return int|null
	 */
	private function get_breakpoint_media_max_px( array $breakpoint ): ?int {
		$name = isset( $breakpoint['name'] ) && is_string( $breakpoint['name'] ) ? $breakpoint['name'] : '';
		if ( '' === $name || 'desktop' === $name ) {
			return null;
		}

		if ( isset( $breakpoint['maxWidth']['default'] ) && is_numeric( $breakpoint['maxWidth']['default'] ) ) {
			return (int) $breakpoint['maxWidth']['default'];
		}

		if ( isset( $breakpoint['maxWidth']['value'] ) ) {
			$raw = $breakpoint['maxWidth']['value'];
			if ( is_numeric( $raw ) ) {
				$parsed = (int) $raw;
				return $parsed > 0 ? $parsed : null;
			}
			if ( is_string( $raw ) && '' !== trim( $raw ) ) {
				$parsed = (int) $raw;
				return $parsed > 0 ? $parsed : null;
			}
		}

		$fallback_by_name = array(
			'tablet'     => 980,
			'phone'      => 767,
			'phoneWide'  => 860,
			'tabletWide' => 1024,
		);

		return $fallback_by_name[ $name ] ?? null;
	}

	/**
	 * Size + responsive typography custom properties at one breakpoint.
	 *
	 * @param array<string, mixed> $settings   Settings.
	 * @param string               $breakpoint Breakpoint name.
	 * @return string
	 */
	private function get_responsive_overlay_css_decls( array $settings, string $breakpoint ): string {
		$cap       = $this->sanitize_text_capitalization(
			$this->resolve_scalar_css( $settings, 'text_capitalization', $breakpoint, '' )
		);
		$transform = in_array( $cap, array( 'uppercase', 'lowercase', 'capitalize' ), true ) ? $cap : 'none';
		$variant   = 'smallCaps' === $cap ? 'small-caps' : ( 'allSmallCaps' === $cap ? 'all-small-caps' : 'normal' );

		$enter_ms = $this->sanitize_int_range( (string) ( $settings['enter_ms'] ?? '450' ), 0, 2000, 450 );

		return sprintf(
			'--dsm-pl-size:%1$s;--dsm-pl-logo-max:%2$s;--dsm-pl-text-size:%3$s;--dsm-pl-text:%4$s;--dsm-pl-text-weight:%5$s;--dsm-pl-text-line-height:%6$s;--dsm-pl-text-letter-spacing:%7$s;--dsm-pl-text-align:%8$s;--dsm-pl-text-transform:%9$s;--dsm-pl-text-variant-caps:%10$s;--dsm-pl-enter-ms:%11$s;',
			esc_attr( $this->resolve_size_css( $settings, 'animation_size', $breakpoint, 0, 120, 48 ) ),
			esc_attr( $this->resolve_size_css( $settings, 'logo_max_width', $breakpoint, 40, 400, 160 ) ),
			esc_attr( $this->resolve_size_css( $settings, 'text_size', $breakpoint, 10, 28, 14 ) ),
			esc_attr( $this->color_for_css( $this->resolve_scalar_css( $settings, 'text_color', $breakpoint, '#1a1a1a' ), '#1a1a1a' ) ),
			esc_attr( $this->sanitize_text_font_weight( $this->resolve_scalar_css( $settings, 'text_font_weight', $breakpoint, '400' ) ) ),
			esc_attr( $this->sanitize_css_length_token( $this->resolve_scalar_css( $settings, 'text_line_height', $breakpoint, '1.4em' ), '1.4em', array( 'em', 'px', '%' ) ) ),
			esc_attr( $this->sanitize_css_length_token( $this->resolve_scalar_css( $settings, 'text_letter_spacing', $breakpoint, '0px' ), '0px', array( 'px', 'em' ), true ) ),
			esc_attr( $this->sanitize_key_in( $this->resolve_scalar_css( $settings, 'text_align', $breakpoint, 'center' ), array( 'left', 'center', 'right', 'justify' ), 'center' ) ),
			esc_attr( $transform ),
			esc_attr( $variant ),
			esc_attr( $enter_ms . 'ms' )
		);
	}

	/**
	 * Desktop size CSS variables plus tablet/phone @media overrides.
	 *
	 * Must not be inlined on the overlay — inline custom properties win over
	 * stylesheet @media rules, so phone/tablet sizes would never apply.
	 *
	 * @param array<string, mixed> $settings Settings.
	 * @return string
	 */
	private function build_responsive_size_css( array $settings ): string {
		$selector = ':is(#dsm-preloader,#dsm-preloader-vb-preview)';
		$css      = sprintf(
			'%1$s{%2$s}',
			$selector,
			$this->get_responsive_overlay_css_decls( $settings, 'desktop' )
		);

		if ( $this->has_size_breakpoint_overrides( $settings ) ) {
			foreach ( $this->get_enabled_breakpoints() as $breakpoint ) {
				if ( ! is_array( $breakpoint ) || ! isset( $breakpoint['name'] ) || ! is_string( $breakpoint['name'] ) ) {
					continue;
				}

				$bp_name = $breakpoint['name'];
				if ( 'desktop' === $bp_name ) {
					continue;
				}

				$max_width = $this->get_breakpoint_media_max_px( $breakpoint );
				if ( null === $max_width ) {
					continue;
				}

				$css .= sprintf(
					'@media (max-width:%1$dpx){%2$s{%3$s}}',
					$max_width,
					$selector,
					$this->get_responsive_overlay_css_decls( $settings, $bp_name )
				);
			}
		}

		/**
		 * Filters Preloader tablet/phone size CSS.
		 *
		 * @param string               $css      CSS.
		 * @param array<string, mixed> $settings Settings.
		 */
		return (string) apply_filters( 'dsm_preloader_responsive_size_css', $css, $settings );
	}

	/**
	 * Sanitize Divi SelectFont family (empty = inherit).
	 *
	 * @param string $family Family name.
	 * @return string
	 */
	private function sanitize_text_font_family( string $family ): string {
		$family = trim( sanitize_text_field( $family ) );
		if ( '' === $family || 'Default' === $family || 'inherit' === $family ) {
			return '';
		}

		if ( preg_match( '/url\s*\(|expression\s*\(|@import|<|>|\{|\}|;/i', $family ) ) {
			return '';
		}

		if ( ! preg_match( '/^[\w\s\-\'",.]+$/u', $family ) ) {
			return '';
		}

		if ( strlen( $family ) > 120 ) {
			return substr( $family, 0, 120 );
		}

		return $family;
	}

	/**
	 * Sanitize a CSS font-weight token.
	 *
	 * @param string $weight Font weight.
	 * @return string
	 */
	private function sanitize_text_font_weight( string $weight ): string {
		$weight = trim( $weight );
		if ( preg_match( '/^(?:[1-9]00|normal|bold)$/', $weight ) ) {
			return $weight;
		}

		return '400';
	}

	/**
	 * Sanitize a CSS length token (`1.4em`, `0px`, `-0.5em`).
	 *
	 * @param string   $raw            Raw value.
	 * @param string   $fallback       Fallback.
	 * @param string[] $units          Allowed units.
	 * @param bool     $allow_negative Allow a leading minus.
	 * @return string
	 */
	private function sanitize_css_length_token( string $raw, string $fallback, array $units, bool $allow_negative = false ): string {
		$raw = trim( sanitize_text_field( $raw ) );
		if ( '' === $raw ) {
			return $fallback;
		}

		$unit_re = implode(
			'|',
			array_map(
				static function ( string $unit ): string {
					return preg_quote( $unit, '/' );
				},
				$units
			)
		);
		$sign    = $allow_negative ? '-?' : '';

		if ( preg_match( '/^' . $sign . '\d+(\.\d+)?(?:' . $unit_re . ')$/i', $raw ) ) {
			return $raw;
		}

		if ( preg_match( '/^' . $sign . '\d+(\.\d+)?$/', $raw ) ) {
			return $raw . $units[0];
		}

		return $fallback;
	}

	/**
	 * Sanitize Divi FontGroup capitalization (empty = none).
	 *
	 * @param string $value Capitalization slug.
	 * @return string
	 */
	private function sanitize_text_capitalization( string $value ): string {
		$allowed = array( 'uppercase', 'lowercase', 'capitalize', 'smallCaps', 'allSmallCaps' );

		return in_array( $value, $allowed, true ) ? $value : '';
	}

	/**
	 * Sanitize italic / underline / overline / strikethrough flags.
	 *
	 * @param mixed $raw Style flags.
	 * @return string[]
	 */
	private function sanitize_text_style_flags( $raw ): array {
		if ( ! is_array( $raw ) ) {
			return array();
		}

		$allowed = array( 'italic', 'underline', 'overline', 'strikethrough' );
		$out     = array();

		foreach ( $raw as $flag ) {
			if ( ! is_string( $flag ) ) {
				continue;
			}
			$flag = trim( $flag );
			if ( in_array( $flag, $allowed, true ) && ! in_array( $flag, $out, true ) ) {
				$out[] = $flag;
			}
		}

		return $out;
	}

	/**
	 * Non-responsive typography vars (font family + style flags).
	 *
	 * Weight, colour, line height, letter spacing, alignment, and
	 * capitalization live in #dsm-preloader-critical so @media can win.
	 *
	 * @param array<string, mixed> $settings Settings.
	 * @return string
	 */
	private function get_text_typography_static_css_vars( array $settings ): string {
		$family     = $this->sanitize_text_font_family( (string) ( $settings['text_font_family'] ?? '' ) );
		$family_css = '' === $family
			? 'inherit'
			: '"' . $family . '", Helvetica, Arial, Lucida, sans-serif';
		$flags      = $this->sanitize_text_style_flags( $settings['text_style'] ?? array() );
		$font_style = in_array( 'italic', $flags, true ) ? 'italic' : 'normal';

		$decorations = array();
		if ( in_array( 'underline', $flags, true ) ) {
			$decorations[] = 'underline';
		}
		if ( in_array( 'overline', $flags, true ) ) {
			$decorations[] = 'overline';
		}
		if ( in_array( 'strikethrough', $flags, true ) ) {
			$decorations[] = 'line-through';
		}
		$decoration = array() === $decorations ? 'none' : implode( ' ', $decorations );

		return sprintf(
			'--dsm-pl-text-family:%1$s;--dsm-pl-text-font-style:%2$s;--dsm-pl-text-decoration:%3$s;',
			esc_attr( $family_css ),
			esc_attr( $font_style ),
			esc_attr( $decoration )
		);
	}

	/**
	 * Whether a value looks like a desktop/tablet/phone map.
	 *
	 * @param mixed $raw Candidate.
	 * @return bool
	 */
	private function is_breakpoint_map( $raw ): bool {
		if ( ! is_array( $raw ) ) {
			return false;
		}

		foreach ( array( 'desktop', 'tablet', 'tabletWide', 'phone', 'phoneWide' ) as $bp ) {
			if ( array_key_exists( $bp, $raw ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Soft-migrate a flat leaf into `{ desktop, tablet?, phone? }`.
	 *
	 * @param mixed    $raw           Map, string, or leaf.
	 * @param callable $sanitize_leaf fn(mixed $leaf, bool $allow_empty): string.
	 * @param string   $fallback      Desktop fallback.
	 * @return array<string, string>
	 */
	private function sanitize_responsive_scalar_map( $raw, callable $sanitize_leaf, string $fallback ): array {
		if ( ! $this->is_breakpoint_map( $raw ) ) {
			return array(
				'desktop' => $sanitize_leaf( $raw, false ),
			);
		}

		$allowed_bp = array( 'desktop', 'tablet', 'tabletWide', 'phone', 'phoneWide' );
		$out        = array();

		foreach ( $allowed_bp as $bp ) {
			if ( ! array_key_exists( $bp, $raw ) ) {
				continue;
			}

			$allow_empty = 'desktop' !== $bp;
			$leaf        = $sanitize_leaf( $raw[ $bp ], $allow_empty );
			if ( '' !== $leaf || ( 'desktop' === $bp && '' === $fallback ) ) {
				$out[ $bp ] = $leaf;
			}
		}

		if ( ! isset( $out['desktop'] ) ) {
			$out['desktop'] = $fallback;
		}

		return $out;
	}

	/**
	 * Resolve a scalar map leaf at a breakpoint (phone ← tablet ← desktop).
	 *
	 * @param array<string, mixed> $settings   Settings.
	 * @param string               $key        Settings key.
	 * @param string               $breakpoint Breakpoint name.
	 * @param string               $fallback   Desktop fallback.
	 * @return string
	 */
	private function resolve_scalar_css( array $settings, string $key, string $breakpoint, string $fallback ): string {
		$raw = $settings[ $key ] ?? $fallback;
		$map = $this->is_breakpoint_map( $raw )
			? $raw
			: array(
				'desktop' => is_string( $raw ) || is_numeric( $raw ) ? (string) $raw : $fallback,
			);

		$normalized = $breakpoint;
		if ( 'tabletWide' === $breakpoint ) {
			$normalized = 'tablet';
		} elseif ( 'phoneWide' === $breakpoint ) {
			$normalized = 'phone';
		}

		$ladder = array( 'desktop' );
		if ( 'tablet' === $normalized ) {
			$ladder = array( 'tablet', 'tabletWide', 'desktop' );
		} elseif ( 'phone' === $normalized ) {
			$ladder = array( 'phone', 'phoneWide', 'tablet', 'tabletWide', 'desktop' );
		}

		foreach ( $ladder as $bp ) {
			if ( isset( $map[ $bp ] ) && is_string( $map[ $bp ] ) ) {
				return $map[ $bp ];
			}
		}

		return $fallback;
	}

	/**
	 * Soft-migrate typography keys to responsive maps.
	 *
	 * @param array<string, mixed> $settings Settings.
	 * @return array<string, mixed>
	 */
	private function sanitize_responsive_typography_maps( array $settings ): array {
		$settings['text_color']          = $this->sanitize_responsive_scalar_map(
			$settings['text_color'] ?? '#1a1a1a',
			function ( $leaf, bool $allow_empty ) {
				$color = $this->sanitize_color( $this->color_value_to_string( $leaf ), $allow_empty ? '' : '#1a1a1a' );

				return $color;
			},
			'#1a1a1a'
		);
		$settings['text_font_weight']    = $this->sanitize_responsive_scalar_map(
			$settings['text_font_weight'] ?? '400',
			function ( $leaf, bool $allow_empty ) {
				$raw = is_string( $leaf ) || is_numeric( $leaf ) ? (string) $leaf : '';
				if ( '' === trim( $raw ) ) {
					return $allow_empty ? '' : '400';
				}

				return $this->sanitize_text_font_weight( $raw );
			},
			'400'
		);
		$settings['text_line_height']    = $this->sanitize_responsive_scalar_map(
			$settings['text_line_height'] ?? '1.4em',
			function ( $leaf, bool $allow_empty ) {
				$raw = is_string( $leaf ) || is_numeric( $leaf ) ? (string) $leaf : '';
				if ( '' === trim( $raw ) ) {
					return $allow_empty ? '' : '1.4em';
				}

				return $this->sanitize_css_length_token( $raw, '1.4em', array( 'em', 'px', '%' ) );
			},
			'1.4em'
		);
		$settings['text_letter_spacing'] = $this->sanitize_responsive_scalar_map(
			$settings['text_letter_spacing'] ?? '0px',
			function ( $leaf, bool $allow_empty ) {
				$raw = is_string( $leaf ) || is_numeric( $leaf ) ? (string) $leaf : '';
				if ( '' === trim( $raw ) ) {
					return $allow_empty ? '' : '0px';
				}

				return $this->sanitize_css_length_token( $raw, '0px', array( 'px', 'em' ), true );
			},
			'0px'
		);
		$settings['text_align']          = $this->sanitize_responsive_scalar_map(
			$settings['text_align'] ?? 'center',
			function ( $leaf, bool $allow_empty ) {
				$raw = is_string( $leaf ) ? $leaf : '';
				if ( '' === trim( $raw ) ) {
					return $allow_empty ? '' : 'center';
				}

				return $this->sanitize_key_in( $raw, array( 'left', 'center', 'right', 'justify' ), 'center' );
			},
			'center'
		);
		$settings['text_capitalization'] = $this->sanitize_responsive_scalar_map(
			$settings['text_capitalization'] ?? '',
			function ( $leaf, bool $allow_empty ) {
				$raw = is_string( $leaf ) ? $leaf : '';
				$cap = $this->sanitize_text_capitalization( $raw );

				return ( '' === $cap && ! $allow_empty ) ? '' : $cap;
			},
			''
		);

		return $settings;
	}

	/**
	 * Clamp an integer to a range.
	 *
	 * @param string $raw      Raw number.
	 * @param int    $min      Min.
	 * @param int    $max      Max.
	 * @param int    $fallback Default.
	 * @return string
	 */
	private function sanitize_int_range( string $raw, int $min, int $max, int $fallback ): string {
		$value = absint( $raw );
		if ( $value < $min || $value > $max ) {
			$value = $fallback;
		}

		return (string) $value;
	}

	/**
	 * Sanitize a key against an allow list.
	 *
	 * @param string   $value    Raw.
	 * @param string[] $allowed  Allow list.
	 * @param string   $fallback Default.
	 * @return string
	 */
	private function sanitize_key_in( string $value, array $allowed, string $fallback ): string {
		$value      = sanitize_key( $value );
		$value      = str_replace( '_', '-', $value );
		$normalized = str_replace( '-', '_', $value );

		foreach ( $allowed as $item ) {
			if ( $item === $value || $item === $normalized || str_replace( '_', '-', $item ) === $value ) {
				return $item;
			}
		}

		return $fallback;
	}

	/**
	 * Sanitize a comma-separated ID list.
	 *
	 * @param string $raw Comma-separated IDs.
	 * @return string
	 */
	private function sanitize_page_ids( string $raw ): string {
		$parts = array_filter(
			array_map(
				static function ( $id ) {
					$id = absint( trim( (string) $id ) );
					return $id > 0 ? (string) $id : '';
				},
				explode( ',', $raw )
			)
		);

		return implode( ',', array_unique( $parts ) );
	}

	/**
	 * Parse a comma-separated ID list.
	 *
	 * @param string $raw Comma-separated IDs.
	 * @return int[]
	 */
	private function parse_page_ids_string( string $raw ): array {
		if ( '' === trim( $raw ) ) {
			return array();
		}

		return array_values( array_filter( array_map( 'absint', explode( ',', $raw ) ) ) );
	}

	/**
	 * Sanitize a post-type multicheck payload.
	 *
	 * @param mixed $raw Multicheck payload.
	 * @return array<string, string>
	 */
	private function sanitize_post_type_list( $raw ): array {
		if ( ! is_array( $raw ) ) {
			return array();
		}

		$out = array();
		foreach ( $raw as $key => $value ) {
			$slug = sanitize_key( (string) $key );
			if ( '' === $slug ) {
				continue;
			}
			if ( '' !== trim( (string) $value ) ) {
				$out[ $slug ] = $slug;
			}
		}

		return $out;
	}

	/**
	 * Whether this request is an excluded WooCommerce screen.
	 *
	 * @param array<string, mixed> $settings Settings.
	 * @return bool
	 */
	private function is_excluded_woo_request( array $settings ): bool {
		if ( 'on' !== ( $settings['exclude_woo_checkout'] ?? 'on' ) ) {
			return false;
		}

		if ( function_exists( 'is_cart' ) && is_cart() ) {
			return true;
		}
		if ( function_exists( 'is_checkout' ) && is_checkout() ) {
			return true;
		}
		if ( function_exists( 'is_account_page' ) && is_account_page() ) {
			return true;
		}

		return false;
	}

	/**
	 * Optimizer-bypass attributes (Dark Mode pattern, not extracted).
	 *
	 * @return void
	 */
	private function print_critical_inline_tag_attrs(): void {
		$attrs = array(
			'data-no-optimize'         => '1',
			'data-no-minify'           => '1',
			'data-cfasync'             => 'false',
			'data-pagespeed-no-defer'  => true,
			'data-wpmeteor-nooptimize' => 'true',
		);

		foreach ( $attrs as $name => $value ) {
			if ( true === $value ) {
				echo ' ' . esc_attr( $name );
				continue;
			}

			echo ' ' . esc_attr( $name ) . '="' . esc_attr( (string) $value ) . '"';
		}
	}
}
