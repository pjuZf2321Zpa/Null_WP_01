<?php
/**
 * Supreme Loop Filter — query mutation + public REST fragment refresh.
 *
 * Parent module nests looped children; this class mutates Divi Loop query args
 * and re-renders the parent's inner blocks for AJAX swaps. Not Filterable Gallery.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Extensions;

use ET\Builder\Packages\ModuleLibrary\LoopQueryRegistry;
use WP_Error;
use WP_Post;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;
use WP_Term;

if ( defined( 'DSM_DIR_PATH' ) ) {
	$dsm_loop_filter_price_styles = DSM_DIR_PATH . 'divi-5/app/Includes/dsm-loop-filter-price-styles.php';
	if ( is_readable( $dsm_loop_filter_price_styles ) ) {
		require_once $dsm_loop_filter_price_styles;
	}
}

/**
 * Bootstrap for Supreme Loop Filter FE AJAX + Divi loop hooks.
 */
class LoopFilter {

	/**
	 * Filters keyed by Divi loopId (scoped; never apply globally).
	 *
	 * @var array<string, array<string, mixed>>
	 */
	private static array $loop_scoped_filters = array();

	/**
	 * Whether pagination should reset to page 1, keyed by loopId.
	 *
	 * @var array<string, bool>
	 */
	private static array $loop_reset_pagination = array();

	/**
	 * Loop IDs observed during the last filtered render (for found_posts).
	 *
	 * @var list<string>
	 */
	private static array $observed_loop_ids = array();

	/**
	 * REST-only fallback: apply filters to any loop executed while rendering the fragment
	 * when nested loopIds could not be discovered from block attrs.
	 *
	 * @var array<string, mixed>|null
	 */
	private static ?array $fragment_wildcard_filters = null;

	/**
	 * Whether the fragment wildcard should reset pagination.
	 *
	 * @var bool
	 */
	private static bool $fragment_wildcard_reset_pagination = false;

	/**
	 * Constructor — register hooks when the Loop Filter module is enabled.
	 */
	public function __construct() {
		if ( ! function_exists( 'dsm_is_loop_filter_module_enabled' ) || ! dsm_is_loop_filter_module_enabled() ) {
			return;
		}

		add_action( 'wp', array( $this, 'maybe_activate_filters_from_url' ), 20 );
		add_filter( 'divi_loop_data_after_execution', array( $this, 'filter_loop_data_after_execution' ), 20, 3 );
		add_action( 'rest_api_init', array( $this, 'register_rest_routes' ) );
	}

	/**
	 * Whether WooCommerce is available for product filter item types.
	 *
	 * @return bool
	 */
	public static function is_woocommerce_active(): bool {
		return class_exists( 'WooCommerce' );
	}

	/**
	 * Sanitize a non-negative price string for Loop Filter (empty when unset/invalid).
	 *
	 * @param mixed $raw Raw price.
	 * @return string Empty or numeric string.
	 */
	public static function sanitize_price_value( $raw ): string {
		if ( null === $raw || '' === $raw ) {
			return '';
		}
		if ( is_string( $raw ) ) {
			$raw = trim( $raw );
			if ( '' === $raw ) {
				return '';
			}
		}
		if ( ! is_numeric( $raw ) ) {
			return '';
		}
		$value = (float) $raw;
		if ( $value < 0 ) {
			return '';
		}

		// Preserve a compact decimal string for meta_query / URL sync.
		$formatted = rtrim( rtrim( sprintf( '%.6F', $value ), '0' ), '.' );
		return '' === $formatted ? '0' : $formatted;
	}

	/**
	 * Sanitize multi-range price filter (`50-100,200-` or list of min/max pairs).
	 *
	 * Empty min = under max; empty max = over min. Used for checkbox buckets (OR).
	 *
	 * @param mixed $raw Raw ranges.
	 * @return list<array{min: string, max: string}>
	 */
	public static function sanitize_price_ranges( $raw ): array {
		$tokens = array();
		if ( is_string( $raw ) ) {
			foreach ( preg_split( '/[,\s]+/', $raw ) as $part ) {
				$part = trim( (string) $part );
				if ( '' !== $part ) {
					$tokens[] = $part;
				}
			}
		} elseif ( is_array( $raw ) ) {
			foreach ( $raw as $row ) {
				if ( is_string( $row ) ) {
					$part = trim( $row );
					if ( '' !== $part ) {
						$tokens[] = $part;
					}
					continue;
				}
				if ( ! is_array( $row ) ) {
					continue;
				}
				$min = self::sanitize_price_value( $row['min'] ?? '' );
				$max = self::sanitize_price_value( $row['max'] ?? '' );
				if ( '' !== $min || '' !== $max ) {
					$tokens[] = $min . '-' . $max;
				}
			}
		}

		$out = array();
		foreach ( $tokens as $token ) {
			if ( false === strpos( $token, '-' ) ) {
				$min = self::sanitize_price_value( $token );
				if ( '' !== $min ) {
					$out[] = array(
						'min' => $min,
						'max' => '',
					);
				}
				continue;
			}
			$dash = strpos( $token, '-' );
			$min  = self::sanitize_price_value( substr( $token, 0, $dash ) );
			$max  = self::sanitize_price_value( substr( $token, $dash + 1 ) );
			if ( '' === $min && '' === $max ) {
				continue;
			}
			$out[] = array(
				'min' => $min,
				'max' => $max,
			);
		}

		/**
		 * Filter sanitized Price filter OR-ranges.
		 *
		 * @param array<int, array{min: string, max: string}> $out Sanitized ranges.
		 * @param mixed                                 $raw Raw input.
		 */
		$filtered = apply_filters( 'dsm_loop_filter_sanitize_price_ranges', $out, $raw );

		return is_array( $filtered ) ? $filtered : $out;
	}

	/**
	 * Build a `_price` DECIMAL meta_query clause for one min/max pair.
	 *
	 * @param string $min          Sanitized min (empty = open).
	 * @param string $max          Sanitized max (empty = open).
	 * @param string $decimal_type WP meta type, e.g. DECIMAL(10,2).
	 * @return array<string, mixed>|null
	 */
	public static function price_range_meta_clause( string $min, string $max, string $decimal_type ): ?array {
		$min = self::sanitize_price_value( $min );
		$max = self::sanitize_price_value( $max );
		if ( '' !== $min && '' !== $max ) {
			if ( (float) $min > (float) $max ) {
				$tmp = $min;
				$min = $max;
				$max = $tmp;
			}
			return array(
				'key'     => '_price',
				'value'   => array( $min, $max ),
				'compare' => 'BETWEEN',
				'type'    => $decimal_type,
			);
		}
		if ( '' !== $min ) {
			return array(
				'key'     => '_price',
				'value'   => $min,
				'compare' => '>=',
				'type'    => $decimal_type,
			);
		}
		if ( '' !== $max ) {
			return array(
				'key'     => '_price',
				'value'   => $max,
				'compare' => '<=',
				'type'    => $decimal_type,
			);
		}

		return null;
	}

	/**
	 * Sanitize product rating selection (1–5); 0 / empty means unset.
	 *
	 * Matches Divi Post Filter product-review values (exact rated-N).
	 *
	 * @param mixed $raw Raw rating.
	 * @return int 0–5.
	 */
	public static function sanitize_rating_min( $raw ): int {
		$rating = absint( $raw );
		return ( $rating >= 1 && $rating <= 5 ) ? $rating : 0;
	}

	/**
	 * Sanitize WooCommerce stock status slug.
	 *
	 * Allowed: instock|outofstock|onbackorder (ProductStockStatus).
	 *
	 * @param mixed $raw Raw status.
	 * @return string Empty when invalid.
	 */
	public static function sanitize_stock_status( $raw ): string {
		$status  = sanitize_key( (string) $raw );
		$allowed = array( 'instock', 'outofstock', 'onbackorder' );

		/**
		 * Filter allowed WooCommerce stock status values for Supreme Loop Filter.
		 *
		 * @param array<int, string> $allowed Allowed statuses.
		 * @param string       $status  Requested status.
		 */
		$allowed = apply_filters( 'dsm_loop_filter_allowed_stock_status', $allowed, $status );
		if ( ! is_array( $allowed ) ) {
			$allowed = array( 'instock', 'outofstock', 'onbackorder' );
		}

		return in_array( $status, $allowed, true ) ? $status : '';
	}

	/**
	 * Whether nested loop post types include WooCommerce products.
	 *
	 * @param array<int, string> $loop_post_types Post types from nested Loop(s).
	 * @return bool
	 */
	public static function loop_includes_product( array $loop_post_types ): bool {
		return in_array( 'product', $loop_post_types, true );
	}

	/**
	 * Whether WooCommerce filter values are present on a filters array.
	 *
	 * @param array<string, mixed> $filters Filters.
	 * @return bool
	 */
	public static function filters_have_woocommerce( array $filters ): bool {
		if ( ! self::is_woocommerce_active() ) {
			return false;
		}
		$min    = self::sanitize_price_value( $filters['min_price'] ?? '' );
		$max    = self::sanitize_price_value( $filters['max_price'] ?? '' );
		$ranges = self::sanitize_price_ranges( $filters['price_ranges'] ?? array() );
		$rating = self::sanitize_rating_min( $filters['rating'] ?? 0 );
		$stock  = self::sanitize_stock_status( $filters['stock_status'] ?? '' );

		return '' !== $min || '' !== $max || ! empty( $ranges ) || $rating > 0 || '' !== $stock;
	}

	/**
	 * Merge WooCommerce filter clauses into Divi Loop query args.
	 *
	 * Price: `_price` DECIMAL compare.
	 * Rating: WooCommerce `product_visibility` `rated-N` exact match (Divi product-review).
	 * Falls back to `_wc_average_rating` >= N when visibility terms are unavailable.
	 * Stock: `_stock_status` = instock|outofstock|onbackorder.
	 *
	 * @param array<string, mixed> $query_args      Query args (by ref).
	 * @param array<string, mixed> $filters         Active filters.
	 * @param array<int, string>   $loop_post_types Nested loop post types.
	 * @return void
	 */
	public static function apply_woocommerce_to_query_args( array &$query_args, array $filters, array $loop_post_types ): void {
		if ( ! self::is_woocommerce_active() ) {
			return;
		}
		if ( ! empty( $loop_post_types ) && ! self::loop_includes_product( $loop_post_types ) ) {
			return;
		}

		$min_price    = self::sanitize_price_value( $filters['min_price'] ?? '' );
		$max_price    = self::sanitize_price_value( $filters['max_price'] ?? '' );
		$price_ranges = self::sanitize_price_ranges( $filters['price_ranges'] ?? array() );
		$rating       = self::sanitize_rating_min( $filters['rating'] ?? 0 );
		$stock        = self::sanitize_stock_status( $filters['stock_status'] ?? '' );

		$clauses      = array();
		$decimals     = function_exists( 'wc_get_price_decimals' ) ? (int) wc_get_price_decimals() : 2;
		$decimal_type = 'DECIMAL(10,' . max( 0, $decimals ) . ')';

		if ( ! empty( $price_ranges ) ) {
			$or_group = array( 'relation' => 'OR' );
			foreach ( $price_ranges as $range ) {
				$clause = self::price_range_meta_clause( $range['min'], $range['max'], $decimal_type );
				if ( is_array( $clause ) ) {
					$or_group[] = $clause;
				}
			}
			if ( count( $or_group ) > 1 ) {
				$clauses[] = $or_group;
			}
		} else {
			$single = self::price_range_meta_clause( $min_price, $max_price, $decimal_type );
			if ( is_array( $single ) ) {
				$clauses[] = $single;
			}
		}

		$rating_applied_via_tax = false;
		if ( $rating > 0 && function_exists( 'wc_get_product_visibility_term_ids' ) ) {
			$visibility_terms = wc_get_product_visibility_term_ids();
			$term_id          = $visibility_terms[ 'rated-' . $rating ] ?? null;
			if ( ! empty( $term_id ) ) {
				$tax_query               = isset( $query_args['tax_query'] ) && is_array( $query_args['tax_query'] )
					? $query_args['tax_query']
					: array();
				$tax_query[]             = array(
					'taxonomy'      => 'product_visibility',
					'field'         => 'term_taxonomy_id',
					'terms'         => array( (int) $term_id ),
					'operator'      => 'IN',
					'rating_filter' => true,
				);
				$query_args['tax_query'] = $tax_query;
				$rating_applied_via_tax  = true;
			}
		}

		if ( $rating > 0 && ! $rating_applied_via_tax ) {
			$clauses[] = array(
				'key'     => '_wc_average_rating',
				'value'   => (string) $rating,
				'compare' => '>=',
				'type'    => 'DECIMAL(3,2)',
			);
		}

		if ( '' !== $stock ) {
			$clauses[] = array(
				'key'     => '_stock_status',
				'value'   => $stock,
				'compare' => '=',
			);
		}

		if ( empty( $clauses ) ) {
			return;
		}

		$meta_query = isset( $query_args['meta_query'] ) && is_array( $query_args['meta_query'] )
			? $query_args['meta_query']
			: array();

		foreach ( $clauses as $clause ) {
			$meta_query[] = $clause;
		}

		if ( count( $meta_query ) > 1 && ! isset( $meta_query['relation'] ) ) {
			$meta_query['relation'] = 'AND';
		}

		$query_args['meta_query'] = $meta_query;
	}

	/**
	 * Resolve the stored custom-field meta key from a Loop Filter Item.
	 *
	 * Field Option `manual` uses `custom_field_key`; otherwise Field Option is the key.
	 *
	 * @param array<string, mixed> $item_attrs Item attrs.
	 * @return string Sanitized key, or empty when unset/denied.
	 */
	public static function resolve_custom_field_key_from_item_attrs( array $item_attrs ): string {
		$option = self::inner_desktop_string( $item_attrs, 'field_option', 'manual' );
		$raw    = ( 'manual' === $option || '' === $option )
			? self::inner_desktop_string( $item_attrs, 'custom_field_key', '' )
			: $option;

		if ( ! function_exists( 'dsm_loop_filter_sanitize_meta_key' ) ) {
			return '';
		}

		$key = dsm_loop_filter_sanitize_meta_key( $raw );
		if ( '' === $key || ! dsm_loop_filter_is_allowed_meta_key( $key ) ) {
			return '';
		}

		return $key;
	}

	/**
	 * Meta keys configured on Custom Field items for this Loop Filter.
	 *
	 * @param array<int, array<string, mixed>> $inner_blocks Parent inner blocks.
	 * @return list<string>
	 */
	public static function collect_allowed_custom_field_keys( array $inner_blocks ): array {
		$keys = array();

		foreach ( $inner_blocks as $block ) {
			if ( ! is_array( $block ) ) {
				continue;
			}
			if ( ( $block['blockName'] ?? '' ) === 'dsm/loop-filter-item' ) {
				$attrs = isset( $block['attrs'] ) && is_array( $block['attrs'] ) ? $block['attrs'] : array();
				if ( 'custom_field' === self::inner_desktop_string( $attrs, 'item_type', 'taxonomy' ) ) {
					$key = self::resolve_custom_field_key_from_item_attrs( $attrs );
					if ( '' !== $key ) {
						$keys[] = $key;
					}
				}
			}
			if ( ! empty( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ) {
				$keys = array_merge( $keys, self::collect_allowed_custom_field_keys( $block['innerBlocks'] ) );
			}
		}

		return array_values( array_unique( $keys ) );
	}

	/**
	 * Normalize visitor values from a custom-field clause.
	 *
	 * Accepts `value` (string) and/or `values` (array). Empty entries are dropped.
	 *
	 * @param array<string, mixed> $row Raw row.
	 * @return list<string>
	 */
	public static function normalize_meta_query_values( array $row ): array {
		$values = array();

		if ( isset( $row['values'] ) && is_array( $row['values'] ) ) {
			foreach ( $row['values'] as $raw ) {
				if ( ! is_scalar( $raw ) ) {
					continue;
				}
				$value = sanitize_text_field( (string) $raw );
				if ( '' !== $value ) {
					$values[] = $value;
				}
			}
		} elseif ( isset( $row['value'] ) && is_scalar( $row['value'] ) ) {
			$value = sanitize_text_field( (string) $row['value'] );
			if ( '' !== $value ) {
				$values[] = $value;
			}
		}

		return array_values( array_unique( $values ) );
	}

	/**
	 * Sanitize visitor custom-field clauses against an allowlist.
	 *
	 * @param mixed              $raw          Raw `{ key, value?, values? }[]`.
	 * @param array<int, string> $allowed_keys Keys present on this instance.
	 * @return list<array{key: string, value: string, values: list<string>}>
	 */
	public static function sanitize_meta_queries( $raw, array $allowed_keys ): array {
		if ( ! is_array( $raw ) || empty( $allowed_keys ) ) {
			return array();
		}

		$allowed = array();
		foreach ( $allowed_keys as $allowed_key ) {
			if ( is_string( $allowed_key ) && '' !== $allowed_key ) {
				$allowed[ $allowed_key ] = true;
			}
		}
		if ( empty( $allowed ) ) {
			return array();
		}

		$out = array();
		foreach ( $raw as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$key_raw = isset( $row['key'] ) && is_scalar( $row['key'] )
				? (string) $row['key']
				: '';

			$key = function_exists( 'dsm_loop_filter_sanitize_meta_key' )
				? dsm_loop_filter_sanitize_meta_key( $key_raw )
				: '';
			if ( '' === $key || ! isset( $allowed[ $key ] ) ) {
				continue;
			}
			if ( function_exists( 'dsm_loop_filter_is_allowed_meta_key' ) && ! dsm_loop_filter_is_allowed_meta_key( $key ) ) {
				continue;
			}

			$values = self::normalize_meta_query_values( $row );
			if ( empty( $values ) ) {
				continue;
			}

			$out[] = array(
				'key'    => $key,
				'value'  => $values[0],
				'values' => $values,
			);
		}

		/**
		 * Filter sanitized custom-field clauses for Supreme Loop Filter.
		 *
		 * @param array<int, array{key: string, value: string, values: list<string>}> $out          Clauses.
		 * @param array<int, string>                                                 $allowed_keys Allowed keys.
		 */
		$filtered = apply_filters( 'dsm_loop_filter_custom_field_queries', $out, $allowed_keys );

		return is_array( $filtered ) ? $filtered : $out;
	}

	/**
	 * Whether custom-field filter values are present.
	 *
	 * @param array<string, mixed> $filters Filters.
	 * @return bool
	 */
	public static function filters_have_custom_field( array $filters ): bool {
		$queries = isset( $filters['meta_queries'] ) && is_array( $filters['meta_queries'] )
			? $filters['meta_queries']
			: array();

		foreach ( $queries as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$key    = isset( $row['key'] ) && is_scalar( $row['key'] ) ? (string) $row['key'] : '';
			$values = self::normalize_meta_query_values( $row );
			if ( '' !== $key && ! empty( $values ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Merge visitor custom-field clauses into WP_Query `meta_query` (CHAR `=` / `IN`).
	 *
	 * @param array<string, mixed> $query_args Query args (by ref).
	 * @param array<string, mixed> $filters    Active filters.
	 * @return void
	 */
	public static function apply_custom_field_to_query_args( array &$query_args, array $filters ): void {
		$queries = isset( $filters['meta_queries'] ) && is_array( $filters['meta_queries'] )
			? $filters['meta_queries']
			: array();
		if ( empty( $queries ) ) {
			return;
		}

		$clauses = array();
		foreach ( $queries as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$key    = isset( $row['key'] ) && is_scalar( $row['key'] ) ? (string) $row['key'] : '';
			$values = self::normalize_meta_query_values( $row );
			if ( '' === $key || empty( $values ) ) {
				continue;
			}
			if ( 1 === count( $values ) ) {
				$clauses[] = array(
					'key'     => $key,
					'value'   => $values[0],
					'compare' => '=',
					'type'    => 'CHAR',
				);
			} else {
				$clauses[] = array(
					'key'     => $key,
					'value'   => $values,
					'compare' => 'IN',
					'type'    => 'CHAR',
				);
			}
		}

		if ( empty( $clauses ) ) {
			return;
		}

		$meta_query = isset( $query_args['meta_query'] ) && is_array( $query_args['meta_query'] )
			? $query_args['meta_query']
			: array();

		foreach ( $clauses as $clause ) {
			$meta_query[] = $clause;
		}

		if ( count( $meta_query ) > 1 && ! isset( $meta_query['relation'] ) ) {
			$meta_query['relation'] = 'AND';
		}

		$query_args['meta_query'] = $meta_query;
	}

	/**
	 * Parse `_mq` URL param: `key~value|key2~v1+v2` (values URL-encoded).
	 *
	 * @param string $raw Raw param.
	 * @return list<array{key: string, value: string, values: list<string>}>
	 */
	public static function parse_meta_queries_url_param( string $raw ): array {
		$raw = trim( $raw );
		if ( '' === $raw ) {
			return array();
		}

		$out = array();
		foreach ( explode( '|', $raw ) as $chunk ) {
			$chunk = trim( $chunk );
			if ( '' === $chunk || false === strpos( $chunk, '~' ) ) {
				continue;
			}
			list( $key_part, $value_part ) = array_pad( explode( '~', $chunk, 2 ), 2, '' );
			$key                           = rawurldecode( (string) $key_part );
			if ( function_exists( 'dsm_loop_filter_sanitize_meta_key' ) ) {
				$key = dsm_loop_filter_sanitize_meta_key( $key );
			} else {
				$key = '';
			}
			if ( '' === $key ) {
				continue;
			}
			if ( function_exists( 'dsm_loop_filter_is_allowed_meta_key' ) && ! dsm_loop_filter_is_allowed_meta_key( $key ) ) {
				continue;
			}

			$values = array();
			foreach ( explode( '+', (string) $value_part ) as $piece ) {
				$value = sanitize_text_field( rawurldecode( $piece ) );
				if ( '' !== $value ) {
					$values[] = $value;
				}
			}
			$values = array_values( array_unique( $values ) );
			if ( empty( $values ) ) {
				continue;
			}

			$out[] = array(
				'key'    => $key,
				'value'  => $values[0],
				'values' => $values,
			);
		}

		return $out;
	}

	/**
	 * Activate URL-synced filters scoped to each Loop Filter instance's nested loops.
	 *
	 * Query shape (per instance): `dsm_lf_{layoutId}_{index}_s`, `_tax`, `_terms`,
	 * `_author`, `_date_from`, `_date_to`, `_min_price`, `_max_price`, `_rating`, `_stock`, `_mq`.
	 * Legacy (single instance): `dsm_lf` (index), `dsm_lf_s`, `dsm_lf_tax`, `dsm_lf_terms`.
	 *
	 * @return void
	 */
	public function maybe_activate_filters_from_url(): void {
		if ( is_admin() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
			return;
		}

		$instances = self::parse_filter_instances_from_request();
		if ( empty( $instances ) ) {
			return;
		}

		foreach ( $instances as $instance ) {
			$layout_id = (int) $instance['layout_id'];
			$index     = (int) $instance['index'];
			$filters   = $instance['filters'];

			$has_search = '' !== (string) ( $filters['search'] ?? '' );
			$has_tax    = ! empty( $filters['tax_queries'] )
				|| ( '' !== (string) ( $filters['taxonomy'] ?? '' ) && ! empty( $filters['terms'] ) );
			$has_author = self::sanitize_author_id( $filters['author'] ?? 0 ) > 0;
			$has_date   = self::filters_have_date( $filters );
			$has_order  = '' !== (string) ( $filters['orderby'] ?? '' );
			$has_woo    = self::filters_have_woocommerce( $filters );
			$has_custom = self::filters_have_custom_field( $filters );
			if ( ! $has_search && ! $has_tax && ! $has_author && ! $has_date && ! $has_order && ! $has_woo && ! $has_custom ) {
				continue;
			}

			$source = self::resolve_module_source_post( $layout_id );
			if ( ! $source instanceof WP_Post ) {
				continue;
			}

			$parent_block = self::find_nth_loop_filter_block( (string) $source->post_content, $index );
			if ( null === $parent_block ) {
				continue;
			}

			$inner_blocks = isset( $parent_block['innerBlocks'] ) && is_array( $parent_block['innerBlocks'] )
				? $parent_block['innerBlocks']
				: array();
			$loop_ids     = self::collect_nested_loop_ids( $inner_blocks );
			if ( empty( $loop_ids ) ) {
				continue;
			}

			$loop_post_types = self::collect_nested_loop_post_types( $inner_blocks );
			if ( isset( $filters['taxonomy'] ) ) {
				$filters['taxonomy'] = self::sanitize_public_taxonomy(
					(string) $filters['taxonomy'],
					$loop_post_types
				);
			}
			$filters['tax_queries']        = self::normalize_tax_queries(
				$filters['tax_queries'] ?? array(),
				$loop_post_types
			);
			$parent_attrs                  = isset( $parent_block['attrs'] ) && is_array( $parent_block['attrs'] )
				? $parent_block['attrs']
				: array();
			$filters['tax_query_relation'] = self::sanitize_tax_relation(
				isset( $filters['tax_query_relation'] )
					? (string) $filters['tax_query_relation']
					: self::inner_desktop_string( $parent_attrs, 'tax_query_relation', 'AND' ),
				'AND'
			);
			$filters['tax_queries']        = self::enrich_tax_queries_with_item_relations(
				$filters['tax_queries'],
				$inner_blocks,
				$loop_post_types
			);
			if ( isset( $filters['orderby'] ) ) {
				$filters['orderby'] = self::sanitize_orderby( (string) $filters['orderby'] );
				$filters['order']   = self::sanitize_order(
					isset( $filters['order'] ) ? (string) $filters['order'] : 'DESC'
				);
			}
			$filters['author']       = self::sanitize_author_id( $filters['author'] ?? 0 );
			$filters['date_from']    = self::sanitize_date_ymd( $filters['date_from'] ?? '' );
			$filters['date_to']      = self::sanitize_date_ymd( $filters['date_to'] ?? '' );
			$filters['min_price']    = self::sanitize_price_value( $filters['min_price'] ?? '' );
			$filters['max_price']    = self::sanitize_price_value( $filters['max_price'] ?? '' );
			$filters['price_ranges'] = self::sanitize_price_ranges( $filters['price_ranges'] ?? array() );
			$filters['rating']       = self::sanitize_rating_min( $filters['rating'] ?? 0 );
			$filters['stock_status'] = self::sanitize_stock_status( $filters['stock_status'] ?? '' );
			$filters['meta_queries'] = self::sanitize_meta_queries(
				$filters['meta_queries'] ?? array(),
				self::collect_allowed_custom_field_keys( $inner_blocks )
			);

			// Keep filtered pagination when Divi loop page params are present.
			$reset_pagination = ! self::request_has_loop_page_param( $loop_ids );

			self::bind_filters_to_loop_ids( $filters, $loop_ids, $reset_pagination );
		}
	}

	/**
	 * Sanitize author user ID for Loop Filter (WP_Query `author`).
	 *
	 * @param mixed $author Raw author id.
	 * @return int Positive user ID, or 0 when unset/invalid.
	 */
	public static function sanitize_author_id( $author ): int {
		$id = absint( $author );
		if ( $id < 1 ) {
			return 0;
		}

		/**
		 * Filter whether an author ID is allowed for Supreme Loop Filter.
		 *
		 * @param bool $allowed Whether the author ID is allowed.
		 * @param int  $id      Author user ID.
		 */
		$allowed = (bool) apply_filters( 'dsm_loop_filter_allow_author', true, $id );
		if ( ! $allowed ) {
			return 0;
		}

		$user = get_userdata( $id );
		return $user instanceof \WP_User ? $id : 0;
	}

	/**
	 * Sanitize a calendar date as `Y-m-d` for Loop Filter (empty when invalid).
	 *
	 * @param mixed $raw Raw date string.
	 * @return string Valid `Y-m-d` or empty string.
	 */
	public static function sanitize_date_ymd( $raw ): string {
		if ( null === $raw || '' === $raw ) {
			return '';
		}
		if ( ! is_string( $raw ) && ! is_numeric( $raw ) ) {
			return '';
		}

		$raw = trim( (string) $raw );
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $raw ) ) {
			return '';
		}

		$dt = \DateTime::createFromFormat( 'Y-m-d', $raw );
		if ( ! $dt instanceof \DateTime ) {
			return '';
		}

		// Reject invalid calendar dates (e.g. 2024-02-31).
		if ( $dt->format( 'Y-m-d' ) !== $raw ) {
			return '';
		}

		/**
		 * Filter a sanitized Loop Filter date (`Y-m-d`) before it is applied.
		 *
		 * Return empty string to reject the value.
		 *
		 * @param string $raw Sanitized `Y-m-d` candidate.
		 */
		$filtered = apply_filters( 'dsm_loop_filter_sanitize_date_ymd', $raw );
		if ( ! is_string( $filtered ) ) {
			return '';
		}
		$filtered = trim( $filtered );
		if ( '' === $filtered || ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $filtered ) ) {
			return '';
		}

		$check = \DateTime::createFromFormat( 'Y-m-d', $filtered );
		if ( ! $check instanceof \DateTime || $check->format( 'Y-m-d' ) !== $filtered ) {
			return '';
		}

		return $filtered;
	}

	/**
	 * Whether filters include a usable published-date range bound.
	 *
	 * @param array<string, mixed> $filters Active filters.
	 * @return bool
	 */
	public static function filters_have_date( array $filters ): bool {
		$from = self::sanitize_date_ymd( $filters['date_from'] ?? '' );
		$to   = self::sanitize_date_ymd( $filters['date_to'] ?? '' );
		return '' !== $from || '' !== $to;
	}

	/**
	 * Merge inclusive published-date range into WP_Query `date_query`.
	 *
	 * Either bound is optional. When both are set and from > to, bounds are swapped.
	 * Column defaults to `post_date` (published).
	 *
	 * Example clause shape:
	 * ```
	 * array(
	 * 'column'    => 'post_date',
	 * 'inclusive' => true,
	 * 'after'     => '2024-01-01 00:00:00',
	 * 'before'    => '2024-12-31 23:59:59',
	 * )
	 * ```
	 *
	 * @param array<string, mixed> $query_args Query args (by ref).
	 * @param array<string, mixed> $filters    Active filters.
	 * @return void
	 */
	public static function apply_date_range_to_query_args( array &$query_args, array $filters ): void {
		$from = self::sanitize_date_ymd( $filters['date_from'] ?? '' );
		$to   = self::sanitize_date_ymd( $filters['date_to'] ?? '' );
		if ( '' === $from && '' === $to ) {
			return;
		}

		if ( '' !== $from && '' !== $to && strcmp( $from, $to ) > 0 ) {
			$tmp  = $from;
			$from = $to;
			$to   = $tmp;
		}

		$clause = array(
			'column'    => 'post_date',
			'inclusive' => true,
		);
		if ( '' !== $from ) {
			$clause['after'] = $from . ' 00:00:00';
		}
		if ( '' !== $to ) {
			$clause['before'] = $to . ' 23:59:59';
		}

		/**
		 * Filter the date_query clause built for Supreme Loop Filter.
		 *
		 * @param array<string, mixed> $clause  WP_Date_Query clause.
		 * @param string               $from    Inclusive start `Y-m-d` or ''.
		 * @param string               $to      Inclusive end `Y-m-d` or ''.
		 * @param array<string, mixed> $filters Active filters.
		 */
		$clause = apply_filters( 'dsm_loop_filter_date_query_clause', $clause, $from, $to, $filters );
		if ( ! is_array( $clause ) || empty( $clause ) ) {
			return;
		}

		$date_query               = isset( $query_args['date_query'] ) && is_array( $query_args['date_query'] )
			? $query_args['date_query']
			: array();
		$date_query[]             = $clause;
		$query_args['date_query'] = $date_query;
	}

	/**
	 * Sanitize WP_Query orderby for Loop Filter.
	 *
	 * Allowed: date|title|menu_order|comment_count|rand.
	 *
	 * @param string $orderby Raw orderby.
	 * @return string Empty when invalid.
	 */
	public static function sanitize_orderby( string $orderby ): string {
		$orderby = sanitize_key( $orderby );
		$allowed = array( 'date', 'title', 'menu_order', 'comment_count', 'rand' );

		/**
		 * Filter allowed orderby values for Supreme Loop Filter.
		 *
		 * @param array<int, string> $allowed Allowed orderby keys.
		 * @param string       $orderby Requested orderby.
		 */
		$allowed = apply_filters( 'dsm_loop_filter_allowed_orderby', $allowed, $orderby );
		if ( ! is_array( $allowed ) ) {
			$allowed = array( 'date', 'title', 'menu_order', 'comment_count', 'rand' );
		}

		return in_array( $orderby, $allowed, true ) ? $orderby : '';
	}

	/**
	 * Sanitize ASC/DESC order.
	 *
	 * @param string $order Raw order.
	 * @return string ASC|DESC (defaults DESC when empty/invalid).
	 */
	public static function sanitize_order( string $order ): string {
		$order = strtoupper( sanitize_text_field( $order ) );
		return 'ASC' === $order ? 'ASC' : 'DESC';
	}

	/**
	 * Sanitize tax_query relation / within-group term relation to AND|OR.
	 *
	 * @param string $relation Raw relation.
	 * @param string $default  Fallback when empty/invalid (AND|OR).
	 * @return string AND|OR
	 */
	public static function sanitize_tax_relation( string $relation, string $default = 'AND' ): string {
		$default  = 'OR' === strtoupper( $default ) ? 'OR' : 'AND';
		$relation = strtoupper( sanitize_text_field( $relation ) );
		if ( 'AND' === $relation || 'OR' === $relation ) {
			return $relation;
		}

		return $default;
	}

	/**
	 * Map within-taxonomy term relation to WP_Tax_Query operator.
	 *
	 * OR (any term) → IN; AND (all terms) → AND.
	 *
	 * @param string $relation AND|OR.
	 * @return string IN|AND
	 */
	public static function tax_relation_to_operator( string $relation ): string {
		return 'AND' === self::sanitize_tax_relation( $relation, 'OR' ) ? 'AND' : 'IN';
	}

	/**
	 * Read a desktop innerContent scalar from module attrs.
	 *
	 * @param array<string, mixed> $attrs   Attributes.
	 * @param string               $key     Attribute key.
	 * @param string               $default Default.
	 * @return string
	 */
	public static function inner_desktop_string( array $attrs, string $key, string $default = '' ): string {
		$value = $attrs[ $key ]['innerContent']['desktop']['value'] ?? $default;
		if ( is_array( $value ) ) {
			if ( isset( $value['text'] ) && is_scalar( $value['text'] ) ) {
				return (string) $value['text'];
			}
			if ( isset( $value['value'] ) && is_scalar( $value['value'] ) ) {
				return (string) $value['value'];
			}

			return $default;
		}

		return is_scalar( $value ) ? (string) $value : $default;
	}

	/**
	 * Attach per-taxonomy item `tax_relation` from Loop Filter Item blocks.
	 *
	 * Used for URL SSR where the `_tq` param does not carry relation.
	 *
	 * @param array<int, array{taxonomy: string, terms: list<string>, relation?: string}> $tax_queries Normalized groups.
	 * @param array<int, array<string, mixed>>                                            $inner_blocks Parent inner blocks.
	 * @param array<int, string>                                                          $loop_post_types Loop post types.
	 * @return list<array{taxonomy: string, terms: list<string>, relation: string}>
	 */
	public static function enrich_tax_queries_with_item_relations( array $tax_queries, array $inner_blocks, array $loop_post_types = array() ): array {
		/**
		 * Per-taxonomy relation from Filter Item attrs.
		 *
		 * @var array<string, string>
		 */
		$relation_by_tax = array();

		foreach ( $inner_blocks as $block ) {
			if ( ! is_array( $block ) || ( $block['blockName'] ?? '' ) !== 'dsm/loop-filter-item' ) {
				continue;
			}
			$attrs = isset( $block['attrs'] ) && is_array( $block['attrs'] ) ? $block['attrs'] : array();
			if ( 'taxonomy' !== self::inner_desktop_string( $attrs, 'item_type', 'taxonomy' ) ) {
				continue;
			}
			$taxonomy = self::resolve_effective_public_taxonomy(
				self::inner_desktop_string( $attrs, 'taxonomy', 'category' ),
				$loop_post_types
			);
			if ( '' === $taxonomy || isset( $relation_by_tax[ $taxonomy ] ) ) {
				continue;
			}
			$relation_by_tax[ $taxonomy ] = self::sanitize_tax_relation(
				self::inner_desktop_string( $attrs, 'tax_relation', 'OR' ),
				'OR'
			);
		}

		$out = array();
		foreach ( $tax_queries as $group ) {
			if ( ! is_array( $group ) ) {
				continue;
			}
			$taxonomy = isset( $group['taxonomy'] ) ? (string) $group['taxonomy'] : '';
			// Prefer Filter Item attrs (config) over payload defaults.
			$relation = $relation_by_tax[ $taxonomy ]
				?? self::sanitize_tax_relation(
					isset( $group['relation'] ) ? (string) $group['relation'] : 'OR',
					'OR'
				);
			$out[]    = array(
				'taxonomy' => $taxonomy,
				'terms'    => isset( $group['terms'] ) && is_array( $group['terms'] ) ? $group['terms'] : array(),
				'relation' => $relation,
			);
		}

		return $out;
	}

	/**
	 * Normalize tax query groups from REST / URL payloads.
	 *
	 * @param mixed              $raw            Raw tax_queries.
	 * @param array<int, string> $loop_post_types Loop post types for taxonomy validation.
	 * @return list<array{taxonomy: string, terms: list<string>, relation: string}>
	 */
	public static function normalize_tax_queries( $raw, array $loop_post_types = array() ): array {
		$out = array();
		if ( ! is_array( $raw ) ) {
			return $out;
		}

		foreach ( $raw as $group ) {
			if ( ! is_array( $group ) ) {
				continue;
			}
			$taxonomy = self::sanitize_public_taxonomy(
				isset( $group['taxonomy'] ) ? (string) $group['taxonomy'] : '',
				$loop_post_types
			);
			if ( '' === $taxonomy ) {
				continue;
			}
			$terms_raw = isset( $group['terms'] ) && is_array( $group['terms'] ) ? $group['terms'] : array();
			$terms     = array();
			foreach ( $terms_raw as $term_slug ) {
				if ( ! is_string( $term_slug ) && ! is_numeric( $term_slug ) ) {
					continue;
				}
				$slug = sanitize_title( (string) $term_slug );
				if ( '' !== $slug ) {
					$terms[] = $slug;
				}
			}
			$terms = array_values( array_unique( $terms ) );
			if ( empty( $terms ) ) {
				continue;
			}
			$relation = self::sanitize_tax_relation(
				isset( $group['relation'] ) ? (string) $group['relation'] : 'OR',
				'OR'
			);
			$out[]    = array(
				'taxonomy' => $taxonomy,
				'terms'    => $terms,
				'relation' => $relation,
			);
		}

		return $out;
	}

	/**
	 * Sanitize a taxonomy slug to a Loop Filter–eligible registered taxonomy (or empty).
	 *
	 * Eligible = public, or (when WooCommerce is active) a product/attribute taxonomy
	 * with `show_ui` even if archives are disabled (`public = false`). See
	 * {@see dsm_is_taxonomy_eligible_for_loop_filter()}.
	 *
	 * When `$post_types` is non-empty (and does not include `any`), the taxonomy
	 * must also apply to at least one of those post types.
	 *
	 * @param string             $taxonomy   Raw taxonomy slug.
	 * @param array<int, string> $post_types Optional loop post types to validate against.
	 * @return string
	 */
	public static function sanitize_public_taxonomy( string $taxonomy, array $post_types = array() ): string {
		$taxonomy = sanitize_key( $taxonomy );
		if ( '' === $taxonomy || ! taxonomy_exists( $taxonomy ) ) {
			return '';
		}

		$object = get_taxonomy( $taxonomy );
		if ( ! $object instanceof \WP_Taxonomy ) {
			return '';
		}

		$eligible = function_exists( 'dsm_is_taxonomy_eligible_for_loop_filter' )
			? dsm_is_taxonomy_eligible_for_loop_filter( $object )
			: (bool) $object->public;
		if ( ! $eligible ) {
			return '';
		}

		$clean_post_types = array_values(
			array_unique(
				array_filter(
					array_map(
						static function ( $post_type ) {
							return is_string( $post_type ) ? sanitize_key( $post_type ) : '';
						},
						$post_types
					)
				)
			)
		);

		if ( ! empty( $clean_post_types ) && ! in_array( 'any', $clean_post_types, true ) ) {
			$object_types = isset( $object->object_type ) && is_array( $object->object_type )
				? array_map( 'sanitize_key', $object->object_type )
				: array();
			if ( empty( array_intersect( $object_types, $clean_post_types ) ) ) {
				return '';
			}
		}

		/**
		 * Filter whether a taxonomy may be used by Supreme Loop Filter.
		 *
		 * @param bool         $allowed    Whether allowed.
		 * @param string       $taxonomy   Taxonomy slug.
		 * @param \WP_Taxonomy $object     Taxonomy object.
		 * @param array<int, string> $post_types Optional loop post types used for validation.
		 */
		$allowed = (bool) apply_filters( 'dsm_loop_filter_allow_taxonomy', true, $taxonomy, $object, $clean_post_types );

		return $allowed ? $taxonomy : '';
	}

	/**
	 * Category-like taxonomy for nested Loop post types.
	 *
	 * Product maps to product_cat; post maps to category; otherwise {type}_cat / {type}_category;
	 * else the first scoped taxonomy whose slug looks like a category.
	 *
	 * @param array<int, string> $post_types Loop post type slugs (or `any`).
	 * @return string Taxonomy slug, or empty when none apply.
	 */
	public static function resolve_default_category_taxonomy( array $post_types ): string {
		$clean_post_types = array_values(
			array_unique(
				array_filter(
					array_map(
						static function ( $post_type ) {
							return is_string( $post_type ) ? sanitize_key( $post_type ) : '';
						},
						$post_types
					)
				)
			)
		);

		$preferred_by_type = array(
			'product'           => 'product_cat',
			'product_variation' => 'product_cat',
			'post'              => 'category',
		);

		$types_to_try = empty( $clean_post_types ) || in_array( 'any', $clean_post_types, true )
			? array( 'post' )
			: $clean_post_types;

		$resolved = '';
		foreach ( $types_to_try as $post_type ) {
			if ( 'any' === $post_type ) {
				continue;
			}
			$candidates = array();
			if ( isset( $preferred_by_type[ $post_type ] ) ) {
				$candidates[] = $preferred_by_type[ $post_type ];
			}
			$candidates[] = $post_type . '_cat';
			$candidates[] = $post_type . '_category';
			foreach ( $candidates as $candidate ) {
				$ok = self::sanitize_public_taxonomy( $candidate, $clean_post_types );
				if ( '' !== $ok ) {
					$resolved = $ok;
					break 2;
				}
			}
		}

		if ( '' === $resolved && function_exists( 'dsm_get_public_taxonomies_for_loop_filter' ) ) {
			$catalog_types = empty( $clean_post_types ) || in_array( 'any', $clean_post_types, true )
				? null
				: $clean_post_types;
			$catalog       = dsm_get_public_taxonomies_for_loop_filter( $catalog_types );
			if ( is_array( $catalog ) ) {
				foreach ( $catalog as $item ) {
					$name = isset( $item['name'] ) ? (string) $item['name'] : '';
					if ( '' === $name ) {
						continue;
					}
					if ( false !== strpos( $name, 'cat' ) && false === strpos( $name, 'tag' ) ) {
						$ok = self::sanitize_public_taxonomy( $name, $clean_post_types );
						if ( '' !== $ok ) {
							$resolved = $ok;
							break;
						}
					}
				}
				if ( '' === $resolved ) {
					foreach ( $catalog as $item ) {
						$name = isset( $item['name'] ) ? (string) $item['name'] : '';
						if ( '' === $name ) {
							continue;
						}
						$ok = self::sanitize_public_taxonomy( $name, $clean_post_types );
						if ( '' !== $ok ) {
							$resolved = $ok;
							break;
						}
					}
				}
			}
		}

		/**
		 * Filter the auto-detected category taxonomy for Supreme Loop Filter.
		 *
		 * @param string       $resolved          Taxonomy slug.
		 * @param array<int, string> $clean_post_types  Loop post types.
		 */
		$filtered = apply_filters( 'dsm_loop_filter_default_category_taxonomy', $resolved, $clean_post_types );
		if ( ! is_string( $filtered ) || '' === $filtered ) {
			return $resolved;
		}

		$checked = self::sanitize_public_taxonomy( $filtered, $clean_post_types );
		return '' !== $checked ? $checked : $resolved;
	}

	/**
	 * Stored taxonomy when it applies to the Loop; otherwise that post type’s category taxonomy.
	 *
	 * @param string             $taxonomy   Raw taxonomy slug.
	 * @param array<int, string> $post_types Loop post types.
	 * @return string
	 */
	public static function resolve_effective_public_taxonomy( string $taxonomy, array $post_types = array() ): string {
		$clean = self::sanitize_public_taxonomy( $taxonomy, $post_types );
		if ( '' !== $clean ) {
			return $clean;
		}

		return self::resolve_default_category_taxonomy( $post_types );
	}

	/**
	 * Extract Divi Loop post type slugs from a loop value object.
	 *
	 * Mirrors Divi `LoopUtils::_extract_sub_type_values()` for `queryType=post_types`:
	 * `module.advanced.loop.desktop.value.subTypes` as value/label items or CSV.
	 * Empty `subTypes` means Divi queries `any` — returned as `array( 'any' )`.
	 *
	 * @param array<string, mixed> $loop_value Loop desktop.value array.
	 * @return list<string> Post type slugs, `any`, or empty when loop is off / non-post query.
	 */
	public static function extract_loop_post_types_from_value( array $loop_value ): array {
		$enabled = isset( $loop_value['enable'] ) ? (string) $loop_value['enable'] : '';
		if ( 'on' !== $enabled ) {
			return array();
		}

		$query_type = isset( $loop_value['queryType'] ) ? sanitize_key( (string) $loop_value['queryType'] ) : 'post_types';
		if ( 'post_types' !== $query_type ) {
			// current_page / terms / users / menus are not post-type taxonomy pickers.
			return array();
		}

		$sub_types = $loop_value['subTypes'] ?? null;
		$values    = self::normalize_loop_sub_type_values( $sub_types );

		if ( empty( $values ) ) {
			// Divi LoopUtils treats empty post_type as `any`.
			return array( 'any' );
		}

		return $values;
	}

	/**
	 * Normalize Divi loop `subTypes` into sanitized post type slugs.
	 *
	 * @param mixed $sub_types Raw subTypes attribute.
	 * @return list<string>
	 */
	public static function normalize_loop_sub_type_values( $sub_types ): array {
		if ( null === $sub_types ) {
			return array();
		}

		if ( is_string( $sub_types ) ) {
			$trimmed = trim( $sub_types );
			if ( '' === $trimmed ) {
				return array();
			}
			$parts = array_map( 'trim', explode( ',', $trimmed ) );
			$out   = array();
			foreach ( $parts as $part ) {
				$key = sanitize_key( $part );
				if ( '' !== $key ) {
					$out[] = $key;
				}
			}
			return array_values( array_unique( $out ) );
		}

		if ( ! is_array( $sub_types ) ) {
			return array();
		}

		if ( empty( $sub_types ) ) {
			return array();
		}

		$out = array();
		foreach ( $sub_types as $entry ) {
			if ( is_string( $entry ) ) {
				$key = sanitize_key( $entry );
				if ( '' !== $key ) {
					$out[] = $key;
				}
				continue;
			}
			if ( ! is_array( $entry ) && ! is_object( $entry ) ) {
				continue;
			}
			$item  = (array) $entry;
			$value = $item['value'] ?? null;
			if ( ! is_string( $value ) && ! is_numeric( $value ) ) {
				continue;
			}
			$key = sanitize_key( (string) $value );
			if ( '' !== $key ) {
				$out[] = $key;
			}
		}

		return array_values( array_unique( $out ) );
	}

	/**
	 * Collect Divi Loop post types from nested blocks (depth-first).
	 *
	 * @param array<int, array<string, mixed>> $blocks Blocks.
	 * @return list<string> Unique post type slugs (may include `any`).
	 */
	public static function collect_nested_loop_post_types( array $blocks ): array {
		$post_types = array();

		foreach ( $blocks as $block ) {
			if ( ! is_array( $block ) ) {
				continue;
			}

			$loop_value = $block['attrs']['module']['advanced']['loop']['desktop']['value'] ?? null;
			if ( is_array( $loop_value ) ) {
				$post_types = array_merge( $post_types, self::extract_loop_post_types_from_value( $loop_value ) );
			}

			if ( ! empty( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ) {
				$post_types = array_merge( $post_types, self::collect_nested_loop_post_types( $block['innerBlocks'] ) );
			}
		}

		return array_values( array_unique( $post_types ) );
	}

	/**
	 * Whether a taxonomy applies to the given loop post types.
	 *
	 * @param string             $taxonomy   Taxonomy slug.
	 * @param array<int, string> $post_types Loop post types (`any` = skip object_type check).
	 * @return bool
	 */
	public static function taxonomy_applies_to_post_types( string $taxonomy, array $post_types ): bool {
		return '' !== self::sanitize_public_taxonomy( $taxonomy, $post_types );
	}

	/**
	 * Bind filter payload to specific Divi loopIds (additive across instances).
	 *
	 * @param array<string, mixed> $filters          Filter payload.
	 * @param array<int, string>   $loop_ids         Target loopIds.
	 * @param bool                 $reset_pagination Whether to force page 1 for those loops.
	 * @return void
	 */
	public static function bind_filters_to_loop_ids( array $filters, array $loop_ids, bool $reset_pagination = true ): void {
		foreach ( $loop_ids as $loop_id ) {
			if ( ! is_string( $loop_id ) || '' === $loop_id ) {
				continue;
			}
			self::$loop_scoped_filters[ $loop_id ]   = $filters;
			self::$loop_reset_pagination[ $loop_id ] = $reset_pagination;
		}
	}

	/**
	 * Replace all scoped bindings (used by REST for a single instance render).
	 *
	 * @param array<string, mixed> $filters          Filter payload.
	 * @param array<int, string>   $loop_ids         Target loopIds.
	 * @param bool                 $reset_pagination Whether to force page 1.
	 * @return void
	 */
	public static function activate_for_loop_ids( array $filters, array $loop_ids, bool $reset_pagination = true ): void {
		self::$loop_scoped_filters                = array();
		self::$loop_reset_pagination              = array();
		self::$observed_loop_ids                  = array();
		self::$fragment_wildcard_filters          = null;
		self::$fragment_wildcard_reset_pagination = false;

		if ( empty( $loop_ids ) ) {
			// Fragment render only: no other loops run during et_builder_render_layout of inner blocks.
			self::$fragment_wildcard_filters          = $filters;
			self::$fragment_wildcard_reset_pagination = $reset_pagination;
			return;
		}

		self::bind_filters_to_loop_ids( $filters, $loop_ids, $reset_pagination );
	}

	/**
	 * Clear all scoped filter bindings.
	 *
	 * @return void
	 */
	public static function deactivate(): void {
		self::$loop_scoped_filters                = array();
		self::$loop_reset_pagination              = array();
		self::$observed_loop_ids                  = array();
		self::$fragment_wildcard_filters          = null;
		self::$fragment_wildcard_reset_pagination = false;
	}

	/**
	 * Whether any scoped filters are active.
	 *
	 * @return bool
	 */
	public static function is_active(): bool {
		return ! empty( self::$loop_scoped_filters ) || null !== self::$fragment_wildcard_filters;
	}

	/**
	 * Mutate Divi loop query args only for loops nested under an active Loop Filter.
	 *
	 * @param array<string, mixed> $loop_data   Loop data (query_args, query_type, …).
	 * @param array<string, mixed> $block_attrs Block attributes.
	 * @param array<string, mixed> $block       Full block array.
	 * @return array<string, mixed>
	 */
	public function filter_loop_data_after_execution( $loop_data, $block_attrs, $block ) {
		if ( ! is_array( $loop_data ) || ! self::is_active() ) {
			return $loop_data;
		}

		$query_type = isset( $loop_data['query_type'] ) ? (string) $loop_data['query_type'] : '';
		if ( ! in_array( $query_type, array( 'post_types', 'current_page' ), true ) ) {
			return $loop_data;
		}

		$loop_id = null;
		if ( is_array( $block_attrs ) ) {
			$loop_value = $block_attrs['module']['advanced']['loop']['desktop']['value'] ?? array();
			$loop_id    = is_array( $loop_value ) ? ( $loop_value['loopId'] ?? null ) : null;
		}

		$filters      = null;
		$should_reset = false;
		if ( is_string( $loop_id ) && '' !== $loop_id && isset( self::$loop_scoped_filters[ $loop_id ] ) ) {
			$filters      = self::$loop_scoped_filters[ $loop_id ];
			$should_reset = ! empty( self::$loop_reset_pagination[ $loop_id ] );
		} elseif ( null !== self::$fragment_wildcard_filters ) {
			$filters      = self::$fragment_wildcard_filters;
			$should_reset = self::$fragment_wildcard_reset_pagination;
		} else {
			return $loop_data;
		}

		if ( ! isset( $loop_data['query_args'] ) || ! is_array( $loop_data['query_args'] ) ) {
			$loop_data['query_args'] = array();
		}

		$search = isset( $filters['search'] ) ? (string) $filters['search'] : '';
		$terms  = isset( $filters['terms'] ) && is_array( $filters['terms'] ) ? $filters['terms'] : array();

		$loop_post_types = array();
		if ( isset( $loop_data['query_args']['post_type'] ) ) {
			$raw_pt = $loop_data['query_args']['post_type'];
			if ( is_string( $raw_pt ) && '' !== $raw_pt ) {
				$loop_post_types = array_map( 'sanitize_key', array_map( 'trim', explode( ',', $raw_pt ) ) );
			} elseif ( is_array( $raw_pt ) ) {
				foreach ( $raw_pt as $pt ) {
					if ( is_string( $pt ) || is_numeric( $pt ) ) {
						$loop_post_types[] = sanitize_key( (string) $pt );
					}
				}
			}
		}
		$loop_post_types = array_values( array_unique( array_filter( $loop_post_types ) ) );

		$taxonomy = isset( $filters['taxonomy'] )
			? self::sanitize_public_taxonomy( (string) $filters['taxonomy'], $loop_post_types )
			: '';

		$tax_queries = self::normalize_tax_queries( $filters['tax_queries'] ?? array(), $loop_post_types );
		if ( empty( $tax_queries ) && '' !== $taxonomy && ! empty( $terms ) ) {
			$tax_queries = self::normalize_tax_queries(
				array(
					array(
						'taxonomy' => $taxonomy,
						'terms'    => $terms,
					),
				),
				$loop_post_types
			);
		}

		if ( '' !== $search ) {
			$loop_data['query_args']['s'] = $search;
		}

		if ( ! empty( $tax_queries ) ) {
			$tax_query = isset( $loop_data['query_args']['tax_query'] ) && is_array( $loop_data['query_args']['tax_query'] )
				? $loop_data['query_args']['tax_query']
				: array();

			foreach ( $tax_queries as $group ) {
				$relation    = isset( $group['relation'] )
					? self::sanitize_tax_relation( (string) $group['relation'], 'OR' )
					: 'OR';
				$tax_query[] = array(
					'taxonomy' => $group['taxonomy'],
					'field'    => 'slug',
					'terms'    => $group['terms'],
					'operator' => self::tax_relation_to_operator( $relation ),
				);
			}

			$across_relation = self::sanitize_tax_relation(
				isset( $filters['tax_query_relation'] ) ? (string) $filters['tax_query_relation'] : 'AND',
				'AND'
			);

			$clause_count = 0;
			foreach ( $tax_query as $key => $clause ) {
				if ( 'relation' === $key || ! is_array( $clause ) ) {
					continue;
				}
				++$clause_count;
			}
			if ( $clause_count > 1 ) {
				$tax_query['relation'] = $across_relation;
			}

			$loop_data['query_args']['tax_query'] = $tax_query;
		}

		$orderby = isset( $filters['orderby'] ) ? self::sanitize_orderby( (string) $filters['orderby'] ) : '';
		if ( '' !== $orderby ) {
			$loop_data['query_args']['orderby'] = $orderby;
			if ( 'rand' !== $orderby ) {
				$loop_data['query_args']['order'] = self::sanitize_order(
					isset( $filters['order'] ) ? (string) $filters['order'] : 'DESC'
				);
			}
		}

		$author_id = self::sanitize_author_id( $filters['author'] ?? 0 );
		if ( $author_id > 0 ) {
			// Single-select Phase 1: WP_Query `author` (int). Multi-author would use author__in.
			$loop_data['query_args']['author'] = $author_id;
		}

		self::apply_date_range_to_query_args( $loop_data['query_args'], $filters );

		self::apply_woocommerce_to_query_args(
			$loop_data['query_args'],
			$filters,
			$loop_post_types
		);

		self::apply_custom_field_to_query_args(
			$loop_data['query_args'],
			$filters
		);

		if ( $should_reset ) {
			$base_offset = 0;
			if ( is_array( $block_attrs ) ) {
				$loop_value  = $block_attrs['module']['advanced']['loop']['desktop']['value'] ?? array();
				$base_offset = is_array( $loop_value ) ? absint( $loop_value['postOffset'] ?? 0 ) : 0;
			}
			if ( is_string( $loop_id ) && '' !== $loop_id && isset( $_GET[ $loop_id ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
				unset( $_GET[ $loop_id ] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			}

			// Pagination is baked into offset before this filter; restore Loop's base postOffset only.
			$loop_data['query_args']['offset'] = $base_offset;
			if ( isset( $loop_data['query_args']['paged'] ) ) {
				$loop_data['query_args']['paged'] = 1;
			}
		}

		if ( is_string( $loop_id ) && '' !== $loop_id ) {
			self::$observed_loop_ids[] = $loop_id;
		}

		/**
		 * Filter mutated loop data after Supreme Loop Filter applies search/taxonomy.
		 *
		 * @param array<string, mixed> $loop_data   Loop data.
		 * @param array<string, mixed> $block_attrs Block attributes.
		 * @param array<string, mixed> $block       Block.
		 * @param array<string, mixed> $filters     Active filters for this loopId.
		 */
		return apply_filters( 'dsm_loop_filter_loop_data', $loop_data, $block_attrs, $block, $filters );
	}

	/**
	 * Register public REST route for filtered results HTML.
	 *
	 * @return void
	 */
	public function register_rest_routes(): void {
		register_rest_route(
			'dsm/v1',
			'/loop-filter/render',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'rest_render_filtered_results' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'layout_id'           => array(
						'type'              => 'integer',
						'required'          => false,
						'default'           => 0,
						'sanitize_callback' => 'absint',
					),
					'context_post_id'     => array(
						'type'              => 'integer',
						'required'          => false,
						'default'           => 0,
						'sanitize_callback' => 'absint',
					),
					'post_id'             => array(
						'type'              => 'integer',
						'required'          => false,
						'default'           => 0,
						'sanitize_callback' => 'absint',
						'description'       => 'Deprecated alias of layout_id / context_post_id.',
					),
					'index'               => array(
						'type'              => 'integer',
						'required'          => true,
						'sanitize_callback' => 'absint',
					),
					'loop_ids'            => array(
						'type'     => 'array',
						'required' => false,
						'default'  => array(),
						'items'    => array(
							'type' => 'string',
						),
					),
					'search'              => array(
						'type'              => 'string',
						'required'          => false,
						'default'           => '',
						'sanitize_callback' => 'sanitize_text_field',
					),
					'taxonomy'            => array(
						'type'              => 'string',
						'required'          => false,
						'default'           => '',
						'sanitize_callback' => 'sanitize_key',
					),
					'terms'               => array(
						'type'     => 'array',
						'required' => false,
						'default'  => array(),
						'items'    => array(
							'type' => 'string',
						),
					),
					'tax_queries'         => array(
						'type'        => 'array',
						'required'    => false,
						'default'     => array(),
						'items'       => array(
							'type' => 'object',
						),
						'description' => 'Multi-taxonomy filters. Each item: { taxonomy, terms[], relation?: AND|OR }. Across-group relation via tax_query_relation.',
					),
					'tax_query_relation'  => array(
						'type'              => 'string',
						'required'          => false,
						'default'           => 'AND',
						'sanitize_callback' => 'sanitize_text_field',
						'description'       => 'Relation across taxonomy filter groups: AND|OR (default AND). Applied from parent module attrs.',
					),
					'orderby'             => array(
						'type'              => 'string',
						'required'          => false,
						'default'           => '',
						'sanitize_callback' => 'sanitize_key',
					),
					'order'               => array(
						'type'              => 'string',
						'required'          => false,
						'default'           => 'DESC',
						'sanitize_callback' => 'sanitize_text_field',
					),
					'author'              => array(
						'type'              => 'integer',
						'required'          => false,
						'default'           => 0,
						'sanitize_callback' => 'absint',
						'description'       => 'Filter by post author user ID (WP_Query author).',
					),
					'date_from'           => array(
						'type'              => 'string',
						'required'          => false,
						'default'           => '',
						'sanitize_callback' => 'sanitize_text_field',
						'description'       => 'Inclusive published-date range start (Y-m-d).',
					),
					'date_to'             => array(
						'type'              => 'string',
						'required'          => false,
						'default'           => '',
						'sanitize_callback' => 'sanitize_text_field',
						'description'       => 'Inclusive published-date range end (Y-m-d).',
					),
					'min_price'           => array(
						'type'              => 'string',
						'required'          => false,
						'default'           => '',
						'sanitize_callback' => 'sanitize_text_field',
						'description'       => 'WooCommerce minimum product price.',
					),
					'max_price'           => array(
						'type'              => 'string',
						'required'          => false,
						'default'           => '',
						'sanitize_callback' => 'sanitize_text_field',
						'description'       => 'WooCommerce maximum product price.',
					),
					'price_ranges'        => array(
						'type'        => 'string',
						'required'    => false,
						'default'     => '',
						'description' => 'OR price buckets as min-max pairs, e.g. 50-100,200- (empty side = open).',
					),
					'include_price_stats' => array(
						'type'        => 'boolean',
						'required'    => false,
						'default'     => false,
						'description' => 'When true, include catalog price_stats (min/max/histogram) on the response.',
					),
					'rating'              => array(
						'type'              => 'integer',
						'required'          => false,
						'default'           => 0,
						'sanitize_callback' => 'absint',
						'description'       => 'Product average star rating (1–5), exact match.',
					),
					'stock_status'        => array(
						'type'              => 'string',
						'required'          => false,
						'default'           => '',
						'sanitize_callback' => 'sanitize_key',
						'description'       => 'WooCommerce stock status: instock|outofstock|onbackorder.',
					),
					'meta_queries'        => array(
						'type'        => 'array',
						'required'    => false,
						'default'     => array(),
						'items'       => array(
							'type' => 'object',
						),
						'description' => 'Custom field filters. Each item: { key, value } or { key, values[] }. Keys must match Custom Field items on this Loop Filter.',
					),
					'reset_pagination'    => array(
						'type'     => 'boolean',
						'required' => false,
						'default'  => true,
					),
					'page'                => array(
						'type'              => 'integer',
						'required'          => false,
						'default'           => 1,
						'sanitize_callback' => 'absint',
						'description'       => '1-based page for nested Divi Loop(s).',
					),
				),
			)
		);

		/*
		 * VB taxonomy preview: core `/wp/v2/{rest_base}` omits Woo attribute taxonomies
		 * (`pa_*`) when archives are off (`public`/`show_in_rest` false). Mirror FE
		 * `get_terms()` for every Loop Filter–eligible taxonomy.
		 */
		register_rest_route(
			'dsm/v1',
			'/loop-filter/terms',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'rest_get_taxonomy_terms' ),
				'permission_callback' => array( $this, 'rest_terms_permission_check' ),
				'args'                => array(
					'taxonomy'   => array(
						'type'              => 'string',
						'required'          => true,
						'sanitize_callback' => 'sanitize_key',
						'description'       => 'Loop Filter–eligible taxonomy slug.',
					),
					'page'       => array(
						'type'              => 'integer',
						'required'          => false,
						'default'           => 1,
						'sanitize_callback' => 'absint',
					),
					'per_page'   => array(
						'type'              => 'integer',
						'required'          => false,
						'default'           => 100,
						'sanitize_callback' => 'absint',
					),
					'hide_empty' => array(
						'type'     => 'boolean',
						'required' => false,
						'default'  => true,
					),
				),
			)
		);

		/*
		 * VB custom-field list preview: distinct values for a known meta key
		 * (not a key-discovery catalog). Same edit_posts gate as /terms.
		 */
		register_rest_route(
			'dsm/v1',
			'/loop-filter/meta-values',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'rest_get_meta_values' ),
				'permission_callback' => array( $this, 'rest_terms_permission_check' ),
				'args'                => array(
					'meta_key'  => array(
						'type'        => 'string',
						'required'    => true,
						'description' => 'Known custom-field meta key configured on a Loop Filter Item.',
					),
					'post_type' => array(
						'type'        => 'array',
						'required'    => false,
						'default'     => array(),
						'items'       => array(
							'type' => 'string',
						),
						'description' => 'Nested Loop post types used to scope distinct values.',
					),
				),
			)
		);

		/*
		 * VB slider bounds / histogram preview. Same edit_posts gate as /terms.
		 */
		register_rest_route(
			'dsm/v1',
			'/loop-filter/price-stats',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'rest_get_price_stats' ),
				'permission_callback' => array( $this, 'rest_terms_permission_check' ),
				'args'                => array(
					'post_type'         => array(
						'type'        => 'array',
						'required'    => false,
						'default'     => array(),
						'items'       => array(
							'type' => 'string',
						),
						'description' => 'Nested Loop post types used to scope catalog min/max.',
					),
					'histogram_buckets' => array(
						'type'              => 'integer',
						'required'          => false,
						'default'           => 20,
						'sanitize_callback' => 'absint',
					),
					'step'              => array(
						'type'              => 'string',
						'required'          => false,
						'default'           => '1',
						'sanitize_callback' => 'sanitize_text_field',
					),
				),
			)
		);
	}

	/**
	 * Whether the current user may load Loop Filter taxonomy terms in the Visual Builder.
	 *
	 * @return bool
	 */
	public function rest_terms_permission_check(): bool {
		return current_user_can( 'edit_posts' );
	}

	/**
	 * REST: list terms for a Loop Filter–eligible taxonomy (VB preview).
	 *
	 * Uses `get_terms()` so WooCommerce global attributes (`pa_*`) work even when
	 * they are not registered with `show_in_rest` (core `/wp/v2/…` 404).
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function rest_get_taxonomy_terms( WP_REST_Request $request ) {
		$taxonomy = self::sanitize_public_taxonomy( (string) $request->get_param( 'taxonomy' ) );
		if ( '' === $taxonomy ) {
			return new WP_Error(
				'dsm_loop_filter_invalid_taxonomy',
				__( 'Invalid or ineligible taxonomy.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 400 )
			);
		}

		$page     = max( 1, (int) $request->get_param( 'page' ) );
		$per_page = (int) $request->get_param( 'per_page' );
		if ( $per_page < 1 ) {
			$per_page = 100;
		}
		if ( $per_page > 100 ) {
			$per_page = 100;
		}

		$hide_empty_param = $request->get_param( 'hide_empty' );
		$hide_empty       = null === $hide_empty_param
			? true
			: rest_sanitize_boolean( $hide_empty_param );

		$offset = ( $page - 1 ) * $per_page;

		$terms = get_terms(
			array(
				'taxonomy'   => $taxonomy,
				'hide_empty' => (bool) $hide_empty,
				'orderby'    => 'name',
				'order'      => 'ASC',
				'number'     => $per_page,
				'offset'     => $offset,
			)
		);

		if ( is_wp_error( $terms ) ) {
			return new WP_Error(
				'dsm_loop_filter_terms_query_failed',
				__( 'Could not load terms.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 500 )
			);
		}

		if ( ! is_array( $terms ) ) {
			$terms = array();
		}

		$total = wp_count_terms(
			array(
				'taxonomy'   => $taxonomy,
				'hide_empty' => (bool) $hide_empty,
			)
		);
		if ( is_wp_error( $total ) ) {
			$total = count( $terms );
		}
		$total       = (int) $total;
		$total_pages = $per_page > 0 ? (int) ceil( $total / $per_page ) : 1;
		if ( $total_pages < 1 ) {
			$total_pages = 1;
		}

		$out = array();
		foreach ( $terms as $term ) {
			if ( ! $term instanceof WP_Term ) {
				continue;
			}
			$out[] = array(
				'id'     => (int) $term->term_id,
				'parent' => (int) $term->parent,
				'slug'   => (string) $term->slug,
				'name'   => (string) $term->name,
				'count'  => (int) $term->count,
			);
		}

		/**
		 * Filter taxonomy terms returned for Loop Filter Visual Builder preview.
		 *
		 * @param array<int, array{id: int, parent: int, slug: string, name: string, count: int}> $out      Terms.
		 * @param string                                                                          $taxonomy Taxonomy slug.
		 * @param WP_REST_Request                                                                 $request  Request.
		 */
		$filtered = apply_filters( 'dsm_loop_filter_rest_taxonomy_terms', $out, $taxonomy, $request );
		if ( ! is_array( $filtered ) ) {
			$filtered = $out;
		}

		$response = new WP_REST_Response( $filtered, 200 );
		$response->header( 'X-WP-Total', (string) $total );
		$response->header( 'X-WP-TotalPages', (string) $total_pages );

		return $response;
	}

	/**
	 * REST: distinct values for a known custom-field meta key (VB preview).
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function rest_get_meta_values( WP_REST_Request $request ) {
		$key_raw = (string) $request->get_param( 'meta_key' );
		$key     = function_exists( 'dsm_loop_filter_sanitize_meta_key' )
			? dsm_loop_filter_sanitize_meta_key( $key_raw )
			: '';

		if ( '' === $key || ! function_exists( 'dsm_loop_filter_is_allowed_meta_key' ) || ! dsm_loop_filter_is_allowed_meta_key( $key ) ) {
			return new WP_Error(
				'dsm_loop_filter_invalid_meta_key',
				__( 'Invalid or ineligible custom field key.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 400 )
			);
		}

		$post_types = $request->get_param( 'post_type' );
		if ( is_string( $post_types ) && '' !== $post_types ) {
			$post_types = explode( ',', $post_types );
		}
		if ( ! is_array( $post_types ) ) {
			$post_types = array();
		}

		$types = array();
		foreach ( $post_types as $post_type ) {
			if ( ! is_scalar( $post_type ) ) {
				continue;
			}
			$sanitized = sanitize_key( (string) $post_type );
			if ( '' !== $sanitized ) {
				$types[] = $sanitized;
			}
		}

		if ( ! function_exists( 'dsm_loop_filter_get_meta_value_options' ) ) {
			return new WP_REST_Response( array(), 200 );
		}

		$out = dsm_loop_filter_get_meta_value_options( $key, $types );

		/**
		 * Filter custom-field values returned for Loop Filter Visual Builder preview.
		 *
		 * @param array<int, array{value: string, label: string}> $out     Values.
		 * @param string                                    $key     Meta key.
		 * @param array<int, string>                              $types   Post types.
		 * @param WP_REST_Request                           $request Request.
		 */
		$filtered = apply_filters( 'dsm_loop_filter_rest_meta_values', $out, $key, $types, $request );

		return new WP_REST_Response( is_array( $filtered ) ? $filtered : $out, 200 );
	}

	/**
	 * REST: catalog price min/max + optional histogram (VB slider preview).
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function rest_get_price_stats( WP_REST_Request $request ) {
		$empty = array(
			'min'     => 0.0,
			'max'     => 0.0,
			'buckets' => array(),
			'empty'   => true,
		);

		if ( ! self::is_woocommerce_active() ) {
			return new WP_Error(
				'dsm_loop_filter_woo_inactive',
				__( 'WooCommerce is not active.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 400 )
			);
		}

		if ( ! function_exists( 'dsm_loop_filter_query_price_stats' ) ) {
			return new WP_REST_Response( $empty, 200 );
		}

		$post_types = $request->get_param( 'post_type' );
		if ( is_string( $post_types ) && '' !== $post_types ) {
			$post_types = explode( ',', $post_types );
		}
		if ( ! is_array( $post_types ) ) {
			$post_types = array();
		}

		$types = array();
		foreach ( $post_types as $post_type ) {
			if ( ! is_scalar( $post_type ) ) {
				continue;
			}
			$sanitized = sanitize_key( (string) $post_type );
			if ( '' !== $sanitized ) {
				$types[] = $sanitized;
			}
		}
		if ( empty( $types ) ) {
			$types = array( 'product' );
		}

		$hist = absint( $request->get_param( 'histogram_buckets' ) );
		if ( $hist < 1 ) {
			$hist = 0;
		}
		$step_raw = $request->get_param( 'step' );
		$step     = is_numeric( $step_raw ) && (float) $step_raw > 0 ? (float) $step_raw : 1.0;

		$stats = dsm_loop_filter_query_price_stats( $types, null, $hist, $step );

		/**
		 * Filter catalog price stats returned for Loop Filter Visual Builder preview.
		 *
		 * @param array<string, mixed> $stats    Stats payload.
		 * @param array<int, string>         $types    Post types.
		 * @param WP_REST_Request      $request  Request.
		 */
		$filtered = apply_filters( 'dsm_loop_filter_rest_price_stats', $stats, $types, $request );

		return new WP_REST_Response( is_array( $filtered ) ? $filtered : $stats, 200 );
	}

	/**
	 * REST: re-render loop-filter parent inner blocks with active filters.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function rest_render_filtered_results( WP_REST_Request $request ) {
		$nonce = $request->get_header( 'X-WP-Nonce' );
		if ( ! is_string( $nonce ) || ! wp_verify_nonce( $nonce, 'wp_rest' ) ) {
			return new WP_Error(
				'dsm_loop_filter_invalid_nonce',
				__( 'Invalid security token.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 403 )
			);
		}

		$rate = self::check_rate_limit();
		if ( is_wp_error( $rate ) ) {
			return $rate;
		}

		$layout_id       = (int) $request->get_param( 'layout_id' );
		$context_post_id = (int) $request->get_param( 'context_post_id' );
		$legacy_post_id  = (int) $request->get_param( 'post_id' );
		$index           = (int) $request->get_param( 'index' );

		if ( $layout_id < 1 ) {
			$layout_id = $legacy_post_id;
		}
		if ( $context_post_id < 1 ) {
			$context_post_id = $legacy_post_id > 0 ? $legacy_post_id : $layout_id;
		}

		$source = self::resolve_module_source_post( $layout_id );
		if ( ! $source instanceof WP_Post ) {
			// Theme Builder / library fallback: scan layout post types for the module.
			$source = self::find_layout_post_containing_loop_filter( $index );
		}

		if ( ! $source instanceof WP_Post ) {
			return new WP_Error(
				'dsm_loop_filter_missing_post',
				__( 'Loop Filter layout not found.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 404 )
			);
		}

		if ( ! $this->is_post_publicly_readable( $source ) ) {
			return new WP_Error(
				'dsm_loop_filter_forbidden_post',
				__( 'You cannot filter this content.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 403 )
			);
		}

		$context_post = get_post( $context_post_id );
		if ( ! $context_post instanceof WP_Post ) {
			$context_post = $source;
		} elseif ( ! $this->is_post_publicly_readable( $context_post ) ) {
			return new WP_Error(
				'dsm_loop_filter_forbidden_post',
				__( 'You cannot filter this content.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 403 )
			);
		}

		$terms_param = $request->get_param( 'terms' );
		$terms       = array();
		if ( is_array( $terms_param ) ) {
			foreach ( $terms_param as $term_slug ) {
				if ( ! is_string( $term_slug ) && ! is_numeric( $term_slug ) ) {
					continue;
				}
				$slug = sanitize_title( (string) $term_slug );
				if ( '' !== $slug ) {
					$terms[] = $slug;
				}
			}
		}

		$parent_block = self::find_nth_loop_filter_block( (string) $source->post_content, $index );
		if ( null === $parent_block ) {
			return new WP_Error(
				'dsm_loop_filter_missing_module',
				__( 'Supreme Loop Filter module not found on this layout.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 404 )
			);
		}

		$inner_blocks = isset( $parent_block['innerBlocks'] ) && is_array( $parent_block['innerBlocks'] )
			? $parent_block['innerBlocks']
			: array();

		// Results only — exclude compositional filter items from the AJAX fragment.
		$results_blocks = array();
		foreach ( $inner_blocks as $inner_block ) {
			if ( ! is_array( $inner_block ) ) {
				continue;
			}
			if ( ( $inner_block['blockName'] ?? '' ) === 'dsm/loop-filter-item' ) {
				continue;
			}
			$results_blocks[] = $inner_block;
		}

		$loop_post_types = self::collect_nested_loop_post_types( $results_blocks );
		$tax_queries     = self::normalize_tax_queries( $request->get_param( 'tax_queries' ), $loop_post_types );
		$legacy_taxonomy = self::sanitize_public_taxonomy( (string) $request->get_param( 'taxonomy' ), $loop_post_types );
		if ( empty( $tax_queries ) && '' !== $legacy_taxonomy && ! empty( $terms ) ) {
			$tax_queries = self::normalize_tax_queries(
				array(
					array(
						'taxonomy' => $legacy_taxonomy,
						'terms'    => $terms,
					),
				),
				$loop_post_types
			);
		}

		$parent_attrs = isset( $parent_block['attrs'] ) && is_array( $parent_block['attrs'] )
			? $parent_block['attrs']
			: array();
		// Across-items relation is module config — read from the layout parent attrs.
		$tax_query_relation = self::sanitize_tax_relation(
			self::inner_desktop_string( $parent_attrs, 'tax_query_relation', 'AND' ),
			'AND'
		);
		$tax_queries        = self::enrich_tax_queries_with_item_relations(
			$tax_queries,
			$inner_blocks,
			$loop_post_types
		);

		$filters = array(
			'search'             => (string) $request->get_param( 'search' ),
			'taxonomy'           => ! empty( $tax_queries ) ? (string) $tax_queries[0]['taxonomy'] : $legacy_taxonomy,
			'terms'              => ! empty( $tax_queries ) ? $tax_queries[0]['terms'] : array_values( array_unique( $terms ) ),
			'tax_queries'        => $tax_queries,
			'tax_query_relation' => $tax_query_relation,
			'orderby'            => self::sanitize_orderby( (string) $request->get_param( 'orderby' ) ),
			'order'              => self::sanitize_order( (string) $request->get_param( 'order' ) ),
			'author'             => self::sanitize_author_id( $request->get_param( 'author' ) ),
			'date_from'          => self::sanitize_date_ymd( $request->get_param( 'date_from' ) ),
			'date_to'            => self::sanitize_date_ymd( $request->get_param( 'date_to' ) ),
			'min_price'          => self::is_woocommerce_active()
				? self::sanitize_price_value( $request->get_param( 'min_price' ) )
				: '',
			'max_price'          => self::is_woocommerce_active()
				? self::sanitize_price_value( $request->get_param( 'max_price' ) )
				: '',
			'price_ranges'       => self::is_woocommerce_active()
				? self::sanitize_price_ranges( $request->get_param( 'price_ranges' ) )
				: array(),
			'rating'             => self::is_woocommerce_active()
				? self::sanitize_rating_min( $request->get_param( 'rating' ) )
				: 0,
			'stock_status'       => self::is_woocommerce_active()
				? self::sanitize_stock_status( $request->get_param( 'stock_status' ) )
				: '',
			'meta_queries'       => self::sanitize_meta_queries(
				$request->get_param( 'meta_queries' ),
				self::collect_allowed_custom_field_keys( $inner_blocks )
			),
		);

		$page = max( 1, (int) $request->get_param( 'page' ) );

		if ( empty( $results_blocks ) ) {
			return rest_ensure_response(
				self::empty_rest_payload( $page )
			);
		}

		$loop_ids_param = $request->get_param( 'loop_ids' );
		$loop_ids       = array();
		if ( is_array( $loop_ids_param ) ) {
			foreach ( $loop_ids_param as $lid ) {
				if ( is_string( $lid ) && '' !== $lid ) {
					$loop_ids[] = $lid;
				}
			}
		}
		if ( empty( $loop_ids ) ) {
			$loop_ids = self::collect_nested_loop_ids( $results_blocks );
		}

		$loop_base = self::collect_nested_loop_base_meta( $results_blocks );

		$fragment = '';
		foreach ( $results_blocks as $inner_block ) {
			$fragment .= serialize_block( $inner_block );
		}

		if ( '' === trim( $fragment ) ) {
			return rest_ensure_response(
				self::empty_rest_payload( $page )
			);
		}

		if ( ! function_exists( 'et_builder_render_layout' ) ) {
			return new WP_Error(
				'dsm_loop_filter_missing_renderer',
				__( 'Divi layout renderer is unavailable.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 500 )
			);
		}

		if ( class_exists( LoopQueryRegistry::class ) ) {
			LoopQueryRegistry::clear();
		}

		$reset_pagination = filter_var( $request->get_param( 'reset_pagination' ), FILTER_VALIDATE_BOOLEAN );
		if ( $page > 1 ) {
			// Paging must keep Divi loop page params; do not force offset back to base.
			$reset_pagination = false;
		}

		$saved_get = self::apply_loop_page_to_request( $loop_ids, $page );
		self::activate_for_loop_ids( $filters, $loop_ids, $reset_pagination );

		$html = '';
		try {
			if ( class_exists( '\ET_Post_Stack' ) ) {
				\ET_Post_Stack::replace( $context_post );
			}

			$rendered = et_builder_render_layout( $fragment );
			$html     = is_string( $rendered ) ? $rendered : '';

			if ( class_exists( '\ET_Post_Stack' ) ) {
				\ET_Post_Stack::restore();
			}
		} catch ( \Throwable $e ) { // phpcs:ignore Generic.CodeAnalysis.EmptyStatement.DetectedCatch -- Restored below.
			if ( class_exists( '\ET_Post_Stack' ) ) {
				\ET_Post_Stack::restore();
			}
			self::restore_loop_page_request( $saved_get );
			self::deactivate();

			return new WP_Error(
				'dsm_loop_filter_render_failed',
				__( 'Failed to render filtered results.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 500 )
			);
		}

		$found_posts = self::resolve_found_posts_from_registry( $loop_ids );
		self::restore_loop_page_request( $saved_get );
		self::deactivate();

		/**
		 * Filter the AJAX HTML fragment returned for Supreme Loop Filter.
		 *
		 * @param string               $html       Rendered HTML.
		 * @param array<string, mixed> $filters    Filters applied.
		 * @param int                  $layout_id  Layout / source post ID.
		 * @param int                  $index      Module instance index within layout.
		 */
		$html = (string) apply_filters( 'dsm_loop_filter_rest_html', $html, $filters, $source->ID, $index );

		$returned_html = self::count_loop_items_in_html( $html );
		$html_is_blank = self::is_effectively_empty_html( $html );

		/*
		 * Keep raw found_posts (0 allowed) for pagination math. Flooring to 1
		 * before resolve_pagination_state forces max_pages=1 and hides chrome.
		 * When the fragment has no loop items, pass found_posts=0 so stale
		 * Divi loop_pagination_total_pages breadcrumbs cannot keep old pages.
		 */
		$paging = self::resolve_pagination_state(
			$loop_ids,
			$loop_base,
			$page,
			$html_is_blank ? 0 : $found_posts,
			$returned_html
		);

		/*
		 * Empty when the fragment has no real loop items / only Divi’s
		 * “No Results Found” placeholder. Do not treat registry found_posts===0
		 * alone as empty (metadata historically always 0).
		 *
		 * For page > 1, blank HTML means “no more posts” — not the empty state,
		 * unless the filtered query has zero items total (stale page index).
		 */
		if ( $html_is_blank && 1 === $page ) {
			$empty               = true;
			$found_posts         = 0;
			$paging['page']      = 1;
			$paging['max_pages'] = 1;
			$paging['has_more']  = false;
		} elseif ( $html_is_blank && $page > 1 ) {
			$empty = false;
			if ( $returned_html < 1 && $found_posts < 1 ) {
				// Filter (or bad page) yielded a fully empty set — reset chrome.
				$empty               = true;
				$found_posts         = 0;
				$paging['page']      = 1;
				$paging['max_pages'] = 1;
				$paging['has_more']  = false;
			} else {
				$paging['has_more']  = false;
				$paging['max_pages'] = max( 1, $page - 1 );
				$paging['page']      = $paging['max_pages'];
			}
		} else {
			$empty = false;
			if ( $found_posts < 1 ) {
				$found_posts = self::estimate_found_posts_for_display(
					$returned_html,
					$paging,
					$page
				);
			}
		}

		$payload = array(
			'html'           => $html,
			'found_posts'    => $found_posts,
			'empty'          => $empty,
			'page'           => $paging['page'],
			'max_pages'      => $paging['max_pages'],
			'has_more'       => $paging['has_more'],
			'posts_per_page' => $paging['posts_per_page'],
		);

		if (
			self::is_woocommerce_active()
			&& $request->get_param( 'include_price_stats' )
			&& function_exists( 'dsm_loop_filter_query_price_stats' )
		) {
			$payload['price_stats'] = dsm_loop_filter_query_price_stats( $loop_post_types, null, 20, 1.0 );
		}

		return rest_ensure_response( $payload );
	}

	/**
	 * Empty REST payload with pagination fields.
	 *
	 * @param int $page Requested page.
	 * @return array<string, mixed>
	 */
	private static function empty_rest_payload( int $page ): array {
		unset( $page );

		return array(
			'html'           => '',
			'found_posts'    => 0,
			'empty'          => true,
			'page'           => 1,
			'max_pages'      => 1,
			'has_more'       => false,
			'posts_per_page' => 0,
		);
	}

	/**
	 * Collect base postPerPage / postOffset / total_pages for nested Divi Loops.
	 *
	 * After Divi expands a loop, `desktop.value` is stripped and only
	 * `loop_pagination_id` + `loop_pagination_total_pages` remain on the first
	 * duplicate — FE SSR of Loop Filter must read those breadcrumbs.
	 *
	 * @param array<int, array<string, mixed>> $blocks Blocks.
	 * @return array<string, array{post_per_page: int, post_offset: int, total_pages: int}>
	 */
	public static function collect_nested_loop_base_meta( array $blocks ): array {
		$meta = array();

		foreach ( $blocks as $block ) {
			if ( ! is_array( $block ) ) {
				continue;
			}

			$loop_root = $block['attrs']['module']['advanced']['loop'] ?? null;
			if ( is_array( $loop_root ) ) {
				$loop_value = $loop_root['desktop']['value'] ?? null;
				if ( is_array( $loop_value ) ) {
					$enabled = isset( $loop_value['enable'] ) ? (string) $loop_value['enable'] : '';
					$loop_id = isset( $loop_value['loopId'] ) ? (string) $loop_value['loopId'] : '';
					if ( 'on' === $enabled && '' !== $loop_id ) {
						$ppp = isset( $loop_value['postPerPage'] ) ? absint( $loop_value['postPerPage'] ) : 10;
						if ( $ppp < 1 ) {
							$ppp = 10;
						}
						$meta[ $loop_id ] = array(
							'post_per_page' => $ppp,
							'post_offset'   => isset( $loop_value['postOffset'] ) ? absint( $loop_value['postOffset'] ) : 0,
							'total_pages'   => isset( $meta[ $loop_id ]['total_pages'] )
								? (int) $meta[ $loop_id ]['total_pages']
								: 0,
						);
					}
				}

				// Post-expansion breadcrumbs (desktop.value already stripped).
				$pagination_id = isset( $loop_root['loop_pagination_id'] )
					? (string) $loop_root['loop_pagination_id']
					: '';
				$total_pages   = isset( $loop_root['loop_pagination_total_pages'] )
					? absint( $loop_root['loop_pagination_total_pages'] )
					: 0;
				if ( '' !== $pagination_id ) {
					if ( ! isset( $meta[ $pagination_id ] ) ) {
						$meta[ $pagination_id ] = array(
							'post_per_page' => 0,
							'post_offset'   => 0,
							'total_pages'   => 0,
						);
					}
					if ( $total_pages > 0 ) {
						$meta[ $pagination_id ]['total_pages'] = max(
							(int) $meta[ $pagination_id ]['total_pages'],
							$total_pages
						);
					}
				}
			}

			if ( ! empty( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ) {
				foreach ( self::collect_nested_loop_base_meta( $block['innerBlocks'] ) as $child_id => $child_meta ) {
					if ( ! isset( $meta[ $child_id ] ) ) {
						$meta[ $child_id ] = $child_meta;
						continue;
					}
					if ( (int) $child_meta['post_per_page'] > 0 ) {
						$meta[ $child_id ]['post_per_page'] = (int) $child_meta['post_per_page'];
					}
					$meta[ $child_id ]['post_offset'] = max(
						(int) $meta[ $child_id ]['post_offset'],
						(int) $child_meta['post_offset']
					);
					$meta[ $child_id ]['total_pages'] = max(
						(int) $meta[ $child_id ]['total_pages'],
						(int) $child_meta['total_pages']
					);
				}
			}
		}

		return $meta;
	}

	/**
	 * Inject Divi loop page params into $_GET for LoopUtils offset math.
	 *
	 * @param array<int, string> $loop_ids Loop IDs.
	 * @param int                $page     1-based page.
	 * @return array<string, mixed> Previous $_GET values keyed by loopId (for restore).
	 */
	public static function apply_loop_page_to_request( array $loop_ids, int $page ): array {
		$saved = array();
		$page  = max( 1, $page );

		foreach ( $loop_ids as $loop_id ) {
			if ( ! is_string( $loop_id ) || '' === $loop_id ) {
				continue;
			}
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Temporary request mutation for Divi LoopUtils.
			if ( ! array_key_exists( $loop_id, $_GET ) ) {
				$saved[ $loop_id ] = null;
			} else {
				// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Temporary request mutation for Divi LoopUtils.
				$saved[ $loop_id ] = sanitize_text_field( wp_unslash( $_GET[ $loop_id ] ) );
			}

			if ( $page <= 1 ) {
				// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Temporary request mutation for Divi LoopUtils.
				unset( $_GET[ $loop_id ] );
			} else {
				// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Temporary request mutation for Divi LoopUtils.
				$_GET[ $loop_id ] = (string) $page;
			}
		}

		return $saved;
	}

	/**
	 * Restore $_GET loop page params after a fragment render.
	 *
	 * @param array<string, mixed> $saved Previous values from apply_loop_page_to_request().
	 * @return void
	 */
	public static function restore_loop_page_request( array $saved ): void {
		foreach ( $saved as $loop_id => $value ) {
			if ( ! is_string( $loop_id ) || '' === $loop_id ) {
				continue;
			}
			if ( null === $value ) {
				// phpcs:ignore WordPress.Security.NonceVerification.Recommended
				unset( $_GET[ $loop_id ] );
			} else {
				// phpcs:ignore WordPress.Security.NonceVerification.Recommended
				$_GET[ $loop_id ] = $value;
			}
		}
	}

	/**
	 * Derive page / max_pages / has_more after a filtered loop render.
	 *
	 * Divi Loop paginates via offset (not WP `paged`), so max_num_pages alone
	 * can ignore the Loop’s base postOffset — we compute from found_posts + attrs.
	 * When found_posts is unavailable, prefer Divi’s loop_pagination_total_pages
	 * breadcrumb, then a full-page returned-count heuristic.
	 *
	 * @param array<int, string>                                                            $loop_ids          Loop IDs.
	 * @param array<string, array{post_per_page: int, post_offset: int, total_pages?: int}> $loop_base       Base meta.
	 * @param int                                                                           $page              Current page.
	 * @param int                                                                           $found_posts       Total found posts.
	 * @param int                                                                           $returned_fallback Items visible in markup when registry post_count is missing.
	 * @return array{page: int, max_pages: int, has_more: bool, posts_per_page: int, total_pages_hint: int}
	 */
	public static function resolve_pagination_state( array $loop_ids, array $loop_base, int $page, int $found_posts, int $returned_fallback = 0 ): array {
		$page             = max( 1, $page );
		$ppp              = 0;
		$base             = 0;
		$returned         = max( 0, $returned_fallback );
		$total_pages_hint = 0;

		foreach ( $loop_ids as $loop_id ) {
			if ( ! is_string( $loop_id ) || '' === $loop_id ) {
				continue;
			}
			if ( isset( $loop_base[ $loop_id ] ) ) {
				$candidate = (int) $loop_base[ $loop_id ]['post_per_page'];
				if ( $candidate > 0 && ( 0 === $ppp || $candidate < $ppp ) ) {
					$ppp = $candidate;
				}
				$base             = max( $base, (int) $loop_base[ $loop_id ]['post_offset'] );
				$total_pages_hint = max( $total_pages_hint, (int) ( $loop_base[ $loop_id ]['total_pages'] ?? 0 ) );
			}

			if ( class_exists( LoopQueryRegistry::class ) ) {
				$query = LoopQueryRegistry::get_query( $loop_id );
				if ( $query instanceof \WP_Query ) {
					$q_ppp = (int) $query->get( 'posts_per_page' );
					if ( $q_ppp > 0 && ( 0 === $ppp || $q_ppp < $ppp ) ) {
						$ppp = $q_ppp;
					}
					$returned = max( $returned, (int) $query->post_count );
				}
			}
		}

		if ( $ppp < 1 ) {
			$ppp = 10;
		}

		/*
		 * Prefer live found_posts. When unavailable:
		 * 1) Full-page returned items + Divi loop_pagination_total_pages hint
		 * 2) Full-page returned-count heuristic (Load more until empty HTML)
		 *
		 * Never use total_pages_hint when the current fragment returned 0 items —
		 * those breadcrumbs come from unfiltered SSR and keep stale pagination
		 * after an empty filter (e.g. “No Results Found” + pages 1–4).
		 */
		if ( $found_posts > 0 ) {
			$available = max( 0, $found_posts - $base );
			$max_pages = $available > 0 ? (int) ceil( $available / $ppp ) : 1;
			if ( $max_pages < 1 ) {
				$max_pages = 1;
			}
			$has_more = $page < $max_pages;
		} elseif ( $returned > 0 && $total_pages_hint > 0 ) {
			$max_pages = max( 1, $total_pages_hint );
			$has_more  = $page < $max_pages;
		} elseif ( $returned > 0 ) {
			$has_more  = $returned >= $ppp;
			$max_pages = $has_more ? $page + 1 : $page;
		} else {
			$max_pages = 1;
			$has_more  = false;
		}

		/**
		 * Filter Loop Filter pagination state after render.
		 *
		 * @param array<string, mixed> $state      Pagination state.
		 * @param array<int, string>         $loop_ids   Loop IDs.
		 * @param int                  $found_posts Found posts.
		 */
		$state = apply_filters(
			'dsm_loop_filter_pagination_state',
			array(
				'page'             => $page,
				'max_pages'        => $max_pages,
				'has_more'         => $has_more,
				'posts_per_page'   => $ppp,
				'total_pages_hint' => $total_pages_hint,
			),
			$loop_ids,
			$found_posts
		);

		return array(
			'page'             => max( 1, (int) ( $state['page'] ?? $page ) ),
			'max_pages'        => max( 1, (int) ( $state['max_pages'] ?? $max_pages ) ),
			'has_more'         => ! empty( $state['has_more'] ),
			'posts_per_page'   => max( 0, (int) ( $state['posts_per_page'] ?? $ppp ) ),
			'total_pages_hint' => max( 0, (int) ( $state['total_pages_hint'] ?? $total_pages_hint ) ),
		);
	}

	/**
	 * Count Divi loop item markers in rendered HTML.
	 *
	 * @param string $html Rendered fragment.
	 * @return int
	 */
	public static function count_loop_items_in_html( string $html ): int {
		if ( '' === $html ) {
			return 0;
		}

		return preg_match_all( '/\bdata-loop-item=/', $html );
	}

	/**
	 * Estimate a display count when live found_posts is unavailable.
	 *
	 * Never returns the historical floor of `1` when multiple items are visible —
	 * that made SSR show “1 result” and forced max_pages=1 when used as found_posts.
	 *
	 * @param int                  $returned          Items on the current page (markup / post_count).
	 * @param array<string, mixed> $paging            Pagination state from resolve_pagination_state().
	 * @param int                  $page              Current 1-based page.
	 * @return int
	 */
	public static function estimate_found_posts_for_display( int $returned, array $paging, int $page ): int {
		$ppp              = max( 1, (int) ( $paging['posts_per_page'] ?? 10 ) );
		$page             = max( 1, $page );
		$max_pages        = max( 1, (int) ( $paging['max_pages'] ?? 1 ) );
		$total_pages_hint = max( 0, (int) ( $paging['total_pages_hint'] ?? 0 ) );
		$has_more         = ! empty( $paging['has_more'] );

		if ( $returned < 1 ) {
			// No loop items — do not invent “1 result” (Divi no-results markup).
			return 0;
		}

		// Exact when this is the last (or only) page.
		if ( ! $has_more || $page >= $max_pages ) {
			return ( $page - 1 ) * $ppp + $returned;
		}

		// Divi total_pages breadcrumb: lower bound (prior pages full + ≥1 on last).
		$hint = $total_pages_hint > 0 ? $total_pages_hint : $max_pages;
		if ( $hint > 1 ) {
			return ( $hint - 1 ) * $ppp + 1;
		}

		return ( $page - 1 ) * $ppp + $returned;
	}

	/**
	 * Whether rendered HTML is Divi’s Loop “No Results Found” placeholder.
	 *
	 * Divi still emits markup (`.not-found-title` / “No Results Found”) when a
	 * filtered query has zero posts — that must not count as real results.
	 *
	 * @param string $html Rendered fragment.
	 * @return bool
	 */
	public static function html_is_divi_loop_no_results( string $html ): bool {
		$trimmed = trim( $html );
		if ( '' === $trimmed ) {
			return false;
		}

		if ( preg_match( '/\bnot-found-title\b/', $trimmed ) ) {
			return true;
		}

		$text = trim( wp_strip_all_tags( $trimmed ) );
		if ( '' === $text ) {
			return false;
		}

		return (bool) preg_match( '/\bno[\s-]*results?\s+found\b/i', $text );
	}

	/**
	 * Whether rendered loop HTML is effectively empty (no loop items / media).
	 *
	 * Treats Divi’s “No Results Found” placeholder as empty even though it
	 * contains text nodes.
	 *
	 * @param string $html Rendered fragment.
	 * @return bool
	 */
	public static function is_effectively_empty_html( string $html ): bool {
		$trimmed = trim( $html );
		if ( '' === $trimmed ) {
			return true;
		}

		$loop_items = self::count_loop_items_in_html( $trimmed );

		// Divi no-results placeholder (no data-loop-item clones).
		if ( $loop_items < 1 && self::html_is_divi_loop_no_results( $trimmed ) ) {
			return true;
		}

		// Image/SVG-only loop cards still count as results.
		if ( preg_match( '/<(img|video|iframe|svg)\b/i', $trimmed ) ) {
			return false;
		}

		return '' === trim( wp_strip_all_tags( $trimmed ) );
	}

	/**
	 * Collect Divi loopIds from nested blocks (depth-first).
	 *
	 * Prefers live `desktop.value.loopId` while Loop is still enabled. After
	 * Divi expands a loop (`LoopUtils::_process_single_loop_block`), that
	 * object is unset and only pagination breadcrumbs remain on the first
	 * duplicate (`loop_pagination_id`) — FE SSR of Loop Filter sees that shape.
	 *
	 * @param array<int, array<string, mixed>> $blocks Blocks.
	 * @return list<string>
	 */
	public static function collect_nested_loop_ids( array $blocks ): array {
		$ids = array();

		foreach ( $blocks as $block ) {
			if ( ! is_array( $block ) ) {
				continue;
			}

			$loop_root = $block['attrs']['module']['advanced']['loop'] ?? null;
			if ( is_array( $loop_root ) ) {
				$loop_value = $loop_root['desktop']['value'] ?? null;
				if ( is_array( $loop_value ) ) {
					$enabled = isset( $loop_value['enable'] ) ? (string) $loop_value['enable'] : '';
					$loop_id = isset( $loop_value['loopId'] ) ? (string) $loop_value['loopId'] : '';
					if ( 'on' === $enabled && '' !== $loop_id ) {
						$ids[] = $loop_id;
					}
				}

				// Post-expansion breadcrumb (enable/loopId already stripped).
				$pagination_id = isset( $loop_root['loop_pagination_id'] )
					? (string) $loop_root['loop_pagination_id']
					: '';
				if ( '' !== $pagination_id ) {
					$ids[] = $pagination_id;
				}
			}

			if ( ! empty( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ) {
				$ids = array_merge( $ids, self::collect_nested_loop_ids( $block['innerBlocks'] ) );
			}
		}

		return array_values( array_unique( $ids ) );
	}

	/**
	 * Sum found_posts for the given loopIds (live WP_Query properties).
	 *
	 * @param array<int, string> $loop_ids Loop IDs.
	 * @return int
	 */
	public static function sum_found_posts_for_loop_ids( array $loop_ids ): int {
		return self::resolve_found_posts_from_registry( $loop_ids );
	}

	/**
	 * Sum found_posts from observed / provided loop IDs in the registry.
	 *
	 * Reads live WP_Query::$found_posts — Divi's get_query_metadata()
	 * "found_posts" value is unreliable (always 0; see store()).
	 *
	 * @param array<int, string>|null $prefer_loop_ids Preferred loop IDs.
	 * @return int
	 */
	private static function resolve_found_posts_from_registry( ?array $prefer_loop_ids = null ): int {
		if ( ! class_exists( LoopQueryRegistry::class ) ) {
			return 0;
		}

		$total = 0;
		$seen  = array();

		if ( is_array( $prefer_loop_ids ) && ! empty( $prefer_loop_ids ) ) {
			$loop_ids = $prefer_loop_ids;
		} elseif ( ! empty( self::$observed_loop_ids ) ) {
			$loop_ids = self::$observed_loop_ids;
		} else {
			$loop_ids = LoopQueryRegistry::get_all_loop_ids();
		}

		foreach ( $loop_ids as $loop_id ) {
			if ( ! is_string( $loop_id ) || '' === $loop_id || isset( $seen[ $loop_id ] ) ) {
				continue;
			}
			$seen[ $loop_id ] = true;

			/*
			 * Prefer get_query() over has_query(): Divi can predictively rebuild
			 * a missing registry entry (same path as core Loop pagination).
			 * Always read the live WP_Query::$found_posts property — store()
			 * metadata uses method_exists('found_posts') and stays 0.
			 */
			$query = LoopQueryRegistry::get_query( $loop_id );
			if ( $query instanceof \WP_Query ) {
				$fp = (int) $query->found_posts;
				if ( $fp > 0 ) {
					$total += $fp;
				}
				continue;
			}

			if ( $query instanceof \WP_User_Query ) {
				$total += (int) $query->get_total();
				continue;
			}

			if ( $query instanceof \WP_Term_Query && is_array( $query->terms ) ) {
				$total += count( $query->terms );
			}
		}

		return $total;
	}

	/**
	 * Find the Nth `dsm/loop-filter` block in serialized content.
	 *
	 * @param string $content Post content.
	 * @param int    $index   Zero-based occurrence index.
	 * @return array<string, mixed>|null
	 */
	public static function find_nth_loop_filter_block( string $content, int $index ): ?array {
		if ( $index < 0 || '' === $content || ! function_exists( 'parse_blocks' ) ) {
			return null;
		}

		$blocks = parse_blocks( $content );
		$cursor = 0;

		return self::walk_blocks_for_loop_filter( $blocks, $index, $cursor );
	}

	/**
	 * Depth-first walk for the Nth loop-filter block.
	 *
	 * @param array<int, array<string, mixed>> $blocks Blocks.
	 * @param int                              $index  Target index.
	 * @param int                              $cursor Current count (by ref).
	 * @return array<string, mixed>|null
	 */
	private static function walk_blocks_for_loop_filter( array $blocks, int $index, int &$cursor ): ?array {
		foreach ( $blocks as $block ) {
			if ( ! is_array( $block ) ) {
				continue;
			}

			if ( ( $block['blockName'] ?? '' ) === 'dsm/loop-filter' ) {
				if ( $cursor === $index ) {
					return $block;
				}
				++$cursor;
			}

			if ( ! empty( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ) {
				$found = self::walk_blocks_for_loop_filter( $block['innerBlocks'], $index, $cursor );
				if ( null !== $found ) {
					return $found;
				}
			}
		}

		return null;
	}

	/**
	 * Resolve the post that stores the Loop Filter module markup.
	 *
	 * @param int $layout_id Layout / page / TB template post ID.
	 * @return WP_Post|null
	 */
	public static function resolve_module_source_post( int $layout_id ): ?WP_Post {
		if ( $layout_id < 1 ) {
			return null;
		}

		$post = get_post( $layout_id );
		if ( ! $post instanceof WP_Post ) {
			return null;
		}

		if ( false === strpos( (string) $post->post_content, 'dsm/loop-filter' ) ) {
			return null;
		}

		return $post;
	}

	/**
	 * Fallback: find a Theme Builder / library layout that contains a Loop Filter.
	 *
	 * Used when the FE could not supply a valid layout_id (e.g. older markup).
	 * Prefer `layout_id` from the module data attribute — scanning is best-effort.
	 *
	 * @param int $index Zero-based occurrence within that layout.
	 * @return WP_Post|null
	 */
	private static function find_layout_post_containing_loop_filter( int $index ): ?WP_Post {
		global $wpdb;

		$post_types = array( 'et_pb_layout' );
		if ( function_exists( 'et_theme_builder_get_layout_post_types' ) ) {
			$post_types = array_merge( et_theme_builder_get_layout_post_types(), $post_types );
		} else {
			$post_types = array_merge(
				array( 'et_header_layout', 'et_body_layout', 'et_footer_layout' ),
				$post_types
			);
		}

		/**
		 * Filter post types scanned when resolving a Loop Filter outside the current post.
		 *
		 * @param array<int, string> $post_types Post types.
		 */
		$post_types = apply_filters( 'dsm_loop_filter_layout_post_types', $post_types );
		if ( ! is_array( $post_types ) || empty( $post_types ) ) {
			return null;
		}

		$post_types = array_values( array_unique( array_map( 'sanitize_key', $post_types ) ) );
		$in_list    = "'" . implode( "','", array_map( 'esc_sql', $post_types ) ) . "'";

		$like = '%' . $wpdb->esc_like( 'dsm/loop-filter' ) . '%';

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Post type list is sanitized above.
		$sql = "SELECT ID FROM {$wpdb->posts}
			WHERE post_type IN ({$in_list})
			AND post_status IN ('publish','private')
			AND post_content LIKE %s
			ORDER BY post_modified DESC
			LIMIT 25";

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Placeholder applied via prepare below.
		$ids = $wpdb->get_col( $wpdb->prepare( $sql, $like ) );
		if ( ! is_array( $ids ) || empty( $ids ) ) {
			return null;
		}

		foreach ( $ids as $candidate_id ) {
			$candidate = get_post( (int) $candidate_id );
			if ( ! $candidate instanceof WP_Post ) {
				continue;
			}
			if ( null !== self::find_nth_loop_filter_block( (string) $candidate->post_content, $index ) ) {
				return $candidate;
			}
		}

		return null;
	}

	/**
	 * Parse per-instance filter state from the current request.
	 *
	 * @return list<array{layout_id: int, index: int, filters: array<string, mixed>}>
	 */
	private static function parse_filter_instances_from_request(): array {
		$instances = array();

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Public filter URL state.
		$get = isset( $_GET ) && is_array( $_GET ) ? $_GET : array();

		foreach ( array_keys( $get ) as $raw_key ) {
			$key = sanitize_key( (string) $raw_key );
			if ( ! preg_match( '/^dsm_lf_(\d+)_(\d+)_(s|tax|terms|tq|orderby|order|author|date_from|date_to|min_price|max_price|price_ranges|rating|stock|mq)$/', $key, $m ) ) {
				continue;
			}
			$layout_id = (int) $m[1];
			$index     = (int) $m[2];
			$slot      = $layout_id . '_' . $index;
			if ( ! isset( $instances[ $slot ] ) ) {
				$instances[ $slot ] = array(
					'layout_id' => $layout_id,
					'index'     => $index,
					'filters'   => array(
						'search'             => '',
						'taxonomy'           => '',
						'terms'              => array(),
						'tax_queries'        => array(),
						'tax_query_relation' => 'AND',
						'orderby'            => '',
						'order'              => 'DESC',
						'author'             => 0,
						'date_from'          => '',
						'date_to'            => '',
						'min_price'          => '',
						'max_price'          => '',
						'price_ranges'       => array(),
						'rating'             => 0,
						'stock_status'       => '',
						'meta_queries'       => array(),
					),
				);
			}
		}

		foreach ( $instances as $slot => $instance ) {
			$prefix = 'dsm_lf_' . $instance['layout_id'] . '_' . $instance['index'];
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Public filter URL state.
			$search = isset( $get[ $prefix . '_s' ] ) ? sanitize_text_field( wp_unslash( (string) $get[ $prefix . '_s' ] ) ) : '';
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Public filter URL state.
			$taxonomy = isset( $get[ $prefix . '_tax' ] ) ? sanitize_key( wp_unslash( (string) $get[ $prefix . '_tax' ] ) ) : '';
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Public filter URL state.
			$terms_raw = isset( $get[ $prefix . '_terms' ] ) ? sanitize_text_field( wp_unslash( (string) $get[ $prefix . '_terms' ] ) ) : '';
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Public filter URL state.
			$tq_raw = isset( $get[ $prefix . '_tq' ] ) ? sanitize_text_field( wp_unslash( (string) $get[ $prefix . '_tq' ] ) ) : '';
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Public filter URL state.
			$orderby = isset( $get[ $prefix . '_orderby' ] ) ? sanitize_key( wp_unslash( (string) $get[ $prefix . '_orderby' ] ) ) : '';
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Public filter URL state.
			$order = isset( $get[ $prefix . '_order' ] ) ? sanitize_text_field( wp_unslash( (string) $get[ $prefix . '_order' ] ) ) : 'DESC';
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Public filter URL state.
			$author_raw = isset( $get[ $prefix . '_author' ] ) ? wp_unslash( (string) $get[ $prefix . '_author' ] ) : '';
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Public filter URL state.
			$date_from_raw = isset( $get[ $prefix . '_date_from' ] ) ? wp_unslash( (string) $get[ $prefix . '_date_from' ] ) : '';
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Public filter URL state.
			$date_to_raw = isset( $get[ $prefix . '_date_to' ] ) ? wp_unslash( (string) $get[ $prefix . '_date_to' ] ) : '';
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Public filter URL state.
			$min_price_raw = isset( $get[ $prefix . '_min_price' ] ) ? wp_unslash( (string) $get[ $prefix . '_min_price' ] ) : '';
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Public filter URL state.
			$max_price_raw = isset( $get[ $prefix . '_max_price' ] ) ? wp_unslash( (string) $get[ $prefix . '_max_price' ] ) : '';
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Public filter URL state.
			$price_ranges_raw = isset( $get[ $prefix . '_price_ranges' ] ) ? wp_unslash( (string) $get[ $prefix . '_price_ranges' ] ) : '';
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Public filter URL state.
			$rating_raw = isset( $get[ $prefix . '_rating' ] ) ? wp_unslash( (string) $get[ $prefix . '_rating' ] ) : '';
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Public filter URL state.
			$stock_raw = isset( $get[ $prefix . '_stock' ] ) ? wp_unslash( (string) $get[ $prefix . '_stock' ] ) : '';
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Public filter URL state.
			$mq_raw = isset( $get[ $prefix . '_mq' ] ) ? wp_unslash( (string) $get[ $prefix . '_mq' ] ) : '';

			$terms = array();
			if ( '' !== $terms_raw ) {
				foreach ( explode( ',', $terms_raw ) as $term_slug ) {
					$term_slug = sanitize_title( $term_slug );
					if ( '' !== $term_slug ) {
						$terms[] = $term_slug;
					}
				}
			}

			$tax_queries = self::parse_tax_queries_url_param( $tq_raw );
			if ( empty( $tax_queries ) && '' !== $taxonomy && ! empty( $terms ) ) {
				$tax_queries = self::normalize_tax_queries(
					array(
						array(
							'taxonomy' => $taxonomy,
							'terms'    => $terms,
						),
					)
				);
			}

			$instances[ $slot ]['filters'] = array(
				'search'             => $search,
				'taxonomy'           => ! empty( $tax_queries ) ? (string) $tax_queries[0]['taxonomy'] : self::sanitize_public_taxonomy( $taxonomy ),
				'terms'              => ! empty( $tax_queries ) ? $tax_queries[0]['terms'] : $terms,
				'tax_queries'        => $tax_queries,
				'tax_query_relation' => 'AND',
				'orderby'            => self::sanitize_orderby( $orderby ),
				'order'              => self::sanitize_order( $order ),
				'author'             => self::sanitize_author_id( $author_raw ),
				'date_from'          => self::sanitize_date_ymd( $date_from_raw ),
				'date_to'            => self::sanitize_date_ymd( $date_to_raw ),
				'min_price'          => self::is_woocommerce_active() ? self::sanitize_price_value( $min_price_raw ) : '',
				'max_price'          => self::is_woocommerce_active() ? self::sanitize_price_value( $max_price_raw ) : '',
				'price_ranges'       => self::is_woocommerce_active() ? self::sanitize_price_ranges( $price_ranges_raw ) : array(),
				'rating'             => self::is_woocommerce_active() ? self::sanitize_rating_min( $rating_raw ) : 0,
				'stock_status'       => self::is_woocommerce_active() ? self::sanitize_stock_status( $stock_raw ) : '',
				'meta_queries'       => self::parse_meta_queries_url_param( $mq_raw ),
			);
		}

		// Legacy single-instance keys (pre-hardening).
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Public filter URL state.
		if ( isset( $get['dsm_lf'] ) && empty( $instances ) ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Public filter URL state.
			$legacy_index = absint( wp_unslash( (string) $get['dsm_lf'] ) );
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Public filter URL state.
			$search = isset( $get['dsm_lf_s'] ) ? sanitize_text_field( wp_unslash( (string) $get['dsm_lf_s'] ) ) : '';
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Public filter URL state.
			$taxonomy = isset( $get['dsm_lf_tax'] ) ? sanitize_key( wp_unslash( (string) $get['dsm_lf_tax'] ) ) : '';
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Public filter URL state.
			$terms_raw = isset( $get['dsm_lf_terms'] ) ? sanitize_text_field( wp_unslash( (string) $get['dsm_lf_terms'] ) ) : '';
			$terms     = array();
			if ( '' !== $terms_raw ) {
				foreach ( explode( ',', $terms_raw ) as $term_slug ) {
					$term_slug = sanitize_title( $term_slug );
					if ( '' !== $term_slug ) {
						$terms[] = $term_slug;
					}
				}
			}

			$layout_id = 0;
			if ( class_exists( '\ET\Builder\FrontEnd\Module\Style' ) ) {
				$layout_id = (int) \ET\Builder\FrontEnd\Module\Style::get_layout_id();
			}
			if ( $layout_id < 1 ) {
				$layout_id = (int) get_queried_object_id();
			}

			$legacy_tax_queries = self::normalize_tax_queries(
				array(
					array(
						'taxonomy' => $taxonomy,
						'terms'    => $terms,
					),
				)
			);

			$instances[ $layout_id . '_' . $legacy_index ] = array(
				'layout_id' => $layout_id,
				'index'     => $legacy_index,
				'filters'   => array(
					'search'       => $search,
					'taxonomy'     => self::sanitize_public_taxonomy( $taxonomy ),
					'terms'        => $terms,
					'tax_queries'  => $legacy_tax_queries,
					'orderby'      => '',
					'order'        => 'DESC',
					'author'       => 0,
					'date_from'    => '',
					'date_to'      => '',
					'min_price'    => '',
					'max_price'    => '',
					'price_ranges' => array(),
					'rating'       => 0,
					'stock_status' => '',
					'meta_queries' => array(),
				),
			);
		}

		return array_values( $instances );
	}

	/**
	 * Parse `_tq` URL param: `tax:term+term;tax2:term`.
	 *
	 * @param string $raw Raw param.
	 * @return list<array{taxonomy: string, terms: list<string>, relation: string}>
	 */
	public static function parse_tax_queries_url_param( string $raw ): array {
		$raw = trim( $raw );
		if ( '' === $raw ) {
			return array();
		}

		$groups = array();
		foreach ( explode( ';', $raw ) as $chunk ) {
			$chunk = trim( $chunk );
			if ( '' === $chunk || false === strpos( $chunk, ':' ) ) {
				continue;
			}
			list( $taxonomy, $terms_part ) = array_pad( explode( ':', $chunk, 2 ), 2, '' );
			$terms                         = array();
			foreach ( explode( '+', (string) $terms_part ) as $term_slug ) {
				$term_slug = sanitize_title( $term_slug );
				if ( '' !== $term_slug ) {
					$terms[] = $term_slug;
				}
			}
			$groups[] = array(
				'taxonomy' => sanitize_key( (string) $taxonomy ),
				'terms'    => $terms,
			);
		}

		return self::normalize_tax_queries( $groups );
	}

	/**
	 * Encode tax queries for the `_tq` URL param.
	 *
	 * @param array<int, array{taxonomy: string, terms: list<string>, relation?: string}> $tax_queries Tax groups.
	 * @return string
	 */
	public static function encode_tax_queries_url_param( array $tax_queries ): string {
		$chunks = array();
		foreach ( $tax_queries as $group ) {
			if ( ! is_array( $group ) ) {
				continue;
			}
			$taxonomy = isset( $group['taxonomy'] ) ? sanitize_key( (string) $group['taxonomy'] ) : '';
			$terms    = isset( $group['terms'] ) && is_array( $group['terms'] ) ? $group['terms'] : array();
			$clean    = array();
			foreach ( $terms as $term ) {
				if ( is_string( $term ) || is_numeric( $term ) ) {
					$slug = sanitize_title( (string) $term );
					if ( '' !== $slug ) {
						$clean[] = $slug;
					}
				}
			}
			if ( '' === $taxonomy || empty( $clean ) ) {
				continue;
			}
			$chunks[] = $taxonomy . ':' . implode( '+', $clean );
		}

		return implode( ';', $chunks );
	}

	/**
	 * Whether the request already carries Divi loop pagination for any of the loopIds.
	 *
	 * @param array<int, string> $loop_ids Loop IDs.
	 * @return bool
	 */
	private static function request_has_loop_page_param( array $loop_ids ): bool {
		foreach ( $loop_ids as $loop_id ) {
			if ( ! is_string( $loop_id ) || '' === $loop_id ) {
				continue;
			}
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Pagination URL state.
			if ( isset( $_GET[ $loop_id ] ) && absint( wp_unslash( $_GET[ $loop_id ] ) ) > 1 ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Whether the post can be read by the current visitor.
	 *
	 * @param WP_Post $post Post.
	 * @return bool
	 */
	private function is_post_publicly_readable( WP_Post $post ): bool {
		$layout_types = function_exists( 'et_theme_builder_get_layout_post_types' )
			? et_theme_builder_get_layout_post_types()
			: array( 'et_header_layout', 'et_body_layout', 'et_footer_layout' );

		$is_layout = in_array( $post->post_type, $layout_types, true )
			|| ( defined( 'ET_BUILDER_LAYOUT_POST_TYPE' ) && ET_BUILDER_LAYOUT_POST_TYPE === $post->post_type )
			|| 'et_pb_layout' === $post->post_type;

		if ( $is_layout ) {
			// Theme Builder / library layouts are not singular public posts; allow published/private for render.
			return in_array( $post->post_status, array( 'publish', 'private' ), true )
				|| current_user_can( 'read_post', $post->ID );
		}

		if ( 'publish' === $post->post_status ) {
			return true;
		}

		return current_user_can( 'read_post', $post->ID );
	}

	/**
	 * Per-IP rate limit for public loop-filter REST.
	 *
	 * @return true|WP_Error
	 */
	private static function check_rate_limit() {
		$ip   = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( (string) $_SERVER['REMOTE_ADDR'] ) ) : 'unknown';
		$key  = 'dsm_lf_rl_' . md5( $ip );
		$hits = (int) get_transient( $key );

		/**
		 * Filter max Loop Filter REST requests per minute per IP.
		 *
		 * @param int $max Maximum hits.
		 */
		$max = (int) apply_filters( 'dsm_loop_filter_rest_rate_limit', 60 );
		if ( $max < 5 ) {
			$max = 5;
		}

		if ( $hits >= $max ) {
			return new WP_Error(
				'dsm_loop_filter_rate_limited',
				__( 'Too many filter requests. Please wait a moment.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 429 )
			);
		}

		set_transient( $key, $hits + 1, MINUTE_IN_SECONDS );

		return true;
	}
}
