<?php
/**
 * Image Parallax — SSR markers on `<img>` for simpleParallax.js frontend runtime.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Extensions;

/**
 * Tags rendered `<img>` elements when a matching field has Image Parallax enabled.
 */
final class ImageParallax {


	private const SCRIPT_HANDLE = 'dsm-image-parallax-frontend';

	private const STYLE_HANDLE = 'dsm-image-parallax-frontend';

	/**
	 * Default orientation for simpleParallax.js.
	 *
	 * @see https://github.com/geosigno/simpleParallax.js/#settings
	 */
	private const DEFAULT_ORIENTATION = 'up';

	/**
	 * Set up the instance.
	 *
	 * @return void
	 */
	public function __construct() {
		add_filter( 'render_block', array( $this, 'filter_render_block' ), 22, 2 );
	}

	/**
	 * Read native parallax fields.
	 *
	 * @param array<string,mixed> $attrs Block attrs.
	 * @return array<string,array<string,mixed>>
	 */
	private static function read_native_parallax_fields( array $attrs ): array {
		/**
		 * Value.
		 *
		 * @var array<string,array<string,mixed>> $out
		 */
		$out = array();

		foreach ( $attrs as $attr_key => $node ) {
			if ( ! is_string( $attr_key ) || ! str_starts_with( $attr_key, 'dsm_ipx_' ) ) {
				continue;
			}

			if ( 'dsm_ipx_fields' === $attr_key ) {
				continue;
			}

			if ( ! is_array( $node ) ) {
				continue;
			}

			$inner = $node['innerContent'] ?? null;

			if ( ! is_array( $inner ) ) {
				continue;
			}

			$desktop = $inner['desktop'] ?? null;

			if ( ! is_array( $desktop ) ) {
				continue;
			}

			$value = $desktop['value'] ?? null;

			if ( ! is_array( $value ) ) {
				continue;
			}

			$field_key = substr( $attr_key, strlen( 'dsm_ipx_' ) );

			if ( '' === $field_key ) {
				continue;
			}

			$out[ $field_key ] = $value;
		}

		return $out;
	}

	/**
	 * Read fields registry.
	 *
	 * @param array<string,mixed> $attrs Block attrs.
	 * @return array<string,array<string,mixed>>
	 */
	private static function read_fields_registry( array $attrs ): array {
		/**
		 * Value.
		 *
		 * @var array<string,array<string,mixed>> $out
		 */
		$out = self::read_native_parallax_fields( $attrs );

		$node = $attrs['dsm_ipx_fields'] ?? null;

		if ( ! is_array( $node ) ) {
			return $out;
		}

		$inner = $node['innerContent'] ?? null;

		if ( ! is_array( $inner ) ) {
			return $out;
		}

		$desktop = $inner['desktop'] ?? null;

		if ( ! is_array( $desktop ) ) {
			return $out;
		}

		$value = $desktop['value'] ?? null;

		if ( ! is_array( $value ) ) {
			return $out;
		}

		foreach ( $value as $field_key => $raw ) {
			if ( ! is_string( $field_key ) || '' === $field_key || ! is_array( $raw ) ) {
				continue;
			}

			if ( ! isset( $out[ $field_key ] ) ) {
				$out[ $field_key ] = $raw;
			}
		}

		return $out;
	}

	/**
	 * Is parallax eligible block.
	 *
	 * @param string $block_name Block name from parsed block.
	 */
	private static function is_parallax_eligible_block( string $block_name ): bool {
		if ( '' === $block_name ) {
			return false;
		}

		if (
			! str_starts_with( $block_name, 'divi/' )
			&& ! str_starts_with( $block_name, 'dsm/' )
		) {
			return false;
		}

		return ! in_array(
			$block_name,
			array(
				'divi/section',
				'divi/row',
				'divi/row-inner',
				'divi/column',
				'divi/column-inner',
			),
			true
		);
	}

	/**
	 * Enqueue frontend assets.
	 *
	 * @return void
	 */
	private static function enqueue_frontend_assets(): void {
		if ( wp_script_is( self::SCRIPT_HANDLE, 'registered' )
			&& ! wp_script_is( self::SCRIPT_HANDLE, 'enqueued' ) ) {
			wp_enqueue_script( self::SCRIPT_HANDLE );
		}

		if ( wp_style_is( self::STYLE_HANDLE, 'registered' )
			&& ! wp_style_is( self::STYLE_HANDLE, 'enqueued' ) ) {
			wp_enqueue_style( self::STYLE_HANDLE );
		}
	}

	/**
	 * Field is enabled.
	 *
	 * @param array<string,mixed> $raw Raw.
	 */
	private static function field_is_enabled( array $raw ): bool {
		return isset( $raw['on'] ) && 'on' === strtolower( (string) $raw['on'] );
	}

	/**
	 * Normalize field config.
	 *
	 * @param array<string,mixed> $raw Raw.
	 * @return array<string,mixed>
	 */
	private static function normalize_field_config( array $raw ): array {
		$orientations = array(
			'up',
			'right',
			'down',
			'left',
			'up left',
			'up right',
			'down left',
			'down right',
		);

		$orientation = strtolower(
			trim( (string) ( $raw['orientation'] ?? self::DEFAULT_ORIENTATION ) )
		);

		if ( ! in_array( $orientation, $orientations, true ) ) {
			$orientation = self::DEFAULT_ORIENTATION;
		}

		$scale = (float) ( $raw['scale'] ?? 1.3 );

		if ( $scale <= 1 ) {
			$scale = 1.3;
		}

		$delay = (float) ( $raw['delay'] ?? 0 );

		if ( $delay < 0 ) {
			$delay = 0;
		}

		$max_transition = (float) ( $raw['maxTransition'] ?? 0 );

		/**
		 * Value.
		 *
		 * @var array<string,mixed> $opts
		 */
		$opts = array(
			'orientation' => $orientation,
			'scale'       => $scale,
			'delay'       => $delay,
			'overflow'    => isset( $raw['overflow'] ) && 'on' === strtolower( (string) $raw['overflow'] ),
		);

		$transition = trim( (string) ( $raw['transition'] ?? '' ) );

		if ( 'default' === strtolower( $transition ) ) {
			$transition = '';
		}

		if ( '' !== $transition ) {
			$opts['transition'] = $transition;
		}

		if ( $max_transition >= 1 && $max_transition <= 99 ) {
			$opts['maxTransition'] = $max_transition;
		}

		return $opts;
	}

	/**
	 * Tag images in content.
	 *
	 * @param string              $content  Block HTML.
	 * @param array<string,mixed> $registry Enabled field configs keyed by field slug.
	 * @return string
	 */
	private function tag_images_in_content( string $content, array $registry ): string {
		if ( '' === trim( $content ) || ! class_exists( 'DOMDocument' ) ) {
			return $content;
		}

		$doc = new \DOMDocument();

		if ( function_exists( 'libxml_use_internal_errors' ) ) {
			libxml_use_internal_errors( true );
		}

		$wrapped = '<div id="dsm-ipx-root">' . $content . '</div>';

		$loaded = $doc->loadHTML(
			'<?xml encoding="utf-8" ?>' . $wrapped,
			LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD
		);

		if ( function_exists( 'libxml_clear_errors' ) ) {
			libxml_clear_errors();
		}

		if ( ! $loaded ) {
			return $content;
		}

		/**
		 * Value.
		 *
		 * @var \DOMElement|null $root
		 */
		$root = $doc->getElementById( 'dsm-ipx-root' );

		if ( ! ( $root instanceof \DOMElement ) ) {
			return $content;
		}

		$images = $root->getElementsByTagName( 'img' );

		if ( 0 === $images->length ) {
			return $content;
		}

		$field_keys = array_keys( $registry );
		$index      = 0;

		foreach ( $images as $img ) {
			if ( ! ( $img instanceof \DOMElement ) ) {
				continue;
			}

			if ( $img->hasAttribute( 'data-dsm-ipx-on' ) ) {
				continue;
			}

			$field_key = $field_keys[ $index ] ?? $field_keys[0] ?? '';

			if ( '' === $field_key || ! isset( $registry[ $field_key ] ) ) {
				continue;
			}

			$raw = $registry[ $field_key ];

			if ( ! self::field_is_enabled( $raw ) ) {
				++$index;

				continue;
			}

			$opts = self::normalize_field_config( $raw );

			$img->setAttribute( 'data-dsm-ipx-on', '1' );
			$img->setAttribute( 'data-dsm-ipx-field', $field_key );
			$img->setAttribute(
				'data-dsm-ipx-opts',
				(string) wp_json_encode( $opts )
			);

			self::enqueue_frontend_assets();

			++$index;
		}

		$html = '';

		foreach ( $root->childNodes as $child ) { // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- External object property.
			$html .= $doc->saveHTML( $child );
		}

		return $html;
	}

	/**
	 * Filter render block.
	 *
	 * @param string                           $block_content HTML.
	 * @param array<string,mixed>|array<mixed> $block         Parsed block.
	 */
	public function filter_render_block( $block_content, $block ): string {
		if (
			! function_exists( 'dsm_is_image_parallax_extension_enabled' )
			|| ! dsm_is_image_parallax_extension_enabled()
			|| ! function_exists( 'et_builder_d5_enabled' )
			|| ! et_builder_d5_enabled()
		) {
			return is_string( $block_content ) ? $block_content : '';
		}

		if ( ! is_string( $block_content ) || '' === trim( $block_content ) ) {
			return is_string( $block_content ) ? $block_content : '';
		}

		if ( ! is_array( $block ) ) {
			return $block_content;
		}

		$block_name = isset( $block['blockName'] ) ? (string) $block['blockName'] : '';

		if ( ! self::is_parallax_eligible_block( $block_name ) ) {
			return $block_content;
		}

		$attrs = isset( $block['attrs'] ) && is_array( $block['attrs'] )
			? $block['attrs']
			: array();

		$registry = self::read_fields_registry( $attrs );

		/**
		 * Value.
		 *
		 * @var array<string,array<string,mixed>> $enabled
		 */
		$enabled = array();

		foreach ( $registry as $field_key => $raw ) {
			if ( self::field_is_enabled( $raw ) ) {
				$enabled[ $field_key ] = $raw;
			}
		}

		if ( array() === $enabled ) {
			return $block_content;
		}

		return $this->tag_images_in_content( $block_content, $enabled );
	}
}

new ImageParallax();
