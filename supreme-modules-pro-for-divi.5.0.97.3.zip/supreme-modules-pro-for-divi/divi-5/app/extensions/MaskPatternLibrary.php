<?php
/**
 * Mask + Pattern library extension bootstrap.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Extensions;

use DiviSupreme\Extensions\MaskPatternLibrary\MaskPatternLibraryBridge;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

require_once DSM_DIR_PATH . 'divi-5/app/extensions/MaskPatternLibrary/MaskPatternEntryBuilder.php';
require_once DSM_DIR_PATH . 'divi-5/app/extensions/MaskPatternLibrary/MaskPatternRegistry.php';
require_once DSM_DIR_PATH . 'divi-5/app/extensions/MaskPatternLibrary/MaskPatternLibraryBridge.php';

/**
 * Divi Supreme Pro custom background masks and patterns for Divi 5.
 */
class MaskPatternLibrary {

	/**
	 * Constructor.
	 */
	public function __construct() {
		MaskPatternLibraryBridge::register();
	}
}
