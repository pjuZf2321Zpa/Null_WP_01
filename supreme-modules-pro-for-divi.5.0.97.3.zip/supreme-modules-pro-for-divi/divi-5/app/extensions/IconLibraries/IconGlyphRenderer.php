<?php
/**
 * SSR webfont glyph markup for the render bridge.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Extensions\IconLibraries;

use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Renders `<i class="…">` glyphs and `.et-pb-icon` hosts for the render bridge.
 */
final class IconGlyphRenderer {

	/**
	 * Resolve webfont CSS classes for a stored icon value.
	 *
	 * @param array<string, mixed> $icon_settings Icon picker leaf.
	 * @return string
	 */
	public static function get_font_class_for_icon( array $icon_settings ): string {
		if ( ! ExtensionSettings::is_extension_enabled() ) {
			return '';
		}

		if ( ! IconLibraryRegistry::is_dsm_library_icon( $icon_settings ) ) {
			return '';
		}

		$library_id = sanitize_key( (string) ( $icon_settings['type'] ?? '' ) );
		$icon_id    = IconLibraryRegistry::resolve_stored_icon_slug(
			$library_id,
			(string) ( $icon_settings['unicode'] ?? '' )
		);
		$library    = IconLibraryRegistry::get( $library_id );

		if ( null === $library || '' === $icon_id ) {
			return '';
		}

		$variant = WebfontAssetLoader::normalize_variant(
			$library_id,
			IconLibraryRegistry::resolve_variant_from_icon( $icon_settings )
		);

		return $library->get_picker_font_class( $icon_id, $variant );
	}

	/**
	 * Whether icon settings represent a native Divi / Font Awesome font icon.
	 *
	 * @param array<string, mixed>|null $icon_settings Icon picker leaf.
	 * @return bool
	 */
	public static function is_native_font_icon( ?array $icon_settings ): bool {
		if ( ! is_array( $icon_settings ) || IconLibraryRegistry::is_dsm_library_icon( $icon_settings ) ) {
			return false;
		}

		return '' !== sanitize_key( (string) ( $icon_settings['unicode'] ?? '' ) );
	}

	/**
	 * Resolve ETmodules / Font Awesome family for a native icon leaf.
	 *
	 * @param array<string, mixed> $icon_settings Icon picker leaf.
	 * @return string
	 */
	public static function get_native_font_family( array $icon_settings ): string {
		if ( IconProcessFontIconBridge::uses_icon_manager_font_family() ) {
			$family = self::icon_manager_font_family( $icon_settings );

			if ( '' !== $family ) {
				return $family;
			}
		}

		$type = sanitize_key( (string) ( $icon_settings['type'] ?? 'divi' ) );

		return 'fa' === $type ? 'FontAwesome' : 'ETmodules';
	}

	/**
	 * Render `<i class="dsm-native-icon-glyph">` for Divi / FA font icons.
	 *
	 * @param array<string, mixed> $icon_settings Icon picker leaf.
	 * @param string[]             $extra_classes Additional CSS classes.
	 * @return string
	 */
	public static function render_native_glyph_markup( array $icon_settings, array $extra_classes = array() ): string {
		if ( ! ExtensionSettings::is_extension_enabled() ) {
			return '';
		}

		if ( ! self::is_native_font_icon( $icon_settings ) ) {
			return '';
		}

		$glyph = Utils::process_font_icon( $icon_settings );

		if ( ! is_string( $glyph ) || '' === $glyph ) {
			return '';
		}

		$font_family = self::get_native_font_family( $icon_settings );
		$weight      = (string) ( $icon_settings['weight'] ?? '400' );
		$style       = sprintf(
			'font-family:%s;font-style:normal;font-weight:%s;',
			esc_attr( $font_family ),
			esc_attr( $weight )
		);
		$classes     = array_merge( array( 'dsm-native-icon-glyph' ), self::sanitize_extra_classes( $extra_classes ) );

		return HTMLUtility::render(
			array(
				'tag'               => 'i',
				'attributes'        => array(
					'class'       => implode( ' ', $classes ),
					'style'       => $style,
					'aria-hidden' => 'true',
				),
				'childrenSanitizer' => 'esc_html',
				'children'          => $glyph,
			)
		);
	}

	/**
	 * Render `.et-pb-icon` host with a native Divi / FA glyph child.
	 *
	 * @param array<string, mixed> $icon_settings Icon picker leaf.
	 * @param string[]             $extra_classes Module-specific host classes.
	 * @return string
	 */
	public static function render_native_icon_span( array $icon_settings, array $extra_classes = array() ): string {
		$glyph = self::render_native_glyph_markup( $icon_settings );

		if ( '' === $glyph ) {
			return '';
		}

		$classes = array_merge( array( 'et-pb-icon', 'dsm-native-icon-host' ), $extra_classes );

		return HTMLUtility::render(
			array(
				'tag'               => 'span',
				'attributes'        => array(
					'class'       => implode( ' ', array_unique( array_filter( $classes ) ) ),
					'aria-hidden' => 'true',
				),
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $glyph,
			)
		);
	}

	/**
	 * Render `<i class="…">` webfont glyph markup for SSR.
	 *
	 * @param array<string, mixed> $icon_settings Icon picker leaf.
	 * @param string[]             $extra_classes Additional CSS classes.
	 * @return string
	 */
	public static function render_glyph_markup( array $icon_settings, array $extra_classes = array() ): string {
		if ( ! ExtensionSettings::is_extension_enabled() ) {
			return '';
		}

		$font_class = self::get_font_class_for_icon( $icon_settings );

		if ( '' === $font_class ) {
			return '';
		}

		$suffix = '';

		foreach ( self::sanitize_extra_classes( $extra_classes ) as $class ) {
			$suffix .= ' ' . $class;
		}

		return '<i class="' . esc_attr( $font_class . ' dsm-webfont-icon-glyph' . $suffix ) . '" aria-hidden="true"></i>';
	}

	/**
	 * Build data attributes for scoped frontend icon CSS.
	 *
	 * @param array<string, mixed>|null $icon Icon settings.
	 * @return array<string, string>
	 */
	public static function data_attrs_from_icon( ?array $icon ): array {
		if ( ! ExtensionSettings::is_extension_enabled() ) {
			return array();
		}

		if ( ! IconLibraryRegistry::is_dsm_library_icon( $icon ) || ! is_array( $icon ) ) {
			return array();
		}

		$library_id = sanitize_key( (string) ( $icon['type'] ?? '' ) );
		$icon_id    = IconLibraryRegistry::resolve_stored_icon_slug(
			$library_id,
			(string) ( $icon['unicode'] ?? '' )
		);
		$variant    = IconLibraryRegistry::resolve_variant_from_icon( $icon );

		$attrs = array(
			'data-dsm-icon-type' => $library_id,
			'data-dsm-icon-id'   => $icon_id,
		);

		if ( '' !== $variant ) {
			$attrs['data-dsm-icon-variant'] = $variant;
		}

		return $attrs;
	}

	/**
	 * Whether Divi's `process_font_icon()` can paint this icon as CSS content.
	 *
	 * True only when `get_icon_font_family()` exists and the catalog row matches
	 * the stored unicode. Slug saves and Divi 5.16 stay on the `<i>` bridge.
	 *
	 * @param array<string, mixed> $icon_settings Icon picker leaf.
	 * @return bool
	 */
	public static function icon_manager_can_paint( array $icon_settings ): bool {
		if ( ! IconProcessFontIconBridge::uses_icon_manager_font_family() ) {
			return false;
		}

		if ( ! IconLibraryRegistry::is_dsm_library_icon( $icon_settings ) ) {
			return false;
		}

		if ( ! isset( $icon_settings['weight'] ) || '' === (string) $icon_settings['weight'] ) {
			return false;
		}

		$glyph = Utils::process_font_icon( $icon_settings );

		return is_string( $glyph ) && '' !== $glyph;
	}

	/**
	 * Inline style that paints a Supreme icon the way Divi 5.17 paints font icons.
	 *
	 * `content` is the escaped catalog unicode (`\HHHH`). `font-family` is the
	 * variant face when the library has one, otherwise `get_icon_font_family()`.
	 *
	 * @param array<string, mixed> $icon_settings Icon picker leaf.
	 * @return string Empty when this Divi build should keep the `<i>` glyph.
	 */
	public static function icon_manager_glyph_style( array $icon_settings ): string {
		if ( ! IconProcessFontIconBridge::uses_icon_manager_font_family() ) {
			return '';
		}

		if ( ! IconLibraryRegistry::is_dsm_library_icon( $icon_settings ) ) {
			return '';
		}

		$lookup = $icon_settings;

		if ( ! isset( $lookup['weight'] ) || '' === (string) $lookup['weight'] ) {
			$lookup['weight'] = '400';
		}

		$unicode = Utils::process_font_icon( $lookup, false, true );

		if ( ! is_string( $unicode ) || '' === $unicode ) {
			return '';
		}

		$escaped = Utils::escape_font_icon( $unicode );

		if ( ! is_string( $escaped ) || '' === $escaped || 1 === preg_match( '/[\'";{}<>]/', $escaped ) ) {
			return '';
		}

		$family = self::icon_manager_font_family( $icon_settings );

		if ( '' === $family ) {
			return '';
		}

		$weight = preg_replace( '/[^0-9]/', '', (string) $lookup['weight'] );

		if ( ! is_string( $weight ) || '' === $weight ) {
			$weight = '400';
		}

		return sprintf(
			"--dsm-icon-content:'%s';--dsm-icon-family:\"%s\";--dsm-icon-weight:%s;",
			$escaped,
			$family,
			$weight
		);
	}

	/**
	 * CSS font-family for a Supreme icon on the Divi 5.17 content path.
	 *
	 * Variant faces (Phosphor-Thin, tabler-icons-filled) win over the single
	 * family Divi's `get_icon_font_family()` stores per library id.
	 *
	 * @param array<string, mixed> $icon_settings Icon picker leaf.
	 * @return string Empty when the name is unsafe or the library is unknown.
	 */
	public static function icon_manager_font_family( array $icon_settings ): string {
		$type    = sanitize_key( (string) ( $icon_settings['type'] ?? '' ) );
		$library = IconLibraryRegistry::get( $type );
		$family  = '';

		if ( null !== $library ) {
			$slug    = IconLibraryRegistry::resolve_stored_icon_slug(
				$type,
				(string) ( $icon_settings['unicode'] ?? '' )
			);
			$variant = IconLibraryRegistry::resolve_variant_from_icon( $icon_settings );
			$family  = $library->get_picker_webfont_family( $slug, $variant );
		}

		if ( '' === $family ) {
			$family = Utils::get_icon_font_family( $type );
		}

		$family = (string) $family;

		if ( '' === $family || 1 !== preg_match( '/^[A-Za-z0-9 _-]+$/', $family ) ) {
			return '';
		}

		return $family;
	}

	/**
	 * One display character for a saved icon.
	 *
	 * Catalog entities come from `process_font_icon()`. A Divi 5.12–5.16 library
	 * slug is decoded from the webfont codepoint so CSS `content` can paint it.
	 *
	 * @param array<string, mixed> $icon_settings Icon picker leaf.
	 * @return string Empty when the icon cannot be drawn as a character.
	 */
	public static function decoded_glyph_character( array $icon_settings ): string {
		if ( class_exists( Utils::class ) ) {
			$processed = Utils::process_font_icon( $icon_settings );

			if ( is_string( $processed ) && '' !== $processed ) {
				return $processed;
			}
		}

		if ( ! IconLibraryRegistry::is_dsm_library_icon( $icon_settings ) ) {
			return '';
		}

		$type    = sanitize_key( (string) ( $icon_settings['type'] ?? '' ) );
		$library = IconLibraryRegistry::get( $type );

		if ( null === $library ) {
			return '';
		}

		$slug = IconLibraryRegistry::resolve_stored_icon_slug(
			$type,
			(string) ( $icon_settings['unicode'] ?? '' )
		);

		if ( '' === $slug ) {
			return '';
		}

		$entity = IconCodepointIndex::entity_for(
			$library,
			$slug,
			IconLibraryRegistry::resolve_variant_from_icon( $icon_settings )
		);

		if ( '' === $entity ) {
			return '';
		}

		$decoded = html_entity_decode( $entity, ENT_QUOTES, 'UTF-8' );

		return ( '' !== $decoded && $decoded !== $entity ) ? $decoded : '';
	}

	/**
	 * Host or child span whose `::before` uses Divi's escaped icon content.
	 *
	 * @param array<string, mixed> $icon_settings Icon picker leaf.
	 * @param string[]             $extra_classes Additional CSS classes.
	 * @param bool                 $as_host       Whether this span is the `.et-pb-icon` host.
	 * @return string
	 */
	private static function render_icon_manager_span( array $icon_settings, array $extra_classes = array(), bool $as_host = true ): string {
		$style = self::icon_manager_glyph_style( $icon_settings );

		if ( '' === $style ) {
			return '';
		}

		$classes = $as_host
			? array( 'et-pb-icon', 'dsm-webfont-icon-host', 'dsm-icon-manager-glyph' )
			: array( 'dsm-icon-manager-glyph' );
		$classes = array_merge( $classes, self::sanitize_extra_classes( $extra_classes ) );

		$attributes = array(
			'class'       => implode( ' ', array_unique( array_filter( $classes ) ) ),
			'style'       => $style,
			'aria-hidden' => 'true',
		);

		if ( $as_host ) {
			$attributes['data-dsm-icon-render'] = 'pseudo';
			$attributes                         = array_merge( $attributes, self::data_attrs_from_icon( $icon_settings ) );
		}

		return HTMLUtility::render(
			array(
				'tag'                  => 'span',
				'attributes'           => $attributes,
				'attributesSanitizers' => array(
					// Divi's CSS allow-list drops escaped `content` (`\HHHH`).
					// esc_attr keeps the declaration and escapes the attribute.
					'style' => 'esc_attr',
				),
				'childrenSanitizer'    => 'esc_html',
				'children'             => '',
			)
		);
	}

	/**
	 * Render an `.et-pb-icon` host span with embedded webfont glyph.
	 *
	 * @param array<string, mixed> $icon_settings Icon picker value.
	 * @param string[]             $extra_classes Additional CSS classes.
	 * @return string
	 */
	public static function render_icon_span( array $icon_settings, array $extra_classes = array() ): string {
		if ( ! ExtensionSettings::is_extension_enabled() ) {
			return '';
		}

		if ( ! IconLibraryRegistry::is_dsm_library_icon( $icon_settings ) ) {
			return '';
		}

		$manager = self::render_icon_manager_span( $icon_settings, $extra_classes );

		if ( '' !== $manager ) {
			return $manager;
		}

		$glyph = self::render_glyph_markup( $icon_settings );

		if ( '' === $glyph ) {
			return '';
		}

		$classes = array_merge( array( 'et-pb-icon', 'dsm-webfont-icon-host' ), $extra_classes );

		return HTMLUtility::render(
			array(
				'tag'               => 'span',
				'attributes'        => array_merge(
					array(
						'class'                => implode( ' ', array_unique( array_filter( $classes ) ) ),
						'data-dsm-icon-render' => 'glyph',
					),
					self::data_attrs_from_icon( $icon_settings )
				),
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $glyph,
			)
		);
	}

	/**
	 * Render a host for an innerContent tree (single glyph, or per-breakpoint children).
	 *
	 * @param array<string, mixed> $inner_content Icon attr innerContent tree.
	 * @param string[]             $extra_classes Additional CSS classes.
	 * @return string
	 */
	public static function render_icon_span_for_inner_content( array $inner_content, array $extra_classes = array() ): string {
		if ( ! ExtensionSettings::is_extension_enabled() ) {
			return '';
		}

		$resolved   = IconAttrBreakpoint::resolved_icon_leaves( $inner_content );
		$renderable = array();

		foreach ( IconAttrBreakpoint::BREAKPOINTS as $breakpoint ) {
			$leaf = $resolved[ $breakpoint ] ?? null;

			if ( ! is_array( $leaf ) ) {
				continue;
			}

			if ( IconLibraryRegistry::is_dsm_library_icon( $leaf ) || self::is_native_font_icon( $leaf ) ) {
				$renderable[ $breakpoint ] = $leaf;
			}
		}

		if ( array() === $renderable ) {
			return '';
		}

		$identities = array();

		foreach ( $renderable as $leaf ) {
			$identities[] = IconAttrBreakpoint::icon_identity( $leaf );
		}

		$unique = array_unique( $identities );

		if ( 1 === count( $unique ) && ( isset( $renderable['desktop'] ) || 3 === count( $renderable ) ) ) {
			return self::render_host_for_leaf( reset( $renderable ), $extra_classes );
		}

		if ( 1 === count( $renderable ) && isset( $renderable['desktop'] ) ) {
			return self::render_host_for_leaf( $renderable['desktop'], $extra_classes );
		}

		return self::render_responsive_icon_span( $renderable, $extra_classes );
	}

	/**
	 * Render a single webfont or native host for one resolved leaf.
	 *
	 * @param array<string, mixed> $icon_settings Icon picker leaf.
	 * @param string[]             $extra_classes Additional CSS classes.
	 * @return string
	 */
	private static function render_host_for_leaf( array $icon_settings, array $extra_classes ): string {
		if ( IconLibraryRegistry::is_dsm_library_icon( $icon_settings ) ) {
			return self::render_icon_span( $icon_settings, $extra_classes );
		}

		if ( self::is_native_font_icon( $icon_settings ) ) {
			return self::render_native_icon_span( $icon_settings, $extra_classes );
		}

		return '';
	}

	/**
	 * Render one host with a glyph child per coarse breakpoint.
	 *
	 * @param array<string, array<string, mixed>> $renderable Cascaded leaves keyed by breakpoint.
	 * @param string[]                            $extra_classes Additional CSS classes.
	 * @return string
	 */
	private static function render_responsive_icon_span( array $renderable, array $extra_classes ): string {
		$children  = '';
		$host_data = array();
		$has_dsm   = false;

		foreach ( IconAttrBreakpoint::BREAKPOINTS as $breakpoint ) {
			if ( ! isset( $renderable[ $breakpoint ] ) ) {
				continue;
			}

			$leaf     = $renderable[ $breakpoint ];
			$bp_class = array( 'dsm-webfont-icon-bp', 'dsm-webfont-icon-bp--' . $breakpoint );

			if ( IconLibraryRegistry::is_dsm_library_icon( $leaf ) ) {
				$has_dsm       = true;
				$manager_child = self::render_icon_manager_span( $leaf, $bp_class, false );
				$children     .= '' !== $manager_child ? $manager_child : self::render_glyph_markup( $leaf, $bp_class );

				if ( array() === $host_data ) {
					$host_data = self::data_attrs_from_icon( $leaf );
				}
			} elseif ( self::is_native_font_icon( $leaf ) ) {
				$children .= self::render_native_glyph_markup( $leaf, $bp_class );
			}
		}

		if ( '' === $children ) {
			return '';
		}

		$host_class = $has_dsm ? 'dsm-webfont-icon-host' : 'dsm-native-icon-host';
		$classes    = array_merge(
			array( 'et-pb-icon', $host_class, 'dsm-webfont-icon-host--responsive' ),
			$extra_classes
		);
		$host_attrs = array(
			'class' => implode( ' ', array_unique( array_filter( $classes ) ) ),
		);

		if ( $has_dsm ) {
			$host_attrs['data-dsm-icon-render'] = 'glyph';
		}

		return HTMLUtility::render(
			array(
				'tag'               => 'span',
				'attributes'        => array_merge(
					$host_attrs,
					$host_data
				),
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $children,
			)
		);
	}

	/**
	 * Sanitize extra class tokens for glyph markup.
	 *
	 * @param string[] $extra_classes Raw extra class names.
	 * @return string[]
	 */
	private static function sanitize_extra_classes( array $extra_classes ): array {
		$safe = array();

		foreach ( $extra_classes as $class ) {
			$token = sanitize_html_class( (string) $class );

			if ( '' !== $token ) {
				$safe[] = $token;
			}
		}

		return $safe;
	}
}
