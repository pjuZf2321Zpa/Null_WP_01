<?php
/**
 * Maps webfont CSS codepoints to manifest slugs.
 *
 * Divi 5.17 Icon Manager decodes iconList `unicode` with
 * `String.fromCodePoint(parseInt(unicode.slice(3, -1), 16))`, which only
 * accepts `&#xHHHH;`. Slugs stay the stored id for layouts saved before that.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Extensions\IconLibraries;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Reads each library webfont CSS once per request.
 */
final class IconCodepointIndex {

	/**
	 * Library id → slug → lowercase hex (no prefix).
	 *
	 * @var array<string, array<string, string>>
	 */
	private static array $slug_to_hex = array();

	/**
	 * Library id → lowercase hex → manifest slug.
	 *
	 * @var array<string, array<string, string>>
	 */
	private static array $hex_to_slug = array();

	/**
	 * Loaded.
	 *
	 * @var array<string, bool>
	 */
	private static array $loaded = array();

	/**
	 * `&#xHHHH;` for a manifest icon, or empty when the CSS has no codepoint.
	 *
	 * @param IconLibraryInterface $library  Library.
	 * @param string               $icon_id  Manifest slug.
	 * @param string               $variant  Stylesheet variant.
	 * @return string
	 */
	public static function entity_for( IconLibraryInterface $library, string $icon_id, string $variant ): string {
		$hex = self::hex_for( $library, $icon_id, $variant );

		if ( '' === $hex ) {
			return '';
		}

		return '&#x' . $hex . ';';
	}

	/**
	 * Manifest slug for a stored `&#xHHHH;` value.
	 *
	 * @param string $library_id Library slug.
	 * @param string $unicode    Stored unicode.
	 * @return string Empty when the value is not an entity or the codepoint is unknown.
	 */
	public static function slug_for_entity( string $library_id, string $unicode ): string {
		$library_id = sanitize_key( $library_id );
		$hex        = self::hex_from_entity( $unicode );

		if ( '' === $library_id || '' === $hex ) {
			return '';
		}

		$library = IconLibraryRegistry::get( $library_id );

		if ( null === $library ) {
			return '';
		}

		self::load_library( $library );

		return self::$hex_to_slug[ $library_id ][ $hex ] ?? '';
	}

	/**
	 * Lowercase hex from `&#xHHHH;` or `&amp;#xHHHH;`.
	 *
	 * @param string $unicode Stored unicode.
	 * @return string
	 */
	public static function hex_from_entity( string $unicode ): string {
		$unicode = trim( $unicode );
		$unicode = str_replace( '&amp;#', '&#', $unicode );

		if ( ! preg_match( '/^&#x([0-9a-fA-F]{1,6});$/', $unicode, $matches ) ) {
			return '';
		}

		return strtolower( $matches[1] );
	}

	/**
	 * Hex for.
	 *
	 * @param IconLibraryInterface $library Library.
	 * @param string               $icon_id Manifest slug.
	 * @param string               $variant Stylesheet variant.
	 * @return string
	 */
	private static function hex_for( IconLibraryInterface $library, string $icon_id, string $variant ): string {
		self::load_library( $library );

		$library_id = $library->get_id();
		$icon_id    = sanitize_key( $icon_id );
		$bucket     = self::variant_key( $library_id, $variant );
		$hex        = self::$slug_to_hex[ $bucket ][ $icon_id ] ?? '';

		if ( '' === $hex ) {
			$hex = self::$slug_to_hex[ self::variant_key( $library_id, $library->get_default_variant() ) ][ $icon_id ] ?? '';
		}

		return $hex;
	}

	/**
	 * Load library.
	 *
	 * @param IconLibraryInterface $library Library.
	 * @return void
	 */
	private static function load_library( IconLibraryInterface $library ): void {
		$library_id = $library->get_id();

		if ( isset( self::$loaded[ $library_id ] ) ) {
			return;
		}

		self::$loaded[ $library_id ] = true;
		$pattern                     = self::pattern_for( $library_id );

		if ( '' === $pattern ) {
			return;
		}

		foreach ( $library->get_webfont_stylesheets() as $sheet ) {
			$path = (string) ( $sheet['path'] ?? '' );

			if ( '' === $path || ! is_readable( $path ) ) {
				continue;
			}

			$css = file_get_contents( $path );

			if ( ! is_string( $css ) || '' === $css ) {
				continue;
			}

			$variant = sanitize_key( (string) ( $sheet['variant'] ?? '' ) );
			$bucket  = self::variant_key( $library_id, $variant );

			if ( ! isset( self::$slug_to_hex[ $bucket ] ) ) {
				self::$slug_to_hex[ $bucket ] = array();
			}

			if ( ! preg_match_all( $pattern, $css, $matches, PREG_SET_ORDER ) ) {
				continue;
			}

			foreach ( $matches as $match ) {
				$slug = sanitize_key( (string) ( $match[1] ?? '' ) );
				$hex  = strtolower( (string) ( $match[2] ?? '' ) );

				if ( '' === $slug || '' === $hex || isset( self::$slug_to_hex[ $bucket ][ $slug ] ) ) {
					continue;
				}

				self::$slug_to_hex[ $bucket ][ $slug ] = $hex;

				if ( ! isset( self::$hex_to_slug[ $library_id ][ $hex ] ) ) {
					self::$hex_to_slug[ $library_id ][ $hex ] = $slug;
				}
			}
		}

		self::prefer_manifest_slugs( $library );
	}

	/**
	 * Point each codepoint at the manifest id when an alias class shares it.
	 *
	 * @param IconLibraryInterface $library Library.
	 * @return void
	 */
	private static function prefer_manifest_slugs( IconLibraryInterface $library ): void {
		$library_id = $library->get_id();

		foreach ( $library->get_manifest() as $entry ) {
			if ( ! is_array( $entry ) ) {
				continue;
			}

			$icon_id = sanitize_key( (string) ( $entry['id'] ?? '' ) );
			$variant = sanitize_key( (string) ( $entry['variant'] ?? $library->get_default_variant() ) );
			$hex     = self::$slug_to_hex[ self::variant_key( $library_id, $variant ) ][ $icon_id ] ?? '';

			if ( '' === $icon_id || '' === $hex ) {
				continue;
			}

			self::$hex_to_slug[ $library_id ][ $hex ] = $icon_id;
		}
	}

	/**
	 * Variant key.
	 *
	 * @param string $library_id Library slug.
	 * @param string $variant    Stylesheet variant.
	 * @return string
	 */
	private static function variant_key( string $library_id, string $variant ): string {
		return sanitize_key( $library_id ) . ':' . sanitize_key( $variant );
	}

	/**
	 * Verified selectors from each shipped webfont stylesheet.
	 *
	 * @param string $library_id Library slug.
	 * @return string Empty when this library has no known CSS shape.
	 */
	private static function pattern_for( string $library_id ): string {
		switch ( $library_id ) {
			case 'lucide':
				return '/\.icon-([a-z0-9_-]+):{1,2}before\s*\{[^}]*content:\s*"\\\\([0-9a-fA-F]{1,6})"/';
			case 'heroicons':
				return '/\.pb-heroicons-([a-z0-9_-]+):{1,2}before\s*\{[^}]*content:\s*"\\\\([0-9a-fA-F]{1,6})"/';
			case 'phosphor':
				return '/\.ph-([a-z0-9_-]+):{1,2}before\s*\{[^}]*content:\s*"\\\\([0-9a-fA-F]{1,6})"/';
			case 'tabler':
				return '/\.ti-([a-z0-9_-]+):before\{content:"\\\\([0-9a-fA-F]{1,6})"/';
			default:
				return '';
		}
	}
}
