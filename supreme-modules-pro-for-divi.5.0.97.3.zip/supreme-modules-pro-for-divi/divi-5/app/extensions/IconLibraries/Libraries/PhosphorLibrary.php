<?php
/**
 * Phosphor Icons library (MIT) — webfont picker + webfont frontend.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Extensions\IconLibraries\Libraries;

use DiviSupreme\Extensions\IconLibraries\AbstractFileIconLibrary;
use DiviSupreme\Extensions\IconLibraries\IconLibraryBrandMark;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Phosphor Icons — webfont everywhere (picker + frontend).
 */
class PhosphorLibrary extends AbstractFileIconLibrary {

	/**
	 * {@inheritDoc}
	 */
	public function get_id(): string {
		return 'phosphor';
	}

	/**
	 * {@inheritDoc}
	 */
	public function get_label(): string {
		return __( 'Phosphor Icons', 'dsm-supreme-modules-pro-for-divi' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function get_license_note(): string {
		return __( 'MIT License — Phosphor Icons © Phosphor Icons contributors.', 'dsm-supreme-modules-pro-for-divi' );
	}

	/**
	 * Official Phosphor brand mark (`phosphor-logo` icon, MIT).
	 *
	 * {@inheritDoc}
	 */
	public function get_brand_mark(): string {
		return IconLibraryBrandMark::sanitize_inline(
			'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 256" fill="currentColor" aria-hidden="true"><path d="M152,32H72a8,8,0,0,0-8,8V168a80.09,80.09,0,0,0,80,80,8,8,0,0,0,8-8V176a72,72,0,0,0,0-144ZM80,70.54,130.32,160H80Zm56,66.92L85.68,48H136ZM80.51,176H136v55.5A64.14,64.14,0,0,1,80.51,176ZM152,160V48a56,56,0,0,1,0,112Z"/></svg>'
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function get_variants(): array {
		return array(
			'thin'    => __( 'Thin', 'dsm-supreme-modules-pro-for-divi' ),
			'light'   => __( 'Light', 'dsm-supreme-modules-pro-for-divi' ),
			'regular' => __( 'Regular', 'dsm-supreme-modules-pro-for-divi' ),
			'bold'    => __( 'Bold', 'dsm-supreme-modules-pro-for-divi' ),
			'fill'    => __( 'Fill', 'dsm-supreme-modules-pro-for-divi' ),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function get_default_variant(): string {
		return 'regular';
	}

	/**
	 * {@inheritDoc}
	 */
	public function get_sample_icon_id(): string {
		return 'house';
	}

	/**
	 * {@inheritDoc}
	 */
	public function get_picker_render_mode(): string {
		return 'webfont';
	}

	/**
	 * {@inheritDoc}
	 */
	public function get_frontend_render_mode(): string {
		return 'webfont';
	}

	/**
	 * {@inheritDoc}
	 */
	public function get_webfont_stylesheets(): array {
		$base     = trailingslashit( $this->get_data_directory() ) . 'webfont/';
		$variants = array_keys( $this->get_variants() );
		$rows     = array();

		foreach ( $variants as $variant ) {
			$rows[] = array(
				'variant' => $variant,
				'handle'  => 'dsm-icon-webfont-phosphor-' . $variant,
				'path'    => $base . $variant . '/style.css',
				'url'     => $this->resolve_plugin_asset_url( $base . $variant . '/style.css' ),
			);
		}

		return $rows;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @param string $icon_id Icon id.
	 * @param string $variant Variant.
	 */
	public function get_picker_font_class( string $icon_id, string $variant = '' ): string {
		$icon_slug    = sanitize_file_name( $icon_id );
		$variant_slug = '' !== $variant ? sanitize_key( $variant ) : $this->get_default_variant();
		$weight_class = $this->get_phosphor_weight_class( $variant_slug );

		return trim( $weight_class . ' ph-' . $icon_slug );
	}

	/**
	 * Map Phosphor variant slug to webfont weight class.
	 *
	 * @param string $variant Variant slug.
	 * @return string
	 */
	private function get_phosphor_weight_class( string $variant ): string {
		$map = array(
			'thin'    => 'ph-thin',
			'light'   => 'ph-light',
			'regular' => 'ph',
			'bold'    => 'ph-bold',
			'fill'    => 'ph-fill',
		);

		return $map[ $variant ] ?? 'ph';
	}

	/**
	 * {@inheritDoc}
	 *
	 * @param string $icon_id Icon id.
	 * @param string $variant Variant.
	 */
	public function get_picker_webfont_family( string $icon_id, string $variant = '' ): string {
		unset( $icon_id );

		$variant_slug = '' !== $variant ? sanitize_key( $variant ) : $this->get_default_variant();

		$map = array(
			'thin'    => 'Phosphor-Thin',
			'light'   => 'Phosphor-Light',
			'regular' => 'Phosphor',
			'bold'    => 'Phosphor-Bold',
			'fill'    => 'Phosphor-Fill',
		);

		return $map[ $variant_slug ] ?? 'Phosphor';
	}
}
