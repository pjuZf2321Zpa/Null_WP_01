<?php
/**
 * Heroicons library (MIT) — webfont picker + webfont frontend.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Extensions\IconLibraries\Libraries;

use DiviSupreme\Extensions\IconLibraries\AbstractFileIconLibrary;
use DiviSupreme\Extensions\IconLibraries\IconLibraryBrandMark;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Heroicons — single-weight webfont (outline + solid glyphs in one font).
 */
class HeroiconsLibrary extends AbstractFileIconLibrary {

	/**
	 * Scope class for Heroicons webfont glyphs (avoids global `pb-heroicons-*` collisions).
	 */
	private const GLYPH_SCOPE_CLASS = 'dsm-heroicons-glyph';

	/**
	 * {@inheritDoc}
	 */
	public function get_id(): string {
		return 'heroicons';
	}

	/**
	 * {@inheritDoc}
	 */
	public function get_label(): string {
		return __( 'Heroicons', 'dsm-supreme-modules-pro-for-divi' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function get_license_note(): string {
		return __( 'MIT License — Heroicons © Tailwind Labs.', 'dsm-supreme-modules-pro-for-divi' );
	}

	/**
	 * Official Heroicons shield mark (outer contour from heroicons outline set, MIT).
	 *
	 * {@inheritDoc}
	 */
	public function get_brand_mark(): string {
		return IconLibraryBrandMark::sanitize_inline(
			'<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 2.714A11.959 11.959 0 0 1 3.598 6 11.99 11.99 0 0 0 3 9.75c0 5.592 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.31-.21-2.57-.598-3.75h-.152c-3.196 0-6.1-1.25-8.25-3.286Z"/></svg>'
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function get_sample_icon_id(): string {
		return 'home';
	}

	/**
	 * {@inheritDoc}
	 */
	public function get_picker_render_mode(): string {
		return 'webfont';
	}

	/**
	 * {@inheritDoc}
	 */
	public function get_frontend_render_mode(): string {
		return 'webfont';
	}

	/**
	 * {@inheritDoc}
	 */
	public function get_webfont_stylesheets(): array {
		$base = trailingslashit( $this->get_data_directory() ) . 'webfont/';

		return array(
			array(
				'variant' => '',
				'handle'  => 'dsm-icon-webfont-heroicons',
				'path'    => $base . 'style.css',
				'url'     => $this->resolve_plugin_asset_url( $base . 'style.css' ),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 *
	 * @param string $icon_id Icon id.
	 * @param string $variant Variant.
	 */
	public function get_picker_font_class( string $icon_id, string $variant = '' ): string {
		unset( $variant );

		$icon_slug = sanitize_file_name( $icon_id );

		if ( '' === $icon_slug ) {
			return self::GLYPH_SCOPE_CLASS;
		}

		return 'pb-heroicons pb-heroicons-' . $icon_slug . ' ' . self::GLYPH_SCOPE_CLASS;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @param string $icon_id Icon id.
	 * @param string $variant Variant.
	 */
	public function get_picker_webfont_family( string $icon_id, string $variant = '' ): string {
		unset( $icon_id, $variant );

		return 'heroicons';
	}
}
