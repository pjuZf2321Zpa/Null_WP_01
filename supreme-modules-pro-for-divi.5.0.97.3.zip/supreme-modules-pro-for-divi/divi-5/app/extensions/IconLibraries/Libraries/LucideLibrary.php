<?php
/**
 * Lucide Icons library (ISC) — webfont picker + webfont frontend.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Extensions\IconLibraries\Libraries;

use DiviSupreme\Extensions\IconLibraries\AbstractFileIconLibrary;
use DiviSupreme\Extensions\IconLibraries\IconLibraryBrandMark;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Lucide Icons — single stroke webfont (lucide-static).
 */
class LucideLibrary extends AbstractFileIconLibrary {

	/**
	 * Scope class for Lucide webfont glyphs (avoids global `.icon-*` collisions).
	 */
	private const GLYPH_SCOPE_CLASS = 'dsm-lucide-glyph';

	/**
	 * {@inheritDoc}
	 */
	public function get_id(): string {
		return 'lucide';
	}

	/**
	 * {@inheritDoc}
	 */
	public function get_label(): string {
		return __( 'Lucide Icons', 'dsm-supreme-modules-pro-for-divi' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function get_license_note(): string {
		return __( 'ISC License — Lucide Icons © Lucide Contributors.', 'dsm-supreme-modules-pro-for-divi' );
	}

	/**
	 * Official Lucide favicon mark (dual-arc logo, ISC — monochrome via currentColor).
	 *
	 * {@inheritDoc}
	 */
	public function get_brand_mark(): string {
		return IconLibraryBrandMark::sanitize_inline(
			'<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14 12C14 9.79086 12.2091 8 10 8C7.79086 8 6 9.79086 6 12C6 16.4183 9.58172 20 14 20C18.4183 20 22 16.4183 22 12C22 8.446 20.455 5.25285 18 3.05557"/><path d="M10 12C10 14.2091 11.7909 16 14 16C16.2091 16 18 14.2091 18 12C18 7.58172 14.4183 4 10 4C5.58172 4 2 7.58172 2 12C2 15.5841 3.57127 18.8012 6.06253 21"/></svg>'
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function get_sample_icon_id(): string {
		return 'house';
	}

	/**
	 * {@inheritDoc}
	 */
	public function get_picker_render_mode(): string {
		return 'webfont';
	}

	/**
	 * {@inheritDoc}
	 */
	public function get_frontend_render_mode(): string {
		return 'webfont';
	}

	/**
	 * {@inheritDoc}
	 */
	public function get_webfont_stylesheets(): array {
		$base = trailingslashit( $this->get_data_directory() ) . 'webfont/';

		return array(
			array(
				'variant' => '',
				'handle'  => 'dsm-icon-webfont-lucide',
				'path'    => $base . 'style.css',
				'url'     => $this->resolve_plugin_asset_url( $base . 'style.css' ),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 *
	 * @param string $icon_id Icon id.
	 * @param string $variant Variant.
	 */
	public function get_picker_font_class( string $icon_id, string $variant = '' ): string {
		unset( $variant );

		$icon_slug = sanitize_file_name( $icon_id );

		return 'icon-' . $icon_slug . ' ' . self::GLYPH_SCOPE_CLASS;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @param string $icon_id Icon id.
	 * @param string $variant Variant.
	 */
	public function get_picker_webfont_family( string $icon_id, string $variant = '' ): string {
		unset( $icon_id, $variant );

		return 'lucide';
	}
}
