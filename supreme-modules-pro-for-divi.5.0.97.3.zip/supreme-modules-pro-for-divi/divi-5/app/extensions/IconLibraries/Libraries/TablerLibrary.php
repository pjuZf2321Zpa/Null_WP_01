<?php
/**
 * Tabler Icons library (MIT) — outline + filled variants.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Extensions\IconLibraries\Libraries;

use DiviSupreme\Extensions\IconLibraries\AbstractFileIconLibrary;
use DiviSupreme\Extensions\IconLibraries\IconLibraryBrandMark;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Tabler Icons — webfont picker + frontend.
 */
class TablerLibrary extends AbstractFileIconLibrary {

	/**
	 * Webfont index cache.
	 *
	 * @var array<string, mixed>|null
	 */
	private ?array $webfont_index_cache = null;

	/**
	 * Scope class for outline webfont glyphs.
	 */
	private const OUTLINE_SCOPE_CLASS = 'dsm-tabler-outline-glyph';

	/**
	 * Scope class for filled webfont glyphs.
	 */
	private const FILLED_SCOPE_CLASS = 'dsm-tabler-filled-glyph';

	/**
	 * {@inheritDoc}
	 */
	public function get_id(): string {
		return 'tabler';
	}

	/**
	 * {@inheritDoc}
	 */
	public function get_label(): string {
		return __( 'Tabler Icons', 'dsm-supreme-modules-pro-for-divi' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function get_license_note(): string {
		return __( 'MIT License — Tabler Icons © Tabler.io contributors.', 'dsm-supreme-modules-pro-for-divi' );
	}

	/**
	 * Official Tabler brand mark (`brand-tabler` icon, MIT).
	 *
	 * {@inheritDoc}
	 */
	public function get_brand_mark(): string {
		return IconLibraryBrandMark::sanitize_inline(
			'<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M8 9l3 3l-3 3"/><path d="M13 15h3"/><path d="M3 7a4 4 0 0 1 4 -4h10a4 4 0 0 1 4 4v10a4 4 0 0 1 -4 4h-10a4 4 0 0 1 -4 -4l0 -10"/></svg>'
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function get_variants(): array {
		return array(
			'outline' => __( 'Outline', 'dsm-supreme-modules-pro-for-divi' ),
			'filled'  => __( 'Filled', 'dsm-supreme-modules-pro-for-divi' ),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function get_default_variant(): string {
		return 'outline';
	}

	/**
	 * {@inheritDoc}
	 */
	public function get_sample_icon_id(): string {
		return 'home';
	}

	/**
	 * {@inheritDoc}
	 */
	public function get_picker_render_mode(): string {
		return 'webfont';
	}

	/**
	 * {@inheritDoc}
	 */
	public function get_frontend_render_mode(): string {
		return 'webfont';
	}

	/**
	 * {@inheritDoc}
	 */
	public function get_webfont_stylesheets(): array {
		$base = trailingslashit( $this->get_data_directory() ) . 'webfont/';

		return array(
			array(
				'variant' => 'outline',
				'handle'  => 'dsm-icon-webfont-tabler-outline',
				'path'    => $base . 'outline/tabler-icons.min.css',
				'url'     => $this->resolve_plugin_asset_url( $base . 'outline/tabler-icons.min.css' ),
			),
			array(
				'variant' => 'filled',
				'handle'  => 'dsm-icon-webfont-tabler-filled',
				'path'    => $base . 'filled/tabler-icons-filled.min.css',
				'url'     => $this->resolve_plugin_asset_url( $base . 'filled/tabler-icons-filled.min.css' ),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 *
	 * @param string $icon_id Icon id.
	 * @param string $variant Variant.
	 */
	public function get_picker_font_class( string $icon_id, string $variant = '' ): string {
		$icon_slug   = sanitize_file_name( $icon_id );
		$scope_class = $this->resolve_picker_scope_class( $icon_id, $variant );

		return 'ti ti-' . $icon_slug . ' ' . $scope_class;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @param string $icon_id Icon id.
	 * @param string $variant Variant.
	 */
	public function get_picker_webfont_family( string $icon_id, string $variant = '' ): string {
		$variant_slug = '' !== $variant ? sanitize_key( $variant ) : $this->get_default_variant();

		if ( 'filled' === $variant_slug && $this->icon_has_filled_webfont( $icon_id ) ) {
			return 'tabler-icons-filled';
		}

		return 'tabler-icons';
	}

	/**
	 * Tabler webfont family index (outline vs filled glyph sets).
	 *
	 * @return array<string, mixed>
	 */
	public function get_webfont_index(): array {
		if ( null !== $this->webfont_index_cache ) {
			return $this->webfont_index_cache;
		}

		$file = trailingslashit( $this->get_data_directory() ) . 'webfont/webfont-index.json';

		if ( ! is_readable( $file ) ) {
			$this->webfont_index_cache = array();
			return $this->webfont_index_cache;
		}

		$raw = file_get_contents( $file );

		if ( false === $raw ) {
			$this->webfont_index_cache = array();
			return $this->webfont_index_cache;
		}

		/**
		 * Icon has filled webfont.
		 *
		 * @var array<string, mixed>|null $decoded
		 */
		$decoded = json_decode( $raw, true );

		$this->webfont_index_cache = is_array( $decoded ) ? $decoded : array();

		return $this->webfont_index_cache;
	}

	/**
	 * Whether an icon id exists in the filled Tabler webfont.
	 *
	 * @param string $icon_id Icon slug.
	 * @return bool
	 */
	public function icon_has_filled_webfont( string $icon_id ): bool {
		$index  = $this->get_webfont_index();
		$filled = $index['filled'] ?? array();

		if ( ! is_array( $filled ) ) {
			return false;
		}

		return in_array( sanitize_file_name( $icon_id ), $filled, true );
	}

	/**
	 * Whether an icon id exists only in the outline Tabler webfont.
	 *
	 * @param string $icon_id Icon slug.
	 * @return bool
	 */
	public function icon_has_outline_only_webfont( string $icon_id ): bool {
		$index        = $this->get_webfont_index();
		$outline_only = $index['outlineOnly'] ?? array();

		if ( ! is_array( $outline_only ) ) {
			return true;
		}

		return in_array( sanitize_file_name( $icon_id ), $outline_only, true );
	}

	/**
	 * Resolve picker scope class.
	 *
	 * @param string $icon_id Icon slug.
	 * @param string $variant Variant slug.
	 * @return string
	 */
	private function resolve_picker_scope_class( string $icon_id, string $variant ): string {
		$variant_slug = '' !== $variant ? sanitize_key( $variant ) : $this->get_default_variant();

		if ( 'filled' === $variant_slug && $this->icon_has_filled_webfont( $icon_id ) ) {
			return self::FILLED_SCOPE_CLASS;
		}

		return self::OUTLINE_SCOPE_CLASS;
	}
}
