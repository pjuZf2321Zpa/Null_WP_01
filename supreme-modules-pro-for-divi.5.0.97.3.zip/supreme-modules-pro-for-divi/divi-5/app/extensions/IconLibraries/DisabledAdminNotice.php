<?php
/**
 * Admin notice when saved library icons exist but Icon Libraries is disabled.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Extensions\IconLibraries;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Admin notice when saved library icons exist but Icon Libraries is disabled.
 */
final class DisabledAdminNotice {

	private const TRANSIENT_KEY = 'dsm_icon_libraries_stored_icons_present';

	private const CACHE_TTL_FOUND = WEEK_IN_SECONDS;

	private const CACHE_TTL_NOT_FOUND = DAY_IN_SECONDS;

	/**
	 * Register.
	 *
	 * @return void
	 */
	public static function register(): void {
		if ( ! is_admin() ) {
			return;
		}

		add_action( 'admin_notices', array( self::class, 'render' ) );
		add_action( 'wp_ajax_dsm_dismiss_icon_libraries_disabled_notice', array( self::class, 'ajax_dismiss' ) );
		add_action( 'save_post', array( self::class, 'handle_save_post' ), 10, 3 );
		add_action(
			'updated_option',
			static function ( string $option ): void {
				if ( in_array( $option, array( 'dsm_general', 'dsm_icon_libraries' ), true ) ) {
					self::clear_scan_cache();
				}
			},
			10,
			1
		);
	}

	/**
	 * Clear scan cache.
	 *
	 * @return void
	 */
	public static function clear_scan_cache(): void {
		delete_transient( self::TRANSIENT_KEY );
	}

	/**
	 * Warm or invalidate the scan cache when post content changes (avoids full-site queries on routine saves).
	 *
	 * @param int           $post_id Post ID.
	 * @param \WP_Post|null $post    Post object.
	 * @param bool          $update  Whether this is an existing post being updated.
	 * @return void
	 */
	public static function handle_save_post( int $post_id, $post, bool $update ): void {
		unset( $update );

		if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
			return;
		}

		if ( ! $post instanceof \WP_Post ) {
			return;
		}

		if ( ! in_array( $post->post_status, array( 'publish', 'draft', 'private', 'pending', 'future' ), true ) ) {
			self::clear_scan_cache();

			return;
		}

		if ( ! in_array( $post->post_type, self::get_scannable_post_types(), true ) ) {
			return;
		}

		$icons = PostContentIconScanner::collect_from_post_content( $post_id );

		if ( array() !== $icons ) {
			set_transient( self::TRANSIENT_KEY, 'yes', self::CACHE_TTL_FOUND );

			return;
		}

		// Content changed on a scannable post; drop cache so the next notice check can rescan if needed.
		self::clear_scan_cache();
	}

	/**
	 * Get known library type IDs.
	 *
	 * @return string[]
	 */
	private static function get_known_library_type_ids(): array {
		$ids = array( 'tabler', 'phosphor', 'lucide' );

		if ( class_exists( IconLibraryRegistry::class ) ) {
			IconLibraryRegistry::boot();
			$ids = array_keys( IconLibraryRegistry::all() );
		}

		return array_values( array_unique( array_filter( array_map( 'sanitize_key', $ids ) ) ) );
	}

	/**
	 * Get scannable post types.
	 *
	 * @return string[]
	 */
	private static function get_scannable_post_types(): array {
		$post_types = apply_filters(
			'dsm_icon_libraries_scannable_post_types',
			array( 'page', 'post', 'et_pb_layout' )
		);

		$post_types = array_values(
			array_filter(
				array_map( 'sanitize_key', is_array( $post_types ) ? $post_types : array() )
			)
		);

		return array_values(
			array_filter( $post_types, 'post_type_exists' )
		);
	}

	/**
	 * Query database for stored library icons.
	 *
	 * @param string[] $library_ids Known library type IDs.
	 * @param string[] $post_types  Scannable post types.
	 * @return bool
	 */
	private static function query_database_for_stored_library_icons( array $library_ids, array $post_types ): bool {
		global $wpdb;

		$like_clauses = array();
		$prepare_args = array();

		foreach ( $library_ids as $library_id ) {
			$escaped        = $wpdb->esc_like( $library_id );
			$like_clauses[] = 'post_content LIKE %s';
			$prepare_args[] = '%"type":"' . $escaped . '"%';
			$like_clauses[] = 'post_content LIKE %s';
			$prepare_args[] = '%"type": "' . $escaped . '"%';
		}

		$post_type_in = implode(
			', ',
			array_map(
				static function ( string $post_type ): string {
					return "'" . esc_sql( $post_type ) . "'";
				},
				$post_types
			)
		);

		$content_match_sql = implode( ' OR ', $like_clauses );

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- Dynamic IN/LIKE lists; post types are sanitize_key + esc_sql; LIKE values are bound below.
		$sql = $wpdb->prepare(
			"SELECT 1 FROM {$wpdb->posts}
			WHERE post_status IN ('publish','draft','private','pending','future')
			AND post_type IN ({$post_type_in})
			AND ({$content_match_sql})
			LIMIT 1",
			...$prepare_args
		);

		$found = null !== $wpdb->get_var( $sql );
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared

		return $found;
	}

	/**
	 * Persist scan cache.
	 *
	 * @param bool $found Whether library icons exist in stored content.
	 * @return void
	 */
	private static function persist_scan_cache( bool $found ): void {
		set_transient(
			self::TRANSIENT_KEY,
			$found ? 'yes' : 'no',
			$found ? self::CACHE_TTL_FOUND : self::CACHE_TTL_NOT_FOUND
		);
	}

	/**
	 * Site has stored library icons.
	 *
	 * @return bool
	 */
	public static function site_has_stored_library_icons(): bool {
		$cached = get_transient( self::TRANSIENT_KEY );

		if ( is_string( $cached ) ) {
			return 'yes' === $cached;
		}

		$library_ids = self::get_known_library_type_ids();

		if ( array() === $library_ids ) {
			self::persist_scan_cache( false );

			return false;
		}

		$post_types = self::get_scannable_post_types();

		if ( array() === $post_types ) {
			self::persist_scan_cache( false );

			return false;
		}

		$found = self::query_database_for_stored_library_icons( $library_ids, $post_types );

		self::persist_scan_cache( $found );

		return $found;
	}

	/**
	 * User dismissed.
	 *
	 * @param int $user_id User ID.
	 * @return bool
	 */
	private static function user_dismissed( int $user_id = 0 ): bool {
		if ( $user_id <= 0 ) {
			$user_id = get_current_user_id();
		}

		if ( $user_id <= 0 ) {
			return true;
		}

		return '1' === get_user_meta( $user_id, 'dsm_dismissed_icon_libraries_disabled_notice', true );
	}

	/**
	 * Should show.
	 *
	 * @return bool
	 */
	private static function should_show(): bool {
		if ( ! is_admin() || ! current_user_can( 'manage_options' ) ) {
			return false;
		}

		if ( ExtensionSettings::is_extension_enabled() ) {
			return false;
		}

		if ( self::user_dismissed() ) {
			return false;
		}

		return self::site_has_stored_library_icons();
	}

	/**
	 * Render.
	 *
	 * @return void
	 */
	public static function render(): void {
		if ( ! self::should_show() ) {
			return;
		}

		$settings_url = add_query_arg(
			array(
				'page' => 'divi_supreme_settings',
				'tab'  => 'dsm_general',
			),
			admin_url( 'admin.php' )
		);

		wp_enqueue_script( 'jquery' );

		$nonce = wp_create_nonce( 'dsm_dismiss_icon_libraries_disabled_notice' );

		wp_add_inline_script(
			'jquery',
			'jQuery(function($){$(document).on("click",".dsm-icon-libraries-disabled-notice .notice-dismiss",function(){$.post(ajaxurl,{action:"dsm_dismiss_icon_libraries_disabled_notice",nonce:' . wp_json_encode( $nonce ) . '});});});'
		);

		?>
		<div class="notice notice-warning is-dismissible dsm-icon-libraries-disabled-notice">
			<p>
				<strong><?php esc_html_e( 'Divi Supreme Pro:', 'dsm-supreme-modules-pro-for-divi' ); ?></strong>
				<?php
				echo ' ';
				echo wp_kses(
					sprintf(
						/* translators: %s: settings URL. */
						__(
							'This site has pages or layouts using Tabler or Phosphor icons, but %s is turned off. Those icons will not display on the frontend until you enable it.',
							'dsm-supreme-modules-pro-for-divi'
						),
						'<a href="' . esc_url( $settings_url ) . '">' . esc_html__( 'Icon Libraries', 'dsm-supreme-modules-pro-for-divi' ) . '</a>'
					),
					array(
						'a' => array(
							'href' => array(),
						),
					)
				);
				?>
			</p>
		</div>
		<?php
	}

	/**
	 * AJAX dismiss.
	 *
	 * @return void
	 */
	public static function ajax_dismiss(): void {
		check_ajax_referer( 'dsm_dismiss_icon_libraries_disabled_notice', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( null, 403 );
		}

		update_user_meta( get_current_user_id(), 'dsm_dismissed_icon_libraries_disabled_notice', '1' );

		wp_send_json_success();
	}
}

DisabledAdminNotice::register();
