<?php
/**
 * Central hook seam for custom icon library types on `process_font_icon` resolution.
 *
 * Divi 5.17 Icon Manager documents third-party libraries through:
 * `divi_icon_library_font_icon_types` and `divi_icon_library_font_icon_families`
 * (JS: `divi.iconLibrary.fontIcon.types` / `.families`, plus `iconList` and filter options).
 * There is no filter on Icon Manager collections. Adding these libraries as
 * `divi_icon_collection` posts would change stored icon ids, so they stay on the
 * font-icon filters and show under the picker's Custom Icons group.
 *
 * Divi does not filter the return value of `process_font_icon()`. On Divi 5.16
 * and older, DSM webfont icons stay null there so the `<i class="…">` bridge paints
 * them. Divi 5.17+ (`Utils::get_icon_font_family()`) looks icons up in
 * `divi_icon_library_font_icon_list` and paints `content` + `font-family`. That
 * catalog filter is a no-op until that method exists, so saved icon JSON is unchanged.
 *
 * - PHP: `divi_module_wrapper_render` → IconModuleRenderBridge (frontend + VB SSR)
 * - JS:  `divi.module.wrapper.render` → module-icon-vb-wrapper.js (Visual Builder canvas)
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Extensions\IconLibraries;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Registers extension-side filters for icon resolution and documents the hook contract.
 */
final class IconProcessFontIconBridge {

	/**
	 * Whether this Divi build paints font icons through get_icon_font_family().
	 *
	 * Divi 5.17 introduced that method together with the icon catalog lookup.
	 * Older builds never call it. Do not parse a version string.
	 *
	 * @return bool
	 */
	public static function uses_icon_manager_font_family(): bool {
		return class_exists( '\ET\Builder\Packages\IconLibrary\IconFont\Utils' )
			&& method_exists( '\ET\Builder\Packages\IconLibrary\IconFont\Utils', 'get_icon_font_family' );
	}

	/**
	 * Register Divi icon catalog filters.
	 *
	 * @return void
	 */
	public static function register(): void {
		add_filter( 'divi_icon_library_font_icon_types', array( self::class, 'filter_font_icon_types' ) );
		add_filter( 'divi_icon_library_font_icon_families', array( self::class, 'filter_font_icon_families' ) );
		add_filter( 'divi_icon_library_font_icon_list', array( self::class, 'filter_font_icon_list' ) );
		add_filter( 'divi_icon_library_process_font_icon', array( self::class, 'filter_process_font_icon' ), 10, 4 );
	}

	/**
	 * Register enabled library ids with Divi's native font icon type list.
	 *
	 * @param array<int, string> $types Divi default types (`divi`, `fa`, …).
	 * @return array<int, string>
	 */
	public static function filter_font_icon_types( array $types ): array {
		if ( ! function_exists( 'dsm_is_icon_libraries_extension_enabled' ) || ! dsm_is_icon_libraries_extension_enabled() ) {
			return $types;
		}

		foreach ( IconLibraryRegistry::enabled() as $library ) {
			$types[] = $library->get_id();
		}

		return array_values( array_unique( $types ) );
	}

	/**
	 * Map each enabled library id to its default CSS font-family.
	 *
	 * Divi 5.17 `Utils::get_icon_font_family()` applies
	 * `divi_icon_library_font_icon_families`. Older Divi builds never call that
	 * filter; registering it is a no-op there and does not change saved icon JSON.
	 * Variant-specific faces (Phosphor weights, Tabler filled) still render through
	 * the webfont `<i>` class, not this single family.
	 *
	 * @param array<string, string> $families Type → font-family map.
	 * @return array<string, string>
	 */
	public static function filter_font_icon_families( array $families ): array {
		if ( ! function_exists( 'dsm_is_icon_libraries_extension_enabled' ) || ! dsm_is_icon_libraries_extension_enabled() ) {
			return $families;
		}

		foreach ( IconLibraryRegistry::enabled() as $library ) {
			$library_id = $library->get_id();

			if ( isset( $families[ $library_id ] ) && is_string( $families[ $library_id ] ) && '' !== $families[ $library_id ] ) {
				continue;
			}

			$family = $library->get_picker_webfont_family(
				$library->get_sample_icon_id(),
				$library->get_default_variant()
			);

			if ( '' === $family ) {
				continue;
			}

			$families[ $library_id ] = $family;
		}

		return $families;
	}

	/**
	 * Append Supreme webfont rows to Divi's icon catalog on Divi 5.17+.
	 *
	 * `Utils::process_font_icon()` matches `unicode`, `fontWeight`, and `styles`.
	 * Icon style declarations ask for the `&#xHHHH;` unicode; button icons ask for
	 * `decodedUnicode`. Rows are omitted until `get_icon_font_family()` exists, so
	 * Divi 5.16 still gets a null glyph and the `<i>` bridge keeps painting.
	 *
	 * @param array<int, array<string, mixed>> $icons Divi icon catalog.
	 * @return array<int, array<string, mixed>>
	 */
	public static function filter_font_icon_list( array $icons ): array {
		if ( ! self::uses_icon_manager_font_family() ) {
			return $icons;
		}

		if ( ! ExtensionSettings::is_extension_enabled() ) {
			return $icons;
		}

		foreach ( $icons as $icon ) {
			if ( is_array( $icon ) && isset( $icon['dsmIconId'], $icon['decodedUnicode'] ) ) {
				return $icons;
			}
		}

		foreach ( IconLibraryRegistry::get_divi_icon_list_rows_for_enabled() as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}

			$entity = (string) ( $row['unicode'] ?? '' );

			if ( '' === IconCodepointIndex::hex_from_entity( $entity ) ) {
				continue;
			}

			$decoded = html_entity_decode( $entity, ENT_QUOTES, 'UTF-8' );

			if ( '' === $decoded || $decoded === $entity ) {
				continue;
			}

			$row['decodedUnicode'] = $decoded;
			$row['fontWeight']     = (int) ( $row['fontWeight'] ?? 400 );

			if ( ! isset( $row['styles'] ) || ! is_array( $row['styles'] ) ) {
				$row['styles'] = array( (string) ( $row['dsmLibraryId'] ?? '' ) );
			}

			$icons[] = $row;
		}

		return $icons;
	}

	/**
	 * Extension hook for `dsm_process_font_icon()` / future callers.
	 *
	 * Stays null for Supreme library icons on every Divi version. Divi 5.17 reads
	 * the catalog above inside `Utils::process_font_icon()` and does not call this
	 * filter. Divi 5.16 still skips CSS `content` and uses the `<i>` bridge.
	 *
	 * @param string|null                 $result             Resolved glyph from Divi Utils (or null).
	 * @param array<string, mixed>|string $icon               Icon picker settings.
	 * @param bool                        $is_font_icons_down Down-icon list flag.
	 * @param bool                        $is_unicode         Unicode output flag.
	 * @return string|null
	 */
	public static function filter_process_font_icon( $result, $icon, bool $is_font_icons_down, bool $is_unicode ): ?string {
		unset( $is_font_icons_down, $is_unicode );

		if ( ! is_array( $icon ) ) {
			return is_string( $result ) ? $result : null;
		}

		if (
			ExtensionSettings::is_extension_enabled()
			&& IconLibraryRegistry::is_dsm_library_icon( $icon )
		) {
			return null;
		}

		return is_string( $result ) ? $result : null;
	}
}
