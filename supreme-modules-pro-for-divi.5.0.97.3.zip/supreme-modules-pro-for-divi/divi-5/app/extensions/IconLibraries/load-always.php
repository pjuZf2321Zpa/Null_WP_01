<?php
/**
 * Icon Libraries — always-loaded bootstrap (extension on or off).
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

$icon_libraries_dir = __DIR__;

require_once $icon_libraries_dir . '/IconLibraryInterface.php';
require_once $icon_libraries_dir . '/AbstractFileIconLibrary.php';
require_once $icon_libraries_dir . '/IconLibraryBrandMark.php';
require_once $icon_libraries_dir . '/Libraries/TablerLibrary.php';
require_once $icon_libraries_dir . '/Libraries/PhosphorLibrary.php';
require_once $icon_libraries_dir . '/Libraries/LucideLibrary.php';
require_once $icon_libraries_dir . '/Libraries/HeroiconsLibrary.php';
require_once $icon_libraries_dir . '/IconLibraryRegistry.php';
require_once $icon_libraries_dir . '/WebfontAssetLoader.php';
require_once $icon_libraries_dir . '/IconAttrBreakpoint.php';
require_once $icon_libraries_dir . '/IconGlyphRenderer.php';
require_once $icon_libraries_dir . '/IconModuleRenderBridge.php';
require_once $icon_libraries_dir . '/LegacyModuleIconStyles.php';
require_once $icon_libraries_dir . '/PostContentIconScanner.php';
require_once $icon_libraries_dir . '/ProcessFontIconHelper.php';
require_once $icon_libraries_dir . '/DisabledAdminNotice.php';
