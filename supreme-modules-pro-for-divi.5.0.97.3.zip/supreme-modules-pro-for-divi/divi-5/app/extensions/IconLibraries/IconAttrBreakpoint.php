<?php
/**
 * Shared Icon Libraries resolver for Divi 5 icon-picker innerContent trees.
 *
 * Storage: innerContent.{desktop|tablet|phone|tabletWide|phoneWide}.value.
 * Cascade from the requested breakpoint: phone → tablet → desktop when a leaf is empty.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Extensions\IconLibraries;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Resolves icon picker leaves and toggle scalars across Divi 5 breakpoints.
 */
final class IconAttrBreakpoint {

	/**
	 * Coarse breakpoints used for frontend per-viewport glyphs.
	 *
	 * @var string[]
	 */
	public const BREAKPOINTS = array( 'desktop', 'tablet', 'phone' );

	/**
	 * Coarse breakpoint for cascade (desktop / tablet / phone).
	 *
	 * @param string $raw Builder view / breakpoint name.
	 * @return string
	 */
	public static function normalize_breakpoint( string $raw ): string {
		if ( 'tablet' === $raw || 'tabletWide' === $raw ) {
			return 'tablet';
		}

		if ( 'phone' === $raw || 'phoneWide' === $raw ) {
			return 'phone';
		}

		return 'desktop';
	}

	/**
	 * Fallback ladder from the requested breakpoint downward.
	 *
	 * @param string $breakpoint Requested breakpoint.
	 * @return string[]
	 */
	public static function fallback_ladder( string $breakpoint ): array {
		$target = self::normalize_breakpoint( $breakpoint );

		if ( 'phone' === $target ) {
			return array( 'phone', 'phoneWide', 'tablet', 'tabletWide', 'desktop' );
		}

		if ( 'tablet' === $target ) {
			return array( 'tablet', 'tabletWide', 'desktop' );
		}

		return array( 'desktop' );
	}

	/**
	 * Whether a stored picker value has a usable glyph (DSM or native).
	 *
	 * @param mixed $value Candidate leaf.
	 * @return bool
	 */
	public static function is_usable_icon_leaf( $value ): bool {
		if ( ! is_array( $value ) ) {
			return false;
		}

		$unicode = isset( $value['unicode'] ) ? trim( (string) $value['unicode'] ) : '';

		return '' !== $unicode;
	}

	/**
	 * Stable identity for comparing resolved leaves across breakpoints.
	 *
	 * @param array<string, mixed> $icon Icon picker leaf.
	 * @return string
	 */
	public static function icon_identity( array $icon ): string {
		$type    = sanitize_key( (string) ( $icon['type'] ?? '' ) );
		$unicode = sanitize_text_field( (string) ( $icon['unicode'] ?? '' ) );
		$variant = sanitize_key( (string) ( $icon['variant'] ?? '' ) );
		$weight  = sanitize_text_field( (string) ( $icon['weight'] ?? '' ) );

		return $type . ':' . $unicode . ':' . $variant . ':' . $weight;
	}

	/**
	 * Icon leaf for the requested breakpoint, falling back when a leaf is empty.
	 *
	 * @param array<string, mixed>|null $inner_content Icon attr innerContent tree.
	 * @param string                    $breakpoint    Requested breakpoint.
	 * @return array<string, mixed>|null
	 */
	public static function leaf_from_inner( ?array $inner_content, string $breakpoint = 'desktop' ): ?array {
		if ( ! is_array( $inner_content ) ) {
			return null;
		}

		if ( self::is_usable_icon_leaf( $inner_content ) ) {
			return $inner_content;
		}

		$legacy = $inner_content['value'] ?? null;

		if ( is_array( $legacy ) && self::is_usable_icon_leaf( $legacy ) ) {
			return $legacy;
		}

		foreach ( self::fallback_ladder( $breakpoint ) as $key ) {
			$leaf = $inner_content[ $key ]['value'] ?? null;

			if ( is_array( $leaf ) && self::is_usable_icon_leaf( $leaf ) ) {
				return $leaf;
			}
		}

		return null;
	}

	/**
	 * First usable leaf walking desktop → tablet → phone (single-glyph contexts).
	 *
	 * @param array<string, mixed>|null $inner_content Icon attr innerContent tree.
	 * @return array<string, mixed>|null
	 */
	public static function first_usable_icon_leaf( ?array $inner_content ): ?array {
		foreach ( self::BREAKPOINTS as $breakpoint ) {
			$leaf = self::leaf_from_inner( $inner_content, $breakpoint );

			if ( is_array( $leaf ) ) {
				return $leaf;
			}
		}

		return null;
	}

	/**
	 * Cascaded leaf per coarse breakpoint (null when that viewport has no icon).
	 *
	 * @param array<string, mixed>|null $inner_content Icon attr innerContent tree.
	 * @return array<string, array<string, mixed>|null>
	 */
	public static function resolved_icon_leaves( ?array $inner_content ): array {
		$out = array();

		foreach ( self::BREAKPOINTS as $breakpoint ) {
			$leaf               = self::leaf_from_inner( $inner_content, $breakpoint );
			$out[ $breakpoint ] = is_array( $leaf ) ? $leaf : null;
		}

		return $out;
	}

	/**
	 * Icon leaf from a module attr key.
	 *
	 * @param array<string, mixed> $module_attrs Module attrs.
	 * @param string               $attr_key     Icon attr key.
	 * @param string               $breakpoint   Requested breakpoint.
	 * @return array<string, mixed>|null
	 */
	public static function leaf_from_module_attrs( array $module_attrs, string $attr_key, string $breakpoint = 'desktop' ): ?array {
		$inner = $module_attrs[ $attr_key ]['innerContent'] ?? null;

		return self::leaf_from_inner( is_array( $inner ) ? $inner : null, $breakpoint );
	}

	/**
	 * Whether any cascaded breakpoint holds a DSM library icon.
	 *
	 * @param array<string, mixed>|null $inner_content Icon attr innerContent tree.
	 * @return bool
	 */
	public static function inner_has_dsm_library_icon( ?array $inner_content ): bool {
		foreach ( self::BREAKPOINTS as $breakpoint ) {
			$leaf = self::leaf_from_inner( $inner_content, $breakpoint );

			if ( is_array( $leaf ) && IconLibraryRegistry::is_dsm_library_icon( $leaf ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Scalar innerContent value for a breakpoint (empty inherits).
	 *
	 * @param array<string, mixed> $inner_content Attr innerContent tree.
	 * @param string               $breakpoint    Requested breakpoint.
	 * @return string
	 */
	public static function scalar_from_inner( array $inner_content, string $breakpoint ): string {
		foreach ( self::fallback_ladder( $breakpoint ) as $key ) {
			$raw = $inner_content[ $key ]['value'] ?? null;

			if ( is_string( $raw ) && '' !== $raw ) {
				return $raw;
			}
		}

		return '';
	}

	/**
	 * True when any coarse breakpoint resolves to `on`.
	 *
	 * @param array<string, mixed> $attrs      Module attrs.
	 * @param string               $toggle_key Toggle attr key.
	 * @return bool
	 */
	public static function is_toggle_on_any( array $attrs, string $toggle_key ): bool {
		$inner = $attrs[ $toggle_key ]['innerContent'] ?? null;

		if ( ! is_array( $inner ) ) {
			return false;
		}

		foreach ( self::BREAKPOINTS as $breakpoint ) {
			if ( 'on' === self::scalar_from_inner( $inner, $breakpoint ) ) {
				return true;
			}
		}

		return false;
	}
}
