<?php
/**
 * Shared native pseudo-element icon CSS + custom-class icon host markup.
 *
 * Mirrors JS {@see buildLegacyPseudoIconFontCss}. Divi/FA icons keep `content` on
 * `::before` / `::after`. On Divi 5.17 a Supreme icon writes `font-family` only, so a
 * text glyph inside `.et-pb-icon` (Card) uses the webfont instead of ETmodules.
 * Divi 5.16 still returns an empty declaration and paints with the `<i>` bridge.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Extensions\IconLibraries;

use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Legacy module icon pseudo CSS and SSR host helpers.
 */
final class LegacyModuleIconStyles {

	/**
	 * CommonStyle declaration for icon font-family and native pseudo content.
	 *
	 * @param array<string, mixed> $params CommonStyle callback params.
	 * @return string
	 */
	public static function build_pseudo_icon_declaration( array $params ): string {
		$icon_attr = is_array( $params['attrValue'] ?? null ) ? $params['attrValue'] : array();

		if (
			ExtensionSettings::is_extension_enabled()
			&& IconLibraryRegistry::is_dsm_library_icon( $icon_attr )
		) {
			return self::build_dsm_icon_font_family_declaration( $icon_attr );
		}

		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
				'important'  => array(
					'font-family' => true,
				),
			)
		);

		if ( isset( $icon_attr['type'] ) && is_string( $icon_attr['type'] ) && '' !== $icon_attr['type'] ) {
			$font_family = 'ETmodules';

			if ( IconProcessFontIconBridge::uses_icon_manager_font_family() ) {
				$resolved_family = IconGlyphRenderer::icon_manager_font_family( $icon_attr );

				if ( '' !== $resolved_family ) {
					$font_family = $resolved_family;
				}
			} elseif ( 'fa' === $icon_attr['type'] ) {
				$font_family = 'FontAwesome';
			}

			$style_declarations->add( 'font-family', "'" . $font_family . "'" );
		}

		if ( isset( $icon_attr['weight'] ) && '' !== $icon_attr['weight'] ) {
			$style_declarations->add( 'font-weight', (string) $icon_attr['weight'] );
		}

		$css_content = self::build_native_icon_css_content( $icon_attr );

		if ( '' !== $css_content ) {
			// Match Divi Icon.php: quoted CSS escape (e.g. '\f073'), never raw &#…; entities.
			$style_declarations->add( 'content', "'" . $css_content . "'" );
		}

		return $style_declarations->value();
	}

	/**
	 * Font-family (and weight) for a Supreme icon whose glyph is a text node.
	 *
	 * `content` is omitted. Card and similar modules target the `.et-pb-icon`
	 * element, where `content` does not paint, and a `::before` `content` value
	 * would stack on the manager glyph. Divi 5.16 has no icon-manager API, so
	 * this stays empty and the `<i>` bridge keeps painting.
	 *
	 * @param array<string, mixed> $icon_attr Icon picker leaf.
	 * @return string
	 */
	private static function build_dsm_icon_font_family_declaration( array $icon_attr ): string {
		if ( ! IconProcessFontIconBridge::uses_icon_manager_font_family() ) {
			return '';
		}

		$family = IconGlyphRenderer::icon_manager_font_family( $icon_attr );

		if ( '' === $family ) {
			return '';
		}

		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
				'important'  => array(
					'font-family' => true,
				),
			)
		);

		$style_declarations->add( 'font-family', '"' . $family . '"' );

		$weight = preg_replace( '/[^0-9]/', '', (string) ( $icon_attr['weight'] ?? '' ) );

		if ( is_string( $weight ) && '' !== $weight ) {
			$style_declarations->add( 'font-weight', $weight );
		}

		return $style_declarations->value();
	}

	/**
	 * Build a CSS `content` value for a native Divi/FA icon (no surrounding quotes).
	 *
	 * D4→D5 `convertFontIcon` often stores decimal entities (`&#61555;`) while the icon
	 * list / `Utils::escape_font_icon()` only match hex (`&#xf073;` → `\f073`). Without
	 * normalization, `content` can become the literal entity string (glyphs show as text)
	 * or invalid quoting that breaks later rules.
	 *
	 * @param array<string, mixed> $icon_attr Icon picker leaf.
	 * @return string CSS escape or decoded glyph safe for `content: '…'`, or empty.
	 */
	public static function build_native_icon_css_content( array $icon_attr ): string {
		if ( ! isset( $icon_attr['unicode'] ) || ! is_string( $icon_attr['unicode'] ) || '' === $icon_attr['unicode'] ) {
			return '';
		}

		$normalized = self::normalize_native_icon_unicode_attr( $icon_attr );

		// Prefer unicode HTML form + escape (same as Divi Icon style declaration).
		$unicode = Utils::process_font_icon( $normalized, false, true );

		if ( ! is_string( $unicode ) || '' === $unicode ) {
			$unicode = (string) $normalized['unicode'];
		}

		$escaped = self::escape_icon_unicode_for_css_content( $unicode );

		if ( '' !== $escaped ) {
			return $escaped;
		}

		// Last resort: decoded glyph from the icon list.
		$decoded = Utils::process_font_icon( $normalized );

		if ( ! is_string( $decoded ) || '' === $decoded ) {
			return '';
		}

		$escaped_decoded = Utils::escape_font_icon( $decoded );

		return is_string( $escaped_decoded ) ? $escaped_decoded : '';
	}

	/**
	 * Normalize D4 decimal HTML entities to hex so icon-list lookup can succeed.
	 *
	 * @param array<string, mixed> $icon_attr Icon picker leaf.
	 * @return array<string, mixed>
	 */
	private static function normalize_native_icon_unicode_attr( array $icon_attr ): array {
		$unicode = $icon_attr['unicode'] ?? '';

		if ( ! is_string( $unicode ) || '' === $unicode ) {
			return $icon_attr;
		}

		if ( preg_match( '/^&(?:amp;)?#(\d+);$/', $unicode, $matches ) ) {
			$icon_attr['unicode'] = sprintf( '&#x%x;', (int) $matches[1] );
		}

		return $icon_attr;
	}

	/**
	 * Convert an icon unicode string to a CSS `content` payload (no quotes).
	 *
	 * @param string $unicode Icon unicode (`&#xf073;`, `&#61555;`, or decoded char).
	 * @return string
	 */
	private static function escape_icon_unicode_for_css_content( string $unicode ): string {
		$unicode = trim( $unicode );

		if ( '' === $unicode ) {
			return '';
		}

		// Decimal entity — Divi's escape_font_icon() only handles &#x…; / &amp;#x…;.
		if ( preg_match( '/^&(?:amp;)?#(\d+);$/', $unicode, $matches ) ) {
			return '\\' . dechex( (int) $matches[1] );
		}

		$escaped = Utils::escape_font_icon( $unicode );

		return is_string( $escaped ) ? $escaped : '';
	}

	/**
	 * Render icon host markup for modules that use custom host classes (Breadcrumbs, etc.).
	 *
	 * @param array<string, mixed>|null $icon_settings Icon picker leaf.
	 * @param string                    $host_class    Module-specific host class.
	 * @return string
	 */
	public static function render_custom_icon_host( ?array $icon_settings, string $host_class ): string {
		$host_class = sanitize_html_class( $host_class );

		if ( '' === $host_class ) {
			return '';
		}

		if ( ! is_array( $icon_settings ) || '' === sanitize_key( (string) ( $icon_settings['unicode'] ?? '' ) ) ) {
			return sprintf(
				'<span class="%s" aria-hidden="true"></span>',
				esc_attr( $host_class )
			);
		}

		if ( ! ExtensionSettings::is_extension_enabled() ) {
			return sprintf(
				'<span class="%s" aria-hidden="true"></span>',
				esc_attr( $host_class )
			);
		}

		if ( IconLibraryRegistry::is_dsm_library_icon( $icon_settings ) ) {
			$webfont_markup = IconGlyphRenderer::render_icon_span(
				$icon_settings,
				array( $host_class )
			);

			if ( '' !== $webfont_markup ) {
				if ( ! str_contains( $webfont_markup, 'aria-hidden' ) ) {
					$webfont_markup = preg_replace(
						'/<span\b/i',
						'<span aria-hidden="true"',
						$webfont_markup,
						1
					);

					if ( ! is_string( $webfont_markup ) ) {
						return IconGlyphRenderer::render_icon_span( $icon_settings, array( $host_class ) );
					}
				}

				IconLibraryRegistry::enqueue_webfonts_for_icons(
					array(
						IconAttrCollector::icon_cache_key( $icon_settings ) => $icon_settings,
					)
				);

				return $webfont_markup;
			}
		}

		if ( IconGlyphRenderer::is_native_font_icon( $icon_settings ) ) {
			$native_markup = IconGlyphRenderer::render_native_icon_span(
				$icon_settings,
				array( $host_class )
			);

			if ( '' !== $native_markup ) {
				return $native_markup;
			}
		}

		// Native Divi / FA fallback: empty host — pseudo-element CSS on the module supplies the glyph.
		return sprintf(
			'<span class="%s" aria-hidden="true"></span>',
			esc_attr( $host_class )
		);
	}
}
