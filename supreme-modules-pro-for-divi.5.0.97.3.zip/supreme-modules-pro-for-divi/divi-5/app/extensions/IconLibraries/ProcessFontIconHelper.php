<?php
/**
 * Bridges Divi Utils::process_font_icon() for optional non-module callers.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Extensions\IconLibraries {

	use ET\Builder\Packages\IconLibrary\IconFont\Utils;

	if ( ! defined( 'ABSPATH' ) ) {
		die( 'Direct access forbidden.' );
	}

	/**
	 * Wrapper around Divi icon resolution with DSM library short-circuit.
	 */
	final class ProcessFontIconHelper {

		/**
		 * Process icon settings — delegates to Divi for font icons, null for DSM webfont libraries.
		 *
		 * @param array<string, mixed>|string|null $icon               Icon picker leaf.
		 * @param bool                             $is_font_icons_down Passed to Divi Utils.
		 * @param bool                             $is_unicode         Passed to Divi Utils.
		 * @return string|null
		 */
		public static function process( $icon, bool $is_font_icons_down = false, bool $is_unicode = false ): ?string {
			if ( is_string( $icon ) ) {
				return Utils::process_font_icon( $icon, $is_font_icons_down, $is_unicode );
			}

			if ( ! is_array( $icon ) ) {
				return null;
			}

			if (
			ExtensionSettings::is_extension_enabled()
			&& IconLibraryRegistry::is_dsm_library_icon( $icon )
			) {
				return null;
			}

			$result = Utils::process_font_icon( $icon, $is_font_icons_down, $is_unicode );

			/**
			 * Filter resolved font icon glyph (Divi has no native equivalent).
			 *
			 * @param string|null                 $result             Decoded unicode or null.
			 * @param array<string, mixed>|string $icon               Icon picker settings.
			 * @param bool                        $is_font_icons_down Passed to Divi Utils.
			 * @param bool                        $is_unicode         Passed to Divi Utils.
			 */
			return apply_filters( 'divi_icon_library_process_font_icon', $result, $icon, $is_font_icons_down, $is_unicode );
		}
	}

}

namespace {

	use DiviSupreme\Extensions\IconLibraries\IconGlyphRenderer;
	use DiviSupreme\Extensions\IconLibraries\PostContentIconScanner;
	use DiviSupreme\Extensions\IconLibraries\ProcessFontIconHelper;
	use DiviSupreme\Extensions\IconLibraries\WebfontAssetLoader;

	if ( ! function_exists( 'dsm_process_font_icon' ) ) {
		/**
		 * Dsm process font icon.
		 *
		 * @param array<string, mixed>|string|null $icon Icon settings.
		 * @param bool                             $is_font_icons_down Down-icons list flag.
		 * @param bool                             $is_unicode         Unicode output flag.
		 * @return string|null
		 */
		function dsm_process_font_icon( $icon, bool $is_font_icons_down = false, bool $is_unicode = false ): ?string {
			return ProcessFontIconHelper::process( $icon, $is_font_icons_down, $is_unicode );
		}
	}

	if ( ! function_exists( 'dsm_icon_libraries_collect_icons_from_post_content' ) ) {
		/**
		 * Dsm icon libraries collect icons from post content.
		 *
		 * @param int $post_id Post ID.
		 * @return array<string, array<string, mixed>>
		 */
		function dsm_icon_libraries_collect_icons_from_post_content( int $post_id ): array {
			return PostContentIconScanner::collect_from_post_content( $post_id );
		}
	}

	if ( ! function_exists( 'dsm_icon_libraries_render_glyph_markup' ) ) {
		/**
		 * Dsm icon libraries render glyph markup.
		 *
		 * @return string
		 * @param array $icon_settings Icon settings.
		 */
		function dsm_icon_libraries_render_glyph_markup( array $icon_settings ): string {
			return IconGlyphRenderer::render_glyph_markup( $icon_settings );
		}
	}

	if ( ! function_exists( 'dsm_icon_libraries_render_icon_span' ) ) {
		/**
		 * Dsm icon libraries render icon span.
		 *
		 * @return string
		 * @param array $icon_settings Icon settings.
		 * @param array $extra_classes Extra classes.
		 */
		function dsm_icon_libraries_render_icon_span( array $icon_settings, array $extra_classes = array() ): string {
			return IconGlyphRenderer::render_icon_span( $icon_settings, $extra_classes );
		}
	}

	if ( ! function_exists( 'dsm_icon_libraries_data_attrs_from_icon' ) ) {
		/**
		 * Dsm icon libraries data attrs from icon.
		 *
		 * @return array<string, string>
		 * @param ?array $icon Icon.
		 */
		function dsm_icon_libraries_data_attrs_from_icon( ?array $icon ): array {
			return IconGlyphRenderer::data_attrs_from_icon( $icon );
		}
	}

	if ( ! function_exists( 'dsm_icon_libraries_enqueue_webfonts_for_icons' ) ) {
		/**
		 * Dsm icon libraries enqueue webfonts for icons.
		 *
		 * @return void
		 * @param array $icons Icons.
		 */
		function dsm_icon_libraries_enqueue_webfonts_for_icons( array $icons ): void {
			WebfontAssetLoader::enqueue_for_icons( $icons );
		}
	}

	if ( ! function_exists( 'dsm_icon_libraries_normalize_variant' ) ) {
		/**
		 * Dsm icon libraries normalize variant.
		 *
		 * @return string
		 * @param string $library_id Library id.
		 * @param string $variant    Variant.
		 */
		function dsm_icon_libraries_normalize_variant( string $library_id, string $variant ): string {
			return WebfontAssetLoader::normalize_variant( $library_id, $variant );
		}
	}
}
