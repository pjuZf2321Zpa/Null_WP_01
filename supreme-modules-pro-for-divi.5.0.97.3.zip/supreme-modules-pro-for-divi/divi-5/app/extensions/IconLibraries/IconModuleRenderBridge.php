<?php
/**
 * Universal module render bridge — DSM webfont icons on any module with Icon Picker attrs.
 *
 * @see https://dev.elegantthemes.com/docs/tutorials/module/advanced/customize-module-settings-output/rendering-additional-module-styles
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Extensions\IconLibraries;

use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Layout\Components\ModuleElements\ModuleElements;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\ModuleUtils\ModuleUtils;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Injects `.et-pb-icon` hosts with webfont `<i>` glyphs for all modules using DSM libraries.
 */
final class IconModuleRenderBridge {

	/**
	 * Register wrapper and Mega Menu child render filters.
	 *
	 * @return void
	 */
	public static function register(): void {
		add_filter( 'divi_module_wrapper_render', array( self::class, 'filter_wrapper_render' ), 10, 2 );
		// Mega Menu children skip Module::render() — wrapper filter never runs for them.
		add_filter( 'render_block_dsm/mega-menu-child', array( self::class, 'filter_mega_menu_child_block' ), 10, 2 );
	}

	/**
	 * Present-only webfont CSS for DSM library icons discovered during module render.
	 *
	 * Theme Builder / CPT layouts often resolve after early {@see IconLibraries::maybe_enqueue_frontend_assets()}.
	 *
	 * @param array<int, array<string, mixed>> $unique_icons Unique icon settings from module attrs.
	 * @return void
	 */
	private static function enqueue_webfonts_for_unique_icons( array $unique_icons ): void {
		if ( array() === $unique_icons ) {
			return;
		}

		$map = array();

		foreach ( $unique_icons as $icon ) {
			if ( ! is_array( $icon ) || ! IconLibraryRegistry::is_dsm_library_icon( $icon ) ) {
				continue;
			}

			$map[ IconAttrCollector::icon_cache_key( $icon ) ] = $icon;
		}

		if ( array() === $map ) {
			return;
		}

		IconLibraryRegistry::enqueue_webfonts_for_icons( $map );
	}

	/**
	 * Add DSM webfont hosts when a module uses library icons.
	 *
	 * @param string               $module_wrapper Module wrapper HTML.
	 * @param array<string, mixed> $args           Filter arguments.
	 * @return string
	 */
	public static function filter_wrapper_render( string $module_wrapper, array $args ): string {
		if ( ! ExtensionSettings::is_extension_enabled() ) {
			return et_core_esc_previously( $module_wrapper );
		}

		$module_attrs    = is_array( $args['attrs'] ?? null ) ? $args['attrs'] : array();
		$module_elements = $args['elements'] ?? null;
		$module_name     = (string) ( $args['name'] ?? '' );
		$has_own_icons   = IconAttrCollector::has_dsm_icons( $module_attrs );
		$is_mega_parent  = 'dsm/mega-menu' === $module_name;

		// Parent Mega Menu often has no library icons of its own — children do.
		if ( ! $has_own_icons && ! $is_mega_parent ) {
			return et_core_esc_previously( $module_wrapper );
		}

		if ( ! $module_elements instanceof ModuleElements ) {
			return et_core_esc_previously( $module_wrapper );
		}

		if ( $has_own_icons ) {
			$icons        = IconAttrCollector::collect_dsm_icons( $module_attrs );
			$unique_icons = IconAttrCollector::collect_unique_dsm_icons( $module_attrs );

			self::enqueue_webfonts_for_unique_icons( $unique_icons );

			$module_wrapper = self::prepare_icon_hosts_in_html(
				$module_wrapper,
				$icons,
				$module_name,
				$module_attrs,
				$args
			);
			self::add_frontend_icon_styles( $args, $unique_icons, $module_elements );
		} elseif ( $is_mega_parent ) {
			$module_wrapper = self::inject_mega_menu_children_from_store( $module_wrapper, $args );
		}

		return et_core_esc_previously( $module_wrapper );
	}

	/**
	 * Ensure `.et-pb-icon` hosts exist and carry DSM data attributes.
	 *
	 * @param string                           $module_wrapper Module HTML.
	 * @param array<int, array<string, mixed>> $icons          Collected icon settings (ordered).
	 * @param string                           $module_name    Registered module name.
	 * @param array<string, mixed>             $module_attrs   Module attrs.
	 * @param array<string, mixed>             $args           Wrapper filter args.
	 * @return string
	 */
	private static function prepare_icon_hosts_in_html(
		string $module_wrapper,
		array $icons,
		string $module_name,
		array $module_attrs,
		array $args = array()
	): string {
		if ( array() === $icons && 'dsm/mega-menu' !== $module_name ) {
			return $module_wrapper;
		}

		$module_wrapper = self::inject_carousel_navigation_icons( $module_wrapper, $module_name, $module_attrs );

		if ( self::is_mega_menu_module( $module_name ) ) {
			return self::inject_mega_menu_icons( $module_wrapper, $module_name, $module_attrs, $args );
		}

		if ( ! str_contains( $module_wrapper, 'et-pb-icon' ) ) {
			$module_wrapper = self::inject_missing_icon_hosts( $module_wrapper, $icons, $module_name, $module_attrs );
		}

		$module_wrapper = self::inject_spans_into_empty_icon_wraps( $module_wrapper, $icons );
		$module_wrapper = self::tag_untagged_icon_spans( $module_wrapper, $icons );
		$module_wrapper = self::replace_slug_text_icon_spans( $module_wrapper, $icons );
		$module_wrapper = self::inject_divi_button_icon( $module_wrapper, $module_attrs );

		return $module_wrapper;
	}

	/**
	 * Inject icon markup when core modules skip output (process_font_icon returns null).
	 *
	 * @param string                           $html         Module HTML.
	 * @param array<int, array<string, mixed>> $icons        Collected icon settings (ordered).
	 * @param string                           $module_name  Registered module name.
	 * @param array<string, mixed>             $module_attrs Module attrs.
	 * @return string
	 */
	private static function inject_missing_icon_hosts(
		string $html,
		array $icons,
		string $module_name,
		array $module_attrs
	): string {
		if ( ! isset( $icons[0] ) ) {
			return $html;
		}

		switch ( $module_name ) {
			case 'divi/blurb':
				if ( ! self::blurb_uses_icon_mode( $module_attrs ) ) {
					return $html;
				}

				return self::inject_blurb_icon_container( $html, $icons[0], $module_attrs );
			case 'divi/icon-list-item':
				return self::inject_icon_list_item_icon( $html, $icons[0] );
			default:
				return $html;
		}
	}

	/**
	 * Insert webfont glyphs into Divi button elements on any module.
	 *
	 * Button icons paint on `:before` / `:after` via `Utils::process_font_icon()`.
	 * DSM libraries resolve to null there. Native Divi and third-party modules
	 * store the control at `decoration.button.desktop.value.icon` (Call to Action
	 * and Divi Button both use `button.decoration.button`).
	 *
	 * @param string               $html         Module HTML.
	 * @param array<string, mixed> $module_attrs Module attrs.
	 * @return string
	 */
	private static function inject_divi_button_icon( string $html, array $module_attrs ): string {
		if ( ! str_contains( $html, 'et_pb_button' ) ) {
			return $html;
		}

		$icons = self::collect_desktop_button_icons( $module_attrs );

		if ( array() === $icons ) {
			return $html;
		}

		$index = 0;

		$replaced = preg_replace_callback(
			'/(<(?:a|button)\b[^>]*\bet_pb_button\b[^>]*>)(.*?)(<\/(?:a|button)>)/is',
			static function ( array $matches ) use ( &$index, $icons ): string {
				if ( ! isset( $icons[ $index ] ) || str_contains( $matches[0], 'dsm-button-webfont-icon' ) ) {
					return $matches[0];
				}

				if ( preg_match( '/\bdata-icon=(["\'])([^"\']+)\1/', $matches[1] ) ) {
					return $matches[0];
				}

				$control  = $icons[ $index ];
				$settings = is_array( $control ) && is_array( $control['settings'] ?? null ) ? $control['settings'] : null;

				if ( is_array( $settings ) && IconGlyphRenderer::icon_manager_can_paint( $settings ) ) {
					++$index;

					return $matches[0];
				}

				$markup = self::button_webfont_glyph_markup( $icons[ $index ] );

				if ( '' === $markup ) {
					return $matches[0];
				}

				++$index;

				return $matches[1] . $matches[2] . $markup . $matches[3];
			},
			$html
		);

		return is_string( $replaced ) ? $replaced : $html;
	}

	/**
	 * Desktop button-icon controls whose settings are a DSM library icon.
	 *
	 * @param array<string, mixed> $module_attrs Module attrs.
	 * @return array<int, array<string, mixed>>
	 */
	private static function collect_desktop_button_icons( array $module_attrs ): array {
		$found = array();

		self::walk_desktop_button_icons( $module_attrs, $found );

		return $found;
	}

	/**
	 * Collect desktop button icon controls that use a DSM library icon.
	 *
	 * @param mixed                            $node  Attr node.
	 * @param array<int, array<string, mixed>> $found Collected icon controls.
	 * @return void
	 */
	private static function walk_desktop_button_icons( $node, array &$found ): void {
		if ( ! is_array( $node ) ) {
			return;
		}

		$icon = $node['decoration']['button']['desktop']['value']['icon'] ?? null;

		$matched = false;

		if ( is_array( $icon ) ) {
			$settings = $icon['settings'] ?? null;

			if (
				is_array( $settings )
				&& 'on' === ( $icon['enable'] ?? 'off' )
				&& IconLibraryRegistry::is_dsm_library_icon( $settings )
			) {
				$found[] = $icon;
				$matched = true;
			}
		}

		foreach ( $node as $key => $child ) {
			if ( ! is_array( $child ) ) {
				continue;
			}

			// The matched button group is this control. Keep walking its siblings.
			if ( $matched && 'decoration' === $key ) {
				foreach ( $child as $decoration_key => $decoration_child ) {
					if ( 'button' === $decoration_key || ! is_array( $decoration_child ) ) {
						continue;
					}

					self::walk_desktop_button_icons( $decoration_child, $found );
				}

				continue;
			}

			self::walk_desktop_button_icons( $child, $found );
		}
	}

	/**
	 * Build the webfont glyph markup for one button icon control.
	 *
	 * @param array<string, mixed> $icon Button icon control (`enable`, `placement`, `onHover`, `settings`).
	 * @return string
	 */
	private static function button_webfont_glyph_markup( array $icon ): string {
		$settings = $icon['settings'] ?? null;

		if ( ! is_array( $settings ) ) {
			return '';
		}

		$extra = array( 'dsm-button-webfont-icon' );

		if ( 'left' === (string) ( $icon['placement'] ?? 'right' ) ) {
			$extra[] = 'dsm-button-webfont-icon--left';
		}

		if ( 'off' === (string) ( $icon['onHover'] ?? '' ) ) {
			$extra[] = 'dsm-button-webfont-icon--visible';
		}

		return IconGlyphRenderer::render_glyph_markup( $settings, $extra );
	}

	/**
	 * Whether Blurb is configured to show an icon instead of an image.
	 *
	 * @param array<string, mixed> $module_attrs Module attrs.
	 * @return bool
	 */
	private static function blurb_uses_icon_mode( array $module_attrs ): bool {
		return 'on' === ( $module_attrs['imageIcon']['innerContent']['desktop']['value']['useIcon'] ?? 'off' );
	}

	/**
	 * Build and prepend Blurb image/icon container when core omitted it for DSM icons.
	 *
	 * @param string               $html          Module HTML.
	 * @param array<string, mixed> $icon_settings Primary icon picker leaf.
	 * @param array<string, mixed> $module_attrs  Module attrs.
	 * @return string
	 */
	private static function inject_blurb_icon_container(
		string $html,
		array $icon_settings,
		array $module_attrs
	): string {
		if ( str_contains( $html, 'et_pb_main_blurb_image' ) ) {
			return $html;
		}

		$icon_span = self::build_icon_span_markup( $icon_settings );

		if ( '' === $icon_span ) {
			return $html;
		}

		$image_icon_attr = is_array( $module_attrs['imageIcon'] ?? null ) ? $module_attrs['imageIcon'] : array();
		$layout_display  = $image_icon_attr['decoration']['layout']['desktop']['value']['display'] ?? 'block';
		$layout_classes  = array(
			'et_flex_module' => 'flex' === $layout_display,
			'et_grid_module' => 'grid' === $layout_display,
		);

		$animation_class = '';
		if ( class_exists( \ET\Builder\Packages\ModuleLibrary\Common\ImageWrapperAnimation::class ) ) {
			$animation_class = \ET\Builder\Packages\ModuleLibrary\Common\ImageWrapperAnimation::wrapper_animation_classname( $image_icon_attr );
		}

		$image_wrap = HTMLUtility::render(
			array(
				'tag'               => 'span',
				'attributes'        => array(
					'class' => HTMLUtility::classnames(
						array(
							'et_pb_image_wrap' => true,
						),
						$layout_classes
					),
				),
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $icon_span,
			)
		);

		$title_link        = $module_attrs['title']['innerContent']['desktop']['value']['url'] ?? '';
		$title_link_target = 'on' === ( $module_attrs['title']['innerContent']['desktop']['value']['target'] ?? '' ) ? '_blank' : null;
		$image_icon_link   = $image_wrap;

		if ( is_string( $title_link ) && '' !== $title_link ) {
			$link_attributes = array(
				'href' => $title_link,
			);

			if ( null !== $title_link_target ) {
				$link_attributes['target'] = $title_link_target;
			}

			$image_icon_link = HTMLUtility::render(
				array(
					'tag'               => 'a',
					'attributes'        => $link_attributes,
					'childrenSanitizer' => 'et_core_esc_previously',
					'children'          => $image_wrap,
				)
			);
		}

		$image_container = HTMLUtility::render(
			array(
				'tag'               => 'div',
				'attributes'        => array(
					'class' => HTMLUtility::classnames(
						'et_pb_main_blurb_image',
						$animation_class
					),
				),
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $image_icon_link,
			)
		);

		if ( preg_match( '/(<div\b[^>]*\bet_pb_blurb_container\b[^>]*>)/i', $html ) ) {
			$replaced = preg_replace(
				'/(<div\b[^>]*\bet_pb_blurb_container\b[^>]*>)/i',
				$image_container . '$1',
				$html,
				1
			);

			return is_string( $replaced ) ? $replaced : $html;
		}

		if ( preg_match( '/(<div\b[^>]*\bet_pb_blurb_content\b[^>]*>)/i', $html ) ) {
			$replaced = preg_replace(
				'/(<div\b[^>]*\bet_pb_blurb_content\b[^>]*>)/i',
				'$1' . $image_container,
				$html,
				1
			);

			return is_string( $replaced ) ? $replaced : $html;
		}

		return $html;
	}

	/**
	 * Inject list item icon host when core skips output for DSM icons.
	 *
	 * @param string               $html          Module HTML.
	 * @param array<string, mixed> $icon_settings Primary icon picker leaf.
	 * @return string
	 */
	private static function inject_icon_list_item_icon( string $html, array $icon_settings ): string {
		if ( str_contains( $html, 'et-pb-icon' ) ) {
			return $html;
		}

		$icon_span = self::build_icon_span_markup( $icon_settings );

		if ( '' === $icon_span ) {
			return $html;
		}

		if ( preg_match( '/(<div\b[^>]*\bet_pb_icon_list_text\b[^>]*>)/i', $html ) ) {
			$replaced = preg_replace(
				'/(<div\b[^>]*\bet_pb_icon_list_text\b[^>]*>)/i',
				$icon_span . '$1',
				$html,
				1
			);

			return is_string( $replaced ) ? $replaced : $html;
		}

		return $html;
	}

	/**
	 * Insert glyph markup into empty `.et_pb_icon_wrap` spans.
	 *
	 * @param string                           $html  Module HTML.
	 * @param array<int, array<string, mixed>> $icons Icon settings in walk order.
	 * @return string
	 */
	private static function inject_spans_into_empty_icon_wraps( string $html, array $icons ): string {
		$icon_index = 0;

		$replaced = preg_replace_callback(
			'/(<span\b(?=[^>]*\bet_pb_icon_wrap\b)[^>]*>)(\s*)(<\/span>)/is',
			static function ( array $matches ) use ( $icons, &$icon_index ): string {
				if ( ! isset( $icons[ $icon_index ] ) ) {
					return $matches[0];
				}

				$icon_settings = $icons[ $icon_index ];
				++$icon_index;

				$icon_span = self::build_icon_span_markup( $icon_settings );

				if ( '' === $icon_span ) {
					return $matches[0];
				}

				return $matches[1] . $icon_span . $matches[3];
			},
			$html,
			-1,
			$replace_count
		);

		return is_string( $replaced ) && $replace_count > 0 ? $replaced : $html;
	}

	/**
	 * Replace empty `.et-pb-icon` hosts with webfont glyph markup (Card, Tilt, etc.).
	 *
	 * @param string                           $html  Module HTML.
	 * @param array<int, array<string, mixed>> $icons Icon settings in walk order.
	 * @return string
	 */
	private static function tag_untagged_icon_spans( string $html, array $icons ): string {
		$icon_index = 0;

		$replaced = preg_replace_callback(
			'/<span\b([^>]*\bet-pb-icon\b[^>]*)>(\s*)<\/span>/is',
			static function ( array $matches ) use ( $icons, &$icon_index ): string {
				if ( ! isset( $icons[ $icon_index ] ) ) {
					return $matches[0];
				}

				// Host already carries the same ::before contract as ModuleIconHost.
				if (
					str_contains( $matches[0], 'dsm-icon-manager-glyph' )
					&& str_contains( $matches[0], '--dsm-icon-content' )
				) {
					++$icon_index;

					return $matches[0];
				}

				$icon_settings = $icons[ $icon_index ];
				++$icon_index;

				$extra_classes = self::parse_extra_icon_classes_from_span_attrs( $matches[1] );
				$icon_span     = self::build_icon_span_markup( $icon_settings, $extra_classes );

				return '' !== $icon_span ? $icon_span : $matches[0];
			},
			$html
		);

		return is_string( $replaced ) ? $replaced : $html;
	}

	/**
	 * Replace an `.et-pb-icon` whose text is a library slug with the webfont host.
	 *
	 * Divi 5.12–5.16 saves store `hospital` in `unicode`. Modules that echo that
	 * string would show the word. A single catalog character is left as-is.
	 *
	 * @param string                           $html  Module HTML.
	 * @param array<int, array<string, mixed>> $icons Collected icon settings.
	 * @return string
	 */
	private static function replace_slug_text_icon_spans( string $html, array $icons ): string {
		$replaced = preg_replace_callback(
			'/<span\b([^>]*\bet-pb-icon\b[^>]*)>([^<]*)<\/span>/i',
			static function ( array $matches ) use ( $icons ): string {
				$text = trim( $matches[2] );

				if ( '' === $text || 1 === mb_strlen( $text ) ) {
					return $matches[0];
				}

				foreach ( $icons as $icon_settings ) {
					if ( ! is_array( $icon_settings ) ) {
						continue;
					}

					$stored = trim( (string) ( $icon_settings['unicode'] ?? '' ) );

					if ( $stored !== $text || ! IconLibraryRegistry::is_dsm_library_icon( $icon_settings ) ) {
						continue;
					}

					$extra_classes = self::parse_extra_icon_classes_from_span_attrs( $matches[1] );
					$icon_span     = self::build_icon_span_markup( $icon_settings, $extra_classes );

					return '' !== $icon_span ? $icon_span : $matches[0];
				}

				return $matches[0];
			},
			$html
		);

		return is_string( $replaced ) ? $replaced : $html;
	}

	/**
	 * Preserve module-specific icon host classes when replacing empty spans.
	 *
	 * @param string $span_attrs Raw attributes from the matched `<span>`.
	 * @return string[]
	 */
	private static function parse_extra_icon_classes_from_span_attrs( string $span_attrs ): array {
		if ( ! preg_match( '/\bclass=(["\'])([^"\']*)\1/i', $span_attrs, $matches ) ) {
			return array();
		}

		$split_classes = preg_split( '/\s+/', trim( $matches[2] ) );
		$classes       = is_array( $split_classes ) && array() !== $split_classes ? $split_classes : array();
		$reserved      = array(
			'et-pb-icon',
			'dsm-webfont-icon-host',
			'et-pb-icon-circle',
			'et-pb-icon-circle-border',
		);

		return array_values(
			array_filter(
				$classes,
				static function ( string $class ) use ( $reserved ): bool {
					return '' !== $class && ! in_array( $class, $reserved, true );
				}
			)
		);
	}

	/**
	 * Render one icon host span for the given icon settings.
	 *
	 * @param array<string, mixed> $icon_settings Icon picker leaf.
	 * @param string[]             $extra_classes Module-specific host classes to preserve.
	 * @return string
	 */
	private static function build_icon_span_markup( array $icon_settings, array $extra_classes = array() ): string {
		return IconGlyphRenderer::render_icon_span( $icon_settings, $extra_classes );
	}

	/**
	 * Enqueue frontend style declarations for webfont icon hosts.
	 *
	 * @param array<string, mixed>             $args            Wrapper filter args.
	 * @param array<int, array<string, mixed>> $icons           Collected icons.
	 * @param ModuleElements                   $module_elements Module elements instance.
	 * @return void
	 */
	private static function add_frontend_icon_styles( array $args, array $icons, ModuleElements $module_elements ): void {
		unset( $icons );

		$order_class = $module_elements->order_class;

		if ( '' === $order_class ) {
			return;
		}

		$module_attrs = is_array( $args['attrs'] ?? null ) ? $args['attrs'] : array();
		$module_name  = (string) ( $args['name'] ?? '' );
		$style_items  = self::build_webfont_icon_host_styles( $order_class, $module_name, $module_attrs );

		if ( array() === $style_items ) {
			self::maybe_add_divi_icon_module_color_size( $args, $module_elements, array() );
			self::maybe_add_divi_icon_list_item_module_styles( $args, $module_elements );
			self::maybe_add_blurb_module_icon_styles( $args, $module_elements );

			return;
		}

		Style::set_group_style( 'module' );

		Style::add(
			array(
				'id'            => (string) ( $args['id'] ?? '' ),
				'name'          => (string) ( $args['name'] ?? '' ),
				'orderIndex'    => (int) ( $args['orderIndex'] ?? 0 ),
				'storeInstance' => (int) ( $args['storeInstance'] ?? 0 ),
				'group'         => 'module',
				'styles'        => $style_items,
			)
		);

		self::maybe_add_divi_icon_module_color_size( $args, $module_elements, $style_items );
		self::maybe_add_divi_icon_list_item_module_styles( $args, $module_elements );
		self::maybe_add_blurb_module_icon_styles( $args, $module_elements );
	}

	/**
	 * Mirror module icon font-size and color attrs onto `.et-pb-icon` host selectors.
	 *
	 * @param string               $order_class  Module order class.
	 * @param string               $module_name  Registered module name.
	 * @param array<string, mixed> $module_attrs Module attrs.
	 * @return array<int, mixed>
	 */
	private static function build_webfont_icon_host_styles( string $order_class, string $module_name, array $module_attrs ): array {
		$style_items = array();

		foreach ( IconHostStyleAttrCollector::collect( $module_name, $module_attrs ) as $rule ) {
			$style_items[] = CommonStyle::style(
				array(
					'selector' => IconHostStyleAttrCollector::build_icon_host_selector(
						$module_name,
						$order_class,
						$rule['attr_key']
					),
					'attr'     => $rule['inner_content'],
					'property' => $rule['property'],
				)
			);
		}

		return $style_items;
	}

	/**
	 * Blurb icon color/size for webfont glyphs when the image container was injected.
	 *
	 * @param array<string, mixed> $args            Wrapper args.
	 * @param ModuleElements       $module_elements Elements instance.
	 * @return void
	 */
	private static function maybe_add_blurb_module_icon_styles( array $args, ModuleElements $module_elements ): void {
		if ( 'divi/blurb' !== ( $args['name'] ?? '' ) ) {
			return;
		}

		$module_attrs = is_array( $args['attrs'] ?? null ) ? $args['attrs'] : array();

		if ( ! self::blurb_uses_icon_mode( $module_attrs ) ) {
			return;
		}

		$icon_selector = $module_elements->order_class . ' .et_pb_main_blurb_image .et-pb-icon.dsm-webfont-icon-host';

		Style::add(
			array(
				'id'            => (string) ( $args['id'] ?? '' ),
				'name'          => (string) ( $args['name'] ?? '' ),
				'orderIndex'    => (int) ( $args['orderIndex'] ?? 0 ),
				'storeInstance' => (int) ( $args['storeInstance'] ?? 0 ),
				'group'         => 'module',
				'styles'        => array(
					CommonStyle::style(
						array(
							'selector' => $icon_selector,
							'attr'     => $module_attrs['imageIcon']['advanced']['color'] ?? array(),
							'property' => 'color',
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $icon_selector,
							'attr'                => $module_attrs['imageIcon']['decoration']['sizing'] ?? array(),
							'declarationFunction' => static function ( array $params ): string {
								$size = $params['attrValue']['iconFontSize'] ?? '';

								if ( ! is_string( $size ) || '' === $size ) {
									return '';
								}

								return sprintf( 'font-size:%s;', esc_attr( $size ) );
							},
						)
					),
				),
			)
		);
	}

	/**
	 * Preserve native Icon module color/size attrs when present.
	 *
	 * @param array<string, mixed> $args            Wrapper args.
	 * @param ModuleElements       $module_elements Elements instance.
	 * @param array<int, mixed>    $existing_styles Styles already queued (unused; reserved).
	 * @return void
	 */
	private static function maybe_add_divi_icon_module_color_size(
		array $args,
		ModuleElements $module_elements,
		array $existing_styles
	): void {
		unset( $existing_styles );

		if ( 'divi/icon' !== ( $args['name'] ?? '' ) ) {
			return;
		}

		$module_attrs = is_array( $args['attrs'] ?? null ) ? $args['attrs'] : array();

		self::add_divi_icon_picker_host_color_size_styles(
			$args,
			$module_elements,
			$module_attrs,
			$module_elements->order_class . ' .et_pb_icon_wrap .et-pb-icon.dsm-webfont-icon-host'
		);
	}

	/**
	 * Mirror native Icon List Item icon color/size onto webfont hosts.
	 *
	 * @param array<string, mixed> $args            Wrapper args.
	 * @param ModuleElements       $module_elements Elements instance.
	 * @return void
	 */
	private static function maybe_add_divi_icon_list_item_module_styles(
		array $args,
		ModuleElements $module_elements
	): void {
		if ( 'divi/icon-list-item' !== ( $args['name'] ?? '' ) ) {
			return;
		}

		$module_attrs = is_array( $args['attrs'] ?? null ) ? $args['attrs'] : array();

		self::add_divi_icon_picker_host_color_size_styles(
			$args,
			$module_elements,
			$module_attrs,
			$module_elements->order_class . ' .et-pb-icon.dsm-webfont-icon-host'
		);
	}

	/**
	 * Apply `icon.advanced.color` and `icon.advanced.size` to webfont icon hosts.
	 *
	 * @param array<string, mixed> $args            Wrapper args.
	 * @param ModuleElements       $module_elements Elements instance.
	 * @param array<string, mixed> $module_attrs    Module attrs.
	 * @param string               $icon_selector   Scoped icon host selector.
	 * @return void
	 */
	private static function add_divi_icon_picker_host_color_size_styles(
		array $args,
		ModuleElements $module_elements,
		array $module_attrs,
		string $icon_selector
	): void {

		Style::add(
			array(
				'id'            => (string) ( $args['id'] ?? '' ),
				'name'          => (string) ( $args['name'] ?? '' ),
				'orderIndex'    => (int) ( $args['orderIndex'] ?? 0 ),
				'storeInstance' => (int) ( $args['storeInstance'] ?? 0 ),
				'group'         => 'module',
				'styles'        => array(
					$module_elements->style(
						array(
							'attrName'   => 'icon',
							'styleProps' => array(
								'advancedStyles' => array(
									array(
										'componentName' => 'divi/common',
										'props'         => array(
											'selector' => $icon_selector,
											'attr'     => $module_attrs['icon']['advanced']['color'] ?? array(),
											'property' => 'color',
										),
									),
									array(
										'componentName' => 'divi/common',
										'props'         => array(
											'selector' => $icon_selector,
											'attr'     => $module_attrs['icon']['advanced']['size'] ?? array(),
											'declarationFunction' => array( self::class, 'webfont_icon_host_size_declaration' ),
										),
									),
								),
							),
						)
					),
				),
			)
		);
	}

	/**
	 * Return a font-size declaration for a webfont icon host.
	 *
	 * @param array<string, mixed> $params CommonStyle params.
	 * @return string
	 */
	public static function webfont_icon_host_size_declaration( array $params ): string {
		$size = $params['attrValue'] ?? '';

		if ( is_array( $size ) ) {
			$size = $size['iconFontSize'] ?? '';
		}

		if ( ! is_string( $size ) || '' === $size ) {
			return '';
		}

		return sprintf( 'font-size:%s;', esc_attr( $size ) );
	}

	/**
	 * Render a standard `.et-pb-icon` host for module markup (native or DSM webfont).
	 *
	 * Use when icon hosts are outside `divi_module_wrapper_render` (e.g. timeline pointers).
	 *
	 * @param array<string, mixed>|null $icon_settings Icon picker leaf; null for empty native host.
	 * @param string[]                  $extra_classes Additional host classes.
	 * @return string
	 */
	public static function render_icon_host_markup( ?array $icon_settings, array $extra_classes = array() ): string {
		if ( ! ExtensionSettings::is_extension_enabled() ) {
			return sprintf(
				'<span class="%s" aria-hidden="true"></span>',
				esc_attr(
					implode(
						' ',
						array_values(
							array_unique(
								array_filter(
									array_merge( array( 'et-pb-icon' ), $extra_classes )
								)
							)
						)
					)
				)
			);
		}

		$host_classes = array_values(
			array_unique(
				array_filter(
					array_merge( array( 'dsm-icon' ), $extra_classes )
				)
			)
		);

		if ( is_array( $icon_settings ) ) {
			if ( IconLibraryRegistry::is_dsm_library_icon( $icon_settings ) ) {
				$webfont_markup = IconGlyphRenderer::render_icon_span( $icon_settings, $host_classes );

				if ( '' !== $webfont_markup ) {
					if ( preg_match( '/<span\b/i', $webfont_markup ) ) {
						$with_aria = preg_replace(
							'/<span\b/i',
							'<span aria-hidden="true"',
							$webfont_markup,
							1
						);

						return is_string( $with_aria ) ? $with_aria : $webfont_markup;
					}

					return $webfont_markup;
				}
			}

			// Native Divi / FA icons: empty `.et-pb-icon` host — module `::before` / `::after` CSS supplies the glyph.
		}

		return sprintf(
			'<span class="%s" aria-hidden="true"></span>',
			esc_attr(
				implode(
					' ',
					array_values(
						array_unique(
							array_filter(
								array_merge( array( 'et-pb-icon' ), $host_classes )
							)
						)
					)
				)
			)
		);
	}

	/**
	 * Inject webfont icon hosts into empty Swiper navigation buttons (carousel modules).
	 *
	 * @param string               $html         Module HTML.
	 * @param string               $module_name  Registered module name.
	 * @param array<string, mixed> $module_attrs Module attrs.
	 * @return string
	 */
	private static function inject_carousel_navigation_icons(
		string $html,
		string $module_name,
		array $module_attrs
	): string {
		$config = self::get_carousel_navigation_icon_attrs( $module_name );

		if ( null === $config ) {
			return $html;
		}

		foreach ( array( 'prev', 'next' ) as $direction ) {
			$slot = $config[ $direction ];

			if (
				isset( $slot['toggle'] )
				&& ! self::is_module_toggle_on( $module_attrs, $slot['toggle'] )
			) {
				continue;
			}

			$icon = self::extract_icon_picker_value( $module_attrs, $slot['icon'] );

			if ( ! is_array( $icon ) || ! IconLibraryRegistry::is_dsm_library_icon( $icon ) ) {
				continue;
			}

			$markup = IconGlyphRenderer::render_icon_span( $icon, array( 'dsm-carousel-arrow-icon' ) );

			if ( '' === $markup ) {
				continue;
			}

			$html = self::inject_markup_into_empty_swiper_button( $html, $direction, $markup );
		}

		return $html;
	}

	/**
	 * Map a carousel module to its previous and next icon attr keys.
	 *
	 * @param string $module_name Registered module name.
	 * @return array{prev: array{icon: string, toggle?: string}, next: array{icon: string, toggle?: string}}|null
	 */
	private static function get_carousel_navigation_icon_attrs( string $module_name ): ?array {
		$map = array(
			'dsm/image-carousel' => array(
				'prev' => array(
					'icon'   => 'arrow_prev_font_icon',
					'toggle' => 'arrow_prev',
				),
				'next' => array(
					'icon'   => 'arrow_next_font_icon',
					'toggle' => 'arrow_next',
				),
			),
			'dsm/card-carousel'  => array(
				'prev' => array(
					'icon'   => 'arrow_prev_font_icon',
					'toggle' => 'arrow_prev',
				),
				'next' => array(
					'icon'   => 'arrow_next_font_icon',
					'toggle' => 'arrow_next',
				),
			),
			'dsm/post-carousel'  => array(
				'prev' => array(
					'icon'   => 'prev_icon',
					'toggle' => 'use_prev_icon',
				),
				'next' => array(
					'icon'   => 'next_icon',
					'toggle' => 'use_next_icon',
				),
			),
			'dsm/blog-carousel'  => array(
				'prev' => array(
					'icon'   => 'prev_icon',
					'toggle' => 'use_prev_icon',
				),
				'next' => array(
					'icon'   => 'next_icon',
					'toggle' => 'use_next_icon',
				),
			),
		);

		return $map[ $module_name ] ?? null;
	}

	/**
	 * Whether a module toggle is on at any coarse breakpoint.
	 *
	 * @param array<string, mixed> $module_attrs Module attrs.
	 * @param string               $toggle_key   Toggle attr key.
	 * @return bool
	 */
	private static function is_module_toggle_on( array $module_attrs, string $toggle_key ): bool {
		return IconAttrBreakpoint::is_toggle_on_any( $module_attrs, $toggle_key );
	}

	/**
	 * Icon picker innerContent tree for an attr key.
	 *
	 * @param array<string, mixed> $module_attrs Module attrs.
	 * @param string               $attr_key     Icon attr key.
	 * @return array<string, mixed>
	 */
	private static function extract_icon_picker_inner( array $module_attrs, string $attr_key ): array {
		$inner = $module_attrs[ $attr_key ]['innerContent'] ?? null;

		return is_array( $inner ) ? $inner : array();
	}

	/**
	 * First usable icon picker leaf (desktop → tablet → phone).
	 *
	 * @param array<string, mixed> $module_attrs Module attrs.
	 * @param string               $attr_key     Icon attr key.
	 * @return array<string, mixed>|null
	 */
	private static function extract_icon_picker_value( array $module_attrs, string $attr_key ): ?array {
		$leaf = IconAttrBreakpoint::first_usable_icon_leaf(
			self::extract_icon_picker_inner( $module_attrs, $attr_key )
		);

		return is_array( $leaf ) ? $leaf : null;
	}

	/**
	 * Insert icon markup into an empty Swiper navigation button.
	 *
	 * @param string $html      Module HTML.
	 * @param string $direction Swiper direction: prev|next.
	 * @param string $markup    Icon host markup.
	 * @return string
	 */
	private static function inject_markup_into_empty_swiper_button( string $html, string $direction, string $markup ): string {
		$class   = 'swiper-button-' . $direction;
		$pattern = '/(<div\b(?=[^>]*\b' . preg_quote( $class, '/' ) . '\b)[^>]*>)(\s*)(<\/div>)/is';

		$replaced = preg_replace_callback(
			$pattern,
			static function ( array $matches ) use ( $markup ): string {
				if ( '' !== trim( $matches[2] ) ) {
					return $matches[0];
				}

				return $matches[1] . $markup . $matches[3];
			},
			$html,
			1
		);

		return is_string( $replaced ) ? $replaced : $html;
	}

	/**
	 * Whether the module is a Mega Menu parent or child.
	 *
	 * @param string $module_name Registered module name.
	 * @return bool
	 */
	private static function is_mega_menu_module( string $module_name ): bool {
		return 'dsm/mega-menu' === $module_name || 'dsm/mega-menu-child' === $module_name;
	}

	/**
	 * Mega Menu prints library slugs as ETmodules text (or omits the host).
	 * Inject one webfont host+glyph per selected icon; do not touch menu labels.
	 *
	 * @param string               $html         Module HTML.
	 * @param string               $module_name  Registered module name.
	 * @param array<string, mixed> $module_attrs Module attrs.
	 * @param array<string, mixed> $args         Wrapper filter args (parent store).
	 * @return string
	 */
	private static function inject_mega_menu_icons(
		string $html,
		string $module_name,
		array $module_attrs,
		array $args = array()
	): string {
		if ( 'dsm/mega-menu-child' === $module_name ) {
			return self::inject_mega_menu_child_icons( $html, $module_attrs );
		}

		if ( 'dsm/mega-menu' === $module_name ) {
			$html = self::inject_mega_menu_parent_icons( $html, $module_attrs );
			$html = self::inject_mega_menu_children_from_store( $html, $args );

			return $html;
		}

		return $html;
	}

	/**
	 * After Mega Menu child render_callback (bypasses Module::render()).
	 *
	 * @param string               $block_content Rendered child HTML.
	 * @param array<string, mixed> $block        Parsed block.
	 * @return string
	 */
	public static function filter_mega_menu_child_block( string $block_content, array $block ): string {
		if ( ! ExtensionSettings::is_extension_enabled() ) {
			return $block_content;
		}

		$attrs = is_array( $block['attrs'] ?? null ) ? $block['attrs'] : array();

		if ( ! IconAttrCollector::has_dsm_icons( $attrs ) ) {
			return $block_content;
		}

		self::enqueue_webfonts_for_unique_icons( IconAttrCollector::collect_unique_dsm_icons( $attrs ) );

		return self::inject_mega_menu_child_icons( $block_content, $attrs );
	}

	/**
	 * Children skip Module::render(); inject from the parent wrapper using the block store.
	 *
	 * @param string               $html Parent module HTML (includes child <li>s).
	 * @param array<string, mixed> $args Wrapper filter args.
	 * @return string
	 */
	private static function inject_mega_menu_children_from_store( string $html, array $args ): string {
		$parent_id = (string) ( $args['id'] ?? '' );
		$store     = $args['storeInstance'] ?? null;

		if ( '' === $parent_id || ! class_exists( BlockParserStore::class ) ) {
			return $html;
		}

		$children = BlockParserStore::get_children( $parent_id, $store );

		foreach ( $children as $child ) {
			// Divi parsed-block field; the property name is not ours to rename.
			$block_name_key = 'blockName';
			$name           = is_object( $child ) ? (string) ( $child->{$block_name_key} ?? '' ) : '';

			if ( 'dsm/mega-menu-child' !== $name ) {
				continue;
			}

			$attrs = is_object( $child ) && is_array( $child->attrs ?? null ) ? $child->attrs : array();

			if ( ! IconAttrCollector::has_dsm_icons( $attrs ) ) {
				continue;
			}

			self::enqueue_webfonts_for_unique_icons( IconAttrCollector::collect_unique_dsm_icons( $attrs ) );

			$child_id    = is_object( $child ) ? (string) ( $child->id ?? '' ) : '';
			$order_class = '';

			if ( '' !== $child_id && class_exists( ModuleUtils::class ) ) {
				$order_class = (string) ModuleUtils::get_module_order_class_name( $child_id, $store );
			}

			if ( '' === $order_class && is_object( $child ) ) {
				// Divi parsed-block field; the property name is not ours to rename.
				$order_index_key = 'orderIndex';
				$order_class     = 'dsm_mega_menu_child_' . (int) ( $child->{$order_index_key} ?? $child->index ?? 0 );
			}

			$html = self::mutate_html_for_order_class(
				$html,
				$order_class,
				static function ( string $slice ) use ( $attrs ): string {
					return self::inject_mega_menu_child_icons( $slice, $attrs );
				}
			);
		}

		return $html;
	}

	/**
	 * Replace the HTML slice for one module order class.
	 *
	 * @param string   $html        Full HTML.
	 * @param string   $order_class Module order class (with or without leading dot).
	 * @param callable $mutator     fn(string $slice): string.
	 * @return string
	 */
	private static function mutate_html_for_order_class( string $html, string $order_class, callable $mutator ): string {
		$token = ltrim( $order_class, '.' );

		if ( '' === $token ) {
			return $html;
		}

		if ( ! preg_match( '/<([a-zA-Z0-9]+)(?=[^>]*\b' . preg_quote( $token, '/' ) . '\b)[^>]*>/', $html, $match, PREG_OFFSET_CAPTURE ) ) {
			return $html;
		}

		$tag   = $match[1][0];
		$start = (int) $match[0][1];
		$end   = self::find_matching_close_tag_end( $html, $start, $tag );

		if ( null === $end ) {
			return $html;
		}

		$slice = substr( $html, $start, $end - $start );
		$next  = $mutator( $slice );

		if ( ! is_string( $next ) || $next === $slice ) {
			return $html;
		}

		return substr( $html, 0, $start ) . $next . substr( $html, $end );
	}

	/**
	 * Find the offset just after the matching closing tag.
	 *
	 * @param string $html     Full HTML.
	 * @param int    $open_pos Offset of the opening tag.
	 * @param string $tag      Tag name.
	 * @return int|null Offset after the matching close tag.
	 */
	private static function find_matching_close_tag_end( string $html, int $open_pos, string $tag ): ?int {
		$tag = strtolower( $tag );

		if ( ! preg_match( '/<' . preg_quote( $tag, '/' ) . '\b[^>]*>/i', $html, $open_match, 0, $open_pos ) ) {
			return null;
		}

		$cursor       = $open_pos + strlen( $open_match[0] );
		$depth        = 1;
		$length       = strlen( $html );
		$open_needle  = '<' . $tag;
		$close_needle = '</' . $tag . '>';

		while ( $cursor < $length && $depth > 0 ) {
			$next_open  = stripos( $html, $open_needle, $cursor );
			$next_close = stripos( $html, $close_needle, $cursor );

			if ( false === $next_close ) {
				return null;
			}

			// stripos('<li') also hits '<link' / '<linearGradient' — require a tag boundary.
			if ( false !== $next_open && $next_open < $next_close ) {
				$after = $next_open + strlen( $open_needle );
				$bound = $after < $length ? $html[ $after ] : '';

				if ( '>' !== $bound && ' ' !== $bound && "\t" !== $bound && "\n" !== $bound && "\r" !== $bound && '/' !== $bound ) {
					$cursor = $after;
					continue;
				}

				if ( ! preg_match( '/<' . preg_quote( $tag, '/' ) . '\b[^>]*>/i', $html, $inner_open, 0, $next_open ) ) {
					$cursor = $after;
					continue;
				}

				++$depth;
				$cursor = $next_open + strlen( $inner_open[0] );
				continue;
			}

			--$depth;
			$cursor = $next_close + strlen( $close_needle );
		}

		return $depth > 0 ? null : $cursor;
	}

	/**
	 * Inject webfont hosts into Mega Menu child icon slots.
	 *
	 * @param string               $html         Child module HTML.
	 * @param array<string, mixed> $module_attrs Child attrs.
	 * @return string
	 */
	private static function inject_mega_menu_child_icons( string $html, array $module_attrs ): string {
		$media_inner = self::extract_icon_picker_inner( $module_attrs, 'font_icon' );

		if ( IconAttrBreakpoint::inner_has_dsm_library_icon( $media_inner ) ) {
			$use_icon_off  = isset( $module_attrs['dsm_use_icon'] ) && ! self::is_module_toggle_on( $module_attrs, 'dsm_use_icon' );
			$use_image_off = isset( $module_attrs['dsm_use_image_icon'] ) && ! self::is_module_toggle_on( $module_attrs, 'dsm_use_image_icon' );

			if ( ! $use_icon_off && ! $use_image_off ) {
				$alignment = self::extract_inner_desktop_string( $module_attrs, 'dsm_image_icon_alignment', 'left' );
				$position  = in_array( $alignment, array( 'right', 'bottom' ), true ) ? 'after' : 'before';
				$html      = self::replace_or_insert_mega_menu_icon(
					$html,
					$media_inner,
					'dsm_icon',
					$position
				);
			}
		}

		$slots = array(
			'dsm_cart_font_icon'           => 'dsm_cart_icon',
			'dsm_dropdown_open_font_icon'  => 'dsm_dropdown_open_icon',
			'dsm_dropdown_close_font_icon' => 'dsm_dropdown_close_icon',
		);

		foreach ( $slots as $attr_key => $host_class ) {
			$inner = self::extract_icon_picker_inner( $module_attrs, $attr_key );

			if ( ! IconAttrBreakpoint::inner_has_dsm_library_icon( $inner ) ) {
				continue;
			}

			$html = self::replace_empty_or_dumped_icon_span_from_inner( $html, $host_class, $inner );
		}

		$dropdown_inner = self::get_mega_menu_native_dropdown_inner( $module_attrs );

		if ( is_array( $dropdown_inner ) ) {
			$html = self::replace_empty_or_dumped_icon_span_from_inner( $html, 'dsm_dropdown_icon', $dropdown_inner );
			$html = self::inject_native_submenu_dropdown_icons( $html, $dropdown_inner );
		}

		return $html;
	}

	/**
	 * Inject webfont hosts into Mega Menu search / hamburger / panel-close slots.
	 *
	 * @param string               $html         Parent module HTML.
	 * @param array<string, mixed> $module_attrs Parent attrs.
	 * @return string
	 */
	private static function inject_mega_menu_parent_icons( string $html, array $module_attrs ): string {
		$slots = array(
			'dsm_search_font_icon'       => 'dsm_search_icon',
			'dsm_mobile_open_font_icon'  => 'dsm-mobile-open-icon',
			'dsm_mobile_close_font_icon' => 'dsm_mobile_close_font_icon',
		);

		foreach ( $slots as $attr_key => $host_class ) {
			$inner = self::extract_icon_picker_inner( $module_attrs, $attr_key );

			if ( ! IconAttrBreakpoint::inner_has_dsm_library_icon( $inner ) ) {
				continue;
			}

			$html = self::replace_empty_or_dumped_icon_span_from_inner( $html, $host_class, $inner );
		}

		return $html;
	}

	/**
	 * Native WP submenu chevrons use Close Icon (Mega Menu PHP / VB preview).
	 *
	 * @param array<string, mixed> $module_attrs Child attrs.
	 * @return array<string, mixed>|null
	 */
	private static function get_mega_menu_native_dropdown_inner( array $module_attrs ): ?array {
		foreach ( array( 'dsm_dropdown_close_font_icon', 'dsm_dropdown_open_font_icon' ) as $attr_key ) {
			$inner = self::extract_icon_picker_inner( $module_attrs, $attr_key );

			if ( IconAttrBreakpoint::inner_has_dsm_library_icon( $inner ) ) {
				return $inner;
			}
		}

		return null;
	}

	/**
	 * Mega Menu omits `.dsm_dropdown_icon` when process_font_icon() is null.
	 * Append one webfont host inside submenu links that actually have a panel.
	 *
	 * @param string               $html          Module HTML.
	 * @param array<string, mixed> $inner_content Icon attr innerContent tree.
	 * @return string
	 */
	private static function inject_native_submenu_dropdown_icons( string $html, array $inner_content ): string {
		$markup = IconGlyphRenderer::render_icon_span_for_inner_content( $inner_content, array( 'dsm_dropdown_icon' ) );

		if ( '' === $markup ) {
			return $html;
		}

		$replaced = preg_replace_callback(
			'/<a\b([^>]*\bdsm-submenu-link\b[^>]*)>(.*?)<\/a>(\s*)(<ul\b[^>]*\bdsm-submenu-container\b)/is',
			static function ( array $matches ) use ( $markup ): string {
				$inner = $matches[2];

				if (
					preg_match(
						'/<span\b[^>]*\bdsm-webfont-icon-host\b[^>]*\bdsm_dropdown_icon\b|<span\b[^>]*\bdsm_dropdown_icon\b[^>]*\bdsm-webfont-icon-host\b/i',
						$inner
					)
				) {
					return $matches[0];
				}

				$stripped = preg_replace(
					'/<span\b[^>]*\bdsm_dropdown_icon\b[^>]*>.*?<\/span>/is',
					'',
					$inner
				);

				if ( is_string( $stripped ) ) {
					$inner = $stripped;
				}

				return '<a' . $matches[1] . '>' . $inner . $markup . '</a>' . $matches[3] . $matches[4];
			},
			$html
		);

		return is_string( $replaced ) ? $replaced : $html;
	}

	/**
	 * Read a desktop innerContent string, or the given fallback.
	 *
	 * @param array<string, mixed> $module_attrs Module attrs.
	 * @param string               $attr_key     Scalar innerContent attr.
	 * @param string               $default      Fallback.
	 * @return string
	 */
	private static function extract_inner_desktop_string( array $module_attrs, string $attr_key, string $default ): string {
		$value = $module_attrs[ $attr_key ]['innerContent']['desktop']['value'] ?? $default;

		return is_string( $value ) && '' !== $value ? $value : $default;
	}

	/**
	 * Replace an existing `.dsm_icon` dump, or insert a host next to the label row.
	 *
	 * @param string               $html          Child HTML.
	 * @param array<string, mixed> $inner_content Icon attr innerContent tree.
	 * @param string               $host_class    Host class.
	 * @param string               $position      before|after the label row.
	 * @return string
	 */
	private static function replace_or_insert_mega_menu_icon(
		string $html,
		array $inner_content,
		string $host_class,
		string $position
	): string {
		$replaced = self::replace_empty_or_dumped_icon_span_from_inner( $html, $host_class, $inner_content );

		if ( $replaced !== $html ) {
			return $replaced;
		}

		if (
			preg_match( '/<span\b[^>]*\b' . preg_quote( $host_class, '/' ) . '\b[^>]*\bdsm-webfont-icon-host\b/i', $html )
			|| preg_match( '/<span\b[^>]*\bdsm-webfont-icon-host\b[^>]*\b' . preg_quote( $host_class, '/' ) . '\b/i', $html )
		) {
			return $html;
		}

		$markup = IconGlyphRenderer::render_icon_span_for_inner_content( $inner_content, array( $host_class ) );

		if ( '' === $markup ) {
			return $html;
		}

		return self::insert_markup_around_menu_label_row( $html, $markup, $position );
	}

	/**
	 * Insert icon markup before or after the Mega Menu label row.
	 *
	 * @param string $html     Child HTML.
	 * @param string $markup   Host markup.
	 * @param string $position before|after.
	 * @return string
	 */
	private static function insert_markup_around_menu_label_row(
		string $html,
		string $markup,
		string $position
	): string {
		if ( ! preg_match( '/<div\b[^>]*\bdsm-menu-label-row\b[^>]*>/i', $html, $match, PREG_OFFSET_CAPTURE ) ) {
			if ( preg_match( '/(<div\b[^>]*\bdsm-menu-text-wrapper\b[^>]*>)/i', $html ) ) {
				$replaced = preg_replace(
					'/(<div\b[^>]*\bdsm-menu-text-wrapper\b[^>]*>)/i',
					'$1' . $markup,
					$html,
					1
				);

				return is_string( $replaced ) ? $replaced : $html;
			}

			return $html;
		}

		$open_start = (int) $match[0][1];

		if ( 'before' === $position ) {
			return substr( $html, 0, $open_start ) . $markup . substr( $html, $open_start );
		}

		$close_end = self::find_matching_close_div_end( $html, $open_start );

		if ( null === $close_end ) {
			return $html;
		}

		return substr( $html, 0, $close_end ) . $markup . substr( $html, $close_end );
	}

	/**
	 * Find the offset just after the matching closing div.
	 *
	 * @param string $html     Full HTML.
	 * @param int    $open_pos Offset of the opening `<div`.
	 * @return int|null Offset after the matching `</div>`.
	 */
	private static function find_matching_close_div_end( string $html, int $open_pos ): ?int {
		if ( ! preg_match( '/<div\b[^>]*>/i', $html, $open_match, 0, $open_pos ) ) {
			return null;
		}

		$cursor = $open_pos + strlen( $open_match[0] );
		$depth  = 1;
		$length = strlen( $html );

		while ( $cursor < $length && $depth > 0 ) {
			$next_open  = stripos( $html, '<div', $cursor );
			$next_close = stripos( $html, '</div>', $cursor );

			if ( false === $next_close ) {
				return null;
			}

			if ( false !== $next_open && $next_open < $next_close ) {
				if ( ! preg_match( '/<div\b[^>]*>/i', $html, $inner_open, 0, $next_open ) ) {
					return null;
				}

				++$depth;
				$cursor = $next_open + strlen( $inner_open[0] );
				continue;
			}

			--$depth;
			$cursor = $next_close + 6;
		}

		return $depth > 0 ? null : $cursor;
	}

	/**
	 * Replace an empty or ETmodules-dumped icon span with a single webfont host.
	 *
	 * @param string               $html       Module HTML.
	 * @param string               $host_class Host class.
	 * @param array<string, mixed> $icon       Icon picker leaf.
	 * @return string
	 */
	private static function replace_empty_or_dumped_icon_span(
		string $html,
		string $host_class,
		array $icon
	): string {
		$markup = IconGlyphRenderer::render_icon_span( $icon, array( $host_class ) );

		return self::replace_icon_span_markup( $html, $host_class, $markup );
	}

	/**
	 * Replace an empty or dumped icon span using a full innerContent tree.
	 *
	 * @param string               $html          Module HTML.
	 * @param string               $host_class    Host class.
	 * @param array<string, mixed> $inner_content Icon attr innerContent tree.
	 * @return string
	 */
	private static function replace_empty_or_dumped_icon_span_from_inner(
		string $html,
		string $host_class,
		array $inner_content
	): string {
		$markup = IconGlyphRenderer::render_icon_span_for_inner_content( $inner_content, array( $host_class ) );

		return self::replace_icon_span_markup( $html, $host_class, $markup );
	}

	/**
	 * Swap a dumped icon span for prepared host markup.
	 *
	 * @param string $html       Module HTML.
	 * @param string $host_class Host class.
	 * @param string $markup     Replacement host markup.
	 * @return string
	 */
	private static function replace_icon_span_markup(
		string $html,
		string $host_class,
		string $markup
	): string {
		if ( '' === $markup ) {
			return $html;
		}

		$quoted   = preg_quote( $host_class, '/' );
		$pattern  = '/<span\b(?=[^>]*\b' . $quoted . '\b)(?![^>]*\bdsm-webfont-icon-host\b)[^>]*>.*?<\/span>/is';
		$replaced = preg_replace( $pattern, $markup, $html );

		return is_string( $replaced ) ? $replaced : $html;
	}
}
