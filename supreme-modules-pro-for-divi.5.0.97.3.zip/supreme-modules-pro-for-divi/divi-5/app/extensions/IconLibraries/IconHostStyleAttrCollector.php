<?php
/**
 * Collect module icon host style attrs (font-size, color) for webfont icons.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Extensions\IconLibraries;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Mirrors each module's icon size/color onto `.et-pb-icon.dsm-webfont-icon-host`.
 */
final class IconHostStyleAttrCollector {

	/**
	 * Size attrs gated by a sibling toggle when that toggle exists on the module.
	 *
	 * @var array<string, string>
	 */
	private const TOGGLE_BY_SIZE_ATTR = array(
		'icon_content_font_size' => 'use_icon_font_size',
		'ia_icon_font_size'      => 'use_ia_icon_font_size',
		'front_icon_font_size'   => 'front_use_icon_font_size',
		'back_icon_font_size'    => 'back_use_icon_font_size',
		'badge_icon_font_size'   => 'use_badge_icon',
	);

	/**
	 * Collect.
	 *
	 * @param string               $module_name Registered module name.
	 * @param array<string, mixed> $attrs         Module attrs.
	 * @return array<int, array{attr_key: string, inner_content: array<string, mixed>, property: string}>
	 */
	public static function collect( string $module_name, array $attrs ): array {
		$style_attrs = IconHostStyleSelectorRegistry::discover_style_attr_keys( $attrs );

		if ( array() === $style_attrs ) {
			return array();
		}

		$rules = array();

		foreach ( $style_attrs as $attr_key ) {
			$property = self::resolve_style_property_for_key( $attr_key );

			if ( null === $property ) {
				continue;
			}

			if ( 'font-size' === $property && ! self::is_size_attr_enabled( $attrs, $attr_key ) ) {
				continue;
			}

			$inner_content = array();

			if (
				isset( $attrs[ $attr_key ]['innerContent'] )
				&& is_array( $attrs[ $attr_key ]['innerContent'] )
			) {
				$inner_content = $attrs[ $attr_key ]['innerContent'];
			}

			$inner_content = IconHostStyleSelectorRegistry::merge_attr_default(
				$module_name,
				$attr_key,
				$inner_content
			);

			$rules[] = array(
				'attr_key'      => $attr_key,
				'inner_content' => $inner_content,
				'property'      => $property,
			);
		}

		return $rules;
	}

	/**
	 * Build icon host selector.
	 *
	 * @param string $module_name Registered module name.
	 * @param string $order_class Module order class.
	 * @param string $attr_key    Style attr key.
	 * @return string
	 */
	public static function build_icon_host_selector( string $module_name, string $order_class, string $attr_key ): string {
		return IconHostStyleSelectorRegistry::build_icon_host_selector( $module_name, $order_class, $attr_key );
	}

	/**
	 * Resolve style property for key.
	 *
	 * @param string $key Module attr key.
	 * @return string|null CSS property or null when not an icon host style attr.
	 */
	public static function resolve_style_property_for_key( string $key ): ?string {
		if ( self::is_icon_font_size_attr_key( $key ) ) {
			return 'font-size';
		}

		if ( self::is_icon_color_attr_key( $key ) ) {
			return 'color';
		}

		return null;
	}

	/**
	 * Is icon font size attr key.
	 *
	 * @param string $key Module attr key.
	 * @return bool
	 */
	private static function is_icon_font_size_attr_key( string $key ): bool {
		if ( in_array( $key, array( 'submenu_arrow_font_size', 'dsm_dir_font_size' ), true ) ) {
			return false;
		}

		if ( 'icon_size' === $key ) {
			return true;
		}

		if ( ! str_ends_with( $key, 'font_size' ) && ! str_ends_with( $key, '_font_size' ) && ! str_ends_with( $key, '_icon_size' ) ) {
			return false;
		}

		return (bool) preg_match( '/(?:icon|font_icon|open|close|pointer|tabs_icon|content_icon)/', $key );
	}

	/**
	 * Is icon color attr key.
	 *
	 * @param string $key Module attr key.
	 * @return bool
	 */
	private static function is_icon_color_attr_key( string $key ): bool {
		if ( 'icon_color' === $key || 'overlay_icon_color' === $key ) {
			return true;
		}

		return (bool) preg_match( '/_icon_color$/', $key );
	}

	/**
	 * Is size attr enabled.
	 *
	 * @param array<string, mixed> $attrs    Module attrs.
	 * @param string               $size_key Size attr key.
	 * @return bool
	 */
	private static function is_size_attr_enabled( array $attrs, string $size_key ): bool {
		if ( 'icon_font_size' === $size_key && isset( $attrs['use_icon_font_size']['innerContent'] ) ) {
			return self::is_toggle_on( $attrs, 'use_icon_font_size' );
		}

		if ( ! isset( self::TOGGLE_BY_SIZE_ATTR[ $size_key ] ) ) {
			return true;
		}

		$toggle_key = self::TOGGLE_BY_SIZE_ATTR[ $size_key ];

		if ( ! isset( $attrs[ $toggle_key ]['innerContent'] ) ) {
			return true;
		}

		return self::is_toggle_on( $attrs, $toggle_key );
	}

	/**
	 * Is toggle on.
	 *
	 * @param array<string, mixed> $attrs      Module attrs.
	 * @param string               $toggle_key Toggle attr key.
	 * @return bool
	 */
	private static function is_toggle_on( array $attrs, string $toggle_key ): bool {
		return IconAttrBreakpoint::is_toggle_on_any( $attrs, $toggle_key );
	}
}
