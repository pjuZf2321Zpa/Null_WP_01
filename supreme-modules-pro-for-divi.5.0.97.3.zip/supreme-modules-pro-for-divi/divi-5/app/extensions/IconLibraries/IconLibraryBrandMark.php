<?php
/**
 * Sanitize inline SVG brand marks for Icon Libraries settings cards.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Extensions\IconLibraries;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Allowed tags/attributes for monochrome library brand marks in admin HTML.
 */
final class IconLibraryBrandMark {

	/**
	 * Allowed SVG tags.
	 *
	 * @return array<string, array<string, bool>>
	 */
	private static function allowed_svg_tags(): array {
		return array(
			'svg'  => array(
				'xmlns'           => true,
				'viewbox'         => true,
				'width'           => true,
				'height'          => true,
				'fill'            => true,
				'stroke'          => true,
				'stroke-width'    => true,
				'stroke-linecap'  => true,
				'stroke-linejoin' => true,
				'fill-rule'       => true,
				'clip-rule'       => true,
				'aria-hidden'     => true,
				'role'            => true,
				'class'           => true,
			),
			'path' => array(
				'd'               => true,
				'fill'            => true,
				'stroke'          => true,
				'stroke-width'    => true,
				'stroke-linecap'  => true,
				'stroke-linejoin' => true,
				'fill-rule'       => true,
				'clip-rule'       => true,
			),
		);
	}

	/**
	 * Sanitize a library brand-mark SVG for safe inline output in settings labels.
	 *
	 * @param string $svg Raw inline SVG markup.
	 * @return string
	 */
	public static function sanitize_inline( string $svg ): string {
		$svg = trim( $svg );

		if ( '' === $svg ) {
			return '';
		}

		return wp_kses( $svg, self::allowed_svg_tags() );
	}
}
