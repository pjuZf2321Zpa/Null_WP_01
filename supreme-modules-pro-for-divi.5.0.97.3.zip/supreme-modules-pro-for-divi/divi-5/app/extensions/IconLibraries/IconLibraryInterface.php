<?php
/**
 * Contract for pluggable webfont icon libraries.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Extensions\IconLibraries;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Icon library definition (Tabler, Phosphor, future sets).
 */
interface IconLibraryInterface {

	/**
	 * Unique library id stored in icon settings `type`.
	 */
	public function get_id(): string;

	/**
	 * Human-readable label for settings + Show Only filter.
	 */
	public function get_label(): string;

	/**
	 * Short license note for the settings card.
	 */
	public function get_license_note(): string;

	/**
	 * Monochrome inline SVG brand mark for the settings card (currentColor-ready).
	 */
	public function get_brand_mark(): string;

	/**
	 * Supported variants (Phosphor weights, Tabler outline/filled). Empty for single-style libraries.
	 *
	 * @return array<string, string> Map of variant id => label.
	 */
	public function get_variants(): array;

	/**
	 * Default variant id when none is stored.
	 */
	public function get_default_variant(): string;

	/**
	 * Total icons shipped in the manifest.
	 */
	public function get_icon_count(): int;

	/**
	 * Sample icon id for settings preview.
	 */
	public function get_sample_icon_id(): string;

	/**
	 * Load manifest entries.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public function get_manifest(): array;

	/**
	 * Resolve one manifest entry by id + variant.
	 *
	 * @param string $icon_id Icon slug.
	 * @param string $variant Variant / weight slug.
	 * @return array<string, mixed>|null
	 */
	public function get_icon( string $icon_id, string $variant = '' ): ?array;

	/**
	 * Search manifest (indexed by searchTerms + name).
	 *
	 * @param string $query Search string.
	 * @return array<int, array<string, mixed>>
	 */
	public function search( string $query = '' ): array;

	/**
	 * Paginated manifest slice (after search).
	 *
	 * @param int    $offset Zero-based offset.
	 * @param int    $limit  Max rows.
	 * @param string $query  Optional search string.
	 * @return array<int, array<string, mixed>>
	 */
	public function get_manifest_slice( int $offset, int $limit, string $query = '' ): array;

	/**
	 * Total manifest rows matching search (before pagination).
	 *
	 * @param string $query Optional search string.
	 * @return int
	 */
	public function get_manifest_total( string $query = '' ): int;

	/**
	 * Picker render mode slug (`webfont`).
	 */
	public function get_picker_render_mode(): string;

	/**
	 * Frontend render mode slug (`webfont`).
	 */
	public function get_frontend_render_mode(): string;

	/**
	 * Self-hosted stylesheet descriptors (one entry per variant / font file).
	 *
	 * @return array<int, array{variant: string, handle: string, path: string, url: string}>
	 */
	public function get_webfont_stylesheets(): array;

	/**
	 * CSS class string for picker / frontend `<i>` glyph (without tag).
	 *
	 * @param string $icon_id Icon slug (manifest `id` / stored `unicode`).
	 * @param string $variant Variant / weight slug.
	 * @return string
	 */
	public function get_picker_font_class( string $icon_id, string $variant = '' ): string;

	/**
	 * Self-hosted `@font-face` family name for the glyph.
	 *
	 * @param string $icon_id Icon slug.
	 * @param string $variant Variant / weight slug.
	 * @return string
	 */
	public function get_picker_webfont_family( string $icon_id, string $variant = '' ): string;
}
