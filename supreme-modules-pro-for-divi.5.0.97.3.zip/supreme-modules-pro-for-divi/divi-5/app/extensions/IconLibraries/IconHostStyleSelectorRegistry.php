<?php
/**
 * Single registry for Supreme module webfont icon host selectors and defaults.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Extensions\IconLibraries;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Maps module icon style attrs to host selectors and fallback default values.
 */
final class IconHostStyleSelectorRegistry {

	/**
	 * Discover icon color/size attr keys from module attrs (class-agnostic).
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 * @return string[]
	 */
	public static function discover_style_attr_keys( array $attrs ): array {
		$keys = array();

		foreach ( array_keys( $attrs ) as $key ) {
			if ( ! is_string( $key ) || '' === $key ) {
				continue;
			}

			if ( self::is_icon_style_attr_key( $key ) ) {
				$keys[] = $key;
			}
		}

		return $keys;
	}

	/**
	 * Is icon style attr key.
	 *
	 * @param string $attr_key Module attr key.
	 * @return bool
	 */
	public static function is_icon_style_attr_key( string $attr_key ): bool {
		return null !== IconHostStyleAttrCollector::resolve_style_property_for_key( $attr_key );
	}

	/**
	 * Scoped selectors for modules with multiple icon slots (`{orderClass}` placeholder).
	 * When absent, `{orderClass} .et-pb-icon.dsm-webfont-icon-host` is used.
	 *
	 * @var array<string, array<string, string>>
	 */
	private const MODULE_SCOPED_SELECTORS = array(
		'dsm/breadcrumbs'            => array(
			'home_icon_size' => '{orderClass} .dsm_home_icon',
		),
		'dsm/post-reading-time'      => array(
			'icon_size'  => '{orderClass} .dsm_post_reading_time__icon.et-pb-icon, {orderClass} .dsm_post_reading_time__icon .dsm-webfont-icon-glyph, {orderClass} .dsm_post_reading_time__icon .dsm-native-icon-glyph',
			'icon_color' => '{orderClass} .dsm_post_reading_time__icon, {orderClass} .dsm_post_reading_time__icon .dsm-webfont-icon-glyph, {orderClass} .dsm_post_reading_time__icon .dsm-native-icon-glyph',
		),
		'dsm/image-hotspots'         => array(
			'icon_font_size' => '{orderClass} .dsm_image_hotspots_wrapper .et-pb-icon.dsm_image_hotspots_icon',
			'icon_color'     => '{orderClass} .dsm_image_hotspots_wrapper .et-pb-icon.dsm_image_hotspots_icon',
		),
		'dsm/image-accordion-child'  => array(
			'ia_icon_font_size' => '{orderClass} .et-pb-icon.dsm_image_accordion_icon',
			'ia_icon_color'     => '{orderClass} .et-pb-icon.dsm_image_accordion_icon',
		),
		'dsm/icon-list-child'        => array(
			'icon_font_size' => '{orderClass}.et_pb_module .dsm_icon_list_wrapper .et-pb-icon.dsm_icon_list_icon',
			'icon_color'     => '{orderClass}.et_pb_module .dsm_icon_list_wrapper .et-pb-icon.dsm_icon_list_icon',
		),
		'dsm/tilt-image'             => array(
			'icon_font_size'     => '{orderClass} .et-pb-icon',
			'overlay_icon_color' => '{orderClass} .et-pb-icon',
		),
		'dsm/step-flow'              => array(
			'dsm_icon_font_size' => '{orderClass} .et-pb-icon.dsm_icon, {orderClass} .et-pb-icon.dsm_icon.dsm-webfont-icon-host .dsm-webfont-icon-glyph',
			'dsm_icon_color'     => '{orderClass} .et-pb-icon.dsm_icon, {orderClass} .et-pb-icon.dsm_icon.dsm-webfont-icon-host .dsm-webfont-icon-glyph',
		),
		'dsm/stacking-card-child'    => array(
			'dsm_icon_font_size' => '.dsm_stacking_card_container {orderClass}.dsm_stacking_card_child .et-pb-icon.dsm_icon',
			'dsm_icon_color'     => '.dsm_stacking_card_container {orderClass}.dsm_stacking_card_child .et-pb-icon.dsm_icon',
		),
		'dsm/content-timeline-child' => array(
			'dsm_icon_font_size' => '.dsm-content-timeline-items-wrapper {orderClass} .dsm-icon-wrapper .et-pb-icon.dsm-icon',
			'dsm_icon_color'     => '.dsm-content-timeline-items-wrapper {orderClass} .dsm-icon-wrapper .et-pb-icon.dsm-icon',
		),
		'dsm/content-timeline'       => array(
			'dsm_pointer_icon_font_size'    => '{orderClass} .dsm-content-timeline-middle-circle .et-pb-icon.dsm-icon',
			'dsm_pointer_icon_color'        => '{orderClass} .dsm-content-timeline-middle-circle .et-pb-icon.dsm-icon',
			'dsm_pointer_active_icon_color' => '{orderClass} .dsm-content-timeline-middle-circle.dsm-timeline-pointer-active .et-pb-icon.dsm-icon',
		),
		'dsm/circle-info-child'      => array(
			'dsm_content_icon_font_size' => '.dsm_circle_info .dsm-circle-info-container {orderClass} .et-pb-icon.dsm_content_icon',
			'dsm_content_icon_color'     => '.dsm_circle_info .dsm-circle-info-container {orderClass} .et-pb-icon.dsm_content_icon',
			'dsm_icon_font_size'         => '.dsm_circle_info .dsm-circle-info-container .dsm-circle-info-button {orderClass} .et-pb-icon.dsm_icon',
			'dsm_icon_color'             => '.dsm_circle_info .dsm-circle-info-container .dsm-circle-info-button {orderClass} .et-pb-icon.dsm_icon',
		),
		'dsm/circle-info'            => array(
			'dsm_content_icon_font_size' => '{orderClass} .et-pb-icon.dsm_content_icon',
			'dsm_content_icon_color'     => '{orderClass} .et-pb-icon.dsm_content_icon',
			'dsm_icon_font_size'         => '{orderClass} .et-pb-icon.dsm_icon',
			'dsm_icon_color'             => '{orderClass} .et-pb-icon.dsm_icon',
		),
		'dsm/card'                   => array(
			'icon_content_font_size' => '{orderClass} .dsm_card_icon .et-pb-icon',
			'icon_color'             => '{orderClass} .dsm_card_icon .et-pb-icon',
			'badge_icon_font_size'   => '{orderClass} .dsm_badge_icon_wrap .et-pb-icon',
			'badge_icon_color'       => '{orderClass} .dsm_badge_icon_wrap .et-pb-icon',
			'icon_font_size'         => '{orderClass} .et_overlay .et-pb-icon',
			'overlay_icon_color'     => '{orderClass} .et_overlay .et-pb-icon',
		),
		'dsm/card-carousel-child'    => array(
			'icon_font_size'     => '.dsm_card_carousel {orderClass}.dsm-show-overlay .et_overlay .et-pb-icon',
			'overlay_icon_color' => '.dsm_card_carousel {orderClass}.dsm-show-overlay .et_overlay .et-pb-icon',
		),
		'dsm/flipbox'                => array(
			'front_icon_font_size' => '{orderClass} .dsm-flipbox-face-front .dsm_flipbox_child_image .et-pb-icon',
			'front_icon_color'     => '{orderClass} .dsm-flipbox-face-front .dsm_flipbox_child_image .et-pb-icon',
			'back_icon_font_size'  => '{orderClass} .dsm-flipbox-face-back .dsm_flipbox_child_image .et-pb-icon',
			'back_icon_color'      => '{orderClass} .dsm-flipbox-face-back .dsm_flipbox_child_image .et-pb-icon',
		),
		'dsm/faq'                    => array(
			'dsm_open_font_size'   => '{orderClass} .dsm-faq-item-wrapper .et-pb-icon.dsm_open_icon, {orderClass} .dsm-faq-item-wrapper .et-pb-icon.dsm_faq-item-open_icon',
			'dsm_open_icon_color'  => '{orderClass} .dsm-faq-item-wrapper .et-pb-icon.dsm_open_icon, {orderClass} .dsm-faq-item-wrapper .et-pb-icon.dsm_faq-item-open_icon',
			'dsm_close_font_size'  => '{orderClass} .dsm-faq-item-wrapper .et-pb-icon.dsm_close_icon, {orderClass} .dsm-faq-item-wrapper .et-pb-icon.dsm_faq-item-close_icon',
			'dsm_close_icon_color' => '{orderClass} .dsm-faq-item-wrapper .et-pb-icon.dsm_close_icon, {orderClass} .dsm-faq-item-wrapper .et-pb-icon.dsm_faq-item-close_icon',
		),
		'dsm/faq-child'              => array(
			'dsm_open_font_size'   => '.dsm-faq-container {orderClass}.dsm-faq-item-wrapper .et-pb-icon.dsm_faq-item-open_icon, .dsm-faq-container {orderClass}.dsm-faq-item-wrapper .et-pb-icon.dsm_open_icon',
			'dsm_open_icon_color'  => '.dsm-faq-container {orderClass}.dsm-faq-item-wrapper .et-pb-icon.dsm_faq-item-open_icon, .dsm-faq-container {orderClass}.dsm-faq-item-wrapper .et-pb-icon.dsm_open_icon',
			'dsm_close_font_size'  => '.dsm-faq-container {orderClass}.dsm-faq-item-wrapper .et-pb-icon.dsm_faq-item-close_icon, .dsm-faq-container {orderClass}.dsm-faq-item-wrapper .et-pb-icon.dsm_close_icon',
			'dsm_close_icon_color' => '.dsm-faq-container {orderClass}.dsm-faq-item-wrapper .et-pb-icon.dsm_faq-item-close_icon, .dsm-faq-container {orderClass}.dsm-faq-item-wrapper .et-pb-icon.dsm_close_icon',
		),
		'dsm/advanced-tabs'          => array(
			'dsm_tabs_icon_size'         => '{orderClass} .dsm-advanced-tabs-wrapper .et-pb-icon.dsm_icon, {orderClass} .dsm-advanced-tabs-wrapper .et-pb-icon.dsm-active-icon',
			'dsm_tabs_icon_color'        => '{orderClass} .dsm-advanced-tabs-wrapper .et-pb-icon.dsm_icon, {orderClass} .dsm-advanced-tabs-wrapper .et-pb-icon.dsm-active-icon',
			'dsm_tabs_active_icon_color' => '{orderClass} .dsm-advanced-tabs-wrapper .dsm-tab.dsm-active .et-pb-icon.dsm_icon, {orderClass} .dsm-advanced-tabs-wrapper .dsm-tab.dsm-active .et-pb-icon.dsm-active-icon',
			'dsm_content_icon_size'      => '{orderClass} .dsm-content-wrapper .et-pb-icon.dsm_content_icon',
			'dsm_content_icon_color'     => '{orderClass} .dsm-content-wrapper .et-pb-icon.dsm_content_icon',
		),
		'dsm/mega-menu-child'        => array(
			'dsm_icon_font_size'          => '{orderClass} .dsm-menu-text-wrapper .et-pb-icon.dsm_icon, {orderClass} .dsm-menu-text-wrapper .et-pb-icon.dsm_icon.dsm-webfont-icon-host .dsm-webfont-icon-glyph',
			'dsm_icon_color'              => '{orderClass} .dsm-mega-menu-link .et-pb-icon.dsm_icon, {orderClass} .dsm-mega-menu-link .et-pb-icon.dsm_icon.dsm-webfont-icon-host .dsm-webfont-icon-glyph',
			'dsm_cart_icon_font_size'     => '{orderClass} .dsm-menu-text-wrapper .et-pb-icon.dsm_cart_icon, {orderClass} .dsm-menu-text-wrapper .et-pb-icon.dsm_cart_icon.dsm-webfont-icon-host .dsm-webfont-icon-glyph',
			'dsm_cart_icon_color'         => '{orderClass} .dsm-mega-menu-link .et-pb-icon.dsm_cart_icon, {orderClass} .dsm-mega-menu-link .et-pb-icon.dsm_cart_icon.dsm-webfont-icon-host .dsm-webfont-icon-glyph',
			'dsm_dropdown_icon_font_size' => '{orderClass} .dsm_dropdown_open_icon, {orderClass} .dsm_dropdown_close_icon, {orderClass} .dsm_dropdown_icon, {orderClass} .dsm_dropdown_open_icon.dsm-webfont-icon-host .dsm-webfont-icon-glyph, {orderClass} .dsm_dropdown_close_icon.dsm-webfont-icon-host .dsm-webfont-icon-glyph, {orderClass} .dsm_dropdown_icon.dsm-webfont-icon-host .dsm-webfont-icon-glyph',
			'dsm_dropdown_icon_color'     => '{orderClass} .dsm_dropdown_open_icon, {orderClass} .dsm_dropdown_close_icon, {orderClass} .dsm_dropdown_icon, {orderClass} .dsm_dropdown_open_icon.dsm-webfont-icon-host .dsm-webfont-icon-glyph, {orderClass} .dsm_dropdown_close_icon.dsm-webfont-icon-host .dsm-webfont-icon-glyph, {orderClass} .dsm_dropdown_icon.dsm-webfont-icon-host .dsm-webfont-icon-glyph',
		),
		'dsm/mega-menu'              => array(
			'dsm_search_icon_font_size' => '{orderClass} .dsm-mega-menu-search-button .dsm_search_icon, {orderClass} .dsm-mega-menu-search-button .dsm_search_icon.dsm-webfont-icon-host .dsm-webfont-icon-glyph',
			'dsm_search_icon_color'     => '{orderClass} .dsm-mega-menu-search-button .dsm_search_icon, {orderClass} .dsm-mega-menu-search-button .dsm_search_icon.dsm-webfont-icon-host .dsm-webfont-icon-glyph',
		),
		'dsm/advanced-tabs-child'    => array(
			'dsm_tabs_icon_size'         => '.dsm-advanced-tabs-container {orderClass} .et-pb-icon.dsm_icon, .dsm-advanced-tabs-container {orderClass} .et-pb-icon.dsm-active-icon',
			'dsm_tabs_icon_color'        => '.dsm-advanced-tabs-container {orderClass} .et-pb-icon.dsm_icon, .dsm-advanced-tabs-container {orderClass} .et-pb-icon.dsm-active-icon',
			'dsm_tabs_active_icon_color' => '.dsm-advanced-tabs-container {orderClass}.dsm-tab.dsm-active .et-pb-icon.dsm_icon, .dsm-advanced-tabs-container {orderClass}.dsm-tab.dsm-active .et-pb-icon.dsm-active-icon',
			'dsm_content_icon_size'      => '.dsm-advanced-tabs-container {orderClass}.dsm-content-wrapper .et-pb-icon.dsm_content_icon',
			'dsm_content_icon_color'     => '.dsm-advanced-tabs-container {orderClass}.dsm-content-wrapper .et-pb-icon.dsm_content_icon',
		),
	);

	/**
	 * Fallback values when attrs are omitted from saved module data (Divi default omission).
	 *
	 * @var array<string, array<string, string>>
	 */
	private const MODULE_ATTR_DEFAULTS = array(
		'dsm/image-hotspots-child' => array(
			'icon_color'     => '#ffffff',
			'icon_font_size' => '14px',
		),
		'dsm/image-hotspots'       => array(
			'icon_color'     => '#ffffff',
			'icon_font_size' => '14px',
		),
	);

	/**
	 * Build icon host selector.
	 *
	 * @param string $module_name Registered module name.
	 * @param string $order_class Module order class.
	 * @param string $attr_key    Style attr key.
	 * @return string
	 */
	public static function build_icon_host_selector( string $module_name, string $order_class, string $attr_key ): string {
		$universal = $order_class . ' .et-pb-icon.dsm-webfont-icon-host';

		if ( ! isset( self::MODULE_SCOPED_SELECTORS[ $module_name ][ $attr_key ] ) ) {
			return $universal;
		}

		return str_replace(
			'{orderClass}',
			$order_class,
			self::MODULE_SCOPED_SELECTORS[ $module_name ][ $attr_key ]
		);
	}

	/**
	 * Merge attr default.
	 *
	 * @param string               $module_name Registered module name.
	 * @param string               $attr_key    Style attr key.
	 * @param array<string, mixed> $inner_content Attr innerContent tree.
	 * @return array<string, mixed>
	 */
	public static function merge_attr_default( string $module_name, string $attr_key, array $inner_content ): array {
		$default = self::MODULE_ATTR_DEFAULTS[ $module_name ][ $attr_key ] ?? null;

		if ( ! is_string( $default ) || '' === $default ) {
			return $inner_content;
		}

		$desktop_value = $inner_content['desktop']['value'] ?? '';

		if ( is_string( $desktop_value ) && '' !== $desktop_value ) {
			return $inner_content;
		}

		if ( ! is_array( $inner_content['desktop'] ?? null ) ) {
			$inner_content['desktop'] = array();
		}

		$inner_content['desktop']['value'] = $default;

		return $inner_content;
	}
}
