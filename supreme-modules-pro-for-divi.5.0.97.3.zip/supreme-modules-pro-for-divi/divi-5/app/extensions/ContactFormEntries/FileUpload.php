<?php
/**
 * File upload for Contact Form Pro (Supreme Contact Field type=file).
 *
 * Divi’s contact form AJAX uses serializeArray() and cannot send multipart files.
 * Frontend uploads via admin-ajax first, then posts an attachment ID hidden field.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Extensions\ContactFormEntries;

use DiviSupreme\Extensions\ContactFormEntries as Entries;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Accepts temp AJAX uploads for field-type File (attachment to entries is
 * handled by ContactFormFields::attach_file_fields).
 */
class FileUpload {

	/**
	 * AJAX multipart field name (FE FormData; not posted via Divi serialize).
	 *
	 * Per-field submit tokens use `dsm_cf_file_id_{field_id}` and are attached by
	 * ContactFormFields::attach_file_fields().
	 */
	public const FILE_INPUT_NAME = 'dsm_cf_file';

	/**
	 * Entry meta: attachment IDs.
	 */
	public const META_ATTACHMENTS = '_dsm_cf_attachments';

	/**
	 * Attachment meta: marks a temporary pre-submit upload.
	 */
	public const META_TEMP = '_dsm_cf_upload_temp';

	/**
	 * AJAX action.
	 */
	public const AJAX_ACTION = 'dsm_cf_upload_file';

	/**
	 * Whether layout CSS was printed.
	 *
	 * @var bool
	 */
	private static $style_printed = false;

	/**
	 * Constructor.
	 */
	public function __construct() {
		\add_action( 'wp_ajax_' . self::AJAX_ACTION, array( $this, 'ajax_upload' ) );
		\add_action( 'wp_ajax_nopriv_' . self::AJAX_ACTION, array( $this, 'ajax_upload' ) );
		\add_action( 'before_delete_post', array( $this, 'delete_entry_attachments' ), 10, 1 );
		\add_action( 'admin_post_dsm_cf_download_attachment', array( $this, 'download_attachment' ) );
		\add_action( self::cron_hook(), array( $this, 'purge_expired_temp_uploads' ) );

		if ( ! \wp_next_scheduled( self::cron_hook() ) ) {
			\wp_schedule_event( \time() + \HOUR_IN_SECONDS, 'daily', self::cron_hook() );
		}
	}

	/**
	 * Cron hook name.
	 *
	 * @return string
	 */
	public static function cron_hook(): string {
		return 'dsm_cf_purge_temp_uploads';
	}

	/**
	 * Max upload size in megabytes.
	 *
	 * @return int
	 */
	public static function get_max_mb(): int {
		$mb = \absint( Entries::get_setting( 'dsm_cf_file_max_mb', '5' ) );
		if ( $mb < 1 ) {
			$mb = 5;
		}
		if ( $mb > 64 ) {
			$mb = 64;
		}

		return $mb;
	}

	/**
	 * Allowed extensions (lowercase, no dots).
	 *
	 * @return array<int, string>
	 */
	public static function get_allowed_extensions(): array {
		$raw   = Entries::get_setting(
			'dsm_cf_file_allowed',
			'pdf,jpg,jpeg,png,gif,webp,doc,docx,txt,zip'
		);
		$parts = \preg_split( '/[\s,]+/', \strtolower( $raw ) );
		if ( ! \is_array( $parts ) ) {
			return array( 'pdf', 'jpg', 'png' );
		}

		$out = array();
		foreach ( $parts as $part ) {
			$ext = \sanitize_key( \ltrim( (string) $part, '.' ) );
			if ( '' !== $ext ) {
				$out[] = $ext;
			}
		}

		return array() !== $out ? \array_values( \array_unique( $out ) ) : array( 'pdf', 'jpg', 'png' );
	}

	/**
	 * VB localize payload (limits only; field UI lives on dsm/contact-form-field).
	 *
	 * @return array<string, mixed>
	 */
	public static function get_vb_config(): array {
		return array(
			'maxMb'   => self::get_max_mb(),
			'allowed' => \implode( ',', self::get_allowed_extensions() ),
		);
	}

	/**
	 * Public enqueue for Supreme Contact Field (type=file) renders.
	 *
	 * @return void
	 */
	public static function enqueue_frontend_public(): void {
		self::enqueue_frontend();
	}

	/**
	 * Enqueue FE uploader for Supreme Contact Field (type=file).
	 *
	 * @return void
	 */
	private static function enqueue_frontend(): void {
		if ( \is_admin() || ! \defined( 'DSM_DIR_URL' ) || ! \defined( 'DSM_DIR_PATH' ) ) {
			return;
		}

		$handle = 'dsm-cf-file-upload';
		if ( \wp_script_is( $handle, 'enqueued' ) ) {
			return;
		}

		$src  = \DSM_DIR_URL . 'public/contact-form-file-upload-frontend.js';
		$path = \DSM_DIR_PATH . 'divi-5/public/contact-form-file-upload-frontend.js';
		$ver  = \is_readable( $path ) ? (string) \filemtime( $path ) : '1.0.0';

		\wp_enqueue_script( $handle, $src, array(), $ver, true );
		\wp_localize_script(
			$handle,
			'dsmCfFileUpload',
			array(
				'ajaxUrl' => \admin_url( 'admin-ajax.php' ),
				'action'  => self::AJAX_ACTION,
				'nonce'   => \wp_create_nonce( self::AJAX_ACTION ),
				'maxMb'   => self::get_max_mb(),
				'allowed' => self::get_allowed_extensions(),
				'i18n'    => array(
					'uploading' => __( 'Uploading…', 'dsm-supreme-modules-pro-for-divi' ),
					'ready'     => __( 'File ready', 'dsm-supreme-modules-pro-for-divi' ),
					'required'  => __( 'Please choose a file before submitting.', 'dsm-supreme-modules-pro-for-divi' ),
					'failed'    => __( 'Upload failed. Please try again.', 'dsm-supreme-modules-pro-for-divi' ),
					'tooLarge'  => __( 'File is too large.', 'dsm-supreme-modules-pro-for-divi' ),
					'type'      => __( 'This file type is not allowed.', 'dsm-supreme-modules-pro-for-divi' ),
				),
			)
		);
	}

	/**
	 * Capability-gated download for private entry attachments.
	 *
	 * @return void
	 */
	public function download_attachment(): void {
		if ( ! \current_user_can( 'edit_posts' ) ) {
			\wp_die( \esc_html__( 'Sorry, you are not allowed to download this file.', 'dsm-supreme-modules-pro-for-divi' ) );
		}

		$attachment_id = isset( $_GET['attachment_id'] ) ? \absint( \wp_unslash( (string) $_GET['attachment_id'] ) ) : 0;
		$entry_id      = isset( $_GET['entry_id'] ) ? \absint( \wp_unslash( (string) $_GET['entry_id'] ) ) : 0;
		$nonce         = isset( $_GET['_wpnonce'] ) ? \sanitize_text_field( \wp_unslash( (string) $_GET['_wpnonce'] ) ) : '';

		if (
			$attachment_id <= 0
			|| $entry_id <= 0
			|| ! \wp_verify_nonce( $nonce, 'dsm_cf_download_' . $attachment_id . '_' . $entry_id )
		) {
			\wp_die( \esc_html__( 'Invalid download request.', 'dsm-supreme-modules-pro-for-divi' ) );
		}

		if ( Entries::POST_TYPE !== \get_post_type( $entry_id ) ) {
			\wp_die( \esc_html__( 'Invalid entry.', 'dsm-supreme-modules-pro-for-divi' ) );
		}

		$ids = \get_post_meta( $entry_id, self::META_ATTACHMENTS, true );
		if ( ! \is_array( $ids ) || ! \in_array( $attachment_id, \array_map( 'absint', $ids ), true ) ) {
			\wp_die( \esc_html__( 'Attachment not found on this entry.', 'dsm-supreme-modules-pro-for-divi' ) );
		}

		$file = \get_attached_file( $attachment_id );
		if ( ! \is_string( $file ) || ! \is_readable( $file ) ) {
			\wp_die( \esc_html__( 'File missing on disk.', 'dsm-supreme-modules-pro-for-divi' ) );
		}

		$mime = \get_post_mime_type( $attachment_id );
		$name = \wp_basename( $file );

		\nocache_headers();
		\header( 'Content-Type: ' . ( $mime ? $mime : 'application/octet-stream' ) );
		\header( 'Content-Disposition: attachment; filename="' . \sanitize_file_name( $name ) . '"' );
		\header( 'Content-Length: ' . (string) \filesize( $file ) );
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_readfile -- Binary download stream.
		\readfile( $file );
		exit;
	}

	/**
	 * Admin download URL for an entry attachment.
	 *
	 * @param int $attachment_id Attachment ID.
	 * @param int $entry_id      Entry ID.
	 * @return string
	 */
	public static function get_download_url( int $attachment_id, int $entry_id ): string {
		return \add_query_arg(
			array(
				'action'        => 'dsm_cf_download_attachment',
				'attachment_id' => $attachment_id,
				'entry_id'      => $entry_id,
				'_wpnonce'      => \wp_create_nonce( 'dsm_cf_download_' . $attachment_id . '_' . $entry_id ),
			),
			\admin_url( 'admin-post.php' )
		);
	}

	/**
	 * AJAX: accept a temp file upload.
	 *
	 * @return void
	 */
	public function ajax_upload(): void {
		if ( ! \check_ajax_referer( self::AJAX_ACTION, 'nonce', false ) ) {
			\wp_send_json_error(
				array(
					'message' => __( 'Invalid security token.', 'dsm-supreme-modules-pro-for-divi' ),
				),
				403
			);
		}

		if ( ! $this->allow_upload_rate() ) {
			\wp_send_json_error(
				array(
					'message' => __( 'Too many uploads. Please wait and try again.', 'dsm-supreme-modules-pro-for-divi' ),
				),
				429
			);
		}

		if ( empty( $_FILES[ self::FILE_INPUT_NAME ] ) || ! \is_array( $_FILES[ self::FILE_INPUT_NAME ] ) ) {
			\wp_send_json_error(
				array(
					'message' => __( 'No file received.', 'dsm-supreme-modules-pro-for-divi' ),
				),
				400
			);
		}

		$file = \map_deep( \wp_unslash( $_FILES[ self::FILE_INPUT_NAME ] ), 'sanitize_text_field' );
		if ( ! \is_array( $file ) ) {
			\wp_send_json_error(
				array(
					'message' => __( 'No file received.', 'dsm-supreme-modules-pro-for-divi' ),
				),
				400
			);
		}
		if ( isset( $file['name'] ) ) {
			$file['name'] = \sanitize_file_name( (string) $file['name'] );
		}
		$tmp_name = isset( $file['tmp_name'] ) ? (string) $file['tmp_name'] : '';
		if ( '' === $tmp_name || ! \is_uploaded_file( $tmp_name ) ) {
			\wp_send_json_error(
				array(
					'message' => __( 'Upload error.', 'dsm-supreme-modules-pro-for-divi' ),
				),
				400
			);
		}
		$error = isset( $file['error'] ) ? (int) $file['error'] : \UPLOAD_ERR_NO_FILE;
		if ( \UPLOAD_ERR_OK !== $error ) {
			\wp_send_json_error(
				array(
					'message' => __( 'Upload error.', 'dsm-supreme-modules-pro-for-divi' ),
				),
				400
			);
		}

		$size = isset( $file['size'] ) ? (int) $file['size'] : 0;
		$max  = self::get_max_mb() * \MB_IN_BYTES;
		if ( $size <= 0 || $size > $max ) {
			\wp_send_json_error(
				array(
					'message' => __( 'File is too large.', 'dsm-supreme-modules-pro-for-divi' ),
				),
				400
			);
		}

		$name = isset( $file['name'] ) ? (string) $file['name'] : '';
		$ext  = \strtolower( \pathinfo( $name, \PATHINFO_EXTENSION ) );
		if ( ! \in_array( $ext, self::get_allowed_extensions(), true ) ) {
			\wp_send_json_error(
				array(
					'message' => __( 'This file type is not allowed.', 'dsm-supreme-modules-pro-for-divi' ),
				),
				400
			);
		}

		\add_filter( 'upload_dir', array( $this, 'filter_upload_dir' ) );
		\add_filter( 'upload_mimes', array( $this, 'filter_upload_mimes' ), 20 );

		require_once \ABSPATH . 'wp-admin/includes/file.php';
		require_once \ABSPATH . 'wp-admin/includes/media.php';
		require_once \ABSPATH . 'wp-admin/includes/image.php';

		$upload = \wp_handle_upload(
			$file,
			array(
				'test_form' => false,
				'mimes'     => $this->allowed_mime_map(),
			)
		);

		\remove_filter( 'upload_dir', array( $this, 'filter_upload_dir' ) );
		\remove_filter( 'upload_mimes', array( $this, 'filter_upload_mimes' ), 20 );

		if ( ! \is_array( $upload ) || isset( $upload['error'] ) ) {
			\wp_send_json_error(
				array(
					'message' => isset( $upload['error'] )
						? (string) $upload['error']
						: __( 'Upload failed.', 'dsm-supreme-modules-pro-for-divi' ),
				),
				400
			);
		}

		$attachment = array(
			'post_mime_type' => isset( $upload['type'] ) ? (string) $upload['type'] : '',
			'post_title'     => \sanitize_file_name( \wp_basename( (string) ( $upload['file'] ?? $name ) ) ),
			'post_content'   => '',
			'post_status'    => 'private',
			'guid'           => isset( $upload['url'] ) ? (string) $upload['url'] : '',
		);

		$attachment_id = \wp_insert_attachment( $attachment, (string) ( $upload['file'] ?? '' ) );
		if ( ! $attachment_id || \is_wp_error( $attachment_id ) ) {
			\wp_send_json_error(
				array(
					'message' => __( 'Could not save file.', 'dsm-supreme-modules-pro-for-divi' ),
				),
				500
			);
		}

		$attachment_id = (int) $attachment_id;
		\update_post_meta( $attachment_id, self::META_TEMP, (string) \time() );

		$meta = \wp_generate_attachment_metadata( $attachment_id, (string) ( $upload['file'] ?? '' ) );
		if ( \is_array( $meta ) ) {
			\wp_update_attachment_metadata( $attachment_id, $meta );
		}

		\wp_send_json_success(
			array(
				'id'   => $attachment_id,
				'name' => \wp_basename( $name ),
			)
		);
	}

	/**
	 * Restrict mimes for this upload flow.
	 *
	 * @param array<string, string> $mimes Mimes.
	 * @return array<string, string>
	 */
	public function filter_upload_mimes( array $mimes ): array {
		unset( $mimes );

		return $this->allowed_mime_map();
	}

	/**
	 * Private subdirectory for Contact Form uploads.
	 *
	 * @param array<string, string> $dirs Upload dirs.
	 * @return array<string, string>
	 */
	public function filter_upload_dir( array $dirs ): array {
		$subdir         = '/dsm-cf-uploads';
		$dirs['subdir'] = $subdir;
		$dirs['path']   = ( $dirs['basedir'] ?? '' ) . $subdir;
		$dirs['url']    = ( $dirs['baseurl'] ?? '' ) . $subdir;

		$path = (string) ( $dirs['path'] ?? '' );
		if ( '' !== $path && ! \is_dir( $path ) ) {
			\wp_mkdir_p( $path );
		}
		if ( '' !== $path && \is_dir( $path ) ) {
			$htaccess = $path . '/.htaccess';
			if ( ! \file_exists( $htaccess ) ) {
				// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- One-time deny rules.
				\file_put_contents( $htaccess, "Options -Indexes\nDeny from all\n" );
			}
			$index = $path . '/index.php';
			if ( ! \file_exists( $index ) ) {
				// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- Silence directory listing.
				\file_put_contents( $index, "<?php\n// Silence is golden.\n" );
			}
		}

		return $dirs;
	}

	/**
	 * Delete attachments when an entry is deleted.
	 *
	 * @param int $post_id Post ID.
	 * @return void
	 */
	public function delete_entry_attachments( int $post_id ): void {
		if ( Entries::POST_TYPE !== \get_post_type( $post_id ) ) {
			return;
		}

		$ids = \get_post_meta( $post_id, self::META_ATTACHMENTS, true );
		if ( ! \is_array( $ids ) ) {
			return;
		}

		foreach ( $ids as $attachment_id ) {
			$attachment_id = \absint( $attachment_id );
			if ( $attachment_id > 0 ) {
				\wp_delete_attachment( $attachment_id, true );
			}
		}
	}

	/**
	 * Purge temp uploads older than 24 hours.
	 *
	 * @return void
	 */
	public function purge_expired_temp_uploads(): void {
		$q = new \WP_Query(
			array(
				'post_type'              => 'attachment',
				'post_status'            => 'private',
				'posts_per_page'         => 50,
				'fields'                 => 'ids',
				'no_found_rows'          => true,
				'update_post_meta_cache' => false,
				'update_post_term_cache' => false,
				// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Temp upload purge by age meta.
				'meta_query'             => array(
					array(
						'key'     => self::META_TEMP,
						'value'   => (string) ( \time() - \DAY_IN_SECONDS ),
						'compare' => '<',
						'type'    => 'NUMERIC',
					),
				),
			)
		);

		foreach ( $q->posts as $attachment_id ) {
			\wp_delete_attachment( (int) $attachment_id, true );
		}
	}

	/**
	 * Simple IP rate limit for nopriv uploads.
	 *
	 * @return bool
	 */
	private function allow_upload_rate(): bool {
		$ip    = isset( $_SERVER['REMOTE_ADDR'] )
			? \sanitize_text_field( \wp_unslash( (string) $_SERVER['REMOTE_ADDR'] ) )
			: '';
		$key   = 'dsm_cf_up_' . \md5( '' !== $ip ? $ip : 'unknown' );
		$count = (int) \get_transient( $key );
		if ( $count >= 20 ) {
			return false;
		}
		\set_transient( $key, $count + 1, \HOUR_IN_SECONDS );

		return true;
	}

	/**
	 * Extension → MIME map for allowed types.
	 *
	 * @return array<string, string>
	 */
	private function allowed_mime_map(): array {
		$map = array(
			'pdf'  => 'application/pdf',
			'jpg'  => 'image/jpeg',
			'jpeg' => 'image/jpeg',
			'png'  => 'image/png',
			'gif'  => 'image/gif',
			'webp' => 'image/webp',
			'doc'  => 'application/msword',
			'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
			'txt'  => 'text/plain',
			'zip'  => 'application/zip',
		);

		$out = array();
		foreach ( self::get_allowed_extensions() as $ext ) {
			if ( isset( $map[ $ext ] ) ) {
				$out[ $ext ] = $map[ $ext ];
			}
		}

		return array() !== $out ? $out : array( 'pdf' => 'application/pdf' );
	}

	/**
	 * Layout CSS once.
	 *
	 * @return void
	 */
	public static function print_layout_style(): void {
		if ( self::$style_printed ) {
			return;
		}
		self::$style_printed = true;

		$css = '.et_pb_contact_form .dsm-cf-file-upload,'
			. 'form.et_pb_contact_form .dsm-cf-file-upload,'
			. '.et_pb_contact_form_container .dsm-cf-file-upload{'
			. 'display:flex;width:100%;max-width:100%;flex:0 0 100%;flex-direction:column;'
			. 'clear:both;margin:1em 0;box-sizing:border-box;gap:.5em;'
			. '}'
			. '.dsm-cf-file-upload--align-left{align-items:flex-start;}'
			. '.dsm-cf-file-upload--align-center{align-items:center;}'
			. '.dsm-cf-file-upload--align-right{align-items:flex-end;}'
			. '.dsm-cf-file-upload--align-left .dsm-cf-file-upload__dropzone,'
			. '.dsm-cf-file-upload--align-center .dsm-cf-file-upload__dropzone,'
			. '.dsm-cf-file-upload--align-right .dsm-cf-file-upload__dropzone{width:100%;max-width:28rem;}'
			. '.dsm-cf-file-upload--align-center .dsm-cf-file-upload__dropzone{margin-inline:auto;}'
			. '.dsm-cf-file-upload--align-right .dsm-cf-file-upload__dropzone{margin-left:auto;}'
			. '.dsm-cf-file-upload__heading{'
			. 'line-height:var(--dsm-cf-file-label-line-height,1.3);'
			. 'color:var(--dsm-cf-file-label-color,#1d2327);'
			. 'font-size:var(--dsm-cf-file-label-size,14px);'
			. 'font-weight:var(--dsm-cf-file-label-weight,600);'
			. 'font-style:var(--dsm-cf-file-label-style,normal);'
			. 'font-family:var(--dsm-cf-file-label-family,inherit);'
			. 'letter-spacing:var(--dsm-cf-file-label-letter-spacing,normal);'
			. 'text-transform:var(--dsm-cf-file-label-transform,none);'
			. '}'
			. '.dsm-cf-file-upload__dropzone{'
			. 'position:relative;display:flex;flex-direction:column;align-items:center;justify-content:center;'
			. 'gap:.5rem;min-height:7.5rem;padding:1.25rem 1rem;box-sizing:border-box;cursor:pointer;'
			. 'border-width:var(--dsm-cf-file-border-width,2px);'
			. 'border-style:var(--dsm-cf-file-border-style,dashed);'
			. 'border-color:var(--dsm-cf-file-input-border-color,#c3c4c7);'
			// background-color only — never the `background` shorthand (wipes gradient/image).
			. 'background-color:var(--dsm-cf-file-input-bg-color,#f6f7f7);'
			. 'background-size:cover;'
			. 'background-position:center;'
			. 'border-radius:var(--dsm-cf-file-input-radius,8px);'
			. 'transition:border-color .15s ease,box-shadow .15s ease;'
			. '}'
			. '.dsm-cf-file-upload__dropzone:hover,'
			. '.dsm-cf-file-upload__dropzone:focus-within,'
			. '.dsm-cf-file-upload.is-dragover .dsm-cf-file-upload__dropzone{'
			. 'border-color:#8c8f94;box-shadow:inset 0 0 0 9999px rgba(0,0,0,.04);'
			. '}'
			. '.dsm-cf-file-upload.is-ready .dsm-cf-file-upload__dropzone{'
			. 'border-style:solid;border-color:#00a32a;box-shadow:inset 0 0 0 9999px rgba(0,163,42,.1);'
			. '}'
			. '.dsm-cf-file-upload .dsm-cf-file-input{'
			. 'position:absolute;inset:0;width:100%;height:100%;margin:0;padding:0;opacity:0;cursor:pointer;'
			. '}'
			. '.dsm-cf-file-upload__icon{display:flex;color:#646970;line-height:0;}'
			. '.dsm-cf-file-upload.is-ready .dsm-cf-file-upload__icon{color:#00a32a;}'
			. '.dsm-cf-file-upload__cta{'
			. 'text-align:center;'
			. 'font-size:var(--dsm-cf-file-cta-size,15px);'
			. 'font-weight:var(--dsm-cf-file-cta-weight,600);'
			. 'font-style:var(--dsm-cf-file-cta-style,normal);'
			. 'font-family:var(--dsm-cf-file-cta-family,inherit);'
			. 'color:var(--dsm-cf-file-cta-color,#1d2327);'
			. 'line-height:var(--dsm-cf-file-cta-line-height,1.3);'
			. 'letter-spacing:var(--dsm-cf-file-cta-letter-spacing,normal);'
			. 'text-transform:var(--dsm-cf-file-cta-transform,none);'
			. '}'
			. '.dsm-cf-file-upload__hint{'
			. 'text-align:center;'
			. 'font-size:var(--dsm-cf-file-hint-size,13px);'
			. 'font-weight:var(--dsm-cf-file-hint-weight,400);'
			. 'font-style:var(--dsm-cf-file-hint-style,normal);'
			. 'font-family:var(--dsm-cf-file-hint-family,inherit);'
			. 'color:var(--dsm-cf-file-hint-color,#646970);'
			. 'line-height:var(--dsm-cf-file-hint-line-height,1.35);'
			. 'letter-spacing:var(--dsm-cf-file-hint-letter-spacing,normal);'
			. 'text-transform:var(--dsm-cf-file-hint-transform,none);'
			. '}'
			. '.dsm-cf-file-upload__name{font-size:.875rem;font-weight:500;text-align:center;word-break:break-all;}'
			. '.dsm-cf-file-upload.is-ready .dsm-cf-file-upload__cta,'
			. '.dsm-cf-file-upload.is-ready .dsm-cf-file-upload__hint{display:none;}'
			. '.dsm-cf-file-upload__status{margin:0;font-size:.875em;color:#50575e;}'
			. '.dsm-cf-file-upload__status.is-error{color:#b32d2e;}'
			. '.dsm-cf-file-upload__status.is-ok{color:#007017;}';

		$version = \defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';
		\wp_register_style( 'dsm-cf-file-upload-layout', false, array(), $version );
		\wp_enqueue_style( 'dsm-cf-file-upload-layout' );
		\wp_add_inline_style( 'dsm-cf-file-upload-layout', $css );
	}
}
