<?php
/**
 * HCaptcha integration for Contact Form Pro.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Extensions\ContactFormEntries;

use DiviSupreme\Extensions\ContactFormEntries as Entries;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Injects and verifies hCaptcha on Divi Contact Form blocks.
 *
 * @see https://docs.hcaptcha.com/
 */
class Hcaptcha {

	/**
	 * POST field name used by the hCaptcha widget.
	 */
	public const TOKEN_FIELD = 'h-captcha-response';

	/**
	 * Whether the hCaptcha script was enqueued this request.
	 *
	 * @var bool
	 */
	private static $script_enqueued = false;

	/**
	 * Whether layout CSS was printed this request.
	 *
	 * @var bool
	 */
	private static $style_printed = false;

	/**
	 * Constructor.
	 */
	public function __construct() {
		\add_filter( 'render_block', array( $this, 'inject_widget' ), 26, 2 );
	}

	/**
	 * Whether site-wide hCaptcha default is on.
	 *
	 * @return bool
	 */
	public static function is_site_default_enabled(): bool {
		return 'on' === Entries::get_setting( 'dsm_cf_hcaptcha_enabled', 'off' );
	}

	/**
	 * Site key from settings.
	 *
	 * @return string
	 */
	public static function get_site_key(): string {
		return \trim( Entries::get_setting( 'dsm_cf_hcaptcha_site_key', '' ) );
	}

	/**
	 * Secret key from settings.
	 *
	 * @return string
	 */
	public static function get_secret_key(): string {
		return \trim( Entries::get_setting( 'dsm_cf_hcaptcha_secret_key', '' ) );
	}

	/**
	 * Site default placement.
	 *
	 * @return string above_button|below_button|above_fields
	 */
	public static function get_site_default_placement(): string {
		$placement = \sanitize_key( Entries::get_setting( 'dsm_cf_hcaptcha_placement', 'above_button' ) );

		return self::normalize_placement( $placement );
	}

	/**
	 * Site default horizontal alignment.
	 *
	 * @return string left|center|right
	 */
	public static function get_site_default_align(): string {
		$align = \sanitize_key( Entries::get_setting( 'dsm_cf_hcaptcha_align', 'right' ) );

		return self::normalize_align( $align );
	}

	/**
	 * Normalize placement slug.
	 *
	 * @param string $placement Raw placement.
	 * @return string
	 */
	public static function normalize_placement( string $placement ): string {
		$allowed = array( 'above_button', 'below_button', 'above_fields' );

		return \in_array( $placement, $allowed, true ) ? $placement : 'above_button';
	}

	/**
	 * Normalize alignment slug.
	 *
	 * @param string $align Raw alignment.
	 * @return string
	 */
	public static function normalize_align( string $align ): string {
		$allowed = array( 'left', 'center', 'right' );

		return \in_array( $align, $allowed, true ) ? $align : 'right';
	}

	/**
	 * Placement for a Contact Form block.
	 *
	 * @param array<string, mixed> $block Parsed block.
	 * @return string
	 */
	public static function get_placement_for_block( array $block ): string {
		$attrs = isset( $block['attrs'] ) && \is_array( $block['attrs'] ) ? $block['attrs'] : array();
		$value = '';

		if ( isset( $attrs['dsm_cf_hcaptcha_placement']['innerContent']['desktop']['value'] ) ) {
			$value = (string) $attrs['dsm_cf_hcaptcha_placement']['innerContent']['desktop']['value'];
		}

		$value = \sanitize_key( $value );
		if ( '' === $value || 'inherit' === $value ) {
			return self::get_site_default_placement();
		}

		return self::normalize_placement( $value );
	}

	/**
	 * Alignment for a Contact Form block.
	 *
	 * @param array<string, mixed> $block Parsed block.
	 * @return string
	 */
	public static function get_align_for_block( array $block ): string {
		$attrs = isset( $block['attrs'] ) && \is_array( $block['attrs'] ) ? $block['attrs'] : array();
		$value = '';

		if ( isset( $attrs['dsm_cf_hcaptcha_align']['innerContent']['desktop']['value'] ) ) {
			$value = (string) $attrs['dsm_cf_hcaptcha_align']['innerContent']['desktop']['value'];
		}

		$value = \sanitize_key( $value );
		if ( '' === $value || 'inherit' === $value ) {
			return self::get_site_default_align();
		}

		return self::normalize_align( $value );
	}

	/**
	 * Public config for Visual Builder localize.
	 *
	 * @return array<string, mixed>
	 */
	public static function get_vb_config(): array {
		return array(
			'enabledByDefault' => self::is_site_default_enabled(),
			'siteKey'          => self::get_site_key(),
			'placement'        => self::get_site_default_placement(),
			'align'            => self::get_site_default_align(),
		);
	}

	/**
	 * Whether hCaptcha should run for a block (mode + keys).
	 *
	 * @param array<string, mixed> $block Parsed block.
	 * @return bool
	 */
	public static function is_enabled_for_block( array $block ): bool {
		$mode = Entries::get_block_mode_attr( $block, 'dsm_cf_hcaptcha' );
		if ( 'off' === $mode ) {
			return false;
		}
		if ( 'inherit' === $mode && ! self::is_site_default_enabled() ) {
			return false;
		}
		if ( 'on' !== $mode && 'inherit' !== $mode ) {
			return false;
		}

		return '' !== self::get_site_key() && '' !== self::get_secret_key();
	}

	/**
	 * Inject hCaptcha widget markup at the chosen placement.
	 *
	 * @param string               $block_content Block HTML.
	 * @param array<string, mixed> $block         Parsed block.
	 * @return string
	 */
	public function inject_widget( string $block_content, array $block ): string {
		$block_name = isset( $block['blockName'] ) ? (string) $block['blockName'] : '';
		if ( 'divi/contact-form' !== $block_name || '' === $block_content ) {
			return $block_content;
		}

		if ( ! self::is_enabled_for_block( $block ) ) {
			return $block_content;
		}

		if ( false !== \strpos( $block_content, 'dsm-cf-hcaptcha' ) ) {
			return $block_content;
		}

		self::enqueue_script();
		self::print_layout_style();

		$placement = self::get_placement_for_block( $block );
		$align     = self::get_align_for_block( $block );
		$widget    = self::render_widget_html( $placement, $align );

		return self::insert_widget( $block_content, $widget, $placement );
	}

	/**
	 * Verify hCaptcha token from the current request.
	 *
	 * @return bool True when valid.
	 */
	public static function verify_request(): bool {
		$secret = self::get_secret_key();
		if ( '' === $secret ) {
			return false;
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Divi owns form nonce.
		$token = isset( $_POST[ self::TOKEN_FIELD ] )
			? \sanitize_text_field( \wp_unslash( (string) $_POST[ self::TOKEN_FIELD ] ) )
			: '';
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		if ( '' === $token ) {
			return false;
		}

		$body = array(
			'secret'   => $secret,
			'response' => $token,
			'remoteip' => isset( $_SERVER['REMOTE_ADDR'] )
				? \sanitize_text_field( \wp_unslash( (string) $_SERVER['REMOTE_ADDR'] ) )
				: '',
		);

		$site_key = self::get_site_key();
		if ( '' !== $site_key ) {
			$body['sitekey'] = $site_key;
		}

		$response = \wp_remote_post(
			'https://api.hcaptcha.com/siteverify',
			array(
				'timeout' => 10,
				'body'    => $body,
			)
		);

		if ( \is_wp_error( $response ) ) {
			return false;
		}

		$code = (int) \wp_remote_retrieve_response_code( $response );
		$data = \json_decode( (string) \wp_remote_retrieve_body( $response ), true );
		if ( 200 !== $code || ! \is_array( $data ) ) {
			return false;
		}

		return ! empty( $data['success'] );
	}

	/**
	 * Widget HTML.
	 *
	 * @param string $placement Placement slug.
	 * @param string $align     Alignment slug.
	 * @return string
	 */
	private static function render_widget_html( string $placement, string $align ): string {
		return \sprintf(
			'<div class="dsm-cf-hcaptcha dsm-cf-hcaptcha--%2$s dsm-cf-hcaptcha--align-%3$s">'
			. '<input type="hidden" name="dsm_cf_hcaptcha_active" value="1" />'
			. '<div class="h-captcha" data-sitekey="%1$s"></div>'
			. '</div>',
			\esc_attr( self::get_site_key() ),
			\esc_attr( self::normalize_placement( $placement ) ),
			\esc_attr( self::normalize_align( $align ) )
		);
	}

	/**
	 * Insert widget into form HTML for the chosen placement.
	 *
	 * @param string $block_content Form HTML.
	 * @param string $widget        Widget HTML.
	 * @param string $placement     Placement slug.
	 * @return string
	 */
	private static function insert_widget( string $block_content, string $widget, string $placement ): string {
		$placement = self::normalize_placement( $placement );

		if ( 'above_fields' === $placement ) {
			$updated = \preg_replace(
				'/(<form\b[^>]*>)/i',
				'$1' . $widget,
				$block_content,
				1
			);
			if ( \is_string( $updated ) && $updated !== $block_content ) {
				return $updated;
			}
		}

		if ( 'above_button' === $placement ) {
			if ( false !== \stripos( $block_content, 'et_contact_bottom_container' ) ) {
				$updated = \preg_replace(
					'/(<div\b[^>]*class="[^"]*\bet_contact_bottom_container\b[^"]*"[^>]*>)/i',
					$widget . '$1',
					$block_content,
					1
				);
				if ( \is_string( $updated ) && $updated !== $block_content ) {
					return $updated;
				}
			}
		}

		if ( 'below_button' === $placement ) {
			if ( false !== \stripos( $block_content, 'et_contact_bottom_container' ) ) {
				$updated = \preg_replace(
					'/(<div\b[^>]*class="[^"]*\bet_contact_bottom_container\b[^"]*"[^>]*>.*?<\/div>)/is',
					'$1' . $widget,
					$block_content,
					1
				);
				if ( \is_string( $updated ) && $updated !== $block_content ) {
					return $updated;
				}
			}
		}

		if ( false !== \stripos( $block_content, '</form>' ) ) {
			return (string) \preg_replace( '/<\/form>/i', $widget . '</form>', $block_content, 1 );
		}

		return $block_content;
	}

	/**
	 * Enqueue hCaptcha API once.
	 *
	 * @return void
	 */
	private static function enqueue_script(): void {
		if ( self::$script_enqueued ) {
			return;
		}

		self::$script_enqueued = true;

		// phpcs:disable WordPress.WP.EnqueuedResourceParameters.MissingVersion -- Vendor CDN script without version query.
		\wp_enqueue_script(
			'dsm-cf-hcaptcha',
			'https://js.hcaptcha.com/1/api.js',
			array(),
			null,
			true
		);
		// phpcs:enable WordPress.WP.EnqueuedResourceParameters.MissingVersion
		\wp_script_add_data( 'dsm-cf-hcaptcha', 'strategy', 'defer' );
	}

	/**
	 * Print once: keep hCaptcha on its own full-width row in flex forms.
	 *
	 * @return void
	 */
	private static function print_layout_style(): void {
		if ( self::$style_printed ) {
			return;
		}

		self::$style_printed = true;

		$css = '.et_pb_contact_form .dsm-cf-hcaptcha,'
			. 'form.et_pb_contact_form .dsm-cf-hcaptcha,'
			. '.et_pb_contact_form_container .dsm-cf-hcaptcha{'
			. 'display:flex;width:100%;max-width:100%;'
			. 'flex:0 0 100%;align-self:stretch;'
			. 'clear:both;margin:1em 0;box-sizing:border-box;'
			. 'align-items:center;'
			. '}'
			. '.et_pb_contact_form .dsm-cf-hcaptcha--align-left,'
			. 'form.et_pb_contact_form .dsm-cf-hcaptcha--align-left,'
			. '.et_pb_contact_form_container .dsm-cf-hcaptcha--align-left{'
			. 'justify-content:flex-start;'
			. '}'
			. '.et_pb_contact_form .dsm-cf-hcaptcha--align-center,'
			. 'form.et_pb_contact_form .dsm-cf-hcaptcha--align-center,'
			. '.et_pb_contact_form_container .dsm-cf-hcaptcha--align-center{'
			. 'justify-content:center;'
			. '}'
			. '.et_pb_contact_form .dsm-cf-hcaptcha--align-right,'
			. 'form.et_pb_contact_form .dsm-cf-hcaptcha--align-right,'
			. '.et_pb_contact_form_container .dsm-cf-hcaptcha--align-right{'
			. 'justify-content:flex-end;'
			. '}'
			. '.et_pb_contact_form .dsm-cf-hcaptcha .h-captcha,'
			. '.et_pb_contact_form_container .dsm-cf-hcaptcha .h-captcha{'
			. 'display:block;'
			. '}';

		$version = \defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';
		\wp_register_style( 'dsm-cf-hcaptcha-layout', false, array(), $version );
		\wp_enqueue_style( 'dsm-cf-hcaptcha-layout' );
		\wp_add_inline_style( 'dsm-cf-hcaptcha-layout', $css );
	}
}
