<?php
/**
 * Collect Supreme Contact Field (dsm/contact-form-field) values into entries.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Extensions\ContactFormEntries;

use DiviSupreme\Extensions\ContactFormEntries as Entries;
use DiviSupreme\Modules\ContactFormField;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Merge typed Supreme fields into stored entry meta and Divi admin notification emails.
 */
class ContactFormFields {

	/**
	 * Supreme fields pending injection into the next Divi Contact Form `wp_mail` message.
	 *
	 * @var array<string, array{id:string,label:string,type:string,value:string}>
	 */
	private $pending_email_fields = array();

	/**
	 * Temp signature image paths created for the admin notification; deleted after send.
	 *
	 * @var array<int, string>
	 */
	private $pending_signature_temp_files = array();

	/**
	 * Whether the current submit failed Supreme Contact Field server-side validation.
	 *
	 * @var bool
	 */
	private $validation_failed = false;

	/**
	 * Boot hooks.
	 */
	public function __construct() {
		\add_action( 'et_pb_contact_form_submit', array( $this, 'maybe_reject_invalid_submit' ), 5, 3 );
		\add_filter( 'dsm_contact_form_entries_should_store', array( $this, 'maybe_skip_store_on_validation_failure' ), 5, 3 );
		\add_filter( 'dsm_contact_form_entries_fields', array( $this, 'merge_fields_before_store' ), 10, 2 );
		\add_action( 'dsm_contact_form_entry_stored', array( $this, 'attach_file_fields' ), 14, 3 );
		\add_action( 'et_pb_contact_form_submit', array( $this, 'maybe_arm_divi_email_merge' ), 20, 3 );
	}

	/**
	 * Reject forged / JS-off submits that violate Supreme Contact Field rules.
	 *
	 * Runs before entry storage. Divi has already finished its own WP_Error checks, so we
	 * mirror the spam hard-block pattern: do not store a successful entry and short-circuit
	 * the admin notification via `pre_wp_mail` (visitor sees Divi's generic send-failure
	 * message — per-field custom Error Message text is FE-only; server still blocks success).
	 *
	 * @param array<string, mixed> $fields            Divi processed fields.
	 * @param bool                 $et_contact_error  Whether Divi reported errors.
	 * @param array<string, mixed> $contact_form_info Form info.
	 * @return void
	 */
	public function maybe_reject_invalid_submit( $fields, $et_contact_error, $contact_form_info ): void {
		unset( $fields, $contact_form_info );
		$this->validation_failed = false;

		if ( true === (bool) $et_contact_error ) {
			return;
		}

		if ( ! $this->has_invalid_supreme_fields() ) {
			return;
		}

		$this->validation_failed = true;
		Entries::arm_block_divi_admin_email();
	}

	/**
	 * Skip Contact Form entry storage when Supreme field validation failed.
	 *
	 * @param bool                 $should_store      Whether to store.
	 * @param array<string, mixed> $fields            Fields.
	 * @param array<string, mixed> $contact_form_info Form info.
	 * @return bool
	 */
	public function maybe_skip_store_on_validation_failure( bool $should_store, array $fields, array $contact_form_info ): bool {
		unset( $fields, $contact_form_info );

		if ( $this->validation_failed ) {
			return false;
		}

		return $should_store;
	}

	/**
	 * Merge POST supreme fields into the fields array before entry storage.
	 *
	 * @param array<string, mixed> $fields            Divi fields.
	 * @param array<string, mixed> $contact_form_info Form info.
	 * @return array<string, mixed>
	 */
	public function merge_fields_before_store( array $fields, array $contact_form_info ): array {
		unset( $contact_form_info );

		$collected = $this->collect_from_request();
		if ( array() === $collected ) {
			return $fields;
		}

		foreach ( $collected as $key => $field ) {
			$fields[ $key ] = $field;
		}

		return $fields;
	}

	/**
	 * Arm a one-shot merge of Supreme field values into Divi's admin notification email.
	 *
	 * Divi builds `$this->_fields` before `et_pb_contact_form_submit` and does not accept
	 * mutations from that action, so we inject via `wp_mail` after the message is built.
	 *
	 * @param array<string, mixed> $fields            Divi processed fields.
	 * @param bool                 $et_contact_error  Whether Divi reported errors.
	 * @param array<string, mixed> $contact_form_info Form info.
	 * @return void
	 */
	public function maybe_arm_divi_email_merge( $fields, $et_contact_error, $contact_form_info ): void {
		unset( $contact_form_info );

		if ( true === (bool) $et_contact_error ) {
			return;
		}

		// Hard-blocked spam / invalid Supreme fields use pre_wp_mail; skip merge so the filter is not left dangling.
		if ( Entries::is_blocking_divi_admin_email() ) {
			return;
		}

		if ( ! \is_array( $fields ) ) {
			$fields = array();
		}

		$collected = $this->collect_from_request();
		$collected = $this->merge_file_fields_for_email( $collected );

		if ( array() === $collected ) {
			return;
		}

		$divi_keys = array();
		foreach ( \array_keys( $fields ) as $key ) {
			$divi_keys[ \strtolower( (string) $key ) ] = true;
		}

		$pending = array();
		foreach ( $collected as $key => $field ) {
			$lookup                 = \strtolower( (string) $key );
			$divi_already_has_value = isset( $divi_keys[ $lookup ] )
				&& '' !== $this->divi_field_stored_value( $fields, (string) $key );
			// Divi may already list the field with an empty value (e.g. phone
			// combined input not synced). Still inject the collected value.
			if ( $divi_already_has_value ) {
				continue;
			}
			$pending[ $key ] = $field;
		}

		if ( array() === $pending ) {
			return;
		}

		$this->pending_email_fields = $pending;
		\add_filter( 'wp_mail', array( $this, 'inject_supreme_fields_into_wp_mail' ), 20 );
	}

	/**
	 * Inject Supreme Contact Field values into Divi's Contact Form notification body.
	 *
	 * Replaces `%%field_id%%` placeholders when present; otherwise appends `Label: value`
	 * lines to match Divi's default message builder. Signature data URLs are attached as
	 * temp PNG/JPEG files (never inlined as data URLs). File uploads are filename-only
	 * in the body (stored on Contact Form Entries; not attached to this admin email).
	 *
	 * @param array<string, mixed> $args wp_mail args.
	 * @return array<string, mixed>
	 */
	public function inject_supreme_fields_into_wp_mail( array $args ): array {
		\remove_filter( 'wp_mail', array( $this, 'inject_supreme_fields_into_wp_mail' ), 20 );

		$pending                    = $this->pending_email_fields;
		$this->pending_email_fields = array();

		if ( array() === $pending ) {
			return $args;
		}

		$signature_paths = $this->build_signature_email_attachments( $pending );
		if ( array() !== $signature_paths ) {
			$args['attachments'] = $this->merge_wp_mail_attachments(
				$args['attachments'] ?? array(),
				$signature_paths
			);
			$this->arm_signature_temp_cleanup( $signature_paths );
		}

		if ( ! isset( $args['message'] ) ) {
			return $args;
		}

		$message      = (string) $args['message'];
		$append_lines = array();

		foreach ( $pending as $key => $field ) {
			if ( ! \is_array( $field ) ) {
				continue;
			}

			$value = $this->email_value_for_field( $field );
			if ( '' === \trim( $value ) ) {
				// Still clear unused placeholders from custom patterns.
				$message = \str_ireplace( '%%' . $key . '%%', '', $message );
				continue;
			}

			$safe_value  = \wp_strip_all_tags( $value );
			$placeholder = '%%' . $key . '%%';

			if ( false !== \stripos( $message, $placeholder ) ) {
				$message = \str_ireplace( $placeholder, $safe_value, $message );
				continue;
			}

			$label = \sanitize_text_field( (string) ( $field['label'] ?? '' ) );
			if ( '' === $label ) {
				$label = (string) $key;
			}

			$replaced_empty = $this->replace_empty_email_field_line( $message, $label, $safe_value );
			if ( $replaced_empty['replaced'] ) {
				$message = $replaced_empty['message'];
				continue;
			}

			$append_lines[] = \sprintf( '%1$s: %2$s', $label, $safe_value );
		}

		if ( array() !== $append_lines ) {
			$suffix  = \implode( "\r\n", $append_lines );
			$message = '' !== \trim( $message )
				? \rtrim( $message ) . "\r\n" . $suffix
				: $suffix;
		}

		$args['message'] = $message;

		return $args;
	}

	/**
	 * Value Divi already stored for a field key (case-insensitive).
	 *
	 * @param array<string, mixed> $fields Divi fields.
	 * @param string               $key    Field id.
	 * @return string
	 */
	private function divi_field_stored_value( array $fields, string $key ): string {
		if ( isset( $fields[ $key ] ) && \is_array( $fields[ $key ] ) ) {
			return \trim( (string) ( $fields[ $key ]['value'] ?? '' ) );
		}

		$lookup = \strtolower( $key );
		foreach ( $fields as $existing_key => $field ) {
			if ( \strtolower( (string) $existing_key ) !== $lookup || ! \is_array( $field ) ) {
				continue;
			}
			return \trim( (string) ( $field['value'] ?? '' ) );
		}

		return '';
	}

	/**
	 * Replace a Divi-built `Label:` line that has no value.
	 *
	 * @param string $message    Email body.
	 * @param string $label      Field label.
	 * @param string $safe_value Sanitized value.
	 * @return array{message:string,replaced:bool}
	 */
	private function replace_empty_email_field_line( string $message, string $label, string $safe_value ): array {
		$label = \trim( $label );
		if ( '' === $label || '' === $safe_value ) {
			return array(
				'message'  => $message,
				'replaced' => false,
			);
		}

		$pattern = '/^' . \preg_quote( $label, '/' ) . ':\s*$/mi';
		$count   = 0;
		$updated = \preg_replace(
			$pattern,
			\sprintf( '%1$s: %2$s', $label, $safe_value ),
			$message,
			1,
			$count
		);

		if ( ! \is_string( $updated ) || 1 !== $count ) {
			return array(
				'message'  => $message,
				'replaced' => false,
			);
		}

		return array(
			'message'  => $updated,
			'replaced' => true,
		);
	}

	/**
	 * Delete temp signature files created for the admin notification email.
	 *
	 * @return void
	 */
	public function cleanup_signature_temp_files(): void {
		\remove_action( 'wp_mail_succeeded', array( $this, 'cleanup_signature_temp_files' ), 20 );
		\remove_action( 'wp_mail_failed', array( $this, 'cleanup_signature_temp_files' ), 20 );
		\remove_action( 'shutdown', array( $this, 'cleanup_signature_temp_files' ), 20 );

		foreach ( $this->pending_signature_temp_files as $path ) {
			if ( ! \is_string( $path ) || '' === $path ) {
				continue;
			}
			// Only unlink files we created under the system temp dir.
			if ( ! $this->is_safe_signature_temp_path( $path ) ) {
				continue;
			}
			if ( \is_file( $path ) ) {
				// phpcs:ignore WordPress.WP.AlternativeFunctions.unlink_unlink -- Temp email attachment cleanup.
				\unlink( $path );
			}
		}

		$this->pending_signature_temp_files = array();
	}

	/**
	 * Attach file-type Supreme field uploads to the entry.
	 *
	 * @param int                  $entry_id          Entry ID.
	 * @param array<string, mixed> $fields            Fields.
	 * @param array<string, mixed> $contact_form_info Form info.
	 * @return void
	 */
	public function attach_file_fields( int $entry_id, array $fields, array $contact_form_info ): void {
		unset( $fields, $contact_form_info );

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Divi owns form nonce.
		// phpcs:disable ET.Sniffs.ValidatedSanitizedInput.InputNotSanitized -- Nested meta keys/types sanitized below.
		$meta = isset( $_POST['dsm_cf_field_meta'] ) && \is_array( $_POST['dsm_cf_field_meta'] )
			? \map_deep( \wp_unslash( $_POST['dsm_cf_field_meta'] ), 'sanitize_text_field' )
			: array();
		// phpcs:enable ET.Sniffs.ValidatedSanitizedInput.InputNotSanitized
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		if ( ! \is_array( $meta ) || array() === $meta ) {
			return;
		}

		$stored = \get_post_meta( $entry_id, Entries::META_FIELDS, true );
		if ( ! \is_array( $stored ) ) {
			$stored = array();
		}

		$attachment_ids = \get_post_meta( $entry_id, FileUpload::META_ATTACHMENTS, true );
		$attachment_ids = \is_array( $attachment_ids ) ? \array_map( 'absint', $attachment_ids ) : array();

		foreach ( $meta as $raw_id => $row ) {
			if ( ! \is_array( $row ) ) {
				continue;
			}
			$field_id = ContactFormField::normalize_field_id( (string) $raw_id );
			$type     = ContactFormField::normalize_type( \sanitize_key( (string) ( $row['type'] ?? '' ) ) );
			if ( 'file' !== $type ) {
				continue;
			}

			$token_key = 'dsm_cf_file_id_' . $field_id;
			// phpcs:disable WordPress.Security.NonceVerification.Missing -- Divi owns form nonce.
			$attachment_id = isset( $_POST[ $token_key ] )
				? \absint( \wp_unslash( (string) $_POST[ $token_key ] ) )
				: 0;
			// phpcs:enable WordPress.Security.NonceVerification.Missing

			if ( $attachment_id <= 0 || ! $this->is_valid_temp_attachment( $attachment_id ) ) {
				continue;
			}

			\wp_update_post(
				array(
					'ID'          => $attachment_id,
					'post_parent' => $entry_id,
					'post_status' => 'private',
				)
			);
			\delete_post_meta( $attachment_id, FileUpload::META_TEMP );

			$attachment_ids[] = $attachment_id;
			$label            = \sanitize_text_field( (string) ( $row['label'] ?? $field_id ) );
			$filename         = \get_the_title( $attachment_id );

			$stored[ $field_id ] = array(
				'id'    => $field_id,
				'label' => '' !== $label ? $label : $field_id,
				'type'  => 'file',
				'value' => $filename . ' (#' . $attachment_id . ')',
			);
		}

		$attachment_ids = \array_values( \array_unique( \array_filter( $attachment_ids ) ) );
		if ( array() !== $attachment_ids ) {
			\update_post_meta( $entry_id, FileUpload::META_ATTACHMENTS, $attachment_ids );
		}
		\update_post_meta( $entry_id, Entries::META_FIELDS, $stored );
	}

	/**
	 * Whether any posted Supreme Contact Field fails required / constraint rules.
	 *
	 * Mirrors `contact-form-field-frontend.js` (+ file-upload required check).
	 *
	 * @return bool
	 */
	private function has_invalid_supreme_fields(): bool {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Divi owns form nonce.
		// phpcs:disable ET.Sniffs.ValidatedSanitizedInput.InputNotSanitized -- Meta via map_deep; signature values sanitized via sanitize_value().
		$meta = isset( $_POST['dsm_cf_field_meta'] ) && \is_array( $_POST['dsm_cf_field_meta'] )
			? \map_deep( \wp_unslash( $_POST['dsm_cf_field_meta'] ), 'sanitize_text_field' )
			: array();

		$invalid = false;
		if ( \is_array( $meta ) && array() !== $meta ) {
			foreach ( $meta as $raw_id => $row ) {
				if ( ! \is_array( $row ) ) {
					continue;
				}

				$field_id = ContactFormField::normalize_field_id( (string) $raw_id );
				$type     = ContactFormField::normalize_type( \sanitize_key( (string) ( $row['type'] ?? 'date' ) ) );
				$required = '1' === (string) ( $row['required'] ?? '0' );

				// Hidden fields are not FE-validated; skip required/constraint checks.
				if ( 'hidden' === $type ) {
					continue;
				}

				if ( 'file' === $type ) {
					if ( $required && ! $this->has_valid_file_upload( $field_id ) ) {
						$invalid = true;
						break;
					}
					continue;
				}

				$post_key = 'dsm_cf_field_' . $field_id;
				if ( 'multi_select' === $type ) {
					$raw_value   = $this->raw_multi_select_from_request( $post_key );
					$options_map = $this->options_map_from_meta_row( $row );
				} else {
					// Signature data URLs must reach sanitize_signature_value() intact.
					$raw_value   = isset( $_POST[ $post_key ] )
						? \wp_unslash( (string) $_POST[ $post_key ] ) // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Validated before the value is stored.
						: '';
					$options_map = array();
				}

				if ( $this->field_has_invalid_chars( $type, $raw_value ) ) {
					$invalid = true;
					break;
				}

				if ( 'url' === $type && ! ContactFormField::is_plausible_url( $raw_value ) ) {
					$invalid = true;
					break;
				}

				$value = $this->sanitize_value( $type, $raw_value );
				if ( 'multi_select' === $type && array() !== $options_map ) {
					$value = $this->filter_multi_select_to_allowed_values( $value, $options_map );
				}

				if ( $required && ! $this->field_has_value( $type, $value, $raw_value ) ) {
					$invalid = true;
					break;
				}

				if ( $this->field_fails_constraints( $type, $value, $row ) ) {
					$invalid = true;
					break;
				}
			}
		}
		// phpcs:enable ET.Sniffs.ValidatedSanitizedInput.InputNotSanitized
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		return $invalid;
	}

	/**
	 * Whether a Supreme field value counts as filled (FE `hasValue` parity).
	 *
	 * @param string $type      Field type.
	 * @param string $value     Sanitized value.
	 * @param string $raw_value Raw POST value (pre-sanitize) for signature shape checks.
	 * @return bool
	 */
	private function field_has_value( string $type, string $value, string $raw_value ): bool {
		switch ( $type ) {
			case 'acceptance':
				return '' !== $value;
			case 'multi_select':
				return '' !== \trim( $value );
			case 'star_rating':
				return '' !== $value && (int) $value > 0;
			case 'signature':
				$check = '' !== $value ? $value : \trim( $raw_value );
				return 0 === \strpos( $check, 'data:image/' );
			default:
				return '' !== \trim( $value );
		}
	}

	/**
	 * Whether raw phone/number input contains disallowed characters (FE parity).
	 *
	 * Phone local (after optional `+\d+` dial prefix): digits and hyphen only.
	 * Number: optional leading `-`, digits, optional fractional part — no `e`/`E`/`+`.
	 *
	 * @param string $type      Field type.
	 * @param string $raw_value Raw POST value.
	 * @return bool True when invalid.
	 */
	private function field_has_invalid_chars( string $type, string $raw_value ): bool {
		$raw = \trim( $raw_value );
		if ( '' === $raw ) {
			return false;
		}

		if ( 'phone' === $type ) {
			$local = \preg_replace( '/^\+\d+\s*/', '', $raw ) ?? $raw;
			$local = \trim( $local );
			if ( '' === $local ) {
				return false;
			}
			return 1 !== \preg_match( '/^[\d\-]+$/', $local );
		}

		if ( 'number' === $type ) {
			return 1 !== \preg_match( '/^-?\d+(\.\d+)?$/', $raw );
		}

		return false;
	}

	/**
	 * Whether phone/number constraints from field meta are violated (FE parity).
	 *
	 * @param string               $type  Field type.
	 * @param string               $value Sanitized value.
	 * @param array<string, mixed> $row   Meta row.
	 * @return bool True when invalid.
	 */
	private function field_fails_constraints( string $type, string $value, array $row ): bool {
		$value = \trim( $value );

		if ( 'phone' !== $type && 'number' !== $type ) {
			return false;
		}

		// Number formerly posted value bounds as min/max — treat those as lengths too.
		$min_raw    = (string) ( $row['min_length'] ?? $row['min'] ?? '0' );
		$max_raw    = (string) ( $row['max_length'] ?? $row['max'] ?? '0' );
		$min_length = ContactFormField::normalize_length( \sanitize_text_field( $min_raw ) );
		$max_length = ContactFormField::normalize_length( \sanitize_text_field( $max_raw ) );
		if ( $min_length > 0 && $max_length > 0 ) {
			$max_length = \max( $min_length, $max_length );
			$min_length = \min( $min_length, $max_length );
		}

		if ( 'phone' === $type ) {
			// FE validates the local part: strip leading dial code `+\d+` + spaces.
			$check = \preg_replace( '/^\+\d+\s*/', '', $value ) ?? $value;
		} else {
			$check = $value;
		}

		$len = \strlen( $check );

		// Min length only when non-empty (required handles empty).
		if ( $min_length > 0 && $len > 0 && $len < $min_length ) {
			return true;
		}
		if ( $max_length > 0 && $len > $max_length ) {
			return true;
		}

		return false;
	}

	/**
	 * Whether a required file field has a valid temp attachment token.
	 *
	 * @param string $field_id Field id.
	 * @return bool
	 */
	private function has_valid_file_upload( string $field_id ): bool {
		$token_key = 'dsm_cf_file_id_' . $field_id;
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Divi owns form nonce.
		$attachment_id = isset( $_POST[ $token_key ] )
			? \absint( \wp_unslash( (string) $_POST[ $token_key ] ) )
			: 0;
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		return $attachment_id > 0 && $this->is_valid_temp_attachment( $attachment_id );
	}

	/**
	 * Collect non-file supreme fields from the request.
	 *
	 * @return array<string, array{id:string,label:string,type:string,value:string}>
	 */
	private function collect_from_request(): array {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Divi owns form nonce.
		// phpcs:disable ET.Sniffs.ValidatedSanitizedInput.InputNotSanitized -- Meta via map_deep; values sanitized via sanitize_value().
		$meta = isset( $_POST['dsm_cf_field_meta'] ) && \is_array( $_POST['dsm_cf_field_meta'] )
			? \map_deep( \wp_unslash( $_POST['dsm_cf_field_meta'] ), 'sanitize_text_field' )
			: array();

		$out = array();
		if ( \is_array( $meta ) && array() !== $meta ) {
			foreach ( $meta as $raw_id => $row ) {
				if ( ! \is_array( $row ) ) {
					continue;
				}

				$field_id = ContactFormField::normalize_field_id( (string) $raw_id );
				$type     = ContactFormField::normalize_type( \sanitize_key( (string) ( $row['type'] ?? 'date' ) ) );
				$label    = \sanitize_text_field( (string) ( $row['label'] ?? $field_id ) );

				if ( 'file' === $type ) {
					// Value filled after attachment in attach_file_fields().
					continue;
				}

				$post_key = 'dsm_cf_field_' . $field_id;
				if ( 'multi_select' === $type ) {
					$raw_value   = $this->raw_multi_select_from_request( $post_key );
					$options_map = $this->options_map_from_meta_row( $row );
				} else {
					// Signature data URLs must reach sanitize_signature_value() intact.
					$raw_value   = isset( $_POST[ $post_key ] )
						? \wp_unslash( (string) $_POST[ $post_key ] ) // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Validated before the value is stored.
						: '';
					$options_map = array();
				}

				$value = $this->sanitize_value( $type, $raw_value );
				if ( 'multi_select' === $type && array() !== $options_map ) {
					$value = $this->filter_multi_select_to_allowed_values( $value, $options_map );
				}

				$field_row = array(
					'id'    => $field_id,
					'label' => '' !== $label ? $label : $field_id,
					'type'  => $type,
					'value' => $value,
				);
				if ( 'multi_select' === $type && array() !== $options_map ) {
					// Used for email label display; stripped by entry storage sanitizer.
					$field_row['options_map'] = $options_map;
				}

				$out[ $field_id ] = $field_row;
			}
		}
		// phpcs:enable ET.Sniffs.ValidatedSanitizedInput.InputNotSanitized
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		return $out;
	}

	/**
	 * Add file-type Supreme fields (filename only) for email merge.
	 *
	 * Intentionally does not add paths to wp_mail attachments — files stay on the
	 * Contact Form Entry (see attach_file_fields). Autoresponder may attach separately
	 * when dsm_cf_autoresponder_attach_files is enabled.
	 *
	 * @param array<string, array{id:string,label:string,type:string,value:string}> $fields Collected fields.
	 * @return array<string, array{id:string,label:string,type:string,value:string}>
	 */
	private function merge_file_fields_for_email( array $fields ): array {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Divi owns form nonce.
		// phpcs:disable ET.Sniffs.ValidatedSanitizedInput.InputNotSanitized -- Nested meta keys/types sanitized below.
		$meta = isset( $_POST['dsm_cf_field_meta'] ) && \is_array( $_POST['dsm_cf_field_meta'] )
			? \map_deep( \wp_unslash( $_POST['dsm_cf_field_meta'] ), 'sanitize_text_field' )
			: array();
		// phpcs:enable ET.Sniffs.ValidatedSanitizedInput.InputNotSanitized
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		if ( ! \is_array( $meta ) || array() === $meta ) {
			return $fields;
		}

		foreach ( $meta as $raw_id => $row ) {
			if ( ! \is_array( $row ) ) {
				continue;
			}

			$field_id = ContactFormField::normalize_field_id( (string) $raw_id );
			$type     = ContactFormField::normalize_type( \sanitize_key( (string) ( $row['type'] ?? '' ) ) );
			if ( 'file' !== $type ) {
				continue;
			}

			$token_key = 'dsm_cf_file_id_' . $field_id;
			// phpcs:disable WordPress.Security.NonceVerification.Missing -- Divi owns form nonce.
			$attachment_id = isset( $_POST[ $token_key ] )
				? \absint( \wp_unslash( (string) $_POST[ $token_key ] ) )
				: 0;
			// phpcs:enable WordPress.Security.NonceVerification.Missing

			if ( $attachment_id <= 0 ) {
				continue;
			}

			$label    = \sanitize_text_field( (string) ( $row['label'] ?? $field_id ) );
			$filename = \get_the_title( $attachment_id );
			$file     = \get_attached_file( $attachment_id );
			if ( '' === $filename && \is_string( $file ) && '' !== $file ) {
				$filename = \wp_basename( $file );
			}

			// Filename only — do not expose private upload URLs in outbound mail.
			$value = '' !== $filename ? $filename : ( '#' . $attachment_id );

			$fields[ $field_id ] = array(
				'id'    => $field_id,
				'label' => '' !== $label ? $label : $field_id,
				'type'  => 'file',
				'value' => $value,
			);
		}

		return $fields;
	}

	/**
	 * Format a stored Supreme field value for email / admin / export display.
	 *
	 * Date, time, and datetime values stay canonical in meta; this applies the site's
	 * WordPress `date_format` / `time_format` at display time. Non-temporal types are
	 * returned unchanged (callers handle signature / multi-select separately).
	 *
	 * @param string $type  Field type slug (`date`, `time`, `datetime`, or `date_time`).
	 * @param string $value Stored / submitted value.
	 * @return string
	 */
	public static function format_value_for_display( string $type, string $value ): string {
		$type  = \sanitize_key( $type );
		$value = \trim( $value );

		if ( '' === $value ) {
			return '';
		}

		if ( 'date_time' === $type ) {
			$type = 'datetime';
		}

		if ( ! \in_array( $type, array( 'date', 'time', 'datetime' ), true ) ) {
			return $value;
		}

		$formatted = self::format_temporal_value( $type, $value );

		return '' !== $formatted ? $formatted : $value;
	}

	/**
	 * Plain-text representation of a Supreme field for Divi's notification email.
	 *
	 * File uploads are stored on the Contact Form Entry only — the admin email
	 * includes the filename (never a binary attachment or private URL).
	 *
	 * @param array{id?:string,label?:string,type?:string,value?:string} $field Field row.
	 * @return string
	 */
	private function email_value_for_field( array $field ): string {
		$type  = \sanitize_key( (string) ( $field['type'] ?? '' ) );
		$value = \trim( (string) ( $field['value'] ?? '' ) );

		if ( 'signature' === $type ) {
			if ( '' === $value ) {
				return '';
			}
			if ( 0 === \strpos( $value, 'data:image/' ) ) {
				return __( 'Signed (see attachment)', 'dsm-supreme-modules-pro-for-divi' );
			}
			return __( 'Signed', 'dsm-supreme-modules-pro-for-divi' );
		}

		if ( 'file' === $type ) {
			if ( '' === $value ) {
				return '';
			}

			return \sprintf(
				/* translators: %s: uploaded file name */
				__( '%s (Available in Contact Form Entries)', 'dsm-supreme-modules-pro-for-divi' ),
				$value
			);
		}

		if ( 'multi_select' === $type ) {
			return $this->multi_select_labels_for_display( $value, $field['options_map'] ?? array() );
		}

		if ( \in_array( $type, array( 'date', 'time', 'datetime', 'date_time' ), true ) ) {
			return self::format_value_for_display( $type, $value );
		}

		return $value;
	}

	/**
	 * Format a canonical date / time / datetime string with WP site formats.
	 *
	 * @param string $type  Normalized type: `date`, `time`, or `datetime`.
	 * @param string $value Canonical submitted value.
	 * @return string Formatted string, or empty when parsing fails.
	 */
	private static function format_temporal_value( string $type, string $value ): string {
		$timezone = \function_exists( 'wp_timezone' ) ? \wp_timezone() : new \DateTimeZone( 'UTC' );
		$parsed   = self::parse_temporal_value( $type, $value, $timezone );
		if ( ! $parsed instanceof \DateTimeImmutable ) {
			return '';
		}

		$date_format = (string) \get_option( 'date_format', 'F j, Y' );
		$time_format = (string) \get_option( 'time_format', 'g:i a' );

		switch ( $type ) {
			case 'date':
				$format = $date_format;
				break;
			case 'time':
				$format = $time_format;
				break;
			case 'datetime':
			default:
				$format = \trim( $date_format . ' ' . $time_format );
				break;
		}

		if ( '' === $format ) {
			return '';
		}

		if ( \function_exists( 'wp_date' ) ) {
			return (string) \wp_date( $format, $parsed->getTimestamp(), $timezone );
		}

		return $parsed->format( $format );
	}

	/**
	 * Parse FE / HTML input temporal values in the site timezone.
	 *
	 * Supports common shapes: `Y-m-d`, `H:i`, `H:i:s`, `Y-m-d\TH:i`, `Y-m-d\TH:i:s`,
	 * and space-separated datetime variants.
	 *
	 * @param string        $type     Normalized type.
	 * @param string        $value    Raw value.
	 * @param \DateTimeZone $timezone Site timezone.
	 * @return \DateTimeImmutable|null
	 */
	private static function parse_temporal_value( string $type, string $value, \DateTimeZone $timezone ): ?\DateTimeImmutable {
		switch ( $type ) {
			case 'date':
				$formats = array( '!Y-m-d' );
				break;
			case 'time':
				$formats = array( '!H:i:s', '!H:i' );
				break;
			case 'datetime':
				$formats = array(
					'!Y-m-d\TH:i:s',
					'!Y-m-d\TH:i',
					'!Y-m-d H:i:s',
					'!Y-m-d H:i',
				);
				break;
			default:
				return null;
		}

		foreach ( $formats as $format ) {
			$dt = \DateTimeImmutable::createFromFormat( $format, $value, $timezone );
			if ( ! $dt instanceof \DateTimeImmutable ) {
				continue;
			}

			$errors = \DateTimeImmutable::getLastErrors();
			if (
				\is_array( $errors )
				&& ( (int) ( $errors['warning_count'] ?? 0 ) > 0 || (int) ( $errors['error_count'] ?? 0 ) > 0 )
			) {
				continue;
			}

			return $dt;
		}

		return null;
	}

	/**
	 * Decode signature data URLs into temp files for wp_mail attachments.
	 *
	 * @param array<string, array{id?:string,label?:string,type?:string,value?:string}> $fields Pending fields.
	 * @return array<int, string> Absolute local paths.
	 */
	private function build_signature_email_attachments( array $fields ): array {
		$paths = array();

		foreach ( $fields as $field ) {
			if ( ! \is_array( $field ) ) {
				continue;
			}
			$type = \sanitize_key( (string) ( $field['type'] ?? '' ) );
			if ( 'signature' !== $type ) {
				continue;
			}

			$value = \trim( (string) ( $field['value'] ?? '' ) );
			if ( '' === $value || 0 !== \strpos( $value, 'data:image/' ) ) {
				continue;
			}

			$field_id = ContactFormField::normalize_field_id( (string) ( $field['id'] ?? 'signature' ) );
			$path     = $this->write_signature_temp_file( $value, $field_id );
			if ( '' !== $path ) {
				$paths[] = $path;
			}
		}

		return $paths;
	}

	/**
	 * Write a validated signature data URL to a uniquely named temp image file.
	 *
	 * @param string $data_url Sanitized PNG/JPEG data URL.
	 * @param string $field_id Field id (for filename).
	 * @return string Absolute path or empty string on failure.
	 */
	private function write_signature_temp_file( string $data_url, string $field_id ): string {
		if ( \strlen( $data_url ) > ContactFormField::SIGNATURE_MAX_BYTES ) {
			return '';
		}

		if ( 1 !== \preg_match( '#^data:image/(png|jpeg);base64,([A-Za-z0-9+/]+=*)$#', $data_url, $matches ) ) {
			return '';
		}

		$mime_subtype = $matches[1];
		// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- Decode validated PNG/JPEG signature payload for email attachment.
		$binary = \base64_decode( $matches[2], true );
		if ( false === $binary || '' === $binary ) {
			return '';
		}

		if ( \strlen( $binary ) > ContactFormField::SIGNATURE_MAX_BYTES ) {
			return '';
		}

		if ( ! $this->signature_binary_matches_mime( $binary, $mime_subtype ) ) {
			return '';
		}

		$ext     = 'jpeg' === $mime_subtype ? 'jpg' : 'png';
		$safe_id = \sanitize_file_name( $field_id );
		if ( '' === $safe_id ) {
			$safe_id = 'signature';
		}

		$dir = \get_temp_dir();
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_is_writable -- Temp dir probe before writing email attachment.
		if ( ! \is_string( $dir ) || '' === $dir || ! \is_dir( $dir ) || ! \is_writable( $dir ) ) {
			return '';
		}

		$basename = \sanitize_file_name(
			\sprintf(
				'signature-%1$s-%2$s.%3$s',
				$safe_id,
				\wp_generate_password( 8, false, false ),
				$ext
			)
		);
		if ( '' === $basename ) {
			return '';
		}

		$basename = \wp_unique_filename( $dir, $basename );
		$path     = \trailingslashit( $dir ) . $basename;

		if ( ! $this->is_safe_signature_temp_path( $path ) ) {
			return '';
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- Binary temp attachment for wp_mail.
		$written = \file_put_contents( $path, $binary );
		if ( false === $written || ! \is_readable( $path ) ) {
			return '';
		}

		return $path;
	}

	/**
	 * Whether decoded bytes match the declared PNG/JPEG subtype (magic bytes).
	 *
	 * @param string $binary       Decoded image bytes.
	 * @param string $mime_subtype png or jpeg.
	 * @return bool
	 */
	private function signature_binary_matches_mime( string $binary, string $mime_subtype ): bool {
		if ( 'png' === $mime_subtype ) {
			return 0 === \strpos( $binary, "\x89PNG\r\n\x1a\n" );
		}
		if ( 'jpeg' === $mime_subtype ) {
			return 0 === \strpos( $binary, "\xFF\xD8\xFF" );
		}

		return false;
	}

	/**
	 * Merge new attachment paths into existing wp_mail attachments.
	 *
	 * @param mixed              $existing Existing attachments (array or string).
	 * @param array<int, string> $paths    New absolute paths.
	 * @return array<int, string>
	 */
	private function merge_wp_mail_attachments( $existing, array $paths ): array {
		$merged = array();

		if ( \is_string( $existing ) && '' !== $existing ) {
			$merged[] = $existing;
		} elseif ( \is_array( $existing ) ) {
			foreach ( $existing as $item ) {
				if ( \is_string( $item ) && '' !== $item ) {
					$merged[] = $item;
				}
			}
		}

		foreach ( $paths as $path ) {
			if ( \is_string( $path ) && '' !== $path ) {
				$merged[] = $path;
			}
		}

		return \array_values( \array_unique( $merged ) );
	}

	/**
	 * Arm one-shot cleanup for signature temp files after wp_mail finishes (or on shutdown).
	 *
	 * @param array<int, string> $paths Absolute temp paths.
	 * @return void
	 */
	private function arm_signature_temp_cleanup( array $paths ): void {
		$this->pending_signature_temp_files = $paths;

		if ( ! \has_action( 'wp_mail_succeeded', array( $this, 'cleanup_signature_temp_files' ) ) ) {
			\add_action( 'wp_mail_succeeded', array( $this, 'cleanup_signature_temp_files' ), 20 );
		}
		if ( ! \has_action( 'wp_mail_failed', array( $this, 'cleanup_signature_temp_files' ) ) ) {
			\add_action( 'wp_mail_failed', array( $this, 'cleanup_signature_temp_files' ), 20 );
		}
		if ( ! \has_action( 'shutdown', array( $this, 'cleanup_signature_temp_files' ) ) ) {
			\add_action( 'shutdown', array( $this, 'cleanup_signature_temp_files' ), 20 );
		}
	}

	/**
	 * Whether a path is a writable file under the system temp directory (no traversal).
	 *
	 * @param string $path Absolute path.
	 * @return bool
	 */
	private function is_safe_signature_temp_path( string $path ): bool {
		$path = \wp_normalize_path( $path );
		if ( '' === $path || false !== \strpos( $path, "\0" ) ) {
			return false;
		}

		$base = \basename( $path );
		if ( '' === $base || '.' === $base || '..' === $base ) {
			return false;
		}
		if ( 1 !== \preg_match( '/^signature-[A-Za-z0-9_-]+\.(png|jpg)$/', $base ) ) {
			return false;
		}

		$temp_dir = \wp_normalize_path( \trailingslashit( \get_temp_dir() ) );
		$real_dir = \realpath( $temp_dir );
		if ( false === $real_dir ) {
			return false;
		}
		$real_dir = \wp_normalize_path( \trailingslashit( $real_dir ) );

		// Before write, realpath on the file may fail; validate the parent dir instead.
		$parent      = \wp_normalize_path( \dirname( $path ) );
		$real_parent = \realpath( $parent );
		if ( false === $real_parent ) {
			return false;
		}
		$real_parent = \wp_normalize_path( \trailingslashit( $real_parent ) );

		return 0 === \strpos( $real_parent, $real_dir );
	}

	/**
	 * Decode value→label map from multi-select field meta.
	 *
	 * @param array<string, mixed> $row Meta row.
	 * @return array<string, string>
	 */
	private function options_map_from_meta_row( array $row ): array {
		$raw = $row['options_map'] ?? '';
		if ( \is_array( $raw ) ) {
			$out = array();
			foreach ( $raw as $value => $label ) {
				$value = \sanitize_text_field( (string) $value );
				$label = \sanitize_text_field( (string) $label );
				if ( '' === $value ) {
					continue;
				}
				$out[ $value ] = '' !== $label ? $label : $value;
			}
			return $out;
		}

		$raw = \trim( (string) $raw );
		if ( '' === $raw ) {
			return array();
		}

		$decoded = \json_decode( $raw, true );
		if ( ! \is_array( $decoded ) ) {
			return array();
		}

		$out = array();
		foreach ( $decoded as $value => $label ) {
			$value = \sanitize_text_field( (string) $value );
			$label = \sanitize_text_field( (string) $label );
			if ( '' === $value ) {
				continue;
			}
			$out[ $value ] = '' !== $label ? $label : $value;
		}

		return $out;
	}

	/**
	 * Keep only submitted multi-select values that exist in the configured map.
	 *
	 * @param string                $value        Comma-separated values.
	 * @param array<string, string> $options_map  Value → label.
	 * @return string
	 */
	private function filter_multi_select_to_allowed_values( string $value, array $options_map ): string {
		if ( '' === $value || array() === $options_map ) {
			return $value;
		}

		$parts = \preg_split( '/\s*,\s*/', $value );
		if ( ! \is_array( $parts ) ) {
			return $value;
		}

		$clean = array();
		foreach ( $parts as $part ) {
			$part = \sanitize_text_field( \trim( (string) $part ) );
			if ( '' === $part || ! isset( $options_map[ $part ] ) ) {
				continue;
			}
			$clean[] = $part;
		}

		return \implode( ', ', $clean );
	}

	/**
	 * Map stored multi-select values to labels for email display.
	 *
	 * @param string                $value        Comma-separated submitted values.
	 * @param array<string, string> $options_map  Value → label (optional).
	 * @return string
	 */
	private function multi_select_labels_for_display( string $value, $options_map ): string {
		$value = \trim( $value );
		if ( '' === $value ) {
			return '';
		}

		if ( ! \is_array( $options_map ) || array() === $options_map ) {
			return $value;
		}

		$parts = \preg_split( '/\s*,\s*/', $value );
		if ( ! \is_array( $parts ) ) {
			return $value;
		}

		$labels = array();
		foreach ( $parts as $part ) {
			$part = \trim( (string) $part );
			if ( '' === $part ) {
				continue;
			}
			$labels[] = isset( $options_map[ $part ] ) && '' !== (string) $options_map[ $part ]
				? (string) $options_map[ $part ]
				: $part;
		}

		return \implode( ', ', $labels );
	}

	/**
	 * Read multi-select POST values as a single readable string.
	 *
	 * Supports `name[]` arrays and a comma-joined fallback string.
	 *
	 * @param string $post_key POST key (without trailing []).
	 * @return string Comma-separated selected values.
	 */
	private function raw_multi_select_from_request( string $post_key ): string {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Divi owns form nonce.
		$raw = null;
		if ( isset( $_POST[ $post_key ] ) ) {
			$raw = \map_deep( \wp_unslash( $_POST[ $post_key ] ), 'sanitize_text_field' );
		}
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		if ( null === $raw ) {
			return '';
		}

		if ( \is_array( $raw ) ) {
			$parts = array();
			foreach ( $raw as $item ) {
				$item = \trim( (string) $item );
				if ( '' === $item ) {
					continue;
				}
				$parts[] = $item;
			}
			return \implode( ', ', $parts );
		}

		return \trim( (string) $raw );
	}

	/**
	 * Sanitize submitted value by type.
	 *
	 * @param string $type  Type.
	 * @param string $value Raw.
	 * @return string
	 */
	private function sanitize_value( string $type, string $value ): string {
		$value = \trim( $value );
		switch ( $type ) {
			case 'url':
				if ( '' === $value || ! ContactFormField::is_plausible_url( $value ) ) {
					return '';
				}
				// Host-without-scheme (example.com) → https:// for storage / email.
				return \esc_url_raw( ContactFormField::normalize_url_candidate( $value ) );
			case 'number':
				$value = \trim( $value );
				if ( 1 !== \preg_match( '/^-?\d+(\.\d+)?$/', $value ) ) {
					return '';
				}
				return $value;
			case 'phone':
				// Dial code (+digits) + spaces + local digits/hyphens (FE parity).
				$value = \preg_replace( '/[^\d\+\-\s]/', '', $value ) ?? '';
				return \sanitize_text_field( \trim( $value ) );
			case 'multi_select':
				return $this->sanitize_multi_select_value( $value );
			case 'star_rating':
				if ( ! \is_numeric( $value ) ) {
					return '';
				}
				$stars = (int) $value;
				return ( $stars >= 1 && $stars <= 10 ) ? (string) $stars : '';
			case 'signature':
				return $this->sanitize_signature_value( $value );
			case 'acceptance':
				return $this->sanitize_acceptance_value( $value );
			case 'datetime':
			case 'date':
			case 'time':
			case 'hidden':
			default:
				return \sanitize_text_field( $value );
		}
	}

	/**
	 * Sanitize multi-select values (comma or newline separated) into a readable list.
	 *
	 * @param string $value Raw joined value.
	 * @return string
	 */
	private function sanitize_multi_select_value( string $value ): string {
		if ( '' === $value ) {
			return '';
		}

		$parts = \preg_split( '/\s*,\s*|\r\n|\r|\n/', $value );
		if ( ! \is_array( $parts ) ) {
			return \sanitize_text_field( $value );
		}

		$clean = array();
		foreach ( $parts as $part ) {
			$part = \sanitize_text_field( \trim( (string) $part ) );
			if ( '' === $part ) {
				continue;
			}
			$clean[] = $part;
		}

		return \implode( ', ', $clean );
	}

	/**
	 * Normalize Acceptance / Consent checkbox POST value.
	 *
	 * @param string $value Raw POST value.
	 * @return string Accepted token or empty string.
	 */
	private function sanitize_acceptance_value( string $value ): string {
		$value = \sanitize_text_field( $value );
		if ( '' === $value ) {
			return '';
		}

		$accepted = ContactFormField::ACCEPTANCE_VALUE;
		$aliases  = array( \strtolower( $accepted ), 'accepted', 'yes', '1', 'on' );

		return \in_array( \strtolower( $value ), $aliases, true ) ? $accepted : '';
	}

	/**
	 * Sanitize PNG/JPEG signature data URL with size cap.
	 *
	 * @param string $value Raw POST value.
	 * @return string Safe data URL or empty string.
	 */
	private function sanitize_signature_value( string $value ): string {
		if ( '' === $value ) {
			return '';
		}

		if ( \strlen( $value ) > ContactFormField::SIGNATURE_MAX_BYTES ) {
			return '';
		}

		if ( ! \preg_match( '#^data:image/(png|jpeg);base64,[A-Za-z0-9+/]+=*$#', $value ) ) {
			return '';
		}

		// Keep as a single-line data URL (no HTML).
		return $value;
	}

	/**
	 * Whether attachment is a valid unused temp upload.
	 *
	 * @param int $attachment_id Attachment ID.
	 * @return bool
	 */
	private function is_valid_temp_attachment( int $attachment_id ): bool {
		$post = \get_post( $attachment_id );
		if ( ! $post || 'attachment' !== $post->post_type ) {
			return false;
		}

		$temp = \get_post_meta( $attachment_id, FileUpload::META_TEMP, true );
		if ( '' === (string) $temp ) {
			return false;
		}

		return 0 === (int) $post->post_parent;
	}
}
