<?php
/**
 * GDPR retention / auto-delete for Contact Form Pro.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Extensions\ContactFormEntries;

use DiviSupreme\Extensions\ContactFormEntries as Entries;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Daily cron that permanently deletes entries older than the configured retention window.
 */
class Retention {

	/**
	 * Cron hook name.
	 */
	public const CRON_HOOK = 'dsm_cf_entries_retention_cron';

	/**
	 * Constructor.
	 */
	public function __construct() {
		\add_action( 'init', array( $this, 'maybe_schedule' ), 30 );
		\add_action( self::CRON_HOOK, array( $this, 'purge_expired_entries' ) );
	}

	/**
	 * Schedule or clear the daily retention cron based on settings.
	 *
	 * @return void
	 */
	public function maybe_schedule(): void {
		$enabled = 'on' === Entries::get_setting( 'dsm_cf_retention_enabled', 'off' );
		$next    = \wp_next_scheduled( self::CRON_HOOK );

		if ( ! $enabled ) {
			if ( $next ) {
				\wp_unschedule_event( $next, self::CRON_HOOK );
			}
			return;
		}

		if ( ! $next ) {
			\wp_schedule_event( \time() + \HOUR_IN_SECONDS, 'daily', self::CRON_HOOK );
		}
	}

	/**
	 * Permanently delete expired entries.
	 *
	 * @return void
	 */
	public function purge_expired_entries(): void {
		if ( 'on' !== Entries::get_setting( 'dsm_cf_retention_enabled', 'off' ) ) {
			return;
		}

		$days = Entries::sanitize_retention_days(
			Entries::get_setting( 'dsm_cf_retention_days', '90' )
		);
		if ( $days < 1 ) {
			return;
		}

		$keep_starred = 'on' === Entries::get_setting( 'dsm_cf_retention_keep_starred', 'on' );
		$cutoff       = \gmdate( 'Y-m-d H:i:s', \time() - ( $days * \DAY_IN_SECONDS ) );

		/**
		 * Filters the retention cutoff datetime (GMT/UTC MySQL format).
		 *
		 * @param string $cutoff Cutoff datetime.
		 * @param int    $days   Retention days.
		 */
		$cutoff = (string) \apply_filters( 'dsm_contact_form_entries_retention_cutoff', $cutoff, $days );

		$query_args = array(
			'post_type'              => Entries::POST_TYPE,
			'post_status'            => array( 'private', 'publish', 'draft', 'trash' ),
			'posts_per_page'         => 100,
			'fields'                 => 'ids',
			'orderby'                => 'date',
			'order'                  => 'ASC',
			'date_query'             => array(
				array(
					'column'    => 'post_date_gmt',
					'before'    => $cutoff,
					'inclusive' => true,
				),
			),
			'no_found_rows'          => true,
			'update_post_meta_cache' => false,
			'update_post_term_cache' => false,
		);

		if ( $keep_starred ) {
			// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Retention exclude starred.
			$query_args['meta_query'] = array(
				'relation' => 'OR',
				array(
					'key'     => Entries::META_STARRED,
					'value'   => '1',
					'compare' => '!=',
				),
				array(
					'key'     => Entries::META_STARRED,
					'compare' => 'NOT EXISTS',
				),
			);
		}

		/**
		 * Filters the WP_Query args used for retention purge.
		 *
		 * @param array<string, mixed> $query_args Query args.
		 * @param int                  $days       Retention days.
		 */
		$query_args = \apply_filters( 'dsm_contact_form_entries_retention_query_args', $query_args, $days );
		if ( ! \is_array( $query_args ) ) {
			return;
		}

		$deleted     = 0;
		$max_batches = 10;

		for ( $batch = 0; $batch < $max_batches; $batch++ ) {
			$ids = \get_posts( $query_args );
			if ( ! \is_array( $ids ) || array() === $ids ) {
				break;
			}

			foreach ( $ids as $entry_id ) {
				$entry_id = \absint( $entry_id );
				if ( $entry_id <= 0 ) {
					continue;
				}

				/**
				 * Whether to permanently delete this entry for retention.
				 *
				 * @param bool $delete   Default true.
				 * @param int  $entry_id Entry ID.
				 */
				$should_delete = (bool) \apply_filters( 'dsm_contact_form_entries_retention_should_delete', true, $entry_id );
				if ( ! $should_delete ) {
					continue;
				}

				\wp_delete_post( $entry_id, true );
				++$deleted;
			}

			if ( \count( $ids ) < 100 ) {
				break;
			}
		}

		/**
		 * Fires after a retention purge run.
		 *
		 * @param int $deleted Number of entries deleted.
		 * @param int $days    Retention days.
		 */
		\do_action( 'dsm_contact_form_entries_retention_purged', $deleted, $days );
	}
}
