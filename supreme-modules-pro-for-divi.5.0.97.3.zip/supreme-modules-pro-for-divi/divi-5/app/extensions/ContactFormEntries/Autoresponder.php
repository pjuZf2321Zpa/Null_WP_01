<?php
/**
 * Autoresponder emails for Contact Form Pro.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Extensions\ContactFormEntries;

use DiviSupreme\Extensions\ContactFormEntries as Entries;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Sends a confirmation email to the submitter after a successful (non-spam) store.
 */
class Autoresponder {

	/**
	 * Meta: last autoresponder attempt result (array).
	 */
	public const META_RESULT = '_dsm_cf_autoresponder';

	/**
	 * Constructor.
	 */
	public function __construct() {
		\add_action( 'dsm_contact_form_entry_stored', array( $this, 'maybe_send' ), 20, 3 );
	}

	/**
	 * Send autoresponder when enabled and entry is not spam.
	 *
	 * @param int                  $entry_id          Entry post ID.
	 * @param array<string, mixed> $fields            Processed fields.
	 * @param array<string, mixed> $contact_form_info Form info.
	 * @return void
	 */
	public function maybe_send( int $entry_id, array $fields, array $contact_form_info ): void {
		if ( 'on' !== Entries::get_setting( 'dsm_cf_autoresponder_enabled', 'off' ) ) {
			$this->store_result(
				$entry_id,
				array(
					'status' => 'skipped',
					'reason' => 'disabled',
				)
			);
			return;
		}

		$status = (string) \get_post_meta( $entry_id, Entries::META_STATUS, true );
		if ( 'spam' === $status ) {
			$this->store_result(
				$entry_id,
				array(
					'status' => 'skipped',
					'reason' => 'spam',
				)
			);
			return;
		}

		$to = (string) \get_post_meta( $entry_id, Entries::META_EMAIL, true );
		if ( ! \is_email( $to ) ) {
			$to = $this->resolve_submitter_email( $fields );
		}
		if ( ! \is_email( $to ) ) {
			$this->store_result(
				$entry_id,
				array(
					'status' => 'skipped',
					'reason' => 'no_email',
				)
			);
			return;
		}

		$name = (string) \get_post_meta( $entry_id, Entries::META_NAME, true );

		$subject = Entries::get_setting(
			'dsm_cf_autoresponder_subject',
			__( 'Thanks for contacting us', 'dsm-supreme-modules-pro-for-divi' )
		);
		$message = Entries::get_setting(
			'dsm_cf_autoresponder_message',
			self::default_message()
		);

		$replacements = array(
			'{{name}}'      => $name,
			'{{email}}'     => $to,
			'{{site_name}}' => \wp_specialchars_decode( \get_bloginfo( 'name' ), ENT_QUOTES ),
			'{{site_url}}'  => \home_url( '/' ),
			'{{fields}}'    => $this->format_fields_plain( $fields ),
		);

		/**
		 * Filters autoresponder placeholder replacements.
		 *
		 * @param array<string, string> $replacements      Placeholder map.
		 * @param int                   $entry_id          Entry ID.
		 * @param array<string, mixed>  $fields            Fields.
		 * @param array<string, mixed>  $contact_form_info Form info.
		 */
		$replacements = \apply_filters(
			'dsm_contact_form_autoresponder_replacements',
			$replacements,
			$entry_id,
			$fields,
			$contact_form_info
		);
		if ( ! \is_array( $replacements ) ) {
			$replacements = array();
		}

		$subject = \strtr( (string) $subject, $replacements );
		$message = \strtr( (string) $message, $replacements );

		$headers = array(
			'Content-Type: text/plain; charset=UTF-8',
		);

		/*
		 * SMTP-friendly From: only set when the site owner configured an explicit
		 * From email. Otherwise leave From unset so WP Mail SMTP / FluentSMTP /
		 * similar plugins control the authenticated sender (forcing admin_email
		 * often makes wp_mail return false while Divi's own notification still works).
		 */
		$from_name  = \trim( Entries::get_setting( 'dsm_cf_autoresponder_from_name', '' ) );
		$from_email = \trim( Entries::get_setting( 'dsm_cf_autoresponder_from_email', '' ) );

		if ( \is_email( $from_email ) ) {
			if ( '' === $from_name ) {
				$from_name = \wp_specialchars_decode( \get_bloginfo( 'name' ), ENT_QUOTES );
			}
			$headers[] = \sprintf(
				'From: %1$s <%2$s>',
				$this->encode_from_name( $from_name ),
				$from_email
			);
		} elseif ( '' !== $from_name ) {
			// Name alone is not enough for a From header; keep Reply-To below.
			$from_name = '';
		}

		$reply_to = (string) \get_option( 'admin_email' );
		if ( \is_email( $reply_to ) ) {
			$headers[] = \sprintf( 'Reply-To: %s', $reply_to );
		}

		/**
		 * Filters autoresponder headers.
		 *
		 * @param array<int, string>   $headers            Headers.
		 * @param int                  $entry_id           Entry ID.
		 * @param string               $to                 Recipient.
		 * @param array<string, mixed> $fields             Fields.
		 * @param array<string, mixed> $contact_form_info  Form info.
		 */
		$headers = \apply_filters(
			'dsm_contact_form_autoresponder_headers',
			$headers,
			$entry_id,
			$to,
			$fields,
			$contact_form_info
		);
		if ( ! \is_array( $headers ) ) {
			$headers = array();
		}

		/**
		 * Filters whether to send the autoresponder.
		 *
		 * @param bool                 $send              Default true.
		 * @param int                  $entry_id          Entry ID.
		 * @param string               $to                Recipient.
		 * @param array<string, mixed> $fields            Fields.
		 * @param array<string, mixed> $contact_form_info Form info.
		 */
		$send = (bool) \apply_filters(
			'dsm_contact_form_autoresponder_should_send',
			true,
			$entry_id,
			$to,
			$fields,
			$contact_form_info
		);
		if ( ! $send ) {
			$this->store_result(
				$entry_id,
				array(
					'status' => 'skipped',
					'reason' => 'filtered',
					'to'     => $to,
				)
			);
			return;
		}

		$attachments = $this->resolve_mail_attachments( $entry_id );

		$sent = \wp_mail(
			$to,
			\sanitize_text_field( $subject ),
			$message,
			$headers,
			$attachments
		);

		$this->store_result(
			$entry_id,
			array(
				'status' => $sent ? 'sent' : 'failed',
				'reason' => $sent ? '' : 'wp_mail_false',
				'to'     => $to,
			)
		);

		/**
		 * Fires after an autoresponder send attempt.
		 *
		 * @param bool                 $sent               Whether wp_mail reported success.
		 * @param int                  $entry_id           Entry ID.
		 * @param string               $to                 Recipient.
		 * @param array<string, mixed> $fields             Fields.
		 * @param array<string, mixed> $contact_form_info  Form info.
		 */
		\do_action( 'dsm_contact_form_autoresponder_sent', $sent, $entry_id, $to, $fields, $contact_form_info );
	}

	/**
	 * Default autoresponder body.
	 *
	 * @return string
	 */
	public static function default_message(): string {
		return \implode(
			"\n",
			array(
				__( 'Hi {{name}},', 'dsm-supreme-modules-pro-for-divi' ),
				'',
				__( 'Thanks for contacting {{site_name}}. We received your message and will get back to you soon.', 'dsm-supreme-modules-pro-for-divi' ),
				'',
				__( 'Your submission:', 'dsm-supreme-modules-pro-for-divi' ),
				'{{fields}}',
				'',
				'{{site_url}}',
			)
		);
	}

	/**
	 * Human label for a stored autoresponder result.
	 *
	 * @param array<string, mixed> $result Stored result.
	 * @return string
	 */
	public static function format_result_label( array $result ): string {
		$status = isset( $result['status'] ) ? (string) $result['status'] : '';
		$reason = isset( $result['reason'] ) ? (string) $result['reason'] : '';
		$to     = isset( $result['to'] ) ? (string) $result['to'] : '';

		switch ( $status ) {
			case 'sent':
				return '' !== $to
					? \sprintf(
						/* translators: %s: recipient email */
						__( 'Sent to %s', 'dsm-supreme-modules-pro-for-divi' ),
						$to
					)
					: __( 'Sent', 'dsm-supreme-modules-pro-for-divi' );
			case 'failed':
				return __( 'Failed (wp_mail returned false — check SMTP logs)', 'dsm-supreme-modules-pro-for-divi' );
			case 'skipped':
				switch ( $reason ) {
					case 'disabled':
						return __( 'Skipped (autoresponder off)', 'dsm-supreme-modules-pro-for-divi' );
					case 'spam':
						return __( 'Skipped (spam entry)', 'dsm-supreme-modules-pro-for-divi' );
					case 'no_email':
						return __( 'Skipped (no valid submitter email)', 'dsm-supreme-modules-pro-for-divi' );
					case 'filtered':
						return __( 'Skipped (filtered)', 'dsm-supreme-modules-pro-for-divi' );
					default:
						return __( 'Skipped', 'dsm-supreme-modules-pro-for-divi' );
				}
			default:
				return __( 'Unknown', 'dsm-supreme-modules-pro-for-divi' );
		}
	}

	/**
	 * Persist send/skip result on the entry.
	 *
	 * @param int                  $entry_id Entry ID.
	 * @param array<string, mixed> $result   Result payload.
	 * @return void
	 */
	private function store_result( int $entry_id, array $result ): void {
		$result['time'] = \time();
		\update_post_meta( $entry_id, self::META_RESULT, $result );
	}

	/**
	 * Local filesystem paths for wp_mail attachments (never public URLs).
	 *
	 * Runs after ContactFormFields::attach_file_fields (priority 14) so
	 * `_dsm_cf_attachments` is available when autoresponder sends (priority 20).
	 *
	 * @param int $entry_id Entry post ID.
	 * @return array<int, string>
	 */
	private function resolve_mail_attachments( int $entry_id ): array {
		if ( 'on' !== Entries::get_setting( 'dsm_cf_autoresponder_attach_files', 'off' ) ) {
			return array();
		}

		$ids = \get_post_meta( $entry_id, FileUpload::META_ATTACHMENTS, true );
		if ( ! \is_array( $ids ) || array() === $ids ) {
			return array();
		}

		$paths = array();
		foreach ( $ids as $attachment_id ) {
			$attachment_id = \absint( $attachment_id );
			if ( $attachment_id <= 0 ) {
				continue;
			}

			$post = \get_post( $attachment_id );
			if ( ! $post || 'attachment' !== $post->post_type ) {
				continue;
			}

			// Prefer files parented to this entry; allow unparented legacy temps if meta lists them.
			$parent = (int) $post->post_parent;
			if ( $parent > 0 && $parent !== $entry_id ) {
				continue;
			}

			$path = \get_attached_file( $attachment_id );
			if ( ! \is_string( $path ) || '' === $path || ! \is_readable( $path ) ) {
				continue;
			}

			$paths[] = $path;
		}

		/**
		 * Filters local paths attached to the autoresponder email.
		 *
		 * @param array<int, string> $paths    Absolute local file paths.
		 * @param int                $entry_id Entry ID.
		 */
		$paths = \apply_filters( 'dsm_contact_form_autoresponder_attachments', $paths, $entry_id );

		return \is_array( $paths ) ? \array_values( \array_filter( $paths, 'is_string' ) ) : array();
	}

	/**
	 * Find a submitter email from Divi processed fields.
	 *
	 * @param array<string, mixed> $fields Fields.
	 * @return string
	 */
	private function resolve_submitter_email( array $fields ): string {
		if ( isset( $fields['email'] ) && \is_array( $fields['email'] ) ) {
			$candidate = $this->stringify_scalar( $fields['email']['value'] ?? '' );
			if ( \is_email( $candidate ) ) {
				return $candidate;
			}
		}

		foreach ( $fields as $field ) {
			if ( ! \is_array( $field ) ) {
				continue;
			}
			$type = isset( $field['type'] ) ? (string) $field['type'] : '';
			if ( 'email' !== $type ) {
				continue;
			}
			$candidate = $this->stringify_scalar( $field['value'] ?? '' );
			if ( \is_email( $candidate ) ) {
				return $candidate;
			}
		}

		// Last resort: first field value that looks like an email.
		foreach ( $fields as $field ) {
			if ( ! \is_array( $field ) ) {
				continue;
			}
			$candidate = $this->stringify_scalar( $field['value'] ?? '' );
			if ( \is_email( $candidate ) ) {
				return $candidate;
			}
		}

		return '';
	}

	/**
	 * Format fields as plain text for email body.
	 *
	 * @param array<string, mixed> $fields Fields.
	 * @return string
	 */
	private function format_fields_plain( array $fields ): string {
		$lines = array();
		foreach ( $fields as $field ) {
			if ( ! \is_array( $field ) ) {
				continue;
			}
			$label = isset( $field['label'] ) ? (string) $field['label'] : '';
			$type  = isset( $field['type'] ) ? \sanitize_key( (string) $field['type'] ) : '';
			$value = $this->stringify_scalar( $field['value'] ?? '' );
			if ( 'signature' === $type && '' !== $value ) {
				$value = \__( 'Signed', 'dsm-supreme-modules-pro-for-divi' );
			}
			if ( '' === $label && '' === $value ) {
				continue;
			}
			$lines[] = $label . ': ' . $value;
		}

		return \implode( "\n", $lines );
	}

	/**
	 * Normalize a field value to a string.
	 *
	 * @param mixed $value Raw value.
	 * @return string
	 */
	private function stringify_scalar( $value ): string {
		if ( \is_array( $value ) ) {
			return \implode( ', ', \array_map( 'strval', $value ) );
		}
		if ( \is_scalar( $value ) ) {
			return (string) $value;
		}

		return '';
	}

	/**
	 * Strip CR/LF from From display name.
	 *
	 * @param string $name From name.
	 * @return string
	 */
	private function encode_from_name( string $name ): string {
		$name = \str_replace( array( "\r", "\n" ), '', $name );
		return \sanitize_text_field( $name );
	}
}
