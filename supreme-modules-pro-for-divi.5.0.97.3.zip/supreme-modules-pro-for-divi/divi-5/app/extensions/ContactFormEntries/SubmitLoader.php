<?php
/**
 * AJAX submit loading indicator for native Divi Contact Forms.
 *
 * Divi only fades the form to 0.2 opacity during jQuery .load() — no spinner.
 * This injects data attributes + enqueues a small FE script for curated loaders.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Extensions\ContactFormEntries;

use DiviSupreme\Extensions\ContactFormEntries as Entries;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Injects submit-loader config on Contact Form blocks and enqueues FE assets.
 */
class SubmitLoader {

	/**
	 * Marker class / data attribute root.
	 */
	public const ROOT_ATTR = 'data-dsm-cf-loader';

	/**
	 * Whether layout CSS was printed.
	 *
	 * @var bool
	 */
	private static $style_printed = false;

	/**
	 * Constructor.
	 */
	public function __construct() {
		\add_filter( 'render_block', array( $this, 'inject_attrs' ), 28, 2 );
	}

	/**
	 * Whether site-wide loader default is on.
	 *
	 * @return bool
	 */
	public static function is_site_default_enabled(): bool {
		return 'on' === Entries::get_setting( 'dsm_cf_loader_enabled', 'off' );
	}

	/**
	 * Site default style preset.
	 *
	 * @return string
	 */
	public static function get_site_default_style(): string {
		return self::normalize_style(
			\sanitize_key( Entries::get_setting( 'dsm_cf_loader_style', 'spinner' ) )
		);
	}

	/**
	 * Site default color.
	 *
	 * @return string
	 */
	public static function get_site_default_color(): string {
		$color = \trim( Entries::get_setting( 'dsm_cf_loader_color', '#2ea3f2' ) );
		if ( '' === $color ) {
			return '#2ea3f2';
		}

		return $color;
	}

	/**
	 * Site default size.
	 *
	 * @return string
	 */
	public static function get_site_default_size(): string {
		return self::normalize_size(
			\sanitize_key( Entries::get_setting( 'dsm_cf_loader_size', 'md' ) )
		);
	}

	/**
	 * Site default placement.
	 *
	 * @return string
	 */
	public static function get_site_default_placement(): string {
		return self::normalize_placement(
			\sanitize_key( Entries::get_setting( 'dsm_cf_loader_placement', 'button' ) )
		);
	}

	/**
	 * Localized fallback busy button label.
	 *
	 * @return string
	 */
	public static function get_default_busy_button_text(): string {
		return \__( 'Submitting…', 'dsm-supreme-modules-pro-for-divi' );
	}

	/**
	 * Site default button replace text.
	 *
	 * @return string
	 */
	public static function get_site_default_button_text(): string {
		$text = \trim( Entries::get_setting( 'dsm_cf_loader_button_text', '' ) );
		if ( '' === $text ) {
			return self::get_default_busy_button_text();
		}

		return $text;
	}

	/**
	 * Normalize loader style slug.
	 *
	 * @param string $style Raw style.
	 * @return string
	 */
	public static function normalize_style( string $style ): string {
		$allowed = array( 'spinner', 'dots', 'pulse', 'button' );

		return \in_array( $style, $allowed, true ) ? $style : 'spinner';
	}

	/**
	 * Normalize loader size slug.
	 *
	 * @param string $size Raw size.
	 * @return string
	 */
	public static function normalize_size( string $size ): string {
		$allowed = array( 'sm', 'md', 'lg' );

		return \in_array( $size, $allowed, true ) ? $size : 'md';
	}

	/**
	 * Normalize loader placement slug.
	 *
	 * @param string $placement Raw placement.
	 * @return string
	 */
	public static function normalize_placement( string $placement ): string {
		$allowed = array( 'button', 'overlay' );

		return \in_array( $placement, $allowed, true ) ? $placement : 'button';
	}

	/**
	 * VB localize payload.
	 *
	 * @return array<string, mixed>
	 */
	public static function get_vb_config(): array {
		return array(
			'enabledByDefault' => self::is_site_default_enabled(),
			'style'            => self::get_site_default_style(),
			'color'            => self::get_site_default_color(),
			'size'             => self::get_site_default_size(),
			'placement'        => self::get_site_default_placement(),
			'buttonText'       => self::get_site_default_button_text(),
		);
	}

	/**
	 * Whether loader is enabled for a block.
	 *
	 * @param array<string, mixed> $block Parsed block.
	 * @return bool
	 */
	public static function is_enabled_for_block( array $block ): bool {
		$mode = Entries::get_block_mode_attr( $block, 'dsm_cf_loader' );
		if ( 'off' === $mode ) {
			return false;
		}
		if ( 'on' === $mode ) {
			return true;
		}

		return self::is_site_default_enabled();
	}

	/**
	 * Read a string attr from a Contact Form block.
	 *
	 * @param array<string, mixed> $block         Parsed block.
	 * @param string               $key           Attr name.
	 * @param string               $default_value Default.
	 * @return string
	 */
	public static function get_block_string_attr( array $block, string $key, string $default_value = '' ): string {
		$attrs = isset( $block['attrs'] ) && \is_array( $block['attrs'] ) ? $block['attrs'] : array();
		if ( ! isset( $attrs[ $key ]['innerContent']['desktop']['value'] ) ) {
			return $default_value;
		}

		$value = $attrs[ $key ]['innerContent']['desktop']['value'];
		if ( \is_string( $value ) ) {
			return $value;
		}
		// Some Divi text controls store `{ text: '…' }`.
		if ( \is_array( $value ) && isset( $value['text'] ) && \is_scalar( $value['text'] ) ) {
			return (string) $value['text'];
		}

		return $default_value;
	}

	/**
	 * Resolve effective config for a block.
	 *
	 * Style: string,
	 * color: string,
	 * size: string,
	 * placement: string,
	 * button_text: string
	 * }
	 *
	 * @param array<string, mixed> $block Parsed block.
	 * @return array{
	 */
	public static function resolve_config( array $block ): array {
		$style = \sanitize_key( self::get_block_string_attr( $block, 'dsm_cf_loader_style', '' ) );
		if ( '' === $style || 'inherit' === $style ) {
			$style = self::get_site_default_style();
		}
		$style = self::normalize_style( $style );

		$color = \trim( self::get_block_string_attr( $block, 'dsm_cf_loader_color', '' ) );
		if ( '' === $color || 'inherit' === \sanitize_key( $color ) ) {
			$color = self::get_site_default_color();
		}

		$size = \sanitize_key( self::get_block_string_attr( $block, 'dsm_cf_loader_size', '' ) );
		if ( '' === $size || 'inherit' === $size ) {
			$size = self::get_site_default_size();
		}
		$size = self::normalize_size( $size );

		$placement = \sanitize_key( self::get_block_string_attr( $block, 'dsm_cf_loader_placement', '' ) );
		if ( '' === $placement || 'inherit' === $placement ) {
			$placement = self::get_site_default_placement();
		}
		$placement = self::normalize_placement( $placement );

		$button_text = \trim( self::get_block_string_attr( $block, 'dsm_cf_loader_button_text', '' ) );
		if ( '' === $button_text ) {
			$button_text = self::get_site_default_button_text();
		}

		return array(
			'style'       => $style,
			'color'       => $color,
			'size'        => $size,
			'placement'   => $placement,
			'button_text' => $button_text,
		);
	}

	/**
	 * Inject data attributes onto the contact form container.
	 *
	 * @param string               $block_content HTML.
	 * @param array<string, mixed> $block         Block.
	 * @return string
	 */
	public function inject_attrs( string $block_content, array $block ): string {
		$block_name = isset( $block['blockName'] ) ? (string) $block['blockName'] : '';
		if ( 'divi/contact-form' !== $block_name || '' === $block_content ) {
			return $block_content;
		}

		if ( ! self::is_enabled_for_block( $block ) ) {
			return $block_content;
		}

		if ( false !== \strpos( $block_content, self::ROOT_ATTR . '=' ) ) {
			return $block_content;
		}

		$config = self::resolve_config( $block );
		self::print_layout_style();
		$this->enqueue_frontend();

		$attr = \sprintf(
			' %1$s="1" data-dsm-cf-loader-style="%2$s" data-dsm-cf-loader-color="%3$s" data-dsm-cf-loader-size="%4$s" data-dsm-cf-loader-placement="%5$s" data-dsm-cf-loader-button-text="%6$s"',
			self::ROOT_ATTR,
			\esc_attr( $config['style'] ),
			\esc_attr( $config['color'] ),
			\esc_attr( $config['size'] ),
			\esc_attr( $config['placement'] ),
			\esc_attr( $config['button_text'] )
		);

		// Prefer the outer container, then form.
		$updated = \preg_replace(
			'/(<(?:div|form)\b[^>]*\b(?:et_pb_contact_form_container|et_pb_contact_form)\b[^>]*)(>)/i',
			'$1' . $attr . '$2',
			$block_content,
			1
		);

		if ( \is_string( $updated ) && $updated !== $block_content ) {
			return $updated;
		}

		return $block_content;
	}

	/**
	 * Enqueue FE loader script after attrs are injected.
	 *
	 * @return void
	 */
	private function enqueue_frontend(): void {
		if ( \is_admin() || ! \defined( 'DSM_DIR_URL' ) || ! \defined( 'DSM_DIR_PATH' ) ) {
			return;
		}

		$handle = 'dsm-cf-submit-loader';
		if ( \wp_script_is( $handle, 'enqueued' ) ) {
			return;
		}

		$src  = \DSM_DIR_URL . 'public/contact-form-submit-loader-frontend.js';
		$path = \DSM_DIR_PATH . 'divi-5/public/contact-form-submit-loader-frontend.js';
		$ver  = \is_readable( $path ) ? (string) \filemtime( $path ) : '1.0.0';

		\wp_enqueue_script( $handle, $src, array(), $ver, true );
		\wp_localize_script(
			$handle,
			'dsmCfSubmitLoader',
			array(
				'i18n' => array(
					'submitting' => self::get_default_busy_button_text(),
				),
			)
		);
	}

	/**
	 * Layout CSS once.
	 *
	 * @return void
	 */
	private static function print_layout_style(): void {
		if ( self::$style_printed ) {
			return;
		}
		self::$style_printed = true;

		$css = self::get_loader_css();

		$version = \defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';
		\wp_register_style( 'dsm-cf-submit-loader-layout', false, array(), $version );
		\wp_enqueue_style( 'dsm-cf-submit-loader-layout' );
		\wp_add_inline_style( 'dsm-cf-submit-loader-layout', $css );
	}

	/**
	 * Shared loader CSS (FE + VB canvas).
	 *
	 * @return string
	 */
	public static function get_loader_css(): string {
		return ''
			. '.et_pb_contact_form_container.dsm-cf-loader-busy,'
			. 'form.et_pb_contact_form.dsm-cf-loader-busy,'
			. '.et_pb_contact_form_container[data-dsm-cf-loader="1"].dsm-cf-loader-busy,'
			. 'form.et_pb_contact_form[data-dsm-cf-loader="1"].dsm-cf-loader-busy{'
			. 'position:relative;'
			. '}'
			. '.dsm-cf-loader-overlay{'
			. 'position:absolute;inset:0;z-index:20;display:flex;align-items:center;justify-content:center;'
			. 'background:rgba(255,255,255,.55);pointer-events:all;box-sizing:border-box;'
			. '}'
			. '.et_pb_contact_submit.dsm-cf-loader-busy-btn{'
			. 'pointer-events:none;cursor:wait;'
			. '}'
			// In-button spinner + busy label (replaces floating sibling spinner).
			. 'button.et_pb_contact_submit.dsm-cf-loader-busy-btn.dsm-cf-loader-has-busy-text{'
			. 'display:inline-flex!important;align-items:center;justify-content:center;gap:.5em;'
			. 'font-size:1rem!important;line-height:normal!important;'
			. '}'
			. 'button.et_pb_contact_submit.dsm-cf-loader-busy-btn.dsm-cf-loader-has-busy-text:after,'
			. 'button.et_pb_contact_submit.dsm-cf-loader-busy-btn.dsm-cf-loader-has-busy-text:before{'
			. 'content:none!important;display:none!important;'
			. '}'
			. '.dsm-cf-loader-btn-indicator{'
			. 'flex:0 0 auto;margin:0;'
			. '}'
			. '.dsm-cf-loader-btn-label{'
			. 'flex:0 1 auto;'
			. '}'
			. '.dsm-cf-loader-spinner,'
			. '.dsm-cf-loader-pulse{'
			. 'display:inline-block;border-radius:50%;box-sizing:border-box;'
			. 'border:2px solid currentColor;border-right-color:transparent;'
			. 'animation:dsm-cf-spin .7s linear infinite;'
			. 'color:var(--dsm-cf-loader-color,#2ea3f2);'
			. '}'
			. '.dsm-cf-loader-pulse{'
			. 'border:2px solid var(--dsm-cf-loader-color,#2ea3f2);border-right-color:var(--dsm-cf-loader-color,#2ea3f2);'
			. 'animation:dsm-cf-pulse .9s ease-in-out infinite;'
			. 'opacity:.85;'
			. '}'
			. '.dsm-cf-loader-dots{'
			. 'display:inline-flex;align-items:center;gap:.28em;'
			. 'color:var(--dsm-cf-loader-color,#2ea3f2);'
			. '}'
			. '.dsm-cf-loader-dots>span{'
			. 'width:.45em;height:.45em;border-radius:50%;background:currentColor;'
			. 'animation:dsm-cf-dots 1s ease-in-out infinite;'
			. '}'
			. '.dsm-cf-loader-dots>span:nth-child(2){animation-delay:.15s;}'
			. '.dsm-cf-loader-dots>span:nth-child(3){animation-delay:.3s;}'
			. '.dsm-cf-loader--sm .dsm-cf-loader-spinner,'
			. '.dsm-cf-loader--sm .dsm-cf-loader-pulse{width:14px;height:14px;}'
			. '.dsm-cf-loader--md .dsm-cf-loader-spinner,'
			. '.dsm-cf-loader--md .dsm-cf-loader-pulse{width:18px;height:18px;}'
			. '.dsm-cf-loader--lg .dsm-cf-loader-spinner,'
			. '.dsm-cf-loader--lg .dsm-cf-loader-pulse{width:24px;height:24px;}'
			. '.dsm-cf-loader--sm .dsm-cf-loader-dots{font-size:10px;}'
			. '.dsm-cf-loader--md .dsm-cf-loader-dots{font-size:12px;}'
			. '.dsm-cf-loader--lg .dsm-cf-loader-dots{font-size:14px;}'
			. '@keyframes dsm-cf-spin{to{transform:rotate(360deg);}}'
			. '@keyframes dsm-cf-pulse{0%,100%{transform:scale(.85);opacity:.55;}50%{transform:scale(1);opacity:1;}}'
			. '@keyframes dsm-cf-dots{0%,80%,100%{opacity:.25;transform:translateY(0);}40%{opacity:1;transform:translateY(-2px);}}';
	}
}
