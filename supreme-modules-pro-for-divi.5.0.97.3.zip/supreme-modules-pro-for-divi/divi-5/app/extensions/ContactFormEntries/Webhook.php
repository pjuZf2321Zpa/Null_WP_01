<?php
/**
 * Outbound webhooks for Contact Form Pro.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Extensions\ContactFormEntries;

use DiviSupreme\Extensions\ContactFormEntries as Entries;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Delivers a JSON payload to a configured URL after an entry is stored.
 */
class Webhook {

	/**
	 * Async delivery cron hook.
	 */
	public const DELIVER_HOOK = 'dsm_cf_entries_webhook_deliver';

	/**
	 * Constructor.
	 */
	public function __construct() {
		\add_action( 'dsm_contact_form_entry_stored', array( $this, 'maybe_queue' ), 30, 3 );
		\add_action( self::DELIVER_HOOK, array( $this, 'deliver' ), 10, 1 );
	}

	/**
	 * Queue async delivery when webhooks are enabled.
	 *
	 * @param int                  $entry_id          Entry post ID.
	 * @param array<string, mixed> $fields            Processed fields.
	 * @param array<string, mixed> $contact_form_info Form info.
	 * @return void
	 */
	public function maybe_queue( int $entry_id, array $fields, array $contact_form_info ): void {
		unset( $fields, $contact_form_info );

		if ( 'on' !== Entries::get_setting( 'dsm_cf_webhook_enabled', 'off' ) ) {
			return;
		}

		$url = Entries::sanitize_webhook_url( Entries::get_setting( 'dsm_cf_webhook_url', '' ) );
		if ( '' === $url ) {
			return;
		}

		$status = (string) \get_post_meta( $entry_id, Entries::META_STATUS, true );
		if ( 'spam' === $status && 'on' !== Entries::get_setting( 'dsm_cf_webhook_include_spam', 'off' ) ) {
			return;
		}

		/**
		 * Whether to queue a webhook for this entry.
		 *
		 * @param bool $queue    Default true when enabled + URL set.
		 * @param int  $entry_id Entry ID.
		 */
		$queue = (bool) \apply_filters( 'dsm_contact_form_entry_webhook_should_queue', true, $entry_id );
		if ( ! $queue ) {
			return;
		}

		if ( ! \wp_next_scheduled( self::DELIVER_HOOK, array( $entry_id ) ) ) {
			\wp_schedule_single_event( \time() + 1, self::DELIVER_HOOK, array( $entry_id ) );
		}

		// Nudge cron on hosts without a real cron runner.
		if ( \function_exists( 'spawn_cron' ) ) {
			\spawn_cron();
		}
	}

	/**
	 * POST JSON payload to the webhook URL.
	 *
	 * @param int $entry_id Entry post ID.
	 * @return void
	 */
	public function deliver( int $entry_id ): void {
		$entry_id = \absint( $entry_id );
		if ( $entry_id <= 0 ) {
			return;
		}

		$post = \get_post( $entry_id );
		if ( ! $post instanceof \WP_Post || Entries::POST_TYPE !== $post->post_type ) {
			return;
		}

		if ( 'on' !== Entries::get_setting( 'dsm_cf_webhook_enabled', 'off' ) ) {
			return;
		}

		$url = Entries::sanitize_webhook_url( Entries::get_setting( 'dsm_cf_webhook_url', '' ) );
		if ( '' === $url ) {
			return;
		}

		$fields = \get_post_meta( $entry_id, Entries::META_FIELDS, true );
		if ( ! \is_array( $fields ) ) {
			$fields = array();
		}

		$payload = array(
			'event'              => 'contact_form.entry.stored',
			'entry_id'           => $entry_id,
			'status'             => (string) \get_post_meta( $entry_id, Entries::META_STATUS, true ),
			'starred'            => '1' === (string) \get_post_meta( $entry_id, Entries::META_STARRED, true ),
			'name'               => (string) \get_post_meta( $entry_id, Entries::META_NAME, true ),
			'email'              => (string) \get_post_meta( $entry_id, Entries::META_EMAIL, true ),
			'form_id'            => (string) \get_post_meta( $entry_id, Entries::META_FORM_ID, true ),
			'form_unique_id'     => (string) \get_post_meta( $entry_id, Entries::META_FORM_UNIQUE_ID, true ),
			'source_post_id'     => \absint( \get_post_meta( $entry_id, Entries::META_SOURCE_POST_ID, true ) ),
			'submitted_at'       => (string) $post->post_date_gmt,
			'submitted_at_local' => (string) $post->post_date,
			'site_url'           => \home_url( '/' ),
			'fields'             => $fields,
		);

		/**
		 * Filters the webhook JSON payload (array before encoding).
		 *
		 * @param array<string, mixed> $payload  Payload.
		 * @param int                  $entry_id Entry ID.
		 */
		$payload = \apply_filters( 'dsm_contact_form_entry_webhook_payload', $payload, $entry_id );
		if ( ! \is_array( $payload ) ) {
			return;
		}

		$body = \wp_json_encode( $payload );
		if ( ! \is_string( $body ) || '' === $body ) {
			return;
		}

		$secret  = (string) Entries::get_setting( 'dsm_cf_webhook_secret', '' );
		$headers = array(
			'Content-Type' => 'application/json; charset=utf-8',
			'User-Agent'   => 'DiviSupreme-ContactFormEntries/' . ( \defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0' ),
		);

		if ( '' !== $secret ) {
			$headers['X-DSM-Signature'] = 'sha256=' . \hash_hmac( 'sha256', $body, $secret );
		}

		$args = array(
			'timeout'             => 15,
			'redirection'         => 2,
			'blocking'            => true,
			'sslverify'           => true,
			'limit_response_size' => 64 * 1024,
			'headers'             => $headers,
			'body'                => $body,
		);

		/**
		 * Filters wp_safe_remote_post args for the webhook request.
		 *
		 * @param array<string, mixed> $args     Request args.
		 * @param string               $url      Webhook URL.
		 * @param int                  $entry_id Entry ID.
		 */
		$args = \apply_filters( 'dsm_contact_form_entry_webhook_request_args', $args, $url, $entry_id );
		if ( ! \is_array( $args ) ) {
			return;
		}

		// wp_safe_remote_post rejects private/reserved IPs (SSRF mitigation).
		$response = \wp_safe_remote_post( $url, $args );

		/**
		 * Fires after a webhook delivery attempt.
		 *
		 * @param array|\WP_Error      $response Response.
		 * @param int                  $entry_id Entry ID.
		 * @param string               $url      URL.
		 * @param array<string, mixed> $payload  Payload.
		 */
		\do_action( 'dsm_contact_form_entry_webhook_delivered', $response, $entry_id, $url, $payload );
	}
}
