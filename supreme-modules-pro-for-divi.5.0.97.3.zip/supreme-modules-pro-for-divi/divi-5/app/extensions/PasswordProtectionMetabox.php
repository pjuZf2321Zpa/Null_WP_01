<?php
/**
 * Per-page Password Protection metabox (Phase 2).
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Extensions;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Classic/block editor metabox for protecting individual posts and pages.
 */
class PasswordProtectionMetabox {

	/**
	 * Nonce action.
	 */
	private const NONCE_ACTION = 'dsm_password_protection_page_meta';

	/**
	 * Nonce field name.
	 */
	private const NONCE_FIELD = 'dsm_pp_page_meta_nonce';

	/**
	 * Whether the Password Protection extension is enabled.
	 *
	 * @return bool
	 */
	private static function is_extension_enabled(): bool {
		return function_exists( 'dsm_is_password_protection_extension_enabled' )
			&& dsm_is_password_protection_extension_enabled();
	}

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public static function register(): void {
		if ( ! self::is_extension_enabled() ) {
			return;
		}

		add_action( 'add_meta_boxes', array( self::class, 'add_meta_box' ) );
		add_action( 'save_post', array( self::class, 'save_meta_box' ), 10, 2 );
		add_action( 'admin_enqueue_scripts', array( self::class, 'enqueue_assets' ) );
	}

	/**
	 * Post types that support per-page Protection.
	 *
	 * @return string[]
	 */
	public static function get_supported_post_types(): array {
		$types = array( 'page', 'post' );

		/**
		 * Filters post types that show the Protection metabox.
		 *
		 * @param string[] $types Post type slugs.
		 */
		$filtered = apply_filters( 'dsm_password_protection_page_post_types', $types );

		return is_array( $filtered ) ? array_values( array_filter( array_map( 'strval', $filtered ) ) ) : $types;
	}

	/**
	 * Register the metabox.
	 *
	 * @return void
	 */
	public static function add_meta_box(): void {
		foreach ( self::get_supported_post_types() as $post_type ) {
			add_meta_box(
				'dsm_password_protection_page',
				__( 'Divi Supreme Password Protection', 'dsm-supreme-modules-pro-for-divi' ),
				array( self::class, 'render_meta_box' ),
				$post_type,
				'side',
				'default'
			);
		}
	}

	/**
	 * Enqueue metabox script on supported edit screens.
	 *
	 * @param string $hook_suffix Current admin page.
	 * @return void
	 */
	public static function enqueue_assets( string $hook_suffix ): void {
		if ( ! in_array( $hook_suffix, array( 'post.php', 'post-new.php' ), true ) ) {
			return;
		}

		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen || ! in_array( (string) $screen->post_type, self::get_supported_post_types(), true ) ) {
			return;
		}

		$script_rel = 'divi-5/assets/js/password-protection-metabox.js';
		$path       = defined( 'DSM_DIR_PATH' ) ? DSM_DIR_PATH . $script_rel : '';
		$url        = defined( 'DSM_DIR_URL' ) ? DSM_DIR_URL . 'assets/js/password-protection-metabox.js' : '';

		if ( '' === $path || ! is_readable( $path ) || '' === $url ) {
			return;
		}

		wp_enqueue_script(
			'dsm-password-protection-metabox',
			$url,
			array(),
			(string) filemtime( $path ),
			true
		);
	}

	/**
	 * Render metabox markup.
	 *
	 * @param \WP_Post $post Post.
	 * @return void
	 */
	public static function render_meta_box( $post ): void {
		if ( ! $post instanceof \WP_Post ) {
			return;
		}

		wp_nonce_field( self::NONCE_ACTION, self::NONCE_FIELD );

		$post_id      = (int) $post->ID;
		$enabled      = PasswordProtection::is_page_protection_enabled( $post_id ) ? 'on' : 'off';
		$entries      = PasswordProtection::entries_for_dashboard_ui(
			(string) get_post_meta( $post_id, PasswordProtection::META_PAGE_ENTRIES, true )
		);
		$bypass_mode  = PasswordProtection::get_page_bypass_mode( $post_id );
		$bypass_roles = PasswordProtection::get_page_bypass_roles( $post_id );
		$role_options = PasswordProtection::get_bypass_role_options_for_settings();

		$settings_url = admin_url( 'admin.php?page=divi_supreme_settings&tab=dsm_settings_protection' );
		?>
		<p class="description" style="margin-top:0;">
			<?php
			echo esc_html__(
				'Lock only this page. Sitewide Password Protection (if enabled) still runs first. Unlocking the site does not unlock this page.',
				'dsm-supreme-modules-pro-for-divi'
			);
			?>
		</p>
		<p>
			<label for="dsm_pp_page_enabled">
				<input
					type="checkbox"
					name="dsm_pp_page_enabled"
					id="dsm_pp_page_enabled"
					value="on"
					<?php checked( $enabled, 'on' ); ?>
				/>
				<?php echo esc_html__( 'Protect this page', 'dsm-supreme-modules-pro-for-divi' ); ?>
			</label>
		</p>
		<p class="description">
			<a href="<?php echo esc_url( $settings_url ); ?>">
				<?php echo esc_html__( 'Sitewide Password Protection settings', 'dsm-supreme-modules-pro-for-divi' ); ?>
			</a>
		</p>

		<p>
			<label for="dsm_pp_page_bypass_mode">
				<strong><?php echo esc_html__( 'Bypass for logged-in users', 'dsm-supreme-modules-pro-for-divi' ); ?></strong>
			</label>
		</p>
		<p class="description" style="margin-top:0;">
			<?php
			echo esc_html__(
				'Optionally let logged-in users view this page without a password. Administrators always bypass. Independent from sitewide bypass settings.',
				'dsm-supreme-modules-pro-for-divi'
			);
			?>
		</p>
		<p>
			<select name="dsm_pp_page_bypass_mode" id="dsm_pp_page_bypass_mode" class="widefat">
				<option value="none" <?php selected( $bypass_mode, 'none' ); ?>>
					<?php echo esc_html__( 'None', 'dsm-supreme-modules-pro-for-divi' ); ?>
				</option>
				<option value="logged_in" <?php selected( $bypass_mode, 'logged_in' ); ?>>
					<?php echo esc_html__( 'Any logged-in user', 'dsm-supreme-modules-pro-for-divi' ); ?>
				</option>
				<option value="roles" <?php selected( $bypass_mode, 'roles' ); ?>>
					<?php echo esc_html__( 'Selected roles', 'dsm-supreme-modules-pro-for-divi' ); ?>
				</option>
			</select>
		</p>

		<div
			id="dsm-pp-page-bypass-roles"
			class="dsm-pp-page-bypass-roles"
			<?php
			if ( 'roles' !== $bypass_mode ) {
				echo 'hidden';
			}
			?>
		>
			<p style="margin-bottom:6px;">
				<strong><?php echo esc_html__( 'Bypass roles', 'dsm-supreme-modules-pro-for-divi' ); ?></strong>
			</p>
			<p class="description" style="margin-top:0;">
				<?php
				echo esc_html__(
					'Users with any selected role can view this page without a password. Administrator is not listed because admins always bypass.',
					'dsm-supreme-modules-pro-for-divi'
				);
				?>
			</p>
			<?php if ( array() === $role_options ) : ?>
				<p class="description"><?php echo esc_html__( 'No selectable roles are available.', 'dsm-supreme-modules-pro-for-divi' ); ?></p>
			<?php else : ?>
				<ul style="margin:0;padding:0;list-style:none;">
					<?php foreach ( $role_options as $slug => $label ) : ?>
						<li style="margin:0 0 4px;">
							<label>
								<input
									type="checkbox"
									name="dsm_pp_page_bypass_roles[]"
									value="<?php echo esc_attr( (string) $slug ); ?>"
									<?php checked( in_array( (string) $slug, $bypass_roles, true ) ); ?>
								/>
								<?php echo esc_html( (string) $label ); ?>
							</label>
						</li>
					<?php endforeach; ?>
				</ul>
			<?php endif; ?>
		</div>

		<div
			id="dsm-pp-page-entries"
			class="dsm-pp-page-entries"
			data-next-index="<?php echo esc_attr( (string) count( $entries ) ); ?>"
		>
			<p><strong><?php echo esc_html__( 'Page passwords', 'dsm-supreme-modules-pro-for-divi' ); ?></strong></p>
			<p class="description" style="margin-top:0;">
				<?php echo esc_html__( 'Leave password blank on an existing row to keep it. New rows need a password.', 'dsm-supreme-modules-pro-for-divi' ); ?>
			</p>
			<div class="dsm-pp-page-entries__list">
				<?php
				if ( array() === $entries ) {
					self::render_entry_row( 0, array(), true );
				} else {
					foreach ( $entries as $index => $entry ) {
						self::render_entry_row( (int) $index, is_array( $entry ) ? $entry : array(), false );
					}
				}
				?>
			</div>
			<p>
				<button type="button" class="button dsm-pp-page-entries__add">
					<?php echo esc_html__( '+ Add password', 'dsm-supreme-modules-pro-for-divi' ); ?>
				</button>
			</p>
		</div>
		<template id="dsm-pp-page-entry-template">
			<?php self::render_entry_row( '__INDEX__', array(), true ); ?>
		</template>
		<?php
	}

	/**
	 * One password row markup.
	 *
	 * @param int|string           $index   Row index (or placeholder).
	 * @param array<string, mixed> $entry   Entry data.
	 * @param bool                 $is_new  Whether this is an empty new row.
	 * @return void
	 */
	private static function render_entry_row( $index, array $entry, bool $is_new ): void {
		$id           = isset( $entry['id'] ) ? (string) $entry['id'] : '';
		$label        = isset( $entry['label'] ) ? (string) $entry['label'] : '';
		$enabled      = ( isset( $entry['enabled'] ) && 'on' === $entry['enabled'] ) || $is_new ? 'on' : 'off';
		$has_password = ! empty( $entry['hasPassword'] );
		$index_attr   = (string) $index;
		?>
		<div class="dsm-pp-page-entry" style="border:1px solid #dcdcde;border-radius:4px;padding:8px;margin:0 0 8px;background:#fff;">
			<input type="hidden" name="dsm_pp_page_entries[<?php echo esc_attr( $index_attr ); ?>][id]" value="<?php echo esc_attr( $id ); ?>" />
			<p style="margin:0 0 6px;">
				<label>
					<span class="screen-reader-text"><?php echo esc_html__( 'Label', 'dsm-supreme-modules-pro-for-divi' ); ?></span>
					<input
						type="text"
						class="widefat"
						name="dsm_pp_page_entries[<?php echo esc_attr( $index_attr ); ?>][label]"
						value="<?php echo esc_attr( $label ); ?>"
						placeholder="<?php echo esc_attr__( 'Label', 'dsm-supreme-modules-pro-for-divi' ); ?>"
						autocomplete="off"
					/>
				</label>
			</p>
			<p style="margin:0 0 6px;">
				<label>
					<span class="screen-reader-text"><?php echo esc_html__( 'Password', 'dsm-supreme-modules-pro-for-divi' ); ?></span>
					<input
						type="password"
						class="widefat"
						name="dsm_pp_page_entries[<?php echo esc_attr( $index_attr ); ?>][password]"
						value=""
						placeholder="<?php echo esc_attr( $has_password ? __( 'Leave blank to keep current', 'dsm-supreme-modules-pro-for-divi' ) : __( 'Password', 'dsm-supreme-modules-pro-for-divi' ) ); ?>"
						autocomplete="new-password"
					/>
				</label>
			</p>
			<p style="margin:0;display:flex;align-items:center;justify-content:space-between;gap:8px;">
				<label>
					<input
						type="checkbox"
						name="dsm_pp_page_entries[<?php echo esc_attr( $index_attr ); ?>][enabled]"
						value="on"
						<?php checked( $enabled, 'on' ); ?>
					/>
					<?php echo esc_html__( 'Enabled', 'dsm-supreme-modules-pro-for-divi' ); ?>
				</label>
				<button type="button" class="button-link-delete dsm-pp-page-entries__remove">
					<?php echo esc_html__( 'Remove', 'dsm-supreme-modules-pro-for-divi' ); ?>
				</button>
			</p>
		</div>
		<?php
	}

	/**
	 * Persist metabox fields.
	 *
	 * @param int      $post_id Post ID.
	 * @param \WP_Post $post    Post object.
	 * @return void
	 */
	public static function save_meta_box( int $post_id, $post ): void {
		if ( ! $post instanceof \WP_Post ) {
			return;
		}

		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		if ( wp_is_post_revision( $post_id ) ) {
			return;
		}

		if ( ! in_array( $post->post_type, self::get_supported_post_types(), true ) ) {
			return;
		}

		if ( ! isset( $_POST[ self::NONCE_FIELD ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Checked below.
			return;
		}

		$nonce = sanitize_text_field( wp_unslash( (string) $_POST[ self::NONCE_FIELD ] ) );
		if ( ! wp_verify_nonce( $nonce, self::NONCE_ACTION ) ) {
			return;
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		$enabled = isset( $_POST['dsm_pp_page_enabled'] ) && 'on' === $_POST['dsm_pp_page_enabled'] ? 'on' : 'off';
		update_post_meta( $post_id, PasswordProtection::META_PAGE_ENABLED, $enabled );

		$bypass_mode = isset( $_POST['dsm_pp_page_bypass_mode'] )
			? sanitize_key( wp_unslash( (string) $_POST['dsm_pp_page_bypass_mode'] ) )
			: 'none';

		$raw_roles = isset( $_POST['dsm_pp_page_bypass_roles'] ) && is_array( $_POST['dsm_pp_page_bypass_roles'] )
			? map_deep( wp_unslash( $_POST['dsm_pp_page_bypass_roles'] ), 'sanitize_key' )
			: array();

		PasswordProtection::save_page_bypass_from_request( $post_id, $bypass_mode, $raw_roles );

		$raw_entries = isset( $_POST['dsm_pp_page_entries'] ) && is_array( $_POST['dsm_pp_page_entries'] )
			? map_deep( wp_unslash( $_POST['dsm_pp_page_entries'] ), 'sanitize_text_field' )
			: array();

		PasswordProtection::save_page_entries_from_request( $post_id, $raw_entries );
	}
}
