<?php
/**
 * Popup Extension
 *
 * @package DiviSupreme
 */

namespace DiviSupreme\Extensions;

require_once dirname( __DIR__ ) . '/Includes/dsm-css-preview-scope.php';
require_once dirname( __DIR__ ) . '/Includes/dsm-preview-script-scope.php';

$dsm_breakpoint_relative   = 'includes/builder-5/server/Framework/Breakpoint/Breakpoint.php';
$dsm_breakpoint_candidates = array();

if ( \function_exists( 'get_parent_theme_file_path' ) ) {
	$dsm_breakpoint_candidates[] = get_parent_theme_file_path( $dsm_breakpoint_relative );
}

// Divi-as-active-theme (non-child): template dir is Divi core.
$dsm_breakpoint_candidates[] = trailingslashit( get_template_directory() ) . $dsm_breakpoint_relative;

// Child theme edge cases: locate Divi by stylesheet slug when parent path fails.
if ( \function_exists( 'wp_get_theme' ) ) {
	$dsm_divi = wp_get_theme( 'Divi' );
	if ( $dsm_divi instanceof \WP_Theme && $dsm_divi->exists() ) {
		$dsm_breakpoint_candidates[] = trailingslashit( $dsm_divi->get_stylesheet_directory() ) . $dsm_breakpoint_relative;
	}
}

foreach ( array_unique( array_filter( $dsm_breakpoint_candidates ) ) as $breakpoint_file_candidate ) {
	if ( \is_string( $breakpoint_file_candidate )
		&& '' !== $breakpoint_file_candidate
		&& \is_readable( $breakpoint_file_candidate )
	) {
		require_once $breakpoint_file_candidate;
		break;
	}
}

use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use ET\Builder\Packages\StyleLibrary\Declarations\Border;

use DiviSupreme\Extensions\IconLibraries\IconGlyphRenderer;
use DiviSupreme\Extensions\IconLibraries\IconProcessFontIconBridge;
use DiviSupreme\Includes\DiviLibraryLayoutRenderer;
use DiviSupreme\Includes\DsmCssPreviewScope;
use DiviSupreme\Includes\DsmPreviewScriptScope;

use DiviSupreme\Includes\DsmFrontendDynamicAssets;

use ET\Builder\FrontEnd\Assets\DetectFeature;
use ET\Builder\FrontEnd\Assets\DynamicAssetsUtils;
use ET\Builder\FrontEnd\Assets\StaticCSS;
use ET\Builder\FrontEnd\Assets\StaticCSSElement;
use ET\Builder\FrontEnd\Module\ScriptData;
use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\FrontEnd\Page;
use ET\Builder\Packages\GlobalData\GlobalData;

/**
 * Popup Extension
 *
 * @package DiviSupreme
 */
class Popup {


	/**
	 * Fully-qualified Divi class name (string avoids autoload when the file is absent).
	 */
	private const DSM_ET_BREAKPOINT_CLASS = 'ET\\Builder\\Framework\\Breakpoint\\Breakpoint';

	/**
	 * Default settings
	 *
	 * @var array
	 */
	private $default_settings = array();

	/**
	 * To prevent infinite loop.
	 *
	 * @var boolean
	 */
	private static $is_rendering_popup = false;

	/**
	 * Cached index of enabled library popups (all scopes).
	 *
	 * @var string
	 */
	private const GLOBAL_POPUPS_CACHE_TRANSIENT = 'dsm_global_popups_index';

	/**
	 * Generated schema
	 *
	 * @var array
	 */
	private $generated_schema = array();

	/**
	 * Constructor
	 *
	 * @return void
	 */
	public function __construct() {

		// Setup schema.
		$this->default_settings = array(
			'is_enabled'                     => false,
			'hide_close_button'              => 'off',
			'entrance_animation'             => 'fadeIn',
			'entrance_animation_duration'    => '0.4s',
			'entrance_animation_delay'       => '0s',
			'popup_viewport_delay'           => '1s',
			'popup_type'                     => 'module',
			'exit_animation'                 => 'fadeOut',
			'exit_animation_duration'        => '0.25s',
			'exit_animation_delay'           => '0s',
			'popup_target'                   => 'select',
			'popup_target_by_class'          => '',
			'popup_target_by_id'             => '',
			'close_popup_triggers'           => array( 'overlay_click' ),
			'popup_appear'                   => 'always',
			'popup_appear_after_x_days'      => '2',
			'popup_appear_after_x_hours'     => '1',
			'open_popup_trigger'             => 'click',
			// Seconds to wait after trigger before opening Magnific (all popup types).
			'popup_open_delay'               => '0s',
			'popup_open_frequency'           => 'unlimited',
			'popup_max_opens_per_session'    => 0,
			'auto_close_popup'               => false,
			'auto_close_popup_delay'         => 20,
			'popup_class'                    => '',
			'popup_max_width'                => $this->breakpoint_value( '600px' ),
			'popup_padding'                  => $this->breakpoint_value(
				array(
					'top'            => '0px',
					'right'          => '0px',
					'bottom'         => '0px',
					'left'           => '0px',
					'syncHorizontal' => 'off',
					'syncVertical'   => 'off',
				)
			),
			'popup_max_height'               => $this->breakpoint_value( '' ),
			'popup_close_button_position'    => $this->breakpoint_value( 'top_right' ),
			'popup_close_button_top'         => $this->breakpoint_value( '0px' ),
			'popup_close_button_left'        => $this->breakpoint_value( '0px' ),
			'popup_main_axis'                => $this->breakpoint_value( 'center' ),
			'popup_cross_axis'               => $this->breakpoint_value( 'center' ),
			// D4 `dsm_modules_popup_position_type`: absolute locks background scroll; fixed pins popup to viewport while page scrolls.
			'popup_position_type'            => 'absolute',
			// D4 `dsm_modules_overlay` — when off, Magnific backdrop is removed and page stays interactive.
			'popup_show_overlay'             => 'on',
			'background_color'               => $this->breakpoint_value( '#000000' ),
			'popup_overlay_color'            => $this->breakpoint_value( 'rgba(11, 11, 11, 0.8)' ),
			'popup_close_button_color'       => $this->breakpoint_value( '#ffffff' ),
			'popup_wrapper_background_color' => $this->breakpoint_value( '#ffffff' ),
			'popup_close_bg_button_color'    => $this->breakpoint_value( '#000000' ),
			'popup_close_button_size'        => $this->breakpoint_value( '28px' ),
			'popup_close_button_icon'        => $this->breakpoint_value(
				array(
					'unicode' => 'M',
					'type'    => 'divi',
					'weight'  => '400',
				)
			),
			'popup_box_shadow'               => $this->breakpoint_value(
				array(
					'style'      => 'none',
					'position'   => 'outer',
					'horizontal' => '0px',
					'vertical'   => '0px',
					'blur'       => '0px',
					'spread'     => '0px',
					'color'      => '#000000',
				)
			),
			'popup_border'                   => $this->breakpoint_value(
				array(
					'style'  => 'solid',
					'color'  => '#000000',
					'width'  => '0px',
					'radius' => array(
						'topLeft'     => '0px',
						'topRight'    => '0px',
						'bottomLeft'  => '0px',
						'bottomRight' => '0px',
					),
				)
			),
			'wc_action'                      => 'select',
		);

		add_action( 'init', array( $this, 'register' ) );
		add_action( 'divi_visual_builder_rest_save_post', array( $this, 'save_popup_settings' ) );
		add_action( 'save_post', array( $this, 'invalidate_global_popups_vb_cache_on_layout_change' ), 10, 3 );
		add_action( 'deleted_post', array( $this, 'invalidate_global_popups_vb_cache_on_delete' ), 10, 1 );
		add_action( 'updated_post_meta', array( $this, 'invalidate_global_popups_vb_cache_on_popup_meta' ), 10, 4 );
		add_filter( 'render_block', array( $this, 'render_module_popup' ), 10, 3 );
		add_action( 'wp_footer', array( $this, 'render_woo_popup' ), 10, 0 );

		/**
		 * The following hook ensures that when the popup layout is saved in the divi libary
		 * it clears all the cache of posts/pages using this particular popup in the content.
		 *
		 * Note: This hook was introduced in divi public beta 4.
		 */
		add_filter(
			'et_core_page_resource_post_id_before_clear',
			function ( $post_id, $post, $update ) {
				unset( $update );

				$popup_settings = $this->get_popup_settings( $post->ID );
				$enabled        = $popup_settings['is_enabled'];

				if ( 'et_pb_layout' === $post->post_type && $enabled && 'all' !== $post_id ) {
					return 'all';
				}

				return $post_id;
			},
			5,
			3
		);
	}

	/**
	 * Normalize `popup_open_frequency` for markup JSON (`data-dsm-popup-options`).
	 *
	 * @param mixed $raw Meta value from layout settings.
	 * @return string One of unlimited|session|day|week|month.
	 */
	private function sanitize_popup_open_frequency_for_options( $raw ): string {
		$allowed   = array( 'unlimited', 'session', 'day', 'week', 'month' );
		$candidate = strtolower( trim( is_string( $raw ) ? $raw : ( is_scalar( $raw ) ? (string) $raw : '' ) ) );
		return in_array( $candidate, $allowed, true ) ? $candidate : 'unlimited';
	}

	/**
	 * Merge `close_popup_triggers` (array) with legacy single `close_popup_trigger` string into a canonical ordered list.
	 *
	 * @param array<string, mixed> $settings Saved popup settings.
	 * @return list<string>
	 */
	private function normalize_close_popup_triggers( array $settings ): array {
		$canonical   = array( 'overlay_click', 'esc_key', 'close_button', 'css_class' );
		$allowed_map = array_flip( $canonical );

		$picked = array();

		if ( isset( $settings['close_popup_triggers'] ) && is_array( $settings['close_popup_triggers'] ) ) {
			foreach ( $settings['close_popup_triggers'] as $slug_raw ) {
				$slug = sanitize_key( is_string( $slug_raw ) ? $slug_raw : (string) $slug_raw );
				if ( isset( $allowed_map[ $slug ] ) && ! in_array( $slug, $picked, true ) ) {
					$picked[] = $slug;
				}
			}
		}

		$legacy_raw = isset( $settings['close_popup_trigger'] ) ? $settings['close_popup_trigger'] : null;
		if ( is_string( $legacy_raw ) && '' !== trim( $legacy_raw ) ) {
			$legacy = sanitize_key( $legacy_raw );
			if ( isset( $allowed_map[ $legacy ] ) && ! in_array( $legacy, $picked, true ) ) {
				$picked[] = $legacy;
			}
		}

		if ( empty( $picked ) ) {
			return array( 'overlay_click' );
		}

		$ordered = array();
		foreach ( $canonical as $slug ) {
			if ( in_array( $slug, $picked, true ) ) {
				$ordered[] = $slug;
			}
		}

		return $ordered;
	}

	/**
	 * Normalize legacy / partial `dsm-popup-settings` meta for D5.
	 *
	 * - `enterance_animation` typo → `entrance_animation`.
	 * - Empty or missing `popup_open_delay` → `'0s'` (Divi 4 had no library meta key for this; partial JSON
	 * saves and `wp_parse_args` both leave an explicit empty string unchanged without this step).
	 * - Empty or missing `popup_open_frequency` inferred from legacy `popup_max_opens_per_session`
	 * (>0 ⇒ `session`, otherwise `unlimited`) so older layouts keep behaviour before the dropdown existed.
	 *
	 * D4 module option `dsm_modules_popup_timed_delay` (onload/scroll/exit) maps to D5 `popup_viewport_delay`
	 * when merging from converted modules — see `ConversionAttrs::maybe_merge_d4_popup_into_library_popup_settings_meta()`.
	 *
	 * @param array<string, mixed> $settings Popup settings (by reference ok; returns new array).
	 * @return array<string, mixed>
	 */
	private function migrate_legacy_popup_setting_keys( array $settings ): array {
		if ( isset( $settings['enterance_animation'] ) && '' !== $settings['enterance_animation'] && null !== $settings['enterance_animation'] ) {
			$legacy = $settings['enterance_animation'];
			if ( ! isset( $settings['entrance_animation'] ) || '' === $settings['entrance_animation'] || null === $settings['entrance_animation'] ) {
				$settings['entrance_animation'] = $legacy;
			}
		}
		unset( $settings['enterance_animation'] );

		$open_delay = isset( $settings['popup_open_delay'] ) ? $settings['popup_open_delay'] : null;
		if ( null === $open_delay || '' === trim( (string) $open_delay ) ) {
			$settings['popup_open_delay'] = '0s';
		}

		if (
			! isset( $settings['popup_open_frequency'] )
			|| '' === $settings['popup_open_frequency']
			|| null === $settings['popup_open_frequency']
		) {
			$max_sess                         = isset( $settings['popup_max_opens_per_session'] )
				? max( 0, absint( (int) $settings['popup_max_opens_per_session'] ) )
				: 0;
			$settings['popup_open_frequency'] = $max_sess > 0 ? 'session' : 'unlimited';
		}

		if (
			( ! isset( $settings['close_popup_triggers'] ) || ! is_array( $settings['close_popup_triggers'] ) )
			&& isset( $settings['close_popup_trigger'] )
			&& is_string( $settings['close_popup_trigger'] )
			&& '' !== trim( $settings['close_popup_trigger'] )
		) {
			$settings['close_popup_triggers'] = array( sanitize_key( $settings['close_popup_trigger'] ) );
		}

		if ( isset( $settings['popup_position_type'] ) ) {
			$settings['popup_position_type'] = $this->sanitize_popup_position_type( $settings['popup_position_type'] );
		}

		if ( ! isset( $settings['popup_show_overlay'] ) || '' === trim( (string) $settings['popup_show_overlay'] ) ) {
			$settings['popup_show_overlay'] = 'on';
		} else {
			$settings['popup_show_overlay'] = 'off' === $settings['popup_show_overlay'] ? 'off' : 'on';
		}

		return $settings;
	}

	/**
	 * Whether any enabled page-load / exit-intent / targeted popup should run on the frontend.
	 *
	 * Used by Dynamic Assets to enqueue ETmodules / FA for popup close icons.
	 *
	 * @return bool
	 */
	public function has_enabled_global_popup_for_frontend_request(): bool {
		foreach ( $this->get_popup_layout_index() as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}

			$popup_type = isset( $row['popup_type'] ) ? (string) $row['popup_type'] : 'module';

			if ( in_array( $popup_type, array( 'page_load', 'exit_intent', 'targetted' ), true ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Whether any enabled WooCommerce popup layout should SSR footer markup on this HTTP request.
	 *
	 * @return bool
	 */
	public function has_woocommerce_footer_popup_for_current_request() {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return false;
		}

		if ( ! $this->popup_index_has_type( 'woocommerce' ) ) {
			return false;
		}

		foreach ( $this->get_global_popups( 'woocommerce' ) as $wc_popup ) {
			if ( $this->woocommerce_footer_popup_matches_request( (int) $wc_popup['id'] ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Whether footer SSR for a single Woo popup is appropriate for this request (page + configured action).
	 *
	 * @param int $popup_id et_pb_layout (library popup) post ID.
	 * @return bool
	 */
	private function woocommerce_footer_popup_matches_request( $popup_id ) {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return false;
		}

		$popup_id = (int) $popup_id;
		if ( $popup_id <= 0 ) {
			return false;
		}

		$settings   = $this->get_popup_settings( $popup_id );
		$popup_type = isset( $settings['popup_type'] ) ? $settings['popup_type'] : '';

		if ( 'woocommerce' !== $popup_type ) {
			return false;
		}

		$raw_action = isset( $settings['wc_action'] ) ? $settings['wc_action'] : 'select';
		$action     = sanitize_key( is_string( $raw_action ) ? $raw_action : (string) $raw_action );

		// Modal reset historically used `add_to_cart`; JS expects `added_to_cart`.
		if ( 'add_to_cart' === $action ) {
			$action = 'added_to_cart';
		}

		if ( '' === $action || 'select' === $action ) {
			return false;
		}

		$is_cart     = function_exists( 'is_cart' ) && is_cart();
		$is_checkout = function_exists( 'is_checkout' ) && is_checkout();
		$is_wc       = function_exists( 'is_woocommerce' ) && is_woocommerce();
		$cart_flow   = $is_cart || $is_checkout;

		switch ( $action ) {
			case 'added_to_cart':
				/*
				 * Product archives/checkout are covered by is_woocommerce() / cart/checkout.
				 * Divi Woo "Add To Cart" (and similar) can live on generic pages — merged content detects those modules.
				 */
				return $is_wc || $cart_flow || $this->page_merged_content_implies_add_to_cart_triggers();
			case 'removed_from_cart':
			case 'cart_updated':
			case 'coupon_applied':
			case 'coupon_removed':
				return $cart_flow;
			default:
				/**
				 * Opt-in footer markup for custom `wc_action` values saved in popup meta.
				 *
				 * @param bool   $render   Whether to SSR this popup’s markup in wp_footer.
				 * @param string $action   Sanitized action slug.
				 * @param int    $popup_id Layout ID.
				 */
				return (bool) apply_filters( 'dsm_popup_should_render_woocommerce_footer_markup', false, $action, $popup_id );
		}
	}

	/**
	 * Whether merged post + Divi page content hints that Add to Cart UX exists here (outside classic WC templates).
	 *
	 * @return bool
	 */
	private function page_merged_content_implies_add_to_cart_triggers() {
		if ( ! class_exists( DsmFrontendDynamicAssets::class ) ) {
			return false;
		}

		/**
		 * Block names that indicate add-to-cart page content.
		 *
		 * @var list<string> $markers
		 */
		$markers = array(
			'divi/woocommerce-product-add-to-cart',
			'divi/woocommerce-products',
			'divi/woocommerce-related-products',
			'divi/woocommerce-cross-sells',
			'divi/woocommerce-product-upsell',
			'divi/woocommerce-cart-products',
			'woocommerce/handpicked-products',
			'woocommerce/featured-product',
			'woocommerce/product-collection',
			'woocommerce/product-search-results',
			'woocommerce/all-products',
		);

		/**
		 * Filtered add-to-cart content markers.
		 *
		 * @var list<string> $markers
		 */
		$markers = apply_filters( 'dsm_popup_add_to_cart_page_content_markers', $markers );

		foreach ( $markers as $needle ) {
			if ( ! is_string( $needle ) || '' === $needle ) {
				continue;
			}
			if ( DsmFrontendDynamicAssets::merged_detection_content_contains( $needle ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Render popups configured for WooCommerce actions.
	 *
	 * @return void
	 */
	public function render_woo_popup() {
		if ( self::$is_rendering_popup ) {
			return;
		}

		if ( ! class_exists( 'WooCommerce' ) ) {
			return;
		}

		if ( wp_doing_ajax() ) {
			return;
		}

		if ( ! $this->popup_index_has_type( 'woocommerce' ) ) {
			return;
		}

		self::$is_rendering_popup = true;

		try {
			$woocommerce_popups = $this->get_global_popups( 'woocommerce' );

			foreach ( $woocommerce_popups as $wc_popup ) {
				$popup_id = (int) $wc_popup['id'];
				if ( ! $this->woocommerce_footer_popup_matches_request( $popup_id ) ) {
					continue;
				}
				echo $this->render_popup( $popup_id ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
		} finally {
			self::$is_rendering_popup = false;
		}
	}

	/**
	 * Divi Builder enabled breakpoints for popup schema/CSS, with safe fallback when ET Breakpoint is unavailable.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	private function get_popup_enabled_breakpoints() {
		static $cached = null;
		if ( null !== $cached ) {
			return $cached;
		}
		$class = self::DSM_ET_BREAKPOINT_CLASS;
		if (
			class_exists( $class )
			&& method_exists( $class, 'get_enabled_breakpoints' )
		) {
			$enabled = call_user_func( array( $class, 'get_enabled_breakpoints' ) );
			$cached  = (
				\is_array( $enabled )
				&& array() !== $enabled
			) ? $enabled : $this->get_popup_fallback_enabled_breakpoints();
			return $cached;
		}
		$cached = $this->get_popup_fallback_enabled_breakpoints();
		return $cached;
	}

	/**
	 * Default breakpoints (desktop/tablet/phone) when Divi's Framework\\Breakpoint API cannot load (e.g. non-Divi parent, stale tree).
	 *
	 * @return array<int, array<string, mixed>>
	 */
	private function get_popup_fallback_enabled_breakpoints() {
		return array(
			array(
				'order'  => 50,
				'enable' => true,
				'name'   => 'desktop',
			),
			array(
				'order'    => 30,
				'enable'   => true,
				'name'     => 'tablet',
				'maxWidth' => array(
					'value'   => '980px',
					'default' => 980,
				),
			),
			array(
				'order'    => 10,
				'enable'   => true,
				'name'     => 'phone',
				'maxWidth' => array(
					'value'   => '767px',
					'default' => 767,
				),
			),
		);
	}

	/**
	 * Max viewport width in pixels for max-width media queries wrapping popup shell CSS variables.
	 *
	 * Divi's saved breakpoint option often stores only `maxWidth.value` (e.g. `980px`) after
	 * {@see \ET\Builder\Framework\Breakpoint\Breakpoint::validate_item()}; the numeric `default` key is omitted.
	 * Relying only on `maxWidth.default` skipped all non-desktop popup CSS on many production sites.
	 *
	 * @param array<string, mixed> $breakpoint One entry from enabled breakpoints.
	 * @return int|null Pixel width, or null when this breakpoint should not emit a max-width media block.
	 */
	private function get_popup_breakpoint_media_max_px( array $breakpoint ): ?int {
		$name = isset( $breakpoint['name'] ) && is_string( $breakpoint['name'] ) ? $breakpoint['name'] : '';
		if ( '' === $name || 'desktop' === $name ) {
			return null;
		}
		if ( isset( $breakpoint['maxWidth']['default'] ) && is_numeric( $breakpoint['maxWidth']['default'] ) ) {
			return (int) $breakpoint['maxWidth']['default'];
		}
		if ( isset( $breakpoint['maxWidth']['value'] ) ) {
			$raw = $breakpoint['maxWidth']['value'];
			if ( is_numeric( $raw ) ) {
				$parsed = (int) $raw;
				return $parsed > 0 ? $parsed : null;
			}
			if ( is_string( $raw ) && '' !== trim( $raw ) ) {
				$parsed = (int) $raw;
				return $parsed > 0 ? $parsed : null;
			}
		}
		$fallback_by_name = array(
			'tablet'     => 980,
			'phone'      => 767,
			'phoneWide'  => 860,
			'tabletWide' => 1024,
		);
		if ( isset( $fallback_by_name[ $name ] ) ) {
			return $fallback_by_name[ $name ];
		}

		return null;
	}

	/**
	 * Get breakpoint value
	 *
	 * @param string $value Value to get breakpoint for.
	 * @return string Breakpoint value
	 */
	private function breakpoint_value( $value ) {
		// Desktop-only: smaller breakpoints inherit via cascade (matches Divi 5 responsive attrs).
		return array(
			'desktop' => $value,
		);
	}

	/**
	 * Schema defaults for responsive scalar design fields (desktop leaf).
	 *
	 * @return array<string, string>
	 */
	private function get_popup_responsive_scalar_schema_defaults() {
		return array(
			'popup_main_axis'                => 'center',
			'popup_cross_axis'               => 'center',
			'popup_overlay_color'            => 'rgba(11, 11, 11, 0.8)',
			'popup_max_width'                => '600px',
			'popup_max_height'               => '',
			'popup_wrapper_background_color' => '#ffffff',
			'popup_close_button_position'    => 'top_right',
			'popup_close_button_top'         => '0px',
			'popup_close_button_left'        => '0px',
			'popup_close_button_size'        => '28px',
			'popup_close_button_color'       => '#ffffff',
			'popup_close_bg_button_color'    => '#000000',
			'background_color'               => '#000000',
		);
	}

	/**
	 * Schema defaults for responsive object design fields (desktop leaf).
	 *
	 * @return array<string, array{default: array<string, mixed>, normalize: bool}>
	 */
	private function get_popup_responsive_object_schema_defaults() {
		return array(
			'popup_close_button_icon' => array(
				'default'   => array(
					'unicode' => 'M',
					'type'    => 'divi',
					'weight'  => '400',
				),
				'normalize' => false,
			),
			'popup_padding'           => array(
				'default'   => array(
					'top'            => '0px',
					'right'          => '0px',
					'bottom'         => '0px',
					'left'           => '0px',
					'syncHorizontal' => 'off',
					'syncVertical'   => 'off',
				),
				'normalize' => true,
			),
			'popup_border'            => array(
				'default'               => array(
					'style'  => 'solid',
					'color'  => '#000000',
					'width'  => '0px',
					'radius' => array(
						'topLeft'     => '0px',
						'topRight'    => '0px',
						'bottomLeft'  => '0px',
						'bottomRight' => '0px',
					),
				),
				'normalize'             => 'border',
				'ignore_schema_smaller' => true,
			),
			'popup_box_shadow'        => array(
				'default'   => array(
					'style'      => 'none',
					'position'   => 'outer',
					'horizontal' => '0px',
					'vertical'   => '0px',
					'blur'       => '0px',
					'spread'     => '0px',
					'color'      => '#000000',
				),
				'normalize' => false,
			),
		);
	}

	/**
	 * Normalize padding leaf (PHP flat or Spacing `{ value: { … } }`).
	 *
	 * @param mixed $leaf Breakpoint padding node.
	 * @return array<string, string>
	 */
	private function normalize_popup_padding_leaf( $leaf ) {
		$defaults = array(
			'top'            => '0px',
			'right'          => '0px',
			'bottom'         => '0px',
			'left'           => '0px',
			'syncVertical'   => 'off',
			'syncHorizontal' => 'off',
		);

		if ( ! is_array( $leaf ) ) {
			return $defaults;
		}

		$raw = ( isset( $leaf['value'] ) && is_array( $leaf['value'] ) ) ? $leaf['value'] : $leaf;

		return array(
			'top'            => ( isset( $raw['top'] ) && is_string( $raw['top'] ) && '' !== $raw['top'] ) ? $raw['top'] : $defaults['top'],
			'right'          => ( isset( $raw['right'] ) && is_string( $raw['right'] ) && '' !== $raw['right'] ) ? $raw['right'] : $defaults['right'],
			'bottom'         => ( isset( $raw['bottom'] ) && is_string( $raw['bottom'] ) && '' !== $raw['bottom'] ) ? $raw['bottom'] : $defaults['bottom'],
			'left'           => ( isset( $raw['left'] ) && is_string( $raw['left'] ) && '' !== $raw['left'] ) ? $raw['left'] : $defaults['left'],
			'syncVertical'   => ( isset( $raw['syncVertical'] ) && is_string( $raw['syncVertical'] ) ) ? $raw['syncVertical'] : $defaults['syncVertical'],
			'syncHorizontal' => ( isset( $raw['syncHorizontal'] ) && is_string( $raw['syncHorizontal'] ) ) ? $raw['syncHorizontal'] : $defaults['syncHorizontal'],
		);
	}

	/**
	 * Normalize popup border leaf (flat PHP default or nested `styles` from BorderGroup).
	 *
	 * @param mixed $leaf Breakpoint border node.
	 * @return array<string, mixed>
	 */
	private function normalize_popup_border_leaf( $leaf ) {
		$default_side   = array(
			'width' => '0px',
			'color' => '#000000',
			'style' => 'solid',
		);
		$default_radius = array(
			'topLeft'     => '0px',
			'topRight'    => '0px',
			'bottomLeft'  => '0px',
			'bottomRight' => '0px',
			'sync'        => 'off',
		);

		if ( ! is_array( $leaf ) ) {
			return array(
				'styles' => array( 'all' => $default_side ),
				'radius' => $default_radius,
			);
		}

		$raw_radius = ( isset( $leaf['radius'] ) && is_array( $leaf['radius'] ) ) ? $leaf['radius'] : array();
		$radius     = array(
			'topLeft'     => ( isset( $raw_radius['topLeft'] ) && is_string( $raw_radius['topLeft'] ) && '' !== $raw_radius['topLeft'] ) ? $raw_radius['topLeft'] : $default_radius['topLeft'],
			'topRight'    => ( isset( $raw_radius['topRight'] ) && is_string( $raw_radius['topRight'] ) && '' !== $raw_radius['topRight'] ) ? $raw_radius['topRight'] : $default_radius['topRight'],
			'bottomLeft'  => ( isset( $raw_radius['bottomLeft'] ) && is_string( $raw_radius['bottomLeft'] ) && '' !== $raw_radius['bottomLeft'] ) ? $raw_radius['bottomLeft'] : $default_radius['bottomLeft'],
			'bottomRight' => ( isset( $raw_radius['bottomRight'] ) && is_string( $raw_radius['bottomRight'] ) && '' !== $raw_radius['bottomRight'] ) ? $raw_radius['bottomRight'] : $default_radius['bottomRight'],
			'sync'        => ( isset( $raw_radius['sync'] ) && is_string( $raw_radius['sync'] ) ) ? $raw_radius['sync'] : $default_radius['sync'],
		);

		if ( isset( $leaf['styles'] ) && is_array( $leaf['styles'] ) ) {
			$styles = array();

			foreach ( $leaf['styles'] as $side => $side_raw ) {
				if ( ! is_array( $side_raw ) ) {
					continue;
				}

				$styles[ $side ] = array(
					'width' => ( isset( $side_raw['width'] ) && is_string( $side_raw['width'] ) && '' !== $side_raw['width'] ) ? $side_raw['width'] : $default_side['width'],
					'color' => ( isset( $side_raw['color'] ) && is_string( $side_raw['color'] ) && '' !== $side_raw['color'] ) ? $side_raw['color'] : $default_side['color'],
					'style' => ( isset( $side_raw['style'] ) && is_string( $side_raw['style'] ) && '' !== $side_raw['style'] ) ? $side_raw['style'] : $default_side['style'],
				);
			}

			if ( ! isset( $styles['all'] ) ) {
				$styles['all'] = array(
					'width' => ( isset( $leaf['width'] ) && is_string( $leaf['width'] ) && '' !== $leaf['width'] ) ? $leaf['width'] : $default_side['width'],
					'color' => ( isset( $leaf['color'] ) && is_string( $leaf['color'] ) && '' !== $leaf['color'] ) ? $leaf['color'] : $default_side['color'],
					'style' => ( isset( $leaf['style'] ) && is_string( $leaf['style'] ) && '' !== $leaf['style'] ) ? $leaf['style'] : $default_side['style'],
				);
			}

			return array(
				'styles' => $styles,
				'radius' => $radius,
			);
		}

		return array(
			'styles' => array(
				'all' => array(
					'width' => ( isset( $leaf['width'] ) && is_string( $leaf['width'] ) && '' !== $leaf['width'] ) ? $leaf['width'] : $default_side['width'],
					'color' => ( isset( $leaf['color'] ) && is_string( $leaf['color'] ) && '' !== $leaf['color'] ) ? $leaf['color'] : $default_side['color'],
					'style' => ( isset( $leaf['style'] ) && is_string( $leaf['style'] ) && '' !== $leaf['style'] ) ? $leaf['style'] : $default_side['style'],
				),
			),
			'radius' => $radius,
		);
	}

	/**
	 * Normalizer callback for one popup object schema entry.
	 *
	 * @param array<string, mixed> $config Object schema config entry.
	 * @return callable(mixed):mixed|null
	 */
	private function get_popup_object_normalize_fn( array $config ) {
		$normalize = $config['normalize'] ?? false;

		if ( true === $normalize || 'padding' === $normalize ) {
			return array( $this, 'normalize_popup_padding_leaf' );
		}

		if ( 'border' === $normalize ) {
			return array( $this, 'normalize_popup_border_leaf' );
		}

		return null;
	}

	/**
	 * Whether two popup object leaves are equal after normalization.
	 *
	 * @param mixed                      $a            Left leaf.
	 * @param mixed                      $b            Right leaf.
	 * @param callable(mixed):mixed|null $normalize_fn Optional normalizer.
	 * @return bool
	 */
	private function popup_objects_deep_equal( $a, $b, $normalize_fn = null ) {
		if ( is_callable( $normalize_fn ) ) {
			$a = call_user_func( $normalize_fn, $a );
			$b = call_user_func( $normalize_fn, $b );
		}

		return wp_json_encode( $a ) === wp_json_encode( $b );
	}

	/**
	 * Whether an object leaf still matches the schema default.
	 *
	 * @param mixed                      $leaf           Stored leaf.
	 * @param array<string, mixed>       $schema_default Schema default.
	 * @param callable(mixed):mixed|null $normalize_fn   Optional normalizer.
	 * @return bool
	 */
	private function popup_object_is_schema_default( $leaf, array $schema_default, $normalize_fn = null ) {
		if ( ! is_array( $leaf ) ) {
			return false;
		}

		return $this->popup_objects_deep_equal( $leaf, $schema_default, $normalize_fn );
	}

	/**
	 * Whether an object leaf is an explicit value rather than the schema default.
	 *
	 * @param mixed                      $leaf           Stored leaf.
	 * @param array<string, mixed>       $schema_default Schema default.
	 * @param callable(mixed):mixed|null $normalize_fn   Optional normalizer.
	 * @return bool
	 */
	private function popup_is_explicit_object_leaf( $leaf, array $schema_default, $normalize_fn = null ) {
		return is_array( $leaf ) && ! $this->popup_object_is_schema_default( $leaf, $schema_default, $normalize_fn );
	}

	/**
	 * Whether a smaller breakpoint still holds a legacy copy of desktop (not a distinct override).
	 *
	 * @param array<string, mixed>       $bucket        Breakpoint map.
	 * @param string                     $breakpoint    Breakpoint name.
	 * @param callable(mixed):mixed|null $normalize_fn  Optional normalizer.
	 * @return bool
	 */
	private function popup_object_is_echo_default_at_breakpoint( array $bucket, $breakpoint, $normalize_fn = null ) {
		if ( 'desktop' === $breakpoint || ! isset( $bucket[ $breakpoint ] ) || ! is_array( $bucket[ $breakpoint ] ) ) {
			return false;
		}

		$desktop = $bucket['desktop'] ?? null;
		if ( ! is_array( $desktop ) ) {
			return false;
		}

		return $this->popup_objects_deep_equal( $bucket[ $breakpoint ], $desktop, $normalize_fn );
	}

	/**
	 * Whether a breakpoint leaf is an explicit object value.
	 *
	 * @param mixed                      $leaf                   Stored leaf.
	 * @param string                     $ladder_key             Breakpoint name.
	 * @param array<string, mixed>       $schema_default         Schema default.
	 * @param callable(mixed):mixed|null $normalize_fn           Optional normalizer.
	 * @param bool                       $ignore_schema_smaller  Ignore schema copies on smaller breakpoints.
	 * @return bool
	 */
	private function popup_is_explicit_object_leaf_at_key( $leaf, $ladder_key, array $schema_default, $normalize_fn = null, $ignore_schema_smaller = false ) {
		if ( ! is_array( $leaf ) ) {
			return false;
		}

		if ( 'desktop' === $ladder_key ) {
			return ! $this->popup_object_is_schema_default( $leaf, $schema_default, $normalize_fn );
		}

		if ( $ignore_schema_smaller && $this->popup_object_is_schema_default( $leaf, $schema_default, $normalize_fn ) ) {
			return false;
		}

		return true;
	}

	/**
	 * Remove tablet/phone leaves that still hold seeded plugin defaults while desktop was customized.
	 *
	 * @param array<string, mixed> $settings Popup settings.
	 * @return array<string, mixed>
	 */
	private function strip_popup_responsive_echo_defaults( array $settings ) {
		$schemas = $this->get_popup_responsive_scalar_schema_defaults();
		$smaller = array( 'tabletWide', 'tablet', 'phoneWide', 'phone' );

		foreach ( $schemas as $key => $schema_default ) {
			if ( ! isset( $settings[ $key ] ) || ! is_array( $settings[ $key ] ) ) {
				continue;
			}

			$desktop = $settings[ $key ]['desktop'] ?? null;
			if ( ! is_string( $desktop ) || '' === trim( $desktop ) || $desktop === $schema_default ) {
				continue;
			}

			foreach ( $smaller as $bp ) {
				if ( ! array_key_exists( $bp, $settings[ $key ] ) ) {
					continue;
				}
				if ( $settings[ $key ][ $bp ] === $schema_default ) {
					unset( $settings[ $key ][ $bp ] );
				}
			}
		}

		$object_schemas = $this->get_popup_responsive_object_schema_defaults();

		foreach ( $object_schemas as $key => $config ) {
			if ( ! isset( $settings[ $key ] ) || ! is_array( $settings[ $key ] ) ) {
				continue;
			}

			$normalize_fn          = $this->get_popup_object_normalize_fn( $config );
			$schema_default        = $config['default'] ?? array();
			$ignore_schema_smaller = ! empty( $config['ignore_schema_smaller'] );
			$desktop               = $settings[ $key ]['desktop'] ?? null;
			$desktop_customized    = is_array( $desktop )
				&& ! $this->popup_object_is_schema_default( $desktop, $schema_default, $normalize_fn );

			foreach ( $smaller as $bp ) {
				if ( ! array_key_exists( $bp, $settings[ $key ] ) ) {
					continue;
				}
				if ( $this->popup_object_is_echo_default_at_breakpoint( $settings[ $key ], $bp, $normalize_fn ) ) {
					unset( $settings[ $key ][ $bp ] );
					continue;
				}
				if (
					$ignore_schema_smaller
					&& $desktop_customized
					&& $this->popup_object_is_schema_default( $settings[ $key ][ $bp ], $schema_default, $normalize_fn )
				) {
					unset( $settings[ $key ][ $bp ] );
				}
			}
		}

		return $settings;
	}

	/**
	 * Ordered breakpoint names (largest → smallest).
	 *
	 * @return string[]
	 */
	private function get_popup_breakpoint_ladder_names() {
		$names = array();

		foreach ( $this->get_popup_enabled_breakpoints() as $breakpoint ) {
			if ( isset( $breakpoint['name'] ) && is_string( $breakpoint['name'] ) ) {
				$names[] = $breakpoint['name'];
			}
		}

		return $names;
	}

	/**
	 * First explicit value walking the breakpoint ladder downward.
	 *
	 * @param array<string, mixed>  $bucket          Breakpoint map.
	 * @param string                $breakpoint_name Target breakpoint.
	 * @param callable(mixed): bool $is_explicit     Explicit-value test.
	 * @return mixed|null
	 */
	private function popup_cascade_flat_map_for_breakpoint( array $bucket, $breakpoint_name, callable $is_explicit ) {
		$ladder     = $this->get_popup_breakpoint_ladder_names();
		$target_idx = array_search( $breakpoint_name, $ladder, true );
		$start_idx  = false !== $target_idx ? (int) $target_idx : 0;

		for ( $i = $start_idx; $i >= 0; $i-- ) {
			$key = $ladder[ $i ];
			if ( ! array_key_exists( $key, $bucket ) ) {
				continue;
			}
			$leaf = $bucket[ $key ];
			if ( $is_explicit( $leaf, $key ) ) {
				return $leaf;
			}
		}

		return null;
	}

	/**
	 * Resolve a scalar popup setting for one breakpoint.
	 *
	 * @param array  $settings        Popup settings.
	 * @param string $key             Setting key.
	 * @param string $breakpoint_name Breakpoint name.
	 * @param string $default_token   Fallback token.
	 * @return string
	 */
	private function resolve_popup_scalar_for_breakpoint( array $settings, $key, $breakpoint_name, $default_token ) {
		if ( isset( $settings[ $key ] ) && is_string( $settings[ $key ] ) ) {
			$trimmed = trim( $settings[ $key ] );

			return '' !== $trimmed ? $trimmed : $default_token;
		}

		$bucket         = isset( $settings[ $key ] ) && is_array( $settings[ $key ] ) ? $settings[ $key ] : array();
		$schemas        = $this->get_popup_responsive_scalar_schema_defaults();
		$schema_default = $schemas[ $key ] ?? $default_token;

		if ( 'desktop' !== $breakpoint_name && isset( $bucket[ $breakpoint_name ] ) && $bucket[ $breakpoint_name ] === $schema_default ) {
			$desktop = $bucket['desktop'] ?? null;
			if ( is_string( $desktop ) && '' !== trim( $desktop ) && $desktop !== $schema_default ) {
				unset( $bucket[ $breakpoint_name ] );
			}
		}

		$cascaded = $this->popup_cascade_flat_map_for_breakpoint(
			$bucket,
			$breakpoint_name,
			function ( $leaf ) {
				return is_string( $leaf ) && '' !== trim( $leaf );
			}
		);

		if ( is_string( $cascaded ) && '' !== trim( $cascaded ) ) {
			return trim( $cascaded );
		}

		return $default_token;
	}

	/**
	 * Normalize a Modal Range field leaf (plain string or { value, unit }) to one CSS dimension string.
	 *
	 * VB Range controls often persist breakpoints as associative arrays while legacy saves used plain strings.
	 *
	 * @param mixed  $leaf     One breakpoint entry from popup settings (e.g. popup_max_width[ tablet ]).
	 * @param string $fallback Returned when absent or invalid (may be '').
	 * @return string
	 */
	private function normalize_popup_design_range_length( $leaf, $fallback = '' ) {
		if ( is_string( $leaf ) ) {
			$t = trim( $leaf );

			return '' !== $t ? $t : $fallback;
		}
		if ( is_array( $leaf ) && isset( $leaf['value'] ) ) {
			$v = $leaf['value'];
			$u = ( isset( $leaf['unit'] ) && is_string( $leaf['unit'] ) ) ? $leaf['unit'] : 'px';
			if ( is_numeric( $v ) || ( is_string( $v ) && '' !== trim( $v ) ) ) {
				return trim( (string) $v ) . $u;
			}
		}

		return $fallback;
	}

	/**
	 * Resolve a per-breakpoint length with desktop fallback and plugin default.
	 *
	 * @param array  $settings        Merged popup settings (dsm-popup-settings).
	 * @param string $key             e.g. popup_max_width.
	 * @param string $breakpoint_name Current breakpoint name (desktop, tablet, phone, …).
	 * @param string $default_token   Last-resort CSS token.
	 * @return string
	 */
	private function resolve_popup_length_for_breakpoint( array $settings, $key, $breakpoint_name, $default_token ) {
		if ( isset( $settings[ $key ] ) && is_string( $settings[ $key ] ) ) {
			return $this->normalize_popup_design_range_length( $settings[ $key ], $default_token );
		}
		$bucket = isset( $settings[ $key ] ) && is_array( $settings[ $key ] ) ? $settings[ $key ] : array();

		$cascaded     = $this->popup_cascade_flat_map_for_breakpoint(
			$bucket,
			$breakpoint_name,
			function ( $leaf ) {
				return '' !== $this->normalize_popup_design_range_length( $leaf, '' );
			}
		);
		$from_cascade = $this->normalize_popup_design_range_length( $cascaded, '' );
		if ( '' !== $from_cascade ) {
			return $from_cascade;
		}

		$defaults         = isset( $this->default_settings[ $key ] ) && is_array( $this->default_settings[ $key ] )
			? $this->default_settings[ $key ]
			: array();
		$default_cascaded = $this->popup_cascade_flat_map_for_breakpoint(
			$defaults,
			$breakpoint_name,
			function ( $leaf ) {
				return '' !== $this->normalize_popup_design_range_length( $leaf, '' );
			}
		);
		$from_defaults    = $this->normalize_popup_design_range_length( $default_cascaded, '' );

		return '' !== $from_defaults ? $from_defaults : $default_token;
	}

	/**
	 * Resolve a per-breakpoint object with desktop cascade and plugin default.
	 *
	 * @param array<string, mixed>       $settings               Popup settings.
	 * @param string                     $key                    Setting key.
	 * @param string                     $breakpoint_name        Breakpoint name.
	 * @param array<string, mixed>       $schema_default         Schema default.
	 * @param callable(mixed):mixed|null $normalize_fn           Optional normalizer.
	 * @param bool                       $ignore_schema_smaller  Ignore schema copies on smaller breakpoints.
	 * @return array<string, mixed>
	 */
	private function resolve_popup_object_for_breakpoint(
		array $settings,
		$key,
		$breakpoint_name,
		array $schema_default,
		$normalize_fn = null,
		$ignore_schema_smaller = false
	) {
		$bucket = isset( $settings[ $key ] ) && is_array( $settings[ $key ] ) ? $settings[ $key ] : array();

		if (
			'desktop' !== $breakpoint_name
			&& $this->popup_object_is_echo_default_at_breakpoint( $bucket, $breakpoint_name, $normalize_fn )
		) {
			unset( $bucket[ $breakpoint_name ] );
		}

		$cascaded = $this->popup_cascade_flat_map_for_breakpoint(
			$bucket,
			$breakpoint_name,
			function ( $leaf, $ladder_key ) use ( $schema_default, $normalize_fn, $ignore_schema_smaller ) {
				return $this->popup_is_explicit_object_leaf_at_key(
					$leaf,
					$ladder_key,
					$schema_default,
					$normalize_fn,
					$ignore_schema_smaller
				);
			}
		);

		if ( is_array( $cascaded ) ) {
			return $cascaded;
		}

		return $schema_default;
	}

	/**
	 * Resolved padding sides for one breakpoint (cascade + normalize).
	 *
	 * @param array<string, mixed> $settings         Popup settings.
	 * @param string               $breakpoint_name Breakpoint name.
	 * @return array<string, string>
	 */
	private function resolve_popup_padding_sides_for_breakpoint( array $settings, $breakpoint_name ) {
		$object_schemas = $this->get_popup_responsive_object_schema_defaults();
		$schema_default = $object_schemas['popup_padding']['default'];
		$resolved       = $this->resolve_popup_object_for_breakpoint(
			$settings,
			'popup_padding',
			$breakpoint_name,
			$schema_default,
			array( $this, 'normalize_popup_padding_leaf' )
		);

		return $this->normalize_popup_padding_leaf( $resolved );
	}

	/**
	 * Drop redundant per-side border props before CSS generation.
	 * Uniform per-side widths that differ from `all` are treated as stale overrides.
	 *
	 * @param mixed $border Resolved border settings.
	 * @return array<string, mixed>
	 */
	private function collapse_popup_border_for_style_declaration( $border ) {
		$normalized = $this->normalize_popup_border_leaf( $border );
		$styles     = isset( $normalized['styles'] ) && is_array( $normalized['styles'] )
			? $normalized['styles']
			: array();

		if ( ! isset( $styles['all'] ) || ! is_array( $styles['all'] ) ) {
			return $normalized;
		}

		$all_side        = $styles['all'];
		$per_side_names  = array( 'top', 'right', 'bottom', 'left' );
		$per_side_widths = array();

		foreach ( $per_side_names as $side_name ) {
			if ( isset( $styles[ $side_name ]['width'] ) && is_string( $styles[ $side_name ]['width'] ) ) {
				$per_side_widths[] = $styles[ $side_name ]['width'];
			}
		}

		if (
			count( $per_side_widths ) === count( $per_side_names )
			&& count( array_unique( $per_side_widths ) ) === 1
			&& ( $all_side['width'] ?? null ) !== $per_side_widths[0]
		) {
			foreach ( $per_side_names as $side_name ) {
				if ( ! isset( $styles[ $side_name ] ) || ! is_array( $styles[ $side_name ] ) ) {
					continue;
				}

				unset( $styles[ $side_name ]['width'] );

				if ( empty( $styles[ $side_name ] ) ) {
					unset( $styles[ $side_name ] );
				}
			}
		}

		foreach ( $per_side_names as $side_name ) {
			if ( ! isset( $styles[ $side_name ] ) || ! is_array( $styles[ $side_name ] ) ) {
				continue;
			}

			foreach ( array( 'width', 'color', 'style' ) as $prop ) {
				if (
					isset( $styles[ $side_name ][ $prop ] )
					&& isset( $all_side[ $prop ] )
					&& $styles[ $side_name ][ $prop ] === $all_side[ $prop ]
				) {
					unset( $styles[ $side_name ][ $prop ] );
				}
			}

			if ( empty( $styles[ $side_name ] ) ) {
				unset( $styles[ $side_name ] );
			}
		}

		$normalized['styles'] = $styles;

		return $normalized;
	}

	/**
	 * Get border styles variables.
	 *
	 * @param array $border Border settings.
	 * @return array Border styles.
	 */
	private function get_border_styles( $border ) {
		$border_style_declaration = Border\Border::style_declaration(
			array(
				'returnType' => 'key_value_pair',
				'attrValue'  => $this->collapse_popup_border_for_style_declaration( $border ),
			)
		);

		$styles = '';

		foreach ( $border_style_declaration as $key => $value ) {
			$styles .= sprintf( '--dsm-popup-%s: %s;', $key, $value );
		}

		return $styles;
	}

	/**
	 * CSS custom properties that place the FE close glyph (`::before`).
	 *
	 * The glyph is `position: absolute`, so overlay flex `--close-button-position-vertical`
	 * / `--horizontal` do not position it. Presets emit the same inset + transform contract
	 * as Visual Builder `body::before` (`vb-style.scss`). Custom must set `right`/`bottom`
	 * to `auto` so SCSS defaults (`right: 0`) cannot fight `left`.
	 *
	 * @param string $position  Preset slug or `custom`.
	 * @param string $close_top Resolved custom top length.
	 * @param string $close_left Resolved custom left length.
	 * @return string
	 */
	private function get_close_button_position_css_variables( $position, $close_top = '0px', $close_left = '0px' ) {
		$position        = is_string( $position ) ? $position : 'top_right';
		$close_top       = is_string( $close_top ) && '' !== $close_top ? $close_top : '0px';
		$close_left      = is_string( $close_left ) && '' !== $close_left ? $close_left : '0px';
		$reset_transform = '--close-button-position-transform: none;';

		switch ( $position ) {
			case 'top_left':
				return '--close-button-position-top: 0; --close-button-position-right: auto; --close-button-position-bottom: auto; --close-button-position-left: 0; ' . $reset_transform;
			case 'top_center':
				return '--close-button-position-top: 0; --close-button-position-right: auto; --close-button-position-bottom: auto; --close-button-position-left: 50%; --close-button-position-transform: translateX(-50%);';
			case 'bottom_right':
				return '--close-button-position-top: auto; --close-button-position-right: 0; --close-button-position-bottom: 0; --close-button-position-left: auto; ' . $reset_transform;
			case 'bottom_left':
				return '--close-button-position-top: auto; --close-button-position-right: auto; --close-button-position-bottom: 0; --close-button-position-left: 0; ' . $reset_transform;
			case 'bottom_center':
				return '--close-button-position-top: auto; --close-button-position-right: auto; --close-button-position-bottom: 0; --close-button-position-left: 50%; --close-button-position-transform: translateX(-50%);';
			case 'custom':
				return '--close-button-position-top: ' . $close_top . '; --close-button-position-right: auto; --close-button-position-bottom: auto; --close-button-position-left: ' . $close_left . '; ' . $reset_transform;
			case 'top_right':
			default:
				return '--close-button-position-top: 0; --close-button-position-right: 0; --close-button-position-bottom: auto; --close-button-position-left: auto; ' . $reset_transform;
		}
	}

	/**
	 * Emit `:root { --gcid-* }` definitions for palette IDs referenced by popup library content only.
	 *
	 * Footer-injected layouts (notably WooCommerce-triggered popups) are not included in Divi's early
	 * dynamic-asset scan of the page post_content, so `var(--gcid-uuid)` resolves to unset otherwise.
	 *
	 * @param string $scan_blob Serialized block content plus optional page-setting JSON matching Divi's detector inputs.
	 * @return string Empty string or `:root{...}` CSS fragment.
	 */
	private function get_global_palette_root_css_for_popup_library_scan( string $scan_blob ): string {
		$scan_blob = trim( $scan_blob );
		if ( '' === $scan_blob ) {
			return '';
		}

		if (
			! class_exists( DetectFeature::class )
			|| ! class_exists( Style::class )
			|| ! class_exists( GlobalData::class )
		) {
			return '';
		}

		$from_content = DetectFeature::get_global_color_ids( $scan_blob );
		$from_presets = DetectFeature::get_preset_global_color_ids( $scan_blob );

		$color_ids = array_merge( $from_content, $from_presets );

		if ( class_exists( DynamicAssetsUtils::class ) ) {
			$color_ids = DynamicAssetsUtils::get_unique_array_values(
				$color_ids,
				array_keys( GlobalData::get_customizer_colors() )
			);
		} else {
			$color_ids = array_values( array_unique( $color_ids ) );
		}

		if ( empty( $color_ids ) ) {
			return '';
		}

		return Style::get_global_colors_style( $color_ids );
	}

	/**
	 * Build popup markup and combined CSS (`Page::custom_css` + DSM popup breakpoint variables).
	 *
	 * @param int  $popup_id Library layout ID.
	 * @param bool $consume_collected_styles Whether to render and clear Divi's shared collected style bucket.
	 * @return array<string, mixed>|null Null when post missing.
	 */
	private function compile_popup_markup_and_aggregate_css( int $popup_id, bool $consume_collected_styles = false ): ?array {

		$popup_post = get_post( $popup_id );
		if ( ! $popup_post instanceof \WP_Post ) {
			return null;
		}

		$settings = self::get_popup_settings( $popup_id );

		$layout_id = DiviLibraryLayoutRenderer::normalize_post_id( $popup_id );

		/*
		 * Mirrors {@see DSM_Library_Layout_Preview_REST::rest_callback()}: TB inner-context + module
		 * {@see Style::render()} output is required for printed module/preset CSS, not only
		 * {@see Page::custom_css()}.
		 */
		$previous_tb_inner = false;
		if ( class_exists( Style::class ) ) {
			$previous_tb_inner = Style::get_is_theme_builder_context_for_inner_content();
			Style::set_is_theme_builder_context_for_inner_content( true );
		}

		try {
			$popup_content = DiviLibraryLayoutRenderer::render_layout(
				$layout_id,
				'dsm_popup_library_styles'
			);
		} finally {
			if ( class_exists( Style::class ) ) {
				Style::set_is_theme_builder_context_for_inner_content( $previous_tb_inner );
			}
		}

		$page_and_module_css = '';
		if ( class_exists( Page::class ) ) {
			$page_and_module_css .= (string) Page::custom_css( $popup_id );
		}

		if ( $consume_collected_styles && class_exists( Style::class ) ) {
			$page_and_module_css .= Style::render( 'default', 'presetNested', 'post' )
				. Style::render( 'default', 'preset', 'post' )
				. Style::render( 'default', 'presetGroup', 'post' )
				. Style::render( 'default', 'module', 'post' );
			Style::clear_styles_for_key( 'post' );
			Style::set_detected_module_types_for_inner_content( array() );
		}

		$combined_for_popup_palette_scan = (string) $popup_post->post_content;
		if ( class_exists( DynamicAssetsUtils::class ) ) {
			$combined_for_popup_palette_scan .= wp_json_encode(
				DynamicAssetsUtils::get_page_setting_attributes( $layout_id, array() ),
				JSON_UNESCAPED_SLASHES
			);
		}
		$page_and_module_css = $this->get_global_palette_root_css_for_popup_library_scan(
			$combined_for_popup_palette_scan
		) . $page_and_module_css;

		$css = '';

		// --- Your Existing CSS Generation Logic (Unchanged) ---
		foreach ( $this->get_popup_enabled_breakpoints() as $breakpoint ) {
			$breakpoint_name = $breakpoint['name'];

			// ... [All your existing variable extraction logic remains here] ...
			// (I have hidden the variable extraction for brevity, assume it is exactly as you wrote it)
			$overlay_color               = $this->resolve_popup_scalar_for_breakpoint(
				$settings,
				'popup_overlay_color',
				$breakpoint_name,
				'rgba(11, 11, 11, 0.8)'
			);
			$popup_max_height            = $this->resolve_popup_length_for_breakpoint(
				$settings,
				'popup_max_height',
				$breakpoint_name,
				''
			);
			$popup_max_width             = $this->resolve_popup_length_for_breakpoint(
				$settings,
				'popup_max_width',
				$breakpoint_name,
				'600px'
			);
			$popup_close_bg_button_color = $this->resolve_popup_scalar_for_breakpoint(
				$settings,
				'popup_close_bg_button_color',
				$breakpoint_name,
				'#000000'
			);
			$popup_close_button_color    = $this->resolve_popup_scalar_for_breakpoint(
				$settings,
				'popup_close_button_color',
				$breakpoint_name,
				'#ffffff'
			);
			$popup_close_button_size     = $this->resolve_popup_length_for_breakpoint(
				$settings,
				'popup_close_button_size',
				$breakpoint_name,
				'28px'
			);
			$object_schemas              = $this->get_popup_responsive_object_schema_defaults();
			$popup_close_button_icon     = $this->resolve_popup_object_for_breakpoint(
				$settings,
				'popup_close_button_icon',
				$breakpoint_name,
				$object_schemas['popup_close_button_icon']['default']
			);
			$popup_close_icon_unicode    = is_array( $popup_close_button_icon )
				? IconGlyphRenderer::decoded_glyph_character( $popup_close_button_icon )
				: '';
			$popup_close_icon_unicode    = str_replace(
				array( '\\', '"' ),
				array( '\\\\', '\\"' ),
				$popup_close_icon_unicode
			);
			$icon_font_family            = 'ETmodules';

			if ( is_array( $popup_close_button_icon ) && IconProcessFontIconBridge::uses_icon_manager_font_family() ) {
				$resolved_family = IconGlyphRenderer::icon_manager_font_family( $popup_close_button_icon );

				if ( '' !== $resolved_family ) {
					$icon_font_family = $resolved_family;
				}
			} elseif ( is_array( $popup_close_button_icon ) && isset( $popup_close_button_icon['type'] ) && 'fa' === $popup_close_button_icon['type'] ) {
				$icon_font_family = 'FontAwesome';
			}
			$icon_font_weight               = is_array( $popup_close_button_icon ) ? ( $popup_close_button_icon['weight'] ?? '' ) : '';
			$popup_padding_sides            = $this->resolve_popup_padding_sides_for_breakpoint( $settings, $breakpoint_name );
			$popup_padding_top              = $popup_padding_sides['top'];
			$popup_padding_right            = $popup_padding_sides['right'];
			$popup_padding_bottom           = $popup_padding_sides['bottom'];
			$popup_padding_left             = $popup_padding_sides['left'];
			$popup_wrapper_background_color = $this->resolve_popup_scalar_for_breakpoint(
				$settings,
				'popup_wrapper_background_color',
				$breakpoint_name,
				'#ffffff'
			);
			$popup_main_axis                = $this->resolve_popup_scalar_for_breakpoint(
				$settings,
				'popup_main_axis',
				$breakpoint_name,
				'center'
			);
			$popup_cross_axis               = $this->resolve_popup_scalar_for_breakpoint(
				$settings,
				'popup_cross_axis',
				$breakpoint_name,
				'center'
			);
			$popup_close_button_position    = $this->resolve_popup_scalar_for_breakpoint(
				$settings,
				'popup_close_button_position',
				$breakpoint_name,
				'top_right'
			);

			$popup_box_shadow = $this->resolve_popup_object_for_breakpoint(
				$settings,
				'popup_box_shadow',
				$breakpoint_name,
				$object_schemas['popup_box_shadow']['default']
			);

			$box_shadow_style = isset( $popup_box_shadow['style'] ) ? $popup_box_shadow['style'] : 'none';

			if ( 'none' === $box_shadow_style ) {
				$box_shadow_value = 'none';
			} else {
				// Inner or outer shadow check.
				$shadow_position   = ( isset( $popup_box_shadow['position'] ) && 'inner' === $popup_box_shadow['position'] ) ? 'inset ' : '';
				$shadow_horizontal = isset( $popup_box_shadow['horizontal'] ) ? $popup_box_shadow['horizontal'] : '0px';
				$shadow_vertical   = isset( $popup_box_shadow['vertical'] ) ? $popup_box_shadow['vertical'] : '0px';
				$shadow_blur       = isset( $popup_box_shadow['blur'] ) ? $popup_box_shadow['blur'] : '0px';
				$shadow_spread     = isset( $popup_box_shadow['spread'] ) ? $popup_box_shadow['spread'] : '0px';
				$shadow_color      = isset( $popup_box_shadow['color'] ) ? $popup_box_shadow['color'] : '#000000';

				$box_shadow_value = sprintf(
					'%s%s %s %s %s %s',
					$shadow_position,
					$shadow_horizontal,
					$shadow_vertical,
					$shadow_blur,
					$shadow_spread,
					$shadow_color
				);
			}

			$popup_border  = $this->resolve_popup_object_for_breakpoint(
				$settings,
				'popup_border',
				$breakpoint_name,
				$object_schemas['popup_border']['default'],
				$this->get_popup_object_normalize_fn( $object_schemas['popup_border'] ),
				! empty( $object_schemas['popup_border']['ignore_schema_smaller'] )
			);
			$border_styles = $this->get_border_styles( $popup_border );

			$close_top  = '0px';
			$close_left = '0px';
			if ( 'custom' === $popup_close_button_position ) {
				$close_top  = $this->resolve_popup_length_for_breakpoint(
					$settings,
					'popup_close_button_top',
					$breakpoint_name,
					'0px'
				);
				$close_left = $this->resolve_popup_length_for_breakpoint(
					$settings,
					'popup_close_button_left',
					$breakpoint_name,
					'0px'
				);
			}
			$close_button_variables = $this->get_close_button_position_css_variables(
				$popup_close_button_position,
				$close_top,
				$close_left
			);

			// Convert positioning values to CSS variables.
			$main_axis_value   = '';
			$main_axis_justify = '';
			$cross_margin      = '';

			// Map main axis values to vertical-align (absolute) and flex justify (fixed).
			switch ( $popup_main_axis ) {
				case 'start':
					$main_axis_value   = 'top';
					$main_axis_justify = 'flex-start';
					break;
				case 'center':
					$main_axis_value   = 'middle';
					$main_axis_justify = 'center';
					break;
				case 'end':
					$main_axis_value   = 'bottom';
					$main_axis_justify = 'flex-end';
					break;
				default:
					$main_axis_value   = 'middle';
					$main_axis_justify = 'center';
			}

			// Map cross axis values to margins.
			switch ( $popup_cross_axis ) {
				case 'left':
					$cross_margin = 'auto 0 0 0';
					break;
				case 'center':
					$cross_margin = '0 auto';
					break;
				case 'right':
					$cross_margin = '0 0 0 auto';
					break;
				default:
					$cross_margin = '0 auto';
			}

			if ( 'desktop' === $breakpoint_name ) {
				$css .= sprintf(
					'
                    .dsm-popup-%21$s {
                        --dsm-popup-overlay-color: %s;
                        --dsm-popup-max-width: %s;
                        --dsm-popup-close-bg-button-color: %s;
                        --dsm-popup-close-button-color: %s;
                        --dsm-popup-close-button-size: %s;
                        --dsm-popup-close-icon-unicode: "%s";
                        --dsm-popup-close-icon-font-family: %s;
                        --dsm-popup-close-icon-font-weight: %s;
                        --dsm-popup-max-height: %s;
                        --dsm-popup-padding-top: %s;
                        --dsm-popup-padding-right: %s;
                        --dsm-popup-padding-bottom: %s;
                        --dsm-popup-padding-left: %s;
                        --dsm-popup-main-align: %s;
                        --dsm-popup-main-justify: %s;
                        --dsm-popup-cross-margin: %s;
                        --dsm-popup-box-shadow: %s;
                        --dsm-popup-wrapper-background-color: %s;
                        %s
                        %s
                    }',
					$overlay_color,
					$popup_max_width,
					$popup_close_bg_button_color,
					$popup_close_button_color,
					$popup_close_button_size,
					$popup_close_icon_unicode,
					$icon_font_family,
					$icon_font_weight,
					$popup_max_height,
					$popup_padding_top,
					$popup_padding_right,
					$popup_padding_bottom,
					$popup_padding_left,
					$main_axis_value,
					$main_axis_justify,
					$cross_margin,
					$box_shadow_value,
					$popup_wrapper_background_color,
					$close_button_variables,
					$border_styles,
					$popup_id
				);
			} else {
				$max_width = $this->get_popup_breakpoint_media_max_px( $breakpoint );
				if ( null === $max_width ) {
					continue;
				}

				$css .= sprintf(
					'
                    @media (max-width: %1$spx) {
                        .dsm-popup-%21$s {
                            --dsm-popup-overlay-color: %2$s;
                            --dsm-popup-max-width: %3$s;
                            --dsm-popup-close-bg-button-color: %4$s;
                            --dsm-popup-close-button-color: %5$s;
                            --dsm-popup-close-button-size: %6$s;
                            --dsm-popup-close-icon-unicode: "%7$s";
                            --dsm-popup-close-icon-font-family: %8$s;
                            --dsm-popup-close-icon-font-weight: %9$s;
                            --dsm-popup-max-height: %10$s;
                            --dsm-popup-padding-top: %11$s;
                            --dsm-popup-padding-right: %12$s;
                            --dsm-popup-padding-bottom: %13$s;
                            --dsm-popup-padding-left: %14$s;
                            --dsm-popup-main-align: %15$s;
                            --dsm-popup-main-justify: %22$s;
                            --dsm-popup-cross-margin: %16$s;
                            --dsm-popup-wrapper-background-color: %17$s;
                            --dsm-popup-box-shadow: %19$s;
                            %18$s
                            %20$s
                        }
                    }',
					$max_width,
					$overlay_color,
					$popup_max_width,
					$popup_close_bg_button_color,
					$popup_close_button_color,
					$popup_close_button_size,
					$popup_close_icon_unicode,
					$icon_font_family,
					$icon_font_weight,
					$popup_max_height,
					$popup_padding_top,
					$popup_padding_right,
					$popup_padding_bottom,
					$popup_padding_left,
					$main_axis_value,
					$cross_margin,
					$popup_wrapper_background_color,
					$close_button_variables,
					$box_shadow_value,
					$border_styles,
					$popup_id,
					$main_axis_justify
				);
			}
		}
		// --- End CSS Generation ---

		$aggregate_css = $page_and_module_css . $css;

		$close_popup_triggers = $this->normalize_close_popup_triggers( $settings );

		$dsm_popup_options = array(
			'close_popup_triggers'        => $close_popup_triggers,
			'entrance_animation'          => isset( $settings['entrance_animation'] ) ? esc_attr( (string) $settings['entrance_animation'] ) : '',
			'entrance_animation_duration' => isset( $settings['entrance_animation_duration'] ) ? esc_attr( (string) $settings['entrance_animation_duration'] ) : '0.4s',
			'entrance_animation_delay'    => isset( $settings['entrance_animation_delay'] ) ? esc_attr( (string) $settings['entrance_animation_delay'] ) : '0s',
			'exit_animation'              => isset( $settings['exit_animation'] ) ? esc_attr( $settings['exit_animation'] ) : '',
			'exit_animation_duration'     => isset( $settings['exit_animation_duration'] ) ? esc_attr( (string) $settings['exit_animation_duration'] ) : '0.25s',
			'exit_animation_delay'        => isset( $settings['exit_animation_delay'] ) ? esc_attr( (string) $settings['exit_animation_delay'] ) : '0s',
			'popup_class'                 => isset( $settings['popup_class'] ) && in_array( 'css_class', $close_popup_triggers, true ) ? esc_attr( $settings['popup_class'] ) : '',
			'open_popup_trigger'          => isset( $settings['open_popup_trigger'] ) ? esc_attr( $settings['open_popup_trigger'] ) : '',
			'auto_close_popup'            => isset( $settings['auto_close_popup'] ) ? esc_attr( $settings['auto_close_popup'] ) : '',
			'auto_close_popup_delay'      => isset( $settings['auto_close_popup_delay'] ) ? esc_attr( $settings['auto_close_popup_delay'] ) : '',
			'popup_appear'                => isset( $settings['popup_appear'] ) ? esc_attr( $settings['popup_appear'] ) : '',
			'popup_appear_after_x_days'   => isset( $settings['popup_appear_after_x_days'] ) ? esc_attr( $settings['popup_appear_after_x_days'] ) : '',
			'popup_appear_after_x_hours'  => isset( $settings['popup_appear_after_x_hours'] ) ? esc_attr( $settings['popup_appear_after_x_hours'] ) : '',
			'popup_main_axis_desktop'     => isset( $settings['popup_main_axis']['desktop'] ) ? esc_attr( $settings['popup_main_axis']['desktop'] ) : '',
			'popup_cross_axis_desktop'    => isset( $settings['popup_cross_axis']['desktop'] ) ? esc_attr( $settings['popup_cross_axis']['desktop'] ) : '',
			'popup_main_axis_tablet'      => isset( $settings['popup_main_axis']['tablet'] ) ? esc_attr( $settings['popup_main_axis']['tablet'] ) : '',
			'popup_cross_axis_tablet'     => isset( $settings['popup_cross_axis']['tablet'] ) ? esc_attr( $settings['popup_cross_axis']['tablet'] ) : '',
			'popup_main_axis_mobile'      => isset( $settings['popup_main_axis']['mobile'] ) ? esc_attr( $settings['popup_main_axis']['mobile'] ) : '',
			'popup_cross_axis_mobile'     => isset( $settings['popup_cross_axis']['mobile'] ) ? esc_attr( $settings['popup_cross_axis']['mobile'] ) : '',
			'popup_id'                    => $popup_id,
			'popup_target'                => isset( $settings['popup_target'] ) ? esc_attr( $settings['popup_target'] ) : '',
			'popup_target_by_class'       => isset( $settings['popup_target_by_class'] ) ? esc_attr( $settings['popup_target_by_class'] ) : '',
			'popup_target_by_id'          => isset( $settings['popup_target_by_id'] ) ? esc_attr( $settings['popup_target_by_id'] ) : '',
			'hide_close_button'           => isset( $settings['hide_close_button'] ) ? esc_attr( $settings['hide_close_button'] ) : '',
			'popup_type'                  => isset( $settings['popup_type'] ) ? esc_attr( $settings['popup_type'] ) : '',
			'popup_viewport_delay'        => isset( $settings['popup_viewport_delay'] ) ? esc_attr( $settings['popup_viewport_delay'] ) : '',
			'popup_open_delay'            => isset( $settings['popup_open_delay'] ) ? esc_attr( (string) $settings['popup_open_delay'] ) : '0s',
			'popup_max_opens_per_session' => isset( $settings['popup_max_opens_per_session'] )
				? max( 0, absint( (int) $settings['popup_max_opens_per_session'] ) )
				: 0,
			'popup_open_frequency'        => esc_attr(
				$this->sanitize_popup_open_frequency_for_options(
					isset( $settings['popup_open_frequency'] ) ? $settings['popup_open_frequency'] : 'unlimited'
				)
			),
			'wc_action'                   => isset( $settings['wc_action'] ) ? esc_attr( $settings['wc_action'] ) : '',
			'popup_position_type'         => esc_attr(
				$this->sanitize_popup_position_type(
					isset( $settings['popup_position_type'] ) ? $settings['popup_position_type'] : 'absolute'
				)
			),
			'popup_show_overlay'          => esc_attr(
				isset( $settings['popup_show_overlay'] ) && 'off' === $settings['popup_show_overlay'] ? 'off' : 'on'
			),
		);

		// Convert array to JSON string.
		$encoded_popup_options = wp_json_encode( $dsm_popup_options );
		$dsm_popup_options     = is_string( $encoded_popup_options ) ? $encoded_popup_options : '{}';

		// [Divi 5 Change] Removed $generated_style logic.
		// Divi will now handle injecting the CSS (either inline or via file) automatically.

		// `id="et-boc"` on WooCommerce shop, product category/tag archives, or single product with a category —
		// so Divi `.et-db #et-boc .et-l` CSS can match without adding the id on every page.
		// Multiple popups still duplicate the id if several open on one URL.
		$popup_wrapper_open = '<div class="dsm-popup-wrapper">';
		$use_et_boc_id      = false;
		if ( function_exists( 'is_product_category' ) && is_product_category() ) {
			$use_et_boc_id = true;
		} elseif ( function_exists( 'is_product_tag' ) && is_product_tag() ) {
			$use_et_boc_id = true;
		} elseif ( function_exists( 'is_shop' ) && is_shop() ) {
			$use_et_boc_id = true;
		} elseif ( function_exists( 'is_product' ) && is_product() && taxonomy_exists( 'product_cat' ) ) {
			$pid = (int) get_the_ID();
			if ( $pid > 0 ) {
				$cats          = wp_get_post_terms( $pid, 'product_cat', array( 'fields' => 'ids' ) );
				$use_et_boc_id = ! is_wp_error( $cats ) && ! empty( $cats );
			}
		}
		// Optional override: filter dsm_popup_wrapper_use_et_boc_id to force the et-boc id.
		if ( apply_filters( 'dsm_popup_wrapper_use_et_boc_id', $use_et_boc_id, $popup_id ) ) {
			$popup_wrapper_open = '<div id="et-boc" class="dsm-popup-wrapper">';
		}

		$html = sprintf(
			'<div id="dsm-popup-%1$s" class="dsm-popup" data-dsm-popup-options=%2$s>
              %4$s
                %3$s
              </div>
            </div>',
			esc_attr( $popup_id ),
			$dsm_popup_options,
			$popup_content,
			$popup_wrapper_open
		);

		return array(
			'html'            => $html,
			'aggregate_css'   => $aggregate_css,
			'library_css'     => $page_and_module_css,
			'popup_shell_css' => $css,
		);
	}

	/**
	 * Scoped scroll/animation/breakpoint JSON for VB Magnific preview only.
	 * Uses a throwaway standalone library parse ({@see DiviLibraryLayoutRenderer::render_standalone_library_layout_for_visual_builder_preview})
	 * because nested embed renders omit ScriptData; always clear duplicate Style residue after this pass.
	 *
	 * @param int $popup_id Library layout ID.
	 * @return array{preview_scroll_data:array,preview_animation_data:array,preview_breakpoint_data:array}
	 */
	private function collect_visual_builder_popup_preview_script_arrays( int $popup_id ): array {
		$empty = array(
			'preview_scroll_data'     => array(),
			'preview_animation_data'  => array(),
			'preview_breakpoint_data' => array(),
		);

		if ( $popup_id <= 0 ) {
			return $empty;
		}

		if ( ! class_exists( ScriptData::class ) ) {
			return $empty;
		}

		ScriptData::reset();

		// Fill ScriptData the same way as {@see DSM_Library_Layout_Preview_REST}.
		DiviLibraryLayoutRenderer::render_standalone_library_layout_for_visual_builder_preview( $popup_id );

		$preview_scroll_data     = array();
		$preview_animation_data  = array();
		$preview_breakpoint_data = array();

		if (
			class_exists( self::DSM_ET_BREAKPOINT_CLASS )
			&& method_exists( self::DSM_ET_BREAKPOINT_CLASS, 'set_script_data' )
		) {
			call_user_func( array( self::DSM_ET_BREAKPOINT_CLASS, 'set_script_data' ) );
		}

		$preview_root = DsmPreviewScriptScope::popup_visual_preview_root_selector( $popup_id );

		$raw_scroll = ScriptData::get_data( 'scroll' );
		if ( ! empty( $raw_scroll ) ) {
			$preview_scroll_data = DsmPreviewScriptScope::scope_scroll_data(
				$raw_scroll,
				$preview_root,
				$popup_id
			);
		}

		$raw_animation = ScriptData::get_data( 'animation' );
		if ( ! empty( $raw_animation ) ) {
			$preview_animation_data = DsmPreviewScriptScope::scope_animation_data(
				$raw_animation,
				$preview_root
			);
		}

		$raw_breakpoint = ScriptData::get_data( 'breakpoint' );
		if ( ! empty( $raw_breakpoint ) ) {
			$preview_breakpoint_data = $raw_breakpoint;
		}

		ScriptData::reset();

		if ( class_exists( Style::class ) ) {
			Style::clear_styles_for_key( 'post' );
			Style::set_detected_module_types_for_inner_content( array() );
		}

		return array(
			'preview_scroll_data'     => $preview_scroll_data,
			'preview_animation_data'  => $preview_animation_data,
			'preview_breakpoint_data' => $preview_breakpoint_data,
		);
	}

	/**
	 * Render popup markup and enqueue frontend assets / StaticCSS (normal page SSR).
	 *
	 * @param int $popup_id The ID of the popup.
	 * @return string The content of the popup.
	 */
	private function render_popup( $popup_id ) {

		if ( function_exists( 'dsm_enqueue_magnific_popup_assets' ) ) {
			dsm_enqueue_magnific_popup_assets();
		}

		if ( function_exists( 'dsm_request_divi_icon_font_for_popup_render' ) ) {
			dsm_request_divi_icon_font_for_popup_render();
		}

		wp_enqueue_style( \DiviSupreme\Includes\DsmFrontendModuleAssetRegistry::EXTENSION_POPUP_STYLE_HANDLE );
		wp_enqueue_script( 'dsm-popup-extension' );

		// Use the current page resource and force footer inline output before rendering
		// the popup. Otherwise existing static CSS files can prevent Divi from collecting
		// module styles generated by this dynamically injected layout.
		$result                  = StaticCSS::setup_styles_manager( 0 );
		$styles_manager          = $result['manager'];
		$deferred_styles_manager = $result['deferred'] ?? null;

		$styles_manager->forced_inline       = true;
		$styles_manager->write_file_location = 'footer';
		$styles_manager->set_output_location( 'footer' );

		if ( $deferred_styles_manager ) {
			$deferred_styles_manager->forced_inline       = true;
			$deferred_styles_manager->write_file_location = 'footer';
			$deferred_styles_manager->set_output_location( 'footer' );
		}

		if ( false === has_action( 'wp_footer', array( StaticCSS::class, 'enqueue_or_render_style' ) ) ) {
			add_action( 'wp_footer', array( StaticCSS::class, 'enqueue_or_render_style' ), 10 );
		}

		$compiled = $this->compile_popup_markup_and_aggregate_css( (int) $popup_id );
		if ( null === $compiled || '' === $compiled['html'] ) {
			return '';
		}

		if ( '' !== trim( (string) $compiled['aggregate_css'] ) ) {
			StaticCSS::add_element(
				new StaticCSSElement(
					'dsm_popup',
					$popup_id,
					$compiled['aggregate_css'],
					$styles_manager,
					$deferred_styles_manager
				)
			);
		}

		return $compiled['html'];
	}

	/**
	 * Serialized popup markup + combined CSS when `render_block` did not emit it (Visual Builder iframe).
	 *
	 * @param int $popup_id Library layout ID (popup layout picker).
	 * @return array{markup:string,inlineCss:string}|null Null if disabled or not renderable.
	 */
	public function export_visual_builder_popup_preview_fragment( int $popup_id ): ?array {
		$settings = self::get_popup_settings( $popup_id );
		$enabled  = $settings['is_enabled'];
		if ( ! $enabled ) {
			return null;
		}

		$compiled = $this->compile_popup_markup_and_aggregate_css( $popup_id, true );
		if ( null === $compiled || '' === $compiled['html'] ) {
			return null;
		}

		$script_payload = $this->collect_visual_builder_popup_preview_script_arrays( $popup_id );

		$library_css    = isset( $compiled['library_css'] ) ? $compiled['library_css'] : '';
		$scoped_library = '';
		if ( is_string( $library_css ) && '' !== trim( $library_css ) ) {
			$root           = '#dsm-popup-' . absint( $popup_id ) . ' .dsm-popup-wrapper';
			$scoped_library = DsmCssPreviewScope::apply( $library_css, $root );
		}

		$popup_shell = isset( $compiled['popup_shell_css'] ) ? $compiled['popup_shell_css'] : '';

		return array(
			'markup'                => $compiled['html'],
			'inlineCss'             => $scoped_library . $popup_shell,
			'previewScrollData'     => isset( $script_payload['preview_scroll_data'] ) ? $script_payload['preview_scroll_data'] : array(),
			'previewAnimationData'  => isset( $script_payload['preview_animation_data'] ) ? $script_payload['preview_animation_data'] : array(),
			'previewBreakpointData' => isset( $script_payload['preview_breakpoint_data'] ) ? $script_payload['preview_breakpoint_data'] : array(),
		);
	}

	/**
	 * Renders the necessary popup content
	 *
	 * @param string    $content The content of the block.
	 * @param array     $block The block.
	 * @param \WP_Block $instance The block instance.
	 * @return string The content of the block.
	 */
	public function render_module_popup( $content, $block, \WP_Block $instance ) {
		unset( $instance );

		$use_popup = isset( $block['attrs']['use_popup']['innerContent']['desktop']['value'] ) ? 'on' === $block['attrs']['use_popup']['innerContent']['desktop']['value'] : false;

		if ( $use_popup ) {
			$popup_id = isset( $block['attrs']['popup_layout']['innerContent']['desktop']['value'] ) ? $block['attrs']['popup_layout']['innerContent']['desktop']['value'] : '-1';
			$popup_id = (int) $popup_id;

			if ( -1 !== $popup_id ) {
				$settings = self::get_popup_settings( $popup_id );
				$enabled  = $settings['is_enabled'];

				if ( $enabled ) {
					$popup_html = $this->render_popup( $popup_id );
					$content    = $this->attach_popup_markup_to_module_content( $content, $popup_html, $block, $popup_id );
				}
			}
		}

		return $content;
	}

	/**
	 * Attach `#dsm-popup-{id}` to the module that enabled it.
	 *
	 * List-item children (Supreme Mega Menu Pro, etc.) render as a root `<li>`. Appending the
	 * popup after that tag leaves `#dsm-popup-*` as a sibling inside `ul.dsm-root-menu`, so JS
	 * `closest('.et_pb_module')` binds the parent menu. Nest inside the root `<li>` instead.
	 *
	 * @param string               $content     Rendered block HTML.
	 * @param string               $popup_html  Popup shell HTML.
	 * @param array<string, mixed> $block       `render_block` block array.
	 * @param int                  $popup_id    Library layout ID.
	 * @return string
	 */
	private function attach_popup_markup_to_module_content( $content, $popup_html, $block, $popup_id ) {
		if ( ! is_string( $content ) || ! is_string( $popup_html ) || '' === $popup_html ) {
			return is_string( $content ) ? $content : '';
		}

		/**
		 * Whether to nest the popup shell inside a root `<li>` (mega-menu / list children).
		 *
		 * @param bool                 $nest      Default true.
		 * @param string               $content   Module HTML.
		 * @param array<string, mixed> $block     Block being rendered.
		 * @param int                  $popup_id  Popup layout ID.
		 */
		$nest = (bool) apply_filters( 'dsm_popup_nest_inside_root_list_item', true, $content, $block, $popup_id );
		if ( $nest ) {
			$nested = $this->insert_before_root_close_tag( $content, 'li', $popup_html );
			if ( is_string( $nested ) && '' !== $nested ) {
				return $nested;
			}
		}

		return $content . $popup_html;
	}

	/**
	 * Insert HTML before the closing tag of the first root element when that tag is `$tag`.
	 *
	 * @param string $html   Module markup (may include leading whitespace).
	 * @param string $tag    Tag name without brackets (e.g. `li`).
	 * @param string $insert Markup to insert.
	 * @return string|null Nested HTML, or null when the root element is not `$tag`.
	 */
	private function insert_before_root_close_tag( $html, $tag, $insert ) {
		if ( ! is_string( $html ) || ! is_string( $tag ) || ! is_string( $insert ) ) {
			return null;
		}

		$tag = strtolower( $tag );
		if ( ! preg_match( '/^[a-z][a-z0-9]*$/', $tag ) ) {
			return null;
		}

		$trimmed = ltrim( $html );
		$lead    = substr( $html, 0, strlen( $html ) - strlen( $trimmed ) );
		if ( ! preg_match( '/^<' . preg_quote( $tag, '/' ) . '(?:[\s>\/])/i', $trimmed ) ) {
			return null;
		}

		$open_prefix = '<' . $tag;
		$close       = '</' . $tag . '>';
		$length      = strlen( $trimmed );
		$pos         = 0;
		$depth       = 0;
		$root_close  = null;

		while ( $pos < $length ) {
			$next_open  = $this->find_html_tag_open( $trimmed, $open_prefix, $pos );
			$next_close = stripos( $trimmed, $close, $pos );

			if ( false === $next_close ) {
				return null;
			}

			if ( false !== $next_open && $next_open < $next_close ) {
				++$depth;
				$pos = $next_open + strlen( $open_prefix );
				continue;
			}

			--$depth;
			if ( 0 === $depth ) {
				$root_close = $next_close;
				break;
			}

			$pos = $next_close + strlen( $close );
		}

		if ( null === $root_close ) {
			return null;
		}

		return $lead . substr( $trimmed, 0, $root_close ) . $insert . substr( $trimmed, $root_close );
	}

	/**
	 * Offset of the next `<tag` that is a real start tag (`<li `, `<li>`, `<li/`), not `<link`.
	 *
	 * @param string $html       Haystack.
	 * @param string $open_prefix Lowercase-insensitive prefix such as `<li`.
	 * @param int    $offset     Search start.
	 * @return int|false
	 */
	private function find_html_tag_open( $html, $open_prefix, $offset ) {
		$prefix_len = strlen( $open_prefix );
		$length     = strlen( $html );
		$pos        = $offset;

		while ( $pos < $length ) {
			$found = stripos( $html, $open_prefix, $pos );
			if ( false === $found ) {
				return false;
			}

			$after = $found + $prefix_len;
			$ch    = $after < $length ? $html[ $after ] : '';
			if ( ' ' === $ch || '>' === $ch || '/' === $ch || "\n" === $ch || "\t" === $ch || "\r" === $ch ) {
				return $found;
			}

			$pos = $after;
		}

		return false;
	}

	/**
	 * Add REST support for storing popup settings
	 *
	 * @param int $post_id Post ID.
	 * @return void
	 */
	public function save_popup_settings( $post_id ) {

		$page_settings  = \DiviSupreme\Includes\DsmVbRestSave::get_page_settings();
		$popup_settings = isset( $page_settings['dsm_popup_settings'] ) ? $page_settings['dsm_popup_settings'] : array();

		// Newer divi version use different structure.
		if ( empty( $popup_settings ) ) {
			$by_layout      = \DiviSupreme\Includes\DsmVbRestSave::get_page_settings_by_layout_post_content();
			$popup_settings = isset( $by_layout['dsm_popup_settings'] ) ? $by_layout['dsm_popup_settings'] : array();
		}

		if ( is_array( $popup_settings ) ) {
			$popup_settings = $this->migrate_legacy_popup_setting_keys( $popup_settings );
			$popup_settings = $this->strip_popup_responsive_echo_defaults( $popup_settings );
		}

		update_post_meta( $post_id, 'dsm-popup-settings', $popup_settings );
		$this->invalidate_global_popups_vb_cache();
	}

	/**
	 * Get popup settings
	 *
	 * @param int $post_id Post ID.
	 * @return array Popup settings.
	 */
	public function get_popup_settings( $post_id ) {
		$settings = get_post_meta( $post_id, 'dsm-popup-settings', true );
		if ( empty( $settings ) || ! is_array( $settings ) ) {
			return $this->default_settings;
		}
		$settings = $this->migrate_legacy_popup_setting_keys( $settings );
		$settings = wp_parse_args( $settings, $this->default_settings );

		return $this->strip_popup_responsive_echo_defaults( $settings );
	}

	/**
	 * Register the popup extension
	 *
	 * @return void
	 */
	public function register() {
		register_post_meta(
			'et_pb_layout',
			'dsm-popup-settings',
			array(
				'type'          => 'object',
				'description'   => __( 'Settings for the DiviSupreme popup functionality', 'dsm-supreme-modules-pro-for-divi' ),
				'single'        => true,
				'auth_callback' => array( $this, 'auth_popup_settings' ),
				'default'       => $this->default_settings,
				'show_in_rest'  => false,
			)
		);
	}

	/**
	 * Drop cached VB popup layout list (new/edit/delete layout or popup settings).
	 *
	 * @return void
	 */
	public function invalidate_global_popups_vb_cache(): void {
		delete_transient( self::GLOBAL_POPUPS_CACHE_TRANSIENT );
	}

	/**
	 * Drop the global popup cache when a layout is saved.
	 *
	 * @param int      $post_id Post ID.
	 * @param \WP_Post $post    Post object.
	 * @param bool     $update  Whether this is an existing post being updated.
	 * @return void
	 */
	public function invalidate_global_popups_vb_cache_on_layout_change( $post_id, $post, $update ): void {
		unset( $update );

		if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
			return;
		}

		if ( ! $post instanceof \WP_Post || 'et_pb_layout' !== $post->post_type ) {
			return;
		}

		$this->invalidate_global_popups_vb_cache();
	}

	/**
	 * Drop the global popup cache when a layout is deleted.
	 *
	 * @param int $post_id Post ID.
	 * @return void
	 */
	public function invalidate_global_popups_vb_cache_on_delete( $post_id ): void {
		if ( 'et_pb_layout' !== get_post_type( $post_id ) ) {
			return;
		}

		$this->invalidate_global_popups_vb_cache();
	}

	/**
	 * Drop the global popup cache when popup meta changes.
	 *
	 * @param int    $meta_id     Meta ID.
	 * @param int    $post_id     Post ID.
	 * @param string $meta_key    Meta key.
	 * @param mixed  $_meta_value Meta value (unused).
	 * @return void
	 */
	public function invalidate_global_popups_vb_cache_on_popup_meta( $meta_id, $post_id, $meta_key, $_meta_value ): void {
		unset( $meta_id, $_meta_value );

		if ( 'dsm-popup-settings' !== $meta_key ) {
			return;
		}

		if ( 'et_pb_layout' !== get_post_type( $post_id ) ) {
			return;
		}

		$this->invalidate_global_popups_vb_cache();
	}

	/**
	 * Get global popups.
	 *
	 * @param string|string[]|false $scope The scope of the popups to get.
	 * @return array Global popups
	 */
	public function get_global_popups( $scope = false ) {
		$index = $this->get_popup_layout_index();

		/**
		 * Popup rows collected for the current scope.
		 *
		 * @var array<int, array{id: int, title: string}> $popups
		 */
		$popups = array();

		foreach ( $index as $row ) {
			if ( ! is_array( $row ) || ! isset( $row['id'], $row['title'] ) ) {
				continue;
			}

			$popup_type = isset( $row['popup_type'] ) ? (string) $row['popup_type'] : 'module';

			if ( false !== $scope ) {
				$is_scoped = is_array( $scope )
					? in_array( $popup_type, $scope, true )
					: $scope === $popup_type;

				if ( ! $is_scoped ) {
					continue;
				}
			}

			$popups[] = array(
				'id'    => (int) $row['id'],
				'title' => (string) $row['title'],
			);
		}

		return $popups;
	}

	/**
	 * Whether the cached popup index includes at least one layout of the given type.
	 *
	 * @param string $popup_type Popup type slug (e.g. `woocommerce`, `module`).
	 * @return bool
	 */
	private function popup_index_has_type( string $popup_type ): bool {
		foreach ( $this->get_popup_layout_index() as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}

			$type = isset( $row['popup_type'] ) ? (string) $row['popup_type'] : 'module';

			if ( $popup_type === $type ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Cached list of enabled library popups with type metadata (shared by all scopes).
	 *
	 * @return array<int, array{id: int, title: string, popup_type: string}>
	 */
	private function get_popup_layout_index(): array {
		$cached = get_transient( self::GLOBAL_POPUPS_CACHE_TRANSIENT );

		if ( is_array( $cached ) ) {
			return $cached;
		}

		$fresh = $this->build_popup_layout_index();
		set_transient( self::GLOBAL_POPUPS_CACHE_TRANSIENT, $fresh, 12 * HOUR_IN_SECONDS );

		return $fresh;
	}

	/**
	 * Uncached build of the enabled popup layout index.
	 *
	 * @return array<int, array{id: int, title: string, popup_type: string}>
	 */
	private function build_popup_layout_index(): array {
		$args = array(
			'post_type'              => 'et_pb_layout',
			'post_status'            => 'publish',
			'posts_per_page'         => -1,
			'no_found_rows'          => true,
			'update_post_term_cache' => false,
			'update_post_meta_cache' => true,
			// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Popup index only needs layouts that store settings.
			'meta_query'             => array(
				array(
					'key'     => 'dsm-popup-settings',
					'value'   => '',
					'compare' => '!=',
				),
			),
		);

		$posts = get_posts( $args );
		$index = array();

		foreach ( $posts as $post ) {
			$popup_settings = $this->get_popup_settings( $post->ID );

			if ( empty( $popup_settings ) || ! isset( $popup_settings['is_enabled'] ) || true !== $popup_settings['is_enabled'] ) {
				continue;
			}

			$popup_type = isset( $popup_settings['popup_type'] ) ? (string) $popup_settings['popup_type'] : 'module';

			$index[] = array(
				'id'         => (int) $post->ID,
				'title'      => (string) $post->post_title,
				'popup_type' => $popup_type,
			);
		}

		return $index;
	}

	/**
	 * Authorize access to popup settings meta.
	 *
	 * @param bool   $allowed   Whether the user can add the meta value.
	 * @param string $meta_key  The meta key.
	 * @param int    $post_id   Post ID.
	 * @param int    $user_id   User ID.
	 * @param string $cap       Capability name.
	 * @param array  $caps      User capabilities.
	 * @return bool Whether the user can add the meta value.
	 */
	public function auth_popup_settings( $allowed, $meta_key, $post_id, $user_id, $cap, $caps ) {
		unset( $allowed, $meta_key, $user_id, $cap, $caps );

		// By default, only allow users who can edit the post to modify popup settings.
		return current_user_can( 'edit_post', $post_id );
	}

	/**
	 * Convert array of variables to CSS custom properties string
	 *
	 * @param array $variables Array of variables to convert
	 * @return string CSS custom properties string
	 */
	/**
	 * Sanitize popup position type (D4 `dsm_modules_popup_position_type` parity).
	 *
	 * @param mixed $value Raw setting value.
	 * @return string `absolute` or `fixed`.
	 */
	private function sanitize_popup_position_type( $value ): string {
		$slug = sanitize_key( (string) $value );

		return in_array( $slug, array( 'fixed', 'absolute' ), true ) ? $slug : 'absolute';
	}

	/**
	 * Turn a name-to-value map into CSS custom properties.
	 *
	 * @param mixed $variables Variable map.
	 * @return string
	 */
	private function array_to_vars( $variables ) {
		if ( ! is_array( $variables ) || empty( $variables ) ) {
			return '';
		}

		$css_vars = array();

		foreach ( $variables as $name => $value ) {
			if ( is_array( $value ) ) {
				// Handle nested arrays (like responsive values).
				foreach ( $value as $breakpoint => $breakpoint_value ) {
					$css_vars[] = sprintf( '--%s-%s: %s', $name, $breakpoint, esc_attr( $breakpoint_value ) );
				}
			} else {
				$css_vars[] = sprintf( '--%s: %s', $name, esc_attr( $value ) );
			}
		}

		return implode( '; ', $css_vars );
	}
}

$GLOBALS['dsm_popup_extension'] = new Popup();
