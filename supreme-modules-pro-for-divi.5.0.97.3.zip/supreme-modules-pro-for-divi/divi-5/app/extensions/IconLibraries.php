<?php
/**
 * Icon Libraries extension bootstrap — REST, frontend webfonts, Divi icon type filter.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Extensions;

use DiviSupreme\Extensions\IconLibraries\IconLibraryRegistry;
use DiviSupreme\Extensions\IconLibraries\IconModuleRenderBridge;
use DiviSupreme\Extensions\IconLibraries\IconProcessFontIconBridge;
use DiviSupreme\Extensions\IconLibraries\PostContentIconScanner;
use DiviSupreme\Includes\DsmDiviBuilderCssScope;
use DiviSupreme\Extensions\IconLibraries\RestApiController;
use DiviSupreme\Extensions\IconLibraries\WebfontAssetLoader;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

$icon_libraries_dir = DSM_DIR_PATH . 'divi-5/app/extensions/IconLibraries/';

require_once $icon_libraries_dir . 'IconAttrCollector.php';
require_once $icon_libraries_dir . 'IconAttrBreakpoint.php';
require_once $icon_libraries_dir . 'IconHostStyleSelectorRegistry.php';
require_once $icon_libraries_dir . 'IconHostStyleAttrCollector.php';
require_once $icon_libraries_dir . 'IconProcessFontIconBridge.php';
require_once $icon_libraries_dir . 'RestApiController.php';

/**
 * Icon Libraries extension.
 */
class IconLibraries {

	/**
	 * Constructor.
	 */
	public function __construct() {
		IconLibraryRegistry::boot();

		IconProcessFontIconBridge::register();
		RestApiController::register();
		IconModuleRenderBridge::register();

		add_action( 'wp_enqueue_scripts', array( $this, 'maybe_enqueue_frontend_assets' ), 99 );
		add_action( 'admin_enqueue_scripts', array( WebfontAssetLoader::class, 'enqueue_admin_previews' ), 20 );
	}

	/**
	 * Enqueue webfont CSS + base icon styles for icons used on the page.
	 *
	 * @return void
	 */
	public function maybe_enqueue_frontend_assets(): void {
		if ( is_admin() || ! function_exists( 'et_core_is_fb_enabled' ) || et_core_is_fb_enabled() ) {
			return;
		}

		if ( array() === IconLibraryRegistry::enabled() ) {
			return;
		}

		$post_id       = (int) get_queried_object_id();
		$icons_on_page = PostContentIconScanner::collect_from_post_content( $post_id );

		IconLibraryRegistry::enqueue_webfonts_for_icons( $icons_on_page );

		if ( ! wp_style_is( 'dsm-icon-libraries-frontend', 'registered' ) ) {
			$css_file = DSM_DIR_PATH . 'divi-5/public/style-icon-libraries-frontend-styles.css';
			$version  = defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';

			if ( is_readable( $css_file ) ) {
				wp_register_style(
					'dsm-icon-libraries-frontend',
					DsmDiviBuilderCssScope::resolve_stylesheet_url( DSM_DIR_URL . 'public/style-icon-libraries-frontend-styles.css' ),
					array(),
					DsmDiviBuilderCssScope::resolve_stylesheet_version( $css_file )
				);
			}
		}

		if ( wp_style_is( 'dsm-icon-libraries-frontend', 'registered' ) ) {
			wp_enqueue_style( 'dsm-icon-libraries-frontend' );
		}
	}
}
