<?php
/**
 * Dark Mode Toggle extension — visitor frontend color scheme.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Extensions;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use DiviSupreme\Extensions\IconLibraries\IconGlyphRenderer;
use DiviSupreme\Extensions\IconLibraries\IconLibraryRegistry;
use DiviSupreme\Extensions\IconLibraries\WebfontAssetLoader;
use ET\Builder\Packages\IconLibrary\IconFont\Utils as DsmDarkModeIconFontUtils;

// Divi Breakpoint API (same candidates as Popup) for floating-switch @media CSS.
$dsm_dm_breakpoint_relative   = 'includes/builder-5/server/Framework/Breakpoint/Breakpoint.php';
$dsm_dm_breakpoint_candidates = array();

if ( \function_exists( 'get_parent_theme_file_path' ) ) {
	$dsm_dm_breakpoint_candidates[] = get_parent_theme_file_path( $dsm_dm_breakpoint_relative );
}

$dsm_dm_breakpoint_candidates[] = trailingslashit( get_template_directory() ) . $dsm_dm_breakpoint_relative;

if ( \function_exists( 'wp_get_theme' ) ) {
	$dsm_dm_divi = wp_get_theme( 'Divi' );
	if ( $dsm_dm_divi instanceof \WP_Theme && $dsm_dm_divi->exists() ) {
		$dsm_dm_breakpoint_candidates[] = trailingslashit( $dsm_dm_divi->get_stylesheet_directory() ) . $dsm_dm_breakpoint_relative;
	}
}

foreach ( array_unique( array_filter( $dsm_dm_breakpoint_candidates ) ) as $dsm_dm_breakpoint_file ) {
	if ( \is_string( $dsm_dm_breakpoint_file )
		&& '' !== $dsm_dm_breakpoint_file
		&& \is_readable( $dsm_dm_breakpoint_file )
	) {
		require_once $dsm_dm_breakpoint_file;
		break;
	}
}

/**
 * Dark Mode Toggle extension bootstrap.
 */
class DarkMode {

	/**
	 * Fully-qualified Divi Breakpoint class name.
	 */
	private const DSM_ET_BREAKPOINT_CLASS = '\\ET\\Builder\\Framework\\Breakpoint\\Breakpoint';

	/**
	 * Wp_options key for global dark mode settings.
	 */
	public const OPTION_KEY = 'dsm_dark_mode_settings';

	/**
	 * LocalStorage key (must match FE / FOUC bootstrap).
	 */
	public const STORAGE_KEY = 'dsm_color_scheme';

	/**
	 * Post meta key for per-page enable flag.
	 */
	public const PAGE_META_KEY = 'dsm-dark-mode-page-enabled';

	/**
	 * Stable Divi Variable Generator colour tokens (read-only public names).
	 *
	 * @see Divi variable-generator-modal.js COLOR_MAP
	 */
	public const GCID_TOKEN_KEYS = array(
		'gcid-primary-color',
		'gcid-secondary-color',
		'gcid-tertiary-color',
		'gcid-heading-color',
		'gcid-body-color',
		'gcid-link-color',
	);

	/**
	 * Default logo img selectors (Divi header / Menu module).
	 */
	public const DEFAULT_LOGO_SELECTOR = '#logo, .logo_container img, .et_pb_menu__logo img, img.logo, .et_pb_fullwidth_menu .logo_container img';

	/**
	 * Default settings.
	 *
	 * @var array<string, mixed>
	 */
	private array $default_settings = array(
		// Site-wide gate. Off until the modal Enable control is saved on.
		// Layouts that already saved settings before this key existed stay on
		// via resolve_saved_is_enabled(). PAGE_META_KEY remains the per-page flag.
		'is_enabled'                      => 'off',
		'default_mode'                    => 'system',
		// Dark Palette: Divi coarse breakpoint maps (soft-migrate flat → desktop).
		'palette_bg'                      => array(
			'desktop' => '#1a1a1a',
		),
		'palette_text'                    => array(
			'desktop' => '#e8e8e8',
		),
		'palette_heading'                 => array(
			'desktop' => '#ffffff',
		),
		'palette_link'                    => array(
			'desktop' => '#7eb8ff',
		),
		'palette_link_hover'              => array(
			'desktop' => '#a8d4ff',
		),
		'palette_accent'                  => array(
			'desktop' => '#7eb8ff',
		),
		'palette_button_text'             => array(
			'desktop' => '#0d1117',
		),
		'palette_surface'                 => array(
			'desktop' => '#242424',
		),
		// none = no automatic Surface; painted = existing fills + carousel cards; cards / content invent surfaces.
		'module_surface_mode'             => 'painted',
		'palette_border'                  => array(
			'desktop' => '#333333',
		),
		// Form / input tokens (defaults cascade from surface / text / border when empty).
		'palette_input_bg'                => array(
			'desktop' => '',
		),
		'palette_input_text'              => array(
			'desktop' => '',
		),
		'palette_input_border'            => array(
			'desktop' => '',
		),
		'show_floating_switch'            => 'off',
		'switch_style'                    => 'pill',
		// Floating switch content mode (Phase 2): default CSS sun/moon vs custom.
		'switch_content_mode'             => 'default',
		'switch_icon_light'               => '',
		'switch_icon_dark'                => '',
		// Empty = inherit Foreground / scale from switch size.
		'switch_icon_color_light'         => '',
		'switch_icon_color_dark'          => '',
		'switch_icon_size'                => '',
		'switch_label_light'              => 'Light',
		'switch_label_dark'               => 'Dark',
		// Label typography (text / icon_text). Divi-like object + responsive maps.
		'switch_label_font'               => array(
			'family'        => '',
			'weight'        => '600',
			'size'          => '13px',
			'letterSpacing' => '0px',
			'lineHeight'    => '1.2em',
			'textAlign'     => 'center',
			'textWrap'      => 'nowrap',
			'style'         => array(),
		),
		'switch_label_font_size'          => array(
			'desktop' => '13px',
		),
		'switch_label_font_weight'        => array(
			'desktop' => '600',
		),
		'switch_label_letter_spacing'     => array(
			'desktop' => '0px',
		),
		'switch_label_line_height'        => array(
			'desktop' => '1.2em',
		),
		'switch_label_text_align'         => array(
			'desktop' => 'center',
		),
		'switch_label_text_transform'     => 'none',
		'switch_label_text_wrap'          => 'nowrap',
		'switch_label_color_light'        => '',
		'switch_label_color_dark'         => '',
		// Legacy flat keys (derived / soft-migrate for older FE payloads).
		'switch_label_font_family'        => 'inherit',
		'switch_label_font_family_custom' => '',
		'switch_image_light_url'          => '',
		'switch_image_dark_url'           => '',
		// Opt-in: apply floating switch design CSS vars to placeable toggle module.
		'apply_floating_design_to_module' => 'off',
		// Stacking (documented; keep high but below some admin bars / modals).
		'switch_z_index'                  => '99999',
		// Phase 2: layout/sizing as Divi coarse breakpoint maps (soft-migrate flat → desktop).
		'switch_position'                 => array(
			'desktop' => 'bottom_right',
		),
		// Floating switch design (aligned with style.scss defaults).
		'switch_size'                     => array(
			'desktop' => '48px',
		),
		'switch_padding_x'                => array(
			'desktop' => '14px',
		),
		// Nested Divi-like shapes as breakpoint maps (soft-migrate leaf → desktop).
		'switch_border'                   => array(
			'desktop' => array(
				'styles' => array(
					'all' => array(
						'width' => '1px',
						'color' => 'rgba(0, 0, 0, 0.1)',
						'style' => 'solid',
					),
				),
				'radius' => array(
					'sync'        => 'on',
					'topLeft'     => '999px',
					'topRight'    => '999px',
					'bottomRight' => '999px',
					'bottomLeft'  => '999px',
				),
			),
		),
		'switch_box_shadow_light'         => array(
			'desktop' => array(
				'style'      => 'preset1',
				'position'   => 'outer',
				'horizontal' => '0px',
				'vertical'   => '8px',
				'blur'       => '24px',
				'spread'     => '0px',
				'color'      => 'rgba(0, 0, 0, 0.12)',
			),
		),
		'switch_box_shadow_dark'          => array(
			'desktop' => array(
				'style'      => 'preset1',
				'position'   => 'outer',
				'horizontal' => '0px',
				'vertical'   => '8px',
				'blur'       => '24px',
				'spread'     => '0px',
				'color'      => 'rgba(0, 0, 0, 0.28)',
			),
		),
		// Derived flat keys (FE CSS vars / Phase 1 migration).
		'switch_border_width'             => '1px',
		'switch_border_radius'            => '999px',
		'switch_border_color_light'       => 'rgba(0, 0, 0, 0.1)',
		'switch_border_color_dark'        => 'rgba(255, 255, 255, 0.12)',
		'switch_bg_light'                 => '#ffffff',
		'switch_bg_dark'                  => '#2a2a2a',
		'switch_fg_light'                 => '#1a1a1a',
		'switch_fg_dark'                  => '#f5f5f5',
		'switch_accent'                   => '#7eb8ff',
		'switch_track_color'              => 'rgba(127, 127, 127, 0.25)',
		'switch_shadow_light'             => '0 8px 24px rgba(0, 0, 0, 0.12)',
		'switch_shadow_dark'              => '0 8px 24px rgba(0, 0, 0, 0.28)',
		'switch_offset_x'                 => array(
			'desktop' => '20px',
		),
		'switch_offset_y'                 => array(
			'desktop' => '20px',
		),
		'switch_hover_lift'               => 'on',
		// Preference reset UX on floating / module toggles (FE localStorage clear).
		'switch_reset_mode'               => 'both',
		'switch_click_delay_ms'           => '100',
		'switch_long_press_ms'            => '650',
		'display_scope'                   => 'entire_site',
		'display_scope_include_ids'       => '',
		'display_scope_exclude_ids'       => '',
		'image_brightness_enabled'        => 'off',
		'image_brightness'                => '85',
		'custom_dark_css'                 => '',
		'keyboard_shortcut_enabled'       => 'off',
		'keyboard_shortcut'               => 'alt+d',
		// Phase 3: per-token dark overrides (empty = palette-derived remap).
		'gcid_mappings'                   => array(
			'gcid-primary-color'   => '',
			'gcid-secondary-color' => '',
			'gcid-tertiary-color'  => '',
			'gcid-heading-color'   => '',
			'gcid-body-color'      => '',
			'gcid-link-color'      => '',
		),
		// Phase 3: extra custom property → colour pairs for html.dsm-dark.
		'custom_var_mappings'             => array(),
		// Phase 3: opt-in logo / image swap.
		'logo_swap_enabled'               => 'off',
		'logo_light_url'                  => '',
		'logo_dark_url'                   => '',
		'logo_selector'                   => self::DEFAULT_LOGO_SELECTOR,
		// Phase 3: optional auto-dark schedule (site timezone).
		'schedule_enabled'                => 'off',
		'schedule_start'                  => '18:00',
		'schedule_end'                    => '06:00',
		// Phase 3: lightweight scheme-change events (CustomEvent + JS callback hook).
		'analytics_events_enabled'        => 'on',
	);

	/**
	 * Constructor.
	 */
	public function __construct() {
		$GLOBALS['dsm_dark_mode_extension'] = $this;

		/*
		 * Critical FOUC / palette output must run as early as possible in <head>.
		 * Priority PHP_INT_MIN keeps scheme class + logo swap ahead of most theme
		 * CSS and optimizer-injected tags. Do not move these behind wp_enqueue_scripts.
		 */
		add_action( 'wp_head', array( $this, 'print_fouc_bootstrap' ), PHP_INT_MIN );
		add_action( 'wp_head', array( $this, 'print_logo_preload' ), PHP_INT_MIN + 1 );
		add_action( 'wp_head', array( $this, 'print_palette_css' ), PHP_INT_MIN + 2 );
		add_action( 'wp_head', array( $this, 'print_floating_switch_layout_css' ), PHP_INT_MIN + 3 );
		add_action( 'wp_head', array( $this, 'print_floating_switch_design_css' ), PHP_INT_MIN + 4 );
		add_action( 'wp_head', array( $this, 'print_floating_switch_typography_css' ), PHP_INT_MIN + 5 );
		add_action( 'wp_head', array( $this, 'print_image_brightness_css' ), 3 );
		add_action( 'wp_head', array( $this, 'print_custom_dark_css' ), 4 );
		add_action( 'wp_enqueue_scripts', array( $this, 'maybe_enqueue_frontend_assets' ), 20 );
		add_action(
			'divi_visual_builder_rest_save_post',
			array( $this, 'save_page_settings_from_rest' ),
			10,
			2
		);
	}

	/**
	 * Default settings shape.
	 *
	 * @return array<string, mixed>
	 */
	public function get_default_settings(): array {
		return $this->default_settings;
	}

	/**
	 * Normalize a stored yes/no flag to `on` or `off`.
	 *
	 * @param mixed $value Raw flag from the option or REST payload.
	 * @return string
	 */
	private function sanitize_on_off_flag( $value ): string {
		if ( true === $value || 1 === $value || '1' === $value ) {
			return 'on';
		}

		if ( is_string( $value ) ) {
			$normalized = strtolower( trim( $value ) );
			if ( in_array( $normalized, array( 'on', 'true', 'yes' ), true ) ) {
				return 'on';
			}
		}

		return 'off';
	}

	/**
	 * Site-wide Enable Dark Mode flag.
	 *
	 * A missing key on a previously saved option stays `on` so layouts that
	 * already used Dark Mode keep working. An empty option (never saved) stays
	 * `off`. `PAGE_META_KEY` is not this gate; it only applies when display
	 * scope is `per_page`.
	 *
	 * @param array<string, mixed> $saved Raw `dsm_dark_mode_settings` value.
	 * @return string `on` or `off`.
	 */
	private function resolve_saved_is_enabled( array $saved ): string {
		if ( array_key_exists( 'is_enabled', $saved ) ) {
			$flag = $this->sanitize_on_off_flag( $saved['is_enabled'] );
		} elseif ( array() !== $saved ) {
			$flag = 'on';
		} else {
			$flag = 'off';
		}

		/**
		 * Filter the site-wide Dark Mode enable flag.
		 *
		 * @param string               $flag  `on` or `off`.
		 * @param array<string, mixed> $saved Raw saved settings.
		 */
		$flag = $this->sanitize_on_off_flag( apply_filters( 'dsm_dark_mode_is_enabled', $flag, $saved ) );

		return $flag;
	}

	/**
	 * Get settings.
	 *
	 * @return array<string, mixed>
	 */
	public function get_settings(): array {
		$saved = get_option( self::OPTION_KEY, array() );

		if ( ! is_array( $saved ) ) {
			$saved = array();
		}

		$is_enabled = $this->resolve_saved_is_enabled( $saved );

		// Soft-migrate Phase 1 flat keys on the raw option *before* defaults fill
		// nested shapes (otherwise defaults would mask custom flat values).
		$saved = $this->migrate_floating_switch_design_settings( $saved );
		// Phase 2: flat layout / palette strings → `{ desktop: string }` maps.
		$saved = $this->migrate_responsive_layout_settings( $saved );
		$saved = $this->migrate_responsive_palette_settings( $saved );
		$saved = $this->migrate_responsive_label_typography_settings( $saved );

		$settings = wp_parse_args( $saved, $this->default_settings );
		$settings = $this->migrate_responsive_layout_settings( $settings );
		$settings = $this->migrate_responsive_palette_settings( $settings );
		$settings = $this->migrate_responsive_label_typography_settings( $settings );

		$default_gcid              = $this->default_settings['gcid_mappings'];
		$saved_gcid                = isset( $saved['gcid_mappings'] ) && is_array( $saved['gcid_mappings'] )
			? $saved['gcid_mappings']
			: array();
		$settings['gcid_mappings'] = wp_parse_args( $saved_gcid, $default_gcid );

		if ( ! is_array( $settings['custom_var_mappings'] ?? null ) ) {
			$settings['custom_var_mappings'] = array();
		}

		// Soft-migrate legacy bare unicode strings → IconPicker leaf objects.
		$settings['switch_icon_light'] = $this->sanitize_icon_value( $settings['switch_icon_light'] ?? '' );
		$settings['switch_icon_dark']  = $this->sanitize_icon_value( $settings['switch_icon_dark'] ?? '' );

		$settings               = $this->sync_floating_switch_flat_design_keys( $settings );
		$settings['is_enabled'] = $is_enabled;

		return $settings;
	}

	/**
	 * Save settings.
	 *
	 * @param array<string, mixed> $settings Raw settings from REST/modal.
	 * @return bool
	 */
	public function save_settings( array $settings ): bool {
		$existing = get_option( self::OPTION_KEY, array() );

		if ( ! is_array( $existing ) ) {
			$existing = array();
		}

		$merged = wp_parse_args( $settings, wp_parse_args( $existing, $this->default_settings ) );

		if ( array_key_exists( 'is_enabled', $settings ) ) {
			$merged['is_enabled'] = $this->sanitize_on_off_flag( $settings['is_enabled'] );
		} else {
			$merged['is_enabled'] = $this->resolve_saved_is_enabled( $existing );
		}

		$merged['default_mode'] = $this->sanitize_default_mode( (string) ( $merged['default_mode'] ?? 'system' ) );
		$merged                 = $this->migrate_responsive_palette_settings( $merged );
		$palette_schemas        = $this->get_responsive_palette_schema_defaults();
		foreach ( $this->get_responsive_palette_keys() as $palette_key ) {
			$merged[ $palette_key ] = $this->sanitize_responsive_color_map(
				$merged[ $palette_key ] ?? array(),
				$palette_schemas[ $palette_key ] ?? ''
			);
		}
		$merged['show_floating_switch']            = 'on' === ( $merged['show_floating_switch'] ?? 'off' ) ? 'on' : 'off';
		$merged['switch_style']                    = $this->sanitize_switch_style( (string) ( $merged['switch_style'] ?? 'pill' ) );
		$merged['switch_content_mode']             = $this->sanitize_switch_content_mode( (string) ( $merged['switch_content_mode'] ?? 'default' ) );
		$merged['switch_icon_light']               = $this->sanitize_icon_value( $merged['switch_icon_light'] ?? '' );
		$merged['switch_icon_dark']                = $this->sanitize_icon_value( $merged['switch_icon_dark'] ?? '' );
		$merged['switch_icon_color_light']         = $this->sanitize_color( (string) ( $merged['switch_icon_color_light'] ?? '' ), '' );
		$merged['switch_icon_color_dark']          = $this->sanitize_color( (string) ( $merged['switch_icon_color_dark'] ?? '' ), '' );
		$merged['switch_icon_size']                = $this->sanitize_optional_css_length( (string) ( $merged['switch_icon_size'] ?? '' ) );
		$merged['switch_label_light']              = sanitize_text_field( (string) ( $merged['switch_label_light'] ?? 'Light' ) );
		$merged['switch_label_dark']               = sanitize_text_field( (string) ( $merged['switch_label_dark'] ?? 'Dark' ) );
		$merged                                    = $this->migrate_responsive_label_typography_settings( $merged );
		$merged                                    = $this->migrate_and_sanitize_switch_label_font( $merged );
		$merged['switch_image_light_url']          = $this->sanitize_url( $this->normalize_logo_url_value( $merged['switch_image_light_url'] ?? '' ) );
		$merged['switch_image_dark_url']           = $this->sanitize_url( $this->normalize_logo_url_value( $merged['switch_image_dark_url'] ?? '' ) );
		$merged['apply_floating_design_to_module'] = 'on' === ( $merged['apply_floating_design_to_module'] ?? 'off' ) ? 'on' : 'off';
		$merged['switch_z_index']                  = $this->sanitize_z_index( (string) ( $merged['switch_z_index'] ?? '99999' ), '99999' );
		$merged                                    = $this->migrate_responsive_layout_settings( $merged );
		$merged['switch_position']                 = $this->sanitize_responsive_select_map(
			$merged['switch_position'] ?? array(),
			array( 'bottom_right', 'bottom_left', 'top_right', 'top_left' ),
			'bottom_right'
		);
		$merged['switch_size']                     = $this->sanitize_responsive_length_map(
			$merged['switch_size'] ?? array(),
			'48px'
		);
		$merged['switch_padding_x']                = $this->sanitize_responsive_length_map(
			$merged['switch_padding_x'] ?? array(),
			'14px'
		);
		$merged['switch_offset_x']                 = $this->sanitize_responsive_length_map(
			$merged['switch_offset_x'] ?? array(),
			'20px'
		);
		$merged['switch_offset_y']                 = $this->sanitize_responsive_length_map(
			$merged['switch_offset_y'] ?? array(),
			'20px'
		);
		$merged['switch_bg_light']                 = $this->sanitize_color( (string) ( $merged['switch_bg_light'] ?? '' ), $this->default_settings['switch_bg_light'] );
		$merged['switch_bg_dark']                  = $this->sanitize_color( (string) ( $merged['switch_bg_dark'] ?? '' ), $this->default_settings['switch_bg_dark'] );
		$merged['switch_fg_light']                 = $this->sanitize_color( (string) ( $merged['switch_fg_light'] ?? '' ), $this->default_settings['switch_fg_light'] );
		$merged['switch_fg_dark']                  = $this->sanitize_color( (string) ( $merged['switch_fg_dark'] ?? '' ), $this->default_settings['switch_fg_dark'] );
		$merged['switch_accent']                   = $this->sanitize_color( (string) ( $merged['switch_accent'] ?? '' ), $this->default_settings['switch_accent'] );
		$merged['switch_track_color']              = $this->sanitize_color( (string) ( $merged['switch_track_color'] ?? '' ), $this->default_settings['switch_track_color'] );
		$merged['switch_border_color_dark']        = $this->sanitize_color( (string) ( $merged['switch_border_color_dark'] ?? '' ), $this->default_settings['switch_border_color_dark'] );
		$merged['switch_hover_lift']               = 'on' === ( $merged['switch_hover_lift'] ?? 'on' ) ? 'on' : 'off';
		$merged['switch_reset_mode']               = $this->sanitize_switch_reset_mode( (string) ( $merged['switch_reset_mode'] ?? 'both' ) );
		$merged['switch_click_delay_ms']           = $this->sanitize_int_range( (string) ( $merged['switch_click_delay_ms'] ?? '100' ), 0, 800, 100 );
		$merged['switch_long_press_ms']            = $this->sanitize_int_range( (string) ( $merged['switch_long_press_ms'] ?? '650' ), 300, 2000, 650 );

		// Nested border / box-shadow maps → sanitize + sync derived flat CSS keys.
		$merged                              = $this->migrate_floating_switch_design_settings( $merged );
		$default_border_leaf                 = isset( $this->default_settings['switch_border']['desktop'] ) && is_array( $this->default_settings['switch_border']['desktop'] )
			? $this->default_settings['switch_border']['desktop']
			: array();
		$default_shadow_light                = isset( $this->default_settings['switch_box_shadow_light']['desktop'] ) && is_array( $this->default_settings['switch_box_shadow_light']['desktop'] )
			? $this->default_settings['switch_box_shadow_light']['desktop']
			: array();
		$default_shadow_dark                 = isset( $this->default_settings['switch_box_shadow_dark']['desktop'] ) && is_array( $this->default_settings['switch_box_shadow_dark']['desktop'] )
			? $this->default_settings['switch_box_shadow_dark']['desktop']
			: array();
		$merged['switch_border']             = $this->migrate_switch_border_to_map(
			$merged['switch_border'] ?? array(),
			$default_border_leaf
		);
		$merged['switch_box_shadow_light']   = $this->migrate_switch_box_shadow_to_map(
			$merged['switch_box_shadow_light'] ?? array(),
			$default_shadow_light
		);
		$merged['switch_box_shadow_dark']    = $this->migrate_switch_box_shadow_to_map(
			$merged['switch_box_shadow_dark'] ?? array(),
			$default_shadow_dark
		);
		$merged                              = $this->sync_floating_switch_flat_design_keys( $merged );
		$merged['display_scope']             = $this->sanitize_scope( (string) ( $merged['display_scope'] ?? 'entire_site' ) );
		$merged['display_scope_include_ids'] = $this->sanitize_page_ids( (string) ( $merged['display_scope_include_ids'] ?? '' ) );
		$merged['display_scope_exclude_ids'] = $this->sanitize_page_ids( (string) ( $merged['display_scope_exclude_ids'] ?? '' ) );
		$merged['module_surface_mode']       = $this->sanitize_module_surface_mode( (string) ( $merged['module_surface_mode'] ?? 'painted' ) );
		$merged['image_brightness_enabled']  = 'on' === ( $merged['image_brightness_enabled'] ?? 'off' ) ? 'on' : 'off';
		$merged['image_brightness']          = $this->sanitize_image_brightness( (string) ( $merged['image_brightness'] ?? '85' ) );
		$merged['custom_dark_css']           = $this->sanitize_custom_css( (string) ( $merged['custom_dark_css'] ?? '' ) );
		$merged['keyboard_shortcut_enabled'] = 'on' === ( $merged['keyboard_shortcut_enabled'] ?? 'off' ) ? 'on' : 'off';
		$merged['keyboard_shortcut']         = $this->sanitize_keyboard_shortcut( (string) ( $merged['keyboard_shortcut'] ?? 'alt+d' ) );
		// Global colour overrides + custom CSS variables UIs removed: when keys are
		// absent from the payload (full-settings replace), preserve previously saved
		// mappings so FE remaps / overrides keep working.
		if ( array_key_exists( 'gcid_mappings', $settings ) ) {
			$merged['gcid_mappings'] = $this->sanitize_gcid_mappings( $settings['gcid_mappings'] );
		} else {
			$merged['gcid_mappings'] = $this->sanitize_gcid_mappings(
				is_array( $existing['gcid_mappings'] ?? null )
					? $existing['gcid_mappings']
					: ( $this->default_settings['gcid_mappings'] ?? array() )
			);
		}
		if ( array_key_exists( 'custom_var_mappings', $settings ) ) {
			$merged['custom_var_mappings'] = $this->sanitize_custom_var_mappings( $settings['custom_var_mappings'] );
		} else {
			$merged['custom_var_mappings'] = $this->sanitize_custom_var_mappings(
				is_array( $existing['custom_var_mappings'] ?? null )
					? $existing['custom_var_mappings']
					: array()
			);
		}
		$merged['logo_swap_enabled']        = 'on' === ( $merged['logo_swap_enabled'] ?? 'off' ) ? 'on' : 'off';
		$merged['logo_light_url']           = $this->sanitize_url( $this->normalize_logo_url_value( $merged['logo_light_url'] ?? '' ) );
		$merged['logo_dark_url']            = $this->sanitize_url( $this->normalize_logo_url_value( $merged['logo_dark_url'] ?? '' ) );
		$merged['logo_selector']            = $this->sanitize_css_selector(
			(string) ( $merged['logo_selector'] ?? self::DEFAULT_LOGO_SELECTOR ),
			self::DEFAULT_LOGO_SELECTOR
		);
		$merged['schedule_enabled']         = 'on' === ( $merged['schedule_enabled'] ?? 'off' ) ? 'on' : 'off';
		$merged['schedule_start']           = $this->sanitize_time_hhmm( (string) ( $merged['schedule_start'] ?? '18:00' ), '18:00' );
		$merged['schedule_end']             = $this->sanitize_time_hhmm( (string) ( $merged['schedule_end'] ?? '06:00' ), '06:00' );
		$merged['analytics_events_enabled'] = 'on' === ( $merged['analytics_events_enabled'] ?? 'on' ) ? 'on' : 'off';

		update_option( self::OPTION_KEY, $merged );

		/**
		 * Fires after Dark Mode global settings are saved.
		 *
		 * @param array<string, mixed> $merged Sanitized settings.
		 */
		do_action( 'dsm_dark_mode_settings_saved', $merged );

		return true;
	}

	/**
	 * Sanitize default mode.
	 *
	 * @param string $mode Default mode slug.
	 * @return string
	 */
	private function sanitize_default_mode( string $mode ): string {
		$allowed = array( 'system', 'light', 'dark' );
		$mode    = sanitize_key( $mode );

		return in_array( $mode, $allowed, true ) ? $mode : 'system';
	}

	/**
	 * Sanitize switch style.
	 *
	 * @param string $style Switch style slug.
	 * @return string
	 */
	private function sanitize_switch_style( string $style ): string {
		$allowed = array( 'pill', 'icon', 'switch' );
		$style   = sanitize_key( $style );

		return in_array( $style, $allowed, true ) ? $style : 'pill';
	}

	/**
	 * Sanitize Apply Surface to mode.
	 *
	 * @param string $mode Mode slug (none / painted / cards / content).
	 * @return string
	 */
	private function sanitize_module_surface_mode( string $mode ): string {
		$allowed = array( 'none', 'painted', 'cards', 'content' );
		$mode    = sanitize_key( $mode );

		return in_array( $mode, $allowed, true ) ? $mode : 'painted';
	}

	/**
	 * Current Apply Surface to mode (none / painted / cards / content).
	 *
	 * @return string
	 */
	public function get_module_surface_mode(): string {
		$settings = $this->get_settings();

		return $this->sanitize_module_surface_mode( (string) ( $settings['module_surface_mode'] ?? 'painted' ) );
	}

	/**
	 * Sanitize switch content mode.
	 *
	 * @param string $mode Content mode slug.
	 * @return string
	 */
	private function sanitize_switch_content_mode( string $mode ): string {
		$allowed = array( 'default', 'icon', 'text', 'icon_text', 'image' );
		$mode    = sanitize_key( $mode );

		return in_array( $mode, $allowed, true ) ? $mode : 'default';
	}

	/**
	 * Whether a stored icon unicode / id is within the allowed length.
	 *
	 * Divi/FA HTML entities stay short; DSM webfont ids (e.g. Lucide
	 * `align-horizontal-distribute-center`) are longer slugs.
	 *
	 * @param string $unicode Unicode entity or library icon id.
	 * @param string $type    Icon picker type.
	 * @return bool
	 */
	private function is_allowed_icon_unicode( string $unicode, string $type ): bool {
		if ( '' === $unicode ) {
			return false;
		}

		$max = 32;
		if ( ! in_array( $type, array( 'divi', 'fa' ), true ) && ! str_starts_with( $unicode, '&' ) ) {
			$max = 80;
		}

		return strlen( $unicode ) <= $max;
	}

	/**
	 * Sanitize Divi IconPicker value.
	 *
	 * Keeps the IconPicker leaf shape `{ unicode, type, weight }` so VB can run
	 * `processFontIcon` and FE can resolve font family (Divi vs FA). Legacy bare
	 * unicode strings are promoted to a minimal divi object. DSM webfont icon
	 * ids (Lucide slugs) may exceed the HTML-entity length cap.
	 *
	 * @param mixed $raw Raw icon value.
	 * @return array<string, string>|string Empty string when unset; otherwise icon leaf.
	 */
	private function sanitize_icon_value( $raw ) {
		if ( is_string( $raw ) ) {
			$unicode = trim( wp_strip_all_tags( $raw ) );
			if ( '' === $unicode || ! $this->is_allowed_icon_unicode( $unicode, 'divi' ) ) {
				return '';
			}

			return array(
				'unicode' => $unicode,
				'type'    => 'divi',
				'weight'  => '400',
			);
		}

		if ( ! is_array( $raw ) ) {
			return '';
		}

		$unicode = '';
		if ( isset( $raw['unicode'] ) && is_string( $raw['unicode'] ) ) {
			$unicode = trim( wp_strip_all_tags( $raw['unicode'] ) );
		} elseif ( isset( $raw['value'] ) && is_string( $raw['value'] ) ) {
			$unicode = trim( wp_strip_all_tags( $raw['value'] ) );
		}

		$type = isset( $raw['type'] ) ? sanitize_key( (string) $raw['type'] ) : 'divi';
		if ( '' === $type ) {
			$type = 'divi';
		}

		if ( '' === $unicode || ! $this->is_allowed_icon_unicode( $unicode, $type ) ) {
			return '';
		}

		$weight = isset( $raw['weight'] ) ? sanitize_text_field( (string) $raw['weight'] ) : '400';
		if ( ! preg_match( '/^(?:[1-9]00|normal|bold)$/', $weight ) ) {
			$weight = '400';
		}

		$icon = array(
			'unicode' => $unicode,
			'type'    => $type,
			'weight'  => $weight,
		);

		if ( isset( $raw['variant'] ) && is_string( $raw['variant'] ) && '' !== $raw['variant'] ) {
			$icon['variant'] = sanitize_key( $raw['variant'] );
		}

		return $icon;
	}

	/**
	 * Prepare a switch icon for FE JS (native glyph or DSM webfont payload).
	 *
	 * Native Divi/FA: `process_font_icon` yields the single character that
	 * `.et-pb-icon` expects as text content. DSM webfont libraries store an
	 * icon id in `unicode` — never dump that through ETmodules.
	 *
	 * @param mixed $raw Stored icon value.
	 * @return array<string, string>|string Empty string when unset.
	 */
	private function prepare_switch_icon_for_frontend( $raw ) {
		$icon = $this->sanitize_icon_value( $raw );
		if ( ! is_array( $icon ) || '' === ( $icon['unicode'] ?? '' ) ) {
			return '';
		}

		if (
			class_exists( IconLibraryRegistry::class )
			&& IconLibraryRegistry::is_dsm_library_icon( $icon )
		) {
			$font_class = '';
			if ( class_exists( IconGlyphRenderer::class ) ) {
				$font_class = IconGlyphRenderer::get_font_class_for_icon( $icon );
			}

			$payload = array(
				'render'    => 'webfont',
				'type'      => (string) ( $icon['type'] ?? '' ),
				'unicode'   => (string) ( $icon['unicode'] ?? '' ),
				'fontClass' => $font_class,
			);

			if ( isset( $icon['variant'] ) && is_string( $icon['variant'] ) && '' !== $icon['variant'] ) {
				$payload['variant'] = $icon['variant'];
			}

			if ( isset( $icon['weight'] ) && is_string( $icon['weight'] ) && '' !== $icon['weight'] ) {
				$payload['weight'] = $icon['weight'];
			}

			return $payload;
		}

		$glyph = '';
		if ( class_exists( DsmDarkModeIconFontUtils::class ) ) {
			try {
				$processed = DsmDarkModeIconFontUtils::process_font_icon( $icon );
				if ( is_string( $processed ) && '' !== $processed ) {
					$glyph = $processed;
				}
			} catch ( \Throwable $e ) { // phpcs:ignore Generic.CodeAnalysis.EmptyStatement.DetectedCatch -- optional Divi API.
				$glyph = '';
			}
		}

		if ( '' === $glyph ) {
			$unicode_raw = (string) ( $icon['unicode'] ?? '' );
			$type        = (string) ( $icon['type'] ?? 'divi' );
			if ( in_array( $type, array( 'divi', 'fa' ), true ) || str_starts_with( $unicode_raw, '&' ) ) {
				$glyph = html_entity_decode( $unicode_raw, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
			}
		}

		if ( '' === $glyph ) {
			return '';
		}

		$type = (string) ( $icon['type'] ?? 'divi' );

		return array(
			'glyph'  => $glyph,
			'type'   => $type,
			'weight' => (string) ( $icon['weight'] ?? '400' ),
		);
	}

	/**
	 * Enqueue webfont CSS for floating-switch custom icons (stored in options).
	 *
	 * @param array<string, mixed> $settings Settings snapshot.
	 * @return void
	 */
	private function enqueue_switch_webfont_assets( array $settings ): void {
		if ( ! class_exists( WebfontAssetLoader::class ) ) {
			return;
		}

		$icons = array();
		foreach ( array( 'switch_icon_light', 'switch_icon_dark' ) as $key ) {
			$icon = $this->sanitize_icon_value( $settings[ $key ] ?? '' );
			if (
				is_array( $icon )
				&& class_exists( IconLibraryRegistry::class )
				&& IconLibraryRegistry::is_dsm_library_icon( $icon )
			) {
				$cache_key           = sanitize_key( (string) ( $icon['type'] ?? '' ) ) . ':' . sanitize_key( (string) ( $icon['unicode'] ?? '' ) );
				$icons[ $cache_key ] = $icon;
			}
		}

		if ( array() === $icons ) {
			return;
		}

		WebfontAssetLoader::enqueue_for_icons( $icons );

		if ( wp_style_is( 'dsm-icon-libraries-frontend', 'registered' ) ) {
			wp_enqueue_style( 'dsm-icon-libraries-frontend' );
		}
	}

	/**
	 * Sanitize font weight.
	 *
	 * @param string $weight   Font weight.
	 * @param string $fallback Fallback.
	 * @return string
	 */
	private function sanitize_font_weight( string $weight, string $fallback ): string {
		$weight = trim( $weight );
		if ( preg_match( '/^(?:[1-9]00|normal|bold)$/', $weight ) ) {
			return $weight;
		}

		return $fallback;
	}

	/**
	 * Sanitize Divi SelectFont / legacy preset family string.
	 *
	 * @param string $family Family name or legacy preset.
	 * @return string
	 */
	private function sanitize_label_font_family( string $family ): string {
		$family = trim( sanitize_text_field( $family ) );
		if ( '' === $family || 'Default' === $family ) {
			return '';
		}

		$legacy = array( 'inherit', 'system', 'sans-serif', 'serif', 'monospace', 'custom' );
		if ( in_array( $family, $legacy, true ) ) {
			return $family;
		}

		// Divi face names (e.g. Open Sans); reject CSS injection.
		if ( preg_match( '/url\s*\(|expression\s*\(|@import|<|>|\{|\}|;/i', $family ) ) {
			return '';
		}

		if ( ! preg_match( '/^[\w\s\-\'",.]+$/u', $family ) ) {
			return '';
		}

		if ( strlen( $family ) > 120 ) {
			return substr( $family, 0, 120 );
		}

		return $family;
	}

	/**
	 * Sanitize custom CSS font-family string (no URL()/expression; does not enqueue fonts).
	 *
	 * @param string $value Raw custom family.
	 * @return string
	 */
	private function sanitize_label_font_family_custom( string $value ): string {
		$value = sanitize_text_field( $value );
		$value = trim( $value );

		if ( '' === $value ) {
			return '';
		}

		// Reject CSS functions / injection; allow quotes, commas, spaces for stacks.
		if ( preg_match( '/url\s*\(|expression\s*\(|@import|<|>|\{|\}|;/i', $value ) ) {
			return '';
		}

		if ( ! preg_match( '/^[\w\s\-\'",.]+$/u', $value ) ) {
			return '';
		}

		if ( strlen( $value ) > 120 ) {
			return substr( $value, 0, 120 );
		}

		return $value;
	}

	/**
	 * Sanitize label text-transform CSS keyword.
	 *
	 * @param string $transform Transform slug.
	 * @return string
	 */
	private function sanitize_label_text_transform( string $transform ): string {
		$transform = trim( strtolower( $transform ) );
		$allowed   = array( 'none', 'uppercase', 'lowercase', 'capitalize' );

		return in_array( $transform, $allowed, true ) ? $transform : 'none';
	}

	/**
	 * Sanitize Divi font style flags array.
	 *
	 * @param mixed $style Raw style list.
	 * @return list<string>
	 */
	private function sanitize_label_font_style( $style ): array {
		if ( ! is_array( $style ) ) {
			return array();
		}
		// Decoration (current) + legacy case flags still accepted for soft-migrate.
		$allowed = array(
			'italic',
			'underline',
			'overline',
			'strikethrough',
			'uppercase',
			'capitalize',
		);
		$out     = array();
		foreach ( $style as $flag ) {
			if ( ! is_string( $flag ) ) {
				continue;
			}
			$flag = sanitize_key( $flag );
			if ( in_array( $flag, $allowed, true ) && ! in_array( $flag, $out, true ) ) {
				$out[] = $flag;
			}
		}

		return $out;
	}

	/**
	 * Decoration-only style flags (Divi FontGroup `style`).
	 *
	 * @param array $style Raw/sanitized style flags.
	 * @return list<string>
	 */
	private function normalize_label_font_decoration_style( array $style ): array {
		$allowed = array( 'italic', 'underline', 'overline', 'strikethrough' );
		$out     = array();
		foreach ( $style as $flag ) {
			if ( is_string( $flag ) && in_array( $flag, $allowed, true ) && ! in_array( $flag, $out, true ) ) {
				$out[] = $flag;
			}
		}

		return $out;
	}

	/**
	 * Sanitize Divi FontGroup capitalization leaf.
	 *
	 * @param string $capitalization Raw.
	 * @return string
	 */
	private function sanitize_label_capitalization( string $capitalization ): string {
		$allowed = array( 'uppercase', 'lowercase', 'capitalize', 'smallCaps', 'allSmallCaps' );

		return in_array( $capitalization, $allowed, true ) ? $capitalization : '';
	}

	/**
	 * Soft-migrate style case flags + flat transform → capitalization.
	 *
	 * @param array  $style              Style flags.
	 * @param string $legacy_transform   Flat transform.
	 * @param string $raw_capitalization Existing capitalization leaf.
	 * @return string
	 */
	private function resolve_label_capitalization( array $style, string $legacy_transform, string $raw_capitalization ): string {
		$existing = $this->sanitize_label_capitalization( $raw_capitalization );
		if ( '' !== $existing ) {
			return $existing;
		}
		if ( in_array( 'uppercase', $style, true ) ) {
			return 'uppercase';
		}
		if ( in_array( 'capitalize', $style, true ) ) {
			return 'capitalize';
		}
		$legacy = $this->sanitize_label_text_transform( $legacy_transform );
		if ( in_array( $legacy, array( 'uppercase', 'lowercase', 'capitalize' ), true ) ) {
			return $legacy;
		}

		return '';
	}

	/**
	 * Map capitalization → CSS text-transform (flat key sync).
	 *
	 * @param string $capitalization Capitalization slug.
	 * @return string
	 */
	private function capitalization_to_text_transform( string $capitalization ): string {
		$cap = $this->sanitize_label_capitalization( $capitalization );
		if ( in_array( $cap, array( 'uppercase', 'lowercase', 'capitalize' ), true ) ) {
			return $cap;
		}

		return 'none';
	}

	/**
	 * Responsive label typography map keys.
	 *
	 * @return array<int, string>
	 */
	private function get_responsive_label_typography_keys(): array {
		return array(
			'switch_label_font_size',
			'switch_label_letter_spacing',
			'switch_label_line_height',
			'switch_label_font_weight',
			'switch_label_text_align',
		);
	}

	/**
	 * Desktop schema defaults for label typography maps.
	 *
	 * @return array<string, string>
	 */
	private function get_responsive_label_typography_schema_defaults(): array {
		return array(
			'switch_label_font_size'      => '13px',
			'switch_label_letter_spacing' => '0px',
			'switch_label_line_height'    => '1.2em',
			'switch_label_font_weight'    => '600',
			'switch_label_text_align'     => 'center',
		);
	}

	/**
	 * Sanitize line-height (unitless or with unit).
	 *
	 * @param string $value    Raw.
	 * @param string $fallback Fallback.
	 * @return string
	 */
	private function sanitize_line_height( string $value, string $fallback ): string {
		$value = trim( sanitize_text_field( $value ) );
		if ( '' === $value ) {
			return $fallback;
		}
		if ( preg_match( '/^-?\d+(\.\d+)?(px|em|rem|%)?$/i', $value ) ) {
			return $value;
		}

		return $fallback;
	}

	/**
	 * Sanitize label text-align.
	 *
	 * @param string $align Raw.
	 * @return string
	 */
	private function sanitize_label_text_align( string $align ): string {
		$align   = sanitize_key( $align );
		$allowed = array( 'left', 'center', 'right', 'justify' );

		return in_array( $align, $allowed, true ) ? $align : 'center';
	}

	/**
	 * Sanitize label text-wrap.
	 *
	 * @param string $wrap Raw.
	 * @return string
	 */
	private function sanitize_label_text_wrap( string $wrap ): string {
		$wrap    = sanitize_key( $wrap );
		$allowed = array( 'nowrap', 'wrap', 'balance', 'pretty' );

		return in_array( $wrap, $allowed, true ) ? $wrap : 'nowrap';
	}

	/**
	 * Soft-migrate flat label typography strings → breakpoint maps.
	 *
	 * Prefers desktop values already on `switch_label_font` when maps are empty.
	 *
	 * @param array<string, mixed> $settings Settings.
	 * @return array<string, mixed>
	 */
	private function migrate_responsive_label_typography_settings( array $settings ): array {
		$schemas = $this->get_responsive_label_typography_schema_defaults();
		$font    = is_array( $settings['switch_label_font'] ?? null )
			? $settings['switch_label_font']
			: array();

		$from_font = array(
			'switch_label_font_size'      => (string) ( $font['size'] ?? $schemas['switch_label_font_size'] ),
			'switch_label_letter_spacing' => (string) ( $font['letterSpacing'] ?? $schemas['switch_label_letter_spacing'] ),
			'switch_label_line_height'    => (string) ( $font['lineHeight'] ?? $schemas['switch_label_line_height'] ),
			'switch_label_font_weight'    => (string) ( $font['weight'] ?? $schemas['switch_label_font_weight'] ),
			'switch_label_text_align'     => (string) ( $font['textAlign'] ?? $schemas['switch_label_text_align'] ),
		);

		foreach ( $this->get_responsive_label_typography_keys() as $key ) {
			$schema = $from_font[ $key ] ?? ( $schemas[ $key ] ?? '' );
			$raw    = $settings[ $key ] ?? null;

			if ( is_string( $raw ) || is_numeric( $raw ) ) {
				$settings[ $key ] = array(
					'desktop' => (string) $raw,
				);
				continue;
			}

			if ( ! is_array( $raw ) ) {
				$settings[ $key ] = array(
					'desktop' => $schema,
				);
				continue;
			}

			$breakpoint_keys = array( 'desktop', 'tablet', 'tabletWide', 'phone', 'phoneWide' );
			$has_bp          = false;
			foreach ( $breakpoint_keys as $bp ) {
				if ( array_key_exists( $bp, $raw ) ) {
					$has_bp = true;
					break;
				}
			}

			if ( $has_bp ) {
				if ( ! isset( $raw['desktop'] ) ) {
					$raw['desktop'] = $schema;
				}
				$settings[ $key ] = $raw;
				continue;
			}

			if ( isset( $raw['value'] ) ) {
				$settings[ $key ] = array(
					'desktop' => $this->normalize_range_length_leaf( $raw, $schema ),
				);
				continue;
			}

			$settings[ $key ] = array(
				'desktop' => $schema,
			);
		}

		return $settings;
	}

	/**
	 * Soft-migrate flat label font keys → Divi-like object; sanitize maps + object.
	 *
	 * @param array<string, mixed> $merged Settings.
	 * @return array<string, mixed>
	 */
	private function migrate_and_sanitize_switch_label_font( array $merged ): array {
		$schemas = $this->get_responsive_label_typography_schema_defaults();
		$merged  = $this->migrate_responsive_label_typography_settings( $merged );

		$raw = $merged['switch_label_font'] ?? null;
		if ( is_array( $raw ) ) {
			$family         = $this->sanitize_label_font_family( (string) ( $raw['family'] ?? '' ) );
			$weight         = $this->sanitize_font_weight( (string) ( $raw['weight'] ?? '600' ), '600' );
			$size           = $this->sanitize_css_length( (string) ( $raw['size'] ?? '13px' ), '13px' );
			$letter         = $this->sanitize_css_length( (string) ( $raw['letterSpacing'] ?? '0px' ), '0px' );
			$line_height    = $this->sanitize_line_height( (string) ( $raw['lineHeight'] ?? '1.2em' ), '1.2em' );
			$text_align     = $this->sanitize_label_text_align( (string) ( $raw['textAlign'] ?? 'center' ) );
			$text_wrap      = $this->sanitize_label_text_wrap(
				(string) ( $raw['textWrap'] ?? ( $merged['switch_label_text_wrap'] ?? 'nowrap' ) )
			);
			$raw_style      = $this->sanitize_label_font_style( $raw['style'] ?? array() );
			$legacy_tf      = $this->sanitize_label_text_transform(
				(string) ( $merged['switch_label_text_transform'] ?? 'none' )
			);
			$capitalization = $this->resolve_label_capitalization(
				$raw_style,
				$legacy_tf,
				(string) ( $raw['capitalization'] ?? '' )
			);
			$style          = $this->normalize_label_font_decoration_style( $raw_style );

			$font = array(
				'family'         => $family,
				'weight'         => $weight,
				'size'           => $size,
				'letterSpacing'  => $letter,
				'lineHeight'     => $line_height,
				'textAlign'      => $text_align,
				'textWrap'       => $text_wrap,
				'capitalization' => $capitalization,
				'style'          => $style,
			);
		} else {
			$preset = $this->sanitize_label_font_family(
				(string) ( $merged['switch_label_font_family'] ?? 'inherit' )
			);
			$custom = $this->sanitize_label_font_family_custom(
				(string) ( $merged['switch_label_font_family_custom'] ?? '' )
			);
			$family = '';
			if ( 'custom' === $preset && '' !== $custom ) {
				$family = $custom;
			} elseif ( '' !== $preset && 'inherit' !== $preset ) {
				$family = $preset;
			}

			$legacy_tf      = $this->sanitize_label_text_transform(
				(string) ( $merged['switch_label_text_transform'] ?? 'none' )
			);
			$capitalization = $this->resolve_label_capitalization( array(), $legacy_tf, '' );

			$size_map   = is_array( $merged['switch_label_font_size'] ?? null )
				? $merged['switch_label_font_size']
				: array( 'desktop' => (string) ( $merged['switch_label_font_size'] ?? '13px' ) );
			$weight_map = is_array( $merged['switch_label_font_weight'] ?? null )
				? $merged['switch_label_font_weight']
				: array( 'desktop' => (string) ( $merged['switch_label_font_weight'] ?? '600' ) );
			$letter_map = is_array( $merged['switch_label_letter_spacing'] ?? null )
				? $merged['switch_label_letter_spacing']
				: array( 'desktop' => (string) ( $merged['switch_label_letter_spacing'] ?? '0px' ) );

			$font = array(
				'family'         => $family,
				'weight'         => $this->sanitize_font_weight(
					(string) ( $weight_map['desktop'] ?? '600' ),
					'600'
				),
				'size'           => $this->sanitize_css_length(
					(string) ( $size_map['desktop'] ?? '13px' ),
					'13px'
				),
				'letterSpacing'  => $this->sanitize_css_length(
					(string) ( $letter_map['desktop'] ?? '0px' ),
					'0px'
				),
				'lineHeight'     => '1.2em',
				'textAlign'      => 'center',
				'textWrap'       => $this->sanitize_label_text_wrap(
					(string) ( $merged['switch_label_text_wrap'] ?? 'nowrap' )
				),
				'capitalization' => $capitalization,
				'style'          => array(),
			);
		}

		$merged['switch_label_font_size']      = $this->sanitize_responsive_length_map(
			$merged['switch_label_font_size'] ?? array( 'desktop' => $font['size'] ),
			$schemas['switch_label_font_size']
		);
		$merged['switch_label_letter_spacing'] = $this->sanitize_responsive_length_map(
			$merged['switch_label_letter_spacing'] ?? array( 'desktop' => $font['letterSpacing'] ),
			$schemas['switch_label_letter_spacing']
		);
		$merged['switch_label_line_height']    = $this->sanitize_responsive_line_height_map(
			$merged['switch_label_line_height'] ?? array( 'desktop' => $font['lineHeight'] ),
			$schemas['switch_label_line_height']
		);
		$merged['switch_label_font_weight']    = $this->sanitize_responsive_select_map(
			$merged['switch_label_font_weight'] ?? array( 'desktop' => $font['weight'] ),
			array( '100', '200', '300', '400', '500', '600', '700', '800', '900', 'normal', 'bold' ),
			$schemas['switch_label_font_weight']
		);
		$merged['switch_label_text_align']     = $this->sanitize_responsive_select_map(
			$merged['switch_label_text_align'] ?? array( 'desktop' => $font['textAlign'] ),
			array( 'left', 'center', 'right', 'justify' ),
			$schemas['switch_label_text_align']
		);

		// Sync desktop map leaves into font object snapshot.
		$font['size']           = (string) ( $merged['switch_label_font_size']['desktop'] ?? $font['size'] );
		$font['weight']         = (string) ( $merged['switch_label_font_weight']['desktop'] ?? $font['weight'] );
		$font['letterSpacing']  = (string) ( $merged['switch_label_letter_spacing']['desktop'] ?? $font['letterSpacing'] );
		$font['lineHeight']     = (string) ( $merged['switch_label_line_height']['desktop'] ?? $font['lineHeight'] );
		$font['textAlign']      = $this->sanitize_label_text_align(
			(string) ( $merged['switch_label_text_align']['desktop'] ?? $font['textAlign'] )
		);
		$font['textWrap']       = $this->sanitize_label_text_wrap(
			(string) ( $merged['switch_label_text_wrap'] ?? $font['textWrap'] )
		);
		$font['capitalization'] = $this->sanitize_label_capitalization(
			(string) ( $font['capitalization'] ?? '' )
		);
		$font['style']          = $this->normalize_label_font_decoration_style(
			is_array( $font['style'] ?? null ) ? $font['style'] : array()
		);

		$text_transform = $this->capitalization_to_text_transform( $font['capitalization'] );

		$merged['switch_label_font']               = $font;
		$merged['switch_label_font_family']        = '' !== $font['family'] ? $font['family'] : 'inherit';
		$merged['switch_label_font_family_custom'] = $this->sanitize_label_font_family_custom(
			(string) ( $merged['switch_label_font_family_custom'] ?? '' )
		);
		$merged['switch_label_text_transform']     = $text_transform;
		$merged['switch_label_text_wrap']          = $font['textWrap'];
		$merged['switch_label_color_light']        = $this->sanitize_color(
			(string) ( $merged['switch_label_color_light'] ?? '' ),
			''
		);
		$merged['switch_label_color_dark']         = $this->sanitize_color(
			(string) ( $merged['switch_label_color_dark'] ?? '' ),
			''
		);

		return $merged;
	}

	/**
	 * Sanitize a responsive line-height map (unitless allowed).
	 *
	 * @param mixed  $raw      Raw map or string.
	 * @param string $fallback Desktop fallback.
	 * @return array<string, string>
	 */
	private function sanitize_responsive_line_height_map( $raw, string $fallback ): array {
		if ( is_string( $raw ) || is_numeric( $raw ) ) {
			return array(
				'desktop' => $this->sanitize_line_height( (string) $raw, $fallback ),
			);
		}

		if ( ! is_array( $raw ) ) {
			return array(
				'desktop' => $fallback,
			);
		}

		$allowed_bp = array( 'desktop', 'tablet', 'tabletWide', 'phone', 'phoneWide' );
		$out        = array();

		foreach ( $allowed_bp as $bp ) {
			if ( ! array_key_exists( $bp, $raw ) ) {
				continue;
			}
			$leaf = is_string( $raw[ $bp ] ) || is_numeric( $raw[ $bp ] )
				? (string) $raw[ $bp ]
				: $this->normalize_range_length_leaf( $raw[ $bp ], '' );
			if ( '' === $leaf ) {
				continue;
			}
			// Prefer preserving unitless; only force unit when Range leaf added px.
			$sanitized = $this->sanitize_line_height( $leaf, '' );
			if ( '' !== $sanitized ) {
				$out[ $bp ] = $sanitized;
			}
		}

		if ( ! isset( $out['desktop'] ) ) {
			$out['desktop'] = $fallback;
		}

		return $out;
	}

	/**
	 * Sanitize z index.
	 *
	 * @param string $z_index  Z-index value.
	 * @param string $fallback Fallback.
	 * @return string
	 */
	private function sanitize_z_index( string $z_index, string $fallback ): string {
		$z_index = trim( $z_index );
		if ( preg_match( '/^-?\d{1,7}$/', $z_index ) ) {
			return $z_index;
		}

		return $fallback;
	}

	/**
	 * Sanitize switch position.
	 *
	 * @param string $position Switch position slug.
	 * @return string
	 */
	private function sanitize_switch_position( string $position ): string {
		$allowed  = array( 'bottom_right', 'bottom_left', 'top_right', 'top_left' );
		$position = sanitize_key( $position );

		return in_array( $position, $allowed, true ) ? $position : 'bottom_right';
	}

	/**
	 * Phase 2 responsive layout keys stored as breakpoint maps.
	 *
	 * @return array<int, string>
	 */
	private function get_responsive_layout_keys(): array {
		return array(
			'switch_position',
			'switch_size',
			'switch_padding_x',
			'switch_offset_x',
			'switch_offset_y',
		);
	}

	/**
	 * Desktop schema defaults for responsive layout keys.
	 *
	 * @return array<string, string>
	 */
	private function get_responsive_layout_schema_defaults(): array {
		return array(
			'switch_position'  => 'bottom_right',
			'switch_size'      => '48px',
			'switch_padding_x' => '14px',
			'switch_offset_x'  => '20px',
			'switch_offset_y'  => '20px',
		);
	}

	/**
	 * Dark Palette colour keys stored as breakpoint maps.
	 *
	 * @return array<int, string>
	 */
	private function get_responsive_palette_keys(): array {
		return array(
			'palette_bg',
			'palette_text',
			'palette_heading',
			'palette_link',
			'palette_link_hover',
			'palette_accent',
			'palette_button_text',
			'palette_surface',
			'palette_border',
			'palette_input_bg',
			'palette_input_text',
			'palette_input_border',
		);
	}

	/**
	 * Desktop schema defaults for Dark Palette colour keys.
	 *
	 * Empty input tokens resolve to surface / text / border at CSS build time.
	 *
	 * @return array<string, string>
	 */
	private function get_responsive_palette_schema_defaults(): array {
		return array(
			'palette_bg'           => '#1a1a1a',
			'palette_text'         => '#e8e8e8',
			'palette_heading'      => '#ffffff',
			'palette_link'         => '#7eb8ff',
			'palette_link_hover'   => '#a8d4ff',
			'palette_accent'       => '#7eb8ff',
			'palette_button_text'  => '#0d1117',
			'palette_surface'      => '#242424',
			'palette_border'       => '#333333',
			'palette_input_bg'     => '',
			'palette_input_text'   => '',
			'palette_input_border' => '',
		);
	}

	/**
	 * Soft-migrate flat palette colour strings → `{ desktop: string }` maps.
	 *
	 * @param array<string, mixed> $settings Settings snapshot.
	 * @return array<string, mixed>
	 */
	private function migrate_responsive_palette_settings( array $settings ): array {
		$schemas = $this->get_responsive_palette_schema_defaults();

		foreach ( $this->get_responsive_palette_keys() as $key ) {
			$schema = $schemas[ $key ] ?? '';
			$raw    = $settings[ $key ] ?? null;

			if ( is_string( $raw ) ) {
				$settings[ $key ] = array(
					'desktop' => $raw,
				);
				continue;
			}

			if ( ! is_array( $raw ) ) {
				$settings[ $key ] = array(
					'desktop' => $schema,
				);
				continue;
			}

			$breakpoint_keys = array( 'desktop', 'tablet', 'tabletWide', 'phone', 'phoneWide' );
			$has_bp          = false;
			foreach ( $breakpoint_keys as $bp ) {
				if ( array_key_exists( $bp, $raw ) ) {
					$has_bp = true;
					break;
				}
			}

			if ( $has_bp ) {
				if ( ! isset( $raw['desktop'] ) || ! is_string( $raw['desktop'] ) || '' === trim( $raw['desktop'] ) ) {
					$raw['desktop'] = $schema;
				}
				$settings[ $key ] = $raw;
				continue;
			}

			$settings[ $key ] = array(
				'desktop' => $schema,
			);
		}

		return $settings;
	}

	/**
	 * Sanitize a responsive colour map (preserves `$variable` / gcid / hex).
	 *
	 * Unset tablet/phone leaves are omitted (inherit). Desktop always present.
	 *
	 * @param mixed  $raw      Raw map or legacy string.
	 * @param string $fallback Desktop fallback.
	 * @return array<string, string>
	 */
	private function sanitize_responsive_color_map( $raw, string $fallback ): array {
		if ( is_string( $raw ) ) {
			return array(
				'desktop' => $this->sanitize_color( $raw, $fallback ),
			);
		}

		if ( ! is_array( $raw ) ) {
			return array(
				'desktop' => $fallback,
			);
		}

		$allowed_bp = array( 'desktop', 'tablet', 'tabletWide', 'phone', 'phoneWide' );
		$out        = array();

		foreach ( $allowed_bp as $bp ) {
			if ( ! array_key_exists( $bp, $raw ) || ! is_string( $raw[ $bp ] ) ) {
				continue;
			}
			$trimmed = trim( $raw[ $bp ] );
			if ( '' === $trimmed ) {
				continue;
			}
			// Empty fallback for optional BPs so invalid leaves are dropped (inherit).
			$sanitized = $this->sanitize_color( $trimmed, '' );
			if ( '' === $sanitized ) {
				continue;
			}
			$out[ $bp ] = $sanitized;
		}

		if ( ! isset( $out['desktop'] ) ) {
			$out['desktop'] = $fallback;
		}

		return $out;
	}

	/**
	 * Soft-migrate flat layout strings → `{ desktop: string }` maps.
	 *
	 * @param array<string, mixed> $settings Settings snapshot.
	 * @return array<string, mixed>
	 */
	private function migrate_responsive_layout_settings( array $settings ): array {
		$schemas = $this->get_responsive_layout_schema_defaults();

		foreach ( $this->get_responsive_layout_keys() as $key ) {
			$schema = $schemas[ $key ] ?? '';
			$raw    = $settings[ $key ] ?? null;

			if ( is_string( $raw ) || is_numeric( $raw ) ) {
				$settings[ $key ] = array(
					'desktop' => (string) $raw,
				);
				continue;
			}

			if ( ! is_array( $raw ) ) {
				$settings[ $key ] = array(
					'desktop' => $schema,
				);
				continue;
			}

			// Already a breakpoint map (has desktop/tablet/phone keys) or Range leaf.
			$breakpoint_keys = array( 'desktop', 'tablet', 'tabletWide', 'phone', 'phoneWide' );
			$has_bp          = false;
			foreach ( $breakpoint_keys as $bp ) {
				if ( array_key_exists( $bp, $raw ) ) {
					$has_bp = true;
					break;
				}
			}

			if ( $has_bp ) {
				if ( ! isset( $raw['desktop'] ) ) {
					$raw['desktop'] = $schema;
				}
				$settings[ $key ] = $raw;
				continue;
			}

			// Mistaken `{ value, unit }` at top level.
			if ( isset( $raw['value'] ) ) {
				$settings[ $key ] = array(
					'desktop' => $this->normalize_range_length_leaf( $raw, $schema ),
				);
				continue;
			}

			$settings[ $key ] = array(
				'desktop' => $schema,
			);
		}

		return $settings;
	}

	/**
	 * Normalize a Range leaf (string or `{ value, unit }`) to one CSS length.
	 *
	 * @param mixed  $leaf     Raw leaf.
	 * @param string $fallback Fallback.
	 * @return string
	 */
	private function normalize_range_length_leaf( $leaf, string $fallback ): string {
		if ( is_string( $leaf ) ) {
			return $this->sanitize_css_length( $leaf, $fallback );
		}
		if ( is_numeric( $leaf ) ) {
			return $this->sanitize_css_length( (string) $leaf . 'px', $fallback );
		}
		if ( is_array( $leaf ) && isset( $leaf['value'] ) ) {
			$v = $leaf['value'];
			$u = ( isset( $leaf['unit'] ) && is_string( $leaf['unit'] ) ) ? $leaf['unit'] : 'px';
			if ( is_numeric( $v ) || ( is_string( $v ) && '' !== trim( (string) $v ) ) ) {
				return $this->sanitize_css_length( trim( (string) $v ) . $u, $fallback );
			}
		}

		return $fallback;
	}

	/**
	 * Sanitize a responsive length map.
	 *
	 * @param mixed  $raw      Raw map or legacy string.
	 * @param string $fallback Desktop fallback.
	 * @return array<string, string>
	 */
	private function sanitize_responsive_length_map( $raw, string $fallback ): array {
		if ( is_string( $raw ) || is_numeric( $raw ) ) {
			return array(
				'desktop' => $this->sanitize_css_length( (string) $raw, $fallback ),
			);
		}

		if ( ! is_array( $raw ) ) {
			return array(
				'desktop' => $fallback,
			);
		}

		$allowed_bp = array( 'desktop', 'tablet', 'tabletWide', 'phone', 'phoneWide' );
		$out        = array();

		foreach ( $allowed_bp as $bp ) {
			if ( ! array_key_exists( $bp, $raw ) ) {
				continue;
			}
			$leaf = $this->normalize_range_length_leaf( $raw[ $bp ], '' );
			if ( '' !== $leaf ) {
				$out[ $bp ] = $leaf;
			}
		}

		if ( ! isset( $out['desktop'] ) ) {
			$out['desktop'] = $fallback;
		}

		return $out;
	}

	/**
	 * Sanitize a responsive select map (e.g. switch_position).
	 *
	 * @param mixed              $raw      Raw map or legacy string.
	 * @param array<int, string> $allowed Allowed slugs.
	 * @param string             $fallback Desktop fallback.
	 * @return array<string, string>
	 */
	private function sanitize_responsive_select_map( $raw, array $allowed, string $fallback ): array {
		if ( is_string( $raw ) ) {
			return array(
				'desktop' => $this->sanitize_allowed_slug( $raw, $allowed, $fallback ),
			);
		}

		if ( ! is_array( $raw ) ) {
			return array(
				'desktop' => $fallback,
			);
		}

		$allowed_bp = array( 'desktop', 'tablet', 'tabletWide', 'phone', 'phoneWide' );
		$out        = array();

		foreach ( $allowed_bp as $bp ) {
			if ( ! array_key_exists( $bp, $raw ) || ! is_string( $raw[ $bp ] ) ) {
				continue;
			}
			$out[ $bp ] = $this->sanitize_allowed_slug( $raw[ $bp ], $allowed, $fallback );
		}

		if ( ! isset( $out['desktop'] ) ) {
			$out['desktop'] = $fallback;
		}

		return $out;
	}

	/**
	 * Sanitize allowed slug.
	 *
	 * @param string             $value    Raw slug.
	 * @param array<int, string> $allowed Allowed.
	 * @param string             $fallback Fallback.
	 * @return string
	 */
	private function sanitize_allowed_slug( string $value, array $allowed, string $fallback ): string {
		$slug = sanitize_key( $value );

		return in_array( $slug, $allowed, true ) ? $slug : $fallback;
	}

	/**
	 * Resolve a responsive scalar for a breakpoint (phone ← tablet ← desktop).
	 *
	 * @param array<string, mixed> $settings        Settings.
	 * @param string               $key             Setting key.
	 * @param string               $breakpoint_name Breakpoint name.
	 * @param string               $default_token   Fallback.
	 * @return string
	 */
	private function resolve_layout_scalar_for_breakpoint( array $settings, string $key, string $breakpoint_name, string $default_token ): string {
		if ( isset( $settings[ $key ] ) && is_string( $settings[ $key ] ) ) {
			$trimmed = trim( $settings[ $key ] );

			return '' !== $trimmed ? $trimmed : $default_token;
		}

		$bucket = isset( $settings[ $key ] ) && is_array( $settings[ $key ] ) ? $settings[ $key ] : array();
		$ladder = array( 'desktop', 'tabletWide', 'tablet', 'phoneWide', 'phone' );

		// Coarse normalize: tabletWide→tablet, phoneWide→phone for cascade start.
		$normalized = $breakpoint_name;
		if ( 'tabletWide' === $breakpoint_name ) {
			$normalized = 'tablet';
		} elseif ( 'phoneWide' === $breakpoint_name ) {
			$normalized = 'phone';
		}

		$target_idx = array_search( $normalized, $ladder, true );
		if ( false === $target_idx ) {
			$target_idx = 0;
		}

		for ( $i = (int) $target_idx; $i >= 0; $i-- ) {
			$bp = $ladder[ $i ];
			if ( ! isset( $bucket[ $bp ] ) ) {
				continue;
			}

			if ( 'switch_position' === $key ) {
				if ( ! is_string( $bucket[ $bp ] ) || '' === trim( $bucket[ $bp ] ) ) {
					continue;
				}
				return $this->sanitize_switch_position( $bucket[ $bp ] );
			}

			$leaf = $this->normalize_range_length_leaf( $bucket[ $bp ], '' );
			if ( '' !== $leaf ) {
				return $leaf;
			}
		}

		return $default_token;
	}

	/**
	 * Whether any layout key has tablet/phone overrides.
	 *
	 * @param array<string, mixed> $settings Settings.
	 * @return bool
	 */
	private function has_layout_breakpoint_overrides( array $settings ): bool {
		foreach ( $this->get_responsive_layout_keys() as $key ) {
			$map = $settings[ $key ] ?? null;
			if ( ! is_array( $map ) ) {
				continue;
			}
			$desk = isset( $map['desktop'] ) ? (string) $map['desktop'] : '';
			foreach ( array( 'tablet', 'tabletWide', 'phone', 'phoneWide' ) as $bp ) {
				if ( ! isset( $map[ $bp ] ) ) {
					continue;
				}
				$v = is_string( $map[ $bp ] ) ? $map[ $bp ] : $this->normalize_range_length_leaf( $map[ $bp ], '' );
				if ( '' !== $v && $v !== $desk ) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Whether any Dark Palette colour has tablet/phone overrides.
	 *
	 * @param array<string, mixed> $settings Settings.
	 * @return bool
	 */
	private function has_palette_breakpoint_overrides( array $settings ): bool {
		foreach ( $this->get_responsive_palette_keys() as $key ) {
			$map = $settings[ $key ] ?? null;
			if ( ! is_array( $map ) ) {
				continue;
			}
			$desk = isset( $map['desktop'] ) && is_string( $map['desktop'] ) ? $map['desktop'] : '';
			foreach ( array( 'tablet', 'tabletWide', 'phone', 'phoneWide' ) as $bp ) {
				if ( ! isset( $map[ $bp ] ) || ! is_string( $map[ $bp ] ) ) {
					continue;
				}
				$v = trim( $map[ $bp ] );
				if ( '' !== $v && $v !== $desk ) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Resolve a Dark Palette colour for a breakpoint (phone ← tablet ← desktop).
	 *
	 * Returns the stored colour string (hex / `$variable` / gcid) before CSS normalize.
	 *
	 * @param array<string, mixed> $settings        Settings.
	 * @param string               $key             Palette key.
	 * @param string               $breakpoint_name Breakpoint name.
	 * @param string               $default_token   Fallback colour.
	 * @return string
	 */
	private function resolve_palette_color_for_breakpoint( array $settings, string $key, string $breakpoint_name, string $default_token ): string {
		if ( isset( $settings[ $key ] ) && is_string( $settings[ $key ] ) ) {
			$trimmed = trim( $settings[ $key ] );

			return '' !== $trimmed ? $trimmed : $default_token;
		}

		$bucket = isset( $settings[ $key ] ) && is_array( $settings[ $key ] ) ? $settings[ $key ] : array();
		$ladder = array( 'desktop', 'tabletWide', 'tablet', 'phoneWide', 'phone' );

		$normalized = $breakpoint_name;
		if ( 'tabletWide' === $breakpoint_name ) {
			$normalized = 'tablet';
		} elseif ( 'phoneWide' === $breakpoint_name ) {
			$normalized = 'phone';
		}

		$target_idx = array_search( $normalized, $ladder, true );
		if ( false === $target_idx ) {
			$target_idx = 0;
		}

		for ( $i = (int) $target_idx; $i >= 0; $i-- ) {
			$bp = $ladder[ $i ];
			if ( ! isset( $bucket[ $bp ] ) || ! is_string( $bucket[ $bp ] ) ) {
				continue;
			}
			$trimmed = trim( $bucket[ $bp ] );
			if ( '' !== $trimmed ) {
				return $trimmed;
			}
		}

		return $default_token;
	}

	/**
	 * Localize a palette colour map with CSS-ready paints (gcid resolved).
	 *
	 * @param array<string, mixed> $settings Settings.
	 * @param string               $key      Palette key.
	 * @return array<string, string>
	 */
	private function palette_map_to_css_map( array $settings, string $key ): array {
		$schemas = $this->get_responsive_palette_schema_defaults();
		$schema  = $schemas[ $key ] ?? '';
		$map     = $this->sanitize_responsive_color_map( $settings[ $key ] ?? array(), $schema );
		$out     = array();

		foreach ( $map as $bp => $raw ) {
			if ( ! is_string( $bp ) || ! is_string( $raw ) ) {
				continue;
			}
			$normalized = $this->normalize_color_for_css( $raw );
			if ( '' === $normalized ) {
				$normalized = $schema;
			}
			$out[ $bp ] = esc_attr( $normalized );
		}

		if ( ! isset( $out['desktop'] ) ) {
			$out['desktop'] = esc_attr( $schema );
		}

		return $out;
	}

	/**
	 * Enabled breakpoints as `{ name, maxWidth }` for FE JS media reinject.
	 *
	 * @return array<int, array{name: string, maxWidth: int|null}>
	 */
	private function get_palette_breakpoints_for_localize(): array {
		$out = array();

		foreach ( $this->get_enabled_breakpoints() as $breakpoint ) {
			if ( ! is_array( $breakpoint ) || ! isset( $breakpoint['name'] ) || ! is_string( $breakpoint['name'] ) ) {
				continue;
			}
			$name  = $breakpoint['name'];
			$out[] = array(
				'name'     => $name,
				'maxWidth' => 'desktop' === $name ? null : $this->get_breakpoint_media_max_px( $breakpoint ),
			);
		}

		return $out;
	}

	/**
	 * Divi enabled breakpoints with safe fallback (mirrors Popup).
	 *
	 * @return array<int, array<string, mixed>>
	 */
	private function get_enabled_breakpoints(): array {
		static $cached = null;
		if ( null !== $cached ) {
			return $cached;
		}

		$class = self::DSM_ET_BREAKPOINT_CLASS;
		if ( class_exists( $class ) && method_exists( $class, 'get_enabled_breakpoints' ) ) {
			$enabled = call_user_func( array( $class, 'get_enabled_breakpoints' ) );
			$cached  = ( is_array( $enabled ) && array() !== $enabled )
				? $enabled
				: $this->get_fallback_enabled_breakpoints();
			return $cached;
		}

		$cached = $this->get_fallback_enabled_breakpoints();
		return $cached;
	}

	/**
	 * Get fallback enabled breakpoints.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	private function get_fallback_enabled_breakpoints(): array {
		return array(
			array(
				'order'  => 50,
				'enable' => true,
				'name'   => 'desktop',
			),
			array(
				'order'    => 30,
				'enable'   => true,
				'name'     => 'tablet',
				'maxWidth' => array(
					'value'   => '980px',
					'default' => 980,
				),
			),
			array(
				'order'    => 10,
				'enable'   => true,
				'name'     => 'phone',
				'maxWidth' => array(
					'value'   => '767px',
					'default' => 767,
				),
			),
		);
	}

	/**
	 * Get breakpoint media max px.
	 *
	 * @param array<string, mixed> $breakpoint Breakpoint entry.
	 * @return int|null
	 */
	private function get_breakpoint_media_max_px( array $breakpoint ): ?int {
		$name = isset( $breakpoint['name'] ) && is_string( $breakpoint['name'] ) ? $breakpoint['name'] : '';
		if ( '' === $name || 'desktop' === $name ) {
			return null;
		}
		if ( isset( $breakpoint['maxWidth']['default'] ) && is_numeric( $breakpoint['maxWidth']['default'] ) ) {
			return (int) $breakpoint['maxWidth']['default'];
		}
		if ( isset( $breakpoint['maxWidth']['value'] ) ) {
			$raw = $breakpoint['maxWidth']['value'];
			if ( is_numeric( $raw ) ) {
				$parsed = (int) $raw;
				return $parsed > 0 ? $parsed : null;
			}
			if ( is_string( $raw ) && '' !== trim( $raw ) ) {
				$parsed = (int) $raw;
				return $parsed > 0 ? $parsed : null;
			}
		}
		$fallback_by_name = array(
			'tablet'     => 980,
			'phone'      => 767,
			'phoneWide'  => 860,
			'tabletWide' => 1024,
		);

		return $fallback_by_name[ $name ] ?? null;
	}

	/**
	 * Position slug → absolute inset declarations for media CSS.
	 *
	 * @param string $position Position slug.
	 * @param string $offset_x Offset X.
	 * @param string $offset_y Offset Y.
	 * @return string CSS declarations.
	 */
	private function build_position_inset_css( string $position, string $offset_x, string $offset_y ): string {
		$x = esc_attr( $offset_x );
		$y = esc_attr( $offset_y );

		switch ( $position ) {
			case 'bottom_left':
				return "top:auto;right:auto;bottom:{$y};left:{$x};";
			case 'top_right':
				return "top:{$y};right:{$x};bottom:auto;left:auto;";
			case 'top_left':
				return "top:{$y};right:auto;bottom:auto;left:{$x};";
			case 'bottom_right':
			default:
				return "top:auto;right:{$x};bottom:{$y};left:auto;";
		}
	}

	/**
	 * Build FOUC-safe floating-switch layout CSS (desktop + Divi @media).
	 *
	 * @param array<string, mixed>|null $settings Optional settings.
	 * @return string
	 */
	public function build_floating_switch_layout_css( ?array $settings = null ): string {
		$settings = is_array( $settings ) ? $settings : $this->get_settings();

		if ( 'on' !== ( $settings['show_floating_switch'] ?? 'off' ) ) {
			return '';
		}

		// Desktop-only maps: keep SCSS soft 782px defaults + JS inline vars.
		// Print Divi @media CSS only when tablet/phone overrides exist.
		if ( ! $this->has_layout_breakpoint_overrides( $settings ) ) {
			return '';
		}

		$schemas  = $this->get_responsive_layout_schema_defaults();
		$css      = '';
		$selector = '.dsm-dark-mode-toggle:not(.dsm-dark-mode-toggle--module)';

		foreach ( $this->get_enabled_breakpoints() as $breakpoint ) {
			if ( ! is_array( $breakpoint ) || ! isset( $breakpoint['name'] ) || ! is_string( $breakpoint['name'] ) ) {
				continue;
			}
			$bp_name = $breakpoint['name'];

			$size      = $this->resolve_layout_scalar_for_breakpoint( $settings, 'switch_size', $bp_name, $schemas['switch_size'] );
			$padding_x = $this->resolve_layout_scalar_for_breakpoint( $settings, 'switch_padding_x', $bp_name, $schemas['switch_padding_x'] );
			$offset_x  = $this->resolve_layout_scalar_for_breakpoint( $settings, 'switch_offset_x', $bp_name, $schemas['switch_offset_x'] );
			$offset_y  = $this->resolve_layout_scalar_for_breakpoint( $settings, 'switch_offset_y', $bp_name, $schemas['switch_offset_y'] );
			$position  = $this->sanitize_switch_position(
				$this->resolve_layout_scalar_for_breakpoint( $settings, 'switch_position', $bp_name, $schemas['switch_position'] )
			);

			$decls  = sprintf(
				'--dsm-dm-toggle-size:%1$s;--dsm-dm-toggle-padding-x:%2$s;--dsm-dm-toggle-offset-x:%3$s;--dsm-dm-toggle-offset-y:%4$s;',
				esc_attr( $size ),
				esc_attr( $padding_x ),
				esc_attr( $offset_x ),
				esc_attr( $offset_y )
			);
			$decls .= $this->build_position_inset_css( $position, $offset_x, $offset_y );

			if ( 'desktop' === $bp_name ) {
				$css .= sprintf( '%s{%s}', $selector, $decls );
				continue;
			}

			$max_width = $this->get_breakpoint_media_max_px( $breakpoint );
			if ( null === $max_width ) {
				continue;
			}

			$css .= sprintf(
				'@media (max-width:%1$dpx){%2$s{%3$s}}',
				$max_width,
				$selector,
				$decls
			);
		}

		/**
		 * Filter floating-switch layout CSS (responsive size/offset/position).
		 *
		 * @param string               $css      CSS.
		 * @param array<string, mixed> $settings Settings.
		 */
		return (string) apply_filters( 'dsm_dark_mode_floating_switch_layout_css', $css, $settings );
	}

	/**
	 * Print floating-switch layout CSS early (FOUC-safe Divi breakpoints).
	 *
	 * @return void
	 */
	public function print_floating_switch_layout_css(): void {
		if ( ! $this->should_load_on_current_request() ) {
			return;
		}

		$css = $this->build_floating_switch_layout_css();

		if ( '' === trim( $css ) ) {
			return;
		}

		echo '<style id="dsm-dark-mode-switch-layout">' . $css . '</style>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- CSS built from sanitized settings.
	}

	/**
	 * Whether nested border / box-shadow maps have tablet/phone overrides.
	 *
	 * @param array<string, mixed> $settings Settings.
	 * @return bool
	 */
	private function has_switch_design_breakpoint_overrides( array $settings ): bool {
		$keys = array( 'switch_border', 'switch_box_shadow_light', 'switch_box_shadow_dark' );

		foreach ( $keys as $key ) {
			$map = $settings[ $key ] ?? null;
			if ( ! is_array( $map ) ) {
				continue;
			}
			$desk = isset( $map['desktop'] ) && is_array( $map['desktop'] )
				? wp_json_encode( $map['desktop'] )
				: '';
			foreach ( array( 'tablet', 'tabletWide', 'phone', 'phoneWide' ) as $bp ) {
				if ( ! isset( $map[ $bp ] ) || ! is_array( $map[ $bp ] ) ) {
					continue;
				}
				$encoded = wp_json_encode( $map[ $bp ] );
				if ( false !== $encoded && '' !== $encoded && $encoded !== $desk ) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Build CSS custom-property declarations for border + box-shadow at one breakpoint.
	 *
	 * @param array<string, mixed> $settings Settings (migrated nested maps).
	 * @param string               $bp_name  Breakpoint name.
	 * @return string CSS declarations (no selector).
	 */
	private function build_switch_design_decls_for_breakpoint( array $settings, string $bp_name ): string {
		$defaults             = $this->default_settings;
		$default_border       = isset( $defaults['switch_border']['desktop'] ) && is_array( $defaults['switch_border']['desktop'] )
			? $defaults['switch_border']['desktop']
			: array();
		$default_shadow_light = isset( $defaults['switch_box_shadow_light']['desktop'] ) && is_array( $defaults['switch_box_shadow_light']['desktop'] )
			? $defaults['switch_box_shadow_light']['desktop']
			: array();
		$default_shadow_dark  = isset( $defaults['switch_box_shadow_dark']['desktop'] ) && is_array( $defaults['switch_box_shadow_dark']['desktop'] )
			? $defaults['switch_box_shadow_dark']['desktop']
			: array();

		$border_map       = isset( $settings['switch_border'] ) && is_array( $settings['switch_border'] )
			? $settings['switch_border']
			: array( 'desktop' => $default_border );
		$shadow_light_map = isset( $settings['switch_box_shadow_light'] ) && is_array( $settings['switch_box_shadow_light'] )
			? $settings['switch_box_shadow_light']
			: array( 'desktop' => $default_shadow_light );
		$shadow_dark_map  = isset( $settings['switch_box_shadow_dark'] ) && is_array( $settings['switch_box_shadow_dark'] )
			? $settings['switch_box_shadow_dark']
			: array( 'desktop' => $default_shadow_dark );

		$border       = $this->resolve_switch_design_map_leaf( $border_map, $bp_name, $default_border, 'border' );
		$shadow_light = $this->resolve_switch_design_map_leaf( $shadow_light_map, $bp_name, $default_shadow_light, 'shadow' );
		$shadow_dark  = $this->resolve_switch_design_map_leaf( $shadow_dark_map, $bp_name, $default_shadow_dark, 'shadow' );

		$styles           = is_array( $border['styles']['all'] ?? null ) ? $border['styles']['all'] : array();
		$width            = $this->sanitize_css_length(
			(string) ( $styles['width'] ?? $defaults['switch_border_width'] ),
			(string) $defaults['switch_border_width']
		);
		$style            = $this->sanitize_border_style( (string) ( $styles['style'] ?? 'solid' ) );
		$radius           = $this->compose_border_radius_css(
			is_array( $border['radius'] ?? null ) ? $border['radius'] : array()
		);
		$border_light_raw = (string) ( $styles['color'] ?? $defaults['switch_border_color_light'] );
		$border_light     = $this->normalize_color_for_css(
			$this->sanitize_color( $border_light_raw, (string) $defaults['switch_border_color_light'] )
		);
		if ( '' === $border_light ) {
			$border_light = (string) $defaults['switch_border_color_light'];
		}
		$border_dark = $this->normalize_color_for_css(
			$this->sanitize_color(
				(string) ( $settings['switch_border_color_dark'] ?? '' ),
				(string) $defaults['switch_border_color_dark']
			)
		);
		if ( '' === $border_dark ) {
			$border_dark = (string) $defaults['switch_border_color_dark'];
		}

		$shadow_light_css = $this->compose_box_shadow_css(
			$shadow_light,
			(string) ( $defaults['switch_shadow_light'] ?? '0 8px 24px rgba(0, 0, 0, 0.12)' )
		);
		$shadow_dark_css  = $this->compose_box_shadow_css(
			$shadow_dark,
			(string) ( $defaults['switch_shadow_dark'] ?? '0 8px 24px rgba(0, 0, 0, 0.28)' )
		);

		return sprintf(
			'--dsm-dm-toggle-border-width:%1$s;--dsm-dm-toggle-border-style:%2$s;--dsm-dm-toggle-border-radius:%3$s;--dsm-dm-toggle-border-color-light:%4$s;--dsm-dm-toggle-border-color-dark:%5$s;--dsm-dm-toggle-shadow-light:%6$s;--dsm-dm-toggle-shadow-dark:%7$s;',
			esc_attr( $width ),
			esc_attr( $style ),
			esc_attr( $radius ),
			esc_attr( $border_light ),
			esc_attr( $border_dark ),
			esc_attr( $shadow_light_css ),
			esc_attr( $shadow_dark_css )
		);
	}

	/**
	 * Build FOUC-safe floating-switch border/shadow CSS (desktop + Divi @media).
	 *
	 * Targets the floating switch and placeable modules with design-sync enabled.
	 * Desktop-only sites (no tablet/phone leaves) return empty — JS/SCSS defaults remain.
	 *
	 * @param array<string, mixed>|null $settings Optional settings.
	 * @return string
	 */
	public function build_floating_switch_design_css( ?array $settings = null ): string {
		$settings = is_array( $settings ) ? $settings : $this->get_settings();

		if ( 'on' !== ( $settings['show_floating_switch'] ?? 'off' )
			&& 'on' !== ( $settings['apply_floating_design_to_module'] ?? 'off' )
		) {
			return '';
		}

		if ( ! $this->has_switch_design_breakpoint_overrides( $settings ) ) {
			return '';
		}

		$css      = '';
		$selector = '.dsm-dark-mode-toggle:not(.dsm-dark-mode-toggle--module),.dsm-dark-mode-toggle--module.dsm-dark-mode-toggle--design-sync';

		foreach ( $this->get_enabled_breakpoints() as $breakpoint ) {
			if ( ! is_array( $breakpoint ) || ! isset( $breakpoint['name'] ) || ! is_string( $breakpoint['name'] ) ) {
				continue;
			}
			$bp_name = $breakpoint['name'];
			$decls   = $this->build_switch_design_decls_for_breakpoint( $settings, $bp_name );

			if ( 'desktop' === $bp_name ) {
				$css .= sprintf( '%s{%s}', $selector, $decls );
				continue;
			}

			$max_width = $this->get_breakpoint_media_max_px( $breakpoint );
			if ( null === $max_width ) {
				continue;
			}

			$css .= sprintf(
				'@media (max-width:%1$dpx){%2$s{%3$s}}',
				$max_width,
				$selector,
				$decls
			);
		}

		/**
		 * Filter floating-switch border/shadow responsive CSS.
		 *
		 * @param string               $css      CSS.
		 * @param array<string, mixed> $settings Settings.
		 */
		return (string) apply_filters( 'dsm_dark_mode_floating_switch_design_css', $css, $settings );
	}

	/**
	 * Print floating-switch border/shadow CSS early (FOUC-safe Divi breakpoints).
	 *
	 * @return void
	 */
	public function print_floating_switch_design_css(): void {
		if ( ! $this->should_load_on_current_request() ) {
			return;
		}

		$css = $this->build_floating_switch_design_css();

		if ( '' === trim( $css ) ) {
			return;
		}

		echo '<style id="dsm-dark-mode-switch-design">' . $css . '</style>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- CSS built from sanitized settings.
	}

	/**
	 * Whether label typography maps have tablet/phone overrides.
	 *
	 * @param array<string, mixed> $settings Settings.
	 * @return bool
	 */
	private function has_label_typography_breakpoint_overrides( array $settings ): bool {
		foreach ( $this->get_responsive_label_typography_keys() as $key ) {
			$map = $settings[ $key ] ?? null;
			if ( ! is_array( $map ) ) {
				continue;
			}
			$desk = isset( $map['desktop'] ) && is_string( $map['desktop'] ) ? $map['desktop'] : '';
			foreach ( array( 'tablet', 'tabletWide', 'phone', 'phoneWide' ) as $bp ) {
				if ( ! isset( $map[ $bp ] ) || ! is_string( $map[ $bp ] ) ) {
					continue;
				}
				if ( '' !== $map[ $bp ] && $map[ $bp ] !== $desk ) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Resolve a label typography scalar at a breakpoint (cascade phone ← tablet ← desktop).
	 *
	 * @param array<string, mixed> $settings Settings.
	 * @param string               $key      Map key.
	 * @param string               $bp_name  Breakpoint name.
	 * @param string               $schema   Desktop fallback.
	 * @return string
	 */
	private function resolve_label_typography_scalar_for_breakpoint(
		array $settings,
		string $key,
		string $bp_name,
		string $schema
	): string {
		$map    = isset( $settings[ $key ] ) && is_array( $settings[ $key ] )
			? $settings[ $key ]
			: array( 'desktop' => $schema );
		$target = $this->normalize_coarse_breakpoint( $bp_name );
		$ladder = 'tablet' === $target
			? array( 'tablet', 'desktop' )
			: ( 'phone' === $target ? array( 'phone', 'tablet', 'desktop' ) : array( 'desktop' ) );

		foreach ( $ladder as $bp ) {
			if ( ! isset( $map[ $bp ] ) || ! is_string( $map[ $bp ] ) || '' === $map[ $bp ] ) {
				continue;
			}
			return $map[ $bp ];
		}

		return $schema;
	}

	/**
	 * Normalize Divi breakpoint name to coarse desktop/tablet/phone.
	 *
	 * @param string $raw Breakpoint name.
	 * @return string
	 */
	private function normalize_coarse_breakpoint( string $raw ): string {
		if ( 'tablet' === $raw || 'tabletWide' === $raw ) {
			return 'tablet';
		}
		if ( 'phone' === $raw || 'phoneWide' === $raw ) {
			return 'phone';
		}

		return 'desktop';
	}

	/**
	 * Build FOUC-safe floating-switch label typography CSS (desktop + Divi @media).
	 *
	 * Desktop-only sites return empty — JS/SCSS defaults remain.
	 *
	 * @param array<string, mixed>|null $settings Optional settings.
	 * @return string
	 */
	public function build_floating_switch_typography_css( ?array $settings = null ): string {
		$settings = is_array( $settings ) ? $settings : $this->get_settings();

		if ( 'on' !== ( $settings['show_floating_switch'] ?? 'off' )
			&& 'on' !== ( $settings['apply_floating_design_to_module'] ?? 'off' )
		) {
			return '';
		}

		$content_mode = (string) ( $settings['switch_content_mode'] ?? 'default' );
		if ( 'text' !== $content_mode && 'icon_text' !== $content_mode ) {
			return '';
		}

		if ( ! $this->has_label_typography_breakpoint_overrides( $settings ) ) {
			return '';
		}

		$schemas  = $this->get_responsive_label_typography_schema_defaults();
		$css      = '';
		$selector = '.dsm-dark-mode-toggle:not(.dsm-dark-mode-toggle--module),.dsm-dark-mode-toggle--module.dsm-dark-mode-toggle--design-sync';

		foreach ( $this->get_enabled_breakpoints() as $breakpoint ) {
			if ( ! is_array( $breakpoint ) || ! isset( $breakpoint['name'] ) || ! is_string( $breakpoint['name'] ) ) {
				continue;
			}
			$bp_name = $breakpoint['name'];
			$size    = $this->resolve_label_typography_scalar_for_breakpoint(
				$settings,
				'switch_label_font_size',
				$bp_name,
				$schemas['switch_label_font_size']
			);
			$weight  = $this->resolve_label_typography_scalar_for_breakpoint(
				$settings,
				'switch_label_font_weight',
				$bp_name,
				$schemas['switch_label_font_weight']
			);
			$letter  = $this->resolve_label_typography_scalar_for_breakpoint(
				$settings,
				'switch_label_letter_spacing',
				$bp_name,
				$schemas['switch_label_letter_spacing']
			);
			$line    = $this->resolve_label_typography_scalar_for_breakpoint(
				$settings,
				'switch_label_line_height',
				$bp_name,
				$schemas['switch_label_line_height']
			);
			$align   = $this->sanitize_label_text_align(
				$this->resolve_label_typography_scalar_for_breakpoint(
					$settings,
					'switch_label_text_align',
					$bp_name,
					$schemas['switch_label_text_align']
				)
			);

			$decls = sprintf(
				'--dsm-dm-toggle-label-size:%1$s;--dsm-dm-toggle-label-weight:%2$s;--dsm-dm-toggle-label-letter-spacing:%3$s;--dsm-dm-toggle-label-line-height:%4$s;--dsm-dm-toggle-label-text-align:%5$s;',
				esc_attr( $size ),
				esc_attr( $weight ),
				esc_attr( $letter ),
				esc_attr( $line ),
				esc_attr( $align )
			);

			if ( 'desktop' === $bp_name ) {
				$css .= sprintf( '%s{%s}', $selector, $decls );
				continue;
			}

			$max_width = $this->get_breakpoint_media_max_px( $breakpoint );
			if ( null === $max_width ) {
				continue;
			}

			$css .= sprintf(
				'@media (max-width:%1$dpx){%2$s{%3$s}}',
				$max_width,
				$selector,
				$decls
			);
		}

		/**
		 * Filter floating-switch label typography responsive CSS.
		 *
		 * @param string               $css      CSS.
		 * @param array<string, mixed> $settings Settings.
		 */
		return (string) apply_filters( 'dsm_dark_mode_floating_switch_typography_css', $css, $settings );
	}

	/**
	 * Print floating-switch label typography CSS early (FOUC-safe Divi breakpoints).
	 *
	 * @return void
	 */
	public function print_floating_switch_typography_css(): void {
		if ( ! $this->should_load_on_current_request() ) {
			return;
		}

		$css = $this->build_floating_switch_typography_css();

		if ( '' === trim( $css ) ) {
			return;
		}

		echo '<style id="dsm-dark-mode-switch-typography">' . $css . '</style>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- CSS built from sanitized settings.
	}

	/**
	 * Sanitize a CSS length (number + unit) for floating-switch design.
	 *
	 * @param string      $value    Raw length.
	 * @param string|null $fallback Fallback when invalid (null → `0px`).
	 * @return string
	 */
	private function sanitize_css_length( string $value, ?string $fallback = null ): string {
		$fallback = $fallback ?? '0px';
		$value    = trim( sanitize_text_field( $value ) );

		if ( '' === $value ) {
			return $fallback;
		}

		if ( preg_match( '/^-?\d+(\.\d+)?(px|em|rem|%|vh|vw)?$/i', $value ) ) {
			if ( ! preg_match( '/(px|em|rem|%|vh|vw)$/i', $value ) ) {
				$value .= 'px';
			}

			return $value;
		}

		return $fallback;
	}

	/**
	 * Optional CSS length (empty allowed — icon size inherits from switch size).
	 *
	 * @param string $value Raw length.
	 * @return string
	 */
	private function sanitize_optional_css_length( string $value ): string {
		$value = trim( $value );
		if ( '' === $value ) {
			return '';
		}

		return $this->sanitize_css_length( $value, '' );
	}

	/**
	 * Sanitize a box-shadow CSS value (string).
	 *
	 * @param string $value    Raw shadow.
	 * @param string $fallback Fallback when invalid.
	 * @return string
	 */
	private function sanitize_box_shadow( string $value, string $fallback ): string {
		$value = trim( wp_strip_all_tags( $value ) );
		$value = str_replace( array( "\0", '\\0', ';', '{', '}', '<' ), '', $value );

		if ( '' === $value ) {
			return $fallback;
		}

		if ( 'none' === strtolower( $value ) ) {
			return 'none';
		}

		// Conservative allowlist: lengths, colors (incl. var(--gcid-…)), inset, commas.
		if ( ! preg_match( '/^[a-zA-Z0-9_\s\.\,\-\%#\(\)\/]+$/i', $value ) ) {
			return $fallback;
		}

		if ( preg_match( '/expression\s*\(|javascript\s*:|url\s*\(/i', $value ) ) {
			return $fallback;
		}

		return sanitize_text_field( $value );
	}

	/**
	 * Whether a value looks like a border leaf (styles/radius) vs breakpoint map.
	 *
	 * @param array<string, mixed> $value Candidate.
	 * @return bool
	 */
	private function is_switch_border_leaf( array $value ): bool {
		return isset( $value['styles'] ) || isset( $value['radius'] );
	}

	/**
	 * Soft-migrate a border value to a breakpoint map.
	 *
	 * @param mixed                $raw      Raw border.
	 * @param array<string, mixed> $fallback Default leaf.
	 * @return array<string, mixed>
	 */
	private function migrate_switch_border_to_map( $raw, array $fallback ): array {
		if ( ! is_array( $raw ) ) {
			return array( 'desktop' => $this->sanitize_switch_border( $fallback ) );
		}
		if ( $this->is_switch_border_leaf( $raw ) ) {
			return array( 'desktop' => $this->sanitize_switch_border( $raw ) );
		}
		$out = array();
		foreach ( array( 'desktop', 'tablet', 'tabletWide', 'phone', 'phoneWide' ) as $bp ) {
			if ( isset( $raw[ $bp ] ) && is_array( $raw[ $bp ] ) ) {
				$out[ $bp ] = $this->sanitize_switch_border( $raw[ $bp ] );
			}
		}
		if ( ! isset( $out['desktop'] ) ) {
			$out['desktop'] = $this->sanitize_switch_border( $fallback );
		}
		return $out;
	}

	/**
	 * Soft-migrate a box-shadow value to a breakpoint map.
	 *
	 * @param mixed                $raw      Raw shadow.
	 * @param array<string, mixed> $fallback Default leaf.
	 * @return array<string, mixed>
	 */
	private function migrate_switch_box_shadow_to_map( $raw, array $fallback ): array {
		if ( is_string( $raw ) ) {
			return array( 'desktop' => $this->parse_box_shadow_css( $raw, $fallback ) );
		}
		if ( ! is_array( $raw ) ) {
			return array( 'desktop' => $fallback );
		}
		// Leaf: has horizontal/blur/style and no desktop key.
		if ( ( isset( $raw['horizontal'] ) || isset( $raw['blur'] ) || isset( $raw['style'] ) )
			&& ! isset( $raw['desktop'] ) && ! isset( $raw['tablet'] ) && ! isset( $raw['phone'] )
		) {
			return array( 'desktop' => $this->sanitize_switch_box_shadow( $raw, $fallback ) );
		}
		$out = array();
		foreach ( array( 'desktop', 'tablet', 'tabletWide', 'phone', 'phoneWide' ) as $bp ) {
			if ( isset( $raw[ $bp ] ) && is_array( $raw[ $bp ] ) ) {
				$out[ $bp ] = $this->sanitize_switch_box_shadow( $raw[ $bp ], $fallback );
			}
		}
		if ( ! isset( $out['desktop'] ) ) {
			$out['desktop'] = $this->sanitize_switch_box_shadow( $fallback, $fallback );
		}
		return $out;
	}

	/**
	 * Resolve border/shadow leaf at breakpoint (phone ← tablet ← desktop).
	 *
	 * @param array<string, mixed> $map               Breakpoint map.
	 * @param string               $breakpoint_name   Breakpoint.
	 * @param array<string, mixed> $fallback          Fallback leaf.
	 * @param string               $kind              border|shadow.
	 * @return array<string, mixed>
	 */
	private function resolve_switch_design_map_leaf( array $map, string $breakpoint_name, array $fallback, string $kind ): array {
		$ladder = array( 'desktop', 'tablet', 'phone' );
		$bp     = $breakpoint_name;
		if ( 'tabletWide' === $bp ) {
			$bp = 'tablet';
		}
		if ( 'phoneWide' === $bp ) {
			$bp = 'phone';
		}
		$idx = array_search( $bp, $ladder, true );
		if ( false === $idx ) {
			$idx = 0;
		}
		for ( $i = (int) $idx; $i >= 0; $i-- ) {
			$key = $ladder[ $i ];
			if ( isset( $map[ $key ] ) && is_array( $map[ $key ] ) ) {
				return 'border' === $kind
					? $this->sanitize_switch_border( $map[ $key ] )
					: $this->sanitize_switch_box_shadow( $map[ $key ], $fallback );
			}
		}
		return $fallback;
	}

	/**
	 * Soft-migrate Phase 1 flat border/shadow keys into nested Divi-like shapes,
	 * then wrap leaves as `{ desktop: leaf }` breakpoint maps.
	 *
	 * Call on the raw option array (before defaults fill nested keys) so custom
	 * flat values are not masked by default nested shapes.
	 *
	 * @param array<string, mixed> $settings Settings snapshot (often raw saved option).
	 * @return array<string, mixed>
	 */
	private function migrate_floating_switch_design_settings( array $settings ): array {
		$defaults             = $this->default_settings;
		$default_border       = isset( $defaults['switch_border']['desktop'] ) && is_array( $defaults['switch_border']['desktop'] )
			? $defaults['switch_border']['desktop']
			: array();
		$default_shadow_light = isset( $defaults['switch_box_shadow_light']['desktop'] ) && is_array( $defaults['switch_box_shadow_light']['desktop'] )
			? $defaults['switch_box_shadow_light']['desktop']
			: array();
		$default_shadow_dark  = isset( $defaults['switch_box_shadow_dark']['desktop'] ) && is_array( $defaults['switch_box_shadow_dark']['desktop'] )
			? $defaults['switch_box_shadow_dark']['desktop']
			: array();

		if ( ! isset( $settings['switch_border'] ) || ! is_array( $settings['switch_border'] ) ) {
			$radius = $this->sanitize_css_length(
				(string) ( $settings['switch_border_radius'] ?? $defaults['switch_border_radius'] ),
				$defaults['switch_border_radius']
			);
			$width  = $this->sanitize_css_length(
				(string) ( $settings['switch_border_width'] ?? $defaults['switch_border_width'] ),
				$defaults['switch_border_width']
			);
			$color  = $this->sanitize_color(
				(string) ( $settings['switch_border_color_light'] ?? '' ),
				$defaults['switch_border_color_light']
			);

			$settings['switch_border'] = array(
				'desktop' => array(
					'styles' => array(
						'all' => array(
							'width' => $width,
							'color' => $color,
							'style' => 'solid',
						),
					),
					'radius' => array(
						'sync'        => 'on',
						'topLeft'     => $radius,
						'topRight'    => $radius,
						'bottomRight' => $radius,
						'bottomLeft'  => $radius,
					),
				),
			);
		} else {
			$settings['switch_border'] = $this->migrate_switch_border_to_map(
				$settings['switch_border'],
				$default_border
			);
		}

		if ( ! isset( $settings['switch_box_shadow_light'] ) || ! is_array( $settings['switch_box_shadow_light'] ) ) {
			$settings['switch_box_shadow_light'] = array(
				'desktop' => $this->parse_box_shadow_css(
					(string) ( $settings['switch_shadow_light'] ?? $defaults['switch_shadow_light'] ),
					$default_shadow_light
				),
			);
		} else {
			$settings['switch_box_shadow_light'] = $this->migrate_switch_box_shadow_to_map(
				$settings['switch_box_shadow_light'],
				$default_shadow_light
			);
		}

		if ( ! isset( $settings['switch_box_shadow_dark'] ) || ! is_array( $settings['switch_box_shadow_dark'] ) ) {
			$settings['switch_box_shadow_dark'] = array(
				'desktop' => $this->parse_box_shadow_css(
					(string) ( $settings['switch_shadow_dark'] ?? $defaults['switch_shadow_dark'] ),
					$default_shadow_dark
				),
			);
		} else {
			$settings['switch_box_shadow_dark'] = $this->migrate_switch_box_shadow_to_map(
				$settings['switch_box_shadow_dark'],
				$default_shadow_dark
			);
		}

		if ( isset( $settings['switch_border_color_dark'] ) ) {
			$settings['switch_border_color_dark'] = $this->sanitize_color(
				(string) $settings['switch_border_color_dark'],
				$defaults['switch_border_color_dark']
			);
		}

		return $this->sync_floating_switch_flat_design_keys( $settings );
	}

	/**
	 * Derive Phase 1 flat CSS keys from nested border / box-shadow shapes.
	 *
	 * @param array<string, mixed> $settings Settings snapshot.
	 * @return array<string, mixed>
	 */
	private function sync_floating_switch_flat_design_keys( array $settings ): array {
		$defaults             = $this->default_settings;
		$default_border_leaf  = isset( $defaults['switch_border']['desktop'] ) && is_array( $defaults['switch_border']['desktop'] )
			? $defaults['switch_border']['desktop']
			: array();
		$default_shadow_light = isset( $defaults['switch_box_shadow_light']['desktop'] ) && is_array( $defaults['switch_box_shadow_light']['desktop'] )
			? $defaults['switch_box_shadow_light']['desktop']
			: $defaults['switch_box_shadow_light'];
		$default_shadow_dark  = isset( $defaults['switch_box_shadow_dark']['desktop'] ) && is_array( $defaults['switch_box_shadow_dark']['desktop'] )
			? $defaults['switch_box_shadow_dark']['desktop']
			: $defaults['switch_box_shadow_dark'];

		$border_map = is_array( $settings['switch_border'] ?? null )
			? $settings['switch_border']
			: $defaults['switch_border'];
		$border     = $this->resolve_switch_design_map_leaf(
			is_array( $border_map ) ? $border_map : array(),
			'desktop',
			$default_border_leaf,
			'border'
		);
		$all        = is_array( $border['styles']['all'] ?? null ) ? $border['styles']['all'] : array();
		$radius     = is_array( $border['radius'] ?? null ) ? $border['radius'] : array();

		$settings['switch_border_width']       = $this->sanitize_css_length(
			(string) ( $all['width'] ?? $defaults['switch_border_width'] ),
			$defaults['switch_border_width']
		);
		$settings['switch_border_color_light'] = $this->sanitize_color(
			(string) ( $all['color'] ?? '' ),
			$defaults['switch_border_color_light']
		);
		$settings['switch_border_radius']      = $this->compose_border_radius_css( $radius );
		$settings['switch_border_color_dark']  = $this->sanitize_color(
			(string) ( $settings['switch_border_color_dark'] ?? '' ),
			$defaults['switch_border_color_dark']
		);

		$shadow_light_leaf = $this->resolve_switch_design_map_leaf(
			is_array( $settings['switch_box_shadow_light'] ?? null )
				? $settings['switch_box_shadow_light']
				: array(),
			'desktop',
			is_array( $default_shadow_light ) ? $default_shadow_light : array(),
			'shadow'
		);
		$shadow_dark_leaf  = $this->resolve_switch_design_map_leaf(
			is_array( $settings['switch_box_shadow_dark'] ?? null )
				? $settings['switch_box_shadow_dark']
				: array(),
			'desktop',
			is_array( $default_shadow_dark ) ? $default_shadow_dark : array(),
			'shadow'
		);

		$settings['switch_shadow_light'] = $this->compose_box_shadow_css(
			$shadow_light_leaf,
			$defaults['switch_shadow_light']
		);
		$settings['switch_shadow_dark']  = $this->compose_box_shadow_css(
			$shadow_dark_leaf,
			$defaults['switch_shadow_dark']
		);

		return $settings;
	}

	/**
	 * Sanitize switch border.
	 *
	 * @param array<string, mixed> $border Raw border leaf.
	 * @return array<string, mixed>
	 */
	private function sanitize_switch_border( array $border ): array {
		$defaults_raw = $this->default_settings['switch_border'];
		$defaults     = isset( $defaults_raw['desktop'] ) && is_array( $defaults_raw['desktop'] )
			? $defaults_raw['desktop']
			: $defaults_raw;
		$styles       = is_array( $border['styles'] ?? null ) ? $border['styles'] : array();
		$all_in       = is_array( $styles['all'] ?? null ) ? $styles['all'] : array();
		$radius       = is_array( $border['radius'] ?? null ) ? $border['radius'] : array();

		$default_width = is_array( $defaults['styles']['all'] ?? null )
			? (string) ( $defaults['styles']['all']['width'] ?? '1px' )
			: '1px';
		$default_color = is_array( $defaults['styles']['all'] ?? null )
			? (string) ( $defaults['styles']['all']['color'] ?? 'rgba(0, 0, 0, 0.1)' )
			: 'rgba(0, 0, 0, 0.1)';

		$width = $this->sanitize_css_length(
			(string) ( $all_in['width'] ?? $border['width'] ?? $default_width ),
			$default_width
		);
		$color = $this->sanitize_color(
			(string) ( $all_in['color'] ?? $border['color'] ?? '' ),
			$default_color
		);
		$style = $this->sanitize_border_style(
			(string) ( $all_in['style'] ?? $border['style'] ?? 'solid' )
		);

		$sanitized_styles = array(
			'all' => array(
				'width' => $width,
				'color' => $color,
				'style' => $style,
			),
		);

		foreach ( array( 'top', 'right', 'bottom', 'left' ) as $side ) {
			if ( ! isset( $styles[ $side ] ) || ! is_array( $styles[ $side ] ) ) {
				continue;
			}

			$side_styles               = $styles[ $side ];
			$sanitized_styles[ $side ] = array(
				'width' => $this->sanitize_css_length(
					(string) ( $side_styles['width'] ?? $width ),
					$width
				),
				'color' => $this->sanitize_color(
					(string) ( $side_styles['color'] ?? $color ),
					$color
				),
				'style' => $this->sanitize_border_style(
					(string) ( $side_styles['style'] ?? $style )
				),
			);
		}

		$default_tl = (string) ( $defaults['radius']['topLeft'] ?? '999px' );
		$tl         = $this->sanitize_css_length(
			(string) ( $radius['topLeft'] ?? $default_tl ),
			$default_tl
		);

		return array(
			'styles' => $sanitized_styles,
			'radius' => array(
				'sync'        => 'on' === ( $radius['sync'] ?? 'on' ) ? 'on' : 'off',
				'topLeft'     => $tl,
				'topRight'    => $this->sanitize_css_length(
					(string) ( $radius['topRight'] ?? $tl ),
					$tl
				),
				'bottomRight' => $this->sanitize_css_length(
					(string) ( $radius['bottomRight'] ?? $tl ),
					$tl
				),
				'bottomLeft'  => $this->sanitize_css_length(
					(string) ( $radius['bottomLeft'] ?? $tl ),
					$tl
				),
			),
		);
	}

	/**
	 * Sanitize switch box shadow.
	 *
	 * @param array<string, mixed> $shadow   Raw shadow leaf.
	 * @param array<string, mixed> $fallback Default shadow shape.
	 * @return array<string, mixed>
	 */
	private function sanitize_switch_box_shadow( array $shadow, array $fallback ): array {
		$style = sanitize_key( (string) ( $shadow['style'] ?? $fallback['style'] ) );
		if ( '' === $style ) {
			$style = (string) $fallback['style'];
		}

		$position = sanitize_key( (string) ( $shadow['position'] ?? $fallback['position'] ) );
		if ( ! in_array( $position, array( 'outer', 'inner' ), true ) ) {
			$position = (string) $fallback['position'];
		}

		return array(
			'style'      => $style,
			'position'   => $position,
			'horizontal' => $this->sanitize_css_length(
				(string) ( $shadow['horizontal'] ?? $fallback['horizontal'] ),
				(string) $fallback['horizontal']
			),
			'vertical'   => $this->sanitize_css_length(
				(string) ( $shadow['vertical'] ?? $fallback['vertical'] ),
				(string) $fallback['vertical']
			),
			'blur'       => $this->sanitize_css_length(
				(string) ( $shadow['blur'] ?? $fallback['blur'] ),
				(string) $fallback['blur']
			),
			'spread'     => $this->sanitize_css_length(
				(string) ( $shadow['spread'] ?? $fallback['spread'] ),
				(string) $fallback['spread']
			),
			'color'      => $this->sanitize_color(
				(string) ( $shadow['color'] ?? '' ),
				(string) $fallback['color']
			),
		);
	}

	/**
	 * Parse box shadow CSS.
	 *
	 * @param string               $css Legacy CSS box-shadow string.
	 * @param array<string, mixed> $fallback Structured fallback.
	 * @return array<string, mixed>
	 */
	private function parse_box_shadow_css( string $css, array $fallback ): array {
		$raw = trim( wp_strip_all_tags( $css ) );

		if ( '' === $raw || 'none' === strtolower( $raw ) ) {
			return array_merge(
				$fallback,
				array(
					'style'      => 'none',
					'horizontal' => '0px',
					'vertical'   => '0px',
					'blur'       => '0px',
					'spread'     => '0px',
				)
			);
		}

		$position = 'outer';
		if ( preg_match( '/^inset\b/i', $raw ) ) {
			$position = 'inner';
			$raw      = trim( (string) preg_replace( '/^inset\s+/i', '', $raw, 1 ) );
		}

		$color = (string) $fallback['color'];
		if ( preg_match( '/^(.*?)(#[0-9a-fA-F]{3,8}|rgba?\([^)]+\)|hsla?\([^)]+\)|[a-zA-Z]+)\s*$/', $raw, $parts ) ) {
			$raw   = trim( $parts[1] );
			$color = $this->sanitize_color( $parts[2], (string) $fallback['color'] );
		}

		$lengths = preg_split( '/\s+/', $raw );
		if ( ! is_array( $lengths ) ) {
			$lengths = array();
		}

		return array(
			'style'      => 'preset1',
			'position'   => $position,
			'horizontal' => $this->sanitize_css_length(
				(string) ( $lengths[0] ?? $fallback['horizontal'] ),
				(string) $fallback['horizontal']
			),
			'vertical'   => $this->sanitize_css_length(
				(string) ( $lengths[1] ?? $fallback['vertical'] ),
				(string) $fallback['vertical']
			),
			'blur'       => $this->sanitize_css_length(
				(string) ( $lengths[2] ?? '0px' ),
				'0px'
			),
			'spread'     => $this->sanitize_css_length(
				(string) ( $lengths[3] ?? '0px' ),
				'0px'
			),
			'color'      => $color,
		);
	}

	/**
	 * Compose box shadow CSS.
	 *
	 * @param array<string, mixed> $shadow   Structured shadow.
	 * @param string               $fallback CSS fallback.
	 * @return string
	 */
	private function compose_box_shadow_css( array $shadow, string $fallback ): string {
		$style = (string) ( $shadow['style'] ?? 'none' );

		if ( 'none' === $style ) {
			return 'none';
		}

		$position   = ( 'inner' === ( $shadow['position'] ?? 'outer' ) ) ? 'inset ' : '';
		$horizontal = (string) ( $shadow['horizontal'] ?? '0px' );
		$vertical   = (string) ( $shadow['vertical'] ?? '0px' );
		$blur       = (string) ( $shadow['blur'] ?? '0px' );
		$spread     = (string) ( $shadow['spread'] ?? '0px' );
		$color_raw  = (string) ( $shadow['color'] ?? '#000000' );
		$color      = $this->normalize_color_for_css( $color_raw );
		if ( '' === $color ) {
			$color = '#000000';
		}

		$composed = trim(
			sprintf(
				'%s%s %s %s %s %s',
				$position,
				$horizontal,
				$vertical,
				$blur,
				$spread,
				$color
			)
		);

		return $this->sanitize_box_shadow( $composed, $fallback );
	}

	/**
	 * Compose border radius CSS.
	 *
	 * @param array<string, mixed> $radius Radius corners.
	 * @return string
	 */
	private function compose_border_radius_css( array $radius ): string {
		$defaults_raw  = is_array( $this->default_settings['switch_border'] ?? null )
			? $this->default_settings['switch_border']
			: array();
		$defaults_leaf = isset( $defaults_raw['desktop'] ) && is_array( $defaults_raw['desktop'] )
			? $defaults_raw['desktop']
			: $defaults_raw;
		$defaults      = is_array( $defaults_leaf['radius'] ?? null )
			? $defaults_leaf['radius']
			: array();
		$default_tl    = (string) ( $defaults['topLeft'] ?? $this->default_settings['switch_border_radius'] ?? '999px' );

		$tl = $this->sanitize_css_length(
			(string) ( $radius['topLeft'] ?? $default_tl ),
			$default_tl
		);
		$tr = $this->sanitize_css_length(
			(string) ( $radius['topRight'] ?? $tl ),
			$tl
		);
		$br = $this->sanitize_css_length(
			(string) ( $radius['bottomRight'] ?? $tl ),
			$tl
		);
		$bl = $this->sanitize_css_length(
			(string) ( $radius['bottomLeft'] ?? $tl ),
			$tl
		);

		if ( $tl === $tr && $tr === $br && $br === $bl ) {
			return $tl;
		}

		return trim( sprintf( '%s %s %s %s', $tl, $tr, $br, $bl ) );
	}

	/**
	 * Sanitize border style.
	 *
	 * @param string $style Border style slug.
	 * @return string
	 */
	private function sanitize_border_style( string $style ): string {
		$allowed = array( 'solid', 'dashed', 'dotted', 'double', 'groove', 'ridge', 'outset', 'inset', 'none' );
		$style   = sanitize_key( $style );

		return in_array( $style, $allowed, true ) ? $style : 'solid';
	}

	/**
	 * Sanitize scope.
	 *
	 * @param string $scope Scope slug.
	 * @return string
	 */
	private function sanitize_scope( string $scope ): string {
		$allowed = array( 'entire_site', 'include_pages', 'exclude_pages', 'per_page' );
		$scope   = sanitize_key( $scope );

		return in_array( $scope, $allowed, true ) ? $scope : 'entire_site';
	}

	/**
	 * Sanitize page IDs.
	 *
	 * @param string $raw Comma-separated post IDs.
	 * @return string
	 */
	private function sanitize_page_ids( string $raw ): string {
		$parts = array_filter(
			array_map(
				static function ( $id ) {
					$id = absint( trim( (string) $id ) );
					return $id > 0 ? (string) $id : '';
				},
				explode( ',', $raw )
			)
		);

		return implode( ',', array_unique( $parts ) );
	}

	/**
	 * Sanitize image brightness.
	 *
	 * @param string $raw Brightness percent (50–100).
	 * @return string
	 */
	private function sanitize_image_brightness( string $raw ): string {
		$value = (int) absint( $raw );

		if ( $value < 50 ) {
			$value = 50;
		}
		if ( $value > 100 ) {
			$value = 100;
		}

		return (string) $value;
	}

	/**
	 * Sanitize optional custom CSS printed under dark mode.
	 *
	 * @param string $css Raw CSS.
	 * @return string
	 */
	private function sanitize_custom_css( string $css ): string {
		$css = wp_strip_all_tags( $css );
		$css = str_replace( array( "\0", '\\0' ), '', $css );

		// Strip common CSS-injection vectors.
		$css = preg_replace( '/@import\b[^;]*;/i', '', $css ) ?? '';
		$css = preg_replace( '/expression\s*\(/i', '', $css ) ?? '';
		$css = preg_replace( '/javascript\s*:/i', '', $css ) ?? '';
		$css = preg_replace( '/-moz-binding\s*:/i', '', $css ) ?? '';
		$css = preg_replace( '/behavior\s*:/i', '', $css ) ?? '';

		/**
		 * Filter sanitized custom dark-mode CSS before save.
		 *
		 * @param string $css Sanitized CSS.
		 */
		return (string) apply_filters( 'dsm_dark_mode_sanitize_custom_css', $css );
	}

	/**
	 * Sanitize keyboard shortcut.
	 *
	 * @param string $shortcut Shortcut slug (e.g. alt+d).
	 * @return string
	 */
	private function sanitize_keyboard_shortcut( string $shortcut ): string {
		$shortcut = strtolower( trim( $shortcut ) );
		$allowed  = array( 'alt+d', 'alt+m', 'ctrl+alt+d', 'shift+alt+d' );

		return in_array( $shortcut, $allowed, true ) ? $shortcut : 'alt+d';
	}

	/**
	 * Sanitize floating-switch preference reset mode.
	 *
	 * @param string $mode Reset mode slug.
	 * @return string
	 */
	private function sanitize_switch_reset_mode( string $mode ): string {
		$allowed = array( 'off', 'long_press', 'double_click', 'both' );
		$mode    = sanitize_key( $mode );

		return in_array( $mode, $allowed, true ) ? $mode : 'both';
	}

	/**
	 * Sanitize an integer string within an inclusive range.
	 *
	 * @param string $raw      Raw value.
	 * @param int    $min      Minimum inclusive.
	 * @param int    $max      Maximum inclusive.
	 * @param int    $fallback Fallback when non-numeric.
	 * @return string
	 */
	private function sanitize_int_range( string $raw, int $min, int $max, int $fallback ): string {
		$trimmed = trim( $raw );
		if ( '' === $trimmed || ! is_numeric( $trimmed ) ) {
			return (string) $fallback;
		}

		$value = (int) $trimmed;
		if ( $value < $min ) {
			$value = $min;
		}
		if ( $value > $max ) {
			$value = $max;
		}

		return (string) $value;
	}

	/**
	 * Title / tooltip hint for preference reset based on configured mode.
	 *
	 * @param string $mode Sanitized switch_reset_mode.
	 * @return string Empty when reset is off.
	 */
	private function get_switch_reset_hint_i18n( string $mode ): string {
		switch ( $mode ) {
			case 'long_press':
				return __(
					'Long-press to reset your saved preference',
					'dsm-supreme-modules-pro-for-divi'
				);
			case 'double_click':
				return __(
					'Double-click to reset your saved preference',
					'dsm-supreme-modules-pro-for-divi'
				);
			case 'both':
				return __(
					'Long-press or double-click to reset your saved preference',
					'dsm-supreme-modules-pro-for-divi'
				);
			case 'off':
			default:
				return '';
		}
	}

	/**
	 * Sanitize per-gcid dark colour map.
	 *
	 * @param mixed $raw Raw mappings (array or JSON string).
	 * @return array<string, string>
	 */
	private function sanitize_gcid_mappings( $raw ): array {
		if ( is_string( $raw ) ) {
			$decoded = json_decode( $raw, true );
			$raw     = is_array( $decoded ) ? $decoded : array();
		}

		if ( ! is_array( $raw ) ) {
			$raw = array();
		}

		$out = array();
		foreach ( self::GCID_TOKEN_KEYS as $token ) {
			$color = isset( $raw[ $token ] ) ? trim( (string) $raw[ $token ] ) : '';
			if ( '' === $color ) {
				$out[ $token ] = '';
				continue;
			}
			$sanitized     = $this->sanitize_color( $color, '' );
			$out[ $token ] = $sanitized;
		}

		/**
		 * Filter sanitized gcid dark mappings.
		 *
		 * @param array<string, string> $out Sanitized map.
		 * @param mixed                 $raw Raw input.
		 */
		return (array) apply_filters( 'dsm_dark_mode_gcid_mappings', $out, $raw );
	}

	/**
	 * Sanitize custom CSS variable → colour pairs (max 12).
	 *
	 * Kept for backward-compatible FE print of existing saved mappings; the
	 * customiser UI for editing these was removed.
	 *
	 * @param mixed $raw Raw list.
	 * @return array<int, array{property: string, color: string}>
	 */
	private function sanitize_custom_var_mappings( $raw ): array {
		if ( is_string( $raw ) ) {
			$decoded = json_decode( $raw, true );
			$raw     = is_array( $decoded ) ? $decoded : array();
		}

		if ( ! is_array( $raw ) ) {
			return array();
		}

		$out   = array();
		$count = 0;
		foreach ( $raw as $row ) {
			if ( $count >= 12 ) {
				break;
			}
			if ( ! is_array( $row ) ) {
				continue;
			}
			$property = isset( $row['property'] ) ? (string) $row['property'] : '';
			$color    = isset( $row['color'] ) ? (string) $row['color'] : '';
			$property = $this->sanitize_css_custom_property( $property );
			$color    = '' === trim( $color ) ? '' : $this->sanitize_color( $color, '' );
			if ( '' === $property || '' === $color ) {
				continue;
			}
			$out[] = array(
				'property' => $property,
				'color'    => $color,
			);
			++$count;
		}

		/**
		 * Filter sanitized custom CSS variable mappings.
		 *
		 * @param array<int, array{property: string, color: string}> $out Sanitized list.
		 * @param mixed                                               $raw Raw input.
		 */
		return (array) apply_filters( 'dsm_dark_mode_custom_var_mappings', $out, $raw );
	}

	/**
	 * Sanitize CSS custom property.
	 *
	 * @param string $property Raw custom property name.
	 * @return string Empty when invalid.
	 */
	private function sanitize_css_custom_property( string $property ): string {
		$property = trim( $property );
		if ( '' === $property ) {
			return '';
		}
		if ( 0 !== strpos( $property, '--' ) ) {
			$property = '--' . ltrim( $property, '-' );
		}
		if ( ! preg_match( '/^--[a-zA-Z_][a-zA-Z0-9_-]*$/', $property ) ) {
			return '';
		}

		return $property;
	}

	/**
	 * Sanitize URL.
	 *
	 * @param string $url Raw URL.
	 * @return string
	 */
	private function sanitize_url( string $url ): string {
		$url = trim( $url );
		if ( '' === $url ) {
			return '';
		}

		$sanitized = esc_url_raw( $url );

		return is_string( $sanitized ) ? $sanitized : '';
	}

	/**
	 * Normalize logo setting to a URL string (string or Upload-shaped `{ src }` array).
	 *
	 * @param mixed $value Raw logo value from REST/modal.
	 * @return string
	 */
	private function normalize_logo_url_value( $value ): string {
		if ( is_string( $value ) ) {
			return $value;
		}

		if ( is_array( $value ) && isset( $value['src'] ) && is_string( $value['src'] ) ) {
			return $value['src'];
		}

		return '';
	}

	/**
	 * Conservative CSS selector sanitizer for logo targeting.
	 *
	 * @param string $selector Raw selector list.
	 * @param string $fallback Fallback when empty/invalid.
	 * @return string
	 */
	private function sanitize_css_selector( string $selector, string $fallback ): string {
		$selector = trim( wp_strip_all_tags( $selector ) );
		$selector = preg_replace( '/[<>"\']/', '', $selector ) ?? '';
		$selector = preg_replace( '/expression\s*\(/i', '', $selector ) ?? '';
		$selector = preg_replace( '/javascript\s*:/i', '', $selector ) ?? '';

		if ( '' === $selector ) {
			return $fallback;
		}

		// Allow common selector characters only.
		if ( ! preg_match( '/^[a-zA-Z0-9\s\.\#\,\:\[\]\=\*_\-\(\)>~+]+$/', $selector ) ) {
			return $fallback;
		}

		return $selector;
	}

	/**
	 * Sanitize time hhmm.
	 *
	 * @param string $time     HH:MM.
	 * @param string $fallback Fallback.
	 * @return string
	 */
	private function sanitize_time_hhmm( string $time, string $fallback ): string {
		$time = trim( $time );
		if ( preg_match( '/^([01]?\d|2[0-3]):([0-5]\d)$/', $time, $m ) ) {
			return sprintf( '%02d:%02d', (int) $m[1], (int) $m[2] );
		}

		return $fallback;
	}

	/**
	 * Site timezone offset in minutes east of UTC (for FOUC / FE schedule).
	 *
	 * @return int
	 */
	public function get_timezone_offset_minutes(): int {
		try {
			$now = new \DateTimeImmutable( 'now', wp_timezone() );

			return (int) round( $now->getOffset() / 60 );
		} catch ( \Exception $e ) {
			return (int) round( (float) get_option( 'gmt_offset', 0 ) * 60 );
		}
	}

	/**
	 * Whether current site time falls in the dark schedule window.
	 *
	 * Supports overnight windows (e.g. 18:00–06:00).
	 *
	 * @param array<string, mixed>|null $settings Optional settings.
	 * @return bool
	 */
	public function is_within_dark_schedule( ?array $settings = null ): bool {
		$settings = is_array( $settings ) ? wp_parse_args( $settings, $this->default_settings ) : $this->get_settings();

		if ( 'on' !== ( $settings['schedule_enabled'] ?? 'off' ) ) {
			return false;
		}

		$start = $this->sanitize_time_hhmm( (string) ( $settings['schedule_start'] ?? '18:00' ), '18:00' );
		$end   = $this->sanitize_time_hhmm( (string) ( $settings['schedule_end'] ?? '06:00' ), '06:00' );

		try {
			$now = new \DateTimeImmutable( 'now', wp_timezone() );
		} catch ( \Exception $e ) {
			$now = new \DateTimeImmutable( 'now' );
		}

		$mins       = ( (int) $now->format( 'H' ) * 60 ) + (int) $now->format( 'i' );
		$start_mins = $this->hhmm_to_minutes( $start );
		$end_mins   = $this->hhmm_to_minutes( $end );

		if ( $start_mins === $end_mins ) {
			return true;
		}

		if ( $start_mins < $end_mins ) {
			return $mins >= $start_mins && $mins < $end_mins;
		}

		// Overnight: e.g. 18:00 → 06:00.
		return $mins >= $start_mins || $mins < $end_mins;
	}

	/**
	 * Hhmm to minutes.
	 *
	 * @param string $hhmm HH:MM.
	 * @return int
	 */
	private function hhmm_to_minutes( string $hhmm ): int {
		$parts = explode( ':', $hhmm );

		return ( (int) ( $parts[0] ?? 0 ) * 60 ) + (int) ( $parts[1] ?? 0 );
	}

	/**
	 * Sanitize a ColorPicker leaf for persistence.
	 *
	 * Divi Global / Variable colours arrive as `$variable({"type":"color",…})$`
	 * or bare `gcid-*` (and sometimes already as `var(--gcid-…)`). Those must
	 * survive save — hex-only sanitizing was stripping them to the fallback.
	 *
	 * @param string $color    Raw color.
	 * @param string $fallback Fallback hex (or empty for optional maps).
	 * @return string
	 */
	private function sanitize_color( string $color, string $fallback ): string {
		$color = trim( $color );

		if ( '' === $color ) {
			return $fallback;
		}

		if ( strlen( $color ) > 800 ) {
			return $fallback;
		}

		if ( preg_match( '/[<>`]|(\x00)/', $color ) ) {
			return $fallback;
		}

		if ( preg_match( '/\b(?:expression|behavior|javascript|@import)\b/i', $color ) ) {
			return $fallback;
		}

		if ( function_exists( 'sanitize_hex_color' ) ) {
			$hex = sanitize_hex_color( $color );
			if ( is_string( $hex ) && '' !== $hex ) {
				return $hex;
			}
		}

		// Hex (incl. 8-digit), rgb(a), hsl(a), var(--…).
		if ( preg_match( '/^(#([0-9a-fA-F]{3}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})|rgba?\([^;{}]+\)|hsla?\([^;{}]+\)|var\(--[a-zA-Z0-9_-]+(?:,\s*[^;{}]+)?\))$/', $color ) ) {
			return $color;
		}

		// Bare Divi global colour id.
		if ( preg_match( '/^gcid-[a-zA-Z0-9_-]+$/', $color ) ) {
			return $color;
		}

		// Divi ColorPicker global / design variable token — keep for the control swatch.
		$variable_name = $this->extract_divi_color_variable_name( $color );
		if ( is_string( $variable_name ) && '' !== $variable_name ) {
			return $color;
		}

		return $fallback;
	}

	/**
	 * Extract a safe CSS custom-property name from a Divi `$variable({…})$` color token.
	 *
	 * @param string $color Raw ColorPicker value.
	 * @return string|null e.g. `gcid-primary-color`, or null when not a color variable.
	 */
	private function extract_divi_color_variable_name( string $color ): ?string {
		$color = trim( $color );
		if ( ! str_starts_with( $color, '$variable(' ) || ! str_ends_with( $color, ')$' ) ) {
			return null;
		}

		$payload = substr( $color, strlen( '$variable(' ), -2 );
		$decoded = json_decode( $payload, true );
		if ( ! is_array( $decoded ) ) {
			$decoded = json_decode( stripslashes( $payload ), true );
		}
		if ( ! is_array( $decoded ) ) {
			return null;
		}

		$type = isset( $decoded['type'] ) ? strtolower( (string) $decoded['type'] ) : '';
		if ( '' !== $type && 'color' !== $type && 'variable' !== $type ) {
			return null;
		}

		$name = '';
		if ( isset( $decoded['value']['name'] ) && is_string( $decoded['value']['name'] ) ) {
			$name = $decoded['value']['name'];
		} elseif ( isset( $decoded['value'] ) && is_string( $decoded['value'] ) ) {
			$name = $decoded['value'];
		}

		$name = ltrim( trim( $name ), '-' );
		if ( '' === $name || ! preg_match( '/^[a-zA-Z0-9_-]+$/', $name ) ) {
			return null;
		}

		return $name;
	}

	/**
	 * Soft-migrate a stored ColorPicker value to a CSS paint string for emission.
	 *
	 * Stable Divi tokens (`gcid-primary-color`, …) stay as `var(--gcid-…)` so
	 * `html.dsm-dark` remaps apply. Custom globals (`gcid-{uuid}`) are resolved
	 * via Divi `GlobalData` to a concrete paint — FE pages often omit unused
	 * custom `--gcid-*` from `:root`, so bare `var(--gcid-uuid)` paints nothing.
	 *
	 * Hex, rgba, and existing `var(--…)` pass through unchanged.
	 *
	 * @param string $color Sanitized stored color.
	 * @return string CSS paint, or empty when the token cannot be emitted safely.
	 */
	private function normalize_color_for_css( string $color ): string {
		$color = trim( $color );
		if ( '' === $color ) {
			return '';
		}

		$variable_name = $this->extract_divi_color_variable_name( $color );
		if ( ! is_string( $variable_name ) || '' === $variable_name ) {
			if ( preg_match( '/^gcid-[a-zA-Z0-9_-]+$/', $color ) ) {
				$variable_name = $color;
			}
		}

		if ( is_string( $variable_name ) && '' !== $variable_name ) {
			// Remapped system tokens must remain var() so dark-mode gcid overrides win.
			if ( in_array( $variable_name, self::GCID_TOKEN_KEYS, true ) ) {
				return 'var(--' . $variable_name . ')';
			}

			$resolved = $this->resolve_divi_global_color_paint( $color, $variable_name );
			if ( '' !== $resolved ) {
				return $resolved;
			}

			return 'var(--' . $variable_name . ')';
		}

		// Bare var(--gcid-uuid) from older saves — resolve when possible.
		if ( class_exists( '\ET\Builder\Packages\GlobalData\GlobalData' )
			&& 0 === stripos( $color, 'var(' )
		) {
			$gcid = \ET\Builder\Packages\GlobalData\GlobalData::get_global_color_id_from_value( $color );
			if ( is_string( $gcid ) && '' !== $gcid && ! in_array( $gcid, self::GCID_TOKEN_KEYS, true ) ) {
				$resolved = $this->resolve_divi_global_color_paint( $color, $gcid );
				if ( '' !== $resolved ) {
					return $resolved;
				}
			}
		}

		// Unresolved dynamic tokens must not leak into stylesheets.
		if ( false !== strpos( $color, '$variable(' ) ) {
			return '';
		}

		return $color;
	}

	/**
	 * Resolve a Divi global colour id / `$variable` token to a concrete CSS paint.
	 *
	 * Mirrors Chart module’s GlobalData lookup so FE emission does not depend on
	 * the colour appearing in the page’s printed `:root` variable sheet.
	 *
	 * @param string $raw  Original stored value (`$variable…`, bare gcid, or var()).
	 * @param string $gcid Normalised `gcid-…` id.
	 * @return string Concrete hex/rgba/hsl, or empty when unresolvable.
	 */
	private function resolve_divi_global_color_paint( string $raw, string $gcid ): string {
		if ( ! class_exists( '\ET\Builder\Packages\GlobalData\GlobalData' ) ) {
			return '';
		}

		$global_colors = \ET\Builder\Packages\GlobalData\GlobalData::get_global_colors();
		$candidates    = array( $raw, $gcid );

		foreach ( $candidates as $candidate ) {
			if ( ! is_string( $candidate ) || '' === trim( $candidate ) ) {
				continue;
			}

			$resolved = \ET\Builder\Packages\GlobalData\GlobalData::resolve_global_color_variable(
				$candidate,
				$global_colors
			);

			$paint = $this->concrete_css_paint_from_resolved( is_string( $resolved ) ? $resolved : '' );
			if ( '' !== $paint ) {
				return $paint;
			}
		}

		$color_data = \ET\Builder\Packages\GlobalData\GlobalData::get_global_color_by_id( $gcid );
		$palette    = is_array( $color_data ) ? ( $color_data['color'] ?? '' ) : '';
		if ( ! is_string( $palette ) || '' === trim( $palette ) ) {
			return '';
		}

		$nested = \ET\Builder\Packages\GlobalData\GlobalData::resolve_global_color_variable(
			trim( $palette ),
			$global_colors
		);

		$paint = $this->concrete_css_paint_from_resolved( is_string( $nested ) ? $nested : '' );
		if ( '' !== $paint ) {
			return $paint;
		}

		return $this->concrete_css_paint_from_resolved( trim( $palette ) );
	}

	/**
	 * Accept only concrete CSS colour paints (reject leftover tokens / var()).
	 *
	 * @param string $value Resolved candidate.
	 * @return string
	 */
	private function concrete_css_paint_from_resolved( string $value ): string {
		$value = trim( $value );
		if ( '' === $value ) {
			return '';
		}

		if ( false !== strpos( $value, '$variable(' ) ) {
			return '';
		}

		if ( 0 === stripos( $value, 'var(' ) ) {
			return '';
		}

		if ( preg_match( '/^gcid-[a-zA-Z0-9_-]+$/', $value ) ) {
			return '';
		}

		if ( function_exists( 'sanitize_hex_color' ) ) {
			$hex = sanitize_hex_color( $value );
			if ( is_string( $hex ) && '' !== $hex ) {
				return $hex;
			}
		}

		if ( preg_match( '/^(#([0-9a-fA-F]{3}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})|rgba?\([^;{}]+\)|hsla?\([^;{}]+\))$/', $value ) ) {
			return $value;
		}

		return '';
	}

	/**
	 * Parse comma-separated post IDs into int list.
	 *
	 * @param string $raw Comma-separated IDs.
	 * @return int[]
	 */
	private function parse_page_ids_string( string $raw ): array {
		if ( '' === trim( $raw ) ) {
			return array();
		}

		return array_values(
			array_filter(
				array_map(
					'absint',
					explode( ',', $raw )
				)
			)
		);
	}

	/**
	 * Scope IDs for the active display mode.
	 *
	 * @param array<string, mixed> $settings Settings array.
	 * @return int[]
	 */
	private function get_scope_ids_for_active_mode( array $settings ): array {
		$scope = $this->sanitize_scope( (string) ( $settings['display_scope'] ?? 'entire_site' ) );

		if ( 'include_pages' === $scope ) {
			return $this->parse_page_ids_string(
				(string) ( $settings['display_scope_include_ids'] ?? '' )
			);
		}

		if ( 'exclude_pages' === $scope ) {
			return $this->parse_page_ids_string(
				(string) ( $settings['display_scope_exclude_ids'] ?? '' )
			);
		}

		return array();
	}

	/**
	 * Whether dark mode assets should load on the current frontend request.
	 *
	 * The modal Enable control (`is_enabled`) must be on before the FOUC class
	 * or `--gcid-*` palette remap is printed. Display scope then gates pages
	 * without a placeable toggle. A rendered `dsm/dark-mode-toggle` forces FE
	 * assets only after that enable gate.
	 *
	 * @return bool
	 */
	public function should_load_on_current_request(): bool {
		if ( ! function_exists( 'dsm_is_dark_mode_extension_enabled' )
			|| ! dsm_is_dark_mode_extension_enabled() ) {
			return false;
		}

		if ( is_admin() ) {
			return false;
		}

		// Visual Builder canvas iframe: preview lives in the customiser (app window).
		if ( function_exists( 'et_core_is_fb_enabled' ) && et_core_is_fb_enabled() ) {
			return false;
		}

		$settings = $this->get_settings();
		if ( 'on' !== ( $settings['is_enabled'] ?? 'off' ) ) {
			return false;
		}

		if ( $this->current_request_has_placeable_toggle_module() ) {
			return true;
		}

		$post_id = (int) get_queried_object_id();
		$scope   = $this->sanitize_scope( (string) ( $settings['display_scope'] ?? 'entire_site' ) );
		$ids     = $this->get_scope_ids_for_active_mode( $settings );

		switch ( $scope ) {
			case 'include_pages':
				return $post_id > 0 && in_array( $post_id, $ids, true );

			case 'exclude_pages':
				return $post_id <= 0 || ! in_array( $post_id, $ids, true );

			case 'per_page':
				if ( $post_id <= 0 ) {
					return false;
				}
				$page_flag = get_post_meta( $post_id, self::PAGE_META_KEY, true );
				return 'on' === $page_flag;

			case 'entire_site':
			default:
				return true;
		}
	}

	/**
	 * Whether the placeable Dark Mode Toggle module is present on this request.
	 *
	 * Covers post content and active Theme Builder header/body/footer layouts so
	 * early `wp_head` FOUC/palette hooks can run before module render.
	 *
	 * @return bool
	 */
	private function current_request_has_placeable_toggle_module(): bool {
		// Only memoize positives — early `wp_head` may run before Theme Builder
		// layouts resolve; a sticky `false` would suppress FOUC/assets incorrectly.
		static $cached_true = false;

		if ( $cached_true ) {
			return true;
		}

		if (
			class_exists( \DiviSupreme\Includes\DsmFrontendDynamicAssets::class )
			&& \DiviSupreme\Includes\DsmFrontendDynamicAssets::merged_detection_includes_block_slug( 'dsm/dark-mode-toggle' )
		) {
			$cached_true = true;
			return true;
		}

		$needles = array( 'dsm/dark-mode-toggle', 'wp:dsm/dark-mode-toggle' );

		$post_id = (int) get_queried_object_id();
		if ( $post_id > 0 && $this->content_contains_any_needle( (string) get_post_field( 'post_content', $post_id ), $needles ) ) {
			$cached_true = true;
			return true;
		}

		if ( function_exists( 'et_theme_builder_get_template_layouts' ) ) {
			$layouts = et_theme_builder_get_template_layouts();
			if ( is_array( $layouts ) ) {
				foreach ( $layouts as $layout ) {
					if ( ! is_array( $layout ) ) {
						continue;
					}
					$layout_id = isset( $layout['id'] ) ? (int) $layout['id'] : 0;
					if ( $layout_id <= 0 || empty( $layout['enabled'] ) ) {
						continue;
					}
					if ( $this->content_contains_any_needle( (string) get_post_field( 'post_content', $layout_id ), $needles ) ) {
						$cached_true = true;
						return true;
					}
				}
			}
		}

		return false;
	}

	/**
	 * Content contains any needle.
	 *
	 * @param string $content Serialized content.
	 * @param array  $needles Substrings to find.
	 * @return bool
	 */
	private function content_contains_any_needle( string $content, array $needles ): bool {
		if ( '' === $content ) {
			return false;
		}

		foreach ( $needles as $needle ) {
			if ( is_string( $needle ) && '' !== $needle && str_contains( $content, $needle ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Ensure Dark Mode FE script/style are enqueued (render-time safety net).
	 *
	 * Used when the placeable module renders after early scope checks missed it.
	 *
	 * @return void
	 */
	public function ensure_frontend_assets_enqueued(): void {
		if ( ! function_exists( 'dsm_is_dark_mode_extension_enabled' )
			|| ! dsm_is_dark_mode_extension_enabled() ) {
			return;
		}

		if ( function_exists( 'et_core_is_fb_enabled' ) && et_core_is_fb_enabled() ) {
			return;
		}

		$settings = $this->get_settings();
		if ( 'on' !== ( $settings['is_enabled'] ?? 'off' ) ) {
			return;
		}

		if ( wp_script_is( 'dsm-dark-mode-frontend', 'enqueued' ) ) {
			return;
		}

		$this->maybe_enqueue_frontend_assets_unscoped();
	}

	/**
	 * Enqueue + localize Dark Mode FE assets without re-checking display scope.
	 *
	 * Callers must already verify extension enablement / VB canvas rules.
	 *
	 * @return void
	 */
	private function maybe_enqueue_frontend_assets_unscoped(): void {
		if ( ! wp_script_is( 'dsm-dark-mode-frontend', 'registered' ) ) {
			return;
		}

		if ( wp_style_is( 'dsm-dark-mode-frontend', 'registered' ) ) {
			wp_enqueue_style( 'dsm-dark-mode-frontend' );
		}

		wp_enqueue_script( 'dsm-dark-mode-frontend' );

		$config = $this->get_frontend_config();
		$this->enqueue_switch_webfont_assets( $this->get_settings() );

		wp_localize_script(
			'dsm-dark-mode-frontend',
			'dsmDarkModeConfig',
			$config
		);

		/**
		 * Fires when Dark Mode frontend assets are enqueued for the current request.
		 *
		 * @param array<string, mixed> $config   Localized config.
		 * @param array<string, mixed> $settings Settings snapshot.
		 */
		do_action( 'dsm_dark_mode_frontend_loaded', $config, $this->get_settings() );
	}

	/**
	 * Persist per-page enable flag from Visual Builder save payload.
	 *
	 * @param int                  $post_id Post ID.
	 * @param array<string, mixed> $data    REST save payload.
	 * @return void
	 */
	public function save_page_settings_from_rest( int $post_id, array $data ): void {
		if ( $post_id <= 0 ) {
			return;
		}

		$page_settings = $data['pageSettings'] ?? array();
		if ( ! is_array( $page_settings ) ) {
			return;
		}

		if ( ! array_key_exists( 'dsm_dark_mode_page_enabled', $page_settings ) ) {
			return;
		}

		$value = 'on' === $page_settings['dsm_dark_mode_page_enabled'] ? 'on' : 'off';
		update_post_meta( $post_id, self::PAGE_META_KEY, $value );
	}

	/**
	 * Per-page enable flag for scope `per_page`.
	 *
	 * @param int $post_id Post ID.
	 * @return string `on` or `off`.
	 */
	public function get_page_enabled( int $post_id ): string {
		if ( $post_id <= 0 ) {
			return 'off';
		}

		$flag = get_post_meta( $post_id, self::PAGE_META_KEY, true );

		return 'on' === $flag ? 'on' : 'off';
	}

	/**
	 * Frontend script config for wp_localize_script.
	 *
	 * @return array<string, mixed>
	 */
	public function get_frontend_config(): array {
		$settings = $this->get_settings();

		$schemas = $this->get_responsive_layout_schema_defaults();

		// Localize CSS-ready paints (resolve custom gcid tokens) so FE JS reinject
		// matches printed `#dsm-dark-mode-palette` — unused globals are often absent from `:root`.
		// Palette colours: full breakpoint maps + desktop-resolved strings for BC.
		$config = array(
			'storageKey'                      => self::STORAGE_KEY,
			'default_mode'                    => (string) $settings['default_mode'],
			'palette_bg'                      => $this->palette_map_to_css_map( $settings, 'palette_bg' ),
			'palette_text'                    => $this->palette_map_to_css_map( $settings, 'palette_text' ),
			'palette_heading'                 => $this->palette_map_to_css_map( $settings, 'palette_heading' ),
			'palette_link'                    => $this->palette_map_to_css_map( $settings, 'palette_link' ),
			'palette_link_hover'              => $this->palette_map_to_css_map( $settings, 'palette_link_hover' ),
			'palette_accent'                  => $this->palette_map_to_css_map( $settings, 'palette_accent' ),
			'palette_button_text'             => $this->palette_map_to_css_map( $settings, 'palette_button_text' ),
			'palette_surface'                 => $this->palette_map_to_css_map( $settings, 'palette_surface' ),
			'palette_border'                  => $this->palette_map_to_css_map( $settings, 'palette_border' ),
			'palette_input_bg'                => $this->palette_map_to_css_map( $settings, 'palette_input_bg' ),
			'palette_input_text'              => $this->palette_map_to_css_map( $settings, 'palette_input_text' ),
			'palette_input_border'            => $this->palette_map_to_css_map( $settings, 'palette_input_border' ),
			'palette_bg_desktop'              => $this->palette_setting_to_css( $settings, 'palette_bg', 'desktop' ),
			'palette_text_desktop'            => $this->palette_setting_to_css( $settings, 'palette_text', 'desktop' ),
			'palette_heading_desktop'         => $this->palette_setting_to_css( $settings, 'palette_heading', 'desktop' ),
			'palette_link_desktop'            => $this->palette_setting_to_css( $settings, 'palette_link', 'desktop' ),
			'palette_link_hover_desktop'      => $this->palette_setting_to_css( $settings, 'palette_link_hover', 'desktop' ),
			'palette_accent_desktop'          => $this->palette_setting_to_css( $settings, 'palette_accent', 'desktop' ),
			'palette_button_text_desktop'     => $this->palette_setting_to_css( $settings, 'palette_button_text', 'desktop' ),
			'palette_surface_desktop'         => $this->palette_setting_to_css( $settings, 'palette_surface', 'desktop' ),
			'palette_border_desktop'          => $this->palette_setting_to_css( $settings, 'palette_border', 'desktop' ),
			'palette_breakpoints'             => $this->get_palette_breakpoints_for_localize(),
			'is_enabled'                      => (string) ( $settings['is_enabled'] ?? 'off' ),
			'show_floating_switch'            => (string) $settings['show_floating_switch'],
			'switch_style'                    => (string) $settings['switch_style'],
			'switch_content_mode'             => (string) ( $settings['switch_content_mode'] ?? 'default' ),
			'switch_icon_light'               => $this->prepare_switch_icon_for_frontend( $settings['switch_icon_light'] ?? '' ),
			'switch_icon_dark'                => $this->prepare_switch_icon_for_frontend( $settings['switch_icon_dark'] ?? '' ),
			'switch_icon_color_light'         => (string) ( $settings['switch_icon_color_light'] ?? '' ),
			'switch_icon_color_dark'          => (string) ( $settings['switch_icon_color_dark'] ?? '' ),
			'switch_icon_size'                => (string) ( $settings['switch_icon_size'] ?? '' ),
			'switch_label_light'              => (string) ( $settings['switch_label_light'] ?? 'Light' ),
			'switch_label_dark'               => (string) ( $settings['switch_label_dark'] ?? 'Dark' ),
			'switch_label_font'               => is_array( $settings['switch_label_font'] ?? null )
				? $settings['switch_label_font']
				: array(
					'family'        => '',
					'weight'        => '600',
					'size'          => '13px',
					'letterSpacing' => '0px',
					'lineHeight'    => '1.2em',
					'textAlign'     => 'center',
					'textWrap'      => 'nowrap',
					'style'         => array(),
				),
			'switch_label_font_family'        => (string) ( $settings['switch_label_font_family'] ?? 'inherit' ),
			'switch_label_font_family_custom' => (string) ( $settings['switch_label_font_family_custom'] ?? '' ),
			'switch_label_font_size'          => is_array( $settings['switch_label_font_size'] ?? null )
				? $settings['switch_label_font_size']
				: array( 'desktop' => (string) ( $settings['switch_label_font_size'] ?? '13px' ) ),
			'switch_label_font_weight'        => is_array( $settings['switch_label_font_weight'] ?? null )
				? $settings['switch_label_font_weight']
				: array( 'desktop' => (string) ( $settings['switch_label_font_weight'] ?? '600' ) ),
			'switch_label_letter_spacing'     => is_array( $settings['switch_label_letter_spacing'] ?? null )
				? $settings['switch_label_letter_spacing']
				: array( 'desktop' => (string) ( $settings['switch_label_letter_spacing'] ?? '0px' ) ),
			'switch_label_line_height'        => is_array( $settings['switch_label_line_height'] ?? null )
				? $settings['switch_label_line_height']
				: array( 'desktop' => (string) ( $settings['switch_label_line_height'] ?? '1.2em' ) ),
			'switch_label_text_align'         => is_array( $settings['switch_label_text_align'] ?? null )
				? $settings['switch_label_text_align']
				: array( 'desktop' => (string) ( $settings['switch_label_text_align'] ?? 'center' ) ),
			'switch_label_text_transform'     => (string) ( $settings['switch_label_text_transform'] ?? 'none' ),
			'switch_label_text_wrap'          => (string) ( $settings['switch_label_text_wrap'] ?? 'nowrap' ),
			'switch_label_color_light'        => (string) ( $settings['switch_label_color_light'] ?? '' ),
			'switch_label_color_dark'         => (string) ( $settings['switch_label_color_dark'] ?? '' ),
			'switch_image_light_url'          => (string) ( $settings['switch_image_light_url'] ?? '' ),
			'switch_image_dark_url'           => (string) ( $settings['switch_image_dark_url'] ?? '' ),
			'apply_floating_design_to_module' => (string) ( $settings['apply_floating_design_to_module'] ?? 'off' ),
			'switch_z_index'                  => (string) ( $settings['switch_z_index'] ?? '99999' ),
			'custom_dark_css'                 => (string) ( $settings['custom_dark_css'] ?? '' ),
			// Phase 2 maps (full) + desktop-resolved strings for BC consumers.
			'switch_position'                 => is_array( $settings['switch_position'] ?? null )
				? $settings['switch_position']
				: array( 'desktop' => (string) ( $settings['switch_position'] ?? 'bottom_right' ) ),
			'switch_size'                     => is_array( $settings['switch_size'] ?? null )
				? $settings['switch_size']
				: array( 'desktop' => (string) ( $settings['switch_size'] ?? '48px' ) ),
			'switch_padding_x'                => is_array( $settings['switch_padding_x'] ?? null )
				? $settings['switch_padding_x']
				: array( 'desktop' => (string) ( $settings['switch_padding_x'] ?? '14px' ) ),
			'switch_offset_x'                 => is_array( $settings['switch_offset_x'] ?? null )
				? $settings['switch_offset_x']
				: array( 'desktop' => (string) ( $settings['switch_offset_x'] ?? '20px' ) ),
			'switch_offset_y'                 => is_array( $settings['switch_offset_y'] ?? null )
				? $settings['switch_offset_y']
				: array( 'desktop' => (string) ( $settings['switch_offset_y'] ?? '20px' ) ),
			'switch_position_desktop'         => $this->resolve_layout_scalar_for_breakpoint( $settings, 'switch_position', 'desktop', $schemas['switch_position'] ),
			'switch_size_desktop'             => $this->resolve_layout_scalar_for_breakpoint( $settings, 'switch_size', 'desktop', $schemas['switch_size'] ),
			'switch_padding_x_desktop'        => $this->resolve_layout_scalar_for_breakpoint( $settings, 'switch_padding_x', 'desktop', $schemas['switch_padding_x'] ),
			'switch_offset_x_desktop'         => $this->resolve_layout_scalar_for_breakpoint( $settings, 'switch_offset_x', 'desktop', $schemas['switch_offset_x'] ),
			'switch_offset_y_desktop'         => $this->resolve_layout_scalar_for_breakpoint( $settings, 'switch_offset_y', 'desktop', $schemas['switch_offset_y'] ),
			'switch_border'                   => is_array( $settings['switch_border'] ?? null )
				? $settings['switch_border']
				: array(),
			'switch_box_shadow_light'         => is_array( $settings['switch_box_shadow_light'] ?? null )
				? $settings['switch_box_shadow_light']
				: array(),
			'switch_box_shadow_dark'          => is_array( $settings['switch_box_shadow_dark'] ?? null )
				? $settings['switch_box_shadow_dark']
				: array(),
			'switch_border_width'             => (string) $settings['switch_border_width'],
			'switch_border_radius'            => (string) $settings['switch_border_radius'],
			'switch_border_color_light'       => (string) $settings['switch_border_color_light'],
			'switch_border_color_dark'        => (string) $settings['switch_border_color_dark'],
			'switch_bg_light'                 => (string) $settings['switch_bg_light'],
			'switch_bg_dark'                  => (string) $settings['switch_bg_dark'],
			'switch_fg_light'                 => (string) $settings['switch_fg_light'],
			'switch_fg_dark'                  => (string) $settings['switch_fg_dark'],
			'switch_accent'                   => (string) $settings['switch_accent'],
			'switch_track_color'              => (string) $settings['switch_track_color'],
			'switch_shadow_light'             => (string) $settings['switch_shadow_light'],
			'switch_shadow_dark'              => (string) $settings['switch_shadow_dark'],
			'switch_hover_lift'               => (string) $settings['switch_hover_lift'],
			'switch_reset_mode'               => (string) ( $settings['switch_reset_mode'] ?? 'both' ),
			'switch_click_delay_ms'           => (int) ( $settings['switch_click_delay_ms'] ?? 100 ),
			'switch_long_press_ms'            => (int) ( $settings['switch_long_press_ms'] ?? 650 ),
			'module_surface_mode'             => $this->sanitize_module_surface_mode( (string) ( $settings['module_surface_mode'] ?? 'painted' ) ),
			'image_brightness_enabled'        => (string) $settings['image_brightness_enabled'],
			'image_brightness'                => (string) $settings['image_brightness'],
			'keyboard_shortcut_enabled'       => (string) $settings['keyboard_shortcut_enabled'],
			'keyboard_shortcut'               => (string) $settings['keyboard_shortcut'],
			'gcid_mappings'                   => is_array( $settings['gcid_mappings'] ?? null )
				? $settings['gcid_mappings']
				: array(),
			'custom_var_mappings'             => is_array( $settings['custom_var_mappings'] ?? null )
				? $settings['custom_var_mappings']
				: array(),
			'logo_swap_enabled'               => (string) $settings['logo_swap_enabled'],
			'logo_light_url'                  => (string) $settings['logo_light_url'],
			'logo_dark_url'                   => (string) $settings['logo_dark_url'],
			'logo_selector'                   => (string) $settings['logo_selector'],
			'schedule_enabled'                => (string) $settings['schedule_enabled'],
			'schedule_start'                  => (string) $settings['schedule_start'],
			'schedule_end'                    => (string) $settings['schedule_end'],
			'timezone_offset_minutes'         => $this->get_timezone_offset_minutes(),
			'analytics_events_enabled'        => (string) $settings['analytics_events_enabled'],
			'i18n'                            => array(
				'toggleLabel'        => __( 'Toggle color scheme', 'dsm-supreme-modules-pro-for-divi' ),
				'light'              => __( 'Light', 'dsm-supreme-modules-pro-for-divi' ),
				'dark'               => __( 'Dark', 'dsm-supreme-modules-pro-for-divi' ),
				'darkModeOn'         => __( 'Dark mode on', 'dsm-supreme-modules-pro-for-divi' ),
				'darkModeOff'        => __( 'Dark mode off', 'dsm-supreme-modules-pro-for-divi' ),
				'resetPreference'    => __(
					'Reset color scheme preference (use schedule or system)',
					'dsm-supreme-modules-pro-for-divi'
				),
				'longPressResetHint' => $this->get_switch_reset_hint_i18n(
					$this->sanitize_switch_reset_mode( (string) ( $settings['switch_reset_mode'] ?? 'both' ) )
				),
				'shortcutHint'       => __(
					'Keyboard shortcut toggles light and dark mode.',
					'dsm-supreme-modules-pro-for-divi'
				),
			),
		);

		/**
		 * Filter frontend Dark Mode config localized to `dsmDarkModeConfig`.
		 *
		 * @param array<string, mixed> $config   Config.
		 * @param array<string, mixed> $settings Settings snapshot.
		 */
		return (array) apply_filters( 'dsm_dark_mode_frontend_config', $config, $settings );
	}

	/**
	 * Normalize a palette_* setting to an escaped CSS paint (with default fallback).
	 *
	 * Resolves responsive maps via cascade (phone ← tablet ← desktop).
	 *
	 * @param array<string, mixed> $settings        Settings.
	 * @param string               $key             Setting key.
	 * @param string               $breakpoint_name Breakpoint name.
	 * @return string
	 */
	private function palette_setting_to_css( array $settings, string $key, string $breakpoint_name = 'desktop' ): string {
		$schemas    = $this->get_responsive_palette_schema_defaults();
		$schema     = $schemas[ $key ] ?? '';
		$raw        = $this->resolve_palette_color_for_breakpoint( $settings, $key, $breakpoint_name, $schema );
		$normalized = $this->normalize_color_for_css( $raw );
		if ( '' === $normalized ) {
			$normalized = $schema;
		}

		return esc_attr( $normalized );
	}

	/**
	 * Emit palette CSS custom-property declarations for one breakpoint.
	 *
	 * @param array<string, mixed> $settings        Settings.
	 * @param string               $breakpoint_name Breakpoint name.
	 * @return string
	 */
	private function build_palette_var_declarations( array $settings, string $breakpoint_name ): string {
		$pairs = array(
			'palette_bg'          => '--dsm-dm-bg',
			'palette_text'        => '--dsm-dm-text',
			'palette_heading'     => '--dsm-dm-heading',
			'palette_link'        => '--dsm-dm-link',
			'palette_link_hover'  => '--dsm-dm-link-hover',
			'palette_accent'      => '--dsm-dm-accent',
			'palette_button_text' => '--dsm-dm-button-text',
			'palette_surface'     => '--dsm-dm-surface',
			'palette_border'      => '--dsm-dm-border',
		);

		$css = '';
		foreach ( $pairs as $key => $css_var ) {
			$css .= $css_var . ':' . $this->palette_setting_to_css( $settings, $key, $breakpoint_name ) . ';';
		}

		// Form inputs: optional tokens; empty → surface / text / border CSS vars.
		$input_pairs = array(
			'palette_input_bg'     => array( '--dsm-dm-input-bg', 'var(--dsm-dm-surface)' ),
			'palette_input_text'   => array( '--dsm-dm-input-text', 'var(--dsm-dm-text)' ),
			'palette_input_border' => array( '--dsm-dm-input-border', 'var(--dsm-dm-border)' ),
		);
		foreach ( $input_pairs as $key => $pair ) {
			$css_var    = $pair[0];
			$fallback   = $pair[1];
			$raw        = $this->resolve_palette_color_for_breakpoint( $settings, $key, $breakpoint_name, '' );
			$normalized = $this->normalize_color_for_css( $raw );
			$css       .= $css_var . ':' . ( '' !== $normalized ? esc_attr( $normalized ) : $fallback ) . ';';
		}

		return $css;
	}

	/**
	 * Resolve CSS value for a gcid token under dark mode.
	 *
	 * Empty mapping → palette-derived var() remap. Non-empty → direct colour.
	 *
	 * @param array<string, mixed> $settings Settings.
	 * @param string               $token    e.g. gcid-primary-color.
	 * @param string               $fallback CSS value fallback.
	 * @return string
	 */
	private function resolve_gcid_css_value( array $settings, string $token, string $fallback ): string {
		$mappings = isset( $settings['gcid_mappings'] ) && is_array( $settings['gcid_mappings'] )
			? $settings['gcid_mappings']
			: array();
		$custom   = isset( $mappings[ $token ] ) ? trim( (string) $mappings[ $token ] ) : '';

		if ( '' !== $custom ) {
			$normalized = $this->normalize_color_for_css( $this->sanitize_color( $custom, '' ) );
			return '' !== $normalized ? esc_attr( $normalized ) : $fallback;
		}

		return $fallback;
	}

	/**
	 * Layout scopes that beat Divi FontGroup `color: … !important`.
	 *
	 * Divi Text example: `.et_pb_text_0 .et_pb_text_inner h2 { color:#000 !important }`
	 * is (0,2,1). `html.dsm-dark .et-l h2` is (0,2,2). Layout-prefixed Divi
	 * (`.et-l--post > .et_builder_inner_content .et_pb_text_0 .et_pb_text_inner h2`)
	 * is (0,4,1); the `.et_pb_module` scopes are (0,4,2) or (1,4,2) on CPT.
	 *
	 * Keep in sync with palette-css.js `getPaletteImportantModuleScopes`.
	 *
	 * @return array<int, string>
	 */
	private function get_palette_important_module_scopes(): array {
		$scopes = array(
			'html.dsm-dark .et-l',
			'html.dsm-dark .et-l .et_builder_inner_content .et_pb_module',
			'html.dsm-dark .et-l--header .et_pb_module',
			'html.dsm-dark .et-l--body .et_pb_module',
			'html.dsm-dark .et-l--footer .et_pb_module',
			'html.dsm-dark .et-db #et-boc .et-l .et_pb_module',
			'html.dsm-dark #et-fb-app-header-root .et_pb_module',
			'html.dsm-dark #et-fb-app-body-root .et_pb_module',
			'html.dsm-dark #et-fb-app-footer-root .et_pb_module',
		);

		/**
		 * Filter layout scopes used to beat Divi/3rd-party `color: … !important`.
		 *
		 * @param array<int, string> $scopes Selector prefixes (no trailing descendant).
		 */
		$filtered = apply_filters( 'dsm_dark_mode_palette_important_scopes', $scopes );
		if ( ! is_array( $filtered ) ) {
			return $scopes;
		}

		$out = array();
		foreach ( $filtered as $scope ) {
			if ( ! is_string( $scope ) ) {
				continue;
			}
			$scope = trim( $scope );
			if ( '' === $scope ) {
				continue;
			}
			$out[] = $scope;
		}

		return array() !== $out ? $out : $scopes;
	}

	/**
	 * Join layout scopes with descendant suffixes.
	 *
	 * @param array<int, string> $scopes   Prefixes.
	 * @param array<int, string> $suffixes Descendants including a leading space, or '' for the scope itself.
	 * @return string
	 */
	private function join_palette_scope_selectors( array $scopes, array $suffixes ): string {
		$parts = array();
		foreach ( $scopes as $scope ) {
			foreach ( $suffixes as $suffix ) {
				$parts[] = $scope . $suffix;
			}
		}

		return implode( ',', $parts );
	}

	/**
	 * High-specificity colour remaps so Divi Design → Text/Heading/Link !important loses.
	 *
	 * Section/row/column Overrides stay more specific and still win.
	 * Keep in sync with palette-css.js `buildPaletteImportantColorRules`.
	 *
	 * @return string
	 */
	private function build_palette_important_color_rules(): string {
		$scopes = $this->get_palette_important_module_scopes();
		$css    = $this->join_palette_scope_selectors( $scopes, array( '' ) ) . '{color:var(--dsm-dm-text)!important;}';
		$css   .= $this->join_palette_scope_selectors(
			$scopes,
			array( ' h1', ' h2', ' h3', ' h4', ' h5', ' h6', ' .et_pb_module_header' )
		) . '{color:var(--dsm-dm-heading)!important;}';
		$css   .= $this->join_palette_scope_selectors( $scopes, array( ' a' ) ) . '{color:var(--dsm-dm-link)!important;}';
		$css   .= $this->join_palette_scope_selectors( $scopes, array( ' a:hover', ' a:focus-visible' ) ) . '{color:var(--dsm-dm-link-hover)!important;}';
		$css   .= $this->join_palette_scope_selectors( $scopes, array( ' .et_pb_button', ' a.et_pb_button' ) ) . '{background-color:var(--dsm-dm-accent)!important;color:var(--dsm-dm-button-text)!important;border-color:var(--dsm-dm-accent)!important;}';

		return $css;
	}

	/**
	 * Layout prefixes for Apply Surface to (cards / all content modules).
	 *
	 * Keep in sync with palette-css.js `getPaletteSurfaceApplyScopes`.
	 *
	 * @return array<int, string>
	 */
	private function get_palette_surface_apply_scopes(): array {
		return array(
			'html.dsm-dark .et-l .et_builder_inner_content',
			'html.dsm-dark .et-l--header',
			'html.dsm-dark .et-l--body',
			'html.dsm-dark .et-l--footer',
			'html.dsm-dark .et-db #et-boc .et-l',
			'html.dsm-dark #et-fb-app-header-root',
			'html.dsm-dark #et-fb-app-body-root',
			'html.dsm-dark #et-fb-app-footer-root',
		);
	}

	/**
	 * Card-like module leaves for Apply Surface to = Content cards.
	 *
	 * Keep in sync with palette-css.js `getPaletteSurfaceCardLeaves`.
	 *
	 * @return array<int, string>
	 */
	private function get_palette_surface_card_leaves(): array {
		$leaves = array(
			'.et_pb_blurb',
			'.et_pb_cta',
			'.et_pb_testimonial',
			'.et_pb_toggle',
			'.et_pb_accordion',
			'.et_pb_pricing_table',
			'.et_pb_pricing_tables',
			'.et_pb_team_member',
			'.et_pb_contact_form',
			'.et_pb_newsletter',
			'.et_pb_login',
			'.dsm_card',
			'.dsm_card_carousel_child',
		);

		/**
		 * Filter card-like selectors for Dark Mode Surface (Content cards).
		 *
		 * @param array<int, string> $leaves Class selectors including the leading dot.
		 */
		$filtered = apply_filters( 'dsm_dark_mode_surface_card_selectors', $leaves );
		if ( ! is_array( $filtered ) ) {
			return $leaves;
		}

		$out = array();
		foreach ( $filtered as $leaf ) {
			if ( ! is_string( $leaf ) ) {
				continue;
			}
			$leaf = trim( $leaf );
			if ( '' === $leaf || ! preg_match( '/^\.[a-zA-Z0-9_-]+$/', $leaf ) ) {
				continue;
			}
			$out[] = $leaf;
		}

		return array() !== $out ? $out : $leaves;
	}

	/**
	 * Module classes skipped when Apply Surface to = All content modules.
	 *
	 * Keep in sync with palette-css.js `getPaletteSurfaceSkipClasses`.
	 *
	 * @return array<int, string>
	 */
	private function get_palette_surface_skip_classes(): array {
		$skip = array(
			'et_pb_section',
			'et_pb_row',
			'et_pb_row_inner',
			'et_pb_column',
			'et_pb_column_inner',
			'et_pb_image',
			'et_pb_fullwidth_image',
			'et_pb_video',
			'et_pb_video_slider',
			'et_pb_slider',
			'et_pb_fullwidth_slider',
			'et_pb_gallery',
			'et_pb_divider',
			'et_pb_button',
			'et_pb_menu',
			'et_pb_fullwidth_menu',
			'et_pb_social_media_follow',
			'et_pb_map',
			'et_pb_fullwidth_map',
			'et_pb_code',
			'et_pb_fullwidth_code',
			'et_pb_audio',
			'et_pb_icon',
			'dsm_dark_mode_toggle',
		);

		/**
		 * Filter module class names excluded from All content modules Surface.
		 *
		 * @param array<int, string> $skip Class names without a leading dot.
		 */
		$filtered = apply_filters( 'dsm_dark_mode_surface_skip_modules', $skip );
		if ( ! is_array( $filtered ) ) {
			return $skip;
		}

		$out = array();
		foreach ( $filtered as $class ) {
			if ( ! is_string( $class ) ) {
				continue;
			}
			$class = sanitize_html_class( $class );
			if ( '' === $class ) {
				continue;
			}
			$out[] = $class;
		}

		return array() !== $out ? $out : $skip;
	}

	/**
	 * Extra Surface fills for Content cards / All content modules.
	 *
	 * None and painted emit nothing here. Painted is handled by auto-remap + carousel item rules.
	 * Keep in sync with palette-css.js `buildPaletteSurfaceApplyRules`.
	 *
	 * @param array<string, mixed> $settings Settings snapshot.
	 * @return string
	 */
	private function build_palette_surface_apply_rules( array $settings ): string {
		$mode = $this->sanitize_module_surface_mode( (string) ( $settings['module_surface_mode'] ?? 'painted' ) );
		if ( 'none' === $mode || 'painted' === $mode ) {
			return '';
		}

		$scopes = $this->get_palette_surface_apply_scopes();
		if ( 'content' === $mode ) {
			$not = '';
			foreach ( $this->get_palette_surface_skip_classes() as $class ) {
				$not .= ':not(.' . $class . ')';
			}
			$leaves = array( '.et_pb_module' . $not );
		} else {
			$leaves = $this->get_palette_surface_card_leaves();
		}

		$selectors = array();
		foreach ( $scopes as $scope ) {
			foreach ( $leaves as $leaf ) {
				$selectors[] = $scope . ' ' . $leaf;
			}
		}

		if ( array() === $selectors ) {
			return '';
		}

		return implode( ',', $selectors ) . '{background-color:var(--dsm-dm-surface)!important;}';
	}

	/**
	 * Build CSS that remaps palette tokens under html.dsm-dark.
	 *
	 * Soft-migrate note: empty --gcid-primary-color falls back to
	 * var(--dsm-dm-accent) (previously var(--dsm-dm-link)) so Divi Primary /
	 * button globals track the accent token. Explicit gcid overrides and
	 * --gcid-link-color → link are unchanged. Surface is exposed as
	 * --dsm-dm-surface plus .dsm-dm-surface utility, painted module fills
	 * (auto-remap), and blog/post carousel items. Overrides still win.
	 * Text/heading/link remaps use !important to beat Divi FontGroup.
	 *
	 * @param array<string, mixed>|null $settings Optional settings snapshot.
	 * @return string
	 */
	public function build_palette_css( ?array $settings = null ): string {
		$settings = is_array( $settings ) ? wp_parse_args( $settings, $this->default_settings ) : $this->get_settings();
		$settings = $this->migrate_responsive_palette_settings( $settings );

		if ( ! isset( $settings['gcid_mappings'] ) || ! is_array( $settings['gcid_mappings'] ) ) {
			$settings['gcid_mappings'] = $this->default_settings['gcid_mappings'];
		} else {
			$settings['gcid_mappings'] = wp_parse_args(
				$settings['gcid_mappings'],
				$this->default_settings['gcid_mappings']
			);
		}

		$css  = 'html.dsm-dark{';
		$css .= $this->build_palette_var_declarations( $settings, 'desktop' );
		$css .= 'color-scheme:dark;';
		$css .= 'background-color:var(--dsm-dm-bg);';
		$css .= 'color:var(--dsm-dm-text);';
		// Remap Divi Variable Generator colour tokens (override when mapped).
		$css .= '--gcid-primary-color:' . $this->resolve_gcid_css_value( $settings, 'gcid-primary-color', 'var(--dsm-dm-accent)' ) . ';';
		$css .= '--gcid-secondary-color:' . $this->resolve_gcid_css_value( $settings, 'gcid-secondary-color', 'var(--dsm-dm-heading)' ) . ';';
		$css .= '--gcid-tertiary-color:' . $this->resolve_gcid_css_value( $settings, 'gcid-tertiary-color', 'var(--dsm-dm-link)' ) . ';';
		$css .= '--gcid-heading-color:' . $this->resolve_gcid_css_value( $settings, 'gcid-heading-color', 'var(--dsm-dm-heading)' ) . ';';
		$css .= '--gcid-body-color:' . $this->resolve_gcid_css_value( $settings, 'gcid-body-color', 'var(--dsm-dm-text)' ) . ';';
		$css .= '--gcid-link-color:' . $this->resolve_gcid_css_value( $settings, 'gcid-link-color', 'var(--dsm-dm-link)' ) . ';';

		$custom_vars = isset( $settings['custom_var_mappings'] ) && is_array( $settings['custom_var_mappings'] )
			? $settings['custom_var_mappings']
			: array();
		foreach ( $custom_vars as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$property = $this->sanitize_css_custom_property( (string) ( $row['property'] ?? '' ) );
			$color    = $this->normalize_color_for_css(
				$this->sanitize_color( (string) ( $row['color'] ?? '' ), '' )
			);
			if ( '' === $property || '' === $color ) {
				continue;
			}
			$css .= esc_attr( $property ) . ':' . esc_attr( $color ) . ';';
		}

		$css .= '}';
		$css .= 'html.dsm-dark body{background-color:var(--dsm-dm-bg);color:var(--dsm-dm-text)!important;}';
		$css .= 'html.dsm-dark h1,html.dsm-dark h2,html.dsm-dark h3,html.dsm-dark h4,html.dsm-dark h5,html.dsm-dark h6{color:var(--dsm-dm-heading)!important;}';
		// Menu / nav: beat Divi `.et_pb_menu ul li a` / `.et-menu a` (higher specificity than `html.dsm-dark a`).
		$css .= 'html.dsm-dark a,html.dsm-dark .et_pb_menu a,html.dsm-dark .et_pb_fullwidth_menu a,html.dsm-dark .et-menu a,html.dsm-dark .et_pb_menu ul li a,html.dsm-dark .et_mobile_menu a,html.dsm-dark .et_pb_menu .nav a{color:var(--dsm-dm-link)!important;}';
		$css .= 'html.dsm-dark a:hover,html.dsm-dark a:focus-visible,html.dsm-dark .et_pb_menu a:hover,html.dsm-dark .et_pb_menu a:focus-visible,html.dsm-dark .et_pb_fullwidth_menu a:hover,html.dsm-dark .et_pb_fullwidth_menu a:focus-visible,html.dsm-dark .et-menu a:hover,html.dsm-dark .et-menu a:focus-visible,html.dsm-dark .et_pb_menu ul li a:hover,html.dsm-dark .et_pb_menu ul li a:focus-visible,html.dsm-dark .et_mobile_menu a:hover,html.dsm-dark .et_mobile_menu a:focus-visible,html.dsm-dark .et_pb_menu .nav a:hover,html.dsm-dark .et_pb_menu .nav a:focus-visible{color:var(--dsm-dm-link-hover)!important;}';
		$css .= 'html.dsm-dark hr,html.dsm-dark .et_pb_border{border-color:var(--dsm-dm-border)!important;}';
		// Surface: utility + painted module auto-remap + carousel item cards.
		$css         .= 'html.dsm-dark .dsm-dm-surface{background-color:var(--dsm-dm-surface);}';
		$surface_mode = $this->sanitize_module_surface_mode( (string) ( $settings['module_surface_mode'] ?? 'painted' ) );
		if ( 'none' !== $surface_mode ) {
			$css .= 'html.dsm-dark .dsm_blog_carousel .dsm-blog-carousel-item,html.dsm-dark .dsm_post_carousel .dsm-post-carousel-item{background-color:var(--dsm-dm-surface)!important;}';
		}
		$css .= $this->build_palette_surface_apply_rules( $settings );
		// Divi buttons: accent fill + contrasting label (overrides link colour above).
		$css .= 'html.dsm-dark .et_pb_button,html.dsm-dark a.et_pb_button{background-color:var(--dsm-dm-accent)!important;color:var(--dsm-dm-button-text)!important;border-color:var(--dsm-dm-accent)!important;}';
		$css .= 'html.dsm-dark .et_pb_button:hover,html.dsm-dark .et_pb_button:focus-visible,html.dsm-dark a.et_pb_button:hover,html.dsm-dark a.et_pb_button:focus-visible{background-color:var(--dsm-dm-accent)!important;color:var(--dsm-dm-button-text)!important;border-color:var(--dsm-dm-accent)!important;}';
		// Forms / inputs (native + common Divi contact / email opt-in fields).
		$css .= 'html.dsm-dark input:not([type=submit]):not([type=button]):not([type=reset]):not([type=image]):not([type=checkbox]):not([type=radio]):not([type=range]):not([type=file]):not([type=color]),html.dsm-dark textarea,html.dsm-dark select,html.dsm-dark .et_pb_contact_form input,html.dsm-dark .et_pb_contact_form textarea,html.dsm-dark .et_pb_contact_form select,html.dsm-dark .et_pb_newsletter_form input,html.dsm-dark .et_pb_newsletter_form textarea,html.dsm-dark .et_pb_newsletter_form select{background-color:var(--dsm-dm-input-bg)!important;color:var(--dsm-dm-input-text)!important;border-color:var(--dsm-dm-input-border)!important;}';
		$css .= 'html.dsm-dark input::placeholder,html.dsm-dark textarea::placeholder{color:var(--dsm-dm-input-text)!important;opacity:.65;}';
		// Beat Divi / 3rd-party module FontGroup `color: … !important` (Text h2, Blurb title, etc.).
		$css .= $this->build_palette_important_color_rules();

		// Divi Breakpoint @media when tablet/phone palette overrides exist.
		if ( $this->has_palette_breakpoint_overrides( $settings ) ) {
			foreach ( $this->get_enabled_breakpoints() as $breakpoint ) {
				if ( ! is_array( $breakpoint ) || ! isset( $breakpoint['name'] ) || ! is_string( $breakpoint['name'] ) ) {
					continue;
				}
				$bp_name = $breakpoint['name'];
				if ( 'desktop' === $bp_name ) {
					continue;
				}
				$max_width = $this->get_breakpoint_media_max_px( $breakpoint );
				if ( null === $max_width ) {
					continue;
				}
				$css .= sprintf(
					'@media (max-width:%1$dpx){html.dsm-dark{%2$s}}',
					$max_width,
					$this->build_palette_var_declarations( $settings, $bp_name )
				);
			}
		}

		/**
		 * Filter generated dark-mode palette CSS.
		 *
		 * @param string               $css      CSS string.
		 * @param array<string, mixed> $settings Settings used to build CSS.
		 */
		return (string) apply_filters( 'dsm_dark_mode_palette_css', $css, $settings );
	}

	/**
	 * Build opt-in image dimming CSS (filter on img only when dark).
	 *
	 * @param array<string, mixed>|null $settings Optional settings.
	 * @return string
	 */
	public function build_image_brightness_css( ?array $settings = null ): string {
		$settings = is_array( $settings ) ? wp_parse_args( $settings, $this->default_settings ) : $this->get_settings();

		if ( 'on' !== ( $settings['image_brightness_enabled'] ?? 'off' ) ) {
			return '';
		}

		$percent = (int) $this->sanitize_image_brightness( (string) ( $settings['image_brightness'] ?? '85' ) );
		$factor  = max( 0.5, min( 1, $percent / 100 ) );
		$factor  = (string) round( $factor, 3 );

		$css  = 'html.dsm-dark img:not([data-dsm-dm-skip-dim]):not(.dsm-dark-mode-toggle__icon){';
		$css .= 'filter:brightness(' . esc_attr( $factor ) . ');';
		$css .= '}';
		$css .= '@media (prefers-reduced-motion: reduce){';
		$css .= 'html.dsm-dark img:not([data-dsm-dm-skip-dim]){transition:none;}';
		$css .= '}';

		/**
		 * Filter image brightness CSS for dark mode.
		 *
		 * @param string               $css      CSS string.
		 * @param array<string, mixed> $settings Settings used.
		 */
		return (string) apply_filters( 'dsm_dark_mode_image_brightness_css', $css, $settings );
	}

	/**
	 * Markup attributes that discourage cache / JS optimizers from deferring,
	 * delaying, or combining this critical FOUC bootstrap.
	 *
	 * Aligns with {@see \DiviSupreme\Includes\DsmWebpackScriptOptimizerCompat}.
	 * Optimizers should leave `#dsm-dark-mode-fouc` / `#dsm-dark-mode-palette` alone.
	 *
	 * @return array<string, string|true> Attribute name => value, or true for a boolean attribute.
	 */
	private function get_critical_inline_script_attr_map(): array {
		return array(
			'data-no-optimize'         => '1',
			'data-no-minify'           => '1',
			'data-cfasync'             => 'false',
			'data-pagespeed-no-defer'  => true,
			'data-wpmeteor-nooptimize' => 'true',
		);
	}

	/**
	 * Print escaped optimizer-bypass attributes for the critical FOUC tags.
	 *
	 * @return void
	 */
	private function print_critical_inline_tag_attrs(): void {
		foreach ( $this->get_critical_inline_script_attr_map() as $name => $value ) {
			if ( true === $value ) {
				echo ' ' . esc_attr( $name );
				continue;
			}

			echo ' ' . esc_attr( $name ) . '="' . esc_attr( (string) $value ) . '"';
		}
	}

	/**
	 * FOUC-safe early head bootstrap (user override → schedule → default/system).
	 *
	 * Precedence: localStorage user choice wins until cleared; then optional
	 * schedule window (site timezone); then default_mode / prefers-color-scheme.
	 *
	 * When logo swap is enabled and a dark logo URL exists, also swaps matching
	 * `<img>` src as early as nodes appear (MutationObserver) to reduce light-logo
	 * flash. Soft-fails when dark URL is empty. Frontend `logo-swap.js` remains
	 * the full backup (incl. Theme Builder remounts).
	 *
	 * @return void
	 */
	public function print_fouc_bootstrap(): void {
		if ( ! $this->should_load_on_current_request() ) {
			return;
		}

		$settings     = $this->get_settings();
		$default_mode = $this->sanitize_default_mode( (string) $settings['default_mode'] );
		$storage_key  = self::STORAGE_KEY;
		$sched_on     = 'on' === ( $settings['schedule_enabled'] ?? 'off' );
		$sched_start  = $this->sanitize_time_hhmm( (string) ( $settings['schedule_start'] ?? '18:00' ), '18:00' );
		$sched_end    = $this->sanitize_time_hhmm( (string) ( $settings['schedule_end'] ?? '06:00' ), '06:00' );
		$tz_offset    = $this->get_timezone_offset_minutes();

		$logo_on    = 'on' === ( $settings['logo_swap_enabled'] ?? 'off' );
		$logo_dark  = $logo_on
			? $this->sanitize_url( $this->normalize_logo_url_value( $settings['logo_dark_url'] ?? '' ) )
			: '';
		$logo_light = $logo_on
			? $this->sanitize_url( $this->normalize_logo_url_value( $settings['logo_light_url'] ?? '' ) )
			: '';
		$logo_sel   = $logo_on
			? $this->sanitize_css_selector(
				(string) ( $settings['logo_selector'] ?? self::DEFAULT_LOGO_SELECTOR ),
				self::DEFAULT_LOGO_SELECTOR
			)
			: '';

		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static HTML comment for optimizer authors.
		echo "<!-- dsm-dark-mode: critical FOUC bootstrap — do not defer, delay, combine, or strip -->\n";
		echo '<script id="' . esc_attr( 'dsm-dark-mode-fouc' ) . '"';
		$this->print_critical_inline_tag_attrs();
		echo '>(function(){try{var k=' . wp_json_encode( $storage_key ) .
			';var def=' . wp_json_encode( $default_mode ) .
			';var schedOn=' . wp_json_encode( $sched_on ) .
			';var schedStart=' . wp_json_encode( $sched_start ) .
			';var schedEnd=' . wp_json_encode( $sched_end ) .
			';var tzOff=' . wp_json_encode( $tz_offset ) .
			';var logoOn=' . wp_json_encode( $logo_on && '' !== $logo_dark ) .
			';var logoDark=' . wp_json_encode( $logo_dark ) .
			';var logoLight=' . wp_json_encode( $logo_light ) .
			';var logoSel=' . wp_json_encode( $logo_sel ) .
			';function toMins(t){var p=String(t||"0:0").split(":");return(parseInt(p[0],10)||0)*60+(parseInt(p[1],10)||0);}' .
			'function inSched(){if(!schedOn)return false;var now=new Date();var utc=now.getTime()+now.getTimezoneOffset()*60000;var site=new Date(utc+tzOff*60000);var mins=site.getHours()*60+site.getMinutes();var a=toMins(schedStart),b=toMins(schedEnd);if(a===b)return true;if(a<b)return mins>=a&&mins<b;return mins>=a||mins<b;}' .
			'var mode=null;try{mode=localStorage.getItem(k);}catch(e){}' .
			'if(mode!=="light"&&mode!=="dark"){if(inSched()){mode="dark";}else if(def==="dark"){mode="dark";}else if(def==="light"){mode="light";}else{mode=(window.matchMedia&&window.matchMedia("(prefers-color-scheme: dark)").matches)?"dark":"light";}}' .
			'var r=document.documentElement;r.setAttribute("data-dsm-color-scheme",mode);if(mode==="dark"){r.classList.add("dsm-dark");}else{r.classList.remove("dsm-dark");}r.style.colorScheme=mode;' .
			// Early logo swap: soft-fail when no dark URL; FE MutationObserver remains backup.
			'if(logoOn&&logoSel){function swap(){var next=mode==="dark"?logoDark:(logoLight||"");if(!next&&mode==="dark")return;var list;try{list=document.querySelectorAll(logoSel);}catch(err){return;}for(var i=0;i<list.length;i++){var el=list[i];if(!el||el.tagName!=="IMG")continue;if(!el.getAttribute("data-dsm-dm-logo-orig")){el.setAttribute("data-dsm-dm-logo-orig",el.getAttribute("src")||el.src||"");}var tgt=next||el.getAttribute("data-dsm-dm-logo-orig")||"";if(!tgt)continue;if(el.getAttribute("src")!==tgt){el.setAttribute("src",tgt);el.removeAttribute("srcset");el.removeAttribute("sizes");}el.setAttribute("data-dsm-dm-logo",mode);el.setAttribute("data-dsm-dm-skip-dim","1");}}swap();if(typeof MutationObserver!=="undefined"){var mo=new MutationObserver(function(){swap();});try{mo.observe(r,{childList:true,subtree:true});}catch(err2){}setTimeout(function(){try{mo.disconnect();}catch(err3){}},8000);}}' .
			'}catch(e){}})();</script>' . "\n";
	}

	/**
	 * Preload dark logo so first dark paint can use a warm cache.
	 *
	 * Soft-fails when logo swap is off or dark URL is empty.
	 *
	 * @return void
	 */
	public function print_logo_preload(): void {
		if ( ! $this->should_load_on_current_request() ) {
			return;
		}

		$settings = $this->get_settings();
		if ( 'on' !== ( $settings['logo_swap_enabled'] ?? 'off' ) ) {
			return;
		}

		$dark_url = $this->sanitize_url( $this->normalize_logo_url_value( $settings['logo_dark_url'] ?? '' ) );
		if ( '' === $dark_url ) {
			return;
		}

		echo '<!-- dsm-dark-mode: logo preload — keep in head -->' . "\n";
		printf(
			'<link rel="preload" as="image" href="%1$s" id="dsm-dark-mode-logo-preload" />' . "\n",
			esc_url( $dark_url )
		);
	}

	/**
	 * Print palette CSS early so first paint after FOUC class is correct.
	 *
	 * Critical: keep inline in head (not deferred CSS file) so `html.dsm-dark`
	 * tokens apply on first paint. Optimizers should not relocate this tag.
	 *
	 * @return void
	 */
	public function print_palette_css(): void {
		if ( ! $this->should_load_on_current_request() ) {
			return;
		}

		$css = $this->build_palette_css();

		if ( '' === trim( $css ) ) {
			return;
		}

		echo "<!-- dsm-dark-mode: critical palette CSS — do not defer or combine -->\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static HTML comment for optimizer authors.
		echo '<style id="' . esc_attr( 'dsm-dark-mode-palette' ) . '"';
		$this->print_critical_inline_tag_attrs();
		echo '>' . $css . '</style>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- CSS built from sanitized settings.
	}

	/**
	 * Print opt-in image brightness CSS.
	 *
	 * @return void
	 */
	public function print_image_brightness_css(): void {
		if ( ! $this->should_load_on_current_request() ) {
			return;
		}

		$css = $this->build_image_brightness_css();

		if ( '' === trim( $css ) ) {
			return;
		}

		echo '<style id="dsm-dark-mode-image-brightness">' . $css . '</style>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- CSS built from sanitized settings.
	}

	/**
	 * Print sanitized custom CSS when dark mode assets load on this request.
	 *
	 * Authors should scope rules with `html.dsm-dark` (or descendants) so they
	 * only apply while dark mode is active.
	 *
	 * @return void
	 */
	public function print_custom_dark_css(): void {
		if ( ! $this->should_load_on_current_request() ) {
			return;
		}

		$settings = $this->get_settings();
		$css      = $this->sanitize_custom_css( (string) ( $settings['custom_dark_css'] ?? '' ) );

		if ( '' === trim( $css ) ) {
			return;
		}

		/**
		 * Filter custom dark CSS before print.
		 *
		 * @param string               $css      CSS.
		 * @param array<string, mixed> $settings Settings.
		 */
		$css = (string) apply_filters( 'dsm_dark_mode_custom_css', $css, $settings );

		if ( '' === trim( $css ) ) {
			return;
		}

		echo '<style id="dsm-dark-mode-custom">' . $css . '</style>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- CSS sanitized via sanitize_custom_css.
	}

	/**
	 * Enqueue frontend bundle when extension is active and scope matches.
	 *
	 * Floating-switch CSS is always wp_enqueue'd (not left solely to Divi Dynamic Assets).
	 * The switch mounts on `document.body`, so styles must load as the global (non-CPT) sheet
	 * even on Theme Builder pages — see {@see DsmDiviBuilderCssScope} CPT exclusions.
	 *
	 * @return void
	 */
	public function maybe_enqueue_frontend_assets(): void {
		if ( ! $this->should_load_on_current_request() ) {
			return;
		}

		$this->maybe_enqueue_frontend_assets_unscoped();
	}
}

new DarkMode();
