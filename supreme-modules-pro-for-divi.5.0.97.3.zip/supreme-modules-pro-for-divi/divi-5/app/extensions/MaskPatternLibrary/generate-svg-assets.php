<?php
/**
 * Generator for self-hosted mask/pattern SVG assets (Supreme library v2).
 *
 * Trend-focused shapes deliberately distinct from Divi native arch/wave/blob/checker/honeycomb/etc.
 *
 * Run from plugin root: php divi-5/app/extensions/MaskPatternLibrary/generate-svg-assets.php
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

define( 'DSM_MASK_GEN_CLI', true );

require_once __DIR__ . '/haikei-style-masks.php';
require_once __DIR__ . '/divider-style-masks.php';

$base = __DIR__ . '/assets/svg';

/**
 * Dsm clean SVG dir.
 *
 * @param string $dir Directory to clean.
 */
function dsm_clean_svg_dir( string $dir ): void {
	if ( ! is_dir( $dir ) ) {
		mkdir( $dir, 0755, true );
		return;
	}

	$svg_files = glob( $dir . '/*.svg' );
	if ( ! is_array( $svg_files ) ) {
		$svg_files = array();
	}
	foreach ( $svg_files as $file ) {
		unlink( $file );
	}
}

dsm_clean_svg_dir( $base . '/masks' );
// Patterns (including Hero Patterns) are managed separately — do not wipe on mask regen.

/**
 * Tile pattern markup across Divi's 80×60 picker canvas (matches native previews).
 *
 * @param string $tile_w       Tile width in px.
 * @param string $tile_h       Tile height in px.
 * @param string $tile_markup  Inner SVG for one tile.
 * @return string
 */
function dsm_pattern_tile_thumbnail( string $tile_w, string $tile_h, string $tile_markup ): string {
	$canvas_w = 80.0;
	$canvas_h = 60.0;
	$tw       = (float) $tile_w;
	$th       = (float) $tile_h;

	if ( $tw <= 0 || $th <= 0 ) {
		return $tile_markup;
	}

	$scale = 1.0;
	while ( $tw * $scale > $canvas_w / 1.4 ) {
		$scale *= 0.75;
	}
	while ( $th * $scale > $canvas_h / 1.4 ) {
		$scale *= 0.75;
	}

	$stw = $tw * $scale;
	$sth = $th * $scale;
	$out = '';

	for ( $y = 0.0; $y <= $canvas_h; $y += $sth ) {
		for ( $x = 0.0; $x <= $canvas_w; $x += $stw ) {
			$out .= '<g transform="translate(' . $x . ',' . $y . ') scale(' . $scale . ')">' . $tile_markup . '</g>';
		}
	}

	return $out;
}

$masks = array(
	'dsm-mask-ink-bloom'       => array(
		'regular'   => '<path d="M1920,0V540c-220,60-420,180-640,160S980,520,760,580,520,720,320,660,120,560,0,620V0Z"/>',
		'inverted'  => '<path d="M0,620c120-60,200-100,320-100s220,80,440,40,420-120,640-100,220,20,420-100,520-160V1440H0Z"/>',
		'thumbnail' => '<path d="M1920,0V620c-280,80-520,200-760,180S940,560,680,640,460,780,240,700,80,580,0,660V0Z"/>',
	),
	'dsm-mask-glass-curve'     => array(
		'regular'   => '<path d="M0,0H780c140,200,140,520,0,720s-140,520,0,720H0Z"/>',
		'inverted'  => '<path d="M780,0H1920V1440H780c140-200,140-520,0-720s140-520,0-720Z"/>',
		'thumbnail' => '<path d="M0,0H920c180,260,180,680,0,960s-180,680,0,960H0Z"/>',
	),
	'dsm-mask-brutalist-steps' => array(
		'regular'   => '<path d="M0,980H280V820H520V1080H760V760H1040V1120H1280V840H1560V1180H1920V1440H0Z"/>',
		'inverted'  => '<path d="M0,980H280V820H520V1080H760V760H1040V1120H1280V840H1560V1180H1920V980H0Z"/>',
		'thumbnail' => '<path d="M0,860H360V680H640V980H920V640H1220V1040H1500V720H1780V1180H1920V1440H0Z"/>',
	),
	'dsm-mask-mesh-orbs'       => array(
		'regular'   => '<circle cx="1320" cy="420" r="320"/><circle cx="620" cy="980" r="260" fill-opacity=".55"/><circle cx="1080" cy="1080" r="200" fill-opacity=".75"/>',
		'inverted'  => '<path d="M0,0H1920V1440H0ZM1320,420a320,320,0,1,0-640,0,320,320,0,1,0,640,0M620,980a260,260,0,1,0-520,0,260,260,0,1,0,520,0M1080,1080a200,200,0,1,0-400,0,200,200,0,1,0,400,0"/>',
		'thumbnail' => '<circle cx="1240" cy="380" r="420"/><circle cx="520" cy="920" r="340" fill-opacity=".55"/><circle cx="980" cy="1040" r="280" fill-opacity=".75"/><circle cx="1560" cy="980" r="240" fill-opacity=".45"/>',
	),
	'dsm-mask-page-fold'       => array(
		'regular'   => '<path d="M1320,980H1920V1440H960Z"/>',
		'inverted'  => '<path d="M1320,980H1920V1440H1320Zm640-460V980H1320Z"/>',
		'thumbnail' => '<path d="M1040,720H1920V1440H760Z"/>',
	),
	'dsm-mask-pixel-edge'      => array(
		'regular'   => '<path d="M0,1440V1120H160V960H320V800H480V640H640V480H800V320H960V160H1120V0H0Z"/>',
		'inverted'  => '<path d="M1120,0H1920V1440H0V1120H160V960H320V800H480V640H640V480H800V320H960V160H1120Z"/>',
		'thumbnail' => '<path d="M0,1440V1080H200V880H400V680H600V480H800V280H1000V80H1200V0H0Z"/>',
	),
	'dsm-mask-aurora-band'     => array(
		'regular'   => '<path fill-opacity=".35" d="M0,520c240,80,480,80,720,0s480-80,720,0,480,80,720,0v120c-240-80-480-80-720,0s-480,80-720,0-480-80-720,0Z"/><path fill-opacity=".6" d="M0,680c200,60,400,60,600,0s400-60,600,0,400,60,600,0,400-60,600,0v100c-200-60-400-60-600,0s-400,60-600,0-400-60-600,0Z"/><path d="M0,820c160,50,320,50,480,0s320-50,480,0,320,50,480,0,320-50,480,0,320,50,480,0v80c-160-50-320-50-480,0s-320,50-480,0-320-50-480,0-320,50-480,0Z"/>',
		'inverted'  => '<path d="M0,0H1920V520H0Zm0,120c240,80,480,80,720,0s480-80,720,0,480,80,720,0v120c-240-80-480-80-720,0s-480,80-720,0-480-80-720,0Zm0,160c200,60,400,60,600,0s400-60,600,0,400,60,600,0,400-60,600,0v100c-200-60-400-60-600,0s-400,60-600,0-400-60-600,0Zm0,140c160,50,320,50,480,0s320-50,480,0,320,50,480,0,320-50,480,0,320,50,480,0v80c-160-50-320-50-480,0s-320,50-480,0-320-50-480,0-320,50-480,0Z"/>',
		'thumbnail' => '<path fill-opacity=".35" d="M0,420c240,100,480,100,720,0s480-100,720,0,480,100,720,0v140c-240-100-480-100-720,0s-480,100-720,0-480-100-720,0Z"/><path fill-opacity=".6" d="M0,620c200,80,400,80,600,0s400-80,600,0,400,80,600,0,400-80,600,0v120c-200-80-400-80-600,0s-400,80-600,0-400-80-600,0Z"/><path d="M0,800c160,70,320,70,480,0s320-70,480,0,320,70,480,0,320-70,480,0,320,70,480,0v100c-160-70-320-70-480,0s-320,70-480,0-320-70-480,0-320,70-480,0Z"/>',
	),
	'dsm-mask-crescent-glow'   => array(
		'regular'   => '<path d="M1520,720a400,400,0,1,0-800,0,320,320,0,1,1,640,0,240,240,0,1,0-480,0,160,160,0,1,1,320,0Z"/>',
		'inverted'  => '<path d="M0,0H1920V1440H0V0Zm720,720a400,400,0,1,1,800,0,320,320,0,1,0-640,0,240,240,0,1,0,480,0,160,160,0,1,0-320,0Z"/>',
		'thumbnail' => '<path d="M1680,720a520,520,0,1,0-1040,0,420,420,0,1,1,840,0,320,320,0,1,0-640,0,220,220,0,1,1,440,0Z"/>',
	),
	'dsm-mask-card-stack'      => array(
		'regular'   => '<rect x="180" y="760" width="520" height="360" rx="28"/><rect x="280" y="640" width="520" height="360" rx="28" fill-opacity=".7"/><rect x="380" y="520" width="520" height="360" rx="28" fill-opacity=".45"/>',
		'inverted'  => '<path d="M0,0H1920V1440H0ZM180,760h520v360H180Zm100-120h520v360H280Zm100-120h520v360H380Z"/>',
		'thumbnail' => '<rect x="460" y="680" width="1000" height="520" rx="36"/><rect x="560" y="520" width="1000" height="520" rx="36" fill-opacity=".7"/><rect x="660" y="360" width="1000" height="520" rx="36" fill-opacity=".45"/>',
	),
	'dsm-mask-synth-grid'      => array(
		'regular'   => '<path d="M0,980H1920V1440H0Zm0,80L960,980,1920,1060V1440H0Zm0,160L960,1140,1920,1220V1440H0Zm0,160L960,1300,1920,1380V1440H0Z"/>',
		'inverted'  => '<path d="M0,0H1920V980H0Zm0,80L960,1060,1920,980V0H0Zm0,160L960,1220,1920,1140V0H0Zm0,160L960,1380,1920,1300V0H0Z"/>',
		'thumbnail' => '<path d="M0,900H1920V1440H0Zm0,100L960,900,1920,1000V1440H0Zm0,180L960,1080,1920,1180V1440H0Zm0,180L960,1260,1920,1360V1440H0Z"/>',
	),
	'dsm-mask-chrome-slice'    => array(
		'regular'   => '<path d="M0,0H1920L720,1440H0Z"/>',
		'inverted'  => '<path d="M720,0H1920V1440H720Z"/>',
		'thumbnail' => '<path d="M0,0H1920L620,1440H0Z"/>',
	),
	'dsm-mask-orbit-ring'      => array(
		'regular'   => '<path d="M960,720m-380,0a380,380,0,1,0,760,0a380,380,0,1,0-760,0m-220,0a220,220,0,1,1,440,0a220,220,0,1,1-440,0"/>',
		'inverted'  => '<path d="M0,0H1920V1440H0ZM960,720a220,220,0,1,0,440,0,220,220,0,1,0-440,0M960,720a380,380,0,1,0,760,0,380,380,0,1,0-760,0"/>',
		'thumbnail' => '<path d="M960,720m-480,0a480,480,0,1,0,960,0a480,480,0,1,0-960,0m-280,0a280,280,0,1,1,560,0a280,280,0,1,1-560,0"/>',
	),
);

foreach ( dsm_mask_pattern_library_haikei_style_masks() as $slug => $haikei ) {
	$masks[ $slug ] = array(
		'regular'   => $haikei['regular'],
		'inverted'  => $haikei['inverted'],
		'thumbnail' => $haikei['thumbnail'],
	);
}

foreach ( dsm_mask_pattern_library_divider_style_masks() as $slug => $divider ) {
	$masks[ $slug ] = array(
		'regular'   => $divider['regular'],
		'inverted'  => $divider['inverted'],
		'thumbnail' => $divider['thumbnail'],
	);
}

$patterns = array(
	'dsm-pattern-bauhaus-bold'     => array(
		'w'        => '72',
		'h'        => '72',
		'regular'  => '<circle cx="18" cy="18" r="14"/><rect x="44" y="8" width="20" height="20"/><path d="M8,44H32V68H8Z"/><path d="M44,44H68V68H44Z"/>',
		'inverted' => '<path d="M0,0H72V72H0Z"/><circle cx="18" cy="18" r="14"/><rect x="44" y="8" width="20" height="20"/><path d="M8,44H32V68H8Z"/><path d="M44,44H68V68H44Z"/>',
	),
	'dsm-pattern-film-grain'       => array(
		'w'        => '20',
		'h'        => '20',
		'regular'  => '<rect x="2" y="1" width="1" height="1"/><rect x="8" y="3" width="1" height="1"/><rect x="14" y="2" width="1" height="1"/><rect x="5" y="7" width="1" height="1"/><rect x="11" y="6" width="1" height="1"/><rect x="17" y="8" width="1" height="1"/><rect x="3" y="12" width="1" height="1"/><rect x="9" y="11" width="1" height="1"/><rect x="15" y="13" width="1" height="1"/><rect x="6" y="16" width="1" height="1"/><rect x="12" y="17" width="1" height="1"/><rect x="18" y="15" width="1" height="1"/>',
		'inverted' => '<path d="M0,0H20V20H0Z"/><rect x="2" y="1" width="1" height="1"/><rect x="8" y="3" width="1" height="1"/><rect x="14" y="2" width="1" height="1"/><rect x="5" y="7" width="1" height="1"/><rect x="11" y="6" width="1" height="1"/><rect x="17" y="8" width="1" height="1"/><rect x="3" y="12" width="1" height="1"/><rect x="9" y="11" width="1" height="1"/><rect x="15" y="13" width="1" height="1"/><rect x="6" y="16" width="1" height="1"/><rect x="12" y="17" width="1" height="1"/><rect x="18" y="15" width="1" height="1"/>',
	),
	'dsm-pattern-node-network'     => array(
		'w'        => '64',
		'h'        => '64',
		'regular'  => '<circle cx="12" cy="12" r="4"/><circle cx="52" cy="12" r="4"/><circle cx="12" cy="52" r="4"/><circle cx="52" cy="52" r="4"/><circle cx="32" cy="32" r="5"/><path d="M12,12L32,32M52,12L32,32M12,52L32,32M52,52L32,32"/>',
		'inverted' => '<path d="M0,0H64V64H0Z"/><circle cx="12" cy="12" r="4"/><circle cx="52" cy="12" r="4"/><circle cx="12" cy="52" r="4"/><circle cx="52" cy="52" r="4"/><circle cx="32" cy="32" r="5"/><path d="M12,12L32,32M52,12L32,32M12,52L32,32M52,52L32,32"/>',
	),
	'dsm-pattern-art-deco-fan'     => array(
		'w'        => '80',
		'h'        => '40',
		'regular'  => '<path d="M0,40A20,20,0,0,1,20,20A20,20,0,0,1,40,40Zm20,0A20,20,0,0,1,60,20A20,20,0,0,1,80,40Z"/>',
		'inverted' => '<path d="M0,0H80V40H0ZM0,40A20,20,0,0,1,20,20A20,20,0,0,1,40,40Zm20,0A20,20,0,0,1,60,20A20,20,0,0,1,80,40Z"/>',
	),
	'dsm-pattern-gradient-mesh'    => array(
		'w'        => '96',
		'h'        => '96',
		'regular'  => '<path d="M0,32C32,8,64,8,96,32M0,64C32,40,64,40,96,64M0,96C32,72,64,72,96,96"/><path d="M32,0C8,32,8,64,32,96M64,0C40,32,40,64,64,96"/>',
		'inverted' => '<path d="M0,0H96V96H0Z"/><path d="M0,32C32,8,64,8,96,32M0,64C32,40,64,40,96,64M0,96C32,72,64,72,96,96"/><path d="M32,0C8,32,8,64,32,96M64,0C40,32,40,64,64,96"/>',
	),
	'dsm-pattern-micro-grid'       => array(
		'w'        => '16',
		'h'        => '16',
		'regular'  => '<circle cx="4" cy="4" r="1.5"/><circle cx="12" cy="4" r="1.5"/><circle cx="4" cy="12" r="1.5"/><circle cx="12" cy="12" r="1.5"/>',
		'inverted' => '<path d="M0,0H16V16H0Z"/><circle cx="4" cy="4" r="1.5"/><circle cx="12" cy="4" r="1.5"/><circle cx="4" cy="12" r="1.5"/><circle cx="12" cy="12" r="1.5"/>',
	),
	'dsm-pattern-speed-lines'      => array(
		'w'        => '64',
		'h'        => '32',
		'regular'  => '<path d="M0,28L56,4h8L8,28Zm0-8L48,4h8L8,20Zm0-8L40,4h8L8,12Z"/>',
		'inverted' => '<path d="M0,0H64V32H0Z"/><path d="M0,28L56,4h8L8,28Zm0-8L48,4h8L8,20Zm0-8L40,4h8L8,12Z"/>',
	),
	'dsm-pattern-terrazzo'         => array(
		'w'        => '80',
		'h'        => '80',
		'regular'  => '<path d="M8,12l10,8-8,10-10-8Z"/><path d="M34,6l12,6-6,12-12-6Z"/><path d="M58,18l8,10-10,8-8-10Z"/><path d="M16,38l14,8-8,14-14-8Z"/><path d="M44,34l10,12-12,10-10-12Z"/><path d="M62,52l8,8-8,8-8-8Z"/>',
		'inverted' => '<path d="M0,0H80V80H0Z"/><path d="M8,12l10,8-8,10-10-8Z"/><path d="M34,6l12,6-6,12-12-6Z"/><path d="M58,18l8,10-10,8-8-10Z"/><path d="M16,38l14,8-8,14-14-8Z"/><path d="M44,34l10,12-12,10-10-12Z"/><path d="M62,52l8,8-8,8-8-8Z"/>',
	),
	'dsm-pattern-braille-texture'  => array(
		'w'        => '24',
		'h'        => '32',
		'regular'  => '<circle cx="6" cy="6" r="2"/><circle cx="18" cy="6" r="2"/><circle cx="6" cy="16" r="2"/><circle cx="18" cy="26" r="2"/><circle cx="6" cy="26" r="2"/>',
		'inverted' => '<path d="M0,0H24V32H0Z"/><circle cx="6" cy="6" r="2"/><circle cx="18" cy="6" r="2"/><circle cx="6" cy="16" r="2"/><circle cx="18" cy="26" r="2"/><circle cx="6" cy="26" r="2"/>',
	),
	'dsm-pattern-squiggle'         => array(
		'w'        => '80',
		'h'        => '24',
		'regular'  => '<path d="M0,12C10,2,20,22,30,12s20-10,30,0,20,10,30,0,20-10,30,0"/>',
		'inverted' => '<path d="M0,0H80V24H0Z"/><path d="M0,12C10,2,20,22,30,12s20-10,30,0,20,10,30,0,20-10,30,0"/>',
	),
	'dsm-pattern-brutalist-blocks' => array(
		'w'        => '56',
		'h'        => '56',
		'regular'  => '<rect x="0" y="0" width="28" height="20"/><rect x="32" y="8" width="24" height="28"/><rect x="8" y="28" width="36" height="28"/>',
		'inverted' => '<path d="M0,0H56V56H0Z"/><rect x="0" y="0" width="28" height="20"/><rect x="32" y="8" width="24" height="28"/><rect x="8" y="28" width="36" height="28"/>',
	),
	'dsm-pattern-water-ripple'     => array(
		'w'        => '64',
		'h'        => '64',
		'regular'  => '<circle cx="32" cy="32" r="6"/><circle cx="32" cy="32" r="14"/><circle cx="32" cy="32" r="22"/><circle cx="32" cy="32" r="30"/>',
		'inverted' => '<path d="M0,0H64V64H0Z"/><circle cx="32" cy="32" r="6"/><circle cx="32" cy="32" r="14"/><circle cx="32" cy="32" r="22"/><circle cx="32" cy="32" r="30"/>',
	),
	'dsm-pattern-hash-weave'       => array(
		'w'        => '36',
		'h'        => '36',
		'regular'  => '<path d="M6,6H14V14H6Zm16,0h8v8H22Zm-16,16h8v8H6Zm16,0h8v8H22Z"/><path d="M14,6h8v8H14Zm-8,8h8v8H6Zm16,0h8v8H22Zm-8,8h8v8H14Z"/>',
		'inverted' => '<path d="M0,0H36V36H0Z"/><path d="M6,6H14V14H6Zm16,0h8v8H22Zm-16,16h8v8H6Zm16,0h8v8H22Z"/><path d="M14,6h8v8H14Zm-8,8h8v8H6Zm16,0h8v8H22Zm-8,8h8v8H14Z"/>',
	),
	'dsm-pattern-capsule-tile'     => array(
		'w'        => '48',
		'h'        => '24',
		'regular'  => '<rect x="4" y="6" width="16" height="12" rx="6"/><rect x="28" y="6" width="16" height="12" rx="6"/>',
		'inverted' => '<path d="M0,0H48V24H0Z"/><rect x="4" y="6" width="16" height="12" rx="6"/><rect x="28" y="6" width="16" height="12" rx="6"/>',
	),
	'dsm-pattern-star-dust'        => array(
		'w'        => '48',
		'h'        => '48',
		'regular'  => '<path d="M8,8l2,4,4,2-4,2-2,4-2-4-4-2,4-2Z"/><path d="M34,6l1.5,3,3,1.5-3,1.5L34,15l-1.5-3-3-1.5,3-1.5Z"/><path d="M38,32l2,4,4,2-4,2-2,4-2-4-4-2,4-2Z"/><path d="M12,34l1.5,3,3,1.5-3,1.5L12,43l-1.5-3-3-1.5,3-1.5Z"/>',
		'inverted' => '<path d="M0,0H48V48H0Z"/><path d="M8,8l2,4,4,2-4,2-2,4-2-4-4-2,4-2Z"/><path d="M34,6l1.5,3,3,1.5-3,1.5L34,15l-1.5-3-3-1.5,3-1.5Z"/><path d="M38,32l2,4,4,2-4,2-2,4-2-4-4-2,4-2Z"/><path d="M12,34l1.5,3,3,1.5-3,1.5L12,43l-1.5-3-3-1.5,3-1.5Z"/>',
	),
);

foreach ( $masks as $slug => $data ) {
	$dir = $base . '/masks';
	foreach ( array( 'regular', 'inverted' ) as $variant ) {
		$file = $dir . '/' . $slug . '-' . $variant . '.svg';
		file_put_contents( $file, '<svg xmlns="http://www.w3.org/2000/svg">' . $data[ $variant ] . '</svg>' );
	}
	$thumb_markup = $data['thumbnail'] ?? $data['regular'];
	$thumb_file   = $dir . '/' . $slug . '-thumbnail.svg';
	file_put_contents( $thumb_file, '<svg xmlns="http://www.w3.org/2000/svg">' . $thumb_markup . '</svg>' );
}

foreach ( $patterns as $slug => $data ) {
	$dir = $base . '/patterns';
	foreach ( array( 'regular', 'inverted' ) as $variant ) {
		$file = $dir . '/' . $slug . '-' . $variant . '.svg';
		file_put_contents( $file, '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' . $data['w'] . ' ' . $data['h'] . '">' . $data[ $variant ] . '</svg>' );
	}
	$thumb = $dir . '/' . $slug . '-thumbnail.svg';
	file_put_contents(
		$thumb,
		'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 60">'
		. dsm_pattern_tile_thumbnail( $data['w'], $data['h'], $data['regular'] )
		. '</svg>'
	);
}

printf(
	"Generated %d masks (including %d haikei-style, %d divider-style) and %d patterns.\n",
	count( $masks ),
	count( dsm_mask_pattern_library_haikei_style_masks() ),
	count( dsm_mask_pattern_library_divider_style_masks() ),
	count( $patterns )
);
