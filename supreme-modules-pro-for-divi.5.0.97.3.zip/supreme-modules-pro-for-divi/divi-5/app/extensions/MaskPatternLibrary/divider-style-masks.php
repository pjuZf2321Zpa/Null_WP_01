<?php
/**
 * Original section-divider mask shapes inspired by common builder style categories.
 *
 * Generic forms only (chevron, drops, brush edge, etc.) — NOT copied from any
 * proprietary builder SVG assets. Regenerate via generate-svg-assets.php.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) && ! defined( 'DSM_MASK_GEN_CLI' ) ) {
	if ( 'cli' !== PHP_SAPI ) {
		exit;
	}
}

/**
 * Dsm mask pattern library divider style masks.
 *
 * @return array<string, array{label:string,regular:string,inverted:string,thumbnail:string}>
 */
function dsm_mask_pattern_library_divider_style_masks(): array {
	return array(
		// ── Arrow / chevron dividers ──────────────────────────────────────
		'dsm-mask-divider-twin-chevron'   => array(
			'label'     => 'Twin Chevrons',
			'regular'   => '<path d="M0,1440V1040L480,720 960,1040 1440,680 1920,960V1440H0Z"/>',
			'inverted'  => '<path d="M0,960L480,680 960,1040 1440,720 1920,1040V0H0V960Z"/>',
			'thumbnail' => '<path d="M0,1440V980L520,640 960,980 1480,620 1920,900V1440H0Z"/>',
		),
		'dsm-mask-divider-notch-top'      => array(
			'label'     => 'Top Notch',
			'regular'   => '<path d="M0,0H1920V520L960,880 0,520V0Z"/>',
			'inverted'  => '<path d="M0,880L960,520 1920,880V1440H0V880Z"/>',
			'thumbnail' => '<path d="M0,0H1920V460L960,820 0,460V0Z"/>',
		),

		// ── Drop / scallop edges ──────────────────────────────────────────
		'dsm-mask-divider-drop-scallops'  => array(
			'label'     => 'Drop Scallops',
			'regular'   => '<path d="M0,1440V1180C120,1180 120,1020 240,1020S360,1180 480,1180 480,1020 720,1020 720,1180 960,1180 960,1020 1200,1020 1200,1180 1440,1180 1440,1020 1680,1020 1680,1180 1920,1180V1440H0Z"/>',
			'inverted'  => '<path d="M0,1020C120,1020 120,1180 240,1180S360,1020 480,1020 480,1180 720,1180 720,1020 960,1020 960,1180 1200,1180 1200,1020 1440,1020 1440,1180 1680,1180 1680,1020 1920,1020V0H0V1020Z"/>',
			'thumbnail' => '<path d="M0,1440V1120C140,1120 140,940 280,940S420,1120 560,1120 560,940 840,940 840,1120 1120,1120 1120,940 1400,940 1400,1120 1640,1120 1640,940 1920,940V1440H0Z"/>',
		),
		'dsm-mask-divider-drip-curtain'   => array(
			'label'     => 'Drip Curtain',
			'regular'   => '<path d="M0,0H1920V360C1720,480 1580,260 1420,400S1140,520 960,340 780,520 580,380 420,260 260,480 80,360 0,420V0Z"/>',
			'inverted'  => '<path d="M0,420C80,360 260,480 420,260S780,520 960,340 1140,520 1420,400 1580,260 1720,480 1920,360V1440H0V420Z"/>',
			'thumbnail' => '<path d="M0,0H1920V300C1680,440 1520,200 1340,360S1080,480 960,280 840,480 620,340 460,200 280,440 60,300 0,380V0Z"/>',
		),
		'dsm-mask-divider-round-scallops' => array(
			'label'     => 'Round Scallops',
			'regular'   => '<path d="M0,1440V1160C160,1160 160,960 320,960S480,1160 640,1160 640,960 960,960 960,1160 1280,1160 1280,960 1600,960 1600,1160 1920,1160V1440H0Z"/>',
			'inverted'  => '<path d="M0,960C160,960 160,1160 320,1160S480,960 640,960 640,1160 960,1160 960,960 1280,960 1280,1160 1600,1160 1600,960 1920,960V0H0V960Z"/>',
			'thumbnail' => '<path d="M0,1440V1080C180,1080 180,860 360,860S540,1080 720,1080 720,860 960,860 960,1080 1200,1080 1200,860 1560,860 1560,1080 1920,1080V1440H0Z"/>',
		),

		// ── Brush / zigzag / slant edges ──────────────────────────────────
		'dsm-mask-divider-brush-edge'     => array(
			'label'     => 'Brush Edge',
			'regular'   => '<path d="M0,1440V940C140,820 220,1020 380,880S560,1060 720,860 900,1040 1080,820 1260,1000 1440,840 1620,1020 1780,880 1920,980V1440H0Z"/>',
			'inverted'  => '<path d="M0,980C140,880 220,1020 380,880S560,1060 720,860 900,1040 1080,820 1260,1000 1440,840 1620,1020 1780,880 1920,980V0H0V980Z"/>',
			'thumbnail' => '<path d="M0,1440V860C160,720 260,920 420,780S600,980 780,780 960,980 1140,760 1320,960 1500,780 1680,980 1920,880V1440H0Z"/>',
		),
		'dsm-mask-divider-zigzag-edge'    => array(
			'label'     => 'Zigzag Edge',
			'regular'   => '<path d="M0,1440V1180L200,1180 400,880 600,1180 800,880 1000,1180 1200,880 1400,1180 1600,880 1920,1180V1440H0Z"/>',
			'inverted'  => '<path d="M0,880L200,880 400,1180 600,880 800,1180 1000,880 1200,1180 1400,880 1600,1180 1920,880V0H0V880Z"/>',
			'thumbnail' => '<path d="M0,1440V1100L220,1100 440,780 660,1100 880,780 1100,1100 1320,780 1540,1100 1920,1100V1440H0Z"/>',
		),
		'dsm-mask-divider-slant-strip'    => array(
			'label'     => 'Slant Strip',
			'regular'   => '<path d="M0,1440V1260L1920,1140V1440H0Z"/>',
			'inverted'  => '<path d="M0,1140L1920,1260V1440H0V1140Z"/>',
			'thumbnail' => '<path d="M0,1440V1200L1920,1080V1440H0Z"/>',
		),

		// ── Split / stroke / layered curves ───────────────────────────────
		'dsm-mask-divider-book-valley'    => array(
			'label'     => 'Book Valley',
			'regular'   => '<path d="M0,1440V480L960,1440 1920,480V1440H0Z"/>',
			'inverted'  => '<path d="M0,480L960,1440 1920,480V0H0V480Z"/>',
			'thumbnail' => '<path d="M0,1440V420L960,1440 1920,420V1440H0Z"/>',
		),
		'dsm-mask-divider-line-bands'     => array(
			'label'     => 'Line Bands',
			'regular'   => '<path fill-opacity=".35" d="M0,1440V1280H1920V1440H0Z"/><path fill-opacity=".6" d="M0,1280V1220H1920V1280H0Z"/><path d="M0,1220V1160H1920V1220H0Z"/>',
			'inverted'  => '<path d="M0,0H1920V1160H0V0Zm0,1160V1220H1920V1160H0Zm0,60V1280H1920V1220H0Zm0,60V1440H1920V1280H0Z"/>',
			'thumbnail' => '<path fill-opacity=".35" d="M0,1440V1240H1920V1440H0Z"/><path fill-opacity=".6" d="M0,1240V1160H1920V1240H0Z"/><path d="M0,1160V1080H1920V1160H0Z"/>',
		),
		'dsm-mask-divider-curve-stack'    => array(
			'label'     => 'Curve Stack',
			'regular'   => '<path fill-opacity=".35" d="M0,1440V1000C480,880 960,1120 1440,960S1920,920 1920,1040V1440H0Z"/><path fill-opacity=".6" d="M0,1440V1100C420,980 840,1180 1260,1040S1740,980 1920,1080V1440H0Z"/><path d="M0,1440V1200C360,1100 720,1280 1080,1160S1680,1080 1920,1140V1440H0Z"/>',
			'inverted'  => '<path d="M0,0H1920V1040C1440,1120 960,880 480,1040S0,920 0,1000V0H0Zm0,1040V1080C1260,1180 840,980 420,1120S0,1060 0,1100V1040H0Zm0,60V1140C1560,1240 1080,1040 660,1180S0,1120 0,1200V1100H0Z"/>',
			'thumbnail' => '<path fill-opacity=".35" d="M0,1440V920C520,780 980,1080 1460,900S1920,860 1920,980V1440H0Z"/><path fill-opacity=".6" d="M0,1440V1040C460,900 900,1120 1340,980S1780,920 1920,1020V1440H0Z"/><path d="M0,1440V1140C400,1020 780,1220 1140,1080S1720,1000 1920,1060V1440H0Z"/>',
		),
		'dsm-mask-divider-arrow-sweep'    => array(
			'label'     => 'Wing Sweep',
			'regular'   => '<path d="M0,1440V720L1280,1440 1920,840V1440H0Z"/>',
			'inverted'  => '<path d="M0,720L1280,1440 1920,840V0H0V720Z"/>',
			'thumbnail' => '<path d="M0,1440V660L1180,1440 1920,760V1440H0Z"/>',
		),
	);
}

/**
 * Dsm mask pattern library divider style mask manifest.
 *
 * @return array<string, array{label:string}>
 */
function dsm_mask_pattern_library_divider_style_mask_manifest(): array {
	/**
	 * Value.
	 *
	 * @var array<string, array{label:string}> $manifest
	 */
	$manifest = array();

	foreach ( dsm_mask_pattern_library_divider_style_masks() as $slug => $data ) {
		$manifest[ $slug ] = array(
			'label' => $data['label'],
		);
	}

	return $manifest;
}
