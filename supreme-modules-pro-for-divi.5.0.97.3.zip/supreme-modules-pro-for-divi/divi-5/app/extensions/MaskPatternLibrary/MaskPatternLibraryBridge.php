<?php
/**
 * Registers Divi mask/pattern library filters and VB bootstrap data.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Extensions\MaskPatternLibrary;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

require_once DSM_DIR_PATH . 'divi-5/app/extensions/MaskPatternLibrary/ExtensionSettings.php';

/**
 * Bridges Supreme mask/pattern entries into Divi 5 PHP + Visual Builder runtimes.
 */
final class MaskPatternLibraryBridge {

	/**
	 * Register WordPress hooks.
	 *
	 * @return void
	 */
	public static function register(): void {
		add_filter( 'divi_mask_and_pattern_library_mask', array( self::class, 'merge_masks' ), 20 );
		add_filter( 'divi_mask_and_pattern_library_pattern', array( self::class, 'merge_patterns' ), 20 );
		add_action( 'divi_visual_builder_assets_before_enqueue_scripts', array( self::class, 'register_vb_bootstrap_script' ), 5 );
	}

	/**
	 * Append Supreme masks to Divi's keyed mask defaults.
	 *
	 * @param array<string, array<string, mixed>> $mask_style_defaults Divi mask defaults keyed by slug.
	 * @return array<string, array<string, mixed>>
	 */
	public static function merge_masks( array $mask_style_defaults ): array {
		foreach ( MaskPatternRegistry::get_masks() as $slug => $entry ) {
			if ( ! ExtensionSettings::is_mask_enabled( $slug ) ) {
				continue;
			}

			if ( ! isset( $mask_style_defaults[ $slug ] ) ) {
				$mask_style_defaults[ $slug ] = $entry;
			}
		}

		return $mask_style_defaults;
	}

	/**
	 * Append Supreme patterns to Divi's keyed pattern defaults.
	 *
	 * @param array<string, array<string, mixed>> $pattern_style_defaults Divi pattern defaults keyed by slug.
	 * @return array<string, array<string, mixed>>
	 */
	public static function merge_patterns( array $pattern_style_defaults ): array {
		foreach ( MaskPatternRegistry::get_patterns() as $slug => $entry ) {
			if ( ! ExtensionSettings::is_pattern_enabled( $slug ) ) {
				continue;
			}

			if ( ! isset( $pattern_style_defaults[ $slug ] ) ) {
				$pattern_style_defaults[ $slug ] = $entry;
			}
		}

		return $pattern_style_defaults;
	}

	/**
	 * Inline bootstrap consumed by `mask-pattern-library-vb-hooks.js`.
	 *
	 * @return void
	 */
	public static function register_vb_bootstrap_script(): void {
		if ( ! ExtensionSettings::is_extension_enabled() ) {
			return;
		}

		if ( ! function_exists( 'et_core_is_fb_enabled' ) || ! et_core_is_fb_enabled() ) {
			return;
		}

		if ( ! function_exists( 'et_builder_d5_enabled' ) || ! et_builder_d5_enabled() ) {
			return;
		}

		$data = array(
			'masks'    => MaskPatternRegistry::get_masks_for_vb(),
			'patterns' => MaskPatternRegistry::get_patterns_for_vb(),
		);

		$version = defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';
		wp_register_script( 'dsm-mask-pattern-library-vb-bootstrap', false, array(), $version, true );
		wp_enqueue_script( 'dsm-mask-pattern-library-vb-bootstrap' );
		wp_add_inline_script(
			'dsm-mask-pattern-library-vb-bootstrap',
			'window.dsmMaskPatternLibraryBootstrap=' . wp_json_encode( $data ) . ';',
			'before'
		);
	}
}
