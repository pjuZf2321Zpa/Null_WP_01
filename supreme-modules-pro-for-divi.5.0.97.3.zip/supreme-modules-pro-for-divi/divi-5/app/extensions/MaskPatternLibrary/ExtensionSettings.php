<?php
/**
 * Mask & Pattern Library extension — global and per-item enable flags.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Extensions\MaskPatternLibrary {

	if ( ! defined( 'ABSPATH' ) ) {
		die( 'Direct access forbidden.' );
	}

	require_once DSM_DIR_PATH . 'divi-5/app/extensions/MaskPatternLibrary/MaskPatternRegistry.php';

	/**
	 * WordPress option helpers for Mask & Pattern Library settings.
	 */
	final class ExtensionSettings {

		/**
		 * Is extension enabled.
		 *
		 * @return bool
		 */
		public static function is_extension_enabled(): bool {
			$general = get_option( 'dsm_general', array() );

			if ( ! is_array( $general ) ) {
				return false;
			}

			if ( ! array_key_exists( 'dsm_use_mask_pattern_library', $general ) ) {
				return false;
			}

			return 'on' === $general['dsm_use_mask_pattern_library'];
		}

		/**
		 * Per mask/pattern enable flags (`dsm_mask_pattern_library` option).
		 *
		 * @return array<string, string>
		 */
		public static function get_selection_settings(): array {
			$saved = get_option( 'dsm_mask_pattern_library', array() );

			if ( ! is_array( $saved ) ) {
				$saved = array();
			}

			/**
			 * Merged.
			 *
			 * @var array<string, string> $defaults
			 */
			$defaults = self::get_default_selection();

			/**
			 * Get default selection.
			 *
			 * @var array<string, string> $merged
			 */
			$merged = wp_parse_args( $saved, $defaults );

			return $merged;
		}

		/**
		 * Default selection: all masks and patterns enabled (opt-out).
		 *
		 * @return array<string, string>
		 */
		public static function get_default_selection(): array {
			/**
			 * Value.
			 *
			 * @var array<string, string> $defaults
			 */
			$defaults = array();

			foreach ( MaskPatternRegistry::get_mask_slugs() as $slug ) {
				$defaults[ $slug ] = 'on';
			}

			foreach ( MaskPatternRegistry::get_pattern_slugs() as $slug ) {
				$defaults[ $slug ] = 'on';
			}

			return $defaults;
		}

		/**
		 * Is mask enabled.
		 *
		 * @param string $slug Mask slug (e.g. dsm-mask-ink-bloom).
		 * @return bool
		 */
		public static function is_mask_enabled( string $slug ): bool {
			if ( ! self::is_extension_enabled() ) {
				return false;
			}

			$settings = self::get_selection_settings();

			return isset( $settings[ $slug ] ) && 'on' === $settings[ $slug ];
		}

		/**
		 * Is pattern enabled.
		 *
		 * @param string $slug Pattern slug (e.g. dsm-pattern-bauhaus-bold).
		 * @return bool
		 */
		public static function is_pattern_enabled( string $slug ): bool {
			if ( ! self::is_extension_enabled() ) {
				return false;
			}

			$settings = self::get_selection_settings();

			return isset( $settings[ $slug ] ) && 'on' === $settings[ $slug ];
		}
	}

}

namespace {

	use DiviSupreme\Extensions\MaskPatternLibrary\ExtensionSettings;

	if ( ! function_exists( 'dsm_is_mask_pattern_library_extension_enabled' ) ) {
		/**
		 * Dsm is mask pattern library extension enabled.
		 *
		 * @return bool
		 */
		function dsm_is_mask_pattern_library_extension_enabled(): bool {
			return ExtensionSettings::is_extension_enabled();
		}
	}

	if ( ! function_exists( 'dsm_get_mask_pattern_library_settings' ) ) {
		/**
		 * Dsm get mask pattern library settings.
		 *
		 * @return array<string, string>
		 */
		function dsm_get_mask_pattern_library_settings(): array {
			return ExtensionSettings::get_selection_settings();
		}
	}

	if ( ! function_exists( 'dsm_is_mask_pattern_library_mask_enabled' ) ) {
		/**
		 * Dsm is mask pattern library mask enabled.
		 *
		 * @return bool
		 * @param string $slug Slug.
		 */
		function dsm_is_mask_pattern_library_mask_enabled( string $slug ): bool {
			return ExtensionSettings::is_mask_enabled( $slug );
		}
	}

	if ( ! function_exists( 'dsm_is_mask_pattern_library_pattern_enabled' ) ) {
		/**
		 * Dsm is mask pattern library pattern enabled.
		 *
		 * @return bool
		 * @param string $slug Slug.
		 */
		function dsm_is_mask_pattern_library_pattern_enabled( string $slug ): bool {
			return ExtensionSettings::is_pattern_enabled( $slug );
		}
	}
}
