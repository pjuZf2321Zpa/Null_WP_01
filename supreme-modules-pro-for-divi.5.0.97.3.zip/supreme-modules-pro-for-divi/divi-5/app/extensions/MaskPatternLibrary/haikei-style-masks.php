<?php
/**
 * Haikei-inspired mask definitions (original shapes — not copied from haikei.app).
 *
 * Curated for visual distinctness: no near-duplicate silhouettes, full-frame edge anchors.
 * Regenerate assets: php divi-5/app/extensions/MaskPatternLibrary/generate-svg-assets.php
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) && ! defined( 'DSM_MASK_GEN_CLI' ) ) {
	if ( 'cli' !== PHP_SAPI ) {
		exit;
	}
}

/**
 * Dsm mask pattern library haikei style masks.
 *
 * @return array<string, array{label:string,regular:string,inverted:string,thumbnail:string}>
 */
function dsm_mask_pattern_library_haikei_style_masks(): array {
	return array(
		// ── Single waves ──────────────────────────────────────────────────
		'dsm-mask-wave-soft-bottom'     => array(
			'label'     => 'Wave: Gentle Bottom',
			'regular'   => '<path d="M0,1440V920C320,780 640,1040 960,860s640,120 960,40V1440H0Z"/>',
			'inverted'  => '<path d="M0,0H1920V900C1600,1020 1280,820 960,940s-640,80-960,40V0H0Z"/>',
			'thumbnail' => '<path d="M0,1440V840C360,680 720,980 1080,780s720,160 840,60V1440H0Z"/>',
		),
		'dsm-mask-wave-sharp-bottom'    => array(
			'label'     => 'Wave: Jagged Bottom',
			'regular'   => '<path d="M0,1440V980L280,860 560,1080 840,820 1120,1060 1400,780 1680,1020 1920,880V1440H0Z"/>',
			'inverted'  => '<path d="M0,0H1920V880L1680,1020 1400,780 1120,1060 840,820 560,1080 280,860 0,980V0H0Z"/>',
			'thumbnail' => '<path d="M0,1440V900L320,740 640,1040 960,760 1280,1020 1600,720 1920,940V1440H0Z"/>',
		),
		'dsm-mask-wave-top-deep'        => array(
			'label'     => 'Wave: Top Banner',
			'regular'   => '<path d="M0,0H1920V720C1680,860 1320,580 960,760S480,640 0,820V0Z"/>',
			'inverted'  => '<path d="M0,820C480,640 720,780 960,760s480-180 960,0V1440H0V820Z"/>',
			'thumbnail' => '<path d="M0,0H1920V640C1600,820 1200,520 960,700S400,560 0,760V0Z"/>',
		),
		'dsm-mask-wave-left-flow'       => array(
			'label'     => 'Wave: Side Panel',
			'regular'   => '<path d="M0,0V1440H620C740,1200 740,840 620,600S740,240 620,0H0Z"/>',
			'inverted'  => '<path d="M620,0H1920V1440H620C740,1200 740,840 620,600S740,240 620,0Z"/>',
			'thumbnail' => '<path d="M0,0V1440H720C860,1180 860,780 720,520S860,180 720,0H0Z"/>',
		),
		// ── Layered waves ─────────────────────────────────────────────────
		'dsm-mask-wave-layers-triple'   => array(
			'label'     => 'Wave: Triple Bands',
			'regular'   => '<path fill-opacity=".35" d="M0,1440V920C320,820 640,980 960,860s640,60 960,100V1440H0Z"/><path fill-opacity=".6" d="M0,1440V1040C280,940 560,1100 840,980s560,40 840,80V1440H0Z"/><path d="M0,1440V1180C240,1100 480,1240 720,1160s560,20 840,60V1440H0Z"/>',
			'inverted'  => '<path d="M0,0H1920V920H0C320,820 640,980 960,860s640,60 960,100V0H0Zm0,920V1040C280,940 560,1100 840,980s560,40 840,80V920H0Zm0,160V1180C240,1100 480,1240 720,1160s560,20 840,60V1080H0Z"/>',
			'thumbnail' => '<path fill-opacity=".35" d="M0,1440V840C360,720 720,920 1080,780s720,80 840,40V1440H0Z"/><path fill-opacity=".6" d="M0,1440V980C320,860 640,1060 960,900s640,60 960,100V1440H0Z"/><path d="M0,1440V1140C280,1040 560,1280 840,1160s640,40 840,80V1440H0Z"/>',
		),
		'dsm-mask-wave-layers-top'      => array(
			'label'     => 'Wave: Layered Cap',
			'regular'   => '<path fill-opacity=".35" d="M0,0H1920V480C1680,600 1320,360 960,520S480,400 0,560V0Z"/><path fill-opacity=".6" d="M0,0H1920V360C1600,480 1280,280 960,420S400,320 0,440V0Z"/><path d="M0,0H1920V240C1520,360 1200,200 960,320S400,240 0,360V0Z"/>',
			'inverted'  => '<path d="M0,560C480,400 720,540 960,520s360-160 960,0V1440H0V560Zm0-200C400,320 640,460 960,420s360-140 960,0V360H0Zm0-120C400,240 640,380 960,320s360-120 960,0V240H0Z"/>',
			'thumbnail' => '<path fill-opacity=".35" d="M0,0H1920V520C1640,660 1280,420 960,580S400,460 0,620V0Z"/><path fill-opacity=".6" d="M0,0H1920V380C1580,520 1220,300 960,460S380,340 0,480V0Z"/><path d="M0,0H1920V260C1500,400 1140,220 960,340S380,260 0,400V0Z"/>',
		),
		'dsm-mask-wave-layers-steep'    => array(
			'label'     => 'Wave: Steep Ridges',
			'regular'   => '<path fill-opacity=".4" d="M0,1440V760L480,640 960,880 1440,600 1920,780V1440H0Z"/><path fill-opacity=".65" d="M0,1440V980L420,860 840,1100 1260,820 1920,960V1440H0Z"/><path d="M0,1440V1180L380,1060 760,1280 1140,1000 1920,1140V1440H0Z"/>',
			'inverted'  => '<path d="M0,0H1920V780L1440,600 960,880 480,640 0,760V0H0Zm0,760V980L1260,820 840,1100 420,860 0,960V760H0Zm0,220V1180L1140,1000 760,1280 380,1060 0,1140V980H0Z"/>',
			'thumbnail' => '<path fill-opacity=".4" d="M0,1440V700L520,560 1040,840 1560,540 1920,720V1440H0Z"/><path fill-opacity=".65" d="M0,1440V940L440,800 880,1080 1320,780 1920,920V1440H0Z"/><path d="M0,1440V1140L400,1000 800,1260 1200,960 1920,1100V1440H0Z"/>',
		),
		'dsm-mask-wave-layers-diagonal' => array(
			'label'     => 'Wave: Diagonal Bands',
			'regular'   => '<path fill-opacity=".35" d="M0,1440V1080L640,920 1280,1100 1920,940V1440H0Z"/><path fill-opacity=".6" d="M0,1440V1180L720,1020 1440,1200 1920,1060V1440H0Z"/><path d="M0,1440V1280L800,1160 1920,1300V1440H0Z"/>',
			'inverted'  => '<path d="M0,0H1920V940L1280,1100 640,920 0,1080V0H0Zm0,1080V1060L1440,1200 720,1020 0,1180V1080H0Zm0,100V1300L800,1160 0,1280V1180H0Z"/>',
			'thumbnail' => '<path fill-opacity=".35" d="M0,1440V1000L680,840 1360,1060 1920,880V1440H0Z"/><path fill-opacity=".6" d="M0,1440V1120L760,960 1520,1180 1920,1020V1440H0Z"/><path d="M0,1440V1240L840,1100 1920,1260V1440H0Z"/>',
		),

		// ── Organic blobs ─────────────────────────────────────────────────
		'dsm-mask-blob-corner-tr'       => array(
			'label'     => 'Blob: Corner Burst',
			'regular'   => '<path d="M1920,0H1200C1320,180 1280,420 1480,520S1800,380 1920,620V0Z"/><path d="M1920,0V720C1700,580 1580,820 1920,900V0Z"/>',
			'inverted'  => '<path d="M0,0H1200C1320,180 1280,420 1480,520S1800,380 1920,620V900C1580,820 1700,580 1920,720V1440H0V0Z"/>',
			'thumbnail' => '<path d="M1920,0H1080C1220,200 1180,480 1400,580S1840,420 1920,680V0Z"/><path d="M1920,0V780C1660,620 1520,900 1920,980V0Z"/>',
		),
		'dsm-mask-blob-edge-left'       => array(
			'label'     => 'Blob: Side Ribbon',
			'regular'   => '<path d="M0,0V1440H480C620,1280 560,1080 680,920S520,640 620,480,380,260 480,80,280,180 0,0Z"/>',
			'inverted'  => '<path d="M480,0H1920V1440H480C380,260 620,480 620,480S520,640 680,920,560,1080 620,1280,480,0Z"/>',
			'thumbnail' => '<path d="M0,0V1440H560C720,1260 640,1040 780,860S580,580 700,400,420,220 560,60,320,160 0,0Z"/>',
		),
		'dsm-mask-ink-flood'            => array(
			'label'     => 'Blob: Ink Flood',
			'regular'   => '<path d="M0,1440V640C180,520 420,780 720,580S1140,720 960,920,720,760 480,980,240,820 0,920V1440Z"/>',
			'inverted'  => '<path d="M0,920C240,820 480,980 720,920S540,640 720,580,420,780 180,520 0,640V0H1920V1440H0Z"/>',
			'thumbnail' => '<path d="M0,1440V560C220,420 480,720 780,520S1200,680 980,880,740,700 500,920,260,760 0,860V1440Z"/>',
		),

		// ── Peaks / mountains ─────────────────────────────────────────────
		'dsm-mask-peak-jagged-bottom'   => array(
			'label'     => 'Peaks: Jagged Edge',
			'regular'   => '<path d="M0,1440V1080L160,960 320,1180 480,900 640,1120 800,860 960,1100 1120,820 1280,1060 1440,780 1600,1040 1760,800 1920,1020V1440H0Z"/>',
			'inverted'  => '<path d="M0,1020L160,800 320,1040 480,780 640,1060 800,820 960,1080 1120,780 1280,1040 1440,760 1600,1000 1760,740 1920,960V0H0V1020Z"/>',
			'thumbnail' => '<path d="M0,1440V1000L180,860 360,1140 540,840 720,1080 900,800 1080,1060 1260,760 1440,1020 1620,740 1920,980V1440H0Z"/>',
		),
		'dsm-mask-peak-pyramid'         => array(
			'label'     => 'Peaks: Pyramid',
			'regular'   => '<path d="M0,1440V1120L960,480 1920,1120V1440H0Z"/>',
			'inverted'  => '<path d="M0,1120L960,480 1920,1120V0H0V1120Z"/>',
			'thumbnail' => '<path d="M0,1440V1040L960,360 1920,1040V1440H0Z"/>',
		),
		'dsm-mask-peak-valley-wide'     => array(
			'label'     => 'Peaks: Wide Valley',
			'regular'   => '<path d="M0,1440V860L640,1180 1280,720 1920,980V1440H0Z"/>',
			'inverted'  => '<path d="M0,980L640,720 1280,1180 1920,860V0H0V980Z"/>',
			'thumbnail' => '<path d="M0,1440V780L680,1160 1360,660 1920,920V1440H0Z"/>',
		),
		'dsm-mask-peak-asymmetric'      => array(
			'label'     => 'Peaks: Asymmetric Range',
			'regular'   => '<path d="M0,1440V1040L420,720 780,1100 1140,580 1560,960 1920,680V1440H0Z"/>',
			'inverted'  => '<path d="M0,680L420,960 780,580 1140,1100 1560,720 1920,1040V0H0V680Z"/>',
			'thumbnail' => '<path d="M0,1440V960L460,620 820,1060 1180,520 1580,920 1920,620V1440H0Z"/>',
		),
		'dsm-mask-canyon-valley'        => array(
			'label'     => 'Peaks: Canyon Split',
			'regular'   => '<path d="M0,1440V720L960,1180 1920,720V1440H0Z"/>',
			'inverted'  => '<path d="M0,720L960,1180 1920,720V0H0V720Z"/>',
			'thumbnail' => '<path d="M0,1440V640L960,1240 1920,640V1440H0Z"/>',
		),

		// ── Low-poly ──────────────────────────────────────────────────────
		'dsm-mask-poly-low-left'        => array(
			'label'     => 'Low Poly: Faceted Side',
			'regular'   => '<path d="M0,0V1440H720L480,1080 960,720 360,480 680,120 0,0Z"/>',
			'inverted'  => '<path d="M720,0H1920V1440H720L960,1080 480,720 1080,480 760,120,720,0Z"/>',
			'thumbnail' => '<path d="M0,0V1440H780L520,1060 1020,680 400,440 740,80 0,0Z"/>',
		),
		'dsm-mask-poly-facet-bottom'    => array(
			'label'     => 'Low Poly: Facet Edge',
			'regular'   => '<path d="M0,1440V960L320,780 640,1080 960,740 1280,1020 1600,800 1920,980V1440H0Z"/>',
			'inverted'  => '<path d="M0,980L320,800 640,1080 960,740 1280,1020 1600,800 1920,980V0H0V980Z"/>',
			'thumbnail' => '<path d="M0,1440V880L360,680 720,1060 1080,700 1440,980 1680,760 1920,940V1440H0Z"/>',
		),
		'dsm-mask-poly-crystal'         => array(
			'label'     => 'Low Poly: Crystal Shard',
			'regular'   => '<path d="M0,1440V720L480,480 960,900 1440,420 1920,780V1440H0Z"/>',
			'inverted'  => '<path d="M0,780L480,420 960,900 1440,480 1920,720V0H0V780Z"/>',
			'thumbnail' => '<path d="M0,1440V660L520,400 960,880 1480,360 1920,720V1440H0Z"/>',
		),
		'dsm-mask-poly-shard'           => array(
			'label'     => 'Low Poly: Diagonal Shard',
			'regular'   => '<path d="M0,0H1080L720,360 1320,720 600,1080 960,1440H0V0Z"/>',
			'inverted'  => '<path d="M1080,0H1920V1440H960L1320,720 720,360 1080,0Z"/>',
			'thumbnail' => '<path d="M0,0H1140L760,340 1400,740 640,1120 1020,1440H0V0Z"/>',
		),
		// ── Corner cuts ───────────────────────────────────────────────────
		'dsm-mask-corner-soft-tl'       => array(
			'label'     => 'Corner: Soft Scoop',
			'regular'   => '<path d="M0,0H920C680,180 520,380 420,620S280,980 0,1120V0Z"/>',
			'inverted'  => '<path d="M920,0H1920V1440H0V1120C280,980 420,620 520,380S680,180 920,0Z"/>',
			'thumbnail' => '<path d="M0,0H980C720,200 540,420 440,680S300,1040 0,1180V0Z"/>',
		),
		'dsm-mask-corner-diagonal-tr'   => array(
			'label'     => 'Corner: Hard Diagonal',
			'regular'   => '<path d="M1920,0H960L1920,720V0Z"/>',
			'inverted'  => '<path d="M960,0H1920V720L960,0ZM0,0V1440H1920V720L960,0H0Z"/>',
			'thumbnail' => '<path d="M1920,0H880L1920,780V0Z"/>',
		),
		'dsm-mask-diagonal-slash'       => array(
			'label'     => 'Slash: Full Diagonal',
			'regular'   => '<path d="M0,0H1280L1920,1440H0V0Z"/>',
			'inverted'  => '<path d="M1280,0H1920V1440H0V0Z"/>',
			'thumbnail' => '<path d="M0,0H1180L1920,1440H0V0Z"/>',
		),
		'dsm-mask-tilt-panel'           => array(
			'label'     => 'Block: Tilt Panel',
			'regular'   => '<path d="M0,0H1520L1920,1440H0V0Z"/>',
			'inverted'  => '<path d="M1520,0H1920V1440H0V0Z"/>',
			'thumbnail' => '<path d="M0,0H1420L1920,1440H0V0Z"/>',
		),

		// ── Soft blobs ────────────────────────────────────────────────────
		'dsm-mask-blur-blob-bottom'     => array(
			'label'     => 'Soft Blob: Rolling Hills',
			'regular'   => '<path d="M0,1440V820C160,680 360,920 580,760S920,640 1120,820,1380,700 1920,880V1440H0Z"/>',
			'inverted'  => '<path d="M0,880C540,700 780,820 1120,820S420,680 580,760,160,680 0,820V0H1920V1440H0Z"/>',
			'thumbnail' => '<path d="M0,1440V760C180,600 400,880 620,700S960,580 1160,780,1420,660 1920,840V1440H0Z"/>',
		),
		'dsm-mask-blur-cloud-top'       => array(
			'label'     => 'Soft Blob: Cloud Cap',
			'regular'   => '<path d="M0,0H1920V480C1720,620 1520,340 1280,520S840,400 640,560,320,380 0,520V0Z"/>',
			'inverted'  => '<path d="M0,520C320,380 480,560 640,560S1080,400 1280,520s240-180 640,0V1440H0V520Z"/>',
			'thumbnail' => '<path d="M0,0H1920V420C1700,580 1480,280 1220,480S780,360 560,540,280,340 0,480V0Z"/>',
		),

		// ── Arches & folds ────────────────────────────────────────────────
		'dsm-mask-arch-bottom'          => array(
			'label'     => 'Arch: Hero Bottom',
			'regular'   => '<path d="M0,1440V720A960,720,0,0,1,1920,720V1440H0Z"/>',
			'inverted'  => '<path d="M0,720A960,720,0,0,0,1920,720V0H0V720Z"/>',
			'thumbnail' => '<path d="M0,1440V680A960,760,0,0,1,1920,680V1440H0Z"/>',
		),
		'dsm-mask-dome-top'             => array(
			'label'     => 'Arch: Dome Cap',
			'regular'   => '<path d="M0,0H1920V360A960,360,0,0,0,0,360V0Z"/>',
			'inverted'  => '<path d="M0,360A960,360,0,0,1,1920,360V1440H0V360Z"/>',
			'thumbnail' => '<path d="M0,0H1920V320A960,320,0,0,0,0,320V0Z"/>',
		),
		'dsm-mask-s-curve-divider'      => array(
			'label'     => 'Curve: S Divider',
			'regular'   => '<path d="M0,0V1440H540C720,1240 480,980 680,720S520,380 640,180,420,60 540,0H0Z"/>',
			'inverted'  => '<path d="M540,0H1920V1440H540C420,60 640,180 680,380S720,980 540,1240,540,0Z"/>',
			'thumbnail' => '<path d="M0,0V1440H620C820,1220 560,940 780,660S600,340 740,120,480,40 620,0H0Z"/>',
		),
		'dsm-mask-zigzag-side'          => array(
			'label'     => 'Zigzag: Side Panel',
			'regular'   => '<path d="M0,0V1440H420L280,1200 560,960 280,720 560,480 280,240 420,0H0Z"/>',
			'inverted'  => '<path d="M420,0H1920V1440H420L560,1200 280,960 560,720 280,480 560,240 420,0Z"/>',
			'thumbnail' => '<path d="M0,0V1440H480L320,1180 640,920 320,660 640,400 320,140 480,0H0Z"/>',
		),

		// ── Hybrids ───────────────────────────────────────────────────────
		'dsm-mask-hybrid-blob-steps'    => array(
			'label'     => 'Hybrid: Blob + Steps',
			'regular'   => '<path d="M0,1440V1080C180,960 360,1180 540,980S840,860 720,1080,480,920 0,1120V1440Z"/><path d="M720,1440V1180H960V1320H1200V1100H1440V1380H1920V1440H720Z"/>',
			'inverted'  => '<path d="M0,1120C480,920 600,1080 720,1080S360,960 540,980,180,960 0,1080V0H1920V1440H720V1180H960V1320H1200V1100H1440V1380H1920V1120H0Z"/>',
			'thumbnail' => '<path d="M0,1440V1020C200,880 400,1140 600,920S900,800 780,1040,540,860 0,1080V1440Z"/><path d="M780,1440V1120H1020V1280H1280V1060H1520V1360H1920V1440H780Z"/>',
		),
	);
}

/**
 * Slug => label manifest for MaskPatternRegistry.
 *
 * @return array<string, array{label:string}>
 */
function dsm_mask_pattern_library_haikei_style_mask_manifest(): array {
	/**
	 * Value.
	 *
	 * @var array<string, array{label:string}> $manifest
	 */
	$manifest = array();

	foreach ( dsm_mask_pattern_library_haikei_style_masks() as $slug => $data ) {
		$manifest[ $slug ] = array(
			'label' => $data['label'],
		);
	}

	return $manifest;
}
