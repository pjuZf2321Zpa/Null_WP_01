<?php
/**
 * Pluggable registry for Divi Supreme mask/pattern library entries.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Extensions\MaskPatternLibrary;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Loads self-hosted SVG assets and exposes mask/pattern entries for PHP + VB bootstrap.
 */
final class MaskPatternRegistry {

	/**
	 * Masks.
	 *
	 * @var array<string, array<string, mixed>>|null
	 */
	private static ?array $masks = null;

	/**
	 * Patterns.
	 *
	 * @var array<string, array<string, mixed>>|null
	 */
	private static ?array $patterns = null;

	/**
	 * Absolute path to bundled SVG assets.
	 *
	 * @return string
	 */
	public static function assets_dir(): string {
		return DSM_DIR_PATH . 'divi-5/app/extensions/MaskPatternLibrary/assets/svg/';
	}

	/**
	 * Get masks.
	 *
	 * @return array<string, array<string, mixed>>
	 */
	public static function get_masks(): array {
		if ( null !== self::$masks ) {
			return self::$masks;
		}

		self::$masks = array();

		foreach ( self::get_mask_manifest() as $slug => $meta ) {
			$regular   = self::load_variant_markup( 'masks', $slug, 'regular' );
			$inverted  = self::load_variant_markup( 'masks', $slug, 'inverted' );
			$thumbnail = self::load_variant_markup( 'masks', $slug, 'thumbnail', false );

			if ( '' === $thumbnail ) {
				$thumbnail = $regular;
			}

			self::$masks[ $slug ] = MaskPatternEntryBuilder::build_mask(
				$slug,
				(string) $meta['label'],
				array(
					'regular'          => $regular,
					'regular_rotated'  => $regular,
					'inverted'         => $inverted,
					'inverted_rotated' => $inverted,
					'thumbnail'        => $thumbnail,
				)
			);
		}

		/**
		 * Filter Supreme mask library entries before registration.
		 *
		 * @param array<string, array<string, mixed>> $masks Mask entries keyed by slug.
		 */
		self::$masks = \apply_filters( 'dsm_mask_pattern_library_masks', self::$masks );

		return self::$masks;
	}

	/**
	 * Get patterns.
	 *
	 * @return array<string, array<string, mixed>>
	 */
	public static function get_patterns(): array {
		if ( null !== self::$patterns ) {
			return self::$patterns;
		}

		self::$patterns = array();

		foreach ( self::get_pattern_manifest() as $slug => $meta ) {
			$regular   = self::load_variant_markup( 'patterns', $slug, 'regular' );
			$inverted  = self::load_variant_markup( 'patterns', $slug, 'inverted' );
			$thumbnail = self::load_variant_markup( 'patterns', $slug, 'thumbnail', false );

			if ( '' === $thumbnail ) {
				$thumbnail = $regular;
			}

			self::$patterns[ $slug ] = MaskPatternEntryBuilder::build_pattern(
				$slug,
				(string) $meta['label'],
				(string) $meta['width'],
				(string) $meta['height'],
				array(
					'regular'          => $regular,
					'rotated'          => $regular,
					'inverted'         => $inverted,
					'inverted_rotated' => $inverted,
					'thumbnail'        => $thumbnail,
				),
				(int) ( $meta['priority'] ?? 20 )
			);
		}

		/**
		 * Filter Supreme pattern library entries before registration.
		 *
		 * @param array<string, array<string, mixed>> $patterns Pattern entries keyed by slug.
		 */
		self::$patterns = \apply_filters( 'dsm_mask_pattern_library_patterns', self::$patterns );

		return self::$patterns;
	}

	/**
	 * Mask slugs from the declarative manifest (no SVG load).
	 *
	 * @return array<int, string>
	 */
	public static function get_mask_slugs(): array {
		return array_keys( self::get_mask_manifest() );
	}

	/**
	 * Pattern slugs from the declarative manifest (no SVG load).
	 *
	 * @return array<int, string>
	 */
	public static function get_pattern_slugs(): array {
		return array_keys( self::get_pattern_manifest() );
	}

	/**
	 * Thumbnail catalog for the settings dashboard preview grid.
	 *
	 * @return array{masks: array<int, array{id: string, label: string, thumbnail: string}>, patterns: array<int, array{id: string, label: string, thumbnail: string}>}
	 */
	public static function get_dashboard_catalog(): array {
		$masks    = array();
		$patterns = array();

		foreach ( self::get_mask_manifest() as $slug => $meta ) {
			$masks[] = array(
				'id'        => $slug,
				'label'     => (string) $meta['label'],
				'thumbnail' => self::load_dashboard_thumbnail_markup( 'masks', $slug ),
			);
		}

		foreach ( self::get_pattern_manifest() as $slug => $meta ) {
			$patterns[] = array(
				'id'        => $slug,
				'label'     => (string) $meta['label'],
				'thumbnail' => self::load_dashboard_thumbnail_markup( 'patterns', $slug ),
			);
		}

		return array(
			'masks'    => $masks,
			'patterns' => $patterns,
		);
	}

	/**
	 * Flat list for Visual Builder bootstrap (array of entry objects).
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public static function get_masks_for_vb(): array {
		if ( ! class_exists( ExtensionSettings::class ) ) {
			return array_values( self::get_masks() );
		}

		$enabled = array();

		foreach ( self::get_masks() as $slug => $entry ) {
			if ( ExtensionSettings::is_mask_enabled( $slug ) ) {
				$enabled[] = $entry;
			}
		}

		return $enabled;
	}

	/**
	 * Flat list for Visual Builder bootstrap (array of entry objects).
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public static function get_patterns_for_vb(): array {
		if ( ! class_exists( ExtensionSettings::class ) ) {
			return array_values( self::get_patterns() );
		}

		$enabled = array();

		foreach ( self::get_patterns() as $slug => $entry ) {
			if ( ExtensionSettings::is_pattern_enabled( $slug ) ) {
				$enabled[] = $entry;
			}
		}

		return $enabled;
	}

	/**
	 * Load variant markup.
	 *
	 * @param string $group    masks|patterns.
	 * @param string $slug     Entry slug.
	 * @param string $variant  regular|inverted|thumbnail.
	 * @param bool   $required When true, missing files throw.
	 * @return string
	 * @throws \RuntimeException When a required SVG asset is missing.
	 */
	private static function load_variant_markup(
		string $group,
		string $slug,
		string $variant,
		bool $required = true
	): string {
		$file = self::assets_dir() . $group . '/' . $slug . '-' . $variant . '.svg';

		if ( ! is_readable( $file ) ) {
			if ( $required ) {
				// phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- Developer-facing message.
				throw new \RuntimeException( 'Mask/pattern SVG asset missing: ' . $file );
			}

			return '';
		}

		$contents = file_get_contents( $file );

		if ( false === $contents ) {
			return '';
		}

		return MaskPatternEntryBuilder::normalize_svg_markup( $contents );
	}

	/**
	 * Full SVG markup for the settings dashboard preview grid.
	 *
	 * Unlike {@see load_variant_markup()}, this keeps the outer <svg> wrapper so React
	 * can inject valid HTML via dangerouslySetInnerHTML.
	 *
	 * @param string $group masks|patterns.
	 * @param string $slug  Entry slug.
	 * @return string
	 */
	private static function load_dashboard_thumbnail_markup( string $group, string $slug ): string {
		$raw = self::load_variant_file_contents( $group, $slug, 'thumbnail' );

		if ( '' === $raw ) {
			$raw = self::load_variant_file_contents( $group, $slug, 'regular' );
		}

		return self::prepare_dashboard_svg_preview( $raw, $group );
	}

	/**
	 * Read raw SVG asset file contents.
	 *
	 * @param string $group   masks|patterns.
	 * @param string $slug    Entry slug.
	 * @param string $variant regular|inverted|thumbnail.
	 * @return string
	 */
	private static function load_variant_file_contents(
		string $group,
		string $slug,
		string $variant
	): string {
		$file = self::assets_dir() . $group . '/' . $slug . '-' . $variant . '.svg';

		if ( ! is_readable( $file ) ) {
			return '';
		}

		$contents = file_get_contents( $file );

		if ( false === $contents ) {
			return '';
		}

		return trim( $contents );
	}

	/**
	 * Ensure dashboard thumbnails render inside the React preview cell.
	 *
	 * @param string $markup Raw SVG file contents.
	 * @param string $group  masks|patterns.
	 * @return string
	 */
	private static function prepare_dashboard_svg_preview( string $markup, string $group ): string {
		$markup = trim( $markup );

		if ( '' === $markup ) {
			return '';
		}

		if ( 'masks' === $group ) {
			if ( ! preg_match( '/\bviewBox=/i', $markup ) ) {
				$markup = (string) preg_replace(
					'/<svg\b/i',
					'<svg viewBox="0 0 1920 1440" preserveAspectRatio="xMidYMid slice"',
					$markup,
					1
				);
			}

			$markup = (string) preg_replace(
				'/<(path|circle|rect|polygon|ellipse)(?![^>]*\bfill=)/i',
				'<$1 fill="#4c1d95"',
				$markup
			);
		}

		if ( 'patterns' === $group ) {
			$markup = (string) preg_replace(
				'/<(path|circle|rect|polygon|ellipse)(?![^>]*\bfill=)/i',
				'<$1 fill="#5b21b6"',
				$markup
			);
		}

		return $markup;
	}

	/**
	 * Declarative mask manifest (slug => label).
	 *
	 * @return array<string, array{label:string}>
	 */
	private static function get_mask_manifest(): array {
		$supreme = array(
			'dsm-mask-ink-bloom'       => array( 'label' => 'Ink Bloom' ),
			'dsm-mask-glass-curve'     => array( 'label' => 'Glass Curve' ),
			'dsm-mask-brutalist-steps' => array( 'label' => 'Brutalist Steps' ),
			'dsm-mask-mesh-orbs'       => array( 'label' => 'Mesh Orbs' ),
			'dsm-mask-page-fold'       => array( 'label' => 'Page Fold' ),
			'dsm-mask-pixel-edge'      => array( 'label' => 'Pixel Edge' ),
			'dsm-mask-aurora-band'     => array( 'label' => 'Aurora Band' ),
			'dsm-mask-crescent-glow'   => array( 'label' => 'Crescent Glow' ),
			'dsm-mask-card-stack'      => array( 'label' => 'Card Stack' ),
			'dsm-mask-synth-grid'      => array( 'label' => 'Synth Grid' ),
			'dsm-mask-chrome-slice'    => array( 'label' => 'Chrome Slice' ),
			'dsm-mask-orbit-ring'      => array( 'label' => 'Orbit Ring' ),
		);

		return array_merge(
			$supreme,
			self::get_haikei_style_mask_manifest(),
			self::get_divider_style_mask_manifest()
		);
	}

	/**
	 * Original section-divider style masks (generic builder-inspired categories).
	 *
	 * @return array<string, array{label:string}>
	 */
	private static function get_divider_style_mask_manifest(): array {
		$manifest_file = __DIR__ . '/divider-style-masks.php';

		if ( ! is_readable( $manifest_file ) ) {
			return array();
		}

		require_once $manifest_file;

		if ( ! function_exists( 'dsm_mask_pattern_library_divider_style_mask_manifest' ) ) {
			return array();
		}

		return dsm_mask_pattern_library_divider_style_mask_manifest();
	}

	/**
	 * Haikei-inspired mask manifest (generated SVG set).
	 *
	 * @return array<string, array{label:string}>
	 */
	private static function get_haikei_style_mask_manifest(): array {
		$manifest_file = __DIR__ . '/haikei-style-masks.php';

		if ( ! is_readable( $manifest_file ) ) {
			return array();
		}

		require_once $manifest_file;

		if ( ! function_exists( 'dsm_mask_pattern_library_haikei_style_mask_manifest' ) ) {
			return array();
		}

		return dsm_mask_pattern_library_haikei_style_mask_manifest();
	}

	/**
	 * Declarative pattern manifest (slug => label + tile size).
	 *
	 * @return array<string, array{label:string,width:string,height:string}>
	 */
	private static function get_pattern_manifest(): array {
		$supreme = array(
			'dsm-pattern-bauhaus-bold'     => array(
				'label'  => 'Bauhaus Bold',
				'width'  => '72px',
				'height' => '72px',
			),
			'dsm-pattern-film-grain'       => array(
				'label'  => 'Film Grain',
				'width'  => '20px',
				'height' => '20px',
			),
			'dsm-pattern-node-network'     => array(
				'label'  => 'Node Network',
				'width'  => '64px',
				'height' => '64px',
			),
			'dsm-pattern-art-deco-fan'     => array(
				'label'  => 'Art Deco Fan',
				'width'  => '80px',
				'height' => '40px',
			),
			'dsm-pattern-gradient-mesh'    => array(
				'label'  => 'Gradient Mesh',
				'width'  => '96px',
				'height' => '96px',
			),
			'dsm-pattern-micro-grid'       => array(
				'label'  => 'Micro Grid',
				'width'  => '16px',
				'height' => '16px',
			),
			'dsm-pattern-speed-lines'      => array(
				'label'  => 'Speed Lines',
				'width'  => '64px',
				'height' => '32px',
			),
			'dsm-pattern-terrazzo'         => array(
				'label'  => 'Terrazzo',
				'width'  => '80px',
				'height' => '80px',
			),
			'dsm-pattern-braille-texture'  => array(
				'label'  => 'Braille Texture',
				'width'  => '24px',
				'height' => '32px',
			),
			'dsm-pattern-squiggle'         => array(
				'label'  => 'Squiggle',
				'width'  => '80px',
				'height' => '24px',
			),
			'dsm-pattern-brutalist-blocks' => array(
				'label'  => 'Brutalist Blocks',
				'width'  => '56px',
				'height' => '56px',
			),
			'dsm-pattern-water-ripple'     => array(
				'label'  => 'Water Ripple',
				'width'  => '64px',
				'height' => '64px',
			),
			'dsm-pattern-hash-weave'       => array(
				'label'  => 'Hash Weave',
				'width'  => '36px',
				'height' => '36px',
			),
			'dsm-pattern-capsule-tile'     => array(
				'label'  => 'Capsule Tile',
				'width'  => '48px',
				'height' => '24px',
			),
			'dsm-pattern-star-dust'        => array(
				'label'  => 'Star Dust',
				'width'  => '48px',
				'height' => '48px',
			),
		);

		$hero = self::get_hero_pattern_manifest();

		return array_merge( $supreme, $hero );
	}

	/**
	 * Hero Patterns (CC BY 4.0) — generated manifest + assets.
	 *
	 * @return array<string, array{label:string,width:string,height:string,priority?:int,source?:string}>
	 */
	private static function get_hero_pattern_manifest(): array {
		$manifest_file = __DIR__ . '/hero-patterns-manifest.php';

		if ( ! is_readable( $manifest_file ) ) {
			return array();
		}

		require_once $manifest_file;

		if ( ! function_exists( 'dsm_mask_pattern_library_hero_patterns_manifest' ) ) {
			return array();
		}

		return dsm_mask_pattern_library_hero_patterns_manifest();
	}
}
