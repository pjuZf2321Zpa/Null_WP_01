<?php
/**
 * Build Divi 5 mask/pattern library entries from compact SVG markup.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Extensions\MaskPatternLibrary;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Normalizes SVG leaf markup and expands mask/pattern entry shapes for Divi.
 */
final class MaskPatternEntryBuilder {

	/**
	 * Duplicate one landscape-oriented path across Divi mask orientations.
	 *
	 * @param string $path SVG inner markup (paths, circles, etc.).
	 * @return array{landscape:string,portrait:string,square:string}
	 */
	public static function mask_orientations( string $path ): array {
		return array(
			'landscape' => $path,
			'portrait'  => $path,
			'square'    => $path,
		);
	}

	/**
	 * Build a mask library entry matching Divi's JSON schema.
	 *
	 * @param string               $name  Unique slug (e.g. dsm-mask-organic-blob).
	 * @param string               $label Human-readable label.
	 * @param array<string,string> $svg   Keys: regular, regular_rotated, inverted, inverted_rotated, thumbnail.
	 * @return array<string, mixed>
	 */
	public static function build_mask( string $name, string $label, array $svg ): array {
		$regular          = $svg['regular'] ?? '';
		$regular_rotated  = $svg['regular_rotated'] ?? $regular;
		$inverted         = $svg['inverted'] ?? $regular;
		$inverted_rotated = $svg['inverted_rotated'] ?? $inverted;
		$thumbnail        = $svg['thumbnail'] ?? $regular;

		$entry = array(
			'name'       => $name,
			'label'      => $label,
			'priority'   => 20,
			'svgContent' => array(
				'regular'   => array(
					'default' => self::mask_orientations( $regular ),
					'rotated' => self::mask_orientations( $regular_rotated ),
				),
				'inverted'  => array(
					'default' => self::mask_orientations( $inverted ),
					'rotated' => self::mask_orientations( $inverted_rotated ),
				),
				'thumbnail' => array(
					'default' => self::mask_orientations( $thumbnail ),
				),
			),
		);

		return $entry;
	}

	/**
	 * Build a pattern library entry matching Divi's JSON schema.
	 *
	 * @param string               $name     Unique slug.
	 * @param string               $label    Human-readable label.
	 * @param string               $width    Tile width (e.g. 80px).
	 * @param string               $height   Tile height (e.g. 80px).
	 * @param array<string,string> $svg      Keys: regular, rotated, inverted, inverted_rotated, thumbnail.
	 * @param int                  $priority Priority.
	 * @return array<string, mixed>
	 */
	public static function build_pattern(
		string $name,
		string $label,
		string $width,
		string $height,
		array $svg,
		int $priority = 20
	): array {
		$regular          = $svg['regular'] ?? '';
		$rotated          = $svg['rotated'] ?? $regular;
		$inverted         = $svg['inverted'] ?? $regular;
		$inverted_rotated = $svg['inverted_rotated'] ?? $rotated;
		$thumbnail        = $svg['thumbnail'] ?? $regular;

		return array(
			'name'       => $name,
			'label'      => $label,
			'priority'   => $priority,
			'width'      => $width,
			'height'     => $height,
			'svgContent' => array(
				'regular'   => array(
					'default' => $regular,
					'rotated' => $rotated,
				),
				'inverted'  => array(
					'default' => $inverted,
					'rotated' => $inverted_rotated,
				),
				'thumbnail' => $thumbnail,
			),
		);
	}

	/**
	 * Strip optional outer <svg> wrapper from a self-hosted asset file.
	 *
	 * @param string $markup Raw file contents.
	 * @return string
	 */
	public static function normalize_svg_markup( string $markup ): string {
		$markup = trim( $markup );

		if ( preg_match( '/<svg[^>]*>(.*)<\/svg>/is', $markup, $matches ) ) {
			return trim( (string) $matches[1] );
		}

		return $markup;
	}
}
