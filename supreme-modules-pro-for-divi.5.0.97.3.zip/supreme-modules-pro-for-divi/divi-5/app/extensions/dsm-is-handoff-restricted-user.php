<?php
/**
 * Whether Handoff page and admin limits apply to a user.
 *
 * Loaded with the Handoff access class so existing calls keep working.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Whether Handoff page and admin limits apply to this user.
 *
 * @param int $user_id User ID. 0 is the current user.
 * @return bool
 */
function dsm_is_handoff_restricted_user( int $user_id = 0 ): bool {
	return \DiviSupreme\Extensions\ClientHandoffAccess::is_restricted_user( $user_id );
}
