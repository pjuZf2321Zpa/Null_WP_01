<?php
/**
 * Tooltip extension — Tippy.js on every Divi 5 module.
 *
 * Script data lives on the module wrapper (`data-dsm-tooltip`), not inline <script>.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Extensions;

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Options\Background\BackgroundStyle;
use ET\Builder\Packages\Module\Options\Border\BorderStyle;
use ET\Builder\Packages\Module\Options\BoxShadow\BoxShadowStyle;
use ET\Builder\Packages\Module\Options\Font\FontStyle;
use ET\Builder\Packages\Module\Options\Spacing\SpacingStyle;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Boots the Tooltip extension when Extensions → Tooltip is on.
 */
class Tooltip {

	public const SCRIPT_HANDLE = 'dsm-tooltip-frontend';

	public const STYLE_HANDLE = 'dsm-tooltip-frontend';

	/**
	 * Whether this request rendered at least one enabled tooltip.
	 *
	 * @var bool
	 */
	private bool $needs_assets = false;

	/**
	 * Constructor.
	 */
	public function __construct() {
		if ( ! function_exists( 'dsm_is_tooltip_extension_enabled' ) || ! dsm_is_tooltip_extension_enabled() ) {
			return;
		}

		add_filter( 'divi_module_wrapper_render', array( $this, 'filter_wrapper_render' ), 16, 2 );
		add_filter( 'divi.conversion.postConvertAttrs', array( $this, 'strip_legacy_arrow_color_attr' ), 20, 4 );
		add_action( 'wp_enqueue_scripts', array( $this, 'register_assets' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'maybe_enqueue_vb_tippy' ), 25 );
		add_action( 'wp_footer', array( $this, 'maybe_enqueue_assets' ), 1 );
	}

	/**
	 * Register FE script + Tippy deps (enqueued only when needed).
	 *
	 * @return void
	 */
	public function register_assets(): void {
		$version = defined( 'DSM5_VERSION' ) ? DSM5_VERSION : ( defined( 'DSM_VERSION' ) ? DSM_VERSION : '1.0.0' );

		$this->ensure_tippy_registered( $version );

		$js = DSM_DIR_PATH . 'divi-5/public/tooltip-frontend.js';
		if ( is_readable( $js ) && ! wp_script_is( self::SCRIPT_HANDLE, 'registered' ) ) {
			wp_register_script(
				self::SCRIPT_HANDLE,
				DSM_DIR_URL . 'public/tooltip-frontend.js',
				array( 'dsm-tippy' ),
				$version . '-' . (string) filemtime( $js ),
				true
			);
		}

		$css = DSM_DIR_PATH . 'divi-5/public/style-tooltip-frontend.css';
		if ( is_readable( $css ) && ! wp_style_is( self::STYLE_HANDLE, 'registered' ) ) {
			wp_register_style(
				self::STYLE_HANDLE,
				DSM_DIR_URL . 'public/style-tooltip-frontend.css',
				array(),
				$version . '-' . (string) filemtime( $css )
			);
		}
	}

	/**
	 * Register Popper and Tippy scripts when they are not already registered.
	 *
	 * @param string $version Asset version.
	 * @return void
	 */
	private function ensure_tippy_registered( string $version ): void {
		if ( ! wp_script_is( 'dsm-popper', 'registered' ) ) {
			wp_register_script(
				'dsm-popper',
				DSM_DIR_URL . 'assets/js/popper.js',
				array(),
				$version,
				true
			);
		}

		if ( ! wp_script_is( 'dsm-tippy', 'registered' ) ) {
			wp_register_script(
				'dsm-tippy',
				DSM_DIR_URL . 'assets/js/tippy.js',
				array( 'dsm-popper' ),
				$version,
				true
			);
		}
	}

	/**
	 * Visual Builder always loads Tippy (no DA gating).
	 *
	 * @return void
	 */
	public function maybe_enqueue_vb_tippy(): void {
		if ( ! function_exists( 'et_core_is_fb_enabled' ) || ! et_core_is_fb_enabled() ) {
			return;
		}

		$version = defined( 'DSM5_VERSION' ) ? DSM5_VERSION : ( defined( 'DSM_VERSION' ) ? DSM_VERSION : '1.0.0' );
		$this->ensure_tippy_registered( $version );
		wp_enqueue_script( 'dsm-popper' );
		wp_enqueue_script( 'dsm-tippy' );

		if ( wp_script_is( 'dsm-supreme-extensions', 'registered' ) ) {
			$ext = wp_scripts()->registered['dsm-supreme-extensions'] ?? null;
			if ( $ext && is_array( $ext->deps ) && ! in_array( 'dsm-tippy', $ext->deps, true ) ) {
				$ext->deps[] = 'dsm-tippy';
			}
		}

		if ( wp_style_is( self::STYLE_HANDLE, 'registered' ) ) {
			wp_enqueue_style( self::STYLE_HANDLE );
		}
	}

	/**
	 * Enqueue FE assets when a wrapper payload was rendered (DA-off fallback).
	 *
	 * @return void
	 */
	public function maybe_enqueue_assets(): void {
		if ( ! $this->needs_assets ) {
			return;
		}

		if ( class_exists( \DiviSupreme\Includes\DsmFrontendAssetRegistry::class )
			&& \DiviSupreme\Includes\DsmFrontendAssetRegistry::should_use_divi_dynamic_assets_pipeline() ) {
			return;
		}

		if ( wp_style_is( self::STYLE_HANDLE, 'registered' ) ) {
			wp_enqueue_style( self::STYLE_HANDLE );
		}
		if ( wp_script_is( self::SCRIPT_HANDLE, 'registered' ) ) {
			wp_enqueue_script( self::SCRIPT_HANDLE );
		}
	}

	/**
	 * Drop leftover Arrow Color. Do not map it onto tooltip_box Background.
	 *
	 * @param array<string, mixed> $converted_attrs      Converted block attrs.
	 * @param string               $module_name          Module name.
	 * @param array<string, mixed> $attrs                Original attrs.
	 * @param bool                 $is_preset_conversion Preset flag.
	 * @return array<string, mixed>
	 */
	public function strip_legacy_arrow_color_attr( $converted_attrs, $module_name, $attrs, $is_preset_conversion ) {
		unset( $module_name, $attrs, $is_preset_conversion );

		if ( ! is_array( $converted_attrs ) ) {
			return $converted_attrs;
		}

		unset( $converted_attrs['tooltip_arrow_color'] );

		return $converted_attrs;
	}

	/**
	 * Attach tooltip script data on the module wrapper.
	 *
	 * @param string               $module_wrapper Wrapper HTML.
	 * @param array<string, mixed> $args           Wrapper args.
	 * @return string
	 */
	public function filter_wrapper_render( $module_wrapper, $args ) {
		if ( ! is_string( $module_wrapper ) ) {
			$module_wrapper = '';
		}

		if ( ! is_array( $args ) ) {
			return $module_wrapper;
		}

		$attrs = isset( $args['attrs'] ) && is_array( $args['attrs'] ) ? $args['attrs'] : array();
		unset( $attrs['tooltip_arrow_color'] );
		if ( ! $this->attrs_enabled( $attrs ) ) {
			return $module_wrapper;
		}

		$this->add_box_styles( $attrs, $args );

		$payload = $this->build_payload( $attrs, $args );
		if ( null === $payload ) {
			return $module_wrapper;
		}

		/**
		 * Filter tooltip script-data payload stored on the module wrapper.
		 *
		 * @param array<string, mixed> $payload Payload.
		 * @param array<string, mixed> $attrs   Module attrs.
		 * @param array<string, mixed> $args    Wrapper args.
		 */
		$payload = apply_filters( 'dsm_tooltip_payload', $payload, $attrs, $args );
		if ( ! is_array( $payload ) ) {
			return $module_wrapper;
		}

		$json = wp_json_encode(
			$payload,
			JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT
		);
		if ( ! is_string( $json ) || '' === $json ) {
			return $module_wrapper;
		}

		$this->needs_assets = true;
		$this->register_assets();

		return $this->inject_wrapper_attributes(
			$module_wrapper,
			array(
				'data-dsm-tooltip-on' => '1',
				'data-dsm-tooltip'    => $json,
			)
		);
	}

	/**
	 * Whether Enable Tooltip is on for desktop.
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 * @return bool
	 */
	private function attrs_enabled( array $attrs ): bool {
		return 'on' === $this->inner_string_for_mode( $attrs, 'enable_tooltip', 'desktop', 'off' );
	}

	/**
	 * Build the breakpoint payload stored on the module wrapper.
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 * @param array<string, mixed> $args  Wrapper args.
	 * @return array<string, mixed>|null
	 */
	private function build_payload( array $attrs, array $args ) {
		$desktop = $this->build_mode_slice( $attrs, $args, 'desktop' );
		if ( null === $desktop ) {
			return null;
		}

		$tablet = $this->build_mode_slice( $attrs, $args, 'tablet' );
		$phone  = $this->build_mode_slice( $attrs, $args, 'phone' );

		return array_merge(
			$desktop,
			array(
				'byMode' => array(
					'desktop' => $desktop,
					'tablet'  => null !== $tablet ? $tablet : $desktop,
					'phone'   => null !== $phone ? $phone : ( null !== $tablet ? $tablet : $desktop ),
				),
			)
		);
	}

	/**
	 * Cascaded Tippy config for one breakpoint.
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 * @param array<string, mixed> $args  Wrapper args.
	 * @param string               $mode  desktop|tablet|phone.
	 * @return array<string, mixed>|null
	 */
	private function build_mode_slice( array $attrs, array $args, string $mode ) {
		$content = $this->resolve_dynamic_text(
			$this->inner_string_for_mode(
				$attrs,
				'tooltip_content',
				$mode,
				'Your tooltip text'
			)
		);
		if ( '' === $content ) {
			return null;
		}

		$allow_html = 'on' === $this->inner_string_for_mode( $attrs, 'tooltip_allow_html', $mode, 'off' );
		$content    = $allow_html
			? wp_kses_post( $content )
			: wp_strip_all_tags( $content );

		if ( '' === $content ) {
			return null;
		}

		$placement = $this->inner_string_for_mode( $attrs, 'tooltip_position', $mode, 'top' );
		$fallbacks = $this->fallback_placements( $placement );
		$animation = $this->inner_string_for_mode( $attrs, 'tooltip_animation', $mode, 'fade' );

		return array(
			'on'                 => true,
			'content'            => $content,
			'allowHtml'          => $allow_html,
			'target'             => $this->inner_string_for_mode( $attrs, 'tooltip_target', $mode, 'module' ),
			'selector'           => $this->sanitize_css_selector( $this->inner_string_for_mode( $attrs, 'tooltip_target_selector', $mode, '' ) ),
			'trigger'            => $this->map_trigger( $this->inner_string_for_mode( $attrs, 'tooltip_trigger', $mode, 'hover' ) ),
			'followCursor'       => $this->map_follow( $this->inner_string_for_mode( $attrs, 'tooltip_movement', $mode, 'anchored' ) ),
			'placement'          => $placement,
			'flip'               => true,
			'fallbackPlacements' => $fallbacks,
			'offset'             => array(
				$this->parse_number( $this->inner_string_for_mode( $attrs, 'tooltip_skid', $mode, '0px' ) ),
				$this->parse_number( $this->inner_string_for_mode( $attrs, 'tooltip_distance', $mode, '8px' ) ),
			),
			'delay'              => array(
				$this->parse_number( $this->inner_string_for_mode( $attrs, 'tooltip_open_delay', $mode, '0ms' ) ),
				$this->parse_number( $this->inner_string_for_mode( $attrs, 'tooltip_close_delay', $mode, '0ms' ) ),
			),
			'interactive'        => 'on' === $this->inner_string_for_mode( $attrs, 'tooltip_interactive', $mode, 'off' ),
			'interactiveBorder'  => $this->parse_number( $this->inner_string_for_mode( $attrs, 'tooltip_interactive_border', $mode, '0px' ) ),
			'hideOnClick'        => 'off' !== $this->inner_string_for_mode( $attrs, 'tooltip_hide_on_click', $mode, 'on' ),
			'sticky'             => 'on' === $this->inner_string_for_mode( $attrs, 'tooltip_sticky', $mode, 'off' ),
			'animation'          => 'none' === $animation ? 'fade' : $animation,
			'duration'           => 'none' === $animation ? 0 : $this->parse_number( $this->inner_string_for_mode( $attrs, 'tooltip_duration', $mode, '300ms' ) ),
			'appendTo'           => $this->inner_string_for_mode( $attrs, 'tooltip_append_to', $mode, 'parent' ),
			'maxWidth'           => $this->inner_string_for_mode( $attrs, 'tooltip_max_width', $mode, '350px' ),
			'zIndex'             => $this->parse_number( $this->inner_string_for_mode( $attrs, 'tooltip_z_index', $mode, '9999' ) ),
			'touch'              => $this->map_touch( $this->inner_string_for_mode( $attrs, 'tooltip_touch_behavior', $mode, 'on' ) ),
			'arrow'              => 'off' !== $this->inner_string_for_mode( $attrs, 'tooltip_show_arrow', $mode, 'on' ),
			'arrowSize'          => $this->inner_string_for_mode( $attrs, 'tooltip_arrow_size', $mode, '8px' ),
			'className'          => $this->sanitize_css_selector( $this->inner_string_for_mode( $attrs, 'tooltip_class', $mode, '' ) ),
			'styleClass'         => $this->box_style_class( $args ),
			'backgroundColor'    => $this->box_solid_color( $attrs, $mode ),
		);
	}

	/**
	 * Resolve tooltip_box decoration, or a background tree stored on tooltip_box itself.
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 * @return array<string, mixed>
	 */
	private function box_decoration( array $attrs ): array {
		$box = $attrs['tooltip_box'] ?? null;
		if ( ! is_array( $box ) ) {
			return array();
		}

		$decoration = isset( $box['decoration'] ) && is_array( $box['decoration'] )
			? $box['decoration']
			: array();

		if ( ! isset( $decoration['background'] ) && $this->looks_like_background_tree( $box ) ) {
			$decoration['background'] = $this->pick_breakpoint_tree( $box );
		}

		return $decoration;
	}

	/**
	 * Whether an attr tree looks like a Divi background value tree.
	 *
	 * @param array<string, mixed> $tree Candidate attr tree.
	 * @return bool
	 */
	private function looks_like_background_tree( array $tree ): bool {
		foreach ( array( 'desktop', 'tablet', 'phone' ) as $bp ) {
			$value = $tree[ $bp ]['value'] ?? null;
			if ( ! is_array( $value ) ) {
				continue;
			}

			if ( isset( $value['color'] ) || isset( $value['gradient'] ) || isset( $value['image'] ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Copy desktop, tablet, and phone slices from an attr tree.
	 *
	 * @param array<string, mixed> $tree Attr tree.
	 * @return array<string, mixed>
	 */
	private function pick_breakpoint_tree( array $tree ): array {
		$out = array();
		foreach ( array( 'desktop', 'tablet', 'phone' ) as $bp ) {
			if ( isset( $tree[ $bp ] ) && is_array( $tree[ $bp ] ) ) {
				$out[ $bp ] = $tree[ $bp ];
			}
		}

		return $out;
	}

	/**
	 * Solid tooltip_box background color for Tippy inline paint.
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 * @param string               $mode  desktop|tablet|phone.
	 * @return string
	 */
	private function box_solid_color( array $attrs, string $mode ): string {
		$tree = $this->box_decoration( $attrs )['background'] ?? null;
		if ( ! is_array( $tree ) ) {
			return '';
		}

		$cascade = 'phone' === $mode
			? array( 'phone', 'tablet', 'desktop' )
			: ( 'tablet' === $mode ? array( 'tablet', 'desktop' ) : array( 'desktop' ) );

		foreach ( $cascade as $bp ) {
			$color = $tree[ $bp ]['value']['color'] ?? '';
			if ( is_string( $color ) && '' !== trim( $color ) ) {
				return $this->sanitize_css_color( trim( $color ) );
			}
		}

		return '';
	}

	/**
	 * Sanitize a CSS color string for frontend output.
	 *
	 * @param string $raw Raw color.
	 * @return string
	 */
	private function sanitize_css_color( string $raw ): string {
		$t = preg_replace( '/<[^>]*>/', '', $raw );
		$t = is_string( $t ) ? trim( $t ) : '';

		if ( '' === $t || strlen( $t ) > 350 ) {
			return '';
		}

		if ( preg_match( '/[<>"`\\\\]|;|}/', $t ) ) {
			return '';
		}

		if ( preg_match( '/\b(?:expression|behavior|javascript|@import)\b/i', $t ) ) {
			return '';
		}

		if ( preg_match( '/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/', $t ) ) {
			return $t;
		}

		if ( preg_match( '/^(?:currentcolor|inherit|transparent)$/i', $t ) ) {
			return $t;
		}

		if ( preg_match( '/^(?:var|rgb|rgba|hsl|hsla)\s*\(/i', $t ) ) {
			return $t;
		}

		return '';
	}

	/**
	 * Unique class on the Tippy box so decoration CSS can target a portal.
	 *
	 * @param array<string, mixed> $args Wrapper args.
	 * @return string
	 */
	private function box_style_class( array $args ): string {
		$id   = isset( $args['id'] ) ? (string) $args['id'] : '';
		$safe = preg_replace( '/[^a-zA-Z0-9_-]/', '', $id );
		if ( is_string( $safe ) && '' !== $safe ) {
			return 'dsm-tooltip-box--' . $safe;
		}

		$order      = $this->bare_order_class( $args );
		$safe_order = preg_replace( '/[^a-zA-Z0-9_-]/', '', $order );

		return is_string( $safe_order ) && '' !== $safe_order
			? 'dsm-tooltip-box--' . $safe_order
			: '';
	}

	/**
	 * Last order-class token (CPT prefix stripped).
	 *
	 * @param array<string, mixed> $args Wrapper args.
	 * @return string
	 */
	private function bare_order_class( array $args ): string {
		$elements = $args['elements'] ?? null;
		$order    = '';
		if ( is_object( $elements ) && isset( $elements->order_class ) ) {
			$order = (string) $elements->order_class;
		} elseif ( isset( $args['orderClass'] ) ) {
			$order = (string) $args['orderClass'];
		}

		$order = preg_replace( '/^\.et-db\s+#et-boc\s+\.et-l\s+/i', '', trim( $order ) );
		if ( ! is_string( $order ) || '' === $order ) {
			return '';
		}

		$parts = preg_split( '/\s+/', $order );
		$last  = is_array( $parts ) ? (string) end( $parts ) : '';

		return ltrim( $last, '.' );
	}

	/**
	 * CSS selector for tooltip_box decorations (not a module descendant).
	 *
	 * @param array<string, mixed> $args Wrapper args.
	 * @return string
	 */
	private function box_selector( array $args ): string {
		$style_class = $this->box_style_class( $args );

		return '' !== $style_class ? '.dsm-tooltip-box.' . $style_class : '';
	}

	/**
	 * Print tooltip_box decorations. Native stylesComponent never includes this attr.
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 * @param array<string, mixed> $args  Wrapper args.
	 * @return void
	 */
	private function add_box_styles( array $attrs, array $args ): void {
		if ( ! class_exists( Style::class ) ) {
			return;
		}

		$selector = $this->box_selector( $args );
		if ( '' === $selector ) {
			return;
		}

		$decoration = $this->box_decoration( $attrs );

		$font_selector = $selector . ', ' . $selector . ' .tippy-content';
		$module_name   = isset( $args['name'] ) ? (string) $args['name'] : '';
		$style_id      = (string) ( $args['id'] ?? '' );
		$order_index   = (int) ( $args['orderIndex'] ?? 0 );
		$store_inst    = (int) ( $args['storeInstance'] ?? 0 );
		$styles        = array();

		if ( class_exists( BackgroundStyle::class ) && isset( $decoration['background'] ) && is_array( $decoration['background'] ) ) {
			$styles[] = BackgroundStyle::style(
				array(
					'selector'  => $selector,
					'attr'      => $decoration['background'],
					'important' => true,
				)
			);
		}

		if ( class_exists( FontStyle::class ) && isset( $decoration['font'] ) && is_array( $decoration['font'] ) ) {
			$styles[] = FontStyle::style(
				array(
					'selector'  => $font_selector,
					'attr'      => $decoration['font'],
					'important' => true,
				)
			);
		}

		if ( class_exists( SpacingStyle::class ) && isset( $decoration['spacing'] ) && is_array( $decoration['spacing'] ) ) {
			$styles[] = SpacingStyle::style(
				array(
					'selector' => $selector,
					'attr'     => $decoration['spacing'],
				)
			);
		}

		if ( class_exists( BorderStyle::class ) && isset( $decoration['border'] ) && is_array( $decoration['border'] ) ) {
			$styles[] = BorderStyle::style(
				array(
					'selector' => $selector,
					'attr'     => $decoration['border'],
				)
			);
		}

		if ( class_exists( BoxShadowStyle::class ) && isset( $decoration['boxShadow'] ) && is_array( $decoration['boxShadow'] ) ) {
			$styles[] = BoxShadowStyle::style(
				array(
					'selector' => $selector,
					'attr'     => $decoration['boxShadow'],
				)
			);
		}

		if ( array() === $styles ) {
			return;
		}

		Style::add(
			array(
				'id'            => $style_id,
				'name'          => $module_name,
				'orderIndex'    => $order_index,
				'storeInstance' => $store_inst,
				'styles'        => $styles,
			)
		);
	}

	/**
	 * Read a cascaded innerContent string for one breakpoint.
	 *
	 * @param array<string, mixed> $attrs    Module attrs.
	 * @param string               $key      Attr name.
	 * @param string               $mode     desktop|tablet|phone.
	 * @param string               $fallback Value when the attr is omitted.
	 * @return string
	 */
	private function inner_string_for_mode( array $attrs, string $key, string $mode, string $fallback ): string {
		$tree = $attrs[ $key ]['innerContent'] ?? null;
		if ( ! is_array( $tree ) ) {
			return $fallback;
		}

		$cascade = 'phone' === $mode
			? array( 'phone', 'tablet', 'desktop' )
			: ( 'tablet' === $mode ? array( 'tablet', 'desktop' ) : array( 'desktop' ) );

		foreach ( $cascade as $bp ) {
			$text = $this->leaf_text( $tree[ $bp ]['value'] ?? null );
			if ( '' !== $text ) {
				return $text;
			}
		}

		return $fallback;
	}

	/**
	 * Normalize an innerContent leaf to a trimmed string.
	 *
	 * @param mixed $leaf Inner content value (string or `{ text }` object).
	 * @return string
	 */
	private function leaf_text( $leaf ): string {
		if ( is_string( $leaf ) ) {
			return trim( $leaf );
		}

		if ( is_array( $leaf ) && isset( $leaf['text'] ) && is_string( $leaf['text'] ) ) {
			return trim( $leaf['text'] );
		}

		return '';
	}

	/**
	 * Resolve Divi `$variable(…)$` tokens for frontend tooltip copy.
	 *
	 * @param string $raw Raw attr value.
	 * @return string
	 */
	private function resolve_dynamic_text( string $raw ): string {
		$text = $raw;

		if ( class_exists( \ET\Builder\Packages\StyleLibrary\Utils\Utils::class ) ) {
			$resolved = \ET\Builder\Packages\StyleLibrary\Utils\Utils::resolve_dynamic_variable( $text );
			if ( is_string( $resolved ) ) {
				$text = $resolved;
			}
		}

		/**
		 * Filters resolved tooltip content before sanitization.
		 *
		 * @param string $text Resolved text.
		 * @param string $raw  Original stored value.
		 */
		return (string) apply_filters( 'dsm_tooltip_resolve_dynamic_text', $text, $raw );
	}

	/**
	 * Map the trigger setting to a Tippy trigger string.
	 *
	 * @param string $trigger Setting value.
	 * @return string
	 */
	private function map_trigger( string $trigger ): string {
		switch ( $trigger ) {
			case 'click':
				return 'click';
			case 'focus':
				return 'focus';
			case 'hover focus':
				return 'mouseenter focus';
			case 'manual':
				return 'manual';
			default:
				return 'mouseenter';
		}
	}

	/**
	 * Map the movement setting to a Tippy followCursor value.
	 *
	 * @param string $movement Setting value.
	 * @return bool|string
	 */
	private function map_follow( string $movement ) {
		switch ( $movement ) {
			case 'follow':
				return true;
			case 'horizontal':
				return 'horizontal';
			case 'vertical':
				return 'vertical';
			case 'initial':
				return 'initial';
			default:
				return false;
		}
	}

	/**
	 * Map the touch setting to a Tippy touch option.
	 *
	 * @param string $touch Setting value.
	 * @return bool|string
	 */
	private function map_touch( string $touch ) {
		if ( 'off' === $touch || 'disabled' === $touch ) {
			return false;
		}
		if ( 'hold' === $touch ) {
			return 'hold';
		}
		return true;
	}

	/**
	 * Conservative CSS selector / class allow-list (same charset as Page Tour).
	 *
	 * Used for `tooltip_target_selector` (`querySelector`) and `tooltip_class`
	 * (`classList.add` tokens). Rejects the whole value when the charset fails.
	 *
	 * @param string $raw Raw selector or class list.
	 * @return string
	 */
	private function sanitize_css_selector( string $raw ): string {
		$raw = trim( $raw );
		if ( '' === $raw || strlen( $raw ) > 300 ) {
			return '';
		}

		if ( 1 !== preg_match( '/^[A-Za-z0-9_\-#\.\[\]="\'\s>+~:(),]+$/', $raw ) ) {
			return '';
		}

		return $raw;
	}

	/**
	 * Parse a numeric value from a range string.
	 *
	 * @param string $raw Range string.
	 * @return float
	 */
	private function parse_number( string $raw ): float {
		return (float) preg_replace( '/[^\d.\-]/', '', $raw );
	}

	/**
	 * Flip placements used when the preferred placement does not fit.
	 *
	 * @param string $placement Tippy placement.
	 * @return list<string>
	 */
	private function fallback_placements( string $placement ): array {
		$map = array(
			'top-start'    => array( 'top', 'top-end', 'bottom-start', 'right-start', 'left-start' ),
			'top'          => array( 'bottom', 'top-start', 'top-end', 'right', 'left' ),
			'top-end'      => array( 'top', 'top-start', 'bottom-end', 'left-start', 'right-start' ),
			'bottom-start' => array( 'bottom', 'bottom-end', 'top-start', 'right-end', 'left-end' ),
			'bottom'       => array( 'top', 'bottom-start', 'bottom-end', 'right', 'left' ),
			'bottom-end'   => array( 'bottom', 'bottom-start', 'top-end', 'left-end', 'right-end' ),
			'left-start'   => array( 'left', 'left-end', 'right-start', 'top-start', 'bottom-start' ),
			'left'         => array( 'right', 'left-start', 'left-end', 'top', 'bottom' ),
			'left-end'     => array( 'left', 'left-start', 'right-end', 'bottom-start', 'top-start' ),
			'right-start'  => array( 'right', 'right-end', 'left-start', 'top-end', 'bottom-end' ),
			'right'        => array( 'left', 'right-start', 'right-end', 'top', 'bottom' ),
			'right-end'    => array( 'right', 'right-start', 'left-end', 'bottom-end', 'top-end' ),
			'auto'         => array( 'top', 'bottom', 'right', 'left' ),
		);

		return $map[ $placement ] ?? $map['top'];
	}

	/**
	 * Inject attributes onto the first opening tag of wrapper HTML.
	 *
	 * @param string                $html       Wrapper HTML.
	 * @param array<string, string> $attributes Attribute map.
	 * @return string
	 */
	private function inject_wrapper_attributes( string $html, array $attributes ): string {
		if ( '' === $html || array() === $attributes ) {
			return $html;
		}

		$attr_html = '';
		foreach ( $attributes as $name => $value ) {
			$attr_html .= ' ' . esc_attr( $name ) . '="' . esc_attr( $value ) . '"';
		}

		// Callback — never interpolate `$attr_html` as a preg replacement.
		// A replacement string would treat `$99` / `$10` in tooltip JSON as
		// backreferences and strip the dollar (VB is JS-only, so it still works).
		$updated = preg_replace_callback(
			'/^(<[a-zA-Z][a-zA-Z0-9]*)(\s|>)/',
			static function ( array $matches ) use ( $attr_html ): string {
				return $matches[1] . $attr_html . $matches[2];
			},
			$html,
			1
		);

		return is_string( $updated ) ? $updated : $html;
	}
}

$GLOBALS['dsm_tooltip_extension'] = new Tooltip();
