<?php // phpcs:ignore WordPress.Files.FileName.NotHyphenatedLowercase, WordPress.Files.FileName.InvalidClassFileName -- PascalCase matches other Divi 5 extension classes such as ClientHandoff.php.
/**
 * Client Guide — agency welcome panel and a hierarchical Help library.
 *
 * Welcome fields live in the `dsm_client_guide` option. Docs are the `dsm_client_help`
 * post type. This does not write Divi Role Editor and does not change Handoff.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Extensions;

use DiviSupreme\Core\Assets;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Welcome content, Help CPT, dashboard widget, and Visual Builder config.
 */
class ClientGuide {

	/**
	 * Dashboard section id.
	 */
	public const SECTION_ID = 'dsm_client_guide';

	/**
	 * Welcome option.
	 */
	public const OPTION = 'dsm_client_guide';

	/**
	 * Help post type.
	 */
	public const POST_TYPE = 'dsm_client_help';

	/**
	 * Post type used before the library moved under Divi Supreme Pro.
	 */
	private const LEGACY_POST_TYPE = 'dsm_help';

	/**
	 * Set after existing docs have been moved to POST_TYPE.
	 */
	private const MIGRATED_OPTION = 'dsm_client_help_post_type_migrated';

	/**
	 * AJAX action.
	 */
	public const AJAX_ACTION = 'dsm_client_guide';

	/**
	 * AJAX nonce action.
	 */
	public const NONCE = 'dsm_client_guide';

	/**
	 * Read-only Help screen slug.
	 */
	public const HELP_PAGE = 'dsm-client-guide-help';

	/**
	 * REST namespace.
	 */
	private const REST_NAMESPACE = 'dsm/v1';

	/**
	 * Maximum quick actions stored on the welcome option.
	 */
	private const MAX_QUICK_ACTIONS = 12;

	/**
	 * Default quick-action icon id from the Font Awesome list.
	 */
	private const DEFAULT_ACTION_ICON = 's/tag';

	/**
	 * Register hooks.
	 */
	public function __construct() {
		add_action( 'init', array( $this, 'migrate_legacy_post_type' ), 0 );
		add_action( 'init', array( $this, 'register_post_type' ) );
		add_action( 'admin_menu', array( $this, 'register_help_screen' ) );
		add_action( 'admin_menu', array( $this, 'register_admin_menu' ), 100 );
		add_filter( 'parent_file', array( $this, 'filter_parent_file' ) );
		add_filter( 'submenu_file', array( $this, 'filter_submenu_file' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin' ) );
		add_action( 'wp_dashboard_setup', array( $this, 'register_dashboard_widget' ) );
		add_action( 'wp_ajax_' . self::AJAX_ACTION, array( $this, 'handle_ajax' ) );
		add_action( 'rest_api_init', array( $this, 'register_rest_routes' ) );
		add_action(
			'divi_visual_builder_assets_before_enqueue_scripts',
			array( $this, 'enqueue_vb_config' ),
			20
		);
	}

	/**
	 * Hierarchical Help documents. Only administrators can edit them.
	 *
	 * @return void
	 */
	public function register_post_type(): void {
		$labels = array(
			'name'          => __( 'Client Help Library', 'dsm-supreme-modules-pro-for-divi' ),
			'singular_name' => __( 'Help doc', 'dsm-supreme-modules-pro-for-divi' ),
			'add_new'       => __( 'Add Help doc', 'dsm-supreme-modules-pro-for-divi' ),
			'add_new_item'  => __( 'Add Help doc', 'dsm-supreme-modules-pro-for-divi' ),
			'edit_item'     => __( 'Edit Help doc', 'dsm-supreme-modules-pro-for-divi' ),
			'all_items'     => __( 'Client Help Library', 'dsm-supreme-modules-pro-for-divi' ),
			'menu_name'     => __( 'Client Help Library', 'dsm-supreme-modules-pro-for-divi' ),
		);

		register_post_type(
			self::POST_TYPE,
			array(
				'labels'              => $labels,
				'public'              => false,
				'publicly_queryable'  => false,
				'exclude_from_search' => true,
				'show_ui'             => true,
				'show_in_menu'        => false,
				'show_in_rest'        => true,
				'rest_base'           => 'dsm-client-help',
				'hierarchical'        => true,
				'rewrite'             => false,
				'query_var'           => false,
				'map_meta_cap'        => false,
				'capabilities'        => array(
					'edit_post'              => 'manage_options',
					'read_post'              => 'manage_options',
					'delete_post'            => 'manage_options',
					'edit_posts'             => 'manage_options',
					'edit_others_posts'      => 'manage_options',
					'delete_posts'           => 'manage_options',
					'publish_posts'          => 'manage_options',
					'read_private_posts'     => 'manage_options',
					'delete_private_posts'   => 'manage_options',
					'delete_published_posts' => 'manage_options',
					'delete_others_posts'    => 'manage_options',
					'edit_private_posts'     => 'manage_options',
					'edit_published_posts'   => 'manage_options',
					'create_posts'           => 'manage_options',
				),
				'supports'            => array( 'title', 'editor', 'page-attributes', 'revisions' ),
			)
		);
	}

	/**
	 * Move docs saved under the previous post type.
	 *
	 * @return void
	 */
	public function migrate_legacy_post_type(): void {
		if ( get_option( self::MIGRATED_OPTION ) ) {
			return;
		}

		global $wpdb;

		$ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT ID FROM {$wpdb->posts} WHERE post_type = %s",
				self::LEGACY_POST_TYPE
			)
		);

		if ( is_array( $ids ) && array() !== $ids ) {
			$wpdb->query(
				$wpdb->prepare(
					"UPDATE {$wpdb->posts} SET post_type = %s WHERE post_type = %s",
					self::POST_TYPE,
					self::LEGACY_POST_TYPE
				)
			);

			foreach ( $ids as $id ) {
				clean_post_cache( (int) $id );
			}
		}

		update_option( self::MIGRATED_OPTION, 1 );
	}

	/**
	 * List and add screens under Divi Supreme Pro.
	 *
	 * `show_in_menu` stays false so this post type does not replace the Settings submenu.
	 *
	 * @return void
	 */
	public function register_admin_menu(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		if ( ! self::client_handoff_extension_enabled() ) {
			return;
		}

		add_submenu_page(
			'divi_supreme_settings',
			__( 'Client Help Library', 'dsm-supreme-modules-pro-for-divi' ),
			__( 'Client Help Library', 'dsm-supreme-modules-pro-for-divi' ),
			'manage_options',
			'edit.php?post_type=' . self::POST_TYPE
		);
	}

	/**
	 * Keep Divi Supreme Pro expanded while editing a Help doc.
	 *
	 * @param string $parent_file Parent menu slug.
	 * @return string
	 */
	public function filter_parent_file( string $parent_file ): string {
		if ( $this->is_help_library_screen() ) {
			return 'divi_supreme_settings';
		}

		return $parent_file;
	}

	/**
	 * Highlight Client Help Library on the list and edit screens.
	 *
	 * @param string|null $submenu_file Current submenu slug.
	 * @return string|null
	 */
	public function filter_submenu_file( $submenu_file ) {
		if ( ! $this->is_help_library_screen() ) {
			return $submenu_file;
		}

		return 'edit.php?post_type=' . self::POST_TYPE;
	}

	/**
	 * Whether the current admin screen is the Client Help Library.
	 *
	 * @return bool
	 */
	private function is_help_library_screen(): bool {
		if ( ! function_exists( 'get_current_screen' ) ) {
			return false;
		}

		$screen = get_current_screen();

		return $screen && self::POST_TYPE === $screen->post_type;
	}

	/**
	 * Read-only Help screen for users who can edit posts but are not administrators.
	 *
	 * @return void
	 */
	public function register_help_screen(): void {
		if ( current_user_can( 'manage_options' ) || ! current_user_can( 'edit_posts' ) ) {
			return;
		}

		add_menu_page(
			__( 'Help', 'dsm-supreme-modules-pro-for-divi' ),
			__( 'Help', 'dsm-supreme-modules-pro-for-divi' ),
			'edit_posts',
			self::HELP_PAGE,
			array( $this, 'render_help_screen' ),
			'dashicons-book-alt',
			58
		);
	}

	/**
	 * Media library on the settings screen, and print CSS on the Help screen.
	 *
	 * @param string $hook Current admin page hook.
	 * @return void
	 */
	public function enqueue_admin( string $hook ): void {
		if (
			'index.php' === $hook
			&& self::client_handoff_extension_enabled()
			&& self::current_user_can_view_welcome()
		) {
			wp_register_style( 'dsm-welcome-widget', false, array(), '1' );
			wp_enqueue_style( 'dsm-welcome-widget' );
			wp_add_inline_style( 'dsm-welcome-widget', self::welcome_widget_css() );
		}

		if ( 'toplevel_page_divi_supreme_settings' === $hook && current_user_can( 'manage_options' ) ) {
			wp_enqueue_media();
		}

		if ( 'toplevel_page_' . self::HELP_PAGE !== $hook ) {
			return;
		}

		$version = defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : false;

		$help_css = defined( 'DSM_DIR_PATH' ) ? DSM_DIR_PATH . 'divi-5/assets/static/css/client-guide-help.css' : '';
		$help_ver = is_readable( $help_css ) ? (string) filemtime( $help_css ) : $version;

		wp_enqueue_style( 'dashicons' );
		wp_enqueue_style(
			'dsm-client-guide-help',
			Assets::getAssetPath( 'css/client-guide-help.css' ),
			array( 'wp-admin' ),
			$help_ver
		);
		wp_enqueue_script(
			'dsm-client-guide-help',
			Assets::getAssetPath( 'js/client-guide-help.js' ),
			array(),
			$version,
			true
		);
	}

	/**
	 * Dashboard widget for administrators and the current Handoff target role.
	 *
	 * Hidden while Divi Supreme → Extensions → Client Handoff is off.
	 * Other dashboard widgets are left in place.
	 *
	 * @return void
	 */
	public function register_dashboard_widget(): void {
		if ( ! self::client_handoff_extension_enabled() || ! self::current_user_can_view_welcome() ) {
			return;
		}

		$welcome = self::get_welcome();
		$title   = '' !== $welcome['agency_name']
			? $welcome['agency_name']
			: __( 'Welcome', 'dsm-supreme-modules-pro-for-divi' );

		wp_add_dashboard_widget(
			'dsm_client_guide_welcome',
			$title,
			array( $this, 'render_dashboard_widget' )
		);
	}

	/**
	 * Print the welcome widget.
	 *
	 * @return void
	 */
	public function render_dashboard_widget(): void {
		if ( ! self::client_handoff_extension_enabled() || ! self::current_user_can_view_welcome() ) {
			return;
		}

		$welcome = self::get_welcome();

		echo '<div class="dsm-welcome">';
		$this->render_welcome_html( $welcome );
		$this->render_welcome_actions( $welcome );
		echo '</div>';
	}

	/**
	 * Read-only Help tree, search, and print view.
	 *
	 * @return void
	 */
	public function render_help_screen(): void {
		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_die( esc_html__( 'You do not have permission to read Help.', 'dsm-supreme-modules-pro-for-divi' ) );
		}

		$search = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( (string) $_GET['s'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only search.
		$doc_id = isset( $_GET['doc'] ) ? absint( $_GET['doc'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only document id.

		$posts         = self::query_help_posts( $search );
		$tree          = '' === $search ? $posts : self::query_help_posts( '' );
		$welcome       = self::get_welcome();
		$agency        = (string) $welcome['agency_name'];
		$support_name  = (string) $welcome['support_name'];
		$support_email = (string) $welcome['support_email'];
		$support_url   = (string) $welcome['support_url'];
		$page_url      = add_query_arg(
			array(
				'page' => self::HELP_PAGE,
			),
			admin_url( 'admin.php' )
		);

		$current = null;

		if ( '' === $search ) {
			foreach ( $tree as $post ) {
				if ( $doc_id === (int) $post->ID ) {
					$current = $post;
					break;
				}
			}
		}

		$is_landing = '' === $search && ! $current instanceof \WP_Post;

		echo '<div class="wrap dsm-client-guide-help' . ( $is_landing ? ' dsm-client-guide-help--landing' : '' ) . '">';
		echo '<header class="dsm-client-guide-help__header">';
		echo '<div class="dsm-client-guide-help__heading">';
		echo '<h1 class="wp-heading-inline">' . esc_html__( 'Help', 'dsm-supreme-modules-pro-for-divi' ) . '</h1>';

		if ( '' !== $agency ) {
			echo '<p class="dsm-client-guide-help__subtitle">' . esc_html(
				sprintf(
					/* translators: %s: agency name. */
					__( 'Guides from %s for editing your site.', 'dsm-supreme-modules-pro-for-divi' ),
					$agency
				)
			) . '</p>';
		} else {
			echo '<p class="dsm-client-guide-help__subtitle">' . esc_html__( 'Guides for editing your site.', 'dsm-supreme-modules-pro-for-divi' ) . '</p>';
		}

		echo '</div>';

		if ( ! $is_landing ) {
			echo '<form class="dsm-client-guide-help__search" method="get" action="' . esc_url( admin_url( 'admin.php' ) ) . '">';
			echo '<input type="hidden" name="page" value="' . esc_attr( self::HELP_PAGE ) . '" />';
			echo '<label for="dsm-client-guide-help-search" class="screen-reader-text">' . esc_html__( 'Search Help', 'dsm-supreme-modules-pro-for-divi' ) . '</label>';
			echo '<span class="dashicons dashicons-search" aria-hidden="true"></span>';
			echo '<input type="search" id="dsm-client-guide-help-search" name="s" value="' . esc_attr( $search ) . '" placeholder="' . esc_attr__( 'Search help docs', 'dsm-supreme-modules-pro-for-divi' ) . '" />';
			echo '<button type="submit" class="screen-reader-text">' . esc_html__( 'Search docs', 'dsm-supreme-modules-pro-for-divi' ) . '</button>';
			echo '</form>';
		}

		echo '</header>';

		$nav_current = $current instanceof \WP_Post ? (int) $current->ID : 0;

		echo '<div class="dsm-client-guide-help__layout' . ( $is_landing ? ' dsm-client-guide-help__layout--landing' : '' ) . '">';

		if ( ! $is_landing ) {
			echo '<aside class="dsm-client-guide-help__sidebar">';
			echo '<nav class="dsm-client-guide-help__nav" aria-label="' . esc_attr__( 'Help docs', 'dsm-supreme-modules-pro-for-divi' ) . '">';
			$this->render_help_tree( $tree, 0, $nav_current, '' );
			echo '</nav>';

			if ( '' !== $support_name || '' !== $support_email || '' !== $support_url ) {
				echo '<div class="dsm-client-guide-help__support">';
				echo '<span class="dsm-client-guide-help__support-title">' . esc_html__( 'Still stuck?', 'dsm-supreme-modules-pro-for-divi' ) . '</span>';

				if ( '' !== $support_name && '' !== $agency ) {
					echo '<p class="dsm-client-guide-help__support-line">' . esc_html(
						sprintf(
						/* translators: 1: support name, 2: agency name. */
							__( '%1$s at %2$s can help.', 'dsm-supreme-modules-pro-for-divi' ),
							$support_name,
							$agency
						)
					) . '</p>';
				} elseif ( '' !== $support_name ) {
					echo '<p class="dsm-client-guide-help__support-line">' . esc_html(
						sprintf(
						/* translators: %s: support name. */
							__( '%s can help.', 'dsm-supreme-modules-pro-for-divi' ),
							$support_name
						)
					) . '</p>';
				} elseif ( '' !== $agency ) {
					echo '<p class="dsm-client-guide-help__support-line">' . esc_html(
						sprintf(
						/* translators: %s: agency name. */
							__( '%s can help.', 'dsm-supreme-modules-pro-for-divi' ),
							$agency
						)
					) . '</p>';
				}

				if ( '' !== $support_email || '' !== $support_url ) {
					echo '<div class="dsm-client-guide-help__support-links">';

					if ( '' !== $support_email ) {
						echo '<a href="' . esc_url( 'mailto:' . $support_email ) . '">' . esc_html( $support_email ) . '</a>';
					}

					if ( '' !== $support_url ) {
						echo '<a href="' . esc_url( $support_url ) . '" target="_blank" rel="noopener noreferrer">' . esc_html__( 'Support portal', 'dsm-supreme-modules-pro-for-divi' ) . '</a>';
					}

					echo '</div>';
				}

				echo '</div>';
			}

			echo '</aside>';
		}

		echo '<div class="dsm-client-guide-help__main">';

		if ( '' !== $search ) {
			echo '<div class="dsm-client-guide-help__results">';
			echo '<div class="dsm-client-guide-help__results-head">';
			echo '<span>' . esc_html(
				sprintf(
					/* translators: 1: result count, 2: search term. */
					_n( '%1$d result for “%2$s”', '%1$d results for “%2$s”', count( $posts ), 'dsm-supreme-modules-pro-for-divi' ),
					count( $posts ),
					$search
				)
			) . '</span>';
			echo '<a href="' . esc_url( $page_url ) . '">' . esc_html__( 'Clear search', 'dsm-supreme-modules-pro-for-divi' ) . '</a>';
			echo '</div>';

			if ( array() === $posts ) {
				if ( '' !== $support_email && '' !== $support_name ) {
					$empty_hint = sprintf(
						/* translators: 1: support name, 2: support email. */
						__( 'Try a shorter word, or ask %1$s at %2$s.', 'dsm-supreme-modules-pro-for-divi' ),
						$support_name,
						$support_email
					);
				} elseif ( '' !== $support_email ) {
					$empty_hint = sprintf(
						/* translators: %s: support email. */
						__( 'Try a shorter word, or ask %s.', 'dsm-supreme-modules-pro-for-divi' ),
						$support_email
					);
				} else {
					$empty_hint = __( 'Try a shorter word.', 'dsm-supreme-modules-pro-for-divi' );
				}

				echo '<div class="dsm-client-guide-help__empty">';
				echo '<span class="dsm-client-guide-help__empty-title">' . esc_html(
					sprintf(
						/* translators: %s: search term. */
						__( 'Nothing matched “%s”', 'dsm-supreme-modules-pro-for-divi' ),
						$search
					)
				) . '</span>';
				echo '<span class="dsm-client-guide-help__empty-hint">' . esc_html( $empty_hint ) . '</span>';
				echo '</div>';
			} else {
				foreach ( $posts as $post ) {
					$url          = add_query_arg(
						array(
							'page' => self::HELP_PAGE,
							'doc'  => $post->ID,
						),
						admin_url( 'admin.php' )
					);
					$title        = esc_html( get_the_title( $post ) );
					$title        = (string) preg_replace(
						'/' . preg_quote( esc_html( $search ), '/' ) . '/iu',
						'<mark>$0</mark>',
						$title
					);
					$ancestor_ids = array_reverse( get_post_ancestors( $post ) );
					$path_parts   = array();

					foreach ( $ancestor_ids as $ancestor_id ) {
						$path_parts[] = get_the_title( $ancestor_id );
					}

					$path_parts[] = get_the_title( $post );
					$excerpt      = has_excerpt( $post ) ? get_the_excerpt( $post ) : wp_trim_words( wp_strip_all_tags( $post->post_content ), 20 );

					echo '<a class="dsm-client-guide-help__result" href="' . esc_url( $url ) . '">';
					echo '<span class="dsm-client-guide-help__result-title">' . wp_kses( $title, array( 'mark' => array() ) ) . '</span>';
					echo '<span class="dsm-client-guide-help__result-excerpt">' . esc_html( wp_strip_all_tags( $excerpt ) ) . '</span>';
					echo '<span class="dsm-client-guide-help__result-path">' . esc_html( implode( ' / ', $path_parts ) ) . '</span>';
					echo '</a>';
				}
			}

			echo '</div>';
		} elseif ( ! $current instanceof \WP_Post ) {
			$this->render_help_landing( $tree, $welcome );
		} else {
			$minutes = max( 1, (int) round( str_word_count( wp_strip_all_tags( $current->post_content ) ) / 200 ) );

			echo '<article class="dsm-client-guide-help__doc">';
			echo '<div class="dsm-client-guide-help__doc-head">';

			$ancestor_ids = array_reverse( get_post_ancestors( $current ) );

			if ( array() !== $ancestor_ids ) {
				echo '<p class="dsm-client-guide-help__crumbs">';
				$crumb_index = 0;

				foreach ( $ancestor_ids as $ancestor_id ) {
					$ancestor_url = add_query_arg(
						array(
							'page' => self::HELP_PAGE,
							'doc'  => $ancestor_id,
						),
						admin_url( 'admin.php' )
					);

					if ( 0 !== $crumb_index ) {
						echo ' / ';
					}

					echo '<a href="' . esc_url( $ancestor_url ) . '">' . esc_html( get_the_title( $ancestor_id ) ) . '</a>';
					++$crumb_index;
				}

				echo '</p>';
			}

			echo '<div class="dsm-client-guide-help__title-row">';
			echo '<h2>' . esc_html( get_the_title( $current ) ) . '</h2>';
			echo '<button type="button" class="button dsm-client-guide-help__print" onclick="window.print()"><span class="dashicons dashicons-printer" aria-hidden="true"></span> ' . esc_html__( 'Print', 'dsm-supreme-modules-pro-for-divi' ) . '</button>';
			echo '</div>';
			echo '<p class="dsm-client-guide-help__meta">' . esc_html(
				sprintf(
					/* translators: 1: last updated date, 2: reading time in minutes. */
					__( 'Updated %1$s · %2$d min read', 'dsm-supreme-modules-pro-for-divi' ),
					(string) get_the_modified_date( '', $current ),
					$minutes
				)
			) . '</p>';
			echo '</div>';
			echo '<div class="dsm-client-guide-help__content">' . wp_kses_post( self::render_post_content( $current ) ) . '</div>';

			$ordered   = array();
			$by_parent = array();

			foreach ( $tree as $tree_post ) {
				$by_parent[ (int) $tree_post->post_parent ][] = $tree_post;
			}

			$stack = isset( $by_parent[0] ) ? array_reverse( $by_parent[0] ) : array();

			while ( array() !== $stack ) {
				$node      = array_pop( $stack );
				$ordered[] = $node;
				$node_id   = (int) $node->ID;

				if ( isset( $by_parent[ $node_id ] ) ) {
					foreach ( array_reverse( $by_parent[ $node_id ] ) as $child ) {
						$stack[] = $child;
					}
				}
			}

			$position = null;

			foreach ( $ordered as $index => $tree_post ) {
				if ( (int) $tree_post->ID === (int) $current->ID ) {
					$position = $index;
					break;
				}
			}

			$previous = null !== $position && isset( $ordered[ $position - 1 ] ) ? $ordered[ $position - 1 ] : null;
			$next     = null !== $position && isset( $ordered[ $position + 1 ] ) ? $ordered[ $position + 1 ] : null;

			if ( $previous instanceof \WP_Post || $next instanceof \WP_Post ) {
				echo '<footer class="dsm-client-guide-help__pager">';

				if ( $previous instanceof \WP_Post ) {
					$previous_url = add_query_arg(
						array(
							'page' => self::HELP_PAGE,
							'doc'  => $previous->ID,
						),
						admin_url( 'admin.php' )
					);
					echo '<a href="' . esc_url( $previous_url ) . '">';
					echo '<span class="dsm-client-guide-help__pager-label">' . esc_html__( '← Previous', 'dsm-supreme-modules-pro-for-divi' ) . '</span>';
					echo '<span class="dsm-client-guide-help__pager-title">' . esc_html( get_the_title( $previous ) ) . '</span>';
					echo '</a>';
				}

				if ( $next instanceof \WP_Post ) {
					$next_url = add_query_arg(
						array(
							'page' => self::HELP_PAGE,
							'doc'  => $next->ID,
						),
						admin_url( 'admin.php' )
					);
					echo '<a class="dsm-client-guide-help__pager-next" href="' . esc_url( $next_url ) . '">';
					echo '<span class="dsm-client-guide-help__pager-label">' . esc_html__( 'Next →', 'dsm-supreme-modules-pro-for-divi' ) . '</span>';
					echo '<span class="dsm-client-guide-help__pager-title">' . esc_html( get_the_title( $next ) ) . '</span>';
					echo '</a>';
				}

				echo '</footer>';
			}

			echo '</article>';
		}

		echo '</div></div></div>';
	}

	/**
	 * Save welcome fields.
	 *
	 * @return void
	 */
	public function handle_ajax(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error(
				array(
					'message' => __( 'You do not have permission to edit Client Guide.', 'dsm-supreme-modules-pro-for-divi' ),
				)
			);
		}

		check_ajax_referer( self::NONCE, 'nonce' );

		$op = isset( $_POST['op'] ) ? sanitize_key( wp_unslash( (string) $_POST['op'] ) ) : '';

		if ( 'save' === $op ) {
			$welcome = self::sanitize_welcome_request();
			update_option( self::OPTION, $welcome, false );

			wp_send_json_success(
				array(
					'message' => __( 'Client Guide saved.', 'dsm-supreme-modules-pro-for-divi' ),
					'welcome' => self::get_welcome(),
					'logoUrl' => self::logo_url( self::get_welcome() ),
				)
			);
		}

		wp_send_json_error(
			array(
				'message' => __( 'Unknown Client Guide action.', 'dsm-supreme-modules-pro-for-divi' ),
			)
		);
	}

	/**
	 * Help list and rendered content for the Visual Builder.
	 *
	 * @return void
	 */
	public function register_rest_routes(): void {
		register_rest_route(
			self::REST_NAMESPACE,
			'/client-guide/help',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'rest_help' ),
				'permission_callback' => static function (): bool {
					return current_user_can( 'edit_posts' );
				},
				'args'                => array(
					'search' => array(
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
				),
			)
		);
	}

	/**
	 * REST callback. Content is rendered and kses'd on the server.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response
	 */
	public function rest_help( \WP_REST_Request $request ): \WP_REST_Response {
		$search = sanitize_text_field( (string) $request->get_param( 'search' ) );
		$docs   = array();

		foreach ( self::query_help_posts( $search ) as $post ) {
			$docs[] = array(
				'id'      => (int) $post->ID,
				'title'   => get_the_title( $post ),
				'parent'  => (int) $post->post_parent,
				'order'   => (int) $post->menu_order,
				'content' => self::render_post_content( $post ),
			);
		}

		return rest_ensure_response(
			array(
				'docs' => $docs,
			)
		);
	}

	/**
	 * Pass welcome content into the Visual Builder for administrators and the Handoff role.
	 *
	 * Skipped while Divi Supreme → Extensions → Client Handoff is off, so the builder
	 * bar never receives `visible: true`.
	 *
	 * @return void
	 */
	public function enqueue_vb_config(): void {
		if ( ! self::client_handoff_extension_enabled() ) {
			return;
		}

		if ( ! self::current_user_can_view_welcome() ) {
			return;
		}

		if ( ! function_exists( 'et_core_is_fb_enabled' ) || ! et_core_is_fb_enabled() ) {
			return;
		}

		if ( ! wp_script_is( 'dsm-supreme-vb-config', 'registered' ) ) {
			return;
		}

		$payload = array(
			'visible'   => true,
			'restUrl'   => rest_url( self::REST_NAMESPACE . '/client-guide/help' ),
			'restNonce' => wp_create_nonce( 'wp_rest' ),
			'helpUrl'   => current_user_can( 'manage_options' )
				? admin_url( 'edit.php?post_type=' . self::POST_TYPE )
				: admin_url( 'admin.php?page=' . self::HELP_PAGE ),
			'welcome'   => self::welcome_for_client(),
		);

		wp_add_inline_script(
			'dsm-supreme-vb-config',
			'window.dsmClientGuide=' . wp_json_encode( $payload ) . ';',
			'after'
		);
	}

	/**
	 * Settings dashboard payload.
	 *
	 * @return array<string, mixed>
	 */
	public static function get_localize_payload(): array {
		$welcome = self::get_welcome();

		return array(
			'nonce'        => wp_create_nonce( self::NONCE ),
			'action'       => self::AJAX_ACTION,
			'welcome'      => $welcome,
			'logoUrl'      => self::logo_url( $welcome ),
			'helpAdminUrl' => admin_url( 'edit.php?post_type=' . self::POST_TYPE ),
			'icons'        => array(
				'agency'       => Assets::getAssetPath( 'dashboard/rows/domain.svg' ),
				'welcome'      => Assets::getAssetPath( 'dashboard/rows/text.svg' ),
				'logo'         => Assets::getAssetPath( 'dashboard/rows/image.svg' ),
				'launch'       => Assets::getAssetPath( 'dashboard/rows/event.svg' ),
				'supportName'  => Assets::getAssetPath( 'dashboard/rows/person.svg' ),
				'supportEmail' => Assets::getAssetPath( 'dashboard/rows/mail.svg' ),
				'supportUrl'   => Assets::getAssetPath( 'dashboard/rows/link.svg' ),
				'action'       => Assets::getAssetPath( 'dashboard/rows/label.svg' ),
				'docs'         => Assets::getAssetPath( 'dashboard/rows/subject.svg' ),
			),
			'actionIcons'  => self::quick_action_icon_choices(),
			'strings'      => array(
				'save'                      => __( 'Save welcome', 'dsm-supreme-modules-pro-for-divi' ),
				'saving'                    => __( 'Saving...', 'dsm-supreme-modules-pro-for-divi' ),
				'agencyTitle'               => __( 'Agency', 'dsm-supreme-modules-pro-for-divi' ),
				'agencyDesc'                => __( 'Shown in the welcome panel. Administrators edit this; the Handoff role can read it.', 'dsm-supreme-modules-pro-for-divi' ),
				'agencyName'                => __( 'Agency name', 'dsm-supreme-modules-pro-for-divi' ),
				'welcomeMessage'            => __( 'Welcome message', 'dsm-supreme-modules-pro-for-divi' ),
				'welcomeMessagePlaceholder' => __( 'Welcome to your site', 'dsm-supreme-modules-pro-for-divi' ),
				'logo'                      => __( 'Logo', 'dsm-supreme-modules-pro-for-divi' ),
				'logoChoose'                => __( 'Choose logo', 'dsm-supreme-modules-pro-for-divi' ),
				'logoReplace'               => __( 'Replace', 'dsm-supreme-modules-pro-for-divi' ),
				'logoRemove'                => __( 'Remove', 'dsm-supreme-modules-pro-for-divi' ),
				'logoNone'                  => __( 'No logo', 'dsm-supreme-modules-pro-for-divi' ),
				'logoPreview'               => __( 'Preview logo', 'dsm-supreme-modules-pro-for-divi' ),
				'close'                     => __( 'Close', 'dsm-supreme-modules-pro-for-divi' ),
				'launchDate'                => __( 'Launch date', 'dsm-supreme-modules-pro-for-divi' ),
				'launchShow'                => __( 'Show', 'dsm-supreme-modules-pro-for-divi' ),
				'launchHidden'              => __( 'Hidden from the welcome panel', 'dsm-supreme-modules-pro-for-divi' ),
				'supportTitle'              => __( 'Support contact', 'dsm-supreme-modules-pro-for-divi' ),
				'supportDesc'               => __( 'Who clients reach when they need help. All three are optional.', 'dsm-supreme-modules-pro-for-divi' ),
				'supportName'               => __( 'Support name', 'dsm-supreme-modules-pro-for-divi' ),
				'supportEmail'              => __( 'Support email', 'dsm-supreme-modules-pro-for-divi' ),
				'supportUrl'                => __( 'Support URL', 'dsm-supreme-modules-pro-for-divi' ),
				'quickActions'              => __( 'Quick actions', 'dsm-supreme-modules-pro-for-divi' ),
				'quickActionsDesc'          => __( 'Up to 12 links shown as buttons in the welcome panel.', 'dsm-supreme-modules-pro-for-divi' ),
				'actionLabel'               => __( 'Title', 'dsm-supreme-modules-pro-for-divi' ),
				'actionUrl'                 => __( 'URL', 'dsm-supreme-modules-pro-for-divi' ),
				'actionLabelPlaceholder'    => __( 'Title', 'dsm-supreme-modules-pro-for-divi' ),
				'actionUrlPlaceholder'      => __( 'https://example.com', 'dsm-supreme-modules-pro-for-divi' ),
				'actionIcon'                => __( 'Icon', 'dsm-supreme-modules-pro-for-divi' ),
				'actionIconSearch'          => __( 'Search icons', 'dsm-supreme-modules-pro-for-divi' ),
				'actionIconSearchHint'      => __( 'Search icons, e.g. phone, ticket, map', 'dsm-supreme-modules-pro-for-divi' ),
				'actionIconCount'           =>
					// translators: %d: number of icons in the current list.
					__( '%d icons', 'dsm-supreme-modules-pro-for-divi' ),
				'actionIconSuggested'       => __( 'Suggested for this link', 'dsm-supreme-modules-pro-for-divi' ),
				'actionIconAll'             => __( 'All icons', 'dsm-supreme-modules-pro-for-divi' ),
				'actionIconEmpty'           =>
					// translators: %s: the icon search query.
					__( 'No icons match “%s”', 'dsm-supreme-modules-pro-for-divi' ),
				'actionIconEmptyHint'       => __( 'Try a broader word like “help”, “mail” or “shop”.', 'dsm-supreme-modules-pro-for-divi' ),
				'actionIconSelected'        =>
					// translators: %s: the selected icon name.
					__( 'Selected · %s', 'dsm-supreme-modules-pro-for-divi' ),
				'addAction'                 => __( 'Add action', 'dsm-supreme-modules-pro-for-divi' ),
				'removeAction'              => __( 'Remove', 'dsm-supreme-modules-pro-for-divi' ),
				'untitledAction'            => __( 'Untitled action', 'dsm-supreme-modules-pro-for-divi' ),
				'noUrl'                     => __( 'No URL', 'dsm-supreme-modules-pro-for-divi' ),
				'editAction'                => __( 'Edit', 'dsm-supreme-modules-pro-for-divi' ),
				'done'                      => __( 'Done', 'dsm-supreme-modules-pro-for-divi' ),
				'actionsUsed'               =>
					// translators: %d: number of quick actions already added, out of 12.
					__( '%d of 12 used.', 'dsm-supreme-modules-pro-for-divi' ),
				'agencyHelpShort'           => __( 'Shown in the welcome panel. The Handoff role can read it.', 'dsm-supreme-modules-pro-for-divi' ),
				'supportHelpShort'          => __( 'Who clients reach for help. All optional.', 'dsm-supreme-modules-pro-for-divi' ),
				'actionsHelpShort'          => __( 'Links shown as buttons in the welcome panel.', 'dsm-supreme-modules-pro-for-divi' ),
				'helpLibraryShort'          => __( 'Pages written in the block editor. The Handoff role can read, search and print them.', 'dsm-supreme-modules-pro-for-divi' ),
				'helpTitle'                 => __( 'Client Help Library', 'dsm-supreme-modules-pro-for-divi' ),
				'helpLibraryTitle'          => __( 'Client Help Library', 'dsm-supreme-modules-pro-for-divi' ),
				'helpBody'                  => __( 'Help docs are pages in the Client Help Library. Write them in the block editor. The Handoff role can read, search, and print them.', 'dsm-supreme-modules-pro-for-divi' ),
				'helpDocs'                  => __( 'Help docs', 'dsm-supreme-modules-pro-for-divi' ),
				'openHelp'                  => __( 'Edit Help docs', 'dsm-supreme-modules-pro-for-divi' ),
			),
		);
	}

	/**
	 * True when Divi Supreme → Extensions → Client Handoff is on.
	 *
	 * The welcome dashboard widget follows the same switch as the Client Help Library menu.
	 *
	 * @return bool
	 */
	private static function client_handoff_extension_enabled(): bool {
		return function_exists( 'dsm_is_client_handoff_extension_enabled' ) && dsm_is_client_handoff_extension_enabled();
	}

	/**
	 * Whether the current user should see the welcome panel.
	 *
	 * Administrators always can. The stored Handoff target role can. This does not lock `manage_options`.
	 *
	 * @return bool
	 */
	public static function current_user_can_view_welcome(): bool {
		if ( current_user_can( 'manage_options' ) ) {
			return true;
		}

		$role = self::handoff_target_role();

		if ( '' === $role ) {
			return false;
		}

		$user = wp_get_current_user();

		return in_array( $role, (array) $user->roles, true );
	}

	/**
	 * Stored Handoff target role, read only. Empty when Handoff has not chosen one.
	 *
	 * @return string
	 */
	private static function handoff_target_role(): string {
		$state = get_option( 'dsm_handoff_state', array() );

		if ( ! is_array( $state ) || empty( $state['target_role'] ) ) {
			return '';
		}

		$role = sanitize_key( (string) $state['target_role'] );

		if ( '' === $role || 'administrator' === $role ) {
			return '';
		}

		return $role;
	}

	/**
	 * Sanitized welcome fields for display, passed through `dsm_client_guide_welcome`.
	 *
	 * Agency name: string,
	 * welcome_message: string,
	 * logo_id: int,
	 * launch_date: string,
	 * show_launch_date: bool,
	 * support_name: string,
	 * support_email: string,
	 * support_url: string,
	 * quick_actions: list<array{label: string, url: string, icon: string}>
	 * }
	 *
	 * @return array{
	 */
	public static function get_welcome(): array {
		$stored  = get_option( self::OPTION, array() );
		$welcome = self::sanitize_welcome( is_array( $stored ) ? $stored : array() );

		/**
		 * Filters the Client Guide welcome content before it is shown.
		 *
		 * @param array $welcome Sanitized welcome fields.
		 */
		$filtered = apply_filters( 'dsm_client_guide_welcome', $welcome );

		if ( ! is_array( $filtered ) ) {
			return $welcome;
		}

		return self::sanitize_welcome( $filtered );
	}

	/**
	 * Welcome fields safe to send to the Visual Builder.
	 *
	 * @return array<string, mixed>
	 */
	private static function welcome_for_client(): array {
		$welcome = self::get_welcome();

		return array(
			'agencyName'     => $welcome['agency_name'],
			'welcomeMessage' => $welcome['welcome_message'],
			'logoUrl'        => self::logo_url( $welcome ),
			'launchDate'     => ! empty( $welcome['show_launch_date'] ) ? self::format_launch_date( $welcome['launch_date'] ) : '',
			'supportName'    => $welcome['support_name'],
			'supportEmail'   => $welcome['support_email'],
			'supportUrl'     => $welcome['support_url'],
			'quickActions'   => self::quick_actions_for_client( $welcome['quick_actions'] ),
		);
	}

	/**
	 * Logo URL for an image attachment, or an empty string.
	 *
	 * @param array<string, mixed> $welcome Welcome fields.
	 * @return string
	 */
	private static function logo_url( array $welcome ): string {
		$logo_id = isset( $welcome['logo_id'] ) ? absint( $welcome['logo_id'] ) : 0;

		if ( $logo_id < 1 || ! wp_attachment_is_image( $logo_id ) ) {
			return '';
		}

		$url = wp_get_attachment_image_url( $logo_id, 'medium' );

		return is_string( $url ) ? esc_url_raw( $url ) : '';
	}

	/**
	 * Read and sanitize the posted welcome JSON.
	 *
	 * @return array<string, mixed>
	 */
	private static function sanitize_welcome_request(): array {
		$raw     = isset( $_POST['welcome'] ) ? wp_unslash( $_POST['welcome'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, ET.Sniffs.ValidatedSanitizedInput.InputNotSanitized -- Nonce checked in handle_ajax(). JSON is decoded, then sanitize_welcome() sanitizes each field.
		$decoded = json_decode( is_string( $raw ) ? $raw : '', true );

		return self::sanitize_welcome( is_array( $decoded ) ? $decoded : array() );
	}

	/**
	 * Normalize welcome fields from storage, a filter, or a request.
	 *
	 * Agency name: string,
	 * welcome_message: string,
	 * logo_id: int,
	 * launch_date: string,
	 * show_launch_date: bool,
	 * support_name: string,
	 * support_email: string,
	 * support_url: string,
	 * quick_actions: list<array{label: string, url: string, icon: string}>
	 * }
	 *
	 * @param array<string, mixed> $raw Raw fields. Accepts camelCase or snake_case keys.
	 * @return array{
	 */
	private static function sanitize_welcome( array $raw ): array {
		$agency  = $raw['agency_name'] ?? ( $raw['agencyName'] ?? '' );
		$message = $raw['welcome_message'] ?? ( $raw['welcomeMessage'] ?? '' );
		$logo    = $raw['logo_id'] ?? ( $raw['logoId'] ?? 0 );
		$date    = $raw['launch_date'] ?? ( $raw['launchDate'] ?? '' );
		$name    = $raw['support_name'] ?? ( $raw['supportName'] ?? '' );
		$email   = $raw['support_email'] ?? ( $raw['supportEmail'] ?? '' );
		$url     = $raw['support_url'] ?? ( $raw['supportUrl'] ?? '' );
		$actions = $raw['quick_actions'] ?? ( $raw['quickActions'] ?? array() );

		$launch = sanitize_text_field( (string) $date );

		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $launch ) ) {
			$launch = '';
		}

		if ( array_key_exists( 'show_launch_date', $raw ) || array_key_exists( 'showLaunchDate', $raw ) ) {
			$show_launch = rest_sanitize_boolean( $raw['show_launch_date'] ?? $raw['showLaunchDate'] );
		} else {
			$show_launch = '' !== $launch;
		}

		$logo_id = absint( $logo );

		if ( $logo_id > 0 && ! wp_attachment_is_image( $logo_id ) ) {
			$logo_id = 0;
		}

		return array(
			'agency_name'      => sanitize_text_field( (string) $agency ),
			'welcome_message'  => sanitize_text_field( (string) $message ),
			'logo_id'          => $logo_id,
			'launch_date'      => $launch,
			'show_launch_date' => $show_launch,
			'support_name'     => sanitize_text_field( (string) $name ),
			'support_email'    => sanitize_email( (string) $email ),
			'support_url'      => esc_url_raw( (string) $url ),
			'quick_actions'    => self::sanitize_quick_actions( is_array( $actions ) ? $actions : array() ),
		);
	}

	/**
	 * Label, URL, and icon rows.
	 *
	 * @param array<int, mixed> $rows Posted rows.
	 * @return list<array{label: string, url: string, icon: string}>
	 */
	private static function sanitize_quick_actions( array $rows ): array {
		$clean = array();

		foreach ( $rows as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}

			$label = sanitize_text_field( (string) ( $row['label'] ?? '' ) );
			$url   = esc_url_raw( (string) ( $row['url'] ?? '' ) );
			$icon  = self::sanitize_quick_action_icon( (string) ( $row['icon'] ?? '' ) );

			if ( '' === $label || '' === $url ) {
				continue;
			}

			$clean[] = array(
				'label' => $label,
				'url'   => $url,
				'icon'  => $icon,
			);

			if ( count( $clean ) >= self::MAX_QUICK_ACTIONS ) {
				break;
			}
		}

		return $clean;
	}

	/**
	 * Earlier curated slugs, mapped onto Font Awesome ids.
	 *
	 * @return array<string, string>
	 */
	private static function legacy_action_icon_map(): array {
		return array(
			'label'      => 's/tag',
			'link'       => 's/link',
			'mail'       => 's/envelope',
			'event'      => 's/calendar',
			'calendar'   => 's/calendar',
			'person'     => 's/user',
			'chat'       => 's/comment',
			'message'    => 's/comment-alt',
			'place'      => 's/map-marker-alt',
			'smartphone' => 's/phone',
			'bolt'       => 's/bolt',
			'star'       => 's/star',
			'image'      => 's/image',
			'pages'      => 's/file-alt',
			'subject'    => 's/file',
			'https'      => 's/lock',
			'attachment' => 's/paperclip',
			'schedule'   => 's/clock',
		);
	}

	/**
	 * Font Awesome icons shipped with Divi, keyed by id.
	 *
	 * @return array<string, array{id: string, hex: string, label: string, style: string}>
	 */
	private static function fontawesome_icons(): array {
		static $icons = null;

		if ( null !== $icons ) {
			return $icons;
		}

		$icons = array();

		if ( ! defined( 'DSM_DIR_PATH' ) ) {
			return $icons;
		}

		$path = DSM_DIR_PATH . 'divi-5/assets/fontawesome-icons.json';

		if ( ! is_readable( $path ) ) {
			return $icons;
		}

		$raw = file_get_contents( $path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Local plugin JSON, not a remote request.

		if ( ! is_string( $raw ) || '' === $raw ) {
			return $icons;
		}

		$decoded = json_decode( $raw, true );

		if ( ! is_array( $decoded ) ) {
			return $icons;
		}

		foreach ( $decoded as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}

			$id    = isset( $row['id'] ) ? (string) $row['id'] : '';
			$hex   = isset( $row['hex'] ) ? strtolower( (string) $row['hex'] ) : '';
			$label = isset( $row['label'] ) ? (string) $row['label'] : '';
			$style = isset( $row['style'] ) ? (string) $row['style'] : '';

			if ( ! preg_match( '/^[srb]\/[a-z0-9-]+$/', $id ) || ! preg_match( '/^[0-9a-f]{3,5}$/', $hex ) ) {
				continue;
			}

			if ( ! in_array( $style, array( 's', 'r', 'b' ), true ) ) {
				continue;
			}

			$icons[ $id ] = array(
				'id'    => $id,
				'hex'   => $hex,
				'label' => $label,
				'style' => $style,
			);
		}

		return $icons;
	}

	/**
	 * Icon id from the Font Awesome list, or the default tag icon.
	 *
	 * @param string $icon Posted icon id.
	 * @return string
	 */
	private static function sanitize_quick_action_icon( string $icon ): string {
		$icon   = strtolower( trim( $icon ) );
		$legacy = self::legacy_action_icon_map();

		if ( isset( $legacy[ $icon ] ) ) {
			$icon = $legacy[ $icon ];
		}

		$icon  = sanitize_text_field( $icon );
		$icons = self::fontawesome_icons();

		if ( isset( $icons[ $icon ] ) ) {
			return $icon;
		}

		return self::DEFAULT_ACTION_ICON;
	}

	/**
	 * Icon choices for the settings picker.
	 *
	 * @return list<array{id: string, hex: string, label: string, style: string}>
	 */
	private static function quick_action_icon_choices(): array {
		return array_values( self::fontawesome_icons() );
	}

	/**
	 * Quick actions with a Font Awesome glyph for the Visual Builder.
	 *
	 * @param list<array{label: string, url: string, icon: string}> $actions Stored actions.
	 * @return list<array{label: string, url: string, icon: string, iconHex: string, iconStyle: string}>
	 */
	private static function quick_actions_for_client( array $actions ): array {
		$client = array();
		$icons  = self::fontawesome_icons();

		foreach ( $actions as $action ) {
			$icon = isset( $action['icon'] ) ? (string) $action['icon'] : self::DEFAULT_ACTION_ICON;
			$id   = self::sanitize_quick_action_icon( $icon );
			$row  = $icons[ $id ] ?? array(
				'hex'   => 'f02b',
				'style' => 's',
			);

			$client[] = array(
				'label'     => $action['label'],
				'url'       => $action['url'],
				'icon'      => $id,
				'iconHex'   => $row['hex'],
				'iconStyle' => $row['style'],
			);
		}

		return $client;
	}

	/**
	 * Localized launch date, or an empty string.
	 *
	 * @param string $date Y-m-d date.
	 * @return string
	 */
	private static function format_launch_date( string $date ): string {
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) ) {
			return '';
		}

		$timestamp = strtotime( $date . ' 00:00:00 UTC' );

		if ( false === $timestamp ) {
			return '';
		}

		return date_i18n( get_option( 'date_format' ), $timestamp );
	}

	/**
	 * Echo escaped welcome markup shared by the dashboard widget.
	 *
	 * @param array<string, mixed> $welcome Welcome fields.
	 * @return void
	 */
	private function render_welcome_html( array $welcome ): void {
		$logo = self::logo_url( $welcome );

		if ( '' !== $logo ) {
			echo '<p class="dsm-welcome__logo"><img src="' . esc_url( $logo ) . '" alt="' . esc_attr( (string) $welcome['agency_name'] ) . '" /></p>';
		}

		$launch      = ! empty( $welcome['show_launch_date'] ) ? self::format_launch_date( (string) $welcome['launch_date'] ) : '';
		$has_support = '' !== $welcome['support_name'] || '' !== $welcome['support_email'] || '' !== $welcome['support_url'];

		if ( '' !== $launch || $has_support ) {
			echo '<dl class="dsm-welcome__meta">';

			if ( '' !== $launch ) {
				echo '<div class="dsm-welcome__row">';
				echo '<dt>' . esc_html__( 'Launch date', 'dsm-supreme-modules-pro-for-divi' ) . '</dt>';
				echo '<dd>' . esc_html( $launch ) . '</dd>';
				echo '</div>';
			}

			if ( $has_support ) {
				echo '<div class="dsm-welcome__row">';
				echo '<dt>' . esc_html__( 'Support', 'dsm-supreme-modules-pro-for-divi' ) . '</dt>';
				echo '<dd><span class="dsm-welcome__support">';

				if ( '' !== $welcome['support_name'] ) {
					echo '<span>' . esc_html( (string) $welcome['support_name'] ) . '</span>';
				}

				if ( '' !== $welcome['support_email'] ) {
					echo '<a href="' . esc_url( 'mailto:' . (string) $welcome['support_email'] ) . '">' . esc_html( (string) $welcome['support_email'] ) . '</a>';
				}

				if ( '' !== $welcome['support_url'] ) {
					echo '<a href="' . esc_url( (string) $welcome['support_url'] ) . '" target="_blank" rel="noopener noreferrer">' . esc_html( (string) $welcome['support_url'] ) . '</a>';
				}

				echo '</span></dd></div>';
			}

			echo '</dl>';
		}
	}

	/**
	 * Inline quick actions, matching the Events and News widget footer.
	 *
	 * @param array<string, mixed> $welcome Welcome fields.
	 * @return void
	 */
	private function render_welcome_actions( array $welcome ): void {
		$actions = isset( $welcome['quick_actions'] ) && is_array( $welcome['quick_actions'] ) ? $welcome['quick_actions'] : array();
		$printed = false;
		$help    = '';

		if ( current_user_can( 'edit_posts' ) ) {
			$help = current_user_can( 'manage_options' )
				? admin_url( 'edit.php?post_type=' . self::POST_TYPE )
				: admin_url( 'admin.php?page=' . self::HELP_PAGE );
		}

		$has_action = false;

		foreach ( $actions as $action ) {
			if ( is_array( $action ) && '' !== (string) $action['label'] && '' !== (string) $action['url'] ) {
				$has_action = true;
				break;
			}
		}

		if ( ! $has_action && '' === $help ) {
			return;
		}

		echo '<p class="dsm-welcome__actions">';

		foreach ( $actions as $action ) {
			if ( ! is_array( $action ) || '' === (string) $action['label'] || '' === (string) $action['url'] ) {
				continue;
			}

			if ( $printed ) {
				echo ' <span class="dsm-welcome__sep" aria-hidden="true">|</span> ';
			}

			echo '<a href="' . esc_url( (string) $action['url'] ) . '" target="_blank" rel="noopener noreferrer">' . esc_html( (string) $action['label'] ) . ' <span class="dashicons dashicons-external" aria-hidden="true"></span></a>';
			$printed = true;
		}

		if ( '' !== $help ) {
			if ( $printed ) {
				echo ' <span class="dsm-welcome__sep" aria-hidden="true">|</span> ';
			}

			echo '<a href="' . esc_url( $help ) . '">' . esc_html__( 'Open Help', 'dsm-supreme-modules-pro-for-divi' ) . '</a>';
		}

		echo '</p>';
	}

	/**
	 * Dashboard widget styles. Link color follows the active WordPress admin scheme.
	 *
	 * @return string
	 */
	private static function welcome_widget_css(): string {
		return '#dsm_client_guide_welcome .dsm-welcome__logo{margin:0 0 12px;}'
			. '#dsm_client_guide_welcome .dsm-welcome__logo img{display:block;max-width:180px;height:auto;}'
			. '#dsm_client_guide_welcome .dsm-welcome__meta{margin:0;}'
			. '#dsm_client_guide_welcome .dsm-welcome__row{display:grid;grid-template-columns:96px minmax(0,1fr);gap:12px;align-items:start;padding:8px 0;}'
			. '#dsm_client_guide_welcome .dsm-welcome__meta dt{margin:0;color:#646970;font-size:13px;font-weight:600;line-height:1.4;}'
			. '#dsm_client_guide_welcome .dsm-welcome__meta dd{margin:0;min-width:0;color:#1d2327;font-size:13px;line-height:1.5;overflow-wrap:anywhere;}'
			. '#dsm_client_guide_welcome .dsm-welcome__support{display:flex;flex-direction:column;align-items:flex-start;gap:2px;}'
			. '#dsm_client_guide_welcome .dsm-welcome__actions{margin:12px -12px -12px;padding:12px;border-top:1px solid #dcdcde;}'
			. '#dsm_client_guide_welcome .dsm-welcome a,#dsm_client_guide_welcome .dsm-welcome a:hover,#dsm_client_guide_welcome .dsm-welcome a:focus{text-decoration:none;}'
			. '#dsm_client_guide_welcome .dsm-welcome__sep{color:#646970;}'
			. '#dsm_client_guide_welcome .dsm-welcome__actions .dashicons{width:16px;height:16px;font-size:16px;vertical-align:text-bottom;}';
	}

	/**
	 * Published Help docs, optionally filtered by title and content search.
	 *
	 * @param string $search Search string.
	 * @return list<\WP_Post>
	 */
	private static function query_help_posts( string $search ): array {
		$args = array(
			'post_type'      => self::POST_TYPE,
			'post_status'    => 'publish',
			'posts_per_page' => 200, // phpcs:ignore WordPress.WP.PostsPerPage.posts_per_page_posts_per_page -- Help tree is capped; the library is not a public archive.
			'orderby'        => array(
				'menu_order' => 'ASC',
				'title'      => 'ASC',
			),
			'no_found_rows'  => true,
		);

		if ( '' !== $search ) {
			$args['s'] = $search;
		}

		/**
		 * Filters the query arguments for Client Guide Help docs.
		 *
		 * @param array<string, mixed> $args    WP_Query arguments.
		 * @param string               $search  Search string.
		 */
		$filtered = apply_filters( 'dsm_client_guide_help_args', $args, $search );

		if ( ! is_array( $filtered ) ) {
			$filtered = $args;
		}

		$filtered['post_type']   = self::POST_TYPE;
		$filtered['post_status'] = 'publish';

		$posts = get_posts( $filtered );

		if ( ! is_array( $posts ) ) {
			return array();
		}

		$clean = array();

		foreach ( $posts as $post ) {
			if ( $post instanceof \WP_Post && self::POST_TYPE === $post->post_type ) {
				$clean[] = $post;
			}
		}

		usort(
			$clean,
			static function ( \WP_Post $left, \WP_Post $right ): int {
				$order = (int) $left->menu_order <=> (int) $right->menu_order;

				if ( 0 !== $order ) {
					return $order;
				}

				return strcasecmp( $left->post_title, $right->post_title );
			}
		);

		return $clean;
	}

	/**
	 * Render block content and strip anything wp_kses_post does not allow.
	 *
	 * @param \WP_Post $post Help doc.
	 * @return string
	 */
	private static function render_post_content( \WP_Post $post ): string {
		$html = apply_filters( 'the_content', $post->post_content );

		if ( ! is_string( $html ) ) {
			return '';
		}

		return wp_kses_post( $html );
	}

	/**
	 * Help landing: welcome panel, topics, and recently updated docs.
	 *
	 * @param \WP_Post[]           $posts   Published Help docs in menu order.
	 * @param array<string, mixed> $welcome Welcome fields.
	 * @return void
	 */
	private function render_help_landing( array $posts, array $welcome ): void {
		$agency        = (string) $welcome['agency_name'];
		$support_name  = (string) $welcome['support_name'];
		$support_email = (string) $welcome['support_email'];
		$support_url   = (string) $welcome['support_url'];
		$logo_id       = isset( $welcome['logo_id'] ) ? absint( $welcome['logo_id'] ) : 0;
		$tops          = array();
		$children      = array();

		foreach ( $posts as $post ) {
			if ( 0 === (int) $post->post_parent ) {
				$tops[] = $post;
			} else {
				$children[] = $post;
			}
		}

		$start   = $tops[0] ?? null;
		$popular = array_slice( $children, 0, 3 );

		if ( count( $popular ) < 3 ) {
			foreach ( $tops as $top ) {
				if ( $start instanceof \WP_Post && (int) $top->ID === (int) $start->ID ) {
					continue;
				}

				$popular[] = $top;

				if ( count( $popular ) >= 3 ) {
					break;
				}
			}
		}

		$has_docs    = array() !== $posts;
		$has_support = '' !== $support_name || '' !== $support_email || '' !== $support_url;
		$logo_html   = ( $logo_id > 0 && wp_attachment_is_image( $logo_id ) ) ? wp_get_attachment_image(
			$logo_id,
			'full',
			false,
			array(
				'class' => 'dsm-help-welcome__logo',
				'alt'   => $agency,
			)
		) : '';
		$agency_mark = '' !== $agency ? mb_strtoupper( mb_substr( $agency, 0, 1 ) ) : '';

		echo '<section class="dsm-help-welcome">';
		echo '<div class="dsm-help-welcome__main">';
		echo '<div class="dsm-help-welcome__intro">';

		if ( is_string( $logo_html ) && '' !== $logo_html ) {
			echo '<span class="dsm-help-welcome__mark dsm-help-welcome__mark--logo">' . wp_kses_post( $logo_html ) . '</span>';
		} elseif ( '' !== $agency_mark ) {
			echo '<span class="dsm-help-welcome__mark" aria-hidden="true">' . esc_html( $agency_mark ) . '</span>';
		}

		echo '<div class="dsm-help-welcome__copy">';
		echo '<h2>' . esc_html__( 'Welcome to your site guide', 'dsm-supreme-modules-pro-for-divi' ) . '</h2>';

		if ( $start instanceof \WP_Post ) {
			$start_url  = add_query_arg(
				array(
					'page' => self::HELP_PAGE,
					'doc'  => $start->ID,
				),
				admin_url( 'admin.php' )
			);
			$start_link = '<a href="' . esc_url( $start_url ) . '">' . esc_html( get_the_title( $start ) ) . '</a>';

			echo '<span class="dsm-help-welcome__start">' . wp_kses(
				sprintf(
					/* translators: %s: linked title of the first guide. */
					__( 'New here? Start with %s.', 'dsm-supreme-modules-pro-for-divi' ),
					$start_link
				),
				array(
					'a' => array(
						'href' => array(),
					),
				)
			) . '</span>';
		}

		echo '</div></div>';

		if ( $has_docs ) {
			echo '<form class="dsm-help-welcome__search" method="get" action="' . esc_url( admin_url( 'admin.php' ) ) . '">';
			echo '<input type="hidden" name="page" value="' . esc_attr( self::HELP_PAGE ) . '" />';
			echo '<label for="dsm-client-guide-help-search" class="screen-reader-text">' . esc_html__( 'Search Help', 'dsm-supreme-modules-pro-for-divi' ) . '</label>';
			echo '<span class="dashicons dashicons-search" aria-hidden="true"></span>';
			echo '<input type="search" id="dsm-client-guide-help-search" name="s" value="" placeholder="' . esc_attr__( 'Search help, e.g. change a headline', 'dsm-supreme-modules-pro-for-divi' ) . '" />';
			echo '<button type="submit" class="screen-reader-text">' . esc_html__( 'Search docs', 'dsm-supreme-modules-pro-for-divi' ) . '</button>';
			echo '</form>';

			if ( array() !== $popular ) {
				echo '<div class="dsm-help-welcome__popular">';
				echo '<span>' . esc_html__( 'Popular:', 'dsm-supreme-modules-pro-for-divi' ) . '</span>';

				foreach ( $popular as $post ) {
					$url = add_query_arg(
						array(
							'page' => self::HELP_PAGE,
							'doc'  => $post->ID,
						),
						admin_url( 'admin.php' )
					);
					echo '<a href="' . esc_url( $url ) . '">' . esc_html( get_the_title( $post ) ) . '</a>';
				}

				echo '</div>';
			}
		}

		echo '</div>';

		if ( $has_support ) {
			$initials = '';
			$parts    = preg_split( '/\s+/', trim( $support_name ) );

			if ( is_array( $parts ) ) {
				foreach ( $parts as $part ) {
					if ( '' === $part ) {
						continue;
					}

					$initials .= mb_strtoupper( mb_substr( $part, 0, 1 ) );

					if ( mb_strlen( $initials ) >= 2 ) {
						break;
					}
				}
			}

			echo '<aside class="dsm-help-welcome__contact">';
			echo '<span class="dsm-help-welcome__contact-title">' . esc_html__( 'Your contact', 'dsm-supreme-modules-pro-for-divi' ) . '</span>';

			if ( '' !== $support_name || '' !== $agency ) {
				echo '<div class="dsm-help-welcome__person">';

				if ( '' !== $initials ) {
					echo '<span class="dsm-help-welcome__avatar" aria-hidden="true">' . esc_html( $initials ) . '</span>';
				}

				echo '<span class="dsm-help-welcome__person-copy">';

				if ( '' !== $support_name ) {
					echo '<span class="dsm-help-welcome__person-name">' . esc_html( $support_name ) . '</span>';
				}

				if ( '' !== $agency ) {
					echo '<span class="dsm-help-welcome__person-agency">' . esc_html( $agency ) . '</span>';
				}

				echo '</span></div>';
			}

			if ( '' !== $support_email || '' !== $support_url ) {
				echo '<div class="dsm-help-welcome__links">';

				if ( '' !== $support_email ) {
					echo '<a href="' . esc_url( 'mailto:' . $support_email ) . '">' . esc_html( $support_email ) . '</a>';
				}

				if ( '' !== $support_url ) {
					echo '<a href="' . esc_url( $support_url ) . '" target="_blank" rel="noopener noreferrer">' . esc_html__( 'Support portal', 'dsm-supreme-modules-pro-for-divi' ) . '</a>';
				}

				echo '</div>';
			}

			echo '</aside>';
		}

		echo '</section>';

		if ( ! $has_docs ) {
			echo '<p class="dsm-help-welcome__empty">';

			if ( '' !== $agency ) {
				echo esc_html(
					sprintf(
						/* translators: %s: agency name. */
						__( 'No guides yet. %s will add them here.', 'dsm-supreme-modules-pro-for-divi' ),
						$agency
					)
				);
			} else {
				echo esc_html__( 'No guides yet.', 'dsm-supreme-modules-pro-for-divi' );
			}

			if ( current_user_can( 'edit_others_posts' ) ) {
				echo ' <a href="' . esc_url( admin_url( 'post-new.php?post_type=' . self::POST_TYPE ) ) . '">' . esc_html__( 'Write the first guide', 'dsm-supreme-modules-pro-for-divi' ) . '</a>';
			}

			echo '</p>';
			return;
		}

		if ( array() !== $tops ) {
			echo '<section class="dsm-help-topics">';
			echo '<h2>' . esc_html__( 'Topics', 'dsm-supreme-modules-pro-for-divi' ) . '</h2>';
			echo '<div class="dsm-help-topics__grid">';

			foreach ( $tops as $topic ) {
				$topic_url = add_query_arg(
					array(
						'page' => self::HELP_PAGE,
						'doc'  => $topic->ID,
					),
					admin_url( 'admin.php' )
				);
				$kids      = array();

				foreach ( $children as $child ) {
					if ( (int) $child->post_parent === (int) $topic->ID ) {
						$kids[] = $child;
					}
				}

				$excerpt = has_excerpt( $topic ) ? get_the_excerpt( $topic ) : wp_trim_words( wp_strip_all_tags( $topic->post_content ), 18 );

				echo '<div class="dsm-help-topic">';
				echo '<a class="dsm-help-topic__head" href="' . esc_url( $topic_url ) . '">';
				echo '<span class="dsm-help-topic__title">' . esc_html( get_the_title( $topic ) ) . '</span>';
				echo '<span class="dsm-help-topic__excerpt">' . esc_html( wp_strip_all_tags( $excerpt ) ) . '</span>';
				echo '</a>';
				echo '<div class="dsm-help-topic__list">';
				echo '<a class="dsm-help-topic__row" href="' . esc_url( $topic_url ) . '"><span>' . esc_html( array() !== $kids ? __( 'Start here', 'dsm-supreme-modules-pro-for-divi' ) : __( 'Read guide', 'dsm-supreme-modules-pro-for-divi' ) ) . '</span><span class="dsm-help-topic__chevron" aria-hidden="true">›</span></a>';

				$shown = array_slice( $kids, 0, 6 );

				foreach ( $shown as $child ) {
					$child_url = add_query_arg(
						array(
							'page' => self::HELP_PAGE,
							'doc'  => $child->ID,
						),
						admin_url( 'admin.php' )
					);
					echo '<a class="dsm-help-topic__row" href="' . esc_url( $child_url ) . '"><span>' . esc_html( get_the_title( $child ) ) . '</span><span class="dsm-help-topic__chevron" aria-hidden="true">›</span></a>';
				}

				if ( count( $kids ) > 6 ) {
					echo '<a class="dsm-help-topic__row" href="' . esc_url( $topic_url ) . '"><span>' . esc_html(
						sprintf(
							/* translators: %d: number of guides in this topic. */
							__( 'View all %d', 'dsm-supreme-modules-pro-for-divi' ),
							count( $kids )
						)
					) . '</span><span class="dsm-help-topic__chevron" aria-hidden="true">›</span></a>';
				}

				echo '</div></div>';
			}

			echo '</div></section>';
		}

		if ( count( $posts ) >= 2 ) {
			$recent = $posts;
			usort(
				$recent,
				static function ( \WP_Post $a, \WP_Post $b ): int {
					return strcmp( (string) $b->post_modified, (string) $a->post_modified );
				}
			);
			$recent = array_slice( $recent, 0, 3 );

			echo '<section class="dsm-help-recent">';
			echo '<h2>' . esc_html__( 'Recently updated', 'dsm-supreme-modules-pro-for-divi' ) . '</h2>';
			echo '<div class="dsm-help-recent__list">';

			foreach ( $recent as $post ) {
				$url    = add_query_arg(
					array(
						'page' => self::HELP_PAGE,
						'doc'  => $post->ID,
					),
					admin_url( 'admin.php' )
				);
				$parent = (int) $post->post_parent > 0
					? get_the_title( (int) $post->post_parent )
					: __( 'Top level', 'dsm-supreme-modules-pro-for-divi' );

				echo '<a class="dsm-help-recent__row" href="' . esc_url( $url ) . '">';
				echo '<span class="dsm-help-recent__copy">';
				echo '<span class="dsm-help-recent__title">' . esc_html( get_the_title( $post ) ) . '</span>';
				echo '<span class="dsm-help-recent__parent">' . esc_html( $parent ) . '</span>';
				echo '</span>';
				echo '<span class="dsm-help-recent__date">' . esc_html( (string) get_the_modified_date( '', $post ) ) . '</span>';
				echo '</a>';
			}

			echo '</div></section>';
		}
	}

	/**
	 * Grouped Help docs for the sidebar. Top-level docs wrap their descendants.
	 *
	 * @param \WP_Post[] $posts     Docs in menu order.
	 * @param int        $parent_id Parent ID.
	 * @param int        $current   Current doc ID. Zero leaves every item inactive.
	 * @param string     $search    Active search string. Included in the doc URL when set.
	 * @param int        $depth     Nesting depth. Zero is a top-level group.
	 * @return void
	 */
	private function render_help_tree( array $posts, int $parent_id, int $current, string $search, int $depth = 0 ): void {
		$children = array();

		foreach ( $posts as $post ) {
			if ( (int) $post->post_parent === $parent_id ) {
				$children[] = $post;
			}
		}

		if ( array() === $children ) {
			return;
		}

		foreach ( $children as $post ) {
			$args = array(
				'page' => self::HELP_PAGE,
				'doc'  => $post->ID,
			);

			if ( '' !== $search ) {
				$args['s'] = $search;
			}

			$url   = add_query_arg( $args, admin_url( 'admin.php' ) );
			$class = 'dsm-help-nav__link';

			if ( $depth > 0 ) {
				$class .= ' dsm-help-nav__link--child';
			}

			if ( $depth > 1 ) {
				$class .= ' dsm-help-nav__link--deep';
			}

			if ( 0 === $depth ) {
				echo '<div class="dsm-help-nav__group">';
			}

			echo '<a class="' . esc_attr( $class ) . '" href="' . esc_url( $url ) . '"' . ( $current === (int) $post->ID ? ' aria-current="page"' : '' ) . '>' . esc_html( get_the_title( $post ) ) . '</a>';
			$this->render_help_tree( $posts, (int) $post->ID, $current, $search, $depth + 1 );

			if ( 0 === $depth ) {
				echo '</div>';
			}
		}
	}
}
