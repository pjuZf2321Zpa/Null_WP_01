<?php
/**
 * Page Tour extension — per-module steps + page-level customiser.
 *
 * Collects steps at `divi_module_wrapper_render` so Divi Loop clones are
 * included, then prints the same footer payload the existing engine reads.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Extensions;

use DiviSupreme\Extensions\IconLibraries\IconGlyphRenderer;
use DiviSupreme\Extensions\IconLibraries\IconLibraryRegistry;
use DiviSupreme\Extensions\IconLibraries\IconProcessFontIconBridge;
use DiviSupreme\Includes\DsmVbRestSave;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use ET\Builder\Packages\Module\Layout\Components\DynamicData\DynamicData;
use ET\Builder\Packages\Module\Options\Loop\LoopContext;
use ET\Builder\Packages\Module\Options\Loop\LoopUtils;
use ET\Builder\Packages\StyleLibrary\Declarations\BoxShadow\BoxShadow;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Boots the Page Tour extension when Extensions → Page Tour is on.
 */
class PageTour {

	public const SCRIPT_HANDLE = 'dsm-page-tour';

	public const META_KEY = 'dsm-page-tour-settings';

	/**
	 * Modules that must not become tour hosts.
	 *
	 * @var list<string>
	 */
	private const SKIP_MODULES = array(
		'dsm/page-tour',
		'dsm/page-tour-step',
		'divi/root',
	);

	/**
	 * Tippy animation slugs.
	 *
	 * @var list<string>
	 */
	private const TIPPY_ANIMATION_ALLOWLIST = array(
		'fade',
		'scale',
		'shift-away',
		'shift-toward',
		'perspective',
	);

	/**
	 * Default page-level settings.
	 *
	 * @var array<string, mixed>
	 */
	private array $default_settings = array(
		'tour_name'                    => '',
		'trigger'                      => 'page_load',
		'click_selector'               => '',
		'display_frequency'            => 'until_skipped',
		'start_behavior'               => 'in_view',
		'in_view_offset'               => '45%',
		'overlay_color'                => 'rgba(15, 10, 28, 0.55)',
		'hole_radius'                  => '4px',
		'tippy_animation'              => 'fade',
		'tippy_duration_show'          => '300ms',
		'tippy_duration_hide'          => '250ms',
		'tippy_move_transition'        => 'none',
		'popover_background'           => '#ffffff',
		'popover_max_width'            => '360px',
		'progress_color'               => '#5c1db0',
		'progress_track_color'         => '#ece6f5',
		'button_style_tab'             => 'primary',
		'nav_primary_icon_font_size'   => '16px',
		'nav_secondary_icon_font_size' => '16px',
		'show_preview'                 => 'off',
		'title_font_family'            => '',
		'title_font_weight'            => '600',
		'title_font_size'              => '16px',
		'title_font_color'             => '#2b1a4a',
		'title_line_height'            => '1.35em',
		'title_letter_spacing'         => '0px',
		'title_capitalization'         => '',
		'title_text_align'             => 'left',
		'title_text_wrap'              => 'wrap',
		'title_text_direction'         => 'horizontal-tb',
		'title_hyphenation'            => 'off',
		'title_paragraph_spacing'      => '',
		'body_font_family'             => '',
		'body_font_weight'             => '400',
		'body_font_size'               => '14px',
		'body_font_color'              => '#3d2d55',
		'body_line_height'             => '1.5em',
		'body_letter_spacing'          => '0px',
		'body_capitalization'          => '',
		'body_text_align'              => 'left',
		'body_text_wrap'               => 'wrap',
		'body_text_direction'          => 'horizontal-tb',
		'body_hyphenation'             => 'off',
		'body_paragraph_spacing'       => '',
	);

	/**
	 * Steps collected during this request.
	 *
	 * @var list<array<string, mixed>>
	 */
	private static array $collected_steps = array();

	/**
	 * Whether the footer renderer is hooked for this request.
	 *
	 * @var bool
	 */
	private static bool $footer_hooked = false;

	/**
	 * Constructor.
	 */
	public function __construct() {
		if ( ! function_exists( 'dsm_is_page_tour_extension_enabled' ) || ! dsm_is_page_tour_extension_enabled() ) {
			return;
		}

		add_filter( 'divi_module_wrapper_render', array( $this, 'filter_wrapper_render' ), 18, 2 );
		add_action( 'divi_visual_builder_rest_save_post', array( $this, 'save_page_settings' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'register_assets' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'maybe_enqueue_nav_button_webfonts' ), 100 );
		add_action( 'init', array( $this, 'register_meta' ) );
	}

	/**
	 * Register post meta used by the customiser.
	 *
	 * @return void
	 */
	public function register_meta(): void {
		$post_types = array( 'page', 'post', 'et_pb_layout' );
		foreach ( $post_types as $post_type ) {
			register_post_meta(
				$post_type,
				self::META_KEY,
				array(
					'type'          => 'object',
					'description'   => __( 'Divi Supreme Page Tour page settings', 'dsm-supreme-modules-pro-for-divi' ),
					'single'        => true,
					'show_in_rest'  => false,
					'auth_callback' => array( $this, 'auth_page_tour_settings' ),
					'default'       => array(),
				)
			);
		}
	}

	/**
	 * Persist customiser settings from a Visual Builder save.
	 *
	 * Divi's `sanitize_page_settings()` drops unknown keys, so the hook's
	 * second argument is only loop context. Read page settings from the
	 * already-parsed Visual Builder REST request (no second body decode).
	 *
	 * @param int                  $post_id Post ID.
	 * @param array<string, mixed> $data    Hook context (not the save payload).
	 * @return void
	 */
	public function save_page_settings( $post_id, $data = array() ): void {
		$post_id = absint( $post_id );
		if ( $post_id <= 0 ) {
			return;
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		$tour_settings = $this->extract_tour_settings_from_vb_save( is_array( $data ) ? $data : array() );
		if ( array() === $tour_settings ) {
			return;
		}

		update_post_meta( $post_id, self::META_KEY, $this->sanitize_page_settings( $tour_settings ) );
	}

	/**
	 * Extract tour settings from vb save.
	 *
	 * @param array<string, mixed> $hook_data Hook context.
	 * @return array<string, mixed>
	 */
	private function extract_tour_settings_from_vb_save( array $hook_data ): array {
		$from_hook = $this->tour_settings_from_payload( $hook_data );
		if ( array() !== $from_hook ) {
			return $from_hook;
		}

		return $this->tour_settings_from_payload( DsmVbRestSave::get_page_settings_payload() );
	}

	/**
	 * Tour settings from payload.
	 *
	 * @param array<string, mixed> $payload Decoded REST body or hook args.
	 * @return array<string, mixed>
	 */
	private function tour_settings_from_payload( array $payload ): array {
		if ( isset( $payload['dsm_page_tour_settings'] ) && is_array( $payload['dsm_page_tour_settings'] ) ) {
			return $payload['dsm_page_tour_settings'];
		}

		if ( isset( $payload['pageSettings']['dsm_page_tour_settings'] ) && is_array( $payload['pageSettings']['dsm_page_tour_settings'] ) ) {
			return $payload['pageSettings']['dsm_page_tour_settings'];
		}

		if ( isset( $payload['pageSettingsByLayout']['postContent']['dsm_page_tour_settings'] )
			&& is_array( $payload['pageSettingsByLayout']['postContent']['dsm_page_tour_settings'] )
		) {
			return $payload['pageSettingsByLayout']['postContent']['dsm_page_tour_settings'];
		}

		return array();
	}

	/**
	 * Get page settings.
	 *
	 * @param int $post_id Post ID.
	 * @return array<string, mixed>
	 */
	public function get_page_settings( $post_id ): array {
		$settings = get_post_meta( absint( $post_id ), self::META_KEY, true );
		if ( ! is_array( $settings ) ) {
			$settings = array();
		}

		$settings = $this->sanitize_page_settings( $settings );

		/**
		 * Filter Page Tour page-level settings.
		 *
		 * @param array<string, mixed> $settings Sanitized settings.
		 * @param int                   $post_id  Post ID.
		 */
		$filtered = apply_filters( 'dsm_page_tour_settings', $settings, absint( $post_id ) );

		return is_array( $filtered ) ? $this->sanitize_page_settings( $filtered ) : $settings;
	}

	/**
	 * Register FE script + Tippy deps (enqueued when a step is collected).
	 *
	 * @return void
	 */
	public function register_assets(): void {
		$version = defined( 'DSM5_VERSION' ) ? DSM5_VERSION : ( defined( 'DSM_VERSION' ) ? DSM_VERSION : '1.0.0' );

		if ( ! wp_script_is( 'dsm-popper', 'registered' ) ) {
			wp_register_script(
				'dsm-popper',
				DSM_DIR_URL . 'assets/js/popper.js',
				array(),
				$version,
				true
			);
		}

		if ( ! wp_script_is( 'dsm-tippy', 'registered' ) ) {
			wp_register_script(
				'dsm-tippy',
				DSM_DIR_URL . 'assets/js/tippy.js',
				array( 'dsm-popper' ),
				$version,
				true
			);
		}

		$js = DSM_DIR_PATH . 'divi-5/assets/js/page-tour.js';
		if ( is_readable( $js ) && ! wp_script_is( self::SCRIPT_HANDLE, 'registered' ) ) {
			wp_register_script(
				self::SCRIPT_HANDLE,
				DSM_DIR_URL . 'assets/js/page-tour.js',
				array( 'dsm-tippy' ),
				$version . '-' . (string) filemtime( $js ),
				true
			);
		}
	}

	/**
	 * Load DSM webfonts and Divi/Font Awesome @font-face for Page Tour nav icons.
	 *
	 * Webfonts enqueue in `wp_head`. Native Divi/FA faces print in `wp_footer`
	 * via the resolved Dynamic Assets fallback (never raw `#dynamic-product-dir/` CSS).
	 *
	 * @return void
	 */
	public function maybe_enqueue_nav_button_webfonts(): void {
		if ( is_admin() ) {
			return;
		}

		$post_id = (int) get_queried_object_id();
		if ( $post_id <= 0 ) {
			$post_id = (int) get_the_ID();
		}
		if ( $post_id <= 0 ) {
			return;
		}

		$page = $this->get_page_settings( $post_id );
		$this->maybe_enqueue_popover_text_fonts( $page );

		$icons = $this->collect_nav_button_icons( $page );
		if ( array() === $icons ) {
			return;
		}

		$needs_native_font = false;
		if ( class_exists( IconLibraryRegistry::class ) ) {
			IconLibraryRegistry::enqueue_webfonts_for_icons( $icons );
			foreach ( $icons as $icon ) {
				if ( ! is_array( $icon ) || IconLibraryRegistry::is_dsm_library_icon( $icon ) ) {
					continue;
				}
				$needs_native_font = true;
				break;
			}
		} else {
			$needs_native_font = true;
		}

		if ( $needs_native_font && function_exists( 'dsm_request_divi_icon_font_for_popup_render' ) ) {
			dsm_request_divi_icon_font_for_popup_render();
		}
	}

	/**
	 * Stamp the wrapper and collect a step when this module is a tour host.
	 *
	 * @param string               $module_wrapper Wrapper HTML.
	 * @param array<string, mixed> $args           Wrapper args.
	 * @return string
	 */
	public function filter_wrapper_render( $module_wrapper, $args ) {
		if ( ! is_string( $module_wrapper ) ) {
			$module_wrapper = '';
		}

		if ( ! is_array( $args ) ) {
			return $module_wrapper;
		}

		$name = isset( $args['name'] ) && is_string( $args['name'] ) ? $args['name'] : '';
		if ( in_array( $name, self::SKIP_MODULES, true ) ) {
			return $module_wrapper;
		}

		$attrs = isset( $args['attrs'] ) && is_array( $args['attrs'] ) ? $args['attrs'] : array();
		if ( 'on' !== $this->inner_desktop_string( $attrs, 'dsm_page_tour_enabled' ) ) {
			return $module_wrapper;
		}

		$loop_iteration = $this->loop_iteration( $attrs );
		$loop_mode      = $this->inner_desktop_string( $attrs, 'dsm_page_tour_loop_mode' );
		if ( ! in_array( $loop_mode, array( 'expand', 'first' ), true ) ) {
			$loop_mode = 'expand';
		}

		/**
		 * Filter how a looped Page Tour host expands.
		 *
		 * @param string               $loop_mode `expand` or `first`.
		 * @param array<string, mixed> $attrs     Module attrs.
		 * @param array<string, mixed> $args      Wrapper args.
		 */
		$loop_mode = apply_filters( 'dsm_page_tour_loop_mode', $loop_mode, $attrs, $args );
		if ( ! in_array( $loop_mode, array( 'expand', 'first' ), true ) ) {
			$loop_mode = 'expand';
		}

		if ( 'first' === $loop_mode && $loop_iteration > 0 ) {
			return $module_wrapper;
		}

		$step = $this->build_step_payload( $attrs, $args, $loop_iteration );
		if ( array() === $step ) {
			return $module_wrapper;
		}

		self::$collected_steps[] = $step;
		$this->maybe_hook_footer();

		$anchor = isset( $step['anchor'] ) && is_string( $step['anchor'] ) ? $step['anchor'] : '';
		$step_n = isset( $step['step'] ) ? (string) (int) $step['step'] : '1';

		return $this->inject_wrapper_attributes(
			$module_wrapper,
			array(
				'data-dsm-tour-step'   => $step_n,
				'data-dsm-tour-anchor' => $anchor,
			)
		);
	}

	/**
	 * Print overlay + JSON config in the footer.
	 *
	 * @return void
	 */
	public function render_footer(): void {
		if ( array() === self::$collected_steps ) {
			return;
		}

		$steps                 = self::$collected_steps;
		self::$collected_steps = array();

		usort(
			$steps,
			static function ( array $a, array $b ): int {
				$step_a = isset( $a['step'] ) ? (int) $a['step'] : 0;
				$step_b = isset( $b['step'] ) ? (int) $b['step'] : 0;
				if ( $step_a !== $step_b ) {
					return $step_a <=> $step_b;
				}

				$loop_a = isset( $a['loopIteration'] ) ? (int) $a['loopIteration'] : 0;
				$loop_b = isset( $b['loopIteration'] ) ? (int) $b['loopIteration'] : 0;
				return $loop_a <=> $loop_b;
			}
		);

		/**
		 * Filter collected Page Tour steps before the footer payload is built.
		 *
		 * @param list<array<string, mixed>> $steps Collected steps.
		 */
		$filtered = apply_filters( 'dsm_page_tour_steps', $steps );
		if ( is_array( $filtered ) ) {
			$steps = array_values( $filtered );
		}

		$post_id = (int) get_queried_object_id();
		if ( $post_id <= 0 ) {
			$post_id = (int) get_the_ID();
		}

		$page      = $this->get_page_settings( $post_id );
		$order     = 'dsm-page-tour--page-' . $post_id;
		$tour_name = sanitize_text_field( (string) $page['tour_name'] );
		$store_id  = sanitize_text_field( '' !== $tour_name ? $tour_name : 'dsm-page-tour-' . $post_id );

		$tour = array(
			'id'               => 'dsm-page-tour-' . $post_id,
			'storeId'          => $store_id,
			'name'             => $tour_name,
			'trigger'          => $page['trigger'],
			'clickSelector'    => $this->sanitize_css_selector( $page['click_selector'] ),
			'displayFrequency' => $page['display_frequency'],
			'startBehavior'    => $page['start_behavior'],
			'inViewOffset'     => $this->normalize_in_view_offset( $page['in_view_offset'] ),
			'animation'        => $this->sanitize_tippy_animation( $page['tippy_animation'] ),
			'durationShow'     => $this->sanitize_tippy_duration_ms( $page['tippy_duration_show'] ?? '300ms', 300 ),
			'durationHide'     => $this->sanitize_tippy_duration_ms( $page['tippy_duration_hide'] ?? '250ms', 250 ),
			'moveTransition'   => $this->sanitize_tippy_move_transition( $page['tippy_move_transition'] ?? 'none' ),
			'orderClass'       => $order,
			'holeRadius'       => $page['hole_radius'],
			'overlayColor'     => $page['overlay_color'],
			'popover'          => array(
				'background' => $this->resolve_responsive_design_value( $page['popover_background'] ?? '', 'popover_background', 'desktop' ),
				'maxWidth'   => $this->resolve_responsive_design_value( $page['popover_max_width'] ?? '', 'popover_max_width', 'desktop' ),
			),
			'buttonIcons'      => $this->build_button_icons( $page ),
			'steps'            => $steps,
		);

		$payload = array(
			'tours' => array( $tour ),
			'i18n'  => array(
				'back'     => esc_html__( 'Back', 'dsm-supreme-modules-pro-for-divi' ),
				'next'     => esc_html__( 'Next', 'dsm-supreme-modules-pro-for-divi' ),
				'skip'     => esc_html__( 'Skip', 'dsm-supreme-modules-pro-for-divi' ),
				'done'     => esc_html__( 'Done', 'dsm-supreme-modules-pro-for-divi' ),
				// translators: %1$s: current step number, %2$s: total steps.
				'progress' => esc_html__( 'Step %1$s of %2$s', 'dsm-supreme-modules-pro-for-divi' ),
			),
		);

		/**
		 * Filter the Page Tour footer payload (tours + i18n).
		 *
		 * @param array<string, mixed> $payload Footer JSON.
		 */
		$payload = apply_filters( 'dsm_page_tour_footer_payload', $payload );
		$payload = $this->sanitize_footer_payload_identity( is_array( $payload ) ? $payload : array() );

		$json = $this->encode_script_json( $payload );
		if ( ! is_string( $json ) || '' === $json ) {
			return;
		}

		$this->register_assets();
		if ( class_exists( \DiviSupreme\Includes\DsmFrontendModuleAssetRegistry::class ) ) {
			\DiviSupreme\Includes\DsmFrontendModuleAssetRegistry::register_extensions_bundle_style_handle();
			if ( wp_style_is( \DiviSupreme\Includes\DsmFrontendModuleAssetRegistry::EXTENSION_POPUP_STYLE_HANDLE, 'registered' ) ) {
				wp_enqueue_style( \DiviSupreme\Includes\DsmFrontendModuleAssetRegistry::EXTENSION_POPUP_STYLE_HANDLE );
			}
		}
		wp_enqueue_script( 'dsm-popper' );
		wp_enqueue_script( 'dsm-tippy' );
		wp_enqueue_script( self::SCRIPT_HANDLE );

		$style = sprintf(
			'--dsm-page-tour-overlay:%1$s;--dsm-page-tour-hole-radius:%2$s;--dsm-page-tour-popover-bg:%3$s;--dsm-page-tour-progress:%4$s;--dsm-page-tour-progress-track:%5$s;',
			esc_attr( $this->resolve_responsive_design_value( $page['overlay_color'] ?? '', 'overlay_color', 'desktop' ) ),
			esc_attr( $this->resolve_responsive_design_value( $page['hole_radius'] ?? '', 'hole_radius', 'desktop' ) ),
			esc_attr( $this->resolve_responsive_design_value( $page['popover_background'] ?? '', 'popover_background', 'desktop' ) ),
			esc_attr( $this->resolve_responsive_design_value( $page['progress_color'] ?? '', 'progress_color', 'desktop' ) ),
			esc_attr( $this->resolve_responsive_design_value( $page['progress_track_color'] ?? '', 'progress_track_color', 'desktop' ) )
		);

		echo '<div id="dsm-page-tour-root" class="dsm-page-tour__root ' . esc_attr( $order ) . '" style="' . $style . '" hidden>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- style is escaped per token.
		echo '<div class="dsm-page-tour__overlay" aria-hidden="true">';
		echo '<div class="dsm-page-tour__dim dsm-page-tour__dim--top"></div>';
		echo '<div class="dsm-page-tour__dim dsm-page-tour__dim--right"></div>';
		echo '<div class="dsm-page-tour__dim dsm-page-tour__dim--bottom"></div>';
		echo '<div class="dsm-page-tour__dim dsm-page-tour__dim--left"></div>';
		echo '<div class="dsm-page-tour__hole"></div>';
		echo '</div></div>';

		$chrome_css = $this->build_chrome_responsive_css( $page );
		$text_css   = $this->build_popover_text_stylesheet( $page );
		$button_css = $this->build_button_stylesheet( $page );
		$combined   = $chrome_css . $text_css . $button_css;
		if ( '' !== $combined ) {
			echo '<style id="dsm-page-tour-button-styles">' . $combined . '</style>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- declarations are sanitized.
		}

		echo '<script type="application/json" id="dsm-page-tour-data">';
		echo $json; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- HEX-encoded JSON; JSON.parse restores title/body HTML.
		echo '</script>';
	}

	/**
	 * Authorize access to Page Tour page settings meta.
	 *
	 * @param bool   $allowed  Whether the user can add the meta value.
	 * @param string $meta_key The meta key.
	 * @param int    $post_id  Post ID.
	 * @return bool
	 */
	public function auth_page_tour_settings( $allowed, $meta_key, $post_id ): bool {
		unset( $allowed, $meta_key );

		return current_user_can( 'edit_post', absint( $post_id ) );
	}

	/**
	 * Maybe hook footer.
	 *
	 * @return void
	 */
	private function maybe_hook_footer(): void {
		if ( self::$footer_hooked ) {
			return;
		}

		self::$footer_hooked = true;
		add_action( 'wp_footer', array( $this, 'render_footer' ), 20 );
	}

	/**
	 * Build step payload.
	 *
	 * @param array<string, mixed> $attrs           Module attrs.
	 * @param array<string, mixed> $args            Wrapper args.
	 * @param int                  $loop_iteration Loop clone index.
	 * @return array<string, mixed>
	 */
	private function build_step_payload( array $attrs, array $args, int $loop_iteration ): array {
		$title   = $this->inner_desktop_heading_text( $attrs, 'dsm_page_tour_title' );
		$content = $this->inner_desktop_heading_text( $attrs, 'dsm_page_tour_content' );
		if ( '' === $title && '' === $content ) {
			return array();
		}

		$highlight = $this->inner_desktop_string( $attrs, 'dsm_page_tour_highlight' );
		if ( '' === $highlight ) {
			$highlight = 'on';
		}

		$selector = $this->sanitize_css_selector( $this->inner_desktop_string( $attrs, 'dsm_page_tour_selector' ) );

		$mode = 'block';
		if ( 'off' === $highlight ) {
			$mode = 'none';
		} elseif ( '' !== $selector ) {
			$mode = 'selector';
		}

		$placement = $this->inner_desktop_string( $attrs, 'dsm_page_tour_placement' );
		if ( ! in_array( $placement, array( 'auto', 'top', 'bottom', 'left', 'right' ), true ) ) {
			$placement = 'auto';
		}

		$show_hole = $this->inner_desktop_string( $attrs, 'dsm_page_tour_show_hole' );
		if ( '' === $show_hole ) {
			$show_hole = 'on';
		}

		$skippable = $this->inner_desktop_string( $attrs, 'dsm_page_tour_skippable' );
		if ( '' === $skippable ) {
			$skippable = 'on';
		}

		$step_n = absint( $this->inner_desktop_string( $attrs, 'dsm_page_tour_step' ) );
		if ( $step_n < 1 ) {
			$step_n = 1;
		}

		$anchor = $this->build_anchor( $args, $loop_iteration );

		/**
		 * Filter the unique stamp for a looped (or static) Page Tour clone.
		 *
		 * @param string               $anchor          Stamp.
		 * @param array<string, mixed> $attrs           Module attrs.
		 * @param array<string, mixed> $args            Wrapper args.
		 * @param int                  $loop_iteration  Loop index.
		 */
		$anchor = apply_filters( 'dsm_page_tour_loop_anchor', $anchor, $attrs, $args, $loop_iteration );
		if ( ! is_string( $anchor ) ) {
			$anchor = '';
		}

		return array(
			'title'         => $title,
			'content'       => $content,
			'mode'          => $mode,
			'anchor'        => $anchor,
			'selector'      => $selector,
			'placement'     => $placement,
			'hole'          => 'on' === $show_hole,
			'skippable'     => 'on' === $skippable,
			'step'          => $step_n,
			'loopIteration' => $loop_iteration,
			'orderClass'    => 'dsm_page_tour_step_' . max( 0, $step_n - 1 ),
			'popover'       => $this->step_popover_chrome( $attrs ),
		);
	}

	/**
	 * Build anchor.
	 *
	 * @param array<string, mixed> $args Args.
	 * @param int                  $loop_iteration Loop iteration.
	 * @return string
	 */
	private function build_anchor( array $args, int $loop_iteration ): string {
		$name  = isset( $args['name'] ) && is_string( $args['name'] ) ? $args['name'] : '';
		$order = isset( $args['orderIndex'] ) ? (int) $args['orderIndex'] : 0;
		$base  = '' !== $name ? $name . '-' . $order : '';

		if ( '' === $base && isset( $args['id'] ) && is_scalar( $args['id'] ) ) {
			$base = (string) $args['id'];
		}

		if ( $loop_iteration > 0 && '' !== $base ) {
			return $base . '__loop-' . $loop_iteration;
		}

		return $base;
	}

	/**
	 * Loop iteration.
	 *
	 * @param array<string, mixed> $attrs Attrs.
	 * @return int
	 */
	private function loop_iteration( array $attrs ): int {
		if ( isset( $attrs['__loop_iteration'] ) && is_numeric( $attrs['__loop_iteration'] ) ) {
			return max( 0, (int) $attrs['__loop_iteration'] );
		}

		if ( class_exists( LoopContext::class ) ) {
			$ctx = LoopContext::get();
			if ( is_object( $ctx ) && isset( $ctx->iteration ) && is_numeric( $ctx->iteration ) ) {
				return max( 0, (int) $ctx->iteration );
			}
		}

		return 0;
	}

	/**
	 * Step popover chrome.
	 *
	 * @param array<string, mixed> $attrs Attrs.
	 * @return array<string, string>
	 */
	private function step_popover_chrome( array $attrs ): array {
		$background = $this->css_paint_from_attr_value(
			$attrs['dsm_page_tour_popover_background_color']['innerContent']['desktop']['value'] ?? ''
		);
		$max_width  = $this->inner_desktop_string( $attrs, 'dsm_page_tour_popover_max_width' );

		$shadow_raw = $attrs['dsm_page_tour_popover_style']['decoration']['boxShadow']['desktop']['value'] ?? array();
		$box_shadow = is_array( $shadow_raw ) && class_exists( BoxShadow::class ) ? BoxShadow::value( $shadow_raw ) : '';

		return array_filter(
			array(
				'background' => $background,
				'maxWidth'   => $max_width,
				'boxShadow'  => is_string( $box_shadow ) ? $box_shadow : '',
			)
		);
	}

	/**
	 * Sanitize page settings.
	 *
	 * @param array<string, mixed> $raw Raw.
	 * @return array<string, mixed>
	 */
	private function sanitize_page_settings( array $raw ): array {
		$out = $this->default_settings;

		foreach ( $out as $key => $fallback ) {
			if ( $this->is_responsive_design_key( $key ) ) {
				$out[ $key ] = $this->sanitize_responsive_design_value(
					$raw[ $key ] ?? null,
					(string) $fallback,
					$this->is_responsive_color_key( $key )
				);
				continue;
			}
			if ( ! isset( $raw[ $key ] ) || ! is_scalar( $raw[ $key ] ) ) {
				continue;
			}

			$value = sanitize_text_field( (string) $raw[ $key ] );
			if ( 'click_selector' === $key ) {
				$value = $this->sanitize_css_selector( $value );
			}
			if (
				'overlay_color' === $key
				|| 'popover_background' === $key
				|| 'progress_color' === $key
				|| 'progress_track_color' === $key
			) {
				$value = $this->sanitize_css_color( $value, $fallback );
			}
			$out[ $key ] = '' !== $value ? $value : $fallback;
		}

		if ( ! in_array( $out['trigger'], array( 'page_load', 'click', 'interaction' ), true ) ) {
			$out['trigger'] = 'page_load';
		}
		if ( ! in_array( $out['display_frequency'], array( 'once', 'always', 'until_skipped' ), true ) ) {
			$out['display_frequency'] = 'until_skipped';
		}
		if ( ! in_array( $out['start_behavior'], array( 'in_view', 'auto_scroll' ), true ) ) {
			$out['start_behavior'] = 'in_view';
		}
		$out['tippy_animation']       = $this->sanitize_tippy_animation( $out['tippy_animation'] );
		$out['tippy_duration_show']   = $this->sanitize_tippy_duration_ms( $out['tippy_duration_show'], 300 ) . 'ms';
		$out['tippy_duration_hide']   = $this->sanitize_tippy_duration_ms( $out['tippy_duration_hide'], 250 ) . 'ms';
		$out['tippy_move_transition'] = $this->sanitize_tippy_move_transition_slug( $out['tippy_move_transition'] );
		if ( 'secondary' !== $out['button_style_tab'] ) {
			$out['button_style_tab'] = 'primary';
		}

		$out['title_font_family']       = $this->sanitize_popover_font_family( (string) ( $raw['title_font_family'] ?? $out['title_font_family'] ) );
		$out['body_font_family']        = $this->sanitize_popover_font_family( (string) ( $raw['body_font_family'] ?? $out['body_font_family'] ) );
		$out['title_font_weight']       = $this->sanitize_popover_font_weight( (string) ( $out['title_font_weight'] ?? '600' ), '600' );
		$out['body_font_weight']        = $this->sanitize_popover_font_weight( (string) ( $out['body_font_weight'] ?? '400' ), '400' );
		$out['title_capitalization']    = $this->sanitize_popover_capitalization( (string) ( $out['title_capitalization'] ?? '' ) );
		$out['body_capitalization']     = $this->sanitize_popover_capitalization( (string) ( $out['body_capitalization'] ?? '' ) );
		$out['title_font_style']        = $this->sanitize_popover_font_style( $raw['title_font_style'] ?? array() );
		$out['body_font_style']         = $this->sanitize_popover_font_style( $raw['body_font_style'] ?? array() );
		$out['title_text_wrap']         = $this->sanitize_popover_text_wrap( (string) ( $out['title_text_wrap'] ?? 'wrap' ) );
		$out['body_text_wrap']          = $this->sanitize_popover_text_wrap( (string) ( $out['body_text_wrap'] ?? 'wrap' ) );
		$out['title_text_direction']    = $this->sanitize_popover_text_direction( (string) ( $out['title_text_direction'] ?? 'horizontal-tb' ) );
		$out['body_text_direction']     = $this->sanitize_popover_text_direction( (string) ( $out['body_text_direction'] ?? 'horizontal-tb' ) );
		$out['title_hyphenation']       = $this->sanitize_popover_hyphenation( (string) ( $out['title_hyphenation'] ?? 'off' ) );
		$out['body_hyphenation']        = $this->sanitize_popover_hyphenation( (string) ( $out['body_hyphenation'] ?? 'off' ) );
		$out['title_text_align']        = $this->sanitize_responsive_token_map(
			$out['title_text_align'] ?? 'left',
			'left',
			array( 'left', 'center', 'right', 'justify' )
		);
		$out['body_text_align']         = $this->sanitize_responsive_token_map(
			$out['body_text_align'] ?? 'left',
			'left',
			array( 'left', 'center', 'right', 'justify' )
		);
		$out['title_paragraph_spacing'] = $this->sanitize_responsive_length_map(
			$out['title_paragraph_spacing'] ?? ''
		);
		$out['body_paragraph_spacing']  = $this->sanitize_responsive_length_map(
			$out['body_paragraph_spacing'] ?? ''
		);

		$out['nav_primary']   = $this->sanitize_nested( $raw['nav_primary'] ?? null );
		$out['nav_secondary'] = $this->sanitize_nested( $raw['nav_secondary'] ?? null );
		$out                  = $this->migrate_flat_button_settings( $out, $raw );

		if ( array() === ( $out['nav_primary'] ?? array() ) ) {
			$out['nav_primary'] = $this->default_nav_decoration( '#5c1db0', '#ffffff' );
		}
		if ( array() === ( $out['nav_secondary'] ?? array() ) ) {
			$out['nav_secondary'] = $this->default_nav_decoration( '#efe8f8', '#5c1db0' );
		}

		return $out;
	}

	/**
	 * Default Button-module decoration for a nav button.
	 *
	 * @param string $background Background color.
	 * @param string $color      Text color.
	 * @return array<string, mixed>
	 */
	private function default_nav_decoration( string $background, string $color ): array {
		return array(
			'decoration' => array(
				'button'     => array(
					'desktop' => array(
						'value' => array(
							'enable' => 'on',
							'icon'   => array(
								'enable'    => 'off',
								'onHover'   => 'on',
								'placement' => 'right',
								'settings'  => array(),
							),
						),
					),
				),
				'background' => array(
					'desktop' => array(
						'value' => array(
							'color' => $background,
						),
					),
				),
				'font'       => array(
					'font' => array(
						'desktop' => array(
							'value' => array(
								'color'          => $color,
								'family'         => '',
								'size'           => '13px',
								'weight'         => '600',
								'letterSpacing'  => '0px',
								'lineHeight'     => '1.2em',
								'style'          => array(),
								'capitalization' => '',
							),
						),
					),
				),
				'border'     => array(
					'desktop' => array(
						'value' => array(
							'radius' => array(
								'sync'        => 'on',
								'topLeft'     => '3px',
								'topRight'    => '3px',
								'bottomLeft'  => '3px',
								'bottomRight' => '3px',
							),
							'styles' => array(
								'all' => array(
									'width' => '0px',
									'color' => '',
									'style' => 'solid',
								),
							),
						),
					),
				),
				'boxShadow'  => array(
					'desktop' => array(
						'value' => array(
							'style'      => 'none',
							'position'   => 'outer',
							'horizontal' => '0px',
							'vertical'   => '0px',
							'blur'       => '0px',
							'spread'     => '0px',
							'color'      => '#000000',
						),
					),
				),
				'spacing'    => array(
					'desktop' => array(
						'value' => array(
							'padding' => array(
								'top'            => '8px',
								'right'          => '12px',
								'bottom'         => '8px',
								'left'           => '12px',
								'syncVertical'   => 'on',
								'syncHorizontal' => 'on',
							),
						),
					),
				),
			),
		);
	}

	/**
	 * Whether a page setting is a Design responsive map.
	 *
	 * @param string $key Setting key.
	 * @return bool
	 */
	private function is_responsive_design_key( string $key ): bool {
		return in_array(
			$key,
			array(
				'overlay_color',
				'hole_radius',
				'popover_background',
				'popover_max_width',
				'progress_color',
				'progress_track_color',
				'nav_primary_icon_font_size',
				'nav_secondary_icon_font_size',
				'title_font_size',
				'title_font_color',
				'title_line_height',
				'title_letter_spacing',
				'title_text_align',
				'title_paragraph_spacing',
				'body_font_size',
				'body_font_color',
				'body_line_height',
				'body_letter_spacing',
				'body_text_align',
				'body_paragraph_spacing',
			),
			true
		);
	}

	/**
	 * Whether a Design map stores CSS colors.
	 *
	 * @param string $key Setting key.
	 * @return bool
	 */
	private function is_responsive_color_key( string $key ): bool {
		return in_array(
			$key,
			array(
				'overlay_color',
				'popover_background',
				'progress_color',
				'progress_track_color',
				'title_font_color',
				'body_font_color',
			),
			true
		);
	}

	/**
	 * Soft-migrate a flat string into `{ desktop: value }` and sanitize leaves.
	 *
	 * @param mixed  $raw       Stored value.
	 * @param string $fallback  Desktop default.
	 * @param bool   $is_color  Sanitize as CSS color.
	 * @return array<string, string>
	 */
	private function sanitize_responsive_design_value( $raw, string $fallback, bool $is_color ): array {
		$allowed = array( 'desktop', 'tablet', 'tabletWide', 'phone', 'phoneWide' );
		$map     = array();

		if ( is_string( $raw ) || is_numeric( $raw ) ) {
			$map['desktop'] = (string) $raw;
		} elseif ( is_array( $raw ) ) {
			foreach ( $raw as $bp => $leaf ) {
				if ( ! is_string( $bp ) || ! in_array( $bp, $allowed, true ) ) {
					continue;
				}
				if ( is_string( $leaf ) || is_numeric( $leaf ) ) {
					$map[ $bp ] = (string) $leaf;
				}
			}
		}

		if ( ! isset( $map['desktop'] ) || '' === $map['desktop'] ) {
			$map['desktop'] = $fallback;
		}

		foreach ( $map as $bp => $leaf ) {
			$clean = sanitize_text_field( $leaf );
			if ( $is_color ) {
				$clean = $this->sanitize_css_color( $clean, $fallback );
			}
			$map[ $bp ] = '' !== $clean ? $clean : $fallback;
		}

		return $map;
	}

	/**
	 * Resolve a Design map at a coarse breakpoint (phone ← tablet ← desktop).
	 *
	 * @param mixed  $raw      Stored map or string.
	 * @param string $key      Setting key.
	 * @param string $breakpoint desktop|tablet|phone.
	 * @return string
	 */
	private function resolve_responsive_design_value( $raw, string $key, string $breakpoint ): string {
		$fallback = isset( $this->default_settings[ $key ] ) ? (string) $this->default_settings[ $key ] : '';
		$map      = $this->sanitize_responsive_design_value( $raw, $fallback, $this->is_responsive_color_key( $key ) );
		$ladder   = array( 'desktop' );
		if ( 'tablet' === $breakpoint ) {
			$ladder = array( 'tablet', 'desktop' );
		} elseif ( 'phone' === $breakpoint ) {
			$ladder = array( 'phone', 'tablet', 'desktop' );
		}

		foreach ( $ladder as $bp ) {
			if ( isset( $map[ $bp ] ) && '' !== $map[ $bp ] ) {
				return $map[ $bp ];
			}
		}

		return $fallback;
	}

	/**
	 * Overlay / popover / progress CSS variables at tablet and phone.
	 *
	 * @param array<string, mixed> $page Page settings.
	 * @return string
	 */
	private function build_chrome_responsive_css( array $page ): string {
		$vars  = array(
			'overlay_color'        => '--dsm-page-tour-overlay',
			'hole_radius'          => '--dsm-page-tour-hole-radius',
			'popover_background'   => '--dsm-page-tour-popover-bg',
			'progress_color'       => '--dsm-page-tour-progress',
			'progress_track_color' => '--dsm-page-tour-progress-track',
		);
		$media = array(
			'tablet' => '980px',
			'phone'  => '767px',
		);
		$css   = '';
		$scope = '#dsm-page-tour-root,.dsm-page-tour__tippy';

		foreach ( $media as $bp => $max ) {
			$decls = array();
			foreach ( $vars as $key => $custom ) {
				$desktop = $this->resolve_responsive_design_value( $page[ $key ] ?? '', $key, 'desktop' );
				$value   = $this->resolve_responsive_design_value( $page[ $key ] ?? '', $key, $bp );
				if ( $value === $desktop ) {
					continue;
				}
				$decls[] = $custom . ':' . $value;
			}
			if ( array() === $decls ) {
				continue;
			}
			$css .= '@media (max-width:' . $max . '){' . $scope . '{' . implode( ';', $decls ) . '}}';
		}

		$max_width_tablet = $this->resolve_responsive_design_value( $page['popover_max_width'] ?? '', 'popover_max_width', 'tablet' );
		$max_width_phone  = $this->resolve_responsive_design_value( $page['popover_max_width'] ?? '', 'popover_max_width', 'phone' );
		$max_width_desk   = $this->resolve_responsive_design_value( $page['popover_max_width'] ?? '', 'popover_max_width', 'desktop' );
		$popover          = '.dsm-page-tour__tippy .tippy-box';
		if ( $max_width_tablet !== $max_width_desk ) {
			$css .= '@media (max-width:980px){' . $popover . '{max-width:' . sanitize_text_field( $max_width_tablet ) . '!important}}';
		}
		if ( $max_width_phone !== $max_width_desk ) {
			$css .= '@media (max-width:767px){' . $popover . '{max-width:' . sanitize_text_field( $max_width_phone ) . '!important}}';
		}

		return $css;
	}

	/**
	 * Title / body typography CSS for the tour popover.
	 *
	 * @param array<string, mixed> $page Page settings.
	 * @return string
	 */
	private function build_popover_text_stylesheet( array $page ): string {
		$css  = $this->popover_text_rule( $page, 'title', 'desktop' );
		$css .= $this->popover_text_rule( $page, 'body', 'desktop' );
		$css .= $this->popover_text_paragraph_rule( $page, 'title', 'desktop' );
		$css .= $this->popover_text_paragraph_rule( $page, 'body', 'desktop' );

		$media_queries = array(
			'tablet' => '980px',
			'phone'  => '767px',
		);
		foreach ( $media_queries as $bp => $max ) {
			$media  = $this->popover_text_responsive_diff( $page, 'title', $bp );
			$media .= $this->popover_text_responsive_diff( $page, 'body', $bp );
			$media .= $this->popover_text_paragraph_responsive_diff( $page, 'title', $bp );
			$media .= $this->popover_text_paragraph_responsive_diff( $page, 'body', $bp );
			if ( '' === $media ) {
				continue;
			}
			$css .= '@media (max-width:' . $max . '){' . $media . '}';
		}

		/**
		 * Filter generated Page Tour title / body typography CSS.
		 *
		 * @param string               $css  Stylesheet.
		 * @param array<string, mixed> $page Sanitized page settings.
		 */
		return (string) apply_filters( 'dsm_page_tour_popover_text_css', $css, $page );
	}

	/**
	 * One title or body rule at a breakpoint.
	 *
	 * @param array<string, mixed> $page       Page settings.
	 * @param string               $role       title|body.
	 * @param string               $breakpoint desktop|tablet|phone.
	 * @return string
	 */
	private function popover_text_rule( array $page, string $role, string $breakpoint ): string {
		$prefix = 'title' === $role ? 'title' : 'body';
		$decls  = array();

		$family = $this->sanitize_popover_font_family( (string) ( $page[ $prefix . '_font_family' ] ?? '' ) );
		if ( '' !== $family ) {
			if ( false !== strpos( $family, ',' ) || 'inherit' === $family ) {
				$decls[] = 'font-family:' . $family;
			} else {
				$decls[] = 'font-family:"' . str_replace( '"', '', $family ) . '"';
			}
		}

		$weight = $this->sanitize_popover_font_weight(
			(string) ( $page[ $prefix . '_font_weight' ] ?? '' ),
			'title' === $prefix ? '600' : '400'
		);
		if ( '' !== $weight ) {
			$decls[] = 'font-weight:' . $weight;
		}

		$size = $this->resolve_responsive_design_value( $page[ $prefix . '_font_size' ] ?? '', $prefix . '_font_size', $breakpoint );
		if ( '' !== $size ) {
			$decls[] = 'font-size:' . sanitize_text_field( $size );
		}

		$color = $this->paint( $this->resolve_responsive_design_value( $page[ $prefix . '_font_color' ] ?? '', $prefix . '_font_color', $breakpoint ) );
		if ( '' !== $color ) {
			$decls[] = 'color:' . $color;
		}

		$line = $this->resolve_responsive_design_value( $page[ $prefix . '_line_height' ] ?? '', $prefix . '_line_height', $breakpoint );
		if ( '' !== $line ) {
			$decls[] = 'line-height:' . sanitize_text_field( $line );
		}

		$letter = $this->resolve_responsive_design_value( $page[ $prefix . '_letter_spacing' ] ?? '', $prefix . '_letter_spacing', $breakpoint );
		if ( '' !== $letter ) {
			$decls[] = 'letter-spacing:' . sanitize_text_field( $letter );
		}

		$styles  = $this->sanitize_popover_font_style( $page[ $prefix . '_font_style' ] ?? array() );
		$decls[] = 'font-style:' . ( in_array( 'italic', $styles, true ) ? 'italic' : 'normal' );
		$deco    = array();
		if ( in_array( 'underline', $styles, true ) ) {
			$deco[] = 'underline';
		}
		if ( in_array( 'overline', $styles, true ) ) {
			$deco[] = 'overline';
		}
		if ( in_array( 'strikethrough', $styles, true ) ) {
			$deco[] = 'line-through';
		}
		if ( array() !== $deco ) {
			$decls[] = 'text-decoration:' . implode( ' ', $deco );
		}

		$caps = $this->sanitize_popover_capitalization( (string) ( $page[ $prefix . '_capitalization' ] ?? '' ) );
		if ( in_array( $caps, array( 'uppercase', 'lowercase', 'capitalize' ), true ) ) {
			$decls[] = 'text-transform:' . $caps;
			$decls[] = 'font-variant-caps:normal';
		} elseif ( 'smallCaps' === $caps ) {
			$decls[] = 'text-transform:none';
			$decls[] = 'font-variant-caps:small-caps';
		} elseif ( 'allSmallCaps' === $caps ) {
			$decls[] = 'text-transform:none';
			$decls[] = 'font-variant-caps:all-small-caps';
		} else {
			$decls[] = 'text-transform:none';
			$decls[] = 'font-variant-caps:normal';
		}

		$align   = $this->sanitize_popover_text_align(
			$this->resolve_responsive_design_value( $page[ $prefix . '_text_align' ] ?? '', $prefix . '_text_align', $breakpoint )
		);
		$decls[] = 'text-align:' . $align;
		$decls[] = 'text-wrap:' . $this->sanitize_popover_text_wrap( (string) ( $page[ $prefix . '_text_wrap' ] ?? 'wrap' ) );
		$decls[] = 'writing-mode:' . $this->sanitize_popover_text_direction( (string) ( $page[ $prefix . '_text_direction' ] ?? 'horizontal-tb' ) );
		if ( 'on' === $this->sanitize_popover_hyphenation( (string) ( $page[ $prefix . '_hyphenation' ] ?? 'off' ) ) ) {
			$decls[] = 'hyphens:auto';
		}

		return $this->popover_text_important_rule( $this->popover_text_selector( $role ), $decls );
	}

	/**
	 * Responsive size / color / line-height / letter-spacing overrides.
	 *
	 * @param array<string, mixed> $page       Page settings.
	 * @param string               $role       title|body.
	 * @param string               $breakpoint tablet|phone.
	 * @return string
	 */
	private function popover_text_responsive_diff( array $page, string $role, string $breakpoint ): string {
		$prefix = 'title' === $role ? 'title' : 'body';
		$map    = array(
			$prefix . '_font_size'      => 'font-size',
			$prefix . '_font_color'     => 'color',
			$prefix . '_line_height'    => 'line-height',
			$prefix . '_letter_spacing' => 'letter-spacing',
			$prefix . '_text_align'     => 'text-align',
		);
		$decls  = array();

		foreach ( $map as $key => $prop ) {
			$desktop = $this->resolve_responsive_design_value( $page[ $key ] ?? '', $key, 'desktop' );
			$value   = $this->resolve_responsive_design_value( $page[ $key ] ?? '', $key, $breakpoint );
			if ( '' === $value || $value === $desktop ) {
				continue;
			}
			if ( 'color' === $prop ) {
				$decls[] = $prop . ':' . $this->paint( $value );
			} elseif ( 'text-align' === $prop ) {
				$decls[] = $prop . ':' . $this->sanitize_popover_text_align( $value );
			} else {
				$decls[] = $prop . ':' . sanitize_text_field( $value );
			}
		}

		return $this->popover_text_important_rule( $this->popover_text_selector( $role ), $decls );
	}

	/**
	 * CSS selector list for title or body copy.
	 *
	 * @param string $role title|body.
	 * @return string
	 */
	private function popover_text_selector( string $role ): string {
		$leaf = 'title' === $role ? '.dsm-page-tour__step-title' : '.dsm-page-tour__step-body';

		return '#dsm-page-tour-root ' . $leaf . ',.dsm-page-tour__tippy ' . $leaf . ',.dsm-page-tour__popover ' . $leaf;
	}

	/**
	 * Paragraph-spacing selector (title block vs body paragraphs).
	 *
	 * @param string $role title|body.
	 * @return string
	 */
	private function popover_text_paragraph_selector( string $role ): string {
		$selector = $this->popover_text_selector( $role );
		if ( 'title' === $role ) {
			return $selector;
		}

		$parts = explode( ',', $selector );
		$out   = array();
		foreach ( $parts as $part ) {
			$part = trim( $part );
			if ( '' !== $part ) {
				$out[] = $part . ' p';
			}
		}

		return implode( ',', $out );
	}

	/**
	 * Paragraph spacing rule at a breakpoint.
	 *
	 * @param array<string, mixed> $page       Page settings.
	 * @param string               $role       title|body.
	 * @param string               $breakpoint desktop|tablet|phone.
	 * @return string
	 */
	private function popover_text_paragraph_rule( array $page, string $role, string $breakpoint ): string {
		$prefix  = 'title' === $role ? 'title' : 'body';
		$spacing = $this->sanitize_css_length(
			$this->resolve_responsive_design_value( $page[ $prefix . '_paragraph_spacing' ] ?? '', $prefix . '_paragraph_spacing', $breakpoint )
		);
		if ( '' === $spacing ) {
			return '';
		}

		$target = $this->popover_text_paragraph_selector( $role );
		$css    = $this->popover_text_important_rule( $target, array( 'margin-bottom:' . $spacing ) );
		if ( 'body' === $role ) {
			$css .= $this->popover_text_important_rule( $target . ':last-child', array( 'margin-bottom:0' ) );
		}

		return $css;
	}

	/**
	 * Responsive paragraph-spacing override.
	 *
	 * @param array<string, mixed> $page       Page settings.
	 * @param string               $role       title|body.
	 * @param string               $breakpoint tablet|phone.
	 * @return string
	 */
	private function popover_text_paragraph_responsive_diff( array $page, string $role, string $breakpoint ): string {
		$prefix  = 'title' === $role ? 'title' : 'body';
		$desktop = $this->sanitize_css_length(
			$this->resolve_responsive_design_value( $page[ $prefix . '_paragraph_spacing' ] ?? '', $prefix . '_paragraph_spacing', 'desktop' )
		);
		$next    = $this->sanitize_css_length(
			$this->resolve_responsive_design_value( $page[ $prefix . '_paragraph_spacing' ] ?? '', $prefix . '_paragraph_spacing', $breakpoint )
		);
		if ( '' === $next || $next === $desktop ) {
			return '';
		}

		$target = $this->popover_text_paragraph_selector( $role );
		$css    = $this->popover_text_important_rule( $target, array( 'margin-bottom:' . $next ) );
		if ( 'body' === $role ) {
			$css .= $this->popover_text_important_rule( $target . ':last-child', array( 'margin-bottom:0' ) );
		}

		return $css;
	}

	/**
	 * Join declarations into an !important rule.
	 *
	 * @param string   $selector Selector list.
	 * @param string[] $decls    CSS declarations without !important.
	 * @return string
	 */
	private function popover_text_important_rule( string $selector, array $decls ): string {
		$clean = array();
		foreach ( $decls as $decl ) {
			if ( ! is_string( $decl ) || '' === $decl ) {
				continue;
			}
			$clean[] = false !== strpos( $decl, '!important' ) ? $decl : $decl . '!important';
		}
		if ( array() === $clean ) {
			return '';
		}

		return $selector . '{' . implode( ';', $clean ) . '}';
	}

	/**
	 * Sanitize Divi SelectFont family (empty = inherit).
	 *
	 * @param string $family Family name.
	 * @return string
	 */
	private function sanitize_popover_font_family( string $family ): string {
		$family = trim( sanitize_text_field( $family ) );
		if ( '' === $family || 'Default' === $family || 'inherit' === $family ) {
			return '';
		}
		if ( preg_match( '/url\s*\(|expression\s*\(|@import|<|>|\{|\}|;/i', $family ) ) {
			return '';
		}
		if ( ! preg_match( '/^[\w\s\-\'",.]+$/u', $family ) ) {
			return '';
		}

		if ( strlen( $family ) > 120 ) {
			return substr( $family, 0, 120 );
		}

		return $family;
	}

	/**
	 * Sanitize a CSS font-weight token.
	 *
	 * @param string $weight   Stored weight.
	 * @param string $fallback Fallback token.
	 * @return string
	 */
	private function sanitize_popover_font_weight( string $weight, string $fallback ): string {
		$weight = trim( $weight );
		if ( preg_match( '/^(?:[1-9]00|normal|bold)$/', $weight ) ) {
			return $weight;
		}

		return $fallback;
	}

	/**
	 * Sanitize a FontGroup capitalization slug.
	 *
	 * @param string $value Stored capitalization slug.
	 * @return string
	 */
	private function sanitize_popover_capitalization( string $value ): string {
		$value = sanitize_text_field( $value );

		return in_array( $value, array( 'uppercase', 'lowercase', 'capitalize', 'smallCaps', 'allSmallCaps' ), true )
			? $value
			: '';
	}

	/**
	 * Sanitize italic / underline / overline / strikethrough flags.
	 *
	 * @param mixed $raw Stored style flags.
	 * @return list<string>
	 */
	private function sanitize_popover_font_style( $raw ): array {
		if ( ! is_array( $raw ) ) {
			if ( ! is_string( $raw ) || '' === $raw ) {
				return array();
			}
			$parts = preg_split( '/[,\s]+/', $raw );
			$raw   = false === $parts ? array() : $parts;
		}

		$allowed = array( 'italic', 'underline', 'overline', 'strikethrough' );
		$out     = array();
		foreach ( $raw as $flag ) {
			if ( ! is_string( $flag ) ) {
				continue;
			}
			$flag = trim( $flag );
			if ( in_array( $flag, $allowed, true ) && ! in_array( $flag, $out, true ) ) {
				$out[] = $flag;
			}
		}

		return $out;
	}

	/**
	 * Sanitize FontGroup text-align token.
	 *
	 * @param string $value Stored align.
	 * @return string
	 */
	private function sanitize_popover_text_align( string $value ): string {
		$value = sanitize_text_field( $value );

		return in_array( $value, array( 'left', 'center', 'right', 'justify' ), true ) ? $value : 'left';
	}

	/**
	 * Sanitize FontGroup text-wrap token.
	 *
	 * @param string $value Stored wrap.
	 * @return string
	 */
	private function sanitize_popover_text_wrap( string $value ): string {
		$value = sanitize_text_field( $value );

		return in_array( $value, array( 'wrap', 'balance', 'pretty' ), true ) ? $value : 'wrap';
	}

	/**
	 * Sanitize FontGroup writing-mode token.
	 *
	 * @param string $value Stored writing mode.
	 * @return string
	 */
	private function sanitize_popover_text_direction( string $value ): string {
		$value = sanitize_text_field( $value );

		return in_array( $value, array( 'horizontal-tb', 'vertical-rl', 'vertical-lr' ), true )
			? $value
			: 'horizontal-tb';
	}

	/**
	 * Sanitize hyphenation toggle.
	 *
	 * @param string $value Stored on/off.
	 * @return string
	 */
	private function sanitize_popover_hyphenation( string $value ): string {
		return 'on' === sanitize_text_field( $value ) ? 'on' : 'off';
	}

	/**
	 * Sanitize a CSS length used for paragraph spacing.
	 *
	 * @param string $value Stored length.
	 * @return string
	 */
	private function sanitize_css_length( string $value ): string {
		$value = trim( sanitize_text_field( $value ) );
		if ( '' === $value ) {
			return '';
		}
		if ( ! preg_match( '/^-?\d+(?:\.\d+)?(?:px|em|rem|%)$/', $value ) ) {
			return '';
		}

		return $value;
	}

	/**
	 * Sanitize a responsive map of discrete tokens.
	 *
	 * @param mixed    $raw      Stored map or string.
	 * @param string   $fallback Desktop fallback.
	 * @param string[] $allowed  Allowed tokens.
	 * @return array<string, string>
	 */
	private function sanitize_responsive_token_map( $raw, string $fallback, array $allowed ): array {
		$map = $this->sanitize_responsive_design_value( $raw, $fallback, false );
		foreach ( $map as $bp => $leaf ) {
			$map[ $bp ] = in_array( $leaf, $allowed, true ) ? $leaf : $fallback;
		}

		return $map;
	}

	/**
	 * Sanitize a responsive map of CSS lengths (empty allowed).
	 *
	 * @param mixed $raw Stored map or string.
	 * @return array<string, string>
	 */
	private function sanitize_responsive_length_map( $raw ): array {
		$map = $this->sanitize_responsive_design_value( $raw, '', false );
		foreach ( $map as $bp => $leaf ) {
			$map[ $bp ] = $this->sanitize_css_length( (string) $leaf );
		}

		return $map;
	}

	/**
	 * Load Google / Divi fonts used by title and body.
	 *
	 * @param array<string, mixed> $page Page settings.
	 * @return void
	 */
	private function maybe_enqueue_popover_text_fonts( array $page ): void {
		if ( ! function_exists( 'et_builder_enqueue_font' ) ) {
			return;
		}

		foreach ( array( 'title_font_family', 'body_font_family' ) as $key ) {
			$family = $this->sanitize_popover_font_family( (string) ( $page[ $key ] ?? '' ) );
			if ( '' !== $family ) {
				et_builder_enqueue_font( $family );
			}
		}
	}

	/**
	 * Icon font-size media queries for a nav button selector.
	 *
	 * @param string $selector Button selector.
	 * @param mixed  $raw      Stored size map.
	 * @param string $key      Setting key.
	 * @return string
	 */
	private function nav_button_icon_size_media( string $selector, $raw, string $key ): string {
		$desktop = $this->resolve_responsive_design_value( $raw, $key, 'desktop' );
		$css     = '';
		foreach ( array(
			'tablet' => '980px',
			'phone'  => '767px',
		) as $bp => $max ) {
			$size = $this->resolve_responsive_design_value( $raw, $key, $bp );
			if ( $size === $desktop ) {
				continue;
			}
			$parts = array_values( array_filter( array_map( 'trim', explode( ',', $selector ) ) ) );
			$icon  = array();
			foreach ( $parts as $part ) {
				$icon[] = $part . '::after';
				$icon[] = $part . '::before';
				$icon[] = $part . ' .dsm-webfont-icon-glyph';
			}
			$css .= '@media (max-width:' . $max . '){' . implode( ',', $icon ) . '{font-size:' . sanitize_text_field( $size ) . '!important}}';
		}

		return $css;
	}

	/**
	 * Recursively sanitize a nested settings object.
	 *
	 * @param mixed $raw Raw value.
	 * @return array<string, mixed>
	 */
	private function sanitize_nested( $raw ): array {
		if ( ! is_array( $raw ) ) {
			return array();
		}

		$out = array();
		foreach ( $raw as $key => $value ) {
			if ( is_int( $key ) ) {
				$store_key = $key;
			} elseif ( is_string( $key ) && 1 === preg_match( '/^[A-Za-z0-9_\-]+$/', $key ) ) {
				$store_key = $key;
			} else {
				continue;
			}
			if ( is_array( $value ) ) {
				$out[ $store_key ] = $this->sanitize_nested( $value );
				continue;
			}
			if ( is_bool( $value ) ) {
				$out[ $store_key ] = $value;
				continue;
			}
			if ( is_int( $value ) || is_float( $value ) ) {
				$out[ $store_key ] = $value;
				continue;
			}
			if ( is_string( $value ) ) {
				if ( 'url' === $store_key ) {
					$out[ $store_key ] = esc_url_raw( $value );
					continue;
				}
				$out[ $store_key ] = sanitize_text_field( $value );
			}
		}

		return $out;
	}

	/**
	 * Lift leftover flat colour / radius keys into decoration objects.
	 *
	 * @param array<string, mixed> $out Sanitized settings.
	 * @param array<string, mixed> $raw Raw settings.
	 * @return array<string, mixed>
	 */
	private function migrate_flat_button_settings( array $out, array $raw ): array {
		if ( array() === ( $out['nav_primary'] ?? array() ) && isset( $raw['btn_primary_bg'] ) ) {
			$out['nav_primary'] = $this->default_nav_decoration(
				$this->sanitize_css_color( (string) $raw['btn_primary_bg'], '#5c1db0' ),
				$this->sanitize_css_color( (string) ( $raw['btn_primary_color'] ?? '#ffffff' ), '#ffffff' )
			);
			if ( isset( $raw['btn_radius'] ) && is_string( $raw['btn_radius'] ) && '' !== $raw['btn_radius'] ) {
				$radius = sanitize_text_field( $raw['btn_radius'] );
				$out['nav_primary']['decoration']['border']['desktop']['value']['radius'] = array(
					'sync'        => 'on',
					'topLeft'     => $radius,
					'topRight'    => $radius,
					'bottomLeft'  => $radius,
					'bottomRight' => $radius,
				);
			}
		}

		if ( array() === ( $out['nav_secondary'] ?? array() ) && isset( $raw['btn_secondary_bg'] ) ) {
			$out['nav_secondary'] = $this->default_nav_decoration(
				$this->sanitize_css_color( (string) $raw['btn_secondary_bg'], '#efe8f8' ),
				$this->sanitize_css_color( (string) ( $raw['btn_secondary_color'] ?? '#5c1db0' ), '#5c1db0' )
			);
			if ( isset( $raw['btn_radius'] ) && is_string( $raw['btn_radius'] ) && '' !== $raw['btn_radius'] ) {
				$radius = sanitize_text_field( $raw['btn_radius'] );
				$out['nav_secondary']['decoration']['border']['desktop']['value']['radius'] = array(
					'sync'        => 'on',
					'topLeft'     => $radius,
					'topRight'    => $radius,
					'bottomLeft'  => $radius,
					'bottomRight' => $radius,
				);
			}
		}

		return $out;
	}

	/**
	 * Read a nested value from a nav decoration tree.
	 *
	 * @param array<string, mixed> $nav  Button decoration.
	 * @param array                $path Path segments.
	 * @return mixed
	 */
	private function nav_path( array $nav, array $path ) {
		$cur = $nav;
		foreach ( $path as $key ) {
			if ( ! is_array( $cur ) || ! array_key_exists( $key, $cur ) ) {
				return null;
			}
			$cur = $cur[ $key ];
		}
		return $cur;
	}

	/**
	 * ColorPicker leaf → sanitized CSS color.
	 *
	 * @param mixed $value Raw color.
	 * @return string
	 */
	private function paint( $value ): string {
		if ( is_string( $value ) ) {
			return $this->sanitize_css_color( $value, '' );
		}
		if ( is_array( $value ) ) {
			if ( isset( $value['color'] ) ) {
				return $this->paint( $value['color'] );
			}
			if ( isset( $value['hex'] ) && is_string( $value['hex'] ) ) {
				return $this->sanitize_css_color( $value['hex'], '' );
			}
		}
		return '';
	}

	/**
	 * Build the Page Tour nav-button stylesheet.
	 *
	 * @param array<string, mixed> $page Page settings.
	 * @return string
	 */
	private function build_button_stylesheet( array $page ): string {
		$primary   = is_array( $page['nav_primary'] ?? null ) ? $page['nav_primary'] : array();
		$secondary = is_array( $page['nav_secondary'] ?? null ) ? $page['nav_secondary'] : array();

		$primary_sel   = '#dsm-page-tour-root .et_pb_button.dsm-page-tour__btn--next,.dsm-page-tour__tippy .et_pb_button.dsm-page-tour__btn--next';
		$secondary_sel = '#dsm-page-tour-root .et_pb_button.dsm-page-tour__btn--back,#dsm-page-tour-root .et_pb_button.dsm-page-tour__btn--skip,.dsm-page-tour__tippy .et_pb_button.dsm-page-tour__btn--back,.dsm-page-tour__tippy .et_pb_button.dsm-page-tour__btn--skip';

		$css  = $this->nav_button_rule(
			$primary_sel,
			$primary,
			$this->resolve_responsive_design_value( $page['nav_primary_icon_font_size'] ?? '', 'nav_primary_icon_font_size', 'desktop' )
		);
		$css .= $this->nav_button_rule(
			$secondary_sel,
			$secondary,
			$this->resolve_responsive_design_value( $page['nav_secondary_icon_font_size'] ?? '', 'nav_secondary_icon_font_size', 'desktop' )
		);
		$css .= $this->nav_button_icon_size_media(
			$primary_sel,
			$page['nav_primary_icon_font_size'] ?? '',
			'nav_primary_icon_font_size'
		);
		$css .= $this->nav_button_icon_size_media(
			$secondary_sel,
			$page['nav_secondary_icon_font_size'] ?? '',
			'nav_secondary_icon_font_size'
		);

		return $css;
	}

	/**
	 * One CSS rule for a primary or secondary nav button.
	 *
	 * @param string               $selector  CSS selector.
	 * @param array<string, mixed> $nav       Button decoration.
	 * @param string               $icon_size Icon font size.
	 * @return string
	 */
	private function nav_button_rule( string $selector, array $nav, string $icon_size ): string {
		$font       = $this->nav_path( $nav, array( 'decoration', 'font', 'font', 'desktop', 'value' ) );
		$font       = is_array( $font ) ? $font : array();
		$background = $this->nav_path( $nav, array( 'decoration', 'background', 'desktop', 'value' ) );
		$background = is_array( $background ) ? $background : array();
		$border     = $this->nav_path( $nav, array( 'decoration', 'border', 'desktop', 'value' ) );
		$border     = is_array( $border ) ? $border : array();
		$shadow     = $this->nav_path( $nav, array( 'decoration', 'boxShadow', 'desktop', 'value' ) );
		$shadow     = is_array( $shadow ) ? $shadow : array();
		$padding    = $this->nav_path( $nav, array( 'decoration', 'spacing', 'desktop', 'value', 'padding' ) );
		$padding    = is_array( $padding ) ? $padding : array();

		$decls = $this->background_decls( $background );
		$text  = $this->paint( $font['color'] ?? '' );
		if ( '' !== $text ) {
			$decls[] = 'color:' . $text;
		}
		if ( isset( $font['size'] ) && is_string( $font['size'] ) && '' !== $font['size'] ) {
			$decls[] = 'font-size:' . sanitize_text_field( $font['size'] );
		}
		if ( isset( $font['weight'] ) && is_string( $font['weight'] ) && '' !== $font['weight'] ) {
			$decls[] = 'font-weight:' . sanitize_text_field( $font['weight'] );
		}
		if ( isset( $font['family'] ) && is_string( $font['family'] ) && '' !== $font['family'] && 'Default' !== $font['family'] ) {
			$family  = sanitize_text_field( $font['family'] );
			$decls[] = 'font-family:"' . str_replace( '"', '', $family ) . '"';
		}
		if ( isset( $font['letterSpacing'] ) && is_string( $font['letterSpacing'] ) && '' !== $font['letterSpacing'] ) {
			$decls[] = 'letter-spacing:' . sanitize_text_field( $font['letterSpacing'] );
		}
		if ( isset( $font['lineHeight'] ) && is_string( $font['lineHeight'] ) && '' !== $font['lineHeight'] ) {
			$decls[] = 'line-height:' . sanitize_text_field( $font['lineHeight'] );
		}

		$styles  = isset( $font['style'] ) && is_array( $font['style'] ) ? $font['style'] : array();
		$decls[] = 'font-style:' . ( in_array( 'italic', $styles, true ) ? 'italic' : 'normal' );
		$deco    = array();
		if ( in_array( 'underline', $styles, true ) ) {
			$deco[] = 'underline';
		}
		if ( in_array( 'overline', $styles, true ) ) {
			$deco[] = 'overline';
		}
		if ( in_array( 'strikethrough', $styles, true ) ) {
			$deco[] = 'line-through';
		}
		if ( array() !== $deco ) {
			$decls[] = 'text-decoration:' . implode( ' ', $deco );
		}

		$caps = isset( $font['capitalization'] ) && is_string( $font['capitalization'] ) ? $font['capitalization'] : '';
		if ( in_array( $caps, array( 'uppercase', 'lowercase', 'capitalize' ), true ) ) {
			$decls[] = 'text-transform:' . $caps;
			$decls[] = 'font-variant-caps:normal';
		} elseif ( 'smallCaps' === $caps ) {
			$decls[] = 'text-transform:none';
			$decls[] = 'font-variant-caps:small-caps';
		} elseif ( 'allSmallCaps' === $caps ) {
			$decls[] = 'text-transform:none';
			$decls[] = 'font-variant-caps:all-small-caps';
		}

		$radius = isset( $border['radius'] ) && is_array( $border['radius'] ) ? $border['radius'] : array();
		if ( array() !== $radius ) {
			$decls[] = sprintf(
				'border-radius:%1$s %2$s %3$s %4$s',
				sanitize_text_field( (string) ( $radius['topLeft'] ?? '0' ) ),
				sanitize_text_field( (string) ( $radius['topRight'] ?? '0' ) ),
				sanitize_text_field( (string) ( $radius['bottomRight'] ?? '0' ) ),
				sanitize_text_field( (string) ( $radius['bottomLeft'] ?? '0' ) )
			);
		}

		$all    = isset( $border['styles']['all'] ) && is_array( $border['styles']['all'] ) ? $border['styles']['all'] : array();
		$width  = sanitize_text_field( (string) ( $all['width'] ?? '' ) );
		$bstyle = sanitize_text_field( (string) ( $all['style'] ?? 'solid' ) );
		$bcolor = $this->paint( $all['color'] ?? '' );
		if ( '' === $width || '0px' === $width || 'none' === $bstyle ) {
			$decls[] = 'border:none';
		} else {
			$decls[] = 'border:' . $width . ' ' . $bstyle . ( '' !== $bcolor ? ' ' . $bcolor : '' );
		}

		if ( isset( $shadow['style'] ) && 'none' !== $shadow['style'] && '' !== (string) $shadow['style'] ) {
			$inset        = ( isset( $shadow['position'] ) && 'inner' === $shadow['position'] ) ? 'inset ' : '';
			$shadow_color = $this->paint( $shadow['color'] ?? '' );
			if ( '' === $shadow_color ) {
				$shadow_color = 'rgba(0,0,0,0.3)';
			}
			$decls[] = 'box-shadow:' . $inset
				. sanitize_text_field( (string) ( $shadow['horizontal'] ?? '0px' ) ) . ' '
				. sanitize_text_field( (string) ( $shadow['vertical'] ?? '0px' ) ) . ' '
				. sanitize_text_field( (string) ( $shadow['blur'] ?? '0px' ) ) . ' '
				. sanitize_text_field( (string) ( $shadow['spread'] ?? '0px' ) ) . ' '
				. $shadow_color;
		}

		if ( array() !== $padding ) {
			$decls[] = sprintf(
				'padding:%1$s %2$s %3$s %4$s',
				sanitize_text_field( (string) ( $padding['top'] ?? '0' ) ),
				sanitize_text_field( (string) ( $padding['right'] ?? '0' ) ),
				sanitize_text_field( (string) ( $padding['bottom'] ?? '0' ) ),
				sanitize_text_field( (string) ( $padding['left'] ?? '0' ) )
			);
		}

		$icon_size = sanitize_text_field( $icon_size );
		if ( '' === $icon_size ) {
			$icon_size = '16px';
		}

		$important = array();
		foreach ( $decls as $decl ) {
			$important[] = false !== strpos( $decl, '!important' ) ? $decl : $decl . '!important';
		}

		$parts        = array_values( array_filter( array_map( 'trim', explode( ',', $selector ) ) ) );
		$icon_parts   = array();
		$after_parts  = array();
		$hover_parts  = array();
		$glyph_parts  = array();
		$always_parts = array();
		foreach ( $parts as $part ) {
			$icon_parts[]   = $part . '::after';
			$icon_parts[]   = $part . '::before';
			$after_parts[]  = $part . '::after';
			$hover_parts[]  = $part . ':hover';
			$hover_parts[]  = $part . ':focus';
			$glyph_parts[]  = $part . ' .dsm-webfont-icon-glyph';
			$always_parts[] = $part . '.dsm-page-tour__btn--icon-always';
		}

		$rule            = $selector . '{' . implode( ';', $important ) . '}';
		$icon_css        = 'font-size:' . $icon_size . '!important';
		$native_icon_css = '';
		if ( $this->nav_icon_flag( $nav, 'enable', false ) ) {
			$native_icon_css = $this->native_icon_pseudo_css( $this->nav_icon_settings( $nav ) );
			if ( '' !== $native_icon_css ) {
				$icon_css .= ';' . $native_icon_css;
			}
		}
		$rule .= implode( ',', $icon_parts ) . '{' . $icon_css . '}';
		if ( '' !== $native_icon_css ) {
			$rule .= implode( ',', $after_parts ) . '{content:attr(data-icon)!important}';
		}
		$rule .= implode( ',', $glyph_parts ) . '{font-size:' . $icon_size . '!important}';

		if ( $this->nav_icon_flag( $nav, 'enable', false ) ) {
			$icon_pad = 'left' === $this->nav_icon_placement( $nav )
				? 'padding-left:2em!important;padding-right:0.7em!important'
				: 'padding-right:2em!important;padding-left:0.7em!important';
			if ( $this->nav_icon_flag( $nav, 'onHover', true ) ) {
				$rule .= implode( ',', $hover_parts ) . '{' . $icon_pad . '}';
			} else {
				$rule .= implode( ',', array_merge( $always_parts, $hover_parts ) ) . '{' . $icon_pad . '}';
			}
		}

		return $rule;
	}

	/**
	 * Background-color / image / gradient declarations.
	 *
	 * @param array<string, mixed> $background Desktop background value.
	 * @return list<string>
	 */
	private function background_decls( array $background ): array {
		$decls = array();
		$color = $this->paint( $background['color'] ?? '' );
		if ( '' !== $color ) {
			$decls[] = 'background-color:' . $color;
		}

		$images   = array();
		$image    = isset( $background['image'] ) && is_array( $background['image'] ) ? $background['image'] : array();
		$image_on = ! isset( $image['enabled'] ) || 'off' !== $image['enabled'];
		$url      = isset( $image['url'] ) && is_string( $image['url'] ) ? esc_url_raw( $image['url'] ) : '';
		if ( $image_on && '' !== $url && 0 !== strpos( strtolower( $url ), 'javascript:' ) ) {
			$images[] = 'url("' . esc_url( $url ) . '")';
		}

		$gradient = isset( $background['gradient'] ) && is_array( $background['gradient'] ) ? $background['gradient'] : array();
		$paint    = $this->gradient_css( $gradient );
		if ( '' !== $paint ) {
			if ( isset( $gradient['overlaysImage'] ) && 'off' === $gradient['overlaysImage'] ) {
				$images[] = $paint;
			} else {
				array_unshift( $images, $paint );
			}
		}

		if ( array() !== $images ) {
			$decls[] = 'background-image:' . implode( ',', $images );
			$repeat  = isset( $image['repeat'] ) && is_string( $image['repeat'] ) ? sanitize_text_field( $image['repeat'] ) : 'no-repeat';
			$size    = isset( $image['size'] ) && is_string( $image['size'] ) ? $image['size'] : 'cover';
			if ( 'contain' === $size ) {
				$size_css = 'contain';
			} elseif ( 'initial' === $size ) {
				$size_css = 'auto';
			} elseif ( 'stretch' === $size ) {
				$size_css = '100% 100%';
			} else {
				$size_css = 'cover';
			}
			$position = isset( $image['position'] ) && is_string( $image['position'] ) ? sanitize_text_field( $image['position'] ) : 'center';
			$decls[]  = 'background-repeat:' . $repeat;
			$decls[]  = 'background-size:' . $size_css;
			$decls[]  = 'background-position:' . $position;
		}

		return $decls;
	}

	/**
	 * Divi-aligned gradient CSS (type, position, repeat, length).
	 *
	 * @param array<string, mixed> $gradient Gradient leaf.
	 * @return string
	 */
	private function gradient_css( array $gradient ): string {
		if ( ! isset( $gradient['enabled'] ) || 'on' !== $gradient['enabled'] ) {
			return '';
		}

		$length = isset( $gradient['length'] ) && is_string( $gradient['length'] ) && '' !== trim( $gradient['length'] )
			? sanitize_text_field( $gradient['length'] )
			: '100%';
		$unit   = false !== strpos( $length, '%' ) ? '%' : (string) preg_replace( '/[\d.\s-]/', '', $length );
		if ( '' === $unit ) {
			$unit = '%';
		}

		$stops    = isset( $gradient['stops'] ) && is_array( $gradient['stops'] ) ? $gradient['stops'] : array();
		$stop_css = array();
		foreach ( $stops as $stop ) {
			if ( ! is_array( $stop ) ) {
				continue;
			}
			$stop_color = $this->paint( $stop['color'] ?? '' );
			if ( '' === $stop_color ) {
				continue;
			}
			$pos        = isset( $stop['position'] ) ? preg_replace( '/[^\d.]/', '', (string) $stop['position'] ) : '';
			$stop_css[] = ( is_string( $pos ) && '' !== $pos ) ? $stop_color . ' ' . $pos . $unit : $stop_color;
		}
		if ( array() === $stop_css ) {
			return '';
		}

		$type_raw  = isset( $gradient['type'] ) && is_string( $gradient['type'] ) ? $gradient['type'] : 'linear';
		$direction = isset( $gradient['direction'] ) && is_string( $gradient['direction'] ) ? sanitize_text_field( $gradient['direction'] ) : '180deg';
		$radial    = isset( $gradient['directionRadial'] ) && is_string( $gradient['directionRadial'] ) ? sanitize_text_field( $gradient['directionRadial'] ) : 'center';

		$kind = 'linear';
		$axis = $direction;
		if ( 'conic' === $type_raw ) {
			$kind = 'conic';
			$axis = 'from ' . $direction . ' at ' . $radial;
		} elseif ( 'elliptical' === $type_raw ) {
			$kind = 'radial';
			$axis = 'ellipse at ' . $radial;
		} elseif ( 'circular' === $type_raw || 'radial' === $type_raw ) {
			$kind = 'radial';
			$axis = 'circle at ' . $radial;
		}

		if ( isset( $gradient['repeat'] ) && 'on' === $gradient['repeat'] ) {
			$kind = 'repeating-' . $kind;
		}

		$last          = (string) end( $stop_css );
		$append_length = ( '' !== $length && ! str_ends_with( $last, ' ' . $length ) ) ? ' ' . $length : '';

		return $kind . '-gradient(' . $axis . ', ' . implode( ', ', $stop_css ) . $append_length . ')';
	}

	/**
	 * Icon payload for the tour engine (data-icon + placement flags).
	 *
	 * @param array<string, mixed> $page Page settings.
	 * @return array<string, mixed>
	 */
	private function build_button_icons( array $page ): array {
		$primary   = is_array( $page['nav_primary'] ?? null ) ? $page['nav_primary'] : array();
		$secondary = is_array( $page['nav_secondary'] ?? null ) ? $page['nav_secondary'] : array();

		return array(
			'primary'            => $this->nav_icon_data_attrs( $primary ),
			'secondary'          => $this->nav_icon_data_attrs( $secondary ),
			'primaryEnabled'     => $this->nav_icon_flag( $primary, 'enable', false ),
			'secondaryEnabled'   => $this->nav_icon_flag( $secondary, 'enable', false ),
			'primaryOnHover'     => $this->nav_icon_flag( $primary, 'onHover', true ),
			'secondaryOnHover'   => $this->nav_icon_flag( $secondary, 'onHover', true ),
			'primaryPlacement'   => $this->nav_icon_placement( $primary ),
			'secondaryPlacement' => $this->nav_icon_placement( $secondary ),
		);
	}

	/**
	 * Read a yes/no icon flag from a nav decoration.
	 *
	 * @param array<string, mixed> $nav                   Button decoration.
	 * @param string               $key                   Icon flag.
	 * @param bool                 $fallback_when_missing Default when missing.
	 * @return bool
	 */
	private function nav_icon_flag( array $nav, string $key, bool $fallback_when_missing ): bool {
		$raw = $this->nav_path( $nav, array( 'decoration', 'button', 'desktop', 'value', 'icon', $key ) );
		if ( ! is_string( $raw ) || '' === $raw ) {
			return $fallback_when_missing;
		}
		return 'off' !== strtolower( $raw );
	}

	/**
	 * Icon placement for a nav button.
	 *
	 * @param array<string, mixed> $nav Button decoration.
	 * @return string
	 */
	private function nav_icon_placement( array $nav ): string {
		$raw = $this->nav_path( $nav, array( 'decoration', 'button', 'desktop', 'value', 'icon', 'placement' ) );
		return ( is_string( $raw ) && 'left' === strtolower( $raw ) ) ? 'left' : 'right';
	}

	/**
	 * Icon picker leaf from a nav decoration.
	 *
	 * @param array<string, mixed> $nav Button decoration.
	 * @return array<string, mixed>
	 */
	private function nav_icon_settings( array $nav ): array {
		$settings = $this->nav_path( $nav, array( 'decoration', 'button', 'desktop', 'value', 'icon', 'settings' ) );
		if ( is_string( $settings ) && '' !== trim( $settings ) ) {
			return array( 'unicode' => $settings );
		}

		return is_array( $settings ) ? $settings : array();
	}

	/**
	 * Enabled nav-button icon leaves for webfont enqueue.
	 *
	 * @param array<string, mixed> $page Page settings.
	 * @return list<array<string, mixed>>
	 */
	private function collect_nav_button_icons( array $page ): array {
		$icons = array();
		foreach ( array( 'nav_primary', 'nav_secondary' ) as $key ) {
			$nav = is_array( $page[ $key ] ?? null ) ? $page[ $key ] : array();
			if ( ! $this->nav_icon_flag( $nav, 'enable', false ) ) {
				continue;
			}
			$settings = $this->nav_icon_settings( $nav );
			if ( array() !== $settings ) {
				$icons[] = $settings;
			}
		}

		return $icons;
	}

	/**
	 * Processed `data-icon` / webfont class for a nav button.
	 *
	 * @param array<string, mixed> $nav Button decoration.
	 * @return array<string, string>
	 */
	private function nav_icon_data_attrs( array $nav ): array {
		if ( ! $this->nav_icon_flag( $nav, 'enable', false ) ) {
			return array();
		}

		$settings = $this->nav_icon_settings( $nav );
		if ( array() === $settings ) {
			return array();
		}

		if (
			class_exists( IconLibraryRegistry::class )
			&& class_exists( IconGlyphRenderer::class )
			&& IconLibraryRegistry::is_dsm_library_icon( $settings )
		) {
			IconLibraryRegistry::enqueue_webfonts_for_icons( array( $settings ) );
			$font_class = IconGlyphRenderer::get_font_class_for_icon( $settings );
			if ( '' !== $font_class ) {
				return array( 'fontClass' => $font_class );
			}
			return array();
		}

		if ( ! class_exists( Utils::class ) ) {
			return array();
		}

		$processed = Utils::process_font_icon( $settings );
		if ( is_string( $processed ) && '' !== $processed ) {
			return array( 'data-icon' => $processed );
		}

		$unicode = isset( $settings['unicode'] ) && is_string( $settings['unicode'] ) ? $settings['unicode'] : '';
		$decoded = $this->decode_native_icon_glyph( $unicode );
		if ( '' !== $decoded ) {
			return array( 'data-icon' => $decoded );
		}

		return array();
	}

	/**
	 * Decode a stored Divi/FA unicode leaf into a single glyph for `data-icon`.
	 *
	 * @param string $unicode Picker unicode (entity, hex, or glyph).
	 * @return string
	 */
	private function decode_native_icon_glyph( string $unicode ): string {
		$raw = trim( $unicode );
		if ( '' === $raw ) {
			return '';
		}

		if ( preg_match( '/&(?:amp;)?#x([0-9a-f]+);/i', $raw, $matches ) ) {
			$entity = html_entity_decode( '&#x' . $matches[1] . ';', ENT_QUOTES, 'UTF-8' );
			return is_string( $entity ) ? $entity : '';
		}

		if ( preg_match( '/&(?:amp;)?#(\d+);/', $raw, $matches ) ) {
			$entity = html_entity_decode( '&#' . $matches[1] . ';', ENT_QUOTES, 'UTF-8' );
			return is_string( $entity ) ? $entity : '';
		}

		if ( preg_match( '/^f[0-9a-f]{2,6}$/i', $raw ) ) {
			$entity = html_entity_decode( '&#x' . $raw . ';', ENT_QUOTES, 'UTF-8' );
			return is_string( $entity ) ? $entity : '';
		}

		if ( function_exists( 'mb_strlen' ) ) {
			return 1 === mb_strlen( $raw, 'UTF-8' ) ? $raw : '';
		}

		return 1 === strlen( $raw ) ? $raw : '';
	}

	/**
	 * Keep Font Awesome / ETmodules on ::after so button text font-weight does not hide the glyph.
	 *
	 * @param array<string, mixed> $settings Icon picker leaf.
	 * @return string
	 */
	private function native_icon_pseudo_css( array $settings ): string {
		if ( array() === $settings ) {
			return '';
		}

		if (
			class_exists( IconLibraryRegistry::class )
			&& IconLibraryRegistry::is_dsm_library_icon( $settings )
		) {
			return '';
		}

		$type  = isset( $settings['type'] ) ? sanitize_key( (string) $settings['type'] ) : '';
		$is_fa = 'fa' === $type || 'fontawesome' === $type;
		if ( class_exists( Utils::class ) && method_exists( Utils::class, 'is_fa_icon' ) ) {
			$is_fa = $is_fa || Utils::is_fa_icon( $settings );
		}

		$family = $is_fa ? 'FontAwesome' : 'ETmodules';

		if (
			class_exists( IconGlyphRenderer::class )
			&& class_exists( IconProcessFontIconBridge::class )
			&& IconProcessFontIconBridge::uses_icon_manager_font_family()
		) {
			$resolved_family = IconGlyphRenderer::icon_manager_font_family( $settings );

			if ( '' !== $resolved_family ) {
				$family = $resolved_family;
			}
		}
		$weight = isset( $settings['weight'] ) ? preg_replace( '/[^0-9]/', '', (string) $settings['weight'] ) : '';
		if ( ! is_string( $weight ) || '' === $weight ) {
			$weight = $is_fa ? '900' : '400';
		}

		return 'font-family:"' . $family . '"!important;font-weight:' . $weight . '!important;font-style:normal!important';
	}

	/**
	 * Inner desktop string.
	 *
	 * @param array<string, mixed> $attrs Attrs.
	 * @param string               $key Key.
	 * @return string
	 */
	private function inner_desktop_string( array $attrs, string $key ): string {
		$raw = $attrs[ $key ]['innerContent']['desktop']['value'] ?? '';
		return $this->leaf_text( $raw );
	}

	/**
	 * Inner desktop heading text.
	 *
	 * @param array<string, mixed> $attrs Attrs.
	 * @param string               $key Key.
	 * @return string
	 */
	private function inner_desktop_heading_text( array $attrs, string $key ): string {
		$raw = $this->inner_desktop_string( $attrs, $key );
		if ( '' === $raw ) {
			return '';
		}

		$resolved = $this->resolve_dynamic_plain( $raw, $attrs );
		if ( '' === $resolved || false !== strpos( $resolved, '$variable(' ) ) {
			return '';
		}

		return wp_kses_post( $resolved );
	}

	/**
	 * Resolve dynamic plain.
	 *
	 * @param string               $value Value.
	 * @param array<string, mixed> $attrs Attrs.
	 * @return string
	 */
	private function resolve_dynamic_plain( string $value, array $attrs = array() ): string {
		if ( '' === $value || false === strpos( $value, '$variable(' ) ) {
			return $value;
		}

		if (
			class_exists( LoopUtils::class ) &&
			class_exists( LoopContext::class ) &&
			null !== LoopContext::get() &&
			array() !== $attrs
		) {
			$looped = LoopUtils::process_dynamic_content( $value, $attrs );
			return $this->filter_resolved_dynamic_text( is_string( $looped ) ? $looped : $value, $value, $attrs );
		}

		if ( ! class_exists( DynamicData::class ) ) {
			return $this->filter_resolved_dynamic_text( $value, $value, $attrs );
		}

		$loop_post_id = isset( $attrs['__loop_post_id'] ) ? absint( $attrs['__loop_post_id'] ) : 0;
		$post_id      = $loop_post_id > 0 ? $loop_post_id : (int) get_the_ID();
		$resolved     = DynamicData::get_processed_dynamic_data(
			$value,
			$post_id > 0 ? $post_id : null
		);
		$text         = null !== $resolved ? (string) $resolved : $value;

		return $this->filter_resolved_dynamic_text( $text, $value, $attrs );
	}

	/**
	 * Filter resolved dynamic text.
	 *
	 * @param string               $text  Text.
	 * @param string               $value Value.
	 * @param array<string, mixed> $attrs Attrs.
	 * @return string
	 */
	private function filter_resolved_dynamic_text( string $text, string $value, array $attrs ): string {
		/**
		 * Filters resolved Page Tour title, content, or tour name.
		 *
		 * @param string               $text  Resolved text.
		 * @param string               $value Original stored value.
		 * @param array<string, mixed> $attrs Module attrs.
		 */
		return (string) apply_filters( 'dsm_page_tour_resolve_dynamic_text', $text, $value, $attrs );
	}

	/**
	 * Leaf text.
	 *
	 * @param mixed $leaf Leaf.
	 * @return string
	 */
	private function leaf_text( $leaf ): string {
		if ( is_string( $leaf ) ) {
			return trim( $leaf );
		}

		if ( is_array( $leaf ) && isset( $leaf['text'] ) && is_scalar( $leaf['text'] ) ) {
			return trim( (string) $leaf['text'] );
		}

		if ( is_scalar( $leaf ) ) {
			return trim( (string) $leaf );
		}

		return '';
	}

	/**
	 * CSS paint from attr value.
	 *
	 * @param mixed $value Value.
	 * @return string
	 */
	private function css_paint_from_attr_value( $value ): string {
		if ( is_string( $value ) ) {
			return trim( $value );
		}

		if ( is_array( $value ) ) {
			if ( isset( $value['hex'] ) && is_string( $value['hex'] ) ) {
				return trim( $value['hex'] );
			}
			if ( isset( $value['desktop']['value'] ) ) {
				return $this->css_paint_from_attr_value( $value['desktop']['value'] );
			}
		}

		return '';
	}

	/**
	 * Sanitize CSS color.
	 *
	 * @param string $raw      Raw.
	 * @param string $fallback Fallback.
	 * @return string
	 */
	private function sanitize_css_color( string $raw, string $fallback ): string {
		$raw = trim( $raw );
		if ( '' === $raw ) {
			return $fallback;
		}

		if ( 1 === preg_match( '/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/', $raw ) ) {
			return $raw;
		}

		if ( 1 === preg_match( '/^rgba?\(\s*[\d.]+\s*,\s*[\d.]+\s*,\s*[\d.]+(?:\s*,\s*[\d.]+)?\s*\)$/', $raw ) ) {
			return $raw;
		}

		return $fallback;
	}

	/**
	 * Re-sanitize tour identity fields after the footer payload filter.
	 *
	 * @param array<string, mixed> $payload Footer JSON.
	 * @return array<string, mixed>
	 */
	private function sanitize_footer_payload_identity( array $payload ): array {
		if ( ! isset( $payload['tours'] ) || ! is_array( $payload['tours'] ) ) {
			return $payload;
		}

		foreach ( $payload['tours'] as $index => $tour ) {
			if ( ! is_array( $tour ) ) {
				continue;
			}

			if ( isset( $tour['name'] ) && is_scalar( $tour['name'] ) ) {
				$payload['tours'][ $index ]['name'] = sanitize_text_field( (string) $tour['name'] );
			}

			if ( isset( $tour['storeId'] ) && is_scalar( $tour['storeId'] ) ) {
				$payload['tours'][ $index ]['storeId'] = sanitize_text_field( (string) $tour['storeId'] );
			}
		}

		return $payload;
	}

	/**
	 * Encode JSON for embedding inside a `<script>` tag.
	 *
	 * HEX flags prevent a literal `</script>` in a string field from closing the tag.
	 * `JSON.parse` still restores kses'd HTML in title/body.
	 *
	 * @param mixed $data Payload.
	 * @return string|false
	 */
	private function encode_script_json( $data ) {
		return wp_json_encode(
			$data,
			JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT
		);
	}

	/**
	 * Sanitize CSS selector.
	 *
	 * @param string $raw Raw.
	 * @return string
	 */
	private function sanitize_css_selector( string $raw ): string {
		$raw = trim( $raw );
		if ( '' === $raw || strlen( $raw ) > 300 ) {
			return '';
		}

		if ( 1 !== preg_match( '/^[A-Za-z0-9_\-#\.\[\]="\'\s>+~:(),]+$/', $raw ) ) {
			return '';
		}

		return $raw;
	}

	/**
	 * Sanitize tippy animation.
	 *
	 * @param string $animation Animation.
	 * @return string
	 */
	private function sanitize_tippy_animation( string $animation ): string {
		return in_array( $animation, self::TIPPY_ANIMATION_ALLOWLIST, true ) ? $animation : 'fade';
	}

	/**
	 * Tippy v6 duration in milliseconds (show or hide).
	 *
	 * @param string $raw      Stored range value (`300ms` or `300`).
	 * @param int    $fallback Tippy default when invalid.
	 * @return int
	 */
	private function sanitize_tippy_duration_ms( string $raw, int $fallback ): int {
		if ( 1 !== preg_match( '/^(-?\d+(?:\.\d+)?)(ms|s)?$/i', trim( $raw ), $match ) ) {
			return $fallback;
		}

		$value = (float) $match[1];
		if ( $value < 0 ) {
			return $fallback;
		}
		if ( isset( $match[2] ) && 's' === strtolower( $match[2] ) ) {
			$value *= 1000;
		}

		return min( 2000, (int) round( $value ) );
	}

	/**
	 * Stored Move Transition slug for settings / REST.
	 *
	 * @param string $raw Slug.
	 * @return string
	 */
	private function sanitize_tippy_move_transition_slug( string $raw ): string {
		$slug = sanitize_key( $raw );
		if ( in_array( $slug, array( 'none', 'ease-out', 'ease', 'linear' ), true ) ) {
			return $slug;
		}

		return 'none';
	}

	/**
	 * Tippy `moveTransition` CSS (empty string is Tippy’s default).
	 *
	 * @param string $raw Stored slug.
	 * @return string
	 */
	private function sanitize_tippy_move_transition( string $raw ): string {
		$slug = $this->sanitize_tippy_move_transition_slug( $raw );
		$map  = array(
			'none'     => '',
			'ease-out' => 'transform 0.2s ease-out',
			'ease'     => 'transform 0.3s ease',
			'linear'   => 'transform 0.2s linear',
		);

		return $map[ $slug ] ?? '';
	}

	/**
	 * Normalize in view offset.
	 *
	 * @param string $raw Raw.
	 * @return int
	 */
	private function normalize_in_view_offset( string $raw ): int {
		$num = (int) preg_replace( '/\D+/', '', $raw );
		if ( $num < 0 ) {
			return 0;
		}
		if ( $num > 100 ) {
			return 100;
		}

		return $num;
	}

	/**
	 * Inject wrapper attributes.
	 *
	 * @param string                $html Html.
	 * @param array<string, string> $attributes Attributes.
	 * @return string
	 */
	private function inject_wrapper_attributes( string $html, array $attributes ): string {
		if ( '' === $html || array() === $attributes ) {
			return $html;
		}

		$attr_html = '';
		foreach ( $attributes as $name => $value ) {
			if ( '' === $value ) {
				continue;
			}
			$attr_html .= ' ' . esc_attr( $name ) . '="' . esc_attr( $value ) . '"';
		}

		// Callback — never interpolate `$attr_html` as a preg replacement.
		// A replacement string would treat `$99` / `$10` in JSON attrs as
		// backreferences and strip the dollar.
		$updated = preg_replace_callback(
			'/^(<[a-zA-Z][a-zA-Z0-9]*)(\s|>)/',
			static function ( array $matches ) use ( $attr_html ): string {
				return $matches[1] . $attr_html . $matches[2];
			},
			$html,
			1
		);

		return is_string( $updated ) ? $updated : $html;
	}
}

$GLOBALS['dsm_page_tour_extension'] = new PageTour();
