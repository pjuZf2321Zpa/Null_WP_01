<?php
/**
 * Contact Form Pro — store native Divi Contact Form submissions.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Extensions;

use DiviSupreme\Modules\ContactFormField;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Soft-extends Divi's native Contact Form via `et_pb_contact_form_submit`.
 *
 * Opt-in under Divi Supreme → Extensions → Contact Form Pro.
 */
class ContactFormEntries {

	/**
	 * CPT slug.
	 */
	public const POST_TYPE = 'dsm_cf_entry';

	/**
	 * Settings option group / dashboard section id.
	 */
	public const OPTION_SECTION = 'dsm_settings_contact_form_pro';

	/**
	 * Meta: processed fields array.
	 */
	public const META_FIELDS = '_dsm_cf_fields';

	/**
	 * Meta: contact form HTML id.
	 */
	public const META_FORM_ID = '_dsm_cf_form_id';

	/**
	 * Meta: Divi unique id.
	 */
	public const META_FORM_UNIQUE_ID = '_dsm_cf_form_unique_id';

	/**
	 * Meta: source post id.
	 */
	public const META_SOURCE_POST_ID = '_dsm_cf_source_post_id';

	/**
	 * Meta: entry status (`new`|`read`|`spam`).
	 */
	public const META_STATUS = '_dsm_cf_status';

	/**
	 * Meta: submitter email (indexed column helper).
	 */
	public const META_EMAIL = '_dsm_cf_email';

	/**
	 * Meta: submitter name (indexed column helper).
	 */
	public const META_NAME = '_dsm_cf_name';

	/**
	 * Meta: starred flag (`1` when starred).
	 */
	public const META_STARRED = '_dsm_cf_starred';

	/**
	 * Meta: spam reason (`honeypot`|`turnstile`|`hcaptcha`|`blacklist`|manual).
	 */
	public const META_SPAM_REASON = '_dsm_cf_spam_reason';

	/**
	 * Honeypot POST field name.
	 */
	public const HONEYPOT_FIELD = 'dsm_cf_hp';

	/**
	 * Capability required for admin UI / export.
	 */
	public const CAPABILITY = 'manage_options';

	/**
	 * Spam reasons that must block Divi's admin notification email after the entry is stored.
	 *
	 * @var list<string>
	 */
	private const HARD_BLOCK_EMAIL_SPAM_REASONS = array( 'honeypot', 'turnstile', 'hcaptcha' );

	/**
	 * Whether the next `wp_mail` from Divi's Contact Form should be short-circuited.
	 *
	 * @var bool
	 */
	private static $block_divi_admin_email = false;

	/**
	 * Constructor.
	 */
	public function __construct() {
		\add_action( 'init', array( $this, 'register_post_type' ) );
		\add_action( 'et_pb_contact_form_submit', array( $this, 'maybe_store_submission' ), 10, 3 );
		\add_filter( 'render_block', array( $this, 'inject_honeypot_into_contact_form_block' ), 20, 2 );

		$this->boot_services();

		if ( \is_admin() ) {
			\add_action( 'admin_menu', array( $this, 'register_admin_menu' ), 100 );
			\add_filter( 'manage_' . self::POST_TYPE . '_posts_columns', array( $this, 'list_columns' ) );
			\add_action( 'manage_' . self::POST_TYPE . '_posts_custom_column', array( $this, 'render_list_column' ), 10, 2 );
			\add_filter( 'post_row_actions', array( $this, 'row_actions' ), 10, 2 );
			\add_filter( 'bulk_actions-edit-' . self::POST_TYPE, array( $this, 'bulk_actions' ) );
			\add_filter( 'handle_bulk_actions-edit-' . self::POST_TYPE, array( $this, 'handle_bulk_actions' ), 10, 3 );
			\add_filter( 'views_edit-' . self::POST_TYPE, array( $this, 'list_views' ) );
			\add_action( 'add_meta_boxes_' . self::POST_TYPE, array( $this, 'register_meta_boxes' ) );
			\add_action( 'load-post.php', array( $this, 'maybe_mark_entry_read' ) );
			\add_action( 'restrict_manage_posts', array( $this, 'render_list_filters' ) );
			\add_action( 'pre_get_posts', array( $this, 'filter_list_query' ) );
			\add_action( 'admin_post_dsm_export_cf_entries', array( $this, 'handle_csv_export' ) );
			\add_action( 'admin_post_dsm_cf_entry_action', array( $this, 'handle_row_action' ) );
			\add_action( 'admin_notices', array( $this, 'maybe_render_list_notice' ) );
			\add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_assets' ) );
		}
	}

	/**
	 * Status badge styles on entry list / edit screens.
	 *
	 * @param string $hook_suffix Current admin page hook.
	 * @return void
	 */
	public function enqueue_admin_assets( string $hook_suffix ): void {
		unset( $hook_suffix );

		$screen = \function_exists( 'get_current_screen' ) ? \get_current_screen() : null;
		if ( ! $screen || self::POST_TYPE !== $screen->post_type ) {
			return;
		}

		$version = \defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';
		\wp_register_style( 'dsm-cf-entries-admin', false, array(), $version );
		\wp_enqueue_style( 'dsm-cf-entries-admin' );
		\wp_add_inline_style(
			'dsm-cf-entries-admin',
			'.dsm-cf-status-badge{display:inline-block;padding:2px 8px;border-radius:999px;font-size:12px;font-weight:600;line-height:1.6;letter-spacing:0.01em;}'
			. '.dsm-cf-status-badge--new{color:#0a4b78;background:#e5f3ff;}'
			. '.dsm-cf-status-badge--read{color:#2c3338;background:#f0f0f1;}'
			. '.dsm-cf-status-badge--spam{color:#8a2424;background:#fcf0f1;}'
			. '.dsm-cf-status-badge--failed{color:#8a6116;background:#fcf9e8;}'
			. '.column-dsm_status{width:7em;}'
		);
	}

	/**
	 * Boot autoresponder, retention, and webhook services.
	 *
	 * @return void
	 */
	private function boot_services(): void {
		$dir = __DIR__ . '/ContactFormEntries';

		$files = array(
			$dir . '/Autoresponder.php',
			$dir . '/Retention.php',
			$dir . '/Webhook.php',
			$dir . '/Turnstile.php',
			$dir . '/Hcaptcha.php',
			$dir . '/FileUpload.php',
			$dir . '/ContactFormFields.php',
			$dir . '/SubmitLoader.php',
		);

		foreach ( $files as $file ) {
			if ( \is_readable( $file ) ) {
				require_once $file;
			}
		}

		if ( \class_exists( ContactFormEntries\Autoresponder::class ) ) {
			new ContactFormEntries\Autoresponder();
		}
		if ( \class_exists( ContactFormEntries\Retention::class ) ) {
			new ContactFormEntries\Retention();
		}
		if ( \class_exists( ContactFormEntries\Webhook::class ) ) {
			new ContactFormEntries\Webhook();
		}
		if ( \class_exists( ContactFormEntries\Turnstile::class ) ) {
			new ContactFormEntries\Turnstile();
		}
		if ( \class_exists( ContactFormEntries\Hcaptcha::class ) ) {
			new ContactFormEntries\Hcaptcha();
		}
		if ( \class_exists( ContactFormEntries\FileUpload::class ) ) {
			new ContactFormEntries\FileUpload();
		}
		if ( \class_exists( ContactFormEntries\ContactFormFields::class ) ) {
			new ContactFormEntries\ContactFormFields();
		}
		if ( \class_exists( ContactFormEntries\SubmitLoader::class ) ) {
			new ContactFormEntries\SubmitLoader();
		}
	}

	/**
	 * Read inherit|on|off mode from a Contact Form block attribute.
	 *
	 * @param array<string, mixed> $block     Parsed block.
	 * @param string               $attr_name Root attr name (e.g. dsm_cf_honeypot).
	 * @return string
	 */
	public static function get_block_mode_attr( array $block, string $attr_name ): string {
		$attrs = isset( $block['attrs'] ) && \is_array( $block['attrs'] ) ? $block['attrs'] : array();
		$value = '';

		if ( isset( $attrs[ $attr_name ]['innerContent']['desktop']['value'] ) ) {
			$value = (string) $attrs[ $attr_name ]['innerContent']['desktop']['value'];
		} elseif ( isset( $attrs[ $attr_name ]['desktop']['value'] ) ) {
			$value = (string) $attrs[ $attr_name ]['desktop']['value'];
		} elseif ( isset( $attrs[ $attr_name ] ) && \is_string( $attrs[ $attr_name ] ) ) {
			$value = $attrs[ $attr_name ];
		}

		$value = \sanitize_key( $value );

		return \in_array( $value, array( 'inherit', 'on', 'off' ), true ) ? $value : 'inherit';
	}

	/**
	 * Whether honeypot should run for this Contact Form block.
	 *
	 * @param array<string, mixed> $block Parsed block.
	 * @return bool
	 */
	public static function is_honeypot_enabled_for_block( array $block ): bool {
		$mode = self::get_block_mode_attr( $block, 'dsm_cf_honeypot' );
		if ( 'on' === $mode ) {
			return true;
		}
		if ( 'off' === $mode ) {
			return false;
		}

		return self::is_honeypot_enabled();
	}

	/**
	 * Read a Contact Form Pro settings value.
	 *
	 * @param string $key           Option key.
	 * @param string $default_value Default when unset.
	 * @return string
	 */
	public static function get_setting( string $key, string $default_value = '' ): string {
		$options = \get_option( self::OPTION_SECTION, array() );
		if ( ! \is_array( $options ) || ! \array_key_exists( $key, $options ) ) {
			return $default_value;
		}

		$value = $options[ $key ];
		if ( \is_bool( $value ) ) {
			return $value ? 'on' : 'off';
		}
		if ( \is_scalar( $value ) ) {
			return (string) $value;
		}

		return $default_value;
	}

	/**
	 * Whether honeypot injection is enabled in settings.
	 *
	 * @return bool
	 */
	public static function is_honeypot_enabled(): bool {
		if ( ! \array_key_exists( 'dsm_cf_honeypot', (array) \get_option( self::OPTION_SECTION, array() ) ) ) {
			return true;
		}

		return 'on' === self::get_setting( 'dsm_cf_honeypot', 'on' );
	}

	/**
	 * Sanitize retention days (1–3650).
	 *
	 * @param mixed $value Raw value.
	 * @return int
	 */
	public static function sanitize_retention_days( $value ): int {
		$days = \absint( $value );
		if ( $days < 1 ) {
			return 90;
		}
		if ( $days > 3650 ) {
			return 3650;
		}

		return $days;
	}

	/**
	 * Sanitize retention days for Settings API (string storage).
	 *
	 * @param mixed $value Raw value.
	 * @return string
	 */
	public static function sanitize_retention_days_option( $value ): string {
		return (string) self::sanitize_retention_days( $value );
	}

	/**
	 * Sanitize webhook URL (HTTPS/HTTP only; reject private/internal targets).
	 *
	 * @param mixed $value Raw value.
	 * @return string
	 */
	public static function sanitize_webhook_url( $value ): string {
		if ( ! \is_string( $value ) ) {
			return '';
		}

		$url = \esc_url_raw( \trim( $value ), array( 'http', 'https' ) );
		if ( ! \is_string( $url ) || '' === $url ) {
			return '';
		}

		// Block loopback / private / link-local targets (SSRF).
		if ( \function_exists( 'wp_http_validate_url' ) && false === \wp_http_validate_url( $url ) ) {
			return '';
		}

		return $url;
	}

	/**
	 * Sanitize autoresponder message (textarea).
	 *
	 * @param mixed $value Raw value.
	 * @return string
	 */
	public static function sanitize_autoresponder_message( $value ): string {
		if ( ! \is_string( $value ) ) {
			return '';
		}

		return \sanitize_textarea_field( $value );
	}

	/**
	 * Default autoresponder body for settings + sends.
	 *
	 * @return string
	 */
	public static function default_autoresponder_message(): string {
		if ( \class_exists( ContactFormEntries\Autoresponder::class ) ) {
			return ContactFormEntries\Autoresponder::default_message();
		}

		return \implode(
			"\n",
			array(
				__( 'Hi {{name}},', 'dsm-supreme-modules-pro-for-divi' ),
				'',
				__( 'Thanks for contacting {{site_name}}. We received your message and will get back to you soon.', 'dsm-supreme-modules-pro-for-divi' ),
				'',
				__( 'Your submission:', 'dsm-supreme-modules-pro-for-divi' ),
				'{{fields}}',
				'',
				'{{site_url}}',
			)
		);
	}

	/**
	 * Keep stored captcha keys when the dashboard posts a masked value.
	 *
	 * Mirrors license-key UX: display shows a leading segment + asterisks; re-saving
	 * without editing must not overwrite the real secret.
	 *
	 * @param array<string, mixed> $merged Posted/merged options.
	 * @return array<string, mixed>
	 */
	public static function normalize_options_after_save( array $merged ): array {
		$stored = \get_option( self::OPTION_SECTION, array() );
		if ( ! \is_array( $stored ) ) {
			$stored = array();
		}

		$secret_keys = array(
			'dsm_cf_turnstile_site_key',
			'dsm_cf_turnstile_secret_key',
			'dsm_cf_hcaptcha_site_key',
			'dsm_cf_hcaptcha_secret_key',
			'dsm_cf_webhook_secret',
		);

		foreach ( $secret_keys as $key ) {
			$posted = isset( $merged[ $key ] ) ? (string) $merged[ $key ] : '';
			$old    = isset( $stored[ $key ] ) ? (string) $stored[ $key ] : '';

			if ( '' === $posted ) {
				continue;
			}

			// Unchanged raw value, or masked display (contains * / •).
			if (
				$posted === $old
				|| false !== \strpos( $posted, '*' )
				|| false !== \strpos( $posted, '•' )
			) {
				$merged[ $key ] = $old;
			}
		}

		return $merged;
	}

	/**
	 * Sanitize a newline-separated list option.
	 *
	 * @param mixed $value Raw value.
	 * @return string
	 */
	public static function sanitize_list_option( $value ): string {
		if ( ! \is_string( $value ) ) {
			return '';
		}

		$lines = \preg_split( '/\r\n|\r|\n/', $value );
		if ( ! \is_array( $lines ) ) {
			return '';
		}

		$out = array();
		foreach ( $lines as $line ) {
			$line = \trim( \sanitize_text_field( $line ) );
			if ( '' === $line || 0 === \strpos( $line, '#' ) ) {
				continue;
			}
			$out[] = $line;
		}

		return \implode( "\n", \array_values( \array_unique( $out ) ) );
	}

	/**
	 * Parsed blacklist lines for a settings key.
	 *
	 * @param string $option_key Option key under OPTION_SECTION.
	 * @return array<int, string>
	 */
	public static function get_blacklist_lines( string $option_key ): array {
		$options = \get_option( self::OPTION_SECTION, array() );
		if ( ! \is_array( $options ) ) {
			return array();
		}

		$raw = isset( $options[ $option_key ] ) ? (string) $options[ $option_key ] : '';
		if ( '' === \trim( $raw ) ) {
			return array();
		}

		$lines = \preg_split( '/\r\n|\r|\n/', $raw );
		if ( ! \is_array( $lines ) ) {
			return array();
		}

		$out = array();
		foreach ( $lines as $line ) {
			$line = \strtolower( \trim( $line ) );
			if ( '' === $line || 0 === \strpos( $line, '#' ) ) {
				continue;
			}
			$out[] = $line;
		}

		return $out;
	}

	/**
	 * Register private CPT for entries (submenu added separately).
	 *
	 * @return void
	 */
	public function register_post_type(): void {
		$labels = array(
			'name'               => __( 'Form Entries', 'dsm-supreme-modules-pro-for-divi' ),
			'singular_name'      => __( 'Form Entry', 'dsm-supreme-modules-pro-for-divi' ),
			'menu_name'          => __( 'Form Entries', 'dsm-supreme-modules-pro-for-divi' ),
			'all_items'          => __( 'Form Entries', 'dsm-supreme-modules-pro-for-divi' ),
			'view_item'          => __( 'View Entry', 'dsm-supreme-modules-pro-for-divi' ),
			'search_items'       => __( 'Search Entries', 'dsm-supreme-modules-pro-for-divi' ),
			'not_found'          => __( 'No entries found.', 'dsm-supreme-modules-pro-for-divi' ),
			'not_found_in_trash' => __( 'No entries found in Trash.', 'dsm-supreme-modules-pro-for-divi' ),
		);

		\register_post_type(
			self::POST_TYPE,
			array(
				'labels'              => $labels,
				'public'              => false,
				'publicly_queryable'  => false,
				'show_ui'             => true,
				'show_in_menu'        => false,
				'show_in_admin_bar'   => false,
				'show_in_rest'        => false,
				'exclude_from_search' => true,
				'has_archive'         => false,
				'rewrite'             => false,
				'query_var'           => false,
				'capability_type'     => 'post',
				'map_meta_cap'        => false,
				'capabilities'        => array(
					'edit_post'           => self::CAPABILITY,
					'read_post'           => self::CAPABILITY,
					'delete_post'         => self::CAPABILITY,
					'edit_posts'          => self::CAPABILITY,
					'edit_others_posts'   => self::CAPABILITY,
					'delete_posts'        => self::CAPABILITY,
					'delete_others_posts' => self::CAPABILITY,
					'read_private_posts'  => self::CAPABILITY,
					'publish_posts'       => self::CAPABILITY,
					'create_posts'        => 'do_not_allow',
				),
				'supports'            => array( 'title' ),
			)
		);
	}

	/**
	 * Add entries list under Divi Supreme settings menu.
	 *
	 * @return void
	 */
	public function register_admin_menu(): void {
		if ( ! \current_user_can( self::CAPABILITY ) ) {
			return;
		}

		\add_submenu_page(
			'divi_supreme_settings',
			__( 'Form Entries', 'dsm-supreme-modules-pro-for-divi' ),
			__( 'Form Entries', 'dsm-supreme-modules-pro-for-divi' ),
			self::CAPABILITY,
			'edit.php?post_type=' . self::POST_TYPE
		);
	}

	/**
	 * Inject honeypot into rendered Divi Contact Form blocks.
	 *
	 * @param string               $block_content Block HTML.
	 * @param array<string, mixed> $block         Parsed block.
	 * @return string
	 */
	public function inject_honeypot_into_contact_form_block( string $block_content, array $block ): string {
		$block_name = isset( $block['blockName'] ) ? (string) $block['blockName'] : '';
		if ( 'divi/contact-form' !== $block_name || '' === $block_content ) {
			return $block_content;
		}

		if ( ! self::is_honeypot_enabled_for_block( $block ) ) {
			return $block_content;
		}

		if ( false !== \strpos( $block_content, 'name="' . self::HONEYPOT_FIELD . '"' ) ) {
			return $block_content;
		}

		$honeypot = \sprintf(
			'<p class="dsm-cf-honeypot" aria-hidden="true" style="position:absolute;left:-9999px;top:auto;width:1px;height:1px;overflow:hidden;">'
			. '<label for="%1$s">%2$s</label>'
			. '<input type="text" name="%1$s" id="%1$s" value="" tabindex="-1" autocomplete="off" />'
			. '</p>',
			\esc_attr( self::HONEYPOT_FIELD ),
			\esc_html__( 'Leave this field empty', 'dsm-supreme-modules-pro-for-divi' )
		);

		if ( false !== \stripos( $block_content, '</form>' ) ) {
			return (string) \preg_replace( '/<\/form>/i', $honeypot . '</form>', $block_content, 1 );
		}

		return $block_content;
	}

	/**
	 * Persist a successful Divi Contact Form submission.
	 *
	 * @param array<string, mixed> $fields            Processed fields from Divi.
	 * @param bool                 $et_contact_error  Whether Divi reported errors.
	 * @param array<string, mixed> $contact_form_info Form metadata from Divi.
	 * @return void
	 */
	public function maybe_store_submission( $fields, $et_contact_error, $contact_form_info ): void {
		if ( true === (bool) $et_contact_error ) {
			return;
		}

		if ( ! \is_array( $fields ) ) {
			$fields = array();
		}

		if ( ! \is_array( $contact_form_info ) ) {
			$contact_form_info = array();
		}

		/**
		 * Filters processed Contact Form fields before entry storage.
		 *
		 * Used to merge Supreme Contact Field (`dsm/contact-form-field`) values.
		 *
		 * @param array<string, mixed> $fields            Processed fields.
		 * @param array<string, mixed> $contact_form_info Form info.
		 */
		$fields = \apply_filters( 'dsm_contact_form_entries_fields', $fields, $contact_form_info );
		if ( ! \is_array( $fields ) || array() === $fields ) {
			return;
		}

		/**
		 * Whether to store this Contact Form submission.
		 *
		 * @param bool                 $should_store      Default true when no Divi errors.
		 * @param array<string, mixed> $fields            Processed fields.
		 * @param array<string, mixed> $contact_form_info Form info.
		 */
		$should_store = (bool) \apply_filters( 'dsm_contact_form_entries_should_store', true, $fields, $contact_form_info );
		if ( ! $should_store ) {
			return;
		}

		$name  = $this->extract_field_value( $fields, 'name' );
		$email = $this->extract_submitter_email( $fields );

		$spam_reason = '';
		if ( $this->is_honeypot_triggered() ) {
			// Field only exists when honeypot was injected for this form.
			$status      = 'spam';
			$spam_reason = 'honeypot';
		} elseif ( $this->is_turnstile_active_on_request() && ! ContactFormEntries\Turnstile::verify_request() ) {
			$status      = 'spam';
			$spam_reason = 'turnstile';
		} elseif ( $this->is_hcaptcha_active_on_request() && ! ContactFormEntries\Hcaptcha::verify_request() ) {
			$status      = 'spam';
			$spam_reason = 'hcaptcha';
		} elseif ( $this->is_blacklisted_submission( $fields, $email ) ) {
			$status      = 'spam';
			$spam_reason = 'blacklist';
		} else {
			$status = 'new';
		}

		$when  = \function_exists( 'wp_date' ) ? \wp_date( 'Y-m-d H:i' ) : \gmdate( 'Y-m-d H:i' );
		$title = '' !== $name
			? \sprintf(
				/* translators: 1: submitter name, 2: datetime */
				__( 'From %1$s — %2$s', 'dsm-supreme-modules-pro-for-divi' ),
				$name,
				$when
			)
			: \sprintf(
				/* translators: %s: datetime */
				__( 'Contact form entry — %s', 'dsm-supreme-modules-pro-for-divi' ),
				$when
			);

		$post_args = array(
			'post_type'   => self::POST_TYPE,
			'post_status' => 'private',
			'post_title'  => \sanitize_text_field( $title ),
			'post_author' => 0,
		);

		/**
		 * Filters args passed to wp_insert_post for a Contact Form entry.
		 *
		 * @param array<string, mixed> $post_args         Insert args.
		 * @param array<string, mixed> $fields            Processed fields.
		 * @param array<string, mixed> $contact_form_info Form info.
		 */
		$post_args = \apply_filters( 'dsm_contact_form_entry_post_args', $post_args, $fields, $contact_form_info );
		if ( ! \is_array( $post_args ) ) {
			return;
		}

		$entry_id = \wp_insert_post( $post_args, true );
		if ( \is_wp_error( $entry_id ) || ! $entry_id ) {
			return;
		}

		$entry_id = (int) $entry_id;

		\update_post_meta( $entry_id, self::META_FIELDS, $this->sanitize_fields_for_storage( $fields ) );
		\update_post_meta(
			$entry_id,
			self::META_FORM_ID,
			\sanitize_text_field( (string) ( $contact_form_info['contact_form_id'] ?? '' ) )
		);
		\update_post_meta(
			$entry_id,
			self::META_FORM_UNIQUE_ID,
			\sanitize_text_field( (string) ( $contact_form_info['contact_form_unique_id'] ?? '' ) )
		);
		\update_post_meta(
			$entry_id,
			self::META_SOURCE_POST_ID,
			\absint( $contact_form_info['post_id'] ?? 0 )
		);
		\update_post_meta( $entry_id, self::META_STATUS, $status );
		\update_post_meta( $entry_id, self::META_EMAIL, \sanitize_email( $email ) );
		\update_post_meta( $entry_id, self::META_NAME, \sanitize_text_field( $name ) );
		\update_post_meta( $entry_id, self::META_STARRED, '0' );
		if ( '' !== $spam_reason ) {
			\update_post_meta( $entry_id, self::META_SPAM_REASON, \sanitize_key( $spam_reason ) );
		} else {
			\delete_post_meta( $entry_id, self::META_SPAM_REASON );
		}

		/**
		 * Fires after a Contact Form entry is stored.
		 *
		 * @param int                  $entry_id          Entry post ID.
		 * @param array<string, mixed> $fields            Processed fields.
		 * @param array<string, mixed> $contact_form_info Form info.
		 */
		\do_action( 'dsm_contact_form_entry_stored', $entry_id, $fields, $contact_form_info );

		// Store spam first, then hard-block Divi admin mail (D5 sends after this action).
		if ( \in_array( $spam_reason, self::HARD_BLOCK_EMAIL_SPAM_REASONS, true ) ) {
			self::arm_block_divi_admin_email();
		}
	}

	/**
	 * Whether Divi's next Contact Form admin notification is armed to be blocked.
	 *
	 * Used so Supreme field email-merge does not leave a dangling `wp_mail` filter when
	 * `pre_wp_mail` short-circuits the send.
	 *
	 * @return bool
	 */
	public static function is_blocking_divi_admin_email(): bool {
		return self::$block_divi_admin_email;
	}

	/**
	 * Arm a one-shot `pre_wp_mail` short-circuit for Divi's Contact Form notification.
	 *
	 * Divi 5 `ContactFormHandler` fires `et_pb_contact_form_submit` before `wp_mail` and
	 * treats a false `wp_mail` return as a send failure (not a success message). There is no
	 * public filter to add a WP_Error on that handler without also skipping entry storage.
	 *
	 * Also used when Supreme Contact Field server-side validation fails so forged/JS-off
	 * invalid submits do not send the admin notification as a success.
	 *
	 * @return void
	 */
	public static function arm_block_divi_admin_email(): void {
		self::$block_divi_admin_email = true;
		if ( ! \has_filter( 'pre_wp_mail', array( self::class, 'block_divi_admin_email_pre_wp_mail' ) ) ) {
			\add_filter( 'pre_wp_mail', array( self::class, 'block_divi_admin_email_pre_wp_mail' ), 1, 2 );
		}
	}

	/**
	 * Short-circuit Divi's Contact Form admin notification when spam was hard-blocked
	 * or Supreme field validation rejected the submit.
	 *
	 * @param null|bool            $pre  Short-circuit value.
	 * @param array<string, mixed> $atts wp_mail attributes (unused).
	 * @return null|bool
	 */
	public static function block_divi_admin_email_pre_wp_mail( $pre, $atts = array() ) {
		unset( $atts );

		if ( ! self::$block_divi_admin_email ) {
			return $pre;
		}

		self::$block_divi_admin_email = false;
		\remove_filter( 'pre_wp_mail', array( self::class, 'block_divi_admin_email_pre_wp_mail' ), 1 );

		/**
		 * Whether to block Divi's Contact Form admin notification after a Supreme spam store
		 * or invalid Supreme field submit.
		 *
		 * @param bool $should_block Default true.
		 */
		$should_block = (bool) \apply_filters( 'dsm_contact_form_block_divi_admin_email', true );
		if ( ! $should_block ) {
			return $pre;
		}

		// Returning false makes wp_mail() return false without sending.
		return false;
	}

	/**
	 * List table columns.
	 *
	 * @param array<string, string> $columns Columns.
	 * @return array<string, string>
	 */
	public function list_columns( array $columns ): array {
		return array(
			'cb'          => $columns['cb'] ?? '<input type="checkbox" />',
			'dsm_starred' => '<span class="dashicons dashicons-star-filled" aria-hidden="true"></span><span class="screen-reader-text">' . \esc_html__( 'Starred', 'dsm-supreme-modules-pro-for-divi' ) . '</span>',
			'title'       => __( 'Entry', 'dsm-supreme-modules-pro-for-divi' ),
			'dsm_name'    => __( 'Name', 'dsm-supreme-modules-pro-for-divi' ),
			'dsm_email'   => __( 'Email', 'dsm-supreme-modules-pro-for-divi' ),
			'dsm_form'    => __( 'Form', 'dsm-supreme-modules-pro-for-divi' ),
			'dsm_page'    => __( 'Page', 'dsm-supreme-modules-pro-for-divi' ),
			'dsm_status'  => __( 'Status', 'dsm-supreme-modules-pro-for-divi' ),
			'date'        => __( 'Date', 'dsm-supreme-modules-pro-for-divi' ),
		);
	}

	/**
	 * Render custom list columns.
	 *
	 * @param string $column  Column key.
	 * @param int    $post_id Entry ID.
	 * @return void
	 */
	public function render_list_column( string $column, int $post_id ): void {
		switch ( $column ) {
			case 'dsm_starred':
				$starred    = '1' === (string) \get_post_meta( $post_id, self::META_STARRED, true );
				$url        = $this->row_action_url( $post_id, $starred ? 'unstar' : 'star' );
				$star_title = $starred
					? __( 'Unstar', 'dsm-supreme-modules-pro-for-divi' )
					: __( 'Star', 'dsm-supreme-modules-pro-for-divi' );
				\printf(
					'<a href="%1$s" title="%2$s"><span class="dashicons dashicons-star-%3$s" aria-hidden="true"></span><span class="screen-reader-text">%2$s</span></a>',
					\esc_url( $url ),
					\esc_attr( $star_title ),
					\esc_attr( $starred ? 'filled' : 'empty' )
				);
				break;
			case 'dsm_name':
				echo \esc_html( (string) \get_post_meta( $post_id, self::META_NAME, true ) );
				break;
			case 'dsm_email':
				$email = (string) \get_post_meta( $post_id, self::META_EMAIL, true );
				if ( '' !== $email ) {
					\printf(
						'<a href="%1$s">%2$s</a>',
						\esc_url( 'mailto:' . $email ),
						\esc_html( $email )
					);
				}
				break;
			case 'dsm_form':
				$form_id = (string) \get_post_meta( $post_id, self::META_FORM_ID, true );
				$unique  = (string) \get_post_meta( $post_id, self::META_FORM_UNIQUE_ID, true );
				echo \esc_html( '' !== $form_id ? $form_id : $unique );
				break;
			case 'dsm_page':
				$source_id = \absint( \get_post_meta( $post_id, self::META_SOURCE_POST_ID, true ) );
				if ( $source_id > 0 ) {
					$edit       = \get_edit_post_link( $source_id );
					$page_title = \get_the_title( $source_id );
					$page_label = ( \is_string( $page_title ) && '' !== $page_title )
						? $page_title
						: (string) $source_id;
					if ( $edit ) {
						\printf(
							'<a href="%1$s">%2$s</a>',
							\esc_url( $edit ),
							\esc_html( $page_label )
						);
					} else {
						echo \esc_html( $page_label );
					}
				} else {
					echo '&mdash;';
				}
				break;
			case 'dsm_status':
				$this->render_status_badge( (string) \get_post_meta( $post_id, self::META_STATUS, true ) );
				$reason = (string) \get_post_meta( $post_id, self::META_SPAM_REASON, true );
				if ( '' !== $reason ) {
					echo '<br><span class="description">' . \esc_html( $this->spam_reason_label( $reason ) ) . '</span>';
				}
				break;
		}
	}

	/**
	 * Trim row actions and add status / star helpers.
	 *
	 * @param array<string, string> $actions Actions.
	 * @param \WP_Post              $post    Post.
	 * @return array<string, string>
	 */
	public function row_actions( array $actions, $post ): array {
		if ( ! $post instanceof \WP_Post || self::POST_TYPE !== $post->post_type ) {
			return $actions;
		}

		unset( $actions['inline hide-if-no-js'], $actions['inline'] );

		$status  = (string) \get_post_meta( $post->ID, self::META_STATUS, true );
		$starred = '1' === (string) \get_post_meta( $post->ID, self::META_STARRED, true );

		if ( 'spam' !== $status ) {
			$actions['dsm_mark_spam'] = \sprintf(
				'<a href="%1$s">%2$s</a>',
				\esc_url( $this->row_action_url( (int) $post->ID, 'spam' ) ),
				\esc_html__( 'Mark as Spam', 'dsm-supreme-modules-pro-for-divi' )
			);
		} else {
			$actions['dsm_mark_not_spam'] = \sprintf(
				'<a href="%1$s">%2$s</a>',
				\esc_url( $this->row_action_url( (int) $post->ID, 'not_spam' ) ),
				\esc_html__( 'Not Spam', 'dsm-supreme-modules-pro-for-divi' )
			);
		}

		if ( 'read' !== $status && 'spam' !== $status ) {
			$actions['dsm_mark_read'] = \sprintf(
				'<a href="%1$s">%2$s</a>',
				\esc_url( $this->row_action_url( (int) $post->ID, 'read' ) ),
				\esc_html__( 'Mark as Read', 'dsm-supreme-modules-pro-for-divi' )
			);
		}

		if ( 'new' !== $status && 'spam' !== $status ) {
			$actions['dsm_mark_new'] = \sprintf(
				'<a href="%1$s">%2$s</a>',
				\esc_url( $this->row_action_url( (int) $post->ID, 'new' ) ),
				\esc_html__( 'Mark as New', 'dsm-supreme-modules-pro-for-divi' )
			);
		}

		$actions['dsm_star'] = \sprintf(
			'<a href="%1$s">%2$s</a>',
			\esc_url( $this->row_action_url( (int) $post->ID, $starred ? 'unstar' : 'star' ) ),
			$starred
				? \esc_html__( 'Unstar', 'dsm-supreme-modules-pro-for-divi' )
				: \esc_html__( 'Star', 'dsm-supreme-modules-pro-for-divi' )
		);

		return $actions;
	}

	/**
	 * Bulk actions for the entries list.
	 *
	 * @param array<string, string> $actions Actions.
	 * @return array<string, string>
	 */
	public function bulk_actions( array $actions ): array {
		unset( $actions['edit'] );

		$actions['dsm_mark_read']     = __( 'Mark as Read', 'dsm-supreme-modules-pro-for-divi' );
		$actions['dsm_mark_new']      = __( 'Mark as New', 'dsm-supreme-modules-pro-for-divi' );
		$actions['dsm_mark_spam']     = __( 'Mark as Spam', 'dsm-supreme-modules-pro-for-divi' );
		$actions['dsm_mark_not_spam'] = __( 'Not Spam', 'dsm-supreme-modules-pro-for-divi' );
		$actions['dsm_star']          = __( 'Star', 'dsm-supreme-modules-pro-for-divi' );
		$actions['dsm_unstar']        = __( 'Unstar', 'dsm-supreme-modules-pro-for-divi' );

		return $actions;
	}

	/**
	 * Handle bulk status / star actions.
	 *
	 * @param string                 $redirect_url Redirect URL.
	 * @param string                 $action       Bulk action slug.
	 * @param array<int, int|string> $post_ids  Selected IDs.
	 * @return string
	 */
	public function handle_bulk_actions( string $redirect_url, string $action, array $post_ids ): string {
		if ( ! \current_user_can( self::CAPABILITY ) ) {
			return $redirect_url;
		}

		$map = array(
			'dsm_mark_read'     => array( 'status', 'read' ),
			'dsm_mark_new'      => array( 'status', 'new' ),
			'dsm_mark_spam'     => array( 'status', 'spam' ),
			'dsm_mark_not_spam' => array( 'status', 'new' ),
			'dsm_star'          => array( 'star', '1' ),
			'dsm_unstar'        => array( 'star', '0' ),
		);

		if ( ! isset( $map[ $action ] ) ) {
			return $redirect_url;
		}

		[ $kind, $value ] = $map[ $action ];
		$updated          = 0;

		foreach ( $post_ids as $post_id ) {
			$post_id = \absint( $post_id );
			if ( $post_id <= 0 || ! $this->is_entry_post( $post_id ) ) {
				continue;
			}

			if ( 'status' === $kind ) {
				\update_post_meta( $post_id, self::META_STATUS, $value );
				if ( 'spam' === $value ) {
					\update_post_meta( $post_id, self::META_SPAM_REASON, 'manual' );
				} else {
					\delete_post_meta( $post_id, self::META_SPAM_REASON );
				}
			} else {
				\update_post_meta( $post_id, self::META_STARRED, $value );
			}
			++$updated;
		}

		return \add_query_arg(
			array(
				'dsm_cf_updated' => $updated,
			),
			$redirect_url
		);
	}

	/**
	 * List view links (status + starred).
	 *
	 * @param array<string, string> $views Views.
	 * @return array<string, string>
	 */
	public function list_views( array $views ): array {
		$base = \admin_url( 'edit.php?post_type=' . self::POST_TYPE );
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- View UI only.
		$current_status = isset( $_GET['dsm_cf_status'] ) ? \sanitize_key( \wp_unslash( $_GET['dsm_cf_status'] ) ) : '';
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- View UI only.
		$starred_view = isset( $_GET['dsm_cf_starred'] ) && '1' === \sanitize_key( \wp_unslash( $_GET['dsm_cf_starred'] ) );

		$counts        = array(
			'new'  => $this->count_by_meta( self::META_STATUS, 'new' ),
			'read' => $this->count_by_meta( self::META_STATUS, 'read' ),
			'spam' => $this->count_by_meta( self::META_STATUS, 'spam' ),
		);
		$starred_count = $this->count_by_meta( self::META_STARRED, '1' );

		$custom = array(
			'dsm_new'     => \sprintf(
				'<a href="%1$s"%2$s>%3$s <span class="count">(%4$d)</span></a>',
				\esc_url( \add_query_arg( 'dsm_cf_status', 'new', $base ) ),
				'new' === $current_status && ! $starred_view ? ' class="current" aria-current="page"' : '',
				\esc_html__( 'New', 'dsm-supreme-modules-pro-for-divi' ),
				$counts['new']
			),
			'dsm_read'    => \sprintf(
				'<a href="%1$s"%2$s>%3$s <span class="count">(%4$d)</span></a>',
				\esc_url( \add_query_arg( 'dsm_cf_status', 'read', $base ) ),
				'read' === $current_status && ! $starred_view ? ' class="current" aria-current="page"' : '',
				\esc_html__( 'Read', 'dsm-supreme-modules-pro-for-divi' ),
				$counts['read']
			),
			'dsm_spam'    => \sprintf(
				'<a href="%1$s"%2$s>%3$s <span class="count">(%4$d)</span></a>',
				\esc_url( \add_query_arg( 'dsm_cf_status', 'spam', $base ) ),
				'spam' === $current_status && ! $starred_view ? ' class="current" aria-current="page"' : '',
				\esc_html__( 'Spam', 'dsm-supreme-modules-pro-for-divi' ),
				$counts['spam']
			),
			'dsm_starred' => \sprintf(
				'<a href="%1$s"%2$s>%3$s <span class="count">(%4$d)</span></a>',
				\esc_url( \add_query_arg( 'dsm_cf_starred', '1', $base ) ),
				$starred_view ? ' class="current" aria-current="page"' : '',
				\esc_html__( 'Starred', 'dsm-supreme-modules-pro-for-divi' ),
				$starred_count
			),
		);

		return \array_merge( $views, $custom );
	}

	/**
	 * Meta boxes on entry edit screen.
	 *
	 * @return void
	 */
	public function register_meta_boxes(): void {
		\remove_meta_box( 'submitdiv', self::POST_TYPE, 'side' );
		\remove_meta_box( 'slugdiv', self::POST_TYPE, 'normal' );

		\add_meta_box(
			'dsm_cf_entry_fields',
			__( 'Submitted fields', 'dsm-supreme-modules-pro-for-divi' ),
			array( $this, 'render_fields_meta_box' ),
			self::POST_TYPE,
			'normal',
			'high'
		);

		\add_meta_box(
			'dsm_cf_entry_meta',
			__( 'Entry details', 'dsm-supreme-modules-pro-for-divi' ),
			array( $this, 'render_details_meta_box' ),
			self::POST_TYPE,
			'side',
			'high'
		);
	}

	/**
	 * Fields table metabox.
	 *
	 * @param \WP_Post $post Entry.
	 * @return void
	 */
	public function render_fields_meta_box( $post ): void {
		$fields = \get_post_meta( (int) $post->ID, self::META_FIELDS, true );
		if ( ! \is_array( $fields ) || array() === $fields ) {
			echo '<p>' . \esc_html__( 'No field data stored for this entry.', 'dsm-supreme-modules-pro-for-divi' ) . '</p>';
			return;
		}

		echo '<table class="widefat striped"><thead><tr>';
		echo '<th>' . \esc_html__( 'Label', 'dsm-supreme-modules-pro-for-divi' ) . '</th>';
		echo '<th>' . \esc_html__( 'Value', 'dsm-supreme-modules-pro-for-divi' ) . '</th>';
		echo '</tr></thead><tbody>';

		foreach ( $fields as $field ) {
			if ( ! \is_array( $field ) ) {
				continue;
			}
			$label = isset( $field['label'] ) ? (string) $field['label'] : '';
			$type  = isset( $field['type'] ) ? \sanitize_key( (string) $field['type'] ) : '';
			$value = $this->stringify_value( $field['value'] ?? '' );
			if ( \in_array( $type, array( 'date', 'time', 'datetime', 'date_time' ), true ) ) {
				$value = ContactFormEntries\ContactFormFields::format_value_for_display( $type, $value );
			}
			echo '<tr><td>' . \esc_html( $label ) . '</td><td>';
			if (
				'signature' === $type
				&& \strlen( $value ) <= ContactFormField::SIGNATURE_MAX_BYTES
				&& 1 === \preg_match( '#^data:image/(png|jpeg);base64,[A-Za-z0-9+/]+=*$#', $value )
			) {
				echo '<img src="' . \esc_attr( $value ) . '" alt="' . \esc_attr__( 'Signature', 'dsm-supreme-modules-pro-for-divi' ) . '" style="max-width:280px;height:auto;display:block;background:#fff;border:1px solid #dcdcde;" />';
			} elseif ( 'signature' === $type && '' !== $value ) {
				echo \esc_html__( 'Signed', 'dsm-supreme-modules-pro-for-divi' );
			} else {
				echo \esc_html( $value );
			}
			echo '</td></tr>';
		}

		echo '</tbody></table>';
	}

	/**
	 * Side details metabox + trash link.
	 *
	 * @param \WP_Post $post Entry.
	 * @return void
	 */
	public function render_details_meta_box( $post ): void {
		$post_id   = (int) $post->ID;
		$status    = (string) \get_post_meta( $post_id, self::META_STATUS, true );
		$starred   = '1' === (string) \get_post_meta( $post_id, self::META_STARRED, true );
		$form_id   = (string) \get_post_meta( $post_id, self::META_FORM_ID, true );
		$unique_id = (string) \get_post_meta( $post_id, self::META_FORM_UNIQUE_ID, true );
		$source_id = \absint( \get_post_meta( $post_id, self::META_SOURCE_POST_ID, true ) );

		echo '<p><strong>' . \esc_html__( 'Status', 'dsm-supreme-modules-pro-for-divi' ) . ':</strong> ';
		$this->render_status_badge( $status );
		echo '</p>';

		$spam_reason = (string) \get_post_meta( $post_id, self::META_SPAM_REASON, true );
		if ( '' !== $spam_reason ) {
			echo '<p><strong>' . \esc_html__( 'Spam reason', 'dsm-supreme-modules-pro-for-divi' ) . ':</strong> ';
			echo \esc_html( $this->spam_reason_label( $spam_reason ) ) . '</p>';
		}

		if ( \class_exists( ContactFormEntries\Autoresponder::class ) ) {
			$autoresponder = \get_post_meta( $post_id, ContactFormEntries\Autoresponder::META_RESULT, true );
			if ( \is_array( $autoresponder ) && array() !== $autoresponder ) {
				echo '<p><strong>' . \esc_html__( 'Autoresponder', 'dsm-supreme-modules-pro-for-divi' ) . ':</strong> ';
				echo \esc_html( ContactFormEntries\Autoresponder::format_result_label( $autoresponder ) ) . '</p>';
			}
		}

		if ( \class_exists( ContactFormEntries\FileUpload::class ) ) {
			$attachments = \get_post_meta( $post_id, ContactFormEntries\FileUpload::META_ATTACHMENTS, true );
			if ( \is_array( $attachments ) && array() !== $attachments ) {
				echo '<p><strong>' . \esc_html__( 'Attachments', 'dsm-supreme-modules-pro-for-divi' ) . ':</strong></p><ul>';
				foreach ( $attachments as $attachment_id ) {
					$attachment_id = \absint( $attachment_id );
					if ( $attachment_id <= 0 ) {
						continue;
					}
					$url  = ContactFormEntries\FileUpload::get_download_url( $attachment_id, $post_id );
					$name = \get_the_title( $attachment_id );
					$file = \get_attached_file( $attachment_id );
					if ( '' === $name && \is_string( $file ) ) {
						$name = \wp_basename( $file );
					}
					if ( '' === $name ) {
						$name = '#' . $attachment_id;
					}
					echo '<li><a href="' . \esc_url( $url ) . '">';
					echo \esc_html( $name );
					echo '</a></li>';
				}
				echo '</ul>';
			}
		}

		echo '<p><strong>' . \esc_html__( 'Starred', 'dsm-supreme-modules-pro-for-divi' ) . ':</strong> ';
		echo \esc_html( $starred ? __( 'Yes', 'dsm-supreme-modules-pro-for-divi' ) : __( 'No', 'dsm-supreme-modules-pro-for-divi' ) ) . '</p>';

		echo '<p>';
		if ( 'spam' !== $status ) {
			\printf(
				'<a class="button" href="%1$s">%2$s</a> ',
				\esc_url( $this->row_action_url( $post_id, 'spam' ) ),
				\esc_html__( 'Mark as Spam', 'dsm-supreme-modules-pro-for-divi' )
			);
		} else {
			\printf(
				'<a class="button" href="%1$s">%2$s</a> ',
				\esc_url( $this->row_action_url( $post_id, 'not_spam' ) ),
				\esc_html__( 'Not Spam', 'dsm-supreme-modules-pro-for-divi' )
			);
		}
		$star_action_label = $starred
			? __( 'Unstar', 'dsm-supreme-modules-pro-for-divi' )
			: __( 'Star', 'dsm-supreme-modules-pro-for-divi' );
		\printf(
			'<a class="button" href="%1$s">%2$s</a>',
			\esc_url( $this->row_action_url( $post_id, $starred ? 'unstar' : 'star' ) ),
			\esc_html( $star_action_label )
		);
		echo '</p>';

		echo '<p><strong>' . \esc_html__( 'Form ID', 'dsm-supreme-modules-pro-for-divi' ) . ':</strong> ';
		echo \esc_html( '' !== $form_id ? $form_id : '—' ) . '</p>';

		echo '<p><strong>' . \esc_html__( 'Unique ID', 'dsm-supreme-modules-pro-for-divi' ) . ':</strong> ';
		echo \esc_html( '' !== $unique_id ? $unique_id : '—' ) . '</p>';

		if ( $source_id > 0 ) {
			$edit = \get_edit_post_link( $source_id );
			echo '<p><strong>' . \esc_html__( 'Page', 'dsm-supreme-modules-pro-for-divi' ) . ':</strong> ';
			if ( $edit ) {
				\printf(
					'<a href="%1$s">%2$s</a>',
					\esc_url( $edit ),
					\esc_html( (string) \get_the_title( $source_id ) )
				);
			} else {
				echo \esc_html( (string) $source_id );
			}
			echo '</p>';
		}

		$trash_url = \get_delete_post_link( $post_id );
		if ( $trash_url ) {
			echo '<p><a class="submitdelete" href="' . \esc_url( $trash_url ) . '">';
			echo \esc_html__( 'Move to Trash', 'dsm-supreme-modules-pro-for-divi' );
			echo '</a></p>';
		}
	}

	/**
	 * Mark entry read when opened in admin (not for spam).
	 *
	 * @return void
	 */
	public function maybe_mark_entry_read(): void {
		if ( ! \current_user_can( self::CAPABILITY ) ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only admin screen bootstrap.
		$post_id = isset( $_GET['post'] ) ? \absint( \wp_unslash( $_GET['post'] ) ) : 0;
		if ( $post_id <= 0 ) {
			return;
		}

		$post = \get_post( $post_id );
		if ( ! $post || self::POST_TYPE !== $post->post_type ) {
			return;
		}

		$status = (string) \get_post_meta( $post_id, self::META_STATUS, true );
		if ( 'new' === $status || '' === $status ) {
			\update_post_meta( $post_id, self::META_STATUS, 'read' );
		}
	}

	/**
	 * Status + export controls on list screen.
	 *
	 * @param string $post_type Post type.
	 * @return void
	 */
	public function render_list_filters( string $post_type ): void {
		if ( self::POST_TYPE !== $post_type || ! \current_user_can( self::CAPABILITY ) ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Filter UI only.
		$current = isset( $_GET['dsm_cf_status'] ) ? \sanitize_key( \wp_unslash( $_GET['dsm_cf_status'] ) ) : '';

		$options = array(
			''     => __( 'All statuses', 'dsm-supreme-modules-pro-for-divi' ),
			'new'  => __( 'New', 'dsm-supreme-modules-pro-for-divi' ),
			'read' => __( 'Read', 'dsm-supreme-modules-pro-for-divi' ),
			'spam' => __( 'Spam', 'dsm-supreme-modules-pro-for-divi' ),
		);

		echo '<select name="dsm_cf_status">';
		foreach ( $options as $value => $label ) {
			\printf(
				'<option value="%1$s" %2$s>%3$s</option>',
				\esc_attr( $value ),
				\selected( $current, $value, false ),
				\esc_html( $label )
			);
		}
		echo '</select>';

		$export_url = \wp_nonce_url(
			\admin_url( 'admin-post.php?action=dsm_export_cf_entries' ),
			'dsm_export_cf_entries'
		);
		\printf(
			'<a class="button" style="margin-left:8px;" href="%1$s">%2$s</a>',
			\esc_url( $export_url ),
			\esc_html__( 'Export CSV', 'dsm-supreme-modules-pro-for-divi' )
		);
	}

	/**
	 * Apply status / starred filters on the entries list query only.
	 *
	 * @param \WP_Query $query Query.
	 * @return void
	 */
	public function filter_list_query( $query ): void {
		if ( ! $query instanceof \WP_Query || ! $query->is_main_query() ) {
			return;
		}

		$post_type = $query->get( 'post_type' );
		if ( self::POST_TYPE !== $post_type ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Filter UI only.
		$status = isset( $_GET['dsm_cf_status'] ) ? \sanitize_key( \wp_unslash( $_GET['dsm_cf_status'] ) ) : '';
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Filter UI only.
		$starred = isset( $_GET['dsm_cf_starred'] ) ? \sanitize_key( \wp_unslash( $_GET['dsm_cf_starred'] ) ) : '';

		$meta_query = array();

		if ( \in_array( $status, array( 'new', 'read', 'spam' ), true ) ) {
			$meta_query[] = array(
				'key'   => self::META_STATUS,
				'value' => $status,
			);
		}

		if ( '1' === $starred ) {
			$meta_query[] = array(
				'key'   => self::META_STARRED,
				'value' => '1',
			);
		}

		if ( array() !== $meta_query ) {
			if ( \count( $meta_query ) > 1 ) {
				$meta_query['relation'] = 'AND';
			}
			$query->set( 'meta_query', $meta_query );
		}
	}

	/**
	 * Single-entry row action handler.
	 *
	 * @return void
	 */
	public function handle_row_action(): void {
		if ( ! \current_user_can( self::CAPABILITY ) ) {
			\wp_die( \esc_html__( 'Sorry, you are not allowed to manage entries.', 'dsm-supreme-modules-pro-for-divi' ) );
		}

		\check_admin_referer( 'dsm_cf_entry_action' );

		$post_id = isset( $_GET['post'] ) ? \absint( \wp_unslash( $_GET['post'] ) ) : 0;
		$do      = isset( $_GET['dsm_cf_do'] ) ? \sanitize_key( \wp_unslash( $_GET['dsm_cf_do'] ) ) : '';

		if ( $post_id <= 0 || ! $this->is_entry_post( $post_id ) ) {
			\wp_die( \esc_html__( 'Invalid entry.', 'dsm-supreme-modules-pro-for-divi' ) );
		}

		switch ( $do ) {
			case 'spam':
				\update_post_meta( $post_id, self::META_STATUS, 'spam' );
				\update_post_meta( $post_id, self::META_SPAM_REASON, 'manual' );
				break;
			case 'not_spam':
			case 'new':
				\update_post_meta( $post_id, self::META_STATUS, 'new' );
				\delete_post_meta( $post_id, self::META_SPAM_REASON );
				break;
			case 'read':
				\update_post_meta( $post_id, self::META_STATUS, 'read' );
				\delete_post_meta( $post_id, self::META_SPAM_REASON );
				break;
			case 'star':
				\update_post_meta( $post_id, self::META_STARRED, '1' );
				break;
			case 'unstar':
				\update_post_meta( $post_id, self::META_STARRED, '0' );
				break;
			default:
				\wp_die( \esc_html__( 'Invalid action.', 'dsm-supreme-modules-pro-for-divi' ) );
		}

		$redirect = \wp_get_referer();
		if ( ! \is_string( $redirect ) || '' === $redirect ) {
			$redirect = \admin_url( 'edit.php?post_type=' . self::POST_TYPE );
		}

		\wp_safe_redirect( \add_query_arg( 'dsm_cf_updated', '1', $redirect ) );
		exit;
	}

	/**
	 * CSV export handler.
	 *
	 * @return void
	 */
	public function handle_csv_export(): void {
		if ( ! \current_user_can( self::CAPABILITY ) ) {
			\wp_die( \esc_html__( 'Sorry, you are not allowed to export entries.', 'dsm-supreme-modules-pro-for-divi' ) );
		}

		\check_admin_referer( 'dsm_export_cf_entries' );

		$entries = \get_posts(
			array(
				'post_type'      => self::POST_TYPE,
				'post_status'    => array( 'private', 'publish', 'draft' ),
				// phpcs:ignore WordPress.WP.PostsPerPage.posts_per_page_posts_per_page -- Bounded CSV export batch.
				'posts_per_page' => 5000,
				'orderby'        => 'date',
				'order'          => 'DESC',
				'no_found_rows'  => true,
			)
		);

		$filename = 'dsm-contact-form-entries-' . \gmdate( 'Y-m-d' ) . '.csv';

		\nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=' . $filename );

		$out = fopen( 'php://output', 'w' );
		if ( false === $out ) {
			\wp_die( \esc_html__( 'Could not open export stream.', 'dsm-supreme-modules-pro-for-divi' ) );
		}

		\fputcsv(
			$out,
			array(
				'ID',
				'Date',
				'Status',
				'Spam Reason',
				'Starred',
				'Name',
				'Email',
				'Form ID',
				'Unique ID',
				'Source Post ID',
				'Fields JSON',
			)
		);

		foreach ( $entries as $entry ) {
			if ( ! $entry instanceof \WP_Post ) {
				continue;
			}
			$fields = \get_post_meta( $entry->ID, self::META_FIELDS, true );
			\fputcsv(
				$out,
				array(
					(string) $entry->ID,
					(string) $entry->post_date,
					(string) \get_post_meta( $entry->ID, self::META_STATUS, true ),
					(string) \get_post_meta( $entry->ID, self::META_SPAM_REASON, true ),
					(string) \get_post_meta( $entry->ID, self::META_STARRED, true ),
					(string) \get_post_meta( $entry->ID, self::META_NAME, true ),
					(string) \get_post_meta( $entry->ID, self::META_EMAIL, true ),
					(string) \get_post_meta( $entry->ID, self::META_FORM_ID, true ),
					(string) \get_post_meta( $entry->ID, self::META_FORM_UNIQUE_ID, true ),
					(string) \get_post_meta( $entry->ID, self::META_SOURCE_POST_ID, true ),
					\wp_json_encode( $this->fields_for_export_display( \is_array( $fields ) ? $fields : array() ) ),
				)
			);
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- php://output stream for CSV.
		fclose( $out );
		exit;
	}

	/**
	 * List-screen tip + bulk update notice.
	 *
	 * @return void
	 */
	public function maybe_render_list_notice(): void {
		if ( ! \function_exists( 'get_current_screen' ) ) {
			return;
		}

		$screen = \get_current_screen();
		if ( ! $screen || self::POST_TYPE !== $screen->post_type || 'edit' !== $screen->base ) {
			return;
		}

		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Admin list notice only.
		if ( isset( $_GET['dsm_cf_updated'] ) ) {
			$n = \absint( \wp_unslash( $_GET['dsm_cf_updated'] ) );
			echo '<div class="notice notice-success is-dismissible"><p>';
			echo \esc_html(
				\sprintf(
					/* translators: %d: number of entries updated */
					\_n( '%d entry updated.', '%d entries updated.', $n, 'dsm-supreme-modules-pro-for-divi' ),
					$n
				)
			);
			echo '</p></div>';
		}
		// phpcs:enable WordPress.Security.NonceVerification.Recommended

		$settings_url = \admin_url( 'admin.php?page=divi_supreme_settings&tab=dsm_settings_contact_form_pro' );

		echo '<div class="notice notice-info"><p>';
		echo \esc_html__(
			'These entries come from Divi native Contact Form modules. Successful submissions are stored automatically while Contact Form Pro is enabled under Divi Supreme → Extensions.',
			'dsm-supreme-modules-pro-for-divi'
		);
		echo ' <a href="' . \esc_url( $settings_url ) . '">';
		echo \esc_html__( 'Configure honeypot & blacklist', 'dsm-supreme-modules-pro-for-divi' );
		echo '</a></p></div>';
	}

	/**
	 * Whether the honeypot POST field was filled.
	 *
	 * @return bool
	 */
	private function is_honeypot_triggered(): bool {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Divi owns form nonce; we only read honeypot.
		if ( ! isset( $_POST[ self::HONEYPOT_FIELD ] ) ) {
			return false;
		}
		$raw = \sanitize_text_field( \wp_unslash( (string) $_POST[ self::HONEYPOT_FIELD ] ) );
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		return '' !== \trim( $raw );
	}

	/**
	 * Whether this request came from a form with Turnstile active.
	 *
	 * @return bool
	 */
	private function is_turnstile_active_on_request(): bool {
		if ( ! \class_exists( ContactFormEntries\Turnstile::class ) ) {
			return false;
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Marker injected with the widget.
		$active = isset( $_POST['dsm_cf_turnstile_active'] )
			|| isset( $_POST[ ContactFormEntries\Turnstile::TOKEN_FIELD ] );
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		return $active;
	}

	/**
	 * Whether this request came from a form with hCaptcha active.
	 *
	 * @return bool
	 */
	private function is_hcaptcha_active_on_request(): bool {
		if ( ! \class_exists( ContactFormEntries\Hcaptcha::class ) ) {
			return false;
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Marker injected with the widget.
		$active = isset( $_POST['dsm_cf_hcaptcha_active'] )
			|| isset( $_POST[ ContactFormEntries\Hcaptcha::TOKEN_FIELD ] );
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		return $active;
	}

	/**
	 * Whether submission matches configured blacklist rules.
	 *
	 * @param array<string, mixed> $fields Processed fields.
	 * @param string               $email  Submitter email.
	 * @return bool
	 */
	private function is_blacklisted_submission( array $fields, string $email ): bool {
		$email_l = \strtolower( \trim( $email ) );

		foreach ( self::get_blacklist_lines( 'dsm_cf_blacklist_emails' ) as $blocked ) {
			if ( '' !== $email_l && $email_l === $blocked ) {
				return true;
			}
		}

		if ( '' !== $email_l && false !== \strpos( $email_l, '@' ) ) {
			$domain = \substr( $email_l, (int) \strrpos( $email_l, '@' ) + 1 );
			foreach ( self::get_blacklist_lines( 'dsm_cf_blacklist_domains' ) as $blocked_domain ) {
				$blocked_domain = \ltrim( $blocked_domain, '@' );
				$suffix         = '.' . $blocked_domain;
				if (
					'' !== $blocked_domain
					&& (
						$domain === $blocked_domain
						|| (
							\strlen( $domain ) > \strlen( $suffix )
							&& \substr( $domain, -\strlen( $suffix ) ) === $suffix
						)
					)
				) {
					return true;
				}
			}
		}

		$haystack = \strtolower( $email_l . ' ' . $this->fields_plaintext( $fields ) );
		foreach ( self::get_blacklist_lines( 'dsm_cf_blacklist_keywords' ) as $keyword ) {
			if ( '' !== $keyword && false !== \strpos( $haystack, $keyword ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Flatten field values for keyword matching.
	 *
	 * @param array<string, mixed> $fields Fields.
	 * @return string
	 */
	private function fields_plaintext( array $fields ): string {
		$parts = array();
		foreach ( $fields as $field ) {
			if ( ! \is_array( $field ) ) {
				continue;
			}
			$parts[] = $this->stringify_value( $field['value'] ?? '' );
			$parts[] = (string) ( $field['label'] ?? '' );
		}

		return \implode( ' ', $parts );
	}

	/**
	 * Build nonce’d admin-post URL for a row action.
	 *
	 * @param int    $post_id    Entry ID.
	 * @param string $action_key Action key.
	 * @return string
	 */
	private function row_action_url( int $post_id, string $action_key ): string {
		return \wp_nonce_url(
			\admin_url(
				'admin-post.php?action=dsm_cf_entry_action&post=' . $post_id . '&dsm_cf_do=' . \rawurlencode( $action_key )
			),
			'dsm_cf_entry_action'
		);
	}

	/**
	 * Whether post id is a contact form entry.
	 *
	 * @param int $post_id Post ID.
	 * @return bool
	 */
	private function is_entry_post( int $post_id ): bool {
		$post = \get_post( $post_id );
		return $post instanceof \WP_Post && self::POST_TYPE === $post->post_type;
	}

	/**
	 * Count entries by meta key/value.
	 *
	 * @param string $key   Meta key.
	 * @param string $value Meta value.
	 * @return int
	 */
	private function count_by_meta( string $key, string $value ): int {
		$q = new \WP_Query(
			array(
				'post_type'              => self::POST_TYPE,
				'post_status'            => array( 'private', 'publish', 'draft' ),
				'posts_per_page'         => 1,
				'fields'                 => 'ids',
				'no_found_rows'          => false,
				'update_post_meta_cache' => false,
				'update_post_term_cache' => false,
				// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Status/starred admin counts.
				'meta_query'             => array(
					array(
						'key'   => $key,
						'value' => $value,
					),
				),
			)
		);

		return (int) $q->found_posts;
	}

	/**
	 * Human-readable spam reason label.
	 *
	 * @param string $reason Reason key.
	 * @return string
	 */
	private function spam_reason_label( string $reason ): string {
		$map = array(
			'honeypot'  => __( 'Honeypot', 'dsm-supreme-modules-pro-for-divi' ),
			'turnstile' => __( 'Turnstile', 'dsm-supreme-modules-pro-for-divi' ),
			'hcaptcha'  => __( 'hCaptcha', 'dsm-supreme-modules-pro-for-divi' ),
			'blacklist' => __( 'Blacklist', 'dsm-supreme-modules-pro-for-divi' ),
			'manual'    => __( 'Marked manually', 'dsm-supreme-modules-pro-for-divi' ),
		);

		$reason = \sanitize_key( $reason );

		return $map[ $reason ] ?? $reason;
	}

	/**
	 * Human status label.
	 *
	 * @param string $status Status key.
	 * @return string
	 */
	private function status_label( string $status ): string {
		$map = array(
			'new'    => __( 'New', 'dsm-supreme-modules-pro-for-divi' ),
			'read'   => __( 'Read', 'dsm-supreme-modules-pro-for-divi' ),
			'spam'   => __( 'Spam', 'dsm-supreme-modules-pro-for-divi' ),
			'failed' => __( 'Failed', 'dsm-supreme-modules-pro-for-divi' ),
		);

		$normalized = $this->normalize_status_key( $status );

		return $map[ $normalized ] ?? ( '' !== $status ? $status : __( 'New', 'dsm-supreme-modules-pro-for-divi' ) );
	}

	/**
	 * Normalize stored status to a known key.
	 *
	 * @param string $status Raw status.
	 * @return string
	 */
	private function normalize_status_key( string $status ): string {
		$status = \sanitize_key( $status );

		return \in_array( $status, array( 'new', 'read', 'spam', 'failed' ), true ) ? $status : 'new';
	}

	/**
	 * Echo a colored status badge.
	 *
	 * @param string $status Status key.
	 * @return void
	 */
	private function render_status_badge( string $status ): void {
		$key = $this->normalize_status_key( $status );

		\printf(
			'<span class="dsm-cf-status-badge dsm-cf-status-badge--%1$s">%2$s</span>',
			\esc_attr( $key ),
			\esc_html( $this->status_label( $key ) )
		);
	}

	/**
	 * Read a named field value from Divi processed fields.
	 *
	 * @param array<string, mixed> $fields Fields.
	 * @param string               $key    Field key.
	 * @return string
	 */
	private function extract_field_value( array $fields, string $key ): string {
		if ( ! isset( $fields[ $key ] ) || ! \is_array( $fields[ $key ] ) ) {
			return '';
		}

		return $this->stringify_value( $fields[ $key ]['value'] ?? '' );
	}

	/**
	 * Resolve submitter email from Divi fields (id, type, then value scan).
	 *
	 * @param array<string, mixed> $fields Processed fields.
	 * @return string Valid email or empty string.
	 */
	private function extract_submitter_email( array $fields ): string {
		$email = $this->extract_field_value( $fields, 'email' );
		if ( \is_email( $email ) ) {
			return $email;
		}

		foreach ( $fields as $field ) {
			if ( ! \is_array( $field ) ) {
				continue;
			}
			$type = isset( $field['type'] ) ? (string) $field['type'] : '';
			if ( 'email' !== $type ) {
				continue;
			}
			$candidate = $this->stringify_value( $field['value'] ?? '' );
			if ( \is_email( $candidate ) ) {
				return $candidate;
			}
		}

		foreach ( $fields as $field ) {
			if ( ! \is_array( $field ) ) {
				continue;
			}
			$candidate = $this->stringify_value( $field['value'] ?? '' );
			if ( \is_email( $candidate ) ) {
				return $candidate;
			}
		}

		return '';
	}

	/**
	 * Clone stored fields and format temporal values for CSV JSON.
	 *
	 * Does not mutate post meta — only the export payload.
	 *
	 * @param array<string, mixed> $fields Stored fields.
	 * @return array<string, mixed>
	 */
	private function fields_for_export_display( array $fields ): array {
		$out = array();

		foreach ( $fields as $key => $field ) {
			if ( ! \is_array( $field ) ) {
				$out[ $key ] = $field;
				continue;
			}

			$row  = $field;
			$type = \sanitize_key( (string) ( $row['type'] ?? '' ) );
			if ( \in_array( $type, array( 'date', 'time', 'datetime', 'date_time' ), true ) ) {
				$row['value'] = ContactFormEntries\ContactFormFields::format_value_for_display(
					$type,
					$this->stringify_value( $row['value'] ?? '' )
				);
			}
			$out[ $key ] = $row;
		}

		return $out;
	}

	/**
	 * Normalize field values for display / CSV.
	 *
	 * @param mixed $value Raw value.
	 * @return string
	 */
	private function stringify_value( $value ): string {
		if ( \is_array( $value ) ) {
			$parts = array();
			foreach ( $value as $part ) {
				if ( \is_scalar( $part ) && '' !== (string) $part ) {
					$parts[] = (string) $part;
				}
			}
			return \implode( ', ', $parts );
		}

		if ( \is_scalar( $value ) ) {
			return (string) $value;
		}

		return '';
	}

	/**
	 * Sanitize field payload before post meta storage.
	 *
	 * @param array<string, mixed> $fields Fields.
	 * @return array<string, array<string, mixed>>
	 */
	private function sanitize_fields_for_storage( array $fields ): array {
		$out = array();

		foreach ( $fields as $key => $field ) {
			if ( ! \is_array( $field ) ) {
				continue;
			}

			$safe_key = \sanitize_key( (string) $key );
			if ( '' === $safe_key ) {
				continue;
			}

			$raw_value = $field['value'] ?? '';
			$type      = \sanitize_key( (string) ( $field['type'] ?? '' ) );

			if ( \is_array( $raw_value ) ) {
				$safe_value = \array_map( 'sanitize_text_field', \array_map( 'strval', $raw_value ) );
			} elseif ( 'signature' === $type ) {
				// Preserve PNG/JPEG data URLs (sanitize_text_field would mangle them).
				$candidate  = \trim( $this->stringify_value( $raw_value ) );
				$safe_value = (
					\strlen( $candidate ) <= ContactFormField::SIGNATURE_MAX_BYTES
					&& 1 === \preg_match( '#^data:image/(png|jpeg);base64,[A-Za-z0-9+/]+=*$#', $candidate )
				) ? $candidate : '';
			} else {
				$safe_value = \sanitize_text_field( $this->stringify_value( $raw_value ) );
			}

			$out[ $safe_key ] = array(
				'id'    => \sanitize_text_field( (string) ( $field['id'] ?? $safe_key ) ),
				'label' => \sanitize_text_field( (string) ( $field['label'] ?? '' ) ),
				'type'  => $type,
				'value' => $safe_value,
			);
		}

		return $out;
	}
}
