<?php
/**
 * Copy to Clipboard — frontend: click target → copy configured text to clipboard.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Extensions;

use DiviSupreme\Extensions\IconLibraries\IconGlyphRenderer;
use DiviSupreme\Extensions\IconLibraries\IconLibraryRegistry;
use DiviSupreme\Extensions\IconLibraries\IconProcessFontIconBridge;
use DiviSupreme\Extensions\IconLibraries\ProcessFontIconHelper;

/**
 * Appends FE payload after modules with Copy to Clipboard enabled.
 */
class CopyToClipboard {

	/**
	 * Allowed Tippy placements.
	 *
	 * @var list<string>
	 */
	private const PLACEMENTS = array( 'auto', 'top', 'bottom', 'left', 'right' );

	/**
	 * Whether the current request rendered at least one Copy to Clipboard module.
	 *
	 * @var bool
	 */
	private bool $needs_assets = false;

	/**
	 * DSM webfont icons referenced by CTC success tooltips (enqueue on footer).
	 *
	 * @var list<array<string, mixed>>
	 */
	private array $pending_dsm_icons = array();

	/**
	 * Constructor.
	 */
	public function __construct() {
		if ( ! function_exists( 'dsm_is_copy_to_clipboard_extension_enabled' ) || ! dsm_is_copy_to_clipboard_extension_enabled() ) {
			return;
		}

		add_filter( 'render_block', array( $this, 'maybe_append_copy_to_clipboard_payload' ), 20, 2 );
		add_action( 'wp_enqueue_scripts', array( $this, 'register_assets' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'maybe_enqueue_vb_tippy' ), 25 );
		add_action( 'wp_footer', array( $this, 'maybe_enqueue_assets' ), 1 );
	}

	/**
	 * Register FE script + Tippy deps (enqueued only when needed).
	 */
	public function register_assets(): void {
		$version = defined( 'DSM5_VERSION' ) ? DSM5_VERSION : ( defined( 'DSM_VERSION' ) ? DSM_VERSION : '1.0.0' );

		$this->ensure_tippy_registered( $version );

		wp_register_script(
			'dsm-copy-to-clipboard',
			DSM_DIR_URL . 'assets/js/extensions/copy-to-clipboard.js',
			array( 'dsm-tippy' ),
			$version,
			true
		);
	}

	/**
	 * Register Popper + Tippy if Hotspot/Icon List has not already.
	 *
	 * @param string $version Asset version.
	 */
	private function ensure_tippy_registered( string $version ): void {
		if ( ! wp_script_is( 'dsm-popper', 'registered' ) ) {
			wp_register_script(
				'dsm-popper',
				DSM_DIR_URL . 'assets/js/popper.js',
				array(),
				$version,
				true
			);
		}

		if ( ! wp_script_is( 'dsm-tippy', 'registered' ) ) {
			wp_register_script(
				'dsm-tippy',
				DSM_DIR_URL . 'assets/js/tippy.js',
				array( 'dsm-popper' ),
				$version,
				true
			);
		}
	}

	/**
	 * Enqueue Tippy in Visual Builder so canvas Preview matches the frontend.
	 */
	public function maybe_enqueue_vb_tippy(): void {
		if ( ! function_exists( 'et_core_is_fb_enabled' ) || ! et_core_is_fb_enabled() ) {
			return;
		}

		$version = defined( 'DSM5_VERSION' ) ? DSM5_VERSION : ( defined( 'DSM_VERSION' ) ? DSM_VERSION : '1.0.0' );
		$this->ensure_tippy_registered( $version );

		wp_enqueue_script( 'dsm-popper' );
		wp_enqueue_script( 'dsm-tippy' );
	}

	/**
	 * Enqueue FE assets in footer when a payload was rendered.
	 */
	public function maybe_enqueue_assets(): void {
		if ( ! $this->needs_assets ) {
			return;
		}

		if (
			array() !== $this->pending_dsm_icons &&
			class_exists( IconLibraryRegistry::class )
		) {
			IconLibraryRegistry::enqueue_webfonts_for_icons( $this->pending_dsm_icons );

			if ( wp_style_is( 'dsm-icon-libraries-frontend', 'registered' ) ) {
				wp_enqueue_style( 'dsm-icon-libraries-frontend' );
			}
		}

		wp_enqueue_script( 'dsm-popper' );
		wp_enqueue_script( 'dsm-tippy' );
		wp_enqueue_script( 'dsm-copy-to-clipboard' );
	}

	/**
	 * Append hidden payload after the module when Copy to Clipboard is enabled.
	 *
	 * @param string               $block_content Block HTML.
	 * @param array<string, mixed> $block         Parsed block.
	 * @return string
	 */
	public function maybe_append_copy_to_clipboard_payload( string $block_content, array $block ): string {
		if ( '' === $block_content || ! isset( $block['attrs'] ) || ! is_array( $block['attrs'] ) ) {
			return $block_content;
		}

		$attrs   = $block['attrs'];
		$entries = $this->collect_entries_from_attrs( $attrs );

		if ( array() === $entries ) {
			return $block_content;
		}

		$this->needs_assets = true;

		$module_tip_style = $this->collect_tip_style_from_attrs( $attrs );

		$entries_json   = esc_attr( (string) wp_json_encode( $entries ) );
		$tip_style_json = esc_attr( (string) wp_json_encode( $module_tip_style ) );

		// Keep legacy class + data-* attrs; add copy-to-clipboard aliases.
		$payload = sprintf(
			'<span class="dsm-click-to-copy-data dsm-copy-to-clipboard-data" hidden data-dsm-click-to-copy-entries="%1$s" data-dsm-copy-to-clipboard-entries="%1$s" data-dsm-click-to-copy-tip-style="%2$s" data-dsm-copy-to-clipboard-tip-style="%2$s"></span>',
			$entries_json,
			$tip_style_json
		);

		return $block_content . $payload;
	}

	/**
	 * Module-level tip Design tokens for Tippy theme (desktop / tablet / phone).
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 * @return array{desktop: array<string, mixed>, tablet: array<string, mixed>, phone: array<string, mixed>}
	 */
	private function collect_tip_style_from_attrs( array $attrs ): array {
		return array(
			'desktop' => $this->collect_tip_style_for_breakpoint( $attrs, 'desktop' ),
			'tablet'  => $this->collect_tip_style_for_breakpoint( $attrs, 'tablet' ),
			'phone'   => $this->collect_tip_style_for_breakpoint( $attrs, 'phone' ),
		);
	}

	/**
	 * Cascaded tip style for one breakpoint (phone → tablet → desktop).
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 * @param string               $mode  desktop|tablet|phone.
	 * @return array<string, mixed>
	 */
	private function collect_tip_style_for_breakpoint( array $attrs, string $mode ): array {
		$bg        = $this->inner_responsive_string( $attrs, 'dsm_ctc_tip_bg_color', $mode, 'rgba(51,51,51,0.95)' );
		$text      = $this->inner_responsive_string( $attrs, 'dsm_ctc_tip_text_color', $mode, '#ffffff' );
		$icon      = $this->inner_responsive_string( $attrs, 'dsm_ctc_tip_icon_color', $mode, '#ffffff' );
		$font_size = $this->inner_responsive_string( $attrs, 'dsm_ctc_tip_font_size', $mode, '14px' );
		$radius    = $this->inner_responsive_string( $attrs, 'dsm_ctc_tip_border_radius', $mode, '4px' );
		$arrow     = strtolower( $this->inner_responsive_string( $attrs, 'dsm_ctc_tip_arrow', $mode, 'on' ) );

		return array(
			'backgroundColor' => $bg,
			'color'           => $text,
			'iconColor'       => $icon,
			'fontSize'        => $font_size,
			'borderRadius'    => $radius,
			'padding'         => $this->padding_css_from_attrs( $attrs, $mode ),
			'boxShadow'       => $this->box_shadow_css_from_attrs( $attrs, $mode ),
			'showArrow'       => 'off' !== $arrow,
		);
	}

	/**
	 * Breakpoint fallback order for a responsive mode.
	 *
	 * @param string $mode desktop|tablet|phone.
	 * @return list<string>
	 */
	private function breakpoint_cascade( string $mode ): array {
		if ( 'phone' === $mode ) {
			return array( 'phone', 'tablet', 'desktop' );
		}
		if ( 'tablet' === $mode ) {
			return array( 'tablet', 'desktop' );
		}
		return array( 'desktop' );
	}

	/**
	 * Read a responsive innerContent string.
	 *
	 * @param array<string, mixed> $attrs   Module attrs.
	 * @param string               $key     Attr root.
	 * @param string               $mode    desktop|tablet|phone.
	 * @param string               $default Default.
	 */
	private function inner_responsive_string( array $attrs, string $key, string $mode, string $default ): string {
		$tree = $attrs[ $key ]['innerContent'] ?? null;
		if ( ! is_array( $tree ) ) {
			return $default;
		}

		foreach ( $this->breakpoint_cascade( $mode ) as $bp ) {
			$leaf = $tree[ $bp ]['value'] ?? null;
			if ( is_string( $leaf ) && '' !== trim( $leaf ) ) {
				return trim( $leaf );
			}
		}

		return $default;
	}

	/**
	 * Read a desktop innerContent string.
	 *
	 * @param array<string, mixed> $attrs    Module attrs.
	 * @param string               $key      Attr root.
	 * @param string               $default  Default.
	 */
	private function inner_desktop_string( array $attrs, string $key, string $default ): string {
		return $this->inner_responsive_string( $attrs, $key, 'desktop', $default );
	}

	/**
	 * CSS padding for the copy tip at one breakpoint.
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 * @param string               $mode  desktop|tablet|phone.
	 */
	private function padding_css_from_attrs( array $attrs, string $mode = 'desktop' ): string {
		$tree = $attrs['dsm_ctc_tip_padding']['decoration']['spacing'] ?? null;
		if ( ! is_array( $tree ) ) {
			return '6px 10px';
		}

		$padding = null;
		foreach ( $this->breakpoint_cascade( $mode ) as $bp ) {
			$candidate = $tree[ $bp ]['value']['padding'] ?? null;
			if ( is_array( $candidate ) ) {
				$padding = $candidate;
				break;
			}
		}

		if ( ! is_array( $padding ) ) {
			return '6px 10px';
		}

		$top    = isset( $padding['top'] ) && is_string( $padding['top'] ) ? $padding['top'] : '0';
		$right  = isset( $padding['right'] ) && is_string( $padding['right'] ) ? $padding['right'] : '0';
		$bottom = isset( $padding['bottom'] ) && is_string( $padding['bottom'] ) ? $padding['bottom'] : '0';
		$left   = isset( $padding['left'] ) && is_string( $padding['left'] ) ? $padding['left'] : '0';

		return trim( "$top $right $bottom $left" );
	}

	/**
	 * CSS box-shadow for the copy tip at one breakpoint.
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 * @param string               $mode  desktop|tablet|phone.
	 */
	private function box_shadow_css_from_attrs( array $attrs, string $mode = 'desktop' ): string {
		$tree = $attrs['dsm_ctc_tip_box_shadow']['decoration']['boxShadow'] ?? null;
		if ( ! is_array( $tree ) ) {
			return '';
		}

		$shadow = null;
		foreach ( $this->breakpoint_cascade( $mode ) as $bp ) {
			$candidate = $tree[ $bp ]['value'] ?? null;
			if ( is_array( $candidate ) ) {
				$shadow = $candidate;
				break;
			}
		}

		if ( ! is_array( $shadow ) ) {
			return '';
		}

		$open  = isset( $shadow['openShadow'] ) ? strtolower( (string) $shadow['openShadow'] ) : '';
		$h     = isset( $shadow['horizontal'] ) && is_string( $shadow['horizontal'] ) ? $shadow['horizontal'] : '';
		$v     = isset( $shadow['vertical'] ) && is_string( $shadow['vertical'] ) ? $shadow['vertical'] : '';
		$blur  = isset( $shadow['blur'] ) && is_string( $shadow['blur'] ) ? $shadow['blur'] : '';
		$color = isset( $shadow['color'] ) && is_string( $shadow['color'] ) ? $shadow['color'] : '';

		if ( 'on' !== $open && '' === $h && '' === $v && '' === $blur && '' === $color ) {
			return '';
		}

		$h      = '' !== $h ? $h : '0px';
		$v      = '' !== $v ? $v : '0px';
		$blur   = '' !== $blur ? $blur : '0px';
		$spread = isset( $shadow['spread'] ) && is_string( $shadow['spread'] ) ? $shadow['spread'] : '0px';
		$color  = '' !== $color ? $color : 'rgba(0,0,0,0.2)';
		$pos    = isset( $shadow['position'] ) ? strtolower( (string) $shadow['position'] ) : 'outer';
		$inset  = ( 'inner' === $pos || 'inset' === $pos ) ? 'inset ' : '';

		return trim( $inset . "$h $v $blur $spread $color" );
	}

	/**
	 * Collect per-field entries; fall back to legacy module-level attrs.
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 * @return list<array<string, mixed>>
	 */
	private function collect_entries_from_attrs( array $attrs ): array {
		$entries          = array();
		$module_tip_style = $this->collect_tip_style_from_attrs( $attrs );

		foreach ( $attrs as $attr_key => $attr_value ) {
			if ( ! is_string( $attr_key ) || ! str_starts_with( $attr_key, 'dsm_ctc_' ) ) {
				continue;
			}

			// Module-level tip Design attrs — not per-field compounds.
			if ( str_starts_with( $attr_key, 'dsm_ctc_tip_' ) ) {
				continue;
			}

			if ( ! is_array( $attr_value ) ) {
				continue;
			}

			$inner_content = isset( $attr_value['innerContent'] ) && is_array( $attr_value['innerContent'] )
				? $attr_value['innerContent']
				: null;
			$leaf          = $this->compound_leaf_at_mode( $inner_content, 'desktop' );
			if ( array() === $leaf ) {
				continue;
			}

			$on = isset( $leaf['on'] ) ? strtolower( (string) $leaf['on'] ) : 'off';
			if ( 'on' !== $on ) {
				continue;
			}

			$text = $this->leaf_text_string( $leaf['text'] ?? '' );
			$text = $this->resolve_dynamic_text( $text );

			// Label toggle only sets on + selector; empty "Text to copy" should
			// fall back to the source field (e.g. title / content) so FE matches VB.
			if ( '' === $text ) {
				$element_key = substr( $attr_key, strlen( 'dsm_ctc_' ) );
				$text        = $this->resolve_dynamic_text(
					$this->fallback_text_from_source_field( $attrs, $element_key )
				);
			}

			if ( '' === $text ) {
				continue;
			}

			$selector = $this->sanitize_selector(
				isset( $leaf['selector'] ) && is_string( $leaf['selector'] ) ? $leaf['selector'] : '',
				$attrs
			);

			if ( '' === $selector ) {
				continue;
			}

			$entry = $this->build_entry_from_leaf( $selector, $text, $leaf, $module_tip_style, $inner_content );

			/**
			 * Filters one Copy to Clipboard entry before FE output.
			 *
			 * @param array<string, mixed> $entry    Entry.
			 * @param string               $attr_key Attr key (e.g. dsm_ctc_title).
			 * @param array<string, mixed> $attrs    Module attrs.
			 */
			$entry = (array) apply_filters( 'dsm_click_to_copy_entry', $entry, $attr_key, $attrs );

			if (
				isset( $entry['selector'], $entry['text'] ) &&
				is_string( $entry['selector'] ) &&
				is_string( $entry['text'] ) &&
				'' !== $entry['selector'] &&
				'' !== $entry['text']
			) {
				$entries[] = $entry;
			}
		}

		if ( array() !== $entries ) {
			return $entries;
		}

		return $this->legacy_entries_from_attrs( $attrs );
	}

	/**
	 * Cascade-merge compound innerContent leaves for a breakpoint.
	 *
	 * @param array<string, mixed>|null $inner_content innerContent tree.
	 * @param string                    $mode          desktop|tablet|phone.
	 * @return array<string, mixed>
	 */
	private function compound_leaf_at_mode( ?array $inner_content, string $mode ): array {
		if ( null === $inner_content ) {
			return array();
		}

		// Ascending specificity so later breakpoints win (desktop → tablet → phone).
		$order = 'phone' === $mode
			? array( 'desktop', 'tablet', 'phone' )
			: ( 'tablet' === $mode ? array( 'desktop', 'tablet' ) : array( 'desktop' ) );

		$merged = array();
		foreach ( $order as $bp ) {
			$value = $inner_content[ $bp ]['value'] ?? null;
			if ( is_array( $value ) ) {
				$merged = array_merge( $merged, $value );
			}
		}

		return $merged;
	}

	/**
	 * Build one clipboard entry from a cascaded field leaf.
	 *
	 * @param string                    $selector         Relative selector.
	 * @param string                    $text             Clipboard text.
	 * @param array<string, mixed>      $leaf             Cascaded desktop compound value.
	 * @param array<string, mixed>      $module_tip_style Module Design tip tokens.
	 * @param array<string, mixed>|null $inner_content    Full innerContent for responsive tip overrides.
	 * @return array<string, mixed>
	 */
	private function build_entry_from_leaf( string $selector, string $text, array $leaf, array $module_tip_style, ?array $inner_content = null ): array {
		$success_text = $this->leaf_text_string( $leaf['success_text'] ?? 'Copied' );
		$success_text = $this->resolve_dynamic_text( $success_text );
		if ( '' === $success_text ) {
			$success_text = __( 'Copied', 'dsm-supreme-modules-pro-for-divi' );
		}

		$show_icon = isset( $leaf['success_show_icon'] )
			? strtolower( (string) $leaf['success_show_icon'] )
			: 'on';
		$show_icon = 'on' === $show_icon ? 'on' : 'off';

		$icon_html = '';
		if ( 'on' === $show_icon ) {
			$icon_settings = isset( $leaf['success_font_icon'] ) && is_array( $leaf['success_font_icon'] )
				? $leaf['success_font_icon']
				: $this->default_success_font_icon();
			$icon_html     = $this->build_icon_html( $icon_settings, 'dsm-ctc-copied-icon' );
		}

		$badge_show = isset( $leaf['badge_show'] )
			? strtolower( (string) $leaf['badge_show'] )
			: 'off';
		$badge_show = 'on' === $badge_show ? 'on' : 'off';

		$badge_placement = isset( $leaf['badge_placement'] )
			? strtolower( (string) $leaf['badge_placement'] )
			: 'after';
		$badge_placement = 'before' === $badge_placement ? 'before' : 'after';

		$badge_html = '';
		if ( 'on' === $badge_show ) {
			$badge_icon = isset( $leaf['badge_font_icon'] ) && is_array( $leaf['badge_font_icon'] )
				? $leaf['badge_font_icon']
				: $this->default_badge_font_icon();
			$badge_html = $this->build_icon_html( $badge_icon, 'dsm-ctc-copy-badge__glyph' );
		}

		$badge_color = $this->leaf_css_color_string( $leaf['badge_color'] ?? '' );
		$badge_size  = isset( $leaf['badge_size'] ) && is_string( $leaf['badge_size'] )
			? trim( $leaf['badge_size'] )
			: '14px';
		$badge_gap   = isset( $leaf['badge_gap'] ) && is_string( $leaf['badge_gap'] )
			? trim( $leaf['badge_gap'] )
			: '6px';

		if ( '' === $badge_size ) {
			$badge_size = '14px';
		}
		if ( '' === $badge_gap ) {
			$badge_gap = '6px';
		}

		return array(
			'selector'          => $selector,
			'text'              => $text,
			'badge_show'        => $badge_show,
			'badge_placement'   => $badge_placement,
			'badge_html'        => $badge_html,
			'badge_color'       => $badge_color,
			'badge_size'        => $badge_size,
			'badge_gap'         => $badge_gap,
			'success_text'      => $success_text,
			'success_show_icon' => $show_icon,
			'success_icon_html' => $icon_html,
			'success_duration'  => $this->sanitize_duration( $leaf['success_duration'] ?? '1500' ),
			'success_placement' => $this->sanitize_placement( $leaf['success_placement'] ?? 'top' ),
			'tip_style'         => $this->merge_entry_tip_style( $leaf, $module_tip_style, $inner_content ),
		);
	}

	/**
	 * Per-field tip overrides when tip_customize is on; else module defaults.
	 *
	 * @param array<string, mixed>      $leaf             Cascaded desktop compound (for tip_customize / arrow).
	 * @param array<string, mixed>      $module_tip_style Module tip tokens.
	 * @param array<string, mixed>|null $inner_content    Full innerContent for responsive tip_* keys.
	 * @return array<string, mixed>
	 */
	private function merge_entry_tip_style( array $leaf, array $module_tip_style, ?array $inner_content = null ): array {
		$customize = isset( $leaf['tip_customize'] )
			? strtolower( (string) $leaf['tip_customize'] )
			: 'off';

		// Always copy — never return the shared module tip_style by reference so
		// one field’s Customize Tooltip Style cannot mutate other entries.
		if ( 'on' !== $customize ) {
			return $this->copy_tip_style_tree( $module_tip_style );
		}

		$is_responsive = isset( $module_tip_style['desktop'] ) && is_array( $module_tip_style['desktop'] );
		if ( ! $is_responsive ) {
			return $this->apply_tip_style_overrides(
				$this->copy_tip_style_slice( $module_tip_style ),
				$this->compound_tip_string( $inner_content, $leaf, 'desktop', 'tip_bg_color' ),
				$this->compound_tip_string( $inner_content, $leaf, 'desktop', 'tip_text_color' ),
				$this->compound_tip_string( $inner_content, $leaf, 'desktop', 'tip_icon_color' ),
				$this->compound_tip_string( $inner_content, $leaf, 'desktop', 'tip_font_size' ),
				$this->compound_tip_string( $inner_content, $leaf, 'desktop', 'tip_border_radius' ),
				$this->compound_tip_arrow( $inner_content, $leaf, 'desktop' )
			);
		}

		$merged = array();
		foreach ( array( 'desktop', 'tablet', 'phone' ) as $bp ) {
			$base          = isset( $module_tip_style[ $bp ] ) && is_array( $module_tip_style[ $bp ] )
				? $module_tip_style[ $bp ]
				: array();
			$merged[ $bp ] = $this->apply_tip_style_overrides(
				$this->copy_tip_style_slice( $base ),
				$this->compound_tip_string( $inner_content, $leaf, $bp, 'tip_bg_color' ),
				$this->compound_tip_string( $inner_content, $leaf, $bp, 'tip_text_color' ),
				$this->compound_tip_string( $inner_content, $leaf, $bp, 'tip_icon_color' ),
				$this->compound_tip_string( $inner_content, $leaf, $bp, 'tip_font_size' ),
				$this->compound_tip_string( $inner_content, $leaf, $bp, 'tip_border_radius' ),
				$this->compound_tip_arrow( $inner_content, $leaf, $bp )
			);
		}

		return $merged;
	}

	/**
	 * Copy a responsive tip-style tree.
	 *
	 * @param array<string, mixed> $tree Nested or flat tip style.
	 * @return array<string, mixed>
	 */
	private function copy_tip_style_tree( array $tree ): array {
		if ( isset( $tree['desktop'] ) && is_array( $tree['desktop'] ) ) {
			$out = array();
			foreach ( array( 'desktop', 'tablet', 'phone' ) as $bp ) {
				$out[ $bp ] = isset( $tree[ $bp ] ) && is_array( $tree[ $bp ] )
					? $this->copy_tip_style_slice( $tree[ $bp ] )
					: array();
			}
			return $out;
		}

		return $this->copy_tip_style_slice( $tree );
	}

	/**
	 * Copy one breakpoint slice of tip style tokens.
	 *
	 * @param array<string, mixed> $slice Flat tip style tokens.
	 * @return array<string, mixed>
	 */
	private function copy_tip_style_slice( array $slice ): array {
		return array_merge( array(), $slice );
	}

	/**
	 * Cascaded non-empty tip style string from compound innerContent.
	 *
	 * @param array<string, mixed>|null $inner_content innerContent tree.
	 * @param array<string, mixed>      $desktop_leaf  Fallback desktop leaf.
	 * @param string                    $mode          desktop|tablet|phone.
	 * @param string                    $key           Compound key.
	 */
	private function compound_tip_string( ?array $inner_content, array $desktop_leaf, string $mode, string $key ): string {
		$cascaded = $this->compound_leaf_at_mode( $inner_content, $mode );
		if ( isset( $cascaded[ $key ] ) && is_string( $cascaded[ $key ] ) && '' !== trim( $cascaded[ $key ] ) ) {
			return trim( $cascaded[ $key ] );
		}

		if ( isset( $desktop_leaf[ $key ] ) && is_string( $desktop_leaf[ $key ] ) ) {
			return trim( $desktop_leaf[ $key ] );
		}

		return '';
	}

	/**
	 * Tip arrow setting for one breakpoint.
	 *
	 * @param array<string, mixed>|null $inner_content innerContent tree.
	 * @param array<string, mixed>      $desktop_leaf  Fallback desktop leaf.
	 * @param string                    $mode          desktop|tablet|phone.
	 */
	private function compound_tip_arrow( ?array $inner_content, array $desktop_leaf, string $mode ): string {
		$cascaded = $this->compound_leaf_at_mode( $inner_content, $mode );
		$raw      = $cascaded['tip_arrow'] ?? ( $desktop_leaf['tip_arrow'] ?? '' );

		if ( null === $raw || '' === $raw ) {
			return '';
		}

		$normalized = strtolower( trim( (string) $raw ) );
		if ( 'on' !== $normalized && 'off' !== $normalized ) {
			return '';
		}

		return $normalized;
	}

	/**
	 * Apply per-field tip style overrides onto a base slice.
	 *
	 * @param array<string, mixed> $base      Tip style slice.
	 * @param string               $bg        Override background.
	 * @param string               $text      Override text color.
	 * @param string               $icon      Override icon color.
	 * @param string               $font_size Override font size.
	 * @param string               $radius    Override radius.
	 * @param string               $arrow     Override arrow (on|off|'').
	 * @return array<string, mixed>
	 */
	private function apply_tip_style_overrides(
		array $base,
		string $bg,
		string $text,
		string $icon,
		string $font_size,
		string $radius,
		string $arrow
	): array {
		$merged = $this->copy_tip_style_slice( $base );
		if ( '' !== $bg ) {
			$merged['backgroundColor'] = $bg;
		}
		if ( '' !== $text ) {
			$merged['color'] = $text;
		}
		if ( '' !== $icon ) {
			$merged['iconColor'] = $icon;
		}
		if ( '' !== $font_size ) {
			$merged['fontSize'] = $font_size;
		}
		if ( '' !== $radius ) {
			$merged['borderRadius'] = $radius;
		}
		// Only explicit on|off overrides Design → Show Tooltip Arrow.
		if ( 'on' === $arrow || 'off' === $arrow ) {
			$merged['showArrow'] = ( 'on' === $arrow );
		}

		return $merged;
	}

	/**
	 * Default success icon (Font Awesome check).
	 *
	 * @return array{unicode: string, type: string, weight: string}
	 */
	private function default_success_font_icon(): array {
		return array(
			'unicode' => '&#xf00c;',
			'type'    => 'fa',
			'weight'  => '900',
		);
	}

	/**
	 * Default badge icon (Font Awesome copy).
	 *
	 * @return array{unicode: string, type: string, weight: string}
	 */
	private function default_badge_font_icon(): array {
		return array(
			'unicode' => '&#xf0c5;',
			'type'    => 'fa',
			'weight'  => '900',
		);
	}

	/**
	 * One character from `&#xHHHH;`, `&#DDDD;`, or a single non-ASCII glyph.
	 *
	 * @param string $unicode Stored or resolved unicode.
	 */
	private function icon_entity_to_char( string $unicode ): string {
		$unicode = trim( $unicode );

		if ( 1 === preg_match( '/^&#x[0-9a-fA-F]{1,6};$/', $unicode ) || 1 === preg_match( '/^&#[0-9]{1,7};$/', $unicode ) ) {
			$char = html_entity_decode( $unicode, ENT_QUOTES | ENT_HTML5, 'UTF-8' );

			if ( is_string( $char ) && '' !== $char && $char !== $unicode ) {
				return $char;
			}
		}

		if ( 1 === mb_strlen( $unicode ) && 1 !== preg_match( '/^[A-Za-z0-9]$/', $unicode ) ) {
			return $unicode;
		}

		return '';
	}

	/**
	 * Build Tippy/trigger-safe icon markup (DSM webfont or native FA/Divi).
	 *
	 * Tippy appends to `document.body`, so module-scoped `.et-pb-icon::before` CSS
	 * never applies — native glyphs must carry font-family inline.
	 *
	 * Supreme library icons are a text node too. The manager `::before` style
	 * quotes the family (`"Phosphor"`), and that quote breaks the JSON payload
	 * in the data attribute, so the frontend script never runs.
	 *
	 * @param array<string, mixed> $icon_settings Icon picker leaf.
	 * @param string               $extra_class   Extra class on the root span.
	 */
	private function build_icon_html( array $icon_settings, string $extra_class ): string {
		$classes = array_values(
			array_filter(
				array( sanitize_html_class( $extra_class ) )
			)
		);

		if (
			class_exists( IconLibraryRegistry::class ) &&
			IconLibraryRegistry::is_dsm_library_icon( $icon_settings )
		) {
			$this->pending_dsm_icons[] = $icon_settings;

			$font_family = class_exists( IconGlyphRenderer::class )
				? IconGlyphRenderer::icon_manager_font_family( $icon_settings )
				: '';
			$glyph       = '';

			if ( class_exists( '\ET\Builder\Packages\IconLibrary\IconFont\Utils' ) ) {
				$resolved = \ET\Builder\Packages\IconLibrary\IconFont\Utils::process_font_icon( $icon_settings, false, true );

				if ( is_string( $resolved ) && '' !== $resolved ) {
					$glyph = $this->icon_entity_to_char( $resolved );
				}
			}

			if ( '' === $glyph ) {
				$glyph = $this->icon_entity_to_char( (string) ( $icon_settings['unicode'] ?? '' ) );
			}

			if ( '' === $glyph || ( function_exists( 'mb_strlen' ) && mb_strlen( $glyph ) > 1 ) ) {
				$webfont = class_exists( IconGlyphRenderer::class )
					? IconGlyphRenderer::render_glyph_markup( $icon_settings )
					: '';

				if ( '' !== $webfont ) {
					return sprintf(
						'<span class="et-pb-icon %1$s dsm-webfont-icon-host" data-dsm-icon-render="glyph" aria-hidden="true">%2$s</span>',
						esc_attr( implode( ' ', $classes ) ),
						$webfont
					);
				}
			}

			$weight = preg_replace( '/[^0-9]/', '', (string) ( $icon_settings['weight'] ?? '' ) );

			if ( ! is_string( $weight ) || '' === $weight ) {
				$weight = '400';
			}

			if ( '' !== $glyph && '' !== $font_family && 1 === preg_match( '/^[A-Za-z0-9_-]+$/', $font_family ) ) {
				return sprintf(
					'<span class="et-pb-icon %1$s dsm-native-icon-host" aria-hidden="true"><i class="dsm-native-icon-glyph" style="font-family:%2$s;font-style:normal;font-weight:%3$s;" aria-hidden="true">%4$s</i></span>',
					esc_attr( implode( ' ', $classes ) ),
					esc_attr( $font_family ),
					esc_attr( $weight ),
					esc_html( $glyph )
				);
			}

			$fallback = 'dsm-ctc-copied-icon' === $extra_class ? '✓' : '⧉';

			return sprintf(
				'<span class="%1$s" aria-hidden="true">%2$s</span>',
				esc_attr( implode( ' ', $classes ) ),
				esc_html( $fallback )
			);
		}

		if ( class_exists( IconGlyphRenderer::class ) ) {
			$native = IconGlyphRenderer::render_native_icon_span(
				$icon_settings,
				$classes
			);

			if ( is_string( $native ) && '' !== $native ) {
				return $native;
			}
		}

		$glyph = null;
		if ( class_exists( ProcessFontIconHelper::class ) ) {
			$glyph = ProcessFontIconHelper::process( $icon_settings, false, false );
		}

		$class_attr = implode( ' ', $classes );

		if ( ! is_string( $glyph ) || '' === $glyph ) {
			$fallback = 'dsm-ctc-copied-icon' === $extra_class ? '✓' : '⧉';
			return sprintf(
				'<span class="%1$s" aria-hidden="true">%2$s</span>',
				esc_attr( $class_attr ),
				esc_html( $fallback )
			);
		}

		$type        = sanitize_key( (string) ( $icon_settings['type'] ?? 'fa' ) );
		$font_family = 'ETmodules';

		if ( IconProcessFontIconBridge::uses_icon_manager_font_family() ) {
			$resolved_family = IconGlyphRenderer::icon_manager_font_family( $icon_settings );

			if ( '' !== $resolved_family ) {
				$font_family = $resolved_family;
			}
		} elseif ( 'fa' === $type ) {
			$font_family = 'FontAwesome';
		}
		$weight = (string) ( $icon_settings['weight'] ?? ( 'fa' === $type ? '900' : '400' ) );

		return sprintf(
			'<span class="et-pb-icon %1$s dsm-native-icon-host" aria-hidden="true"><i class="dsm-native-icon-glyph" style="font-family:%2$s;font-style:normal;font-weight:%3$s;" aria-hidden="true">%4$s</i></span>',
			esc_attr( $class_attr ),
			esc_attr( $font_family ),
			esc_attr( $weight ),
			esc_html( $glyph )
		);
	}

	/**
	 * Clamp a tip duration to the allowed millisecond range.
	 *
	 * @param mixed $raw Duration leaf.
	 */
	private function sanitize_duration( $raw ): int {
		$ms = absint( is_scalar( $raw ) ? (string) $raw : '1500' );
		if ( $ms < 500 ) {
			$ms = 500;
		}
		if ( $ms > 10000 ) {
			$ms = 10000;
		}
		return $ms;
	}

	/**
	 * Sanitize a tip placement against the allowed list.
	 *
	 * @param mixed $raw Placement leaf.
	 */
	private function sanitize_placement( $raw ): string {
		$placement = is_string( $raw ) ? strtolower( trim( $raw ) ) : 'top';
		return in_array( $placement, self::PLACEMENTS, true ) ? $placement : 'top';
	}

	/**
	 * Legacy single-target attrs (pre per-field).
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 * @return list<array<string, mixed>>
	 */
	private function legacy_entries_from_attrs( array $attrs ): array {
		$enabled = $attrs['dsm_click_to_copy']['innerContent']['desktop']['value'] ?? 'off';
		if ( 'on' !== $enabled ) {
			return array();
		}

		$text = $this->resolve_dynamic_text( $this->get_legacy_copy_text_from_attrs( $attrs ) );
		if ( '' === $text ) {
			return array();
		}

		$selector = $this->sanitize_selector(
			$this->get_legacy_target_selector_from_attrs( $attrs ),
			$attrs
		);

		return array(
			$this->build_entry_from_leaf(
				$selector,
				$text,
				array(),
				$this->collect_tip_style_from_attrs( $attrs )
			),
		);
	}

	/**
	 * Read text from a string or heading-link leaf.
	 *
	 * @param mixed $leaf Text leaf (string or headingLink-like).
	 */
	private function leaf_text_string( $leaf ): string {
		if ( is_string( $leaf ) ) {
			return $leaf;
		}

		if ( is_array( $leaf ) && isset( $leaf['text'] ) && is_string( $leaf['text'] ) ) {
			return $leaf['text'];
		}

		return '';
	}

	/**
	 * Normalize a color-picker leaf to a CSS color string.
	 *
	 * @param mixed $leaf Color leaf (string, or rare nested shapes).
	 */
	private function leaf_css_color_string( $leaf ): string {
		if ( is_string( $leaf ) ) {
			return trim( $leaf );
		}

		if ( ! is_array( $leaf ) ) {
			return '';
		}

		foreach ( array( 'color', 'hex', 'value' ) as $key ) {
			if ( isset( $leaf[ $key ] ) && is_string( $leaf[ $key ] ) && '' !== trim( $leaf[ $key ] ) ) {
				return trim( $leaf[ $key ] );
			}
		}

		return '';
	}

	/**
	 * Clipboard fallback from the module field CTC is attached to (title, content, …).
	 *
	 * @param array<string, mixed> $attrs       Module attrs.
	 * @param string               $element_key Field root key (e.g. title).
	 */
	private function fallback_text_from_source_field( array $attrs, string $element_key ): string {
		if ( '' === $element_key || ! isset( $attrs[ $element_key ] ) || ! is_array( $attrs[ $element_key ] ) ) {
			return '';
		}

		$value = $attrs[ $element_key ]['innerContent']['desktop']['value'] ?? null;

		return $this->leaf_text_string( $value );
	}

	/**
	 * Relative CSS selector inside the module (empty allowed for legacy module-root bind).
	 *
	 * @param string               $selector Raw selector.
	 * @param array<string, mixed> $attrs    Module attrs.
	 */
	private function sanitize_selector( string $selector, array $attrs ): string {
		$selector = trim( $selector );

		/**
		 * Filters the relative Copy to Clipboard target selector.
		 *
		 * @param string               $selector Relative selector.
		 * @param array<string, mixed> $attrs    Module attrs.
		 */
		$selector = (string) apply_filters( 'dsm_click_to_copy_target_selector', $selector, $attrs );

		if ( '' === $selector ) {
			return '';
		}

		if ( preg_match( '/[<>"\']/', $selector ) ) {
			return '';
		}

		return $selector;
	}

	/**
	 * Legacy single-target selector from module attrs.
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 */
	private function get_legacy_target_selector_from_attrs( array $attrs ): string {
		$leaf = $attrs['dsm_click_to_copy_target']['innerContent']['desktop']['value'] ?? '';

		return is_string( $leaf ) ? $leaf : '';
	}

	/**
	 * Legacy clipboard text from module attrs.
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 */
	private function get_legacy_copy_text_from_attrs( array $attrs ): string {
		$leaf = $attrs['dsm_click_to_copy_text']['innerContent']['desktop']['value'] ?? '';

		return $this->leaf_text_string( $leaf );
	}

	/**
	 * Resolve Divi dynamic variables when possible; strip tags for clipboard safety.
	 *
	 * @param string $raw Raw attr value.
	 */
	private function resolve_dynamic_text( string $raw ): string {
		$text = $raw;

		if ( class_exists( \ET\Builder\Packages\StyleLibrary\Utils\Utils::class ) ) {
			$resolved = \ET\Builder\Packages\StyleLibrary\Utils\Utils::resolve_dynamic_variable( $text );
			if ( is_string( $resolved ) ) {
				$text = $resolved;
			}
		}

		$text = html_entity_decode( $text, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
		$text = wp_strip_all_tags( $text, false );
		$text = preg_replace( "/[ \t]+/u", ' ', $text ) ?? $text;
		$text = trim( $text );

		/**
		 * Filters the Copy to Clipboard clipboard string before FE output.
		 *
		 * @param string $text Resolved text.
		 */
		return (string) apply_filters( 'dsm_click_to_copy_text', $text );
	}
}
