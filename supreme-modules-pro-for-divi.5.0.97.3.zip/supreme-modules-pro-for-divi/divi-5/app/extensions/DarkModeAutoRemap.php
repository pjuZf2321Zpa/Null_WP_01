<?php
/**
 * Auto-remap painted module backgrounds when Dark Mode is on.
 *
 * Detects module.decoration.background paint and emits a solid palette
 * token under html.dsm-dark. Does not mutate stored attrs. Overrides win.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Extensions;

use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Frontend style bag for Dark Mode auto-remap of painted fills.
 */
class DarkModeAutoRemap {

	/**
	 * Modules that keep their own chrome (or are already remapped by palette CSS).
	 *
	 * @var array<int, string>
	 */
	private const SKIP_MODULES = array(
		'dsm/dark-mode-toggle',
		'divi/menu',
		'divi/fullwidth-menu',
		'divi/button',
		'divi/fullwidth-button',
	);

	/**
	 * Constructor.
	 */
	public function __construct() {
		if ( ! function_exists( 'dsm_is_dark_mode_extension_enabled' ) || ! dsm_is_dark_mode_extension_enabled() ) {
			return;
		}

		add_filter( 'divi_module_wrapper_render', array( $this, 'filter_wrapper_render_styles' ), 13, 2 );
	}

	/**
	 * Emit auto-remap background styles via Divi Style bag.
	 *
	 * @param string               $module_wrapper Wrapper HTML.
	 * @param array<string, mixed> $args           Wrapper filter args.
	 * @return string
	 */
	public function filter_wrapper_render_styles( $module_wrapper, $args ): string {
		if ( ! is_string( $module_wrapper ) ) {
			$module_wrapper = '';
		}

		if ( ! is_array( $args ) ) {
			return $module_wrapper;
		}

		$module_name = isset( $args['name'] ) ? (string) $args['name'] : '';
		if ( '' === $module_name || self::should_skip_module( $module_name ) || ! self::is_auto_remap_enabled() ) {
			return $module_wrapper;
		}

		$attrs = isset( $args['attrs'] ) && is_array( $args['attrs'] ) ? $args['attrs'] : array();

		if ( DarkModeOverrides::is_target_block( $module_name ) && DarkModeOverrides::attrs_enabled( $attrs ) ) {
			return $module_wrapper;
		}

		if ( ! self::decoration_background_has_opaque_paint( $attrs ) ) {
			return $module_wrapper;
		}

		$elements = $args['elements'] ?? null;
		if ( ! is_object( $elements ) ) {
			return $module_wrapper;
		}

		if ( ! class_exists( Style::class ) || ! class_exists( CommonStyle::class ) ) {
			return $module_wrapper;
		}

		$order_class = isset( $elements->order_class ) ? (string) $elements->order_class : '';
		if ( '' === $order_class ) {
			return $module_wrapper;
		}

		$selector = DarkModeOverrides::build_background_selector( $order_class, $module_name );

		/**
		 * Filter the CSS selector used for Dark Mode auto-remap.
		 *
		 * @param string               $selector    Full selector including html.dsm-dark.
		 * @param string               $order_class Module order class.
		 * @param string               $module_name Module name.
		 * @param array<string, mixed> $attrs       Module attrs.
		 */
		$selector = (string) apply_filters(
			'dsm_dark_mode_auto_remap_selector',
			$selector,
			$order_class,
			$module_name,
			$attrs
		);

		if ( '' === trim( $selector ) ) {
			return $module_wrapper;
		}

		$token = self::token_for_module( $module_name );

		/**
		 * Filter the CSS token used for Dark Mode auto-remap.
		 *
		 * Must be a `var(--dsm-dm-*)` custom property reference.
		 *
		 * @param string               $token       Palette token.
		 * @param string               $module_name Module name.
		 * @param array<string, mixed> $attrs       Module attrs.
		 */
		$token = (string) apply_filters( 'dsm_dark_mode_auto_remap_token', $token, $module_name, $attrs );
		if ( ! preg_match( '/^var\(--dsm-dm-[a-z0-9-]+\)$/', $token ) ) {
			$token = self::token_for_module( $module_name );
		}

		$color_attr = array(
			'desktop' => array(
				'value' => $token,
			),
		);
		$image_attr = array(
			'desktop' => array(
				'value' => 'none',
			),
		);

		Style::add(
			array(
				'id'            => (string) ( $args['id'] ?? '' ),
				'name'          => $module_name,
				'orderIndex'    => (int) ( $args['orderIndex'] ?? 0 ),
				'storeInstance' => (int) ( $args['storeInstance'] ?? 0 ),
				'styles'        => array(
					CommonStyle::style(
						array(
							'selector'  => $selector,
							'attr'      => $color_attr,
							'property'  => 'background-color',
							'important' => true,
						)
					),
					CommonStyle::style(
						array(
							'selector'  => $selector,
							'attr'      => $image_attr,
							'property'  => 'background-image',
							'important' => true,
						)
					),
				),
			)
		);

		return $module_wrapper;
	}

	/**
	 * Whether Design → Background has an opaque fill (not transparent / inherit).
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 * @return bool
	 */
	public static function decoration_background_has_opaque_paint( array $attrs ): bool {
		$bg = $attrs['module']['decoration']['background'] ?? null;
		if ( ! is_array( $bg ) ) {
			return false;
		}

		foreach ( array( 'desktop', 'tablet', 'phone' ) as $bp ) {
			$val = $bg[ $bp ]['value'] ?? null;
			if ( ! is_array( $val ) ) {
				continue;
			}

			$color = self::extract_color_string( $val['color'] ?? '' );
			if ( '' !== $color && ! self::color_is_non_paint( $color ) ) {
				return true;
			}

			if ( DarkModeOverrides::background_value_has_non_color_layers( $val ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Whether painted-fill auto-remap is enabled (Apply Surface to is not "none").
	 *
	 * @return bool
	 */
	public static function is_auto_remap_enabled(): bool {
		if ( ! isset( $GLOBALS['dsm_dark_mode_extension'] ) || ! $GLOBALS['dsm_dark_mode_extension'] instanceof DarkMode ) {
			return true;
		}

		return 'none' !== $GLOBALS['dsm_dark_mode_extension']->get_module_surface_mode();
	}

	/**
	 * Whether this module is excluded from auto-remap.
	 *
	 * @param string $module_name Module name.
	 * @return bool
	 */
	public static function should_skip_module( string $module_name ): bool {
		$skip = self::SKIP_MODULES;

		/**
		 * Filter modules excluded from Dark Mode auto-remap.
		 *
		 * @param array<int, string> $skip        Module names.
		 * @param string             $module_name Current module name.
		 */
		$skip = apply_filters( 'dsm_dark_mode_auto_remap_skip_modules', $skip, $module_name );

		if ( ! is_array( $skip ) ) {
			$skip = self::SKIP_MODULES;
		}

		return in_array( $module_name, $skip, true );
	}

	/**
	 * Palette token for a painted fill: page Background on structural blocks, Surface otherwise.
	 *
	 * @param string $module_name Module name.
	 * @return string
	 */
	public static function token_for_module( string $module_name ): string {
		return DarkModeOverrides::is_target_block( $module_name )
			? 'var(--dsm-dm-bg)'
			: 'var(--dsm-dm-surface)';
	}

	/**
	 * Normalize a ColorPicker leaf to a CSS color string.
	 *
	 * @param mixed $color Stored color.
	 * @return string
	 */
	public static function extract_color_string( $color ): string {
		if ( is_string( $color ) ) {
			return trim( $color );
		}

		if ( is_int( $color ) || is_float( $color ) ) {
			return (string) $color;
		}

		if ( ! is_array( $color ) ) {
			return '';
		}

		foreach ( array( 'hex', 'rgba', 'color', 'value' ) as $key ) {
			if ( ! isset( $color[ $key ] ) ) {
				continue;
			}

			$piece = $color[ $key ];
			if ( is_string( $piece ) && '' !== trim( $piece ) ) {
				return trim( $piece );
			}
		}

		return trim( DarkModeOverrides::stringify_color_leaf( $color ) );
	}

	/**
	 * Transparent / inherit leaves should not trigger auto-remap.
	 *
	 * @param string $color Color string.
	 * @return bool
	 */
	public static function color_is_non_paint( string $color ): bool {
		$normalized = strtolower( trim( $color ) );
		if ( '' === $normalized ) {
			return true;
		}

		if ( in_array( $normalized, array( 'transparent', 'inherit' ), true ) ) {
			return true;
		}

		if ( preg_match( '/^rgba?\(\s*0\s*,\s*0\s*,\s*0\s*,\s*0(?:\.0+)?\s*\)$/', $normalized ) ) {
			return true;
		}

		if ( preg_match( '/^#(?:fff0|ffff0000|0000|00000000)$/i', $normalized ) ) {
			return true;
		}

		return false;
	}
}

new DarkModeAutoRemap();
