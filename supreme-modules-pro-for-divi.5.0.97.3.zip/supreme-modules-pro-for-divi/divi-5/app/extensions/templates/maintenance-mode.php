<?php
/**
 * Full-page Maintenance Mode template (Divi Library layout as main query).
 *
 * Uses Divi’s normal `#et-boc` / Static CSS / Dynamic Assets pipeline so module
 * styles match Visual Builder and frontend pages.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="robots" content="noindex, nofollow">
	<?php wp_head(); ?>
</head>
<body <?php body_class( 'dsm-maintenance-mode et_pb_pagebuilder_layout et_no_sidebar' ); ?>>
	<div id="page-container">
		<div id="et-boc" class="et-boc">
			<div id="et-main-area">
				<div id="main-content">
					<div class="container">
						<div id="content-area" class="clearfix">
							<div id="left-area">
								<?php
								while ( have_posts() ) :
									the_post();
									?>
									<article id="post-<?php the_ID(); ?>" <?php post_class( 'et_pb_post' ); ?>>
										<div class="entry-content">
											<?php
											/*
											 * Prefer Divi’s content pipeline so StaticCSS / Dynamic Assets
											 * attach to this library layout post ID.
											 */
											the_content();
											?>
										</div>
									</article>
									<?php
								endwhile;
								?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<?php wp_footer(); ?>
</body>
</html>
