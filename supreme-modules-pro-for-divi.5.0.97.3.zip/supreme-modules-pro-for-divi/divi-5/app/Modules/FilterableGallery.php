<?php
/**
 * Text Badge Module.
 *
 * @package DiviSupreme.
 */

declare(strict_types=1);

namespace DiviSupreme\Modules;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\Module\Options\Element\ElementClassnames;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\Packages\ModuleUtils\ModuleUtils;
use ET\Builder\Packages\Module\Layout\Components\ModuleElements\ModuleElements;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\Module\Options\Text\TextStyle;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;
use DiviSupreme\Includes\DsmFrontendAssetRegistry;
use DiviSupreme\Utils\HeadingLevel;


/**
 * Class that handles "FilterableGallery Module" module.
 */
class FilterableGallery implements DependencyInterface {



	/**
	 * Register module.
	 * `DependencyInterface` interface ensures class method name `load()` is executed for initialization.
	 */
	public function load() {
		add_action( 'init', array( self::class, 'register_module' ) );
	}

	/**
	 * Initilises the module.
	 *
	 * @return void
	 */
	public static function dsm_initialise() {
		add_action(
			'divi_module_library_modules_dependency_tree',
			function ( $dependency_tree ) {
				$dependency_tree->add_dependency( new self() );
			}
		);
	}

	/**
	 * Register module.
	 */
	public static function register_module() {

		$module_json_path = DSM_DIR_PATH . 'divi-5/public/packages/module-library/filterable-gallery';

		ModuleRegistration::register_module(
			$module_json_path,
			array(
				'render_callback' => array( self::class, 'render_callback' ),
			)
		);
	}

	/**
	 * Normalize a range / string leaf from innerContent to a single CSS dimension token (e.g. 10px).
	 *
	 * @param mixed $leaf innerContent desktop|tablet|phone leaf.
	 * @return string Non-empty token or empty string.
	 */
	private static function filterable_gallery_gap_css_token_from_leaf( $leaf ): string {
		if ( is_string( $leaf ) ) {
			$t = trim( $leaf );

			return '' !== $t ? $t : '';
		}
		if ( ! is_array( $leaf ) ) {
			return '';
		}
		if ( isset( $leaf['value'] ) ) {
			$v = $leaf['value'];
			if ( is_string( $v ) || is_numeric( $v ) ) {
				$vs = trim( (string) $v );
				if ( '' === $vs ) {
					return '';
				}
				$u = ( isset( $leaf['unit'] ) && is_string( $leaf['unit'] ) && '' !== $leaf['unit'] )
					? $leaf['unit']
					: 'px';

				return $vs . $u;
			}
		}

		return '';
	}

	/**
	 * Read gap token for one breakpoint from attrs (no cross-breakpoint fallback).
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 * @param string               $attr_key e.g. dsm_column_gap.
	 * @param string               $breakpoint desktop|tablet|phone.
	 */
	private static function filterable_gallery_gap_token_at_breakpoint( array $attrs, string $attr_key, string $breakpoint ): string {
		$inner = $attrs[ $attr_key ]['innerContent'] ?? array();
		if ( ! is_array( $inner ) ) {
			return '';
		}
		$bucket = $inner[ $breakpoint ] ?? array();
		if ( ! is_array( $bucket ) ) {
			return '';
		}
		$leaf = $bucket['value'] ?? null;

		return self::filterable_gallery_gap_css_token_from_leaf( $leaf );
	}

	/**
	 * Leading number from a gap token for Shuffle `gutterWidth` data attributes (px semantics).
	 *
	 * @param string $token e.g. 10px, 1.5rem (rem treated as number only for Shuffle).
	 */
	private static function filterable_gallery_gap_numeric_string_for_shuffle( string $token ): string {
		if ( '' === $token ) {
			return '0';
		}
		if ( 1 === preg_match( '/([-0-9.]+)/', $token, $m ) ) {
			$n = (float) $m[1];

			return (string) max( 0, $n );
		}

		return '0';
	}

	/**
	 * Divi Toggle / legacy yes-no: whether innerContent desktop value means “on”.
	 *
	 * @param mixed $raw Leaf value from attrs (string/bool/int).
	 */
	private static function filterable_gallery_inner_toggle_is_on( $raw ): bool {
		if ( true === $raw || 1 === $raw ) {
			return true;
		}
		if ( false === $raw || 0 === $raw ) {
			return false;
		}
		if ( ! is_scalar( $raw ) ) {
			return false;
		}

		return in_array(
			strtolower( trim( (string) $raw ) ),
			array( 'on', 'yes', 'true', '1' ),
			true
		);
	}

	/**
	 * Data attributes on the Shuffle root so JS can pass responsive `gutterWidth` (horizontal) without CSS margin-right.
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 * @return string Space-prefixed HTML attributes or empty string.
	 */
	private static function filterable_gallery_shuffle_gutter_data_attributes_string( array $attrs ): string {
		$d = self::filterable_gallery_gap_token_at_breakpoint( $attrs, 'dsm_column_gap', 'desktop' );
		$t = self::filterable_gallery_gap_token_at_breakpoint( $attrs, 'dsm_column_gap', 'tablet' );
		$p = self::filterable_gallery_gap_token_at_breakpoint( $attrs, 'dsm_column_gap', 'phone' );
		if ( '' === $t ) {
			$t = $d;
		}
		if ( '' === $p ) {
			$p = '' !== $t ? $t : $d;
		}
		$nd = self::filterable_gallery_gap_numeric_string_for_shuffle( '' !== $d ? $d : '0px' );
		$nt = self::filterable_gallery_gap_numeric_string_for_shuffle( '' !== $t ? $t : ( '' !== $d ? $d : '0px' ) );
		$np = self::filterable_gallery_gap_numeric_string_for_shuffle( '' !== $p ? $p : ( '' !== $t ? $t : ( '' !== $d ? $d : '0px' ) ) );

		return sprintf(
			' data-shuffle-gutter-desktop="%s" data-shuffle-gutter-tablet="%s" data-shuffle-gutter-phone="%s"',
			esc_attr( $nd ),
			esc_attr( $nt ),
			esc_attr( $np )
		);
	}

	/**
	 * Column count for grid / responsive `sizes` (1–6).
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 */
	private static function filterable_gallery_columns_count( array $attrs ): int {
		$raw = $attrs['dsm_number_of_columns']['innerContent']['desktop']['value'] ?? '3';

		return max( 1, min( 6, (int) $raw ) );
	}

	/**
	 * `sizes` attribute so the browser picks an appropriate `srcset` candidate per column count.
	 *
	 * @param int $columns Number of columns (1–6).
	 */
	private static function filterable_gallery_responsive_sizes_attr( int $columns ): string {
		$columns = max( 1, min( 6, $columns ) );
		$vw      = (int) round( 100 / $columns );

		return sprintf(
			'(max-width: 767px) 100vw, (max-width: 980px) 50vw, %dvw',
			$vw
		);
	}

	/**
	 * Extra attributes on the Shuffle root (gutters, columns, pre-layout CSS variables).
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 */
	private static function filterable_gallery_inner_container_extra_attributes_string( array $attrs ): string {
		$cols = self::filterable_gallery_columns_count( $attrs );

		return self::filterable_gallery_shuffle_gutter_data_attributes_string( $attrs ) . sprintf(
			' data-columns="%1$d" style="--dsm-fg-cols:%1$d"',
			$cols
		);
	}

	/**
	 * Full-size (or large) URL for lightbox / `data-mfp-src` — grid uses `dsm_image_sizes`.
	 *
	 * @param int $attachment_id Attachment ID.
	 */
	private static function filterable_gallery_lightbox_image_url( int $attachment_id ): string {
		$url = wp_get_attachment_image_url( $attachment_id, 'full' );
		if ( is_string( $url ) && '' !== $url ) {
			return $url;
		}

		$url = wp_get_attachment_image_url( $attachment_id, 'large' );

		return is_string( $url ) ? $url : '';
	}

	/**
	 * Render module style.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_styles( $args ) {
		$args                  = \DiviSupreme\Includes\DsmDiviBuilderCssScope::normalize_module_styles_args( $args );
		$attrs                 = $args['attrs'] ?? array();
		$elements              = $args['elements'];
		$dsm_custom_row_height = $attrs['dsm_custom_row_height']['innerContent']['desktop']['value'] ?? '';
		$dsm_auto_height       = $attrs['dsm_auto_height']['innerContent']['desktop']['value'] ?? '';
		$dsm_auto_height_on    = self::filterable_gallery_inner_toggle_is_on( $dsm_auto_height );
		$dsm_layout            = $attrs['dsm_layout']['innerContent']['desktop']['value'] ?? '';

		Style::add(
			array(
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => array(
					// Module.
					$elements->style(
						array(
							'attrName'   => 'module',
							'styleProps' => array(
								'disabledOn' => array(
									'disabledModuleVisibility' => $args['settings']['disabledModuleVisibility'] ?? null,
								),
							),
						)
					),

					CssStyle::style(
						array(
							'selector' => $args['orderClass'],
							'attr'     => $attrs['css'] ?? array(),
						)
					),

					$elements->style(
						array(
							'attrName' => 'header',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_caption',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_description',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_overlay_padding',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_category_margin',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_category_padding',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_category',
						)
					),

					$elements->style(
						array(
							'attrName' => 'category_tab_style',
						)
					),

					$elements->style(
						array(
							'attrName' => 'category_tab_active_style',
						)
					),

					$elements->style(
						array(
							'attrName' => 'loadmore_style',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_load_more',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_load_more_padding',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_load_more_margin',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_pagination',
						)
					),

					$elements->style(
						array(
							'attrName' => 'pagination_style',
						)
					),

					$elements->style(
						array(
							'attrName' => 'pagination_active_style',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_pagination_padding',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_pagination_margin',
						)
					),

					$elements->style(
						array(
							'attrName' => 'card_style',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_card_padding',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_image_wrapper_margin',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_image_wrapper_padding',
						)
					),

					$elements->style(
						array(
							'attrName' => 'image_style',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_content_wrapper_margin',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_content_wrapper_padding',
						)
					),

					$elements->style(
						array(
							'attrName' => 'content_wrapper_style',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-filterable-gallery-item .dsm-filterable-gallery-inner-item",
							'attr'     => $attrs['dsm_card_bg_color']['innerContent'] ?? array(),
							'property' => 'background-color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-filterable-gallery-container .dsm-filterable-gallery-item",
							'attr'     => $attrs['dsm_row_gap']['innerContent'] ?? array(),
							'property' => 'margin-bottom',
						)
					),

					( ! $dsm_auto_height_on && 'overlay' === $dsm_layout ) ?

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-filterable-gallery-container .dsm-filterable-gallery-item .dsm-filterable-gallery-image-wrapper img",
							'attr'     => $attrs['dsm_image_height']['innerContent'] ?? array(),
							'property' => 'height',
						)
					) : '',

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-filterable-gallery-container .dsm-filterable-gallery-item:hover .dsm-filterable-gallery-image-wrapper::before",
							'attr'     => $attrs['dsm_overlay_color']['innerContent'] ?? array(),
							'property' => 'background-color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-filterable-gallery-container .dsm-filterable-gallery-item .dsm-filterable-gallery-image-wrapper::before, {$args['orderClass']} .dsm-filterable-gallery-container .dsm-filterable-gallery-item .dsm-filterable-gallery-content-wrapper",
							'attr'     => $attrs['dsm_hover_transition']['innerContent'] ?? array(),
							'property' => 'transition',
						)
					),

					'on' === $dsm_custom_row_height ?
					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-filterable-gallery-container .dsm-filterable-gallery-item",
							'attr'     => $attrs['dsm_row_height']['innerContent'] ?? array(),
							'property' => 'min-height',
						)
					)
					: '',

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm-filterable-gallery-container .dsm-filterable-gallery-item",
							'attr'                => $attrs['dsm_number_of_columns']['innerContent'] ?? array(),
							'declarationFunction' => function ( $params ) use ( $attrs ) {
								$cols_raw = $params['attrValue'] ?? '1';
								$cols     = max( 1, absint( (string) $cols_raw ) );
								$bp       = $params['breakpoint'] ?? 'desktop';
								$gap      = self::filterable_gallery_gap_token_at_breakpoint( $attrs, 'dsm_column_gap', (string) $bp );
								if ( '' === $gap && 'tablet' === $bp ) {
									$gap = self::filterable_gallery_gap_token_at_breakpoint( $attrs, 'dsm_column_gap', 'desktop' );
								}
								if ( '' === $gap && 'phone' === $bp ) {
									$gap = self::filterable_gallery_gap_token_at_breakpoint( $attrs, 'dsm_column_gap', 'tablet' );
									if ( '' === $gap ) {
										$gap = self::filterable_gallery_gap_token_at_breakpoint( $attrs, 'dsm_column_gap', 'desktop' );
									}
								}
								if ( '' === $gap ) {
									$gap = '0px';
								}
								$slots = max( 0, $cols - 1 );

								$style_declarations = new StyleDeclarations(
									array(
										'returnType' => 'string',
										'important'  => array(
											'width' => true,
										),
									)
								);

								$style_declarations->add(
									'width',
									sprintf( 'calc((100%% - %d * %s) / %d)', $slots, $gap, $cols )
								);

								return $style_declarations->value();
							},
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm-filterable-gallery-container .dsm-filterable-category-container",
							'attr'                => $attrs['dsm_category_alignment']['innerContent'] ?? array(),
							'declarationFunction' => function ( $params ) {
								$attr = $params['attrValue'] ?? array();

								$style_declarations = new StyleDeclarations(
									array(
										'returnType' => 'string',
										'important'  => array(
											'justify-content' => true,
										),
									)
								);

								if ( 'left' === $attr ) {
									$style_declarations->add( 'justify-content', 'flex-start' );
								}

								if ( 'center' === $attr ) {
									$style_declarations->add( 'justify-content', 'center' );
								}

								if ( 'right' === $attr ) {
									$style_declarations->add( 'justify-content', 'flex-end' );
								}

								return $style_declarations->value();
							},
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-filterable-gallery-container .dsm-filterable-category-container .dsm-filterable-gallery-filter-item",
							'attr'     => $attrs['dsm_category_inactive_bg_color']['innerContent'] ?? array(),
							'property' => 'background-color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-filterable-gallery-container .dsm-filterable-category-container .dsm-filterable-gallery-filter-item.dsm-active-filter",
							'attr'     => $attrs['dsm_category_active_bg_color']['innerContent'] ?? array(),
							'property' => 'background-color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-filterable-gallery-container .dsm-filterable-category-container .dsm-filterable-gallery-filter-item",
							'attr'     => $attrs['dsm_category_inactive_color']['innerContent'] ?? array(),
							'property' => 'color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-filterable-gallery-container .dsm-filterable-category-container .dsm-filterable-gallery-filter-item.dsm-active-filter",
							'attr'     => $attrs['dsm_category_active_color']['innerContent'] ?? array(),
							'property' => 'color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-gallery-loadmore-button",
							'attr'     => $attrs['dsm_load_more_bg_color']['innerContent'] ?? array(),
							'property' => 'background-color',
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm-gallery-loadmore-container",
							'attr'                => $attrs['dsm_loadmore_alignment']['innerContent'] ?? array(),
							'declarationFunction' => function ( $params ) {
								$attr = $params['attrValue'] ?? array();

								$style_declarations = new StyleDeclarations(
									array(
										'returnType' => 'string',
										'important'  => array(
											'justify-content' => true,
										),
									)
								);

								if ( 'left' === $attr ) {
									$style_declarations->add( 'justify-content', 'flex-start' );
								}

								if ( 'center' === $attr ) {
									$style_declarations->add( 'justify-content', 'center' );
								}

								if ( 'right' === $attr ) {
									$style_declarations->add( 'justify-content', 'flex-end' );
								}

								return $style_declarations->value();
							},
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm-gallery-number-pagination-container",
							'attr'                => $attrs['dsm_pagination_alignment']['innerContent'] ?? array(),
							'declarationFunction' => function ( $params ) {
								$attr = $params['attrValue'] ?? array();

								$style_declarations = new StyleDeclarations(
									array(
										'returnType' => 'string',
										'important'  => array(
											'justify-content' => true,
										),
									)
								);

								if ( 'left' === $attr ) {
									$style_declarations->add( 'justify-content', 'flex-start' );
								}

								if ( 'center' === $attr ) {
									$style_declarations->add( 'justify-content', 'center' );
								}

								if ( 'right' === $attr ) {
									$style_declarations->add( 'justify-content', 'flex-end' );
								}

								return $style_declarations->value();
							},
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-gallery-number-pagination-container .dsm-gallery-number-pagination",
							'attr'     => $attrs['dsm_pagination_inactive_bg_color']['innerContent'] ?? array(),
							'property' => 'background-color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-gallery-number-pagination-container .dsm-gallery-number-pagination.dsm-active-pagination-item",
							'attr'     => $attrs['dsm_pagination_active_bg_color']['innerContent'] ?? array(),
							'property' => 'background-color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-gallery-number-pagination-container .dsm-gallery-number-pagination",
							'attr'     => $attrs['dsm_pagination_inactive_color']['innerContent'] ?? array(),
							'property' => 'color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-gallery-number-pagination-container .dsm-gallery-number-pagination.dsm-active-pagination-item",
							'attr'     => $attrs['dsm_pagination_active_color']['innerContent'] ?? array(),
							'property' => 'color',
						)
					),
				),
			)
		);
	}

	/**
	 * Render module script data.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_script_data( $args ) {
		$elements = $args['elements'];

		// Element Script Data Options.
		$elements->script_data(
			array(
				'attrName' => 'module',
			)
		);
	}

	/**
	 * Render module classnames.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_classnames( $args ) {
		$classnames_instance = $args['classnamesInstance'];
		$attrs               = $args['attrs'];
		$dsm_layout          = $attrs['dsm_layout']['innerContent']['desktop']['value'] ?? '';
		$dsm_hover_style     = $attrs['dsm_hover_style']['innerContent']['desktop']['value'] ?? '';

		// Module.
		$classnames_instance->add(
			ElementClassnames::classnames(
				array(
					'attrs' => $attrs['module']['decoration'] ?? array(),
				)
			)
		);

		$classnames_instance->add( "dsm-filterable-gallery-layout-$dsm_layout" );
		$classnames_instance->add( "dsm-filterable-gallery-$dsm_hover_style" );
	}

	/**
	 * Get gallery.
	 *
	 * @param mixed $args             Args.
	 * @param mixed $conditional_tags Conditional tags.
	 * @param mixed $current_page     Current page.
	 */
	public static function get_gallery( $args = array(), $conditional_tags = array(), $current_page = array() ) {
		$attachments = array();

		$defaults = array(
			'gallery_ids'        => array(),
			'gallery_orderby'    => '',
			'include_categories' => '',
			'posts_per_page'     => 10,
			'order'              => 'ASC',
			'dsm_sortby'         => '',
		);

		$args = wp_parse_args( $args, $defaults );

		// For Pagination.
		$current_page = 0;
		$per_page     = (int) $args['posts_per_page'];
		$offset       = $current_page * $per_page;

		$attachments_args = array(
			'include'        => $args['gallery_ids'],
			'post_status'    => 'inherit',
			'post_type'      => 'attachment',
			'post_mime_type' => 'image',
			'order'          => $args['order'],
			'orderby'        => 'post__in',
			'numberposts'    => isset( $args['max'] ) ? $args['max'] : -1,
			'dsm_sortby'     => $args['dsm_sortby'],
		);

		if ( $args['use_dynamic'] ) {
			// Unsetting selected images.
			unset( $attachments_args['orderby'] );
			unset( $attachments_args['include'] );

			$cat_ids_as_int = is_array( $args['categories'] )
				? array_map( 'intval', $args['categories'] )
				: array_map(
					function ( $cat ) {
						return (int) $cat;
					},
					explode( ',', (string) ( $args['categories'] ?? '' ) )
				);

			$attachments_args['tax_query'] = array(
				array(
					'taxonomy' => 'dsm-attachment-category',
					'field'    => 'term_id',
					'terms'    => $cat_ids_as_int,
				),
			);
		}

		if ( 'rand' === $args['gallery_orderby'] ) {
			$attachments_args['orderby'] = 'rand';
		}

		$_attachments = get_posts( $attachments_args );

		foreach ( $_attachments as $key => $val ) {
			$attachments[ $key ]                 = $_attachments[ $key ];
			$attachments[ $key ]->image_src_full = wp_get_attachment_image_src( $val->ID, 'full' );
			$attachments[ $key ]->description    = $val->post_content;
		}

		return array_chunk( $attachments, $per_page );
	}

	/**
	 * Get attachments.
	 *
	 * @param mixed $args   Args.
	 */
	public static function get_attachments( $args = array() ) {
		return self::get_gallery( $args );
	}

	/**
	 * Obtains necessary markup for loadmore pagination.
	 *
	 * @param mixed $dsm_load_more_text Dsm load more text.
	 * @return string - Markup.
	 */
	public static function get_loadmore_pagination( $dsm_load_more_text ) {
		$label = esc_attr__( 'Load more gallery images', 'dsm-supreme-modules-pro-for-divi' );

		return sprintf(
			'<div class="dsm-gallery-loadmore-container" role="navigation" aria-label="%1$s"><button type="button" class="dsm-gallery-loadmore-button">%2$s</button></div>',
			$label,
			wp_kses_post( $dsm_load_more_text )
		);
	}


	/**
	 * Obtains necessary markup for number pagination.
	 *
	 * @param array $attachments              - Attachments to create pagination for.
	 * @param mixed $dsm_tidy_up_pagination   Dsm tidy up pagination.
	 * @param mixed $dsm_pagination_prev_text Dsm pagination prev text.
	 * @param mixed $dsm_pagination_next_text Dsm pagination next text.
	 * @return string - Markup.
	 */
	public static function get_number_pagination( $attachments, $dsm_tidy_up_pagination, $dsm_pagination_prev_text, $dsm_pagination_next_text ) {

		$total_pages         = count( $attachments );
		$has_next_prev_links = true;

		$markup = '';

		$nav_label = esc_attr__( 'Gallery pagination', 'dsm-supreme-modules-pro-for-divi' );
		$prev_text = $dsm_pagination_prev_text;
		$next_text = $dsm_pagination_next_text;

		for ( $page = 0; $page < $total_pages; $page++ ) {
			$normalized_page_index = $page + 1;
			/* translators: %d: page number */
			$page_label = esc_attr( sprintf( __( 'Go to page %d', 'dsm-supreme-modules-pro-for-divi' ), $normalized_page_index ) );
			$markup    .= sprintf(
				'<button type="button" class="dsm-gallery-number-pagination" data-pagination="%1$d" aria-label="%2$s">%1$d</button>',
				$normalized_page_index,
				$page_label
			);
		}

		if ( $has_next_prev_links ) {

			$prev_plain = wp_strip_all_tags( $prev_text );
			$next_plain = wp_strip_all_tags( $next_text );

			$markup  = sprintf(
				'<button type="button" class="dsm-gallery-number-pagination" data-pagination="prev" aria-label="%1$s">%2$s</button>',
				esc_attr( $prev_plain ),
				esc_html( $prev_plain )
			) . $markup;
			$markup .= sprintf(
				'<button type="button" class="dsm-gallery-number-pagination" data-pagination="next" aria-label="%1$s">%2$s</button>',
				esc_attr( $next_plain ),
				esc_html( $next_plain )
			);
		}

		return sprintf(
			'<div class="dsm-gallery-number-pagination-container" role="navigation" aria-label="%5$s" data-pagination-prev-text="%2$s" data-pagination-next-text="%3$s" data-tidy-pagination="%4$s">%1$s</div>',
			$markup,
			wp_strip_all_tags( $prev_text ),
			wp_strip_all_tags( $next_text ),
			$dsm_tidy_up_pagination,
			$nav_label
		);
	}

	/**
	 * Render module HTML output.
	 *
	 * @param array     $attrs - Modules Attributes.
	 * @param string    $content - Content.
	 * @param \WP_Block $block - Block.
	 * @param mixed     $elements - Elements.
	 */
	public static function render_callback( $attrs, $content, $block, $elements ) {
		if ( DsmFrontendAssetRegistry::should_wp_enqueue_module_scripts( 'dsm/filterable-gallery' ) ) {
			wp_enqueue_script( 'dsm-filterable-library-gallery' );
			wp_enqueue_script( 'dsm-filterable-gallery' );
		}

		$gallery_ids                   = $attrs['gallery_ids']['innerContent']['desktop']['value'] ?? '';
		$dsm_per_page                  = $attrs['dsm_per_page']['innerContent']['desktop']['value'] ?? '';
		$dsm_query_order               = $attrs['dsm_query_order']['innerContent']['desktop']['value'] ?? '';
		$dsm_include_categories        = $attrs['dsm_include_categories']['innerContent']['desktop']['value'] ?? '';
		$dsm_total_number_images       = $attrs['dsm_total_number_images']['innerContent']['desktop']['value'] ?? '';
		$dsm_use_dynamic_images        = $attrs['dsm_use_dynamic_images']['innerContent']['desktop']['value'] ?? '';
		$dsm_show_title                = $attrs['dsm_show_title']['innerContent']['desktop']['value'] ?? '';
		$dsm_show_caption              = $attrs['dsm_show_caption']['innerContent']['desktop']['value'] ?? '';
		$dsm_show_description          = $attrs['dsm_show_description']['innerContent']['desktop']['value'] ?? '';
		$dsm_show_title_lightbox       = $attrs['dsm_show_title_lightbox']['innerContent']['desktop']['value'] ?? '';
		$dsm_show_caption_lightbox     = $attrs['dsm_show_caption_lightbox']['innerContent']['desktop']['value'] ?? '';
		$dsm_show_description_lightbox = $attrs['dsm_show_description_lightbox']['innerContent']['desktop']['value'] ?? '';
		$dsm_image_sizes               = $attrs['dsm_image_sizes']['innerContent']['desktop']['value'] ?? '';
		if ( ! is_string( $dsm_image_sizes ) || '' === trim( $dsm_image_sizes ) ) {
			$dsm_image_sizes = 'medium';
		}
		$columns_count    = self::filterable_gallery_columns_count( $attrs );
		$image_sizes_attr = self::filterable_gallery_responsive_sizes_attr( $columns_count );
		$heading_level    = HeadingLevel::sanitize(
			$attrs['header']['decoration']['font']['font']['desktop']['value']['headingLevel'] ?? '',
			'h4'
		);
		$dsm_use_lightbox = $attrs['dsm_use_lightbox']['innerContent']['desktop']['value'] ?? '';

		if ( 'on' === $dsm_use_lightbox ) {
			if ( function_exists( 'dsm_ensure_registered_script_dependency' ) && function_exists( 'dsm_get_active_magnific_popup_script_handle' ) ) {
				dsm_ensure_registered_script_dependency(
					'dsm-filterable-library-gallery',
					dsm_get_active_magnific_popup_script_handle()
				);
			}
			if ( function_exists( 'dsm_enqueue_magnific_popup_assets' ) ) {
				dsm_enqueue_magnific_popup_assets();
			}
		}

		$dsm_speed                       = $attrs['dsm_speed']['innerContent']['desktop']['value'] ?? '';
		$dsm_show_pagination             = $attrs['dsm_show_pagination']['innerContent']['desktop']['value'] ?? '';
		$dsm_pagination_type             = $attrs['dsm_pagination_type']['innerContent']['desktop']['value'] ?? '';
		$dsm_use_zoom_on_hover           = $attrs['dsm_use_zoom_on_hover']['innerContent']['desktop']['value'] ?? '';
		$dsm_show_filterable_gallery     = $attrs['dsm_show_filterable_gallery']['innerContent']['desktop']['value'] ?? '';
		$dsm_show_all_images_text        = $attrs['dsm_show_all_images_text']['innerContent']['desktop']['value'] ?? '';
		$dsm_filterable_gallery_all_text = $attrs['dsm_filterable_gallery_all_text']['innerContent']['desktop']['value'] ?? '';
		$dsm_sortby                      = $attrs['dsm_sortby']['innerContent']['desktop']['value'] ?? '';
		$dsm_load_more_text              = $attrs['dsm_load_more_text']['innerContent']['desktop']['value'] ?? '';
		$dsm_tidy_up_pagination          = $attrs['dsm_tidy_up_pagination']['innerContent']['desktop']['value'] ?? '';
		$dsm_pagination_prev_text        = $attrs['dsm_pagination_prev_text']['innerContent']['desktop']['value'] ?? '';
		$dsm_pagination_next_text        = $attrs['dsm_pagination_next_text']['innerContent']['desktop']['value'] ?? '';

		// $has_pagination     = 'on' === $this->props['dsm_show_pagination'];
		// $has_dynamic_images = 'on' === $this->props['dsm_use_dynamic_images'];

		// Get gallery item data.
		$attachments_pages = self::get_attachments(
			array(
				'gallery_ids'    => $gallery_ids,
				'posts_per_page' => $dsm_per_page,
				'order'          => $dsm_query_order,
				'use_dynamic'    => 'on' === $dsm_use_dynamic_images,
				'categories'     => $dsm_include_categories,
				'max'            => (int) $dsm_total_number_images,
			)
		);

		if ( empty( $attachments_pages ) ) {
			return '';
		}

		$ids_in_array = explode( ',', $gallery_ids );
		$__ids        = array();

		$markup                 = array();
		$filterable_tabs_markup = '';

		foreach ( $ids_in_array as $id ) {
			$__ids[] = (int) $id;
		}

		$slides              = '';
		$display_image_index = 0;

		foreach ( $attachments_pages as $attachment_page_no => $attachments_in_page ) {
			foreach ( $attachments_in_page as $attachment ) {
				// Divi Supreme Custom URL for Galleries.
				$dsm_upload_gallery_custom_link_url       = get_post_meta( $attachment->ID, 'dsm_upload_gallery_custom_link_url', true );
				$dsm_upload_gallery_link_url_target       = get_post_meta( $attachment->ID, 'dsm_upload_gallery_link_url_target', true );
				$dsm_upload_gallery_link_as_download_file = get_post_meta( $attachment->ID, 'dsm_upload_gallery_link_as_download_file', true );

				$title_text       = trim( wp_strip_all_tags( wptexturize( get_the_title( $attachment->ID ) ) ) );
				$caption_text     = trim( wp_strip_all_tags( wp_get_attachment_caption( $attachment->ID ) ) );
				$description_text = trim( wp_strip_all_tags( $attachment->post_content ) );

				$title                    = 'on' === $dsm_show_title && '' !== $title_text ? sprintf( '<%2$s class="dsm-title">%1$s</%2$s>', trim( wptexturize( get_the_title( $attachment->ID ) ) ), esc_attr( $heading_level ) ) : '';
				$caption                  = 'on' === $dsm_show_caption && '' !== $caption_text ? sprintf( '<div class="dsm-caption">%1$s</div>', esc_html( trim( wp_get_attachment_caption( $attachment->ID ) ) ) ) : '';
				$description              = 'on' === $dsm_show_description && '' !== $description_text ? sprintf( '<div class="dsm-description">%1$s</div>', esc_html( trim( $attachment->post_content ) ) ) : '';
				$attachment_sizes         = wp_get_attachment_image_src( $attachment->ID, $dsm_image_sizes );
				$current_attachment_sizes = $attachment_sizes[0];
				$current_image_title      = get_the_title( $attachment->ID );
				$current_image_alt        = get_post_meta( $attachment->ID, '_wp_attachment_image_alt', true );
				if ( '' === trim( (string) $current_image_alt ) ) {
					$current_image_alt = $current_image_title;
				}
				$current_categories = get_the_terms( $attachment->ID, 'dsm-attachment-category' );

				if ( false === $current_categories ) {
					$current_categories = array();
				}

				$all_category = (object) array(
					'name' => 'all',
				);
				if ( ! is_wp_error( $current_categories ) ) {
					$current_categories[] = $all_category;
				} else {
					$current_categories = array( $all_category );
				}

				$categories_as_string = join( ',', wp_list_pluck( $current_categories, 'name' ) );

				$normalized_page_index = $attachment_page_no + 1;

				++$display_image_index;
				$image_loading = $display_image_index <= $columns_count ? 'eager' : 'lazy';
				$lightbox_src  = self::filterable_gallery_lightbox_image_url( (int) $attachment->ID );
				if ( '' === $lightbox_src ) {
					$lightbox_src = $current_attachment_sizes;
				}

				$attachment_img_attrs = array(
					'title'    => $current_image_title,
					'alt'      => $current_image_alt,
					'decoding' => 'async',
					'loading'  => $image_loading,
					'sizes'    => $image_sizes_attr,
					'class'    => 'dsm-fg-gallery-image',
				);

				/**
				 * Filter grid `<img>` attributes for Filterable Gallery.
				 *
				 * @param array<string, string> $attachment_img_attrs Attributes for wp_get_attachment_image().
				 * @param int                   $attachment_id        Attachment ID.
				 * @param array<string, mixed>  $attrs                Module attrs.
				 */
				$attachment_img_attrs = apply_filters(
					'dsm_filterable_gallery_attachment_image_attrs',
					$attachment_img_attrs,
					(int) $attachment->ID,
					$attrs
				);

				// Native loading, srcset/sizes, and dimensions via core (grid size ≠ lightbox full URL).
				$image = wp_get_attachment_image(
					$attachment->ID,
					$dsm_image_sizes,
					false,
					$attachment_img_attrs
				);

				if ( '' === $image ) {
					$image = sprintf(
						'<img src="%1$s" title="%2$s" alt="%3$s" class="dsm-fg-gallery-image" loading="%4$s" decoding="async" sizes="%5$s" />',
						esc_url( $current_attachment_sizes ),
						esc_attr( $current_image_title ),
						esc_attr( $current_image_alt ),
						esc_attr( $image_loading ),
						esc_attr( $image_sizes_attr )
					);
				}

				$content_wrapper = ( '' !== $title || '' !== $caption || '' !== $description ) ? sprintf( '<div class="dsm-filterable-gallery-content-wrapper">%1$s %2$s %3$s</div>', $title, $caption, $description ) : '';

				if ( '' === $dsm_upload_gallery_custom_link_url ) {
					$wrapper = sprintf(
						'<div class="dsm-filterable-gallery-item" data-mfp-src="%5$s" data-inpage="%4$s" data-groups="%3$s" %6$s %7$s %8$s>
							<div class="dsm-filterable-gallery-inner-item">
							  <div class="dsm-filterable-gallery-image-wrapper">%1$s</div>
							  %2$s
							</div>
						</div> 
					',
						$image,
						$content_wrapper,
						strtolower( $categories_as_string ),
						$normalized_page_index,
						esc_url( $lightbox_src ),
						'on' === $dsm_show_title_lightbox ? sprintf( 'data-lightbox_title="%1$s"', trim( wptexturize( get_the_title( $attachment->ID ) ) ) ) : '',
						'on' === $dsm_show_caption_lightbox ? sprintf( 'data-lightbox_caption="%1$s"', esc_html( trim( wp_get_attachment_caption( $attachment->ID ) ) ) ) : '',
						'on' === $dsm_show_description_lightbox ? sprintf( 'data-lightbox_description="%1$s"', esc_html( html_entity_decode( trim( $attachment->post_content ) ) ) ) : ''
					);
				}

				if ( '' !== $dsm_upload_gallery_custom_link_url ) {
					$wrapper = sprintf(
						'<div class="dsm-filterable-gallery-item" data-mfp-src="%5$s" data-inpage="%4$s" data-groups="%3$s" %9$s %10$s %11$s>
							<div class="dsm-filterable-gallery-inner-item">
							 <a href="%6$s" target="%7$s" %8$s>
							  <div class="dsm-filterable-gallery-image-wrapper">
							    <div class="et_pb_image_wrap">%1$s</div> 
							  </div>
							  %2$s
							  </a>
							</div>
						</div> 
					',
						$image,
						$content_wrapper,
						strtolower( $categories_as_string ),
						$normalized_page_index,
						esc_url( $lightbox_src ),
						esc_url( $dsm_upload_gallery_custom_link_url ),
						esc_attr( $dsm_upload_gallery_link_url_target ),
						( '1' === $dsm_upload_gallery_link_as_download_file ? ' download' : '' ),
						'on' === $dsm_show_title_lightbox ? sprintf( 'data-lightbox_title="%1$s"', trim( wptexturize( get_the_title( $attachment->ID ) ) ) ) : '',
						'on' === $dsm_show_caption_lightbox ? sprintf( 'data-lightbox_caption="%1$s"', esc_html( trim( wp_get_attachment_caption( $attachment->ID ) ) ) ) : '',
						'on' === $dsm_show_description_lightbox ? sprintf( 'data-lightbox_description="%1$s"', esc_html( html_entity_decode( trim( $attachment->post_content ) ) ) ) : ''
					);
				}

				$slides .= $wrapper;
			}
		}

		$instance_id   = wp_unique_id( 'dsm-fg-' );
		$panel_id      = $instance_id . '-panel';
		$active_tab_id = '';

		if ( 'on' === $dsm_show_filterable_gallery ) {
			$show_all_tab = 'on' === $dsm_show_all_images_text;
			$all_tab_id   = $instance_id . '-tab-all';
			$tabs_inner   = '';

			if ( $show_all_tab ) {
				$active_tab_id = $all_tab_id;
				$tabs_inner   .= sprintf(
					'<li role="presentation"><button type="button" id="%1$s" role="tab" class="dsm-filterable-gallery-filter-item dsm-active-filter" aria-selected="true" aria-controls="%2$s" data-category="all">%3$s</button></li>',
					esc_attr( $all_tab_id ),
					esc_attr( $panel_id ),
					esc_html( $dsm_filterable_gallery_all_text )
				);
			}

			// Get unique categories.
			$categories = array();
			foreach ( $attachments_pages as $attachments ) {
				foreach ( $attachments as $attachment ) {
					$terms = get_the_terms( $attachment->ID, 'dsm-attachment-category' );
					if ( $terms && ! is_wp_error( $terms ) ) {
						foreach ( $terms as $term ) {
							$categories[ $term->name ] = $term->name;
						}
					}
				}
			}

			// Sort categories based on sortby setting.
			if ( 'asc' === $dsm_sortby ) {
				sort( $categories );
			} elseif ( 'desc' === $dsm_sortby ) {
				rsort( $categories );
			}

			// Generate category tabs (first tab is selected when "All" is hidden).
			$category_index = 0;
			foreach ( $categories as $category ) {
				$cat_slug    = strtolower( $category );
				$cat_tab_id  = $instance_id . '-tab-' . sanitize_title( $cat_slug );
				$is_selected = ! $show_all_tab && 0 === $category_index;
				if ( $is_selected ) {
					$active_tab_id = $cat_tab_id;
				}
				$tabs_inner .= sprintf(
					'<li role="presentation"><button type="button" id="%1$s" role="tab" class="dsm-filterable-gallery-filter-item%5$s" aria-selected="%2$s" aria-controls="%3$s" data-category="%4$s">%6$s</button></li>',
					esc_attr( $cat_tab_id ),
					$is_selected ? 'true' : 'false',
					esc_attr( $panel_id ),
					esc_attr( $cat_slug ),
					$is_selected ? ' dsm-active-filter' : '',
					esc_html( $category )
				);
				++$category_index;
			}

			if ( '' !== $tabs_inner ) {
				$filterable_tabs_markup = sprintf(
					'<ul class="dsm-filterable-category-container" role="tablist" aria-label="%1$s">%2$s</ul>',
					esc_attr__( 'Filter gallery by category', 'dsm-supreme-modules-pro-for-divi' ),
					$tabs_inner
				);
			}
		}

		$has_tab_interface = '' !== $filterable_tabs_markup && '' !== $active_tab_id;

		$inner_container_extra = self::filterable_gallery_inner_container_extra_attributes_string( $attrs );

		if ( $has_tab_interface ) {
			$inner_container_html = sprintf(
				'<div id="%1$s" class="dsm-filterable-gallery-inner-container dsm-fg-layout-pending" role="tabpanel" tabindex="-1" aria-labelledby="%2$s" aria-live="polite"%4$s>%3$s</div>',
				esc_attr( $panel_id ),
				esc_attr( $active_tab_id ),
				$slides,
				$inner_container_extra
			);
		} else {
			$inner_container_html = sprintf(
				'<div id="%1$s" class="dsm-filterable-gallery-inner-container dsm-fg-layout-pending" aria-live="polite"%3$s>%2$s</div>',
				esc_attr( $panel_id ),
				$slides,
				$inner_container_extra
			);
		}

		$gallery_region_label_esc = esc_attr__( 'Image gallery', 'dsm-supreme-modules-pro-for-divi' );
		$data_i18n_pagination     = esc_attr(
			wp_json_encode(
				array(
					/* translators: %d: page number (digits only) */
					'goToPage' => __( 'Go to page %d', 'dsm-supreme-modules-pro-for-divi' ),
				),
				JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT
			)
		);

		$container = sprintf(
			'<div class="dsm-filterable-gallery-container %1$s" role="region" aria-label="%2$s" data-i18n-pagination="%3$s" data-paginationtype="%4$s" data-currentpage="1" data-per_page="%5$s" data-use_lightbox="%6$s" data-totalpages="%7$s" data-speed="%8$s" data-showpagination="%9$s" data-columns="%14$s">
				%10$s
				%11$s
				%12$s
				%13$s
			</div>',
			'on' === $dsm_use_zoom_on_hover ? 'dsm-image-hover' : '',
			$gallery_region_label_esc,
			$data_i18n_pagination,
			esc_attr( $dsm_pagination_type ),
			esc_attr( (string) $dsm_per_page ),
			esc_attr( $dsm_use_lightbox ),
			esc_attr( (string) count( $attachments_pages ) ),
			esc_attr( (string) $dsm_speed ),
			esc_attr( $dsm_show_pagination ),
			$filterable_tabs_markup,
			$inner_container_html,
			'on' === $dsm_show_pagination && 'load_more' === $dsm_pagination_type ? self::get_loadmore_pagination( $dsm_load_more_text ) : '',
			'on' === $dsm_show_pagination && 'number' === $dsm_pagination_type ? self::get_number_pagination( $attachments_pages, $dsm_tidy_up_pagination, $dsm_pagination_prev_text, $dsm_pagination_next_text ) : '',
			esc_attr( (string) $columns_count )
		);

		// Module Inner.
		// Essentially, this is the module content.
		// Were wrapping the title and content in a div with class `et_pb_module_inner`.
		$module_inner = HTMLUtility::render(
			array(
				'tag'               => 'div',
				'attributes'        => array(
					'class' => 'et_pb_module_inner',
				),
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $container,
			)
		);

		// This are the module elements that will be rendered in the frontend.
		$module_elements = $elements->style_components(
			array(
				'attrName' => 'module',
			)
		);

		// This are the children of the module container, which are the module elements and the module inner.
		$module_container_children = $module_elements . $module_inner;

		return Module::render(
			array(
				// FE only.
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],
				// VB equivalent.
				'attrs'               => $attrs,
				'elements'            => $elements,
				'id'                  => $block->parsed_block['id'],
				'moduleClassName'     => 'd5_tut_simple_quick_module',
				'name'                => $block->block_type->name,
				'classnamesFunction'  => array( self::class, 'module_classnames' ),
				'moduleCategory'      => $block->block_type->category,
				'stylesComponent'     => array( self::class, 'module_styles' ),
				'scriptDataComponent' => array( self::class, 'module_script_data' ),
				'children'            => $module_container_children,
			)
		);
	}
}
