<?php
/**
 * Marquee Child Module.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Modules;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use DiviSupreme\Extensions\IconLibraries\LegacyModuleIconStyles;
use DiviSupreme\Includes\UploadImageMarkup;
use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\Module\Options\Element\ElementClassnames;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;

/**
 * Class that handles a Supreme Marquee child item.
 */
class MarqueeChild implements DependencyInterface {

	/**
	 * Register module.
	 */
	public function load(): void {
		add_action( 'init', array( self::class, 'register_module' ) );
	}

	/**
	 * Initialise the module.
	 *
	 * @return void
	 */
	public static function dsm_initialise(): void {
		add_action(
			'divi_module_library_modules_dependency_tree',
			static function ( $dependency_tree ): void {
				$dependency_tree->add_dependency( new self() );
			}
		);
	}

	/**
	 * Register module.
	 *
	 * @return void
	 */
	public static function register_module(): void {
		$module_json_path = DSM_DIR_PATH . 'divi-5/public/packages/module-library/marquee-child';

		ModuleRegistration::register_module(
			$module_json_path,
			array(
				'render_callback' => array( self::class, 'render_callback' ),
			)
		);
	}

	/**
	 * Icon ::after declaration for native Divi / FA glyphs.
	 *
	 * @param mixed $params Style params from CommonStyle.
	 * @return string
	 */
	public static function icon_style_declaration( $params ): string {
		return LegacyModuleIconStyles::build_pseudo_icon_declaration( $params );
	}

	/**
	 * CSS custom-property declaration for a range attr.
	 *
	 * @param mixed  $params   Style params from CommonStyle.
	 * @param string $property Custom property name.
	 * @return string
	 */
	public static function css_var_declaration( $params, string $property ): string {
		$declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
			)
		);

		$value = '';
		if ( is_array( $params ) && isset( $params['attrValue'] ) ) {
			$value = is_string( $params['attrValue'] ) ? $params['attrValue'] : '';
		}

		if ( '' !== $value ) {
			$declarations->add( $property, $value );
		}

		return $declarations->value();
	}

	/**
	 * Render module style.
	 *
	 * @param array<string, mixed> $args Style arguments.
	 * @return void
	 */
	public static function module_styles( array $args ): void {
		$args        = \DiviSupreme\Includes\DsmDiviBuilderCssScope::normalize_module_styles_args( $args );
		$attrs       = $args['attrs'] ?? array();
		$elements    = $args['elements'];
		$order_class = (string) ( $args['orderClass'] ?? '' );

		Style::add(
			array(
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => array(
					$elements->style(
						array(
							'attrName'   => 'module',
							'styleProps' => array(
								'disabledOn' => array(
									'disabledModuleVisibility' => $args['settings']['disabledModuleVisibility'] ?? null,
								),
							),
						)
					),
					CssStyle::style(
						array(
							'selector' => $order_class,
							'attr'     => $attrs['css'] ?? array(),
						)
					),
					$elements->style(
						array(
							'attrName' => 'text',
						)
					),
					CommonStyle::style(
						array(
							'selector'            => "{$order_class} .dsm_marquee_child_icon::after",
							'attr'                => $attrs['font_icon']['innerContent'] ?? array(),
							'declarationFunction' => array( self::class, 'icon_style_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector' => "{$order_class} .dsm_marquee_child_icon",
							'attr'     => $attrs['icon_color']['innerContent'] ?? array(),
							'property' => 'color',
						)
					),
					CommonStyle::style(
						array(
							'selector' => "{$order_class} .dsm_marquee_child_icon",
							'attr'     => $attrs['icon_font_size']['innerContent'] ?? array(),
							'property' => 'font-size',
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $order_class,
							'attr'                => $attrs['image_max_height']['innerContent'] ?? array(),
							'declarationFunction' => static function ( $params ) {
								return self::css_var_declaration( $params, '--dsm-marquee-logo-max-height' );
							},
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $order_class,
							'attr'                => $attrs['image_hover_scale']['innerContent'] ?? array(),
							'declarationFunction' => static function ( $params ) {
								return self::css_var_declaration( $params, '--dsm-marquee-logo-hover-scale' );
							},
						)
					),
				),
			)
		);
	}

	/**
	 * Render module script data.
	 *
	 * @param array<string, mixed> $args Script data arguments.
	 * @return void
	 */
	public static function module_script_data( array $args ): void {
		$elements = $args['elements'];

		$elements->script_data(
			array(
				'attrName' => 'module',
			)
		);
	}

	/**
	 * Render module classnames.
	 *
	 * @param array<string, mixed> $args Classname arguments.
	 * @return void
	 */
	public static function module_classnames( array $args ): void {
		$classnames_instance = $args['classnamesInstance'];
		$attrs               = $args['attrs'];

		$classnames_instance->add(
			ElementClassnames::classnames(
				array(
					'attrs' => $attrs['module']['decoration'] ?? array(),
				)
			)
		);

		$classnames_instance->add( 'dsm_marquee_child' );
	}

	/**
	 * Render an item image using the parent Image Size when an attachment exists.
	 *
	 * @param mixed  $image_raw   Upload innerContent desktop value.
	 * @param string $alt         Fallback alt text.
	 * @param string $image_size  WordPress image size slug.
	 * @return string
	 */
	private static function render_item_image( $image_raw, string $alt, string $image_size ): string {
		$src           = UploadImageMarkup::resolve_upload_src_string( $image_raw );
		$attachment_id = UploadImageMarkup::resolve_upload_attachment_id( $image_raw );

		if ( $attachment_id < 1 && ( '' === $src || ( str_starts_with( $src, 'data:image/svg+xml' ) && str_contains( $src, 'Logo' ) ) ) ) {
			return '';
		}
		$extra_attrs = array(
			'class'    => 'dsm_marquee_child_img',
			'decoding' => 'async',
			'loading'  => 'lazy',
		);

		if ( $attachment_id > 0 && wp_attachment_is_image( $attachment_id ) ) {
			$img = wp_get_attachment_image(
				$attachment_id,
				$image_size,
				false,
				array_merge(
					$extra_attrs,
					array(
						'alt' => $alt,
					)
				)
			);

			if ( is_string( $img ) && '' !== $img ) {
				return $img;
			}
		}

		return UploadImageMarkup::render_img_html( $image_raw, $alt, $extra_attrs );
	}

	/**
	 * Render module HTML output.
	 *
	 * @param array<string, mixed> $attrs    Module attributes.
	 * @param string               $content  Child HTML.
	 * @param \WP_Block            $block    Block.
	 * @param mixed                $elements Elements.
	 * @return string
	 */
	public static function render_callback( $attrs, $content, $block, $elements ): string {
		$use_icon    = $attrs['use_icon']['innerContent']['desktop']['value'] ?? 'off';
		$image_raw   = $attrs['image']['innerContent']['desktop']['value'] ?? '';
		$link_url    = $attrs['module']['advanced']['link']['desktop']['value']['url'] ?? '';
		$link_target = $attrs['module']['advanced']['link']['desktop']['value']['target'] ?? '';

		$parent       = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );
		$parent_attrs = ( is_object( $parent ) && isset( $parent->attrs ) && is_array( $parent->attrs ) ) ? $parent->attrs : array();
		$image_size   = $parent_attrs['image_size']['innerContent']['desktop']['value'] ?? 'full';
		if ( ! is_string( $image_size ) || '' === $image_size ) {
			$image_size = 'full';
		}

		$text_markup = $elements->render(
			array(
				'attrName' => 'text',
			)
		);

		$alt_rendered = isset( $attrs['image_alt'] )
			? (string) $elements->render(
				array(
					'attrName' => 'image_alt',
				)
			)
			: '';
		$alt_text     = trim( wp_strip_all_tags( $alt_rendered ) );
		$fallback_alt = '' !== $alt_text ? $alt_text : trim( wp_strip_all_tags( (string) $text_markup ) );

		$font_icon_settings = null;
		if (
			isset( $attrs['font_icon']['innerContent']['desktop']['value'] )
			&& is_array( $attrs['font_icon']['innerContent']['desktop']['value'] )
		) {
			$font_icon_settings = $attrs['font_icon']['innerContent']['desktop']['value'];
		}

		$icon = '';
		if ( 'on' === $use_icon && is_array( $font_icon_settings ) ) {
			$icon = LegacyModuleIconStyles::render_custom_icon_host( $font_icon_settings, 'dsm_marquee_child_icon' );
		}

		$img_html     = 'on' === $use_icon
			? ''
			: self::render_item_image( $image_raw, $fallback_alt, $image_size );
		$image_markup = '' !== $img_html
			? sprintf( '<span class="dsm_marquee_child_image">%s</span>', $img_html )
			: '';

		$text_html = '' !== trim( wp_strip_all_tags( (string) $text_markup ) )
			? sprintf( '<span class="dsm_marquee_child_text">%s</span>', et_core_esc_previously( $text_markup ) )
			: '';

		$inner = sprintf(
			'<span class="dsm_marquee_child_inner">%s</span>',
			$icon . $image_markup . $text_html
		);

		if ( ! empty( $link_url ) ) {
			$inner = sprintf(
				'<a href="%1$s"%2$s>%3$s</a>',
				esc_url( $link_url ),
				'on' === $link_target ? ' target="_blank" rel="noopener noreferrer"' : '',
				$inner
			);
		}

		$module_elements = $elements->style_components(
			array(
				'attrName' => 'module',
			)
		);

		return Module::render(
			array(
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],
				'tag'                 => 'li',
				'attrs'               => $attrs,
				'elements'            => $elements,
				'id'                  => $block->parsed_block['id'],
				'name'                => $block->block_type->name,
				'classnamesFunction'  => array( self::class, 'module_classnames' ),
				'moduleCategory'      => $block->block_type->category,
				'stylesComponent'     => array( self::class, 'module_styles' ),
				'scriptDataComponent' => array( self::class, 'module_script_data' ),
				'children'            => $module_elements . $inner,
			)
		);
	}
}
