<?php
/**
 * Card Carousel Module.
 *
 * @package DiviSupreme.
 */

declare(strict_types=1);

namespace DiviSupreme\Modules;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\Module\Options\Element\ElementClassnames;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Options\Element\ElementComponents;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;
use ET\Builder\Packages\Module\Options\Text\TextStyle;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use DiviSupreme\Extensions\IconLibraries\LegacyModuleIconStyles;


/**
 * Class that handles "CardCarousel Module" module.
 */
class CardCarousel implements DependencyInterface {


	/**
	 * Register module.
	 * `DependencyInterface` interface ensures class method name `load()` is executed for initialization.
	 */
	public function load() {
		add_action( 'init', array( self::class, 'register_module' ) );
	}

	/**
	 * Initilises the module.
	 *
	 * @return void
	 */
	public static function dsm_initialise() {
		add_action(
			'divi_module_library_modules_dependency_tree',
			function ( $dependency_tree ) {
				$dependency_tree->add_dependency( new self() );
			}
		);
	}

	/**
	 * Register module.
	 */
	public static function register_module() {

		$module_json_path = DSM_DIR_PATH . 'divi-5/public/packages/module-library/card-carousel';

		ModuleRegistration::register_module(
			$module_json_path,
			array(
				'render_callback' => array( self::class, 'render_callback' ),
			)
		);
	}

	/**
	 * Prev arrow icon declaration.
	 *
	 * @param mixed $params Params.
	 */
	public static function prev_arrow_icon_declaration( $params ) {
		return LegacyModuleIconStyles::build_pseudo_icon_declaration( $params );
	}

	/**
	 * Next arrow icon declaration.
	 *
	 * @param mixed $params Params.
	 */
	public static function next_arrow_icon_declaration( $params ) {
		return LegacyModuleIconStyles::build_pseudo_icon_declaration( $params );
	}

	/**
	 * Image alignment decalaration.
	 *
	 * @param mixed $params Params.
	 */
	public static function image_alignment_decalaration( $params ) {
		$attr = $params['attrValue'] ?? array();

		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
				'important'  => array(
					'justify-content' => true,
				),
			)
		);

		$align_value = '';

		switch ( $attr ) {
			case 'left':
				$align_value = 'flex-start';
				break;
			case 'center':
				$align_value = 'center';
				break;
			case 'right':
				$align_value = 'flex-end';
				break;
			default:
				$align_value = 'center';
		}

		$style_declarations->add( 'display', 'flex' );
		$style_declarations->add( 'justify-content', $align_value );

		return $style_declarations->value();
	}

	/**
	 * Next prev arrow width height declaration.
	 *
	 * @param mixed $params Params.
	 */
	public static function next_prev_arrow_width_height_declaration( $params ) {
		$attr = $params['attrValue'] ?? array();

		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
				'important'  => array(
					'width'  => true,
					'height' => true,
				),
			)
		);

		$attr_value = ( floatval( $attr ) + 20 ) . 'px';

		$style_declarations->add( 'width', $attr_value );
		$style_declarations->add( 'height', $attr_value );

		return $style_declarations->value();
	}

	/**
	 * Swiper hit box: `--swiper-navigation-size` is arrow size plus 20px, per breakpoint.
	 *
	 * CommonStyle calls this for desktop, tablet, and phone when those values exist.
	 * Outside arrows use `calc(-1 * var(--swiper-navigation-size))`.
	 *
	 * @param array<string, mixed> $params Style params including attrValue for the current breakpoint.
	 * @return string
	 */
	public static function swiper_navigation_size_var_declaration( $params ) {
		$attr = $params['attrValue'] ?? '';

		if ( ! is_scalar( $attr ) || '' === trim( (string) $attr ) ) {
			return '';
		}

		$n = floatval( $attr );

		if ( ! is_finite( $n ) || $n < 0 ) {
			return '';
		}

		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
			)
		);

		$style_declarations->add( '--swiper-navigation-size', ( $n + 20 ) . 'px' );

		return $style_declarations->value();
	}

	/**
	 * Custom arrow inset: same value as D4 prev `left` / next `right`, expressed as Swiper var.
	 *
	 * @param array $params Style params including attrValue per breakpoint.
	 * @return string
	 */
	public static function arrow_custom_sides_offset_declaration( $params ) {
		$attr = $params['attrValue'] ?? '';

		if ( '' === $attr || null === $attr ) {
			return '';
		}

		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
			)
		);

		$style_declarations->add( '--swiper-navigation-sides-offset', $attr );

		return $style_declarations->value();
	}

	/**
	 * Image inline width declaration.
	 *
	 * @param mixed $params Params.
	 */
	public static function image_inline_width_declaration( $params ) {
		$attr = $params['attrValue'] ?? array();

		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
				'important'  => array(
					'flex' => true,
				),
			)
		);

		$style_declarations->add( 'flex', "0 0 $attr" );

		return $style_declarations->value();
	}


	/**
	 * Image inline order declaration.
	 *
	 * @param mixed $params Params.
	 */
	public static function image_inline_order_declaration( $params ) {
		$attr = $params['attrValue'] ?? array();

		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
				'important'  => array(
					'order' => true,
				),
			)
		);

		$style_declarations->add( 'order', 'left' === $attr ? '0' : '1' );

		return $style_declarations->value();
	}

	/**
	 * Image inline horizontal align declaration.
	 *
	 * @param mixed $params Params.
	 */
	public static function image_inline_horizontal_align_declaration( $params ) {
		$attr = $params['attrValue'] ?? array();

		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
				'important'  => array(
					'margin' => true,
				),
			)
		);

		if ( 'top' === $attr ) {
			$style_declarations->add( 'margin-bottom', 'auto' );
		}

		if ( 'center' === $attr ) {
			$style_declarations->add( 'margin-top', 'auto' );
			$style_declarations->add( 'margin-bottom', 'auto' );
		}

		if ( 'bottom' === $attr ) {
			$style_declarations->add( 'margin-top', 'auto' );
		}

		return $style_declarations->value();
	}

	/**
	 * Content inline alignment declaration.
	 *
	 * @param mixed $params Params.
	 */
	public static function content_inline_alignment_declaration( $params ) {
		$attr = $params['attrValue'] ?? array();

		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
				'important'  => array(
					'margin' => true,
				),
			)
		);

		if ( 'flex-start' === $attr ) {
			$style_declarations->add( 'margin-bottom', 'auto' );
		}

		if ( 'center' === $attr ) {
			$style_declarations->add( 'margin-top', 'auto' );
			$style_declarations->add( 'margin-bottom', 'auto' );
		}

		if ( 'flex-end' === $attr ) {
			$style_declarations->add( 'margin-top', 'auto' );
		}

		return $style_declarations->value();
	}

	/**
	 * Build innerContent-shaped attr for button wrapper alignment (matches module-styles.js).
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 * @return array<string, mixed>
	 */
	private static function button_decoration_alignment_inner_content_for_style( array $attrs ): array {
		$button_attr = $attrs['button'] ?? null;
		if ( ! is_array( $button_attr ) ) {
			return array( 'innerContent' => array() );
		}

		$sizing = $button_attr['decoration']['sizing'] ?? null;
		$button = $button_attr['decoration']['button'] ?? null;

		$inner_content = array();
		foreach ( array( 'desktop', 'tablet', 'phone' ) as $bp ) {
			$raw = '';

			if ( is_array( $sizing ) && isset( $sizing[ $bp ]['value'] ) && is_array( $sizing[ $bp ]['value'] ) ) {
				$alignment = $sizing[ $bp ]['value']['alignment'] ?? '';
				if ( is_string( $alignment ) && '' !== trim( $alignment ) ) {
					$raw = $alignment;
				}
			}

			if ( '' === trim( (string) $raw ) && is_array( $button ) && isset( $button[ $bp ]['value'] ) && is_array( $button[ $bp ]['value'] ) ) {
				$value = $button[ $bp ]['value'];
				$raw   = $value['textAlign'] ?? $value['alignment'] ?? '';
			}

			if ( ! is_string( $raw ) || '' === trim( $raw ) ) {
				continue;
			}
			$lower = strtolower( trim( $raw ) );
			if ( in_array( $lower, array( 'left', 'center', 'right' ), true ) ) {
				$inner_content[ $bp ] = array( 'value' => $lower );
			}
		}

		return array( 'innerContent' => $inner_content );
	}

	/**
	 * Wrapper alignment: text-align + margin auto (fit-content wrapper in common.scss).
	 *
	 * @param array<string, mixed> $params CommonStyle params.
	 * @return string
	 */
	public static function button_wrapper_align_declaration( array $params ): string {
		$alignment = $params['attrValue'] ?? '';

		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
				'important'  => array(
					'text-align'   => true,
					'margin-left'  => true,
					'margin-right' => true,
					'align-self'   => true,
				),
			)
		);

		if ( 'left' === $alignment ) {
			$style_declarations->add( 'text-align', 'left' );
			$style_declarations->add( 'margin-left', '0' );
			$style_declarations->add( 'margin-right', 'auto' );
			$style_declarations->add( 'align-self', 'flex-start' );
		}

		if ( 'center' === $alignment ) {
			$style_declarations->add( 'text-align', 'center' );
			$style_declarations->add( 'margin-left', 'auto' );
			$style_declarations->add( 'margin-right', 'auto' );
			$style_declarations->add( 'align-self', 'center' );
		}

		if ( 'right' === $alignment ) {
			$style_declarations->add( 'text-align', 'right' );
			$style_declarations->add( 'margin-left', 'auto' );
			$style_declarations->add( 'margin-right', '0' );
			$style_declarations->add( 'align-self', 'flex-end' );
		}

		return $style_declarations->value();
	}

	/**
	 * Wrapper alignment from ButtonGroup `decoration.sizing` (attrValue.alignment).
	 *
	 * @param array<string, mixed> $params CommonStyle params.
	 * @return string
	 */
	public static function button_sizing_alignment_wrapper_declaration( array $params ): string {
		$attr_value = $params['attrValue'] ?? array();
		$alignment  = is_array( $attr_value ) ? ( $attr_value['alignment'] ?? '' ) : '';

		if ( ! is_string( $alignment ) || '' === trim( $alignment ) ) {
			return '';
		}

		return self::button_wrapper_align_declaration(
			array(
				'attrValue' => strtolower( trim( $alignment ) ),
			)
		);
	}

	/**
	 * Layout image order declaration.
	 *
	 * @param mixed $params Params.
	 */
	public static function layout_image_order_declaration( $params ) {
		$attr = $params['attrValue'] ?? array();

		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
				'important'  => array(
					'order' => true,
				),
			)
		);

		$is_right_image_order = 'left' === $attr ? '0' : '1';

		$style_declarations->add( 'order', $is_right_image_order );

		return $style_declarations->value();
	}

	/**
	 * Normalize duration/delay stored as int ms, numeric string, or time string.
	 *
	 * @param mixed  $value   Raw value.
	 * @param string $default Fallback.
	 * @return string
	 */
	private static function normalize_transition_time_property( $value, string $default ): string {
		if ( is_int( $value ) ) {
			return (string) $value . 'ms';
		}
		if ( is_float( $value ) ) {
			return (string) (int) round( $value ) . 'ms';
		}
		if ( ! is_string( $value ) ) {
			return $default;
		}
		$t = trim( $value );
		if ( '' === $t ) {
			return $default;
		}
		if ( preg_match( '/[a-z%]/i', $t ) ) {
			return $t;
		}
		if ( is_numeric( $t ) ) {
			return (string) (int) round( (float) $t ) . 'ms';
		}

		return $t;
	}

	/**
	 * Read Advanced → Transition (`module.decoration.transition`) at breakpoint.
	 *
	 * @param array  $attrs      Module attrs.
	 * @param string $breakpoint desktop|tablet|phone.
	 * @return array{duration: string, delay: string, speedCurve: string}
	 */
	private static function read_module_transition_leaf_at_breakpoint( array $attrs, string $breakpoint ): array {
		$defaults = array(
			'duration'   => '300ms',
			'delay'      => '0ms',
			'speedCurve' => 'ease',
		);
		$module   = $attrs['module'] ?? array();
		if ( ! is_array( $module ) ) {
			return $defaults;
		}
		$decoration = $module['decoration'] ?? array();
		$trans      = is_array( $decoration ) ? ( $decoration['transition'] ?? null ) : null;
		if ( ! is_array( $trans ) ) {
			return $defaults;
		}
		$order = array_values(
			array_unique(
				array_merge(
					array( $breakpoint ),
					array( 'desktop', 'tablet', 'phone' )
				)
			)
		);
		foreach ( $order as $bp ) {
			if ( ! isset( $trans[ $bp ] ) || ! is_array( $trans[ $bp ] ) ) {
				continue;
			}
			$node = $trans[ $bp ];
			if ( ! isset( $node['value'] ) || ! is_array( $node['value'] ) ) {
				continue;
			}
			$leaf = $node['value'];
			$out  = $defaults;
			if ( isset( $leaf['duration'] ) ) {
				$out['duration'] = self::normalize_transition_time_property( $leaf['duration'], $defaults['duration'] );
			}
			if ( isset( $leaf['delay'] ) ) {
				$out['delay'] = self::normalize_transition_time_property( $leaf['delay'], $defaults['delay'] );
			}
			if ( isset( $leaf['speedCurve'] ) && is_string( $leaf['speedCurve'] ) && '' !== $leaf['speedCurve'] ) {
				$out['speedCurve'] = $leaf['speedCurve'];
			}
			return $out;
		}
		return $defaults;
	}

	/**
	 * Transition declaration for card inner, arrows, badge, image layer (D4 parity).
	 *
	 * @param array  $attrs      Module attrs.
	 * @param string $breakpoint desktop|tablet|phone.
	 * @return string
	 */
	private static function card_carousel_parent_hover_transition_css( array $attrs, string $breakpoint ): string {
		$t      = self::read_module_transition_leaf_at_breakpoint( $attrs, $breakpoint );
		$d      = esc_attr( $t['duration'] );
		$c      = esc_attr( $t['speedCurve'] );
		$s      = esc_attr( $t['delay'] );
		$triple = "{$d} {$c} {$s}";

		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
			)
		);
		$style_declarations->add(
			'transition',
			"background {$triple}, box-shadow {$triple}, border {$triple}, padding {$triple}, border-radius {$triple}, transform {$triple}, color {$triple}"
		);

		return $style_declarations->value();
	}

	/**
	 * Site phone/tablet max-widths and Swiper min-width keys (Divi 5 configured breakpoints).
	 *
	 * @return array{phone_max:int,tablet_max:int,tablet_min:int,desktop_min:int}
	 */
	public static function card_carousel_viewport_breakpoints(): array {
		$phone_max  = 767;
		$tablet_max = 980;

		if ( class_exists( '\ET\Builder\Framework\Breakpoint\Breakpoint' ) ) {
			$items = \ET\Builder\Framework\Breakpoint\Breakpoint::get_settings_values()['items'] ?? array();
			if ( ! empty( $items['phone']['maxWidth']['value'] ) ) {
				$parsed = (int) preg_replace( '/\D+/', '', (string) $items['phone']['maxWidth']['value'] );
				if ( $parsed > 0 ) {
					$phone_max = $parsed;
				}
			}
			if ( ! empty( $items['tablet']['maxWidth']['value'] ) ) {
				$parsed = (int) preg_replace( '/\D+/', '', (string) $items['tablet']['maxWidth']['value'] );
				if ( $parsed > 0 ) {
					$tablet_max = $parsed;
				}
			}
		}

		$breakpoints = array(
			'phone_max'   => $phone_max,
			'tablet_max'  => $tablet_max,
			'tablet_min'  => $phone_max + 1,
			'desktop_min' => $tablet_max + 1,
		);

		/**
		 * Filter Card Carousel viewport breakpoint pixels.
		 *
		 * @param array{phone_max:int,tablet_max:int,tablet_min:int,desktop_min:int} $breakpoints Computed widths.
		 */
		$filtered = apply_filters( 'dsm_card_carousel_viewport_breakpoints', $breakpoints );
		if ( ! is_array( $filtered ) ) {
			return $breakpoints;
		}

		foreach ( array( 'phone_max', 'tablet_max', 'tablet_min', 'desktop_min' ) as $key ) {
			if ( isset( $filtered[ $key ] ) && is_numeric( $filtered[ $key ] ) ) {
				$breakpoints[ $key ] = (int) $filtered[ $key ];
			}
		}

		return $breakpoints;
	}

	/**
	 * Resolve innerContent string at a breakpoint (phone ← tablet ← desktop).
	 *
	 * @param array  $inner      Attr innerContent.
	 * @param string $breakpoint desktop|tablet|phone.
	 * @param string $default    Fallback when desktop is empty.
	 * @return string
	 */
	public static function inner_content_value_at_breakpoint( array $inner, string $breakpoint, string $default = '' ): string {
		$desktop = isset( $inner['desktop']['value'] ) ? trim( (string) $inner['desktop']['value'] ) : '';
		$tablet  = isset( $inner['tablet']['value'] ) ? trim( (string) $inner['tablet']['value'] ) : '';
		$phone   = isset( $inner['phone']['value'] ) ? trim( (string) $inner['phone']['value'] ) : '';

		if ( '' === $desktop ) {
			$desktop = $default;
		}
		if ( '' === $tablet ) {
			$tablet = $desktop;
		}
		if ( '' === $phone ) {
			$phone = $tablet;
		}

		if ( 'phone' === $breakpoint ) {
			return $phone;
		}
		if ( 'tablet' === $breakpoint ) {
			return $tablet;
		}

		return $desktop;
	}

	/**
	 * Whether an on/off innerContent toggle is on at a breakpoint.
	 *
	 * @param array  $inner      Attr innerContent.
	 * @param string $breakpoint desktop|tablet|phone.
	 * @param string $default    Fallback when desktop is empty.
	 * @return bool
	 */
	public static function inner_content_toggle_is_on( array $inner, string $breakpoint, string $default = 'off' ): bool {
		return 'on' === self::inner_content_value_at_breakpoint( $inner, $breakpoint, $default );
	}

	/**
	 * Whether a toggle is on at any coarse breakpoint (after inheritance).
	 *
	 * @param array  $inner   Attr innerContent.
	 * @param string $default Fallback when desktop is empty.
	 * @return bool
	 */
	public static function inner_content_toggle_on_any( array $inner, string $default = 'off' ): bool {
		return self::inner_content_toggle_is_on( $inner, 'desktop', $default )
			|| self::inner_content_toggle_is_on( $inner, 'tablet', $default )
			|| self::inner_content_toggle_is_on( $inner, 'phone', $default );
	}

	/**
	 * Raw innerContent leaf (empty string when unset — JS/CSS inherit).
	 *
	 * @param array  $inner      Attr innerContent.
	 * @param string $breakpoint desktop|tablet|phone.
	 * @return string
	 */
	public static function inner_content_raw_at_breakpoint( array $inner, string $breakpoint ): string {
		if ( ! isset( $inner[ $breakpoint ]['value'] ) ) {
			return '';
		}

		return trim( (string) $inner[ $breakpoint ]['value'] );
	}

	/**
	 * Raw on/off toggle leaf (empty when unset so JS can inherit).
	 *
	 * Boolean false must not become "" via (string) cast — that looks unset
	 * and the frontend would inherit desktop ON onto phone.
	 *
	 * @param array  $inner      Attr innerContent.
	 * @param string $breakpoint desktop|tablet|phone.
	 * @return string `on`, `off`, or empty.
	 */
	public static function inner_content_toggle_raw_at_breakpoint( array $inner, string $breakpoint ): string {
		if (
			! isset( $inner[ $breakpoint ] ) ||
			! is_array( $inner[ $breakpoint ] ) ||
			! array_key_exists( 'value', $inner[ $breakpoint ] )
		) {
			return '';
		}

		$raw = $inner[ $breakpoint ]['value'];

		if ( true === $raw || 1 === $raw || '1' === $raw || 'true' === $raw || 'on' === $raw ) {
			return 'on';
		}

		if ( false === $raw || 0 === $raw || '0' === $raw || 'false' === $raw || 'off' === $raw ) {
			return 'off';
		}

		if ( ! is_scalar( $raw ) ) {
			return '';
		}

		$normalized = strtolower( trim( (string) $raw ) );

		if ( 'on' === $normalized || 'off' === $normalized ) {
			return $normalized;
		}

		return '';
	}

	/**
	 * Whether badge_position has a non-empty value at any breakpoint.
	 *
	 * @param array $attrs Module attrs.
	 * @return bool
	 */
	public static function badge_position_inner_has_value( array $attrs ): bool {
		$inner = $attrs['badge_position']['innerContent'] ?? array();
		if ( ! is_array( $inner ) ) {
			return false;
		}

		foreach ( array( 'desktop', 'tablet', 'phone' ) as $breakpoint ) {
			if ( '' !== self::inner_content_raw_at_breakpoint( $inner, $breakpoint ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Preset badge text position CSS (resets opposing sides so breakpoint overrides win).
	 *
	 * @param array $params CommonStyle params.
	 * @return string
	 */
	public static function badge_position_text_declaration( $params ): string {
		$raw = $params['attrValue'] ?? '';
		if ( ! is_string( $raw ) ) {
			return '';
		}

		$slug = strtolower( trim( $raw ) );
		if ( '' === $slug ) {
			return '';
		}

		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
				'important'  => true,
			)
		);
		$style_declarations->add( 'position', 'absolute' );
		$style_declarations->add( 'top', 'auto' );
		$style_declarations->add( 'right', 'auto' );
		$style_declarations->add( 'bottom', 'auto' );
		$style_declarations->add( 'left', 'auto' );
		$style_declarations->add( 'transform', 'none' );

		switch ( $slug ) {
			case 'top_right':
				$style_declarations->add( 'top', '1rem' );
				$style_declarations->add( 'right', '1rem' );
				break;
			case 'top_left':
				$style_declarations->add( 'top', '1rem' );
				$style_declarations->add( 'left', '1rem' );
				break;
			case 'top_center':
				$style_declarations->add( 'top', '1rem' );
				$style_declarations->add( 'left', '50%' );
				$style_declarations->add( 'transform', 'translateX(-50%)' );
				break;
			case 'bottom_right':
				$style_declarations->add( 'bottom', '1rem' );
				$style_declarations->add( 'right', '1rem' );
				break;
			case 'bottom_left':
				$style_declarations->add( 'bottom', '1rem' );
				$style_declarations->add( 'left', '1rem' );
				break;
			case 'bottom_center':
				$style_declarations->add( 'bottom', '1rem' );
				$style_declarations->add( 'left', '50%' );
				$style_declarations->add( 'transform', 'translateX(-50%)' );
				break;
			case 'center':
				$style_declarations->add( 'top', '50%' );
				$style_declarations->add( 'left', '50%' );
				$style_declarations->add( 'transform', 'translate(-50%, -50%)' );
				break;
			case 'center_left':
				$style_declarations->add( 'left', '1rem' );
				break;
			case 'center_right':
				$style_declarations->add( 'right', '1rem' );
				break;
			default:
				return '';
		}

		return $style_declarations->value();
	}

	/**
	 * Figure flex for center-left / center-right badge presets (reset at other slugs).
	 *
	 * @param array $params CommonStyle params.
	 * @return string
	 */
	public static function badge_position_figure_declaration( $params ): string {
		$raw = $params['attrValue'] ?? '';
		if ( ! is_string( $raw ) ) {
			return '';
		}

		$slug = strtolower( trim( $raw ) );
		if ( '' === $slug ) {
			return '';
		}

		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
				'important'  => true,
			)
		);

		if ( 'center_left' === $slug ) {
			$style_declarations->add( 'display', 'flex' );
			$style_declarations->add( 'justify-content', 'left' );
			$style_declarations->add( 'align-items', 'center' );
		} elseif ( 'center_right' === $slug ) {
			$style_declarations->add( 'display', 'flex' );
			$style_declarations->add( 'justify-content', 'right' );
			$style_declarations->add( 'align-items', 'center' );
		} else {
			$style_declarations->add( 'display', 'block' );
			$style_declarations->add( 'justify-content', 'initial' );
			$style_declarations->add( 'align-items', 'initial' );
		}

		return $style_declarations->value();
	}

	/**
	 * Show/hide carousel chrome (arrows or pagination) per breakpoint.
	 *
	 * @param array  $params     CommonStyle params.
	 * @param string $display_on CSS display when the toggle is on.
	 * @return string
	 */
	public static function chrome_visibility_declaration( $params, string $display_on = 'flex' ): string {
		$raw = $params['attrValue'] ?? '';
		if ( ! is_string( $raw ) || '' === trim( $raw ) ) {
			return '';
		}

		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
				'important'  => true,
			)
		);
		$style_declarations->add( 'display', 'on' === trim( $raw ) ? $display_on : 'none' );

		return $style_declarations->value();
	}

	/**
	 * Effective carousel card layout at a style breakpoint.
	 *
	 * @param array  $attrs      Module attrs.
	 * @param string $breakpoint desktop|tablet|phone.
	 * @return string stacked|inline
	 */
	private static function get_carousel_resolved_layout( array $attrs, string $breakpoint ): string {
		$inner   = $attrs['layout']['innerContent'] ?? array();
		$desktop = isset( $inner['desktop']['value'] ) ? trim( (string) $inner['desktop']['value'] ) : '';
		if ( '' === $desktop ) {
			$desktop = 'stacked';
		}
		if ( 'desktop' === $breakpoint ) {
			return $desktop;
		}
		$tablet = isset( $inner['tablet']['value'] ) ? trim( (string) $inner['tablet']['value'] ) : '';
		if ( 'tablet' === $breakpoint ) {
			return '' !== $tablet ? $tablet : $desktop;
		}
		$phone = isset( $inner['phone']['value'] ) ? trim( (string) $inner['phone']['value'] ) : '';
		if ( '' !== $phone ) {
			return $phone;
		}
		if ( '' !== $tablet ) {
			return $tablet;
		}
		return $desktop;
	}

	/**
	 * Inline carousel child image column selector at breakpoint.
	 *
	 * @param array  $attrs       Module attrs.
	 * @param string $order_class Module order class.
	 * @param string $breakpoint  desktop|tablet|phone.
	 * @return string
	 */
	private static function get_carousel_inline_child_image_wrapper_selector( array $attrs, string $order_class, string $breakpoint ): string {
		if ( 'inline' !== self::get_carousel_resolved_layout( $attrs, $breakpoint ) ) {
			return '';
		}
		$inner      = $attrs['layout']['innerContent'] ?? array();
		$tablet_raw = isset( $inner['tablet']['value'] ) ? trim( (string) $inner['tablet']['value'] ) : '';
		$phone_raw  = isset( $inner['phone']['value'] ) ? trim( (string) $inner['phone']['value'] ) : '';
		$suffix     = ' .dsm_card_carousel_child .dsm_card_carousel_child_image_wrapper';
		if ( 'desktop' === $breakpoint ) {
			return "{$order_class}.dsm_card_carousel_layout_inline{$suffix}";
		}
		if ( 'tablet' === $breakpoint ) {
			return '' !== $tablet_raw
				? "{$order_class}.dsm_card_carousel_layout_tablet_inline{$suffix}"
				: "{$order_class}.dsm_card_carousel_layout_inline{$suffix}";
		}
		if ( '' !== $phone_raw ) {
			return "{$order_class}.dsm_card_carousel_layout_phone_inline{$suffix}";
		}
		if ( '' !== $tablet_raw ) {
			return "{$order_class}.dsm_card_carousel_layout_tablet_inline{$suffix}";
		}
		return "{$order_class}.dsm_card_carousel_layout_inline{$suffix}";
	}

	/**
	 * Wrapper selector for inline vertical content alignment (carousel slide).
	 *
	 * @param array  $attrs       Module attrs.
	 * @param string $order_class Module order class.
	 * @param string $breakpoint  desktop|tablet|phone.
	 * @return string
	 */
	private static function get_carousel_inline_child_wrapper_selector( array $attrs, string $order_class, string $breakpoint ): string {
		$img = self::get_carousel_inline_child_image_wrapper_selector( $attrs, $order_class, $breakpoint );
		if ( '' === $img ) {
			return '';
		}
		return str_replace(
			' .dsm_card_carousel_child_image_wrapper',
			' .dsm_card_wrapper',
			$img
		);
	}

	/**
	 * Render module style.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_styles( $args ) {
		$args                      = \DiviSupreme\Includes\DsmDiviBuilderCssScope::normalize_module_styles_args( $args );
		$attrs                     = $args['attrs'] ?? array();
		$elements                  = $args['elements'];
		$use_arrow_custom_position = $attrs['use_arrow_custom_position']['innerContent']['desktop']['value'] ?? '';
		$button_align_attr         = self::button_decoration_alignment_inner_content_for_style( $attrs );

		// StyleWrapper needs non-empty `attr`; Divi core skips TransitionStyle on FE without hover attr JSON.
		$module          = isset( $attrs['module'] ) && is_array( $attrs['module'] ) ? $attrs['module'] : array();
		$decoration      = isset( $module['decoration'] ) && is_array( $module['decoration'] ) ? $module['decoration'] : array();
		$transition_attr = isset( $decoration['transition'] ) && is_array( $decoration['transition'] ) ? $decoration['transition'] : array();
		if ( empty( $transition_attr ) ) {
			$transition_attr = array(
				'desktop' => array(
					'value' => array(
						'duration'   => '300ms',
						'delay'      => '0ms',
						'speedCurve' => 'ease',
					),
				),
			);
		}

		Style::add(
			array(
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => array(
					// Module.
					$elements->style(
						array(
							'attrName'   => 'module',
							'styleProps' => array(
								'disabledOn' => array(
									'disabledModuleVisibility' => $args['settings']['disabledModuleVisibility'] ?? null,
								),
							),
						)
					),

					CssStyle::style(
						array(
							'selector' => $args['orderClass'],
							'attr'     => $attrs['css'] ?? array(),
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm_card_carousel_child > div:first-of-type, {$args['orderClass']} .dsm_card_carousel_arrow, {$args['orderClass']} .dsm_card_carousel_child_badge_text, {$args['orderClass']} .dsm_card_carousel_child_image_background",
							'attr'                => $transition_attr,
							'declarationFunction' => static function ( $params ) use ( $attrs ) {
								$state = isset( $params['state'] ) && is_string( $params['state'] ) ? $params['state'] : 'value';
								if ( 'value' !== $state ) {
									return '';
								}
								$breakpoint = isset( $params['breakpoint'] ) && is_string( $params['breakpoint'] ) ? $params['breakpoint'] : 'desktop';
								return self::card_carousel_parent_hover_transition_css( $attrs, $breakpoint );
							},
						)
					),

					$elements->style(
						array(
							'attrName' => 'title',
						)
					),

					$elements->style(
						array(
							'attrName' => 'subtitle',
						)
					),

					$elements->style(
						array(
							'attrName' => 'content',
						)
					),

					$elements->style(
						array(
							'attrName' => 'badgeFont',
						)
					),

					$elements->style(
						array(
							'attrName' => 'badge',
						)
					),

					$elements->style(
						array(
							'attrName' => 'button',
						)
					),

					( ! empty( $button_align_attr['innerContent'] )
						? CommonStyle::style(
							array(
								'selector'            => "{$args['orderClass']} .et_pb_button_module_wrapper",
								'attr'                => $button_align_attr['innerContent'],
								'declarationFunction' => array( static::class, 'button_wrapper_align_declaration' ),
							)
						)
						: '' ),
					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .et_pb_button_module_wrapper",
							'attr'                => $attrs['button']['decoration']['sizing'] ?? array(),
							'declarationFunction' => array( static::class, 'button_sizing_alignment_wrapper_declaration' ),
						)
					),

					$elements->style(
						array(
							'attrName' => 'imageStyle',
						)
					),

					$elements->style(
						array(
							'attrName' => 'arrowStyle',
						)
					),

					$elements->style(
						array(
							'attrName' => 'card',
						)
					),

					TextStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm_card_wrapper",
							'attr'     => $attrs['module']['advanced']['text'] ?? array(),
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm_card_carousel_child_badge_text",
							'attr'     => $attrs['badge_background_color']['innerContent'] ?? array(),
							'property' => 'background-color',
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .swiper-button-prev::before",
							'attr'                => $attrs['arrow_prev_font_icon']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'prev_arrow_icon_declaration' ),
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .swiper-button-next::before",
							'attr'                => $attrs['arrow_next_font_icon']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'next_arrow_icon_declaration' ),
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .swiper-button-prev, {$args['orderClass']} .swiper-button-next",
							'attr'                => $attrs['arrow_size']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'next_prev_arrow_width_height_declaration' ),
						)
					),

					CommonStyle::style(
						array(
							'selector'            => $args['orderClass'],
							'attr'                => $attrs['arrow_size']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'swiper_navigation_size_var_declaration' ),
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .swiper-container.swiper-vertical",
							'attr'     => $attrs['slider_container_height']['innerContent'] ?? array(),
							'property' => 'height',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .swiper-button-prev::before, {$args['orderClass']} .swiper-button-next::before",
							'attr'     => $attrs['arrow_color']['innerContent'] ?? array(),
							'property' => 'color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .swiper-button-prev, {$args['orderClass']} .swiper-button-next",
							'attr'     => $attrs['arrow_background_color']['innerContent'] ?? array(),
							'property' => 'background-color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .swiper-button-prev::before, {$args['orderClass']} .swiper-button-next::before",
							'attr'     => $attrs['arrow_size']['innerContent'] ?? array(),
							'property' => 'font-size',
						)
					),

					'on' === $use_arrow_custom_position ?

					CommonStyle::style(
						array(
							'selector'            => $args['orderClass'],
							'attr'                => $attrs['arrow_custom_position']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'arrow_custom_sides_offset_declaration' ),
						)
					) : '',

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']}.dsm_card_carousel_slider_horizontal .dsm_card_carousel_pagination.swiper-pagination-bullets, {$args['orderClass']}.dsm_card_carousel_slider_horizontal .dsm_card_carousel_pagination.swiper-pagination-custom, {$args['orderClass']}.dsm_card_carousel_slider_horizontal .dsm_card_carousel_pagination.swiper-pagination-progressbar",
							'attr'     => $attrs['dots_horizontal_placement']['innerContent'] ?? array(),
							'property' => 'bottom',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm_card_carousel_pagination .swiper-pagination-bullet.swiper-pagination-bullet-active, {$args['orderClass']} .dsm_card_carousel_pagination .swiper-pagination-progressbar-fill",
							'attr'     => $attrs['dots_active_color']['innerContent'] ?? array(),
							'property' => 'background',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm_card_carousel_pagination .swiper-pagination-bullet, {$args['orderClass']} .dsm_card_carousel_pagination.swiper-pagination-progressbar",
							'attr'     => $attrs['dots_inactive_color']['innerContent'] ?? array(),
							'property' => 'background',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm_card_carousel_child_img, {$args['orderClass']} .dsm_card_carousel_child_image_wrapper img",
							'attr'     => $attrs['image_width']['innerContent'] ?? array(),
							'property' => 'max-width',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']}.dsm_card_carousel_slider_vertical .swiper-button-next, {$args['orderClass']}.dsm_card_carousel_slider_vertical .swiper-button-prev",
							'attr'     => $attrs['navi_hori_position']['innerContent'] ?? array(),
							'property' => 'left',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']}.dsm_card_carousel_slider_vertical .swiper-button-prev",
							'attr'     => $attrs['top_navi_ver_position']['innerContent'] ?? array(),
							'property' => 'top',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']}.dsm_card_carousel_slider_vertical .swiper-button-next",
							'attr'     => $attrs['bottom_navi_ver_position']['innerContent'] ?? array(),
							'property' => 'bottom',
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm_card_carousel_child_image_wrapper",
							'attr'                => $attrs['image_alignment']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'image_alignment_decalaration' ),
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm_card_carousel_child .dsm_card_wrapper",
							'attr'     => $attrs['content_horizontal_alignment']['innerContent'] ?? array(),
							'property' => 'justify-content',
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm_card_carousel_child .dsm_card_wrapper",
							'attr'                => $attrs['content_horizontal_alignment']['innerContent'] ?? array(),
							'selectorFunction'    => static function ( $params ) use ( $attrs, $args ) {
								return self::get_carousel_inline_child_wrapper_selector( $attrs, $args['orderClass'], $params['breakpoint'] ?? 'desktop' );
							},
							'declarationFunction' => static function ( $params ) use ( $attrs ) {
								if ( 'inline' !== self::get_carousel_resolved_layout( $attrs, $params['breakpoint'] ?? 'desktop' ) ) {
									return '';
								}
								return self::content_inline_alignment_declaration( $params );
							},
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']}.dsm_card_carousel_slider_vertical.dsm_pagi_placement_right .swiper-pagination-bullets",
							'attr'     => $attrs['dots_horizontal_placement']['innerContent'] ?? array(),
							'property' => 'right',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']}.dsm_card_carousel_slider_vertical.dsm_pagi_placement_left .swiper-pagination-bullets",
							'attr'     => $attrs['dots_horizontal_placement']['innerContent'] ?? array(),
							'property' => 'left',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']}.dsm_card_carousel_slider_vertical .swiper-pagination-bullets",
							'attr'     => $attrs['dots_vertical_placement']['innerContent'] ?? array(),
							'property' => 'top',
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm_card_carousel_child .dsm_card_carousel_child_image_wrapper",
							'attr'                => $attrs['layout_inline_image_width']['innerContent'] ?? array(),
							'selectorFunction'    => static function ( $params ) use ( $attrs, $args ) {
								return self::get_carousel_inline_child_image_wrapper_selector( $attrs, $args['orderClass'], $params['breakpoint'] ?? 'desktop' );
							},
							'declarationFunction' => static function ( $params ) use ( $attrs ) {
								if ( 'inline' !== self::get_carousel_resolved_layout( $attrs, $params['breakpoint'] ?? 'desktop' ) ) {
									return '';
								}
								return self::image_inline_width_declaration( $params );
							},
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm_card_carousel_child .dsm_card_carousel_child_image_wrapper",
							'attr'                => $attrs['layout_inline_order']['innerContent'] ?? array(),
							'selectorFunction'    => static function ( $params ) use ( $attrs, $args ) {
								return self::get_carousel_inline_child_image_wrapper_selector( $attrs, $args['orderClass'], $params['breakpoint'] ?? 'desktop' );
							},
							'declarationFunction' => static function ( $params ) use ( $attrs ) {
								if ( 'inline' !== self::get_carousel_resolved_layout( $attrs, $params['breakpoint'] ?? 'desktop' ) ) {
									return '';
								}
								return self::layout_image_order_declaration( $params );
							},
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm_card_carousel_child .dsm_card_carousel_child_image_wrapper",
							'attr'                => $attrs['image_horizontal_alignment']['innerContent'] ?? array(),
							'selectorFunction'    => static function ( $params ) use ( $attrs, $args ) {
								return self::get_carousel_inline_child_image_wrapper_selector( $attrs, $args['orderClass'], $params['breakpoint'] ?? 'desktop' );
							},
							'declarationFunction' => static function ( $params ) use ( $attrs ) {
								if ( 'inline' !== self::get_carousel_resolved_layout( $attrs, $params['breakpoint'] ?? 'desktop' ) ) {
									return '';
								}
								return self::image_inline_horizontal_align_declaration( $params );
							},
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm_card_carousel_child_badge_preset .dsm_card_carousel_child_badge_text",
							'attr'                => $attrs['badge_position']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'badge_position_text_declaration' ),
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm_card_carousel_child_image_wrapper.dsm_card_carousel_child_badge_preset",
							'attr'                => $attrs['badge_position']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'badge_position_figure_declaration' ),
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm_card_carousel_arrow, {$args['orderClass']} .swiper-button-prev, {$args['orderClass']} .swiper-button-next",
							'attr'                => $attrs['arrows']['innerContent'] ?? array(),
							'declarationFunction' => static function ( $params ) {
								return self::chrome_visibility_declaration( $params, 'flex' );
							},
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm_card_carousel_pagination, {$args['orderClass']} .swiper-pagination",
							'attr'                => $attrs['dots']['innerContent'] ?? array(),
							'declarationFunction' => static function ( $params ) {
								return self::chrome_visibility_declaration( $params, 'block' );
							},
						)
					),
				),
			)
		);
	}

	/**
	 * Render module script data.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_script_data( $args ) {
		$elements = $args['elements'];

		// Element Script Data Options.
		$elements->script_data(
			array(
				'attrName' => 'module',
			)
		);
	}

	/**
	 * Render module classnames.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_classnames( $args ) {
		$classnames_instance       = $args['classnamesInstance'];
		$attrs                     = $args['attrs'];
		$slider_orientation        = $attrs['slider_orientation']['innerContent']['desktop']['value'] ?? 'horizontal';
		$arrow_position            = $attrs['arrow_position']['innerContent']['desktop']['value'] ?? 'outside';
		$arrow_position_mobile     = $attrs['arrow_position_mobile']['innerContent']['desktop']['value'] ?? '';
		$badge_show_on_hover       = $attrs['badge_show_on_hover']['innerContent']['desktop']['value'] ?? '';
		$pagi_vertical_placement   = $attrs['pagi_vertical_placement']['innerContent']['desktop']['value'] ?? 'right';
		$layout                    = $attrs['layout']['innerContent']['desktop']['value'] ?? 'stacked';
		$layout_tablet             = $attrs['layout']['innerContent']['tablet']['value'] ?? '';
		$layout_phone              = $attrs['layout']['innerContent']['phone']['value'] ?? '';
		$infinite_smooth_scrolling = $attrs['infinite_smooth_scrolling']['innerContent']['desktop']['value'] ?? 'off';
		$use_arrow_custom_position = $attrs['use_arrow_custom_position']['innerContent']['desktop']['value'] ?? '';

		// Module.
		$classnames_instance->add(
			ElementClassnames::classnames(
				array(
					'attrs' => $attrs['module']['decoration'] ?? array(),
				)
			)
		);

		$classnames_instance->add( "dsm_card_carousel_arrow_$arrow_position" );
		$classnames_instance->add( "dsm_card_carousel_slider_$slider_orientation" );

		/*
		 * D4 default for Mobile Arrow Position is inside, and that key is often
		 * omitted from saved attrs. Explicit "outside" is the only opt-out.
		 * Custom arrow position replaces this, matching Divi 4.
		 */
		if (
			'on' !== $use_arrow_custom_position &&
			'outside' === $arrow_position &&
			'outside' !== $arrow_position_mobile
		) {
			$classnames_instance->add( 'dsm_card_carousel_arrow_mobile_inside' );
		}

		$classnames_instance->add( "dsm_card_carousel_layout_$layout" );

		if ( ! empty( $layout_tablet ) ) {
			$classnames_instance->add( "dsm_card_carousel_layout_tablet_$layout_tablet" );
		}

		if ( ! empty( $layout_phone ) ) {
			$classnames_instance->add( "dsm_card_carousel_layout_phone_$layout_phone" );
		}

		if ( 'vertical' === $slider_orientation ) {
			$classnames_instance->add( "dsm_pagi_placement_$pagi_vertical_placement" );
		}

		if ( 'on' === $badge_show_on_hover ) {
			$classnames_instance->add( 'dsm_card_carousel_badge_hover' );
		}

		if ( self::inner_content_toggle_is_on( $attrs['equal_height']['innerContent'] ?? array(), 'desktop', 'off' ) ) {
			$classnames_instance->add( 'dsm_card_carousel_equal_height' );
		}

		if ( 'on' === $infinite_smooth_scrolling ) {
			$classnames_instance->add( 'dsm_card_carousel_infinite_scroll' );
		}

		if ( 'on' === $use_arrow_custom_position ) {
			$classnames_instance->add( 'dsm_card_carousel_use_arrow_custom_position' );
		}
	}

	/**
	 * Render module HTML output.
	 *
	 * @param array     $attrs - Modules Attributes.
	 * @param string    $content - Content.
	 * @param \WP_Block $block - Block.
	 * @param mixed     $elements - Elements.
	 */
	public static function render_callback( $attrs, $content, $block, $elements ) {
		$slider_effect                  = $attrs['slider_effect']['innerContent']['desktop']['value'] ?? 'default';
		$slider_orientation             = $attrs['slider_orientation']['innerContent']['desktop']['value'] ?? 'horizontal';
		$slide_to_show                  = $attrs['slide_to_show']['innerContent']['desktop']['value'] ?? '3';
		$slide_to_show_tablet           = $attrs['slide_to_show']['innerContent']['tablet']['value'] ?? '';
		$slide_to_show_phone            = $attrs['slide_to_show']['innerContent']['phone']['value'] ?? '';
		$speed                          = $attrs['speed']['innerContent']['desktop']['value'] ?? '300';
		$multiple_slide_row             = $attrs['multiple_slide_row']['innerContent']['desktop']['value'] ?? 'off';
		$loop                           = $attrs['infinite']['innerContent']['desktop']['value'] ?? 'on';
		$space_between                  = $attrs['space_between']['innerContent']['desktop']['value'] ?? '15';
		$space_between_tablet           = $attrs['space_between']['innerContent']['tablet']['value'] ?? '';
		$space_between_phone            = $attrs['space_between']['innerContent']['phone']['value'] ?? '';
		$centered_slides_inner          = $attrs['centered_slides']['innerContent'] ?? array();
		$centered_slides_desktop_raw    = self::inner_content_toggle_raw_at_breakpoint( $centered_slides_inner, 'desktop' );
		$centered_slides                = '' !== $centered_slides_desktop_raw ? $centered_slides_desktop_raw : 'off';
		$centered_slides_tablet         = self::inner_content_toggle_raw_at_breakpoint( $centered_slides_inner, 'tablet' );
		$centered_slides_phone          = self::inner_content_toggle_raw_at_breakpoint( $centered_slides_inner, 'phone' );
		$autoplay                       = $attrs['autoplay']['innerContent']['desktop']['value'] ?? 'on';
		$autoplay_speed                 = $attrs['autoplay_speed']['innerContent']['desktop']['value'] ?? '3000';
		$touch_move                     = $attrs['touch_move']['innerContent']['desktop']['value'] ?? 'off';
		$grab                           = $attrs['grab']['innerContent']['desktop']['value'] ?? 'on';
		$pause_on_hover                 = $attrs['pause_on_hover']['innerContent']['desktop']['value'] ?? 'off';
		$mousewheel                     = $attrs['mousewheel']['innerContent']['desktop']['value'] ?? 'off';
		$auto_height                    = $attrs['auto_height']['innerContent']['desktop']['value'] ?? '';
		$auto_height_tablet             = self::inner_content_raw_at_breakpoint( $attrs['auto_height']['innerContent'] ?? array(), 'tablet' );
		$auto_height_phone              = self::inner_content_raw_at_breakpoint( $attrs['auto_height']['innerContent'] ?? array(), 'phone' );
		$equal_height                   = $attrs['equal_height']['innerContent']['desktop']['value'] ?? '';
		$equal_height_tablet            = self::inner_content_raw_at_breakpoint( $attrs['equal_height']['innerContent'] ?? array(), 'tablet' );
		$equal_height_phone             = self::inner_content_raw_at_breakpoint( $attrs['equal_height']['innerContent'] ?? array(), 'phone' );
		$pagi_style                     = $attrs['pagi_style']['innerContent']['desktop']['value'] ?? 'bullets';
		$slider_direction               = $attrs['slider_direction']['innerContent']['desktop']['value'] ?? 'ltr';
		$slide_to_scroll                = $attrs['slide_to_scroll']['innerContent']['desktop']['value'] ?? '1';
		$slide_to_scroll_tablet         = $attrs['slide_to_scroll']['innerContent']['tablet']['value'] ?? '';
		$slide_to_scroll_phone          = $attrs['slide_to_scroll']['innerContent']['phone']['value'] ?? '';
		$slide_row                      = $attrs['slide_row']['innerContent']['desktop']['value'] ?? '1';
		$slide_row_tablet               = $attrs['slide_row']['innerContent']['tablet']['value'] ?? '';
		$slide_row_phone                = $attrs['slide_row']['innerContent']['phone']['value'] ?? '';
		$slider_effect_shadows          = $attrs['slider_effect_shadows']['innerContent']['desktop']['value'] ?? 'off';
		$slider_effect_coverflow_rotate = $attrs['slider_effect_coverflow_rotate']['innerContent']['desktop']['value'] ?? '30';
		$slider_effect_coverflow_depth  = $attrs['slider_effect_coverflow_depth']['innerContent']['desktop']['value'] ?? '0';
		$infinite_smooth_scrolling      = $attrs['infinite_smooth_scrolling']['innerContent']['desktop']['value'] ?? 'off';
		$autoplay_viewport              = $attrs['autoplay_viewport']['innerContent']['desktop']['value'] ?? '80%';
		$text_color                     = $attrs['module']['advanced']['text']['text']['desktop']['value']['color'] ?? '';
		$layout_inline_image_width      = $attrs['layout_inline_image_width']['innerContent']['desktop']['value'] ?? '50%';
		$viewport_breakpoints           = self::card_carousel_viewport_breakpoints();

		$arrows_any = self::inner_content_toggle_on_any( $attrs['arrows']['innerContent'] ?? array(), 'on' );
		$dots_any   = self::inner_content_toggle_on_any( $attrs['dots']['innerContent'] ?? array(), 'on' );

		// Match D4 CardCarousel.php: Swiper per-slide height only when Auto Slide Height is on AND Equal Height is off.
		$swiper_variable_height_desktop = ( 'off' !== $auto_height ) && ( 'off' === $equal_height );
		$equal_height_mode_desktop      = ( 'on' === $equal_height );
		$is_loop                        = 'off' !== $loop ? true : false;
		$is_multi_row                   = 'on' === $multiple_slide_row;

		if ( \DiviSupreme\Includes\DsmFrontendAssetRegistry::should_wp_enqueue_module_styles( 'dsm/card-carousel' ) ) {
			wp_enqueue_style( \DiviSupreme\Includes\DsmFrontendModuleAssetRegistry::SWIPER_LIBRARY_STYLE_HANDLE );
		}

		$parsed_for_children = isset( $block->parsed_block ) && is_array( $block->parsed_block ) ? $block->parsed_block : array();
		$inner_block_nodes   = isset( $parsed_for_children['innerBlocks'] ) && is_array( $parsed_for_children['innerBlocks'] ) ? $parsed_for_children['innerBlocks'] : array();
		if (
			array() !== $inner_block_nodes
			&& function_exists( 'dsm_parsed_inner_blocks_any_child_toggle_on' )
			&& dsm_parsed_inner_blocks_any_child_toggle_on(
				$inner_block_nodes,
				'dsm/card-carousel-child',
				array( 'image_popup', 'image_video_popup', 'button_image_popup' )
			)
			&& function_exists( 'dsm_enqueue_magnific_popup_assets' )
		) {
			if ( function_exists( 'dsm_ensure_registered_script_dependency' ) && function_exists( 'dsm_get_active_magnific_popup_script_handle' ) ) {
				dsm_ensure_registered_script_dependency(
					'dsm-card-carousel',
					dsm_get_active_magnific_popup_script_handle()
				);
			}
			dsm_enqueue_magnific_popup_assets();
		}

		if ( \DiviSupreme\Includes\DsmFrontendAssetRegistry::should_wp_enqueue_module_scripts( 'dsm/card-carousel' ) ) {
			wp_enqueue_script( 'dsm-swiper-library' );
			wp_enqueue_script( 'dsm-card-carousel' );
		}

		$data_attr[] = array(
			'direction'                      => $slider_orientation,
			'effect'                         => $slider_effect,
			'slider_effect_shadows'          => 'off' !== $slider_effect_shadows ? true : false,
			'slider_effect_coverflow_rotate' => $slider_effect_coverflow_rotate,
			'slider_effect_coverflow_depth'  => $slider_effect_coverflow_depth,
			'loop'                           => 'off' !== $multiple_slide_row ? false : $is_loop,
			'infinite_smooth_scrolling'      => 'on' === $infinite_smooth_scrolling ? true : false,
			'slide_to_show'                  => $slide_to_show,
			'slide_to_show_tablet'           => $slide_to_show_tablet,
			'slide_to_show_phone'            => $slide_to_show_phone,
			'slide_to_scroll'                => $slide_to_scroll,
			'slide_to_scroll_tablet'         => $slide_to_scroll_tablet,
			'slide_to_scroll_phone'          => $slide_to_scroll_phone,
			'space_between'                  => 'cube' !== $slider_effect ? $space_between : '0',
			'space_between_tablet'           => 'cube' !== $slider_effect ? $space_between_tablet : '0',
			'space_between_phone'            => 'cube' !== $slider_effect ? $space_between_phone : '0',
			'centered_slides'                => 'off' !== $centered_slides ? true : false,
			'centered_slides_tablet'         => $centered_slides_tablet,
			'centered_slides_phone'          => $centered_slides_phone,
			'multiple_slide_row'             => $multiple_slide_row,
			'slide_row'                      => $is_multi_row ? $slide_row : '1',
			'slide_row_tablet'               => $slide_row_tablet,
			'slide_row_phone'                => $slide_row_phone,
			'speed'                          => $speed,
			'autoplay'                       => 'off' !== $autoplay ? true : false,
			'autoplay_speed'                 => $autoplay_speed,
			'autoplay_viewport'              => 'off' !== $autoplay && '' !== $autoplay_viewport ? esc_attr( $autoplay_viewport ) : '',
			'touch_move'                     => 'off' !== $touch_move ? false : true,
			'grab'                           => 'off' !== $grab ? true : false,
			'pause_on_hover'                 => 'off' !== $pause_on_hover ? true : false,
			'mousewheel'                     => 'off' !== $mousewheel ? true : false,
			'auto_height'                    => $is_multi_row ? false : $swiper_variable_height_desktop,
			'auto_height_tablet'             => $is_multi_row ? '' : $auto_height_tablet,
			'auto_height_phone'              => $is_multi_row ? '' : $auto_height_phone,
			'equal_height'                   => $is_multi_row ? false : $equal_height_mode_desktop,
			'equal_height_tablet'            => $is_multi_row ? 'off' : $equal_height_tablet,
			'equal_height_phone'             => $is_multi_row ? 'off' : $equal_height_phone,
			'pagi_style'                     => $pagi_style,
			'bp_tablet_min'                  => (int) $viewport_breakpoints['tablet_min'],
			'bp_desktop_min'                 => (int) $viewport_breakpoints['desktop_min'],
		);

		$children_ids = $block->parsed_block['innerBlocks'] ? array_map(
			function ( $inner_block ) {
				return $inner_block['id'];
			},
			$block->parsed_block['innerBlocks']
		) : array();

		$parent       = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );
		$parent_attrs = $parent->attrs ?? array();

		$arrow_markup = sprintf(
			'<div class="swiper-button-prev dsm_card_carousel_arrow"></div>
			 <div class="swiper-button-next dsm_card_carousel_arrow"></div>',
		);

		$container = sprintf(
			'<div class="swiper-container dsm_card_carousel_wrapper dsm_card_carousel_container %6$s" data-params="%2$s" data-effect="%7$s" dir="%5$s">
				<div class="swiper-wrapper">
					%1$s
				</div>
		    </div>
			%3$s
			%4$s',
			$content,
			htmlspecialchars( wp_json_encode( $data_attr ), ENT_QUOTES, 'UTF-8' ),
			'off' === $infinite_smooth_scrolling && $arrows_any ? $arrow_markup : '',
			'off' === $infinite_smooth_scrolling && $dots_any ? '<div class="swiper-pagination swiper-pagination-bullets swiper-pagination-clickable dsm_card_carousel_pagination"></div>' : '',
			$slider_direction,
			sprintf( 'et_pb_bg_layout_%1$s', $text_color ),
			esc_attr( $slider_effect )
		);

		// Module Inner.
		// Essentially, this is the module content.
		// Were wrapping the title and content in a div with class `et_pb_module_inner`.
		$module_inner = HTMLUtility::render(
			array(
				'tag'               => 'div',
				'attributes'        => array(
					'class' => 'et_pb_module_inner',
				),
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $container,
			)
		);

		// This are the module elements that will be rendered in the frontend.
		$module_elements = $elements->style_components(
			array(
				'attrName' => 'module',
			)
		);

		// This are the children of the module container, which are the module elements and the module inner.
		$module_container_children = $module_elements . $module_inner;

		return Module::render(
			array(
				// FE only.
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],
				// VB equivalent.
				'attrs'               => $attrs,
				'parentAttrs'         => $parent_attrs,
				'elements'            => $elements,
				'id'                  => $block->parsed_block['id'],
				'moduleClassName'     => '',
				'name'                => $block->block_type->name,
				'classnamesFunction'  => array( self::class, 'module_classnames' ),
				'moduleCategory'      => $block->block_type->category,
				'stylesComponent'     => array( self::class, 'module_styles' ),
				'scriptDataComponent' => array( self::class, 'module_script_data' ),
				'children'            => ElementComponents::component(
					array(
						'attrs'         => $attrs['module']['decoration'] ?? array(),
						'id'            => $block->parsed_block['id'],
						// FE only.
						'orderIndex'    => $block->parsed_block['orderIndex'],
						'storeInstance' => $block->parsed_block['storeInstance'],
					)
				) . $module_container_children,
				'childrenIds'         => $children_ids,
			)
		);
	}
}
