<?php
/**
 * Supreme Loop Filter Module — group-like parent around Divi Loop children.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Modules;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use DiviSupreme\Extensions\LoopFilter as LoopFilterExtension;
use DiviSupreme\Includes\DsmFrontendModuleAssetRegistry;

$dsm_loop_filter_price_styles = DSM_DIR_PATH . 'divi-5/app/Includes/dsm-loop-filter-price-styles.php';
if ( is_readable( $dsm_loop_filter_price_styles ) ) {
	require_once $dsm_loop_filter_price_styles;
}
use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\FrontEnd\Module\Style;
use DiviSupreme\Extensions\IconLibraries\IconLibraryRegistry;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\Module\Options\Background\BackgroundStyle;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\Module\Options\Element\ElementClassnames;
use ET\Builder\Packages\Module\Options\Element\ElementComponents;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;
use WP_Block;

/**
 * Class that handles the Supreme Loop Filter parent module.
 */
class LoopFilter implements DependencyInterface {

	/**
	 * Per-request occurrence counters keyed by layout post ID.
	 *
	 * Index must match `find_nth_loop_filter_block` within that layout's
	 * `post_content` (Theme Builder header/body each start at 0).
	 *
	 * @var array<string, int>
	 */
	private static array $instance_index_by_layout = array();

	/**
	 * Index already assigned to a Loop Filter block in this request.
	 *
	 * A second render of the same parsed block reuses this index so it still
	 * matches find_nth_loop_filter_block. Keyed by layout id, then block id.
	 *
	 * @var array<string, array<string, int>>
	 */
	private static array $index_by_block_id = array();

	/**
	 * Register module.
	 */
	public function load(): void {
		add_action( 'init', array( self::class, 'register_module' ) );
	}

	/**
	 * Register module with Divi.
	 *
	 * @return void
	 */
	public static function register_module(): void {
		$module_json_path = DSM_DIR_PATH . 'divi-5/public/packages/module-library/loop-filter';

		ModuleRegistration::register_module(
			$module_json_path,
			array(
				'render_callback' => array( self::class, 'render_callback' ),
			)
		);
	}

	/**
	 * Read a desktop innerContent scalar.
	 *
	 * @param array<string, mixed> $attrs Attributes.
	 * @param string               $key   Attribute key.
	 * @param string               $default Default.
	 * @return string
	 */
	private static function inner_desktop_string( array $attrs, string $key, string $default = '' ): string {
		$value = $attrs[ $key ]['innerContent']['desktop']['value'] ?? $default;
		if ( is_array( $value ) ) {
			if ( isset( $value['text'] ) && is_scalar( $value['text'] ) ) {
				return (string) $value['text'];
			}
			if ( isset( $value['color'] ) && is_scalar( $value['color'] ) ) {
				return (string) $value['color'];
			}
			if ( isset( $value['hex'] ) && is_scalar( $value['hex'] ) ) {
				return (string) $value['hex'];
			}
			if ( isset( $value['value'] ) && is_scalar( $value['value'] ) ) {
				return (string) $value['value'];
			}

			return $default;
		}

		return is_scalar( $value ) ? (string) $value : $default;
	}

	/**
	 * Normalize Terms Layout select (inline|stacked).
	 *
	 * @param string $raw Raw attr value.
	 * @return string inline|stacked
	 */
	private static function normalize_terms_layout( string $raw ): string {
		return 'inline' === $raw ? 'inline' : 'stacked';
	}

	/**
	 * Normalize AJAX loading icon style.
	 *
	 * @param string $raw Raw attr value.
	 * @return string ring|dots|pulse|bars
	 */
	private static function normalize_spinner_style( string $raw ): string {
		$allowed = array( 'ring', 'dots', 'pulse', 'bars' );
		return in_array( $raw, $allowed, true ) ? $raw : 'ring';
	}

	/**
	 * Resolve empty-state title (Divi-aligned default when unset).
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 * @return string
	 */
	private static function resolve_empty_state_title( array $attrs ): string {
		if ( isset( $attrs['empty_state_title'] ) ) {
			return trim( self::inner_desktop_string( $attrs, 'empty_state_title', '' ) );
		}

		return __( 'No Results Found.', 'dsm-supreme-modules-pro-for-divi' );
	}

	/**
	 * Resolve empty-state description.
	 *
	 * Prefers `empty_state_description`; falls back to legacy `empty_state_text`
	 * when the new key is unset. Default matches Divi’s no-results copy.
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 * @return string
	 */
	private static function resolve_empty_state_description( array $attrs ): string {
		if ( isset( $attrs['empty_state_description'] ) ) {
			return trim( self::inner_desktop_string( $attrs, 'empty_state_description', '' ) );
		}

		if ( isset( $attrs['empty_state_text'] ) ) {
			return trim( self::inner_desktop_string( $attrs, 'empty_state_text', '' ) );
		}

		return __(
			'The page you requested could not be found. Try refining your search, or use the navigation above to locate the post.',
			'dsm-supreme-modules-pro-for-divi'
		);
	}

	/**
	 * Build DSP empty-state markup (title + description).
	 *
	 * When both strings are empty the block stays hidden even if results are empty
	 * (Divi’s `.not-found-title` markup is suppressed via CSS).
	 *
	 * @param string $title       Empty-state title.
	 * @param string $description Empty-state description.
	 * @param bool   $is_empty    Whether the Loop currently has no results.
	 * @return string
	 */
	private static function render_empty_state_html( string $title, string $description, bool $is_empty ): string {
		$title       = trim( $title );
		$description = trim( $description );
		$has_copy    = '' !== $title || '' !== $description;
		$parts       = '';

		if ( '' !== $title ) {
			$parts .= sprintf(
				'<h3 class="dsm-loop-filter__empty-title">%s</h3>',
				esc_html( $title )
			);
		}

		if ( '' !== $description ) {
			$parts .= sprintf(
				'<p class="dsm-loop-filter__empty-description">%s</p>',
				esc_html( $description )
			);
		}

		return sprintf(
			'<div class="dsm-loop-filter__empty" data-dsm-lf-empty%1$s%2$s>%3$s</div>',
			$has_copy ? ' data-dsm-lf-empty-has-copy="1"' : '',
			( $is_empty && $has_copy ) ? '' : ' hidden',
			et_core_esc_previously( $parts )
		);
	}

	/**
	 * Build taxonomy term options for the filter UI.
	 *
	 * @param string $taxonomy Taxonomy slug.
	 * @return array<int, array{id: int, parent: int, slug: string, name: string, count: int}>
	 */
	private static function get_taxonomy_term_options( string $taxonomy ): array {
		$taxonomy = LoopFilterExtension::sanitize_public_taxonomy( $taxonomy );
		if ( '' === $taxonomy ) {
			return array();
		}

		$terms = get_terms(
			array(
				'taxonomy'   => $taxonomy,
				'hide_empty' => true,
			)
		);

		if ( is_wp_error( $terms ) || ! is_array( $terms ) ) {
			return array();
		}

		$out = array();
		foreach ( $terms as $term ) {
			if ( ! $term instanceof \WP_Term ) {
				continue;
			}
			$out[] = array(
				'id'     => (int) $term->term_id,
				'parent' => (int) $term->parent,
				'slug'   => (string) $term->slug,
				'name'   => (string) $term->name,
				'count'  => (int) $term->count,
			);
		}

		/**
		 * Filter taxonomy terms shown in Supreme Loop Filter UI.
		 *
		 * @param array<int, array{id: int, parent: int, slug: string, name: string, count: int}> $out      Terms.
		 * @param string                                                                          $taxonomy Taxonomy.
		 */
		$filtered = apply_filters( 'dsm_loop_filter_taxonomy_terms', $out, $taxonomy );

		return is_array( $filtered ) ? $filtered : $out;
	}

	/**
	 * Nest taxonomy terms by parent. Missing parents become roots (orphans stay visible).
	 *
	 * @param array<int, array{id?: int, parent?: int, slug: string, name: string, count?: int}> $terms Flat terms.
	 * @return list<array{term: array<string, mixed>, children: list<array<string, mixed>>}>
	 */
	private static function build_taxonomy_term_tree( array $terms ): array {
		$by_id = array();
		foreach ( $terms as $term ) {
			if ( ! is_array( $term ) || ! isset( $term['slug'] ) ) {
				continue;
			}
			$id = isset( $term['id'] ) ? (int) $term['id'] : 0;
			if ( $id < 1 ) {
				continue;
			}
			$by_id[ $id ] = $term;
		}

		$children = array();
		$roots    = array();
		foreach ( $terms as $term ) {
			if ( ! is_array( $term ) || ! isset( $term['slug'] ) ) {
				continue;
			}
			$id     = isset( $term['id'] ) ? (int) $term['id'] : 0;
			$parent = isset( $term['parent'] ) ? (int) $term['parent'] : 0;
			if ( $id < 1 ) {
				$roots[] = $term;
				continue;
			}
			if ( $parent > 0 && isset( $by_id[ $parent ] ) ) {
				if ( ! isset( $children[ $parent ] ) ) {
					$children[ $parent ] = array();
				}
				$children[ $parent ][] = $term;
				continue;
			}
			$roots[] = $term;
		}

		$walk = static function ( array $term ) use ( &$walk, $children ): array {
			$id    = isset( $term['id'] ) ? (int) $term['id'] : 0;
			$kids  = ( $id > 0 && isset( $children[ $id ] ) ) ? $children[ $id ] : array();
			$nodes = array();
			foreach ( $kids as $child ) {
				$nodes[] = $walk( $child );
			}
			return array(
				'term'     => $term,
				'children' => $nodes,
			);
		};

		$tree = array();
		foreach ( $roots as $root ) {
			$tree[] = $walk( $root );
		}

		return $tree;
	}

	/**
	 * Parenthetical post count for checkbox, radio, and select labels.
	 *
	 * @param array<string, mixed> $term Term row.
	 * @return string Already-escaped markup, or empty.
	 */
	private static function taxonomy_term_count_markup( array $term ): string {
		if ( ! isset( $term['count'] ) || ! is_numeric( $term['count'] ) ) {
			return '';
		}

		return sprintf(
			'<span class="dsm-loop-filter__term-count"> (%s)</span>',
			esc_html( (string) (int) $term['count'] )
		);
	}

	/**
	 * Plain parenthetical post count for a select option label.
	 *
	 * @param array<string, mixed> $term Term row.
	 * @return string ` (4)`, or empty. Not escaped.
	 */
	private static function taxonomy_term_count_text( array $term ): string {
		if ( ! isset( $term['count'] ) || ! is_numeric( $term['count'] ) ) {
			return '';
		}

		return ' (' . (string) (int) $term['count'] . ')';
	}

	/**
	 * One checkbox/radio term label (same input contract as the flat list).
	 *
	 * @param string               $taxonomy       Taxonomy slug.
	 * @param array<string, mixed> $term           Term row.
	 * @param int                  $instance_index Instance index.
	 * @param int                  $item_index     Item index.
	 * @param bool                 $is_radio       Radio UI.
	 * @param string               $radio_name     Shared radio name.
	 * @param bool                 $show_count     Append the post count on checkbox and radio labels.
	 * @return string
	 */
	private static function render_taxonomy_term_label(
		string $taxonomy,
		array $term,
		int $instance_index,
		int $item_index,
		bool $is_radio,
		string $radio_name,
		bool $show_count = false
	): string {
		$slug = isset( $term['slug'] ) ? (string) $term['slug'] : '';
		$name = isset( $term['name'] ) ? (string) $term['name'] : '';
		if ( '' === $slug ) {
			return '';
		}
		$id = 'dsm-lf-' . absint( $instance_index ) . '-i' . absint( $item_index ) . '-term-' . sanitize_html_class( $slug );
		if ( $is_radio ) {
			return sprintf(
				'<label class="dsm-loop-filter__term" for="%1$s"><input type="radio" class="dsm-loop-filter__radio" id="%1$s" name="%2$s" value="%3$s" data-taxonomy="%4$s" /> <span>%5$s%6$s</span></label>',
				esc_attr( $id ),
				esc_attr( $radio_name ),
				esc_attr( $slug ),
				esc_attr( $taxonomy ),
				esc_html( $name ),
				et_core_esc_previously( $show_count ? self::taxonomy_term_count_markup( $term ) : '' )
			);
		}

		return sprintf(
			'<label class="dsm-loop-filter__term" for="%1$s"><input type="checkbox" class="dsm-loop-filter__checkbox" id="%1$s" name="dsm_lf_terms[]" value="%2$s" data-taxonomy="%3$s" /> <span>%4$s%5$s</span></label>',
			esc_attr( $id ),
			esc_attr( $slug ),
			esc_attr( $taxonomy ),
			esc_html( $name ),
			et_core_esc_previously( $show_count ? self::taxonomy_term_count_markup( $term ) : '' )
		);
	}

	/**
	 * Nested term branches with collapsed children + disclosure.
	 *
	 * @param string $taxonomy       Taxonomy slug.
	 * @param array  $nodes          Tree nodes from build_taxonomy_term_tree().
	 * @param int    $instance_index Instance index.
	 * @param int    $item_index     Item index.
	 * @param bool   $is_radio        Radio UI.
	 * @param string $radio_name      Shared radio name.
	 * @param bool   $start_expanded  Show children open on first render.
	 * @param bool   $show_count      Append the post count on checkbox and radio labels.
	 * @return string
	 */
	private static function render_taxonomy_term_tree(
		string $taxonomy,
		array $nodes,
		int $instance_index,
		int $item_index,
		bool $is_radio,
		string $radio_name,
		bool $start_expanded = false,
		bool $show_count = false
	): string {
		$html = '';
		foreach ( $nodes as $node ) {
			if ( ! is_array( $node ) || ! isset( $node['term'] ) || ! is_array( $node['term'] ) ) {
				continue;
			}
			$term     = $node['term'];
			$children = isset( $node['children'] ) && is_array( $node['children'] ) ? $node['children'] : array();
			$label    = self::render_taxonomy_term_label(
				$taxonomy,
				$term,
				$instance_index,
				$item_index,
				$is_radio,
				$radio_name,
				$show_count
			);
			if ( '' === $label ) {
				continue;
			}

			$slug = isset( $term['slug'] ) ? (string) $term['slug'] : '';
			if ( empty( $children ) ) {
				$html .= '<div class="dsm-loop-filter__term-branch">' . et_core_esc_previously( $label ) . '</div>';
				continue;
			}

			$panel_id   = 'dsm-lf-' . absint( $instance_index ) . '-i' . absint( $item_index ) . '-kids-' . sanitize_html_class( $slug );
			$show_label = __( 'Show subcategories', 'dsm-supreme-modules-pro-for-divi' );
			$hide_label = __( 'Hide subcategories', 'dsm-supreme-modules-pro-for-divi' );
			$toggle     = sprintf(
				'<button type="button" class="dsm-loop-filter__term-toggle" aria-expanded="%4$s" aria-controls="%1$s" aria-label="%2$s" data-dsm-lf-label-show="%5$s" data-dsm-lf-label-hide="%3$s"><span class="dsm-loop-filter__term-toggle-icon et-pb-icon" aria-hidden="true"></span></button>',
				esc_attr( $panel_id ),
				esc_attr( $start_expanded ? $hide_label : $show_label ),
				esc_attr( $hide_label ),
				$start_expanded ? 'true' : 'false',
				esc_attr( $show_label )
			);
			$kids_html  = self::render_taxonomy_term_tree(
				$taxonomy,
				$children,
				$instance_index,
				$item_index,
				$is_radio,
				$radio_name,
				$start_expanded,
				$show_count
			);
			$html      .= sprintf(
				'<div class="dsm-loop-filter__term-branch"><div class="dsm-loop-filter__term-row">%1$s%2$s</div><div class="dsm-loop-filter__term-children" id="%3$s"%5$s>%4$s</div></div>',
				et_core_esc_previously( $label ),
				et_core_esc_previously( $toggle ),
				esc_attr( $panel_id ),
				et_core_esc_previously( $kids_html ),
				$start_expanded ? '' : ' hidden'
			);
		}

		return et_core_intentionally_unescaped( $html, 'html' );
	}

	/**
	 * Select options, optionally indented by hierarchy.
	 *
	 * @param array<int, array{id?: int, parent?: int, slug: string, name: string, count?: int}> $terms     Flat terms.
	 * @param bool                                                                               $indent    Indent children.
	 * @param bool                                                                               $show_count Append the post count.
	 * @return string
	 */
	private static function render_taxonomy_select_options( array $terms, bool $indent, bool $show_count = false ): string {
		$options = '<option value="">' . esc_html__( 'All', 'dsm-supreme-modules-pro-for-divi' ) . '</option>';
		if ( ! $indent ) {
			foreach ( $terms as $term ) {
				if ( ! is_array( $term ) || ! isset( $term['slug'] ) ) {
					continue;
				}
				$options .= sprintf(
					'<option value="%1$s">%2$s</option>',
					esc_attr( (string) $term['slug'] ),
					esc_html( (string) ( $term['name'] ?? '' ) . ( $show_count ? self::taxonomy_term_count_text( $term ) : '' ) )
				);
			}
			return et_core_intentionally_unescaped( $options, 'html' );
		}

		$walk = static function ( array $nodes, int $depth ) use ( &$walk, &$options ): void {
			foreach ( $nodes as $node ) {
				if ( ! is_array( $node ) || ! isset( $node['term'] ) || ! is_array( $node['term'] ) ) {
					continue;
				}
				$term = $node['term'];
				$slug = isset( $term['slug'] ) ? (string) $term['slug'] : '';
				$name = isset( $term['name'] ) ? (string) $term['name'] : '';
				if ( '' === $slug ) {
					continue;
				}
				$prefix   = $depth > 0 ? str_repeat( '— ', $depth ) : '';
				$options .= sprintf(
					'<option value="%1$s">%2$s</option>',
					esc_attr( $slug ),
					esc_html( $prefix . $name . ( $show_count ? self::taxonomy_term_count_text( $term ) : '' ) )
				);
				$children = isset( $node['children'] ) && is_array( $node['children'] ) ? $node['children'] : array();
				if ( ! empty( $children ) ) {
					$walk( $children, $depth + 1 );
				}
			}
		};
		$walk( self::build_taxonomy_term_tree( $terms ), 0 );

		return et_core_intentionally_unescaped( $options, 'html' );
	}

	/**
	 * Whether a parsed block is a Loop Filter Item child.
	 *
	 * @param array<string, mixed> $block Block.
	 * @return bool
	 */
	private static function is_filter_item_block( array $block ): bool {
		return ( $block['blockName'] ?? '' ) === 'dsm/loop-filter-item';
	}

	/**
	 * Collect filter-item child blocks in Layers order.
	 *
	 * @param array<int, array<string, mixed>> $inner_blocks Parent inner blocks.
	 * @return list<array<string, mixed>>
	 */
	private static function collect_filter_item_blocks( array $inner_blocks ): array {
		$items = array();
		foreach ( $inner_blocks as $block ) {
			if ( ! is_array( $block ) ) {
				continue;
			}
			if ( self::is_filter_item_block( $block ) ) {
				$items[] = $block;
			}
		}
		return $items;
	}

	/**
	 * Inner blocks used for Loop results (exclude filter items).
	 *
	 * @param array<int, array<string, mixed>> $inner_blocks Parent inner blocks.
	 * @return list<array<string, mixed>>
	 */
	private static function collect_results_inner_blocks( array $inner_blocks ): array {
		$out = array();
		foreach ( $inner_blocks as $block ) {
			if ( ! is_array( $block ) ) {
				continue;
			}
			if ( self::is_filter_item_block( $block ) ) {
				continue;
			}
			$out[] = $block;
		}
		return $out;
	}

	/**
	 * Render one taxonomy control.
	 *
	 * @param string $taxonomy          Taxonomy slug.
	 * @param string $taxonomy_ui       checkbox|radio|pills|pills_single|select.
	 * @param string $label             Visible label (empty/whitespace = omit; a11y uses taxonomy name).
	 * @param array  $terms             Term rows with slug, name, optional id/parent/count.
	 * @param int    $instance_index    Instance index.
	 * @param int    $item_index        Item index for unique ids.
	 * @param string $terms_layout      inline|stacked (checkbox/radio).
	 * @param string $tax_relation      AND|OR for multi-term checkbox groups.
	 * @param bool   $collapse_subterms Nest hierarchical children behind a disclosure.
	 * @param bool   $expand_subterms   Start with nested children visible.
	 * @param bool   $show_term_count   Append the post count on checkbox, radio, and select.
	 * @return string
	 */
	private static function render_taxonomy_control(
		string $taxonomy,
		string $taxonomy_ui,
		string $label,
		array $terms,
		int $instance_index,
		int $item_index,
		string $terms_layout = 'stacked',
		string $tax_relation = 'OR',
		bool $collapse_subterms = false,
		bool $expand_subterms = false,
		bool $show_term_count = false
	): string {
		if ( '' === $taxonomy ) {
			return '';
		}

		$label        = trim( $label );
		$tax_relation = LoopFilterExtension::sanitize_tax_relation( $tax_relation, 'OR' );

		$tax_obj    = get_taxonomy( $taxonomy );
		$a11y_label = '' !== $label
			? $label
			: ( $tax_obj instanceof \WP_Taxonomy ? (string) $tax_obj->labels->name : $taxonomy );
		if ( '' === $a11y_label ) {
			$a11y_label = $taxonomy;
		}

		$visible_label_html = '' !== $label
			? sprintf( '<span class="dsm-loop-filter__label">%s</span>', esc_html( $label ) )
			: '';

		$tax_relation_attr = sprintf( ' data-tax-relation="%s"', esc_attr( $tax_relation ) );

		if ( empty( $terms ) ) {
			return sprintf(
				'<div class="dsm-loop-filter__taxonomy dsm-loop-filter__taxonomy--empty" data-taxonomy="%1$s"%5$s%4$s>%2$s<p class="dsm-loop-filter__empty-terms">%3$s</p></div>',
				esc_attr( $taxonomy ),
				et_core_esc_previously( $visible_label_html ),
				esc_html__( 'No terms available yet.', 'dsm-supreme-modules-pro-for-divi' ),
				'' !== $label ? '' : et_core_esc_previously( sprintf( ' aria-label="%s"', esc_attr( $a11y_label ) ) ),
				et_core_esc_previously( $tax_relation_attr )
			);
		}

		$term_tree = $collapse_subterms && is_taxonomy_hierarchical( $taxonomy )
			? self::build_taxonomy_term_tree( $terms )
			: array();
		$use_tree  = false;
		foreach ( $term_tree as $node ) {
			if ( is_array( $node ) && ! empty( $node['children'] ) ) {
				$use_tree = true;
				break;
			}
		}

		if ( 'select' === $taxonomy_ui ) {
			$options = self::render_taxonomy_select_options( $terms, $use_tree, $show_term_count );
			return sprintf(
				'<label class="dsm-loop-filter__taxonomy dsm-loop-filter__taxonomy--select" data-taxonomy="%2$s"%5$s>%1$s<select class="et_pb_contact_select input dsm-loop-filter__select" name="dsm_lf_terms" data-taxonomy="%2$s" aria-label="%3$s">%4$s</select></label>',
				et_core_esc_previously( $visible_label_html ),
				esc_attr( $taxonomy ),
				esc_attr( $a11y_label ),
				et_core_esc_previously( $options ),
				et_core_esc_previously( $tax_relation_attr )
			);
		}

		$is_pills         = 'pills' === $taxonomy_ui || 'pills_single' === $taxonomy_ui;
		$is_radio         = 'radio' === $taxonomy_ui;
		$pills_single     = 'pills_single' === $taxonomy_ui;
		$use_radio_inputs = $is_radio || $pills_single;
		$inputs           = '';
		$radio_name       = 'dsm_lf_terms_' . absint( $instance_index ) . '_' . absint( $item_index );

		if ( $is_radio ) {
			// Empty "All" matches dropdown clearable UX; Reset also clears.
			$all_id  = 'dsm-lf-' . absint( $instance_index ) . '-i' . absint( $item_index ) . '-term-all';
			$inputs .= sprintf(
				'<label class="dsm-loop-filter__term" for="%1$s"><input type="radio" class="dsm-loop-filter__radio" id="%1$s" name="%2$s" value="" data-taxonomy="%3$s" checked /> <span>%4$s</span></label>',
				esc_attr( $all_id ),
				esc_attr( $radio_name ),
				esc_attr( $taxonomy ),
				esc_html__( 'All', 'dsm-supreme-modules-pro-for-divi' )
			);
		} elseif ( $pills_single ) {
			// One year (or other term) at a time. Empty All clears the selection.
			$all_id  = 'dsm-lf-' . absint( $instance_index ) . '-i' . absint( $item_index ) . '-term-all';
			$inputs .= sprintf(
				'<label class="dsm-loop-filter__term" for="%1$s"><input type="radio" class="dsm-loop-filter__radio" id="%1$s" name="%2$s" value="" data-taxonomy="%3$s" data-dsm-lf-pill-all="1" checked /> <span>%4$s</span></label>',
				esc_attr( $all_id ),
				esc_attr( $radio_name ),
				esc_attr( $taxonomy ),
				esc_html__( 'All', 'dsm-supreme-modules-pro-for-divi' )
			);
		} elseif ( $is_pills ) {
			// Empty All clears the multi-select. It is not a taxonomy term.
			$all_id  = 'dsm-lf-' . absint( $instance_index ) . '-i' . absint( $item_index ) . '-term-all';
			$inputs .= sprintf(
				'<label class="dsm-loop-filter__term" for="%1$s"><input type="checkbox" class="dsm-loop-filter__checkbox" id="%1$s" value="" data-taxonomy="%2$s" data-dsm-lf-pill-all="1" checked /> <span>%3$s</span></label>',
				esc_attr( $all_id ),
				esc_attr( $taxonomy ),
				esc_html__( 'All', 'dsm-supreme-modules-pro-for-divi' )
			);
		}

		if ( $use_tree ) {
			$inputs .= self::render_taxonomy_term_tree(
				$taxonomy,
				$term_tree,
				$instance_index,
				$item_index,
				$use_radio_inputs,
				$radio_name,
				$expand_subterms,
				$show_term_count
			);
		} elseif ( $use_radio_inputs ) {
			foreach ( $terms as $term ) {
				$inputs .= self::render_taxonomy_term_label(
					$taxonomy,
					$term,
					$instance_index,
					$item_index,
					true,
					$radio_name,
					$show_term_count
				);
			}
		} else {
			foreach ( $terms as $term ) {
				$inputs .= self::render_taxonomy_term_label(
					$taxonomy,
					$term,
					$instance_index,
					$item_index,
					false,
					$radio_name,
					$show_term_count
				);
			}
		}

		$legend_html = '' !== $label
			? sprintf( '<legend class="dsm-loop-filter__label">%s</legend>', esc_html( $label ) )
			: '';

		$terms_layout   = self::normalize_terms_layout( $terms_layout );
		$is_stacked     = 'stacked' === $terms_layout;
		if ( $is_pills ) {
			$taxonomy_class = 'dsm-loop-filter__taxonomy dsm-loop-filter__taxonomy--pills';
		} elseif ( $is_radio ) {
			$taxonomy_class = 'dsm-loop-filter__taxonomy dsm-loop-filter__taxonomy--radio';
		} else {
			$taxonomy_class = 'dsm-loop-filter__taxonomy dsm-loop-filter__taxonomy--checkbox';
		}
		$terms_class    = 'dsm-loop-filter__terms';
		if ( $is_stacked ) {
			$taxonomy_class .= ' dsm-loop-filter__taxonomy--stacked';
			$terms_class    .= ' dsm-loop-filter__terms--stacked';
		}
		if ( $use_tree ) {
			$taxonomy_class .= ' dsm-loop-filter__taxonomy--tree';
			$terms_class    .= ' dsm-loop-filter__terms--tree';
		}
		$pills_selection_attr = $is_pills
			? sprintf( ' data-dsm-lf-pills-selection="%s"', $pills_single ? 'single' : 'multiple' )
			: '';

		return sprintf(
			'<fieldset class="%5$s" data-taxonomy="%1$s" data-terms-layout="%7$s"%8$s%9$s%4$s>%2$s<div class="%6$s">%3$s</div></fieldset>',
			esc_attr( $taxonomy ),
			et_core_esc_previously( $legend_html ),
			et_core_esc_previously( $inputs ),
			'' !== $label ? '' : et_core_esc_previously( sprintf( ' aria-label="%s"', esc_attr( $a11y_label ) ) ),
			esc_attr( $taxonomy_class ),
			esc_attr( $terms_class ),
			esc_attr( $terms_layout ),
			et_core_esc_previously( $tax_relation_attr ),
			et_core_esc_previously( $pills_selection_attr )
		);
	}

	/**
	 * Build author options for the filter UI (users with published posts).
	 *
	 * Prefer authors of the nested Loop post type(s); fall back to any
	 * published post authors when post types are unknown.
	 *
	 * @param array<int, string> $loop_post_types Nested loop post types.
	 * @return array<int, array{id: int, name: string}>
	 */
	private static function get_author_options( array $loop_post_types ): array {
		$post_types = array();
		foreach ( $loop_post_types as $pt ) {
			$pt = sanitize_key( (string) $pt );
			if ( '' !== $pt && post_type_exists( $pt ) ) {
				$post_types[] = $pt;
			}
		}
		$post_types = array_values( array_unique( $post_types ) );

		$query_args = array(
			'number'              => 200,
			'orderby'             => 'display_name',
			'order'               => 'ASC',
			'fields'              => array( 'ID', 'display_name' ),
			'has_published_posts' => ! empty( $post_types ) ? $post_types : true,
		);

		/**
		 * Filter WP_User_Query args for Supreme Loop Filter author options.
		 *
		 * @param array<string, mixed> $query_args      User query args.
		 * @param array<int, string>         $loop_post_types Nested loop post types.
		 */
		$query_args = apply_filters( 'dsm_loop_filter_author_query_args', $query_args, $loop_post_types );
		if ( ! is_array( $query_args ) ) {
			$query_args = array(
				'number'              => 200,
				'orderby'             => 'display_name',
				'order'               => 'ASC',
				'fields'              => array( 'ID', 'display_name' ),
				'has_published_posts' => true,
			);
		}

		$users = get_users( $query_args );
		$out   = array();
		if ( is_array( $users ) ) {
			foreach ( $users as $user ) {
				if ( $user instanceof \WP_User ) {
					$id   = (int) $user->ID;
					$name = (string) $user->display_name;
				} elseif ( is_object( $user ) ) {
					$id   = isset( $user->ID ) ? (int) $user->ID : 0;
					$name = isset( $user->display_name ) ? (string) $user->display_name : '';
				} else {
					continue;
				}
				if ( $id < 1 || '' === $name ) {
					continue;
				}
				$out[] = array(
					'id'   => $id,
					'name' => $name,
				);
			}
		}

		/**
		 * Filter author options shown in Supreme Loop Filter UI.
		 *
		 * @param array<int, array{id: int, name: string}> $out             Authors.
		 * @param array<int, string>                              $loop_post_types Nested loop post types.
		 */
		$filtered = apply_filters( 'dsm_loop_filter_author_options', $out, $loop_post_types );

		return is_array( $filtered ) ? $filtered : $out;
	}

	/**
	 * Optional visible Field Label (empty hides the chrome, matching Search/Taxonomy).
	 *
	 * @param string $label Field Label from the Filter Item.
	 * @return string Empty string or a span.dsm-loop-filter__label.
	 */
	private static function render_optional_field_label( string $label ): string {
		$label = trim( $label );
		if ( '' === $label ) {
			return '';
		}

		return sprintf(
			'<span class="dsm-loop-filter__label">%s</span>',
			esc_html( $label )
		);
	}

	/**
	 * Optional fieldset legend (empty Field Label hides the chrome).
	 *
	 * @param string $label Field Label from the Filter Item.
	 * @return string Empty string or a legend.dsm-loop-filter__label.
	 */
	private static function render_optional_field_legend( string $label ): string {
		$label = trim( $label );
		if ( '' === $label ) {
			return '';
		}

		return sprintf(
			'<legend class="dsm-loop-filter__label">%s</legend>',
			esc_html( $label )
		);
	}

	/**
	 * Render Author select control.
	 *
	 * @param string                                   $label   Optional visible label.
	 * @param array<int, array{id: int, name: string}> $authors Author options.
	 * @return string
	 */
	private static function render_author_control( string $label, array $authors ): string {
		$options_html = sprintf(
			'<option value="">%s</option>',
			esc_html__( 'All authors', 'dsm-supreme-modules-pro-for-divi' )
		);

		foreach ( $authors as $author ) {
			if ( ! is_array( $author ) ) {
				continue;
			}
			$id   = isset( $author['id'] ) ? absint( $author['id'] ) : 0;
			$name = isset( $author['name'] ) && is_scalar( $author['name'] )
				? (string) $author['name']
				: '';
			if ( $id < 1 || '' === $name ) {
				continue;
			}
			$options_html .= sprintf(
				'<option value="%1$d">%2$s</option>',
				$id,
				esc_html( $name )
			);
		}

		return sprintf(
			'<label class="dsm-loop-filter__author">%1$s<select class="et_pb_contact_select input dsm-loop-filter__select dsm-loop-filter__author-select" name="dsm_lf_author" aria-label="%2$s">%3$s</select></label>',
			et_core_esc_previously( self::render_optional_field_label( $label ) ),
			esc_attr__( 'Author', 'dsm-supreme-modules-pro-for-divi' ),
			et_core_esc_previously( $options_html )
		);
	}

	/**
	 * Render Order By controls.
	 *
	 * @param string $label           Optional label.
	 * @param string $orderby_default date|title|menu_order|comment_count|rand.
	 * @param string $order_default   ASC|DESC.
	 * @return string
	 */
	private static function render_orderby_control( string $label, string $orderby_default, string $order_default ): string {
		$orderby_default = LoopFilterExtension::sanitize_orderby( $orderby_default );
		if ( '' === $orderby_default ) {
			$orderby_default = 'date';
		}
		$order_default = LoopFilterExtension::sanitize_order( $order_default );
		$label         = trim( $label );
		$orderby_aria  = '' !== $label
			? $label
			: __( 'Sort by', 'dsm-supreme-modules-pro-for-divi' );

		$orderby_options = array(
			'date'          => __( 'Date', 'dsm-supreme-modules-pro-for-divi' ),
			'title'         => __( 'Title', 'dsm-supreme-modules-pro-for-divi' ),
			'menu_order'    => __( 'Menu order', 'dsm-supreme-modules-pro-for-divi' ),
			'comment_count' => __( 'Comment count', 'dsm-supreme-modules-pro-for-divi' ),
			'rand'          => __( 'Random', 'dsm-supreme-modules-pro-for-divi' ),
		);
		$order_options   = array(
			'DESC' => __( 'Descending', 'dsm-supreme-modules-pro-for-divi' ),
			'ASC'  => __( 'Ascending', 'dsm-supreme-modules-pro-for-divi' ),
		);

		$orderby_html = '';
		foreach ( $orderby_options as $value => $opt_label ) {
			$orderby_html .= sprintf(
				'<option value="%1$s"%2$s>%3$s</option>',
				esc_attr( $value ),
				selected( $orderby_default, $value, false ),
				esc_html( $opt_label )
			);
		}

		$order_html = '';
		foreach ( $order_options as $value => $opt_label ) {
			$order_html .= sprintf(
				'<option value="%1$s"%2$s>%3$s</option>',
				esc_attr( $value ),
				selected( $order_default, $value, false ),
				esc_html( $opt_label )
			);
		}

		return sprintf(
			'<div class="dsm-loop-filter__orderby-wrap">%1$s<div class="dsm-loop-filter__orderby-fields"><select class="et_pb_contact_select input dsm-loop-filter__select dsm-loop-filter__orderby" name="dsm_lf_orderby" aria-label="%2$s">%3$s</select><select class="et_pb_contact_select input dsm-loop-filter__select dsm-loop-filter__order" name="dsm_lf_order" aria-label="%4$s">%5$s</select></div></div>',
			et_core_esc_previously( self::render_optional_field_label( $label ) ),
			esc_attr( $orderby_aria ),
			et_core_esc_previously( $orderby_html ),
			esc_attr__( 'Order', 'dsm-supreme-modules-pro-for-divi' ),
			et_core_esc_previously( $order_html )
		);
	}

	/**
	 * Render published-date from/to inputs (HTML type=date).
	 *
	 * @param string $label Optional visible label.
	 * @return string
	 */
	private static function render_date_control( string $label ): string {
		return sprintf(
			'<div class="dsm-loop-filter__date">%1$s<div class="dsm-loop-filter__date-fields"><input type="date" class="input dsm-loop-filter__date-input dsm-loop-filter__date-from" name="dsm_lf_date_from" autocomplete="off" aria-label="%2$s" /><input type="date" class="input dsm-loop-filter__date-input dsm-loop-filter__date-to" name="dsm_lf_date_to" autocomplete="off" aria-label="%3$s" /></div></div>',
			et_core_esc_previously( self::render_optional_field_label( $label ) ),
			esc_attr__( 'From date', 'dsm-supreme-modules-pro-for-divi' ),
			esc_attr__( 'To date', 'dsm-supreme-modules-pro-for-divi' )
		);
	}

	/**
	 * Render Custom Field control (text, select, checkbox, or radio).
	 *
	 * @param string                                          $label          Optional visible label.
	 * @param string                                          $meta_key       Sanitized meta key (empty when unset).
	 * @param string                                          $field_ui       text|checkbox|radio|select.
	 * @param array<int, array{value: string, label: string}> $values         Distinct values for list UIs.
	 * @param int                                             $instance_index Instance index.
	 * @param int                                             $item_index     Item index for unique ids.
	 * @param string                                          $terms_layout   inline|stacked (checkbox/radio).
	 * @return string
	 */
	private static function render_custom_field_control(
		string $label,
		string $meta_key,
		string $field_ui = 'text',
		array $values = array(),
		int $instance_index = 0,
		int $item_index = 0,
		string $terms_layout = 'stacked'
	): string {
		$visible_label = trim( $label );
		$field_ui      = function_exists( 'dsm_loop_filter_normalize_custom_field_ui' )
			? dsm_loop_filter_normalize_custom_field_ui( $field_ui )
			: 'text';
		$a11y_label    = '' !== $visible_label
			? $visible_label
			: ( '' !== $meta_key
				? $meta_key
				: __( 'Custom field', 'dsm-supreme-modules-pro-for-divi' ) );
		$data_attr     = '' !== $meta_key
			? sprintf( ' data-dsm-lf-meta-key="%s"', esc_attr( $meta_key ) )
			: '';

		if ( 'text' === $field_ui ) {
			$placeholder = '' !== $meta_key
				? $meta_key
				: __( 'Enter value…', 'dsm-supreme-modules-pro-for-divi' );

			return sprintf(
				'<label class="dsm-loop-filter__custom-field"%4$s>%1$s<input type="text" class="input dsm-loop-filter__custom-field-input" placeholder="%2$s" autocomplete="off" aria-label="%3$s"%4$s /></label>',
				et_core_esc_previously( self::render_optional_field_label( $visible_label ) ),
				esc_attr( $placeholder ),
				esc_attr( $a11y_label ),
				et_core_esc_previously( $data_attr )
			);
		}

		$visible_label_html = '' !== $visible_label
			? sprintf( '<span class="dsm-loop-filter__label">%s</span>', esc_html( $visible_label ) )
			: '';

		if ( empty( $values ) ) {
			return sprintf(
				'<div class="dsm-loop-filter__custom-field dsm-loop-filter__custom-field--empty"%4$s%3$s>%1$s<p class="dsm-loop-filter__empty-terms">%2$s</p></div>',
				et_core_esc_previously( $visible_label_html ),
				esc_html__( 'No values available yet.', 'dsm-supreme-modules-pro-for-divi' ),
				'' !== $visible_label ? '' : et_core_esc_previously( sprintf( ' aria-label="%s"', esc_attr( $a11y_label ) ) ),
				et_core_esc_previously( $data_attr )
			);
		}

		if ( 'select' === $field_ui ) {
			$options = '<option value="">' . esc_html__( 'All', 'dsm-supreme-modules-pro-for-divi' ) . '</option>';
			foreach ( $values as $row ) {
				$value = isset( $row['value'] ) ? (string) $row['value'] : '';
				$name  = isset( $row['label'] ) ? (string) $row['label'] : $value;
				if ( '' === $value ) {
					continue;
				}
				$options .= sprintf(
					'<option value="%1$s">%2$s</option>',
					esc_attr( $value ),
					esc_html( $name )
				);
			}

			return sprintf(
				'<label class="dsm-loop-filter__custom-field dsm-loop-filter__custom-field--select"%4$s>%1$s<select class="et_pb_contact_select input dsm-loop-filter__select" name="dsm_lf_mq" aria-label="%2$s">%3$s</select></label>',
				et_core_esc_previously( $visible_label_html ),
				esc_attr( $a11y_label ),
				et_core_esc_previously( $options ),
				et_core_esc_previously( $data_attr )
			);
		}

		$is_radio   = 'radio' === $field_ui;
		$inputs     = '';
		$radio_name = 'dsm_lf_mq_' . absint( $instance_index ) . '_' . absint( $item_index );

		if ( $is_radio ) {
			$all_id  = 'dsm-lf-' . absint( $instance_index ) . '-i' . absint( $item_index ) . '-mv-all';
			$inputs .= sprintf(
				'<label class="dsm-loop-filter__term" for="%1$s"><input type="radio" class="dsm-loop-filter__radio" id="%1$s" name="%2$s" value="" checked /> <span>%3$s</span></label>',
				esc_attr( $all_id ),
				esc_attr( $radio_name ),
				esc_html__( 'All', 'dsm-supreme-modules-pro-for-divi' )
			);
		}

		foreach ( $values as $idx => $row ) {
			$value = isset( $row['value'] ) ? (string) $row['value'] : '';
			$name  = isset( $row['label'] ) ? (string) $row['label'] : $value;
			if ( '' === $value ) {
				continue;
			}
			$class_slug = sanitize_html_class( $value );
			if ( '' === $class_slug ) {
				$class_slug = (string) absint( $idx );
			}
			$id = 'dsm-lf-' . absint( $instance_index ) . '-i' . absint( $item_index ) . '-mv-' . $class_slug;
			if ( $is_radio ) {
				$inputs .= sprintf(
					'<label class="dsm-loop-filter__term" for="%1$s"><input type="radio" class="dsm-loop-filter__radio" id="%1$s" name="%2$s" value="%3$s" /> <span>%4$s</span></label>',
					esc_attr( $id ),
					esc_attr( $radio_name ),
					esc_attr( $value ),
					esc_html( $name )
				);
			} else {
				$inputs .= sprintf(
					'<label class="dsm-loop-filter__term" for="%1$s"><input type="checkbox" class="dsm-loop-filter__checkbox" id="%1$s" name="dsm_lf_mq[]" value="%2$s" /> <span>%3$s</span></label>',
					esc_attr( $id ),
					esc_attr( $value ),
					esc_html( $name )
				);
			}
		}

		$legend_html = '' !== $visible_label
			? sprintf( '<legend class="dsm-loop-filter__label">%s</legend>', esc_html( $visible_label ) )
			: '';

		$terms_layout = self::normalize_terms_layout( $terms_layout );
		$is_stacked   = 'stacked' === $terms_layout;
		$wrap_class   = $is_radio
			? 'dsm-loop-filter__custom-field dsm-loop-filter__custom-field--radio'
			: 'dsm-loop-filter__custom-field dsm-loop-filter__custom-field--checkbox';
		$terms_class  = 'dsm-loop-filter__terms';
		if ( $is_stacked ) {
			$wrap_class  .= ' dsm-loop-filter__custom-field--stacked';
			$terms_class .= ' dsm-loop-filter__terms--stacked';
		}

		return sprintf(
			'<fieldset class="%1$s"%2$s data-terms-layout="%3$s"%4$s>%5$s<div class="%6$s">%7$s</div></fieldset>',
			esc_attr( $wrap_class ),
			et_core_esc_previously( $data_attr ),
			esc_attr( $terms_layout ),
			'' !== $visible_label ? '' : et_core_esc_previously( sprintf( ' aria-label="%s"', esc_attr( $a11y_label ) ) ),
			et_core_esc_previously( $legend_html ),
			esc_attr( $terms_class ),
			et_core_esc_previously( $inputs )
		);
	}

	/**
	 * Render WooCommerce min/max price inputs (legacy DOM — byte-identical default).
	 *
	 * @param string $label           Optional visible label.
	 * @param string $min_placeholder Min input placeholder.
	 * @param string $max_placeholder Max input placeholder.
	 * @return string
	 */
	private static function render_price_control( string $label, string $min_placeholder, string $max_placeholder ): string {
		if ( ! LoopFilterExtension::is_woocommerce_active() ) {
			return '';
		}
		if ( '' === $min_placeholder ) {
			$min_placeholder = __( 'Min', 'dsm-supreme-modules-pro-for-divi' );
		}
		if ( '' === $max_placeholder ) {
			$max_placeholder = __( 'Max', 'dsm-supreme-modules-pro-for-divi' );
		}

		return sprintf(
			'<div class="dsm-loop-filter__price">%1$s<div class="dsm-loop-filter__price-fields"><input type="number" class="input dsm-loop-filter__price-input dsm-loop-filter__price-min" name="dsm_lf_min_price" min="0" step="any" placeholder="%2$s" inputmode="decimal" autocomplete="off" aria-label="%3$s" /><input type="number" class="input dsm-loop-filter__price-input dsm-loop-filter__price-max" name="dsm_lf_max_price" min="0" step="any" placeholder="%4$s" inputmode="decimal" autocomplete="off" aria-label="%5$s" /></div></div>',
			et_core_esc_previously( self::render_optional_field_label( $label ) ),
			esc_attr( $min_placeholder ),
			esc_attr__( 'Minimum price', 'dsm-supreme-modules-pro-for-divi' ),
			esc_attr( $max_placeholder ),
			esc_attr__( 'Maximum price', 'dsm-supreme-modules-pro-for-divi' )
		);
	}

	/**
	 * Render a Price filter item from child attrs (registry-driven styles).
	 *
	 * `input-fields` with no extras reuses {@see render_price_control()} so saved
	 * layouts keep the original DOM.
	 *
	 * @param array<string, mixed> $item_attrs       Child attrs.
	 * @param int                  $instance_index   Parent instance index.
	 * @param int                  $item_index       Child index.
	 * @param array<int, string>   $loop_post_types  Nested loop post types.
	 * @return string
	 */
	private static function render_price_control_from_attrs( array $item_attrs, int $instance_index, int $item_index, array $loop_post_types ): string {
		if ( ! LoopFilterExtension::is_woocommerce_active() ) {
			return '';
		}

		$label           = self::inner_desktop_string( $item_attrs, 'label', '' );
		$min_placeholder = self::inner_desktop_string( $item_attrs, 'price_min_placeholder', __( 'Min', 'dsm-supreme-modules-pro-for-divi' ) );
		$max_placeholder = self::inner_desktop_string( $item_attrs, 'price_max_placeholder', __( 'Max', 'dsm-supreme-modules-pro-for-divi' ) );
		$raw_price_ui    = self::inner_desktop_string( $item_attrs, 'price_ui', 'input-fields' );
		$price_ui        = function_exists( 'dsm_loop_filter_normalize_price_ui' )
			? dsm_loop_filter_normalize_price_ui( $raw_price_ui )
			: 'input-fields';
		$separator       = self::inner_desktop_string( $item_attrs, 'price_separator', '' );
		$show_go         = self::inner_desktop_string( $item_attrs, 'price_show_go', 'off' );
		$has_extras      = '' !== trim( $separator ) || 'on' === $show_go;

		if ( 'input-fields' === $price_ui && ! $has_extras ) {
			return self::render_price_control( $label, $min_placeholder, $max_placeholder );
		}

		$supports = function_exists( 'dsm_loop_filter_price_style_supports' )
			? dsm_loop_filter_price_style_supports( $price_ui )
			: array( 'fields' => true );
		$modifier = function_exists( 'dsm_loop_filter_price_style_modifier_class' )
			? dsm_loop_filter_price_style_modifier_class( $price_ui )
			: '';

		$prefix      = self::inner_desktop_string( $item_attrs, 'price_currency_prefix', '' );
		$suffix      = self::inner_desktop_string( $item_attrs, 'price_currency_suffix', '' );
		$currency    = function_exists( 'dsm_loop_filter_price_currency' )
			? dsm_loop_filter_price_currency( $prefix, $suffix )
			: array();
		$step        = self::inner_desktop_string( $item_attrs, 'price_step', '1' );
		$step_f      = is_numeric( $step ) && (float) $step > 0 ? (float) $step : 1.0;
		$min_gap     = self::inner_desktop_string( $item_attrs, 'price_min_gap', '1' );
		$min_gap_f   = is_numeric( $min_gap ) && (float) $min_gap > 0 ? (float) $min_gap : $step_f;
		$label_pos   = function_exists( 'dsm_loop_filter_normalize_price_label_position' )
			? dsm_loop_filter_normalize_price_label_position( self::inner_desktop_string( $item_attrs, 'price_label_position', 'above' ) )
			: 'above';
		$apply_mode  = function_exists( 'dsm_loop_filter_normalize_price_apply_mode' )
			? dsm_loop_filter_normalize_price_apply_mode( self::inner_desktop_string( $item_attrs, 'price_apply_mode', 'auto' ) )
			: 'auto';
		$apply_label = self::inner_desktop_string( $item_attrs, 'price_apply_label', __( 'Apply', 'dsm-supreme-modules-pro-for-divi' ) );
		if ( '' === $apply_label ) {
			$apply_label = __( 'Apply', 'dsm-supreme-modules-pro-for-divi' );
		}
		$go_label = self::inner_desktop_string( $item_attrs, 'price_go_label', __( 'Go', 'dsm-supreme-modules-pro-for-divi' ) );
		if ( '' === $go_label ) {
			$go_label = __( 'Go', 'dsm-supreme-modules-pro-for-divi' );
		}

		$show_quick = self::inner_desktop_string( $item_attrs, 'show_quick_buckets', '' );
		if ( '' === $show_quick ) {
			$show_quick = 'slider-with-buckets' === $price_ui ? 'on' : 'off';
		}
		$show_hist = self::inner_desktop_string( $item_attrs, 'show_histogram', '' );
		if ( '' === $show_hist ) {
			$show_hist = 'histogram-slider' === $raw_price_ui ? 'on' : 'off';
		}
		$hist_count = absint( self::inner_desktop_string( $item_attrs, 'histogram_buckets', '20' ) );
		if ( $hist_count < 4 ) {
			$hist_count = 20;
		}
		$need_hist   = ! empty( $supports['histogram'] ) && 'on' === $show_hist;
		$need_slider = ! empty( $supports['slider'] );

		$override_min = self::inner_desktop_string( $item_attrs, 'price_range_min', '' );
		$override_max = self::inner_desktop_string( $item_attrs, 'price_range_max', '' );

		$stats = array(
			'min'     => 0.0,
			'max'     => 0.0,
			'buckets' => array(),
			'empty'   => true,
		);
		if ( $need_slider || $need_hist ) {
			$stats = function_exists( 'dsm_loop_filter_query_price_stats' )
				? dsm_loop_filter_query_price_stats( $loop_post_types, null, $need_hist ? $hist_count : 0, $step_f )
				: $stats;
			if ( is_numeric( $override_min ) ) {
				$stats['min']   = (float) $override_min;
				$stats['empty'] = false;
			}
			if ( is_numeric( $override_max ) ) {
				$stats['max']   = (float) $override_max;
				$stats['empty'] = false;
			}
			if ( $stats['max'] < $stats['min'] ) {
				$tmp          = $stats['max'];
				$stats['max'] = $stats['min'];
				$stats['min'] = $tmp;
			}
		}

		$buckets       = array();
		$bucket_layout = function_exists( 'dsm_loop_filter_normalize_bucket_layout' )
			? dsm_loop_filter_normalize_bucket_layout( self::inner_desktop_string( $item_attrs, 'bucket_layout', 'checkbox' ) )
			: 'checkbox';

		if ( $need_slider && ( 'slider-with-buckets' === $price_ui || 'on' === $show_quick ) && ! $stats['empty'] && $stats['max'] > $stats['min'] ) {
			$quick_raw   = self::inner_desktop_string( $item_attrs, 'quick_range_count', '4' );
			$quick_count = '' === $quick_raw ? 4 : (int) $quick_raw;
			$buckets     = function_exists( 'dsm_loop_filter_auto_price_buckets' )
				? dsm_loop_filter_auto_price_buckets( (float) $stats['min'], (float) $stats['max'], $quick_count )
				: array();
		}

		$widget_id = 'dsm-lf-price-' . absint( $instance_index ) . '-' . absint( $item_index );
		$classes   = array( 'dsm-loop-filter__price' );
		if ( '' !== $modifier ) {
			$classes[] = $modifier;
		}

		$parts = self::render_optional_field_label( $label );

		if ( $need_slider && $stats['empty'] ) {
			$parts .= '<p class="dsm-loop-filter__price-empty">' . esc_html__( 'No priced products available.', 'dsm-supreme-modules-pro-for-divi' ) . '</p>';
			return sprintf(
				'<div class="%1$s" data-dsm-lf-price-ui="%2$s" data-dsm-lf-price-disabled="1">%3$s</div>',
				esc_attr( implode( ' ', $classes ) ),
				esc_attr( $price_ui ),
				et_core_esc_previously( $parts )
			);
		}

		if ( $need_slider ) {
			$parts .= self::render_price_slider_markup(
				$widget_id,
				$stats,
				$currency,
				$step_f,
				$min_gap_f,
				$label_pos,
				$need_hist,
				$min_placeholder,
				$max_placeholder,
				$separator,
				! empty( $supports['fields'] )
			);
		} elseif ( ! empty( $supports['fields'] ) ) {
			$parts .= self::render_price_fields_markup( $min_placeholder, $max_placeholder, $separator, $show_go, $go_label );
		}

		if ( ( ! empty( $supports['buckets'] ) && 'range-buckets' === $price_ui ) || ( $need_slider && 'on' === $show_quick ) ) {
			$as_pills = $need_slider || 'pills' === $bucket_layout;
			$parts   .= self::render_price_buckets_markup(
				$widget_id,
				$buckets,
				$currency,
				$as_pills ? 'pills' : $bucket_layout,
				$instance_index,
				$item_index
			);
		}

		if ( $need_slider && 'button' === $apply_mode ) {
			$parts .= sprintf(
				'<div class="dsm-loop-filter__price-apply"><button type="button" class="et_pb_button dsm-loop-filter__price-apply-btn">%s</button></div>',
				esc_html( $apply_label )
			);
		}

		$config = array(
			'ui'            => $price_ui,
			'step'          => $step_f,
			'minGap'        => $min_gap_f,
			'boundMin'      => $stats['min'],
			'boundMax'      => $stats['max'],
			'labelPosition' => $label_pos,
			'applyMode'     => $apply_mode,
			'currency'      => $currency,
		);

		$extra_attrs = '';
		if ( ! empty( $supports['goButton'] ) && 'on' === $show_go ) {
			$extra_attrs .= ' data-dsm-lf-price-go="1"';
		}
		if ( $need_slider && 'button' === $apply_mode ) {
			$extra_attrs .= ' data-dsm-lf-price-apply="button"';
		}

		$encoded = wp_json_encode( $config );
		if ( ! is_string( $encoded ) ) {
			$encoded = '{}';
		}

		return sprintf(
			'<div class="%1$s" data-dsm-lf-price-ui="%2$s" data-dsm-lf-price-config="%3$s"%4$s>%5$s</div>',
			esc_attr( implode( ' ', $classes ) ),
			esc_attr( $price_ui ),
			esc_attr( $encoded ),
			et_core_esc_previously( $extra_attrs ),
			et_core_esc_previously( $parts )
		);
	}

	/**
	 * Min/max number fields (and optional separator / Go).
	 *
	 * @param string $min_placeholder Min placeholder.
	 * @param string $max_placeholder Max placeholder.
	 * @param string $separator       Optional separator text.
	 * @param string $show_go         on|off.
	 * @param string $go_label        Go button label.
	 * @return string
	 */
	private static function render_price_fields_markup( string $min_placeholder, string $max_placeholder, string $separator, string $show_go, string $go_label ): string {
		if ( '' === $min_placeholder ) {
			$min_placeholder = __( 'Min', 'dsm-supreme-modules-pro-for-divi' );
		}
		if ( '' === $max_placeholder ) {
			$max_placeholder = __( 'Max', 'dsm-supreme-modules-pro-for-divi' );
		}

		$sep_html = '' !== trim( $separator )
			? sprintf( '<span class="dsm-loop-filter__price-separator">%s</span>', esc_html( $separator ) )
			: '';
		$go_html  = 'on' === $show_go
			? sprintf(
				'<button type="button" class="et_pb_button dsm-loop-filter__price-go">%s</button>',
				esc_html( $go_label )
			)
			: '';

		return sprintf(
			'<div class="dsm-loop-filter__price-fields"><input type="number" class="input dsm-loop-filter__price-input dsm-loop-filter__price-min" name="dsm_lf_min_price" min="0" step="any" placeholder="%1$s" inputmode="decimal" autocomplete="off" aria-label="%2$s" />%3$s<input type="number" class="input dsm-loop-filter__price-input dsm-loop-filter__price-max" name="dsm_lf_max_price" min="0" step="any" placeholder="%4$s" inputmode="decimal" autocomplete="off" aria-label="%5$s" />%6$s</div>',
			esc_attr( $min_placeholder ),
			esc_attr__( 'Minimum price', 'dsm-supreme-modules-pro-for-divi' ),
			et_core_esc_previously( $sep_html ),
			esc_attr( $max_placeholder ),
			esc_attr__( 'Maximum price', 'dsm-supreme-modules-pro-for-divi' ),
			et_core_esc_previously( $go_html )
		);
	}

	/**
	 * Dual-handle slider + optional histogram + synced number fields.
	 *
	 * @param string               $widget_id         Unique id prefix.
	 * @param array<string, mixed> $stats             Bounds + histogram.
	 * @param array<string, mixed> $currency          Currency config.
	 * @param float                $step              Step.
	 * @param float                $min_gap           Minimum handle gap.
	 * @param string               $label_pos         above|tooltip|below|none.
	 * @param bool                 $show_histogram    Whether to paint bars.
	 * @param string               $min_placeholder   Min field placeholder.
	 * @param string               $max_placeholder   Max field placeholder.
	 * @param string               $separator         Optional field separator.
	 * @param bool                 $show_fields       Whether to include number inputs.
	 * @return string
	 */
	private static function render_price_slider_markup(
		string $widget_id,
		array $stats,
		array $currency,
		float $step,
		float $min_gap,
		string $label_pos,
		bool $show_histogram,
		string $min_placeholder,
		string $max_placeholder,
		string $separator,
		bool $show_fields
	): string {
		$min = (float) ( $stats['min'] ?? 0 );
		$max = (float) ( $stats['max'] ?? 0 );
		if ( $max <= $min ) {
			$max = $min + max( $step, 1.0 );
		}

		$min_inner = function_exists( 'dsm_loop_filter_price_bound_inner_html' )
			? dsm_loop_filter_price_bound_inner_html(
				dsm_loop_filter_format_price_parts( $min, $currency, true )
			)
			: esc_html( (string) $min );
		$max_inner = function_exists( 'dsm_loop_filter_price_bound_inner_html' )
			? dsm_loop_filter_price_bound_inner_html(
				dsm_loop_filter_format_price_parts( $max, $currency, true )
			)
			: esc_html( (string) $max );

		$labels_html = '';
		if ( 'above' === $label_pos || 'below' === $label_pos ) {
			$labels_html = sprintf(
				'<div class="dsm-loop-filter__price-value-labels" data-dsm-lf-price-labels><span class="dsm-loop-filter__price-value-min">%1$s</span><span class="dsm-loop-filter__price-value-max">%2$s</span></div>',
				et_core_esc_previously( $min_inner ),
				et_core_esc_previously( $max_inner )
			);
		}

		$hist_html = '';
		$bars      = isset( $stats['buckets'] ) && is_array( $stats['buckets'] ) ? $stats['buckets'] : array();
		if ( $show_histogram && ! empty( $bars ) ) {
			$max_count = 1;
			foreach ( $bars as $bar ) {
				$count     = isset( $bar['count'] ) ? (int) $bar['count'] : 0;
				$max_count = max( $max_count, $count );
			}
			$bar_html = '';
			foreach ( $bars as $bar ) {
				$count     = isset( $bar['count'] ) ? (int) $bar['count'] : 0;
				$height    = (int) round( 100 * ( $count / $max_count ) );
				$bar_html .= sprintf(
					'<span class="dsm-loop-filter__price-hist-bar" style="height:%1$d%%" data-from="%2$s" data-to="%3$s" data-count="%4$d"></span>',
					max( 4, $height ),
					esc_attr( (string) ( $bar['from'] ?? '' ) ),
					esc_attr( (string) ( $bar['to'] ?? '' ) ),
					$count
				);
			}
			$hist_html = '<div class="dsm-loop-filter__price-hist" aria-hidden="true">' . et_core_esc_previously( $bar_html ) . '</div>';
		}

		$min_id = $widget_id . '-min';
		$max_id = $widget_id . '-max';

		$slider_html = sprintf(
			'<div class="dsm-loop-filter__price-slider" data-dsm-lf-price-slider style="--dsm-lf-price-min:%1$s;--dsm-lf-price-max:%2$s;--dsm-lf-price-low:%1$s;--dsm-lf-price-high:%2$s;">%3$s<div class="dsm-loop-filter__price-track" aria-hidden="true"><span class="dsm-loop-filter__price-track-fill"></span></div><input type="range" class="dsm-loop-filter__price-range dsm-loop-filter__price-range-min" id="%4$s" min="%1$s" max="%2$s" step="%5$s" value="%1$s" role="slider" aria-label="%6$s" aria-valuemin="%1$s" aria-valuemax="%2$s" aria-valuenow="%1$s" /><input type="range" class="dsm-loop-filter__price-range dsm-loop-filter__price-range-max" id="%7$s" min="%1$s" max="%2$s" step="%5$s" value="%2$s" role="slider" aria-label="%8$s" aria-valuemin="%1$s" aria-valuemax="%2$s" aria-valuenow="%2$s" />%9$s</div>',
			esc_attr( (string) $min ),
			esc_attr( (string) $max ),
			et_core_esc_previously( $hist_html ),
			esc_attr( $min_id ),
			esc_attr( (string) $step ),
			esc_attr__( 'Minimum price', 'dsm-supreme-modules-pro-for-divi' ),
			esc_attr( $max_id ),
			esc_attr__( 'Maximum price', 'dsm-supreme-modules-pro-for-divi' ),
			'title' === $label_pos || 'tooltip' === $label_pos
				? et_core_intentionally_unescaped(
					sprintf(
						'<span class="dsm-loop-filter__price-tooltip dsm-loop-filter__price-tooltip-min" hidden>%1$s</span><span class="dsm-loop-filter__price-tooltip dsm-loop-filter__price-tooltip-max" hidden>%2$s</span>',
						et_core_esc_previously( $min_inner ),
						et_core_esc_previously( $max_inner )
					),
					'html'
				)
				: ''
		);

		$out = '';
		if ( 'above' === $label_pos ) {
			$out .= $labels_html;
		}
		$out .= $slider_html;
		if ( 'below' === $label_pos ) {
			$out .= $labels_html;
		}
		if ( $show_fields ) {
			$out .= self::render_price_fields_markup( $min_placeholder, $max_placeholder, $separator, 'off', '' );
		}

		unset( $min_gap );

		return et_core_intentionally_unescaped( $out, 'html' );
	}

	/**
	 * Predefined price-range controls.
	 *
	 * @param string                                                     $widget_id       Unique id prefix.
	 * @param array<int, array{min: string, max: string, label: string}> $buckets         Ranges.
	 * @param array<string, mixed>                                       $currency        Currency.
	 * @param string                                                     $layout          checkbox|radio|pills|dropdown.
	 * @param int                                                        $instance_index  Instance.
	 * @param int                                                        $item_index      Item.
	 * @return string
	 */
	private static function render_price_buckets_markup( string $widget_id, array $buckets, array $currency, string $layout, int $instance_index, int $item_index ): string {
		if ( empty( $buckets ) ) {
			return '';
		}

		if ( 'dropdown' === $layout ) {
			$options = '<option value="">' . esc_html__( 'Any price', 'dsm-supreme-modules-pro-for-divi' ) . '</option>';
			foreach ( $buckets as $idx => $bucket ) {
				$label    = function_exists( 'dsm_loop_filter_auto_label_price_bucket' )
					? dsm_loop_filter_auto_label_price_bucket( $bucket, $currency )
					: (string) ( $bucket['label'] ?? '' );
				$value    = (string) ( $bucket['min'] ?? '' ) . '-' . (string) ( $bucket['max'] ?? '' );
				$options .= sprintf(
					'<option value="%1$s">%2$s</option>',
					esc_attr( $value ),
					esc_html( $label )
				);
				unset( $idx );
			}

			return sprintf(
				'<div class="dsm-loop-filter__price-buckets dsm-loop-filter__price-buckets--dropdown"><select class="et_pb_contact_select input dsm-loop-filter__select dsm-loop-filter__price-bucket-select" name="dsm_lf_price_ranges" aria-label="%1$s">%2$s</select></div>',
				esc_attr__( 'Price range', 'dsm-supreme-modules-pro-for-divi' ),
				et_core_esc_previously( $options )
			);
		}

		$is_radio = 'radio' === $layout;
		$is_pills = 'pills' === $layout;
		$inputs   = '';
		$name     = 'dsm_lf_price_ranges_' . absint( $instance_index ) . '_' . absint( $item_index );

		foreach ( $buckets as $idx => $bucket ) {
			$label = function_exists( 'dsm_loop_filter_auto_label_price_bucket' )
				? dsm_loop_filter_auto_label_price_bucket( $bucket, $currency )
				: (string) ( $bucket['label'] ?? '' );
			$value = (string) ( $bucket['min'] ?? '' ) . '-' . (string) ( $bucket['max'] ?? '' );
			$id    = $widget_id . '-b' . absint( $idx );
			if ( $is_pills ) {
				$inputs .= sprintf(
					'<button type="button" class="dsm-loop-filter__price-pill" data-dsm-lf-price-range="%1$s">%2$s</button>',
					esc_attr( $value ),
					esc_html( $label )
				);
			} elseif ( $is_radio ) {
				$inputs .= sprintf(
					'<label class="dsm-loop-filter__term dsm-loop-filter__price-bucket" for="%1$s"><input type="radio" class="dsm-loop-filter__radio dsm-loop-filter__price-bucket-input" id="%1$s" name="%2$s" value="%3$s" /> <span>%4$s</span></label>',
					esc_attr( $id ),
					esc_attr( $name ),
					esc_attr( $value ),
					esc_html( $label )
				);
			} else {
				$inputs .= sprintf(
					'<label class="dsm-loop-filter__term dsm-loop-filter__price-bucket" for="%1$s"><input type="checkbox" class="dsm-loop-filter__checkbox dsm-loop-filter__price-bucket-input" id="%1$s" name="dsm_lf_price_ranges[]" value="%2$s" /> <span>%3$s</span></label>',
					esc_attr( $id ),
					esc_attr( $value ),
					esc_html( $label )
				);
			}
		}

		$mod = $is_pills ? 'pills' : ( $is_radio ? 'radio' : 'checkbox' );

		return sprintf(
			'<div class="dsm-loop-filter__price-buckets dsm-loop-filter__price-buckets--%1$s" data-dsm-lf-bucket-layout="%1$s">%2$s</div>',
			esc_attr( $mod ),
			et_core_esc_previously( $inputs )
		);
	}

	/**
	 * SVG star row for a rating option (Divi product-review style path).
	 *
	 * @param int $rating Star count 1–5.
	 * @return string
	 */
	private static function render_rating_stars_html( int $rating ): string {
		$rating     = max( 1, min( 5, $rating ) );
		$stars_html = '';
		$view_box   = '7 7.4 14 13.3';
		$path       = 'M20.4629 12.0664L16.6419 11.5134C16.4619 11.4874 16.3049 11.3744 16.2229 11.2114L14.5089 7.80741C14.3029 7.39841 13.7199 7.39741 13.5119 7.80541L11.7729 11.2134C11.6899 11.3754 11.5339 11.4874 11.3549 11.5134L7.53692 12.0654C7.07392 12.1324 6.89292 12.7044 7.23392 13.0254L9.98392 15.6214C10.1199 15.7504 10.1829 15.9394 10.1499 16.1254L9.49692 19.8424C9.41692 20.2964 9.88992 20.6474 10.3009 20.4374L14.0099 18.5474H14.0129L17.6979 20.4374C18.1079 20.6474 18.5819 20.2994 18.5049 19.8454L17.8709 16.1224C17.8399 15.9384 17.9019 15.7514 18.0369 15.6234L20.7679 13.0244C21.1069 12.7034 20.9249 12.1334 20.4629 12.0664Z';
		$size       = 17;

		for ( $index = 0; $index < $rating; $index++ ) {
			$stars_html .= sprintf(
				'<svg xmlns="http://www.w3.org/2000/svg" class="dsm-loop-filter__rating-star" viewBox="%1$s" width="%2$d" height="%2$d" aria-hidden="true" focusable="false"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="%3$s"></path></svg>',
				esc_attr( $view_box ),
				$size,
				esc_attr( $path )
			);
		}

		return sprintf(
			'<span class="dsm-loop-filter__rating-stars" aria-hidden="true">%s</span>',
			et_core_esc_previously( $stars_html )
		);
	}

	/**
	 * Accessible rating option label (Divi “Rated %d out of 5”).
	 *
	 * @param int $rating Star count 1–5.
	 * @return string
	 */
	private static function rating_option_label( int $rating ): string {
		return sprintf(
			/* translators: %d: rating from 1 to 5. */
			__( 'Rated %d out of 5', 'dsm-supreme-modules-pro-for-divi' ),
			$rating
		);
	}

	/**
	 * Render WooCommerce product rating control (dropdown / radio / checkbox).
	 *
	 * Radio matches Divi Post Filter product-review UX (star rows). Checkbox is
	 * single-select with checkbox appearance. Dropdown uses star characters in labels.
	 *
	 * @param string $label     Optional visible label.
	 * @param string $rating_ui dropdown|radio|checkbox.
	 * @return string
	 */
	private static function render_rating_control( string $label, string $rating_ui = 'radio' ): string {
		if ( ! LoopFilterExtension::is_woocommerce_active() ) {
			return '';
		}
		$label = trim( $label );

		$rating_ui = in_array( $rating_ui, array( 'dropdown', 'radio', 'checkbox' ), true )
			? $rating_ui
			: 'radio';

		$ratings = array( 5, 4, 3, 2, 1 );

		if ( 'dropdown' === $rating_ui ) {
			$options_html = sprintf(
				'<option value="">%s</option>',
				esc_html__( 'Any rating', 'dsm-supreme-modules-pro-for-divi' )
			);
			foreach ( $ratings as $stars ) {
				$star_chars    = str_repeat( '★', $stars );
				$options_html .= sprintf(
					'<option value="%1$d">%2$s</option>',
					$stars,
					esc_html( $star_chars . ' — ' . self::rating_option_label( $stars ) )
				);
			}

			return sprintf(
				'<label class="dsm-loop-filter__rating dsm-loop-filter__rating--dropdown">%1$s<select class="et_pb_contact_select input dsm-loop-filter__select dsm-loop-filter__rating-select" name="dsm_lf_rating" aria-label="%2$s">%3$s</select></label>',
				et_core_esc_previously( self::render_optional_field_label( $label ) ),
				esc_attr__( 'Product rating', 'dsm-supreme-modules-pro-for-divi' ),
				et_core_esc_previously( $options_html )
			);
		}

		$is_radio     = 'radio' === $rating_ui;
		$input_type   = $is_radio ? 'radio' : 'checkbox';
		$input_class  = $is_radio
			? 'dsm-loop-filter__radio dsm-loop-filter__rating-input'
			: 'dsm-loop-filter__checkbox dsm-loop-filter__rating-input';
		$modifier     = $is_radio ? 'radio' : 'checkbox';
		$options_html = '';
		$radio_name   = 'dsm_lf_rating';

		foreach ( $ratings as $stars ) {
			$option_label = self::rating_option_label( $stars );
			$input_id     = 'dsm-lf-rating-' . $stars . '-' . wp_unique_id();
			$name_attr    = $is_radio
				? sprintf( ' name="%s"', esc_attr( $radio_name ) )
				: '';

			$options_html .= sprintf(
				'<label class="dsm-loop-filter__term dsm-loop-filter__rating-option" for="%1$s"><input type="%2$s" class="%3$s" id="%1$s"%4$s value="%5$d" aria-label="%6$s" />%7$s<span class="screen-reader-text">%8$s</span></label>',
				esc_attr( $input_id ),
				esc_attr( $input_type ),
				esc_attr( $input_class ),
				et_core_esc_previously( $name_attr ),
				$stars,
				esc_attr( $option_label ),
				et_core_esc_previously( self::render_rating_stars_html( $stars ) ),
				esc_html( $option_label )
			);
		}

		$fieldset_aria = '' === $label
			? sprintf(
				' aria-label="%s"',
				esc_attr__( 'Product rating', 'dsm-supreme-modules-pro-for-divi' )
			)
			: '';

		return sprintf(
			'<fieldset class="dsm-loop-filter__rating dsm-loop-filter__rating--%1$s"%4$s>%2$s<div class="dsm-loop-filter__terms dsm-loop-filter__rating-options">%3$s</div></fieldset>',
			esc_attr( $modifier ),
			et_core_esc_previously( self::render_optional_field_legend( $label ) ),
			et_core_esc_previously( $options_html ),
			et_core_esc_previously( $fieldset_aria )
		);
	}

	/**
	 * Render WooCommerce stock status select.
	 *
	 * Statuses match WooCommerce ProductStockStatus: instock|outofstock|onbackorder.
	 *
	 * @param string $label Optional visible label.
	 * @return string
	 */
	private static function render_stock_status_control( string $label ): string {
		if ( ! LoopFilterExtension::is_woocommerce_active() ) {
			return '';
		}
		$options = array(
			''            => __( 'Any stock status', 'dsm-supreme-modules-pro-for-divi' ),
			'instock'     => __( 'In stock', 'dsm-supreme-modules-pro-for-divi' ),
			'outofstock'  => __( 'Out of stock', 'dsm-supreme-modules-pro-for-divi' ),
			'onbackorder' => __( 'On backorder', 'dsm-supreme-modules-pro-for-divi' ),
		);

		$options_html = '';
		foreach ( $options as $value => $opt_label ) {
			$options_html .= sprintf(
				'<option value="%1$s">%2$s</option>',
				esc_attr( $value ),
				esc_html( $opt_label )
			);
		}

		return sprintf(
			'<label class="dsm-loop-filter__stock">%1$s<select class="et_pb_contact_select input dsm-loop-filter__select dsm-loop-filter__stock-select" name="dsm_lf_stock" aria-label="%2$s">%3$s</select></label>',
			et_core_esc_previously( self::render_optional_field_label( $label ) ),
			esc_attr__( 'Stock status', 'dsm-supreme-modules-pro-for-divi' ),
			et_core_esc_previously( $options_html )
		);
	}

	/**
	 * Render filter UI from compositional child items.
	 *
	 * @param array<int, array<string, mixed>> $item_blocks     Filter item blocks.
	 * @param array<int, string>               $loop_post_types Nested loop post types.
	 * @param int                              $instance_index  Instance index.
	 * @param string                           $actions_layout  side_by_side|stacked.
	 * @param array<string, mixed>             $parent_attrs    Parent Loop Filter attrs (button chrome).
	 * @return string
	 */
	private static function render_filter_ui_from_items( array $item_blocks, array $loop_post_types, int $instance_index = 0, string $actions_layout = 'side_by_side', array $parent_attrs = array() ): string {
		/**
		 * Filter UI segments collected from child items.
		 *
		 * @var array<int, array{kind: string, type: string, html: string}>
		 */
		$segments   = array();
		$item_index = 0;

		foreach ( $item_blocks as $block ) {
			$item_attrs = isset( $block['attrs'] ) && is_array( $block['attrs'] ) ? $block['attrs'] : array();
			$type       = self::inner_desktop_string( $item_attrs, 'item_type', 'taxonomy' );
			$leaf_html  = '';
			$kind       = 'other';

			if ( 'search' === $type ) {
				$placeholder = self::inner_desktop_string(
					$item_attrs,
					'search_placeholder',
					__( 'Search…', 'dsm-supreme-modules-pro-for-divi' )
				);
				$label       = trim( self::inner_desktop_string( $item_attrs, 'label', '' ) );
				$label_html  = '' !== $label
					? sprintf( '<span class="dsm-loop-filter__label">%s</span>', esc_html( $label ) )
					: '';
				$a11y_label  = '' !== $label
					? $label
					: __( 'Search', 'dsm-supreme-modules-pro-for-divi' );
				$leaf_html   = sprintf(
					'<label class="dsm-loop-filter__search">%1$s<input type="search" class="input dsm-loop-filter__search-input" name="dsm_lf_s" placeholder="%2$s" autocomplete="off"%3$s /></label>',
					et_core_esc_previously( $label_html ),
					esc_attr( $placeholder ),
					'' !== $label ? '' : et_core_esc_previously( sprintf( ' aria-label="%s"', esc_attr( $a11y_label ) ) )
				);
			} elseif ( 'taxonomy' === $type ) {
				$taxonomy     = LoopFilterExtension::resolve_effective_public_taxonomy(
					self::inner_desktop_string( $item_attrs, 'taxonomy', 'category' ),
					$loop_post_types
				);
				$ui           = self::inner_desktop_string( $item_attrs, 'taxonomy_ui', 'checkbox' );
				$label        = self::inner_desktop_string( $item_attrs, 'label', '' );
				$tax_relation = LoopFilterExtension::sanitize_tax_relation(
					self::inner_desktop_string( $item_attrs, 'tax_relation', 'OR' ),
					'OR'
				);
				$terms_layout = self::normalize_terms_layout(
					self::inner_desktop_string( $item_attrs, 'terms_layout', 'stacked' )
				);
				/**
				 * Whether this taxonomy item nests child terms behind a disclosure.
				 *
				 * @param bool                 $collapse   Whether collapse is enabled.
				 * @param string               $taxonomy   Taxonomy slug.
				 * @param array<string, mixed> $item_attrs Filter item attrs.
				 */
				$collapse_subterms = apply_filters(
					'dsm_loop_filter_collapse_subterms',
					'on' === self::inner_desktop_string( $item_attrs, 'collapse_subterms', 'off' ),
					$taxonomy,
					$item_attrs
				);
				/**
				 * Whether nested children start visible when collapse is on.
				 *
				 * @param bool                 $expand     Whether children start expanded.
				 * @param string               $taxonomy   Taxonomy slug.
				 * @param array<string, mixed> $item_attrs Filter item attrs.
				 */
				$expand_subterms = apply_filters(
					'dsm_loop_filter_expand_subterms',
					'on' === self::inner_desktop_string( $item_attrs, 'expand_subterms', 'off' ),
					$taxonomy,
					$item_attrs
				);
				$terms           = self::get_taxonomy_term_options( $taxonomy );
				$show_term_count = 'on' === self::inner_desktop_string( $item_attrs, 'show_term_count', 'off' );
				$leaf_html       = self::render_taxonomy_control(
					$taxonomy,
					$ui,
					$label,
					$terms,
					$instance_index,
					$item_index,
					$terms_layout,
					$tax_relation,
					(bool) $collapse_subterms,
					(bool) $expand_subterms,
					$show_term_count
				);
			} elseif ( 'submit' === $type ) {
				$kind         = 'action';
				$submit_label = self::inner_desktop_string(
					$item_attrs,
					'submit_label',
					__( 'Submit', 'dsm-supreme-modules-pro-for-divi' )
				);
				if ( '' === $submit_label ) {
					$submit_label = __( 'Submit', 'dsm-supreme-modules-pro-for-divi' );
				}
				$leaf_html = self::render_action_button_html(
					'submit',
					'dsm-loop-filter__submit',
					$submit_label,
					isset( $parent_attrs['submit_button'] ) && is_array( $parent_attrs['submit_button'] )
						? $parent_attrs['submit_button']
						: array(),
					isset( $item_attrs['button'] ) && is_array( $item_attrs['button'] )
						? $item_attrs['button']
						: array()
				);
			} elseif ( 'reset' === $type ) {
				$kind        = 'action';
				$reset_label = self::inner_desktop_string(
					$item_attrs,
					'reset_label',
					__( 'Reset', 'dsm-supreme-modules-pro-for-divi' )
				);
				if ( '' === $reset_label ) {
					$reset_label = __( 'Reset', 'dsm-supreme-modules-pro-for-divi' );
				}
				$leaf_html = self::render_action_button_html(
					'button',
					'dsm-loop-filter__reset',
					$reset_label,
					isset( $parent_attrs['reset_button'] ) && is_array( $parent_attrs['reset_button'] )
						? $parent_attrs['reset_button']
						: array(),
					isset( $item_attrs['button'] ) && is_array( $item_attrs['button'] )
						? $item_attrs['button']
						: array()
				);
			} elseif ( 'author' === $type ) {
				$leaf_html = self::render_author_control(
					self::inner_desktop_string( $item_attrs, 'label', '' ),
					self::get_author_options( $loop_post_types )
				);
			} elseif ( 'date' === $type ) {
				$leaf_html = self::render_date_control(
					self::inner_desktop_string( $item_attrs, 'label', '' )
				);
			} elseif ( 'order_by' === $type ) {
				$leaf_html = self::render_orderby_control(
					self::inner_desktop_string( $item_attrs, 'label', '' ),
					self::inner_desktop_string( $item_attrs, 'orderby_default', 'date' ),
					self::inner_desktop_string( $item_attrs, 'order_default', 'DESC' )
				);
			} elseif ( 'custom_field' === $type ) {
				$field_ui     = function_exists( 'dsm_loop_filter_normalize_custom_field_ui' )
					? dsm_loop_filter_normalize_custom_field_ui(
						self::inner_desktop_string( $item_attrs, 'custom_field_ui', 'text' )
					)
					: 'text';
				$terms_layout = self::normalize_terms_layout(
					self::inner_desktop_string( $item_attrs, 'terms_layout', 'stacked' )
				);
				$meta_key  = LoopFilterExtension::resolve_custom_field_key_from_item_attrs( $item_attrs );
				$values    = ( 'text' === $field_ui || '' === $meta_key || ! function_exists( 'dsm_loop_filter_get_meta_value_options' ) )
					? array()
					: dsm_loop_filter_get_meta_value_options( $meta_key, $loop_post_types );
				$leaf_html = self::render_custom_field_control(
					self::inner_desktop_string( $item_attrs, 'label', '' ),
					$meta_key,
					$field_ui,
					$values,
					$instance_index,
					$item_index,
					$terms_layout
				);
			} elseif ( 'price' === $type ) {
				$leaf_html = self::render_price_control_from_attrs(
					$item_attrs,
					$instance_index,
					$item_index,
					$loop_post_types
				);
			} elseif ( 'rating' === $type ) {
				$leaf_html = self::render_rating_control(
					self::inner_desktop_string( $item_attrs, 'label', '' ),
					self::inner_desktop_string( $item_attrs, 'rating_ui', 'radio' )
				);
			} elseif ( 'stock_status' === $type ) {
				$leaf_html = self::render_stock_status_control(
					self::inner_desktop_string( $item_attrs, 'label', '' )
				);
			}

			if ( '' !== $leaf_html ) {
				// Child Design overrides parent when set; unset falls back to parent.
				$segments[] = array(
					'kind' => $kind,
					'type' => $type,
					'html' => LoopFilterItem::wrap_frontend_item(
						$leaf_html,
						$item_attrs,
						$type,
						$instance_index,
						$item_index
					),
				);
			}

			++$item_index;
		}

		$parts = self::fold_action_segments( $segments, $actions_layout );

		if ( empty( $parts ) ) {
			return '';
		}

		return et_core_intentionally_unescaped(
			'<form class="dsm-loop-filter__ui" action="#" method="get" novalidate>' . implode( '', $parts ) . '</form>',
			'html'
		);
	}

	/**
	 * Group consecutive Reset+Submit (or Submit+Reset) into a side-by-side row when requested.
	 *
	 * Single Reset-only or Submit-only items stay unwrapped. Same-type pairs are not grouped.
	 *
	 * @param array<int, array{kind: string, type: string, html: string}> $segments       Typed UI segments.
	 * @param string                                                      $actions_layout stacked|side_by_side.
	 * @return list<string> HTML chunks for the filter form.
	 */
	private static function fold_action_segments( array $segments, string $actions_layout ): array {
		$side_by_side = 'side_by_side' === $actions_layout;
		$parts        = array();
		$count        = count( $segments );
		$i            = 0;

		while ( $i < $count ) {
			$current = $segments[ $i ];
			$next    = ( $i + 1 < $count ) ? $segments[ $i + 1 ] : null;

			if (
				$side_by_side
				&& 'action' === ( $current['kind'] ?? '' )
				&& is_array( $next )
				&& 'action' === ( $next['kind'] ?? '' )
				&& ( $current['type'] ?? '' ) !== ( $next['type'] ?? '' )
			) {
				$parts[] = et_core_intentionally_unescaped(
					'<div class="dsm-loop-filter__actions-group">' . $current['html'] . $next['html'] . '</div>',
					'html'
				);
				$i      += 2;
				continue;
			}

			$parts[] = $current['html'];
			++$i;
		}

		return $parts;
	}

	/**
	 * Legacy parent-only filter bar (soft-migrate when no filter-item children).
	 *
	 * @param array<string, mixed>                                      $attrs           Module attrs.
	 * @param array<int, array{slug: string, name: string, count: int}> $terms           Terms for primary taxonomy.
	 * @param int                                                       $instance_index  Instance index.
	 * @return string
	 */
	private static function render_filter_ui_legacy( array $attrs, array $terms, int $instance_index = 0 ): string {
		$show_taxonomy = self::inner_desktop_string( $attrs, 'show_taxonomy_filter', 'on' );
		$show_search   = self::inner_desktop_string( $attrs, 'show_search', 'on' );
		$show_reset    = self::inner_desktop_string( $attrs, 'show_reset', 'on' );
		$taxonomy      = LoopFilterExtension::sanitize_public_taxonomy(
			self::inner_desktop_string( $attrs, 'taxonomy', 'category' )
		);
		$taxonomy_ui   = self::inner_desktop_string( $attrs, 'taxonomy_ui', 'checkbox' );
		$placeholder   = self::inner_desktop_string(
			$attrs,
			'search_placeholder',
			__( 'Search…', 'dsm-supreme-modules-pro-for-divi' )
		);

		$parts = array();

		if ( 'on' === $show_search ) {
			$parts[] = sprintf(
				'<label class="dsm-loop-filter__search"><span class="screen-reader-text">%1$s</span><input type="search" class="input dsm-loop-filter__search-input" name="dsm_lf_s" placeholder="%2$s" autocomplete="off" /></label>',
				esc_html__( 'Search', 'dsm-supreme-modules-pro-for-divi' ),
				esc_attr( $placeholder )
			);
		}

		if ( 'on' === $show_taxonomy && '' !== $taxonomy ) {
			// Legacy parent attrs have no Label field — keep taxonomy name as the visible label.
			$tax_obj      = get_taxonomy( $taxonomy );
			$legacy_label = $tax_obj instanceof \WP_Taxonomy ? (string) $tax_obj->labels->name : $taxonomy;
			$terms_layout = self::normalize_terms_layout(
				self::inner_desktop_string( $attrs, 'terms_layout', 'stacked' )
			);
			$control      = self::render_taxonomy_control(
				$taxonomy,
				$taxonomy_ui,
				$legacy_label,
				$terms,
				$instance_index,
				0,
				$terms_layout
			);
			if ( '' !== $control ) {
				$parts[] = $control;
			}
		}

		if ( 'on' === $show_reset ) {
			$reset_label = self::inner_desktop_string(
				$attrs,
				'reset_label',
				__( 'Reset', 'dsm-supreme-modules-pro-for-divi' )
			);
			if ( '' === $reset_label ) {
				$reset_label = __( 'Reset', 'dsm-supreme-modules-pro-for-divi' );
			}
			$parts[] = self::render_action_button_html(
				'button',
				'dsm-loop-filter__reset',
				$reset_label,
				isset( $attrs['reset_button'] ) && is_array( $attrs['reset_button'] )
					? $attrs['reset_button']
					: array(),
				array()
			);
		}

		if ( empty( $parts ) ) {
			return '';
		}

		return et_core_intentionally_unescaped(
			'<form class="dsm-loop-filter__ui" action="#" method="get" novalidate>' . implode( '', $parts ) . '</form>',
			'html'
		);
	}

	/**
	 * Render filter UI markup (child items preferred; legacy parent attrs as fallback).
	 *
	 * @param array<string, mixed>             $attrs           Module attrs.
	 * @param array<int, array<string, mixed>> $inner_blocks    Parent inner blocks.
	 * @param array<int, string>               $loop_post_types Nested loop post types.
	 * @param int                              $instance_index  Zero-based instance index within layout.
	 * @return string
	 */
	private static function render_filter_ui( array $attrs, array $inner_blocks, array $loop_post_types = array(), int $instance_index = 0 ): string {
		$enable = self::inner_desktop_string( $attrs, 'enable_filters', 'on' );
		if ( 'on' !== $enable ) {
			return '';
		}

		$item_blocks = self::collect_filter_item_blocks( $inner_blocks );
		if ( ! empty( $item_blocks ) ) {
			$actions_layout = self::inner_desktop_string( $attrs, 'actions_layout', 'side_by_side' );
			if ( 'side_by_side' !== $actions_layout ) {
				$actions_layout = 'stacked';
			}

			return self::render_filter_ui_from_items( $item_blocks, $loop_post_types, $instance_index, $actions_layout, $attrs );
		}

		$taxonomy = LoopFilterExtension::resolve_effective_public_taxonomy(
			self::inner_desktop_string( $attrs, 'taxonomy', 'category' ),
			$loop_post_types
		);
		$terms    = self::get_taxonomy_term_options( $taxonomy );

		return self::render_filter_ui_legacy( $attrs, $terms, $instance_index );
	}

	/**
	 * Render callback.
	 *
	 * @param array<string, mixed> $attrs    Attributes.
	 * @param string               $content  Child HTML.
	 * @param WP_Block             $block    Block.
	 * @param mixed                $elements Elements helper.
	 * @return string
	 */
	public static function render_callback( $attrs, $content, $block, $elements ): string {
		if ( ! is_array( $attrs ) ) {
			$attrs = array();
		}

		$children_ids = ! empty( $block->parsed_block['innerBlocks'] ) && is_array( $block->parsed_block['innerBlocks'] )
			? array_map(
				static function ( $inner_block ) {
					return $inner_block['id'] ?? '';
				},
				$block->parsed_block['innerBlocks']
			)
			: array();

		$parent       = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );
		$parent_attrs = $parent->attrs ?? array();

		// Source post that stores this module (Theme Builder layout / page / library).
		$layout_id = 0;
		if ( class_exists( Style::class ) && method_exists( Style::class, 'get_layout_id' ) ) {
			$layout_id = (int) Style::get_layout_id();
		}
		if ( $layout_id < 1 && class_exists( '\ET_Theme_Builder_Layout' ) && method_exists( '\ET_Theme_Builder_Layout', 'get_theme_builder_layout_id' ) ) {
			$layout_id = (int) \ET_Theme_Builder_Layout::get_theme_builder_layout_id();
		}
		if ( $layout_id < 1 ) {
			$layout_id = (int) get_the_ID();
		}

		$layout_key = (string) $layout_id;
		$block_id   = (string) ( $block->parsed_block['id'] ?? '' );

		if ( '' !== $block_id && isset( self::$index_by_block_id[ $layout_key ][ $block_id ] ) ) {
			// Same block rendered again (e.g. Advanced Tabs re-renders nested modules): keep its index.
			$index = self::$index_by_block_id[ $layout_key ][ $block_id ];
		} else {
			if ( ! isset( self::$instance_index_by_layout[ $layout_key ] ) ) {
				self::$instance_index_by_layout[ $layout_key ] = 0;
			}
			$index = self::$instance_index_by_layout[ $layout_key ];
			++self::$instance_index_by_layout[ $layout_key ];
			if ( '' !== $block_id ) {
				self::$index_by_block_id[ $layout_key ][ $block_id ] = $index;
			}
		}

		// Queried / main post for render context (archive singular, not the TB layout).
		$context_post_id = 0;
		if ( class_exists( '\ET_Post_Stack' ) ) {
			$context_post_id = (int) \ET_Post_Stack::get_main_post_id();
		}
		if ( $context_post_id < 1 ) {
			$context_post_id = (int) get_queried_object_id();
		}
		if ( $context_post_id < 1 ) {
			$context_post_id = $layout_id;
		}

		$inner_blocks    = ! empty( $block->parsed_block['innerBlocks'] ) && is_array( $block->parsed_block['innerBlocks'] )
			? $block->parsed_block['innerBlocks']
			: array();
		$results_blocks  = self::collect_results_inner_blocks( $inner_blocks );
		$loop_ids        = LoopFilterExtension::collect_nested_loop_ids( $results_blocks );
		$loop_post_types = LoopFilterExtension::collect_nested_loop_post_types( $results_blocks );

		// Primary taxonomy for legacy config / URL back-compat (first taxonomy item or parent attr).
		$taxonomy = '';
		foreach ( self::collect_filter_item_blocks( $inner_blocks ) as $item_block ) {
			$item_attrs = isset( $item_block['attrs'] ) && is_array( $item_block['attrs'] ) ? $item_block['attrs'] : array();
			if ( 'taxonomy' !== self::inner_desktop_string( $item_attrs, 'item_type', 'taxonomy' ) ) {
				continue;
			}
			$taxonomy = LoopFilterExtension::resolve_effective_public_taxonomy(
				self::inner_desktop_string( $item_attrs, 'taxonomy', 'category' ),
				$loop_post_types
			);
			if ( '' !== $taxonomy ) {
				break;
			}
		}
		if ( '' === $taxonomy ) {
			$taxonomy = LoopFilterExtension::resolve_effective_public_taxonomy(
				self::inner_desktop_string( $attrs, 'taxonomy', 'category' ),
				$loop_post_types
			);
		}

		$show_result_count = self::inner_desktop_string( $attrs, 'show_result_count', 'on' );
		$url_sync          = self::inner_desktop_string( $attrs, 'url_sync', 'off' );
		$apply_mode        = self::inner_desktop_string( $attrs, 'apply_mode', 'auto' );
		if ( ! in_array( $apply_mode, array( 'auto', 'submit' ), true ) ) {
			$apply_mode = 'auto';
		}
		$tax_query_relation = LoopFilterExtension::sanitize_tax_relation(
			self::inner_desktop_string( $attrs, 'tax_query_relation', 'AND' ),
			'AND'
		);
		$pagination_mode    = self::inner_desktop_string( $attrs, 'pagination_mode', 'off' );
		if ( ! in_array( $pagination_mode, array( 'off', 'load_more', 'numbered' ), true ) ) {
			$pagination_mode = 'off';
		}
		$load_more_text = self::inner_desktop_string(
			$attrs,
			'load_more_text',
			__( 'Load more', 'dsm-supreme-modules-pro-for-divi' )
		);
		if ( '' === $load_more_text ) {
			$load_more_text = __( 'Load more', 'dsm-supreme-modules-pro-for-divi' );
		}
		$empty_title       = self::resolve_empty_state_title( $attrs );
		$empty_description = self::resolve_empty_state_description( $attrs );
		$filter_ui         = self::render_filter_ui( $attrs, $inner_blocks, $loop_post_types, $index );

		wp_enqueue_script( 'dsm-loop-filter' );
		self::enqueue_module_styles();

		/*
		 * Children already rendered into $content — registry should hold nested
		 * loop queries for SSR count / empty (same live found_posts path as REST).
		 *
		 * Do NOT floor found_posts to 1 before pagination: that forces max_pages=1
		 * and hides Load more / numbered chrome until the next AJAX refresh.
		 */
		$content_html  = is_string( $content ) ? $content : '';
		$found_posts   = ! empty( $loop_ids )
			? LoopFilterExtension::sum_found_posts_for_loop_ids( $loop_ids )
			: 0;
		$content_empty = LoopFilterExtension::is_effectively_empty_html( $content_html );
		$returned_html = LoopFilterExtension::count_loop_items_in_html( $content_html );

		$current_page = self::resolve_current_loop_page( $loop_ids );
		$loop_base    = LoopFilterExtension::collect_nested_loop_base_meta( $results_blocks );
		$paging       = LoopFilterExtension::resolve_pagination_state(
			$loop_ids,
			$loop_base,
			$current_page,
			$content_empty ? 0 : $found_posts,
			$returned_html
		);

		if ( $content_empty ) {
			$found_posts         = 0;
			$paging['page']      = 1;
			$paging['max_pages'] = 1;
			$paging['has_more']  = false;
		} elseif ( $found_posts < 1 ) {
			$found_posts = LoopFilterExtension::estimate_found_posts_for_display(
				$returned_html,
				$paging,
				$current_page
			);
		}

		$count_html = '';
		if ( 'on' === $show_result_count ) {
			if ( $found_posts < 1 ) {
				$count_label = __( '0 results', 'dsm-supreme-modules-pro-for-divi' );
			} elseif ( 1 === $found_posts ) {
				$count_label = __( '1 result', 'dsm-supreme-modules-pro-for-divi' );
			} else {
				$count_label = sprintf(
					/* translators: %d: number of results */
					_n( '%d result', '%d results', $found_posts, 'dsm-supreme-modules-pro-for-divi' ),
					$found_posts
				);
			}
			$count_html = sprintf(
				'<div class="dsm-loop-filter__count" data-dsm-lf-count aria-live="polite">%s</div>',
				esc_html( $count_label )
			);
		}

		$empty_html = self::render_empty_state_html(
			$empty_title,
			$empty_description,
			$content_empty
		);

		$pagination_html = self::render_pagination_ui(
			$pagination_mode,
			$load_more_text,
			$paging,
			$content_empty
		);

		$inner = sprintf(
			'%1$s<div class="dsm-loop-filter__main">%2$s<div class="dsm-loop-filter__results" data-dsm-lf-results%3$s>%4$s</div>%5$s%6$s<div class="dsm-loop-filter__loading" data-dsm-lf-loading hidden><span class="dsm-loop-filter__spinner" aria-hidden="true"></span><span class="screen-reader-text">%7$s</span></div></div>',
			et_core_esc_previously( $filter_ui ),
			et_core_esc_previously( $count_html ),
			$content_empty ? ' hidden' : '',
			et_core_esc_previously( is_string( $content ) ? $content : '' ),
			et_core_esc_previously( $empty_html ),
			et_core_esc_previously( $pagination_html ),
			esc_html__( 'Loading filtered results', 'dsm-supreme-modules-pro-for-divi' )
		);

		$layout_classes = self::detect_results_layout_classes( $content_html );

		$config = array(
			'layoutId'           => $layout_id,
			'contextPostId'      => $context_post_id,
			'postId'             => $layout_id, // Back-compat for older FE builds.
			'index'              => $index,
			'loopIds'            => $loop_ids,
			'taxonomy'           => $taxonomy,
			'urlSync'            => 'on' === $url_sync,
			'applyMode'          => $apply_mode,
			'taxQueryRelation'   => $tax_query_relation,
			'restUrl'            => esc_url_raw( rest_url( 'dsm/v1/loop-filter/render' ) ),
			'paginationMode'     => $pagination_mode,
			'page'               => $paging['page'],
			'maxPages'           => $paging['max_pages'],
			'hasMore'            => $paging['has_more'],
			'postsPerPage'       => $paging['posts_per_page'],
			'loadMoreText'       => $load_more_text,
			// SSR order classes — AJAX fragment re-indexes; FE preserves / remaps these.
			'resultsRowClass'    => $layout_classes['row'],
			'resultsColumnClass' => $layout_classes['column'],
			'i18n'               => array(
				'loading'     => __( 'Loading filtered results', 'dsm-supreme-modules-pro-for-divi' ),
				'loadMore'    => $load_more_text,
				'resultZero'  => __( '0 results', 'dsm-supreme-modules-pro-for-divi' ),
				'resultOne'   => __( '1 result', 'dsm-supreme-modules-pro-for-divi' ),
				/* translators: %d: number of results */
				'resultsMany' => __( '%d results', 'dsm-supreme-modules-pro-for-divi' ),
				'pagination'  => __( 'Pagination', 'dsm-supreme-modules-pro-for-divi' ),
				'prev'        => __( 'Previous', 'dsm-supreme-modules-pro-for-divi' ),
				'next'        => __( 'Next', 'dsm-supreme-modules-pro-for-divi' ),
			),
		);

		$layout_class  = self::get_layout_classnames( $attrs );
		$spinner_style = self::normalize_spinner_style(
			self::inner_desktop_string( $attrs, 'spinner_style', 'ring' )
		);

		$wrapper = sprintf(
			'<div class="dsm-loop-filter %1$s" data-dsm-loop-filter="%2$s" data-dsm-lf-spinner="%4$s">%3$s</div>',
			esc_attr( $layout_class ),
			esc_attr( wp_json_encode( $config ) ),
			et_core_esc_previously( $inner ),
			esc_attr( $spinner_style )
		);

		return Module::render(
			array(
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],
				'attrs'               => $attrs,
				'elements'            => $elements,
				'id'                  => $block->parsed_block['id'],
				'name'                => $block->block_type->name,
				'moduleCategory'      => $block->block_type->category,
				'classnamesFunction'  => array( self::class, 'module_classnames' ),
				'stylesComponent'     => array( self::class, 'module_styles' ),
				'scriptDataComponent' => array( self::class, 'module_script_data' ),
				'parentAttrs'         => $parent_attrs,
				'parentId'            => $parent->id ?? '',
				'parentName'          => is_object( $parent ) ? (string) ( $parent->{'blockName'} ?? '' ) : '',
				'childrenIds'         => $children_ids,
				'children'            => et_core_esc_previously(
					ElementComponents::component(
						array(
							'attrs'         => $attrs['module']['decoration'] ?? array(),
							'id'            => $block->parsed_block['id'],
							'orderIndex'    => $block->parsed_block['orderIndex'],
							'storeInstance' => $block->parsed_block['storeInstance'],
						)
					)
				) . et_core_esc_previously( $wrapper ),
			)
		);
	}

	/**
	 * Detect Divi Row/Column order classes from SSR results markup.
	 *
	 * Used by the FE so AJAX fragments (which restart orderIndex) can remap or
	 * preserve the wrappers that carry layout CSS such as `--column-count: 3`.
	 *
	 * @param string $html Nested Loop / Row HTML inside results.
	 * @return array{row: string, column: string}
	 */
	private static function detect_results_layout_classes( string $html ): array {
		$row    = '';
		$column = '';

		if ( '' !== $html ) {
			if ( preg_match( '/\bet_pb_row_(\d+)\b/', $html, $row_match ) ) {
				$row = 'et_pb_row_' . $row_match[1];
			}
			if ( preg_match( '/\bet_pb_column_(\d+)\b/', $html, $col_match ) ) {
				$column = 'et_pb_column_' . $col_match[1];
			}
		}

		/**
		 * Filter detected results layout order classes for Loop Filter AJAX.
		 *
		 * @param array{row: string, column: string} $classes Detected classes.
		 * @param string                             $html    Results HTML.
		 */
		$filtered = apply_filters(
			'dsm_loop_filter_results_layout_classes',
			array(
				'row'    => $row,
				'column' => $column,
			),
			$html
		);

		if ( ! is_array( $filtered ) ) {
			return array(
				'row'    => $row,
				'column' => $column,
			);
		}

		$out_row = isset( $filtered['row'] ) && is_string( $filtered['row'] ) ? $filtered['row'] : $row;
		$out_col = isset( $filtered['column'] ) && is_string( $filtered['column'] ) ? $filtered['column'] : $column;

		return array(
			'row'    => preg_match( '/^et_pb_row_\d+$/', $out_row ) ? $out_row : '',
			'column' => preg_match( '/^et_pb_column_\d+$/', $out_col ) ? $out_col : '',
		);
	}

	/**
	 * Resolve the highest Divi loop page param among nested loopIds.
	 *
	 * @param array<int, string> $loop_ids Loop IDs.
	 * @return int
	 */
	private static function resolve_current_loop_page( array $loop_ids ): int {
		$page = 1;
		foreach ( $loop_ids as $loop_id ) {
			if ( ! is_string( $loop_id ) || '' === $loop_id ) {
				continue;
			}
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Divi Loop pagination URL state.
			if ( isset( $_GET[ $loop_id ] ) ) {
				// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Divi Loop pagination URL state.
				$page = max( $page, max( 1, absint( wp_unslash( $_GET[ $loop_id ] ) ) ) );
			}
		}

		return $page;
	}

	/**
	 * Render Load more / numbered pagination chrome for the frontend.
	 *
	 * @param string               $mode          Pagination mode.
	 * @param string               $load_more_text Load more label.
	 * @param array<string, mixed> $paging        Pagination state.
	 * @param bool                 $content_empty Whether results are empty.
	 * @return string
	 */
	private static function render_pagination_ui( string $mode, string $load_more_text, array $paging, bool $content_empty ): string {
		if ( ! in_array( $mode, array( 'load_more', 'numbered' ), true ) ) {
			return '';
		}

		$page      = max( 1, (int) ( $paging['page'] ?? 1 ) );
		$max_pages = max( 1, (int) ( $paging['max_pages'] ?? 1 ) );
		$has_more  = ! empty( $paging['has_more'] );

		if ( 'load_more' === $mode ) {
			$hidden = ( $content_empty || ! $has_more ) ? ' hidden' : '';
			return sprintf(
				'<div class="dsm-loop-filter__pagination dsm-loop-filter__pagination--load-more" data-dsm-lf-pagination="load_more"%1$s><button type="button" class="dsm-loop-filter__load-more" data-dsm-lf-load-more>%2$s</button></div>',
				$hidden,
				esc_html( $load_more_text )
			);
		}

		if ( $content_empty || $max_pages < 2 ) {
			return sprintf(
				'<nav class="dsm-loop-filter__pagination dsm-loop-filter__pagination--numbered" data-dsm-lf-pagination="numbered" hidden aria-label="%s"></nav>',
				esc_attr__( 'Pagination', 'dsm-supreme-modules-pro-for-divi' )
			);
		}

		$items = self::build_numbered_page_buttons_html( $page, $max_pages );

		return sprintf(
			'<nav class="dsm-loop-filter__pagination dsm-loop-filter__pagination--numbered" data-dsm-lf-pagination="numbered" aria-label="%1$s">%2$s</nav>',
			esc_attr__( 'Pagination', 'dsm-supreme-modules-pro-for-divi' ),
			et_core_esc_previously( $items )
		);
	}

	/**
	 * Build numbered page control HTML.
	 *
	 * @param int $page      Current page.
	 * @param int $max_pages Total pages.
	 * @return string
	 */
	private static function build_numbered_page_buttons_html( int $page, int $max_pages ): string {
		$page      = max( 1, $page );
		$max_pages = max( 1, $max_pages );
		$html      = '';

		$prev_disabled = $page <= 1 ? ' disabled' : '';
		$html         .= sprintf(
			'<button type="button" class="dsm-loop-filter__page dsm-loop-filter__page--prev" data-dsm-lf-page="%1$d"%2$s>%3$s</button>',
			max( 1, $page - 1 ),
			$prev_disabled,
			esc_html__( 'Previous', 'dsm-supreme-modules-pro-for-divi' )
		);

		// Compact window around the current page for large result sets.
		$window = 2;
		$start  = max( 1, $page - $window );
		$end    = min( $max_pages, $page + $window );
		if ( $start > 1 ) {
			$html .= '<button type="button" class="dsm-loop-filter__page" data-dsm-lf-page="1">1</button>';
			if ( $start > 2 ) {
				$html .= '<span class="dsm-loop-filter__page-ellipsis" aria-hidden="true">…</span>';
			}
		}

		for ( $i = $start; $i <= $end; $i++ ) {
			if ( $i === $page ) {
				$html .= sprintf(
					'<button type="button" class="dsm-loop-filter__page is-current" data-dsm-lf-page="%1$d" aria-current="page">%1$d</button>',
					$i
				);
			} else {
				$html .= sprintf(
					'<button type="button" class="dsm-loop-filter__page" data-dsm-lf-page="%1$d">%1$d</button>',
					$i
				);
			}
		}

		if ( $end < $max_pages ) {
			if ( $end < $max_pages - 1 ) {
				$html .= '<span class="dsm-loop-filter__page-ellipsis" aria-hidden="true">…</span>';
			}
			$html .= sprintf(
				'<button type="button" class="dsm-loop-filter__page" data-dsm-lf-page="%1$d">%1$d</button>',
				$max_pages
			);
		}

		$next_disabled = $page >= $max_pages ? ' disabled' : '';
		$html         .= sprintf(
			'<button type="button" class="dsm-loop-filter__page dsm-loop-filter__page--next" data-dsm-lf-page="%1$d"%2$s>%3$s</button>',
			min( $max_pages, $page + 1 ),
			$next_disabled,
			esc_html__( 'Next', 'dsm-supreme-modules-pro-for-divi' )
		);

		return et_core_intentionally_unescaped( $html, 'html' );
	}

	/**
	 * Layout modifier classes for the filter root.
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 * @return string Space-separated class list (no leading/trailing space).
	 */
	private static function get_layout_classnames( array $attrs ): string {
		$layout = self::inner_desktop_string( $attrs, 'filter_layout', 'vertical' );
		if ( 'horizontal' !== $layout ) {
			$layout = 'vertical';
		}

		$classes = array( 'dsm-loop-filter--layout-' . $layout );

		if ( 'vertical' === $layout ) {
			$stack = self::inner_desktop_string( $attrs, 'layout_stack_breakpoint', '767px' );
			if ( '980px' === $stack ) {
				$classes[] = 'dsm-loop-filter--stack-980';
			} elseif ( 'never' === $stack ) {
				$classes[] = 'dsm-loop-filter--stack-never';
			} else {
				$classes[] = 'dsm-loop-filter--stack-767';
			}

			if ( 'on' === self::inner_desktop_string( $attrs, 'sidebar_sticky', 'off' ) ) {
				$classes[] = 'dsm-loop-filter--sidebar-sticky';
			}
		}

		$actions_layout = self::inner_desktop_string( $attrs, 'actions_layout', 'side_by_side' );
		if ( 'side_by_side' === $actions_layout ) {
			$classes[] = 'dsm-loop-filter--actions-side-by-side';
		} else {
			$classes[] = 'dsm-loop-filter--actions-stacked';
		}

		if ( 'stacked' === self::normalize_terms_layout( self::inner_desktop_string( $attrs, 'terms_layout', 'stacked' ) ) ) {
			$classes[] = 'dsm-loop-filter--terms-stacked';
		}

		/**
		 * Filter Supreme Loop Filter layout class names.
		 *
		 * @param string               $joined Space-separated classes.
		 * @param array<string, mixed> $attrs  Module attrs.
		 */
		$filtered = apply_filters( 'dsm_loop_filter_layout_classnames', implode( ' ', $classes ), $attrs );

		return is_string( $filtered ) ? $filtered : implode( ' ', $classes );
	}

	/**
	 * Normalize ButtonOptionsContainer value to a scalar string.
	 *
	 * @param mixed $value Raw CommonStyle attrValue.
	 * @return string
	 */
	private static function scalar_button_option_value( $value ): string {
		if ( is_scalar( $value ) ) {
			return trim( (string) $value );
		}

		if ( ! is_array( $value ) || array() === $value ) {
			return '';
		}

		if ( isset( $value['alignment'] ) && is_scalar( $value['alignment'] ) ) {
			return trim( (string) $value['alignment'] );
		}

		if ( isset( $value['value'] ) && is_scalar( $value['value'] ) ) {
			return trim( (string) $value['value'] );
		}

		$on_keys = array();
		foreach ( $value as $key => $flag ) {
			if ( ! is_string( $key ) ) {
				continue;
			}
			if ( true === $flag || 'on' === $flag || 1 === $flag || '1' === $flag ) {
				$on_keys[] = $key;
			}
		}

		if ( 1 === count( $on_keys ) ) {
			return $on_keys[0];
		}

		if ( array_key_exists( 0, $value ) && is_scalar( $value[0] ) ) {
			return trim( (string) $value[0] );
		}

		return '';
	}

	/**
	 * Sidebar Left/Right → `--dsm-lf-sidebar-direction`.
	 *
	 * @param string               $selector CSS selector.
	 * @param array<string, mixed> $attr     innerContent attr map.
	 * @return array<string, mixed>
	 */
	private static function sidebar_position_style( string $selector, array $attr ): array {
		return CommonStyle::style(
			array(
				'selector'            => $selector,
				'attr'                => $attr,
				'declarationFunction' => static function ( array $params ): string {
					$trimmed = self::scalar_button_option_value( $params['attrValue'] ?? '' );
					if ( ! in_array( $trimmed, array( 'left', 'right' ), true ) ) {
						return '';
					}
					$declarations = new StyleDeclarations(
						array(
							'returnType' => 'string',
						)
					);
					$declarations->add(
						'--dsm-lf-sidebar-direction',
						'right' === $trimmed ? 'row-reverse' : 'row'
					);

					return $declarations->value();
				},
			)
		);
	}

	/**
	 * Sidebar content Top/Center/Bottom → place the hugging sidebar card.
	 *
	 * The wrapper keeps content height (Background hugs the filters). Center
	 * and Bottom move that card on the results column via `align-self`.
	 *
	 * @param string               $selector CSS selector.
	 * @param array<string, mixed> $attr     innerContent attr map.
	 * @return array<string, mixed>
	 */
	private static function sidebar_content_align_style( string $selector, array $attr ): array {
		return CommonStyle::style(
			array(
				'selector'            => $selector,
				'attr'                => $attr,
				'declarationFunction' => static function ( array $params ): string {
					$trimmed = self::scalar_button_option_value( $params['attrValue'] ?? '' );
					if ( ! in_array( $trimmed, array( 'flex-start', 'center', 'flex-end' ), true ) ) {
						return '';
					}
					$declarations = new StyleDeclarations(
						array(
							'returnType' => 'string',
						)
					);
					$declarations->add( '--dsm-lf-sidebar-self', $trimmed );

					return $declarations->value();
				},
			)
		);
	}

	/**
	 * Build a CommonStyle that sets a CSS custom property.
	 *
	 * @param string                $selector CSS selector.
	 * @param array<string, mixed>  $attr     innerContent attr map.
	 * @param string                $css_var  Custom property name including `--`.
	 * @param array<int, string>|null $allowed Optional whitelist of attr values.
	 * @return array<string, mixed>
	 */
	/**
	 * Whether a Background group has a usable desktop value.
	 *
	 * @param mixed $background Background decoration tree.
	 * @return bool
	 */
	private static function has_background_decoration( $background ): bool {
		if ( ! is_array( $background ) || array() === $background ) {
			return false;
		}

		$value = $background['desktop']['value'] ?? null;
		if ( ! is_array( $value ) || array() === $value ) {
			return false;
		}

		foreach ( array( 'color', 'gradient', 'image', 'video', 'pattern', 'mask' ) as $key ) {
			if ( ! isset( $value[ $key ] ) ) {
				continue;
			}
			$part = $value[ $key ];
			if ( is_string( $part ) && '' !== trim( $part ) ) {
				return true;
			}
			if ( is_array( $part ) && array() !== $part ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Style props for price value labels, currency, and similar chrome.
	 *
	 * @param string      $selector          Leaf selector.
	 * @param string|null $spacing_selector  Optional spacing-only selector.
	 * @return array<string, mixed>
	 */
	private static function price_chrome_style_props( string $selector, ?string $spacing_selector = null ): array {
		$space = $spacing_selector ?? $selector;

		return array(
			'font'       => array(
				'important' => true,
				'selectors' => array(
					'desktop' => array(
						'value' => $selector,
						'hover' => $selector . ':hover',
					),
				),
			),
			'background' => array(
				'important' => true,
				'selector'  => $selector,
			),
			'spacing'    => array(
				'important' => true,
				'selector'  => $space,
			),
			'border'     => array(
				'important' => true,
				'selector'  => $selector,
			),
			'boxShadow'  => array(
				'important' => true,
				'selector'  => $selector,
			),
		);
	}

	/**
	 * Style props so Field decoration (Background / Font / Border / Shadow / Spacing) hits FE leaves.
	 *
	 * Pass resolved selectors — FE `elements->style()` does not expand `{{selector}}`.
	 *
	 * @param string $field_selector Inputs and selects.
	 * @return array<string, mixed>
	 */
	private static function field_style_props( string $field_selector ): array {
		return array(
			'background' => array(
				'important' => true,
				'selector'  => $field_selector,
			),
			'border'     => array(
				'important' => true,
				'selector'  => $field_selector,
			),
			'boxShadow'  => array(
				'important' => true,
				'selector'  => $field_selector,
			),
			'spacing'    => array(
				'important' => true,
				'selector'  => $field_selector,
			),
			'font'       => array(
				'important' => true,
				'selectors' => array(
					'desktop' => array(
						'value' => $field_selector,
						'hover' => $field_selector . ':hover',
					),
				),
			),
		);
	}

	/**
	 * Style props so Reset/Submit beat theme `.et_pb_button` !important.
	 *
	 * @param string $selector Button selector.
	 * @return array<string, mixed>
	 */
	private static function action_button_style_props( string $selector ): array {
		return array(
			'background' => array(
				'important' => true,
				'selector'  => $selector,
				'selectors' => array(
					'desktop' => array(
						'value' => $selector,
						'hover' => $selector . ':hover',
					),
				),
			),
			'font'       => array(
				'important' => true,
				'selectors' => array(
					'desktop' => array(
						'value' => $selector,
						'hover' => $selector . ':hover',
					),
				),
			),
			'border'     => array(
				'important' => true,
				'selector'  => $selector,
			),
			'boxShadow'  => array(
				'important' => true,
				'selector'  => $selector,
			),
			'spacing'    => array(
				'important' => true,
				'selector'  => $selector,
			),
			'button'     => array(
				'selector' => $selector,
			),
		);
	}

	/**
	 * Whether a ButtonGroup icon leaf has a glyph Divi can paint.
	 *
	 * @param mixed $icon `decoration.button.*.value.icon`.
	 * @return bool
	 */
	private static function action_button_icon_is_renderable( $icon ): bool {
		if ( ! is_array( $icon ) ) {
			return false;
		}

		$settings = $icon['settings'] ?? null;
		if ( is_string( $settings ) && '' !== trim( $settings ) ) {
			return true;
		}

		if ( ! is_array( $settings ) || array() === $settings ) {
			return false;
		}

		if (
			class_exists( IconLibraryRegistry::class )
			&& IconLibraryRegistry::is_dsm_library_icon( $settings )
		) {
			return true;
		}

		if ( ! class_exists( Utils::class ) ) {
			return false;
		}

		$processed = Utils::process_font_icon( $settings );

		return is_string( $processed ) && '' !== trim( $processed );
	}

	/**
	 * Child `button` wins when it has a glyph; otherwise parent Reset/Submit.
	 *
	 * @param mixed $child_button  Child button attr.
	 * @param mixed $parent_button Parent reset_button / submit_button attr.
	 * @return array<string, mixed>
	 */
	private static function resolve_action_button_attr_for_icon( $child_button, $parent_button ): array {
		if ( is_array( $child_button ) ) {
			$child_dec = $child_button['decoration']['button'] ?? null;
			if ( is_array( $child_dec ) ) {
				foreach ( $child_dec as $breakpoint_value ) {
					if ( ! is_array( $breakpoint_value ) ) {
						continue;
					}
					if ( self::action_button_icon_is_renderable( $breakpoint_value['value']['icon'] ?? null ) ) {
						return $child_button;
					}
				}
			}
		}

		return is_array( $parent_button ) ? $parent_button : array();
	}

	/**
	 * Space-prefixed `data-icon` / `data-icon-*` for Reset/Submit (Card / ButtonModule).
	 *
	 * @param array<string, mixed> $button_attr Button attribute tree.
	 * @return string HTML attribute fragment (leading space), or empty string.
	 */
	private static function render_action_button_icon_data_attributes_html( array $button_attr ): string {
		if ( ! class_exists( Utils::class ) ) {
			return '';
		}

		$icon_enable_raw   = $button_attr['decoration']['button']['desktop']['value']['icon']['enable'] ?? 'on';
		$is_icon_enabled   = 'off' !== strtolower( (string) $icon_enable_raw );
		$button_decoration = $button_attr['decoration']['button'] ?? array();
		if ( ! $is_icon_enabled || ! is_array( $button_decoration ) ) {
			return '';
		}

		$parts = array();
		foreach ( $button_decoration as $breakpoint => $breakpoint_value ) {
			if ( ! is_array( $breakpoint_value ) ) {
				continue;
			}
			$icon_settings = $breakpoint_value['value']['icon']['settings'] ?? null;
			if ( is_string( $icon_settings ) && '' !== trim( $icon_settings ) ) {
				$icon_settings = array( 'unicode' => $icon_settings );
			}
			if ( ! is_array( $icon_settings ) || array() === $icon_settings ) {
				continue;
			}
			$processed_icon = Utils::process_font_icon( $icon_settings );
			if ( '' === $processed_icon || null === $processed_icon ) {
				continue;
			}
			$bp = is_string( $breakpoint ) ? $breakpoint : (string) $breakpoint;
			if ( 'desktop' === $bp ) {
				$data_attr_name = 'data-icon';
			} else {
				$data_attr_name = 'data-icon-' . strtolower( (string) preg_replace( '/([A-Z])/', '-$1', $bp ) );
			}
			$parts[] = sprintf( '%s="%s"', esc_attr( $data_attr_name ), esc_attr( (string) $processed_icon ) );
		}

		if ( array() === $parts ) {
			return '';
		}

		return ' ' . implode( ' ', $parts );
	}

	/**
	 * Reset/Submit button markup with optional Divi icon data attrs.
	 *
	 * @param string               $html_type     `button` or `submit`.
	 * @param string               $button_class  `dsm-loop-filter__reset` or `__submit`.
	 * @param string               $label         Visible label.
	 * @param array<string, mixed> $parent_button Parent button attr.
	 * @param array<string, mixed> $child_button  Child button attr.
	 * @return string
	 */
	private static function render_action_button_html( string $html_type, string $button_class, string $label, array $parent_button, array $child_button ): string {
		$icon_html  = self::render_action_button_icon_data_attributes_html(
			self::resolve_action_button_attr_for_icon( $child_button, $parent_button )
		);
		$icon_class = '' !== trim( $icon_html ) ? ' et_pb_custom_button_icon' : '';

		return sprintf(
			'<div class="dsm-loop-filter__actions"><button type="%1$s" class="et_pb_button %2$s%3$s"%4$s>%5$s</button></div>',
			esc_attr( $html_type ),
			esc_attr( $button_class ),
			esc_attr( $icon_class ),
			et_core_esc_previously( $icon_html ),
			esc_html( $label )
		);
	}

	/**
	 * Flatten a ColorPicker / range attrValue to a CSS string (includes alpha).
	 *
	 * @param mixed $value Raw CommonStyle attrValue.
	 * @return string
	 */
	private static function scalar_css_color_value( $value ): string {
		if ( is_scalar( $value ) ) {
			return trim( (string) $value );
		}
		if ( ! is_array( $value ) ) {
			return '';
		}
		if ( isset( $value['rgba'] ) && is_scalar( $value['rgba'] ) && '' !== trim( (string) $value['rgba'] ) ) {
			return trim( (string) $value['rgba'] );
		}
		$alpha = self::opacity_to_alpha( $value['opacity'] ?? $value['alpha'] ?? null );
		if ( isset( $value['color'] ) && is_array( $value['color'] ) ) {
			return self::scalar_css_color_value( $value['color'] );
		}
		if ( isset( $value['color'] ) && is_scalar( $value['color'] ) && '' !== trim( (string) $value['color'] ) ) {
			$color = trim( (string) $value['color'] );
			return null !== $alpha ? self::color_with_alpha( $color, $alpha ) : $color;
		}
		if ( isset( $value['hex'] ) && is_scalar( $value['hex'] ) && '' !== trim( (string) $value['hex'] ) ) {
			$hex = trim( (string) $value['hex'] );
			return null !== $alpha ? self::color_with_alpha( $hex, $alpha ) : $hex;
		}
		if ( isset( $value['value'] ) ) {
			return self::scalar_css_color_value( $value['value'] );
		}

		return '';
	}

	/**
	 * ColorPicker opacity (`25%`, 0.25, 25) → 0–1, or null when unset.
	 *
	 * @param mixed $opacity Raw opacity.
	 * @return float|null
	 */
	private static function opacity_to_alpha( $opacity ): ?float {
		if ( null === $opacity || '' === $opacity || false === $opacity ) {
			return null;
		}
		if ( is_string( $opacity ) ) {
			$raw     = trim( $opacity );
			$numeric = (float) $raw;
			if ( '' === $raw ) {
				return null;
			}
			if ( str_ends_with( $raw, '%' ) || $numeric > 1 ) {
				return max( 0.0, min( 1.0, $numeric / 100 ) );
			}
			return max( 0.0, min( 1.0, $numeric ) );
		}
		if ( is_numeric( $opacity ) ) {
			$numeric = (float) $opacity;
			return $numeric > 1 ? max( 0.0, min( 1.0, $numeric / 100 ) ) : max( 0.0, min( 1.0, $numeric ) );
		}

		return null;
	}

	/**
	 * Apply alpha to a hex or rgb color.
	 *
	 * @param string $color CSS color.
	 * @param float  $alpha 0–1.
	 * @return string
	 */
	private static function color_with_alpha( string $color, float $alpha ): string {
		$hex = ltrim( $color, '#' );
		if ( 1 === preg_match( '/^(?:[0-9a-f]{3}|[0-9a-f]{6}|[0-9a-f]{8})$/i', $hex ) ) {
			if ( 3 === strlen( $hex ) ) {
				$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
			}
			$red   = hexdec( substr( $hex, 0, 2 ) );
			$green = hexdec( substr( $hex, 2, 2 ) );
			$blue  = hexdec( substr( $hex, 4, 2 ) );
			return sprintf( 'rgba(%d, %d, %d, %s)', $red, $green, $blue, rtrim( rtrim( sprintf( '%.3f', $alpha ), '0' ), '.' ) );
		}
		if ( 1 === preg_match( '/^rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/i', $color, $match ) ) {
			return sprintf(
				'rgba(%d, %d, %d, %s)',
				(int) $match[1],
				(int) $match[2],
				(int) $match[3],
				rtrim( rtrim( sprintf( '%.3f', $alpha ), '0' ), '.' )
			);
		}

		return $color;
	}

	/**
	 * Emit a CSS custom property when the attr has a value.
	 *
	 * @param string                  $selector CSS selector.
	 * @param array<string, mixed>    $attr     innerContent attr map.
	 * @param string                  $css_var  Custom property including `--`.
	 * @param array<int, string>|null $allowed  Optional allow-list.
	 * @return array<string, mixed>
	 */
	private static function css_var_style( string $selector, array $attr, string $css_var, ?array $allowed = null ): array {
		return CommonStyle::style(
			array(
				'selector'            => $selector,
				'attr'                => $attr,
				'declarationFunction' => static function ( array $params ) use ( $css_var, $allowed ): string {
					$value = self::scalar_css_color_value( $params['attrValue'] ?? '' );
					if ( null !== $allowed ) {
						$trimmed = self::scalar_button_option_value( $value );
					} elseif ( ! is_scalar( $value ) || '' === trim( (string) $value ) ) {
						return '';
					} else {
						$trimmed = trim( (string) $value );
					}
					if ( '' === $trimmed ) {
						return '';
					}
					if ( null !== $allowed && ! in_array( $trimmed, $allowed, true ) ) {
						return '';
					}
					$declarations = new StyleDeclarations(
						array(
							'returnType' => 'string',
						)
					);
					$declarations->add( $css_var, $trimmed );

					return $declarations->value();
				},
			)
		);
	}

	/**
	 * Enqueue frontend module CSS (split stylesheet or core modules bundle).
	 *
	 * @return void
	 */
	private static function enqueue_module_styles(): void {
		if ( ! class_exists( DsmFrontendModuleAssetRegistry::class ) ) {
			return;
		}

		if ( DsmFrontendModuleAssetRegistry::maybe_enqueue_split_frontend_stylesheet_for_block( 'dsm/loop-filter' ) ) {
			return;
		}

		if ( wp_style_is( DsmFrontendModuleAssetRegistry::CORE_MODULES_STYLE_HANDLE, 'enqueued' ) ) {
			return;
		}

		if ( wp_style_is( DsmFrontendModuleAssetRegistry::CORE_MODULES_STYLE_HANDLE, 'registered' ) ) {
			wp_enqueue_style( DsmFrontendModuleAssetRegistry::CORE_MODULES_STYLE_HANDLE );
			return;
		}

		DsmFrontendModuleAssetRegistry::refresh_scoped_frontend_style_handles();

		if ( wp_style_is( DsmFrontendModuleAssetRegistry::CORE_MODULES_STYLE_HANDLE, 'registered' ) ) {
			wp_enqueue_style( DsmFrontendModuleAssetRegistry::CORE_MODULES_STYLE_HANDLE );
		}
	}

	/**
	 * Module classnames.
	 *
	 * @param array<string, mixed> $args Args.
	 * @return void
	 */
	public static function module_classnames( array $args ): void {
		$classnames_instance = $args['classnamesInstance'];
		$attrs               = $args['attrs'];

		$classnames_instance->add( 'dsm_loop_filter' );
		$classnames_instance->add(
			ElementClassnames::classnames(
				array(
					'attrs' => $attrs['module']['decoration'] ?? array(),
				)
			)
		);
	}

	/**
	 * Script data.
	 *
	 * @param array<string, mixed> $args Args.
	 * @return void
	 */
	public static function module_script_data( array $args ): void {
		$elements = $args['elements'];
		$elements->script_data(
			array(
				'attrName' => 'module',
			)
		);
	}

	/**
	 * Module styles.
	 *
	 * @param array<string, mixed> $args Args.
	 * @return void
	 */
	public static function module_styles( array $args ): void {
		$attrs       = $args['attrs'] ?? array();
		$elements    = $args['elements'];
		$settings    = $args['settings'] ?? array();
		$order_class = $args['orderClass'] ?? '';
		$root        = "{$order_class} .dsm-loop-filter";
		$fields      = "{$root} .dsm-loop-filter__search-input, {$root} .dsm-loop-filter__select, {$root} .dsm-loop-filter__price-input, {$root} .dsm-loop-filter__date-input, {$root} .dsm-loop-filter__custom-field-input";
		$boxes       = "{$root} .dsm-loop-filter__checkbox, {$root} .dsm-loop-filter__radio";

		Style::add(
			array(
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => array(
					$elements->style(
						array(
							'attrName'   => 'module',
							'styleProps' => array(
								'disabledOn' => array(
									'disabledModuleVisibility' => $settings['disabledModuleVisibility'] ?? null,
								),
							),
						)
					),
					CssStyle::style(
						array(
							'selector' => $order_class,
							'attr'     => $attrs['css'] ?? array(),
						)
					),
					$elements->style( array( 'attrName' => 'filter_bar' ) ),
					$elements->style( array( 'attrName' => 'filter_sidebar' ) ),
					$elements->style(
						array(
							'attrName'   => 'field',
							'styleProps' => self::field_style_props( $fields ),
						)
					),
					self::has_background_decoration( $attrs['field']['decoration']['background'] ?? null ) && class_exists( BackgroundStyle::class )
						? BackgroundStyle::style(
							array(
								'selector'  => $fields,
								'attr'      => $attrs['field']['decoration']['background'],
								'important' => true,
							)
						)
						: array(),
					$elements->style(
						array(
							'attrName'   => 'field_label',
							'styleProps' => array(
								'spacing' => array(
									'important' => true,
									'selector'  => "{$root} .dsm-loop-filter__label",
								),
							),
						)
					),
					$elements->style( array( 'attrName' => 'checkbox_label' ) ),
					$elements->style(
						array(
							'attrName'   => 'price_value_labels',
							'styleProps' => self::price_chrome_style_props(
								"{$root} .dsm-loop-filter__price-value-labels, {$root} .dsm-loop-filter__price-tooltip",
								"{$root} .dsm-loop-filter__price-value-labels"
							),
						)
					),
					$elements->style(
						array(
							'attrName'   => 'price_currency_prefix_style',
							'styleProps' => self::price_chrome_style_props( "{$root} .dsm-loop-filter__price-currency-prefix" ),
						)
					),
					$elements->style(
						array(
							'attrName'   => 'price_currency_suffix_style',
							'styleProps' => self::price_chrome_style_props( "{$root} .dsm-loop-filter__price-currency-suffix" ),
						)
					),
					$elements->style(
						array(
							'attrName'   => 'price_pill',
							'styleProps' => array(
								'font'      => array(
									'important' => true,
									'selectors' => array(
										'desktop' => array(
											'value' => "{$root} .dsm-loop-filter__price-pill",
											'hover' => "{$root} .dsm-loop-filter__price-pill:hover",
										),
									),
								),
								'spacing'   => array(
									'important' => true,
									'selector'  => "{$root} .dsm-loop-filter__price-pill",
								),
								'border'    => array(
									'important' => true,
									'selector'  => "{$root} .dsm-loop-filter__price-pill",
								),
								'boxShadow' => array(
									'important' => true,
									'selector'  => "{$root} .dsm-loop-filter__price-pill",
								),
							),
						)
					),
					$elements->style(
						array(
							'attrName'   => 'reset_button',
							'styleProps' => self::action_button_style_props( "{$root} .dsm-loop-filter__reset" ),
						)
					),
					self::has_background_decoration( $attrs['reset_button']['decoration']['background'] ?? null ) && class_exists( BackgroundStyle::class )
						? BackgroundStyle::style(
							array(
								'selector'  => "{$root} .dsm-loop-filter__reset",
								'attr'      => $attrs['reset_button']['decoration']['background'],
								'important' => true,
							)
						)
						: array(),
					$elements->style( array( 'attrName' => 'reset_button_style' ) ),
					$elements->style(
						array(
							'attrName'   => 'submit_button',
							'styleProps' => self::action_button_style_props( "{$root} .dsm-loop-filter__submit" ),
						)
					),
					self::has_background_decoration( $attrs['submit_button']['decoration']['background'] ?? null ) && class_exists( BackgroundStyle::class )
						? BackgroundStyle::style(
							array(
								'selector'  => "{$root} .dsm-loop-filter__submit",
								'attr'      => $attrs['submit_button']['decoration']['background'],
								'important' => true,
							)
						)
						: array(),
					$elements->style( array( 'attrName' => 'submit_button_style' ) ),
					$elements->style( array( 'attrName' => 'load_more_button' ) ),
					$elements->style( array( 'attrName' => 'load_more_button_style' ) ),
					$elements->style( array( 'attrName' => 'result_count' ) ),
					$elements->style( array( 'attrName' => 'result_count_spacing' ) ),
					$elements->style( array( 'attrName' => 'empty_state' ) ),
					$elements->style( array( 'attrName' => 'empty_state_description_style' ) ),
					$elements->style( array( 'attrName' => 'empty_state_spacing' ) ),
					$elements->style( array( 'attrName' => 'pagination_item' ) ),
					$elements->style( array( 'attrName' => 'pagination_style' ) ),
					$elements->style( array( 'attrName' => 'pagination_active_style' ) ),
					self::css_var_style( $root, $attrs['sidebar_width']['innerContent'] ?? array(), '--dsm-lf-sidebar-width' ),
					self::css_var_style( $root, $attrs['sidebar_sticky_offset']['innerContent'] ?? array(), '--dsm-lf-sidebar-sticky-offset' ),
					self::sidebar_position_style( $root, $attrs['sidebar_position']['innerContent'] ?? array() ),
					self::sidebar_content_align_style( $root, $attrs['sidebar_content_align']['innerContent'] ?? array() ),
					self::css_var_style(
						$root,
						$attrs['sidebar_items_align']['innerContent'] ?? array(),
						'--dsm-lf-sidebar-items',
						array( 'stretch', 'flex-start', 'center', 'flex-end' )
					),
					self::css_var_style( $root, $attrs['filter_bar_gap']['innerContent'] ?? array(), '--dsm-lf-bar-gap' ),
					self::css_var_style(
						$root,
						$attrs['filter_bar_justify']['innerContent'] ?? array(),
						'--dsm-lf-bar-justify',
						array( 'flex-start', 'center', 'flex-end', 'space-between' )
					),
					self::css_var_style(
						$root,
						$attrs['filter_bar_alignment']['innerContent'] ?? array(),
						'--dsm-lf-bar-align',
						array( 'flex-start', 'center', 'flex-end', 'stretch' )
					),
					self::css_var_style( $root, $attrs['field_border_radius']['innerContent'] ?? array(), '--dsm-lf-field-radius' ),
					self::css_var_style( $root, $attrs['checkbox_size']['innerContent'] ?? array(), '--dsm-lf-checkbox-size' ),
					self::css_var_style( $root, $attrs['terms_gap']['innerContent'] ?? array(), '--dsm-lf-terms-gap' ),
					self::css_var_style( $root, $attrs['nested_indent']['innerContent'] ?? array(), '--dsm-lf-term-indent' ),
					self::css_var_style( $root, $attrs['nested_gap']['innerContent'] ?? array(), '--dsm-lf-term-nested-gap' ),
					self::css_var_style( $root, $attrs['chevron_color']['innerContent'] ?? array(), '--dsm-lf-term-chevron' ),
					self::css_var_style( $root, $attrs['chevron_size']['innerContent'] ?? array(), '--dsm-lf-term-chevron-size' ),
					self::css_var_style( $root, $attrs['slider_track_height']['innerContent'] ?? array(), '--dsm-lf-price-track-h' ),
					self::css_var_style( $root, $attrs['slider_track_color']['innerContent'] ?? array(), '--dsm-lf-price-track' ),
					self::css_var_style( $root, $attrs['slider_fill_color']['innerContent'] ?? array(), '--dsm-lf-price-fill' ),
					self::css_var_style( $root, $attrs['slider_handle_size']['innerContent'] ?? array(), '--dsm-lf-price-handle-size' ),
					self::css_var_style( $root, $attrs['slider_handle_color']['innerContent'] ?? array(), '--dsm-lf-price-handle' ),
					self::css_var_style( $root, $attrs['slider_handle_border_color']['innerContent'] ?? array(), '--dsm-lf-price-handle-border' ),
					self::css_var_style( $root, $attrs['slider_tooltip_offset']['innerContent'] ?? array(), '--dsm-lf-price-tooltip-offset' ),
					self::css_var_style( $root, $attrs['histogram_bar_color']['innerContent'] ?? array(), '--dsm-lf-price-hist' ),
					self::css_var_style( $root, $attrs['histogram_bar_dim_color']['innerContent'] ?? array(), '--dsm-lf-price-hist-dim' ),
					self::css_var_style( $root, $attrs['histogram_height']['innerContent'] ?? array(), '--dsm-lf-price-hist-h' ),
					self::css_var_style( $root, $attrs['price_bucket_gap']['innerContent'] ?? array(), '--dsm-lf-price-bucket-gap' ),
					self::css_var_style( "{$root} .dsm-loop-filter__price-pill", $attrs['price_pill_bg_color']['innerContent'] ?? array(), '--dsm-lf-price-pill-bg' ),
					self::css_var_style( "{$root} .dsm-loop-filter__price-pill", $attrs['price_pill_text_color']['innerContent'] ?? array(), '--dsm-lf-price-pill-color' ),
					self::css_var_style( "{$root} .dsm-loop-filter__price-pill", $attrs['price_pill_active_bg_color']['innerContent'] ?? array(), '--dsm-lf-price-pill-active-bg' ),
					self::css_var_style( "{$root} .dsm-loop-filter__price-pill", $attrs['price_pill_active_text_color']['innerContent'] ?? array(), '--dsm-lf-price-pill-active-color' ),
					self::css_var_style( $root, $attrs['pagination_gap']['innerContent'] ?? array(), '--dsm-lf-page-gap' ),
					self::css_var_style( $root, $attrs['spinner_color']['innerContent'] ?? array(), '--dsm-lf-spinner' ),
					self::css_var_style( $root, $attrs['spinner_size']['innerContent'] ?? array(), '--dsm-lf-spinner-size' ),
					self::css_var_style( $root, $attrs['spinner_bg_color']['innerContent'] ?? array(), '--dsm-lf-loading-bg' ),
					self::css_var_style( $root, $attrs['field_focus_border_color']['innerContent'] ?? array(), '--dsm-lf-focus-border' ),
					self::css_var_style( $root, $attrs['checkbox_unchecked_color']['innerContent'] ?? array(), '--dsm-lf-checkbox-unchecked' ),
					self::css_var_style( $root, $attrs['checkbox_checked_color']['innerContent'] ?? array(), '--dsm-lf-checkbox-checked' ),
					self::css_var_style( $boxes, $attrs['checkbox_unchecked_color']['innerContent'] ?? array(), '--dsm-lf-checkbox-unchecked' ),
					self::css_var_style( $boxes, $attrs['checkbox_checked_color']['innerContent'] ?? array(), '--dsm-lf-checkbox-checked' ),
					self::css_var_style( $root, $attrs['field_placeholder_color']['innerContent'] ?? array(), '--dsm-lf-placeholder' ),
					self::css_var_style( $root, $attrs['field_bg_color']['innerContent'] ?? array(), '--dsm-lf-field-bg' ),
					self::css_var_style( $root, $attrs['field_text_color']['innerContent'] ?? array(), '--dsm-lf-field-color' ),
					self::css_var_style( $root, $attrs['field_border_color']['innerContent'] ?? array(), '--dsm-lf-field-border-color' ),
					CommonStyle::style(
						array(
							'selector' => $fields,
							'attr'     => $attrs['field_bg_color']['innerContent'] ?? array(),
							'property' => 'background-color',
						)
					),
					CommonStyle::style(
						array(
							'selector' => $fields,
							'attr'     => $attrs['field_text_color']['innerContent'] ?? array(),
							'property' => 'color',
						)
					),
					CommonStyle::style(
						array(
							'selector' => $fields,
							'attr'     => $attrs['field_border_color']['innerContent'] ?? array(),
							'property' => 'border-color',
						)
					),
					CommonStyle::style(
						array(
							'selector' => $fields,
							'attr'     => $attrs['field_border_radius']['innerContent'] ?? array(),
							'property' => 'border-radius',
						)
					),
					CommonStyle::style(
						array(
							'selector'            => "{$root} .dsm-loop-filter__terms",
							'attr'                => $attrs['terms_wrap']['innerContent'] ?? array(),
							'declarationFunction' => static function ( array $params ): string {
								$raw = $params['attrValue'] ?? 'on';
								$on  = in_array( $raw, array( 'on', 'yes', true, 1, '1' ), true );
								$declarations = new StyleDeclarations(
									array(
										'returnType' => 'string',
									)
								);
								$declarations->add( 'flex-wrap', $on ? 'wrap' : 'nowrap' );

								return $declarations->value();
							},
						)
					),
					CommonStyle::style(
						array(
							'selector'            => "{$root} .dsm-loop-filter__terms",
							'attr'                => $attrs['terms_layout']['innerContent'] ?? array(),
							'declarationFunction' => static function ( array $params ): string {
								$raw = $params['attrValue'] ?? 'stacked';
								if ( 'stacked' !== $raw ) {
									return '';
								}
								$declarations = new StyleDeclarations(
									array(
										'returnType' => 'string',
									)
								);
								$declarations->add( 'flex-direction', 'column' );
								$declarations->add( 'flex-wrap', 'nowrap' );
								$declarations->add( 'align-items', 'stretch' );

								return $declarations->value();
							},
						)
					),
					self::has_background_decoration( $attrs['reset_button']['decoration']['background'] ?? null )
						? array()
						: CommonStyle::style(
							array(
								'selector' => "{$root} .dsm-loop-filter__reset",
								'attr'     => $attrs['reset_bg_color']['innerContent'] ?? array(),
								'property' => 'background-color',
							)
						),
					CommonStyle::style(
						array(
							'selector' => "{$root} .dsm-loop-filter__reset",
							'attr'     => $attrs['reset_text_color']['innerContent'] ?? array(),
							'property' => 'color',
						)
					),
					CommonStyle::style(
						array(
							'selector' => "{$root} .dsm-loop-filter__reset",
							'attr'     => $attrs['reset_border_color']['innerContent'] ?? array(),
							'property' => 'border-color',
						)
					),
					self::has_background_decoration( $attrs['submit_button']['decoration']['background'] ?? null )
						? array()
						: CommonStyle::style(
							array(
								'selector' => "{$root} .dsm-loop-filter__submit",
								'attr'     => $attrs['submit_bg_color']['innerContent'] ?? array(),
								'property' => 'background-color',
							)
						),
					CommonStyle::style(
						array(
							'selector' => "{$root} .dsm-loop-filter__submit",
							'attr'     => $attrs['submit_text_color']['innerContent'] ?? array(),
							'property' => 'color',
						)
					),
					CommonStyle::style(
						array(
							'selector' => "{$root} .dsm-loop-filter__submit",
							'attr'     => $attrs['submit_border_color']['innerContent'] ?? array(),
							'property' => 'border-color',
						)
					),
					CommonStyle::style(
						array(
							'selector' => "{$root} .dsm-loop-filter__load-more",
							'attr'     => $attrs['load_more_bg_color']['innerContent'] ?? array(),
							'property' => 'background-color',
						)
					),
					CommonStyle::style(
						array(
							'selector' => "{$root} .dsm-loop-filter__load-more",
							'attr'     => $attrs['load_more_text_color']['innerContent'] ?? array(),
							'property' => 'color',
						)
					),
					CommonStyle::style(
						array(
							'selector' => "{$root} .dsm-loop-filter__load-more",
							'attr'     => $attrs['load_more_border_color']['innerContent'] ?? array(),
							'property' => 'border-color',
						)
					),
					self::css_var_style( $root, $attrs['pagination_bg_color']['innerContent'] ?? array(), '--dsm-lf-page-bg' ),
					self::css_var_style( $root, $attrs['pagination_text_color']['innerContent'] ?? array(), '--dsm-lf-page-color' ),
					self::css_var_style( $root, $attrs['pagination_border_color']['innerContent'] ?? array(), '--dsm-lf-page-border' ),
					self::css_var_style( $root, $attrs['pagination_active_bg_color']['innerContent'] ?? array(), '--dsm-lf-page-active-bg' ),
					self::css_var_style( $root, $attrs['pagination_active_text_color']['innerContent'] ?? array(), '--dsm-lf-page-active-color' ),
					self::css_var_style( $root, $attrs['pagination_active_border_color']['innerContent'] ?? array(), '--dsm-lf-page-active-border' ),
				),
			)
		);
	}
}
