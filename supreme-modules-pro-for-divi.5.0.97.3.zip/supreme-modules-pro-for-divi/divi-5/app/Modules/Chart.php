<?php
/**
 * Supreme Chart module (Divi 5).
 *
 * Primary multi-dataset UX: each Dataset child owns Data Points
 * (label + value rows). Soft-compat keeps legacy Categories + comma values
 * and single-point children.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Modules;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use DiviSupreme\Includes\DsmChartCsvParser;
use DiviSupreme\Includes\DsmRemoteUrlGuard;
use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\Module\Options\Element\ElementClassnames;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\Packages\GlobalData\GlobalData;
use ET\Builder\Packages\Module\Layout\Components\DynamicData\DynamicData;
use ET\Builder\Packages\Module\Options\Loop\LoopContext;
use ET\Builder\Packages\Module\Options\Loop\LoopUtils;
use ET\Builder\Packages\Module\Layout\Components\MultiView\MultiViewScriptData;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\Module\Options\Text\TextStyle;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use WP_Error;
use WP_REST_Request;
use WP_REST_Server;

/**
 * Handles the Supreme Chart parent module.
 */
class Chart implements DependencyInterface {

	/**
	 * Maximum chart points per module (legacy point mode).
	 *
	 * @var int
	 */
	private const MAX_POINTS = 100;

	/**
	 * Maximum category labels in multi-dataset mode.
	 *
	 * @var int
	 */
	private const MAX_CATEGORIES = 50;

	/**
	 * Maximum datasets in multi-dataset mode.
	 *
	 * @var int
	 */
	private const MAX_DATASETS = 20;

	/**
	 * Transient TTL for remote CSV cache (seconds).
	 *
	 * Matches the shortest Live refresh interval (5 minutes).
	 *
	 * @var int
	 */
	private const CSV_CACHE_TTL = 300;

	/**
	 * Transient TTL for last-good live payload (seconds) — 7 days.
	 *
	 * @var int
	 */
	private const CSV_LAST_GOOD_TTL = 604800;

	/**
	 * Max remote CSV preview requests per user per minute (VB).
	 *
	 * @var int
	 */
	private const CSV_RATE_LIMIT = 20;

	/**
	 * Max public live CSV requests per IP per minute.
	 *
	 * @var int
	 */
	private const CSV_LIVE_RATE_LIMIT = 12;

	/**
	 * Allowed Live refresh intervals (minutes).
	 *
	 * @var array<int, int>
	 */
	private const LIVE_INTERVALS = array( 5, 15, 30, 60 );

	/**
	 * Default chart colors.
	 *
	 * @var array<int, string>
	 */
	private const DEFAULT_COLORS = array(
		'#5C1DB0',
		'#7B2CBF',
		'#9D4EDD',
		'#3A86FF',
		'#FF006E',
		'#FB5607',
		'#06D6A0',
		'#FFD166',
	);

	/**
	 * Allowed Chart.js pointStyle values (select stores `"false"` for none).
	 *
	 * @var array<int, string>
	 */
	private const POINT_STYLES = array(
		'circle',
		'cross',
		'crossRot',
		'dash',
		'line',
		'rect',
		'rectRounded',
		'rectRot',
		'star',
		'triangle',
		'false',
	);

	/**
	 * Initialize module registration and Visual Builder assets.
	 *
	 * @return void
	 */
	public function load(): void {
		add_action( 'init', array( self::class, 'register_module' ) );
		add_action( 'rest_api_init', array( self::class, 'register_rest_routes' ) );
		add_action(
			'divi_visual_builder_assets_before_enqueue_scripts',
			array( self::class, 'enqueue_vb_assets' )
		);
	}

	/**
	 * REST: VB preview + public Live refresh for remote Chart CSV.
	 *
	 * Server-side fetch only — SSRF-hardened via {@see DsmRemoteUrlGuard}.
	 *
	 * @return void
	 */
	public static function register_rest_routes(): void {
		register_rest_route(
			'dsm/v1',
			'/chart-csv-source',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( self::class, 'rest_chart_csv_source' ),
				'permission_callback' => static function () {
					return current_user_can( 'edit_posts' );
				},
				'args'                => array(
					'url'     => array(
						'type'              => 'string',
						'required'          => true,
						'sanitize_callback' => 'esc_url_raw',
					),
					'nocache' => array(
						'type'    => 'boolean',
						'default' => false,
					),
				),
			)
		);

		register_rest_route(
			'dsm/v1',
			'/chart-csv-live',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( self::class, 'rest_chart_csv_live' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'url' => array(
						'type'              => 'string',
						'required'          => true,
						'sanitize_callback' => 'esc_url_raw',
					),
				),
			)
		);
	}

	/**
	 * Fetch remote CSV text for Visual Builder preview (authenticated editors).
	 *
	 * @param WP_REST_Request $request Request.
	 * @return \WP_REST_Response|WP_Error
	 */
	public static function rest_chart_csv_source( WP_REST_Request $request ) {
		$url = (string) $request->get_param( 'url' );

		$rate = self::check_chart_csv_rate_limit();
		if ( is_wp_error( $rate ) ) {
			return $rate;
		}

		$validated = DsmRemoteUrlGuard::validate_url( $url );
		if ( is_wp_error( $validated ) ) {
			return $validated;
		}

		$skip_cache = (bool) $request->get_param( 'nocache' );
		$result     = self::fetch_remote_csv_payload( $validated, $skip_cache );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return rest_ensure_response(
			array(
				'csv'    => $result['csv'],
				'url'    => $result['url'],
				'bytes'  => $result['bytes'],
				'cached' => $result['cached'],
			)
		);
	}

	/**
	 * Public Live refresh: return parsed series for a module-stored remote URL.
	 *
	 * The URL is re-validated with {@see DsmRemoteUrlGuard} on every request.
	 * Clients should only pass the URL rendered into the chart host from PHP.
	 * On remote failure, returns last-good parsed payload when available.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return \WP_REST_Response|WP_Error
	 */
	public static function rest_chart_csv_live( WP_REST_Request $request ) {
		$url = (string) $request->get_param( 'url' );

		$rate = self::check_chart_csv_live_rate_limit();
		if ( is_wp_error( $rate ) ) {
			return $rate;
		}

		$validated = DsmRemoteUrlGuard::validate_url( $url );
		if ( is_wp_error( $validated ) ) {
			return $validated;
		}

		$parsed_key = 'dsm_chart_live_' . md5( $validated );
		$last_key   = 'dsm_chart_live_last_' . md5( $validated );

		/**
		 * Filter Live Chart CSV parse-cache TTL (seconds). Minimum interval is 5 minutes.
		 *
		 * @param int    $ttl Cache TTL.
		 * @param string $url Validated URL.
		 */
		$ttl = (int) apply_filters( 'dsm_chart_csv_live_cache_ttl', self::CSV_CACHE_TTL, $validated );
		if ( $ttl < self::CSV_CACHE_TTL ) {
			$ttl = self::CSV_CACHE_TTL;
		}

		$cached = get_transient( $parsed_key );
		if ( is_array( $cached ) && isset( $cached['labels'], $cached['series'] ) ) {
			return rest_ensure_response(
				array(
					'labels' => $cached['labels'],
					'series' => $cached['series'],
					'url'    => isset( $cached['url'] ) && is_string( $cached['url'] ) ? $cached['url'] : $validated,
					'cached' => true,
					'stale'  => false,
				)
			);
		}

		$csv_result = self::fetch_remote_csv_payload( $validated, false );
		if ( is_wp_error( $csv_result ) ) {
			$last = get_transient( $last_key );
			if ( is_array( $last ) && isset( $last['labels'], $last['series'] ) ) {
				return rest_ensure_response(
					array(
						'labels' => $last['labels'],
						'series' => $last['series'],
						'url'    => isset( $last['url'] ) && is_string( $last['url'] ) ? $last['url'] : $validated,
						'cached' => true,
						'stale'  => true,
					)
				);
			}
			return $csv_result;
		}

		$parsed = DsmChartCsvParser::parse( $csv_result['csv'] );
		if ( is_wp_error( $parsed ) ) {
			$last = get_transient( $last_key );
			if ( is_array( $last ) && isset( $last['labels'], $last['series'] ) ) {
				return rest_ensure_response(
					array(
						'labels' => $last['labels'],
						'series' => $last['series'],
						'url'    => isset( $last['url'] ) && is_string( $last['url'] ) ? $last['url'] : $validated,
						'cached' => true,
						'stale'  => true,
					)
				);
			}
			return $parsed;
		}

		$payload = array(
			'labels' => $parsed['labels'],
			'series' => $parsed['series'],
			'url'    => $csv_result['url'],
		);

		set_transient( $parsed_key, $payload, $ttl );

		/**
		 * Filter last-good Live Chart payload TTL (seconds).
		 *
		 * @param int    $ttl Cache TTL.
		 * @param string $url Validated URL.
		 */
		$last_ttl = (int) apply_filters( 'dsm_chart_csv_live_last_good_ttl', self::CSV_LAST_GOOD_TTL, $validated );
		if ( $last_ttl > 0 ) {
			set_transient( $last_key, $payload, $last_ttl );
		}

		return rest_ensure_response(
			array(
				'labels' => $payload['labels'],
				'series' => $payload['series'],
				'url'    => $payload['url'],
				'cached' => $csv_result['cached'],
				'stale'  => false,
			)
		);
	}

	/**
	 * Fetch (and optionally cache) remote CSV text via the URL guard.
	 *
	 * @param string $validated Validated HTTPS URL.
	 * @param bool   $skip_cache Whether to bypass read cache (editors Refresh now).
	 * @return array{csv: string, url: string, bytes: int, cached: bool}|WP_Error
	 */
	private static function fetch_remote_csv_payload( string $validated, bool $skip_cache = false ) {
		$cache_key = 'dsm_chart_csv_' . md5( $validated );
		/**
		 * Filter remote Chart CSV preview cache TTL (seconds).
		 *
		 * @param int    $ttl Cache TTL.
		 * @param string $url Validated URL.
		 */
		$ttl = (int) apply_filters( 'dsm_chart_csv_cache_ttl', self::CSV_CACHE_TTL, $validated );
		if ( $ttl < 0 ) {
			$ttl = 0;
		}

		if ( ! $skip_cache && $ttl > 0 ) {
			$cached = get_transient( $cache_key );
			if ( is_array( $cached ) && isset( $cached['csv'] ) && is_string( $cached['csv'] ) ) {
				return array(
					'csv'    => $cached['csv'],
					'url'    => isset( $cached['url'] ) && is_string( $cached['url'] ) ? $cached['url'] : $validated,
					'bytes'  => isset( $cached['bytes'] ) ? (int) $cached['bytes'] : strlen( $cached['csv'] ),
					'cached' => true,
				);
			}
		}

		$fetched = DsmRemoteUrlGuard::fetch_text(
			$validated,
			array(
				'max_bytes' => (int) apply_filters( 'dsm_chart_csv_max_bytes', 524288, $validated ),
			)
		);
		if ( is_wp_error( $fetched ) ) {
			return $fetched;
		}

		$payload = array(
			'csv'   => $fetched['body'],
			'url'   => $fetched['url'],
			'bytes' => $fetched['bytes'],
		);

		if ( $ttl > 0 ) {
			set_transient( $cache_key, $payload, $ttl );
		}

		return array(
			'csv'    => $payload['csv'],
			'url'    => $payload['url'],
			'bytes'  => $payload['bytes'],
			'cached' => false,
		);
	}

	/**
	 * Simple per-user rate limit for Chart CSV preview REST.
	 *
	 * @return true|WP_Error
	 */
	private static function check_chart_csv_rate_limit() {
		$user_id = get_current_user_id();
		if ( $user_id <= 0 ) {
			return new WP_Error(
				'dsm_chart_csv_forbidden',
				__( 'You must be logged in to preview remote CSV.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 403 )
			);
		}
		$key = 'dsm_chart_csv_rl_' . (string) $user_id;

		/**
		 * Filter max Chart CSV preview requests per user per minute.
		 *
		 * @param int $limit Max requests.
		 */
		$limit = (int) apply_filters( 'dsm_chart_csv_rate_limit', self::CSV_RATE_LIMIT );
		if ( $limit < 1 ) {
			return true;
		}

		$count = get_transient( $key );
		if ( false === $count ) {
			set_transient( $key, 1, MINUTE_IN_SECONDS );
			return true;
		}

		$count = (int) $count;
		if ( $count >= $limit ) {
			return new WP_Error(
				'dsm_chart_csv_rate_limited',
				__( 'Too many CSV preview requests. Please wait a moment and try again.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 429 )
			);
		}

		set_transient( $key, $count + 1, MINUTE_IN_SECONDS );
		return true;
	}

	/**
	 * Per-IP rate limit for public Live Chart CSV REST.
	 *
	 * @return true|WP_Error
	 */
	private static function check_chart_csv_live_rate_limit() {
		$ip = '';
		if ( isset( $_SERVER['REMOTE_ADDR'] ) && is_string( $_SERVER['REMOTE_ADDR'] ) ) {
			$ip = sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) );
		}
		if ( '' === $ip ) {
			$ip = 'unknown';
		}

		$key = 'dsm_chart_live_rl_' . md5( $ip );

		/**
		 * Filter max public Live Chart CSV requests per IP per minute.
		 *
		 * @param int $limit Max requests.
		 */
		$limit = (int) apply_filters( 'dsm_chart_csv_live_rate_limit', self::CSV_LIVE_RATE_LIMIT );
		if ( $limit < 1 ) {
			return true;
		}

		$count = get_transient( $key );
		if ( false === $count ) {
			set_transient( $key, 1, MINUTE_IN_SECONDS );
			return true;
		}

		$count = (int) $count;
		if ( $count >= $limit ) {
			return new WP_Error(
				'dsm_chart_csv_live_rate_limited',
				__( 'Too many chart data requests. Please try again shortly.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 429 )
			);
		}

		set_transient( $key, $count + 1, MINUTE_IN_SECONDS );
		return true;
	}

	/**
	 * Normalize Live refresh interval (minutes).
	 *
	 * @param string $raw Stored value.
	 * @return int
	 */
	private static function normalize_live_interval_minutes( string $raw ): int {
		$minutes = (int) preg_replace( '/[^\d]/', '', $raw );
		if ( ! in_array( $minutes, self::LIVE_INTERVALS, true ) ) {
			return 15;
		}
		return $minutes;
	}

	/**
	 * Legacy bootstrap hook for dependency tree registration.
	 *
	 * @return void
	 */
	public static function dsm_initialise(): void {
		add_action(
			'divi_module_library_modules_dependency_tree',
			function ( $dependency_tree ) {
				$dependency_tree->add_dependency( new self() );
			}
		);
	}

	/**
	 * Register module with Divi module library.
	 *
	 * @return void
	 */
	public static function register_module(): void {
		$module_json_path = DSM_DIR_PATH . 'divi-5/public/packages/module-library/chart';

		ModuleRegistration::register_module(
			$module_json_path,
			array(
				'render_callback' => array( self::class, 'render_callback' ),
			)
		);
	}

	/**
	 * Register and enqueue Chart.js + chart init for Visual Builder.
	 *
	 * @return void
	 */
	public static function enqueue_vb_assets(): void {
		self::register_chart_scripts();
		wp_enqueue_script( 'dsm-chartjs-library' );
		wp_enqueue_script( 'dsm-chart' );
		self::localize_chart_settings();
	}

	/**
	 * Register frontend chart script handles.
	 *
	 * @return void
	 */
	private static function register_chart_scripts(): void {
		$version = defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';

		if ( ! wp_script_is( 'dsm-chartjs-library', 'registered' ) ) {
			wp_register_script(
				'dsm-chartjs-library',
				DSM_DIR_URL . 'assets/js/chart.js',
				array(),
				$version,
				true
			);
		}

		if ( ! wp_script_is( 'dsm-chart', 'registered' ) ) {
			wp_register_script(
				'dsm-chart',
				DSM_DIR_URL . 'assets/js/chart-module.js',
				array( 'dsm-chartjs-library' ),
				$version,
				true
			);
		}
	}

	/**
	 * Localize Chart.js locale (BCP 47) for Visual Builder config builders.
	 *
	 * @return void
	 */
	private static function localize_chart_settings(): void {
		if ( ! wp_script_is( 'dsm-chart', 'registered' ) && ! wp_script_is( 'dsm-chart', 'enqueued' ) ) {
			return;
		}

		$locale = self::resolve_chart_locale();
		wp_localize_script(
			'dsm-chart',
			'dsmChartSettings',
			array(
				'locale'       => $locale,
				// Divi default breakpoint max widths (px); FE swaps canvas colors.
				'tabletMax'    => 980,
				'phoneMax'     => 767,
				// Sample CSV for Content → Import data (VB download link).
				'sampleCsvUrl' => esc_url_raw( DSM_DIR_URL . 'assets/csv/chart-sample.csv' ),
				// Public Live refresh REST base (`chart-csv-live`).
				'restUrl'      => esc_url_raw( rest_url( 'dsm/v1/' ) ),
			)
		);
	}

	/**
	 * Resolve WordPress locale as a BCP 47 tag for Chart.js `options.locale`.
	 *
	 * Empty string when invalid — Chart.js then uses the browser default.
	 *
	 * @return string
	 */
	private static function resolve_chart_locale(): string {
		$locale = '';

		if ( function_exists( 'determine_locale' ) ) {
			$locale = (string) determine_locale();
		}

		if ( '' === $locale && function_exists( 'get_user_locale' ) ) {
			$locale = (string) get_user_locale();
		}

		if ( '' === $locale ) {
			$locale = (string) get_locale();
		}

		$locale = str_replace( '_', '-', trim( $locale ) );

		if ( '' === $locale || 1 !== preg_match( '/^[a-zA-Z]{2,3}(-[a-zA-Z0-9]+)*$/', $locale ) ) {
			return '';
		}

		return $locale;
	}

	/**
	 * Normalize chart type + bar orientation (soft-compat for legacy `horizontal_bar`).
	 *
	 * @param string $chart_type      Stored chart_type value.
	 * @param string $bar_orientation Stored bar_orientation value.
	 * @return array{chart_type: string, bar_orientation: string}
	 */
	private static function normalize_chart_type_and_orientation( string $chart_type, string $bar_orientation = 'vertical' ): array {
		if ( 'horizontal_bar' === $chart_type ) {
			return array(
				'chart_type'      => 'bar',
				'bar_orientation' => 'horizontal',
			);
		}

		$allowed = array( 'bar', 'line', 'area', 'pie', 'doughnut', 'radar', 'polarArea', 'scatter', 'bubble' );
		$type    = in_array( $chart_type, $allowed, true ) ? $chart_type : 'bar';
		$orient  = 'horizontal' === $bar_orientation ? 'horizontal' : 'vertical';

		return array(
			'chart_type'      => $type,
			'bar_orientation' => $orient,
		);
	}

	/**
	 * Resolve UI chart type (+ bar orientation) to Chart.js `type` + optional `indexAxis`.
	 *
	 * Bar + Horizontal → `type: 'bar'` + `indexAxis: 'y'`.
	 * Legacy `horizontal_bar` chart type is treated the same.
	 * Area → `type: 'line'` (fill is forced on in dataset build).
	 *
	 * @param string $chart_type      Stored chart_type value.
	 * @param string $bar_orientation Stored bar_orientation (`vertical`|`horizontal`).
	 * @return array{type: string, index_axis: string|null}
	 */
	private static function resolve_chart_js_type( string $chart_type, string $bar_orientation = 'vertical' ): array {
		$normalized = self::normalize_chart_type_and_orientation( $chart_type, $bar_orientation );

		if ( 'bar' === $normalized['chart_type'] && 'horizontal' === $normalized['bar_orientation'] ) {
			return array(
				'type'       => 'bar',
				'index_axis' => 'y',
			);
		}

		if ( 'area' === $normalized['chart_type'] ) {
			return array(
				'type'       => 'line',
				'index_axis' => null,
			);
		}

		return array(
			'type'       => $normalized['chart_type'],
			'index_axis' => null,
		);
	}

	/**
	 * Whether the stored UI chart type is Area.
	 *
	 * @param string $chart_type Stored chart_type value.
	 * @return bool
	 */
	private static function is_area_chart_type( string $chart_type ): bool {
		$normalized = self::normalize_chart_type_and_orientation( $chart_type );

		return 'area' === $normalized['chart_type'];
	}

	/**
	 * Chart.js dataset.fill for line / area / radar.
	 *
	 * Area always fills. Radar defaults on. Line uses the Fill Area toggle (default off).
	 *
	 * @param string $chart_type Stored chart_type value.
	 * @param string $fill       Stored fill toggle.
	 * @param bool   $is_radar   Resolved Chart.js type is radar.
	 * @return bool
	 */
	private static function resolve_dataset_fill( string $chart_type, string $fill, bool $is_radar ): bool {
		if ( self::is_area_chart_type( $chart_type ) ) {
			return true;
		}

		return self::is_on( $fill, $is_radar ? 'on' : 'off' );
	}

	/**
	 * Normalize plain innerContent leaf (string or `{ text }`).
	 *
	 * @param mixed $value Stored leaf value.
	 * @return string
	 */
	private static function normalize_inner_plain( $value ): string {
		if ( null === $value || '' === $value ) {
			return '';
		}

		if ( is_string( $value ) || is_numeric( $value ) ) {
			return (string) $value;
		}

		if ( is_array( $value ) && array_key_exists( 'text', $value ) && null !== $value['text'] ) {
			return (string) $value['text'];
		}

		return '';
	}

	/**
	 * Resolve Divi dynamic data tokens for Chart.js config strings.
	 *
	 * Chart.js cannot process `$variable(...)` — resolve before JSON encode.
	 * Prefers Loop context when `$attrs` carries `__loop_post_id` / `__loop_iteration`
	 * (duplicated Chart Item children under Divi Loop).
	 *
	 * @param string               $value Plain string that may contain `$variable(...)`.
	 * @param array<string, mixed> $attrs Optional module attrs (loop markers).
	 * @return string
	 */
	private static function resolve_dynamic_plain( string $value, array $attrs = array() ): string {
		if ( '' === $value || false === strpos( $value, '$variable(' ) ) {
			return $value;
		}

		// Prefer Divi’s Loop helper only while LoopContext is active (during
		// duplication). After parse, attrs are usually already resolved — use
		// __loop_post_id so leftover tokens still target the loop item post.
		if (
			class_exists( LoopUtils::class ) &&
			class_exists( LoopContext::class ) &&
			null !== LoopContext::get() &&
			array() !== $attrs
		) {
			return LoopUtils::process_dynamic_content( $value, $attrs );
		}

		if ( ! class_exists( DynamicData::class ) ) {
			return $value;
		}

		$loop_post_id = isset( $attrs['__loop_post_id'] ) ? absint( $attrs['__loop_post_id'] ) : 0;
		$post_id      = $loop_post_id > 0 ? $loop_post_id : get_the_ID();
		$resolved     = DynamicData::get_processed_dynamic_data(
			$value,
			false !== $post_id && $post_id > 0 ? (int) $post_id : null
		);

		return null !== $resolved ? (string) $resolved : $value;
	}

	/**
	 * Resolve a ColorPicker leaf to a Chart.js-safe paint string.
	 *
	 * Divi Global Colors persist as `$variable({"type":"color",…})$`. Canvas /
	 * Chart.js cannot use those tokens (they render black). Match Divi
	 * CircleCounter: `GlobalData::resolve_global_color_variable()`.
	 *
	 * @param string $value Raw color string (hex, rgba, `$variable(…)$`, `var(--gcid-…)`).
	 * @return string Concrete color, or '' when empty / unusable.
	 */
	private static function resolve_chart_color_paint( string $value ): string {
		$trimmed = trim( $value );
		if ( '' === $trimmed ) {
			return '';
		}

		if ( class_exists( GlobalData::class ) ) {
			$resolved = GlobalData::resolve_global_color_variable(
				$trimmed,
				GlobalData::get_global_colors()
			);
			if ( is_string( $resolved ) && '' !== trim( $resolved ) ) {
				$trimmed = trim( $resolved );
			}

			// Bare `var(--gcid-…)` is left unchanged by resolve_global_color_variable —
			// look up the palette hex so Chart.js canvas can paint it.
			if ( 0 === stripos( $trimmed, 'var(' ) ) {
				$gcid = GlobalData::get_global_color_id_from_value( $trimmed );
				if ( is_string( $gcid ) && '' !== $gcid ) {
					$color_data = GlobalData::get_global_color_by_id( $gcid );
					$palette    = is_array( $color_data ) ? ( $color_data['color'] ?? '' ) : '';
					if ( is_string( $palette ) && '' !== trim( $palette ) ) {
						$nested = GlobalData::resolve_global_color_variable(
							trim( $palette ),
							GlobalData::get_global_colors()
						);
						if ( is_string( $nested ) && '' !== trim( $nested ) && 0 !== stripos( trim( $nested ), 'var(' ) ) {
							$trimmed = trim( $nested );
						} elseif ( 0 !== stripos( trim( $palette ), 'var(' ) && false === strpos( $palette, '$variable(' ) ) {
							$trimmed = trim( $palette );
						}
					}
				}
			}
		}

		// Unresolved dynamic token — treat as empty so palette / parent fallback runs.
		if ( false !== strpos( $trimmed, '$variable(' ) ) {
			return '';
		}

		return $trimmed;
	}

	/**
	 * Resolve a point / series color with parent + palette fallback.
	 *
	 * Precedence: explicit color → parent default → palette.
	 *
	 * @param string $color        Custom / child color.
	 * @param int    $index        Point index.
	 * @param string $parent_color Parent Chart default color.
	 * @return string
	 */
	private static function resolve_point_color( string $color, int $index, string $parent_color = '' ): string {
		$trimmed = self::resolve_chart_color_paint( $color );
		if ( '' !== $trimmed ) {
			return $trimmed;
		}

		$parent = self::resolve_chart_color_paint( $parent_color );
		if ( '' !== $parent ) {
			return $parent;
		}

		$palette = self::DEFAULT_COLORS;
		return $palette[ $index % count( $palette ) ];
	}

	/**
	 * First non-empty trimmed string among candidates.
	 *
	 * @param string ...$candidates Values.
	 * @return string
	 */
	private static function first_non_empty_plain( string ...$candidates ): string {
		foreach ( $candidates as $candidate ) {
			$trimmed = trim( $candidate );
			if ( '' !== $trimmed ) {
				return $trimmed;
			}
		}

		return '';
	}

	/**
	 * Resolve series border color (child → parent → fill / circular fallback).
	 *
	 * @param array<string, mixed> $series             Dataset row.
	 * @param string               $parent_border      Parent default border.
	 * @param string               $fill_color         Resolved fill color.
	 * @param string               $circular_fallback  Pie/doughnut fallback.
	 * @return string
	 */
	private static function resolve_series_border_color( array $series, string $parent_border, string $fill_color, string $circular_fallback = '' ): string {
		$child = self::resolve_chart_color_paint(
			self::normalize_inner_plain( $series['borderColor'] ?? '' )
		);

		foreach ( array( $child, $parent_border, $circular_fallback, $fill_color ) as $candidate ) {
			$resolved = self::resolve_chart_color_paint( (string) $candidate );
			if ( '' !== $resolved ) {
				return $resolved;
			}
		}

		return '';
	}

	/**
	 * Per-slice color string from a data point row.
	 *
	 * @param array<string, mixed>|null $point Data point.
	 * @return string
	 */
	private static function data_point_slice_color( $point ): string {
		if ( ! is_array( $point ) ) {
			return '';
		}

		return self::resolve_chart_color_paint(
			self::normalize_inner_plain(
				$point['point_color'] ?? ( $point['pointColor'] ?? ( $point['color'] ?? '' ) )
			)
		);
	}

	/**
	 * Background colors for pie / doughnut / polarArea slices.
	 *
	 * Precedence per slice:
	 * 1. Data point color (if set)
	 * 2. Dataset Chart Color / parent default (when either is set)
	 * 3. Palette by slice index
	 *
	 * @param array<int, string>               $labels            Slice labels.
	 * @param array<int, array<string, mixed>> $points            Dataset data points.
	 * @param string                           $series_color      Resolved fill color.
	 * @param bool                             $has_explicit_fill Whether child or parent set a color.
	 * @return string|array<int, string>
	 */
	private static function resolve_arc_slice_background_colors( array $labels, array $points, string $series_color, bool $has_explicit_fill ) {
		if ( array() === $labels ) {
			return $has_explicit_fill ? $series_color : self::resolve_point_color( '', 0 );
		}

		$color_by_label = array();
		foreach ( $points as $point ) {
			if ( ! is_array( $point ) ) {
				continue;
			}
			$label = trim( self::normalize_inner_plain( $point['label'] ?? '' ) );
			if ( '' === $label || array_key_exists( $label, $color_by_label ) ) {
				continue;
			}
			$color_by_label[ $label ] = self::data_point_slice_color( $point );
		}

		$slice_colors = array();
		foreach ( $labels as $slice_index => $label ) {
			$point_color = '';
			if ( array_key_exists( $label, $color_by_label ) ) {
				$point_color = (string) $color_by_label[ $label ];
			} else {
				$point_color = self::data_point_slice_color( $points[ $slice_index ] ?? null );
			}

			if ( '' !== $point_color ) {
				$slice_colors[] = $point_color;
				continue;
			}

			if ( $has_explicit_fill ) {
				$slice_colors[] = $series_color;
				continue;
			}

			$slice_colors[] = self::resolve_point_color( '', (int) $slice_index );
		}

		return $slice_colors;
	}

	/**
	 * Resolve bar border radius (child → parent). Empty → null (Chart.js default 0).
	 *
	 * @param array<string, mixed> $series        Dataset row.
	 * @param string               $parent_radius Parent border radius.
	 * @return float|null
	 */
	private static function resolve_series_border_radius( array $series, string $parent_radius ) {
		$child = trim( self::normalize_inner_plain( $series['borderRadius'] ?? '' ) );
		if ( '' !== $child ) {
			return max( 0.0, self::parse_numeric_attr( $child, 0.0 ) );
		}

		$parent = trim( $parent_radius );
		if ( '' !== $parent ) {
			return max( 0.0, self::parse_numeric_attr( $parent, 0.0 ) );
		}

		return null;
	}

	/**
	 * Apply hover style keys when a value is set (child → parent).
	 *
	 * @param array<string, mixed>  $dataset       Chart.js dataset (by ref).
	 * @param array<string, mixed>  $series        Dataset row.
	 * @param array<string, string> $parent_hover Parent hover defaults.
	 */
	private static function apply_dataset_hover_styles( array &$dataset, array $series, array $parent_hover ): void {
		$hover_bg = '';
		foreach (
			array(
				self::normalize_inner_plain( $series['hoverBackgroundColor'] ?? '' ),
				(string) ( $parent_hover['backgroundColor'] ?? '' ),
			) as $candidate
		) {
			$hover_bg = self::resolve_chart_color_paint( $candidate );
			if ( '' !== $hover_bg ) {
				break;
			}
		}

		$hover_border = '';
		foreach (
			array(
				self::normalize_inner_plain( $series['hoverBorderColor'] ?? '' ),
				(string) ( $parent_hover['borderColor'] ?? '' ),
			) as $candidate
		) {
			$hover_border = self::resolve_chart_color_paint( $candidate );
			if ( '' !== $hover_border ) {
				break;
			}
		}
		$hover_width_raw = self::first_non_empty_plain(
			self::normalize_inner_plain( $series['hoverBorderWidth'] ?? '' ),
			(string) ( $parent_hover['borderWidth'] ?? '' )
		);

		if ( '' !== $hover_bg ) {
			$dataset['hoverBackgroundColor'] = $hover_bg;
		}
		if ( '' !== $hover_border ) {
			$dataset['hoverBorderColor'] = $hover_border;
		}
		if ( '' !== $hover_width_raw ) {
			$dataset['hoverBorderWidth'] = max( 0.0, self::parse_numeric_attr( $hover_width_raw, 1.0 ) );
		}
	}

	/**
	 * Extract category labels from SortableList rows (`{ value, dragID }[]`).
	 *
	 * @param mixed $raw SortableList value.
	 * @return array<int, string>
	 */
	private static function extract_category_labels( $raw ): array {
		if ( null === $raw || '' === $raw ) {
			return array();
		}

		$rows = $raw;
		if ( ! is_array( $rows ) ) {
			return array();
		}

		// Associative map → list of rows.
		if ( array() !== $rows && array_keys( $rows ) !== range( 0, count( $rows ) - 1 ) ) {
			$rows = array_values( $rows );
		}

		$labels = array();
		foreach ( $rows as $row ) {
			if ( is_string( $row ) || is_numeric( $row ) ) {
				$label = trim( (string) $row );
			} elseif ( is_array( $row ) ) {
				$label = trim( self::normalize_inner_plain( $row['value'] ?? '' ) );
			} else {
				$label = '';
			}

			if ( '' !== $label ) {
				$labels[] = self::resolve_dynamic_plain( $label );
			}
		}

		return array_slice( $labels, 0, self::MAX_CATEGORIES );
	}

	/**
	 * Extract Data Points from Chart Item rows
	 * (`{ label, point_value, point_radius?, point_color?, dragID }[]`).
	 *
	 * @param mixed                $raw   Stored `data_points.innerContent` leaf.
	 * @param array<string, mixed> $attrs Optional child attrs for Loop / DC context.
	 * @return array<int, array{label: string, point_value: string, point_radius: string, point_color: string}>
	 */
	private static function extract_data_points( $raw, array $attrs = array() ): array {
		if ( null === $raw || '' === $raw ) {
			return array();
		}

		$rows = $raw;
		if ( ! is_array( $rows ) ) {
			return array();
		}

		if ( array() !== $rows && array_keys( $rows ) !== range( 0, count( $rows ) - 1 ) ) {
			$rows = array_values( $rows );
		}

		$points = array();
		foreach ( $rows as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}

			$label        = trim(
				self::normalize_inner_plain( $row['label'] ?? ( $row['value'] ?? '' ) )
			);
			$point_value  = trim(
				self::normalize_inner_plain(
					$row['point_value'] ?? ( $row['pointValue'] ?? ( $row['amount'] ?? '' ) )
				)
			);
			$point_radius = trim(
				self::normalize_inner_plain(
					$row['point_radius'] ?? ( $row['pointRadius'] ?? '' )
				)
			);
			$point_color  = trim(
				self::normalize_inner_plain(
					$row['point_color'] ?? ( $row['pointColor'] ?? ( $row['color'] ?? '' ) )
				)
			);

			if ( '' === $label && '' === $point_value && '' === $point_radius && '' === $point_color ) {
				continue;
			}

			$points[] = array(
				'label'        => self::resolve_dynamic_plain( $label, $attrs ),
				'point_value'  => self::resolve_dynamic_plain( $point_value, $attrs ),
				'point_radius' => self::resolve_dynamic_plain( $point_radius, $attrs ),
				'point_color'  => $point_color,
			);
		}

		return array_slice( $points, 0, self::MAX_CATEGORIES );
	}

	/**
	 * Map Data Points to Chart.js scatter `{ x, y }[]`.
	 *
	 * Label → X (numeric), Value → Y.
	 *
	 * @param array<int, array<string, mixed>> $points Data points.
	 * @return array<int, array{x: float, y: float}>
	 */
	private static function map_data_points_to_scatter( array $points ): array {
		$mapped = array();

		foreach ( $points as $point ) {
			if ( ! is_array( $point ) ) {
				continue;
			}
			$x = self::parse_point_number( (string) ( $point['label'] ?? '' ) );
			$y = self::parse_point_number( (string) ( $point['point_value'] ?? '' ) );
			if ( null === $x || null === $y ) {
				continue;
			}
			$mapped[] = array(
				'x' => $x,
				'y' => $y,
			);
		}

		return $mapped;
	}

	/**
	 * Map Data Points to Chart.js bubble `{ x, y, r }[]`.
	 *
	 * Label → X, Value → Y, optional `point_radius` → r.
	 *
	 * @param array<int, array<string, mixed>> $points         Data points.
	 * @param float                            $default_radius Fallback radius in pixels.
	 * @return array<int, array{x: float, y: float, r: float}>
	 */
	private static function map_data_points_to_bubble( array $points, float $default_radius = 10.0 ): array {
		$fallback = max( 0.0, $default_radius );
		$mapped   = array();

		foreach ( $points as $point ) {
			if ( ! is_array( $point ) ) {
				continue;
			}
			$x = self::parse_point_number( (string) ( $point['label'] ?? '' ) );
			$y = self::parse_point_number( (string) ( $point['point_value'] ?? '' ) );
			if ( null === $x || null === $y ) {
				continue;
			}
			$radius_raw = self::parse_point_number( (string) ( $point['point_radius'] ?? '' ) );
			$r          = null !== $radius_raw ? max( 0.0, $radius_raw ) : $fallback;
			$mapped[]   = array(
				'x' => $x,
				'y' => $y,
				'r' => $r,
			);
		}

		return $mapped;
	}

	/**
	 * Parse a point value string to float or null.
	 *
	 * @param string $value_raw Raw value.
	 * @return float|null
	 */
	private static function parse_point_number( string $value_raw ): ?float {
		$plain = trim( self::normalize_inner_plain( $value_raw ) );
		if ( '' === $plain ) {
			return null;
		}

		$numeric = (float) preg_replace( '/[^\d.-]/', '', $plain );
		return is_finite( $numeric ) ? $numeric : null;
	}

	/**
	 * Build shared labels from the first dataset’s data points.
	 *
	 * @param array<int, array<string, mixed>> $datasets Dataset rows.
	 * @return array<int, string>
	 */
	private static function build_labels_from_first_dataset_points( array $datasets ): array {
		if ( array() === $datasets ) {
			return array();
		}

		$first  = $datasets[0];
		$points = is_array( $first['dataPoints'] ?? null ) ? $first['dataPoints'] : array();
		$labels = array();

		foreach ( $points as $point ) {
			if ( ! is_array( $point ) ) {
				continue;
			}
			$label = trim( self::normalize_inner_plain( $point['label'] ?? '' ) );
			if ( '' !== $label ) {
				$labels[] = $label;
			}
		}

		return array_slice( $labels, 0, self::MAX_CATEGORIES );
	}

	/**
	 * Align a dataset’s data points to shared labels (match by label, else index).
	 *
	 * @param array<int, string>                                      $labels Shared labels.
	 * @param array<int, array{label?: string, point_value?: string}> $points Dataset points.
	 * @return array<int, float|null>
	 */
	private static function align_data_points_to_labels( array $labels, array $points ): array {
		$by_label = array();

		foreach ( $points as $point ) {
			if ( ! is_array( $point ) ) {
				continue;
			}
			$label = trim( self::normalize_inner_plain( $point['label'] ?? '' ) );
			if ( '' === $label || array_key_exists( $label, $by_label ) ) {
				continue;
			}
			$by_label[ $label ] = self::parse_point_number(
				(string) ( $point['point_value'] ?? '' )
			);
		}

		$aligned = array();
		foreach ( $labels as $index => $label ) {
			if ( array_key_exists( $label, $by_label ) ) {
				$aligned[] = $by_label[ $label ];
				continue;
			}

			$by_index = $points[ $index ] ?? null;
			if ( is_array( $by_index ) ) {
				$aligned[] = self::parse_point_number(
					(string) ( $by_index['point_value'] ?? '' )
				);
				continue;
			}

			$aligned[] = null;
		}

		return $aligned;
	}

	/**
	 * Parse comma-separated dataset values into numbers / nulls.
	 *
	 * @param string $values_raw Comma-separated numbers.
	 * @param int    $length     Target length (pad / truncate).
	 * @return array<int, float|null>
	 */
	private static function parse_comma_separated_values( string $values_raw, int $length ): array {
		$parts  = array_map( 'trim', explode( ',', $values_raw ) );
		$parsed = array();

		for ( $index = 0; $index < $length; $index++ ) {
			$part = $parts[ $index ] ?? '';
			if ( '' === $part ) {
				$parsed[] = null;
				continue;
			}

			$numeric  = (float) preg_replace( '/[^\d.-]/', '', $part );
			$parsed[] = is_finite( $numeric ) ? $numeric : null;
		}

		return $parsed;
	}

	/**
	 * Parse raw points into numeric rows.
	 *
	 * @param array<int, array<string, mixed>> $points Raw points.
	 * @return array<int, array{label: string, value: float, color: string}>
	 */
	private static function parse_chart_points( array $points ): array {
		$parsed = array();

		foreach ( $points as $point ) {
			if ( ! is_array( $point ) ) {
				continue;
			}

			$label     = self::normalize_inner_plain( $point['label'] ?? '' );
			$value_raw = self::normalize_inner_plain( $point['value'] ?? '' );

			if ( '' === trim( $value_raw ) ) {
				continue;
			}

			$numeric = (float) preg_replace( '/[^\d.-]/', '', $value_raw );

			if ( ! is_finite( $numeric ) ) {
				continue;
			}

			$parsed[] = array(
				'label' => $label,
				'value' => $numeric,
				'color' => self::normalize_inner_plain( $point['color'] ?? '' ),
			);
		}

		return array_slice( $parsed, 0, self::MAX_POINTS );
	}

	/**
	 * Collect legacy chart points from child block attrs.
	 *
	 * @param array<int, array<string, mixed>> $inner_blocks Parsed inner blocks.
	 * @return array<int, array{label: string, value: string, color: string}>
	 */
	private static function collect_points_from_inner_blocks( array $inner_blocks ): array {
		$points = array();

		foreach ( $inner_blocks as $inner_block ) {
			if ( ! is_array( $inner_block ) ) {
				continue;
			}

			$child_attrs = $inner_block['attrs'] ?? array();
			if ( ! is_array( $child_attrs ) ) {
				continue;
			}

			$desktop_value = static function ( string $key ) use ( $child_attrs ): string {
				$leaf = $child_attrs[ $key ]['innerContent']['desktop']['value'] ?? '';
				return self::normalize_inner_plain( $leaf );
			};

			$points[] = array(
				'label' => self::resolve_dynamic_plain( $desktop_value( 'label' ), $child_attrs ),
				'value' => self::resolve_dynamic_plain( $desktop_value( 'value' ), $child_attrs ),
				'color' => $desktop_value( 'point_color' ),
			);
		}

		return $points;
	}

	/**
	 * Collect multi-dataset rows from child block attrs.
	 *
	 * Data (labels / values / data points) always uses desktop. Style colors and
	 * related ranges cascade for `$breakpoint` like Divi `getAttrByMode`.
	 *
	 * @param array<int, array<string, mixed>> $inner_blocks Parsed inner blocks.
	 * @param string                           $breakpoint   desktop|tablet|phone.
	 * @return array<int, array<string, mixed>>
	 */
	private static function collect_datasets_from_inner_blocks( array $inner_blocks, string $breakpoint = 'desktop' ): array {
		$datasets = array();

		foreach ( $inner_blocks as $inner_block ) {
			if ( ! is_array( $inner_block ) ) {
				continue;
			}

			$child_attrs = $inner_block['attrs'] ?? array();
			if ( ! is_array( $child_attrs ) ) {
				continue;
			}

			$desktop_value = static function ( string $key ) use ( $child_attrs ): string {
				return self::read_inner_attr_for_breakpoint( $child_attrs, $key, 'desktop', '' );
			};

			$style_value = static function ( string $key ) use ( $child_attrs, $breakpoint ): string {
				return self::read_inner_attr_for_breakpoint( $child_attrs, $key, $breakpoint, '' );
			};

			$data_points_raw = $child_attrs['data_points']['innerContent']['desktop']['value'] ?? array();

			$datasets[] = array(
				'label'                => self::resolve_dynamic_plain( $desktop_value( 'dataset_label' ), $child_attrs ),
				'values'               => self::resolve_dynamic_plain( $desktop_value( 'dataset_values' ), $child_attrs ),
				'dataPoints'           => self::extract_data_points( $data_points_raw, $child_attrs ),
				'color'                => $style_value( 'dataset_color' ),
				'borderColor'          => $style_value( 'dataset_border_color' ),
				'borderWidth'          => $style_value( 'dataset_border_width' ),
				'hoverBackgroundColor' => $style_value( 'dataset_hover_background_color' ),
				'hoverBorderColor'     => $style_value( 'dataset_hover_border_color' ),
				'hoverBorderWidth'     => $style_value( 'dataset_hover_border_width' ),
				'borderRadius'         => $style_value( 'dataset_border_radius' ),
			);
		}

		// Soft cap — never fatal when Loop returns more than MAX_DATASETS.
		return array_slice( $datasets, 0, self::MAX_DATASETS );
	}

	/**
	 * Count Chart Item children before the dataset cap (for truncation notices).
	 *
	 * @param array<int, array<string, mixed>> $inner_blocks Parsed inner blocks.
	 * @return int
	 */
	private static function count_chart_item_inner_blocks( array $inner_blocks ): int {
		$count = 0;
		foreach ( $inner_blocks as $inner_block ) {
			if ( ! is_array( $inner_block ) ) {
				continue;
			}
			++$count;
		}
		return $count;
	}

	/**
	 * Editor-facing notice when Loop / children exceed the dataset cap.
	 *
	 * Visible only to users who can edit posts so visitors never see it.
	 *
	 * @param int $raw_count Uncapped child / dataset count.
	 * @return string HTML or empty.
	 */
	private static function render_dataset_cap_notice( int $raw_count ): string {
		if ( $raw_count <= self::MAX_DATASETS ) {
			return '';
		}

		if ( ! current_user_can( 'edit_posts' ) ) {
			return '';
		}

		return sprintf(
			'<p class="dsm-chart-dataset-cap-notice" role="status">%s</p>',
			esc_html(
				sprintf(
					/* translators: 1: maximum datasets, 2: total datasets returned by Loop/query */
					__(
						'Chart shows the first %1$d datasets (%2$d found). Reduce the Loop query or posts per page.',
						'dsm-supreme-modules-pro-for-divi'
					),
					self::MAX_DATASETS,
					$raw_count
				)
			)
		);
	}

	/**
	 * Whether a dataset has nested data_points rows.
	 *
	 * @param array<string, mixed> $dataset Dataset row.
	 * @return bool
	 */
	private static function child_has_data_points( array $dataset ): bool {
		$points = $dataset['dataPoints'] ?? null;
		return is_array( $points ) && array() !== $points;
	}

	/**
	 * Soft-detect multi-dataset mode.
	 *
	 * Prefer nested data_points. Fall back to Categories + dataset_values.
	 *
	 * @param array<int, string>               $categories Category labels.
	 * @param array<int, array<string, mixed>> $datasets   Dataset rows.
	 * @return bool
	 */
	private static function is_multi_dataset_mode( array $categories, array $datasets ): bool {
		if ( array() === $datasets ) {
			return false;
		}

		foreach ( $datasets as $dataset ) {
			if ( is_array( $dataset ) && self::child_has_data_points( $dataset ) ) {
				return true;
			}
		}

		if ( array() === $categories ) {
			return false;
		}

		foreach ( $datasets as $dataset ) {
			if ( ! is_array( $dataset ) ) {
				continue;
			}
			$values = trim( self::normalize_inner_plain( $dataset['values'] ?? '' ) );
			if ( '' !== $values ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Format a chart numeric for data-summary display.
	 *
	 * @param mixed $value Chart.js data value.
	 * @return string
	 */
	private static function format_summary_value( $value ): string {
		if ( null === $value || '' === $value ) {
			return '';
		}

		if ( is_array( $value ) ) {
			$x = isset( $value['x'] ) && is_numeric( $value['x'] ) ? (float) $value['x'] : null;
			$y = isset( $value['y'] ) && is_numeric( $value['y'] ) ? (float) $value['y'] : null;
			if ( null === $x || null === $y || ! is_finite( $x ) || ! is_finite( $y ) ) {
				return '';
			}
			$xy = self::format_summary_value( $x ) . ', ' . self::format_summary_value( $y );
			if ( isset( $value['r'] ) && is_numeric( $value['r'] ) && is_finite( (float) $value['r'] ) ) {
				return $xy . ' (r=' . self::format_summary_value( (float) $value['r'] ) . ')';
			}
			return $xy;
		}

		if ( ! is_numeric( $value ) ) {
			return (string) $value;
		}

		$numeric = (float) $value;
		if ( ! is_finite( $numeric ) ) {
			return '';
		}

		if ( (float) (int) $numeric === $numeric ) {
			return (string) (int) $numeric;
		}

		return (string) $numeric;
	}

	/**
	 * Build data-summary rows from a Chart.js config (resolved labels/datasets).
	 *
	 * Includes all datasets (pie/doughnut/polarArea multi-ring included).
	 * Scatter/bubble summarize `{ x, y }` / `{ x, y, r }` point objects.
	 *
	 * @param array<string, mixed> $config Chart.js config.
	 * @return array<int, array{series: string, label: string, value: string}>
	 */
	private static function build_data_summary_rows( array $config ): array {
		$type     = (string) ( $config['type'] ?? '' );
		$is_xy    = in_array( $type, array( 'scatter', 'bubble' ), true );
		$labels   = $config['data']['labels'] ?? null;
		$datasets = $config['data']['datasets'] ?? null;

		if ( ! is_array( $datasets ) || array() === $datasets ) {
			return array();
		}

		if ( ! $is_xy && ( ! is_array( $labels ) || array() === $labels ) ) {
			return array();
		}

		$rows = array();

		foreach ( $datasets as $dataset_index => $dataset ) {
			if ( ! is_array( $dataset ) ) {
				continue;
			}

			$series_label = trim( self::normalize_inner_plain( $dataset['label'] ?? '' ) );
			if ( '' === $series_label ) {
				$series_label = 'Dataset ' . ( (int) $dataset_index + 1 );
			}

			$data = is_array( $dataset['data'] ?? null ) ? $dataset['data'] : array();

			if ( $is_xy ) {
				$point_index = 0;
				foreach ( $data as $point ) {
					if ( ! is_array( $point ) ) {
						continue;
					}
					++$point_index;
					$rows[] = array(
						'series' => $series_label,
						'label'  => 'Point ' . $point_index,
						'value'  => self::format_summary_value( $point ),
					);
				}
				continue;
			}

			foreach ( $labels as $label_index => $label ) {
				$rows[] = array(
					'series' => $series_label,
					'label'  => trim( self::normalize_inner_plain( $label ) ),
					'value'  => self::format_summary_value( $data[ $label_index ] ?? null ),
				);
			}
		}

		return $rows;
	}

	/**
	 * Render frontend data-summary table HTML.
	 *
	 * @param array<string, mixed>  $config         Chart.js config.
	 * @param string                $style          `visible`|`sr_only`.
	 * @param array<string, string> $header_labels  Series / Label / Value headers.
	 * @return string
	 */
	private static function render_data_summary_html( array $config, string $style, array $header_labels = array() ): string {
		$rows = self::build_data_summary_rows( $config );
		if ( array() === $rows ) {
			return '';
		}

		$is_sr_only = 'sr_only' === $style;
		$classes    = 'dsm-chart-data-summary';
		if ( $is_sr_only ) {
			$classes .= ' screen-reader-text';
		}

		$series_header = isset( $header_labels['series'] ) && '' !== trim( (string) $header_labels['series'] )
			? (string) $header_labels['series']
			: __( 'Series', 'dsm-supreme-modules-pro-for-divi' );
		$label_header  = isset( $header_labels['label'] ) && '' !== trim( (string) $header_labels['label'] )
			? (string) $header_labels['label']
			: __( 'Label', 'dsm-supreme-modules-pro-for-divi' );
		$value_header  = isset( $header_labels['value'] ) && '' !== trim( (string) $header_labels['value'] )
			? (string) $header_labels['value']
			: __( 'Value', 'dsm-supreme-modules-pro-for-divi' );

		$thead = sprintf(
			'<thead><tr><th scope="col" class="dsm-chart-data-summary-th--series">%1$s</th><th scope="col" class="dsm-chart-data-summary-th--label">%2$s</th><th scope="col" class="dsm-chart-data-summary-th--value">%3$s</th></tr></thead>',
			esc_html( $series_header ),
			esc_html( $label_header ),
			esc_html( $value_header )
		);

		$body_rows = '';
		foreach ( $rows as $row ) {
			$body_rows .= sprintf(
				'<tr><th scope="row">%1$s</th><td>%2$s</td><td>%3$s</td></tr>',
				esc_html( (string) ( $row['series'] ?? '' ) ),
				esc_html( (string) ( $row['label'] ?? '' ) ),
				esc_html( (string) ( $row['value'] ?? '' ) )
			);
		}

		return sprintf(
			'<div class="%1$s" aria-label="%2$s"><table class="dsm-chart-data-summary-table">%3$s<tbody>%4$s</tbody></table></div>',
			esc_attr( $classes ),
			esc_attr__( 'Chart data summary', 'dsm-supreme-modules-pro-for-divi' ),
			$thead,
			$body_rows
		);
	}

	/**
	 * Whether a Chart.js config has renderable numeric data.
	 *
	 * @param array<string, mixed> $config Chart.js config.
	 * @return bool
	 */
	private static function chart_config_has_data( array $config ): bool {
		$type     = (string) ( $config['type'] ?? '' );
		$is_xy    = in_array( $type, array( 'scatter', 'bubble' ), true );
		$labels   = $config['data']['labels'] ?? null;
		$datasets = $config['data']['datasets'] ?? null;

		if ( ! is_array( $datasets ) || array() === $datasets ) {
			return false;
		}

		$has_points = false;
		foreach ( $datasets as $dataset ) {
			if ( ! is_array( $dataset ) || ! isset( $dataset['data'] ) || ! is_array( $dataset['data'] ) ) {
				continue;
			}
			foreach ( $dataset['data'] as $value ) {
				if ( is_array( $value ) ) {
					$x = isset( $value['x'] ) && is_numeric( $value['x'] ) ? (float) $value['x'] : null;
					$y = isset( $value['y'] ) && is_numeric( $value['y'] ) ? (float) $value['y'] : null;
					if ( null !== $x && null !== $y && is_finite( $x ) && is_finite( $y ) ) {
						$has_points = true;
						break 2;
					}
					continue;
				}
				if ( null !== $value && is_numeric( $value ) && is_finite( (float) $value ) ) {
					$has_points = true;
					break 2;
				}
			}
		}

		if ( ! $has_points ) {
			return false;
		}

		if ( $is_xy ) {
			return true;
		}

		return is_array( $labels ) && array() !== $labels;
	}

	/**
	 * Parse a numeric attr value (strips units).
	 *
	 * @param mixed $value    Stored leaf.
	 * @param float $fallback Fallback when invalid.
	 * @return float
	 */
	private static function parse_numeric_attr( $value, float $fallback ): float {
		$plain = trim( self::normalize_inner_plain( $value ) );
		if ( '' === $plain ) {
			return $fallback;
		}

		$numeric = (float) preg_replace( '/[^\d.-]/', '', $plain );
		return is_finite( $numeric ) ? $numeric : $fallback;
	}

	/**
	 * Resolve Chart.js dataset `pointStyle`.
	 *
	 * Stored select value `"false"` maps to boolean false (no marker).
	 *
	 * @param string $value    Stored point_style.
	 * @param string $fallback Default style string.
	 * @return string|false
	 */
	private static function resolve_point_style( string $value, string $fallback = 'circle' ) {
		$plain = trim( $value );
		if ( ! in_array( $plain, self::POINT_STYLES, true ) ) {
			return $fallback;
		}

		return 'false' === $plain ? false : $plain;
	}

	/**
	 * Whether an on/off toggle is on.
	 *
	 * @param string $value    on|off.
	 * @param string $fallback Default when empty.
	 * @return bool
	 */
	private static function is_on( string $value, string $fallback = 'on' ): bool {
		$resolved = '' !== trim( $value ) ? trim( $value ) : $fallback;
		return 'on' === $resolved;
	}

	/**
	 * Resolve doughnut cutout (percent string).
	 *
	 * @param string $value Stored cutout.
	 * @return string
	 */
	private static function resolve_cutout( string $value ): string {
		$plain = trim( $value );
		if ( '' === $plain ) {
			return '50%';
		}

		if ( false !== strpos( $plain, '%' ) ) {
			return $plain;
		}

		$numeric = (float) preg_replace( '/[^\d.-]/', '', $plain );
		return is_finite( $numeric ) ? $numeric . '%' : '50%';
	}

	/**
	 * Read cascaded innerContent string for a Divi breakpoint.
	 *
	 * Empty / missing values inherit from larger breakpoints (phone → tablet →
	 * desktop), matching Visual Builder `getAttrByMode`.
	 *
	 * @param array<string, mixed> $attrs      Module attrs.
	 * @param string               $key        Attribute key.
	 * @param string               $breakpoint desktop|tablet|phone.
	 * @param string               $fallback   Default when all breakpoints empty.
	 * @return string
	 */
	private static function read_inner_attr_for_breakpoint( array $attrs, string $key, string $breakpoint, string $fallback ): string {
		$cascade = array( 'desktop' );
		if ( 'tablet' === $breakpoint ) {
			$cascade = array( 'tablet', 'desktop' );
		} elseif ( 'phone' === $breakpoint ) {
			$cascade = array( 'phone', 'tablet', 'desktop' );
		}

		foreach ( $cascade as $bp ) {
			$leaf  = $attrs[ $key ]['innerContent'][ $bp ]['value'] ?? null;
			$plain = self::normalize_inner_plain( $leaf );
			if ( '' !== trim( $plain ) ) {
				return $plain;
			}
		}

		return $fallback;
	}

	/**
	 * Read desktop innerContent string from attrs.
	 *
	 * @param array<string, mixed> $attrs    Module attrs.
	 * @param string               $key      Attribute key.
	 * @param string               $fallback Default.
	 * @return string
	 */
	private static function read_inner_attr( array $attrs, string $key, string $fallback ): string {
		return self::read_inner_attr_for_breakpoint( $attrs, $key, 'desktop', $fallback );
	}

	/**
	 * Extract Chart.js style fields that can change per Divi breakpoint.
	 *
	 * @param array<string, mixed> $config Full Chart.js config.
	 * @return array{datasets: array<int, array<string, mixed>>, scales: array<string, array<string, mixed>>}
	 */
	private static function extract_chart_style_snapshot( array $config ): array {
		$datasets = array();
		$raw      = $config['data']['datasets'] ?? array();
		if ( is_array( $raw ) ) {
			foreach ( $raw as $dataset ) {
				if ( ! is_array( $dataset ) ) {
					continue;
				}
				$entry = array();
				foreach (
					array(
						'backgroundColor',
						'borderColor',
						'hoverBackgroundColor',
						'hoverBorderColor',
						'hoverBorderWidth',
						'borderRadius',
						'borderWidth',
						'pointBackgroundColor',
						'pointBorderColor',
					) as $prop
				) {
					if ( array_key_exists( $prop, $dataset ) ) {
						$entry[ $prop ] = $dataset[ $prop ];
					}
				}
				$datasets[] = $entry;
			}
		}

		$scales     = array();
		$opt_scales = $config['options']['scales'] ?? null;
		if ( is_array( $opt_scales ) ) {
			foreach ( array( 'x', 'y', 'r' ) as $axis ) {
				if ( ! isset( $opt_scales[ $axis ] ) || ! is_array( $opt_scales[ $axis ] ) ) {
					continue;
				}
				$axis_styles = array();
				if ( isset( $opt_scales[ $axis ]['grid']['color'] ) ) {
					$axis_styles['gridColor'] = $opt_scales[ $axis ]['grid']['color'];
				}
				if ( isset( $opt_scales[ $axis ]['ticks']['color'] ) ) {
					$axis_styles['ticksColor'] = $opt_scales[ $axis ]['ticks']['color'];
				}
				if ( isset( $opt_scales[ $axis ]['angleLines']['color'] ) ) {
					$axis_styles['angleLinesColor'] = $opt_scales[ $axis ]['angleLines']['color'];
				}
				if ( array() !== $axis_styles ) {
					$scales[ $axis ] = $axis_styles;
				}
			}
		}

		return array(
			'datasets' => $datasets,
			'scales'   => $scales,
		);
	}

	/**
	 * Build Chart.js config args for one Divi breakpoint.
	 *
	 * Non-style options stay desktop; color / hover / radius / grid / tick
	 * attrs cascade for `$breakpoint`.
	 *
	 * @param array<string, mixed>                                           $attrs            Module attrs.
	 * @param array<int, array<string, mixed>>                               $inner_blocks     Child blocks.
	 * @param array<int, string>                                             $category_labels  Category labels.
	 * @param array<int, array{label: string, value: string, color: string}> $raw_points Legacy points.
	 * @param string                                                         $title_text       Resolved title.
	 * @param string                                                         $breakpoint       desktop|tablet|phone.
	 * @return array<string, mixed>
	 */
	private static function build_chart_config_args_for_breakpoint(
		array $attrs,
		array $inner_blocks,
		array $category_labels,
		array $raw_points,
		string $title_text,
		string $breakpoint
	): array {
		$style = static function ( string $key, string $fallback ) use ( $attrs, $breakpoint ): string {
			return self::read_inner_attr_for_breakpoint( $attrs, $key, $breakpoint, $fallback );
		};

		return array(
			'chart_type'                     => self::read_inner_attr( $attrs, 'chart_type', 'bar' ),
			'bar_orientation'                => self::read_inner_attr( $attrs, 'bar_orientation', 'vertical' ),
			'points'                         => $raw_points,
			'category_labels'                => $category_labels,
			'datasets'                       => self::collect_datasets_from_inner_blocks( $inner_blocks, $breakpoint ),
			'show_legend'                    => self::read_inner_attr( $attrs, 'show_legend', 'on' ),
			'show_tooltips'                  => self::read_inner_attr( $attrs, 'show_tooltips', 'on' ),
			'animate'                        => self::read_inner_attr( $attrs, 'animate', 'on' ),
			'title'                          => $title_text,
			'legend_position'                => self::read_inner_attr( $attrs, 'legend_position', 'top' ),
			'legend_align'                   => self::read_inner_attr( $attrs, 'legend_align', 'center' ),
			'legend_reverse'                 => self::read_inner_attr( $attrs, 'legend_reverse', 'off' ),
			'tooltip_mode'                   => self::read_inner_attr( $attrs, 'tooltip_mode', 'nearest' ),
			'tooltip_intersect'              => self::read_inner_attr( $attrs, 'tooltip_intersect', 'on' ),
			'animation_duration'             => self::read_inner_attr( $attrs, 'animation_duration', '1000' ),
			'animation_easing'               => self::read_inner_attr( $attrs, 'animation_easing', 'easeOutQuart' ),
			'animation_delay'                => self::read_inner_attr( $attrs, 'animation_delay', '0' ),
			'animation_loop'                 => self::read_inner_attr( $attrs, 'animation_loop', 'off' ),
			'interaction_mode'               => self::read_inner_attr( $attrs, 'interaction_mode', 'nearest' ),
			'cutout'                         => self::read_inner_attr( $attrs, 'cutout', '50%' ),
			'circumference'                  => self::read_inner_attr( $attrs, 'circumference', '360' ),
			'rotation'                       => self::read_inner_attr( $attrs, 'rotation', '0' ),
			'begin_at_zero'                  => self::read_inner_attr( $attrs, 'begin_at_zero', 'on' ),
			'stacked'                        => self::read_inner_attr( $attrs, 'stacked', 'off' ),
			'fill'                           => self::read_inner_attr( $attrs, 'fill', 'off' ),
			'border_width'                   => self::read_inner_attr( $attrs, 'border_width', '1' ),
			'tension'                        => self::read_inner_attr( $attrs, 'tension', '0.3' ),
			'point_radius'                   => self::read_inner_attr( $attrs, 'point_radius', '3' ),
			'point_style'                    => self::read_inner_attr( $attrs, 'point_style', 'circle' ),
			'show_x_grid'                    => self::read_inner_attr( $attrs, 'show_x_grid', 'on' ),
			'show_y_grid'                    => self::read_inner_attr( $attrs, 'show_y_grid', 'on' ),
			'grid_color'                     => $style( 'grid_color', 'rgba(0,0,0,0.1)' ),
			'tick_color'                     => $style( 'tick_color', '#666666' ),
			'dataset_color'                  => $style( 'dataset_color', '' ),
			'dataset_border_color'           => $style( 'dataset_border_color', '' ),
			'dataset_hover_background_color' => $style( 'dataset_hover_background_color', '' ),
			'dataset_hover_border_color'     => $style( 'dataset_hover_border_color', '' ),
			'dataset_hover_border_width'     => $style( 'dataset_hover_border_width', '' ),
			'border_radius'                  => $style( 'border_radius', '0' ),
			'chart_responsive'               => self::read_inner_attr( $attrs, 'chart_responsive', 'on' ),
			'maintain_aspect_ratio'          => self::read_inner_attr( $attrs, 'maintain_aspect_ratio', 'off' ),
		);
	}

	/**
	 * Build responsive style snapshots for tablet/phone when they differ from desktop.
	 *
	 * @param array<string, mixed>                                           $attrs           Module attrs.
	 * @param array<int, array<string, mixed>>                               $inner_blocks    Child blocks.
	 * @param array<int, string>                                             $category_labels Category labels.
	 * @param array<int, array{label: string, value: string, color: string}> $raw_points Legacy points.
	 * @param string                                                         $title_text      Resolved title.
	 * @param array<string, mixed>                                           $desktop_config  Desktop Chart.js config.
	 * @return array<string, array{datasets: array<int, array<string, mixed>>, scales: array<string, array<string, mixed>>}>
	 */
	private static function build_responsive_style_breakpoints(
		array $attrs,
		array $inner_blocks,
		array $category_labels,
		array $raw_points,
		string $title_text,
		array $desktop_config
	): array {
		$desktop_styles = self::extract_chart_style_snapshot( $desktop_config );
		$desktop_json   = wp_json_encode( $desktop_styles );
		$out            = array(
			'desktop' => $desktop_styles,
		);

		foreach ( array( 'tablet', 'phone' ) as $breakpoint ) {
			$config = self::build_chart_js_config(
				self::build_chart_config_args_for_breakpoint(
					$attrs,
					$inner_blocks,
					$category_labels,
					$raw_points,
					$title_text,
					$breakpoint
				)
			);
			$styles = self::extract_chart_style_snapshot( $config );
			$json   = wp_json_encode( $styles );
			if ( false !== $json && $json !== $desktop_json ) {
				$out[ $breakpoint ] = $styles;
			}
		}

		return $out;
	}

	/**
	 * Build shared Chart.js options.
	 *
	 * @param array<string, mixed> $args Options args.
	 * @return array<string, mixed>
	 */
	private static function build_chart_options( array $args ): array {
		$type               = (string) ( $args['type'] ?? 'bar' );
		$index_axis         = $args['index_axis'] ?? null;
		$show_legend        = (string) ( $args['show_legend'] ?? 'on' );
		$show_tooltips      = (string) ( $args['show_tooltips'] ?? 'on' );
		$animate            = (string) ( $args['animate'] ?? 'on' );
		$legend_position    = (string) ( $args['legend_position'] ?? 'top' );
		$legend_align       = (string) ( $args['legend_align'] ?? 'center' );
		$legend_reverse     = (string) ( $args['legend_reverse'] ?? 'off' );
		$tooltip_mode       = (string) ( $args['tooltip_mode'] ?? 'nearest' );
		$tooltip_intersect  = (string) ( $args['tooltip_intersect'] ?? 'on' );
		$animation_duration = (string) ( $args['animation_duration'] ?? '1000' );
		$animation_easing   = (string) ( $args['animation_easing'] ?? 'easeOutQuart' );
		$animation_delay    = (string) ( $args['animation_delay'] ?? '0' );
		$animation_loop     = (string) ( $args['animation_loop'] ?? 'off' );
		$interaction_mode   = (string) ( $args['interaction_mode'] ?? 'nearest' );
		$cutout             = (string) ( $args['cutout'] ?? '50%' );
		$circumference      = (string) ( $args['circumference'] ?? '360' );
		$rotation           = (string) ( $args['rotation'] ?? '0' );
		$begin_at_zero      = (string) ( $args['begin_at_zero'] ?? 'on' );
		$stacked            = (string) ( $args['stacked'] ?? 'off' );
		$show_x_grid        = (string) ( $args['show_x_grid'] ?? 'on' );
		$show_y_grid        = (string) ( $args['show_y_grid'] ?? 'on' );
		$grid_color         = (string) ( $args['grid_color'] ?? 'rgba(0,0,0,0.1)' );
		$tick_color         = (string) ( $args['tick_color'] ?? '#666666' );
		$locale             = (string) ( $args['locale'] ?? '' );
		$chart_responsive   = (string) ( $args['chart_responsive'] ?? 'on' );
		$maintain_aspect    = (string) ( $args['maintain_aspect_ratio'] ?? 'off' );

		$is_pie_doughnut   = in_array( $type, array( 'pie', 'doughnut' ), true );
		$is_radial         = in_array( $type, array( 'radar', 'polarArea' ), true );
		$is_xy             = in_array( $type, array( 'scatter', 'bubble' ), true );
		$allowed_positions = array( 'top', 'bottom', 'left', 'right' );
		$allowed_align     = array( 'start', 'center', 'end' );
		$allowed_modes     = array( 'index', 'nearest', 'point', 'dataset' );
		$allowed_easings   = array(
			'linear',
			'easeInQuad',
			'easeOutQuad',
			'easeInOutQuad',
			'easeInCubic',
			'easeOutCubic',
			'easeInOutCubic',
			'easeInQuart',
			'easeOutQuart',
			'easeInOutQuart',
			'easeInQuint',
			'easeOutQuint',
			'easeInOutQuint',
			'easeInSine',
			'easeOutSine',
			'easeInOutSine',
			'easeInExpo',
			'easeOutExpo',
			'easeInOutExpo',
			'easeInCirc',
			'easeOutCirc',
			'easeInOutCirc',
			'easeInElastic',
			'easeOutElastic',
			'easeInOutElastic',
			'easeInBack',
			'easeOutBack',
			'easeInOutBack',
			'easeInBounce',
			'easeOutBounce',
			'easeInOutBounce',
		);

		$legend_pos      = in_array( $legend_position, $allowed_positions, true ) ? $legend_position : 'top';
		$legend_al       = in_array( $legend_align, $allowed_align, true ) ? $legend_align : 'center';
		$tip_mode        = in_array( $tooltip_mode, $allowed_modes, true ) ? $tooltip_mode : 'nearest';
		$ix_mode         = in_array( $interaction_mode, array( 'index', 'nearest', 'point' ), true ) ? $interaction_mode : 'nearest';
		$easing          = in_array( $animation_easing, $allowed_easings, true ) ? $animation_easing : 'easeOutQuart';
		$duration        = max( 0.0, self::parse_numeric_attr( $animation_duration, 1000.0 ) );
		$delay           = max( 0.0, self::parse_numeric_attr( $animation_delay, 0.0 ) );
		$loop_on         = self::is_on( $animation_loop, 'off' );
		$grid_resolved   = self::resolve_chart_color_paint( $grid_color );
		$tick_resolved   = self::resolve_chart_color_paint( $tick_color );
		$grid_color_val  = '' !== $grid_resolved ? $grid_resolved : 'rgba(0,0,0,0.1)';
		$tick_color_val  = '' !== $tick_resolved ? $tick_resolved : '#666666';
		$tip_intersect   = self::is_on( $tooltip_intersect, 'on' );
		$legend_on       = self::is_on( $show_legend, 'on' );
		$resolved_locale = '' !== trim( $locale ) ? trim( $locale ) : self::resolve_chart_locale();

		$options = array(
			'responsive'          => self::is_on( $chart_responsive, 'on' ),
			'maintainAspectRatio' => self::is_on( $maintain_aspect, 'off' ),
			'interaction'         => array(
				'mode'      => $ix_mode,
				'intersect' => $tip_intersect,
			),
			'plugins'             => array(
				'legend'     => array(
					'display'  => false,
					'position' => $legend_pos,
					'align'    => $legend_al,
					'reverse'  => self::is_on( $legend_reverse, 'off' ),
				),
				'htmlLegend' => array(
					'enabled' => $legend_on,
				),
				'tooltip'    => array(
					'enabled'   => self::is_on( $show_tooltips, 'on' ),
					'mode'      => $tip_mode,
					'intersect' => $tip_intersect,
				),
				'title'      => array(
					'display' => false,
				),
			),
		);

		if ( '' !== $resolved_locale ) {
			$options['locale'] = $resolved_locale;
		}

		if ( 'y' === $index_axis ) {
			$options['indexAxis'] = 'y';
		}

		if ( ! self::is_on( $animate, 'on' ) ) {
			$options['animation'] = false;
		} else {
			$options['animation'] = array(
				'duration' => $duration,
				'delay'    => $delay,
				'loop'     => $loop_on,
				'easing'   => $easing,
			);
		}

		if ( $is_pie_doughnut ) {
			$options['circumference'] = min( 360.0, max( 0.0, self::parse_numeric_attr( $circumference, 360.0 ) ) );
			$options['rotation']      = self::parse_numeric_attr( $rotation, 0.0 );
			if ( 'doughnut' === $type ) {
				$options['cutout'] = self::resolve_cutout( $cutout );
			}
		} elseif ( $is_radial ) {
			$begin_zero        = self::is_on( $begin_at_zero, 'on' );
			$options['scales'] = array(
				'r' => array(
					'beginAtZero' => $begin_zero,
					'angleLines'  => array(
						'display' => self::is_on( $show_x_grid, 'on' ),
						'color'   => $grid_color_val,
					),
					'grid'        => array(
						'display' => self::is_on( $show_y_grid, 'on' ),
						'color'   => $grid_color_val,
					),
					'ticks'       => array(
						'color'         => $tick_color_val,
						'backdropColor' => 'transparent',
					),
				),
			);
		} elseif ( $is_xy ) {
			$begin_zero        = self::is_on( $begin_at_zero, 'on' );
			$options['scales'] = array(
				'x' => array(
					'type'        => 'linear',
					'position'    => 'bottom',
					'beginAtZero' => $begin_zero,
					'grid'        => array(
						'display' => self::is_on( $show_x_grid, 'on' ),
						'color'   => $grid_color_val,
					),
					'ticks'       => array(
						'color' => $tick_color_val,
					),
				),
				'y' => array(
					'type'        => 'linear',
					'beginAtZero' => $begin_zero,
					'grid'        => array(
						'display' => self::is_on( $show_y_grid, 'on' ),
						'color'   => $grid_color_val,
					),
					'ticks'       => array(
						'color' => $tick_color_val,
					),
				),
			);
		} else {
			$begin_zero        = self::is_on( $begin_at_zero, 'on' );
			$is_stacked        = self::is_on( $stacked, 'off' );
			$options['scales'] = array(
				'x' => array(
					'beginAtZero' => $begin_zero,
					'stacked'     => $is_stacked,
					'grid'        => array(
						'display' => self::is_on( $show_x_grid, 'on' ),
						'color'   => $grid_color_val,
					),
					'ticks'       => array(
						'color' => $tick_color_val,
					),
				),
				'y' => array(
					'beginAtZero' => $begin_zero,
					'stacked'     => $is_stacked,
					'grid'        => array(
						'display' => self::is_on( $show_y_grid, 'on' ),
						'color'   => $grid_color_val,
					),
					'ticks'       => array(
						'color' => $tick_color_val,
					),
				),
			);
		}

		return $options;
	}

	/**
	 * Resolve per-series border width (child override, else parent default).
	 *
	 * @param array<string, mixed> $series       Dataset row.
	 * @param string               $border_width Parent border width.
	 * @return float
	 */
	private static function resolve_series_border_width( array $series, string $border_width ): float {
		$child_width = trim( self::normalize_inner_plain( $series['borderWidth'] ?? '' ) );
		if ( '' !== $child_width ) {
			return max( 0.0, self::parse_numeric_attr( $child_width, 1.0 ) );
		}

		return max( 0.0, self::parse_numeric_attr( $border_width, 1.0 ) );
	}

	/**
	 * Build multi-dataset Chart.js config.
	 *
	 * Pie/doughnut/polarArea: each dataset is a concentric ring (Chart.js);
	 * shared labels from the first dataset’s points; later series align by label.
	 * Scatter/bubble: Label→X, Value→Y (bubble radius from point_radius or parent).
	 *
	 * @param array<string, mixed> $args Config args.
	 * @return array<string, mixed>
	 */
	private static function build_multi_dataset_chart_config( array $args ): array {
		$chart_type      = (string) ( $args['chart_type'] ?? 'bar' );
		$bar_orientation = (string) ( $args['bar_orientation'] ?? 'vertical' );
		$category_labels = is_array( $args['category_labels'] ?? null ) ? $args['category_labels'] : array();
		$datasets        = is_array( $args['datasets'] ?? null ) ? $args['datasets'] : array();
		$fill            = (string) ( $args['fill'] ?? 'off' );
		$border_width    = (string) ( $args['border_width'] ?? '1' );
		$tension         = (string) ( $args['tension'] ?? '0.3' );
		$point_radius    = (string) ( $args['point_radius'] ?? '3' );
		$point_style     = (string) ( $args['point_style'] ?? 'circle' );
		$dataset_color   = (string) ( $args['dataset_color'] ?? '' );
		$dataset_border  = (string) ( $args['dataset_border_color'] ?? '' );
		$border_radius   = (string) ( $args['border_radius'] ?? '0' );
		$parent_hover    = array(
			'backgroundColor' => (string) ( $args['dataset_hover_background_color'] ?? '' ),
			'borderColor'     => (string) ( $args['dataset_hover_border_color'] ?? '' ),
			'borderWidth'     => (string) ( $args['dataset_hover_border_width'] ?? '' ),
		);

		$resolved             = self::resolve_chart_js_type( $chart_type, $bar_orientation );
		$type                 = $resolved['type'];
		$index_axis           = $resolved['index_axis'];
		$is_arc_slice         = in_array( $type, array( 'pie', 'doughnut', 'polarArea' ), true );
		$is_pie_doughnut      = in_array( $type, array( 'pie', 'doughnut' ), true );
		$is_line              = 'line' === $type;
		$is_radar             = 'radar' === $type;
		$is_bar               = 'bar' === $type;
		$is_scatter           = 'scatter' === $type;
		$is_bubble            = 'bubble' === $type;
		$is_xy                = $is_scatter || $is_bubble;
		$is_point_style_type  = $is_line || $is_radar || $is_scatter || $is_bubble;
		$point_radius_num     = max( 0.0, self::parse_numeric_attr( $point_radius, $is_bubble ? 10.0 : 3.0 ) );
		$resolved_point_style = self::resolve_point_style( $point_style, 'circle' );

		$series_list = array_slice( $datasets, 0, self::MAX_DATASETS );
		$use_points  = false;
		foreach ( $series_list as $series ) {
			if ( is_array( $series ) && self::child_has_data_points( $series ) ) {
				$use_points = true;
				break;
			}
		}

		$labels = array();
		if ( ! $is_xy ) {
			if ( $use_points ) {
				$labels = self::build_labels_from_first_dataset_points( $series_list );
			} else {
				$labels = array_slice( $category_labels, 0, self::MAX_CATEGORIES );
			}
		}

		$chart_datasets = array();

		foreach ( $series_list as $index => $series ) {
			if ( ! is_array( $series ) ) {
				continue;
			}

			$series_label = trim( self::normalize_inner_plain( $series['label'] ?? '' ) );
			if ( '' === $series_label ) {
				$series_label = 'Dataset ' . ( (int) $index + 1 );
			}

			$points = $use_points && is_array( $series['dataPoints'] ?? null )
				? $series['dataPoints']
				: array();

			if ( $is_xy ) {
				if ( $use_points ) {
					$data = $is_bubble
						? self::map_data_points_to_bubble( $points, $point_radius_num )
						: self::map_data_points_to_scatter( $points );
				} else {
					$legacy_labels = array_slice( $category_labels, 0, self::MAX_CATEGORIES );
					$values_raw    = self::normalize_inner_plain( $series['values'] ?? '' );
					$values        = self::parse_comma_separated_values( $values_raw, count( $legacy_labels ) );
					$data          = array();
					foreach ( $legacy_labels as $label_index => $label ) {
						$x = self::parse_point_number( (string) $label );
						$y = $values[ $label_index ] ?? null;
						if ( null === $x || null === $y || ! is_finite( (float) $y ) ) {
							continue;
						}
						if ( $is_bubble ) {
							$data[] = array(
								'x' => $x,
								'y' => (float) $y,
								'r' => $point_radius_num,
							);
						} else {
							$data[] = array(
								'x' => $x,
								'y' => (float) $y,
							);
						}
					}
				}
			} elseif ( $use_points ) {
				$data = self::align_data_points_to_labels( $labels, $points );
			} else {
				$values_raw = self::normalize_inner_plain( $series['values'] ?? '' );
				$data       = self::parse_comma_separated_values( $values_raw, count( $labels ) );
			}

			$child_fill        = trim( self::normalize_inner_plain( $series['color'] ?? '' ) );
			$parent_fill       = trim( $dataset_color );
			$has_explicit_fill = '' !== $child_fill || '' !== $parent_fill;
			$series_color      = self::resolve_point_color(
				$child_fill,
				(int) $index,
				$dataset_color
			);
			$series_border     = self::resolve_series_border_color(
				$series,
				$dataset_border,
				$series_color,
				( $is_pie_doughnut || 'polarArea' === $type ) ? '#ffffff' : ''
			);
			$border_width_num  = self::resolve_series_border_width( $series, $border_width );

			$dataset = array(
				'label'       => $series_label,
				'data'        => $data,
				'borderWidth' => $border_width_num,
			);

			if ( $is_arc_slice ) {
				$dataset['backgroundColor'] = self::resolve_arc_slice_background_colors(
					$labels,
					$points,
					$series_color,
					$has_explicit_fill
				);
				$dataset['borderColor']     = $series_border;
			} elseif ( $is_line || $is_radar ) {
				$dataset['borderColor']          = $series_border;
				$dataset['backgroundColor']      = $series_color;
				$dataset['fill']                 = self::resolve_dataset_fill( $chart_type, $fill, $is_radar );
				$dataset['tension']              = min( 1.0, max( 0.0, self::parse_numeric_attr( $tension, 0.3 ) ) );
				$dataset['pointRadius']          = $point_radius_num;
				$dataset['pointBackgroundColor'] = $series_color;
				$dataset['pointBorderColor']     = $series_color;
			} elseif ( $is_scatter ) {
				$dataset['backgroundColor']      = $series_color;
				$dataset['borderColor']          = $series_border;
				$dataset['pointRadius']          = $point_radius_num;
				$dataset['pointBackgroundColor'] = $series_color;
				$dataset['pointBorderColor']     = '' !== $series_border ? $series_border : $series_color;
			} elseif ( $is_bubble ) {
				$dataset['backgroundColor'] = $series_color;
				$dataset['borderColor']     = $series_border;
			} else {
				$dataset['backgroundColor'] = $series_color;
				$dataset['borderColor']     = $series_border;
			}

			if ( $is_point_style_type ) {
				$dataset['pointStyle'] = $resolved_point_style;
			}

			if ( $is_bar ) {
				$radius = self::resolve_series_border_radius( $series, $border_radius );
				if ( null !== $radius ) {
					$dataset['borderRadius'] = $radius;
				}
			}

			self::apply_dataset_hover_styles( $dataset, $series, $parent_hover );

			$chart_datasets[] = $dataset;
		}

		return array(
			'type'    => $type,
			'data'    => array(
				'labels'   => $is_xy ? array() : $labels,
				'datasets' => $chart_datasets,
			),
			'options' => self::build_chart_options(
				array_merge(
					$args,
					array(
						'type'       => $type,
						'index_axis' => $index_axis,
					)
				)
			),
		);
	}

	/**
	 * Build Chart.js v4 config array.
	 *
	 * @param array<string, mixed> $args Config args.
	 * @return array<string, mixed>
	 */
	private static function build_chart_js_config( array $args ): array {
		$chart_type           = (string) ( $args['chart_type'] ?? 'bar' );
		$bar_orientation      = (string) ( $args['bar_orientation'] ?? 'vertical' );
		$points               = is_array( $args['points'] ?? null ) ? $args['points'] : array();
		$category_labels      = is_array( $args['category_labels'] ?? null ) ? $args['category_labels'] : array();
		$datasets             = is_array( $args['datasets'] ?? null ) ? $args['datasets'] : array();
		$show_legend          = (string) ( $args['show_legend'] ?? 'on' );
		$show_tooltips        = (string) ( $args['show_tooltips'] ?? 'on' );
		$animate              = (string) ( $args['animate'] ?? 'on' );
		$title                = (string) ( $args['title'] ?? '' );
		$legend_position      = (string) ( $args['legend_position'] ?? 'top' );
		$legend_align         = (string) ( $args['legend_align'] ?? 'center' );
		$legend_reverse       = (string) ( $args['legend_reverse'] ?? 'off' );
		$tooltip_mode         = (string) ( $args['tooltip_mode'] ?? 'nearest' );
		$tooltip_intersect    = (string) ( $args['tooltip_intersect'] ?? 'on' );
		$animation_duration   = (string) ( $args['animation_duration'] ?? '1000' );
		$animation_easing     = (string) ( $args['animation_easing'] ?? 'easeOutQuart' );
		$animation_delay      = (string) ( $args['animation_delay'] ?? '0' );
		$animation_loop       = (string) ( $args['animation_loop'] ?? 'off' );
		$interaction_mode     = (string) ( $args['interaction_mode'] ?? 'nearest' );
		$cutout               = (string) ( $args['cutout'] ?? '50%' );
		$circumference        = (string) ( $args['circumference'] ?? '360' );
		$rotation             = (string) ( $args['rotation'] ?? '0' );
		$begin_at_zero        = (string) ( $args['begin_at_zero'] ?? 'on' );
		$stacked              = (string) ( $args['stacked'] ?? 'off' );
		$fill                 = (string) ( $args['fill'] ?? 'off' );
		$border_width         = (string) ( $args['border_width'] ?? '1' );
		$tension              = (string) ( $args['tension'] ?? '0.3' );
		$point_radius         = (string) ( $args['point_radius'] ?? '3' );
		$point_style          = (string) ( $args['point_style'] ?? 'circle' );
		$show_x_grid          = (string) ( $args['show_x_grid'] ?? 'on' );
		$show_y_grid          = (string) ( $args['show_y_grid'] ?? 'on' );
		$grid_color           = (string) ( $args['grid_color'] ?? 'rgba(0,0,0,0.1)' );
		$tick_color           = (string) ( $args['tick_color'] ?? '#666666' );
		$dataset_color        = (string) ( $args['dataset_color'] ?? '' );
		$dataset_border_color = (string) ( $args['dataset_border_color'] ?? '' );
		$dataset_hover_bg     = (string) ( $args['dataset_hover_background_color'] ?? '' );
		$dataset_hover_border = (string) ( $args['dataset_hover_border_color'] ?? '' );
		$dataset_hover_width  = (string) ( $args['dataset_hover_border_width'] ?? '' );
		$border_radius        = (string) ( $args['border_radius'] ?? '0' );
		$chart_responsive     = (string) ( $args['chart_responsive'] ?? 'on' );
		$maintain_aspect      = (string) ( $args['maintain_aspect_ratio'] ?? 'off' );

		$shared_options_args = array(
			'show_legend'                    => $show_legend,
			'show_tooltips'                  => $show_tooltips,
			'animate'                        => $animate,
			'legend_position'                => $legend_position,
			'legend_align'                   => $legend_align,
			'legend_reverse'                 => $legend_reverse,
			'tooltip_mode'                   => $tooltip_mode,
			'tooltip_intersect'              => $tooltip_intersect,
			'animation_duration'             => $animation_duration,
			'animation_easing'               => $animation_easing,
			'animation_delay'                => $animation_delay,
			'animation_loop'                 => $animation_loop,
			'interaction_mode'               => $interaction_mode,
			'cutout'                         => $cutout,
			'circumference'                  => $circumference,
			'rotation'                       => $rotation,
			'begin_at_zero'                  => $begin_at_zero,
			'stacked'                        => $stacked,
			'show_x_grid'                    => $show_x_grid,
			'show_y_grid'                    => $show_y_grid,
			'grid_color'                     => $grid_color,
			'tick_color'                     => $tick_color,
			'fill'                           => $fill,
			'border_width'                   => $border_width,
			'tension'                        => $tension,
			'point_radius'                   => $point_radius,
			'point_style'                    => $point_style,
			'dataset_color'                  => $dataset_color,
			'dataset_border_color'           => $dataset_border_color,
			'dataset_hover_background_color' => $dataset_hover_bg,
			'dataset_hover_border_color'     => $dataset_hover_border,
			'dataset_hover_border_width'     => $dataset_hover_width,
			'border_radius'                  => $border_radius,
			'chart_responsive'               => $chart_responsive,
			'maintain_aspect_ratio'          => $maintain_aspect,
			'locale'                         => self::resolve_chart_locale(),
		);

		if ( self::is_multi_dataset_mode( $category_labels, $datasets ) ) {
			return self::build_multi_dataset_chart_config(
				array_merge(
					$shared_options_args,
					array(
						'chart_type'      => $chart_type,
						'bar_orientation' => $bar_orientation,
						'category_labels' => $category_labels,
						'datasets'        => $datasets,
					)
				)
			);
		}

		$resolved   = self::resolve_chart_js_type( $chart_type, $bar_orientation );
		$type       = $resolved['type'];
		$index_axis = $resolved['index_axis'];
		$parsed     = self::parse_chart_points( $points );

		$is_arc_slice         = in_array( $type, array( 'pie', 'doughnut', 'polarArea' ), true );
		$is_pie_doughnut      = in_array( $type, array( 'pie', 'doughnut' ), true );
		$is_line              = 'line' === $type;
		$is_radar             = 'radar' === $type;
		$is_bar               = 'bar' === $type;
		$is_scatter           = 'scatter' === $type;
		$is_bubble            = 'bubble' === $type;
		$is_xy                = $is_scatter || $is_bubble;
		$is_point_style_type  = $is_line || $is_radar || $is_scatter || $is_bubble;
		$title_text           = trim( $title );
		$border_width_num     = max( 0.0, self::parse_numeric_attr( $border_width, 1.0 ) );
		$custom_border        = self::resolve_chart_color_paint( $dataset_border_color );
		$point_radius_num     = max( 0.0, self::parse_numeric_attr( $point_radius, $is_bubble ? 10.0 : 3.0 ) );
		$resolved_point_style = self::resolve_point_style( $point_style, 'circle' );
		$parent_hover         = array(
			'backgroundColor' => self::resolve_chart_color_paint( $dataset_hover_bg ),
			'borderColor'     => self::resolve_chart_color_paint( $dataset_hover_border ),
			'borderWidth'     => $dataset_hover_width,
		);

		$labels = array();
		$data   = array();
		$colors = array();

		foreach ( $parsed as $index => $point ) {
			$colors[] = self::resolve_point_color( (string) ( $point['color'] ?? '' ), (int) $index, $dataset_color );
			if ( $is_xy ) {
				$x = self::parse_point_number( (string) ( $point['label'] ?? '' ) );
				$y = isset( $point['value'] ) && is_finite( (float) $point['value'] )
					? (float) $point['value']
					: null;
				if ( null === $x || null === $y ) {
					continue;
				}
				if ( $is_bubble ) {
					$data[] = array(
						'x' => $x,
						'y' => $y,
						'r' => $point_radius_num,
					);
				} else {
					$data[] = array(
						'x' => $x,
						'y' => $y,
					);
				}
			} else {
				$labels[] = (string) ( $point['label'] ?? '' );
				$data[]   = (float) $point['value'];
			}
		}

		$dataset = array(
			'label'       => '' !== $title_text ? $title_text : 'Dataset',
			'data'        => $data,
			'borderWidth' => $border_width_num,
		);

		if ( $is_arc_slice ) {
			$dataset['backgroundColor'] = $colors;
			$dataset['borderColor']     = '' !== $custom_border
				? $custom_border
				: ( ( $is_pie_doughnut || 'polarArea' === $type ) ? '#ffffff' : $colors );
		} elseif ( $is_line || $is_radar ) {
			$primary                         = $colors[0] ?? self::DEFAULT_COLORS[0];
			$dataset['borderColor']          = '' !== $custom_border ? $custom_border : $primary;
			$dataset['backgroundColor']      = $primary;
			$dataset['fill']                 = self::resolve_dataset_fill( $chart_type, $fill, $is_radar );
			$dataset['tension']              = min( 1.0, max( 0.0, self::parse_numeric_attr( $tension, 0.3 ) ) );
			$dataset['pointRadius']          = $point_radius_num;
			$dataset['pointBackgroundColor'] = $colors;
			$dataset['pointBorderColor']     = $colors;
		} elseif ( $is_scatter ) {
			$primary                         = $colors[0] ?? self::DEFAULT_COLORS[0];
			$dataset['backgroundColor']      = $primary;
			$dataset['borderColor']          = '' !== $custom_border ? $custom_border : $primary;
			$dataset['pointRadius']          = $point_radius_num;
			$dataset['pointBackgroundColor'] = array() !== $colors ? $colors : $primary;
			$dataset['pointBorderColor']     = '' !== $custom_border ? $custom_border : $primary;
		} elseif ( $is_bubble ) {
			$primary                    = $colors[0] ?? self::DEFAULT_COLORS[0];
			$dataset['backgroundColor'] = $primary;
			$dataset['borderColor']     = '' !== $custom_border ? $custom_border : $primary;
		} else {
			$dataset['backgroundColor'] = $colors;
			$dataset['borderColor']     = '' !== $custom_border ? $custom_border : $colors;
		}

		if ( $is_point_style_type ) {
			$dataset['pointStyle'] = $resolved_point_style;
		}

		if ( $is_bar ) {
			$radius = self::resolve_series_border_radius( array(), $border_radius );
			if ( null !== $radius ) {
				$dataset['borderRadius'] = $radius;
			}
		}

		self::apply_dataset_hover_styles( $dataset, array(), $parent_hover );

		return array(
			'type'    => $type,
			'data'    => array(
				'labels'   => $labels,
				'datasets' => array( $dataset ),
			),
			'options' => self::build_chart_options(
				array_merge(
					$shared_options_args,
					array(
						'type'       => $type,
						'index_axis' => $index_axis,
					)
				)
			),
		);
	}

	/**
	 * Render module styles.
	 *
	 * @param array<string, mixed> $args Hook args.
	 * @return void
	 */
	public static function module_styles( array $args ): void {
		$args     = \DiviSupreme\Includes\DsmDiviBuilderCssScope::normalize_module_styles_args( $args );
		$attrs    = $args['attrs'] ?? array();
		$elements = $args['elements'];

		Style::add(
			array(
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => array(
					$elements->style(
						array(
							'attrName'   => 'module',
							'styleProps' => array(
								'disabledOn' => array(
									'disabledModuleVisibility' => $args['settings']['disabledModuleVisibility'] ?? null,
								),
							),
						)
					),
					TextStyle::style(
						array(
							'selector' => $args['orderClass'],
							'attr'     => $attrs['module']['advanced']['text'] ?? array(),
						)
					),
					CssStyle::style(
						array(
							'selector' => $args['orderClass'],
							'attr'     => $attrs['css'] ?? array(),
						)
					),
					$elements->style(
						array(
							'attrName' => 'title',
						)
					),
					$elements->style(
						array(
							'attrName' => 'legend',
						)
					),
					$elements->style(
						array(
							'attrName' => 'data_summary',
						)
					),
					$elements->style(
						array(
							'attrName' => 'data_summary_header',
						)
					),
					$elements->style(
						array(
							'attrName' => 'data_summary_rows',
						)
					),
					$elements->style(
						array(
							'attrName' => 'data_summary_row_even',
						)
					),
					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-chart-canvas-wrap",
							'attr'     => $attrs['chart_height']['innerContent'] ?? array(),
							'property' => 'height',
						)
					),
				),
			)
		);
	}

	/**
	 * Render module script data.
	 *
	 * @param array<string, mixed> $args Hook args.
	 * @return void
	 */
	public static function module_script_data( array $args ): void {
		$elements = $args['elements'];
		$attrs    = $args['attrs'] ?? array();
		$id       = $args['id'] ?? '';
		$name     = $args['name'] ?? '';
		$selector = $args['selector'] ?? '';
		$store    = $args['storeInstance'] ?? null;

		$elements->script_data(
			array(
				'attrName' => 'module',
			)
		);

		if ( ! is_array( $attrs ) ) {
			return;
		}

		// Responsive Series / Label / Value header copy (VB uses getAttrByMode; FE needs MultiView).
		$plain_text_resolver = static function ( $value ) {
			if ( is_array( $value ) ) {
				$value = $value['text'] ?? '';
			}

			if ( ! is_string( $value ) ) {
				return '';
			}

			return self::resolve_dynamic_plain( $value );
		};

		MultiViewScriptData::set(
			array(
				'id'            => $id,
				'name'          => $name,
				'selector'      => $selector,
				'storeInstance' => $store,
				'setContent'    => array(
					array(
						'selector'      => $selector . ' .dsm-chart-data-summary-th--series',
						'data'          => $attrs['data_summary_series_label']['innerContent'] ?? array(),
						'valueResolver' => $plain_text_resolver,
					),
					array(
						'selector'      => $selector . ' .dsm-chart-data-summary-th--label',
						'data'          => $attrs['data_summary_label_label']['innerContent'] ?? array(),
						'valueResolver' => $plain_text_resolver,
					),
					array(
						'selector'      => $selector . ' .dsm-chart-data-summary-th--value',
						'data'          => $attrs['data_summary_value_label']['innerContent'] ?? array(),
						'valueResolver' => $plain_text_resolver,
					),
				),
			)
		);
	}

	/**
	 * Render module classnames.
	 *
	 * @param array<string, mixed> $args Hook args.
	 * @return void
	 */
	public static function module_classnames( array $args ): void {
		$classnames_instance = $args['classnamesInstance'];
		$attrs               = $args['attrs'];

		$classnames_instance->add(
			ElementClassnames::classnames(
				array(
					'attrs' => $attrs['module']['decoration'] ?? array(),
				)
			)
		);
	}

	/**
	 * Render module HTML output.
	 *
	 * @param array<string, mixed> $attrs    Block attributes.
	 * @param string               $content  Inner content (child HTML — unused on FE).
	 * @param \WP_Block            $block    Block instance.
	 * @param mixed                $elements Module elements registry.
	 * @return string
	 */
	public static function render_callback( $attrs, $content, $block, $elements ): string {
		if ( ! is_array( $attrs ) ) {
			$attrs = array();
		}

		self::register_chart_scripts();
		wp_enqueue_script( 'dsm-chartjs-library' );
		wp_enqueue_script( 'dsm-chart' );
		self::localize_chart_settings();

		$chart_height = self::read_inner_attr( $attrs, 'chart_height', '320px' );
		$title_leaf   = $attrs['title']['innerContent']['desktop']['value'] ?? '';
		$title_raw    = self::normalize_inner_plain( $title_leaf );
		$title_text   = self::resolve_dynamic_plain( $title_raw );

		$inner_blocks = $block->parsed_block['innerBlocks'] ?? array();
		if ( ! is_array( $inner_blocks ) ) {
			$inner_blocks = array();
		}

		$category_raw    = $attrs['category_labels']['innerContent']['desktop']['value'] ?? array();
		$category_labels = self::extract_category_labels( $category_raw );
		$raw_points      = self::collect_points_from_inner_blocks( $inner_blocks );

		$show_legend        = self::read_inner_attr( $attrs, 'show_legend', 'on' );
		$show_data_summary  = self::read_inner_attr( $attrs, 'show_data_summary', 'off' );
		$data_summary_style = self::read_inner_attr( $attrs, 'data_summary_style', 'visible' );
		$legend_position    = self::read_inner_attr( $attrs, 'legend_position', 'top' );
		$legend_align       = self::read_inner_attr( $attrs, 'legend_align', 'center' );

		$data_source        = self::read_inner_attr( $attrs, 'data_source', 'manual' );
		$data_source_url    = trim( self::read_inner_attr( $attrs, 'data_source_url', '' ) );
		$data_source_live   = self::read_inner_attr( $attrs, 'data_source_live', 'off' );
		$refresh_interval   = self::normalize_live_interval_minutes(
			self::read_inner_attr( $attrs, 'data_source_refresh_interval', '15' )
		);
		$is_remote_source   = in_array( $data_source, array( 'google_sheets', 'csv_url' ), true );
		$live_enabled       = $is_remote_source && self::is_on( $data_source_live, 'off' ) && '' !== $data_source_url;
		$live_url_validated = '';
		if ( $live_enabled ) {
			$validated_live = DsmRemoteUrlGuard::validate_url( $data_source_url );
			if ( ! is_wp_error( $validated_live ) ) {
				$live_url_validated = $validated_live;
			} else {
				$live_enabled = false;
			}
		}

		$config = self::build_chart_js_config(
			self::build_chart_config_args_for_breakpoint(
				$attrs,
				$inner_blocks,
				$category_labels,
				$raw_points,
				$title_text,
				'desktop'
			)
		);

		$config_json = wp_json_encode( $config );
		if ( false === $config_json ) {
			$config_json = '{}';
		}

		// Canvas colors cannot use CSS media queries — emit resolved style
		// snapshots so FE JS can swap tablet/phone colors on resize.
		$style_breakpoints      = self::build_responsive_style_breakpoints(
			$attrs,
			$inner_blocks,
			$category_labels,
			$raw_points,
			$title_text,
			$config
		);
		$style_breakpoints_attr = '';
		if ( isset( $style_breakpoints['tablet'] ) || isset( $style_breakpoints['phone'] ) ) {
			$style_breakpoints_json = wp_json_encode( $style_breakpoints );
			if ( false !== $style_breakpoints_json ) {
				$style_breakpoints_attr = ' data-dsm-chart-style-breakpoints="' . esc_attr( $style_breakpoints_json ) . '"';
			}
		}

		$children_ids = array();
		foreach ( $inner_blocks as $inner_block ) {
			if ( is_array( $inner_block ) && ! empty( $inner_block['id'] ) ) {
				$children_ids[] = $inner_block['id'];
			}
		}

		$raw_dataset_count = self::count_chart_item_inner_blocks( $inner_blocks );
		$cap_notice_html   = self::render_dataset_cap_notice( $raw_dataset_count );

		$has_data     = self::chart_config_has_data( $config );
		$canvas_inner = '';
		if ( ! $has_data ) {
			$canvas_inner = sprintf(
				'<p class="dsm-chart-empty">%s</p>',
				esc_html__(
					'Add Datasets with Data Points (label + value) to display a chart.',
					'dsm-supreme-modules-pro-for-divi'
				)
			);
		} else {
			$aria_label   = '' !== trim( $title_text ) ? $title_text : __( 'Chart', 'dsm-supreme-modules-pro-for-divi' );
			$canvas_inner = '<canvas class="dsm-chart-canvas" role="img" aria-label="' . esc_attr( $aria_label ) . '"></canvas>';
		}

		$title_html = '';
		if ( '' !== trim( $title_raw ) ) {
			$title_html = $elements->render(
				array(
					'attrName' => 'title',
				)
			);
		}

		$allowed_positions = array( 'top', 'bottom', 'left', 'right' );
		$allowed_align     = array( 'start', 'center', 'end' );
		$legend_pos_attr   = in_array( $legend_position, $allowed_positions, true ) ? $legend_position : 'top';
		$legend_align_attr = in_array( $legend_align, $allowed_align, true ) ? $legend_align : 'center';
		$show_legend_attr  = self::is_on( $show_legend, 'on' ) ? 'on' : 'off';

		$legend_html = sprintf(
			'<div class="dsm-chart-legend"%1$s aria-label="%2$s"></div>',
			'on' === $show_legend_attr ? '' : ' hidden',
			esc_attr__( 'Chart legend', 'dsm-supreme-modules-pro-for-divi' )
		);

		$summary_html = '';
		if ( self::is_on( $show_data_summary, 'off' ) && $has_data ) {
			$summary_style = 'sr_only' === $data_summary_style ? 'sr_only' : 'visible';
			$summary_html  = self::render_data_summary_html(
				$config,
				$summary_style,
				array(
					'series' => self::resolve_dynamic_plain(
						self::read_inner_attr(
							$attrs,
							'data_summary_series_label',
							__( 'Series', 'dsm-supreme-modules-pro-for-divi' )
						)
					),
					'label'  => self::resolve_dynamic_plain(
						self::read_inner_attr(
							$attrs,
							'data_summary_label_label',
							__( 'Label', 'dsm-supreme-modules-pro-for-divi' )
						)
					),
					'value'  => self::resolve_dynamic_plain(
						self::read_inner_attr(
							$attrs,
							'data_summary_value_label',
							__( 'Value', 'dsm-supreme-modules-pro-for-divi' )
						)
					),
				)
			);
		}

		$live_attrs = '';
		if ( $live_enabled && '' !== $live_url_validated ) {
			$live_attrs = sprintf(
				' data-dsm-chart-live="on" data-dsm-chart-remote-url="%1$s" data-dsm-chart-refresh-minutes="%2$s"',
				esc_attr( $live_url_validated ),
				esc_attr( (string) $refresh_interval )
			);
		}

		$chart_markup = sprintf(
			'%1$s%12$s<div class="dsm-chart" data-dsm-chart-config="%2$s"%3$s%4$s data-dsm-show-legend="%5$s" data-dsm-legend-position="%6$s" data-dsm-legend-align="%7$s">%8$s<div class="dsm-chart-canvas-wrap" style="height:%9$s">%10$s</div></div>%11$s',
			$title_html,
			esc_attr( $config_json ),
			$style_breakpoints_attr,
			$live_attrs,
			esc_attr( $show_legend_attr ),
			esc_attr( $legend_pos_attr ),
			esc_attr( $legend_align_attr ),
			$legend_html,
			esc_attr( $chart_height ),
			$canvas_inner,
			$summary_html,
			$cap_notice_html
		);

		$module_inner = HTMLUtility::render(
			array(
				'tag'               => 'div',
				'attributes'        => array(
					'class' => 'et_pb_module_inner dsm-chart-inner',
				),
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $chart_markup,
			)
		);

		$module_elements           = $elements->style_components(
			array(
				'attrName' => 'module',
			)
		);
		$module_container_children = $module_elements . $module_inner;

		return Module::render(
			array(
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],
				'attrs'               => $attrs,
				'elements'            => $elements,
				'id'                  => $block->parsed_block['id'],
				'moduleClassName'     => 'dsm_chart',
				'name'                => $block->block_type->name,
				'classnamesFunction'  => array( self::class, 'module_classnames' ),
				'moduleCategory'      => $block->block_type->category,
				'stylesComponent'     => array( self::class, 'module_styles' ),
				'scriptDataComponent' => array( self::class, 'module_script_data' ),
				'children'            => $module_container_children,
				'childrenIds'         => $children_ids,
			)
		);
	}
}
