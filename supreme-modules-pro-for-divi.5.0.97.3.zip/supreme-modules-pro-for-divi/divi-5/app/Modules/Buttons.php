<?php
/**
 * Button Module.
 *
 * @package DiviSupreme.
 */

declare(strict_types=1);

namespace DiviSupreme\Modules;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}


use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\Module\Options\Element\ElementClassnames;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use ET\Builder\Packages\Module\Options\Text\TextStyle;
use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use DiviSupreme\Includes\Divi5Conversion\ConversionAttrs;
use ET\Builder\Packages\Module\Options\Text\TextClassnames;
use ET\Builder\Packages\Module\Options\Attributes\AttributeUtils;
use ET\Builder\Packages\Module\Layout\Components\MultiView\MultiViewScriptData;

/**
 * Class that handles "Button Module" module.
 */
class Buttons implements DependencyInterface {


	/**
	 * Register module.
	 * `DependencyInterface` interface ensures class method name `load()` is executed for initialization.
	 */
	public function load() {
		add_action( 'init', array( self::class, 'register_module' ) );
	}

	/**
	 * Initilises the module.
	 *
	 * @return void
	 */
	public static function dsm_initialise() {
		add_action(
			'divi_module_library_modules_dependency_tree',
			function ( $dependency_tree ) {
				$dependency_tree->add_dependency( new self() );
			}
		);
	}

	/**
	 * Register module.
	 */
	public static function register_module() {

		$module_json_path = DSM_DIR_PATH . 'divi-5/public/packages/module-library/buttons';

		ModuleRegistration::register_module(
			$module_json_path,
			array(
				'render_callback' => array( self::class, 'render_callback' ),
			)
		);
	}

	/**
	 * Whether a toggle innerContent value is on.
	 *
	 * @param mixed $value Raw toggle value.
	 * @return bool
	 */
	private static function is_truthy_toggle( $value ): bool {
		if ( true === $value || 1 === $value || '1' === $value ) {
			return true;
		}

		return 'on' === $value;
	}

	/**
	 * Read responsive innerContent scalar with desktop fallback.
	 *
	 * @param array  $attrs      Module attrs.
	 * @param string $attr_name  Attribute key.
	 * @param string $breakpoint Style pass breakpoint.
	 * @return mixed
	 */
	private static function resolve_buttons_group_attr_by_mode( array $attrs, string $attr_name, string $breakpoint = 'desktop' ) {
		if ( ! isset( $attrs[ $attr_name ]['innerContent'] ) || ! is_array( $attrs[ $attr_name ]['innerContent'] ) ) {
			return null;
		}

		$inner = $attrs[ $attr_name ]['innerContent'];

		if ( isset( $inner[ $breakpoint ]['value'] ) && '' !== $inner[ $breakpoint ]['value'] && null !== $inner[ $breakpoint ]['value'] ) {
			return $inner[ $breakpoint ]['value'];
		}

		return $inner['desktop']['value'] ?? null;
	}

	/**
	 * Normalize button group gap to a CSS length.
	 *
	 * @param mixed $raw Raw gap value.
	 * @return string
	 */
	private static function normalize_button_group_gap_value( $raw ): string {
		if ( null === $raw || '' === $raw ) {
			return '20px';
		}

		if ( is_numeric( $raw ) ) {
			return (string) $raw . 'px';
		}

		if ( is_array( $raw ) && isset( $raw['value'] ) ) {
			return self::normalize_button_group_gap_value( $raw['value'] );
		}

		$trimmed = trim( (string) $raw );

		if ( '' === $trimmed ) {
			return '20px';
		}

		if ( preg_match( '/^\d+$/', $trimmed ) ) {
			return $trimmed . 'px';
		}

		return $trimmed;
	}

	/**
	 * Map button alignment slug to flex justify/align value.
	 *
	 * @param string $align Alignment slug.
	 * @return string
	 */
	private static function map_button_alignment_to_flex( string $align ): string {
		if ( 'center' === $align ) {
			return 'center';
		}

		if ( 'right' === $align ) {
			return 'flex-end';
		}

		return 'flex-start';
	}

	/**
	 * Whether buttons are stacked at the current style breakpoint.
	 *
	 * @param array  $attrs      Module attrs.
	 * @param string $breakpoint Style pass breakpoint.
	 * @return bool
	 */
	private static function is_buttons_group_stacked( array $attrs, string $breakpoint ): bool {
		return self::is_truthy_toggle(
			self::resolve_buttons_group_attr_by_mode( $attrs, 'stack_buttons', $breakpoint )
		);
	}

	/**
	 * Whether stacked buttons should stretch full width at the current breakpoint.
	 *
	 * @param array  $attrs      Module attrs.
	 * @param string $breakpoint Style pass breakpoint.
	 * @return bool
	 */
	private static function is_buttons_group_fullwidth( array $attrs, string $breakpoint ): bool {
		return self::is_buttons_group_stacked( $attrs, $breakpoint )
			&& self::is_truthy_toggle(
				self::resolve_buttons_group_attr_by_mode( $attrs, 'fullwidth_buttons_on_mobile', $breakpoint )
			);
	}

	/**
	 * Flex layout for `.et_pb_button_module_wrappers`.
	 *
	 * @param array $params Style callback params.
	 * @param array $attrs  Module attrs.
	 * @return string
	 */
	public static function buttons_group_layout_declaration( array $params, array $attrs ): string {
		$breakpoint = isset( $params['breakpoint'] ) && is_string( $params['breakpoint'] ) && '' !== $params['breakpoint']
			? $params['breakpoint']
			: 'desktop';

		$gap       = self::normalize_button_group_gap_value(
			self::resolve_buttons_group_attr_by_mode( $attrs, 'button_group_gap', $breakpoint )
		);
		$stacked   = self::is_buttons_group_stacked( $attrs, $breakpoint );
		$fullwidth = self::is_buttons_group_fullwidth( $attrs, $breakpoint );
		$alignment = self::map_button_alignment_to_flex(
			(string) ( self::resolve_buttons_group_attr_by_mode( $attrs, 'button_alignment', $breakpoint ) ?? 'left' )
		);

		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
				'important'  => array(
					'display'         => true,
					'flex-wrap'       => true,
					'gap'             => true,
					'flex-direction'  => true,
					'justify-content' => true,
					'align-items'     => true,
				),
			)
		);

		$style_declarations->add( 'display', 'flex' );
		$style_declarations->add( 'flex-wrap', 'wrap' );
		$style_declarations->add( 'gap', $gap );

		if ( $stacked ) {
			$style_declarations->add( 'flex-direction', 'column' );
			$style_declarations->add( 'align-items', $fullwidth ? 'stretch' : $alignment );
		} else {
			$style_declarations->add( 'flex-direction', 'row' );
			$style_declarations->add( 'justify-content', $alignment );
			$style_declarations->add( 'align-items', 'center' );
		}

		return $style_declarations->value();
	}

	/**
	 * Full-width child buttons when stacked + fullwidth toggle is on.
	 *
	 * @param array $params Style callback params.
	 * @param array $attrs  Module attrs.
	 * @return string
	 */
	public static function buttons_group_fullwidth_declaration( array $params, array $attrs ): string {
		$breakpoint = isset( $params['breakpoint'] ) && is_string( $params['breakpoint'] ) && '' !== $params['breakpoint']
			? $params['breakpoint']
			: 'desktop';

		if ( ! self::is_buttons_group_fullwidth( $attrs, $breakpoint ) ) {
			return '';
		}

		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
				'important'  => array(
					'width'     => true,
					'max-width' => true,
					'display'   => true,
				),
			)
		);

		$style_declarations->add( 'width', '100%' );
		$style_declarations->add( 'max-width', '100%' );
		$style_declarations->add( 'display', 'block' );

		return $style_declarations->value();
	}

	/**
	 * Render module style.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_styles( $args ) {
		$args     = \DiviSupreme\Includes\DsmDiviBuilderCssScope::normalize_module_styles_args( $args );
		$attrs    = $args['attrs'] ?? array();
		$elements = $args['elements'];

		$button_one_tooltip_placement = $attrs['button_one_tooltip_placement']['innerContent']['desktop']['value'] ?? '';
		$button_two_tooltip_placement = $attrs['button_two_tooltip_placement']['innerContent']['desktop']['value'] ?? '';

		Style::add(
			array(
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => array(
					// Module.
					$elements->style(
						array(
							'attrName'   => 'module',
							'styleProps' => array(
								'disabledOn' => array(
									'disabledModuleVisibility' => $args['settings']['disabledModuleVisibility'] ?? null,
								),
							),
						)
					),

					CssStyle::style(
						array(
							'selector' => $args['orderClass'],
							'attr'     => $attrs['css'] ?? array(),
						)
					),

					$elements->style(
						array(
							'attrName' => 'separator_text',
						)
					),

					$elements->style(
						array(
							'attrName' => 'tooltip_one_font',
						)
					),

					$elements->style(
						array(
							'attrName' => 'tooltip_two_font',
						)
					),

					$elements->style(
						array(
							'attrName' => 'button_one',
						)
					),

					$elements->style(
						array(
							'attrName' => 'button_two',
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .et_pb_button_module_wrappers",
							'attr'                => $attrs['button_alignment']['innerContent'] ?? array(),
							'declarationFunction' => static function ( $params ) use ( $attrs ) {
								return self::buttons_group_layout_declaration( $params, $attrs );
							},
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .et_pb_button_module_wrappers",
							'attr'                => $attrs['button_group_gap']['innerContent'] ?? array(),
							'declarationFunction' => static function ( $params ) use ( $attrs ) {
								return self::buttons_group_layout_declaration( $params, $attrs );
							},
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .et_pb_button_module_wrappers",
							'attr'                => $attrs['stack_buttons']['innerContent'] ?? array(),
							'declarationFunction' => static function ( $params ) use ( $attrs ) {
								return self::buttons_group_layout_declaration( $params, $attrs );
							},
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .et_pb_button_module_wrappers > a.et_pb_button, {$args['orderClass']} .et_pb_button_module_wrappers > .dsm_button_one, {$args['orderClass']} .et_pb_button_module_wrappers > .dsm_button_two",
							'attr'                => $attrs['fullwidth_buttons_on_mobile']['innerContent'] ?? array(),
							'declarationFunction' => static function ( $params ) use ( $attrs ) {
								return self::buttons_group_fullwidth_declaration( $params, $attrs );
							},
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .et_pb_button_module_wrappers > a.et_pb_button, {$args['orderClass']} .et_pb_button_module_wrappers > .dsm_button_one, {$args['orderClass']} .et_pb_button_module_wrappers > .dsm_button_two",
							'attr'                => $attrs['stack_buttons']['innerContent'] ?? array(),
							'declarationFunction' => static function ( $params ) use ( $attrs ) {
								return self::buttons_group_fullwidth_declaration( $params, $attrs );
							},
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-button-separator-text",
							'attr'     => $attrs['separator_gap']['innerContent'] ?? array(),
							'property' => 'margin-left',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-button-separator-text",
							'attr'     => $attrs['separator_gap']['innerContent'] ?? array(),
							'property' => 'margin-right',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm_button_one.dsm-tooltip[data-dsm-tooltip]:after",
							'attr'     => $attrs['button_one_tooltip_bg_color']['innerContent'] ?? array(),
							'property' => 'background-color',
						)
					),

					'top' === $button_one_tooltip_placement ?

						CommonStyle::style(
							array(
								'selector' => "{$args['orderClass']} .dsm_button_one.dsm-tooltip:before",
								'attr'     => $attrs['button_one_tooltip_bg_color']['innerContent'] ?? array(),
								'property' => 'border-top-color',
							)
						) : '',

					'bottom' === $button_one_tooltip_placement ?

						CommonStyle::style(
							array(
								'selector' => "{$args['orderClass']} .dsm_button_one.dsm-tooltip:before",
								'attr'     => $attrs['button_one_tooltip_bg_color']['innerContent'] ?? array(),
								'property' => 'border-bottom-color',
							)
						) : '',

					'left' === $button_one_tooltip_placement ?

						CommonStyle::style(
							array(
								'selector' => "{$args['orderClass']} .dsm_button_one.dsm-tooltip:before",
								'attr'     => $attrs['button_one_tooltip_bg_color']['innerContent'] ?? array(),
								'property' => 'border-left-color',
							)
						) : '',

					'right' === $button_one_tooltip_placement ?

						CommonStyle::style(
							array(
								'selector' => "{$args['orderClass']} .dsm_button_one.dsm-tooltip:before",
								'attr'     => $attrs['button_one_tooltip_bg_color']['innerContent'] ?? array(),
								'property' => 'border-right-color',
							)
						) : '',

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm_button_two.dsm-tooltip[data-dsm-tooltip]:after",
							'attr'     => $attrs['button_two_tooltip_bg_color']['innerContent'] ?? array(),
							'property' => 'background-color',
						)
					),

					'top' === $button_two_tooltip_placement ?

						CommonStyle::style(
							array(
								'selector' => "{$args['orderClass']} .dsm_button_two.dsm-tooltip:before",
								'attr'     => $attrs['button_two_tooltip_bg_color']['innerContent'] ?? array(),
								'property' => 'border-top-color',
							)
						) : '',

					'bottom' === $button_two_tooltip_placement ?

						CommonStyle::style(
							array(
								'selector' => "{$args['orderClass']} .dsm_button_two.dsm-tooltip:before",
								'attr'     => $attrs['button_two_tooltip_bg_color']['innerContent'] ?? array(),
								'property' => 'border-bottom-color',
							)
						) : '',

					'left' === $button_two_tooltip_placement ?

						CommonStyle::style(
							array(
								'selector' => "{$args['orderClass']} .dsm_button_two.dsm-tooltip:before",
								'attr'     => $attrs['button_two_tooltip_bg_color']['innerContent'] ?? array(),
								'property' => 'border-left-color',
							)
						) : '',

					'right' === $button_two_tooltip_placement ?

						CommonStyle::style(
							array(
								'selector' => "{$args['orderClass']} .dsm_button_two.dsm-tooltip:before",
								'attr'     => $attrs['button_two_tooltip_bg_color']['innerContent'] ?? array(),
								'property' => 'border-right-color',
							)
						) : '',

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']}.dsm-lightbox-button-one .mfp-close",
							'attr'     => $attrs['button_one_lightbox_close_color']['innerContent'] ?? array(),
							'property' => 'color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']}.dsm-lightbox-button-one .mfp-content",
							'attr'     => $attrs['button_one_lightbox_max_width']['innerContent'] ?? array(),
							'property' => 'width',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']}.dsm-lightbox-button-two .mfp-close",
							'attr'     => $attrs['button_two_lightbox_close_color']['innerContent'] ?? array(),
							'property' => 'color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']}.dsm-lightbox-button-two .mfp-content",
							'attr'     => $attrs['button_two_lightbox_max_width']['innerContent'] ?? array(),
							'property' => 'width',
						)
					),
				),
			)
		);
	}

	/**
	 * Render module script data.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_script_data( $args ) {
		$elements = $args['elements'];
		$attrs    = $args['attrs'] ?? array();
		$id       = $args['id'] ?? '';
		$name     = $args['name'] ?? '';
		$selector = $args['selector'] ?? '';
		$store    = $args['storeInstance'] ?? null;

		// Element Script Data Options.
		$elements->script_data(
			array(
				'attrName' => 'module',
			)
		);

		// Responsive button / separator copy (D4 used ET_Builder_Module_Multi_View::render_element).
		$plain_text_resolver = static function ( $value ) {
			if ( is_array( $value ) ) {
				$value = $value['text'] ?? '';
			}

			return is_string( $value ) ? $value : '';
		};

		MultiViewScriptData::set(
			array(
				'id'            => $id,
				'name'          => $name,
				'selector'      => $selector,
				'storeInstance' => $store,
				'setContent'    => array(
					array(
						// Compound selector (no space): ET multi-view filters out descendant
						// selectors when an et_pb_*_* order class sits between module and target.
						'selector'      => $selector . '.et_pb_button_one',
						'data'          => $attrs['button_one_text']['innerContent'] ?? array(),
						'valueResolver' => $plain_text_resolver,
					),
					array(
						'selector'      => $selector . '.et_pb_button_two',
						'data'          => $attrs['button_two_text']['innerContent'] ?? array(),
						'valueResolver' => $plain_text_resolver,
					),
					array(
						'selector'      => $selector . '.dsm-button-separator-text',
						'data'          => $attrs['separator_text']['innerContent'] ?? array(),
						'valueResolver' => $plain_text_resolver,
					),
				),
			)
		);
	}

	/**
	 * Render module classnames.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_classnames( $args ) {
		$classnames_instance = $args['classnamesInstance'];
		$attrs               = $args['attrs'];

		// Module.
		$classnames_instance->add(
			ElementClassnames::classnames(
				array(
					'attrs' => $attrs['module']['decoration'] ?? array(),
				)
			)
		);

		// D4 parity: Text → Text Color (theme styles `et_pb_button` border / contrast via `et_pb_bg_layout_*`).
		$classnames_instance->add(
			self::get_text_background_layout_classes( $attrs ),
			true
		);
	}

	/**
	 * Decoration icon.settings array for Buttons (Loop “no results” payloads may omit nested keys).
	 *
	 * @param array  $attrs     Module attrs.
	 * @param string $btn_group `button_one` or `button_two`.
	 * @return array<string, mixed>
	 */
	private static function get_supreme_button_font_icon_settings( array $attrs, string $btn_group ): array {
		if ( '' === $btn_group || ! isset( $attrs[ $btn_group ] ) || ! is_array( $attrs[ $btn_group ] ) ) {
			return array();
		}

		if ( ! isset( $attrs[ $btn_group ]['decoration']['button']['desktop']['value']['icon'] ) ) {
			return array();
		}

		$icon = $attrs[ $btn_group ]['decoration']['button']['desktop']['value']['icon'];
		if ( ! is_array( $icon ) ) {
			return array();
		}

		$settings = $icon['settings'] ?? null;

		return is_array( $settings ) ? $settings : array();
	}

	/**
	 * Render module HTML output.
	 *
	 * @param array     $attrs - Modules Attributes.
	 * @param string    $content - Content.
	 * @param \WP_Block $block - Block.
	 * @param mixed     $elements - Elements.
	 */
	public static function render_callback( $attrs, $content, $block, $elements ) {

		$attrs = is_array( $attrs ) ? $attrs : array();

		$button_one_text_value           = self::inner_content_desktop_plain_text( $attrs, 'button_one_text' );
		$button_two_text_value           = self::inner_content_desktop_plain_text( $attrs, 'button_two_text' );
		$separator_text_value            = self::inner_content_desktop_plain_text( $attrs, 'separator_text' );
		$has_button_one_text             = self::inner_content_has_text_any_breakpoint( $attrs, 'button_one_text' );
		$has_button_two_text             = self::inner_content_has_text_any_breakpoint( $attrs, 'button_two_text' );
		$has_separator_text              = self::inner_content_has_text_any_breakpoint( $attrs, 'separator_text' );
		$button_one_link_type            = $attrs['button_one_url_type']['innerContent']['desktop']['value'] ?? '';
		$button_one_url                  = $attrs['button_one_url']['innerContent']['desktop']['value'] ?? '';
		$button_one_url_new_window       = $attrs['button_one_url_new_window']['innerContent']['desktop']['value'] ?? '';
		$button_one_email_address        = $attrs['button_one_email_address']['innerContent']['desktop']['value'] ?? '';
		$button_one_email_cc             = $attrs['button_one_email_cc']['innerContent']['desktop']['value'] ?? '';
		$button_one_email_bcc            = $attrs['button_one_email_bcc']['innerContent']['desktop']['value'] ?? '';
		$button_one_email_subject        = $attrs['button_one_email_subject']['innerContent']['desktop']['value'] ?? '';
		$button_one_email_msg            = $attrs['button_one_email_msg']['innerContent']['desktop']['value'] ?? '';
		$button_one_phone_number         = $attrs['button_one_phone_number']['innerContent']['desktop']['value'] ?? '';
		$button_one_sms_number           = $attrs['button_one_sms_number']['innerContent']['desktop']['value'] ?? '';
		$button_one_sms_msg              = $attrs['button_one_sms_body_text']['innerContent']['desktop']['value'] ?? '';
		$button_one_fb_messenger         = $attrs['button_one_fb_messenger']['innerContent']['desktop']['value'] ?? '';
		$button_one_skype                = $attrs['button_one_skype']['innerContent']['desktop']['value'] ?? '';
		$button_one_skype_action_type    = $attrs['button_one_skype_action_type']['innerContent']['desktop']['value'] ?? '';
		$button_one_whatsapp_number      = $attrs['button_one_whatsapp_number']['innerContent']['desktop']['value'] ?? '';
		$button_one_whatsapp_msg         = $attrs['button_one_whatsapp_msg']['innerContent']['desktop']['value'] ?? '';
		$button_one_telegram             = $attrs['button_one_telegram']['innerContent']['desktop']['value'] ?? '';
		$button_one_telegram_msg         = $attrs['button_one_telegram_msg']['innerContent']['desktop']['value'] ?? '';
		$button_one_download_file        = $attrs['button_one_download_file']['innerContent']['desktop']['value'] ?? '';
		$button_two_link_type            = $attrs['button_two_url_type']['innerContent']['desktop']['value'] ?? '';
		$button_two_url                  = $attrs['button_two_url']['innerContent']['desktop']['value'] ?? '';
		$button_two_url_new_window       = $attrs['button_two_url_new_window']['innerContent']['desktop']['value'] ?? '';
		$button_two_email_address        = $attrs['button_two_email_address']['innerContent']['desktop']['value'] ?? '';
		$button_two_email_cc             = $attrs['button_two_email_cc']['innerContent']['desktop']['value'] ?? '';
		$button_two_email_bcc            = $attrs['button_two_email_bcc']['innerContent']['desktop']['value'] ?? '';
		$button_two_email_subject        = $attrs['button_two_email_subject']['innerContent']['desktop']['value'] ?? '';
		$button_two_email_msg            = $attrs['button_two_email_msg']['innerContent']['desktop']['value'] ?? '';
		$button_two_phone_number         = $attrs['button_two_phone_number']['innerContent']['desktop']['value'] ?? '';
		$button_two_sms_number           = $attrs['button_two_sms_number']['innerContent']['desktop']['value'] ?? '';
		$button_two_sms_msg              = $attrs['button_two_sms_body_text']['innerContent']['desktop']['value'] ?? '';
		$button_two_fb_messenger         = $attrs['button_two_fb_messenger']['innerContent']['desktop']['value'] ?? '';
		$button_two_skype                = $attrs['button_two_skype']['innerContent']['desktop']['value'] ?? '';
		$button_two_skype_action_type    = $attrs['button_two_skype_action_type']['innerContent']['desktop']['value'] ?? '';
		$button_two_whatsapp_number      = $attrs['button_two_whatsapp_number']['innerContent']['desktop']['value'] ?? '';
		$button_two_whatsapp_msg         = $attrs['button_two_whatsapp_msg']['innerContent']['desktop']['value'] ?? '';
		$button_two_telegram             = $attrs['button_two_telegram']['innerContent']['desktop']['value'] ?? '';
		$button_two_telegram_msg         = $attrs['button_two_telegram_msg']['innerContent']['desktop']['value'] ?? '';
		$button_two_download_file        = $attrs['button_two_download_file']['innerContent']['desktop']['value'] ?? '';
		$button_one_hover_animation      = $attrs['button_one_hover_animation']['innerContent']['desktop']['value'] ?? '';
		$button_two_hover_animation      = $attrs['button_two_hover_animation']['innerContent']['desktop']['value'] ?? '';
		$button_one_use_tooltip          = $attrs['button_one_tooltip']['innerContent']['desktop']['value'] ?? '';
		$button_one_tooltip_animation    = $attrs['button_one_tooltip_animation']['innerContent']['desktop']['value'] ?? '';
		$button_one_tooltip_content      = $attrs['button_one_tooltip_content']['innerContent']['desktop']['value'] ?? '';
		$button_one_tooltip_arrow        = $attrs['button_one_tooltip_arrow']['innerContent']['desktop']['value'] ?? '';
		$button_one_tooltip_size         = $attrs['button_one_tooltip_size']['innerContent']['desktop']['value'] ?? '';
		$button_one_tooltip_placement    = $attrs['button_one_tooltip_placement']['innerContent']['desktop']['value'] ?? '';
		$button_two_use_tooltip          = $attrs['button_two_tooltip']['innerContent']['desktop']['value'] ?? '';
		$button_two_tooltip_animation    = $attrs['button_two_tooltip_animation']['innerContent']['desktop']['value'] ?? '';
		$button_two_tooltip_content      = $attrs['button_two_tooltip_content']['innerContent']['desktop']['value'] ?? '';
		$button_two_tooltip_arrow        = $attrs['button_two_tooltip_arrow']['innerContent']['desktop']['value'] ?? '';
		$button_two_tooltip_size         = $attrs['button_two_tooltip_size']['innerContent']['desktop']['value'] ?? '';
		$button_two_tooltip_placement    = $attrs['button_two_tooltip_placement']['innerContent']['desktop']['value'] ?? '';
		$button_one_icon_hover_animation = $attrs['button_one_icon_hover_animation']['innerContent']['desktop']['value'] ?? '';
		$button_two_icon_hover_animation = $attrs['button_two_icon_hover_animation']['innerContent']['desktop']['value'] ?? '';
		$button_one_image_popup          = $attrs['button_one_image_popup']['innerContent']['desktop']['value'] ?? '';
		$button_one_popup_src            = self::normalize_upload_inner_value_to_src( $attrs['button_one_image_src']['innerContent']['desktop']['value'] ?? null );
		$button_two_image_popup          = $attrs['button_two_image_popup']['innerContent']['desktop']['value'] ?? '';
		$button_two_popup_src            = self::normalize_upload_inner_value_to_src( $attrs['button_two_image_src']['innerContent']['desktop']['value'] ?? null );
		$button_one_video_popup          = $attrs['button_one_video_popup']['innerContent']['desktop']['value'] ?? '';
		$button_two_video_popup          = $attrs['button_two_video_popup']['innerContent']['desktop']['value'] ?? '';

		$needs_magnific_buttons = (
			'on' === $button_one_image_popup
			|| 'on' === $button_two_image_popup
			|| 'on' === $button_one_video_popup
			|| 'on' === $button_two_video_popup
		);
		if ( $needs_magnific_buttons ) {
			if ( function_exists( 'dsm_ensure_registered_script_dependency' ) && function_exists( 'dsm_get_active_magnific_popup_script_handle' ) ) {
				dsm_ensure_registered_script_dependency(
					'dsm-buttons',
					dsm_get_active_magnific_popup_script_handle()
				);
			}
			if ( function_exists( 'dsm_enqueue_magnific_popup_assets' ) ) {
				dsm_enqueue_magnific_popup_assets();
			}
		}

		$button_one_icon = Utils::process_font_icon( self::get_supreme_button_font_icon_settings( $attrs, 'button_one' ) ) ?? '';
		$button_two_icon = Utils::process_font_icon( self::get_supreme_button_font_icon_settings( $attrs, 'button_two' ) ) ?? '';
		wp_enqueue_script( 'dsm-tippy' );
		wp_enqueue_script( 'dsm-buttons' );

		$link_one_url = '';
		switch ( $button_one_link_type ) {
			case 'url':
				$link_one_url = sprintf( '%1$s', $button_one_url );
				break;
			case 'email':
				$link_one_url = sprintf(
					'mailto:%1$s?%2$s%3$s%4$s%5$s',
					'' !== $button_one_email_address ? esc_attr( $button_one_email_address ) : '',
					'' !== $button_one_email_cc ? '&cc=' . $button_one_email_cc : '',
					'' !== $button_one_email_bcc ? esc_attr( "&bcc=$button_one_email_bcc" ) : '',
					'' !== $button_one_email_subject ? esc_attr( '&subject=' . $button_one_email_subject ) : '',
					'' !== $button_one_email_msg ? esc_attr( '&body=' . $button_one_email_msg ) : ''
				);
				break;
			case 'phone':
				$link_one_url = sprintf( 'tel:%1$s', $button_one_phone_number );
				break;
			case 'sms':
				$link_one_url = sprintf(
					'sms:%1$s%2$s',
					'' !== $button_one_sms_number ? esc_attr( $button_one_sms_number ) : '',
					'' !== $button_one_sms_msg ? '?&body=' . rawurlencode( $button_one_sms_msg ) : ''
				);
				break;

			case 'fb_messenger':
				$link_one_url = sprintf(
					'https://m.me/%1$s',
					'' !== $button_one_fb_messenger ? esc_attr( $button_one_fb_messenger ) : ''
				);
				break;

			case 'skype':
				$link_one_url = sprintf(
					'skype:%1$s%2$s',
					'' !== $button_one_skype ? esc_attr( $button_one_skype ) : '',
					esc_attr( '?' . $button_one_skype_action_type )
				);
				break;

			case 'whatsapp':
				$link_one_url = sprintf(
					'https://wa.me/%1$s%2$s',
					'' !== $button_one_whatsapp_number ? esc_attr( $button_one_whatsapp_number ) : '',
					'' !== $button_one_whatsapp_msg ? esc_attr( '?text=' . $button_one_whatsapp_msg ) : ''
				);
				break;

			case 'telegram':
				$link_one_url = sprintf(
					'https://t.me/%1$s%2$s',
					'' !== $button_one_telegram ? esc_attr( $button_one_telegram ) : '',
					'' !== $button_one_telegram_msg ? esc_attr( '?start=' . $button_one_telegram_msg ) : ''
				);
				break;

			case 'download':
				$link_one_url = sprintf(
					'%1$s',
					'' !== $button_one_download_file ? esc_attr( $button_one_download_file ) : ''
				);
				break;
			default:
				$link_one_url = '';
		}

		$link_two_url = '';
		switch ( $button_two_link_type ) {
			case 'url':
				$link_two_url = sprintf( '%1$s', $button_two_url );
				break;
			case 'email':
				$link_two_url = sprintf(
					'mailto:%1$s?%2$s%3$s%4$s%5$s',
					'' !== $button_two_email_address ? esc_attr( $button_two_email_address ) : '',
					'' !== $button_two_email_cc ? '&cc=' . $button_two_email_cc : '',
					'' !== $button_two_email_bcc ? esc_attr( "&bcc=$button_two_email_bcc" ) : '',
					'' !== $button_two_email_subject ? esc_attr( '&subject=' . $button_two_email_subject ) : '',
					'' !== $button_two_email_msg ? esc_attr( '&body=' . $button_two_email_msg ) : ''
				);
				break;
			case 'phone':
				$link_two_url = sprintf( 'tel:%1$s', $button_two_phone_number );
				break;
			case 'sms':
				$link_two_url = sprintf(
					'sms:%1$s%2$s',
					'' !== $button_two_sms_number ? esc_attr( $button_two_sms_number ) : '',
					'' !== $button_two_sms_msg ? '?&body=' . rawurlencode( $button_two_sms_msg ) : ''
				);
				break;

			case 'fb_messenger':
				$link_two_url = sprintf(
					'https://m.me/%1$s',
					'' !== $button_two_fb_messenger ? esc_attr( $button_two_fb_messenger ) : ''
				);
				break;

			case 'skype':
				$link_two_url = sprintf(
					'skype:%1$s%2$s',
					'' !== $button_two_skype ? esc_attr( $button_two_skype ) : '',
					esc_attr( '?' . $button_two_skype_action_type )
				);
				break;

			case 'whatsapp':
				$link_two_url = sprintf(
					'https://wa.me/%1$s%2$s',
					'' !== $button_two_whatsapp_number ? esc_attr( $button_two_whatsapp_number ) : '',
					'' !== $button_two_whatsapp_msg ? esc_attr( '?text=' . $button_two_whatsapp_msg ) : ''
				);
				break;

			case 'telegram':
				$link_two_url = sprintf(
					'https://t.me/%1$s%2$s',
					'' !== $button_two_telegram ? esc_attr( $button_two_telegram ) : '',
					'' !== $button_two_telegram_msg ? esc_attr( '?start=' . $button_two_telegram_msg ) : ''
				);
				break;

			case 'download':
				$link_two_url = sprintf(
					'%1$s',
					'' !== $button_two_download_file ? esc_attr( $button_two_download_file ) : ''
				);
				break;
			default:
				$link_two_url = '';
		}

		$button_one_dec = self::get_button_anchor_id_and_class( $attrs, 'button_one' );
		$button_two_dec = self::get_button_anchor_id_and_class( $attrs, 'button_two' );

		$bg_layout_classes = self::get_text_background_layout_classes( $attrs );

		$button_one_id_attr = '' !== $button_one_dec['id'] ? sprintf( ' id="%s"', esc_attr( $button_one_dec['id'] ) ) : '';
		$button_two_id_attr = '' !== $button_two_dec['id'] ? sprintf( ' id="%s"', esc_attr( $button_two_dec['id'] ) ) : '';

		$order_index = $block->parsed_block['orderIndex'] ?? '';
		$order_class = '' !== $order_index ? sprintf( 'dsm_button_%1$s', $order_index ) : '';

		// The order class is also on each anchor and the separator so responsive
		// button text can use a compound selector. Module decoration (position,
		// spacing, transform) is scoped to `{{selector}}.et_pb_module` in module.json
		// so those styles stay on the wrapper. Divi 4 only put the order class on
		// the module, which is why absolute position must not match the anchors.

		$button_one_anchor_classes = array_filter(
			array_merge(
				array(
					'et_pb_button',
					'et_pb_button_one',
					'dsm-none' === $button_one_hover_animation ? '' : $button_one_hover_animation,
					'none' !== $button_one_icon_hover_animation ? $button_one_icon_hover_animation : '',
					$order_class,
				),
				array_filter( explode( ' ', $bg_layout_classes ) ),
				array(
					'on' === $button_one_image_popup ? 'dsm-image-lightbox' : '',
					'on' === $button_one_video_popup ? 'dsm-video-lightbox' : '',
					$button_one_dec['class'],
				)
			)
		);
		$button_one_class_attr     = trim( implode( ' ', array_map( 'trim', $button_one_anchor_classes ) ) );

		$button_two_anchor_classes = array_filter(
			array_merge(
				array(
					'et_pb_button',
					'et_pb_button_two',
					'dsm-none' === $button_two_hover_animation ? '' : $button_two_hover_animation,
					'none' !== $button_two_icon_hover_animation ? $button_two_icon_hover_animation : '',
					$order_class,
				),
				array_filter( explode( ' ', $bg_layout_classes ) ),
				array(
					'on' === $button_two_image_popup ? 'dsm-image-lightbox' : '',
					'on' === $button_two_video_popup ? 'dsm-video-lightbox' : '',
					$button_two_dec['class'],
				)
			)
		);
		$button_two_class_attr     = trim( implode( ' ', array_map( 'trim', $button_two_anchor_classes ) ) );

		$button_one_shared_args = array(
			esc_html( $button_one_text_value ),
			( 'on' !== $button_one_image_popup && '' !== $link_one_url )
				? sprintf( 'href="%s"', esc_url( $link_one_url ) )
				: '',
			'download' === $button_one_link_type ? 'download' : '',
			'on' === $button_one_url_new_window ? ' target="_blank"' : '',
			'on' === $button_one_use_tooltip ? 'dsm-tooltip' : '',
			'on' === $button_one_use_tooltip ? sprintf( 'dsm-tooltip-%1$s', $button_one_tooltip_animation ) : '',
			'on' === $button_one_use_tooltip ? sprintf( 'data-dsm-tooltip="%1$s" ', $button_one_tooltip_content ) : '',
			'on' === $button_one_use_tooltip ? sprintf( 'data-dsm-tooltip-placement="%1$s" ', $button_one_tooltip_placement ) : '',
			'on' === $button_one_use_tooltip ? sprintf( 'data-dsm-tooltip-size="%1$s" ', $button_one_tooltip_size ) : '',
			'on' === $button_one_image_popup ? sprintf( 'data-button-one-image-url="%1$s" ', $button_one_popup_src ) : '',
			$order_class,
			$button_one_id_attr,
			esc_attr( $button_one_class_attr ),
		);

		if ( 'on' === $button_one_use_tooltip ) {
			$button_one_markup = sprintf(
				'<div class="dsm_button_one %5$s %6$s" %7$s %8$s %9$s> 
				   <a%12$s class="%13$s" %2$s %3$s %4$s %10$s data-order-class="%11$s" data-icon="%14$s">%1$s</a>
				 </div>',
				$button_one_shared_args[0],
				$button_one_shared_args[1],
				$button_one_shared_args[2],
				$button_one_shared_args[3],
				$button_one_shared_args[4],
				$button_one_shared_args[5],
				$button_one_shared_args[6],
				$button_one_shared_args[7],
				$button_one_shared_args[8],
				$button_one_shared_args[9],
				$button_one_shared_args[10],
				$button_one_shared_args[11],
				$button_one_shared_args[12],
				$button_one_icon
			);
		} else {
			$button_one_markup = sprintf(
				'<a%12$s class="%13$s" %2$s %3$s %4$s %10$s data-order-class="%11$s" data-icon="%14$s">%1$s</a>',
				$button_one_shared_args[0],
				$button_one_shared_args[1],
				$button_one_shared_args[2],
				$button_one_shared_args[3],
				'',
				'',
				'',
				'',
				'',
				$button_one_shared_args[9],
				$button_one_shared_args[10],
				$button_one_shared_args[11],
				$button_one_shared_args[12],
				$button_one_icon
			);
		}

		$button_two_shared_args = array(
			esc_html( $button_two_text_value ),
			( 'on' !== $button_two_image_popup && '' !== $link_two_url )
				? sprintf( 'href="%s" ', esc_url( $link_two_url ) )
				: '',
			'download' === $button_two_link_type ? 'download' : '',
			'on' === $button_two_url_new_window ? ' target="_blank"' : '',
			'on' === $button_two_use_tooltip ? 'dsm-tooltip ' : '',
			'on' === $button_two_use_tooltip ? sprintf( 'dsm-tooltip-%1$s', $button_two_tooltip_animation ) : '',
			'on' === $button_two_use_tooltip ? sprintf( 'data-dsm-tooltip="%1$s" ', $button_two_tooltip_content ) : '',
			'on' === $button_two_use_tooltip ? sprintf( 'data-dsm-tooltip-placement="%1$s" ', $button_two_tooltip_placement ) : '',
			'on' === $button_two_use_tooltip ? sprintf( 'data-dsm-tooltip-size="%1$s" ', $button_two_tooltip_size ) : '',
			'on' === $button_two_image_popup ? sprintf( 'data-button-two-image-url="%1$s" ', $button_two_popup_src ) : '',
			$order_class,
			$button_two_id_attr,
			esc_attr( $button_two_class_attr ),
		);

		if ( 'on' === $button_two_use_tooltip ) {
			$button_two_markup = sprintf(
				'<div class="dsm_button_two %5$s%6$s" %7$s %8$s %9$s>
				   <a%12$s class="%13$s" %2$s %3$s %4$s %10$s data-order-class="%11$s" data-icon="%14$s">%1$s</a>
				</div>',
				$button_two_shared_args[0],
				$button_two_shared_args[1],
				$button_two_shared_args[2],
				$button_two_shared_args[3],
				$button_two_shared_args[4],
				$button_two_shared_args[5],
				$button_two_shared_args[6],
				$button_two_shared_args[7],
				$button_two_shared_args[8],
				$button_two_shared_args[9],
				$button_two_shared_args[10],
				$button_two_shared_args[11],
				$button_two_shared_args[12],
				$button_two_icon
			);
		} else {
			$button_two_markup = sprintf(
				'<a%12$s class="%13$s" %2$s %3$s %4$s %10$s data-order-class="%11$s" data-icon="%14$s">%1$s</a>',
				$button_two_shared_args[0],
				$button_two_shared_args[1],
				$button_two_shared_args[2],
				$button_two_shared_args[3],
				'',
				'',
				'',
				'',
				'',
				$button_two_shared_args[9],
				$button_two_shared_args[10],
				$button_two_shared_args[11],
				$button_two_shared_args[12],
				$button_two_icon
			);
		}

		$separator_text_markup = sprintf(
			'<span class="dsm-button-separator-text%2$s">%1$s</span>',
			esc_html( $separator_text_value ),
			'' !== $order_class ? ' ' . esc_attr( $order_class ) : ''
		);

		// No whitespace between %1$s / %3$s / %2$s: inline-block children would show it as a gap on the frontend.
		$buttons_wrapper = sprintf(
			'<div class="et_pb_button_module_wrappers">%1$s%3$s%2$s</div>',
			$has_button_one_text ? $button_one_markup : '',
			$has_button_two_text ? $button_two_markup : '',
			$has_separator_text ? $separator_text_markup : ''
		);

		// Were wrapping the title and content in a div with class `et_pb_module_inner`.
		$module_inner = HTMLUtility::render(
			array(
				'tag'               => 'div',
				'attributes'        => array(
					'class' => 'et_pb_module_inner',
				),
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $buttons_wrapper,
			)
		);

		// This are the module elements that will be rendered in the frontend.
		$module_elements = $elements->style_components(
			array(
				'attrName' => 'module',
			)
		);

		// This are the children of the module container, which are the module elements and the module inner.
		$module_container_children = $module_elements . $module_inner;

		return Module::render(
			array(
				// FE only.
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],

				// VB equivalent.
				'attrs'               => $attrs,
				'elements'            => $elements,
				'id'                  => $block->parsed_block['id'],
				'name'                => $block->block_type->name,
				'classnamesFunction'  => array( self::class, 'module_classnames' ),
				'moduleCategory'      => $block->block_type->category,
				'stylesComponent'     => array( self::class, 'module_styles' ),
				'scriptDataComponent' => array( self::class, 'module_script_data' ),
				'children'            => $module_container_children,
			)
		);
	}

	/**
	 * ID and class for a button `<a>`: element decoration (Design → target) plus Advanced → Attributes rows with target `button_one` / `button_two`.
	 *
	 * @param array  $attrs       Module attributes.
	 * @param string $target_key `button_one` or `button_two`.
	 * @return array{id: string, class: string}
	 */
	private static function get_button_anchor_id_and_class( array $attrs, string $target_key ): array {
		$from_element = ConversionAttrs::extract_element_decoration_id_and_class( $attrs[ $target_key ] ?? array() );
		$from_module  = self::get_module_targeted_id_class_for_button( $attrs, $target_key );

		// Prefer Advanced → Attributes (module + targetElement) over element decoration when both exist.
		$id = '' !== $from_module['id'] ? $from_module['id'] : $from_element['id'];

		$class = AttributeUtils::merge_attribute_values(
			'class',
			trim( $from_element['class'] ),
			trim( $from_module['class'] )
		);

		return array(
			'id'    => $id,
			'class' => trim( $class ),
		);
	}

	/**
	 * Read id/class from module Advanced → Attributes when the row target is `button_one` or `button_two`.
	 *
	 * @param array  $attrs       Module attributes.
	 * @param string $target_key `button_one` or `button_two`.
	 * @return array{id: string, class: string}
	 */
	private static function get_module_targeted_id_class_for_button( array $attrs, string $target_key ): array {
		$out = array(
			'id'    => '',
			'class' => '',
		);

		$dec = $attrs['module']['decoration']['attributes'] ?? null;
		if ( ! is_array( $dec ) ) {
			return $out;
		}

		$separated = AttributeUtils::separate_attributes_by_target_element( $dec );
		$block     = $separated[ $target_key ] ?? array();
		if ( ! is_array( $block ) ) {
			return $out;
		}

		if ( isset( $block['id'] ) && is_string( $block['id'] ) && '' !== $block['id'] ) {
			$out['id'] = sanitize_text_field( $block['id'] );
		}
		if ( isset( $block['class'] ) && is_string( $block['class'] ) && '' !== $block['class'] ) {
			$out['class'] = sanitize_text_field( $block['class'] );
		}

		return $out;
	}

	/**
	 * Normalize upload field `innerContent.desktop.value` to a URL string.
	 *
	 * @param mixed $value Raw value (string URL or array with `src`).
	 * @return string
	 */
	private static function normalize_upload_inner_value_to_src( $value ): string {
		if ( is_string( $value ) ) {
			return $value;
		}
		if ( is_array( $value ) && isset( $value['src'] ) && is_string( $value['src'] ) ) {
			return $value['src'];
		}
		return '';
	}

	/**
	 * Classes matching Divi 4 `background_layout` on buttons (maps to D5 module Text → Text Color).
	 *
	 * Divi theme targets `et_pb_bg_layout_light` / `et_pb_bg_layout_dark` on `.et_pb_button` for default border/contrast.
	 *
	 * @param array $attrs Module attributes.
	 * @return string Space-separated class names.
	 */
	private static function get_text_background_layout_classes( array $attrs ): string {
		$text_advanced = $attrs['module']['advanced']['text'] ?? array();
		$from_et       = trim( TextClassnames::get_background_layout_classnames( $text_advanced ) );
		if ( '' !== $from_et ) {
			return $from_et;
		}

		// Fallback when advanced.text is empty (matches D4 default and TypingEffect pattern).
		$text_group = $text_advanced['text'] ?? array();
		$desktop    = $text_group['desktop']['value']['color'] ?? 'light';
		if ( ! is_string( $desktop ) || ! in_array( $desktop, array( 'light', 'dark' ), true ) ) {
			$desktop = 'light';
		}
		$classes = array( 'et_pb_bg_layout_' . $desktop );
		foreach ( array( 'tablet', 'phone' ) as $bp ) {
			$color = $text_group[ $bp ]['value']['color'] ?? '';
			if ( is_string( $color ) && '' !== $color && in_array( $color, array( 'light', 'dark' ), true ) ) {
				$classes[] = 'et_pb_bg_layout_' . $color . '_' . $bp;
			}
		}
		return implode( ' ', $classes );
	}

	/**
	 * Desktop plain-text leaf from responsive `innerContent`.
	 *
	 * @param array  $attrs Module attributes.
	 * @param string $key   Attribute key.
	 * @return string
	 */
	private static function inner_content_desktop_plain_text( array $attrs, string $key ): string {
		$value = $attrs[ $key ]['innerContent']['desktop']['value'] ?? '';

		if ( is_array( $value ) ) {
			$value = $value['text'] ?? '';
		}

		return is_string( $value ) ? $value : '';
	}

	/**
	 * True when any breakpoint has non-empty plain text (tablet/phone inherit is handled by MultiView on the frontend).
	 *
	 * @param array  $attrs Module attributes.
	 * @param string $key   Attribute key.
	 * @return bool
	 */
	private static function inner_content_has_text_any_breakpoint( array $attrs, string $key ): bool {
		$inner = $attrs[ $key ]['innerContent'] ?? null;

		if ( ! is_array( $inner ) ) {
			return false;
		}

		foreach ( array( 'desktop', 'tablet', 'phone' ) as $breakpoint ) {
			if ( ! isset( $inner[ $breakpoint ]['value'] ) ) {
				continue;
			}

			$value = $inner[ $breakpoint ]['value'];

			if ( is_array( $value ) ) {
				$value = $value['text'] ?? '';
			}

			if ( is_string( $value ) && '' !== trim( $value ) ) {
				return true;
			}
		}

		return false;
	}
}
