<?php
/**
 * Read More Module.
 *
 * @package DiviSupreme.
 */

declare(strict_types=1);

namespace DiviSupreme\Modules;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\Module\Options\Element\ElementClassnames;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use DiviSupreme\Extensions\IconLibraries\LegacyModuleIconStyles;

/**
 * Class that handles "ReadMore Module" module.
 */
class Readmore implements DependencyInterface {


	/**
	 * Register module.
	 */
	public function load() {
		add_action( 'init', array( self::class, 'register_module' ) );
	}

	/**
	 * Dsm initialise.
	 */
	public static function dsm_initialise() {
		add_action(
			'divi_module_library_modules_dependency_tree',
			function ( $dependency_tree ) {
				$dependency_tree->add_dependency( new self() );
			}
		);
	}

	/**
	 * Register module.
	 */
	public static function register_module() {
		$module_json_path = DSM_DIR_PATH . 'divi-5/public/packages/module-library/readmore';

		ModuleRegistration::register_module(
			$module_json_path,
			array(
				'render_callback' => array( self::class, 'render_callback' ),
			)
		);
	}

	/**
	 * Icon style declaration.
	 *
	 * @param mixed $params Params.
	 */
	public static function icon_style_declaration( $params ) {
		return LegacyModuleIconStyles::build_pseudo_icon_declaration( $params );
	}

	/**
	 * Normalize range / string icon size for font-size (CommonStyle expects a string).
	 *
	 * @param mixed $raw Attr leaf from iconSize.innerContent (string, array, or numeric).
	 * @return string
	 */
	public static function readmore_icon_size_to_css_string( $raw ) {
		if ( is_string( $raw ) && '' !== $raw ) {
			return $raw;
		}
		if ( is_array( $raw ) && isset( $raw['value'], $raw['unit'] ) ) {
			return $raw['value'] . $raw['unit'];
		}
		if ( is_numeric( $raw ) ) {
			return (string) $raw . 'px';
		}

		return '24px';
	}

	/**
	 * Style declaration callback for icon font-size (avoids array passed to StyleDeclarations::add).
	 *
	 * @param array $params Declaration params including attrValue and important.
	 * @return string
	 */
	public static function icon_size_style_declaration( $params ) {
		$raw  = $params['attrValue'] ?? '';
		$size = self::readmore_icon_size_to_css_string( $raw );

		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
				'important'  => $params['important'] ?? array(),
			)
		);

		$style_declarations->add( 'font-size', $size );

		return $style_declarations->value();
	}

	/**
	 * Module styles.
	 *
	 * @param mixed $args   Args.
	 */
	public static function module_styles( $args ) {
		$args     = \DiviSupreme\Includes\DsmDiviBuilderCssScope::normalize_module_styles_args( $args );
		$attrs    = $args['attrs'] ?? array();
		$elements = $args['elements'];

		Style::add(
			array(
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => array(
					$elements->style(
						array(
							'attrName'   => 'module',
							'styleProps' => array(
								'disabledOn' => array(
									'disabledModuleVisibility' => $args['settings']['disabledModuleVisibility'] ?? null,
								),
							),
						)
					),

					CssStyle::style(
						array(
							'selector' => $args['orderClass'],
							'attr'     => $attrs['css'] ?? array(),
						)
					),

					$elements->style(
						array(
							'attrName' => 'button',
						)
					),

					$elements->style(
						array(
							'attrName' => 'shadowFade',
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm_button_wrapper .dsm-readmore-button.dsm-btn-close::after",
							'attr'                => $attrs['closeIcon']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'icon_style_declaration' ),
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm_button_wrapper .dsm-readmore-button.dsm-btn-open::after",
							'attr'                => $attrs['openIcon']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'icon_style_declaration' ),
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm_button_wrapper .dsm-readmore-button::after",
							'attr'                => $attrs['iconSize']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'icon_size_style_declaration' ),
						)
					),
				),
			)
		);
	}

	/**
	 * Module script data.
	 *
	 * @param mixed $args   Args.
	 */
	public static function module_script_data( $args ) {
		$elements = $args['elements'];
		$elements->script_data(
			array(
				'attrName' => 'module',
			)
		);
	}

	/**
	 * Module classnames.
	 *
	 * @param mixed $args   Args.
	 */
	public static function module_classnames( $args ) {
		$classnames_instance = $args['classnamesInstance'];
		$attrs               = $args['attrs'];

		$classnames_instance->add(
			ElementClassnames::classnames(
				array(
					'attrs' => $attrs['module']['decoration'] ?? array(),
				)
			)
		);
	}

	/**
	 * Normalize dsmHeight innerContent leaf to a CSS length.
	 *
	 * @param mixed $raw Value from innerContent breakpoint leaf.
	 * @return string
	 */
	public static function readmore_normalize_collapse_height( $raw ) {
		if ( is_array( $raw ) && isset( $raw['value'], $raw['unit'] ) ) {
			return $raw['value'] . $raw['unit'];
		}
		if ( is_string( $raw ) && '' !== $raw ) {
			return $raw;
		}
		if ( is_numeric( $raw ) ) {
			return (string) $raw . 'px';
		}

		return '100px';
	}

	/**
	 * Collapse heights per breakpoint (tablet/phone inherit when unset, same as builder).
	 *
	 * @param array $attrs Module attrs.
	 * @return array{desktop:string,tablet:string,phone:string}
	 */
	public static function readmore_responsive_collapse_heights( array $attrs ) {
		$inner       = $attrs['dsmHeight']['innerContent'] ?? array();
		$desktop_raw = $inner['desktop']['value'] ?? null;
		$tablet_raw  = $inner['tablet']['value'] ?? null;
		$phone_raw   = $inner['phone']['value'] ?? null;

		$desktop = self::readmore_normalize_collapse_height( $desktop_raw );
		$tablet  = ( null !== $tablet_raw && '' !== $tablet_raw )
			? self::readmore_normalize_collapse_height( $tablet_raw )
			: $desktop;
		$phone   = ( null !== $phone_raw && '' !== $phone_raw )
			? self::readmore_normalize_collapse_height( $phone_raw )
			: $tablet;

		return array(
			'desktop' => $desktop,
			'tablet'  => $tablet,
			'phone'   => $phone,
		);
	}

	/**
	 * Phone/tablet max-width in px (Divi defaults or Theme Builder custom breakpoints).
	 *
	 * @return array{phone_max:int,tablet_max:int}
	 */
	public static function readmore_viewport_breakpoint_max_px() {
		$out = array(
			'phone_max'  => 767,
			'tablet_max' => 980,
		);

		if ( ! class_exists( '\ET\Builder\Framework\Breakpoint\Breakpoint' ) ) {
			return $out;
		}

		$items = \ET\Builder\Framework\Breakpoint\Breakpoint::get_settings_values()['items'] ?? array();

		if ( ! empty( $items['phone']['maxWidth']['value'] ) ) {
			$out['phone_max'] = (int) preg_replace( '/\D+/', '', (string) $items['phone']['maxWidth']['value'] );
		}
		if ( ! empty( $items['tablet']['maxWidth']['value'] ) ) {
			$out['tablet_max'] = (int) preg_replace( '/\D+/', '', (string) $items['tablet']['maxWidth']['value'] );
		}

		return $out;
	}

	/**
	 * Render module HTML output.
	 *
	 * @param mixed $attrs    Attrs.
	 * @param mixed $content  Content.
	 * @param mixed $block    Block.
	 * @param mixed $elements Elements.
	 */
	public static function render_callback( $attrs, $content, $block, $elements ) {

		$show_readmore_raw = $attrs['showReadMore']['innerContent']['desktop']['value'] ?? 'on';
		$show_readmore     = ( 'off' === $show_readmore_raw || false === $show_readmore_raw ) ? 'off' : 'on';
		$close_text        = $attrs['closeText']['innerContent']['desktop']['value'] ?? 'Read Less';
		$open_text         = $attrs['openText']['innerContent']['desktop']['value'] ?? 'Read More';

		$heights = self::readmore_responsive_collapse_heights( $attrs );
		$bp      = self::readmore_viewport_breakpoint_max_px();

		$use_shadow_raw = $attrs['useShadow']['innerContent']['desktop']['value'] ?? 'on';
		$use_shadow     = ( 'off' === $use_shadow_raw || false === $use_shadow_raw ) ? 'off' : 'on';

		$collapse_scroll_raw = $attrs['collapseScrollToTop']['innerContent']['desktop']['value'] ?? 'off';
		$collapse_scroll     = ( 'on' === $collapse_scroll_raw || true === $collapse_scroll_raw ) ? 'on' : 'off';

		wp_enqueue_script( 'dsm-readmore' );

		$data_settings = array(
			'data-show-readmore'          => $show_readmore,
			'data-close-text'             => $close_text,
			'data-open-text'              => $open_text,
			'data-height'                 => $heights['desktop'],
			'data-readmore-heights'       => wp_json_encode( $heights ),
			'data-readmore-phone-max'     => (string) $bp['phone_max'],
			'data-readmore-tablet-max'    => (string) $bp['tablet_max'],
			'data-collapse-scroll-to-top' => $collapse_scroll,
		);

		$data_attrs_string = '';
		foreach ( $data_settings as $key => $value ) {
			$data_attrs_string .= sprintf( ' %1$s="%2$s"', esc_attr( $key ), esc_attr( $value ) );
		}

		$button_markup = sprintf(
			'<div class="dsm_button_wrapper">
					<a class="dsm-readmore-button et_pb_button">ReadMore</a>
			</div>'
		);

		$container = sprintf(
			'<div class="dsm-readmore-wrapper %4$s"%3$s>
               %1$s
            </div>
			%2$s',
			$content,
			'on' === $show_readmore ? $button_markup : '',
			$data_attrs_string,
			( 'on' === $show_readmore && 'on' === $use_shadow ) ? 'dsm-readmore-shadow' : ''
		);

		$module_inner = HTMLUtility::render(
			array(
				'tag'               => 'div',
				'attributes'        => array(
					'class' => 'et_pb_module_inner',
				),
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $container,
			)
		);

		$module_elements = $elements->style_components(
			array(
				'attrName' => 'module',
			)
		);

		$module_container_children = $module_elements . $module_inner;

		return Module::render(
			array(
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],
				'attrs'               => $attrs,
				'elements'            => $elements,
				'id'                  => $block->parsed_block['id'],
				'name'                => $block->block_type->name,
				'classnamesFunction'  => array( self::class, 'module_classnames' ),
				'moduleCategory'      => $block->block_type->category,
				'stylesComponent'     => array( self::class, 'module_styles' ),
				'scriptDataComponent' => array( self::class, 'module_script_data' ),
				'children'            => $module_container_children,
			)
		);
	}
}
