<?php
/**
 * Flipbox child (D4 `dsm_flipbox_child`): registered so Divi’s D4→D5 conversion nests faces under `dsm/flipbox`.
 * Faces are merged into `dsm/flipbox` `front_*` / `back_*` by {@see \DiviSupreme\Includes\Divi5Conversion\FlipboxChildMergeMigrator}.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Modules;

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Stub child module: output is owned by `dsm/flipbox` after merge.
 */
final class FlipboxChild implements DependencyInterface {

	/**
	 * Register hooks.
	 */
	public function load(): void {
		add_action( 'init', array( self::class, 'register_module' ) );
	}

	/**
	 * Register with Divi 5 (required for conversion `childrenName` on `dsm/flipbox`).
	 */
	public static function register_module(): void {
		$module_json_path = DSM_DIR_PATH . 'divi-5/public/packages/module-library/flipbox-child';

		ModuleRegistration::register_module(
			$module_json_path,
			array(
				'render_callback' => array( self::class, 'render_callback' ),
			)
		);
	}

	/**
	 * Render callback: faces render from the parent `dsm/flipbox` block after migration merge.
	 *
	 * @param array<string, mixed> $attrs    Attributes.
	 * @param string               $content  Inner content.
	 * @param \WP_Block            $block    Block.
	 * @param mixed                $elements Elements API.
	 * @return string
	 */
	public static function render_callback( $attrs, $content, $block, $elements ) {
		unset( $attrs, $content, $block, $elements );

		return '';
	}
}
