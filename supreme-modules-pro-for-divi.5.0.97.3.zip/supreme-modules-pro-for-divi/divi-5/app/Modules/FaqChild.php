<?php
/**
 * Faq Child Module.
 *
 * @package DiviSupreme.
 */

declare(strict_types=1);

namespace DiviSupreme\Modules;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}


use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\Module\Options\Element\ElementClassnames;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\ModuleUtils\ChildrenUtils;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use DiviSupreme\Includes\Divi5Conversion\ConversionAttrs;
use DiviSupreme\Extensions\IconLibraries\IconModuleRenderBridge;
use DiviSupreme\Extensions\IconLibraries\LegacyModuleIconStyles;
use DiviSupreme\Includes\ModuleRegisterAttrsNormalize;
use DiviSupreme\Includes\UploadImageMarkup;
use DiviSupreme\Utils\HeadingLevel;

/**
 * Class that handles "FaqChild Module" module.
 */
class FaqChild implements DependencyInterface {



	/**
	 * Register module.
	 * `DependencyInterface` interface ensures class method name `load()` is executed for initialization.
	 */
	public function load() {
		add_filter(
			'divi_module_library_register_module_attrs',
			array( self::class, 'filter_register_module_attrs' ),
			10,
			2
		);

		add_action( 'init', array( self::class, 'register_module' ) );
	}

	/**
	 * Migrate legacy FAQ toggle plain-color saves into decoration background blobs.
	 *
	 * @param array<string, mixed> $module_attrs Merged attrs.
	 * @param array<string, mixed> $filter_args  Context (`name`, `attrs`, …).
	 * @return array<string, mixed>
	 */
	public static function filter_register_module_attrs( $module_attrs, $filter_args ) {
		if ( ! is_array( $module_attrs ) || ! is_array( $filter_args ) ) {
			return is_array( $module_attrs ) ? $module_attrs : array();
		}

		if ( ( $filter_args['name'] ?? '' ) !== 'dsm/faq-child' ) {
			return $module_attrs;
		}

		$parent_attrs = $filter_args['parentAttrs'] ?? null;
		ModuleRegisterAttrsNormalize::faq_child_merged(
			$module_attrs,
			\is_array( $parent_attrs ) ? $parent_attrs : null
		);

		return $module_attrs;
	}

	/**
	 * Initilises the module.
	 *
	 * @return void
	 */
	public static function dsm_initialise() {
		add_action(
			'divi_module_library_modules_dependency_tree',
			function ( $dependency_tree ) {
				$dependency_tree->add_dependency( new self() );
			}
		);
	}

	/**
	 * Register module.
	 */
	public static function register_module() {

		$module_json_path = DSM_DIR_PATH . 'divi-5/public/packages/module-library/faq-child';

		ModuleRegistration::register_module(
			$module_json_path,
			array(
				'render_callback' => array( self::class, 'render_callback' ),
			)
		);
	}

	/**
	 * Render module style.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_styles( $args ) {
		$args        = \DiviSupreme\Includes\DsmDiviBuilderCssScope::normalize_module_styles_args( $args );
		$order_class = (string) ( $args['orderClass'] ?? '' );
		$sc          = static function ( string $parent_chain, string $suffix = '' ) use ( $order_class ): string {
			return \DiviSupreme\Includes\DsmDiviBuilderCssScope::scoped_child_selector( $parent_chain, $order_class, $suffix );
		};
		$elements    = $args['elements'] ?? null;
		if ( is_object( $elements ) && isset( $elements->module_attrs ) && \is_array( $elements->module_attrs ) ) {
			ConversionAttrs::migrate_faq_toggle_legacy_inner_content_color_into_decoration_background( $elements->module_attrs );
		}
		if ( ! empty( $args['attrs'] ) && \is_array( $args['attrs'] ) ) {
			ConversionAttrs::migrate_faq_toggle_legacy_inner_content_color_into_decoration_background( $args['attrs'] );
		}

		$parent_attrs = $args['parentAttrs'] ?? array();
		if ( \is_array( $parent_attrs ) && array() !== $parent_attrs ) {
			if ( is_object( $elements ) && isset( $elements->module_attrs ) && \is_array( $elements->module_attrs ) ) {
				ConversionAttrs::hydrate_faq_child_toggle_backgrounds_from_parent( $elements->module_attrs, $parent_attrs );
			}
			if ( ! empty( $args['attrs'] ) && \is_array( $args['attrs'] ) ) {
				ConversionAttrs::hydrate_faq_child_toggle_backgrounds_from_parent( $args['attrs'], $parent_attrs );
			}
		}

		$attrs = $args['attrs'] ?? array();

		Style::add(
			array(
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => array(
					// Module.
					$elements->style(
						array(
							'attrName'   => 'module',
							'styleProps' => array(
								'disabledOn' => array(
									'disabledModuleVisibility' => $args['settings']['disabledModuleVisibility'] ?? null,
								),
							),
						)
					),

					CssStyle::style(
						array(
							'selector' => $args['orderClass'],
							'attr'     => $attrs['css'] ?? array(),
						)
					),

					$elements->style(
						array(
							'attrName' => 'header_item',
						)
					),

					$elements->style(
						array(
							'attrName' => 'closed_header_item',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_open_toggle_margin',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_open_toggle_padding',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_closed_toggle_margin',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_closed_toggle_padding',
						)
					),

					$elements->style(
						array(
							'attrName' => 'toggleOpenStateStyle',
						)
					),

					$elements->style(
						array(
							'attrName' => 'toggleCloseStateStyle',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_open_icon_margin',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_open_icon_padding',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_close_icon_margin',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_close_icon_padding',
						)
					),

					$elements->style(
						array(
							'attrName' => 'iconOpenStateStyle',
						)
					),

					$elements->style(
						array(
							'attrName' => 'iconCloseStateStyle',
						)
					),

					$elements->style(
						array(
							'attrName' => 'imageOpenStateStyle',
						)
					),

					$elements->style(
						array(
							'attrName' => 'imageCloseStateStyle',
						)
					),

					$elements->style(
						array(
							'attrName' => 'content',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_content_margin',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_content_padding',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_open_image_margin',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_open_image_padding',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_close_image_margin',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_close_image_padding',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_close_bg_color',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_open_bg_color',
						)
					),

					CommonStyle::style(
						array(
							'selector'            => $sc( '.dsm-faq-container', ' .dsm-title-wrapper .et-pb-icon.dsm_faq-item-open_icon::before' ),
							'attr'                => $attrs['dsm_child_open_font_icon']['innerContent'] ?? array(),
							'declarationFunction' => array( LegacyModuleIconStyles::class, 'build_pseudo_icon_declaration' ),
						)
					),

					CommonStyle::style(
						array(
							'selector'            => $sc( '.dsm-faq-container', ' .dsm-title-wrapper .et-pb-icon.dsm_faq-item-close_icon::before' ),
							'attr'                => $attrs['dsm_child_close_font_icon']['innerContent'] ?? array(),
							'declarationFunction' => array( LegacyModuleIconStyles::class, 'build_pseudo_icon_declaration' ),
						)
					),

					CommonStyle::style(
						array(
							'selector' => $sc( '.dsm-faq-container', '.dsm-faq-item-wrapper .et-pb-icon.dsm_faq-item-open_icon' ) . ', ' . $sc( '.dsm-faq-container', '.dsm-faq-item-wrapper .et-pb-icon.dsm_open_icon' ),
							'attr'     => $attrs['dsm_open_font_size']['innerContent'] ?? array(),
							'property' => 'font-size',
						)
					),

					CommonStyle::style(
						array(
							'selector' => $sc( '.dsm-faq-container', '.dsm-faq-item-wrapper .et-pb-icon.dsm_faq-item-close_icon' ) . ', ' . $sc( '.dsm-faq-container', '.dsm-faq-item-wrapper .et-pb-icon.dsm_close_icon' ),
							'attr'     => $attrs['dsm_close_font_size']['innerContent'] ?? array(),
							'property' => 'font-size',
						)
					),

					CommonStyle::style(
						array(
							'selector' => $sc( '.dsm-faq-container', '.dsm-faq-item-wrapper .et-pb-icon.dsm_faq-item-close_icon' ) . ', ' . $sc( '.dsm-faq-container', '.dsm-faq-item-wrapper .et-pb-icon.dsm_close_icon' ),
							'attr'     => $attrs['dsm_close_icon_bg_color']['innerContent'] ?? array(),
							'property' => 'background',
						)
					),

					CommonStyle::style(
						array(
							'selector' => $sc( '.dsm-faq-container', '.dsm-faq-item-wrapper .et-pb-icon.dsm_faq-item-close_icon' ) . ', ' . $sc( '.dsm-faq-container', '.dsm-faq-item-wrapper .et-pb-icon.dsm_close_icon' ),
							'attr'     => $attrs['dsm_close_icon_color']['innerContent'] ?? array(),
							'property' => 'color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => $sc( '.dsm-faq-container', '.dsm-faq-item-wrapper .et-pb-icon.dsm_faq-item-open_icon' ) . ', ' . $sc( '.dsm-faq-container', '.dsm-faq-item-wrapper .et-pb-icon.dsm_open_icon' ),
							'attr'     => $attrs['dsm_open_icon_bg_color']['innerContent'] ?? array(),
							'property' => 'background',
						)
					),

					CommonStyle::style(
						array(
							'selector' => $sc( '.dsm-faq-container', '.dsm-faq-item-wrapper .et-pb-icon.dsm_faq-item-open_icon' ) . ', ' . $sc( '.dsm-faq-container', '.dsm-faq-item-wrapper .et-pb-icon.dsm_open_icon' ),
							'attr'     => $attrs['dsm_open_icon_color']['innerContent'] ?? array(),
							'property' => 'color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => $sc( '.dsm-faq-container', '.dsm-faq-item-wrapper .dsm_open_image' ),
							'attr'     => $attrs['dsm_open_image_width']['innerContent'] ?? array(),
							'property' => 'width',
						)
					),

					CommonStyle::style(
						array(
							'selector' => $sc( '.dsm-faq-container', '.dsm-faq-item-wrapper .dsm_open_image' ),
							'attr'     => $attrs['dsm_open_image_width']['innerContent'] ?? array(),
							'property' => 'height',
						)
					),

					CommonStyle::style(
						array(
							'selector' => $sc( '.dsm-faq-container', '.dsm-faq-item-wrapper .dsm_close_image' ),
							'attr'     => $attrs['dsm_close_image_width']['innerContent'] ?? array(),
							'property' => 'width',
						)
					),

					CommonStyle::style(
						array(
							'selector' => $sc( '.dsm-faq-container', '.dsm-faq-item-wrapper .dsm_close_image' ),
							'attr'     => $attrs['dsm_close_image_width']['innerContent'] ?? array(),
							'property' => 'height',
						)
					),
				),
			)
		);
	}

	/**
	 * Render module script data.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_script_data( $args ) {
		$elements = $args['elements'];

		// Element Script Data Options.
		$elements->script_data(
			array(
				'attrName' => 'module',
			)
		);
	}

	/**
	 * Render module classnames.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_classnames( $args ) {
		$classnames_instance = $args['classnamesInstance'];
		$attrs               = $args['attrs'];
		$parent_attrs        = $args['parentAttrs'] ?? array();

		// Module.
		$classnames_instance->add(
			ElementClassnames::classnames(
				array(
					'attrs' => $attrs['module']['decoration'] ?? array(),
				)
			)
		);

		$classnames_instance->add( 'dsm-faq-item-wrapper' );

		$dsm_child_use_image   = $attrs['dsm_child_use_image']['innerContent']['desktop']['value'] ?? 'off';
		$dsm_open_child_image  = $attrs['dsm_open_child_image']['innerContent']['desktop']['value'] ?? '';
		$dsm_close_child_image = $attrs['dsm_close_child_image']['innerContent']['desktop']['value'] ?? '';

		$parent_use_image   = $parent_attrs['dsm_use_image']['innerContent']['desktop']['value'] ?? 'off';
		$parent_open_image  = $parent_attrs['dsm_open_image']['innerContent']['desktop']['value'] ?? '';
		$parent_close_image = $parent_attrs['dsm_close_image']['innerContent']['desktop']['value'] ?? '';

		$uses_parent_toggle_images = (
			'on' === $parent_use_image
			&& 'on' !== $dsm_child_use_image
			&& (
				'' !== UploadImageMarkup::resolve_upload_src_string( $parent_open_image )
				|| '' !== UploadImageMarkup::resolve_upload_src_string( $parent_close_image )
			)
		);
		$uses_child_toggle_images  = (
			'on' === $dsm_child_use_image
			&& (
				'' !== UploadImageMarkup::resolve_upload_src_string( $dsm_open_child_image )
				|| '' !== UploadImageMarkup::resolve_upload_src_string( $dsm_close_child_image )
			)
		);

		if ( $uses_parent_toggle_images || $uses_child_toggle_images ) {
			$classnames_instance->add( 'dsm-faq-item-has-toggle-images' );
		}
	}

	/**
	 * Whether an icon picker leaf has a usable unicode value.
	 *
	 * @param mixed $icon Icon picker leaf.
	 * @return bool
	 */
	private static function faq_icon_has_value( $icon ): bool {
		if ( ! is_array( $icon ) ) {
			return false;
		}

		$unicode = $icon['unicode'] ?? '';

		return is_string( $unicode ) && '' !== $unicode;
	}

	/**
	 * Render FAQ toggle icon host (child override or parent fallback).
	 *
	 * @param mixed  $child_icon   Child icon picker leaf.
	 * @param mixed  $parent_icon  Parent icon picker leaf.
	 * @param string $parent_class Class when using parent icon styles.
	 * @param string $child_class  Class when using child icon styles.
	 * @return string
	 */
	private static function render_faq_toggle_icon(
		$child_icon,
		$parent_icon,
		string $parent_class,
		string $child_class
	): string {
		if ( self::faq_icon_has_value( $child_icon ) ) {
			return IconModuleRenderBridge::render_icon_host_markup(
				is_array( $child_icon ) ? $child_icon : null,
				array( $child_class )
			);
		}

		return IconModuleRenderBridge::render_icon_host_markup(
			is_array( $parent_icon ) ? $parent_icon : null,
			array( $parent_class )
		);
	}

	/**
	 * Render FAQ open/close toggle image with responsive srcset when possible.
	 *
	 * @param mixed  $raw            Upload innerContent desktop value.
	 * @param string $wrapper_class  Wrapper class (`dsm_open_image` or `dsm_close_image`).
	 * @return string
	 */
	private static function render_faq_toggle_image_markup( $raw, string $wrapper_class ): string {
		$img = UploadImageMarkup::render_img_html( $raw, '' );
		if ( '' === $img ) {
			return '';
		}

		return sprintf(
			'<div class="%1$s">%2$s</div>',
			esc_attr( $wrapper_class ),
			$img
		);
	}

	/**
	 * Resolve FAQ child title heading tag from Design → Title → Title Heading Level.
	 *
	 * Matches D4: `header_item_level` with fallback to parent `header_level`, then module default `h4`.
	 *
	 * @param array<string, mixed> $attrs        Child module attrs.
	 * @param array<string, mixed> $parent_attrs Parent FAQ attrs.
	 * @return string
	 */
	private static function resolve_faq_child_title_heading_tag( array $attrs, array $parent_attrs ): string {
		$level = $attrs['header_item']['decoration']['font']['font']['desktop']['value']['headingLevel'] ?? '';
		if ( HeadingLevel::is_allowed( $level ) ) {
			return HeadingLevel::sanitize( $level, 'h4' );
		}

		$legacy = $attrs['header_item_level']['innerContent']['desktop']['value'] ?? '';
		if ( HeadingLevel::is_allowed( $legacy ) ) {
			return HeadingLevel::sanitize( $legacy, 'h4' );
		}

		$parent_level = $parent_attrs['header']['decoration']['font']['font']['desktop']['value']['headingLevel'] ?? '';
		if ( HeadingLevel::is_allowed( $parent_level ) ) {
			return HeadingLevel::sanitize( $parent_level, 'h4' );
		}

		return 'h4';
	}

	/**
	 * Render module HTML output.
	 *
	 * @param array     $attrs - Modules Attributes.
	 * @param string    $child_modules_content - Nested inner module HTML.
	 * @param \WP_Block $block - Block.
	 * @param mixed     $elements - Elements.
	 */
	public static function render_callback( $attrs, $child_modules_content, $block, $elements ) {
		$children_ids         = ChildrenUtils::extract_children_ids( $block );
		$has_nested_modules   = '' !== trim( (string) $child_modules_content ) || ! empty( $children_ids );
		$layout_display_value = $attrs['module']['decoration']['layout']['desktop']['value']['display'] ?? 'flex';
		$nestable_classes     = HTMLUtility::classnames(
			'dsm-faq-nestable',
			array(
				'et_flex_module' => 'flex' === $layout_display_value,
				'et_grid_module' => 'grid' === $layout_display_value,
			)
		);

		if ( is_object( $elements ) && isset( $elements->module_attrs ) && \is_array( $elements->module_attrs ) ) {
			ConversionAttrs::migrate_faq_toggle_legacy_inner_content_color_into_decoration_background( $elements->module_attrs );
		}
		if ( \is_array( $attrs ) ) {
			ConversionAttrs::migrate_faq_toggle_legacy_inner_content_color_into_decoration_background( $attrs );
		}

		Faq::enqueue_module_styles();

		$parent       = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );
		$parent_attrs = $parent->attrs ?? array();

		if ( \is_array( $parent_attrs ) && array() !== $parent_attrs ) {
			if ( \is_array( $attrs ) ) {
				ConversionAttrs::hydrate_faq_child_toggle_backgrounds_from_parent( $attrs, $parent_attrs );
			}
			if ( is_object( $elements ) && isset( $elements->module_attrs ) && \is_array( $elements->module_attrs ) ) {
				ConversionAttrs::hydrate_faq_child_toggle_backgrounds_from_parent( $elements->module_attrs, $parent_attrs );
			}
		}

		$dsm_title                 = $attrs['dsm_title']['innerContent']['desktop']['value']['text'] ?? '';
		$heading_tag               = self::resolve_faq_child_title_heading_tag( $attrs, $parent_attrs );
		$dsm_child_open_font_icon  = $attrs['dsm_child_open_font_icon']['innerContent']['desktop']['value'] ?? '';
		$dsm_child_close_font_icon = $attrs['dsm_child_close_font_icon']['innerContent']['desktop']['value'] ?? '';
		$dsm_child_use_image       = $attrs['dsm_child_use_image']['innerContent']['desktop']['value'] ?? 'off';
		$dsm_open_child_image      = $attrs['dsm_open_child_image']['innerContent']['desktop']['value'] ?? '';
		$dsm_close_child_image     = $attrs['dsm_close_child_image']['innerContent']['desktop']['value'] ?? '';

		$faq_content_html      = $attrs['dsm_content']['innerContent']['desktop']['value']['text'] ?? '';
		$dsm_content_type      = $attrs['dsm_content_type']['innerContent']['desktop']['value'] ?? 'content';
		$dsm_shortcode_content = $attrs['dsm_shortcode_content']['innerContent']['desktop']['value'] ?? '';

		$faq_body_markup = '';
		if ( $has_nested_modules && '' !== trim( (string) $child_modules_content ) ) {
			$faq_body_markup = sprintf(
				'<div class="%1$s">%2$s</div>',
				esc_attr( $nestable_classes ),
				et_core_esc_previously( $child_modules_content )
			);
		} elseif ( 'content' === $dsm_content_type ) {
			$faq_body_markup = wp_kses_post( $faq_content_html );
		} else {
			$faq_body_markup = \DiviSupreme\Includes\DiviLibraryLayoutRenderer::render_shortcode_field_content(
				is_string( $dsm_shortcode_content ) ? $dsm_shortcode_content : '',
				'dsm_faq_shortcode_styles'
			);
		}

		$parent_open_font_icon  = $parent_attrs['dsm_open_font_icon']['innerContent']['desktop']['value'] ?? '';
		$parent_close_font_icon = $parent_attrs['dsm_close_font_icon']['innerContent']['desktop']['value'] ?? '';
		$parent_open_image      = $parent_attrs['dsm_open_image']['innerContent']['desktop']['value'] ?? '';
		$parent_close_image     = $parent_attrs['dsm_close_image']['innerContent']['desktop']['value'] ?? '';
		$dsm_icon_placement     = $parent_attrs['dsm_icon_placement']['innerContent']['desktop']['value'] ?? 'left';
		$parent_use_image       = $parent_attrs['dsm_use_image']['innerContent']['desktop']['value'] ?? '';

		$open_icon  = self::render_faq_toggle_icon(
			$dsm_child_open_font_icon,
			$parent_open_font_icon,
			'dsm_open_icon',
			'dsm_faq-item-open_icon'
		);
		$close_icon = self::render_faq_toggle_icon(
			$dsm_child_close_font_icon,
			$parent_close_font_icon,
			'dsm_close_icon',
			'dsm_faq-item-close_icon'
		);

		$parent_open_image_markup  = 'on' === $parent_use_image
			? self::render_faq_toggle_image_markup( $parent_open_image, 'dsm_open_image' )
			: '';
		$parent_close_image_markup = 'on' === $parent_use_image
			? self::render_faq_toggle_image_markup( $parent_close_image, 'dsm_close_image' )
			: '';

		$open_image  = 'off' === $dsm_child_use_image
			? $parent_open_image_markup
			: self::render_faq_toggle_image_markup( $dsm_open_child_image, 'dsm_open_image' );
		$close_image = 'off' === $dsm_child_use_image
			? $parent_close_image_markup
			: self::render_faq_toggle_image_markup( $dsm_close_child_image, 'dsm_close_image' );

		$container = sprintf(
			'<div class="dsm-title-wrapper">
				 <div class="dsm-title-inner-wrapper">
				   %3$s
				   %4$s
				   %9$s
				   %10$s
				   %1$s
				 </div> 
				 <div class="dsm-faq-item-inner-wrapper">
				   %5$s
				   %6$s
				   %7$s
				   %8$s
				 </div>
				</div>
				%2$s',
			'' !== $dsm_title ? sprintf( '<%2$s class="dsm-faq-title">%1$s</%2$s>', $dsm_title, esc_attr( $heading_tag ) ) : '',
			sprintf( '<div class="dsm-faq-content"><div>%1$s</div></div>', et_core_esc_previously( $faq_body_markup ) ),
			'left' === $dsm_icon_placement ? $open_icon : '',
			'left' === $dsm_icon_placement ? $close_icon : '',
			'right' === $dsm_icon_placement ? $open_icon : '',
			'right' === $dsm_icon_placement ? $close_icon : '',
			'left' === $dsm_icon_placement ? $open_image : '',
			'left' === $dsm_icon_placement ? $close_image : '',
			'right' === $dsm_icon_placement ? $open_image : '',
			'right' === $dsm_icon_placement ? $close_image : ''
		);

		// Module Inner.
		// Essentially, this is the module content.
		// Were wrapping the title and content in a div with class `et_pb_module_inner`.
		$module_inner = HTMLUtility::render(
			array(
				'tag'               => 'div',
				'attributes'        => array(
					'class' => 'et_pb_module_inner',
				),
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $container,
			)
		);

		// This are the module elements that will be rendered in the frontend.
		$module_elements = $elements->style_components(
			array(
				'attrName' => 'module',
			)
		);

		// This are the children of the module container, which are the module elements and the module inner.
		$module_container_children = $module_elements . $module_inner;

		return Module::render(
			array(
				// FE only.
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],

				// VB equivalent.
				'attrs'               => $attrs,
				'parentAttrs'         => \is_array( $parent_attrs ) ? $parent_attrs : array(),
				'elements'            => $elements,
				'id'                  => $block->parsed_block['id'],
				'moduleClassName'     => 'd5_tut_simple_quick_module',
				'name'                => $block->block_type->name,
				'classnamesFunction'  => array( self::class, 'module_classnames' ),
				'moduleCategory'      => $block->block_type->category,
				'stylesComponent'     => array( self::class, 'module_styles' ),
				'scriptDataComponent' => array( self::class, 'module_script_data' ),
				'childrenIds'         => $children_ids,
				'children'            => $module_container_children,
			)
		);
	}
}
