<?php
/**
 * Icon List Module.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Modules;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}


use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\Module\Options\Element\ElementClassnames;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Options\Element\ElementComponents;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;
use ET\Builder\Packages\Module\Options\Css\CssStyle;


/**
 * Class that handles "IconList Module" module.
 */
class IconList implements DependencyInterface {



	/**
	 * Register module.
	 * `DependencyInterface` interface ensures class method name `load()` is executed for initialization.
	 */
	public function load(): void {
		add_action( 'init', array( self::class, 'register_module' ) );
	}

	/**
	 * Initilises the module.
	 *
	 * @return void
	 */
	public static function dsm_initialise(): void {
		add_action(
			'divi_module_library_modules_dependency_tree',
			static function ( $dependency_tree ): void {
				$dependency_tree->add_dependency( new self() );
			}
		);
	}

	/**
	 * Register module.
	 */
	public static function register_module(): void {
		$module_json_path = DSM_DIR_PATH . 'divi-5/public/packages/module-library/icon-list';

		ModuleRegistration::register_module(
			$module_json_path,
			array(
				'render_callback' => array( self::class, 'render_callback' ),
			)
		);
	}

	/**
	 * Render module style.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_styles( array $args ): void {
		$args        = \DiviSupreme\Includes\DsmDiviBuilderCssScope::normalize_module_styles_args( $args );
		$attrs       = $args['attrs'] ?? array();
		$elements    = $args['elements'];
		$order_class = (string) ( $args['orderClass'] ?? '' );

		Style::add(
			array(
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => array(
					// Module.
					$elements->style(
						array(
							'attrName'   => 'module',
							'styleProps' => array(
								'disabledOn' => array(
									'disabledModuleVisibility' => $args['settings']['disabledModuleVisibility'] ?? null,
								),
							),
						)
					),

					CssStyle::style(
						array(
							'selector' => $order_class,
							'attr'     => $attrs['css'] ?? array(),
						)
					),

					$elements->style(
						array(
							'attrName' => 'icon_styling',
						)
					),

					$elements->style(
						array(
							'attrName' => 'text',
						)
					),

					$elements->style(
						array(
							'attrName' => 'list_padding',
						)
					),

					$elements->style(
						array(
							'attrName' => 'item_styling',
						)
					),

					$elements->style(
						array(
							'attrName' => 'image_styling',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$order_class} .dsm_icon_list_child .dsm_icon_list_icon",
							'attr'     => $attrs['icon_gap_width']['innerContent'] ?? array(),
							'property' => 'width',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$order_class} .dsm_icon_list_child .dsm_icon_list_icon",
							'attr'     => $attrs['icon_color']['innerContent'] ?? array(),
							'property' => 'color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$order_class} .dsm_icon_list_child .dsm_icon_list_icon",
							'attr'     => $attrs['icon_background_color']['innerContent'] ?? array(),
							'property' => 'background',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$order_class} .dsm_icon_list_child .dsm_icon_list_icon",
							'attr'     => $attrs['icon_padding']['innerContent'] ?? array(),
							'property' => 'padding',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$order_class} .dsm_icon_list_child .dsm_icon_list_icon",
							'attr'     => $attrs['icon_font_size']['innerContent'] ?? array(),
							'property' => 'font-size',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$order_class} .dsm_icon_list_child",
							'attr'     => $attrs['list_vertical_alignment']['innerContent'] ?? array(),
							'property' => 'align-items',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$order_class} .dsm_icon_list_child",
							'attr'     => $attrs['list_direction']['innerContent'] ?? array(),
							'property' => 'direction',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$order_class}.dsm_icon_list .dsm_icon_list_direction_left .dsm_icon_list_text",
							'attr'     => $attrs['text_indent']['innerContent'] ?? array(),
							'property' => 'padding-left',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$order_class}.dsm_icon_list .dsm_icon_list_direction_right .dsm_icon_list_text",
							'attr'     => $attrs['text_indent']['innerContent'] ?? array(),
							'property' => 'padding-right',
						)
					),

					CommonStyle::style(
						array(
							'selector'  => "{$order_class} .dsm_icon_list_layout_vertical .dsm_icon_list_child:not(:last-child)",
							'attr'      => $attrs['list_space_between']['innerContent'] ?? array(),
							'property'  => 'margin-bottom',
							'important' => true,
						)
					),

					CommonStyle::style(
						array(
							'selector'  => "{$order_class} .dsm_icon_list_layout_horizontal .dsm_icon_list_child:not(:last-child)",
							'attr'      => $attrs['list_space_between']['innerContent'] ?? array(),
							'property'  => 'margin-right',
							'important' => true,
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$order_class} .dsm_icon_list_layout_vertical .dsm_icon_list_child",
							'attr'     => $attrs['list_alignment']['innerContent'] ?? array(),
							'property' => 'justify-content',
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$order_class} .dsm_icon_list_layout_horizontal.dsm_icon_list_items",
							'attr'                => $attrs['list_alignment']['innerContent'] ?? array(),
							'declarationFunction' => function ( $params ) {
								$list_alignment_attr = $params['attrValue'] ?? array();

								$style_declarations = new StyleDeclarations(
									array(
										'returnType' => 'string',
										'important'  => array(
											'transform' => true,
										),
									)
								);

								$text_alignment_value = '';
								switch ( $list_alignment_attr ) {
									case 'flex-start':
										$text_alignment_value = 'left';
										break;
									case 'center':
										$text_alignment_value = 'center';
										break;
									case 'flex-end':
										$text_alignment_value = 'right';
										break;
								}

								$style_declarations->add( 'text-align', $text_alignment_value );

								return $style_declarations->value();
							},
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$order_class} .dsm_icon_list_child",
							'attr'     => $attrs['list_background']['innerContent'] ?? array(),
							'property' => 'background',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$order_class} .dsm_icon_list_items",
							'attr'     => $attrs['list_alignment']['innerContent'] ?? array(),
							'property' => 'background',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$order_class} .dsm_icon_list_image",
							'attr'     => $attrs['image_background_color']['innerContent'] ?? array(),
							'property' => 'background-color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$order_class} .dsm_icon_list_image",
							'attr'     => $attrs['image_padding']['innerContent'] ?? array(),
							'property' => 'padding',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$order_class} .dsm_icon_list_image img",
							'attr'     => $attrs['image_max_width']['innerContent'] ?? array(),
							'property' => 'width',
						)
					),
				),
			)
		);
	}

	/**
	 * Render module script data.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_script_data( array $args ): void {
		$elements = $args['elements'];

		// Element Script Data Options.
		$elements->script_data(
			array(
				'attrName' => 'module',
			)
		);
	}

	/**
	 * Render module classnames.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_classnames( array $args ): void {
		$classnames_instance = $args['classnamesInstance'];
		$attrs               = $args['attrs'];

		// Module.
		$classnames_instance->add(
			ElementClassnames::classnames(
				array(
					'attrs' => $attrs['module']['decoration'] ?? array(),
				)
			)
		);
	}

	/**
	 * Render module HTML output.
	 *
	 * @param array     $attrs - Modules Attributes.
	 * @param string    $content - Content.
	 * @param \WP_Block $block - Block.
	 * @param mixed     $elements - Elements.
	 */
	public static function render_callback( $attrs, $content, $block, $elements ): string {
		$children_ids = $block->parsed_block['innerBlocks'] ? array_map(
			static function ( $inner_block ) {
				return $inner_block['id'];
			},
			$block->parsed_block['innerBlocks']
		) : array();

		$parent          = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );
		$parent_attrs    = ( is_object( $parent ) && isset( $parent->attrs ) && is_array( $parent->attrs ) ) ? $parent->attrs : array();
		$list_layout_raw = $attrs['list_layout']['innerContent']['desktop']['value'] ?? '';
		$list_layout     = is_string( $list_layout_raw ) && '' !== $list_layout_raw ? $list_layout_raw : 'vertical';
		if ( ! in_array( $list_layout, array( 'vertical', 'horizontal' ), true ) ) {
			$list_layout = 'vertical';
		}
		$list_direction  = $attrs['list_direction']['innerContent']['desktop']['value'] ?? 'ltr';
		$direction_class = 'ltr' === $list_direction ? 'dsm_icon_list_direction_left' : 'dsm_icon_list_direction_right';

		wp_enqueue_script( 'dsm-popper' );
		wp_enqueue_script( 'dsm-tippy' );
		wp_enqueue_script( 'dsm-icon-list' );

		$icon_list = sprintf(
			'<ul class="dsm_icon_list_items %2$s %3$s">%1$s</ul>',
			$content,
			sprintf( 'dsm_icon_list_layout_%1$s', $list_layout ),
			$direction_class
		);

		// Module Inner.
		// Essentially, this is the module content.
		// Were wrapping the title and content in a div with class `et_pb_module_inner`.
		$module_inner = HTMLUtility::render(
			array(
				'tag'               => 'div',
				'attributes'        => array(
					'class' => 'et_pb_module_inner',
				),
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $icon_list,
			)
		);

		// This are the module elements that will be rendered in the frontend.
		$module_elements = $elements->style_components(
			array(
				'attrName' => 'module',
			)
		);

		// This are the children of the module container, which are the module elements and the module inner.
		$module_container_children = $module_elements . $icon_list;

		return Module::render(
			array(
				// FE only.
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],

				// VB equivalent.
				'attrs'               => $attrs,
				'parentAttrs'         => $parent_attrs,
				'elements'            => $elements,
				'id'                  => $block->parsed_block['id'],
				'moduleClassName'     => '',
				'name'                => $block->block_type->name,
				'classnamesFunction'  => array( self::class, 'module_classnames' ),
				'moduleCategory'      => $block->block_type->category,
				'stylesComponent'     => array( self::class, 'module_styles' ),
				'scriptDataComponent' => array( self::class, 'module_script_data' ),
				'children'            => ElementComponents::component(
					array(
						'attrs'         => $attrs['module']['decoration'] ?? array(),
						'id'            => $block->parsed_block['id'],

						// FE only.
						'orderIndex'    => $block->parsed_block['orderIndex'],
						'storeInstance' => $block->parsed_block['storeInstance'],
					)
				) . $module_container_children,
				'childrenIds'         => $children_ids,
			)
		);
	}
}
