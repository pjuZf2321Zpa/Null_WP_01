<?php
/**
 * Content Timeline Module.
 *
 * @package DiviSupreme.
 */

declare(strict_types=1);

namespace DiviSupreme\Modules;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\Module\Options\Element\ElementClassnames;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Options\Element\ElementComponents;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;


/**
 * Class that handles "ContentTimeline Module" module.
 */
class ContentTimeline implements DependencyInterface {



	/**
	 * Register module.
	 * `DependencyInterface` interface ensures class method name `load()` is executed for initialization.
	 */
	public function load() {
		add_action( 'init', array( self::class, 'register_module' ) );
	}

	/**
	 * Initilises the module.
	 *
	 * @return void
	 */
	public static function dsm_initialise() {
		add_action(
			'divi_module_library_modules_dependency_tree',
			function ( $dependency_tree ) {
				$dependency_tree->add_dependency( new self() );
			}
		);
	}

	/**
	 * Register module.
	 */
	public static function register_module() {

		$module_json_path = DSM_DIR_PATH . 'divi-5/public/packages/module-library/content-timeline';

		ModuleRegistration::register_module(
			$module_json_path,
			array(
				'render_callback' => array( self::class, 'render_callback' ),
			)
		);
	}

	/**
	 * Image icon align declaration.
	 *
	 * @param mixed $params Params.
	 */
	public static function image_icon_align_declaration( $params ) {
		$attr = $params['attrValue'] ?? array();

		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
				'important'  => array(
					'justify-content' => true,
				),
			)
		);

		$style_declarations->add( 'display', 'flex' );

		if ( 'left' === $attr ) {
			$style_declarations->add( 'justify-content', 'flex-start' );
		}

		if ( 'center' === $attr ) {
			$style_declarations->add( 'justify-content', 'center' );
		}

		if ( 'right' === $attr ) {
			$style_declarations->add( 'justify-content', 'flex-end' );
		}

		return $style_declarations->value();
	}


	/**
	 * Button align declaration.
	 *
	 * @param mixed $params Params.
	 */
	public static function button_align_declaration( $params ) {
		$attr = $params['attrValue'] ?? array();

		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
				'important'  => array(
					'justify-content' => true,
				),
			)
		);

		if ( 'left' === $attr ) {
			$style_declarations->add( 'text-align', 'left' );
		}

		if ( 'center' === $attr ) {
			$style_declarations->add( 'text-align', 'center' );
		}

		if ( 'right' === $attr ) {
			$style_declarations->add( 'text-align', 'right' );
		}

		return $style_declarations->value();
	}

	/**
	 * Render module style.
	 *
	 * @param array $args  - Arguments.
	 * @param mixed $block Block.
	 */
	public static function module_styles( $args, $block ) {
		$args     = \DiviSupreme\Includes\DsmDiviBuilderCssScope::normalize_module_styles_args( $args );
		$attrs    = $args['attrs'] ?? array();
		$elements = $args['elements'];

		Style::add(
			array(
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => array(
					// Module.
					$elements->style(
						array(
							'attrName'   => 'module',
							'styleProps' => array(
								'disabledOn' => array(
									'disabledModuleVisibility' => $args['settings']['disabledModuleVisibility'] ?? null,
								),
							),
						)
					),

					CssStyle::style(
						array(
							'selector' => $args['orderClass'],
							'attr'     => $attrs['css'] ?? array(),
						)
					),

					$elements->style(
						array(
							'attrName' => 'header',
						)
					),

					$elements->style(
						array(
							'attrName' => 'content',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_card_margin',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_card_padding',
						)
					),

					$elements->style(
						array(
							'attrName' => 'card_style',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_opposite_padding',
						)
					),

					$elements->style(
						array(
							'attrName' => 'opposite_text',
						)
					),

					$elements->style(
						array(
							'attrName' => 'opposite_text_style',
						)
					),

					$elements->style(
						array(
							'attrName' => 'image_icon_padding',
						)
					),

					$elements->style(
						array(
							'attrName' => 'image_icon_margin',
						)
					),

					$elements->style(
						array(
							'attrName' => 'image_icon_style',
						)
					),

					$elements->style(
						array(
							'attrName' => 'button',
						)
					),

					$elements->style(
						array(
							'attrName' => 'pointer_style',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-content-timeline-content-wrapper, {$args['orderClass']} .dsm-content-timeline-content-wrapper::before",
							'attr'     => $attrs['dsm_bg_color']['innerContent'] ?? array(),
							'property' => 'background-color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-content-timeline-date .date",
							'attr'     => $attrs['dsm_opposite_bg_color']['innerContent'] ?? array(),
							'property' => 'background-color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-content-timeline-date .date",
							'attr'     => $attrs['dsm_opposite_content_width']['innerContent'] ?? array(),
							'property' => 'width',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-content-timeline-middle-line, {$args['orderClass']} .dsm-content-timeline-middle .dsm-content-timeline-tree-animation",
							'attr'     => $attrs['dsm_tree_width']['innerContent'] ?? array(),
							'property' => 'width',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-content-timeline-middle-line",
							'attr'     => $attrs['dsm_tree_bg_color']['innerContent'] ?? array(),
							'property' => 'background-color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-content-timeline-middle .dsm-content-timeline-tree-animation",
							'attr'     => $attrs['dsm_tree_active_bg_color']['innerContent'] ?? array(),
							'property' => 'background-color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-content-timeline-middle-circle",
							'attr'     => $attrs['dsm_pointer_bg_color']['innerContent'] ?? array(),
							'property' => 'background-color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-content-timeline-middle-circle.dsm-timeline-pointer-active",
							'attr'     => $attrs['dsm_pointer_active_bg_color']['innerContent'] ?? array(),
							'property' => 'background-color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-content-timeline-middle-circle .et-pb-icon.dsm-icon",
							'attr'     => $attrs['dsm_pointer_icon_color']['innerContent'] ?? array(),
							'property' => 'color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-content-timeline-middle-circle.dsm-timeline-pointer-active .et-pb-icon.dsm-icon",
							'attr'     => $attrs['dsm_pointer_active_icon_color']['innerContent'] ?? array(),
							'property' => 'color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-content-timeline-items-wrapper",
							'attr'     => $attrs['dsm_horizontal_alignment']['innerContent'] ?? array(),
							'property' => 'text-align',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-icon-wrapper .et-pb-icon.dsm-icon",
							'attr'     => $attrs['dsm_icon_color']['innerContent'] ?? array(),
							'property' => 'color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-icon-wrapper .et-pb-icon.dsm-icon",
							'attr'     => $attrs['dsm_icon_bg_color']['innerContent'] ?? array(),
							'property' => 'background-color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-icon-wrapper .et-pb-icon.dsm-icon",
							'attr'     => $attrs['dsm_icon_font_size']['innerContent'] ?? array(),
							'property' => 'font-size',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-image-wrapper .dsm-image",
							'attr'     => $attrs['dsm_image_width']['innerContent'] ?? array(),
							'property' => 'max-width',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-content-timeline-middle-circle .dsm-image",
							'attr'     => $attrs['dsm_pointer_icon_font_size']['innerContent'] ?? array(),
							'property' => 'width',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-content-timeline-middle-circle .et-pb-icon.dsm-icon",
							'attr'     => $attrs['dsm_pointer_icon_font_size']['innerContent'] ?? array(),
							'property' => 'font-size',
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm-image-wrapper, {$args['orderClass']} .dsm-icon-wrapper",
							'attr'                => $attrs['dsm_icon_image_align']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'image_icon_align_declaration' ),
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .et_pb_button_module_wrapper",
							'attr'                => $attrs['button_alignment']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'button_align_declaration' ),
						)
					),

				),
			)
		);
	}

	/**
	 * Render module script data.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_script_data( $args ) {
		$elements = $args['elements'];

		// Element Script Data Options.
		$elements->script_data(
			array(
				'attrName' => 'module',
			)
		);
	}

	/**
	 * Render module classnames.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_classnames( $args ) {
		$classnames_instance = $args['classnamesInstance'];
		$attrs               = $args['attrs'];
		$timeline_style      = $attrs['dsm_timeline_style']['innerContent']['desktop']['value'] ?? 'center';
		$dsm_card_arrow      = $attrs['dsm_card_arrow']['innerContent']['desktop']['value'] ?? 'off';

		// Module.
		$classnames_instance->add(
			ElementClassnames::classnames(
				array(
					'attrs' => $attrs['module']['decoration'] ?? array(),
				)
			)
		);

		$classnames_instance->add( "dsm-timeline-$timeline_style" );

		if ( 'on' === $dsm_card_arrow ) {
			$classnames_instance->add( 'dsm-show-arrow' );
		}
	}

	/**
	 * Render module HTML output.
	 *
	 * @param array     $attrs - Modules Attributes.
	 * @param string    $content - Content.
	 * @param \WP_Block $block - Block.
	 * @param mixed     $elements - Elements.
	 */
	public static function render_callback( $attrs, $content, $block, $elements ) {
		$dsm_image_lightbox = $attrs['dsm_image_lightbox']['innerContent']['desktop']['value'] ?? 'off';
		if ( 'on' === $dsm_image_lightbox ) {
			if ( function_exists( 'dsm_ensure_registered_script_dependency' ) && function_exists( 'dsm_get_active_magnific_popup_script_handle' ) ) {
				dsm_ensure_registered_script_dependency(
					'dsm-content-timeline',
					dsm_get_active_magnific_popup_script_handle()
				);
			}
			if ( function_exists( 'dsm_enqueue_magnific_popup_assets' ) ) {
				dsm_enqueue_magnific_popup_assets();
			}
		}

		wp_enqueue_script( 'dsm-content-timeline' );

		$children_ids = $block->parsed_block['innerBlocks'] ? array_map(
			function ( $inner_block ) {
				return $inner_block['id'];
			},
			$block->parsed_block['innerBlocks']
		) : array();

		// Extract attributes from innerBlocks.
		$opposite_texts        = array();
		$has_any_opposite_text = false;
		if ( ! empty( $block->parsed_block['innerBlocks'] ) ) {
			foreach ( $block->parsed_block['innerBlocks'] as $inner_block ) {
				if ( isset( $inner_block['attrs'] ) ) {

					$opposite_text = $inner_block['attrs']['dsm_opposite_text']['innerContent']['desktop']['value'] ?? '';

					if ( ! empty( $opposite_text ) ) {
						$has_any_opposite_text = true;
						break;
					}
					$opposite_texts[] = $opposite_text;
				}
			}
		}

		$parent       = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );
		$parent_attrs = $parent->attrs ?? array();

		$timeline_style            = $attrs['dsm_timeline_style']['innerContent']['desktop']['value'] ?? 'center';
		$timeline_responsive_style = $attrs['dsm_responsive_style']['innerContent']['desktop']['value'] ?? $timeline_style;

		if ( 'select' === $timeline_responsive_style ) {
			$timeline_responsive_style = $timeline_style;
		}

		$tree_animation               = $attrs['dsm_tree_animation']['innerContent']['desktop']['value'] ?? 'off';
		$tree_animation_tablet        = $attrs['dsm_tree_animation']['innerContent']['tablet']['value'] ?? '';
		$tree_animation_mobile        = $attrs['dsm_tree_animation']['innerContent']['mobile']['value'] ?? '';
		$dsm_fill_animation_speed_raw = $attrs['dsm_fill_animation_speed']['innerContent']['desktop']['value'] ?? '100';
		$dsm_fill_animation_speed     = (string) max( 50, absint( $dsm_fill_animation_speed_raw ) );

		$item_scroll_animation      = $attrs['dsm_item_scroll_animation']['innerContent']['desktop']['value'] ?? 'off';
		$item_scroll_style_raw      = $attrs['dsm_item_scroll_style']['innerContent']['desktop']['value'] ?? 'alternate';
		$allowed_item_scroll_styles = array( 'alternate', 'from_left', 'from_right', 'fade' );
		$item_scroll_style          = in_array( $item_scroll_style_raw, $allowed_item_scroll_styles, true )
			? $item_scroll_style_raw
			: 'alternate';
		$item_scroll_duration_raw   = $attrs['dsm_item_scroll_duration']['innerContent']['desktop']['value'] ?? '600';
		$item_scroll_duration       = (string) max( 100, absint( $item_scroll_duration_raw ) );

		$timeline_region_label = __( 'Content timeline', 'dsm-supreme-modules-pro-for-divi' );

		$container = sprintf(
			'<div class="dsm-content-timeline-items-wrapper %1$s responsive-%2$s %3$s" style="--spacing: 50px; --tree-animation-speed: %9$s; --item-scroll-duration: %10$s;" data-image_lightbox="%7$s" data-tree-animation="%4$s" data-tree-animation-tablet="%5$s" data-tree-animation-mobile="%6$s" data-item-scroll-animation="%11$s" data-item-scroll-style="%12$s" role="region" aria-label="%13$s">%8$s</div>',
			$timeline_style,
			$timeline_responsive_style,
			! $has_any_opposite_text ? 'dsm-no-opposite-text' : '',
			$tree_animation,
			$tree_animation_tablet,
			$tree_animation_mobile,
			$dsm_image_lightbox,
			$content,
			$dsm_fill_animation_speed . 'ms',
			$item_scroll_duration . 'ms',
			\esc_attr( $item_scroll_animation ),
			\esc_attr( $item_scroll_style ),
			\esc_attr( $timeline_region_label )
		);

		$module_inner_classnames = array(
			'et_pb_module_inner',
			'dsm-content-timeline-container',
		);

		// Module Inner.
		// Essentially, this is the module content.
		// Were wrapping the title and content in a div with class `et_pb_module_inner`.
		$module_inner = HTMLUtility::render(
			array(
				'tag'               => 'div',
				'attributes'        => array(
					'class' => implode( ' ', $module_inner_classnames ),
				),
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $container,
			)
		);

		// This are the module elements that will be rendered in the frontend.
		$module_elements = $elements->style_components(
			array(
				'attrName' => 'module',
			)
		);

		// This are the children of the module container, which are the module elements and the module inner.
		$module_container_children = $module_elements . $module_inner;

		return Module::render(
			array(
				// FE only.
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],
				// VB equivalent.
				'attrs'               => $attrs,
				'parentAttrs'         => $parent_attrs,
				'elements'            => $elements,
				'id'                  => $block->parsed_block['id'],
				'moduleClassName'     => 'dsm_content_timeline',
				'name'                => $block->block_type->name,
				'classnamesFunction'  => array( self::class, 'module_classnames' ),
				'moduleCategory'      => $block->block_type->category,
				'stylesComponent'     => function ( $args ) use ( $block ) {
					return self::module_styles( $args, $block );
				},
				'scriptDataComponent' => array( self::class, 'module_script_data' ),
				'children'            => ElementComponents::component(
					array(
						'attrs'         => $attrs['module']['decoration'] ?? array(),
						'id'            => $block->parsed_block['id'],

						// FE only.
						'orderIndex'    => $block->parsed_block['orderIndex'],
						'storeInstance' => $block->parsed_block['storeInstance'],
					)
				) . $module_container_children,
				'childrenIds'         => $children_ids,
			)
		);
	}
}
