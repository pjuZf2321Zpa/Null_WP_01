<?php
/**
 * Supreme Testimonials parent module.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Modules;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use DiviSupreme\Extensions\IconLibraries\ExtensionSettings;
use DiviSupreme\Extensions\IconLibraries\IconGlyphRenderer;
use DiviSupreme\Extensions\IconLibraries\IconLibraryRegistry;
use DiviSupreme\Extensions\IconLibraries\IconProcessFontIconBridge;
use DiviSupreme\Extensions\IconLibraries\LegacyModuleIconStyles;
use DiviSupreme\Includes\Testimonials\Attrs;
use DiviSupreme\Includes\Testimonials\CardComposition;
use DiviSupreme\Includes\Testimonials\Items;
use DiviSupreme\Includes\Testimonials\Markup;
use DiviSupreme\Includes\Testimonials\Schema;
use DiviSupreme\Includes\DsmFrontendAssetRegistry;
use DiviSupreme\Includes\DsmFrontendModuleAssetRegistry;
use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\Module\Options\Element\ElementClassnames;
use ET\Builder\Packages\Module\Options\Element\ElementComponents;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;

/**
 * Parent module: layouts, sources, aggregate, collect form, schema.
 */
class Testimonials implements DependencyInterface {

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function load() {
		add_action( 'init', array( self::class, 'register_module' ) );
	}

	/**
	 * Dependency tree helper.
	 *
	 * @return void
	 */
	public static function dsm_initialise() {
		add_action(
			'divi_module_library_modules_dependency_tree',
			static function ( $dependency_tree ) {
				$dependency_tree->add_dependency( new self() );
			}
		);
	}

	/**
	 * Register the module.
	 *
	 * @return void
	 */
	public static function register_module() {
		$module_json_path = DSM_DIR_PATH . 'divi-5/public/packages/module-library/testimonials';

		ModuleRegistration::register_module(
			$module_json_path,
			array(
				'render_callback' => array( self::class, 'render_callback' ),
			)
		);
	}

	/**
	 * Grid column count CSS.
	 *
	 * @param array<string, mixed> $params Style params.
	 * @return string
	 */
	public static function columns_declaration( $params ) {
		$raw = $params['attrValue'] ?? '3';
		if ( is_array( $raw ) ) {
			$raw = $raw['value'] ?? '3';
		}

		$columns = max( 1, absint( $raw ) );
		$style   = new StyleDeclarations(
			array(
				'returnType' => 'string',
			)
		);
		$style->add( '--dsm-testimonials-columns', (string) $columns );
		return $style->value();
	}

	/**
	 * Grid/list gap CSS.
	 *
	 * @param array<string, mixed> $params Style params.
	 * @return string
	 */
	public static function gap_declaration( $params ) {
		$raw = $params['attrValue'] ?? '20px';
		if ( is_array( $raw ) ) {
			$raw = $raw['value'] ?? '20px';
		}

		if ( is_numeric( $raw ) ) {
			$raw = absint( $raw ) . 'px';
		} elseif ( ! is_string( $raw ) || '' === $raw ) {
			$raw = '20px';
		} elseif ( ! preg_match( '/[a-z%]+$/i', $raw ) ) {
			$raw = absint( $raw ) . 'px';
		}

		$style = new StyleDeclarations(
			array(
				'returnType' => 'string',
			)
		);
		$style->add( '--dsm-testimonials-gap', $raw );
		return $style->value();
	}

	/**
	 * Star color CSS custom property.
	 *
	 * @param array<string, mixed> $params Style params.
	 * @return string
	 */
	public static function stars_color_declaration( $params ) {
		$raw = $params['attrValue'] ?? '#f0ad4e';
		if ( is_array( $raw ) ) {
			$raw = $raw['hex'] ?? $raw['color'] ?? $raw['value'] ?? '#f0ad4e';
		}

		$color = is_string( $raw ) && '' !== trim( $raw ) ? trim( $raw ) : '#f0ad4e';
		$style = new StyleDeclarations(
			array(
				'returnType' => 'string',
			)
		);
		$style->add( '--dsm-testimonials-star-color', $color );
		return $style->value();
	}

	/**
	 * Star size CSS custom property.
	 *
	 * @param array<string, mixed> $params Style params.
	 * @return string
	 */
	public static function stars_size_declaration( $params ) {
		$raw = $params['attrValue'] ?? '16px';
		if ( is_array( $raw ) ) {
			$raw = $raw['value'] ?? '16px';
		}

		$style = new StyleDeclarations(
			array(
				'returnType' => 'string',
			)
		);
		$style->add( '--dsm-testimonials-star-size', is_string( $raw ) && '' !== $raw ? $raw : '16px' );
		return $style->value();
	}

	/**
	 * Star gap CSS custom property.
	 *
	 * @param array<string, mixed> $params Style params.
	 * @return string
	 */
	public static function stars_gap_declaration( $params ) {
		$raw = $params['attrValue'] ?? '2px';
		if ( is_array( $raw ) ) {
			$raw = $raw['value'] ?? '2px';
		}

		$style = new StyleDeclarations(
			array(
				'returnType' => 'string',
			)
		);
		$style->add( '--dsm-testimonials-star-gap', is_string( $raw ) && '' !== $raw ? $raw : '2px' );
		return $style->value();
	}

	/**
	 * Collect-form star color CSS custom property.
	 *
	 * @param array<string, mixed> $params Style params.
	 * @return string
	 */
	public static function collect_stars_color_declaration( $params ) {
		$style = new StyleDeclarations(
			array(
				'returnType' => 'string',
			)
		);
		$style->add( '--dsm-testimonials-collect-star-color', self::color_leaf( $params, '#f0ad4e' ) );
		return $style->value();
	}

	/**
	 * Collect-form star size CSS custom property.
	 *
	 * @param array<string, mixed> $params Style params.
	 * @return string
	 */
	public static function collect_stars_size_declaration( $params ) {
		$style = new StyleDeclarations(
			array(
				'returnType' => 'string',
			)
		);
		$style->add( '--dsm-testimonials-collect-star-size', self::size_leaf( $params, '16px' ) );
		return $style->value();
	}

	/**
	 * Collect-form star gap CSS custom property.
	 *
	 * @param array<string, mixed> $params Style params.
	 * @return string
	 */
	public static function collect_stars_gap_declaration( $params ) {
		$style = new StyleDeclarations(
			array(
				'returnType' => 'string',
			)
		);
		$style->add( '--dsm-testimonials-collect-star-gap', self::size_leaf( $params, '2px' ) );
		return $style->value();
	}

	/**
	 * Aggregate summary star color CSS custom property.
	 *
	 * @param array<string, mixed> $params Style params.
	 * @return string
	 */
	public static function aggregate_stars_color_declaration( $params ) {
		$style = new StyleDeclarations(
			array(
				'returnType' => 'string',
			)
		);
		$style->add( '--dsm-testimonials-aggregate-star-color', self::color_leaf( $params, '#f0ad4e' ) );
		return $style->value();
	}

	/**
	 * Aggregate summary star size CSS custom property.
	 *
	 * @param array<string, mixed> $params Style params.
	 * @return string
	 */
	public static function aggregate_stars_size_declaration( $params ) {
		$style = new StyleDeclarations(
			array(
				'returnType' => 'string',
			)
		);
		$style->add( '--dsm-testimonials-aggregate-star-size', self::size_leaf( $params, '16px' ) );
		return $style->value();
	}

	/**
	 * Aggregate summary star gap CSS custom property.
	 *
	 * @param array<string, mixed> $params Style params.
	 * @return string
	 */
	public static function aggregate_stars_gap_declaration( $params ) {
		$style = new StyleDeclarations(
			array(
				'returnType' => 'string',
			)
		);
		$style->add( '--dsm-testimonials-aggregate-star-gap', self::size_leaf( $params, '2px' ) );
		return $style->value();
	}

	/**
	 * Histogram track color CSS custom property.
	 *
	 * @param array<string, mixed> $params Style params.
	 * @return string
	 */
	public static function histogram_track_color_declaration( $params ) {
		$style = new StyleDeclarations(
			array(
				'returnType' => 'string',
			)
		);
		$style->add( '--dsm-testimonials-histogram-track', self::color_leaf( $params, '#eeeeee' ) );
		return $style->value();
	}

	/**
	 * Histogram fill color CSS custom property.
	 *
	 * @param array<string, mixed> $params Style params.
	 * @return string
	 */
	public static function histogram_fill_color_declaration( $params ) {
		$style = new StyleDeclarations(
			array(
				'returnType' => 'string',
			)
		);
		$style->add( '--dsm-testimonials-histogram-fill', self::color_leaf( $params, '#f0ad4e' ) );
		return $style->value();
	}

	/**
	 * Filter bar gap CSS custom property.
	 *
	 * @param array<string, mixed> $params Style params.
	 * @return string
	 */
	public static function filter_gap_declaration( $params ) {
		$style = new StyleDeclarations(
			array(
				'returnType' => 'string',
			)
		);
		$style->add( '--dsm-testimonials-filter-gap', self::size_leaf( $params, '12px' ) );
		return $style->value();
	}

	/**
	 * Filter dropdown caret color CSS custom property.
	 *
	 * @param array<string, mixed> $params Style params.
	 * @return string
	 */
	public static function filter_caret_color_declaration( $params ) {
		$style = new StyleDeclarations(
			array(
				'returnType' => 'string',
			)
		);
		$style->add( '--dsm-testimonials-filter-caret', self::color_leaf( $params, '#666666' ) );
		return $style->value();
	}

	/**
	 * Normalize a color leaf from CommonStyle params.
	 *
	 * @param array<string, mixed> $params Style params.
	 * @param string               $fallback Fallback color.
	 * @return string
	 */
	private static function color_leaf( $params, $fallback ) {
		$raw = $params['attrValue'] ?? $fallback;
		if ( is_array( $raw ) ) {
			$raw = $raw['hex'] ?? $raw['color'] ?? $raw['value'] ?? $fallback;
		}

		return is_string( $raw ) && '' !== trim( $raw ) ? trim( $raw ) : $fallback;
	}

	/**
	 * Normalize a size leaf and append px when unitless.
	 *
	 * @param array<string, mixed> $params Style params.
	 * @param string               $fallback Fallback size.
	 * @return string
	 */
	private static function size_leaf( $params, $fallback ) {
		$raw = $params['attrValue'] ?? $fallback;
		if ( is_array( $raw ) ) {
			$raw = $raw['value'] ?? $fallback;
		}

		if ( is_numeric( $raw ) ) {
			return absint( $raw ) . 'px';
		}

		if ( ! is_string( $raw ) || '' === $raw ) {
			return $fallback;
		}

		if ( ! preg_match( '/[a-z%]+$/i', $raw ) ) {
			return absint( $raw ) . 'px';
		}

		return $raw;
	}

	/**
	 * Normalize a signed offset leaf (negative px allowed).
	 *
	 * @param array<string, mixed> $params Style params.
	 * @param string               $fallback Fallback offset.
	 * @return string
	 */
	private static function offset_leaf( $params, $fallback ) {
		$raw = $params['attrValue'] ?? $fallback;
		if ( is_array( $raw ) ) {
			$raw = $raw['value'] ?? $fallback;
		}

		if ( is_numeric( $raw ) ) {
			return (int) $raw . 'px';
		}

		if ( ! is_string( $raw ) || '' === $raw ) {
			return $fallback;
		}

		if ( ! preg_match( '/[a-z%]+$/i', $raw ) ) {
			return (int) $raw . 'px';
		}

		return $raw;
	}

	/**
	 * Carousel arrow size CSS custom property.
	 *
	 * @param array<string, mixed> $params Style params.
	 * @return string
	 */
	public static function arrow_size_declaration( $params ) {
		$style = new StyleDeclarations(
			array(
				'returnType' => 'string',
			)
		);
		$style->add( '--dsm-testimonials-arrow-size', self::size_leaf( $params, '40px' ) );
		return $style->value();
	}

	/**
	 * Carousel arrow color CSS custom property.
	 *
	 * @param array<string, mixed> $params Style params.
	 * @return string
	 */
	public static function arrow_color_declaration( $params ) {
		$style = new StyleDeclarations(
			array(
				'returnType' => 'string',
			)
		);
		$style->add( '--dsm-testimonials-arrow-color', self::color_leaf( $params, '#666666' ) );
		return $style->value();
	}

	/**
	 * Carousel arrow background CSS custom property.
	 *
	 * @param array<string, mixed> $params Style params.
	 * @return string
	 */
	public static function arrow_background_declaration( $params ) {
		$color = self::color_leaf( $params, '' );
		$style = new StyleDeclarations(
			array(
				'returnType' => 'string',
			)
		);
		if ( '' !== $color ) {
			$style->add( '--dsm-testimonials-arrow-bg', $color );
		}
		return $style->value();
	}

	/**
	 * Pagination inactive color CSS custom property.
	 *
	 * @param array<string, mixed> $params Style params.
	 * @return string
	 */
	public static function pagination_color_declaration( $params ) {
		$style = new StyleDeclarations(
			array(
				'returnType' => 'string',
			)
		);
		$style->add( '--dsm-testimonials-pagination-color', self::color_leaf( $params, 'rgba(0,0,0,0.2)' ) );
		return $style->value();
	}

	/**
	 * Pagination active color CSS custom property.
	 *
	 * @param array<string, mixed> $params Style params.
	 * @return string
	 */
	public static function pagination_active_color_declaration( $params ) {
		$style = new StyleDeclarations(
			array(
				'returnType' => 'string',
			)
		);
		$style->add( '--dsm-testimonials-pagination-active-color', self::color_leaf( $params, '#007aff' ) );
		return $style->value();
	}

	/**
	 * Pagination size CSS custom property.
	 *
	 * @param array<string, mixed> $params Style params.
	 * @return string
	 */
	public static function pagination_size_declaration( $params ) {
		$style = new StyleDeclarations(
			array(
				'returnType' => 'string',
			)
		);
		$style->add( '--dsm-testimonials-pagination-size', self::size_leaf( $params, '8px' ) );
		return $style->value();
	}

	/**
	 * Carousel arrow vertical offset CSS custom property.
	 *
	 * @param array<string, mixed> $params Style params.
	 * @return string
	 */
	public static function arrow_vertical_offset_declaration( $params ) {
		$style = new StyleDeclarations(
			array(
				'returnType' => 'string',
			)
		);
		$style->add( '--dsm-testimonials-arrow-offset-y', self::offset_leaf( $params, '0px' ) );
		return $style->value();
	}

	/**
	 * Carousel arrow horizontal offset CSS custom property.
	 *
	 * @param array<string, mixed> $params Style params.
	 * @return string
	 */
	public static function arrow_horizontal_offset_declaration( $params ) {
		$style = new StyleDeclarations(
			array(
				'returnType' => 'string',
			)
		);
		$style->add( '--dsm-testimonials-arrow-offset-x', self::offset_leaf( $params, '0px' ) );
		return $style->value();
	}

	/**
	 * Carousel pagination vertical offset CSS custom property.
	 *
	 * @param array<string, mixed> $params Style params.
	 * @return string
	 */
	public static function pagination_vertical_offset_declaration( $params ) {
		$style = new StyleDeclarations(
			array(
				'returnType' => 'string',
			)
		);
		$style->add( '--dsm-testimonials-pagination-offset-y', self::offset_leaf( $params, '-28px' ) );
		return $style->value();
	}

	/**
	 * Marquee duration CSS custom property.
	 *
	 * @param array<string, mixed> $params Style params.
	 * @return string
	 */
	public static function ticker_duration_declaration( $params ) {
		$raw = $params['attrValue'] ?? '40s';
		if ( is_array( $raw ) ) {
			$raw = $raw['value'] ?? '40s';
		}

		if ( is_numeric( $raw ) ) {
			$raw = absint( $raw ) . 's';
		} elseif ( ! is_string( $raw ) || '' === $raw ) {
			$raw = '40s';
		} elseif ( ! preg_match( '/[a-z%]+$/i', $raw ) ) {
			$raw = absint( $raw ) . 's';
		}

		$style = new StyleDeclarations(
			array(
				'returnType' => 'string',
			)
		);
		$style->add( '--dsm-testimonials-ticker', $raw );
		return $style->value();
	}

	/**
	 * Marquee hover speed multiplier CSS custom property.
	 *
	 * @param array<string, mixed> $params Style params.
	 * @return string
	 */
	public static function hover_speed_factor_declaration( $params ) {
		$raw = $params['attrValue'] ?? '2';
		if ( is_array( $raw ) ) {
			$raw = $raw['value'] ?? '2';
		}

		$value = is_numeric( $raw ) ? (string) $raw : ( is_string( $raw ) && '' !== $raw ? $raw : '2' );
		$style = new StyleDeclarations(
			array(
				'returnType' => 'string',
			)
		);
		$style->add( '--dsm-testimonials-hover-speed-factor', $value );
		return $style->value();
	}

	/**
	 * Marquee edge fade size CSS custom property.
	 *
	 * @param array<string, mixed> $params Style params.
	 * @return string
	 */
	public static function fade_size_declaration( $params ) {
		$style = new StyleDeclarations(
			array(
				'returnType' => 'string',
			)
		);
		$style->add( '--dsm-testimonials-fade-size', self::size_leaf( $params, '80px' ) );
		return $style->value();
	}

	/**
	 * Quote accent bar color CSS custom property.
	 *
	 * @param array<string, mixed> $params Style params.
	 * @return string
	 */
	public static function quote_accent_color_declaration( $params ) {
		$style = new StyleDeclarations(
			array(
				'returnType' => 'string',
			)
		);
		$style->add( '--dsm-testimonials-quote-accent', self::color_leaf( $params, '#2EA3F2' ) );
		return $style->value();
	}

	/**
	 * Quote accent bar size CSS custom property.
	 *
	 * @param array<string, mixed> $params Style params.
	 * @return string
	 */
	public static function quote_accent_size_declaration( $params ) {
		$style = new StyleDeclarations(
			array(
				'returnType' => 'string',
			)
		);
		$style->add( '--dsm-testimonials-quote-accent-size', self::size_leaf( $params, '4px' ) );
		return $style->value();
	}

	/**
	 * Video poster overlay color CSS custom property.
	 *
	 * @param array<string, mixed> $params Style params.
	 * @return string
	 */
	public static function video_overlay_color_declaration( $params ) {
		$style = new StyleDeclarations(
			array(
				'returnType' => 'string',
			)
		);
		$style->add( '--dsm-testimonials-video-overlay', self::color_leaf( $params, 'rgba(0,0,0,0)' ) );
		return $style->value();
	}

	/**
	 * Video play icon color CSS custom property.
	 *
	 * @param array<string, mixed> $params Style params.
	 * @return string
	 */
	public static function video_icon_color_declaration( $params ) {
		$style = new StyleDeclarations(
			array(
				'returnType' => 'string',
			)
		);
		$style->add( '--dsm-testimonials-video-icon', self::color_leaf( $params, '#ffffff' ) );
		return $style->value();
	}

	/**
	 * Quote Style Icon CSS custom properties (Divi / FA only; empty keeps the default mark).
	 *
	 * @param array<string, mixed> $params Style params.
	 * @return string
	 */
	public static function quote_icon_declaration( $params ) {
		$style     = new StyleDeclarations(
			array(
				'returnType' => 'string',
			)
		);
		$icon_attr = is_array( $params['attrValue'] ?? null ) ? $params['attrValue'] : array();

		if (
			ExtensionSettings::is_extension_enabled()
			&& IconLibraryRegistry::is_dsm_library_icon( $icon_attr )
		) {
			return $style->value();
		}

		$content = LegacyModuleIconStyles::build_native_icon_css_content( $icon_attr );

		if ( '' === $content ) {
			return $style->value();
		}

		$font_family = 'ETmodules';

		if ( IconProcessFontIconBridge::uses_icon_manager_font_family() ) {
			$resolved_family = IconGlyphRenderer::icon_manager_font_family( $icon_attr );

			if ( '' !== $resolved_family ) {
				$font_family = $resolved_family;
			}
		} elseif ( isset( $icon_attr['type'] ) && 'fa' === $icon_attr['type'] ) {
			$font_family = 'FontAwesome';
		}
		$weight = isset( $icon_attr['weight'] ) && '' !== $icon_attr['weight']
			? (string) $icon_attr['weight']
			: '400';

		$style->add( '--dsm-testimonials-quote-icon-content', "'" . $content . "'" );
		$style->add( '--dsm-testimonials-quote-icon-family', "'" . $font_family . "'" );
		$style->add( '--dsm-testimonials-quote-icon-weight', $weight );

		return $style->value();
	}

	/**
	 * Module styles.
	 *
	 * @param array<string, mixed> $args Style args.
	 * @return void
	 */
	public static function module_styles( $args ) {
		$args     = \DiviSupreme\Includes\DsmDiviBuilderCssScope::normalize_module_styles_args( $args );
		$attrs    = $args['attrs'] ?? array();
		$elements = $args['elements'] ?? null;

		Style::add(
			array(
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => array(
					$elements->style(
						array(
							'attrName'   => 'module',
							'styleProps' => array(
								'disabledOn' => array(
									'disabledModuleVisibility' => $args['settings']['disabledModuleVisibility'] ?? null,
								),
							),
						)
					),
					CssStyle::style(
						array(
							'selector' => $args['orderClass'],
							'attr'     => $attrs['css'] ?? array(),
						)
					),
					$elements->style(
						array(
							'attrName' => 'dsm_author',
						)
					),
					$elements->style(
						array(
							'attrName' => 'dsm_meta',
						)
					),
					$elements->style(
						array(
							'attrName' => 'dsm_company',
						)
					),
					$elements->style(
						array(
							'attrName' => 'dsm_avatar_style',
						)
					),
					$elements->style(
						array(
							'attrName' => 'dsm_date',
						)
					),
					$elements->style(
						array(
							'attrName' => 'dsm_source_style',
						)
					),
					$elements->style(
						array(
							'attrName' => 'dsm_product_style',
						)
					),
					$elements->style(
						array(
							'attrName' => 'dsm_video_style',
						)
					),
					$elements->style(
						array(
							'attrName' => 'dsm_quote',
						)
					),
					$elements->style(
						array(
							'attrName' => 'card',
						)
					),
					$elements->style(
						array(
							'attrName' => 'arrowStyle',
						)
					),
					$elements->style(
						array(
							'attrName' => 'dsm_collect',
						)
					),
					$elements->style(
						array(
							'attrName' => 'dsm_collect_stars',
						)
					),
					$elements->style(
						array(
							'attrName' => 'dsm_collect_field',
						)
					),
					$elements->style(
						array(
							'attrName' => 'dsm_collect_label',
						)
					),
					$elements->style(
						array(
							'attrName' => 'dsm_collect_success_style',
						)
					),
					$elements->style(
						array(
							'attrName' => 'dsm_collect_button',
						)
					),
					$elements->style(
						array(
							'attrName' => 'dsm_aggregate_stars_style',
						)
					),
					$elements->style(
						array(
							'attrName' => 'dsm_aggregate_score',
						)
					),
					$elements->style(
						array(
							'attrName' => 'dsm_aggregate_count',
						)
					),
					$elements->style(
						array(
							'attrName' => 'dsm_histogram_text',
						)
					),
					$elements->style(
						array(
							'attrName' => 'dsm_histogram_style',
						)
					),
					$elements->style(
						array(
							'attrName' => 'dsm_filter',
						)
					),
					$elements->style(
						array(
							'attrName' => 'dsm_filter_bar',
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $args['orderClass'],
							'attr'                => Attrs::style_inner_content( $attrs, 'dsm_columns' ),
							'declarationFunction' => array( self::class, 'columns_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $args['orderClass'],
							'attr'                => Attrs::style_inner_content( $attrs, 'dsm_gap' ),
							'declarationFunction' => array( self::class, 'gap_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $args['orderClass'],
							'attr'                => Attrs::style_inner_content( $attrs, 'dsm_stars_color' ),
							'declarationFunction' => array( self::class, 'stars_color_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $args['orderClass'],
							'attr'                => Attrs::style_inner_content( $attrs, 'dsm_stars_size' ),
							'declarationFunction' => array( self::class, 'stars_size_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $args['orderClass'],
							'attr'                => Attrs::style_inner_content( $attrs, 'dsm_stars_gap' ),
							'declarationFunction' => array( self::class, 'stars_gap_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $args['orderClass'] . ' .dsm-testimonials-collect .dsm-star-rating',
							'attr'                => Attrs::style_inner_content( $attrs, 'dsm_collect_stars_color' ),
							'declarationFunction' => array( self::class, 'collect_stars_color_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $args['orderClass'] . ' .dsm-testimonials-collect .dsm-star-rating',
							'attr'                => Attrs::style_inner_content( $attrs, 'dsm_collect_stars_size' ),
							'declarationFunction' => array( self::class, 'collect_stars_size_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $args['orderClass'] . ' .dsm-testimonials-collect .dsm-star-rating',
							'attr'                => Attrs::style_inner_content( $attrs, 'dsm_collect_stars_gap' ),
							'declarationFunction' => array( self::class, 'collect_stars_gap_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $args['orderClass'],
							'attr'                => Attrs::style_inner_content( $attrs, 'dsm_aggregate_stars_color' ),
							'declarationFunction' => array( self::class, 'aggregate_stars_color_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $args['orderClass'],
							'attr'                => Attrs::style_inner_content( $attrs, 'dsm_aggregate_stars_size' ),
							'declarationFunction' => array( self::class, 'aggregate_stars_size_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $args['orderClass'],
							'attr'                => Attrs::style_inner_content( $attrs, 'dsm_aggregate_stars_gap' ),
							'declarationFunction' => array( self::class, 'aggregate_stars_gap_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $args['orderClass'],
							'attr'                => Attrs::style_inner_content( $attrs, 'dsm_histogram_track_color' ),
							'declarationFunction' => array( self::class, 'histogram_track_color_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $args['orderClass'],
							'attr'                => Attrs::style_inner_content( $attrs, 'dsm_histogram_fill_color' ),
							'declarationFunction' => array( self::class, 'histogram_fill_color_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $args['orderClass'],
							'attr'                => Attrs::style_inner_content( $attrs, 'dsm_filter_gap' ),
							'declarationFunction' => array( self::class, 'filter_gap_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $args['orderClass'],
							'attr'                => Attrs::style_inner_content( $attrs, 'dsm_filter_caret_color' ),
							'declarationFunction' => array( self::class, 'filter_caret_color_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $args['orderClass'],
							'attr'                => Attrs::style_inner_content( $attrs, 'arrow_size' ),
							'declarationFunction' => array( self::class, 'arrow_size_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $args['orderClass'],
							'attr'                => Attrs::style_inner_content( $attrs, 'arrow_color' ),
							'declarationFunction' => array( self::class, 'arrow_color_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $args['orderClass'],
							'attr'                => Attrs::style_inner_content( $attrs, 'arrow_background_color' ),
							'declarationFunction' => array( self::class, 'arrow_background_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $args['orderClass'],
							'attr'                => Attrs::style_inner_content( $attrs, 'dots_inactive_color' ),
							'declarationFunction' => array( self::class, 'pagination_color_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $args['orderClass'],
							'attr'                => Attrs::style_inner_content( $attrs, 'dots_active_color' ),
							'declarationFunction' => array( self::class, 'pagination_active_color_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $args['orderClass'],
							'attr'                => Attrs::style_inner_content( $attrs, 'dsm_pagination_size' ),
							'declarationFunction' => array( self::class, 'pagination_size_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $args['orderClass'],
							'attr'                => Attrs::style_inner_content( $attrs, 'dsm_arrow_vertical_offset' ),
							'declarationFunction' => array( self::class, 'arrow_vertical_offset_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $args['orderClass'],
							'attr'                => Attrs::style_inner_content( $attrs, 'dsm_arrow_horizontal_offset' ),
							'declarationFunction' => array( self::class, 'arrow_horizontal_offset_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $args['orderClass'],
							'attr'                => Attrs::style_inner_content( $attrs, 'dots_horizontal_placement' ),
							'declarationFunction' => array( self::class, 'pagination_vertical_offset_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $args['orderClass'],
							'attr'                => Attrs::style_inner_content( $attrs, 'dsm_marquee_speed' ),
							'declarationFunction' => array( self::class, 'ticker_duration_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $args['orderClass'],
							'attr'                => Attrs::style_inner_content( $attrs, 'dsm_hover_speed_factor' ),
							'declarationFunction' => array( self::class, 'hover_speed_factor_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $args['orderClass'],
							'attr'                => Attrs::style_inner_content( $attrs, 'dsm_edge_fade_size' ),
							'declarationFunction' => array( self::class, 'fade_size_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $args['orderClass'],
							'attr'                => Attrs::style_inner_content( $attrs, 'dsm_quote_accent_color' ),
							'declarationFunction' => array( self::class, 'quote_accent_color_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $args['orderClass'],
							'attr'                => Attrs::style_inner_content( $attrs, 'dsm_quote_accent_size' ),
							'declarationFunction' => array( self::class, 'quote_accent_size_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $args['orderClass'],
							'attr'                => Attrs::style_inner_content( $attrs, 'dsm_quote_icon' ),
							'declarationFunction' => array( self::class, 'quote_icon_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $args['orderClass'],
							'attr'                => Attrs::style_inner_content( $attrs, 'dsm_video_overlay_color' ),
							'declarationFunction' => array( self::class, 'video_overlay_color_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $args['orderClass'],
							'attr'                => Attrs::style_inner_content( $attrs, 'dsm_video_icon_color' ),
							'declarationFunction' => array( self::class, 'video_icon_color_declaration' ),
						)
					),
				),
			)
		);
	}

	/**
	 * Script data.
	 *
	 * @param array<string, mixed> $args Args.
	 * @return void
	 */
	public static function module_script_data( $args ) {
		$elements = $args['elements'];
		$elements->script_data(
			array(
				'attrName' => 'module',
			)
		);
	}

	/**
	 * Classnames.
	 *
	 * @param array<string, mixed> $args Args.
	 * @return void
	 */
	public static function module_classnames( $args ) {
		$classnames_instance = $args['classnamesInstance'];
		$attrs               = $args['attrs'];
		$layout              = Attrs::layout( $attrs, 'grid' );
		$source              = Attrs::inner_string( $attrs, 'dsm_source', 'visual' );

		$classnames_instance->add(
			ElementClassnames::classnames(
				array(
					'attrs' => $attrs['module']['decoration'] ?? array(),
				)
			)
		);

		$classnames_instance->add( 'dsm_testimonials' );
		$classnames_instance->add( 'dsm-testimonials-layout-' . sanitize_html_class( $layout ) );
		$classnames_instance->add( 'dsm-testimonials-source-' . sanitize_html_class( $source ) );

		if ( 'carousel' === $layout && Attrs::inner_on( $attrs, 'equal_height', 'on' ) ) {
			$classnames_instance->add( 'dsm-testimonials-equal-height' );
		}

		if ( Attrs::dsm_equal_height_on( $attrs ) ) {
			$classnames_instance->add( 'dsm-testimonials-equal-height' );
			$classnames_instance->add( 'dsm-testimonials-stretch-height' );
			$classnames_instance->add( 'dsm-testimonials-marquee-stretch' );
		}

		$quote_style = Attrs::inner_string( $attrs, 'dsm_quote_style', 'bar' );
		if ( ! in_array( $quote_style, array( 'bar', 'icon', 'none' ), true ) ) {
			$quote_style = 'bar';
		}
		$classnames_instance->add( 'dsm-testimonials-quote-style-' . sanitize_html_class( $quote_style ) );

		foreach ( CardComposition::classnames( $attrs ) as $composition_class ) {
			$classnames_instance->add( $composition_class );
		}

		if ( is_rtl() ) {
			$classnames_instance->add( 'dsm-testimonials-rtl' );
		}
	}

	/**
	 * Enqueue frontend CSS/JS for this module.
	 *
	 * @param string $layout Layout slug.
	 * @param bool   $has_video Whether any item has a video.
	 * @param bool   $has_form Whether the collect form is on.
	 * @return void
	 */
	public static function enqueue_assets( string $layout, bool $has_video, bool $has_form ): void {
		unset( $has_form );
		$is_vb = function_exists( 'et_core_is_fb_enabled' ) && et_core_is_fb_enabled();

		if ( function_exists( 'dsm_supreme_dynamic_assets_enabled' ) && dsm_supreme_dynamic_assets_enabled() && ! $is_vb ) {
			DsmFrontendModuleAssetRegistry::maybe_enqueue_split_frontend_stylesheet_for_block( 'dsm/testimonials' );
			DsmFrontendModuleAssetRegistry::maybe_enqueue_split_frontend_stylesheet_for_block( 'dsm/testimonial-item' );
		} elseif ( wp_style_is( DsmFrontendModuleAssetRegistry::CORE_MODULES_STYLE_HANDLE, 'registered' ) ) {
			wp_enqueue_style( DsmFrontendModuleAssetRegistry::CORE_MODULES_STYLE_HANDLE );
		}

		if ( 'carousel' === $layout && DsmFrontendAssetRegistry::should_wp_enqueue_module_styles( 'dsm/testimonials' ) ) {
			wp_enqueue_style( DsmFrontendModuleAssetRegistry::SWIPER_LIBRARY_STYLE_HANDLE );
		}

		if ( $has_video && function_exists( 'dsm_enqueue_magnific_popup_assets' ) ) {
			if ( function_exists( 'dsm_ensure_registered_script_dependency' ) && function_exists( 'dsm_get_active_magnific_popup_script_handle' ) ) {
				dsm_ensure_registered_script_dependency(
					'dsm-testimonials',
					dsm_get_active_magnific_popup_script_handle()
				);
			}
			dsm_enqueue_magnific_popup_assets();
		}

		if ( DsmFrontendAssetRegistry::should_wp_enqueue_module_scripts( 'dsm/testimonials' ) ) {
			if ( 'carousel' === $layout ) {
				if ( function_exists( 'dsm_ensure_registered_script_dependency' ) ) {
					dsm_ensure_registered_script_dependency( 'dsm-testimonials', 'dsm-swiper-library' );
				}
				wp_enqueue_script( 'dsm-swiper-library' );
			}
			wp_enqueue_script( 'dsm-testimonials' );
		}
	}

	/**
	 * Render.
	 *
	 * @param array<string, mixed> $attrs    Attrs.
	 * @param string               $content  Child HTML.
	 * @param \WP_Block            $block    Block.
	 * @param mixed                $elements Elements.
	 * @return string
	 */
	public static function render_callback( $attrs, $content, $block, $elements ) {
		$source      = Attrs::inner_string( $attrs, 'dsm_source', 'visual' );
		$layout      = Attrs::layout( $attrs, 'grid' );
		$show_agg    = Attrs::inner_on( $attrs, 'dsm_show_aggregate', 'on' );
		$histogram   = Attrs::inner_on( $attrs, 'dsm_show_histogram', 'on' );
		$show_filt   = Attrs::inner_on( $attrs, 'dsm_show_filters', 'off' ) && 'comments' !== $source;
		$show_source = Attrs::inner_on( $attrs, 'dsm_show_source', 'off' );
		$show_form   = Attrs::inner_on( $attrs, 'dsm_collect_form', 'off' );

		$query_args = array(
			'number'     => absint( Attrs::inner_string( $attrs, 'dsm_posts_number', '10' ) ),
			'order'      => Attrs::inner_string( $attrs, 'dsm_order', 'DESC' ),
			'orderby'    => Attrs::inner_string( $attrs, 'dsm_orderby', 'date' ),
			'min_rating' => Attrs::inner_string( $attrs, 'dsm_min_rating', '0' ),
			'tags'       => Attrs::inner_string( $attrs, 'dsm_tags_query', '' ),
			'product_id' => absint( Attrs::inner_string( $attrs, 'dsm_product_id', '0' ) ),
			'post_id'    => absint( Attrs::inner_string( $attrs, 'dsm_comments_post_id', '0' ) ),
		);

		$visual_items = array();
		$inner_blocks = isset( $block->parsed_block['innerBlocks'] ) && is_array( $block->parsed_block['innerBlocks'] )
			? $block->parsed_block['innerBlocks']
			: array();

		foreach ( $inner_blocks as $inner ) {
			if ( ! is_array( $inner ) || ( $inner['blockName'] ?? '' ) !== 'dsm/testimonial-item' ) {
				continue;
			}
			$child_attrs    = isset( $inner['attrs'] ) && is_array( $inner['attrs'] ) ? $inner['attrs'] : array();
			$visual_items[] = Items::from_child_attrs( $child_attrs, (string) ( $inner['id'] ?? '' ) );
		}

		$items = Items::from_source( $source, $query_args, $visual_items );

		$has_video = false;
		foreach ( $items as $item ) {
			if ( ! empty( $item['video_url'] ) ) {
				$has_video = true;
				break;
			}
		}

		self::enqueue_assets( $layout, $has_video, $show_form );

		if ( 'visual' === $source ) {
			$cards_html = (string) $content;
			if ( 'carousel' === $layout ) {
				$cards_html = Markup::layout_wrap( $cards_html, 'carousel', $attrs );
			} elseif ( 'marquee' === $layout ) {
				$cards_html = Markup::layout_wrap( $cards_html, 'marquee', $attrs );
			} else {
				$cards_html = Markup::layout_wrap( $cards_html, $layout, $attrs );
			}
		} else {
			$cards = '';
			foreach ( $items as $item ) {
				$cards .= Markup::as_slide( Markup::card( $item, '', $show_source ), $layout );
			}
			$cards_html = Markup::layout_wrap( $cards, $layout, $attrs );
		}

		$form = $show_form ? Markup::collect_form( $attrs ) : '';
		$ld   = Schema::script( $items, $attrs );

		$chrome_html = array(
			'aggregate' => $show_agg ? Markup::aggregate( $items, $histogram ) : '',
			'filters'   => $show_filt ? Markup::filters( $items, $source ) : '',
			'items'     => $cards_html,
			'form'      => $form,
		);

		$inner = '';
		foreach ( Attrs::visible_chrome_sections( $attrs, $layout, $show_agg, $show_filt, $show_form ) as $section_id ) {
			if ( isset( $chrome_html[ $section_id ] ) ) {
				$inner .= $chrome_html[ $section_id ];
			}
		}
		$inner .= $ld;

		$module_inner = HTMLUtility::render(
			array(
				'tag'               => 'div',
				'attributes'        => array(
					'class' => 'et_pb_module_inner',
				),
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $inner,
			)
		);

		$module_elements = $elements->style_components(
			array(
				'attrName' => 'module',
			)
		);

		$children_ids = array_map(
			static function ( $inner_block ) {
				return $inner_block['id'] ?? '';
			},
			$inner_blocks
		);

		$parent       = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );
		$parent_attrs = $parent->attrs ?? array();

		return Module::render(
			array(
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],
				'attrs'               => $attrs,
				'parentAttrs'         => $parent_attrs,
				'elements'            => $elements,
				'id'                  => $block->parsed_block['id'],
				'moduleClassName'     => '',
				'name'                => $block->block_type->name,
				'classnamesFunction'  => array( self::class, 'module_classnames' ),
				'moduleCategory'      => $block->block_type->category,
				'stylesComponent'     => array( self::class, 'module_styles' ),
				'scriptDataComponent' => array( self::class, 'module_script_data' ),
				'children'            => et_core_esc_previously(
					ElementComponents::component(
						array(
							'attrs'         => $attrs['module']['decoration'] ?? array(),
							'id'            => $block->parsed_block['id'],
							'orderIndex'    => $block->parsed_block['orderIndex'],
							'storeInstance' => $block->parsed_block['storeInstance'],
						)
					)
				) . et_core_esc_previously( $module_elements ) . et_core_esc_previously( $module_inner ),
				'childrenIds'         => $children_ids,
			)
		);
	}
}
