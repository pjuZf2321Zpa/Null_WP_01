<?php
/**
 * RandomImage Module.
 *
 * @package DiviSupreme.
 */

declare(strict_types=1);

namespace DiviSupreme\Modules;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\Module\Options\Element\ElementClassnames;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use ET\Builder\Packages\Module\Options\Text\TextStyle;
use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use DiviSupreme\Includes\ModuleRegisterAttrsNormalize;
use DiviSupreme\Extensions\IconLibraries\LegacyModuleIconStyles;

/**
 * Class that handles "RandomImage Module" module.
 */
class RandomImage implements DependencyInterface {



	/**
	 * Register module.
	 * `DependencyInterface` interface ensures class method name `load()` is executed for initialization.
	 */
	public function load() {
		add_action( 'init', array( self::class, 'register_module' ) );
		add_filter(
			'divi_module_library_register_module_attrs',
			array( self::class, 'ensure_overlay_toggle_defaults' ),
			10,
			2
		);
	}

	/**
	 * Restore overlay toggles when omitted from stored attrs (legacy: matched module.json schema defaults).
	 *
	 * @param array $module_attrs Merged module attrs.
	 * @param array $args         Contains `name`, `attrs`, etc.
	 * @return array
	 */
	public static function ensure_overlay_toggle_defaults( $module_attrs, $args ) {
		if ( ! is_array( $module_attrs ) ) {
			return $module_attrs;
		}
		if ( ( $args['name'] ?? '' ) !== 'dsm/random-image' ) {
			return $module_attrs;
		}

		$attrs = $module_attrs;
		ModuleRegisterAttrsNormalize::random_image_overlay_toggles( $attrs );

		return $attrs;
	}

	/**
	 * Initilises the module.
	 *
	 * @return void
	 */
	public static function dsm_initialise() {
		add_action(
			'divi_module_library_modules_dependency_tree',
			function ( $dependency_tree ) {
				$dependency_tree->add_dependency( new self() );
			}
		);
	}

	/**
	 * Register module.
	 */
	public static function register_module() {

		$module_json_path = DSM_DIR_PATH . 'divi-5/public/packages/module-library/random-image';

		ModuleRegistration::register_module(
			$module_json_path,
			array(
				'render_callback' => array( self::class, 'render_callback' ),
			)
		);
	}


	/**
	 * Overlay icon style declaration.
	 *
	 * @param mixed $params Params.
	 */
	public static function overlay_icon_style_declaration( $params ) {
		return LegacyModuleIconStyles::build_pseudo_icon_declaration( $params );
	}

	/**
	 * Render module style.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_styles( $args ) {
		$args     = \DiviSupreme\Includes\DsmDiviBuilderCssScope::normalize_module_styles_args( $args );
		$attrs    = $args['attrs'] ?? array();
		$elements = $args['elements'];

		Style::add(
			array(
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => array(
					// Module.
					$elements->style(
						array(
							'attrName'   => 'module',
							'styleProps' => array(
								'disabledOn' => array(
									'disabledModuleVisibility' => $args['settings']['disabledModuleVisibility'] ?? null,
								),
							),
						)
					),

					TextStyle::style(
						array(
							'selector' => $args['orderClass'],
							'attr'     => $attrs['module']['advanced']['text'] ?? array(),
						)
					),

					CssStyle::style(
						array(
							'selector' => $args['orderClass'],
							'attr'     => $attrs['css'] ?? array(),
						)
					),

					$elements->style(
						array(
							'attrName' => 'header',
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .et_pb_has_overlay .et_overlay::before",
							'attr'                => $attrs['hover_icon']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'overlay_icon_style_declaration' ),
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .et_overlay:before",
							'attr'     => $attrs['overlay_icon_color']['innerContent'] ?? array(),
							'property' => 'color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .et_overlay",
							'attr'     => $attrs['hover_overlay_color']['innerContent'] ?? array(),
							'property' => 'background-color',
						)
					),
				),
			)
		);
	}

	/**
	 * Render module script data.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_script_data( $args ) {
		$elements = $args['elements'];

		// Element Script Data Options.
		$elements->script_data(
			array(
				'attrName' => 'module',
			)
		);
	}

	/**
	 * Render module classnames.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_classnames( $args ) {
		$classnames_instance = $args['classnamesInstance'];
		$attrs               = $args['attrs'];

		// Module.
		$classnames_instance->add(
			ElementClassnames::classnames(
				array(
					'attrs' => $attrs['module']['decoration'] ?? array(),
				)
			)
		);
	}

	/**
	 * Normalize gallery ID attribute to a list of attachment IDs.
	 *
	 * @param mixed $gallery_ids Raw `gallery_ids` from attrs or args.
	 * @return list<int>
	 */
	private static function normalize_gallery_id_list( $gallery_ids ): array {
		if ( is_array( $gallery_ids ) && isset( $gallery_ids['innerContent']['desktop']['value'] ) ) {
			$gallery_ids = $gallery_ids['innerContent']['desktop']['value'];
		}
		if ( ! is_array( $gallery_ids ) ) {
			$gallery_ids = explode( ',', (string) $gallery_ids );
		}
		return array_values( array_filter( array_map( 'intval', $gallery_ids ) ) );
	}

	/**
	 * Load gallery attachments in gallery order.
	 *
	 * @param array $gallery_ids Attachment IDs.
	 * @return list<\WP_Post>
	 */
	private static function get_gallery_attachment_posts( array $gallery_ids ): array {
		if ( array() === $gallery_ids ) {
			return array();
		}
		$attachments_args = array(
			'include'        => $gallery_ids,
			'post_status'    => 'inherit',
			'post_type'      => 'attachment',
			'post_mime_type' => 'image',
			'order'          => 'ASC',
			'orderby'        => 'post__in',
		);
		$posts            = get_posts( $attachments_args );
		return is_array( $posts ) ? $posts : array();
	}

	/**
	 * Build image HTML for one attachment (wrap, overlay, link/lightbox).
	 *
	 * @param \WP_Post             $attachment Attachment post.
	 * @param array<string, mixed> $args       Gallery options (sizes, overlay, lightbox, …).
	 * @return string
	 */
	private static function build_attachment_gallery_markup( \WP_Post $attachment, array $args ): string {
		$image_id = isset( $attachment->ID ) ? (int) $attachment->ID : 0;
		if ( $image_id <= 0 ) {
			return '';
		}

		$dsm_upload_gallery_custom_link_url = get_post_meta( $image_id, 'dsm_upload_gallery_custom_link_url', true );
		$dsm_upload_gallery_link_url_target = get_post_meta( $image_id, 'dsm_upload_gallery_link_url_target', true );

		$image_src = wp_get_attachment_image_src( $image_id, $args['sizes'] );

		if ( ! $image_src || ! is_array( $image_src ) || count( $image_src ) < 3 ) {
			return '';
		}

		$image_url = $image_src[0];

		$use_overlay      = isset( $args['use_overlay'] ) ? $args['use_overlay'] : 'off';
		$overlay_on_hover = isset( $args['overlay_on_hover'] ) ? $args['overlay_on_hover'] : 'on';

		$image_output = sprintf(
			'<span class="et_pb_image_wrap%3$s%4$s%5$s">%1$s%2$s</span>',
			wp_get_attachment_image(
				$image_id,
				$args['sizes'],
				false,
				array(
					'class' => 'wp-image-' . esc_attr( (string) $image_id ),
					'title' => get_the_title( $image_id ),
				)
			),
			'on' === $use_overlay ? sprintf( '<span class="et_overlay"></span>' ) : '',
			'on' === $use_overlay ? esc_attr( ' et_pb_has_overlay' ) : '',
			'off' === $overlay_on_hover ? esc_attr( ' dsm_random_image_overlay_off' ) : '',
			pathinfo( $image_url, PATHINFO_EXTENSION ) === 'svg' ? esc_attr( ' dsm_random_image_svg' ) : ''
		);

		$url_new_window    = isset( $args['url_new_window'] ) ? $args['url_new_window'] : 'off';
		$is_url_new_window = 'on' === $url_new_window ? '_blank' : '_self';

		$use_image_link_url = isset( $args['use_image_link_url'] ) ? $args['use_image_link_url'] : 'off';
		$show_in_lightbox   = isset( $args['show_in_lightbox'] ) ? $args['show_in_lightbox'] : 'off';

		if ( 'on' === $use_image_link_url || ( isset( $dsm_upload_gallery_custom_link_url ) && '' !== $dsm_upload_gallery_custom_link_url ) ) {
			return sprintf(
				'<a href="%1$s" target="%3$s" title="%2$s">%4$s</a>',
				esc_url( (string) $dsm_upload_gallery_custom_link_url ),
				esc_attr( get_the_title( $image_id ) ),
				! empty( $dsm_upload_gallery_link_url_target ) ? esc_attr( (string) $dsm_upload_gallery_link_url_target ) : esc_attr( $is_url_new_window ),
				$image_output // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			);
		}
		if ( 'on' === $show_in_lightbox ) {
			$lightbox_image_src = wp_get_attachment_image_src( $image_id, $args['lightbox_img_sizes'] );
			if ( $lightbox_image_src && is_array( $lightbox_image_src ) && isset( $lightbox_image_src[0] ) ) {
				return sprintf(
					'<a href="%1$s" class="et_pb_image et_pb_lightbox_image dsm-image-lightbox" title="%2$s">%3$s</a>',
					esc_url( $lightbox_image_src[0] ),
					esc_attr( get_the_title( $image_id ) ),
					$image_output // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				);
			}
		}

		return $image_output;
	}

	/**
	 * Build one HTML fragment per gallery image (same shape as legacy `get_gallery` output).
	 *
	 * @param array<string, mixed> $args Parsed gallery args (`gallery_ids`, `sizes`, …).
	 * @return list<string>
	 */
	public static function get_gallery_markup_variants( array $args ): array {
		$defaults = array(
			'gallery_ids'        => array(),
			'sizes'              => 'full',
			'use_image_link_url' => 'off',
			'url_new_window'     => 'off',
			'show_in_lightbox'   => 'off',
			'lightbox_img_sizes' => 'full',
			'use_overlay'        => 'off',
			'overlay_on_hover'   => 'on',
			'hover_icon'         => '',
			'hover_icon_tablet'  => '',
			'hover_icon_phone'   => '',
		);
		$args     = wp_parse_args( $args, $defaults );

		$gallery_ids = self::normalize_gallery_id_list( $args['gallery_ids'] ?? array() );
		if ( array() === $gallery_ids ) {
			return array();
		}
		$args['gallery_ids'] = $gallery_ids;

		$attachments = self::get_gallery_attachment_posts( $gallery_ids );
		$out         = array();
		foreach ( $attachments as $attachment ) {
			if ( ! $attachment instanceof \WP_Post ) {
				continue;
			}
			$fragment = self::build_attachment_gallery_markup( $attachment, $args );
			if ( '' !== $fragment ) {
				$out[] = $fragment;
			}
		}
		return $out;
	}

	/**
	 * Legacy: return one random fragment (server-side). Prefer `get_gallery_markup_variants` + client script when cache is used.
	 *
	 * @param array<string, mixed> $args             Gallery options.
	 * @param array<string, mixed> $conditional_tags Unused.
	 * @param array<string, mixed> $current_page     Unused.
	 * @return string
	 */
	public static function get_gallery( $args = array(), $conditional_tags = array(), $current_page = array() ) {
		unset( $conditional_tags, $current_page );

		$variants = self::get_gallery_markup_variants( is_array( $args ) ? $args : array() );
		if ( array() === $variants ) {
			return '';
		}
		return $variants[ array_rand( $variants ) ];
	}

	/**
	 * Render module HTML output.
	 *
	 * @param array     $attrs - Modules Attributes.
	 * @param string    $content - Content.
	 * @param \WP_Block $block - Block.
	 * @param mixed     $elements - Elements.
	 */
	public static function render_callback( $attrs, $content, $block, $elements ) {

		$gallery_ids        = isset( $attrs['gallery_ids']['innerContent']['desktop']['value'] ) ? $attrs['gallery_ids']['innerContent']['desktop']['value'] : '';
		$sizes              = isset( $attrs['sizes']['innerContent']['desktop']['value'] ) ? $attrs['sizes']['innerContent']['desktop']['value'] : 'full';
		$use_image_link_url = isset( $attrs['use_image_link_url']['innerContent']['desktop']['value'] ) ? $attrs['use_image_link_url']['innerContent']['desktop']['value'] : 'off';
		$url_new_window     = isset( $attrs['url_new_window']['innerContent']['desktop']['value'] ) ? $attrs['url_new_window']['innerContent']['desktop']['value'] : 'off';
		$show_in_lightbox   = isset( $attrs['show_in_lightbox']['innerContent']['desktop']['value'] ) ? $attrs['show_in_lightbox']['innerContent']['desktop']['value'] : 'off';
		$lightbox_img_sizes = isset( $attrs['lightbox_img_sizes']['innerContent']['desktop']['value'] ) ? $attrs['lightbox_img_sizes']['innerContent']['desktop']['value'] : 'full';
		$use_overlay        = isset( $attrs['use_overlay']['innerContent']['desktop']['value'] ) ? $attrs['use_overlay']['innerContent']['desktop']['value'] : 'off';
		$overlay_on_hover   = isset( $attrs['overlay_on_hover']['innerContent']['desktop']['value'] ) ? $attrs['overlay_on_hover']['innerContent']['desktop']['value'] : 'on';

		if ( 'on' === $show_in_lightbox && function_exists( 'dsm_enqueue_magnific_popup_assets' ) ) {
			dsm_enqueue_magnific_popup_assets();
		}

		$variant_args = array(
			'gallery_ids'        => $gallery_ids,
			'sizes'              => $sizes,
			'use_image_link_url' => $use_image_link_url,
			'url_new_window'     => $url_new_window,
			'show_in_lightbox'   => $show_in_lightbox,
			'lightbox_img_sizes' => $lightbox_img_sizes,
			'use_overlay'        => $use_overlay,
			'overlay_on_hover'   => $overlay_on_hover,
		);

		$variants = self::get_gallery_markup_variants( $variant_args );
		if ( array() === $variants ) {
			return '';
		}

		$use_client_pick = count( $variants ) > 1 && apply_filters( 'dsm_random_image_use_client_side_pick', true, $variants, $attrs );

		if ( $use_client_pick ) {
			wp_enqueue_script( 'dsm-random-image' );
			$templates = '';
			foreach ( $variants as $html ) {
				$templates .= '<template class="dsm-random-image__tpl">' . $html . '</template>';
			}
			$gallery_output = '<div class="dsm-random-image__root" data-dsm-random-image-hydrate="1"><div class="dsm-random-image__slot"></div>' . $templates . '</div>';
		} else {
			$gallery_output = $variants[0];
		}

		$container = sprintf(
			'<div class="et_pb_module_inner">%s</div>',
			$gallery_output
		);

		// Module Inner.
		// Essentially, this is the module content.
		// Were wrapping the title and content in a div with class `et_pb_module_inner`.
		$module_inner = HTMLUtility::render(
			array(
				'tag'               => 'div',
				'attributes'        => array(
					'class' => 'et_pb_module_inner',
				),
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $container,
			)
		);

		// This are the module elements that will be rendered in the frontend.
		$module_elements = $elements->style_components(
			array(
				'attrName' => 'module',
			)
		);

		// This are the children of the module container, which are the module elements and the module inner.
		$module_container_children = $module_elements . $module_inner;

		return Module::render(
			array(
				// FE only.
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],
				// VB equivalent.
				'attrs'               => $attrs,
				'elements'            => $elements,
				'id'                  => $block->parsed_block['id'],
				'name'                => $block->block_type->name,
				'classnamesFunction'  => array( self::class, 'module_classnames' ),
				'moduleCategory'      => $block->block_type->category,
				'stylesComponent'     => array( self::class, 'module_styles' ),
				'scriptDataComponent' => array( self::class, 'module_script_data' ),
				'children'            => $module_container_children,
			)
		);
	}
}
