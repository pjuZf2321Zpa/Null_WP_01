<?php
/**
 * Supreme Table module (Divi 5) — Manual grid + Phase 2 sources + Phase 3 sort.
 *
 * Rows/columns/cells live in one versioned `table_grid` JSON attr on the parent.
 * No child modules. Remote CSV / Sheets / JSON and Loop are first-party
 * (no Tabulator / PapaParse / SheetJS).
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Modules;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use DiviSupreme\Extensions\IconLibraries\IconGlyphRenderer;
use DiviSupreme\Includes\DsmTableLibrary;
use DiviSupreme\Includes\DsmTableSource;
use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use ET\Builder\Packages\Module\Layout\Components\DynamicData\DynamicData;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\Module\Options\Element\ElementClassnames;
use ET\Builder\Packages\Module\Options\Text\TextStyle;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;
use WP_Error;
use WP_REST_Request;
use WP_REST_Server;

/**
 * Handles the Supreme Table parent module.
 */
class Table implements DependencyInterface {

	/**
	 * Grid JSON schema version (Phase 1 lock).
	 *
	 * @var int
	 */
	private const SCHEMA_VERSION = 1;

	/**
	 * Maximum editor / Add Row / Confirm snapshot rows (includes header).
	 *
	 * File CSV import and Live remote use {@see DsmTableSource::get_import_max_rows()}.
	 *
	 * @var int
	 */
	private const MAX_ROWS = 100;

	/**
	 * Maximum columns.
	 *
	 * @var int
	 */
	private const MAX_COLS = 20;

	/**
	 * Allowed cell types. Unknown types degrade to escaped text.
	 *
	 * @var array<int, string>
	 */
	private const CELL_TYPES = array(
		'text',
		'rich_text',
		'image',
		'icon',
		'button',
		'star_rating',
		'icon_list',
		'badge',
		'shortcode',
	);

	/**
	 * Allowed row roles.
	 *
	 * @var array<int, string>
	 */
	private const ROW_ROLES = array( 'header', 'body', 'footer', 'cta' );

	/**
	 * Initialize module registration.
	 *
	 * @return void
	 */
	public function load(): void {
		add_action( 'init', array( self::class, 'register_module' ) );
		add_action( 'rest_api_init', array( self::class, 'register_rest_routes' ) );
	}

	/**
	 * Register with the Divi 5 module library.
	 *
	 * @return void
	 */
	public static function register_module(): void {
		$module_json_path = DSM_DIR_PATH . 'divi-5/public/packages/module-library/table';

		ModuleRegistration::register_module(
			$module_json_path,
			array(
				'render_callback' => array( self::class, 'render_callback' ),
			)
		);
	}

	/**
	 * REST: VB preview + public Live refresh for remote Table sources.
	 *
	 * Server-side fetch only — SSRF-hardened via {@see DsmTableSource}.
	 *
	 * @return void
	 */
	public static function register_rest_routes(): void {
		register_rest_route(
			'dsm/v1',
			'/table-source',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( self::class, 'rest_table_source' ),
				'permission_callback' => static function () {
					return current_user_can( 'edit_posts' );
				},
				'args'                => array(
					'url'     => array(
						'type'              => 'string',
						'required'          => true,
						'sanitize_callback' => 'esc_url_raw',
					),
					'source'  => array(
						'type'              => 'string',
						'required'          => false,
						'default'           => 'csv',
						'sanitize_callback' => 'sanitize_key',
					),
					'nocache' => array(
						'type'    => 'boolean',
						'default' => false,
					),
				),
			)
		);

		register_rest_route(
			'dsm/v1',
			'/table-live',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( self::class, 'rest_table_live' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'url'    => array(
						'type'              => 'string',
						'required'          => true,
						'sanitize_callback' => 'esc_url_raw',
					),
					'source' => array(
						'type'              => 'string',
						'required'          => false,
						'default'           => 'csv',
						'sanitize_callback' => 'sanitize_key',
					),
					'header' => array(
						'type'    => 'boolean',
						'default' => true,
					),
				),
			)
		);

		register_rest_route(
			'dsm/v1',
			'/table-loop-preview',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( self::class, 'rest_table_loop_preview' ),
				'permission_callback' => static function () {
					return current_user_can( 'edit_posts' );
				},
				'args'                => array(
					'post_type' => array(
						'type'              => 'string',
						'required'          => false,
						'default'           => 'post',
						'sanitize_callback' => 'sanitize_key',
					),
					'count'     => array(
						'type'              => 'string',
						'default'           => '10',
						'sanitize_callback' => 'sanitize_text_field',
					),
					'orderby'   => array(
						'type'              => 'string',
						'default'           => 'date',
						'sanitize_callback' => 'sanitize_key',
					),
					'order'     => array(
						'type'              => 'string',
						'default'           => 'DESC',
						'sanitize_callback' => 'sanitize_text_field',
					),
					'fields'    => array(
						'type'              => 'string',
						'default'           => 'title,date,author,excerpt',
						'sanitize_callback' => 'sanitize_text_field',
					),
					'term_ids'  => array(
						'type'              => 'string',
						'default'           => '',
						'sanitize_callback' => 'sanitize_text_field',
					),
					'author'    => array(
						'type'              => 'string',
						'default'           => '',
						'sanitize_callback' => 'sanitize_text_field',
					),
				),
			)
		);

		register_rest_route(
			'dsm/v1',
			'/table-loop-options',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( self::class, 'rest_table_loop_options' ),
				'permission_callback' => static function () {
					return current_user_can( 'edit_posts' );
				},
			)
		);

		register_rest_route(
			'dsm/v1',
			'/table-shortcode-preview',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( self::class, 'rest_table_shortcode_preview' ),
				'permission_callback' => static function () {
					return current_user_can( 'edit_posts' );
				},
				'args'                => array(
					'content' => array(
						'type'              => 'string',
						'required'          => true,
						'validate_callback' => static function ( $param ) {
							return is_string( $param );
						},
					),
				),
			)
		);
	}

	/**
	 * Fetch remote CSV/JSON text for Visual Builder preview (authenticated editors).
	 *
	 * @param WP_REST_Request $request Request.
	 * @return \WP_REST_Response|WP_Error
	 */
	public static function rest_table_source( WP_REST_Request $request ) {
		$rate = DsmTableSource::check_preview_rate_limit();
		if ( is_wp_error( $rate ) ) {
			return $rate;
		}

		$source = sanitize_key( (string) $request->get_param( 'source' ) );
		if ( ! DsmTableSource::is_remote_source( $source ) ) {
			$source = 'csv';
		}

		$url       = (string) $request->get_param( 'url' );
		$validated = DsmTableSource::prepare_remote_url( $source, $url );
		if ( is_wp_error( $validated ) ) {
			return $validated;
		}

		$skip_cache = (bool) $request->get_param( 'nocache' );
		$fetched    = DsmTableSource::fetch_remote_text( $validated, $source, $skip_cache );
		if ( is_wp_error( $fetched ) ) {
			return $fetched;
		}

		$parsed = DsmTableSource::parse_remote_matrix( $source, $fetched['body'] );
		if ( is_wp_error( $parsed ) ) {
			return $parsed;
		}

		return rest_ensure_response(
			array(
				'body'     => $fetched['body'],
				'url'      => $fetched['url'],
				'bytes'    => $fetched['bytes'],
				'cached'   => $fetched['cached'],
				'source'   => $source,
				'matrix'   => $parsed['matrix'],
				'warnings' => $parsed['warnings'],
			)
		);
	}

	/**
	 * Public Live refresh: return headers + rows for a module-stored remote URL.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return \WP_REST_Response|WP_Error
	 */
	public static function rest_table_live( WP_REST_Request $request ) {
		$rate = DsmTableSource::check_live_rate_limit();
		if ( is_wp_error( $rate ) ) {
			return $rate;
		}

		$source = sanitize_key( (string) $request->get_param( 'source' ) );
		if ( ! DsmTableSource::is_remote_source( $source ) ) {
			$source = 'csv';
		}

		$url       = (string) $request->get_param( 'url' );
		$validated = DsmTableSource::prepare_remote_url( $source, $url );
		if ( is_wp_error( $validated ) ) {
			return $validated;
		}

		$header = ! empty( $request->get_param( 'header' ) );
		$grid   = DsmTableSource::resolve_remote_grid( $source, $validated, $header, array(), false );
		if ( is_wp_error( $grid ) ) {
			$last = DsmTableSource::get_last_good_grid( $source, $validated );
			if ( is_array( $last ) ) {
				$payload           = DsmTableSource::grid_to_matrix_payload( $last );
				$payload['url']    = $validated;
				$payload['cached'] = true;
				$payload['stale']  = true;
				$payload['source'] = $source;
				return rest_ensure_response( $payload );
			}
			return $grid;
		}

		$payload           = DsmTableSource::grid_to_matrix_payload( $grid );
		$payload['url']    = $validated;
		$payload['cached'] = false;
		$payload['stale']  = false;
		$payload['source'] = $source;

		return rest_ensure_response( $payload );
	}

	/**
	 * Loop preview for Visual Builder (publish-only query).
	 *
	 * @param WP_REST_Request $request Request.
	 * @return \WP_REST_Response|WP_Error
	 */
	public static function rest_table_loop_preview( WP_REST_Request $request ) {
		$rate = DsmTableSource::check_preview_rate_limit();
		if ( is_wp_error( $rate ) ) {
			return $rate;
		}

		$grid = DsmTableSource::build_loop_grid(
			array(
				'post_type' => (string) $request->get_param( 'post_type' ),
				'count'     => (string) $request->get_param( 'count' ),
				'orderby'   => (string) $request->get_param( 'orderby' ),
				'order'     => (string) $request->get_param( 'order' ),
				'fields'    => (string) $request->get_param( 'fields' ),
				'term_ids'  => (string) $request->get_param( 'term_ids' ),
				'author'    => (string) $request->get_param( 'author' ),
			)
		);
		if ( is_wp_error( $grid ) ) {
			return $grid;
		}

		return rest_ensure_response(
			array(
				'grid'    => $grid,
				'source'  => 'loop',
				'payload' => DsmTableSource::grid_to_matrix_payload( $grid ),
			)
		);
	}

	/**
	 * Visual Builder shortcode-cell preview (same processing as frontend render).
	 *
	 * WordPress REST cookie + nonce via `apiFetch`. Capability: `edit_posts`.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return \WP_REST_Response
	 */
	public static function rest_table_shortcode_preview( WP_REST_Request $request ) {
		$content = (string) $request->get_param( 'content' );

		return rest_ensure_response(
			array(
				'html' => self::render_shortcode_cell_html( $content ),
			)
		);
	}

	/**
	 * Process a shortcode cell: `do_shortcode` then `wp_kses_post`.
	 *
	 * Shared by frontend render and authenticated VB preview. Empty content
	 * returns an empty string (nothing rendered).
	 *
	 * @param string $content Shortcode markup after dynamic-content resolve.
	 * @return string
	 */
	public static function render_shortcode_cell_html( string $content ): string {
		if ( '' === $content ) {
			return '';
		}

		$html = wp_kses_post( do_shortcode( $content ) );

		/**
		 * Filter processed Table shortcode cell HTML.
		 *
		 * @param string $html    KSES'd shortcode output.
		 * @param string $content Raw shortcode markup after dynamic resolve.
		 */
		$filtered = apply_filters( 'dsm_table_shortcode_cell_html', $html, $content );

		return is_string( $filtered ) ? $filtered : $html;
	}

	/**
	 * Loop author picker options for Visual Builder.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return \WP_REST_Response|WP_Error
	 */
	public static function rest_table_loop_options( WP_REST_Request $request ) {
		unset( $request );
		$rate = DsmTableSource::check_preview_rate_limit();
		if ( is_wp_error( $rate ) ) {
			return $rate;
		}

		return rest_ensure_response(
			array(
				'authors' => DsmTableSource::get_loop_authors(),
			)
		);
	}

	/**
	 * Allowed cell type slugs (filterable).
	 *
	 * @return array<int, string>
	 */
	public static function get_cell_types(): array {
		$types = apply_filters( 'dsm_table_cell_types', self::CELL_TYPES );

		if ( ! is_array( $types ) ) {
			return self::CELL_TYPES;
		}

		$clean = array();
		foreach ( $types as $type ) {
			if ( is_string( $type ) && '' !== $type ) {
				$clean[] = sanitize_key( $type );
			}
		}

		return array() === $clean ? self::CELL_TYPES : array_values( array_unique( $clean ) );
	}

	/**
	 * Template catalog (VB applies templates; IDs stay filterable on the server).
	 *
	 * @return array<int, array<string, string>>
	 */
	public static function get_templates(): array {
		$templates = array(
			array(
				'id'    => 'pricing',
				'label' => __( 'Pricing', 'dsm-supreme-modules-pro-for-divi' ),
			),
			array(
				'id'    => 'feature-comparison',
				'label' => __( 'Feature comparison', 'dsm-supreme-modules-pro-for-divi' ),
			),
			array(
				'id'    => 'pros-cons',
				'label' => __( 'Pros / cons', 'dsm-supreme-modules-pro-for-divi' ),
			),
			array(
				'id'    => 'schedule',
				'label' => __( 'Schedule', 'dsm-supreme-modules-pro-for-divi' ),
			),
			array(
				'id'    => 'spec-sheet',
				'label' => __( 'Spec sheet', 'dsm-supreme-modules-pro-for-divi' ),
			),
			array(
				'id'    => 'team',
				'label' => __( 'Team', 'dsm-supreme-modules-pro-for-divi' ),
			),
			array(
				'id'    => 'menu',
				'label' => __( 'Menu', 'dsm-supreme-modules-pro-for-divi' ),
			),
			array(
				'id'    => 'invoice-lite',
				'label' => __( 'Invoice lite', 'dsm-supreme-modules-pro-for-divi' ),
			),
			array(
				'id'    => 'compatibility',
				'label' => __( 'Compatibility', 'dsm-supreme-modules-pro-for-divi' ),
			),
			array(
				'id'    => 'yes-no-matrix',
				'label' => __( 'Yes / no matrix', 'dsm-supreme-modules-pro-for-divi' ),
			),
			array(
				'id'    => 'pricing-annual',
				'label' => __( 'Annual pricing', 'dsm-supreme-modules-pro-for-divi' ),
			),
		);

		$filtered = apply_filters( 'dsm_table_templates', $templates );

		return is_array( $filtered ) ? $filtered : $templates;
	}

	/**
	 * Read a desktop innerContent string (plain or `{ text }`).
	 *
	 * @param array<string, mixed> $attrs    Module attrs.
	 * @param string               $key      Attribute key.
	 * @param string               $fallback Default.
	 * @return string
	 */
	private static function read_inner_attr( array $attrs, string $key, string $fallback ): string {
		$leaf = $attrs[ $key ]['innerContent']['desktop']['value'] ?? null;

		if ( is_array( $leaf ) && ( isset( $leaf['text'] ) || isset( $leaf['html'] ) ) ) {
			return self::coerce_html_string( $leaf );
		}

		if ( is_string( $leaf ) || is_numeric( $leaf ) ) {
			return (string) $leaf;
		}

		return $fallback;
	}

	/**
	 * Read a desktop innerContent list (checkboxes or comma string).
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 * @param string               $key   Attribute key.
	 * @return array<int, string>
	 */
	private static function read_inner_list( array $attrs, string $key ): array {
		$leaf = $attrs[ $key ]['innerContent']['desktop']['value'] ?? null;
		if ( is_array( $leaf ) ) {
			if ( isset( $leaf['text'] ) ) {
				$leaf = $leaf['text'];
			} else {
				$out = array();
				foreach ( $leaf as $item ) {
					$out[] = is_scalar( $item ) ? (string) $item : '';
				}
				return $out;
			}
		}

		if ( is_string( $leaf ) || is_numeric( $leaf ) ) {
			$parts = preg_split( '/[\s,|]+/', (string) $leaf );
			return is_array( $parts ) ? $parts : array();
		}

		return array();
	}

	/**
	 * Sanitize a CSS length used for stacked-card gap.
	 *
	 * @param string $value    Raw length.
	 * @param string $fallback Default length.
	 * @return string
	 */
	private static function sanitize_css_length( string $value, string $fallback ): string {
		$value = trim( $value );
		if ( 1 === preg_match( '/^(-?[\d.]+)(px|em|rem|%)$/', $value ) ) {
			return $value;
		}

		return $fallback;
	}

	/**
	 * Whether a toggle attr is on.
	 *
	 * @param array<string, mixed> $attrs    Module attrs.
	 * @param string               $key      Attribute key.
	 * @param string               $fallback Default on/off.
	 * @return bool
	 */
	private static function is_on( array $attrs, string $key, string $fallback = 'on' ): bool {
		$value = strtolower( trim( self::read_inner_attr( $attrs, $key, $fallback ) ) );

		return in_array( $value, array( 'on', 'true', '1', 'yes' ), true );
	}

	/**
	 * Search / pagination toolbar placement.
	 *
	 * @param string $value Raw layout value.
	 * @return string `top` or `bottom`.
	 */
	private static function sanitize_toolbar_layout( string $value ): string {
		return 'bottom' === strtolower( trim( $value ) ) ? 'bottom' : 'top';
	}

	/**
	 * Search / pagination toolbar alignment.
	 *
	 * @param mixed $value Raw align value (string or ButtonOptions object).
	 * @return string `left`, `center`, or `right`.
	 */
	private static function sanitize_toolbar_align( $value ): string {
		if ( is_array( $value ) ) {
			if ( isset( $value['alignment'] ) && is_string( $value['alignment'] ) ) {
				$value = $value['alignment'];
			} elseif ( isset( $value['value'] ) && is_string( $value['value'] ) ) {
				$value = $value['value'];
			} else {
				$value = '';
			}
		}

		$choice = strtolower( trim( (string) $value ) );
		$choice = (string) preg_replace( '/^(et_pb_text_align_|et_pb_align_|text-align-|align-)/', '', $choice );

		return in_array( $choice, array( 'center', 'right' ), true ) ? $choice : 'left';
	}

	/**
	 * Align a toolbar row from the control that owns it.
	 *
	 * Combined search + pagination keeps the default row (search grows).
	 *
	 * @param bool   $has_search       Search is in this bar.
	 * @param bool   $has_pagination   Pagination is in this bar.
	 * @param string $search_align     Search alignment.
	 * @param string $pagination_align Pagination alignment.
	 * @return string
	 */
	private static function toolbar_bar_align( bool $has_search, bool $has_pagination, string $search_align, string $pagination_align ): string {
		if ( $has_pagination && ! $has_search ) {
			return $pagination_align;
		}
		if ( $has_search && ! $has_pagination ) {
			return $search_align;
		}

		return 'left';
	}

	/**
	 * Toolbar label with a translated fallback when the setting is empty.
	 *
	 * @param string $value    User value.
	 * @param string $fallback Translated default.
	 * @return string
	 */
	private static function toolbar_label( string $value, string $fallback ): string {
		$trimmed = trim( $value );

		return '' !== $trimmed ? $trimmed : $fallback;
	}

	/**
	 * Resolve search / pagination / export labels for both toolbars.
	 *
	 * @param array<string, mixed> $options  Render options.
	 * @param string               $table_id Table element id.
	 * @return array<string, string>
	 */
	private static function resolve_toolbar_labels( array $options, string $table_id ): array {
		$labels = array(
			'search_placeholder' => self::toolbar_label(
				(string) ( $options['search_placeholder'] ?? '' ),
				__( 'Search…', 'dsm-supreme-modules-pro-for-divi' )
			),
			'prev'               => self::toolbar_label(
				(string) ( $options['pagination_prev_text'] ?? '' ),
				__( 'Previous', 'dsm-supreme-modules-pro-for-divi' )
			),
			'next'               => self::toolbar_label(
				(string) ( $options['pagination_next_text'] ?? '' ),
				__( 'Next', 'dsm-supreme-modules-pro-for-divi' )
			),
			'export'             => self::toolbar_label(
				(string) ( $options['export_text'] ?? '' ),
				__( 'Export CSV', 'dsm-supreme-modules-pro-for-divi' )
			),
		);

		/**
		 * Filter Supreme Table toolbar labels.
		 *
		 * @param array<string, string> $labels   Label map.
		 * @param string                $table_id Table element id.
		 */
		$filtered = apply_filters( 'dsm_table_toolbar_labels', $labels, $table_id );

		if ( ! is_array( $filtered ) ) {
			return $labels;
		}

		$out = $labels;
		foreach ( array( 'search_placeholder', 'prev', 'next', 'export' ) as $key ) {
			if ( isset( $filtered[ $key ] ) && is_scalar( $filtered[ $key ] ) ) {
				$out[ $key ] = self::toolbar_label( (string) $filtered[ $key ], $labels[ $key ] );
			}
		}

		return $out;
	}

	/**
	 * Desktop innerContent leaf for toolbar alignment.
	 *
	 * @param array<string, mixed> $attrs    Module attrs.
	 * @param string               $key      Attribute key.
	 * @param string               $fallback Default.
	 * @return string
	 */
	private static function read_toolbar_align( array $attrs, string $key, string $fallback ): string {
		$leaf = $attrs[ $key ]['innerContent']['desktop']['value'] ?? $fallback;

		return self::sanitize_toolbar_align( $leaf );
	}

	/**
	 * Resolve Divi `$variable(` tokens to plain text. Never evaluates PHP.
	 *
	 * @param string $value Raw string.
	 * @return string
	 */
	private static function resolve_dynamic_plain( string $value ): string {
		if ( '' === $value || false === strpos( $value, '$variable(' ) ) {
			return $value;
		}

		if ( ! class_exists( DynamicData::class ) ) {
			return $value;
		}

		$post_id  = get_the_ID();
		$resolved = DynamicData::get_processed_dynamic_data(
			$value,
			false !== $post_id && $post_id > 0 ? (int) $post_id : null
		);

		return null !== $resolved ? (string) $resolved : $value;
	}

	/**
	 * Keep Divi `$variable(` tokens; otherwise sanitize as a URL.
	 *
	 * `esc_url_raw()` strips Dynamic Content tokens, so URL fields that
	 * allow DC must use this before storage.
	 *
	 * @param string $value Raw URL or `$variable(` token.
	 * @return string
	 */
	private static function sanitize_maybe_dynamic_url( string $value ): string {
		$value = trim( $value );
		if ( '' === $value ) {
			return '';
		}

		if ( false !== strpos( $value, '$variable(' ) ) {
			return $value;
		}

		return esc_url_raw( $value );
	}

	/**
	 * Default starter grid when the attr is empty.
	 *
	 * @return array<string, mixed>
	 */
	public static function get_default_grid(): array {
		return array(
			'schema_version' => self::SCHEMA_VERSION,
			'columns'        => array(
				array(
					'id'           => 'col-feature',
					'header'       => __( 'Feature', 'dsm-supreme-modules-pro-for-divi' ),
					'hide_on'      => array(
						'tablet' => false,
						'phone'  => false,
					),
					'sticky'       => true,
					'type_default' => 'text',
					'width'        => '',
					'align'        => '',
				),
				array(
					'id'           => 'col-basic',
					'header'       => __( 'Basic', 'dsm-supreme-modules-pro-for-divi' ),
					'hide_on'      => array(
						'tablet' => false,
						'phone'  => false,
					),
					'sticky'       => false,
					'type_default' => 'text',
					'width'        => '',
					'align'        => '',
				),
				array(
					'id'           => 'col-pro',
					'header'       => __( 'Pro', 'dsm-supreme-modules-pro-for-divi' ),
					'hide_on'      => array(
						'tablet' => false,
						'phone'  => false,
					),
					'sticky'       => false,
					'type_default' => 'text',
					'width'        => '',
					'align'        => '',
				),
			),
			'rows'           => array(
				array(
					'id'      => 'row-h',
					'role'    => 'header',
					'tooltip' => '',
					'cells'   => array(
						self::make_text_cell( 'cell-h-1', __( 'Feature', 'dsm-supreme-modules-pro-for-divi' ) ),
						self::make_text_cell( 'cell-h-2', __( 'Basic', 'dsm-supreme-modules-pro-for-divi' ) ),
						self::make_text_cell( 'cell-h-3', __( 'Pro', 'dsm-supreme-modules-pro-for-divi' ) ),
					),
				),
				array(
					'id'      => 'row-1',
					'role'    => 'body',
					'tooltip' => '',
					'cells'   => array(
						self::make_text_cell( 'cell-1-1', __( 'Users', 'dsm-supreme-modules-pro-for-divi' ) ),
						self::make_text_cell( 'cell-1-2', '3' ),
						self::make_text_cell( 'cell-1-3', __( 'Unlimited', 'dsm-supreme-modules-pro-for-divi' ) ),
					),
				),
				array(
					'id'      => 'row-2',
					'role'    => 'body',
					'tooltip' => '',
					'cells'   => array(
						self::make_text_cell( 'cell-2-1', __( 'Support', 'dsm-supreme-modules-pro-for-divi' ) ),
						self::make_text_cell( 'cell-2-2', __( 'Email', 'dsm-supreme-modules-pro-for-divi' ) ),
						self::make_text_cell( 'cell-2-3', __( 'Priority', 'dsm-supreme-modules-pro-for-divi' ) ),
					),
				),
			),
			'merges'         => array(),
			'comparison'     => array(
				'highlight_column_id'  => 'col-pro',
				'best_value_column_id' => 'col-pro',
				'best_value_label'     => __( 'Best value', 'dsm-supreme-modules-pro-for-divi' ),
			),
		);
	}

	/**
	 * Minimal empty grid (1 column, header + one body row).
	 *
	 * Used for new library CPT items. `sanitize_grid` cannot store zero
	 * columns/rows; this is the smallest valid schema.
	 *
	 * @return array<string, mixed>
	 */
	public static function get_blank_grid(): array {
		return DsmTableLibrary::get_blank_grid();
	}

	/**
	 * Whether a grid has no header or cell text yet.
	 *
	 * @param array<string, mixed> $grid Sanitized grid.
	 * @return bool
	 */
	public static function is_blank_grid( array $grid ): bool {
		return DsmTableLibrary::is_blank_grid( $grid );
	}

	/**
	 * Create a plain-text cell for the default grid.
	 *
	 * @param string $id   Cell id.
	 * @param string $text Plain text.
	 * @return array<string, mixed>
	 */
	private static function make_text_cell( string $id, string $text ): array {
		return array(
			'id'      => $id,
			'type'    => 'text',
			'colspan' => 1,
			'rowspan' => 1,
			'value'   => array( 'text' => $text ),
			'design'  => array(),
		);
	}

	/**
	 * Sanitize stored grid JSON to schema_version 1.
	 *
	 * @param mixed $raw      Raw attr value.
	 * @param int   $max_rows Row cap. `0` uses the import cap (5000) so stored CSV imports survive.
	 * @return array<string, mixed>
	 */
	public static function sanitize_grid( $raw, int $max_rows = 0 ): array {
		if ( is_string( $raw ) && '' !== trim( $raw ) ) {
			$decoded = json_decode( $raw, true );
			$raw     = is_array( $decoded ) ? $decoded : array();
		}

		if ( ! is_array( $raw ) || array() === $raw ) {
			return self::get_default_grid();
		}

		if ( $max_rows < 1 ) {
			$max_rows = class_exists( DsmTableSource::class )
				? DsmTableSource::get_import_max_rows()
				: self::MAX_ROWS;
		}

		$columns_in = isset( $raw['columns'] ) && is_array( $raw['columns'] ) ? $raw['columns'] : array();
		$col_count  = min( self::MAX_COLS, max( 1, count( $columns_in ) ) );
		$columns    = array();

		for ( $c = 0; $c < $col_count; $c++ ) {
			$src       = isset( $columns_in[ $c ] ) && is_array( $columns_in[ $c ] ) ? $columns_in[ $c ] : array();
			$hide      = isset( $src['hide_on'] ) && is_array( $src['hide_on'] ) ? $src['hide_on'] : array();
			$columns[] = array(
				'id'           => self::sanitize_id( $src['id'] ?? '', 'col-' . ( $c + 1 ) ),
				'header'       => sanitize_text_field( (string) ( $src['header'] ?? '' ) ),
				'hide_on'      => array(
					'tablet' => ! empty( $hide['tablet'] ) && 'off' !== $hide['tablet'],
					'phone'  => ! empty( $hide['phone'] ) && 'off' !== $hide['phone'],
				),
				'sticky'       => ! empty( $src['sticky'] ) && 'off' !== $src['sticky'],
				'type_default' => self::sanitize_cell_type( $src['type_default'] ?? 'text' ),
				'width'        => self::sanitize_column_width( (string) ( $src['width'] ?? '' ) ),
				'align'        => self::sanitize_column_align( (string) ( $src['align'] ?? '' ) ),
			);
		}

		$rows_in   = isset( $raw['rows'] ) && is_array( $raw['rows'] ) ? $raw['rows'] : array();
		$row_count = min( $max_rows, max( 1, count( $rows_in ) ) );
		$rows      = array();

		for ( $r = 0; $r < $row_count; $r++ ) {
			$src      = isset( $rows_in[ $r ] ) && is_array( $rows_in[ $r ] ) ? $rows_in[ $r ] : array();
			$cells_in = isset( $src['cells'] ) && is_array( $src['cells'] ) ? $src['cells'] : array();
			$cells    = array();
			$role     = (string) ( $src['role'] ?? 'body' );
			if ( ! in_array( $role, self::ROW_ROLES, true ) ) {
				$role = 'body';
			}

			for ( $c = 0; $c < $col_count; $c++ ) {
				$cell_src = isset( $cells_in[ $c ] ) && is_array( $cells_in[ $c ] ) ? $cells_in[ $c ] : array();
				$cells[]  = self::sanitize_cell( $cell_src, $columns[ $c ]['type_default'] );
			}

			$rows[] = array(
				'id'      => self::sanitize_id( $src['id'] ?? '', 'row-' . ( $r + 1 ) ),
				'role'    => $role,
				'tooltip' => sanitize_text_field( (string) ( $src['tooltip'] ?? '' ) ),
				'cells'   => $cells,
			);
		}

		$col_ids = array();
		foreach ( $columns as $column ) {
			$col_ids[ $column['id'] ] = true;
		}

		$comparison_in = isset( $raw['comparison'] ) && is_array( $raw['comparison'] ) ? $raw['comparison'] : array();
		$highlight     = sanitize_text_field( (string) ( $comparison_in['highlight_column_id'] ?? $comparison_in['highlightColumnId'] ?? '' ) );
		$best          = sanitize_text_field( (string) ( $comparison_in['best_value_column_id'] ?? $comparison_in['bestValueColumnId'] ?? '' ) );

		$source_in = isset( $raw['source'] ) && is_array( $raw['source'] ) ? $raw['source'] : array();
		$src_type  = sanitize_key( (string) ( $source_in['type'] ?? '' ) );
		if ( ! in_array( $src_type, array( 'manual', 'csv', 'sheets', 'json', 'loop', 'library' ), true ) ) {
			$src_type = '';
		}

		$grid = array(
			'schema_version' => self::SCHEMA_VERSION,
			'columns'        => $columns,
			'rows'           => $rows,
			'merges'         => array(),
			'comparison'     => array(
				'highlight_column_id'  => isset( $col_ids[ $highlight ] ) ? $highlight : '',
				'best_value_column_id' => isset( $col_ids[ $best ] ) ? $best : '',
				'best_value_label'     => sanitize_text_field( (string) ( $comparison_in['best_value_label'] ?? $comparison_in['bestValueLabel'] ?? '' ) ),
			),
			'source'         => array(
				'type' => $src_type,
				'url'  => esc_url_raw( (string) ( $source_in['url'] ?? '' ) ),
			),
		);

		$grid['merges'] = self::rebuild_merges( $grid );

		return $grid;
	}

	/**
	 * Optional column width (px / em / rem / %).
	 *
	 * @param string $raw Raw width.
	 * @return string
	 */
	private static function sanitize_column_width( string $raw ): string {
		$raw = trim( $raw );
		if ( 1 === preg_match( '/^[\d.]+(px|em|rem|%)$/', $raw ) ) {
			return $raw;
		}

		return '';
	}

	/**
	 * Optional column text alignment.
	 *
	 * @param string $raw Raw align.
	 * @return string
	 */
	private static function sanitize_column_align( string $raw ): string {
		$align = sanitize_key( $raw );

		return in_array( $align, array( 'left', 'center', 'right' ), true ) ? $align : '';
	}

	/**
	 * Index of a column id, or -1.
	 *
	 * @param array<string, mixed> $grid Grid.
	 * @param string               $id   Column id.
	 * @return int
	 */
	private static function column_index_by_id( array $grid, string $id ): int {
		if ( '' === $id || ! isset( $grid['columns'] ) || ! is_array( $grid['columns'] ) ) {
			return -1;
		}
		foreach ( $grid['columns'] as $index => $column ) {
			if ( is_array( $column ) && (string) ( $column['id'] ?? '' ) === $id ) {
				return (int) $index;
			}
		}

		return -1;
	}

	/**
	 * Sanitize a cell or column id.
	 *
	 * @param mixed  $id       Raw id.
	 * @param string $fallback Fallback id.
	 * @return string
	 */
	private static function sanitize_id( $id, string $fallback ): string {
		$clean = sanitize_html_class( (string) $id );

		return '' !== $clean ? $clean : sanitize_html_class( $fallback );
	}

	/**
	 * Normalize a cell type slug.
	 *
	 * @param mixed $type Raw type.
	 * @return string
	 */
	private static function sanitize_cell_type( $type ): string {
		$raw   = sanitize_key( (string) $type );
		$types = self::get_cell_types();

		return in_array( $raw, $types, true ) ? $raw : 'text';
	}

	/**
	 * Sanitize one cell object.
	 *
	 * @param array<string, mixed> $src  Raw cell.
	 * @param string               $type Fallback type.
	 * @return array<string, mixed>
	 */
	private static function sanitize_cell( array $src, string $type ): array {
		$cell_type = self::sanitize_cell_type( $src['type'] ?? $type );
		$colspan   = isset( $src['colspan'] ) ? absint( $src['colspan'] ) : 1;
		$rowspan   = isset( $src['rowspan'] ) ? absint( $src['rowspan'] ) : 1;
		$design    = isset( $src['design'] ) && is_array( $src['design'] ) ? $src['design'] : array();
		$align     = sanitize_key( (string) ( $design['align'] ?? '' ) );
		if ( ! in_array( $align, array( 'left', 'center', 'right' ), true ) ) {
			$align = '';
		}

		return array(
			'id'      => self::sanitize_id( $src['id'] ?? '', 'cell' ),
			'type'    => $cell_type,
			'colspan' => min( self::MAX_COLS, max( 1, $colspan ) ),
			'rowspan' => min( self::MAX_ROWS, max( 1, $rowspan ) ),
			'value'   => self::sanitize_cell_value( $cell_type, $src['value'] ?? array() ),
			'design'  => array(
				'align' => $align,
			),
		);
	}

	/**
	 * Flatten a rich-text leaf (`html`, `text`, or nested copies) to a string.
	 *
	 * RichTextContainer may persist `{ text: '<p>…</p>' }` instead of a bare
	 * HTML string. Casting that array fatals PHP 8 and blanks frontend render.
	 *
	 * @param mixed $raw Raw html/text leaf.
	 * @return string
	 */
	public static function coerce_html_string( $raw ): string {
		if ( is_string( $raw ) || is_numeric( $raw ) ) {
			return (string) $raw;
		}
		if ( ! is_array( $raw ) ) {
			return '';
		}
		if ( isset( $raw['html'] ) ) {
			return self::coerce_html_string( $raw['html'] );
		}
		if ( isset( $raw['text'] ) ) {
			return self::coerce_html_string( $raw['text'] );
		}

		return '';
	}

	/**
	 * Flatten `table_cell_text` leaves to strings.
	 *
	 * RichTextContainer may persist `{ text: '…' }`. Divi's content pipeline
	 * (`wpautop` / `preg_replace`) TypeErrors on that array and the module
	 * disappears on the frontend.
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 * @return array<string, mixed>
	 */
	private static function normalize_table_cell_text_attr( array $attrs ): array {
		if ( ! isset( $attrs['table_cell_text'] ) || ! is_array( $attrs['table_cell_text'] ) ) {
			return $attrs;
		}
		$ic = $attrs['table_cell_text']['innerContent'] ?? null;
		if ( ! is_array( $ic ) ) {
			return $attrs;
		}
		foreach ( array( 'desktop', 'tablet', 'phone', 'phoneWide' ) as $bp ) {
			if ( ! isset( $ic[ $bp ] ) || ! is_array( $ic[ $bp ] ) ) {
				continue;
			}
			foreach ( array( 'value', 'hover', 'sticky' ) as $state ) {
				if ( ! isset( $ic[ $bp ][ $state ] ) ) {
					continue;
				}
				$ic[ $bp ][ $state ] = self::coerce_html_string( $ic[ $bp ][ $state ] );
			}
		}
		$attrs['table_cell_text']['innerContent'] = $ic;

		return $attrs;
	}

	/**
	 * Sanitize a typed cell value payload.
	 *
	 * @param string $type Cell type.
	 * @param mixed  $raw  Raw value.
	 * @return array<string, mixed>
	 */
	private static function sanitize_cell_value( string $type, $raw ): array {
		if ( is_string( $raw ) || is_numeric( $raw ) ) {
			$raw = array( 'text' => (string) $raw );
		}
		if ( ! is_array( $raw ) ) {
			$raw = array();
		}

		switch ( $type ) {
			case 'rich_text':
				return array(
					'html' => self::coerce_html_string( $raw['html'] ?? $raw['text'] ?? '' ),
				);
			case 'image':
				return array(
					'src' => self::sanitize_maybe_dynamic_url( (string) ( $raw['src'] ?? '' ) ),
					'alt' => sanitize_text_field( (string) ( $raw['alt'] ?? '' ) ),
					'url' => self::sanitize_maybe_dynamic_url( (string) ( $raw['url'] ?? '' ) ),
				);
			case 'icon':
				$icon = isset( $raw['icon'] ) && is_array( $raw['icon'] ) ? $raw['icon'] : $raw;
				return array(
					'icon' => self::sanitize_icon_settings( $icon ),
				);
			case 'button':
				$target = (string) ( $raw['target'] ?? '_self' );
				return array(
					'text'   => sanitize_text_field( (string) ( $raw['text'] ?? '' ) ),
					'url'    => self::sanitize_maybe_dynamic_url( (string) ( $raw['url'] ?? '' ) ),
					'target' => '_blank' === $target ? '_blank' : '_self',
				);
			case 'star_rating':
				return array(
					'rating' => sanitize_text_field( (string) ( $raw['rating'] ?? '5' ) ),
					'max'    => sanitize_text_field( (string) ( $raw['max'] ?? '5' ) ),
				);
			case 'icon_list':
				$items_in = isset( $raw['items'] ) && is_array( $raw['items'] ) ? $raw['items'] : array();
				$items    = array();
				foreach ( $items_in as $item ) {
					if ( ! is_array( $item ) ) {
						continue;
					}
					$items[] = array(
						'icon' => self::sanitize_icon_settings( isset( $item['icon'] ) && is_array( $item['icon'] ) ? $item['icon'] : array() ),
						'text' => sanitize_text_field( (string) ( $item['text'] ?? '' ) ),
					);
				}
				return array( 'items' => $items );
			case 'badge':
				$variant = sanitize_key( (string) ( $raw['variant'] ?? 'default' ) );
				if ( ! in_array( $variant, array( 'default', 'ribbon', 'success', 'warning', 'danger' ), true ) ) {
					$variant = 'default';
				}
				return array(
					'text'    => sanitize_text_field( (string) ( $raw['text'] ?? '' ) ),
					'variant' => $variant,
				);
			case 'shortcode':
				return array(
					'content' => (string) ( $raw['content'] ?? $raw['text'] ?? '' ),
				);
			case 'text':
			default:
				return array(
					'text' => (string) ( $raw['text'] ?? '' ),
				);
		}
	}

	/**
	 * Sanitize an icon picker leaf for storage.
	 *
	 * @param array<string, mixed> $icon Icon picker leaf.
	 * @return array<string, mixed>
	 */
	private static function sanitize_icon_settings( array $icon ): array {
		$out = array();
		if ( isset( $icon['unicode'] ) ) {
			$out['unicode'] = sanitize_text_field( (string) $icon['unicode'] );
		}
		if ( isset( $icon['type'] ) ) {
			$out['type'] = sanitize_key( (string) $icon['type'] );
		}
		if ( isset( $icon['weight'] ) ) {
			$out['weight'] = sanitize_text_field( (string) $icon['weight'] );
		}
		if ( isset( $icon['fontWeight'] ) ) {
			$out['fontWeight'] = sanitize_text_field( (string) $icon['fontWeight'] );
		}
		if ( isset( $icon['variant'] ) ) {
			$out['variant'] = sanitize_text_field( (string) $icon['variant'] );
		}

		return $out;
	}

	/**
	 * Rebuild merge rectangles from cell colspan/rowspan.
	 *
	 * @param array<string, mixed> $grid Grid.
	 * @return array<int, array<string, int>>
	 */
	private static function rebuild_merges( array $grid ): array {
		$merges = array();
		$rows   = $grid['rows'] ?? array();
		if ( ! is_array( $rows ) ) {
			return $merges;
		}

		foreach ( $rows as $r => $row ) {
			if ( ! is_array( $row ) || ! isset( $row['cells'] ) || ! is_array( $row['cells'] ) ) {
				continue;
			}
			foreach ( $row['cells'] as $c => $cell ) {
				if ( ! is_array( $cell ) ) {
					continue;
				}
				$colspan = isset( $cell['colspan'] ) ? absint( $cell['colspan'] ) : 1;
				$rowspan = isset( $cell['rowspan'] ) ? absint( $cell['rowspan'] ) : 1;
				if ( $colspan > 1 || $rowspan > 1 ) {
					$merges[] = array(
						'r'       => (int) $r,
						'c'       => (int) $c,
						'rowspan' => max( 1, $rowspan ),
						'colspan' => max( 1, $colspan ),
					);
				}
			}
		}

		return $merges;
	}

	/**
	 * Covered cells (not rendered) keyed as "r:c" → origin "r:c".
	 *
	 * @param array<string, mixed> $grid Grid.
	 * @return array<string, string>
	 */
	private static function covered_map( array $grid ): array {
		$covered = array();
		$merges  = isset( $grid['merges'] ) && is_array( $grid['merges'] ) ? $grid['merges'] : array();
		$row_n   = isset( $grid['rows'] ) && is_array( $grid['rows'] ) ? count( $grid['rows'] ) : 0;
		$col_n   = isset( $grid['columns'] ) && is_array( $grid['columns'] ) ? count( $grid['columns'] ) : 0;

		foreach ( $merges as $merge ) {
			if ( ! is_array( $merge ) ) {
				continue;
			}
			$r       = isset( $merge['r'] ) ? (int) $merge['r'] : -1;
			$c       = isset( $merge['c'] ) ? (int) $merge['c'] : -1;
			$rowspan = isset( $merge['rowspan'] ) ? max( 1, (int) $merge['rowspan'] ) : 1;
			$colspan = isset( $merge['colspan'] ) ? max( 1, (int) $merge['colspan'] ) : 1;
			if ( $r < 0 || $c < 0 || $r >= $row_n || $c >= $col_n ) {
				continue;
			}
			$origin = $r . ':' . $c;
			for ( $rr = $r; $rr < $r + $rowspan && $rr < $row_n; $rr++ ) {
				for ( $cc = $c; $cc < $c + $colspan && $cc < $col_n; $cc++ ) {
					if ( $rr === $r && $cc === $c ) {
						continue;
					}
					$covered[ $rr . ':' . $cc ] = $origin;
				}
			}
		}

		return $covered;
	}

	/**
	 * Safe fragment for H43 cell ids.
	 *
	 * @param string $table_id Module table id.
	 * @return string
	 */
	private static function sanitize_table_dom_id( string $table_id ): string {
		return (string) preg_replace( '/[^A-Za-z0-9_-]/', '', $table_id );
	}

	/**
	 * Header cell ids that cover a body column (including colspan hosts).
	 *
	 * @param array<string, mixed>  $grid     Grid.
	 * @param int                   $col_index Column index.
	 * @param string                $table_id Table id.
	 * @param array<string, string> $covered  Covered map.
	 * @return array<int, string>
	 */
	private static function covering_header_ids( array $grid, int $col_index, string $table_id, array $covered ): array {
		$base = self::sanitize_table_dom_id( $table_id );
		if ( '' === $base ) {
			return array();
		}
		$ids  = array();
		$rows = isset( $grid['rows'] ) && is_array( $grid['rows'] ) ? $grid['rows'] : array();
		foreach ( $rows as $r => $row ) {
			if ( ! is_array( $row ) || 'header' !== ( $row['role'] ?? '' ) ) {
				continue;
			}
			$cells = isset( $row['cells'] ) && is_array( $row['cells'] ) ? $row['cells'] : array();
			foreach ( $cells as $c => $cell ) {
				$c = (int) $c;
				if ( isset( $covered[ $r . ':' . $c ] ) ) {
					continue;
				}
				$colspan = 1;
				if ( is_array( $cell ) && isset( $cell['colspan'] ) ) {
					$colspan = max( 1, absint( $cell['colspan'] ) );
				}
				if ( $col_index >= $c && $col_index < $c + $colspan ) {
					$ids[] = $base . '-h-' . (string) (int) $r . '-' . (string) $c;
				}
			}
		}

		return $ids;
	}

	/**
	 * Build HTML id and headers attributes for one cell.
	 *
	 * @param array<string, mixed>  $grid            Grid.
	 * @param int                   $r               Row index.
	 * @param int                   $c               Column index.
	 * @param string                $table_id        Table id.
	 * @param bool                  $is_header       Header section.
	 * @param bool                  $is_row_header   First-column row header.
	 * @param bool                  $first_col_header First-col header option.
	 * @param array<string, string> $covered         Covered map.
	 * @return string
	 */
	private static function cell_a11y_attrs( array $grid, int $r, int $c, string $table_id, bool $is_header, bool $is_row_header, bool $first_col_header, array $covered ): string {
		$base = self::sanitize_table_dom_id( $table_id );
		if ( '' === $base ) {
			return '';
		}
		if ( $is_header ) {
			return ' id="' . esc_attr( $base . '-h-' . (string) $r . '-' . (string) $c ) . '"';
		}
		$header_ids = self::covering_header_ids( $grid, $c, $table_id, $covered );
		$attr       = '';
		if ( $is_row_header ) {
			$attr .= ' id="' . esc_attr( $base . '-rh-' . (string) $r ) . '"';
		} elseif ( $first_col_header ) {
			$header_ids[] = $base . '-rh-' . (string) $r;
		}
		$header_ids = array_values( array_filter( $header_ids ) );
		if ( array() !== $header_ids ) {
			$attr .= ' headers="' . esc_attr( implode( ' ', $header_ids ) ) . '"';
		}

		return $attr;
	}

	/**
	 * Visitor-facing empty-body copy.
	 *
	 * @return string
	 */
	private static function default_empty_text(): string {
		return __( 'No data.', 'dsm-supreme-modules-pro-for-divi' );
	}

	/**
	 * Accessible name for an icon-only cell.
	 *
	 * @param array<string, mixed> $icon Icon leaf.
	 * @return string
	 */
	private static function icon_accessible_name( array $icon ): string {
		foreach ( array( 'label', 'title', 'name' ) as $key ) {
			if ( isset( $icon[ $key ] ) && is_string( $icon[ $key ] ) && '' !== trim( $icon[ $key ] ) ) {
				return trim( $icon[ $key ] );
			}
		}

		return __( 'Icon', 'dsm-supreme-modules-pro-for-divi' );
	}

	/**
	 * Column header label for stacked cards.
	 *
	 * @param array<string, mixed> $grid Grid.
	 * @param int                  $c    Column index.
	 * @return string
	 */
	private static function column_label( array $grid, int $c ): string {
		$header = '';
		if ( isset( $grid['columns'][ $c ]['header'] ) ) {
			$header = trim( (string) $grid['columns'][ $c ]['header'] );
		}
		if ( '' !== $header ) {
			return $header;
		}

		foreach ( $grid['rows'] as $row ) {
			if ( ! is_array( $row ) || 'header' !== ( $row['role'] ?? '' ) ) {
				continue;
			}
			$cell = $row['cells'][ $c ] ?? null;
			if ( is_array( $cell ) ) {
				return self::cell_plain_text( $cell );
			}
		}

		return '';
	}

	/**
	 * Plain-text representation of a cell (captions, CSV, data-label).
	 *
	 * @param array<string, mixed> $cell Cell.
	 * @return string
	 */
	private static function cell_plain_text( array $cell ): string {
		$type  = (string) ( $cell['type'] ?? 'text' );
		$value = isset( $cell['value'] ) && is_array( $cell['value'] ) ? $cell['value'] : array();

		switch ( $type ) {
			case 'rich_text':
				return trim( wp_strip_all_tags( self::coerce_html_string( $value['html'] ?? $value['text'] ?? '' ) ) );
			case 'button':
			case 'badge':
			case 'text':
				return (string) ( $value['text'] ?? '' );
			case 'shortcode':
				return (string) ( $value['content'] ?? '' );
			case 'star_rating':
				return (string) ( $value['rating'] ?? '' );
			case 'image':
				return (string) ( $value['alt'] ?? $value['src'] ?? '' );
			default:
				return (string) ( $value['text'] ?? '' );
		}
	}

	/**
	 * Hide / highlight / sticky classes for a column.
	 *
	 * @param array<string, mixed> $grid Grid.
	 * @param int                  $c    Column index.
	 * @return string
	 */
	private static function column_classes( array $grid, int $c ): string {
		$classes = array();
		$col     = $grid['columns'][ $c ] ?? array();
		$hide    = isset( $col['hide_on'] ) && is_array( $col['hide_on'] ) ? $col['hide_on'] : array();

		if ( ! empty( $hide['tablet'] ) ) {
			$classes[] = 'dsm-table-hide-tablet';
		}
		if ( ! empty( $hide['phone'] ) ) {
			$classes[] = 'dsm-table-hide-phone';
		}
		if ( ! empty( $col['sticky'] ) ) {
			$classes[] = 'dsm-table-col-sticky';
		}

		$col_id = (string) ( $col['id'] ?? '' );
		$style  = self::column_style_class( $col_id );
		if ( '' !== $style ) {
			$classes[] = $style;
		}
		if ( '' !== $col_id && ( $grid['comparison']['highlight_column_id'] ?? '' ) === $col_id ) {
			$classes[] = 'dsm-table-col-highlight';
		}
		if ( '' !== $col_id && ( $grid['comparison']['best_value_column_id'] ?? '' ) === $col_id ) {
			$classes[] = 'dsm-table-col-best';
		}

		return implode( ' ', $classes );
	}

	/**
	 * Stable class for per-column badge/button overrides.
	 *
	 * @param string $column_id Column id.
	 * @return string
	 */
	private static function column_style_class( string $column_id ): string {
		$safe = sanitize_html_class( $column_id );

		return '' !== $safe ? 'dsm-table-col--' . $safe : '';
	}

	/**
	 * ColorPicker leaf → CSS color string.
	 *
	 * @param mixed $raw Hex, rgb, Divi `$variable()`, or `{ hex }`.
	 * @return string
	 */
	private static function sanitize_column_item_color( $raw ): string {
		if ( is_array( $raw ) ) {
			if ( isset( $raw['hex'] ) && is_string( $raw['hex'] ) ) {
				return self::sanitize_column_item_color( $raw['hex'] );
			}
			if ( isset( $raw['rgba'] ) && is_string( $raw['rgba'] ) ) {
				return self::sanitize_column_item_color( $raw['rgba'] );
			}
			if ( isset( $raw['cssVariable'] ) && is_string( $raw['cssVariable'] ) ) {
				return self::sanitize_column_item_color( $raw['cssVariable'] );
			}
			if ( isset( $raw['value'] ) ) {
				return self::sanitize_column_item_color( $raw['value'] );
			}
			if ( isset( $raw['color'] ) ) {
				return self::sanitize_column_item_color( $raw['color'] );
			}

			return '';
		}

		if ( ! is_string( $raw ) && ! is_numeric( $raw ) ) {
			return '';
		}

		$color = trim( (string) $raw );
		if ( '' === $color ) {
			return '';
		}

		if ( function_exists( 'sanitize_hex_color' ) ) {
			$hex = sanitize_hex_color( $color );
			if ( is_string( $hex ) && '' !== $hex ) {
				return $hex;
			}
		}

		if ( 1 === preg_match( '/^#([0-9a-f]{3}|[0-9a-f]{4}|[0-9a-f]{6}|[0-9a-f]{8})$/i', $color ) ) {
			return $color;
		}

		if ( 1 === preg_match( '/^(rgba?|hsla?)\(/i', $color ) ) {
			$safe = preg_replace( '/[^a-z0-9.,%()#\\s\\/-]/i', '', $color );

			return is_string( $safe ) ? $safe : '';
		}

		if ( 1 === preg_match( '/^var\\(/i', $color ) ) {
			return $color;
		}

		if ( 0 === strpos( $color, 'gcid-' ) ) {
			return sanitize_html_class( $color );
		}

		if ( 0 === strpos( $color, '$variable(' ) && substr( $color, -2 ) === ')$' ) {
			return $color;
		}

		return '';
	}

	/**
	 * Range leaf → CSS length. Empty means inherit the global group.
	 *
	 * @param mixed $raw Length string or FieldContainer payload.
	 * @return string
	 */
	private static function sanitize_column_item_length( $raw ): string {
		if ( is_array( $raw ) ) {
			if ( isset( $raw['inputValue'] ) ) {
				return self::sanitize_column_item_length( $raw['inputValue'] );
			}
			if ( isset( $raw['value'] ) ) {
				return self::sanitize_column_item_length( $raw['value'] );
			}

			return '';
		}

		if ( ! is_string( $raw ) && ! is_numeric( $raw ) ) {
			return '';
		}

		$value = trim( (string) $raw );
		if ( '' === $value ) {
			return '';
		}

		if ( 1 === preg_match( '/^(-?[\d.]+)(px|em|rem|%)$/', $value ) ) {
			return $value;
		}

		if ( 1 === preg_match( '/^-?[\d.]+$/', $value ) ) {
			return $value . 'px';
		}

		return '';
	}

	/**
	 * Sanitize one per-column badge/button override leaf.
	 *
	 * @param mixed  $raw  Stored leaf.
	 * @param string $prop Slot key.
	 * @return string
	 */
	private static function sanitize_column_item_slot_value( $raw, string $prop ): string {
		if ( 'background' === $prop || 'color' === $prop ) {
			return self::sanitize_column_item_color( $raw );
		}

		if ( 'borderRadius' === $prop || 'fontSize' === $prop ) {
			return self::sanitize_column_item_length( $raw );
		}

		return '';
	}

	/**
	 * Module-level per-column badge/button color map.
	 *
	 * @param mixed $raw innerContent desktop value.
	 * @return array<string, array<string, array<string, string>>>
	 */
	private static function parse_column_item_styles( $raw ): array {
		if ( is_string( $raw ) && '' !== trim( $raw ) ) {
			$decoded = json_decode( $raw, true );
			$raw     = is_array( $decoded ) ? $decoded : array();
		}

		if ( ! is_array( $raw ) ) {
			return array();
		}

		$out = array();
		foreach ( $raw as $column_id => $entry ) {
			$id = sanitize_text_field( (string) $column_id );
			if ( '' === $id || ! is_array( $entry ) ) {
				continue;
			}

			$next = array();
			foreach ( array( 'badge', 'button' ) as $group ) {
				$group_src = $entry[ $group ] ?? null;
				if ( ! is_array( $group_src ) ) {
					continue;
				}
				$slot = array();
				foreach ( array( 'background', 'color', 'borderRadius', 'fontSize' ) as $prop ) {
					$clean = self::sanitize_column_item_slot_value( $group_src[ $prop ] ?? '', $prop );
					if ( '' !== $clean ) {
						$slot[ $prop ] = $clean;
					}
				}
				if ( array() !== $slot ) {
					$next[ $group ] = $slot;
				}
			}

			if ( array() !== $next ) {
				$out[ $id ] = $next;
			}
		}

		return $out;
	}

	/**
	 * Drop map keys that do not match current column ids.
	 *
	 * @param mixed             $raw     Stored map.
	 * @param array<int, mixed> $columns Grid columns.
	 * @return array<string, array<string, array<string, string>>>
	 */
	private static function prune_column_item_styles( $raw, array $columns ): array {
		$map = self::parse_column_item_styles( $raw );
		$ids = array();
		foreach ( $columns as $column ) {
			if ( ! is_array( $column ) ) {
				continue;
			}
			$col_id = (string) ( $column['id'] ?? '' );
			if ( '' !== $col_id ) {
				$ids[ $col_id ] = true;
			}
		}

		$out = array();
		foreach ( $map as $column_id => $entry ) {
			if ( isset( $ids[ $column_id ] ) ) {
				$out[ $column_id ] = $entry;
			}
		}

		return $out;
	}

	/**
	 * CommonStyle blocks for per-column badge/button overrides.
	 *
	 * @param array<string, mixed> $attrs       Module attrs.
	 * @param string               $order_class Module order class.
	 * @return array<int, mixed>
	 */
	private static function column_item_style_declarations( array $attrs, string $order_class ): array {
		$grid = self::sanitize_grid( $attrs['table_grid']['innerContent']['desktop']['value'] ?? array() );
		$map  = self::prune_column_item_styles(
			$attrs['table_column_item_styles']['innerContent']['desktop']['value'] ?? array(),
			$grid['columns'] ?? array()
		);

		$styles = array();
		foreach ( $map as $column_id => $entry ) {
			$col_class = self::column_style_class( (string) $column_id );
			if ( '' === $col_class ) {
				continue;
			}

			$badge_sel  = $order_class . ' .' . $col_class . ' .dsm-table-badge';
			$button_sel = $order_class . ' .dsm-table .' . $col_class . ' .et_pb_button';
			$button_all = $button_sel . ', ' . $button_sel . ':hover';

			if ( ! empty( $entry['badge']['background'] ) ) {
				$styles[] = CommonStyle::style(
					array(
						'selector'  => $badge_sel,
						'attr'      => array(
							'desktop' => array(
								'value' => $entry['badge']['background'],
							),
						),
						'property'  => 'background-color',
						'important' => true,
					)
				);
			}
			if ( ! empty( $entry['badge']['color'] ) ) {
				$styles[] = CommonStyle::style(
					array(
						'selector'  => $badge_sel,
						'attr'      => array(
							'desktop' => array(
								'value' => $entry['badge']['color'],
							),
						),
						'property'  => 'color',
						'important' => true,
					)
				);
			}
			if ( ! empty( $entry['button']['background'] ) ) {
				$styles[] = CommonStyle::style(
					array(
						'selector'  => $button_all,
						'attr'      => array(
							'desktop' => array(
								'value' => $entry['button']['background'],
							),
						),
						'property'  => 'background-color',
						'important' => true,
					)
				);
			}
			if ( ! empty( $entry['button']['color'] ) ) {
				$styles[] = CommonStyle::style(
					array(
						'selector'  => $button_all,
						'attr'      => array(
							'desktop' => array(
								'value' => $entry['button']['color'],
							),
						),
						'property'  => 'color',
						'important' => true,
					)
				);
			}
			if ( ! empty( $entry['badge']['fontSize'] ) ) {
				$styles[] = CommonStyle::style(
					array(
						'selector'  => $badge_sel,
						'attr'      => array(
							'desktop' => array(
								'value' => $entry['badge']['fontSize'],
							),
						),
						'property'  => 'font-size',
						'important' => true,
					)
				);
			}
			if ( ! empty( $entry['badge']['borderRadius'] ) ) {
				$styles[] = CommonStyle::style(
					array(
						'selector'  => $badge_sel,
						'attr'      => array(
							'desktop' => array(
								'value' => $entry['badge']['borderRadius'],
							),
						),
						'property'  => 'border-radius',
						'important' => true,
					)
				);
			}
			if ( ! empty( $entry['button']['fontSize'] ) ) {
				$styles[] = CommonStyle::style(
					array(
						'selector'  => $button_all,
						'attr'      => array(
							'desktop' => array(
								'value' => $entry['button']['fontSize'],
							),
						),
						'property'  => 'font-size',
						'important' => true,
					)
				);
			}
			if ( ! empty( $entry['button']['borderRadius'] ) ) {
				$styles[] = CommonStyle::style(
					array(
						'selector'  => $button_all,
						'attr'      => array(
							'desktop' => array(
								'value' => $entry['button']['borderRadius'],
							),
						),
						'property'  => 'border-radius',
						'important' => true,
					)
				);
			}
		}

		return $styles;
	}

	/**
	 * Render an icon picker leaf.
	 *
	 * @param array<string, mixed> $icon_settings Icon.
	 * @return string
	 */
	private static function render_icon_html( array $icon_settings ): string {
		if ( array() === $icon_settings ) {
			return '';
		}

		if ( class_exists( IconGlyphRenderer::class ) ) {
			$glyph = IconGlyphRenderer::render_glyph_markup( $icon_settings );
			if ( is_string( $glyph ) && '' !== $glyph ) {
				return $glyph;
			}
			$native = IconGlyphRenderer::render_native_icon_span( $icon_settings, array( 'dsm-table-icon' ) );
			if ( is_string( $native ) && '' !== $native ) {
				return $native;
			}
		}

		if ( ! class_exists( Utils::class ) ) {
			return '';
		}

		$processed = Utils::process_font_icon( $icon_settings );
		if ( ! is_string( $processed ) || '' === $processed ) {
			return '';
		}

		return HTMLUtility::render(
			array(
				'tag'               => 'span',
				'attributes'        => array(
					'class'       => 'et-pb-icon dsm-table-icon',
					'aria-hidden' => 'true',
				),
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $processed,
			)
		);
	}

	/**
	 * Inner HTML for one cell (already sanitized by type).
	 *
	 * @param array<string, mixed> $cell Cell.
	 * @return string
	 */
	private static function render_cell_inner( array $cell ): string {
		$type  = self::sanitize_cell_type( $cell['type'] ?? 'text' );
		$value = isset( $cell['value'] ) && is_array( $cell['value'] ) ? $cell['value'] : array();

		switch ( $type ) {
			case 'rich_text':
				$html = self::coerce_html_string( $value['html'] ?? $value['text'] ?? '' );
				$html = self::resolve_dynamic_plain( $html );
				$html = wp_kses_post( $html );
				if ( '' === $html ) {
					return '';
				}
				return '<div class="dsm-table-rich">' . $html . '</div>';
			case 'image':
				$src = self::resolve_dynamic_plain( (string) ( $value['src'] ?? '' ) );
				if ( '' === $src ) {
					return '';
				}
				$alt = self::resolve_dynamic_plain( (string) ( $value['alt'] ?? '' ) );
				$img = sprintf(
					'<img class="dsm-table-image" src="%1$s" alt="%2$s" />',
					esc_url( $src ),
					esc_attr( $alt )
				);
				$url = self::resolve_dynamic_plain( (string) ( $value['url'] ?? '' ) );
				if ( '' !== $url ) {
					$link_label = '' !== $alt
						? ''
						: ' aria-label="' . esc_attr__( 'Table image', 'dsm-supreme-modules-pro-for-divi' ) . '"';
					return sprintf(
						'<a class="dsm-table-image-link" href="%1$s"%2$s>%3$s</a>',
						esc_url( $url ),
						$link_label,
						$img
					);
				}
				return $img;
			case 'icon':
				$icon = isset( $value['icon'] ) && is_array( $value['icon'] ) ? $value['icon'] : array();
				return '<span class="dsm-table-icon-cell" role="img" aria-label="' . esc_attr( self::icon_accessible_name( $icon ) ) . '">' . self::render_icon_html( $icon ) . '</span>';
			case 'button':
				$text = self::resolve_dynamic_plain( (string) ( $value['text'] ?? '' ) );
				if ( '' === $text ) {
					return '';
				}
				$url    = self::resolve_dynamic_plain( (string) ( $value['url'] ?? '' ) );
				$target = '_blank' === ( $value['target'] ?? '' ) ? ' target="_blank" rel="noopener noreferrer"' : '';
				if ( '' === $url ) {
					return '<span class="et_pb_button dsm-table-button"><span>' . esc_html( $text ) . '</span></span>';
				}
				return sprintf(
					'<a class="et_pb_button dsm-table-button" href="%1$s"%2$s><span>%3$s</span></a>',
					esc_url( $url ),
					$target,
					esc_html( $text )
				);
			case 'star_rating':
				$max    = min( 10, max( 1, (int) $value['max'] ) );
				$rating = (float) $value['rating'];
				$full   = (int) round( max( 0, min( $max, $rating ) ) );
				$glyphs = '';
				for ( $i = 1; $i <= $max; $i++ ) {
					$glyphs .= $i <= $full ? '★' : '☆';
				}
				$label = sprintf(
					/* translators: 1: rating, 2: maximum */
					__( 'Rated %1$s out of %2$s', 'dsm-supreme-modules-pro-for-divi' ),
					(string) $rating,
					(string) $max
				);
				return sprintf(
					'<span class="dsm-table-stars" role="img" aria-label="%1$s"><span aria-hidden="true">%2$s</span></span>',
					esc_attr( $label ),
					esc_html( $glyphs )
				);
			case 'icon_list':
				$items = isset( $value['items'] ) && is_array( $value['items'] ) ? $value['items'] : array();
				if ( array() === $items ) {
					return '';
				}
				$list = '';
				foreach ( $items as $item ) {
					if ( ! is_array( $item ) ) {
						continue;
					}
					$icon  = isset( $item['icon'] ) && is_array( $item['icon'] ) ? $item['icon'] : array();
					$label = self::resolve_dynamic_plain( (string) ( $item['text'] ?? '' ) );
					$list .= '<li class="dsm-table-icon-list__item">' . self::render_icon_html( $icon ) . '<span>' . esc_html( $label ) . '</span></li>';
				}
				return '<ul class="dsm-table-icon-list">' . $list . '</ul>';
			case 'badge':
				$text = self::resolve_dynamic_plain( (string) ( $value['text'] ?? '' ) );
				if ( '' === $text ) {
					return '';
				}
				$variant = sanitize_key( (string) ( $value['variant'] ?? 'default' ) );
				return sprintf(
					'<span class="dsm-table-badge dsm-table-badge--%1$s">%2$s</span>',
					esc_attr( $variant ),
					esc_html( $text )
				);
			case 'shortcode':
				$content = (string) ( $value['content'] ?? '' );
				$content = self::resolve_dynamic_plain( $content );
				return self::render_shortcode_cell_html( $content );
			case 'text':
			default:
				$text = self::resolve_dynamic_plain( (string) ( $value['text'] ?? '' ) );
				return esc_html( $text );
		}
	}

	/**
	 * Render one table row.
	 *
	 * @param array<string, mixed>  $grid            Grid.
	 * @param array<string, mixed>  $row             Row.
	 * @param int                   $r               Row index.
	 * @param array<string, string> $covered        Covered map.
	 * @param bool                  $is_header       Header section.
	 * @param bool                  $first_col_header First column as row header.
	 * @param bool                  $enable_sort      Wrap header cells in sort buttons.
	 * @param string                $table_id         Table id for H43.
	 * @param string                $ribbon_placement `before` or `after` the label.
	 * @return string
	 */
	private static function render_row( array $grid, array $row, int $r, array $covered, bool $is_header, bool $first_col_header, bool $enable_sort = false, string $table_id = '', string $ribbon_placement = 'before' ): string {
		$role      = (string) ( $row['role'] ?? 'body' );
		$tooltip   = self::resolve_dynamic_plain( (string) ( $row['tooltip'] ?? '' ) );
		$cells     = isset( $row['cells'] ) && is_array( $row['cells'] ) ? $row['cells'] : array();
		$best_id   = (string) ( $grid['comparison']['best_value_column_id'] ?? '' );
		$best_lbl  = (string) ( $grid['comparison']['best_value_label'] ?? '' );
		$row_class = 'dsm-table-row dsm-table-row--' . sanitize_html_class( $role );
		if ( '' !== $tooltip ) {
			$row_class .= ' dsm-table-row--has-tooltip';
		}

		$html = '<tr class="' . esc_attr( $row_class ) . '"' . ( '' !== $tooltip ? ' title="' . esc_attr( $tooltip ) . '"' : '' ) . '>';

		foreach ( $cells as $c => $cell ) {
			$c = (int) $c;
			if ( isset( $covered[ $r . ':' . $c ] ) ) {
				continue;
			}
			if ( ! is_array( $cell ) ) {
				continue;
			}

			$col       = $grid['columns'][ $c ] ?? array();
			$label     = self::column_label( $grid, $c );
			$col_class = self::column_classes( $grid, $c );
			$is_th     = $is_header || ( $first_col_header && 0 === $c && ! $is_header );
			$tag       = $is_th ? 'th' : 'td';
			$scope     = $is_header ? ' scope="col"' : ( $is_th ? ' scope="row"' : '' );
			$colspan   = isset( $cell['colspan'] ) ? absint( $cell['colspan'] ) : 1;
			$rowspan   = isset( $cell['rowspan'] ) ? absint( $cell['rowspan'] ) : 1;
			$align     = (string) ( $cell['design']['align'] ?? '' );
			if ( '' === $align ) {
				$align = self::sanitize_column_align( (string) ( $col['align'] ?? '' ) );
			}
			$type      = self::sanitize_cell_type( $cell['type'] ?? 'text' );
			$class     = trim(
				'dsm-table-cell dsm-table-cell--' . sanitize_html_class( $type ) . ' ' . $col_class . ( '' !== $align ? ' dsm-table-cell--align-' . sanitize_html_class( $align ) : '' )
			);
			$span_attr = '';
			if ( $colspan > 1 ) {
				$span_attr .= ' colspan="' . esc_attr( (string) $colspan ) . '"';
			}
			if ( $rowspan > 1 ) {
				$span_attr .= ' rowspan="' . esc_attr( (string) $rowspan ) . '"';
			}

			$inner  = self::render_cell_inner( $cell );
			$col_id = (string) ( $col['id'] ?? '' );
			if ( $is_header && $col_id && $col_id === $best_id && '' !== $best_lbl ) {
				$ribbon_after = 'after' === $ribbon_placement;
				$ribbon       = '<span class="dsm-table-best-value-ribbon' . ( $ribbon_after ? ' dsm-table-best-value-ribbon--after' : '' ) . '">' . esc_html( $best_lbl ) . '</span>';
				$inner        = $ribbon_after ? $inner . $ribbon : $ribbon . $inner;
			}
			if ( '' !== $tooltip && 0 === $c && ! $is_header ) {
				$inner .= '<span class="dsm-table-row-tooltip-sr">' . esc_html( $tooltip ) . '</span>';
			}

			if ( $is_header && $enable_sort ) {
				$sort_name = '' !== $label ? $label : trim( wp_strip_all_tags( $inner ) );
				if ( '' === $sort_name ) {
					$sort_name = __( 'column', 'dsm-supreme-modules-pro-for-divi' );
				}
				$sort_label = sprintf(
					/* translators: %s: column header text */
					__( 'Sort by %s', 'dsm-supreme-modules-pro-for-divi' ),
					$sort_name
				);
				$inner = sprintf(
					'<button type="button" class="dsm-table-sort" data-dsm-sort-label="%1$s" aria-label="%1$s">%2$s<span class="dsm-table-sort__icon" aria-hidden="true"></span></button>',
					esc_attr( $sort_label ),
					$inner
				);
			}

			if ( '' !== $label ) {
				$inner = '<span class="dsm-table-stack-label" aria-hidden="true">' . esc_html( $label ) . '</span>' . $inner;
			}

			$a11y_attr = self::cell_a11y_attrs( $grid, $r, $c, $table_id, $is_header, $is_th && ! $is_header, $first_col_header, $covered );

			$html .= sprintf(
				'<%1$s class="%2$s"%3$s%4$s%5$s data-label="%6$s" data-col-id="%7$s" data-dsm-table-col="%8$s">%9$s</%1$s>',
				$tag,
				esc_attr( $class ),
				$scope,
				$span_attr,
				$a11y_attr,
				esc_attr( $label ),
				esc_attr( $col_id ),
				esc_attr( (string) $c ),
				$inner
			);
		}

		$html .= '</tr>';

		return $html;
	}

	/**
	 * Build the semantic table HTML.
	 *
	 * @param array<string, mixed> $grid    Sanitized grid.
	 * @param array<string, mixed> $options Render options.
	 * @return string
	 */
	public static function render_table_html( array $grid, array $options ): string {
		$caption          = (string) ( $options['caption'] ?? '' );
		$show_header      = ! empty( $options['show_header'] );
		$first_col_header = ! empty( $options['first_col_header'] );
		$responsive       = (string) ( $options['responsive_mode'] ?? 'scroll' );
		if ( ! in_array( $responsive, array( 'scroll', 'stack', 'hide' ), true ) ) {
			$responsive = 'scroll';
		}
		$sticky            = ! empty( $options['sticky_header'] );
		$zebra             = ! empty( $options['zebra'] );
		$hover             = ! empty( $options['hover'] );
		$search            = ! empty( $options['search'] );
		$sort              = ! empty( $options['sort'] );
		$pagination        = ! empty( $options['pagination'] );
		$export            = ! empty( $options['export'] );
		$search_layout     = self::sanitize_toolbar_layout( (string) ( $options['search_layout'] ?? 'top' ) );
		$pagination_layout = self::sanitize_toolbar_layout( (string) ( $options['pagination_layout'] ?? 'top' ) );
		$search_align      = self::sanitize_toolbar_align( $options['search_align'] ?? 'left' );
		$pagination_align  = self::sanitize_toolbar_align( $options['pagination_align'] ?? 'left' );
		$export_layout     = $search ? $search_layout : ( $pagination ? $pagination_layout : 'top' );
		$live              = ! empty( $options['live'] );
		$page_size         = isset( $options['page_size'] ) ? absint( $options['page_size'] ) : 10;
		if ( ! in_array( $page_size, array( 5, 10, 25, 50 ), true ) ) {
			$page_size = 10;
		}
		$source_slug = sanitize_key( (string) ( $options['source'] ?? 'manual' ) );
		$remote_url  = esc_url( (string) ( $options['remote_url'] ?? '' ) );
		$refresh_min = isset( $options['refresh_minutes'] ) ? absint( $options['refresh_minutes'] ) : 15;

		$table_id         = sanitize_html_class( (string) ( $options['table_id'] ?? '' ) );
		$stack_gap        = self::sanitize_css_length( (string) ( $options['stack_gap'] ?? '12px' ), '12px' );
		$ribbon_placement = 'after' === ( $options['ribbon_placement'] ?? '' ) ? 'after' : 'before';
		$interactive      = $search || $sort || $pagination || $export || $live;

		$header_rows = array();
		$body_rows   = array();
		$footer_rows = array();
		$cta_rows    = array();

		foreach ( $grid['rows'] as $r => $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$packed = array(
				'row' => $row,
				'r'   => (int) $r,
			);
			$role   = (string) ( $row['role'] ?? 'body' );
			if ( 'header' === $role ) {
				$header_rows[] = $packed;
			} elseif ( 'footer' === $role ) {
				$footer_rows[] = $packed;
			} elseif ( 'cta' === $role ) {
				$cta_rows[] = $packed;
			} else {
				$body_rows[] = $packed;
			}
		}

		$covered = self::covered_map( $grid );
		$classes = array( 'dsm-table', 'dsm-table--' . $responsive );
		if ( $zebra ) {
			$classes[] = 'dsm-table--zebra';
		}
		if ( $hover ) {
			$classes[] = 'dsm-table--hover';
		}
		if ( $sticky ) {
			$classes[] = 'dsm-table--sticky-header';
		}

		$caption_id    = '' !== $table_id ? $table_id . '-caption' : '';
		$stack_note_id = '' !== $table_id ? $table_id . '-stack-note' : '';
		$described_by  = array();
		if ( 'stack' === $responsive && '' !== $stack_note_id ) {
			$described_by[] = $stack_note_id;
		}

		$empty_text = trim( (string) ( $options['empty_text'] ?? '' ) );
		if ( '' === $empty_text ) {
			$empty_text = self::default_empty_text();
		}

		$aria_label_attr = '' !== $caption
			? ''
			: ' aria-label="' . esc_attr__( 'Data table', 'dsm-supreme-modules-pro-for-divi' ) . '"';

		$wrap_class  = 'dsm-table-wrap' . ( $interactive ? ' dsm-table-interactive' : '' );
		$wrap_attrs  = ' class="' . esc_attr( $wrap_class ) . '" style="--dsm-table-stack-gap:' . esc_attr( $stack_gap ) . '"';
		$wrap_attrs .= ' data-dsm-table-search="' . ( $search ? 'on' : 'off' ) . '"';
		$wrap_attrs .= ' data-dsm-table-sort="' . ( $sort ? 'on' : 'off' ) . '"';
		$wrap_attrs .= ' data-dsm-table-sort-locked="' . esc_attr__( 'Sorting is unavailable while this table has merged body cells.', 'dsm-supreme-modules-pro-for-divi' ) . '"';
		$wrap_attrs .= ' data-dsm-table-pagination="' . ( $pagination ? 'on' : 'off' ) . '"';
		$wrap_attrs .= ' data-dsm-table-export="' . ( $export ? 'on' : 'off' ) . '"';
		$wrap_attrs .= ' data-dsm-table-page-size="' . esc_attr( (string) $page_size ) . '"';
		$wrap_attrs .= ' data-dsm-table-live="' . ( $live ? 'on' : 'off' ) . '"';
		$wrap_attrs .= ' data-dsm-table-source="' . esc_attr( $source_slug ) . '"';
		$sort_col    = '';
		$sort_dir    = '';
		if ( $sort ) {
			$default_id  = sanitize_text_field( (string) ( $options['sort_default_column'] ?? '' ) );
			$default_idx = self::column_index_by_id( $grid, $default_id );
			if ( $default_idx >= 0 ) {
				$sort_col = (string) $default_idx;
				$sort_dir = 'desc' === strtolower( (string) ( $options['sort_default_dir'] ?? 'asc' ) ) ? 'desc' : 'asc';
			}
		}
		$wrap_attrs .= ' data-dsm-table-sort-col="' . esc_attr( $sort_col ) . '"';
		$wrap_attrs .= ' data-dsm-table-sort-dir="' . esc_attr( $sort_dir ) . '"';
		$wrap_attrs .= ' data-dsm-table-first-col-header="' . ( $first_col_header ? 'on' : 'off' ) . '"';
		$wrap_attrs .= ' data-dsm-table-empty-text="' . esc_attr( $empty_text ) . '"';
		/* translators: %s: column header text */
		$wrap_attrs .= ' data-dsm-table-sort-by-template="' . esc_attr__( 'Sort by %s', 'dsm-supreme-modules-pro-for-divi' ) . '"';
		if ( $live && '' !== $remote_url ) {
			$wrap_attrs .= ' data-dsm-table-remote-url="' . esc_url( $remote_url ) . '"';
			$wrap_attrs .= ' data-dsm-table-refresh-minutes="' . esc_attr( (string) $refresh_min ) . '"';
			$wrap_attrs .= ' data-dsm-table-header-row="' . ( ! empty( $options['header_row'] ) ? 'on' : 'off' ) . '"';
		}

		$top_search     = $search && 'top' === $search_layout;
		$top_pagination = $pagination && 'top' === $pagination_layout;
		$toolbar_labels = self::resolve_toolbar_labels( $options, $table_id );

		$html  = '<div' . $wrap_attrs . '>';
		$html .= self::render_toolbar(
			array(
				'search'     => $top_search,
				'pagination' => $top_pagination,
				'export'     => $export && 'top' === $export_layout,
			),
			'top',
			self::toolbar_bar_align( $top_search, $top_pagination, $search_align, $pagination_align ),
			$table_id,
			$toolbar_labels
		);
		if ( 'stack' === $responsive ) {
			$html .= '<p id="' . esc_attr( $stack_note_id ) . '" class="screen-reader-text">' . esc_html__( 'On small screens this table is shown as stacked cards. Column headers are repeated as labels on each cell.', 'dsm-supreme-modules-pro-for-divi' ) . '</p>';
		}

		$html .= '<div class="dsm-table-scroll">';
		$html .= sprintf(
			'<table%1$s class="%2$s" data-dsm-responsive="%3$s" data-dsm-sticky="%4$s" data-dsm-zebra="%5$s" data-dsm-hover="%6$s"%7$s%8$s>',
			'' !== $table_id ? ' id="' . esc_attr( $table_id ) . '"' : '',
			esc_attr( implode( ' ', $classes ) ),
			esc_attr( $responsive ),
			$sticky ? 'on' : 'off',
			$zebra ? 'on' : 'off',
			$hover ? 'on' : 'off',
			$aria_label_attr,
			array() === $described_by ? '' : ' aria-describedby="' . esc_attr( implode( ' ', $described_by ) ) . '"'
		);

		if ( '' !== $caption ) {
			$html .= '<caption id="' . esc_attr( $caption_id ) . '" class="dsm-table-caption">' . esc_html( $caption ) . '</caption>';
		}

		if ( isset( $grid['columns'] ) && is_array( $grid['columns'] ) && array() !== $grid['columns'] ) {
			$html .= '<colgroup>';
			foreach ( $grid['columns'] as $column ) {
				$width = is_array( $column ) ? self::sanitize_column_width( (string) ( $column['width'] ?? '' ) ) : '';
				$html .= '<col' . ( '' !== $width ? ' style="width:' . esc_attr( $width ) . '"' : '' ) . ' />';
			}
			$html .= '</colgroup>';
		}

		if ( $show_header && array() !== $header_rows ) {
			$html .= '<thead class="dsm-table-head">';
			foreach ( $header_rows as $packed ) {
				$html .= self::render_row( $grid, $packed['row'], $packed['r'], $covered, true, false, $sort, $table_id, $ribbon_placement );
			}
			$html .= '</thead>';
		}

		$html .= '<tbody class="dsm-table-body">';
		if ( array() === $body_rows ) {
			$colspan = max( 1, count( $grid['columns'] ) );
			$html   .= '<tr class="dsm-table-row dsm-table-row--empty"><td class="dsm-table-cell" colspan="' . esc_attr( (string) $colspan ) . '">' . esc_html( $empty_text ) . '</td></tr>';
		} else {
			foreach ( $body_rows as $packed ) {
				$html .= self::render_row( $grid, $packed['row'], $packed['r'], $covered, false, $first_col_header, false, $table_id, $ribbon_placement );
			}
		}
		$html .= '</tbody>';

		if ( array() !== $footer_rows || array() !== $cta_rows ) {
			$html .= '<tfoot class="dsm-table-foot">';
			foreach ( $footer_rows as $packed ) {
				$html .= self::render_row( $grid, $packed['row'], $packed['r'], $covered, false, $first_col_header, false, $table_id, $ribbon_placement );
			}
			foreach ( $cta_rows as $packed ) {
				$html .= self::render_row( $grid, $packed['row'], $packed['r'], $covered, false, $first_col_header, false, $table_id, $ribbon_placement );
			}
			$html .= '</tfoot>';
		}

		$html .= '</table>';
		$html .= '</div>';
		if ( $search ) {
			$search_empty = trim( (string) ( $options['search_empty_text'] ?? '' ) );
			if ( '' === $search_empty ) {
				$search_empty = __( 'No matching rows.', 'dsm-supreme-modules-pro-for-divi' );
			}
			$html .= '<p class="dsm-table-empty" role="status" aria-live="polite" aria-atomic="true" data-dsm-table-empty hidden>' . esc_html( $search_empty ) . '</p>';
		}
		if ( $live ) {
			$html .= '<p class="screen-reader-text" data-dsm-table-live-status role="status" aria-live="polite" aria-atomic="true"';
			$html .= ' data-dsm-table-live-fail="' . esc_attr__( 'Could not refresh table data.', 'dsm-supreme-modules-pro-for-divi' ) . '"';
			$html .= ' data-dsm-table-live-ok="' . esc_attr__( 'Table data updated.', 'dsm-supreme-modules-pro-for-divi' ) . '"></p>';
		}
		$bottom_search     = $search && 'bottom' === $search_layout;
		$bottom_pagination = $pagination && 'bottom' === $pagination_layout;

		$html .= self::render_toolbar(
			array(
				'search'     => $bottom_search,
				'pagination' => $bottom_pagination,
				'export'     => $export && 'bottom' === $export_layout,
			),
			'bottom',
			self::toolbar_bar_align( $bottom_search, $bottom_pagination, $search_align, $pagination_align ),
			$table_id,
			$toolbar_labels
		);
		$html .= '</div>';

		return $html;
	}

	/**
	 * Search / pagination / export toolbar (progressive enhancement; JS binds).
	 *
	 * @param array<string, bool>   $flags     Feature flags.
	 * @param string                $placement `top` or `bottom`.
	 * @param string                $align     `left`, `center`, or `right`.
	 * @param string                $table_id  Table element id for aria-controls.
	 * @param array<string, string> $labels    Resolved toolbar labels.
	 * @return string
	 */
	private static function render_toolbar( array $flags, string $placement = 'top', string $align = 'left', string $table_id = '', array $labels = array() ): string {
		if ( empty( $flags['search'] ) && empty( $flags['pagination'] ) && empty( $flags['export'] ) ) {
			return '';
		}

		$placement          = self::sanitize_toolbar_layout( $placement );
		$align              = self::sanitize_toolbar_align( $align );
		$search_placeholder = self::toolbar_label(
			(string) ( $labels['search_placeholder'] ?? '' ),
			__( 'Search…', 'dsm-supreme-modules-pro-for-divi' )
		);
		$prev_text          = self::toolbar_label(
			(string) ( $labels['prev'] ?? '' ),
			__( 'Previous', 'dsm-supreme-modules-pro-for-divi' )
		);
		$next_text          = self::toolbar_label(
			(string) ( $labels['next'] ?? '' ),
			__( 'Next', 'dsm-supreme-modules-pro-for-divi' )
		);
		$export_text        = self::toolbar_label(
			(string) ( $labels['export'] ?? '' ),
			__( 'Export CSV', 'dsm-supreme-modules-pro-for-divi' )
		);
		$html               = '<div class="dsm-table-toolbar dsm-table-toolbar--' . esc_attr( $placement ) . ' dsm-table-toolbar--align-' . esc_attr( $align ) . '" data-dsm-table-toolbar="' . esc_attr( $placement ) . '" data-dsm-table-toolbar-align="' . esc_attr( $align ) . '">';
		if ( ! empty( $flags['search'] ) ) {
			$html .= '<label class="dsm-table-toolbar__search"><span class="screen-reader-text">' . esc_html__( 'Search table', 'dsm-supreme-modules-pro-for-divi' ) . '</span>';
			$html .= '<input type="search" class="dsm-table-toolbar__search-input" data-dsm-table-search-input placeholder="' . esc_attr( $search_placeholder ) . '" />';
			$html .= '</label>';
		}
		if ( ! empty( $flags['pagination'] ) ) {
			$controls = '' !== $table_id ? ' aria-controls="' . esc_attr( $table_id ) . '"' : '';
			$html    .= '<div class="dsm-table-toolbar__pager">';
			$html    .= '<button type="button" class="dsm-table-toolbar__btn" data-dsm-table-page-prev' . $controls . '>' . esc_html( $prev_text ) . '</button>';
			$html    .= '<span class="dsm-table-toolbar__status" role="status" aria-live="polite" aria-atomic="true" data-dsm-table-page-status data-dsm-table-page-template="';
			/* translators: 1: current page number, 2: total pages */
			$html .= esc_attr__( 'Page %1$s of %2$s', 'dsm-supreme-modules-pro-for-divi' );
			$html .= '"></span>';
			$html .= '<button type="button" class="dsm-table-toolbar__btn" data-dsm-table-page-next' . $controls . '>' . esc_html( $next_text ) . '</button>';
			$html .= '</div>';
		}
		if ( ! empty( $flags['export'] ) ) {
			$html .= '<button type="button" class="dsm-table-toolbar__btn dsm-table-toolbar__export" data-dsm-table-export-btn>' . esc_html( $export_text ) . '</button>';
		}
		$html .= '</div>';

		return $html;
	}

	/**
	 * Resolve the grid used for frontend render (Manual snapshot, Live remote, or Loop).
	 *
	 * @param array<string, mixed> $attrs     Module attrs.
	 * @param string               $module_id Module id.
	 * @return array<string, mixed>
	 */
	public static function resolve_render_grid( array $attrs, string $module_id ): array {
		$stored        = self::sanitize_grid(
			$attrs['table_grid']['innerContent']['desktop']['value'] ?? array(),
			DsmTableSource::get_import_max_rows()
		);
		$source        = self::read_inner_attr( $attrs, 'data_source', 'manual' );
		$url           = trim( self::read_inner_attr( $attrs, 'data_source_url', '' ) );
		$live          = self::is_on( $attrs, 'data_source_live', 'off' );
		$header        = self::is_on( $attrs, 'table_source_header_row', 'on' );
		$grid          = $stored;
		$sanitize_rows = DsmTableSource::get_import_max_rows();

		if ( 'library' === $source && class_exists( DsmTableLibrary::class ) ) {
			$library_id = absint( self::read_inner_attr( $attrs, 'table_library_id', '0' ) );
			$from_lib   = DsmTableLibrary::get_grid( $library_id );
			if ( is_array( $from_lib ) ) {
				$grid = $from_lib;
			}
		}

		if ( DsmTableSource::is_remote_source( $source ) && $live && '' !== $url ) {
			$remote = DsmTableSource::resolve_remote_grid( $source, $url, $header, $stored['comparison'] ?? array(), false );
			if ( ! is_wp_error( $remote ) ) {
				$grid          = $remote;
				$sanitize_rows = DsmTableSource::get_remote_max_rows();
			} else {
				$validated = DsmTableSource::prepare_remote_url( $source, $url );
				if ( ! is_wp_error( $validated ) ) {
					$last = DsmTableSource::get_last_good_grid( $source, $validated );
					if ( is_array( $last ) ) {
						$grid          = $last;
						$sanitize_rows = DsmTableSource::get_remote_max_rows();
					}
				}
			}
		} elseif ( 'loop' === $source ) {
			$loop = DsmTableSource::build_loop_grid(
				array(
					'post_type'  => self::read_inner_attr( $attrs, 'table_loop_post_type', 'post' ),
					'count'      => self::read_inner_attr( $attrs, 'table_loop_count', '10' ),
					'orderby'    => self::read_inner_attr( $attrs, 'table_loop_orderby', 'date' ),
					'order'      => self::read_inner_attr( $attrs, 'table_loop_order', 'DESC' ),
					'fields'     => self::read_inner_list( $attrs, 'table_loop_fields' ),
					'term_ids'   => self::read_inner_list( $attrs, 'table_loop_term_ids' ),
					'author'     => self::read_inner_attr( $attrs, 'table_loop_author', '' ),
					'comparison' => $stored['comparison'] ?? array(),
				)
			);
			if ( ! is_wp_error( $loop ) ) {
				$grid = $loop;
			}
		}

		/**
		 * Filter the resolved Table grid before render.
		 *
		 * @param array<string, mixed> $grid      Sanitized grid.
		 * @param string               $module_id Module id.
		 * @param array<string, mixed> $attrs     Module attrs.
		 */
		$grid = apply_filters( 'dsm_table_grid', $grid, $module_id, $attrs );
		if ( ! is_array( $grid ) ) {
			$grid = $stored;
		}

		return self::sanitize_grid( $grid, $sanitize_rows );
	}

	/**
	 * Register the first-party table interactive script (search / sort / pagination / export / live).
	 *
	 * @return void
	 */
	private static function register_table_scripts(): void {
		$version = defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';

		if ( ! wp_script_is( 'dsm-table', 'registered' ) ) {
			wp_register_script(
				'dsm-table',
				DSM_DIR_URL . 'assets/js/table-module.js',
				array(),
				$version,
				true
			);
		}
	}

	/**
	 * Localize REST base for Live refresh.
	 *
	 * @return void
	 */
	private static function localize_table_settings(): void {
		if ( ! wp_script_is( 'dsm-table', 'registered' ) && ! wp_script_is( 'dsm-table', 'enqueued' ) ) {
			return;
		}

		wp_localize_script(
			'dsm-table',
			'dsmTableSettings',
			array(
				'restUrl' => esc_url_raw( rest_url( 'dsm/v1/' ) ),
			)
		);
	}

	/**
	 * Enqueue interactive script when search, sort, pagination, export, or Live is on.
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 * @return void
	 */
	private static function maybe_enqueue_frontend_script( array $attrs ): void {
		$source = self::read_inner_attr( $attrs, 'data_source', 'manual' );
		$live   = self::is_on( $attrs, 'data_source_live', 'off' )
			&& DsmTableSource::is_remote_source( $source )
			&& '' !== trim( self::read_inner_attr( $attrs, 'data_source_url', '' ) );
		$need   = $live
			|| self::is_on( $attrs, 'table_search', 'off' )
			|| self::is_on( $attrs, 'table_sort', 'off' )
			|| self::is_on( $attrs, 'table_pagination', 'off' )
			|| self::is_on( $attrs, 'table_export', 'off' );

		if ( ! $need ) {
			return;
		}

		self::register_table_scripts();
		wp_enqueue_script( 'dsm-table' );
		self::localize_table_settings();
	}

	/**
	 * Vertical-align for table cells plus align-items for stacked cards.
	 *
	 * @param array<string, mixed> $params CommonStyle callback params.
	 * @return string
	 */
	public static function vertical_align_declaration( array $params ): string {
		$raw = $params['attrValue'] ?? '';
		if ( is_array( $raw ) ) {
			$raw = (string) ( $raw['value'] ?? '' );
		}
		$raw = sanitize_key( (string) $raw );

		$valign = '';
		$items  = '';
		if ( 'middle' === $raw ) {
			$valign = 'middle';
			$items  = 'center';
		} elseif ( 'bottom' === $raw ) {
			$valign = 'bottom';
			$items  = 'flex-end';
		} elseif ( 'top' === $raw ) {
			$valign = 'top';
			$items  = 'flex-start';
		}
		if ( '' === $valign ) {
			return '';
		}

		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
				'important'  => array(
					'vertical-align' => true,
					'align-items'    => true,
				),
			)
		);
		$style_declarations->add( 'vertical-align', $valign );
		$style_declarations->add( 'align-items', $items );

		return $style_declarations->value();
	}

	/**
	 * Render module styles (mirrors module-styles.js).
	 *
	 * @param array<string, mixed> $args Hook args.
	 * @return void
	 */
	public static function module_styles( array $args ): void {
		$args     = \DiviSupreme\Includes\DsmDiviBuilderCssScope::normalize_module_styles_args( $args );
		$attrs    = $args['attrs'] ?? array();
		$elements = $args['elements'];

		Style::add(
			array(
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => array(
					$elements->style(
						array(
							'attrName'   => 'module',
							'styleProps' => array(
								'disabledOn' => array(
									'disabledModuleVisibility' => $args['settings']['disabledModuleVisibility'] ?? null,
								),
							),
						)
					),
					TextStyle::style(
						array(
							'selector' => $args['orderClass'],
							'attr'     => $attrs['module']['advanced']['text'] ?? array(),
						)
					),
					CssStyle::style(
						array(
							'selector' => $args['orderClass'],
							'attr'     => $attrs['css'] ?? array(),
						)
					),
					$elements->style( array( 'attrName' => 'table_element' ) ),
					$elements->style( array( 'attrName' => 'table_header' ) ),
					$elements->style( array( 'attrName' => 'table_body' ) ),
					$elements->style( array( 'attrName' => 'table_footer' ) ),
					$elements->style( array( 'attrName' => 'table_caption_style' ) ),
					$elements->style( array( 'attrName' => 'table_links' ) ),
					$elements->style( array( 'attrName' => 'table_buttons' ) ),
					$elements->style( array( 'attrName' => 'table_badges' ) ),
					$elements->style( array( 'attrName' => 'table_icons' ) ),
					$elements->style( array( 'attrName' => 'table_row_even' ) ),
					$elements->style( array( 'attrName' => 'table_highlight' ) ),
					$elements->style( array( 'attrName' => 'table_row_hover' ) ),
					$elements->style( array( 'attrName' => 'table_ribbon' ) ),
					$elements->style( array( 'attrName' => 'table_toolbar' ) ),
					$elements->style( array( 'attrName' => 'table_toolbar_search' ) ),
					$elements->style( array( 'attrName' => 'table_toolbar_buttons' ) ),
					$elements->style( array( 'attrName' => 'table_cell' ) ),
					CommonStyle::style(
						array(
							'selector' => $args['orderClass'] . ' .dsm-table--sticky-header thead th',
							'attr'     => $attrs['table_sticky_offset']['innerContent'] ?? array(),
							'property' => 'top',
						)
					),
					CommonStyle::style(
						array(
							'selector' => $args['orderClass'] . ' .dsm-table-wrap',
							'attr'     => $attrs['table_stack_gap']['innerContent'] ?? array(),
							'property' => '--dsm-table-stack-gap',
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $args['orderClass'] . ' .dsm-table th, ' . $args['orderClass'] . ' .dsm-table td',
							'attr'                => $attrs['table_cell_vertical_align']['innerContent'] ?? array(),
							'declarationFunction' => array( self::class, 'vertical_align_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $args['orderClass'] . ' .dsm-table thead th',
							'attr'                => $attrs['table_header_vertical_align']['innerContent'] ?? array(),
							'declarationFunction' => array( self::class, 'vertical_align_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $args['orderClass'] . ' .dsm-table tbody th, ' . $args['orderClass'] . ' .dsm-table tbody td',
							'attr'                => $attrs['table_body_vertical_align']['innerContent'] ?? array(),
							'declarationFunction' => array( self::class, 'vertical_align_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $args['orderClass'] . ' .dsm-table tfoot th, ' . $args['orderClass'] . ' .dsm-table tfoot td',
							'attr'                => $attrs['table_footer_vertical_align']['innerContent'] ?? array(),
							'declarationFunction' => array( self::class, 'vertical_align_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector'  => $args['orderClass'] . ' .dsm-table-sort__icon',
							'attr'      => $attrs['table_sort_icon_color']['innerContent'] ?? array(),
							'property'  => 'color',
							'important' => true,
						)
					),
					CommonStyle::style(
						array(
							'selector'  => $args['orderClass'] . ' .dsm-table thead th[aria-sort=\'ascending\'] .dsm-table-sort__icon, ' . $args['orderClass'] . ' .dsm-table thead th[aria-sort=\'descending\'] .dsm-table-sort__icon',
							'attr'      => $attrs['table_sort_icon_active_color']['innerContent'] ?? array(),
							'property'  => 'color',
							'important' => true,
						)
					),
					CommonStyle::style(
						array(
							'selector' => $args['orderClass'] . ' .dsm-table-sort__icon',
							'attr'     => $attrs['table_sort_icon_size']['innerContent'] ?? array(),
							'property' => 'font-size',
						)
					),
					...self::column_item_style_declarations( $attrs, (string) ( $args['orderClass'] ?? '' ) ),
				),
			)
		);
	}

	/**
	 * Script data.
	 *
	 * @param array<string, mixed> $args Hook args.
	 * @return void
	 */
	public static function module_script_data( array $args ): void {
		$elements = $args['elements'];
		$elements->script_data(
			array(
				'attrName' => 'module',
			)
		);
	}

	/**
	 * Module classnames.
	 *
	 * @param array<string, mixed> $args Hook args.
	 * @return void
	 */
	public static function module_classnames( array $args ): void {
		$classnames_instance = $args['classnamesInstance'];
		$attrs               = $args['attrs'];

		$classnames_instance->add(
			ElementClassnames::classnames(
				array(
					'attrs' => $attrs['module']['decoration'] ?? array(),
				)
			)
		);
	}

	/**
	 * Frontend HTML.
	 *
	 * @param array<string, mixed> $attrs    Block attributes.
	 * @param string               $content  Inner content.
	 * @param \WP_Block            $block    Block instance.
	 * @param mixed                $elements Module elements.
	 * @return string
	 */
	public static function render_callback( $attrs, $content, $block, $elements ): string {
		if ( ! is_array( $attrs ) ) {
			$attrs = array();
		}

		$attrs = self::normalize_table_cell_text_attr( $attrs );

		self::maybe_enqueue_frontend_script( $attrs );

		$module_id = isset( $block->parsed_block['id'] ) ? (string) $block->parsed_block['id'] : '';
		$grid      = self::resolve_render_grid( $attrs, $module_id );

		$caption  = self::resolve_dynamic_plain(
			self::read_inner_attr( $attrs, 'table_caption', '' )
		);
		$mode     = self::read_inner_attr( $attrs, 'table_responsive_mode', 'scroll' );
		$source   = self::read_inner_attr( $attrs, 'data_source', 'manual' );
		$url      = trim( self::read_inner_attr( $attrs, 'data_source_url', '' ) );
		$live     = self::is_on( $attrs, 'data_source_live', 'off' )
			&& DsmTableSource::is_remote_source( $source )
			&& '' !== $url;
		$live_url = '';
		if ( $live ) {
			$validated = DsmTableSource::prepare_remote_url( $source, $url );
			if ( ! is_wp_error( $validated ) ) {
				$live_url = $validated;
			} else {
				$live = false;
			}
		}

		$page_size = absint( self::read_inner_attr( $attrs, 'table_page_size', '10' ) );

		$table_html = self::render_table_html(
			$grid,
			array(
				'caption'              => $caption,
				'show_header'          => self::is_on( $attrs, 'table_show_header', 'on' ),
				'first_col_header'     => self::is_on( $attrs, 'table_first_col_header', 'on' ),
				'responsive_mode'      => $mode,
				'sticky_header'        => self::is_on( $attrs, 'table_sticky_header', 'on' ),
				'zebra'                => self::is_on( $attrs, 'table_zebra', 'on' ),
				'hover'                => self::is_on( $attrs, 'table_hover', 'on' ),
				'stack_gap'            => self::read_inner_attr( $attrs, 'table_stack_gap', '12px' ),
				'table_id'             => $module_id,
				'search'               => self::is_on( $attrs, 'table_search', 'off' ),
				'search_layout'        => self::read_inner_attr( $attrs, 'table_search_layout', 'top' ),
				'search_align'         => self::read_toolbar_align( $attrs, 'table_search_align', 'left' ),
				'sort'                 => self::is_on( $attrs, 'table_sort', 'off' ),
				'pagination'           => self::is_on( $attrs, 'table_pagination', 'off' ),
				'pagination_layout'    => self::read_inner_attr( $attrs, 'table_pagination_layout', 'top' ),
				'pagination_align'     => self::read_toolbar_align( $attrs, 'table_pagination_align', 'left' ),
				'export'               => self::is_on( $attrs, 'table_export', 'off' ),
				'page_size'            => $page_size,
				'live'                 => $live,
				'source'               => $source,
				'remote_url'           => $live_url,
				'refresh_minutes'      => DsmTableSource::normalize_refresh_minutes(
					self::read_inner_attr( $attrs, 'data_source_refresh_interval', '15' )
				),
				'header_row'           => self::is_on( $attrs, 'table_source_header_row', 'on' ),
				'sort_default_column'  => self::read_inner_attr( $attrs, 'table_sort_default_column', '' ),
				'sort_default_dir'     => self::read_inner_attr( $attrs, 'table_sort_default_dir', 'asc' ),
				'empty_text'           => self::resolve_dynamic_plain(
					self::read_inner_attr( $attrs, 'table_empty_text', '' )
				),
				'search_empty_text'    => self::resolve_dynamic_plain(
					self::read_inner_attr( $attrs, 'table_search_empty_text', '' )
				),
				'search_placeholder'   => self::resolve_dynamic_plain(
					self::read_inner_attr( $attrs, 'table_search_placeholder', '' )
				),
				'pagination_prev_text' => self::resolve_dynamic_plain(
					self::read_inner_attr( $attrs, 'table_pagination_prev_text', '' )
				),
				'pagination_next_text' => self::resolve_dynamic_plain(
					self::read_inner_attr( $attrs, 'table_pagination_next_text', '' )
				),
				'export_text'          => self::resolve_dynamic_plain(
					self::read_inner_attr( $attrs, 'table_export_text', '' )
				),
				'ribbon_placement'     => self::read_inner_attr( $attrs, 'table_ribbon_placement', 'before' ),
			)
		);

		$module_inner = HTMLUtility::render(
			array(
				'tag'               => 'div',
				'attributes'        => array(
					'class' => 'et_pb_module_inner dsm-table-inner',
				),
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $table_html,
			)
		);

		$module_elements           = $elements->style_components(
			array(
				'attrName' => 'module',
			)
		);
		$module_container_children = $module_elements . $module_inner;

		return Module::render(
			array(
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],
				'attrs'               => $attrs,
				'elements'            => $elements,
				'id'                  => $block->parsed_block['id'],
				'moduleClassName'     => 'dsm_table',
				'name'                => $block->block_type->name,
				'classnamesFunction'  => array( self::class, 'module_classnames' ),
				'moduleCategory'      => $block->block_type->category,
				'stylesComponent'     => array( self::class, 'module_styles' ),
				'scriptDataComponent' => array( self::class, 'module_script_data' ),
				'children'            => $module_container_children,
			)
		);
	}
}
