<?php
/**
 * Contact Form 7 Module.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Modules;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\Module\Options\Element\ElementClassnames;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\Module\Options\Css\CssStyle;

/**
 * Class that handles "ContactForm7 Module" module.
 */
class ContactForm7 implements DependencyInterface {



	/**
	 * Register module.
	 * `DependencyInterface` interface ensures class method name `load()` is executed for initialization.
	 */
	public function load() {
		add_action( 'init', array( self::class, 'register_module' ) );
		add_action( 'init', array( $this, 'register_wordpress_shortcodes' ) );
		add_action( 'wp_ajax_dsm_contact_form', array( $this, 'render_form' ) );
		add_action( 'divi_visual_builder_assets_before_enqueue_scripts', array( $this, 'load_contact_forms' ) );
		add_action( 'wpcf7_init', array( $this, 'dsm_remove_cf7_default_select_form_tag' ), 9 );
		add_action( 'wpcf7_init', array( $this, 'dsm_register_custom_shortcodes' ) );
		add_action( 'wpcf7_init', array( $this, 'dsm_register_cf7_select_form_tag' ), 11 );

		// Also try to register CF7 shortcodes early if CF7 is already loaded.
		add_action( 'init', array( $this, 'dsm_register_custom_shortcodes' ), 20 );
	}

	/**
	 * Register WordPress shortcodes.
	 */
	public function register_wordpress_shortcodes() {
		add_shortcode( 'dsm_submit', array( $this, 'dsm_submit_wp_shortcode_handler' ) );
		// Legacy hyphenated tag left in older renders.
		add_shortcode( 'dsm-submit', array( $this, 'dsm_submit_wp_shortcode_handler' ) );
	}

	/**
	 * Register our custom CF7 shortcodes.
	 */
	public function dsm_register_custom_shortcodes() {
		// Only register if CF7 is available.
		if ( ! function_exists( 'wpcf7_add_form_tag' ) ) {
			return;
		}

		// Check if shortcode type exists (with fallback for older CF7 versions)
		// CF7 sanitizes tag types: hyphens become underscores (`dsm-submit` → `dsm_submit`).
		$shortcode_exists = function_exists( 'wpcf7_form_tag_type_exists' )
			? wpcf7_form_tag_type_exists( 'dsm_submit' )
			: false;

		if ( ! $shortcode_exists ) {
			// Nameless like native [submit] — do NOT pass true (that enables name-attr).
			wpcf7_add_form_tag( 'dsm_submit', array( $this, 'dsm_submit_shortcode_handler' ) );
		}

		// Add more custom shortcodes here as needed:
		// wpcf7_add_form_tag( 'dsm-text', array( $this, 'dsm_text_shortcode_handler' ), true );
		// Wpcf7_add_form_tag( 'dsm-textarea', array( $this, 'dsm_textarea_shortcode_handler' ), true );.
	}

	/**
	 * Unhook Contact Form 7 default select tag so we can wrap selects for custom arrow styling.
	 *
	 * @return void
	 */
	public function dsm_remove_cf7_default_select_form_tag() {
		remove_action( 'wpcf7_init', 'wpcf7_add_form_tag_select', 10 );
	}

	/**
	 * Register select / select* form tags with wrapper class used by module styles (Divi-style chevron).
	 *
	 * @return void
	 */
	public function dsm_register_cf7_select_form_tag() {
		if ( ! function_exists( 'wpcf7_add_form_tag' ) ) {
			return;
		}

		wpcf7_add_form_tag(
			array( 'select', 'select*' ),
			array( $this, 'dsm_cf7_select_form_tag_handler' ),
			array(
				'name-attr'         => true,
				'selectable-values' => true,
			)
		);
	}

	/**
	 * Renders CF7 select markup with `dsm-contact-form-7-select` wrapper (matches D4 / Divi contact field arrow pattern).
	 *
	 * @param object $tag WPCF7_FormTag instance.
	 * @return string HTML.
	 */
	public function dsm_cf7_select_form_tag_handler( $tag ) {
		if ( empty( $tag->name ) ) {
			return '';
		}

		$validation_error = wpcf7_get_validation_error( $tag->name );
		$class            = wpcf7_form_controls_class( $tag->type );

		if ( $validation_error ) {
			$class .= ' wpcf7-not-valid';
		}

		$atts = array();

		$atts['class']        = $tag->get_class_option( $class . ' et_pb_contact_select input' );
		$atts['id']           = $tag->get_id_option();
		$atts['tabindex']     = $tag->get_option( 'tabindex', 'signed_int', true );
		$atts['autocomplete'] = $tag->get_option(
			'autocomplete',
			'[-0-9a-zA-Z]+',
			true
		);

		if ( $tag->is_required() ) {
			$atts['aria-required'] = 'true';
		}

		if ( $validation_error ) {
			$atts['aria-invalid']     = 'true';
			$atts['aria-describedby'] = wpcf7_get_validation_error_reference( $tag->name );
		} else {
			$atts['aria-invalid'] = 'false';
		}

		$multiple       = $tag->has_option( 'multiple' );
		$include_blank  = $tag->has_option( 'include_blank' );
		$first_as_label = $tag->has_option( 'first_as_label' );

		if ( $tag->has_option( 'size' ) ) {
			$size = $tag->get_option( 'size', 'int', true );
			if ( $size ) {
				$atts['size'] = $size;
			} elseif ( $multiple ) {
				$atts['size'] = 4;
			} else {
				$atts['size'] = 1;
			}
		}

		$data = (array) $tag->get_data_option();
		if ( array() !== $data ) {
			$tag->values = array_merge( $tag->values, array_values( $data ) );
			$tag->labels = array_merge( $tag->labels, array_values( $data ) );
		}

		$values         = $tag->values;
		$labels         = $tag->labels;
		$default_choice = $tag->get_default_option(
			null,
			array(
				'multiple' => $multiple,
			)
		);

		if ( $include_blank || empty( $values ) ) {
			array_unshift(
				$labels,
				__( '&#8212;Please choose an option&#8212;', 'contact-form-7' )
			);
			array_unshift( $values, '' );
		} elseif ( $first_as_label ) {
			$values[0] = '';
		}

		$html     = '';
		$hangover = wpcf7_get_hangover( $tag->name );

		foreach ( $values as $key => $value ) {
			if ( $hangover ) {
				$selected = in_array( $value, (array) $hangover, true );
			} else {
				$selected = in_array( $value, (array) $default_choice, true );
			}

			$item_atts = array(
				'value'    => $value,
				'selected' => $selected,
			);

			$label = isset( $labels[ $key ] ) ? $labels[ $key ] : $value;

			$html .= sprintf(
				'<option %1$s>%2$s</option>',
				wpcf7_format_atts( $item_atts ),
				esc_html( $label )
			);
		}

		$atts['multiple'] = (bool) $multiple;
		$atts['name']     = $tag->name . ( $multiple ? '[]' : '' );

		return sprintf(
			'<span class="wpcf7-form-control-wrap dsm-contact-form-7-select" data-name="%1$s"><select %2$s>%3$s</select>%4$s</span>',
			esc_attr( $tag->name ),
			wpcf7_format_atts( $atts ),
			$html,
			$validation_error
		);
	}

	/**
	 * CF7 form-tag handler for nameless `[dsm_submit]` (rewritten from `[submit]`).
	 *
	 * @param object $tag WPCF7_FormTag instance.
	 * @return string Button HTML.
	 */
	public function dsm_submit_shortcode_handler( $tag ) {
		$base_class  = wpcf7_form_controls_class( $tag->type, 'has-spinner' );
		$base_class .= ' et_pb_button dsm-custom-submit';

		$class = $tag->get_class_option( $base_class );
		if ( empty( $class ) ) {
			$class = $base_class;
		}

		$atts = array(
			'class'    => $class,
			'id'       => $tag->get_id_option(),
			'tabindex' => $tag->get_option( 'tabindex', 'signed_int', true ),
			'type'     => 'submit',
		);

		$value = isset( $tag->values[0] ) ? (string) $tag->values[0] : '';
		if ( '' === $value ) {
			$value = __( 'Send', 'contact-form-7' );
		}

		return sprintf(
			'<button %s>%s<span class="dsm-spinner"></span></button>',
			wpcf7_format_atts( $atts ),
			esc_html( $value )
		);
	}

	/**
	 * WordPress shortcode handler for `[dsm_submit]` / legacy `[dsm-submit]`.
	 *
	 * Parses CF7 `class:` / `id:` options; does not treat `class:myclass` as the label.
	 *
	 * @param array|string $atts    Shortcode attributes.
	 * @param string       $content Shortcode content.
	 * @return string The rendered shortcode output.
	 */
	public function dsm_submit_wp_shortcode_handler( $atts, $content = '' ) {
		$parsed = self::parse_cf7_submit_wp_atts( is_array( $atts ) ? $atts : array(), (string) $content );

		$class = 'et_pb_button has-spinner dsm-custom-submit';
		if ( ! empty( $parsed['classes'] ) ) {
			$class .= ' ' . implode( ' ', $parsed['classes'] );
		}

		$button_atts = array(
			'class' => $class,
			'type'  => 'submit',
		);

		if ( '' !== $parsed['id'] ) {
			$button_atts['id'] = $parsed['id'];
		}

		if ( '' !== $parsed['tabindex'] ) {
			$button_atts['tabindex'] = (string) intval( $parsed['tabindex'] );
		}

		$atts_str = '';
		foreach ( $button_atts as $key => $value ) {
			if ( '' !== (string) $value ) {
				$atts_str .= sprintf( ' %s="%s"', esc_attr( $key ), esc_attr( (string) $value ) );
			}
		}

		return sprintf(
			'<p><button%s><span class="dsm-button-text">%s</span><span class="dsm-spinner"></span></button></p>',
			$atts_str,
			esc_html( $parsed['label'] )
		);
	}

	/**
	 * Parse CF7 submit options from a WordPress shortcode atts array.
	 *
	 * @param array<string|int, mixed> $atts    Shortcode attributes.
	 * @param string                   $content Enclosed shortcode content.
	 * @return array{classes: array<int, string>, id: string, tabindex: string, label: string}
	 */
	private static function parse_cf7_submit_wp_atts( array $atts, string $content = '' ): array {
		$parsed = array(
			'classes'  => array(),
			'id'       => '',
			'tabindex' => '',
			'label'    => '',
		);

		if ( isset( $atts['class'] ) && is_string( $atts['class'] ) && '' !== $atts['class'] ) {
			$parts = preg_split( '/\s+/', $atts['class'] );
			if ( is_array( $parts ) ) {
				foreach ( $parts as $slug ) {
					self::append_cf7_submit_class( $parsed, $slug );
				}
			}
			unset( $atts['class'] );
		}

		if ( isset( $atts['id'] ) && is_string( $atts['id'] ) && '' !== $atts['id'] ) {
			$parsed['id'] = sanitize_html_class( $atts['id'] );
			unset( $atts['id'] );
		}

		if ( isset( $atts['tabindex'] ) && '' !== (string) $atts['tabindex'] ) {
			$parsed['tabindex'] = sanitize_text_field( (string) $atts['tabindex'] );
			unset( $atts['tabindex'] );
		}

		unset( $atts['type'], $atts['text'] );

		foreach ( $atts as $key => $value ) {
			$token = is_int( $key ) ? (string) $value : (string) $key;
			self::apply_cf7_submit_token( $token, $parsed );
		}

		if ( '' !== trim( $content ) ) {
			$parsed['label'] = $content;
		}

		if ( '' === $parsed['label'] ) {
			$parsed['label'] = __( 'Send', 'contact-form-7' );
		}

		return $parsed;
	}

	/**
	 * Parse a CF7-style attribute string (` class:foo id:bar "Label"`).
	 *
	 * @param string $raw Attribute string inside the form tag.
	 * @return array{classes: array<int, string>, id: string, tabindex: string, label: string}
	 */
	private static function parse_cf7_submit_attr_string( string $raw ): array {
		$parsed = array(
			'classes'  => array(),
			'id'       => '',
			'tabindex' => '',
			'label'    => '',
		);

		$raw = trim( $raw );
		if ( '' === $raw ) {
			$parsed['label'] = __( 'Send', 'contact-form-7' );
			return $parsed;
		}

		if ( ! preg_match_all( '/"([^"]*)"|\'([^\']*)\'|(\S+)/', $raw, $matches, PREG_SET_ORDER ) ) {
			$parsed['label'] = __( 'Send', 'contact-form-7' );
			return $parsed;
		}

		foreach ( $matches as $match ) {
			$token = isset( $match[0][0] ) ? $match[0][0] : '';
			if ( '"' === $token ) {
				$parsed['label'] = isset( $match[1] ) ? $match[1] : '';
				continue;
			}
			if ( "'" === $token ) {
				$parsed['label'] = isset( $match[2] ) ? $match[2] : '';
				continue;
			}
			self::apply_cf7_submit_token( isset( $match[3] ) ? $match[3] : $match[0], $parsed );
		}

		if ( '' === $parsed['label'] ) {
			$parsed['label'] = __( 'Send', 'contact-form-7' );
		}

		return $parsed;
	}

	/**
	 * Apply one CF7 form-tag token to the parsed submit options.
	 *
	 * @param string $token  Raw token.
	 * @param array  $parsed Parsed accumulator.
	 * @return void
	 */
	private static function apply_cf7_submit_token( string $token, array &$parsed ): void {
		if ( 0 === strpos( $token, 'class:' ) ) {
			self::append_cf7_submit_class( $parsed, substr( $token, 6 ) );
			return;
		}

		if ( 0 === strpos( $token, 'id:' ) ) {
			$id = sanitize_html_class( substr( $token, 3 ) );
			if ( '' !== $id ) {
				$parsed['id'] = $id;
			}
			return;
		}

		if ( 0 === strpos( $token, 'tabindex:' ) ) {
			$parsed['tabindex'] = sanitize_text_field( substr( $token, 9 ) );
			return;
		}

		if ( false === strpos( $token, ':' ) && '' !== $token && '' === $parsed['label'] ) {
			$parsed['label'] = $token;
		}
	}

	/**
	 * Append a sanitized CSS class slug.
	 *
	 * @param array  $parsed Parsed accumulator.
	 * @param string $slug   Raw class slug.
	 * @return void
	 */
	private static function append_cf7_submit_class( array &$parsed, string $slug ): void {
		$slug = sanitize_html_class( $slug );
		if ( '' !== $slug && ! in_array( $slug, $parsed['classes'], true ) ) {
			$parsed['classes'][] = $slug;
		}
	}

	/**
	 * Map a stored Contact Form 7 post ID to the current WPML language.
	 *
	 * @param mixed $contact_form_id Form post ID from module settings or AJAX.
	 * @return int
	 */
	private static function get_translated_cf7_form_id( $contact_form_id ): int {
		$form_id = absint( $contact_form_id );

		if ( $form_id < 1 ) {
			return 0;
		}

		$mapped = apply_filters( 'wpml_object_id', $form_id, 'wpcf7_contact_form', true );

		return absint( $mapped ? $mapped : $form_id );
	}

	/**
	 * Get the Contact Form 7 form object.
	 *
	 * @param string $contact_form_id The form ID.
	 * @return \WPCF7_ContactForm|null The contact form object or null if not found.
	 */
	private static function get_contact_form( $contact_form_id ) {
		$form_id = self::get_translated_cf7_form_id( $contact_form_id );

		if ( $form_id < 1 ) {
			return null;
		}

		return wpcf7_contact_form( $form_id );
	}

	/**
	 * Get the form with processed shortcodes.
	 *
	 * @param \WPCF7_ContactForm $contact_form The contact form object.
	 * @param array              $attrs        The module attributes.
	 * @return string The form HTML with processed shortcodes.
	 */
	private static function get_processed_form_html( $contact_form, $attrs = array() ) {
		if ( is_null( $contact_form ) ) {
			return '';
		}

		// Get the original form content (shortcodes).
		$form_content = $contact_form->prop( 'form' );

		// Process the shortcodes before CF7 renders them.
		$processed_content = self::process_form_shortcodes( $form_content, $attrs );

		// Temporarily replace the form content.
		$original_form = $contact_form->prop( 'form' );
		$contact_form->set_properties( array( 'form' => $processed_content ) );

		// Get the HTML with our processed shortcodes.
		$form_html = $contact_form->form_html();

		if ( false !== strpos( $form_html, '[dsm_submit' ) || false !== strpos( $form_html, '[dsm-submit' ) ) {
			$form_html = self::fallback_html_replacement( $form_html );
		}

		// Restore the original form content.
		$contact_form->set_properties( array( 'form' => $original_form ) );

		return $form_html;
	}

	/**
	 * Process and replace shortcodes in the form content.
	 *
	 * @param string $form_content The original form content with shortcodes.
	 * @param array  $attrs        The module attributes.
	 * @return string The processed form content with custom shortcodes.
	 */
	private static function process_form_shortcodes( $form_content, $attrs = array() ) {
		if ( empty( $form_content ) ) {
			return '';
		}

		// Replace submit shortcodes with our custom ones.
		$processed_content = self::replace_submit_shortcodes( $form_content, $attrs );

		// Add more shortcode replacements here as needed:
		// $processed_content = self::replace_text_shortcodes( $processed_content, $attrs );
		// $processed_content = self::replace_textarea_shortcodes( $processed_content, $attrs );.

		return $processed_content;
	}

	/**
	 * Replace [submit] form tags with [dsm_submit] so CF7 can match the registered type.
	 *
	 * @param string $form_content The form content.
	 * @param array  $attrs        The module attributes.
	 * @return string The form content with replaced shortcodes.
	 */
	private static function replace_submit_shortcodes( $form_content, $attrs = array() ) {

		// Use the general shortcode replacement method.
		$result = self::replace_shortcodes_in_content(
			$form_content,
			array( 'submit' => 'dsm_submit' )
		);

		return $result;
	}

	/**
	 * Replace shortcodes in general WordPress content.
	 *
	 * @param string $content The content to process.
	 * @param array  $replacements Array of shortcode replacements.
	 * @return string The processed content.
	 */
	public static function replace_shortcodes_in_content( $content, $replacements = array() ) {
		// Default replacements.
		$default_replacements = array(
			'submit' => 'dsm_submit',
		);

		$replacements = wp_parse_args( $replacements, $default_replacements );

		/**
		 * Filter: dsm_shortcode_replacements
		 *
		 * Allows developers to modify the shortcode replacement mappings.
		 *
		 * @param array  $replacements Array of shortcode replacements (old => new).
		 * @param string $content      The content being processed.
		 */
		$replacements = apply_filters( 'dsm_shortcode_replacements', $replacements, $content );

		foreach ( $replacements as $old_shortcode => $new_shortcode ) {
			// Replace shortcodes while preserving all attributes and content.
			$pattern     = '/\[' . preg_quote( $old_shortcode, '/' ) . '(\s[^\]]*?)?\]/';
			$replacement = '[' . $new_shortcode . '$1]';
			$content     = preg_replace( $pattern, $replacement, $content );
		}

		/**
		 * Filter: dsm_processed_shortcode_content
		 *
		 * Allows developers to modify the content after shortcode replacements.
		 *
		 * @param string $content      The processed content.
		 * @param array  $replacements The replacements that were applied.
		 */
		return apply_filters( 'dsm_processed_shortcode_content', $content, $replacements );
	}

	/**
	 * Generate the final form container HTML.
	 *
	 * @param string $form_html The form HTML.
	 * @return string The final container HTML.
	 */
	private static function generate_form_container( $form_html ) {
		return HTMLUtility::render(
			array(
				'tag'               => 'div',
				'attributes'        => array(
					'class' => 'et_pb_module_inner dsm-cf7-container',
				),
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $form_html,
			)
		);
	}

	/**
	 * Renders the form in the ajax request.
	 *
	 * @return void
	 */
	public function render_form() {
		$nonce = isset( $_REQUEST['nonce'] )
			? sanitize_text_field( wp_unslash( (string) $_REQUEST['nonce'] ) )
			: '';

		if ( '' === $nonce || ! wp_verify_nonce( $nonce, 'render_dsm_form' ) ) {
			exit;
		}

		$contact_form_id = isset( $_REQUEST['id'] ) ? absint( wp_unslash( $_REQUEST['id'] ) ) : 0;
		$contact_form    = self::get_contact_form( $contact_form_id );

		if ( is_null( $contact_form ) || 0 === $contact_form_id ) {
			echo 'No contact form 7 Selected';
			exit;
		}

		// Ensure CF7 shortcodes are registered for AJAX calls.
		$this->ensure_cf7_shortcodes_registered();

		// Use the same shortcode processing for AJAX requests.
		$result = self::get_processed_form_html( $contact_form, array() );

		// FALLBACK: If shortcode is still visible, do direct HTML replacement.
		if ( false !== strpos( $result, '[dsm_submit' ) || false !== strpos( $result, '[dsm-submit' ) ) {
			$result = self::fallback_html_replacement( $result );
		}

		if ( function_exists( 'et_core_intentionally_unescaped' ) ) {
			echo et_core_intentionally_unescaped( $result, 'Contact Form 7 generated form markup' );
		} else {
			// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- CF7 generates trusted form markup.
			echo $result;
		}
		exit;
	}

	/**
	 * Fallback HTML replacement for when shortcode processing fails.
	 *
	 * @param string $html Form HTML that still contains submit form tags.
	 * @return string
	 */
	private static function fallback_html_replacement( $html ) {
		$pattern = '/\[dsm[_-]submit([^\]]*)\]/';

		$replacement = static function ( $matches ) {
			$parsed = self::parse_cf7_submit_attr_string( isset( $matches[1] ) ? (string) $matches[1] : '' );
			$class  = 'et_pb_button has-spinner dsm-custom-submit';
			if ( ! empty( $parsed['classes'] ) ) {
				$class .= ' ' . implode( ' ', $parsed['classes'] );
			}

			$id_attr = '' !== $parsed['id']
				? ' id="' . esc_attr( $parsed['id'] ) . '"'
				: '';

			return sprintf(
				'<button type="submit" class="%s"%s>%s<span class="dsm-spinner"></span></button>',
				esc_attr( $class ),
				$id_attr,
				esc_html( $parsed['label'] )
			);
		};

		$replaced = preg_replace_callback( $pattern, $replacement, $html );

		return is_string( $replaced ) ? $replaced : $html;
	}

	/**
	 * Ensure CF7 shortcodes are registered (for AJAX calls).
	 */
	private function ensure_cf7_shortcodes_registered() {
		// Check if CF7 is available and shortcode is not already registered.
		if ( function_exists( 'wpcf7_add_form_tag' ) ) {
			wpcf7_add_form_tag( 'dsm_submit', array( $this, 'dsm_submit_shortcode_handler' ) );
		}

		if ( ! shortcode_exists( 'dsm_submit' ) ) {
			add_shortcode( 'dsm_submit', array( $this, 'dsm_submit_wp_shortcode_handler' ) );
		}
		if ( ! shortcode_exists( 'dsm-submit' ) ) {
			add_shortcode( 'dsm-submit', array( $this, 'dsm_submit_wp_shortcode_handler' ) );
		}
	}

	/**
	 * Loads the list of cf7 contact forms.
	 *
	 * @return void
	 */
	public function load_contact_forms() {

		$forms = get_posts(
			array(
				'post_type'      => 'wpcf7_contact_form',
				'posts_per_page' => -1,
			)
		);

		$processed_forms = array(
			'none' => array(
				'label' => 'Select Contact Form',
			),
		);

		foreach ( $forms as $form ) {
			$processed_forms[ $form->ID ] = array(
				'label' => $form->post_title,
			);
		}

		wp_localize_script(
			'dsm-supreme-modules',
			'dsmContactForms',
			array(
				'forms'       => $processed_forms,
				'renderNonce' => wp_create_nonce( 'render_dsm_form' ),
			)
		);
	}

	/**
	 * Initilises the module.
	 *
	 * @return void
	 */
	public static function dsm_initialise() {
		add_action(
			'divi_module_library_modules_dependency_tree',
			function ( $dependency_tree ) {
				$dependency_tree->add_dependency( new self() );
			}
		);
	}

	/**
	 * Register module.
	 */
	public static function register_module() {

		$module_json_path = DSM_DIR_PATH . 'divi-5/public/packages/module-library/contact-form7';

		ModuleRegistration::register_module(
			$module_json_path,
			array(
				'render_callback' => array( self::class, 'render_callback' ),
			)
		);
	}

	/**
	 * Render module style.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_styles( $args ) {
		$args     = \DiviSupreme\Includes\DsmDiviBuilderCssScope::normalize_module_styles_args( $args );
		$attrs    = $args['attrs'] ?? array();
		$elements = $args['elements'];

		Style::add(
			array(
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => array(
					// Module.
					$elements->style(
						array(
							'attrName'   => 'module',
							'styleProps' => array(
								'disabledOn' => array(
									'disabledModuleVisibility' => $args['settings']['disabledModuleVisibility'] ?? null,
								),
							),
						)
					),

					CssStyle::style(
						array(
							'selector' => $args['orderClass'],
							'attr'     => $attrs['css'] ?? array(),
						)
					),

					$elements->style(
						array(
							'attrName' => 'labels',
						)
					),

					$elements->style(
						array(
							'attrName' => 'input_textarea_select',
						)
					),

					$elements->style(
						array(
							'attrName' => 'date_field',
						)
					),

					$elements->style(
						array(
							'attrName' => 'date_icon',
						)
					),

					$elements->style(
						array(
							'attrName' => 'error_msg',
						)
					),

					$elements->style(
						array(
							'attrName' => 'placeholder',
						)
					),

					$elements->style(
						array(
							'attrName' => 'radio_checkbox',
						)
					),

					$elements->style(
						array(
							'attrName' => 'button',
						)
					),

					$elements->style(
						array(
							'attrName' => 'file',
						)
					),

					$elements->style(
						array(
							'attrName' => 'file_padding',
						)
					),

					$elements->style(
						array(
							'attrName' => 'error_validation',
						)
					),

					$elements->style(
						array(
							'attrName' => 'validation_success',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .wpcf7 label",
							'attr'     => $attrs['label_bottom_spacing']['innerContent'] ?? array(),
							'property' => 'margin-bottom',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .wpcf7-form p:nth-last-of-type(1)",
							'attr'     => $attrs['button_alignment']['innerContent'] ?? array(),
							'property' => 'text-align',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .wpcf7 form.invalid .wpcf7-response-output, {$args['orderClass']} .wpcf7 form.unaccepted .wpcf7-response-output",
							'attr'     => $attrs['button_alignment']['innerContent'] ?? array(),
							'property' => 'text-align',
						)
					),

				),
			)
		);
	}

	/**
	 * Render module script data.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_script_data( $args ) {
		$elements = $args['elements'];

		// Element Script Data Options.
		$elements->script_data(
			array(
				'attrName' => 'module',
			)
		);
	}

	/**
	 * Render module classnames.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_classnames( $args ) {
		$classnames_instance = $args['classnamesInstance'];
		$attrs               = $args['attrs'];

		// Module.
		$classnames_instance->add(
			ElementClassnames::classnames(
				array(
					'attrs' => $attrs['module']['decoration'] ?? array(),
				)
			)
		);
	}

	/**
	 * Render module HTML output.
	 *
	 * @param array     $attrs - Modules Attributes.
	 * @param string    $content - Content.
	 * @param \WP_Block $block - Block.
	 * @param mixed     $elements - Elements.
	 */
	public static function render_callback( $attrs, $content, $block, $elements ) {

		if ( ! dsm_is_cf7_active() ) {
			return '';
		}

		$contact_form_id = $attrs['cf7_library']['innerContent']['desktop']['value'] ?? '';
		$contact_form    = self::get_contact_form( $contact_form_id );

		if ( is_null( $contact_form ) ) {
			return '';
		}

		// Get the form HTML with processed shortcodes.
		$form_html = self::get_processed_form_html( $contact_form, $attrs );

		// Generate the final form container.
		$module_inner = self::generate_form_container( $form_html );

		// This are the module elements that will be rendered in the frontend.
		$module_elements = $elements->style_components(
			array(
				'attrName' => 'module',
			)
		);

		// This are the children of the module container, which are the module elements and the module inner.
		$module_container_children = $module_elements . $module_inner;

		return Module::render(
			array(
				// FE only.
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],

				// VB equivalent.
				'attrs'               => $attrs,
				'elements'            => $elements,
				'id'                  => $block->parsed_block['id'],
				'name'                => $block->block_type->name,
				'classnamesFunction'  => array( self::class, 'module_classnames' ),
				'moduleCategory'      => $block->block_type->category,
				'stylesComponent'     => array( self::class, 'module_styles' ),
				'scriptDataComponent' => array( self::class, 'module_script_data' ),
				'children'            => $module_container_children,
			)
		);
	}
}
