<?php
/**
 * Masonry Gallery module (Divi 5).
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Modules;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use DiviSupreme\Includes\Module\MasonryGallerySvgDecoration;
use DiviSupreme\Utils\HeadingLevel;
use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\Module\Options\Element\ElementClassnames;
use ET\Builder\Packages\Module\Options\Text\TextStyle;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\Packages\ModuleUtils\ModuleUtils;
use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;

/**
 * Supreme Masonry Gallery — Masonry layout + optional lightbox (D4 parity).
 */
class MasonryGallery implements DependencyInterface {


	/**
	 * Register module.
	 */
	public function load(): void {
		add_action( 'init', array( self::class, 'register_module' ) );
	}

	/**
	 * Initialise module dependency.
	 */
	public static function dsm_initialise(): void {
		add_action(
			'divi_module_library_modules_dependency_tree',
			static function ( $dependency_tree ): void {
				$dependency_tree->add_dependency( new self() );
			}
		);
	}

	/**
	 * Register module with Divi.
	 */
	public static function register_module(): void {
		$module_json_path = DSM_DIR_PATH . 'divi-5/public/packages/module-library/masonry-gallery';

		ModuleRegistration::register_module(
			$module_json_path,
			array(
				'render_callback' => array( self::class, 'render_callback' ),
			)
		);
	}

	/**
	 * Order class token for Magnific mainClass (matches `baseOrderClass` / module wrapper), no leading dot.
	 *
	 * @param string          $block_id       Block id.
	 * @param int|string|null $store_instance Block store instance.
	 * @param int             $order_index    Fallback index.
	 * @param string          $block_name     Namespaced block name.
	 * @return string
	 */
	private static function masonry_lightbox_scope_class_token( string $block_id, $store_instance, int $order_index, string $block_name ): string {
		$scope = ModuleUtils::get_module_order_class_name( $block_id, $store_instance );
		if ( '' !== $scope ) {
			return $scope;
		}

		$base = ModuleUtils::get_module_class_by_name( $block_name );
		if ( '' === $base ) {
			$base = 'dsm_masonry_gallery';
		}

		return $base . '_' . $order_index;
	}

	/**
	 * Desktop innerContent value (string).
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 * @param string               $key   Attribute key.
	 * @param string               $fb    Fallback.
	 * @return string
	 */
	private static function inner_desktop_string( array $attrs, string $key, string $fb = '' ): string {
		$v = $attrs[ $key ]['innerContent']['desktop']['value'] ?? null;
		if ( is_string( $v ) ) {
			return $v;
		}
		if ( is_numeric( $v ) ) {
			return (string) $v;
		}

		return $fb;
	}

	/**
	 * Read positive integer from range innerContent at breakpoint (fallback chain).
	 *
	 * @param array<string, mixed> $attrs      Module attrs.
	 * @param string               $key        Attribute key.
	 * @param string               $breakpoint desktop|tablet|phone.
	 * @param int                  $fb         Fallback int.
	 * @return int
	 */
	private static function read_range_int( array $attrs, string $key, string $breakpoint, int $fb ): int {
		$ic = $attrs[ $key ]['innerContent'] ?? array();
		if ( ! is_array( $ic ) ) {
			return $fb;
		}

		$order = array( $breakpoint, 'desktop', 'tablet', 'phone' );
		$order = array_values( array_unique( $order ) );

		foreach ( $order as $bp ) {
			if ( ! isset( $ic[ $bp ] ) || ! is_array( $ic[ $bp ] ) ) {
				continue;
			}
			$raw = $ic[ $bp ]['value'] ?? null;
			if ( is_string( $raw ) || is_numeric( $raw ) ) {
				$n = (int) preg_replace( '/\D/', '', (string) $raw );
				if ( $n > 0 ) {
					return $n;
				}
			}
		}

		return $fb;
	}

	/**
	 * Responsive range ms with fallback chain; allows 0 (read_range_int skips 0 and breaks stagger/transition "off").
	 *
	 * @param array<string, mixed> $attrs      Module attrs.
	 * @param string               $key        Attribute key.
	 * @param string               $breakpoint desktop|tablet|phone.
	 * @param int                  $fb         Fallback when all missing.
	 * @return int>=0
	 */
	private static function read_range_ms_allow_zero( array $attrs, string $key, string $breakpoint, int $fb ): int {
		$ic = $attrs[ $key ]['innerContent'] ?? array();
		if ( ! is_array( $ic ) ) {
			return $fb;
		}

		$order = array( $breakpoint, 'desktop', 'tablet', 'phone' );
		$order = array_values( array_unique( $order ) );

		foreach ( $order as $bp ) {
			if ( ! isset( $ic[ $bp ] ) || ! is_array( $ic[ $bp ] ) ) {
				continue;
			}
			$raw = $ic[ $bp ]['value'] ?? null;
			if ( null === $raw || '' === $raw ) {
				continue;
			}
			$n = (int) preg_replace( '/\D/', '', (string) $raw );

			return max( 0, $n );
		}

		return $fb;
	}

	/**
	 * Sanitized bottom rootMargin percent for deferred Masonry init (IntersectionObserver).
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 * @return string e.g. "15%"
	 */
	private static function viewport_margin_percent_string( array $attrs ): string {
		$raw = self::inner_desktop_string( $attrs, 'dsm_masonry_viewport_margin', '15%' );
		$raw = trim( $raw );
		if ( ! preg_match( '/^(\d+(?:\.\d+)?)\s*%?$/u', $raw, $m ) ) {
			return '15%';
		}

		$n       = max( 0.0, min( 100.0, (float) $m[1] ) );
		$rounded = round( $n, 2 );
		$as_int  = (int) round( $rounded );
		if ( abs( $rounded - $as_int ) < 0.00001 ) {
			return (string) $as_int . '%';
		}

		return (string) $rounded . '%';
	}

	/**
	 * Opening tag for image wrap; reserves aspect ratio when dimensions are known.
	 *
	 * @param string $width  Attachment width (px).
	 * @param string $height Attachment height (px).
	 * @return string Unescaped HTML opening tag (safe: integers only in style).
	 */
	private static function masonry_image_wrap_open( string $width, string $height ): string {
		$w = absint( $width );
		$h = absint( $height );
		if ( $w > 0 && $h > 0 ) {
			return sprintf(
				'<div class="et_pb_image_wrap dsm-mg-aspect-reserve" style="--dsm-mg-aspect-ratio:%1$d / %2$d;">',
				$w,
				$h
			);
		}

		return '<div class="et_pb_image_wrap">';
	}

	/**
	 * Image alt: attachment alt, else caption, else title (WCAG 1.1.1).
	 *
	 * @param string $attachment_alt `_wp_attachment_image_alt`.
	 * @param string $caption        Attachment caption.
	 * @param string $title          Attachment title.
	 * @return string
	 */
	private static function masonry_resolved_image_alt( string $attachment_alt, string $caption, string $title ): string {
		$alt = trim( $attachment_alt );
		if ( '' !== $alt ) {
			return $alt;
		}
		$cap = trim( wp_strip_all_tags( $caption ) );
		if ( '' !== $cap ) {
			return $cap;
		}

		return trim( $title );
	}

	/**
	 * Accessible name for the lightbox trigger.
	 *
	 * The image keeps its own alt and title. This label names the action.
	 *
	 * @param string $title         Attachment title.
	 * @param string $caption       Caption HTML/text.
	 * @param string $resolved_alt  Alt after fallback chain.
	 * @return string               Already escaped for `aria-label`.
	 */
	private static function masonry_lightbox_aria_label_value( string $title, string $caption, string $resolved_alt ): string {
		$primary = trim( $resolved_alt );
		if ( '' === $primary ) {
			$primary = trim( wp_strip_all_tags( $caption ) );
		}
		if ( '' === $primary ) {
			$primary = trim( $title );
		}
		if ( '' === $primary ) {
			return esc_attr__( 'Open image in lightbox', 'dsm-supreme-modules-pro-for-divi' );
		}

		return esc_attr(
			sprintf(
				/* translators: %s: image description (alt, caption, or title). */
				__( 'Open image in lightbox: %s', 'dsm-supreme-modules-pro-for-divi' ),
				$primary
			)
		);
	}

	/**
	 * Accessible name for custom URL on a gallery item.
	 *
	 * @param string $title  Attachment title.
	 * @param string $url    Link URL.
	 * @param string $target Link target (`_self`, `_blank`, etc.).
	 * @return string        Escaped for `aria-label`.
	 */
	private static function masonry_external_link_aria_label_value( string $title, string $url, string $target ): string {
		$t       = trim( wp_strip_all_tags( $title ) );
		$new_tab = ( '_blank' === strtolower( $target ) );
		if ( '' !== $t ) {
			$label = sprintf(
				/* translators: %s: image or attachment title. */
				__( 'Link: %s', 'dsm-supreme-modules-pro-for-divi' ),
				$t
			);
		} else {
			$label = sprintf(
				/* translators: %s: destination URL. */
				__( 'Open link: %s', 'dsm-supreme-modules-pro-for-divi' ),
				$url
			);
		}
		if ( $new_tab ) {
			$label .= ' ' . __( '(opens in a new tab)', 'dsm-supreme-modules-pro-for-divi' );
		}

		return esc_attr( $label );
	}

	/**
	 * JSON for `data-dsm-mg-motion`: transition/stagger ms per breakpoint (matches responsive Range).
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 * @return string JSON object.
	 */
	private static function masonry_motion_data_json( array $attrs ): string {
		$data = array(
			'transition' => array(
				'd' => self::read_range_ms_allow_zero( $attrs, 'dsm_masonry_transition_ms', 'desktop', 400 ),
				't' => self::read_range_ms_allow_zero( $attrs, 'dsm_masonry_transition_ms', 'tablet', 400 ),
				'p' => self::read_range_ms_allow_zero( $attrs, 'dsm_masonry_transition_ms', 'phone', 400 ),
			),
			'stagger'    => array(
				'd' => self::read_range_ms_allow_zero( $attrs, 'dsm_masonry_stagger_ms', 'desktop', 0 ),
				't' => self::read_range_ms_allow_zero( $attrs, 'dsm_masonry_stagger_ms', 'tablet', 0 ),
				'p' => self::read_range_ms_allow_zero( $attrs, 'dsm_masonry_stagger_ms', 'phone', 0 ),
			),
		);

		return (string) wp_json_encode( $data );
	}

	/**
	 * Heading tag for overlay title from `image_title_font` decoration.
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 * @return string h1–h6, p, div, or span.
	 */
	private static function heading_level_from_attrs( array $attrs ): string {
		return HeadingLevel::sanitize(
			$attrs['image_title_font']['decoration']['font']['font']['desktop']['value']['headingLevel'] ?? 'h4',
			'h4'
		);
	}

	/**
	 * Parse gallery attachment IDs from `gallery_ids` innerContent.
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 * @return list<int>
	 */
	private static function parse_gallery_ids( array $attrs ): array {
		$raw = $attrs['gallery_ids']['innerContent']['desktop']['value'] ?? '';
		if ( is_array( $raw ) ) {
			$raw = isset( $raw['ids'] ) && is_string( $raw['ids'] ) ? $raw['ids'] : '';
		}
		if ( ! is_string( $raw ) || '' === $raw ) {
			return array();
		}

		$parts = array_map( 'intval', array_filter( array_map( 'trim', explode( ',', $raw ) ) ) );

		return array_values( array_filter( $parts, static fn ( int $id ): bool => $id > 0 ) );
	}

	/**
	 * Overlay background color (accent fallback when empty).
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 * @return string
	 */
	private static function overlay_color_resolved( array $attrs ): string {
		$c = self::inner_desktop_string( $attrs, 'overlay_color', '' );
		if ( '' !== $c ) {
			return $c;
		}
		if ( function_exists( 'et_builder_accent_color' ) ) {
			return (string) et_builder_accent_color();
		}

		return '#2ea3f2';
	}

	/**
	 * Gallery HTML (D4 `get_galleries` parity).
	 *
	 * @param array<string, mixed> $args Props keyed like D4 shortcode props.
	 * @return string
	 */
	public static function get_galleries( array $args = array() ): string {
		$defaults = array(
			'gallery_ids'           => array(),
			'use_overlay'           => 'off',
			'use_zoom_on_hover'     => 'off',
			'overlay_title'         => 'on',
			'overlay_caption'       => 'on',
			'overlay_description'   => 'on',
			'lightbox_title'        => 'on',
			'lightbox_caption'      => 'on',
			'image_title_level'     => 'h4',
			'lightbox_img_sizes'    => 'full',
			'dsm_sort_images'       => 'off',
			'dsm_sort_images_order' => 'title',
			'dsm_order_sort'        => 'asc',
			'lazyload'              => 'off',
		);

		$args = wp_parse_args( $args, $defaults );

		$gallery_ids = $args['gallery_ids'];
		if ( ! is_array( $gallery_ids ) || array() === $gallery_ids ) {
			return '';
		}

		$is_sort_image = 'on' === $args['dsm_sort_images'] ? $args['dsm_sort_images_order'] : 'post__in';

		$attachments_args = array(
			'include'        => $gallery_ids,
			'post_status'    => 'inherit',
			'post_type'      => 'attachment',
			'post_mime_type' => 'image',
			'order'          => strtoupper( (string) $args['dsm_order_sort'] ),
			'orderby'        => $is_sort_image,
		);

		$_attachments = get_posts( $attachments_args );
		$attachments  = array();

		foreach ( $_attachments as $key => $val ) {
			$attachments[ $key ]                          = $_attachments[ $key ];
			$attachments[ $key ]->lightbox_image_src_full = wp_get_attachment_image_src( $val->ID, (string) $args['lightbox_img_sizes'] );
		}

		$output = array(
			'<div class="grid-sizer"></div>',
			'<div class="gutter-sizer"></div>',
		);

		foreach ( $attachments as $attachment ) {
			$dsm_upload_gallery_custom_link_url       = get_post_meta( $attachment->ID, 'dsm_upload_gallery_custom_link_url', true );
			$dsm_upload_gallery_link_url_target       = get_post_meta( $attachment->ID, 'dsm_upload_gallery_link_url_target', true );
			$dsm_upload_gallery_link_as_download_file = get_post_meta( $attachment->ID, 'dsm_upload_gallery_link_as_download_file', true );

			$image             = wp_get_attachment_image_src( $attachment->ID, 'full' );
			$image_title       = get_the_title( $attachment->ID );
			$image_alt         = get_post_meta( $attachment->ID, '_wp_attachment_image_alt', true );
			$image_caption     = wp_get_attachment_caption( $attachment->ID );
			$image_description = isset( $attachment->post_content ) ? $attachment->post_content : '';
			$width             = isset( $image[1] ) ? esc_attr( (string) $image[1] ) : '';
			$height            = isset( $image[2] ) ? esc_attr( (string) $image[2] ) : '';
			$img_srcset_sizes  = isset( $image ) ? wp_get_attachment_image_sizes( $attachment->ID, 'full', null ) : '';
			$img_srcset        = isset( $image ) ? wp_get_attachment_image_srcset( $attachment->ID, 'full' ) : '';
			$lazyload          = isset( $args['lazyload'] ) && 'off' !== $args['lazyload'] ? '' : 'dsm-skip-lazyload';

			$image_src = isset( $image[0] ) ? $image[0] : '';

			$caption_str  = is_string( $image_caption ) ? $image_caption : '';
			$alt_raw      = is_string( $image_alt ) ? $image_alt : '';
			$resolved_alt = self::masonry_resolved_image_alt( $alt_raw, $caption_str, $image_title );

			$use_lightbox = 'on' === $args['use_lightbox'] && isset( $image[0] );
			$use_custom   = ! $use_lightbox && '' !== $dsm_upload_gallery_custom_link_url && is_string( $dsm_upload_gallery_custom_link_url );

			$img_alt_attr   = $use_custom ? '' : esc_attr( $resolved_alt );
			$img_title_attr = '';
			if ( $use_lightbox && '' !== trim( $image_title ) ) {
				$img_title_attr = ' title="' . esc_attr( $image_title ) . '"';
			}

			$lazy_native = isset( $args['lazyload'] ) && 'off' !== $args['lazyload'];
			$load_attrs  = $lazy_native ? ' loading="lazy" decoding="async"' : ' decoding="async"';
			$wrap_open   = self::masonry_image_wrap_open( $width, $height );

			$image_html = sprintf(
				'<img src="%1$s"%9$s alt="%2$s" class="%7$s" srcset="%3$s" sizes="%4$s" width="%5$s" height="%6$s"%8$s />',
				esc_url( $image_src ),
				$img_alt_attr,
				esc_attr( $img_srcset ),
				esc_attr( $img_srcset_sizes ),
				esc_attr( $width ),
				esc_attr( $height ),
				esc_attr( $lazyload ),
				$load_attrs,
				$img_title_attr
			);

			$title_tag = HeadingLevel::sanitize( $args['image_title_level'] ?? 'h4', 'h4' );

			$image_title_render = sprintf(
				'<%2$s class="dsm-overlay-title">%1$s</%2$s>',
				esc_html( $image_title ),
				esc_attr( $title_tag )
			);

			$image_caption_render = sprintf(
				'<p class="dsm-overlay-caption">%1$s</p>',
				esc_html( $caption_str )
			);

			$image_description_render = sprintf(
				'<p class="dsm-overlay-desc">%1$s</p>',
				wp_kses_post( $image_description )
			);

			$overlay = '';
			if ( 'on' === $args['use_overlay'] ) {
				$overlay = sprintf(
					'<span class="et_overlay dsm-overlay" aria-hidden="true"><div class="dsm-overlay-inner">%1$s%2$s%3$s</div></span>',
					'on' === $args['overlay_title'] ? $image_title_render : '',
					'on' === $args['overlay_caption'] ? $image_caption_render : '',
					'on' === $args['overlay_description'] ? $image_description_render : ''
				);
			}

			$lightbox = '';
			if ( $use_lightbox ) {
				$lb_full         = isset( $attachment->lightbox_image_src_full[0] ) ? $attachment->lightbox_image_src_full[0] : $image[0];
				$a_label         = self::masonry_lightbox_aria_label_value( $image_title, $caption_str, $resolved_alt );
				$lb_title_attr   = 'on' === $args['lightbox_title'] ? " data-title='" . esc_attr( $image_title ) . "'" : '';
				$lb_caption_attr = 'on' === $args['lightbox_caption'] && '' !== $caption_str ? " data-caption='" . esc_attr( $caption_str ) . "'" : '';
				$lightbox        = sprintf(
					'<a href="%3$s" aria-label="%1$s" %4$s %5$s data-mfp-src="%6$s">%7$s%2$s</div></a>',
					$a_label,
					$image_html . $overlay,
					esc_url( $image[0] ),
					$lb_title_attr,
					$lb_caption_attr,
					esc_url( $lb_full ),
					$wrap_open
				);
			} elseif ( $use_custom ) {
				$target_raw = is_string( $dsm_upload_gallery_link_url_target ) ? $dsm_upload_gallery_link_url_target : '_self';
				$rel_attr   = ( '_blank' === $target_raw ) ? ' rel="noopener noreferrer"' : '';
				$a_custom   = self::masonry_external_link_aria_label_value( $image_title, (string) $dsm_upload_gallery_custom_link_url, $target_raw );
				$download   = ( '1' === $dsm_upload_gallery_link_as_download_file ) ? ' download' : '';
				$lightbox   = sprintf(
					'<a href="%3$s" target="%4$s"%5$s%6$s aria-label="%1$s">%7$s%2$s</div></a>',
					$a_custom,
					$image_html . $overlay,
					esc_url( $dsm_upload_gallery_custom_link_url ),
					esc_attr( $target_raw ),
					$rel_attr,
					$download,
					$wrap_open
				);
			} else {
				$lightbox = sprintf(
					'%1$s%2$s%3$s</div>',
					$wrap_open,
					$image_html,
					$overlay
				);
			}

			$svg_class = '';
			if ( MasonryGallerySvgDecoration::is_svg_url( $image_src ) ) {
				$svg_class = ' dsm_masonry_gallery_svg';
			}

			$output[] = sprintf(
				'<div class="grid-item%2$s">%1$s</div>',
				$lightbox,
				esc_attr( $svg_class )
			);
		}

		return implode( '', $output );
	}

	/**
	 * Build D4-style props from D5 attrs.
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 * @return array<string, mixed>
	 */
	private static function build_gallery_props( array $attrs ): array {
		$ids = self::parse_gallery_ids( $attrs );

		return array(
			'gallery_ids'           => $ids,
			'use_overlay'           => self::inner_desktop_string( $attrs, 'use_overlay', 'off' ),
			'use_zoom_on_hover'     => self::inner_desktop_string( $attrs, 'use_zoom_on_hover', 'off' ),
			'overlay_title'         => self::inner_desktop_string( $attrs, 'overlay_title', 'on' ),
			'overlay_caption'       => self::inner_desktop_string( $attrs, 'overlay_caption', 'on' ),
			'overlay_description'   => self::inner_desktop_string( $attrs, 'overlay_description', 'on' ),
			'lightbox_title'        => self::inner_desktop_string( $attrs, 'lightbox_title', 'on' ),
			'lightbox_caption'      => self::inner_desktop_string( $attrs, 'lightbox_caption', 'on' ),
			'image_title_level'     => self::heading_level_from_attrs( $attrs ),
			'lightbox_img_sizes'    => self::inner_desktop_string( $attrs, 'lightbox_img_sizes', 'full' ),
			'dsm_sort_images'       => self::inner_desktop_string( $attrs, 'dsm_sort_images', 'on' ),
			'dsm_sort_images_order' => self::inner_desktop_string( $attrs, 'dsm_sort_images_order', 'title' ),
			'dsm_order_sort'        => self::inner_desktop_string( $attrs, 'dsm_order_sort', 'asc' ),
			'lazyload'              => self::inner_desktop_string( $attrs, 'lazyload', 'off' ),
			'use_lightbox'          => self::inner_desktop_string( $attrs, 'use_lightbox', 'off' ),
		);
	}

	/**
	 * Grid width CSS declaration string.
	 *
	 * @param int $columns Columns count.
	 * @param int $gutter  Gutter px.
	 * @return string
	 */
	private static function grid_width_declaration( int $columns, int $gutter ): string {
		$declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
			)
		);
		$declarations->add(
			'width',
			sprintf( 'calc((100%% - (%d - 1) * %dpx) / %d)', $columns, $gutter, $columns )
		);

		return $declarations->value();
	}

	/**
	 * Gutter width declaration.
	 *
	 * @param int $gutter Gutter px.
	 * @return string
	 */
	private static function gutter_width_declaration( int $gutter ): string {
		$declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
			)
		);
		$declarations->add( 'width', (string) $gutter . 'px' );

		return $declarations->value();
	}

	/**
	 * Margin-bottom on grid items.
	 *
	 * @param int $gutter Gutter px.
	 * @return string
	 */
	private static function grid_margin_bottom_declaration( int $gutter ): string {
		$declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
			)
		);
		$declarations->add( 'margin-bottom', (string) $gutter . 'px' );

		return $declarations->value();
	}

	/**
	 * Append responsive grid layout styles (D4 inline CSS parity).
	 *
	 * @param array<int, mixed>    $styles_list Styles list (reference).
	 * @param string               $order_class Order class.
	 * @param array<string, mixed> $attrs       Module attrs.
	 * @return void
	 */
	private static function add_grid_layout_styles( array &$styles_list, string $order_class, array $attrs ): void {
		$oc = $order_class;

		$breakpoints = array(
			'desktop' => '',
			'tablet'  => '@media screen and (max-width: 980px)',
			'phone'   => '@media screen and (max-width: 767px)',
		);

		foreach ( $breakpoints as $bp => $at ) {
			$cols = self::read_range_int( $attrs, 'columns', $bp, 3 );
			$gut  = self::read_range_int( $attrs, 'gutter', $bp, 12 );

			$styles_list[] = CommonStyle::style(
				array(
					'selector'            => "{$oc} .gutter-sizer",
					'attr'                => $attrs['gutter']['innerContent'] ?? array(),
					'declarationFunction' => static function () use ( $gut ): string {
						return self::gutter_width_declaration( $gut );
					},
					'atRules'             => $at,
				)
			);

			$styles_list[] = CommonStyle::style(
				array(
					'selector'            => "{$oc} .grid-item, {$oc} .grid-sizer",
					'attr'                => $attrs['columns']['innerContent'] ?? array(),
					'declarationFunction' => static function () use ( $cols, $gut ): string {
						return self::grid_width_declaration( $cols, $gut );
					},
					'atRules'             => $at,
				)
			);

			$styles_list[] = CommonStyle::style(
				array(
					'selector'            => "{$oc} .grid-item",
					'attr'                => $attrs['gutter']['innerContent'] ?? array(),
					'declarationFunction' => static function () use ( $gut ): string {
						return self::grid_margin_bottom_declaration( $gut );
					},
					'atRules'             => $at,
				)
			);
		}
	}

	/**
	 * Module script data (entrance animation, interactions, etc.).
	 *
	 * @param array<string, mixed> $args Arguments.
	 */
	public static function module_script_data( $args ): void {
		$elements = $args['elements'];

		$elements->script_data(
			array(
				'attrName' => 'module',
			)
		);
	}

	/**
	 * Module classnames.
	 *
	 * @param array<string, mixed> $args Arguments.
	 */
	public static function module_classnames( $args ): void {
		$classnames_instance = $args['classnamesInstance'];
		$attrs               = $args['attrs'];

		$classnames_instance->add( 'dsm_masonry_gallery' );

		$classnames_instance->add(
			ElementClassnames::classnames(
				array(
					'attrs' => $attrs['module']['decoration'] ?? array(),
				)
			)
		);
	}

	/**
	 * Render module styles.
	 *
	 * @param array<string, mixed> $args Arguments.
	 */
	public static function module_styles( array $args ): void {
		$args     = \DiviSupreme\Includes\DsmDiviBuilderCssScope::normalize_module_styles_args( $args );
		$attrs    = $args['attrs'] ?? array();
		$elements = $args['elements'];
		$oc       = $args['orderClass'];
		$base_oc  = isset( $args['baseOrderClass'] ) && is_string( $args['baseOrderClass'] ) ? $args['baseOrderClass'] : '';

		$styles_list = array(
			$elements->style(
				array(
					'attrName'   => 'module',
					'styleProps' => array(
						'disabledOn' => array(
							'disabledModuleVisibility' => $args['settings']['disabledModuleVisibility'] ?? null,
						),
					),
				)
			),

			TextStyle::style(
				array(
					'selector' => $oc,
					'attr'     => $attrs['module']['advanced']['text'] ?? array(),
				)
			),

			CssStyle::style(
				array(
					'selector' => $oc,
					'attr'     => $attrs['css'] ?? array(),
				)
			),

			$elements->style(
				array(
					'attrName' => 'grid_item_style',
				)
			),

			$elements->style(
				array(
					'attrName' => 'image_title_font',
				)
			),

			$elements->style(
				array(
					'attrName' => 'image_caption_font',
				)
			),

			$elements->style(
				array(
					'attrName' => 'image_desc_font',
				)
			),

			$elements->style(
				array(
					'attrName' => 'lightbox_title_font',
				)
			),

			$elements->style(
				array(
					'attrName' => 'lightbox_caption_font',
				)
			),

			$elements->style(
				array(
					'attrName' => 'overlay_inner_padding',
				)
			),

			CommonStyle::style(
				array(
					'selector'            => "{$oc} .grid-item .dsm-overlay",
					'attr'                => $attrs['overlay_color']['innerContent'] ?? array(),
					'declarationFunction' => static function () use ( $attrs ): string {
						$c = self::inner_desktop_string( $attrs, 'overlay_color', '' );
						if ( '' === $c && function_exists( 'et_builder_accent_color' ) ) {
							$c = (string) et_builder_accent_color();
						}
						if ( '' === $c ) {
							$c = '#2ea3f2';
						}
						$declarations = new StyleDeclarations(
							array(
								'returnType' => 'string',
								'important'  => array(
									'background' => true,
								),
							)
						);
						$declarations->add( 'background', $c );

						return $declarations->value();
					},
				)
			),

			CommonStyle::style(
				array(
					'selector'            => '.mfp-bg.dsm-masonry-gallery-lightbox' . $base_oc,
					'attr'                => $attrs['lightbox_overlay_color']['innerContent'] ?? array(),
					'declarationFunction' => static function () use ( $attrs ): string {
						$c = self::inner_desktop_string( $attrs, 'lightbox_overlay_color', '' );
						if ( '' === trim( $c ) ) {
							return '';
						}
						$declarations = new StyleDeclarations(
							array(
								'returnType' => 'string',
								'important'  => array(
									'background' => true,
								),
							)
						);
						$declarations->add( 'background', $c );

						return $declarations->value();
					},
				)
			),
		);

		self::add_grid_layout_styles( $styles_list, $oc, $attrs );

		Style::add(
			array(
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => $styles_list,
			)
		);
	}

	/**
	 * Render callback.
	 *
	 * @param array<string, mixed>               $attrs    Block attrs.
	 * @param string                             $content  Children (unused).
	 * @param \WP_Block                          $block    Block.
	 * @param \ET\Builder\Modules\ModuleElements $elements Module elements.
	 * @return string
	 */
	public static function render_callback( $attrs, $content, $block, $elements ) {
		$props = self::build_gallery_props( $attrs );

		if ( 'on' === $props['use_lightbox'] ) {
			dsm_enqueue_magnific_popup_assets();
		}

		wp_enqueue_script( 'dsm-masonry-gallery' );

		$galleries = self::get_galleries( $props );

		$dec = MasonryGallerySvgDecoration::root_id_class_from_decoration( $attrs );

		$zoom_class = 'on' === $props['use_zoom_on_hover'] ? ' dsm_masonry_zoom_hover' : '';
		$root_class = trim( 'dsm-gallery grid' . $zoom_class . ( '' !== $dec['class'] ? ' ' . $dec['class'] : '' ) );
		$id_attr    = '' !== $dec['id'] ? ' id="' . esc_attr( $dec['id'] ) . '"' : '';

		$lightbox_data = 'on' === $props['use_lightbox'] ? 'true' : 'false';
		$horiz_data    = 'on' === self::inner_desktop_string( $attrs, 'use_horizontal_order', 'on' ) ? 'true' : 'false';

		$transition_ms = (string) self::read_range_int( $attrs, 'dsm_masonry_transition_ms', 'desktop', 400 );
		$stagger_ms    = (string) self::read_range_int( $attrs, 'dsm_masonry_stagger_ms', 'desktop', 0 );
		$origin_left   = 'on' === self::inner_desktop_string( $attrs, 'dsm_masonry_origin_left', 'on' ) ? 'true' : 'false';

		$parsed_block = $block->parsed_block;
		$scope_lb     = self::masonry_lightbox_scope_class_token(
			(string) ( $parsed_block['id'] ?? '' ),
			$parsed_block['storeInstance'] ?? null,
			(int) ( $parsed_block['orderIndex'] ?? 0 ),
			(string) ( $block->block_type->name ?? 'dsm/masonry-gallery' )
		);

		$motion_json     = self::masonry_motion_data_json( $attrs );
		$viewport_margin = self::viewport_margin_percent_string( $attrs );

		$gallery_region_label = esc_attr__(
			'Image gallery',
			'dsm-supreme-modules-pro-for-divi'
		);

		$inner = sprintf(
			'<div class="et_pb_module_inner"><div class="%1$s"%2$s role="region" aria-label="%12$s" data-lightbox="%3$s" data-horizontalorder="%4$s" data-transition-ms="%5$s" data-stagger-ms="%6$s" data-origin-left="%7$s" data-dsm-mg-lb-scope="%8$s" data-dsm-mg-motion="%9$s" data-dsm-mg-viewport-margin="%10$s">%11$s</div></div>',
			esc_attr( $root_class ),
			$id_attr,
			esc_attr( $lightbox_data ),
			esc_attr( $horiz_data ),
			esc_attr( $transition_ms ),
			esc_attr( $stagger_ms ),
			esc_attr( $origin_left ),
			esc_attr( $scope_lb ),
			esc_attr( $motion_json ),
			esc_attr( $viewport_margin ),
			$galleries,
			$gallery_region_label
		);

		$module_elements = $elements->style_components(
			array(
				'attrName' => 'module',
			)
		);

		return Module::render(
			array(
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],
				'attrs'               => $attrs,
				'elements'            => $elements,
				'id'                  => $block->parsed_block['id'],
				'name'                => $block->block_type->name,
				'classnamesFunction'  => array( self::class, 'module_classnames' ),
				'moduleCategory'      => $block->block_type->category,
				'stylesComponent'     => array( self::class, 'module_styles' ),
				'scriptDataComponent' => array( self::class, 'module_script_data' ),
				'children'            => $module_elements . $inner,
			)
		);
	}
}
