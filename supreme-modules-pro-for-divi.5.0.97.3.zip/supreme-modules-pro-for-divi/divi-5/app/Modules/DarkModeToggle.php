<?php
/**
 * Dark Mode Toggle Module — placeable control for Theme Builder headers.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Modules;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use DiviSupreme\Extensions\IconLibraries\IconGlyphRenderer;
use DiviSupreme\Extensions\IconLibraries\IconLibraryRegistry;
use DiviSupreme\Extensions\IconLibraries\IconProcessFontIconBridge;
use DiviSupreme\Extensions\IconLibraries\WebfontAssetLoader;
use DiviSupreme\Includes\DsmFrontendModuleAssetRegistry;
use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\GlobalData\GlobalData;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\Module\Options\Element\ElementClassnames;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;

/**
 * Placeable dark mode toggle sharing storage with the floating switch.
 */
class DarkModeToggle implements DependencyInterface {

	/**
	 * Register module.
	 */
	public function load(): void {
		add_action( 'init', array( self::class, 'register_module' ) );
	}

	/**
	 * Register module with Divi.
	 *
	 * @return void
	 */
	public static function register_module(): void {
		$module_json_path = DSM_DIR_PATH . 'divi-5/public/packages/module-library/dark-mode-toggle';

		ModuleRegistration::register_module(
			$module_json_path,
			array(
				'render_callback' => array( self::class, 'render_callback' ),
			)
		);
	}

	/**
	 * Read a desktop innerContent scalar.
	 *
	 * @param array<string, mixed> $attrs   Attributes.
	 * @param string               $key     Attribute key.
	 * @param string               $default Default.
	 * @return string
	 */
	private static function inner_desktop_string( array $attrs, string $key, string $default = '' ): string {
		$value = $attrs[ $key ]['innerContent']['desktop']['value'] ?? $default;
		if ( is_array( $value ) ) {
			if ( isset( $value['text'] ) ) {
				return (string) $value['text'];
			}
			if ( isset( $value['src'] ) ) {
				return (string) $value['src'];
			}
			return $default;
		}

		return is_scalar( $value ) ? (string) $value : $default;
	}

	/**
	 * Read desktop icon picker leaf.
	 *
	 * @param array<string, mixed> $attrs Attributes.
	 * @param string               $key   Attribute key.
	 * @return array<string, mixed>
	 */
	private static function inner_desktop_icon( array $attrs, string $key ): array {
		$value = $attrs[ $key ]['innerContent']['desktop']['value'] ?? null;
		return is_array( $value ) ? $value : array();
	}

	/**
	 * Whether an icon picker leaf can render a glyph or webfont host.
	 *
	 * @param array<string, mixed> $icon_settings Icon picker leaf.
	 * @return bool
	 */
	private static function icon_is_renderable( array $icon_settings ): bool {
		if ( array() === $icon_settings ) {
			return false;
		}

		$unicode = isset( $icon_settings['unicode'] ) ? trim( (string) $icon_settings['unicode'] ) : '';
		$glyph   = isset( $icon_settings['glyph'] ) ? trim( (string) $icon_settings['glyph'] ) : '';
		$font    = isset( $icon_settings['fontClass'] ) ? trim( (string) $icon_settings['fontClass'] ) : '';

		return '' !== $unicode || '' !== $glyph || '' !== $font;
	}

	/**
	 * Default CSS sun/moon orb when a custom scheme icon is empty.
	 *
	 * @param string $scheme_class for-light|for-dark.
	 * @return string
	 */
	private static function render_default_orb_span( string $scheme_class ): string {
		$kind = 'for-dark' === $scheme_class ? 'moon' : 'sun';

		return sprintf(
			'<span class="dsm-dark-mode-toggle__icon dsm-dark-mode-toggle__icon--%1$s dsm-dark-mode-toggle__icon--%2$s" aria-hidden="true"></span>',
			esc_attr( $kind ),
			esc_attr( $scheme_class )
		);
	}

	/**
	 * Sanitize switch style slug.
	 *
	 * @param string $style Style slug.
	 * @return string
	 */
	private static function sanitize_switch_style( string $style ): string {
		$allowed = array( 'pill', 'icon', 'switch' );
		$style   = sanitize_key( $style );

		return in_array( $style, $allowed, true ) ? $style : 'pill';
	}

	/**
	 * Sanitize content mode slug.
	 *
	 * @param string $mode Mode slug.
	 * @return string
	 */
	private static function sanitize_content_mode( string $mode ): string {
		$allowed = array( 'default', 'icon', 'text', 'icon_text', 'image' );
		$mode    = sanitize_key( $mode );

		return in_array( $mode, $allowed, true ) ? $mode : 'default';
	}

	/**
	 * Sanitize alignment slug.
	 *
	 * @param string $align Alignment.
	 * @return string
	 */
	private static function sanitize_align( string $align ): string {
		$allowed = array( 'left', 'center', 'right', 'justified' );
		$align   = sanitize_key( $align );

		return in_array( $align, $allowed, true ) ? $align : 'left';
	}

	/**
	 * Legacy preset slugs from the pre-FontGroup Select UI.
	 *
	 * @return list<string>
	 */
	private static function legacy_label_font_presets(): array {
		return array( 'inherit', 'system', 'sans-serif', 'serif', 'monospace', 'custom' );
	}

	/**
	 * Resolve label font-family → CSS value (legacy presets + Divi face names).
	 *
	 * @param string $family Family name, legacy preset, or empty.
	 * @param string $custom Legacy custom string when family is `custom`.
	 * @return string
	 */
	private static function resolve_label_font_family_css( string $family, string $custom = '' ): string {
		$family = trim( $family );
		if ( '' === $family || 'Default' === $family || 'inherit' === $family ) {
			return 'inherit';
		}

		switch ( $family ) {
			case 'system':
				return '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif';
			case 'sans-serif':
				return 'sans-serif';
			case 'serif':
				return 'Georgia, "Times New Roman", Times, serif';
			case 'monospace':
				return 'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace';
			case 'custom':
				$custom = sanitize_text_field( $custom );
				$custom = preg_replace( '/[;{}<>\\\\]/', '', $custom ) ?? '';
				return '' !== trim( $custom ) ? trim( $custom ) : 'inherit';
			default:
				// Divi SelectFont / FontGroup face name (e.g. Open Sans).
				$safe = preg_replace( '/["<>;{}\\\\]/', '', sanitize_text_field( $family ) ) ?? '';
				$safe = trim( $safe );
				return '' !== $safe
					? sprintf( '"%1$s", Helvetica, Arial, Lucida, sans-serif', $safe )
					: 'inherit';
		}
	}

	/**
	 * Map Divi font style flags → CSS text-transform.
	 *
	 * @param mixed  $style            Style array from decoration.font.
	 * @param string $legacy_transform Flat-key fallback.
	 * @return string
	 */
	private static function font_style_to_text_transform( $style, string $legacy_transform = 'none' ): string {
		$allowed_tf = array( 'none', 'uppercase', 'lowercase', 'capitalize' );
		if ( is_array( $style ) ) {
			if ( in_array( 'uppercase', $style, true ) ) {
				return 'uppercase';
			}
			if ( in_array( 'capitalize', $style, true ) ) {
				return 'capitalize';
			}
		}
		$legacy = sanitize_key( $legacy_transform );

		return in_array( $legacy, $allowed_tf, true ) ? $legacy : 'none';
	}

	/**
	 * Derive font-style / text-decoration from Divi style flags.
	 *
	 * @param mixed $style Raw style list.
	 * @return array{fontStyle:string,textDecoration:string}
	 */
	private static function font_style_to_css( $style ): array {
		$list = array();
		if ( is_array( $style ) ) {
			$allowed = array( 'italic', 'underline', 'overline', 'strikethrough', 'uppercase', 'capitalize' );
			foreach ( $style as $flag ) {
				if ( is_string( $flag ) && in_array( $flag, $allowed, true ) ) {
					$list[] = $flag;
				}
			}
		}
		$decorations = array();
		if ( in_array( 'underline', $list, true ) ) {
			$decorations[] = 'underline';
		}
		if ( in_array( 'overline', $list, true ) ) {
			$decorations[] = 'overline';
		}
		if ( in_array( 'strikethrough', $list, true ) ) {
			$decorations[] = 'line-through';
		}

		return array(
			'fontStyle'      => in_array( 'italic', $list, true ) ? 'italic' : 'normal',
			'textDecoration' => array() !== $decorations ? implode( ' ', $decorations ) : 'none',
		);
	}

	/**
	 * Sanitize Divi FontGroup capitalization leaf.
	 *
	 * @param string $capitalization Raw.
	 * @return string
	 */
	private static function sanitize_label_capitalization( string $capitalization ): string {
		$allowed = array( 'uppercase', 'lowercase', 'capitalize', 'smallCaps', 'allSmallCaps' );

		return in_array( $capitalization, $allowed, true ) ? $capitalization : '';
	}

	/**
	 * Map capitalization → CSS text-transform.
	 *
	 * @param string $capitalization Capitalization slug.
	 * @return string
	 */
	private static function capitalization_to_text_transform( string $capitalization ): string {
		$cap = self::sanitize_label_capitalization( $capitalization );
		if ( in_array( $cap, array( 'uppercase', 'lowercase', 'capitalize' ), true ) ) {
			return $cap;
		}

		return 'none';
	}

	/**
	 * Map capitalization → CSS font-variant-caps.
	 *
	 * @param string $capitalization Capitalization slug.
	 * @return string
	 */
	private static function capitalization_to_font_variant_caps( string $capitalization ): string {
		$cap = self::sanitize_label_capitalization( $capitalization );
		if ( 'smallCaps' === $cap ) {
			return 'small-caps';
		}
		if ( 'allSmallCaps' === $cap ) {
			return 'all-small-caps';
		}

		return 'normal';
	}

	/**
	 * Sanitize text-align for label typography.
	 *
	 * @param string $align Raw.
	 * @return string
	 */
	private static function sanitize_label_text_align( string $align ): string {
		$align   = sanitize_key( $align );
		$allowed = array( 'left', 'center', 'right', 'justify' );

		return in_array( $align, $allowed, true ) ? $align : 'center';
	}

	/**
	 * Sanitize text-wrap for label typography.
	 *
	 * @param string $wrap Raw.
	 * @return string
	 */
	private static function sanitize_label_text_wrap( string $wrap ): string {
		$wrap    = sanitize_key( $wrap );
		$allowed = array( 'nowrap', 'wrap', 'balance', 'pretty' );

		return in_array( $wrap, $allowed, true ) ? $wrap : 'nowrap';
	}

	/**
	 * Sanitize line-height (unitless or with unit).
	 *
	 * @param string $value    Raw.
	 * @param string $fallback Fallback.
	 * @return string
	 */
	private static function sanitize_line_height( string $value, string $fallback ): string {
		$value = trim( sanitize_text_field( $value ) );
		if ( '' === $value ) {
			return $fallback;
		}
		if ( preg_match( '/^-?\d+(\.\d+)?(px|em|rem|%)?$/i', $value ) ) {
			return $value;
		}

		return $fallback;
	}

	/**
	 * Read desktop label font decoration (FontGroup), soft-migrating flat attrs.
	 *
	 * Family: string,
	 * size:string,
	 * weight:string,
	 * letterSpacing:string,
	 * lineHeight:string,
	 * textTransform:string,
	 * textAlign:string,
	 * fontStyle:string,
	 * textDecoration:string,
	 * textWrap:string,
	 * whiteSpace:string
	 * }
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 * @return array{
	 */
	private static function resolve_label_typography_from_attrs( array $attrs ): array {
		$desktop = $attrs['label']['decoration']['font']['font']['desktop']['value'] ?? null;
		if ( is_array( $desktop ) ) {
			$family = isset( $desktop['family'] ) && is_string( $desktop['family'] )
				? trim( $desktop['family'] )
				: '';
			if ( 'Default' === $family ) {
				$family = '';
			}
			$weight = isset( $desktop['weight'] ) && is_string( $desktop['weight'] )
				? $desktop['weight']
				: '600';
			if ( ! preg_match( '/^(?:[1-9]00|normal|bold)$/', $weight ) ) {
				$weight = '600';
			}
			$size           = self::sanitize_css_length(
				isset( $desktop['size'] ) && is_string( $desktop['size'] ) ? $desktop['size'] : '13px',
				'13px'
			);
			$letter         = self::sanitize_css_length(
				isset( $desktop['letterSpacing'] ) && is_string( $desktop['letterSpacing'] )
					? $desktop['letterSpacing']
					: '0px',
				'0px'
			);
			$line_height    = self::sanitize_line_height(
				isset( $desktop['lineHeight'] ) && is_string( $desktop['lineHeight'] )
					? $desktop['lineHeight']
					: '1.2em',
				'1.2em'
			);
			$text_align     = self::sanitize_label_text_align(
				isset( $desktop['textAlign'] ) && is_string( $desktop['textAlign'] )
					? $desktop['textAlign']
					: 'center'
			);
			$text_wrap      = self::sanitize_label_text_wrap(
				isset( $desktop['textWrap'] ) && is_string( $desktop['textWrap'] )
					? $desktop['textWrap']
					: 'nowrap'
			);
			$style_css      = self::font_style_to_css( $desktop['style'] ?? null );
			$capitalization = self::sanitize_label_capitalization(
				isset( $desktop['capitalization'] ) && is_string( $desktop['capitalization'] )
					? $desktop['capitalization']
					: ''
			);
			if ( '' === $capitalization ) {
				// Soft-migrate legacy case flags still stored on style.
				$text_transform_from_style = self::font_style_to_text_transform( $desktop['style'] ?? null, 'none' );
				$capitalization            = self::sanitize_label_capitalization( $text_transform_from_style );
			}

			return array(
				'family'          => self::resolve_label_font_family_css( $family, '' ),
				'size'            => $size,
				'weight'          => $weight,
				'letterSpacing'   => $letter,
				'lineHeight'      => $line_height,
				'textTransform'   => self::capitalization_to_text_transform( $capitalization ),
				'fontVariantCaps' => self::capitalization_to_font_variant_caps( $capitalization ),
				'textAlign'       => $text_align,
				'fontStyle'       => $style_css['fontStyle'],
				'textDecoration'  => $style_css['textDecoration'],
				'textWrap'        => 'nowrap' === $text_wrap ? 'nowrap' : $text_wrap,
				'whiteSpace'      => 'nowrap' === $text_wrap ? 'nowrap' : 'normal',
			);
		}

		// Soft-migrate pre-FontGroup flat module attrs.
		$preset = self::inner_desktop_string( $attrs, 'label_font_family', 'inherit' );
		if ( ! in_array( $preset, self::legacy_label_font_presets(), true ) && '' !== $preset ) {
			$family_css = self::resolve_label_font_family_css( $preset, '' );
		} else {
			$family_css = self::resolve_label_font_family_css(
				$preset,
				self::inner_desktop_string( $attrs, 'label_font_family_custom', '' )
			);
		}
		$weight = self::inner_desktop_string( $attrs, 'label_font_weight', '600' );
		if ( ! preg_match( '/^(?:[1-9]00|normal|bold)$/', $weight ) ) {
			$weight = '600';
		}

		$flat_transform = self::inner_desktop_string( $attrs, 'label_text_transform', 'none' );

		return array(
			'family'          => $family_css,
			'size'            => self::sanitize_css_length(
				self::inner_desktop_string( $attrs, 'label_font_size', '13px' ),
				'13px'
			),
			'weight'          => $weight,
			'letterSpacing'   => self::sanitize_css_length(
				self::inner_desktop_string( $attrs, 'label_letter_spacing', '0px' ),
				'0px'
			),
			'lineHeight'      => '1.2em',
			'textTransform'   => self::font_style_to_text_transform( null, $flat_transform ),
			'fontVariantCaps' => 'normal',
			'textAlign'       => 'center',
			'fontStyle'       => 'normal',
			'textDecoration'  => 'none',
			'textWrap'        => 'nowrap',
			'whiteSpace'      => 'nowrap',
		);
	}

	/**
	 * Sanitize CSS length for typography.
	 *
	 * @param string $value    Raw.
	 * @param string $fallback Fallback.
	 * @return string
	 */
	private static function sanitize_css_length( string $value, string $fallback ): string {
		$value = trim( sanitize_text_field( $value ) );
		if ( '' === $value ) {
			return $fallback;
		}
		if ( preg_match( '/^-?\d+(\.\d+)?(px|em|rem|%)?$/i', $value ) ) {
			if ( ! preg_match( '/(px|em|rem|%)$/i', $value ) ) {
				$value .= 'px';
			}
			return $value;
		}
		return $fallback;
	}

	/**
	 * Soft-migrate ColorPicker globals to a CSS paint (mirrors palette-css.js).
	 *
	 * `$variable({…})$` / bare `gcid-*` → prefer GlobalData concrete paint when
	 * available, else `var(--gcid-…)` so system tokens follow Divi’s `:root` sheet.
	 *
	 * @param string $color Raw ColorPicker value.
	 * @return string CSS paint, or empty when unusable.
	 */
	private static function normalize_chrome_color_for_css( string $color ): string {
		$color = trim( $color );
		if ( '' === $color ) {
			return '';
		}

		if ( class_exists( GlobalData::class ) ) {
			$resolved = GlobalData::resolve_global_color_variable(
				$color,
				GlobalData::get_global_colors()
			);
			if ( is_string( $resolved ) && '' !== trim( $resolved ) ) {
				$color = trim( $resolved );
			}
		}

		if ( str_starts_with( $color, '$variable(' ) && str_ends_with( $color, ')$' ) ) {
			$payload = substr( $color, strlen( '$variable(' ), -2 );
			$decoded = json_decode( $payload, true );
			if ( ! is_array( $decoded ) ) {
				$decoded = json_decode( stripslashes( $payload ), true );
			}
			if ( is_array( $decoded ) ) {
				$type = isset( $decoded['type'] ) ? strtolower( (string) $decoded['type'] ) : '';
				$name = '';
				if ( isset( $decoded['value']['name'] ) && is_string( $decoded['value']['name'] ) ) {
					$name = $decoded['value']['name'];
				} elseif ( isset( $decoded['value'] ) && is_string( $decoded['value'] ) ) {
					$name = $decoded['value'];
				}
				$name = ltrim( trim( $name ), '-' );
				if (
					'' !== $name
					&& preg_match( '/^[a-zA-Z0-9_-]+$/', $name )
					&& ( '' === $type || 'color' === $type || 'variable' === $type )
				) {
					return 'var(--' . $name . ')';
				}
			}
			return '';
		}

		if ( preg_match( '/^gcid-[a-zA-Z0-9_-]+$/', $color ) ) {
			return 'var(--' . $color . ')';
		}

		if ( false !== strpos( $color, '$variable(' ) ) {
			return '';
		}

		return $color;
	}

	/**
	 * Soft-sanitize a CSS colour for inline custom properties.
	 *
	 * @param string $color    Raw colour.
	 * @param string $fallback Soft default.
	 * @return string
	 */
	private static function sanitize_chrome_color( string $color, string $fallback ): string {
		$color = self::normalize_chrome_color_for_css( trim( $color ) );
		if ( '' === $color ) {
			return $fallback;
		}
		if ( strlen( $color ) > 200 || preg_match( '/[<>`]|(\x00)/', $color ) ) {
			return $fallback;
		}
		if ( preg_match( '/\b(?:expression|behavior|javascript|@import)\b/i', $color ) ) {
			return $fallback;
		}
		if ( function_exists( 'sanitize_hex_color' ) ) {
			$hex = sanitize_hex_color( $color );
			if ( is_string( $hex ) && '' !== $hex ) {
				return $hex;
			}
		}
		// Allow rgba()/rgb()/hsl() and named tokens already used by floating switch.
		if ( preg_match( '/^(?:rgba?|hsla?)\(\s*[\d.%\s,\/]+\)$/i', $color ) ) {
			return $color;
		}
		if ( preg_match( '/^var\(\s*--[a-zA-Z0-9_-]+\s*(?:,\s*[^)]+)?\)$/', $color ) ) {
			return $color;
		}

		return $fallback;
	}

	/**
	 * Soft chrome defaults (match floating switch essentials).
	 *
	 * @return array<string, string>
	 */
	private static function chrome_soft_defaults(): array {
		return array(
			'chrome_bg_light' => '#ffffff',
			'chrome_bg_dark'  => '#2a2a2a',
			'chrome_fg_light' => '#1a1a1a',
			'chrome_fg_dark'  => '#f5f5f5',
			'chrome_accent'   => '#7eb8ff',
			'chrome_track'    => 'rgba(127, 127, 127, 0.25)',
			'chrome_size'     => '48px',
		);
	}

	/**
	 * Build placeable switch chrome CSS custom properties.
	 *
	 * Applied when floating design sync is off; sync overwrites via JS when on.
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 * @return string Inline style fragment (may be empty).
	 */
	private static function build_chrome_style( array $attrs ): string {
		$defaults = self::chrome_soft_defaults();
		$bg_light = self::sanitize_chrome_color(
			self::inner_desktop_string( $attrs, 'chrome_bg_light', $defaults['chrome_bg_light'] ),
			$defaults['chrome_bg_light']
		);
		$bg_dark  = self::sanitize_chrome_color(
			self::inner_desktop_string( $attrs, 'chrome_bg_dark', $defaults['chrome_bg_dark'] ),
			$defaults['chrome_bg_dark']
		);
		$fg_light = self::sanitize_chrome_color(
			self::inner_desktop_string( $attrs, 'chrome_fg_light', $defaults['chrome_fg_light'] ),
			$defaults['chrome_fg_light']
		);
		$fg_dark  = self::sanitize_chrome_color(
			self::inner_desktop_string( $attrs, 'chrome_fg_dark', $defaults['chrome_fg_dark'] ),
			$defaults['chrome_fg_dark']
		);
		$accent   = self::sanitize_chrome_color(
			self::inner_desktop_string( $attrs, 'chrome_accent', $defaults['chrome_accent'] ),
			$defaults['chrome_accent']
		);
		$track    = self::sanitize_chrome_color(
			self::inner_desktop_string( $attrs, 'chrome_track', $defaults['chrome_track'] ),
			$defaults['chrome_track']
		);
		$size     = self::sanitize_css_length(
			self::inner_desktop_string( $attrs, 'chrome_size', $defaults['chrome_size'] ),
			$defaults['chrome_size']
		);

		$style = sprintf(
			'--dsm-dm-toggle-bg-light:%1$s;--dsm-dm-toggle-bg-dark:%2$s;--dsm-dm-toggle-fg-light:%3$s;--dsm-dm-toggle-fg-dark:%4$s;--dsm-dm-toggle-accent:%5$s;--dsm-dm-toggle-track:%6$s;--dsm-dm-toggle-size:%7$s;',
			$bg_light,
			$bg_dark,
			$fg_light,
			$fg_dark,
			$accent,
			$track,
			$size
		);

		$icon_color_light = self::sanitize_chrome_color(
			self::inner_desktop_string( $attrs, 'chrome_icon_color_light', '' ),
			''
		);
		if ( '' !== $icon_color_light ) {
			$style .= '--dsm-dm-toggle-icon-color-light:' . $icon_color_light . ';';
		}

		$icon_color_dark = self::sanitize_chrome_color(
			self::inner_desktop_string( $attrs, 'chrome_icon_color_dark', '' ),
			''
		);
		if ( '' !== $icon_color_dark ) {
			$style .= '--dsm-dm-toggle-icon-color-dark:' . $icon_color_dark . ';';
		}

		$icon_size_raw = trim( self::inner_desktop_string( $attrs, 'chrome_icon_size', '' ) );
		if ( '' !== $icon_size_raw ) {
			$icon_size = self::sanitize_css_length( $icon_size_raw, '' );
			if ( '' !== $icon_size ) {
				$style .= '--dsm-dm-toggle-icon-size:' . $icon_size . ';';
			}
		}

		return $style;
	}

	/**
	 * Extra classes for a light/dark custom icon host.
	 *
	 * @param string $scheme_class for-light|for-dark.
	 * @return string[]
	 */
	private static function icon_host_extra_classes( string $scheme_class ): array {
		return array(
			'dsm-dark-mode-toggle__icon',
			'dsm-dark-mode-toggle__icon--custom',
			'dsm-dark-mode-toggle__icon--' . $scheme_class,
		);
	}

	/**
	 * Render a custom icon span for light/dark content modes.
	 *
	 * DSM webfont libraries (Lucide, Tabler, Phosphor, Heroicons) use
	 * {@see IconGlyphRenderer} — their stored `unicode` is an icon id, not an
	 * ETmodules HTML entity.
	 *
	 * @param array<string, mixed> $icon_settings Icon picker leaf.
	 * @param string               $scheme_class  for-light|for-dark.
	 * @return string
	 */
	private static function render_icon_span( array $icon_settings, string $scheme_class ): string {
		$extra_classes = self::icon_host_extra_classes( $scheme_class );

		if (
			array() !== $icon_settings
			&& class_exists( IconLibraryRegistry::class )
			&& IconLibraryRegistry::is_dsm_library_icon( $icon_settings )
			&& class_exists( IconGlyphRenderer::class )
		) {
			$dsm_markup = IconGlyphRenderer::render_icon_span( $icon_settings, $extra_classes );
			if ( is_string( $dsm_markup ) && '' !== $dsm_markup ) {
				return $dsm_markup;
			}

			return sprintf(
				'<span class="%1$s et-pb-icon" aria-hidden="true"></span>',
				esc_attr( implode( ' ', $extra_classes ) )
			);
		}

		$type = isset( $icon_settings['type'] ) ? sanitize_key( (string) $icon_settings['type'] ) : 'divi';
		if ( '' === $type ) {
			$type = 'divi';
		}

		$glyph = '';
		if ( array() !== $icon_settings && class_exists( Utils::class ) ) {
			try {
				$processed = Utils::process_font_icon( $icon_settings );
				if ( is_string( $processed ) && '' !== $processed ) {
					$glyph = $processed;
				}
			} catch ( \Throwable $e ) { // phpcs:ignore Generic.CodeAnalysis.EmptyStatement.DetectedCatch -- optional Divi API.
				$glyph = '';
			}
		}
		if ( '' === $glyph && isset( $icon_settings['unicode'] ) && is_string( $icon_settings['unicode'] ) ) {
			$unicode_raw = $icon_settings['unicode'];
			if ( in_array( $type, array( 'divi', 'fa' ), true ) || str_starts_with( $unicode_raw, '&' ) ) {
				$glyph = html_entity_decode( $unicode_raw, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
			}
		}

		$family = 'ETmodules';

		if ( IconProcessFontIconBridge::uses_icon_manager_font_family() ) {
			$resolved_family = IconGlyphRenderer::icon_manager_font_family( $icon_settings );

			if ( '' !== $resolved_family ) {
				$family = $resolved_family;
			}
		} elseif ( 'fa' === $type ) {
			$family = 'FontAwesome';
		}
		$weight = isset( $icon_settings['weight'] ) ? sanitize_text_field( (string) $icon_settings['weight'] ) : '400';
		if ( ! preg_match( '/^(?:[1-9]00|normal|bold)$/', $weight ) ) {
			$weight = '400';
		}

		$style = sprintf(
			"font-family:'%1\$s';font-style:normal;font-weight:%2\$s;",
			$family,
			$weight
		);

		return sprintf(
			'<span class="dsm-dark-mode-toggle__icon dsm-dark-mode-toggle__icon--custom dsm-dark-mode-toggle__icon--%1$s et-pb-icon" aria-hidden="true" style="%2$s">%3$s</span>',
			esc_attr( $scheme_class ),
			esc_attr( $style ),
			esc_html( $glyph )
		);
	}

	/**
	 * Enqueue DSM webfont CSS for custom icons used by this module instance.
	 *
	 * Theme Builder headers are not always in the queried post, so the Icon
	 * Libraries post-content scanner can miss these icons.
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 * @param string               $mode  Content mode.
	 * @return void
	 */
	private static function enqueue_toggle_webfonts( array $attrs, string $mode ): void {
		if ( 'icon' !== $mode && 'icon_text' !== $mode ) {
			return;
		}

		if ( ! class_exists( WebfontAssetLoader::class ) ) {
			return;
		}

		$icons = array();
		foreach ( array( 'icon_light', 'icon_dark' ) as $key ) {
			$icon = self::inner_desktop_icon( $attrs, $key );
			if (
				class_exists( IconLibraryRegistry::class )
				&& IconLibraryRegistry::is_dsm_library_icon( $icon )
			) {
				$cache_key           = sanitize_key( (string) ( $icon['type'] ?? '' ) ) . ':' . sanitize_key( (string) ( $icon['unicode'] ?? '' ) );
				$icons[ $cache_key ] = $icon;
			}
		}

		if ( array() === $icons ) {
			return;
		}

		WebfontAssetLoader::enqueue_for_icons( $icons );

		if ( wp_style_is( 'dsm-icon-libraries-frontend', 'registered' ) ) {
			wp_enqueue_style( 'dsm-icon-libraries-frontend' );
		}
	}

	/**
	 * Build toggle button inner HTML for the active content mode.
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 * @param string               $mode  Content mode.
	 * @return string
	 */
	private static function build_toggle_inner_html( array $attrs, string $mode ): string {
		$track = '<span class="dsm-dark-mode-toggle__track" aria-hidden="true"><span class="dsm-dark-mode-toggle__thumb"></span></span>';

		if ( 'default' === $mode ) {
			return '<span class="dsm-dark-mode-toggle__icon dsm-dark-mode-toggle__icon--sun" aria-hidden="true"></span>'
				. '<span class="dsm-dark-mode-toggle__icon dsm-dark-mode-toggle__icon--moon" aria-hidden="true"></span>'
				. $track;
		}

		$html = '';

		if ( 'icon' === $mode || 'icon_text' === $mode ) {
			$light = self::inner_desktop_icon( $attrs, 'icon_light' );
			$dark  = self::inner_desktop_icon( $attrs, 'icon_dark' );
			$html .= self::icon_is_renderable( $light )
				? self::render_icon_span( $light, 'for-light' )
				: self::render_default_orb_span( 'for-light' );
			$html .= self::icon_is_renderable( $dark )
				? self::render_icon_span( $dark, 'for-dark' )
				: self::render_default_orb_span( 'for-dark' );
		}

		if ( 'text' === $mode || 'icon_text' === $mode ) {
			$light = self::inner_desktop_string( $attrs, 'label_light', 'Light' );
			$dark  = self::inner_desktop_string( $attrs, 'label_dark', 'Dark' );
			if ( '' === trim( $light ) ) {
				$light = 'Light';
			}
			if ( '' === trim( $dark ) ) {
				$dark = 'Dark';
			}
			$html .= sprintf(
				'<span class="dsm-dark-mode-toggle__label dsm-dark-mode-toggle__label--for-light">%1$s</span>',
				esc_html( $light )
			);
			$html .= sprintf(
				'<span class="dsm-dark-mode-toggle__label dsm-dark-mode-toggle__label--for-dark">%1$s</span>',
				esc_html( $dark )
			);
		}

		if ( 'image' === $mode ) {
			$light_src = esc_url( self::inner_desktop_string( $attrs, 'image_light', '' ) );
			$dark_src  = esc_url( self::inner_desktop_string( $attrs, 'image_dark', '' ) );
			$html     .= sprintf(
				'<img class="dsm-dark-mode-toggle__image dsm-dark-mode-toggle__image--for-light" alt="" data-dsm-dm-skip-dim="1"%1$s />',
				'' !== $light_src ? ' src="' . $light_src . '"' : ''
			);
			$html     .= sprintf(
				'<img class="dsm-dark-mode-toggle__image dsm-dark-mode-toggle__image--for-dark" alt="" data-dsm-dm-skip-dim="1"%1$s />',
				'' !== $dark_src ? ' src="' . $dark_src . '"' : ''
			);
		}

		return $html . $track;
	}

	/**
	 * Inline label typography CSS vars (used when floating design sync is off).
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 * @param string               $mode  Content mode.
	 * @return string Inline style attribute value (may be empty).
	 */
	private static function build_label_typography_style( array $attrs, string $mode ): string {
		if ( 'text' !== $mode && 'icon_text' !== $mode ) {
			return '';
		}

		$typo = self::resolve_label_typography_from_attrs( $attrs );

		// Values are sanitized above; escape once when building the style attribute.
		return sprintf(
			'--dsm-dm-toggle-label-family:%1$s;--dsm-dm-toggle-label-size:%2$s;--dsm-dm-toggle-label-weight:%3$s;--dsm-dm-toggle-label-letter-spacing:%4$s;--dsm-dm-toggle-label-line-height:%5$s;--dsm-dm-toggle-label-text-transform:%6$s;--dsm-dm-toggle-label-font-variant-caps:%7$s;--dsm-dm-toggle-label-text-align:%8$s;--dsm-dm-toggle-label-font-style:%9$s;--dsm-dm-toggle-label-text-decoration:%10$s;--dsm-dm-toggle-label-text-wrap:%11$s;--dsm-dm-toggle-label-white-space:%12$s;',
			$typo['family'],
			$typo['size'],
			$typo['weight'],
			$typo['letterSpacing'],
			$typo['lineHeight'],
			$typo['textTransform'],
			$typo['fontVariantCaps'] ?? 'normal',
			$typo['textAlign'],
			$typo['fontStyle'],
			$typo['textDecoration'],
			$typo['textWrap'],
			$typo['whiteSpace']
		);
	}

	/**
	 * Combine chrome + label typography inline style fragments.
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 * @param string               $mode  Content mode.
	 * @return string
	 */
	private static function build_button_inline_style( array $attrs, string $mode ): string {
		return self::build_chrome_style( $attrs ) . self::build_label_typography_style( $attrs, $mode );
	}

	/**
	 * Module styles.
	 *
	 * @param array<string, mixed> $args Style args.
	 * @return void
	 */
	public static function module_styles( $args ): void {
		$args     = \DiviSupreme\Includes\DsmDiviBuilderCssScope::normalize_module_styles_args( $args );
		$attrs    = $args['attrs'] ?? array();
		$elements = $args['elements'];

		Style::add(
			array(
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => array(
					$elements->style(
						array(
							'attrName'   => 'module',
							'styleProps' => array(
								'disabledOn' => array(
									'disabledModuleVisibility' => $args['settings']['disabledModuleVisibility'] ?? null,
								),
							),
						)
					),
					$elements->style(
						array(
							'attrName' => 'label',
						)
					),
					CssStyle::style(
						array(
							'selector' => $args['orderClass'],
							'attr'     => $attrs['css'] ?? array(),
						)
					),
				),
			)
		);
	}

	/**
	 * Script data.
	 *
	 * @param array<string, mixed> $args Args.
	 * @return void
	 */
	public static function module_script_data( $args ): void {
		$elements = $args['elements'];
		$elements->script_data(
			array(
				'attrName' => 'module',
			)
		);
	}

	/**
	 * Classnames.
	 *
	 * @param array<string, mixed> $args Args.
	 * @return void
	 */
	public static function module_classnames( $args ): void {
		$classnames_instance = $args['classnamesInstance'];
		$attrs               = $args['attrs'];
		$align               = self::sanitize_align(
			self::inner_desktop_string( $attrs, 'align', 'left' )
		);

		$classnames_instance->add(
			ElementClassnames::classnames(
				array(
					'attrs' => $attrs['module']['decoration'] ?? array(),
				)
			)
		);

		$classnames_instance->add( 'dsm-dark-mode-toggle-align-' . $align );
	}

	/**
	 * Enqueue placeable-module chrome CSS + Dark Mode FE runtime.
	 *
	 * Theme Builder headers are easy for Divi Dynamic Assets to miss; without
	 * this render-time enqueue the button HTML prints but CSS-only sun/moon
	 * chrome stays invisible. Mirrors LoopFilter / FAQ split-CSS fallback.
	 *
	 * @return void
	 */
	private static function enqueue_frontend_assets(): void {
		$is_vb = function_exists( 'et_core_is_fb_enabled' ) && et_core_is_fb_enabled();

		if ( ! $is_vb && class_exists( DsmFrontendModuleAssetRegistry::class ) ) {
			$split_ok = false;

			if ( function_exists( 'dsm_supreme_dynamic_assets_enabled' ) && dsm_supreme_dynamic_assets_enabled() ) {
				$dark_mode_style_handle = DsmFrontendModuleAssetRegistry::frontend_style_handle_for_library_folder( 'dark-mode-toggle' );

				// Theme Builder headers can render before the central enqueue. Register once if the
				// split handle is missing; do not rescan every module stylesheet on each toggle.
				if ( ! wp_style_is( $dark_mode_style_handle, 'registered' ) ) {
					DsmFrontendModuleAssetRegistry::refresh_scoped_frontend_style_handles();
				}

				$split_ok = DsmFrontendModuleAssetRegistry::maybe_enqueue_split_frontend_stylesheet_for_block( 'dsm/dark-mode-toggle' );
			}

			if (
				! $split_ok
				&& wp_style_is( DsmFrontendModuleAssetRegistry::CORE_MODULES_STYLE_HANDLE, 'registered' )
				&& ! wp_style_is( DsmFrontendModuleAssetRegistry::CORE_MODULES_STYLE_HANDLE, 'enqueued' )
			) {
				wp_enqueue_style( DsmFrontendModuleAssetRegistry::CORE_MODULES_STYLE_HANDLE );
			}
		}

		if (
			isset( $GLOBALS['dsm_dark_mode_extension'] )
			&& is_object( $GLOBALS['dsm_dark_mode_extension'] )
			&& method_exists( $GLOBALS['dsm_dark_mode_extension'], 'ensure_frontend_assets_enqueued' )
		) {
			$GLOBALS['dsm_dark_mode_extension']->ensure_frontend_assets_enqueued();
		}
	}

	/**
	 * Frontend render.
	 *
	 * @param array<string, mixed> $attrs    Attributes.
	 * @param string               $content  Content.
	 * @param \WP_Block            $block    Block.
	 * @param mixed                $elements Elements helper.
	 * @return string
	 */
	public static function render_callback( $attrs, $content, $block, $elements ) {
		self::enqueue_frontend_assets();

		$switch_style = self::sanitize_switch_style(
			self::inner_desktop_string( $attrs, 'switch_style', 'pill' )
		);
		$content_mode = self::sanitize_content_mode(
			self::inner_desktop_string( $attrs, 'content_mode', 'default' )
		);
		self::enqueue_toggle_webfonts( $attrs, $content_mode );

		$label = esc_attr__( 'Toggle color scheme', 'dsm-supreme-modules-pro-for-divi' );

		$button_classes = array(
			'dsm-dark-mode-toggle',
			'dsm-dark-mode-toggle--module',
			'dsm-dark-mode-toggle--style-' . $switch_style,
			'dsm-dark-mode-toggle--light',
		);
		if ( 'default' === $content_mode ) {
			$button_classes[] = 'dsm-dark-mode-toggle--content-default';
		} else {
			$button_classes[] = 'dsm-dark-mode-toggle--content-custom';
		}

		$icon_color_dark = self::sanitize_chrome_color(
			self::inner_desktop_string( $attrs, 'chrome_icon_color_dark', '' ),
			''
		);
		if ( '' !== $icon_color_dark ) {
			$button_classes[] = 'dsm-dark-mode-toggle--has-icon-color-dark';
		}

		$style_attr = self::build_button_inline_style( $attrs, $content_mode );
		$inner_html = self::build_toggle_inner_html( $attrs, $content_mode );

		$button = sprintf(
			'<button type="button" class="%1$s" data-dsm-dark-mode-toggle="module" data-dsm-content-mode="%2$s" aria-label="%3$s" aria-pressed="false" data-dsm-scheme="light"%4$s>%5$s</button>',
			esc_attr( implode( ' ', $button_classes ) ),
			esc_attr( $content_mode ),
			$label,
			'' !== $style_attr ? ' style="' . esc_attr( $style_attr ) . '"' : '',
			$inner_html // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built from escaped fragments.
		);

		$module_inner = HTMLUtility::render(
			array(
				'tag'               => 'div',
				'attributes'        => array(
					'class' => 'et_pb_module_inner',
				),
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $button,
			)
		);

		$module_elements = $elements->style_components(
			array(
				'attrName' => 'module',
			)
		);

		return Module::render(
			array(
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],
				'attrs'               => $attrs,
				'elements'            => $elements,
				'id'                  => $block->parsed_block['id'],
				'moduleClassName'     => 'dsm_dark_mode_toggle',
				'name'                => $block->block_type->name,
				'classnamesFunction'  => array( self::class, 'module_classnames' ),
				'moduleCategory'      => $block->block_type->category,
				'stylesComponent'     => array( self::class, 'module_styles' ),
				'scriptDataComponent' => array( self::class, 'module_script_data' ),
				'children'            => $module_elements . $module_inner,
			)
		);
	}
}
