<?php
/**
 * Supreme Loop Filter Item child module (Divi 5).
 *
 * Frontend markup is built by the parent Loop Filter from child block attrs.
 * Visual Builder uses edit.js for previews. Per-item Design overrides are
 * emitted here when the parent wraps each leaf (cascade: child overrides
 * parent when set; unset falls back to parent Design).
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Modules;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

$dsm_loop_filter_price_styles = DSM_DIR_PATH . 'divi-5/app/Includes/dsm-loop-filter-price-styles.php';
if ( is_readable( $dsm_loop_filter_price_styles ) ) {
	require_once $dsm_loop_filter_price_styles;
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\Module\Options\Background\BackgroundStyle;
use ET\Builder\Packages\Module\Options\Border\BorderStyle;
use ET\Builder\Packages\Module\Options\BoxShadow\BoxShadowStyle;
use ET\Builder\Packages\Module\Options\Button\ButtonStyle;
use ET\Builder\Packages\Module\Options\Font\FontStyle;
use ET\Builder\Packages\Module\Options\Spacing\SpacingStyle;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;

/**
 * Handles the Supreme Loop Filter Item child module.
 */
class LoopFilterItem implements DependencyInterface {

	/**
	 * Initialize module registration.
	 *
	 * @return void
	 */
	public function load(): void {
		add_action( 'init', array( self::class, 'register_module' ) );
	}

	/**
	 * Register module with Divi module library.
	 *
	 * @return void
	 */
	public static function register_module(): void {
		$module_json_path = DSM_DIR_PATH . 'divi-5/public/packages/module-library/loop-filter-item';

		ModuleRegistration::register_module(
			$module_json_path,
			array(
				'render_callback' => array( self::class, 'render_callback' ),
			)
		);
	}

	/**
	 * Child supplies attrs only — parent renders the filter bar.
	 *
	 * @param array<string, mixed> $attrs    Block attributes.
	 * @param string               $content  Inner content.
	 * @param \WP_Block            $block    Block instance.
	 * @param mixed                $elements Module elements registry.
	 * @return string
	 */
	public static function render_callback( $attrs, $content, $block, $elements ): string {
		unset( $attrs, $content, $block, $elements );
		return '';
	}

	/**
	 * Read a desktop innerContent scalar (headingLink text or string).
	 *
	 * @param array<string, mixed> $attrs   Attributes.
	 * @param string               $key     Attribute key.
	 * @param string               $default Default.
	 * @return string
	 */
	private static function inner_desktop_string( array $attrs, string $key, string $default = '' ): string {
		$value = $attrs[ $key ]['innerContent']['desktop']['value'] ?? $default;
		if ( is_array( $value ) ) {
			if ( isset( $value['text'] ) && is_scalar( $value['text'] ) ) {
				return (string) $value['text'];
			}
			if ( isset( $value['color'] ) && is_scalar( $value['color'] ) ) {
				return (string) $value['color'];
			}
			if ( isset( $value['hex'] ) && is_scalar( $value['hex'] ) ) {
				return (string) $value['hex'];
			}
			if ( isset( $value['value'] ) && is_scalar( $value['value'] ) ) {
				return (string) $value['value'];
			}

			return $default;
		}

		return is_scalar( $value ) ? (string) $value : $default;
	}

	/**
	 * Whether a decoration leaf has a non-empty string somewhere in the tree.
	 *
	 * @param mixed $value Decoration value.
	 * @return bool
	 */
	private static function decoration_value_is_meaningful( $value ): bool {
		if ( is_string( $value ) ) {
			return '' !== trim( $value );
		}

		if ( ! is_array( $value ) || array() === $value ) {
			return false;
		}

		foreach ( $value as $part ) {
			if ( self::decoration_value_is_meaningful( $part ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Emit Font / Background / Spacing / Border / Box Shadow for a decoration object.
	 *
	 * @param string                    $selector   CSS selector.
	 * @param array<string, mixed>|null $decoration Decoration attrs.
	 * @return list<string>
	 */
	private static function emit_decoration_chrome_styles( string $selector, $decoration ): array {
		$styles = array();
		if ( ! is_array( $decoration ) ) {
			return $styles;
		}

		$font = $decoration['font'] ?? null;
		if (
			is_array( $font )
			&& self::decoration_value_is_meaningful( $font )
			&& class_exists( FontStyle::class )
		) {
			$styles[] = FontStyle::style(
				array(
					'selector'  => $selector,
					'attr'      => $font,
					'important' => true,
				)
			);
		}
		if (
			self::has_background_decoration( $decoration['background'] ?? null )
			&& class_exists( BackgroundStyle::class )
		) {
			$styles[] = BackgroundStyle::style(
				array(
					'selector'  => $selector,
					'attr'      => $decoration['background'],
					'important' => true,
				)
			);
		}
		if ( self::has_decoration_branch( $decoration, 'spacing' ) && class_exists( SpacingStyle::class ) ) {
			$styles[] = SpacingStyle::style(
				array(
					'selector'  => $selector,
					'attr'      => $decoration['spacing'],
					'important' => true,
				)
			);
		}
		if ( self::has_decoration_branch( $decoration, 'border' ) && class_exists( BorderStyle::class ) ) {
			$styles[] = BorderStyle::style(
				array(
					'selector'  => $selector,
					'attr'      => $decoration['border'],
					'important' => true,
				)
			);
		}
		if ( self::has_decoration_branch( $decoration, 'boxShadow' ) && class_exists( BoxShadowStyle::class ) ) {
			$styles[] = BoxShadowStyle::style(
				array(
					'selector'  => $selector,
					'attr'      => $decoration['boxShadow'],
					'important' => true,
				)
			);
		}

		return $styles;
	}

	/**
	 * Whether a decoration branch has a non-empty breakpoint value.
	 *
	 * @param mixed  $decoration Decoration tree.
	 * @param string $key        Branch key (border, spacing, boxShadow).
	 * @return bool
	 */
	private static function has_decoration_branch( $decoration, string $key ): bool {
		if ( ! is_array( $decoration ) ) {
			return false;
		}

		$branch = $decoration[ $key ] ?? null;
		if ( ! is_array( $branch ) || array() === $branch ) {
			return false;
		}

		foreach ( $branch as $breakpoint_value ) {
			if ( ! is_array( $breakpoint_value ) ) {
				continue;
			}
			if ( self::decoration_value_is_meaningful( $breakpoint_value['value'] ?? null ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Whether decoration.background has a usable desktop value.
	 *
	 * @param mixed $background Background attr tree.
	 * @return bool
	 */
	private static function has_background_decoration( $background ): bool {
		if ( ! is_array( $background ) || array() === $background ) {
			return false;
		}

		$value = $background['desktop']['value'] ?? null;
		if ( ! is_array( $value ) || array() === $value ) {
			return false;
		}

		foreach ( array( 'color', 'gradient', 'image', 'video', 'pattern', 'mask' ) as $key ) {
			if ( ! isset( $value[ $key ] ) ) {
				continue;
			}
			$part = $value[ $key ];
			if ( is_string( $part ) && '' !== trim( $part ) ) {
				return true;
			}
			if ( is_array( $part ) && array() !== $part ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Whether an attr value is non-empty (child override is active).
	 *
	 * @param string $value Desktop string value.
	 * @return bool
	 */
	private static function has_override( string $value ): bool {
		return '' !== trim( $value );
	}

	/**
	 * Build FE order class for a filter item instance.
	 *
	 * @param int $instance_index Parent Loop Filter occurrence index.
	 * @param int $item_index     Child item index in the filter bar.
	 * @return string Class without leading dot.
	 */
	public static function frontend_order_class( int $instance_index, int $item_index ): string {
		return 'dsm_lf_item_' . absint( $instance_index ) . '_' . absint( $item_index );
	}

	/**
	 * Wrap leaf HTML and emit per-item Design override styles.
	 *
	 * Cascade: child Design overrides parent Design for this item when set;
	 * unset child attrs emit nothing so parent globals apply.
	 *
	 * @param string               $html            Leaf control HTML.
	 * @param array<string, mixed> $attrs           Child block attrs.
	 * @param string               $item_type       Item type slug.
	 * @param int                  $instance_index  Parent instance index.
	 * @param int                  $item_index      Item index.
	 * @return string
	 */
	public static function wrap_frontend_item(
		string $html,
		array $attrs,
		string $item_type,
		int $instance_index,
		int $item_index
	): string {
		if ( '' === $html ) {
			return '';
		}

		$order_class = self::frontend_order_class( $instance_index, $item_index );
		self::emit_frontend_item_styles( $attrs, $item_type, $order_class );

		return sprintf(
			'<div class="dsm-loop-filter-item dsm_loop_filter_item dsm_loop_filter_item--%1$s %2$s">%3$s</div>',
			esc_attr( sanitize_html_class( $item_type ) ),
			esc_attr( $order_class ),
			et_core_esc_previously( $html )
		);
	}

	/**
	 * Host selector that beats parent Design (`.parent .dsm-loop-filter .leaf`).
	 *
	 * Parent field/button rules use three classes; child must nest under
	 * `.dsm-loop-filter` and the item host class or parent always wins.
	 *
	 * @param string $order_class Class without leading dot.
	 * @return string
	 */
	private static function item_host_selector( string $order_class ): string {
		$order_class = ltrim( $order_class, '.' );

		return '.dsm-loop-filter .' . $order_class . '.dsm_loop_filter_item';
	}

	/**
	 * Emit Style::add rules for child Design overrides on the FE wrap.
	 *
	 * @param array<string, mixed> $attrs       Child attrs.
	 * @param string               $item_type   Item type.
	 * @param string               $order_class Class without leading dot.
	 * @return void
	 */
	public static function emit_frontend_item_styles( array $attrs, string $item_type, string $order_class ): void {
		$host            = self::item_host_selector( $order_class );
		$taxonomy_ui     = self::inner_desktop_string( $attrs, 'taxonomy_ui', 'checkbox' );
		$rating_ui       = self::inner_desktop_string( $attrs, 'rating_ui', 'radio' );
		$custom_field_ui = self::inner_desktop_string( $attrs, 'custom_field_ui', 'text' );
		$show_button     = ( 'reset' === $item_type || 'submit' === $item_type );
		$price_ui        = function_exists( 'dsm_loop_filter_normalize_price_ui' )
			? dsm_loop_filter_normalize_price_ui( self::inner_desktop_string( $attrs, 'price_ui', 'input-fields' ) )
			: 'input-fields';
		$price_supports  = function_exists( 'dsm_loop_filter_price_style_supports' )
			? dsm_loop_filter_price_style_supports( $price_ui )
			: array( 'fields' => true );
		$bucket_layout   = function_exists( 'dsm_loop_filter_normalize_bucket_layout' )
			? dsm_loop_filter_normalize_bucket_layout( self::inner_desktop_string( $attrs, 'bucket_layout', 'checkbox' ) )
			: 'checkbox';
		$show_price_list = (
			'price' === $item_type
			&& ! empty( $price_supports['buckets'] )
			&& 'range-buckets' === $price_ui
			&& in_array( $bucket_layout, array( 'checkbox', 'radio' ), true )
		);
		// Radio reuses Checkbox Design overrides (size/colors/gap/wrap/term fonts).
		$show_checkbox    = (
			( 'taxonomy' === $item_type
				&& in_array( $taxonomy_ui, array( 'checkbox', 'radio' ), true ) )
			|| ( 'rating' === $item_type
				&& in_array( $rating_ui, array( 'checkbox', 'radio' ), true ) )
			|| ( 'custom_field' === $item_type
				&& in_array( $custom_field_ui, array( 'checkbox', 'radio' ), true ) )
			|| $show_price_list
		);
		$show_field       = (
			'search' === $item_type
			|| 'author' === $item_type
			|| 'date' === $item_type
			|| 'order_by' === $item_type
			|| ( 'custom_field' === $item_type
				&& in_array( $custom_field_ui, array( 'text', 'select' ), true ) )
			|| ( 'price' === $item_type && ! empty( $price_supports['fields'] ) )
			|| 'stock_status' === $item_type
			|| ( 'rating' === $item_type && 'dropdown' === $rating_ui )
			|| ( 'taxonomy' === $item_type && 'select' === $taxonomy_ui )
		);
		$show_field_label = (
			'search' === $item_type
			|| 'taxonomy' === $item_type
			|| 'author' === $item_type
			|| 'date' === $item_type
			|| 'order_by' === $item_type
			|| 'custom_field' === $item_type
			|| 'price' === $item_type
			|| 'rating' === $item_type
			|| 'stock_status' === $item_type
		);

		$styles = array();

		if ( $show_field_label ) {
			$label_selector   = "{$host} .dsm-loop-filter__label";
			$label_decoration = $attrs['field_label']['decoration'] ?? null;
			$label_font       = is_array( $label_decoration ) ? ( $label_decoration['font'] ?? null ) : null;
			if ( is_array( $label_font ) ) {
				$styles[] = FontStyle::style(
					array(
						'selector'  => $label_selector,
						'attr'      => $label_font,
						'important' => true,
					)
				);
			}
			if ( is_array( $label_decoration ) && self::has_decoration_branch( $label_decoration, 'spacing' ) && class_exists( SpacingStyle::class ) ) {
				$styles[] = SpacingStyle::style(
					array(
						'selector'  => $label_selector,
						'attr'      => $label_decoration['spacing'],
						'important' => true,
					)
				);
			}
		}

		if ( $show_field ) {
			$field_selector       = "{$host} .dsm-loop-filter__search-input, {$host} .dsm-loop-filter__select, {$host} .dsm-loop-filter__price-input, {$host} .dsm-loop-filter__date-input, {$host} .dsm-loop-filter__custom-field-input";
			$field_decoration     = $attrs['field']['decoration'] ?? null;
			$has_field_background = self::has_background_decoration(
				is_array( $field_decoration ) ? ( $field_decoration['background'] ?? null ) : null
			);
			$has_field_border     = is_array( $field_decoration ) && self::has_decoration_branch( $field_decoration, 'border' );
			$has_field_font       = is_array( $field_decoration ) && self::decoration_value_is_meaningful( $field_decoration['font'] ?? null );

			$host_var_map        = array(
				'field_focus_border_color' => '--dsm-lf-focus-border',
				'field_placeholder_color'  => '--dsm-lf-placeholder',
			);
			$leaf_var_map        = array(
				// Focus/placeholder on the painted input: FE host is
				// display:contents so host-only vars never reach :focus.
				'field_focus_border_color' => '--dsm-lf-focus-border',
				'field_placeholder_color'  => '--dsm-lf-placeholder',
			);
			$chrome_var_map      = array();
			$leaf_property_map   = array();
			$chrome_property_map = array();

			if ( ! $has_field_background ) {
				$host_var_map['field_bg_color']        = '--dsm-lf-field-bg';
				$chrome_var_map['field_bg_color']      = '--dsm-lf-field-bg';
				$chrome_property_map['field_bg_color'] = 'background-color';
			}

			if ( ! $has_field_font ) {
				$host_var_map['field_text_color']      = '--dsm-lf-field-color';
				$leaf_var_map['field_text_color']      = '--dsm-lf-field-color';
				$leaf_property_map['field_text_color'] = 'color';
			}

			if ( ! $has_field_border ) {
				$host_var_map['field_border_radius']        = '--dsm-lf-field-radius';
				$host_var_map['field_border_color']         = '--dsm-lf-field-border-color';
				$chrome_var_map['field_border_color']       = '--dsm-lf-field-border-color';
				$leaf_var_map['field_border_radius']        = '--dsm-lf-field-radius';
				$chrome_property_map['field_border_color']  = 'border-color';
				$chrome_property_map['field_border_radius'] = 'border-radius';
			}

			$styles = array_merge(
				$styles,
				// Host + leaves: display:contents wrap still matches descendants;
				// leaf-targeted vars keep --dsm-lf-* reliable on the painted nodes.
				self::css_var_styles( $host, $attrs, $host_var_map ),
				self::css_var_styles( $field_selector, $attrs, $leaf_var_map ),
				self::css_var_styles( $field_selector, $attrs, $chrome_var_map ),
				self::property_styles( $field_selector, $attrs, $leaf_property_map ),
				self::property_styles( $field_selector, $attrs, $chrome_property_map )
			);

			if ( $has_field_background && class_exists( BackgroundStyle::class ) ) {
				$styles[] = BackgroundStyle::style(
					array(
						'selector'  => $field_selector,
						'attr'      => $field_decoration['background'],
						'important' => true,
					)
				);
			}

			$field_font = is_array( $field_decoration ) ? ( $field_decoration['font'] ?? null ) : null;
			if ( is_array( $field_font ) ) {
				$styles[] = FontStyle::style(
					array(
						'selector'  => $field_selector,
						'attr'      => $field_font,
						'important' => true,
					)
				);
			}

			if ( $has_field_border && class_exists( BorderStyle::class ) ) {
				$styles[] = BorderStyle::style(
					array(
						'selector'  => $field_selector,
						'attr'      => $field_decoration['border'],
						'important' => true,
					)
				);
			}

			if ( is_array( $field_decoration ) && self::has_decoration_branch( $field_decoration, 'boxShadow' ) && class_exists( BoxShadowStyle::class ) ) {
				$styles[] = BoxShadowStyle::style(
					array(
						'selector'  => $field_selector,
						'attr'      => $field_decoration['boxShadow'],
						'important' => true,
					)
				);
			}

			if ( is_array( $field_decoration ) && self::has_decoration_branch( $field_decoration, 'spacing' ) && class_exists( SpacingStyle::class ) ) {
				$styles[] = SpacingStyle::style(
					array(
						'selector'  => $field_selector,
						'attr'      => $field_decoration['spacing'],
						'important' => true,
					)
				);
			}
		}

		if ( $show_checkbox ) {
			$checkbox_selector = "{$host} .dsm-loop-filter__checkbox, {$host} .dsm-loop-filter__radio";
			$styles            = array_merge(
				$styles,
				self::css_var_styles(
					$host,
					$attrs,
					array(
						'checkbox_size'            => '--dsm-lf-checkbox-size',
						'checkbox_unchecked_color' => '--dsm-lf-checkbox-unchecked',
						'checkbox_checked_color'   => '--dsm-lf-checkbox-checked',
						'terms_gap'                => '--dsm-lf-terms-gap',
						'nested_indent'            => '--dsm-lf-term-indent',
						'nested_gap'               => '--dsm-lf-term-nested-gap',
						'chevron_color'            => '--dsm-lf-term-chevron',
						'chevron_size'             => '--dsm-lf-term-chevron-size',
					)
				),
				self::css_var_styles(
					$checkbox_selector,
					$attrs,
					array(
						'checkbox_size'            => '--dsm-lf-checkbox-size',
						'checkbox_unchecked_color' => '--dsm-lf-checkbox-unchecked',
						'checkbox_checked_color'   => '--dsm-lf-checkbox-checked',
					)
				),
				self::css_var_styles(
					"{$host} .dsm-loop-filter__terms",
					$attrs,
					array(
						'terms_gap' => '--dsm-lf-terms-gap',
					)
				)
			);

			$terms_wrap = self::inner_desktop_string( $attrs, 'terms_wrap', '' );
			if ( self::has_override( $terms_wrap ) ) {
				$styles[] = CommonStyle::style(
					array(
						'selector'            => "{$host} .dsm-loop-filter__terms",
						'attr'                => $attrs['terms_wrap']['innerContent'] ?? array(),
						'declarationFunction' => static function ( array $args ): string {
							$declarations = new StyleDeclarations(
								array(
									'returnType' => 'string',
									'important'  => true,
								)
							);
							$value = $args['attrValue'] ?? '';
							if ( '' === trim( (string) $value ) ) {
								return $declarations->value();
							}
							$on = in_array( (string) $value, array( 'on', 'yes', 'true', '1' ), true );
							$declarations->add( 'flex-wrap', $on ? 'wrap' : 'nowrap' );
							return $declarations->value();
						},
					)
				);
			}

			$checkbox_font = $attrs['checkbox_label']['decoration']['font'] ?? null;
			if ( is_array( $checkbox_font ) ) {
				$styles[] = FontStyle::style(
					array(
						'selector'  => "{$host} .dsm-loop-filter__term",
						'attr'      => $checkbox_font,
						'important' => true,
					)
				);
			}

			$box_decoration = $attrs['checkbox_box']['decoration'] ?? null;
			if ( is_array( $box_decoration ) ) {
				$box_background = $box_decoration['background'] ?? null;
				if ( self::has_background_decoration( $box_background ) && class_exists( BackgroundStyle::class ) ) {
					$styles[] = BackgroundStyle::style(
						array(
							'selector'  => $checkbox_selector,
							'attr'      => $box_background,
							'important' => true,
						)
					);
				}
				if ( self::has_decoration_branch( $box_decoration, 'border' ) && class_exists( BorderStyle::class ) ) {
					$styles[] = BorderStyle::style(
						array(
							'selector'  => $checkbox_selector,
							'attr'      => $box_decoration['border'],
							'important' => true,
						)
					);
				}
				if ( self::has_decoration_branch( $box_decoration, 'boxShadow' ) && class_exists( BoxShadowStyle::class ) ) {
					$styles[] = BoxShadowStyle::style(
						array(
							'selector'  => $checkbox_selector,
							'attr'      => $box_decoration['boxShadow'],
							'important' => true,
						)
					);
				}
			}
		}

		if ( 'taxonomy' === $item_type && in_array( $taxonomy_ui, array( 'pills', 'pills_single' ), true ) ) {
			$tax_pill_selector = "{$host} .dsm-loop-filter__taxonomy--pills .dsm-loop-filter__term";
			$styles            = array_merge(
				$styles,
				self::css_var_styles(
					$host,
					$attrs,
					array(
						'tax_pill_gap' => '--dsm-lf-tax-pill-gap',
					)
				),
				// Color hover must be `.dsm-loop-filter__term:hover`. The same
				// variables on the item host become `host:hover` and restyle every pill.
				self::css_var_styles(
					$tax_pill_selector,
					$attrs,
					array(
						'tax_pill_bg_color'          => '--dsm-lf-tax-pill-bg',
						'tax_pill_text_color'        => '--dsm-lf-tax-pill-color',
						'tax_pill_active_bg_color'   => '--dsm-lf-tax-pill-active-bg',
						'tax_pill_active_text_color' => '--dsm-lf-tax-pill-active-color',
					)
				)
			);

			$tax_pill_decoration = $attrs['tax_pill']['decoration'] ?? null;
			if ( is_array( $tax_pill_decoration ) ) {
				$tax_pill_font = $tax_pill_decoration['font'] ?? null;
				if (
					is_array( $tax_pill_font )
					&& self::decoration_value_is_meaningful( $tax_pill_font )
					&& class_exists( FontStyle::class )
				) {
					$styles[] = FontStyle::style(
						array(
							'selector'  => $tax_pill_selector,
							'attr'      => $tax_pill_font,
							'important' => true,
						)
					);
				}
				if ( self::has_decoration_branch( $tax_pill_decoration, 'spacing' ) && class_exists( SpacingStyle::class ) ) {
					$styles[] = SpacingStyle::style(
						array(
							'selector'  => $tax_pill_selector,
							'attr'      => $tax_pill_decoration['spacing'],
							'important' => true,
						)
					);
				}
				if ( self::has_decoration_branch( $tax_pill_decoration, 'border' ) && class_exists( BorderStyle::class ) ) {
					$styles[] = BorderStyle::style(
						array(
							'selector'  => $tax_pill_selector,
							'attr'      => $tax_pill_decoration['border'],
							'important' => true,
						)
					);
				}
				if ( self::has_decoration_branch( $tax_pill_decoration, 'boxShadow' ) && class_exists( BoxShadowStyle::class ) ) {
					$styles[] = BoxShadowStyle::style(
						array(
							'selector'  => $tax_pill_selector,
							'attr'      => $tax_pill_decoration['boxShadow'],
							'important' => true,
						)
					);
				}
			}

			$tax_pill_active_selector = $tax_pill_selector . ':has(.dsm-loop-filter__checkbox:checked), ' . $tax_pill_selector . ':has(.dsm-loop-filter__radio:checked)';
			$styles                   = array_merge(
				$styles,
				self::property_styles(
					$tax_pill_selector,
					$attrs,
					array(
						'tax_pill_bg_color' => 'background-color',
					)
				),
				self::property_styles(
					$tax_pill_active_selector,
					$attrs,
					array(
						'tax_pill_active_bg_color' => 'background-color',
					)
				)
			);
			// Text and Active Text own pill color. Font color stays hidden.
			$styles[] = CommonStyle::style(
				array(
					'selector'            => $tax_pill_selector . ', ' . $tax_pill_selector . ':hover',
					'attr'                => array(
						'desktop' => array(
							'value' => 'on',
						),
					),
					'declarationFunction' => static function (): string {
						$declarations = new StyleDeclarations(
							array(
								'returnType' => 'string',
								'important'  => true,
							)
						);
						$declarations->add( 'color', 'var(--dsm-lf-tax-pill-color, #1c1c1c)' );
						return $declarations->value();
					},
				)
			);
			$styles[] = CommonStyle::style(
				array(
					'selector'            => $tax_pill_active_selector . ', ' . $tax_pill_selector . ':hover:has(.dsm-loop-filter__checkbox:checked), ' . $tax_pill_selector . ':hover:has(.dsm-loop-filter__radio:checked)',
					'attr'                => array(
						'desktop' => array(
							'value' => 'on',
						),
					),
					'declarationFunction' => static function (): string {
						$declarations = new StyleDeclarations(
							array(
								'returnType' => 'string',
								'important'  => true,
							)
						);
						$declarations->add( 'color', 'var(--dsm-lf-tax-pill-active-color, #fff)' );
						return $declarations->value();
					},
				)
			);
		}

		if ( $show_button ) {
			$button_selector = 'reset' === $item_type
				? "{$host} .dsm-loop-filter__reset"
				: "{$host} .dsm-loop-filter__submit";

			$button_background     = $attrs['button']['decoration']['background'] ?? null;
			$has_button_background = self::has_background_decoration( $button_background );

			// Native Content → Background (button.decoration.background) is source of truth.
			if ( $has_button_background && class_exists( BackgroundStyle::class ) ) {
				$styles[] = BackgroundStyle::style(
					array(
						'selector'  => $button_selector,
						'attr'      => $button_background,
						'important' => true,
					)
				);
			}

			$button_color_map = array(
				'button_text_color'   => 'color',
				'button_border_color' => 'border-color',
			);
			// Legacy solid fill only when Background group is unset.
			if ( ! $has_button_background ) {
				$button_color_map['button_bg_color'] = 'background-color';
			}

			$styles = array_merge(
				$styles,
				self::property_styles(
					$button_selector,
					$attrs,
					$button_color_map
				)
			);

			$button_font = $attrs['button']['decoration']['font'] ?? null;
			if ( is_array( $button_font ) ) {
				$styles[] = FontStyle::style(
					array(
						'selector'  => $button_selector,
						'attr'      => $button_font,
						'important' => true,
					)
				);
			}

			$button_decoration = $attrs['button']['decoration'] ?? null;
			$button_border     = is_array( $button_decoration ) && self::has_decoration_branch( $button_decoration, 'border' )
				? ( $button_decoration['border'] ?? null )
				: ( $attrs['button_style']['decoration']['border'] ?? null );
			if ( is_array( $button_border ) ) {
				$styles[] = BorderStyle::style(
					array(
						'selector'  => $button_selector,
						'attr'      => $button_border,
						'important' => true,
					)
				);
			}

			$button_box_shadow = is_array( $button_decoration ) && self::has_decoration_branch( $button_decoration, 'boxShadow' )
				? ( $button_decoration['boxShadow'] ?? null )
				: ( $attrs['button_style']['decoration']['boxShadow'] ?? null );
			if ( is_array( $button_box_shadow ) && class_exists( BoxShadowStyle::class ) ) {
				$styles[] = BoxShadowStyle::style(
					array(
						'selector'  => $button_selector,
						'attr'      => $button_box_shadow,
						'important' => true,
					)
				);
			}

			$button_spacing = is_array( $button_decoration ) && self::has_decoration_branch( $button_decoration, 'spacing' )
				? ( $button_decoration['spacing'] ?? null )
				: ( $attrs['button_style']['decoration']['spacing'] ?? null );
			if ( is_array( $button_spacing ) ) {
				$styles[] = SpacingStyle::style(
					array(
						'selector'  => $button_selector,
						'attr'      => $button_spacing,
						'important' => true,
					)
				);
			}

			$button_icon = is_array( $button_decoration ) ? ( $button_decoration['button'] ?? null ) : null;
			if ( is_array( $button_icon ) && class_exists( ButtonStyle::class ) ) {
				$styles[] = ButtonStyle::style(
					array(
						'selector' => $button_selector,
						'attr'     => $button_icon,
					)
				);
			}
		}

		if (
			'price' === $item_type
			&& (
				! empty( $price_supports['slider'] )
				|| ! empty( $price_supports['histogram'] )
				|| ! empty( $price_supports['buckets'] )
			)
		) {
			$pill_selector = "{$host} .dsm-loop-filter__price-pill";
			$styles        = array_merge(
				$styles,
				self::css_var_styles(
					$host,
					$attrs,
					array(
						'slider_track_height'        => '--dsm-lf-price-track-h',
						'slider_track_color'         => '--dsm-lf-price-track',
						'slider_fill_color'          => '--dsm-lf-price-fill',
						'slider_handle_size'         => '--dsm-lf-price-handle-size',
						'slider_handle_color'        => '--dsm-lf-price-handle',
						'slider_handle_border_color' => '--dsm-lf-price-handle-border',
						'slider_tooltip_offset'      => '--dsm-lf-price-tooltip-offset',
						'histogram_bar_color'        => '--dsm-lf-price-hist',
						'histogram_bar_dim_color'    => '--dsm-lf-price-hist-dim',
						'histogram_height'           => '--dsm-lf-price-hist-h',
						'price_bucket_gap'           => '--dsm-lf-price-bucket-gap',
					)
				),
				// Price-pill hover colors stay on the hovered pill, not the item host.
				self::css_var_styles(
					$pill_selector,
					$attrs,
					array(
						'price_pill_bg_color'          => '--dsm-lf-price-pill-bg',
						'price_pill_text_color'        => '--dsm-lf-price-pill-color',
						'price_pill_active_bg_color'   => '--dsm-lf-price-pill-active-bg',
						'price_pill_active_text_color' => '--dsm-lf-price-pill-active-color',
					)
				)
			);

			$pill_decoration = $attrs['price_pill']['decoration'] ?? null;
			if ( is_array( $pill_decoration ) ) {
				$pill_font = $pill_decoration['font'] ?? null;
				if (
					is_array( $pill_font )
					&& self::decoration_value_is_meaningful( $pill_font )
					&& class_exists( FontStyle::class )
				) {
					$styles[] = FontStyle::style(
						array(
							'selector'  => $pill_selector,
							'attr'      => $pill_font,
							'important' => true,
						)
					);
				}
				if ( self::has_decoration_branch( $pill_decoration, 'spacing' ) && class_exists( SpacingStyle::class ) ) {
					$styles[] = SpacingStyle::style(
						array(
							'selector'  => $pill_selector,
							'attr'      => $pill_decoration['spacing'],
							'important' => true,
						)
					);
				}
				if ( self::has_decoration_branch( $pill_decoration, 'border' ) && class_exists( BorderStyle::class ) ) {
					$styles[] = BorderStyle::style(
						array(
							'selector'  => $pill_selector,
							'attr'      => $pill_decoration['border'],
							'important' => true,
						)
					);
				}
				if ( self::has_decoration_branch( $pill_decoration, 'boxShadow' ) && class_exists( BoxShadowStyle::class ) ) {
					$styles[] = BoxShadowStyle::style(
						array(
							'selector'  => $pill_selector,
							'attr'      => $pill_decoration['boxShadow'],
							'important' => true,
						)
					);
				}
			}

			$styles = array_merge(
				$styles,
				self::emit_decoration_chrome_styles(
					"{$host} .dsm-loop-filter__price-value-labels",
					$attrs['price_value_labels']['decoration'] ?? null
				),
				self::emit_decoration_chrome_styles(
					"{$host} .dsm-loop-filter__price-tooltip",
					$attrs['price_value_labels']['decoration'] ?? null
				),
				self::emit_decoration_chrome_styles(
					"{$host} .dsm-loop-filter__price-currency-prefix",
					$attrs['price_currency_prefix_style']['decoration'] ?? null
				),
				self::emit_decoration_chrome_styles(
					"{$host} .dsm-loop-filter__price-currency-suffix",
					$attrs['price_currency_suffix_style']['decoration'] ?? null
				)
			);
		}

		$styles = array_values(
			array_filter(
				$styles,
				static function ( $style ): bool {
					return ! empty( $style );
				}
			)
		);

		if ( empty( $styles ) ) {
			return;
		}

		Style::add(
			array(
				'id'            => $order_class,
				'name'          => 'dsm/loop-filter-item',
				'orderIndex'    => 0,
				'storeInstance' => null,
				'styles'        => $styles,
			)
		);
	}

	/**
	 * Build CommonStyle entries that set CSS custom properties when set.
	 *
	 * @param string                $selector Root selector.
	 * @param array<string, mixed>  $attrs    Child attrs.
	 * @param array<string, string> $map      Attr key => CSS var.
	 * @return list<mixed>
	 */
	private static function css_var_styles( string $selector, array $attrs, array $map ): array {
		$out = array();
		foreach ( $map as $key => $css_var ) {
			$value = self::inner_desktop_string( $attrs, $key, '' );
			if ( ! self::has_override( $value ) ) {
				continue;
			}
			$out[] = CommonStyle::style(
				array(
					'selector'            => $selector,
					'attr'                => $attrs[ $key ]['innerContent'] ?? array(),
					'declarationFunction' => static function ( array $args ) use ( $css_var ): string {
						$declarations = new StyleDeclarations(
							array(
								'returnType' => 'string',
								'important'  => true,
							)
						);
						$raw = $args['attrValue'] ?? '';
						if ( is_array( $raw ) ) {
							if ( isset( $raw['color'] ) && is_scalar( $raw['color'] ) ) {
								$raw = (string) $raw['color'];
							} elseif ( isset( $raw['hex'] ) && is_scalar( $raw['hex'] ) ) {
								$raw = (string) $raw['hex'];
							} elseif ( isset( $raw['value'] ) && is_scalar( $raw['value'] ) ) {
								$raw = (string) $raw['value'];
							} else {
								$raw = '';
							}
						}
						if ( '' !== trim( (string) $raw ) ) {
							$declarations->add( $css_var, trim( (string) $raw ) );
						}
						return $declarations->value();
					},
				)
			);
		}
		return $out;
	}

	/**
	 * Build CommonStyle property entries when attrs are set.
	 *
	 * Uses !important so child colors beat parent Design and `.et_pb_button` theme rules.
	 *
	 * @param string                $selector Target selector.
	 * @param array<string, mixed>  $attrs    Child attrs.
	 * @param array<string, string> $map      Attr key => CSS property.
	 * @return list<mixed>
	 */
	private static function property_styles( string $selector, array $attrs, array $map ): array {
		$out = array();
		foreach ( $map as $key => $property ) {
			$value = self::inner_desktop_string( $attrs, $key, '' );
			if ( ! self::has_override( $value ) ) {
				continue;
			}
			$out[] = CommonStyle::style(
				array(
					'selector'            => $selector,
					'attr'                => $attrs[ $key ]['innerContent'] ?? array(),
					'declarationFunction' => static function ( array $args ) use ( $property ): string {
						$declarations = new StyleDeclarations(
							array(
								'returnType' => 'string',
								'important'  => true,
							)
						);
						$raw = $args['attrValue'] ?? '';
						if ( is_array( $raw ) ) {
							if ( isset( $raw['color'] ) && is_scalar( $raw['color'] ) ) {
								$raw = (string) $raw['color'];
							} elseif ( isset( $raw['hex'] ) && is_scalar( $raw['hex'] ) ) {
								$raw = (string) $raw['hex'];
							} elseif ( isset( $raw['value'] ) && is_scalar( $raw['value'] ) ) {
								$raw = (string) $raw['value'];
							} else {
								$raw = '';
							}
						}
						if ( '' !== trim( (string) $raw ) ) {
							$declarations->add( $property, trim( (string) $raw ) );
						}
						return $declarations->value();
					},
				)
			);
		}
		return $out;
	}
}
