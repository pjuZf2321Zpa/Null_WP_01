<?php
/**
 * Image Carousel Module.
 *
 * @package DiviSupreme.
 */

declare(strict_types=1);

namespace DiviSupreme\Modules;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}


use DiviSupreme\Includes\DsmFrontendDynamicAssets;
use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\Module\Options\Element\ElementClassnames;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use ET\Builder\Packages\Module\Options\Text\TextStyle;
use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use DiviSupreme\Extensions\IconLibraries\LegacyModuleIconStyles;

/**
 * Class that handles "ImageCarousel module".
 */
class ImageCarousel implements DependencyInterface {


	/**
	 * Register module.
	 * `DependencyInterface` interface ensures class method name `load()` is executed for initialization.
	 */
	public function load() {
		add_action( 'init', array( self::class, 'register_module' ) );
	}

	/**
	 * Initilises the module.
	 *
	 * @return void
	 */
	public static function dsm_initialise() {
		add_action(
			'divi_module_library_modules_dependency_tree',
			function ( $dependency_tree ) {
				$dependency_tree->add_dependency( new self() );
			}
		);
	}

	/**
	 * Prev icon style declaration.
	 *
	 * @param mixed $params Params.
	 */
	public static function prev_icon_style_declaration( $params ) {
		return LegacyModuleIconStyles::build_pseudo_icon_declaration( $params );
	}

	/**
	 * Next icon style declaration.
	 *
	 * @param mixed $params Params.
	 */
	public static function next_icon_style_declaration( $params ) {
		return LegacyModuleIconStyles::build_pseudo_icon_declaration( $params );
	}

	/**
	 * Arrow size drives `--swiper-navigation-size` at each breakpoint that is stored.
	 *
	 * Image carousel uses the size itself (not size + 20). Phone and tablet values
	 * print in their media queries when the Arrow Size control has them.
	 *
	 * @param array<string, mixed> $params Style params including attrValue for the current breakpoint.
	 * @return string
	 */
	public static function swiper_navigation_size_var_declaration( $params ) {
		$attr = $params['attrValue'] ?? '';

		if ( ! is_scalar( $attr ) || '' === trim( (string) $attr ) ) {
			return '';
		}

		$n = floatval( $attr );

		if ( ! is_finite( $n ) || $n < 0 ) {
			return '';
		}

		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
			)
		);

		$style_declarations->add( '--swiper-navigation-size', $n . 'px' );

		return $style_declarations->value();
	}


	/**
	 * Thumb image ratio style declaration.
	 *
	 * @param mixed $params Params.
	 */
	public static function thumb_image_ratio_style_declaration( $params ) {
		$attr = $params['attrValue'] ?? array();

		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
				'important'  => array(
					'aspect-ratio' => true,
				),
			)
		);

		$ratio_value = '';

		// Thumb Image Ratio.
		switch ( $attr ) {
			case '11':
				$ratio_value = '1 / 1';
				break;
			case '43':
				$ratio_value = '4 / 3';
				break;
			case '169':
				$ratio_value = '16 / 9';
				break;
			default:
				$ratio_value = '21 / 9';
		}

		$style_declarations->add( 'aspect-ratio', $ratio_value );

		return $style_declarations->value();
	}


	/**
	 * Thumb image position style declaration.
	 *
	 * @param mixed $params Params.
	 */
	public static function thumb_image_position_style_declaration( $params ) {
		$attr = $params['attrValue'] ?? '';

		if ( ! is_string( $attr ) || '' === $attr ) {
			return '';
		}

		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
				'important'  => array(
					'background-position' => true,
				),
			)
		);

		// Values are e.g. top_left → CSS keywords "top left" (hyphenated is invalid).
		$position_value = str_replace( '_', ' ', $attr );

		$style_declarations->add( 'background-position', $position_value );

		return $style_declarations->value();
	}

	/**
	 * Parse unitless opacity (0–1) from stored innerContent value.
	 *
	 * @param mixed $raw Stored value for the current breakpoint.
	 * @param float $fallback Default when empty or invalid.
	 * @return float
	 */
	private static function parse_thumbnail_opacity_value( $raw, float $fallback ): float {
		if ( null === $raw || false === $raw || '' === $raw ) {
			return $fallback;
		}
		if ( is_numeric( $raw ) ) {
			$n = (float) $raw;
			return max( 0.0, min( 1.0, $n ) );
		}
		if ( ! is_string( $raw ) ) {
			return $fallback;
		}
		$t = trim( $raw );
		if ( '' === $t || ! is_numeric( $t ) ) {
			return $fallback;
		}
		$n = (float) $t;
		return max( 0.0, min( 1.0, $n ) );
	}

	/**
	 * Opacity for inactive slideshow thumbnails (matches legacy SCSS default 0.4).
	 *
	 * @param array<string, mixed> $params Declaration params from CommonStyle.
	 * @return string
	 */
	public static function thumbnail_inactive_opacity_declaration( array $params ): string {
		$raw     = $params['attrValue'] ?? null;
		$opacity = self::parse_thumbnail_opacity_value( $raw, 0.4 );
		$decl    = new StyleDeclarations(
			array(
				'returnType' => 'string',
			)
		);
		$decl->add( 'opacity', (string) $opacity );
		return $decl->value();
	}

	/**
	 * Opacity for active slideshow thumbnail (matches legacy SCSS default 1).
	 *
	 * @param array<string, mixed> $params Declaration params from CommonStyle.
	 * @return string
	 */
	public static function thumbnail_active_opacity_declaration( array $params ): string {
		$raw     = $params['attrValue'] ?? null;
		$opacity = self::parse_thumbnail_opacity_value( $raw, 1.0 );
		$decl    = new StyleDeclarations(
			array(
				'returnType' => 'string',
			)
		);
		$decl->add( 'opacity', (string) $opacity );
		return $decl->value();
	}


	/**
	 * Build spacing-shaped attr for slideshow thumb position inset (merges legacy top/right/left innerContent).
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 * @return array<string, mixed>
	 */
	public static function slideshow_thumbs_offset_spacing_attr_for_style( array $attrs ): array {
		$breakpoints    = array( 'desktop', 'tablet', 'phone' );
		$legacy_key_map = array(
			'top'   => 'slideshow_thumbs_offset_top',
			'right' => 'slideshow_thumbs_offset_right',
			'left'  => 'slideshow_thumbs_offset_left',
		);
		$sides          = array( 'top', 'right', 'bottom', 'left' );
		$offset_root    = $attrs['slideshow_thumbs_offset'] ?? array();
		$spacing        = $offset_root['decoration']['spacing'] ?? array();
		$desktop_pad    = $spacing['desktop']['value']['padding'] ?? array();
		$out            = array();

		foreach ( $breakpoints as $bp ) {
			$pad_bp  = $spacing[ $bp ]['value']['padding'] ?? array();
			$padding = array();
			foreach ( $sides as $side ) {
				$raw = $pad_bp[ $side ] ?? '';
				if ( is_string( $raw ) ) {
					$raw = trim( $raw );
				}
				if ( '' === (string) $raw ) {
					$desk_side = $desktop_pad[ $side ] ?? '';
					if ( is_string( $desk_side ) ) {
						$desk_side = trim( $desk_side );
					}
					$raw = $desk_side;
				}
				if ( '' === (string) $raw && 'bottom' !== $side && isset( $legacy_key_map[ $side ] ) ) {
					$lk = $legacy_key_map[ $side ];
					if ( isset( $attrs[ $lk ] ) && is_array( $attrs[ $lk ] ) ) {
						$ic = $attrs[ $lk ]['innerContent'] ?? array();
						if ( is_array( $ic ) ) {
							$leg = $ic[ $bp ]['value'] ?? $ic['desktop']['value'] ?? '';
							$leg = is_string( $leg ) ? trim( $leg ) : $leg;
							if ( '' !== (string) $leg && null !== $leg ) {
								$raw = (string) $leg;
							}
						}
					}
				}
				$padding[ $side ] = is_string( $raw ) ? trim( (string) $raw ) : (string) $raw;
			}
			$out[ $bp ] = array(
				'value' => array(
					'padding' => $padding,
				),
			);
		}

		return $out;
	}


	/**
	 * Maps spacing.padding sides to CSS position longhands (top, right, bottom, left).
	 *
	 * @param array<string, mixed> $params Style params.
	 * @return string
	 */
	public static function slideshow_thumbs_offset_position_declaration( array $params ): string {
		$attr_value = $params['attrValue'] ?? array();
		$padding    = $attr_value['padding'] ?? array();
		if ( ! is_array( $padding ) ) {
			return '';
		}

		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
			)
		);

		foreach ( array( 'top', 'right', 'bottom', 'left' ) as $side ) {
			if ( ! array_key_exists( $side, $padding ) ) {
				continue;
			}
			$raw = $padding[ $side ];
			if ( null === $raw ) {
				continue;
			}
			$s = is_string( $raw ) ? trim( $raw ) : trim( (string) $raw );
			if ( '' === $s ) {
				continue;
			}
			$style_declarations->add( $side, $s );
		}

		return $style_declarations->value();
	}


	/**
	 * Register module.
	 */
	public static function register_module() {

		$module_json_path = DSM_DIR_PATH . 'divi-5/public/packages/module-library/image-carousel';

		ModuleRegistration::register_module(
			$module_json_path,
			array(
				'render_callback' => array( self::class, 'render_callback' ),
			)
		);
	}

	/**
	 * Render module style.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_styles( $args ) {
		$args                      = \DiviSupreme\Includes\DsmDiviBuilderCssScope::normalize_module_styles_args( $args );
		$attrs                     = $args['attrs'] ?? array();
		$elements                  = $args['elements'];
		$use_icon                  = $attrs['use_icon']['innerContent']['desktop']['value'] ?? '';
		$use_arrow_custom_position = $attrs['use_arrow_custom_position']['innerContent']['desktop']['value'] ?? '';
		$slider_orientation        = $attrs['slider_orientation']['innerContent']['desktop']['value'] ?? '';

		Style::add(
			array(
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => array(
					// Module.
					$elements->style(
						array(
							'attrName'   => 'module',
							'styleProps' => array(
								'disabledOn' => array(
									'disabledModuleVisibility' => $args['settings']['disabledModuleVisibility'] ?? null,
								),
							),
						)
					),

					CssStyle::style(
						array(
							'selector' => $args['orderClass'],
							'attr'     => $attrs['css'] ?? array(),
						)
					),

					$elements->style(
						array(
							'attrName' => 'arrowStyle',
						)
					),

					$elements->style(
						array(
							'attrName' => 'carousel_image_style',
						)
					),

					$elements->style(
						array(
							'attrName' => 'slideshow_image_style',
						)
					),

					$elements->style(
						array(
							'attrName' => 'slideshow_overlay_style',
						)
					),

					$elements->style(
						array(
							'attrName' => 'slideshow_padding',
						)
					),

					$elements->style(
						array(
							'attrName' => 'thumbs_padding',
						)
					),

					$elements->style(
						array(
							'attrName' => 'thumbnail_inactive_image_style',
						)
					),

					$elements->style(
						array(
							'attrName' => 'thumbnail_active_image_style',
						)
					),

					$elements->style(
						array(
							'attrName' => 'slideshow_slide_title_style',
						)
					),

					$elements->style(
						array(
							'attrName' => 'slideshow_slide_description_style',
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .swiper-button-prev::before",
							'attr'                => $attrs['arrow_prev_font_icon']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'prev_icon_style_declaration' ),
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .swiper-button-next::before",
							'attr'                => $attrs['arrow_next_font_icon']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'next_icon_style_declaration' ),
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .swiper-button-prev, {$args['orderClass']} .swiper-button-next",
							'attr'     => $attrs['arrow_size']['innerContent'] ?? array(),
							'property' => 'font-size',
						)
					),

					CommonStyle::style(
						array(
							'selector'            => $args['orderClass'],
							'attr'                => $attrs['arrow_size']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'swiper_navigation_size_var_declaration' ),
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .swiper-button-prev, {$args['orderClass']} .swiper-button-next",
							'attr'     => $attrs['arrow_color']['innerContent'] ?? array(),
							'property' => 'color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .swiper-button-prev, {$args['orderClass']} .swiper-button-next",
							'attr'     => $attrs['arrow_background_color']['innerContent'] ?? array(),
							'property' => 'background-color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']}.dsm_image_carousel_horizontal .swiper-pagination",
							'attr'     => $attrs['dots_horizontal_placement']['innerContent'] ?? array(),
							'property' => 'bottom',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .swiper-pagination-bullet",
							'attr'     => $attrs['dots_inactive_color']['innerContent'] ?? array(),
							'property' => 'background-color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .swiper-pagination-bullet.swiper-pagination-bullet-active",
							'attr'     => $attrs['dots_active_color']['innerContent'] ?? array(),
							'property' => 'background-color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .swiper-container.swiper-vertical",
							'attr'     => $attrs['slider_container_height']['innerContent'] ?? array(),
							'property' => 'height',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']}.dsm_image_carousel_horizontal .swiper-arrow-button",
							'attr'     => $attrs['arrow_horizontal_position']['innerContent'] ?? array(),
							'property' => 'top',
						)
					),

					'vertical' === $slider_orientation ?

						CommonStyle::style(
							array(
								'selector' => "{$args['orderClass']}.dsm_image_carousel_pagi_placement_right .swiper-pagination",
								'attr'     => $attrs['dots_horizontal_placement']['innerContent'] ?? array(),
								'property' => 'right',
							)
						) : '',

					'vertical' === $slider_orientation ?
						CommonStyle::style(
							array(
								'selector' => "{$args['orderClass']}.dsm_image_carousel_pagi_placement_left .swiper-pagination",
								'attr'     => $attrs['dots_horizontal_placement']['innerContent'] ?? array(),
								'property' => 'left',
							)
						) : '',

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']}.dsm_image_carousel_vertical .swiper-pagination",
							'attr'     => $attrs['dots_vertical_placement']['innerContent'] ?? array(),
							'property' => 'top',
						)
					),

					'on' === $use_arrow_custom_position ?
						CommonStyle::style(
							array(
								'selector' => "{$args['orderClass']}.dsm_image_carousel_horizontal .swiper-button-prev",
								'attr'     => $attrs['arrow_custom_position']['innerContent'] ?? array(),
								'property' => 'left',
							)
						)
					: '',

					'on' === $use_arrow_custom_position ?
						CommonStyle::style(
							array(
								'selector' => "{$args['orderClass']}.dsm_image_carousel_horizontal .swiper-button-next",
								'attr'     => $attrs['arrow_custom_position']['innerContent'] ?? array(),
								'property' => 'right',
							)
						)
					: '',

					'on' === $use_arrow_custom_position ?
						CommonStyle::style(
							array(
								'selector' => "{$args['orderClass']}.dsm_image_carousel_vertical .swiper-button-prev, {$args['orderClass']}.dsm_image_carousel_vertical .swiper-button-next",
								'attr'     => $attrs['arrow_custom_position']['innerContent'] ?? array(),
								'property' => 'right',
							)
						)
					: '',

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']}.dsm_image_carousel_vertical .swiper-button-prev, {$args['orderClass']}.dsm_image_carousel_vertical .swiper-button-next",
							'attr'     => $attrs['navi_hori_position']['innerContent'] ?? array(),
							'property' => 'left',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']}.dsm_image_carousel_vertical .swiper-button-prev",
							'attr'     => $attrs['top_navi_ver_position']['innerContent'] ?? array(),
							'property' => 'top',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']}.dsm_image_carousel_vertical .swiper-button-next",
							'attr'     => $attrs['bottom_navi_ver_position']['innerContent'] ?? array(),
							'property' => 'bottom',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm_image_carousel_slideshow .dsm_image_carousel_item .dsm_image_carousel_slideshow_bg",
							'attr'     => $attrs['slideshow_height']['innerContent'] ?? array(),
							'property' => 'height',
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm_image_gallery_thumbs .dsm_image_carousel_thumbs_image",
							'attr'                => $attrs['slideshow_ratio']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'thumb_image_ratio_style_declaration' ),
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm_image_gallery_thumbs .dsm_image_carousel_thumbs_image",
							'attr'                => $attrs['slideshow_image_position']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'thumb_image_position_style_declaration' ),
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .swiper-slide.dsm_image_carousel_item .dsm_image_carousel_slideshow_bg",
							'attr'     => $attrs['image_fit']['innerContent'] ?? array(),
							'property' => 'background-size',
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .swiper-slide.dsm_image_carousel_item .dsm_image_carousel_slideshow_bg",
							'attr'                => $attrs['image_position']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'thumb_image_position_style_declaration' ),
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm_image_gallery_thumbs .dsm_image_carousel_thumbs_image",
							'attr'     => $attrs['slideshow_image_fit']['innerContent'] ?? array(),
							'property' => 'background-size',
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm_image_gallery_thumbs .swiper-slide",
							'attr'                => $attrs['thumbnail_inactive_opacity']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'thumbnail_inactive_opacity_declaration' ),
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm_image_gallery_thumbs .swiper-slide-thumb-active",
							'attr'                => $attrs['thumbnail_active_opacity']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'thumbnail_active_opacity_declaration' ),
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .swiper-wrapper",
							'attr'     => $attrs['horizontal_alignment']['innerContent'] ?? array(),
							'property' => 'align-items',
						)
					),

					// Slideshow custom thumb strip: decoration.spacing padding → CSS position inset (TRBL).
					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm_image_gallery_thumbs.dsm_ic_slideshow_thumbs_absolute",
							'attr'                => self::slideshow_thumbs_offset_spacing_attr_for_style( $attrs ),
							'declarationFunction' => array( static::class, 'slideshow_thumbs_offset_position_declaration' ),
						)
					),
				),
			)
		);
	}

	/**
	 * Render module script data.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_script_data( $args ) {
		$elements = $args['elements'];

		// Element Script Data Options.
		$elements->script_data(
			array(
				'attrName' => 'module',
			)
		);
	}

	/**
	 * Render module classnames.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_classnames( $args ) {
		$classnames_instance    = $args['classnamesInstance'];
		$attrs                  = $args['attrs'];
		$pagi_vertical_position = $attrs['pagi_vertical_position']['innerContent']['desktop']['value'] ?? '';
		$slider_orientation     = $attrs['slider_orientation']['innerContent']['desktop']['value'] ?? '';
		$arrow_desktop          = $attrs['arrow_position']['innerContent']['desktop']['value'] ?? 'outside';
		$arrow_phone            = $attrs['arrow_position']['innerContent']['phone']['value'] ?? '';
		if ( '' === $arrow_phone ) {
			$legacy_mobile = $attrs['arrow_position_mobile']['innerContent']['desktop']['value'] ?? '';
			$arrow_phone   = '' !== $legacy_mobile ? $legacy_mobile : $arrow_desktop;
		}
		$infinite_smooth_scrolling = $attrs['infinite_smooth_scrolling']['innerContent']['desktop']['value'] ?? '';

		// Module.
		$classnames_instance->add(
			ElementClassnames::classnames(
				array(
					'attrs' => $attrs['module']['decoration'] ?? array(),
				)
			)
		);

		$classnames_instance->add( "dsm_image_carousel_$slider_orientation" );
		$classnames_instance->add( "dsm_image_carousel_pagi_placement_$pagi_vertical_position" );
		$classnames_instance->add( "dsm_image_carousel_arrow_$arrow_desktop" );

		if ( 'outside' === $arrow_desktop && 'inside' === $arrow_phone ) {
			$classnames_instance->add( 'dsm_image_carousel_arrow_mobile_inside' );
		}

		if ( 'on' === $infinite_smooth_scrolling ) {
			$classnames_instance->add( 'dsm_image_carousel_infinite_scroll' );
		}

		$slider_type_cb   = $attrs['slider_type']['innerContent']['desktop']['value'] ?? '';
		$slide_overlay_on = 'on' === ( $attrs['slideshow_use_overlay']['innerContent']['desktop']['value'] ?? 'off' );
		if ( $slide_overlay_on && in_array( $slider_type_cb, array( 'carousel', 'slideshow' ), true ) ) {
			$classnames_instance->add( 'dsm_ic_slideshow_use_overlay' );
			$classnames_instance->add( 'dsm_ic_use_slide_image_overlay' );
		}
		if ( 'slideshow' === $slider_type_cb ) {
			$show_thumbs_cb = $attrs['slideshow_show_thumbs']['innerContent']['desktop']['value'] ?? 'on';
			if ( 'on' === $show_thumbs_cb ) {
				$thumbs_pos_cb = $attrs['slideshow_thumbs_position']['innerContent']['desktop']['value'] ?? 'bottom';
				if ( in_array( $thumbs_pos_cb, array( 'top', 'bottom', 'custom' ), true ) ) {
					$classnames_instance->add( 'dsm_ic_slideshow_thumbs_' . $thumbs_pos_cb );
				}
			}
		}
	}

	/**
	 * Get gallery.
	 *
	 * @param mixed $args             Args.
	 * @param mixed $conditional_tags Conditional tags.
	 * @param mixed $current_page     Current page.
	 */
	public static function get_gallery( $args = array(), $conditional_tags = array(), $current_page = array() ) {

		$attachments = array();

		$defaults = array(
			'gallery_ids'        => array(),
			'gallery_orderby'    => '',
			'gallery_captions'   => array(),
			'sizes'              => 'full',
			'lightbox_img_sizes' => 'full',
			'slideshow_sizes'    => 'large',
		);

		$args = wp_parse_args( $args, $defaults );

		$attachments_args = array(
			'include'        => $args['gallery_ids'],
			'post_status'    => 'inherit',
			'post_type'      => 'attachment',
			'post_mime_type' => 'image',
			'order'          => 'ASC',
			'orderby'        => 'post__in',
		);

		if ( 'rand' === $args['gallery_orderby'] ) {
			$attachments_args['orderby'] = 'rand';
		}

		$_attachments = get_posts( $attachments_args );

		foreach ( $_attachments as $key => $val ) {
			$attachments[ $key ]                          = $_attachments[ $key ];
			$attachments[ $key ]->image_src_full          = wp_get_attachment_image_src( $val->ID, $args['sizes'] );
			$attachments[ $key ]->lightbox_image_src_full = wp_get_attachment_image_src( $val->ID, $args['lightbox_img_sizes'] );
			$attachments[ $key ]->slideshow_sizes         = wp_get_attachment_image_src( $val->ID, $args['slideshow_sizes'] );

		}
		return $attachments;
	}

	/**
	 * Build the HTML `sizes` attribute for carousel `<img>` tags from slides-per-view.
	 *
	 * Aligns roughly with Swiper breakpoints (981px / 768px) used in `image-carousel.js`.
	 *
	 * @param int $slides_phone  Slides per view at phone widths.
	 * @param int $slides_tablet Slides per view at tablet widths.
	 * @param int $slides_desktop Slides per view at desktop widths.
	 * @return string
	 */
	private static function get_carousel_image_sizes_attr( $slides_phone, $slides_tablet, $slides_desktop ) {
		$phone   = max( 1, (int) $slides_phone );
		$tablet  = max( 1, (int) $slides_tablet );
		$desktop = max( 1, (int) $slides_desktop );

		$vw_phone   = min( 100, (int) ceil( 100 / $phone ) );
		$vw_tablet  = min( 100, (int) ceil( 100 / $tablet ) );
		$vw_desktop = min( 100, (int) ceil( 100 / $desktop ) );

		return sprintf(
			'(max-width: 767px) %1$dvw, (max-width: 980px) %2$dvw, %3$dvw',
			$vw_phone,
			$vw_tablet,
			$vw_desktop
		);
	}

	/**
	 * Render a carousel `<img>` for the selected WordPress image size.
	 *
	 * For a concrete size (medium, large, thumbnail, …) use a single `src` like the Visual Builder
	 * and Divi 4 — `wp_get_attachment_image()` would add a `srcset` that includes larger/full
	 * candidates, and with our slide-based `sizes` (e.g. 25vw) the browser often picks the full
	 * file so FE no longer matches the Image Size control.
	 *
	 * For `full`, keep WordPress responsive `srcset` / `sizes`.
	 *
	 * When lazy loading is enabled, adds `swiper-lazy` and `loading="lazy"` (Swiper 12 uses native
	 * lazy loading + `lazyPreloadPrevNext`). When disabled, uses `loading="eager"` so images are not
	 * deferred by the browser.
	 *
	 * @param int    $attachment_id       Attachment ID.
	 * @param string $wp_image_size       Registered image size (e.g. full, large).
	 * @param string $carousel_sizes_attr Value for the `sizes` attribute (full size only).
	 * @param array  $extra_attrs         Extra attributes (title, alt, data-*, class).
	 * @param bool   $lazyload_enabled    Whether the module lazy-load option is on.
	 * @return string
	 */
	private static function get_carousel_attachment_image_html( $attachment_id, $wp_image_size, $carousel_sizes_attr, array $extra_attrs = array(), $lazyload_enabled = false ) {
		$attachment_id = (int) $attachment_id;
		$wp_image_size = is_string( $wp_image_size ) && '' !== $wp_image_size ? $wp_image_size : 'large';
		$img_attrs     = $extra_attrs;

		if ( isset( $img_attrs['alt'] ) && '' === $img_attrs['alt'] ) {
			unset( $img_attrs['alt'] );
		}

		if ( isset( $img_attrs['title'] ) && '' === $img_attrs['title'] ) {
			unset( $img_attrs['title'] );
		}

		$existing_class = isset( $img_attrs['class'] ) ? (string) $img_attrs['class'] : '';
		unset( $img_attrs['class'], $img_attrs['src'], $img_attrs['srcset'], $img_attrs['sizes'], $img_attrs['width'], $img_attrs['height'] );

		$size_slug = sanitize_html_class( $wp_image_size );
		$class     = trim(
			sprintf(
				'%1$sattachment-%2$s size-%2$s %3$s',
				$lazyload_enabled ? 'swiper-lazy ' : '',
				$size_slug,
				$existing_class
			)
		);

		$supports_loading = version_compare( get_bloginfo( 'version' ), '5.5', '>=' );

		// Concrete sizes: lock to that URL (VB + D4 parity). Do not emit upgradeable srcset.
		if ( 'full' !== $wp_image_size ) {
			$src = wp_get_attachment_image_src( $attachment_id, $wp_image_size );
			if ( ! $src ) {
				return '';
			}

			$parts = array(
				sprintf( 'src="%s"', esc_url( $src[0] ) ),
				sprintf( 'width="%d"', (int) $src[1] ),
				sprintf( 'height="%d"', (int) $src[2] ),
				sprintf( 'class="%s"', esc_attr( $class ) ),
			);

			if ( $supports_loading ) {
				$parts[] = sprintf( 'loading="%s"', $lazyload_enabled ? 'lazy' : 'eager' );
			}

			foreach ( $img_attrs as $attr_name => $attr_value ) {
				if ( ! is_string( $attr_name ) || '' === $attr_name ) {
					continue;
				}
				$parts[] = sprintf(
					'%1$s="%2$s"',
					esc_attr( $attr_name ),
					esc_attr( (string) $attr_value )
				);
			}

			return '<img ' . implode( ' ', $parts ) . ' />';
		}

		if ( '' !== $carousel_sizes_attr ) {
			$img_attrs['sizes'] = $carousel_sizes_attr;
		}

		$img_attrs['class'] = $class;
		if ( $supports_loading ) {
			$img_attrs['loading'] = $lazyload_enabled ? 'lazy' : 'eager';
		}

		$html = wp_get_attachment_image( $attachment_id, 'full', false, $img_attrs );

		if ( false === $html || '' === $html ) {
			$src = wp_get_attachment_image_src( $attachment_id, 'full' );
			if ( ! $src ) {
				return '';
			}

			$alt    = isset( $extra_attrs['alt'] ) ? (string) $extra_attrs['alt'] : '';
			$title  = isset( $extra_attrs['title'] ) ? (string) $extra_attrs['title'] : '';
			$lazy_a = $supports_loading
				? sprintf( ' loading="%s"', $lazyload_enabled ? 'lazy' : 'eager' )
				: '';

			return sprintf(
				'<img src="%1$s" width="%6$d" height="%7$d" class="%2$s"%3$s%4$s%5$s />',
				esc_url( $src[0] ),
				esc_attr( $class ),
				$lazy_a,
				'' !== $alt ? ' alt="' . esc_attr( $alt ) . '"' : '',
				'' !== $title ? ' title="' . esc_attr( $title ) . '"' : '',
				(int) $src[1],
				(int) $src[2]
			);
		}

		return $html;
	}

	/**
	 * Plain slideshow description for overlay + data attributes: caption (attachment excerpt),
	 * else attachment Description (post content) — only when the field contains visible text
	 * after stripping markup (empty caption + img-only/description never falls back incorrectly).
	 *
	 * @param \WP_Post $attachment Attachment post object.
	 * @return string Plain text, may be empty.
	 */
	private static function slideshow_attachment_description_plain_text( $attachment ): string {
		$caption_raw = wp_get_attachment_caption( $attachment->ID );
		$caption_txt = trim( wp_strip_all_tags( is_string( $caption_raw ) ? $caption_raw : '' ) );
		if ( '' !== $caption_txt ) {
			return $caption_txt;
		}

		return trim( wp_strip_all_tags( (string) $attachment->post_content ) );
	}

	/**
	 * Slideshow caption overlay: optional title (attachment title / alt) and optional description (caption / description).
	 *
	 * @param \WP_Post $attachment            Attachment post.
	 * @param string   $dsm_image_alt_text    Alt meta.
	 * @param string   $show_title             on|off.
	 * @param string   $show_description       on|off.
	 * @param string   $align_h               flex-start|center|flex-end.
	 * @param string   $align_v               flex-start|center|flex-end (maps with justify-content on overlay).
	 * @return string Markup or empty string.
	 */
	private static function slideshow_slide_caption_overlay_html( $attachment, $dsm_image_alt_text, $show_title, $show_description, $align_h, $align_v ) {
		$title_html       = '';
		$description_html = '';

		if ( 'on' === $show_title ) {
			$t = trim( (string) $attachment->post_title );
			if ( '' === $t ) {
				$t = trim( (string) $dsm_image_alt_text );
			}
			if ( '' !== $t ) {
				$title_html = sprintf(
					'<span class="dsm_image_carousel_slide_title">%s</span>',
					esc_html( $t )
				);
			}
		}

		if ( 'on' === $show_description ) {
			$d = self::slideshow_attachment_description_plain_text( $attachment );
			if ( '' !== $d ) {
				$description_html = sprintf(
					'<span class="dsm_image_carousel_slide_description">%s</span>',
					esc_html( $d )
				);
			}
		}

		if ( '' === $title_html && '' === $description_html ) {
			return '';
		}

		$justify = in_array( $align_v, array( 'flex-start', 'center', 'flex-end' ), true ) ? $align_v : 'center';
		$items   = in_array( $align_h, array( 'flex-start', 'center', 'flex-end' ), true ) ? $align_h : 'center';

		$inner = sprintf(
			'<div class="dsm_image_carousel_slideshow_content">%1$s%2$s</div>',
			$title_html,
			$description_html
		);

		return sprintf(
			'<div class="dsm_image_carousel_slide_title_overlay" style="justify-content:%1$s;align-items:%2$s;">%3$s</div>',
			esc_attr( $justify ),
			esc_attr( $items ),
			$inner
		);
	}

	/**
	 * Insert slideshow inner markup (optional color overlay, optional title overlay) inside `div.dsm_image_carousel_slideshow_bg`.
	 *
	 * @param string $slide_bg        Single root `div.dsm_image_carousel_slideshow_bg` element (empty).
	 * @param string $use_overlay     on|off — outputs `.dsm_image_carousel_slideshow_overlay` when on (slideshow background or carousel slide wrapper).
	 * @param string $title_overlay_html Title overlay HTML (may be empty).
	 * @return string
	 */
	private static function slideshow_slideshow_bg_append_inner_content( $slide_bg, $use_overlay, $title_overlay_html ) {
		$fragments = '';
		if ( 'on' === $use_overlay ) {
			$fragments .= '<div class="dsm_image_carousel_slideshow_overlay" aria-hidden="true"></div>';
		}
		if ( '' !== $title_overlay_html ) {
			$fragments .= $title_overlay_html;
		}
		if ( '' === $fragments ) {
			return $slide_bg;
		}

		return (string) preg_replace( '#>(\s*)</div>\s*$#', '>' . $fragments . '</div>', $slide_bg, 1 );
	}

	/**
	 * Slideshow thumbnail Swiper wrapper HTML.
	 *
	 * @param string $thumb_output Inner slides HTML.
	 * @param string $slider_direction Slider `dir` attribute.
	 * @param string $position       top|bottom|custom.
	 * @return string
	 */
	private static function build_slideshow_thumbs_markup( string $thumb_output, string $slider_direction, string $position ): string {
		$thumb_classes_parts = array( 'swiper', 'dsm_image_gallery_thumbs' );
		if ( 'custom' === $position ) {
			$thumb_classes_parts[] = 'dsm_ic_slideshow_thumbs_absolute';
		}

		return sprintf(
			'<div thumbsslider class="%1$s" dir="%2$s"><div class="swiper-wrapper">%3$s</div></div>',
			esc_attr( implode( ' ', $thumb_classes_parts ) ),
			esc_attr( $slider_direction ),
			$thumb_output
		);
	}

	/**
	 * Format a title animation time string for a `data-*` attribute (matches VB `dsmIcCssAnimationTime`).
	 *
	 * @param string $raw              Stored innerContent value.
	 * @param string $fallback_digits Milliseconds without unit when empty.
	 * @return string Escaped attribute fragment (no outer quotes).
	 */
	private static function image_carousel_title_anim_format_for_attr( string $raw, string $fallback_digits ): string {
		$s = trim( $raw );
		if ( '' === $s ) {
			return esc_attr( $fallback_digits . 'ms' );
		}
		if ( preg_match( '/ms$/i', $s ) ) {
			return esc_attr( $s );
		}
		if ( preg_match( '/^-?\d+(\.\d+)?s$/i', $s ) ) {
			return esc_attr( $s );
		}
		if ( preg_match( '/^-?\d+(\.\d+)?$/', $s ) ) {
			return esc_attr( $s . 'ms' );
		}

		return esc_attr( $fallback_digits . 'ms' );
	}

	/**
	 * Get thumbnail image output.
	 *
	 * @param mixed $attachments Attachments.
	 * @param mixed $lazyload    Lazyload.
	 */
	public static function get_thumbnail_image_output( $attachments, $lazyload ) {

		$output = '';

		foreach ( $attachments as $id => $attachment ) {
			$dsm_image_alt_text = get_post_meta( $attachment->ID, '_wp_attachment_image_alt', true );

			if ( 'on' === $lazyload ) {
				$thumbnail_output = sprintf(
					'<div class="dsm_image_carousel_thumbs_image swiper-lazy" role="img" aria-label="%2$s" data-dsm-lazy-bg="%1$s"></div>',
					esc_url( $attachment->slideshow_sizes[0] ),
					esc_attr( $dsm_image_alt_text )
				);
			} else {
				$thumbnail_output = sprintf(
					'<div class="dsm_image_carousel_thumbs_image skip-lazy" role="img" aria-label="%2$s" style="background-image: url(%1$s)"></div>',
					esc_url( $attachment->slideshow_sizes[0] ),
					esc_attr( $dsm_image_alt_text )
				);
			}

			$output .= sprintf(
				'<div class="swiper-slide">%1$s</div>',
				$thumbnail_output
			);
		}

		return $output;
	}

	/**
	 * Build the main slide markup (carousel `<img>` with responsive sources, or slideshow).
	 *
	 * @param array  $attachments           Attachment rows from `get_gallery()`.
	 * @param string $show_lightbox         Show lightbox on/off.
	 * @param string $slider_type         carousel|slideshow.
	 * @param string $wp_image_size       Registered size for slide images (`sizes` module option).
	 * @param string $lightbox_img_size   Registered size for lightbox `href` / `data-mfp-src`.
	 * @param string $carousel_sizes_attr Value for the `sizes` attribute on `<img>`.
	 * @param string $lazyload            Lazy load option on|off.
	 * @param array  $slideshow_slide_options Optional: `show_slide_title`, `show_slide_description`, `title_align_h`, `title_align_v`, `use_slideshow_overlay` (carousel + slideshow slide image overlay).
	 * @return string
	 */
	public static function getImageOutput( $attachments, $show_lightbox, $slider_type, $wp_image_size = 'large', $lightbox_img_size = 'full', $carousel_sizes_attr = '', $lazyload = 'off', array $slideshow_slide_options = array() ) {

		$output = '';

		$lazy_on = 'on' === $lazyload;

		$ss_show_title       = isset( $slideshow_slide_options['show_slide_title'] ) ? (string) $slideshow_slide_options['show_slide_title'] : 'off';
		$ss_show_description = isset( $slideshow_slide_options['show_slide_description'] ) ? (string) $slideshow_slide_options['show_slide_description'] : 'off';
		$ss_align_h          = isset( $slideshow_slide_options['title_align_h'] ) ? (string) $slideshow_slide_options['title_align_h'] : 'center';
		$ss_align_v          = isset( $slideshow_slide_options['title_align_v'] ) ? (string) $slideshow_slide_options['title_align_v'] : 'center';
		$ss_use_overlay      = isset( $slideshow_slide_options['use_slideshow_overlay'] ) ? (string) $slideshow_slide_options['use_slideshow_overlay'] : 'off';

		foreach ( $attachments as $id => $attachment ) {
			$dsm_upload_gallery_custom_link_url       = get_post_meta( $attachment->ID, 'dsm_upload_gallery_custom_link_url', true );
			$dsm_upload_gallery_link_url_target       = get_post_meta( $attachment->ID, 'dsm_upload_gallery_link_url_target', true );
			$dsm_upload_gallery_link_as_download_file = get_post_meta( $attachment->ID, 'dsm_upload_gallery_link_as_download_file', true );
			$dsm_image_alt_text                       = get_post_meta( $attachment->ID, '_wp_attachment_image_alt', true );
			$dsm_slide_desc_plain                     = self::slideshow_attachment_description_plain_text( $attachment );

			$title_overlay = self::slideshow_slide_caption_overlay_html(
				$attachment,
				(string) $dsm_image_alt_text,
				$ss_show_title,
				$ss_show_description,
				$ss_align_h,
				$ss_align_v
			);

			$image_output = '';

			if ( 'carousel' === $slider_type ) {
				$img_extra = array(
					'title' => $attachment->post_title,
					'alt'   => $dsm_image_alt_text,
				);
				if ( '' !== $dsm_slide_desc_plain ) {
					$img_extra['data-dsm-image-description'] = $dsm_slide_desc_plain;
				}
				$img_html = self::get_carousel_attachment_image_html(
					(int) $attachment->ID,
					$wp_image_size,
					$carousel_sizes_attr,
					$img_extra,
					$lazy_on
				);

				if ( '' === $img_html ) {
					continue;
				}

				if ( 'on' === $show_lightbox ) {
					$lightbox_src = wp_get_attachment_image_src( (int) $attachment->ID, $lightbox_img_size );
					$lightbox_url = $lightbox_src ? $lightbox_src[0] : $attachment->image_src_full[0];

					$image_output = sprintf(
						'<a class="%2$s" href="%3$s" data-mfp-src="%3$s">%1$s</a>',
						$img_html,
						'dsm_image_carousel_lightbox',
						esc_url( $lightbox_url )
					);
				} elseif ( '' !== $dsm_upload_gallery_custom_link_url ) {
					$image_output = sprintf(
						'<a href="%2$s" class="dsm_image_carousel_link" target="%3$s" %4$s>%1$s</a>',
						$img_html,
						esc_url( $dsm_upload_gallery_custom_link_url ),
						esc_attr( $dsm_upload_gallery_link_url_target ),
						( '1' === $dsm_upload_gallery_link_as_download_file ? ' download' : '' )
					);
				} else {
					$image_output = $img_html;
				}

				if ( 'on' === $ss_use_overlay ) {
					$image_output = sprintf(
						'<div class="dsm_image_carousel_carousel_media">%1$s<div class="dsm_image_carousel_slideshow_overlay" aria-hidden="true"></div></div>',
						$image_output
					);
				}
			} elseif ( 'on' === $show_lightbox ) {
				$lightbox_src = wp_get_attachment_image_src( (int) $attachment->ID, $lightbox_img_size );
				$lightbox_url = $lightbox_src ? $lightbox_src[0] : $attachment->image_src_full[0];

				if ( $lazy_on ) {
					$slide_bg = sprintf(
						'<div class="dsm_image_carousel_slideshow_bg swiper-lazy" role="img" data-dsm-lazy-bg="%1$s" title="%2$s" data-dsm-image-description="%3$s" data-title="%2$s"></div>',
						esc_url( $attachment->image_src_full[0] ),
						esc_attr( $attachment->post_title ),
						esc_attr( $dsm_slide_desc_plain )
					);
				} else {
					$slide_bg = sprintf(
						'<div class="dsm_image_carousel_slideshow_bg" role="img" style="background-image: url(%1$s)" title="%2$s" data-dsm-image-description="%3$s" data-title="%2$s"></div>',
						esc_url( $attachment->image_src_full[0] ),
						esc_attr( $attachment->post_title ),
						esc_attr( $dsm_slide_desc_plain )
					);
				}

				$slide_inner = self::slideshow_slideshow_bg_append_inner_content( $slide_bg, $ss_use_overlay, $title_overlay );

				$image_output = sprintf(
					'<a class="%2$s" href="%3$s" data-mfp-src="%3$s">%1$s</a>',
					$slide_inner,
					'dsm_image_carousel_lightbox',
					esc_url( $lightbox_url )
				);
			} elseif ( '' !== $dsm_upload_gallery_custom_link_url ) {
				$loading_attr = '';
				if ( version_compare( get_bloginfo( 'version' ), '5.5', '>=' ) ) {
					$loading_attr = $lazy_on ? ' loading="lazy"' : ' loading="eager"';
				}
				$lazy_class = $lazy_on ? ' class="swiper-lazy"' : '';

				$slide_img = sprintf(
					'<img src="%1$s" title="%2$s"%3$s%4$s%5$s />',
					esc_url( $attachment->image_src_full[0] ),
					esc_attr( $attachment->post_title ),
					$lazy_class,
					$loading_attr,
					'' !== $dsm_image_alt_text ? ' alt="' . esc_attr( $dsm_image_alt_text ) . '"' : ''
				);

				$slide_inner = $slide_img . $title_overlay;

				$image_output = sprintf(
					'<a href="%2$s" class="dsm_image_carousel_link%5$s" target="%3$s" %4$s>%1$s</a>',
					$slide_inner,
					esc_url( $dsm_upload_gallery_custom_link_url ),
					esc_attr( $dsm_upload_gallery_link_url_target ),
					( '1' === $dsm_upload_gallery_link_as_download_file ? ' download' : '' ),
					'' !== $title_overlay ? ' dsm_ic_slideshow_link_title' : ''
				);

			} else {
				if ( $lazy_on ) {
					$slide_bg = sprintf(
						'<div class="dsm_image_carousel_slideshow_bg swiper-lazy" role="img" data-dsm-lazy-bg="%1$s" title="%2$s" data-title="%2$s"></div>',
						esc_url( $attachment->image_src_full[0] ),
						esc_attr( $attachment->post_title )
					);
				} else {
					$slide_bg = sprintf(
						'<div class="dsm_image_carousel_slideshow_bg" role="img" style="background-image: url(%1$s)" data-title="%2$s"></div>',
						esc_url( $attachment->image_src_full[0] ),
						esc_attr( $attachment->post_title )
					);
				}

				$image_output = self::slideshow_slideshow_bg_append_inner_content( $slide_bg, $ss_use_overlay, $title_overlay );
			}

			$output .= sprintf(
				'<div class="swiper-slide dsm_image_carousel_item">%s</div>',
				$image_output
			);
		}

		return $output;
	}

	/**
	 * Render module HTML output.
	 *
	 * @param array     $attrs - Modules Attributes.
	 * @param string    $content - Content.
	 * @param \WP_Block $block - Block.
	 * @param mixed     $elements - Elements.
	 */
	public static function render_callback( $attrs, $content, $block, $elements ) {
		$gallery_ids_desktop = $attrs['gallery_ids']['innerContent']['desktop']['value'] ?? '';
		$gallery_ids_tablet  = $attrs['gallery_ids']['innerContent']['tablet']['value'] ?? '';
		$gallery_ids_phone   = $attrs['gallery_ids']['innerContent']['phone']['value'] ?? '';

		if ( '' === $gallery_ids_tablet ) {
			$gallery_ids_tablet = $gallery_ids_desktop;
		}
		if ( '' === $gallery_ids_phone ) {
			$gallery_ids_phone = '' !== $gallery_ids_tablet ? $gallery_ids_tablet : $gallery_ids_desktop;
		}

		$gallery_ids                    = $gallery_ids_desktop;
		$gallery_orderby                = $attrs['gallery_orderby']['innerContent']['desktop']['value'] ?? '';
		$sizes                          = $attrs['sizes']['innerContent']['desktop']['value'] ?? '';
		$show_lightbox                  = $attrs['show_lightbox']['innerContent']['desktop']['value'] ?? '';
		$infinite                       = $attrs['infinite']['innerContent']['desktop']['value'] ?? '';
		$slider_effect                  = $attrs['slider_effect']['innerContent']['desktop']['value'] ?? '';
		$slider_effect_shadows          = $attrs['slider_effect_shadows']['innerContent']['desktop']['value'] ?? '';
		$slider_effect_coverflow_rotate = $attrs['slider_effect_coverflow_rotate']['innerContent']['desktop']['value'] ?? '';
		$multiple_slide_row             = $attrs['multiple_slide_row']['innerContent']['desktop']['value'] ?? '';
		$slide_to_show                  = $attrs['slide_to_show']['innerContent']['desktop']['value'] ?? '';
		$slide_to_show_tablet           = $attrs['slide_to_show']['innerContent']['tablet']['value'] ?? '';
		$slide_to_show_phone            = $attrs['slide_to_show']['innerContent']['phone']['value'] ?? '';
		$slide_to_scroll                = $attrs['slide_to_scroll']['innerContent']['desktop']['value'] ?? '';
		$slide_to_scroll_tablet         = $attrs['slide_to_scroll']['innerContent']['tablet']['value'] ?? '';
		$slide_to_scroll_phone          = $attrs['slide_to_scroll']['innerContent']['phone']['value'] ?? '';
		$space_between                  = $attrs['space_between']['innerContent']['desktop']['value'] ?? '';
		$space_between_tablet           = $attrs['space_between']['innerContent']['tablet']['value'] ?? '';
		$space_between_phone            = $attrs['space_between']['innerContent']['phone']['value'] ?? '';
		$slide_row                      = $attrs['slide_row']['innerContent']['desktop']['value'] ?? '';
		$slide_row_tablet               = $attrs['slide_row']['innerContent']['tablet']['value'] ?? '';
		$slide_row_phone                = $attrs['slide_row']['innerContent']['phone']['value'] ?? '';
		$centered_slides                = $attrs['centered_slides']['innerContent']['desktop']['value'] ?? '';
		$speed                          = $attrs['speed']['innerContent']['desktop']['value'] ?? '';
		$autoplay                       = $attrs['autoplay']['innerContent']['desktop']['value'] ?? '';
		$autoplay_speed                 = $attrs['autoplay_speed']['innerContent']['desktop']['value'] ?? '';
		$touch_move                     = $attrs['touch_move']['innerContent']['desktop']['value'] ?? '';
		$grab                           = $attrs['grab']['innerContent']['desktop']['value'] ?? '';
		$pause_on_hover                 = $attrs['pause_on_hover']['innerContent']['desktop']['value'] ?? '';
		$show_lightbox_gallery          = $attrs['show_lightbox_gallery']['innerContent']['desktop']['value'] ?? '';
		$infinite_smooth_scrolling      = $attrs['infinite_smooth_scrolling']['innerContent']['desktop']['value'] ?? '';
		$slider_effect_coverflow_depth  = $attrs['slider_effect_coverflow_depth']['innerContent']['desktop']['value'] ?? '';
		$show_lightbox_caption          = $attrs['show_lightbox_caption']['innerContent']['desktop']['value'] ?? '';
		$dots                           = $attrs['dots']['innerContent']['desktop']['value'] ?? '';
		$arrows                         = $attrs['arrows']['innerContent']['desktop']['value'] ?? '';
		$mousewheel                     = $attrs['mousewheel']['innerContent']['desktop']['value'] ?? '';
		$slider_orientation             = $attrs['slider_orientation']['innerContent']['desktop']['value'] ?? '';
		$slide_to_row_show              = $attrs['slide_to_row_show']['innerContent']['desktop']['value'] ?? '';
		$slide_to_row_show_tablet       = $attrs['slide_to_row_show']['innerContent']['tablet']['value'] ?? '';
		$slide_to_row_show_phone        = $attrs['slide_to_row_show']['innerContent']['phone']['value'] ?? '';
		$autoplay_viewport              = $attrs['autoplay_viewport']['innerContent']['desktop']['value'] ?? '';
		$lazyload                       = $attrs['lazyload']['innerContent']['desktop']['value'] ?? '';
		$slider_type                    = $attrs['slider_type']['innerContent']['desktop']['value'] ?? '';
		$slideshow_effect               = $attrs['slideshow_effect']['innerContent']['desktop']['value'] ?? '';
		$slideshow_to_show              = $attrs['slideshow_to_show']['innerContent']['desktop']['value'] ?? '';
		$slideshow_to_show_tablet       = $attrs['slideshow_to_show']['innerContent']['tablet']['value'] ?? '';
		$slideshow_to_show_phone        = $attrs['slideshow_to_show']['innerContent']['phone']['value'] ?? '';
		$show_lightbox_title            = $attrs['show_lightbox_title']['innerContent']['desktop']['value'] ?? '';
		$slider_direction               = $attrs['slider_direction']['innerContent']['desktop']['value'] ?? '';
		$lightbox_img_sizes             = $attrs['lightbox_img_sizes']['innerContent']['desktop']['value'] ?? '';
		$slideshow_sizes                = $attrs['slideshow_sizes']['innerContent']['desktop']['value'] ?? '';
		$slideshow_show_thumbs          = $attrs['slideshow_show_thumbs']['innerContent']['desktop']['value'] ?? 'on';
		$slideshow_thumbs_position      = $attrs['slideshow_thumbs_position']['innerContent']['desktop']['value'] ?? 'bottom';

		$wp_need_magnific_carousel = 'off' !== $show_lightbox;
		if ( $wp_need_magnific_carousel ) {
			if ( function_exists( 'dsm_ensure_registered_script_dependency' ) && function_exists( 'dsm_get_active_magnific_popup_script_handle' ) ) {
				dsm_ensure_registered_script_dependency(
					'dsm-image-carousel',
					dsm_get_active_magnific_popup_script_handle()
				);
			}
			if ( function_exists( 'dsm_enqueue_magnific_popup_assets' ) ) {
				dsm_enqueue_magnific_popup_assets();
			}
		}

		if ( \DiviSupreme\Includes\DsmFrontendAssetRegistry::should_wp_enqueue_module_styles( 'dsm/image-carousel' ) ) {
			wp_enqueue_style( \DiviSupreme\Includes\DsmFrontendModuleAssetRegistry::SWIPER_LIBRARY_STYLE_HANDLE );
		}
		if ( \DiviSupreme\Includes\DsmFrontendAssetRegistry::should_wp_enqueue_module_scripts( 'dsm/image-carousel' ) ) {
			wp_enqueue_script( 'dsm-swiper-library' );
			wp_enqueue_script( 'dsm-image-carousel' );
		}

		$loop_check = 'off' !== $infinite ? 'true' : 'false';

		$slides_per_view        = 'horizontal' === $slider_orientation ? $slide_to_show : $slide_to_row_show;
		$slides_per_view_tablet = 'horizontal' === $slider_orientation ? $slide_to_show_tablet : $slide_to_row_show_tablet;
		$slides_per_view_phone  = 'horizontal' === $slider_orientation ? $slide_to_show_phone : $slide_to_row_show_phone;

		$wp_image_size     = '' !== $sizes ? $sizes : 'large';
		$lightbox_img_size = '' !== $lightbox_img_sizes ? $lightbox_img_sizes : 'full';

		$resolved_phone   = ( '' === (string) $slides_per_view_phone || (int) $slides_per_view_phone < 1 ) ? 1 : (int) $slides_per_view_phone;
		$resolved_tablet  = ( '' === (string) $slides_per_view_tablet || (int) $slides_per_view_tablet < 1 ) ? 2 : (int) $slides_per_view_tablet;
		$resolved_desktop = '' !== $slides_per_view && '' !== (string) $slides_per_view ? (int) $slides_per_view : 4;

		$resolved_slide_row        = 'off' !== $multiple_slide_row ? ( '' !== (string) $slide_row ? $slide_row : '1' ) : '1';
		$resolved_slide_row_tablet = 'off' !== $multiple_slide_row
			? ( '' !== (string) $slide_row_tablet ? $slide_row_tablet : $resolved_slide_row )
			: '1';
		$resolved_slide_row_phone  = 'off' !== $multiple_slide_row
			? ( '' !== (string) $slide_row_phone ? $slide_row_phone : $resolved_slide_row_tablet )
			: '1';

		$carousel_sizes_attr = self::get_carousel_image_sizes_attr( $resolved_phone, $resolved_tablet, $resolved_desktop );

		$image_carousel_data_attr = '';
		$image_carousel_data_attr = sprintf(
			'data-effect="%1$s"
			data-slider-effect-shadows="%2$s"
			data-slider-effect-coverflow-rotate="%3$s"
			data-slider-effect-coverflow-depth="%4$s"
			data-loop="%5$s"
			data-slide-to-show="%6$s"
			data-slide-to-show-tablet="%7$s"
			data-slide-to-show-phone="%8$s"
			data-slide-to-scroll="%9$s"
			data-slide-to-scroll-tablet="%10$s"
			data-slide-to-scroll-phone="%11$s"
			data-space-between="%12$s"
			data-space-between-tablet="%13$s"
			data-space-between-phone="%14$s"
			data-slide-row="%15$s"
			data-centered-slides="%16$s"
			data-speed="%17$s"
			data-autoplay="%18$s"
			data-autoplay-speed="%19$s"
			data-touch-move="%20$s"
			data-grab="%21$s"
			data-pause-on-hover="%22$s"
			data-show-lightbox="%23$s"
			data-lightbox-gallery="%24$s"
			data-lightbox-caption="%25$s"
			data-infinite-scrolling="%26$s"
			data-slide-row-tablet="%27$s"
			data-slide-row-phone="%28$s"
			%29$s
			data-mousewheel="%30$s"
			data-lazyload="%31$s"
			data-type="%32$s"
			data-slideshow-effect="%33$s"
			data-slideshow-to-show="%34$s"
			data-slideshow-to-show-tablet="%35$s"
			data-slideshow-to-show-phone="%36$s"
			data-slider-orientation="%37$s"
						data-lightbox-title="%38$s"

			',
			esc_attr( $slider_effect ),
			'off' !== $slider_effect_shadows ? 'true' : 'false',
			esc_attr( $slider_effect_coverflow_rotate ),
			esc_attr( $slider_effect_coverflow_depth ),
			'off' !== $multiple_slide_row ? 'false' : $loop_check,
			esc_attr( (string) $resolved_desktop ),
			(string) $resolved_tablet,
			(string) $resolved_phone,
			esc_attr( $slide_to_scroll ),
			'' !== $slide_to_scroll_tablet ? $slide_to_scroll_tablet : '1',
			'' !== $slide_to_scroll_phone ? $slide_to_scroll_phone : '1',
			'cube' !== $slider_effect ? $space_between : '0',
			'cube' !== $slider_effect ? $space_between_tablet : '0',
			'cube' !== $slider_effect ? $space_between_phone : '0',
			esc_attr( (string) $resolved_slide_row ),
			'off' !== $centered_slides ? 'true' : 'false',
			esc_attr( $speed ),
			'off' !== $autoplay ? 'true' : 'false',
			esc_attr( $autoplay_speed ),
			'off' !== $touch_move ? 'false' : 'true',
			'off' !== $grab ? 'true' : 'false',
			'off' !== $pause_on_hover ? 'true' : 'false',
			'off' !== $show_lightbox ? 'true' : 'false',
			'off' !== $show_lightbox_gallery ? 'true' : 'false',
			'off' !== $show_lightbox_caption ? 'true' : 'false',
			'on' === $infinite_smooth_scrolling ? 'true' : 'false',
			esc_attr( (string) $resolved_slide_row_tablet ),
			esc_attr( (string) $resolved_slide_row_phone ),
			'off' !== $autoplay && '' !== $autoplay_viewport ? esc_attr( 'data-autoplay-viewport=' . $autoplay_viewport ) : '',
			'off' !== $mousewheel ? 'true' : 'false',
			'off' !== $lazyload ? 'true' : 'false',
			'off' !== $slider_type ? esc_attr( $slider_type ) : 'carousel',
			esc_attr( $slideshow_effect ),
			esc_attr( $slideshow_to_show ),
			'' !== $slideshow_to_show_tablet ? $slideshow_to_show_tablet : $slideshow_to_show,
			'' !== $slideshow_to_show_phone ? $slideshow_to_show_phone : $slideshow_to_show_tablet,
			'carousel' === $slider_type ? $slider_orientation : 'horizontal',
			'off' !== $show_lightbox_title ? 'true' : 'false'
		);

		$slideshow_show_title_val = $attrs['slideshow_show_slide_title']['innerContent']['desktop']['value'] ?? 'off';
		$slideshow_show_desc_val  = $attrs['slideshow_show_slide_description']['innerContent']['desktop']['value'] ?? 'off';

		$slideshow_anim_in_raw  = (string) ( $attrs['slideshow_title_animation']['innerContent']['desktop']['value'] ?? 'fadeInUp' );
		$slideshow_anim_out_raw = (string) ( ( $attrs['slideshow_title_animation_out'] ?? array() )['innerContent']['desktop']['value'] ?? 'fadeOutDown' );
		$slideshow_anim_in_dur  = (string) ( $attrs['slideshow_title_animation_duration']['innerContent']['desktop']['value'] ?? '1000' );
		$slideshow_anim_in_del  = (string) ( $attrs['slideshow_title_animation_delay']['innerContent']['desktop']['value'] ?? '0' );
		$slideshow_anim_out_dur = (string) ( ( $attrs['slideshow_title_animation_out_duration'] ?? array() )['innerContent']['desktop']['value'] ?? '1000' );
		$slideshow_anim_out_del = (string) ( ( $attrs['slideshow_title_animation_out_delay'] ?? array() )['innerContent']['desktop']['value'] ?? '0' );

		$slideshow_desc_anim_in_raw  = (string) ( $attrs['slideshow_description_animation']['innerContent']['desktop']['value'] ?? 'fadeInUp' );
		$slideshow_desc_anim_out_raw = (string) ( ( $attrs['slideshow_description_animation_out'] ?? array() )['innerContent']['desktop']['value'] ?? 'fadeOutDown' );
		$slideshow_desc_anim_in_dur  = (string) ( $attrs['slideshow_description_animation_duration']['innerContent']['desktop']['value'] ?? '1000' );
		$slideshow_desc_anim_in_del  = (string) ( $attrs['slideshow_description_animation_delay']['innerContent']['desktop']['value'] ?? '0' );
		$slideshow_desc_anim_out_dur = (string) ( ( $attrs['slideshow_description_animation_out_duration'] ?? array() )['innerContent']['desktop']['value'] ?? '1000' );
		$slideshow_desc_anim_out_del = (string) ( ( $attrs['slideshow_description_animation_out_delay'] ?? array() )['innerContent']['desktop']['value'] ?? '0' );

		$slideshow_wrap_anim_in_raw  = (string) ( $attrs['slideshow_wrapper_animation_in']['innerContent']['desktop']['value'] ?? 'none' );
		$slideshow_wrap_anim_out_raw = (string) ( ( $attrs['slideshow_wrapper_animation_out'] ?? array() )['innerContent']['desktop']['value'] ?? 'none' );
		$slideshow_wrap_anim_in_dur  = (string) ( $attrs['slideshow_wrapper_animation_in_duration']['innerContent']['desktop']['value'] ?? '1000' );
		$slideshow_wrap_anim_in_del  = (string) ( $attrs['slideshow_wrapper_animation_in_delay']['innerContent']['desktop']['value'] ?? '0' );
		$slideshow_wrap_anim_out_dur = (string) ( ( $attrs['slideshow_wrapper_animation_out_duration'] ?? array() )['innerContent']['desktop']['value'] ?? '1000' );
		$slideshow_wrap_anim_out_del = (string) ( ( $attrs['slideshow_wrapper_animation_out_delay'] ?? array() )['innerContent']['desktop']['value'] ?? '0' );

		if ( 'slideshow' === $slider_type ) {
			$image_carousel_data_attr .= sprintf(
				' data-slideshow-show-slide-title="%1$s" data-slideshow-show-slide-description="%17$s" data-slideshow-title-animation="%2$s" data-slideshow-title-animation-duration="%3$s" data-slideshow-title-animation-delay="%4$s" data-slideshow-title-animation-out="%5$s" data-slideshow-title-animation-out-duration="%6$s" data-slideshow-title-animation-out-delay="%7$s" data-slideshow-description-animation="%8$s" data-slideshow-description-animation-duration="%9$s" data-slideshow-description-animation-delay="%10$s" data-slideshow-description-animation-out="%11$s" data-slideshow-description-animation-out-duration="%12$s" data-slideshow-description-animation-out-delay="%13$s" data-slideshow-wrapper-animation-in="%14$s" data-slideshow-wrapper-animation-in-duration="%15$s" data-slideshow-wrapper-animation-in-delay="%16$s" data-slideshow-wrapper-animation-out="%18$s" data-slideshow-wrapper-animation-out-duration="%19$s" data-slideshow-wrapper-animation-out-delay="%20$s"',
				'on' === $slideshow_show_title_val ? 'true' : 'false',
				esc_attr( $slideshow_anim_in_raw ),
				self::image_carousel_title_anim_format_for_attr( $slideshow_anim_in_dur, '1000' ),
				self::image_carousel_title_anim_format_for_attr( $slideshow_anim_in_del, '0' ),
				esc_attr( $slideshow_anim_out_raw ),
				self::image_carousel_title_anim_format_for_attr( $slideshow_anim_out_dur, '1000' ),
				self::image_carousel_title_anim_format_for_attr( $slideshow_anim_out_del, '0' ),
				esc_attr( $slideshow_desc_anim_in_raw ),
				self::image_carousel_title_anim_format_for_attr( $slideshow_desc_anim_in_dur, '1000' ),
				self::image_carousel_title_anim_format_for_attr( $slideshow_desc_anim_in_del, '0' ),
				esc_attr( $slideshow_desc_anim_out_raw ),
				self::image_carousel_title_anim_format_for_attr( $slideshow_desc_anim_out_dur, '1000' ),
				self::image_carousel_title_anim_format_for_attr( $slideshow_desc_anim_out_del, '0' ),
				esc_attr( $slideshow_wrap_anim_in_raw ),
				self::image_carousel_title_anim_format_for_attr( $slideshow_wrap_anim_in_dur, '1000' ),
				self::image_carousel_title_anim_format_for_attr( $slideshow_wrap_anim_in_del, '0' ),
				'on' === $slideshow_show_desc_val ? 'true' : 'false',
				esc_attr( $slideshow_wrap_anim_out_raw ),
				self::image_carousel_title_anim_format_for_attr( $slideshow_wrap_anim_out_dur, '1000' ),
				self::image_carousel_title_anim_format_for_attr( $slideshow_wrap_anim_out_del, '0' )
			);

			$need_animate = ( '' !== $slideshow_anim_in_raw && 'none' !== $slideshow_anim_in_raw )
				|| ( '' !== $slideshow_anim_out_raw && 'none' !== $slideshow_anim_out_raw )
				|| (
					'on' === $slideshow_show_desc_val
					&& (
						( '' !== $slideshow_desc_anim_in_raw && 'none' !== $slideshow_desc_anim_in_raw )
						|| ( '' !== $slideshow_desc_anim_out_raw && 'none' !== $slideshow_desc_anim_out_raw )
					)
				)
				|| ( '' !== $slideshow_wrap_anim_in_raw && 'none' !== $slideshow_wrap_anim_in_raw )
				|| ( '' !== $slideshow_wrap_anim_out_raw && 'none' !== $slideshow_wrap_anim_out_raw );

			if ( $need_animate ) {
				DsmFrontendDynamicAssets::enqueue_supreme_animate_if_needed( true );
			}
		}

		$slideshow_use_overlay_val = (string) ( $attrs['slideshow_use_overlay']['innerContent']['desktop']['value'] ?? 'off' );

		$slideshow_slide_options = array(
			'show_slide_title'       => $slideshow_show_title_val,
			'show_slide_description' => $slideshow_show_desc_val,
			'title_align_h'          => (string) ( ( $attrs['slideshow_slide_title_align_h'] ?? array() )['innerContent']['desktop']['value'] ?? 'center' ),
			'title_align_v'          => (string) ( ( $attrs['slideshow_slide_title_align_v'] ?? array() )['innerContent']['desktop']['value'] ?? 'center' ),
			'use_slideshow_overlay'  => $slideshow_use_overlay_val,
		);

		// Get gallery item data.
		$attachments = self::get_gallery(
			array(
				'gallery_ids'        => $gallery_ids,
				'gallery_orderby'    => $gallery_orderby,
				'sizes'              => $sizes,
				'lightbox_img_sizes' => $lightbox_img_sizes,
				'slideshow_sizes'    => $slideshow_sizes,
			)
		);

		if ( empty( $attachments ) ) {
			return '';
		}

		$image_output = self::getImageOutput( $attachments, $show_lightbox, $slider_type, $wp_image_size, $lightbox_img_size, $carousel_sizes_attr, $lazyload, $slideshow_slide_options );
		$thumb_output = ( 'slideshow' === $slider_type && 'on' === $slideshow_show_thumbs )
			? self::get_thumbnail_image_output( $attachments, $lazyload )
			: '';

		$gallery_base_args = array(
			'gallery_orderby'    => $gallery_orderby,
			'sizes'              => $sizes,
			'lightbox_img_sizes' => $lightbox_img_sizes,
			'slideshow_sizes'    => $slideshow_sizes,
		);

		$responsive_payload = array();

		if ( $gallery_ids_tablet !== $gallery_ids_desktop && '' !== $gallery_ids_tablet ) {
			$attachments_tablet = self::get_gallery(
				array_merge(
					$gallery_base_args,
					array( 'gallery_ids' => $gallery_ids_tablet )
				)
			);
			if ( ! empty( $attachments_tablet ) ) {
				$responsive_payload['tablet'] = array(
					'main' => self::getImageOutput( $attachments_tablet, $show_lightbox, $slider_type, $wp_image_size, $lightbox_img_size, $carousel_sizes_attr, $lazyload, $slideshow_slide_options ),
				);
				if ( 'slideshow' === $slider_type && 'on' === $slideshow_show_thumbs ) {
					$responsive_payload['tablet']['thumbs'] = self::get_thumbnail_image_output( $attachments_tablet, $lazyload );
				}
			}
		}

		if ( $gallery_ids_phone !== $gallery_ids_desktop && '' !== $gallery_ids_phone ) {
			if ( $gallery_ids_phone === $gallery_ids_tablet && isset( $responsive_payload['tablet'] ) ) {
				$responsive_payload['phone'] = $responsive_payload['tablet'];
			} else {
				$attachments_phone = self::get_gallery(
					array_merge(
						$gallery_base_args,
						array( 'gallery_ids' => $gallery_ids_phone )
					)
				);
				if ( ! empty( $attachments_phone ) ) {
					$responsive_payload['phone'] = array(
						'main' => self::getImageOutput( $attachments_phone, $show_lightbox, $slider_type, $wp_image_size, $lightbox_img_size, $carousel_sizes_attr, $lazyload, $slideshow_slide_options ),
					);
					if ( 'slideshow' === $slider_type && 'on' === $slideshow_show_thumbs ) {
						$responsive_payload['phone']['thumbs'] = self::get_thumbnail_image_output( $attachments_phone, $lazyload );
					}
				}
			}
		}

		$responsive_gallery_script = '';
		if ( ! empty( $responsive_payload ) ) {
			$responsive_gallery_script = sprintf(
				'<script type="application/json" class="dsm-ic-responsive-gallery">%s</script>',
				wp_json_encode(
					$responsive_payload,
					JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT
				)
			);
		}

		$slideshow_classname = 'slideshow' === $slider_type ? 'dsm_image_carousel_slideshow' : '';

		$arrows_html = 'off' !== $arrows && 'off' === $infinite_smooth_scrolling
			? '<div class="swiper-button-prev swiper-arrow-button"></div><div class="swiper-button-next swiper-arrow-button"></div>'
			: '';
		$dots_html   = 'carousel' === $slider_type && 'off' !== $dots && 'off' === $infinite_smooth_scrolling
			? '<div class="swiper-pagination"></div>'
			: '';

		$main_swiper = sprintf(
			'<div class="swiper-container dsm_image_carousel_container %1$s" %2$s dir="%3$s"><div class="swiper-wrapper">%4$s</div></div>',
			esc_attr( $slideshow_classname ),
			$image_carousel_data_attr,
			esc_attr( $slider_direction ),
			$image_output
		);

		$thumbs_html = '';
		if ( 'slideshow' === $slider_type && 'on' === $slideshow_show_thumbs ) {
			$thumbs_html = self::build_slideshow_thumbs_markup(
				$thumb_output,
				$slider_direction,
				(string) $slideshow_thumbs_position
			);
		}

		$tail = $responsive_gallery_script . $arrows_html . $dots_html;

		if ( 'slideshow' === $slider_type && 'on' === $slideshow_show_thumbs && 'top' === $slideshow_thumbs_position ) {
			$container = $thumbs_html . $main_swiper . $tail;
		} else {
			$container = $main_swiper . $tail . $thumbs_html;
		}

		// Module Inner.
		// Essentially, this is the module content.
		// Were wrapping the title and content in a div with class `et_pb_module_inner`.
		$module_inner = HTMLUtility::render(
			array(
				'tag'               => 'div',
				'attributes'        => array(
					'class' => 'et_pb_module_inner',
				),
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $container,
			)
		);

		// This are the module elements that will be rendered in the frontend.
		$module_elements = $elements->style_components(
			array(
				'attrName' => 'module',
			)
		);

		// This are the children of the module container, which are the module elements and the module inner.
		$module_container_children = $module_elements . $module_inner;

		return Module::render(
			array(
				// FE only.
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],
				// VB equivalent.
				'attrs'               => $attrs,
				'elements'            => $elements,
				'id'                  => $block->parsed_block['id'],
				'name'                => $block->block_type->name,
				'classnamesFunction'  => array( self::class, 'module_classnames' ),
				'moduleCategory'      => $block->block_type->category,
				'stylesComponent'     => array( self::class, 'module_styles' ),
				'scriptDataComponent' => array( self::class, 'module_script_data' ),
				'children'            => $module_container_children,
			)
		);
	}
}
