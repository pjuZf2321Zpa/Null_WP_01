<?php
/**
 * Circle Info Module.
 *
 * @package DiviSupreme.
 */

declare(strict_types=1);

namespace DiviSupreme\Modules;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}


use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\Module\Options\Element\ElementClassnames;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use ET\Builder\Packages\Module\Options\Text\TextStyle;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\ModuleUtils\ModuleUtils;
use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;
use DiviSupreme\Extensions\IconLibraries\IconModuleRenderBridge;
use DiviSupreme\Extensions\IconLibraries\LegacyModuleIconStyles;
use DiviSupreme\Includes\Divi5Conversion\ConversionAttrs;
use DiviSupreme\Includes\DsmFrontendDynamicAssets;
use DiviSupreme\Includes\ModuleRegisterAttrsNormalize;
use DiviSupreme\Includes\UploadImageMarkup;
use DiviSupreme\Utils\HeadingLevel;


/**
 * Class that handles "CircleInfo Module" module.
 */
class CircleInfo implements DependencyInterface {



	/**
	 * Register module.
	 * `DependencyInterface` interface ensures class method name `load()` is executed for initialization.
	 */
	public function load() {
		add_filter(
			'divi_module_library_register_module_attrs',
			array( self::class, 'filter_register_module_attrs' ),
			10,
			2
		);
		add_action( 'init', array( self::class, 'register_module' ) );
	}

	/**
	 * Normalize migrated parent layout attrs so orbit transform CommonStyle rules print.
	 *
	 * @param array<string, mixed> $module_attrs Merged module attrs.
	 * @param array<string, mixed> $filter_args  Filter context.
	 * @return array<string, mixed>
	 */
	public static function filter_register_module_attrs( $module_attrs, $filter_args ) {
		if ( ! is_array( $module_attrs ) || ! is_array( $filter_args ) ) {
			return is_array( $module_attrs ) ? $module_attrs : array();
		}

		if ( 'dsm/circle-info' !== ( $filter_args['name'] ?? '' ) ) {
			return $module_attrs;
		}

		ModuleRegisterAttrsNormalize::circle_info_merged( $module_attrs );

		return $module_attrs;
	}

	/**
	 * Initilises the module.
	 *
	 * @return void
	 */
	public static function dsm_initialise() {
		add_action(
			'divi_module_library_modules_dependency_tree',
			function ( $dependency_tree ) {
				$dependency_tree->add_dependency( new self() );
			}
		);
	}

	/**
	 * Register module.
	 */
	public static function register_module() {

		$module_json_path = DSM_DIR_PATH . 'divi-5/public/packages/module-library/circle-info';

		ModuleRegistration::register_module(
			$module_json_path,
			array(
				'render_callback' => array( self::class, 'render_callback' ),
			)
		);
	}


	/**
	 * Icon style declaration.
	 *
	 * @param mixed $params Params.
	 */
	public static function icon_style_declaration( $params ) {
		return LegacyModuleIconStyles::build_pseudo_icon_declaration( $params );
	}


	/**
	 * Dir icon style declaration.
	 *
	 * @param mixed $params Params.
	 */
	public static function dir_icon_style_declaration( $params ) {
		return LegacyModuleIconStyles::build_pseudo_icon_declaration( $params );
	}

	/**
	 * Circle button rotate.
	 *
	 * @param mixed $params Params.
	 */
	public static function circle_button_rotate( $params ) {
		unset( $params );

		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
				'important'  => array(
					'transform' => true,
				),
			)
		);

		$style_declarations->add( 'transform', 'rotate(calc(var(--dsm-angle) * 1deg))' );

		return $style_declarations->value();
	}

	/**
	 * Render module style.
	 *
	 * @param array     $args - Arguments.
	 * @param \WP_Block $block - Block.
	 */
	public static function module_styles( $args, $block ) {

		$args  = \DiviSupreme\Includes\DsmDiviBuilderCssScope::normalize_module_styles_args( $args );
		$attrs = $args['attrs'] ?? array();
		ConversionAttrs::ensure_circle_info_parent_layout_inner_content_defaults( $attrs );
		$circle_size_style_attr = ConversionAttrs::circle_info_inner_content_for_style_output(
			$attrs,
			'dsm_circle_size',
			'500px'
		);
		$speed_style_attr       = ConversionAttrs::circle_info_inner_content_for_style_output(
			$attrs,
			'dsm_speed',
			'1s'
		);
		$elements               = $args['elements'];

		$circle_size_auto = $attrs['dsm_circle_size_auto']['innerContent']['desktop']['value'] ?? 'off';

		$inner_blocks           = $block->parsed_block['innerBlocks'] ?? array();
		$dsm_badge_use_position = $attrs['dsm_badge_use_position']['innerContent']['desktop']['value'] ?? '';
		$total_item_count       = count( $inner_blocks );

		$angle = '';
		if ( $total_item_count ) {
			$angle = ( 360 / $total_item_count );
		}

		$rot = $angle;

		$styles = array(
			// Module.
			$elements->style(
				array(
					'attrName'   => 'module',
					'styleProps' => array(
						'disabledOn' => array(
							'disabledModuleVisibility' => $args['settings']['disabledModuleVisibility'] ?? null,
						),
					),
				)
			),

			TextStyle::style(
				array(
					'selector' => $args['orderClass'],
					'attr'     => $attrs['module']['advanced']['text'] ?? array(),
				)
			),

			$elements->style(
				array(
					'attrName' => 'header',
				)
			),

			$elements->style(
				array(
					'attrName' => 'dsm_content',
				)
			),

			$elements->style(
				array(
					'attrName' => 'circle_style',
				)
			),

			$elements->style(
				array(
					'attrName' => 'circle_normal_item_style',
				)
			),

			$elements->style(
				array(
					'attrName' => 'circle_title',
				)
			),

			$elements->style(
				array(
					'attrName' => 'dsm_content_padding',
				)
			),

			$elements->style(
				array(
					'attrName' => 'content_general_style',
				)
			),

			$elements->style(
				array(
					'attrName' => 'image_style',
				)
			),

			$elements->style(
				array(
					'attrName' => 'dsm_content_icon_margin',
				)
			),

			$elements->style(
				array(
					'attrName' => 'dsm_content_icon_padding',
				)
			),

			$elements->style(
				array(
					'attrName' => 'content_icon_style',
				)
			),

			$elements->style(
				array(
					'attrName' => 'content_image_style',
				)
			),

			$elements->style(
				array(
					'attrName' => 'dsm_icon_margin',
				)
			),

			$elements->style(
				array(
					'attrName' => 'dsm_icon_padding',
				)
			),

			$elements->style(
				array(
					'attrName' => 'icon_style',
				)
			),

			$elements->style(
				array(
					'attrName' => 'image_style',
				)
			),

			$elements->style(
				array(
					'attrName' => 'circle_active_item_style',
				)
			),

			$elements->style(
				array(
					'attrName' => 'button',
				)
			),

			CommonStyle::style(
				array(
					'selector' => "{$args['orderClass']} .dsm-circle-info-button-wrapper",
					'attr'     => $attrs['dsm_circle_item_size']['innerContent'] ?? array(),
					'property' => 'width',
				)
			),

			CommonStyle::style(
				array(
					'selector' => "{$args['orderClass']} .dsm-circle-info-button-wrapper",
					'attr'     => $attrs['dsm_circle_item_size']['innerContent'] ?? array(),
					'property' => 'height',
				)
			),

			CommonStyle::style(
				array(
					'selector' => "{$args['orderClass']} .dsm-circle-info-button-wrapper",
					'attr'     => $attrs['dsm_circle_bg_color']['innerContent'] ?? array(),
					'property' => 'background',
				)
			),

			CommonStyle::style(
				array(
					'selector' => "{$args['orderClass']} .dsm-circle-info-button-wrapper",
					'attr'     => $attrs['dsm_circle_color']['innerContent'] ?? array(),
					'property' => 'color',
				)
			),

			CommonStyle::style(
				array(
					'selector' => "{$args['orderClass']} .dsm-circle-info-item-inner-wrapper.dsm-circle-info-item-active .dsm-circle-info-button-wrapper",
					'attr'     => $attrs['dsm_circle_active_bg_color']['innerContent'] ?? array(),
					'property' => 'background',
				)
			),

			CommonStyle::style(
				array(
					'selector' => "{$args['orderClass']} .dsm-circle-info-item-inner-wrapper.dsm-circle-info-item-active .dsm-circle-info-button-wrapper",
					'attr'     => $attrs['dsm_circle_active_color']['innerContent'] ?? array(),
					'property' => 'color',
				)
			),

			CommonStyle::style(
				array(
					'selector' => "{$args['orderClass']} .dsm_content_icon",
					'attr'     => $attrs['dsm_content_icon_font_size']['innerContent'] ?? array(),
					'property' => 'font-size',
				)
			),

			CommonStyle::style(
				array(
					'selector' => "{$args['orderClass']} .dsm_content_icon",
					'attr'     => $attrs['dsm_content_icon_bg_color']['innerContent'] ?? array(),
					'property' => 'background-color',
				)
			),

			CommonStyle::style(
				array(
					'selector' => "{$args['orderClass']} .dsm_content_icon",
					'attr'     => $attrs['dsm_content_icon_color']['innerContent'] ?? array(),
					'property' => 'color',
				)
			),

			CommonStyle::style(
				array(
					'selector' => "{$args['orderClass']} .dsm_icon",
					'attr'     => $attrs['dsm_icon_font_size']['innerContent'] ?? array(),
					'property' => 'font-size',
				)
			),

			CommonStyle::style(
				array(
					'selector' => "{$args['orderClass']} .dsm_icon",
					'attr'     => $attrs['dsm_icon_bg_color']['innerContent'] ?? array(),
					'property' => 'background-color',
				)
			),

			CommonStyle::style(
				array(
					'selector' => "{$args['orderClass']} .dsm_icon",
					'attr'     => $attrs['dsm_icon_color']['innerContent'] ?? array(),
					'property' => 'color',
				)
			),

			CommonStyle::style(
				array(
					'selector' => "{$args['orderClass']} .dsm-circle-info-button .dsm-circle-info-item-inner-wrapper.dsm-circle-info-item-active .dsm_icon",
					'attr'     => $attrs['dsm_icon_active_bg_color']['innerContent'] ?? array(),
					'property' => 'background-color',
				)
			),

			CommonStyle::style(
				array(
					'selector' => "{$args['orderClass']} .dsm-circle-info-button .dsm-circle-info-item-inner-wrapper.dsm-circle-info-item-active .dsm_icon",
					'attr'     => $attrs['dsm_icon_active_color']['innerContent'] ?? array(),
					'property' => 'color',
				)
			),

			CommonStyle::style(
				array(
					'selector' => "{$args['orderClass']} .dsm-circle-info-button-wrapper .dsm-circle-info-inner img",
					'attr'     => $attrs['dsm_circle_image_width']['innerContent'] ?? array(),
					'property' => 'max-width',
				)
			),

			CommonStyle::style(
				array(
					'selector' => "{$args['orderClass']} .dsm-image img",
					'attr'     => $attrs['dsm_content_image_width']['innerContent'] ?? array(),
					'property' => 'width',
				)
			),

			CommonStyle::style(
				array(
					'selector' => "{$args['orderClass']} .dsm-circle-info-container.dsm_animate .dsm-circle-info-button, {$args['orderClass']} .dsm-circle-info-container.dsm_animate .dsm-circle-info-button .dsm-circle-info-item-inner-wrapper",
					'attr'     => $speed_style_attr,
					'property' => 'transition-duration',
				)
			),

			CommonStyle::style(
				array(
					'selector'            => "{$args['orderClass']} .dsm-circle-info-button",
					'attr'                => $speed_style_attr,
					'declarationFunction' => array( static::class, 'circle_button_rotate' ),
				)
			),
		);

		if ( 'on' !== $circle_size_auto ) {
			$styles[] = CommonStyle::style(
				array(
					'selector' => "{$args['orderClass']} .dsm-circle-info-container",
					'attr'     => $circle_size_style_attr,
					'property' => '--main-circle-size',
				)
			);
		}

		for ( $item_count = 1; $item_count <= $total_item_count; $item_count++ ) {
			$styles[] = CommonStyle::style(
				array(
					'selector'            => "{$args['orderClass']} .dsm-circle-info-item-inner-wrapper:nth-child($item_count)",
					'attr'                => $circle_size_style_attr,
					'declarationFunction' => function ( $params ) use ( $rot ) {
						unset( $params );
						$style_declarations = new StyleDeclarations(
							array(
								'returnType' => 'string',
								'important'  => array(
									'transform' => true,
								),
							)
						);

						$style_declarations->add(
							'transform',
							sprintf(
								'rotate(calc(%1$s * 1deg)) translate(calc(var(--main-circle-size, 500px) / 2)) rotate(calc((%1$s + var(--dsm-angle)) * -1deg))',
								$rot
							)
						);

						return $style_declarations->value();
					},
				)
			);

			$rot = $rot + $angle;
		}

		Style::add(
			array(
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => $styles,
			),
		);
	}

	/**
	 * Render module script data.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_script_data( $args ) {
		$elements = $args['elements'];

		// Element Script Data Options.
		$elements->script_data(
			array(
				'attrName' => 'module',
			)
		);
	}

	/**
	 * Render module classnames.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_classnames( $args ) {
		$classnames_instance = $args['classnamesInstance'];
		$attrs               = $args['attrs'];

		// Module.
		$classnames_instance->add(
			ElementClassnames::classnames(
				array(
					'attrs' => $attrs['module']['decoration'] ?? array(),
				)
			)
		);
	}

	/**
	 * Read TextContainer / RichText `innerContent.desktop.value` (string or `{ text: string }`).
	 *
	 * @param array  $child_attrs Child block attrs.
	 * @param string $attr_key    Attribute key.
	 * @param string $fallback    Default when missing.
	 * @return string
	 */
	private static function circle_info_child_inner_text_leaf( array $child_attrs, string $attr_key, string $fallback = '' ) {
		$desktop = $child_attrs[ $attr_key ]['innerContent']['desktop'] ?? null;
		if ( ! is_array( $desktop ) ) {
			return $fallback;
		}

		$v = $desktop['value'] ?? null;
		if ( is_string( $v ) ) {
			return $v;
		}
		if ( is_array( $v ) && isset( $v['text'] ) && is_string( $v['text'] ) ) {
			return $v['text'];
		}

		// D4→D5 migrator outline `*.innerContent.*.text` can leave `text` on desktop with no `value`.
		if ( isset( $desktop['text'] ) && is_string( $desktop['text'] ) ) {
			return $desktop['text'];
		}

		return $fallback;
	}

	/**
	 * Read UploadContainer `innerContent.desktop.value` (URL string or `{ src, id }`).
	 *
	 * @param array  $child_attrs Child block attrs.
	 * @param string $attr_key    Attribute key.
	 * @param mixed  $fallback    Default when missing.
	 * @return mixed
	 */
	private static function circle_info_child_upload_raw_leaf( array $child_attrs, string $attr_key, $fallback = '' ) {
		$v = $child_attrs[ $attr_key ]['innerContent']['desktop']['value'] ?? null;
		if ( is_string( $v ) || is_array( $v ) ) {
			return $v;
		}

		return $fallback;
	}

	/**
	 * Read UploadContainer `innerContent.desktop.value` (URL string or `{ src: string }`).
	 *
	 * @param array  $child_attrs Child block attrs.
	 * @param string $attr_key    Attribute key.
	 * @param string $fallback    Default when missing.
	 * @return string
	 */
	private static function circle_info_child_upload_src_leaf( array $child_attrs, string $attr_key, string $fallback = '' ) {
		$src = UploadImageMarkup::resolve_upload_src_string(
			self::circle_info_child_upload_raw_leaf( $child_attrs, $attr_key, '' )
		);

		return $src ? $src : $fallback;
	}

	/**
	 * Read IconPicker `innerContent.desktop.value` object.
	 *
	 * @param array  $child_attrs Child block attrs.
	 * @param string $attr_key    Attribute key.
	 * @return array<string, mixed>|null
	 */
	private static function circle_info_child_icon_leaf( array $child_attrs, string $attr_key ): ?array {
		$value = $child_attrs[ $attr_key ]['innerContent']['desktop']['value'] ?? null;

		return is_array( $value ) ? $value : null;
	}

	/**
	 * Match D4 / Divi FE: child wrapper uses full order class (e.g. et_pb_dsm_circle_info_child_0), not a ad-hoc id suffix.
	 *
	 * @param array<string, mixed> $child          Parsed inner block.
	 * @param int|null             $store_instance Parent block store instance.
	 * @return string
	 */
	private static function circle_info_child_order_class( array $child, $store_instance ) {
		$child_id = isset( $child['id'] ) && is_string( $child['id'] ) ? $child['id'] : '';
		if ( '' !== $child_id && null !== $store_instance ) {
			$order_class = ModuleUtils::get_module_order_class_name( $child_id, $store_instance );
			if ( is_string( $order_class ) && '' !== $order_class ) {
				return $order_class;
			}
		}

		$base = ModuleUtils::get_module_order_class_name_base( 'dsm/circle-info-child' );
		$idx  = isset( $child['orderIndex'] ) && is_numeric( $child['orderIndex'] ) ? (int) $child['orderIndex'] : 0;

		return '' !== $base ? $base . '_' . $idx : 'et_pb_dsm_circle_info_child_' . $idx;
	}

	/**
	 * Render module HTML output.
	 *
	 * @param array     $attrs - Modules Attributes.
	 * @param string    $content - Content.
	 * @param \WP_Block $block - Block.
	 * @param mixed     $elements - Elements.
	 */
	public static function render_callback( $attrs, $content, $block, $elements ) {

		$parent       = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );
		$parent_attrs = $parent->attrs ?? array();

		$dsm_circle_size_auto  = $attrs['dsm_circle_size_auto']['innerContent']['desktop']['value'] ?? 'off';
		$circle_auto_class     = ( 'on' === $dsm_circle_size_auto ) ? ' dsm-circle-info-size-auto' : '';
		$dsm_enable_autoplay   = $attrs['dsm_enable_autoplay']['innerContent']['desktop']['value'] ?? 'off';
		$dsm_trigger           = $attrs['dsm_trigger']['innerContent']['desktop']['value'] ?? 'click';
		$dsm_delay             = $attrs['dsm_delay']['innerContent']['desktop']['value'] ?? '3000';
		$dsm_content_animation = $attrs['dsm_content_animation']['innerContent']['desktop']['value'] ?? 'fadeIn';
		$parent_heading_level  = HeadingLevel::sanitize(
			$attrs['header']['decoration']['font']['font']['desktop']['value']['headingLevel'] ?? 'h4',
			'h4'
		);

		wp_enqueue_script( 'dsm-circle-info' );
		if ( '' !== $dsm_content_animation && 'none' !== $dsm_content_animation ) {
			DsmFrontendDynamicAssets::enqueue_supreme_animate_if_needed( true );
		}
		$inner_blocks   = $block->parsed_block['innerBlocks'] ?? array();
		$store_instance = $block->parsed_block['storeInstance'] ?? null;

		$parsed_module_id = isset( $block->parsed_block['id'] ) ? (string) $block->parsed_block['id'] : 'ci';
		$a11y_base_id     = 'dsm-ci-' . preg_replace( '/[^a-zA-Z0-9_-]/', '-', $parsed_module_id );
		$tablist_label    = esc_attr__( 'Circle items', 'dsm-supreme-modules-pro-for-divi' );

		// BlockParser duplicates loop-enabled children before this callback; empty
		// queries leave a single child marked `__loop_no_results` (see LoopUtils).
		$renderable_inner_blocks = array();
		foreach ( $inner_blocks as $child ) {
			$child_attrs = isset( $child['attrs'] ) && is_array( $child['attrs'] ) ? $child['attrs'] : array();
			if ( ! empty( $child_attrs['__loop_no_results'] ) ) {
				continue;
			}
			$renderable_inner_blocks[] = $child;
		}

		$primary_active_idx = 0;
		foreach ( $renderable_inner_blocks as $idx => $child ) {
			$ca = $child['attrs'] ?? array();
			if ( 'on' === ( $ca['dsm_active_item_default']['innerContent']['desktop']['value'] ?? 'off' ) ) {
				$primary_active_idx = (int) $idx;
			}
		}

		$circle_info_button_content = '';
		foreach ( $renderable_inner_blocks as $idx => $child ) {
			$child_attrs       = $child['attrs'] ?? array();
			$child_order_class = self::circle_info_child_order_class( $child, $store_instance );
			$title             = self::circle_info_child_inner_text_leaf( $child_attrs, 'dsm_circle_info_title', 'Title' );
			$image_raw         = self::circle_info_child_upload_raw_leaf( $child_attrs, 'image', '' );
			$img_alt           = self::circle_info_child_inner_text_leaf( $child_attrs, 'alt', '' );
			$dsm_show_icon     = $child_attrs['dsm_show_icon']['innerContent']['desktop']['value'] ?? 'off';

			$is_tab_active    = ( $idx === $primary_active_idx );
			$tab_active_class = $is_tab_active ? 'dsm-circle-info-item-active' : '';
			$tab_id           = $a11y_base_id . '-tab-' . $idx;
			$panel_id         = $a11y_base_id . '-panel-' . $idx;
			$aria_selected    = $is_tab_active ? 'true' : 'false';
			$tabindex         = $is_tab_active ? '0' : '-1';

			$button_image_markup = '';
			if ( 'on' !== $dsm_show_icon ) {
				$button_image_markup = UploadImageMarkup::render_img_html(
					$image_raw,
					$img_alt,
					array(
						'class' => 'dsm_circle_info_image',
					)
				);
			}

			$icon_markup = '';
			if ( 'on' === $dsm_show_icon ) {
				$icon_markup = IconModuleRenderBridge::render_icon_host_markup(
					self::circle_info_child_icon_leaf( $child_attrs, 'font_icon' ),
					array( 'dsm_icon' )
				);
			}
			$title_span = '' !== $title ? sprintf( '<span class="dsm_text">%1$s</span>', esc_html( $title ) ) : '<span class="dsm_text"></span>';

			$circle_info_button_content .= sprintf(
				'<div class="dsm-circle-info-item-inner-wrapper %1$s %2$s">
					<button type="button" class="dsm-circle-info-button-wrapper" id="%3$s" role="tab" aria-selected="%4$s" aria-controls="%5$s" tabindex="%6$s">
						<span class="dsm-circle-info-inner">
							%7$s
							%8$s
							%9$s
						</span>
					</button>
				</div>',
				esc_attr( $child_order_class ),
				esc_attr( $tab_active_class ),
				esc_attr( $tab_id ),
				esc_attr( $aria_selected ),
				esc_attr( $panel_id ),
				esc_attr( $tabindex ),
				$button_image_markup,
				$icon_markup,
				$title_span
			);
		}

		$circle_info_content = '';
		foreach ( $renderable_inner_blocks as $idx => $child ) {
			$child_attrs             = $child['attrs'] ?? array();
			$child_order_class       = self::circle_info_child_order_class( $child, $store_instance );
			$title                   = self::circle_info_child_inner_text_leaf( $child_attrs, 'dsm_content_title', '' );
			$dsm_circle_info_content = self::circle_info_child_inner_text_leaf(
				$child_attrs,
				'dsm_circle_info_content',
				''
			);
			$dsm_content_image_raw   = self::circle_info_child_upload_raw_leaf( $child_attrs, 'dsm_content_image', '' );
			$dsm_content_show_icon   = $child_attrs['dsm_content_show_icon']['innerContent']['desktop']['value'] ?? 'off';
			$button_text             = self::circle_info_child_inner_text_leaf( $child_attrs, 'button_text', '' );
			$button_url              = self::circle_info_child_inner_text_leaf( $child_attrs, 'button_url', '' );
			$button_url_new_window   = $child_attrs['button_url_new_window']['innerContent']['desktop']['value'] ?? '';
			$dsm_content_type        = $child_attrs['dsm_content_type']['innerContent']['desktop']['value'] ?? 'content';
			$shortcode_content       = self::circle_info_child_inner_text_leaf( $child_attrs, 'shortcode_content', '' );
			$heading_level           = $child_attrs['header']['decoration']['font']['font']['desktop']['value']['headingLevel'] ?? 'h4';
			if ( is_string( $heading_level ) && '' === $heading_level ) {
				$heading_level = $parent_heading_level;
			} else {
				$heading_level = HeadingLevel::sanitize( $heading_level, 'h4' );
			}

			// D4 `ET_Builder_Element::render_button()` — wrapper `et_pb_button_wrapper`, classes `et_pb_button dsm_button`.
			$button_markup = sprintf(
				'<div class="et_pb_button_wrapper">
				  <a %2$s %3$s class="et_pb_button dsm_button">%1$s</a>
				</div>',
				esc_html( $button_text ),
				'' !== $button_url ? sprintf( 'href="%1$s" ', esc_url( $button_url ) ) : '',
				'on' === $button_url_new_window ? 'target="_blank" rel="noopener noreferrer" ' : ''
			);

			$heading_tag  = $heading_level;
			$title_markup = '';
			if ( 'content' === $dsm_content_type && '' !== $title ) {
				$title_markup = sprintf(
					'<%1$s class="dsm-title">%2$s</%1$s>',
					esc_attr( $heading_tag ),
					esc_html( $title )
				);
			}

			$description_markup = '';
			if ( 'content' === $dsm_content_type && '' !== $dsm_circle_info_content ) {
				$description_markup = sprintf(
					'<div class="dsm-circle-info-description">%1$s</div>',
					wp_kses_post( $dsm_circle_info_content )
				);
			}

			$content_image_markup = '';
			if ( 'content' === $dsm_content_type && 'on' !== $dsm_content_show_icon ) {
				$content_image_alt = '' !== $title ? $title : '';
				$content_img       = UploadImageMarkup::render_img_html(
					$dsm_content_image_raw,
					$content_image_alt
				);
				if ( '' !== $content_img ) {
					$content_image_markup = sprintf(
						'<div class="dsm-image">%s</div>',
						$content_img
					);
				}
			}

			$icon_span = '';
			if ( 'content' === $dsm_content_type && 'on' === $dsm_content_show_icon ) {
				$icon_span = IconModuleRenderBridge::render_icon_host_markup(
					self::circle_info_child_icon_leaf( $child_attrs, 'dsm_font_icon' ),
					array( 'dsm_content_icon' )
				);
			}

			$is_panel_active    = ( $idx === $primary_active_idx );
			$panel_active_class = $is_panel_active ? 'dsm-circle-info-item-active' : '';
			$tab_ref_id         = $a11y_base_id . '-tab-' . $idx;
			$panel_ref_id       = $a11y_base_id . '-panel-' . $idx;

			$panel_inner = $content_image_markup . $icon_span . $title_markup . $description_markup;
			if ( 'content' === $dsm_content_type && '' !== $button_text ) {
				$panel_inner .= $button_markup;
			}
			if ( 'shortcode' === $dsm_content_type ) {
				$panel_inner .= \DiviSupreme\Includes\DiviLibraryLayoutRenderer::render_shortcode_field_content(
					is_string( $shortcode_content ) ? $shortcode_content : '',
					'dsm_circle_info_shortcode_styles'
				);
			}

			$panel_open = '<div class="dsm-circle-info-content-wrapper ' . esc_attr( $child_order_class );
			if ( '' !== $panel_active_class ) {
				$panel_open .= ' ' . esc_attr( $panel_active_class );
			}
			$panel_open .= '" id="' . esc_attr( $panel_ref_id ) . '" role="tabpanel" aria-labelledby="' . esc_attr( $tab_ref_id ) . '"';
			if ( ! $is_panel_active ) {
				$panel_open .= ' hidden';
			}
			$panel_open .= '><div class="dsm-circle-info-content-inner-wrapper">' . $panel_inner . '</div></div>';

			$circle_info_content .= $panel_open;
		}

		$total_item_count = count( $renderable_inner_blocks );
		$angle            = '';
		if ( $total_item_count ) {
			$angle = ( 360 / $total_item_count );
		}

		$rot = $angle;

		// D4 parent `render()` outputs only built button/content markup — never raw `$content`.
		// After D4→D5 migration, block `innerHTML` can still contain legacy `[dsm_circle_info_child …]` strings;
		// appending `$content` would print them on the frontend. Children are fully rendered from `innerBlocks` above.
		$container = sprintf(
			'<div class="dsm-circle-info-container dsm_animate%7$s" data-circle-size-auto="%8$s" data-updateangle="%9$s" data-autoplay="%3$s" style="--dsm-angle: 0;" data-trigger="%4$s" data-delay="%5$s" data-animation="%6$s">
			  <div class="dsm-circle-info-button" role="tablist" aria-label="%10$s">%1$s</div>
			  <div class="dsm-circle-info-content">%2$s</div>
			</div>
			',
			$circle_info_button_content,
			$circle_info_content,
			$dsm_enable_autoplay,
			$dsm_trigger,
			$dsm_delay,
			$dsm_content_animation,
			esc_attr( $circle_auto_class ),
			esc_attr( $dsm_circle_size_auto ),
			esc_attr( (string) $angle ),
			$tablist_label
		);

		// Module Inner.
		// Essentially, this is the module content.
		// Were wrapping the title and content in a div with class `et_pb_module_inner`.
		$module_inner = HTMLUtility::render(
			array(
				'tag'               => 'div',
				'attributes'        => array(
					'class' => 'et_pb_module_inner',
				),
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $container,
			)
		);

		// This are the module elements that will be rendered in the frontend.
		$module_elements = $elements->style_components(
			array(
				'attrName' => 'module',
			)
		);

		// This are the children of the module container, which are the module elements and the module inner.
		$module_container_children = $module_elements . $module_inner;

		return Module::render(
			array(
				// FE only.
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],
				// VB equivalent.
				'attrs'               => $attrs,
				'elements'            => $elements,
				'id'                  => $block->parsed_block['id'],
				'moduleClassName'     => 'dsm_circle_info',
				'name'                => $block->block_type->name,
				'classnamesFunction'  => array( self::class, 'module_classnames' ),
				'moduleCategory'      => $block->block_type->category,
				'stylesComponent'     => function ( $args ) use ( $block ) {
					return self::module_styles( $args, $block );
				},
				'scriptDataComponent' => array( self::class, 'module_script_data' ),
				'children'            => $module_container_children,
			)
		);
	}
}
