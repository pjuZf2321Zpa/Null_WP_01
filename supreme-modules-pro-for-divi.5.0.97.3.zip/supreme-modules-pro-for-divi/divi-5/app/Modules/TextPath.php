<?php
/**
 * Text Path Module.
 *
 * @package DiviSupreme.
 */

declare(strict_types=1);

namespace DiviSupreme\Modules;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}


use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\Module\Options\Element\ElementClassnames;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use ET\Builder\Packages\Module\Options\Text\TextStyle;
use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;
use ET\Builder\Packages\Module\Options\Css\CssStyle;


/**
 * Class that handles "Text Path Module" module.
 */
class TextPath implements DependencyInterface {



	/**
	 * Extract color value from either hex or variable format.
	 *
	 * @param string $color_value The color value to process.
	 * @return string The processed color value.
	 */
	private static function extract_color_value( $color_value ) {
		// Check if the color value is in variable format.
		if ( strpos( $color_value, '$variable' ) === 0 ) {
			// Extract the variable data.
			$variable_data = substr( $color_value, 10, -2 ); // Remove $variable( and )$.
			$decoded_data  = json_decode( $variable_data, true );

			// Return the variable name if it exists.
			if ( isset( $decoded_data['value']['name'] ) ) {
				return 'var(--' . $decoded_data['value']['name'] . ')';
			}
		}

		// Return the original value if it's a hex color or invalid format.
		return $color_value;
	}

	/**
	 * Register module.
	 * `DependencyInterface` interface ensures class method name `load()` is executed for initialization.
	 */
	public function load() {
		add_action( 'init', array( self::class, 'register_module' ) );
	}

	/**
	 * Initilises the module.
	 *
	 * @return void
	 */
	public static function dsm_initialise() {
		add_action(
			'divi_module_library_modules_dependency_tree',
			function ( $dependency_tree ) {
				$dependency_tree->add_dependency( new self() );
			}
		);
	}

	/**
	 * Register module.
	 */
	public static function register_module() {

		$module_json_path = DSM_DIR_PATH . 'divi-5/public/packages/module-library/text-path';

		ModuleRegistration::register_module(
			$module_json_path,
			array(
				'render_callback' => array( self::class, 'render_callback' ),
			)
		);
	}

	/**
	 * Path rotate declaration.
	 *
	 * @param mixed $params Params.
	 */
	public static function path_rotate_declaration( $params ) {
		$raw  = $params['attrValue'] ?? '';
		$attr = ( is_string( $raw ) && '' !== trim( $raw ) ) ? $raw : '0deg';

		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
				'important'  => array(
					'transform' => true,
				),
			)
		);

		$style_declarations->add( 'transform', "rotate($attr)" );

		return $style_declarations->value();
	}

	/**
	 * Render module style.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_styles( $args ) {
		$args     = \DiviSupreme\Includes\DsmDiviBuilderCssScope::normalize_module_styles_args( $args );
		$attrs    = $args['attrs'] ?? array();
		$elements = $args['elements'];

		Style::add(
			array(
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => array(
					// Module.
					$elements->style(
						array(
							'attrName'   => 'module',
							'styleProps' => array(
								'disabledOn' => array(
									'disabledModuleVisibility' => $args['settings']['disabledModuleVisibility'] ?? null,
								),
							),
						)
					),

					CssStyle::style(
						array(
							'selector' => $args['orderClass'],
							'attr'     => $attrs['css'] ?? array(),
						)
					),

					TextStyle::style(
						array(
							'selector' => $args['orderClass'],
							'attr'     => $attrs['module']['advanced']['text'] ?? array(),
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_path_text',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-text-path-container",
							'attr'     => $attrs['dsm_path_alignment']['innerContent'] ?? array(),
							'property' => 'text-align',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-text-path-container svg",
							'attr'     => $attrs['dsm_text_path_size']['innerContent'] ?? array(),
							'property' => 'width',
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm-text-path-container svg",
							'attr'                => $attrs['dsm_path_rotate']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'path_rotate_declaration' ),
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-text-path-container svg",
							'attr'     => $attrs['dsm_path_word_spacing']['innerContent'] ?? array(),
							'property' => 'word-spacing',
						)
					),
				),
			)
		);
	}

	/**
	 * Render module script data.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_script_data( $args ) {
		$elements = $args['elements'];

		// Element Script Data Options.
		$elements->script_data(
			array(
				'attrName' => 'module',
			)
		);
	}

	/**
	 * Render module classnames.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_classnames( $args ) {
		$classnames_instance = $args['classnamesInstance'];
		$attrs               = $args['attrs'];

		// Module.
		$classnames_instance->add(
			ElementClassnames::classnames(
				array(
					'attrs' => $attrs['module']['decoration'] ?? array(),
				)
			)
		);
	}


	/**
	 * Process custom path.
	 *
	 * @param mixed $content     Content.
	 * @param mixed $order_class Order class.
	 */
	public static function process_custom_path( $content, $order_class ) {

		if ( '' === trim( $content ) ) {
			return '';
		}

		$document = new \DOMDocument();

		libxml_use_internal_errors( true );

		$document->loadXML( $content );

		libxml_clear_errors();

		$svg = $document->getElementsByTagName( 'svg' )->item( 0 );

		$svg_width  = $svg->getAttribute( 'width' );
		$svg_height = $svg->getAttribute( 'height' );

		$inner_html = static::get_inner_html( $svg );

		return array(
			$svg_width,
			$svg_height,
			str_replace( '<path', sprintf( '<path id="%1$s"', $order_class ), $inner_html ),
		);
	}

	/**
	 * Get inner HTML.
	 *
	 * @param mixed $node   Node.
	 */
	public static function get_inner_html( $node ) {
		$inner_html = '';
		$children   = $node->childNodes; // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- External object property.
		foreach ( $children as $child ) {
			$inner_html .= $child->ownerDocument->saveXML( $child ); // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- External object property.
		}

		return $inner_html;
	}

	/**
	 * Render module HTML output.
	 *
	 * @param array     $attrs - Modules Attributes.
	 * @param string    $content - Content.
	 * @param \WP_Block $block - Block.
	 * @param mixed     $elements - Elements.
	 */
	public static function render_callback( $attrs, $content, $block, $elements ) {

		$path_types_allow  = dsm_get_text_path_allowed_types();
		$dsm_path_type_raw = $attrs['dsm_path_type']['innerContent']['desktop']['value'] ?? '';
		$dsm_path_type     = 'wave';
		if ( is_string( $dsm_path_type_raw ) ) {
			$pt = strtolower( trim( $dsm_path_type_raw ) );
			if ( in_array( $pt, $path_types_allow, true ) ) {
				$dsm_path_type = $pt;
			}
		}

		$dsm_path_text = self::resolve_inner_plain_or_heading_text( $attrs['dsm_path_text']['innerContent']['desktop']['value'] ?? '' );
		$dsm_text_dir  = $attrs['dsm_text_dir']['innerContent']['desktop']['value'] ?? '';
		if ( ! is_string( $dsm_text_dir ) || '' === $dsm_text_dir ) {
			$dsm_text_dir = 'default';
		}
		list($link_option_url, $link_option_url_new_window) = self::resolve_module_link_for_text_path( $attrs );
		$dsm_path_starting_point                            = $attrs['dsm_path_starting_point']['innerContent']['desktop']['value'] ?? '';
		if ( ! is_string( $dsm_path_starting_point ) || '' === trim( $dsm_path_starting_point ) ) {
			$dsm_path_starting_point = '0%';
		}
		$dsm_stroke_width        = $attrs['dsm_stroke_width']['innerContent']['desktop']['value'] ?? '';
		$dsm_stroke_color        = self::extract_color_value( $attrs['dsm_stroke_color']['innerContent']['desktop']['value'] ?? '' );
		$dsm_show_path           = $attrs['dsm_show_path']['innerContent']['desktop']['value'] ?? '';
		$dsm_custom_path_content = $attrs['dsm_custom_path_content']['innerContent']['desktop']['value'] ?? '';
		$path_color              = self::extract_color_value( $attrs['dsm_path_text']['decoration']['font']['font']['desktop']['value']['color'] ?? '' );

		$text_path_value = '';
		switch ( $dsm_path_type ) {
			case 'wave':
				$text_path_value = sprintf(
					'<svg xmlns="http://www.w3.org/2000/svg" width="250" height="42.4994" viewBox="0 0 250 42.4994">
				                            <path d="M0,42.2494C62.5,42.2494,62.5.25,125,.25s62.5,41.9994,125,41.9994" id="dsm-path-wave"></path>
		                                    <path d="M-41.6693,49.25"></path>
			                                <path d="M-208.3307-6.75"></path>
											<text>
											<textPath href="#dsm-path-wave" startOffset="%2$s%3$s%4$s%5$s">%1$s%6$s%7$s</textPath>
											</text>
											</svg>',
					'' === trim( $link_option_url ) ? $dsm_path_text : '',
					( 'rtl' === $dsm_text_dir && '0%' === $dsm_path_starting_point ) ? '100%' : '',
					( 'rtl' === $dsm_text_dir && '0%' !== $dsm_path_starting_point ) ? 100 - (int) $dsm_path_starting_point . '%' : '',
					( 'rtl' !== $dsm_text_dir && '0%' === $dsm_path_starting_point ) ? '0%' : '',
					( 'rtl' !== $dsm_text_dir && '0%' !== $dsm_path_starting_point ) ? $dsm_path_starting_point : '',
					'on' === $link_option_url_new_window && '' !== trim( $link_option_url ) ? sprintf( '<a href="%1$s" target="_blank">%2$s</a>', esc_url( $link_option_url ), $dsm_path_text ) : '',
					'' !== trim( $link_option_url ) && 'off' === $link_option_url_new_window ? sprintf( '<a href="%1$s">%2$s</a>', esc_url( $link_option_url ), $dsm_path_text ) : ''
				);
				break;
			case 'arc':
				$text_path_value = sprintf(
					'<svg xmlns="http://www.w3.org/2000/svg" width="250.5" height="125.25" viewBox="0 0 250.5 125.25">
												<path d="M.25,125.25a125,125,0,0,1,250,0" id="dsm-path-arc"></path>
												<text>
												   <textPath href="#dsm-path-arc" startOffset="%2$s%3$s%4$s%5$s">%1$s%6$s%7$s</textPath>
												</text>
											</svg>
											',
					'' === trim( $link_option_url ) ? $dsm_path_text : '',
					( 'rtl' === $dsm_text_dir && '0%' === $dsm_path_starting_point ) ? '100%' : '',
					( 'rtl' === $dsm_text_dir && '0%' !== $dsm_path_starting_point ) ? 100 - (int) $dsm_path_starting_point . '%' : '',
					( 'rtl' !== $dsm_text_dir && '0%' === $dsm_path_starting_point ) ? '0%' : '',
					( 'rtl' !== $dsm_text_dir && '0%' !== $dsm_path_starting_point ) ? $dsm_path_starting_point : '',
					'on' === $link_option_url_new_window && '' !== trim( $link_option_url ) ? sprintf( '<a href="%1$s" target="_blank">%2$s</a>', esc_url( $link_option_url ), $dsm_path_text ) : '',
					'' !== trim( $link_option_url ) && 'off' === $link_option_url_new_window ? sprintf( '<a href="%1$s">%2$s</a>', esc_url( $link_option_url ), $dsm_path_text ) : ''
				);
				break;
			case 'circle':
				$text_path_value = sprintf(
					'<svg xmlns="http://www.w3.org/2000/svg" width="250.5" height="250.5" viewBox="0 0 250.5 250.5">
												<path d="M.25,125.25a125,125,0,1,1,125,125,125,125,0,0,1-125-125" id="dsm-path-circle"></path>
												<text>
													<textPath href="#dsm-path-circle" startOffset="%2$s%3$s%4$s%5$s">%1$s%6$s%7$s</textPath>
												</text>
											</svg>
											',
					'' === trim( $link_option_url ) ? $dsm_path_text : '',
					( 'rtl' === $dsm_text_dir && '0%' === $dsm_path_starting_point ) ? '100%' : '',
					( 'rtl' === $dsm_text_dir && '0%' !== $dsm_path_starting_point ) ? 100 - (int) $dsm_path_starting_point . '%' : '',
					( 'rtl' !== $dsm_text_dir && '0%' === $dsm_path_starting_point ) ? '0%' : '',
					( 'rtl' !== $dsm_text_dir && '0%' !== $dsm_path_starting_point ) ? $dsm_path_starting_point : '',
					'on' === $link_option_url_new_window && '' !== trim( $link_option_url ) ? sprintf( '<a href="%1$s" target="_blank">%2$s</a>', esc_url( $link_option_url ), $dsm_path_text ) : '',
					'' !== trim( $link_option_url ) && 'off' === $link_option_url_new_window ? sprintf( '<a href="%1$s">%2$s</a>', esc_url( $link_option_url ), $dsm_path_text ) : ''
				);
				break;
			case 'line':
				$text_path_value = sprintf(
					'<svg xmlns="http://www.w3.org/2000/svg" width="250" height="22" viewBox="0 0 250 22">
												<path d="M 0 27 l 250 -22" id="dsm-path-line"></path>
												<text>
													<textPath href="#dsm-path-line" startOffset="%2$s%3$s%4$s%5$s">%1$s%6$s%7$s</textPath>
												</text>
											</svg>
											',
					'' === trim( $link_option_url ) ? $dsm_path_text : '',
					( 'rtl' === $dsm_text_dir && '0%' === $dsm_path_starting_point ) ? '100%' : '',
					( 'rtl' === $dsm_text_dir && '0%' !== $dsm_path_starting_point ) ? 100 - (int) $dsm_path_starting_point . '%' : '',
					( 'rtl' !== $dsm_text_dir && '0%' === $dsm_path_starting_point ) ? '0%' : '',
					( 'rtl' !== $dsm_text_dir && '0%' !== $dsm_path_starting_point ) ? $dsm_path_starting_point : '',
					'on' === $link_option_url_new_window && '' !== trim( $link_option_url ) ? sprintf( '<a href="%1$s" target="_blank">%2$s</a>', esc_url( $link_option_url ), $dsm_path_text ) : '',
					'' !== trim( $link_option_url ) && 'off' === $link_option_url_new_window ? sprintf( '<a href="%1$s">%2$s</a>', esc_url( $link_option_url ), $dsm_path_text ) : ''
				);
				break;
			case 'oval':
				$text_path_value = sprintf(
					'<svg xmlns="http://www.w3.org/2000/svg" width="250.5" height="125.75" viewBox="0 0 250.5 125.75">
												<path class="b473dc75-7459-43a5-8a1c-89caf910da53" d="M.25,62.875C.25,28.2882,56.2144.25,125.25.25s125,28.0382,125,62.625-55.9644,62.625-125,62.625S.25,97.4619.25,62.875" id="dsm-path-oval"></path>
												<text>
													<textPath href="#dsm-path-oval" startOffset="%2$s%3$s%4$s%5$s">%1$s%6$s%7$s</textPath>
												</text>
											</svg>
											',
					'' === trim( $link_option_url ) ? $dsm_path_text : '',
					( 'rtl' === $dsm_text_dir && '0%' === $dsm_path_starting_point ) ? '100%' : '',
					( 'rtl' === $dsm_text_dir && '0%' !== $dsm_path_starting_point ) ? 100 - (int) $dsm_path_starting_point . '%' : '',
					( 'rtl' !== $dsm_text_dir && '0%' === $dsm_path_starting_point ) ? '0%' : '',
					( 'rtl' !== $dsm_text_dir && '0%' !== $dsm_path_starting_point ) ? $dsm_path_starting_point : '',
					'on' === $link_option_url_new_window && '' !== trim( $link_option_url ) ? sprintf( '<a href="%1$s" target="_blank">%2$s</a>', esc_url( $link_option_url ), $dsm_path_text ) : '',
					'' !== trim( $link_option_url ) && 'off' === $link_option_url_new_window ? sprintf( '<a href="%1$s">%2$s</a>', esc_url( $link_option_url ), $dsm_path_text ) : ''
				);
				break;
			case 'spiral':
				$text_path_value = sprintf(
					'<svg xmlns="http://www.w3.org/2000/svg" width="250.4348" height="239.4454" viewBox="0 0 250.4348 239.4454">
												<path d="M.1848,49.0219a149.3489,149.3489,0,0,1,210.9824-9.8266,119.479,119.479,0,0,1,7.8613,168.786A95.5831,95.5831,0,0,1,84,214.27a76.4666,76.4666,0,0,1-5.0312-108.023" id="dsm-path-spiral"></path>
												<text>
												<textPath href="#dsm-path-spiral" startOffset="%2$s%3$s%4$s%5$s">%1$s%6$s%7$s</textPath>
												</text>
											</svg>
											',
					'' === trim( $link_option_url ) ? $dsm_path_text : '',
					( 'rtl' === $dsm_text_dir && '0%' === $dsm_path_starting_point ) ? '100%' : '',
					( 'rtl' === $dsm_text_dir && '0%' !== $dsm_path_starting_point ) ? 100 - (int) $dsm_path_starting_point . '%' : '',
					( 'rtl' !== $dsm_text_dir && '0%' === $dsm_path_starting_point ) ? '0%' : '',
					( 'rtl' !== $dsm_text_dir && '0%' !== $dsm_path_starting_point ) ? $dsm_path_starting_point : '',
					'on' === $link_option_url_new_window && '' !== trim( $link_option_url ) ? sprintf( '<a href="%1$s" target="_blank">%2$s</a>', esc_url( $link_option_url ), $dsm_path_text ) : '',
					'' !== trim( $link_option_url ) && 'off' === $link_option_url_new_window ? sprintf( '<a href="%1$s">%2$s</a>', esc_url( $link_option_url ), $dsm_path_text ) : ''
				);
				break;

			case 'custom':
				$order_class = 'dsm-text-path' . $block->parsed_block['orderIndex'];

				list($svg_width, $svg_height, $svg_code) = static::process_custom_path( $dsm_custom_path_content, $order_class );

				$text_path_value = sprintf(
					'<svg xmlns="http://www.w3.org/2000/svg" width="%7$s" height="%8$s" viewBox="0 0 %7$s %8$s" fill="none" >
												%6$s
												<text>
													<textPath href="#%9$s" startOffset="%2$s%3$s%4$s%5$s">%1$s</textPath>
												</text>
											</svg>',
					'' === trim( $link_option_url ) ? $dsm_path_text : '',
					( 'rtl' === $dsm_text_dir && '0%' === $dsm_path_starting_point ) ? '100%' : '',
					( 'rtl' === $dsm_text_dir && '0%' !== $dsm_path_starting_point ) ? 100 - (int) $dsm_path_starting_point . '%' : '',
					( 'rtl' !== $dsm_text_dir && '0%' === $dsm_path_starting_point ) ? '0%' : '',
					( 'rtl' !== $dsm_text_dir && '0%' !== $dsm_path_starting_point ) ? $dsm_path_starting_point : '',
					$svg_code,
					$svg_width,
					$svg_height,
					$order_class
				);
				break;
			default:
				$extra_presets = dsm_get_text_path_extra_shape_presets();
				if ( isset( $extra_presets[ $dsm_path_type ] ) ) {
					$preset          = $extra_presets[ $dsm_path_type ];
					$path_id         = 'dsm-text-path' . $block->parsed_block['orderIndex'];
					$text_path_value = sprintf(
						'<svg xmlns="http://www.w3.org/2000/svg" viewBox="%8$s" fill="none">
							<path d="%9$s" id="%10$s"></path>
							<text>
								<textPath href="#%10$s" startOffset="%2$s%3$s%4$s%5$s">%1$s%6$s%7$s</textPath>
							</text>
						</svg>',
						'' === trim( $link_option_url ) ? $dsm_path_text : '',
						( 'rtl' === $dsm_text_dir && '0%' === $dsm_path_starting_point ) ? '100%' : '',
						( 'rtl' === $dsm_text_dir && '0%' !== $dsm_path_starting_point ) ? 100 - (int) $dsm_path_starting_point . '%' : '',
						( 'rtl' !== $dsm_text_dir && '0%' === $dsm_path_starting_point ) ? '0%' : '',
						( 'rtl' !== $dsm_text_dir && '0%' !== $dsm_path_starting_point ) ? $dsm_path_starting_point : '',
						'on' === $link_option_url_new_window && '' !== trim( $link_option_url ) ? sprintf( '<a href="%1$s" target="_blank">%2$s</a>', esc_url( $link_option_url ), $dsm_path_text ) : '',
						'' !== trim( $link_option_url ) && 'off' === $link_option_url_new_window ? sprintf( '<a href="%1$s">%2$s</a>', esc_url( $link_option_url ), $dsm_path_text ) : '',
						esc_attr( $preset['view_box'] ),
						esc_attr( $preset['path_d'] ),
						esc_attr( $path_id )
					);
				} else {
					$text_path_value = '';
				}
				break;
		}

		$container = sprintf(
			'<div class="dsm-text-path-container dsm-%2$s" style="%3$s %4$s">
				%1$s  
			</div>',
			$text_path_value,
			$dsm_text_dir,
			'on' === $dsm_show_path ? sprintf( '--text-path-color: %1$s; --text-path-width: %2$s;', $dsm_stroke_color, $dsm_stroke_width ) : '',
			sprintf( '--text-color:%1$s;', $path_color )
		);

		// Module Inner.
		// Essentially, this is the module content.
		// Were wrapping the title and content in a div with class `et_pb_module_inner`.
		$module_inner = HTMLUtility::render(
			array(
				'tag'               => 'div',
				'attributes'        => array(
					'class' => 'et_pb_module_inner',
				),
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $container,
			)
		);

		// This are the module elements that will be rendered in the frontend.
		$module_elements = $elements->style_components(
			array(
				'attrName' => 'module',
			)
		);

		// This are the children of the module container, which are the module elements and the module inner.
		$module_container_children = $module_elements . $module_inner;

		return Module::render(
			array(
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],
				'attrs'               => $attrs,
				'elements'            => $elements,
				'id'                  => $block->parsed_block['id'],
				'moduleClassName'     => '',
				'name'                => $block->block_type->name,
				'classnamesFunction'  => array( self::class, 'module_classnames' ),
				'moduleCategory'      => $block->block_type->category,
				'stylesComponent'     => array( self::class, 'module_styles' ),
				'scriptDataComponent' => array( self::class, 'module_script_data' ),
				'children'            => $module_container_children,
			)
		);
	}

	/**
	 * String or headingLink `{ text }` from innerContent desktop value.
	 *
	 * @param mixed $raw Raw value.
	 * @return string
	 */
	private static function resolve_inner_plain_or_heading_text( $raw ) {
		if ( is_string( $raw ) ) {
			return $raw;
		}
		if ( is_array( $raw ) && isset( $raw['text'] ) && is_string( $raw['text'] ) ) {
			return $raw['text'];
		}
		return '';
	}

	/**
	 * Module link URL + new-tab flag: D5 `module.advanced.link` (migrated from D4 link_options) or legacy attrs.
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 * @return array{0: string, 1: string} URL and `on`|`off` for new window (matches D4 `link_option_url_new_window`).
	 */
	private static function resolve_module_link_for_text_path( array $attrs ): array {
		$url        = '';
		$new_window = 'off';

		$link_branch = $attrs['module']['advanced']['link'] ?? null;
		if ( is_array( $link_branch ) ) {
			$bucket = null;
			if ( isset( $link_branch['innerContent']['desktop']['value'] ) && is_array( $link_branch['innerContent']['desktop']['value'] ) ) {
				$bucket = $link_branch['innerContent']['desktop']['value'];
			} elseif ( isset( $link_branch['desktop']['value'] ) && is_array( $link_branch['desktop']['value'] ) ) {
				$bucket = $link_branch['desktop']['value'];
			}
			if ( is_array( $bucket ) ) {
				if ( isset( $bucket['url'] ) ) {
					if ( is_string( $bucket['url'] ) ) {
						$url = $bucket['url'];
					}
				}
				$target = $bucket['target'] ?? $bucket['linkTarget'] ?? '';
				if ( 'on' === $target || true === $target || 1 === $target || 'yes' === $target || '_blank' === $target ) {
					$new_window = 'on';
				}
			}
		}

		if ( '' === $url && isset( $attrs['link_option_url']['innerContent']['desktop']['value'] ) ) {
			$legacy = $attrs['link_option_url']['innerContent']['desktop']['value'];
			if ( is_string( $legacy ) ) {
				$url = $legacy;
			}
		}
		if ( isset( $attrs['link_option_url_new_window']['innerContent']['desktop']['value'] ) ) {
			$legacy_t = $attrs['link_option_url_new_window']['innerContent']['desktop']['value'];
			if ( 'on' === $legacy_t ) {
				$new_window = 'on';
			}
			if ( 'off' === $legacy_t ) {
				$new_window = 'off';
			}
		}

		return array( $url, $new_window );
	}
}
