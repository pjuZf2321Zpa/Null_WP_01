<?php
/**
 * Supreme Perspective Image module (D5).
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Modules;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\Module\Options\Element\ElementClassnames;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use ET\Builder\Packages\Module\Options\Text\TextStyle;
use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\Module\Layout\Components\ModuleElements\ModuleElementsUtils;
use ET\Builder\Packages\Module\Options\Attributes\AttributeUtils;
use DiviSupreme\Includes\ModuleRegisterAttrsNormalize;
use DiviSupreme\Extensions\IconLibraries\IconGlyphRenderer;
use DiviSupreme\Extensions\IconLibraries\LegacyModuleIconStyles;

/**
 * Handles `dsm/perspective-image`.
 */
class PerspectiveImage implements DependencyInterface {


	/**
	 * Register with Divi (DependencyInterface).
	 *
	 * @return void
	 */
	public function load() {
		add_filter(
			'divi_module_library_register_module_attrs',
			array( self::class, 'filter_register_module_attrs' ),
			10,
			2
		);
		add_action( 'init', array( self::class, 'register_module' ) );
	}

	/**
	 * Normalize Perspective Image attrs after merged JSON + defaults (matches scroll-image decoration pattern).
	 *
	 * @param array $module_attrs Merged module attrs.
	 * @param array $filter_args  Contains `name`, `attrs`, `id`, `storeInstance`.
	 * @return array
	 */
	public static function filter_register_module_attrs( $module_attrs, $filter_args ) {
		if ( ! is_array( $module_attrs ) || ! is_array( $filter_args ) ) {
			return is_array( $module_attrs ) ? $module_attrs : array();
		}

		if ( ( $filter_args['name'] ?? '' ) !== 'dsm/perspective-image' ) {
			return $module_attrs;
		}

		ModuleRegisterAttrsNormalize::perspective_image_merged( $module_attrs );

		return $module_attrs;
	}

	/**
	 * Legacy installer hook.
	 *
	 * @return void
	 */
	public static function dsm_initialise() {
		add_action(
			'divi_module_library_modules_dependency_tree',
			function ( $dependency_tree ) {
				$dependency_tree->add_dependency( new self() );
			}
		);
	}

	/**
	 * Register module JSON path + render callback.
	 *
	 * @return void
	 */
	public static function register_module() {
		$module_json_path = DSM_DIR_PATH . 'divi-5/public/packages/module-library/perspective-image';

		ModuleRegistration::register_module(
			$module_json_path,
			array(
				'render_callback' => array( self::class, 'render_callback' ),
			)
		);
	}

	/**
	 * Resolve image URL from Upload `innerContent.desktop.value`.
	 *
	 * @param mixed $image_raw Raw value.
	 * @return string
	 */
	private static function get_upload_image_src( $image_raw ) {
		if ( is_string( $image_raw ) || is_numeric( $image_raw ) ) {
			return (string) $image_raw;
		}
		if ( is_array( $image_raw ) && ! empty( $image_raw['src'] ) ) {
			return (string) $image_raw['src'];
		}

		return '';
	}

	/**
	 * Escape `<img src="">` (URL or `data:` URI).
	 *
	 * @param string $src Image source.
	 * @return string
	 */
	private static function escape_img_src_attribute( string $src ): string {
		if ( preg_match( '#^data:image/[a-zA-Z0-9.+-]+;base64,[a-zA-Z0-9+/=]+$#', $src ) ) {
			return esc_attr( $src );
		}

		return esc_url( $src );
	}

	/**
	 * Advanced → Attributes rows targeting the main image (`src` or legacy `image` target key).
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 * @return array<string, string>
	 */
	private static function get_perspective_src_target_attributes_from_decoration( array $attrs ): array {
		$dec = $attrs['module']['decoration']['attributes'] ?? array();
		if ( empty( $dec ) || ! is_array( $dec ) ) {
			return array();
		}

		$separated = AttributeUtils::separate_attributes_by_target_element( $dec );
		$target    = $separated['src'] ?? array();
		if ( empty( $target ) && isset( $separated['image'] ) && is_array( $separated['image'] ) ) {
			$target = $separated['image'];
		}

		return is_array( $target ) ? $target : array();
	}

	/**
	 * Effective `<img alt>` / `title` after Advanced → Attributes override (scroll-image pattern).
	 *
	 * @param array<string, mixed> $attrs     Module attrs.
	 * @param mixed                $image_raw `src` innerContent desktop value.
	 * @return array{0: string, 1: string}
	 */
	private static function get_perspective_effective_img_alt_title( array $attrs, $image_raw ): array {
		$extra                       = self::get_perspective_src_target_attributes_from_decoration( $attrs );
		list($alt_base, $title_base) = self::get_perspective_img_alt_title( $attrs, $image_raw );
		$alt                         = $alt_base;
		$title                       = $title_base;
		if ( array_key_exists( 'alt', $extra ) ) {
			$alt = is_string( $extra['alt'] ) ? trim( $extra['alt'] ) : '';
		}
		if ( array_key_exists( 'title', $extra ) ) {
			$title = is_string( $extra['title'] ) ? trim( $extra['title'] ) : '';
		}

		return array( $alt, $title );
	}

	/**
	 * Frontend `<img>` with responsive srcset + decoration attrs on `src` (native Image module pattern).
	 *
	 * @param array<string, mixed> $attrs     Module attrs.
	 * @param mixed                $image_raw `src` innerContent desktop value.
	 * @param string               $image_src Resolved URL or data URI.
	 * @return string
	 */
	private static function render_perspective_image_img( array $attrs, $image_raw, string $image_src ): string {
		$extra                       = self::get_perspective_src_target_attributes_from_decoration( $attrs );
		list($alt_base, $title_base) = self::get_perspective_img_alt_title( $attrs, $image_raw );

		$attributes = array(
			'src' => $image_src,
		);

		$responsive_input = array(
			'src' => $image_src,
		);

		if ( is_array( $image_raw ) && ! empty( $image_raw['id'] ) ) {
			$responsive_input['id'] = absint( $image_raw['id'] );
		}

		$responsive = ModuleElementsUtils::get_responsive_image_attrs( $responsive_input );

		if ( is_array( $responsive ) ) {
			if ( ! empty( $responsive['srcset'] ) && is_string( $responsive['srcset'] ) ) {
				$attributes['srcset'] = $responsive['srcset'];
			}
			if ( ! empty( $responsive['sizes'] ) && is_string( $responsive['sizes'] ) ) {
				$attributes['sizes'] = $responsive['sizes'];
			}
			if ( ! empty( $responsive['width'] ) && is_string( $responsive['width'] ) ) {
				$attributes['width'] = $responsive['width'];
			}
			if ( ! empty( $responsive['height'] ) && is_string( $responsive['height'] ) ) {
				$attributes['height'] = $responsive['height'];
			}
		}

		foreach ( $extra as $key => $val ) {
			if ( ! is_string( $key ) || '' === $key || 'class' === $key || 'src' === $key ) {
				continue;
			}
			if ( ! is_scalar( $val ) ) {
				continue;
			}
			$s = trim( (string) $val );
			if ( '' === $s && 'alt' !== $key ) {
				continue;
			}
			$attributes[ $key ] = $s;
		}

		if ( ! array_key_exists( 'alt', $attributes ) && '' !== $alt_base ) {
			$attributes['alt'] = $alt_base;
		}

		if ( ! array_key_exists( 'title', $attributes ) && '' !== $title_base ) {
			$attributes['title'] = $title_base;
		}

		return HTMLUtility::render(
			array(
				'tag'                  => 'img',
				'tagEscaped'           => true,
				'attributes'           => $attributes,
				'attributesSanitizers' => array(
					'src' => function ( $v ) {
						return is_string( $v ) ? self::escape_img_src_attribute( $v ) : '';
					},
				),
			)
		);
	}

	/**
	 * Read `<img alt>` and `title` from Divi 5 `src` upload value, with legacy attr fallback.
	 *
	 * @param array<string, mixed> $attrs      Module attrs.
	 * @param mixed                $image_raw `src` innerContent desktop value.
	 * @return array{0: string, 1: string} Alt and title strings.
	 */
	private static function get_perspective_img_alt_title( array $attrs, $image_raw ): array {
		$alt   = '';
		$title = '';
		if ( is_array( $image_raw ) ) {
			if ( isset( $image_raw['alt'] ) && is_string( $image_raw['alt'] ) ) {
				$alt = $image_raw['alt'];
			}
			if ( isset( $image_raw['title'] ) && is_string( $image_raw['title'] ) ) {
				$title = $image_raw['title'];
			} elseif ( isset( $image_raw['titleText'] ) && is_string( $image_raw['titleText'] ) ) {
				$title = $image_raw['titleText'];
			}
		}
		if ( '' === $alt ) {
			$alt = self::get_inner_desktop_value_string( $attrs, 'alt', '' );
		}
		if ( '' === $title ) {
			$title = self::get_inner_desktop_value_string( $attrs, 'title_text', '' );
		}

		return array( $alt, $title );
	}

	/**
	 * Read range/innerContent string at breakpoint + state (hover, value, …) with fallback cascade.
	 *
	 * Mirrors VB shapes helper: try `breakpoint` first, then desktop → tablet → phone; hover uses
	 * `node[ state ].value` when set, else `node.value`.
	 *
	 * @param array<string, mixed> $attrs      Module attrs.
	 * @param string               $key        Top-level attr key.
	 * @param string               $breakpoint desktop|tablet|phone.
	 * @param string               $state      Value, hover, or another state.
	 * @param string               $fallback   When all missing or empty after trim.
	 * @return string
	 */
	private static function read_inner_content_string_at_breakpoint_state(
		array $attrs,
		string $key,
		string $breakpoint,
		string $state,
		string $fallback
	): string {
		$ic = $attrs[ $key ]['innerContent'] ?? null;
		if ( ! is_array( $ic ) ) {
			return $fallback;
		}
		$order = array_values(
			array_unique(
				array_merge(
					array( $breakpoint ),
					array( 'desktop', 'tablet', 'phone' )
				)
			)
		);
		foreach ( $order as $bp ) {
			if ( ! isset( $ic[ $bp ] ) || ! is_array( $ic[ $bp ] ) ) {
				continue;
			}
			$node = $ic[ $bp ];
			// Divi often stores hover/sticky as a scalar or as { value: string } (see ModuleUtils::sort_states).
			if ( 'value' !== $state && isset( $node[ $state ] ) ) {
				$st_raw = $node[ $state ];
				if ( is_string( $st_raw ) || is_numeric( $st_raw ) ) {
					$s = trim( (string) $st_raw );
					if ( '' !== $s ) {
						return $s;
					}
				} elseif ( is_array( $st_raw ) && array_key_exists( 'value', $st_raw ) ) {
					$s = self::trim_inner_scalar_string( $st_raw['value'] );
					if ( null !== $s && '' !== $s ) {
						return $s;
					}
				}
			}
			if ( array_key_exists( 'value', $node ) ) {
				$s = self::trim_inner_scalar_string( $node['value'] );
				if ( null !== $s ) {
					return $s;
				}
			}
		}

		return $fallback;
	}

	/**
	 * Trim an innerContent leaf to a string.
	 *
	 * @param mixed $raw innerContent leaf (string, number, or array with value).
	 * @return string|null Non-null: use this string (may be empty).
	 */
	private static function trim_inner_scalar_string( $raw ): ?string {
		if ( is_string( $raw ) || is_numeric( $raw ) ) {
			return trim( (string) $raw );
		}
		if ( is_array( $raw ) && array_key_exists( 'value', $raw ) && ( is_string( $raw['value'] ) || is_numeric( $raw['value'] ) ) ) {
			return trim( (string) $raw['value'] );
		}

		return null;
	}

	/**
	 * Per-breakpoint selectors: hover uses module `:hover` + descendant wrapper (Divi/card pattern).
	 *
	 * @param string               $order_class  Module order class.
	 * @param array<string, mixed> $merged_inner Merged innerContent from {@see merge_perspective_transform_inner_contents_for_style()}.
	 * @return array<string, array<string, string>>
	 */
	private static function perspective_transform_selectors_for_common_style( string $order_class, array $merged_inner ): array {
		$value_sel = "{$order_class} .dsm-perspective-image-wrapper";
		$hover_sel = "{$order_class}:hover .dsm-perspective-image-wrapper";
		$out       = array();
		foreach ( array_keys( $merged_inner ) as $bp ) {
			if ( ! is_string( $bp ) ) {
				continue;
			}
			$out[ $bp ] = array(
				'value' => $value_sel,
			);
			if ( isset( $merged_inner[ $bp ]['hover'] ) ) {
				$out[ $bp ]['hover'] = $hover_sel;
			}
		}

		return $out;
	}

	/**
	 * Wrapper-only selectors for transition (base state); always targets `.dsm-perspective-image-wrapper`.
	 *
	 * @param string               $order_class  Module order class.
	 * @param array<string, mixed> $merged_inner Merged transform innerContent (for breakpoint keys).
	 * @return array<string, array<string, string>>
	 */
	private static function perspective_wrapper_transition_selectors_for_common_style( string $order_class, array $merged_inner ): array {
		$sel = "{$order_class} .dsm-perspective-image-wrapper";
		$out = array();
		foreach ( array_keys( $merged_inner ) as $bp ) {
			if ( ! is_string( $bp ) ) {
				continue;
			}
			$out[ $bp ] = array(
				'value' => $sel,
			);
		}

		return $out;
	}

	/**
	 * Minimal `attr` shape so transition rules emit once per breakpoint on the wrapper only.
	 *
	 * @param array<string, mixed> $merged_inner Merged transform innerContent.
	 * @return array<string, mixed>
	 */
	private static function build_perspective_wrapper_transition_style_attr( array $merged_inner ): array {
		$attr = array();
		foreach ( array_keys( $merged_inner ) as $bp ) {
			if ( ! is_string( $bp ) ) {
				continue;
			}
			$attr[ $bp ] = array(
				'value' => array(
					'wrapperTransition' => true,
				),
			);
		}

		return $attr;
	}

	/**
	 * Union of breakpoint/state keys so CommonStyle emits hover rules when only rotate fields have hover.
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 * @return array<string, mixed> innerContent-shaped map for CommonStyle `attr`.
	 */
	private static function merge_perspective_transform_inner_contents_for_style( array $attrs ): array {
		$merged = array();
		foreach ( array( 'perspective', 'dsm_rotate_x', 'dsm_rotate_y', 'dsm_rotate_z' ) as $field_key ) {
			$ic = $attrs[ $field_key ]['innerContent'] ?? null;
			if ( ! is_array( $ic ) ) {
				continue;
			}
			foreach ( $ic as $bp => $state_values ) {
				if ( ! is_string( $bp ) || ! is_array( $state_values ) ) {
					continue;
				}
				foreach ( array_keys( $state_values ) as $st ) {
					if ( ! is_string( $st ) ) {
						continue;
					}
					if ( ! isset( $merged[ $bp ] ) ) {
						$merged[ $bp ] = array();
					}
					if ( ! isset( $merged[ $bp ][ $st ] ) ) {
						$merged[ $bp ][ $st ] = array(
							'value' => '',
						);
					}
				}
			}
		}

		return $merged;
	}

	/**
	 * Read desktop innerContent scalar string.
	 *
	 * @param array<string, mixed> $attrs    Module attrs.
	 * @param string               $key      Attribute key.
	 * @param string               $fallback Default.
	 * @return string
	 */
	private static function get_inner_desktop_value_string( array $attrs, string $key, string $fallback = '' ): string {
		if ( ! isset( $attrs[ $key ]['innerContent']['desktop']['value'] ) ) {
			return $fallback;
		}

		$raw = $attrs[ $key ]['innerContent']['desktop']['value'];

		if ( is_string( $raw ) || is_numeric( $raw ) ) {
			$out = trim( (string) $raw );

			return '' !== $out ? $out : $fallback;
		}

		if ( is_array( $raw ) && isset( $raw['value'] ) && ( is_string( $raw['value'] ) || is_numeric( $raw['value'] ) ) ) {
			$out = trim( (string) $raw['value'] );

			return '' !== $out ? $out : $fallback;
		}

		return $fallback;
	}

	/**
	 * Whether toggle is `on`.
	 *
	 * @param array  $attrs        Module attrs.
	 * @param string $key          Key.
	 * @param string $when_missing Fallback.
	 * @return bool
	 */
	private static function inner_toggle_is_on( array $attrs, string $key, string $when_missing = 'off' ): bool {
		return 'on' === self::get_inner_desktop_value_string( $attrs, $key, $when_missing );
	}

	/**
	 * Icon overlay (::after) styles.
	 *
	 * @param array $params Params from Divi.
	 * @return string
	 */
	public static function icon_style_declaration( $params ) {
		return LegacyModuleIconStyles::build_pseudo_icon_declaration( $params );
	}

	/**
	 * Map Divi transition speedCurve to CSS timing-function (see Transition style declaration).
	 *
	 * @param string $curve Stored curve key.
	 * @return string
	 */
	private static function map_speed_curve_to_timing_function( string $curve ): string {
		switch ( $curve ) {
			case 'easeInOut':
				return 'ease-in-out';
			case 'easeIn':
				return 'ease-in';
			case 'easeOut':
				return 'ease-out';
			case 'linear':
				return 'linear';
			case 'ease':
			default:
				return 'ease';
		}
	}

	/**
	 * Read `module.decoration.transition` desktop/tablet/phone leaf (Design → Transition).
	 *
	 * @param array<string, mixed> $attrs      Module attrs.
	 * @param string               $breakpoint desktop|tablet|phone.
	 * @return array{duration: string, delay: string, speedCurve: string}
	 */
	private static function read_module_transition_leaf_at_breakpoint( array $attrs, string $breakpoint ): array {
		$defaults = array(
			'duration'   => '300ms',
			'delay'      => '0ms',
			'speedCurve' => 'ease',
		);
		$trans    = $attrs['module']['decoration']['transition'] ?? null;
		if ( ! is_array( $trans ) ) {
			return $defaults;
		}
		$order = array_values(
			array_unique(
				array_merge(
					array( $breakpoint ),
					array( 'desktop', 'tablet', 'phone' )
				)
			)
		);
		foreach ( $order as $bp ) {
			if ( ! isset( $trans[ $bp ] ) || ! is_array( $trans[ $bp ] ) ) {
				continue;
			}
			$node = $trans[ $bp ];
			if ( ! isset( $node['value'] ) || ! is_array( $node['value'] ) ) {
				continue;
			}
			$leaf = $node['value'];
			$out  = $defaults;
			foreach ( array( 'duration', 'delay', 'speedCurve' ) as $k ) {
				if ( isset( $leaf[ $k ] ) && is_string( $leaf[ $k ] ) && '' !== $leaf[ $k ] ) {
					$out[ $k ] = $leaf[ $k ];
				}
			}

			return $out;
		}

		return $defaults;
	}

	/**
	 * 3D transform for `.dsm-perspective-image-wrapper`.
	 *
	 * @param array $params Style params.
	 * @param array $attrs  Module attrs (captured).
	 * @return string
	 */
	private static function perspective_transform_declaration( array $params, array $attrs ): string {
		$breakpoint = isset( $params['breakpoint'] ) && is_string( $params['breakpoint'] ) ? $params['breakpoint'] : 'desktop';
		$state      = isset( $params['state'] ) && is_string( $params['state'] ) ? $params['state'] : 'value';

		$perspective = self::read_inner_content_string_at_breakpoint_state( $attrs, 'perspective', $breakpoint, $state, '1000px' );
		if ( '' === trim( $perspective ) ) {
			$perspective = '1000px';
		}
		$rx = self::read_inner_content_string_at_breakpoint_state( $attrs, 'dsm_rotate_x', $breakpoint, $state, '0deg' );
		$ry = self::read_inner_content_string_at_breakpoint_state( $attrs, 'dsm_rotate_y', $breakpoint, $state, '0deg' );
		$rz = self::read_inner_content_string_at_breakpoint_state( $attrs, 'dsm_rotate_z', $breakpoint, $state, '0deg' );
		if ( '' === trim( $rx ) ) {
			$rx = '0deg';
		}
		if ( '' === trim( $ry ) ) {
			$ry = '0deg';
		}
		if ( '' === trim( $rz ) ) {
			$rz = '0deg';
		}

		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
			)
		);

		$style_declarations->add(
			'transform',
			sprintf(
				'perspective(%1$s) rotateX(%2$s) rotateY(%3$s) rotateZ(%4$s)',
				$perspective,
				$rx,
				$ry,
				$rz
			)
		);

		return $style_declarations->value();
	}

	/**
	 * Transition on `.dsm-perspective-image-wrapper` only (Design → Transition), base state per breakpoint.
	 *
	 * @param array<string, mixed> $params Style params.
	 * @param array<string, mixed> $attrs  Module attrs.
	 * @return string
	 */
	private static function perspective_wrapper_transition_declaration( array $params, array $attrs ): string {
		$state = isset( $params['state'] ) && is_string( $params['state'] ) ? $params['state'] : 'value';
		if ( 'value' !== $state ) {
			return '';
		}
		$breakpoint   = isset( $params['breakpoint'] ) && is_string( $params['breakpoint'] ) ? $params['breakpoint'] : 'desktop';
		$t            = self::read_module_transition_leaf_at_breakpoint( $attrs, $breakpoint );
		$declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
			)
		);
		$declarations->add( 'transition-property', 'transform' );
		$declarations->add( 'transition-duration', $t['duration'] );
		$declarations->add(
			'transition-timing-function',
			self::map_speed_curve_to_timing_function( $t['speedCurve'] )
		);
		$declarations->add( 'transition-delay', $t['delay'] );

		return $declarations->value();
	}

	/**
	 * FE/VB styles.
	 *
	 * @param array $args Divi style args.
	 * @return void
	 */
	public static function module_styles( $args ) {
		$args  = \DiviSupreme\Includes\DsmDiviBuilderCssScope::normalize_module_styles_args( $args );
		$attrs = $args['attrs'] ?? array();
		if ( ! is_array( $attrs ) ) {
			$attrs = array();
		}

		$merged_transform_attr = self::merge_perspective_transform_inner_contents_for_style( $attrs );
		if ( empty( $merged_transform_attr ) ) {
			$merged_transform_attr = $attrs['perspective']['innerContent'] ?? array();
		}

		$transform_selectors = self::perspective_transform_selectors_for_common_style(
			$args['orderClass'],
			$merged_transform_attr
		);
		if ( empty( $transform_selectors ) ) {
			$transform_selectors = array(
				'desktop' => array(
					'value' => "{$args['orderClass']} .dsm-perspective-image-wrapper",
				),
			);
		}

		$transition_selectors = self::perspective_wrapper_transition_selectors_for_common_style(
			$args['orderClass'],
			$merged_transform_attr
		);
		$transition_attr      = self::build_perspective_wrapper_transition_style_attr( $merged_transform_attr );
		if ( empty( $transition_selectors ) ) {
			$transition_selectors = array(
				'desktop' => array(
					'value' => "{$args['orderClass']} .dsm-perspective-image-wrapper",
				),
			);
			$transition_attr      = array(
				'desktop' => array(
					'value' => array( 'wrapperTransition' => true ),
				),
			);
		}

		$styles = array(
			$args['elements']->style(
				array(
					'attrName'   => 'module',
					'styleProps' => array(
						'disabledOn' => array(
							'disabledModuleVisibility' => $args['settings']['disabledModuleVisibility'] ?? null,
						),
					),
				)
			),
			TextStyle::style(
				array(
					'selector' => $args['orderClass'],
					'attr'     => $attrs['module']['advanced']['text'] ?? array(),
				)
			),
			CssStyle::style(
				array(
					'selector' => $args['orderClass'],
					'attr'     => $attrs['css'] ?? array(),
				)
			),
			$args['elements']->style(
				array(
					'attrName' => 'overlay_styling',
				)
			),
			CommonStyle::style(
				array(
					'selector'            => "{$args['orderClass']} .et_pb_inline_icon::after",
					'attr'                => $attrs['hover_icon']['innerContent'] ?? array(),
					'declarationFunction' => array( self::class, 'icon_style_declaration' ),
				)
			),
			CommonStyle::style(
				array(
					'selector'            => "{$args['orderClass']} .dsm-perspective-image-wrapper",
					'selectors'           => $transform_selectors,
					'attr'                => $merged_transform_attr,
					'orderClass'          => $args['orderClass'],
					'declarationFunction' => static function ( $params ) use ( $attrs ) {
						return self::perspective_transform_declaration(
							is_array( $params ) ? $params : array(),
							$attrs
						);
					},
				)
			),
			CommonStyle::style(
				array(
					'selector'            => "{$args['orderClass']} .dsm-perspective-image-wrapper",
					'selectors'           => $transition_selectors,
					'attr'                => $transition_attr,
					'orderClass'          => $args['orderClass'],
					'declarationFunction' => static function ( $params ) use ( $attrs ) {
						return self::perspective_wrapper_transition_declaration(
							is_array( $params ) ? $params : array(),
							$attrs
						);
					},
				)
			),
			CommonStyle::style(
				array(
					'selector' => $args['orderClass'],
					'attr'     => $attrs['align']['innerContent'] ?? array(),
					'property' => 'text-align',
				)
			),
			CommonStyle::style(
				array(
					'selector' => "{$args['orderClass']} .dsm-perspective-image-wrapper .et_overlay",
					'attr'     => $attrs['hover_overlay_color']['innerContent'] ?? array(),
					'property' => 'background-color',
				)
			),
			CommonStyle::style(
				array(
					'selector' => "{$args['orderClass']} .dsm-perspective-image-wrapper .et_pb_inline_icon",
					'attr'     => $attrs['overlay_icon_color']['innerContent'] ?? array(),
					'property' => 'color',
				)
			),
			CommonStyle::style(
				array(
					'selector' => "{$args['orderClass']} .mfp-content .mfp-close",
					'attr'     => $attrs['lightbox_close_color']['innerContent'] ?? array(),
					'property' => 'color',
				)
			),
			CommonStyle::style(
				array(
					'selector' => "{$args['orderClass']} .mfp-content",
					'attr'     => $attrs['lightbox_max_width']['innerContent'] ?? array(),
					'property' => 'max-width',
				)
			),
		);

		Style::add(
			array(
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => $styles,
			)
		);
	}

	/**
	 * Script data for the module.
	 *
	 * @param array $args Args.
	 * @return void
	 */
	public static function module_script_data( $args ) {
		$elements = $args['elements'];
		$elements->script_data(
			array(
				'attrName' => 'module',
			)
		);
		$elements->script_data(
			array(
				'attrName' => 'overlay_styling',
			)
		);
	}

	/**
	 * Module wrapper classnames.
	 *
	 * @param array $args Args.
	 * @return void
	 */
	public static function module_classnames( $args ) {
		$classnames_instance = $args['classnamesInstance'];
		$attrs               = $args['attrs'] ?? array();
		if ( ! is_array( $attrs ) ) {
			$attrs = array();
		}

		$classnames_instance->add(
			ElementClassnames::classnames(
				array(
					'attrs' => $attrs['module']['decoration'] ?? array(),
				)
			)
		);

		$text_color = $attrs['module']['advanced']['text']['text']['desktop']['value']['color'] ?? 'light';
		if ( is_string( $text_color ) && '' !== $text_color ) {
			$classnames_instance->add( 'et_pb_bg_layout_' . $text_color );
		}

		if ( self::inner_toggle_is_on( $attrs, 'always_center_on_mobile', 'on' ) ) {
			$classnames_instance->add( 'et_always_center_on_mobile' );
		}
	}

	/**
	 * Render HTML.
	 *
	 * @param array     $attrs    Block attrs.
	 * @param string    $content  Inner content.
	 * @param \WP_Block $block    Block.
	 * @param mixed     $elements Elements API.
	 * @return string
	 */
	public static function render_callback( $attrs, $content, $block, $elements ) {
		if ( ! is_array( $attrs ) ) {
			$attrs = array();
		}

		$image_raw                   = $attrs['src']['innerContent']['desktop']['value'] ?? '';
		$image_src                   = self::get_upload_image_src( $image_raw );
		list($alt_text, $title_text) = self::get_perspective_effective_img_alt_title( $attrs, $image_raw );
		$show_lb                     = self::inner_toggle_is_on( $attrs, 'show_in_lightbox', 'off' );
		$use_other_lb                = self::inner_toggle_is_on( $attrs, 'show_lightbox_other_img', 'off' );
		$other_raw                   = $attrs['show_lightbox_other_img_src']['innerContent']['desktop']['value'] ?? '';
		$other_src                   = self::get_upload_image_src( $other_raw );
		$lb_href                     = ( $use_other_lb && '' !== $other_src ) ? $other_src : $image_src;
		$use_video_popup             = self::inner_toggle_is_on( $attrs, 'use_video_popup', 'off' );
		$url                         = self::get_inner_desktop_value_string( $attrs, 'url', '' );
		$url_new_window              = self::get_inner_desktop_value_string( $attrs, 'url_new_window', 'off' );
		$use_overlay                 = self::inner_toggle_is_on( $attrs, 'use_overlay', 'off' );
		$overlay_on_hover            = self::inner_toggle_is_on( $attrs, 'overlay_on_hover', 'on' );
		$use_icon                    = self::inner_toggle_is_on( $attrs, 'use_icon', 'on' );

		$icon_raw    = $attrs['hover_icon']['innerContent']['desktop']['value'] ?? array();
		$icon_raw    = is_array( $icon_raw ) ? $icon_raw : array();
		$icon_chr    = Utils::process_font_icon( $icon_raw );
		$icon_chr    = is_string( $icon_chr ) ? $icon_chr : '';
		$dsm_overlay = '';
		if ( '' === $icon_chr && $use_icon && class_exists( IconGlyphRenderer::class ) ) {
			$dsm_overlay = IconGlyphRenderer::render_icon_span( $icon_raw );
		}
		$data_icon = ( '' !== $icon_chr && $use_icon )
			? sprintf( ' data-icon="%s"', esc_attr( $icon_chr ) )
			: '';

		$overlay_classes = 'et_overlay';
		if ( '' !== $icon_chr && $use_icon ) {
			$overlay_classes .= ' et_pb_inline_icon';
		} else {
			$overlay_classes .= ' dsm-perspective-image-icon-empty';
		}

		if ( $show_lb || $use_video_popup ) {
			if ( function_exists( 'dsm_enqueue_magnific_popup_assets' ) ) {
				dsm_enqueue_magnific_popup_assets();
			}
			wp_enqueue_script( 'dsm-perspective-image' );
		}

		$overlay_html = '';
		if ( $use_overlay ) {
			$overlay_html = sprintf(
				'<span class="%1$s"%2$s>%3$s</span>',
				esc_attr( $overlay_classes ),
				$data_icon,
				$dsm_overlay
			);
		}

		$img_tag = self::render_perspective_image_img( $attrs, $image_raw, $image_src );

		$inner_wrap = sprintf(
			'<span class="et_pb_image_wrap">%1$s%2$s</span>',
			$img_tag,
			et_core_esc_previously( $overlay_html )
		);

		$wrapper_classes = array( 'dsm-perspective-image-wrapper' );
		if ( $use_overlay ) {
			$wrapper_classes[] = 'et_pb_has_overlay';
			if ( ! $overlay_on_hover ) {
				$wrapper_classes[] = 'dsm-perspective-image-overlay-off';
			}
		}
		if ( self::inner_toggle_is_on( $attrs, 'force_fullwidth', 'off' ) ) {
			$wrapper_classes[] = 'dsm-force-fullwidth';
		}

		$wrapper_class_attr = implode( ' ', array_filter( $wrapper_classes ) );

		$link_inner = $inner_wrap;

		if ( $show_lb && '' !== $image_src ) {
			$order_index = isset( $block->parsed_block['orderIndex'] ) ? (string) $block->parsed_block['orderIndex'] : '';
			$link_inner  = sprintf(
				'<a href="%1$s" class="et_pb_lightbox_image dsm-image-lightbox"%2$s data-mfp-src="%3$s">%4$s</a>',
				esc_url( $image_src ),
				'' !== $title_text ? sprintf( ' title="%s"', esc_attr( $title_text ) ) : '',
				esc_url( $lb_href ),
				$inner_wrap
			);
		} elseif ( $use_video_popup && '' !== trim( $url ) ) {
			$link_inner = sprintf(
				'<a href="%1$s" class="dsm-video-lightbox">%2$s</a>',
				esc_url( $url ),
				$inner_wrap
			);
		} elseif ( '' !== trim( $url ) && ! $show_lb && ! $use_video_popup ) {
			$target     = 'on' === $url_new_window ? ' target="_blank" rel="noopener noreferrer"' : '';
			$link_inner = sprintf(
				'<a href="%1$s"%2$s>%3$s</a>',
				esc_url( $url ),
				$target,
				$inner_wrap
			);
		}

		$wrapper_html = sprintf(
			'<div class="%1$s">%2$s</div>',
			esc_attr( $wrapper_class_attr ),
			et_core_esc_previously( $link_inner )
		);

		$module_inner = HTMLUtility::render(
			array(
				'tag'               => 'div',
				'attributes'        => array(
					'class' => 'et_pb_module_inner',
				),
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $wrapper_html,
			)
		);

		$module_elements           = $elements->style_components(
			array(
				'attrName' => 'module',
			)
		);
		$module_container_children = $module_elements . $module_inner;

		return Module::render(
			array(
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],
				'attrs'               => $attrs,
				'elements'            => $elements,
				'id'                  => $block->parsed_block['id'],
				'moduleClassName'     => 'dsm_perspective_image',
				'name'                => $block->block_type->name,
				'classnamesFunction'  => array( self::class, 'module_classnames' ),
				'moduleCategory'      => $block->block_type->category,
				'stylesComponent'     => array( self::class, 'module_styles' ),
				'scriptDataComponent' => array( self::class, 'module_script_data' ),
				'children'            => $module_container_children,
			)
		);
	}
}
