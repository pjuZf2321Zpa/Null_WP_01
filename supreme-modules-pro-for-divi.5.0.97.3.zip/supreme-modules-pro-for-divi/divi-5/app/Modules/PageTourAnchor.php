<?php
/**
 * Page Tour targeting: stamp `data-dsm-tour-anchor` on picked modules.
 *
 * Pre-scans the current post (not Theme Builder header/footer) for
 * `dsm/page-tour-step` block IDs, then inverts Popup's `render_block`
 * filter: stamp the *target* module instead of the tour itself.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Modules;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Frontend block-ID resolver and HTML stamp for Supreme Page Tour steps.
 */
class PageTourAnchor {

	/**
	 * Data attribute written onto the highlighted module root.
	 */
	public const ATTR = 'data-dsm-tour-anchor';

	/**
	 * Theme Builder layout types excluded from v1 targeting.
	 *
	 * @var list<string>
	 */
	private const SKIP_LAYOUT_TYPES = array(
		'et_header_layout',
		'et_footer_layout',
	);

	/**
	 * Token to stamp-value map (stored target block ID).
	 *
	 * @var array<string, string>|null
	 */
	private static $map = null;

	/**
	 * Post ID the cached map was built from.
	 *
	 * @var int
	 */
	private static $map_post_id = 0;

	/**
	 * Register the inverted `render_block` stamp (same filter Popup uses).
	 *
	 * @return void
	 */
	public static function register(): void {
		add_filter( 'render_block', array( self::class, 'filter_render_block' ), 20, 3 );
	}

	/**
	 * Stamp the target module when this block's ID is in the pre-scan map.
	 *
	 * @param string               $content  Rendered HTML.
	 * @param array<string, mixed> $block    Parsed block.
	 * @param \WP_Block|null       $instance Block instance (Divi adds `id` / `orderIndex`).
	 * @return string
	 */
	public static function filter_render_block( $content, $block, $instance = null ) {
		if ( ! is_string( $content ) || '' === $content || ! is_array( $block ) ) {
			return is_string( $content ) ? $content : '';
		}

		$block_name = isset( $block['blockName'] ) ? (string) $block['blockName'] : '';
		if ( in_array( $block_name, array( 'dsm/page-tour', 'dsm/page-tour-step' ), true ) ) {
			return $content;
		}

		$layout_type = self::block_layout_type( $block, $instance );
		if ( in_array( $layout_type, self::SKIP_LAYOUT_TYPES, true ) ) {
			return $content;
		}

		$map = self::get_map();
		if ( array() === $map ) {
			return $content;
		}

		$stamp = self::match_stamp( $block, $instance, $map );
		if ( '' === $stamp ) {
			return $content;
		}

		return self::add_attr_to_module_root( $content, $stamp );
	}

	/**
	 * Token map of stored target block IDs for the current post.
	 *
	 * @return array<string, string>
	 */
	public static function get_map(): array {
		$post_id = (int) get_queried_object_id();
		if ( $post_id <= 0 ) {
			$post_id = (int) get_the_ID();
		}

		if ( is_array( self::$map ) && self::$map_post_id === $post_id ) {
			return self::$map;
		}

		self::$map         = array();
		self::$map_post_id = $post_id;

		if ( $post_id <= 0 ) {
			return self::$map;
		}

		$post = get_post( $post_id );
		if ( ! $post instanceof \WP_Post || ! is_string( $post->post_content ) ) {
			return self::$map;
		}

		$blocks = parse_blocks( $post->post_content );
		if ( is_array( $blocks ) ) {
			self::walk_blocks( $blocks, self::$map );
		}

		/**
		 * Filter the Page Tour target token map (token => stamp value).
		 *
		 * Theme Builder header/footer are not scanned in v1.
		 *
		 * @param array<string, string> $map     Token => stored target block ID.
		 * @param int                   $post_id Current post ID.
		 */
		self::$map = apply_filters( 'dsm_page_tour_anchor_map', self::$map, $post_id );

		return self::$map;
	}

	/**
	 * Walk parsed blocks on the current post (page content only).
	 *
	 * @param array<int, mixed>     $blocks Parsed blocks.
	 * @param array<string, string> $map    Token map (by ref).
	 * @return void
	 */
	private static function walk_blocks( array $blocks, array &$map ): void {
		foreach ( $blocks as $block ) {
			if ( ! is_array( $block ) ) {
				continue;
			}

			$name = isset( $block['blockName'] ) ? (string) $block['blockName'] : '';
			if ( 'dsm/page-tour-step' === $name ) {
				$attrs = isset( $block['attrs'] ) && is_array( $block['attrs'] ) ? $block['attrs'] : array();
				self::collect_step( $attrs, $map );
			}

			if ( isset( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) && array() !== $block['innerBlocks'] ) {
				self::walk_blocks( $block['innerBlocks'], $map );
			}

			if (
				isset( $block['innerHTML'] ) &&
				is_string( $block['innerHTML'] ) &&
				false !== strpos( $block['innerHTML'], 'wp:dsm/page-tour-step' )
			) {
				$nested = parse_blocks( $block['innerHTML'] );
				if ( is_array( $nested ) && array() !== $nested ) {
					self::walk_blocks( $nested, $map );
				}
			}
		}
	}

	/**
	 * Add a step's target tokens to the map when Target Mode is block.
	 *
	 * @param array<string, mixed>  $attrs Step attrs.
	 * @param array<string, string> $map   Token map (by ref).
	 * @return void
	 */
	private static function collect_step( array $attrs, array &$map ): void {
		$mode = self::inner_desktop_string( $attrs, 'target_mode' );
		if ( '' === $mode ) {
			$mode = 'block';
		}

		if ( 'block' !== $mode ) {
			return;
		}

		$tokens = array_values(
			array_unique(
				array_merge(
					self::tokens_from_raw( self::inner_desktop_string( $attrs, 'target_block_id' ) ),
					self::tokens_from_raw( self::inner_desktop_string( $attrs, 'target_render_id' ) )
				)
			)
		);

		if ( array() === $tokens ) {
			return;
		}

		$stamp = self::prefer_frontend_stamp( $tokens );
		if ( '' === $stamp ) {
			return;
		}

		foreach ( $tokens as $token ) {
			$map[ $token ] = $stamp;
		}
	}

	/**
	 * Split a stored picker / render-id string into sanitized tokens.
	 *
	 * Older saves may store a VB UUID; new saves store `divi/text-0`. A space-
	 * separated composite must not be passed through {@see sanitize_token()} whole
	 * (spaces are rejected).
	 *
	 * @param string $raw Raw innerContent value.
	 * @return list<string>
	 */
	private static function tokens_from_raw( string $raw ): array {
		$parts = preg_split( '/\s+/', trim( $raw ) );
		if ( ! is_array( $parts ) ) {
			return array();
		}

		$out = array();
		foreach ( $parts as $part ) {
			$token = self::sanitize_token( (string) $part );
			if ( '' !== $token ) {
				$out[] = $token;
			}
		}

		return $out;
	}

	/**
	 * Prefer `{blockName}-{orderIndex}` (what FE `parsed_block.id` uses).
	 *
	 * @param array $tokens Sanitized tokens.
	 * @return string
	 */
	private static function prefer_frontend_stamp( array $tokens ): string {
		foreach ( $tokens as $token ) {
			if ( 1 === preg_match( '/\/.+-\d+$/', $token ) ) {
				return $token;
			}
		}

		return isset( $tokens[0] ) ? (string) $tokens[0] : '';
	}

	/**
	 * Match this rendered block against the pre-scan map.
	 *
	 * @param array<string, mixed>  $block    Parsed block.
	 * @param \WP_Block|null        $instance Block instance.
	 * @param array<string, string> $map      Token map.
	 * @return string Stamp value or empty.
	 */
	private static function match_stamp( array $block, $instance, array $map ): string {
		foreach ( self::block_tokens( $block, $instance ) as $token ) {
			if ( isset( $map[ $token ] ) && '' !== $map[ $token ] ) {
				return $map[ $token ];
			}
		}

		return '';
	}

	/**
	 * Candidate IDs for the block being rendered.
	 *
	 * Frontend `BlockParserBlock` uses `{blockName}-{orderIndex}`. Visual Builder
	 * stores a UUID. Both are collected at pick time in `target_render_id`.
	 *
	 * @param array<string, mixed> $block    Parsed block.
	 * @param \WP_Block|null       $instance Block instance.
	 * @return list<string>
	 */
	private static function block_tokens( array $block, $instance ): array {
		$tokens = array();

		$parsed = array();
		if ( $instance instanceof \WP_Block && isset( $instance->parsed_block ) && is_array( $instance->parsed_block ) ) {
			$parsed = $instance->parsed_block;
		}

		if ( isset( $parsed['id'] ) && is_scalar( $parsed['id'] ) ) {
			$tokens[] = self::sanitize_token( (string) $parsed['id'] );
		}

		if ( isset( $block['id'] ) && is_scalar( $block['id'] ) ) {
			$tokens[] = self::sanitize_token( (string) $block['id'] );
		}

		$attrs  = isset( $block['attrs'] ) && is_array( $block['attrs'] ) ? $block['attrs'] : array();
		$unique = self::unique_id_from_attrs( $attrs );
		if ( '' !== $unique ) {
			$tokens[] = $unique;
		}

		$name        = isset( $block['blockName'] ) ? (string) $block['blockName'] : '';
		$order_index = null;
		if ( isset( $parsed['orderIndex'] ) && is_numeric( $parsed['orderIndex'] ) ) {
			$order_index = (int) $parsed['orderIndex'];
		}

		if ( '' !== $name && null !== $order_index ) {
			$tokens[] = self::sanitize_token( $name . '-' . $order_index );
		}

		$out = array();
		foreach ( $tokens as $token ) {
			if ( '' !== $token && ! in_array( $token, $out, true ) ) {
				$out[] = $token;
			}
		}

		return $out;
	}

	/**
	 * Layout type from the Divi-enriched parsed block.
	 *
	 * @param array<string, mixed> $block    Parsed block.
	 * @param \WP_Block|null       $instance Block instance.
	 * @return string
	 */
	private static function block_layout_type( array $block, $instance ): string {
		if ( $instance instanceof \WP_Block && isset( $instance->parsed_block['layout_type'] ) ) {
			return sanitize_key( (string) $instance->parsed_block['layout_type'] );
		}

		if ( isset( $block['layout_type'] ) ) {
			return sanitize_key( (string) $block['layout_type'] );
		}

		return '';
	}

	/**
	 * `module.advanced.uniqueId.desktop.value` when present.
	 *
	 * @param array<string, mixed> $attrs Block attrs.
	 * @return string
	 */
	private static function unique_id_from_attrs( array $attrs ): string {
		$raw = $attrs['module']['advanced']['uniqueId']['desktop']['value'] ?? '';
		if ( ! is_scalar( $raw ) ) {
			return '';
		}

		return self::sanitize_token( (string) $raw );
	}

	/**
	 * Desktop innerContent string (select / text leaf).
	 *
	 * @param array<string, mixed> $attrs Attrs.
	 * @param string               $key   Attribute key.
	 * @return string
	 */
	private static function inner_desktop_string( array $attrs, string $key ): string {
		if ( ! isset( $attrs[ $key ] ) || ! is_array( $attrs[ $key ] ) ) {
			return '';
		}

		$raw = $attrs[ $key ]['innerContent']['desktop']['value'] ?? '';
		if ( is_array( $raw ) && isset( $raw['text'] ) && is_scalar( $raw['text'] ) ) {
			$raw = $raw['text'];
		}

		if ( ! is_scalar( $raw ) ) {
			return '';
		}

		return trim( (string) $raw );
	}

	/**
	 * Allow block IDs (`divi/text-0`, UUIDs) and reject anything else.
	 *
	 * @param string $raw Raw token.
	 * @return string
	 */
	private static function sanitize_token( string $raw ): string {
		$token = trim( sanitize_text_field( $raw ) );
		if ( '' === $token ) {
			return '';
		}

		if ( 1 !== preg_match( '/^[A-Za-z0-9_:\-\/.]+$/', $token ) ) {
			return '';
		}

		return $token;
	}

	/**
	 * Inject `data-dsm-tour-anchor` on the first Divi module/section/row/column root.
	 *
	 * @param string $html  Module HTML (may start with `<style>`).
	 * @param string $stamp Stored target block ID.
	 * @return string
	 */
	private static function add_attr_to_module_root( string $html, string $stamp ): string {
		if ( false !== strpos( $html, self::ATTR . '=' ) ) {
			return $html;
		}

		$attr = sprintf( ' %s="%s"', self::ATTR, esc_attr( $stamp ) );

		$updated = preg_replace(
			'/(<(?:div|section|article|aside|header|footer|nav|ul|ol|li|figure|span)\b[^>]*\b(?:et_pb_section|et_pb_row|et_pb_column|et_pb_module|et_flex_module|et_grid_module)\b[^>]*)(>)/i',
			'$1' . $attr . '$2',
			$html,
			1
		);

		if ( is_string( $updated ) && $updated !== $html ) {
			return $updated;
		}

		$fallback = preg_replace(
			'/(<(?:div|section|article|aside)\b)([^>]*)(>)/i',
			'$1$2' . $attr . '$3',
			$html,
			1
		);

		return is_string( $fallback ) ? $fallback : $html;
	}
}
