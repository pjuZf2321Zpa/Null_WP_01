<?php
/**
 * Content Timeline Child Module.
 *
 * @package DiviSupreme.
 */

declare(strict_types=1);

namespace DiviSupreme\Modules;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\Module\Options\Element\ElementClassnames;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\ModuleUtils\ChildrenUtils;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;
use DiviSupreme\Extensions\IconLibraries\IconModuleRenderBridge;
use DiviSupreme\Extensions\IconLibraries\LegacyModuleIconStyles;
use DiviSupreme\Includes\Divi5Conversion\ConversionAttrs;
use DiviSupreme\Utils\HeadingLevel;


/**
 * Class that handles "ContentTimelineChild Module" module.
 */
class ContentTimelineChild implements DependencyInterface {



	/**
	 * Register module.
	 * `DependencyInterface` interface ensures class method name `load()` is executed for initialization.
	 */
	public function load() {
		add_action( 'init', array( self::class, 'register_module' ) );
	}

	/**
	 * Initilises the module.
	 *
	 * @return void
	 */
	public static function dsm_initialise() {
		add_action(
			'divi_module_library_modules_dependency_tree',
			function ( $dependency_tree ) {
				$dependency_tree->add_dependency( new self() );
			}
		);
	}

	/**
	 * Register module.
	 */
	public static function register_module() {

		$module_json_path = DSM_DIR_PATH . 'divi-5/public/packages/module-library/content-timeline-child';

		ModuleRegistration::register_module(
			$module_json_path,
			array(
				'render_callback' => array( self::class, 'render_callback' ),
			)
		);
	}

	/**
	 * Card icon style declaration.
	 *
	 * @param mixed $params Params.
	 */
	public static function card_icon_style_declaration( $params ) {
		return LegacyModuleIconStyles::build_pseudo_icon_declaration( $params );
	}


	/**
	 * Pointer icon style declaration.
	 *
	 * @param mixed $params Params.
	 */
	public static function pointer_icon_style_declaration( $params ) {
		return LegacyModuleIconStyles::build_pseudo_icon_declaration( $params );
	}

	/**
	 * Image icon align declaration.
	 *
	 * @param mixed $params Params.
	 */
	public static function image_icon_align_declaration( $params ) {
		$attr = $params['attrValue'] ?? array();

		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
				'important'  => array(
					'justify-content' => true,
				),
			)
		);

		$style_declarations->add( 'display', 'flex' );

		if ( 'left' === $attr ) {
			$style_declarations->add( 'justify-content', 'flex-start' );
		}

		if ( 'center' === $attr ) {
			$style_declarations->add( 'justify-content', 'center' );
		}

		if ( 'right' === $attr ) {
			$style_declarations->add( 'justify-content', 'flex-end' );
		}

		return $style_declarations->value();
	}

	/**
	 * Button alignment declaration.
	 *
	 * @param array $params - Parameters.
	 * @return string
	 */
	public static function button_align_declaration( $params ) {
		$attr = $params['attrValue'] ?? array();

		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
				'important'  => array(
					'text-align' => true,
				),
			)
		);

		if ( 'left' === $attr ) {
			$style_declarations->add( 'text-align', 'left' );
		}

		if ( 'center' === $attr ) {
			$style_declarations->add( 'text-align', 'center' );
		}

		if ( 'right' === $attr ) {
			$style_declarations->add( 'text-align', 'right' );
		}

		return $style_declarations->value();
	}

	/**
	 * Render module style.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_styles( $args ) {
		$args        = \DiviSupreme\Includes\DsmDiviBuilderCssScope::normalize_module_styles_args( $args );
		$order_class = (string) ( $args['orderClass'] ?? '' );
		$sc          = static function ( string $parent_chain, string $suffix = '' ) use ( $order_class ): string {
			return \DiviSupreme\Includes\DsmDiviBuilderCssScope::scoped_child_selector( $parent_chain, $order_class, $suffix );
		};
		$attrs       = $args['attrs'] ?? array();
		$elements    = $args['elements'];

		Style::add(
			array(
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => array(
					// Module.
					$elements->style(
						array(
							'attrName'   => 'module',
							'styleProps' => array(
								'disabledOn' => array(
									'disabledModuleVisibility' => $args['settings']['disabledModuleVisibility'] ?? null,
								),
							),
						)
					),

					CssStyle::style(
						array(
							'selector' => $args['orderClass'],
							'attr'     => $attrs['css'] ?? array(),
						)
					),

					$elements->style(
						array(
							'attrName' => 'header',
						)
					),

					$elements->style(
						array(
							'attrName' => 'content',
						)
					),

					$elements->style(
						array(
							'attrName' => 'opposite_text',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_card_margin',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_timeline_content_spacing',
						)
					),

					$elements->style(
						array(
							'attrName' => 'card_style',
						)
					),

					$elements->style(
						array(
							'attrName' => 'opposite_style',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_opposite_padding',
						)
					),

					$elements->style(
						array(
							'attrName' => 'opposite_text',
						)
					),

					$elements->style(
						array(
							'attrName' => 'image_icon_style',
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm-icon-wrapper .et-pb-icon.dsm-icon::before",
							'attr'                => $attrs['font_icon']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'card_icon_style_declaration' ),
						)
					),

					CommonStyle::style(
						array(
							'selector'            => '.dsm-content-timeline-items-wrapper .dsm-content-timeline-middle' . $args['orderClass'] . ' .et-pb-icon.dsm-icon::before',
							'attr'                => $attrs['dsm_point_font_icon']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'pointer_icon_style_declaration' ),
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-content-timeline-content-wrapper",
							'attr'     => $attrs['dsm_bg_color']['innerContent'] ?? array(),
							'property' => 'background-color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-content-timeline-content-wrapper, {$args['orderClass']} .dsm-image-wrapper",
							'attr'     => $attrs['dsm_horizontal_alignment']['innerContent'] ?? array(),
							'property' => 'text-align',
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .et_pb_button_module_wrapper",
							'attr'                => $attrs['button_alignment']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'button_align_declaration' ),
						)
					),

					CommonStyle::style(
						array(
							'selector' => $sc( '.dsm-content-timeline-items-wrapper', ' .dsm-content-timeline-date .date' ),
							'attr'     => $attrs['dsm_opposite_bg_color']['innerContent'] ?? array(),
							'property' => 'background-color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => $sc( '.dsm-content-timeline-items-wrapper', ' .dsm-content-timeline-date .date' ),
							'attr'     => $attrs['dsm_opposite_content_width']['innerContent'] ?? array(),
							'property' => 'width',
						)
					),

					CommonStyle::style(
						array(
							'selector' => $sc( '.dsm-content-timeline-items-wrapper', ' .dsm-icon-wrapper .et-pb-icon.dsm-icon' ),
							'attr'     => $attrs['dsm_icon_font_size']['innerContent'] ?? array(),
							'property' => 'font-size',
						)
					),

					CommonStyle::style(
						array(
							'selector' => $sc( '.dsm-content-timeline-items-wrapper', ' .dsm-image-wrapper .dsm-image' ),
							'attr'     => $attrs['dsm_image_width']['innerContent'] ?? array(),
							'property' => 'max-width',
						)
					),

					CommonStyle::style(
						array(
							'selector' => $sc( '.dsm-content-timeline-items-wrapper', ' .dsm-icon-wrapper .et-pb-icon.dsm-icon' ),
							'attr'     => $attrs['dsm_icon_color']['innerContent'] ?? array(),
							'property' => 'color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => $sc( '.dsm-content-timeline-items-wrapper', ' .dsm-icon-wrapper .et-pb-icon.dsm-icon' ),
							'attr'     => $attrs['dsm_icon_bg_color']['innerContent'] ?? array(),
							'property' => 'background-color',
						)
					),

					CommonStyle::style(
						array(
							'selector'            => $sc( '.dsm-content-timeline-items-wrapper', ' .dsm-image-wrapper' ) . ', ' . $sc( '.dsm-content-timeline-items-wrapper', ' .dsm-icon-wrapper' ),
							'attr'                => $attrs['dsm_icon_image_align']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'image_icon_align_declaration' ),
						)
					),
				),
			)
		);
	}

	/**
	 * Render module script data.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_script_data( $args ) {
		$elements = $args['elements'];

		// Element Script Data Options.
		$elements->script_data(
			array(
				'attrName' => 'module',
			)
		);
	}

	/**
	 * Render module classnames.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_classnames( $args ) {
		$classnames_instance             = $args['classnamesInstance'];
		$attrs                           = $args['attrs'];
		$dsm_icon_image_placement        = $attrs['dsm_icon_image_placement']['innerContent']['desktop']['value'] ?? 'top';
		$dsm_icon_image_placement_tablet = $attrs['dsm_icon_image_placement']['innerContent']['tablet']['value'] ?? '';
		$dsm_icon_image_placement_mobile = $attrs['dsm_icon_image_placement']['innerContent']['phone']['value'] ?? '';

		// Module.
		$classnames_instance->add(
			ElementClassnames::classnames(
				array(
					'attrs' => $attrs['module']['decoration'] ?? array(),
				)
			)
		);

		$classnames_instance->add( 'dsm-content-timeline-item' );
		$classnames_instance->add( "dsm-image-icon_placement-$dsm_icon_image_placement" );
		if ( ! empty( $dsm_icon_image_placement_tablet ) ) {
			$classnames_instance->add( "dsm-image-icon_placement-tablet-$dsm_icon_image_placement_tablet" );
		}
		if ( ! empty( $dsm_icon_image_placement_mobile ) ) {
			$classnames_instance->add( "dsm-image-icon_placement-phone-$dsm_icon_image_placement_mobile" );
		}
	}

	/**
	 * Normalize rich text attribute: string (legacy / migrated) or `{ text: string }` (Divi 5).
	 *
	 * @param mixed  $value Raw `innerContent.{breakpoint}.value`.
	 * @param string $fallback Default HTML when empty or invalid.
	 * @return string
	 */
	private static function normalize_rich_text_inner_value( $value, string $fallback ) {
		if ( is_string( $value ) ) {
			return $value;
		}
		if ( is_array( $value ) && isset( $value['text'] ) && is_string( $value['text'] ) ) {
			return $value['text'];
		}

		return $fallback;
	}

	/**
	 * Get order index.
	 *
	 * @param \WP_Block $block - Block.
	 * @return int - Order index.
	 */
	private static function get_order_index( $block ) {
		$parent      = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );
		$order_index = 0;

		foreach ( $parent->innerBlocks as $inner_block ) { // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- External object property.
			if ( $inner_block['id'] === $block->parsed_block['id'] ) {
				break;
			}
			++$order_index;
		}

		return $order_index;
	}

	/**
	 * Normalize upload innerContent to a URL string (legacy string or `{ src, id }`).
	 *
	 * @param mixed $raw Desktop innerContent value.
	 * @return string
	 */
	private static function resolve_upload_src_string( $raw ) {
		if ( is_string( $raw ) && '' !== $raw ) {
			return $raw;
		}
		if ( is_array( $raw ) ) {
			if ( isset( $raw['src'] ) && is_string( $raw['src'] ) && '' !== $raw['src'] ) {
				return $raw['src'];
			}
			if ( isset( $raw['url'] ) && is_string( $raw['url'] ) && '' !== $raw['url'] ) {
				return $raw['url'];
			}
		}
		return '';
	}

	/**
	 * Normalize timeline upload attrs at render time (D4 string URL, `{ url }`, or partial objects).
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 * @return array<string, mixed>
	 */
	private static function normalize_timeline_child_upload_attrs( array $attrs ): array {
		$normalized = $attrs;
		ConversionAttrs::normalize_upload_inner_content_to_object_value( $normalized, 'dsm_image' );
		ConversionAttrs::normalize_upload_inner_content_to_object_value( $normalized, 'dsm_point_image' );

		return $normalized;
	}

	/**
	 * Resolve attachment ID from upload field value.
	 *
	 * @param mixed $raw Desktop innerContent value.
	 * @return int
	 */
	private static function resolve_upload_attachment_id( $raw ) {
		if ( is_array( $raw ) && ! empty( $raw['id'] ) ) {
			return absint( $raw['id'] );
		}

		$url = self::resolve_upload_src_string( $raw );
		if ( '' === $url || 0 === strpos( $url, 'data:' ) ) {
			return 0;
		}

		if ( function_exists( 'et_get_attachment_id_by_url' ) ) {
			$found = (int) et_get_attachment_id_by_url( $url );
			return $found > 0 ? $found : 0;
		}

		$found = (int) attachment_url_to_postid( $url );
		return $found > 0 ? $found : 0;
	}

	/**
	 * Escape `src` for `<img>` (http(s) or `data:image/...`).
	 *
	 * @param string $src Source.
	 * @return string
	 */
	private static function escape_timeline_img_src_attribute( $src ) {
		if ( 0 === strpos( $src, 'data:image/' ) ) {
			return esc_attr( $src );
		}
		return esc_url( $src );
	}

	/**
	 * Responsive `<img>`: `wp_get_attachment_image` when a media ID is known; otherwise plain img + Divi srcset helper when available.
	 *
	 * @param mixed  $raw          Upload innerContent desktop value.
	 * @param string $fallback_alt Alt if attachment has no alt.
	 * @return string Safe HTML (empty when no src).
	 */
	private static function render_upload_image_html( $raw, $fallback_alt ) {
		$src = self::resolve_upload_src_string( $raw );
		if ( '' === $src ) {
			return '';
		}

		$fallback_alt  = is_string( $fallback_alt ) ? trim( $fallback_alt ) : '';
		$attachment_id = self::resolve_upload_attachment_id( $raw );

		if ( $attachment_id > 0 && wp_attachment_is_image( $attachment_id ) ) {
			$alt = get_post_meta( $attachment_id, '_wp_attachment_image_alt', true );
			$alt = is_string( $alt ) ? trim( $alt ) : '';
			if ( '' === $alt ) {
				$alt = $fallback_alt;
			}

			$img = wp_get_attachment_image(
				$attachment_id,
				'full',
				false,
				array(
					'alt'      => $alt,
					'decoding' => 'async',
					'loading'  => 'lazy',
				)
			);

			return is_string( $img ) ? $img : '';
		}

		$src_esc = self::escape_timeline_img_src_attribute( $src );

		$img_html = sprintf(
			'<img src="%1$s" alt="%2$s" decoding="async" loading="lazy" />',
			$src_esc,
			esc_attr( $fallback_alt )
		);

		if ( function_exists( 'et_image_add_srcset_and_sizes' ) ) {
			return et_image_add_srcset_and_sizes( $img_html, false );
		}

		return $img_html;
	}

	/**
	 * Render module HTML output.
	 *
	 * @param array     $attrs - Modules Attributes.
	 * @param string    $child_modules_content - Nested inner module HTML.
	 * @param \WP_Block $block - Block.
	 * @param mixed     $elements - Elements.
	 */
	public static function render_callback( $attrs, $child_modules_content, $block, $elements ) {
		$attrs              = self::normalize_timeline_child_upload_attrs( $attrs );
		$children_ids       = ChildrenUtils::extract_children_ids( $block );
		$has_nested_modules = '' !== trim( (string) $child_modules_content ) || ! empty( $children_ids );

		$parent       = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );
		$parent_attrs = $parent->attrs ?? array();
		$total_items  = count( $parent->innerBlocks ); // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- External object property.
		$order_index  = self::get_order_index( $block );

		$block_id_safe = preg_replace( '/[^a-zA-Z0-9_-]/', '-', (string) $block->parsed_block['id'] );
		$title_id      = 'dsm-timeline-title-' . $block_id_safe;

		$use_icon_image             = $attrs['dsm_use_icon_image']['innerContent']['desktop']['value'] ?? 'on';
		$raw_dsm_image              = $attrs['dsm_image']['innerContent']['desktop']['value'] ?? 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTA4MCIgaGVpZ2h0PSI1NDAiIHZpZXdCb3g9IjAgMCAxMDgwIDU0MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KICAgIDxnIGZpbGw9Im5vbmUiIGZpbGwtcnVsZT0iZXZlbm9kZCI+CiAgICAgICAgPHBhdGggZmlsbD0iI0VCRUJFQiIgZD0iTTAgMGgxMDgwdjU0MEgweiIvPgogICAgICAgIDxwYXRoIGQ9Ik00NDUuNjQ5IDU0MGgtOTguOTk1TDE0NC42NDkgMzM3Ljk5NSAwIDQ4Mi42NDR2LTk4Ljk5NWwxMTYuMzY1LTExNi4zNjVjMTUuNjItMTUuNjIgNDAuOTQ3LTE1LjYyIDU2LjU2OCAwTDQ0NS42NSA1NDB6IiBmaWxsLW9wYWNpdHk9Ii4xIiBmaWxsPSIjMDAwIiBmaWxsLXJ1bGU9Im5vbnplcm8iLz4KICAgICAgICA8Y2lyY2xlIGZpbGwtb3BhY2l0eT0iLjA1IiBmaWxsPSIjMDAwIiBjeD0iMzMxIiBjeT0iMTQ4IiByPSI3MCIvPgogICAgICAgIDxwYXRoIGQ9Ik0xMDgwIDM3OXYxMTMuMTM3TDcyOC4xNjIgMTQwLjMgMzI4LjQ2MiA1NDBIMjE1LjMyNEw2OTkuODc4IDU1LjQ0NmMxNS42Mi0xNS42MiA0MC45NDgtMTUuNjIgNTYuNTY4IDBMMTA4MCAzNzl6IiBmaWxsLW9wYWNpdHk9Ii4yIiBmaWxsPSIjMDAwIiBmaWxsLXJ1bGU9Im5vbnplcm8iLz4KICAgIDwvZz4KPC9zdmc+Cg==';
		$dsm_image_src              = self::resolve_upload_src_string( $raw_dsm_image );
		$header_level               = HeadingLevel::sanitize(
			$attrs['header']['decoration']['font']['font']['desktop']['value']['headingLevel'] ??
			$parent_attrs['header']['decoration']['font']['font']['desktop']['value']['headingLevel'] ?? 'h4',
			'h4'
		);
		$title_text                 = $attrs['dsm_title']['innerContent']['desktop']['value'] ?? '';
		$dsm_shortcode              = $attrs['dsm_shortcode']['innerContent']['desktop']['value'] ?? '';
		$dsm_content_type           = $attrs['dsm_content_type']['innerContent']['desktop']['value'] ?? 'custom';
		$raw_dsm_content            = $attrs['dsm_content']['innerContent']['desktop']['value'] ?? null;
		$dsm_content_html           = self::normalize_rich_text_inner_value(
			$raw_dsm_content,
			''
		);
		$dsm_opposite_text          = $attrs['dsm_opposite_text']['innerContent']['desktop']['value'] ?? '';
		$tree_animation             = $parent_attrs['dsm_tree_animation']['innerContent']['desktop']['value'] ?? 'off';
		$dsm_use_icon               = $attrs['dsm_use_icon']['innerContent']['desktop']['value'] ?? 'off';
		$button_text                = $attrs['button_text']['innerContent']['desktop']['value'] ?? '';
		$button_url                 = $attrs['button_url']['innerContent']['desktop']['value'] ?? '';
		$button_url_new_window      = $attrs['button_url_new_window']['innerContent']['desktop']['value'] ?? 'off';
		$dsm_use_pointer_element    = $attrs['dsm_use_pointer_element']['innerContent']['desktop']['value'] ?? 'off';
		$dsm_select_pointer_option  = $attrs['dsm_select_pointer_option']['innerContent']['desktop']['value'] ?? 'icon';
		$raw_dsm_point_image        = $attrs['dsm_point_image']['innerContent']['desktop']['value'] ?? '';
		$dsm_pointer_icon_font_size = $parent_attrs['dsm_pointer_icon_font_size']['innerContent']['desktop']['value'] ?? '';
		$dsm_point_font_icon        = $attrs['dsm_point_font_icon']['innerContent']['desktop']['value'] ?? array();
		$font_icon                  = $attrs['font_icon']['innerContent']['desktop']['value'] ?? array();
		$card_icon_settings         = is_array( $font_icon ) ? $font_icon : null;
		$pointer_icon_settings      = is_array( $dsm_point_font_icon ) ? $dsm_point_font_icon : null;

		$has_title_for_label  = ( 'custom' === $dsm_content_type && '' !== trim( (string) $title_text ) );
		$layout_display_value = $attrs['module']['decoration']['layout']['desktop']['value']['display'] ?? 'flex';
		$nestable_classes     = HTMLUtility::classnames(
			'dsm-timeline-nestable',
			array(
				'et_flex_module' => 'flex' === $layout_display_value,
				'et_grid_module' => 'grid' === $layout_display_value,
			)
		);
		$article_html_attrs   = array(
			'role' => 'article',
		);
		if ( $has_title_for_label ) {
			$article_html_attrs['aria-labelledby'] = $title_id;
		} else {
			$article_html_attrs['aria-label'] = sprintf(
				/* translators: 1: current item number (1-based), 2: total items */
				__( 'Timeline item %1$d of %2$d', 'dsm-supreme-modules-pro-for-divi' ),
				$order_index + 1,
				max( 1, $total_items )
			);
		}

		$container = '';

		ob_start();
		?>
		<div class="dsm-content-timeline-content-wrapper dsm-visibility">
			<?php if ( '' !== trim( (string) $dsm_opposite_text ) ) : ?>
				<div class="dsm-content-timeline-date dsm-mobile">
					<span class="date"><?php echo esc_html( $dsm_opposite_text ); ?></span>
				</div>
			<?php endif; ?>

			<?php if ( ( 'off' !== $use_icon_image && 'on' !== $dsm_use_icon ) && '' !== $dsm_image_src ) : ?>
				<div class="dsm-image-wrapper">
					<div class="dsm-image">
						<?php
						echo et_core_esc_previously(
							self::render_upload_image_html(
								$raw_dsm_image,
								__( 'Content Timeline Image', 'dsm-supreme-modules-pro-for-divi' )
							)
						);
						?>
					</div>
				</div>
			<?php endif; ?>

			<?php if ( ( 'off' !== $use_icon_image && 'on' === $dsm_use_icon ) ) : ?>
				<div class="dsm-icon-wrapper">
					<?php
					echo et_core_esc_previously(
						IconModuleRenderBridge::render_icon_host_markup(
							$card_icon_settings,
							array( 'dsm-icon' )
						)
					);
					?>
				</div>
			<?php endif; ?>

			<div class="dsm-timeline-content">
				<?php
				if ( 'custom' === $dsm_content_type ) {

					if ( $has_title_for_label ) {
						printf(
							'<%1$s class="dsm-title" id="%2$s">%3$s</%1$s>',
							esc_attr( $header_level ),
							esc_attr( $title_id ),
							esc_html( $title_text )
						);
					}

					if ( '' !== trim( $dsm_content_html ) ) {
						echo '<div class="dsm-description">' . wp_kses_post( $dsm_content_html ) . '</div>';
					}

					if ( ! empty( $button_text ) ) {
						echo '<div class="et_pb_button_module_wrapper">';
						echo '<a class="et_pb_button"';
						if ( '' !== $button_url ) {
							echo ' href="' . esc_url( $button_url ) . '"';
						}
						if ( 'on' === $button_url_new_window ) {
							echo ' target="_blank" rel="noopener noreferrer"';
						}
						echo '>' . esc_html( $button_text ) . '</a>';
						echo '</div>';
					}

					if ( $has_nested_modules && '' !== trim( (string) $child_modules_content ) ) {
						printf(
							'<div class="%1$s">%2$s</div>',
							esc_attr( $nestable_classes ),
							et_core_esc_previously( $child_modules_content )
						);
					}
				} else {
					$shortcode_html = \DiviSupreme\Includes\DiviLibraryLayoutRenderer::render_shortcode_field_content(
						is_string( $dsm_shortcode ) ? $dsm_shortcode : '',
						'dsm_content_timeline_shortcode_styles'
					);
					if ( '' !== $shortcode_html ) {
						echo et_core_esc_previously( $shortcode_html );
					}

					if ( $has_nested_modules && '' !== trim( (string) $child_modules_content ) ) {
						printf(
							'<div class="%1$s">%2$s</div>',
							esc_attr( $nestable_classes ),
							et_core_esc_previously( $child_modules_content )
						);
					}
				}
				?>
					</div>
			</div>
			<?php
			$container = ob_get_clean();

			// Module Inner.
			// Essentially, this is the module content.
			// Were wrapping the title and content in a div with class `et_pb_module_inner`.
			$module_inner = HTMLUtility::render(
				array(
					'tag'               => 'div',
					'attributes'        => array(
						'class' => 'et_pb_module_inner dsm-content-timeline-item-wrapper',
					),
					'childrenSanitizer' => 'et_core_esc_previously',
					'children'          => $container,
				)
			);

			// This are the module elements that will be rendered in the frontend.
			$module_elements = $elements->style_components(
				array(
					'attrName' => 'module',
				)
			);

			// This are the children of the module container, which are the module elements and the module inner.
			$module_container_children = $module_elements . $module_inner;

			$module_render = Module::render(
				array(
					// FE only.
					'orderIndex'          => $block->parsed_block['orderIndex'],
					'storeInstance'       => $block->parsed_block['storeInstance'],
					// VB equivalent.
					'attrs'               => $attrs,
					'elements'            => $elements,
					'id'                  => $block->parsed_block['id'],
					'moduleClassName'     => 'dsm_content_timeline_child',
					'name'                => $block->block_type->name,
					'classnamesFunction'  => function ( $args ) use ( $total_items, $order_index ) {
						self::module_classnames( $args );
						$args['classnamesInstance']->add(
							0 === ( $order_index % 2 ) ? 'dsm-timeline-index-even' : 'dsm-timeline-index-odd'
						);
						if ( $args['orderIndex'] === $total_items - 1 ) {
							$args['classnamesInstance']->add( 'dsm-last' );
						}
					},
					'styles'              => array(
						'--item-index' => (string) $order_index,
					),
					'moduleCategory'      => $block->block_type->category,
					'stylesComponent'     => array( self::class, 'module_styles' ),
					'scriptDataComponent' => array( self::class, 'module_script_data' ),
					'childrenIds'         => $children_ids,
					'children'            => $module_container_children,
					'htmlAttrs'           => $article_html_attrs,
				)
			);

			// Calculate pointer size.
			$pointer_size = '20px';

			// Add 20px to the existing font size.
			if ( ! empty( $dsm_point_font_icon ) && empty( $dsm_pointer_icon_font_size ) ) {
				$pointer_size = '40px';
			} elseif ( ! empty( $dsm_point_font_icon ) && ! empty( $dsm_pointer_icon_font_size ) ) {
				$pointer_size = ( intval( $dsm_pointer_icon_font_size ) + 20 ) . 'px';
			}

			$order_class          = 'dsm_content_timeline_child_' . $block->parsed_block['orderIndex'];
			$is_last_item         = ( $order_index === $total_items - 1 );
			$timeline_index_class = 0 === ( $order_index % 2 ) ? 'dsm-timeline-index-even' : 'dsm-timeline-index-odd';
			$middle_class         = 'dsm-content-timeline-middle ' . $order_class . ' ' . $timeline_index_class;

			// Add dsm-last-middle class if this is the last item.
			if ( $is_last_item ) {
				$middle_class .= ' dsm-last-middle';
			}

			$pointer_image_markup = '';
			if ( 'on' === $dsm_use_pointer_element && 'image' === $dsm_select_pointer_option ) {
				$point_img_html = self::render_upload_image_html(
					$raw_dsm_point_image,
					__( 'Content Timeline Pointer Image', 'dsm-supreme-modules-pro-for-divi' )
				);
				if ( '' !== $point_img_html ) {
					$pointer_image_markup = '<span class="dsm-image">' . $point_img_html . '</span>';
				}
			}

			$pointer_icon_markup = 'on' === $dsm_use_pointer_element && 'icon' === $dsm_select_pointer_option
				? IconModuleRenderBridge::render_icon_host_markup(
					$pointer_icon_settings,
					array( 'dsm-icon' )
				)
				: '';

			$middle_container = sprintf(
				'<div class="%6$s" style="--item-index: %1$s; --pointer-size: %2$s" aria-hidden="true">
				<div class="dsm-content-timeline-middle-circle">%3$s %4$s</div>
				<div class="dsm-content-timeline-middle-line"></div>
				%5$s
			</div>',
				$order_index,
				$pointer_size,
				$pointer_icon_markup,
				$pointer_image_markup,
				'on' === $tree_animation ? '<div class="dsm-content-timeline-tree-animation"></div>' : '',
				$middle_class
			);

			$opposite_hidden    = '' === trim( (string) $dsm_opposite_text ) ? ' aria-hidden="true"' : '';
			$opposite_container = sprintf(
				'<div class="%4$s dsm-content-timeline-opposite dsm-content-timeline-date dsm-desktop %3$s %6$s" style="--item-index: %1$s"%5$s><span class="date">%2$s</span></div>',
				$order_index,
				esc_html( (string) $dsm_opposite_text ),
				'' !== trim( (string) $dsm_opposite_text ) ? 'dsm-opposite-text' : '',
				$order_class,
				$opposite_hidden,
				$timeline_index_class
			);

			return $module_render . $middle_container . $opposite_container;
	}
}