<?php
/**
 * OnScrollHeaderAnimation Module.
 *
 * @package DiviSupreme.
 */

declare(strict_types=1);

namespace DiviSupreme\Modules;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\Module\Options\Element\ElementClassnames;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use ET\Builder\Packages\Module\Options\Text\TextStyle;
use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use DiviSupreme\Utils\HeadingLevel;

/**
 * Class that handles "OnScrollHeaderAnimation Module" module.
 *
 * Divi 5-only module: no Divi 4 shortcode and no D4→D5 conversion outline.
 */
class OnScrollHeaderAnimation implements DependencyInterface {

	/**
	 * Register module.
	 * `DependencyInterface` interface ensures class method name `load()` is executed for initialization.
	 */
	public function load() {
		add_action( 'init', array( self::class, 'register_module' ) );
	}

	/**
	 * Initilises the module.
	 *
	 * @return void
	 */
	public static function dsm_initialise() {
		add_action(
			'divi_module_library_modules_dependency_tree',
			function ( $dependency_tree ) {
				$dependency_tree->add_dependency( new self() );
			}
		);
	}

	/**
	 * Scroll image speed func.
	 *
	 * @param mixed $params Params.
	 */
	public static function scroll_image_speed_func( $params ) {
		$speed_value = $params['attrValue'] ?? array();

		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
				'important'  => array(
					'transition' => true,
				),
			)
		);

		$style_declarations->add( 'transition', "all $speed_value" );

		return $style_declarations->value();
	}

	/**
	 * Register module.
	 */
	public static function register_module() {

		$module_json_path = DSM_DIR_PATH . 'divi-5/public/packages/module-library/on-scroll-header-animation';

		ModuleRegistration::register_module(
			$module_json_path,
			array(
				'render_callback' => array( self::class, 'render_callback' ),
			)
		);
	}

	/**
	 * Render module style.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_styles( $args ) {
		$args     = \DiviSupreme\Includes\DsmDiviBuilderCssScope::normalize_module_styles_args( $args );
		$attrs    = $args['attrs'] ?? array();
		$elements = $args['elements'];

		Style::add(
			array(
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => array(
					// Module.
					$elements->style(
						array(
							'attrName'   => 'module',
							'styleProps' => array(
								'disabledOn' => array(
									'disabledModuleVisibility' => $args['settings']['disabledModuleVisibility'] ?? null,
								),
							),
						)
					),

					CssStyle::style(
						array(
							'selector' => $args['orderClass'],
							'attr'     => $attrs['css'] ?? array(),
						)
					),

					$elements->style(
						array(
							'attrName' => 'title',
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']}.dsm_scroll_image img",
							'attr'                => $attrs['scroll_image_speed']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'scroll_image_speed_func' ),
						)
					),
				),
			)
		);
	}

	/**
	 * Render module script data.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_script_data( $args ) {
		$elements = $args['elements'];

		// Element Script Data Options.
		$elements->script_data(
			array(
				'attrName' => 'module',
			)
		);
	}

	/**
	 * Render module classnames.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_classnames( $args ) {
		$classnames_instance = $args['classnamesInstance'];
		$attrs               = $args['attrs'];

		// Module.
		$classnames_instance->add(
			ElementClassnames::classnames(
				array(
					'attrs' => $attrs['module']['decoration'] ?? array(),
				)
			)
		);
	}

	/**
	 * Render module HTML output.
	 *
	 * @param array     $attrs - Modules Attributes.
	 * @param string    $content - Content.
	 * @param \WP_Block $block - Block.
	 * @param mixed     $elements - Elements.
	 */
	public static function render_callback( $attrs, $content, $block, $elements ) {
		$title            = $attrs['title']['innerContent']['desktop']['value'] ?? '';
		$heading_level    = HeadingLevel::sanitize(
			$attrs['title']['decoration']['font']['font']['desktop']['value']['headingLevel'] ?? 'h3',
			'h3'
		);
		$animation_effect = $attrs['animation_effect']['innerContent']['desktop']['value'] ?? 'effect_1';

		$animation_start_raw  = $attrs['animation_start_offset']['innerContent']['desktop']['value'] ?? '100%';
		$animation_start_attr = is_string( $animation_start_raw )
			? preg_replace( '/[^0-9.%]/', '', $animation_start_raw )
			: '100%';
		if ( '' === $animation_start_attr ) {
			$animation_start_attr = '100%';
		}

		wp_enqueue_script( 'dsm-gsap' );
		wp_enqueue_script( 'dsm-scroll-trigger' );
		wp_enqueue_script( 'dsm-splitting' );
		wp_enqueue_script( 'dsm-lenis' );
		wp_enqueue_script( 'dsm-scroll-header-animation' );

		$container = sprintf(
			'<div class="dsm-on-scroll-header-animation-wrapper" %2$s>
				%1$s
			</div>',
			'' !== $title ? sprintf( '<%2$s class="dsm-title">%1$s</%2$s>', $title, esc_attr( $heading_level ) ) : '',
			'' !== $title ? sprintf(
				'data-effect="%1$s" data-animation-start="%2$s"',
				esc_attr( $animation_effect ),
				esc_attr( $animation_start_attr )
			) : ''
		);

		// Module Inner.
		// Essentially, this is the module content.
		// Were wrapping the title and content in a div with class `et_pb_module_inner`.
		$module_inner = HTMLUtility::render(
			array(
				'tag'               => 'div',
				'attributes'        => array(
					'class' => 'et_pb_module_inner',
				),
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $container,
			)
		);

		// This are the module elements that will be rendered in the frontend.
		$module_elements = $elements->style_components(
			array(
				'attrName' => 'module',
			)
		);

		// This are the children of the module container, which are the module elements and the module inner.
		$module_container_children = $module_elements . $module_inner;

		return Module::render(
			array(
				// FE only.
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],
				'attrs'               => $attrs,
				'elements'            => $elements,
				'id'                  => $block->parsed_block['id'],
				'name'                => $block->block_type->name,
				'classnamesFunction'  => array( self::class, 'module_classnames' ),
				'moduleCategory'      => $block->block_type->category,
				'stylesComponent'     => array( self::class, 'module_styles' ),
				'scriptDataComponent' => array( self::class, 'module_script_data' ),
				'children'            => $module_container_children,
			)
		);
	}
}
