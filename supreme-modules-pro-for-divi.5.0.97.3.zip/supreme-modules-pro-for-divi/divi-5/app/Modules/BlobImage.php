<?php
/**
 * Blob Image Module.
 *
 * @package DiviSupreme.
 */

declare(strict_types=1);

namespace DiviSupreme\Modules;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\Module\Options\Element\ElementClassnames;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\Module\Options\Text\TextStyle;
use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;
use ET\Builder\Packages\Module\Options\Attributes\AttributeUtils;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use DiviSupreme\Includes\UploadImageMarkup;
use DiviSupreme\Includes\Divi5Conversion\ConversionAttrs;

/**
 * Class that handles the Supreme Blob Image module (D5).
 */
class BlobImage implements DependencyInterface {


	/**
	 * Default inline SVG shown when no image is set (matches Visual Builder placeholder).
	 */
	private const PLACEHOLDER_IMAGE_SRC = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTA4MCIgaGVpZ2h0PSI1NDAiIHZpZXdCb3g9IjAgMCAxMDgwIDU0MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KICAgIDxnIGZpbGw9Im5vbmUiIGZpbGwtcnVsZT0iZXZlbm9kZCI+CiAgICAgICAgPHBhdGggZmlsbD0iI0VCRUJFQiIgZD0iTTAgMGgxMDgwdjU0MEgweiIvPgogICAgICAgIDxwYXRoIGQ9Ik00NDUuNjQ5IDU0MGgtOTguOTk1TDE0NC42NDkgMzM3Ljk5NSAwIDQ4Mi42NDR2LTk4Ljk5NWwxMTYuMzY1LTExNi4zNjVjMTUuNjItMTUuNjIgNDAuOTQ3LTE1LjYyIDU2LjU2OCAwTDQ0NS42NSA1NDB6IiBmaWxsLW9wYWNpdHk9Ii4xIiBmaWxsPSIjMDAwIiBmaWxsLXJ1bGU9Im5vbnplcm8iLz4KICAgICAgICA8Y2lyY2xlIGZpbGwtb3BhY2l0eT0iLjA1IiBmaWxsPSIjMDAwIiBjeD0iMzMxIiBjeT0iMTQ4IiByPSI3MCIvPgogICAgICAgIDxwYXRoIGQ9Ik0xMDgwIDM3OXYxMTMuMTM3TDcyOC4xNjIgMTQwLjMgMzI4LjQ2MiA1NDBIMjE1LjMyNEw2OTkuODc4IDU1LjQ0NmMxNS42Mi0xNS42MiA0MC45NDgtMTUuNjIgNTYuNTY4IDBMMTA4MCAzNzl6IiBmaWxsLW9wYWNpdHk9Ii4yIiBmaWxsPSIjMDAwIiBmaWxsLXJ1bGU9Im5vbnplcm8iLz4KICAgIDwvZz4KPC9zdmc+Cg==';

	/**
	 * Register module (DependencyInterface entry).
	 *
	 * @return void
	 */
	public function load() {
		add_action( 'init', array( self::class, 'register_module' ) );
	}

	/**
	 * Initilises the module.
	 *
	 * @return void
	 */
	public static function dsm_initialise() {
		add_action(
			'divi_module_library_modules_dependency_tree',
			function ( $dependency_tree ) {
				$dependency_tree->add_dependency( new self() );
			}
		);
	}

	/**
	 * Register module with Divi 5.
	 *
	 * @return void
	 */
	public static function register_module() {
		$module_json_path = DSM_DIR_PATH . 'divi-5/public/packages/module-library/blob-image';

		ModuleRegistration::register_module(
			$module_json_path,
			array(
				'render_callback' => array( self::class, 'render_callback' ),
			)
		);
	}

	/**
	 * Render module style.
	 *
	 * @param array<string, mixed> $args Arguments from Divi (attrs, elements, orderClass, etc.).
	 * @return void
	 */
	public static function module_styles( $args ) {
		$args     = \DiviSupreme\Includes\DsmDiviBuilderCssScope::normalize_module_styles_args( $args );
		$attrs    = $args['attrs'] ?? array();
		$elements = $args['elements'];

		$use_gradient              = $attrs['use_gradient']['innerContent']['desktop']['value'] ?? '';
		$gradient_angle            = $attrs['gradient_angle']['innerContent']['desktop']['value'] ?? '';
		$fade_offset               = $attrs['fade_offset']['innerContent']['desktop']['value'] ?? '';
		$gradient_color_one        = $attrs['gradient_color_one']['innerContent']['desktop']['value'] ?? '';
		$gradient_color_one_offset = $attrs['gradient_color_one_offset']['innerContent']['desktop']['value'] ?? '';
		$gradient_color_two        = $attrs['gradient_color_two']['innerContent']['desktop']['value'] ?? '';
		$gradient_color_two_offset = $attrs['gradient_color_two_offset']['innerContent']['desktop']['value'] ?? '';

		$style_items = array(
			$elements->style(
				array(
					'attrName'   => 'module',
					'styleProps' => array(
						'disabledOn' => array(
							'disabledModuleVisibility' => $args['settings']['disabledModuleVisibility'] ?? null,
						),
					),
				)
			),
			CssStyle::style(
				array(
					'selector' => $args['orderClass'],
					'attr'     => $attrs['css'] ?? array(),
				)
			),
			TextStyle::style(
				array(
					'selector' => $args['orderClass'],
					'attr'     => $attrs['module']['advanced']['text'] ?? array(),
				)
			),
			$elements->style(
				array(
					'attrName' => 'blob_style',
				)
			),
			$elements->style(
				array(
					'attrName' => 'blob_title',
				)
			),
			$elements->style(
				array(
					'attrName' => 'blob_desc',
				)
			),
			$elements->style(
				array(
					'attrName' => 'overlay_content_padding',
				)
			),
			CommonStyle::style(
				array(
					'selector' => "{$args['orderClass']} .dsm_blob_image_wrap",
					'attr'     => $attrs['image_height']['innerContent'] ?? array(),
					'property' => 'height',
				)
			),
			CommonStyle::style(
				array(
					'selector' => "{$args['orderClass']} .dsm_blob_image_img",
					'attr'     => $attrs['blob_size']['innerContent'] ?? array(),
					'property' => 'object-fit',
				)
			),
			CommonStyle::style(
				array(
					'selector' => "{$args['orderClass']} .dsm_blob_image_img",
					'attr'     => $attrs['blob_position']['innerContent'] ?? array(),
					'property' => 'object-position',
				)
			),
			CommonStyle::style(
				array(
					'selector' => "{$args['orderClass']} .dsm_blob_image_overlay",
					'attr'     => $attrs['overlay_color']['innerContent'] ?? array(),
					'property' => 'background-color',
				)
			),
		);

		if ( 'on' === $use_gradient ) {
			$style_items[] = CommonStyle::style(
				array(
					'selector'            => "{$args['orderClass']} .dsm_blob_image_gradient_overlay",
					'attr'                => $attrs['gradient_color_one']['innerContent'] ?? array(),
					'declarationFunction' => function ( $params ) use ( $gradient_angle, $fade_offset, $gradient_color_one, $gradient_color_one_offset, $gradient_color_two, $gradient_color_two_offset ) {
						unset( $params );
						$style_declarations = new StyleDeclarations(
							array(
								'returnType' => 'string',
								'important'  => array(
									'background' => true,
								),
							)
						);

						$style_declarations->add(
							'background',
							'linear-gradient(' . $gradient_angle . "deg, {$gradient_color_one} {$gradient_color_one_offset}, {$fade_offset}, {$gradient_color_two} {$gradient_color_two_offset})"
						);

						return $style_declarations->value();
					},
				)
			);
		}

		Style::add(
			array(
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => $style_items,
			)
		);
	}

	/**
	 * Render module script data.
	 *
	 * @param array<string, mixed> $args Arguments.
	 * @return void
	 */
	public static function module_script_data( $args ) {
		$elements = $args['elements'];

		$elements->script_data(
			array(
				'attrName' => 'module',
			)
		);
	}

	/**
	 * Render module classnames.
	 *
	 * @param array<string, mixed> $args Arguments.
	 * @return void
	 */
	public static function module_classnames( $args ) {
		$classnames_instance = $args['classnamesInstance'];
		$attrs               = $args['attrs'];

		$classnames_instance->add(
			ElementClassnames::classnames(
				array(
					'attrs' => $attrs['module']['decoration'] ?? array(),
				)
			)
		);
	}

	/**
	 * Normalize rich-text / innerContent values to a flat string for Divi content rendering (wpautop expects string).
	 *
	 * @param mixed $value innerContent desktop value or nested `text` fragment.
	 * @return string
	 */
	private static function coerce_rich_text_inner_value_to_string( $value ) {
		if ( is_string( $value ) || is_numeric( $value ) ) {
			return (string) $value;
		}

		if ( ! is_array( $value ) ) {
			return '';
		}

		if ( isset( $value['text'] ) ) {
			return self::coerce_rich_text_inner_value_to_string( $value['text'] );
		}

		if ( isset( $value['content'] ) && is_string( $value['content'] ) ) {
			return $value['content'];
		}

		if ( isset( $value['innerHTML'] ) && is_string( $value['innerHTML'] ) ) {
			return $value['innerHTML'];
		}

		$pieces = array();
		foreach ( $value as $piece ) {
			if ( is_string( $piece ) || is_numeric( $piece ) ) {
				$pieces[] = (string) $piece;
				continue;
			}
			if ( is_array( $piece ) ) {
				$nested = self::coerce_rich_text_inner_value_to_string( $piece );
				if ( '' !== $nested ) {
					$pieces[] = $nested;
				}
			}
		}

		return implode( '', $pieces );
	}

	/**
	 * Custom attributes for `<img class="dsm_blob_image_img">` from Advanced → Attributes (target: blob_image).
	 *
	 * @param array $attrs Module attrs.
	 * @return array<string, string>
	 */
	private static function get_blob_image_target_attributes_from_decoration( array $attrs ): array {
		$dec = $attrs['module']['decoration']['attributes'] ?? array();
		if ( empty( $dec ) || ! is_array( $dec ) ) {
			return array();
		}

		$separated = AttributeUtils::separate_attributes_by_target_element( $dec );
		$blob      = $separated['blob_image'] ?? array();

		return is_array( $blob ) ? $blob : array();
	}

	/**
	 * Resolve effective alt text (decoration target `blob_image` overrides content `alt`).
	 *
	 * @param array $attrs Module attrs.
	 * @return string
	 */
	private static function resolve_blob_image_alt( array $attrs ): string {
		$extra = self::get_blob_image_target_attributes_from_decoration( $attrs );
		if ( isset( $extra['alt'] ) && is_scalar( $extra['alt'] ) ) {
			return trim( (string) $extra['alt'] );
		}

		return (string) ( $attrs['alt']['innerContent']['desktop']['value'] ?? '' );
	}

	/**
	 * Extra `<img>` attributes for decoration target `blob_image` (excluding `src` / `alt`).
	 *
	 * @param array $attrs Module attrs.
	 * @return array<string, string>
	 */
	private static function build_blob_image_img_extra_attributes( array $attrs ): array {
		$extra        = self::get_blob_image_target_attributes_from_decoration( $attrs );
		$legacy_title = (string) ( $attrs['title_text']['innerContent']['desktop']['value'] ?? '' );

		$img_attributes = array(
			'class' => 'dsm_blob_image_img',
		);

		foreach ( $extra as $key => $val ) {
			if ( ! is_string( $key ) || '' === $key || in_array( $key, array( 'class', 'src', 'alt' ), true ) ) {
				continue;
			}
			if ( ! is_scalar( $val ) ) {
				continue;
			}
			$s = trim( (string) $val );
			if ( '' === $s ) {
				continue;
			}
			$img_attributes[ $key ] = $s;
		}

		if ( ! isset( $img_attributes['title'] ) && '' !== $legacy_title ) {
			$img_attributes['title'] = $legacy_title;
		}

		return $img_attributes;
	}

	/**
	 * Render module HTML output.
	 *
	 * @param array<string, mixed> $attrs    Module attributes.
	 * @param string               $content  Inner blocks (unused).
	 * @param \WP_Block            $block    Block instance.
	 * @param mixed                $elements Style/render helpers.
	 * @return string
	 */
	public static function render_callback( $attrs, $content, $block, $elements ) {
		unset( $content );

		ConversionAttrs::ensure_heading_link_inner_content_for_module_elements( $attrs, $elements, 'blob_title' );
		ConversionAttrs::ensure_inner_content_text_shape_for_module_elements( $attrs, $elements, 'blob_desc' );

		$image_raw = $attrs['blob_image']['innerContent']['desktop']['value'] ?? '';
		if ( '' === UploadImageMarkup::resolve_upload_src_string( $image_raw ) ) {
			$image_raw = self::PLACEHOLDER_IMAGE_SRC;
		}

		$blob_shapes = $attrs['blob_shapes']['innerContent']['desktop']['value'] ?? '';

		$title_inner = $attrs['blob_title']['innerContent']['desktop']['value'] ?? array();
		$blob_title  = is_array( $title_inner ) ? (string) ( $title_inner['text'] ?? '' ) : (string) $title_inner;

		$blob_desc_val  = $attrs['blob_desc']['innerContent']['desktop']['value'] ?? null;
		$blob_desc_text = self::coerce_rich_text_inner_value_to_string( $blob_desc_val );

		$use_overlay        = $attrs['use_overlay']['innerContent']['desktop']['value'] ?? '';
		$use_gradient       = $attrs['use_gradient']['innerContent']['desktop']['value'] ?? '';
		$show_content_hover = $attrs['show_content_hover']['innerContent']['desktop']['value'] ?? '';
		$url                = (string) ( $attrs['url']['innerContent']['desktop']['value'] ?? '' );
		$url_new_window     = $attrs['url_new_window']['innerContent']['desktop']['value'] ?? '';

		$title = $elements->render(
			array(
				'attrName' => 'blob_title',
			)
		);

		$desc_markup = $elements->render(
			array(
				'attrName'      => 'blob_desc',
				'attrSubName'   => 'text',
				'valueResolver' => function ( $value, array $resolver_args ) {
					unset( $resolver_args );

					return self::coerce_rich_text_inner_value_to_string( $value );
				},
			)
		);

		$has_overlay_content = '' !== trim( $blob_title )
			|| '' !== trim( $blob_desc_text )
			|| ( is_string( $desc_markup ) && '' !== trim( wp_strip_all_tags( $desc_markup ) ) );

		$overlay_text = '';
		if ( $has_overlay_content ) {
			$overlay_text = sprintf(
				'<div class="dsm_blob_overlay_wrapper">
				  <div class="dsm_blob_overlay_text">
				    %1$s
					%2$s
				  </div>
				</div>',
				$title,
				$desc_markup
			);
		}

		$overlay_class = 'on' === $use_overlay ? ( 'off' === $use_gradient ? 'dsm_blob_image_overlay' : 'dsm_blob_image_gradient_overlay' ) : '';

		$wrap_classes = array(
			'dsm_blob_image_wrap',
			'dsm_blob_' . $blob_shapes,
		);
		if ( '' !== $overlay_class ) {
			$wrap_classes[] = $overlay_class;
		}
		if ( 'on' === $show_content_hover ) {
			$wrap_classes[] = 'dsm_blob_image_content_hover';
		}

		$img_tag = UploadImageMarkup::render_img_html(
			$image_raw,
			self::resolve_blob_image_alt( $attrs ),
			self::build_blob_image_img_extra_attributes( $attrs )
		);

		$container_inner = $img_tag . $overlay_text;

		$tag         = '' !== trim( $url ) ? 'a' : 'div';
		$href_attr   = '' !== trim( $url ) ? sprintf( 'href="%s" ', esc_url( $url ) ) : '';
		$target_attr = 'a' === $tag && 'on' === $url_new_window ? 'target="_blank" rel="noopener" ' : '';

		$container = sprintf(
			'<%1$s %2$s%3$s class="%4$s">%5$s</%1$s>',
			$tag,
			$href_attr,
			$target_attr,
			esc_attr( implode( ' ', $wrap_classes ) ),
			$container_inner
		);

		$module_inner = HTMLUtility::render(
			array(
				'tag'               => 'div',
				'attributes'        => array(
					'class' => 'et_pb_module_inner',
				),
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $container,
			)
		);

		$module_elements = $elements->style_components(
			array(
				'attrName' => 'module',
			)
		);

		$module_container_children = $module_elements . $module_inner;

		return Module::render(
			array(
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],
				'attrs'               => $attrs,
				'elements'            => $elements,
				'id'                  => $block->parsed_block['id'],
				'moduleClassName'     => 'dsm_blob_image',
				'name'                => $block->block_type->name,
				'classnamesFunction'  => array( self::class, 'module_classnames' ),
				'moduleCategory'      => $block->block_type->category,
				'stylesComponent'     => array( self::class, 'module_styles' ),
				'scriptDataComponent' => array( self::class, 'module_script_data' ),
				'children'            => $module_container_children,
			)
		);
	}
}
