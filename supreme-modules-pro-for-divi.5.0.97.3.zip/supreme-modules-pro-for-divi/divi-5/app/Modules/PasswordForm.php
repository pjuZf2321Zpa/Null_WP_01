<?php
/**
 * Password Form Module.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Modules;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use DiviSupreme\Extensions\PasswordProtection;
use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\Module\Options\Element\ElementClassnames;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\Packages\Module\Options\Css\CssStyle;

/**
 * Frontend Password Form module for Protection Library layouts.
 */
class PasswordForm implements DependencyInterface {

	/**
	 * Register module hooks.
	 *
	 * @return void
	 */
	public function load() {
		add_action( 'init', array( self::class, 'register_module' ) );
	}

	/**
	 * Initialise module dependency.
	 *
	 * @return void
	 */
	public static function dsm_initialise() {
		add_action(
			'divi_module_library_modules_dependency_tree',
			function ( $dependency_tree ) {
				$dependency_tree->add_dependency( new self() );
			}
		);
	}

	/**
	 * Register module with Divi.
	 *
	 * @return void
	 */
	public static function register_module() {
		$module_json_path = DSM_DIR_PATH . 'divi-5/public/packages/module-library/password-form';

		ModuleRegistration::register_module(
			$module_json_path,
			array(
				'render_callback' => array( self::class, 'render_callback' ),
			)
		);
	}

	/**
	 * Render module styles.
	 *
	 * @param array<string, mixed> $args Style args.
	 * @return void
	 */
	public static function module_styles( $args ) {
		$args     = \DiviSupreme\Includes\DsmDiviBuilderCssScope::normalize_module_styles_args( $args );
		$attrs    = $args['attrs'] ?? array();
		$elements = $args['elements'];

		Style::add(
			array(
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => array(
					$elements->style(
						array(
							'attrName'   => 'module',
							'styleProps' => array(
								'disabledOn' => array(
									'disabledModuleVisibility' => $args['settings']['disabledModuleVisibility'] ?? null,
								),
							),
						)
					),
					$elements->style(
						array(
							'attrName' => 'form_title',
						)
					),
					$elements->style(
						array(
							'attrName' => 'password_input',
						)
					),
					$elements->style(
						array(
							'attrName' => 'button',
						)
					),
					CssStyle::style(
						array(
							'selector' => $args['orderClass'],
							'attr'     => $attrs['css'] ?? array(),
						)
					),
				),
			)
		);
	}

	/**
	 * Render module classnames.
	 *
	 * @param array<string, mixed> $args Classname args.
	 * @return void
	 */
	public static function module_classnames( $args ) {
		$classnames_instance = $args['classnamesInstance'];
		$attrs               = $args['attrs'];

		$classnames_instance->add(
			ElementClassnames::classnames(
				array(
					'attrs' => $attrs['module']['decoration'] ?? array(),
				)
			)
		);
	}

	/**
	 * Render module script data.
	 *
	 * @param array<string, mixed> $args Script data args.
	 * @return void
	 */
	public static function module_script_data( $args ) {
		$elements = $args['elements'];
		$elements->script_data(
			array(
				'attrName' => 'module',
			)
		);
	}

	/**
	 * Render module HTML.
	 *
	 * @param array<string, mixed> $attrs    Module attributes.
	 * @param string               $content  Content.
	 * @param \WP_Block            $block    Block.
	 * @param mixed                $elements Elements helper.
	 * @return string
	 */
	public static function render_callback( $attrs, $content, $block, $elements ) {
		unset( $content );

		$title       = self::resolve_dynamic_text( self::get_heading_text( $attrs, 'form_title' ) );
		$button_text = self::resolve_dynamic_text(
			self::get_scalar_text( $attrs, 'button_text', __( 'Unlock', 'dsm-supreme-modules-pro-for-divi' ) )
		);
		$placeholder = self::resolve_dynamic_text(
			self::get_scalar_text( $attrs, 'placeholder', __( 'Enter password', 'dsm-supreme-modules-pro-for-divi' ) )
		);
		$layout      = self::get_form_layout( $attrs );
		$alignment   = self::get_button_alignment( $attrs );

		$scope   = 'sitewide';
		$post_id = 0;
		if (
			isset( $GLOBALS['dsm_password_protection_extension'] )
			&& $GLOBALS['dsm_password_protection_extension'] instanceof PasswordProtection
		) {
			$scope   = $GLOBALS['dsm_password_protection_extension']->get_form_scope();
			$post_id = $GLOBALS['dsm_password_protection_extension']->get_form_post_id();
		}

		$form_html = PasswordProtection::render_password_form_html(
			$title,
			$button_text,
			$placeholder,
			$scope,
			$post_id,
			$layout,
			$alignment,
			'',
			array(
				'button' => is_array( $attrs['button'] ?? null ) ? $attrs['button'] : array(),
			)
		);

		$module_inner = HTMLUtility::render(
			array(
				'tag'               => 'div',
				'attributes'        => array(
					'class' => 'et_pb_module_inner',
				),
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $form_html,
			)
		);

		$module_elements = $elements->style_components(
			array(
				'attrName' => 'module',
			)
		);

		$module_container_children = $module_elements . $module_inner;

		return Module::render(
			array(
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],
				'attrs'               => $attrs,
				'elements'            => $elements,
				'id'                  => $block->parsed_block['id'],
				'moduleClassName'     => 'dsm_password_form',
				'name'                => $block->block_type->name,
				'classnamesFunction'  => array( self::class, 'module_classnames' ),
				'moduleCategory'      => $block->block_type->category,
				'stylesComponent'     => array( self::class, 'module_styles' ),
				'scriptDataComponent' => array( self::class, 'module_script_data' ),
				'children'            => $module_container_children,
			)
		);
	}

	/**
	 * Resolve Divi Dynamic Content / `$variable(…)$` tokens for form copy fields.
	 *
	 * Used for Form Title, Button Text, and Input Placeholder only — never for
	 * password secrets.
	 *
	 * @param string $raw Raw attr value (may include `$variable(…)$`).
	 * @return string
	 */
	private static function resolve_dynamic_text( string $raw ): string {
		$text = $raw;

		if ( class_exists( \ET\Builder\Packages\StyleLibrary\Utils\Utils::class ) ) {
			$resolved = \ET\Builder\Packages\StyleLibrary\Utils\Utils::resolve_dynamic_variable( $text );
			if ( is_string( $resolved ) ) {
				$text = $resolved;
			}
		}

		/**
		 * Filters resolved Password Form copy (title / button / placeholder).
		 *
		 * @param string $text Resolved text.
		 * @param string $raw  Original stored value.
		 */
		$text = (string) apply_filters( 'dsm_password_form_resolve_dynamic_text', $text, $raw );

		return sanitize_text_field( $text );
	}

	/**
	 * Read headingLink text leaf (raw; may contain `$variable(…)$`).
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 * @param string               $key   Attribute key.
	 * @return string
	 */
	private static function get_heading_text( array $attrs, string $key ): string {
		$value = $attrs[ $key ]['innerContent']['desktop']['value'] ?? '';
		if ( is_array( $value ) && isset( $value['text'] ) ) {
			return (string) $value['text'];
		}
		if ( is_string( $value ) ) {
			return $value;
		}
		return '';
	}

	/**
	 * Read scalar innerContent text (raw; may contain `$variable(…)$`).
	 *
	 * @param array<string, mixed> $attrs          Module attrs.
	 * @param string               $key            Attribute key.
	 * @param string               $default_value  Default.
	 * @return string
	 */
	private static function get_scalar_text( array $attrs, string $key, string $default_value ): string {
		$value = $attrs[ $key ]['innerContent']['desktop']['value'] ?? '';
		if ( is_array( $value ) && isset( $value['text'] ) ) {
			$text = (string) $value['text'];
			return '' !== $text ? $text : $default_value;
		}
		if ( is_string( $value ) && '' !== $value ) {
			return $value;
		}
		return $default_value;
	}

	/**
	 * Resolve form layout (`inline`|`stacked`).
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 * @return string
	 */
	private static function get_form_layout( array $attrs ): string {
		$value = $attrs['form_layout']['innerContent']['desktop']['value'] ?? 'inline';
		if ( is_array( $value ) ) {
			$value = $value['text'] ?? 'inline';
		}
		$value = sanitize_key( (string) $value );
		return 'stacked' === $value ? 'stacked' : 'inline';
	}

	/**
	 * Resolve button alignment (`left`|`center`|`right`).
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 * @return string
	 */
	private static function get_button_alignment( array $attrs ): string {
		$value = $attrs['button_alignment']['innerContent']['desktop']['value'] ?? 'left';
		if ( is_array( $value ) ) {
			$value = $value['text'] ?? 'left';
		}
		$value = sanitize_key( (string) $value );
		if ( in_array( $value, array( 'center', 'right' ), true ) ) {
			return $value;
		}
		return 'left';
	}
}
