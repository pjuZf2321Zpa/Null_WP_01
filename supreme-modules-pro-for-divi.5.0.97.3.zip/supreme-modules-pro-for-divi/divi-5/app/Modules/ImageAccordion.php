<?php
/**
 * Image Accordion Module.
 *
 * @package DiviSupreme.
 */

declare(strict_types=1);

namespace DiviSupreme\Modules;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}


use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\Module\Options\Element\ElementClassnames;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Options\Element\ElementComponents;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;
use ET\Builder\Packages\Module\Options\Css\CssStyle;


/**
 * Class that handles "ImageAccordion Module" module.
 */
class ImageAccordion implements DependencyInterface {



	/**
	 * Register module.
	 * `DependencyInterface` interface ensures class method name `load()` is executed for initialization.
	 */
	public function load() {
		add_action( 'init', array( self::class, 'register_module' ) );
	}

	/**
	 * Initilises the module.
	 *
	 * @return void
	 */
	public static function dsm_initialise() {
		add_action(
			'divi_module_library_modules_dependency_tree',
			function ( $dependency_tree ) {
				$dependency_tree->add_dependency( new self() );
			}
		);
	}

	/**
	 * Register module.
	 */
	public static function register_module() {

		$module_json_path = DSM_DIR_PATH . 'divi-5/public/packages/module-library/image-accordion';

		ModuleRegistration::register_module(
			$module_json_path,
			array(
				'render_callback' => array( self::class, 'render_callback' ),
			)
		);
	}


	/**
	 * Image accordion direction declaration.
	 *
	 * @param mixed $params Params.
	 */
	public static function image_accordion_direction_declaration( $params ) {
		$direction_attr = $params['attrValue'] ?? array();

		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
				'important'  => array(
					'flex-direction' => true,
				),
			)
		);

		$direction_value = '';

		switch ( $direction_attr ) {
			case 'horizontal':
				$direction_value = 'row';
				break;
			case 'vertical':
				$direction_value = 'column';
				break;
		}

		$style_declarations->add( 'flex-direction', $direction_value );

		return $style_declarations->value();
	}

	/**
	 * Render module style.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_styles( $args ) {
		$args     = \DiviSupreme\Includes\DsmDiviBuilderCssScope::normalize_module_styles_args( $args );
		$attrs    = $args['attrs'] ?? array();
		$elements = $args['elements'];

		Style::add(
			array(
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => array(
					// Module.
					$elements->style(
						array(
							'attrName'   => 'module',
							'styleProps' => array(
								'disabledOn' => array(
									'disabledModuleVisibility' => $args['settings']['disabledModuleVisibility'] ?? null,
								),
							),
						)
					),

					CssStyle::style(
						array(
							'selector' => $args['orderClass'],
							'attr'     => $attrs['css'] ?? array(),
						)
					),

					$elements->style(
						array(
							'attrName' => 'ia_direction',
						)
					),

					$elements->style(
						array(
							'attrName' => 'ia_height',
						)
					),

					$elements->style(
						array(
							'attrName' => 'ia_icon_color',
						)
					),

					$elements->style(
						array(
							'attrName' => 'image_accordion_title',
						)
					),

					$elements->style(
						array(
							'attrName' => 'image_accordion_desc',
						)
					),

					$elements->style(
						array(
							'attrName' => 'image_accordion_overlay_title',
						)
					),

					$elements->style(
						array(
							'attrName' => 'overlay_color',
						)
					),

					$elements->style(
						array(
							'attrName' => 'image_icon',
						)
					),

					$elements->style(
						array(
							'attrName' => 'ia_icon_color',
						)
					),

					$elements->style(
						array(
							'attrName' => 'ia_icon_font_size',
						)
					),

					$elements->style(
						array(
							'attrName' => 'button',
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm_image_accordion_wrapper",
							'attr'                => $attrs['ia_direction']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'image_accordion_direction_declaration' ),
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm_image_accordion_wrapper",
							'attr'     => $attrs['ia_height']['innerContent'] ?? array(),
							'property' => 'height',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm_image_accordion_child:before",
							'attr'     => $attrs['overlay_color']['innerContent'] ?? array(),
							'property' => 'background',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm_image_accordion_child .dsm_image_accordion_overylay_content",
							'attr'     => $attrs['ia_overlay_align_horizontal']['innerContent'] ?? array(),
							'property' => 'justify-content',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm_image_accordion_child .dsm_image_accordion_overylay_content",
							'attr'     => $attrs['ia_overlay_align_vertical']['innerContent'] ?? array(),
							'property' => 'align-items',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm_image_accordion_child_content .et-pb-icon",
							'attr'     => $attrs['ia_icon_color']['innerContent'] ?? array(),
							'property' => 'color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm_image_accordion_child_content .dsm_image_accordion_image_icon_wrapper .et-pb-icon",
							'attr'     => $attrs['ia_icon_font_size']['innerContent'] ?? array(),
							'property' => 'font-size',
						)
					),
				),
			)
		);
	}

	/**
	 * Render module script data.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_script_data( $args ) {
		$elements = $args['elements'];

		// Element Script Data Options.
		$elements->script_data(
			array(
				'attrName' => 'module',
			)
		);
	}

	/**
	 * Render module classnames.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_classnames( $args ) {
		$classnames_instance    = $args['classnamesInstance'];
		$attrs                  = $args['attrs'];
		$content_animtion       = $attrs['image_accordion_animation']['innerContent']['desktop']['value'] ?? 'fade_in';
		$use_animation_sequence = $attrs['image_accordion_animation_sequence']['innerContent']['desktop']['value'] ?? 'off';

		// Module.
		$classnames_instance->add(
			ElementClassnames::classnames(
				array(
					'attrs' => $attrs['module']['decoration'] ?? array(),
				)
			),
		);

		$classnames_instance->add( 'dsm_image_accordion_animation_' . $content_animtion );
		$classnames_instance->add( 'dsm_image_accordion_animation_sequence_' . $use_animation_sequence );
	}

	/**
	 * Render module HTML output.
	 *
	 * @param array     $attrs - Modules Attributes.
	 * @param string    $content - Content.
	 * @param \WP_Block $block - Block.
	 * @param mixed     $elements - Elements.
	 */
	public static function render_callback( $attrs, $content, $block, $elements ) {
		$type_raw = null;
		if ( isset( $attrs['image_accordion_type']['innerContent']['desktop']['value'] ) ) {
			$type_raw = $attrs['image_accordion_type']['innerContent']['desktop']['value'];
		}
		$type = ( is_string( $type_raw ) && '' !== $type_raw ) ? $type_raw : 'on_hover';

		wp_enqueue_script( 'dsm-image-accordion' );

		$children_ids = $block->parsed_block['innerBlocks'] ? array_map(
			function ( $inner_block ) {
				return $inner_block['id'];
			},
			$block->parsed_block['innerBlocks']
		) : array();

		$parent       = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );
		$parent_attrs = $parent->attrs ?? array();

		$container = sprintf(
			'<div class="dsm_image_accordion_wrapper %2$s">%1$s</div>',
			$content,
			'on_hover' === $type ? 'dsm_image_accordion_trigger_on_hover' : 'dsm_image_accordion_trigger_on_click'
		);

		// Module Inner.
		// Essentially, this is the module content.
		// Were wrapping the title and content in a div with class `et_pb_module_inner`.
		$module_inner = HTMLUtility::render(
			array(
				'tag'               => 'div',
				'attributes'        => array(
					'class' => 'et_pb_module_inner',
				),
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $container,
			)
		);

		// This are the module elements that will be rendered in the frontend.
		$module_elements = $elements->style_components(
			array(
				'attrName' => 'module',
			)
		);

		// This are the children of the module container, which are the module elements and the module inner.
		$module_container_children = $module_elements . $module_inner;

		return Module::render(
			array(
				// FE only.
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],

				// VB equivalent.
				'attrs'               => $attrs,
				'parentAttrs'         => $parent_attrs,
				'elements'            => $elements,
				'id'                  => $block->parsed_block['id'],
				'moduleClassName'     => '',
				'name'                => $block->block_type->name,
				'classnamesFunction'  => array( self::class, 'module_classnames' ),
				'moduleCategory'      => $block->block_type->category,
				'stylesComponent'     => array( self::class, 'module_styles' ),
				'scriptDataComponent' => array( self::class, 'module_script_data' ),
				'children'            => ElementComponents::component(
					array(
						'attrs'         => $attrs['module']['decoration'] ?? array(),
						'id'            => $block->parsed_block['id'],

						// FE only.
						'orderIndex'    => $block->parsed_block['orderIndex'],
						'storeInstance' => $block->parsed_block['storeInstance'],
					)
				) . $module_container_children,
				'childrenIds'         => $children_ids,
			)
		);
	}
}
