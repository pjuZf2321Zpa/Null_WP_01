<?php
/**
 * Marquee Module.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Modules;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\Module\Options\Element\ElementClassnames;
use ET\Builder\Packages\Module\Options\Element\ElementComponents;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use DiviSupreme\Extensions\IconLibraries\LegacyModuleIconStyles;
use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;

/**
 * Class that handles the Supreme Marquee parent module.
 */
class Marquee implements DependencyInterface {

	/**
	 * Register module.
	 */
	public function load(): void {
		add_action( 'init', array( self::class, 'register_module' ) );
	}

	/**
	 * Initialise the module.
	 *
	 * @return void
	 */
	public static function dsm_initialise(): void {
		add_action(
			'divi_module_library_modules_dependency_tree',
			static function ( $dependency_tree ): void {
				$dependency_tree->add_dependency( new self() );
			}
		);
	}

	/**
	 * Register module.
	 *
	 * @return void
	 */
	public static function register_module(): void {
		$module_json_path = DSM_DIR_PATH . 'divi-5/public/packages/module-library/marquee';

		ModuleRegistration::register_module(
			$module_json_path,
			array(
				'render_callback' => array( self::class, 'render_callback' ),
			)
		);
	}

	/**
	 * CSS custom-property declaration for a range/select attr.
	 *
	 * @param mixed  $params   Style params from CommonStyle.
	 * @param string $property Custom property name.
	 * @return string
	 */
	public static function css_var_declaration( $params, string $property ): string {
		$declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
			)
		);

		$value = '';
		if ( is_array( $params ) && isset( $params['attrValue'] ) ) {
			$value = is_string( $params['attrValue'] ) ? $params['attrValue'] : '';
		}

		if ( '' !== $value ) {
			$declarations->add( $property, $value );
		}

		return $declarations->value();
	}

	/**
	 * Render module style.
	 *
	 * @param array<string, mixed> $args Style arguments.
	 * @return void
	 */
	public static function module_styles( array $args ): void {
		$args        = \DiviSupreme\Includes\DsmDiviBuilderCssScope::normalize_module_styles_args( $args );
		$attrs       = $args['attrs'] ?? array();
		$elements    = $args['elements'];
		$order_class = (string) ( $args['orderClass'] ?? '' );

		Style::add(
			array(
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => array(
					$elements->style(
						array(
							'attrName'   => 'module',
							'styleProps' => array(
								'disabledOn' => array(
									'disabledModuleVisibility' => $args['settings']['disabledModuleVisibility'] ?? null,
								),
							),
						)
					),
					CssStyle::style(
						array(
							'selector' => $order_class,
							'attr'     => $attrs['css'] ?? array(),
						)
					),
					$elements->style(
						array(
							'attrName' => 'text',
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $order_class,
							'attr'                => $attrs['item_gap']['innerContent'] ?? array(),
							'declarationFunction' => static function ( $params ) {
								return self::css_var_declaration( $params, '--dsm-marquee-item-gap' );
							},
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $order_class,
							'attr'                => $attrs['media_text_gap']['innerContent'] ?? array(),
							'declarationFunction' => static function ( $params ) {
								return self::css_var_declaration( $params, '--dsm-marquee-media-text-gap' );
							},
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $order_class,
							'attr'                => $attrs['logo_max_height']['innerContent'] ?? array(),
							'declarationFunction' => static function ( $params ) {
								return self::css_var_declaration( $params, '--dsm-marquee-logo-max-height' );
							},
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $order_class,
							'attr'                => $attrs['edge_fade_size']['innerContent'] ?? array(),
							'declarationFunction' => static function ( $params ) {
								return self::css_var_declaration( $params, '--dsm-marquee-fade-size' );
							},
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $order_class,
							'attr'                => $attrs['track_size']['innerContent'] ?? array(),
							'declarationFunction' => static function ( $params ) {
								return self::css_var_declaration( $params, '--dsm-marquee-track-size' );
							},
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $order_class,
							'attr'                => $attrs['item_align']['innerContent'] ?? array(),
							'declarationFunction' => static function ( $params ) {
								return self::css_var_declaration( $params, '--dsm-marquee-item-align' );
							},
						)
					),
					CommonStyle::style(
						array(
							'selector' => "{$order_class} .dsm_marquee_child_icon",
							'attr'     => $attrs['icon_color']['innerContent'] ?? array(),
							'property' => 'color',
						)
					),
					CommonStyle::style(
						array(
							'selector' => "{$order_class} .dsm_marquee_child_icon",
							'attr'     => $attrs['icon_font_size']['innerContent'] ?? array(),
							'property' => 'font-size',
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $order_class,
							'attr'                => $attrs['hover_speed_factor']['innerContent'] ?? array(),
							'declarationFunction' => static function ( $params ) {
								return self::css_var_declaration( $params, '--dsm-marquee-hover-speed-factor' );
							},
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $order_class,
							'attr'                => $attrs['logo_hover_scale']['innerContent'] ?? array(),
							'declarationFunction' => static function ( $params ) {
								return self::css_var_declaration( $params, '--dsm-marquee-logo-hover-scale' );
							},
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $order_class,
							'attr'                => $attrs['start_offset']['innerContent'] ?? array(),
							'declarationFunction' => static function ( $params ) {
								return self::css_var_declaration( $params, '--dsm-marquee-offset' );
							},
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $order_class,
							'attr'                => $attrs['twin_gap']['innerContent'] ?? array(),
							'declarationFunction' => static function ( $params ) {
								return self::css_var_declaration( $params, '--dsm-marquee-twin-gap' );
							},
						)
					),
					CommonStyle::style(
						array(
							'selector' => "{$order_class} .dsm_marquee_sep",
							'attr'     => $attrs['separator_color']['innerContent'] ?? array(),
							'property' => 'color',
						)
					),
					CommonStyle::style(
						array(
							'selector' => "{$order_class} .dsm_marquee_sep",
							'attr'     => $attrs['separator_size']['innerContent'] ?? array(),
							'property' => 'font-size',
						)
					),
					CommonStyle::style(
						array(
							'selector'            => "{$order_class} .dsm_marquee_sep_icon::after",
							'attr'                => $attrs['separator_icon']['innerContent'] ?? array(),
							'declarationFunction' => array( LegacyModuleIconStyles::class, 'build_pseudo_icon_declaration' ),
						)
					),
				),
			)
		);
	}

	/**
	 * Render module script data.
	 *
	 * @param array<string, mixed> $args Script data arguments.
	 * @return void
	 */
	public static function module_script_data( array $args ): void {
		$elements = $args['elements'];

		$elements->script_data(
			array(
				'attrName' => 'module',
			)
		);
	}

	/**
	 * Render module classnames.
	 *
	 * @param array<string, mixed> $args Classname arguments.
	 * @return void
	 */
	public static function module_classnames( array $args ): void {
		$classnames_instance = $args['classnamesInstance'];
		$attrs               = $args['attrs'];

		$classnames_instance->add(
			ElementClassnames::classnames(
				array(
					'attrs' => $attrs['module']['decoration'] ?? array(),
				)
			)
		);

		$direction      = self::inner_desktop_string( $attrs, 'direction', 'left' );
		$track_height   = self::inner_desktop_string( $attrs, 'track_height', 'auto' );
		$hover_action   = self::resolve_hover_action( $attrs );
		$edge_fade      = self::inner_desktop_string( $attrs, 'edge_fade', 'on' );
		$reduced_motion = self::inner_desktop_string( $attrs, 'reduced_motion', 'auto' );
		$separator      = self::inner_desktop_string( $attrs, 'separator', 'none' );
		$image_filter   = self::resolve_image_filter( $attrs );
		$twin_track     = self::inner_desktop_string( $attrs, 'twin_track', 'off' );
		$show_control   = self::inner_desktop_string( $attrs, 'show_pause_control', 'off' );

		if ( ! in_array( $direction, array( 'left', 'right', 'up', 'down' ), true ) ) {
			$direction = 'left';
		}

		if ( ! in_array( $track_height, array( 'auto', 'custom' ), true ) ) {
			$track_height = 'auto';
		}

		if ( ! in_array( $separator, array( 'none', 'dot', 'icon', 'text' ), true ) ) {
			$separator = 'none';
		}

		$classnames_instance->add( 'dsm_marquee' );
		$classnames_instance->add( 'dsm_marquee_dir_' . $direction );
		$classnames_instance->add( 'dsm_marquee_hover_' . $hover_action );

		if ( in_array( $direction, array( 'up', 'down' ), true ) ) {
			$classnames_instance->add( 'dsm_marquee_vertical' );
			$classnames_instance->add( 'dsm_marquee_height_' . $track_height );
		}

		if ( 'pause' === $hover_action ) {
			$classnames_instance->add( 'dsm_marquee_pause_hover' );
		}

		if ( 'on' === $edge_fade ) {
			$classnames_instance->add( 'dsm_marquee_fade' );
		}

		if ( 'auto' === $reduced_motion ) {
			$classnames_instance->add( 'dsm_marquee_reduced_auto' );
		}

		if ( 'none' !== $separator ) {
			$classnames_instance->add( 'dsm_marquee_sep_' . $separator );
		}

		if ( 'off' !== $image_filter ) {
			$classnames_instance->add( 'dsm_marquee_img_filter_' . $image_filter );
			$classnames_instance->add( 'dsm_marquee_img_hover_scale' );
		}

		if ( 'on' === $twin_track ) {
			$classnames_instance->add( 'dsm_marquee_twin' );
		}

		if ( 'on' === $show_control ) {
			$classnames_instance->add( 'dsm_marquee_has_control' );
		}
	}

	/**
	 * Track markup: source list plus one aria-hidden clone so CSS can loop if JS is late.
	 *
	 * @param string $content            Rendered child HTML (separators already injected).
	 * @param string $extra_track_class  Extra class for the track element.
	 * @return string
	 */
	private static function render_track_html( string $content, string $extra_track_class = '' ): string {
		$source_list = sprintf(
			'<ul class="dsm_marquee_list">%s</ul>',
			et_core_esc_previously( $content )
		);

		$clone_list = '' !== trim( $content )
			? sprintf(
				'<ul class="dsm_marquee_list" aria-hidden="true">%s</ul>',
				et_core_esc_previously( $content )
			)
			: '';

		$track_class = trim( 'dsm_marquee_track ' . $extra_track_class );

		return sprintf(
			'<div class="%1$s">%2$s%3$s</div>',
			esc_attr( $track_class ),
			$source_list,
			$clone_list
		);
	}

	/**
	 * Separator list item between children (outside item borders).
	 *
	 * @param array<string, mixed> $attrs Module attributes.
	 * @return string
	 */
	private static function render_separator_html( array $attrs ): string {
		$type = self::inner_desktop_string( $attrs, 'separator', 'none' );

		if ( ! in_array( $type, array( 'dot', 'icon', 'text' ), true ) ) {
			return '';
		}

		if ( 'icon' === $type ) {
			$icon_settings = $attrs['separator_icon']['innerContent']['desktop']['value'] ?? null;
			$icon          = is_array( $icon_settings )
				? LegacyModuleIconStyles::render_custom_icon_host( $icon_settings, 'dsm_marquee_sep_icon' )
				: '<span class="dsm_marquee_sep_icon" aria-hidden="true"></span>';

			/**
			 * Filter Supreme Marquee separator HTML.
			 *
			 * @param string               $separator_html Separator markup.
			 * @param array<string, mixed> $attrs          Module attributes.
			 */
			return apply_filters(
				'dsm_marquee_separator_html',
				sprintf( '<li class="dsm_marquee_sep" aria-hidden="true">%s</li>', $icon ),
				$attrs
			);
		}

		$text = 'dot' === $type
			? '·'
			: self::inner_desktop_string( $attrs, 'separator_text', '·' );

		return apply_filters(
			'dsm_marquee_separator_html',
			sprintf(
				'<li class="dsm_marquee_sep" aria-hidden="true"><span class="dsm_marquee_sep_text">%s</span></li>',
				esc_html( $text )
			),
			$attrs
		);
	}

	/**
	 * Insert a separator after every top-level child `</li>`.
	 *
	 * @param string $content  Concatenated child HTML.
	 * @param string $sep_html Separator markup.
	 * @return string
	 */
	private static function inject_separators( string $content, string $sep_html ): string {
		if ( '' === $sep_html || '' === trim( $content ) ) {
			return $content;
		}

		$injected = preg_replace( '/<\/li>/', '</li>' . $sep_html, $content );

		return is_string( $injected ) ? $injected : $content;
	}

	/**
	 * Image grayscale mode, with fallback to the legacy logo_hover on/off toggle.
	 *
	 * @param array<string, mixed> $attrs Module attributes.
	 * @return string
	 */
	private static function resolve_image_filter( array $attrs ): string {
		$value = self::inner_desktop_string( $attrs, 'logo_hover', 'color_on_hover' );

		if ( 'on' === $value ) {
			$value = 'color_on_hover';
		}

		if ( ! in_array( $value, array( 'off', 'color_on_hover', 'grayscale_on_hover', 'always' ), true ) ) {
			$value = 'color_on_hover';
		}

		/**
		 * Filter Supreme Marquee image grayscale mode.
		 *
		 * @param string               $value Image filter slug.
		 * @param array<string, mixed> $attrs Module attributes.
		 */
		return apply_filters( 'dsm_marquee_image_filter', $value, $attrs );
	}

	/**
	 * Hover interaction, with fallback to the legacy pause_on_hover toggle.
	 *
	 * @param array<string, mixed> $attrs Module attributes.
	 * @return string
	 */
	private static function resolve_hover_action( array $attrs ): string {
		$action = self::inner_desktop_string( $attrs, 'hover_action', '' );

		if ( in_array( $action, array( 'none', 'pause', 'reverse', 'speed_up' ), true ) ) {
			/**
			 * Filter Supreme Marquee hover interaction.
			 *
			 * @param string               $action Hover action slug.
			 * @param array<string, mixed> $attrs  Module attributes.
			 */
			return apply_filters( 'dsm_marquee_hover_action', $action, $attrs );
		}

		$legacy = self::inner_desktop_string( $attrs, 'pause_on_hover', 'on' );
		$mapped = 'off' === $legacy ? 'none' : 'pause';

		return apply_filters( 'dsm_marquee_hover_action', $mapped, $attrs );
	}

	/**
	 * Read a desktop innerContent string.
	 *
	 * @param array<string, mixed> $attrs    Module attrs.
	 * @param string               $key      Attribute key.
	 * @param string               $fallback Default when empty.
	 * @return string
	 */
	private static function inner_desktop_string( array $attrs, string $key, string $fallback = '' ): string {
		$raw = $attrs[ $key ]['innerContent']['desktop']['value'] ?? '';
		return is_string( $raw ) && '' !== $raw ? $raw : $fallback;
	}

	/**
	 * Render module HTML output.
	 *
	 * @param array<string, mixed> $attrs    Module attributes.
	 * @param string               $content  Child HTML.
	 * @param \WP_Block            $block    Block.
	 * @param mixed                $elements Elements.
	 * @return string
	 */
	public static function render_callback( $attrs, $content, $block, $elements ): string {
		$children_ids = $block->parsed_block['innerBlocks'] ? array_map(
			static function ( $inner_block ) {
				return $inner_block['id'];
			},
			$block->parsed_block['innerBlocks']
		) : array();

		$parent       = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );
		$parent_attrs = ( is_object( $parent ) && isset( $parent->attrs ) && is_array( $parent->attrs ) ) ? $parent->attrs : array();

		$speed           = self::inner_desktop_string( $attrs, 'speed', '40' );
		$speed_tablet    = is_string( $attrs['speed']['innerContent']['tablet']['value'] ?? null ) ? $attrs['speed']['innerContent']['tablet']['value'] : '';
		$speed_phone     = is_string( $attrs['speed']['innerContent']['phone']['value'] ?? null ) ? $attrs['speed']['innerContent']['phone']['value'] : '';
		$pause_offscreen = self::inner_desktop_string( $attrs, 'pause_offscreen', 'on' );
		$track_height    = self::inner_desktop_string( $attrs, 'track_height', 'auto' );
		$separator       = self::inner_desktop_string( $attrs, 'separator', 'none' );
		$separator_text  = self::inner_desktop_string( $attrs, 'separator_text', '·' );
		$twin_track      = self::inner_desktop_string( $attrs, 'twin_track', 'off' );
		$show_control    = self::inner_desktop_string( $attrs, 'show_pause_control', 'off' );

		if ( ! in_array( $track_height, array( 'auto', 'custom' ), true ) ) {
			$track_height = 'auto';
		}

		if ( ! in_array( $separator, array( 'none', 'dot', 'icon', 'text' ), true ) ) {
			$separator = 'none';
		}

		$sep_text         = 'dot' === $separator ? '·' : $separator_text;
		$content_with_sep = self::inject_separators( (string) $content, self::render_separator_html( $attrs ) );

		wp_enqueue_script( 'dsm-marquee' );

		/**
		 * Filter Supreme Marquee viewport attributes before render.
		 *
		 * @param array<string, string> $viewport_attributes Viewport HTML attributes.
		 * @param array<string, mixed>  $attrs               Module attributes.
		 */
		$viewport_attributes = apply_filters(
			'dsm_marquee_viewport_attrs',
			array(
				'class'                            => 'dsm_marquee_viewport',
				'role'                             => 'region',
				'aria-label'                       => __( 'Marquee', 'dsm-supreme-modules-pro-for-divi' ),
				'data-dsm-marquee-speed'           => $speed,
				'data-dsm-marquee-speed-tablet'    => $speed_tablet,
				'data-dsm-marquee-speed-phone'     => $speed_phone,
				'data-dsm-marquee-pause-offscreen' => $pause_offscreen,
				'data-dsm-marquee-height'          => $track_height,
				'data-dsm-marquee-sep'             => $separator,
				'data-dsm-marquee-sep-text'        => $sep_text,
			),
			$attrs
		);

		$viewport = HTMLUtility::render(
			array(
				'tag'               => 'div',
				'attributes'        => is_array( $viewport_attributes ) ? $viewport_attributes : array(),
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => self::render_track_html( $content_with_sep ),
			)
		);

		$twin_viewport = '';
		if ( 'on' === $twin_track ) {
			$twin_attributes          = is_array( $viewport_attributes ) ? $viewport_attributes : array();
			$twin_attributes['class'] = 'dsm_marquee_viewport dsm_marquee_viewport_twin';
			unset( $twin_attributes['role'], $twin_attributes['aria-label'] );
			$twin_attributes['aria-hidden'] = 'true';

			$twin_viewport = HTMLUtility::render(
				array(
					'tag'               => 'div',
					'attributes'        => $twin_attributes,
					'childrenSanitizer' => 'et_core_esc_previously',
					'children'          => self::render_track_html( $content_with_sep, 'dsm_marquee_track_twin' ),
				)
			);
		}

		$tracks = HTMLUtility::render(
			array(
				'tag'               => 'div',
				'attributes'        => array(
					'class' => 'dsm_marquee_tracks',
				),
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $viewport . $twin_viewport,
			)
		);

		$control = '';
		if ( 'on' === $show_control ) {
			$control = HTMLUtility::render(
				array(
					'tag'               => 'button',
					'attributes'        => array(
						'type'                         => 'button',
						'class'                        => 'dsm_marquee_control',
						'aria-pressed'                 => 'false',
						'aria-label'                   => __( 'Pause marquee', 'dsm-supreme-modules-pro-for-divi' ),
						'data-dsm-marquee-label-pause' => __( 'Pause marquee', 'dsm-supreme-modules-pro-for-divi' ),
						'data-dsm-marquee-label-play'  => __( 'Play marquee', 'dsm-supreme-modules-pro-for-divi' ),
					),
					'childrenSanitizer' => 'et_core_esc_previously',
					'children'          => '<span class="dsm_marquee_control_icon" aria-hidden="true"></span>',
				)
			);
		}

		$module_elements = $elements->style_components(
			array(
				'attrName' => 'module',
			)
		);

		return Module::render(
			array(
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],
				'attrs'               => $attrs,
				'parentAttrs'         => $parent_attrs,
				'elements'            => $elements,
				'id'                  => $block->parsed_block['id'],
				'moduleClassName'     => 'dsm_marquee',
				'name'                => $block->block_type->name,
				'classnamesFunction'  => array( self::class, 'module_classnames' ),
				'moduleCategory'      => $block->block_type->category,
				'stylesComponent'     => array( self::class, 'module_styles' ),
				'scriptDataComponent' => array( self::class, 'module_script_data' ),
				'children'            => ElementComponents::component(
					array(
						'attrs'         => $attrs['module']['decoration'] ?? array(),
						'id'            => $block->parsed_block['id'],
						'orderIndex'    => $block->parsed_block['orderIndex'],
						'storeInstance' => $block->parsed_block['storeInstance'],
					)
				) . $module_elements . $tracks . $control,
				'childrenIds'         => $children_ids,
			)
		);
	}
}
