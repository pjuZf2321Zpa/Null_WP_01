<?php
/**
 * Supreme Page Tour parent module (Divi 5).
 *
 * Registers the parent and hoists targeting via {@see PageTourAnchor}.
 * Overlay + tour JSON hoist to `wp_footer` (Popup pattern).
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Modules;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use ET\Builder\Packages\Module\Layout\Components\DynamicData\DynamicData;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\Module\Options\Element\ElementClassnames;
use ET\Builder\Packages\Module\Options\Loop\LoopContext;
use ET\Builder\Packages\Module\Options\Loop\LoopUtils;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\Packages\StyleLibrary\Declarations\BoxShadow\BoxShadow;
use ET\Builder\Packages\StyleLibrary\Declarations\Font\Font;
use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;

/**
 * Class that handles the Supreme Page Tour parent module.
 */
class PageTour implements DependencyInterface {

	/**
	 * Queued tour payloads for `wp_footer`.
	 *
	 * @var list<array<string, mixed>>
	 */
	private static $footer_tours = array();

	/**
	 * Whether the footer renderer is hooked.
	 *
	 * @var bool
	 */
	private static $footer_hooked = false;

	/**
	 * Tippy animation slugs (matches Design → Tippy Animation).
	 *
	 * @var list<string>
	 */
	private const TIPPY_ANIMATION_ALLOWLIST = array(
		'fade',
		'scale',
		'shift-away',
		'shift-toward',
		'perspective',
	);

	/**
	 * Register module hooks.
	 */
	public function load(): void {
		add_action( 'init', array( self::class, 'register_module' ) );
		PageTourAnchor::register();
	}

	/**
	 * Adds this module to Divi's module dependency tree.
	 */
	public static function dsm_initialise(): void {
		add_action(
			'divi_module_library_modules_dependency_tree',
			static function ( $dependency_tree ) {
				$dependency_tree->add_dependency( new self() );
			}
		);
	}

	/**
	 * Register module metadata and render callback.
	 */
	public static function register_module(): void {
		$module_json_path = DSM_DIR_PATH . 'divi-5/public/packages/module-library/page-tour';

		ModuleRegistration::register_module(
			$module_json_path,
			array(
				'render_callback' => array( self::class, 'render_callback' ),
			)
		);
	}

	/**
	 * Background-color declaration with !important (beats default SCSS).
	 *
	 * @param array<string, mixed> $params CommonStyle params.
	 * @return string
	 */
	public static function important_background_style_declaration( $params ): string {
		$attr_value = self::css_paint_from_attr_value( $params['attrValue'] ?? '' );
		if ( '' === $attr_value ) {
			return '';
		}

		$declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
				'important'  => array(
					'background-color' => true,
				),
			)
		);
		$declarations->add( 'background-color', $attr_value );

		return $declarations->value();
	}

	/**
	 * Font-size declaration for portaled nav button icons.
	 *
	 * @param array<string, mixed> $params CommonStyle params.
	 * @return string
	 */
	public static function font_size_style_declaration( $params ): string {
		$attr_value = $params['attrValue'] ?? '';
		if ( ! is_string( $attr_value ) || '' === trim( $attr_value ) ) {
			return '';
		}

		$declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
				'important'  => false,
			)
		);
		$declarations->add( 'font-size', trim( $attr_value ) );

		return $declarations->value();
	}

	/**
	 * Background-color declaration for portaled nav buttons.
	 *
	 * @param array<string, mixed> $params CommonStyle params.
	 * @return string
	 */
	public static function background_style_declaration( $params ): string {
		$attr_value = self::css_paint_from_attr_value( $params['attrValue'] ?? '' );
		if ( '' === $attr_value ) {
			return '';
		}

		$declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
				'important'  => false,
			)
		);
		$declarations->add( 'background-color', $attr_value );

		return $declarations->value();
	}

	/**
	 * Button-group font declaration for portaled Tippy buttons.
	 *
	 * @param array<string, mixed> $params CommonStyle params.
	 * @return string
	 */
	public static function nav_button_font_style_declaration( $params ): string {
		$attr_value = $params['attrValue'] ?? array();
		if ( ! is_array( $attr_value ) ) {
			return '';
		}

		$result = Font::style_declaration(
			array(
				'attr'       => $params['attr'] ?? array(),
				'attrValue'  => $attr_value,
				'important'  => false,
				'returnType' => 'string',
			)
		);

		return is_string( $result ) ? $result : '';
	}

	/**
	 * Button-group border for portaled Tippy buttons.
	 *
	 * @param array<string, mixed> $params CommonStyle params.
	 * @return string
	 */
	public static function nav_button_border_style_declaration( $params ): string {
		$value = $params['attrValue'] ?? array();
		if ( ! is_array( $value ) ) {
			return '';
		}

		$declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
				'important'  => false,
			)
		);

		$radius = isset( $value['radius'] ) && is_array( $value['radius'] ) ? $value['radius'] : array();
		$map    = array(
			'topLeft'     => 'border-top-left-radius',
			'topRight'    => 'border-top-right-radius',
			'bottomRight' => 'border-bottom-right-radius',
			'bottomLeft'  => 'border-bottom-left-radius',
		);

		foreach ( $map as $side => $prop ) {
			$part = $radius[ $side ] ?? '';
			if ( is_string( $part ) && '' !== trim( $part ) ) {
				$declarations->add( $prop, trim( $part ) );
			}
		}

		$all   = isset( $value['styles']['all'] ) && is_array( $value['styles']['all'] ) ? $value['styles']['all'] : array();
		$width = is_string( $all['width'] ?? null ) ? trim( (string) $all['width'] ) : '';
		$style = is_string( $all['style'] ?? null ) ? trim( (string) $all['style'] ) : '';
		$color = self::css_paint_from_attr_value( $all['color'] ?? '' );

		if ( '' !== $width ) {
			$declarations->add( 'border-width', $width );
			$declarations->add( 'border-style', '' !== $style ? $style : 'solid' );
			$declarations->add( 'border-color', '' !== $color ? $color : '#333' );
		} elseif ( '' !== $style ) {
			$declarations->add( 'border-style', $style );
		}

		return $declarations->value();
	}

	/**
	 * Popover box-shadow for the portaled Tippy box.
	 *
	 * @param array<string, mixed> $params CommonStyle params.
	 * @return string
	 */
	public static function popover_box_shadow_style_declaration( $params ): string {
		$attr_value = $params['attrValue'] ?? array();
		if ( ! is_array( $attr_value ) ) {
			return '';
		}

		$result = BoxShadow::style_declaration(
			array(
				'attrValue'  => $attr_value,
				'important'  => false,
				'returnType' => 'string',
			)
		);

		return is_string( $result ) ? $result : '';
	}

	/**
	 * `:after` / `:before` selectors for portaled nav button icons.
	 *
	 * @param string $button_selector Comma-separated button selectors.
	 * @return string
	 */
	public static function nav_button_icon_selector( string $button_selector ): string {
		$parts = array_filter( array_map( 'trim', explode( ',', $button_selector ) ) );
		$out   = array();

		foreach ( $parts as $part ) {
			if ( '' === $part ) {
				continue;
			}

			$out[] = $part . ':after';
			$out[] = $part . ':before';
		}

		return implode( ', ', $out );
	}

	/**
	 * Append a pseudo-class to every selector in a comma-separated list.
	 *
	 * @param string $button_selector Comma-separated button selectors.
	 * @param string $state           Pseudo-class such as `:hover`.
	 * @return string
	 */
	public static function nav_button_state_selector( string $button_selector, string $state ): string {
		$parts = array_filter( array_map( 'trim', explode( ',', $button_selector ) ) );
		$out   = array();

		foreach ( $parts as $part ) {
			if ( '' === $part ) {
				continue;
			}

			$out[] = $part . $state;
		}

		return implode( ', ', $out );
	}

	/**
	 * Portaled Next / Back / Skip selector (Tippy popper + tour root host).
	 *
	 * @param string $scope     Order-class token such as `.dsm_page_tour_0`.
	 * @param string $btn_class Button modifier, e.g. `.dsm-page-tour__btn--next`.
	 * @return string
	 */
	public static function nav_button_selector( string $scope, string $btn_class ): string {
		$button = ' .et_pb_button' . $btn_class;

		return $scope . '.dsm-page-tour__tippy' . $button . ', ' . $scope . '.dsm-page-tour__root' . $button . ', #dsm-page-tour-root' . $scope . $button;
	}

	/**
	 * Portaled overlay root (order class + `#dsm-page-tour-root` host).
	 *
	 * @param string $scope Order-class token such as `.dsm_page_tour_0`.
	 * @return string
	 */
	public static function portaled_root_selector( string $scope ): string {
		return $scope . '.dsm-page-tour__root, #dsm-page-tour-root' . $scope;
	}

	/**
	 * Portaled overlay child (dim, hole, …).
	 *
	 * @param string $scope Order-class token such as `.dsm_page_tour_0`.
	 * @param string $child Descendant selector, e.g. `.dsm-page-tour__hole`.
	 * @return string
	 */
	public static function portaled_child_selector( string $scope, string $child ): string {
		$part = ' ' . ltrim( $child );

		return $scope . '.dsm-page-tour__root' . $part . ', #dsm-page-tour-root' . $scope . $part;
	}

	/**
	 * CSS custom property for overlay color.
	 *
	 * @param array<string, mixed> $params CommonStyle params.
	 * @return string
	 */
	public static function overlay_var_style_declaration( $params ): string {
		$paint = self::css_paint_from_attr_value( $params['attrValue'] ?? '' );
		if ( '' === $paint ) {
			return '';
		}

		$declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
				'important'  => false,
			)
		);
		$declarations->add( '--dsm-page-tour-overlay', $paint );
		$result = $declarations->value();

		return is_string( $result ) ? $result : '';
	}

	/**
	 * CSS custom property for spotlight hole radius.
	 *
	 * @param array<string, mixed> $params CommonStyle params.
	 * @return string
	 */
	public static function hole_radius_var_style_declaration( $params ): string {
		$value = $params['attrValue'] ?? '';
		$paint = is_scalar( $value ) ? trim( (string) $value ) : self::css_paint_from_attr_value( $value );
		if ( '' === $paint || false !== strpos( $paint, '$variable(' ) ) {
			return '';
		}

		$declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
				'important'  => false,
			)
		);
		$declarations->add( '--dsm-page-tour-hole-radius', $paint );
		$result = $declarations->value();

		return is_string( $result ) ? $result : '';
	}

	/**
	 * Whether the Button-group Icon toggle is on (Divi default is on).
	 *
	 * @param array<string, mixed> $attrs     Parent module attrs.
	 * @param string               $attr_name `nav_primary` or `nav_secondary`.
	 * @return bool
	 */
	public static function nav_button_icon_is_on( array $attrs, string $attr_name ): bool {
		$raw = $attrs[ $attr_name ]['decoration']['button']['desktop']['value']['icon']['enable'] ?? 'on';

		return 'off' !== strtolower( (string) $raw );
	}

	/**
	 * Whether the Button-group icon is reserved for hover (Divi default is on).
	 *
	 * @param array<string, mixed> $attrs     Parent module attrs.
	 * @param string               $attr_name `nav_primary` or `nav_secondary`.
	 * @return bool
	 */
	public static function nav_button_icon_shows_on_hover( array $attrs, string $attr_name ): bool {
		$raw = $attrs[ $attr_name ]['decoration']['button']['desktop']['value']['icon']['onHover'] ?? 'on';

		return 'off' !== strtolower( (string) $raw );
	}

	/**
	 * Button-group icon placement (`left` or `right`).
	 *
	 * @param array<string, mixed> $attrs     Parent module attrs.
	 * @param string               $attr_name `nav_primary` or `nav_secondary`.
	 * @return string
	 */
	public static function nav_button_icon_placement( array $attrs, string $attr_name ): string {
		$raw = $attrs[ $attr_name ]['decoration']['button']['desktop']['value']['icon']['placement'] ?? 'right';

		return 'left' === strtolower( (string) $raw ) ? 'left' : 'right';
	}

	/**
	 * Merge Button icon + Spacing padding for hover-padding declarations.
	 *
	 * @param array<string, mixed> $attrs     Parent module attrs.
	 * @param string               $attr_name `nav_primary` or `nav_secondary`.
	 * @return array<string, mixed>
	 */
	public static function nav_button_spacing_icon_attr( array $attrs, string $attr_name ): array {
		$button  = $attrs[ $attr_name ]['decoration']['button'] ?? array();
		$spacing = $attrs[ $attr_name ]['decoration']['spacing'] ?? array();
		if ( ! is_array( $button ) ) {
			$button = array();
		}
		if ( ! is_array( $spacing ) ) {
			$spacing = array();
		}

		$out = $button;
		foreach ( array( 'desktop', 'tablet', 'phone' ) as $breakpoint ) {
			$icon    = $button[ $breakpoint ]['value']['icon'] ?? ( $button['desktop']['value']['icon'] ?? array() );
			$padding = $spacing[ $breakpoint ]['value']['padding'] ?? array();
			if ( ! isset( $out[ $breakpoint ] ) || ! is_array( $out[ $breakpoint ] ) ) {
				$out[ $breakpoint ] = array();
			}
			if ( ! isset( $out[ $breakpoint ]['value'] ) || ! is_array( $out[ $breakpoint ]['value'] ) ) {
				$out[ $breakpoint ]['value'] = array();
			}
			$out[ $breakpoint ]['value']['icon']    = is_array( $icon ) ? $icon : array();
			$out[ $breakpoint ]['value']['padding'] = is_array( $padding ) ? $padding : array();
		}

		return $out;
	}

	/**
	 * Extra left/right padding when the icon appears on hover (Divi Button).
	 *
	 * @param array<string, mixed> $params CommonStyle params.
	 * @return string
	 */
	public static function nav_button_icon_hover_padding_declaration( $params ): string {
		$value = $params['attrValue'] ?? array();
		if ( ! is_array( $value ) ) {
			return '';
		}

		$icon      = isset( $value['icon'] ) && is_array( $value['icon'] ) ? $value['icon'] : array();
		$enable    = strtolower( (string) ( $icon['enable'] ?? 'on' ) );
		$on_hover  = strtolower( (string) ( $icon['onHover'] ?? 'on' ) );
		$placement = strtolower( (string) ( $icon['placement'] ?? 'right' ) );
		$padding   = isset( $value['padding'] ) && is_array( $value['padding'] ) ? $value['padding'] : array();

		if ( 'on' !== $enable || 'off' === $on_hover ) {
			return '';
		}

		return self::nav_button_icon_side_padding_css( $placement, $padding );
	}

	/**
	 * Extra left/right padding when the icon is always visible.
	 *
	 * @param array<string, mixed> $params CommonStyle params.
	 * @return string
	 */
	public static function nav_button_icon_always_padding_declaration( $params ): string {
		$value = $params['attrValue'] ?? array();
		if ( ! is_array( $value ) ) {
			return '';
		}

		$icon      = isset( $value['icon'] ) && is_array( $value['icon'] ) ? $value['icon'] : array();
		$enable    = strtolower( (string) ( $icon['enable'] ?? 'on' ) );
		$on_hover  = strtolower( (string) ( $icon['onHover'] ?? 'on' ) );
		$placement = strtolower( (string) ( $icon['placement'] ?? 'right' ) );
		$padding   = isset( $value['padding'] ) && is_array( $value['padding'] ) ? $value['padding'] : array();

		if ( 'on' !== $enable || 'off' !== $on_hover ) {
			return '';
		}

		return self::nav_button_icon_side_padding_css( $placement, $padding );
	}

	/**
	 * Divi icon-room padding: 2em on the icon side, 0.7em on the other.
	 *
	 * @param string               $placement `left` or `right`.
	 * @param array<string, mixed> $padding   Existing spacing padding.
	 * @return string
	 */
	public static function nav_button_icon_side_padding_css( string $placement, array $padding ): string {
		$is_left            = 'left' === $placement;
		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
				'important'  => false,
			)
		);

		$right = isset( $padding['right'] ) && '' !== (string) $padding['right']
			? (string) $padding['right']
			: ( $is_left ? '0.7em' : '2em' );
		$left  = isset( $padding['left'] ) && '' !== (string) $padding['left']
			? (string) $padding['left']
			: ( $is_left ? '2em' : '0.7em' );

		$style_declarations->add( 'padding-right', $right );
		$style_declarations->add( 'padding-left', $left );

		$result = $style_declarations->value();

		return is_string( $result ) ? $result : '';
	}

	/**
	 * Processed `data-icon` / `data-icon-*` map for a nav button (Card / ButtonModule).
	 *
	 * @param array<string, mixed> $attrs     Parent module attrs.
	 * @param string               $attr_name `nav_primary` or `nav_secondary`.
	 * @return array<string, string>
	 */
	public static function nav_button_icon_data_attrs( array $attrs, string $attr_name ): array {
		$button = $attrs[ $attr_name ] ?? null;
		if ( ! is_array( $button ) ) {
			return array();
		}

		$icon_enable_raw   = $button['decoration']['button']['desktop']['value']['icon']['enable'] ?? 'on';
		$is_icon_enabled   = 'off' !== strtolower( (string) $icon_enable_raw );
		$button_decoration = $button['decoration']['button'] ?? array();
		if ( ! $is_icon_enabled || ! is_array( $button_decoration ) ) {
			return array();
		}

		$out = array();
		foreach ( $button_decoration as $breakpoint => $breakpoint_value ) {
			if ( ! is_array( $breakpoint_value ) ) {
				continue;
			}

			$icon_settings = $breakpoint_value['value']['icon']['settings'] ?? null;
			if ( is_string( $icon_settings ) && '' !== trim( $icon_settings ) ) {
				$icon_settings = array( 'unicode' => $icon_settings );
			}
			if ( ! is_array( $icon_settings ) ) {
				continue;
			}

			$processed_icon = Utils::process_font_icon( $icon_settings );
			if ( '' === $processed_icon || null === $processed_icon ) {
				continue;
			}

			$bp = is_string( $breakpoint ) ? $breakpoint : (string) $breakpoint;
			if ( 'desktop' === $bp ) {
				$data_attr_name = 'data-icon';
			} else {
				$data_attr_name = 'data-icon-' . strtolower( (string) preg_replace( '/([A-Z])/', '-$1', $bp ) );
			}

			$out[ $data_attr_name ] = (string) $processed_icon;
		}

		return $out;
	}

	/**
	 * Printed nav-button defaults for `elements.style` — border only.
	 *
	 * Background / font must not be printed defaults or the VB will not
	 * re-emit user Button-group colors.
	 *
	 * @param string $attr_name `nav_primary` or `nav_secondary`.
	 * @return array<string, mixed>
	 */
	public static function nav_button_default_printed_style_attrs( string $attr_name ): array {
		static $defaults = null;

		if ( null === $defaults ) {
			$path = DSM_DIR_PATH . 'divi-5/public/packages/module-library/page-tour/module-default-render-attributes.json';
			if ( ! is_readable( $path ) ) {
				$defaults = array();
			} else {
				$decoded  = wp_json_file_decode( $path, array( 'associative' => true ) );
				$defaults = is_array( $decoded ) ? $decoded : array();
			}
		}

		$border = $defaults[ $attr_name ]['decoration']['border'] ?? null;

		return is_array( $border ) ? array( 'border' => $border ) : array();
	}

	/**
	 * Style props so portaled Tippy buttons receive Divi button decoration.
	 *
	 * @param string $selector  Portaled button selector.
	 * @param string $attr_name `nav_primary` or `nav_secondary`.
	 * @return array<string, mixed>
	 */
	public static function nav_button_style_props( string $selector, string $attr_name ): array {
		return array(
			'selector'                 => $selector,
			'defaultPrintedStyleAttrs' => self::nav_button_default_printed_style_attrs( $attr_name ),
			'font'                     => array(
				'selector' => $selector,
			),
			'spacing'                  => array(
				'selector' => $selector,
			),
			'background'               => array(
				'selector' => $selector,
			),
			'border'                   => array(
				'selector' => $selector,
			),
			'boxShadow'                => array(
				'selector' => $selector,
			),
			'button'                   => array(
				'selector' => $selector,
			),
		);
	}

	/**
	 * Tour scope class.
	 *
	 * @param array $args   Args.
	 * @return string
	 */
	public static function tour_scope_class( array $args ): string {
		$candidates = array(
			$args['baseOrderClass'] ?? '',
			$args['orderClass'] ?? '',
		);

		foreach ( $candidates as $candidate ) {
			if ( ! is_string( $candidate ) || '' === $candidate ) {
				continue;
			}

			$token = self::last_order_class_token( $candidate );
			if ( '' !== $token ) {
				return $token;
			}
		}

		return '.dsm_page_tour_' . (int) ( $args['orderIndex'] ?? 0 );
	}

	/**
	 * Last class token from a Divi order-class selector (portaled overlay / Tippy).
	 *
	 * @param string $selector Full `orderClass` or `baseOrderClass`.
	 * @return string Selector such as `.dsm_page_tour_0`.
	 */
	public static function last_order_class_token( string $selector ): string {
		$trimmed = trim( $selector );
		if ( '' === $trimmed ) {
			return '';
		}

		$parts = preg_split( '/\s+/', $trimmed );
		$last  = is_array( $parts ) ? (string) end( $parts ) : $trimmed;
		$bits  = array_values( array_filter( explode( '.', $last ) ) );
		$token = isset( $bits[ count( $bits ) - 1 ] ) ? (string) $bits[ count( $bits ) - 1 ] : '';

		return '' !== $token ? '.' . $token : '';
	}

	/**
	 * ColorPicker / CommonStyle leaf to a CSS color string.
	 *
	 * @param mixed $attr_value Raw attr value.
	 * @return string
	 */
	public static function css_paint_from_attr_value( $attr_value ): string {
		if ( is_string( $attr_value ) ) {
			$paint = trim( $attr_value );
			if ( '' === $paint || false !== strpos( $paint, '$variable(' ) ) {
				return '';
			}

			return $paint;
		}

		if ( is_array( $attr_value ) ) {
			if ( isset( $attr_value['color'] ) && '' !== $attr_value['color'] && false !== $attr_value['color'] ) {
				return self::css_paint_from_attr_value( $attr_value['color'] );
			}

			if ( isset( $attr_value['hex'] ) && is_string( $attr_value['hex'] ) ) {
				return self::css_paint_from_attr_value( $attr_value['hex'] );
			}
		}

		return '';
	}

	/**
	 * Print frontend style tags via Style API.
	 *
	 * @param array<string, mixed> $args Args passed by Divi.
	 */
	public static function module_styles( $args ): void {
		$args          = \DiviSupreme\Includes\DsmDiviBuilderCssScope::normalize_module_styles_args( $args );
		$attrs         = isset( $args['attrs'] ) && is_array( $args['attrs'] ) ? $args['attrs'] : array();
		$elements      = $args['elements'];
		$scope         = self::tour_scope_class( $args );
		$root          = self::portaled_root_selector( $scope );
		$hole          = self::portaled_child_selector( $scope, '.dsm-page-tour__hole' );
		$tippy         = $scope . '.dsm-page-tour__tippy';
		$primary_btn   = self::nav_button_selector( $scope, '.dsm-page-tour__btn--next' );
		$secondary_btn = self::nav_button_selector( $scope, '.dsm-page-tour__btn--back' ) . ', ' . self::nav_button_selector( $scope, '.dsm-page-tour__btn--skip' );

		Style::add(
			array(
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => array(
					$elements->style(
						array(
							'attrName'   => 'module',
							'styleProps' => array(
								'disabledOn' => array(
									'disabledModuleVisibility' => $args['settings']['disabledModuleVisibility'] ?? null,
								),
							),
						)
					),
					CssStyle::style(
						array(
							'selector' => $args['orderClass'],
							'attr'     => $attrs['css'] ?? array(),
						)
					),
					$elements->style(
						array(
							'attrName'   => 'nav_primary',
							'styleProps' => self::nav_button_style_props( $primary_btn, 'nav_primary' ),
						)
					),
					$elements->style(
						array(
							'attrName'   => 'nav_secondary',
							'styleProps' => self::nav_button_style_props( $secondary_btn, 'nav_secondary' ),
						)
					),
					$elements->style(
						array(
							'attrName'   => 'popover_padding',
							'styleProps' => array(
								'selector' => $tippy . ' .tippy-content',
							),
						)
					),
					$elements->style(
						array(
							'attrName'   => 'popoverStyle',
							'styleProps' => array(
								'selector'  => $tippy . ' .tippy-box[data-theme~=\'dsm-page-tour\'], ' . $tippy . ' .tippy-box',
								'border'    => array(
									'selector'  => $tippy . ' .tippy-box[data-theme~=\'dsm-page-tour\'], ' . $tippy . ' .tippy-box',
									'important' => true,
								),
								'boxShadow' => array(
									'selector'   => $tippy . ' .tippy-box[data-theme~=\'dsm-page-tour\'], ' . $tippy . ' .tippy-box',
									'useOverlay' => true,
								),
							),
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $tippy . ' .tippy-box[data-theme~=\'dsm-page-tour\'], ' . $tippy . ' .tippy-box',
							'attr'                => $attrs['popover_background_color']['innerContent'] ?? array(),
							'declarationFunction' => array( PageTourStep::class, 'popover_background_style_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $tippy . ' .tippy-arrow',
							'attr'                => $attrs['popover_background_color']['innerContent'] ?? array(),
							'declarationFunction' => array( PageTourStep::class, 'popover_arrow_style_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector' => $tippy . ' .tippy-content',
							'attr'     => $attrs['popover_max_width']['innerContent'] ?? array(),
							'property' => 'max-width',
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $tippy . ' .tippy-box[data-theme~=\'dsm-page-tour\'], ' . $tippy . ' .tippy-box',
							'attr'                => $attrs['popoverStyle']['decoration']['boxShadow'] ?? array(),
							'declarationFunction' => array( self::class, 'popover_box_shadow_style_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $root,
							'attr'                => $attrs['overlay_color']['innerContent'] ?? array(),
							'declarationFunction' => array( self::class, 'overlay_var_style_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $root,
							'attr'                => $attrs['hole_radius']['innerContent'] ?? array(),
							'declarationFunction' => array( self::class, 'hole_radius_var_style_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector' => $hole,
							'attr'     => $attrs['hole_radius']['innerContent'] ?? array(),
							'property' => 'border-radius',
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $tippy . ' .dsm-page-tour__progress-bar',
							'attr'                => $attrs['progress_color']['innerContent'] ?? array(),
							'declarationFunction' => array( self::class, 'important_background_style_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $tippy . ' .dsm-page-tour__progress',
							'attr'                => $attrs['progress_track_color']['innerContent'] ?? array(),
							'declarationFunction' => array( self::class, 'important_background_style_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $primary_btn,
							'attr'                => $attrs['nav_primary']['decoration']['background'] ?? array(),
							'declarationFunction' => array( self::class, 'background_style_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $secondary_btn,
							'attr'                => $attrs['nav_secondary']['decoration']['background'] ?? array(),
							'declarationFunction' => array( self::class, 'background_style_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $primary_btn,
							'attr'                => $attrs['nav_primary']['decoration']['font']['font'] ?? array(),
							'declarationFunction' => array( self::class, 'nav_button_font_style_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $secondary_btn,
							'attr'                => $attrs['nav_secondary']['decoration']['font']['font'] ?? array(),
							'declarationFunction' => array( self::class, 'nav_button_font_style_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $primary_btn,
							'attr'                => $attrs['nav_primary']['decoration']['border'] ?? array(),
							'declarationFunction' => array( self::class, 'nav_button_border_style_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $secondary_btn,
							'attr'                => $attrs['nav_secondary']['decoration']['border'] ?? array(),
							'declarationFunction' => array( self::class, 'nav_button_border_style_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector'            => self::nav_button_icon_selector( $primary_btn ),
							'attr'                => $attrs['nav_primary_icon_font_size']['innerContent'] ?? array(),
							'declarationFunction' => array( self::class, 'font_size_style_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector'            => self::nav_button_icon_selector( $secondary_btn ),
							'attr'                => $attrs['nav_secondary_icon_font_size']['innerContent'] ?? array(),
							'declarationFunction' => array( self::class, 'font_size_style_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector'            => self::nav_button_state_selector( $primary_btn, ':hover' ) . ', ' . self::nav_button_state_selector( $primary_btn, ':focus' ),
							'attr'                => self::nav_button_spacing_icon_attr( $attrs, 'nav_primary' ),
							'declarationFunction' => array( self::class, 'nav_button_icon_hover_padding_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector'            => self::nav_button_state_selector( $secondary_btn, ':hover' ) . ', ' . self::nav_button_state_selector( $secondary_btn, ':focus' ),
							'attr'                => self::nav_button_spacing_icon_attr( $attrs, 'nav_secondary' ),
							'declarationFunction' => array( self::class, 'nav_button_icon_hover_padding_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $primary_btn,
							'attr'                => self::nav_button_spacing_icon_attr( $attrs, 'nav_primary' ),
							'declarationFunction' => array( self::class, 'nav_button_icon_always_padding_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $secondary_btn,
							'attr'                => self::nav_button_spacing_icon_attr( $attrs, 'nav_secondary' ),
							'declarationFunction' => array( self::class, 'nav_button_icon_always_padding_declaration' ),
						)
					),
				),
			)
		);
	}

	/**
	 * Script data for the module wrapper.
	 *
	 * @param array<string, mixed> $args Args.
	 */
	public static function module_script_data( $args ): void {
		$elements = $args['elements'];
		$elements->script_data(
			array(
				'attrName' => 'module',
			)
		);
	}

	/**
	 * Classnames on the root module wrapper.
	 *
	 * @param array<string, mixed> $args Args.
	 */
	public static function module_classnames( $args ): void {
		$classnames_instance = $args['classnamesInstance'];
		$attrs               = $args['attrs'];

		$classnames_instance->add( 'dsm-page-tour' );
		$classnames_instance->add(
			ElementClassnames::classnames(
				array(
					'attrs' => $attrs['module']['decoration'] ?? array(),
				)
			)
		);
	}

	/**
	 * Frontend HTML. Overlay and popovers hoist to the footer — not in-flow.
	 *
	 * @param array<string, mixed> $attrs    Parsed attributes.
	 * @param string               $content  Inner blocks markup (intentionally unused).
	 * @param \WP_Block            $block    Block instance.
	 * @param mixed                $elements Elements API.
	 * @return string
	 */
	public static function render_callback( $attrs, $content, $block, $elements ) {
		unset( $content );

		if ( ! is_admin() && ! ( function_exists( 'et_core_is_fb_enabled' ) && et_core_is_fb_enabled() ) ) {
			try {
				self::queue_tour( is_array( $attrs ) ? $attrs : array(), $block );
			} catch ( \Throwable $e ) {
				// Never take down the page if tour collection fails.
				unset( $e );
			}
		}

		$parent       = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );
		$parent_attrs = $parent->attrs ?? array();

		return Module::render(
			array(
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],
				'attrs'               => $attrs,
				'parentAttrs'         => $parent_attrs,
				'elements'            => $elements,
				'id'                  => $block->parsed_block['id'],
				'moduleClassName'     => 'dsm_page_tour',
				'name'                => $block->block_type->name,
				'classnamesFunction'  => array( self::class, 'module_classnames' ),
				'moduleCategory'      => $block->block_type->category,
				'stylesComponent'     => array( self::class, 'module_styles' ),
				'scriptDataComponent' => array( self::class, 'module_script_data' ),
				'children'            => '',
			)
		);
	}

	/**
	 * Queue a tour payload and hook the footer hoist once.
	 *
	 * @param array<string, mixed> $attrs Parent attrs.
	 * @param \WP_Block            $block Block instance.
	 * @return void
	 */
	private static function queue_tour( array $attrs, $block ): void {
		$tour = self::build_tour_payload( $attrs, $block );
		if ( array() === $tour['steps'] ) {
			return;
		}

		self::$footer_tours[] = $tour;

		self::enqueue_frontend_scripts();

		if ( ! self::$footer_hooked ) {
			self::$footer_hooked = true;
			add_action( 'wp_footer', array( self::class, 'render_footer' ), 20 );
		}
	}

	/**
	 * Enqueue Popper → Tippy → Page Tour (Hotspots pattern).
	 *
	 * @return void
	 */
	private static function enqueue_frontend_scripts(): void {
		if ( ! function_exists( 'wp_enqueue_script' ) ) {
			return;
		}

		$version = defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';

		if ( ! wp_script_is( 'dsm-popper', 'registered' ) ) {
			wp_register_script(
				'dsm-popper',
				DSM_DIR_URL . 'assets/js/popper.js',
				array(),
				$version,
				true
			);
		}

		if ( ! wp_script_is( 'dsm-tippy', 'registered' ) ) {
			wp_register_script(
				'dsm-tippy',
				DSM_DIR_URL . 'assets/js/tippy.js',
				array( 'dsm-popper' ),
				$version,
				true
			);
		}

		if ( ! wp_script_is( 'dsm-page-tour', 'registered' ) ) {
			wp_register_script(
				'dsm-page-tour',
				DSM_DIR_URL . 'assets/js/page-tour.js',
				array( 'dsm-popper', 'dsm-tippy' ),
				$version,
				true
			);
		}

		wp_enqueue_script( 'dsm-popper' );
		wp_enqueue_script( 'dsm-tippy' );
		wp_enqueue_script( 'dsm-page-tour' );
	}

	/**
	 * Print overlay + JSON config in the footer.
	 *
	 * @return void
	 */
	public static function render_footer(): void {
		if ( array() === self::$footer_tours ) {
			return;
		}

		$payload = array(
			'tours' => self::$footer_tours,
			'i18n'  => array(
				'back'     => esc_html__( 'Back', 'dsm-supreme-modules-pro-for-divi' ),
				'next'     => esc_html__( 'Next', 'dsm-supreme-modules-pro-for-divi' ),
				'skip'     => esc_html__( 'Skip', 'dsm-supreme-modules-pro-for-divi' ),
				'done'     => esc_html__( 'Done', 'dsm-supreme-modules-pro-for-divi' ),
				// translators: %1$s: current step number, %2$s: total steps.
				'progress' => esc_html__( 'Step %1$s of %2$s', 'dsm-supreme-modules-pro-for-divi' ),
			),
		);

		/**
		 * Filter the Page Tour footer payload (tours + i18n).
		 *
		 * @param array<string, mixed> $payload Footer JSON.
		 */
		$payload = apply_filters( 'dsm_page_tour_footer_payload', $payload );
		$payload = self::sanitize_footer_payload_identity( is_array( $payload ) ? $payload : array() );

		self::$footer_tours = array();

		echo '<div id="dsm-page-tour-root" class="dsm-page-tour__root" hidden>';
		echo '<div class="dsm-page-tour__overlay" aria-hidden="true">';
		echo '<div class="dsm-page-tour__dim dsm-page-tour__dim--top"></div>';
		echo '<div class="dsm-page-tour__dim dsm-page-tour__dim--right"></div>';
		echo '<div class="dsm-page-tour__dim dsm-page-tour__dim--bottom"></div>';
		echo '<div class="dsm-page-tour__dim dsm-page-tour__dim--left"></div>';
		echo '<div class="dsm-page-tour__hole"></div>';
		echo '</div></div>';
		self::enqueue_frontend_scripts();

		$json = self::encode_script_json( $payload );
		if ( ! is_string( $json ) || '' === $json ) {
			return;
		}

		echo '<script type="application/json" id="dsm-page-tour-data">';
		echo $json; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- HEX-encoded JSON; JSON.parse restores title/body HTML.
		echo '</script>';
	}

	/**
	 * Build one tour object for the frontend script.
	 *
	 * @param array<string, mixed> $attrs Parent attrs.
	 * @param \WP_Block            $block Block instance.
	 * @return array<string, mixed>
	 */
	private static function build_tour_payload( array $attrs, $block ): array {
		$parsed_id = '';
		if ( isset( $block->parsed_block['id'] ) && is_scalar( $block->parsed_block['id'] ) ) {
			$parsed_id = (string) $block->parsed_block['id'];
		}

		$tour_name_raw = self::inner_desktop_string( $attrs, 'tour_name' );
		$tour_name     = self::resolve_dynamic_plain( $tour_name_raw, $attrs );
		if ( false !== strpos( $tour_name, '$variable(' ) ) {
			$tour_name = '';
		}
		$tour_name = sanitize_text_field( $tour_name );
		$trigger   = self::inner_desktop_string( $attrs, 'trigger' );
		if ( ! in_array( $trigger, array( 'page_load', 'click', 'interaction' ), true ) ) {
			$trigger = 'page_load';
		}

		$click_selector = self::sanitize_css_selector( self::inner_desktop_string( $attrs, 'click_selector' ) );

		$display_frequency = self::inner_desktop_string( $attrs, 'display_frequency' );
		if ( ! in_array( $display_frequency, array( 'once', 'always', 'until_skipped' ), true ) ) {
			$display_frequency = 'once';
		}

		/**
		 * Filter the On Page Load display frequency for a tour payload.
		 *
		 * @param string               $display_frequency `once`, `always`, or `until_skipped`.
		 * @param array<string, mixed> $attrs             Parent module attrs.
		 * @param \WP_Block            $block             Parent block.
		 */
		$display_frequency = apply_filters( 'dsm_page_tour_display_frequency', $display_frequency, $attrs, $block );
		if ( ! in_array( $display_frequency, array( 'once', 'always', 'until_skipped' ), true ) ) {
			$display_frequency = 'once';
		}

		$start_behavior = self::inner_desktop_string( $attrs, 'start_behavior' );
		if ( ! in_array( $start_behavior, array( 'in_view', 'auto_scroll' ), true ) ) {
			$start_behavior = 'in_view';
		}

		/**
		 * Filter how On Page Load reaches the first (or resumed) step.
		 *
		 * @param string               $start_behavior `in_view` or `auto_scroll`.
		 * @param array<string, mixed> $attrs          Parent module attrs.
		 * @param \WP_Block            $block          Parent block.
		 */
		$start_behavior = apply_filters( 'dsm_page_tour_start_behavior', $start_behavior, $attrs, $block );
		if ( ! in_array( $start_behavior, array( 'in_view', 'auto_scroll' ), true ) ) {
			$start_behavior = 'in_view';
		}

		$in_view_offset = self::normalize_in_view_offset(
			self::inner_desktop_string( $attrs, 'in_view_offset' )
		);

		/**
		 * Filter the viewport travel (0–100) used when First Step is “When target is in view”.
		 *
		 * @param int                  $in_view_offset Inset percent.
		 * @param array<string, mixed> $attrs          Parent module attrs.
		 * @param \WP_Block            $block          Parent block.
		 */
		$in_view_offset = (int) apply_filters( 'dsm_page_tour_in_view_offset', $in_view_offset, $attrs, $block );
		$in_view_offset = self::normalize_in_view_offset( (string) $in_view_offset );

		$animation = self::sanitize_tippy_animation(
			self::inner_desktop_string( $attrs, 'tippy_animation' )
		);

		/**
		 * Filter the Tippy popover animation slug.
		 *
		 * @param string               $animation `fade`, `scale`, `shift-away`, `shift-toward`, or `perspective`.
		 * @param array<string, mixed> $attrs     Parent module attrs.
		 * @param \WP_Block            $block     Parent block.
		 */
		$animation = apply_filters( 'dsm_page_tour_tippy_animation', $animation, $attrs, $block );
		$animation = self::sanitize_tippy_animation( $animation );

		$store_id_source = $tour_name_raw;
		if ( '' === $store_id_source || false !== strpos( $store_id_source, '$variable(' ) ) {
			$store_id_source = $parsed_id;
		}

		$store_id = sanitize_text_field( '' !== $store_id_source ? $store_id_source : 'dsm-page-tour' );

		$steps = self::collect_step_payloads( $block );

		$order_index = isset( $block->parsed_block['orderIndex'] ) ? (int) $block->parsed_block['orderIndex'] : 0;

		$button_icons = array(
			'primary'            => self::nav_button_icon_data_attrs( $attrs, 'nav_primary' ),
			'secondary'          => self::nav_button_icon_data_attrs( $attrs, 'nav_secondary' ),
			'primaryEnabled'     => self::nav_button_icon_is_on( $attrs, 'nav_primary' ),
			'secondaryEnabled'   => self::nav_button_icon_is_on( $attrs, 'nav_secondary' ),
			'primaryOnHover'     => self::nav_button_icon_shows_on_hover( $attrs, 'nav_primary' ),
			'secondaryOnHover'   => self::nav_button_icon_shows_on_hover( $attrs, 'nav_secondary' ),
			'primaryPlacement'   => self::nav_button_icon_placement( $attrs, 'nav_primary' ),
			'secondaryPlacement' => self::nav_button_icon_placement( $attrs, 'nav_secondary' ),
		);

		/**
		 * Filter processed nav button icon attrs (`data-icon` maps) for the tour payload.
		 *
		 * @param array<string, array<string, string>> $button_icons Primary/secondary maps.
		 * @param array<string, mixed>                 $attrs        Parent module attrs.
		 * @param \WP_Block                            $block        Parent block.
		 */
		$button_icons = apply_filters( 'dsm_page_tour_button_icons', $button_icons, $attrs, $block );
		if ( ! is_array( $button_icons ) ) {
			$button_icons = array();
		}

		return array(
			'id'               => $parsed_id,
			'storeId'          => $store_id,
			'name'             => $tour_name,
			'trigger'          => $trigger,
			'clickSelector'    => $click_selector,
			'displayFrequency' => $display_frequency,
			'startBehavior'    => $start_behavior,
			'inViewOffset'     => $in_view_offset,
			'animation'        => $animation,
			'orderClass'       => 'et_pb_dsm_page_tour_' . $order_index,
			'buttonIcons'      => $button_icons,
			'holeRadius'       => '' !== self::inner_desktop_string( $attrs, 'hole_radius' )
				? self::inner_desktop_string( $attrs, 'hole_radius' )
				: '4px',
			'overlayColor'     => self::css_paint_from_attr_value(
				$attrs['overlay_color']['innerContent']['desktop']['value'] ?? ''
			),
			'popover'          => self::step_popover_chrome( $attrs ),
			'steps'            => $steps,
		);
	}

	/**
	 * Child step payloads in document order.
	 *
	 * @param \WP_Block $block Parent block.
	 * @return list<array<string, mixed>>
	 */
	private static function collect_step_payloads( $block ): array {
		$steps = array();

		$inner_blocks = array();
		if ( isset( $block->parsed_block['innerBlocks'] ) && is_array( $block->parsed_block['innerBlocks'] ) ) {
			$inner_blocks = $block->parsed_block['innerBlocks'];
		}

		if ( array() === $inner_blocks ) {
			$store_instance = $block->parsed_block['storeInstance'] ?? null;
			$parent_id      = isset( $block->parsed_block['id'] ) ? (string) $block->parsed_block['id'] : '';
			if ( '' !== $parent_id ) {
				$from_store = BlockParserStore::get_children( $parent_id, $store_instance );
				if ( is_array( $from_store ) ) {
					foreach ( $from_store as $child ) {
						if ( $child instanceof \ET\Builder\FrontEnd\BlockParser\BlockParserBlock ) {
							$inner_blocks[] = array(
								'blockName'  => (string) $child->blockName, // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- External object property.
								'attrs'      => is_array( $child->attrs ) ? $child->attrs : array(),
								'orderIndex' => isset( $child->orderIndex ) ? (int) $child->orderIndex : 0, // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- External object property.
							);
						}
					}
				}
			}
		}

		foreach ( $inner_blocks as $child ) {
			if ( ! is_array( $child ) ) {
				continue;
			}

			$child_name  = isset( $child['blockName'] ) ? (string) $child['blockName'] : '';
			$child_attrs = isset( $child['attrs'] ) && is_array( $child['attrs'] ) ? $child['attrs'] : array();

			if ( 'dsm/page-tour-step' !== $child_name ) {
				continue;
			}

			$step_index = isset( $child['orderIndex'] ) ? (int) $child['orderIndex'] : count( $steps );
			$step       = self::step_payload_from_attrs( $child_attrs, $step_index );
			if ( array() !== $step ) {
				$steps[] = $step;
			}
		}

		return $steps;
	}

	/**
	 * One step for Tippy (title, body, target, placement, hole, skip).
	 *
	 * @param array<string, mixed> $attrs      Step attrs.
	 * @param int                  $order_index Child order index.
	 * @return array<string, mixed>
	 */
	private static function step_payload_from_attrs( array $attrs, int $order_index = 0 ): array {
		$title   = self::inner_desktop_heading_text( $attrs, 'title' );
		$content = self::inner_desktop_heading_text( $attrs, 'content' );
		if ( '' === $title && '' === $content ) {
			return array();
		}

		$mode = self::inner_desktop_string( $attrs, 'target_mode' );
		if ( ! in_array( $mode, array( 'block', 'selector', 'none' ), true ) ) {
			$mode = 'block';
		}

		$placement = self::inner_desktop_string( $attrs, 'placement' );
		$allowed   = array( 'auto', 'top', 'bottom', 'left', 'right' );
		if ( ! in_array( $placement, $allowed, true ) ) {
			$placement = 'auto';
		}

		$show_hole = self::inner_desktop_string( $attrs, 'show_hole' );
		if ( '' === $show_hole ) {
			$show_hole = 'on';
		}

		$skippable = self::inner_desktop_string( $attrs, 'skippable' );
		if ( '' === $skippable ) {
			$skippable = 'on';
		}

		$anchor   = '';
		$selector = '';

		if ( 'block' === $mode ) {
			$tokens = array_merge(
				self::tokens_from_raw( self::inner_desktop_string( $attrs, 'target_block_id' ) ),
				self::tokens_from_raw( self::inner_desktop_string( $attrs, 'target_render_id' ) )
			);
			foreach ( $tokens as $token ) {
				if ( 1 === preg_match( '/\/.+-\d+$/', $token ) ) {
					$anchor = $token;
					break;
				}
			}
			if ( '' === $anchor && isset( $tokens[0] ) ) {
				$anchor = $tokens[0];
			}
		} elseif ( 'selector' === $mode ) {
			$selector = self::sanitize_css_selector( self::inner_desktop_string( $attrs, 'target_selector' ) );
		}

		return array(
			'title'      => $title,
			'content'    => $content,
			'mode'       => $mode,
			'anchor'     => $anchor,
			'selector'   => $selector,
			'placement'  => $placement,
			'hole'       => 'on' === $show_hole,
			'skippable'  => 'on' === $skippable,
			'orderClass' => 'dsm_page_tour_step_' . $order_index,
			'popover'    => self::step_popover_chrome( $attrs ),
		);
	}

	/**
	 * Child Popover Design leaves for the portaled Tippy box.
	 *
	 * @param array<string, mixed> $attrs Step attrs.
	 * @return array<string, string>
	 */
	public static function step_popover_chrome( array $attrs ): array {
		$background  = self::css_paint_from_attr_value(
			$attrs['popover_background_color']['innerContent']['desktop']['value'] ?? ''
		);
		$max_width   = self::inner_desktop_string( $attrs, 'popover_max_width' );
		$padding_raw = $attrs['popover_padding']['decoration']['spacing']['desktop']['value']['padding'] ?? array();
		$padding     = is_array( $padding_raw ) ? $padding_raw : array();
		$border_raw  = $attrs['popoverStyle']['decoration']['border']['desktop']['value'] ?? array();
		$border      = is_array( $border_raw ) ? $border_raw : array();
		$radius      = is_array( $border['radius'] ?? null ) ? $border['radius'] : array();
		$all         = is_array( $border['styles']['all'] ?? null ) ? $border['styles']['all'] : array();

		$border_width = is_string( $all['width'] ?? null ) ? trim( (string) $all['width'] ) : '';
		if ( '' !== $border_width && 1 === preg_match( '/^0(?:px|em|rem|%)?$/i', $border_width ) ) {
			$border_width = '';
		}

		$shadow_raw = $attrs['popoverStyle']['decoration']['boxShadow']['desktop']['value'] ?? array();
		$box_shadow = is_array( $shadow_raw ) ? BoxShadow::value( $shadow_raw ) : '';

		return array(
			'background'  => $background,
			'maxWidth'    => $max_width,
			'padding'     => self::css_box_sides( $padding, array( 'top', 'right', 'bottom', 'left' ) ),
			'radius'      => self::css_box_sides(
				$radius,
				array( 'topLeft', 'topRight', 'bottomRight', 'bottomLeft' )
			),
			'borderWidth' => $border_width,
			'borderStyle' => is_string( $all['style'] ?? null ) ? trim( (string) $all['style'] ) : '',
			'borderColor' => self::css_paint_from_attr_value( $all['color'] ?? '' ),
			'boxShadow'   => is_string( $box_shadow ) ? $box_shadow : '',
		);
	}

	/**
	 * Join spacing / radius side values into a CSS shorthand, or empty when all zero.
	 *
	 * @param array<string, mixed> $sides Side map.
	 * @param array                $keys Side keys in CSS order.
	 * @return string
	 */
	private static function css_box_sides( array $sides, array $keys ): string {
		$parts = array();
		$has   = false;

		foreach ( $keys as $key ) {
			$raw = isset( $sides[ $key ] ) && is_scalar( $sides[ $key ] ) ? trim( (string) $sides[ $key ] ) : '';
			if ( '' !== $raw && ! preg_match( '/^0(?:px|em|rem|%)?$/i', $raw ) ) {
				$has = true;
			}
			$parts[] = '' !== $raw ? $raw : '0';
		}

		return $has ? implode( ' ', $parts ) : '';
	}

	/**
	 * Clamp the in-view viewport travel to 0–100 (default 45).
	 *
	 * @param string $raw Raw attr or filter value.
	 * @return int
	 */
	private static function normalize_in_view_offset( string $raw ): int {
		if ( '' === $raw ) {
			return 45;
		}

		$digits = preg_replace( '/[^0-9]/', '', $raw );
		if ( ! is_string( $digits ) || '' === $digits ) {
			return 45;
		}

		$offset = (int) $digits;

		if ( $offset > 100 ) {
			return 100;
		}

		return $offset;
	}

	/**
	 * Sanitize Tippy animation slug for the frontend payload.
	 *
	 * @param mixed $value Raw attr value.
	 * @return string
	 */
	private static function sanitize_tippy_animation( $value ): string {
		$slug = is_string( $value ) ? trim( $value ) : '';
		if ( '' !== $slug && in_array( $slug, self::TIPPY_ANIMATION_ALLOWLIST, true ) ) {
			return $slug;
		}

		return 'shift-away';
	}

	/**
	 * Desktop innerContent string (select / text leaf).
	 *
	 * @param array<string, mixed> $attrs Attrs.
	 * @param string               $key   Attribute key.
	 * @return string
	 */
	private static function inner_desktop_string( array $attrs, string $key ): string {
		if ( ! isset( $attrs[ $key ] ) || ! is_array( $attrs[ $key ] ) ) {
			return '';
		}

		$raw = $attrs[ $key ]['innerContent']['desktop']['value'] ?? '';
		if ( is_array( $raw ) && isset( $raw['text'] ) && is_scalar( $raw['text'] ) ) {
			$raw = $raw['text'];
		}

		if ( ! is_scalar( $raw ) ) {
			return '';
		}

		return trim( (string) $raw );
	}

	/**
	 * Heading / rich-text leaf, KSES'd for the popover.
	 *
	 * @param array<string, mixed> $attrs Attrs.
	 * @param string               $key   Attribute key.
	 * @return string
	 */
	private static function inner_desktop_heading_text( array $attrs, string $key ): string {
		$raw = self::inner_desktop_string( $attrs, $key );
		if ( '' === $raw ) {
			return '';
		}

		$resolved = self::resolve_dynamic_plain( $raw, $attrs );
		if ( '' === $resolved || false !== strpos( $resolved, '$variable(' ) ) {
			return '';
		}

		return wp_kses_post( $resolved );
	}

	/**
	 * Resolve Divi Dynamic Content (`$variable({…})$`) in a stored string.
	 *
	 * Matches Chart: Loop helper while LoopContext is active, otherwise
	 * {@see DynamicData::get_processed_dynamic_data()}.
	 *
	 * @param string               $value Plain string that may contain `$variable(...)`.
	 * @param array<string, mixed> $attrs Optional module attrs (loop markers).
	 * @return string
	 */
	private static function resolve_dynamic_plain( string $value, array $attrs = array() ): string {
		if ( '' === $value || false === strpos( $value, '$variable(' ) ) {
			return $value;
		}

		if (
			class_exists( LoopUtils::class ) &&
			class_exists( LoopContext::class ) &&
			null !== LoopContext::get() &&
			array() !== $attrs
		) {
			$looped = LoopUtils::process_dynamic_content( $value, $attrs );

			return self::filter_resolved_dynamic_text( $looped, $value, $attrs );
		}

		if ( ! class_exists( DynamicData::class ) ) {
			return self::filter_resolved_dynamic_text( $value, $value, $attrs );
		}

		$loop_post_id = isset( $attrs['__loop_post_id'] ) ? absint( $attrs['__loop_post_id'] ) : 0;
		$post_id      = $loop_post_id > 0 ? $loop_post_id : get_the_ID();
		$resolved     = DynamicData::get_processed_dynamic_data(
			$value,
			false !== $post_id && $post_id > 0 ? (int) $post_id : null
		);
		$text         = null !== $resolved ? (string) $resolved : $value;

		return self::filter_resolved_dynamic_text( $text, $value, $attrs );
	}

	/**
	 * Filter resolved Page Tour copy after Divi Dynamic Content.
	 *
	 * @param string               $text  Resolved text.
	 * @param string               $value Original stored value.
	 * @param array<string, mixed> $attrs Step or parent attrs.
	 * @return string
	 */
	private static function filter_resolved_dynamic_text( string $text, string $value, array $attrs ): string {
		/**
		 * Filters resolved Page Tour title, content, or tour name.
		 *
		 * @param string               $text  Resolved text.
		 * @param string               $value Original stored value.
		 * @param array<string, mixed> $attrs Module attrs.
		 */
		return (string) apply_filters( 'dsm_page_tour_resolve_dynamic_text', $text, $value, $attrs );
	}

	/**
	 * Split a stored picker string into tokens.
	 *
	 * @param string $raw Raw value.
	 * @return list<string>
	 */
	private static function tokens_from_raw( string $raw ): array {
		$parts = preg_split( '/\s+/', trim( $raw ) );
		if ( ! is_array( $parts ) ) {
			return array();
		}

		$out = array();
		foreach ( $parts as $part ) {
			$token = trim( sanitize_text_field( (string) $part ) );
			if ( '' !== $token && 1 === preg_match( '/^[A-Za-z0-9_:\-\/.]+$/', $token ) ) {
				$out[] = $token;
			}
		}

		return $out;
	}

	/**
	 * Re-sanitize tour identity fields after the footer payload filter.
	 *
	 * @param array<string, mixed> $payload Footer JSON.
	 * @return array<string, mixed>
	 */
	private static function sanitize_footer_payload_identity( array $payload ): array {
		if ( ! isset( $payload['tours'] ) || ! is_array( $payload['tours'] ) ) {
			return $payload;
		}

		foreach ( $payload['tours'] as $index => $tour ) {
			if ( ! is_array( $tour ) ) {
				continue;
			}

			if ( isset( $tour['name'] ) && is_scalar( $tour['name'] ) ) {
				$payload['tours'][ $index ]['name'] = sanitize_text_field( (string) $tour['name'] );
			}

			if ( isset( $tour['storeId'] ) && is_scalar( $tour['storeId'] ) ) {
				$payload['tours'][ $index ]['storeId'] = sanitize_text_field( (string) $tour['storeId'] );
			}
		}

		return $payload;
	}

	/**
	 * Encode JSON for embedding inside a `<script>` tag.
	 *
	 * HEX flags prevent a literal `</script>` in a string field from closing the tag.
	 * `JSON.parse` still restores kses'd HTML in title/body.
	 *
	 * @param mixed $data Payload.
	 * @return string|false
	 */
	private static function encode_script_json( $data ) {
		return wp_json_encode(
			$data,
			JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT
		);
	}

	/**
	 * Conservative CSS selector allow-list (escape hatch + click trigger).
	 *
	 * @param string $raw Raw selector.
	 * @return string
	 */
	private static function sanitize_css_selector( string $raw ): string {
		$raw = trim( $raw );
		if ( '' === $raw || strlen( $raw ) > 300 ) {
			return '';
		}

		if ( 1 !== preg_match( '/^[A-Za-z0-9_\-#\.\[\]="\'\s>+~:(),]+$/', $raw ) ) {
			return '';
		}

		return $raw;
	}
}
