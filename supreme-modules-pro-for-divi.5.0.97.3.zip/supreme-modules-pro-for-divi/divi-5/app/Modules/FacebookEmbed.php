<?php
/**
 * Facebook Embed module (Divi 5).
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Modules;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\Module\Options\Element\ElementClassnames;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;

/**
 * Supreme Facebook Embed — post or video (D4 parity).
 */
class FacebookEmbed implements DependencyInterface {


	/**
	 * Register module.
	 */
	public function load(): void {
		add_action( 'init', array( self::class, 'register_module' ) );
	}

	/**
	 * Initialise module dependency.
	 */
	public static function dsm_initialise(): void {
		add_action(
			'divi_module_library_modules_dependency_tree',
			static function ( $dependency_tree ): void {
				$dependency_tree->add_dependency( new self() );
			}
		);
	}

	/**
	 * Register module with Divi.
	 */
	public static function register_module(): void {
		$module_json_path = DSM_DIR_PATH . 'divi-5/public/packages/module-library/facebook-embed';

		ModuleRegistration::register_module(
			$module_json_path,
			array(
				'render_callback' => array( self::class, 'render_callback' ),
			)
		);
	}

	/**
	 * Render module style.
	 *
	 * @param array<string, mixed> $args Arguments.
	 */
	public static function module_styles( array $args ): void {
		$args     = \DiviSupreme\Includes\DsmDiviBuilderCssScope::normalize_module_styles_args( $args );
		$attrs    = $args['attrs'] ?? array();
		$elements = $args['elements'];

		Style::add(
			array(
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => array(
					$elements->style(
						array(
							'attrName'   => 'module',
							'styleProps' => array(
								'disabledOn' => array(
									'disabledModuleVisibility' => $args['settings']['disabledModuleVisibility'] ?? null,
								),
							),
						)
					),

					CssStyle::style(
						array(
							'selector' => $args['orderClass'],
							'attr'     => $attrs['css'] ?? array(),
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']}",
							'attr'     => $attrs['fb_alignment']['innerContent'] ?? array(),
							'property' => 'text-align',
						)
					),
				),
			)
		);
	}

	/**
	 * Render module script data.
	 *
	 * @param array<string, mixed> $args Arguments.
	 */
	public static function module_script_data( array $args ): void {
		$elements = $args['elements'];

		$elements->script_data(
			array(
				'attrName' => 'module',
			)
		);
	}

	/**
	 * Render module classnames.
	 *
	 * @param array<string, mixed> $args Arguments.
	 */
	public static function module_classnames( array $args ): void {
		$classnames_instance = $args['classnamesInstance'];
		$attrs               = $args['attrs'];

		$classnames_instance->add(
			ElementClassnames::classnames(
				array(
					'attrs' => $attrs['module']['decoration'] ?? array(),
				)
			)
		);
	}

	/**
	 * Live public post used when the module has no URL, and as a replacement
	 * for the old Divi Supreme photo default Facebook removed.
	 */
	private const DEFAULT_POST_URL = 'https://www.facebook.com/divisupreme/posts/1007322319061299';

	/**
	 * Fb bool string.
	 *
	 * @param mixed $raw Raw yes/no value.
	 */
	private static function fb_bool_string( $raw ): string {
		if ( is_bool( $raw ) ) {
			return $raw ? 'true' : 'false';
		}
		$v = strtolower( trim( (string) $raw ) );

		return in_array( $v, array( 'true', 'on', 'yes', '1' ), true ) ? 'true' : 'false';
	}

	/**
	 * Fb URL string.
	 *
	 * @param mixed  $raw      Stored URL.
	 * @param string $fallback Used when the stored value is empty.
	 */
	private static function fb_url_string( $raw, string $fallback ): string {
		if ( ! is_string( $raw ) ) {
			return $fallback;
		}
		$url = trim( $raw );
		if ( '' === $url ) {
			return $fallback;
		}

		$removed = array(
			'https://www.facebook.com/divisupreme/photos/a.318525935577439/631773864252643/' => self::DEFAULT_POST_URL,
			'https://www.facebook.com/divisupreme/photos/a.318525935577439/631773864252643'  => self::DEFAULT_POST_URL,
			'https://www.facebook.com/yourpage/posts/1234567890' => self::DEFAULT_POST_URL,
			'https://www.facebook.com/yourpage/posts/1234567890/' => self::DEFAULT_POST_URL,
		);

		return $removed[ $url ] ?? $url;
	}

	/**
	 * Plugin iframe. XFBML (.fb-post) stays empty when the SDK parses before the
	 * node has a size, or when the post URL Facebook shipped as the default was removed.
	 *
	 * @param string $type       post|video.
	 * @param string $href       Public Facebook URL.
	 * @param string $show_text  true|false.
	 * @param string $fullscreen true|false.
	 * @param string $autoplay   true|false.
	 * @param string $captions   true|false.
	 */
	private static function embed_iframe( string $type, string $href, string $show_text, string $fullscreen, string $autoplay, string $captions ): string {
		$is_video = 'video' === $type;
		$args     = array(
			'href'      => $href,
			'show_text' => $show_text,
			'width'     => '500',
		);
		if ( $is_video ) {
			$args['allowfullscreen'] = $fullscreen;
			$args['autoplay']        = $autoplay;
			$args['show_captions']   = $captions;
		}

		$src    = add_query_arg( $args, 'https://www.facebook.com/plugins/' . ( $is_video ? 'video' : 'post' ) . '.php' );
		$height = $is_video ? 340 : 680;

		return sprintf(
			'<iframe class="dsm-facebook-embed" title="%4$s" src="%1$s" width="500" height="%2$d" style="border:none;overflow:hidden;max-width:100%%;background-color:#ffffff;color-scheme:light" scrolling="no" frameborder="0" allow="autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share" %3$s></iframe>',
			esc_url( $src ),
			$height,
			'true' === $fullscreen || ! $is_video ? 'allowfullscreen="true"' : '',
			esc_attr__( 'Facebook embed', 'dsm-supreme-modules-pro-for-divi' )
		);
	}

	/**
	 * Render module HTML output.
	 *
	 * @param array<string, mixed> $attrs    Module attrs.
	 * @param string               $content  Inner content (unused).
	 * @param \WP_Block            $block    Block instance.
	 * @param mixed                $elements Elements API.
	 * @return string
	 */
	public static function render_callback( $attrs, $content, $block, $elements ): string {
		$fb_type                = $attrs['fb_type']['innerContent']['desktop']['value'] ?? 'post';
		$fb_type                = is_string( $fb_type ) && 'video' === $fb_type ? 'video' : 'post';
		$fb_post_url            = self::fb_url_string(
			$attrs['fb_post_url']['innerContent']['desktop']['value'] ?? null,
			self::DEFAULT_POST_URL
		);
		$fb_video_url           = self::fb_url_string(
			$attrs['fb_video_url']['innerContent']['desktop']['value'] ?? null,
			'https://fb.watch/lpF1Z-680x/'
		);
		$fb_show_text           = self::fb_bool_string( $attrs['fb_show_text']['innerContent']['desktop']['value'] ?? 'false' );
		$fb_video_fullscreen    = self::fb_bool_string( $attrs['fb_video_fullscreen']['innerContent']['desktop']['value'] ?? 'false' );
		$fb_video_autoplay      = self::fb_bool_string( $attrs['fb_video_autoplay']['innerContent']['desktop']['value'] ?? 'false' );
		$fb_video_show_captions = self::fb_bool_string( $attrs['fb_video_show_captions']['innerContent']['desktop']['value'] ?? 'false' );

		$container = self::embed_iframe(
			$fb_type,
			'video' === $fb_type ? $fb_video_url : $fb_post_url,
			$fb_show_text,
			$fb_video_fullscreen,
			$fb_video_autoplay,
			$fb_video_show_captions
		);

		$module_inner = HTMLUtility::render(
			array(
				'tag'               => 'div',
				'attributes'        => array(
					'class' => 'et_pb_module_inner',
				),
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $container,
			)
		);

		$module_elements = $elements->style_components(
			array(
				'attrName' => 'module',
			)
		);

		$module_container_children = $module_elements . $module_inner;

		return Module::render(
			array(
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],
				'attrs'               => $attrs,
				'elements'            => $elements,
				'id'                  => $block->parsed_block['id'],
				'moduleClassName'     => 'dsm_facebook_embed',
				'name'                => $block->block_type->name,
				'classnamesFunction'  => array( self::class, 'module_classnames' ),
				'moduleCategory'      => $block->block_type->category,
				'stylesComponent'     => array( self::class, 'module_styles' ),
				'scriptDataComponent' => array( self::class, 'module_script_data' ),
				'children'            => $module_container_children,
			)
		);
	}
}
