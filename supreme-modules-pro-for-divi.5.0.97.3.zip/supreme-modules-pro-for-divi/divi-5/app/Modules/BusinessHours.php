<?php
/**
 * Business Hour Module.
 *
 * @package DiviSupreme.
 */

declare(strict_types=1);

namespace DiviSupreme\Modules;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}


use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\Module\Options\Element\ElementClassnames;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Options\Element\ElementComponents;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\Module\Options\Css\CssStyle;


/**
 * Class that handles "BusinessHours Module" module.
 */
class BusinessHours implements DependencyInterface {



	/**
	 * Register module.
	 * `DependencyInterface` interface ensures class method name `load()` is executed for initialization.
	 */
	public function load() {
		add_action( 'init', array( self::class, 'register_module' ) );
	}

	/**
	 * Initilises the module.
	 *
	 * @return void
	 */
	public static function dsm_initialise() {
		add_action(
			'divi_module_library_modules_dependency_tree',
			function ( $dependency_tree ) {
				$dependency_tree->add_dependency( new self() );
			}
		);
	}

	/**
	 * Register module.
	 */
	public static function register_module() {

		$module_json_path = DSM_DIR_PATH . 'divi-5/public/packages/module-library/business-hours';

		ModuleRegistration::register_module(
			$module_json_path,
			array(
				'render_callback' => array( self::class, 'render_callback' ),
			)
		);
	}

	/**
	 * Render module style.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_styles( $args ) {
		$args     = \DiviSupreme\Includes\DsmDiviBuilderCssScope::normalize_module_styles_args( $args );
		$attrs    = $args['attrs'] ?? array();
		$elements = $args['elements'];
		// When the key is omitted, match module default (striped on).
		$background_striped_on = 'on' === (string) ( $attrs['background_striped']['innerContent']['desktop']['value'] ?? 'on' );

		$styles = array(
			// Module.
			$elements->style(
				array(
					'attrName'   => 'module',
					'styleProps' => array(
						'disabledOn' => array(
							'disabledModuleVisibility' => $args['settings']['disabledModuleVisibility'] ?? null,
						),
					),
				)
			),

			CssStyle::style(
				array(
					'selector' => $args['orderClass'],
					'attr'     => $attrs['css'] ?? array(),
				)
			),

			$elements->style(
				array(
					'attrName' => 'text',
				)
			),

			$elements->style(
				array(
					'attrName' => 'time',
				)
			),

			$elements->style(
				array(
					'attrName' => 'title',
				)
			),

			$elements->style(
				array(
					'attrName' => 'separator_style',
				)
			),

			$elements->style(
				array(
					'attrName' => 'separator_weight',
				)
			),

			$elements->style(
				array(
					'attrName' => 'separator_color',
				)
			),

			$elements->style(
				array(
					'attrName' => 'separator_gap',
				)
			),

			$elements->style(
				array(
					'attrName' => 'divider_style',
				)
			),

			$elements->style(
				array(
					'attrName' => 'divider_weight',
				)
			),

			$elements->style(
				array(
					'attrName' => 'divider_color',
				)
			),

			$elements->style(
				array(
					'attrName' => 'dsm_item',
				)
			),

			$elements->style(
				array(
					'attrName' => 'background_striped_odd_row_color',
				)
			),

			$elements->style(
				array(
					'attrName' => 'background_striped_even_row_color',
				)
			),
		);

		$styles[] = CommonStyle::style(
			array(
				'selector' => "{$args['orderClass']}  .dsm-business-hours-separator",
				'attr'     => $attrs['separator_style']['innerContent'] ?? array(),
				'property' => 'border-bottom-style',
			)
		);

		$styles[] = CommonStyle::style(
			array(
				'selector' => "{$args['orderClass']}  .dsm-business-hours-separator",
				'attr'     => $attrs['separator_weight']['innerContent'] ?? array(),
				'property' => 'border-bottom-width',
			)
		);

		$styles[] = CommonStyle::style(
			array(
				'selector' => "{$args['orderClass']}  .dsm-business-hours-separator",
				'attr'     => $attrs['separator_color']['innerContent'] ?? array(),
				'property' => 'border-bottom-color',
			)
		);

		$styles[] = CommonStyle::style(
			array(
				'selector' => "{$args['orderClass']}  .dsm-business-hours-separator",
				'attr'     => $attrs['separator_gap']['innerContent'] ?? array(),
				'property' => 'margin-left',
			)
		);

		$styles[] = CommonStyle::style(
			array(
				'selector' => "{$args['orderClass']}  .dsm-business-hours-separator",
				'attr'     => $attrs['separator_gap']['innerContent'] ?? array(),
				'property' => 'margin-right',
			)
		);

		$styles[] = CommonStyle::style(
			array(
				'selector' => "{$args['orderClass']} .dsm_business_hours_child",
				'attr'     => $attrs['divider_style']['innerContent'] ?? array(),
				'property' => 'border-bottom-style',
			)
		);

		$styles[] = CommonStyle::style(
			array(
				'selector' => "{$args['orderClass']} .dsm_business_hours_child",
				'attr'     => $attrs['divider_weight']['innerContent'] ?? array(),
				'property' => 'border-bottom-width',
			)
		);

		$styles[] = CommonStyle::style(
			array(
				'selector' => "{$args['orderClass']} .dsm_business_hours_child",
				'attr'     => $attrs['divider_color']['innerContent'] ?? array(),
				'property' => 'border-bottom-color',
			)
		);

		if ( $background_striped_on ) {
			$styles[] = CommonStyle::style(
				array(
					'selector' => "{$args['orderClass']}  .dsm_business_hours_child:nth-child(odd)",
					'attr'     => $attrs['background_striped_odd_row_color']['innerContent'] ?? array(),
					'property' => 'background-color',
				)
			);

			$styles[] = CommonStyle::style(
				array(
					'selector' => "{$args['orderClass']} .dsm_business_hours_child:nth-child(even)",
					'attr'     => $attrs['background_striped_even_row_color']['innerContent'] ?? array(),
					'property' => 'background-color',
				)
			);
		}

		$styles[] = CommonStyle::style(
			array(
				'selector' => "{$args['orderClass']} .dsm_business_hours_child>div",
				'attr'     => $attrs['content_orientation']['innerContent'] ?? array(),
				'property' => 'align-items',
			)
		);

		Style::add(
			array(
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => $styles,
			)
		);
	}

	/**
	 * Render module script data.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_script_data( $args ) {
		$elements = $args['elements'];

		// Element Script Data Options.
		$elements->script_data(
			array(
				'attrName' => 'module',
			)
		);
	}

	/**
	 * Render module classnames.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_classnames( $args ) {
		$classnames_instance = $args['classnamesInstance'];
		$attrs               = $args['attrs'];

		// Module.
		$classnames_instance->add(
			ElementClassnames::classnames(
				array(
					'attrs' => $attrs['module']['decoration'] ?? array(),
				)
			)
		);
	}

	/**
	 * Render module HTML output.
	 *
	 * @param array     $attrs - Modules Attributes.
	 * @param string    $content - Content.
	 * @param \WP_Block $block - Block.
	 * @param mixed     $elements - Elements.
	 */
	public static function render_callback( $attrs, $content, $block, $elements ) {

		$children_ids = $block->parsed_block['innerBlocks'] ? array_map(
			function ( $inner_block ) {
				return $inner_block['id'];
			},
			$block->parsed_block['innerBlocks']
		) : array();

		$parent       = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );
		$parent_attrs = $parent->attrs ?? array();

		// Module Inner.
		// Essentially, this is the module content.
		// Were wrapping the title and content in a div with class `et_pb_module_inner`.
		$module_inner = HTMLUtility::render(
			array(
				'tag'               => 'div',
				'attributes'        => array(
					'class' => 'et_pb_module_inner',
				),
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $content,
			)
		);

		// This are the module elements that will be rendered in the frontend.
		$module_elements = $elements->style_components(
			array(
				'attrName' => 'module',
			)
		);

		// This are the children of the module container, which are the module elements and the module inner.
		$module_container_children = $module_elements . $module_inner;

		return Module::render(
			array(
				// FE only.
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],

				// VB equivalent.
				'attrs'               => $attrs,
				'parentAttrs'         => $parent_attrs,
				'elements'            => $elements,
				'id'                  => $block->parsed_block['id'],
				'moduleClassName'     => '',
				'name'                => $block->block_type->name,
				'classnamesFunction'  => array( self::class, 'module_classnames' ),
				'moduleCategory'      => $block->block_type->category,
				'stylesComponent'     => array( self::class, 'module_styles' ),
				'scriptDataComponent' => array( self::class, 'module_script_data' ),
				'children'            => ElementComponents::component(
					array(
						'attrs'         => $attrs['module']['decoration'] ?? array(),
						'id'            => $block->parsed_block['id'],

						// FE only.
						'orderIndex'    => $block->parsed_block['orderIndex'],
						'storeInstance' => $block->parsed_block['storeInstance'],
					)
				) . $module_container_children,
				'childrenIds'         => $children_ids,
			)
		);
	}
}
