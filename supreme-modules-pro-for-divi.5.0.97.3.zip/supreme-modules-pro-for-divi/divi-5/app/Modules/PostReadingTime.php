<?php
/**
 * Post Reading Time module.
 *
 * Estimates minutes from the current article, a looped article, or custom text.
 * The formula in minutes_from_text() is the source of truth. The Visual Builder
 * mirror lives in packages/module-library/post-reading-time/reading-time.js.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Modules;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use DiviSupreme\Extensions\IconLibraries\LegacyModuleIconStyles;
use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Layout\Components\DynamicContent\DynamicContentUtils;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\Module\Options\Element\ElementClassnames;
use ET\Builder\Packages\Module\Options\Loop\LoopContext;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;

/**
 * Supreme Post Reading Time.
 */
class PostReadingTime implements DependencyInterface {

	/**
	 * Guards excerpt generation so a nested render does not call wp_trim_excerpt again.
	 *
	 * @var bool
	 */
	private static bool $in_excerpt = false;

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function load(): void {
		add_action( 'init', array( self::class, 'register_module' ) );
		add_action( 'rest_api_init', array( self::class, 'register_rest_routes' ) );
	}

	/**
	 * Register the module with Divi 5.
	 *
	 * @return void
	 */
	public static function register_module(): void {
		$module_json_path = DSM_DIR_PATH . 'divi-5/public/packages/module-library/post-reading-time';

		ModuleRegistration::register_module(
			$module_json_path,
			array(
				'render_callback' => array( self::class, 'render_callback' ),
			)
		);
	}

	/**
	 * REST route for the Visual Builder when the editor store cannot see the article.
	 *
	 * Returns the minute count and term names. It does not return post HTML.
	 *
	 * @return void
	 */
	public static function register_rest_routes(): void {
		register_rest_route(
			'dsm/v1',
			'/post-reading-time',
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( self::class, 'rest_minutes' ),
				'permission_callback' => static function (): bool {
					return current_user_can( 'edit_posts' );
				},
				'args'                => array(
					'post_id'     => array(
						'type'              => 'integer',
						'required'          => true,
						'sanitize_callback' => 'absint',
					),
					'source'      => array(
						'type'              => 'string',
						'default'           => 'post_content',
						'sanitize_callback' => 'sanitize_key',
					),
					'calculation' => array(
						'type'              => 'string',
						'default'           => 'words',
						'sanitize_callback' => 'sanitize_key',
					),
					'wpm'         => array(
						'type'              => 'integer',
						'default'           => 200,
						'sanitize_callback' => 'absint',
					),
				),
			)
		);
	}

	/**
	 * Builder preview payload: minutes for one post.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public static function rest_minutes( \WP_REST_Request $request ) {
		$post_id = absint( $request->get_param( 'post_id' ) );
		$post    = get_post( $post_id );

		if ( ! $post instanceof \WP_Post ) {
			return rest_ensure_response(
				array(
					'minutes' => 0,
				)
			);
		}

		if ( 'publish' !== $post->post_status && ! current_user_can( 'edit_post', $post_id ) ) {
			return new \WP_Error(
				'dsm_post_reading_time_forbidden',
				esc_html__( 'You cannot preview this post.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 403 )
			);
		}

		if ( self::is_builder_layout( $post ) ) {
			return rest_ensure_response(
				array(
					'minutes' => 0,
					'layout'  => true,
				)
			);
		}

		$source  = self::sanitize_source( (string) $request->get_param( 'source' ) );
		$method  = self::sanitize_method( (string) $request->get_param( 'calculation' ) );
		$wpm     = max( 1, min( 1000, absint( $request->get_param( 'wpm' ) ) ) );
		$text    = 'custom_content' === $source ? '' : self::source_text( $post, $source );
		$minutes = self::apply_minutes_filter(
			self::minutes_from_text( $text, $method, $wpm ),
			$post_id,
			array(
				'source' => $source,
				'method' => $method,
				'wpm'    => $wpm,
			)
		);

		return rest_ensure_response(
			array(
				'minutes' => $minutes,
			)
		);
	}

	/**
	 * Minutes for a plain-text body.
	 *
	 * Word mode uses ceil(count / wpm), minimum 1 when count > 0.
	 * Character mode uses ceil((mb_strlen / 5) / wpm), minimum 1 when length > 0.
	 * Character mode treats 5 characters as one word. That rule is ours.
	 *
	 * @param string $text   Raw source. Tags, comments, and shortcodes are removed here.
	 * @param string $method `words` or `characters`.
	 * @param int    $wpm    Words per minute. Values below 1 are treated as 1.
	 * @return int
	 */
	public static function minutes_from_text( string $text, string $method, int $wpm ): int {
		$plain = self::plain_text( $text );
		if ( '' === $plain ) {
			return 0;
		}

		$wpm = max( 1, $wpm );

		if ( 'characters' === $method ) {
			$length = function_exists( 'mb_strlen' ) ? mb_strlen( $plain ) : strlen( $plain );
			if ( $length < 1 ) {
				return 0;
			}

			return max( 1, (int) ceil( ( $length / 5 ) / $wpm ) );
		}

		$words = preg_split( '/\s+/u', $plain, -1, PREG_SPLIT_NO_EMPTY );
		$count = is_array( $words ) ? count( $words ) : 0;
		if ( $count < 1 ) {
			return 0;
		}

		return max( 1, (int) ceil( $count / $wpm ) );
	}

	/**
	 * Icon pseudo-element CSS for Divi and Font Awesome glyphs.
	 *
	 * @param array<string, mixed> $params CommonStyle params.
	 * @return string
	 */
	public static function icon_style_declaration( array $params ): string {
		return LegacyModuleIconStyles::build_pseudo_icon_declaration( $params );
	}

	/**
	 * Module styles.
	 *
	 * @param array<string, mixed> $args Style args.
	 * @return void
	 */
	public static function module_styles( array $args ): void {
		$args     = \DiviSupreme\Includes\DsmDiviBuilderCssScope::normalize_module_styles_args( $args );
		$attrs    = $args['attrs'] ?? array();
		$elements = $args['elements'];
		$order    = isset( $args['orderClass'] ) ? (string) $args['orderClass'] : '';

		Style::add(
			array(
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => array(
					$elements->style(
						array(
							'attrName'   => 'module',
							'styleProps' => array(
								'disabledOn' => array(
									'disabledModuleVisibility' => $args['settings']['disabledModuleVisibility'] ?? null,
								),
							),
						)
					),
					CssStyle::style(
						array(
							'selector' => $order,
							'attr'     => $attrs['css'] ?? array(),
						)
					),
					$elements->style(
						array(
							'attrName' => 'reading_time',
						)
					),
					$elements->style(
						array(
							'attrName' => 'prefix',
						)
					),
					$elements->style(
						array(
							'attrName' => 'suffix',
						)
					),
					$elements->style(
						array(
							'attrName' => 'icon_style',
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $order . ' .dsm_post_reading_time__icon::before',
							'attr'                => $attrs['icon']['innerContent'] ?? array(),
							'declarationFunction' => array( self::class, 'icon_style_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector' => $order . ' .dsm_post_reading_time__icon, ' . $order . ' .dsm_post_reading_time__icon::before, ' . $order . ' .dsm_post_reading_time__icon .dsm-webfont-icon-glyph, ' . $order . ' .dsm_post_reading_time__icon .dsm-native-icon-glyph',
							'attr'     => $attrs['icon_color']['innerContent'] ?? array(),
							'property' => 'color',
						)
					),
					CommonStyle::style(
						array(
							'selector' => $order . ' .dsm_post_reading_time__icon.et-pb-icon, ' . $order . ' .dsm_post_reading_time__icon::before, ' . $order . ' .dsm_post_reading_time__icon .dsm-webfont-icon-glyph, ' . $order . ' .dsm_post_reading_time__icon .dsm-native-icon-glyph',
							'attr'     => $attrs['icon_size']['innerContent'] ?? array(),
							'property' => 'font-size',
						)
					),
					CommonStyle::style(
						array(
							'selector' => $order . ' .dsm_post_reading_time__minutes',
							'attr'     => $attrs['icon_gap']['innerContent'] ?? array(),
							'property' => 'gap',
						)
					),
				),
			)
		);
	}

	/**
	 * Element script data.
	 *
	 * @param array<string, mixed> $args Script args.
	 * @return void
	 */
	public static function module_script_data( array $args ): void {
		$elements = $args['elements'];
		$elements->script_data(
			array(
				'attrName' => 'module',
			)
		);
	}

	/**
	 * Module classnames.
	 *
	 * @param array<string, mixed> $args Classname args.
	 * @return void
	 */
	public static function module_classnames( array $args ): void {
		$classnames_instance = $args['classnamesInstance'];
		$attrs               = $args['attrs'];

		$classnames_instance->add(
			ElementClassnames::classnames(
				array(
					'attrs' => $attrs['module']['decoration'] ?? array(),
				)
			)
		);
	}

	/**
	 * Frontend markup.
	 *
	 * @param array<string, mixed> $attrs    Module attributes.
	 * @param string               $content  Block content.
	 * @param \WP_Block            $block    Block instance.
	 * @param mixed                $elements Module elements.
	 * @return string
	 */
	public static function render_callback( $attrs, $content, $block, $elements ): string {
		unset( $content );

		if ( ! is_array( $attrs ) ) {
			$attrs = array();
		}

		$source  = self::inner_string( $attrs, 'content_source', 'post_content' );
		$method  = self::inner_string( $attrs, 'calculation_method', 'words' );
		$wpm     = max( 1, min( 1000, absint( self::inner_string( $attrs, 'words_per_minute', '200' ) ) ) );
		$post    = self::resolve_post( $attrs, $block );
		$text    = self::text_for_render( $post, $source, self::inner_string( $attrs, 'custom_content', '' ) );
		$minutes = self::apply_minutes_filter(
			self::minutes_from_text( $text, self::sanitize_method( $method ), $wpm ),
			$post instanceof \WP_Post ? (int) $post->ID : 0,
			array(
				'source' => self::sanitize_source( $source ),
				'method' => self::sanitize_method( $method ),
				'wpm'    => $wpm,
			)
		);

		if ( self::is_on( $attrs, 'hide_if_empty', 'on' ) && $minutes < 1 ) {
			return '';
		}

		$markup = self::render_line( $attrs, $minutes );

		$module_inner = HTMLUtility::render(
			array(
				'tag'               => 'div',
				'attributes'        => array(
					'class' => 'et_pb_module_inner',
				),
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => et_core_intentionally_unescaped( $markup, 'html' ),
			)
		);

		$module_elements = $elements->style_components(
			array(
				'attrName' => 'module',
			)
		);

		return Module::render(
			array(
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],
				'attrs'               => $attrs,
				'elements'            => $elements,
				'id'                  => $block->parsed_block['id'],
				'moduleClassName'     => 'dsm_post_reading_time',
				'name'                => $block->block_type->name,
				'classnamesFunction'  => array( self::class, 'module_classnames' ),
				'moduleCategory'      => $block->block_type->category,
				'stylesComponent'     => array( self::class, 'module_styles' ),
				'scriptDataComponent' => array( self::class, 'module_script_data' ),
				'children'            => et_core_intentionally_unescaped( $module_elements . $module_inner, 'html' ),
			)
		);
	}

	/**
	 * Strip tags, comments, and shortcodes, then collapse whitespace.
	 *
	 * Divi 5 stores the article inside block comments. Stripping those comments
	 * first would drop the body, so block copy is pulled out before that.
	 *
	 * @param string $text Raw text.
	 * @return string
	 */
	private static function plain_text( string $text ): string {
		if ( str_contains( $text, '<!-- wp:' ) ) {
			$text = self::text_from_blocks( $text );
		}

		$decoded = html_entity_decode( $text, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
		$decoded = preg_replace( '/<!--.*?-->/s', ' ', $decoded );
		if ( ! is_string( $decoded ) ) {
			$decoded = $text;
		}

		$decoded   = preg_replace( '/<[^>]+>/', ' ', $decoded );
		$decoded   = is_string( $decoded ) ? $decoded : $text;
		$stripped  = wp_strip_all_tags( strip_shortcodes( $decoded ) );
		$collapsed = preg_replace( '/\s+/u', ' ', $stripped );

		return is_string( $collapsed ) ? trim( $collapsed ) : '';
	}

	/**
	 * Desktop innerContent string.
	 *
	 * @param array<string, mixed> $attrs   Attributes.
	 * @param string               $key     Attribute key.
	 * @param string               $fallback Value used when the field is missing.
	 * @return string
	 */
	private static function inner_string( array $attrs, string $key, string $fallback ): string {
		$value = $attrs[ $key ]['innerContent']['desktop']['value'] ?? $fallback;

		if ( is_string( $value ) ) {
			return $value;
		}

		if ( is_numeric( $value ) ) {
			return (string) $value;
		}

		return $fallback;
	}

	/**
	 * Whether a yes/no field is on.
	 *
	 * @param array<string, mixed> $attrs    Attributes.
	 * @param string               $key      Attribute key.
	 * @param string               $fallback `on` or `off` when the field is missing.
	 * @return bool
	 */
	private static function is_on( array $attrs, string $key, string $fallback ): bool {
		return 'on' === self::inner_string( $attrs, $key, $fallback );
	}

	/**
	 * Limit the content source to the three supported slugs.
	 *
	 * @param string $source Raw source slug.
	 * @return string
	 */
	private static function sanitize_source( string $source ): string {
		$allowed = array( 'post_content', 'post_excerpt', 'custom_content' );

		return in_array( $source, $allowed, true ) ? $source : 'post_content';
	}

	/**
	 * Limit the calculation method to words or characters.
	 *
	 * @param string $method Raw method slug.
	 * @return string
	 */
	private static function sanitize_method( string $method ): string {
		return 'characters' === $method ? 'characters' : 'words';
	}

	/**
	 * Article used for the count.
	 *
	 * Loop items win. Singular and Theme Builder use Divi's dynamic post id.
	 * Archives without a loop have no article.
	 *
	 * `__loop_post_id` can store a term or user id. LoopContext is cleared before
	 * render, so a terms loop can still collide with a real post of the same id.
	 *
	 * @param array<string, mixed> $attrs Attributes.
	 * @param mixed                $block Block.
	 * @return \WP_Post|null
	 */
	private static function resolve_post( array $attrs, $block ): ?\WP_Post {
		$loop_id = 0;

		if ( class_exists( DynamicContentUtils::class ) && $block instanceof \WP_Block ) {
			$module_id = isset( $block->parsed_block['id'] ) ? (string) $block->parsed_block['id'] : '';
			$store     = isset( $block->parsed_block['storeInstance'] ) ? (int) $block->parsed_block['storeInstance'] : null;
			$loop_id   = DynamicContentUtils::get_loop_post_id( $attrs, $module_id, $store );
		} else {
			$loop_id = absint( $attrs['__loop_post_id'] ?? 0 );
		}

		if ( class_exists( LoopContext::class ) ) {
			$context = LoopContext::get();
			if ( null !== $context ) {
				$non_post = array( 'terms', 'post_taxonomies', 'user_roles', 'users', 'menus' );
				if ( in_array( $context->get_query_type(), $non_post, true ) ) {
					$loop_id = 0;
				}
			}
		}

		$loop_post = self::article_from_id( $loop_id );
		if ( $loop_post instanceof \WP_Post ) {
			return $loop_post;
		}

		if ( class_exists( DynamicContentUtils::class ) ) {
			$dynamic_id = DynamicContentUtils::get_dynamic_content_post_id();
			if ( is_int( $dynamic_id ) && $dynamic_id > 0 ) {
				$dynamic_post = self::article_from_id( $dynamic_id );
				if ( $dynamic_post instanceof \WP_Post ) {
					return $dynamic_post;
				}
			}
		}

		if ( is_archive() ) {
			return null;
		}

		return self::article_from_id( (int) get_the_ID() );
	}

	/**
	 * Load a post that can be counted as an article.
	 *
	 * @param int $post_id Post ID.
	 * @return \WP_Post|null
	 */
	private static function article_from_id( int $post_id ): ?\WP_Post {
		if ( $post_id < 1 ) {
			return null;
		}

		$post = get_post( $post_id );
		if ( ! $post instanceof \WP_Post || self::is_builder_layout( $post ) ) {
			return null;
		}

		$blocked = array( 'nav_menu_item', 'revision', 'attachment', 'wp_template', 'wp_template_part', 'wp_navigation', 'wp_global_styles' );
		if ( in_array( $post->post_type, $blocked, true ) ) {
			return null;
		}

		return $post;
	}

	/**
	 * Theme Builder and library posts are not articles.
	 *
	 * @param \WP_Post $post Post.
	 * @return bool
	 */
	private static function is_builder_layout( \WP_Post $post ): bool {
		$layouts = array( 'et_pb_layout', 'et_template', 'et_header_layout', 'et_body_layout', 'et_footer_layout' );

		return in_array( $post->post_type, $layouts, true );
	}

	/**
	 * Text passed to the counter.
	 *
	 * @param \WP_Post|null $post   Article, when one was resolved.
	 * @param string        $source Source slug.
	 * @param string        $custom Custom content field.
	 * @return string
	 */
	private static function text_for_render( ?\WP_Post $post, string $source, string $custom ): string {
		$source = self::sanitize_source( $source );
		if ( 'custom_content' === $source ) {
			return $custom;
		}

		if ( ! $post instanceof \WP_Post ) {
			return '';
		}

		return self::source_text( $post, $source );
	}

	/**
	 * Post body or excerpt. Empty excerpts fall back to a generated excerpt.
	 *
	 * @param \WP_Post $post   Article.
	 * @param string   $source `post_content` or `post_excerpt`.
	 * @return string
	 */
	private static function source_text( \WP_Post $post, string $source ): string {
		if ( 'post_excerpt' === $source ) {
			$excerpt = trim( (string) $post->post_excerpt );
			if ( '' !== $excerpt ) {
				return $excerpt;
			}

			$content = (string) $post->post_content;
			if ( str_contains( $content, '<!-- wp:' ) ) {
				$length = (int) apply_filters( 'excerpt_length', 55 );

				return wp_trim_words( self::plain_text( $content ), max( 1, $length ), '' );
			}

			if ( self::$in_excerpt ) {
				return $content;
			}

			self::$in_excerpt = true;
			$generated        = wp_trim_excerpt( '', $post );
			self::$in_excerpt = false;

			return is_string( $generated ) ? $generated : '';
		}

		return (string) $post->post_content;
	}

	/**
	 * Readable copy from serialized Gutenberg or Divi blocks.
	 *
	 * Uses each block's inner content strings. When a block has none, its HTML
	 * is used instead. The reading-time block is skipped so its label is not counted.
	 *
	 * @param string $content Serialized block content.
	 * @return string
	 */
	private static function text_from_blocks( string $content ): string {
		$blocks = parse_blocks( $content );
		if ( array() === $blocks ) {
			return $content;
		}

		return self::blocks_to_text( $blocks );
	}

	/**
	 * Walk parsed blocks and join their readable copy.
	 *
	 * @param array<int, array<string, mixed>> $blocks Parsed blocks.
	 * @return string
	 */
	private static function blocks_to_text( array $blocks ): string {
		$chunks = array();

		foreach ( $blocks as $block ) {
			if ( ! is_array( $block ) ) {
				continue;
			}

			$name = isset( $block['blockName'] ) ? (string) $block['blockName'] : '';
			if ( 'dsm/post-reading-time' === $name ) {
				continue;
			}

			$copy = array();
			if ( isset( $block['attrs'] ) && is_array( $block['attrs'] ) ) {
				self::collect_inner_content_strings( $block['attrs'], $copy, false );
			}

			$attr_text = trim( implode( ' ', $copy ) );
			if ( '' !== $attr_text ) {
				$chunks[] = $attr_text;
			} elseif ( isset( $block['innerHTML'] ) && is_string( $block['innerHTML'] ) && '' !== trim( $block['innerHTML'] ) ) {
				$chunks[] = $block['innerHTML'];
			}

			if ( isset( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ) {
				$nested = self::blocks_to_text( $block['innerBlocks'] );
				if ( '' !== $nested ) {
					$chunks[] = $nested;
				}
			}
		}

		return trim( implode( ' ', $chunks ) );
	}

	/**
	 * Collect desktop innerContent strings that look like copy.
	 *
	 * Tablet, phone, and hover values are skipped so the same sentence is not counted three times.
	 *
	 * @param array<mixed>       $node    Attribute tree.
	 * @param array<int, string> $chunks Collected strings.
	 * @param bool               $inside True once the walk is under innerContent.
	 * @return void
	 */
	private static function collect_inner_content_strings( array $node, array &$chunks, bool $inside ): void {
		foreach ( $node as $key => $child ) {
			if ( $inside && in_array( $key, array( 'tablet', 'phone', 'hover', 'sticky' ), true ) ) {
				continue;
			}

			$next = $inside || 'innerContent' === $key;
			if ( is_string( $child ) ) {
				if ( $next && ! self::is_setting_token( $child ) ) {
					$chunks[] = $child;
				}
				continue;
			}

			if ( is_array( $child ) ) {
				self::collect_inner_content_strings( $child, $chunks, $next );
			}
		}
	}

	/**
	 * Whether a stored value is a control token rather than article copy.
	 *
	 * @param string $value Stored innerContent string.
	 * @return bool
	 */
	private static function is_setting_token( string $value ): bool {
		$value = trim( $value );
		if ( '' === $value ) {
			return true;
		}

		if ( preg_match( '/^(on|off|yes|no|true|false|none|auto|inherit|block|flex|inline|inline-block|grid|left|right|center|justify|start|end|top|bottom|middle|words|characters|before|after|post_content|post_excerpt|custom_content|category|post_tag|divi|default|cover|contain|repeat|no-repeat)$/i', $value ) ) {
			return true;
		}

		if ( preg_match( '/^-?\d+(?:\.\d+)?(?:px|em|rem|%|vh|vw|ch|pt|ms|s)?$/', $value ) ) {
			return true;
		}

		if ( preg_match( '/^#(?:[0-9a-f]{3}|[0-9a-f]{6}|[0-9a-f]{8})$/i', $value ) ) {
			return true;
		}

		if ( preg_match( '/^rgba?\(/i', $value ) ) {
			return true;
		}

		if ( preg_match( '#^https?://\S+$#i', $value ) ) {
			return true;
		}

		return false;
	}

	/**
	 * Apply the minutes filter and keep the result at zero or above.
	 *
	 * @param int                  $minutes Computed minutes.
	 * @param int                  $post_id Article ID, or 0.
	 * @param array<string, mixed> $context Source, method, and words per minute.
	 * @return int
	 */
	private static function apply_minutes_filter( int $minutes, int $post_id, array $context ): int {
		/**
		 * Filters the reading time in minutes.
		 *
		 * @param int                  $minutes Minutes, minimum 0.
		 * @param int                  $post_id Article ID, or 0 for custom text with no post.
		 * @param array<string, mixed> $context Source, method, and words per minute.
		 */
		$filtered = apply_filters( 'dsm_post_reading_time_minutes', $minutes, $post_id, $context );

		return max( 0, (int) $filtered );
	}

	/**
	 * Visible line: prefix, icon, minutes, and suffix.
	 *
	 * @param array<string, mixed> $attrs   Attributes.
	 * @param int                  $minutes Minutes.
	 * @return string Escaped HTML.
	 */
	private static function render_line( array $attrs, int $minutes ): string {
		$prefix    = self::inner_string( $attrs, 'prefix', 'Reading time:' );
		$suffix    = self::inner_string( $attrs, 'suffix', 'min' );
		$icon_html = '';

		if ( self::is_on( $attrs, 'show_icon', 'on' ) ) {
			$icon_value = $attrs['icon']['innerContent']['desktop']['value'] ?? array();
			if ( ! is_array( $icon_value ) || '' === trim( (string) ( $icon_value['unicode'] ?? '' ) ) ) {
				$icon_value = array(
					'type'    => 'divi',
					'unicode' => '&#x7d;',
					'weight'  => '400',
				);
			}
			$icon_html = LegacyModuleIconStyles::render_custom_icon_host(
				$icon_value,
				'dsm_post_reading_time__icon'
			);
		}

		$icon_before = 'after' !== self::inner_string( $attrs, 'icon_position', 'before' );
		$count       = esc_html( (string) $minutes );
		$suffix_html = '' !== $suffix
			? '<span class="dsm_post_reading_time__suffix">' . esc_html( $suffix ) . '</span>'
			: '';
		$prefix_html = '' !== $prefix
			? '<span class="dsm_post_reading_time__prefix">' . esc_html( $prefix ) . '</span>'
			: '';

		$minutes_html = '<span class="dsm_post_reading_time__minutes">'
			. ( $icon_before ? $icon_html : '' )
			. '<span class="dsm_post_reading_time__count">' . $count . '</span>'
			. $suffix_html
			. ( $icon_before ? '' : $icon_html )
			. '</span>';

		$reading_html = '<span class="dsm_post_reading_time__reading">' . $prefix_html . $minutes_html . '</span>';

		return '<div class="dsm_post_reading_time__line">' . $reading_html . '</div>';
	}
}
