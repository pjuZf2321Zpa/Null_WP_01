<?php
/**
 * Shapes Module.
 *
 * @package DiviSupreme.
 */

declare(strict_types=1);

namespace DiviSupreme\Modules;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\Module\Options\Element\ElementClassnames;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\StyleLibrary\Declarations\BoxShadow\BoxShadow;
use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\StyleLibrary\Declarations\Background\Background;

/**
 * Class that handles "Shapes Module" module.
 */
class Shapes implements DependencyInterface {


	/**
	 * Shape type slugs for inline SVG (must match settings-content & shape-svg.js).
	 *
	 * @var list<string>
	 */
	private const SHAPES_SVG_ALLOWED_TYPES = array(
		'square',
		'circle',
		'rectangle',
		'triangle',
		'oval',
		'trapezoid',
		'parallelogram',
		'diamond_square',
		'hexagon',
		'pentagon',
		'octagon',
		'star_five',
		'semi_circle',
		'pill',
		'ring',
		'blob_one',
		'blob_two',
		'blob_three',
		'blob_four',
		'blob_five',
		'blob_six',
		'blob_seven',
		'blob_eight',
		'heart',
		'shield',
		'squircle',
		'cross_plus',
		'chevron_right',
	);

	/**
	 * Normalize range / innerContent values to a positive pixel number for shape geometry.
	 *
	 * @param mixed $raw Attribute value from style declaration callbacks.
	 * @return float
	 */
	private static function shapes_parse_size_px( $raw ): float {
		if ( is_array( $raw ) ) {
			if ( isset( $raw['value'] ) ) {
				return self::shapes_parse_size_px( $raw['value'] );
			}

			return 80.0;
		}

		if ( is_numeric( $raw ) ) {
			$n = (float) $raw;

			return $n > 0 ? $n : 80.0;
		}

		if ( is_string( $raw ) ) {
			$n = (float) preg_replace( '/[^0-9.]/', '', $raw );

			return $n > 0 ? $n : 80.0;
		}

		return 80.0;
	}

	/**
	 * Register module.
	 * `DependencyInterface` interface ensures class method name `load()` is executed for initialization.
	 */
	public function load() {
		add_action( 'init', array( self::class, 'register_module' ) );
	}

	/**
	 * Initilises the module.
	 *
	 * @return void
	 */
	public static function dsm_initialise() {
		add_action(
			'divi_module_library_modules_dependency_tree',
			function ( $dependency_tree ) {
				$dependency_tree->add_dependency( new self() );
			}
		);
	}

	/**
	 * Shape width declaration.
	 *
	 * @param mixed $params Params.
	 */
	public static function shape_width_declaration( $params ) {
		$value = self::shapes_parse_size_px( $params['attrValue'] ?? null );

		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
			)
		);

		$style_declarations->add( 'width', $value . 'px' );

		return $style_declarations->value();
	}

	/**
	 * Shape height declaration.
	 *
	 * @param mixed $params Params.
	 */
	public static function shape_height_declaration( $params ) {
		$value = self::shapes_parse_size_px( $params['attrValue'] ?? null );

		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
			)
		);

		$style_declarations->add( 'height', $value . 'px' );

		return $style_declarations->value();
	}

	/**
	 * Shape half height declaration.
	 *
	 * @param mixed $params Params.
	 */
	public static function shape_half_height_declaration( $params ) {
		$value = self::shapes_parse_size_px( $params['attrValue'] ?? null );

		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
			)
		);

		$style_declarations->add( 'height', ( $value / 2 ) . 'px' );

		return $style_declarations->value();
	}

	/**
	 * Semi-circle: full width, half height, rounded top.
	 *
	 * @param array $params Style params including attrValue.
	 * @return string
	 */
	public static function shape_semi_circle_style_declaration( $params ) {
		$value = self::shapes_parse_size_px( $params['attrValue'] ?? null );
		$half  = $value / 2;

		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
			)
		);

		$style_declarations->add( 'width', $value . 'px' );
		$style_declarations->add( 'height', $half . 'px' );

		return $style_declarations->value();
	}

	/**
	 * Rounded pill: full width, half height (SVG draws corners).
	 *
	 * @param array $params Style params including attrValue.
	 * @return string
	 */
	public static function shape_pill_style_declaration( $params ) {
		$value = self::shapes_parse_size_px( $params['attrValue'] ?? null );
		$half  = $value / 2;

		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
			)
		);

		$style_declarations->add( 'width', $value . 'px' );
		$style_declarations->add( 'height', $half . 'px' );

		return $style_declarations->value();
	}

	/**
	 * Donut ring: wrapper dimensions (stroke is drawn in SVG).
	 *
	 * @param array $params Style params including attrValue.
	 * @return string
	 */
	public static function shape_ring_style_declaration( $params ) {
		$value = self::shapes_parse_size_px( $params['attrValue'] ?? null );

		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
			)
		);

		$style_declarations->add( 'width', $value . 'px' );
		$style_declarations->add( 'height', $value . 'px' );

		return $style_declarations->value();
	}

	/**
	 * Read innerContent string for a breakpoint/state (matches VB shape toggles/selects).
	 *
	 * @param array  $element_attr Full element attribute.
	 * @param string $breakpoint   desktop|tablet|phone.
	 * @param string $state        value|hover|sticky|etc.
	 * @return string
	 */
	private static function shapes_read_inner_content_string( array $element_attr, string $breakpoint, string $state ): string {
		$ic = $element_attr['innerContent'] ?? null;
		if ( ! is_array( $ic ) ) {
			return '';
		}

		$candidates = array( $breakpoint, 'desktop', 'tablet', 'phone' );
		$candidates = array_values( array_unique( $candidates ) );

		foreach ( $candidates as $bp ) {
			if ( ! isset( $ic[ $bp ] ) || ! is_array( $ic[ $bp ] ) ) {
				continue;
			}

			$node = $ic[ $bp ];

			if ( 'value' !== $state && isset( $node[ $state ]['value'] ) && is_string( $node[ $state ]['value'] ) ) {
				return $node[ $state ]['value'];
			}

			if ( isset( $node['value'] ) ) {
				$v = $node['value'];
				if ( is_string( $v ) ) {
					return $v;
				}
				if ( is_array( $v ) && isset( $v['value'] ) && is_string( $v['value'] ) ) {
					return $v['value'];
				}
			}
		}

		return '';
	}

	/**
	 * Convert ET box-shadow CSS (no inset) to a single drop-shadow() for SVG alpha-aware shadow.
	 *
	 * @param string $css_value Output of BoxShadow::value() without inset prefix.
	 * @return string Filter value e.g. drop-shadow(0 2px 4px rgba(...)), or empty.
	 */
	private static function shapes_box_shadow_css_string_to_drop_shadow( string $css_value ): string {
		$css_value = trim( $css_value );
		if ( '' === $css_value || 'none' === strtolower( $css_value ) ) {
			return '';
		}

		if ( preg_match( '/^(.+?)\\s+((?:rgba?|hsla?)\\([^)]+\\)|#[0-9a-fA-F]{3,8})$/i', $css_value, $m ) ) {
			$dims = preg_split( '/\\s+/', trim( $m[1] ) );
			if ( is_array( $dims ) && 4 === count( $dims ) ) {
				array_pop( $dims );
			}
			$inner = implode( ' ', $dims ) . ' ' . $m[2];

			return 'drop-shadow(' . $inner . ')';
		}

		return 'drop-shadow(' . $css_value . ')';
	}

	/**
	 * Outer box shadow as filter drop-shadow on the SVG root (follows painted shape).
	 *
	 * @param array $params Style declaration params.
	 * @return string
	 */
	public static function shapes_svg_drop_shadow_declaration( $params ) {
		$attr_value = $params['attrValue'] ?? null;
		if ( ! is_array( $attr_value ) ) {
			return '';
		}

		$position = $attr_value['position'] ?? '';
		if ( 'inner' === $position ) {
			return '';
		}

		$default_attr_value = $params['defaultAttrValue'] ?? array();
		$default_attr_value = is_array( $default_attr_value ) ? $default_attr_value : array();

		$raw = BoxShadow::value( $attr_value, $default_attr_value );
		if ( '' === $raw ) {
			return '';
		}

		$raw = trim( (string) preg_replace( '/^inset\\s+/i', '', $raw ) );
		if ( '' === $raw || 'none' === strtolower( $raw ) ) {
			return '';
		}

		$filter_value = self::shapes_box_shadow_css_string_to_drop_shadow( $raw );
		if ( '' === $filter_value ) {
			return '';
		}

		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
				'important'  => $params['important'] ?? false,
			)
		);

		$style_declarations->add( 'filter', $filter_value );

		return $style_declarations->value();
	}

	/**
	 * Inner (inset) box shadow on the rectangular wrapper — SVG has no equivalent.
	 *
	 * @param array $params Style declaration params.
	 * @return string
	 */
	public static function shapes_wrapper_inset_box_shadow_declaration( $params ) {
		$attr_value = $params['attrValue'] ?? null;
		if ( ! is_array( $attr_value ) ) {
			return '';
		}

		if ( 'inner' !== ( $attr_value['position'] ?? '' ) ) {
			return '';
		}

		$default_attr_value = $params['defaultAttrValue'] ?? array();

		return BoxShadow::style_declaration(
			array(
				'attrValue'        => $attr_value,
				'defaultAttrValue' => is_array( $default_attr_value ) ? $default_attr_value : array(),
				'important'        => $params['important'] ?? false,
				'returnType'       => $params['returnType'] ?? 'string',
			)
		);
	}

	/**
	 * Map decorative border to SVG stroke on primitives (shape-following outline).
	 *
	 * @param array $params Style declaration params.
	 * @param array $attrs  Full module attrs (for toggles / shape slug).
	 * @return string
	 */
	public static function shapes_svg_vector_border_declaration( $params, array $attrs ) {
		$breakpoint = isset( $params['breakpoint'] ) && is_string( $params['breakpoint'] ) ? $params['breakpoint'] : 'desktop';
		$state      = isset( $params['state'] ) && is_string( $params['state'] ) ? $params['state'] : 'value';

		$shape_type = self::shapes_read_inner_content_string( $attrs['shapes_type'] ?? array(), $breakpoint, $state );
		if ( 'trapezoid' === $shape_type ) {
			return '';
		}

		$use_border = self::shapes_read_inner_content_string( $attrs['use_shape_border'] ?? array(), $breakpoint, $state );
		if ( 'on' !== $use_border ) {
			return '';
		}

		$attr_value = $params['attrValue'] ?? null;
		if ( ! is_array( $attr_value ) ) {
			return '';
		}

		$styles = $attr_value['styles'] ?? null;
		if ( ! is_array( $styles ) ) {
			return '';
		}

		$side_data = $styles['all'] ?? array();
		if ( empty( $side_data['width'] ) ) {
			foreach ( array( 'top', 'right', 'bottom', 'left' ) as $side ) {
				if ( ! empty( $styles[ $side ]['width'] ) ) {
					$side_data = $styles[ $side ];
					break;
				}
			}
		}

		$width   = isset( $side_data['width'] ) && is_string( $side_data['width'] ) ? trim( $side_data['width'] ) : '';
		$color   = isset( $side_data['color'] ) && is_string( $side_data['color'] ) ? trim( $side_data['color'] ) : '';
		$b_style = isset( $side_data['style'] ) && is_string( $side_data['style'] ) ? trim( $side_data['style'] ) : '';

		if ( '' === $width || '0px' === $width || '0' === $width ) {
			return '';
		}

		if ( '' === $color ) {
			$color = '#333';
		}

		if ( '' === $b_style ) {
			$b_style = 'solid';
		}

		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
				'important'  => true,
			)
		);

		$style_declarations->add( 'stroke', $color );
		$style_declarations->add( 'stroke-width', $width );
		$style_declarations->add( 'vector-effect', 'non-scaling-stroke' );
		$style_declarations->add( 'paint-order', 'fill stroke' );
		$style_declarations->add( 'stroke-linejoin', 'round' );

		if ( 'dashed' === $b_style ) {
			$style_declarations->add( 'stroke-dasharray', '6 4' );
		} elseif ( 'dotted' === $b_style ) {
			$style_declarations->add( 'stroke-dasharray', '1 4' );
			$style_declarations->add( 'stroke-linecap', 'round' );
		} else {
			$style_declarations->add( 'stroke-dasharray', 'none' );
		}

		return $style_declarations->value();
	}

	/**
	 * Register module.
	 */
	public static function register_module() {

		$module_json_path = DSM_DIR_PATH . 'divi-5/public/packages/module-library/shapes';

		ModuleRegistration::register_module(
			$module_json_path,
			array(
				'render_callback' => array( self::class, 'render_callback' ),
			)
		);
	}

	/**
	 * Render module style.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_styles( $args ) {
		$args     = \DiviSupreme\Includes\DsmDiviBuilderCssScope::normalize_module_styles_args( $args );
		$attrs    = $args['attrs'] ?? array();
		$elements = $args['elements'];

		Style::add(
			array(
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => array(
					// Module.
					$elements->style(
						array(
							'attrName'   => 'module',
							'styleProps' => array(
								'disabledOn' => array(
									'disabledModuleVisibility' => $args['settings']['disabledModuleVisibility'] ?? null,
								),
							),
						)
					),

					CssStyle::style(
						array(
							'selector' => $args['orderClass'],
							'attr'     => $attrs['css'] ?? array(),
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm_shapes_svg",
							'attr'                => $attrs['shapes_styling']['decoration']['boxShadow'] ?? array(),
							'declarationFunction' => array( static::class, 'shapes_svg_drop_shadow_declaration' ),
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm_shapes_wrapper",
							'attr'                => $attrs['shapes_styling']['decoration']['boxShadow'] ?? array(),
							'declarationFunction' => array( static::class, 'shapes_wrapper_inset_box_shadow_declaration' ),
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm_shapes_svg *",
							'attr'                => $attrs['shapes_styling']['decoration']['border'] ?? array(),
							'declarationFunction' => function ( $params ) use ( $attrs ) {
								return self::shapes_svg_vector_border_declaration( $params, $attrs );
							},
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm_shapes_wrapper",
							'attr'                => $attrs['shape_color']['innerContent'] ?? array(),
							'declarationFunction' => function ( array $params ) use ( $attrs ) {
								$breakpoint = $params['breakpoint'] ?? 'desktop';
								$state      = $params['state'] ?? 'value';
								if ( 'on' === self::shapes_read_inner_content_string( $attrs['use_shape_gradient'] ?? array(), $breakpoint, $state ) ) {
									return '';
								}
								$raw = $params['attrValue'] ?? null;
								if ( is_array( $raw ) && isset( $raw['value'] ) && is_string( $raw['value'] ) ) {
									$raw = $raw['value'];
								}
								if ( ! is_string( $raw ) || '' === $raw ) {
									return '';
								}
								$decl = new StyleDeclarations(
									array(
										'returnType' => 'string',
									)
								);
								$decl->add( 'color', $raw );

								return $decl->value();
							},
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm_shapes_wrapper",
							'attr'                => $attrs['shapes_square_size']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'shape_width_declaration' ),
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm_shapes_wrapper",
							'attr'                => $attrs['shapes_square_size']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'shape_height_declaration' ),
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm_shapes_wrapper.dsm_shapes_rectangle, {$args['orderClass']} .dsm_shapes_wrapper.dsm_shapes_oval, {$args['orderClass']} .dsm_shapes_wrapper.dsm_shapes_parallelogram",
							'attr'                => $attrs['shapes_square_size']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'shape_half_height_declaration' ),
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm_shapes_wrapper.dsm_shapes_semi_circle",
							'attr'                => $attrs['shapes_square_size']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'shape_semi_circle_style_declaration' ),
						),
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm_shapes_wrapper.dsm_shapes_pill",
							'attr'                => $attrs['shapes_square_size']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'shape_pill_style_declaration' ),
						),
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm_shapes_wrapper.dsm_shapes_ring",
							'attr'                => $attrs['shapes_square_size']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'shape_ring_style_declaration' ),
						),
					),

				),
			)
		);
	}

	/**
	 * Render module script data.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_script_data( $args ) {
		$elements = $args['elements'];

		// Element Script Data Options.
		$elements->script_data(
			array(
				'attrName' => 'module',
			)
		);
	}

	/**
	 * Render module classnames.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_classnames( $args ) {
		$classnames_instance = $args['classnamesInstance'];
		$attrs               = $args['attrs'];

		// Module.
		$classnames_instance->add(
			ElementClassnames::classnames(
				array(
					'attrs' => $attrs['module']['decoration'] ?? array(),
				)
			)
		);
	}

	// -------------------------------------------------------------------------
	// SVG markup (formerly ShapesSvg).
	// -------------------------------------------------------------------------

	/**
	 * Shapes SVG open.
	 *
	 * @param string $view_box SVG viewBox attribute value.
	 * @return string
	 */
	private static function shapes_svg_open( string $view_box ): string {
		return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="' . esc_attr( $view_box ) . '" preserveAspectRatio="xMidYMid meet" width="100%" height="100%" class="dsm_shapes_svg" aria-hidden="true" focusable="false">';
	}

	/**
	 * Shapes SVG close.
	 *
	 * @return string
	 */
	private static function shapes_svg_close(): string {
		return '</svg>';
	}

	/**
	 * Render inner SVG for a shape slug (no wrapper).
	 *
	 * @param string $type   Shape type slug.
	 * @param string $defs   Optional defs (e.g. gradient).
	 * @param string $fill   fill value (currentColor or url(#id)).
	 * @param string $stroke stroke for ring (currentColor or url(#id)).
	 * @return string
	 */
	private static function shapes_svg_render_inner( string $type, string $defs = '', string $fill = 'currentColor', string $stroke = 'currentColor' ): string {
		if ( 'star_six' === $type ) {
			$type = 'star_five';
		}

		if ( ! in_array( $type, self::SHAPES_SVG_ALLOWED_TYPES, true ) ) {
			$type = 'square';
		}

		$attr_fill = ' fill="' . esc_attr( $fill ) . '"';

		switch ( $type ) {
			case 'square':
				return self::shapes_svg_open( '0 0 100 100' ) . $defs . '<rect width="100" height="100"' . $attr_fill . ' />' . self::shapes_svg_close();

			case 'circle':
				return self::shapes_svg_open( '0 0 100 100' ) . $defs . '<circle cx="50" cy="50" r="50"' . $attr_fill . ' />' . self::shapes_svg_close();

			case 'rectangle':
				return self::shapes_svg_open( '0 0 100 100' ) . $defs . '<rect x="0" y="25" width="100" height="50"' . $attr_fill . ' />' . self::shapes_svg_close();

			case 'triangle':
				return self::shapes_svg_open( '0 0 100 100' ) . $defs . '<polygon points="50,8 92,92 8,92"' . $attr_fill . ' />' . self::shapes_svg_close();

			case 'oval':
				return self::shapes_svg_open( '0 0 100 100' ) . $defs . '<ellipse cx="50" cy="50" rx="50" ry="25"' . $attr_fill . ' />' . self::shapes_svg_close();

			case 'trapezoid':
				return self::shapes_svg_open( '0 0 100 100' ) . $defs . '<polygon points="22,22 78,22 100,92 0,92"' . $attr_fill . ' />' . self::shapes_svg_close();

			case 'parallelogram':
				return self::shapes_svg_open( '0 0 100 100' ) . $defs . '<polygon points="18,30 100,30 82,70 0,70"' . $attr_fill . ' />' . self::shapes_svg_close();

			case 'diamond_square':
				return self::shapes_svg_open( '0 0 100 100' ) . $defs . '<polygon points="50,2 98,50 50,98 2,50"' . $attr_fill . ' />' . self::shapes_svg_close();

			case 'hexagon':
				return self::shapes_svg_open( '0 0 100 100' ) . $defs . '<polygon points="50,3 97,28 97,72 50,97 3,72 3,28"' . $attr_fill . ' />' . self::shapes_svg_close();

			case 'pentagon':
				return self::shapes_svg_open( '0 0 100 100' ) . $defs . '<polygon points="50,2 99,36 80,95 20,95 1,36"' . $attr_fill . ' />' . self::shapes_svg_close();

			case 'octagon':
				return self::shapes_svg_open( '0 0 100 100' ) . $defs . '<polygon points="30,0 70,0 100,30 100,70 70,100 30,100 0,70 0,30"' . $attr_fill . ' />' . self::shapes_svg_close();

			case 'star_five':
				return self::shapes_svg_open( '0 0 100 100' ) . $defs . '<polygon points="50,2 61,35 98,35 68,57 79,91 50,70 21,91 32,57 2,35 39,35"' . $attr_fill . ' />' . self::shapes_svg_close();

			case 'semi_circle':
				return self::shapes_svg_open( '0 0 100 50' ) . $defs . '<path d="M0,50 A50,50 0 0 1 100,50 Z"' . $attr_fill . ' />' . self::shapes_svg_close();

			case 'pill':
				return self::shapes_svg_open( '0 0 100 50' ) . $defs . '<rect width="100" height="50" rx="25" ry="25"' . $attr_fill . ' />' . self::shapes_svg_close();

			case 'ring':
				return self::shapes_svg_open( '0 0 100 100' ) . $defs . '<circle cx="50" cy="50" r="38" fill="none" stroke="' . esc_attr( $stroke ) . '" stroke-width="24" />' . self::shapes_svg_close();

			case 'heart':
				return self::shapes_svg_open( '0 0 100 100' ) . $defs . '<path d="M50,88 C18,58 5,40 5,28 C5,12 20,6 35,14 C42,18 48,26 50,30 C52,26 58,18 65,14 C80,6 95,12 95,28 C95,40 82,58 50,88 Z"' . $attr_fill . ' />' . self::shapes_svg_close();

			case 'shield':
				return self::shapes_svg_open( '0 0 100 100' ) . $defs . '<polygon points="0,2 100,2 100,68 50,98 0,68"' . $attr_fill . ' />' . self::shapes_svg_close();

			case 'squircle':
				return self::shapes_svg_open( '0 0 100 100' ) . $defs . '<rect width="100" height="100" rx="32" ry="32"' . $attr_fill . ' />' . self::shapes_svg_close();

			case 'cross_plus':
				return self::shapes_svg_open( '0 0 100 100' ) . $defs . '<polygon points="33,0 67,0 67,33 100,33 100,67 67,67 67,100 33,100 33,67 0,67 0,33 33,33"' . $attr_fill . ' />' . self::shapes_svg_close();

			case 'chevron_right':
				return self::shapes_svg_open( '0 0 100 100' ) . $defs . '<polygon points="0,8 52,8 52,0 100,50 52,100 52,92 0,92 42,50"' . $attr_fill . ' />' . self::shapes_svg_close();

			case 'blob_one':
				return self::shapes_svg_open( '0 0 100 100' ) . $defs . '<path d="M50,2 C78,2 98,22 96,48 C94,78 72,100 42,98 C12,96 2,72 4,42 C6,14 28,2 50,2 Z"' . $attr_fill . ' />' . self::shapes_svg_close();

			case 'blob_two':
				return self::shapes_svg_open( '0 0 100 100' ) . $defs . '<path d="M48,0 C82,8 100,38 92,68 C84,96 52,104 24,92 C4,82 -4,54 8,28 C18,8 32,0 48,0 Z"' . $attr_fill . ' />' . self::shapes_svg_close();

			case 'blob_three':
				return self::shapes_svg_open( '0 0 100 100' ) . $defs . '<path d="M50,4 C72,0 96,18 98,42 C102,68 88,94 62,100 C32,104 6,88 2,58 C0,32 18,8 50,4 Z"' . $attr_fill . ' />' . self::shapes_svg_close();

			case 'blob_four':
				return self::shapes_svg_open( '0 0 100 100' ) . $defs . '<path d="M52,0 C80,6 100,34 94,62 C88,90 58,102 30,96 C6,90 -2,64 6,38 C12,10 34,0 52,0 Z"' . $attr_fill . ' />' . self::shapes_svg_close();

			case 'blob_five':
				return self::shapes_svg_open( '0 0 100 100' ) . $defs . '<path d="M50,3 C75,0 98,20 99,48 C100,76 80,99 52,100 C24,101 0,82 1,52 C2,26 22,6 50,3 Z"' . $attr_fill . ' />' . self::shapes_svg_close();

			case 'blob_six':
				return self::shapes_svg_open( '0 0 100 100' ) . $defs . '<path d="M50,2 C78,6 100,32 96,60 C92,88 66,102 38,98 C10,94 -2,70 4,40 C10,12 28,0 50,2 Z"' . $attr_fill . ' />' . self::shapes_svg_close();

			case 'blob_seven':
				return self::shapes_svg_open( '0 0 100 100' ) . $defs . '<path d="M50,4 C74,0 98,18 100,46 C102,74 82,98 54,100 C26,102 0,86 0,56 C0,30 22,8 50,4 Z"' . $attr_fill . ' />' . self::shapes_svg_close();

			case 'blob_eight':
				return self::shapes_svg_open( '0 0 100 100' ) . $defs . '<path d="M48,0 C76,10 100,36 96,66 C92,96 62,108 34,98 C8,90 -4,60 8,32 C16,10 32,0 48,0 Z"' . $attr_fill . ' />' . self::shapes_svg_close();

			default:
				return self::shapes_svg_open( '0 0 100 100' ) . $defs . '<rect width="100" height="100"' . $attr_fill . ' />' . self::shapes_svg_close();
		}
	}

	// -------------------------------------------------------------------------
	// SVG gradient defs (formerly ShapesGradient).
	// -------------------------------------------------------------------------

	/**
	 * Stable id for url(#…) references.
	 *
	 * @param string $block_id Block id from parsed block.
	 * @return string
	 */
	private static function shapes_gradient_unique_id( string $block_id ): string {
		$s = preg_replace( '/[^a-zA-Z0-9_-]/', '', $block_id );

		if ( '' === $s ) {
			$s = 'shape';
		}

		return 'dsm_svg_grad_' . $s;
	}

	/**
	 * Resolve merged gradient payload when toggle + enabled + stops are valid.
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 * @return array<string, mixed>|null
	 */
	private static function shapes_gradient_get_payload( array $attrs ): ?array {
		$toggle = $attrs['use_shape_gradient']['innerContent']['desktop']['value'] ?? 'off';
		if ( 'on' !== $toggle ) {
			return null;
		}

		$bg = $attrs['shape_fill']['decoration']['background']['desktop']['value'] ?? null;
		if ( ! is_array( $bg ) ) {
			return null;
		}

		$grad = $bg['gradient'] ?? null;
		if ( ! is_array( $grad ) ) {
			return null;
		}

		$base  = Background::$background_default_attr['gradient'];
		$merge = array_merge( $base, $grad );

		if ( ! isset( $merge['enabled'] ) || 'on' !== $merge['enabled'] ) {
			return null;
		}

		$stops = $merge['stops'] ?? array();
		if ( ! is_array( $stops ) || count( $stops ) < 2 ) {
			return null;
		}

		$type = isset( $merge['type'] ) ? (string) $merge['type'] : 'linear';

		if ( 'conic' === $type ) {
			return null;
		}

		return $merge;
	}

	/**
	 * SVG defs markup or empty string.
	 *
	 * @param array<string, mixed> $gradient Merged gradient attr (Divi shape).
	 * @param string               $id       Gradient element id (no #).
	 * @return string
	 */
	private static function shapes_gradient_render_defs( array $gradient, string $id ): string {
		$id_attr = esc_attr( $id );
		$type    = isset( $gradient['type'] ) ? (string) $gradient['type'] : 'linear';

		if ( 'linear' === $type ) {
			return self::shapes_gradient_linear_defs( $gradient, $id_attr );
		}

		if ( 'circular' === $type || 'elliptical' === $type ) {
			return self::shapes_gradient_radial_defs( $gradient, $id_attr );
		}

		return '';
	}

	/**
	 * Shapes gradient linear defs.
	 *
	 * @param array<string, mixed> $gradient Gradient data.
	 * @param string               $id_attr Escaped id.
	 * @return string
	 */
	private static function shapes_gradient_linear_defs( array $gradient, string $id_attr ): string {
		list($x1, $y1, $x2, $y2) = self::shapes_gradient_linear_vector( $gradient );
		$repeat                  = isset( $gradient['repeat'] ) && 'on' === $gradient['repeat'] ? 'repeat' : 'pad';
		$stops                   = self::shapes_gradient_stop_elements( $gradient['stops'] ?? array() );

		if ( '' === $stops ) {
			return '';
		}

		return sprintf(
			'<defs><linearGradient id="%1$s" gradientUnits="objectBoundingBox" x1="%2$s" y1="%3$s" x2="%4$s" y2="%5$s" spreadMethod="%6$s">%7$s</linearGradient></defs>',
			$id_attr,
			esc_attr( (string) $x1 ),
			esc_attr( (string) $y1 ),
			esc_attr( (string) $x2 ),
			esc_attr( (string) $y2 ),
			esc_attr( $repeat ),
			$stops
		);
	}

	/**
	 * Shapes gradient radial defs.
	 *
	 * @param array<string, mixed> $gradient Gradient data.
	 * @param string               $id_attr Escaped id.
	 * @return string
	 */
	private static function shapes_gradient_radial_defs( array $gradient, string $id_attr ): string {
		list($cx, $cy) = self::shapes_gradient_radial_center( $gradient['directionRadial'] ?? 'center' );
		$repeat        = isset( $gradient['repeat'] ) && 'on' === $gradient['repeat'] ? 'repeat' : 'pad';
		$stops         = self::shapes_gradient_stop_elements( $gradient['stops'] ?? array() );
		$transform     = '';

		if ( 'elliptical' === ( $gradient['type'] ?? '' ) ) {
			$transform = ' gradientTransform="translate(0.5 0.5) scale(1 0.65) translate(-0.5 -0.5)"';
		}

		if ( '' === $stops ) {
			return '';
		}

		return sprintf(
			'<defs><radialGradient id="%1$s" gradientUnits="objectBoundingBox" cx="%2$s" cy="%3$s" r="0.75"%4$s spreadMethod="%5$s">%6$s</radialGradient></defs>',
			$id_attr,
			esc_attr( (string) $cx ),
			esc_attr( (string) $cy ),
			$transform,
			esc_attr( $repeat ),
			$stops
		);
	}

	/**
	 * Shapes gradient stop elements.
	 *
	 * @param array<int|string, mixed> $stops Gradient stops.
	 * @return string
	 */
	private static function shapes_gradient_stop_elements( array $stops ): string {
		$out = '';

		foreach ( $stops as $stop ) {
			if ( ! is_array( $stop ) ) {
				continue;
			}

			$color = isset( $stop['color'] ) ? (string) $stop['color'] : '';
			$pos   = isset( $stop['position'] ) ? (string) $stop['position'] : '0';

			if ( '' === $color ) {
				continue;
			}

			if ( '' !== $pos && false === strpos( $pos, '%' ) && false === strpos( $pos, 'px' ) ) {
				$pos .= '%';
			}

			$out .= sprintf(
				'<stop offset="%s" stop-color="%s"/>',
				esc_attr( $pos ),
				esc_attr( $color )
			);
		}

		return $out;
	}

	/**
	 * ObjectBoundingBox endpoints for linearGradient.
	 *
	 * @param array<string, mixed> $gradient Gradient data.
	 * @return array{0: float, 1: float, 2: float, 3: float}
	 */
	private static function shapes_gradient_linear_vector( array $gradient ): array {
		$direction = isset( $gradient['direction'] ) ? (string) $gradient['direction'] : 'to bottom';

		$map = array(
			'to bottom'       => array( 0.0, 0.0, 0.0, 1.0 ),
			'to top'          => array( 0.0, 1.0, 0.0, 0.0 ),
			'to right'        => array( 0.0, 0.0, 1.0, 0.0 ),
			'to left'         => array( 1.0, 0.0, 0.0, 0.0 ),
			'to bottom right' => array( 0.0, 0.0, 1.0, 1.0 ),
			'to bottom left'  => array( 1.0, 0.0, 0.0, 1.0 ),
			'to top right'    => array( 0.0, 1.0, 1.0, 0.0 ),
			'to top left'     => array( 1.0, 1.0, 0.0, 0.0 ),
			'180deg'          => array( 0.0, 0.0, 0.0, 1.0 ),
			'90deg'           => array( 0.0, 0.0, 1.0, 0.0 ),
			'270deg'          => array( 1.0, 0.0, 0.0, 0.0 ),
			'0deg'            => array( 0.0, 1.0, 0.0, 0.0 ),
		);

		if ( isset( $map[ $direction ] ) ) {
			return $map[ $direction ];
		}

		if ( preg_match( '/^(-?[\\d.]+)deg$/', $direction, $m ) ) {
			$deg = (float) $m[1];
			$rad = deg2rad( $deg );
			$dx  = sin( $rad );
			$dy  = -cos( $rad );

			return array(
				0.5 - 0.5 * $dx,
				0.5 - 0.5 * $dy,
				0.5 + 0.5 * $dx,
				0.5 + 0.5 * $dy,
			);
		}

		return array( 0.0, 0.0, 0.0, 1.0 );
	}

	/**
	 * ObjectBoundingBox center for radialGradient.
	 *
	 * @param string $direction_radial Divi radial direction label.
	 * @return array{0: float, 1: float}
	 */
	private static function shapes_gradient_radial_center( string $direction_radial ): array {
		$map = array(
			'center'       => array( 0.5, 0.5 ),
			'top'          => array( 0.5, 0.0 ),
			'bottom'       => array( 0.5, 1.0 ),
			'left'         => array( 0.0, 0.5 ),
			'right'        => array( 1.0, 0.5 ),
			'top right'    => array( 1.0, 0.0 ),
			'top left'     => array( 0.0, 0.0 ),
			'bottom right' => array( 1.0, 1.0 ),
			'bottom left'  => array( 0.0, 1.0 ),
		);

		return $map[ $direction_radial ] ?? array( 0.5, 0.5 );
	}

	/**
	 * Render module HTML output.
	 *
	 * @param array     $attrs - Modules Attributes.
	 * @param string    $content - Content.
	 * @param \WP_Block $block - Block.
	 * @param mixed     $elements - Elements.
	 */
	public static function render_callback( $attrs, $content, $block, $elements ) {

		$shape_type_value = $attrs['shapes_type']['innerContent']['desktop']['value'] ?? '';
		if ( '' === $shape_type_value || ! is_string( $shape_type_value ) ) {
			$shape_type_value = 'square';
		}

		if ( 'star_six' === $shape_type_value ) {
			$shape_type_value = 'star_five';
		}

		$block_id     = isset( $block->parsed_block['id'] ) ? (string) $block->parsed_block['id'] : '';
		$grad_payload = self::shapes_gradient_get_payload( is_array( $attrs ) ? $attrs : array() );
		$svg_defs     = '';
		$svg_fill     = 'currentColor';
		$svg_stroke   = 'currentColor';

		if ( null !== $grad_payload ) {
			$grad_el_id = self::shapes_gradient_unique_id( $block_id );
			$svg_defs   = self::shapes_gradient_render_defs( $grad_payload, $grad_el_id );
			if ( '' !== $svg_defs ) {
				$paint_url = 'url(#' . $grad_el_id . ')';
				if ( 'ring' === $shape_type_value ) {
					$svg_fill   = 'none';
					$svg_stroke = $paint_url;
				} else {
					$svg_fill = $paint_url;
				}
			}
		}

		$shape_container = sprintf(
			'<div class="dsm_shapes_wrapper dsm_shapes_%1$s">%2$s</div>',
			esc_attr( $shape_type_value ),
			self::shapes_svg_render_inner( $shape_type_value, $svg_defs, $svg_fill, $svg_stroke )
		);

		// Module Inner.
		// Essentially, this is the module content.
		// Were wrapping the title and content in a div with class `et_pb_module_inner`.
		$module_inner = HTMLUtility::render(
			array(
				'tag'               => 'div',
				'attributes'        => array(
					'class' => 'et_pb_module_inner',
				),
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $shape_container,
			)
		);

		// This are the module elements that will be rendered in the frontend.
		$module_elements = $elements->style_components(
			array(
				'attrName' => 'module',
			)
		);

		// This are the children of the module container, which are the module elements and the module inner.
		$module_container_children = $module_elements . $module_inner;

		return Module::render(
			array(
				// FE only.
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],

				// VB equivalent.
				'attrs'               => $attrs,
				'elements'            => $elements,
				'id'                  => $block->parsed_block['id'],
				'moduleClassName'     => 'dsm_shapes',
				'name'                => $block->block_type->name,
				'classnamesFunction'  => array( self::class, 'module_classnames' ),
				'moduleCategory'      => $block->block_type->category,
				'stylesComponent'     => array( self::class, 'module_styles' ),
				'scriptDataComponent' => array( self::class, 'module_script_data' ),
				'children'            => $module_container_children,
			)
		);
	}
}
