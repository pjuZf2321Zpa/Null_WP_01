<?php
/**
 * Supreme Page Tour step child module (Divi 5).
 *
 * Registers the child. Frontend output is a hidden wrapper so Design styles
 * still emit; the parent hoists the Tippy popover to the footer.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Modules;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\Module\Options\Element\ElementClassnames;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;

/**
 * Class that handles the Supreme Page Tour step child module.
 */
class PageTourStep implements DependencyInterface {

	/**
	 * Register module hooks.
	 */
	public function load(): void {
		add_action( 'init', array( self::class, 'register_module' ) );
	}

	/**
	 * Adds this module to Divi's module dependency tree.
	 */
	public static function dsm_initialise(): void {
		add_action(
			'divi_module_library_modules_dependency_tree',
			static function ( $dependency_tree ) {
				$dependency_tree->add_dependency( new self() );
			}
		);
	}

	/**
	 * Register module metadata and render callback.
	 */
	public static function register_module(): void {
		$module_json_path = DSM_DIR_PATH . 'divi-5/public/packages/module-library/page-tour-step';

		ModuleRegistration::register_module(
			$module_json_path,
			array(
				'render_callback' => array( self::class, 'render_callback' ),
			)
		);
	}

	/**
	 * Background-color declaration with !important (beats Tippy theme defaults).
	 *
	 * @param array<string, mixed> $params CommonStyle params.
	 * @return string
	 */
	public static function popover_background_style_declaration( $params ): string {
		$attr_value = PageTour::css_paint_from_attr_value( $params['attrValue'] ?? '' );
		if ( '' === $attr_value ) {
			return '';
		}

		$declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
				'important'  => array(
					'background-color' => true,
				),
			)
		);
		$declarations->add( 'background-color', $attr_value );

		return $declarations->value();
	}

	/**
	 * Arrow color matching popover background.
	 *
	 * @param array<string, mixed> $params CommonStyle params.
	 * @return string
	 */
	public static function popover_arrow_style_declaration( $params ): string {
		$attr_value = PageTour::css_paint_from_attr_value( $params['attrValue'] ?? '' );
		if ( '' === $attr_value ) {
			return '';
		}

		$declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
				'important'  => array(
					'color' => true,
				),
			)
		);
		$declarations->add( 'color', $attr_value );

		return $declarations->value();
	}

	/**
	 * Scope class on the portaled Tippy popper.
	 *
	 * @param array<string, mixed> $args Style component args.
	 * @return string Selector such as `.dsm_page_tour_step_0`.
	 */
	public static function step_scope_class( array $args ): string {
		$candidates = array(
			$args['baseOrderClass'] ?? '',
			$args['orderClass'] ?? '',
		);

		foreach ( $candidates as $candidate ) {
			if ( ! is_string( $candidate ) || '' === $candidate ) {
				continue;
			}

			$token = PageTour::last_order_class_token( $candidate );
			if ( '' !== $token ) {
				return $token;
			}
		}

		return '.dsm_page_tour_step_' . (int) ( $args['orderIndex'] ?? 0 );
	}

	/**
	 * Print frontend style tags via Style API.
	 *
	 * @param array<string, mixed> $args Args passed by Divi.
	 */
	public static function module_styles( $args ): void {
		$args     = \DiviSupreme\Includes\DsmDiviBuilderCssScope::normalize_module_styles_args( $args );
		$attrs    = isset( $args['attrs'] ) && is_array( $args['attrs'] ) ? $args['attrs'] : array();
		$elements = $args['elements'];
		$scope    = self::step_scope_class( $args );
		$box      = $scope . '.dsm-page-tour__tippy .tippy-box[data-theme~=\'dsm-page-tour\'], ' . $scope . '.dsm-page-tour__tippy .tippy-box';
		$content  = $scope . '.dsm-page-tour__tippy .tippy-content';
		$arrow    = $scope . '.dsm-page-tour__tippy .tippy-arrow';
		$title    = $scope . '.dsm-page-tour__tippy .dsm-page-tour__step-title, ' . $scope . ' .dsm-page-tour__step-title';
		$body     = $scope . '.dsm-page-tour__tippy .dsm-page-tour__step-body, ' . $scope . ' .dsm-page-tour__step-body';

		Style::add(
			array(
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => array(
					$elements->style(
						array(
							'attrName'   => 'module',
							'styleProps' => array(
								'disabledOn' => array(
									'disabledModuleVisibility' => $args['settings']['disabledModuleVisibility'] ?? null,
								),
							),
						)
					),
					$elements->style(
						array(
							'attrName'   => 'title',
							'styleProps' => array(
								'selector' => $title,
								'font'     => array(
									'selectors' => array(
										'desktop' => array(
											'value' => $title,
										),
									),
								),
							),
						)
					),
					$elements->style(
						array(
							'attrName'   => 'content',
							'styleProps' => array(
								'selector' => $body,
								'bodyFont' => array(
									'selectors' => array(
										'desktop' => array(
											'value' => $body,
										),
									),
								),
							),
						)
					),
					$elements->style(
						array(
							'attrName'   => 'popover_padding',
							'styleProps' => array(
								'selector' => $content,
							),
						)
					),
					$elements->style(
						array(
							'attrName'   => 'popoverStyle',
							'styleProps' => array(
								'selector'  => $box,
								'border'    => array(
									'selector'  => $box,
									'important' => true,
								),
								'boxShadow' => array(
									'selector'   => $box,
									'useOverlay' => true,
								),
							),
						)
					),
					CssStyle::style(
						array(
							'selector' => $args['orderClass'],
							'attr'     => $attrs['css'] ?? array(),
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $box,
							'attr'                => $attrs['popover_background_color']['innerContent'] ?? array(),
							'declarationFunction' => array( self::class, 'popover_background_style_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $arrow,
							'attr'                => $attrs['popover_background_color']['innerContent'] ?? array(),
							'declarationFunction' => array( self::class, 'popover_arrow_style_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector' => $content,
							'attr'     => $attrs['popover_max_width']['innerContent'] ?? array(),
							'property' => 'max-width',
						)
					),
				),
			)
		);
	}

	/**
	 * Script data for the module wrapper.
	 *
	 * @param array<string, mixed> $args Args.
	 */
	public static function module_script_data( $args ): void {
		$elements = $args['elements'];
		$elements->script_data(
			array(
				'attrName' => 'module',
			)
		);
	}

	/**
	 * Classnames on the root module wrapper.
	 *
	 * @param array<string, mixed> $args Args.
	 */
	public static function module_classnames( $args ): void {
		$classnames_instance = $args['classnamesInstance'];
		$attrs               = $args['attrs'];

		$classnames_instance->add( 'dsm-page-tour__step' );
		$classnames_instance->add(
			ElementClassnames::classnames(
				array(
					'attrs' => $attrs['module']['decoration'] ?? array(),
				)
			)
		);
	}

	/**
	 * Frontend HTML. Hidden wrapper so styles emit; parent discards in-flow markup.
	 *
	 * @param array<string, mixed> $attrs    Parsed attributes.
	 * @param string               $content  Inner blocks markup (unused).
	 * @param \WP_Block            $block    Block instance.
	 * @param mixed                $elements Elements API.
	 * @return string
	 */
	public static function render_callback( $attrs, $content, $block, $elements ) {
		unset( $content );

		$parent       = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );
		$parent_attrs = ( is_object( $parent ) && isset( $parent->attrs ) && is_array( $parent->attrs ) )
			? $parent->attrs
			: array();

		return Module::render(
			array(
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],
				'attrs'               => $attrs,
				'parentAttrs'         => $parent_attrs,
				'elements'            => $elements,
				'id'                  => $block->parsed_block['id'],
				'moduleClassName'     => 'dsm_page_tour_step',
				'name'                => $block->block_type->name,
				'classnamesFunction'  => array( self::class, 'module_classnames' ),
				'moduleCategory'      => $block->block_type->category,
				'stylesComponent'     => array( self::class, 'module_styles' ),
				'scriptDataComponent' => array( self::class, 'module_script_data' ),
				'children'            => '',
			)
		);
	}
}
