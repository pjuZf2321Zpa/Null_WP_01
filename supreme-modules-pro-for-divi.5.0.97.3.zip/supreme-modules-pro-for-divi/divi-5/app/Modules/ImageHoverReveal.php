<?php
/**
 * Image Hover Reveal Animation module (Divi 5).
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Modules;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use DiviSupreme\Includes\Module\ImageHoverRevealSvgDecoration;
use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\Module\Options\Element\ElementClassnames;
use ET\Builder\Packages\Module\Options\Text\TextStyle;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;

/**
 * Supreme Image Hover Reveal — Splitting.js cell reveal (D4 parity).
 */
class ImageHoverReveal implements DependencyInterface {


	/**
	 * Register module.
	 */
	public function load(): void {
		add_action( 'init', array( self::class, 'register_module' ) );
	}

	/**
	 * Initialise module dependency.
	 */
	public static function dsm_initialise(): void {
		add_action(
			'divi_module_library_modules_dependency_tree',
			static function ( $dependency_tree ): void {
				$dependency_tree->add_dependency( new self() );
			}
		);
	}

	/**
	 * Register module with Divi.
	 */
	public static function register_module(): void {
		$module_json_path = DSM_DIR_PATH . 'divi-5/public/packages/module-library/image-hover-reveal';

		ModuleRegistration::register_module(
			$module_json_path,
			array(
				'render_callback' => array( self::class, 'render_callback' ),
			)
		);
	}

	/**
	 * Resolve image URL from `src.innerContent` (string or upload object).
	 *
	 * @param mixed $raw Raw desktop value.
	 * @return string
	 */
	private static function resolve_src_url( $raw ): string {
		if ( is_string( $raw ) || is_numeric( $raw ) ) {
			return trim( (string) $raw );
		}
		if ( ! is_array( $raw ) ) {
			return '';
		}
		if ( ! empty( $raw['src'] ) && is_string( $raw['src'] ) ) {
			return $raw['src'];
		}

		return '';
	}

	/**
	 * Desktop `src` URL from attrs.
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 * @return string
	 */
	private static function get_src_url( array $attrs ): string {
		$inner = $attrs['src']['innerContent'] ?? array();
		$raw   = $inner['desktop']['value'] ?? null;

		return self::resolve_src_url( $raw );
	}

	/**
	 * CSS class slug for slide direction on `.et_pb_image_wrap`.
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 * @return string
	 */
	private static function resolve_reveal_direction_class( array $attrs ): string {
		$allowed = array(
			'vert-slide-down',
			'vert-slide-up',
			'horiz-slide-right',
			'horiz-slide-left',
		);

		$mode = $attrs['image_reveal_animation']['innerContent']['desktop']['value'] ?? 'vert-slide-down';
		if ( ! is_string( $mode ) || '' === $mode || 'custom' === $mode ) {
			return 'vert-slide-down';
		}

		return in_array( $mode, $allowed, true ) ? $mode : 'vert-slide-down';
	}

	/**
	 * Rows/columns for Splitting `cells` (matches `getSplittingRowsCols` in JS).
	 *
	 * @param string $animation Animation slug.
	 * @param int    $split     Split count (presets use 5).
	 * @return array{rows: int, columns: int}
	 */
	private static function get_splitting_rows_cols( string $animation, int $split ): array {
		$horiz = ( 'horiz-slide-left' === $animation || 'horiz-slide-right' === $animation );
		$vert  = ( 'vert-slide-down' === $animation || 'vert-slide-up' === $animation );
		if ( $horiz ) {
			return array(
				'rows'    => $split,
				'columns' => 1,
			);
		}
		if ( $vert ) {
			return array(
				'rows'    => 1,
				'columns' => $split,
			);
		}

		return array(
			'rows'    => 1,
			'columns' => $split,
		);
	}

	/**
	 * Classnames callback.
	 *
	 * @param array<string, mixed> $args Arguments.
	 */
	public static function module_classnames( $args ): void {
		$classnames_instance = $args['classnamesInstance'];
		$attrs               = $args['attrs'];

		$classnames_instance->add(
			ElementClassnames::classnames(
				array(
					'attrs' => $attrs['module']['decoration'] ?? array(),
				)
			)
		);
	}

	/**
	 * Background image for reveal layers (splitting + back span).
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 * @return string
	 */
	public static function reveal_background_declaration_from_attrs( array $attrs ): string {
		$src = self::get_src_url( $attrs );
		if ( '' === $src ) {
			return '';
		}

		$safe = ( is_string( $src ) && str_starts_with( $src, 'data:' ) )
			? esc_attr( $src )
			: esc_url( $src );

		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
				'important'  => array(
					'background-image' => true,
				),
			)
		);

		$style_declarations->add( 'background-image', 'url(\'' . $safe . '\')' );

		return $style_declarations->value();
	}

	/**
	 * Render module style.
	 *
	 * @param array<string, mixed> $args Arguments.
	 */
	public static function module_styles( array $args ): void {
		$args     = \DiviSupreme\Includes\DsmDiviBuilderCssScope::normalize_module_styles_args( $args );
		$attrs    = $args['attrs'] ?? array();
		$elements = $args['elements'];

		$styles_list = array(
			$elements->style(
				array(
					'attrName'   => 'module',
					'styleProps' => array(
						'disabledOn' => array(
							'disabledModuleVisibility' => $args['settings']['disabledModuleVisibility'] ?? null,
						),
					),
				)
			),

			TextStyle::style(
				array(
					'selector' => $args['orderClass'],
					'attr'     => $attrs['module']['advanced']['text'] ?? array(),
				)
			),

			CssStyle::style(
				array(
					'selector' => $args['orderClass'],
					'attr'     => $attrs['css'] ?? array(),
				)
			),

			$elements->style(
				array(
					'attrName' => 'image_wrap_style',
				)
			),

			CommonStyle::style(
				array(
					'selector'            => "{$args['orderClass']} .dsm-image-reveal-back, {$args['orderClass']} .splitting",
					'attr'                => $attrs['src']['innerContent'] ?? array(),
					'declarationFunction' => function () use ( $attrs ) {
						return self::reveal_background_declaration_from_attrs( $attrs );
					},
				)
			),

			CommonStyle::style(
				array(
					'selector' => "{$args['orderClass']} .dsm-image-reveal .splitting",
					'attr'     => $attrs['image_reveal_height']['innerContent'] ?? array(),
					'property' => 'height',
				)
			),

			CommonStyle::style(
				array(
					'selector' => "{$args['orderClass']} .dsm-image-reveal .et_pb_image_wrap",
					'attr'     => $attrs['image_reveal_height']['innerContent'] ?? array(),
					'property' => 'height',
				)
			),
		);

		if ( ImageHoverRevealSvgDecoration::is_svg_url( self::get_src_url( $attrs ) ) ) {
			$styles_list[] = CommonStyle::style(
				array(
					'selector' => "{$args['orderClass']} .et_pb_image_wrap",
					'attr'     => array(
						'desktop' => array(
							'value' => 'block',
						),
					),
					'property' => 'display',
				)
			);
		}

		Style::add(
			array(
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => $styles_list,
			)
		);
	}

	/**
	 * Render callback.
	 *
	 * @param array<string, mixed>               $attrs    Block attrs.
	 * @param string                             $content  Children (unused).
	 * @param \WP_Block                          $block    Block.
	 * @param \ET\Builder\Modules\ModuleElements $elements Module elements.
	 * @return string
	 */
	public static function render_callback( $attrs, $content, $block, $elements ) {
		$direction = self::resolve_reveal_direction_class( $attrs );

		$src = self::get_src_url( $attrs );
		if ( '' === $src ) {
			return '';
		}

		wp_enqueue_script( 'dsm-image-hover-reveal' );

		$split          = 5;
		$rows_cols      = self::get_splitting_rows_cols( $direction, $split );
		$data_rows_attr = sprintf( ' data-rows="%d"', $rows_cols['rows'] );
		$data_cols_attr = sprintf( ' data-columns="%d"', $rows_cols['columns'] );

		$root         = ImageHoverRevealSvgDecoration::root_id_class_from_decoration( $attrs );
		$reveal_class = 'dsm-image-reveal';
		if ( '' !== trim( (string) $root['class'] ) ) {
			$reveal_class .= ' ' . trim( (string) $root['class'] );
		}
		$reveal_id_attr = '' !== $root['id'] ? ' id="' . esc_attr( (string) $root['id'] ) . '"' : '';

		$wrap = sprintf(
			'<div class="%4$s"%5$s><div class="dsm-image-wrapper"><span class="et_pb_image_wrap %1$s"%2$s%3$s><span class="dsm-image-reveal-back"></span></span></div></div>',
			esc_attr( $direction ),
			$data_rows_attr,
			$data_cols_attr,
			esc_attr( $reveal_class ),
			$reveal_id_attr
		);

		$inner = sprintf(
			'<div class="et_pb_module_inner">%s</div>',
			$wrap
		);

		$module_elements = $elements->style_components(
			array(
				'attrName' => 'module',
			)
		);

		$module_container_children = $module_elements . $inner;

		return Module::render(
			array(
				'orderIndex'         => $block->parsed_block['orderIndex'],
				'storeInstance'      => $block->parsed_block['storeInstance'],
				'attrs'              => $attrs,
				'elements'           => $elements,
				'id'                 => $block->parsed_block['id'],
				'name'               => $block->block_type->name,
				'classnamesFunction' => array( self::class, 'module_classnames' ),
				'moduleCategory'     => $block->block_type->category,
				'stylesComponent'    => array( self::class, 'module_styles' ),
				'children'           => $module_container_children,
			)
		);
	}
}
