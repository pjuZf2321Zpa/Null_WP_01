<?php
/**
 * Faq Module.
 *
 * @package DiviSupreme.
 */

declare(strict_types=1);

namespace DiviSupreme\Modules;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\Module\Options\Element\ElementClassnames;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Options\Element\ElementComponents;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use DiviSupreme\Includes\DsmFrontendModuleAssetRegistry;
use DiviSupreme\Includes\Divi5Conversion\ConversionAttrs;
use DiviSupreme\Includes\ModuleRegisterAttrsNormalize;
use DiviSupreme\Extensions\IconLibraries\LegacyModuleIconStyles;


/**
 * Class that handles "Faq Module" module.
 */
class Faq implements DependencyInterface {


	/**
	 * Collected `Question` objects for the current request (all `dsm/faq` modules with schema enabled).
	 *
	 * Printed once in `wp_footer` as a single `FAQPage` JSON-LD block.
	 *
	 * @var array<int, array<string, mixed>>
	 */
	private static $schema_main_entities = array();

	/**
	 * Register module.
	 * `DependencyInterface` interface ensures class method name `load()` is executed for initialization.
	 */
	public function load() {
		add_filter(
			'divi_module_library_register_module_attrs',
			array( self::class, 'filter_register_module_attrs' ),
			10,
			2
		);

		add_action( 'init', array( self::class, 'register_module' ) );
	}

	/**
	 * Migrate legacy FAQ toggle plain-color saves into decoration background blobs.
	 *
	 * @param array<string, mixed> $module_attrs Merged attrs.
	 * @param array<string, mixed> $filter_args  Context (`name`, `attrs`, …).
	 * @return array<string, mixed>
	 */
	public static function filter_register_module_attrs( $module_attrs, $filter_args ) {
		if ( ! is_array( $module_attrs ) || ! is_array( $filter_args ) ) {
			return is_array( $module_attrs ) ? $module_attrs : array();
		}

		if ( ( $filter_args['name'] ?? '' ) !== 'dsm/faq' ) {
			return $module_attrs;
		}

		ModuleRegisterAttrsNormalize::faq_merged( $module_attrs );

		return $module_attrs;
	}

	/**
	 * Initilises the module.
	 *
	 * @return void
	 */
	public static function dsm_initialise() {
		add_action(
			'divi_module_library_modules_dependency_tree',
			function ( $dependency_tree ) {
				$dependency_tree->add_dependency( new self() );
			}
		);
	}

	/**
	 * Register module.
	 */
	public static function register_module() {

		$module_json_path = DSM_DIR_PATH . 'divi-5/public/packages/module-library/faq';

		ModuleRegistration::register_module(
			$module_json_path,
			array(
				'render_callback' => array( self::class, 'render_callback' ),
			)
		);

		add_action( 'template_redirect', array( self::class, 'reset_faq_schema_collection' ), 0 );
		add_action( 'wp_footer', array( self::class, 'maybe_print_combined_faq_schema' ), 99 );
	}

	/**
	 * Clears the per-request FAQ schema queue (before block output).
	 *
	 * @return void
	 */
	public static function reset_faq_schema_collection(): void {
		self::$schema_main_entities = array();
	}

	/**
	 * Outputs one `FAQPage` JSON-LD script combining all FAQ modules on the page.
	 *
	 * @return void
	 */
	public static function maybe_print_combined_faq_schema(): void {
		if ( empty( self::$schema_main_entities ) ) {
			return;
		}

		/**
		 * Filter the combined FAQ `mainEntity` list before deduplication and encoding.
		 *
		 * @param array<int, array<string, mixed>> $entities Question graph items.
		 */
		$entities = apply_filters( 'dsm_faq_schema_main_entities', self::$schema_main_entities );
		if ( ! \is_array( $entities ) ) {
			return;
		}

		$entities = self::dedupe_faq_question_entities( $entities );
		if ( empty( $entities ) ) {
			return;
		}

		$schema = array(
			'@context'   => 'https://schema.org',
			'@type'      => 'FAQPage',
			'mainEntity' => $entities,
		);

		$json = self::encode_faq_schema_json( $schema );
		if ( '' === $json ) {
			return;
		}

		// JSON-LD is already escaped for script embedding via encode_faq_schema_json().
		echo '<script type="application/ld+json">' . $json . '</script>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/**
	 * Drops duplicate questions (case-insensitive `name`), keeping the first occurrence.
	 *
	 * @param array<int, array<string, mixed>> $entities Question items.
	 * @return array<int, array<string, mixed>>
	 */
	private static function dedupe_faq_question_entities( array $entities ): array {
		$seen = array();
		$out  = array();

		foreach ( $entities as $entity ) {
			$name = $entity['name'] ?? '';
			if ( ! \is_string( $name ) ) {
				continue;
			}

			$key = strtolower( trim( $name ) );
			if ( '' === $key || isset( $seen[ $key ] ) ) {
				continue;
			}

			$seen[ $key ] = true;
			$out[]        = $entity;
		}

		return $out;
	}

	/**
	 * Ensure module library CSS is loaded (FAQ styles are bundled in `packages/module-library/style.scss` / `vb.scss`).
	 *
	 * Frontend with dynamic assets: `public/packages/module-library/{faq|faq-child}/frontend.css`.
	 * Otherwise: bundled `style-modules-frontend-styles.css`. Visual Builder: `modules-vb-styles.css`.
	 *
	 * @return void
	 */
	public static function enqueue_module_styles(): void {
		$is_vb = function_exists( 'et_core_is_fb_enabled' ) && et_core_is_fb_enabled();

		if ( function_exists( 'dsm_supreme_dynamic_assets_enabled' ) && dsm_supreme_dynamic_assets_enabled() && ! $is_vb ) {
			$split_ok = false;
			foreach ( array( 'dsm/faq', 'dsm/faq-child' ) as $faq_block_slug ) {
				if ( DsmFrontendModuleAssetRegistry::maybe_enqueue_split_frontend_stylesheet_for_block( $faq_block_slug ) ) {
					$split_ok = true;
				}
			}
			if ( $split_ok ) {
				return;
			}
		}

		if ( wp_style_is( \DiviSupreme\Includes\DsmFrontendModuleAssetRegistry::CORE_MODULES_STYLE_HANDLE, 'enqueued' ) ) {
			return;
		}
		if ( wp_style_is( \DiviSupreme\Includes\DsmFrontendModuleAssetRegistry::CORE_MODULES_STYLE_HANDLE, 'registered' ) ) {
			wp_enqueue_style( \DiviSupreme\Includes\DsmFrontendModuleAssetRegistry::CORE_MODULES_STYLE_HANDLE );
			return;
		}

		\DiviSupreme\Includes\DsmFrontendModuleAssetRegistry::refresh_scoped_frontend_style_handles();

		$version = defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';
		$is_vb   = function_exists( 'et_core_is_fb_enabled' ) && et_core_is_fb_enabled();
		$src     = $is_vb
			? DSM_DIR_URL . 'public/modules-vb-styles.css'
			: \DiviSupreme\Includes\DsmDiviBuilderCssScope::resolve_stylesheet_url(
				DSM_DIR_URL . 'public/style-modules-frontend-styles.css'
			);

		wp_enqueue_style(
			\DiviSupreme\Includes\DsmFrontendModuleAssetRegistry::CORE_MODULES_STYLE_HANDLE,
			$src,
			array(),
			$version
		);
	}

	/**
	 * Toggle icon open style declaration.
	 *
	 * @param mixed $params Params.
	 */
	public static function toggle_icon_open_style_declaration( $params ) {
		return LegacyModuleIconStyles::build_pseudo_icon_declaration( $params );
	}

	/**
	 * Toggle icon close style declaration.
	 *
	 * @param mixed $params Params.
	 */
	public static function toggle_icon_close_style_declaration( $params ) {
		return LegacyModuleIconStyles::build_pseudo_icon_declaration( $params );
	}

	/**
	 * Accordion item gap style declaration.
	 *
	 * @param mixed $params Params.
	 */
	public static function accordion_item_gap_style_declaration( $params ) {
		$attr = $params['attrValue'] ?? array();

		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
				'important'  => array(
					'margin-bottom' => true,
				),
			)
		);

		$style_declarations->add( 'margin-bottom', $attr );

		return $style_declarations->value();
	}

	/**
	 * Render module style.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_styles( $args ) {
		$args = \DiviSupreme\Includes\DsmDiviBuilderCssScope::normalize_module_styles_args( $args );
		// `ModuleElements::style()` reads from `$elements->module_attrs`, not `$args['attrs']`.
		// Migrate legacy color-picker `innerContent` → `decoration.background` on every FE/VB paint.
		$elements = $args['elements'] ?? null;
		if ( is_object( $elements ) && isset( $elements->module_attrs ) && \is_array( $elements->module_attrs ) ) {
			ConversionAttrs::migrate_faq_toggle_legacy_inner_content_color_into_decoration_background( $elements->module_attrs );
		}
		if ( ! empty( $args['attrs'] ) && \is_array( $args['attrs'] ) ) {
			ConversionAttrs::migrate_faq_toggle_legacy_inner_content_color_into_decoration_background( $args['attrs'] );
		}

		$attrs = $args['attrs'] ?? array();

		Style::add(
			array(
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => array(
					// Module.
					$elements->style(
						array(
							'attrName'   => 'module',
							'styleProps' => array(
								'disabledOn' => array(
									'disabledModuleVisibility' => $args['settings']['disabledModuleVisibility'] ?? null,
								),
							),
						)
					),

					CssStyle::style(
						array(
							'selector' => $args['orderClass'],
							'attr'     => $attrs['css'] ?? array(),
						)
					),

					$elements->style(
						array(
							'attrName' => 'header',
						)
					),

					$elements->style(
						array(
							'attrName' => 'closed_header',
						)
					),

					$elements->style(
						array(
							'attrName' => 'content',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_content_padding',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_content_margin',
						)
					),

					$elements->style(
						array(
							'attrName' => 'toggleOpenStateStyle',
						)
					),

					$elements->style(
						array(
							'attrName' => 'toggleCloseStateStyle',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_close_icon_margin',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_close_icon_padding',
						)
					),

					$elements->style(
						array(
							'attrName' => 'iconOpenStateStyle',
						)
					),

					$elements->style(
						array(
							'attrName' => 'iconCloseStateStyle',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_open_icon_margin',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_open_icon_padding',
						)
					),

					$elements->style(
						array(
							'attrName' => 'iconOpenStateStyle',
						)
					),

					$elements->style(
						array(
							'attrName' => 'imageOpenStateStyle',
						)
					),

					$elements->style(
						array(
							'attrName' => 'imageCloseStateStyle',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_open_image_margin',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_open_image_padding',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_open_toggle_margin',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_open_toggle_padding',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_closed_toggle_margin',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_closed_toggle_padding',
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm-faq-item-wrapper",
							'attr'                => $attrs['dsm_accordion_gap']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'accordion_item_gap_style_declaration' ),
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm-title-wrapper .et-pb-icon.dsm_open_icon::before",
							'attr'                => $attrs['dsm_open_font_icon']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'toggle_icon_open_style_declaration' ),
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm-title-wrapper .et-pb-icon.dsm_close_icon::before",
							'attr'                => $attrs['dsm_close_font_icon']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'toggle_icon_close_style_declaration' ),
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_close_bg_color',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_open_bg_color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-faq-item-wrapper .et-pb-icon.dsm_open_icon, {$args['orderClass']} .dsm-faq-item-wrapper .et-pb-icon.dsm_faq-item-open_icon",
							'attr'     => $attrs['dsm_open_font_size']['innerContent'] ?? array(),
							'property' => 'font-size',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-faq-item-wrapper .et-pb-icon.dsm_close_icon, {$args['orderClass']} .dsm-faq-item-wrapper .et-pb-icon.dsm_faq-item-close_icon",
							'attr'     => $attrs['dsm_close_font_size']['innerContent'] ?? array(),
							'property' => 'font-size',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-faq-item-wrapper .et-pb-icon.dsm_close_icon, {$args['orderClass']} .dsm-faq-item-wrapper .et-pb-icon.dsm_faq-item-close_icon",
							'attr'     => $attrs['dsm_close_icon_bg_color']['innerContent'] ?? array(),
							'property' => 'background',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-faq-item-wrapper .et-pb-icon.dsm_close_icon, {$args['orderClass']} .dsm-faq-item-wrapper .et-pb-icon.dsm_faq-item-close_icon",
							'attr'     => $attrs['dsm_close_icon_color']['innerContent'] ?? array(),
							'property' => 'color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-faq-item-wrapper .et-pb-icon.dsm_open_icon, {$args['orderClass']} .dsm-faq-item-wrapper .et-pb-icon.dsm_faq-item-open_icon",
							'attr'     => $attrs['dsm_open_icon_bg_color']['innerContent'] ?? array(),
							'property' => 'background',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-faq-item-wrapper .et-pb-icon.dsm_open_icon, {$args['orderClass']} .dsm-faq-item-wrapper .et-pb-icon.dsm_faq-item-open_icon",
							'attr'     => $attrs['dsm_open_icon_color']['innerContent'] ?? array(),
							'property' => 'color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-faq-item-wrapper .dsm_open_image",
							'attr'     => $attrs['dsm_open_image_width']['innerContent'] ?? array(),
							'property' => 'width',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-faq-item-wrapper .dsm_open_image",
							'attr'     => $attrs['dsm_open_image_width']['innerContent'] ?? array(),
							'property' => 'height',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-faq-item-wrapper .dsm_close_image",
							'attr'     => $attrs['dsm_close_image_width']['innerContent'] ?? array(),
							'property' => 'width',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-faq-item-wrapper .dsm_close_image",
							'attr'     => $attrs['dsm_close_image_width']['innerContent'] ?? array(),
							'property' => 'height',
						)
					),
				),
			)
		);
	}

	/**
	 * Render module script data.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_script_data( $args ) {
		$elements = $args['elements'];

		// Element Script Data Options.
		$elements->script_data(
			array(
				'attrName' => 'module',
			)
		);
	}

	/**
	 * Render module classnames.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_classnames( $args ) {
		$classnames_instance = $args['classnamesInstance'];
		$attrs               = $args['attrs'];

		// Module.
		$classnames_instance->add(
			ElementClassnames::classnames(
				array(
					'attrs' => $attrs['module']['decoration'] ?? array(),
				)
			)
		);
	}

	/**
	 * HTML tags allowed in FAQ `Answer.text` (Google FAQ rich-result / schema.org; unsupported tags are stripped).
	 *
	 * @return array<string, array<string, bool>>
	 */
	private static function get_faq_answer_schema_allowed_tags(): array {
		return array(
			'a'      => array(
				'href'   => true,
				'title'  => true,
				'target' => true,
				'rel'    => true,
			),
			'b'      => array(),
			'br'     => array(),
			'div'    => array( 'class' => true ),
			'em'     => array(),
			'h1'     => array(),
			'h2'     => array(),
			'h3'     => array(),
			'h4'     => array(),
			'h5'     => array(),
			'h6'     => array(),
			'i'      => array(),
			'li'     => array(),
			'ol'     => array(),
			'p'      => array(),
			'strong' => array(),
			'ul'     => array(),
			'span'   => array( 'class' => true ),
		);
	}

	/**
	 * Collapse whitespace for plain-text schema fields (Question `name`).
	 *
	 * @param string $text Raw text.
	 * @return string
	 */
	private static function normalize_faq_schema_plain_text( string $text ): string {
		$text = preg_replace( '/\s+/u', ' ', $text );

		return trim( (string) $text );
	}

	/**
	 * Full question text for `Question.name` (plain text, no HTML).
	 *
	 * @param \DOMElement $title_element `.dsm-faq-title` node.
	 * @return string
	 */
	private static function get_faq_question_name_for_schema( \DOMElement $title_element ): string {
		$doc = $title_element->ownerDocument; // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- External object property.
		if ( null === $doc ) {
			return '';
		}

		$html = $doc->saveHTML( $title_element );
		$text = wp_strip_all_tags( $html, true );

		return self::normalize_faq_schema_plain_text( $text );
	}

	/**
	 * Answer markup for `Answer.text` (allowed HTML preserved; see Google FAQ structured data docs).
	 *
	 * @param \DOMElement $answer_element `.dsm-faq-content` node.
	 * @return string
	 */
	private static function get_faq_answer_text_for_schema( \DOMElement $answer_element ): string {
		$doc = $answer_element->ownerDocument; // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- External object property.
		if ( null === $doc ) {
			return '';
		}

		$html = '';
		foreach ( $answer_element->childNodes as $child ) { // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- External object property.
			$html .= $doc->saveHTML( $child );
		}

		$html = trim( $html );
		$html = wp_kses( $html, self::get_faq_answer_schema_allowed_tags() );

		return trim( $html );
	}

	/**
	 * JSON-LD payload safe for `<script type="application/ld+json">`.
	 *
	 * @param array<string, mixed> $schema FAQPage graph.
	 * @return string JSON or empty string on failure.
	 */
	private static function encode_faq_schema_json( array $schema ): string {
		$flags = JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS;
		if ( \defined( 'JSON_INVALID_UTF8_SUBSTITUTE' ) ) {
			$flags |= JSON_INVALID_UTF8_SUBSTITUTE;
		}

		$json = wp_json_encode( $schema, $flags );
		if ( false === $json || ! \is_string( $json ) ) {
			return '';
		}

		return $json;
	}

	/**
	 * Parses rendered FAQ HTML into schema.org `Question` items (one per valid row).
	 *
	 * @param string $content Rendered inner blocks HTML.
	 * @return array<int, array<string, mixed>>
	 */
	private static function extract_faq_question_entities_from_content( $content ) {
		if ( '' === trim( (string) $content ) ) {
			return array();
		}

		$entities = array();

		libxml_use_internal_errors( true );

		$document = new \DOMDocument();
		$document->loadHTML( '<?xml encoding="utf-8" ?>' . $content );
		$finder = new \DOMXPath( $document );

		$faq_items = $finder->query( '//*[contains(@class, "dsm-faq-item-wrapper")]' );

		foreach ( $faq_items as $current_faq_item ) {
			$faq_title_element  = $finder->query( 'descendant::*[contains(@class, "dsm-faq-title")]', $current_faq_item )->item( 0 );
			$faq_answer_element = $finder->query( 'descendant::*[contains(@class, "dsm-faq-content")]', $current_faq_item )->item( 0 );

			if ( ! ( $faq_title_element instanceof \DOMElement ) || ! ( $faq_answer_element instanceof \DOMElement ) ) {
				continue;
			}

			$faq_title  = self::get_faq_question_name_for_schema( $faq_title_element );
			$faq_answer = self::get_faq_answer_text_for_schema( $faq_answer_element );

			if ( '' === $faq_title || '' === trim( wp_strip_all_tags( $faq_answer ) ) ) {
				continue;
			}

			$entities[] = array(
				'@type'          => 'Question',
				'name'           => $faq_title,
				'acceptedAnswer' => array(
					'@type' => 'Answer',
					'text'  => $faq_answer,
				),
			);
		}

		return $entities;
	}

	/**
	 * Builds a standalone FAQPage JSON-LD script from one HTML fragment (tests / legacy helpers).
	 *
	 * @param string $content Rendered inner blocks HTML.
	 * @return string Script tag or empty string if nothing valid to emit.
	 */
	public static function generate_schema_support( $content ) {
		$entities = self::extract_faq_question_entities_from_content( $content );
		if ( empty( $entities ) ) {
			return '';
		}

		$schema = array(
			'@context'   => 'https://schema.org',
			'@type'      => 'FAQPage',
			'mainEntity' => $entities,
		);

		$json = self::encode_faq_schema_json( $schema );
		if ( '' === $json ) {
			return '';
		}

		return '<script type="application/ld+json">' . $json . '</script>';
	}

	/**
	 * Whether a parent FAQ icon picker leaf is empty (default ET icon fallback).
	 *
	 * @param mixed $icon Icon picker leaf.
	 * @return bool
	 */
	private static function faq_parent_icon_is_empty( $icon ): bool {
		if ( is_array( $icon ) ) {
			return '' === (string) ( $icon['unicode'] ?? '' );
		}

		return '' === $icon;
	}

	/**
	 * Render module HTML output.
	 *
	 * @param array     $attrs - Modules Attributes.
	 * @param string    $content - Content.
	 * @param \WP_Block $block - Block.
	 * @param mixed     $elements - Elements.
	 */
	public static function render_callback( $attrs, $content, $block, $elements ) {
		if ( is_object( $elements ) && isset( $elements->module_attrs ) && \is_array( $elements->module_attrs ) ) {
			ConversionAttrs::migrate_faq_toggle_legacy_inner_content_color_into_decoration_background( $elements->module_attrs );
		}
		if ( \is_array( $attrs ) ) {
			ConversionAttrs::migrate_faq_toggle_legacy_inner_content_color_into_decoration_background( $attrs );
		}

		$children_ids = $block->parsed_block['innerBlocks'] ? array_map(
			function ( $inner_block ) {
				return $inner_block['id'];
			},
			$block->parsed_block['innerBlocks']
		) : array();

		$parent       = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );
		$parent_attrs = $parent->attrs ?? array();

		$dsm_make_accordion_toggle = $attrs['dsm_make_accordion_toggle']['innerContent']['desktop']['value'] ?? 'off';
		$dsm_open_faq_item         = $attrs['dsm_open_faq_item']['innerContent']['desktop']['value'] ?? 'off';
		$dsm_enable_schema_markup  = $attrs['dsm_enable_schema_markup']['innerContent']['desktop']['value'] ?? 'off';
		$dsm_animate_icon          = $attrs['dsm_animate_icon']['innerContent']['desktop']['value'] ?? 'off';

		$dsm_open_font_icon  = $attrs['dsm_open_font_icon']['innerContent']['desktop']['value'] ?? '';
		$dsm_close_font_icon = $attrs['dsm_close_font_icon']['innerContent']['desktop']['value'] ?? '';

		$is_open_font_icon  = self::faq_parent_icon_is_empty( $dsm_open_font_icon ) ? 'dsm-open-font-icon-empty' : '';
		$is_close_font_icon = self::faq_parent_icon_is_empty( $dsm_close_font_icon ) ? 'dsm-close-font-icon-empty' : '';

		$dsm_icon_placement   = $attrs['dsm_icon_placement']['innerContent']['desktop']['value'] ?? 'left';
		$icon_placement_class = 'right' === $dsm_icon_placement ? 'dsm-icon-placement-right' : '';

		wp_enqueue_script( 'dsm-faq' );
		self::enqueue_module_styles();

		if ( 'on' === $dsm_enable_schema_markup ) {
			foreach ( self::extract_faq_question_entities_from_content( $content ) as $entity ) {
				self::$schema_main_entities[] = $entity;
			}
		}

		$container = sprintf(
			'<div class="dsm-faq-container dsm-front %5$s %6$s %7$s %8$s" data-accordion="%2$s" data-open_first_item="%3$s">%1$s</div>%4$s',
			$content,
			$dsm_make_accordion_toggle,
			$dsm_open_faq_item,
			'',
			'on' === $dsm_animate_icon ? 'dsm-animate-icon' : '',
			$is_open_font_icon,
			$is_close_font_icon,
			$icon_placement_class
		);

		// Module Inner.
		// Essentially, this is the module content.
		// Were wrapping the title and content in a div with class `et_pb_module_inner`.
		$module_inner = HTMLUtility::render(
			array(
				'tag'               => 'div',
				'attributes'        => array(
					'class' => 'et_pb_module_inner',
				),
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $container,
			)
		);

		// This are the module elements that will be rendered in the frontend.
		$module_elements = $elements->style_components(
			array(
				'attrName' => 'module',
			)
		);

		// This are the children of the module container, which are the module elements and the module inner.
		$module_container_children = $module_elements . $module_inner;

		return Module::render(
			array(
				// FE only.
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],
				// VB equivalent.
				'attrs'               => $attrs,
				'parentAttrs'         => $parent_attrs,
				'elements'            => $elements,
				'id'                  => $block->parsed_block['id'],
				'moduleClassName'     => '',
				'name'                => $block->block_type->name,
				'classnamesFunction'  => array( self::class, 'module_classnames' ),
				'moduleCategory'      => $block->block_type->category,
				'stylesComponent'     => array( self::class, 'module_styles' ),
				'scriptDataComponent' => array( self::class, 'module_script_data' ),
				'children'            => ElementComponents::component(
					array(
						'attrs'         => $attrs['module']['decoration'] ?? array(),
						'id'            => $block->parsed_block['id'],

						// FE only.
						'orderIndex'    => $block->parsed_block['orderIndex'],
						'storeInstance' => $block->parsed_block['storeInstance'],
					)
				) . $module_container_children,
				'childrenIds'         => $children_ids,
			)
		);
	}
}
