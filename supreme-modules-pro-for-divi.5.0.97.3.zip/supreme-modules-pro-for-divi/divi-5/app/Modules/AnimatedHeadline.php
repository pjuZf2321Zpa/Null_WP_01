<?php
/**
 * Typing Effect Module.
 *
 * @package DiviSupreme.
 */

declare(strict_types=1);

namespace DiviSupreme\Modules;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}


use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\Module\Options\Element\ElementClassnames;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use ET\Builder\Packages\Module\Options\Text\TextStyle;
use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;
use ET\Builder\Packages\Module\Options\Css\CssStyle;

/**
 * Class that handles "AnimatedHeadline Module" module.
 */
class AnimatedHeadline implements DependencyInterface {



	/**
	 * Extract color value from either hex or variable format.
	 *
	 * @param string $color_value The color value to process.
	 * @return string The processed color value.
	 */
	private static function extract_color_value( $color_value ) {
		// Check if the color value is in variable format.
		if ( strpos( $color_value, '$variable' ) === 0 ) {
			// Extract the variable data.
			$variable_data = substr( $color_value, 10, -2 ); // Remove $variable( and )$.
			$decoded_data  = json_decode( $variable_data, true );

			// Return the variable name if it exists.
			if ( isset( $decoded_data['value']['name'] ) ) {
				return 'var(--' . $decoded_data['value']['name'] . ')';
			}
		}

		// Return the original value if it's a hex color or invalid format.
		return $color_value;
	}

	/**
	 * Register module.
	 * `DependencyInterface` interface ensures class method name `load()` is executed for initialization.
	 */
	public function load() {
		add_action( 'init', array( self::class, 'register_module' ) );
	}

	/**
	 * Initilises the module.
	 *
	 * @return void
	 */
	public static function dsm_initialise() {
		add_action(
			'divi_module_library_modules_dependency_tree',
			function ( $dependency_tree ) {
				$dependency_tree->add_dependency( new self() );
			}
		);
	}

	/**
	 * Register module.
	 */
	public static function register_module() {

		$module_json_path = DSM_DIR_PATH . 'divi-5/public/packages/module-library/animated-headline';

		ModuleRegistration::register_module(
			$module_json_path,
			array(
				'render_callback' => array( self::class, 'render_callback' ),
			)
		);
	}

	/**
	 * Render module style.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_styles( $args ) {
		$args     = \DiviSupreme\Includes\DsmDiviBuilderCssScope::normalize_module_styles_args( $args );
		$attrs    = $args['attrs'] ?? array();
		$elements = $args['elements'];

		Style::add(
			array(
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => array(
					$elements->style(
						array(
							'attrName'   => 'module',
							'styleProps' => array(
								'disabledOn' => array(
									'disabledModuleVisibility' => $args['settings']['disabledModuleVisibility'] ?? null,
								),
							),
						)
					),

					CssStyle::style(
						array(
							'selector' => $args['orderClass'],
							'attr'     => $attrs['css'] ?? array(),
						)
					),

					$elements->style(
						array(
							'attrName' => 'header',
						)
					),

					$elements->style(
						array(
							'attrName' => 'prefix',
						)
					),

					$elements->style(
						array(
							'attrName' => 'suffix',
						)
					),

					$elements->style(
						array(
							'attrName' => 'animated_headline',
						)
					),

					$elements->style(
						array(
							'attrName' => 'prefix_style',
						)
					),

					$elements->style(
						array(
							'attrName' => 'prefix_spacing',
						)
					),

					$elements->style(
						array(
							'attrName' => 'suffix_style',
						)
					),

					$elements->style(
						array(
							'attrName' => 'suffix_spacing',
						)
					),

					$elements->style(
						array(
							'attrName' => 'animated_headline_style',
						)
					),

					$elements->style(
						array(
							'attrName' => 'animated_headline_spacing',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-animated-prefix",
							'attr'     => $attrs['prefix_background']['innerContent'] ?? array(),
							'property' => 'background-color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-animated-suffix",
							'attr'     => $attrs['suffix_background']['innerContent'] ?? array(),
							'property' => 'background-color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-animated-words-wrapper",
							'attr'     => $attrs['animated_headline_background']['innerContent'] ?? array(),
							'property' => 'background-color',
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm-animated-prefix",
							'attr'                => $attrs['prefix_display_type']['innerContent'] ?? array(),
							'declarationFunction' => function ( $params ) {
								$attr = $params['attrValue'] ?? array();

								$style_declarations = new StyleDeclarations(
									array(
										'returnType' => 'string',
										'important'  => array(
											'display' => true,
										),
									)
								);

								if ( 'inline' === $attr ) {
									$style_declarations->add( 'display', 'inline' );
								}

								if ( 'inline-block' === $attr ) {
									$style_declarations->add( 'display', 'inline-block' );
								}

								if ( 'block' === $attr ) {
									$style_declarations->add( 'display', 'block' );
								}

								return $style_declarations->value();
							},
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm-animated-words-wrapper",
							'attr'                => $attrs['animated_display_type']['innerContent'] ?? array(),
							'declarationFunction' => function ( $params ) {
								$attr = $params['attrValue'] ?? array();

								$style_declarations = new StyleDeclarations(
									array(
										'returnType' => 'string',
										'important'  => array(
											'display' => true,
										),
									)
								);

								if ( 'inline' === $attr ) {
									$style_declarations->add( 'display', 'inline' );
								}

								if ( 'inline-block' === $attr ) {
									$style_declarations->add( 'display', 'inline-block' );
								}

								if ( 'block' === $attr ) {
									$style_declarations->add( 'display', 'block' );
								}

								return $style_declarations->value();
							},
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm-animated-suffix",
							'attr'                => $attrs['suffix_display_type']['innerContent'] ?? array(),
							'declarationFunction' => function ( $params ) {
								$attr = $params['attrValue'] ?? array();

								$style_declarations = new StyleDeclarations(
									array(
										'returnType' => 'string',
										'important'  => array(
											'display' => true,
										),
									)
								);

								if ( 'inline' === $attr ) {
									$style_declarations->add( 'display', 'inline' );
								}

								if ( 'inline-block' === $attr ) {
									$style_declarations->add( 'display', 'inline-block' );
								}

								if ( 'block' === $attr ) {
									$style_declarations->add( 'display', 'block' );
								}

								return $style_declarations->value();
							},
						)
					),
				),
			)
		);
	}

	/**
	 * Render module script data.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_script_data( $args ) {
		$elements = $args['elements'];

		$elements->script_data(
			array(
				'attrName' => 'module',
			)
		);
	}

	/**
	 * Render module classnames.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_classnames( $args ) {
		$classnames_instance = $args['classnamesInstance'];
		$attrs               = $args['attrs'];

		$classnames_instance->add(
			ElementClassnames::classnames(
				array(
					'attrs' => $attrs['module']['decoration'] ?? array(),
				)
			)
		);

		$effect              = $attrs['effects']['innerContent']['desktop']['value'] ?? 'rotate1';
		$effect_formatted    = str_replace( array( 'rotate1', 'rotate2', 'rotate3', 'loadingBar' ), array( 'rotate-1', 'rotate-2', 'rotate-3', 'loading-bar' ), $effect );
		$letter_effects      = array( 'scale', 'type', 'rotate-2', 'rotate-3' );
		$needs_letters_class = in_array( $effect_formatted, $letter_effects, true );

		$classnames_instance->add( 'dsm-animated-headline' );
		$classnames_instance->add( 'et_pb_module_header' );
		$classnames_instance->add( 'dsm-headline' );

		if ( $needs_letters_class ) {
			$classnames_instance->add( 'dsm-headline-letters' );
		}

		$classnames_instance->add( $effect_formatted );
	}

	/**
	 * Enqueue module scripts.
	 */
	public static function enqueue_scripts() {
		wp_enqueue_script( 'dsm-animated-headline' );
	}

	/**
	 * Render module HTML output.
	 *
	 * @param array     $attrs - Modules Attributes.
	 * @param string    $content - Content.
	 * @param \WP_Block $block - Block.
	 * @param mixed     $elements - Elements.
	 */
	public static function render_callback( $attrs, $content, $block, $elements ) {

		self::enqueue_scripts();

		$prefix                      = $attrs['prefix']['innerContent']['desktop']['value'] ?? '';
		$suffix                      = $attrs['suffix']['innerContent']['desktop']['value'] ?? '';
		$words                       = $attrs['animated_headline']['innerContent']['desktop']['value'] ?? array();
		$effect                      = $attrs['effects']['innerContent']['desktop']['value'] ?? 'rotate1';
		$anim_delay                  = $attrs['animation_delay']['innerContent']['desktop']['value'] ?? 2500;
		$letters_delay               = $attrs['letters_delay']['innerContent']['desktop']['value'] ?? 50;
		$type_letters_delay          = $attrs['type_letters_delay']['innerContent']['desktop']['value'] ?? 150;
		$type_selection_duration     = $attrs['type_selection_duration']['innerContent']['desktop']['value'] ?? 500;
		$clip_reveal_duration        = $attrs['clip_reveal_duration']['innerContent']['desktop']['value'] ?? 600;
		$clip_reveal_animation_delay = $attrs['clip_reveal_animation_delay']['innerContent']['desktop']['value'] ?? 1500;
		$bar_width                   = $attrs['bar_width']['innerContent']['desktop']['value'] ?? 1;
		$bar_color                   = self::extract_color_value( $attrs['bar_color']['innerContent']['desktop']['value'] ) ?? '#2c3e50';
		$text_highlight              = self::extract_color_value( $attrs['text_highlight']['innerContent']['desktop']['value'] ) ?? '#2c3e50';
		$text_color                  = self::extract_color_value( $attrs['text_color']['innerContent']['desktop']['value'] ) ?? '#ffffff';
		$bar_height                  = $attrs['bar_height']['innerContent']['desktop']['value'] ?? 3;
		$tag                         = $attrs['tag']['innerContent']['desktop']['value'] ?? 'div';

		$type_letters_delay      = (int) $type_letters_delay;
		$type_selection_duration = (int) $type_selection_duration;
		$anim_delay              = (int) $anim_delay;
		$letters_delay           = (int) $letters_delay;
		$bar_width               = (int) $bar_width;
		$bar_height              = (int) $bar_height;

		$effect_formatted = str_replace( array( 'rotate1', 'rotate2', 'rotate3', 'loadingBar' ), array( 'rotate-1', 'rotate-2', 'rotate-3', 'loading-bar' ), $effect );

		$letter_effects      = array( 'scale', 'type', 'rotate-2', 'rotate-3' );
		$needs_letters_class = in_array( $effect_formatted, $letter_effects, true );

		$words_markup = '';
		if ( is_array( $words ) ) {
			foreach ( $words as $index => $word_obj ) {
				$word          = is_string( $word_obj ) ? $word_obj : ( $word_obj['value'] ?? '' );
				$class         = 0 === $index ? 'is-visible' : 'is-hidden';
				$words_markup .= sprintf( '<b class="%s">%s</b>', esc_attr( $class ), esc_html( $word ) );
			}
		}

		$animated_headline_options = array(
			'effect'                   => $effect_formatted,
			'animationDelay'           => $anim_delay,
			'lettersDelay'             => $letters_delay,
			'typeLettersDelay'         => $type_letters_delay,
			'typeSelectionDuration'    => $type_selection_duration,
			'clipRevealDuration'       => $clip_reveal_duration,
			'clipRevealAnimationDelay' => $clip_reveal_animation_delay,
		);

		$container = sprintf(
			'<%1$s class="dsm-headline %2$s%3$s" data-dsm-animated-headline-options="%4$s" style="--dsm-bar-width: %5$spx; --dsm-bar-height: %6$spx; --dsm-bar-color: %7$s; --dsm-text-highlight: %8$s; --dsm-text-color: %9$s;"><div class="dsm-animated-headlines-words-container">%10$s<span class="dsm-animated-words-wrapper">%11$s</span>%12$s</div></%1$s>',
			esc_attr( $tag ),
			esc_attr( $effect_formatted ),
			$needs_letters_class ? ' dsm-headline-letters' : '',
			esc_attr( wp_json_encode( $animated_headline_options ) ),
			esc_attr( $bar_width ),
			esc_attr( $bar_height ),
			esc_attr( $bar_color ),
			esc_attr( $text_highlight ),
			esc_attr( $text_color ),
			! empty( $prefix ) ? sprintf( '<span class="dsm-animated-prefix">%s</span>', esc_html( $prefix ) ) : '',
			$words_markup,
			! empty( $suffix ) ? sprintf( '<span class="dsm-animated-suffix">%s</span>', esc_html( $suffix ) ) : ''
		);

		$module_inner = HTMLUtility::render(
			array(
				'tag'               => 'div',
				'attributes'        => array(
					'class' => 'et_pb_module_inner',
				),
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $container,
			)
		);

		$module_elements = $elements->style_components(
			array(
				'attrName' => 'module',
			)
		);

		$module_container_children = $module_elements . $module_inner;

		$output = Module::render(
			array(
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],
				'attrs'               => $attrs,
				'elements'            => $elements,
				'id'                  => $block->parsed_block['id'],
				'name'                => $block->block_type->name,
				'classnamesFunction'  => array( self::class, 'module_classnames' ),
				'moduleCategory'      => $block->block_type->category,
				'stylesComponent'     => array( self::class, 'module_styles' ),
				'scriptDataComponent' => array( self::class, 'module_script_data' ),
				'children'            => $module_container_children,
			)
		);

		return $output;
	}
}
