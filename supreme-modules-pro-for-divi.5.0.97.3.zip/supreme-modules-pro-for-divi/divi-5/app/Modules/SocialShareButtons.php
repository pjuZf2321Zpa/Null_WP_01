<?php
/**
 * SocialShare Buttons Module.
 *
 * @package DiviSupreme.
 */

declare(strict_types=1);

namespace DiviSupreme\Modules;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\Module\Options\Element\ElementClassnames;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Options\Element\ElementComponents;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;
use ET\Builder\Packages\Module\Options\Css\CssStyle;


/**
 * Class that handles "Social Share Button Module" module.
 *
 * D4 `module_id` / `module_class` migrate to D5 `module.decoration.attributes` through the shared
 * conversion outline value expansion map and
 * {@see \DiviSupreme\Includes\Divi5Conversion\SupremeSharedConversion::post_convert_merge_decoration_attributes()}.
 */
class SocialShareButtons implements DependencyInterface {



	/**
	 * Register module.
	 * `DependencyInterface` interface ensures class method name `load()` is executed for initialization.
	 */
	public function load() {
		add_action( 'init', array( self::class, 'register_module' ) );
	}

	/**
	 * Initilises the module.
	 *
	 * @return void
	 */
	public static function dsm_initialise() {
		add_action(
			'divi_module_library_modules_dependency_tree',
			function ( $dependency_tree ) {
				$dependency_tree->add_dependency( new self() );
			}
		);
	}


	/**
	 * Read innerContent string for a breakpoint (D4 parity for button height vs size).
	 *
	 * @param array<string, mixed> $inner_content dsm_* innerContent array.
	 * @param string               $breakpoint    desktop|tablet|phone.
	 * @return string
	 */
	private static function social_share_read_inner_content_string( array $inner_content, string $breakpoint ): string {
		if ( isset( $inner_content[ $breakpoint ] ) && is_array( $inner_content[ $breakpoint ] ) ) {
			$v = $inner_content[ $breakpoint ]['value'] ?? '';
			return is_string( $v ) ? $v : '';
		}

		if ( isset( $inner_content['desktop']['value'] ) && is_string( $inner_content['desktop']['value'] ) ) {
			return $inner_content['desktop']['value'];
		}

		return '';
	}

	/**
	 * D4 parity: `font-size` when button size is set; `height: 4.5em` only when `dsm_button_height`
	 * is empty for this breakpoint; when size is empty return nothing (baseline `45px` from SCSS).
	 *
	 * @param array<string, mixed> $params Declaration params from CommonStyle.
	 * @param array<string, mixed> $attrs  Module attrs.
	 * @return string
	 */
	public static function social_share_button_size_style_declaration( array $params, array $attrs ): string {
		$breakpoint = isset( $params['breakpoint'] ) && is_string( $params['breakpoint'] ) ? $params['breakpoint'] : 'desktop';

		$size_raw = $params['attrValue'] ?? null;
		if ( is_array( $size_raw ) && isset( $size_raw['value'] ) ) {
			$size_raw = $size_raw['value'];
		}

		$size = is_string( $size_raw ) ? $size_raw : '';
		if ( '' === $size ) {
			return '';
		}

		$height_ic = $attrs['dsm_button_height']['innerContent'] ?? array();
		if ( ! is_array( $height_ic ) ) {
			$height_ic = array();
		}

		$height = self::social_share_read_inner_content_string( $height_ic, $breakpoint );

		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
				'important'  => array(
					'font-size' => true,
				),
			)
		);

		$style_declarations->add( 'font-size', "calc($size * 10)" );

		if ( '' === $height ) {
			$style_declarations->add( 'height', '4.5em' );
		}

		return $style_declarations->value();
	}

	/**
	 * Register module.
	 */
	public static function register_module() {

		$module_json_path = DSM_DIR_PATH . 'divi-5/public/packages/module-library/social-share-buttons';

		ModuleRegistration::register_module(
			$module_json_path,
			array(
				'render_callback' => array( self::class, 'render_callback' ),
			)
		);
	}

	/**
	 * Render module style.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_styles( $args ) {
		$args           = \DiviSupreme\Includes\DsmDiviBuilderCssScope::normalize_module_styles_args( $args );
		$attrs          = $args['attrs'] ?? array();
		$elements       = $args['elements'];
		$dsm_color_type = $attrs['dsm_color_type']['innerContent']['desktop']['value'] ?? '';

		Style::add(
			array(
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => array(
					// Module.
					$elements->style(
						array(
							'attrName'   => 'module',
							'styleProps' => array(
								'disabledOn' => array(
									'disabledModuleVisibility' => $args['settings']['disabledModuleVisibility'] ?? null,
								),
							),
						)
					),

					CssStyle::style(
						array(
							'selector' => $args['orderClass'],
							'attr'     => $attrs['css'] ?? array(),
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_label_text',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-social-share-buttons-container .dsm-social-share-button-inner-wrapper",
							'attr'     => $attrs['dsm_button_height']['innerContent'] ?? array(),
							'property' => 'height',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']}  .dsm-social-share-button-icon .dsm_icon",
							'attr'     => $attrs['dsm_icon_size']['innerContent'] ?? array(),
							'property' => 'font-size',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']}",
							'attr'     => $attrs['dsm_alignment']['innerContent'] ?? array(),
							'property' => 'text-align',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-social-share-buttons-container",
							'attr'     => $attrs['dsm_column_gap']['innerContent'] ?? array(),
							'property' => 'column-gap',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-social-share-buttons-container",
							'attr'     => $attrs['dsm_row_gap']['innerContent'] ?? array(),
							'property' => 'row-gap',
						)
					),

					'custom' === $dsm_color_type ?
					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-social-share-buttons-container .dsm-social-share-button-inner-wrapper",
							'attr'     => $attrs['dsm_custom_bg_color']['innerContent'] ?? array(),
							'property' => 'background-color',
						)
					) : '',

					'custom' === $dsm_color_type ?
					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-social-share-buttons-container .dsm-social-share-button-inner-wrapper",
							'attr'     => $attrs['dsm_custom_color']['innerContent'] ?? array(),
							'property' => 'color',
						)
					) : '',

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm-social-share-button-inner-wrapper",
							'attr'                => $attrs['dsm_button_size']['innerContent'] ?? array(),
							'declarationFunction' => function ( array $params ) use ( $attrs ) {
								return self::social_share_button_size_style_declaration( $params, $attrs );
							},
						)
					),
				),
			)
		);
	}

	/**
	 * Render module script data.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_script_data( $args ) {
		$elements = $args['elements'];

		// Element Script Data Options.
		$elements->script_data(
			array(
				'attrName' => 'module',
			)
		);
	}

	/**
	 * Render module classnames.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_classnames( $args ) {
		$classnames_instance = $args['classnamesInstance'];
		$attrs               = $args['attrs'];
		$dsm_column          = $attrs['dsm_column']['innerContent']['desktop']['value'] ?? '';
		$dsm_shape           = $attrs['dsm_shape']['innerContent']['desktop']['value'] ?? '';

		// Module.
		$classnames_instance->add(
			ElementClassnames::classnames(
				array(
					'attrs' => $attrs['module']['decoration'] ?? array(),
				)
			)
		);

		$classnames_instance->add( 'dsm-social-share-button-column-' . $dsm_column );
		$classnames_instance->add( 'dsm-social-share-button-shape-' . $dsm_shape );
	}

	/**
	 * Render module HTML output.
	 *
	 * @param array     $attrs - Modules Attributes.
	 * @param string    $content - Content.
	 * @param \WP_Block $block - Block.
	 * @param mixed     $elements - Elements.
	 */
	public static function render_callback( $attrs, $content, $block, $elements ) {

		$dsm_skin = $attrs['dsm_skin']['innerContent']['desktop']['value'] ?? '';
		$dsm_view = $attrs['dsm_view']['innerContent']['desktop']['value'] ?? '';

		$children_ids = $block->parsed_block['innerBlocks'] ? array_map(
			function ( $inner_block ) {
				return $inner_block['id'];
			},
			$block->parsed_block['innerBlocks']
		) : array();

		$parent       = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );
		$parent_attrs = $parent->attrs ?? array();

		wp_enqueue_script( 'dsm-social-share-button' );

		$container = sprintf(
			'<div class="dsm-social-share-buttons-container dsm-%2$s dsm-%3$s">
			   %1$s
			</div>',
			$content,
			$dsm_skin,
			$dsm_view
		);

		// Module Inner.
		// Essentially, this is the module content.
		// Were wrapping the title and content in a div with class `et_pb_module_inner`.
		$module_inner = HTMLUtility::render(
			array(
				'tag'               => 'div',
				'attributes'        => array(
					'class' => 'et_pb_module_inner',
				),
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $container,
			)
		);

		// This are the module elements that will be rendered in the frontend.
		$module_elements = $elements->style_components(
			array(
				'attrName' => 'module',
			)
		);

		// This are the children of the module container, which are the module elements and the module inner.
		$module_container_children = $module_elements . $module_inner;

		return Module::render(
			array(
				// FE only.
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],
				// VB equivalent.
				'attrs'               => $attrs,
				'parentAttrs'         => $parent_attrs,
				'elements'            => $elements,
				'id'                  => $block->parsed_block['id'],
				'moduleClassName'     => '',
				'name'                => $block->block_type->name,
				'classnamesFunction'  => array( self::class, 'module_classnames' ),
				'moduleCategory'      => $block->block_type->category,
				'stylesComponent'     => array( self::class, 'module_styles' ),
				'scriptDataComponent' => array( self::class, 'module_script_data' ),
				'children'            => ElementComponents::component(
					array(
						'attrs'         => $attrs['module']['decoration'] ?? array(),
						'id'            => $block->parsed_block['id'],

						// FE only.
						'orderIndex'    => $block->parsed_block['orderIndex'],
						'storeInstance' => $block->parsed_block['storeInstance'],
					)
				) . $module_container_children,
				'childrenIds'         => $children_ids,
			)
		);
	}
}
