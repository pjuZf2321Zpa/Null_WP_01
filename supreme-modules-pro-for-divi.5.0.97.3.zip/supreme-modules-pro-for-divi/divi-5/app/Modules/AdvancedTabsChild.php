<?php
/**
 * Advanced Tabs Child Module.
 *
 * @package DiviSupreme.
 */

declare(strict_types=1);

namespace DiviSupreme\Modules;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}


use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\Module\Options\Element\ElementClassnames;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\Packages\ModuleUtils\ChildrenUtils;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;
use DiviSupreme\Extensions\IconLibraries\LegacyModuleIconStyles;


/**
 * Class that handles "AdvancedTabsChild Module" module.
 */
class AdvancedTabsChild implements DependencyInterface {



	/**
	 * Register module.
	 * `DependencyInterface` interface ensures class method name `load()` is executed for initialization.
	 */
	public function load() {
		add_action( 'init', array( self::class, 'register_module' ) );
	}

	/**
	 * Initilises the module.
	 *
	 * @return void
	 */
	public static function dsm_initialise() {
		add_action(
			'divi_module_library_modules_dependency_tree',
			function ( $dependency_tree ) {
				$dependency_tree->add_dependency( new self() );
			}
		);
	}

	/**
	 * Register module.
	 */
	public static function register_module() {

		$module_json_path = DSM_DIR_PATH . 'divi-5/public/packages/module-library/advanced-tabs-child';

		ModuleRegistration::register_module(
			$module_json_path,
			array(
				'render_callback' => array( self::class, 'render_callback' ),
			)
		);
	}

	/**
	 * Tab icon style declaration.
	 *
	 * @param mixed $params Params.
	 */
	public static function tab_icon_style_declaration( $params ) {
		return LegacyModuleIconStyles::build_pseudo_icon_declaration( $params );
	}

	/**
	 * Tab active icon style declaration.
	 *
	 * @param mixed $params Params.
	 */
	public static function tab_active_icon_style_declaration( $params ) {
		return LegacyModuleIconStyles::build_pseudo_icon_declaration( $params );
	}

	/**
	 * Tab content icon style declaration.
	 *
	 * @param mixed $params Params.
	 */
	public static function tab_content_icon_style_declaration( $params ) {
		return LegacyModuleIconStyles::build_pseudo_icon_declaration( $params );
	}


	/**
	 * Content image icon placement declaration.
	 *
	 * @param mixed $params Params.
	 */
	public static function content_image_icon_placement_declaration( $params ) {
		$attr = $params['attrValue'] ?? array();

		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
				'important'  => array(
					'flex-direction' => true,
				),
			)
		);

		if ( 'top' === $attr ) {
			$style_declarations->add( 'flex-direction', 'column' );
		}

		if ( 'left' === $attr ) {
			$style_declarations->add( 'flex-direction', 'row' );
		}

		return $style_declarations->value();
	}

	/**
	 * D4 complementary column width: `100 - (int) dsm_content_image_width` when placement is left.
	 *
	 * @param array<string, mixed> $params Declaration params including `attrValue` (e.g. `50%`).
	 * @return string
	 */
	public static function content_image_remaining_width_declaration( $params ) {
		return AdvancedTabs::content_image_remaining_width_declaration( $params );
	}

	/**
	 * Render module style.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_styles( $args ) {
		$args        = \DiviSupreme\Includes\DsmDiviBuilderCssScope::normalize_module_styles_args( $args );
		$order_class = (string) ( $args['orderClass'] ?? '' );
		$sc          = static function ( string $parent_chain, string $suffix = '' ) use ( $order_class ): string {
			return \DiviSupreme\Includes\DsmDiviBuilderCssScope::scoped_child_selector( $parent_chain, $order_class, $suffix );
		};
		$attrs       = $args['attrs'] ?? array();
		$elements    = $args['elements'];

		Style::add(
			array(
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => array(
					// Module.
					$elements->style(
						array(
							'attrName'   => 'module',
							'styleProps' => array(
								'disabledOn' => array(
									'disabledModuleVisibility' => $args['settings']['disabledModuleVisibility'] ?? null,
								),
							),
						)
					),

					CssStyle::style(
						array(
							'selector' => $args['orderClass'],
							'attr'     => $attrs['css'] ?? array(),
						)
					),

					$elements->style(
						array(
							'attrName' => 'tab_title',
						)
					),

					$elements->style(
						array(
							'attrName' => 'tab_subtitle',
						)
					),

					$elements->style(
						array(
							'attrName' => 'content_title',
						)
					),

					$elements->style(
						array(
							'attrName' => 'tab_content_text',
						)
					),

					$elements->style(
						array(
							'attrName' => 'tab_image_icon_style',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_tab_margin',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_tab_padding',
						)
					),

					$elements->style(
						array(
							'attrName' => 'button',
						)
					),

					$elements->style(
						array(
							'attrName' => 'content_image_icon_style',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_content_margin',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_content_padding',
						)
					),

					// Font-icon ::before glyphs: AdvancedTabs::render_child_tab_font_icon_styles (parent render) so FE
					// still gets rules when Divi skips child stylesComponent (e.g. static CSS).

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm-inner-content-wrapper",
							'attr'                => $attrs['dsm_content_image_icon_placement']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'content_image_icon_placement_declaration' ),
						)
					),

					CommonStyle::style(
						array(
							'selector' => $sc( '.dsm_advanced_tabs .dsm-advanced-tabs-container', ' .dsm-icon-wrapper .et-pb-icon.dsm_icon' ) . ', ' . $sc( '.dsm_advanced_tabs .dsm-advanced-tabs-container', ' .dsm-active-icon-wrapper .et-pb-icon.dsm-active-icon' ),
							'attr'     => $attrs['dsm_tabs_icon_size']['innerContent'] ?? array(),
							'property' => 'font-size',
						)
					),

					CommonStyle::style(
						array(
							'selector' => $sc( '.dsm_advanced_tabs .dsm-advanced-tabs-container', ' .dsm-icon-wrapper .et-pb-icon.dsm_icon' ),
							'attr'     => $attrs['dsm_tabs_icon_color']['innerContent'] ?? array(),
							'property' => 'color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => $sc( '.dsm_advanced_tabs .dsm-advanced-tabs-container', '.dsm-tab.dsm-active .dsm-active-icon-wrapper .et-pb-icon.dsm-active-icon' ) . ', ' . $sc( '.dsm_advanced_tabs .dsm-advanced-tabs-container', '.dsm-tab.dsm-active .dsm-active-icon-wrapper .et-pb-icon.dsm-active-icon::before' ) . ', ' . $sc( '.dsm_advanced_tabs .dsm-advanced-tabs-container', '.dsm-tab.dsm-active .dsm-icon-wrapper .et-pb-icon.dsm_icon' ) . ', ' . $sc( '.dsm_advanced_tabs .dsm-advanced-tabs-container', '.dsm-tab.dsm-active .dsm-icon-wrapper .et-pb-icon.dsm_icon::before' ),
							'attr'     => $attrs['dsm_tabs_active_icon_color']['innerContent'] ?? array(),
							'property' => 'color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => $sc( '.dsm-advanced-tabs-container', '.dsm-content-wrapper .dsm-image' ),
							'attr'     => $attrs['dsm_content_image_width']['innerContent'] ?? array(),
							'property' => 'width',
						)
					),

					CommonStyle::style(
						array(
							'selector'            => $sc( '.dsm-advanced-tabs-container', '.dsm-content-wrapper.dsm-content-image.dsm-left .dsm-inner-content' ),
							'attr'                => $attrs['dsm_content_image_width']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'content_image_remaining_width_declaration' ),
						)
					),

					CommonStyle::style(
						array(
							'selector' => $sc( '.dsm-advanced-tabs-container', '.dsm-tab .dsm-image' ),
							'attr'     => $attrs['dsm_tabs_image_width']['innerContent'] ?? array(),
							'property' => 'width',
						)
					),

					CommonStyle::style(
						array(
							'selector'            => $sc( '.dsm-advanced-tabs-container.dsm-tabs-image-icon-top', '.dsm-tab .dsm-image' ) . ', ' . $sc( '.dsm-advanced-tabs-container.dsm-tabs-image-icon-top', '.dsm-tab .dsm-icon-wrapper' ) . ', ' . $sc( '.dsm-advanced-tabs-container.dsm-tabs-image-icon-top', '.dsm-tab .dsm-active-icon-wrapper' ),
							'attr'                => $attrs['dsm_tabs_image_alignment']['innerContent'] ?? array(),
							'declarationFunction' => static function ( $params ) {
								$attr = $params['attrValue'] ?? '';

								if ( ! is_string( $attr ) || '' === $attr || 'default' === $attr ) {
									return '';
								}

								$style_declarations = new StyleDeclarations(
									array(
										'returnType' => 'string',
										'important'  => array(
											'margin-left'  => true,
											'margin-right' => true,
										),
									)
								);

								if ( 'left' === $attr ) {
									$style_declarations->add( 'margin-left', '0' );
									$style_declarations->add( 'margin-right', 'auto' );
								}

								if ( 'center' === $attr ) {
									$style_declarations->add( 'margin-left', 'auto' );
									$style_declarations->add( 'margin-right', 'auto' );
								}

								if ( 'right' === $attr ) {
									$style_declarations->add( 'margin-left', 'auto' );
									$style_declarations->add( 'margin-right', '0' );
								}

								return $style_declarations->value();
							},
						)
					),

					CommonStyle::style(
						array(
							'selector'            => $sc( '.dsm-advanced-tabs-container.dsm-tabs-image-icon-top', '.dsm-tab .dsm-icon-wrapper' ) . ', ' . $sc( '.dsm-advanced-tabs-container.dsm-tabs-image-icon-top', '.dsm-tab .dsm-active-icon-wrapper' ),
							'attr'                => $attrs['dsm_tabs_image_alignment']['innerContent'] ?? array(),
							'declarationFunction' => static function ( $params ) {
								$attr = $params['attrValue'] ?? '';

								if ( 'left' !== $attr && 'center' !== $attr && 'right' !== $attr ) {
									return '';
								}

								$style_declarations = new StyleDeclarations(
									array(
										'returnType' => 'string',
										'important'  => array(
											'width' => true,
										),
									)
								);

								$style_declarations->add( 'width', 'fit-content' );
								$style_declarations->add( 'max-width', '100%' );

								return $style_declarations->value();
							},
						)
					),

					CommonStyle::style(
						array(
							'selector' => $sc( '.dsm-advanced-tabs-container', '.dsm-content-wrapper .dsm-image' ) . ', ' . $sc( '.dsm-advanced-tabs-container', '.dsm-content-wrapper .dsm-icon' ),
							'attr'     => $attrs['dsm_content_image_icon_alignment']['innerContent'] ?? array(),
							'property' => 'text-align',
						)
					),

					CommonStyle::style(
						array(
							'selector' => $sc( '.dsm-advanced-tabs-container', '.dsm-content-wrapper .et-pb-icon.dsm_content_icon' ) . ', ' . $sc( '.dsm-advanced-tabs-container', '.dsm-content-wrapper .dsm-icon' ),
							'attr'     => $attrs['dsm_content_icon_size']['innerContent'] ?? array(),
							'property' => 'font-size',
						)
					),

					CommonStyle::style(
						array(
							'selector' => $sc( '.dsm-advanced-tabs-container', '.dsm-content-wrapper .et-pb-icon.dsm_content_icon' ) . ', ' . $sc( '.dsm-advanced-tabs-container', '.dsm-content-wrapper .dsm-icon' ),
							'attr'     => $attrs['dsm_content_icon_color']['innerContent'] ?? array(),
							'property' => 'color',
						)
					),
				),
			)
		);
	}

	/**
	 * Render module script data.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_script_data( $args ) {
		$elements = $args['elements'];

		// Element Script Data Options.
		$elements->script_data(
			array(
				'attrName' => 'module',
			)
		);
	}

	/**
	 * Render module classnames.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_classnames( $args ) {
		$classnames_instance = $args['classnamesInstance'];
		$attrs               = $args['attrs'];

		// Module.
		$classnames_instance->add(
			ElementClassnames::classnames(
				array(
					'attrs' => $attrs['module']['decoration'] ?? array(),
				)
			)
		);
	}

	/**
	 * Render module HTML output.
	 *
	 * @param array     $attrs                 Module attributes.
	 * @param mixed     $child_modules_content Child modules content.
	 * @param \WP_Block $block                 Block.
	 * @param mixed     $elements              Elements.
	 */
	public static function render_callback( $attrs, $child_modules_content, $block, $elements ) {
		AdvancedTabs::stash_child_nested_content(
			$block->parsed_block['storeInstance'] ?? null,
			(string) ( $block->parsed_block['id'] ?? '' ),
			is_string( $child_modules_content ) ? $child_modules_content : ''
		);

		$children_ids = ChildrenUtils::extract_children_ids( $block );

		// Module Inner.
		// Essentially, this is the module content.
		// Were wrapping the title and content in a div with class `et_pb_module_inner`.
		$module_inner = HTMLUtility::render(
			array(
				'tag'               => 'div',
				'attributes'        => array(
					'class' => 'et_pb_module_inner',
				),
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => '',
			)
		);

		// Background style components are mounted on the parent-rendered
		// `.dsm-content-wrapper` panel (see AdvancedTabs::render_callback), not here.
		$module_container_children = $module_inner;

		return Module::render(
			array(
				// FE only.
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],
				// VB equivalent.
				'attrs'               => $attrs,
				'elements'            => $elements,
				'id'                  => $block->parsed_block['id'],
				'moduleClassName'     => 'd5_tut_simple_quick_module',
				'name'                => $block->block_type->name,
				'classnamesFunction'  => array( self::class, 'module_classnames' ),
				'moduleCategory'      => $block->block_type->category,
				'stylesComponent'     => array( self::class, 'module_styles' ),
				'scriptDataComponent' => array( self::class, 'module_script_data' ),
				'childrenIds'         => $children_ids,
				'children'            => $module_container_children,
			)
		);
	}
}
