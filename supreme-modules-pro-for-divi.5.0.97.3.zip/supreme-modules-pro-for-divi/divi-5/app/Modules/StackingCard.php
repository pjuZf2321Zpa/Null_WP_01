<?php
/**
 * Stacking Card Module.
 *
 * @package DiviSupreme.
 */

declare(strict_types=1);

namespace DiviSupreme\Modules;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\Module\Options\Element\ElementClassnames;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Options\Element\ElementComponents;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;
use ET\Builder\Packages\Module\Options\Css\CssStyle;


/**
 * Class that handles "Stacking Card Module" module.
 */
class StackingCard implements DependencyInterface {



	/**
	 * Register module.
	 * `DependencyInterface` interface ensures class method name `load()` is executed for initialization.
	 */
	public function load() {
		add_action( 'init', array( self::class, 'register_module' ) );
	}

	/**
	 * Initilises the module.
	 *
	 * @return void
	 */
	public static function dsm_initialise() {
		add_action(
			'divi_module_library_modules_dependency_tree',
			function ( $dependency_tree ) {
				$dependency_tree->add_dependency( new self() );
			}
		);
	}

	/**
	 * Register module.
	 */
	public static function register_module() {

		$module_json_path = DSM_DIR_PATH . 'divi-5/public/packages/module-library/stacking-card';

		ModuleRegistration::register_module(
			$module_json_path,
			array(
				'render_callback' => array( self::class, 'render_callback' ),
			)
		);
	}

	/**
	 * Dsm content order alignment declaration.
	 *
	 * @param mixed $params Params.
	 */
	public static function dsm_content_order_alignment_declaration( $params ) {
		$attr_value = $params['attrValue'] ?? array();

		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
				'important'  => array(
					'order' => true,
				),
			)
		);

		if ( 'left' === $attr_value ) {
			$style_declarations->add( 'order', '-1' );
		}

		return $style_declarations->value();
	}


	/**
	 * Dsm content vertical alignment declaration.
	 *
	 * @param mixed $params Params.
	 */
	public static function dsm_content_vertical_alignment_declaration( $params ) {
		$attr_value = $params['attrValue'] ?? array();

		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
				'important'  => array(
					'align-items' => true,
				),
			)
		);

		if ( 'top' === $attr_value ) {
			$style_declarations->add( 'align-items', 'flex-start' );
		}

		if ( 'center' === $attr_value ) {
			$style_declarations->add( 'align-items', 'center' );
		}

		if ( 'bottom' === $attr_value ) {
			$style_declarations->add( 'align-items', 'flex-end' );
		}

		return $style_declarations->value();
	}

	/**
	 * Dsm layout declaration.
	 *
	 * @param mixed $params Params.
	 */
	public static function dsm_layout_declaration( $params ) {
		$attr_value = $params['attrValue'] ?? array();

		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
				'important'  => array(
					'flex-direction' => true,
				),
			)
		);

		if ( 'inline' === $attr_value ) {
			$style_declarations->add( 'flex-direction', 'row' );
		}

		if ( 'stacked' === $attr_value ) {
			$style_declarations->add( 'flex-direction', 'column' );
		}

		return $style_declarations->value();
	}

	/**
	 * Render module style.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_styles( $args ) {
		$args        = \DiviSupreme\Includes\DsmDiviBuilderCssScope::normalize_module_styles_args( $args );
		$attrs       = $args['attrs'] ?? array();
		$elements    = $args['elements'];
		$list_layout = $attrs['list_layout']['innerContent']['desktop']['value'] ?? '';

		Style::add(
			array(
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => array(
					// Module.
					$elements->style(
						array(
							'attrName'   => 'module',
							'styleProps' => array(
								'disabledOn' => array(
									'disabledModuleVisibility' => $args['settings']['disabledModuleVisibility'] ?? null,
								),
							),
						)
					),

					CssStyle::style(
						array(
							'selector' => $args['orderClass'],
							'attr'     => $attrs['css'] ?? array(),
						)
					),

					$elements->style(
						array(
							'attrName' => 'header',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_content',
						)
					),

					$elements->style(
						array(
							'attrName' => 'button',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_card_margin',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_card_padding',
						)
					),

					$elements->style(
						array(
							'attrName' => 'card_style',
						)
					),

					$elements->style(
						array(
							'attrName' => 'image_style',
						)
					),

					$elements->style(
						array(
							'attrName' => 'image_spacing',
						)
					),

					$elements->style(
						array(
							'attrName' => 'icon_style',
						)
					),

					$elements->style(
						array(
							'attrName' => 'icon_margin',
						)
					),

					$elements->style(
						array(
							'attrName' => 'icon_padding',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm_stacking_card_child",
							'attr'     => $attrs['dsm_bg_color']['innerContent'] ?? array(),
							'property' => 'background-color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm_stacking_card_child .dsm_icon::before",
							'attr'     => $attrs['dsm_icon_color']['innerContent'] ?? array(),
							'property' => 'color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm_stacking_card_child .dsm_icon::before",
							'attr'     => $attrs['dsm_icon_bg_color']['innerContent'] ?? array(),
							'property' => 'background-color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm_stacking_card_child .dsm_icon::before",
							'attr'     => $attrs['dsm_icon_font_size']['innerContent'] ?? array(),
							'property' => 'font-size',
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm_stacking_card_child .dsm_stacking_card_wrapper .dsm_content_wrapper",
							'attr'                => $attrs['content_order']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'dsm_content_order_alignment_declaration' ),
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm_stacking_card_child .dsm_stacking_card_wrapper",
							'attr'                => $attrs['layout']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'dsm_layout_declaration' ),
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm_stacking_card_child .dsm_stacking_card_wrapper",
							'attr'                => $attrs['content_horizontal_alignment']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'dsm_content_vertical_alignment_declaration' ),
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm_stacking_card_child .dsm_stacking_card_wrapper .dsm_image_wrapper",
							'attr'     => $attrs['image_width']['innerContent'] ?? array(),
							'property' => 'width',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm_stacking_card_child .dsm_icon",
							'attr'     => $attrs['dsm_icon_align']['innerContent'] ?? array(),
							'property' => 'text-align',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm_stacking_card_child .dsm-button-wrapper",
							'attr'     => $attrs['button_alignment']['innerContent'] ?? array(),
							'property' => 'text-align',
						)
					),
				),
			)
		);
	}

	/**
	 * Render module script data.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_script_data( $args ) {
		$elements = $args['elements'];

		// Element Script Data Options.
		$elements->script_data(
			array(
				'attrName' => 'module',
			)
		);
	}

	/**
	 * Render module classnames.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_classnames( $args ) {
		$classnames_instance = $args['classnamesInstance'];
		$attrs               = $args['attrs'];

		// Module.
		$classnames_instance->add(
			ElementClassnames::classnames(
				array(
					'attrs' => $attrs['module']['decoration'] ?? array(),
				)
			)
		);
	}

	/**
	 * Render module HTML output.
	 *
	 * @param array     $attrs - Modules Attributes.
	 * @param string    $content - Content.
	 * @param \WP_Block $block - Block.
	 * @param mixed     $elements - Elements.
	 */
	public static function render_callback( $attrs, $content, $block, $elements ) {

		$children_ids = $block->parsed_block['innerBlocks'] ? array_map(
			function ( $inner_block ) {
				return $inner_block['id'];
			},
			$block->parsed_block['innerBlocks']
		) : array();

		$parent                  = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );
		$parent_attrs            = $parent->attrs ?? array();
		$animation_type          = $attrs['animation_type']['innerContent']['desktop']['value'] ?? '';
		$disable_stacking_offset = $attrs['disable_offset']['innerContent']['desktop']['value'] ?? '';
		$start_horizontal_offset = $attrs['start_horizontal_offset']['innerContent']['desktop']['value'] ?? '';

		$direction_responsive = array(
			'desktop' => $attrs['card_direction']['innerContent']['desktop']['value'] ?? 'vertical',
			'tablet'  => $attrs['card_direction']['innerContent']['tablet']['value'] ?? '',
			'phone'   => $attrs['card_direction']['innerContent']['phone']['value'] ?? '',
		);

		$offset_vertical_responsive = array(
			'desktop' => $attrs['start_offset']['innerContent']['desktop']['value'] ?? '',
			'tablet'  => $attrs['start_offset']['innerContent']['tablet']['value'] ?? '',
			'phone'   => $attrs['start_offset']['innerContent']['phone']['value'] ?? '',
		);

		$offset_horizontal_responsive = array(
			'desktop' => $attrs['start_horizontal_offset']['innerContent']['desktop']['value'] ?? '',
			'tablet'  => $attrs['start_horizontal_offset']['innerContent']['tablet']['value'] ?? '',
			'phone'   => $attrs['start_horizontal_offset']['innerContent']['phone']['value'] ?? '',
		);

		wp_enqueue_script( 'dsm-gsap' );
		wp_enqueue_script( 'dsm-scroll-trigger' );
		wp_enqueue_script( 'dsm-stacking-card' );

		$options = array(
			'direction'               => $direction_responsive,
			'animation_type'          => $animation_type,
			'start_offset'            => $offset_vertical_responsive,
			'start_horizontal_offset' => $offset_horizontal_responsive,
			'disable_stacking_offset' => $disable_stacking_offset,
		);

		$container = sprintf(
			'<div class="dsm_stacking_card_container" data-options="%1$s">%2$s</div>',
			htmlspecialchars( (string) wp_json_encode( $options ) ),
			$content,
		);

		// Module Inner.
		// Essentially, this is the module content.
		// Were wrapping the title and content in a div with class `et_pb_module_inner`.
		$module_inner = HTMLUtility::render(
			array(
				'tag'               => 'div',
				'attributes'        => array(
					'class' => 'et_pb_module_inner',
				),
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $container,
			)
		);

		// This are the module elements that will be rendered in the frontend.
		$module_elements = $elements->style_components(
			array(
				'attrName' => 'module',
			)
		);

		// This are the children of the module container, which are the module elements and the module inner.
		$module_container_children = $module_elements . $container;

		return Module::render(
			array(
				// FE only.
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],
				'attrs'               => $attrs,
				'parentAttrs'         => $parent_attrs,
				'elements'            => $elements,
				'id'                  => $block->parsed_block['id'],
				'name'                => $block->block_type->name,
				'classnamesFunction'  => array( self::class, 'module_classnames' ),
				'moduleCategory'      => $block->block_type->category,
				'stylesComponent'     => array( self::class, 'module_styles' ),
				'scriptDataComponent' => array( self::class, 'module_script_data' ),
				'children'            => ElementComponents::component(
					array(
						'attrs'         => $attrs['module']['decoration'] ?? array(),
						'id'            => $block->parsed_block['id'],
						'orderIndex'    => $block->parsed_block['orderIndex'],
						'storeInstance' => $block->parsed_block['storeInstance'],
					)
				) . $module_container_children,
				'childrenIds'         => $children_ids,
			)
		);
	}
}
