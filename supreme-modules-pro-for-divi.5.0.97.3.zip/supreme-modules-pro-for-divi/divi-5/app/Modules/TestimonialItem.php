<?php
/**
 * Supreme Testimonial Item child module.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Modules;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use DiviSupreme\Includes\Testimonials\Attrs;
use DiviSupreme\Includes\Testimonials\Items;
use DiviSupreme\Includes\Testimonials\Markup;
use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\Module\Options\Element\ElementClassnames;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\Packages\ModuleUtils\ChildrenUtils;
use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;

/**
 * Child card: author, quote, rating, video, source.
 */
class TestimonialItem implements DependencyInterface {

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function load() {
		add_action( 'init', array( self::class, 'register_module' ) );
	}

	/**
	 * Dependency tree helper.
	 *
	 * @return void
	 */
	public static function dsm_initialise() {
		add_action(
			'divi_module_library_modules_dependency_tree',
			static function ( $dependency_tree ) {
				$dependency_tree->add_dependency( new self() );
			}
		);
	}

	/**
	 * Register the module.
	 *
	 * @return void
	 */
	public static function register_module() {
		$module_json_path = DSM_DIR_PATH . 'divi-5/public/packages/module-library/testimonial-item';

		ModuleRegistration::register_module(
			$module_json_path,
			array(
				'render_callback' => array( self::class, 'render_callback' ),
			)
		);
	}

	/**
	 * Whether a child star token is the inherit-from-parent default.
	 *
	 * Emitting `#f0ad4e` / `16px` / `2px` as `--dsm-testimonial-item-star-*`
	 * overrides parent `--dsm-testimonials-star-*` on the frontend.
	 *
	 * @param string $raw      Resolved CSS value.
	 * @param string $var_name CSS custom property.
	 * @return bool
	 */
	private static function item_star_is_inherit_default( string $raw, string $var_name ): bool {
		$normalized = strtolower( str_replace( ' ', '', $raw ) );

		if ( '--dsm-testimonial-item-star-color' === $var_name ) {
			return in_array( $normalized, array( '#f0ad4e', 'f0ad4e' ), true );
		}

		if ( '--dsm-testimonial-item-star-size' === $var_name ) {
			return in_array( $normalized, array( '16px', '16' ), true );
		}

		if ( '--dsm-testimonial-item-star-gap' === $var_name ) {
			return in_array( $normalized, array( '2px', '2' ), true );
		}

		return false;
	}

	/**
	 * Item star CSS custom property when the child attr is set.
	 *
	 * @param array<string, mixed> $params Style params.
	 * @param string               $var_name CSS custom property.
	 * @param string               $kind     color|size.
	 * @return string
	 */
	public static function item_star_var_declaration( $params, $var_name, $kind ) {
		$raw = $params['attrValue'] ?? '';
		if ( is_array( $raw ) ) {
			$raw = $raw['hex'] ?? $raw['color'] ?? $raw['value'] ?? '';
		}

		if ( ! is_string( $raw ) || '' === trim( $raw ) ) {
			if ( ! is_numeric( $raw ) ) {
				return '';
			}
			$raw = (string) $raw;
		}

		$raw = trim( (string) $raw );
		if ( '' === $raw ) {
			return '';
		}

		if ( 'size' === $kind && ! preg_match( '/[a-z%]+$/i', $raw ) ) {
			$raw = absint( $raw ) . 'px';
		}

		if ( self::item_star_is_inherit_default( $raw, $var_name ) ) {
			return '';
		}

		$style = new StyleDeclarations(
			array(
				'returnType' => 'string',
			)
		);
		$style->add( $var_name, $raw );
		return $style->value();
	}

	/**
	 * Item star color CSS custom property.
	 *
	 * @param array<string, mixed> $params Style params.
	 * @return string
	 */
	public static function item_stars_color_declaration( $params ) {
		return self::item_star_var_declaration( $params, '--dsm-testimonial-item-star-color', 'color' );
	}

	/**
	 * Item star size CSS custom property.
	 *
	 * @param array<string, mixed> $params Style params.
	 * @return string
	 */
	public static function item_stars_size_declaration( $params ) {
		return self::item_star_var_declaration( $params, '--dsm-testimonial-item-star-size', 'size' );
	}

	/**
	 * Item star gap CSS custom property.
	 *
	 * @param array<string, mixed> $params Style params.
	 * @return string
	 */
	public static function item_stars_gap_declaration( $params ) {
		return self::item_star_var_declaration( $params, '--dsm-testimonial-item-star-gap', 'size' );
	}

	/**
	 * Item video overlay color CSS custom property.
	 *
	 * @param array<string, mixed> $params Style params.
	 * @return string
	 */
	public static function item_video_overlay_color_declaration( $params ) {
		return self::item_star_var_declaration( $params, '--dsm-testimonial-item-video-overlay', 'color' );
	}

	/**
	 * Item video play icon color CSS custom property.
	 *
	 * @param array<string, mixed> $params Style params.
	 * @return string
	 */
	public static function item_video_icon_color_declaration( $params ) {
		return self::item_star_var_declaration( $params, '--dsm-testimonial-item-video-icon', 'color' );
	}

	/**
	 * Module styles.
	 *
	 * @param array<string, mixed> $args Style args.
	 * @return void
	 */
	public static function module_styles( $args ) {
		$args     = \DiviSupreme\Includes\DsmDiviBuilderCssScope::normalize_module_styles_args( $args );
		$attrs    = $args['attrs'] ?? array();
		$elements = $args['elements'] ?? null;

		Style::add(
			array(
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => array(
					$elements->style(
						array(
							'attrName'   => 'module',
							'styleProps' => array(
								'disabledOn' => array(
									'disabledModuleVisibility' => $args['settings']['disabledModuleVisibility'] ?? null,
								),
							),
						)
					),
					CssStyle::style(
						array(
							'selector' => $args['orderClass'],
							'attr'     => $attrs['css'] ?? array(),
						)
					),
					$elements->style(
						array(
							'attrName' => 'dsm_author',
						)
					),
					$elements->style(
						array(
							'attrName' => 'dsm_role',
						)
					),
					$elements->style(
						array(
							'attrName' => 'dsm_company',
						)
					),
					$elements->style(
						array(
							'attrName' => 'dsm_quote',
						)
					),
					$elements->style(
						array(
							'attrName' => 'dsm_avatar_style',
						)
					),
					$elements->style(
						array(
							'attrName' => 'dsm_review_date',
						)
					),
					$elements->style(
						array(
							'attrName' => 'dsm_source_style',
						)
					),
					$elements->style(
						array(
							'attrName' => 'dsm_product_style',
						)
					),
					$elements->style(
						array(
							'attrName' => 'dsm_video_style',
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $args['orderClass'],
							'attr'                => $attrs['dsm_stars_color']['innerContent'] ?? array(),
							'declarationFunction' => array( self::class, 'item_stars_color_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $args['orderClass'],
							'attr'                => $attrs['dsm_stars_size']['innerContent'] ?? array(),
							'declarationFunction' => array( self::class, 'item_stars_size_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $args['orderClass'],
							'attr'                => $attrs['dsm_stars_gap']['innerContent'] ?? array(),
							'declarationFunction' => array( self::class, 'item_stars_gap_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $args['orderClass'],
							'attr'                => $attrs['dsm_video_overlay_color']['innerContent'] ?? array(),
							'declarationFunction' => array( self::class, 'item_video_overlay_color_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $args['orderClass'],
							'attr'                => $attrs['dsm_video_icon_color']['innerContent'] ?? array(),
							'declarationFunction' => array( self::class, 'item_video_icon_color_declaration' ),
						)
					),
				),
			)
		);
	}

	/**
	 * Script data.
	 *
	 * @param array<string, mixed> $args Args.
	 * @return void
	 */
	public static function module_script_data( $args ) {
		$elements = $args['elements'];
		$elements->script_data(
			array(
				'attrName' => 'module',
			)
		);
	}

	/**
	 * Classnames.
	 *
	 * @param array<string, mixed> $args Args.
	 * @return void
	 */
	public static function module_classnames( $args ) {
		$classnames_instance = $args['classnamesInstance'];
		$attrs               = $args['attrs'];
		$parent_attrs        = $args['parentAttrs'] ?? array();

		$classnames_instance->add(
			ElementClassnames::classnames(
				array(
					'attrs' => $attrs['module']['decoration'] ?? array(),
				)
			)
		);

		$classnames_instance->add( 'dsm_testimonial_item' );

		$layout = Attrs::layout( is_array( $parent_attrs ) ? $parent_attrs : array() );

		if ( 'carousel' === $layout ) {
			$classnames_instance->add( 'swiper-slide' );
		}
	}

	/**
	 * Render.
	 *
	 * @param array<string, mixed> $attrs    Attrs.
	 * @param string               $content  Nested inner-module HTML.
	 * @param \WP_Block            $block    Block.
	 * @param mixed                $elements Elements.
	 * @return string
	 */
	public static function render_callback( $attrs, $content, $block, $elements ) {
		$child_modules_content = is_string( $content ) ? $content : '';
		$children_ids          = ChildrenUtils::extract_children_ids( $block );
		$has_nested_modules    = '' !== trim( $child_modules_content ) || ! empty( $children_ids );
		$layout_display_value  = $attrs['module']['decoration']['layout']['desktop']['value']['display'] ?? 'flex';
		$nestable_classes      = HTMLUtility::classnames(
			'dsm-testimonials-nestable',
			array(
				'et_flex_module' => 'flex' === $layout_display_value,
				'et_grid_module' => 'grid' === $layout_display_value,
			)
		);
		$nested_markup         = ( $has_nested_modules && '' !== trim( $child_modules_content ) )
			? sprintf(
				'<div class="%1$s">%2$s</div>',
				esc_attr( $nestable_classes ),
				et_core_esc_previously( $child_modules_content )
			)
			: '';

		$parent       = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );
		$parent_attrs = $parent->attrs ?? array();
		$show_source  = Attrs::inner_on( is_array( $parent_attrs ) ? $parent_attrs : array(), 'dsm_show_source', 'off' );

		$item      = Items::from_child_attrs( is_array( $attrs ) ? $attrs : array(), (string) ( $block->parsed_block['id'] ?? '' ) );
		$container = Markup::card( $item, $nested_markup, $show_source );

		$module_inner = HTMLUtility::render(
			array(
				'tag'               => 'div',
				'attributes'        => array(
					'class' => 'et_pb_module_inner',
				),
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $container,
			)
		);

		$module_elements = $elements->style_components(
			array(
				'attrName' => 'module',
			)
		);

		return Module::render(
			array(
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],
				'attrs'               => $attrs,
				'parentAttrs'         => $parent_attrs,
				'elements'            => $elements,
				'id'                  => $block->parsed_block['id'],
				'moduleClassName'     => '',
				'name'                => $block->block_type->name,
				'classnamesFunction'  => array( self::class, 'module_classnames' ),
				'moduleCategory'      => $block->block_type->category,
				'stylesComponent'     => array( self::class, 'module_styles' ),
				'scriptDataComponent' => array( self::class, 'module_script_data' ),
				'children'            => et_core_esc_previously( $module_elements ) . et_core_esc_previously( $module_inner ),
			)
		);
	}
}
