<?php
/**
 * Step Flow Module.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Modules;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\Module\Options\Element\ElementClassnames;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use ET\Builder\Packages\Module\Options\Text\TextStyle;
use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use DiviSupreme\Extensions\IconLibraries\LegacyModuleIconStyles;
use DiviSupreme\Includes\UploadImageMarkup;
use DiviSupreme\Includes\Divi5Conversion\ConversionAttrs;


/**
 * Class that handles "Stepflow Module" module.
 */
class StepFlow implements DependencyInterface {



	/**
	 * Register module.
	 * `DependencyInterface` interface ensures class method name `load()` is executed for initialization.
	 */
	public function load() {
		add_action( 'init', array( self::class, 'register_module' ) );
	}

	/**
	 * Initilises the module.
	 *
	 * @return void
	 */
	public static function dsm_initialise() {
		add_action(
			'divi_module_library_modules_dependency_tree',
			function ( $dependency_tree ) {
				$dependency_tree->add_dependency( new self() );
			}
		);
	}

	/**
	 * Register module.
	 */
	public static function register_module() {

		$module_json_path = DSM_DIR_PATH . 'divi-5/public/packages/module-library/step-flow';

		ModuleRegistration::register_module(
			$module_json_path,
			array(
				'render_callback' => array( self::class, 'render_callback' ),
			)
		);
	}


	/**
	 * Icon style declaration.
	 *
	 * @param mixed $params Params.
	 */
	public static function icon_style_declaration( $params ) {
		return LegacyModuleIconStyles::build_pseudo_icon_declaration( $params );
	}


	/**
	 * Dir icon style declaration.
	 *
	 * @param mixed $params Params.
	 */
	public static function dir_icon_style_declaration( $params ) {
		return LegacyModuleIconStyles::build_pseudo_icon_declaration( $params );
	}

	/**
	 * Desktop icon picker leaf from a Step Flow icon attr.
	 *
	 * @param array<string, mixed> $attrs     Module attrs.
	 * @param string               $attr_name Attr name (`font_icon` or `dsm_dir_font_icon`).
	 * @return array<string, mixed>|null
	 */
	private static function step_flow_icon_settings( array $attrs, string $attr_name ): ?array {
		$value = $attrs[ $attr_name ]['innerContent']['desktop']['value'] ?? null;

		return is_array( $value ) ? $value : null;
	}

	/**
	 * Resolved "Show Direction" toggle for a breakpoint (inherits phone ← tablet ← desktop).
	 *
	 * @param array<string, mixed> $inner `dsm_show_dir.innerContent`.
	 * @param string               $breakpoint One of desktop|tablet|phone.
	 * @return bool
	 */
	private static function step_flow_resolved_show_dir_is_on( array $inner, string $breakpoint ): bool {
		$order = 'phone' === $breakpoint
			? array( 'phone', 'tablet', 'desktop' )
			: ( 'tablet' === $breakpoint ? array( 'tablet', 'desktop' ) : array( 'desktop' ) );
		foreach ( $order as $bp ) {
			if ( ! isset( $inner[ $bp ]['value'] ) ) {
				continue;
			}
			$v = $inner[ $bp ]['value'];
			if ( ! is_scalar( $v ) ) {
				continue;
			}
			$vs = strtolower( trim( (string) $v ) );
			if ( '' === $vs ) {
				continue;
			}

			return 'on' === $vs;
		}

		return false;
	}

	/**
	 * Whether direction markup should exist in HTML (any breakpoint shows direction).
	 *
	 * @param array<string, mixed> $inner `dsm_show_dir.innerContent`.
	 * @return bool
	 */
	private static function step_flow_show_dir_any_breakpoint_on( array $inner ): bool {
		foreach ( array( 'desktop', 'tablet', 'phone' ) as $bp ) {
			if ( self::step_flow_resolved_show_dir_is_on( $inner, $bp ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Per-breakpoint `display:none` when Show Direction is off (matches VB `getAttrByMode`).
	 *
	 * @param array<string, mixed> $params Declaration params from CommonStyle.
	 * @return string
	 */
	public static function show_direction_display_declaration( array $params ): string {
		$raw = $params['attrValue'] ?? null;
		if ( 'on' === $raw ) {
			return '';
		}

		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
			)
		);
		$style_declarations->add( 'display', 'none' );

		return $style_declarations->value();
	}

	/**
	 * D4 applies a baseline `left`/`top` of 5px when custom badge position is on, then overrides
	 * each axis only when `if ( $this->props['dsm_badge_*_position'] )` passes (empty or string "0" skips).
	 *
	 * @param array<string, mixed> $params Declaration params from CommonStyle.
	 * @return string
	 */
	public static function badge_custom_position_baseline_declaration( array $params ): string {
		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
				'important'  => $params['important'] ?? false,
			)
		);
		$style_declarations->add( 'left', '5px' );
		$style_declarations->add( 'top', '5px' );

		return $style_declarations->value();
	}

	/**
	 * Left offset override for custom badge position (skips when D4 would keep baseline).
	 *
	 * @param array<string, mixed> $params Declaration params from CommonStyle.
	 * @return string
	 */
	public static function badge_custom_position_left_declaration( array $params ): string {
		$raw = self::step_flow_badge_axis_raw_value( $params );
		if ( ! self::step_flow_badge_axis_overrides_baseline( $raw ) ) {
			return '';
		}

		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
				'important'  => $params['important'] ?? false,
			)
		);
		$style_declarations->add( 'left', $raw );

		return $style_declarations->value();
	}

	/**
	 * Top offset override for custom badge position (skips when D4 would keep baseline).
	 *
	 * @param array<string, mixed> $params Declaration params from CommonStyle.
	 * @return string
	 */
	public static function badge_custom_position_top_declaration( array $params ): string {
		$raw = self::step_flow_badge_axis_raw_value( $params );
		if ( ! self::step_flow_badge_axis_overrides_baseline( $raw ) ) {
			return '';
		}

		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
				'important'  => $params['important'] ?? false,
			)
		);
		$style_declarations->add( 'top', $raw );

		return $style_declarations->value();
	}

	/**
	 * Normalize CommonStyle attr value for a range leaf.
	 *
	 * @param array<string, mixed> $params Declaration params.
	 * @return string
	 */
	private static function step_flow_badge_axis_raw_value( array $params ): string {
		$attr_value = $params['attrValue'] ?? null;
		if ( is_array( $attr_value ) ) {
			if ( ! isset( $attr_value['value'] ) ) {
				return '';
			}
			$v = $attr_value['value'];
		} else {
			$v = $attr_value;
		}

		if ( null === $v || '' === $v ) {
			return '';
		}

		return is_scalar( $v ) ? (string) $v : '';
	}

	/**
	 * Match D4 truthiness for `if ( $this->props['dsm_badge_*_position'] )`.
	 *
	 * @param string $raw Axis value (e.g. `10%`, `0%`, '', `0`).
	 * @return bool
	 */
	private static function step_flow_badge_axis_overrides_baseline( string $raw ): bool {
		$t = trim( $raw );

		return '' !== $t && '0' !== $t;
	}

	/**
	 * Icon size selectors (host + webfont glyph).
	 *
	 * @param string $order_class Module order class.
	 * @return string
	 */
	private static function step_flow_icon_size_selector( string $order_class ): string {
		return implode(
			', ',
			array(
				"{$order_class} .dsm_icon",
				"{$order_class} .dsm_icon.et-pb-icon",
				"{$order_class} .dsm_icon.et-pb-icon.dsm-webfont-icon-host",
				"{$order_class} .dsm_icon.et-pb-icon.dsm-webfont-icon-host .dsm-webfont-icon-glyph",
				"{$order_class} .dsm_icon .dsm-webfont-icon-glyph",
			)
		);
	}

	/**
	 * Icon color selectors (size targets + native ::before).
	 *
	 * @param string $order_class Module order class.
	 * @return string
	 */
	private static function step_flow_icon_color_selector( string $order_class ): string {
		return self::step_flow_icon_size_selector( $order_class ) . ", {$order_class} .dsm_icon::before";
	}

	/**
	 * Direction icon size selectors (host + webfont glyph).
	 *
	 * @param string $order_class Module order class.
	 * @return string
	 */
	private static function step_flow_dir_icon_size_selector( string $order_class ): string {
		return implode(
			', ',
			array(
				"{$order_class} .dsm-steps-image-icon-wrapper .dsm_dir_icon",
				"{$order_class} .dsm-steps-image-icon-wrapper .dsm_dir_icon.et-pb-icon",
				"{$order_class} .dsm-steps-image-icon-wrapper .dsm_dir_icon.et-pb-icon.dsm-webfont-icon-host",
				"{$order_class} .dsm-steps-image-icon-wrapper .dsm_dir_icon.et-pb-icon.dsm-webfont-icon-host .dsm-webfont-icon-glyph",
			)
		);
	}

	/**
	 * Icon font-size innerContent; D4 default `96px` when omitted (Divi drops matching keys).
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 * @return array<string, mixed>
	 */
	private static function step_flow_icon_font_size_inner_content( array $attrs ): array {
		$inner   = $attrs['dsm_icon_font_size']['innerContent'] ?? array();
		$desktop = $inner['desktop']['value'] ?? '';

		if ( is_string( $desktop ) && '' !== trim( $desktop ) ) {
			return $inner;
		}

		if ( ! is_array( $inner['desktop'] ?? null ) ) {
			$inner['desktop'] = array();
		}

		$inner['desktop']['value'] = '96px';

		return $inner;
	}

	/**
	 * Direction color innerContent; D4 default `#dddddd` when omitted (empty attr skips CommonStyle).
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 * @return array<string, mixed>
	 */
	private static function step_flow_dir_color_inner_content( array $attrs ): array {
		$inner = $attrs['dsm_dir_color']['innerContent'] ?? array();

		if ( array() === $inner ) {
			return array(
				'desktop' => array(
					'value' => '#dddddd',
				),
			);
		}

		return $inner;
	}

	/**
	 * Direction arrow border-style innerContent; D4 default `solid` when omitted.
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 * @return array<string, mixed>
	 */
	private static function step_flow_dir_style_inner_content( array $attrs ): array {
		$inner = $attrs['dsm_dir_style']['innerContent'] ?? array();

		if ( array() === $inner ) {
			return array(
				'desktop' => array(
					'value' => 'solid',
				),
			);
		}

		return $inner;
	}

	/**
	 * Render module style.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_styles( $args ) {
		$args                   = \DiviSupreme\Includes\DsmDiviBuilderCssScope::normalize_module_styles_args( $args );
		$attrs                  = $args['attrs'] ?? array();
		$elements               = $args['elements'];
		$use_content_raw        = $attrs['dsm_use_content']['innerContent']['desktop']['value'] ?? 'on';
		$dsm_use_content        = 'on' === $use_content_raw ? 'on' : 'off';
		$badge_use_raw          = $attrs['dsm_badge_use_position']['innerContent']['desktop']['value'] ?? 'off';
		$dsm_badge_use_position = 'on' === $badge_use_raw ? 'on' : 'off';

		Style::add(
			array(
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => array(
					// Module.
					$elements->style(
						array(
							'attrName'   => 'module',
							'styleProps' => array(
								'disabledOn' => array(
									'disabledModuleVisibility' => $args['settings']['disabledModuleVisibility'] ?? null,
								),
							),
						)
					),

					CssStyle::style(
						array(
							'selector' => $args['orderClass'],
							'attr'     => $attrs['css'] ?? array(),
						)
					),

					TextStyle::style(
						array(
							'selector' => $args['orderClass'],
							'attr'     => $attrs['module']['advanced']['text'] ?? array(),
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_image_icon_margin',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_image_icon_padding',
						)
					),

					$elements->style(
						array(
							'attrName' => 'imageIconStyle',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_title',
						)
					),

					'on' === $dsm_use_content
					? $elements->style(
						array(
							'attrName' => 'dsm_content',
						)
					)
					: '',

					$elements->style(
						array(
							'attrName' => 'dsm_badge',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_badge_padding',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_badge_margin',
						)
					),

					$elements->style(
						array(
							'attrName' => 'badgeStyle',
						)
					),

					$elements->style(
						array(
							'attrName' => 'button',
						)
					),

					CommonStyle::style(
						array(
							'selector' => self::step_flow_icon_color_selector( (string) $args['orderClass'] ),
							'attr'     => $attrs['dsm_icon_color']['innerContent'] ?? array(),
							'property' => 'color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm_icon, {$args['orderClass']} .dsm-steps-image-icon-wrapper img",
							'attr'     => $attrs['dsm_image_icon_bg_color']['innerContent'] ?? array(),
							'property' => 'background',
						)
					),

					CommonStyle::style(
						array(
							'selector' => self::step_flow_icon_size_selector( (string) $args['orderClass'] ),
							'attr'     => self::step_flow_icon_font_size_inner_content( $attrs ),
							'property' => 'font-size',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-step-flow-container",
							'attr'     => $attrs['dsm_image_icon_alignment']['innerContent'] ?? array(),
							'property' => 'text-align',
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm_icon::before",
							'attr'                => $attrs['font_icon']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'icon_style_declaration' ),
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm_dir_icon::before",
							'attr'                => $attrs['dsm_dir_font_icon']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'dir_icon_style_declaration' ),
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-step-badge",
							'attr'     => $attrs['dsm_badge_bg_color']['innerContent'] ?? array(),
							'property' => 'background',
						)
					),

					'on' === $dsm_badge_use_position ?
					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm-step-badge",
							'attr'                => array(
								'desktop' => array(
									'value' => 'on',
								),
							),
							'declarationFunction' => array( static::class, 'badge_custom_position_baseline_declaration' ),
						)
					) : '',

					'on' === $dsm_badge_use_position ?
					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm-step-badge",
							'attr'                => $attrs['dsm_badge_left_position']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'badge_custom_position_left_declaration' ),
						)
					) : '',

					'on' === $dsm_badge_use_position ?
					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm-step-badge",
							'attr'                => $attrs['dsm_badge_top_position']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'badge_custom_position_top_declaration' ),
						)
					) : '',

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-button-wrapper",
							'attr'     => $attrs['button_alignment']['innerContent'] ?? array(),
							'property' => 'text-align',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-steps-image-icon-wrapper .dsm-image-wrap",
							'attr'     => $attrs['dsm_image_width']['innerContent'] ?? array(),
							'property' => 'width',
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm-steps-image-icon-wrapper .dsm-step-arrow, {$args['orderClass']} .dsm-steps-image-icon-wrapper .dsm_dir_icon, {$args['orderClass']} .dsm-steps-image-icon-wrapper .dsm-dir-image",
							'attr'                => $attrs['dsm_show_dir']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'show_direction_display_declaration' ),
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-steps-image-icon-wrapper .dsm-step-arrow",
							'attr'     => self::step_flow_dir_color_inner_content( $attrs ),
							'property' => 'border-top-color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-steps-image-icon-wrapper .dsm-step-arrow::before",
							'attr'     => self::step_flow_dir_color_inner_content( $attrs ),
							'property' => 'border-top-color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-steps-image-icon-wrapper .dsm-step-arrow::before",
							'attr'     => self::step_flow_dir_color_inner_content( $attrs ),
							'property' => 'border-right-color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-steps-image-icon-wrapper .dsm-step-arrow",
							'attr'     => self::step_flow_dir_style_inner_content( $attrs ),
							'property' => 'border-style',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-steps-image-icon-wrapper .dsm-step-arrow::before",
							'attr'     => self::step_flow_dir_style_inner_content( $attrs ),
							'property' => 'border-top-style',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-steps-image-icon-wrapper .dsm-step-arrow::before",
							'attr'     => self::step_flow_dir_style_inner_content( $attrs ),
							'property' => 'border-right-style',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-steps-image-icon-wrapper .dsm-step-arrow, {$args['orderClass']} .dsm-steps-image-icon-wrapper .dsm_dir_icon, {$args['orderClass']} .dsm-steps-image-icon-wrapper .dsm-dir-image",
							'attr'     => $attrs['dsm_dir_offset_top']['innerContent'] ?? array(),
							'property' => 'top',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-steps-image-icon-wrapper .dsm-step-arrow, {$args['orderClass']} .dsm-steps-image-icon-wrapper .dsm_dir_icon, {$args['orderClass']} .dsm-steps-image-icon-wrapper .dsm-dir-image",
							'attr'     => $attrs['dsm_dir_offset_left']['innerContent'] ?? array(),
							'property' => 'left',
						)
					),

					CommonStyle::style(
						array(
							'selector' => self::step_flow_dir_icon_size_selector( (string) $args['orderClass'] ),
							'attr'     => $attrs['dsm_dir_font_size']['innerContent'] ?? array(),
							'property' => 'font-size',
						)
					),

					CommonStyle::style(
						array(
							'selector' => self::step_flow_dir_icon_size_selector( (string) $args['orderClass'] ) . ', ' . $args['orderClass'] . ' .dsm-steps-image-icon-wrapper .dsm_dir_icon .dsm-webfont-icon-glyph',
							'attr'     => self::step_flow_dir_color_inner_content( $attrs ),
							'property' => 'color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-steps-image-icon-wrapper .dsm-dir-image",
							'attr'     => $attrs['dsm_dir_image_width']['innerContent'] ?? array(),
							'property' => 'width',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-steps-image-icon-wrapper .dsm-step-arrow",
							'attr'     => $attrs['dsm_dir_width']['innerContent'] ?? array(),
							'property' => 'width',
						)
					),
				),
			)
		);
	}

	/**
	 * Render module script data.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_script_data( $args ) {
		$elements = $args['elements'];

		// Element Script Data Options.
		$elements->script_data(
			array(
				'attrName' => 'module',
			)
		);
	}

	/**
	 * Render module classnames.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_classnames( $args ) {
		$classnames_instance = $args['classnamesInstance'];
		$attrs               = $args['attrs'];

		// Module.
		$classnames_instance->add(
			ElementClassnames::classnames(
				array(
					'attrs' => $attrs['module']['decoration'] ?? array(),
				)
			)
		);
	}

	/**
	 * Render module HTML output.
	 *
	 * @param array     $attrs - Modules Attributes.
	 * @param string    $content - Content.
	 * @param \WP_Block $block - Block.
	 * @param mixed     $elements - Elements.
	 */
	public static function render_callback( $attrs, $content, $block, $elements ) {
		// MultiView `populate_data_content()` requires a string per breakpoint/state; RichText / plain fields
		// often store `{ text: string }` while generic `element` rendering uses no `subName`, which leaves
		// the array intact and throws. Normalize before `ModuleElements->render()` (uses `module_attrs`).
		if ( isset( $elements->module_attrs ) && is_array( $elements->module_attrs ) ) {
			self::ensure_heading_link_text_shape_step_flow( $elements->module_attrs, 'dsm_title' );
			ConversionAttrs::ensure_inner_content_text_shape_for_render( $elements->module_attrs, 'dsm_content' );
			ConversionAttrs::ensure_inner_content_text_shape_for_render( $elements->module_attrs, 'dsm_badge' );
		}
		if ( is_array( $attrs ) ) {
			self::ensure_heading_link_text_shape_step_flow( $attrs, 'dsm_title' );
			ConversionAttrs::ensure_inner_content_text_shape_for_render( $attrs, 'dsm_content' );
			ConversionAttrs::ensure_inner_content_text_shape_for_render( $attrs, 'dsm_badge' );
		}

		$dsm_use_icon       = $attrs['dsm_use_icon']['innerContent']['desktop']['value'] ?? 'off';
		$dsm_show_dir_inner = $attrs['dsm_show_dir']['innerContent'] ?? array();
		$dsm_show_dir_any   = self::step_flow_show_dir_any_breakpoint_on( $dsm_show_dir_inner );
		$dsm_dir_type       = $attrs['dsm_dir_type']['innerContent']['desktop']['value'] ?? 'default';
		if ( ! is_string( $dsm_dir_type ) || '' === trim( $dsm_dir_type ) ) {
			$dsm_dir_type = 'default';
		}

		$use_content_raw        = $attrs['dsm_use_content']['innerContent']['desktop']['value'] ?? 'on';
		$dsm_use_content        = 'on' === $use_content_raw ? 'on' : 'off';
		$badge_use_raw          = $attrs['dsm_badge_use_position']['innerContent']['desktop']['value'] ?? 'off';
		$dsm_badge_use_position = 'on' === $badge_use_raw ? 'on' : 'off';
		$dsm_badge_position     = self::normalize_dsm_badge_position( $attrs );

		$button_text_raw = $attrs['button_text']['innerContent']['desktop']['value'] ?? '';
		$button_text     = is_string( $button_text_raw ) ? $button_text_raw : '';
		$button_url      = $attrs['button_url']['innerContent']['desktop']['value'] ?? '';
		$button_url      = is_string( $button_url ) ? $button_url : '';
		$url_new_window  = $attrs['url_new_window']['innerContent']['desktop']['value'] ?? 'off';

		$dsm_image_raw     = $attrs['dsm_image']['innerContent']['desktop']['value'] ?? null;
		$dsm_dir_image_raw = $attrs['dsm_dir_image']['innerContent']['desktop']['value'] ?? null;

		// Match Divi 4 (StepFlow.php / StepFlow.jsx): arrow → main image → main icon → direction icon → direction image.
		$dir_arrow      = $dsm_show_dir_any && 'default' === $dsm_dir_type
			? sprintf(
				'<div class="dsm-step-arrow dsm-dir-type-%1$s"></div>',
				esc_attr( $dsm_dir_type )
			)
			: '';
		$dir_icon_part  = $dsm_show_dir_any && 'icon' === $dsm_dir_type
			? LegacyModuleIconStyles::render_custom_icon_host(
				self::step_flow_icon_settings( $attrs, 'dsm_dir_font_icon' ),
				'dsm_dir_icon'
			)
			: '';
		$dir_image_part = $dsm_show_dir_any && 'image' === $dsm_dir_type
			? UploadImageMarkup::render_img_html(
				$dsm_dir_image_raw,
				'',
				array(
					'class' => 'dsm-dir-image',
				)
			)
			: '';
		$image_part     = 'off' === $dsm_use_icon
			? self::render_step_flow_main_image_markup( $dsm_image_raw )
			: '';
		$icon_part      = 'on' === $dsm_use_icon
			? LegacyModuleIconStyles::render_custom_icon_host(
				self::step_flow_icon_settings( $attrs, 'font_icon' ),
				'dsm_icon'
			)
			: '';

		$badge_markup = self::render_step_flow_badge_block(
			$elements,
			$attrs,
			$dsm_badge_use_position,
			$dsm_badge_position
		);

		$title_markup = $elements->render(
			array(
				'attrName' => 'dsm_title',
			)
		);

		$content_markup = 'on' === $dsm_use_content
			? $elements->render(
				array(
					'attrName'    => 'dsm_content',
					'attrSubName' => 'text',
					'elementType' => 'content',
				)
			)
			: '';

		$button_rel    = ( 'on' === $url_new_window && '' !== $button_url ) ? ' rel="noopener noreferrer"' : '';
		$button_markup = '' !== trim( $button_text )
			? sprintf(
				'<div class="dsm-button-wrapper">
				  <a %2$s%3$s%4$s class="et_pb_button">%1$s</a>
				</div>',
				et_core_esc_previously( $button_text ),
				'' !== $button_url ? sprintf( 'href="%1$s" ', esc_url( $button_url ) ) : '',
				'on' === $url_new_window ? 'target="_blank" ' : '',
				$button_rel
			)
			: '';

		$container = sprintf(
			'<div class="dsm-step-flow-container">
				<div class="dsm-steps-image-icon-wrapper">
					%1$s
					%2$s
					%3$s
					%4$s
					%5$s
				</div>
				%6$s
				%7$s
				%8$s
				%9$s
			</div>',
			$dir_arrow,
			$image_part,
			$icon_part,
			$dir_icon_part,
			$dir_image_part,
			$badge_markup,
			$title_markup,
			$content_markup,
			$button_markup
		);

		$module_inner = HTMLUtility::render(
			array(
				'tag'               => 'div',
				'attributes'        => array(
					'class' => 'et_pb_module_inner',
				),
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $container,
			)
		);

		// This are the module elements that will be rendered in the frontend.
		$module_elements = $elements->style_components(
			array(
				'attrName' => 'module',
			)
		);

		// This are the children of the module container, which are the module elements and the module inner.
		$module_container_children = $module_elements . $module_inner;

		return Module::render(
			array(
				// FE only.
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],
				// VB equivalent.
				'attrs'               => $attrs,
				'elements'            => $elements,
				'id'                  => $block->parsed_block['id'],
				'moduleClassName'     => 'dsm_step_flow',
				'name'                => $block->block_type->name,
				'classnamesFunction'  => array( self::class, 'module_classnames' ),
				'moduleCategory'      => $block->block_type->category,
				'stylesComponent'     => array( self::class, 'module_styles' ),
				'scriptDataComponent' => array( self::class, 'module_script_data' ),
				'children'            => $module_container_children,
			)
		);
	}

	/**
	 * Normalize preset slug when “Use Custom Badge Position” is off.
	 *
	 * @param array $attrs Module attrs.
	 * @return string
	 */
	private static function normalize_dsm_badge_position( array $attrs ): string {
		$raw = $attrs['dsm_badge_position']['innerContent']['desktop']['value'] ?? 'top_right';
		if ( is_string( $raw ) && '' !== trim( $raw ) ) {
			return $raw;
		}

		return 'top_right';
	}

	/**
	 * Badge block matching Visual Builder: wrapper classes + `elements->render( dsm_badge )`.
	 *
	 * @param mixed  $elements                 Module elements API.
	 * @param array  $attrs                    Full module attrs (for empty check / dynamic).
	 * @param string $dsm_badge_use_position   `on` or `off`.
	 * @param string $dsm_badge_position       Preset slug when custom position is off.
	 * @return string
	 */
	private static function render_step_flow_badge_block( $elements, array $attrs, $dsm_badge_use_position, $dsm_badge_position ): string {
		$raw = $attrs['dsm_badge']['innerContent']['desktop']['value'] ?? null;
		if ( is_string( $raw ) && '' === trim( $raw ) ) {
			return '';
		}
		if ( is_array( $raw ) && isset( $raw['text'] ) && is_string( $raw['text'] ) && '' === trim( $raw['text'] ) ) {
			return '';
		}

		$classes = array( 'dsm-step-badge' );
		if ( 'off' === $dsm_badge_use_position ) {
			$slug = strtolower( (string) $dsm_badge_position );
			$slug = str_replace( array( '-', ' ' ), '_', $slug );
			$slug = preg_replace( '/[^a-z0-9_]/', '', $slug );
			if ( '' === $slug ) {
				$slug = 'top_right';
			}
			$classes[] = 'dsm-badge-position-' . $slug;
		}

		return sprintf(
			'<div class="%2$s">%1$s</div>',
			$elements->render(
				array(
					'attrName'    => 'dsm_badge',
					'attrSubName' => 'text',
				)
			),
			esc_attr( implode( ' ', $classes ) )
		);
	}

	/**
	 * Build a minimal `headingLink` value object for server / MultiView (expects `text`, not a bare string).
	 *
	 * @param string $text Plain text.
	 * @return array<string, string>
	 */
	private static function step_flow_heading_link_value_from_string( string $text ): array {
		return array(
			'text'   => $text,
			'url'    => '',
			'target' => 'off',
		);
	}

	/**
	 * Legacy saves may store `innerContent` leaves as plain strings. Divi 5 MultiView uses
	 * `ArrayUtility::get_value( $leaf, 'text', '' )` and requires an array leaf for `headingLink`.
	 *
	 * @param array  $attrs    Reference to module attrs.
	 * @param string $attr_key Attribute key (`dsm_title`).
	 */
	private static function ensure_heading_link_text_shape_step_flow( array &$attrs, string $attr_key ): void {
		if ( ! isset( $attrs[ $attr_key ]['innerContent'] ) || ! is_array( $attrs[ $attr_key ]['innerContent'] ) ) {
			return;
		}

		$inner = &$attrs[ $attr_key ]['innerContent'];

		foreach ( array_keys( $inner ) as $breakpoint ) {
			if ( ! isset( $inner[ $breakpoint ] ) ) {
				continue;
			}

			if ( is_string( $inner[ $breakpoint ] ) ) {
				$inner[ $breakpoint ] = array(
					'value' => self::step_flow_heading_link_value_from_string( $inner[ $breakpoint ] ),
				);
				continue;
			}

			if ( ! is_array( $inner[ $breakpoint ] ) ) {
				continue;
			}

			foreach ( array_keys( $inner[ $breakpoint ] ) as $state_key ) {
				if ( ! isset( $inner[ $breakpoint ][ $state_key ] ) ) {
					continue;
				}

				$leaf = &$inner[ $breakpoint ][ $state_key ];

				if ( is_string( $leaf ) ) {
					$leaf = self::step_flow_heading_link_value_from_string( $leaf );
					continue;
				}

				if ( ! is_array( $leaf ) ) {
					continue;
				}

				if ( ! array_key_exists( 'text', $leaf ) ) {
					$leaf['text'] = '';
				}

				$t = $leaf['text'];
				if ( ! is_string( $t ) ) {
					if ( is_scalar( $t ) && ! is_bool( $t ) ) {
						$leaf['text'] = (string) $t;
					} else {
						$leaf['text'] = '';
					}
				}

				if ( ! array_key_exists( 'url', $leaf ) ) {
					$leaf['url'] = '';
				}

				if ( ! array_key_exists( 'target', $leaf ) ) {
					$leaf['target'] = 'off';
				}
			}
		}
	}

	/**
	 * Main step image wrapped for layout (responsive srcset when attachment-based).
	 *
	 * @param mixed $raw Upload innerContent desktop value.
	 * @return string
	 */
	private static function render_step_flow_main_image_markup( $raw ): string {
		$img = UploadImageMarkup::render_img_html( $raw, '' );
		if ( '' === $img ) {
			return '';
		}

		return sprintf( '<span class="dsm-image-wrap">%s</span>', $img );
	}
}
