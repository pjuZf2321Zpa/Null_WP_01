<?php
/**
 * Supreme Contact Field — typed field nested in Divi Contact Form.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Modules;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use DiviSupreme\Extensions\ContactFormEntries\FileUpload;
use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\Module\Options\Element\ElementClassnames;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;

/**
 * Contact Form Field module (dsm/contact-form-field).
 */
class ContactFormField implements DependencyInterface {

	/**
	 * Supported field types.
	 *
	 * @var list<string>
	 */
	public const TYPES = array(
		'date',
		'time',
		'datetime',
		'phone',
		'number',
		'url',
		'multi_select',
		'star_rating',
		'signature',
		'hidden',
		'acceptance',
		'file',
	);

	/**
	 * Submitted value when an Acceptance / Consent checkbox is checked.
	 *
	 * @var string
	 */
	public const ACCEPTANCE_VALUE = 'Accepted';

	/**
	 * Max signature data-URL length (bytes) accepted on submit.
	 *
	 * @var int
	 */
	public const SIGNATURE_MAX_BYTES = 150000;

	/**
	 * Load hooks.
	 *
	 * @return void
	 */
	public function load(): void {
		if (
			! \function_exists( 'dsm_is_contact_form_entries_extension_enabled' )
			|| ! dsm_is_contact_form_entries_extension_enabled()
		) {
			return;
		}

		\add_action( 'init', array( self::class, 'register_module' ) );
	}

	/**
	 * Register with Divi dependency tree.
	 *
	 * @return void
	 */
	public static function dsm_initialise(): void {
		\add_action(
			'divi_module_library_modules_dependency_tree',
			static function ( $dependency_tree ): void {
				$dependency_tree->add_dependency( new self() );
			}
		);
	}

	/**
	 * Register module JSON + render callback.
	 *
	 * @return void
	 */
	public static function register_module(): void {
		$module_json_path = \DSM_DIR_PATH . 'divi-5/public/packages/module-library/contact-form-field';

		ModuleRegistration::register_module(
			$module_json_path,
			array(
				'render_callback' => array( self::class, 'render_callback' ),
			)
		);
	}

	/**
	 * Module styles.
	 *
	 * @param array<string, mixed> $args Style args.
	 * @return void
	 */
	public static function module_styles( $args ): void {
		$args     = \DiviSupreme\Includes\DsmDiviBuilderCssScope::normalize_module_styles_args( $args );
		$attrs    = $args['attrs'] ?? array();
		$elements = $args['elements'];

		$order_class         = (string) ( $args['orderClass'] ?? '' );
		$input_sel           = $order_class . ' .input.dsm-cf-field__control, ' . $order_class . ' .dsm-cf-multiselect__trigger, ' . $order_class . ' .dsm-cf-field__control:not(.dsm-cf-acceptance__input):not(.dsm-cf-multiselect__option-input)';
		$placeholder_sel     = $order_class . ' .input.dsm-cf-field__control::placeholder, ' . $order_class . ' .dsm-cf-field__control:not(.dsm-cf-acceptance__input)::placeholder, ' . $order_class . ' .dsm-cf-multiselect__summary--placeholder';
		$dropzone_sel        = $order_class . ' .dsm-cf-file-upload--field .dsm-cf-file-upload__dropzone';
		$label_sel           = $order_class . ' .dsm-cf-field__label, ' . $order_class . ' .dsm-cf-file-upload__heading';
		$acceptance_text_sel = $order_class . ' .dsm-cf-acceptance__text';
		// Descendants of order class only (match VB ModuleStyles — do not require
		// `.et_pb_contact_field` on the same node as the order class).
		$acceptance_checkbox_sel = $order_class . ' .dsm-cf-acceptance__input, ' . $order_class . ' input.dsm-cf-acceptance__input';
		$acceptance_checked_sel  = $order_class . ' .dsm-cf-acceptance__input:checked, ' . $order_class . ' input.dsm-cf-acceptance__input:checked';
		$acceptance_label_sel    = $order_class . ' .dsm-cf-acceptance__label';
		$cta_sel                 = $order_class . ' .dsm-cf-file-upload--field .dsm-cf-file-upload__cta';
		$hint_sel                = $order_class . ' .dsm-cf-file-upload--field .dsm-cf-file-upload__hint';
		$star_sel                = $order_class . ' .dsm-cf-stars';
		$star_selected_sel       = $order_class . ' .dsm-cf-stars__btn--full .dsm-cf-stars__icon::before, ' . $order_class . ' .dsm-cf-stars__btn.is-active .dsm-cf-stars__icon::before, ' . $order_class . ' .dsm-cf-stars__btn.is-hover .dsm-cf-stars__icon::before';
		$star_unselected_sel     = $order_class . ' .dsm-cf-stars__icon::after';
		$signature_sel           = $order_class . ' .dsm-cf-signature__pad';
		$signature_clear_sel     = $order_class . ' .dsm-cf-signature__clear';
		$ms_panel_sel            = $order_class . ' .dsm-cf-multiselect__panel';
		$ms_option_label_sel     = $order_class . ' .dsm-cf-multiselect__option-label';
		$ms_option_hover_sel     = $order_class . ' .dsm-cf-multiselect__option:hover, ' . $order_class . ' .dsm-cf-multiselect__option:focus-within';
		$ms_option_checked_sel   = $order_class . ' .dsm-cf-multiselect__option:has(.dsm-cf-multiselect__option-input:checked)';
		$ms_checkbox_sel         = $order_class . ' .dsm-cf-multiselect__option-input, ' . $order_class . ' input.dsm-cf-multiselect__option-input';
		$ms_checkbox_checked_sel = $order_class . ' .dsm-cf-multiselect__option-input:checked, ' . $order_class . ' input.dsm-cf-multiselect__option-input:checked';

		Style::add(
			array(
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => array(
					$elements->style(
						array(
							'attrName'   => 'module',
							'styleProps' => array(
								'disabledOn' => array(
									'disabledModuleVisibility' => $args['settings']['disabledModuleVisibility'] ?? null,
								),
							),
						)
					),
					$elements->style(
						array(
							'attrName'   => 'field_label',
							'styleProps' => array(
								'selector' => $label_sel,
								'font'     => array(
									'selector' => $label_sel,
								),
							),
						)
					),
					$elements->style(
						array(
							'attrName'   => 'acceptance_text',
							'styleProps' => array(
								'selector' => $acceptance_text_sel,
								'font'     => array(
									'selector' => $acceptance_text_sel,
								),
							),
						)
					),
					$elements->style(
						array(
							'attrName'   => 'acceptance_checkbox',
							'styleProps' => array(
								'selector'   => $acceptance_checkbox_sel,
								'background' => array(
									'selector'  => $acceptance_checkbox_sel,
									'important' => true,
								),
								'border'     => array(
									'selector'  => $acceptance_checkbox_sel,
									'important' => true,
								),
								'sizing'     => array(
									'selector'  => $acceptance_checkbox_sel,
									'important' => true,
								),
							),
						)
					),
					// CSS custom properties on the module root — inherit into the checkbox.
					CommonStyle::style(
						array(
							'selector'            => $order_class,
							'attr'                => $attrs['acceptance_checkbox']['decoration']['background'] ?? array(),
							'important'           => true,
							'declarationFunction' => static function ( array $params ): string {
								$attr_value = $params['attrValue'] ?? null;
								$color      = '';
								if ( \is_array( $attr_value ) && isset( $attr_value['color'] ) ) {
									$color = (string) $attr_value['color'];
								} elseif ( \is_string( $attr_value ) ) {
									$color = $attr_value;
								}
								if ( '' === $color ) {
									return '';
								}
								return '--dsm-cf-acceptance-bg: ' . $color . ' !important;';
							},
						)
					),
					CommonStyle::style(
						array(
							'selector'  => $order_class,
							'attr'      => $attrs['acceptance_checked_color']['innerContent'] ?? array(),
							'property'  => '--dsm-cf-acceptance-checked',
							'important' => true,
						)
					),
					CommonStyle::style(
						array(
							'selector'  => $order_class,
							'attr'      => $attrs['acceptance_gap']['innerContent'] ?? array(),
							'property'  => '--dsm-cf-acceptance-gap',
							'important' => true,
						)
					),
					CommonStyle::style(
						array(
							'selector'  => $acceptance_checked_sel,
							'attr'      => $attrs['acceptance_checked_color']['innerContent'] ?? array(),
							'property'  => 'background-color',
							'important' => true,
						)
					),
					CommonStyle::style(
						array(
							'selector'  => $acceptance_checked_sel,
							'attr'      => $attrs['acceptance_checked_color']['innerContent'] ?? array(),
							'property'  => 'border-color',
							'important' => true,
						)
					),
					CommonStyle::style(
						array(
							'selector'  => $acceptance_label_sel,
							'attr'      => $attrs['acceptance_gap']['innerContent'] ?? array(),
							'property'  => 'gap',
							'important' => true,
						)
					),
					$elements->style(
						array(
							'attrName'   => 'field_placeholder',
							'styleProps' => array(
								'selector' => $placeholder_sel,
								'font'     => array(
									'selector' => $placeholder_sel,
								),
							),
						)
					),
					$elements->style(
						array(
							'attrName'   => 'field_input',
							'styleProps' => array(
								'selector'   => $input_sel,
								'font'       => array(
									'selector' => $input_sel,
								),
								'background' => array(
									'selector' => $input_sel,
								),
								'border'     => array(
									'selector'  => $input_sel,
									'important' => true,
								),
								'boxShadow'  => array(
									'selector'   => $input_sel,
									'useOverlay' => true,
								),
								'spacing'    => array(
									'selector'  => $input_sel,
									'important' => true,
								),
								'sizing'     => array(
									'selector' => $input_sel,
								),
							),
						)
					),
					$elements->style(
						array(
							'attrName'   => 'multiselect_panel',
							'styleProps' => array(
								'selector'   => $ms_panel_sel,
								'background' => array(
									'selector'  => $ms_panel_sel,
									'important' => true,
								),
								'border'     => array(
									'selector'  => $ms_panel_sel,
									'important' => true,
								),
								'boxShadow'  => array(
									'selector'   => $ms_panel_sel,
									'useOverlay' => true,
								),
							),
						)
					),
					$elements->style(
						array(
							'attrName'   => 'multiselect_option',
							'styleProps' => array(
								'selector' => $ms_option_label_sel,
								'font'     => array(
									'selector' => $ms_option_label_sel,
								),
							),
						)
					),
					CommonStyle::style(
						array(
							'selector'            => $order_class,
							'attr'                => $attrs['multiselect_checkbox']['decoration']['background'] ?? array(),
							'important'           => true,
							'declarationFunction' => static function ( array $params ): string {
								$attr_value = $params['attrValue'] ?? null;
								$color      = '';
								if ( \is_array( $attr_value ) && isset( $attr_value['color'] ) ) {
									$color = (string) $attr_value['color'];
								} elseif ( \is_string( $attr_value ) ) {
									$color = $attr_value;
								}
								if ( '' === $color ) {
									return '';
								}
								return '--dsm-cf-ms-checkbox-bg: ' . $color . ' !important;';
							},
						)
					),
					CommonStyle::style(
						array(
							'selector'  => $order_class,
							'attr'      => $attrs['multiselect_checkbox_checked']['innerContent'] ?? array(),
							'property'  => '--dsm-cf-ms-checkbox-checked',
							'important' => true,
						)
					),
					CommonStyle::style(
						array(
							'selector'  => $order_class,
							'attr'      => $attrs['multiselect_option_hover']['innerContent'] ?? array(),
							'property'  => '--dsm-cf-ms-option-hover',
							'important' => true,
						)
					),
					CommonStyle::style(
						array(
							'selector'  => $order_class,
							'attr'      => $attrs['multiselect_option_checked']['innerContent'] ?? array(),
							'property'  => '--dsm-cf-ms-option-checked',
							'important' => true,
						)
					),
					$elements->style(
						array(
							'attrName'   => 'multiselect_checkbox',
							'styleProps' => array(
								'selector'   => $ms_checkbox_sel,
								'background' => array(
									'selector'  => $ms_checkbox_sel,
									'important' => true,
								),
								'border'     => array(
									'selector'  => $ms_checkbox_sel,
									'important' => true,
								),
								'sizing'     => array(
									'selector'  => $ms_checkbox_sel,
									'important' => true,
								),
							),
						)
					),
					CommonStyle::style(
						array(
							'selector'  => $ms_option_hover_sel,
							'attr'      => $attrs['multiselect_option_hover']['innerContent'] ?? array(),
							'property'  => 'background-color',
							'important' => true,
						)
					),
					CommonStyle::style(
						array(
							'selector'  => $ms_option_checked_sel,
							'attr'      => $attrs['multiselect_option_checked']['innerContent'] ?? array(),
							'property'  => 'background-color',
							'important' => true,
						)
					),
					CommonStyle::style(
						array(
							'selector'  => $ms_checkbox_checked_sel,
							'attr'      => $attrs['multiselect_checkbox_checked']['innerContent'] ?? array(),
							'property'  => 'background-color',
							'important' => true,
						)
					),
					CommonStyle::style(
						array(
							'selector'  => $ms_checkbox_checked_sel,
							'attr'      => $attrs['multiselect_checkbox_checked']['innerContent'] ?? array(),
							'property'  => 'border-color',
							'important' => true,
						)
					),
					CommonStyle::style(
						array(
							'selector' => $star_sel,
							'attr'     => $attrs['star_size']['innerContent'] ?? array(),
							'property' => 'font-size',
						)
					),
					CommonStyle::style(
						array(
							'selector' => $star_sel,
							'attr'     => $attrs['star_gap']['innerContent'] ?? array(),
							'property' => 'gap',
						)
					),
					CommonStyle::style(
						array(
							'selector' => $star_selected_sel,
							'attr'     => $attrs['star_selected_color']['innerContent'] ?? array(),
							'property' => 'background-color',
						)
					),
					CommonStyle::style(
						array(
							'selector' => $star_unselected_sel,
							'attr'     => $attrs['star_unselected_color']['innerContent'] ?? array(),
							'property' => 'background-color',
						)
					),
					$elements->style(
						array(
							'attrName'   => 'signature_pad',
							'styleProps' => array(
								'selector'   => $signature_sel,
								'background' => array(
									'selector' => $signature_sel,
								),
								'border'     => array(
									'selector'  => $signature_sel,
									'important' => true,
								),
								'sizing'     => array(
									'selector' => $signature_sel,
								),
							),
						)
					),
					$elements->style(
						array(
							'attrName'   => 'signature_clear',
							'styleProps' => array(
								'selector' => $signature_clear_sel,
								'font'     => array(
									'selector' => $signature_clear_sel,
								),
							),
						)
					),
					$elements->style(
						array(
							'attrName'   => 'file_dropzone',
							'styleProps' => array(
								'selector'   => $dropzone_sel,
								'background' => array(
									'selector' => $dropzone_sel,
								),
								'border'     => array(
									'selector' => $dropzone_sel,
								),
							),
						)
					),
					$elements->style(
						array(
							'attrName'   => 'file_cta_font',
							'styleProps' => array(
								'selector' => $cta_sel,
								'font'     => array(
									'selector' => $cta_sel,
								),
							),
						)
					),
					$elements->style(
						array(
							'attrName'   => 'file_hint_font',
							'styleProps' => array(
								'selector' => $hint_sel,
								'font'     => array(
									'selector' => $hint_sel,
								),
							),
						)
					),
					CssStyle::style(
						array(
							'selector' => $args['orderClass'],
							'attr'     => $attrs['css'] ?? array(),
						)
					),
				),
			)
		);
	}

	/**
	 * Script data.
	 *
	 * @param array<string, mixed> $args Args.
	 * @return void
	 */
	public static function module_script_data( $args ): void {
		$elements = $args['elements'];
		$elements->script_data(
			array(
				'attrName' => 'module',
			)
		);
	}

	/**
	 * Classnames.
	 *
	 * @param array<string, mixed> $args Args.
	 * @return void
	 */
	public static function module_classnames( $args ): void {
		$classnames_instance = $args['classnamesInstance'];
		$attrs               = $args['attrs'];
		$field_type          = self::get_string_attr( $attrs, 'field_type', 'date' );

		$classnames_instance->add(
			ElementClassnames::classnames(
				array(
					'attrs' => $attrs['module']['decoration'] ?? array(),
				)
			)
		);
		$classnames_instance->add( 'et_pb_contact_field' );
		$classnames_instance->add( 'dsm-cf-field-type--' . \sanitize_key( $field_type ) );
	}

	/**
	 * Frontend render.
	 *
	 * @param array<string, mixed> $attrs    Attrs.
	 * @param string               $content  Content.
	 * @param \WP_Block            $block    Block.
	 * @param mixed                $elements Elements.
	 * @return string
	 */
	public static function render_callback( $attrs, $content, $block, $elements ) {
		if (
			! \function_exists( 'dsm_is_contact_form_entries_extension_enabled' )
			|| ! dsm_is_contact_form_entries_extension_enabled()
		) {
			return '';
		}

		$field_type    = self::normalize_type( self::get_string_attr( $attrs, 'field_type', 'date' ) );
		$field_id      = self::normalize_field_id( self::get_string_attr( $attrs, 'field_id', 'supreme_field' ) );
		$label         = \sanitize_text_field( self::get_string_attr( $attrs, 'field_label', '' ) );
		$required      = 'on' === self::get_string_attr( $attrs, 'field_required', 'off' );
		$placeholder   = \sanitize_text_field( self::get_string_attr( $attrs, 'field_placeholder', '' ) );
		$field_value   = \sanitize_text_field( self::get_string_attr( $attrs, 'field_value', '' ) );
		$error_message = \sanitize_text_field( self::get_string_attr( $attrs, 'field_error_message', '' ) );

		$input_name = 'dsm_cf_field_' . $field_id;
		$star_max   = self::normalize_star_max( self::get_string_attr( $attrs, 'star_max', '5' ) );

		if ( 'file' === $field_type ) {
			self::maybe_enqueue_file_assets();
			$inner = self::render_file_field( $field_id, $label, $required, $error_message );
		} elseif ( 'star_rating' === $field_type ) {
			self::maybe_enqueue_field_assets();
			$inner = self::render_star_rating_field( $input_name, $field_id, $label, $required, $star_max, $error_message );
		} elseif ( 'signature' === $field_type ) {
			self::maybe_enqueue_field_assets();
			$inner = self::render_signature_field( $input_name, $field_id, $label, $required, $error_message );
		} elseif ( 'acceptance' === $field_type ) {
			self::maybe_enqueue_field_assets();
			$inner = self::render_acceptance_field( $input_name, $field_id, $required, $attrs, $error_message );
		} elseif ( 'multi_select' === $field_type ) {
			self::maybe_enqueue_field_assets();
			$inner = self::render_multi_select_field(
				$input_name,
				$field_id,
				$label,
				$required,
				$placeholder,
				self::parse_field_options( self::get_field_options_raw( $attrs ) ),
				$error_message
			);
		} else {
			self::maybe_enqueue_field_assets();
			// Phone uses field_*_length; Number reuses number_min/number_max as digit lengths.
			$length_min = 'number' === $field_type
				? self::normalize_length( self::get_string_attr( $attrs, 'number_min', '0' ) )
				: self::normalize_length( self::get_string_attr( $attrs, 'field_min_length', '0' ) );
			$length_max = 'number' === $field_type
				? self::normalize_length( self::get_string_attr( $attrs, 'number_max', '0' ) )
				: self::normalize_length( self::get_string_attr( $attrs, 'field_max_length', '0' ) );
			$inner      = self::render_input_field(
				$field_type,
				$input_name,
				$field_id,
				$label,
				$required,
				$placeholder,
				array(
					'min_length'           => $length_min,
					'max_length'           => $length_max,
					'phone_country_enable' => 'on' === self::get_string_attr( $attrs, 'phone_country_code_enable', 'off' ),
					'phone_country_code'   => self::normalize_phone_country_code( self::get_string_attr( $attrs, 'phone_country_code', '+1' ) ),
					'field_value'          => $field_value,
					'error_message'        => $error_message,
				)
			);
		}

		$module_elements = $elements->style_components(
			array(
				'attrName' => 'module',
			)
		);

		$module_inner = HTMLUtility::render(
			array(
				'tag'               => 'div',
				'attributes'        => array(
					'class' => 'et_pb_module_inner',
				),
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $inner,
			)
		);

		// Required for et_flex_column_* (Column Class) — same as divi/contact-field.
		$parent               = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );
		$default_parent_attrs = ModuleRegistration::get_default_attrs( 'divi/contact-form' );
		$parent_attrs_raw     = ( is_object( $parent ) && isset( $parent->attrs ) && is_array( $parent->attrs ) )
			? $parent->attrs
			: array();
		$parent_attrs         = array_replace_recursive( $default_parent_attrs, $parent_attrs_raw );

		return Module::render(
			array(
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],
				'attrs'               => $attrs,
				'elements'            => $elements,
				'id'                  => $block->parsed_block['id'],
				'moduleClassName'     => 'dsm_contact_form_field',
				'name'                => $block->block_type->name,
				'classnamesFunction'  => array( self::class, 'module_classnames' ),
				'moduleCategory'      => $block->block_type->category,
				'stylesComponent'     => array( self::class, 'module_styles' ),
				'scriptDataComponent' => array( self::class, 'module_script_data' ),
				'parentAttrs'         => $parent_attrs,
				'parentId'            => is_object( $parent ) ? ( $parent->id ?? '' ) : '',
				// phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- Divi Block API.
				'parentName'          => is_object( $parent ) ? ( $parent->blockName ?? '' ) : '',
				'htmlAttrs'           => array(
					'data-type'                  => $field_type,
					'data-id'                    => $field_id,
					'data-dsm-cf-supreme-field'  => '1',
					'data-dsm-cf-field-type'     => $field_type,
					'data-dsm-cf-field-required' => $required ? '1' : '0',
				),
				'children'            => $module_elements . $module_inner,
			)
		);
	}

	/**
	 * Render standard input types.
	 *
	 * @param string               $field_type  Type.
	 * @param string               $input_name  POST name.
	 * @param string               $field_id    Field id.
	 * @param string               $label       Label.
	 * @param bool                 $required    Required.
	 * @param string               $placeholder Placeholder.
	 * @param array<string, mixed> $options     Type-specific options.
	 * @return string
	 */
	private static function render_input_field(
		string $field_type,
		string $input_name,
		string $field_id,
		string $label,
		bool $required,
		string $placeholder,
		array $options = array()
	): string {
		$html_type  = self::html_input_type( $field_type );
		$is_hidden  = 'hidden' === $field_type;
		$wrap_class = $is_hidden ? 'dsm-cf-field dsm-cf-field--hidden' : 'dsm-cf-field';

		$min_length = isset( $options['min_length'] ) ? (int) $options['min_length'] : 0;
		$max_length = isset( $options['max_length'] ) ? (int) $options['max_length'] : 0;
		if ( $min_length > 0 && $max_length > 0 ) {
			$max_length = \max( $min_length, $max_length );
			$min_length = \min( $min_length, $max_length );
		}

		$phone_cc_on   = ! empty( $options['phone_country_enable'] );
		$phone_cc      = isset( $options['phone_country_code'] ) ? (string) $options['phone_country_code'] : '+1';
		$error_message = isset( $options['error_message'] ) ? \sanitize_text_field( (string) $options['error_message'] ) : '';
		$error_html    = $is_hidden ? '' : self::render_inline_error( $field_id );
		$wrap_data     = self::error_message_data_attr( $error_message );

		// Keep label text clean (no "*") so Divi’s sibling-label message list reads “Phone”, not “Phone *”.
		$label_html = '';
		if ( ! $is_hidden && '' !== $label ) {
			$label_class = 'dsm-cf-field__label' . ( $required ? ' dsm-cf-field__label--required' : '' );
			$label_html  = \sprintf(
				'<label class="%1$s" for="%2$s">%3$s</label>',
				\esc_attr( $label_class ),
				\esc_attr( $input_name ),
				\esc_html( $label )
			);
		}

		$value = '';
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Contact form repost after validation.
		if ( isset( $_POST[ $input_name ] ) ) {
			$value = \sanitize_text_field( \wp_unslash( (string) $_POST[ $input_name ] ) );
		} elseif ( $is_hidden ) {
			$value = isset( $options['field_value'] )
				? \sanitize_text_field( (string) $options['field_value'] )
				: '';
		}
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		$ph = '' !== $placeholder ? $placeholder : $label;

		$divi_attrs  = $is_hidden ? '' : self::divi_contact_field_attrs( $required, $field_id, $field_type );
		$extra_attrs = $divi_attrs;
		if ( $required && ! $is_hidden ) {
			$extra_attrs .= ' aria-required="true"';
		}

		if ( 'phone' === $field_type ) {
			$extra_attrs .= ' inputmode="numeric"';
			$extra_attrs .= ' pattern="[0-9\\-]*"';
			$extra_attrs .= ' autocomplete="tel-national"';
			if ( $min_length > 0 ) {
				$extra_attrs .= ' minlength="' . \esc_attr( (string) $min_length ) . '"';
				$extra_attrs .= ' data-min-length="' . \esc_attr( (string) $min_length ) . '"';
			}
			if ( $max_length > 0 ) {
				$extra_attrs .= ' maxlength="' . \esc_attr( (string) $max_length ) . '"';
				$extra_attrs .= ' data-max-length="' . \esc_attr( (string) $max_length ) . '"';
			}
		}

		if ( 'number' === $field_type ) {
			// type=text so browsers honor maxlength (type=number ignores it).
			$html_type    = 'text';
			$extra_attrs .= ' inputmode="decimal"';
			$extra_attrs .= ' pattern="-?[0-9]*\\.?[0-9]*"';
			$extra_attrs .= ' autocomplete="off"';
			if ( $min_length > 0 ) {
				$extra_attrs .= ' minlength="' . \esc_attr( (string) $min_length ) . '"';
				$extra_attrs .= ' data-min-length="' . \esc_attr( (string) $min_length ) . '"';
			}
			if ( $max_length > 0 ) {
				$extra_attrs .= ' maxlength="' . \esc_attr( (string) $max_length ) . '"';
				$extra_attrs .= ' data-max-length="' . \esc_attr( (string) $max_length ) . '"';
			}
		}

		if ( 'url' === $field_type ) {
			// type=text: native type=url rejects host-without-scheme (example.com) before FE validation.
			$html_type    = 'text';
			$extra_attrs .= ' inputmode="url"';
			$extra_attrs .= ' autocomplete="url"';
			$extra_attrs .= ' spellcheck="false"';
		}

		$control = \sprintf(
			'<input type="%1$s" name="%2$s" id="%2$s" class="input dsm-cf-field__control" value="%3$s" placeholder="%4$s" data-dsm-cf-field="1" data-dsm-cf-field-id="%5$s" data-dsm-cf-field-type="%6$s" data-dsm-cf-field-label="%7$s"%8$s />',
			\esc_attr( $html_type ),
			\esc_attr( $input_name ),
			\esc_attr( $value ),
			\esc_attr( $ph ),
			\esc_attr( $field_id ),
			\esc_attr( $field_type ),
			\esc_attr( $label ),
			$extra_attrs
		);

		if ( 'phone' === $field_type && $phone_cc_on ) {
			$local_value = $value;
			if ( 0 === \strpos( $local_value, $phone_cc ) ) {
				$local_value = \ltrim( \substr( $local_value, \strlen( $phone_cc ) ) );
			}

			$code_options = '';
			foreach ( self::phone_country_codes() as $code => $code_label ) {
				$code_options .= \sprintf(
					'<option value="%1$s" data-dsm-cf-phone-label="%2$s"%3$s>%4$s</option>',
					\esc_attr( $code ),
					\esc_attr( $code_label ),
					\selected( $phone_cc, $code, false ),
					\esc_html( $code_label )
				);
			}

			$cc_label     = __( 'Country code', 'dsm-supreme-modules-pro-for-divi' );
			$local_extra  = ' inputmode="numeric" pattern="[0-9\\-]*" autocomplete="tel-national"';
			$local_extra .= $min_length > 0 ? ' minlength="' . \esc_attr( (string) $min_length ) . '" data-min-length="' . \esc_attr( (string) $min_length ) . '"' : '';
			$local_extra .= $max_length > 0 ? ' maxlength="' . \esc_attr( (string) $max_length ) . '" data-max-length="' . \esc_attr( (string) $max_length ) . '"' : '';

			// Combined value is type=text + screen-reader-text so Divi can discover it as a sibling of the field label.
			$control = \sprintf(
				'<div class="dsm-cf-phone" data-dsm-cf-phone="1">'
				. '<label class="screen-reader-text" for="%1$s-code">%2$s</label>'
				. '<select id="%1$s-code" class="dsm-cf-phone__code" data-dsm-cf-phone-code="1" aria-label="%3$s">%4$s</select>'
				. '<input type="tel" id="%1$s-local" class="input dsm-cf-field__control dsm-cf-phone__local" value="%5$s" placeholder="%6$s" data-dsm-cf-phone-local="1" data-dsm-cf-field-id="%7$s" data-dsm-cf-field-type="phone"%8$s />'
				. '</div>'
				. '<input type="text" name="%1$s" id="%1$s" class="input dsm-cf-field__control dsm-cf-phone__value screen-reader-text" value="%9$s" tabindex="-1" aria-hidden="true" data-dsm-cf-field="1" data-dsm-cf-field-id="%7$s" data-dsm-cf-field-type="phone" data-dsm-cf-field-label="%10$s" data-dsm-cf-phone-combined="1"%11$s />',
				\esc_attr( $input_name ),
				\esc_html( $cc_label ),
				\esc_attr( $cc_label ),
				$code_options,
				\esc_attr( $local_value ),
				\esc_attr( $ph ),
				\esc_attr( $field_id ),
				$local_extra,
				\esc_attr( $value ),
				\esc_attr( $label ),
				$divi_attrs . ( $required ? ' aria-required="true"' : '' )
			);
		}

		$constraints = array();
		if ( 'phone' === $field_type || 'number' === $field_type ) {
			if ( $min_length > 0 ) {
				$constraints['min_length'] = (string) $min_length;
			}
			if ( $max_length > 0 ) {
				$constraints['max_length'] = (string) $max_length;
			}
		}

		$meta = self::render_field_meta( $field_id, $field_type, $label, $required, $constraints );

		return \sprintf(
			'<div class="%1$s" data-dsm-cf-field-type="%2$s" data-dsm-cf-field-id="%3$s"%4$s>%5$s%6$s%7$s%8$s</div>',
			\esc_attr( $wrap_class ),
			\esc_attr( $field_type ),
			\esc_attr( $field_id ),
			$wrap_data,
			$label_html,
			$control,
			$error_html,
			$meta
		);
	}

	/**
	 * Inline error label markup (filled by FE validation).
	 *
	 * @param string $field_id Field id.
	 * @return string
	 */
	private static function render_inline_error( string $field_id ): string {
		return \sprintf(
			'<span class="dsm-cf-field__error" id="dsm-cf-error-%1$s" role="alert" hidden></span>',
			\esc_attr( $field_id )
		);
	}

	/**
	 * Optional custom error message data attribute for FE.
	 *
	 * @param string $error_message Custom message (empty = use defaults).
	 * @return string Attribute string including leading space, or empty.
	 */
	private static function error_message_data_attr( string $error_message ): string {
		$error_message = \sanitize_text_field( $error_message );
		if ( '' === $error_message ) {
			return '';
		}
		return ' data-dsm-cf-error-message="' . \esc_attr( $error_message ) . '"';
	}

	/**
	 * Raw `field_options` leaf (structured rows array or legacy string).
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 * @return mixed
	 */
	private static function get_field_options_raw( array $attrs ) {
		return $attrs['field_options']['innerContent']['desktop']['value'] ?? '';
	}

	/**
	 * Parse multi-select options.
	 *
	 * Accepts structured `{ value, label }[]` rows, SortableList-like maps,
	 * or legacy textarea / `value|Label` strings.
	 *
	 * @param mixed $raw Raw attribute value.
	 * @return list<array{value:string,label:string}>
	 */
	public static function parse_field_options( $raw ): array {
		if ( \is_string( $raw ) ) {
			return self::parse_field_options_from_string( $raw );
		}

		if ( ! \is_array( $raw ) ) {
			return array();
		}

		// Object map → list.
		if ( self::is_assoc_array( $raw ) ) {
			$raw = \array_values( $raw );
		}

		$out = array();
		foreach ( $raw as $row ) {
			if ( \is_string( $row ) ) {
				$parsed = self::parse_field_options_from_string( $row );
				foreach ( $parsed as $item ) {
					$out[] = $item;
				}
				continue;
			}
			if ( ! \is_array( $row ) ) {
				continue;
			}

			$value = \sanitize_text_field( (string) ( $row['value'] ?? '' ) );
			$label = \sanitize_text_field( (string) ( $row['label'] ?? '' ) );
			if ( '' === $value && '' === $label ) {
				continue;
			}
			if ( '' === $value ) {
				$value = $label;
			}
			if ( '' === $label ) {
				$label = $value;
			}

			$out[] = array(
				'value' => $value,
				'label' => $label,
			);
		}

		return $out;
	}

	/**
	 * Parse legacy string options (newline / value|Label).
	 *
	 * @param string $raw Raw string.
	 * @return list<array{value:string,label:string}>
	 */
	private static function parse_field_options_from_string( string $raw ): array {
		$lines = \preg_split( '/\r\n|\r|\n/', $raw );
		if ( ! \is_array( $lines ) ) {
			return array();
		}

		$out = array();
		foreach ( $lines as $line ) {
			$line = \trim( (string) $line );
			if ( '' === $line ) {
				continue;
			}

			$pipe = \strpos( $line, '|' );
			if ( false === $pipe ) {
				$text = \sanitize_text_field( $line );
				if ( '' === $text ) {
					continue;
				}
				$out[] = array(
					'value' => $text,
					'label' => $text,
				);
				continue;
			}

			$value = \sanitize_text_field( \trim( \substr( $line, 0, $pipe ) ) );
			$label = \sanitize_text_field( \trim( \substr( $line, $pipe + 1 ) ) );
			if ( '' === $value && '' === $label ) {
				continue;
			}
			if ( '' === $value ) {
				$value = $label;
			}
			if ( '' === $label ) {
				$label = $value;
			}

			$out[] = array(
				'value' => $value,
				'label' => $label,
			);
		}

		return $out;
	}

	/**
	 * Whether an array is associative (object-like map).
	 *
	 * @param array<mixed> $arr Array.
	 * @return bool
	 */
	private static function is_assoc_array( array $arr ): bool {
		if ( array() === $arr ) {
			return false;
		}
		return \array_keys( $arr ) !== \range( 0, \count( $arr ) - 1 );
	}

	/**
	 * Default multi-select options when none configured.
	 *
	 * @return list<array{value:string,label:string}>
	 */
	private static function default_multi_select_options(): array {
		return array(
			array(
				'value' => 'option-1',
				'label' => __( 'Option 1', 'dsm-supreme-modules-pro-for-divi' ),
			),
			array(
				'value' => 'option-2',
				'label' => __( 'Option 2', 'dsm-supreme-modules-pro-for-divi' ),
			),
			array(
				'value' => 'option-3',
				'label' => __( 'Option 3', 'dsm-supreme-modules-pro-for-divi' ),
			),
		);
	}

	/**
	 * Render multi-select dropdown + checkbox panel.
	 *
	 * @param string                                 $input_name  POST name (without []).
	 * @param string                                 $field_id    Field id.
	 * @param string                                 $label       Label.
	 * @param bool                                   $required    Required.
	 * @param string                                 $placeholder   Closed-state placeholder.
	 * @param list<array{value:string,label:string}> $options        Option value/label pairs.
	 * @param string                                 $error_message Optional custom FE error message.
	 * @return string
	 */
	private static function render_multi_select_field(
		string $input_name,
		string $field_id,
		string $label,
		bool $required,
		string $placeholder,
		array $options,
		string $error_message = ''
	): string {
		$trigger_id = $input_name . '-trigger';
		$panel_id   = $input_name . '-panel';

		$label_html = '';
		if ( '' !== $label ) {
			$label_html = \sprintf(
				'<label class="dsm-cf-field__label" id="%1$s-label" for="%2$s">%3$s%4$s</label>',
				\esc_attr( $input_name ),
				\esc_attr( $trigger_id ),
				\esc_html( $label ),
				$required ? ' <span class="dsm-cf-field__req">*</span>' : ''
			);
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Contact form repost after validation.
		$selected = array();
		if ( isset( $_POST[ $input_name ] ) && \is_array( $_POST[ $input_name ] ) ) {
			$posted_selected = \map_deep( \wp_unslash( $_POST[ $input_name ] ), 'sanitize_text_field' );
			if ( \is_array( $posted_selected ) ) {
				foreach ( $posted_selected as $raw_selected ) {
					$selected[] = (string) $raw_selected;
				}
			}
		}
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		if ( array() === $options ) {
			$options = self::default_multi_select_options();
		}

		$options_map     = array();
		$options_html    = '';
		$values_html     = '';
		$selected_labels = array();

		foreach ( $options as $index => $option ) {
			if ( ! \is_array( $option ) ) {
				$text = \sanitize_text_field( (string) $option );
				if ( '' === $text ) {
					continue;
				}
				$option = array(
					'value' => $text,
					'label' => $text,
				);
			}

			$opt_value = \sanitize_text_field( (string) ( $option['value'] ?? '' ) );
			$opt_label = \sanitize_text_field( (string) ( $option['label'] ?? $opt_value ) );
			if ( '' === $opt_value ) {
				continue;
			}
			if ( '' === $opt_label ) {
				$opt_label = $opt_value;
			}

			$options_map[ $opt_value ] = $opt_label;
			$is_checked                = \in_array( $opt_value, $selected, true );
			if ( $is_checked ) {
				$selected_labels[] = $opt_label;
				$values_html      .= \sprintf(
					'<input type="hidden" name="%1$s[]" value="%2$s" />',
					\esc_attr( $input_name ),
					\esc_attr( $opt_value )
				);
			}

			$opt_dom_id    = $input_name . '-opt-' . (string) $index;
			$options_html .= \sprintf(
				'<label class="dsm-cf-multiselect__option" for="%1$s">'
				. '<input type="checkbox" id="%1$s" class="dsm-cf-multiselect__option-input" value="%2$s" data-label="%3$s"%4$s />'
				. '<span class="dsm-cf-multiselect__option-label">%5$s</span>'
				. '</label>',
				\esc_attr( $opt_dom_id ),
				\esc_attr( $opt_value ),
				\esc_attr( $opt_label ),
				$is_checked ? ' checked' : '',
				\esc_html( $opt_label )
			);
		}

		$placeholder_text = '' !== $placeholder
			? $placeholder
			: __( 'Select options', 'dsm-supreme-modules-pro-for-divi' );

		$summary_text  = array() !== $selected_labels
			? \implode( ', ', $selected_labels )
			: $placeholder_text;
		$summary_class = array() !== $selected_labels
			? 'dsm-cf-multiselect__summary'
			: 'dsm-cf-multiselect__summary dsm-cf-multiselect__summary--placeholder';

		$sentinel_value = \implode( ', ', $selected );

		$map_json = \wp_json_encode( $options_map );
		if ( ! \is_string( $map_json ) ) {
			$map_json = '{}';
		}

		$meta  = self::render_field_meta( $field_id, 'multi_select', $label, $required );
		$meta .= \sprintf(
			'<input type="hidden" name="dsm_cf_field_meta[%1$s][options_map]" value="%2$s" />',
			\esc_attr( $field_id ),
			\esc_attr( $map_json )
		);

		$labelledby = '' !== $label
			? ' aria-labelledby="' . \esc_attr( $input_name ) . '-label"'
			: '';

		$control = \sprintf(
			'<div class="dsm-cf-multiselect" data-dsm-cf-multiselect="1" data-placeholder="%1$s">'
			. '<button type="button" id="%2$s" class="input dsm-cf-field__control dsm-cf-multiselect__trigger" aria-haspopup="listbox" aria-expanded="false" aria-controls="%3$s"%4$s%5$s>'
			. '<span class="%6$s">%7$s</span>'
			. '<span class="dsm-cf-multiselect__chevron" aria-hidden="true"></span>'
			. '</button>'
			. '<div id="%3$s" class="dsm-cf-multiselect__panel" role="listbox" aria-hidden="true">%8$s</div>'
			. '<div class="dsm-cf-multiselect__values" data-dsm-cf-multiselect-values="1">%9$s</div>'
			. '<input type="hidden" class="dsm-cf-field__control dsm-cf-multiselect__sentinel" value="%10$s" data-dsm-cf-field="1" data-dsm-cf-field-id="%11$s" data-dsm-cf-field-type="multi_select" data-dsm-cf-field-label="%12$s" data-required="%13$s"%14$s />'
			. '</div>',
			\esc_attr( $placeholder_text ),
			\esc_attr( $trigger_id ),
			\esc_attr( $panel_id ),
			$labelledby,
			$required ? ' aria-required="true"' : '',
			\esc_attr( $summary_class ),
			\esc_html( $summary_text ),
			$options_html,
			$values_html,
			\esc_attr( $sentinel_value ),
			\esc_attr( $field_id ),
			\esc_attr( $label ),
			$required ? '1' : '0',
			$required ? ' aria-required="true"' : ''
		);

		return \sprintf(
			'<div class="dsm-cf-field" data-dsm-cf-field-type="multi_select" data-dsm-cf-field-id="%1$s"%2$s>%3$s%4$s%5$s%6$s</div>',
			\esc_attr( $field_id ),
			self::error_message_data_attr( $error_message ),
			$label_html,
			$control,
			self::render_inline_error( $field_id ),
			$meta
		);
	}

	/**
	 * Render star rating field.
	 *
	 * @param string $input_name    POST name.
	 * @param string $field_id      Field id.
	 * @param string $label         Label.
	 * @param bool   $required      Required.
	 * @param int    $star_max      Max stars (5|10).
	 * @param string $error_message Optional custom FE error message.
	 * @return string
	 */
	private static function render_star_rating_field(
		string $input_name,
		string $field_id,
		string $label,
		bool $required,
		int $star_max,
		string $error_message = ''
	): string {
		$label_html = '';
		if ( '' !== $label ) {
			$label_html = \sprintf(
				'<label class="dsm-cf-field__label" id="%1$s-label">%2$s%3$s</label>',
				\esc_attr( $input_name ),
				\esc_html( $label ),
				$required ? ' <span class="dsm-cf-field__req">*</span>' : ''
			);
		}

		$buttons = '';
		for ( $i = 1; $i <= $star_max; $i++ ) {
			$buttons .= \sprintf(
				'<button type="button" class="dsm-cf-stars__btn" data-value="%1$d" role="radio" aria-checked="false" aria-label="%2$s">'
				. '<span class="dsm-cf-stars__icon" aria-hidden="true"></span>'
				. '</button>',
				$i,
				/* translators: %d: star value */
				\esc_attr( \sprintf( __( '%d star', 'dsm-supreme-modules-pro-for-divi' ), $i ) )
			);
		}

		$input = \sprintf(
			'<input type="hidden" name="%1$s" id="%1$s" class="input dsm-cf-field__control" value="" data-dsm-cf-field="1" data-dsm-cf-field-id="%2$s" data-dsm-cf-field-type="star_rating" data-dsm-cf-field-label="%3$s" data-required="%4$s"%5$s />',
			\esc_attr( $input_name ),
			\esc_attr( $field_id ),
			\esc_attr( $label ),
			$required ? '1' : '0',
			$required ? ' aria-required="true"' : ''
		);

		$meta = self::render_field_meta( $field_id, 'star_rating', $label, $required );

		$group_aria = '' !== $label
			? ' aria-labelledby="' . \esc_attr( $input_name ) . '-label"'
			: ' aria-label="' . \esc_attr__( 'Star rating', 'dsm-supreme-modules-pro-for-divi' ) . '"';

		return \sprintf(
			'<div class="dsm-cf-field" data-dsm-cf-field-type="star_rating" data-dsm-cf-field-id="%1$s"%2$s>'
			. '%3$s'
			. '<div class="dsm-cf-stars" data-dsm-cf-stars="1" role="radiogroup" tabindex="-1"%4$s data-max="%5$d">'
			. '%6$s%7$s'
			. '</div>%8$s%9$s</div>',
			\esc_attr( $field_id ),
			self::error_message_data_attr( $error_message ),
			$label_html,
			$group_aria,
			$star_max,
			$buttons,
			$input,
			self::render_inline_error( $field_id ),
			$meta
		);
	}

	/**
	 * Render signature pad field.
	 *
	 * @param string $input_name    POST name.
	 * @param string $field_id      Field id.
	 * @param string $label         Label.
	 * @param bool   $required      Required.
	 * @param string $error_message Optional custom FE error message.
	 * @return string
	 */
	private static function render_signature_field(
		string $input_name,
		string $field_id,
		string $label,
		bool $required,
		string $error_message = ''
	): string {
		$label_html = '';
		if ( '' !== $label ) {
			$label_html = \sprintf(
				'<label class="dsm-cf-field__label" for="%1$s">%2$s%3$s</label>',
				\esc_attr( $input_name ),
				\esc_html( $label ),
				$required ? ' <span class="dsm-cf-field__req">*</span>' : ''
			);
		}

		$input = \sprintf(
			'<input type="hidden" name="%1$s" id="%1$s" class="input dsm-cf-field__control" value="" data-dsm-cf-field="1" data-dsm-cf-field-id="%2$s" data-dsm-cf-field-type="signature" data-dsm-cf-field-label="%3$s" data-required="%4$s"%5$s />',
			\esc_attr( $input_name ),
			\esc_attr( $field_id ),
			\esc_attr( $label ),
			$required ? '1' : '0',
			$required ? ' aria-required="true"' : ''
		);

		$meta = self::render_field_meta( $field_id, 'signature', $label, $required );

		$canvas_label = '' !== $label
			? $label
			: __( 'Signature', 'dsm-supreme-modules-pro-for-divi' );

		return \sprintf(
			'<div class="dsm-cf-field" data-dsm-cf-field-type="signature" data-dsm-cf-field-id="%1$s"%2$s>'
			. '%3$s'
			. '<div class="dsm-cf-signature" data-dsm-cf-signature="1">'
			. '<canvas class="dsm-cf-signature__pad" width="600" height="160" role="img" aria-label="%4$s"></canvas>'
			. '<button type="button" class="dsm-cf-signature__clear">%5$s</button>'
			. '%6$s'
			. '</div>%7$s%8$s</div>',
			\esc_attr( $field_id ),
			self::error_message_data_attr( $error_message ),
			$label_html,
			\esc_attr( $canvas_label ),
			\esc_html__( 'Clear', 'dsm-supreme-modules-pro-for-divi' ),
			$input,
			self::render_inline_error( $field_id ),
			$meta
		);
	}

	/**
	 * Render Acceptance / GDPR consent checkbox.
	 *
	 * @param string               $input_name    POST name.
	 * @param string               $field_id      Field id.
	 * @param bool                 $required      Required.
	 * @param array<string, mixed> $attrs         Module attrs (rich consent + legacy privacy URL).
	 * @param string               $error_message Optional custom FE error message.
	 * @return string
	 */
	private static function render_acceptance_field(
		string $input_name,
		string $field_id,
		bool $required,
		array $attrs,
		string $error_message = ''
	): string {
		$resolved  = self::resolve_acceptance_consent( $attrs );
		$text_html = $resolved['html'];
		$plain     = $resolved['plain'];

		if ( $required ) {
			$text_html .= ' <span class="dsm-cf-field__req">*</span>';
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Contact form repost after validation.
		$checked = isset( $_POST[ $input_name ] );
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		$meta_label = \sanitize_text_field( self::get_string_attr( $attrs, 'field_label', '' ) );
		if ( '' === $meta_label ) {
			$meta_label = $plain;
		}

		$input = \sprintf(
			'<input type="checkbox" name="%1$s" id="%1$s" class="dsm-cf-field__control dsm-cf-acceptance__input" value="%2$s" data-dsm-cf-field="1" data-dsm-cf-field-id="%3$s" data-dsm-cf-field-type="acceptance" data-dsm-cf-field-label="%4$s" data-required="%5$s"%6$s%7$s />',
			\esc_attr( $input_name ),
			\esc_attr( self::ACCEPTANCE_VALUE ),
			\esc_attr( $field_id ),
			\esc_attr( $plain ),
			$required ? '1' : '0',
			$required ? ' aria-required="true"' : '',
			$checked ? ' checked="checked"' : ''
		);

		$meta = self::render_field_meta( $field_id, 'acceptance', $meta_label, $required );

		return \sprintf(
			'<div class="dsm-cf-field dsm-cf-acceptance" data-dsm-cf-field-type="acceptance" data-dsm-cf-field-id="%1$s"%2$s>'
			. '<label class="dsm-cf-acceptance__label" for="%3$s">%4$s<span class="dsm-cf-acceptance__text">%5$s</span></label>'
			. '%6$s%7$s</div>',
			\esc_attr( $field_id ),
			self::error_message_data_attr( $error_message ),
			\esc_attr( $input_name ),
			$input,
			$text_html,
			self::render_inline_error( $field_id ),
			$meta
		);
	}

	/**
	 * Resolve consent HTML for Acceptance fields.
	 *
	 * Prefers rich `acceptance_text` (`value.text`). Falls back to legacy plain
	 * `field_label` + optional `acceptance_privacy_url` when rich text is empty,
	 * or when a leftover privacy URL exists and the consent HTML has no links.
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 * @return array{html:string,plain:string}
	 */
	private static function resolve_acceptance_consent( array $attrs ): array {
		$default = __( 'I agree to the terms and privacy policy', 'dsm-supreme-modules-pro-for-divi' );
		$html    = self::get_content_text_attr( $attrs, 'acceptance_text', '' );
		$privacy = \esc_url_raw( self::get_string_attr( $attrs, 'acceptance_privacy_url', '' ) );

		if ( '' === \trim( \wp_strip_all_tags( $html ) ) ) {
			$legacy = self::get_string_attr( $attrs, 'field_label', '' );
			// Legacy plain consent (pre-rich) lived on field_label — escape as text.
			$html = '' !== $legacy ? \esc_html( $legacy ) : \esc_html( $default );
		}

		if ( '' !== $privacy && false === \stripos( $html, '<a' ) ) {
			$html .= ' ' . \sprintf(
				'<a class="dsm-cf-acceptance__privacy" href="%1$s" target="_blank" rel="noopener noreferrer">%2$s</a>',
				\esc_url( $privacy ),
				\esc_html__( 'Privacy Policy', 'dsm-supreme-modules-pro-for-divi' )
			);
		}

		$html  = self::sanitize_acceptance_html( $html );
		$plain = \sanitize_text_field( \wp_strip_all_tags( $html ) );
		if ( '' === $plain ) {
			$plain = $default;
			$html  = \esc_html( $default );
		}

		return array(
			'html'  => $html,
			'plain' => $plain,
		);
	}

	/**
	 * Sanitize consent HTML (unwrap a single TinyMCE paragraph, then wp_kses_post).
	 *
	 * @param string $html Raw HTML.
	 * @return string
	 */
	private static function sanitize_acceptance_html( string $html ): string {
		$html = \trim( $html );
		if ( '' === $html ) {
			return '';
		}

		// TinyMCE often wraps a single line in <p>…</p> — unwrap for checkbox labels.
		if ( \preg_match( '#^<p>(.*)</p>$#is', $html, $matches ) && false === \stripos( $matches[1], '<p' ) ) {
			$html = $matches[1];
		}

		return \wp_kses_post( $html );
	}

	/**
	 * Read rich/content attr text leaf (`innerContent.desktop.value.text`).
	 *
	 * Also accepts legacy plain string `value`.
	 *
	 * @param array<string, mixed> $attrs         Attrs.
	 * @param string               $key           Attr key.
	 * @param string               $default_value Default.
	 * @return string
	 */
	private static function get_content_text_attr( array $attrs, string $key, string $default_value = '' ): string {
		if ( ! isset( $attrs[ $key ]['innerContent']['desktop'] ) ) {
			return $default_value;
		}

		$desktop = $attrs[ $key ]['innerContent']['desktop'];
		if ( ! \is_array( $desktop ) ) {
			return $default_value;
		}

		$value = $desktop['value'] ?? null;
		if ( \is_array( $value ) && isset( $value['text'] ) ) {
			return (string) $value['text'];
		}
		if ( \is_string( $value ) ) {
			return $value;
		}
		// Migrator leaf: desktop.text without value wrapper.
		if ( isset( $desktop['text'] ) && \is_string( $desktop['text'] ) ) {
			return $desktop['text'];
		}

		return $default_value;
	}

	/**
	 * Hidden meta inputs shared by all Supreme field types.
	 *
	 * Constraint keys (`min_length`, `max_length`) mirror FE `data-*` attributes
	 * for phone/number character length so server-side submit validation matches.
	 *
	 * @param string                $field_id     Field id.
	 * @param string                $field_type   Type.
	 * @param string                $label        Label.
	 * @param bool                  $required     Required.
	 * @param array<string, string> $constraints  Optional numeric constraints.
	 * @return string
	 */
	private static function render_field_meta( string $field_id, string $field_type, string $label, bool $required, array $constraints = array() ): string {
		$html = \sprintf(
			'<input type="hidden" name="dsm_cf_field_meta[%1$s][type]" value="%2$s" />'
			. '<input type="hidden" name="dsm_cf_field_meta[%1$s][label]" value="%3$s" />'
			. '<input type="hidden" name="dsm_cf_field_meta[%1$s][required]" value="%4$s" />',
			\esc_attr( $field_id ),
			\esc_attr( $field_type ),
			\esc_attr( $label ),
			$required ? '1' : '0'
		);

		$allowed_keys = array( 'min_length', 'max_length', 'min', 'max' );
		foreach ( $allowed_keys as $key ) {
			if ( ! isset( $constraints[ $key ] ) ) {
				continue;
			}
			$value = \sanitize_text_field( (string) $constraints[ $key ] );
			if ( '' === $value ) {
				continue;
			}
			$html .= \sprintf(
				'<input type="hidden" name="dsm_cf_field_meta[%1$s][%2$s]" value="%3$s" />',
				\esc_attr( $field_id ),
				\esc_attr( $key ),
				\esc_attr( $value )
			);
		}

		return $html;
	}

	/**
	 * Render file dropzone (pre-upload architecture).
	 *
	 * @param string $field_id      Field id.
	 * @param string $label         Label.
	 * @param bool   $required      Required.
	 * @param string $error_message Optional custom FE error message.
	 * @return string
	 */
	private static function render_file_field( string $field_id, string $label, bool $required, string $error_message = '' ): string {
		if ( ! \class_exists( FileUpload::class ) ) {
			return '';
		}

		FileUpload::print_layout_style();

		$extensions = FileUpload::get_allowed_extensions();
		$accept     = \implode(
			',',
			\array_map(
				static function ( string $ext ): string {
					return '.' . $ext;
				},
				$extensions
			)
		);
		$max_mb     = FileUpload::get_max_mb();
		$hint       = \sprintf(
			/* translators: 1: comma-separated extensions, 2: max size in MB */
			__( '%1$s · max %2$d MB', 'dsm-supreme-modules-pro-for-divi' ),
			\strtoupper( \implode( ', ', \array_slice( $extensions, 0, 6 ) ) ),
			$max_mb
		);

		$token_name = 'dsm_cf_file_id_' . $field_id;

		$meta = \sprintf(
			'<input type="hidden" name="dsm_cf_field_meta[%1$s][type]" value="file" />'
			. '<input type="hidden" name="dsm_cf_field_meta[%1$s][label]" value="%2$s" />'
			. '<input type="hidden" name="dsm_cf_field_meta[%1$s][required]" value="%3$s" />',
			\esc_attr( $field_id ),
			\esc_attr( $label ),
			$required ? '1' : '0'
		);

		$heading_html = '';
		if ( '' !== $label ) {
			$heading_html = \sprintf(
				'<div class="dsm-cf-file-upload__heading">%1$s%2$s</div>',
				\esc_html( $label ),
				$required ? ' <span class="dsm-cf-file-upload__req">*</span>' : ''
			);
		}

		return \sprintf(
			'<div class="dsm-cf-file-upload dsm-cf-file-upload--field" data-dsm-cf-file="1" data-dsm-cf-field-type="file" data-dsm-cf-field-id="%1$s" data-required="%2$s" data-max-mb="%3$d"%4$s>'
			. '<input type="hidden" name="%5$s" value="" class="dsm-cf-file-id" />'
			. '%6$s'
			. '<label class="dsm-cf-file-upload__dropzone">'
			. '<input type="file" name="dsm_cf_file_%1$s" class="dsm-cf-file-input et_pb_contact_field" accept="%7$s" />'
			. '<span class="dsm-cf-file-upload__icon" aria-hidden="true">'
			. '<svg width="28" height="28" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">'
			. '<path d="M12 16V4m0 0l-4 4m4-4l4 4M4 17.5V19a2 2 0 002 2h12a2 2 0 002-2v-1.5" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"/>'
			. '</svg></span>'
			. '<span class="dsm-cf-file-upload__cta">%8$s</span>'
			. '<span class="dsm-cf-file-upload__hint">%9$s</span>'
			. '<span class="dsm-cf-file-upload__name" hidden></span>'
			. '</label>'
			. '<p class="dsm-cf-file-upload__status" hidden></p>'
			. '%10$s%11$s'
			. '</div>',
			\esc_attr( $field_id ),
			$required ? '1' : '0',
			$max_mb,
			self::error_message_data_attr( $error_message ),
			\esc_attr( $token_name ),
			$heading_html,
			\esc_attr( $accept ),
			\esc_html__( 'Choose a file or drag it here', 'dsm-supreme-modules-pro-for-divi' ),
			\esc_html( $hint ),
			self::render_inline_error( $field_id ),
			$meta
		);
	}

	/**
	 * Enqueue required-field FE script.
	 *
	 * @return void
	 */
	private static function maybe_enqueue_field_assets(): void {
		static $done = false;
		if ( $done ) {
			return;
		}
		$done = true;

		$handle = 'dsm-cf-contact-form-field';
		$src    = \DSM_DIR_URL . 'public/contact-form-field-frontend.js';
		$path   = \DSM_DIR_PATH . 'divi-5/public/contact-form-field-frontend.js';
		$ver    = \is_readable( $path ) ? (string) \filemtime( $path ) : ( \defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0' );

		\wp_enqueue_script( $handle, $src, array(), $ver, true );
		\wp_localize_script(
			$handle,
			'dsmCfContactFormField',
			array(
				'i18n' => array(
					'required'      => __( 'Please fill in the required field.', 'dsm-supreme-modules-pro-for-divi' ),
					'acceptance'    => __( 'Please accept the required consent before submitting.', 'dsm-supreme-modules-pro-for-divi' ),
					'minLength'     => __( 'Please enter at least the minimum number of characters.', 'dsm-supreme-modules-pro-for-divi' ),
					'maxLength'     => __( 'Please shorten this field to the maximum length.', 'dsm-supreme-modules-pro-for-divi' ),
					'minValue'      => __( 'Please enter a value greater than or equal to the minimum.', 'dsm-supreme-modules-pro-for-divi' ),
					'maxValue'      => __( 'Please enter a value less than or equal to the maximum.', 'dsm-supreme-modules-pro-for-divi' ),
					'invalidPhone'  => __( 'Please enter a valid phone number using digits and hyphens only.', 'dsm-supreme-modules-pro-for-divi' ),
					'invalidNumber' => __( 'Please enter a valid number.', 'dsm-supreme-modules-pro-for-divi' ),
					'invalidUrl'    => __( 'Please enter a valid URL.', 'dsm-supreme-modules-pro-for-divi' ),
					'selectOptions' => __( 'Select options', 'dsm-supreme-modules-pro-for-divi' ),
				),
			)
		);
	}

	/**
	 * Enqueue file pre-upload assets via FileUpload.
	 *
	 * @return void
	 */
	private static function maybe_enqueue_file_assets(): void {
		if ( \class_exists( FileUpload::class ) ) {
			// Public enqueue helper — call through a thin wrapper if private.
			FileUpload::enqueue_frontend_public();
		}
		self::maybe_enqueue_field_assets();
	}

	/**
	 * Read string attr from D5 shape.
	 *
	 * @param array<string, mixed> $attrs         Attrs.
	 * @param string               $key           Key.
	 * @param string               $default_value Default.
	 * @return string
	 */
	private static function get_string_attr( array $attrs, string $key, string $default_value = '' ): string {
		if ( isset( $attrs[ $key ]['innerContent']['desktop']['value'] ) ) {
			return (string) $attrs[ $key ]['innerContent']['desktop']['value'];
		}
		return $default_value;
	}

	/**
	 * Normalize type slug.
	 *
	 * @param string $type Type.
	 * @return string
	 */
	public static function normalize_type( string $type ): string {
		$type = \sanitize_key( $type );
		return \in_array( $type, self::TYPES, true ) ? $type : 'date';
	}

	/**
	 * Normalize field id for POST keys.
	 *
	 * @param string $field_id Raw id.
	 * @return string
	 */
	public static function normalize_field_id( string $field_id ): string {
		$field_id = \strtolower( \sanitize_key( $field_id ) );
		if ( '' === $field_id ) {
			return 'supreme_field';
		}
		return $field_id;
	}

	/**
	 * Map field type to HTML input type.
	 *
	 * @param string $field_type Type.
	 * @return string
	 */
	private static function html_input_type( string $field_type ): string {
		switch ( $field_type ) {
			case 'time':
				return 'time';
			case 'datetime':
				return 'datetime-local';
			case 'phone':
				// type=text so Divi’s contact FE can collect it (`input[type=text]`).
				return 'text';
			case 'number':
				// Rendered as text + inputmode so maxlength/minlength work (see render_input_field).
				return 'text';
			case 'url':
				// Rendered as text + inputmode so host-without-scheme is not blocked by UA validation.
				return 'text';
			case 'hidden':
				return 'hidden';
			case 'date':
			default:
				return 'date';
		}
	}

	/**
	 * Divi contact-form FE discovery attributes.
	 *
	 * Divi collects required empties via `data-required_mark="required"` on
	 * `input[type=text]`, textarea, select (see module-library-script-contact-form.js)
	 * and reads the label from a sibling `<label>`.
	 *
	 * @param bool   $required   Whether required.
	 * @param string $field_id   Original field id.
	 * @param string $field_type Supreme field type (stored on data-field_type for Divi).
	 * @return string Attribute string including a leading space, or empty for non-required hidden.
	 */
	private static function divi_contact_field_attrs( bool $required, string $field_id, string $field_type ): string {
		// Divi treats unknown field_type as text; "input" matches native text fields.
		$divi_type = \in_array( $field_type, array( 'email', 'text', 'input' ), true )
			? $field_type
			: 'input';

		return \sprintf(
			' data-required_mark="%1$s" data-field_type="%2$s" data-original_id="%3$s" data-required="%4$s"',
			$required ? 'required' : 'not_required',
			\esc_attr( $divi_type ),
			\esc_attr( $field_id ),
			$required ? '1' : '0'
		);
	}

	/**
	 * Normalize max stars (5 or 10).
	 *
	 * @param string $raw Raw value.
	 * @return int
	 */
	public static function normalize_star_max( string $raw ): int {
		return 10 === (int) $raw ? 10 : 5;
	}

	/**
	 * Normalize length restriction (0 = none).
	 *
	 * @param string $raw Raw.
	 * @return int
	 */
	public static function normalize_length( string $raw ): int {
		// Strip accidental CSS units from RangeControl (e.g. "12px" → 12).
		$raw = \preg_replace( '/[^\d.\-]/', '', $raw ) ?? '';
		$n   = (int) $raw;
		return $n > 0 ? $n : 0;
	}

	/**
	 * Prepend https:// when the value has no URI scheme (validation / sanitize helper).
	 *
	 * Host-without-scheme values like `example.com` are accepted after this normalization.
	 * Bare tokens like `asd` remain invalid because the host has no dot (see is_plausible_url).
	 *
	 * @param string $value Raw URL input.
	 * @return string Candidate URL with scheme when needed.
	 */
	public static function normalize_url_candidate( string $value ): string {
		$value = \trim( $value );
		if ( '' === $value ) {
			return '';
		}
		if ( 1 !== \preg_match( '#^[a-z][a-z0-9+.\-]*:#i', $value ) ) {
			return 'https://' . $value;
		}
		return $value;
	}

	/**
	 * Whether a non-empty URL field value is a plausible http(s) URL.
	 *
	 * Empty strings are valid here (required is checked separately). Scheme may be omitted;
	 * missing schemes are treated as https:// for validation. Hosts must include a dot
	 * (or be `localhost`) so values like `asd` fail while `example.com` passes.
	 *
	 * @param string $value Raw URL input.
	 * @return bool
	 */
	public static function is_plausible_url( string $value ): bool {
		$value = \trim( $value );
		if ( '' === $value ) {
			return true;
		}

		$candidate = self::normalize_url_candidate( $value );
		if ( 1 !== \preg_match( '#^https?://#i', $candidate ) ) {
			return false;
		}

		$parts = \wp_parse_url( $candidate );
		if ( ! \is_array( $parts ) || empty( $parts['host'] ) || ! \is_string( $parts['host'] ) ) {
			return false;
		}

		$host = \strtolower( $parts['host'] );
		if ( 'localhost' === $host ) {
			return true;
		}

		if ( false === \strpos( $host, '.' ) ) {
			return false;
		}

		if ( 1 === \preg_match( '/\.\.|\A\.|\.\z/', $host ) ) {
			return false;
		}

		if ( 1 !== \preg_match( '/\A[a-z0-9.\-]+\z/', $host ) ) {
			return false;
		}

		return false !== \filter_var( $candidate, \FILTER_VALIDATE_URL );
	}

	/**
	 * Normalize number min/max bound (empty = none).
	 *
	 * Strips accidental CSS units from RangeControl (e.g. "12px" → "12").
	 *
	 * @param string $raw Raw attribute value.
	 * @return string Numeric string, or empty when unset/invalid.
	 */
	public static function normalize_number_bound( string $raw ): string {
		$raw = \trim( $raw );
		if ( '' === $raw ) {
			return '';
		}

		$raw = \preg_replace( '/[^\d.\-]/', '', $raw ) ?? '';
		if ( '' === $raw || ! \is_numeric( $raw ) ) {
			return '';
		}

		return $raw;
	}

	/**
	 * Normalize dial code (+digits).
	 *
	 * @param string $raw Raw.
	 * @return string
	 */
	public static function normalize_phone_country_code( string $raw ): string {
		$raw = \trim( $raw );
		if ( ! \preg_match( '/^\+\d{1,4}$/', $raw ) ) {
			return '+1';
		}
		$known = self::phone_country_codes();
		return isset( $known[ $raw ] ) ? $raw : '+1';
	}

	/**
	 * Cached dial codes from phone-country-codes-data.json.
	 *
	 * @var array<string, string>|null
	 */
	private static $phone_country_codes_cache = null;

	/**
	 * Full unique E.164 dial codes for phone country select (FE + validation).
	 *
	 * Source of truth: `phone-country-codes-data.json` (also imported by VB JS).
	 * Prefer public copy after `npm run build`; fall back to packages for local dev.
	 *
	 * @return array<string, string> code => label
	 */
	public static function phone_country_codes(): array {
		if ( null !== self::$phone_country_codes_cache ) {
			return self::$phone_country_codes_cache;
		}

		$relative = 'packages/module-library/contact-form-field/phone-country-codes-data.json';
		$paths    = array(
			\DSM_DIR_PATH . 'divi-5/public/' . $relative,
			\DSM_DIR_PATH . 'divi-5/' . $relative,
		);

		$decoded = null;
		foreach ( $paths as $path ) {
			if ( ! \is_readable( $path ) ) {
				continue;
			}
			$decoded = \wp_json_file_decode( $path, array( 'associative' => true ) );
			if ( \is_array( $decoded ) ) {
				break;
			}
		}

		$codes = array();
		if ( \is_array( $decoded ) ) {
			foreach ( $decoded as $entry ) {
				if ( ! \is_array( $entry ) ) {
					continue;
				}
				$code = isset( $entry['code'] ) ? \trim( (string) $entry['code'] ) : '';
				$name = isset( $entry['name'] ) ? \trim( (string) $entry['name'] ) : '';
				if ( ! \preg_match( '/^\+\d{1,4}$/', $code ) || '' === $name ) {
					continue;
				}
				$codes[ $code ] = \sprintf(
					/* translators: 1: dial code (e.g. +1), 2: country or territory name */
					__( '%1$s (%2$s)', 'dsm-supreme-modules-pro-for-divi' ),
					$code,
					// phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralText -- Country names from shared JSON source of truth.
					__( $name, 'dsm-supreme-modules-pro-for-divi' )
				);
			}
		}

		if ( empty( $codes ) ) {
			$codes = array(
				'+1' => '+1 (United States / Canada)',
			);
		}

		self::$phone_country_codes_cache = $codes;

		return self::$phone_country_codes_cache;
	}
}
