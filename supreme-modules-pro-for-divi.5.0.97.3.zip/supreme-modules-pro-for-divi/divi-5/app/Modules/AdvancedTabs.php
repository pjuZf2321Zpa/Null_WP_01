<?php
/**
 * Advanced Tabs Module.
 *
 * @package DiviSupreme.
 */

declare(strict_types=1);

namespace DiviSupreme\Modules;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\Module\Options\Element\ElementClassnames;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\Packages\ModuleUtils\ModuleUtils;
use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Packages\Module\Options\Element\ElementComponents;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;
use ET\Builder\Packages\Module\Layout\Components\ModuleElements\ModuleElements;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use DiviSupreme\Includes\DsmDiviBuilderCssScope;
use DiviSupreme\Includes\DiviLibraryLayoutRenderer;
use DiviSupreme\Includes\DsmFrontendDynamicAssets;
use DiviSupreme\Includes\UploadImageMarkup;
use DiviSupreme\Extensions\IconLibraries\IconModuleRenderBridge;


/**
 * Class that handles "AdvancedTabs Module" module.
 */
class AdvancedTabs implements DependencyInterface {


	/**
	 * Nested module HTML from each tab child's first render.
	 *
	 * Keyed by store instance and child block id so Theme Builder layouts and
	 * nested Advanced Tabs do not reuse another canvas's HTML. WordPress renders
	 * a tab's inner blocks before the parent callback.
	 *
	 * @var array<string, string>
	 */
	private static array $rendered_child_content = array();

	/**
	 * Remember nested module HTML from a tab child's first render.
	 *
	 * @param mixed  $store_instance Block parser store instance.
	 * @param string $child_id       Child block id from the parsed block.
	 * @param string $html           Rendered inner blocks.
	 * @return void
	 */
	public static function stash_child_nested_content( $store_instance, string $child_id, string $html ): void {
		if ( '' !== $child_id ) {
			self::$rendered_child_content[ (string) $store_instance . '|' . $child_id ] = $html;
		}
	}

	/**
	 * Register module.
	 * `DependencyInterface` interface ensures class method name `load()` is executed for initialization.
	 */
	public function load() {
		add_action( 'init', array( self::class, 'register_module' ) );
	}

	/**
	 * Initilises the module.
	 *
	 * @return void
	 */
	public static function dsm_initialise() {
		add_action(
			'divi_module_library_modules_dependency_tree',
			function ( $dependency_tree ) {
				$dependency_tree->add_dependency( new self() );
			}
		);
	}

	/**
	 * Register module.
	 */
	public static function register_module() {

		$module_json_path = DSM_DIR_PATH . 'divi-5/public/packages/module-library/advanced-tabs';

		ModuleRegistration::register_module(
			$module_json_path,
			array(
				'render_callback' => array( self::class, 'render_callback' ),
			)
		);
	}

	/**
	 * Tab wrapper align declaration.
	 *
	 * @param mixed $params Params.
	 */
	public static function tab_wrapper_align_declaration( $params ) {
		$attr = $params['attrValue'] ?? '';

		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
				'important'  => array(
					'align-self'   => true,
					'margin-left'  => true,
					'margin-right' => true,
				),
			)
		);

		// Column flex parent: cross-axis alignment needs align-self, not only margins (stretch was full width).
		if ( 'left' === $attr ) {
			$style_declarations->add( 'align-self', 'flex-start' );
			$style_declarations->add( 'margin-left', '0' );
			$style_declarations->add( 'margin-right', 'auto' );

			return $style_declarations->value();
		}

		if ( 'center' === $attr ) {
			$style_declarations->add( 'align-self', 'center' );
			$style_declarations->add( 'margin-left', 'auto;' );
			$style_declarations->add( 'margin-right', 'auto;' );

			return $style_declarations->value();
		}

		if ( 'right' === $attr ) {
			$style_declarations->add( 'align-self', 'flex-end' );
			$style_declarations->add( 'margin-left', 'auto;' );

			return $style_declarations->value();
		}

		return $style_declarations->value();
	}

	/**
	 * Tab horizontal position declaration.
	 *
	 * @param mixed $params Params.
	 */
	public static function tab_horizontal_position_declaration( $params ) {
		$attr = $params['attrValue'] ?? array();

		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
				'important'  => array(
					'order' => true,
				),
			)
		);

		if ( 'bottom' === $attr ) {
			$style_declarations->add( 'order', '-1' );
		}

		return $style_declarations->value();
	}

	/**
	 * Tabs horizontal alignment declaration.
	 *
	 * @param mixed $params Params.
	 */
	public static function tabs_horizontal_alignment_declaration( $params ) {
		$attr = $params['attrValue'] ?? array();

		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
				'important'  => array(
					'justify-content' => true,
				),
			)
		);

		$align_value = '';
		switch ( $attr ) {
			case 'left':
				$align_value = 'flex-start';
				break;
			case 'center':
				$align_value = 'center';
				break;
			case 'right':
				$align_value = 'flex-end';
				break;
		}

		$style_declarations->add( 'justify-content', $align_value );

		return $style_declarations->value();
	}

	/**
	 * D4 complementary column width: `100 - (int) dsm_content_image_width` on `.dsm-inner-content`
	 * when the panel has `dsm-left` (image/icon placement left).
	 *
	 * @param array<string, mixed> $params Declaration params including `attrValue` (e.g. `50%`).
	 * @return string
	 */
	public static function content_image_remaining_width_declaration( $params ) {
		$raw = $params['attrValue'] ?? '';
		if ( is_array( $raw ) && isset( $raw['value'] ) ) {
			$raw = $raw['value'];
		}
		if ( ! is_scalar( $raw ) || '' === trim( (string) $raw ) ) {
			return '';
		}

		$image_width = (int) $raw;
		if ( $image_width <= 0 ) {
			return '';
		}

		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
			)
		);
		$style_declarations->add( 'width', (string) ( 100 - $image_width ) . '%' );

		return $style_declarations->value();
	}

	/**
	 * Tabs vertical width declaration.
	 *
	 * @param mixed $params Params.
	 */
	public static function tabs_vertical_width_declaration( $params ) {
		$raw = $params['attrValue'] ?? '';
		if ( is_array( $raw ) && isset( $raw['value'] ) ) {
			$raw = $raw['value'];
		}
		$attr = is_scalar( $raw ) ? trim( (string) $raw ) : '';
		if ( '' === $attr ) {
			return '';
		}

		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
				'important'  => array(
					'flex' => true,
				),
			)
		);

		$style_declarations->add( 'flex', "0 0 {$attr}" );

		return $style_declarations->value();
	}

	/**
	 * Vertical layout: pack tab stack along the column (top / center / bottom) via justify-content.
	 *
	 * Matches D4: `justify-content` on `.dsm-advanced-tabs-wrapper` when `flex-direction: column`.
	 *
	 * @param array<string, mixed> $params Declaration params including `attrValue` (top|center|bottom).
	 * @return string
	 */
	public static function tabs_vertical_alignment_declaration( $params ) {
		$attr = $params['attrValue'] ?? '';

		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
				'important'  => array(
					'justify-content' => true,
				),
			)
		);

		$align_value = '';
		switch ( $attr ) {
			case 'top':
				$align_value = 'flex-start';
				break;
			case 'center':
				$align_value = 'center';
				break;
			case 'bottom':
				$align_value = 'flex-end';
				break;
			default:
				$align_value = 'flex-start';
				break;
		}

		$style_declarations->add( 'justify-content', $align_value );

		return $style_declarations->value();
	}

	/**
	 * Render module style.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_styles( $args ) {
		$args            = \DiviSupreme\Includes\DsmDiviBuilderCssScope::normalize_module_styles_args( $args );
		$attrs           = $args['attrs'] ?? array();
		$elements        = $args['elements'];
		$dsm_tabs_sticky = $attrs['dsm_tabs_sticky']['innerContent']['desktop']['value'] ?? '';

		Style::add(
			array(
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => array(
					// Module.
					$elements->style(
						array(
							'attrName'   => 'module',
							'styleProps' => array(
								'disabledOn' => array(
									'disabledModuleVisibility' => $args['settings']['disabledModuleVisibility'] ?? null,
								),
							),
						)
					),

					CssStyle::style(
						array(
							'selector' => $args['orderClass'],
							'attr'     => $attrs['css'] ?? array(),
						)
					),

					$elements->style(
						array(
							'attrName' => 'tab_title',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_tabs_margin',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_tabs_padding',
						)
					),

					$elements->style(
						array(
							'attrName' => 'tab_style',
						)
					),

					$elements->style(
						array(
							'attrName' => 'active_tab_style',
						)
					),

					$elements->style(
						array(
							'attrName' => 'content_style',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_content_margin',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_content_padding',
						)
					),

					$elements->style(
						array(
							'attrName' => 'content_title',
						)
					),

					$elements->style(
						array(
							'attrName' => 'tab_content_text',
						)
					),

					$elements->style(
						array(
							'attrName' => 'tab_subtitle',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_tabs_wrapper_margin',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_tabs_wrapper_padding',
						)
					),

					$elements->style(
						array(
							'attrName' => 'tabs_wrapper_style',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_tabs_image_icon_margin',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_tabs_image_icon_padding',
						)
					),

					$elements->style(
						array(
							'attrName' => 'image_icon_style',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_content_image_icon_margin',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_content_image_icon_padding',
						)
					),

					$elements->style(
						array(
							'attrName' => 'button',
						)
					),

					$elements->style(
						array(
							'attrName' => 'content_image_icon_style',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-tab",
							'attr'     => $attrs['dsm_tabs_bg_color']['innerContent'] ?? array(),
							'property' => 'background',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-tab:hover",
							'attr'     => $attrs['tabs_background_color_hover']['innerContent'] ?? array(),
							'property' => 'background',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-tab.dsm-active",
							'attr'     => $attrs['dsm_tabs_active_bg_color']['innerContent'] ?? array(),
							'property' => 'background',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-tab.dsm-active:hover",
							'attr'     => $attrs['tabs_active_background_color_hover']['innerContent'] ?? array(),
							'property' => 'background',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-tab .dsm-title, {$args['orderClass']} .dsm-tab .dsm-title a",
							'attr'     => $attrs['dsm_tabs_text_color']['innerContent'] ?? array(),
							'property' => 'color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-tab-subtitle, {$args['orderClass']}.dsm-tab .dsm-tab-subtitle a",
							'attr'     => $attrs['dsm_tabs_subtitle_color']['innerContent'] ?? array(),
							'property' => 'color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-tab.dsm-active .dsm-tab-subtitle, {$args['orderClass']}.dsm-tab.dsm-active .dsm-tab-subtitle a",
							'attr'     => $attrs['dsm_tabs_active_subtitle_color']['innerContent'] ?? array(),
							'property' => 'color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-tab.dsm-active .dsm-title, {$args['orderClass']} .dsm-tab.dsm-active .dsm-title a, {$args['orderClass']} .dsm-tab.dsm-active .dsm-tab-subtitle, {$args['orderClass']} .dsm-tab.dsm-active .dsm-tab-subtitle a",
							'attr'     => $attrs['dsm_tabs_active_text_color']['innerContent'] ?? array(),
							'property' => 'color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-advanced-tabs-wrapper",
							'attr'     => $attrs['dsm_tabs_gap']['innerContent'] ?? array(),
							'property' => 'gap',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-content-wrapper",
							'attr'     => $attrs['dsm_content_bg_color']['innerContent'] ?? array(),
							'property' => 'background-color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-advanced-tabs-wrapper",
							'attr'     => $attrs['dsm_tabs_wrapper_bg_color']['innerContent'] ?? array(),
							'property' => 'background-color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-advanced-tabs-wrapper",
							'attr'     => $attrs['dsm_tabs_wrapper_width']['innerContent'] ?? array(),
							'property' => 'width',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-advanced-tabs-wrapper .dsm-icon-wrapper .et-pb-icon.dsm_icon, {$args['orderClass']} .dsm-advanced-tabs-wrapper .dsm-active-icon-wrapper .et-pb-icon.dsm-active-icon",
							'attr'     => $attrs['dsm_tabs_icon_size']['innerContent'] ?? array(),
							'property' => 'font-size',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-advanced-tabs-wrapper .dsm-icon-wrapper .et-pb-icon.dsm_icon",
							'attr'     => $attrs['dsm_tabs_icon_color']['innerContent'] ?? array(),
							'property' => 'color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-advanced-tabs-wrapper .dsm-tab.dsm-active .dsm-active-icon-wrapper .et-pb-icon.dsm-active-icon, {$args['orderClass']} .dsm-advanced-tabs-wrapper .dsm-tab.dsm-active .dsm-active-icon-wrapper .et-pb-icon.dsm-active-icon::before, {$args['orderClass']} .dsm-advanced-tabs-wrapper .dsm-tab.dsm-active .dsm-icon-wrapper .et-pb-icon.dsm_icon, {$args['orderClass']} .dsm-advanced-tabs-wrapper .dsm-tab.dsm-active .dsm-icon-wrapper .et-pb-icon.dsm_icon::before",
							'attr'     => $attrs['dsm_tabs_active_icon_color']['innerContent'] ?? array(),
							'property' => 'color',
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm-advanced-tabs-container.dsm-tabs-horizontal .dsm-advanced-tabs-wrapper",
							'attr'                => $attrs['dsm_tabs_wrapper_alignment']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'tab_wrapper_align_declaration' ),
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm-advanced-tabs-container.dsm-tabs-horizontal .dsm-advanced-tabs-content-wrapper",
							'attr'                => $attrs['dsm_tabs_horizontal_position']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'tab_horizontal_position_declaration' ),
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm-advanced-tabs-container.dsm-tabs-horizontal .dsm-advanced-tabs-wrapper",
							'attr'                => $attrs['dsm_tabs_horizontal_alignment']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'tabs_horizontal_alignment_declaration' ),
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm-advanced-tabs-container.dsm-tabs-vertical .dsm-advanced-tabs-wrapper",
							'attr'                => $attrs['dsm_tabs_wrapper_width']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'tabs_vertical_width_declaration' ),
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm-advanced-tabs-container.dsm-tabs-vertical .dsm-advanced-tabs-wrapper",
							'attr'                => $attrs['dsm_tabs_vertical_alignment']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'tabs_vertical_alignment_declaration' ),
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-advanced-tabs-wrapper .dsm-image",
							'attr'     => $attrs['dsm_tabs_image_width']['innerContent'] ?? array(),
							'property' => 'width',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-advanced-tabs-content-wrapper .dsm-image",
							'attr'     => $attrs['dsm_content_image_width']['innerContent'] ?? array(),
							'property' => 'width',
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm-content-wrapper.dsm-content-image.dsm-left .dsm-inner-content",
							'attr'                => $attrs['dsm_content_image_width']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'content_image_remaining_width_declaration' ),
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-content-wrapper .et-pb-icon.dsm_content_icon, {$args['orderClass']} .dsm-content-wrapper .dsm-icon",
							'attr'     => $attrs['dsm_content_icon_size']['innerContent'] ?? array(),
							'property' => 'font-size',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-content-wrapper .et-pb-icon.dsm_content_icon, {$args['orderClass']} .dsm-content-wrapper .dsm-icon",
							'attr'     => $attrs['dsm_content_icon_color']['innerContent'] ?? array(),
							'property' => 'color',
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm-content-wrapper .dsm-icon, {$args['orderClass']} .dsm-advanced-tabs-content-wrapper .dsm-image",
							'attr'                => $attrs['dsm_content_image_icon_alignment']['innerContent'] ?? array(),
							'declarationFunction' => function ( $params ) {
								$attr = $params['attrValue'] ?? array();

								$style_declarations = new StyleDeclarations(
									array(
										'returnType' => 'string',
										'important'  => array(
											'margin' => true,
										),
									)
								);

								if ( 'left' === $attr ) {
									$style_declarations->add( 'margin', 'auto 0 0 0' );
								}

								if ( 'center' === $attr ) {
									$style_declarations->add( 'margin', '0 auto' );
								}

								if ( 'right' === $attr ) {
									$style_declarations->add( 'margin', '0 0 0 auto' );
								}

								return $style_declarations->value();
							},
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm-tab",
							'attr'                => $attrs['dsm_tabs_image_icon_placement']['innerContent'] ?? array(),
							'declarationFunction' => function ( $params ) {
								$attr = $params['attrValue'] ?? array();

								$style_declarations = new StyleDeclarations(
									array(
										'returnType' => 'string',
										'important'  => array(
											'display' => true,
										),
									)
								);

								if ( 'top' !== $attr ) {
									$style_declarations->add( 'display', 'flex' );
									$style_declarations->add( 'align-items', 'center' );
								}

								return $style_declarations->value();
							},
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm-tab .dsm-icon-wrapper, {$args['orderClass']} .dsm-tab .dsm-image",
							'attr'                => $attrs['dsm_tabs_image_icon_placement']['innerContent'] ?? array(),
							'declarationFunction' => function ( $params ) {
								$attr = $params['attrValue'] ?? array();

								$style_declarations = new StyleDeclarations(
									array(
										'returnType' => 'string',
										'important'  => array(
											'order' => true,
										),
									)
								);

								if ( 'right' === $attr ) {
									$style_declarations->add( 'order', '1' );
								}

								return $style_declarations->value();
							},
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm-tabs-image-icon-top .dsm-tab .dsm-image, {$args['orderClass']} .dsm-tabs-image-icon-top .dsm-tab .dsm-icon-wrapper, {$args['orderClass']} .dsm-tabs-image-icon-top .dsm-tab .dsm-active-icon-wrapper",
							'attr'                => $attrs['dsm_tabs_image_alignment']['innerContent'] ?? array(),
							'declarationFunction' => function ( $params ) {
								$attr = $params['attrValue'] ?? '';

								if ( ! is_string( $attr ) || '' === $attr ) {
									return '';
								}

								$style_declarations = new StyleDeclarations(
									array(
										'returnType' => 'string',
										'important'  => array(
											'margin-left'  => true,
											'margin-right' => true,
										),
									)
								);

								if ( 'left' === $attr ) {
									$style_declarations->add( 'margin-left', '0' );
									$style_declarations->add( 'margin-right', 'auto' );
								}

								if ( 'center' === $attr ) {
									$style_declarations->add( 'margin-left', 'auto' );
									$style_declarations->add( 'margin-right', 'auto' );
								}

								if ( 'right' === $attr ) {
									$style_declarations->add( 'margin-left', 'auto' );
									$style_declarations->add( 'margin-right', '0' );
								}

								return $style_declarations->value();
							},
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm-tabs-image-icon-top .dsm-tab .dsm-icon-wrapper, {$args['orderClass']} .dsm-tabs-image-icon-top .dsm-tab .dsm-active-icon-wrapper",
							'attr'                => $attrs['dsm_tabs_image_alignment']['innerContent'] ?? array(),
							'declarationFunction' => function ( $params ) {
								$attr = $params['attrValue'] ?? '';

								if ( 'left' !== $attr && 'center' !== $attr && 'right' !== $attr ) {
									return '';
								}

								$style_declarations = new StyleDeclarations(
									array(
										'returnType' => 'string',
										'important'  => array(
											'width' => true,
										),
									)
								);

								$style_declarations->add( 'width', 'fit-content' );
								$style_declarations->add( 'max-width', '100%' );

								return $style_declarations->value();
							},
						)
					),

					'on' === $dsm_tabs_sticky ?
					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm-advanced-tabs-container .dsm-advanced-tabs-wrapper",
							'attr'                => $attrs['dsm_stick_tabs_offset']['innerContent'] ?? array(),
							'declarationFunction' => function ( $params ) {
								$attr = $params['attrValue'] ?? array();

								$style_declarations = new StyleDeclarations(
									array(
										'returnType' => 'string',
										'important'  => array(
											'position' => true,
										),
									)
								);

								$style_declarations->add( 'position', 'sticky' );
								$style_declarations->add( 'top', $attr );

								return $style_declarations->value();
							},
						)
					) : '',
				),
			)
		);
	}

	/**
	 * Render module script data.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_script_data( $args ) {
		$elements = $args['elements'];

		// Element Script Data Options.
		$elements->script_data(
			array(
				'attrName' => 'module',
			)
		);
	}

	/**
	 * Render module classnames.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_classnames( $args ) {
		$classnames_instance          = $args['classnamesInstance'];
		$attrs                        = $args['attrs'];
		$dsm_show_arrow               = $attrs['dsm_show_arrow']['innerContent']['desktop']['value'] ?? '';
		$dsm_tabs_layout              = $attrs['dsm_tabs_layout']['innerContent']['desktop']['value'] ?? '';
		$dsm_tabs_horizontal_position = $attrs['dsm_tabs_horizontal_position']['innerContent']['desktop']['value'] ?? '';
		$dsm_tabs_vertical_position   = $attrs['dsm_tabs_vertical_position']['innerContent']['desktop']['value'] ?? '';
		$dsm_tabs_column_position     = $attrs['dsm_tabs_column_position']['innerContent']['desktop']['value'] ?? '';
		if ( '' === $dsm_tabs_vertical_position ) {
			$dsm_tabs_vertical_position = 'left';
		}
		if ( '' === $dsm_tabs_column_position ) {
			$dsm_tabs_column_position = 'left';
		}

		// Module.
		$classnames_instance->add(
			ElementClassnames::classnames(
				array(
					'attrs' => $attrs['module']['decoration'] ?? array(),
				)
			)
		);

		if ( 'on' === $dsm_show_arrow && 'horizontal' === $dsm_tabs_layout && 'top' === $dsm_tabs_horizontal_position ) {
			$classnames_instance->add( 'dsm-show-arrow-active-top' );
		}

		if ( 'on' === $dsm_show_arrow && 'horizontal' === $dsm_tabs_layout && 'bottom' === $dsm_tabs_horizontal_position ) {
			$classnames_instance->add( 'dsm-show-arrow-active-bottom' );
		}

		if ( 'on' === $dsm_show_arrow && 'vertical' === $dsm_tabs_layout && 'left' === $dsm_tabs_vertical_position ) {
			$classnames_instance->add( 'dsm-show-arrow-active-left' );
		}

		if ( 'on' === $dsm_show_arrow && 'vertical' === $dsm_tabs_layout && 'right' === $dsm_tabs_vertical_position ) {
			$classnames_instance->add( 'dsm-show-arrow-active-right' );
		}

		if ( 'vertical' === $dsm_tabs_layout ) {
			$classnames_instance->add( "dsm-vertical-tabs-position-$dsm_tabs_vertical_position" );
		}

		if ( 'column' === $dsm_tabs_layout ) {
			$classnames_instance->add( "dsm-column-tabs-position-$dsm_tabs_column_position" );
		}

		// Mobile/Tablet stack order: matches edit.js + common.scss (VB often uses mode `frontend` for styles).
		$dsm_mtp_vertical = $attrs['dsm_tabs_mobile_tablet_vertical_pos']['innerContent']['desktop']['value'] ?? 'top';
		$dsm_mtp_column   = $attrs['dsm_tabs_mobile_tablet_column_pos']['innerContent']['desktop']['value'] ?? 'top';

		if ( 'vertical' === $dsm_tabs_layout ) {
			$classnames_instance->add(
				'dsm-mobile-tablet-vertical-pos-' . ( 'bottom' === $dsm_mtp_vertical ? 'bottom' : 'top' )
			);
		}

		if ( 'column' === $dsm_tabs_layout ) {
			$classnames_instance->add(
				'dsm-mobile-tablet-column-pos-' . ( 'bottom' === $dsm_mtp_column ? 'bottom' : 'top' )
			);
		}

		if ( ( 'on' === $dsm_show_arrow && 'vertical' === $dsm_tabs_layout ) || ( 'on' === $dsm_show_arrow && 'column' === $dsm_tabs_layout ) ) {
			$classnames_instance->add( 'dsm-show-arrow' );
		}

		$dsm_tabs_scroll_tablet_phone = $attrs['dsm_tabs_scroll_tablet_phone']['innerContent']['desktop']['value'] ?? '';
		if ( 'on' === $dsm_tabs_scroll_tablet_phone ) {
			$classnames_instance->add( 'dsm-tabs-scroll-tablet-phone' );
		}
	}

	/**
	 * Read a child module innerContent desktop value (TextContainer or RichText: plain string or `{ text: string }`).
	 *
	 * D4→D5 migration and TextContainer defaults sometimes store a scalar `value`; RichText uses `value.text`.
	 *
	 * @param array  $attrs Child module attrs.
	 * @param string $key Attribute key.
	 * @param string $fallback Fallback when empty.
	 * @return string
	 */
	private static function get_child_desktop_inner_text( array $attrs, string $key, string $fallback = '' ): string {
		if ( ! isset( $attrs[ $key ]['innerContent']['desktop']['value'] ) ) {
			return $fallback;
		}

		$raw = $attrs[ $key ]['innerContent']['desktop']['value'];

		if ( is_string( $raw ) || is_numeric( $raw ) ) {
			$out = trim( (string) $raw );

			return '' !== $out ? $out : $fallback;
		}

		if ( is_array( $raw ) && isset( $raw['text'] ) && is_string( $raw['text'] ) ) {
			$out = trim( $raw['text'] );

			return '' !== $out ? $out : $fallback;
		}

		return $fallback;
	}

	/**
	 * Read a child upload field raw `innerContent.desktop.value`.
	 *
	 * @param array  $attrs Child module attrs.
	 * @param string $key   Attribute key.
	 * @return mixed
	 */
	private static function get_child_upload_raw( array $attrs, string $key ) {
		return $attrs[ $key ]['innerContent']['desktop']['value'] ?? null;
	}

	/**
	 * Responsive tab/content `<img>` wrapped in `.dsm-image` (or custom wrapper class).
	 *
	 * @param array  $attrs          Child module attrs.
	 * @param string $key            Upload attribute key.
	 * @param string $wrapper_class  Wrapper div class(es).
	 * @return string Safe HTML (empty when no src).
	 */
	private static function render_child_upload_image_markup( array $attrs, string $key, string $wrapper_class = 'dsm-image' ): string {
		$raw = self::get_child_upload_raw( $attrs, $key );
		if ( '' === UploadImageMarkup::resolve_upload_src_string( $raw ) ) {
			return '';
		}

		$img = UploadImageMarkup::render_img_html(
			$raw,
			'',
			array(
				'decoding' => 'async',
			)
		);
		if ( '' === $img ) {
			return '';
		}

		return sprintf(
			'<div class="%1$s">%2$s</div>',
			esc_attr( $wrapper_class ),
			$img
		);
	}

	/**
	 * Content-panel image markup (plain or lightbox slot).
	 *
	 * @param array  $child_attrs              Child attrs.
	 * @param string $dsm_content_type         Content type slug.
	 * @param string $dsm_lightbox_image       Parent lightbox toggle.
	 * @param string $dsm_content_use_icon_image Child use image toggle.
	 * @param string $dsm_content_use_icon     Child use icon toggle.
	 * @param bool   $for_lightbox             When true, render lightbox-linked markup only.
	 * @return string
	 */
	private static function render_child_content_image_markup(
		array $child_attrs,
		string $dsm_content_type,
		string $dsm_lightbox_image,
		string $dsm_content_use_icon_image,
		string $dsm_content_use_icon,
		bool $for_lightbox
	): string {
		if ( 'content' !== $dsm_content_type || 'on' !== $dsm_content_use_icon_image || 'on' === $dsm_content_use_icon ) {
			return '';
		}
		if ( $for_lightbox && 'on' !== $dsm_lightbox_image ) {
			return '';
		}
		if ( ! $for_lightbox && 'on' === $dsm_lightbox_image ) {
			return '';
		}

		$raw = self::get_child_upload_raw( $child_attrs, 'dsm_content_image' );
		$url = UploadImageMarkup::resolve_upload_src_string( $raw );
		$img = UploadImageMarkup::render_img_html(
			$raw,
			'',
			array(
				'decoding' => 'async',
			)
		);
		if ( '' === $url || '' === $img ) {
			return '';
		}

		if ( $for_lightbox ) {
			return sprintf(
				'<div class="dsm-image"><a class="et_pb_lightbox_image dsm-image-lightbox" href="%1$s">%2$s</a></div>',
				esc_url( $url ),
				$img
			);
		}

		return sprintf( '<div class="dsm-image">%s</div>', $img );
	}

	/**
	 * Output child tab styles on the frontend.
	 *
	 * The parent renders tab/content markup directly, so Divi never invokes each child block's
	 * `stylesComponent`. When static CSS is enabled, {@see Module::render} also skips inline
	 * `module_styles` — child design (tab bg, fonts, spacing, etc.) must be registered here.
	 *
	 * @param array<string, mixed> $inner_blocks   Parsed inner blocks of the parent block.
	 * @param int|null             $store_instance BlockParserStore instance id.
	 * @param array<string, mixed> $parent_attrs   Parent module attrs.
	 * @return void
	 */
	private static function render_child_module_styles_for_frontend( array $inner_blocks, $store_instance, array $parent_attrs ): void {
		if ( empty( $inner_blocks ) ) {
			return;
		}

		$block_type = \WP_Block_Type_Registry::get_instance()->get_registered( 'dsm/advanced-tabs-child' );

		if ( $block_type instanceof \WP_Block_Type ) {
			$needs_prefix    = DsmDiviBuilderCssScope::needs_builder_css_prefix();
			$selector_prefix = $needs_prefix ? DsmDiviBuilderCssScope::SELECTOR_PREFIX : '';

			foreach ( $inner_blocks as $child ) {
				if ( ! is_array( $child ) ) {
					continue;
				}

				$child_id    = isset( $child['id'] ) && is_string( $child['id'] ) ? $child['id'] : '';
				$child_attrs = isset( $child['attrs'] ) && is_array( $child['attrs'] ) ? $child['attrs'] : array();
				$order_name  = '' !== $child_id
					? ModuleUtils::get_module_order_class_name( $child_id, $store_instance )
					: '';

				if ( '' === $order_name ) {
					$idx        = $child['orderIndex'] ?? 0;
					$order_name = 'dsm_advanced_tabs_child_' . ( is_scalar( $idx ) ? (string) $idx : '0' );
				}

				$base_order_class = '.' . $order_name;
				$order_class      = $needs_prefix ? $selector_prefix . $base_order_class : $base_order_class;

				$child_elements = new ModuleElements(
					array(
						'id'                  => $child_id,
						'name'                => 'dsm/advanced-tabs-child',
						'moduleAttrs'         => $child_attrs,
						'moduleMetadata'      => $block_type,
						'orderIndex'          => $child['orderIndex'] ?? 0,
						'storeInstance'       => $store_instance,
						'is_custom_post_type' => $needs_prefix,
					)
				);

				// ModuleElements does not set these in its constructor; Module::render normally
				// does. Required so styleProps.background (`{{baseSelector}}.dsm-content-wrapper`)
				// and other child decoration CSS resolve on the frontend.
				$child_elements->set_base_order_class( $base_order_class );
				$child_elements->set_order_class( $order_class );

				AdvancedTabsChild::module_styles(
					DsmDiviBuilderCssScope::normalize_module_styles_args(
						array(
							'id'                       => '' !== $child_id ? $child_id : $order_name,
							'name'                     => 'dsm/advanced-tabs-child',
							'orderIndex'               => $child['orderIndex'] ?? 0,
							'storeInstance'            => $store_instance,
							'elements'                 => $child_elements,
							'attrs'                    => $child_attrs,
							'parentAttrs'              => $parent_attrs,
							'orderClass'               => $order_class,
							'baseOrderClass'           => $base_order_class,
							'selectorPrefix'           => $selector_prefix,
							'isCustomPostType'         => $needs_prefix,
							'defaultPrintedStyleAttrs' => array(),
							'settings'                 => array(),
							'state'                    => 'value',
							'mode'                     => 'frontend',
							'styleGroup'               => 'module',
						)
					)
				);
			}
		}

		self::render_child_tab_font_icon_styles( $inner_blocks, $store_instance );
	}

	/**
	 * Output tab/content font-icon ::before CSS for each child on the frontend.
	 *
	 * When Divi static CSS is enabled, {@see Module::render} skips the child module `stylesComponent`,
	 * so glyph rules from {@see AdvancedTabsChild::module_styles} never run. The parent always renders
	 * the tab markup and can register the same `Style::add` rules here so icons match the Visual Builder.
	 *
	 * @param array    $inner_blocks   Parsed inner blocks of the parent block.
	 * @param int|null $store_instance BlockParserStore instance id.
	 * @return void
	 */
	private static function render_child_tab_font_icon_styles( array $inner_blocks, $store_instance ): void {
		foreach ( $inner_blocks as $child ) {
			if ( ! is_array( $child ) ) {
				continue;
			}

			$child_id    = isset( $child['id'] ) && is_string( $child['id'] ) ? $child['id'] : '';
			$child_attrs = isset( $child['attrs'] ) && is_array( $child['attrs'] ) ? $child['attrs'] : array();

			$order_name = '' !== $child_id
				? ModuleUtils::get_module_order_class_name( $child_id, $store_instance )
				: '';

			if ( '' === $order_name ) {
				$idx        = $child['orderIndex'] ?? '';
				$order_name = 'dsm_advanced_tabs_child_' . ( is_scalar( $idx ) ? (string) $idx : '0' );
			}

			$order_class = '.' . $order_name;

			Style::add(
				array(
					'id'            => '' !== $child_id ? $child_id : $order_name,
					'name'          => 'dsm/advanced-tabs-child',
					'orderIndex'    => $child['orderIndex'] ?? 0,
					'storeInstance' => $store_instance,
					'styles'        => array(
						CommonStyle::style(
							array(
								'selector'            => "{$order_class}.dsm-tab .dsm-icon-wrapper .et-pb-icon.dsm_icon::before",
								'attr'                => $child_attrs['font_icon']['innerContent'] ?? array(),
								'declarationFunction' => array( AdvancedTabsChild::class, 'tab_icon_style_declaration' ),
							)
						),
						CommonStyle::style(
							array(
								'selector'            => "{$order_class}.dsm-tab.dsm-active .dsm-active-icon-wrapper .et-pb-icon.dsm-active-icon::before",
								'attr'                => $child_attrs['font_icon_active']['innerContent'] ?? array(),
								'declarationFunction' => array( AdvancedTabsChild::class, 'tab_active_icon_style_declaration' ),
							)
						),
						CommonStyle::style(
							array(
								'selector'            => "{$order_class} .dsm-inner-content-wrapper .dsm-icon .et-pb-icon.dsm_content_icon::before",
								'attr'                => $child_attrs['dsm_content_font_icon']['innerContent'] ?? array(),
								'declarationFunction' => array( AdvancedTabsChild::class, 'tab_content_icon_style_declaration' ),
							)
						),
					),
				)
			);
		}
	}

	/**
	 * Render Divi background style components for a tab child panel.
	 *
	 * Mounted as direct children of `.dsm-content-wrapper` so mask / pattern /
	 * parallax selectors (`> .et_pb_background_*`) match the full content panel.
	 *
	 * @param array<string, mixed> $child          Child parsed block.
	 * @param int|null             $store_instance Block parser store instance.
	 * @return string
	 */
	private static function render_child_background_style_components( array $child, $store_instance ): string {
		$block_type = \WP_Block_Type_Registry::get_instance()->get_registered( 'dsm/advanced-tabs-child' );

		if ( ! $block_type instanceof \WP_Block_Type ) {
			return '';
		}

		$child_id    = isset( $child['id'] ) && is_string( $child['id'] ) ? $child['id'] : '';
		$child_attrs = isset( $child['attrs'] ) && is_array( $child['attrs'] ) ? $child['attrs'] : array();

		if ( empty( $child_attrs['module']['decoration']['background'] ) ) {
			return '';
		}

		$needs_prefix = DsmDiviBuilderCssScope::needs_builder_css_prefix();

		$child_elements = new ModuleElements(
			array(
				'id'                  => $child_id,
				'name'                => 'dsm/advanced-tabs-child',
				'moduleAttrs'         => $child_attrs,
				'moduleMetadata'      => $block_type,
				'orderIndex'          => $child['orderIndex'] ?? 0,
				'storeInstance'       => $store_instance,
				'is_custom_post_type' => $needs_prefix,
			)
		);

		$components = $child_elements->style_components(
			array(
				'attrName' => 'module',
			)
		);

		return is_string( $components ) ? $components : '';
	}

	/**
	 * Render nested Elements (inner blocks) for a tab child parsed block.
	 *
	 * Prefers HTML stashed when WordPress rendered the child. The fallback renders
	 * inner blocks when that first pass did not run.
	 *
	 * @param array<string, mixed> $parsed_block   Child parsed block.
	 * @param int|null             $store_instance Block parser store instance.
	 * @return string
	 */
	private static function render_child_nested_modules_content( array $parsed_block, ?int $store_instance ): string {
		$key = (string) $store_instance . '|' . (string) ( $parsed_block['id'] ?? '' );

		if ( array_key_exists( $key, self::$rendered_child_content ) ) {
			$html = self::$rendered_child_content[ $key ];
			unset( self::$rendered_child_content[ $key ] );

			return $html;
		}

		$inner_blocks = $parsed_block['innerBlocks'] ?? array();
		if ( empty( $inner_blocks ) ) {
			return '';
		}

		$html = '';
		foreach ( $inner_blocks as $inner_block ) {
			if ( null !== $store_instance ) {
				$inner_block['storeInstance'] = $store_instance;
			}
			$html .= ( new \WP_Block( $inner_block ) )->render();
		}

		return $html;
	}

	/**
	 * Pixel max of the enabled Divi breakpoint immediately below desktop.
	 *
	 * Default sites return the tablet max (980). A custom tablet width, or an
	 * enabled wider breakpoint such as Tablet Wide, replaces that number.
	 * Desktop then starts one pixel above this value.
	 *
	 * @return int
	 */
	public static function scroll_below_desktop_max_px(): int {
		$max = 980;

		if ( class_exists( '\ET\Builder\Framework\Breakpoint\Breakpoint' ) ) {
			$enabled = \ET\Builder\Framework\Breakpoint\Breakpoint::get_enabled_breakpoints();
			if ( is_array( $enabled ) ) {
				$desktop_index = null;
				foreach ( $enabled as $index => $breakpoint ) {
					if ( is_array( $breakpoint ) && 'desktop' === ( $breakpoint['name'] ?? '' ) ) {
						$desktop_index = $index;
						break;
					}
				}
				$below = ( null !== $desktop_index && isset( $enabled[ $desktop_index + 1 ] ) )
					? $enabled[ $desktop_index + 1 ]
					: null;
				if ( is_array( $below ) ) {
					$raw    = $below['maxWidth']['value'] ?? '';
					$parsed = (int) preg_replace( '/\D+/', '', (string) $raw );
					if ( $parsed > 0 ) {
						$max = $parsed;
					}
				}
			}
		}

		/**
		 * Filter the max-width used by the Advanced Tabs scroll strip.
		 *
		 * @param int $max Pixel width of the enabled breakpoint below desktop.
		 */
		$filtered = apply_filters( 'dsm_advanced_tabs_scroll_max_width', $max );
		$filtered = is_numeric( $filtered ) ? (int) $filtered : $max;

		return $filtered > 0 ? $filtered : 980;
	}

	/**
	 * Scroll-strip CSS for the saved Divi breakpoint below desktop.
	 *
	 * Keep selectors aligned with `ensureAdvancedTabsScrollStyle` in `edit.js`.
	 *
	 * @param int $max_width Breakpoint max in pixels.
	 * @return string
	 */
	public static function scroll_breakpoint_css( int $max_width ): string {
		$max_width = max( 1, $max_width );

		return '@media (max-width: ' . $max_width . 'px) {'
			. '.dsm_advanced_tabs.dsm-tabs-scroll-tablet-phone{min-width:0;max-width:100%;}'
			. '.dsm_advanced_tabs.dsm-tabs-scroll-tablet-phone .dsm-advanced-tabs-wrapper{'
			. 'display:flex;flex-direction:row;flex-wrap:nowrap;width:100%;min-width:0;max-width:100%;'
			. 'overflow-x:auto;overflow-y:hidden;-webkit-overflow-scrolling:touch;'
			. 'overscroll-behavior-x:contain;touch-action:pan-x pan-y;'
			. 'scrollbar-width:none;-ms-overflow-style:none;}'
			. '.dsm_advanced_tabs.dsm-tabs-scroll-tablet-phone .dsm-advanced-tabs-wrapper::-webkit-scrollbar{'
			. 'width:0;height:0;}'
			. '.dsm_advanced_tabs.dsm-tabs-scroll-tablet-phone .dsm-advanced-tabs-container .dsm-advanced-tabs-wrapper>.dsm-tab{'
			. 'flex:0 0 auto;max-width:none;white-space:nowrap;}'
			. '.dsm_advanced_tabs.dsm-tabs-scroll-tablet-phone.dsm-show-arrow-active-top .dsm-advanced-tabs-wrapper{padding-bottom:20px;}'
			. '.dsm_advanced_tabs.dsm-tabs-scroll-tablet-phone.dsm-show-arrow-active-top .dsm-tabs-horizontal .dsm-tab.dsm-active::before{z-index:1;}'
			. '.dsm_advanced_tabs.dsm-tabs-scroll-tablet-phone.dsm-show-arrow-active-bottom .dsm-advanced-tabs-wrapper{padding-top:20px;}'
			. '}';
	}

	/**
	 * Print the scroll-strip media query and pass the same width to the frontend script.
	 *
	 * @return void
	 */
	public static function enqueue_scroll_breakpoint_style(): void {
		static $added = false;

		if ( $added ) {
			return;
		}
		$added = true;

		$max    = self::scroll_below_desktop_max_px();
		$handle = 'dsm-advanced-tabs-scroll';
		$deps   = array();
		foreach ( array( 'dsm-frontend-advanced-tabs', 'dsm-supreme-modules-style' ) as $candidate ) {
			if ( wp_style_is( $candidate, 'registered' ) ) {
				$deps[] = $candidate;
				break;
			}
		}

		if ( ! wp_style_is( $handle, 'registered' ) ) {
			wp_register_style(
				$handle,
				false,
				$deps,
				defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : false
			);
		}
		wp_enqueue_style( $handle );
		wp_add_inline_style( $handle, self::scroll_breakpoint_css( $max ) );

		if ( wp_script_is( 'dsm-advanced-tabs', 'registered' ) ) {
			wp_localize_script(
				'dsm-advanced-tabs',
				'dsmAdvancedTabsData',
				array(
					'scrollMaxWidth' => $max,
				)
			);
		}
	}

	/**
	 * Render module HTML output.
	 *
	 * @param array     $attrs - Modules Attributes.
	 * @param string    $content - Content.
	 * @param \WP_Block $block - Block.
	 * @param mixed     $elements - Elements.
	 */
	public static function render_callback( $attrs, $content, $block, $elements ) {

		$children_ids = $block->parsed_block['innerBlocks'] ? array_map(
			function ( $inner_block ) {
				return $inner_block['id'];
			},
			$block->parsed_block['innerBlocks']
		) : array();

		$parent       = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );
		$parent_attrs = $parent->attrs ?? array();

		$dsm_tabs_horizontal_position  = $attrs['dsm_tabs_horizontal_position']['innerContent']['desktop']['value'] ?? '';
		$dsm_tabs_trigger              = $attrs['dsm_tabs_trigger']['innerContent']['desktop']['value'] ?? '';
		$dsm_content_animation         = $attrs['dsm_content_animation']['innerContent']['desktop']['value'] ?? '';
		$dsm_inner_content_animation   = $attrs['dsm_inner_content_animation']['innerContent']['desktop']['value'] ?? '';
		$dsm_deep_link                 = $attrs['dsm_deep_link']['innerContent']['desktop']['value'] ?? '';
		$dsm_lightbox_image            = $attrs['dsm_lightbox_image']['innerContent']['desktop']['value'] ?? '';
		$dsm_auto_scroll_mobile        = $attrs['dsm_auto_scroll_mobile']['innerContent']['desktop']['value'] ?? '';
		$dsm_anchor_scroll             = $attrs['dsm_anchor_scroll']['innerContent']['desktop']['value'] ?? '';
		$dsm_tabs_layout               = $attrs['dsm_tabs_layout']['innerContent']['desktop']['value'] ?? '';
		$dsm_tabs_image_icon_placement = $attrs['dsm_tabs_image_icon_placement']['innerContent']['desktop']['value'] ?? 'top';

		wp_enqueue_script( 'dsm-advanced-tabs' );
		self::enqueue_scroll_breakpoint_style();
		if (
			( '' !== $dsm_content_animation && 'none' !== $dsm_content_animation )
			|| ( '' !== $dsm_inner_content_animation && 'none' !== $dsm_inner_content_animation )
		) {
			DsmFrontendDynamicAssets::enqueue_supreme_animate_if_needed( true );
		}

		// InnerBlocks ko access karna.
		$inner_blocks = $block->parsed_block['innerBlocks'] ?? array();

		$advanced_tabs_button  = '';
		$advanced_tabs_content = '';

		$tabs_aria_label = isset( $attrs['dsm_aria_label']['innerContent']['desktop']['value'] )
			? trim( (string) $attrs['dsm_aria_label']['innerContent']['desktop']['value'] )
			: '';

		$tablist_attrs = 'role="tablist"';
		if ( '' !== $tabs_aria_label ) {
			$tablist_attrs .= sprintf( ' aria-label="%s"', esc_attr( $tabs_aria_label ) );
		} else {
			$tablist_attrs .= sprintf( ' aria-label="%s"', esc_attr__( 'Tabs', 'dsm-supreme-modules-pro-for-divi' ) );
		}
		if ( 'vertical' === $dsm_tabs_layout || 'column' === $dsm_tabs_layout ) {
			$tablist_attrs .= ' aria-orientation="vertical"';
		} else {
			$tablist_attrs .= ' aria-orientation="horizontal"';
		}

		// Sequential index among tabs that actually render (first active + aria).
		// BlockParser duplicates loop-enabled children before this callback; empty
		// queries leave a single child marked `__loop_no_results` (see LoopUtils).
		$rendered_tab_index = 0;

		foreach ( $inner_blocks as $index => $child ) {
			$child_attrs = isset( $child['attrs'] ) && is_array( $child['attrs'] ) ? $child['attrs'] : array();

			// Skip Loop "no results" placeholders — child Module::render would return '',
			// but this parent synthesizes nav + panels from attrs (Chart / Tabs pattern).
			if ( ! empty( $child_attrs['__loop_no_results'] ) ) {
				continue;
			}

			// Har tab ke liye unique ID banayein.
			$unique_id_index = uniqid();

			$child_order_class      = $child['orderIndex'] ?? '';
			$child_order_class_name = isset( $child['id'] ) && is_string( $child['id'] )
				? ModuleUtils::get_module_order_class_name( $child['id'], $block->parsed_block['storeInstance'] ?? null )
				: '';

			if ( '' === $child_order_class_name ) {
				$child_order_class_name = 'dsm_advanced_tabs_child_' . ( is_scalar( $child_order_class ) ? (string) $child_order_class : (string) $index );
			}

			// Tab title: VB shows "Tab Title" via `defaultAttr` / WithDynamicValues when the value is absent.
			// Saved JSON often omits keys that match schema default; use the same effective default on FE only
			// when the attr is missing — if the user clears the title, innerContent exists with empty text.
			$dsm_title = self::get_child_desktop_inner_text( $child_attrs, 'dsm_title', '' );
			if ( '' === $dsm_title && ! isset( $child_attrs['dsm_title']['innerContent']['desktop']['value'] ) ) {
				$dsm_title = 'Tab Title';
			}
			$dsm_subtitle                = self::get_child_desktop_inner_text( $child_attrs, 'dsm_subtitle', '' );
			$dsm_use_icon_image          = $child_attrs['dsm_use_icon_image']['innerContent']['desktop']['value'] ?? '';
			$dsm_use_icon                = $child_attrs['dsm_use_icon']['innerContent']['desktop']['value'] ?? '';
			$dsm_use_icon_active         = $child_attrs['dsm_use_icon_active']['innerContent']['desktop']['value'] ?? '';
			$dsm_use_icon_image_active   = $child_attrs['dsm_use_icon_image_active']['innerContent']['desktop']['value'] ?? 'off';
			$tab_image_markup            = ( 'on' === $dsm_use_icon_image && 'on' !== $dsm_use_icon )
				? self::render_child_upload_image_markup( $child_attrs, 'dsm_image' )
				: '';
			$tab_active_image_markup     = ( 'on' === $dsm_use_icon_image_active && 'on' !== $dsm_use_icon_active )
				? self::render_child_upload_image_markup( $child_attrs, 'dsm_image_active', 'dsm-image dsm-image-active' )
				: '';
			$dsm_title_url               = $child_attrs['dsm_title_url']['innerContent']['desktop']['value'] ?? '';
			$dsm_title_url_new_window    = $child_attrs['dsm_title_url_new_window']['innerContent']['desktop']['value'] ?? '';
			$dsm_subtitle_url            = $child_attrs['dsm_subtitle_url']['innerContent']['desktop']['value'] ?? '';
			$dsm_subtitle_url_new_window = $child_attrs['dsm_subtitle_url_new_window']['innerContent']['desktop']['value'] ?? '';

			$tab_font_icon_settings        = is_array( $child_attrs['font_icon']['innerContent']['desktop']['value'] ?? null )
				? $child_attrs['font_icon']['innerContent']['desktop']['value']
				: null;
			$tab_active_font_icon_settings = is_array( $child_attrs['font_icon_active']['innerContent']['desktop']['value'] ?? null )
				? $child_attrs['font_icon_active']['innerContent']['desktop']['value']
				: null;

			$tab_icon_markup = 'on' === $dsm_use_icon_image && 'on' === $dsm_use_icon
				? sprintf(
					'<div class="dsm-icon-wrapper">%s</div>',
					IconModuleRenderBridge::render_icon_host_markup( $tab_font_icon_settings, array( 'dsm_icon' ) )
				)
				: '';

			$tab_active_icon_markup = 'on' === $dsm_use_icon_image_active && 'on' === $dsm_use_icon_active
				? sprintf(
					'<div class="dsm-active-icon-wrapper">%s</div>',
					IconModuleRenderBridge::render_icon_host_markup( $tab_active_font_icon_settings, array( 'dsm-active-icon' ) )
				)
				: '';

			$is_first_tab       = ( 0 === $rendered_tab_index );
			$aria_selected      = $is_first_tab ? 'true' : 'false';
			$tab_index          = $is_first_tab ? '0' : '-1';
			$panel_hidden       = $is_first_tab ? '' : ' hidden';
			$tab_active_class   = $is_first_tab ? ' dsm-active' : '';
			$panel_active_class = $is_first_tab ? ' dsm-active' : '';
			++$rendered_tab_index;

			$child_nested_modules_content = self::render_child_nested_modules_content(
				$child,
				$block->parsed_block['storeInstance'] ?? null
			);
			$has_nested_modules           = '' !== trim( $child_nested_modules_content );
			$layout_display_value         = $child_attrs['module']['decoration']['layout']['desktop']['value']['display'] ?? 'flex';
			$nestable_classes             = HTMLUtility::classnames(
				'dsm-tabs-nestable',
				array(
					'et_flex_module' => 'flex' === $layout_display_value,
					'et_grid_module' => 'grid' === $layout_display_value,
				)
			);

			// Advanced Tabs Button.
			$advanced_tabs_button .= sprintf(
				'<div id="dsm-tab-%2$s" role="tab" aria-selected="%11$s" aria-controls="dsm-panel-%2$s" tabindex="%12$s" class="%1$s dsm-tab%13$s" data-tabid="%2$s">
					%5$s
					%7$s
					%6$s
					%10$s
					<div class="dsm-title-wrapper">
						%8$s
					    %3$s
						%4$s
						%9$s
					</div>
				</div>',
				esc_attr( $child_order_class_name ),
				esc_attr( $unique_id_index ),
				'' !== $dsm_title && '' === trim( $dsm_title_url ) ? sprintf( '<div class="dsm-title">%1$s</div>', esc_html( $dsm_title ) ) : '',
				'' !== $dsm_subtitle && '' === trim( $dsm_subtitle_url ) ? sprintf( '<div class="dsm-tab-subtitle">%1$s</div>', esc_html( $dsm_subtitle ) ) : '',
				$tab_image_markup,
				$tab_icon_markup,
				$tab_active_image_markup,
				'' !== $dsm_title && '' !== trim( $dsm_title_url ) ? sprintf( '<div class="dsm-title"><a href="%2$s" %3$s>%1$s</a></div>', esc_html( $dsm_title ), esc_url( $dsm_title_url ), 'on' === $dsm_title_url_new_window ? 'target="_blank" rel="noopener noreferrer" ' : '' ) : '',
				'' !== $dsm_subtitle && '' !== trim( $dsm_subtitle_url ) ? sprintf( '<div class="dsm-tab-subtitle"><a href="%2$s" %3$s>%1$s</a></div>', esc_html( $dsm_subtitle ), esc_url( $dsm_subtitle_url ), 'on' === $dsm_subtitle_url_new_window ? 'target="_blank" rel="noopener noreferrer"' : '' ) : '',
				$tab_active_icon_markup,
				esc_attr( $aria_selected ),
				esc_attr( $tab_index ),
				esc_attr( $tab_active_class ),
			);

			// Advanced Tabs Content.
			$child_attrs = isset( $child['attrs'] ) && is_array( $child['attrs'] ) ? $child['attrs'] : array();

			$dsm_content_title                = self::get_child_desktop_inner_text( $child_attrs, 'dsm_content_title', '' );
			$dsm_content                      = self::get_child_desktop_inner_text( $child_attrs, 'dsm_content', '' );
			$dsm_content_type                 = $child_attrs['dsm_content_type']['innerContent']['desktop']['value'] ?? 'content';
			$dsm_content_use_icon_image       = $child_attrs['dsm_content_use_icon_image']['innerContent']['desktop']['value'] ?? '';
			$dsm_content_use_icon             = $child_attrs['dsm_content_use_icon']['innerContent']['desktop']['value'] ?? '';
			$content_image_lightbox_markup    = self::render_child_content_image_markup(
				$child_attrs,
				(string) $dsm_content_type,
				(string) $dsm_lightbox_image,
				(string) $dsm_content_use_icon_image,
				(string) $dsm_content_use_icon,
				true
			);
			$content_image_plain_markup       = self::render_child_content_image_markup(
				$child_attrs,
				(string) $dsm_content_type,
				(string) $dsm_lightbox_image,
				(string) $dsm_content_use_icon_image,
				(string) $dsm_content_use_icon,
				false
			);
			$content_font_icon_settings       = is_array( $child_attrs['dsm_content_font_icon']['innerContent']['desktop']['value'] ?? null )
				? $child_attrs['dsm_content_font_icon']['innerContent']['desktop']['value']
				: null;
			$content_icon_markup              = 'content' === $dsm_content_type && 'on' === $dsm_content_use_icon_image && 'on' === $dsm_content_use_icon
				? sprintf(
					'<div class="dsm-icon">%s</div>',
					IconModuleRenderBridge::render_icon_host_markup( $content_font_icon_settings, array( 'dsm_content_icon' ) )
				)
				: '';
			$dsm_content_image_icon_placement = $child_attrs['dsm_content_image_icon_placement']['innerContent']['desktop']['value'] ?? 'top';
			$has_content_image                = (
				'content' === $dsm_content_type
				&& 'on' === $dsm_content_use_icon_image
				&& 'on' !== $dsm_content_use_icon
				&& (
					'' !== $content_image_plain_markup
					|| '' !== $content_image_lightbox_markup
				)
			);
			$content_image_panel_class        = '';
			if ( $has_content_image ) {
				$placement_slug = sanitize_html_class( (string) $dsm_content_image_icon_placement );
				if ( '' === $placement_slug ) {
					$placement_slug = 'top';
				}
				$content_image_panel_class = ' dsm-content-image dsm-' . $placement_slug;
			}
			$shortcode_content          = self::get_child_desktop_inner_text( $child_attrs, 'shortcode_content', '' );
			$dsm_content_library_layout = $child_attrs['dsm_content_library_layout']['innerContent']['desktop']['value'] ?? '';
			$button_text                = $child_attrs['button_text']['innerContent']['desktop']['value'] ?? '';
			$button_url                 = $child_attrs['button_url']['innerContent']['desktop']['value'] ?? '';
			$url_new_window             = $child_attrs['url_new_window']['innerContent']['desktop']['value'] ?? '';

			$content_value = '';
			switch ( $dsm_content_type ) {
				case 'shortcode':
					$content_value = DiviLibraryLayoutRenderer::render_shortcode_field_content(
						is_string( $shortcode_content ) ? $shortcode_content : '',
						'dsm_advanced_tabs_shortcode_styles'
					);
					break;
				case 'library':
					$library_id    = DiviLibraryLayoutRenderer::normalize_post_id( $dsm_content_library_layout );
					$content_value = DiviLibraryLayoutRenderer::render_layout( $library_id, 'dsm_advanced_tabs_library_styles' );
					break;
			}

			$button_markup = sprintf(
				'<div class="et_pb_button_module_wrapper">
				  <a %2$s %3$s class="et_pb_button">%1$s</a>
				</div>',
				$button_text,
				'' !== $button_url ? sprintf( 'href="%1$s" ', esc_url( $button_url ) ) : '',
				'on' === $url_new_window ? 'target="_blank" rel="noopener noreferrer" ' : ''
			);

			// Content-type body: run shortcodes so migrated HTML that still contains `[shortcode]` tags renders (D4 shortcode mode used `do_shortcode`; migrated layouts may keep shortcodes in `dsm_content` while type stays `content`).
			$dsm_content_output = $dsm_content;
			if ( 'content' === $dsm_content_type && '' !== $dsm_content_output ) {
				$dsm_content_output = do_shortcode( $dsm_content_output );
			}

			$custom_content = sprintf(
				'%1$s
				 %2$s
				 %3$s',
				'' !== $dsm_content_title ? sprintf( '<h2 class="dsm-title">%1$s</h2>', esc_html( $dsm_content_title ) ) : '',
				'' !== $dsm_content ? sprintf( '<div class="dsm-content">%1$s</div>', $dsm_content_output ) : '',
				'' !== $button_text ? $button_markup : ''
			);

			$inner_content_html = '';
			if ( $has_nested_modules ) {
				$nested_markup = sprintf(
					'<div class="%1$s">%2$s</div>',
					esc_attr( $nestable_classes ),
					et_core_esc_previously( $child_nested_modules_content )
				);
				if ( 'content' === $dsm_content_type ) {
					// Match VB AdvancedTabsContent: title → description → nestable → button.
					$inner_content_html = sprintf(
						'%1$s%2$s%3$s%4$s',
						'' !== $dsm_content_title ? sprintf( '<h2 class="dsm-title">%1$s</h2>', esc_html( $dsm_content_title ) ) : '',
						'' !== $dsm_content ? sprintf( '<div class="dsm-content">%1$s</div>', $dsm_content_output ) : '',
						$nested_markup,
						'' !== $button_text ? $button_markup : ''
					);
				} else {
					$inner_content_html = $nested_markup;
				}
			} elseif ( 'content' === $dsm_content_type ) {
				$inner_content_html = $custom_content;
			} else {
				$inner_content_html = $content_value;
			}

			// Background mask/pattern/parallax must be direct children of the panel
			// (styleProps.background → `.dsm-content-wrapper`); nestable-only Module::render
			// cannot host them for the full content surface.
			$child_background_components = self::render_child_background_style_components(
				$child,
				$block->parsed_block['storeInstance'] ?? null
			);

			$advanced_tabs_content .= sprintf(
				'<div id="dsm-panel-%2$s" role="tabpanel"%6$s class="dsm-content-wrapper %1$s animated%7$s%10$s" aria-labelledby="dsm-tab-%2$s" data-contentid="%2$s">
				  %9$s
				  <div class="dsm-inner-content-wrapper">
				    %5$s
				    %4$s
				    %3$s
				  <div class="dsm-inner-content">
					 %8$s
				   </div>
				  </div>
				</div>',
				esc_attr( $child_order_class_name ),
				esc_attr( $unique_id_index ),
				$content_image_plain_markup,
				$content_icon_markup,
				$content_image_lightbox_markup,
				esc_attr( $panel_hidden ),
				esc_attr( $panel_active_class ),
				et_core_esc_previously( $inner_content_html ),
				et_core_esc_previously( $child_background_components ),
				esc_attr( $content_image_panel_class ),
			);
		}

		$container = sprintf(
			'<div class="dsm-advanced-tabs-container %10$s" data-trigger="%1$s" data-animation="%2$s" data-inner_animation="%3$s" data-deep_link="%4$s" data-image_lightbox="%5$s" data-auto_scroll_mobile="%6$s" data-anchor_link="%7$s">
			  <div class="dsm-advanced-tabs-wrapper" %11$s>%8$s</div>
			  <div class="dsm-advanced-tabs-content-wrapper">%9$s</div>
			</div>',
			$dsm_tabs_trigger,
			$dsm_content_animation,
			$dsm_inner_content_animation,
			$dsm_deep_link,
			$dsm_lightbox_image,
			$dsm_auto_scroll_mobile,
			$dsm_anchor_scroll,
			$advanced_tabs_button,
			$advanced_tabs_content,
			trim(
				( $dsm_tabs_layout ? sprintf( 'dsm-tabs-%1$s', $dsm_tabs_layout ) : '' )
				. ( 'top' === $dsm_tabs_image_icon_placement ? ' dsm-tabs-image-icon-top' : '' )
			),
			$tablist_attrs
		);

		self::render_child_module_styles_for_frontend( $inner_blocks, $block->parsed_block['storeInstance'] ?? null, $attrs );

		// Module Inner.
		// Essentially, this is the module content.
		// Were wrapping the title and content in a div with class `et_pb_module_inner`.
		$module_inner = HTMLUtility::render(
			array(
				'tag'               => 'div',
				'attributes'        => array(
					'class' => 'et_pb_module_inner',
				),
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $container,
			)
		);

		// This are the module elements that will be rendered in the frontend.
		$module_elements = $elements->style_components(
			array(
				'attrName' => 'module',
			)
		);

		// This are the children of the module container, which are the module elements and the module inner.
		$module_container_children = $module_elements . $module_inner;

		return Module::render(
			array(
				// FE only.
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],

				// VB equivalent.
				'attrs'               => $attrs,
				'parentAttrs'         => $parent_attrs,
				'elements'            => $elements,
				'id'                  => $block->parsed_block['id'],
				'moduleClassName'     => '',
				'name'                => $block->block_type->name,
				'classnamesFunction'  => array( self::class, 'module_classnames' ),
				'moduleCategory'      => $block->block_type->category,
				'stylesComponent'     => array( self::class, 'module_styles' ),
				'scriptDataComponent' => array( self::class, 'module_script_data' ),
				'children'            => ElementComponents::component(
					array(
						'attrs'         => $attrs['module']['decoration'] ?? array(),
						'id'            => $block->parsed_block['id'],

						// FE only.
						'orderIndex'    => $block->parsed_block['orderIndex'],
						'storeInstance' => $block->parsed_block['storeInstance'],
					)
				) . $module_container_children,
				'childrenIds'         => $children_ids,
			)
		);
	}
}
