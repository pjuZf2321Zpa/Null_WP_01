<?php
/**
 * Circle Info Child Module.
 *
 * @package DiviSupreme.
 */

declare(strict_types=1);

namespace DiviSupreme\Modules;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\Module\Options\Element\ElementClassnames;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use ET\Builder\Packages\Module\Options\Text\TextStyle;
use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;
use DiviSupreme\Includes\Divi5Conversion\ConversionAttrs;
use DiviSupreme\Extensions\IconLibraries\LegacyModuleIconStyles;


/**
 * Class that handles "CircleInfoChild Module" module.
 */
class CircleInfoChild implements DependencyInterface {



	/**
	 * Register module.
	 * `DependencyInterface` interface ensures class method name `load()` is executed for initialization.
	 */
	public function load() {
		add_action( 'init', array( self::class, 'register_module' ) );
	}

	/**
	 * Initilises the module.
	 *
	 * @return void
	 */
	public static function dsm_initialise() {
		add_action(
			'divi_module_library_modules_dependency_tree',
			function ( $dependency_tree ) {
				$dependency_tree->add_dependency( new self() );
			}
		);
	}

	/**
	 * Register module.
	 */
	public static function register_module() {

		$module_json_path = DSM_DIR_PATH . 'divi-5/public/packages/module-library/circle-info-child';

		ModuleRegistration::register_module(
			$module_json_path,
			array(
				'render_callback' => array( self::class, 'render_callback' ),
			)
		);
	}

	/**
	 * Content icon style declaration.
	 *
	 * @param mixed $params Params.
	 */
	public static function content_icon_style_declaration( $params ) {
		return LegacyModuleIconStyles::build_pseudo_icon_declaration( $params );
	}

	/**
	 * Circle icon style declaration.
	 *
	 * @param mixed $params Params.
	 */
	public static function circle_icon_style_declaration( $params ) {
		return LegacyModuleIconStyles::build_pseudo_icon_declaration( $params );
	}

	/**
	 * Render module style.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_styles( $args ) {
		$args        = \DiviSupreme\Includes\DsmDiviBuilderCssScope::normalize_module_styles_args( $args );
		$order_class = (string) ( $args['orderClass'] ?? '' );
		$sc          = static function ( string $parent_chain, string $suffix = '' ) use ( $order_class ): string {
			return \DiviSupreme\Includes\DsmDiviBuilderCssScope::scoped_child_selector( $parent_chain, $order_class, $suffix );
		};
		if ( ! empty( $args['attrs'] ) && \is_array( $args['attrs'] ) ) {
			ConversionAttrs::hydrate_circle_info_child_module_background_image_props_for_declaration_output( $args['attrs'] );
		}
		$attrs                  = $args['attrs'] ?? array();
		$elements               = $args['elements'];
		$dsm_badge_use_position = $attrs['dsm_badge_use_position']['innerContent']['desktop']['value'] ?? '';

		Style::add(
			array(
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => array(
					// Module.
					$elements->style(
						array(
							'attrName'   => 'module',
							'styleProps' => array(
								'disabledOn' => array(
									'disabledModuleVisibility' => $args['settings']['disabledModuleVisibility'] ?? null,
								),
							),
						)
					),

					TextStyle::style(
						array(
							'selector' => $args['orderClass'],
							'attr'     => $attrs['module']['advanced']['text'] ?? array(),
						)
					),

					$elements->style(
						array(
							'attrName' => 'header',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_circle_info_title',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_content',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_image_icon_margin',
						)
					),

					$elements->style(
						array(
							'attrName' => 'content_image_style',
						)
					),

					$elements->style(
						array(
							'attrName' => 'content_icon_style',
						)
					),

					$elements->style(
						array(
							'attrName' => 'button',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_content_icon_margin',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_content_icon_padding',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_circle_content_wrapper_style',
						)
					),

					$elements->style(
						array(
							'attrName' => 'icon_style',
						)
					),

					$elements->style(
						array(
							'attrName' => 'image_style',
						)
					),

					$elements->style(
						array(
							'attrName' => 'circle_active_item_style',
						)
					),

					$elements->style(
						array(
							'attrName' => 'circle_normal_item_style',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_icon_margin',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_icon_padding',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .et-pb-icon.dsm_icon::before",
							'attr'     => $attrs['dsm_icon_color']['innerContent'] ?? array(),
							'property' => 'color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => $sc( '.dsm_circle_info .dsm-circle-info-container', ' .et-pb-icon.dsm_content_icon' ),
							'attr'     => $attrs['dsm_content_icon_font_size']['innerContent'] ?? array(),
							'property' => 'font-size',
						)
					),

					CommonStyle::style(
						array(
							'selector' => $sc( '.dsm_circle_info .dsm-circle-info-container', ' .et-pb-icon.dsm_content_icon' ),
							'attr'     => $attrs['dsm_content_icon_bg_color']['innerContent'] ?? array(),
							'property' => 'background-color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => $sc( '.dsm_circle_info .dsm-circle-info-container', ' .et-pb-icon.dsm_content_icon' ),
							'attr'     => $attrs['dsm_content_icon_color']['innerContent'] ?? array(),
							'property' => 'color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => $sc( '.dsm_circle_info .dsm-circle-info-container', ' .dsm-image img' ),
							'attr'     => $attrs['dsm_content_image_width']['innerContent'] ?? array(),
							'property' => 'width',
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .et-pb-icon.dsm_icon::before",
							'attr'                => $attrs['font_icon']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'circle_icon_style_declaration' ),
						)
					),

					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .et-pb-icon.dsm_content_icon::before",
							'attr'                => $attrs['dsm_font_icon']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'content_icon_style_declaration' ),
						)
					),

					CommonStyle::style(
						array(
							'selector' => $sc( '.dsm_circle_info .dsm-circle-info-container .dsm-circle-info-button', ' .et-pb-icon.dsm_icon' ),
							'attr'     => $attrs['dsm_icon_color']['innerContent'] ?? array(),
							'property' => 'color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => $sc( '.dsm_circle_info .dsm-circle-info-container .dsm-circle-info-button', ' .et-pb-icon.dsm_icon' ),
							'attr'     => $attrs['dsm_icon_bg_color']['innerContent'] ?? array(),
							'property' => 'background-color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => $sc( '.dsm_circle_info .dsm-circle-info-container .dsm-circle-info-button', ' .et-pb-icon.dsm_icon' ),
							'attr'     => $attrs['dsm_icon_font_size']['innerContent'] ?? array(),
							'property' => 'font-size',
						)
					),

					CommonStyle::style(
						array(
							'selector' => $sc( '.dsm_circle_info .dsm-circle-info-container .dsm-circle-info-button', '.dsm-circle-info-item-active .et-pb-icon.dsm_icon' ),
							'attr'     => $attrs['dsm_icon_active_bg_color']['innerContent'] ?? array(),
							'property' => 'background-color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => $sc( '.dsm_circle_info .dsm-circle-info-container .dsm-circle-info-button', '.dsm-circle-info-item-active .et-pb-icon.dsm_icon' ),
							'attr'     => $attrs['dsm_icon_active_color']['innerContent'] ?? array(),
							'property' => 'color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => $sc( '.dsm_circle_info .dsm-circle-info-container .dsm-circle-info-button', ' img' ),
							'attr'     => $attrs['dsm_circle_image_width']['innerContent'] ?? array(),
							'property' => 'width',
						)
					),

					CommonStyle::style(
						array(
							'selector' => $sc( '.dsm_circle_info .dsm-circle-info-container', '.dsm-circle-info-item-inner-wrapper .dsm-circle-info-button-wrapper' ),
							'attr'     => $attrs['dsm_circle_bg_color']['innerContent'] ?? array(),
							'property' => 'background',
						)
					),

					CommonStyle::style(
						array(
							'selector' => $sc( '.dsm_circle_info .dsm-circle-info-container', '.dsm-circle-info-item-inner-wrapper.dsm-circle-info-item-active .dsm-circle-info-button-wrapper' ),
							'attr'     => $attrs['dsm_circle_active_bg_color']['innerContent'] ?? array(),
							'property' => 'background',
						)
					),

				),
			)
		);
	}

	/**
	 * Render module script data.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_script_data( $args ) {
		$elements = $args['elements'];

		// Element Script Data Options.
		$elements->script_data(
			array(
				'attrName' => 'module',
			)
		);

		$elements->script_data(
			array(
				'attrName' => 'dsm_circle_content_wrapper_style',
			)
		);
	}

	/**
	 * Render module classnames.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_classnames( $args ) {
		$classnames_instance = $args['classnamesInstance'];
		$attrs               = $args['attrs'];

		// Module.
		$classnames_instance->add(
			ElementClassnames::classnames(
				array(
					'attrs' => $attrs['module']['decoration'] ?? array(),
				)
			)
		);
	}

	/**
	 * Render module HTML output.
	 *
	 * @param array     $attrs - Modules Attributes.
	 * @param string    $content - Content.
	 * @param \WP_Block $block - Block.
	 * @param mixed     $elements - Elements.
	 */
	public static function render_callback( $attrs, $content, $block, $elements ) {

		$container = sprintf(
			'',
		);

		// Module Inner.
		// Essentially, this is the module content.
		// Were wrapping the title and content in a div with class `et_pb_module_inner`.
		$module_inner = HTMLUtility::render(
			array(
				'tag'               => 'div',
				'attributes'        => array(
					'class' => 'et_pb_module_inner',
				),
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $container,
			)
		);

		// This are the module elements that will be rendered in the frontend.
		$module_elements = $elements->style_components(
			array(
				'attrName' => 'module',
			)
		);

		// This are the children of the module container, which are the module elements and the module inner.
		$module_container_children = $module_elements . $module_inner;

		return Module::render(
			array(
				// FE only.
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],
				// VB equivalent.
				'attrs'               => $attrs,
				'elements'            => $elements,
				'id'                  => $block->parsed_block['id'],
				'moduleClassName'     => 'dsm_circle_info_child',
				'name'                => $block->block_type->name,
				'classnamesFunction'  => array( self::class, 'module_classnames' ),
				'moduleCategory'      => $block->block_type->category,
				'stylesComponent'     => array( self::class, 'module_styles' ),
				'scriptDataComponent' => array( self::class, 'module_script_data' ),
				'children'            => $module_container_children,
			)
		);
	}
}
