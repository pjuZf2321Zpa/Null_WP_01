<?php
/**
 * Business Hour Module.
 *
 * @package DiviSupreme.
 */

declare(strict_types=1);

namespace DiviSupreme\Modules;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\Module\Options\Element\ElementClassnames;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\Packages\Module\Options\Css\CssStyle;


/**
 * Class that handles "BusinessHoursChild Module" module.
 */
class BusinessHoursChild implements DependencyInterface {


	/**
	 * Build a minimal `headingLink` value object for server / MultiView (expects `text`, not a bare string).
	 *
	 * @param string $text Plain text.
	 * @return array<string, string>
	 */
	private static function heading_link_value_from_string( $text ) {
		return array(
			'text'   => (string) $text,
			'url'    => '',
			'target' => 'off',
		);
	}

	/**
	 * Legacy saves may store `innerContent` leaves as plain strings. Divi 5 MultiView calls
	 * `ArrayUtility::get_value( $leaf, 'text', '' )` and requires an array leaf.
	 *
	 * Must run on {@see \ET\Builder\Packages\Module\Layout\Components\ModuleElements\ModuleElements::$module_attrs}
	 * before `$elements->render()` — that object does not use the `$attrs` callback argument.
	 *
	 * @param array  $attrs    Reference to module attrs.
	 * @param string $attr_key Attribute key (`title` or `time`).
	 */
	private static function ensure_heading_link_text_shape( array &$attrs, $attr_key ) {
		if ( ! isset( $attrs[ $attr_key ]['innerContent'] ) || ! is_array( $attrs[ $attr_key ]['innerContent'] ) ) {
			return;
		}

		$inner = &$attrs[ $attr_key ]['innerContent'];

		foreach ( array_keys( $inner ) as $breakpoint ) {
			if ( ! isset( $inner[ $breakpoint ] ) ) {
				continue;
			}

			// Legacy: entire breakpoint is a string (no `value` / state nesting).
			if ( is_string( $inner[ $breakpoint ] ) ) {
				$inner[ $breakpoint ] = array(
					'value' => self::heading_link_value_from_string( $inner[ $breakpoint ] ),
				);
				continue;
			}

			if ( ! is_array( $inner[ $breakpoint ] ) ) {
				continue;
			}

			foreach ( array_keys( $inner[ $breakpoint ] ) as $state_key ) {
				if ( ! isset( $inner[ $breakpoint ][ $state_key ] ) ) {
					continue;
				}

				$leaf = &$inner[ $breakpoint ][ $state_key ];

				if ( is_string( $leaf ) ) {
					$leaf = self::heading_link_value_from_string( $leaf );
					continue;
				}

				if ( ! is_array( $leaf ) ) {
					continue;
				}

				if ( ! array_key_exists( 'url', $leaf ) ) {
					$leaf['url'] = '';
				}

				if ( ! array_key_exists( 'target', $leaf ) ) {
					$leaf['target'] = 'off';
				}
			}
		}
	}

	/**
	 * Register module.
	 * `DependencyInterface` interface ensures class method name `load()` is executed for initialization.
	 */
	public function load() {
		add_action( 'init', array( self::class, 'register_module' ) );
	}

	/**
	 * Initilises the module.
	 *
	 * @return void
	 */
	public static function dsm_initialise() {
		add_action(
			'divi_module_library_modules_dependency_tree',
			function ( $dependency_tree ) {
				$dependency_tree->add_dependency( new self() );
			}
		);
	}

	/**
	 * Register module.
	 */
	public static function register_module() {

		$module_json_path = DSM_DIR_PATH . 'divi-5/public/packages/module-library/business-hours-child';

		ModuleRegistration::register_module(
			$module_json_path,
			array(
				'render_callback' => array( self::class, 'render_callback' ),
			)
		);
	}

	/**
	 * Render module style.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_styles( $args ) {
		$args     = \DiviSupreme\Includes\DsmDiviBuilderCssScope::normalize_module_styles_args( $args );
		$attrs    = $args['attrs'] ?? array();
		$elements = $args['elements'];

		Style::add(
			array(
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => array(
					// Module.
					$elements->style(
						array(
							'attrName'   => 'module',
							'styleProps' => array(
								'disabledOn' => array(
									'disabledModuleVisibility' => $args['settings']['disabledModuleVisibility'] ?? null,
								),
							),
						)
					),

					CssStyle::style(
						array(
							'selector' => $args['orderClass'],
							'attr'     => $attrs['css'] ?? array(),
						)
					),

					$elements->style(
						array(
							'attrName' => 'text',
						)
					),

					$elements->style(
						array(
							'attrName' => 'time',
						)
					),

					$elements->style(
						array(
							'attrName' => 'title',
						)
					),
				),
			)
		);
	}

	/**
	 * Render module script data.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_script_data( $args ) {
		$elements = $args['elements'];

		// Element Script Data Options.
		$elements->script_data(
			array(
				'attrName' => 'module',
			)
		);
	}

	/**
	 * Render module classnames.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_classnames( $args ) {
		$classnames_instance = $args['classnamesInstance'];
		$attrs               = $args['attrs'];

		// Module.
		$classnames_instance->add(
			ElementClassnames::classnames(
				array(
					'attrs' => $attrs['module']['decoration'] ?? array(),
				)
			)
		);
	}

	/**
	 * Render module HTML output.
	 *
	 * @param array     $attrs - Modules Attributes.
	 * @param string    $content - Content.
	 * @param \WP_Block $block - Block.
	 * @param mixed     $elements - Elements.
	 */
	public static function render_callback( $attrs, $content, $block, $elements ) {
		if ( isset( $elements->module_attrs ) && is_array( $elements->module_attrs ) ) {
			self::ensure_heading_link_text_shape( $elements->module_attrs, 'title' );
			self::ensure_heading_link_text_shape( $elements->module_attrs, 'time' );
		}

		if ( is_array( $attrs ) ) {
			self::ensure_heading_link_text_shape( $attrs, 'title' );
			self::ensure_heading_link_text_shape( $attrs, 'time' );
		}

		$time_text = $elements->render(
			array(
				'attrName' => 'time',
			)
		);

		$day_text = $elements->render(
			array(
				'attrName' => 'title',
			)
		);

		$container = sprintf(
			'<div class="dsm_business_hours_item_wrapper">
		  <div class="dsm-business-hours-header">
		    <div class="dsm-business-hours-day">%1$s</div>
			<div class="dsm-business-hours-separator"></div>
			<div class="dsm-business-hours-time">%2$s</div>
		  </div>
		</div>',
			$day_text,
			$time_text
		);

		// Module Inner.
		// Essentially, this is the module content.
		// Were wrapping the title and content in a div with class `et_pb_module_inner`.
		$module_inner = HTMLUtility::render(
			array(
				'tag'               => 'div',
				'attributes'        => array(
					'class' => 'et_pb_module_inner',
				),
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $container,
			)
		);

		// This are the module elements that will be rendered in the frontend.
		$module_elements = $elements->style_components(
			array(
				'attrName' => 'module',
			)
		);

		// This are the children of the module container, which are the module elements and the module inner.
		$module_container_children = $module_elements . $module_inner;

		return Module::render(
			array(
				// FE only.
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],

				// VB equivalent.
				'attrs'               => $attrs,
				'elements'            => $elements,
				'id'                  => $block->parsed_block['id'],
				'moduleClassName'     => 'd5_tut_simple_quick_module',
				'name'                => $block->block_type->name,
				'classnamesFunction'  => array( self::class, 'module_classnames' ),
				'moduleCategory'      => $block->block_type->category,
				'stylesComponent'     => array( self::class, 'module_styles' ),
				'scriptDataComponent' => array( self::class, 'module_script_data' ),
				'children'            => $module_container_children,
			)
		);
	}
}
