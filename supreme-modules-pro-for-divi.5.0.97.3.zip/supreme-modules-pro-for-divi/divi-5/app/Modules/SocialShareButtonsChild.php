<?php
/**
 * SocialShare Button Child Module.
 *
 * @package DiviSupreme.
 */

declare(strict_types=1);

namespace DiviSupreme\Modules;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\FrontEnd\BlockParser\BlockParserStore;
use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\Module\Options\Element\ElementClassnames;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use DiviSupreme\Includes\UploadImageMarkup;


/**
 * Class that handles "Social Share Button Module" module.
 *
 * D4 `module_id` / `module_class` migrate to D5 `module.decoration.attributes` through the shared
 * conversion outline value expansion map and
 * {@see \DiviSupreme\Includes\Divi5Conversion\SupremeSharedConversion::post_convert_merge_decoration_attributes()}.
 */
class SocialShareButtonsChild implements DependencyInterface {


	/**
	 * Get the current page URL.
	 *
	 * @return string
	 */
	private static function get_current_page_url() {
		// Try to get the URL from WordPress functions first.
		if ( is_singular() ) {
			return get_permalink( get_queried_object_id() );
		}

		// For archive pages.
		if ( is_archive() || is_home() || is_front_page() ) {
			global $wp;
			return home_url( $wp->request );
		}

		// Fallback to server variables.
		if ( isset( $_SERVER['HTTPS'] ) && 'on' === $_SERVER['HTTPS'] ) {
			$protocol = 'https://';
		} else {
			$protocol = 'http://';
		}

		if ( isset( $_SERVER['HTTP_HOST'] ) && isset( $_SERVER['REQUEST_URI'] ) ) {
			$host        = sanitize_text_field( wp_unslash( (string) $_SERVER['HTTP_HOST'] ) );
			$request_uri = sanitize_text_field( wp_unslash( (string) $_SERVER['REQUEST_URI'] ) );
			$share_url   = esc_url_raw( $protocol . $host . $request_uri );

			if ( is_string( $share_url ) && '' !== $share_url ) {
				return $share_url;
			}
		}

		// Last resort fallback.
		return get_permalink();
	}



	/**
	 * Register module.
	 * `DependencyInterface` interface ensures class method name `load()` is executed for initialization.
	 */
	public function load() {
		add_action( 'init', array( self::class, 'register_module' ) );
	}

	/**
	 * Initilises the module.
	 *
	 * @return void
	 */
	public static function dsm_initialise() {
		add_action(
			'divi_module_library_modules_dependency_tree',
			function ( $dependency_tree ) {
				$dependency_tree->add_dependency( new self() );
			}
		);
	}

	/**
	 * Register module.
	 */
	public static function register_module() {

		$module_json_path = DSM_DIR_PATH . 'divi-5/public/packages/module-library/social-share-buttons-child';

		ModuleRegistration::register_module(
			$module_json_path,
			array(
				'render_callback' => array( self::class, 'render_callback' ),
			)
		);
	}

	/**
	 * Render module style.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_styles( $args ) {
		$args           = \DiviSupreme\Includes\DsmDiviBuilderCssScope::normalize_module_styles_args( $args );
		$order_class    = (string) ( $args['orderClass'] ?? '' );
		$sc             = static function ( string $parent_chain, string $suffix = '' ) use ( $order_class ): string {
			return \DiviSupreme\Includes\DsmDiviBuilderCssScope::scoped_child_selector( $parent_chain, $order_class, $suffix );
		};
		$attrs          = $args['attrs'] ?? array();
		$elements       = $args['elements'];
		$dsm_color_type = $attrs['dsm_color_type']['innerContent']['desktop']['value'] ?? '';

		Style::add(
			array(
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => array(
					// Module.
					$elements->style(
						array(
							'attrName'   => 'module',
							'styleProps' => array(
								'disabledOn' => array(
									'disabledModuleVisibility' => $args['settings']['disabledModuleVisibility'] ?? null,
								),
							),
						)
					),

					CssStyle::style(
						array(
							'selector' => $args['orderClass'],
							'attr'     => $attrs['css'] ?? array(),
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']}",
							'attr'     => $attrs['hotspot_image_max_width']['innerContent'] ?? array(),
							'property' => 'max-width',
						)
					),

					'custom' === $dsm_color_type ?
					CommonStyle::style(
						array(
							'selector' => $sc( '.dsm-social-share-buttons-container', '.et_pb_module .dsm-social-share-button-inner-wrapper' ),
							'attr'     => $attrs['dsm_custom_bg_color']['innerContent'] ?? array(),
							'property' => 'background-color',
						)
					) : '',

					'custom' === $dsm_color_type ?
					CommonStyle::style(
						array(
							'selector' => $sc( '.dsm-social-share-buttons-container', '.et_pb_module .dsm-social-share-button-inner-wrapper' ),
							'attr'     => $attrs['dsm_custom_color']['innerContent'] ?? array(),
							'property' => 'color',
						)
					) : '',
				),
			)
		);
	}

	/**
	 * Render module script data.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_script_data( $args ) {
		$elements = $args['elements'];

		// Element Script Data Options.
		$elements->script_data(
			array(
				'attrName' => 'module',
			)
		);
	}

	/**
	 * Render module classnames.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_classnames( $args ) {
		$classnames_instance = $args['classnamesInstance'];
		$attrs               = $args['attrs'];

		// Module.
		$classnames_instance->add(
			ElementClassnames::classnames(
				array(
					'attrs' => $attrs['module']['decoration'] ?? array(),
				)
			),
		);

		$classnames_instance->add( 'dsm-social-share-button-wrapper' );
	}

	/**
	 * Render module HTML output.
	 *
	 * @param array     $attrs - Modules Attributes.
	 * @param string    $content - Content.
	 * @param \WP_Block $block - Block.
	 * @param mixed     $elements - Elements.
	 */
	public static function render_callback( $attrs, $content, $block, $elements ) {
		$parent                 = BlockParserStore::get_parent( $block->parsed_block['id'], $block->parsed_block['storeInstance'] );
		$parent_attrs           = $parent->attrs ?? array();
		$parent_view            = $parent_attrs['dsm_view']['innerContent']['desktop']['value'] ?? '';
		$parent_dsm_label       = $parent_attrs['dsm_label']['innerContent']['desktop']['value'] ?? '';
		$parent_target_type     = $parent_attrs['dsm_target_type']['innerContent']['desktop']['value'] ?? 'current_page';
		$parent_target_url      = $parent_attrs['dsm_target_link_url']['innerContent']['desktop']['value'] ?? '';
		$dsm_network            = $attrs['dsm_network']['innerContent']['desktop']['value'] ?? '';
		$dsm_custom_image_icon  = $attrs['dsm_custom_image_icon']['innerContent']['desktop']['value'] ?? '';
		$raw_src                = $attrs['src']['innerContent']['desktop']['value'] ?? '';
		$button_hover_animation = $parent_attrs['dsm_social_hover_animation']['innerContent']['desktop']['value'] ?? '';
		$dsm_custom_label       = $attrs['dsm_custom_label']['innerContent']['desktop']['value'] ?? '';

		$images_output = UploadImageMarkup::render_img_html(
			$raw_src,
			'',
			array(
				'class' => 'dsm_custom_image_icon',
			)
		);

		$social_share_button_value = '';

		switch ( $dsm_network ) {
			case 'facebook':
				$social_share_button_value = sprintf(
					'<div class="dsm-social-share-button-inner-wrapper dsm-facebook %5$s" data-share_url="%4$s">
							%1$s
							%2$s
							%3$s
					</div>
			   ',
					'icon_text' === $parent_view || '' === $parent_view ?
					sprintf(
						'<div class="dsm-social-share-button-icon">
								%2$s
						    </div>
							%1$s
							',
						'on' === $parent_dsm_label || '' === $parent_dsm_label ? sprintf(
							'<div class="dsm-social-share-button-text">
									<span class="dsm-text">%1$s</span>
								</div>',
							'' === $dsm_custom_label ? 'Facebook' : $dsm_custom_label
						) : '',
						'on' === $dsm_custom_image_icon ? sprintf(
							'%1$s',
							$images_output
						) : '<span class="dsm_icon et-pb-icon"></span>'
					) : '',
					'icon' === $parent_view ?
					sprintf(
						'<div class="dsm-social-share-button-icon">
								%1$s
							</div>',
						'on' === $dsm_custom_image_icon ? sprintf(
							'<span class="dsm_icon et-pb-icon">%1$s</span>
								',
							$images_output
						) : '<span class="dsm_icon et-pb-icon"></span>'
					) : '',
					'text' === $parent_view ?
					sprintf(
						'<div class="dsm-social-share-button-text">
									 <span class="dsm-text">%1$s</span>
									</div>',
						'' === trim( $dsm_custom_label ) ? 'Facebook' : $dsm_custom_label
					) : '',
					'current_page' === $parent_target_type ? 'https://www.facebook.com/sharer/sharer.php?u=' . esc_url( self::get_current_page_url() ) : 'https://www.facebook.com/sharer/sharer.php?u=' . esc_url( $parent_target_url ),
					$button_hover_animation
				);
				break;

			case 'twitter':
				$social_share_button_value = sprintf(
					'<div class="dsm-social-share-button-inner-wrapper dsm-twitter %5$s" data-share_url="%4$s">
						    %1$s
							%2$s
							%3$s
						</div>
					',
					'icon_text' === $parent_view || '' === $parent_view ? sprintf(
						'
				                <div class="dsm-social-share-button-icon">
								%2$s
						        </div>
						         %1$s
								',
						'on' === $parent_dsm_label || '' === $parent_dsm_label ? sprintf(
							'<div class="dsm-social-share-button-text">
						              <span class="dsm-text">%1$s</span>
						            </div>',
							'' === trim( $dsm_custom_label ) ? 'Twitter' : $dsm_custom_label
						) : '',
						'on' === $dsm_custom_image_icon ? sprintf(
							'%1$s',
							$images_output
						) : '<span class="dsm_icon et-pb-icon"></span>'
					) : '',
					'icon' === $parent_view ? sprintf(
						'<div class="dsm-social-share-button-icon">
								%1$s
						        </div>',
						'on' === $dsm_custom_image_icon ? sprintf(
							'<span class="dsm_icon et-pb-icon">%1$s</span>
								',
							$images_output
						) : '<span class="dsm_icon et-pb-icon"></span>'
					) : '',
					'text' === $parent_view ? sprintf(
						'
						        <div class="dsm-social-share-button-text">
						          <span class="dsm-text">%1$s</span>
						        </div>',
						'' === trim( $dsm_custom_label ) ? 'Twitter' : $dsm_custom_label
					) : '',
					'current_page' === $parent_target_type ? 'https://twitter.com/intent/tweet?text=%20' . esc_url( self::get_current_page_url() ) : 'https://twitter.com/intent/tweet?text=%20' . esc_url( $parent_target_url ),
					$button_hover_animation
				);
				break;

			case 'linkedin':
				$social_share_button_value = sprintf(
					'
			            <div class="dsm-social-share-button-inner-wrapper dsm-linkedin  %5$s" data-share_url="%4$s">
						    %1$s
							%2$s
							%3$s
						</div>
			   ',
					'icon_text' === $parent_view || '' === $parent_view ? sprintf(
						'
				              <div class="dsm-social-share-button-icon">
						         <span class="dsm_icon et-pb-icon"></span>
						      </div>
						       %1$s 
							  ',
						'on' === $parent_dsm_label || '' === $parent_dsm_label ? sprintf(
							'
							    <div class="dsm-social-share-button-text">
						         <span class="dsm-text">%1$s</span>
						        </div>
							  ',
							'' === trim( $dsm_custom_label ) ? 'Linkedin' : $dsm_custom_label
						) : '',
						'on' === $dsm_custom_image_icon ? sprintf(
							'<span class="dsm_icon et-pb-icon">%1$s</span>
							',
							$images_output
						) : '<span class="dsm_icon et-pb-icon"></span>'
					) : '',
					'icon' === $parent_view ? sprintf(
						'
				              <div class="dsm-social-share-button-icon">
							  %1$s						      </div>',
						'on' === $dsm_custom_image_icon ? sprintf(
							'%1$s',
							$images_output
						) : '<span class="dsm_icon et-pb-icon"></span>'
					) : '',
					'text' === $parent_view ? sprintf(
						'
						      <div class="dsm-social-share-button-text">
						         <span class="dsm-text">%1$s</span>
						      </div>',
						'' === trim( $dsm_custom_label ) ? 'Linkedin' : $dsm_custom_label
					) : '',
					'current_page' === $parent_target_type ? 'https://www.linkedin.com/shareArticle?mini=true&url=' . esc_url( self::get_current_page_url() ) . '/&title=&summary=&source=' : 'https://www.linkedin.com/shareArticle?mini=true&url=' . esc_url( $parent_target_url ) . '/&title=&summary=&source=',
					$button_hover_animation
				);
				break;

			case 'pinterest':
				$social_share_button_value = sprintf(
					'
			            <div class="dsm-social-share-button-inner-wrapper dsm-pinterest %5$s" data-share_url="%4$s">
						    %1$s
							%2$s
							%3$s
						</div>
			   ',
					'icon_text' === $parent_view || '' === $parent_view ? sprintf(
						'
			                <div class="dsm-social-share-button-icon">
						       <span class="dsm_icon et-pb-icon"></span>
						    </div>
							%1$s
						    ',
						'on' === $parent_dsm_label || '' === $parent_dsm_label ? sprintf(
							'
							    <div class="dsm-social-share-button-text">
						          <span class="dsm-text">%1$s</span>
						        </div>',
							'' === trim( $dsm_custom_label ) ? 'Pinterest' : $dsm_custom_label
						) : '',
						'on' === $dsm_custom_image_icon ? sprintf(
							'<span class="dsm_icon et-pb-icon">%1$s</span>
							',
							$images_output
						) : '<span class="dsm_icon et-pb-icon"></span>'
					) : '',
					'icon' === $parent_view ? sprintf(
						'
			                <div class="dsm-social-share-button-icon">
							%1$s						    </div>',
						'on' === $dsm_custom_image_icon ? sprintf(
							'%1$s',
							$images_output
						) : '<span class="dsm_icon et-pb-icon"></span>'
					) : '',
					'text' === $parent_view ? sprintf(
						'
						    <div class="dsm-social-share-button-text">
						      <span class="dsm-text">%1$s</span>
						    </div>',
						'' === trim( $dsm_custom_label ) ? 'Pinterest' : $dsm_custom_label
					) : '',
					'current_page' === $parent_target_type ? 'https://www.pinterest.com/pin/create/button/?url=' . esc_url( self::get_current_page_url() ) . '&media=' : 'https://www.pinterest.com/pin/create/button/?url=' . esc_url( $parent_target_url ) . '&media=',
					$button_hover_animation
				);
				break;

			case 'reddit':
				$social_share_button_value = sprintf(
					'
			            <div class="dsm-social-share-button-inner-wrapper dsm-reddit %5$s" data-share_url="%4$s">
						    %1$s
							%2$s
							%3$s
						</div>
			   ',
					'icon_text' === $parent_view || '' === $parent_view ? sprintf(
						'
			                <div class="dsm-social-share-button-icon">
						       <span class="dsm_icon et-pb-icon"></span>
						    </div>
						    %1$s
							',
						'on' === $parent_dsm_label || '' === $parent_dsm_label ? sprintf(
							'
							    <div class="dsm-social-share-button-text">
						          <span class="dsm-text">%1$s</span>
						        </div>',
							'' === trim( $dsm_custom_label ) ? 'Reddit' : $dsm_custom_label
						) : '',
						'on' === $dsm_custom_image_icon ? sprintf(
							'%1$s',
							$images_output
						) : '<span class="dsm_icon et-pb-icon"></span>'
					) : '',
					'icon' === $parent_view ? sprintf(
						'
			                <div class="dsm-social-share-button-icon">
							%1$s						    </div>',
						'on' === $dsm_custom_image_icon ? sprintf(
							'<span class="dsm_icon et-pb-icon">%1$s</span>
									  ',
							$images_output
						) : '<span class="dsm_icon et-pb-icon"></span>'
					) : '',
					'text' === $parent_view ? sprintf(
						'
						    <div class="dsm-social-share-button-text">
						      <span class="dsm-text">%1$s</span>
						    </div>',
						'' === trim( $dsm_custom_label ) ? 'Reddit' : $dsm_custom_label
					) : '',
					'current_page' === $parent_target_type ? 'https://www.reddit.com/submit?url=' . esc_url( self::get_current_page_url() ) : 'https://www.reddit.com/submit?url=' . esc_url( $parent_target_url ),
					$button_hover_animation
				);
				break;

			case 'vk':
				$social_share_button_value = sprintf(
					'
			            <div class="dsm-social-share-button-inner-wrapper dsm-vk %5$s" data-share_url="%4$s">
						     %1$s
							 %2$s
							 %3$s
						</div>
			   ',
					'icon_text' === $parent_view || '' === $parent_view ? sprintf(
						'
			                <div class="dsm-social-share-button-icon">
						       <span class="dsm_icon et-pb-icon"></span>
						    </div>
							%1$s
						    ',
						'on' === $parent_dsm_label || '' === $parent_dsm_label ? sprintf(
							'
							    <div class="dsm-social-share-button-text">
						          <span class="dsm-text">%1$s</span>
						        </div>',
							'' === trim( $dsm_custom_label ) ? 'Vk' : $dsm_custom_label
						) : '',
						'on' === $dsm_custom_image_icon ? sprintf(
							'%1$s',
							$images_output
						) : '<span class="dsm_icon et-pb-icon"></span>'
					) : '',
					'icon' === $parent_view ? sprintf(
						'
						    <div class="dsm-social-share-button-icon">
							%1$s						    </div>',
						'on' === $dsm_custom_image_icon ? sprintf(
							'<span class="dsm_icon et-pb-icon">%1$s</span>
									  ',
							$images_output
						) : '<span class="dsm_icon et-pb-icon"></span>'
					) : '',
					'text' === $parent_view ? sprintf(
						'
			                <div class="dsm-social-share-button-text">
						      <span class="dsm-text">%1$s</span>
						    </div>',
						'' === trim( $dsm_custom_label ) ? 'Vk' : $dsm_custom_label
					) : '',
					'current_page' === $parent_target_type ? 'https://vk.com/share.php?url=' . esc_url( self::get_current_page_url() ) : 'https://vk.com/share.php?url=' . esc_url( $parent_target_url ),
					$button_hover_animation
				);
				break;
			case 'tumblr':
				$social_share_button_value = sprintf(
					'
			            <div class="dsm-social-share-button-inner-wrapper dsm-tumbler %5$s" data-share_url="%4$s">
						     %1$s
							 %2$s
							 %3$s
						</div>
			   ',
					'icon_text' === $parent_view || '' === $parent_view ? sprintf(
						'
			            <div class="dsm-social-share-button-icon">
						       <span class="dsm_icon et-pb-icon"></span>
						</div>
						%1$s
						',
						'on' === $parent_dsm_label || '' === $parent_dsm_label ? sprintf(
							'
							    <div class="dsm-social-share-button-text">
						            <span class="dsm-text">%1$s</span>
						        </div>',
							'' === trim( $dsm_custom_label ) ? 'Tumblr' : $dsm_custom_label
						) : '',
						'on' === $dsm_custom_image_icon ? sprintf(
							'%1$s',
							$images_output
						) : '<span class="dsm_icon et-pb-icon"></span>'
					) : '',
					'icon' === $parent_view ? sprintf(
						'
			            <div class="dsm-social-share-button-icon">
						%1$s						</div>',
						'on' === $dsm_custom_image_icon ? sprintf(
							'<span class="dsm_icon et-pb-icon">%1$s</span>
								  ',
							$images_output
						) : '<span class="dsm_icon et-pb-icon"></span>'
					) : '',
					'text' === $parent_view ? sprintf(
						'
						<div class="dsm-social-share-button-text">
						      <span class="dsm-text">%1$s</span>
						</div>',
						'' === trim( $dsm_custom_label ) ? 'Tumblr' : $dsm_custom_label
					) : '',
					'current_page' === $parent_target_type ? 'https://tumblr.com/share/link?url=' . esc_url( self::get_current_page_url() ) : 'https://tumblr.com/share/link?url=' . esc_url( $parent_target_url ),
					$button_hover_animation
				);
				break;

			case 'digg':
				$social_share_button_value = sprintf(
					'<div class="dsm-social-share-button-inner-wrapper dsm-digg %5$s" data-share_url="%4$s">
						    %1$s
							%2$s
							%3$s
						</div> ',
					'icon_text' === $parent_view || '' === $parent_view ? sprintf(
						'
				            <div class="dsm-social-share-button-icon">
						       <span class="dsm_icon et-pb-icon"></span>
						    </div>
							%1$s
						    ',
						'on' === $parent_dsm_label || '' === $parent_dsm_label ? sprintf(
							'
							    <div class="dsm-social-share-button-text">
						           <span class="dsm-text">%1$s</span>
						        </div>',
							'' === trim( $dsm_custom_label ) ? 'Digg' : $dsm_custom_label
						) : '',
						'on' === $dsm_custom_image_icon ? sprintf(
							'<span class="dsm_icon et-pb-icon">%1$s</span>
							',
							$images_output
						) : '<span class="dsm_icon et-pb-icon"></span>'
					) : '',
					'icon' === $parent_view ? sprintf(
						'
				            <div class="dsm-social-share-button-icon">
							%1$s						    </div>',
						'on' === $dsm_custom_image_icon ? sprintf(
							'%1$s',
							$images_output
						) : '<span class="dsm_icon et-pb-icon"></span>'
					) : '',
					'text' === $parent_view ? sprintf(
						'
						    <div class="dsm-social-share-button-text">
						      <span class="dsm-text">%1$s</span>
						    </div>',
						'' === trim( $dsm_custom_label ) ? 'Digg' : $dsm_custom_label
					) : '',
					'current_page' === $parent_target_type ? 'https://digg.com/submit?url=' . esc_url( self::get_current_page_url() ) : 'https://digg.com/submit?url=' . esc_url( $parent_target_url ),
					$button_hover_animation
				);
				break;

			case 'skype':
				$social_share_button_value = sprintf(
					'<div class="dsm-social-share-button-inner-wrapper dsm-skype %5$s" data-share_url="%4$s">
						    %1$s
							%2$s
							%3$s
						</div>',
					'icon_text' === $parent_view || '' === $parent_view ? sprintf(
						'
			                <div class="dsm-social-share-button-icon">
						       <span class="dsm_icon et-pb-icon"></span>
						    </div>
		                    %1$s
						    ',
						'on' === $parent_dsm_label || '' === $parent_dsm_label ? sprintf(
							'
							    <div class="dsm-social-share-button-text">
						          <span class="dsm-text">%1$s</span>
						        </div>',
							'' === trim( $dsm_custom_label ) ? 'Skype' : $dsm_custom_label
						) : '',
						'on' === $dsm_custom_image_icon ? sprintf(
							'%1$s',
							$images_output
						) : '<span class="dsm_icon et-pb-icon"></span>'
					) : '',
					'icon' === $parent_view ? sprintf(
						'
			                <div class="dsm-social-share-button-icon">
							%1$s						    </div>',
						'on' === $dsm_custom_image_icon ? sprintf(
							'<span class="dsm_icon et-pb-icon">%1$s</span>
									  ',
							$images_output
						) : '<span class="dsm_icon et-pb-icon"></span>'
					) : '',
					'text' === $parent_view ? sprintf(
						'
						    <div class="dsm-social-share-button-text">
						      <span class="dsm-text">%1$s</span>
						    </div>',
						'' === trim( $dsm_custom_label ) ? 'Skype' : $dsm_custom_label
					) : '',
					'current_page' === $parent_target_type ? 'https://web.skype.com/share?url=' . esc_url( self::get_current_page_url() ) : 'https://web.skype.com/share?url=' . esc_url( $parent_target_url ),
					$button_hover_animation
				);
				break;

			case 'stumbleupon':
				$social_share_button_value = sprintf(
					'<div class="dsm-social-share-button-inner-wrapper dsm-stumbleupon %5$s" data-share_url="%4$s">
						    %1$s
							%2$s
							%3$s
						</div>
			   ',
					'icon_text' === $parent_view || '' === $parent_view ? sprintf(
						'<div class="dsm-social-share-button-icon">
						       <span class="dsm_icon et-pb-icon"></span>
						    </div>
						     %1$s
							',
						'on' === $parent_dsm_label || '' === $parent_dsm_label ? sprintf(
							'
							    <div class="dsm-social-share-button-text">
						          <span class="dsm-text">%1$s</span>
						        </div>',
							'' === trim( $dsm_custom_label ) ? 'Stumbleupon' : $dsm_custom_label
						) : '',
						'on' === $dsm_custom_image_icon ? sprintf(
							'<span class="dsm_icon et-pb-icon">%1$s</span>
							',
							$images_output
						) : '<span class="dsm_icon et-pb-icon"></span>'
					) : '',
					'icon' === $parent_view ? sprintf(
						'
			                <div class="dsm-social-share-button-icon">
							%1$s						    </div>',
						'on' === $dsm_custom_image_icon ? sprintf(
							'%1$s',
							$images_output
						) : '<span class="dsm_icon et-pb-icon"></span>'
					) : '',
					'text' === $parent_view ? sprintf(
						'
						    <div class="dsm-social-share-button-text">
						      <span class="dsm-text">%1$s</span>
						    </div>',
						'' === trim( $dsm_custom_label ) ? 'Stumbleupon' : $dsm_custom_label
					) : '',
					'current_page' === $parent_target_type ? 'https://www.stumbleupon.com/submit?url=' . esc_url( self::get_current_page_url() ) : 'https://www.stumbleupon.com/submit?url=' . esc_url( $parent_target_url ),
					$button_hover_animation
				);
				break;

			case 'mix':
				$social_share_button_value = sprintf(
					'<div class="dsm-social-share-button-inner-wrapper dsm-mix %5$s" data-share_url="%4$s">
						    %1$s
							%2$s
							%3$s
						</div> ',
					'icon_text' === $parent_view || '' === $parent_view ? sprintf(
						'<div class="dsm-social-share-button-icon">
						       <span class="dsm_icon et-pb-icon"></span>
						    </div>
							%1$s
						    ',
						'on' === $parent_dsm_label || '' === $parent_dsm_label ? sprintf(
							'
							    <div class="dsm-social-share-button-text">
						          <span class="dsm-text">%1$s</span>
						        </div>',
							'' === trim( $dsm_custom_label ) ? 'Mix' : $dsm_custom_label
						) : '',
						'on' === $dsm_custom_image_icon ? sprintf(
							'%1$s',
							$images_output
						) : '<span class="dsm_icon et-pb-icon"></span>'
					) : '',
					'icon' === $parent_view ? sprintf(
						'
			                <div class="dsm-social-share-button-icon">
							%1$s						    </div>',
						'on' === $dsm_custom_image_icon ? sprintf(
							'<span class="dsm_icon et-pb-icon">%1$s</span>
									  ',
							$images_output
						) : '<span class="dsm_icon et-pb-icon"></span>'
					) : '',
					'text' === $parent_view ? sprintf(
						'
						    <div class="dsm-social-share-button-text">
						      <span class="dsm-text">%1$s</span>
						    </div>',
						'' === trim( $dsm_custom_label ) ? 'Mix' : $dsm_custom_label
					) : '',
					'current_page' === $parent_target_type ? 'https://www.facebook.com/sharer/sharer.php?u=' . esc_url( self::get_current_page_url() ) : 'https://www.facebook.com/sharer/sharer.php?u=' . esc_url( $parent_target_url ),
					$button_hover_animation
				);
				break;

			case 'telegram':
				$social_share_button_value = sprintf(
					'<div class="dsm-social-share-button-inner-wrapper dsm-telegram %5$s" data-share_url="%4$s">
						    %1$s
							%2$s
							%3$s
						</div>',
					'icon_text' === $parent_view || '' === $parent_view ? sprintf(
						'
			                <div class="dsm-social-share-button-icon">
						       <span class="dsm_icon et-pb-icon"></span>
						    </div>
							%1$s
						    ',
						'on' === $parent_dsm_label || '' === $parent_dsm_label ? sprintf(
							'
							    <div class="dsm-social-share-button-text">
						          <span class="dsm-text">%1$s</span>
						        </div>',
							'' === trim( $dsm_custom_label ) ? 'Telegram' : $dsm_custom_label
						) : '',
						'on' === $dsm_custom_image_icon ? sprintf(
							'%1$s',
							$images_output
						) : '<span class="dsm_icon et-pb-icon"></span>'
					) : '',
					'icon' === $parent_view ? sprintf(
						'
			                <div class="dsm-social-share-button-icon">
							%1$s						    </div>',
						'on' === $dsm_custom_image_icon ? sprintf(
							'<span class="dsm_icon et-pb-icon">%1$s</span>
									  ',
							$images_output
						) : '<span class="dsm_icon et-pb-icon"></span>'
					) : '',
					'text' === $parent_view ? sprintf(
						'
						    <div class="dsm-social-share-button-text">
						      <span class="dsm-text">%1$s</span>
						    </div>',
						'' === trim( $dsm_custom_label ) ? 'Telegram' : $dsm_custom_label
					) : '',
					'current_page' === $parent_target_type ? 'https://telegram.me/share/url?url=' . esc_url( self::get_current_page_url() ) . '&text=' : 'https://telegram.me/share/url?url=' . esc_url( $parent_target_url ) . '&text=',
					$button_hover_animation
				);
				break;
			case 'pocket':
				$social_share_button_value = sprintf(
					'<div class="dsm-social-share-button-inner-wrapper dsm-pocket %5$s" data-share_url="%4$s">
						    %1$s
							%2$s
							%3$s
					</div> ',
					'icon_text' === $parent_view || '' === $parent_view ? sprintf(
						'
			                <div class="dsm-social-share-button-icon">
						       <span class="dsm_icon et-pb-icon"></span>
						    </div>
							%1$s
						    ',
						'on' === $parent_dsm_label || '' === $parent_dsm_label ? sprintf(
							'
							    <div class="dsm-social-share-button-text">
						          <span class="dsm-text">%1$s</span>
						        </div>',
							'' === trim( $dsm_custom_label ) ? 'Pocket' : $dsm_custom_label
						) : '',
						'on' === $dsm_custom_image_icon ? sprintf(
							'%1$s',
							$images_output
						) : '<span class="dsm_icon et-pb-icon"></span>'
					) : '',
					'icon' === $parent_view ? sprintf(
						'
			                <div class="dsm-social-share-button-icon">
							%1$s						    </div>',
						'on' === $dsm_custom_image_icon ? sprintf(
							'<span class="dsm_icon et-pb-icon">%1$s</span>
									  ',
							$images_output
						) : '<span class="dsm_icon et-pb-icon"></span>'
					) : '',
					'text' === $parent_view ? sprintf(
						'
						    <div class="dsm-social-share-button-text">
						      <span class="dsm-text">%1$s</span>
						    </div>',
						'' === trim( $dsm_custom_label ) ? 'Pocket' : $dsm_custom_label
					) : '',
					'current_page' === $parent_target_type ? 'https://getpocket.com/edit?url=' . esc_url( self::get_current_page_url() ) : 'https://getpocket.com/edit?url=' . esc_url( $parent_target_url ),
					$button_hover_animation
				);
				break;

			case 'xing':
				$social_share_button_value = sprintf(
					'<div class="dsm-social-share-button-inner-wrapper dsm-xing %5$s" data-share_url="%4$s">
						    %1$s
							%2$s
							%3$s
						</div>
			   ',
					'icon_text' === $parent_view || '' === $parent_view ? sprintf(
						'<div class="dsm-social-share-button-icon">
						       <span class="dsm_icon et-pb-icon"></span>
						    </div>
						    %1$s
							',
						'on' === $parent_dsm_label || '' === $parent_dsm_label ? sprintf(
							'
							    <div class="dsm-social-share-button-text">
						          <span class="dsm-text">%1$s</span>
						        </div>',
							'' === trim( $dsm_custom_label ) ? 'Xing' : $dsm_custom_label
						) : '',
						'on' === $dsm_custom_image_icon ? sprintf(
							'<span class="dsm_icon et-pb-icon">%1$s</span>
							',
							$images_output
						) : '<span class="dsm_icon et-pb-icon"></span>'
					) : '',
					'icon' === $parent_view ? sprintf(
						'
			                <div class="dsm-social-share-button-icon">
							%1$s						    </div>',
						'on' === $dsm_custom_image_icon ? sprintf(
							'%1$s',
							$images_output
						) : '<span class="dsm_icon et-pb-icon"></span>'
					) : '',
					'text' === $parent_view ? sprintf(
						'
						    <div class="dsm-social-share-button-text">
						      <span class="dsm-text">%1$s</span>
						    </div>',
						'' === trim( $dsm_custom_label ) ? 'Xing' : $dsm_custom_label
					) : '',
					'current_page' === $parent_target_type ? 'https://www.xing.com/spi/shares/new?url=' . esc_url( self::get_current_page_url() ) : 'https://www.xing.com/spi/shares/new?url=' . esc_url( $parent_target_url ),
					$button_hover_animation
				);
				break;

			case 'whatsapp':
				$social_share_button_value = sprintf(
					'<div class="dsm-social-share-button-inner-wrapper dsm-whatsapp %5$s" data-share_url="%4$s">
						%1$s
						%2$s
						%3$s
					</div>',
					'icon_text' === $parent_view || '' === $parent_view ? sprintf(
						'
				            <div class="dsm-social-share-button-icon">
						       <span class="dsm_icon et-pb-icon"></span>
						    </div>
							%1$s
						    ',
						'on' === $parent_dsm_label || '' === $parent_dsm_label ? sprintf(
							'
							    <div class="dsm-social-share-button-text">
						          <span class="dsm-text">%1$s</span>
						        </div>',
							'' === trim( $dsm_custom_label ) ? 'Whatsapp' : $dsm_custom_label
						) : '',
						'on' === $dsm_custom_image_icon ? sprintf(
							'%1$s',
							$images_output
						) : '<span class="dsm_icon et-pb-icon"></span>'
					) : '',
					'icon' === $parent_view ? sprintf(
						'
				            <div class="dsm-social-share-button-icon">
							%1$s						    </div>',
						'on' === $dsm_custom_image_icon ? sprintf(
							'<span class="dsm_icon et-pb-icon">%1$s</span>
									  ',
							$images_output
						) : '<span class="dsm_icon et-pb-icon"></span>'
					) : '',
					'text' === $parent_view ? sprintf(
						'<div class="dsm-social-share-button-text">
						      <span class="dsm-text">%1$s</span>
						    </div>',
						'' === trim( $dsm_custom_label ) ? 'Whatsapp' : $dsm_custom_label
					) : '',
					'current_page' === $parent_target_type ? 'https://api.whatsapp.com/send?text=**' . esc_url( self::get_current_page_url() ) : 'https://api.whatsapp.com/send?text=**' . esc_url( $parent_target_url ),
					$button_hover_animation
				);
				break;

			case 'email':
				if ( isset( $_SERVER['REQUEST_URI'] ) ) {
					$request_uri = esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) );
				}
				$social_share_button_value = sprintf(
					'
			            <div class="dsm-social-share-button-inner-wrapper dsm-email %5$s" data-share_url="%4$s">
						    %1$s
							%2$s
							%3$s
						</div>
			   ',
					'icon_text' === $parent_view || '' === $parent_view ? sprintf(
						'
			                <div class="dsm-social-share-button-icon">
						       <span class="dsm_icon et-pb-icon"></span>
						    </div>
							%1$s
						    ',
						'on' === $parent_dsm_label || '' === $parent_dsm_label ? sprintf(
							'
							    <div class="dsm-social-share-button-text">
						          <span class="dsm-text">%1$s</span>
						        </div>',
							'' === trim( $dsm_custom_label ) ? 'Email' : $dsm_custom_label
						) : '',
						'on' === $dsm_custom_image_icon ? sprintf(
							'%1$s',
							$images_output
						) : '<span class="dsm_icon et-pb-icon"></span>'
					) : '',
					'icon' === $parent_view ? sprintf(
						'
			                <div class="dsm-social-share-button-icon">
							%1$s						    </div>',
						'on' === $dsm_custom_image_icon ? sprintf(
							'<span class="dsm_icon et-pb-icon">%1$s</span>
									  ',
							$images_output
						) : '<span class="dsm_icon et-pb-icon"></span>'
					) : '',
					'text' === $parent_view ? sprintf(
						'
						    <div class="dsm-social-share-button-text">
						      <span class="dsm-text">%1$s</span>
						    </div>',
						'' === trim( $dsm_custom_label ) ? 'Email' : $dsm_custom_label
					) : '',
					'current_page' === $parent_target_type ? 'mailto:?body=' . esc_url( self::get_current_page_url() ) : 'mailto:?body=' . esc_url( $parent_target_url ),
					$button_hover_animation
				);
				break;

			case 'print':
				$social_share_button_value = sprintf(
					'<div class="dsm-social-share-button-inner-wrapper dsm-print %4$s">
						%1$s
						%2$s
						%3$s
					  </div>',
					'icon_text' === $parent_view || '' === $parent_view ? sprintf(
						'<div class="dsm-social-share-button-icon">
						       <span class="dsm_icon et-pb-icon"></span>
						    </div>
						     %1$s
							',
						'on' === $parent_dsm_label || '' === $parent_dsm_label ? sprintf(
							'
							    <div class="dsm-social-share-button-text">
						          <span class="dsm-text">%1$s</span>
						        </div>',
							'' === trim( $dsm_custom_label ) ? 'Print' : $dsm_custom_label
						) : '',
						'on' === $dsm_custom_image_icon ? sprintf(
							'%1$s',
							$images_output
						) : '<span class="dsm_icon et-pb-icon"></span>'
					) : '',
					'icon' === $parent_view ? sprintf(
						'
			                <div class="dsm-social-share-button-icon">
							%1$s						    </div>',
						'on' === $dsm_custom_image_icon ? sprintf(
							'<span class="dsm_icon et-pb-icon">%1$s</span>
									  ',
							$images_output
						) : '<span class="dsm_icon et-pb-icon"></span>'
					) : '',
					'text' === $parent_view ? sprintf(
						'
						    <div class="dsm-social-share-button-text">
						      <span class="dsm-text">%1$s</span>
						    </div>',
						'' === trim( $dsm_custom_label ) ? 'Print' : $dsm_custom_label
					) : '',
					$button_hover_animation
				);
				break;

			default:
				$social_share_button_value = '';
				break;
		}

		$container = sprintf(
			'%1$s',
			$social_share_button_value
		);

		// Module Inner.
		// Essentially, this is the module content.
		// Were wrapping the title and content in a div with class `et_pb_module_inner`.
		$module_inner = HTMLUtility::render(
			array(
				'tag'               => 'div',
				'attributes'        => array(
					'class' => 'et_pb_module_inner',
				),
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $container,
			)
		);

		// This are the module elements that will be rendered in the frontend.
		$module_elements = $elements->style_components(
			array(
				'attrName' => 'module',
			)
		);

		// This are the children of the module container, which are the module elements and the module inner.
		$module_container_children = $module_elements . $module_inner;

		return Module::render(
			array(
				// FE only.
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],
				// VB equivalent.
				'attrs'               => $attrs,
				'elements'            => $elements,
				'id'                  => $block->parsed_block['id'],
				'name'                => $block->block_type->name,
				'classnamesFunction'  => array( self::class, 'module_classnames' ),
				'moduleCategory'      => $block->block_type->category,
				'stylesComponent'     => array( self::class, 'module_styles' ),
				'scriptDataComponent' => array( self::class, 'module_script_data' ),
				'children'            => $module_container_children,
			)
		);
	}
}
