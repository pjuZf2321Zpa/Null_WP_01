<?php
/**
 * Supreme Flipbox (D5): single module with front/back faces (D4 parent + two children).
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Modules;

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\Module\Options\Element\ElementClassnames;
use ET\Builder\Packages\Module\Options\Text\TextClassnames;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\Packages\ModuleUtils\ModuleUtils;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\Module\Options\Button\ButtonComponent;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\StyleLibrary\Declarations\Declarations;
use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;
use DiviSupreme\Includes\Divi5Conversion\ConversionAttrs;
use DiviSupreme\Extensions\IconLibraries\IconGlyphRenderer;
use DiviSupreme\Extensions\IconLibraries\IconLibraryRegistry;
use DiviSupreme\Extensions\IconLibraries\LegacyModuleIconStyles;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Flipbox module (dsm/flipbox).
 */
class FlipboxPerk implements DependencyInterface {

	/**
	 * Register hooks.
	 */
	public function load(): void {
		add_action( 'init', array( self::class, 'register_module' ) );
	}

	/**
	 * Register with Divi 5.
	 */
	public static function register_module(): void {
		$module_json_path = DSM_DIR_PATH . 'divi-5/public/packages/module-library/flipbox-perk';

		ModuleRegistration::register_module(
			$module_json_path,
			array(
				'render_callback' => array( self::class, 'render_callback' ),
			)
		);
	}

	/**
	 * Registers module script data (Design → Animation, interactions) for the frontend.
	 *
	 * Without this, scroll/entrance animations do not run on the live site — see {@see \DiviSupreme\Modules\Card::module_script_data}.
	 *
	 * @param array<string, mixed> $args Args.
	 */
	public static function module_script_data( array $args ): void {
		$elements = $args['elements'];
		$elements->script_data(
			array(
				'attrName' => 'module',
			)
		);
		$elements->script_data(
			array(
				'attrName' => 'front_text',
			)
		);
		$elements->script_data(
			array(
				'attrName' => 'back_text',
			)
		);
		$elements->script_data(
			array(
				'attrName' => 'front_face',
			)
		);
		$elements->script_data(
			array(
				'attrName' => 'back_face',
			)
		);
	}

	/**
	 * Module classnames.
	 *
	 * @param array<string, mixed> $args Args.
	 */
	public static function module_classnames( array $args ): void {
		$classnames_instance = $args['classnamesInstance'] ?? null;
		if ( ! $classnames_instance instanceof ElementClassnames ) {
			return;
		}
		$attrs             = $args['attrs'] ?? array();
		$module_decoration = isset( $attrs['module']['decoration'] ) && is_array( $attrs['module']['decoration'] )
			? $attrs['module']['decoration']
			: array();
		$module_link       = isset( $attrs['module']['advanced']['link'] ) && is_array( $attrs['module']['advanced']['link'] )
			? $attrs['module']['advanced']['link']
			: array();

		// Match {@see \DiviSupreme\Modules\Card::module_classnames} / flipbox-perk edit.js elementClassnames.
		$classnames_instance->add(
			ElementClassnames::classnames(
				array(
					'attrs' => array_merge(
						$module_decoration,
						array(
							'link' => $module_link,
						)
					),
				)
			)
		);
		$classnames_instance->add( 'dsm_flipbox' );
	}

	/**
	 * Merge breakpoint maps for TextGroup `value` objects (VB partial updates + advanced defaults).
	 *
	 * @param array<string, mixed> $base     Typically `advanced.text.text`.
	 * @param array<string, mixed> $override Typically `*_text.text` breakpoint map.
	 * @return array<string, mixed>
	 */
	private static function merge_flip_text_breakpoint_maps( array $base, array $override ): array {
		$out = array();
		foreach ( array( 'desktop', 'tablet', 'phone' ) as $bp ) {
			$b = isset( $base[ $bp ] ) && is_array( $base[ $bp ] ) ? $base[ $bp ] : array();
			$o = isset( $override[ $bp ] ) && is_array( $override[ $bp ] ) ? $override[ $bp ] : array();
			if ( empty( $b ) && empty( $o ) ) {
				continue;
			}
			$bv              = isset( $b['value'] ) && is_array( $b['value'] ) ? $b['value'] : array();
			$ov              = isset( $o['value'] ) && is_array( $o['value'] ) ? $o['value'] : array();
			$merged          = array_merge( $b, $o );
			$merged['value'] = array_merge( $bv, $ov );
			$out[ $bp ]      = $merged;
		}
		return $out;
	}

	/**
	 * Flat breakpoint map from `*_text.text` / `advanced.text.text` (may be nested `{ text: { desktop… } }`).
	 *
	 * @param array<string, mixed> $node Raw branch.
	 * @return array<string, mixed>|null
	 */
	private static function unwrap_flip_text_breakpoint_map( array $node ): ?array {
		if ( isset( $node['text'] ) && is_array( $node['text'] ) ) {
			$inner = $node['text'];
			if ( isset( $inner['desktop'] ) || isset( $inner['tablet'] ) || isset( $inner['phone'] ) ) {
				return $inner;
			}
			$nested = self::unwrap_flip_text_breakpoint_map( $inner );
			if ( null !== $nested ) {
				return $nested;
			}
		}
		if ( isset( $node['desktop'] ) || isset( $node['tablet'] ) || isset( $node['phone'] ) ) {
			return $node;
		}
		return null;
	}

	/**
	 * Pick `textShadow` for `divi/text` (`TextStyle::style` reads `attr['textShadow']`).
	 *
	 * @param array<string, mixed>      $attrs     Module attrs.
	 * @param string                    $text_key  `front_text` / `back_text`.
	 * @param string                    $face_key  `front_face` / `back_face`.
	 * @param array<string, mixed>|null $adv_text  `advanced.text` from `*_text`.
	 * @param array<string, mixed>|null $adv_face  `advanced.text` from `*_face`.
	 * @return array<string, mixed>
	 */
	private static function flipbox_pick_face_text_shadow( array $attrs, string $text_key, string $face_key, ?array $adv_text, ?array $adv_face ): array {
		$candidates = array(
			isset( $attrs[ $text_key ]['textShadow'] ) && is_array( $attrs[ $text_key ]['textShadow'] ) ? $attrs[ $text_key ]['textShadow'] : null,
			is_array( $adv_text ) && isset( $adv_text['textShadow'] ) && is_array( $adv_text['textShadow'] ) ? $adv_text['textShadow'] : null,
			isset( $attrs[ $face_key ]['textShadow'] ) && is_array( $attrs[ $face_key ]['textShadow'] ) ? $attrs[ $face_key ]['textShadow'] : null,
			is_array( $adv_face ) && isset( $adv_face['textShadow'] ) && is_array( $adv_face['textShadow'] ) ? $adv_face['textShadow'] : null,
		);
		foreach ( $candidates as $candidate ) {
			if ( is_array( $candidate ) && array() !== $candidate ) {
				return $candidate;
			}
		}

		return array();
	}

	/**
	 * Merge `textShadow` onto the `divi/text` attr bag (non-mutating when merging into shared arrays).
	 *
	 * @param array<string, mixed>      $result    Resolved `{ text?: … }` / `advanced.text` slice.
	 * @param array<string, mixed>      $attrs     Module attrs.
	 * @param string                    $text_key  `front_text` / `back_text`.
	 * @param string                    $face_key  `front_face` / `back_face`.
	 * @param array<string, mixed>|null $adv_text  `advanced.text` from `*_text`.
	 * @param array<string, mixed>|null $adv_face  `advanced.text` from `*_face`.
	 * @return array<string, mixed>
	 */
	private static function flipbox_with_face_text_shadow( array $result, array $attrs, string $text_key, string $face_key, ?array $adv_text, ?array $adv_face ): array {
		$shadow = self::flipbox_pick_face_text_shadow( $attrs, $text_key, $face_key, $adv_text, $adv_face );
		if ( array() === $shadow ) {
			return $result;
		}

		return array_merge( $result, array( 'textShadow' => $shadow ) );
	}

	/**
	 * Advanced text for TextGroup / `divi/text` (`text` + `textShadow` for {@see \ET\Builder\Packages\Module\Options\Text\TextStyle::style}).
	 * Merges VB `*_text.text` with `advanced.text.text` when both exist.
	 *
	 * @param array<string, mixed> $attrs Full module attrs.
	 * @param string               $prefix `front` or `back`.
	 * @return array<string, mixed>
	 */
	private static function get_flip_face_text_adv_text_attr( array $attrs, string $prefix ): array {
		$text_key = "{$prefix}_text";
		$face_key = "{$prefix}_face";

		$adv_text = isset( $attrs[ $text_key ]['advanced']['text'] ) && is_array( $attrs[ $text_key ]['advanced']['text'] )
			? $attrs[ $text_key ]['advanced']['text']
			: null;
		$adv_face = isset( $attrs[ $face_key ]['advanced']['text'] ) && is_array( $attrs[ $face_key ]['advanced']['text'] )
			? $attrs[ $face_key ]['advanced']['text']
			: null;

		$raw_base = null;
		if ( is_array( $adv_text ) && isset( $adv_text['text'] ) && is_array( $adv_text['text'] ) ) {
			$raw_base = $adv_text['text'];
		} elseif ( is_array( $adv_face ) && isset( $adv_face['text'] ) && is_array( $adv_face['text'] ) ) {
			$raw_base = $adv_face['text'];
		}

		$vb_raw = null;
		if ( isset( $attrs[ $text_key ]['text'] ) && is_array( $attrs[ $text_key ]['text'] ) ) {
			$vb_raw = $attrs[ $text_key ]['text'];
		} elseif ( isset( $attrs[ $face_key ]['text'] ) && is_array( $attrs[ $face_key ]['text'] ) ) {
			$vb_raw = $attrs[ $face_key ]['text'];
		}

		$base_map = is_array( $raw_base ) ? self::unwrap_flip_text_breakpoint_map( $raw_base ) : null;
		$vb_map   = is_array( $vb_raw ) ? self::unwrap_flip_text_breakpoint_map( $vb_raw ) : null;

		if ( $vb_map && is_array( $base_map ) ) {
			$result = array( 'text' => self::merge_flip_text_breakpoint_maps( $base_map, $vb_map ) );
		} elseif ( $vb_map ) {
			$result = array( 'text' => $vb_map );
		} elseif ( is_array( $adv_text ) && isset( $adv_text['text'] ) ) {
			$inner  = self::unwrap_flip_text_breakpoint_map( $adv_text['text'] );
			$result = null !== $inner ? array( 'text' => $inner ) : $adv_text;
		} elseif ( is_array( $adv_face ) && isset( $adv_face['text'] ) ) {
			$inner  = self::unwrap_flip_text_breakpoint_map( $adv_face['text'] );
			$result = null !== $inner ? array( 'text' => $inner ) : $adv_face;
		} else {
			$result = is_array( $adv_text ) ? $adv_text : ( is_array( $adv_face ) ? $adv_face : array() );
		}

		return self::flipbox_with_face_text_shadow( $result, $attrs, $text_key, $face_key, $adv_text, $adv_face );
	}

	/**
	 * Icon slot (image vs font icon) for layout + font-family CSS. Use Icon toggle only — leftover font_icon unicode must not force icon mode.
	 *
	 * @param array<string, mixed> $attrs  Module attrs.
	 * @param string               $prefix front|back.
	 */
	private static function flipbox_face_icon_slot_active( array $attrs, string $prefix ): bool {
		return 'on' === self::inner_desktop_string( $attrs, "{$prefix}_use_icon", 'off' );
	}

	/**
	 * Content → Settings: “Automatic” uses content-based height (grid + intrinsic faces); see `dsm-flipbox--auto-height` in common.scss.
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 */
	private static function flipbox_height_mode_is_auto( array $attrs ): bool {
		return 'auto' === self::inner_desktop_string( $attrs, 'flipbox_height_mode', 'fixed' );
	}

	/**
	 * When container height is Automatic, drop `module.decoration.sizing.*.value.height` so Design → Sizing does not lock `.dsm-flipbox` to a pixel height (restores content-driven layout).
	 *
	 * @param array<string, mixed> $attrs Module attrs (by reference; cloned before use in callers).
	 */
	private static function strip_flipbox_module_sizing_height_when_auto( array &$attrs ): void {
		if ( ! self::flipbox_height_mode_is_auto( $attrs ) ) {
			return;
		}
		if ( ! isset( $attrs['module']['decoration']['sizing'] ) || ! is_array( $attrs['module']['decoration']['sizing'] ) ) {
			return;
		}
		$sizing = &$attrs['module']['decoration']['sizing'];
		$bps    = array( 'desktop', 'tablet', 'phone', 'phoneWide' );
		foreach ( $bps as $bp ) {
			if ( ! isset( $sizing[ $bp ]['value'] ) || ! is_array( $sizing[ $bp ]['value'] ) ) {
				continue;
			}
			unset( $sizing[ $bp ]['value']['height'] );
		}
	}

	/**
	 * Deep-clone attrs so merge/strip for styles does not mutate stored block attrs.
	 *
	 * @param array<string, mixed> $attrs Raw attrs.
	 * @return array<string, mixed>
	 */
	private static function clone_attrs_array( array $attrs ): array {
		$json = wp_json_encode( $attrs );
		if ( false === $json ) {
			return $attrs;
		}
		$decoded = json_decode( $json, true );

		return is_array( $decoded ) ? $decoded : $attrs;
	}

	/**
	 * Styles component.
	 *
	 * @param array<string, mixed> $args Args.
	 */
	public static function module_styles( array $args ): void {
		$args  = \DiviSupreme\Includes\DsmDiviBuilderCssScope::normalize_module_styles_args( $args );
		$attrs = self::clone_attrs_array( $args['attrs'] ?? array() );
		$attrs = ConversionAttrs::merge_flipbox_legacy_height_into_module_sizing( $attrs, false );
		ConversionAttrs::mirror_flipbox_phone_module_sizing_height_to_phone_wide_when_empty( $attrs );
		self::strip_flipbox_module_sizing_height_when_auto( $attrs );
		$elements = $args['elements'];

		$front_icon_slot          = self::flipbox_face_icon_slot_active( $attrs, 'front' );
		$back_icon_slot           = self::flipbox_face_icon_slot_active( $attrs, 'back' );
		$front_use_circle         = 'on' === self::inner_desktop_string( $attrs, 'front_use_circle', 'off' );
		$back_use_circle          = 'on' === self::inner_desktop_string( $attrs, 'back_use_circle', 'off' );
		$front_use_circle_border  = $front_use_circle && 'on' === self::inner_desktop_string( $attrs, 'front_use_circle_border', 'off' );
		$back_use_circle_border   = $back_use_circle && 'on' === self::inner_desktop_string( $attrs, 'back_use_circle_border', 'off' );
		$front_use_icon_font_size = 'on' === self::inner_desktop_string( $attrs, 'front_use_icon_font_size', 'off' );
		$back_use_icon_font_size  = 'on' === self::inner_desktop_string( $attrs, 'back_use_icon_font_size', 'off' );
		$front_button_align_attr  = self::flipbox_button_decoration_alignment_inner_content_for_style( $attrs, 'front_button' );
		$back_button_align_attr   = self::flipbox_button_decoration_alignment_inner_content_for_style( $attrs, 'back_button' );

		Style::add(
			array(
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => array(
					// Match {@see \ET\Builder\Packages\ModuleLibrary\Blurb\BlurbModule::module_styles}: explicit
					// divi/background + border/overflow on `module` so Design → spacing/transform/background apply
					// to the root (VB + frontend both use the same style pipeline).
					$elements->style(
						array(
							'attrName'   => 'module',
							'styleProps' => array(
								'disabledOn'     => array(
									'disabledModuleVisibility' => $args['settings']['disabledModuleVisibility'] ?? null,
								),
								'advancedStyles' => array(
									array(
										'componentName' => 'divi/background',
										'props'         => array(
											'attr' => $attrs['module']['decoration']['background'] ?? array(),
										),
									),
									array(
										'componentName' => 'divi/common',
										'props'         => array(
											'attr' => $attrs['module']['decoration']['border'] ?? array(),
											'declarationFunction' => function ( $params ) use ( $attrs ) {
												$overflow_attr = $attrs['module']['decoration']['overflow'] ?? array();
												return Declarations::overflow_for_border_radius_style_declaration( $params, $overflow_attr );
											},
										),
									),
								),
							),
						)
					),
					$elements->style(
						array(
							'attrName'   => 'front_text',
							'styleProps' => array(
								'advancedStyles' => array(
									array(
										'componentName' => 'divi/text',
										'props'         => array(
											'selector' => "{$args['orderClass']} .dsm-flipbox-face-front .dsm_flipbox_wrapper",
											'attr'     => self::get_flip_face_text_adv_text_attr( $attrs, 'front' ),
										),
									),
								),
							),
						)
					),
					$elements->style(
						array(
							'attrName'   => 'back_text',
							'styleProps' => array(
								'advancedStyles' => array(
									array(
										'componentName' => 'divi/text',
										'props'         => array(
											'selector' => "{$args['orderClass']} .dsm-flipbox-face-back .dsm_flipbox_wrapper",
											'attr'     => self::get_flip_face_text_adv_text_attr( $attrs, 'back' ),
										),
									),
								),
							),
						)
					),
					CssStyle::style(
						array(
							'selector' => $args['orderClass'],
							'attr'     => $attrs['css'] ?? array(),
						)
					),
					! $front_icon_slot ?
					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-flipbox-face-front .dsm_flipbox_child_image_wrap",
							'attr'     => $attrs['front_image_max_width']['innerContent'] ?? array(),
							'property' => 'max-width',
						)
					) : '',
					! $back_icon_slot ?
					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-flipbox-face-back .dsm_flipbox_child_image_wrap",
							'attr'     => $attrs['back_image_max_width']['innerContent'] ?? array(),
							'property' => 'max-width',
						)
					) : '',
					$elements->style( array( 'attrName' => 'face_style' ) ),
					$elements->style( array( 'attrName' => 'face_title' ) ),
					$elements->style( array( 'attrName' => 'face_subtitle' ) ),
					$elements->style( array( 'attrName' => 'face_content' ) ),
					// Face decoration (background, spacing, border, …) from module.json `front_face` / `back_face`.
					$elements->style( array( 'attrName' => 'front_face' ) ),
					$elements->style( array( 'attrName' => 'back_face' ) ),
					$elements->style( array( 'attrName' => 'front_image_style' ) ),
					$elements->style( array( 'attrName' => 'back_image_style' ) ),
					$elements->style( array( 'attrName' => 'front_icon_style' ) ),
					$elements->style( array( 'attrName' => 'back_icon_style' ) ),
					$front_icon_slot ?
					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm-flipbox-face-front .dsm_flipbox_child_image .et-pb-icon",
							'attr'                => $attrs['front_font_icon']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'flipbox_icon_font_declaration' ),
						)
					) : '',
					$back_icon_slot ?
					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm-flipbox-face-back .dsm_flipbox_child_image .et-pb-icon",
							'attr'                => $attrs['back_font_icon']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'flipbox_icon_font_declaration' ),
						)
					) : '',
					$elements->style( array( 'attrName' => 'front_title' ) ),
					$elements->style( array( 'attrName' => 'back_title' ) ),
					$elements->style( array( 'attrName' => 'front_subtitle' ) ),
					$elements->style( array( 'attrName' => 'back_subtitle' ) ),
					$elements->style( array( 'attrName' => 'front_content' ) ),
					$elements->style( array( 'attrName' => 'back_content' ) ),
					$elements->style( array( 'attrName' => 'front_button' ) ),
					$elements->style( array( 'attrName' => 'back_button' ) ),

					( ! empty( $front_button_align_attr['innerContent'] )
						? CommonStyle::style(
							array(
								'selector'            => "{$args['orderClass']} .dsm-flipbox-face-front .et_pb_button_module_wrapper",
								'attr'                => $front_button_align_attr,
								'declarationFunction' => array( self::class, 'flipbox_button_wrapper_align_declaration' ),
							)
						)
						: '' ),
					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm-flipbox-face-front .et_pb_button_module_wrapper",
							'attr'                => $attrs['front_button']['decoration']['sizing'] ?? array(),
							'declarationFunction' => array( self::class, 'flipbox_button_sizing_alignment_wrapper_declaration' ),
						)
					),
					( ! empty( $back_button_align_attr['innerContent'] )
						? CommonStyle::style(
							array(
								'selector'            => "{$args['orderClass']} .dsm-flipbox-face-back .et_pb_button_module_wrapper",
								'attr'                => $back_button_align_attr,
								'declarationFunction' => array( self::class, 'flipbox_button_wrapper_align_declaration' ),
							)
						)
						: '' ),
					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm-flipbox-face-back .et_pb_button_module_wrapper",
							'attr'                => $attrs['back_button']['decoration']['sizing'] ?? array(),
							'declarationFunction' => array( self::class, 'flipbox_button_sizing_alignment_wrapper_declaration' ),
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-flipbox-face-front .dsm_flipbox_child_image .et-pb-icon",
							'attr'     => $attrs['front_icon_color']['innerContent'] ?? array(),
							'property' => 'color',
						)
					),
					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-flipbox-face-back .dsm_flipbox_child_image .et-pb-icon",
							'attr'     => $attrs['back_icon_color']['innerContent'] ?? array(),
							'property' => 'color',
						)
					),

					$front_use_icon_font_size ?
					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-flipbox-face-front .dsm_flipbox_child_image .et-pb-icon",
							'attr'     => $attrs['front_icon_font_size']['innerContent'] ?? array(),
							'property' => 'font-size',
						)
					) : '',
					$back_use_icon_font_size ?
					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-flipbox-face-back .dsm_flipbox_child_image .et-pb-icon",
							'attr'     => $attrs['back_icon_font_size']['innerContent'] ?? array(),
							'property' => 'font-size',
						)
					) : '',

					$front_use_circle ?
					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm-flipbox-face-front .dsm_flipbox_child_image .et-pb-icon",
							'attr'                => $attrs['front_use_circle']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'flipbox_icon_circle_shape_declaration' ),
						)
					) : '',
					$back_use_circle ?
					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm-flipbox-face-back .dsm_flipbox_child_image .et-pb-icon",
							'attr'                => $attrs['back_use_circle']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'flipbox_icon_circle_shape_declaration' ),
						)
					) : '',

					$front_use_circle ?
					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm-flipbox-face-front .dsm_flipbox_child_image .et-pb-icon",
							'attr'                => $attrs['front_circle_color']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'flipbox_icon_circle_fill_declaration' ),
						)
					) : '',
					$back_use_circle ?
					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm-flipbox-face-back .dsm_flipbox_child_image .et-pb-icon",
							'attr'                => $attrs['back_circle_color']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'flipbox_icon_circle_fill_declaration' ),
						)
					) : '',

					$front_use_circle_border ?
					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm-flipbox-face-front .dsm_flipbox_child_image .et-pb-icon",
							'attr'                => $attrs['front_circle_border_color']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'flipbox_icon_border_declaration' ),
						)
					) : '',
					$back_use_circle_border ?
					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm-flipbox-face-back .dsm_flipbox_child_image .et-pb-icon",
							'attr'                => $attrs['back_circle_border_color']['innerContent'] ?? array(),
							'declarationFunction' => array( static::class, 'flipbox_icon_border_declaration' ),
						)
					) : '',
				),
			)
		);
	}

	/**
	 * Build innerContent-shaped attr for face button wrapper alignment (matches module-styles.js).
	 *
	 * @param array<string, mixed> $attrs     Module attrs.
	 * @param string               $attr_name `front_button` or `back_button`.
	 * @return array<string, mixed>
	 */
	private static function flipbox_button_decoration_alignment_inner_content_for_style( array $attrs, string $attr_name ): array {
		$button_attr = $attrs[ $attr_name ] ?? null;
		if ( ! is_array( $button_attr ) ) {
			return array( 'innerContent' => array() );
		}

		$sizing = $button_attr['decoration']['sizing'] ?? null;
		$button = $button_attr['decoration']['button'] ?? null;

		$inner_content = array();
		foreach ( array( 'desktop', 'tablet', 'phone' ) as $bp ) {
			$raw = '';

			if ( is_array( $sizing ) && isset( $sizing[ $bp ]['value'] ) && is_array( $sizing[ $bp ]['value'] ) ) {
				$alignment = $sizing[ $bp ]['value']['alignment'] ?? '';
				if ( is_string( $alignment ) && '' !== trim( $alignment ) ) {
					$raw = $alignment;
				}
			}

			if ( '' === trim( (string) $raw ) && is_array( $button ) && isset( $button[ $bp ]['value'] ) && is_array( $button[ $bp ]['value'] ) ) {
				$value = $button[ $bp ]['value'];
				$raw   = $value['textAlign'] ?? $value['alignment'] ?? '';
			}

			if ( ! is_string( $raw ) || '' === trim( $raw ) ) {
				continue;
			}
			$lower = strtolower( trim( $raw ) );
			if ( in_array( $lower, array( 'left', 'center', 'right' ), true ) ) {
				$inner_content[ $bp ] = array( 'value' => $lower );
			}
		}

		return array( 'innerContent' => $inner_content );
	}

	/**
	 * Resolve face button alignment slug for wrapper classnames.
	 *
	 * @param array<string, mixed> $attrs     Module attrs.
	 * @param string               $prefix    `front` or `back`.
	 * @return string Empty or `left` | `center` | `right`.
	 */
	private static function flipbox_resolve_button_alignment( array $attrs, string $prefix ): string {
		$attr_name   = 'front' === $prefix ? 'front_button' : 'back_button';
		$inner       = self::flipbox_button_decoration_alignment_inner_content_for_style( $attrs, $attr_name );
		$desktop_val = $inner['innerContent']['desktop']['value'] ?? '';

		if ( is_string( $desktop_val ) && in_array( $desktop_val, array( 'left', 'center', 'right' ), true ) ) {
			return $desktop_val;
		}

		foreach ( array( 'tablet', 'phone' ) as $bp ) {
			$val = $inner['innerContent'][ $bp ]['value'] ?? '';
			if ( is_string( $val ) && in_array( $val, array( 'left', 'center', 'right' ), true ) ) {
				return $val;
			}
		}

		return '';
	}

	/**
	 * Wrapper alignment from `decoration.sizing` (Divi ButtonGroup alignment field).
	 *
	 * @param array<string, mixed> $params CommonStyle params.
	 * @return string
	 */
	public static function flipbox_button_sizing_alignment_wrapper_declaration( array $params ): string {
		$attr_value = $params['attrValue'] ?? array();
		$alignment  = is_array( $attr_value ) ? ( $attr_value['alignment'] ?? '' ) : '';

		if ( ! is_string( $alignment ) || '' === trim( $alignment ) ) {
			return '';
		}

		return self::flipbox_button_wrapper_align_declaration(
			array(
				'attrValue' => strtolower( trim( $alignment ) ),
			)
		);
	}

	/**
	 * Wrapper alignment: text-align + margin auto (fit-content wrapper in common.scss).
	 *
	 * @param array<string, mixed> $params CommonStyle params.
	 * @return string
	 */
	public static function flipbox_button_wrapper_align_declaration( array $params ): string {
		$alignment = $params['attrValue'] ?? '';

		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
				'important'  => array(
					'text-align'   => true,
					'margin-left'  => true,
					'margin-right' => true,
					'align-self'   => true,
				),
			)
		);

		if ( 'left' === $alignment ) {
			$style_declarations->add( 'text-align', 'left' );
			$style_declarations->add( 'margin-left', '0' );
			$style_declarations->add( 'margin-right', 'auto' );
			$style_declarations->add( 'align-self', 'flex-start' );
		} elseif ( 'center' === $alignment ) {
			$style_declarations->add( 'text-align', 'center' );
			$style_declarations->add( 'margin-left', 'auto' );
			$style_declarations->add( 'margin-right', 'auto' );
			$style_declarations->add( 'align-self', 'center' );
		} elseif ( 'right' === $alignment ) {
			$style_declarations->add( 'text-align', 'right' );
			$style_declarations->add( 'margin-left', 'auto' );
			$style_declarations->add( 'margin-right', '0' );
			$style_declarations->add( 'align-self', 'flex-end' );
		}

		return $style_declarations->value();
	}

	/**
	 * Icon font-family / weight on `.et-pb-icon` (matches Card icon_style_declaration minus `content`).
	 * A catalog match is a text child. A Supreme library slug is a webfont host.
	 *
	 * @param array<string, mixed> $params Style callback params.
	 * @return string
	 */
	public static function flipbox_icon_font_declaration( array $params ): string {
		return LegacyModuleIconStyles::build_pseudo_icon_declaration( $params );
	}

	/**
	 * Circle icon shape (matches Card content_icon_circle_shape_declaration).
	 *
	 * @param array<string, mixed> $params Style callback params.
	 * @return string
	 */
	public static function flipbox_icon_circle_shape_declaration( array $params ): string {
		$important = $params['important'] ?? false;

		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
				'important'  => is_array( $important ) ? $important : array(),
			)
		);

		$style_declarations->add( 'border-radius', '50%' );
		$style_declarations->add( 'display', 'inline-flex' );
		$style_declarations->add( 'align-items', 'center' );
		$style_declarations->add( 'justify-content', 'center' );
		$style_declarations->add( 'padding', '0.35em' );
		$style_declarations->add( 'line-height', '1' );
		$style_declarations->add( 'box-sizing', 'border-box' );
		$style_declarations->add( 'vertical-align', 'middle' );
		$style_declarations->add( 'aspect-ratio', '1' );

		return $style_declarations->value();
	}

	/**
	 * Circle fill: resolve D5 color objects to CSS (matches Card content_icon_circle_fill_declaration).
	 *
	 * @param array<string, mixed> $params Style callback params.
	 * @return string
	 */
	public static function flipbox_icon_circle_fill_declaration( array $params ): string {
		$raw       = $params['attrValue'] ?? null;
		$color     = self::resolve_simple_color_css( $raw );
		$important = $params['important'] ?? false;

		if ( '' === $color ) {
			$color = '#f4f4f4';
		}

		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
				'important'  => is_array( $important ) ? $important : array(),
			)
		);

		$style_declarations->add( 'background-color', $color );

		return $style_declarations->value();
	}

	/**
	 * Circle border color (matches Card icon_border_style_declaration).
	 *
	 * @param array<string, mixed> $params Style callback params.
	 * @return string
	 */
	public static function flipbox_icon_border_declaration( array $params ): string {
		$border_color_attr = $params['attrValue'] ?? '';
		$resolved          = is_string( $border_color_attr )
			? trim( $border_color_attr )
			: self::resolve_simple_color_css( $border_color_attr );
		if ( '' === $resolved ) {
			$resolved = '#333333';
		}

		$style_declarations = new StyleDeclarations(
			array(
				'returnType' => 'string',
			)
		);

		$style_declarations->add( 'border-style', 'solid' );
		$style_declarations->add( 'border-width', '2px' );
		$style_declarations->add( 'border-color', $resolved );

		return $style_declarations->value();
	}

	/**
	 * Flatten color innerContent leaf for CSS (string hex/rgba or D5 color object).
	 *
	 * @param mixed $raw Attr value.
	 * @return string
	 */
	private static function resolve_simple_color_css( $raw ): string {
		if ( is_string( $raw ) ) {
			$t = trim( $raw );

			return '' !== $t ? $t : '';
		}

		if ( ! is_array( $raw ) ) {
			return '';
		}

		if ( isset( $raw['hex'] ) && is_string( $raw['hex'] ) && '' !== trim( $raw['hex'] ) ) {
			return trim( $raw['hex'] );
		}

		if ( isset( $raw['rgba'] ) && is_string( $raw['rgba'] ) && '' !== trim( $raw['rgba'] ) ) {
			return trim( $raw['rgba'] );
		}

		return '';
	}

	/**
	 * Parse upload innerContent value into attachment id and/or URL (for responsive image output).
	 *
	 * @param mixed $raw Raw `innerContent.desktop.value` (string URL or `{ src, id }`).
	 * @return array{id: int, src: string}
	 */
	private static function parse_upload_inner_value( $raw ): array {
		$out = array(
			'id'  => 0,
			'src' => '',
		);
		if ( is_string( $raw ) && '' !== $raw ) {
			$out['src'] = $raw;
			return $out;
		}
		if ( ! is_array( $raw ) ) {
			return $out;
		}
		if ( ! empty( $raw['src'] ) && is_string( $raw['src'] ) ) {
			$out['src'] = $raw['src'];
		}
		if ( isset( $raw['id'] ) ) {
			$out['id'] = absint( $raw['id'] );
		}
		return $out;
	}

	/**
	 * Fallback alt text for non-library image URLs (attachment images use media library alt via wp_get_attachment_image).
	 *
	 * @param array<string, mixed> $attrs   Module attrs.
	 * @param string               $prefix  front|back.
	 * @return string
	 */
	private static function get_flipbox_face_image_alt_fallback( array $attrs, string $prefix ): string {
		$title = self::get_heading_inner_text( $attrs, "{$prefix}_title" );
		$title = is_string( $title ) ? wp_strip_all_tags( $title ) : '';
		$title = trim( $title );

		return '' !== $title ? $title : '';
	}

	/**
	 * Markup for face image: uses wp_get_attachment_image (srcset/sizes) when attachment id is valid; otherwise a plain img.
	 *
	 * @param array<string, mixed> $img_data From {@see self::parse_upload_inner_value()}.
	 * @param array<string, mixed> $attrs    Module attrs.
	 * @param string               $prefix   front|back.
	 * @return string Empty when no image.
	 */
	private static function build_flipbox_face_image_html( array $img_data, array $attrs, string $prefix ): string {
		$id  = isset( $img_data['id'] ) ? absint( $img_data['id'] ) : 0;
		$src = isset( $img_data['src'] ) && is_string( $img_data['src'] ) ? trim( $img_data['src'] ) : '';

		if ( $id > 0 && wp_attachment_is_image( $id ) ) {
			$html = wp_get_attachment_image(
				$id,
				'full',
				false,
				array(
					'class'    => 'dsm-flipbox-face-img',
					'loading'  => 'lazy',
					'decoding' => 'async',
				)
			);
			if ( ! is_string( $html ) || '' === $html ) {
				return '';
			}
		} elseif ( '' !== $src ) {
			$alt  = self::get_flipbox_face_image_alt_fallback( $attrs, $prefix );
			$html = sprintf(
				'<img src="%1$s" alt="%2$s" class="dsm-flipbox-face-img" loading="lazy" decoding="async" />',
				esc_url( $src ),
				esc_attr( $alt )
			);
		} else {
			return '';
		}

		return sprintf(
			'<div class="dsm_flipbox_child_image"><span class="dsm_flipbox_child_image_wrap">%s</span></div>',
			$html
		);
	}

	/**
	 * Inner heading / body text from attrs.
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 * @param string               $key   Attribute key.
	 * @return string
	 */
	private static function get_heading_inner_text( array $attrs, string $key ): string {
		$raw = $attrs[ $key ]['innerContent']['desktop']['value'] ?? null;
		if ( is_string( $raw ) ) {
			return $raw;
		}
		if ( is_array( $raw ) && isset( $raw['text'] ) && is_string( $raw['text'] ) ) {
			return $raw['text'];
		}
		return '';
	}

	/**
	 * Desktop innerContent string (first breakpoint).
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 * @param string               $key   Attribute key.
	 * @param string               $default Default.
	 * @return string
	 */
	private static function inner_desktop_string( array $attrs, string $key, string $default = '' ): string {
		if ( ! isset( $attrs[ $key ]['innerContent'] ) ) {
			return $default;
		}
		$inner = $attrs[ $key ]['innerContent'];
		if ( is_object( $inner ) ) {
			$decoded = json_decode( wp_json_encode( $inner ), true );
			$inner   = is_array( $decoded ) ? $decoded : array();
		}
		if ( ! is_array( $inner ) ) {
			return $default;
		}
		$v = ModuleUtils::use_attr_value(
			array(
				'attr'         => $inner,
				'breakpoint'   => 'desktop',
				'state'        => 'value',
				'mode'         => 'getOrInheritAll',
				'defaultValue' => null,
			)
		);
		if ( null === $v ) {
			return $default;
		}
		if ( is_string( $v ) ) {
			return $v;
		}
		if ( is_scalar( $v ) ) {
			return (string) $v;
		}
		return $default;
	}

	/**
	 * Normalize innerContent to array (FE may decode nested objects).
	 *
	 * @param mixed $inner Raw innerContent.
	 * @return array<string, mixed>
	 */
	private static function inner_content_to_array( $inner ): array {
		if ( is_object( $inner ) ) {
			$decoded = json_decode( wp_json_encode( $inner ), true );
			return is_array( $decoded ) ? $decoded : array();
		}
		return is_array( $inner ) ? $inner : array();
	}

	/**
	 * Whether font icon value has a non-empty unicode (process_font_icon needs it).
	 *
	 * @param array<string, mixed> $arr Icon value.
	 */
	private static function font_icon_value_has_unicode( array $arr ): bool {
		if ( ! isset( $arr['unicode'] ) ) {
			return false;
		}
		$u = $arr['unicode'];
		if ( is_numeric( $u ) ) {
			return true;
		}
		return is_string( $u ) && '' !== trim( $u );
	}

	/**
	 * Some IconPicker saves match Blurb {@see \ET\Builder\Packages\ModuleLibrary\Blurb\BlurbModule}: glyph under `icon`.
	 *
	 * @param array<string, mixed> $value Resolved desktop/tablet value.
	 * @return array<string, mixed>
	 */
	private static function flatten_icon_picker_leaf( array $value ): array {
		if ( isset( $value['icon'] ) && is_array( $value['icon'] ) ) {
			$inner = self::normalize_font_icon_value( $value['icon'] );
			if ( self::font_icon_value_has_unicode( $inner ) ) {
				return $inner;
			}
		}
		if ( isset( $value['settings'] ) && is_array( $value['settings'] ) ) {
			$inner = self::normalize_font_icon_value( $value['settings'] );
			if ( self::font_icon_value_has_unicode( $inner ) ) {
				return $inner;
			}
		}
		return $value;
	}

	/**
	 * Coerce icon leaf to array for process_font_icon.
	 *
	 * @param mixed $value Resolved value.
	 * @return array<string, mixed>
	 */
	private static function normalize_font_icon_value( $value ): array {
		if ( is_object( $value ) ) {
			$decoded = json_decode( wp_json_encode( $value ), true );
			return is_array( $decoded ) ? $decoded : array();
		}
		return is_array( $value ) ? $value : array();
	}

	/**
	 * Icon picker value for `process_font_icon` (desktop.value with breakpoint inheritance + migrated shapes).
	 *
	 * @param array<string, mixed> $attrs  Module attrs.
	 * @param string               $prefix front|back.
	 * @return array<string, mixed>
	 */
	private static function get_font_icon_value_array( array $attrs, string $prefix ): array {
		$key = "{$prefix}_font_icon";
		if ( ! isset( $attrs[ $key ]['innerContent'] ) ) {
			return array();
		}
		$ic = self::inner_content_to_array( $attrs[ $key ]['innerContent'] );
		if ( array() === $ic ) {
			return array();
		}

		// Migrated / merged attrs may omit the breakpoint wrapper: innerContent = { value: { unicode, type } } only.
		// ModuleUtils::use_attr_value() looks for desktop.value first; resolve explicit shapes before inheritance.
		if ( isset( $ic['desktop']['value'] ) ) {
			$direct = self::flatten_icon_picker_leaf( self::normalize_font_icon_value( $ic['desktop']['value'] ) );
			if ( self::font_icon_value_has_unicode( $direct ) ) {
				return $direct;
			}
		}
		if ( isset( $ic['value'] ) && is_array( $ic['value'] ) ) {
			$direct = self::flatten_icon_picker_leaf( self::normalize_font_icon_value( $ic['value'] ) );
			if ( self::font_icon_value_has_unicode( $direct ) ) {
				return $direct;
			}
		}

		$resolved = ModuleUtils::use_attr_value(
			array(
				'attr'         => $ic,
				'breakpoint'   => 'desktop',
				'state'        => 'value',
				'mode'         => 'getOrInheritAll',
				'defaultValue' => null,
			)
		);
		$out      = self::flatten_icon_picker_leaf( self::normalize_font_icon_value( $resolved ) );
		if ( self::font_icon_value_has_unicode( $out ) ) {
			return $out;
		}

		// Desktop may be {} while tablet/phone hold the pick; getOrInheritAll keeps empty local value.
		foreach ( array( 'tablet', 'phone', 'phoneWide' ) as $bp ) {
			if ( ! isset( $ic[ $bp ]['value'] ) ) {
				continue;
			}
			$cand = self::flatten_icon_picker_leaf( self::normalize_font_icon_value( $ic[ $bp ]['value'] ) );
			if ( self::font_icon_value_has_unicode( $cand ) ) {
				return $cand;
			}
		}

		if ( isset( $ic['value'] ) && is_array( $ic['value'] ) ) {
			return self::flatten_icon_picker_leaf( self::normalize_font_icon_value( $ic['value'] ) );
		}
		if ( isset( $ic['unicode'] ) || isset( $ic['type'] ) ) {
			return self::flatten_icon_picker_leaf( self::normalize_font_icon_value( $ic ) );
		}

		return $out;
	}

	/**
	 * Match Divi icon picker + {@see Utils::find_icon_in_list()}: unicode, type, and weight are required.
	 * Saved layouts often omit `weight` when it matches the default (Divi omits schema-default keys), so FE SSR
	 * would otherwise get null from {@see Utils::process_font_icon()}.
	 *
	 * @param array<string, mixed> $icon Icon attr value (by ref).
	 */
	private static function normalize_icon_pick_for_process_font_icon( array &$icon ): void {
		if ( isset( $icon['unicode'] ) && ! is_string( $icon['unicode'] ) ) {
			$icon['unicode'] = (string) $icon['unicode'];
		}
		if ( isset( $icon['unicode'] ) && is_string( $icon['unicode'] ) && '' !== trim( $icon['unicode'] ) ) {
			$raw_type = isset( $icon['type'] ) ? trim( (string) $icon['type'] ) : '';
			$t        = strtolower( $raw_type );
			if ( '' === $t ) {
				$icon['type'] = 'divi';
			} elseif ( in_array( $t, array( 'solid', 'regular', 'brands' ), true ) ) {
				// FA style slots — {@see Utils::process_font_icon()} only allows `divi`|`fa` before lookup.
				$icon['type'] = 'fa';
			} elseif ( 'line' === $t ) {
				// Et icons: "line" is a style in iconList; family guard still requires `divi` or `fa`.
				$icon['type'] = 'divi';
			} elseif ( in_array( $t, array( 'divi', 'fa' ), true ) ) {
				$icon['type'] = $t;
			} else {
				$icon['type'] = 'divi';
			}
		}
		if ( ! isset( $icon['weight'] ) || '' === trim( (string) ( $icon['weight'] ?? '' ) ) ) {
			$icon['weight'] = '400';
		} elseif ( ! is_string( $icon['weight'] ) ) {
			$icon['weight'] = (string) $icon['weight'];
		}
	}

	/**
	 * Resolve glyph for SSR: prefer {@see Utils::process_font_icon()} (iconList match).
	 *
	 * When the stored `unicode` is already a decoded PUA character (or otherwise does not exactly match
	 * iconList.json entity strings), lookup returns empty — fall back to the stored unicode string so
	 * the ETmodules/FA font still renders the glyph (same visual as VB).
	 *
	 * A Supreme library slug (`hospital`) is not a glyph. Return null so the face can render the webfont host.
	 *
	 * @param array<string, mixed> $icon_raw Flattened icon picker value.
	 * @return string|null Display string for span children, or null.
	 */
	private static function resolve_flipbox_font_icon_decoded_char( array $icon_raw ): ?string {
		$work = $icon_raw;
		self::normalize_icon_pick_for_process_font_icon( $work );
		$char = Utils::process_font_icon( $work );
		if ( is_string( $char ) && '' !== $char ) {
			return $char;
		}
		if ( ! self::font_icon_value_has_unicode( $icon_raw ) ) {
			return null;
		}
		// If family guess was wrong (e.g. FA glyph saved with Et-style `line`), retry the other family.
		$work2 = $icon_raw;
		self::normalize_icon_pick_for_process_font_icon( $work2 );
		$work2['type'] = ( isset( $work2['type'] ) && 'fa' === $work2['type'] ) ? 'divi' : 'fa';
		$char          = Utils::process_font_icon( $work2 );
		if ( is_string( $char ) && '' !== $char ) {
			return $char;
		}

		if ( class_exists( IconLibraryRegistry::class ) && IconLibraryRegistry::is_dsm_library_icon( $icon_raw ) ) {
			return null;
		}

		$u = $icon_raw['unicode'] ?? '';
		if ( is_string( $u ) && '' !== trim( $u ) ) {
			return $u;
		}
		if ( is_numeric( $u ) ) {
			return (string) $u;
		}

		return null;
	}

	/**
	 * Coerce rich-text `innerContent` so `ModuleUtils::has_value` + `attrSubName` `text` never see a bare string leaf.
	 * Handles: top-level string, `desktop|tablet|phone|phoneWide` × `value|hover|sticky`, and legacy root `value`.
	 *
	 * @param array<string, mixed> $element_attr Single attr branch (`front_content` / `back_content`).
	 * @return array<string, mixed>
	 */
	private static function normalize_flipbox_face_content_element_attr( array $element_attr ): array {
		if ( ! isset( $element_attr['innerContent'] ) ) {
			return $element_attr;
		}
		$ic = $element_attr['innerContent'];
		if ( is_string( $ic ) ) {
			$element_attr['innerContent'] = array(
				'desktop' => array(
					'value' => array( 'text' => $ic ),
				),
			);

			return $element_attr;
		}
		if ( ! is_array( $ic ) ) {
			return $element_attr;
		}
		$element_attr['innerContent'] = self::normalize_inner_content_text_values_for_rich_text( $ic );

		return $element_attr;
	}

	/**
	 * Normalize rich-text innerContent leaves to the text shape.
	 *
	 * @param array<string, mixed> $ic innerContent array.
	 * @return array<string, mixed>
	 */
	private static function normalize_inner_content_text_values_for_rich_text( array $ic ): array {
		$states = array( 'value', 'hover', 'sticky' );
		$bps    = array( 'desktop', 'tablet', 'phone', 'phoneWide' );
		foreach ( $bps as $bp ) {
			if ( ! isset( $ic[ $bp ] ) || ! is_array( $ic[ $bp ] ) ) {
				continue;
			}
			foreach ( $states as $state ) {
				if ( ! isset( $ic[ $bp ][ $state ] ) ) {
					continue;
				}
				if ( is_string( $ic[ $bp ][ $state ] ) ) {
					$ic[ $bp ][ $state ] = array( 'text' => $ic[ $bp ][ $state ] );
				}
			}
		}
		if ( isset( $ic['value'] ) && is_string( $ic['value'] ) ) {
			$ic['value'] = array( 'text' => $ic['value'] );
		}

		return $ic;
	}

	/**
	 * Apply {@see self::normalize_flipbox_face_content_element_attr()} to the active face content key on full module attrs.
	 *
	 * @param array<string, mixed> $attrs  Module attrs.
	 * @param string               $prefix `front` or `back`.
	 * @return array<string, mixed>
	 */
	private static function normalize_flipbox_module_attrs_for_face_content( array $attrs, string $prefix ): array {
		$key = "{$prefix}_content";
		if ( ! isset( $attrs[ $key ] ) || ! is_array( $attrs[ $key ] ) ) {
			return $attrs;
		}
		$attrs[ $key ] = self::normalize_flipbox_face_content_element_attr( $attrs[ $key ] );

		return $attrs;
	}

	/**
	 * Coerce face title `headingLink` innerContent before `ModuleElements::render()` (legacy string leaves crash MultiView).
	 *
	 * @param array<string, mixed> $attrs Module attrs (by reference).
	 * @return void
	 */
	private static function normalize_flipbox_face_heading_attrs_for_render( array &$attrs ): void {
		foreach ( array( 'front_title', 'back_title' ) as $title_key ) {
			ConversionAttrs::normalize_inner_value_to_heading_link_text_shape( $attrs, $title_key );
		}
	}

	/**
	 * Render one face (front or back).
	 *
	 * @param array<string, mixed> $attrs             All attrs.
	 * @param mixed                $elements          Elements API.
	 * @param string               $prefix            front|back.
	 * @param string               $flipbox_trigger   hover|click (affects initial aria-hidden on faces).
	 * @return string
	 */
	private static function render_face( array $attrs, $elements, string $prefix, string $flipbox_trigger = 'hover' ): string {
		$attrs = self::normalize_flipbox_module_attrs_for_face_content( $attrs, $prefix );
		$elements->use_custom_module_attrs( $attrs );
		try {
			$icon_raw = self::get_font_icon_value_array( $attrs, $prefix );
			if ( is_object( $icon_raw ) ) {
				$icon_raw = (array) $icon_raw;
			}
			if ( ! is_array( $icon_raw ) ) {
				$icon_raw = array();
			}
			$use_icon      = 'on' === self::inner_desktop_string( $attrs, "{$prefix}_use_icon", 'off' );
			$icon_resolved = self::resolve_flipbox_font_icon_decoded_char( $icon_raw );
			$icon_char     = is_string( $icon_resolved ) ? $icon_resolved : '';
			$img_raw       = $attrs[ "{$prefix}_image" ]['innerContent']['desktop']['value'] ?? '';
			$img_data      = self::parse_upload_inner_value( $img_raw );

			$placement = self::inner_desktop_string( $attrs, "{$prefix}_icon_placement", 'top' );
			$placement = preg_match( '/^(top|left|right)$/', $placement ) ? $placement : 'top';

			$title_html    = $elements->render( array( 'attrName' => "{$prefix}_title" ) );
			$subtitle_text = self::get_heading_inner_text( $attrs, "{$prefix}_subtitle" );
			// Rich text: `ModuleElements::render` reads `$this->module_attrs`; `use_custom_module_attrs` + normalized `*_content` fixes string leaves.
			$content_html = $elements->render(
				array(
					'attrName'    => "{$prefix}_content",
					'attrSubName' => 'text',
				)
			);

			$subtitle_html = '' !== $subtitle_text
			? HTMLUtility::render(
				array(
					'tag'               => 'span',
					'attributes'        => array( 'class' => 'dsm-subtitle' ),
					'children'          => $subtitle_text,
					'childrenSanitizer' => 'et_core_esc_previously',
				)
			)
			: '';

			// Match {@see \DiviSupreme\Modules\Card::render_callback}: plain string or `{ text }` after dynamic/decoding.
			$button_raw  = $attrs[ "{$prefix}_button_text" ]['innerContent']['desktop']['value'] ?? '';
			$button_text = '';
			if ( is_array( $button_raw ) && isset( $button_raw['text'] ) && is_string( $button_raw['text'] ) ) {
				$button_text = $button_raw['text'];
			} elseif ( is_string( $button_raw ) ) {
				$button_text = $button_raw;
			}
			$button_url_raw = $attrs[ "{$prefix}_button_url" ]['innerContent']['desktop']['value'] ?? '';
			$button_url     = is_string( $button_url_raw ) ? trim( $button_url_raw ) : '';
			$new_win        = $attrs[ "{$prefix}_button_url_new_window" ]['innerContent']['desktop']['value'] ?? 'off';

			$button_html = '';
			if ( '' !== trim( $button_text ) && '' !== $button_url ) {
				$button_decoration  = $attrs[ "{$prefix}_button" ] ?? array();
				$button_attr_branch = is_array( $button_decoration ) && isset( $button_decoration['decoration']['button'] ) && is_array( $button_decoration['decoration']['button'] )
				? $button_decoration['decoration']['button']
				: array();

				$button_inner = ButtonComponent::component(
					array(
						'type'         => 'link',
						'hasWrapper'   => false,
						'innerContent' => array(
							'desktop' => array(
								'value' => array(
									'text'       => trim( $button_text ),
									'linkUrl'    => $button_url,
									'linkTarget' => 'on' === $new_win ? 'on' : 'off',
								),
							),
						),
						'buttonAttr'   => $button_attr_branch,
					)
				);

				if ( '' !== $button_inner ) {
					$button_align       = self::flipbox_resolve_button_alignment( $attrs, $prefix );
					$button_align_class = in_array( $button_align, array( 'left', 'center', 'right' ), true )
						? ' dsm_button_align_' . $button_align
						: '';
					$button_html        = sprintf(
						'<div class="et_pb_button_module_wrapper%s">%s</div>',
						esc_attr( $button_align_class ),
						$button_inner
					);
				}
			}

			$image_html = '';

			if ( $use_icon ) {
				$icon_classes = array( 'et-pb-icon' );
				if ( 'on' === self::inner_desktop_string( $attrs, "{$prefix}_use_circle", 'off' ) ) {
					$icon_classes[] = 'et-pb-icon-circle';
				}
				if ( 'on' === self::inner_desktop_string( $attrs, "{$prefix}_use_circle_border", 'off' ) ) {
					$icon_classes[] = 'et-pb-icon-circle-border';
				}
				$icon_span = '';
				if ( '' === $icon_char && class_exists( IconGlyphRenderer::class ) ) {
					$extra_classes = array();
					foreach ( $icon_classes as $icon_class ) {
						if ( 'et-pb-icon' !== $icon_class ) {
							$extra_classes[] = $icon_class;
						}
					}
					$icon_span = IconGlyphRenderer::render_icon_span( $icon_raw, $extra_classes );
				}
				if ( '' === $icon_span && '' !== $icon_char ) {
					// Icon color, circle fill, border, font-size: CommonStyle in module_styles (D5 color objects are not plain strings).
					$icon_span = HTMLUtility::render(
						array(
							'tag'               => 'span',
							'attributes'        => array(
								'class'       => implode( ' ', $icon_classes ),
								'aria-hidden' => 'true',
							),
							'children'          => $icon_char,
							'childrenSanitizer' => 'et_core_esc_previously',
						)
					);
				}
				if ( '' !== $icon_span ) {
					$image_html = sprintf(
						'<div class="dsm_flipbox_child_image"><span class="dsm_flipbox_child_image_wrap">%s</span></div>',
						$icon_span
					);
				}
			} elseif ( ! $use_icon ) {
				$image_html = self::build_flipbox_face_image_html( $img_data, $attrs, $prefix );
			}

			$content_markup = '';
			if ( '' !== trim( (string) $content_html ) ) {
				$content_markup = sprintf( '<div class="dsm-content">%s</div>', $content_html );
			}

			$wrapper_inner = sprintf(
				'%1$s%2$s%3$s%4$s',
				$title_html,
				$subtitle_html,
				$content_markup,
				$button_html
			);

			$content_orientation = self::inner_desktop_string( $attrs, "{$prefix}_content_orientation", 'center' );
			$content_orientation = preg_match( '/^(flex-start|center|flex-end)$/', $content_orientation ) ? $content_orientation : 'center';
			$co_map              = array(
				'flex-start' => 'dsm_flipbox_content_vertical_top',
				'center'     => 'dsm_flipbox_content_vertical_center',
				'flex-end'   => 'dsm_flipbox_content_vertical_bottom',
			);
			$co_class            = $co_map[ $content_orientation ] ?? 'dsm_flipbox_content_vertical_center';

			$face_advanced_text      = self::get_flip_face_text_adv_text_attr( $attrs, $prefix );
			$face_text_group_classes = TextClassnames::text_options_classnames( $face_advanced_text );

			$wrapper_classes = sprintf(
				'dsm_flipbox_wrapper %s',
				esc_attr( $face_text_group_classes )
			);

			$face_decoration = isset( $attrs[ "{$prefix}_face" ]['decoration'] ) && is_array( $attrs[ "{$prefix}_face" ]['decoration'] )
			? $attrs[ "{$prefix}_face" ]['decoration']
			: array();
			// Design → Animation / background / link classnames on the face root (matches module.json selector `.dsm-flipbox-face-*`).
			// Icon placement + text vertical alignment (D4: on order_class; image is sibling before wrapper, not inside it).
			$face_outer_classes = trim(
				'dsm_flipbox_child dsm-flipbox-face-' . $prefix . ' dsm_flipbox_icon_position_' . $placement . ' ' . $co_class . ' ' . ElementClassnames::classnames(
					array(
						'attrs' => $face_decoration,
					)
				)
			);

			$face_aria = '';
			if ( 'click' === $flipbox_trigger && 'back' === $prefix ) {
				$face_aria = ' aria-hidden="true"';
			}

			return sprintf(
				'<div class="%1$s"%5$s><div class="dsm_flipbox_face_inner">%2$s<div class="%4$s">%3$s</div></div></div>',
				esc_attr( $face_outer_classes ),
				$image_html,
				$wrapper_inner,
				esc_attr( $wrapper_classes ),
				$face_aria
			);
		} finally {
			$elements->clear_custom_attributes();
		}
	}

	/**
	 * Render callback.
	 *
	 * @param array<string, mixed> $attrs    Attributes.
	 * @param string               $content  Inner content.
	 * @param \WP_Block            $block    Block.
	 * @param mixed                $elements Elements API.
	 * @return string
	 */
	public static function render_callback( $attrs, $content, $block, $elements ) {
		$attrs = self::clone_attrs_array( is_array( $attrs ) ? $attrs : array() );
		self::normalize_flipbox_face_heading_attrs_for_render( $attrs );
		ConversionAttrs::normalize_flipbox_rich_content_inner_content_for_vb( $attrs );
		$attrs = ConversionAttrs::merge_flipbox_legacy_height_into_module_sizing( $attrs, false );
		ConversionAttrs::mirror_flipbox_phone_module_sizing_height_to_phone_wide_when_empty( $attrs );
		self::strip_flipbox_module_sizing_height_when_auto( $attrs );
		$flipbox_type    = $attrs['flipbox_type']['innerContent']['desktop']['value'] ?? 'flip';
		$flipbox_effect  = $attrs['flipbox_effect']['innerContent']['desktop']['value'] ?? 'right';
		$flipbox_3d      = $attrs['flipbox_3d']['innerContent']['desktop']['value'] ?? 'off';
		$flipbox_trigger = $attrs['flipbox_trigger']['innerContent']['desktop']['value'] ?? 'hover';
		$flipbox_click   = $attrs['flipbox_click']['innerContent']['desktop']['value'] ?? 'whole';
		$slide_effect    = $attrs['flipbox_slide_effect']['innerContent']['desktop']['value'] ?? 'slide-up';
		$zoom_out_effect = $attrs['flipbox_zoom_out_effect']['innerContent']['desktop']['value'] ?? 'zoom-out';

		if ( 'click' === $flipbox_trigger ) {
			wp_enqueue_script( 'dsm-flipbox-click' );
		}
		wp_enqueue_style( 'dsm-flipbox-d5' );

		$classes = array( 'dsm-flipbox' );
		if ( self::flipbox_height_mode_is_auto( $attrs ) ) {
			$classes[] = 'dsm-flipbox--auto-height';
		}
		if ( 'flip' === $flipbox_type ) {
			$classes[] = 'dsm-flipbox-effect-' . preg_replace( '/[^a-z\-]/', '', (string) $flipbox_effect );
		}
		if ( 'flip' === $flipbox_type && 'on' === $flipbox_3d ) {
			$classes[] = 'dsm-flipbox-3d';
		}
		if ( 'zoom-in' === $flipbox_type ) {
			$classes[] = 'dsm-flipbox-zoom-in';
		}
		if ( 'fade' === $flipbox_type ) {
			$classes[] = 'dsm-flipbox-fade';
		}
		if ( 'zoom-out' === $flipbox_type ) {
			$classes[] = 'dsm-flipbox-zoom';
			$classes[] = 'dsm-flipbox-' . preg_replace( '/[^a-z\-]/', '', (string) $zoom_out_effect );
		}
		if ( 'slide' === $flipbox_type ) {
			$classes[] = 'dsm-flipbox-' . preg_replace( '/[^a-z\-]/', '', (string) $slide_effect );
		}
		$classes[] = 'dsm_flipbox_' . preg_replace( '/[^a-z]/', '', (string) $flipbox_trigger );
		if ( 'click' === $flipbox_trigger ) {
			$classes[] = 'dsm_flipbox_trigger_' . preg_replace( '/[^a-z]/', '', (string) $flipbox_click );
		}

		$front = self::render_face( $attrs, $elements, 'front', $flipbox_trigger );
		$back  = self::render_face( $attrs, $elements, 'back', $flipbox_trigger );

		$sanitized_flip_trigger = in_array( $flipbox_trigger, array( 'hover', 'click' ), true )
			? $flipbox_trigger
			: 'hover';

		$flipbox_inner_attributes = array(
			'class'                 => implode( ' ', array_filter( $classes ) ),
			'role'                  => 'group',
			'aria-label'            => __( 'Flip box with front and back content', 'dsm-supreme-modules-pro-for-divi' ),
			'data-dsm-flip-trigger' => $sanitized_flip_trigger,
		);

		if ( 'click' === $flipbox_trigger && 'whole' === $flipbox_click ) {
			$flipbox_inner_attributes['tabindex'] = '0';
		}

		$inner = HTMLUtility::render(
			array(
				'tag'               => 'div',
				'attributes'        => $flipbox_inner_attributes,
				'children'          => $front . $back,
				'childrenSanitizer' => 'et_core_esc_previously',
			)
		);

		$module_inner = HTMLUtility::render(
			array(
				'tag'               => 'div',
				'attributes'        => array( 'class' => 'et_pb_module_inner' ),
				'children'          => $inner,
				'childrenSanitizer' => 'et_core_esc_previously',
			)
		);

		$module_elements = $elements->style_components( array( 'attrName' => 'module' ) );
		$children        = $module_elements . $module_inner;

		return Module::render(
			array(
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],
				'attrs'               => $attrs,
				'elements'            => $elements,
				'id'                  => $block->parsed_block['id'],
				'moduleClassName'     => 'dsm_flipbox',
				'name'                => $block->block_type->name,
				'classnamesFunction'  => array( self::class, 'module_classnames' ),
				'moduleCategory'      => $block->block_type->category,
				'stylesComponent'     => array( self::class, 'module_styles' ),
				'scriptDataComponent' => array( self::class, 'module_script_data' ),
				'children'            => $children,
			)
		);
	}
}
