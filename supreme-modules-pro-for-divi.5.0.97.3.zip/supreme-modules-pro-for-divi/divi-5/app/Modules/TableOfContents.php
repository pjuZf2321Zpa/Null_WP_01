<?php
/**
 * Table of Contents module — Divi 5.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Modules;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use ET\Builder\Packages\Module\Options\Element\ElementClassnames;
use ET\Builder\Packages\Module\Options\Text\TextStyle;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use DiviSupreme\Extensions\IconLibraries\LegacyModuleIconStyles;
use DiviSupreme\Includes\DsmFrontendModuleAssetRegistry;

/**
 * Supreme Table Of Contents (`dsm/table-of-contents`).
 */
class TableOfContents implements DependencyInterface {

	/**
	 * Register hooks.
	 */
	public function load() {
		add_action( 'init', array( self::class, 'register_module' ) );
	}

	/**
	 * Normalize innerContent length to CSS (px or string).
	 *
	 * @param mixed $raw Raw breakpoint value.
	 */
	public static function normalize_length_px( $raw ): string {
		if ( \is_array( $raw ) && isset( $raw['value'], $raw['unit'] ) ) {
			$val = $raw['value'];
			if ( '' === $val || null === $val ) {
				return '';
			}

			return (string) $val . (string) $raw['unit'];
		}
		if ( \is_string( $raw ) && '' !== $raw ) {
			return $raw;
		}
		if ( \is_numeric( $raw ) ) {
			return (string) $raw . 'px';
		}

		return '0px';
	}

	/**
	 * Parse CSS length to integer pixels (best-effort for px/%/em not supported — px only).
	 *
	 * @param mixed $raw Raw value.
	 */
	public static function length_to_int_px( $raw ): int {
		$s = self::normalize_length_px( $raw );
		$s = trim( $s );
		if ( '' === $s ) {
			return 0;
		}
		if ( preg_match( '/^(-?\d+(\.\d+)?)/', $s, $m ) ) {
			return (int) round( (float) $m[1] );
		}

		return 0;
	}

	/**
	 * Whether a toggle attr is on.
	 *
	 * @param mixed $value Raw value.
	 */
	public static function toggle_is_on( $value ): bool {
		if ( true === $value || 1 === $value ) {
			return true;
		}
		if ( false === $value || 0 === $value ) {
			return false;
		}
		if ( \is_string( $value ) ) {
			$v = strtolower( trim( $value ) );

			return \in_array( $v, array( 'on', '1', 'true', 'yes' ), true );
		}

		return false;
	}

	/**
	 * Style declarations for mobile TOC toggle icon glyph (`::before`).
	 *
	 * @param array<string, mixed> $params CommonStyle params.
	 */
	public static function mobile_toggle_icon_glyph_declaration( $params ): string {
		return LegacyModuleIconStyles::build_pseudo_icon_declaration( $params );
	}

	/**
	 * Register module metadata + render callback.
	 */
	public static function register_module() {
		$module_json_path = DSM_DIR_PATH . 'divi-5/public/packages/module-library/table-of-contents';

		ModuleRegistration::register_module(
			$module_json_path,
			array(
				'render_callback' => array( self::class, 'render_callback' ),
			)
		);
	}

	/**
	 * Print frontend style tags via Style API.
	 *
	 * @param array<string, mixed> $args Args passed by Divi.
	 */
	public static function module_styles( $args ): void {
		$args     = \DiviSupreme\Includes\DsmDiviBuilderCssScope::normalize_module_styles_args( $args );
		$attrs    = isset( $args['attrs'] ) && \is_array( $args['attrs'] ) ? $args['attrs'] : array();
		$elements = $args['elements'];

		Style::add(
			array(
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => array(
					$elements->style(
						array(
							'attrName'   => 'module',
							'styleProps' => array(
								'disabledOn' => array(
									'disabledModuleVisibility' => $args['settings']['disabledModuleVisibility'] ?? null,
								),
							),
						)
					),
					TextStyle::style(
						array(
							'selector' => $args['orderClass'],
							'attr'     => $attrs['module']['advanced']['text'] ?? array(),
						)
					),
					CssStyle::style(
						array(
							'selector' => $args['orderClass'],
							'attr'     => $attrs['css'] ?? array(),
						)
					),
					$elements->style(
						array(
							'attrName' => 'toc_list',
						)
					),
					$elements->style(
						array(
							'attrName' => 'toc_list_active',
						)
					),
					$elements->style(
						array(
							'attrName' => 'toc_mobile_toggle_bg',
						)
					),
					CommonStyle::style(
						array(
							'selector'            => "{$args['orderClass']} .dsm-toc-mobile-toggle .dsm-toc-toggle-icon::before",
							'attr'                => ( $attrs['dsm_mobile_toggle_icon'] ?? array() )['innerContent'] ?? array(),
							'declarationFunction' => array( self::class, 'mobile_toggle_icon_glyph_declaration' ),
						)
					),
					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-toc-mobile-toggle .dsm-toc-toggle-icon",
							'attr'     => ( $attrs['dsm_mobile_toggle_icon_size'] ?? array() )['innerContent'] ?? array(),
							'property' => 'font-size',
						)
					),
					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-toc-mobile-toggle .dsm-toc-toggle-icon",
							'attr'     => ( $attrs['dsm_mobile_toggle_icon_color'] ?? array() )['innerContent'] ?? array(),
							'property' => 'color',
						)
					),
				),
			)
		);
	}

	/**
	 * Script data for module + motion prefs.
	 *
	 * @param array<string, mixed> $args Args.
	 */
	public static function module_script_data( $args ): void {
		$elements = $args['elements'];
		$elements->script_data(
			array(
				'attrName' => 'module',
			)
		);
	}

	/**
	 * Classnames on root module wrapper.
	 *
	 * @param array<string, mixed> $args Args.
	 */
	public static function module_classnames( $args ): void {
		$classnames_instance = $args['classnamesInstance'];
		$attrs               = $args['attrs'];

		$classnames_instance->add(
			ElementClassnames::classnames(
				array(
					'attrs' => $attrs['module']['decoration'] ?? array(),
				)
			)
		);
	}

	/**
	 * Enqueue shared module CSS + TOCS script.
	 */
	public static function enqueue_module_styles(): void {
		$is_vb = function_exists( 'et_core_is_fb_enabled' ) && et_core_is_fb_enabled();

		if ( function_exists( 'dsm_supreme_dynamic_assets_enabled' ) && dsm_supreme_dynamic_assets_enabled() && ! $is_vb ) {
			if ( DsmFrontendModuleAssetRegistry::maybe_enqueue_split_frontend_stylesheet_for_block( 'dsm/table-of-contents' ) ) {
				return;
			}
		}

		if ( wp_style_is( \DiviSupreme\Includes\DsmFrontendModuleAssetRegistry::CORE_MODULES_STYLE_HANDLE, 'enqueued' ) ) {
			return;
		}
		if ( wp_style_is( \DiviSupreme\Includes\DsmFrontendModuleAssetRegistry::CORE_MODULES_STYLE_HANDLE, 'registered' ) ) {
			wp_enqueue_style( \DiviSupreme\Includes\DsmFrontendModuleAssetRegistry::CORE_MODULES_STYLE_HANDLE );
			return;
		}

		\DiviSupreme\Includes\DsmFrontendModuleAssetRegistry::refresh_scoped_frontend_style_handles();

		$version = defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';
		$is_vb   = function_exists( 'et_core_is_fb_enabled' ) && et_core_is_fb_enabled();
		$src     = $is_vb
			? DSM_DIR_URL . 'public/modules-vb-styles.css'
			: \DiviSupreme\Includes\DsmDiviBuilderCssScope::resolve_stylesheet_url(
				DSM_DIR_URL . 'public/style-modules-frontend-styles.css'
			);

		wp_enqueue_style(
			\DiviSupreme\Includes\DsmFrontendModuleAssetRegistry::CORE_MODULES_STYLE_HANDLE,
			$src,
			array(),
			$version
		);
	}

	/**
	 * Frontend HTML.
	 *
	 * @param array<string, mixed> $attrs Parsed attributes.
	 * @param string               $content Inner blocks markup (unused).
	 * @param \WP_Block            $block Block instance.
	 * @param mixed                $elements Elements API.
	 */
	public static function render_callback( $attrs, $content, $block, $elements ) {

		wp_enqueue_script( 'dsm-toc' );
		self::enqueue_module_styles();

		$content_selector_raw = $attrs['dsm_content_selector']['innerContent']['desktop']['value'] ?? '';
		$content_selector_raw = \is_string( $content_selector_raw ) ? trim( $content_selector_raw ) : '';

		$heading_levels_raw = $attrs['dsm_heading_levels']['innerContent']['desktop']['value'] ?? 'h2, h3, h4';
		$heading_levels_raw = \is_string( $heading_levels_raw ) ? trim( $heading_levels_raw ) : 'h2, h3, h4';

		$ignore_selector_raw = $attrs['dsm_ignore_selector']['innerContent']['desktop']['value'] ?? '';
		$ignore_selector_raw = \is_string( $ignore_selector_raw ) ? trim( $ignore_selector_raw ) : '';

		$exclude_empty = self::toggle_is_on(
			$attrs['dsm_exclude_empty']['innerContent']['desktop']['value'] ?? 'on'
		);
		$smooth        = self::toggle_is_on(
			$attrs['dsm_smooth_scroll']['innerContent']['desktop']['value'] ?? 'on'
		);
		$ordered       = self::toggle_is_on(
			$attrs['dsm_ordered_list']['innerContent']['desktop']['value'] ?? 'off'
		);
		$collapse      = self::toggle_is_on(
			$attrs['dsm_collapse_inactive']['innerContent']['desktop']['value'] ?? 'off'
		);
		$mobile_toggle = self::toggle_is_on(
			$attrs['dsm_mobile_collapsible']['innerContent']['desktop']['value'] ?? 'off'
		);

		$scroll_offset_raw = $attrs['dsm_scroll_offset']['innerContent']['desktop']['value'] ?? '0px';
		$max_height_raw    = $attrs['dsm_list_max_height']['innerContent']['desktop']['value'] ?? '';

		$scroll_offset_px = self::length_to_int_px( $scroll_offset_raw );
		$max_height_px    = self::length_to_int_px( $max_height_raw );

		$empty_message = $attrs['dsm_empty_message']['innerContent']['desktop']['value'] ?? '';
		$empty_message = \is_string( $empty_message ) ? $empty_message : '';
		if ( '' === trim( $empty_message ) ) {
			$empty_message = __( 'No headings were found in the selected content area.', 'dsm-supreme-modules-pro-for-divi' );
		}

		$mtl_row             = $attrs['dsm_mobile_toggle_label'] ?? array();
		$mobile_toggle_label = '';
		if ( isset( $mtl_row['innerContent']['desktop']['value'] ) ) {
			$v                   = $mtl_row['innerContent']['desktop']['value'];
			$mobile_toggle_label = \is_string( $v ) ? trim( $v ) : trim( (string) $v );
		}
		if ( '' === $mobile_toggle_label ) {
			$mobile_toggle_label = __( 'Contents', 'dsm-supreme-modules-pro-for-divi' );
		}

		$icon_placement_raw = $attrs['dsm_mobile_toggle_icon_placement']['innerContent']['desktop']['value'] ?? 'left';
		$icon_placement_raw = \is_string( $icon_placement_raw ) ? strtolower( trim( $icon_placement_raw ) ) : 'left';
		$icon_placement     = 'right' === $icon_placement_raw ? 'right' : 'left';

		$toggle_btn_class = 'dsm-toc-mobile-toggle' . ( 'right' === $icon_placement ? ' dsm-toc-mobile-toggle--icon-right' : '' );

		$mobile_toggle_icon = $attrs['dsm_mobile_toggle_icon']['innerContent']['desktop']['value'] ?? null;
		$toggle_icon_markup = LegacyModuleIconStyles::render_custom_icon_host(
			\is_array( $mobile_toggle_icon ) ? $mobile_toggle_icon : null,
			'dsm-toc-toggle-icon'
		);

		$block_id = isset( $block->parsed_block['id'] ) ? (string) $block->parsed_block['id'] : '';

		$shell_classes = array( 'dsm-toc-shell', 'dsm-toc-shell--expanded' );
		if ( $mobile_toggle ) {
			$shell_classes[] = 'dsm-toc--mobile-toggle';
		}

		$scroll_area_style = '';
		if ( $max_height_px > 0 ) {
			$scroll_area_style = sprintf(
				'max-height:%s;',
				esc_attr( (string) $max_height_px . 'px' )
			);
		}

		$nav_attrs = array(
			'class'                       => 'dsm-toc-root',
			'aria-label'                  => __( 'Table of contents', 'dsm-supreme-modules-pro-for-divi' ),
			'data-dsm-instance'           => $block_id,
			'data-dsm-content-selector'   => $content_selector_raw,
			'data-dsm-heading-levels'     => $heading_levels_raw,
			'data-dsm-ignore-selector'    => $ignore_selector_raw,
			'data-dsm-exclude-empty'      => $exclude_empty ? 'on' : 'off',
			'data-dsm-smooth'             => $smooth ? 'on' : 'off',
			'data-dsm-ordered'            => $ordered ? 'on' : 'off',
			'data-dsm-collapse'           => $collapse ? 'on' : 'off',
			'data-dsm-scroll-offset'      => (string) $scroll_offset_px,
			'data-dsm-max-height-px'      => (string) $max_height_px,
			'data-dsm-empty-message'      => wp_strip_all_tags( $empty_message ),
			'data-dsm-mobile-collapsible' => $mobile_toggle ? 'on' : 'off',
		);

		$data_attr_pairs = '';
		foreach ( $nav_attrs as $key => $val ) {
			$data_attr_pairs .= sprintf(
				' %1$s="%2$s"',
				esc_attr( $key ),
				esc_attr( \is_scalar( $val ) ? (string) $val : wp_json_encode( $val ) )
			);
		}

		$region_uid = sanitize_html_class( 'dsm-toc-region-' . ( '' !== $block_id ? preg_replace( '/[^\w\-]/', '', $block_id ) : '0' ) );

		$inner_html = sprintf(
			'<div class="%1$s">
				<button type="button" class="%6$s">
					%8$s
					<span class="dsm-toc-mobile-toggle-label">%2$s</span>
				</button>
				<div id="%3$s" class="dsm-toc-scroll-area"%4$s>
					<p class="dsm-toc-empty" aria-hidden="true">%5$s</p>
					<div class="dsm-toc-vb-sample" aria-hidden="true"><ul class="dsm-toc-list dsm-toc-list--unordered"><li class="dsm-toc-item is-active-li"><span class="dsm-toc-link is-active-link">%7$s</span></li></ul></div>
					<div class="dsm-toc-list-host"></div>
				</div>
			</div>',
			esc_attr( implode( ' ', array_filter( $shell_classes ) ) ),
			esc_html( $mobile_toggle_label ),
			esc_attr( $region_uid ),
			$max_height_px > 0 ? ' style="' . esc_attr( $scroll_area_style ) . '"' : '',
			esc_html( __( 'Headings populate on the live page from your selected content wrapper.', 'dsm-supreme-modules-pro-for-divi' ) ),
			esc_attr( $toggle_btn_class ),
			esc_html__( 'Sample heading', 'dsm-supreme-modules-pro-for-divi' ),
			et_core_esc_previously( $toggle_icon_markup )
		);

		$nav_open = sprintf( '<nav%1$s>%2$s</nav>', $data_attr_pairs, $inner_html );

		$module_inner = HTMLUtility::render(
			array(
				'tag'               => 'div',
				'attributes'        => array(
					'class' => 'et_pb_module_inner',
				),
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $nav_open,
			)
		);

		$module_elements           = $elements->style_components(
			array(
				'attrName' => 'module',
			)
		);
		$module_container_children = $module_elements . $module_inner;

		return Module::render(
			array(
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],
				'attrs'               => $attrs,
				'elements'            => $elements,
				'id'                  => $block->parsed_block['id'],
				'name'                => $block->block_type->name,
				'classnamesFunction'  => array( self::class, 'module_classnames' ),
				'moduleCategory'      => $block->block_type->category,
				'stylesComponent'     => array( self::class, 'module_styles' ),
				'scriptDataComponent' => array( self::class, 'module_script_data' ),
				'children'            => $module_container_children,
			)
		);
	}
}
