<?php
/**
 * Menu Module.
 *
 * @package DiviSupreme.
 */

declare(strict_types=1);

namespace DiviSupreme\Modules;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}


use ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface;
use ET\Builder\Framework\Utility\HTMLUtility;
use ET\Builder\FrontEnd\Module\Style;
use ET\Builder\Packages\Module\Module;
use ET\Builder\Packages\Module\Options\Element\ElementClassnames;
use ET\Builder\Packages\ModuleLibrary\ModuleRegistration;
use ET\Builder\Packages\Module\Layout\Components\StyleCommon\CommonStyle;
use ET\Builder\Packages\IconLibrary\IconFont\Utils;
use ET\Builder\Packages\Module\Options\Text\TextStyle;
use ET\Builder\Packages\StyleLibrary\Utils\StyleDeclarations;
use ET\Builder\Packages\Module\Options\Css\CssStyle;
use DiviSupreme\Utils\HeadingLevel;

/**
 * Class that handles "Menu Module" module.
 */
class Menu implements DependencyInterface {


	/**
	 * Register module.
	 * `DependencyInterface` interface ensures class method name `load()` is executed for initialization.
	 */
	public function load() {
		add_action( 'init', array( self::class, 'register_module' ) );
		add_action( 'wp_ajax_dsm_menu', array( $this, 'render_menu' ) );
	}

	/**
	 * Whether a menu option is "on" (D5 Toggle / migrated JSON may use bool true or string "on").
	 *
	 * @param mixed $value Raw value from attrs or shortcode.
	 */
	private static function menu_attr_is_on( $value ): bool {
		if ( true === $value || 1 === $value ) {
			return true;
		}
		if ( false === $value || 0 === $value ) {
			return false;
		}
		if ( is_string( $value ) ) {
			$v = strtolower( trim( $value ) );

			return in_array( $v, array( 'on', '1', 'true', 'yes' ), true );
		}

		return false;
	}

	/**
	 * First registered nav menu that has at least one item (same resolution as `wp_nav_menu()` when `menu` is 0).
	 */
	private static function get_first_nav_menu_with_items(): ?object {
		$menus = wp_get_nav_menus();

		foreach ( $menus as $menu_maybe ) {
			$menu_items = wp_get_nav_menu_items( $menu_maybe->term_id, array( 'update_post_term_cache' => false ) );
			if ( $menu_items ) {
				return $menu_maybe;
			}
		}

		return null;
	}

	/**
	 * Accessible name for `<nav>` (landmark) when multiple navs may exist on the page.
	 *
	 * @param string $menu_id Menu term ID, placeholder (`select-menu`), or empty.
	 */
	private static function get_dsm_nav_accessible_label( string $menu_id ): string {
		$menu_id = trim( $menu_id );

		if ( '' !== $menu_id && ctype_digit( $menu_id ) ) {
			$menu_obj = wp_get_nav_menu_object( (int) $menu_id );
			if ( $menu_obj && ! is_wp_error( $menu_obj ) && isset( $menu_obj->name ) && '' !== trim( (string) $menu_obj->name ) ) {
				return (string) $menu_obj->name;
			}
		}

		if ( '' === $menu_id || 'none' === $menu_id || 'select-menu' === $menu_id || ! ctype_digit( $menu_id ) ) {
			$menu_obj = self::get_first_nav_menu_with_items();
			if ( $menu_obj && isset( $menu_obj->name ) && '' !== trim( (string) $menu_obj->name ) ) {
				return (string) $menu_obj->name;
			}
		}

		return (string) __( 'Menu', 'dsm-supreme-modules-pro-for-divi' );
	}

	/**
	 * Build `wp_nav_menu()` args for `menu` / `theme_location` (aligned with Divi 5 MenuUtils + MenuHTMLController).
	 *
	 * When no menu is selected, Divi passes a non-numeric `menuId` (e.g. `primary-menu`) so `(int) $menuId` is `0`
	 * and `theme_location` stays empty — WordPress then uses the first menu that has items. We must not
	 * set `theme_location` => `primary-menu` unless a menu is assigned there; otherwise `wp_nav_menu()` returns
	 * false and we fall back to `show_page_menu` / `wp_page_menu`, which bypass schema filters.
	 *
	 * @param string $menu_id Menu id.
	 * @return array{ menu: int, theme_location: string }
	 */
	private static function get_dsm_wp_nav_menu_args_for_menu_id( string $menu_id ): array {
		$menu_id = trim( $menu_id );

		if ( '' === $menu_id || 'none' === $menu_id || 'select-menu' === $menu_id ) {
			return array(
				'menu'           => 0,
				'theme_location' => '',
			);
		}

		if ( ctype_digit( $menu_id ) ) {
			return array(
				'menu'           => (int) $menu_id,
				'theme_location' => '',
			);
		}

		return array(
			'menu'           => 0,
			'theme_location' => '',
		);
	}

	/**
	 * Collapsible submenu: disclosure semantics on parent links.
	 *
	 * @param array<string, string> $atts HTML attributes for the anchor.
	 * @param \WP_Post              $item Menu item object.
	 * @param object                $args Nav menu arguments.
	 * @return array<string, string>
	 */
	public static function filter_nav_menu_link_attributes_submenu_a11y( $atts, $item, $args ) {
		unset( $args );

		if ( ! is_array( $atts ) ) {
			$atts = array();
		}

		if ( ! is_object( $item ) || ! isset( $item->classes ) || ! is_array( $item->classes ) ) {
			return $atts;
		}

		if ( ! in_array( 'menu-item-has-children', $item->classes, true ) ) {
			return $atts;
		}

		$atts['aria-haspopup'] = 'true';
		$atts['aria-expanded'] = 'false';

		return $atts;
	}

	/**
	 * Get fullwidth menu markup for fullwidth menu module
	 *
	 * @param mixed $args Args.
	 * @return string of fullwidth menu markup
	 */
	public static function get_dsm_navmenu( $args = array() ) {
		$defaults = array(
			'list_style_type'     => '',
			'menu_layout'         => '',
			'menu_animation'      => '',
			'menu_animation_type' => '',
			'underline_animation' => '',
			'menu_id'             => '',
			'submenu_collapse'    => '',
			'use_schema_markup'   => '',
		);

		$args                = wp_parse_args( $args, $defaults );
		$schema_on           = self::menu_attr_is_on( $args['use_schema_markup'] ?? '' );
		$submenu_collapse_on = self::menu_attr_is_on( $args['submenu_collapse'] ?? '' );

		/*
		 * Microdata / schema: only when enabled.
		 * Do not leave `nav_menu_link_attributes` hooked globally — it would affect every menu on the page.
		 */
		if ( $schema_on ) {
			add_filter( 'nav_menu_link_attributes', array( self::class, 'filter_nav_menu_link_attributes_schema' ), 99, 3 );
			add_filter( 'wp_setup_nav_menu_item', array( self::class, 'modify_dsm_menu_item' ) );
			// After walker output: some themes strip `itemprop` from `nav_menu_link_attributes`.
			add_filter( 'walker_nav_menu_start_el', array( self::class, 'dsm_ensure_menu_anchor_itemprop_url' ), 5, 4 );
		}

		if ( $submenu_collapse_on ) {
			add_filter( 'nav_menu_link_attributes', array( self::class, 'filter_nav_menu_link_attributes_submenu_a11y' ), 98, 3 );
			add_filter( 'walker_nav_menu_start_el', array( self::class, 'dsm_arrows_in_menus' ), 10, 4 );
		}

		$nav_aria_label = self::get_dsm_nav_accessible_label( (string) ( $args['menu_id'] ?? '' ) );

		$nav_attrs = ' aria-label="' . esc_attr( $nav_aria_label ) . '"';
		if ( $schema_on ) {
			$nav_attrs .= ' itemscope itemtype="https://schema.org/SiteNavigationElement"';
		}

		$menu = '<nav class="dsm-menu-container"' . $nav_attrs . '>';

		$menu_class = 'dsm-menu';

		if ( ! et_is_builder_plugin_active() && 'on' === et_get_option( 'divi_disable_toptier' ) ) {
			$menu_class .= ' et_disable_top_tier';
		}

		$menu_class .= sprintf( ' %s', esc_attr( 'dsm-menu-style-type-' . $args['list_style_type'] ) );
		$menu_class .= sprintf( ' %s', esc_attr( 'dsm-menu-layout-' . $args['menu_layout'] ) );
		$menu_class .= ( self::menu_attr_is_on( $args['menu_animation'] ?? '' ) ? sprintf( ' %s', esc_attr( 'dsm-menu-animation dsm-menu-animation-' . $args['underline_animation'] ) ) : '' );
		$menu_class .= ( $submenu_collapse_on ? sprintf( ' %s', esc_attr( 'dsm-menu-submenu-collapse' ) ) : '' );
		$primary_nav = '';

		$nav_query = self::get_dsm_wp_nav_menu_args_for_menu_id( (string) ( $args['menu_id'] ?? '' ) );

		$menu_args = array(
			'theme_location' => $nav_query['theme_location'],
			'menu'           => $nav_query['menu'],
			'container'      => '',
			'fallback_cb'    => '',
			'link_before'    => $schema_on ? '<span itemprop="name">' : '',
			'link_after'     => $schema_on ? '</span>' : '',
			'menu_class'     => $menu_class,
			'menu_id'        => '',
			'echo'           => false,
		);

		$menu_args = apply_filters( 'dsm_menu_args', $menu_args );

		/*
		 * `dsm_menu_args` may clear `link_before` / `link_after`; restore schema spans when enabled.
		 */
		if ( $schema_on ) {
			$menu_args['link_before'] = '<span itemprop="name">';
			$menu_args['link_after']  = '</span>';
		}

		$primary_nav = wp_nav_menu( $menu_args );

		if ( empty( $primary_nav ) ) {
			$menu .= sprintf(
				'<ul class="%1$s">
					%2$s',
				esc_attr( $menu_class ),
				( ! et_is_builder_plugin_active() && 'on' === et_get_option( 'divi_home_link' )
					? sprintf(
						'<li%1$s><a href="%2$s"%4$s><span%5$s>%3$s</span></a></li>',
						( is_home() ? ' class="current_page_item"' : '' ),
						esc_url( home_url( '/' ) ),
						esc_html__( 'Home', 'dsm-supreme-modules-pro-for-divi' ),
						$schema_on ? esc_attr( ' itemprop=url' ) : '',
						$schema_on ? esc_attr( ' itemprop=name' ) : ''
					)
					: ''
				)
			);

			ob_start();

			// @todo: check if Fullwidth Menu module works fine with no menu selected in settings
			if ( et_is_builder_plugin_active() ) {
				wp_page_menu();
			} else {
				show_page_menu( $menu_class, false, false );
				show_categories_menu( $menu_class, false );
			}

			$menu .= ob_get_contents();

			$menu .= '</ul>';

			ob_end_clean();
		} else {
			$menu .= $primary_nav;
		}

		$menu .= '</nav>';

		if ( $schema_on ) {
			remove_filter( 'nav_menu_link_attributes', array( self::class, 'filter_nav_menu_link_attributes_schema' ), 99 );
			remove_filter( 'wp_setup_nav_menu_item', array( self::class, 'modify_dsm_menu_item' ) );
			remove_filter( 'walker_nav_menu_start_el', array( self::class, 'dsm_ensure_menu_anchor_itemprop_url' ), 5 );
		}
		if ( $submenu_collapse_on ) {
			remove_filter( 'nav_menu_link_attributes', array( self::class, 'filter_nav_menu_link_attributes_submenu_a11y' ), 98 );
			remove_filter( 'walker_nav_menu_start_el', array( self::class, 'dsm_arrows_in_menus' ), 10 );
		}

		return $menu;
	}

	/**
	 * Microdata: add `itemprop="url"` to menu anchor tags when schema markup is enabled for this menu.
	 *
	 * @param array<string, string> $atts HTML attributes for the anchor.
	 * @param \WP_Post              $item Menu item object.
	 * @param object                $args Nav menu arguments.
	 * @return array<string, string>
	 */
	public static function filter_nav_menu_link_attributes_schema( $atts, $item, $args ) {
		unset( $item, $args );
		$atts['itemprop'] = 'url';

		return $atts;
	}

	/**
	 * Ensure `<a itemprop="url">` exists when schema markup is on (themes may strip via `nav_menu_link_attributes`).
	 *
	 * @param string $item_output Walker output.
	 * @param object $item        Menu item.
	 * @param int    $depth       Depth.
	 * @param object $args        Walker args.
	 */
	public static function dsm_ensure_menu_anchor_itemprop_url( $item_output, $item, $depth, $args ) {
		unset( $item, $depth, $args );

		if ( ! is_string( $item_output ) || '' === $item_output ) {
			return $item_output;
		}

		if ( preg_match( '/<a[^>]+itemprop\s*=\s*([\'"])url\1/i', $item_output ) ) {
			return $item_output;
		}

		return preg_replace( '/<a\s+/i', '<a itemprop="url" ', $item_output, 1 );
	}

	/**
	 * Add the class with page ID to menu item so it can be easily found by ID in Frontend Builder
	 *
	 * @param mixed $menu_item Menu item.
	 * @return menu item object
	 */
	public static function modify_dsm_menu_item( $menu_item ) {
		// Since PHP 7.1 silent conversion to array is no longer supported.
		$menu_item->classes = (array) $menu_item->classes;

		if ( esc_url( home_url( '/' ) ) === $menu_item->url ) {
			$fw_menu_custom_class = 'et_pb_menu_page_id-home';
		} else {
			$fw_menu_custom_class = 'et_pb_menu_page_id-' . $menu_item->object_id;
		}

		$menu_item->classes[] = $fw_menu_custom_class;
		return $menu_item;
	}

	/**
	 * Dsm arrows in menus.
	 *
	 * @param mixed $item_output Item output.
	 * @param mixed $item        Item.
	 * @param mixed $depth       Depth.
	 * @param mixed $args        Args.
	 */
	public static function dsm_arrows_in_menus( $item_output, $item, $depth, $args ) {

		if ( in_array( 'menu-item-has-children', $item->classes, true ) ) {
			$arrow       = '<span class="et-pb-icon" aria-hidden="true">3</span>';
			$item_output = str_replace( '</a>', $arrow . '</a>', $item_output );
		}

		return $item_output;
	}

	/**
	 * Temporarily make `$wp_query` look like the Visual Builder’s edited post so
	 * `wp_nav_menu()` / `_wp_menu_item_classes_by_context()` emit `current-menu-item`.
	 *
	 * Admin-ajax has no singular queried object; without this, Active Link Color never matches in VB.
	 * Only `$wp_query` flags / queried object are spoofed — Core menu context helpers do not need
	 * the global `$post`, so it is left untouched (avoids GlobalVariablesOverride).
	 *
	 * @param int $post_id Edited post/page ID from the builder.
	 * @return array<string, mixed>|null Backup for {@see self::end_vb_menu_query_context()}, or null when skipped.
	 */
	private static function begin_vb_menu_query_context( int $post_id ): ?array {
		if ( $post_id <= 0 ) {
			return null;
		}

		$post_obj = get_post( $post_id );
		if ( ! $post_obj instanceof \WP_Post ) {
			return null;
		}

		// VB may preview drafts/private; require edit capability for non-public posts.
		if ( 'publish' !== $post_obj->post_status && ! current_user_can( 'edit_post', $post_id ) ) {
			return null;
		}

		global $wp_query;

		if ( ! $wp_query instanceof \WP_Query ) {
			return null;
		}

		$backup = array(
			'queried_object'    => $wp_query->queried_object,
			'queried_object_id' => (int) $wp_query->queried_object_id,
			'is_singular'       => (bool) $wp_query->is_singular,
			'is_page'           => (bool) $wp_query->is_page,
			'is_single'         => (bool) $wp_query->is_single,
			'is_home'           => (bool) $wp_query->is_home,
			'is_front_page'     => (bool) $wp_query->is_front_page,
			'is_archive'        => (bool) $wp_query->is_archive,
		);

		$is_page         = ( 'page' === $post_obj->post_type );
		$front_id        = (int) get_option( 'page_on_front' );
		$is_static_front = ( 'page' === get_option( 'show_on_front' ) && $front_id > 0 && $front_id === $post_id );

		$wp_query->queried_object    = $post_obj;
		$wp_query->queried_object_id = $post_id;
		$wp_query->is_singular       = true;
		$wp_query->is_page           = $is_page;
		$wp_query->is_single         = ! $is_page;
		$wp_query->is_archive        = false;
		$wp_query->is_home           = $is_static_front;
		$wp_query->is_front_page     = $is_static_front;

		return $backup;
	}

	/**
	 * Restore `$wp_query` after {@see self::begin_vb_menu_query_context()}.
	 *
	 * @param array<string, mixed>|null $backup Backup from begin, or null.
	 * @return void
	 */
	private static function end_vb_menu_query_context( ?array $backup ): void {
		if ( null === $backup ) {
			return;
		}

		global $wp_query;

		if ( ! $wp_query instanceof \WP_Query ) {
			return;
		}

		$wp_query->queried_object    = $backup['queried_object'] ?? null;
		$wp_query->queried_object_id = (int) ( $backup['queried_object_id'] ?? 0 );
		$wp_query->is_singular       = (bool) ( $backup['is_singular'] ?? false );
		$wp_query->is_page           = (bool) ( $backup['is_page'] ?? false );
		$wp_query->is_single         = (bool) ( $backup['is_single'] ?? false );
		$wp_query->is_home           = (bool) ( $backup['is_home'] ?? false );
		$wp_query->is_front_page     = (bool) ( $backup['is_front_page'] ?? false );
		$wp_query->is_archive        = (bool) ( $backup['is_archive'] ?? false );
	}

	/**
	 * Renders the menu (Visual Builder AJAX).
	 *
	 * @return void
	 */
	public function render_menu() {
		if ( ! isset( $_REQUEST['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( (string) $_REQUEST['nonce'] ) ), 'render_dsm_menu' ) ) {
			exit;
		}

		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Sanitized per-field below.
		$req = wp_unslash( $_REQUEST );

		$menu_id             = isset( $req['id'] ) ? sanitize_text_field( (string) $req['id'] ) : '';
		$list_style_type     = isset( $req['list_style_type'] ) ? sanitize_text_field( (string) $req['list_style_type'] ) : 'disc';
		$menu_layout         = isset( $req['menu_layout'] ) ? sanitize_text_field( (string) $req['menu_layout'] ) : 'vertical';
		$menu_animation      = isset( $req['menu_animation'] ) ? sanitize_text_field( (string) $req['menu_animation'] ) : 'off';
		$menu_animation_type = isset( $req['menu_animation_type'] ) ? sanitize_text_field( (string) $req['menu_animation_type'] ) : 'underline';
		$underline_animation = isset( $req['underline_animation'] ) ? sanitize_text_field( (string) $req['underline_animation'] ) : 'left-right';
		$submenu_collapse    = isset( $req['submenu_collapse'] ) ? sanitize_text_field( (string) $req['submenu_collapse'] ) : '';
		$use_schema_markup   = isset( $req['use_schema_markup'] ) ? sanitize_text_field( (string) $req['use_schema_markup'] ) : 'on';

		$builder_edited_post_id = isset( $req['builder_edited_post_id'] )
			? absint( $req['builder_edited_post_id'] )
			: 0;
		if ( $builder_edited_post_id <= 0 && function_exists( 'dsm_get_vb_builder_edited_post_id' ) ) {
			$builder_edited_post_id = dsm_get_vb_builder_edited_post_id();
		}

		$query_backup = self::begin_vb_menu_query_context( $builder_edited_post_id );

		try {
			$menu = self::get_dsm_navmenu(
				array(
					'menu_id'             => $menu_id,
					'menu_layout'         => $menu_layout,
					'menu_animation'      => $menu_animation,
					'menu_animation_type' => $menu_animation_type,
					'underline_animation' => $underline_animation,
					'list_style_type'     => $list_style_type,
					'submenu_collapse'    => $submenu_collapse,
					'use_schema_markup'   => $use_schema_markup,
				)
			);
		} finally {
			self::end_vb_menu_query_context( $query_backup );
		}

		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup from WordPress nav Walker / Core helpers.
		echo $menu;
		exit;
	}

	/**
	 * Register module.
	 */
	public static function register_module() {

		$module_json_path = DSM_DIR_PATH . 'divi-5/public/packages/module-library/menu';

		ModuleRegistration::register_module(
			$module_json_path,
			array(
				'render_callback' => array( self::class, 'render_callback' ),
			)
		);
	}

	/**
	 * Render module style.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_styles( $args ) {
		$args     = \DiviSupreme\Includes\DsmDiviBuilderCssScope::normalize_module_styles_args( $args );
		$attrs    = $args['attrs'] ?? array();
		$elements = $args['elements'];

		$underline_animation = $attrs['underline_animation']['innerContent']['desktop']['value'] ?? '';

		Style::add(
			array(
				'id'            => $args['id'],
				'name'          => $args['name'],
				'orderIndex'    => $args['orderIndex'],
				'storeInstance' => $args['storeInstance'],
				'styles'        => array(
					// Module.
					$elements->style(
						array(
							'attrName'   => 'module',
							'styleProps' => array(
								'disabledOn' => array(
									'disabledModuleVisibility' => $args['settings']['disabledModuleVisibility'] ?? null,
								),
							),
						)
					),

					CssStyle::style(
						array(
							'selector' => $args['orderClass'],
							'attr'     => $attrs['css'] ?? array(),
						)
					),

					$elements->style(
						array(
							'attrName' => 'title',
						)
					),

					$elements->style(
						array(
							'attrName' => 'menu',
						)
					),

					$elements->style(
						array(
							'attrName' => 'sub_menu',
						)
					),

					$elements->style(
						array(
							'attrName' => 'dsm_submenu_collapse',
						)
					),

					$elements->style(
						array(
							'attrName' => 'submenu_arrow_padding',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-menu-title",
							'attr'     => $attrs['title_bottom_gap']['innerContent'] ?? array(),
							'property' => 'padding-bottom',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} ul.dsm-menu li a",
							'attr'     => $attrs['menu_link_text_color']['innerContent'] ?? array(),
							'property' => 'color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} ul.dsm-menu li.current-menu-item a",
							'attr'     => $attrs['active_link_color']['innerContent'] ?? array(),
							'property' => 'color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} ul.dsm-menu li a:active",
							'attr'     => $attrs['menu_link_text_active_color']['innerContent'] ?? array(),
							'property' => 'color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} ul.dsm-menu li a:visited",
							'attr'     => $attrs['menu_link_text_visited_color']['innerContent'] ?? array(),
							'property' => 'color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-menu li:not(:last-child)",
							'attr'     => $attrs['menu_space_between']['innerContent'] ?? array(),
							'property' => 'margin-bottom',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-menu .menu-item-has-children .sub-menu>li",
							'attr'     => $attrs['menu_space_between']['innerContent'] ?? array(),
							'property' => 'margin-top',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} ul.dsm-menu",
							'attr'     => $attrs['menu_left_space']['innerContent'] ?? array(),
							'property' => 'padding-left',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} ul.dsm-menu, {$args['orderClass']} ul.dsm-menu .sub-menu",
							'attr'     => $attrs['list_style_type']['innerContent'] ?? array(),
							'property' => 'list-style-type',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} ul.dsm-menu, {$args['orderClass']} ul.dsm-menu .sub-menu",
							'attr'     => $attrs['list_style_position']['innerContent'] ?? array(),
							'property' => 'list-style-position',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} ul.dsm-menu li",
							'attr'     => $attrs['list_style_color']['innerContent'] ?? array(),
							'property' => 'color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-menu .menu-item-has-children .sub-menu",
							'attr'     => $attrs['submenu_left_space']['innerContent'] ?? array(),
							'property' => 'padding-left',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-menu-animation-{$underline_animation} li a::after",
							'attr'     => $attrs['underline_animation_color']['innerContent'] ?? array(),
							'property' => 'background-color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} ul.dsm-menu-submenu-collapse li a .et-pb-icon",
							'attr'     => $attrs['submenu_arrow_color']['innerContent'] ?? array(),
							'property' => 'color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} ul.dsm-menu-submenu-collapse li a .et-pb-icon",
							'attr'     => $attrs['submenu_arrow_background_color']['innerContent'] ?? array(),
							'property' => 'background-color',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} ul.dsm-menu-submenu-collapse li a .et-pb-icon",
							'attr'     => $attrs['submenu_arrow_font_size']['innerContent'] ?? array(),
							'property' => 'font-size',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} ul.dsm-menu-submenu-collapse li a",
							'attr'     => $attrs['submenu_arrow_gap']['innerContent'] ?? array(),
							'property' => 'gap',
						)
					),

					CommonStyle::style(
						array(
							'selector' => "{$args['orderClass']} .dsm-menu-container",
							'attr'     => $attrs['menu_alignment']['innerContent'] ?? array(),
							'property' => 'text-align',
						)
					),

				),
			)
		);
	}

	/**
	 * Render module script data.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_script_data( $args ) {
		$elements = $args['elements'];

		// Element Script Data Options.
		$elements->script_data(
			array(
				'attrName' => 'module',
			)
		);
	}

	/**
	 * Render module classnames.
	 *
	 * @param array $args - Arguments.
	 */
	public static function module_classnames( $args ) {
		$classnames_instance = $args['classnamesInstance'];
		$attrs               = $args['attrs'];

		// Module.
		$classnames_instance->add(
			ElementClassnames::classnames(
				array(
					'attrs' => $attrs['module']['decoration'] ?? array(),
				)
			)
		);
	}

	/**
	 * Render module HTML output.
	 *
	 * @param array     $attrs - Modules Attributes.
	 * @param string    $content - Content.
	 * @param \WP_Block $block - Block.
	 * @param mixed     $elements - Elements.
	 */
	public static function render_callback( $attrs, $content, $block, $elements ) {

		$menu_id             = $attrs['menu_id']['innerContent']['desktop']['value'] ?? '';
		$title               = $attrs['title']['innerContent']['desktop']['value']['text'] ?? '';
		$html_tag            = HeadingLevel::sanitize(
			$attrs['title']['decoration']['font']['font']['desktop']['value']['headingLevel'] ?? '',
			'h4'
		);
		$use_schema_markup   = $attrs['use_schema_markup']['innerContent']['desktop']['value'] ?? '';
		$list_style_type     = $attrs['list_style_type']['innerContent']['desktop']['value'] ?? '';
		$menu_layout         = $attrs['menu_layout']['innerContent']['desktop']['value'] ?? '';
		$menu_animation      = $attrs['menu_animation']['innerContent']['desktop']['value'] ?? '';
		$menu_animation_type = $attrs['menu_animation_type']['innerContent']['desktop']['value'] ?? '';
		$underline_animation = $attrs['underline_animation']['innerContent']['desktop']['value'] ?? '';
		$submenu_collapse    = $attrs['submenu_collapse']['innerContent']['desktop']['value'] ?? '';

		if ( self::menu_attr_is_on( $submenu_collapse ) ) {
			wp_enqueue_script( 'dsm-menu' );
		}

		$menu = self::get_dsm_navmenu(
			array(
				'menu_id'             => $menu_id,
				'list_style_type'     => $list_style_type,
				'menu_layout'         => $menu_layout,
				'menu_animation'      => $menu_animation,
				'menu_animation_type' => $menu_animation_type,
				'underline_animation' => $underline_animation,
				'submenu_collapse'    => $submenu_collapse,
				'use_schema_markup'   => $use_schema_markup,
			)
		);

		$menu_wrapper = sprintf(
			'%2$s
			 %1$s',
			$menu,
			'' !== $title ? sprintf( '<%2$s class="dsm-menu-title et_pb_module_header">%1$s</%2$s>', esc_html( (string) $title ), esc_attr( $html_tag ) ) : ''
		);

		// Module Inner.
		// Essentially, this is the module content.
		// Were wrapping the title and content in a div with class `et_pb_module_inner`.
		$module_inner = HTMLUtility::render(
			array(
				'tag'               => 'div',
				'attributes'        => array(
					'class' => 'et_pb_module_inner',
				),
				'childrenSanitizer' => 'et_core_esc_previously',
				'children'          => $menu_wrapper,
			)
		);

		// This are the module elements that will be rendered in the frontend.
		$module_elements = $elements->style_components(
			array(
				'attrName' => 'module',
			)
		);

		// This are the children of the module container, which are the module elements and the module inner.
		$module_container_children = $module_elements . $module_inner;

		return Module::render(
			array(
				// FE only.
				'orderIndex'          => $block->parsed_block['orderIndex'],
				'storeInstance'       => $block->parsed_block['storeInstance'],
				// VB equivalent.
				'attrs'               => $attrs,
				'elements'            => $elements,
				'id'                  => $block->parsed_block['id'],
				'moduleClassName'     => 'dsm_menu',
				'name'                => $block->block_type->name,
				'classnamesFunction'  => array( self::class, 'module_classnames' ),
				'moduleCategory'      => $block->block_type->category,
				'stylesComponent'     => array( self::class, 'module_styles' ),
				'scriptDataComponent' => array( self::class, 'module_script_data' ),
				'children'            => $module_container_children,
			)
		);
	}
}
