<?php
/**
 * Plugin file.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);
/**
 * Class DSM_Rest_Extend
 *
 * Extends the WordPress REST API with additional fields for all post types.
 *
 * @package DSM
 * @since 1.0.0
 */
class DSM_Rest_Extend {

	/**
	 * Resolve post ID from `register_rest_field` get_callback argument (array, WP_Post, or stdClass).
	 *
	 * @param mixed $post Value passed by WordPress to the getter.
	 * @return int Post ID, or 0 if not resolvable.
	 */
	private function resolve_rest_callback_post_id( $post ): int {
		if ( is_array( $post ) ) {
			if ( isset( $post['id'] ) ) {
				return (int) $post['id'];
			}
			if ( isset( $post['ID'] ) ) {
				return (int) $post['ID'];
			}
			return 0;
		}
		if ( is_object( $post ) ) {
			if ( isset( $post->ID ) ) {
				return (int) $post->ID;
			}
		}
		return 0;
	}

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		add_action( 'rest_api_init', array( $this, 'register_rest_fields' ) );
	}

	/**
	 * Register custom REST API fields for all post types.
	 *
	 * @since 1.0.0
	 */
	public function register_rest_fields() {
		register_rest_route(
			'dsm/v1',
			'/image-sizes',
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_image_sizes_rest' ),
				'permission_callback' => function () {
					return current_user_can( 'edit_posts' );
				},
			)
		);

		// Public types plus any with a REST collection (many CPTs use public => false, show_in_rest => true).
		$post_types = array_values(
			array_unique(
				array_merge(
					get_post_types( array( 'public' => true ), 'names' ),
					get_post_types( array( 'show_in_rest' => true ), 'names' )
				)
			)
		);

		foreach ( $post_types as $post_type ) {

			register_rest_field(
				$post_type,
				'dsm_author',
				array(
					'get_callback'    => array( $this, 'get_dsm_author' ),
					'update_callback' => null,
					'schema'          => null,
				)
			);

			register_rest_field(
				$post_type,
				'dsm_categories',
				array(
					'get_callback'    => array( $this, 'get_dsm_categories' ),
					'update_callback' => null,
					'schema'          => null,
				)
			);

			register_rest_field(
				$post_type,
				'dsm_attachment_categories',
				array(
					'get_callback'    => array( $this, 'get_dsm_attachment_categories' ),
					'update_callback' => null,
					'schema'          => null,
				)
			);

			register_rest_field(
				$post_type,
				'dsm_featured_image',
				array(
					'get_callback'    => array( $this, 'get_dsm_featured_image' ),
					'update_callback' => null,
					'schema'          => null,
				)
			);

			register_rest_field(
				$post_type,
				'dsm_comment_count',
				array(
					'get_callback'    => array( $this, 'get_dsm_comment_count' ),
					'update_callback' => null,
					'schema'          => array(
						'description' => __( 'Comment count from get_comments_number() (matches theme/module frontend).', 'dsm-supreme-modules-pro-for-divi' ),
						'type'        => 'integer',
						'context'     => array( 'view', 'edit', 'embed' ),
					),
				)
			);
		}
	}

	/**
	 * REST callback: image size slug => human-readable label (matches dsm_get_all_image_sizes).
	 *
	 * @return \WP_REST_Response
	 */
	public function get_image_sizes_rest() {
		if ( ! function_exists( 'dsm_get_all_image_sizes' ) ) {
			require_once DSM_DIR_PATH . 'divi-5/app/Utils/get-image-sizes.php';
		}

		return rest_ensure_response( dsm_get_all_image_sizes() );
	}

	/**
	 * Get author information for the dsm_author field.
	 *
	 * REST `author` is omitted for post types that do not declare `author` in `supports`
	 * (common for CPTs), even though `post_author` exists — match PHP loop behavior by
	 * loading from the post row when needed.
	 *
	 * @param array|\WP_Post $post Prepared REST item (array) or post object.
	 * @return array Author information.
	 * @since 1.0.0
	 */
	public function get_dsm_author( $post ) {
		$post_id = $this->resolve_rest_callback_post_id( $post );

		$author_id = 0;
		if ( is_array( $post ) && isset( $post['author'] ) ) {
			$author_id = (int) $post['author'];
		} elseif ( is_object( $post ) && isset( $post->post_author ) ) {
			$author_id = (int) $post->post_author;
		}

		if ( $post_id > 0 && $author_id < 1 ) {
			$author_id = (int) get_post_field( 'post_author', $post_id );
		}

		if ( $author_id < 1 ) {
			return array(
				'name'         => '',
				'avatar_url'   => '',
				'archive_link' => '',
				'biodata'      => '',
			);
		}

		$author = get_userdata( $author_id );

		if ( ! $author ) {
			return array(
				'name'         => '',
				'avatar_url'   => '',
				'archive_link' => '',
				'biodata'      => '',
			);
		}

		return array(
			'name'         => $author->display_name,
			'avatar_url'   => get_avatar_url( $author_id ),
			'archive_link' => get_author_posts_url( $author_id ),
			'biodata'      => get_the_author_meta( 'description', $author_id ),
		);
	}

	/**
	 * Approved comment count for Visual Builder previews (matches `get_comments_number()` / carousel PHP).
	 *
	 * Core REST `comment_count` can be unset, stale, or out of sync with filtered counts used on the frontend.
	 *
	 * @param array|\WP_Post $post Prepared REST item or post object.
	 * @return int
	 */
	public function get_dsm_comment_count( $post ) {
		$post_id = $this->resolve_rest_callback_post_id( $post );

		if ( $post_id < 1 ) {
			return 0;
		}

		return (int) get_comments_number( $post_id );
	}

	/**
	 * Get categories or terms information for the dsm_categories field.
	 *
	 * @param array|\WP_Post $post Prepared REST item or post object.
	 * @return array<int, array<string, int|string>> Categories or terms information.
	 * @since 1.0.0
	 */
	public function get_dsm_categories( $post ) {
		$post_id = $this->resolve_rest_callback_post_id( $post );
		if ( $post_id < 1 ) {
			return array();
		}

		$post_type = get_post_type( $post_id );
		$taxonomy  = 'post' === $post_type ? 'category' : $post_type . '_category';

		if ( ! taxonomy_exists( $taxonomy ) ) {
			return array();
		}

		$terms = wp_get_post_terms( $post_id, $taxonomy, array( 'fields' => 'all' ) );
		if ( is_wp_error( $terms ) || ! is_array( $terms ) ) {
			return array();
		}

		$result = array();

		foreach ( $terms as $term ) {
			$result[] = array(
				'term_name' => $term->name,
				'term_id'   => $term->term_id,
				'term_link' => get_term_link( $term->term_id, $taxonomy ),
			);
		}

		return $result;
	}

	/**
	 * Terms for the dsm-attachment-category taxonomy (attachments / media).
	 *
	 * @param array|\WP_Post $post Prepared REST item or post object.
	 * @return array<int, array<string, int|string>>
	 * @since 1.0.0
	 */
	public function get_dsm_attachment_categories( $post ) {
		$post_id = $this->resolve_rest_callback_post_id( $post );
		if ( $post_id < 1 ) {
			return array();
		}

		$taxonomy = 'dsm-attachment-category';

		if ( ! taxonomy_exists( $taxonomy ) ) {
			return array();
		}

		$terms = wp_get_post_terms( $post_id, $taxonomy, array( 'fields' => 'all' ) );
		if ( is_wp_error( $terms ) || ! is_array( $terms ) ) {
			return array();
		}

		$result = array();

		foreach ( $terms as $term ) {
			$result[] = array(
				'term_name' => $term->name,
				'term_id'   => $term->term_id,
				'term_link' => get_term_link( $term->term_id, $taxonomy ),
			);
		}

		return $result;
	}

	/**
	 * Get featured image information for the dsm_featured_image field.
	 *
	 * @param array|\WP_Post $post Prepared REST item or post object.
	 * @return array<string, string>|null Featured image URLs per size, or null if no featured image.
	 * @since 1.0.0
	 */
	public function get_dsm_featured_image( $post ) {
		$post_id = $this->resolve_rest_callback_post_id( $post );
		if ( $post_id < 1 ) {
			return null;
		}

		if ( ! has_post_thumbnail( $post_id ) ) {
			return null;
		}

		$featured_image_id = get_post_thumbnail_id( $post_id );
		$image_sizes       = get_intermediate_image_sizes();
		$result            = array();

		foreach ( $image_sizes as $size ) {
			$image = wp_get_attachment_image_src( $featured_image_id, $size );
			if ( $image ) {
				$result[ $size ] = $image[0];
			}
		}

		// Add full size image.
		$full_image = wp_get_attachment_image_src( $featured_image_id, 'full' );
		if ( $full_image ) {
			$result['full'] = $full_image[0];
		}

		return $result;
	}
}

// Initialize the class.
new DSM_Rest_Extend();
