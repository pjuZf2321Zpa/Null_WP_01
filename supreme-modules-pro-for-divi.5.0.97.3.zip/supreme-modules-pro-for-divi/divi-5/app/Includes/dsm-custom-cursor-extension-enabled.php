<?php
/**
 * Custom Cursor extension — global enable flag (Divi Supreme → General).
 *
 * Opt-in: disabled unless the user turns on Enable Custom Cursor in plugin settings.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

if ( ! function_exists( 'dsm_is_custom_cursor_extension_enabled' ) ) {
	/**
	 * Dsm is custom cursor extension enabled.
	 *
	 * @return bool
	 */
	function dsm_is_custom_cursor_extension_enabled(): bool {
		$general = get_option( 'dsm_general', array() );

		if ( ! is_array( $general ) ) {
			return false;
		}

		if ( ! array_key_exists( 'dsm_use_custom_cursor', $general ) ) {
			return false;
		}

		return 'on' === $general['dsm_use_custom_cursor'];
	}
}
