<?php
/**
 * Read-only scan for Supreme Table modules in saved layouts.
 *
 * Never writes `post_content`. Used by the Find tables admin tool (Phase 1).
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Includes;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Locate `dsm/table` / `[dsm_table]` instances without mutating layouts.
 */
final class DsmTableFinder {

	/**
	 * Transient for library usage map (post IDs keyed by library ID).
	 */
	public const USAGE_TRANSIENT = 'dsm_table_library_usage';

	/**
	 * Max `post_content` bytes to pass through `parse_blocks()`.
	 */
	private const PARSE_BLOCKS_MAX_BYTES = 1048576;

	/**
	 * Default cap on posts inspected after the SQL candidate query.
	 */
	private const DEFAULT_MAX_POSTS = 200;

	/**
	 * Post types included in the Find tables scan.
	 *
	 * @return list<string>
	 */
	public static function get_scannable_post_types(): array {
		$types = array( 'page', 'post', 'et_pb_layout' );

		$public = get_post_types(
			array(
				'public'  => true,
				'show_ui' => true,
			),
			'names'
		);

		if ( is_array( $public ) ) {
			foreach ( $public as $name ) {
				if ( is_string( $name ) && ! in_array( $name, $types, true ) ) {
					$types[] = $name;
				}
			}
		}

		/**
		 * Post types included in the Supreme Table finder scan.
		 *
		 * @param list<string> $types Post type slugs.
		 */
		$filtered = apply_filters( 'dsm_table_finder_post_types', $types );

		if ( ! is_array( $filtered ) ) {
			return $types;
		}

		$out = array();
		foreach ( $filtered as $name ) {
			if ( is_string( $name ) && '' !== $name ) {
				$out[] = $name;
			}
		}

		return array_values( array_unique( $out ) );
	}

	/**
	 * Scan layouts for Supreme Table modules.
	 *
	 * Total posts: int,
	 * total_tables: int,
	 * truncated: bool,
	 * items: list<array{
	 * post_id: int,
	 * title: string,
	 * post_type: string,
	 * post_type_label: string,
	 * status: string,
	 * status_label: string,
	 * table_count: int,
	 * sources: list<string>,
	 * edit_url: string,
	 * view_url: string
	 * }>
	 * }
	 *
	 * @return array{
	 */
	public static function scan(): array {
		global $wpdb;

		$empty = array(
			'total_posts'  => 0,
			'total_tables' => 0,
			'truncated'    => false,
			'items'        => array(),
		);

		$post_types = self::get_scannable_post_types();
		if ( array() === $post_types ) {
			return $empty;
		}

		$max_posts = (int) apply_filters( 'dsm_table_finder_max_posts', self::DEFAULT_MAX_POSTS );
		if ( $max_posts < 1 ) {
			$max_posts = self::DEFAULT_MAX_POSTS;
		}

		$placeholders = implode( ', ', array_fill( 0, count( $post_types ), '%s' ) );
		$statuses     = array( 'publish', 'draft', 'private', 'pending', 'future' );
		$stat_place   = implode( ', ', array_fill( 0, count( $statuses ), '%s' ) );

		$like_name   = '%' . $wpdb->esc_like( '"name":"dsm/table"' ) . '%';
		$like_wp_sp  = '%' . $wpdb->esc_like( 'wp:dsm/table ' ) . '%';
		$like_wp_br  = '%' . $wpdb->esc_like( 'wp:dsm/table{' ) . '%';
		$like_wp_cmt = '%' . $wpdb->esc_like( 'wp:dsm/table --' ) . '%';
		$like_d4_sp  = '%' . $wpdb->esc_like( '[dsm_table ' ) . '%';
		$like_d4_cl  = '%' . $wpdb->esc_like( '[dsm_table]' ) . '%';

		$sql = "
			SELECT ID, post_title, post_type, post_status
			FROM {$wpdb->posts}
			WHERE post_type IN ({$placeholders})
			AND post_status IN ({$stat_place})
			AND (
				post_content LIKE %s
				OR post_content LIKE %s
				OR post_content LIKE %s
				OR post_content LIKE %s
				OR post_content LIKE %s
				OR post_content LIKE %s
			)
			ORDER BY post_type ASC, post_title ASC
			LIMIT %d
		";

		$prepare_args = array_merge(
			$post_types,
			$statuses,
			array(
				$like_name,
				$like_wp_sp,
				$like_wp_br,
				$like_wp_cmt,
				$like_d4_sp,
				$like_d4_cl,
				$max_posts + 1,
			)
		);

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- one-shot admin scan; placeholders from trusted type/status lists.
		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $prepare_args ) );

		$truncated = false;
		if ( is_array( $rows ) && count( $rows ) > $max_posts ) {
			$truncated = true;
			$rows      = array_slice( $rows, 0, $max_posts );
		}

		$items        = array();
		$total_tables = 0;
		$usage        = array();

		if ( is_array( $rows ) ) {
			foreach ( $rows as $row ) {
				$post_id = (int) $row->ID;
				$content = (string) get_post_field( 'post_content', $post_id, 'raw' );
				$hits    = self::extract_tables_from_content( $content );
				unset( $content );

				if ( array() === $hits ) {
					continue;
				}

				$sources          = array();
				$lib_ids_for_post = array();
				foreach ( $hits as $hit ) {
					$sources[] = $hit['source'];
					$lib_id    = isset( $hit['library_id'] ) ? (int) $hit['library_id'] : 0;
					if ( $lib_id > 0 ) {
						$lib_ids_for_post[ $lib_id ] = true;
					}
				}
				$sources = array_values( array_unique( $sources ) );

				$title = (string) $row->post_title;
				if ( '' === trim( $title ) ) {
					$title = sprintf(
						/* translators: %d: post ID */
						__( '(no title) — #%d', 'dsm-supreme-modules-pro-for-divi' ),
						$post_id
					);
				}

				$post_type     = (string) $row->post_type;
				$status        = (string) $row->post_status;
				$count         = count( $hits );
				$total_tables += $count;
				$edit_url      = self::edit_url( $post_id );
				$view_url      = self::view_url( $post_id, $status );

				$items[] = array(
					'post_id'         => $post_id,
					'title'           => $title,
					'post_type'       => $post_type,
					'post_type_label' => self::post_type_label( $post_type ),
					'status'          => $status,
					'status_label'    => self::status_label( $status ),
					'table_count'     => $count,
					'sources'         => $sources,
					'edit_url'        => $edit_url,
					'view_url'        => $view_url,
				);

				$usage_entry = array(
					'post_id'  => $post_id,
					'title'    => $title,
					'edit_url' => $edit_url,
					'view_url' => $view_url,
				);
				foreach ( array_keys( $lib_ids_for_post ) as $lib_id ) {
					$usage[ $lib_id ][ $post_id ] = $usage_entry;
				}
			}
		}

		$result = array(
			'total_posts'  => count( $items ),
			'total_tables' => $total_tables,
			'truncated'    => $truncated,
			'items'        => $items,
			'usage'        => $usage,
		);

		/**
		 * Filter Find tables scan results (read-only; do not persist).
		 *
		 * @param array<string, mixed> $result Scan payload.
		 */
		$filtered = apply_filters( 'dsm_table_finder_results', $result );

		return is_array( $filtered ) ? $filtered : $result;
	}

	/**
	 * Library ID => layouts that use it (from the last scan, cached briefly).
	 *
	 * @return array<int, array<int, array{post_id: int, title: string, edit_url: string, view_url: string}>>
	 */
	public static function library_usage_map(): array {
		$cached = get_transient( self::USAGE_TRANSIENT );
		if ( is_array( $cached ) ) {
			return $cached;
		}

		$scan = self::scan();
		$map  = isset( $scan['usage'] ) && is_array( $scan['usage'] ) ? $scan['usage'] : array();

		set_transient( self::USAGE_TRANSIENT, $map, 5 * MINUTE_IN_SECONDS );

		/**
		 * Filter library usage map.
		 *
		 * @param array<int, array<int, array<string, mixed>>> $map Library ID => post ID => layout.
		 */
		$filtered = apply_filters( 'dsm_table_library_usage_map', $map );

		return is_array( $filtered ) ? $filtered : $map;
	}

	/**
	 * Drop the usage transient after library create/update.
	 *
	 * @return void
	 */
	public static function bust_usage_cache(): void {
		delete_transient( self::USAGE_TRANSIENT );
	}

	/**
	 * Human-readable data source label.
	 *
	 * @param string $source Stored source slug.
	 * @return string
	 */
	public static function source_label( string $source ): string {
		switch ( $source ) {
			case 'manual':
				return __( 'Manual', 'dsm-supreme-modules-pro-for-divi' );
			case 'csv':
				return __( 'CSV URL', 'dsm-supreme-modules-pro-for-divi' );
			case 'sheets':
				return __( 'Google Sheets', 'dsm-supreme-modules-pro-for-divi' );
			case 'json':
				return __( 'JSON / REST', 'dsm-supreme-modules-pro-for-divi' );
			case 'loop':
				return __( 'Loop', 'dsm-supreme-modules-pro-for-divi' );
			case 'library':
				return __( 'Library', 'dsm-supreme-modules-pro-for-divi' );
			default:
				return __( 'Unknown', 'dsm-supreme-modules-pro-for-divi' );
		}
	}

	/**
	 * Extract table instances from layout HTML/JSON. Read-only.
	 *
	 * @param string $content Post content.
	 * @return list<array{source: string, format: string, library_id: int}>
	 */
	private static function extract_tables_from_content( string $content ): array {
		$hits = array();

		if ( '' === trim( $content ) ) {
			return $hits;
		}

		if ( function_exists( 'parse_blocks' ) && strlen( $content ) <= self::PARSE_BLOCKS_MAX_BYTES ) {
			foreach ( parse_blocks( $content ) as $block ) {
				if ( is_array( $block ) ) {
					self::walk_block( $block, $hits );
				}
			}
		}

		if ( array() === $hits ) {
			self::collect_d4_shortcodes( $content, $hits );
		}

		return $hits;
	}

	/**
	 * Walk a parsed block tree for `dsm/table` only (not table-of-contents).
	 *
	 * @param array<string, mixed>                                         $block Block.
	 * @param list<array{source: string, format: string, library_id: int}> $hits  Collector.
	 * @return void
	 */
	private static function walk_block( array $block, array &$hits ): void {
		$name = isset( $block['blockName'] ) ? (string) $block['blockName'] : '';
		if ( 'dsm/table' === $name ) {
			$attrs  = isset( $block['attrs'] ) && is_array( $block['attrs'] ) ? $block['attrs'] : array();
			$hits[] = array(
				'source'     => self::read_source_from_attrs( $attrs ),
				'format'     => 'd5',
				'library_id' => self::read_library_id_from_attrs( $attrs ),
			);
		}

		$inner = $block['innerBlocks'] ?? array();
		if ( is_array( $inner ) ) {
			foreach ( $inner as $child ) {
				if ( is_array( $child ) ) {
					self::walk_block( $child, $hits );
				}
			}
		}
	}

	/**
	 * Collect D4 `[dsm_table …]` shortcodes (not `[dsm_table_of_contents]`).
	 *
	 * @param string                                                       $content Post content.
	 * @param list<array{source: string, format: string, library_id: int}> $hits    Collector.
	 * @return void
	 */
	private static function collect_d4_shortcodes( string $content, array &$hits ): void {
		if ( ! preg_match_all( '/\[dsm_table(\s|\])/i', $content, $matches, PREG_OFFSET_CAPTURE ) ) {
			return;
		}

		foreach ( $matches[0] as $match ) {
			$offset     = isset( $match[1] ) ? (int) $match[1] : 0;
			$chunk      = substr( $content, $offset, 800 );
			$source     = 'unknown';
			$library_id = 0;
			if ( preg_match( '/\bdata_source="([^"]*)"/i', $chunk, $attr ) ) {
				$candidate = sanitize_key( (string) $attr[1] );
				if ( in_array( $candidate, array( 'manual', 'csv', 'sheets', 'json', 'loop', 'library' ), true ) ) {
					$source = $candidate;
				}
			}
			if ( preg_match( '/\btable_library_id="(\d+)"/i', $chunk, $lib ) ) {
				$library_id = absint( $lib[1] );
			}
			$hits[] = array(
				'source'     => $source,
				'format'     => 'd4',
				'library_id' => $library_id,
			);
		}
	}

	/**
	 * Read `data_source` from D5 module attrs.
	 *
	 * @param array<string, mixed> $attrs Block attrs.
	 * @return string
	 */
	private static function read_source_from_attrs( array $attrs ): string {
		$node  = $attrs['data_source'] ?? null;
		$value = '';

		if ( is_string( $node ) ) {
			$value = $node;
		} elseif ( is_array( $node ) ) {
			$inner = $node['innerContent']['desktop']['value'] ?? $node['desktop']['value'] ?? null;
			if ( is_string( $inner ) ) {
				$value = $inner;
			}
		}

		$value = sanitize_key( $value );
		if ( in_array( $value, array( 'manual', 'csv', 'sheets', 'json', 'loop', 'library' ), true ) ) {
			return $value;
		}

		return 'manual';
	}

	/**
	 * Read `table_library_id` from D5 module attrs.
	 *
	 * @param array<string, mixed> $attrs Block attrs.
	 * @return int
	 */
	private static function read_library_id_from_attrs( array $attrs ): int {
		$node  = $attrs['table_library_id'] ?? null;
		$value = '';

		if ( is_string( $node ) || is_int( $node ) ) {
			$value = (string) $node;
		} elseif ( is_array( $node ) ) {
			$inner = $node['innerContent']['desktop']['value'] ?? $node['desktop']['value'] ?? null;
			if ( is_string( $inner ) || is_int( $inner ) ) {
				$value = (string) $inner;
			}
		}

		return absint( $value );
	}

	/**
	 * Singular post type label, or the slug if the type is unknown.
	 *
	 * @param string $post_type Post type slug.
	 * @return string
	 */
	private static function post_type_label( string $post_type ): string {
		$object = get_post_type_object( $post_type );
		if ( $object && isset( $object->labels->singular_name ) ) {
			return (string) $object->labels->singular_name;
		}

		return $post_type;
	}

	/**
	 * Localized post status label, or the raw status slug.
	 *
	 * @param string $status Post status.
	 * @return string
	 */
	private static function status_label( string $status ): string {
		$object = get_post_status_object( $status );
		if ( $object && isset( $object->label ) ) {
			return (string) $object->label;
		}

		return $status;
	}

	/**
	 * Open Visual Builder when the layout has a frontend URL.
	 *
	 * Built like Divi’s `et_fb_get_vb_url()` (`et_fb=1&PageSpeed=off`) without
	 * calling that helper (it can boot the builder during a scan). Divi Library
	 * layouts and posts with no permalink fall back to `post.php`.
	 *
	 * @param int $post_id Post ID.
	 * @return string
	 */
	private static function edit_url( int $post_id ): string {
		if ( $post_id <= 0 || ! current_user_can( 'edit_post', $post_id ) ) {
			return '';
		}

		$admin_edit = admin_url( 'post.php?post=' . $post_id . '&action=edit' );

		if ( 'et_pb_layout' === get_post_type( $post_id ) ) {
			return $admin_edit;
		}

		$permalink = get_permalink( $post_id );
		if ( ! is_string( $permalink ) || '' === $permalink ) {
			return $admin_edit;
		}

		return add_query_arg(
			array(
				'et_fb'     => '1',
				'PageSpeed' => 'off',
			),
			$permalink
		);
	}

	/**
	 * Frontend URL when the post is viewable.
	 *
	 * @param int    $post_id Post ID.
	 * @param string $status  Post status.
	 * @return string
	 */
	private static function view_url( int $post_id, string $status ): string {
		if ( 'publish' !== $status ) {
			return '';
		}

		$link = get_permalink( $post_id );

		return is_string( $link ) ? $link : '';
	}
}
