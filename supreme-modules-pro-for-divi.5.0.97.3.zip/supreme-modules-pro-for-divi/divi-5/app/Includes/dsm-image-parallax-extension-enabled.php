<?php
/**
 * Image Parallax extension — global enable flag (Divi Supreme → General).
 *
 * Opt-in: disabled unless the user turns on Enable Image Parallax in plugin settings.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

if ( ! function_exists( 'dsm_is_image_parallax_extension_enabled' ) ) {
	/**
	 * Dsm is image parallax extension enabled.
	 *
	 * @return bool
	 */
	function dsm_is_image_parallax_extension_enabled(): bool {
		$general = get_option( 'dsm_general', array() );

		if ( ! is_array( $general ) ) {
			return false;
		}

		if ( ! array_key_exists( 'dsm_use_image_parallax', $general ) ) {
			return false;
		}

		return 'on' === $general['dsm_use_image_parallax'];
	}
}
