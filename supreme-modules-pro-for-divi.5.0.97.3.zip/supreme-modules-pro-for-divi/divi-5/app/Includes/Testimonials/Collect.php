<?php
/**
 * Public collect REST endpoint — creates a pending testimonial.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Includes\Testimonials;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * POST `/dsm/v1/testimonials/collect`.
 */
final class Collect {

	/**
	 * Collect form nonce action.
	 */
	public const NONCE_ACTION = 'dsm_testimonials_collect';

	/**
	 * Author name max length (matches collect form maxlength).
	 */
	public const AUTHOR_MAX_LENGTH = 120;

	/**
	 * Email max length (matches collect form maxlength).
	 */
	public const EMAIL_MAX_LENGTH = 200;

	/**
	 * Company max length (matches collect form maxlength).
	 */
	public const COMPANY_MAX_LENGTH = 120;

	/**
	 * Quote max length (matches collect form maxlength).
	 */
	public const QUOTE_MAX_LENGTH = 4000;

	/**
	 * Register REST route.
	 *
	 * @return void
	 */
	public static function register_routes(): void {
		register_rest_route(
			Cpt::REST_NAMESPACE,
			'/testimonials/collect',
			array(
				'methods'             => 'POST',
				'callback'            => array( self::class, 'handle' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'dsm_testimonials_nonce' => array(
						'type'     => 'string',
						'required' => true,
					),
					'dsm_author'             => array(
						'type'      => 'string',
						'required'  => true,
						'maxLength' => self::AUTHOR_MAX_LENGTH,
					),
					'dsm_email'              => array(
						'type'      => 'string',
						'required'  => true,
						'maxLength' => self::EMAIL_MAX_LENGTH,
					),
					'dsm_quote'              => array(
						'type'      => 'string',
						'required'  => true,
						'maxLength' => self::QUOTE_MAX_LENGTH,
					),
					'dsm_rating'             => array(
						'type'     => 'number',
						'required' => false,
					),
					'dsm_company'            => array(
						'type'      => 'string',
						'required'  => false,
						'maxLength' => self::COMPANY_MAX_LENGTH,
					),
					'dsm_consent'            => array(
						'type'     => 'string',
						'required' => false,
					),
					'dsm_hp'                 => array(
						'type'     => 'string',
						'required' => false,
					),
				),
			)
		);
	}

	/**
	 * Handle collect POST.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public static function handle( \WP_REST_Request $request ) {
		$nonce = sanitize_text_field( (string) $request->get_param( 'dsm_testimonials_nonce' ) );
		if ( ! wp_verify_nonce( $nonce, self::NONCE_ACTION ) ) {
			return new \WP_Error(
				'dsm_testimonials_nonce',
				__( 'Invalid security token. Please reload and try again.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 403 )
			);
		}

		$honeypot = sanitize_text_field( (string) $request->get_param( 'dsm_hp' ) );
		if ( '' !== $honeypot ) {
			return new \WP_REST_Response(
				array(
					'success' => true,
					'message' => __( 'Thank you. Your review was submitted and is waiting for approval.', 'dsm-supreme-modules-pro-for-divi' ),
				),
				200
			);
		}

		$consent = sanitize_text_field( (string) $request->get_param( 'dsm_consent' ) );
		if ( '1' !== $consent && 'on' !== $consent ) {
			return new \WP_Error(
				'dsm_testimonials_consent',
				__( 'Please agree to the terms before submitting your review.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 400 )
			);
		}

		if ( ! self::rate_limit_ok() ) {
			return new \WP_Error(
				'dsm_testimonials_rate',
				__( 'Please wait a moment before submitting another review.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 429 )
			);
		}

		$author  = sanitize_text_field( (string) $request->get_param( 'dsm_author' ) );
		$email   = sanitize_email( (string) $request->get_param( 'dsm_email' ) );
		$quote   = sanitize_textarea_field( (string) $request->get_param( 'dsm_quote' ) );
		$company = sanitize_text_field( (string) $request->get_param( 'dsm_company' ) );
		$rating  = Cpt::sanitize_rating( $request->get_param( 'dsm_rating' ) );

		$too_long = strlen( $author ) > self::AUTHOR_MAX_LENGTH
			|| strlen( $email ) > self::EMAIL_MAX_LENGTH
			|| strlen( $company ) > self::COMPANY_MAX_LENGTH
			|| strlen( $quote ) > self::QUOTE_MAX_LENGTH;

		if ( $too_long ) {
			return new \WP_Error(
				'dsm_testimonials_too_long',
				__( 'Your review is too long.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 400 )
			);
		}

		$author_ok = '' !== $author;
		$email_ok  = '' !== $email && is_email( $email );
		$quote_ok  = '' !== $quote;

		if ( ! $author_ok || ! $email_ok || ! $quote_ok ) {
			return new \WP_Error(
				'dsm_testimonials_invalid',
				self::invalid_fields_message( $author_ok, $email_ok, $quote_ok, true ),
				array( 'status' => 400 )
			);
		}

		$post_args = array(
			'post_type'    => Cpt::POST_TYPE,
			'post_status'  => 'pending',
			'post_title'   => $author,
			'post_content' => $quote,
			'post_author'  => 0,
		);

		/**
		 * Filters `wp_insert_post` args for collected testimonials.
		 *
		 * @param array<string, mixed> $post_args Insert args.
		 * @param \WP_REST_Request     $request   Request.
		 */
		$post_args = apply_filters( 'dsm_testimonials_collect_post_args', $post_args, $request );
		if ( ! is_array( $post_args ) ) {
			return new \WP_Error( 'dsm_testimonials_insert', __( 'Could not save your review.', 'dsm-supreme-modules-pro-for-divi' ), array( 'status' => 500 ) );
		}

		$post_id = wp_insert_post( $post_args, true );
		if ( is_wp_error( $post_id ) || ! $post_id ) {
			return new \WP_Error(
				'dsm_testimonials_insert',
				__( 'Could not save your review.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 500 )
			);
		}

		$post_id = (int) $post_id;

		update_post_meta( $post_id, Cpt::META_AUTHOR, $author );
		update_post_meta( $post_id, Cpt::META_EMAIL, $email );
		update_post_meta( $post_id, Cpt::META_COMPANY, $company );
		update_post_meta( $post_id, Cpt::META_RATING, $rating );
		update_post_meta( $post_id, Cpt::META_SOURCE, 'form' );
		update_post_meta( $post_id, Cpt::META_MODERATION, Cpt::MODERATION_PENDING );
		update_post_meta( $post_id, Cpt::META_CONSENT_AT, gmdate( 'c' ) );
		update_post_meta( $post_id, Cpt::META_REVIEW_DATE, current_time( 'Y-m-d' ) );
		update_post_meta( $post_id, Cpt::META_SCHEMA_INCLUDE, 'on' );

		/**
		 * Fires after a collected testimonial is stored as pending.
		 *
		 * @param int              $post_id Post ID.
		 * @param \WP_REST_Request $request Request.
		 */
		do_action( 'dsm_testimonials_collected', $post_id, $request );

		return new \WP_REST_Response(
			array(
				'success' => true,
				'message' => __( 'Thank you. Your review was submitted and is waiting for approval.', 'dsm-supreme-modules-pro-for-divi' ),
			),
			201
		);
	}

	/**
	 * Join localized list items with “and”.
	 *
	 * @param string[] $items Phrases such as “your name”.
	 * @return string
	 */
	private static function join_list( array $items ): string {
		$items = array_values( $items );
		$count = count( $items );

		if ( 0 === $count ) {
			return '';
		}

		if ( 1 === $count ) {
			return $items[0];
		}

		if ( 2 === $count ) {
			/* translators: 1: first item, 2: second item. */
			return sprintf( __( '%1$s and %2$s', 'dsm-supreme-modules-pro-for-divi' ), $items[0], $items[1] );
		}

		$last = array_pop( $items );

		/* translators: 1: comma-separated items, 2: last item. */
		return sprintf( __( '%1$s, and %2$s', 'dsm-supreme-modules-pro-for-divi' ), implode( ', ', $items ), $last );
	}

	/**
	 * Validation copy for the fields that failed.
	 *
	 * @param bool $author_ok  Name is present.
	 * @param bool $email_ok   Email is present and valid.
	 * @param bool $quote_ok   Review is present.
	 * @param bool $consent_ok Consent is accepted.
	 * @return string
	 */
	public static function invalid_fields_message( bool $author_ok, bool $email_ok, bool $quote_ok, bool $consent_ok ): string {
		$parts = array();

		if ( ! $author_ok ) {
			$parts[] = __( 'your name', 'dsm-supreme-modules-pro-for-divi' );
		}
		if ( ! $email_ok ) {
			$parts[] = __( 'a valid email address', 'dsm-supreme-modules-pro-for-divi' );
		}
		if ( ! $quote_ok ) {
			$parts[] = __( 'your review', 'dsm-supreme-modules-pro-for-divi' );
		}

		if ( array() === $parts ) {
			$message = __( 'Please agree to the terms before submitting your review.', 'dsm-supreme-modules-pro-for-divi' );
		} else {
			$list = self::join_list( $parts );
			if ( $consent_ok ) {
				/* translators: %s: list of missing fields, e.g. “a valid email address”. */
				$message = sprintf( __( 'Please enter %s.', 'dsm-supreme-modules-pro-for-divi' ), $list );
			} else {
				/* translators: %s: list of missing fields, e.g. “your name and a valid email address”. */
				$message = sprintf( __( 'Please enter %s, and agree to the terms.', 'dsm-supreme-modules-pro-for-divi' ), $list );
			}
		}

		/**
		 * Filters the collect-form validation message.
		 *
		 * @param string $message    Localized message.
		 * @param bool   $author_ok  Name is present.
		 * @param bool   $email_ok   Email is present and valid.
		 * @param bool   $quote_ok   Review is present.
		 * @param bool   $consent_ok Consent is accepted.
		 */
		$filtered = apply_filters( 'dsm_testimonials_collect_invalid_message', $message, $author_ok, $email_ok, $quote_ok, $consent_ok );

		return is_string( $filtered ) && '' !== $filtered ? $filtered : $message;
	}

	/**
	 * One submission per IP per minute.
	 *
	 * @return bool
	 */
	private static function rate_limit_ok(): bool {
		$ip  = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( (string) $_SERVER['REMOTE_ADDR'] ) ) : '';
		$key = 'dsm_tmon_' . md5( $ip . wp_salt( 'nonce' ) );

		if ( false !== get_transient( $key ) ) {
			return false;
		}

		set_transient( $key, '1', MINUTE_IN_SECONDS );
		return true;
	}
}
