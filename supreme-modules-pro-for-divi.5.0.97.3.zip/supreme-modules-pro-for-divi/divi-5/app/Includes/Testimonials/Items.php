<?php
/**
 * Resolve testimonial item models from a module source.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Includes\Testimonials;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Source dispatcher (visual children, CPT library, Woo, comments).
 */
final class Items {

	/**
	 * Item models for a source.
	 *
	 * @param string                     $source          visual|library|woocommerce|comments.
	 * @param array<string, mixed>       $query_args      Query args.
	 * @param list<array<string, mixed>> $visual_items    Already mapped visual children.
	 * @return list<array<string, mixed>>
	 */
	public static function from_source( string $source, array $query_args, array $visual_items ): array {
		$source = sanitize_key( $source );

		if ( 'woocommerce' === $source ) {
			return Adapters::woocommerce_items( $query_args );
		}

		if ( 'comments' === $source ) {
			return Adapters::comments_items( $query_args );
		}

		if ( 'library' === $source ) {
			return Query::library_items( $query_args );
		}

		if ( 'visual' !== $source ) {
			return array();
		}

		return $visual_items;
	}

	/**
	 * Map a Visual Builder child module's attrs to the item model.
	 *
	 * @param array<string, mixed> $attrs Child attrs.
	 * @param string               $id    Child block id.
	 * @return array<string, mixed>
	 */
	public static function from_child_attrs( array $attrs, string $id = '' ): array {
		$avatar_raw  = Attrs::inner_raw( $attrs, 'dsm_avatar' );
		$poster_raw  = Attrs::inner_raw( $attrs, 'dsm_video_poster' );
		$product_raw = Attrs::inner_raw( $attrs, 'dsm_product_image' );
		$tags_raw    = Attrs::inner_string( $attrs, 'dsm_tags' );
		$tags        = array();
		if ( '' !== $tags_raw ) {
			foreach ( explode( ',', $tags_raw ) as $tag ) {
				$slug = sanitize_title( trim( $tag ) );
				if ( '' !== $slug ) {
					$tags[] = $slug;
				}
			}
		}

		$rating = Cpt::sanitize_rating( Attrs::inner_string( $attrs, 'dsm_rating', '5' ) );
		$source = sanitize_key( Attrs::inner_string( $attrs, 'dsm_source', 'manual' ) );
		if ( ! in_array( $source, Cpt::source_slugs(), true ) ) {
			$source = 'manual';
		}

		return array(
			'id'             => $id,
			'author'         => Attrs::inner_string( $attrs, 'dsm_author' ),
			'role'           => Attrs::inner_string( $attrs, 'dsm_role' ),
			'company'        => Attrs::inner_string( $attrs, 'dsm_company' ),
			'email'          => '',
			'avatar_id'      => 0,
			'avatar_url'     => self::upload_url( $avatar_raw ),
			'rating'         => $rating,
			'date'           => Attrs::sanitize_review_date( Attrs::inner_string( $attrs, 'dsm_review_date' ) ),
			'date_iso'       => Attrs::review_date_iso( Attrs::inner_string( $attrs, 'dsm_review_date' ) ),
			'source'         => $source,
			'source_url'     => Attrs::inner_string( $attrs, 'dsm_source_url' ),
			'quote'          => Attrs::inner_html( $attrs, 'dsm_quote' ),
			'video_url'      => Attrs::inner_string( $attrs, 'dsm_video_url' ),
			'video_poster'   => self::upload_url( $poster_raw ),
			'product_image'  => self::upload_url( $product_raw ),
			'tags'           => $tags,
			'schema_include' => 'off' !== Attrs::inner_string( $attrs, 'dsm_schema_include', 'on' ),
		);
	}

	/**
	 * Upload innerContent → URL.
	 *
	 * @param mixed $raw Upload leaf.
	 * @return string
	 */
	private static function upload_url( $raw ): string {
		if ( class_exists( \DiviSupreme\Includes\UploadImageMarkup::class ) ) {
			return \DiviSupreme\Includes\UploadImageMarkup::resolve_upload_src_string( $raw );
		}

		if ( is_string( $raw ) ) {
			return $raw;
		}

		if ( is_array( $raw ) ) {
			if ( isset( $raw['src'] ) && is_string( $raw['src'] ) ) {
				return $raw['src'];
			}
			if ( isset( $raw['url'] ) && is_string( $raw['url'] ) ) {
				return $raw['url'];
			}
		}

		return '';
	}
}
