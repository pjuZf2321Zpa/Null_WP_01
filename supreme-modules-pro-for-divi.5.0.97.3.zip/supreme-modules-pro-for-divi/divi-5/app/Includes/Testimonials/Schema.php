<?php
/**
 * Optional Product JSON-LD for Supreme Testimonials (off by default).
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Includes\Testimonials;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Review snippet markup. LocalBusiness / Organization self-serving reviews are never emitted.
 *
 * @link https://developers.google.com/search/docs/appearance/structured-data/review-snippet
 */
final class Schema {

	/**
	 * Item types eligible for Review snippets (self-serving LocalBusiness is excluded).
	 *
	 * @return list<string>
	 */
	public static function eligible_types(): array {
		$types = array(
			'Product',
			'SoftwareApplication',
			'Book',
			'Course',
			'Event',
			'Movie',
			'Game',
			'Recipe',
		);

		/**
		 * Filters schema.org types allowed for Testimonials JSON-LD.
		 *
		 * @param list<string> $types Type names.
		 */
		$filtered = apply_filters( 'dsm_testimonials_schema_eligible_types', $types );

		return is_array( $filtered ) ? array_values( array_map( 'strval', $filtered ) ) : $types;
	}

	/**
	 * Build JSON-LD for owned reviews only (manual, form, woocommerce, comments).
	 *
	 * Third-party imported reviews (v2 Google/Trustpilot) must never be aggregated here.
	 *
	 * @param list<array<string, mixed>> $items Item models.
	 * @param array<string, mixed>       $attrs Parent attrs.
	 * @return string JSON-LD script or empty.
	 */
	public static function script( array $items, array $attrs ): string {
		if ( ! Attrs::inner_on( $attrs, 'dsm_schema_enable', 'off' ) ) {
			return '';
		}

		$type = Attrs::inner_string( $attrs, 'dsm_schema_item_type', 'Product' );
		if ( in_array( $type, array( 'LocalBusiness', 'Organization' ), true ) ) {
			return '';
		}

		if ( ! in_array( $type, self::eligible_types(), true ) ) {
			$type = 'Product';
		}

		$name = Attrs::inner_string( $attrs, 'dsm_schema_item_name', '' );
		if ( '' === $name ) {
			$name = wp_strip_all_tags( get_bloginfo( 'name' ) );
		}

		$owned_sources = array( 'manual', 'form', 'woocommerce', 'comments' );
		$reviews       = array();
		$sum           = 0.0;
		$count         = 0;

		foreach ( $items as $item ) {
			if ( empty( $item['schema_include'] ) ) {
				continue;
			}

			$source = isset( $item['source'] ) ? sanitize_key( (string) $item['source'] ) : 'manual';
			if ( ! in_array( $source, $owned_sources, true ) ) {
				continue;
			}

			$rating = isset( $item['rating'] ) ? Cpt::sanitize_rating( $item['rating'] ) : 0.0;
			if ( $rating <= 0 ) {
				continue;
			}

			$author = isset( $item['author'] ) ? wp_strip_all_tags( (string) $item['author'] ) : '';
			$body   = isset( $item['quote'] ) ? wp_strip_all_tags( (string) $item['quote'] ) : '';

			$review = array(
				'@type'        => 'Review',
				'author'       => array(
					'@type' => 'Person',
					'name'  => $author,
				),
				'reviewRating' => array(
					'@type'       => 'Rating',
					'ratingValue' => $rating,
					'bestRating'  => 5,
					'worstRating' => 1,
				),
			);

			if ( '' !== $body ) {
				$review['reviewBody'] = $body;
			}

			$reviews[] = $review;
			$sum      += $rating;
			++$count;
		}

		if ( 0 === $count ) {
			return '';
		}

		$graph = array(
			'@context'        => 'https://schema.org',
			'@type'           => $type,
			'name'            => $name,
			'aggregateRating' => array(
				'@type'       => 'AggregateRating',
				'ratingValue' => round( $sum / $count, 1 ),
				'reviewCount' => $count,
				'bestRating'  => 5,
				'worstRating' => 1,
			),
			'review'          => $reviews,
		);

		/**
		 * Filters Product/eligible JSON-LD before encoding.
		 *
		 * @param array<string, mixed>       $graph Schema graph.
		 * @param list<array<string, mixed>> $items Source items.
		 * @param array<string, mixed>       $attrs Parent attrs.
		 */
		$graph = apply_filters( 'dsm_testimonials_schema_graph', $graph, $items, $attrs );
		if ( ! is_array( $graph ) ) {
			return '';
		}

		$json = wp_json_encode( $graph, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
		if ( ! is_string( $json ) || '' === $json ) {
			return '';
		}

		$json = str_replace( array( '<', '>' ), array( '\u003C', '\u003E' ), $json );

		return et_core_intentionally_unescaped( '<script type="application/ld+json">' . $json . '</script>', 'html' );
	}
}
