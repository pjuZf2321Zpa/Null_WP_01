<?php
/**
 * Privacy exporter and eraser for testimonial PII.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Includes\Testimonials;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * WP privacy tools: author name, email, quote, company.
 */
final class Privacy {

	/**
	 * Register exporter and eraser.
	 *
	 * @return void
	 */
	public static function register(): void {
		add_filter( 'wp_privacy_personal_data_exporters', array( self::class, 'register_exporter' ) );
		add_filter( 'wp_privacy_personal_data_erasers', array( self::class, 'register_eraser' ) );
	}

	/**
	 * Add exporter.
	 *
	 * @param array<string, mixed> $exporters Exporters.
	 * @return array<string, mixed>
	 */
	public static function register_exporter( array $exporters ): array {
		$exporters['dsm-testimonials'] = array(
			'exporter_friendly_name' => __( 'Supreme Testimonials', 'dsm-supreme-modules-pro-for-divi' ),
			'callback'               => array( self::class, 'export' ),
		);
		return $exporters;
	}

	/**
	 * Add eraser.
	 *
	 * @param array<string, mixed> $erasers Erasers.
	 * @return array<string, mixed>
	 */
	public static function register_eraser( array $erasers ): array {
		$erasers['dsm-testimonials'] = array(
			'eraser_friendly_name' => __( 'Supreme Testimonials', 'dsm-supreme-modules-pro-for-divi' ),
			'callback'             => array( self::class, 'erase' ),
		);
		return $erasers;
	}

	/**
	 * Export testimonials matching an email.
	 *
	 * @param string $email_address Email.
	 * @param int    $page          Page.
	 * @return array{data: list<array<string, mixed>>, done: bool}
	 */
	public static function export( string $email_address, int $page = 1 ) {
		unset( $page );

		$items = self::posts_for_email( $email_address );
		$data  = array();

		foreach ( $items as $post ) {
			$data[] = array(
				'group_id'    => 'dsm-testimonials',
				'group_label' => __( 'Supreme Testimonials', 'dsm-supreme-modules-pro-for-divi' ),
				'item_id'     => 'dsm-testimonial-' . $post->ID,
				'data'        => array(
					array(
						'name'  => __( 'Name', 'dsm-supreme-modules-pro-for-divi' ),
						'value' => (string) get_post_meta( $post->ID, Cpt::META_AUTHOR, true ),
					),
					array(
						'name'  => __( 'Email', 'dsm-supreme-modules-pro-for-divi' ),
						'value' => (string) get_post_meta( $post->ID, Cpt::META_EMAIL, true ),
					),
					array(
						'name'  => __( 'Company', 'dsm-supreme-modules-pro-for-divi' ),
						'value' => (string) get_post_meta( $post->ID, Cpt::META_COMPANY, true ),
					),
					array(
						'name'  => __( 'Review', 'dsm-supreme-modules-pro-for-divi' ),
						'value' => wp_strip_all_tags( (string) $post->post_content ),
					),
				),
			);
		}

		return array(
			'data' => $data,
			'done' => true,
		);
	}

	/**
	 * Erase PII on matching testimonials (keeps an anonymized pending/approved row).
	 *
	 * @param string $email_address Email.
	 * @param int    $page          Page.
	 * @return array{items_removed: bool, items_retained: bool, messages: list<string>, done: bool}
	 */
	public static function erase( string $email_address, int $page = 1 ) {
		unset( $page );

		$items    = self::posts_for_email( $email_address );
		$removed  = false;
		$retained = false;
		$messages = array();

		foreach ( $items as $post ) {
			$anon = __( 'Anonymous', 'dsm-supreme-modules-pro-for-divi' );
			wp_update_post(
				array(
					'ID'           => $post->ID,
					'post_title'   => $anon,
					'post_content' => '',
				)
			);
			update_post_meta( $post->ID, Cpt::META_AUTHOR, $anon );
			update_post_meta( $post->ID, Cpt::META_EMAIL, '' );
			update_post_meta( $post->ID, Cpt::META_COMPANY, '' );
			update_post_meta( $post->ID, Cpt::META_ROLE, '' );
			$removed = true;
		}

		/**
		 * Filters the privacy eraser result for testimonials.
		 *
		 * @param array<string, mixed> $result Result payload.
		 * @param string               $email_address Email.
		 */
		$result = array(
			'items_removed'  => $removed,
			'items_retained' => $retained,
			'messages'       => $messages,
			'done'           => true,
		);

		$filtered = apply_filters( 'dsm_testimonials_privacy_erase_result', $result, $email_address );
		return is_array( $filtered ) ? $filtered : $result;
	}

	/**
	 * Posts whose `_dsm_email` matches.
	 *
	 * @param string $email_address Email.
	 * @return list<\WP_Post>
	 */
	private static function posts_for_email( string $email_address ): array {
		$email_address = sanitize_email( $email_address );
		if ( '' === $email_address || ! is_email( $email_address ) ) {
			return array();
		}

		$query = new \WP_Query(
			array(
				'post_type'      => Cpt::POST_TYPE,
				'post_status'    => 'any',
				'posts_per_page' => 100,
				'meta_key'       => Cpt::META_EMAIL, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
				'meta_value'     => $email_address, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
				'no_found_rows'  => true,
			)
		);

		$posts = array();
		foreach ( $query->posts as $post ) {
			if ( $post instanceof \WP_Post ) {
				$posts[] = $post;
			}
		}

		wp_reset_postdata();
		return $posts;
	}
}
