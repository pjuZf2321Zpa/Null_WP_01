<?php
/**
 * Parent card composition classnames (matches JS card-layout.js).
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Includes\Testimonials;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Sanitize and map card layout / align attrs to BEM parent classes.
 */
final class CardComposition {

	/**
	 * BEM classnames for the parent card composition attrs.
	 *
	 * @param array<string, mixed> $attrs Parent module attrs.
	 * @return list<string>
	 */
	public static function classnames( array $attrs ): array {
		$layout  = self::card_layout( Attrs::inner_string( $attrs, 'dsm_card_layout', 'quote_above' ) );
		$author  = self::align( Attrs::inner_string( $attrs, 'dsm_author_align', 'left' ) );
		$quote   = self::align( Attrs::inner_string( $attrs, 'dsm_quote_align', 'left' ) );
		$avatar  = 'above' === Attrs::inner_string( $attrs, 'dsm_avatar_placement', 'beside' )
			? 'above'
			: 'beside';
		$stars   = self::stars_placement( Attrs::inner_string( $attrs, 'dsm_stars_placement', 'below_quote' ) );
		$date    = self::date_placement( Attrs::inner_string( $attrs, 'dsm_date_placement', 'footer' ) );
		$source  = self::source_placement( Attrs::inner_string( $attrs, 'dsm_source_placement', 'footer' ) );
		$product = self::media_placement( Attrs::inner_string( $attrs, 'dsm_product_placement', 'top' ) );
		$video   = self::media_placement( Attrs::inner_string( $attrs, 'dsm_video_placement', 'top' ) );

		/**
		 * Filter the normalized source placement slug.
		 *
		 * @param string               $source Normalized slug.
		 * @param array<string, mixed> $attrs  Parent module attrs.
		 */
		$source = self::source_placement(
			(string) apply_filters( 'dsm_testimonials_source_placement', $source, $attrs )
		);

		return array(
			'dsm-testimonials-card-' . str_replace( '_', '-', $layout ),
			'dsm-testimonials-author-align-' . $author,
			'dsm-testimonials-quote-align-' . $quote,
			'dsm-testimonials-avatar-' . $avatar,
			'dsm-testimonials-stars-' . str_replace( '_', '-', $stars ),
			'dsm-testimonials-date-' . str_replace( '_', '-', $date ),
			'dsm-testimonials-source-' . str_replace( '_', '-', $source ),
			'dsm-testimonials-product-' . $product,
			'dsm-testimonials-video-' . $video,
		);
	}

	/**
	 * Allowed card layout slug, or quote_above.
	 *
	 * @param string $raw Stored card layout.
	 * @return string
	 */
	private static function card_layout( string $raw ): string {
		$allowed = array( 'quote_above', 'author_above', 'author_left', 'author_right' );

		return in_array( $raw, $allowed, true ) ? $raw : 'quote_above';
	}

	/**
	 * Native Divi alignmentOptions: left / center / right.
	 *
	 * @param string $raw Stored align value.
	 * @return string
	 */
	private static function align( string $raw ): string {
		$slug = strtolower( trim( $raw ) );

		if ( 'center' === $slug ) {
			return 'center';
		}

		if ( in_array( $slug, array( 'right', 'end' ), true ) ) {
			return 'right';
		}

		return 'left';
	}

	/**
	 * Allowed stars placement slug, or below_quote.
	 *
	 * @param string $raw Stored stars placement.
	 * @return string
	 */
	private static function stars_placement( string $raw ): string {
		$allowed = array( 'below_quote', 'above_quote', 'above_author', 'below_author' );

		return in_array( $raw, $allowed, true ) ? $raw : 'below_quote';
	}

	/**
	 * Allowed date placement slug, or footer.
	 *
	 * @param string $raw Stored date placement.
	 * @return string
	 */
	private static function date_placement( string $raw ): string {
		$allowed = array( 'footer', 'below_quote', 'above_quote', 'above_author', 'below_author' );

		return in_array( $raw, $allowed, true ) ? $raw : 'footer';
	}

	/**
	 * Allowed source placement slug, or footer.
	 *
	 * @param string $raw Stored source placement.
	 * @return string
	 */
	private static function source_placement( string $raw ): string {
		$allowed = array( 'footer', 'below_quote', 'above_quote', 'above_author', 'below_author' );

		return in_array( $raw, $allowed, true ) ? $raw : 'footer';
	}

	/**
	 * Product / video: top (current) or bottom of the card. Not inside quote/author.
	 *
	 * @param string $raw Stored media placement.
	 * @return string
	 */
	private static function media_placement( string $raw ): string {
		return 'bottom' === $raw ? 'bottom' : 'top';
	}
}
