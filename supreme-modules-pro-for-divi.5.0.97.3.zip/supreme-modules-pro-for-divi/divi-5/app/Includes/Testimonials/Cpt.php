<?php
/**
 * Testimonials custom post type, taxonomy, and REST meta.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Includes\Testimonials;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Registers `dsm_testimonial` and `dsm_testimonial_tag`.
 */
final class Cpt {

	/**
	 * CPT slug.
	 */
	public const POST_TYPE = 'dsm_testimonial';

	/**
	 * Tag taxonomy slug.
	 */
	public const TAXONOMY = 'dsm_testimonial_tag';

	/**
	 * REST namespace.
	 */
	public const REST_NAMESPACE = 'dsm/v1';

	/**
	 * Author name meta key.
	 */
	public const META_AUTHOR = '_dsm_author';

	/**
	 * Author email meta key (not shown on the frontend).
	 */
	public const META_EMAIL = '_dsm_email';

	/**
	 * Role meta key.
	 */
	public const META_ROLE = '_dsm_role';

	/**
	 * Company meta key.
	 */
	public const META_COMPANY = '_dsm_company';

	/**
	 * Avatar attachment ID meta key.
	 */
	public const META_AVATAR_ID = '_dsm_avatar_id';

	/**
	 * Rating meta key (0–5).
	 */
	public const META_RATING = '_dsm_rating';

	/**
	 * Review date meta key.
	 */
	public const META_REVIEW_DATE = '_dsm_review_date';

	/**
	 * Source slug meta key (manual|form|woocommerce|comments).
	 */
	public const META_SOURCE = '_dsm_source';

	/**
	 * Source URL meta key.
	 */
	public const META_SOURCE_URL = '_dsm_source_url';

	/**
	 * Video URL meta key.
	 */
	public const META_VIDEO_URL = '_dsm_video_url';

	/**
	 * Video poster attachment ID meta key.
	 */
	public const META_VIDEO_POSTER_ID = '_dsm_video_poster_id';

	/**
	 * Product image attachment ID meta key.
	 */
	public const META_PRODUCT_IMAGE_ID = '_dsm_product_image_id';

	/**
	 * Moderation slug meta key.
	 */
	public const META_MODERATION = '_dsm_moderation';

	/**
	 * Consent timestamp meta key (ISO-8601).
	 */
	public const META_CONSENT_AT = '_dsm_consent_at';

	/**
	 * Include-in-schema flag meta key.
	 */
	public const META_SCHEMA_INCLUDE = '_dsm_schema_include';

	/**
	 * Pending moderation slug.
	 */
	public const MODERATION_PENDING = 'pending';

	/**
	 * Approved moderation slug.
	 */
	public const MODERATION_APPROVED = 'approved';

	/**
	 * Rejected moderation slug.
	 */
	public const MODERATION_REJECTED = 'rejected';

	/**
	 * Admin / library capability (same as Form Entries and Table Library).
	 */
	public const CAPABILITY = 'manage_options';

	/**
	 * Whether the current user can manage the Testimonials library.
	 *
	 * @return bool
	 */
	public static function current_user_can_manage(): bool {
		return current_user_can( self::CAPABILITY );
	}

	/**
	 * Register CPT, taxonomy, and REST-visible meta.
	 *
	 * @return void
	 */
	public static function register(): void {
		$labels = array(
			'name'               => __( 'Testimonials', 'dsm-supreme-modules-pro-for-divi' ),
			'singular_name'      => __( 'Testimonial', 'dsm-supreme-modules-pro-for-divi' ),
			'menu_name'          => __( 'Testimonials', 'dsm-supreme-modules-pro-for-divi' ),
			'all_items'          => __( 'All Testimonials', 'dsm-supreme-modules-pro-for-divi' ),
			'add_new'            => __( 'Add New', 'dsm-supreme-modules-pro-for-divi' ),
			'add_new_item'       => __( 'Add New Testimonial', 'dsm-supreme-modules-pro-for-divi' ),
			'edit_item'          => __( 'Edit Testimonial', 'dsm-supreme-modules-pro-for-divi' ),
			'new_item'           => __( 'New Testimonial', 'dsm-supreme-modules-pro-for-divi' ),
			'view_item'          => __( 'View Testimonial', 'dsm-supreme-modules-pro-for-divi' ),
			'search_items'       => __( 'Search Testimonials', 'dsm-supreme-modules-pro-for-divi' ),
			'not_found'          => __( 'No testimonials found.', 'dsm-supreme-modules-pro-for-divi' ),
			'not_found_in_trash' => __( 'No testimonials found in Trash.', 'dsm-supreme-modules-pro-for-divi' ),
		);

		$args = array(
			'labels'              => $labels,
			'public'              => false,
			'publicly_queryable'  => false,
			'show_ui'             => true,
			'show_in_menu'        => false,
			'show_in_admin_bar'   => false,
			'show_in_rest'        => true,
			'rest_base'           => 'dsm-testimonials',
			'exclude_from_search' => true,
			'has_archive'         => false,
			'rewrite'             => false,
			'query_var'           => false,
			'capability_type'     => 'post',
			'map_meta_cap'        => false,
			'capabilities'        => array(
				'edit_post'           => self::CAPABILITY,
				'read_post'           => self::CAPABILITY,
				'delete_post'         => self::CAPABILITY,
				'edit_posts'          => self::CAPABILITY,
				'edit_others_posts'   => self::CAPABILITY,
				'delete_posts'        => self::CAPABILITY,
				'delete_others_posts' => self::CAPABILITY,
				'read_private_posts'  => self::CAPABILITY,
				'publish_posts'       => self::CAPABILITY,
				'create_posts'        => self::CAPABILITY,
			),
			'supports'            => array( 'title', 'editor', 'thumbnail', 'custom-fields' ),
		);

		/**
		 * Filters `register_post_type` args for Supreme Testimonials.
		 *
		 * @param array<string, mixed> $args Register args.
		 */
		$args = apply_filters( 'dsm_testimonials_post_type_args', $args );

		register_post_type( self::POST_TYPE, is_array( $args ) ? $args : array() );

		// Loop Builder / Dynamic Content need `show_in_rest`, but GET must not be anonymous.
		add_filter( 'rest_' . self::POST_TYPE . '_query', array( self::class, 'restrict_rest_query' ), 10, 2 );
		add_filter( 'rest_pre_dispatch', array( self::class, 'restrict_core_rest' ), 10, 3 );

		$tax_labels = array(
			'name'          => __( 'Testimonial Tags', 'dsm-supreme-modules-pro-for-divi' ),
			'singular_name' => __( 'Testimonial Tag', 'dsm-supreme-modules-pro-for-divi' ),
			'search_items'  => __( 'Search Tags', 'dsm-supreme-modules-pro-for-divi' ),
			'all_items'     => __( 'All Tags', 'dsm-supreme-modules-pro-for-divi' ),
			'edit_item'     => __( 'Edit Tag', 'dsm-supreme-modules-pro-for-divi' ),
			'add_new_item'  => __( 'Add New Tag', 'dsm-supreme-modules-pro-for-divi' ),
			'menu_name'     => __( 'Tags', 'dsm-supreme-modules-pro-for-divi' ),
		);

		$tax_args = array(
			'labels'            => $tax_labels,
			'public'            => false,
			'show_ui'           => true,
			'show_in_menu'      => false,
			'show_in_rest'      => true,
			'show_admin_column' => true,
			'hierarchical'      => false,
			'rewrite'           => false,
			'query_var'         => false,
			'capabilities'      => array(
				'manage_terms' => self::CAPABILITY,
				'edit_terms'   => self::CAPABILITY,
				'delete_terms' => self::CAPABILITY,
				'assign_terms' => self::CAPABILITY,
			),
		);

		/**
		 * Filters tag taxonomy args for Supreme Testimonials.
		 *
		 * @param array<string, mixed> $tax_args Taxonomy args.
		 */
		$tax_args = apply_filters( 'dsm_testimonials_taxonomy_args', $tax_args );

		register_taxonomy( self::TAXONOMY, self::POST_TYPE, is_array( $tax_args ) ? $tax_args : array() );

		self::register_meta();
	}

	/**
	 * Register REST-visible post meta used by Loop Builder / Dynamic Content.
	 *
	 * @return void
	 */
	private static function register_meta(): void {
		$string_keys = array(
			self::META_AUTHOR,
			self::META_ROLE,
			self::META_COMPANY,
			self::META_REVIEW_DATE,
			self::META_SOURCE,
			self::META_SOURCE_URL,
			self::META_VIDEO_URL,
			self::META_MODERATION,
			self::META_SCHEMA_INCLUDE,
		);

		foreach ( $string_keys as $key ) {
			register_post_meta(
				self::POST_TYPE,
				$key,
				array(
					'type'              => 'string',
					'single'            => true,
					'show_in_rest'      => true,
					'sanitize_callback' => 'sanitize_text_field',
					'auth_callback'     => array( self::class, 'meta_auth' ),
				)
			);
		}

		register_post_meta(
			self::POST_TYPE,
			self::META_EMAIL,
			array(
				'type'              => 'string',
				'single'            => true,
				'show_in_rest'      => false,
				'sanitize_callback' => 'sanitize_email',
				'auth_callback'     => array( self::class, 'meta_auth' ),
			)
		);

		// Consent timestamp is GDPR-adjacent and is not needed for Loop Builder / Dynamic Content.
		register_post_meta(
			self::POST_TYPE,
			self::META_CONSENT_AT,
			array(
				'type'              => 'string',
				'single'            => true,
				'show_in_rest'      => false,
				'sanitize_callback' => 'sanitize_text_field',
				'auth_callback'     => array( self::class, 'meta_auth' ),
			)
		);

		$int_keys = array(
			self::META_AVATAR_ID,
			self::META_VIDEO_POSTER_ID,
			self::META_PRODUCT_IMAGE_ID,
		);

		foreach ( $int_keys as $key ) {
			register_post_meta(
				self::POST_TYPE,
				$key,
				array(
					'type'              => 'integer',
					'single'            => true,
					'show_in_rest'      => true,
					'sanitize_callback' => 'absint',
					'auth_callback'     => array( self::class, 'meta_auth' ),
				)
			);
		}

		register_post_meta(
			self::POST_TYPE,
			self::META_RATING,
			array(
				'type'              => 'number',
				'single'            => true,
				'show_in_rest'      => true,
				'sanitize_callback' => array( self::class, 'sanitize_rating' ),
				'auth_callback'     => array( self::class, 'meta_auth' ),
			)
		);
	}

	/**
	 * REST meta auth: library managers only.
	 *
	 * @return bool
	 */
	public static function meta_auth(): bool {
		return self::current_user_can_manage();
	}

	/**
	 * Empty the core REST collection for users who cannot manage the library.
	 *
	 * @param array<string, mixed> $args    WP_Query args.
	 * @param \WP_REST_Request     $request Request.
	 * @return array<string, mixed>
	 */
	public static function restrict_rest_query( array $args, $request ): array {
		unset( $request );

		if ( self::current_user_can_manage() ) {
			return $args;
		}

		$args['post__in'] = array( 0 );
		return $args;
	}

	/**
	 * Require `manage_options` for GET/HEAD on `/wp/v2/dsm-testimonials`.
	 *
	 * `show_in_rest` stays true for Visual Builder Loop Builder / Dynamic Content.
	 * Published posts would otherwise be readable by anonymous clients.
	 *
	 * @param mixed            $result  Dispatch result.
	 * @param \WP_REST_Server  $server  Server.
	 * @param \WP_REST_Request $request Request.
	 * @return mixed
	 */
	public static function restrict_core_rest( $result, $server, $request ) {
		unset( $server );

		if ( null !== $result ) {
			return $result;
		}

		$method = $request->get_method();
		if ( ! in_array( $method, array( 'GET', 'HEAD' ), true ) ) {
			return $result;
		}

		$route = $request->get_route();
		if ( ! is_string( $route ) ) {
			return $result;
		}

		$post_type = get_post_type_object( self::POST_TYPE );
		$namespace = 'wp/v2';
		$rest_base = 'dsm-testimonials';
		if ( $post_type instanceof \WP_Post_Type ) {
			if ( is_string( $post_type->rest_namespace ) && '' !== $post_type->rest_namespace ) {
				$namespace = trim( $post_type->rest_namespace, '/' );
			}
			if ( is_string( $post_type->rest_base ) && '' !== $post_type->rest_base ) {
				$rest_base = trim( $post_type->rest_base, '/' );
			}
		}

		$pattern = '#^/' . preg_quote( $namespace, '#' ) . '/' . preg_quote( $rest_base, '#' ) . '(?:/|$)#';
		if ( 1 !== preg_match( $pattern, $route ) ) {
			return $result;
		}

		if ( self::current_user_can_manage() ) {
			return $result;
		}

		return new \WP_Error(
			'rest_forbidden',
			__( 'Sorry, you are not allowed to access testimonials.', 'dsm-supreme-modules-pro-for-divi' ),
			array( 'status' => rest_authorization_required_code() )
		);
	}

	/**
	 * Clamp rating to 0–5.
	 *
	 * @param mixed $value Raw rating.
	 * @return float
	 */
	public static function sanitize_rating( $value ): float {
		if ( is_array( $value ) ) {
			if ( isset( $value['text'] ) ) {
				$value = $value['text'];
			} elseif ( isset( $value['value'] ) ) {
				$value = $value['value'];
			}
		}

		if ( is_string( $value ) && preg_match( '/-?\d+(?:\.\d+)?/', $value, $matches ) ) {
			$value = $matches[0];
		}

		$rating = is_numeric( $value ) ? (float) $value : 0.0;
		if ( $rating < 0 ) {
			return 0.0;
		}
		if ( $rating > 5 ) {
			return 5.0;
		}
		return round( $rating, 1 );
	}

	/**
	 * Allowed source slugs.
	 *
	 * @return list<string>
	 */
	public static function source_slugs(): array {
		$slugs = array( 'manual', 'form', 'woocommerce', 'comments' );

		/**
		 * Filters allowed testimonial source slugs (v2 adapters append here).
		 *
		 * @param list<string> $slugs Source identifiers.
		 */
		$filtered = apply_filters( 'dsm_testimonials_source_slugs', $slugs );

		return is_array( $filtered ) ? array_values( array_map( 'strval', $filtered ) ) : $slugs;
	}

	/**
	 * Read moderation slug from a post.
	 *
	 * @param int $post_id Post ID.
	 * @return string
	 */
	public static function get_moderation( int $post_id ): string {
		$value = (string) get_post_meta( $post_id, self::META_MODERATION, true );
		if ( in_array( $value, array( self::MODERATION_PENDING, self::MODERATION_APPROVED, self::MODERATION_REJECTED ), true ) ) {
			return $value;
		}
		return self::MODERATION_PENDING;
	}

	/**
	 * Whether a post is frontend-eligible (approved + publish).
	 *
	 * @param int $post_id Post ID.
	 * @return bool
	 */
	public static function is_approved_for_frontend( int $post_id ): bool {
		$post = get_post( $post_id );
		if ( ! $post instanceof \WP_Post || self::POST_TYPE !== $post->post_type ) {
			return false;
		}
		return 'publish' === $post->post_status && self::MODERATION_APPROVED === self::get_moderation( $post_id );
	}
}
