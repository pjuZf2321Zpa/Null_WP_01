<?php
/**
 * Divi 5 innerContent helpers for Supreme Testimonials.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Includes\Testimonials;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Read D5 `innerContent.desktop.value` leaves (string, `{ text }`, or upload).
 */
final class Attrs {

	/**
	 * Cached module-default-render-attributes.json.
	 *
	 * @var array<string, mixed>|null
	 */
	private static $default_render_attrs = null;

	/**
	 * Load Testimonials defaults from the public package JSON.
	 *
	 * @return array<string, mixed>
	 */
	public static function default_render_attributes(): array {
		if ( null !== self::$default_render_attrs ) {
			return self::$default_render_attrs;
		}

		$path = DSM_DIR_PATH . 'divi-5/public/packages/module-library/testimonials/module-default-render-attributes.json';
		if ( ! is_readable( $path ) ) {
			self::$default_render_attrs = array();

			return self::$default_render_attrs;
		}

		$decoded                    = wp_json_file_decode( $path, array( 'associative' => true ) );
		self::$default_render_attrs = is_array( $decoded ) ? $decoded : array();

		return self::$default_render_attrs;
	}

	/**
	 * Deep-merge stored innerContent over JSON defaults (stored wins).
	 *
	 * Divi omits tablet/phone keys that match defaultAttrs. The Visual Builder
	 * still sees them via FieldContainer defaultAttr; frontend CommonStyle only
	 * iterates keys present on the attr.
	 *
	 * @param array<string, mixed> $stored   Saved innerContent.
	 * @param array<string, mixed> $defaults Default innerContent.
	 * @return array<string, mixed>
	 */
	public static function merge_inner_content( array $stored, array $defaults ): array {
		if ( array() === $defaults ) {
			return $stored;
		}

		if ( array() === $stored ) {
			return $defaults;
		}

		return array_replace_recursive( $defaults, $stored );
	}

	/**
	 * InnerContent for CommonStyle, with omitted breakpoint defaults restored.
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 * @param string               $key   Attribute name.
	 * @return array<string, mixed>
	 */
	public static function style_inner_content( array $attrs, string $key ): array {
		$defaults      = self::default_render_attributes();
		$default_inner = $defaults[ $key ]['innerContent'] ?? array();
		$stored        = $attrs[ $key ]['innerContent'] ?? array();

		return self::merge_inner_content(
			is_array( $stored ) ? $stored : array(),
			is_array( $default_inner ) ? $default_inner : array()
		);
	}

	/**
	 * Desktop innerContent leaf for an attribute key.
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 * @param string               $key   Attribute name.
	 * @return mixed
	 */
	public static function inner_raw( array $attrs, string $key ) {
		return $attrs[ $key ]['innerContent']['desktop']['value'] ?? null;
	}

	/**
	 * Plain string from TextContainer / Select / Toggle / Range.
	 *
	 * @param array<string, mixed> $attrs    Module attrs.
	 * @param string               $key      Attribute name.
	 * @param string               $fallback Fallback when empty.
	 * @return string
	 */
	public static function inner_string( array $attrs, string $key, string $fallback = '' ): string {
		$raw = self::inner_raw( $attrs, $key );

		if ( is_string( $raw ) || is_numeric( $raw ) ) {
			$out = trim( (string) $raw );
			return '' !== $out ? $out : $fallback;
		}

		if ( is_array( $raw ) && isset( $raw['text'] ) && is_string( $raw['text'] ) ) {
			$out = trim( $raw['text'] );
			return '' !== $out ? $out : $fallback;
		}

		return $fallback;
	}

	/**
	 * Layout slug. Retired `badge` and `featured` render as grid.
	 *
	 * @param array<string, mixed> $attrs    Module attrs.
	 * @param string               $fallback Fallback when empty.
	 * @return string
	 */
	public static function layout( array $attrs, string $fallback = 'grid' ): string {
		$raw = self::inner_string( $attrs, 'dsm_layout', $fallback );

		return in_array( $raw, array( 'badge', 'featured' ), true ) ? $fallback : $raw;
	}

	/**
	 * Layouts that support Equal Height (Grid, Marquee).
	 *
	 * @return array<int, string>
	 */
	public static function equal_height_layouts(): array {
		$layouts = array( 'grid', 'marquee' );

		/**
		 * Filter layouts that show Equal Height.
		 *
		 * @param array<int, string> $layouts Layout slugs.
		 */
		return apply_filters( 'dsm_testimonials_equal_height_layouts', $layouts );
	}

	/**
	 * Whether layout Equal Height is on (`dsm_equal_height`, legacy stretch key).
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 * @return bool
	 */
	public static function dsm_equal_height_on( array $attrs ): bool {
		$layout = self::layout( $attrs, 'grid' );
		if ( ! in_array( $layout, self::equal_height_layouts(), true ) ) {
			return false;
		}

		$current = self::inner_raw( $attrs, 'dsm_equal_height' );
		if ( null !== $current && '' !== $current ) {
			return self::inner_on( $attrs, 'dsm_equal_height', 'off' );
		}

		return self::inner_on( $attrs, 'dsm_marquee_stretch_height', 'off' );
	}

	/**
	 * Rich-text HTML from RichTextContainer (`value` or `value.text`).
	 *
	 * @param array<string, mixed> $attrs    Module attrs.
	 * @param string               $key      Attribute name.
	 * @param string               $fallback Fallback when empty.
	 * @return string
	 */
	public static function inner_html( array $attrs, string $key, string $fallback = '' ): string {
		$raw = self::inner_raw( $attrs, $key );

		if ( is_string( $raw ) || is_numeric( $raw ) ) {
			$out = trim( (string) $raw );
			return '' !== $out ? $out : $fallback;
		}

		if ( is_array( $raw ) && isset( $raw['text'] ) && is_string( $raw['text'] ) ) {
			$out = trim( $raw['text'] );
			return '' !== $out ? $out : $fallback;
		}

		return $fallback;
	}

	/**
	 * Whether a toggle is `on`.
	 *
	 * @param array<string, mixed> $attrs        Module attrs.
	 * @param string               $key          Attribute name.
	 * @param string               $default_slug Default `on`/`off` when missing.
	 * @return bool
	 */
	public static function inner_on( array $attrs, string $key, string $default_slug = 'off' ): bool {
		$value = self::inner_string( $attrs, $key, $default_slug );
		return 'on' === $value;
	}

	/**
	 * Marquee hover action, falling back to the legacy pause_on_hover toggle.
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 * @return string none|pause|reverse|speed_up
	 */
	public static function hover_action( array $attrs ): string {
		$action = self::inner_string( $attrs, 'dsm_hover_action', '' );
		if ( in_array( $action, array( 'none', 'pause', 'reverse', 'speed_up' ), true ) ) {
			return apply_filters( 'dsm_testimonials_hover_action', $action, $attrs );
		}

		$mapped = self::inner_on( $attrs, 'pause_on_hover', 'on' ) ? 'pause' : 'none';

		return apply_filters( 'dsm_testimonials_hover_action', $mapped, $attrs );
	}

	/**
	 * Responsive innerContent map (desktop / tablet / phone).
	 *
	 * @param array<string, mixed> $attrs    Module attrs.
	 * @param string               $key      Attribute name.
	 * @param string               $fallback Fallback desktop value.
	 * @return array{desktop:string,tablet:string,phone:string}
	 */
	public static function inner_responsive( array $attrs, string $key, string $fallback = '' ): array {
		$inner   = self::style_inner_content( $attrs, $key );
		$desktop = self::leaf_to_string( $inner['desktop']['value'] ?? null, $fallback );
		$tablet  = self::leaf_to_string( $inner['tablet']['value'] ?? null, $desktop );
		$phone   = self::leaf_to_string( $inner['phone']['value'] ?? null, $tablet );

		return array(
			'desktop' => $desktop,
			'tablet'  => $tablet,
			'phone'   => $phone,
		);
	}

	/**
	 * Default chrome section ids (aggregate → filters → items → form).
	 *
	 * @return string[]
	 */
	public static function chrome_order_default_ids(): array {
		return array( 'aggregate', 'filters', 'items', 'form' );
	}

	/**
	 * Map a SortableList value / alias to a chrome section id.
	 *
	 * @param string $raw Raw row value.
	 * @return string Empty when unknown.
	 */
	public static function resolve_chrome_id( string $raw ): string {
		$key = strtolower( trim( $raw ) );
		$map = array(
			'aggregate'      => 'aggregate',
			'rating summary' => 'aggregate',
			'summary'        => 'aggregate',
			'filters'        => 'filters',
			'filter'         => 'filters',
			'items'          => 'items',
			'testimonials'   => 'items',
			'cards'          => 'items',
			'form'           => 'form',
			'collect form'   => 'form',
			'collect'        => 'form',
		);

		return $map[ $key ] ?? '';
	}

	/**
	 * Normalize SortableList chrome rows to the four known ids.
	 *
	 * @param mixed $raw `innerContent` leaf (array of `{ value, dragID }` or strings).
	 * @return string[]
	 */
	public static function normalize_chrome_order_ids( $raw ): array {
		$seen    = array();
		$ordered = array();

		$push = static function ( string $id ) use ( &$seen, &$ordered ): void {
			if ( '' === $id || isset( $seen[ $id ] ) ) {
				return;
			}
			if ( ! in_array( $id, self::chrome_order_default_ids(), true ) ) {
				return;
			}
			$seen[ $id ] = true;
			$ordered[]   = $id;
		};

		$rows = array();
		if ( is_array( $raw ) ) {
			$rows = $raw;
		} elseif ( is_string( $raw ) && '' !== trim( $raw ) ) {
			$trimmed = trim( $raw );
			if ( '[' === $trimmed[0] || '{' === $trimmed[0] ) {
				$decoded = json_decode( $trimmed, true );
				$rows    = is_array( $decoded ) ? $decoded : array();
			} else {
				$split = preg_split( '/[,|]/', $trimmed );
				$rows  = is_array( $split ) ? $split : array();
			}
		}

		foreach ( $rows as $row ) {
			if ( is_string( $row ) || is_numeric( $row ) ) {
				$push( self::resolve_chrome_id( (string) $row ) );
				continue;
			}
			if ( ! is_array( $row ) ) {
				continue;
			}
			$value = $row['value'] ?? '';
			if ( is_string( $value ) || is_numeric( $value ) ) {
				$push( self::resolve_chrome_id( (string) $value ) );
			}
		}

		foreach ( self::chrome_order_default_ids() as $id ) {
			$push( $id );
		}

		return $ordered;
	}

	/**
	 * Chrome section ids after toggles.
	 *
	 * @param array<string, mixed> $attrs        Module attrs.
	 * @param string               $layout       Layout slug.
	 * @param bool                 $show_agg     Show aggregate.
	 * @param bool                 $show_filters Show filters.
	 * @param bool                 $show_form    Show collect form.
	 * @return string[]
	 */
	public static function visible_chrome_sections( array $attrs, string $layout, bool $show_agg, bool $show_filters, bool $show_form ): array {
		$raw = self::inner_raw( $attrs, 'dsm_chrome_order' );
		$ids = self::normalize_chrome_order_ids( $raw );

		$visible = array();
		foreach ( $ids as $id ) {
			if ( 'aggregate' === $id ) {
				if ( $show_agg ) {
					$visible[] = $id;
				}
				continue;
			}
			if ( 'filters' === $id ) {
				if ( $show_filters ) {
					$visible[] = $id;
				}
				continue;
			}
			if ( 'form' === $id ) {
				if ( $show_form ) {
					$visible[] = $id;
				}
				continue;
			}
			$visible[] = $id;
		}

		/**
		 * Visible testimonials chrome section ids.
		 *
		 * @param string[]             $visible Visible ids.
		 * @param array<string, mixed> $attrs   Module attrs.
		 * @param string               $layout  Layout slug.
		 */
		$filtered = apply_filters( 'dsm_testimonials_visible_chrome_sections', $visible, $attrs, $layout );

		return is_array( $filtered ) ? $filtered : $visible;
	}

	/**
	 * Sanitize a review date to `Y-m-d` or `Y-m-d H:i:s`. Invalid text becomes empty.
	 *
	 * @param string $raw Stored or submitted date.
	 * @return string
	 */
	public static function sanitize_review_date( string $raw ): string {
		$raw = trim( $raw );
		if ( '' === $raw ) {
			return '';
		}

		if ( preg_match( '/^(\d{4}-\d{2}-\d{2})(?:[ T](\d{2}:\d{2})(?::(\d{2}))?)?$/', $raw, $matches ) ) {
			$day = $matches[1];
			if ( ! self::is_valid_ymd( $day ) ) {
				return '';
			}

			if ( empty( $matches[2] ) ) {
				return $day;
			}

			$seconds = isset( $matches[3] ) && '' !== $matches[3] ? $matches[3] : '00';

			return $day . ' ' . $matches[2] . ':' . $seconds;
		}

		$timestamp = strtotime( $raw );
		if ( false === $timestamp ) {
			return '';
		}

		if ( preg_match( '/\d{1,2}:\d{2}/', $raw ) ) {
			return wp_date( 'Y-m-d H:i:s', $timestamp );
		}

		return wp_date( 'Y-m-d', $timestamp );
	}

	/**
	 * `Y-m-d` value for the admin datepicker hidden field.
	 *
	 * @param string $raw Stored date.
	 * @return string
	 */
	public static function review_date_input_value( string $raw ): string {
		$sanitized = self::sanitize_review_date( $raw );

		return '' !== $sanitized ? substr( $sanitized, 0, 10 ) : '';
	}

	/**
	 * ISO datetime attribute for `<time datetime>`.
	 *
	 * @param string $raw Stored date.
	 * @return string
	 */
	public static function review_date_iso( string $raw ): string {
		$sanitized = self::sanitize_review_date( $raw );
		if ( '' === $sanitized ) {
			return '';
		}

		$timestamp = strtotime( $sanitized );
		if ( false === $timestamp ) {
			return '';
		}

		return wp_date( 'c', $timestamp );
	}

	/**
	 * PHP date format used for visible review dates (Settings → General).
	 *
	 * WordPress core default is `F j, Y` (e.g. September 9, 2026).
	 *
	 * @param string $raw Stored date passed to the format filter.
	 * @return string
	 */
	public static function review_date_display_format( string $raw = '' ): string {
		$format = get_option( 'date_format' );
		if ( ! is_string( $format ) || '' === $format ) {
			$format = 'F j, Y';
		}

		/**
		 * Filters the visible testimonials review date format (PHP date format).
		 *
		 * @param string $format PHP date format.
		 * @param string $raw    Original stored date.
		 */
		$filtered = apply_filters( 'dsm_testimonials_review_date_format', $format, $raw );
		if ( ! is_string( $filtered ) || '' === $filtered ) {
			return 'F j, Y';
		}

		return $filtered;
	}

	/**
	 * Visible review date using the site date format.
	 *
	 * @param string $raw Stored date.
	 * @return string
	 */
	public static function format_review_date( string $raw ): string {
		$sanitized = self::sanitize_review_date( $raw );
		if ( '' === $sanitized ) {
			return '';
		}

		$timestamp = strtotime( $sanitized );
		if ( false === $timestamp ) {
			return '';
		}

		return wp_date( self::review_date_display_format( $raw ), $timestamp );
	}

	/**
	 * Whether a `Y-m-d` string is a real calendar day.
	 *
	 * @param string $day Date string.
	 * @return bool
	 */
	private static function is_valid_ymd( string $day ): bool {
		$parsed = date_parse_from_format( 'Y-m-d', $day );

		return is_array( $parsed )
			&& empty( $parsed['error_count'] )
			&& checkdate( (int) ( $parsed['month'] ?? 0 ), (int) ( $parsed['day'] ?? 0 ), (int) ( $parsed['year'] ?? 0 ) );
	}

	/**
	 * Normalize a leaf to a trimmed string.
	 *
	 * @param mixed  $raw      Leaf value.
	 * @param string $fallback Fallback.
	 * @return string
	 */
	private static function leaf_to_string( $raw, string $fallback ): string {
		if ( is_string( $raw ) || is_numeric( $raw ) ) {
			$out = trim( (string) $raw );
			return '' !== $out ? $out : $fallback;
		}

		if ( is_array( $raw ) && isset( $raw['text'] ) && is_string( $raw['text'] ) ) {
			$out = trim( $raw['text'] );
			return '' !== $out ? $out : $fallback;
		}

		return $fallback;
	}
}
