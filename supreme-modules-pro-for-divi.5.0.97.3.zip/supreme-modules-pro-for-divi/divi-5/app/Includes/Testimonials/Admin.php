<?php
/**
 * Admin UI: submenu, columns, Approve/Reject, metabox.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Includes\Testimonials;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Testimonials library screens under Divi Supreme.
 */
final class Admin {

	/**
	 * Hook admin.
	 *
	 * @return void
	 */
	public static function register(): void {
		add_action( 'admin_menu', array( self::class, 'register_menu' ), 100 );
		add_filter( 'manage_' . Cpt::POST_TYPE . '_posts_columns', array( self::class, 'columns' ) );
		add_action( 'manage_' . Cpt::POST_TYPE . '_posts_custom_column', array( self::class, 'column_content' ), 10, 2 );
		add_filter( 'post_row_actions', array( self::class, 'row_actions' ), 10, 2 );
		add_action( 'add_meta_boxes_' . Cpt::POST_TYPE, array( self::class, 'metaboxes' ) );
		add_action( 'admin_enqueue_scripts', array( self::class, 'enqueue_metabox_assets' ) );
		add_action( 'save_post_' . Cpt::POST_TYPE, array( self::class, 'save_metabox' ), 10, 2 );
		add_filter( 'wp_insert_post_data', array( self::class, 'force_pending_until_approved' ), 10, 2 );
		add_action( 'admin_post_dsm_testimonial_moderate', array( self::class, 'handle_moderate' ) );
		add_action( 'admin_notices', array( self::class, 'pending_notice' ) );
		add_filter( 'display_post_states', array( self::class, 'post_states' ), 10, 2 );
	}

	/**
	 * Submenu under Divi Supreme.
	 *
	 * @return void
	 */
	public static function register_menu(): void {
		if ( ! Cpt::current_user_can_manage() ) {
			return;
		}

		add_submenu_page(
			'divi_supreme_settings',
			__( 'Testimonials', 'dsm-supreme-modules-pro-for-divi' ),
			__( 'Testimonials', 'dsm-supreme-modules-pro-for-divi' ),
			Cpt::CAPABILITY,
			'edit.php?post_type=' . Cpt::POST_TYPE
		);
	}

	/**
	 * List columns.
	 *
	 * @param array<string, string> $columns Columns.
	 * @return array<string, string>
	 */
	public static function columns( array $columns ): array {
		$out = array();
		foreach ( $columns as $key => $label ) {
			$out[ $key ] = $label;
			if ( 'title' === $key ) {
				$out['dsm_rating']     = __( 'Rating', 'dsm-supreme-modules-pro-for-divi' );
				$out['dsm_source']     = __( 'Source', 'dsm-supreme-modules-pro-for-divi' );
				$out['dsm_moderation'] = __( 'Moderation', 'dsm-supreme-modules-pro-for-divi' );
			}
		}
		return $out;
	}

	/**
	 * Column cells.
	 *
	 * @param string $column  Column id.
	 * @param int    $post_id Post ID.
	 * @return void
	 */
	public static function column_content( string $column, int $post_id ): void {
		if ( 'dsm_rating' === $column ) {
			$rating = Cpt::sanitize_rating( get_post_meta( $post_id, Cpt::META_RATING, true ) );
			echo esc_html( $rating > 0 ? (string) $rating : '—' );
			return;
		}

		if ( 'dsm_source' === $column ) {
			$source = sanitize_key( (string) get_post_meta( $post_id, Cpt::META_SOURCE, true ) );
			echo esc_html( Markup::source_label( $source ) );
			return;
		}

		if ( 'dsm_moderation' === $column ) {
			echo esc_html( self::moderation_label( Cpt::get_moderation( $post_id ) ) );
		}
	}

	/**
	 * Approve / Reject row actions (explicit, not Publish).
	 *
	 * @param array<string, string> $actions Actions.
	 * @param \WP_Post              $post    Post.
	 * @return array<string, string>
	 */
	public static function row_actions( array $actions, $post ): array {
		if ( ! $post instanceof \WP_Post || Cpt::POST_TYPE !== $post->post_type || ! self::can_moderate( (int) $post->ID ) ) {
			return $actions;
		}

		$moderation = Cpt::get_moderation( (int) $post->ID );

		if ( Cpt::MODERATION_APPROVED !== $moderation ) {
			$actions['dsm_approve'] = et_core_intentionally_unescaped(
				sprintf(
					'<a href="%1$s">%2$s</a>',
					esc_url( self::moderate_url( (int) $post->ID, 'approve' ) ),
					esc_html__( 'Approve', 'dsm-supreme-modules-pro-for-divi' )
				),
				'html'
			);
		}

		if ( Cpt::MODERATION_REJECTED !== $moderation ) {
			$actions['dsm_reject'] = et_core_intentionally_unescaped(
				sprintf(
					'<a href="%1$s">%2$s</a>',
					esc_url( self::moderate_url( (int) $post->ID, 'reject' ) ),
					esc_html__( 'Reject', 'dsm-supreme-modules-pro-for-divi' )
				),
				'html'
			);
		}

		return $actions;
	}

	/**
	 * WordPress core datepicker on the testimonial edit screen.
	 *
	 * Uses the bundled `jquery-ui-datepicker` handle. Core then localizes it to
	 * Settings → General via {@see wp_localize_jquery_ui_datepicker()}.
	 *
	 * @param string $hook_suffix Current admin page hook.
	 * @return void
	 */
	public static function enqueue_metabox_assets( string $hook_suffix ): void {
		if ( ! in_array( $hook_suffix, array( 'post.php', 'post-new.php' ), true ) ) {
			return;
		}

		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen || Cpt::POST_TYPE !== $screen->post_type ) {
			return;
		}

		$css_path = defined( 'DSM_DIR_PATH' ) ? DSM_DIR_PATH . 'divi-5/assets/css/testimonials-admin.css' : '';
		$css_url  = defined( 'DSM_DIR_URL' ) ? DSM_DIR_URL . 'assets/css/testimonials-admin.css' : '';
		if ( '' !== $css_path && '' !== $css_url && is_readable( $css_path ) ) {
			wp_enqueue_style(
				'dsm-testimonials-admin',
				$css_url,
				array(),
				(string) filemtime( $css_path )
			);
		}

		$js_path = defined( 'DSM_DIR_PATH' ) ? DSM_DIR_PATH . 'divi-5/assets/js/testimonials-admin.js' : '';
		$js_url  = defined( 'DSM_DIR_URL' ) ? DSM_DIR_URL . 'assets/js/testimonials-admin.js' : '';
		if ( '' === $js_path || '' === $js_url || ! is_readable( $js_path ) ) {
			return;
		}

		wp_enqueue_script(
			'dsm-testimonials-admin',
			$js_url,
			array( 'jquery', 'jquery-ui-datepicker' ),
			(string) filemtime( $js_path ),
			true
		);

		/**
		 * Filters jQuery UI datepicker options for the Testimonials CPT date field.
		 *
		 * @param array<string, mixed> $options Datepicker options (altFormat stays yy-mm-dd).
		 */
		$datepicker = apply_filters(
			'dsm_testimonials_admin_datepicker',
			array(
				'altFormat'       => 'yy-mm-dd',
				'changeMonth'     => true,
				'changeYear'      => true,
				'constrainInput'  => false,
				'showButtonPanel' => true,
			)
		);
		if ( ! is_array( $datepicker ) ) {
			$datepicker = array();
		}
		$datepicker['altField']  = '#dsm_review_date';
		$datepicker['altFormat'] = 'yy-mm-dd';

		wp_localize_script(
			'dsm-testimonials-admin',
			'dsmTestimonialsAdmin',
			array(
				'datepicker' => $datepicker,
			)
		);
	}

	/**
	 * Metabox fields.
	 *
	 * @return void
	 */
	public static function metaboxes(): void {
		add_meta_box(
			'dsm_testimonial_details',
			__( 'Testimonial details', 'dsm-supreme-modules-pro-for-divi' ),
			array( self::class, 'render_metabox' ),
			Cpt::POST_TYPE,
			'normal',
			'high'
		);
	}

	/**
	 * Details metabox.
	 *
	 * @param \WP_Post $post Post.
	 * @return void
	 */
	public static function render_metabox( \WP_Post $post ): void {
		wp_nonce_field( 'dsm_testimonial_meta', 'dsm_testimonial_meta_nonce' );

		$author  = (string) get_post_meta( $post->ID, Cpt::META_AUTHOR, true );
		$email   = (string) get_post_meta( $post->ID, Cpt::META_EMAIL, true );
		$role    = (string) get_post_meta( $post->ID, Cpt::META_ROLE, true );
		$company = (string) get_post_meta( $post->ID, Cpt::META_COMPANY, true );
		$rating  = Cpt::sanitize_rating( get_post_meta( $post->ID, Cpt::META_RATING, true ) );
		$date    = (string) get_post_meta( $post->ID, Cpt::META_REVIEW_DATE, true );
		$source  = (string) get_post_meta( $post->ID, Cpt::META_SOURCE, true );
		$url     = (string) get_post_meta( $post->ID, Cpt::META_SOURCE_URL, true );
		$video   = (string) get_post_meta( $post->ID, Cpt::META_VIDEO_URL, true );
		$schema  = (string) get_post_meta( $post->ID, Cpt::META_SCHEMA_INCLUDE, true );
		$mod     = Cpt::get_moderation( (int) $post->ID );

		$html  = '<p><label>' . esc_html__( 'Author', 'dsm-supreme-modules-pro-for-divi' ) . '<br /><input type="text" class="widefat" name="dsm_author" value="' . esc_attr( $author ) . '" /></label></p>';
		$html .= '<p><label>' . esc_html__( 'Email (not shown on the frontend)', 'dsm-supreme-modules-pro-for-divi' ) . '<br /><input type="email" class="widefat" name="dsm_email" value="' . esc_attr( $email ) . '" /></label></p>';
		$html .= '<p><label>' . esc_html__( 'Role', 'dsm-supreme-modules-pro-for-divi' ) . '<br /><input type="text" class="widefat" name="dsm_role" value="' . esc_attr( $role ) . '" /></label></p>';
		$html .= '<p><label>' . esc_html__( 'Company', 'dsm-supreme-modules-pro-for-divi' ) . '<br /><input type="text" class="widefat" name="dsm_company" value="' . esc_attr( $company ) . '" /></label></p>';
		$html .= '<p><label>' . esc_html__( 'Rating (0–5, 0 hides stars)', 'dsm-supreme-modules-pro-for-divi' ) . '<br /><input type="number" min="0" max="5" step="0.5" name="dsm_rating" value="' . esc_attr( (string) $rating ) . '" /></label></p>';
		echo et_core_intentionally_unescaped( $html, 'html' );
		self::render_review_date_field( $date );
		$html  = '<p><label>' . esc_html__( 'Source', 'dsm-supreme-modules-pro-for-divi' ) . '<br /><input type="text" class="widefat" name="dsm_source" value="' . esc_attr( $source ) . '" /></label></p>';
		$html .= '<p><label>' . esc_html__( 'Source URL', 'dsm-supreme-modules-pro-for-divi' ) . '<br /><input type="url" class="widefat" name="dsm_source_url" value="' . esc_attr( $url ) . '" /></label></p>';
		$html .= '<p><label>' . esc_html__( 'Video URL', 'dsm-supreme-modules-pro-for-divi' ) . '<br /><input type="url" class="widefat" name="dsm_video_url" value="' . esc_attr( $video ) . '" /></label></p>';
		$html .= '<p><label><input type="checkbox" name="dsm_schema_include" value="on" ' . checked( 'off' !== $schema, true, false ) . ' /> ' . esc_html__( 'Include in schema when enabled on the module', 'dsm-supreme-modules-pro-for-divi' ) . '</label></p>';
		$html .= '<p><strong>' . esc_html__( 'Moderation', 'dsm-supreme-modules-pro-for-divi' ) . ':</strong> ' . esc_html( self::moderation_label( $mod ) ) . '</p>';
		$html .= '<p>' . esc_html__( 'Frontend modules only show testimonials after you click Approve. Publishing in the editor is not enough.', 'dsm-supreme-modules-pro-for-divi' ) . '</p>';
		echo et_core_intentionally_unescaped( $html, 'html' );

		if ( self::can_moderate( (int) $post->ID ) ) {
			$actions = '<p class="dsm-testimonial-moderate-actions">';
			if ( Cpt::MODERATION_APPROVED !== $mod ) {
				$actions .= '<a class="button button-primary" href="' . esc_url( self::moderate_url( (int) $post->ID, 'approve' ) ) . '">' . esc_html__( 'Approve', 'dsm-supreme-modules-pro-for-divi' ) . '</a> ';
			}
			if ( Cpt::MODERATION_REJECTED !== $mod ) {
				$actions .= '<a class="button" href="' . esc_url( self::moderate_url( (int) $post->ID, 'reject' ) ) . '">' . esc_html__( 'Reject', 'dsm-supreme-modules-pro-for-divi' ) . '</a>';
			}
			$actions .= '</p>';
			echo et_core_intentionally_unescaped( $actions, 'html' );
		}
	}

	/**
	 * Save metabox.
	 *
	 * @param int      $post_id Post ID.
	 * @param \WP_Post $post    Post.
	 * @return void
	 */
	public static function save_metabox( int $post_id, $post ): void {
		unset( $post );

		if ( ! isset( $_POST['dsm_testimonial_meta_nonce'] ) ) {
			return;
		}

		$nonce = sanitize_text_field( wp_unslash( (string) $_POST['dsm_testimonial_meta_nonce'] ) );
		if ( ! wp_verify_nonce( $nonce, 'dsm_testimonial_meta' ) ) {
			return;
		}

		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		if ( ! Cpt::current_user_can_manage() ) {
			return;
		}

		$author  = isset( $_POST['dsm_author'] ) ? sanitize_text_field( wp_unslash( (string) $_POST['dsm_author'] ) ) : '';
		$email   = isset( $_POST['dsm_email'] ) ? sanitize_email( wp_unslash( (string) $_POST['dsm_email'] ) ) : '';
		$role    = isset( $_POST['dsm_role'] ) ? sanitize_text_field( wp_unslash( (string) $_POST['dsm_role'] ) ) : '';
		$company = isset( $_POST['dsm_company'] ) ? sanitize_text_field( wp_unslash( (string) $_POST['dsm_company'] ) ) : '';
		$rating  = isset( $_POST['dsm_rating'] ) ? Cpt::sanitize_rating( sanitize_text_field( wp_unslash( (string) $_POST['dsm_rating'] ) ) ) : 0.0;
		$date    = isset( $_POST['dsm_review_date'] ) ? Attrs::sanitize_review_date( sanitize_text_field( wp_unslash( (string) $_POST['dsm_review_date'] ) ) ) : '';
		$source  = isset( $_POST['dsm_source'] ) ? sanitize_key( wp_unslash( (string) $_POST['dsm_source'] ) ) : 'manual';
		$url     = isset( $_POST['dsm_source_url'] ) ? esc_url_raw( wp_unslash( (string) $_POST['dsm_source_url'] ) ) : '';
		$video   = isset( $_POST['dsm_video_url'] ) ? esc_url_raw( wp_unslash( (string) $_POST['dsm_video_url'] ) ) : '';
		$schema  = isset( $_POST['dsm_schema_include'] ) ? 'on' : 'off';

		if ( ! in_array( $source, Cpt::source_slugs(), true ) ) {
			$source = 'manual';
		}

		update_post_meta( $post_id, Cpt::META_AUTHOR, $author );
		update_post_meta( $post_id, Cpt::META_EMAIL, $email );
		update_post_meta( $post_id, Cpt::META_ROLE, $role );
		update_post_meta( $post_id, Cpt::META_COMPANY, $company );
		update_post_meta( $post_id, Cpt::META_RATING, $rating );
		update_post_meta( $post_id, Cpt::META_REVIEW_DATE, $date );
		update_post_meta( $post_id, Cpt::META_SOURCE, $source );
		update_post_meta( $post_id, Cpt::META_SOURCE_URL, $url );
		update_post_meta( $post_id, Cpt::META_VIDEO_URL, $video );
		update_post_meta( $post_id, Cpt::META_SCHEMA_INCLUDE, $schema );

		if ( '' === (string) get_post_meta( $post_id, Cpt::META_MODERATION, true ) ) {
			update_post_meta( $post_id, Cpt::META_MODERATION, Cpt::MODERATION_PENDING );
		}
	}

	/**
	 * Keep post_status pending until an explicit Approve action.
	 *
	 * @param array<string, mixed> $data    Sanitized post data.
	 * @param array<string, mixed> $postarr Raw postarr.
	 * @return array<string, mixed>
	 */
	public static function force_pending_until_approved( array $data, array $postarr ): array {
		if ( ! isset( $data['post_type'] ) || Cpt::POST_TYPE !== $data['post_type'] ) {
			return $data;
		}

		if ( isset( $data['post_status'] ) && in_array( $data['post_status'], array( 'trash', 'auto-draft', 'inherit' ), true ) ) {
			return $data;
		}

		$post_id = isset( $postarr['ID'] ) ? absint( $postarr['ID'] ) : 0;
		if ( $post_id > 0 && Cpt::MODERATION_APPROVED === Cpt::get_moderation( $post_id ) ) {
			return $data;
		}

		if ( $post_id > 0 && Cpt::MODERATION_REJECTED === Cpt::get_moderation( $post_id ) ) {
			$data['post_status'] = 'draft';
			return $data;
		}

		$data['post_status'] = 'pending';
		return $data;
	}

	/**
	 * Approve / reject handler.
	 *
	 * @return void
	 */
	public static function handle_moderate(): void {
		$nonce   = isset( $_GET['_wpnonce'] ) ? sanitize_text_field( wp_unslash( (string) $_GET['_wpnonce'] ) ) : '';
		$post_id = isset( $_GET['post_id'] ) ? absint( $_GET['post_id'] ) : 0;
		$action  = isset( $_GET['dsm_mod'] ) ? sanitize_key( wp_unslash( (string) $_GET['dsm_mod'] ) ) : '';

		if ( $post_id < 1 || ! wp_verify_nonce( $nonce, 'dsm_testimonial_moderate_' . $post_id ) ) {
			wp_die( esc_html__( 'Invalid moderation link.', 'dsm-supreme-modules-pro-for-divi' ) );
		}

		// Approve is the real publish action (`force_pending_until_approved` blocks editor Publish).
		if ( ! self::can_moderate( $post_id ) ) {
			wp_die( esc_html__( 'You are not allowed to moderate this testimonial.', 'dsm-supreme-modules-pro-for-divi' ) );
		}

		if ( 'approve' === $action ) {
			update_post_meta( $post_id, Cpt::META_MODERATION, Cpt::MODERATION_APPROVED );
			wp_update_post(
				array(
					'ID'          => $post_id,
					'post_status' => 'publish',
				)
			);
		} elseif ( 'reject' === $action ) {
			update_post_meta( $post_id, Cpt::META_MODERATION, Cpt::MODERATION_REJECTED );
			wp_update_post(
				array(
					'ID'          => $post_id,
					'post_status' => 'draft',
				)
			);
		}

		$redirect = add_query_arg(
			array(
				'post_type'     => Cpt::POST_TYPE,
				'dsm_moderated' => $action,
			),
			admin_url( 'edit.php' )
		);

		wp_safe_redirect( $redirect );
		exit;
	}

	/**
	 * Notice after moderation.
	 *
	 * @return void
	 */
	public static function pending_notice(): void {
		if ( ! Cpt::current_user_can_manage() ) {
			return;
		}

		if ( ! isset( $_GET['dsm_moderated'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return;
		}

		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen || Cpt::POST_TYPE !== $screen->post_type ) {
			return;
		}

		$action = sanitize_key( wp_unslash( (string) $_GET['dsm_moderated'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( 'approve' === $action ) {
			echo et_core_intentionally_unescaped(
				'<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Testimonial approved and is now visible on the frontend.', 'dsm-supreme-modules-pro-for-divi' ) . '</p></div>',
				'html'
			);
		} elseif ( 'reject' === $action ) {
			echo et_core_intentionally_unescaped(
				'<div class="notice notice-warning is-dismissible"><p>' . esc_html__( 'Testimonial rejected.', 'dsm-supreme-modules-pro-for-divi' ) . '</p></div>',
				'html'
			);
		}
	}

	/**
	 * Post list states.
	 *
	 * @param array<string, string> $states States.
	 * @param \WP_Post              $post   Post.
	 * @return array<string, string>
	 */
	public static function post_states( array $states, $post ): array {
		if ( ! $post instanceof \WP_Post || Cpt::POST_TYPE !== $post->post_type ) {
			return $states;
		}

		$states['dsm_mod'] = self::moderation_label( Cpt::get_moderation( (int) $post->ID ) );
		return $states;
	}

	/**
	 * Moderation label.
	 *
	 * @param string $slug Slug.
	 * @return string
	 */
	public static function moderation_label( string $slug ): string {
		if ( Cpt::MODERATION_APPROVED === $slug ) {
			return __( 'Approved', 'dsm-supreme-modules-pro-for-divi' );
		}
		if ( Cpt::MODERATION_REJECTED === $slug ) {
			return __( 'Rejected', 'dsm-supreme-modules-pro-for-divi' );
		}
		return __( 'Pending', 'dsm-supreme-modules-pro-for-divi' );
	}

	/**
	 * Review date control: WordPress jQuery UI datepicker + hidden `Y-m-d`.
	 *
	 * @param string $date Stored review date.
	 * @return void
	 */
	private static function render_review_date_field( string $date ): void {
		$stored  = Attrs::review_date_input_value( $date );
		$display = Attrs::format_review_date( $date );
		$example = Attrs::format_review_date( '2026-09-09' );

		$html  = '<p class="dsm-testimonial-review-date">';
		$html .= '<label for="dsm_review_date_display">' . esc_html__( 'Review date', 'dsm-supreme-modules-pro-for-divi' ) . '</label><br />';
		$html .= '<input type="text" class="regular-text" id="dsm_review_date_display" value="' . esc_attr( $display ) . '" placeholder="' . esc_attr( $example ) . '" autocomplete="off" />';
		$html .= '<input type="hidden" name="dsm_review_date" id="dsm_review_date" value="' . esc_attr( $stored ) . '" />';
		$html .= '<br /><span class="description">' . esc_html__( 'Uses the date format from Settings → General.', 'dsm-supreme-modules-pro-for-divi' ) . '</span>';
		$html .= '</p>';
		echo et_core_intentionally_unescaped( $html, 'html' );
	}

	/**
	 * Whether the current user can Approve/Reject a testimonial.
	 *
	 * Requires `manage_options` so Editor / Author roles cannot moderate.
	 *
	 * @param int $post_id Post ID.
	 * @return bool
	 */
	public static function can_moderate( int $post_id ): bool {
		$allowed = Cpt::current_user_can_manage();

		/**
		 * Filters whether the current user can Approve/Reject a testimonial.
		 *
		 * @param bool $allowed Whether moderation is allowed.
		 * @param int  $post_id Post ID.
		 */
		$filtered = apply_filters( 'dsm_testimonials_can_moderate', $allowed, $post_id );

		return true === $filtered;
	}

	/**
	 * Signed moderation URL.
	 *
	 * @param int    $post_id Post ID.
	 * @param string $action  approve|reject.
	 * @return string
	 */
	private static function moderate_url( int $post_id, string $action ): string {
		return wp_nonce_url(
			add_query_arg(
				array(
					'action'  => 'dsm_testimonial_moderate',
					'post_id' => $post_id,
					'dsm_mod' => $action,
				),
				admin_url( 'admin-post.php' )
			),
			'dsm_testimonial_moderate_' . $post_id
		);
	}
}
