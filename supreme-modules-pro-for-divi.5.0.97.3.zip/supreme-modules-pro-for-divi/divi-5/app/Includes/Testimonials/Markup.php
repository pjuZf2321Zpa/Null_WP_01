<?php
/**
 * Frontend / Visual Builder HTML for testimonial cards, stars, video, form, and header.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Includes\Testimonials;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Shared markup. Star classes match Supreme Star Rating (`dsm-star-full` / `dsm-star-empty`).
 */
final class Markup {

	/**
	 * Default person-silhouette avatar (matches JS `TESTIMONIAL_AVATAR_PLACEHOLDER_SRC`).
	 */
	public const AVATAR_PLACEHOLDER_SRC = 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMjgiIGhlaWdodD0iMTI4IiB2aWV3Qm94PSIwIDAgMTI4IDEyOCI+PHJlY3Qgd2lkdGg9IjEyOCIgaGVpZ2h0PSIxMjgiIGZpbGw9IiNFOEU4RTgiLz48Y2lyY2xlIGN4PSI2NCIgY3k9IjUwIiByPSIyNCIgZmlsbD0iI0M0QzRDNCIvPjxwYXRoIGQ9Ik0yMCAxMjhjNC0yOCAyMi00NiA0NC00NnM0MCAxOCA0NCA0NiIgZmlsbD0iI0M0QzRDNCIvPjwvc3ZnPg==';

	/**
	 * Avatar URL or the default silhouette when empty.
	 *
	 * @param string $avatar_url Stored or query avatar URL.
	 * @return string
	 */
	public static function avatar_src( string $avatar_url ): string {
		return '' !== $avatar_url ? $avatar_url : self::AVATAR_PLACEHOLDER_SRC;
	}

	/**
	 * Escape an <img src> (data URIs are not valid `esc_url` protocols).
	 *
	 * @param string $src Raw src.
	 * @return string
	 */
	public static function esc_img_src( string $src ): string {
		if ( '' === $src ) {
			return '';
		}

		return \DiviSupreme\Includes\UploadImageMarkup::escape_image_src_attribute( $src );
	}

	/**
	 * Star row matching `StarRating::get_starrating` class names (do not mutate that module).
	 *
	 * @param float $rating Rating 0–5. Empty / 0 hides the row (quote-only).
	 * @param int   $scale  Scale (always 5 for Testimonials v1).
	 * @return string
	 */
	public static function stars( float $rating, int $scale = 5 ): string {
		if ( $rating <= 0 ) {
			return '';
		}

		$scale      = max( 1, $scale );
		$int_rating = (int) floor( $rating );
		$output     = '';

		for ( $star_index = 1; $star_index <= $scale; $star_index++ ) {
			if ( $star_index <= $int_rating ) {
				$output .= '<i class="dsm-star-full"></i>';
			} elseif ( $int_rating + 1 === $star_index && (float) $int_rating !== $rating ) {
				$partial = (int) round( ( $rating - $int_rating ) * 10 );
				$output .= '<i class="dsm-star-' . $partial . '"></i>';
			} else {
				$output .= '<i class="dsm-star-empty"></i>';
			}
		}

		$label = sprintf(
			/* translators: 1: rating value, 2: scale */
			__( '%1$s out of %2$s stars', 'dsm-supreme-modules-pro-for-divi' ),
			esc_html( (string) $rating ),
			esc_html( (string) $scale )
		);

		return sprintf(
			'<div class="dsm-star-rating" role="img" aria-label="%1$s">%2$s</div>',
			esc_attr( $label ),
			et_core_esc_previously( $output )
		);
	}

	/**
	 * Extract a YouTube id from watch, embed, shorts, live, nocookie, or youtu.be URLs.
	 *
	 * @param string $url Video URL.
	 * @return string
	 */
	public static function youtube_id_from_url( string $url ): string {
		$url = trim( $url );
		if ( '' === $url ) {
			return '';
		}

		if ( 0 === strpos( $url, '//' ) ) {
			$url = 'https:' . $url;
		} elseif ( ! preg_match( '#^https?://#i', $url ) ) {
			$url = 'https://' . ltrim( $url, '/' );
		}

		$parts = wp_parse_url( $url );
		$host  = isset( $parts['host'] ) ? strtolower( (string) $parts['host'] ) : '';
		$path  = isset( $parts['path'] ) ? (string) $parts['path'] : '';
		$query = array();
		if ( ! empty( $parts['query'] ) ) {
			wp_parse_str( (string) $parts['query'], $query );
		}

		if ( isset( $query['v'] ) && is_string( $query['v'] ) && self::is_youtube_id( $query['v'] ) ) {
			return $query['v'];
		}

		if ( false !== strpos( $host, 'youtu.be' ) ) {
			$id = explode( '/', ltrim( $path, '/' ) )[0];
			return self::is_youtube_id( $id ) ? $id : '';
		}

		if ( false !== strpos( $host, 'youtube' ) && preg_match( '~/(?:embed|shorts|live|v)/([A-Za-z0-9_-]{6,})~', $path, $matches ) ) {
			return $matches[1];
		}

		return '';
	}

	/**
	 * Extract a Vimeo id from player, channel, or numeric URLs.
	 *
	 * @param string $url Video URL.
	 * @return string
	 */
	public static function vimeo_id_from_url( string $url ): string {
		$url = trim( $url );
		if ( '' === $url ) {
			return '';
		}

		if ( preg_match( '~vimeo\.com/(?:video/|channels/[^/]+/|groups/[^/]+/videos/)?([0-9]+)~', $url, $matches ) ) {
			return $matches[1];
		}

		return '';
	}

	/**
	 * Parse a video URL into a YouTube / Vimeo / HTML5 facade payload.
	 *
	 * `source` is the Magnific-friendly page URL (watch / vimeo). `embed` is the
	 * iframe src used only when Magnific is unavailable.
	 *
	 * @param string $url Video URL.
	 * @return array{provider:string,embed:string,poster:string,source:string}
	 */
	public static function parse_video( string $url ): array {
		$url = trim( $url );
		$out = array(
			'provider' => '',
			'embed'    => '',
			'poster'   => '',
			'source'   => '',
		);

		if ( '' === $url ) {
			return apply_filters( 'dsm_testimonials_parse_video', $out, $url );
		}

		$youtube_id = self::youtube_id_from_url( $url );
		if ( '' !== $youtube_id ) {
			$out['provider'] = 'youtube';
			$out['source']   = 'https://www.youtube.com/watch?v=' . rawurlencode( $youtube_id );
			$out['embed']    = 'https://www.youtube.com/embed/' . rawurlencode( $youtube_id ) . '?autoplay=1&rel=0';
			$out['poster']   = 'https://i.ytimg.com/vi/' . rawurlencode( $youtube_id ) . '/hqdefault.jpg';

			return apply_filters( 'dsm_testimonials_parse_video', $out, $url );
		}

		$vimeo_id = self::vimeo_id_from_url( $url );
		if ( '' !== $vimeo_id ) {
			$out['provider'] = 'vimeo';
			$out['source']   = 'https://vimeo.com/' . rawurlencode( $vimeo_id );
			$out['embed']    = 'https://player.vimeo.com/video/' . rawurlencode( $vimeo_id ) . '?autoplay=1';

			return apply_filters( 'dsm_testimonials_parse_video', $out, $url );
		}

		$safe            = esc_url_raw( $url );
		$out['provider'] = 'html5';
		$out['source']   = $safe;
		$out['embed']    = $safe;

		return apply_filters( 'dsm_testimonials_parse_video', $out, $url );
	}

	/**
	 * Whether a string looks like a YouTube video id.
	 *
	 * @param string $id Candidate id.
	 * @return bool
	 */
	private static function is_youtube_id( string $id ): bool {
		return 1 === preg_match( '/^[A-Za-z0-9_-]{6,}$/', $id );
	}

	/**
	 * Click-to-load video facade (lightbox via Magnific on the frontend).
	 *
	 * @param string $video_url    Video URL.
	 * @param string $poster_url   Optional poster.
	 * @param string $author_label Accessible name.
	 * @return string
	 */
	public static function video_facade( string $video_url, string $poster_url, string $author_label ): string {
		$parsed = self::parse_video( $video_url );
		if ( '' === $parsed['embed'] ) {
			return '';
		}

		$poster = '' !== $poster_url ? $poster_url : $parsed['poster'];
		$play   = sprintf(
			/* translators: %s: reviewer name */
			__( 'Play video testimonial from %s', 'dsm-supreme-modules-pro-for-divi' ),
			$author_label
		);

		$poster_html = '';
		if ( '' !== $poster ) {
			$poster_html = sprintf(
				'<img class="dsm-testimonials-video-poster" src="%1$s" alt="" decoding="async" />',
				esc_url( $poster )
			);
		}

		$source = '' !== $parsed['source'] ? $parsed['source'] : $video_url;

		return sprintf(
			'<button type="button" class="dsm-testimonials-video-facade" data-dsm-video-provider="%1$s" data-dsm-video-embed="%2$s" aria-label="%3$s">%4$s<span class="dsm-testimonials-play" aria-hidden="true"></span></button>',
			esc_attr( $parsed['provider'] ),
			esc_url( $source ),
			esc_attr( $play ),
			et_core_esc_previously( $poster_html )
		);
	}

	/**
	 * One testimonial card.
	 *
	 * @param array<string, mixed> $item        Item model.
	 * @param string               $extra_html  Optional nestable inner-module HTML (already escaped).
	 * @param bool                 $show_source Whether to render `.dsm-testimonials-source`.
	 * @return string
	 */
	public static function card( array $item, string $extra_html = '', bool $show_source = false ): string {
		$author  = isset( $item['author'] ) ? (string) $item['author'] : '';
		$role    = isset( $item['role'] ) ? (string) $item['role'] : '';
		$company = isset( $item['company'] ) ? (string) $item['company'] : '';
		$quote   = isset( $item['quote'] ) ? (string) $item['quote'] : '';
		$rating  = isset( $item['rating'] ) ? Cpt::sanitize_rating( $item['rating'] ) : 0.0;
		$source  = isset( $item['source'] ) ? sanitize_key( (string) $item['source'] ) : 'manual';
		$date    = isset( $item['date'] ) ? (string) $item['date'] : '';
		if ( '' === $date && isset( $item['date_iso'] ) ) {
			$date = (string) $item['date_iso'];
		}
		$tags     = isset( $item['tags'] ) && is_array( $item['tags'] ) ? $item['tags'] : array();
		$avatar   = isset( $item['avatar_url'] ) ? (string) $item['avatar_url'] : '';
		$video    = isset( $item['video_url'] ) ? (string) $item['video_url'] : '';
		$poster   = isset( $item['video_poster'] ) ? (string) $item['video_poster'] : '';
		$product  = isset( $item['product_image'] ) ? (string) $item['product_image'] : '';
		$source_u = isset( $item['source_url'] ) ? (string) $item['source_url'] : '';
		$id       = isset( $item['id'] ) ? (string) $item['id'] : '';

		$tag_slugs = array();
		foreach ( $tags as $tag ) {
			$slug = sanitize_title( (string) $tag );
			if ( '' !== $slug ) {
				$tag_slugs[] = $slug;
			}
		}

		$avatar_html = sprintf(
			'<div class="dsm-testimonials-avatar"><img src="%1$s" alt="%2$s" width="64" height="64" decoding="async" /></div>',
			self::esc_img_src( self::avatar_src( $avatar ) ),
			esc_attr( $author )
		);

		$product_html = '';
		if ( '' !== $product ) {
			$product_html = sprintf(
				'<div class="dsm-testimonials-product"><img src="%1$s" alt="" decoding="async" /></div>',
				esc_url( $product )
			);
		}

		$role_html    = '' !== $role
			? '<p class="dsm-testimonials-meta">' . esc_html( $role ) . '</p>'
			: '';
		$company_html = '' !== $company
			? '<p class="dsm-testimonials-company">' . esc_html( $company ) . '</p>'
			: '';
		$meta_html    = $role_html . $company_html;

		$date_html  = '';
		$date_label = Attrs::format_review_date( $date );
		$date_iso   = Attrs::review_date_iso( $date );
		if ( '' !== $date_label && '' !== $date_iso ) {
			$date_html = sprintf(
				'<time class="dsm-testimonials-date" datetime="%1$s">%2$s</time>',
				esc_attr( $date_iso ),
				esc_html( $date_label )
			);
		}

		$source_html = '';
		if ( $show_source && '' !== $source ) {
			$label = self::source_label( $source );
			if ( '' !== $source_u ) {
				$source_html = sprintf(
					'<a class="dsm-testimonials-source" href="%1$s">%2$s</a>',
					esc_url( $source_u ),
					esc_html( $label )
				);
			} else {
				$source_html = sprintf(
					'<span class="dsm-testimonials-source">%1$s</span>',
					esc_html( $label )
				);
			}
		}

		$classes = array( 'dsm-testimonials-card' );

		$allowed = wp_kses_allowed_html( 'post' );

		$stars_html   = self::stars( $rating );
		$date_quote   = '<div class="dsm-testimonials-date-slot dsm-testimonials-date-slot--quote">' . $date_html . '</div>';
		$date_auth    = '<div class="dsm-testimonials-date-slot dsm-testimonials-date-slot--author">' . $date_html . '</div>';
		$date_foot    = '<div class="dsm-testimonials-date-slot dsm-testimonials-date-slot--footer">' . $date_html . '</div>';
		$source_quote = '<div class="dsm-testimonials-source-slot dsm-testimonials-source-slot--quote">' . $source_html . '</div>';
		$source_auth  = '<div class="dsm-testimonials-source-slot dsm-testimonials-source-slot--author">' . $source_html . '</div>';
		$source_foot  = '<div class="dsm-testimonials-source-slot dsm-testimonials-source-slot--footer">' . $source_html . '</div>';
		$main_html    = sprintf(
			'<div class="dsm-testimonials-card-main"><div class="dsm-testimonials-quote-region"><div class="dsm-testimonials-quote-wrap"><blockquote class="dsm-testimonials-quote">%1$s</blockquote></div><div class="dsm-testimonials-stars-slot dsm-testimonials-stars-slot--quote">%2$s</div>%6$s%8$s</div><div class="dsm-testimonials-author-stack"><div class="dsm-testimonials-stars-slot dsm-testimonials-stars-slot--author">%2$s</div><div class="dsm-testimonials-author-row">%3$s<div class="dsm-testimonials-author-text"><p class="dsm-testimonials-author">%4$s</p>%5$s</div></div>%7$s%9$s</div></div>',
			wp_kses( $quote, $allowed ),
			et_core_esc_previously( $stars_html ),
			et_core_esc_previously( $avatar_html ),
			esc_html( $author ),
			et_core_esc_previously( $meta_html ),
			et_core_esc_previously( $date_quote ),
			et_core_esc_previously( $date_auth ),
			et_core_esc_previously( $source_quote ),
			et_core_esc_previously( $source_auth )
		);

		return sprintf(
			'<article class="%1$s" data-rating="%2$s" data-source="%3$s" data-tags="%4$s" data-item-id="%5$s">%6$s%7$s%8$s<div class="dsm-testimonials-footer">%9$s%10$s</div>%11$s</article>',
			esc_attr( implode( ' ', $classes ) ),
			esc_attr( (string) $rating ),
			esc_attr( $source ),
			esc_attr( implode( ',', $tag_slugs ) ),
			esc_attr( $id ),
			et_core_esc_previously( $product_html ),
			et_core_esc_previously( self::video_facade( $video, $poster, $author ) ),
			et_core_esc_previously( $main_html ),
			et_core_esc_previously( $date_foot ),
			et_core_esc_previously( $source_foot ),
			et_core_esc_previously( $extra_html )
		);
	}

	/**
	 * Human source label.
	 *
	 * @param string $source Source slug.
	 * @return string
	 */
	public static function source_label( string $source ): string {
		$map = array(
			'manual'      => __( 'Manual', 'dsm-supreme-modules-pro-for-divi' ),
			'form'        => __( 'Form', 'dsm-supreme-modules-pro-for-divi' ),
			'woocommerce' => __( 'WooCommerce', 'dsm-supreme-modules-pro-for-divi' ),
			'comments'    => __( 'Comments', 'dsm-supreme-modules-pro-for-divi' ),
		);

		/**
		 * Filters source labels shown on cards and filters.
		 *
		 * @param array<string, string> $map Source slug => label.
		 */
		$map = apply_filters( 'dsm_testimonials_source_labels', $map );

		if ( is_array( $map ) && isset( $map[ $source ] ) && is_string( $map[ $source ] ) ) {
			return $map[ $source ];
		}

		return $source;
	}

	/**
	 * Aggregate header: average, count, optional histogram.
	 *
	 * @param list<array<string, mixed>> $items     Items.
	 * @param bool                       $histogram Whether to show a 5–1 bar chart.
	 * @return string
	 */
	public static function aggregate( array $items, bool $histogram ): string {
		$rated = array();
		foreach ( $items as $item ) {
			$rating = isset( $item['rating'] ) ? Cpt::sanitize_rating( $item['rating'] ) : 0.0;
			if ( $rating > 0 ) {
				$rated[] = $rating;
			}
		}

		$count = count( $rated );
		if ( 0 === $count ) {
			return '';
		}

		$avg = array_sum( $rated ) / $count;
		$avg = round( $avg, 1 );

		$summary = sprintf(
			'<div class="dsm-testimonials-aggregate-summary"><div class="dsm-testimonials-aggregate-stars">%1$s</div><p class="dsm-testimonials-aggregate-score">%2$s</p><p class="dsm-testimonials-aggregate-count">%3$s</p></div>',
			et_core_esc_previously( self::stars( $avg ) ),
			esc_html( (string) $avg ),
			esc_html(
				sprintf(
					/* translators: %d: number of reviews */
					_n( '%d review', '%d reviews', $count, 'dsm-supreme-modules-pro-for-divi' ),
					$count
				)
			)
		);

		$bars = '';
		if ( $histogram ) {
			$buckets = array(
				5 => 0,
				4 => 0,
				3 => 0,
				2 => 0,
				1 => 0,
			);
			foreach ( $rated as $rating ) {
				$bucket = (int) round( $rating );
				if ( $bucket < 1 ) {
					$bucket = 1;
				}
				if ( $bucket > 5 ) {
					$bucket = 5;
				}
				++$buckets[ $bucket ];
			}

			$rows = '';
			foreach ( $buckets as $star => $star_count ) {
				$pct   = $count > 0 ? (int) round( ( $star_count / $count ) * 100 ) : 0;
				$rows .= sprintf(
					'<div class="dsm-testimonials-histogram-row" data-star="%1$d"><span class="dsm-testimonials-histogram-label">%1$d</span><span class="dsm-testimonials-histogram-track"><span class="dsm-testimonials-histogram-fill" style="width:%2$d%%"></span></span><span class="dsm-testimonials-histogram-count">%3$d</span></div>',
					$star,
					$pct,
					$star_count
				);
			}
			$bars = '<div class="dsm-testimonials-histogram" aria-hidden="true">' . $rows . '</div>';
		}

		return et_core_intentionally_unescaped( '<div class="dsm-testimonials-aggregate">' . $summary . $bars . '</div>', 'html' );
	}

	/**
	 * One styled filter select (Contact Form 7 chevron wrap).
	 *
	 * @param string $field_id Field id.
	 * @param string $label    Screen-reader label.
	 * @param string $filter   data-filter slug.
	 * @param string $options  Option HTML.
	 * @return string
	 */
	private static function filter_select( string $field_id, string $label, string $filter, string $options ): string {
		return sprintf(
			'<div class="dsm-testimonials-filter-wrap"><label class="screen-reader-text" for="%1$s">%2$s</label><select class="dsm-testimonials-filter" data-filter="%3$s" id="%1$s">%4$s</select></div>',
			esc_attr( $field_id ),
			esc_html( $label ),
			esc_attr( $filter ),
			et_core_esc_previously( $options )
		);
	}

	/**
	 * Client-side filter toolbar (rating / source / tag).
	 *
	 * @param list<array<string, mixed>> $items          Items used to build options.
	 * @param string                     $content_source Parent `dsm_source` slug.
	 * @return string
	 */
	public static function filters( array $items, string $content_source = '' ): string {
		$sources = array();
		$tags    = array();

		foreach ( $items as $item ) {
			$source = isset( $item['source'] ) ? sanitize_key( (string) $item['source'] ) : '';
			if ( '' !== $source ) {
				$sources[ $source ] = self::source_label( $source );
			}
			if ( isset( $item['tags'] ) && is_array( $item['tags'] ) ) {
				foreach ( $item['tags'] as $tag ) {
					$slug = sanitize_title( (string) $tag );
					if ( '' !== $slug ) {
						$tags[ $slug ] = $slug;
					}
				}
			}
		}

		$rating_opts = '<option value="">' . esc_html__( 'All ratings', 'dsm-supreme-modules-pro-for-divi' ) . '</option>';
		for ( $star = 5; $star >= 1; $star-- ) {
			$rating_opts .= sprintf(
				'<option value="%1$d">%2$s</option>',
				$star,
				esc_html(
					sprintf(
						/* translators: %d: minimum star rating */
						__( '%d stars & up', 'dsm-supreme-modules-pro-for-divi' ),
						$star
					)
				)
			);
		}

		$tag_opts = '<option value="">' . esc_html__( 'All tags', 'dsm-supreme-modules-pro-for-divi' ) . '</option>';
		foreach ( $tags as $slug => $label ) {
			$tag_opts .= sprintf(
				'<option value="%1$s">%2$s</option>',
				esc_attr( $slug ),
				esc_html( $label )
			);
		}

		$rating_id = function_exists( 'wp_unique_id' ) ? wp_unique_id( 'dsm-testimonials-filter-rating-' ) : 'dsm-testimonials-filter-rating';
		$source_id = function_exists( 'wp_unique_id' ) ? wp_unique_id( 'dsm-testimonials-filter-source-' ) : 'dsm-testimonials-filter-source';
		$tag_id    = function_exists( 'wp_unique_id' ) ? wp_unique_id( 'dsm-testimonials-filter-tag-' ) : 'dsm-testimonials-filter-tag';

		$hide_source = in_array( $content_source, array( 'comments', 'woocommerce' ), true );
		$hide_rating = 'comments' === $content_source;
		$source_html = '';
		if ( ! $hide_source ) {
			$source_opts = '<option value="">' . esc_html__( 'All sources', 'dsm-supreme-modules-pro-for-divi' ) . '</option>';
			foreach ( $sources as $slug => $label ) {
				$source_opts .= sprintf(
					'<option value="%1$s">%2$s</option>',
					esc_attr( $slug ),
					esc_html( $label )
				);
			}
			$source_html = self::filter_select(
				$source_id,
				__( 'Filter by source', 'dsm-supreme-modules-pro-for-divi' ),
				'source',
				$source_opts
			);
		}

		$tag_html = '';
		if ( count( $tags ) > 0 ) {
			$tag_html = self::filter_select(
				$tag_id,
				__( 'Filter by tag', 'dsm-supreme-modules-pro-for-divi' ),
				'tag',
				$tag_opts
			);
		}

		$rating_html = '';
		if ( ! $hide_rating ) {
			$rating_html = self::filter_select(
				$rating_id,
				__( 'Filter by rating', 'dsm-supreme-modules-pro-for-divi' ),
				'rating',
				$rating_opts
			);
		}

		if ( '' === $rating_html && '' === $source_html && '' === $tag_html ) {
			return '';
		}

		return sprintf(
			'<div class="dsm-testimonials-filters" role="search">%1$s%2$s%3$s</div>',
			et_core_esc_previously( $rating_html ),
			et_core_esc_previously( $source_html ),
			et_core_esc_previously( $tag_html )
		);
	}

	/**
	 * Public collect form (pending CPT on submit).
	 *
	 * @param array<string, mixed> $attrs Parent module attrs.
	 * @return string
	 */
	public static function collect_form( array $attrs ): string {
		$consent     = Attrs::inner_string(
			$attrs,
			'dsm_collect_consent',
			__( 'I agree to have my review published on this site.', 'dsm-supreme-modules-pro-for-divi' )
		);
		$success_raw = Attrs::inner_raw( $attrs, 'dsm_collect_success' );
		if ( null === $success_raw ) {
			$success = __( 'Thank you. Your review was submitted and is waiting for approval.', 'dsm-supreme-modules-pro-for-divi' );
		} else {
			$success = Attrs::inner_string( $attrs, 'dsm_collect_success', '' );
		}
		$success = apply_filters( 'dsm_testimonials_collect_success', $success, $attrs );
		if ( ! is_string( $success ) ) {
			$success = '';
		} else {
			$success = trim( $success );
		}
		$labels = apply_filters(
			'dsm_testimonials_collect_labels',
			array(
				'name'   => Attrs::inner_string(
					$attrs,
					'dsm_collect_label_name',
					__( 'Your name', 'dsm-supreme-modules-pro-for-divi' )
				),
				'email'  => Attrs::inner_string(
					$attrs,
					'dsm_collect_label_email',
					__( 'Email', 'dsm-supreme-modules-pro-for-divi' )
				),
				'rating' => Attrs::inner_string(
					$attrs,
					'dsm_collect_label_rating',
					__( 'Rating', 'dsm-supreme-modules-pro-for-divi' )
				),
				'review' => Attrs::inner_string(
					$attrs,
					'dsm_collect_label_review',
					__( 'Your review', 'dsm-supreme-modules-pro-for-divi' )
				),
			),
			$attrs
		);
		if ( ! is_array( $labels ) ) {
			$labels = array();
		}
		$nonce = wp_create_nonce( 'dsm_testimonials_collect' );
		$rest  = rest_url( 'dsm/v1/testimonials/collect' );

		$stars = '';
		for ( $star = 1; $star <= 5; $star++ ) {
			$stars .= sprintf(
				'<button type="button" class="dsm-testimonials-star-input" data-value="%1$d" aria-label="%2$s"><i class="dsm-star-empty"></i></button>',
				$star,
				esc_attr(
					sprintf(
						/* translators: %d: star value */
						__( '%d stars', 'dsm-supreme-modules-pro-for-divi' ),
						$star
					)
				)
			);
		}

		return sprintf(
			'<form class="dsm-testimonials-collect" method="post" action="#" novalidate data-success="%1$s" data-rest-url="%2$s">
				<input type="hidden" name="dsm_testimonials_nonce" value="%3$s" />
				<input type="hidden" name="dsm_rating" value="5" />
				<p class="dsm-testimonials-hp" aria-hidden="true"><label>%4$s<input class="input" type="text" name="dsm_hp" tabindex="-1" autocomplete="off" /></label></p>
				<p class="et_pb_contact_field"><label class="et_pb_contact_field_label">%5$s</label><input class="input" type="text" name="dsm_author" required maxlength="120" /></p>
				<p class="et_pb_contact_field"><label class="et_pb_contact_field_label">%6$s</label><input class="input" type="email" name="dsm_email" required maxlength="200" /></p>
				<p class="et_pb_contact_field"><label class="et_pb_contact_field_label">%7$s</label><input class="input" type="text" name="dsm_company" maxlength="120" /></p>
				<p class="et_pb_contact_field dsm-testimonials-collect-rating"><span class="et_pb_contact_field_label">%8$s</span><span class="dsm-star-rating dsm-testimonials-star-picker">%9$s</span></p>
				<p class="et_pb_contact_field"><label class="et_pb_contact_field_label">%10$s</label><textarea class="et_pb_contact_message input" name="dsm_quote" required rows="4" maxlength="4000"></textarea></p>
				<p class="et_pb_contact_field"><label><input type="checkbox" name="dsm_consent" value="1" required /> %11$s</label></p>
				<p class="et_pb_contact_field"><button type="submit" class="et_pb_contact_submit et_pb_button et_pb_bg_layout_light dsm-testimonials-collect-submit">%12$s</button></p>
				<div class="dsm-testimonials-collect-status" role="status" aria-live="polite"></div>
			</form>',
			esc_attr( $success ),
			esc_url( $rest ),
			esc_attr( $nonce ),
			esc_html__( 'Leave this field empty', 'dsm-supreme-modules-pro-for-divi' ),
			esc_html( is_string( $labels['name'] ?? null ) ? $labels['name'] : __( 'Your name', 'dsm-supreme-modules-pro-for-divi' ) ),
			esc_html( is_string( $labels['email'] ?? null ) ? $labels['email'] : __( 'Email', 'dsm-supreme-modules-pro-for-divi' ) ),
			esc_html__( 'Company (optional)', 'dsm-supreme-modules-pro-for-divi' ),
			esc_html( is_string( $labels['rating'] ?? null ) ? $labels['rating'] : __( 'Rating', 'dsm-supreme-modules-pro-for-divi' ) ),
			et_core_esc_previously( $stars ),
			esc_html( is_string( $labels['review'] ?? null ) ? $labels['review'] : __( 'Your review', 'dsm-supreme-modules-pro-for-divi' ) ),
			esc_html( $consent ),
			esc_html__( 'Submit review', 'dsm-supreme-modules-pro-for-divi' )
		);
	}

	/**
	 * Wrap rendered cards for a layout mode.
	 *
	 * @param string               $items_html Inner cards HTML.
	 * @param string               $layout     Layout slug.
	 * @param array<string, mixed> $attrs      Parent attrs (carousel data-params).
	 * @return string
	 */
	public static function layout_wrap( string $items_html, string $layout, array $attrs ): string {
		$layout = sanitize_key( $layout );

		if ( 'carousel' === $layout ) {
			$params = wp_json_encode( self::carousel_params( $attrs ) );
			$arrows = '';
			$dots   = '';

			if ( Attrs::inner_on( $attrs, 'arrows', 'on' ) ) {
				$arrows = '<div class="swiper-button-prev swiper-arrow-button dsm-testimonials-arrow"></div><div class="swiper-button-next swiper-arrow-button dsm-testimonials-arrow"></div>';
			}

			if ( Attrs::inner_on( $attrs, 'dots', 'on' ) ) {
				$dots = '<div class="swiper-pagination dsm-testimonials-pagination"></div>';
			}

			return sprintf(
				'<div class="dsm-testimonials-carousel-shell"><div class="swiper-container dsm-testimonials-carousel" data-params="%1$s"><div class="swiper-wrapper">%2$s</div></div>%3$s%4$s</div>',
				esc_attr( is_string( $params ) ? $params : '{}' ),
				et_core_intentionally_unescaped( $items_html, 'html' ),
				et_core_intentionally_unescaped( $arrows, 'html' ),
				et_core_intentionally_unescaped( $dots, 'html' )
			);
		}

		if ( 'marquee' === $layout ) {
			$speed   = Attrs::inner_string( $attrs, 'dsm_marquee_speed', '40s' );
			$action  = Attrs::hover_action( $attrs );
			$dir     = Attrs::inner_string( $attrs, 'dsm_marquee_direction', 'left' );
			$dir     = 'right' === $dir ? 'right' : 'left';
			$off     = Attrs::inner_on( $attrs, 'dsm_pause_offscreen', 'on' ) ? 'on' : 'off';
			$pause   = 'pause' === $action ? 'on' : 'off';
			$classes = array(
				'dsm-testimonials-marquee',
				'dsm-testimonials-marquee--dir-' . $dir,
			);
			if ( 'none' !== $action ) {
				$classes[] = 'dsm-testimonials-marquee--hover-' . str_replace( '_', '-', $action );
			}
			if ( Attrs::inner_on( $attrs, 'dsm_edge_fade', 'on' ) ) {
				$classes[] = 'dsm-testimonials-marquee--fade';
			}
			if ( Attrs::dsm_equal_height_on( $attrs ) ) {
				$classes[] = 'dsm-testimonials-marquee--stretch';
			}

			return sprintf(
				'<div class="%1$s" data-speed="%2$s" data-pause-hover="%3$s" data-pause-offscreen="%4$s"><div class="dsm-testimonials-marquee-track">%5$s</div></div>',
				esc_attr( implode( ' ', $classes ) ),
				esc_attr( $speed ),
				esc_attr( $pause ),
				esc_attr( $off ),
				et_core_intentionally_unescaped( $items_html, 'html' )
			);
		}

		$classes = array(
			'dsm-testimonials-items',
			'dsm-testimonials-items--' . $layout,
		);
		if ( Attrs::dsm_equal_height_on( $attrs ) ) {
			$classes[] = 'dsm-testimonials-items--equal-height';
		}

		return sprintf(
			'<div class="%1$s">%2$s</div>',
			esc_attr( implode( ' ', $classes ) ),
			et_core_intentionally_unescaped( $items_html, 'html' )
		);
	}

	/**
	 * Swiper data-params (subset of Card Carousel).
	 *
	 * @param array<string, mixed> $attrs Parent attrs.
	 * @return array<string, mixed>
	 */
	public static function carousel_params( array $attrs ): array {
		$show  = Attrs::inner_responsive( $attrs, 'slide_to_show', '3' );
		$space = Attrs::inner_responsive( $attrs, 'space_between', '15' );

		$params = array(
			'slide_to_show'        => $show['desktop'],
			'slide_to_show_tablet' => $show['tablet'],
			'slide_to_show_phone'  => $show['phone'],
			'space_between'        => $space['desktop'],
			'space_between_tablet' => $space['tablet'],
			'space_between_phone'  => $space['phone'],
			'autoplay'             => Attrs::inner_on( $attrs, 'autoplay', 'off' ),
			'autoplay_speed'       => Attrs::inner_string( $attrs, 'autoplay_speed', '3000' ),
			'pause_on_hover'       => Attrs::inner_on( $attrs, 'pause_on_hover', 'on' ),
			'loop'                 => Attrs::inner_on( $attrs, 'infinite', 'on' ),
			'arrows'               => Attrs::inner_on( $attrs, 'arrows', 'on' ),
			'dots'                 => Attrs::inner_on( $attrs, 'dots', 'on' ),
			'equal_height'         => Attrs::inner_on( $attrs, 'equal_height', 'on' ),
			'centered_slides'      => Attrs::inner_on( $attrs, 'centered_slides', 'off' ),
			'speed'                => Attrs::inner_string( $attrs, 'speed', '300' ),
		);

		/**
		 * Filters frontend Swiper params for Testimonials carousel layout.
		 *
		 * @param array<string, mixed> $params Encoded data-params.
		 * @param array<string, mixed> $attrs  Parent attrs.
		 */
		$filtered = apply_filters( 'dsm_testimonials_carousel_params', $params, $attrs );

		return is_array( $filtered ) ? $filtered : $params;
	}

	/**
	 * Wrap query-rendered cards as Swiper slides when layout is carousel.
	 *
	 * @param string $card_html Card inner HTML.
	 * @param string $layout    Layout slug.
	 * @return string
	 */
	public static function as_slide( string $card_html, string $layout ): string {
		if ( 'carousel' === $layout ) {
			return et_core_intentionally_unescaped( '<div class="swiper-slide dsm-testimonials-slide">' . $card_html . '</div>', 'html' );
		}
		return et_core_esc_previously( $card_html );
	}
}
