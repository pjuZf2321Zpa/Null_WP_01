<?php
/**
 * Read-only WooCommerce product reviews and WordPress comments adapters.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Includes\Testimonials;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Map approved comments / product reviews into the Testimonials item model.
 *
 * These adapters never write to `dsm_testimonial`. Google / Trustpilot stay in v2.
 */
final class Adapters {

	/**
	 * WooCommerce product reviews (`comment_type` = review).
	 *
	 * @param array<string, mixed> $args number, min_rating, product_id.
	 * @return list<array<string, mixed>>
	 */
	public static function woocommerce_items( array $args ): array {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return array();
		}

		$number     = Query::clamp_number( $args['number'] ?? 10 );
		$min_rating = isset( $args['min_rating'] ) ? Cpt::sanitize_rating( $args['min_rating'] ) : 0.0;
		$product_id = isset( $args['product_id'] ) ? absint( $args['product_id'] ) : 0;
		$sort       = self::comment_sort( $args, true );

		$comment_args = array(
			'type'    => 'review',
			'status'  => 'approve',
			'number'  => $number,
			'orderby' => $sort['orderby'],
			'order'   => $sort['order'],
			'post_id' => $product_id > 0 ? $product_id : 0,
		);
		if ( '' !== $sort['meta_key'] ) {
			$comment_args['meta_key'] = $sort['meta_key']; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
		}

		/**
		 * Filters WooCommerce review comment query args.
		 *
		 * @param array<string, mixed> $comment_args get_comments args.
		 * @param array<string, mixed> $args         Module args.
		 */
		$comment_args = apply_filters( 'dsm_testimonials_woocommerce_query_args', $comment_args, $args );
		if ( ! is_array( $comment_args ) ) {
			return array();
		}

		$comments = get_comments( $comment_args );
		if ( $sort['shuffle'] && is_array( $comments ) ) {
			shuffle( $comments );
		}
		$items = array();

		foreach ( (array) $comments as $comment ) {
			if ( ! $comment instanceof \WP_Comment ) {
				continue;
			}

			if ( 'review' !== $comment->comment_type ) {
				continue;
			}

			$rating = Cpt::sanitize_rating( get_comment_meta( (int) $comment->comment_ID, 'rating', true ) );
			if ( $min_rating > 0 && $rating < $min_rating ) {
				continue;
			}

			$avatar = get_avatar_url( $comment, array( 'size' => 96 ) );

			$items[] = array(
				'id'             => 'woo-' . (int) $comment->comment_ID,
				'author'         => $comment->comment_author,
				'role'           => '',
				'company'        => '',
				'email'          => $comment->comment_author_email,
				'avatar_id'      => 0,
				'avatar_url'     => is_string( $avatar ) ? $avatar : '',
				'rating'         => $rating,
				'date'           => Attrs::sanitize_review_date( (string) $comment->comment_date ),
				'date_iso'       => Attrs::review_date_iso( (string) $comment->comment_date_gmt ),
				'source'         => 'woocommerce',
				'source_url'     => get_comment_link( $comment ),
				'quote'          => $comment->comment_content,
				'video_url'      => '',
				'video_poster'   => '',
				'product_image'  => '',
				'tags'           => array(),
				'schema_include' => true,
			);
		}

		/**
		 * Filters mapped WooCommerce review items.
		 *
		 * @param list<array<string, mixed>> $items Item models.
		 * @param array<string, mixed>       $args  Module args.
		 */
		$filtered = apply_filters( 'dsm_testimonials_woocommerce_items', $items, $args );

		return is_array( $filtered ) ? array_values( $filtered ) : $items;
	}

	/**
	 * Approved WordPress comments (not pingbacks / trackbacks).
	 *
	 * @param array<string, mixed> $args number, post_id.
	 * @return list<array<string, mixed>>
	 */
	public static function comments_items( array $args ): array {
		$number  = Query::clamp_number( $args['number'] ?? 10 );
		$post_id = isset( $args['post_id'] ) ? absint( $args['post_id'] ) : 0;
		$sort    = self::comment_sort( $args, false );

		$comment_args = array(
			'type'    => 'comment',
			'status'  => 'approve',
			'number'  => $number,
			'orderby' => $sort['orderby'],
			'order'   => $sort['order'],
			'post_id' => $post_id > 0 ? $post_id : 0,
		);

		/**
		 * Filters WordPress comment query args for the Testimonials adapter.
		 *
		 * @param array<string, mixed> $comment_args get_comments args.
		 * @param array<string, mixed> $args         Module args.
		 */
		$comment_args = apply_filters( 'dsm_testimonials_comments_query_args', $comment_args, $args );
		if ( ! is_array( $comment_args ) ) {
			return array();
		}

		$comments = get_comments( $comment_args );
		if ( $sort['shuffle'] && is_array( $comments ) ) {
			shuffle( $comments );
		}
		$items = array();

		foreach ( (array) $comments as $comment ) {
			if ( ! $comment instanceof \WP_Comment ) {
				continue;
			}

			if ( 'review' === $comment->comment_type ) {
				continue;
			}

			$avatar = get_avatar_url( $comment, array( 'size' => 96 ) );

			$items[] = array(
				'id'             => 'comment-' . (int) $comment->comment_ID,
				'author'         => $comment->comment_author,
				'role'           => '',
				'company'        => '',
				'email'          => $comment->comment_author_email,
				'avatar_id'      => 0,
				'avatar_url'     => is_string( $avatar ) ? $avatar : '',
				'rating'         => 0.0,
				'date'           => Attrs::sanitize_review_date( (string) $comment->comment_date ),
				'date_iso'       => Attrs::review_date_iso( (string) $comment->comment_date_gmt ),
				'source'         => 'comments',
				'source_url'     => get_comment_link( $comment ),
				'quote'          => $comment->comment_content,
				'video_url'      => '',
				'video_poster'   => '',
				'product_image'  => '',
				'tags'           => array(),
				'schema_include' => true,
			);
		}

		/**
		 * Filters mapped WordPress comment items.
		 *
		 * @param list<array<string, mixed>> $items Item models.
		 * @param array<string, mixed>       $args  Module args.
		 */
		$filtered = apply_filters( 'dsm_testimonials_comments_items', $items, $args );

		return is_array( $filtered ) ? array_values( $filtered ) : $items;
	}

	/**
	 * Map module `orderby` / `order` onto `get_comments` args.
	 *
	 * @param array<string, mixed> $args         Module query args.
	 * @param bool                 $allow_rating Whether rating meta sort is valid (Woo only).
	 * @return array{orderby: string, order: string, meta_key: string, shuffle: bool}
	 */
	private static function comment_sort( array $args, bool $allow_rating ): array {
		$order   = isset( $args['order'] ) && 'ASC' === strtoupper( (string) $args['order'] ) ? 'ASC' : 'DESC';
		$orderby = isset( $args['orderby'] ) ? sanitize_key( (string) $args['orderby'] ) : 'date';

		if ( 'rand' === $orderby ) {
			return array(
				'orderby'  => 'comment_date_gmt',
				'order'    => $order,
				'meta_key' => '',
				'shuffle'  => true,
			);
		}

		if ( 'title' === $orderby ) {
			return array(
				'orderby'  => 'comment_author',
				'order'    => $order,
				'meta_key' => '',
				'shuffle'  => false,
			);
		}

		if ( $allow_rating && 'rating' === $orderby ) {
			return array(
				'orderby'  => 'meta_value_num',
				'order'    => $order,
				'meta_key' => 'rating',
				'shuffle'  => false,
			);
		}

		return array(
			'orderby'  => 'comment_date_gmt',
			'order'    => $order,
			'meta_key' => '',
			'shuffle'  => false,
		);
	}
}
