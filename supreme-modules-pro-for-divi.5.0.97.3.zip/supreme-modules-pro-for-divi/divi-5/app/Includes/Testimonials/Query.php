<?php
/**
 * Query approved testimonials from the CPT library.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Includes\Testimonials;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * WP_Query wrapper for frontend / Visual Builder library source.
 */
final class Query {

	/**
	 * Maximum library query size (REST `number` and frontend `posts_per_page`).
	 */
	public const LIBRARY_NUMBER_MAX = 100;

	/**
	 * Clamp library `number` to 1–100 (empty/zero uses 10).
	 *
	 * @param mixed $number Raw number.
	 * @return int
	 */
	public static function clamp_number( $number ): int {
		$clamped = absint( $number );
		if ( $clamped < 1 ) {
			$clamped = 10;
		}

		$max = (int) apply_filters( 'dsm_testimonials_library_max_number', self::LIBRARY_NUMBER_MAX );
		if ( $max < 1 ) {
			$max = self::LIBRARY_NUMBER_MAX;
		}

		return min( $max, $clamped );
	}

	/**
	 * Fetch approved CPT testimonials as item arrays.
	 *
	 * @param array<string, mixed> $args Query args (number, order, orderby, min_rating, tags).
	 * @return list<array<string, mixed>>
	 */
	public static function library_items( array $args ): array {
		$number     = self::clamp_number( $args['number'] ?? 10 );
		$order      = isset( $args['order'] ) && 'ASC' === strtoupper( (string) $args['order'] ) ? 'ASC' : 'DESC';
		$orderby    = isset( $args['orderby'] ) ? sanitize_key( (string) $args['orderby'] ) : 'date';
		$min_rating = isset( $args['min_rating'] ) ? Cpt::sanitize_rating( $args['min_rating'] ) : 0.0;
		$tags       = isset( $args['tags'] ) ? sanitize_text_field( (string) $args['tags'] ) : '';

		$query_args = array(
			'post_type'              => Cpt::POST_TYPE,
			'post_status'            => 'publish',
			'posts_per_page'         => $number,
			'order'                  => $order,
			'orderby'                => in_array( $orderby, array( 'date', 'title', 'rand', 'meta_value_num' ), true ) ? $orderby : 'date',
			'ignore_sticky_posts'    => true,
			'no_found_rows'          => true,
			'update_post_meta_cache' => true,
			'update_post_term_cache' => true,
			'meta_query'             => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
				array(
					'key'   => Cpt::META_MODERATION,
					'value' => Cpt::MODERATION_APPROVED,
				),
			),
		);

		if ( $min_rating > 0 ) {
			$query_args['meta_query'][] = array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
				'key'     => Cpt::META_RATING,
				'value'   => $min_rating,
				'compare' => '>=',
				'type'    => 'DECIMAL(3,1)',
			);
		}

		if ( 'rating' === $orderby ) {
			$query_args['orderby']  = 'meta_value_num';
			$query_args['meta_key'] = Cpt::META_RATING; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
		}

		if ( '' !== $tags ) {
			$query_args['tax_query'] = array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
				array(
					'taxonomy' => Cpt::TAXONOMY,
					'field'    => 'slug',
					'terms'    => array_filter( array_map( 'sanitize_title', explode( ',', $tags ) ) ),
				),
			);
		}

		/**
		 * Filters WP_Query args for the Testimonials library source.
		 *
		 * @param array<string, mixed> $query_args WP_Query args.
		 * @param array<string, mixed> $args       Module query args.
		 */
		$query_args = apply_filters( 'dsm_testimonials_query_args', $query_args, $args );
		if ( ! is_array( $query_args ) ) {
			return array();
		}

		$query = new \WP_Query( $query_args );
		$items = array();

		foreach ( $query->posts as $post ) {
			if ( ! $post instanceof \WP_Post ) {
				continue;
			}
			$items[] = self::post_to_item( $post );
		}

		wp_reset_postdata();

		/**
		 * Filters library item rows after query.
		 *
		 * @param list<array<string, mixed>> $items Item models.
		 * @param array<string, mixed>       $args  Module query args.
		 */
		$filtered = apply_filters( 'dsm_testimonials_library_items', $items, $args );

		return is_array( $filtered ) ? array_values( $filtered ) : $items;
	}

	/**
	 * Map a CPT post to the shared item model.
	 *
	 * @param \WP_Post $post Testimonial post.
	 * @return array<string, mixed>
	 */
	public static function post_to_item( \WP_Post $post ): array {
		$rating      = Cpt::sanitize_rating( get_post_meta( $post->ID, Cpt::META_RATING, true ) );
		$avatar_id   = absint( get_post_meta( $post->ID, Cpt::META_AVATAR_ID, true ) );
		$poster_id   = absint( get_post_meta( $post->ID, Cpt::META_VIDEO_POSTER_ID, true ) );
		$product_id  = absint( get_post_meta( $post->ID, Cpt::META_PRODUCT_IMAGE_ID, true ) );
		$source      = sanitize_key( (string) get_post_meta( $post->ID, Cpt::META_SOURCE, true ) );
		$tags        = wp_get_post_terms( $post->ID, Cpt::TAXONOMY, array( 'fields' => 'slugs' ) );
		$author      = (string) get_post_meta( $post->ID, Cpt::META_AUTHOR, true );
		$review_date = (string) get_post_meta( $post->ID, Cpt::META_REVIEW_DATE, true );

		if ( '' === $author ) {
			$author = $post->post_title;
		}

		if ( ! in_array( $source, Cpt::source_slugs(), true ) ) {
			$source = 'manual';
		}

		$schema_raw = (string) get_post_meta( $post->ID, Cpt::META_SCHEMA_INCLUDE, true );

		return array(
			'id'             => (string) $post->ID,
			'author'         => $author,
			'role'           => (string) get_post_meta( $post->ID, Cpt::META_ROLE, true ),
			'company'        => (string) get_post_meta( $post->ID, Cpt::META_COMPANY, true ),
			'email'          => (string) get_post_meta( $post->ID, Cpt::META_EMAIL, true ),
			'avatar_id'      => $avatar_id,
			'avatar_url'     => $avatar_id > 0 ? (string) wp_get_attachment_image_url( $avatar_id, 'thumbnail' ) : '',
			'rating'         => $rating,
			'date'           => Attrs::sanitize_review_date( $review_date ),
			'date_iso'       => Attrs::review_date_iso( $review_date ),
			'source'         => $source,
			'source_url'     => (string) get_post_meta( $post->ID, Cpt::META_SOURCE_URL, true ),
			'quote'          => $post->post_content,
			'video_url'      => (string) get_post_meta( $post->ID, Cpt::META_VIDEO_URL, true ),
			'video_poster'   => $poster_id > 0 ? (string) wp_get_attachment_image_url( $poster_id, 'large' ) : '',
			'product_image'  => $product_id > 0 ? (string) wp_get_attachment_image_url( $product_id, 'medium' ) : '',
			'tags'           => is_array( $tags ) ? array_values( array_map( 'strval', $tags ) ) : array(),
			'schema_include' => 'off' !== $schema_raw,
		);
	}
}
