<?php
/**
 * Authenticated REST list for Visual Builder library preview.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Includes\Testimonials;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * GET `/dsm/v1/testimonials`.
 */
final class Rest {

	/**
	 * Register routes.
	 *
	 * @return void
	 */
	public static function register_routes(): void {
		register_rest_route(
			Cpt::REST_NAMESPACE,
			'/testimonials',
			array(
				'methods'             => 'GET',
				'callback'            => array( self::class, 'list_items' ),
				'permission_callback' => static function () {
					return Cpt::current_user_can_manage();
				},
			)
		);
	}

	/**
	 * List item models for the current source.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response
	 */
	public static function list_items( \WP_REST_Request $request ) {
		$source = sanitize_key( (string) $request->get_param( 'source' ) );
		$args   = array(
			'number'     => Query::clamp_number( $request->get_param( 'number' ) ),
			'order'      => sanitize_text_field( (string) $request->get_param( 'order' ) ),
			'orderby'    => sanitize_key( (string) $request->get_param( 'orderby' ) ),
			'min_rating' => Cpt::sanitize_rating( $request->get_param( 'min_rating' ) ),
			'tags'       => sanitize_text_field( (string) $request->get_param( 'tags' ) ),
			'product_id' => absint( $request->get_param( 'product_id' ) ),
			'post_id'    => absint( $request->get_param( 'post_id' ) ),
		);

		$items = Items::from_source( $source, $args, array() );

		$public = array();
		foreach ( $items as $item ) {
			unset( $item['email'] );
			$public[] = $item;
		}

		return new \WP_REST_Response( $public, 200 );
	}
}
