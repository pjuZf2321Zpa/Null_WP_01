<?php
/**
 * Whether the Copy to Clipboard extension is enabled.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * True when Divi Supreme → Extensions → Copy to Clipboard is on (default: off).
 *
 * Opt-in: disabled unless the user turns on Copy to Clipboard under
 * Divi Supreme → Extensions (same policy as other new extensions).
 *
 * Legacy option key `dsm_use_click_to_copy` is intentional — do not rename
 * (existing site settings in `dsm_general`).
 *
 * @return bool
 */
function dsm_is_copy_to_clipboard_extension_enabled(): bool {
	$general = get_option( 'dsm_general', array() );

	if ( ! is_array( $general ) ) {
		return false;
	}

	// Legacy settings key — keep for saved Extensions toggles.
	if ( ! array_key_exists( 'dsm_use_click_to_copy', $general ) ) {
		return false;
	}

	return 'on' === $general['dsm_use_click_to_copy'];
}

/**
 * Legacy alias — prefer dsm_is_copy_to_clipboard_extension_enabled().
 *
 * @return bool
 */
function dsm_is_click_to_copy_extension_enabled(): bool {
	return dsm_is_copy_to_clipboard_extension_enabled();
}
