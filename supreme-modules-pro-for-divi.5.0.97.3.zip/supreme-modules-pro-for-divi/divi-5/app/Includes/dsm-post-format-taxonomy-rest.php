<?php
/**
 * Expose the core `post_format` taxonomy in the REST API.
 *
 * WordPress registers `post_format` without `show_in_rest`, so neither `/wp/v2/post_format`
 * nor `/wp/v2/formats` exists. The Visual Builder (useTaxonomies → GET collection) and
 * `GET /wp/v2/posts?formats[]=` filtering require this route.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Dsm post format register taxonomy args.
 *
 * @param array<string, mixed> $args     Taxonomy registration arguments.
 * @param string               $taxonomy Taxonomy slug.
 * @return array<string, mixed>
 */
function dsm_post_format_register_taxonomy_args( $args, $taxonomy ) {
	if ( 'post_format' !== $taxonomy ) {
		return $args;
	}

	$args['show_in_rest'] = true;
	$args['rest_base']    = 'formats';

	return $args;
}

add_filter( 'register_taxonomy_args', 'dsm_post_format_register_taxonomy_args', 10, 2 );
