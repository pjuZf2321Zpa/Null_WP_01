<?php
/**
 * Snapshot and restore Divi's frontend style store around nested library renders.
 *
 * Divi 5.11.1's {@see \ET\Builder\FrontEnd\Module\Style} has no `capture_state()` or
 * `restore_state()`. Calling them fatals while a popup (or any other library embed)
 * is rendered. The style bucket those methods were meant to round-trip is the
 * private static `$_styles` array that `clear_styles_for_key()` and `render()` already use.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Includes;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Isolates the Divi 5 style store without requiring a Divi version that exposes state APIs.
 */
final class DsmDiviStyleState {

	/**
	 * Divi frontend style class.
	 *
	 * @var class-string
	 */
	public const STYLE_CLASS = \ET\Builder\FrontEnd\Module\Style::class;

	/**
	 * Read the current style store.
	 *
	 * Uses `Style::capture_state()` when both that method and `restore_state()` exist.
	 * Otherwise copies private static properties, including `$_styles`, so a later restore
	 * can put the host page back exactly.
	 *
	 * @param string $style_class Style class name. Defaults to Divi's class.
	 * @return array<string, mixed>|null Null when the store cannot be snapshotted safely.
	 */
	public static function capture( string $style_class = self::STYLE_CLASS ): ?array {
		if ( ! class_exists( $style_class ) ) {
			return null;
		}

		if ( self::has_native_state_api( $style_class ) ) {
			$captured = $style_class::capture_state();

			return is_array( $captured ) ? $captured : null;
		}

		$properties = self::read_static_properties( $style_class );
		if ( null === $properties || ! isset( $properties['_styles'] ) || ! is_array( $properties['_styles'] ) ) {
			return null;
		}

		return array(
			'styles'                => $properties['_styles'],
			'dsm_fallback'          => true,
			'dsm_static_properties' => $properties,
		);
	}

	/**
	 * Snapshot the style store and empty it so a nested library render starts clean.
	 *
	 * @param string $style_class Style class name. Defaults to Divi's class.
	 * @return array<string, mixed>|null Snapshot for {@see self::end_isolation()}, or null when isolation is skipped.
	 */
	public static function begin_isolation( string $style_class = self::STYLE_CLASS ): ?array {
		$state = self::capture( $style_class );
		if ( null === $state ) {
			return null;
		}

		$fallback = isset( $state['dsm_fallback'] ) && true === $state['dsm_fallback'];
		self::clear_collected_style_keys( $style_class, self::style_keys_from_state( $state ), $fallback );

		return $state;
	}

	/**
	 * Drop styles written during isolation and put the host-page snapshot back.
	 *
	 * Native `restore_state()` merges, so leftover library keys are cleared first.
	 * The fallback path replaces the snapshotted static properties, which also puts
	 * preset dedupe and detected module types back to the pre-embed values.
	 *
	 * @param array<string, mixed>|null $state        Snapshot from {@see self::begin_isolation()}.
	 * @param string                    $style_class Style class name. Defaults to Divi's class.
	 * @return void
	 */
	public static function end_isolation( ?array $state, string $style_class = self::STYLE_CLASS ): void {
		if ( null === $state || ! class_exists( $style_class ) ) {
			return;
		}

		$fallback = isset( $state['dsm_fallback'] ) && true === $state['dsm_fallback'];
		$current  = self::capture( $style_class );

		if ( is_array( $current ) ) {
			self::clear_collected_style_keys( $style_class, self::style_keys_from_state( $current ), $fallback );
		}

		if ( $fallback ) {
			$properties = isset( $state['dsm_static_properties'] ) && is_array( $state['dsm_static_properties'] )
				? $state['dsm_static_properties']
				: null;

			if ( null !== $properties ) {
				self::write_static_properties( $style_class, $properties );
			}

			return;
		}

		if ( method_exists( $style_class, 'restore_state' ) ) {
			$style_class::restore_state( $state );
		}
	}

	/**
	 * Whether this Divi build exposes the style-store snapshot API.
	 *
	 * Both methods are required. `capture_state()` alone cannot put the page back.
	 *
	 * @param string $style_class Style class name.
	 * @return bool
	 */
	private static function has_native_state_api( string $style_class ): bool {
		return method_exists( $style_class, 'capture_state' ) && method_exists( $style_class, 'restore_state' );
	}

	/**
	 * Style-store keys recorded on a snapshot (`post`, theme-builder layout IDs, …).
	 *
	 * @param array<string, mixed>|null $state Style snapshot.
	 * @return array<int, int|string>
	 */
	private static function style_keys_from_state( ?array $state ): array {
		if ( ! is_array( $state ) || ! isset( $state['styles'] ) || ! is_array( $state['styles'] ) ) {
			return array();
		}

		return array_keys( $state['styles'] );
	}

	/**
	 * Remove collected rules for the given keys.
	 *
	 * `0` is Divi's sentinel for the current style key, matching
	 * {@see \ET\Builder\FrontEnd\Module\Style::clear_styles_for_key()}.
	 *
	 * @param string            $style_class Style class name.
	 * @param array<int, mixed> $keys        Keys from the style store.
	 * @param bool              $fallback    True when the private `$_styles` store is in use.
	 * @return void
	 */
	private static function clear_collected_style_keys( string $style_class, array $keys, bool $fallback ): void {
		if ( method_exists( $style_class, 'clear_styles_for_key' ) ) {
			foreach ( $keys as $key ) {
				$style_class::clear_styles_for_key( $key );
			}

			$style_class::clear_styles_for_key( 0 );

			return;
		}

		if ( ! $fallback ) {
			return;
		}

		self::write_static_properties(
			$style_class,
			array(
				'_styles' => array(),
			)
		);
	}

	/**
	 * Copy private and protected static properties.
	 *
	 * Public statics are left alone; they are shared services, not the collected CSS bucket.
	 *
	 * @param string $style_class Style class name.
	 * @return array<string, mixed>|null Property name to value, or null when reflection fails.
	 */
	private static function read_static_properties( string $style_class ): ?array {
		try {
			$reflection = new \ReflectionClass( $style_class );
		} catch ( \ReflectionException $exception ) {
			unset( $exception );

			return null;
		}

		$values = array();

		foreach ( $reflection->getProperties() as $property ) {
			if ( ! $property->isStatic() || $property->isPublic() ) {
				continue;
			}

			try {
				$property->setAccessible( true );
				$values[ $property->getName() ] = $property->getValue();
			} catch ( \Throwable $exception ) {
				unset( $exception );
				continue;
			}
		}

		return $values;
	}

	/**
	 * Write previously copied private and protected static properties.
	 *
	 * @param string               $style_class Style class name.
	 * @param array<string, mixed> $values      Property name to value.
	 * @return void
	 */
	private static function write_static_properties( string $style_class, array $values ): void {
		try {
			$reflection = new \ReflectionClass( $style_class );
		} catch ( \ReflectionException $exception ) {
			unset( $exception );

			return;
		}

		foreach ( $values as $name => $value ) {
			if ( ! is_string( $name ) || ! $reflection->hasProperty( $name ) ) {
				continue;
			}

			$property = $reflection->getProperty( $name );
			if ( ! $property->isStatic() || $property->isPublic() ) {
				continue;
			}

			try {
				$property->setAccessible( true );
				$property->setValue( null, $value );
			} catch ( \Throwable $exception ) {
				unset( $exception );
				continue;
			}
		}
	}
}
