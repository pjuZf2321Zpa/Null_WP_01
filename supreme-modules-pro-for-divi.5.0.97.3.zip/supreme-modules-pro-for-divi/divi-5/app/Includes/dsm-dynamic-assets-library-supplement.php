<?php
/**
 * Extends Divi 5 Dynamic Assets merged "all content" with extra layout bodies from Supreme modules
 * that reference Divi Library layouts outside core detection patterns.
 *
 * Register a supplement builder with {@see DSM_Dynamic_Assets_Library_Supplement::register_supplement_builder()}
 * from your module bootstrap (before the `wp` action at priority 5). The callable receives the current
 * merged content string and should return additional `post_content` fragments (e.g. library layouts), space-separated.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Orchestrates supplemental dynamic-asset content from one or more module-specific builders.
 */
class DSM_Dynamic_Assets_Library_Supplement {

	/**
	 * Supplement callbacks: `function ( string $base_content ): string`.
	 *
	 * @var array<int, callable(string): string>
	 */
	private static array $supplement_builders = array();

	/**
	 * Skip `parse_blocks()` above this size to avoid memory exhaustion on Theme Builder mega-content.
	 */
	private const MAX_PARSE_BLOCKS_BYTES = 1_048_576;

	/**
	 * Whether the dynamic-assets supplement hook is registered.
	 *
	 * @var bool
	 */
	private static bool $hook_registered = false;

	/**
	 * Register a callback that returns extra post_content fragments for dynamic asset detection.
	 *
	 * The builder receives the same merged page content Divi uses for early module detection. Return any
	 * non-empty string to merge (typically concatenated library layout `post_content`). Implementations
	 * should return '' when they have nothing to add for the current page content.
	 *
	 * @param callable(string): string $builder Supplement builder.
	 * @return void
	 */
	public static function register_supplement_builder( callable $builder ): void {
		self::$supplement_builders[] = $builder;
		self::ensure_hook();
	}

	/**
	 * Whether any supplement builders are registered.
	 *
	 * @return bool
	 */
	public static function has_supplement_builders(): bool {
		return array() !== self::$supplement_builders;
	}

	/**
	 * Ensure hook.
	 *
	 * @return void
	 */
	private static function ensure_hook(): void {
		if ( self::$hook_registered ) {
			return;
		}
		self::$hook_registered = true;
		add_action( 'wp', array( self::class, 'supplement_dynamic_assets' ), 5 );
	}

	/**
	 * After Divi `pre_initial_setup` (wp:0), extend merged page content and early module lists.
	 *
	 * @return void
	 */
	public static function supplement_dynamic_assets(): void {
		if ( array() === self::$supplement_builders ) {
			return;
		}

		if ( ! class_exists( \ET\Builder\FrontEnd\Assets\DynamicAssetsUtils::class )
			|| ! \ET\Builder\FrontEnd\Assets\DynamicAssetsUtils::is_dynamic_front_end_request() ) {
			return;
		}

		if ( ! class_exists( \ET\Builder\FrontEnd\Assets\DynamicAssets::class ) ) {
			return;
		}

		$dynamic_assets = \ET\Builder\FrontEnd\Assets\DynamicAssets::get_instance();
		if ( ! $dynamic_assets instanceof \ET\Builder\FrontEnd\Assets\DynamicAssets ) {
			return;
		}

		$ref             = new \ReflectionClass( $dynamic_assets );
		$content_handler = self::reflection_get_property_value( $ref, '_content', $dynamic_assets );
		if ( ! $content_handler instanceof \ET\Builder\FrontEnd\Assets\DynamicAssets\DynamicAssetsContent ) {
			return;
		}

		$current   = $content_handler->get_all_content();
		$extra_raw = self::build_combined_supplement( $current );
		if ( '' === $extra_raw ) {
			return;
		}

		if ( strlen( $extra_raw ) > 2_097_152 ) {
			$extra_raw = substr( $extra_raw, 0, 2_097_152 );
		}

		$content_handler->set_all_content( trim( $current . ' ' . $extra_raw ) );

		if ( ! \ET\Builder\FrontEnd\Assets\DynamicAssetsUtils::should_initiate_dynamic_assets() ) {
			return;
		}

		$store    = self::reflection_get_property_value( $ref, '_store', $dynamic_assets );
		$detector = self::reflection_get_property_value( $ref, '_detection', $dynamic_assets );
		if ( ! $store instanceof \ET\Builder\FrontEnd\Assets\DynamicAssets\DynamicAssetsStore
			|| ! $detector instanceof \ET\Builder\FrontEnd\Assets\DynamicAssets\DynamicAssetsDetection ) {
			return;
		}

		$detection_state = $store->detection();
		$had_shortcodes  = ! empty( $detection_state->early_shortcodes );

		$extra_modules = $detector->get_early_modules( $extra_raw );
		$extra_blocks  = isset( $extra_modules['blocks'] ) && is_array( $extra_modules['blocks'] ) ? $extra_modules['blocks'] : array();
		$extra_codes   = isset( $extra_modules['shortcodes'] ) && is_array( $extra_modules['shortcodes'] ) ? $extra_modules['shortcodes'] : array();

		$detection_state->early_blocks     = array_values( array_unique( array_merge( $detection_state->early_blocks, $extra_blocks ) ) );
		$detection_state->early_shortcodes = array_values( array_unique( array_merge( $detection_state->early_shortcodes, $extra_codes ) ) );

		$detection_state->early_modules = array_values(
			array_unique(
				array_merge(
					$detection_state->early_blocks,
					array_map(
						array( \ET\Builder\FrontEnd\Assets\DynamicAssetsUtils::class, 'get_block_name_from_shortcode' ),
						$detection_state->early_shortcodes
					)
				)
			)
		);

		$detection_state->options['has_block']     = ! empty( $detection_state->early_blocks );
		$detection_state->options['has_shortcode'] = ! empty( $detection_state->early_shortcodes );

		if ( ! $had_shortcodes && ! empty( $detection_state->early_shortcodes ) ) {
			add_filter( 'the_content', array( \ET\Builder\Framework\Utility\HTMLUtility::class, 'fix_builder_shortcodes' ) );
			add_filter( 'et_builder_render_layout', array( \ET\Builder\Framework\Utility\HTMLUtility::class, 'fix_builder_shortcodes' ) );
			add_filter( 'the_content', 'et_pb_the_content_prep_code_module_for_wpautop', 0 );
			add_filter( 'et_builder_render_layout', 'et_pb_the_content_prep_code_module_for_wpautop', 0 );
			$dynamic_assets->maybe_load_early_framework( $content_handler->get_all_content() );
		}
	}

	/**
	 * Build supplemental layout `post_content` for asset detection from registered module builders.
	 *
	 * Used by Divi Dynamic Assets (wp:5 reflection hook) and Supreme {@see \DiviSupreme\Includes\DsmFrontendDynamicAssets::get_merged_detection_block_slugs()}.
	 *
	 * @param string $base_content         Current merged page content (post + retriever + popup, etc.).
	 * @param array  $skip_builder_classes Optional builder class names to omit (e.g. popup when already merged).
	 * @return string Combined supplemental content or empty string.
	 */
	public static function build_combined_supplement_for_content( string $base_content, array $skip_builder_classes = array() ): string {
		if ( array() === self::$supplement_builders || '' === $base_content ) {
			return '';
		}

		return self::build_combined_supplement( $base_content, $skip_builder_classes );
	}

	/**
	 * Build combined supplement.
	 *
	 * @param string $base_content         Current dynamic-assets merged content.
	 * @param array  $skip_builder_classes Builder classes to skip.
	 * @return string Combined supplemental content or empty string.
	 */
	private static function build_combined_supplement( string $base_content, array $skip_builder_classes = array() ): string {
		$layout_ids = self::collect_supplement_layout_ids_for_content( $base_content, $skip_builder_classes );
		if ( array() === $layout_ids ) {
			return '';
		}

		if ( count( $layout_ids ) > 75 ) {
			$layout_ids = array_slice( $layout_ids, 0, 75 );
		}

		return implode( ' ', self::fetch_layout_post_content_strings_for_ids( $layout_ids ) );
	}

	/**
	 * Union of nested library layout IDs referenced by registered supplement builders.
	 *
	 * @param string $base_content         Current dynamic-assets merged content.
	 * @param array  $skip_builder_classes Builder classes to skip.
	 * @return list<int>
	 */
	public static function collect_supplement_layout_ids_for_content( string $base_content, array $skip_builder_classes = array() ): array {
		if ( '' === $base_content ) {
			return array();
		}

		$skip_builder_classes = array_values(
			array_filter(
				array_map( 'strval', $skip_builder_classes )
			)
		);

		$collectors = array(
			array( DSM_Dynamic_Assets_Content_Toggle_Library::class, 'collect_referenced_layout_ids' ),
			array( DSM_Dynamic_Assets_Advanced_Tabs_Library::class, 'collect_referenced_layout_ids' ),
			array( DSM_Dynamic_Assets_Popup_Library::class, 'collect_referenced_layout_ids' ),
			array( DSM_Dynamic_Assets_Divi_Shortcode_Library::class, 'collect_referenced_layout_ids' ),
		);

		$seen = array();
		foreach ( $collectors as $collector ) {
			if ( ! is_array( $collector ) || ! isset( $collector[0], $collector[1] ) ) {
				continue;
			}
			if ( in_array( (string) $collector[0], $skip_builder_classes, true ) ) {
				continue;
			}
			if ( ! is_callable( $collector ) ) {
				continue;
			}

			foreach ( $collector( $base_content ) as $layout_id ) {
				$layout_id = (int) $layout_id;
				if ( $layout_id > 0 ) {
					$seen[ $layout_id ] = true;
				}
			}
		}

		return array_map( 'intval', array_keys( $seen ) );
	}

	/**
	 * Fetch layout post content strings for IDs.
	 *
	 * @param array $layout_ids Library layout post IDs.
	 * @return list<string> Non-empty `post_content` fragments.
	 */
	public static function fetch_layout_post_content_strings_for_ids( array $layout_ids ): array {
		$pieces = array();

		foreach ( $layout_ids as $layout_id ) {
			$layout_id = (int) $layout_id;
			if ( $layout_id <= 0 ) {
				continue;
			}

			$layout_post = get_post( $layout_id );
			if ( ! $layout_post instanceof \WP_Post ) {
				continue;
			}

			$post_content = isset( $layout_post->post_content ) ? (string) $layout_post->post_content : '';
			if ( '' === $post_content ) {
				continue;
			}

			$pieces[] = $post_content;
		}

		return $pieces;
	}

	/**
	 * Parse blocks with a byte-size guard so Theme Builder mega-content cannot exhaust PHP memory.
	 *
	 * @param string $content Serialized block / post content.
	 * @return array<int, mixed>
	 */
	public static function safe_parse_blocks( string $content ): array {
		if ( '' === $content ) {
			return array();
		}

		if (
			class_exists( \DiviSupreme\Includes\DsmFrontendAssetRegistry::class )
			&& ! \DiviSupreme\Includes\DsmFrontendAssetRegistry::should_use_manual_block_parsing_for_detection()
		) {
			return array();
		}

		if ( strlen( $content ) > self::MAX_PARSE_BLOCKS_BYTES ) {
			return array();
		}

		return parse_blocks( $content );
	}

	/**
	 * Breadth-first walk of nested library layouts (shared by module supplement collectors).
	 *
	 * @param string   $base_content                 Seed content (page / layout body).
	 * @param callable $collect_seed_ids             `function ( string $content ): list<int>`.
	 * @param callable $collect_nested_ids_from_body `function ( string $layout_post_content ): list<int>`.
	 * @return list<int>
	 */
	public static function bfs_collect_nested_layout_ids(
		string $base_content,
		callable $collect_seed_ids,
		callable $collect_nested_ids_from_body
	): array {
		if ( '' === $base_content ) {
			return array();
		}

		$seen  = array();
		$queue = array_values(
			array_filter(
				array_map( 'intval', $collect_seed_ids( $base_content ) )
			)
		);
		$guard = 0;

		while ( array() !== $queue && $guard < 100 ) {
			++$guard;
			$layout_id = (int) array_shift( $queue );
			if ( $layout_id <= 0 || isset( $seen[ $layout_id ] ) ) {
				continue;
			}
			$seen[ $layout_id ] = true;

			$layout_post = get_post( $layout_id );
			if ( ! $layout_post instanceof \WP_Post ) {
				continue;
			}

			$post_content = isset( $layout_post->post_content ) ? (string) $layout_post->post_content : '';
			if ( '' === $post_content ) {
				continue;
			}

			foreach ( $collect_nested_ids_from_body( $post_content ) as $nested_id ) {
				$nested_id = (int) $nested_id;
				if ( $nested_id > 0 && ! isset( $seen[ $nested_id ] ) ) {
					$queue[] = $nested_id;
				}
			}
		}

		return array_map( 'intval', array_keys( $seen ) );
	}

	/**
	 * Read property from an object (private props on DynamicAssets).
	 *
	 * @param \ReflectionClass $ref      Class reflection.
	 * @param string           $name     Property name.
	 * @param object           $instance Object instance.
	 * @return mixed
	 */
	private static function reflection_get_property_value( \ReflectionClass $ref, string $name, object $instance ) {
		if ( ! $ref->hasProperty( $name ) ) {
			return null;
		}
		$prop = $ref->getProperty( $name );
		if ( PHP_VERSION_ID < 80100 ) {
			$prop->setAccessible( true );
		}

		return $prop->getValue( $instance );
	}
}

/**
 * Library layout IDs referenced by the Supreme Content Toggle module (Divi 5 block).
 *
 * Use {@see DSM_Dynamic_Assets_Content_Toggle_Library::build_library_supplement()} as a
 * {@see DSM_Dynamic_Assets_Library_Supplement::register_supplement_builder()} callback, or call helpers
 * from custom builders if you need the same parsing rules.
 */
class DSM_Dynamic_Assets_Content_Toggle_Library {

	/**
	 * Supplement callback for {@see DSM_Dynamic_Assets_Library_Supplement}.
	 *
	 * @param string $base_content Current dynamic-assets merged content.
	 * @return string Supplementary content or empty string.
	 */
	public static function build_library_supplement( string $base_content ): string {
		$layout_ids = self::collect_referenced_layout_ids( $base_content );
		if ( array() === $layout_ids ) {
			return '';
		}

		return implode( ' ', DSM_Dynamic_Assets_Library_Supplement::fetch_layout_post_content_strings_for_ids( $layout_ids ) );
	}

	/**
	 * All library layout IDs referenced directly or via nested Content Toggle embeds.
	 *
	 * @param string $base_content Current dynamic-assets merged content.
	 * @return list<int>
	 */
	public static function collect_referenced_layout_ids( string $base_content ): array {
		if ( '' === $base_content || ! str_contains( $base_content, 'dsm/content-toggle' ) ) {
			return array();
		}

		return DSM_Dynamic_Assets_Library_Supplement::bfs_collect_nested_layout_ids(
			$base_content,
			array( self::class, 'collect_toggle_library_ids_from_content' ),
			static function ( string $post_content ): array {
				if ( ! str_contains( $post_content, 'dsm/content-toggle' ) ) {
					return array();
				}

				return DSM_Dynamic_Assets_Content_Toggle_Library::collect_toggle_library_ids_from_content( $post_content );
			}
		);
	}

	/**
	 * Parse blocks and collect et_pb_layout IDs used when a Content Toggle side is set to "library".
	 *
	 * @param string $content HTML / block content.
	 * @return int[] Layout post IDs.
	 */
	public static function collect_toggle_library_ids_from_content( string $content ): array {
		$blocks = DSM_Dynamic_Assets_Library_Supplement::safe_parse_blocks( $content );
		if ( ! empty( $blocks ) ) {
			$ids = array();
			self::walk_blocks_for_toggle_library_ids( $blocks, $ids );

			return array_values( array_unique( array_filter( array_map( 'intval', $ids ) ) ) );
		}

		return self::collect_toggle_library_ids_regex_fallback( $content );
	}

	/**
	 * Regex fallback for Content Toggle library IDs when block parsing is skipped.
	 *
	 * @param string $content Serialized block / post content.
	 * @return list<int>
	 */
	private static function collect_toggle_library_ids_regex_fallback( string $content ): array {
		if ( '' === $content || ! str_contains( $content, 'dsm/content-toggle' ) ) {
			return array();
		}

		$ids = array();
		if ( preg_match_all( '/library_id_(?:one|two)[^}]{0,300}?["\']?value["\']?\s*:\s*"?(\d+)"?/s', $content, $matches ) ) {
			foreach ( $matches[1] as $raw_id ) {
				$layout_id = (int) $raw_id;
				if ( $layout_id > 0 ) {
					$ids[] = $layout_id;
				}
			}
		}

		return array_values( array_unique( $ids ) );
	}

	/**
	 * Recursive block walk for Content Toggle library references.
	 *
	 * @param array<int, mixed> $blocks Parsed blocks.
	 * @param int[]             $ids    Collected IDs (by ref).
	 * @return void
	 */
	public static function walk_blocks_for_toggle_library_ids( array $blocks, array &$ids ): void {
		foreach ( $blocks as $block ) {
			if ( ! is_array( $block ) ) {
				continue;
			}

			if ( 'dsm/content-toggle' === ( $block['blockName'] ?? '' ) ) {
				$attrs = $block['attrs'] ?? array();
				if ( is_array( $attrs ) ) {
					foreach ( array( 'one', 'two' ) as $idx ) {
						$ctype = self::read_inner_desktop_string( $attrs[ 'content_type_' . $idx ] ?? null );
						if ( 'library' !== $ctype ) {
							continue;
						}
						$lid = self::read_library_post_id_from_attr( $attrs[ 'library_id_' . $idx ] ?? null );
						if ( $lid > 0 ) {
							$ids[] = $lid;
						}
					}
				}
			}

			if ( ! empty( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ) {
				self::walk_blocks_for_toggle_library_ids( $block['innerBlocks'], $ids );
			}
		}
	}

	/**
	 * Read inner desktop string.
	 *
	 * @param mixed $attr_node Module attribute node.
	 * @return string Desktop innerContent string value.
	 */
	public static function read_inner_desktop_string( $attr_node ): string {
		if ( ! is_array( $attr_node ) ) {
			return '';
		}
		$inner = $attr_node['innerContent'] ?? null;
		if ( ! is_array( $inner ) ) {
			return '';
		}
		$desktop = $inner['desktop'] ?? null;
		if ( ! is_array( $desktop ) ) {
			return '';
		}
		$value = $desktop['value'] ?? '';

		return is_string( $value ) ? $value : '';
	}

	/**
	 * Read library post ID from attr.
	 *
	 * @param mixed $attr_node library_id_* attribute node.
	 * @return int Post ID or 0.
	 */
	public static function read_library_post_id_from_attr( $attr_node ): int {
		if ( ! is_array( $attr_node ) ) {
			return 0;
		}
		$inner = $attr_node['innerContent'] ?? null;
		if ( ! is_array( $inner ) ) {
			return 0;
		}
		$desktop = $inner['desktop'] ?? null;
		if ( ! is_array( $desktop ) ) {
			return 0;
		}
		$raw = $desktop['value'] ?? 0;
		if ( is_numeric( $raw ) ) {
			$id = (int) $raw;
			return $id > 0 ? $id : 0;
		}

		return 0;
	}
}

/**
 * Library layout IDs referenced by the Supreme Advanced Tabs module (Divi 5 parent + tab children).
 *
 * Mirrors {@see DSM_Dynamic_Assets_Content_Toggle_Library}: nested layouts must be merged into Divi's
 * Dynamic Assets merged content so frontend CSS/JS for modules inside those layouts loads correctly.
 */
class DSM_Dynamic_Assets_Advanced_Tabs_Library {

	/**
	 * Supplement callback for {@see DSM_Dynamic_Assets_Library_Supplement}.
	 *
	 * @param string $base_content Current dynamic-assets merged content.
	 * @return string Supplementary content or empty string.
	 */
	public static function build_library_supplement( string $base_content ): string {
		$layout_ids = self::collect_referenced_layout_ids( $base_content );
		if ( array() === $layout_ids ) {
			return '';
		}

		return implode( ' ', DSM_Dynamic_Assets_Library_Supplement::fetch_layout_post_content_strings_for_ids( $layout_ids ) );
	}

	/**
	 * All library layout IDs referenced by Advanced Tabs (including nested toggle/shortcode layouts).
	 *
	 * @param string $base_content Current dynamic-assets merged content.
	 * @return list<int>
	 */
	public static function collect_referenced_layout_ids( string $base_content ): array {
		if ( '' === $base_content || ! str_contains( $base_content, 'dsm/advanced-tabs' ) ) {
			return array();
		}

		return DSM_Dynamic_Assets_Library_Supplement::bfs_collect_nested_layout_ids(
			$base_content,
			array( self::class, 'collect_advanced_tabs_library_ids_from_content' ),
			static function ( string $post_content ): array {
				$nested = array();

				if ( str_contains( $post_content, 'dsm/advanced-tabs' ) ) {
					$nested = array_merge(
						$nested,
						DSM_Dynamic_Assets_Advanced_Tabs_Library::collect_advanced_tabs_library_ids_from_content( $post_content )
					);
				}

				if ( str_contains( $post_content, 'dsm/content-toggle' ) ) {
					$nested = array_merge(
						$nested,
						DSM_Dynamic_Assets_Content_Toggle_Library::collect_toggle_library_ids_from_content( $post_content )
					);
				}

				return $nested;
			}
		);
	}

	/**
	 * Parse blocks and collect et_pb_layout IDs used when an Advanced Tabs tab uses content type "library".
	 *
	 * @param string $content HTML / block content.
	 * @return int[] Layout post IDs.
	 */
	public static function collect_advanced_tabs_library_ids_from_content( string $content ): array {
		$blocks = DSM_Dynamic_Assets_Library_Supplement::safe_parse_blocks( $content );
		if ( ! empty( $blocks ) ) {
			$ids = array();
			self::walk_blocks_for_advanced_tabs_library_ids( $blocks, $ids );

			return array_values( array_unique( array_filter( array_map( 'intval', $ids ) ) ) );
		}

		return self::collect_advanced_tabs_library_ids_regex_fallback( $content );
	}

	/**
	 * Regex fallback for Advanced Tabs library IDs when block parsing is skipped.
	 *
	 * @param string $content Serialized block / post content.
	 * @return list<int>
	 */
	private static function collect_advanced_tabs_library_ids_regex_fallback( string $content ): array {
		if ( '' === $content || ! str_contains( $content, 'dsm/advanced-tabs' ) ) {
			return array();
		}

		$ids = array();
		if ( preg_match_all( '/library_id[^}]{0,300}?["\']?value["\']?\s*:\s*"?(\d+)"?/s', $content, $matches ) ) {
			foreach ( $matches[1] as $raw_id ) {
				$layout_id = (int) $raw_id;
				if ( $layout_id > 0 ) {
					$ids[] = $layout_id;
				}
			}
		}

		return array_values( array_unique( $ids ) );
	}

	/**
	 * Recursive block walk for Advanced Tabs library references (parent → tab children).
	 *
	 * @param array<int, mixed> $blocks Parsed blocks.
	 * @param int[]             $ids    Collected IDs (by ref).
	 * @return void
	 */
	public static function walk_blocks_for_advanced_tabs_library_ids( array $blocks, array &$ids ): void {
		foreach ( $blocks as $block ) {
			if ( ! is_array( $block ) ) {
				continue;
			}

			if ( 'dsm/advanced-tabs' === ( $block['blockName'] ?? '' ) ) {
				$inner = $block['innerBlocks'] ?? array();
				if ( is_array( $inner ) ) {
					foreach ( $inner as $child_block ) {
						if ( ! is_array( $child_block ) ) {
							continue;
						}
						if ( 'dsm/advanced-tabs-child' !== ( $child_block['blockName'] ?? '' ) ) {
							continue;
						}
						$cattrs = $child_block['attrs'] ?? array();
						if ( ! is_array( $cattrs ) ) {
							continue;
						}
						$ctype = DSM_Dynamic_Assets_Content_Toggle_Library::read_inner_desktop_string( $cattrs['dsm_content_type'] ?? null );
						if ( 'library' !== $ctype ) {
							continue;
						}
						$lid = DSM_Dynamic_Assets_Content_Toggle_Library::read_library_post_id_from_attr( $cattrs['dsm_content_library_layout'] ?? null );
						if ( $lid > 0 ) {
							$ids[] = $lid;
						}
					}
				}
			}

			if ( ! empty( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ) {
				self::walk_blocks_for_advanced_tabs_library_ids( $block['innerBlocks'], $ids );
			}
		}
	}
}

/**
 * Merges Divi Library layouts opened via Advanced → Popup into Divi Dynamic Assets merged content.
 *
 * Without this, pages that only trigger a popup (no `dsm/*` in the main post) never detect Supreme
 * modules inside the popup layout, so their scripts/styles are not enqueued.
 */
class DSM_Dynamic_Assets_Popup_Library {

	/**
	 * Supplement callback for {@see DSM_Dynamic_Assets_Library_Supplement}.
	 *
	 * @param string $base_content Current dynamic-assets merged content.
	 * @return string Supplementary layout post_content or empty string.
	 */
	public static function build_library_supplement( string $base_content ): string {
		if ( ! class_exists( \DiviSupreme\Includes\DsmFrontendDynamicAssets::class ) ) {
			return '';
		}

		$layout_ids = self::collect_referenced_layout_ids( $base_content );
		if ( array() === $layout_ids ) {
			return '';
		}

		return implode( ' ', DSM_Dynamic_Assets_Library_Supplement::fetch_layout_post_content_strings_for_ids( $layout_ids ) );
	}

	/**
	 * Popup layout IDs referenced from merged content (including nested popup layouts).
	 *
	 * @param string $base_content Current dynamic-assets merged content.
	 * @return list<int>
	 */
	public static function collect_referenced_layout_ids( string $base_content ): array {
		if ( ! class_exists( \DiviSupreme\Includes\DsmFrontendDynamicAssets::class ) ) {
			return array();
		}

		return \DiviSupreme\Includes\DsmFrontendDynamicAssets::collect_popup_layout_ids_for_dynamic_assets( $base_content );
	}
}

DSM_Dynamic_Assets_Library_Supplement::register_supplement_builder(
	array( DSM_Dynamic_Assets_Content_Toggle_Library::class, 'build_library_supplement' )
);

DSM_Dynamic_Assets_Library_Supplement::register_supplement_builder(
	array( DSM_Dynamic_Assets_Advanced_Tabs_Library::class, 'build_library_supplement' )
);

DSM_Dynamic_Assets_Library_Supplement::register_supplement_builder(
	array( DSM_Dynamic_Assets_Popup_Library::class, 'build_library_supplement' )
);

/**
 * Merges Divi Library layouts referenced by `[divi_shortcode id="…"]` into Dynamic Assets merged content.
 *
 * Covers standalone shortcode usage (widgets, classic content) and Supreme modules with Content Type Shortcode.
 */
class DSM_Dynamic_Assets_Divi_Shortcode_Library {

	/**
	 * Supplement callback for {@see DSM_Dynamic_Assets_Library_Supplement}.
	 *
	 * @param string $base_content Current dynamic-assets merged content.
	 * @return string Supplementary layout post_content or empty string.
	 */
	public static function build_library_supplement( string $base_content ): string {
		$layout_ids = self::collect_referenced_layout_ids( $base_content );
		if ( array() === $layout_ids ) {
			return '';
		}

		return implode( ' ', DSM_Dynamic_Assets_Library_Supplement::fetch_layout_post_content_strings_for_ids( $layout_ids ) );
	}

	/**
	 * All library layout IDs from `[divi_shortcode]` tags and DSM shortcode content-type fields.
	 *
	 * @param string $base_content Current dynamic-assets merged content.
	 * @return list<int>
	 */
	public static function collect_referenced_layout_ids( string $base_content ): array {
		if ( '' === $base_content ) {
			return array();
		}

		if ( ! str_contains( $base_content, 'divi_shortcode' )
			&& ! str_contains( $base_content, 'divi_library_layout' )
			&& ! self::content_has_dsm_shortcode_content_type_blocks( $base_content ) ) {
			return array();
		}

		return DSM_Dynamic_Assets_Library_Supplement::bfs_collect_nested_layout_ids(
			$base_content,
			array( self::class, 'collect_divi_shortcode_layout_ids_from_content' ),
			array( self::class, 'collect_divi_shortcode_layout_ids_from_content' )
		);
	}

	/**
	 * Content has dsm shortcode content type blocks.
	 *
	 * @param string $content HTML / block content.
	 * @return bool
	 */
	private static function content_has_dsm_shortcode_content_type_blocks( string $content ): bool {
		if ( ! str_contains( $content, 'dsm/' ) ) {
			return false;
		}

		if ( str_contains( $content, 'divi_shortcode' )
			|| str_contains( $content, 'divi_library_layout' )
			|| str_contains( $content, 'shortcode_content_' ) ) {
			return true;
		}

		$blocks = DSM_Dynamic_Assets_Library_Supplement::safe_parse_blocks( $content );
		if ( empty( $blocks ) ) {
			return false;
		}

		return self::blocks_have_shortcode_content_type( $blocks );
	}

	/**
	 * Blocks have shortcode content type.
	 *
	 * @param array<int, mixed> $blocks Parsed blocks.
	 * @return bool
	 */
	private static function blocks_have_shortcode_content_type( array $blocks ): bool {
		foreach ( $blocks as $block ) {
			if ( ! is_array( $block ) ) {
				continue;
			}

			$attrs = $block['attrs'] ?? array();
			if ( is_array( $attrs ) && self::block_attrs_reference_divi_shortcode( $block['blockName'] ?? '', $attrs ) ) {
				return true;
			}

			$inner = $block['innerBlocks'] ?? array();
			if ( is_array( $inner ) && self::blocks_have_shortcode_content_type( $inner ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Whether a shortcode field value references a library-embed shortcode tag.
	 *
	 * @param string $field Shortcode field text.
	 * @return bool
	 */
	private static function field_references_library_embed_shortcode( string $field ): bool {
		return '' !== $field
			&& ( str_contains( $field, 'divi_shortcode' ) || str_contains( $field, 'divi_library_layout' ) );
	}

	/**
	 * Block attrs reference divi shortcode.
	 *
	 * @param string              $block_name Block name.
	 * @param array<string,mixed> $attrs      Block attrs.
	 * @return bool
	 */
	private static function block_attrs_reference_divi_shortcode( string $block_name, array $attrs ): bool {
		switch ( $block_name ) {
			case 'dsm/content-toggle':
				foreach ( array( 'one', 'two' ) as $idx ) {
					$ctype = DSM_Dynamic_Assets_Content_Toggle_Library::read_inner_desktop_string( $attrs[ 'content_type_' . $idx ] ?? null );
					if ( 'shortcode' !== $ctype ) {
						continue;
					}
					$field = DSM_Dynamic_Assets_Content_Toggle_Library::read_inner_desktop_string( $attrs[ 'shortcode_content_' . $idx ] ?? null );
					if ( self::field_references_library_embed_shortcode( $field ) ) {
						return true;
					}
				}
				break;
			case 'dsm/advanced-tabs-child':
				$ctype = DSM_Dynamic_Assets_Content_Toggle_Library::read_inner_desktop_string( $attrs['dsm_content_type'] ?? null );
				if ( 'shortcode' === $ctype ) {
					$field = DSM_Dynamic_Assets_Content_Toggle_Library::read_inner_desktop_string( $attrs['shortcode_content'] ?? null );
					if ( self::field_references_library_embed_shortcode( $field ) ) {
						return true;
					}
				}
				break;
			case 'dsm/faq-child':
				$ctype = DSM_Dynamic_Assets_Content_Toggle_Library::read_inner_desktop_string( $attrs['dsm_content_type'] ?? null );
				if ( 'shortcode' === $ctype ) {
					$field = DSM_Dynamic_Assets_Content_Toggle_Library::read_inner_desktop_string( $attrs['dsm_shortcode_content'] ?? null );
					if ( self::field_references_library_embed_shortcode( $field ) ) {
						return true;
					}
				}
				break;
			case 'dsm/circle-info-child':
				$ctype = DSM_Dynamic_Assets_Content_Toggle_Library::read_inner_desktop_string( $attrs['dsm_content_type'] ?? null );
				if ( 'shortcode' === $ctype ) {
					$raw   = $attrs['shortcode_content'] ?? null;
					$field = self::read_shortcode_content_text_attr( $raw );
					if ( self::field_references_library_embed_shortcode( $field ) ) {
						return true;
					}
				}
				break;
			case 'dsm/content-timeline-child':
				$ctype = DSM_Dynamic_Assets_Content_Toggle_Library::read_inner_desktop_string( $attrs['dsm_content_type'] ?? null );
				if ( 'shortcode' === $ctype ) {
					$field = DSM_Dynamic_Assets_Content_Toggle_Library::read_inner_desktop_string( $attrs['dsm_shortcode'] ?? null );
					if ( self::field_references_library_embed_shortcode( $field ) ) {
						return true;
					}
				}
				break;
		}

		return false;
	}

	/**
	 * Read shortcode content text attr.
	 *
	 * @param mixed $attr_node `shortcode_content` (headingLink leaf).
	 * @return string
	 */
	private static function read_shortcode_content_text_attr( $attr_node ): string {
		if ( ! is_array( $attr_node ) ) {
			return '';
		}
		$inner = $attr_node['innerContent'] ?? null;
		if ( ! is_array( $inner ) ) {
			return '';
		}
		$desktop = $inner['desktop'] ?? null;
		if ( ! is_array( $desktop ) ) {
			return '';
		}
		$value = $desktop['value'] ?? '';
		if ( is_string( $value ) ) {
			return $value;
		}
		if ( is_array( $value ) && isset( $value['text'] ) && is_string( $value['text'] ) ) {
			return $value['text'];
		}

		return '';
	}

	/**
	 * Collect layout IDs from `[divi_shortcode id="…"]` in raw content and DSM shortcode content-type fields.
	 *
	 * @param string $content HTML / block content.
	 * @return int[]
	 */
	public static function collect_divi_shortcode_layout_ids_from_content( string $content ): array {
		$ids = array();

		if ( class_exists( \DiviSupreme\Includes\DiviLibraryLayoutRenderer::class ) ) {
			foreach ( \DiviSupreme\Includes\DiviLibraryLayoutRenderer::extract_divi_shortcode_layout_ids( $content ) as $id ) {
				$ids[] = $id;
			}
		}

		$blocks = DSM_Dynamic_Assets_Library_Supplement::safe_parse_blocks( $content );
		if ( ! empty( $blocks ) ) {
			self::walk_blocks_collect_divi_shortcode_layout_ids( $blocks, $ids );
		}

		return array_values( array_unique( array_filter( array_map( 'intval', $ids ) ) ) );
	}

	/**
	 * Walk blocks collect divi shortcode layout IDs.
	 *
	 * @param array<int, mixed> $blocks Parsed blocks.
	 * @param int[]             $ids Collected IDs (by ref).
	 * @return void
	 */
	private static function walk_blocks_collect_divi_shortcode_layout_ids( array $blocks, array &$ids ): void {
		foreach ( $blocks as $block ) {
			if ( ! is_array( $block ) ) {
				continue;
			}

			$attrs = $block['attrs'] ?? array();
			if ( is_array( $attrs ) ) {
				foreach ( self::shortcode_field_values_from_block_attrs( $block['blockName'] ?? '', $attrs ) as $field_value ) {
					if ( class_exists( \DiviSupreme\Includes\DiviLibraryLayoutRenderer::class ) ) {
						foreach ( \DiviSupreme\Includes\DiviLibraryLayoutRenderer::extract_divi_shortcode_layout_ids( $field_value ) as $id ) {
							$ids[] = $id;
						}
					}
				}
			}

			$inner = $block['innerBlocks'] ?? array();
			if ( is_array( $inner ) ) {
				self::walk_blocks_collect_divi_shortcode_layout_ids( $inner, $ids );
			}
		}
	}

	/**
	 * Shortcode field values from block attrs.
	 *
	 * @param string              $block_name Block name.
	 * @param array<string,mixed> $attrs      Block attrs.
	 * @return string[]
	 */
	private static function shortcode_field_values_from_block_attrs( string $block_name, array $attrs ): array {
		$values = array();

		switch ( $block_name ) {
			case 'dsm/content-toggle':
				foreach ( array( 'one', 'two' ) as $idx ) {
					$ctype = DSM_Dynamic_Assets_Content_Toggle_Library::read_inner_desktop_string( $attrs[ 'content_type_' . $idx ] ?? null );
					if ( 'shortcode' === $ctype ) {
						$field = DSM_Dynamic_Assets_Content_Toggle_Library::read_inner_desktop_string( $attrs[ 'shortcode_content_' . $idx ] ?? null );
						if ( '' !== $field ) {
							$values[] = $field;
						}
					}
				}
				break;
			case 'dsm/advanced-tabs-child':
				$ctype = DSM_Dynamic_Assets_Content_Toggle_Library::read_inner_desktop_string( $attrs['dsm_content_type'] ?? null );
				if ( 'shortcode' === $ctype ) {
					$field = DSM_Dynamic_Assets_Content_Toggle_Library::read_inner_desktop_string( $attrs['shortcode_content'] ?? null );
					if ( '' !== $field ) {
						$values[] = $field;
					}
				}
				break;
			case 'dsm/faq-child':
				$ctype = DSM_Dynamic_Assets_Content_Toggle_Library::read_inner_desktop_string( $attrs['dsm_content_type'] ?? null );
				if ( 'shortcode' === $ctype ) {
					$field = DSM_Dynamic_Assets_Content_Toggle_Library::read_inner_desktop_string( $attrs['dsm_shortcode_content'] ?? null );
					if ( '' !== $field ) {
						$values[] = $field;
					}
				}
				break;
			case 'dsm/circle-info-child':
				$ctype = DSM_Dynamic_Assets_Content_Toggle_Library::read_inner_desktop_string( $attrs['dsm_content_type'] ?? null );
				if ( 'shortcode' === $ctype ) {
					$field = self::read_shortcode_content_text_attr( $attrs['shortcode_content'] ?? null );
					if ( '' !== $field ) {
						$values[] = $field;
					}
				}
				break;
			case 'dsm/content-timeline-child':
				$ctype = DSM_Dynamic_Assets_Content_Toggle_Library::read_inner_desktop_string( $attrs['dsm_content_type'] ?? null );
				if ( 'shortcode' === $ctype ) {
					$field = DSM_Dynamic_Assets_Content_Toggle_Library::read_inner_desktop_string( $attrs['dsm_shortcode'] ?? null );
					if ( '' !== $field ) {
						$values[] = $field;
					}
				}
				break;
		}

		return $values;
	}
}

DSM_Dynamic_Assets_Library_Supplement::register_supplement_builder(
	array( DSM_Dynamic_Assets_Divi_Shortcode_Library::class, 'build_library_supplement' )
);
