<?php
/**
 * Visual Builder REST save helpers (memory + page-settings access).
 *
 * Divi `sync-to-server` payloads are large. PHP's default admin cap is 256M
 * (`WP_MAX_MEMORY_LIMIT`), which this site already exhausts in `$wpdb` during
 * `wp_update_post`. Divi's `sanitize_page_settings()` also drops unknown keys,
 * so extensions must read `dsm_*` settings from the raw body — but must not
 * `json_decode` the full layout.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

// phpcs:disable WordPress.Files.FileName -- PSR-4 class name matches sibling Includes.

namespace DiviSupreme\Includes;

use WP_REST_Request;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Raises memory for Divi VB saves and exposes slim page-settings slices.
 */
final class DsmVbRestSave {

	/**
	 * Default admin memory ceiling for a VB sync (overridable).
	 */
	public const DEFAULT_MEMORY_LIMIT = '512M';

	/**
	 * Current `/divi/v1/sync-to-server` request, if any.
	 *
	 * @var WP_REST_Request|null
	 */
	private static ?WP_REST_Request $request = null;

	/**
	 * Whether the slim page-settings slices were extracted.
	 *
	 * @var bool
	 */
	private static bool $hydrated = false;

	/**
	 * Unsanitized `pageSettings` object (includes `dsm_*` keys).
	 *
	 * @var array<string, mixed>
	 */
	private static array $page_settings = array();

	/**
	 * Unsanitized `pageSettingsByLayout.postContent` object.
	 *
	 * @var array<string, mixed>
	 */
	private static array $page_settings_by_layout_post_content = array();

	/**
	 * Register WordPress hooks.
	 *
	 * @return void
	 */
	public static function register_hooks(): void {
		add_filter( 'admin_memory_limit', array( self::class, 'filter_admin_memory_limit' ) );
		add_filter( 'rest_pre_dispatch', array( self::class, 'filter_rest_pre_dispatch' ), 1, 3 );
		add_filter( 'divi_visual_builder_rest_before_save_post', array( self::class, 'filter_before_save_raise_memory' ), 0 );
	}

	/**
	 * Raise the WordPress admin memory cap for Divi Visual Builder syncs.
	 *
	 * @param mixed $limit Current filtered limit (string or int).
	 * @return mixed
	 */
	public static function filter_admin_memory_limit( $limit ) {
		if ( ! self::is_divi_vb_sync_request() ) {
			return $limit;
		}

		/**
		 * Filter PHP memory limit used during Divi Visual Builder `sync-to-server`.
		 *
		 * @param string $memory_limit Memory limit string (e.g. `512M`).
		 */
		$raised = apply_filters( 'dsm_vb_rest_save_memory_limit', self::DEFAULT_MEMORY_LIMIT );

		return is_string( $raised ) && '' !== $raised ? $raised : self::DEFAULT_MEMORY_LIMIT;
	}

	/**
	 * Capture the sync request and raise memory before Divi parses the body.
	 *
	 * @param mixed           $result  Dispatch result (null to continue).
	 * @param mixed           $server  REST server.
	 * @param WP_REST_Request $request Current request.
	 * @return mixed
	 */
	public static function filter_rest_pre_dispatch( $result, $server, $request ) {
		unset( $server );

		if ( ! $request instanceof WP_REST_Request || ! self::request_is_sync_to_server( $request ) ) {
			return $result;
		}

		self::$request = $request;
		self::raise_memory();
		self::hydrate_page_settings_from_request( $request );

		return $result;
	}

	/**
	 * Safety net when a VB save runs without `rest_pre_dispatch` (internal resave).
	 *
	 * @param mixed $value Filter value (abort payload or null).
	 * @return mixed
	 */
	public static function filter_before_save_raise_memory( $value ) {
		self::raise_memory();

		return $value;
	}

	/**
	 * Apply the admin memory limit for the current request.
	 *
	 * @return void
	 */
	public static function raise_memory(): void {
		if ( function_exists( 'wp_raise_memory_limit' ) ) {
			wp_raise_memory_limit( 'admin' );
		}
	}

	/**
	 * Slim payload compatible with extension `pageSettings` readers.
	 *
	 * @return array<string, mixed>
	 */
	public static function get_page_settings_payload(): array {
		$page_settings = self::get_page_settings();
		$by_layout     = self::get_page_settings_by_layout_post_content();
		$payload       = array();

		if ( array() !== $page_settings ) {
			$payload['pageSettings'] = $page_settings;
		}

		if ( array() !== $by_layout ) {
			$payload['pageSettingsByLayout'] = array(
				'postContent' => $by_layout,
			);
		}

		return $payload;
	}

	/**
	 * Unsanitized `pageSettings` object from the current VB sync request.
	 *
	 * @return array<string, mixed>
	 */
	public static function get_page_settings(): array {
		self::ensure_hydrated();

		return self::$page_settings;
	}

	/**
	 * Unsanitized `pageSettingsByLayout.postContent` from the current VB sync request.
	 *
	 * @return array<string, mixed>
	 */
	public static function get_page_settings_by_layout_post_content(): array {
		self::ensure_hydrated();

		return self::$page_settings_by_layout_post_content;
	}

	/**
	 * Whether the current HTTP request is Divi's Visual Builder sync.
	 *
	 * @return bool
	 */
	public static function is_divi_vb_sync_request(): bool {
		if ( self::$request instanceof WP_REST_Request ) {
			return self::request_is_sync_to_server( self::$request );
		}

		if ( empty( $_SERVER['REQUEST_URI'] ) || ! is_string( $_SERVER['REQUEST_URI'] ) ) { // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- path check only.
			return false;
		}

		$uri = sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) );

		return is_string( $uri ) && false !== strpos( $uri, '/divi/v1/sync-to-server' );
	}

	/**
	 * Whether a REST request is Divi's Visual Builder sync endpoint.
	 *
	 * @param WP_REST_Request $request REST request.
	 * @return bool
	 */
	private static function request_is_sync_to_server( WP_REST_Request $request ): bool {
		$route = $request->get_route();

		return is_string( $route ) && '/divi/v1/sync-to-server' === $route;
	}

	/**
	 * Extract slim page-settings slices if a sync request is already captured.
	 *
	 * @return void
	 */
	private static function ensure_hydrated(): void {
		if ( self::$hydrated || ! self::$request instanceof WP_REST_Request ) {
			return;
		}

		self::hydrate_page_settings_from_request( self::$request );
	}

	/**
	 * Decode only the top-level page-settings objects (never the layout `content`).
	 *
	 * @param WP_REST_Request $request Current sync request.
	 * @return void
	 */
	private static function hydrate_page_settings_from_request( WP_REST_Request $request ): void {
		if ( self::$hydrated ) {
			return;
		}

		self::$hydrated                             = true;
		self::$page_settings                        = array();
		self::$page_settings_by_layout_post_content = array();

		$raw = $request->get_body();
		if ( ! is_string( $raw ) || '' === $raw ) {
			return;
		}

		self::$page_settings = self::extract_top_level_object( $raw, 'pageSettings' );

		$by_layout = self::extract_top_level_object( $raw, 'pageSettingsByLayout' );
		if ( isset( $by_layout['postContent'] ) && is_array( $by_layout['postContent'] ) ) {
			self::$page_settings_by_layout_post_content = $by_layout['postContent'];
		}
	}

	/**
	 * Decode one top-level JSON object property without parsing the rest of the body.
	 *
	 * @param string $json Raw request body.
	 * @param string $key  Top-level property name.
	 * @return array<string, mixed>
	 */
	private static function extract_top_level_object( string $json, string $key ): array {
		$start = self::find_top_level_object_start( $json, $key );
		if ( null === $start ) {
			return array();
		}

		$slice = self::slice_json_object( $json, $start );
		if ( ! is_string( $slice ) || '' === $slice ) {
			return array();
		}

		$decoded = json_decode( $slice, true );

		return is_array( $decoded ) ? $decoded : array();
	}

	/**
	 * Byte offset of `{` for a top-level object property, or null when missing.
	 *
	 * @param string $json Raw request body.
	 * @param string $key  Top-level property name.
	 * @return int|null
	 */
	private static function find_top_level_object_start( string $json, string $key ): ?int {
		$length = strlen( $json );
		$index  = 0;

		while ( $index < $length && ctype_space( $json[ $index ] ) ) {
			++$index;
		}

		if ( $index >= $length || '{' !== $json[ $index ] ) {
			return null;
		}

		++$index;

		$in_string     = false;
		$escape        = false;
		$depth         = 1;
		$expecting_key = true;
		$key_start     = null;

		for ( ; $index < $length; $index++ ) {
			$character = $json[ $index ];

			if ( $in_string ) {
				if ( $escape ) {
					$escape = false;
					continue;
				}

				if ( '\\' === $character ) {
					$escape = true;
					continue;
				}

				if ( '"' === $character ) {
					$in_string = false;

					if ( 1 === $depth && $expecting_key && null !== $key_start ) {
						$found_key = substr( $json, $key_start + 1, $index - $key_start - 1 );
						if ( $found_key === $key ) {
							$cursor = $index + 1;
							while ( $cursor < $length && ctype_space( $json[ $cursor ] ) ) {
								++$cursor;
							}

							if ( $cursor < $length && ':' === $json[ $cursor ] ) {
								++$cursor;
								while ( $cursor < $length && ctype_space( $json[ $cursor ] ) ) {
									++$cursor;
								}

								if ( $cursor < $length && '{' === $json[ $cursor ] ) {
									return $cursor;
								}
							}
						}

						$expecting_key = false;
						$key_start     = null;
					}
				}

				continue;
			}

			if ( '"' === $character ) {
				$in_string = true;
				if ( 1 === $depth && $expecting_key ) {
					$key_start = $index;
				}
				continue;
			}

			if ( '{' === $character || '[' === $character ) {
				++$depth;
				continue;
			}

			if ( '}' === $character || ']' === $character ) {
				--$depth;
				if ( 0 === $depth ) {
					return null;
				}
				continue;
			}

			if ( 1 === $depth && ',' === $character ) {
				$expecting_key = true;
			}
		}

		return null;
	}

	/**
	 * Return the JSON object starting at `$start` (inclusive).
	 *
	 * @param string $json  Raw JSON.
	 * @param int    $start Offset of the opening `{`.
	 * @return string|null
	 */
	private static function slice_json_object( string $json, int $start ): ?string {
		if ( ! isset( $json[ $start ] ) || '{' !== $json[ $start ] ) {
			return null;
		}

		$length    = strlen( $json );
		$depth     = 0;
		$in_string = false;
		$escape    = false;

		for ( $index = $start; $index < $length; $index++ ) {
			$character = $json[ $index ];

			if ( $in_string ) {
				if ( $escape ) {
					$escape = false;
					continue;
				}

				if ( '\\' === $character ) {
					$escape = true;
					continue;
				}

				if ( '"' === $character ) {
					$in_string = false;
				}

				continue;
			}

			if ( '"' === $character ) {
				$in_string = true;
				continue;
			}

			if ( '{' === $character ) {
				++$depth;
				continue;
			}

			if ( '}' === $character ) {
				--$depth;
				if ( 0 === $depth ) {
					return substr( $json, $start, $index - $start + 1 );
				}
			}
		}

		return null;
	}
}
