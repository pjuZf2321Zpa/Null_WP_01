<?php
/**
 * Result of legacy shortcode-module → native DSM conversion.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Includes\Divi5Conversion;

/**
 * Value object returned by {@see LegacyShortcodeConversionService}.
 */
final class LegacyShortcodeConversionResult {


	/**
	 * Content.
	 *
	 * @var string
	 */
	public $content;

	/**
	 * Changed.
	 *
	 * @var bool
	 */
	public $changed;

	/**
	 * Legacy before.
	 *
	 * @var int
	 */
	public $legacy_before;

	/**
	 * Legacy after.
	 *
	 * @var int
	 */
	public $legacy_after;

	/**
	 * Module errors.
	 *
	 * @var array<int, array<string, mixed>>
	 */
	public $module_errors;

	/**
	 * Fatal error.
	 *
	 * @var string|null
	 */
	public $fatal_error;

	/**
	 * Set up the instance.
	 *
	 * @param string                           $content       Converted (or original) post content.
	 * @param bool                             $changed       True when content string differs from input.
	 * @param int                              $legacy_before Count of `divi/shortcode-module` before conversion.
	 * @param int                              $legacy_after  Count after conversion.
	 * @param array<int, array<string, mixed>> $module_errors  Per-module failures (index, message, shortcode snippet).
	 * @param string|null                      $fatal_error   Whole-content failure message when fast path aborted.
	 */
	public function __construct(
		string $content,
		bool $changed,
		int $legacy_before,
		int $legacy_after,
		array $module_errors = array(),
		?string $fatal_error = null
	) {
		$this->content       = $content;
		$this->changed       = $changed;
		$this->legacy_before = $legacy_before;
		$this->legacy_after  = $legacy_after;
		$this->module_errors = $module_errors;
		$this->fatal_error   = $fatal_error;
	}

	/**
	 * Whether any legacy shortcode-module blocks remain.
	 */
	public function has_remaining_legacy(): bool {
		return $this->legacy_after > 0;
	}

	/**
	 * Whether conversion reduced the legacy block count.
	 */
	public function made_progress(): bool {
		return $this->legacy_after < $this->legacy_before;
	}

	/**
	 * To array.
	 *
	 * @return array<string, mixed>
	 */
	public function to_array(): array {
		return array(
			'changed'       => $this->changed,
			'legacy_before' => $this->legacy_before,
			'legacy_after'  => $this->legacy_after,
			'module_errors' => $this->module_errors,
			'fatal_error'   => $this->fatal_error,
			'has_remaining' => $this->has_remaining_legacy(),
		);
	}
}
