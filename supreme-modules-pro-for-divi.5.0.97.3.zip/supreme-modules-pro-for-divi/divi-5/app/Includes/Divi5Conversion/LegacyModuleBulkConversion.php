<?php
/**
 * Site-wide scan and batched re-save of layouts with legacy `divi/shortcode-module` content.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Includes\Divi5Conversion;

/**
 * Bulk Visual Builder re-save for legacy Supreme modules (shared by admin AJAX and WP-CLI).
 */
final class LegacyModuleBulkConversion {


	public const JOB_OPTION_KEY = 'dsm_legacy_conversion_job';

	public const AJAX_NONCE_ACTION = 'dsm_legacy_conversion';

	public const DEFAULT_BATCH_SIZE = 5;

	/**
	 * Post types scanned for legacy Supreme shortcode-module blocks.
	 *
	 * @return array<int, string>
	 */
	public static function get_scannable_post_types(): array {
		$types = array( 'page', 'post', 'et_pb_layout' );

		$public = get_post_types(
			array(
				'public'  => true,
				'show_ui' => true,
			),
			'names'
		);

		if ( is_array( $public ) ) {
			foreach ( $public as $name ) {
				if ( is_string( $name ) && ! in_array( $name, $types, true ) ) {
					$types[] = $name;
				}
			}
		}

		/**
		 * Post types included in Supreme legacy module bulk conversion scans.
		 *
		 * @param array<int, string> $types Post type slugs.
		 */
		return array_values( array_unique( apply_filters( 'dsm_legacy_conversion_post_types', $types ) ) );
	}

	/**
	 * Scan layouts that contain Supreme modules needing legacy conversion or builder re-save.
	 *
	 * Total: int,
	 * by_type: array<string, int>,
	 * by_reason: array<string, int>,
	 * items: array<int, array{id: int, title: string, post_type: string, edit_url: string, reason: string}>
	 * }
	 *
	 * @return array{
	 */
	public static function scan(): array {
		global $wpdb;

		$post_types = self::get_scannable_post_types();

		if ( array() === $post_types ) {
			return array(
				'total'     => 0,
				'by_type'   => array(),
				'by_reason' => array(),
				'items'     => array(),
			);
		}

		$placeholders = implode( ', ', array_fill( 0, count( $post_types ), '%s' ) );
		$statuses     = array( 'publish', 'draft', 'private', 'pending', 'future' );
		$stat_place   = implode( ', ', array_fill( 0, count( $statuses ), '%s' ) );

		$sql = "
			SELECT ID, post_title, post_type, post_content
			FROM {$wpdb->posts}
			WHERE post_type IN ({$placeholders})
			AND post_status IN ({$stat_place})
			AND (
				(
					post_content LIKE %s
					AND (
						post_content LIKE %s
						OR post_content LIKE %s
					)
				)
				OR post_content LIKE %s
				OR (
					post_content LIKE %s
					AND (
						post_content LIKE %s
						OR post_content LIKE %s
					)
				)
				OR (
					post_content LIKE %s
					AND post_content LIKE %s
				)
			)
			ORDER BY post_type ASC, post_title ASC
		";

		$prepare_args = array_merge(
			$post_types,
			$statuses,
			array(
				'%' . $wpdb->esc_like( 'divi/shortcode-module' ) . '%',
				'%' . $wpdb->esc_like( '[dsm_' ) . '%',
				'%' . $wpdb->esc_like( '"shortcodeName":"dsm_' ) . '%',
				'%' . $wpdb->esc_like( 'wp:dsm/' ) . '%',
				'%' . $wpdb->esc_like( '[dsm_' ) . '%',
				'%' . $wpdb->esc_like( '[_et_pb_' ) . '%',
				'%' . $wpdb->esc_like( '<!-- wp:' ) . '%',
				// Pure D4 shortcode trees that still contain Supreme modules.
				'%' . $wpdb->esc_like( '[dsm_' ) . '%',
				'%' . $wpdb->esc_like( '[et_pb_' ) . '%',
			)
		);

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- placeholders built from trusted post type list.
		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $prepare_args ) );

		$items     = array();
		$by_type   = array();
		$by_reason = array();

		if ( is_array( $rows ) ) {
			foreach ( $rows as $row ) {
				$id      = (int) $row->ID;
				$content = LegacyShortcodeConversionService::prepare_stored_layout_content( (string) ( $row->post_content ?? '' ) );
				$reason  = LegacyShortcodeConversionService::get_resave_reason( $content );

				if ( null === $reason ) {
					continue;
				}

				$post_type = (string) $row->post_type;
				$title     = (string) $row->post_title;

				if ( '' === trim( $title ) ) {
					$title = sprintf(
						/* translators: %d: post ID */
						__( '(no title) — #%d', 'dsm-supreme-modules-pro-for-divi' ),
						$id
					);
				}

				$items[] = array(
					'id'        => $id,
					'title'     => $title,
					'post_type' => $post_type,
					'edit_url'  => (string) get_edit_post_link( $id, 'raw' ),
					'reason'    => $reason,
				);

				if ( ! isset( $by_type[ $post_type ] ) ) {
					$by_type[ $post_type ] = 0;
				}

				++$by_type[ $post_type ];

				if ( ! isset( $by_reason[ $reason ] ) ) {
					$by_reason[ $reason ] = 0;
				}

				++$by_reason[ $reason ];
			}
		}

		return array(
			'total'     => count( $items ),
			'by_type'   => $by_type,
			'by_reason' => $by_reason,
			'items'     => $items,
		);
	}

	/**
	 * Start or replace a conversion job in the options table.
	 *
	 * @param bool            $dry_run      When true, batches report targets but do not persist.
	 * @param array<int, int> $selected_ids Optional post IDs to re-save; empty means all scan results.
	 * @return array<string, mixed>
	 */
	public static function start_job( bool $dry_run = false, array $selected_ids = array() ): array {
		$scan  = self::scan();
		$items = self::filter_scan_items( $scan['items'], $selected_ids );

		$job = array(
			'status'        => 'running',
			'dry_run'       => $dry_run,
			'started_at'    => time(),
			'queue'         => $items,
			'offset'        => 0,
			'total'         => count( $items ),
			'processed'     => 0,
			'converted'     => 0,
			'skipped'       => 0,
			'failed'        => array(),
			'by_type'       => self::summarize_items_by_type( $items ),
			'current'       => null,
			'cancelled'     => false,
			'selected_only' => array() !== $selected_ids,
		);

		update_option( self::JOB_OPTION_KEY, $job, false );

		return $job;
	}

	/**
	 * Restrict scan items to an explicit ID list (validated against the latest scan).
	 *
	 * @param array<int, array{id: int, title: string, post_type: string, edit_url?: string}> $items Items.
	 * @param array<int, int>                                                                 $selected_ids Selected ids.
	 * @return array<int, array{id: int, title: string, post_type: string, edit_url?: string}>
	 */
	public static function filter_scan_items( array $items, array $selected_ids ): array {
		if ( array() === $selected_ids ) {
			return $items;
		}

		$allowed = array();

		foreach ( $selected_ids as $selected_id ) {
			$selected_id = absint( $selected_id );

			if ( $selected_id > 0 ) {
				$allowed[ $selected_id ] = true;
			}
		}

		if ( array() === $allowed ) {
			return array();
		}

		$filtered = array();

		foreach ( $items as $item ) {
			if ( ! is_array( $item ) || empty( $item['id'] ) ) {
				continue;
			}

			$id = (int) $item['id'];

			if ( isset( $allowed[ $id ] ) ) {
				$filtered[] = $item;
			}
		}

		return $filtered;
	}

	/**
	 * Summarize items by type.
	 *
	 * @param array<int, array{id: int, title: string, post_type: string, edit_url?: string}> $items Items.
	 * @return array<string, int>
	 */
	public static function summarize_items_by_type( array $items ): array {
		$by_type = array();

		foreach ( $items as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}

			$post_type = (string) ( $item['post_type'] ?? '' );

			if ( '' === $post_type ) {
				continue;
			}

			if ( ! isset( $by_type[ $post_type ] ) ) {
				$by_type[ $post_type ] = 0;
			}

			++$by_type[ $post_type ];
		}

		return $by_type;
	}

	/**
	 * Whether the current request included a `selected_ids` payload.
	 */
	public static function selected_ids_sent_in_request(): bool {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Caller verifies nonce before invoking.
		return isset( $_POST['selected_ids'] );
	}

	/**
	 * Parse selected post IDs from an admin AJAX request payload.
	 *
	 * @return array<int, int>
	 */
	public static function parse_selected_ids_from_request(): array {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Caller verifies nonce before invoking.
		if ( ! isset( $_POST['selected_ids'] ) ) {
			return array();
		}

		$raw = sanitize_text_field( wp_unslash( (string) $_POST['selected_ids'] ) );
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		if ( '' === $raw ) {
			return array();
		}

		$decoded = json_decode( $raw, true );

		if ( ! is_array( $decoded ) ) {
			return array();
		}

		return array_values( array_filter( array_map( 'absint', $decoded ) ) );
	}

	/**
	 * Get job.
	 *
	 * @return array<string, mixed>|null
	 */
	public static function get_job(): ?array {
		$job = get_option( self::JOB_OPTION_KEY, null );

		return is_array( $job ) ? $job : null;
	}

	/**
	 * Clear job.
	 *
	 * @return void
	 */
	public static function clear_job(): void {
		delete_option( self::JOB_OPTION_KEY );
	}

	/**
	 * Mark the active job as cancelled.
	 */
	public static function cancel_job(): ?array {
		$job = self::get_job();

		if ( null === $job ) {
			return null;
		}

		$job['status']    = 'cancelled';
		$job['cancelled'] = true;

		update_option( self::JOB_OPTION_KEY, $job, false );

		return $job;
	}

	/**
	 * Process the next batch of queued posts.
	 *
	 * @param int $batch_size Number of posts per batch.
	 * @return array<string, mixed>
	 */
	public static function process_batch( int $batch_size = self::DEFAULT_BATCH_SIZE ): array {
		$job = self::get_job();

		if ( null === $job ) {
			return array(
				'error' => __( 'No conversion job is in progress.', 'dsm-supreme-modules-pro-for-divi' ),
			);
		}

		if ( ! empty( $job['cancelled'] ) ) {
			$job['status'] = 'cancelled';
			update_option( self::JOB_OPTION_KEY, $job, false );

			return $job;
		}

		$queue   = isset( $job['queue'] ) && is_array( $job['queue'] ) ? $job['queue'] : array();
		$offset  = isset( $job['offset'] ) ? (int) $job['offset'] : 0;
		$dry_run = ! empty( $job['dry_run'] );
		$slice   = array_slice( $queue, $offset, max( 1, $batch_size ) );

		if ( array() === $slice ) {
			$job['status']  = 'complete';
			$job['current'] = null;
			update_option( self::JOB_OPTION_KEY, $job, false );

			return $job;
		}

		try {
			LegacyShortcodeConversionService::bootstrap_divi_for_conversion();
		} catch ( \Throwable $exception ) {
			return array(
				'error'  => $exception->getMessage(),
				'status' => 'error',
			);
		}

		foreach ( $slice as $item ) {
			if ( ! is_array( $item ) || empty( $item['id'] ) ) {
				++$job['processed'];
				continue;
			}

			$post_id        = (int) $item['id'];
			$job['current'] = array(
				'id'        => $post_id,
				'title'     => (string) ( $item['title'] ?? '' ),
				'post_type' => (string) ( $item['post_type'] ?? '' ),
			);

			$result = self::convert_single_post( $post_id, $dry_run );

			if ( ! empty( $result['skipped'] ) ) {
				++$job['skipped'];
			} elseif ( ! empty( $result['success'] ) ) {
				++$job['converted'];
			} else {
				$job['failed'][] = array(
					'id'        => $post_id,
					'title'     => (string) ( $item['title'] ?? '' ),
					'post_type' => (string) ( $item['post_type'] ?? '' ),
					'edit_url'  => get_edit_post_link( $post_id, 'raw' ),
					'message'   => (string) ( $result['message'] ?? __( 'Unknown error.', 'dsm-supreme-modules-pro-for-divi' ) ),
				);
			}

			++$job['processed'];
			++$job['offset'];

			update_option( self::JOB_OPTION_KEY, $job, false );
		}

		if ( $job['offset'] >= count( $queue ) ) {
			$job['status']  = 'complete';
			$job['current'] = null;
		} else {
			$job['status'] = 'running';
		}

		update_option( self::JOB_OPTION_KEY, $job, false );

		return $job;
	}

	/**
	 * Re-save one post through Divi's Visual Builder save pipeline.
	 *
	 * @param int  $post_id Post id.
	 * @param bool $dry_run Dry run.
	 * @return array<string, mixed>
	 */
	public static function convert_single_post( int $post_id, bool $dry_run = false ): array {
		return DiviVisualBuilderResaveService::resave_post( $post_id, $dry_run );
	}

	/**
	 * Run the full queue synchronously (WP-CLI).
	 *
	 * @param bool            $dry_run      Dry run flag.
	 * @param int             $batch_size   Batch size.
	 * @param array<int, int> $selected_ids Optional post IDs to re-save; empty means all scan results.
	 * @return array<string, mixed> Final job state.
	 */
	public static function run_all( bool $dry_run = false, int $batch_size = self::DEFAULT_BATCH_SIZE, array $selected_ids = array() ): array {
		self::start_job( $dry_run, $selected_ids );

		$job = self::get_job();

		while ( is_array( $job ) && 'running' === ( $job['status'] ?? '' ) ) {
			$job = self::process_batch( $batch_size );
		}

		return is_array( $job ) ? $job : array();
	}
}
