<?php
/**
 * Import / VB load: convert legacy `dsm_filterable_gallery` shortcodes and normalize block attrs.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Includes\Divi5Conversion;

use ET\Builder\Packages\Conversion\Conversion;

/**
 * Portability and raw post load normalization for `dsm/filterable-gallery`.
 */
final class FilterableGalleryImportMigrator {

	/**
	 * Register content filters.
	 *
	 * @return void
	 */
	public static function register(): void {

		add_filter(
			'divi_framework_portability_import_migrated_post_content',
			array( self::class, 'migrate_import_content' ),
			20,
			2
		);

		add_filter(
			'et_fb_load_raw_post_content',
			array( self::class, 'migrate_import_content' ),
			20,
			2
		);
	}

	/**
	 * Convert an unmigrated shortcode, then normalize gallery blocks in place.
	 *
	 * Already-saved gallery blocks are rewritten only when their attrs change.
	 * The rest of the layout, including component `localAttrs`, is left as stored.
	 *
	 * @param string   $content Post content (block markup or shortcodes).
	 * @param int|null $post_id Optional post ID.
	 * @return string
	 */
	public static function migrate_import_content( $content, $post_id = null ) {
		if ( ! is_string( $content ) || '' === $content ) {
			return $content;
		}

		$has_shortcode = false !== strpos( $content, '[dsm_filterable_gallery' );
		$has_block     = false !== strpos( $content, 'dsm/filterable-gallery' );

		if ( ! $has_shortcode && ! $has_block ) {
			return $content;
		}

		ConversionOutlineBootstrap::ensure_conversion_maps();

		if ( $has_shortcode && class_exists( Conversion::class ) ) {
			$content   = Conversion::maybeConvertContent(
				$content,
				true,
				is_numeric( $post_id ) ? (int) $post_id : null
			);
			$has_block = false !== strpos( $content, 'dsm/filterable-gallery' );
		}

		if ( $has_block && function_exists( 'parse_blocks' ) && function_exists( 'serialize_blocks' ) ) {
			$content = self::replace_gallery_blocks( $content );
		}

		return $content;
	}

	/**
	 * Normalize filterable-gallery blocks without rewriting neighboring modules.
	 *
	 * A full-page serialize_blocks() turns a component snapshot `localAttrs: {}`
	 * into `localAttrs: []`. Only a gallery block whose attrs change is replaced.
	 *
	 * @param string $content Post content (block markup).
	 * @return string
	 */
	private static function replace_gallery_blocks( string $content ): string {
		$offset = 0;
		$needle = '<!-- wp:dsm/filterable-gallery';

		while ( true ) {
			$start = strpos( $content, $needle, $offset );
			if ( false === $start ) {
				break;
			}
			$region = self::extract_block_markup( $content, $start, 'dsm/filterable-gallery' );
			if ( null === $region ) {
				$offset = $start + strlen( $needle );
				continue;
			}

			$raw    = substr( $content, $region['start'], $region['length'] );
			$merged = self::normalize_one_block_markup( $raw );
			if ( null === $merged || $merged === $raw ) {
				$offset = $region['start'] + $region['length'];
				continue;
			}

			$content = substr( $content, 0, $region['start'] ) . $merged . substr( $content, $region['start'] + $region['length'] );
			$offset  = $region['start'] + strlen( $merged );
		}

		return $content;
	}

	/**
	 * Byte range of one block that opens at $start.
	 *
	 * @param string $content    Full layout markup.
	 * @param int    $start      Offset of the opening comment.
	 * @param string $block_name Block name without the wp: prefix.
	 * @return array{start: int, length: int}|null
	 */
	private static function extract_block_markup( string $content, int $start, string $block_name ): ?array {
		$length   = strlen( $content );
		$open     = '<!-- wp:' . $block_name;
		$name_end = $start + strlen( $open );
		$after    = $name_end < $length ? $content[ $name_end ] : '';
		if ( '' !== $after && ' ' !== $after && '/' !== $after && '>' !== $after ) {
			return null;
		}

		$opener_end = strpos( $content, '-->', $start );
		if ( false === $opener_end ) {
			return null;
		}

		$opener = substr( $content, $start, ( $opener_end + 3 ) - $start );
		if ( preg_match( '/\/-->\s*$/', $opener ) ) {
			return array(
				'start'  => $start,
				'length' => ( $opener_end + 3 ) - $start,
			);
		}

		$depth  = 1;
		$cursor = $opener_end + 3;
		$close  = '<!-- /wp:' . $block_name;

		while ( $depth > 0 && $cursor < $length ) {
			$next_open  = strpos( $content, $open, $cursor );
			$next_close = strpos( $content, $close, $cursor );
			if ( false === $next_close ) {
				return null;
			}

			if ( false !== $next_open && $next_open < $next_close ) {
				$after_name = $next_open + strlen( $open );
				$next_char  = $after_name < $length ? $content[ $after_name ] : '';
				if ( '' !== $next_char && ' ' !== $next_char && '/' !== $next_char && '>' !== $next_char ) {
					$cursor = $after_name;
					continue;
				}
				++$depth;
				$cursor = $after_name;
				continue;
			}

			$close_end = strpos( $content, '-->', $next_close );
			if ( false === $close_end ) {
				return null;
			}
			--$depth;
			$cursor = $close_end + 3;
		}

		if ( 0 !== $depth ) {
			return null;
		}

		return array(
			'start'  => $start,
			'length' => $cursor - $start,
		);
	}

	/**
	 * Normalize one filterable-gallery block when its attrs are still legacy.
	 *
	 * @param string $markup One filterable-gallery block.
	 * @return string|null Replacement markup, or null when the attrs are already normalized.
	 */
	private static function normalize_one_block_markup( string $markup ): ?string {
		$blocks = self::strip_empty_parsed_blocks( parse_blocks( $markup ) );
		if ( 1 !== count( $blocks ) || 'dsm/filterable-gallery' !== ( $blocks[0]['blockName'] ?? '' ) ) {
			return null;
		}

		$attrs = isset( $blocks[0]['attrs'] ) && is_array( $blocks[0]['attrs'] ) ? $blocks[0]['attrs'] : array();
		$next  = FilterableGalleryConversion::normalize_block_attrs( $attrs );
		if ( $next === $attrs ) {
			return null;
		}

		$blocks[0]['attrs'] = $next;

		return serialize_blocks( $blocks );
	}

	/**
	 * Drop the empty trailing block parse_blocks() appends.
	 *
	 * @param array<int, array<string, mixed>> $blocks Parsed blocks.
	 * @return array<int, array<string, mixed>>
	 */
	private static function strip_empty_parsed_blocks( array $blocks ): array {
		$out = array();
		foreach ( $blocks as $block ) {
			if ( ! is_array( $block ) ) {
				continue;
			}
			$name = $block['blockName'] ?? null;
			$html = isset( $block['innerHTML'] ) && is_string( $block['innerHTML'] ) ? trim( $block['innerHTML'] ) : '';
			if ( null === $name && '' === $html ) {
				continue;
			}
			$out[] = $block;
		}

		return $out;
	}
}
