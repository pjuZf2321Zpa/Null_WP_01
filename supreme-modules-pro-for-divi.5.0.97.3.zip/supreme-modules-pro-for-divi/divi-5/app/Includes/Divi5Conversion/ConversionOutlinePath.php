<?php
/**
 * Resolves conversion-outline.json path for dsm/* modules.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Includes\Divi5Conversion;

/**
 * Filter callback for divi.moduleLibrary.conversion.moduleConversionOutlineFile.
 */
final class ConversionOutlinePath {


	/**
	 * Map D5 module slug folder name → filesystem folder under module-library (when they differ).
	 *
	 * @var array<string, string>
	 */
	private const DIRNAME_TO_SLUG_MAP = array(
		'button'              => 'buttons',
		'flipbox'             => 'flipbox-perk',
		'before-after-image'  => 'before-after-slider',
		'image-text-reveal'   => 'image-reveal',
		'image-hotspot'       => 'image-hotspots',
		'image-hotspot-child' => 'image-hotspots-child',
	);

	/**
	 * Filter.
	 *
	 * @param string $conversion_outline_file Default path from Divi.
	 * @param string $module_name             Module name (e.g. dsm/blob-image).
	 * @return string
	 */
	public static function filter( $conversion_outline_file, $module_name ) {
		if ( ! str_starts_with( $module_name, 'dsm/' ) ) {
			return $conversion_outline_file;
		}

		$dsm_module_name = str_replace( 'dsm/', '', $module_name );

		if ( isset( self::DIRNAME_TO_SLUG_MAP[ $dsm_module_name ] ) ) {
			$dsm_module_name = self::DIRNAME_TO_SLUG_MAP[ $dsm_module_name ];
		}

		return DSM_DIR_PATH . 'divi-5/public/packages/module-library/' . $dsm_module_name . '/conversion-outline.json';
	}
}
