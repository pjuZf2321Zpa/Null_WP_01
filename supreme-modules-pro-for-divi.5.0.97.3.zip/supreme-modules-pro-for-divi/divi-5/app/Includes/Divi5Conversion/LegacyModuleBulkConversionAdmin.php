<?php
/**
 * Admin AJAX endpoints for bulk legacy module conversion.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Includes\Divi5Conversion;

use Throwable;

/**
 * Browser-driven batch runner for {@see LegacyModuleBulkConversion}.
 */
final class LegacyModuleBulkConversionAdmin {


	/**
	 * Register.
	 *
	 * @return void
	 */
	public static function register(): void {
		add_action( 'plugins_loaded', array( self::class, 'enable_divi_framework_for_legacy_conversion_ajax' ), 0 );

		add_action( 'wp_ajax_dsm_legacy_conversion_scan', array( self::class, 'ajax_scan' ) );
		add_action( 'wp_ajax_dsm_legacy_conversion_start', array( self::class, 'ajax_start' ) );
		add_action( 'wp_ajax_dsm_legacy_conversion_batch', array( self::class, 'ajax_batch' ) );
		add_action( 'wp_ajax_dsm_legacy_conversion_status', array( self::class, 'ajax_status' ) );
		add_action( 'wp_ajax_dsm_legacy_conversion_cancel', array( self::class, 'ajax_cancel' ) );
		add_action( 'wp_ajax_dsm_legacy_conversion_reset', array( self::class, 'ajax_reset' ) );
	}

	/**
	 * AJAX scan.
	 *
	 * @return void
	 */
	public static function ajax_scan(): void {
		self::run_ajax(
			static function (): void {
				wp_send_json_success( LegacyModuleBulkConversion::scan() );
			}
		);
	}

	/**
	 * AJAX start.
	 *
	 * @return void
	 */
	public static function ajax_start(): void {
		self::run_ajax(
			static function (): void {
				// phpcs:disable WordPress.Security.NonceVerification.Missing -- Verified in run_ajax() via check_ajax_referer().
				$dry_run      = ! empty( $_POST['dry_run'] );
				$selected_ids = LegacyModuleBulkConversion::parse_selected_ids_from_request();
				// phpcs:enable WordPress.Security.NonceVerification.Missing

				if (
					LegacyModuleBulkConversion::selected_ids_sent_in_request()
					&& array() === $selected_ids
				) {
					wp_send_json_error(
						array(
							'message' => __( 'Select at least one item to re-save.', 'dsm-supreme-modules-pro-for-divi' ),
						),
						400
					);
				}

				wp_send_json_success( LegacyModuleBulkConversion::start_job( $dry_run, $selected_ids ) );
			}
		);
	}

	/**
	 * AJAX batch.
	 *
	 * @return void
	 */
	public static function ajax_batch(): void {
		self::run_ajax(
			static function (): void {
				// phpcs:disable WordPress.Security.NonceVerification.Missing -- Verified in run_ajax() via check_ajax_referer().
				$batch_size = isset( $_POST['batch_size'] ) ? absint( $_POST['batch_size'] ) : LegacyModuleBulkConversion::DEFAULT_BATCH_SIZE;
				// phpcs:enable WordPress.Security.NonceVerification.Missing
				$batch_size = max( 1, min( 20, $batch_size ) );

				$job = LegacyModuleBulkConversion::process_batch( $batch_size );

				if ( isset( $job['error'] ) ) {
					wp_send_json_error( $job );
				}

				wp_send_json_success( $job );
			}
		);
	}

	/**
	 * AJAX status.
	 *
	 * @return void
	 */
	public static function ajax_status(): void {
		self::run_ajax(
			static function (): void {
				wp_send_json_success(
					array(
						'job' => LegacyModuleBulkConversion::get_job(),
					)
				);
			}
		);
	}

	/**
	 * AJAX cancel.
	 *
	 * @return void
	 */
	public static function ajax_cancel(): void {
		self::run_ajax(
			static function (): void {
				wp_send_json_success(
					array(
						'job' => LegacyModuleBulkConversion::cancel_job(),
					)
				);
			}
		);
	}

	/**
	 * AJAX reset.
	 *
	 * @return void
	 */
	public static function ajax_reset(): void {
		self::run_ajax(
			static function (): void {
				LegacyModuleBulkConversion::clear_job();

				wp_send_json_success( array( 'cleared' => true ) );
			}
		);
	}

	/**
	 * Ensure Divi builder + shortcode framework load before our batch AJAX runs.
	 *
	 * Must run on `plugins_loaded` (before theme `after_setup_theme` / builder bootstrap).
	 *
	 * @return void
	 */
	public static function enable_divi_framework_for_legacy_conversion_ajax(): void {
		if ( ! wp_doing_ajax() ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Early bootstrap only; nonce verified in run_ajax().
		$action = isset( $_REQUEST['action'] ) ? sanitize_text_field( wp_unslash( (string) $_REQUEST['action'] ) ) : '';

		if ( 'dsm_legacy_conversion_batch' !== $action ) {
			return;
		}

		add_filter( 'et_builder_should_load_framework', '__return_true', 99999 );
		add_filter( 'et_should_load_shortcode_framework', '__return_true', 99999 );
	}

	/**
	 * Run AJAX.
	 *
	 * @param callable $callback Handler that calls wp_send_json_*.
	 * @return void
	 */
	private static function run_ajax( callable $callback ): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error(
				array(
					'message' => __( 'You do not have permission to run this tool.', 'dsm-supreme-modules-pro-for-divi' ),
				),
				403
			);
		}

		check_ajax_referer( LegacyModuleBulkConversion::AJAX_NONCE_ACTION, 'nonce' );

		$ob_level = ob_get_level();
		ob_start();

		try {
			$callback();
		} catch ( Throwable $exception ) {
			while ( ob_get_level() > $ob_level ) {
				ob_end_clean();
			}

			wp_send_json_error(
				array(
					'message' => $exception->getMessage(),
				),
				500
			);
		}

		// Handler must call wp_send_json_* (which exits). Discard stray output if not.
		$buffer = ob_get_clean();

		if ( is_string( $buffer ) && '' !== trim( $buffer ) ) {
			wp_send_json_error(
				array(
					'message' => __( 'Unexpected output during conversion request.', 'dsm-supreme-modules-pro-for-divi' ),
					'detail'  => wp_strip_all_tags( substr( $buffer, 0, 500 ) ),
				),
				500
			);
		}
	}
}
