<?php
/**
 * Persists D4 legacy `divi/shortcode-module` → native `dsm/*` conversion when a layout is saved.
 *
 * Divi's Visual Builder converts nonconvertible blocks in memory on load
 * ({@see \ET\Builder\Packages\Conversion\Utils\ConversionUtils}) but a normal VB save
 * can still write `divi/shortcode-module` to `post_content`. The frontend renders
 * stored blocks (D4 shortcode path), not the in-memory VB tree — so the canvas can
 * look native while the live page stays legacy.
 *
 * Conversion runs only during {@see divi_visual_builder_rest_before_save_post} …
 * {@see divi_visual_builder_rest_save_post} (VB REST save), and only when the payload
 * still contains `divi/shortcode-module` inside a D5 `<!-- wp:divi/` layout.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Includes\Divi5Conversion;

/**
 * Runs legacy conversion on save via {@see LegacyShortcodeConversionService}.
 */
final class PersistShortcodeModuleConversionOnSave {


	/**
	 * True only while a Divi Visual Builder REST save is in progress (main post + Theme Builder layouts).
	 *
	 * @var bool
	 */
	private static bool $is_vb_rest_save = false;

	/**
	 * Register.
	 *
	 * @return void
	 */
	public static function register(): void {
		LegacyShortcodeConversionService::register_hooks();

		add_action( 'divi_visual_builder_rest_before_save_post', array( self::class, 'mark_vb_rest_save_started' ), 1 );
		add_action( 'divi_visual_builder_rest_save_post', array( self::class, 'mark_vb_rest_save_finished' ), 999 );
		add_filter( 'wp_insert_post_data', array( self::class, 'filter_post_data' ), 20, 2 );
	}

	/**
	 * Mark vb rest save started.
	 *
	 * @return void
	 */
	public static function mark_vb_rest_save_started(): void {
		self::$is_vb_rest_save = true;
	}

	/**
	 * Mark vb rest save finished.
	 *
	 * @return void
	 */
	public static function mark_vb_rest_save_finished(): void {
		self::$is_vb_rest_save = false;
	}

	/**
	 * Replace remaining `divi/shortcode-module` blocks with native D5 blocks before DB write.
	 *
	 * @param array<string, mixed> $data     Slashed post data for insert/update.
	 * @param array<string, mixed> $postarr  Raw post data.
	 * @return array<string, mixed>
	 */
	public static function filter_post_data( array $data, array $postarr ): array {
		if ( ! self::$is_vb_rest_save ) {
			return $data;
		}

		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return $data;
		}

		if ( ! isset( $data['post_content'] ) || ! is_string( $data['post_content'] ) ) {
			return $data;
		}

		// wp_insert_post_data receives slashed content. Unslash once, then restore
		// JSON hex escapes that were already missing their backslash.
		$unslashed = wp_unslash( $data['post_content'] );
		$raw       = LegacyShortcodeConversionService::prepare_stored_layout_content( $unslashed );
		$post_id   = isset( $postarr['ID'] ) ? (int) $postarr['ID'] : 0;

		if ( ! LegacyShortcodeConversionService::content_needs_legacy_conversion( $raw ) ) {
			if ( $raw !== $unslashed ) {
				$data['post_content'] = wp_slash( $raw );
			}

			return $data;
		}

		$result = LegacyShortcodeConversionService::convert_content(
			$raw,
			$post_id > 0 ? $post_id : null
		);

		if ( ! $result->made_progress() && ! $result->changed ) {
			if ( $raw !== $unslashed ) {
				$data['post_content'] = wp_slash( $raw );
			}

			return $data;
		}

		if ( array() !== $result->module_errors ) {
			self::log_module_errors( $post_id, $result->module_errors );
		}

		if ( null !== $result->fatal_error ) {
			self::log_event(
				$post_id,
				sprintf(
					'Legacy conversion fast path failed; fault-tolerant path used. %s',
					$result->fatal_error
				)
			);
		}

		$data['post_content'] = wp_slash(
			LegacyShortcodeConversionService::prepare_stored_layout_content( $result->content )
		);

		return $data;
	}

	/**
	 * Log module errors.
	 *
	 * @param int                              $post_id       Post ID.
	 * @param array<int, array<string, mixed>> $module_errors Module-level failures.
	 */
	private static function log_module_errors( int $post_id, array $module_errors ): void {
		foreach ( $module_errors as $error ) {
			$message   = isset( $error['message'] ) ? (string) $error['message'] : 'Unknown error';
			$shortcode = isset( $error['shortcode'] ) ? (string) $error['shortcode'] : '';

			self::log_event(
				$post_id,
				sprintf(
					'Legacy module conversion skipped one block: %s (%s)',
					$message,
					$shortcode
				)
			);
		}
	}

	/**
	 * Log event.
	 *
	 * @param int    $post_id Post id.
	 * @param string $message Message.
	 * @return void
	 */
	private static function log_event( int $post_id, string $message ): void {
		if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
			// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- intentional when debugging conversion.
			error_log( sprintf( '[dsm-legacy-conversion post:%d] %s', $post_id, $message ) );
		}

		/**
		 * Log legacy shortcode-module conversion issues during VB save.
		 *
		 * @param int    $post_id Post ID (0 when unknown).
		 * @param string $message Log message.
		 */
		do_action( 'dsm_legacy_shortcode_conversion_log', $post_id, $message );
	}
}
