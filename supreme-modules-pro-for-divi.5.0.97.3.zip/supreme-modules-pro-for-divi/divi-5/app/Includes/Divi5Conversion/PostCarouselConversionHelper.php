<?php
/**
 * Post Carousel D4→D5: taxonomy terms + readmore button + title heading (CSS ID/class use shared merge).
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Includes\Divi5Conversion;

/**
 * Targeted migrator fixes for `dsm/post-carousel` (not a substitute for `defaultAttrs` / VB `defaultAttr`).
 */
final class PostCarouselConversionHelper {


	/**
	 * Merge D4 taxonomy `dsm_include_{post_type}_{taxonomy}` into `term_ids.innerContent.desktop.value`.
	 *
	 * @param array<string, mixed> $converted_attrs Converted block attrs (by reference).
	 * @param array<string, mixed> $d4_attrs        Original D4 shortcode attributes.
	 * @return void
	 */
	public static function hydrate_term_ids_from_d4( array &$converted_attrs, array $d4_attrs ): void {
		ConversionAttrs::hydrate_post_carousel_term_ids_from_d4( $converted_attrs, $d4_attrs );
	}

	/**
	 * Map D4 `custom_readmore` / `readmore_use_icon` into `readmore.decoration.button`.
	 *
	 * @param array<string, mixed> $converted_attrs Converted block attrs (by reference).
	 * @param array<string, mixed> $d4_attrs        Original D4 shortcode attributes.
	 * @return void
	 */
	public static function hydrate_readmore_from_d4( array &$converted_attrs, array $d4_attrs ): void {
		ConversionAttrs::hydrate_post_carousel_readmore_from_d4( $converted_attrs, $d4_attrs );
	}

	/**
	 * Map D4 `title_level` → D5 title heading level (default h2).
	 *
	 * @param array<string, mixed> $converted_attrs Converted block attrs (by reference).
	 * @param array<string, mixed> $d4_attrs        Original D4 shortcode attributes.
	 * @return void
	 */
	public static function normalize_title_heading_from_d4( array &$converted_attrs, array $d4_attrs ): void {
		ConversionAttrs::normalize_heading_level_from_d4( $converted_attrs, $d4_attrs, 'title', 'title_level', 'h2' );
	}
}
