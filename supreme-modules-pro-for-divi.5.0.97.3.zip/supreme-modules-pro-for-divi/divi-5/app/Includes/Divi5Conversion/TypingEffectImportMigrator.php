<?php
/**
 * Import / VB load: normalize `typing_effect` SortableList rows after shortcode→block conversion.
 *
 * Shortcode conversion for all Supreme modules (including Typing Effect) runs in
 * {@see SupremeShortcodeImportMigrator}. This migrator only coerces SortableList row shape.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Includes\Divi5Conversion;

/**
 * Portability and raw post load normalization for `dsm/typing-effect`.
 */
final class TypingEffectImportMigrator {

	/**
	 * Register content filters (after {@see SupremeShortcodeImportMigrator}).
	 *
	 * @return void
	 */
	public static function register(): void {
		add_filter(
			'divi_framework_portability_import_migrated_post_content',
			array( self::class, 'migrate_import_content' ),
			25,
			2
		);

		add_filter(
			'et_fb_load_raw_post_content',
			array( self::class, 'migrate_import_content' ),
			25,
			2
		);
	}

	/**
	 * Normalize typing-effect rows without rewriting the rest of the layout.
	 *
	 * A full parse_blocks() / serialize_blocks() round trip turns a Divi
	 * component snapshot `localAttrs: {}` into `localAttrs: []`. Replace only
	 * a typing-effect block whose rows actually change.
	 *
	 * @param string   $content Post content (block markup).
	 * @param int|null $post_id Optional post ID. Unused.
	 * @return string
	 */
	public static function migrate_import_content( $content, $post_id = null ) {
		unset( $post_id );

		if ( ! is_string( $content ) || '' === $content ) {
			return $content;
		}

		if ( false === strpos( $content, 'dsm/typing-effect' ) ) {
			return $content;
		}

		if ( ! function_exists( 'parse_blocks' ) || ! function_exists( 'serialize_blocks' ) ) {
			return $content;
		}

		return self::replace_typing_effect_blocks( $content );
	}

	/**
	 * Replace typing-effect blocks whose SortableList rows need coercing.
	 *
	 * @param string $content Post content (block markup).
	 * @return string
	 */
	private static function replace_typing_effect_blocks( string $content ): string {
		$offset = 0;
		$needle = '<!-- wp:dsm/typing-effect';

		while ( true ) {
			$start = strpos( $content, $needle, $offset );
			if ( false === $start ) {
				break;
			}
			$region = self::extract_block_markup( $content, $start, 'dsm/typing-effect' );
			if ( null === $region ) {
				$offset = $start + strlen( $needle );
				continue;
			}

			$raw    = substr( $content, $region['start'], $region['length'] );
			$merged = self::normalize_one_block_markup( $raw );
			if ( null === $merged || $merged === $raw ) {
				$offset = $region['start'] + $region['length'];
				continue;
			}

			$content = substr( $content, 0, $region['start'] ) . $merged . substr( $content, $region['start'] + $region['length'] );
			$offset  = $region['start'] + strlen( $merged );
		}

		return $content;
	}

	/**
	 * Byte range of one block that opens at $start.
	 *
	 * @param string $content    Full layout markup.
	 * @param int    $start      Offset of the opening comment.
	 * @param string $block_name Block name without the wp: prefix.
	 * @return array{start: int, length: int}|null
	 */
	private static function extract_block_markup( string $content, int $start, string $block_name ): ?array {
		$length   = strlen( $content );
		$open     = '<!-- wp:' . $block_name;
		$name_end = $start + strlen( $open );
		$after    = $name_end < $length ? $content[ $name_end ] : '';
		if ( '' !== $after && ' ' !== $after && '/' !== $after && '>' !== $after ) {
			return null;
		}

		$opener_end = strpos( $content, '-->', $start );
		if ( false === $opener_end ) {
			return null;
		}

		$opener = substr( $content, $start, ( $opener_end + 3 ) - $start );
		if ( preg_match( '/\/-->\s*$/', $opener ) ) {
			return array(
				'start'  => $start,
				'length' => ( $opener_end + 3 ) - $start,
			);
		}

		$depth  = 1;
		$cursor = $opener_end + 3;
		$close  = '<!-- /wp:' . $block_name;

		while ( $depth > 0 && $cursor < $length ) {
			$next_open  = strpos( $content, $open, $cursor );
			$next_close = strpos( $content, $close, $cursor );
			if ( false === $next_close ) {
				return null;
			}

			if ( false !== $next_open && $next_open < $next_close ) {
				$after_name = $next_open + strlen( $open );
				$next_char  = $after_name < $length ? $content[ $after_name ] : '';
				if ( '' !== $next_char && ' ' !== $next_char && '/' !== $next_char && '>' !== $next_char ) {
					$cursor = $after_name;
					continue;
				}
				++$depth;
				$cursor = $after_name;
				continue;
			}

			$close_end = strpos( $content, '-->', $next_close );
			if ( false === $close_end ) {
				return null;
			}
			--$depth;
			$cursor = $close_end + 3;
		}

		if ( 0 !== $depth ) {
			return null;
		}

		return array(
			'start'  => $start,
			'length' => $cursor - $start,
		);
	}

	/**
	 * Normalize one typing-effect block when its rows are not already SortableList rows.
	 *
	 * @param string $markup One typing-effect block.
	 * @return string|null Replacement markup, or null when the block is already normalized.
	 */
	private static function normalize_one_block_markup( string $markup ): ?string {
		$blocks = self::strip_empty_parsed_blocks( parse_blocks( $markup ) );
		if ( 1 !== count( $blocks ) || 'dsm/typing-effect' !== ( $blocks[0]['blockName'] ?? '' ) ) {
			return null;
		}

		$attrs = isset( $blocks[0]['attrs'] ) && is_array( $blocks[0]['attrs'] ) ? $blocks[0]['attrs'] : array();
		$next  = $attrs;
		ConversionAttrs::normalize_typing_effect_block_attrs( $next );
		if ( $next === $attrs ) {
			return null;
		}

		$blocks[0]['attrs'] = $next;

		return serialize_blocks( $blocks );
	}

	/**
	 * Drop the empty trailing block parse_blocks() appends.
	 *
	 * @param array<int, array<string, mixed>> $blocks Parsed blocks.
	 * @return array<int, array<string, mixed>>
	 */
	private static function strip_empty_parsed_blocks( array $blocks ): array {
		$out = array();
		foreach ( $blocks as $block ) {
			if ( ! is_array( $block ) ) {
				continue;
			}
			$name = $block['blockName'] ?? null;
			$html = isset( $block['innerHTML'] ) && is_string( $block['innerHTML'] ) ? trim( $block['innerHTML'] ) : '';
			if ( null === $name && '' === $html ) {
				continue;
			}
			$out[] = $block;
		}

		return $out;
	}
}
