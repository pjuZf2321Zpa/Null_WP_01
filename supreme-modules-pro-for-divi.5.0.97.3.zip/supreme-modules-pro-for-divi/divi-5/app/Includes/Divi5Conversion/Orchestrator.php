<?php
/**
 * Thin orchestrator for Divi 5 D4→D5 conversion: shared outline path + per-module registrars.
 *
 * Adds shared migrator hooks (outline path, decoration merge, per-module structural fixes).
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Includes\Divi5Conversion;

/**
 * Entry point for all Divi 5 conversion hooks used by Divi Supreme Pro.
 */
final class Orchestrator {


	/**
	 * Wire shared and per-module conversion / sanitization filters.
	 *
	 * @return void
	 */
	public static function register(): void {
		ConversionOutlineBootstrap::register();

		LegacyShortcodeFrontendBootstrap::register();
		PersistShortcodeModuleConversionOnSave::register();
		LegacyModuleBulkConversionAdmin::register();
		LegacyModuleBulkConversionCli::register();

		add_filter(
			'divi.moduleLibrary.conversion.moduleConversionOutlineFile',
			array( ConversionOutlinePath::class, 'filter' ),
			10,
			2
		);

		SupremeSharedConversion::register();

		// Convert leftover `dsm_*` shortcode-modules on import / VB load (before module-specific migrators).
		SupremeShortcodeImportMigrator::register();

		FlipboxChildMergeMigrator::register();
		TypingEffectImportMigrator::register();
		FilterableGalleryImportMigrator::register();
	}
}
