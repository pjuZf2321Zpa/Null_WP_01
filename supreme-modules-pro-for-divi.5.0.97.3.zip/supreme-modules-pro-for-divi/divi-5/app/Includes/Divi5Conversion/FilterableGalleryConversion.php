<?php
/**
 * D4→D5 post-convert fixes for `dsm/filterable-gallery`.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Includes\Divi5Conversion;

/**
 * Structural normalization after outline conversion (spacing uses convertSpacing in outline).
 */
final class FilterableGalleryConversion {

	/**
	 * Post convert.
	 *
	 * @param array<string, mixed> $converted_attrs Converted block attrs.
	 * @param array<string, mixed> $d4_attrs        Original D4 shortcode attrs.
	 * @return array<string, mixed>
	 */
	public static function post_convert( array $converted_attrs, array $d4_attrs ): array {
		if ( ! is_array( $converted_attrs ) ) {
			return array();
		}

		if ( ! is_array( $d4_attrs ) ) {
			$d4_attrs = array();
		}

		ConversionAttrs::normalize_heading_level_from_d4( $converted_attrs, $d4_attrs, 'header', 'header_level', 'h4' );

		foreach ( array( 'header', 'dsm_caption', 'dsm_description' ) as $font_key ) {
			ConversionAttrs::migrate_d4_font_text_align_if_empty( $converted_attrs, $d4_attrs, $font_key, $font_key );
			ConversionAttrs::migrate_d4_font_text_color_if_empty( $converted_attrs, $d4_attrs, $font_key, $font_key );
		}

		foreach ( array( 'dsm_category', 'dsm_pagination', 'dsm_load_more' ) as $font_key ) {
			ConversionAttrs::migrate_d4_font_text_align_if_empty( $converted_attrs, $d4_attrs, $font_key, $font_key );
			ConversionAttrs::migrate_d4_font_text_color_if_empty( $converted_attrs, $d4_attrs, $font_key, $font_key );
		}

		$range_defaults = array(
			'dsm_column_gap'          => '10px',
			'dsm_row_gap'             => '10px',
			'dsm_row_height'          => '180px',
			'dsm_image_height'        => '250px',
			'dsm_hover_transition'    => '500ms',
			'dsm_total_number_images' => '10',
			'dsm_per_page'            => '10',
		);

		foreach ( $range_defaults as $key => $default ) {
			ConversionAttrs::normalize_range_attr( $converted_attrs, $key, $default );
		}

		self::normalize_speed_inner_content( $converted_attrs, $d4_attrs );

		$toggles = array(
			'dsm_use_dynamic_images',
			'dsm_show_filterable_gallery',
			'dsm_show_all_images_text',
			'dsm_show_title',
			'dsm_show_caption',
			'dsm_show_description',
			'dsm_use_lightbox',
			'dsm_show_title_lightbox',
			'dsm_show_description_lightbox',
			'dsm_show_caption_lightbox',
			'dsm_show_pagination',
			'dsm_use_zoom_on_hover',
			'dsm_tidy_up_pagination',
			'dsm_auto_height',
			'dsm_custom_row_height',
		);

		foreach ( $toggles as $key ) {
			if ( isset( $converted_attrs[ $key ] ) ) {
				ConversionAttrs::coerce_inner_desktop_toggle_on_off( $converted_attrs, $key, 'off' );
			}
		}

		if ( isset( $d4_attrs['dsm_include_categories'] ) ) {
			self::hydrate_include_categories_from_d4( $converted_attrs, $d4_attrs );
		}

		if ( isset( $converted_attrs['dsm_include_categories'] ) ) {
			self::normalize_include_categories( $converted_attrs );
		}

		self::coerce_color_inner_content_strings( $converted_attrs );

		return $converted_attrs;
	}

	/**
	 * Normalize attrs on an already-converted block (import / VB load).
	 *
	 * @param array<string, mixed> $attrs Block attrs.
	 * @return array<string, mixed>
	 */
	public static function normalize_block_attrs( array $attrs ): array {
		return self::post_convert( $attrs, array() );
	}

	/**
	 * D4 speed is unit-less (Shuffle duration ms).
	 *
	 * @param array<string, mixed> $converted_attrs By reference.
	 * @param array<string, mixed> $d4_attrs        Original D4 attrs.
	 * @return void
	 */
	private static function normalize_speed_inner_content( array &$converted_attrs, array $d4_attrs ): void {
		$from_d4 = '';
		if ( isset( $d4_attrs['dsm_speed'] ) && is_scalar( $d4_attrs['dsm_speed'] ) ) {
			$from_d4 = trim( (string) $d4_attrs['dsm_speed'] );
		}

		if ( ! isset( $converted_attrs['dsm_speed']['innerContent']['desktop']['value'] ) ) {
			if ( '' !== $from_d4 ) {
				ConversionAttrs::set_inner_desktop_value( $converted_attrs, 'dsm_speed', $from_d4, true );
			}
			return;
		}

		$cur = $converted_attrs['dsm_speed']['innerContent']['desktop']['value'];
		if ( is_numeric( $cur ) ) {
			$converted_attrs['dsm_speed']['innerContent']['desktop']['value'] = (string) (int) $cur;
		} elseif ( is_string( $cur ) ) {
			$converted_attrs['dsm_speed']['innerContent']['desktop']['value'] = preg_replace( '/[^0-9]/', '', $cur ) ?? $cur;
		}
	}

	/**
	 * D4 `dsm_include_categories` comma-separated attachment term IDs → D5 checkbox array.
	 *
	 * @param array<string, mixed> $converted_attrs Converted block attrs (by reference).
	 * @param array<string, mixed> $d4_attrs        Original D4 shortcode attributes.
	 * @return void
	 */
	private static function hydrate_include_categories_from_d4( array &$converted_attrs, array $d4_attrs ): void {
		if ( ! isset( $d4_attrs['dsm_include_categories'] ) ) {
			return;
		}

		$raw = $d4_attrs['dsm_include_categories'];
		if ( is_array( $raw ) ) {
			$tokens = $raw;
		} elseif ( is_string( $raw ) ) {
			$raw = trim( $raw );
			if ( '' === $raw ) {
				return;
			}
			$tokens = array_filter( array_map( 'trim', explode( ',', $raw ) ) );
		} else {
			return;
		}

		if ( array() === $tokens ) {
			return;
		}

		$ids = array();
		foreach ( $tokens as $token ) {
			if ( is_numeric( $token ) ) {
				$id = (int) $token;
				if ( $id > 0 ) {
					$ids[] = (string) $id;
				}
			}
		}

		if ( array() === $ids ) {
			return;
		}

		if ( ! isset( $converted_attrs['dsm_include_categories'] ) || ! is_array( $converted_attrs['dsm_include_categories'] ) ) {
			$converted_attrs['dsm_include_categories'] = array();
		}
		if ( ! isset( $converted_attrs['dsm_include_categories']['innerContent'] ) || ! is_array( $converted_attrs['dsm_include_categories']['innerContent'] ) ) {
			$converted_attrs['dsm_include_categories']['innerContent'] = array();
		}
		if ( ! isset( $converted_attrs['dsm_include_categories']['innerContent']['desktop'] ) || ! is_array( $converted_attrs['dsm_include_categories']['innerContent']['desktop'] ) ) {
			$converted_attrs['dsm_include_categories']['innerContent']['desktop'] = array();
		}

		$converted_attrs['dsm_include_categories']['innerContent']['desktop']['value'] = array_values( array_unique( $ids, SORT_REGULAR ) );
	}

	/**
	 * Store attachment category IDs as a checkbox array for Visual Builder persistence.
	 *
	 * PHP render and VB edit normalize comma strings when needed.
	 *
	 * @param array<string, mixed> $converted_attrs By reference.
	 * @return void
	 */
	private static function normalize_include_categories( array &$converted_attrs ): void {
		if ( ! isset( $converted_attrs['dsm_include_categories']['innerContent'] ) || ! is_array( $converted_attrs['dsm_include_categories']['innerContent'] ) ) {
			$converted_attrs['dsm_include_categories']['innerContent'] = array();
		}
		if ( ! isset( $converted_attrs['dsm_include_categories']['innerContent']['desktop'] ) || ! is_array( $converted_attrs['dsm_include_categories']['innerContent']['desktop'] ) ) {
			$converted_attrs['dsm_include_categories']['innerContent']['desktop'] = array();
		}

		$raw = $converted_attrs['dsm_include_categories']['innerContent']['desktop']['value'] ?? array();

		if ( is_string( $raw ) ) {
			$raw = trim( $raw );
			if ( '' === $raw ) {
				$converted_attrs['dsm_include_categories']['innerContent']['desktop']['value'] = array();
				return;
			}
			$raw = array_filter( array_map( 'trim', explode( ',', $raw ) ) );
		}

		if ( ! is_array( $raw ) ) {
			$converted_attrs['dsm_include_categories']['innerContent']['desktop']['value'] = array();
			return;
		}

		$ids = array();
		foreach ( $raw as $id ) {
			if ( is_numeric( $id ) ) {
				$int_id = (int) $id;
				if ( $int_id > 0 ) {
					$ids[] = (string) $int_id;
				}
				continue;
			}
			if ( is_string( $id ) && ctype_digit( $id ) ) {
				$ids[] = $id;
			}
		}

		$converted_attrs['dsm_include_categories']['innerContent']['desktop']['value'] = array_values( array_unique( $ids, SORT_REGULAR ) );
	}

	/**
	 * CommonStyle expects a color string at innerContent.*.value.
	 *
	 * @param array<string, mixed> $converted_attrs By reference.
	 * @return void
	 */
	private static function coerce_color_inner_content_strings( array &$converted_attrs ): void {
		$color_keys = array(
			'dsm_overlay_color',
			'dsm_category_inactive_bg_color',
			'dsm_category_active_bg_color',
			'dsm_category_inactive_color',
			'dsm_category_active_color',
			'dsm_pagination_inactive_bg_color',
			'dsm_pagination_active_bg_color',
			'dsm_pagination_inactive_color',
			'dsm_pagination_active_color',
			'dsm_load_more_bg_color',
			'dsm_card_bg_color',
		);

		foreach ( $color_keys as $key ) {
			if ( ! isset( $converted_attrs[ $key ]['innerContent'] ) || ! is_array( $converted_attrs[ $key ]['innerContent'] ) ) {
				continue;
			}
			foreach ( array( 'desktop', 'tablet', 'phone' ) as $bp ) {
				if ( ! isset( $converted_attrs[ $key ]['innerContent'][ $bp ]['value'] ) ) {
					continue;
				}
				$val = $converted_attrs[ $key ]['innerContent'][ $bp ]['value'];
				if ( is_array( $val ) && isset( $val['color'] ) && is_string( $val['color'] ) ) {
					$converted_attrs[ $key ]['innerContent'][ $bp ]['value'] = $val['color'];
				}
			}
		}
	}
}
