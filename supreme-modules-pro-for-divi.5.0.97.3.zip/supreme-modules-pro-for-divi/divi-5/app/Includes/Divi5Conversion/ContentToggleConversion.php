<?php
/**
 * D4→D5 post-convert fixes for `dsm/content-toggle`.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Includes\Divi5Conversion;

/**
 * Structural normalization after outline conversion (library IDs, heading levels, rich content).
 */
final class ContentToggleConversion {

	/**
	 * Post-convert filter callback.
	 *
	 * @param array<string, mixed> $converted_attrs       Converted block attrs.
	 * @param string               $module_name           D5 module name.
	 * @param array<string, mixed> $d4_attrs              Original D4 shortcode attrs.
	 * @param bool                 $is_preset_conversion  Preset conversion flag.
	 * @return array<string, mixed>
	 */
	public static function post_convert_filter(
		array $converted_attrs,
		string $module_name,
		array $d4_attrs,
		bool $is_preset_conversion
	): array {
		unset( $is_preset_conversion );

		if ( 'dsm/content-toggle' !== $module_name ) {
			return $converted_attrs;
		}

		return self::post_convert( $converted_attrs, $d4_attrs );
	}

	/**
	 * Normalize converted Content Toggle attrs.
	 *
	 * @param array<string, mixed> $converted_attrs Converted block attrs.
	 * @param array<string, mixed> $d4_attrs        Original D4 shortcode attrs.
	 * @return array<string, mixed>
	 */
	public static function post_convert( array $converted_attrs, array $d4_attrs ): array {
		if ( ! is_array( $converted_attrs ) ) {
			return array();
		}

		if ( ! is_array( $d4_attrs ) ) {
			$d4_attrs = array();
		}

		ConversionAttrs::normalize_heading_level_from_d4(
			$converted_attrs,
			$d4_attrs,
			'heading_one',
			'heading_one_level',
			'h5'
		);
		ConversionAttrs::normalize_heading_level_from_d4(
			$converted_attrs,
			$d4_attrs,
			'heading_two',
			'heading_two_level',
			'h5'
		);

		ConversionAttrs::normalize_inner_value_to_heading_link_text_shape(
			$converted_attrs,
			'heading_one'
		);
		ConversionAttrs::normalize_inner_value_to_heading_link_text_shape(
			$converted_attrs,
			'heading_two'
		);

		foreach ( array( 'heading_one', 'heading_two' ) as $font_key ) {
			ConversionAttrs::migrate_d4_font_text_align_if_empty(
				$converted_attrs,
				$d4_attrs,
				$font_key,
				$font_key
			);
			ConversionAttrs::migrate_d4_font_text_color_if_empty(
				$converted_attrs,
				$d4_attrs,
				$font_key,
				$font_key
			);
			ConversionAttrs::migrate_d4_font_typography_scalars_if_empty(
				$converted_attrs,
				$d4_attrs,
				$font_key,
				$font_key
			);
		}

		foreach ( array( 'custom_content_one', 'custom_content_two' ) as $font_key ) {
			$d4_font_key = str_replace( 'custom_', '', $font_key );
			ConversionAttrs::migrate_d4_font_text_align_if_empty(
				$converted_attrs,
				$d4_attrs,
				$font_key,
				$d4_font_key
			);
			ConversionAttrs::migrate_d4_font_text_color_if_empty(
				$converted_attrs,
				$d4_attrs,
				$font_key,
				$d4_font_key
			);
			ConversionAttrs::migrate_d4_font_typography_scalars_if_empty(
				$converted_attrs,
				$d4_attrs,
				$font_key,
				$d4_font_key
			);
		}

		foreach ( array( 'custom_content_one', 'custom_content_two' ) as $rich_content_key ) {
			ConversionAttrs::normalize_flipbox_rich_content_inner_content_for_vb(
				$converted_attrs,
				$rich_content_key
			);
		}

		foreach ( array( 'one', 'two' ) as $index ) {
			self::normalize_library_id_attr( $converted_attrs, 'library_id_' . $index, $d4_attrs );
			self::normalize_content_type_attr( $converted_attrs, 'content_type_' . $index, $d4_attrs );
		}

		foreach (
			array(
				'switcher_size'           => '15px',
				'content_spacing_top_one' => '25px',
				'content_spacing_top_two' => '25px',
			) as $range_key => $default
		) {
			ConversionAttrs::normalize_range_attr( $converted_attrs, $range_key, $default );
		}

		foreach ( array( 'content_fullwidth_one', 'content_fullwidth_two' ) as $toggle_key ) {
			if ( isset( $converted_attrs[ $toggle_key ] ) ) {
				ConversionAttrs::coerce_inner_desktop_toggle_on_off(
					$converted_attrs,
					$toggle_key,
					'off'
				);
			}
		}

		ConversionAttrs::merge_d4_module_id_class_into_decoration_attributes(
			$converted_attrs,
			$d4_attrs
		);

		return $converted_attrs;
	}

	/**
	 * Drop D4-only Content Toggle attrs handled elsewhere (fonts, computed, meta).
	 *
	 * @param bool                 $should_deprecate Whether ET already marked this attribute deprecated.
	 * @param string               $desktop_name     Base attribute name (no responsive/hover suffix).
	 * @param string               $module_name      D5 module name.
	 * @param array<string, mixed> $attrs            Full D4 shortcode attributes.
	 * @return bool
	 */
	public static function deprecate_d4_legacy_attrs(
		bool $should_deprecate,
		string $desktop_name,
		string $module_name,
		array $attrs
	): bool {
		unset( $attrs );

		if ( $should_deprecate ) {
			return true;
		}

		if ( ! is_string( $desktop_name ) || 'dsm/content-toggle' !== $module_name ) {
			return false;
		}

		static $deprecated = array(
			'global_colors_info',
			'_builder_version',
			'_module_preset',
			'__library_one',
			'__library_two',
		);

		if ( in_array( $desktop_name, $deprecated, true ) ) {
			return true;
		}

		if ( str_starts_with( $desktop_name, 'border_radii_content_' ) ) {
			return true;
		}

		if ( preg_match(
			'/^(heading_one|heading_two|content_one|content_two)_(font|font_size|font_last_edited|text_color|text_align|line_height|letter_spacing|text_shadow)/',
			$desktop_name
		) ) {
			return true;
		}

		return false;
	}

	/**
	 * Ensure library layout IDs are numeric innerContent values.
	 *
	 * @param array<string, mixed> $converted_attrs Reference.
	 * @param string               $attr_key        Attribute key.
	 * @param array<string, mixed> $d4_attrs        Original D4 attrs.
	 * @return void
	 */
	private static function normalize_library_id_attr(
		array &$converted_attrs,
		string $attr_key,
		array $d4_attrs
	): void {
		$raw = $converted_attrs[ $attr_key ]['innerContent']['desktop']['value']
			?? ( $d4_attrs[ $attr_key ] ?? '' );

		if ( is_numeric( $raw ) ) {
			$id = (int) $raw;
			if ( $id <= 0 ) {
				return;
			}

			if ( ! isset( $converted_attrs[ $attr_key ] ) || ! is_array( $converted_attrs[ $attr_key ] ) ) {
				$converted_attrs[ $attr_key ] = array();
			}
			if ( ! isset( $converted_attrs[ $attr_key ]['innerContent'] ) ) {
				$converted_attrs[ $attr_key ]['innerContent'] = array();
			}
			if ( ! isset( $converted_attrs[ $attr_key ]['innerContent']['desktop'] ) ) {
				$converted_attrs[ $attr_key ]['innerContent']['desktop'] = array();
			}

			$converted_attrs[ $attr_key ]['innerContent']['desktop']['value'] = $id;
		}
	}

	/**
	 * Preserve content source type (`content`, `library`, `shortcode`) from D4.
	 *
	 * @param array<string, mixed> $converted_attrs Reference.
	 * @param string               $attr_key        Attribute key.
	 * @param array<string, mixed> $d4_attrs        Original D4 attrs.
	 * @return void
	 */
	private static function normalize_content_type_attr(
		array &$converted_attrs,
		string $attr_key,
		array $d4_attrs
	): void {
		$allowed = array( 'content', 'library', 'shortcode' );
		$raw     = $converted_attrs[ $attr_key ]['innerContent']['desktop']['value']
			?? ( $d4_attrs[ $attr_key ] ?? 'content' );

		if ( ! is_string( $raw ) || ! in_array( $raw, $allowed, true ) ) {
			return;
		}

		if ( ! isset( $converted_attrs[ $attr_key ] ) || ! is_array( $converted_attrs[ $attr_key ] ) ) {
			$converted_attrs[ $attr_key ] = array();
		}
		if ( ! isset( $converted_attrs[ $attr_key ]['innerContent'] ) ) {
			$converted_attrs[ $attr_key ]['innerContent'] = array();
		}
		if ( ! isset( $converted_attrs[ $attr_key ]['innerContent']['desktop'] ) ) {
			$converted_attrs[ $attr_key ]['innerContent']['desktop'] = array();
		}

		$converted_attrs[ $attr_key ]['innerContent']['desktop']['value'] = $raw;
	}
}
