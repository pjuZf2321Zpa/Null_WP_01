<?php
/**
 * Load Divi 4 Supreme shortcode modules on Divi 5 frontends for unconverted layouts.
 *
 * On Divi 5, Supreme Pro boots only the D5 app. Cloned / restored sites often still store
 * pure D4 shortcodes (`[et_pb_section]…[dsm_text_divider]…`). Core `et_pb_*` shortcodes
 * still render via Divi's shortcode framework, but `dsm_*` handlers are never registered —
 * so the frontend prints raw shortcodes until a Visual Builder save converts the layout.
 *
 * This bootstrap loads D4 module PHP files on `et_builder_ready` so those shortcodes render
 * without requiring a per-page resave. It does not load the D4 DiviExtension builder bundle
 * (keeps D5 VB native).
 *
 * It also registers/enqueues the Divi 4 frontend CSS/JS those modules expect:
 * - `divi-4/styles/style.min.css` only when the base page / Theme Builder still has `[dsm_*]`
 * shortcodes (never on fully converted Divi 5 pages — that bundle disturbs Critical CSS and
 * lets Divi's global `.et_pb_section { padding: 54px 0 }` beat Theme Builder section padding)
 * - D4 public shared CSS (Swiper, animate, popup, readmore) when that bundle loads
 * - D4 public script handles (so `wp_enqueue_script( 'dsm-*' )` from module render resolves)
 * - Lazy bootstrap via `pre_do_shortcode_tag` for nested library/popup shortcodes without the
 * full head CSS bundle
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Includes\Divi5Conversion;

/**
 * Frontend-only D4 shortcode registration under Divi 5.
 */
final class LegacyShortcodeFrontendBootstrap {

	/**
	 * Handle used by DiviExtension on Divi 4 for the compiled module stylesheet.
	 */
	private const D4_MODULE_STYLES_HANDLE = 'supreme-modules-pro-for-divi-styles';

	/**
	 * Modules loaded.
	 *
	 * @var bool
	 */
	private static bool $modules_loaded = false;

	/**
	 * Assets registered.
	 *
	 * @var bool
	 */
	private static bool $assets_registered = false;

	/**
	 * Has legacy shortcodes cache.
	 *
	 * @var bool|null
	 */
	private static ?bool $has_legacy_shortcodes_cache = null;

	/**
	 * Register.
	 *
	 * @return void
	 */
	public static function register(): void {
		add_action( 'et_builder_ready', array( self::class, 'load_d4_shortcode_modules' ), 9 );
		// After Divi Dynamic Assets supplement (wp:5) so Theme Builder / library content is scannable.
		add_action( 'wp', array( self::class, 'load_d4_shortcode_modules' ), 20 );
		// After D5 frontend asset registration so D4 shortcode handles win for this request.
		add_action( 'wp_enqueue_scripts', array( self::class, 'register_d4_frontend_assets' ), 100 );
		add_action( 'wp_enqueue_scripts', array( self::class, 'enqueue_d4_frontend_styles' ), 101 );
		// Safety net: if detection missed a legacy shortcode still rendered on the page, load then.
		add_filter( 'pre_do_shortcode_tag', array( self::class, 'maybe_bootstrap_on_dsm_shortcode' ), 1, 2 );
	}

	/**
	 * Whether the main page / Theme Builder body still contains Divi 4 `dsm_*` shortcodes.
	 *
	 * Intentionally ignores nested library supplements (popups, toggles, tabs). Scanning those
	 * would enqueue the full D4 `style.min.css` bundle on otherwise-native Divi 5 pages and
	 * disturb Critical CSS so Theme Builder section padding loses to Divi's global
	 * `.et-db #et-boc .et-l .et_pb_section { padding: 54px 0 }` rule at wide breakpoints.
	 * Nested shortcodes are bootstrapped lazily via {@see maybe_bootstrap_on_dsm_shortcode()}.
	 *
	 * @param bool $cache_negative Whether a "not found" result may be cached (avoid caching before `wp`).
	 * @return bool
	 */
	private static function current_request_has_legacy_dsm_shortcodes( bool $cache_negative = true ): bool {
		if ( true === self::$has_legacy_shortcodes_cache ) {
			return true;
		}

		if ( false === self::$has_legacy_shortcodes_cache && $cache_negative ) {
			return false;
		}

		$blobs = array();

		$post = get_post();
		if ( $post instanceof \WP_Post && is_string( $post->post_content ) && '' !== $post->post_content ) {
			$blobs[] = $post->post_content;
		}

		if ( class_exists( \DiviSupreme\Includes\DsmFrontendDynamicAssets::class ) ) {
			$base = \DiviSupreme\Includes\DsmFrontendDynamicAssets::get_base_page_content_for_detection();
			if ( '' !== $base ) {
				$blobs[] = $base;
			}
		}

		foreach ( array_unique( $blobs ) as $blob ) {
			if ( self::content_has_legacy_dsm_shortcode( $blob ) ) {
				self::$has_legacy_shortcodes_cache = true;
				return true;
			}
		}

		// Do not cache negatives before the main query is ready.
		if ( $cache_negative && did_action( 'wp' ) ) {
			self::$has_legacy_shortcodes_cache = false;
		}

		return false;
	}

	/**
	 * Content has legacy dsm shortcode.
	 *
	 * @param string $content Post / TB content blob.
	 * @return bool
	 */
	private static function content_has_legacy_dsm_shortcode( string $content ): bool {
		return '' !== $content && 1 === preg_match( '/\[dsm_[a-z0-9_]+/i', $content );
	}

	/**
	 * Lazy-load D4 shortcode modules when a `dsm_*` shortcode is about to render.
	 *
	 * Used for nested library / popup bodies that are not part of the base page scan. Avoids
	 * enqueueing the full D4 `style.min.css` head bundle (TB padding regression); per-module
	 * CSS is attached in the footer via {@see maybe_enqueue_late_module_styles()}.
	 *
	 * @param false|string $return Short-circuit return value.
	 * @param string       $tag    Shortcode tag.
	 * @return false|string
	 */
	public static function maybe_bootstrap_on_dsm_shortcode( $return, string $tag ) {
		if ( ! is_string( $tag ) || ! str_starts_with( $tag, 'dsm_' ) ) {
			return $return;
		}

		self::$has_legacy_shortcodes_cache = true;
		self::load_d4_shortcode_modules();

		if ( ! self::is_divi_builder_app_request() ) {
			self::register_d4_frontend_assets();
			// Do not enqueue style.min.css here — that head bundle breaks TB section padding on D5.
			add_action( 'wp_footer', array( self::class, 'maybe_enqueue_late_module_styles' ), 1 );
		}

		return $return;
	}

	/**
	 * Require Divi 4 module PHP files so `dsm_*` shortcodes are registered.
	 *
	 * @return void
	 */
	public static function load_d4_shortcode_modules(): void {
		if ( self::$modules_loaded ) {
			return;
		}

		if ( ! class_exists( 'ET_Builder_Element' ) ) {
			return;
		}

		// Visual Builder / app frames use native D5 modules — skip D4 shortcode classes there.
		if ( self::is_divi_builder_app_request() ) {
			return;
		}

		// Fully converted Divi 5 pages have no `[dsm_*` shortcodes — skip D4 module PHP.
		// Nested library shortcodes set the cache true via {@see maybe_bootstrap_on_dsm_shortcode()}.
		if ( ! self::current_request_has_legacy_dsm_shortcodes( (bool) did_action( 'wp' ) ) ) {
			return;
		}

		$helper      = DSM_DIR_PATH . 'divi-4/includes/class-dsm-supreme-modules-pro-for-divi-helper.php';
		$compat      = DSM_DIR_PATH . 'divi-4/includes/SupremeModulesLoader.php';
		$modules_dir = DSM_DIR_PATH . 'divi-4/includes/modules';

		if ( ! is_dir( $modules_dir ) ) {
			return;
		}

		// Helpers + D4 polyfills required by module field callbacks during construction.
		if ( is_readable( $helper ) ) {
			require_once $helper;
		}

		if ( is_readable( $compat ) ) {
			require_once $compat;
		}

		foreach ( self::get_module_files_to_load( $modules_dir ) as $module_file ) {
			try {
				require_once $module_file;
			} catch ( \Throwable $exception ) {
				if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
					// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
					error_log(
						sprintf(
							'[dsm-legacy-shortcode-frontend] skipped %s: %s',
							basename( dirname( $module_file ) ),
							$exception->getMessage()
						)
					);
				}
			}
		}

		self::$modules_loaded = true;
	}

	/**
	 * Register Divi 4 public style/script handles expected by D4 shortcode modules.
	 *
	 * @return void
	 */
	public static function register_d4_frontend_assets(): void {
		if ( self::$assets_registered || self::is_divi_builder_app_request() ) {
			return;
		}

		if ( ! self::current_request_has_legacy_dsm_shortcodes() ) {
			return;
		}

		if ( ! defined( 'DSM_DIR_PATH' ) ) {
			return;
		}

		$version    = defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';
		$plugin_url = plugin_dir_url( DSM_DIR_PATH . 'supreme-modules-pro-for-divi.php' );
		$public_url = $plugin_url . 'divi-4/public/';
		$styles_url = $plugin_url . 'divi-4/styles/';

		// Full compiled D4 module CSS (Text Divider, Icon List, Card Carousel, …).
		// On Divi 4 this is enqueued by DiviExtension as `supreme-modules-pro-for-divi-styles`.
		wp_register_style(
			self::D4_MODULE_STYLES_HANDLE,
			$styles_url . 'style.min.css',
			array(),
			$version,
			'all'
		);

		wp_register_style( 'dsm-swiper', $public_url . 'css/swiper.css', array(), $version, 'all' );
		wp_register_style( 'dsm-animate', $public_url . 'css/animate.css', array(), $version, 'all' );
		wp_register_style( 'dsm-popup', $public_url . 'css/popup.css', array(), $version, 'all' );
		wp_register_style( 'dsm-readmore', $public_url . 'css/readmore.css', array(), $version, 'all' );

		$et_builder_url = defined( 'ET_BUILDER_PLUGIN_URI' )
			? ET_BUILDER_PLUGIN_URI
			: get_template_directory_uri();

		if ( ! wp_style_is( 'dsm-magnific-popup', 'registered' ) ) {
			wp_register_style(
				'dsm-magnific-popup',
				$et_builder_url . '/includes/builder/feature/dynamic-assets/assets/css/magnific_popup.css',
				array(),
				$version,
				'all'
			);
		}

		// Per-module CSS handles used when dynamic assets + compatibility mode is on.
		self::register_d4_module_style_handles( $plugin_url . 'divi-4/includes/modules/', $version );

		// Register every D4 frontend script handle modules may enqueue during render.
		self::register_d4_public_scripts( $public_url, $plugin_url . 'divi-4/includes/modules/', $version );

		self::$assets_registered = true;
	}

	/**
	 * Enqueue Divi 4 frontend styles for legacy shortcode rendering.
	 *
	 * @return void
	 */
	public static function enqueue_d4_frontend_styles(): void {
		if ( self::is_divi_builder_app_request() ) {
			return;
		}

		if ( ! self::current_request_has_legacy_dsm_shortcodes() ) {
			return;
		}

		if ( ! wp_style_is( self::D4_MODULE_STYLES_HANDLE, 'registered' ) ) {
			self::register_d4_frontend_assets();
		}

		if ( ! wp_style_is( self::D4_MODULE_STYLES_HANDLE, 'registered' ) ) {
			return;
		}

		// Full D4 module stylesheet only when legacy shortcodes are present on this request.
		wp_enqueue_style( self::D4_MODULE_STYLES_HANDLE );

		$dsm_settings_misc  = get_option( 'dsm_settings_misc' );
		$dsm_dynamic_assets = (
			is_array( $dsm_settings_misc )
			&& isset( $dsm_settings_misc['dsm_dynamic_assets'] )
			&& 'off' !== $dsm_settings_misc['dsm_dynamic_assets']
		);

		// Match {@see \Dsm_Supreme_Modules_Pro_For_Divi_Public::enqueue_styles()} non-dynamic mode.
		if ( ! $dsm_dynamic_assets ) {
			wp_enqueue_style( 'dsm-magnific-popup' );
			wp_enqueue_style( 'dsm-swiper' );
			wp_enqueue_style( 'dsm-popup' );
			wp_enqueue_style( 'dsm-animate' );
			wp_enqueue_style( 'dsm-readmore' );
		}

		// When a module enqueues only its script (or dynamic-compat style), print late styles too.
		add_action( 'wp_footer', array( self::class, 'maybe_enqueue_late_module_styles' ), 1 );
	}

	/**
	 * Enqueue per-module CSS when the matching script was enqueued during render.
	 *
	 * @return void
	 */
	public static function maybe_enqueue_late_module_styles(): void {
		$script_to_style = array(
			'dsm-card-carousel'      => 'dsm-card-carousel',
			'dsm-image-carousel'     => 'dsm-image-carousel',
			'dsm-blog-carousel'      => 'dsm-blog-carousel',
			'dsm-post-carousel'      => 'dsm-post-carousel',
			'dsm-image-hotspots'     => 'dsm-image-hotspots',
			'dsm-icon-list'          => 'dsm-icon-list',
			'dsm-advanced-tabs'      => 'dsm-advanced-tabs',
			'dsm-faq'                => 'dsm-faq',
			'dsm-tilt-image'         => 'dsm-tilt-image',
			'dsm-lottie-module'      => 'dsm-lottie',
			'dsm-before-after-image' => 'dsm-before-after-image',
			'dsm-masonry-gallery'    => 'dsm-masonry-gallery',
			'dsm-filterable-gallery' => 'dsm-filterable-gallery',
			'dsm-image-accordion'    => 'dsm-image-accordion',
			'dsm-content-timeline'   => 'dsm-content-timeline',
			'dsm-circle-info'        => 'dsm-circle-info',
			'dsm-menu'               => 'dsm-menu',
			'dsm-progress-bar'       => 'dsm-progress-bar',
			'dsm-social-share'       => 'dsm-social-share',
			'dsm-typing-effect'      => 'dsm-typing-effect',
			'dsm-text-rotator'       => 'dsm-text-rotator',
			'dsm-shuffle-letters'    => 'dsm-shuffle-letters',
			'dsm-text-notation'      => 'dsm-text-notation',
			'dsm-block-reveal-text'  => 'dsm-block-reveal-text',
			'dsm-block-reveal-image' => 'dsm-block-reveal-image',
			'dsm-image-text-reveal'  => 'dsm-image-text-reveal',
			'dsm-image-hover-reveal' => 'dsm-image-hover-reveal',
			'dsm-content-toggle'     => 'dsm-content-toggle',
			'dsm-flipbox-click'      => 'dsm-flipbox',
			'dsm-svg-animation'      => 'dsm-svg-animation',
		);

		foreach ( $script_to_style as $script_handle => $style_handle ) {
			if ( wp_script_is( $script_handle, 'enqueued' ) && wp_style_is( $style_handle, 'registered' ) ) {
				wp_enqueue_style( $style_handle );
			}
		}

		// Text Divider has no frontend script — ensure its handle is available if a module asked for it.
		if ( wp_style_is( 'dsm-text-divider', 'registered' ) && self::legacy_shortcode_likely_present( 'dsm_text_divider' ) ) {
			wp_enqueue_style( 'dsm-text-divider' );
		}
	}

	/**
	 * Register `style.css` for each D4 module folder (dynamic-assets compatibility handles).
	 *
	 * @param string $modules_url Absolute URL to divi-4/includes/modules/.
	 * @param string $version     Asset version.
	 * @return void
	 */
	private static function register_d4_module_style_handles( string $modules_url, string $version ): void {
		$modules_dir = DSM_DIR_PATH . 'divi-4/includes/modules';

		if ( ! is_dir( $modules_dir ) ) {
			return;
		}

		$style_files = glob( $modules_dir . '/*/style.css' );

		if ( ! is_array( $style_files ) ) {
			return;
		}

		foreach ( $style_files as $style_file ) {
			$folder = basename( dirname( $style_file ) );
			$handle = self::module_folder_to_style_handle( $folder );

			if ( '' === $handle || wp_style_is( $handle, 'registered' ) ) {
				continue;
			}

			$deps = array();

			if ( in_array( $folder, array( 'CardCarousel', 'ImageCarousel', 'BlogCarousel', 'PostCarousel' ), true ) ) {
				$deps[] = 'dsm-swiper';
			}

			wp_register_style(
				$handle,
				$modules_url . $folder . '/style.css',
				$deps,
				$version,
				'all'
			);
		}
	}

	/**
	 * Register D4 frontend scripts (mirrors {@see \Dsm_Supreme_Modules_Pro_For_Divi_Public::enqueue_scripts()}).
	 *
	 * @param string $public_url  Absolute URL to divi-4/public/.
	 * @param string $modules_url Absolute URL to divi-4/includes/modules/.
	 * @param string $version     Asset version.
	 * @return void
	 */
	private static function register_d4_public_scripts( string $public_url, string $modules_url, string $version ): void {
		$dsm_settings_social_media = get_option( 'dsm_settings_social_media' );
		$facebook_app_id           = '';

		if ( is_array( $dsm_settings_social_media ) && ! empty( $dsm_settings_social_media['dsm_facebook_app_id'] ) ) {
			$facebook_app_id = '&appId=' . rawurlencode( (string) $dsm_settings_social_media['dsm_facebook_app_id'] );
		}

		$facebook_lang = 'en_US';

		if (
			is_array( $dsm_settings_social_media )
			&& isset( $dsm_settings_social_media['dsm_facebook_site_lang'] )
			&& 'off' !== $dsm_settings_social_media['dsm_facebook_site_lang']
		) {
			$facebook_lang = get_locale();
		}

		$libs = array(
			'dsm-typed'        => array( 'js/typed.min.js', array() ),
			'dsm-splitting'    => array( 'js/splitting.js', array() ),
			'dsm-gsap'         => array( 'js/gsap.min.js', array() ),
			'dsm-tilt'         => array( 'js/vanilla-tilt.min.js', array() ),
			'dsm-baffle'       => array( 'js/baffle.min.js', array() ),
			'dsm-swiper'       => array( 'js/swiper-bundle.min.js', array() ),
			'dsm-js-cookie'    => array( 'js/js.cookie.js', array() ),
			'dsm-readmore'     => array( 'js/readmore.js', array() ),
			'dsm-popper'       => array( 'js/popper.min.js', array() ),
			'dsm-replace-me'   => array( 'js/replaceme.min.js', array() ),
			'dsm-lottie'       => array( 'js/lottie.min.js', array() ),
			'dsm-notation'     => array( 'js/rough-notation.iife.js', array() ),
			'dsm-imagesloaded' => array( 'js/imagesloaded.pkgd.min.js', array( 'jquery' ) ),
			'dsm-twentytwenty' => array( 'js/dsm-before-after-image-slider.js', array( 'jquery' ) ),
		);

		foreach ( $libs as $handle => $config ) {
			self::reregister_script( $handle, $public_url . $config[0], $config[1], $version );
		}

		self::reregister_script( 'dsm-glio', $public_url . 'js/glio.min.js', array( 'dsm-js-cookie' ), $version );
		self::reregister_script( 'dsm-tippy', $public_url . 'js/tippy-bundle.umd.min.js', array( 'dsm-popper' ), $version );
		self::reregister_script( 'dsm-revealFx', $public_url . 'js/revealFX.js', array( 'dsm-gsap' ), $version );
		self::reregister_script( 'dsm-masonry', $public_url . 'js/masonry.pkgd.min.js', array( 'dsm-imagesloaded' ), $version );
		self::reregister_script(
			'dsm-magnific-popup-image',
			$public_url . 'js/dsm-magnific-popup-image.js',
			array( 'dsm-magnific-popup' ),
			$version
		);
		self::reregister_script(
			'dsm-magnific-popup-video',
			$public_url . 'js/dsm-magnific-popup-video.js',
			array( 'dsm-magnific-popup' ),
			$version
		);
		self::reregister_script(
			'dsm-facebook',
			'https://connect.facebook.net/' . rawurlencode( $facebook_lang ) . '/sdk.js#xfbml=1&version=v20.0' . $facebook_app_id,
			array(),
			$version
		);
		self::reregister_script(
			'dsm-twitter-embed',
			'https://platform.twitter.com/widgets.js',
			array(),
			$version
		);

		$module_scripts = array(
			'dsm-image-hotspots'     => array( 'ImageHotSpots/frontend.min.js', array( 'dsm-tippy' ) ),
			'dsm-icon-list'          => array( 'IconListChild/frontend.min.js', array( 'dsm-tippy' ) ),
			'dsm-typing-effect'      => array( 'TypingEffect/frontend.min.js', array( 'dsm-typed' ) ),
			'dsm-text-rotator'       => array( 'TextRotator/frontend.min.js', array( 'dsm-replace-me' ) ),
			'dsm-shuffle-letters'    => array( 'ShuffleLetters/frontend.min.js', array( 'dsm-baffle' ) ),
			'dsm-before-after-image' => array( 'BeforeAfterImage/frontend.min.js', array( 'dsm-twentytwenty' ) ),
			'dsm-lottie-module'      => array( 'Lottie/frontend.min.js', array( 'dsm-lottie' ) ),
			'dsm-block-reveal-text'  => array( 'BlockRevealText/frontend.min.js', array( 'dsm-revealFx' ) ),
			'dsm-block-reveal-image' => array( 'BlockRevealImage/frontend.min.js', array( 'dsm-revealFx' ) ),
			'dsm-card-carousel'      => array( 'CardCarousel/frontend.min.js', array( 'jquery', 'dsm-swiper' ) ),
			'dsm-image-carousel'     => array( 'ImageCarousel/frontend.min.js', array( 'jquery', 'dsm-swiper' ) ),
			'dsm-tilt-image'         => array( 'TiltImage/frontend.min.js', array( 'dsm-tilt' ) ),
			'dsm-image-text-reveal'  => array( 'ImageReveal/frontend.min.js', array( 'dsm-splitting' ) ),
			'dsm-image-hover-reveal' => array( 'ImageHoverReveal/frontend.min.js', array( 'dsm-splitting' ) ),
			'dsm-contact-form-7'     => array( 'ContactForm7/frontend.min.js', array() ),
			'dsm-caldera-forms'      => array( 'CalderaForms/frontend.min.js', array() ),
			'dsm-text-notation'      => array( 'TextNotation/frontend.min.js', array( 'dsm-notation' ) ),
			'dsm-flipbox-click'      => array( 'FlipBoxPerk/frontend.min.js', array() ),
			'dsm-masonry-gallery'    => array( 'MasonryGallery/frontend.min.js', array( 'dsm-masonry' ) ),
			'dsm-content-toggle'     => array( 'ContentToggle/frontend.min.js', array( 'jquery' ) ),
			'dsm-blog-carousel'      => array( 'BlogCarousel/frontend.min.js', array( 'jquery', 'dsm-swiper' ) ),
			'dsm-image-accordion'    => array( 'ImageAccordion/frontend.min.js', array( 'jquery' ) ),
			'dsm-post-carousel'      => array( 'PostCarousel/frontend.min.js', array( 'jquery', 'dsm-swiper' ) ),
			'dsm-menu'               => array( 'Menu/frontend.min.js', array( 'jquery' ) ),
			'dsm-content-timeline'   => array( 'ContentTimeLine/frontend.min.js', array( 'jquery' ) ),
			'dsm-social-share'       => array( 'SocialShareButtons/frontend.min.js', array( 'jquery' ) ),
			'dsm-advanced-tabs'      => array( 'AdvancedTabs/frontend.min.js', array( 'jquery' ) ),
			'dsm-progress-bar'       => array( 'ProgressBar/frontend.min.js', array( 'jquery' ) ),
			'dsm-faq'                => array( 'Faq/frontend.min.js', array( 'jquery' ) ),
			'dsm-svg-animation'      => array( 'SvgAnimation/frontend.min.js', array( 'jquery' ) ),
			'dsm-shuffle'            => array( 'FilterableGallery/dsm-shuffle.js', array( 'jquery' ) ),
			'dsm-filterable-gallery' => array( 'FilterableGallery/dsm-filterable-gallery.js', array( 'jquery' ) ),
			'dsm-circle-info'        => array( 'CircleInfo/frontend.min.js', array( 'jquery' ) ),
		);

		foreach ( $module_scripts as $handle => $config ) {
			self::reregister_script( $handle, $modules_url . $config[0], $config[1], $version );
		}

		$ext_url = plugin_dir_url( DSM_DIR_PATH . 'supreme-modules-pro-for-divi.php' ) . 'divi-4/includes/extensions/';

		self::reregister_script( 'dsm-readme', $ext_url . 'ReadMore/frontend.min.js', array( 'dsm-readmore' ), $version );
		self::reregister_script(
			'dsm-popup',
			$ext_url . 'Popup/frontend.min.js',
			array( 'jquery', 'dsm-magnific-popup' ),
			$version
		);
	}

	/**
	 * Map a D4 module folder name to a wp_style handle.
	 *
	 * @param string $folder Folder.
	 */
	private static function module_folder_to_style_handle( string $folder ): string {
		$map = array(
			'TextDivider'         => 'dsm-text-divider',
			'IconDivider'         => 'dsm-icon-divider',
			'CardCarousel'        => 'dsm-card-carousel',
			'ImageCarousel'       => 'dsm-image-carousel',
			'BlogCarousel'        => 'dsm-blog-carousel',
			'PostCarousel'        => 'dsm-post-carousel',
			'ImageHotSpots'       => 'dsm-image-hotspots',
			'IconList'            => 'dsm-icon-list',
			'AdvancedTabs'        => 'dsm-advanced-tabs',
			'Faq'                 => 'dsm-faq',
			'TiltImage'           => 'dsm-tilt-image',
			'Lottie'              => 'dsm-lottie',
			'BeforeAfterImage'    => 'dsm-before-after-image',
			'MasonryGallery'      => 'dsm-masonry-gallery',
			'FilterableGallery'   => 'dsm-filterable-gallery',
			'ImageAccordion'      => 'dsm-image-accordion',
			'ContentTimeLine'     => 'dsm-content-timeline',
			'CircleInfo'          => 'dsm-circle-info',
			'Menu'                => 'dsm-menu',
			'ProgressBar'         => 'dsm-progress-bar',
			'SocialShareButtons'  => 'dsm-social-share',
			'TypingEffect'        => 'dsm-typing-effect',
			'TextRotator'         => 'dsm-text-rotator',
			'ShuffleLetters'      => 'dsm-shuffle-letters',
			'TextNotation'        => 'dsm-text-notation',
			'BlockRevealText'     => 'dsm-block-reveal-text',
			'BlockRevealImage'    => 'dsm-block-reveal-image',
			'ImageReveal'         => 'dsm-image-text-reveal',
			'ImageHoverReveal'    => 'dsm-image-hover-reveal',
			'ContentToggle'       => 'dsm-content-toggle',
			'FlipBoxPerk'         => 'dsm-flipbox',
			'SvgAnimation'        => 'dsm-svg-animation',
			'BusinessHours'       => 'dsm-business-hours',
			'PriceList'           => 'dsm-price-list',
			'StarRating'          => 'dsm-star-rating',
			'GradientText'        => 'dsm-gradient-text',
			'GlitchText'          => 'dsm-glitch-text',
			'Breadcrumbs'         => 'dsm-breadcrumbs',
			'StepFlow'            => 'dsm-step-flow',
			'ScrollImage'         => 'dsm-scroll-image',
			'PerspectiveImage'    => 'dsm-perspective-image',
			'BlobImage'           => 'dsm-blob-image',
			'FloatingMultiImages' => 'dsm-floating-multi-images',
			'TextPath'            => 'dsm-text-path',
			'RandomImage'         => 'dsm-random-image',
			'Badges'              => 'dsm-badges',
		);

		return $map[ $folder ] ?? '';
	}

	/**
	 * Best-effort check whether a shortcode slug appears in the main query / TB content.
	 *
	 * @param string $shortcode_tag Shortcode tag.
	 */
	private static function legacy_shortcode_likely_present( string $shortcode_tag ): bool {
		$needle = '[' . $shortcode_tag;
		$post   = get_post();

		if ( $post instanceof \WP_Post && str_contains( (string) $post->post_content, $needle ) ) {
			return true;
		}

		if ( class_exists( \DiviSupreme\Includes\DsmFrontendDynamicAssets::class ) ) {
			$base = \DiviSupreme\Includes\DsmFrontendDynamicAssets::get_base_page_content_for_detection();
			if ( '' !== $base && str_contains( $base, $needle ) ) {
				return true;
			}
		}

		return self::$modules_loaded && self::current_request_has_legacy_dsm_shortcodes();
	}

	/**
	 * Resolve module PHP files using the same toggle rules as {@see divi-4/includes/loader.php}.
	 *
	 * @param string $modules_dir Absolute path to divi-4/includes/modules.
	 * @return array<int, string>
	 */
	private static function get_module_files_to_load( string $modules_dir ): array {
		$divi_modules = get_option( 'dsm_modules', array() );
		$files        = array();

		if ( empty( $divi_modules ) || ! is_array( $divi_modules ) ) {
			$module_files = glob( $modules_dir . '/*/*.php' );

			if ( ! is_array( $module_files ) ) {
				return array();
			}

			foreach ( $module_files as $module_file ) {
				if ( $module_file && preg_match( '/\/modules\/\b([^\/]+)\/\1\.php$/', $module_file ) ) {
					$files[] = $module_file;
				}
			}

			return $files;
		}

		$child_map = array(
			'AdvancedTabs'        => 'AdvancedTabsChild',
			'BusinessHours'       => 'BusinessHoursChild',
			'CardCarousel'        => 'CardCarouselChild',
			'CircleInfo'          => 'CircleInfoChild',
			'ContentTimeLine'     => 'ContentTimeLineChild',
			'Faq'                 => 'FaqChild',
			'FlipBoxPerk'         => 'FlipBoxPerkChild',
			'FloatingMultiImages' => 'FloatingMultiImagesChild',
			'IconList'            => 'IconListChild',
			'ImageAccordion'      => 'ImageAccordionChild',
			'ImageHotSpots'       => 'ImageHotSpotsChild',
			'PriceList'           => 'PriceListChild',
			'SocialShareButtons'  => 'SocialShareButtonsChild',
		);

		foreach ( $divi_modules as $module => $toggle ) {
			if ( 'on' !== $toggle || ! is_string( $module ) ) {
				continue;
			}

			$parent = $modules_dir . '/' . $module . '/' . $module . '.php';

			if ( is_readable( $parent ) ) {
				$files[] = $parent;
			}

			if ( isset( $child_map[ $module ] ) ) {
				$child = $modules_dir . '/' . $child_map[ $module ] . '/' . $child_map[ $module ] . '.php';

				if ( is_readable( $child ) ) {
					$files[] = $child;
				}
			}
		}

		return $files;
	}

	/**
	 * Deregister a script handle (if present) and register the Divi 4 source.
	 *
	 * @param string             $handle  Script handle.
	 * @param string             $src     Absolute URL to the script.
	 * @param array<int, string> $deps    Dependencies.
	 * @param string             $version Version string.
	 * @return void
	 */
	private static function reregister_script( string $handle, string $src, array $deps, string $version ): void {
		if ( wp_script_is( $handle, 'registered' ) ) {
			wp_deregister_script( $handle );
		}

		wp_register_script( $handle, $src, $deps, $version, true );
	}

	/**
	 * Whether the current request is the Divi Visual Builder / frontend builder app.
	 */
	private static function is_divi_builder_app_request(): bool {
		if ( function_exists( 'et_core_is_fb_enabled' ) && et_core_is_fb_enabled() ) {
			return true;
		}

		if ( function_exists( 'et_builder_bfb_enabled' ) && et_builder_bfb_enabled() ) {
			return true;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only request detection.
		if ( isset( $_GET['et_fb'] ) || isset( $_GET['et_bfb'] ) ) {
			return true;
		}

		return false;
	}
}
