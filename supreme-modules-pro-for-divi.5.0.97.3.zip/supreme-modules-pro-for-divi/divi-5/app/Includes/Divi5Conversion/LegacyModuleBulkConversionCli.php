<?php
/**
 * WP-CLI command for bulk legacy Supreme module conversion.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Includes\Divi5Conversion;

/**
 * `wp dsm convert-legacy` for agencies managing many sites.
 */
final class LegacyModuleBulkConversionCli {


	/**
	 * Register the WP-CLI command when available.
	 *
	 * @return void
	 */
	public static function register(): void {
		if ( ! defined( 'WP_CLI' ) || ! WP_CLI || ! class_exists( '\WP_CLI' ) ) {
			return;
		}

		\WP_CLI::add_command( 'dsm convert-legacy', array( self::class, 'convert_legacy' ) );
	}

	/**
	 * Re-save legacy shortcode-module layouts via Divi's builder save pipeline.
	 *
	 * ## OPTIONS
	 *
	 * [--dry-run]
	 * : Scan and simulate re-save without writing to the database.
	 *
	 * [--batch-size=<n>]
	 * : Posts processed per internal batch (default: 5).
	 *
	 * [--scan-only]
	 * : Only report how many items contain legacy modules.
	 *
	 * [--ids=<ids>]
	 * : Comma-separated post IDs to re-save (must match scan results). Omit to re-save all.
	 *
	 * [--diagnose=<id>]
	 * : Inspect one post ID (read-only). Reports stored legacy vs native Supreme blocks.
	 *
	 * ## EXAMPLES
	 *
	 * wp dsm convert-legacy --scan-only
	 * wp dsm convert-legacy --diagnose=123
	 * wp dsm convert-legacy --dry-run --ids=12,34
	 * wp dsm convert-legacy --batch-size=10
	 *
	 * @param array<int, string>   $args       Positional arguments.
	 * @param array<string, mixed> $assoc_args Associative arguments.
	 * @return void
	 */
	public static function convert_legacy( array $args, array $assoc_args ): void {
		unset( $args );

		$scan = LegacyModuleBulkConversion::scan();

		if ( isset( $assoc_args['scan-only'] ) ) {
			\WP_CLI::log( sprintf( 'Found %d item(s) with Supreme modules needing attention.', $scan['total'] ) );

			$by_reason = isset( $scan['by_reason'] ) && is_array( $scan['by_reason'] ) ? $scan['by_reason'] : array();

			if ( array() !== $by_reason ) {
				\WP_CLI::log(
					sprintf(
						'  Legacy conversion: %d · Builder re-save only: %d',
						(int) ( $by_reason['legacy_conversion'] ?? 0 ),
						(int) ( $by_reason['builder_resave'] ?? 0 )
					)
				);
			}

			foreach ( $scan['by_type'] as $type => $count ) {
				\WP_CLI::log( sprintf( '  %s: %d', $type, $count ) );
			}

			return;
		}

		if ( isset( $assoc_args['diagnose'] ) ) {
			$post_id = absint( $assoc_args['diagnose'] );

			if ( $post_id <= 0 ) {
				\WP_CLI::error( 'Provide a valid post ID: --diagnose=123' );
			}

			$report = LegacyShortcodeConversionService::diagnose_post( $post_id );

			if ( isset( $report['error'] ) ) {
				\WP_CLI::error( (string) $report['error'] );
			}

			\WP_CLI::log( wp_json_encode( $report, JSON_PRETTY_PRINT ) );
			\WP_CLI::success( 'Diagnosis complete (read-only).' );

			return;
		}

		$dry_run      = isset( $assoc_args['dry-run'] );
		$batch_size   = isset( $assoc_args['batch-size'] ) ? max( 1, (int) $assoc_args['batch-size'] ) : LegacyModuleBulkConversion::DEFAULT_BATCH_SIZE;
		$selected_ids = self::parse_ids_argument( $assoc_args['ids'] ?? null );

		if ( array() !== $selected_ids ) {
			$scan['items']   = LegacyModuleBulkConversion::filter_scan_items( $scan['items'], $selected_ids );
			$scan['total']   = count( $scan['items'] );
			$scan['by_type'] = LegacyModuleBulkConversion::summarize_items_by_type( $scan['items'] );
		}

		if ( 0 === $scan['total'] ) {
			\WP_CLI::success( 'No legacy Supreme modules found. Nothing to re-save.' );

			return;
		}

		\WP_CLI::log( sprintf( 'Starting re-save for %d item(s)%s…', $scan['total'], $dry_run ? ' (dry run)' : '' ) );

		$job = LegacyModuleBulkConversion::run_all( $dry_run, $batch_size, $selected_ids );

		\WP_CLI::log( sprintf( 'Processed: %d', (int) ( $job['processed'] ?? 0 ) ) );
		\WP_CLI::log( sprintf( 'Re-saved: %d', (int) ( $job['converted'] ?? 0 ) ) );
		\WP_CLI::log( sprintf( 'Skipped: %d', (int) ( $job['skipped'] ?? 0 ) ) );

		$failed = isset( $job['failed'] ) && is_array( $job['failed'] ) ? $job['failed'] : array();

		if ( array() !== $failed ) {
			\WP_CLI::warning( sprintf( '%d item(s) failed:', count( $failed ) ) );

			foreach ( $failed as $failure ) {
				if ( ! is_array( $failure ) ) {
					continue;
				}

				\WP_CLI::log(
					sprintf(
						'  #%d %s (%s): %s',
						(int) ( $failure['id'] ?? 0 ),
						(string) ( $failure['title'] ?? '' ),
						(string) ( $failure['post_type'] ?? '' ),
						(string) ( $failure['message'] ?? '' )
					)
				);
			}
		}

		if ( 'complete' === ( $job['status'] ?? '' ) ) {
			\WP_CLI::success( 'Bulk legacy re-save finished.' );
		} else {
			\WP_CLI::warning( sprintf( 'Job ended with status: %s', (string) ( $job['status'] ?? 'unknown' ) ) );
		}
	}

	/**
	 * Parse IDs argument.
	 *
	 * @param mixed $raw_ids Comma-separated post IDs from CLI.
	 * @return array<int, int>
	 */
	private static function parse_ids_argument( $raw_ids ): array {
		if ( ! is_string( $raw_ids ) || '' === trim( $raw_ids ) ) {
			return array();
		}

		$parts = array_map( 'trim', explode( ',', $raw_ids ) );

		return array_values( array_filter( array_map( 'absint', $parts ) ) );
	}
}
