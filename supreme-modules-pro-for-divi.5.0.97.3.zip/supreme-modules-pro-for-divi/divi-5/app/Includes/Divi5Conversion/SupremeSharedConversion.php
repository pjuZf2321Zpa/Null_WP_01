<?php
/**
 * Shared D4→D5 conversion hooks for Divi Supreme Pro (single entry point).
 *
 * Bundles:
 * - {@see self::register_value_expansion_map()} — outline `valueExpansionFunctionMap` (`module_id`, `module_class`).
 * - {@see self::post_convert_additional_modules()} — per-module defaults / shapes (priority 10).
 * - {@see self::post_convert_lottie_remote_import_late()} — Lottie external JSON sideload retry (priority 88).
 * - {@see self::post_convert_post_carousel_readmore_finalize()} — readmore custom-styles toggle (priority 97).
 * - {@see self::post_convert_merge_decoration_attributes()} — CSS ID/class + Supreme Custom Attrs merge for `dsm/*` and native `divi/*` (priority 99).
 * - {@see self::deprecate_dsm_extension_custom_attribute_d4_attrs()} — D4 Supreme Custom Attributes props (never unknownAttributes) for `dsm/*` + `divi/*`.
 * - {@see self::post_convert_d4_popup_extension()} — `dsm_modules_popup*` → Supreme Popup (`use_popup` / `popup_layout`).
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Includes\Divi5Conversion;

/**
 * Registers shared migrator filters previously split across multiple classes.
 */
final class SupremeSharedConversion {


	/**
	 * Modules handled by {@see self::post_convert_additional_modules()}.
	 *
	 * @var list<string>
	 */
	private const ADDITIONAL_MODULE_NAMES = array(
		'dsm/dual-heading',
		'dsm/lottie',
		'dsm/random-image',
		'dsm/scroll-image',
		'dsm/star-rating',
		'dsm/mask-text',
		'dsm/perspective-image',
		'dsm/block-reveal-text',
		'dsm/block-reveal-image',
		'dsm/text-divider',
		'dsm/text-path',
		'dsm/icon-divider',
		'dsm/glitch-text',
		'dsm/image-accordion-child',
		'dsm/social-share-buttons-child',
		'dsm/image-hover-reveal',
		'dsm/masonry-gallery',
		'dsm/flipbox',
		'dsm/flipbox-child',
		'dsm/card',
		'dsm/card-carousel',
		'dsm/card-carousel-child',
		'dsm/post-carousel',
		'dsm/blog-carousel',
		'dsm/image-hotspots',
		'dsm/image-hotspots-child',
		'dsm/image-hotspot',
		'dsm/image-hotspot-child',
		'dsm/image-text-reveal',
		'dsm/circle-info',
		'dsm/circle-info-child',
		'dsm/icon-list-child',
		'dsm/content-timeline-child',
		'dsm/filterable-gallery',
		'dsm/faq',
		'dsm/faq-child',
		'dsm/chart',
		'dsm/chart-item',
		'dsm/price-list',
		'dsm/price-list-child',
	);

	/**
	 * Wire all shared conversion filters.
	 *
	 * @return void
	 */
	public static function register(): void {
		add_filter(
			'divi.moduleLibrary.conversion.valueExpansionFunctionMap',
			array( self::class, 'register_value_expansion_map' ),
			10,
			1
		);

		add_filter(
			'divi_conversion_deprecated_attribute',
			array( self::class, 'deprecate_post_carousel_dynamic_taxonomy_attrs' ),
			10,
			4
		);

		add_filter(
			'divi_conversion_deprecated_attribute',
			array( self::class, 'deprecate_circle_info_runtime_attrs' ),
			11,
			4
		);

		add_filter(
			'divi_conversion_deprecated_attribute',
			array( self::class, 'deprecate_contact_form7_legacy_input_background_attr' ),
			12,
			4
		);

		add_filter(
			'divi_conversion_deprecated_attribute',
			array( self::class, 'deprecate_dsm_modules_popup_d4_attrs' ),
			13,
			4
		);

		add_filter(
			'divi_conversion_deprecated_attribute',
			array( self::class, 'deprecate_filterable_gallery_d4_legacy_attrs' ),
			13,
			4
		);

		add_filter(
			'divi_conversion_deprecated_attribute',
			array( ContentToggleConversion::class, 'deprecate_d4_legacy_attrs' ),
			13,
			4
		);

		add_filter(
			'divi_conversion_deprecated_attribute',
			array( self::class, 'deprecate_dsm_extension_custom_attribute_d4_attrs' ),
			14,
			4
		);

		add_filter(
			'divi.conversion.postConvertAttrs',
			array( self::class, 'post_convert_d4_popup_extension' ),
			7,
			4
		);

		add_filter(
			'divi.conversion.postConvertAttrs',
			array( self::class, 'post_convert_contact_form7' ),
			8,
			4
		);

		add_filter(
			'divi.conversion.postConvertAttrs',
			array( ContentToggleConversion::class, 'post_convert_filter' ),
			9,
			4
		);

		add_filter(
			'divi.conversion.postConvertAttrs',
			array( self::class, 'post_convert_additional_modules' ),
			10,
			4
		);

		add_filter(
			'divi.conversion.postConvertAttrs',
			array( self::class, 'post_convert_lottie_remote_import_late' ),
			88,
			4
		);

		add_filter(
			'divi.conversion.postConvertAttrs',
			array( self::class, 'post_convert_post_carousel_readmore_finalize' ),
			97,
			4
		);

		add_filter(
			'divi.conversion.postConvertAttrs',
			array( self::class, 'post_convert_merge_decoration_attributes' ),
			99,
			4
		);
	}

	/**
	 * Late pass: ensure D5 readmore `decoration.button.*.value.enable` matches D4 `custom_readmore` / migrated decoration.
	 *
	 * @param array<string, mixed> $converted_attrs       Converted block attrs.
	 * @param string               $module_name           Module name.
	 * @param array<string, mixed> $attrs                 Original D4 shortcode attrs.
	 * @param bool                 $is_preset_conversion Preset conversion flag.
	 * @return array<string, mixed>
	 */
	public static function post_convert_post_carousel_readmore_finalize( $converted_attrs, $module_name, $attrs, $is_preset_conversion ) {
		unset( $is_preset_conversion );

		if ( ! is_array( $converted_attrs ) || ! is_array( $attrs ) ) {
			return $converted_attrs;
		}

		if ( 'dsm/post-carousel' !== $module_name && 'dsm/blog-carousel' !== $module_name ) {
			return $converted_attrs;
		}

		ConversionAttrs::finalize_post_carousel_readmore_button_enable( $converted_attrs, $attrs );

		return $converted_attrs;
	}

	/**
	 * Register value expansion map.
	 *
	 * @param array<string, callable|string> $map Divi conversion expansion map.
	 * @return array<string, callable|string>
	 */
	public static function register_value_expansion_map( $map ) {
		if ( ! is_array( $map ) ) {
			return $map;
		}

		$map['dsm_convert_module_id_to_decoration_attributes']    = array( self::class, 'expand_module_id' );
		$map['dsm_convert_module_class_to_decoration_attributes'] = array( self::class, 'expand_module_class' );

		return $map;
	}

	/**
	 * Drop D4 `dsm_include_{post_type}_{taxonomy}` from migrator mapping so they are not treated as unknownAttributes.
	 *
	 * Values are merged into `term_ids` in {@see PostCarouselConversionHelper::hydrate_term_ids_from_d4()} from original attrs.
	 *
	 * @param bool                 $should_deprecate Whether ET already marked this attribute deprecated.
	 * @param string               $desktop_name     Base attribute name (no responsive/hover suffix).
	 * @param string               $module_name      D5 module name.
	 * @param array<string, mixed> $attrs            Full D4 shortcode attributes.
	 * @return bool
	 */
	public static function deprecate_post_carousel_dynamic_taxonomy_attrs( $should_deprecate, $desktop_name, $module_name, $attrs ) {
		unset( $attrs );

		if ( $should_deprecate ) {
			return true;
		}

		if ( 'dsm/post-carousel' !== $module_name || ! is_string( $desktop_name ) ) {
			return false;
		}

		if ( str_starts_with( $desktop_name, 'dsm_include_' ) ) {
			return true;
		}

		return false;
	}

	/**
	 * D4 color-alpha background attrs are merged into element `decoration.background` in post-convert.
	 *
	 * @param bool                 $should_deprecate Whether ET already marked this attribute deprecated.
	 * @param string               $desktop_name     Base attribute name.
	 * @param string               $module_name      D5 module name.
	 * @param array<string, mixed> $attrs            Full D4 shortcode attributes.
	 * @return bool
	 */
	public static function deprecate_contact_form7_legacy_input_background_attr( $should_deprecate, $desktop_name, $module_name, $attrs ) {
		unset( $attrs );

		if ( $should_deprecate ) {
			return true;
		}

		if ( 'dsm/contact-form7' !== $module_name || ! is_string( $desktop_name ) ) {
			return false;
		}

		static $legacy = array(
			'input_background_color',
			'file_background_color',
			'error_msg_background_color',
			'validation_error_background_color',
			'validation_success_background_color',
		);

		return in_array( $desktop_name, $legacy, true );
	}

	/**
	 * Contact Form 7: map legacy field background color into native Background decoration.
	 *
	 * @param array<string, mixed> $converted_attrs       Converted block attrs.
	 * @param string               $module_name           Module name.
	 * @param array<string, mixed> $attrs                 Original D4 shortcode attrs.
	 * @param bool                 $is_preset_conversion Preset conversion flag.
	 * @return array<string, mixed>
	 */
	public static function post_convert_contact_form7( $converted_attrs, $module_name, $attrs, $is_preset_conversion ) {
		unset( $is_preset_conversion );

		if ( ! is_array( $converted_attrs ) || ! is_array( $attrs ) ) {
			return $converted_attrs;
		}

		if ( 'dsm/contact-form7' !== $module_name ) {
			return $converted_attrs;
		}

		ConversionAttrs::migrate_contact_form7_d4_legacy_background_colors( $converted_attrs, $attrs );

		return $converted_attrs;
	}

	/**
	 * Deprecate Divi 4 global Supreme popup shortcode attributes so they are not treated as unknownAttributes.
	 *
	 * Populated on all DSM modules (`dsm_modules_popup*`, `dsm_modules_overlay*` when popup was on). Conversion
	 * is applied in {@see self::post_convert_d4_popup_extension()}.
	 *
	 * @param bool                 $should_deprecate Whether ET already marked this attribute deprecated.
	 * @param string               $desktop_name     Base attribute name (no responsive/hover suffix).
	 * @param string               $module_name      D5 module name.
	 * @param array<string, mixed> $attrs            Full D4 shortcode attributes.
	 * @return bool
	 */
	public static function deprecate_dsm_modules_popup_d4_attrs( $should_deprecate, $desktop_name, $module_name, $attrs ) {
		if ( $should_deprecate ) {
			return true;
		}

		if ( ! is_string( $module_name ) || ! str_starts_with( $module_name, 'dsm/' ) ) {
			return false;
		}

		if ( ! is_string( $desktop_name ) ) {
			return false;
		}

		if ( str_starts_with( $desktop_name, 'dsm_modules_popup' ) ) {
			return true;
		}

		// Close-button chrome lives under Custom CSS → Visibility when popup is on (not `dsm_modules_popup_*`).
		if ( str_starts_with( $desktop_name, 'dsm_modules_close' ) ) {
			return true;
		}

		if ( str_starts_with( $desktop_name, 'dsm_modules_overlay' ) && isset( $attrs['dsm_modules_popup'] ) && 'on' === $attrs['dsm_modules_popup'] ) {
			return true;
		}

		return false;
	}

	/**
	 * Map D4 `dsm_modules_popup*` into D5 Supreme Popup extension attrs and sync Library layout meta when needed.
	 *
	 * @param array<string, mixed> $converted_attrs       Converted block attrs.
	 * @param string               $module_name           Module name.
	 * @param array<string, mixed> $attrs                 Original D4 shortcode attrs.
	 * @param bool                 $is_preset_conversion Preset conversion flag.
	 * @return array<string, mixed>
	 */
	public static function post_convert_d4_popup_extension( $converted_attrs, $module_name, $attrs, $is_preset_conversion ) {
		unset( $is_preset_conversion );

		if ( ! is_array( $converted_attrs ) || ! is_array( $attrs ) ) {
			return $converted_attrs;
		}

		if ( ! is_string( $module_name ) || ! str_starts_with( $module_name, 'dsm/' ) ) {
			return $converted_attrs;
		}

		ConversionAttrs::migrate_d4_modules_popup_into_supreme_popup_extension( $converted_attrs, $attrs );
		ConversionAttrs::sanitize_supreme_popup_extension_after_d4_migration( $converted_attrs, $attrs );

		return $converted_attrs;
	}

	/**
	 * Mark D4 Supreme Pro Custom Attributes extension props so they are migrated in post-convert, not surfaced as unknownAttributes.
	 *
	 * @param bool                 $should_deprecate Whether ET already marked deprecated.
	 * @param string               $desktop_name     Base desktop attribute name.
	 * @param string               $module_name      D5 module name.
	 * @param array<string, mixed> $attrs            Full D4 shortcode attributes.
	 * @return bool
	 */
	public static function deprecate_dsm_extension_custom_attribute_d4_attrs( $should_deprecate, $desktop_name, $module_name, $attrs ) {
		unset( $attrs );

		if ( $should_deprecate ) {
			return true;
		}

		if (
			! is_string( $module_name )
			|| ( ! str_starts_with( $module_name, 'dsm/' ) && ! str_starts_with( $module_name, 'divi/' ) )
		) {
			return false;
		}

		if ( ! is_string( $desktop_name ) ) {
			return false;
		}

		static $legacy = array(
			'dsm_modules_custom_attribute_on_off',
			'dsm_modules_custom_attribute_add',
			'dsm_modules_custom_attribute_css_selector',
			'dsm_custom_attributes_options',
		);

		return in_array( $desktop_name, $legacy, true );
	}

	/**
	 * Drop D4-only / runtime shortcode attributes that have no D5 equivalent (avoids migrator noise on Circle Info).
	 *
	 * @param bool                 $should_deprecate Whether ET already marked this attribute deprecated.
	 * @param string               $desktop_name     Base attribute name (no responsive/hover suffix).
	 * @param string               $module_name      D5 module name.
	 * @param array<string, mixed> $attrs            Full D4 shortcode attributes.
	 * @return bool
	 */

	/**
	 * Drop D4-only Filterable Gallery attrs handled elsewhere (fonts, borders, meta).
	 *
	 * @param bool                 $should_deprecate Whether ET already marked this attribute deprecated.
	 * @param string               $desktop_name     Base attribute name (no responsive/hover suffix).
	 * @param string               $module_name      D5 module name.
	 * @param array<string, mixed> $attrs            Full D4 shortcode attributes.
	 * @return bool
	 */
	public static function deprecate_filterable_gallery_d4_legacy_attrs( $should_deprecate, $desktop_name, $module_name, $attrs ) {
		unset( $attrs );

		if ( $should_deprecate ) {
			return true;
		}

		if ( ! is_string( $desktop_name ) || 'dsm/filterable-gallery' !== $module_name ) {
			return false;
		}

		static $deprecated = array(
			'global_colors_info',
			'_builder_version',
			'_module_preset',
			'text_shadow_style',
			'text_shadow_horizontal_length',
			'text_shadow_vertical_length',
			'text_shadow_blur_strength',
			'text_shadow_color',
		);

		if ( in_array( $desktop_name, $deprecated, true ) ) {
			return true;
		}

		if ( str_starts_with( $desktop_name, 'border_radii_' ) ) {
			return true;
		}

		if ( preg_match( '/^(header|dsm_caption|dsm_description|dsm_category|dsm_pagination|dsm_load_more)_(font|font_size|font_last_edited|text_color|text_align|line_height|letter_spacing)/', $desktop_name ) ) {
			return true;
		}

		return false;
	}

	/**
	 * Deprecate circle info runtime attrs.
	 *
	 * @param mixed $should_deprecate Should deprecate.
	 * @param mixed $desktop_name     Desktop name.
	 * @param mixed $module_name      Module name.
	 * @param mixed $attrs            Attrs.
	 */
	public static function deprecate_circle_info_runtime_attrs( $should_deprecate, $desktop_name, $module_name, $attrs ) {
		unset( $attrs );

		if ( $should_deprecate ) {
			return true;
		}

		if ( ! is_string( $desktop_name ) ) {
			return false;
		}

		if ( ! in_array( $module_name, array( 'dsm/circle-info', 'dsm/circle-info-child' ), true ) ) {
			return false;
		}

		static $deprecated = array(
			'global_colors_info',
			'parentorderclass',
			'totalcount',
			'itemindex',
			'_builder_version',
			'_module_preset',
		);

		return in_array( $desktop_name, $deprecated, true );
	}

	/**
	 * Map D4 `module_id` to decoration attributes row (see ET custom attributes tutorial).
	 *
	 * @param mixed $value   Raw shortcode value.
	 * @param array $context Context passed by Divi (desktopName, moduleName, viewport, state).
	 * @return array<string, array<string, string>>|array<string, mixed>
	 */
	public static function expand_module_id( $value, $context ) {
		unset( $context );

		if ( ! is_string( $value ) || '' === $value ) {
			return array();
		}

		return array(
			'attributes.0' => array(
				'id'            => uniqid( 'dsm-id-', true ),
				'name'          => 'id',
				'value'         => $value,
				'adminLabel'    => 'CSS ID',
				'targetElement' => '',
			),
		);
	}

	/**
	 * Map D4 `module_class` to decoration attributes row.
	 *
	 * @param mixed $value   Raw shortcode value.
	 * @param array $context Context passed by Divi.
	 * @return array<string, array<string, string>>|array<string, mixed>
	 */
	public static function expand_module_class( $value, $context ) {
		unset( $context );

		if ( ! is_string( $value ) || '' === $value ) {
			return array();
		}

		return array(
			'attributes.1' => array(
				'id'            => uniqid( 'dsm-class-', true ),
				'name'          => 'class',
				'value'         => $value,
				'adminLabel'    => 'CSS Class',
				'targetElement' => '',
			),
		);
	}

	/**
	 * Per-module post-convert fixes (dual heading, scroll/random image, text modules, icon-divider).
	 *
	 * @param array<string, mixed> $converted_attrs       Converted block attrs.
	 * @param string               $module_name          Module name.
	 * @param array<string, mixed> $attrs                Original D4 shortcode attrs.
	 * @param bool                 $is_preset_conversion Preset conversion flag.
	 * @return array<string, mixed>
	 */
	public static function post_convert_additional_modules( $converted_attrs, $module_name, $attrs, $is_preset_conversion ) {
		unset( $is_preset_conversion );

		if ( ! is_array( $converted_attrs ) || ! is_array( $attrs ) ) {
			return $converted_attrs;
		}

		if ( ! in_array( $module_name, self::ADDITIONAL_MODULE_NAMES, true ) ) {
			return $converted_attrs;
		}

		if ( 'dsm/icon-divider' === $module_name ) {
			ConversionAttrs::normalize_upload_inner_content_to_object_value( $converted_attrs, 'image' );
		}

		if ( 'dsm/faq' === $module_name || 'dsm/faq-child' === $module_name ) {
			ConversionAttrs::migrate_faq_toggle_legacy_inner_content_color_into_decoration_background( $converted_attrs );
		}

		if ( 'dsm/faq-child' === $module_name ) {
			ConversionAttrs::normalize_heading_level_from_d4( $converted_attrs, $attrs, 'header_item', 'header_item_level', 'h4' );
		}

		if ( 'dsm/lottie' === $module_name ) {
			ConversionAttrs::hydrate_lottie_url_from_d4_shortcode_attrs( $converted_attrs, $attrs );
			ConversionAttrs::normalize_upload_inner_content_to_object_value( $converted_attrs, 'lottie_url' );
			ConversionAttrs::sideload_external_lottie_json_urls( $converted_attrs );
		}

		if ( 'dsm/text-path' === $module_name ) {
			ConversionAttrs::normalize_inner_value_to_heading_link_text_shape( $converted_attrs, 'dsm_path_text' );
			ConversionAttrs::apply_text_path_d4_defaults( $converted_attrs, $attrs );
		}

		if ( 'dsm/scroll-image' === $module_name ) {
			ConversionAttrs::migrate_scroll_image_title_from_d4_to_decoration( $converted_attrs, $attrs );
			ConversionAttrs::apply_scroll_image_d4_defaults( $converted_attrs, $attrs );
		}

		if ( 'dsm/random-image' === $module_name ) {
			ConversionAttrs::apply_random_image_d4_defaults( $converted_attrs, $attrs );
		}

		if ( 'dsm/text-divider' === $module_name ) {
			ConversionAttrs::apply_text_divider_d4_defaults( $converted_attrs, $attrs );
		}

		if ( 'dsm/star-rating' === $module_name ) {
			ConversionAttrs::normalize_heading_level_from_d4( $converted_attrs, $attrs, 'title', 'header_level', 'h4' );
		}

		if ( 'dsm/mask-text' === $module_name ) {
			ConversionAttrs::normalize_upload_inner_content_to_object_value( $converted_attrs, 'image' );
		}

		if ( 'dsm/perspective-image' === $module_name ) {
			ConversionAttrs::normalize_upload_inner_content_to_object_value( $converted_attrs, 'src' );
			ConversionAttrs::normalize_upload_inner_content_to_object_value( $converted_attrs, 'show_lightbox_other_img_src' );
			ConversionAttrs::merge_perspective_image_alt_title_into_src( $converted_attrs );
			ConversionAttrs::migrate_perspective_image_alt_title_from_d4_to_decoration( $converted_attrs, $attrs );
			ConversionAttrs::consolidate_perspective_image_alt_title_into_decoration( $converted_attrs );
		}

		if ( 'dsm/block-reveal-text' === $module_name ) {
			ConversionAttrs::normalize_inner_value_to_heading_link_text_shape( $converted_attrs, 'block_reveal_text' );
		}

		if ( 'dsm/block-reveal-image' === $module_name ) {
			ConversionAttrs::normalize_upload_inner_content_to_object_value( $converted_attrs, 'src' );
			ConversionAttrs::normalize_upload_inner_content_to_object_value( $converted_attrs, 'show_lightbox_other_img_src' );
		}

		if ( 'dsm/glitch-text' === $module_name ) {
			ConversionAttrs::normalize_heading_level_from_d4( $converted_attrs, $attrs, 'header', 'header_level', 'h1' );
			ConversionAttrs::merge_module_advanced_link_into_heading_link_element( $converted_attrs, 'glitch_text' );
		}

		if ( 'dsm/image-accordion-child' === $module_name ) {
			ConversionAttrs::hydrate_image_accordion_child_uploads_from_d4( $converted_attrs, $attrs );
			ConversionAttrs::normalize_upload_inner_content_to_object_value( $converted_attrs, 'image_accordion_src' );
			ConversionAttrs::normalize_upload_inner_content_to_object_value( $converted_attrs, 'image_accordion_icon_image' );
			ConversionAttrs::normalize_flipbox_rich_content_inner_content_for_vb( $converted_attrs, 'image_accordion_desc' );
		}

		if ( 'dsm/icon-list-child' === $module_name ) {
			ConversionAttrs::hydrate_icon_list_child_link_from_d4( $converted_attrs, $attrs );
			ConversionAttrs::normalize_upload_inner_content_to_object_value( $converted_attrs, 'image' );
			ConversionAttrs::normalize_flipbox_rich_content_inner_content_for_vb( $converted_attrs, 'content' );
		}

		if ( 'dsm/content-timeline-child' === $module_name ) {
			ConversionAttrs::normalize_upload_inner_content_to_object_value( $converted_attrs, 'dsm_image' );
			ConversionAttrs::normalize_upload_inner_content_to_object_value( $converted_attrs, 'dsm_point_image' );
		}

		if ( 'dsm/price-list-child' === $module_name ) {
			ConversionAttrs::normalize_upload_inner_content_to_object_value( $converted_attrs, 'image' );
			ConversionAttrs::hydrate_price_list_image_sizing_defaults_when_empty( $converted_attrs, $attrs );
			ConversionAttrs::normalize_inner_value_to_heading_link_text_shape( $converted_attrs, 'content' );
		}

		if ( 'dsm/price-list' === $module_name ) {
			ConversionAttrs::hydrate_price_list_image_sizing_defaults_when_empty( $converted_attrs, $attrs );
		}

		if ( 'dsm/circle-info' === $module_name ) {
			ConversionAttrs::ensure_circle_info_parent_layout_inner_content_defaults( $converted_attrs );
		}

		if ( 'dsm/circle-info-child' === $module_name ) {
			foreach ( array( 'dsm_circle_info_title', 'shortcode_content', 'dsm_content_title', 'dsm_circle_info_content', 'button_text', 'button_url', 'admin_title', 'alt' ) as $text_attr ) {
				ConversionAttrs::normalize_inner_value_to_heading_link_text_shape( $converted_attrs, $text_attr );
				ConversionAttrs::hydrate_inner_heading_link_text_from_d4_when_empty( $converted_attrs, $attrs, $text_attr );
			}
			ConversionAttrs::clear_circle_info_child_placeholder_text_when_d4_empty( $converted_attrs, $attrs );
			// D4 `tiny_mce` body — ensure VB RichText binds `innerContent.*.value.text`.
			ConversionAttrs::normalize_flipbox_rich_content_inner_content_for_vb( $converted_attrs, 'dsm_circle_info_content' );
			ConversionAttrs::normalize_upload_inner_content_to_object_value( $converted_attrs, 'image' );
			ConversionAttrs::normalize_upload_inner_content_to_object_value( $converted_attrs, 'dsm_content_image' );
			ConversionAttrs::ensure_circle_info_child_background_consolidated_on_module( $converted_attrs );
			ConversionAttrs::hydrate_circle_info_child_module_background_image_props_for_declaration_output( $converted_attrs );
		}

		if ( 'dsm/social-share-buttons-child' === $module_name ) {
			ConversionAttrs::normalize_upload_inner_content_to_object_value( $converted_attrs, 'src' );
		}

		if ( 'dsm/image-hover-reveal' === $module_name ) {
			ConversionAttrs::normalize_upload_inner_content_to_object_value( $converted_attrs, 'src' );
		}

		if ( 'dsm/image-text-reveal' === $module_name ) {
			ConversionAttrs::normalize_upload_inner_content_to_object_value( $converted_attrs, 'src' );
			ConversionAttrs::normalize_heading_level_from_d4( $converted_attrs, $attrs, 'reveal_text', 'reveal_text_level', 'h3' );
			ConversionAttrs::hydrate_image_text_reveal_animation_from_d4( $converted_attrs, $attrs );
		}

		if ( 'dsm/masonry-gallery' === $module_name ) {
			ConversionAttrs::normalize_heading_level_from_d4( $converted_attrs, $attrs, 'image_title_font', 'image_title_level', 'h4' );
		}

		if ( 'dsm/filterable-gallery' === $module_name ) {
			$converted_attrs = FilterableGalleryConversion::post_convert( $converted_attrs, $attrs );
		}

		if ( 'dsm/flipbox' === $module_name ) {
			ConversionAttrs::migrate_flipbox_d4_height_shortcode_into_module_sizing( $converted_attrs, $attrs );
			$converted_attrs = ConversionAttrs::merge_flipbox_legacy_height_into_module_sizing( $converted_attrs, true );
			ConversionAttrs::mirror_flipbox_phone_module_sizing_height_to_phone_wide_when_empty( $converted_attrs );
			ConversionAttrs::normalize_flipbox_rich_content_inner_content_for_vb( $converted_attrs );
			ConversionAttrs::normalize_inner_value_to_heading_link_text_shape( $converted_attrs, 'front_title' );
			ConversionAttrs::normalize_inner_value_to_heading_link_text_shape( $converted_attrs, 'back_title' );
			ConversionAttrs::hydrate_flipbox_face_shared_fonts_into_per_face_when_empty( $converted_attrs );
			ConversionAttrs::apply_flipbox_d4_parent_fonts_to_both_faces( $converted_attrs );
		}

		if ( 'dsm/card' === $module_name ) {
			ConversionAttrs::ensure_explicit_empty_upload_when_d4_had_no_image( $converted_attrs, $attrs, 'image' );
			ConversionAttrs::normalize_upload_inner_content_to_object_value( $converted_attrs, 'image' );
			ConversionAttrs::coerce_inner_desktop_toggle_on_off( $converted_attrs, 'button_url_new_window', 'off' );
		}

		if ( 'dsm/card-carousel-child' === $module_name ) {
			ConversionAttrs::normalize_flipbox_rich_content_inner_content_for_vb( $converted_attrs, 'content' );
			ConversionAttrs::normalize_inner_value_to_heading_link_text_shape( $converted_attrs, 'title' );
			ConversionAttrs::normalize_inner_value_to_heading_link_text_shape( $converted_attrs, 'subtitle' );
			ConversionAttrs::ensure_explicit_empty_upload_when_d4_had_no_image( $converted_attrs, $attrs, 'image' );
			ConversionAttrs::normalize_upload_inner_content_to_object_value( $converted_attrs, 'image' );
			ConversionAttrs::normalize_upload_inner_content_to_object_value( $converted_attrs, 'image_popup_src' );
			ConversionAttrs::normalize_upload_inner_content_to_object_value( $converted_attrs, 'button_image_src' );
			$d4_attrs = $attrs;
			if ( ( ! isset( $d4_attrs['header_level'] ) || '' === (string) $d4_attrs['header_level'] ) && isset( $d4_attrs['parent_header_level'] ) && '' !== (string) $d4_attrs['parent_header_level'] ) {
				$d4_attrs['header_level'] = $d4_attrs['parent_header_level'];
			}
			ConversionAttrs::normalize_heading_level_from_d4( $converted_attrs, $d4_attrs, 'title', 'header_level', 'h4' );
			// D4 Design → Button → "Show Button Icon" is `button_use_icon`; map to D5 `button.decoration.button.*.value.icon.enable` (same as flipbox-child).
			FlipboxChildMergeMigrator::sync_flipbox_child_button_icon_enable_from_d4_post_convert( $converted_attrs, $attrs );
		}

		if ( 'dsm/card-carousel' === $module_name || 'dsm/card-carousel-child' === $module_name ) {
			ConversionAttrs::hydrate_card_carousel_d4_hover_transition_into_module_decoration( $converted_attrs, $attrs );
		}

		if ( 'dsm/card-carousel' === $module_name ) {
			ConversionAttrs::hydrate_card_carousel_parent_text_group_from_d4( $converted_attrs, $attrs );
			ConversionAttrs::normalize_heading_level_from_d4( $converted_attrs, $attrs, 'title', 'header_level', 'h4' );
			// D4 `button_use_icon` → D5 `button.decoration.button.*.value.icon.enable` (parent carousel button element).
			FlipboxChildMergeMigrator::sync_flipbox_child_button_icon_enable_from_d4_post_convert( $converted_attrs, $attrs );
		}

		if ( 'dsm/post-carousel' === $module_name ) {
			PostCarouselConversionHelper::hydrate_term_ids_from_d4( $converted_attrs, $attrs );
			PostCarouselConversionHelper::hydrate_readmore_from_d4( $converted_attrs, $attrs );
			PostCarouselConversionHelper::normalize_title_heading_from_d4( $converted_attrs, $attrs );
		}

		if ( 'dsm/blog-carousel' === $module_name ) {
			ConversionAttrs::hydrate_blog_carousel_include_categories_from_d4( $converted_attrs, $attrs );
			PostCarouselConversionHelper::hydrate_readmore_from_d4( $converted_attrs, $attrs );
			PostCarouselConversionHelper::normalize_title_heading_from_d4( $converted_attrs, $attrs );
		}

		if ( 'dsm/flipbox-child' === $module_name ) {
			ConversionAttrs::normalize_upload_inner_content_to_object_value( $converted_attrs, 'image' );
			ConversionAttrs::normalize_flipbox_rich_content_inner_content_for_vb( $converted_attrs, 'content' );
			ConversionAttrs::normalize_inner_value_to_heading_link_text_shape( $converted_attrs, 'title' );
			FlipboxChildMergeMigrator::sync_flipbox_child_button_icon_enable_from_d4_post_convert( $converted_attrs, $attrs );
			FlipboxChildMergeMigrator::hydrate_flipbox_child_font_icon_after_conversion( $converted_attrs, $attrs );
		}

		if ( in_array( $module_name, array( 'dsm/image-hotspots', 'dsm/image-hotspot' ), true ) ) {
			ConversionAttrs::ensure_explicit_empty_upload_when_d4_had_no_image( $converted_attrs, $attrs, 'src' );
			ConversionAttrs::normalize_upload_inner_content_to_object_value( $converted_attrs, 'src' );
			ConversionAttrs::normalize_image_hotspot_hotspot_event_from_d4( $converted_attrs );
			ConversionAttrs::hydrate_d4_responsive_color_alpha_into_inner_content( $converted_attrs, $attrs, 'tooltip_background_color' );
		}

		if ( in_array( $module_name, array( 'dsm/image-hotspots-child', 'dsm/image-hotspot-child' ), true ) ) {
			ConversionAttrs::ensure_explicit_empty_upload_when_d4_had_no_image( $converted_attrs, $attrs, 'hotspot_img' );
			ConversionAttrs::normalize_upload_inner_content_to_object_value( $converted_attrs, 'hotspot_img' );
			// RichText VB binds `content.innerContent.*.value.text`; D4 migration often leaves a raw HTML string at `*.value`.
			ConversionAttrs::normalize_flipbox_rich_content_inner_content_for_vb( $converted_attrs, 'content' );
			ConversionAttrs::hydrate_d4_responsive_color_alpha_into_inner_content( $converted_attrs, $attrs, 'tooltip_background_color' );
		}

		if ( 'dsm/dual-heading' !== $module_name ) {
			return $converted_attrs;
		}

		ConversionAttrs::normalize_dual_heading_attrs( $converted_attrs, $attrs );

		return $converted_attrs;
	}

	/**
	 * Second pass for Lottie: re-hydrate from D4 attrs and sideload remote JSON after any earlier conversion steps.
	 *
	 * @param array<string, mixed> $converted_attrs       Converted block attrs.
	 * @param string               $module_name           Module name.
	 * @param array<string, mixed> $attrs                 Original D4 shortcode attrs.
	 * @param bool                 $is_preset_conversion Preset conversion flag.
	 * @return array<string, mixed>
	 */
	public static function post_convert_lottie_remote_import_late( $converted_attrs, $module_name, $attrs, $is_preset_conversion ) {
		unset( $is_preset_conversion );

		if ( 'dsm/lottie' !== $module_name || ! is_array( $converted_attrs ) || ! is_array( $attrs ) ) {
			return $converted_attrs;
		}

		ConversionAttrs::hydrate_lottie_url_from_d4_shortcode_attrs( $converted_attrs, $attrs );
		ConversionAttrs::normalize_upload_inner_content_to_object_value( $converted_attrs, 'lottie_url' );
		ConversionAttrs::sideload_external_lottie_json_urls( $converted_attrs );

		return $converted_attrs;
	}

	/**
	 * Finalize CSS ID / class and D4 Supreme Custom Attributes on migrated `dsm/*` and native `divi/*` blocks.
	 *
	 * @param array<string, mixed> $converted_attrs       Converted block attrs.
	 * @param string               $module_name          Module name.
	 * @param array<string, mixed> $attrs                Original D4 shortcode attrs.
	 * @param bool                 $is_preset_conversion Preset conversion flag.
	 * @return array<string, mixed>
	 */
	public static function post_convert_merge_decoration_attributes( $converted_attrs, $module_name, $attrs, $is_preset_conversion ) {
		unset( $is_preset_conversion );

		if ( ! is_string( $module_name ) ) {
			return $converted_attrs;
		}

		$is_dsm  = str_starts_with( $module_name, 'dsm/' );
		$is_divi = str_starts_with( $module_name, 'divi/' );

		if ( ! $is_dsm && ! $is_divi ) {
			return $converted_attrs;
		}

		if ( ! is_array( $converted_attrs ) || ! is_array( $attrs ) ) {
			return $converted_attrs;
		}

		if ( $is_dsm ) {
			if ( 'dsm/block-reveal-image' === $module_name || 'dsm/perspective-image' === $module_name ) {
				ConversionAttrs::migrate_block_reveal_image_align( $converted_attrs, $attrs );
			}

			if ( 'dsm/block-reveal-text' === $module_name ) {
				ConversionAttrs::migrate_block_reveal_text_heading_level_from_heading_html_tag( $converted_attrs );
				ConversionAttrs::migrate_block_reveal_text_header_text_align( $converted_attrs, $attrs );
			}

			if ( 'dsm/step-flow' === $module_name ) {
				ConversionAttrs::migrate_step_flow_direction_offset_ranges_from_d4( $converted_attrs, $attrs );
			}

			if ( 'dsm/typing-effect' === $module_name ) {
				ConversionAttrs::migrate_typing_effect_pipe_string_to_sortable_list( $converted_attrs, $attrs );
			}

			if ( 'dsm/image-accordion-child' === $module_name ) {
				ConversionAttrs::normalize_upload_inner_content_to_object_value( $converted_attrs, 'image_accordion_src' );
				ConversionAttrs::normalize_upload_inner_content_to_object_value( $converted_attrs, 'image_accordion_icon_image' );
				ConversionAttrs::normalize_flipbox_rich_content_inner_content_for_vb( $converted_attrs, 'image_accordion_desc' );
			}
		}

		if ( 'dsm/button' === $module_name ) {
			ConversionAttrs::merge_d4_button_elements_id_class_into_decoration_attributes( $converted_attrs, $attrs );
		} else {
			ConversionAttrs::merge_d4_module_id_class_into_decoration_attributes( $converted_attrs, $attrs );
		}

		ConversionAttrs::migrate_dsm_d4_extension_custom_attributes_into_decoration_attributes( $converted_attrs, $attrs, $module_name );

		return $converted_attrs;
	}
}
