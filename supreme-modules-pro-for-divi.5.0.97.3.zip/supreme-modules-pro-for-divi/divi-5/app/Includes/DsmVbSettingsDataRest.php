<?php
/**
 * Raise PHP memory for Divi Visual Builder settings-data REST (after-app-load).
 *
 * That GET hydrates fonts, shortcode definitions, taxonomies, and markups. DSP
 * increases the working set enough that the default frontend `WP_MEMORY_LIMIT`
 * (often 40M/128M) fatals with an empty 500 — the VB font dropdown then stays
 * empty. Confirmed on a customer site: `define( 'WP_MEMORY_LIMIT', '256M' )`
 * restored the payload. This hook applies the WordPress admin cap (default
 * `WP_MAX_MEMORY_LIMIT` 256M) to `/divi/v1/settings-data/*` only.
 *
 * Does not touch `/divi/v1/sync-to-server` ({@see DsmVbRestSave}).
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

// phpcs:disable WordPress.Files.FileName -- PSR-4 class name matches sibling Includes.

namespace DiviSupreme\Includes;

use WP_REST_Request;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Memory raise for Divi settings-data hydration REST routes.
 */
final class DsmVbSettingsDataRest {

	/**
	 * Register WordPress hooks.
	 *
	 * @return void
	 */
	public static function register_hooks(): void {
		add_filter( 'rest_pre_dispatch', array( self::class, 'filter_rest_pre_dispatch' ), 1, 3 );
	}

	/**
	 * Raise memory before Divi builds the after-app-load payload.
	 *
	 * @param mixed           $result  Dispatch result (null to continue).
	 * @param mixed           $server  REST server.
	 * @param WP_REST_Request $request Current request.
	 * @return mixed
	 */
	public static function filter_rest_pre_dispatch( $result, $server, $request ) {
		unset( $server );

		if ( ! $request instanceof WP_REST_Request || ! self::request_is_settings_data( $request ) ) {
			return $result;
		}

		if ( function_exists( 'wp_raise_memory_limit' ) ) {
			wp_raise_memory_limit( 'admin' );
		}

		return $result;
	}

	/**
	 * Whether a REST request is Divi Visual Builder settings-data.
	 *
	 * @param WP_REST_Request $request REST request.
	 * @return bool
	 */
	private static function request_is_settings_data( WP_REST_Request $request ): bool {
		$route = $request->get_route();

		return is_string( $route ) && str_starts_with( $route, '/divi/v1/settings-data/' );
	}
}
