<?php
/**
 * Includes.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Includes;

use WP_Scripts;

/**
 * Optional defer/async on Divi Supreme Pro frontend script tags (`dsm_settings_misc[dsm_defer_js_assets]`).
 *
 * Mirrors Divi 4 {@see \Dsm_Supreme_Modules_Pro_For_Divi::add_async_defer_attribute()} with Divi 5 handles,
 * narrowed with {@see wp_scripts()} source checks so only DSM-bundled (or trusted Divi Magnific) URLs are modified.
 *
 * @package DiviSupreme
 */
final class DsmDeferFrontendScripts {

	public const DSM_DEFER_FRONTEND_SCRIPT_HANDLES_FILTER = 'dsm_defer_frontend_script_handles';

	/**
	 * Request-scoped cache for {@see filtered_canonical_handles()}.
	 *
	 * @since 5.0.0
	 * @var array<int, string>|null
	 */
	private static $filtered_handle_cache = null;

	/**
	 * Register WordPress hooks.
	 *
	 * @since 5.0.0
	 * @return void
	 */
	public static function register_hooks(): void {
		add_filter( 'script_loader_tag', array( self::class, 'filter_script_loader_tag' ), 10, 2 );
	}

	/**
	 * Canonical defer handles — filter output must be a subset of this list only.
	 *
	 * @since 5.0.0
	 * @return array<int, string>
	 */
	private static function canonical_defer_handles(): array {
		return array(
			'magnific-popup',
			'dsm-magnific-popup',
			'dsm-typing-library',
			'dsm-typing',
			'dsm-twitter-embed',
			'dsm-splitting',
			'dsm-gsap',
			'dsm-vanilla-tilt',
			'dsm-tilt-image',
			'dsm-baffle',
			'dsm-swiper-library',
			'dsm-readmore',
			'dsm-popper',
			'dsm-tippy',
			'dsm-tooltip-frontend',
			'dsm-replace-me',
			'dsm-reveal-library',
			'dsm-before-after-library',
			'dsm-before-after-icv-mobile-fix',
			'dsm-before-after-slider',
			'dsm-lottie-frontend',
			'dsm-notation-library',
			'dsm-text-notation',
			'dsm-facebook',
			'dsm-image-hotspot',
			'dsm-page-tour',
			'dsm-icon-list',
			'dsm-text-rotator',
			'dsm-shuffle-letter',
			'dsm-block-reveal-text',
			'dsm-block-reveal-image',
			'dsm-card-carousel',
			'dsm-image-carousel',
			'dsm-text-reveal',
			'dsm-image-hover-reveal',
			'dsm-flipbox-click',
			'dsm-masonry-gallery',
			'dsm-content-toggle',
			'dsm-blog-carousel',
			'dsm-image-accordion',
			'dsm-post-carousel',
			'dsm-menu',
			'dsm-content-timeline',
			'dsm-social-share-button',
			'dsm-advanced-tabs',
			'dsm-progress-bar',
			'dsm-faq',
			'dsm-svg-animation',
			'dsm-filterable-gallery',
			'dsm-filterable-library-gallery',
			'dsm-circle-info',
			'dsm-popup-extension',
			'dsm-perspective-image',
			'dsm-random-image',
			'dsm-stacking-card',
			'dsm-scroll-header-animation',
			'dsm-animated-headline',
			'dsm-scroll-trigger',
			'dsm-lenis',
			'dsm-toc',
			'dsm-testimonials',
			'dsm-scroll-image',
		);
	}

	/**
	 * Resolved registered dependency source for comparison against DSM/Divi bundles.
	 *
	 * @since 5.0.0
	 * @param WP_Scripts $wp_scripts Registered scripts instance.
	 * @param string     $handle     Script handle.
	 * @return string Empty when not resolved.
	 */
	private static function get_registered_dependency_absolute_src( WP_Scripts $wp_scripts, string $handle ): string {
		$registered = isset( $wp_scripts->registered[ $handle ] ) ? $wp_scripts->registered[ $handle ] : null;

		if ( null === $registered || empty( $registered->src ) || ! is_string( $registered->src ) ) {
			return '';
		}

		$src = trim( $registered->src );

		if ( '' === $src ) {
			return '';
		}

		if ( preg_match( '#^https?:#i', $src ) ) {
			return esc_url_raw( $src );
		}

		if ( strpos( $src, '//' ) === 0 && function_exists( 'set_url_scheme' ) ) {
			return esc_url_raw( set_url_scheme( $src, is_ssl() ? 'https' : 'http' ) );
		}

		if ( strpos( $src, '/' ) === 0 ) {
			return esc_url_raw( home_url( $src ) );
		}

		$prefix = '';

		if ( is_string( $wp_scripts->base_url ) && '' !== $wp_scripts->base_url ) {
			$prefix = trailingslashit( $wp_scripts->base_url );

			return esc_url_raw( $prefix . ltrim( $src, '/' ) );
		}

		$dsm_entry = '';

		if ( defined( 'DSM_DIR_PATH' ) && is_string( DSM_DIR_PATH ) ) {
			$dsm_entry = DSM_DIR_PATH . 'supreme-modules-pro-for-divi.php';
		}

		if ( '' !== $dsm_entry && file_exists( $dsm_entry ) ) {
			return esc_url_raw( plugins_url( $src, $dsm_entry ) );
		}

		return '';
	}

	/**
	 * DSM divi-5 bundle URLs and Divi-registered Magnific Popup (same handle as DSM modules depend on).
	 *
	 * @since 5.0.0
	 * @param string $absolute_src Resolved script URL without query string normalization.
	 * @return bool
	 */
	private static function defer_src_is_owned_or_trusted( string $absolute_src ): bool {
		if ( '' === $absolute_src ) {
			return false;
		}

		$strip_q = strtolower( strtok( esc_url_raw( $absolute_src ), '?' ) );

		if ( defined( 'DSM_DIR_URL' ) && is_string( DSM_DIR_URL ) && DSM_DIR_URL !== '' ) {
			$dsm_base = strtolower( strtok( esc_url_raw( DSM_DIR_URL ), '?' ) );

			if ( '' !== $dsm_base && strpos( $strip_q, $dsm_base ) === 0 ) {
				return true;
			}
		}

		return ( strpos( $strip_q, 'magnific-popup' ) !== false || strpos( $strip_q, 'magnific_popup' ) !== false )
			&& (
				strpos( $strip_q, 'visual-builder' ) !== false
				|| strpos( $strip_q, 'dynamic-assets' ) !== false
			);
	}

	/**
	 * Filter return value intersected against {@see canonical_defer_handles()} so unknown handles are never deferred.
	 *
	 * @since 5.0.0
	 * @return array<int, string>
	 */
	private static function filtered_canonical_handles(): array {
		if ( null !== self::$filtered_handle_cache ) {
			return self::$filtered_handle_cache;
		}

		$base = self::canonical_defer_handles();

		if ( class_exists( DsmFrontendAssetRegistry::class ) ) {
			$layout_critical = array_fill_keys(
				DsmFrontendAssetRegistry::get_layout_critical_script_handles(),
				true
			);
			$base            = array_values(
				array_filter(
					$base,
					static function ( string $handle ) use ( $layout_critical ): bool {
						return ! isset( $layout_critical[ $handle ] );
					}
				)
			);
		}

		/**
		 * Value.
		 *
		 * @var array<int, mixed> $incoming
		 */
		$incoming = apply_filters( self::DSM_DEFER_FRONTEND_SCRIPT_HANDLES_FILTER, $base );

		if ( ! is_array( $incoming ) ) {
			self::$filtered_handle_cache = $base;

			return self::$filtered_handle_cache;
		}

		$allowed = array_fill_keys( $base, true );
		$subset  = array();

		foreach ( $incoming as $raw ) {
			if ( ! is_string( $raw ) || '' === $raw ) {
				continue;
			}

			$key = sanitize_key( $raw );

			if ( '' === $key || ! isset( $allowed[ $key ] ) ) {
				continue;
			}

			$subset[ $key ] = $key;
		}

		self::$filtered_handle_cache = array_values( $subset );

		return self::$filtered_handle_cache;
	}

	/**
	 * Twitter embed script URL allow-list (widgets.js from Twitter CDNs — not DSM-hosted).
	 *
	 * @since 5.0.0
	 * @param string $absolute_src Resolved script URL without query string.
	 * @return bool
	 */
	private static function twitter_embed_src_matches_known_widget_cdn( string $absolute_src ): bool {
		if ( '' === $absolute_src ) {
			return false;
		}

		$host = strtolower( (string) wp_parse_url( $absolute_src, PHP_URL_HOST ) );

		return in_array(
			$host,
			array(
				'platform.twitter.com',
				'syndication.twitter.com',
				'cdn.syndication.twimg.com',
			),
			true
		);
	}

	/**
	 * Canonical handle whitelist + `$src` must match DSM (or Magnific Popup from Divi/ET bundles).
	 *
	 * @since 5.0.0
	 * @param WP_Scripts $wp_scripts Script registry instance.
	 * @param string     $handle     Script handle.
	 * @return bool
	 */
	private static function may_modify_registered_script_markup( WP_Scripts $wp_scripts, string $handle ): bool {
		if ( '' === $handle ) {
			return false;
		}

		if ( ! in_array( $handle, self::filtered_canonical_handles(), true ) ) {
			return false;
		}

		$resolved = self::get_registered_dependency_absolute_src( $wp_scripts, $handle );

		return self::defer_src_is_owned_or_trusted( $resolved );
	}

	/**
	 * Facebook SDK async tweaks (defer off — Divi 4 parity) — only when `dsm-facebook` points at DSM bundles.
	 *
	 * @since 5.0.0
	 * @param WP_Scripts $wp_scripts Script registry instance.
	 * @param string     $handle     Script handle.
	 * @return bool
	 */
	private static function facebook_async_markup_eligible( WP_Scripts $wp_scripts, string $handle ): bool {
		if ( 'dsm-facebook' !== $handle ) {
			return false;
		}

		$resolved = self::get_registered_dependency_absolute_src( $wp_scripts, $handle );

		return '' !== $resolved && self::defer_src_is_owned_or_trusted( $resolved );
	}

	/**
	 * Twitter widgets async tweaks (defer off — Divi 4 parity) — only known widget CDNs or DSM bundle overrides.
	 *
	 * @since 5.0.0
	 * @param WP_Scripts $wp_scripts Script registry instance.
	 * @param string     $handle     Script handle.
	 * @return bool
	 */
	private static function twitter_async_markup_eligible( WP_Scripts $wp_scripts, string $handle ): bool {
		if ( 'dsm-twitter-embed' !== $handle ) {
			return false;
		}

		$resolved = self::get_registered_dependency_absolute_src( $wp_scripts, $handle );

		if ( '' === $resolved ) {
			return false;
		}

		return self::defer_src_is_owned_or_trusted( $resolved ) || self::twitter_embed_src_matches_known_widget_cdn( $resolved );
	}

	/**
	 * Filter `script_loader_tag` HTML for DSM-managed front-end bundles when the Misc option is ON.
	 *
	 * Option toggling is sanitized and saved via `wp_ajax_dsm_save_settings` (nonce + caps). This callback only reads.
	 *
	 * @since 5.0.0
	 * @param string $tag    Full enqueue tag.
	 * @param string $handle Registered handle.
	 * @return string Filtered markup.
	 */
	public static function filter_script_loader_tag( string $tag, string $handle ): string {
		if ( is_admin() ) {
			return $tag;
		}

		if ( '' === trim( $tag ) ) {
			return $tag;
		}

		$wp_scripts = wp_scripts();
		if ( ! ( $wp_scripts instanceof WP_Scripts ) ) {
			return $tag;
		}

		$defer_on = dsm_misc_defer_js_assets_is_explicitly_enabled();

		$ensure_defer = static function ( string $html ): string {
			if ( str_contains( $html, ' defer' ) || preg_match( '/\sdefer\s*=/', $html ) ) {
				return $html;
			}

			return str_replace( ' src', ' defer="defer" src', $html );
		};

		if ( $defer_on ) {
			if ( self::may_modify_registered_script_markup( $wp_scripts, $handle ) ) {
				return $ensure_defer( $tag );
			}

			return $tag;
		}

		if ( self::facebook_async_markup_eligible( $wp_scripts, $handle ) ) {
			if ( str_contains( $tag, ' async' ) && str_contains( $tag, ' defer' ) ) {
				return $tag;
			}

			return str_replace( ' src', ' async defer crossorigin="anonymous" src', $tag );
		}

		if ( self::twitter_async_markup_eligible( $wp_scripts, $handle ) ) {
			return str_replace( ' src', ' async crossorigin="anonymous" charset="utf-8" src', $tag );
		}

		return $tag;
	}
}

/**
 * Reads `dsm_settings_misc[dsm_defer_js_assets]` via {@see get_option()} with sanitized values.
 *
 * Returns true **only** when the option exists and sanitizes strictly to `'on'` (explicit opt-in — no optimistic default).
 *
 * Used by {@see \DiviSupreme\Includes\DsmDeferFrontendScripts} and available for assertions/tests.
 *
 * @since 5.0.0
 * @return bool
 */
function dsm_misc_defer_js_assets_is_explicitly_enabled(): bool {
	$misc = get_option( 'dsm_settings_misc', array() );

	if ( ! is_array( $misc ) ) {
		return false;
	}

	if ( ! array_key_exists( 'dsm_defer_js_assets', $misc ) ) {
		return false;
	}

	$raw = $misc['dsm_defer_js_assets'];

	if ( is_bool( $raw ) ) {
		return false;
	}

	$val = sanitize_text_field( (string) $raw );

	return 'on' === $val;
}
