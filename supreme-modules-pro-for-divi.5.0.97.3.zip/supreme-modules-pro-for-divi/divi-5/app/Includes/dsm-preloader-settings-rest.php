<?php
/**
 * REST: Preloader global settings (Visual Builder modal).
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Registers `GET|POST /dsm/v1/preloader-settings` and `/preloader-page-enabled`.
 */
final class DSM_Preloader_Settings_REST {

	/**
	 * Hook REST routes.
	 */
	public function __construct() {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	/**
	 * Register REST routes.
	 *
	 * @return void
	 */
	public function register_routes(): void {
		register_rest_route(
			'dsm/v1',
			'/preloader-settings',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_settings' ),
					'permission_callback' => array( $this, 'permission_callback' ),
				),
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'save_settings' ),
					'permission_callback' => array( $this, 'permission_callback' ),
				),
			)
		);

		register_rest_route(
			'dsm/v1',
			'/preloader-page-enabled',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_page_enabled' ),
					'permission_callback' => array( $this, 'permission_callback' ),
					'args'                => array(
						'post_id' => array(
							'type'              => 'integer',
							'required'          => true,
							'sanitize_callback' => 'absint',
						),
					),
				),
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'save_page_enabled' ),
					'permission_callback' => array( $this, 'permission_callback' ),
				),
			)
		);
	}

	/**
	 * REST permission callback.
	 *
	 * @return bool
	 */
	public function permission_callback(): bool {
		return current_user_can( 'edit_posts' );
	}

	/**
	 * GET handler.
	 *
	 * @return \WP_REST_Response
	 */
	public function get_settings(): \WP_REST_Response {
		if ( ! isset( $GLOBALS['dsm_preloader_extension'] )
			|| ! $GLOBALS['dsm_preloader_extension'] instanceof \DiviSupreme\Extensions\Preloader ) {
			return new \WP_REST_Response( array(), 200 );
		}

		return new \WP_REST_Response(
			$GLOBALS['dsm_preloader_extension']->get_settings(),
			200
		);
	}

	/**
	 * POST handler.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function save_settings( \WP_REST_Request $request ) {
		if ( ! isset( $GLOBALS['dsm_preloader_extension'] )
			|| ! $GLOBALS['dsm_preloader_extension'] instanceof \DiviSupreme\Extensions\Preloader ) {
			return new \WP_Error(
				'dsm_preloader_unavailable',
				esc_html__( 'Preloader extension is not loaded.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 503 )
			);
		}

		$payload = $request->get_json_params();
		if ( ! is_array( $payload ) ) {
			$payload = array();
		}

		$saved = $GLOBALS['dsm_preloader_extension']->save_settings( $payload );

		if ( ! $saved ) {
			return new \WP_Error(
				'dsm_preloader_save_failed',
				esc_html__( 'Could not save Preloader settings.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 500 )
			);
		}

		return new \WP_REST_Response(
			$GLOBALS['dsm_preloader_extension']->get_settings(),
			200
		);
	}

	/**
	 * GET per-page enable flag.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function get_page_enabled( \WP_REST_Request $request ) {
		$preloader = $this->get_preloader_instance();
		if ( is_wp_error( $preloader ) ) {
			return $preloader;
		}

		$post_id = absint( $request->get_param( 'post_id' ) );
		if ( $post_id <= 0 || ! current_user_can( 'edit_post', $post_id ) ) {
			return new \WP_Error(
				'dsm_preloader_page_forbidden',
				esc_html__( 'You cannot edit this page.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 403 )
			);
		}

		return new \WP_REST_Response(
			array(
				'enabled' => $preloader->get_page_enabled( $post_id ),
			),
			200
		);
	}

	/**
	 * POST per-page enable flag.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function save_page_enabled( \WP_REST_Request $request ) {
		$preloader = $this->get_preloader_instance();
		if ( is_wp_error( $preloader ) ) {
			return $preloader;
		}

		$payload = $request->get_json_params();
		if ( ! is_array( $payload ) ) {
			$payload = array();
		}

		$post_id = absint( $payload['post_id'] ?? $request->get_param( 'post_id' ) );
		if ( $post_id <= 0 || ! current_user_can( 'edit_post', $post_id ) ) {
			return new \WP_Error(
				'dsm_preloader_page_forbidden',
				esc_html__( 'You cannot edit this page.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 403 )
			);
		}

		$enabled = sanitize_text_field( (string) ( $payload['enabled'] ?? $request->get_param( 'enabled' ) ) );

		return new \WP_REST_Response(
			array(
				'enabled' => $preloader->set_page_enabled( $post_id, $enabled ),
			),
			200
		);
	}

	/**
	 * Loaded Preloader instance.
	 *
	 * @return \DiviSupreme\Extensions\Preloader|\WP_Error
	 */
	private function get_preloader_instance() {
		if ( ! isset( $GLOBALS['dsm_preloader_extension'] )
			|| ! $GLOBALS['dsm_preloader_extension'] instanceof \DiviSupreme\Extensions\Preloader ) {
			return new \WP_Error(
				'dsm_preloader_unavailable',
				esc_html__( 'Preloader extension is not loaded.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 503 )
			);
		}

		return $GLOBALS['dsm_preloader_extension'];
	}
}

new DSM_Preloader_Settings_REST();
