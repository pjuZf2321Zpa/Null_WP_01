<?php
/**
 * Supreme Table library CPT (`dsm_table_lib`) — reusable grids.
 *
 * Registered only when the Table module is enabled. Slug is not `dsm_table`
 * (that is the D4 shortcode / frontend class).
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Includes;

use DiviSupreme\Modules\Table;
use WP_Error;
use WP_Post;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Library post type, grid meta, and REST for the Visual Builder picker.
 */
final class DsmTableLibrary {

	public const POST_TYPE = 'dsm_table_lib';

	public const META_GRID = '_dsm_table_grid';

	/**
	 * Whether the Supreme Table module is on in Divi Supreme → Modules.
	 *
	 * @return bool
	 */
	public static function is_table_module_enabled(): bool {
		$settings = get_option( 'dsm_modules', array() );
		if ( ! is_array( $settings ) ) {
			return true;
		}

		return ! isset( $settings['Table'] ) || 'on' === $settings['Table'];
	}

	/**
	 * Register CPT, REST, and save hooks when the Table module is enabled.
	 *
	 * @return void
	 */
	public static function register(): void {
		if ( ! self::is_table_module_enabled() ) {
			return;
		}

		add_action( 'init', array( self::class, 'register_post_type' ) );
		add_action( 'rest_api_init', array( self::class, 'register_rest_routes' ) );
		add_action( 'save_post_' . self::POST_TYPE, array( self::class, 'maybe_seed_grid' ), 10, 3 );
		add_action( 'save_post', array( self::class, 'sync_grids_from_saved_post' ), 20, 2 );
		DsmTableLibraryAdmin::register();
		DsmTableFinderAdmin::register();
	}

	/**
	 * Register the non-public library CPT under Divi Supreme.
	 *
	 * @return void
	 */
	public static function register_post_type(): void {
		$labels = array(
			'name'               => __( 'Table library', 'dsm-supreme-modules-pro-for-divi' ),
			'singular_name'      => __( 'Library table', 'dsm-supreme-modules-pro-for-divi' ),
			'menu_name'          => __( 'Tables', 'dsm-supreme-modules-pro-for-divi' ),
			'add_new'            => __( 'Add New', 'dsm-supreme-modules-pro-for-divi' ),
			'add_new_item'       => __( 'Add library table', 'dsm-supreme-modules-pro-for-divi' ),
			'edit_item'          => __( 'Edit library table', 'dsm-supreme-modules-pro-for-divi' ),
			'new_item'           => __( 'New library table', 'dsm-supreme-modules-pro-for-divi' ),
			'view_item'          => __( 'View library table', 'dsm-supreme-modules-pro-for-divi' ),
			'search_items'       => __( 'Search library tables', 'dsm-supreme-modules-pro-for-divi' ),
			'not_found'          => __( 'No library tables yet. Add one here, or save a Manual table from Visual Builder.', 'dsm-supreme-modules-pro-for-divi' ),
			'not_found_in_trash' => __( 'No library tables found in Trash.', 'dsm-supreme-modules-pro-for-divi' ),
			'all_items'          => __( 'All tables', 'dsm-supreme-modules-pro-for-divi' ),
		);

		register_post_type(
			self::POST_TYPE,
			array(
				'labels'              => $labels,
				'public'              => false,
				'publicly_queryable'  => false,
				'show_ui'             => true,
				'show_in_menu'        => false,
				'show_in_admin_bar'   => false,
				'show_in_rest'        => false,
				'exclude_from_search' => true,
				'has_archive'         => false,
				'rewrite'             => false,
				'query_var'           => false,
				'capability_type'     => 'post',
				'map_meta_cap'        => false,
				'capabilities'        => array(
					'edit_post'           => 'manage_options',
					'read_post'           => 'manage_options',
					'delete_post'         => 'manage_options',
					'edit_posts'          => 'manage_options',
					'edit_others_posts'   => 'manage_options',
					'delete_posts'        => 'manage_options',
					'delete_others_posts' => 'manage_options',
					'read_private_posts'  => 'manage_options',
					'publish_posts'       => 'manage_options',
					'create_posts'        => 'manage_options',
				),
				'supports'            => array( 'title' ),
			)
		);
	}

	/**
	 * REST: list / get / update library grids for the Visual Builder.
	 *
	 * @return void
	 */
	public static function register_rest_routes(): void {
		register_rest_route(
			'dsm/v1',
			'/table-library',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( self::class, 'rest_list' ),
					'permission_callback' => array( self::class, 'rest_can_manage' ),
				),
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( self::class, 'rest_create' ),
					'permission_callback' => array( self::class, 'rest_can_manage' ),
				),
			)
		);

		register_rest_route(
			'dsm/v1',
			'/table-library/(?P<id>\d+)',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( self::class, 'rest_get' ),
					'permission_callback' => array( self::class, 'rest_can_manage' ),
					'args'                => array(
						'id' => array(
							'type'              => 'integer',
							'required'          => true,
							'sanitize_callback' => 'absint',
						),
					),
				),
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( self::class, 'rest_update' ),
					'permission_callback' => array( self::class, 'rest_can_manage' ),
					'args'                => array(
						'id' => array(
							'type'              => 'integer',
							'required'          => true,
							'sanitize_callback' => 'absint',
						),
					),
				),
			)
		);
	}

	/**
	 * Whether the current user can manage library tables via REST.
	 *
	 * @return bool
	 */
	public static function rest_can_manage(): bool {
		return current_user_can( 'manage_options' );
	}

	/**
	 * REST: picker options for the Visual Builder.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function rest_list( WP_REST_Request $request ): WP_REST_Response {
		unset( $request );

		return new WP_REST_Response(
			array(
				'options' => self::get_picker_options(),
			),
			200
		);
	}

	/**
	 * REST: one library grid.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function rest_get( WP_REST_Request $request ) {
		$id   = absint( $request->get_param( 'id' ) );
		$grid = self::get_grid( $id );
		if ( null === $grid ) {
			return new WP_Error(
				'dsm_table_library_missing',
				__( 'Library table not found.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 404 )
			);
		}

		return new WP_REST_Response(
			array(
				'id'    => $id,
				'title' => get_the_title( $id ),
				'grid'  => $grid,
			),
			200
		);
	}

	/**
	 * REST: save a library grid from the Visual Builder.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function rest_update( WP_REST_Request $request ) {
		$id = absint( $request->get_param( 'id' ) );
		if ( ! self::is_library_post( $id ) ) {
			return new WP_Error(
				'dsm_table_library_missing',
				__( 'Library table not found.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 404 )
			);
		}

		$params = $request->get_json_params();
		$raw    = is_array( $params ) && isset( $params['grid'] ) ? $params['grid'] : null;
		$saved  = self::save_grid( $id, $raw );
		if ( null === $saved ) {
			return new WP_Error(
				'dsm_table_library_save',
				__( 'Could not save the library table.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 400 )
			);
		}

		DsmTableFinder::bust_usage_cache();

		return new WP_REST_Response(
			array(
				'id'   => $id,
				'grid' => $saved,
			),
			200
		);
	}

	/**
	 * REST: create a library table from a Visual Builder Manual grid.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function rest_create( WP_REST_Request $request ) {
		$params = $request->get_json_params();
		$title  = '';
		if ( is_array( $params ) && isset( $params['title'] ) ) {
			$title = sanitize_text_field( (string) $params['title'] );
		}
		if ( '' === $title ) {
			$title = __( 'Library table', 'dsm-supreme-modules-pro-for-divi' );
		}

		$post_id = wp_insert_post(
			array(
				'post_type'   => self::POST_TYPE,
				'post_status' => 'publish',
				'post_title'  => $title,
			),
			true
		);

		if ( is_wp_error( $post_id ) ) {
			return $post_id;
		}

		$raw  = is_array( $params ) && isset( $params['grid'] ) ? $params['grid'] : array();
		$grid = self::save_grid( (int) $post_id, $raw );
		if ( null === $grid ) {
			return new WP_Error(
				'dsm_table_library_save',
				__( 'Could not save the library table.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 400 )
			);
		}

		DsmTableFinder::bust_usage_cache();

		return new WP_REST_Response(
			array(
				'id'    => (int) $post_id,
				'title' => $title,
				'grid'  => $grid,
			),
			201
		);
	}

	/**
	 * Seed an empty library item with a blank 1×1 grid (not the pricing template).
	 *
	 * @param int     $post_id Post ID.
	 * @param WP_Post $post    Post.
	 * @param bool    $update  Whether this is an update.
	 * @return void
	 */
	public static function maybe_seed_grid( int $post_id, WP_Post $post, bool $update ): void {
		unset( $update );

		if ( $post_id <= 0 || wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
			return;
		}

		$existing = get_post_meta( $post_id, self::META_GRID, true );
		if ( is_array( $existing ) && array() !== $existing ) {
			return;
		}

		self::save_grid( $post_id, self::get_blank_grid(), $post );
	}

	/**
	 * Sanitized grid for a library post, or null if missing.
	 *
	 * @param int $post_id Library post ID.
	 * @return array<string, mixed>|null
	 */
	public static function get_grid( int $post_id ): ?array {
		if ( ! self::is_library_post( $post_id ) ) {
			return null;
		}

		$raw = get_post_meta( $post_id, self::META_GRID, true );
		if ( ! is_array( $raw ) || array() === $raw ) {
			return null;
		}

		return self::maybe_sanitize_grid( $raw, DsmTableSource::get_import_max_rows() );
	}

	/**
	 * Persist a grid on a library post.
	 *
	 * CPT admin save runs before Divi 5 bootstraps `Table`. Persist the
	 * well-formed array anyway; sanitize when the module class is available.
	 *
	 * @param int          $post_id Library post ID.
	 * @param mixed        $raw     Grid JSON.
	 * @param WP_Post|null $post    Post from save_post (avoids get_post_type races).
	 * @return array<string, mixed>|null
	 */
	public static function save_grid( int $post_id, $raw, ?WP_Post $post = null ): ?array {
		if ( ! self::is_library_post( $post_id, $post ) ) {
			return null;
		}

		$grid = self::maybe_sanitize_grid( $raw, DsmTableSource::get_import_max_rows() );
		if ( ! is_array( $grid ) || ! isset( $grid['columns'], $grid['rows'] ) || ! is_array( $grid['columns'] ) || ! is_array( $grid['rows'] ) ) {
			return null;
		}

		update_post_meta( $post_id, self::META_GRID, $grid );

		return $grid;
	}

	/**
	 * When a page is saved, write each Library-sourced Table grid to its CPT.
	 *
	 * Reads `post_content` only — does not `serialize_blocks` or rewrite the page.
	 *
	 * @param int     $post_id Post ID.
	 * @param WP_Post $post    Post.
	 * @return void
	 */
	public static function sync_grids_from_saved_post( int $post_id, WP_Post $post ): void {
		if ( $post_id <= 0 || self::POST_TYPE === $post->post_type ) {
			return;
		}

		if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
			return;
		}

		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		$content = (string) $post->post_content;
		if ( '' === $content || false === strpos( $content, 'dsm/table' ) ) {
			return;
		}

		if ( ! function_exists( 'parse_blocks' ) ) {
			return;
		}

		$grids = array();
		foreach ( parse_blocks( $content ) as $block ) {
			if ( is_array( $block ) ) {
				self::collect_library_grids_from_block( $block, $grids );
			}
		}

		if ( array() === $grids ) {
			return;
		}

		foreach ( $grids as $library_id => $grid ) {
			self::save_grid( (int) $library_id, $grid );
		}

		DsmTableFinder::bust_usage_cache();
	}

	/**
	 * Collect Library table grids from a D5 block tree.
	 *
	 * @param array<string, mixed>             $block Block.
	 * @param array<int, array<string, mixed>> $grids library_id => grid (last wins).
	 * @return void
	 */
	private static function collect_library_grids_from_block( array $block, array &$grids ): void {
		$name = isset( $block['blockName'] ) ? (string) $block['blockName'] : '';
		if ( 'dsm/table' === $name ) {
			$attrs = isset( $block['attrs'] ) && is_array( $block['attrs'] ) ? $block['attrs'] : array();
			if ( 'library' === self::read_block_inner_string( $attrs, 'data_source' ) ) {
				$library_id = absint( self::read_block_inner_string( $attrs, 'table_library_id' ) );
				$grid       = self::read_block_grid( $attrs );
				if ( $library_id > 0 && is_array( $grid ) ) {
					$grids[ $library_id ] = $grid;
				}
			}
		}

		$inner = $block['innerBlocks'] ?? array();
		if ( is_array( $inner ) ) {
			foreach ( $inner as $child ) {
				if ( is_array( $child ) ) {
					self::collect_library_grids_from_block( $child, $grids );
				}
			}
		}
	}

	/**
	 * Read a scalar innerContent leaf from D5 module attrs.
	 *
	 * @param array<string, mixed> $attrs Block attrs.
	 * @param string               $key   Attr key.
	 * @return string
	 */
	private static function read_block_inner_string( array $attrs, string $key ): string {
		$node = $attrs[ $key ] ?? null;
		if ( is_string( $node ) || is_int( $node ) ) {
			return (string) $node;
		}
		if ( ! is_array( $node ) ) {
			return '';
		}

		$inner = $node['innerContent']['desktop']['value'] ?? $node['desktop']['value'] ?? null;
		if ( is_string( $inner ) || is_int( $inner ) ) {
			return (string) $inner;
		}

		return '';
	}

	/**
	 * Read `table_grid` from D5 module attrs.
	 *
	 * @param array<string, mixed> $attrs Block attrs.
	 * @return array<string, mixed>|null
	 */
	private static function read_block_grid( array $attrs ): ?array {
		$node = $attrs['table_grid'] ?? null;
		if ( is_string( $node ) && '' !== $node ) {
			$decoded = json_decode( $node, true );
			return is_array( $decoded ) ? $decoded : null;
		}
		if ( ! is_array( $node ) ) {
			return null;
		}

		$value = $node['innerContent']['desktop']['value'] ?? $node['desktop']['value'] ?? null;
		if ( is_array( $value ) ) {
			return $value;
		}
		if ( is_string( $value ) && '' !== $value ) {
			$decoded = json_decode( $value, true );
			return is_array( $decoded ) ? $decoded : null;
		}

		return null;
	}

	/**
	 * Minimal empty grid (1 column, header + one body row). Safe without Divi 5.
	 *
	 * @return array<string, mixed>
	 */
	public static function get_blank_grid(): array {
		return array(
			'schema_version' => 1,
			'columns'        => array(
				array(
					'id'           => 'col-1',
					'header'       => '',
					'hide_on'      => array(
						'tablet' => false,
						'phone'  => false,
					),
					'sticky'       => true,
					'type_default' => 'text',
					'width'        => '',
					'align'        => '',
				),
			),
			'rows'           => array(
				array(
					'id'      => 'row-h',
					'role'    => 'header',
					'tooltip' => '',
					'cells'   => array(
						self::make_text_cell( 'cell-h-1', '' ),
					),
				),
				array(
					'id'      => 'row-1',
					'role'    => 'body',
					'tooltip' => '',
					'cells'   => array(
						self::make_text_cell( 'cell-1-1', '' ),
					),
				),
			),
			'merges'         => array(),
			'comparison'     => array(
				'highlight_column_id'  => '',
				'best_value_column_id' => '',
				'best_value_label'     => '',
			),
		);
	}

	/**
	 * Whether a grid has no header or cell text yet.
	 *
	 * @param array<string, mixed> $grid Grid.
	 * @return bool
	 */
	public static function is_blank_grid( array $grid ): bool {
		$columns = isset( $grid['columns'] ) && is_array( $grid['columns'] ) ? $grid['columns'] : array();
		foreach ( $columns as $column ) {
			if ( is_array( $column ) && '' !== trim( (string) ( $column['header'] ?? '' ) ) ) {
				return false;
			}
		}

		$rows = isset( $grid['rows'] ) && is_array( $grid['rows'] ) ? $grid['rows'] : array();
		foreach ( $rows as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$cells = isset( $row['cells'] ) && is_array( $row['cells'] ) ? $row['cells'] : array();
			foreach ( $cells as $cell ) {
				if ( ! is_array( $cell ) ) {
					continue;
				}
				$value = $cell['value'] ?? array();
				if ( is_string( $value ) && '' !== trim( $value ) ) {
					return false;
				}
				if ( is_array( $value ) ) {
					if ( isset( $value['text'] ) && '' !== trim( (string) $value['text'] ) ) {
						return false;
					}
					if ( isset( $value['html'] ) && '' !== trim( wp_strip_all_tags( Table::coerce_html_string( $value['html'] ) ) ) ) {
						return false;
					}
				}
			}
		}

		return true;
	}

	/**
	 * SelectContainer options for the Visual Builder (`id` => { label }).
	 *
	 * @return array<string, array{label: string}>
	 */
	public static function get_picker_options(): array {
		$options = array(
			'' => array(
				'label' => __( 'Choose a library table…', 'dsm-supreme-modules-pro-for-divi' ),
			),
		);

		$query = new \WP_Query(
			array(
				'post_type'              => self::POST_TYPE,
				'post_status'            => array( 'publish', 'draft', 'private' ),
				// phpcs:ignore WordPress.WP.PostsPerPage.posts_per_page_posts_per_page -- picker cap, not a public archive.
				'posts_per_page'         => 200,
				'orderby'                => 'title',
				'order'                  => 'ASC',
				'no_found_rows'          => true,
				'update_post_meta_cache' => false,
				'update_post_term_cache' => false,
			)
		);

		if ( $query->have_posts() ) {
			foreach ( $query->posts as $post ) {
				if ( ! $post instanceof WP_Post ) {
					continue;
				}
				$title = '' !== trim( $post->post_title ) ? $post->post_title : sprintf(
					/* translators: %d: post ID */
					__( '(no title) — #%d', 'dsm-supreme-modules-pro-for-divi' ),
					(int) $post->ID
				);
				$options[ (string) $post->ID ] = array(
					'label' => $title,
				);
			}
		}

		wp_reset_postdata();

		/**
		 * Filter Visual Builder library table picker options.
		 *
		 * @param array<string, array{label: string}> $options Select options.
		 */
		$filtered = apply_filters( 'dsm_table_library_picker_options', $options );

		return is_array( $filtered ) ? $filtered : $options;
	}

	/**
	 * Payload localized on `diviSupreme5.tableLibrary`.
	 *
	 * @return array<string, mixed>
	 */
	public static function get_vb_payload(): array {
		return array(
			'enabled'  => self::is_table_module_enabled(),
			'restUrl'  => esc_url_raw( rest_url( 'dsm/v1/table-library' ) ),
			'nonce'    => wp_create_nonce( 'wp_rest' ),
			'options'  => self::get_picker_options(),
			'adminUrl' => admin_url( 'edit.php?post_type=' . self::POST_TYPE ),
		);
	}

	/**
	 * Whether the post is a library table.
	 *
	 * @param int          $post_id Post ID.
	 * @param WP_Post|null $post    Optional post from save_post.
	 * @return bool
	 */
	public static function is_library_post( int $post_id, ?WP_Post $post = null ): bool {
		if ( $post_id <= 0 ) {
			return false;
		}

		if ( $post instanceof WP_Post ) {
			return self::POST_TYPE === $post->post_type && (int) $post->ID === $post_id;
		}

		return self::POST_TYPE === get_post_type( $post_id );
	}

	/**
	 * Sanitize through `Table::sanitize_grid` when Divi 5 has booted; otherwise keep the array.
	 *
	 * @param mixed $raw      Grid.
	 * @param int   $max_rows Row cap. `0` uses the import cap (5000).
	 * @return array<string, mixed>|null
	 */
	public static function maybe_sanitize_grid( $raw, int $max_rows = 0 ): ?array {
		if ( $max_rows < 1 ) {
			$max_rows = DsmTableSource::get_import_max_rows();
		}

		if ( self::table_class_ready() ) {
			return Table::sanitize_grid( $raw, $max_rows );
		}

		if ( ! is_array( $raw ) ) {
			return null;
		}

		if ( isset( $raw['rows'] ) && is_array( $raw['rows'] ) && count( $raw['rows'] ) > $max_rows ) {
			$raw['rows'] = array_slice( $raw['rows'], 0, $max_rows );
		}

		return $raw;
	}

	/**
	 * Plain-text cell matching `Table::make_text_cell`.
	 *
	 * @param string $id   Cell id.
	 * @param string $text Plain text.
	 * @return array<string, mixed>
	 */
	private static function make_text_cell( string $id, string $text ): array {
		return array(
			'id'      => $id,
			'type'    => 'text',
			'colspan' => 1,
			'rowspan' => 1,
			'value'   => array( 'text' => $text ),
			'design'  => array(),
		);
	}

	/**
	 * Whether `Table` can be loaded without fatalling on missing Divi interfaces.
	 *
	 * @return bool
	 */
	private static function table_class_ready(): bool {
		if ( class_exists( Table::class, false ) ) {
			return true;
		}

		if ( ! class_exists( \ET\Builder\Framework\DependencyManagement\Interfaces\DependencyInterface::class ) ) {
			return false;
		}

		return class_exists( Table::class );
	}
}
