<?php
/**
 * Divi Shop Builder shop-ajax compatibility.
 *
 * `loadShopAjax()` updates the shop in place when the POST body contains the
 * agsdsb-json-start marker and JSON `shop` HTML. `dscwp_ags_filters_before_shop()`
 * returns false unless the module order class is identical to the posted class,
 * so `ShopHtmlTrait::get_shop()` never builds that HTML. This class lets the
 * same shop render, keeps the HTML, and returns it under the class the browser
 * queried. `loadShopAjax()` then replaces the module contents and removes
 * `.ags-woo-shop-loading` without `window.location`. A `dswcpRedirect` reload
 * remains only when that HTML was not captured.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Includes;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Completes a Divi Shop Builder shop ajax POST in place when the marker was not printed.
 */
final class DiviShopBuilderAjaxCompat {

	/**
	 * Marker `loadShopAjax()` requires before it will parse JSON.
	 */
	private const MARKER = '/*agsdsb-json-start*/';

	/**
	 * Shop inner HTML captured before Shop Builder replaces it with an empty string.
	 *
	 * @var string
	 */
	private static string $shop_html = '';

	/**
	 * Mini-cart fragments for the `added_to_cart` event Shop Builder fires after a shop payload.
	 *
	 * @var array<string, string>
	 */
	private static array $fragments = array();

	/**
	 * WooCommerce cart hash captured with the fragments.
	 *
	 * @var string
	 */
	private static string $cart_hash = '';

	/**
	 * Whether this request already replaced the shop ajax body.
	 *
	 * @var bool
	 */
	private static bool $sent = false;

	/**
	 * Register hooks only for a Shop Builder shop ajax POST.
	 *
	 * @return void
	 */
	public static function register_hooks(): void {
		if ( '' === self::requested_class() ) {
			return;
		}

		add_filter( 'ags_woo_shop_plus_before_print_shop', array( self::class, 'allow_shop_render' ), 20, 3 );
		add_filter( 'ags_woo_shop_html', array( self::class, 'capture_shop_html' ), 9, 2 );
		add_action( 'template_redirect', array( self::class, 'start_buffer' ), 0 );
	}

	/**
	 * Capture the page so a marker-less HTML document can be replaced.
	 *
	 * Shop Builder already started a buffer when it saw this POST. This inner
	 * buffer receives the template. `ob_end_clean()` in Shop Builder's own
	 * success path discards it without calling the callback, then prints the
	 * marker itself.
	 *
	 * @return void
	 */
	public static function start_buffer(): void {
		ob_start( array( self::class, 'filter_buffer' ) );
	}

	/**
	 * Posted shop order class (`wpzone_agswooshopplus_0`).
	 *
	 * @return string
	 */
	private static function requested_class(): string {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Shop Builder ajax flag; read-only.
		if ( ! isset( $_POST['ags_wc_filters_ajax_shop'] ) ) {
			return '';
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Shop Builder ajax flag; read-only.
		$raw = sanitize_text_field( wp_unslash( (string) $_POST['ags_wc_filters_ajax_shop'] ) );

		return sanitize_html_class( $raw );
	}

	/**
	 * Keep rendering the shop when Divi's order class is the same module the browser posted.
	 *
	 * Shop Builder returns false on a strict mismatch and skips `get_shop()` before
	 * `ags_woo_shop_html` can run. Filter hooks that ran only after a match are
	 * applied here so the in-place HTML still respects the active product filters.
	 *
	 * @param bool                 $should_render Whether Shop Builder should render the shop.
	 * @param array<string, mixed> $props         Module props.
	 * @param string               $order_class   Module order class.
	 * @return bool
	 */
	public static function allow_shop_render( $should_render, $props, $order_class ): bool {
		if ( $should_render ) {
			return true;
		}

		$order_class = is_string( $order_class ) ? $order_class : '';

		if ( ! self::is_same_shop( $order_class, self::requested_class() ) ) {
			return false;
		}

		if ( function_exists( 'dswcp_ags_filters_strip_unwanted_pagination_url_params' ) ) {
			add_filter( 'woocommerce_pagination_args', 'dswcp_ags_filters_strip_unwanted_pagination_url_params', 999 );
		}

		$filter_target = is_array( $props ) && isset( $props['filter_target'] ) ? (string) $props['filter_target'] : '';

		if ( 'on' === $filter_target && function_exists( 'dscwp_ags_filters_hooks' ) ) {
			dscwp_ags_filters_hooks();

			if ( function_exists( 'dswcp_ags_filters_transform_category_urls' ) ) {
				add_filter( 'term_link', 'dswcp_ags_filters_transform_category_urls', 10, 2 );
			}

			if ( function_exists( 'dswcp_ags_filters_transform_category_links' ) ) {
				add_filter( 'term_links-product_cat', 'dswcp_ags_filters_transform_category_links' );
			}
		}

		return true;
	}

	/**
	 * Store shop markup before Shop Builder replaces a mismatched shop with an empty string.
	 *
	 * @param string $shop_html   Rendered shop HTML.
	 * @param string $order_class Module order class.
	 * @return string
	 */
	public static function capture_shop_html( $shop_html, $order_class ): string {
		if ( ! is_string( $shop_html ) || ! is_string( $order_class ) || '' === $shop_html ) {
			return is_string( $shop_html ) ? $shop_html : '';
		}

		if ( self::is_same_shop( $order_class, self::requested_class() ) ) {
			self::$shop_html = $shop_html;
			self::remember_cart_fragments();
		}

		return $shop_html;
	}

	/**
	 * Return shop HTML for an in-place update, or a redirect when that HTML is missing.
	 *
	 * @param string $output Buffered template output.
	 * @param int    $phase  Output handler phase flags.
	 * @return string
	 */
	public static function filter_buffer( $output, $phase ): string {
		$output = is_string( $output ) ? $output : '';
		$phase  = is_int( $phase ) ? $phase : 0;

		if ( self::$sent || str_contains( $output, self::MARKER ) ) {
			return $output;
		}

		if ( 0 === ( $phase & PHP_OUTPUT_HANDLER_FINAL ) ) {
			return $output;
		}

		$shop_html = self::with_pending_notices( self::$shop_html );
		$response  = array();

		if ( '' !== $shop_html ) {
			$response = array(
				'shop'    => array(
					self::requested_class() => $shop_html,
				),
				'notices' => array(),
			);

			if ( array() !== self::$fragments ) {
				$response['wc-fragments'] = self::$fragments;
				$response['wc-cart-hash'] = self::$cart_hash;
			}
		} else {
			$redirect = self::redirect_url();

			if ( '' === $redirect ) {
				return $output;
			}

			$response = array(
				'dswcpRedirect' => $redirect,
			);
		}

		/**
		 * Shop Builder ajax JSON used when the response has no agsdsb-json-start marker.
		 *
		 * `shop` updates the module in place. `dswcpRedirect` is the reload fallback.
		 *
		 * @param array<string, mixed> $response  Payload encoded after the marker.
		 * @param string               $requested Posted shop class.
		 */
		$filtered = apply_filters( 'dsm_divi_shop_builder_ajax_response', $response, self::requested_class() );

		if ( is_array( $filtered ) ) {
			$response = $filtered;
		}

		$json = wp_json_encode( $response );

		if ( ! is_string( $json ) || '' === $json ) {
			return $output;
		}

		self::$sent = true;

		return self::MARKER . $json;
	}

	/**
	 * Put queued WooCommerce notices above the products when the loop did not print them.
	 *
	 * @param string $shop_html Shop HTML.
	 * @return string
	 */
	private static function with_pending_notices( string $shop_html ): string {
		if ( '' === $shop_html || str_contains( $shop_html, 'woocommerce-message' ) || ! function_exists( 'wc_print_notices' ) || ! function_exists( 'wc_notice_count' ) ) {
			return $shop_html;
		}

		if ( wc_notice_count( 'success' ) < 1 && wc_notice_count( 'notice' ) < 1 && wc_notice_count( 'error' ) < 1 ) {
			return $shop_html;
		}

		$notices = wc_print_notices( true );

		if ( ! is_string( $notices ) || '' === $notices ) {
			return $shop_html;
		}

		$replaced = preg_replace_callback(
			'/<div class="woocommerce-notices-wrapper">\s*<\/div>/',
			static function () use ( $notices ): string {
				return '<div class="woocommerce-notices-wrapper">' . $notices . '</div>';
			},
			$shop_html,
			1
		);

		if ( is_string( $replaced ) && $replaced !== $shop_html ) {
			return $replaced;
		}

		return $notices . $shop_html;
	}

	/**
	 * Mini-cart fragments for the `added_to_cart` event fired after a successful payload.
	 *
	 * @return void
	 */
	private static function remember_cart_fragments(): void {
		if ( array() !== self::$fragments ) {
			return;
		}

		$woocommerce = function_exists( 'WC' ) ? WC() : null;

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- WooCommerce add-to-cart flag already processed this request.
		if ( ! isset( $_REQUEST['add-to-cart'] ) || ! $woocommerce || ! $woocommerce->cart || ! function_exists( 'woocommerce_mini_cart' ) ) {
			return;
		}

		ob_start();
		woocommerce_mini_cart();
		$mini_cart = ob_get_clean();

		if ( ! is_string( $mini_cart ) ) {
			$mini_cart = '';
		}

		$fragments = apply_filters(
			'woocommerce_add_to_cart_fragments',
			array(
				'div.widget_shopping_cart_content' => '<div class="widget_shopping_cart_content">' . $mini_cart . '</div>',
			)
		);

		if ( ! is_array( $fragments ) ) {
			return;
		}

		$clean = array();

		foreach ( $fragments as $selector => $html ) {
			if ( is_string( $selector ) && is_string( $html ) ) {
				$clean[ $selector ] = $html;
			}
		}

		self::$fragments = $clean;
		self::$cart_hash = (string) $woocommerce->cart->get_cart_hash();
	}

	/**
	 * Current page URL without the add-to-cart query, so a fallback reload does not add twice.
	 *
	 * @return string
	 */
	private static function redirect_url(): string {
		$uri = '';

		if ( isset( $_SERVER['REQUEST_URI'] ) ) {
			$uri = esc_url_raw( wp_unslash( (string) $_SERVER['REQUEST_URI'] ) );
		}

		$path  = wp_parse_url( $uri, PHP_URL_PATH );
		$query = wp_parse_url( $uri, PHP_URL_QUERY );
		$args  = array();

		if ( is_string( $query ) && '' !== $query ) {
			parse_str( $query, $args );
		}

		unset( $args['add-to-cart'], $args['quantity'] );

		$url = home_url( is_string( $path ) && '' !== $path ? $path : '/' );

		if ( array() !== $args ) {
			$url = add_query_arg( $args, $url );
		}

		$url = esc_url_raw( $url );

		/**
		 * URL Shop Builder navigates to when shop HTML could not be captured.
		 *
		 * @param string $url       Redirect URL.
		 * @param string $requested Posted shop class.
		 */
		$filtered = apply_filters( 'dsm_divi_shop_builder_ajax_redirect_url', $url, self::requested_class() );

		return is_string( $filtered ) ? esc_url_raw( $filtered ) : $url;
	}

	/**
	 * Whether two shop order classes refer to the same Woo Shop+ instance.
	 *
	 * @param string $order_class Module order class from Shop Builder.
	 * @param string $requested   Class posted by `loadShopAjax()`.
	 * @return bool
	 */
	private static function is_same_shop( string $order_class, string $requested ): bool {
		$bare_order     = self::bare_shop_class( $order_class );
		$bare_requested = self::bare_shop_class( $requested );

		if ( '' === $bare_order || '' === $bare_requested ) {
			return false;
		}

		if ( $bare_order === $bare_requested || str_contains( $order_class, $bare_requested ) ) {
			return true;
		}

		if ( ! self::is_shop_order_class( $bare_order ) || ! self::is_shop_order_class( $bare_requested ) ) {
			return false;
		}

		$order_index     = self::trailing_index( $bare_order );
		$requested_index = self::trailing_index( $bare_requested );

		return '' !== $order_index && $order_index === $requested_index;
	}

	/**
	 * Last class token, without a Divi order-class dot or Theme Builder prefix.
	 *
	 * @param string $order_class Raw order class or selector.
	 * @return string
	 */
	private static function bare_shop_class( string $order_class ): string {
		$order_class = trim( $order_class );
		$stripped    = preg_replace( '/^\.et-db\s+#et-boc\s+\.et-l\s+/', '', $order_class );
		$order_class = is_string( $stripped ) ? trim( $stripped ) : $order_class;

		if ( str_contains( $order_class, ' ' ) ) {
			$parts       = preg_split( '/\s+/', $order_class );
			$order_class = is_array( $parts ) && array() !== $parts ? (string) end( $parts ) : $order_class;
		}

		return ltrim( trim( $order_class ), '.' );
	}

	/**
	 * Whether a class token is a Woo Shop+ order class.
	 *
	 * @param string $class_name Bare class.
	 * @return bool
	 */
	private static function is_shop_order_class( string $class_name ): bool {
		return str_contains( $class_name, 'agswooshopplus_' ) || str_contains( $class_name, 'ags_woo_shop_plus_' );
	}

	/**
	 * Trailing `_0` style index.
	 *
	 * @param string $class_name Bare class.
	 * @return string
	 */
	private static function trailing_index( string $class_name ): string {
		if ( 1 === preg_match( '/_(\d+)$/', $class_name, $matches ) ) {
			return $matches[1];
		}

		return '';
	}
}
