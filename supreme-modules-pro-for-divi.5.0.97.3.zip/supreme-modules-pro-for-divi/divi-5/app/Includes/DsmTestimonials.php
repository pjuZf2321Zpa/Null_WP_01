<?php
/**
 * Supreme Testimonials module services: CPT library, collect form, adapters, privacy.
 *
 * Not a Divi Supreme extension. Lives with other module libraries (same pattern as Table).
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Includes;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Boots CPT / REST / admin for the Supreme Testimonials module.
 */
final class DsmTestimonials {

	/**
	 * Whether the Supreme Testimonials module is on in Divi Supreme → Modules.
	 *
	 * @return bool
	 */
	public static function is_module_enabled(): bool {
		$settings = get_option( 'dsm_modules', array() );
		if ( ! is_array( $settings ) ) {
			return true;
		}

		return ! isset( $settings['Testimonials'] ) || 'on' === $settings['Testimonials'];
	}

	/**
	 * Register CPT, collect REST, library REST, admin, and privacy when the module is enabled.
	 *
	 * @return void
	 */
	public static function register(): void {
		if ( ! self::is_module_enabled() ) {
			return;
		}

		add_action( 'init', array( Testimonials\Cpt::class, 'register' ) );
		add_action( 'rest_api_init', array( Testimonials\Collect::class, 'register_routes' ) );
		add_action( 'rest_api_init', array( Testimonials\Rest::class, 'register_routes' ) );

		Testimonials\Admin::register();
		Testimonials\Privacy::register();
	}
}
