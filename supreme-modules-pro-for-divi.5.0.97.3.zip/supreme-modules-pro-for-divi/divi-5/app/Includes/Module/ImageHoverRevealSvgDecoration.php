<?php
/**
 * Image Hover Reveal: decoration + SVG-related presentation helpers.
 *
 * Maps module CSS ID / class (decoration attributes) onto root markup and applies
 * SVG-specific rules when the image URL points at an SVG asset (matches D4 behaviour).
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Includes\Module;

/**
 * Helpers for {@see \DiviSupreme\Modules\ImageHoverReveal}.
 */
final class ImageHoverRevealSvgDecoration {


	/**
	 * Whether a URL targets an SVG (for display/background quirks).
	 *
	 * @param string $url Image URL.
	 * @return bool
	 */
	public static function is_svg_url( string $url ): bool {
		$url = trim( $url );
		if ( '' === $url ) {
			return false;
		}

		$path = wp_parse_url( $url, PHP_URL_PATH );
		if ( ! is_string( $path ) || '' === $path ) {
			return false;
		}

		$ext = strtolower( pathinfo( $path, PATHINFO_EXTENSION ) );

		return 'svg' === $ext;
	}

	/**
	 * Build `id` and `class` strings from D5 `module.decoration.attributes` desktop rows
	 * for use on the module inner root (mirrors mapping to “SVG” presentation layer / wrapper attrs).
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 * @return array{id: string, class: string}
	 */
	public static function root_id_class_from_decoration( array $attrs ): array {
		$out = array(
			'id'    => '',
			'class' => '',
		);

		$rows = $attrs['module']['decoration']['attributes']['desktop']['value'] ?? null;
		if ( ! is_array( $rows ) ) {
			return $out;
		}

		foreach ( $rows as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$name  = isset( $row['name'] ) ? (string) $row['name'] : '';
			$value = isset( $row['value'] ) ? (string) $row['value'] : '';
			if ( '' === $value ) {
				continue;
			}
			if ( 'id' === $name ) {
				$out['id'] = $value;
			}
			if ( 'class' === $name ) {
				$out['class'] = trim( $out['class'] . ' ' . $value );
			}
		}

		return $out;
	}
}
