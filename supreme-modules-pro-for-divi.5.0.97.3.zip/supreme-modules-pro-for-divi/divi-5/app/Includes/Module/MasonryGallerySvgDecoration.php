<?php
/**
 * Masonry Gallery: Advanced → HTML id/class mapped to gallery root + SVG item detection.
 *
 * Maps module CSS ID / class (`module.decoration.attributes`) onto the `.dsm-gallery.grid` wrapper
 * and exposes SVG URL detection for grid items (parity with D4 `dsm_masonry_gallery_svg`).
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Includes\Module;

/**
 * Helpers for {@see \DiviSupreme\Modules\MasonryGallery}.
 */
final class MasonryGallerySvgDecoration {


	/**
	 * Whether a URL targets an SVG (grid item class + display quirks).
	 *
	 * @param string $url Image URL.
	 * @return bool
	 */
	public static function is_svg_url( string $url ): bool {
		$url = trim( $url );
		if ( '' === $url ) {
			return false;
		}

		$path = wp_parse_url( $url, PHP_URL_PATH );
		if ( ! is_string( $path ) || '' === $path ) {
			return false;
		}

		$ext = strtolower( pathinfo( $path, PATHINFO_EXTENSION ) );

		return 'svg' === $ext;
	}

	/**
	 * Build `id` and `class` strings from D5 `module.decoration.attributes` desktop rows
	 * for the masonry grid root (mirrors D4 `module_id()` on the gallery wrapper).
	 *
	 * @param array<string, mixed> $attrs Module attrs.
	 * @return array{id: string, class: string}
	 */
	public static function root_id_class_from_decoration( array $attrs ): array {
		$out = array(
			'id'    => '',
			'class' => '',
		);

		$rows = $attrs['module']['decoration']['attributes']['desktop']['value'] ?? null;
		if ( ! is_array( $rows ) ) {
			return $out;
		}

		foreach ( $rows as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$name  = isset( $row['name'] ) ? (string) $row['name'] : '';
			$value = isset( $row['value'] ) ? (string) $row['value'] : '';
			if ( '' === $value ) {
				continue;
			}
			if ( 'id' === $name ) {
				$out['id'] = $value;
			}
			if ( 'class' === $name ) {
				$out['class'] = trim( $out['class'] . ' ' . $value );
			}
		}

		return $out;
	}
}
