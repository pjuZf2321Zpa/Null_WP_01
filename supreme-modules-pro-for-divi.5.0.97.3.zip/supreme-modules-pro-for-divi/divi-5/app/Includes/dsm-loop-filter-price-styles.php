<?php
/**
 * Supreme Loop Filter — price style registry + currency + aggregated stats.
 *
 * Reads the same JSON the Visual Builder imports so `price_ui` ids and
 * class names stay in lockstep. Histogram / bounds use one aggregated query
 * (Woo lookup table when present), never N per-bucket queries.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Path to the shared price-style registry JSON.
 *
 * @return string
 */
function dsm_loop_filter_price_styles_registry_path(): string {
	return DSM_DIR_PATH . 'divi-5/packages/module-library/loop-filter/price-filter-styles.json';
}

/**
 * Load the price style registry (id, label, modifier class, supports).
 *
 * @return array{defaultId: string, styles: list<array<string, mixed>>}
 */
function dsm_loop_filter_get_price_style_registry(): array {
	static $cached = null;
	if ( is_array( $cached ) ) {
		return $cached;
	}

	$fallback   = dsm_loop_filter_fallback_price_style_registry();
	$candidates = array(
		dsm_loop_filter_price_styles_registry_path(),
		DSM_DIR_PATH . 'divi-5/public/packages/module-library/loop-filter/price-filter-styles.json',
	);

	foreach ( $candidates as $path ) {
		if ( ! is_readable( $path ) ) {
			continue;
		}
		$raw  = file_get_contents( $path );
		$data = is_string( $raw ) ? json_decode( $raw, true ) : null;
		if ( ! is_array( $data ) || empty( $data['styles'] ) || ! is_array( $data['styles'] ) ) {
			continue;
		}
		$cached = array(
			'defaultId' => isset( $data['defaultId'] ) && is_string( $data['defaultId'] ) && '' !== $data['defaultId']
				? $data['defaultId']
				: 'input-fields',
			'styles'    => $data['styles'],
		);
		return $cached;
	}

	$cached = $fallback;
	return $cached;
}

/**
 * Hardcoded registry when the JSON file is not shipped with the build.
 *
 * @return array{defaultId: string, styles: list<array<string, mixed>>}
 */
function dsm_loop_filter_fallback_price_style_registry(): array {
	return array(
		'defaultId' => 'input-fields',
		'styles'    => array(
			array(
				'id'            => 'input-fields',
				'label'         => 'Input fields',
				'modifierClass' => '',
				'supports'      => array(
					'fields'         => true,
					'slider'         => false,
					'buckets'        => false,
					'histogram'      => false,
					'goButton'       => true,
					'separator'      => true,
					'applyButton'    => false,
					'labelPosition'  => false,
					'rangeOverrides' => false,
					'step'           => false,
				),
			),
			array(
				'id'            => 'range-slider',
				'label'         => 'Range slider',
				'modifierClass' => 'dsm-loop-filter__price--range-slider',
				'supports'      => array(
					'fields'         => false,
					'slider'         => true,
					'buckets'        => false,
					'histogram'      => true,
					'goButton'       => false,
					'separator'      => false,
					'applyButton'    => true,
					'labelPosition'  => true,
					'rangeOverrides' => true,
					'step'           => true,
				),
			),
			array(
				'id'            => 'slider-with-buckets',
				'label'         => 'Slider + input fields',
				'modifierClass' => 'dsm-loop-filter__price--slider-with-buckets',
				'supports'      => array(
					'fields'         => true,
					'slider'         => true,
					'buckets'        => true,
					'histogram'      => true,
					'goButton'       => false,
					'separator'      => true,
					'applyButton'    => true,
					'labelPosition'  => true,
					'rangeOverrides' => true,
					'step'           => true,
				),
			),
		),
	);
}

/**
 * Removed from the Price Filter Type select; still resolve so saved layouts keep working.
 *
 * @return list<array<string, mixed>>
 */
function dsm_loop_filter_legacy_price_styles(): array {
	return array(
		array(
			'id'            => 'range-buckets',
			'label'         => 'Price ranges',
			'modifierClass' => 'dsm-loop-filter__price--range-buckets',
			'supports'      => array(
				'fields'         => false,
				'slider'         => false,
				'buckets'        => true,
				'histogram'      => false,
				'goButton'       => false,
				'separator'      => false,
				'applyButton'    => false,
				'labelPosition'  => false,
				'rangeOverrides' => false,
				'step'           => false,
			),
		),
	);
}

/**
 * Legacy registry entry for a stored `price_ui` id.
 *
 * @param string $id Style id.
 * @return array<string, mixed>|null
 */
function dsm_loop_filter_get_legacy_price_style( string $id ): ?array {
	foreach ( dsm_loop_filter_legacy_price_styles() as $style ) {
		if ( isset( $style['id'] ) && $style['id'] === $id ) {
			return $style;
		}
	}

	return null;
}

/**
 * Default `price_ui` id (current min/max inputs).
 *
 * @return string
 */
function dsm_loop_filter_default_price_ui(): string {
	$registry = dsm_loop_filter_get_price_style_registry();
	return $registry['defaultId'];
}

/**
 * Normalize a stored `price_ui` value to a registered id.
 *
 * @param mixed $raw Raw attr.
 * @return string
 */
function dsm_loop_filter_normalize_price_ui( $raw ): string {
	$value    = is_scalar( $raw ) ? trim( (string) $raw ) : '';
	$registry = dsm_loop_filter_get_price_style_registry();
	if ( '' === $value ) {
		return $registry['defaultId'];
	}
	// Removed UI: Distribution slider was Range slider + Show Histogram.
	if ( 'histogram-slider' === $value ) {
		return 'range-slider';
	}
	foreach ( $registry['styles'] as $style ) {
		if ( isset( $style['id'] ) && $style['id'] === $value ) {
			return $value;
		}
	}
	// Removed UI: Price ranges stays buckets-only on existing layouts.
	if ( null !== dsm_loop_filter_get_legacy_price_style( $value ) ) {
		return $value;
	}

	return $registry['defaultId'];
}

/**
 * Registry entry for a style id.
 *
 * @param string $id Style id.
 * @return array<string, mixed>|null
 */
function dsm_loop_filter_get_price_style( string $id ): ?array {
	$id       = dsm_loop_filter_normalize_price_ui( $id );
	$registry = dsm_loop_filter_get_price_style_registry();
	foreach ( $registry['styles'] as $style ) {
		if ( isset( $style['id'] ) && $style['id'] === $id ) {
			return $style;
		}
	}

	return dsm_loop_filter_get_legacy_price_style( $id );
}

/**
 * Supports map for a style id.
 *
 * @param string $id Style id.
 * @return array<string, bool>
 */
function dsm_loop_filter_price_style_supports( string $id ): array {
	$style    = dsm_loop_filter_get_price_style( $id );
	$supports = isset( $style['supports'] ) && is_array( $style['supports'] )
		? $style['supports']
		: array();

	$defaults = array(
		'fields'         => true,
		'slider'         => false,
		'buckets'        => false,
		'histogram'      => false,
		'goButton'       => true,
		'separator'      => true,
		'applyButton'    => false,
		'labelPosition'  => false,
		'rangeOverrides' => false,
		'step'           => false,
	);

	foreach ( $defaults as $key => $fallback ) {
		if ( ! array_key_exists( $key, $supports ) ) {
			$supports[ $key ] = $fallback;
		} else {
			$supports[ $key ] = (bool) $supports[ $key ];
		}
	}

	return $supports;
}

/**
 * Modifier class for a style (empty for the default input-fields DOM).
 *
 * @param string $id Style id.
 * @return string
 */
function dsm_loop_filter_price_style_modifier_class( string $id ): string {
	$style = dsm_loop_filter_get_price_style( $id );
	if ( ! is_array( $style ) ) {
		return '';
	}
	$class = isset( $style['modifierClass'] ) && is_string( $style['modifierClass'] )
		? $style['modifierClass']
		: '';

	return $class;
}

/**
 * Normalize bucket layout.
 *
 * @param mixed $raw Raw attr.
 * @return string checkbox|radio|pills|dropdown
 */
function dsm_loop_filter_normalize_bucket_layout( $raw ): string {
	$value   = is_scalar( $raw ) ? (string) $raw : 'checkbox';
	$allowed = array( 'checkbox', 'radio', 'pills', 'dropdown' );

	return in_array( $value, $allowed, true ) ? $value : 'checkbox';
}

/**
 * Normalize slider value-label position.
 *
 * @param mixed $raw Raw attr.
 * @return string above|tooltip|below|none
 */
function dsm_loop_filter_normalize_price_label_position( $raw ): string {
	$value   = is_scalar( $raw ) ? (string) $raw : 'above';
	$allowed = array( 'above', 'tooltip', 'below', 'none' );

	return in_array( $value, $allowed, true ) ? $value : 'above';
}

/**
 * Normalize slider-local apply mode.
 *
 * @param mixed $raw Raw attr.
 * @return string auto|button
 */
function dsm_loop_filter_normalize_price_apply_mode( $raw ): string {
	return 'button' === (string) $raw ? 'button' : 'auto';
}

/**
 * Parse author-defined price buckets (`min,max` or `min,max,Label` per line).
 *
 * @param string $raw Textarea value.
 * @return list<array{min: string, max: string, label: string}>
 */
function dsm_loop_filter_parse_price_buckets( string $raw ): array {
	$out   = array();
	$lines = preg_split( '/\r\n|\r|\n/', $raw );
	if ( ! is_array( $lines ) ) {
		return $out;
	}

	foreach ( $lines as $line ) {
		$trimmed = trim( (string) $line );
		if ( '' === $trimmed || 0 === strpos( $trimmed, '#' ) ) {
			continue;
		}
		$parts = array_map( 'trim', explode( ',', $trimmed ) );
		$min   = $parts[0] ?? '';
		$max   = $parts[1] ?? '';
		$label = implode( ',', array_slice( $parts, 2 ) );
		if ( '' === $min && '' === $max ) {
			continue;
		}
		$out[] = array(
			'min'   => $min,
			'max'   => $max,
			'label' => $label,
		);
	}

	/**
	 * Filter parsed Price filter buckets.
	 *
	 * @param array<int, array{min: string, max: string, label: string}> $out Parsed buckets.
	 * @param string                                                $raw Raw textarea.
	 */
	$filtered = apply_filters( 'dsm_loop_filter_price_buckets', $out, $raw );

	return is_array( $filtered ) ? $filtered : $out;
}

/**
 * Even slices of a price span. First is under the first cut, last is over the last cut.
 *
 * @param float $min   Catalog or override min.
 * @param float $max   Catalog or override max.
 * @param int   $count Button count, clamped 2–8.
 * @return list<array{min: string, max: string, label: string}>
 */
function dsm_loop_filter_auto_price_buckets( float $min, float $max, int $count = 4 ): array {
	if ( $max <= $min ) {
		return array();
	}

	$slices = min( 8, max( 2, $count ) );
	$span   = $max - $min;
	$out    = array();

	for ( $i = 0; $i < $slices; $i++ ) {
		$from  = 0 === $i ? '' : (string) ( $min + ( $span * $i ) / $slices );
		$to    = ( $i === $slices - 1 ) ? '' : (string) ( $min + ( $span * ( $i + 1 ) ) / $slices );
		$out[] = array(
			'min'   => $from,
			'max'   => $to,
			'label' => '',
		);
	}

	/**
	 * Filter auto-built Price shortcut ranges.
	 *
	 * @param array<int, array{min: string, max: string, label: string}> $out   Ranges.
	 * @param float                                               $min   Bound min.
	 * @param float                                               $max   Bound max.
	 * @param int                                                 $count Requested count.
	 */
	$filtered = apply_filters( 'dsm_loop_filter_auto_price_buckets', $out, $min, $max, $count );

	return is_array( $filtered ) ? $filtered : $out;
}

/**
 * Woo / fallback currency config for price labels.
 *
 * @param string $prefix Manual prefix (used when Woo is off).
 * @param string $suffix Manual suffix (used when Woo is off).
 * @return array<string, mixed>
 */
function dsm_loop_filter_price_currency( string $prefix = '', string $suffix = '' ): array {
	if ( function_exists( 'get_woocommerce_currency_symbol' ) ) {
		$symbol = html_entity_decode( (string) get_woocommerce_currency_symbol(), ENT_QUOTES, 'UTF-8' );
		return array(
			'symbol'   => $symbol,
			'position' => (string) get_option( 'woocommerce_currency_pos', 'left' ),
			'decimals' => function_exists( 'wc_get_price_decimals' ) ? (int) wc_get_price_decimals() : 2,
			'thousand' => function_exists( 'wc_get_price_thousand_separator' ) ? (string) wc_get_price_thousand_separator() : ',',
			'decimal'  => function_exists( 'wc_get_price_decimal_separator' ) ? (string) wc_get_price_decimal_separator() : '.',
			'prefix'   => '',
			'suffix'   => '',
		);
	}

	return array(
		'symbol'   => '' !== $prefix ? $prefix : $suffix,
		'position' => ( '' !== $suffix && '' === $prefix ) ? 'right_space' : 'left',
		'decimals' => 0,
		'thousand' => ',',
		'decimal'  => '.',
		'prefix'   => $prefix,
		'suffix'   => $suffix,
	);
}

/**
 * Prefix / suffix strings for a currency config (manual or Woo symbol).
 *
 * @param array<string, mixed> $currency Currency config.
 * @return array{prefix: string, suffix: string}
 */
function dsm_loop_filter_price_currency_affixes( array $currency ): array {
	$prefix = isset( $currency['prefix'] ) ? (string) $currency['prefix'] : '';
	$suffix = isset( $currency['suffix'] ) ? (string) $currency['suffix'] : '';
	if ( '' !== $prefix || '' !== $suffix ) {
		return array(
			'prefix' => $prefix,
			'suffix' => $suffix,
		);
	}

	$symbol = isset( $currency['symbol'] ) ? (string) $currency['symbol'] : '';
	if ( '' === $symbol ) {
		return array(
			'prefix' => '',
			'suffix' => '',
		);
	}

	$position = isset( $currency['position'] ) ? (string) $currency['position'] : 'left';
	switch ( $position ) {
		case 'right':
			return array(
				'prefix' => '',
				'suffix' => $symbol,
			);
		case 'right_space':
			return array(
				'prefix' => '',
				'suffix' => ' ' . $symbol,
			);
		case 'left_space':
			return array(
				'prefix' => $symbol . ' ',
				'suffix' => '',
			);
		case 'left':
		default:
			return array(
				'prefix' => $symbol,
				'suffix' => '',
			);
	}
}

/**
 * Split a formatted price into prefix, numeric amount, and suffix.
 *
 * @param float                $value    Amount.
 * @param array<string, mixed> $currency Currency config.
 * @param bool                 $clean    Drop decimals for bound chips.
 * @return array{prefix: string, amount: string, suffix: string}
 */
function dsm_loop_filter_format_price_parts( float $value, array $currency, bool $clean = false ): array {
	$decimals = $clean ? 0 : max( 0, (int) ( $currency['decimals'] ?? 0 ) );
	$rounded  = $clean ? (float) round( $value ) : $value;
	$thousand = isset( $currency['thousand'] ) ? (string) $currency['thousand'] : ',';
	$decimal  = isset( $currency['decimal'] ) ? (string) $currency['decimal'] : '.';
	$number   = number_format( abs( $rounded ), $decimals, $decimal, $thousand );
	if ( $rounded < 0 ) {
		$number = '-' . $number;
	}

	$affixes = dsm_loop_filter_price_currency_affixes( $currency );

	return array(
		'prefix' => $affixes['prefix'],
		'amount' => $number,
		'suffix' => $affixes['suffix'],
	);
}

/**
 * Wrap prefix / amount / suffix for slider labels and tooltips.
 *
 * Empty prefix/suffix omit their spans. Amount is always wrapped. Text is escaped.
 *
 * @param array{prefix?: string, amount?: string, suffix?: string} $parts Price parts.
 * @return string
 */
function dsm_loop_filter_price_bound_inner_html( array $parts ): string {
	$prefix = isset( $parts['prefix'] ) ? (string) $parts['prefix'] : '';
	$amount = isset( $parts['amount'] ) ? (string) $parts['amount'] : '';
	$suffix = isset( $parts['suffix'] ) ? (string) $parts['suffix'] : '';
	$html   = '';
	if ( '' !== $prefix ) {
		$html .= '<span class="dsm-loop-filter__price-currency-prefix">' . esc_html( $prefix ) . '</span>';
	}
	$html .= '<span class="dsm-loop-filter__price-value-amount">' . esc_html( $amount ) . '</span>';
	if ( '' !== $suffix ) {
		$html .= '<span class="dsm-loop-filter__price-currency-suffix">' . esc_html( $suffix ) . '</span>';
	}

	if ( function_exists( 'et_core_intentionally_unescaped' ) ) {
		return et_core_intentionally_unescaped( $html, 'html' );
	}

	return $html;
}

/**
 * Format a price for labels (Woo separators / position; never hardcodes $).
 *
 * @param float                $value    Amount.
 * @param array<string, mixed> $currency Currency config.
 * @param bool                 $clean    Drop decimals for bound chips.
 * @return string
 */
function dsm_loop_filter_format_price_display( float $value, array $currency, bool $clean = false ): string {
	$parts = dsm_loop_filter_format_price_parts( $value, $currency, $clean );

	return $parts['prefix'] . $parts['amount'] . $parts['suffix'];
}

/**
 * Auto-label a bucket when no custom label is set.
 *
 * @param array{min: string, max: string, label: string} $bucket   Bucket.
 * @param array<string, mixed>                           $currency Currency.
 * @return string
 */
function dsm_loop_filter_auto_label_price_bucket( array $bucket, array $currency ): string {
	if ( '' !== trim( (string) ( $bucket['label'] ?? '' ) ) ) {
		return (string) $bucket['label'];
	}
	$min_raw = isset( $bucket['min'] ) ? (string) $bucket['min'] : '';
	$max_raw = isset( $bucket['max'] ) ? (string) $bucket['max'] : '';
	$has_min = '' !== $min_raw && is_numeric( $min_raw );
	$has_max = '' !== $max_raw && is_numeric( $max_raw );

	if ( $has_max && ! $has_min ) {
		return sprintf(
			/* translators: %s: formatted price */
			__( 'Under %s', 'dsm-supreme-modules-pro-for-divi' ),
			dsm_loop_filter_format_price_display( (float) $max_raw, $currency, true )
		);
	}
	if ( $has_min && ! $has_max ) {
		return sprintf(
			/* translators: %s: formatted price */
			__( 'Over %s', 'dsm-supreme-modules-pro-for-divi' ),
			dsm_loop_filter_format_price_display( (float) $min_raw, $currency, true )
		);
	}
	if ( $has_min && $has_max ) {
		return sprintf(
			/* translators: 1: min price, 2: max price */
			__( '%1$s – %2$s', 'dsm-supreme-modules-pro-for-divi' ),
			dsm_loop_filter_format_price_display( (float) $min_raw, $currency, true ),
			dsm_loop_filter_format_price_display( (float) $max_raw, $currency, true )
		);
	}

	return '';
}

/**
 * Round catalog bounds outward to clean step-aligned numbers.
 *
 * @param float $min  Raw min.
 * @param float $max  Raw max.
 * @param float $step Step (default 1).
 * @return array{0: float, 1: float}
 */
function dsm_loop_filter_round_price_bounds( float $min, float $max, float $step = 1.0 ): array {
	$step = $step > 0 ? $step : 1.0;
	$min  = floor( $min / $step ) * $step;
	$max  = ceil( $max / $step ) * $step;
	if ( $step >= 1 ) {
		$min = floor( $min );
		$max = ceil( $max );
	}
	if ( $max < $min ) {
		$max = $min;
	}

	return array( $min, $max );
}

/**
 * Whether the WooCommerce product meta lookup table exists.
 *
 * @return bool
 */
function dsm_loop_filter_wc_lookup_table_exists(): bool {
	global $wpdb;
	static $exists = null;
	if ( is_bool( $exists ) ) {
		return $exists;
	}
	if ( ! isset( $wpdb ) || ! is_object( $wpdb ) ) {
		$exists = false;
		return false;
	}
	$table = $wpdb->prefix . 'wc_product_meta_lookup';
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	$found  = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
	$exists = is_string( $found ) && $found === $table;

	return $exists;
}

/**
 * One aggregated price-stats query (min/max + optional histogram counts).
 *
 * Uses `wc_product_meta_lookup` when present; otherwise `_price` postmeta.
 * `$product_ids` null = all published products (or the given post types).
 *
 * @param array<int, string>   $post_types   Loop post types.
 * @param array<int, int>|null $product_ids  Restricted IDs, or null for the catalog.
 * @param int                  $bucket_count Histogram buckets (0 = skip histogram).
 * @param float                $step         Step for outward rounding.
 * @return array{min: float, max: float, buckets: list<array{from: float, to: float, count: int}>, empty: bool}
 */
function dsm_loop_filter_query_price_stats( array $post_types, ?array $product_ids, int $bucket_count, float $step = 1.0 ): array {
	$empty = array(
		'min'     => 0.0,
		'max'     => 0.0,
		'buckets' => array(),
		'empty'   => true,
	);

	global $wpdb;
	if ( ! isset( $wpdb ) || ! is_object( $wpdb ) ) {
		return $empty;
	}

	$types = array();
	foreach ( $post_types as $pt ) {
		$pt = sanitize_key( (string) $pt );
		if ( '' !== $pt ) {
			$types[] = $pt;
		}
	}
	if ( empty( $types ) ) {
		$types = array( 'product' );
	}

	$id_in     = '';
	$id_params = array();
	if ( is_array( $product_ids ) ) {
		$ids = array();
		foreach ( $product_ids as $id ) {
			$id = absint( $id );
			if ( $id > 0 ) {
				$ids[] = $id;
			}
		}
		$ids = array_values( array_unique( $ids ) );
		if ( empty( $ids ) ) {
			return $empty;
		}
		$id_in     = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
		$id_params = $ids;
	}

	$type_placeholders = implode( ',', array_fill( 0, count( $types ), '%s' ) );

	if ( dsm_loop_filter_wc_lookup_table_exists() && in_array( 'product', $types, true ) ) {
		$lookup    = $wpdb->prefix . 'wc_product_meta_lookup';
		$id_clause = '' !== $id_in ? " AND lookup.product_id IN ({$id_in})" : '';
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- Prefixed table + $wpdb->prepare() on placeholder IN lists.
		$sql      = "SELECT MIN(lookup.min_price) AS price_min, MAX(lookup.max_price) AS price_max
			FROM {$lookup} lookup
			INNER JOIN {$wpdb->posts} posts ON posts.ID = lookup.product_id
			WHERE posts.post_status = 'publish'
			AND posts.post_type IN ({$type_placeholders})
			AND lookup.min_price IS NOT NULL
			{$id_clause}";
		$prepared = $wpdb->prepare( $sql, array_merge( $types, $id_params ) );
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared
	} else {
		$id_clause = '' !== $id_in ? " AND pm.post_id IN ({$id_in})" : '';
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- Prefixed table + $wpdb->prepare() on placeholder IN lists.
		$sql      = "SELECT MIN(CAST(pm.meta_value AS DECIMAL(20,6))) AS price_min, MAX(CAST(pm.meta_value AS DECIMAL(20,6))) AS price_max
			FROM {$wpdb->postmeta} pm
			INNER JOIN {$wpdb->posts} posts ON posts.ID = pm.post_id
			WHERE pm.meta_key = '_price'
			AND pm.meta_value <> ''
			AND posts.post_status = 'publish'
			AND posts.post_type IN ({$type_placeholders})
			{$id_clause}";
		$prepared = $wpdb->prepare( $sql, array_merge( $types, $id_params ) );
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared
	}

	if ( ! is_string( $prepared ) ) {
		return $empty;
	}

	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared
	$row = $wpdb->get_row( $prepared, ARRAY_A );
	if ( ! is_array( $row ) || ! isset( $row['price_min'] ) || null === $row['price_min'] ) {
		return $empty;
	}

	$min = (float) $row['price_min'];
	$max = (float) $row['price_max'];
	if ( $max < $min ) {
		$max = $min;
	}
	[ $min, $max ] = dsm_loop_filter_round_price_bounds( $min, $max, $step );

	$buckets      = array();
	$bucket_count = max( 0, $bucket_count );
	if ( $bucket_count > 0 && $max > $min ) {
		$width = ( $max - $min ) / $bucket_count;
		if ( $width <= 0 ) {
			$width = 1;
		}

		if ( dsm_loop_filter_wc_lookup_table_exists() && in_array( 'product', $types, true ) ) {
			$lookup    = $wpdb->prefix . 'wc_product_meta_lookup';
			$id_clause = '' !== $id_in ? " AND lookup.product_id IN ({$id_in})" : '';
			// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- Prefixed table + $wpdb->prepare() on placeholder IN lists.
			$hist_sql      = "SELECT LEAST({$bucket_count} - 1, GREATEST(0, FLOOR( (lookup.min_price - %f) / %f ))) AS bucket_idx, COUNT(*) AS bucket_count
				FROM {$lookup} lookup
				INNER JOIN {$wpdb->posts} posts ON posts.ID = lookup.product_id
				WHERE posts.post_status = 'publish'
				AND posts.post_type IN ({$type_placeholders})
				AND lookup.min_price IS NOT NULL
				{$id_clause}
				GROUP BY bucket_idx";
			$hist_prepared = $wpdb->prepare(
				$hist_sql,
				array_merge( array( $min, $width ), $types, $id_params )
			);
			// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared
		} else {
			$id_clause = '' !== $id_in ? " AND pm.post_id IN ({$id_in})" : '';
			// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- Prefixed table + $wpdb->prepare() on placeholder IN lists.
			$hist_sql      = "SELECT LEAST({$bucket_count} - 1, GREATEST(0, FLOOR( (CAST(pm.meta_value AS DECIMAL(20,6)) - %f) / %f ))) AS bucket_idx, COUNT(*) AS bucket_count
				FROM {$wpdb->postmeta} pm
				INNER JOIN {$wpdb->posts} posts ON posts.ID = pm.post_id
				WHERE pm.meta_key = '_price'
				AND pm.meta_value <> ''
				AND posts.post_status = 'publish'
				AND posts.post_type IN ({$type_placeholders})
				{$id_clause}
				GROUP BY bucket_idx";
			$hist_prepared = $wpdb->prepare(
				$hist_sql,
				array_merge( array( $min, $width ), $types, $id_params )
			);
			// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared
		}

		$counts = array();
		if ( is_string( $hist_prepared ) ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared
			$rows = $wpdb->get_results( $hist_prepared, ARRAY_A );
			if ( is_array( $rows ) ) {
				foreach ( $rows as $hist_row ) {
					$idx = isset( $hist_row['bucket_idx'] ) ? (int) $hist_row['bucket_idx'] : -1;
					if ( $idx >= 0 && $idx < $bucket_count ) {
						$counts[ $idx ] = isset( $hist_row['bucket_count'] ) ? (int) $hist_row['bucket_count'] : 0;
					}
				}
			}
		}

		for ( $i = 0; $i < $bucket_count; $i++ ) {
			$from      = $min + ( $i * $width );
			$to        = ( $i === $bucket_count - 1 ) ? $max : $min + ( ( $i + 1 ) * $width );
			$buckets[] = array(
				'from'  => $from,
				'to'    => $to,
				'count' => $counts[ $i ] ?? 0,
			);
		}
	}

	return array(
		'min'     => $min,
		'max'     => $max,
		'buckets' => $buckets,
		'empty'   => $max <= $min && 0.0 === $min,
	);
}
