<?php
/**
 * Admin list, tabs, and grid editor for the Table library CPT.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Includes;

use DiviSupreme\Modules\Table;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * WordPress admin chrome for `dsm_table_lib`.
 */
final class DsmTableLibraryAdmin {

	/**
	 * User meta key for library editor page size.
	 */
	private const EDITOR_PER_PAGE_META = 'dsm_table_lib_per_page';

	/**
	 * Default library editor page size.
	 */
	private const EDITOR_PER_PAGE_DEFAULT = 20;

	/**
	 * Minimum library editor page size.
	 */
	private const EDITOR_PER_PAGE_MIN = 5;

	/**
	 * Maximum library editor page size (Add Row / editor input cap).
	 */
	private const EDITOR_PER_PAGE_MAX = 100;

	/**
	 * Register list columns, tabs, and the grid / CSV / usage metaboxes.
	 *
	 * @return void
	 */
	public static function register(): void {
		add_action( 'admin_menu', array( self::class, 'register_admin_menu' ), 100 );
		add_action( 'admin_head', array( self::class, 'hide_find_sidebar_css' ) );
		add_filter( 'parent_file', array( self::class, 'filter_parent_file' ) );
		add_filter( 'submenu_file', array( self::class, 'filter_submenu_file' ) );
		add_action( 'admin_enqueue_scripts', array( self::class, 'enqueue_admin_assets' ) );
		add_filter( 'tiny_mce_before_init', array( self::class, 'filter_rich_editor_tinymce' ), 10, 2 );
		add_action( 'all_admin_notices', array( self::class, 'maybe_render_tabs' ) );
		add_filter( 'manage_' . DsmTableLibrary::POST_TYPE . '_posts_columns', array( self::class, 'list_columns' ) );
		add_action( 'manage_' . DsmTableLibrary::POST_TYPE . '_posts_custom_column', array( self::class, 'render_list_column' ), 10, 2 );
		add_action( 'add_meta_boxes_' . DsmTableLibrary::POST_TYPE, array( self::class, 'register_meta_boxes' ) );
		add_filter(
			'get_user_option_meta-box-order_' . DsmTableLibrary::POST_TYPE,
			array( self::class, 'prefer_publish_metabox_first' )
		);
		add_action( 'save_post_' . DsmTableLibrary::POST_TYPE, array( self::class, 'save_grid_from_request' ), 20, 2 );
		add_filter( 'redirect_post_location', array( self::class, 'filter_redirect_after_save' ), 10, 2 );
		add_action( 'post_edit_form_tag', array( self::class, 'maybe_multipart_form' ) );
		add_action( 'admin_notices', array( self::class, 'maybe_render_save_notice' ) );
		add_action( 'wp_ajax_dsm_table_lib_import_csv', array( self::class, 'ajax_import_csv' ) );
	}

	/**
	 * Add the CPT list under Divi Supreme without hijacking the settings page.
	 *
	 * Same pattern as Form Entries: `show_in_menu` is false on the CPT, then
	 * `add_submenu_page` attaches `edit.php?post_type=…`. Using
	 * `show_in_menu => 'divi_supreme_settings'` on `register_post_type`
	 * replaces the parent’s first submenu (the settings screen).
	 *
	 * @return void
	 */
	public static function register_admin_menu(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		add_submenu_page(
			'divi_supreme_settings',
			__( 'Tables', 'dsm-supreme-modules-pro-for-divi' ),
			__( 'Tables', 'dsm-supreme-modules-pro-for-divi' ),
			'manage_options',
			'edit.php?post_type=' . DsmTableLibrary::POST_TYPE
		);
	}

	/**
	 * Hide Find on pages from the sidebar only. Do not `remove_submenu_page()` —
	 * WordPress then treats `admin.php?page=dsm_table_finder` as forbidden.
	 *
	 * @return void
	 */
	public static function hide_find_sidebar_css(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		echo '<style id="dsm-table-hide-find-menu">#adminmenu a[href*="page=dsm_table_finder"]{display:none!important;}</style>';
	}

	/**
	 * Keep Divi Supreme Pro expanded on Library / Find screens.
	 *
	 * @param string $parent_file Parent menu slug.
	 * @return string
	 */
	public static function filter_parent_file( string $parent_file ): string {
		if ( self::is_library_screen() || self::is_finder_screen() ) {
			return 'divi_supreme_settings';
		}

		return $parent_file;
	}

	/**
	 * Highlight Tables (not a hidden Find slug) in the sidebar.
	 *
	 * @param string|null $submenu_file Current submenu slug.
	 * @return string|null
	 */
	public static function filter_submenu_file( $submenu_file ) {
		if ( self::is_library_screen() || self::is_finder_screen() ) {
			return 'edit.php?post_type=' . DsmTableLibrary::POST_TYPE;
		}

		return $submenu_file;
	}

	/**
	 * Lightweight styles for library + Find tabs.
	 *
	 * @param string $hook_suffix Current admin page hook.
	 * @return void
	 */
	public static function enqueue_admin_assets( string $hook_suffix ): void {
		if ( ! self::is_library_screen() && false === strpos( $hook_suffix, DsmTableFinderAdmin::PAGE_SLUG ) ) {
			return;
		}

		$css_path = defined( 'DSM_DIR_PATH' ) ? DSM_DIR_PATH . 'divi-5/assets/css/dsm-table-library-admin.css' : '';
		$css_url  = defined( 'DSM_DIR_URL' ) ? DSM_DIR_URL . 'assets/css/dsm-table-library-admin.css' : '';
		if ( '' !== $css_path && '' !== $css_url && is_readable( $css_path ) ) {
			wp_enqueue_style(
				'dsm-table-library-admin',
				$css_url,
				array(),
				(string) filemtime( $css_path )
			);
		}

		if ( self::is_library_edit_screen() ) {
			wp_enqueue_media();
			wp_enqueue_editor();
			$path = defined( 'DSM_DIR_PATH' ) ? DSM_DIR_PATH . 'divi-5/assets/js/dsm-table-library-admin.js' : '';
			$url  = defined( 'DSM_DIR_URL' ) ? DSM_DIR_URL . 'assets/js/dsm-table-library-admin.js' : '';
			if ( '' !== $path && '' !== $url && is_readable( $path ) ) {
				wp_enqueue_script(
					'dsm-table-library-admin',
					$url,
					array( 'jquery', 'jquery-ui-sortable', 'editor' ),
					(string) filemtime( $path ),
					true
				);
				$edit_post = get_post();
				$post_id   = $edit_post instanceof \WP_Post ? (int) $edit_post->ID : 0;

				wp_localize_script(
					'dsm-table-library-admin',
					'dsmTableLibraryAdmin',
					array(
						'maxCols'   => 20,
						'maxRows'   => 100,
						'ajaxUrl'   => admin_url( 'admin-ajax.php' ),
						'ajaxNonce' => wp_create_nonce( 'dsm_table_lib_import_csv' ),
						'postId'    => $post_id,
						'i18n'      => array(
							/* translators: %d: number of selected cells */
							'cellOne'      => __( '%d cell selected', 'dsm-supreme-modules-pro-for-divi' ),
							/* translators: %d: number of selected cells */
							'cellMany'     => __( '%d cells selected', 'dsm-supreme-modules-pro-for-divi' ),
							/* translators: %d: number of selected rows */
							'rowOne'       => __( '%d row selected', 'dsm-supreme-modules-pro-for-divi' ),
							/* translators: %d: number of selected rows */
							'rowMany'      => __( '%d rows selected', 'dsm-supreme-modules-pro-for-divi' ),
							/* translators: %d: number of selected columns */
							'colOne'       => __( '%d column selected', 'dsm-supreme-modules-pro-for-divi' ),
							/* translators: %d: number of selected columns */
							'colMany'      => __( '%d columns selected', 'dsm-supreme-modules-pro-for-divi' ),
							'editRich'     => __( 'Edit formatted text', 'dsm-supreme-modules-pro-for-divi' ),
							'addFormatted' => __( 'Click to add formatted text', 'dsm-supreme-modules-pro-for-divi' ),
							'typeText'     => __( 'Text', 'dsm-supreme-modules-pro-for-divi' ),
							'typeRich'     => __( 'Rich text', 'dsm-supreme-modules-pro-for-divi' ),
							'typeMixed'    => __( 'Mixed', 'dsm-supreme-modules-pro-for-divi' ),
							'typeNone'     => __( 'Select a cell', 'dsm-supreme-modules-pro-for-divi' ),
							'importing'    => __( 'Importing…', 'dsm-supreme-modules-pro-for-divi' ),
							'importFail'   => __( 'Could not import the CSV.', 'dsm-supreme-modules-pro-for-divi' ),
						),
					)
				);
			}
		}
	}

	/**
	 * Keep the library TinyMCE instance a fixed height so Apply / Cancel stay clickable.
	 *
	 * @param array<string, mixed> $init      TinyMCE init.
	 * @param string               $editor_id Editor id.
	 * @return array<string, mixed>
	 */
	public static function filter_rich_editor_tinymce( array $init, string $editor_id ): array {
		if ( 'dsm_table_library_rich_editor' !== $editor_id ) {
			return $init;
		}

		$init['wp_autoresize_on'] = false;
		$init['resize']           = true;
		$init['min_height']       = 240;
		$init['height']           = 240;

		return $init;
	}

	/**
	 * All tables | Find on pages tabs on CPT and Find screens.
	 *
	 * @return void
	 */
	public static function maybe_render_tabs(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$active = '';
		if ( self::is_library_screen() ) {
			$active = 'library';
		} elseif ( self::is_finder_screen() ) {
			$active = 'find';
		}

		if ( '' === $active ) {
			return;
		}

		self::render_tabs( $active );

		if ( 'library' === $active && self::is_library_list_screen() ) {
			echo '<div class="notice notice-info dsm-table-library-help"><p>';
			echo esc_html__(
				'Shared tables used by Table modules. Open one to edit rows, columns, or import a CSV. You can also save a table from the Visual Builder.',
				'dsm-supreme-modules-pro-for-divi'
			);
			echo '</p></div>';
		}
	}

	/**
	 * Print All tables | Find on pages tabs.
	 *
	 * @param string $active `library` or `find`.
	 * @return void
	 */
	public static function render_tabs( string $active ): void {
		$library_url = admin_url( 'edit.php?post_type=' . DsmTableLibrary::POST_TYPE );
		$find_url    = admin_url( 'admin.php?page=' . DsmTableFinderAdmin::PAGE_SLUG );

		echo '<nav class="nav-tab-wrapper dsm-table-library-tabs">';
		echo '<a href="' . esc_url( $library_url ) . '" class="nav-tab' . ( 'library' === $active ? ' nav-tab-active' : '' ) . '">';
		echo esc_html__( 'All tables', 'dsm-supreme-modules-pro-for-divi' );
		echo '</a>';
		echo '<a href="' . esc_url( $find_url ) . '" class="nav-tab' . ( 'find' === $active ? ' nav-tab-active' : '' ) . '">';
		echo esc_html__( 'Find on pages', 'dsm-supreme-modules-pro-for-divi' );
		echo '</a>';
		echo '</nav>';
	}

	/**
	 * Add a Used on column to the library list.
	 *
	 * @param array<string, string> $columns Columns.
	 * @return array<string, string>
	 */
	public static function list_columns( array $columns ): array {
		$date = $columns['date'] ?? '';
		unset( $columns['date'] );
		$columns['dsm_table_usage'] = __( 'Used on', 'dsm-supreme-modules-pro-for-divi' );
		if ( '' !== $date ) {
			$columns['date'] = $date;
		}

		return $columns;
	}

	/**
	 * Render the Used on column.
	 *
	 * @param string $column  Column id.
	 * @param int    $post_id Post ID.
	 * @return void
	 */
	public static function render_list_column( string $column, int $post_id ): void {
		if ( 'dsm_table_usage' !== $column ) {
			return;
		}

		self::render_usage_links( $post_id );
	}

	/**
	 * Keep Publish first in the side column (WordPress default).
	 *
	 * A saved user layout can pin Import CSV above `submitdiv` after we
	 * briefly registered that box as `high`. Also drop the retired Used on box.
	 *
	 * @param mixed $order User metabox order option.
	 * @return mixed
	 */
	public static function prefer_publish_metabox_first( $order ) {
		if ( ! is_array( $order ) || ! isset( $order['side'] ) ) {
			return $order;
		}

		$side = array_values(
			array_filter(
				array_map( 'trim', explode( ',', (string) $order['side'] ) ),
				static function ( string $id ): bool {
					return '' !== $id && 'dsm_table_library_usage' !== $id;
				}
			)
		);
		$side = array_values( array_diff( $side, array( 'submitdiv' ) ) );
		array_unshift( $side, 'submitdiv' );
		$order['side'] = implode( ',', $side );

		return $order;
	}

	/**
	 * Register the library grid editor metabox.
	 *
	 * @return void
	 */
	public static function register_meta_boxes(): void {
		add_meta_box(
			'dsm_table_library_summary',
			__( 'Table data', 'dsm-supreme-modules-pro-for-divi' ),
			array( self::class, 'render_summary_metabox' ),
			DsmTableLibrary::POST_TYPE,
			'normal',
			'high'
		);
		add_meta_box(
			'dsm_table_library_csv',
			__( 'Import CSV', 'dsm-supreme-modules-pro-for-divi' ),
			array( self::class, 'render_csv_metabox' ),
			DsmTableLibrary::POST_TYPE,
			'side',
			'default'
		);
	}

	/**
	 * Grid editor metabox (rows and columns).
	 *
	 * @param \WP_Post $post Post.
	 * @return void
	 */
	public static function render_summary_metabox( \WP_Post $post ): void {
		$post_id = (int) $post->ID;
		$grid    = DsmTableLibrary::get_grid( $post_id );
		if ( ! is_array( $grid ) ) {
			$grid = DsmTableLibrary::get_blank_grid();
		}

		wp_nonce_field( 'dsm_table_lib_grid', 'dsm_table_lib_grid_nonce' );

		$is_blank = DsmTableLibrary::is_blank_grid( $grid );
		if ( $is_blank ) {
			echo '<p class="dsm-table-library-empty">';
			echo esc_html__( 'This library table is unused and not designed yet. Add columns and rows below, or import a CSV from the sidebar. Table modules that pick this item stay in sync with this table.', 'dsm-supreme-modules-pro-for-divi' );
			echo '</p>';
		} else {
			echo '<p class="dsm-table-library-help-line">';
			echo esc_html__( 'The first row is the header. Hover a row or column for select, drag, and + insert. Shift-click or ⌘/Ctrl-click cells to merge. Select a cell, then use Cell type in the toolbar (Rich text opens the visual editor). Button, icon, and image cell types still edit in Visual Builder → Edit Table Data.', 'dsm-supreme-modules-pro-for-divi' );
			echo '</p>';
		}

		echo '<p class="dsm-table-library-used-on description">';
		echo '<strong>' . esc_html__( 'Used on:', 'dsm-supreme-modules-pro-for-divi' ) . '</strong> ';
		self::render_usage_links( $post_id );
		echo '</p>';

		self::render_grid_editor( $grid );
	}

	/**
	 * Sidebar CSV import metabox.
	 *
	 * @param \WP_Post $post Post.
	 * @return void
	 */
	public static function render_csv_metabox( \WP_Post $post ): void {
		unset( $post );

		echo '<div class="dsm-table-library-csv">';
		echo '<p class="description">';
		echo esc_html(
			sprintf(
				/* translators: 1: max columns 2: max imported rows */
				__( 'Choose a file, then click Import CSV. You can import up to %1$d columns and %2$d rows. Large files import in batches.', 'dsm-supreme-modules-pro-for-divi' ),
				20,
				DsmTableSource::get_import_max_rows()
			)
		);
		echo '</p>';
		echo '<p><label for="dsm_table_lib_csv">';
		echo esc_html__( 'CSV file', 'dsm-supreme-modules-pro-for-divi' );
		echo '</label><br />';
		echo '<input type="file" id="dsm_table_lib_csv" name="dsm_table_lib_csv" accept=".csv,text/csv,text/plain" />';
		echo '</p>';
		echo '<p><label for="dsm_table_lib_csv_header">';
		echo '<input type="checkbox" id="dsm_table_lib_csv_header" name="dsm_table_lib_csv_header" value="on" checked="checked" /> ';
		echo esc_html__( 'Use the first CSV row as column headers', 'dsm-supreme-modules-pro-for-divi' );
		echo '</label></p>';
		echo '<p class="dsm-table-library-csv__actions">';
		echo '<button type="button" class="button button-primary" id="dsm_table_lib_import_csv" disabled="disabled">';
		echo esc_html__( 'Import CSV', 'dsm-supreme-modules-pro-for-divi' );
		echo '</button>';
		echo '</p>';
		echo '<p class="dsm-table-library-csv__status" id="dsm_table_lib_import_status" hidden></p>';
		echo '</div>';
	}

	/**
	 * Enable file upload on the library CPT edit form.
	 *
	 * @param \WP_Post $post Post being edited.
	 * @return void
	 */
	public static function maybe_multipart_form( \WP_Post $post ): void {
		if ( DsmTableLibrary::POST_TYPE !== $post->post_type ) {
			return;
		}

		echo ' enctype="multipart/form-data"';
	}

	/**
	 * Data rows shown on one library editor page (per-user, clamped 5–100).
	 *
	 * @return int
	 */
	public static function get_editor_page_size(): int {
		$user_id = get_current_user_id();
		if ( $user_id > 0 ) {
			$meta = get_user_meta( $user_id, self::EDITOR_PER_PAGE_META, true );
			if ( is_numeric( $meta ) && (int) $meta > 0 ) {
				return self::clamp_editor_page_size( absint( $meta ) );
			}
		}

		return self::EDITOR_PER_PAGE_DEFAULT;
	}

	/**
	 * Clamp a library editor page size to the 5–100 safety range.
	 *
	 * @param int $size Requested size.
	 * @return int
	 */
	private static function clamp_editor_page_size( int $size ): int {
		if ( $size < self::EDITOR_PER_PAGE_MIN ) {
			return self::EDITOR_PER_PAGE_MIN;
		}

		if ( $size > self::EDITOR_PER_PAGE_MAX ) {
			return self::EDITOR_PER_PAGE_MAX;
		}

		return $size;
	}

	/**
	 * Persist the posted per-page size for the current user.
	 *
	 * @param array<string, mixed> $request Unslashed POST after nonce verification.
	 * @return void
	 */
	private static function persist_editor_page_size_from_request( array $request ): void {
		if ( ! isset( $request['dsm_table_lib_per_page'] ) ) {
			return;
		}

		$user_id = get_current_user_id();
		if ( $user_id <= 0 ) {
			return;
		}

		update_user_meta(
			$user_id,
			self::EDITOR_PER_PAGE_META,
			self::clamp_editor_page_size( absint( $request['dsm_table_lib_per_page'] ) )
		);
	}

	/**
	 * Current library editor page from the request (1-based).
	 *
	 * @return int
	 */
	private static function requested_editor_page(): int {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only pager; edit screen already requires manage_options.
		$page = isset( $_GET['dsm_table_page'] ) ? absint( wp_unslash( (string) $_GET['dsm_table_page'] ) ) : 1;

		return max( 1, $page );
	}

	/**
	 * Current library editor search from the request.
	 *
	 * @return string
	 */
	private static function requested_editor_search(): string {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only filter; edit screen already requires manage_options.
		$raw = isset( $_GET['dsm_table_q'] ) ? sanitize_text_field( wp_unslash( $_GET['dsm_table_q'] ) ) : '';

		return is_string( $raw ) ? $raw : '';
	}

	/**
	 * After save, stay on the requested editor page (or page 1 after CSV import).
	 *
	 * Pager / search / per-page submits still save the grid (same post form)
	 * but MUST NOT show WordPress’s “Post updated.” notice.
	 *
	 * @param string $location Redirect URL.
	 * @param int    $post_id  Post ID.
	 * @return string
	 */
	public static function filter_redirect_after_save( string $location, int $post_id ): string {
		if ( $post_id <= 0 || ! current_user_can( 'manage_options' ) ) {
			return $location;
		}

		if ( DsmTableLibrary::POST_TYPE !== get_post_type( $post_id ) ) {
			return $location;
		}

		if ( ! isset( $_POST['dsm_table_lib_grid_nonce'] ) ) {
			return $location;
		}

		$nonce = sanitize_text_field( wp_unslash( (string) $_POST['dsm_table_lib_grid_nonce'] ) );
		if ( ! wp_verify_nonce( $nonce, 'dsm_table_lib_grid' ) ) {
			return $location;
		}

		$csv_error = isset( $_FILES['dsm_table_lib_csv']['error'] )
			? absint( $_FILES['dsm_table_lib_csv']['error'] )
			: UPLOAD_ERR_NO_FILE;
		if ( UPLOAD_ERR_OK === $csv_error ) {
			$location = remove_query_arg( 'dsm_table_q', $location );
			return add_query_arg( 'dsm_table_page', 1, $location );
		}

		$clear_search = isset( $_POST['dsm_table_lib_clear_search'] );
		$do_search    = isset( $_POST['dsm_table_lib_do_search'] );
		$apply_size   = isset( $_POST['dsm_table_lib_apply_per_page'] );
		$goto_page    = isset( $_POST['dsm_table_lib_goto_page'] );
		$paged_input  = isset( $_POST['dsm_table_lib_paged'] )
			? max( 1, absint( wp_unslash( (string) $_POST['dsm_table_lib_paged'] ) ) )
			: 0;
		$current_page = isset( $_POST['dsm_table_lib_page'] )
			? max( 1, absint( wp_unslash( (string) $_POST['dsm_table_lib_page'] ) ) )
			: 1;

		$search = '';
		if ( ! $clear_search && isset( $_POST['dsm_table_q'] ) ) {
			$search = sanitize_text_field( wp_unslash( (string) $_POST['dsm_table_q'] ) );
		}

		if ( $clear_search || $do_search || $apply_size ) {
			$page = 1;
		} elseif ( $goto_page ) {
			$page = max( 1, absint( wp_unslash( (string) $_POST['dsm_table_lib_goto_page'] ) ) );
		} elseif ( $paged_input > 0 ) {
			$page = $paged_input;
		} else {
			$page = $current_page;
		}

		$pager_nav = $clear_search || $do_search || $apply_size || $goto_page
			|| ( $paged_input > 0 && $paged_input !== $current_page );

		$location = add_query_arg( 'dsm_table_page', $page, $location );
		if ( $pager_nav ) {
			$location = remove_query_arg( array( 'message', 'updated' ), $location );
		}
		if ( '' !== $search ) {
			return add_query_arg( 'dsm_table_q', $search, $location );
		}

		return remove_query_arg( 'dsm_table_q', $location );
	}

	/**
	 * Persist the metabox grid or a CSV import to `_dsm_table_grid`.
	 *
	 * @param int      $post_id Post ID.
	 * @param \WP_Post $post    Post.
	 * @return void
	 */
	public static function save_grid_from_request( int $post_id, \WP_Post $post ): void {
		if ( $post_id <= 0 || wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
			return;
		}

		if ( DsmTableLibrary::POST_TYPE !== $post->post_type ) {
			return;
		}

		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		if ( ! isset( $_POST['dsm_table_lib_grid_nonce'] ) ) {
			return;
		}

		$nonce = sanitize_text_field( wp_unslash( (string) $_POST['dsm_table_lib_grid_nonce'] ) );
		if ( ! wp_verify_nonce( $nonce, 'dsm_table_lib_grid' ) ) {
			return;
		}

		$request = wp_unslash( $_POST );
		self::persist_editor_page_size_from_request( $request );

		$from_csv = self::grid_from_uploaded_csv( $request );
		if ( is_wp_error( $from_csv ) ) {
			self::store_save_notice( 'error', $from_csv->get_error_message() );
			return;
		}

		if ( is_array( $from_csv ) && isset( $from_csv['grid'] ) && is_array( $from_csv['grid'] ) ) {
			$saved = DsmTableLibrary::save_grid( $post_id, $from_csv['grid'], $post );
			if ( null === $saved ) {
				self::store_save_notice( 'error', __( 'Could not save the imported CSV.', 'dsm-supreme-modules-pro-for-divi' ) );
				return;
			}

			$warnings = isset( $from_csv['warnings'] ) && is_array( $from_csv['warnings'] ) ? $from_csv['warnings'] : array();
			if ( array() !== $warnings ) {
				self::store_save_notice( 'warning', implode( ' ', array_map( 'strval', $warnings ) ) );
			}

			return;
		}

		$saved = DsmTableLibrary::save_grid( $post_id, self::grid_from_editor_post( $post_id, $request ), $post );
		if ( null === $saved ) {
			self::store_save_notice( 'error', __( 'Could not save the table.', 'dsm-supreme-modules-pro-for-divi' ) );
		}
	}

	/**
	 * Import a CSV into the library grid immediately (no Update/Publish).
	 *
	 * @return void
	 */
	public static function ajax_import_csv(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error(
				array(
					'message' => __( 'You do not have permission to import a CSV.', 'dsm-supreme-modules-pro-for-divi' ),
				),
				403
			);
		}

		check_ajax_referer( 'dsm_table_lib_import_csv' );

		$post_id = isset( $_POST['post_id'] ) ? absint( wp_unslash( (string) $_POST['post_id'] ) ) : 0;
		$post    = $post_id > 0 ? get_post( $post_id ) : null;

		if ( ! $post instanceof \WP_Post || ! DsmTableLibrary::is_library_post( $post_id, $post ) ) {
			wp_send_json_error(
				array(
					'message' => __( 'Invalid table library item.', 'dsm-supreme-modules-pro-for-divi' ),
				),
				400
			);
		}

		$request  = wp_unslash( $_POST );
		$from_csv = self::grid_from_uploaded_csv( $request );

		if ( null === $from_csv ) {
			wp_send_json_error(
				array(
					'message' => __( 'Choose a file, then click Import CSV.', 'dsm-supreme-modules-pro-for-divi' ),
				)
			);
		}

		if ( is_wp_error( $from_csv ) ) {
			wp_send_json_error(
				array(
					'message' => $from_csv->get_error_message(),
				)
			);
		}

		$saved = DsmTableLibrary::save_grid( $post_id, $from_csv['grid'], $post );
		if ( null === $saved ) {
			wp_send_json_error(
				array(
					'message' => __( 'Could not save the imported CSV.', 'dsm-supreme-modules-pro-for-divi' ),
				)
			);
		}

		$row_count = isset( $saved['rows'] ) && is_array( $saved['rows'] ) ? count( $saved['rows'] ) : 0;
		$warnings  = isset( $from_csv['warnings'] ) && is_array( $from_csv['warnings'] ) ? $from_csv['warnings'] : array();
		$message   = sprintf(
			/* translators: %d: number of imported data rows */
			_n( 'Imported %d row.', 'Imported %d rows.', $row_count, 'dsm-supreme-modules-pro-for-divi' ),
			$row_count
		);

		if ( array() !== $warnings ) {
			$message .= ' ' . implode( ' ', array_map( 'strval', $warnings ) );
			self::store_save_notice( 'warning', $message );
		} else {
			self::store_save_notice( 'success', $message );
		}

		$reload = get_edit_post_link( $post_id, 'raw' );
		if ( ! is_string( $reload ) || '' === $reload ) {
			$reload = admin_url( 'post.php?post=' . $post_id . '&action=edit' );
		}

		wp_send_json_success(
			array(
				'reload' => add_query_arg( 'dsm_table_page', 1, $reload ),
				'rows'   => $row_count,
			)
		);
	}

	/**
	 * Show a one-shot notice after CSV import or a failed save.
	 *
	 * @return void
	 */
	public static function maybe_render_save_notice(): void {
		if ( ! current_user_can( 'manage_options' ) || ! self::is_library_edit_screen() ) {
			return;
		}

		$key  = self::notice_transient_key();
		$data = get_transient( $key );
		if ( ! is_array( $data ) ) {
			return;
		}

		delete_transient( $key );

		$type    = isset( $data['type'] ) ? sanitize_key( (string) $data['type'] ) : 'info';
		$message = isset( $data['message'] ) ? (string) $data['message'] : '';
		if ( '' === $message ) {
			return;
		}

		if ( ! in_array( $type, array( 'error', 'warning', 'success', 'info' ), true ) ) {
			$type = 'info';
		}

		echo '<div class="notice notice-' . esc_attr( $type ) . ' is-dismissible"><p>';
		echo esc_html( $message );
		echo '</p></div>';
	}

	/**
	 * Print usage links for a library item.
	 *
	 * @param int  $post_id Library post ID.
	 * @param bool $as_list Stack links for the sidebar metabox.
	 * @return void
	 */
	private static function render_usage_links( int $post_id, bool $as_list = false ): void {
		$map   = DsmTableFinder::library_usage_map();
		$items = isset( $map[ $post_id ] ) && is_array( $map[ $post_id ] ) ? $map[ $post_id ] : array();

		if ( array() === $items ) {
			echo esc_html__( 'Not used on any page yet.', 'dsm-supreme-modules-pro-for-divi' );
			return;
		}

		$parts = array();
		foreach ( $items as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}
			$title = isset( $item['title'] ) ? (string) $item['title'] : '';
			$edit  = isset( $item['edit_url'] ) ? (string) $item['edit_url'] : '';
			if ( '' === $title ) {
				continue;
			}
			if ( '' !== $edit ) {
				$parts[] = '<a href="' . esc_url( $edit ) . '" target="_blank" rel="noopener noreferrer">' . esc_html( $title ) . '</a>';
			} else {
				$parts[] = esc_html( $title );
			}
		}

		$allowed = array(
			'a' => array(
				'href'   => array(),
				'target' => array(),
				'rel'    => array(),
			),
		);

		if ( $as_list ) {
			echo '<ul class="dsm-table-library-usage-list">';
			foreach ( $parts as $part ) {
				echo '<li>' . wp_kses( $part, $allowed ) . '</li>';
			}
			echo '</ul>';
			return;
		}

		echo wp_kses( implode( ', ', $parts ), $allowed );
	}

	/**
	 * Editable text grid (headers + body/footer/cta rows).
	 *
	 * @param array<string, mixed> $grid Sanitized grid.
	 * @return void
	 */
	private static function render_grid_editor( array $grid ): void {
		$columns = isset( $grid['columns'] ) && is_array( $grid['columns'] ) ? $grid['columns'] : array();
		$rows    = isset( $grid['rows'] ) && is_array( $grid['rows'] ) ? $grid['rows'] : array();
		if ( array() === $columns ) {
			$columns = array(
				array(
					'id'     => 'col-1',
					'header' => '',
				),
			);
		}

		$data_rows = array();
		foreach ( $rows as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$role = isset( $row['role'] ) ? sanitize_key( (string) $row['role'] ) : 'body';
			if ( 'header' === $role ) {
				continue;
			}
			$data_rows[] = $row;
		}

		$all_data_rows = $data_rows;
		$search        = self::requested_editor_search();

		if ( '' !== $search ) {
			$data_rows = array();
			foreach ( $all_data_rows as $row ) {
				if ( self::row_matches_search( $row, $search ) ) {
					$data_rows[] = $row;
				}
			}
		} elseif ( array() === $data_rows ) {
			$data_rows[] = array(
				'id'    => 'row-1',
				'role'  => 'body',
				'cells' => array(),
			);
		}

		$total_data  = count( $data_rows );
		$page_size   = self::get_editor_page_size();
		$total_pages = $total_data > 0 ? max( 1, (int) ceil( $total_data / $page_size ) ) : 1;
		$page        = min( $total_pages, self::requested_editor_page() );
		$offset      = ( $page - 1 ) * $page_size;
		$row_before  = array_slice( $data_rows, 0, $offset );
		$row_after   = array_slice( $data_rows, $offset + $page_size );
		$visible     = array_slice( $data_rows, $offset, $page_size );
		$row_rest    = null;

		if ( '' !== $search ) {
			$visible_ids = array();
			foreach ( $visible as $row ) {
				$rid = isset( $row['id'] ) ? (string) $row['id'] : '';
				if ( '' !== $rid ) {
					$visible_ids[ $rid ] = true;
				}
			}
			$row_rest = array();
			foreach ( $all_data_rows as $row ) {
				$rid = isset( $row['id'] ) ? (string) $row['id'] : '';
				if ( '' === $rid || ! isset( $visible_ids[ $rid ] ) ) {
					$row_rest[] = $row;
				}
			}
		}

		$data_rows = $visible;

		$header_cells = array();
		foreach ( $rows as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$role = isset( $row['role'] ) ? sanitize_key( (string) $row['role'] ) : 'body';
			if ( 'header' === $role ) {
				$header_cells = isset( $row['cells'] ) && is_array( $row['cells'] ) ? $row['cells'] : array();
				break;
			}
		}

		$covered = self::data_cover_map( $data_rows, $columns, $header_cells );

		echo '<div class="dsm-table-library-board">';
		echo '<div class="dsm-table-library-toolbar">';
		echo '<span class="dsm-table-library-toolbar__group">';
		echo '<span class="dsm-table-library-toolbar__label">';
		echo esc_html__( 'Insert', 'dsm-supreme-modules-pro-for-divi' );
		echo '</span>';
		self::render_toolbar_icon_button(
			'table-col-after',
			__( 'Add column', 'dsm-supreme-modules-pro-for-divi' ),
			array( 'data-dsm-table-add-col' => '' )
		);
		self::render_toolbar_icon_button(
			'table-row-after',
			__( 'Add row', 'dsm-supreme-modules-pro-for-divi' ),
			array(
				'data-dsm-table-add-row'  => '',
				'data-dsm-table-row-role' => 'body',
			)
		);
		echo '</span>';
		echo '<span class="dsm-table-library-toolbar__group">';
		echo '<span class="dsm-table-library-toolbar__label">';
		echo esc_html__( 'Cells', 'dsm-supreme-modules-pro-for-divi' );
		echo '</span>';
		self::render_toolbar_icon_button(
			'editor-expand',
			__( 'Merge cells', 'dsm-supreme-modules-pro-for-divi' ),
			array( 'data-dsm-table-merge' => '' ),
			false,
			true
		);
		self::render_toolbar_icon_button(
			'editor-contract',
			__( 'Split cell', 'dsm-supreme-modules-pro-for-divi' ),
			array( 'data-dsm-table-split' => '' ),
			false,
			true
		);
		echo '</span>';
		echo '<span class="dsm-table-library-toolbar__group">';
		echo '<label class="dsm-table-library-toolbar__label" for="dsm-table-library-toolbar-cell-type">';
		echo esc_html__( 'Cell type', 'dsm-supreme-modules-pro-for-divi' );
		echo '</label>';
		echo '<select id="dsm-table-library-toolbar-cell-type" class="dsm-table-library-toolbar-type" data-dsm-table-toolbar-type disabled>';
		echo '<option value="">';
		echo esc_html__( 'Select a cell', 'dsm-supreme-modules-pro-for-divi' );
		echo '</option>';
		foreach ( self::cell_type_choices( '' ) as $value => $label ) {
			echo '<option value="' . esc_attr( $value ) . '">';
			echo esc_html( $label );
			echo '</option>';
		}
		echo '</select>';
		echo '</span>';
		echo '<p class="dsm-table-library-selection" data-dsm-table-selection-status hidden></p>';
		echo '<span class="dsm-table-library-toolbar__group dsm-table-library-toolbar__group--danger">';
		self::render_toolbar_icon_button(
			'trash',
			__( 'Remove selected', 'dsm-supreme-modules-pro-for-divi' ),
			array( 'data-dsm-table-remove-selected' => '' ),
			true,
			true
		);
		echo '</span>';
		echo '</div>';

		echo '<input type="hidden" name="dsm_table_lib_page" value="' . esc_attr( (string) $page ) . '" />';
		if ( is_array( $row_rest ) ) {
			echo '<textarea name="dsm_table_lib_row_rest" class="dsm-table-library-row-rest" hidden readonly cols="1" rows="1">';
			echo esc_textarea( (string) wp_json_encode( $row_rest ) );
			echo '</textarea>';
		} else {
			echo '<textarea name="dsm_table_lib_row_before" class="dsm-table-library-row-rest" hidden readonly cols="1" rows="1">';
			echo esc_textarea( (string) wp_json_encode( $row_before ) );
			echo '</textarea>';
			echo '<textarea name="dsm_table_lib_row_after" class="dsm-table-library-row-rest" hidden readonly cols="1" rows="1">';
			echo esc_textarea( (string) wp_json_encode( $row_after ) );
			echo '</textarea>';
		}

		self::render_editor_pager( $page, $total_pages, $offset, $total_data, count( $data_rows ), $search, 'top' );

		echo '<div class="dsm-table-library-editor-wrap" id="dsm-table-library-editor">';
		echo '<table class="dsm-table-library-editor"><thead><tr>';
		echo '<th class="dsm-table-library-rowmeta" scope="col">';
		echo '<span class="screen-reader-text">';
		echo esc_html__( 'Row controls', 'dsm-supreme-modules-pro-for-divi' );
		echo '</span>';
		echo '</th>';
		foreach ( $columns as $col_index => $column ) {
			$col_id  = is_array( $column ) && isset( $column['id'] ) ? (string) $column['id'] : '';
			$header  = is_array( $column ) && isset( $column['header'] ) ? (string) $column['header'] : '';
			$h_cell  = isset( $header_cells[ $col_index ] ) && is_array( $header_cells[ $col_index ] ) ? $header_cells[ $col_index ] : array();
			$colspan = self::cell_span( $h_cell, 'colspan' );
			$rowspan = self::cell_span( $h_cell, 'rowspan' );
			$h_key   = 'h:' . (string) $col_index;
			$classes = 'dsm-table-library-header-cell';
			if ( isset( $covered[ $h_key ] ) ) {
				$classes .= ' is-covered';
			}
			echo '<th class="' . esc_attr( $classes ) . '">';
			echo '<div class="dsm-table-library-colhead">';
			echo '<label class="screen-reader-text">';
			echo esc_html__( 'Select column', 'dsm-supreme-modules-pro-for-divi' );
			echo '</label>';
			echo '<input type="checkbox" class="dsm-table-library-col-check" />';
			echo '<input type="hidden" name="dsm_table_lib_col_id[]" value="' . esc_attr( $col_id ) . '" />';
			echo '<input type="text" name="dsm_table_lib_header[]" value="' . esc_attr( $header ) . '" />';
			echo '<input type="hidden" name="dsm_table_lib_header_colspan[]" value="' . esc_attr( (string) $colspan ) . '" />';
			echo '<input type="hidden" name="dsm_table_lib_header_rowspan[]" value="' . esc_attr( (string) $rowspan ) . '" />';
			if ( $colspan > 1 || $rowspan > 1 ) {
				echo '<span class="dsm-table-library-merge-badge">';
				echo esc_html(
					sprintf(
						/* translators: 1: colspan, 2: rowspan */
						__( '%1$d×%2$d', 'dsm-supreme-modules-pro-for-divi' ),
						$colspan,
						$rowspan
					)
				);
				echo '</span>';
			}
			echo '</div>';
			self::render_insert_column_button();
			echo '</th>';
		}
		echo '</tr></thead><tbody>';

		foreach ( $data_rows as $row_index => $row ) {
			$role = isset( $row['role'] ) ? sanitize_key( (string) $row['role'] ) : 'body';
			if ( ! array_key_exists( $role, self::row_role_choices() ) ) {
				$role = 'body';
			}
			$row_id = isset( $row['id'] ) ? (string) $row['id'] : '';
			$cells  = isset( $row['cells'] ) && is_array( $row['cells'] ) ? $row['cells'] : array();
			echo '<tr data-dsm-row-role="' . esc_attr( $role ) . '">';
			echo '<td class="dsm-table-library-rowmeta">';
			echo '<div class="dsm-table-library-rowgutter">';
			echo '<span class="dsm-table-library-row-handle dashicons dashicons-menu" title="' . esc_attr__( 'Drag to reorder', 'dsm-supreme-modules-pro-for-divi' ) . '" aria-hidden="true"></span>';
			echo '<span class="screen-reader-text">';
			echo esc_html__( 'Drag to reorder this row', 'dsm-supreme-modules-pro-for-divi' );
			echo '</span>';
			echo '<label class="screen-reader-text">';
			echo esc_html__( 'Select row', 'dsm-supreme-modules-pro-for-divi' );
			echo '</label>';
			echo '<input type="checkbox" class="dsm-table-library-row-check" />';
			echo '<input type="hidden" name="dsm_table_lib_row_id[]" value="' . esc_attr( $row_id ) . '" />';
			echo '<label class="screen-reader-text" for="dsm_table_lib_row_role_' . esc_attr( (string) $row_index ) . '">';
			echo esc_html__( 'Row type', 'dsm-supreme-modules-pro-for-divi' );
			echo '</label>';
			echo '<select class="dsm-table-library-role" id="dsm_table_lib_row_role_' . esc_attr( (string) $row_index ) . '" name="dsm_table_lib_row_role[]">';
			foreach ( self::row_role_choices() as $value => $label ) {
				echo '<option value="' . esc_attr( $value ) . '"' . selected( $role, $value, false ) . '>';
				echo esc_html( $label );
				echo '</option>';
			}
			echo '</select>';
			echo '</div>';
			self::render_insert_row_button();
			echo '</td>';
			foreach ( array_keys( $columns ) as $col_index ) {
				$cell    = isset( $cells[ $col_index ] ) && is_array( $cells[ $col_index ] ) ? $cells[ $col_index ] : array();
				$colspan = self::cell_span( $cell, 'colspan' );
				$rowspan = self::cell_span( $cell, 'rowspan' );
				$key     = (string) $row_index . ':' . (string) $col_index;
				$classes = 'dsm-table-library-cell';
				if ( isset( $covered[ $key ] ) ) {
					$classes .= ' is-covered';
				}
				echo '<td class="' . esc_attr( $classes ) . '" data-dsm-row="' . esc_attr( (string) $row_index ) . '" data-dsm-col="' . esc_attr( (string) $col_index ) . '">';
				echo '<button type="button" class="dsm-table-library-cell-pick" aria-label="' . esc_attr__( 'Select cell', 'dsm-supreme-modules-pro-for-divi' ) . '"></button>';
				self::render_cell_value_control( $cell, (int) $row_index );
				echo '<input type="hidden" name="dsm_table_lib_colspan[' . esc_attr( (string) $row_index ) . '][]" value="' . esc_attr( (string) $colspan ) . '" />';
				echo '<input type="hidden" name="dsm_table_lib_rowspan[' . esc_attr( (string) $row_index ) . '][]" value="' . esc_attr( (string) $rowspan ) . '" />';
				if ( $colspan > 1 || $rowspan > 1 ) {
					echo '<span class="dsm-table-library-merge-badge">';
					echo esc_html(
						sprintf(
							/* translators: 1: colspan, 2: rowspan */
							__( '%1$d×%2$d', 'dsm-supreme-modules-pro-for-divi' ),
							$colspan,
							$rowspan
						)
					);
					echo '</span>';
				}
				echo '</td>';
			}
			echo '</tr>';
		}

		echo '</tbody></table></div>';
		self::render_editor_pager( $page, $total_pages, $offset, $total_data, count( $data_rows ), $search, 'bottom' );
		echo '</div>';
		self::render_rich_text_modal();
	}

	/**
	 * Per-page, search, and WordPress-style pager for the library grid editor.
	 *
	 * @param int    $page          Current 1-based page.
	 * @param int    $total_pages   Page count for the (filtered) list.
	 * @param int    $offset        First visible index.
	 * @param int    $total_data    (Filtered) data-row count.
	 * @param int    $visible_count Visible row count on this page.
	 * @param string $search        Active search query.
	 * @param string $position      `top` or `bottom`.
	 * @return void
	 */
	private static function render_editor_pager( int $page, int $total_pages, int $offset, int $total_data, int $visible_count, string $search, string $position = 'top' ): void {
		$is_top = 'bottom' !== $position;
		unset( $offset, $visible_count );

		echo '<div class="tablenav ' . esc_attr( $is_top ? 'top' : 'bottom' ) . ' dsm-table-library-tablenav">';
		echo '<span class="screen-reader-text">';
		echo esc_html__( 'Changing page or search saves the table.', 'dsm-supreme-modules-pro-for-divi' );
		echo '</span>';

		if ( $is_top ) {
			$page_size = self::get_editor_page_size();
			echo '<div class="dsm-table-library-tablenav__row dsm-table-library-tablenav__row--tools">';
			echo '<div class="alignleft actions">';
			echo '<label for="dsm_table_lib_per_page">';
			echo esc_html__( 'Number of items per page:', 'dsm-supreme-modules-pro-for-divi' );
			echo '</label> ';
			echo '<input type="number" class="small-text" id="dsm_table_lib_per_page" name="dsm_table_lib_per_page" value="' . esc_attr( (string) $page_size ) . '" min="' . esc_attr( (string) self::EDITOR_PER_PAGE_MIN ) . '" max="' . esc_attr( (string) self::EDITOR_PER_PAGE_MAX ) . '" step="1" /> ';
			echo '<button type="submit" class="button" name="dsm_table_lib_apply_per_page" value="1">';
			echo esc_html__( 'Apply', 'dsm-supreme-modules-pro-for-divi' );
			echo '</button>';
			echo '</div>';
			echo '<p class="search-box">';
			echo '<label class="screen-reader-text" for="dsm_table_q">';
			echo esc_html__( 'Search rows', 'dsm-supreme-modules-pro-for-divi' );
			echo '</label>';
			echo '<input type="search" id="dsm_table_q" name="dsm_table_q" value="' . esc_attr( $search ) . '" /> ';
			echo '<button type="submit" class="button" name="dsm_table_lib_do_search" value="1">';
			echo esc_html__( 'Search', 'dsm-supreme-modules-pro-for-divi' );
			echo '</button>';
			if ( '' !== $search ) {
				echo ' <button type="submit" class="button" name="dsm_table_lib_clear_search" value="1">';
				echo esc_html__( 'Clear', 'dsm-supreme-modules-pro-for-divi' );
				echo '</button>';
			}
			echo '</p>';
			echo '</div>';
		}

		echo '<div class="dsm-table-library-tablenav__row dsm-table-library-tablenav__row--pages">';
		self::render_editor_tablenav_pages( $page, $total_pages, $total_data, $is_top );
		echo '</div>';

		if ( $is_top && '' !== $search && $total_data < 1 ) {
			echo '<p class="dsm-table-library-empty-search">';
			echo esc_html__( 'No rows match this search.', 'dsm-supreme-modules-pro-for-divi' );
			echo '</p>';
		}

		echo '</div>';
	}

	/**
	 * WordPress list-table page links (item count + « ‹ › »).
	 *
	 * @param int  $page        Current 1-based page.
	 * @param int  $total_pages Total pages.
	 * @param int  $total_data  (Filtered) data-row count.
	 * @param bool $with_input  Whether to show a current-page input.
	 * @return void
	 */
	private static function render_editor_tablenav_pages( int $page, int $total_pages, int $total_data, bool $with_input ): void {
		echo '<div class="tablenav-pages">';
		echo '<span class="displaying-num">';
		echo esc_html(
			sprintf(
				/* translators: %s: number of data rows */
				_n( '%s item', '%s items', $total_data, 'dsm-supreme-modules-pro-for-divi' ),
				number_format_i18n( $total_data )
			)
		);
		echo '</span>';

		if ( $total_pages > 1 ) {
			echo '<span class="pagination-links">';
			self::render_editor_pager_button( 1, 1 === $page, __( 'First page', 'dsm-supreme-modules-pro-for-divi' ), '«' );
			self::render_editor_pager_button( max( 1, $page - 1 ), 1 === $page, __( 'Previous page', 'dsm-supreme-modules-pro-for-divi' ), '‹' );

			if ( $with_input ) {
				echo '<span class="paging-input">';
				echo '<label for="dsm_table_lib_paged" class="screen-reader-text">';
				echo esc_html__( 'Current Page', 'dsm-supreme-modules-pro-for-divi' );
				echo '</label>';
				echo '<input class="current-page" id="dsm_table_lib_paged" type="text" name="dsm_table_lib_paged" value="' . esc_attr( (string) $page ) . '" size="' . esc_attr( (string) max( 1, strlen( (string) $total_pages ) ) ) . '" />';
				echo '<span class="tablenav-paging-text"> ';
				echo esc_html(
					sprintf(
						/* translators: %s: total pages */
						__( 'of %s', 'dsm-supreme-modules-pro-for-divi' ),
						number_format_i18n( $total_pages )
					)
				);
				echo '</span>';
				echo '</span> ';
			} else {
				echo '<span class="tablenav-paging-text">';
				echo esc_html(
					sprintf(
						/* translators: 1: current page 2: total pages */
						__( '%1$s of %2$s', 'dsm-supreme-modules-pro-for-divi' ),
						number_format_i18n( $page ),
						number_format_i18n( $total_pages )
					)
				);
				echo '</span> ';
			}

			self::render_editor_pager_button( min( $total_pages, $page + 1 ), $page >= $total_pages, __( 'Next page', 'dsm-supreme-modules-pro-for-divi' ), '›' );
			self::render_editor_pager_button( $total_pages, $page >= $total_pages, __( 'Last page', 'dsm-supreme-modules-pro-for-divi' ), '»' );
			echo '</span>';
		}

		echo '</div>';
	}

	/**
	 * Submit or disabled list-table page control.
	 *
	 * @param int    $target   Page to load.
	 * @param bool   $disabled Whether the control is inactive.
	 * @param string $label    Screen-reader label.
	 * @param string $symbol   Visible arrow.
	 * @return void
	 */
	private static function render_editor_pager_button( int $target, bool $disabled, string $label, string $symbol ): void {
		if ( $disabled ) {
			echo '<span class="tablenav-pages-navspan button disabled" aria-hidden="true">';
			echo esc_html( $symbol );
			echo '</span> ';
			return;
		}

		echo '<button type="submit" class="button" name="dsm_table_lib_goto_page" value="' . esc_attr( (string) $target ) . '">';
		echo '<span class="screen-reader-text">' . esc_html( $label ) . '</span>';
		echo '<span aria-hidden="true">' . esc_html( $symbol ) . '</span>';
		echo '</button> ';
	}

	/**
	 * One shared TinyMCE modal for library Rich text cells.
	 *
	 * @return void
	 */
	private static function render_rich_text_modal(): void {
		echo '<div class="dsm-table-library-rich-modal" id="dsm-table-library-rich-modal" hidden>';
		echo '<div class="dsm-table-library-rich-modal__box" role="dialog" aria-modal="true" aria-labelledby="dsm-table-library-rich-title">';
		echo '<div class="dsm-table-library-rich-modal__header">';
		echo '<h2 id="dsm-table-library-rich-title">';
		echo esc_html__( 'Edit rich text', 'dsm-supreme-modules-pro-for-divi' );
		echo '</h2>';
		echo '<p class="dsm-table-library-rich-modal__actions">';
		echo '<button type="button" class="button button-primary" data-dsm-table-rich-apply>';
		echo esc_html__( 'Apply to cell', 'dsm-supreme-modules-pro-for-divi' );
		echo '</button> ';
		echo '<button type="button" class="button" data-dsm-table-rich-cancel>';
		echo esc_html__( 'Cancel', 'dsm-supreme-modules-pro-for-divi' );
		echo '</button>';
		echo '</p>';
		echo '</div>';
		wp_editor(
			'',
			'dsm_table_library_rich_editor',
			array(
				'textarea_name'    => 'dsm_table_library_rich_scratch',
				'textarea_rows'    => 10,
				'media_buttons'    => true,
				'teeny'            => false,
				'quicktags'        => true,
				'editor_height'    => 240,
				'wp_autoresize_on' => false,
				'tinymce'          => array(
					'wp_skip_init'     => false,
					'wp_autoresize_on' => false,
					'resize'           => true,
				),
			)
		);
		echo '</div></div>';
	}

	/**
	 * Gutenberg-style icon toolbar control (tooltip + accessible name).
	 *
	 * @param string                $icon     Dashicon suffix without `dashicons-`.
	 * @param string                $label    Tooltip and aria-label.
	 * @param array<string, string> $attrs    Extra HTML attributes.
	 * @param bool                  $danger   Whether to use delete styling.
	 * @param bool                  $disabled Whether the control starts disabled.
	 * @return void
	 */
	private static function render_toolbar_icon_button(
		string $icon,
		string $label,
		array $attrs,
		bool $danger = false,
		bool $disabled = false
	): void {
		$class = $danger
			? 'dsm-table-library-toolbar__btn button-link-delete'
			: 'dsm-table-library-toolbar__btn button';
		echo '<button type="button" class="' . esc_attr( $class ) . '"';
		foreach ( $attrs as $name => $value ) {
			echo ' ' . esc_attr( (string) $name ) . '="' . esc_attr( $value ) . '"';
		}
		echo ' aria-label="' . esc_attr( $label ) . '" title="' . esc_attr( $label ) . '"';
		if ( $disabled ) {
			echo ' disabled';
		}
		echo '>';
		echo '<span class="dashicons dashicons-' . esc_attr( $icon ) . '" aria-hidden="true"></span>';
		echo '</button>';
	}

	/**
	 * Hover control: insert a column after this header.
	 *
	 * @return void
	 */
	private static function render_insert_column_button(): void {
		echo '<button type="button" class="dsm-table-library-insert-col" data-dsm-table-insert-col aria-label="';
		echo esc_attr__( 'Add column after this one', 'dsm-supreme-modules-pro-for-divi' );
		echo '">+</button>';
	}

	/**
	 * Hover control: insert a body row after this row.
	 *
	 * @return void
	 */
	private static function render_insert_row_button(): void {
		echo '<button type="button" class="dsm-table-library-insert-row" data-dsm-table-insert-row data-dsm-table-row-role="body" aria-label="';
		echo esc_attr__( 'Add row below', 'dsm-supreme-modules-pro-for-divi' );
		echo '">+</button>';
	}

	/**
	 * Body / Footer / CTA choices (header is the first row of the editor).
	 *
	 * @return array<string, string>
	 */
	private static function row_role_choices(): array {
		return array(
			'body'   => __( 'Body', 'dsm-supreme-modules-pro-for-divi' ),
			'footer' => __( 'Footer', 'dsm-supreme-modules-pro-for-divi' ),
			'cta'    => __( 'CTA', 'dsm-supreme-modules-pro-for-divi' ),
		);
	}

	/**
	 * Cell colspan or rowspan (minimum 1).
	 *
	 * @param array<string, mixed> $cell Cell.
	 * @param string               $key  `colspan` or `rowspan`.
	 * @return int
	 */
	private static function cell_span( array $cell, string $key ): int {
		$value = isset( $cell[ $key ] ) ? absint( $cell[ $key ] ) : 1;

		return max( 1, $value );
	}

	/**
	 * Covered cells in the admin editor (header keys `h:c`, data keys `r:c`).
	 *
	 * Matches `Table::rebuild_merges` / `dsmTableMergeMap`: origin keeps
	 * colspan/rowspan; covered cells stay in the matrix as 1×1 placeholders.
	 *
	 * @param array<int, array<string, mixed>> $data_rows    Body/footer/cta rows.
	 * @param array<int, mixed>                $columns      Columns.
	 * @param array<int, mixed>                $header_cells Header-role cells.
	 * @return array<string, string>
	 */
	private static function data_cover_map( array $data_rows, array $columns, array $header_cells ): array {
		$covered = array();
		$col_n   = count( $columns );
		$row_n   = count( $data_rows );

		foreach ( $header_cells as $c => $cell ) {
			if ( ! is_array( $cell ) ) {
				continue;
			}
			$colspan = self::cell_span( $cell, 'colspan' );
			$rowspan = self::cell_span( $cell, 'rowspan' );
			if ( $colspan < 2 && $rowspan < 2 ) {
				continue;
			}
			for ( $rr = 0; $rr < $rowspan; $rr++ ) {
				for ( $cc = (int) $c; $cc < (int) $c + $colspan && $cc < $col_n; $cc++ ) {
					if ( 0 === $rr && $cc === (int) $c ) {
						continue;
					}
					if ( 0 === $rr ) {
						$covered[ 'h:' . (string) $cc ] = 'h:' . (string) $c;
						continue;
					}
					$data_r = $rr - 1;
					if ( $data_r >= 0 && $data_r < $row_n ) {
						$covered[ (string) $data_r . ':' . (string) $cc ] = 'h:' . (string) $c;
					}
				}
			}
		}

		foreach ( $data_rows as $r => $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$cells = isset( $row['cells'] ) && is_array( $row['cells'] ) ? $row['cells'] : array();
			foreach ( $cells as $c => $cell ) {
				if ( ! is_array( $cell ) ) {
					continue;
				}
				$colspan = self::cell_span( $cell, 'colspan' );
				$rowspan = self::cell_span( $cell, 'rowspan' );
				if ( $colspan < 2 && $rowspan < 2 ) {
					continue;
				}
				for ( $rr = (int) $r; $rr < (int) $r + $rowspan && $rr < $row_n; $rr++ ) {
					for ( $cc = (int) $c; $cc < (int) $c + $colspan && $cc < $col_n; $cc++ ) {
						if ( $rr === (int) $r && $cc === (int) $c ) {
							continue;
						}
						$covered[ (string) $rr . ':' . (string) $cc ] = (string) $r . ':' . (string) $c;
					}
				}
			}
		}

		return $covered;
	}

	/**
	 * Parse an uploaded CSV into a replacement grid, or null when no file was sent.
	 *
	 * @param array<string, mixed> $request Unslashed POST after nonce verification.
	 * @return array{grid: array<string, mixed>, warnings: array<int, string>}|null|\WP_Error
	 */
	private static function grid_from_uploaded_csv( array $request ) {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- caller verified nonce.
		if ( ! isset( $_FILES['dsm_table_lib_csv'] ) || ! is_array( $_FILES['dsm_table_lib_csv'] ) ) {
			return null;
		}

		$error = isset( $_FILES['dsm_table_lib_csv']['error'] )
			? absint( $_FILES['dsm_table_lib_csv']['error'] )
			: UPLOAD_ERR_NO_FILE;
		if ( UPLOAD_ERR_NO_FILE === $error ) {
			return null;
		}

		if ( UPLOAD_ERR_OK !== $error ) {
			return new \WP_Error(
				'dsm_table_lib_csv_upload',
				__( 'Could not upload the CSV file.', 'dsm-supreme-modules-pro-for-divi' )
			);
		}

		$tmp  = isset( $_FILES['dsm_table_lib_csv']['tmp_name'] )
			? sanitize_text_field( wp_unslash( (string) $_FILES['dsm_table_lib_csv']['tmp_name'] ) )
			: '';
		$size = isset( $_FILES['dsm_table_lib_csv']['size'] )
			? absint( $_FILES['dsm_table_lib_csv']['size'] )
			: 0;
		// phpcs:enable WordPress.Security.NonceVerification.Missing
		if ( '' === $tmp || ! is_uploaded_file( $tmp ) ) {
			return new \WP_Error(
				'dsm_table_lib_csv_upload',
				__( 'Could not upload the CSV file.', 'dsm-supreme-modules-pro-for-divi' )
			);
		}

		$max_bytes = DsmTableSource::get_csv_max_bytes();
		$disk_size = false;
		if ( is_readable( $tmp ) ) {
			$disk_size = function_exists( 'wp_filesize' ) ? wp_filesize( $tmp ) : filesize( $tmp );
		}
		if ( $size > $max_bytes || ( false !== $disk_size && $disk_size > $max_bytes ) ) {
			return new \WP_Error(
				'dsm_table_lib_csv_too_large',
				sprintf(
					/* translators: %d: max file size in megabytes */
					__( 'CSV is too large. Use a file smaller than %d MB.', 'dsm-supreme-modules-pro-for-divi' ),
					(int) round( $max_bytes / ( 1024 * 1024 ) )
				)
			);
		}

		$import_max = DsmTableSource::get_import_max_rows();
		$parsed     = DsmTableSource::parse_csv_matrix_from_path( $tmp, $import_max );
		if ( is_wp_error( $parsed ) ) {
			return $parsed;
		}

		$first_row_header = isset( $request['dsm_table_lib_csv_header'] )
			&& 'on' === sanitize_text_field( (string) $request['dsm_table_lib_csv_header'] );

		$grid = DsmTableSource::grid_from_matrix(
			$parsed['matrix'],
			$first_row_header,
			array(),
			array(),
			$import_max
		);

		return array(
			'grid'     => $grid,
			'warnings' => isset( $parsed['warnings'] ) && is_array( $parsed['warnings'] ) ? $parsed['warnings'] : array(),
		);
	}

	/**
	 * Rebuild a grid from the metabox inputs, preserving comparison and cell types.
	 *
	 * @param int                  $post_id Library post ID.
	 * @param array<string, mixed> $request Unslashed POST after nonce verification.
	 * @return array<string, mixed>
	 */
	private static function grid_from_editor_post( int $post_id, array $request ): array {
		$existing = DsmTableLibrary::get_grid( $post_id );
		if ( ! is_array( $existing ) ) {
			$existing = DsmTableLibrary::get_blank_grid();
		}

		$headers         = self::posted_string_list( $request, 'dsm_table_lib_header' );
		$col_ids         = self::posted_string_list( $request, 'dsm_table_lib_col_id' );
		$row_ids         = self::posted_string_list( $request, 'dsm_table_lib_row_id' );
		$roles           = self::posted_string_list( $request, 'dsm_table_lib_row_role' );
		$header_colspans = self::posted_int_list( $request, 'dsm_table_lib_header_colspan' );
		$header_rowspans = self::posted_int_list( $request, 'dsm_table_lib_header_rowspan' );
		$cells           = self::posted_cell_matrix( $request );
		$types           = self::posted_cell_type_matrix( $request );
		$colspans        = self::posted_int_matrix( $request, 'dsm_table_lib_colspan' );
		$rowspans        = self::posted_int_matrix( $request, 'dsm_table_lib_rowspan' );

		$col_count     = min( 20, max( 1, count( $headers ) ) );
		$existing_cols = isset( $existing['columns'] ) && is_array( $existing['columns'] ) ? $existing['columns'] : array();
		$columns       = array();

		for ( $c = 0; $c < $col_count; $c++ ) {
			$prev      = isset( $existing_cols[ $c ] ) && is_array( $existing_cols[ $c ] ) ? $existing_cols[ $c ] : array();
			$header    = isset( $headers[ $c ] ) ? $headers[ $c ] : '';
			$col_id    = isset( $col_ids[ $c ] ) ? $col_ids[ $c ] : (string) ( $prev['id'] ?? '' );
			$columns[] = array(
				'id'           => $col_id,
				'header'       => $header,
				'hide_on'      => isset( $prev['hide_on'] ) && is_array( $prev['hide_on'] ) ? $prev['hide_on'] : array(
					'tablet' => false,
					'phone'  => false,
				),
				'sticky'       => isset( $prev['sticky'] ) ? (bool) $prev['sticky'] : ( 0 === $c ),
				'type_default' => isset( $prev['type_default'] ) ? (string) $prev['type_default'] : 'text',
				'width'        => isset( $prev['width'] ) ? (string) $prev['width'] : '',
				'align'        => isset( $prev['align'] ) ? (string) $prev['align'] : '',
			);
		}

		$existing_rows = isset( $existing['rows'] ) && is_array( $existing['rows'] ) ? $existing['rows'] : array();
		$header_prev   = array();
		$data_prev     = array();
		foreach ( $existing_rows as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$role = isset( $row['role'] ) ? sanitize_key( (string) $row['role'] ) : 'body';
			if ( 'header' === $role && array() === $header_prev ) {
				$header_prev = $row;
				continue;
			}
			if ( 'header' !== $role ) {
				$data_prev[] = $row;
			}
		}

		$header_texts = array();
		foreach ( $columns as $column ) {
			$header_texts[] = (string) $column['header'];
		}

		$rows   = array();
		$rows[] = array(
			'id'      => isset( $header_prev['id'] ) ? (string) $header_prev['id'] : 'row-h',
			'role'    => 'header',
			'tooltip' => isset( $header_prev['tooltip'] ) ? (string) $header_prev['tooltip'] : '',
			'cells'   => self::cells_from_texts(
				$header_texts,
				$header_prev['cells'] ?? array(),
				$header_colspans,
				$header_rowspans
			),
		);

		$import_max     = DsmTableSource::get_import_max_rows();
		$use_id_merge   = array_key_exists( 'dsm_table_lib_row_rest', $request );
		$posted_limit   = $use_id_merge
			? min( $import_max, count( $row_ids ) )
			: min( $import_max, max( 1, count( $row_ids ) ) );
		$posted_visible = array();

		for ( $r = 0; $r < $posted_limit; $r++ ) {
			$role = isset( $roles[ $r ] ) ? sanitize_key( $roles[ $r ] ) : 'body';
			if ( ! in_array( $role, array( 'body', 'footer', 'cta' ), true ) ) {
				$role = 'body';
			}

			$prev_row = array();
			$want_id  = isset( $row_ids[ $r ] ) ? $row_ids[ $r ] : '';
			if ( '' !== $want_id ) {
				foreach ( $data_prev as $candidate ) {
					if ( isset( $candidate['id'] ) && (string) $candidate['id'] === $want_id ) {
						$prev_row = $candidate;
						break;
					}
				}
			}
			if ( array() === $prev_row && ! $use_id_merge && isset( $data_prev[ $r ] ) && is_array( $data_prev[ $r ] ) ) {
				$prev_row = $data_prev[ $r ];
			}

			$line      = isset( $cells[ $r ] ) && is_array( $cells[ $r ] ) ? $cells[ $r ] : array();
			$line_size = count( $line );
			if ( $line_size < $col_count ) {
				$line = array_merge( $line, array_fill( 0, $col_count - $line_size, '' ) );
			}
			$line = array_slice( $line, 0, $col_count );

			$posted_visible[] = array(
				'id'      => '' !== $want_id ? $want_id : (string) ( $prev_row['id'] ?? ( 'row-' . ( $r + 1 ) ) ),
				'role'    => $role,
				'tooltip' => isset( $prev_row['tooltip'] ) ? (string) $prev_row['tooltip'] : '',
				'cells'   => self::cells_from_texts(
					$line,
					$prev_row['cells'] ?? array(),
					isset( $colspans[ $r ] ) && is_array( $colspans[ $r ] ) ? $colspans[ $r ] : array(),
					isset( $rowspans[ $r ] ) && is_array( $rowspans[ $r ] ) ? $rowspans[ $r ] : array(),
					isset( $types[ $r ] ) && is_array( $types[ $r ] ) ? $types[ $r ] : array()
				),
			);
		}

		if ( $use_id_merge ) {
			self::merge_posted_rows_by_id(
				$rows,
				$data_prev,
				$posted_visible,
				self::posted_row_json( $request, 'dsm_table_lib_row_rest' ),
				$import_max
			);
		} else {
			self::append_stored_rows( $rows, self::posted_row_json( $request, 'dsm_table_lib_row_before' ), $import_max );
			foreach ( $posted_visible as $posted_row ) {
				if ( count( $rows ) >= $import_max ) {
					break;
				}
				$rows[] = $posted_row;
			}
			self::append_stored_rows( $rows, self::posted_row_json( $request, 'dsm_table_lib_row_after' ), $import_max );
		}

		$grid = array(
			'schema_version' => 1,
			'columns'        => $columns,
			'rows'           => $rows,
			'merges'         => array(),
			'comparison'     => isset( $existing['comparison'] ) && is_array( $existing['comparison'] ) ? $existing['comparison'] : array(),
			'source'         => isset( $existing['source'] ) && is_array( $existing['source'] ) ? $existing['source'] : array(),
		);

		$grid['merges'] = self::rebuild_merges_from_cells( $grid );

		return $grid;
	}

	/**
	 * Same shape as `Table::rebuild_merges` / `dsmTableRebuildMerges`.
	 *
	 * CPT save can run before `Table` boots, so the stored `merges` array
	 * must match cell colspan/rowspan without calling that private method.
	 *
	 * @param array<string, mixed> $grid Grid with rows/cells.
	 * @return array<int, array<string, int>>
	 */
	private static function rebuild_merges_from_cells( array $grid ): array {
		$merges = array();
		$rows   = isset( $grid['rows'] ) && is_array( $grid['rows'] ) ? $grid['rows'] : array();

		foreach ( $rows as $r => $row ) {
			if ( ! is_array( $row ) || ! isset( $row['cells'] ) || ! is_array( $row['cells'] ) ) {
				continue;
			}
			foreach ( $row['cells'] as $c => $cell ) {
				if ( ! is_array( $cell ) ) {
					continue;
				}
				$colspan = self::cell_span( $cell, 'colspan' );
				$rowspan = self::cell_span( $cell, 'rowspan' );
				if ( $colspan > 1 || $rowspan > 1 ) {
					$merges[] = array(
						'r'       => (int) $r,
						'c'       => (int) $c,
						'rowspan' => $rowspan,
						'colspan' => $colspan,
					);
				}
			}
		}

		return $merges;
	}

	/**
	 * Merge posted cell text into previous cell objects (keeps type / design).
	 *
	 * @param array<int, string> $texts    Posted text per column.
	 * @param array<int, mixed>  $prev     Previous cells.
	 * @param array<int, int>    $colspans Posted colspan per column.
	 * @param array<int, int>    $rowspans Posted rowspan per column.
	 * @param array<int, string> $types    Posted cell types per column.
	 * @return array<int, array<string, mixed>>
	 */
	private static function cells_from_texts( array $texts, $prev, array $colspans = array(), array $rowspans = array(), array $types = array() ): array {
		$prev_cells = is_array( $prev ) ? $prev : array();
		$cells      = array();
		foreach ( $texts as $index => $text ) {
			$cell          = isset( $prev_cells[ $index ] ) && is_array( $prev_cells[ $index ] ) ? $prev_cells[ $index ] : array(
				'id'      => 'cell-' . (string) ( $index + 1 ),
				'type'    => 'text',
				'colspan' => 1,
				'rowspan' => 1,
				'value'   => array( 'text' => '' ),
				'design'  => array(),
			);
			$existing_type = isset( $cell['type'] ) ? sanitize_key( (string) $cell['type'] ) : 'text';
			$posted_type   = isset( $types[ $index ] ) ? sanitize_key( (string) $types[ $index ] ) : '';
			$cell['type']  = self::sanitize_posted_cell_type( $posted_type, $existing_type );
			$value         = isset( $cell['value'] ) && is_array( $cell['value'] ) ? $cell['value'] : array();
			if ( 'rich_text' === $cell['type'] ) {
				$value['html'] = wp_kses_post( $text );
				$value['text'] = wp_strip_all_tags( $value['html'] );
			} else {
				$value['text'] = sanitize_text_field( $text );
			}
			$cell['value']   = $value;
			$cell['colspan'] = isset( $colspans[ $index ] ) ? max( 1, absint( $colspans[ $index ] ) ) : self::cell_span( $cell, 'colspan' );
			$cell['rowspan'] = isset( $rowspans[ $index ] ) ? max( 1, absint( $rowspans[ $index ] ) ) : self::cell_span( $cell, 'rowspan' );
			$cells[]         = $cell;
		}

		return $cells;
	}

	/**
	 * Re-insert posted rows by id; keep unmatched stored rows in original order.
	 *
	 * @param array<int, array<string, mixed>> $rows            Grid rows including header (by ref).
	 * @param array<int, array<string, mixed>> $stored_data     Stored data rows in original order.
	 * @param array<int, array<string, mixed>> $posted_visible  Visible posted rows.
	 * @param array<int, array<string, mixed>> $remaining       Non-visible stored rows from the editor.
	 * @param int                              $import_max      Cap including the header row.
	 * @return void
	 */
	private static function merge_posted_rows_by_id( array &$rows, array $stored_data, array $posted_visible, array $remaining, int $import_max ): void {
		$posted_by_id = array();
		$posted_new   = array();
		foreach ( $posted_visible as $row ) {
			$id = isset( $row['id'] ) ? (string) $row['id'] : '';
			if ( '' !== $id ) {
				$posted_by_id[ $id ] = $row;
			} else {
				$posted_new[] = $row;
			}
		}

		$remaining_ids = array();
		foreach ( $remaining as $row ) {
			$id = isset( $row['id'] ) ? (string) $row['id'] : '';
			if ( '' !== $id ) {
				$remaining_ids[ $id ] = true;
			}
		}

		foreach ( $stored_data as $stored ) {
			if ( count( $rows ) >= $import_max ) {
				return;
			}
			if ( ! is_array( $stored ) ) {
				continue;
			}
			$sid = isset( $stored['id'] ) ? (string) $stored['id'] : '';
			if ( '' !== $sid && isset( $posted_by_id[ $sid ] ) ) {
				$rows[] = $posted_by_id[ $sid ];
				unset( $posted_by_id[ $sid ] );
				continue;
			}
			if ( '' === $sid || isset( $remaining_ids[ $sid ] ) ) {
				$rows[] = $stored;
			}
		}

		foreach ( $posted_by_id as $row ) {
			if ( count( $rows ) >= $import_max ) {
				return;
			}
			$rows[] = $row;
		}

		foreach ( $posted_new as $row ) {
			if ( count( $rows ) >= $import_max ) {
				return;
			}
			$rows[] = $row;
		}
	}

	/**
	 * Whether a data row matches a case-insensitive cell-text search.
	 *
	 * @param array<string, mixed> $row   Data row.
	 * @param string               $query Sanitized search string.
	 * @return bool
	 */
	private static function row_matches_search( array $row, string $query ): bool {
		if ( '' === $query ) {
			return true;
		}

		$needle = function_exists( 'mb_strtolower' ) ? mb_strtolower( $query, 'UTF-8' ) : strtolower( $query );
		$cells  = isset( $row['cells'] ) && is_array( $row['cells'] ) ? $row['cells'] : array();
		foreach ( $cells as $cell ) {
			if ( ! is_array( $cell ) ) {
				continue;
			}
			$hay = self::cell_plain_text_for_search( $cell );
			$hay = function_exists( 'mb_strtolower' ) ? mb_strtolower( $hay, 'UTF-8' ) : strtolower( $hay );
			if ( '' !== $hay && false !== strpos( $hay, $needle ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Plain cell text for library search (rich_text strips tags).
	 *
	 * Mirrors the Table / DsmTableSource plain-text cell helpers.
	 *
	 * @param array<string, mixed> $cell Cell.
	 * @return string
	 */
	private static function cell_plain_text_for_search( array $cell ): string {
		$type  = isset( $cell['type'] ) ? (string) $cell['type'] : 'text';
		$value = isset( $cell['value'] ) && is_array( $cell['value'] ) ? $cell['value'] : array();

		switch ( $type ) {
			case 'rich_text':
				$html = $value['html'] ?? $value['text'] ?? '';
				if ( class_exists( Table::class ) ) {
					$html = Table::coerce_html_string( $html );
				} elseif ( ! is_string( $html ) ) {
					$html = '';
				}
				return trim( wp_strip_all_tags( $html ) );
			case 'button':
			case 'badge':
			case 'text':
				return (string) ( $value['text'] ?? '' );
			case 'image':
				return (string) ( $value['alt'] ?? $value['src'] ?? '' );
			case 'shortcode':
				return (string) ( $value['content'] ?? '' );
			case 'star_rating':
				return (string) ( $value['rating'] ?? '' );
			default:
				return (string) ( $value['text'] ?? '' );
		}
	}

	/**
	 * Hidden editor rows (other pages) from a verified request.
	 *
	 * @param array<string, mixed> $request Unslashed POST.
	 * @param string               $key     Request key.
	 * @return array<int, array<string, mixed>>
	 */
	private static function posted_row_json( array $request, string $key ): array {
		$raw = isset( $request[ $key ] ) ? (string) $request[ $key ] : '';
		if ( '' === trim( $raw ) ) {
			return array();
		}

		$decoded = json_decode( $raw, true );
		if ( ! is_array( $decoded ) ) {
			return array();
		}

		$out = array();
		foreach ( $decoded as $row ) {
			if ( is_array( $row ) && isset( $row['cells'] ) && is_array( $row['cells'] ) ) {
				$out[] = $row;
			}
		}

		return $out;
	}

	/**
	 * Append stored row objects until the import cap.
	 *
	 * @param array<int, array<string, mixed>> $rows       Grid rows (by ref).
	 * @param array<int, array<string, mixed>> $extra      Extra rows.
	 * @param int                              $import_max Cap including the header row.
	 * @return void
	 */
	private static function append_stored_rows( array &$rows, array $extra, int $import_max ): void {
		foreach ( $extra as $row ) {
			if ( count( $rows ) >= $import_max ) {
				break;
			}
			if ( is_array( $row ) && isset( $row['cells'] ) && is_array( $row['cells'] ) ) {
				$rows[] = $row;
			}
		}
	}

	/**
	 * Sanitized string list from a verified request.
	 *
	 * @param array<string, mixed> $request Unslashed POST.
	 * @param string               $key     Request key.
	 * @return array<int, string>
	 */
	private static function posted_string_list( array $request, string $key ): array {
		if ( ! isset( $request[ $key ] ) || ! is_array( $request[ $key ] ) ) {
			return array();
		}

		$out = array();
		foreach ( $request[ $key ] as $item ) {
			$out[] = is_scalar( $item ) ? sanitize_text_field( (string) $item ) : '';
		}

		return $out;
	}

	/**
	 * Allowed cell type from the library editor.
	 *
	 * Text and Rich text can be set here. Other types (image, icon, button)
	 * are kept only when they already exist on the cell.
	 *
	 * @param string $posted   Posted type.
	 * @param string $existing Existing type.
	 * @return string
	 */
	private static function sanitize_posted_cell_type( string $posted, string $existing ): string {
		if ( in_array( $posted, array( 'text', 'rich_text' ), true ) ) {
			return $posted;
		}
		if ( '' !== $posted && $posted === $existing ) {
			return $existing;
		}

		return '' !== $existing ? $existing : 'text';
	}

	/**
	 * Posted cell types (`dsm_table_lib_cell_type[row][col]`).
	 *
	 * @param array<string, mixed> $request Unslashed POST.
	 * @return array<int, array<int, string>>
	 */
	private static function posted_cell_type_matrix( array $request ): array {
		if ( ! isset( $request['dsm_table_lib_cell_type'] ) || ! is_array( $request['dsm_table_lib_cell_type'] ) ) {
			return array();
		}

		$out = array();
		foreach ( $request['dsm_table_lib_cell_type'] as $row ) {
			$line = array();
			if ( is_array( $row ) ) {
				foreach ( $row as $cell ) {
					$line[] = is_scalar( $cell ) ? sanitize_key( (string) $cell ) : '';
				}
			}
			$out[] = $line;
		}

		return $out;
	}

	/**
	 * Cell matrix (`dsm_table_lib_cell[row][col]`). HTML is kses'd per type later.
	 *
	 * @param array<string, mixed> $request Unslashed POST.
	 * @return array<int, array<int, string>>
	 */
	private static function posted_cell_matrix( array $request ): array {
		if ( ! isset( $request['dsm_table_lib_cell'] ) || ! is_array( $request['dsm_table_lib_cell'] ) ) {
			return array();
		}

		$out = array();
		foreach ( $request['dsm_table_lib_cell'] as $row ) {
			$line = array();
			if ( is_array( $row ) ) {
				foreach ( $row as $cell ) {
					$line[] = is_scalar( $cell ) ? (string) $cell : '';
				}
			}
			$out[] = $line;
		}

		return $out;
	}

	/**
	 * Sanitized positive-int list from a verified request.
	 *
	 * @param array<string, mixed> $request Unslashed POST.
	 * @param string               $key     Request key.
	 * @return array<int, int>
	 */
	private static function posted_int_list( array $request, string $key ): array {
		if ( ! isset( $request[ $key ] ) || ! is_array( $request[ $key ] ) ) {
			return array();
		}

		$out = array();
		foreach ( $request[ $key ] as $item ) {
			$out[] = max( 1, absint( $item ) );
		}

		return $out;
	}

	/**
	 * Sanitized positive-int matrix (`dsm_table_lib_colspan[row][col]`).
	 *
	 * @param array<string, mixed> $request Unslashed POST.
	 * @param string               $key     Request key.
	 * @return array<int, array<int, int>>
	 */
	private static function posted_int_matrix( array $request, string $key ): array {
		if ( ! isset( $request[ $key ] ) || ! is_array( $request[ $key ] ) ) {
			return array();
		}

		$out = array();
		foreach ( $request[ $key ] as $row ) {
			$line = array();
			if ( is_array( $row ) ) {
				foreach ( $row as $cell ) {
					$line[] = max( 1, absint( $cell ) );
				}
			}
			$out[] = $line;
		}

		return $out;
	}

	/**
	 * Store a one-shot admin notice for the current user.
	 *
	 * @param string $type    Notice type.
	 * @param string $message Message.
	 * @return void
	 */
	private static function store_save_notice( string $type, string $message ): void {
		if ( '' === $message ) {
			return;
		}

		set_transient(
			self::notice_transient_key(),
			array(
				'type'    => $type,
				'message' => $message,
			),
			60
		);
	}

	/**
	 * Transient key for the current user’s save notice.
	 *
	 * @return string
	 */
	private static function notice_transient_key(): string {
		return 'dsm_table_lib_notice_' . (string) get_current_user_id();
	}

	/**
	 * Cell value control (plain text input, or HTML preview + hidden field).
	 *
	 * @param array<string, mixed> $cell      Cell.
	 * @param int                  $row_index Row index.
	 * @return void
	 */
	private static function render_cell_value_control( array $cell, int $row_index ): void {
		$type = isset( $cell['type'] ) ? sanitize_key( (string) $cell['type'] ) : 'text';
		$name = 'dsm_table_lib_cell[' . (string) $row_index . '][]';
		$html = '';
		if ( 'rich_text' === $type ) {
			$value = isset( $cell['value'] ) && is_array( $cell['value'] ) ? $cell['value'] : array();
			$html  = class_exists( Table::class )
				? Table::coerce_html_string( $value['html'] ?? $value['text'] ?? '' )
				: (string) ( $value['html'] ?? $value['text'] ?? '' );
			$html  = wp_kses_post( $html );
		}

		echo '<input type="hidden" class="dsm-table-library-cell-type" data-dsm-table-cell-type name="dsm_table_lib_cell_type[' . esc_attr( (string) $row_index ) . '][]" value="' . esc_attr( $type ) . '" />';

		if ( 'rich_text' === $type ) {
			echo '<button type="button" class="dsm-table-library-rich-edit" data-dsm-table-rich-edit>';
			echo esc_html__( 'Edit formatted text', 'dsm-supreme-modules-pro-for-divi' );
			echo '</button>';
			echo '<div class="dsm-table-library-rich-preview" data-dsm-table-rich-edit>';
			if ( '' !== $html ) {
				echo $html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- wp_kses_post above.
			} else {
				echo '<span class="dsm-table-library-rich-placeholder">';
				echo esc_html__( 'Click to add formatted text', 'dsm-supreme-modules-pro-for-divi' );
				echo '</span>';
			}
			echo '</div>';
			echo '<input type="hidden" class="dsm-table-library-cell-value" name="' . esc_attr( $name ) . '" value="' . esc_attr( $html ) . '" />';
			return;
		}

		echo '<input type="text" class="dsm-table-library-cell-value" name="' . esc_attr( $name ) . '" value="' . esc_attr( self::cell_preview_text( $cell ) ) . '" />';
	}

	/**
	 * Cell type options for the library editor.
	 *
	 * @param string $current Current type.
	 * @return array<string, string>
	 */
	private static function cell_type_choices( string $current ): array {
		$choices = array(
			'text'      => __( 'Text', 'dsm-supreme-modules-pro-for-divi' ),
			'rich_text' => __( 'Rich text', 'dsm-supreme-modules-pro-for-divi' ),
		);
		if ( '' !== $current && ! isset( $choices[ $current ] ) ) {
			$choices[ $current ] = $current;
		}

		return $choices;
	}

	/**
	 * Plain text for a preview cell.
	 *
	 * @param array<string, mixed> $cell Cell.
	 * @return string
	 */
	private static function cell_preview_text( array $cell ): string {
		$value = $cell['value'] ?? array();
		if ( is_string( $value ) ) {
			return $value;
		}
		if ( ! is_array( $value ) ) {
			return '';
		}
		if ( isset( $value['text'] ) && is_string( $value['text'] ) && '' !== $value['text'] ) {
			return $value['text'];
		}
		if ( isset( $value['html'] ) && is_string( $value['html'] ) && '' !== $value['html'] ) {
			return wp_strip_all_tags( $value['html'] );
		}

		$type = isset( $cell['type'] ) ? sanitize_key( (string) $cell['type'] ) : 'text';
		if ( 'text' !== $type && '' !== $type ) {
			return '[' . $type . ']';
		}

		return '';
	}

	/**
	 * Whether the current screen is the library add/edit form.
	 *
	 * @return bool
	 */
	private static function is_library_edit_screen(): bool {
		if ( ! function_exists( 'get_current_screen' ) ) {
			return false;
		}
		$screen = get_current_screen();

		return $screen
			&& DsmTableLibrary::POST_TYPE === $screen->post_type
			&& 'post' === $screen->base;
	}

	/**
	 * Whether the current screen is the library list (not add/edit).
	 *
	 * @return bool
	 */
	private static function is_library_list_screen(): bool {
		if ( ! function_exists( 'get_current_screen' ) ) {
			return false;
		}
		$screen = get_current_screen();

		return $screen
			&& DsmTableLibrary::POST_TYPE === $screen->post_type
			&& 'edit' === $screen->base;
	}

	/**
	 * Whether the current screen is the library CPT.
	 *
	 * @return bool
	 */
	private static function is_library_screen(): bool {
		if ( ! function_exists( 'get_current_screen' ) ) {
			return false;
		}
		$screen = get_current_screen();

		return $screen && DsmTableLibrary::POST_TYPE === $screen->post_type;
	}

	/**
	 * Whether the current request is the Find on pages tab.
	 *
	 * @return bool
	 */
	private static function is_finder_screen(): bool {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only screen id.
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( (string) $_GET['page'] ) ) : '';

		return DsmTableFinderAdmin::PAGE_SLUG === $page;
	}
}
