<?php
/**
 * Whether the Supreme Loop Filter module is enabled.
 *
 * Historically toggled under Divi Supreme → Extensions (`dsm_general[dsm_use_loop_filter]`).
 * Canonical store is now Divi Supreme → Modules (`dsm_modules[LoopFilter]`).
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Option key under `dsm_modules` for Supreme Loop Filter (parent + child).
 */
const DSM_LOOP_FILTER_MODULE_OPTION_KEY = 'LoopFilter';

/**
 * Legacy option key under `dsm_general` (Extensions tab).
 */
const DSM_LOOP_FILTER_LEGACY_EXTENSION_OPTION_KEY = 'dsm_use_loop_filter';

/**
 * Option flag set after the default-on upgrade has run once.
 */
const DSM_LOOP_FILTER_DEFAULT_ON_APPLIED_OPTION = 'dsm_loop_filter_default_on_applied';

/**
 * True when Divi Supreme → Modules → Supreme Loop Filter is on (default: on).
 *
 * Matches the other module toggles. A saved Modules value wins. When that key
 * has not been saved yet, a legacy Extensions off stays off.
 *
 * @return bool
 */
function dsm_is_loop_filter_module_enabled(): bool {
	$modules = get_option( 'dsm_modules', array() );

	if ( is_array( $modules ) && array_key_exists( DSM_LOOP_FILTER_MODULE_OPTION_KEY, $modules ) ) {
		return 'on' === $modules[ DSM_LOOP_FILTER_MODULE_OPTION_KEY ];
	}

	$general = get_option( 'dsm_general', array() );

	if ( is_array( $general ) && array_key_exists( DSM_LOOP_FILTER_LEGACY_EXTENSION_OPTION_KEY, $general ) ) {
		return 'on' === $general[ DSM_LOOP_FILTER_LEGACY_EXTENSION_OPTION_KEY ];
	}

	return true;
}

/**
 * Back-compat alias for {@see dsm_is_loop_filter_module_enabled()}.
 *
 * @return bool
 */
function dsm_is_loop_filter_extension_enabled(): bool {
	return dsm_is_loop_filter_module_enabled();
}

/**
 * Whether the one-time Loop Filter default-on migration has already run.
 *
 * The flag is autoloaded so a later frontend request does not issue its own
 * SELECT. Rows saved earlier with autoload off are promoted on the next read.
 *
 * @return bool
 */
function dsm_loop_filter_default_on_is_applied(): bool {
	$alloptions = wp_load_alloptions();

	if ( is_array( $alloptions ) && array_key_exists( DSM_LOOP_FILTER_DEFAULT_ON_APPLIED_OPTION, $alloptions ) ) {
		return '1' === (string) $alloptions[ DSM_LOOP_FILTER_DEFAULT_ON_APPLIED_OPTION ];
	}

	if ( '1' !== (string) get_option( DSM_LOOP_FILTER_DEFAULT_ON_APPLIED_OPTION, '' ) ) {
		return false;
	}

	if ( function_exists( 'wp_set_option_autoload' ) ) {
		wp_set_option_autoload( DSM_LOOP_FILTER_DEFAULT_ON_APPLIED_OPTION, true );
	}

	return true;
}

/**
 * Copy the legacy Extensions toggle into `dsm_modules[LoopFilter]`, then apply the on default once.
 *
 * Sites that only have `dsm_general[dsm_use_loop_filter]` keep that on/off.
 * When neither key exists, Modules is seeded as `on`.
 * An earlier release seeded missing keys as `off`. That seed is switched to `on`
 * once, unless the legacy Extensions toggle is explicitly off. A later Modules save stays as saved.
 *
 * @return void
 */
function dsm_maybe_migrate_loop_filter_extension_option_to_modules(): void {
	if ( dsm_loop_filter_default_on_is_applied() ) {
		return;
	}

	$modules = get_option( 'dsm_modules', array() );

	if ( ! is_array( $modules ) ) {
		$modules = array();
	}

	$general    = get_option( 'dsm_general', array() );
	$has_legacy = is_array( $general ) && array_key_exists( DSM_LOOP_FILTER_LEGACY_EXTENSION_OPTION_KEY, $general );
	$legacy_off = $has_legacy && 'on' !== $general[ DSM_LOOP_FILTER_LEGACY_EXTENSION_OPTION_KEY ];

	if ( ! array_key_exists( DSM_LOOP_FILTER_MODULE_OPTION_KEY, $modules ) ) {
		$modules[ DSM_LOOP_FILTER_MODULE_OPTION_KEY ] = $legacy_off ? 'off' : 'on';
		update_option( 'dsm_modules', $modules );
		update_option( DSM_LOOP_FILTER_DEFAULT_ON_APPLIED_OPTION, '1', true );
		return;
	}

	if ( 'off' === $modules[ DSM_LOOP_FILTER_MODULE_OPTION_KEY ] && ! $legacy_off ) {
		$modules[ DSM_LOOP_FILTER_MODULE_OPTION_KEY ] = 'on';
		update_option( 'dsm_modules', $modules );
	}

	update_option( DSM_LOOP_FILTER_DEFAULT_ON_APPLIED_OPTION, '1', true );
}
