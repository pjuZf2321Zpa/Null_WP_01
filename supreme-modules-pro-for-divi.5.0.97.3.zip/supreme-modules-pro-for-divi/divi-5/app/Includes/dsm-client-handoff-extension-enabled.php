<?php
/**
 * Whether the Client Handoff extension is enabled.
 *
 * Opt-in: disabled unless the user turns on Client Handoff under
 * Divi Supreme → Extensions.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * True when Divi Supreme → Extensions → Client Handoff is on (default: off).
 *
 * Controls visibility of the Client Handoff settings tab. Turning the
 * extension off while Handoff is applied restores the Role Editor snapshot.
 *
 * @return bool
 */
function dsm_is_client_handoff_extension_enabled(): bool {
	$general = get_option( 'dsm_general', array() );

	if ( ! is_array( $general ) ) {
		return false;
	}

	if ( ! array_key_exists( 'dsm_use_client_handoff', $general ) ) {
		return false;
	}

	return 'on' === $general['dsm_use_client_handoff'];
}
