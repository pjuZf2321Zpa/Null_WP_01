<?php
/**
 * Dark Mode Toggle extension — global enable flag (Divi Supreme → General).
 *
 * Opt-in: disabled unless the user turns on Enable Dark Mode Toggle in plugin settings.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

if ( ! function_exists( 'dsm_is_dark_mode_extension_enabled' ) ) {
	/**
	 * Dsm is dark mode extension enabled.
	 *
	 * @return bool
	 */
	function dsm_is_dark_mode_extension_enabled(): bool {
		$general = get_option( 'dsm_general', array() );

		if ( ! is_array( $general ) ) {
			return false;
		}

		if ( ! array_key_exists( 'dsm_use_dark_mode', $general ) ) {
			return false;
		}

		return 'on' === $general['dsm_use_dark_mode'];
	}
}
