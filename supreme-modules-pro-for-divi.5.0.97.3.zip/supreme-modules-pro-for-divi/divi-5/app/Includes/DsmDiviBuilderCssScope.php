<?php
/**
 * Divi Theme Builder / CPT CSS selector prefix helpers (mirrors Divi Module.php).
 *
 * Static frontend CSS is built as unprefixed base files plus `-cpt.css` companions. PHP selects
 * the correct file at enqueue time via {@see self::resolve_stylesheet_path()}.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Includes;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Shared selector prefix + stylesheet path resolution for DSM frontend CSS.
 */
final class DsmDiviBuilderCssScope {

	/**
	 * Divi builder wrapper prefix (matches `ET_BUILDER_CSS_PREFIX` + trailing space).
	 */
	public const SELECTOR_PREFIX = '.et-db #et-boc .et-l ';

	/**
	 * Filename suffix before extension for CPT/TB stylesheets (`frontend-cpt.css`).
	 */
	public const CPT_CSS_FILENAME_SUFFIX = '-cpt';

	/**
	 * Base stylesheets that must not switch to `-cpt.css`.
	 *
	 * Utility sheets that apply outside builder-scoped DOM (Magnific portaled UI historically;
	 * `supreme-animate.css` stays global). Dark Mode floating switch is appended to `document.body`
	 * (outside `#et-boc .et-l`), so CPT-prefixed selectors would never match it on Theme Builder pages.
	 * Extension popup rules now mount inside `.et-db #et-boc .et-l` on CPT/TB, so
	 * `style-extensions-frontend-styles-cpt.css` is generated and enqueued again.
	 *
	 * @var list<string>
	 */
	private const CPT_VARIANT_EXCLUDED_BASENAMES = array(
		'supreme-animate.css',
		'style-dark-mode-frontend-styles.css',
	);

	/**
	 * Cached prefix decision from calls made before the main query (`wp`).
	 *
	 * @var bool|null
	 */
	private static ?bool $prefix_before_wp = null;

	/**
	 * Cached prefix decision once `wp` has fired. Kept separate so an early `init` call cannot
	 * freeze a false CPT/Theme Builder result for the rest of the request.
	 *
	 * @var bool|null
	 */
	private static ?bool $prefix_after_wp = null;

	/**
	 * Resolved stylesheet paths for this request, keyed by query phase and base path.
	 *
	 * @var array<string, string>
	 */
	private static array $resolved_path_cache = array();

	/**
	 * `filemtime()` (or version fallback) keyed by the resolved absolute path.
	 *
	 * @var array<string, string>
	 */
	private static array $version_cache = array();

	/**
	 * Whether {@see prime_version_cache()} is filling the cache from storage.
	 *
	 * @var bool
	 */
	private static bool $priming_version_cache = false;

	/**
	 * Whether the current request should load `-cpt.css` static stylesheets.
	 *
	 * Mirrors Divi 5 {@see \ET\Builder\Packages\Module\Module} `$should_use_prefix` for dynamic CSS.
	 * The result is computed at most once before `wp` and once after. Callers on `init` must not
	 * reuse the later answer, and the post-query answer must not reuse the early one.
	 *
	 * @return bool
	 */
	public static function needs_builder_css_prefix(): bool {
		if ( did_action( 'wp' ) ) {
			if ( null === self::$prefix_after_wp ) {
				self::$prefix_after_wp = self::compute_needs_builder_css_prefix();
			}

			return self::$prefix_after_wp;
		}

		if ( null === self::$prefix_before_wp ) {
			self::$prefix_before_wp = self::compute_needs_builder_css_prefix();
		}

		return self::$prefix_before_wp;
	}

	/**
	 * Uncached CPT/Theme Builder decision.
	 *
	 * Prefer checks that do not touch Divi's Conditions::* static cache before `wp`.
	 * Calling Conditions::is_custom_post_type() too early caches `false` for the whole request,
	 * so Theme Builder module CSS is emitted without `.et-db #et-boc .et-l` while customizer CSS
	 * still wraps — then `padding: 54px 0` at ≥1350px beats TB section padding.
	 *
	 * @return bool
	 */
	private static function compute_needs_builder_css_prefix(): bool {
		if ( function_exists( 'et_builder_tb_enabled' ) && et_builder_tb_enabled() ) {
			return true;
		}

		if ( class_exists( '\ET\Builder\Framework\Utility\Conditions' ) && did_action( 'wp' ) ) {
			$conditions = '\ET\Builder\Framework\Utility\Conditions';

			if ( $conditions::is_custom_post_type() || $conditions::is_tb_enabled() ) {
				return true;
			}
		}

		if ( function_exists( 'et_core_is_fb_enabled' ) && et_core_is_fb_enabled() ) {
			if ( function_exists( 'dsm_get_vb_builder_edited_post_id' ) ) {
				$post_id = dsm_get_vb_builder_edited_post_id();

				if ( $post_id > 0 && function_exists( 'et_builder_is_post_type_custom' ) ) {
					$post_type = get_post_type( $post_id );

					if ( is_string( $post_type ) && et_builder_is_post_type_custom( $post_type ) ) {
						return true;
					}
				}
			}
		}

		if ( function_exists( 'is_et_theme_builder_live_preview' ) && is_et_theme_builder_live_preview() ) {
			return true;
		}

		if ( function_exists( 'is_singular' ) && is_singular() && function_exists( 'et_builder_is_post_type_custom' ) ) {
			$post_type = get_post_type();

			if ( is_string( $post_type ) && '' !== $post_type && et_builder_is_post_type_custom( $post_type ) ) {
				return true;
			}
		}

		$queried = get_queried_object();

		if ( $queried instanceof \WP_Post && function_exists( 'et_theme_builder_is_layout_post_type' ) ) {
			if ( et_theme_builder_is_layout_post_type( $queried->post_type ) ) {
				return true;
			}
		}

		/**
		 * Force CPT-scoped static CSS (popups with `#et-boc`, library layouts, etc.).
		 *
		 * @param bool $needs_builder_css_prefix Default false.
		 */
		return (bool) apply_filters( 'dsm_needs_builder_css_prefix', false );
	}

	/**
	 * Ensure module `orderClass` includes the TB/CPT prefix when static/dynamic CSS needs it.
	 *
	 * Divi usually prefixes before calling `module_styles`; this covers edge paths where it does not.
	 *
	 * @param string $order_class Module order class (e.g. `.dsm_icon_list_0`).
	 * @return string
	 */
	public static function resolve_order_class( string $order_class ): string {
		$order_class = trim( $order_class );

		if ( '' === $order_class || ! self::needs_builder_css_prefix() ) {
			return $order_class;
		}

		if ( 1 === preg_match( '/^\.et-db\b/i', $order_class ) ) {
			return $order_class;
		}

		return self::SELECTOR_PREFIX . ltrim( $order_class, ' ' );
	}

	/**
	 * Strip TB/CPT wrapper prefix from an order class (for {{baseSelector}} tokens).
	 *
	 * @param string $order_class Module order class.
	 * @return string
	 */
	public static function strip_builder_css_prefix_from_order_class( string $order_class ): string {
		$order_class = trim( $order_class );

		if ( '' === $order_class || 1 !== preg_match( '/^\.et-db\b/i', $order_class ) ) {
			return $order_class;
		}

		return trim( (string) preg_replace( '/^\.et-db\s+#et-boc\s+\.et-l\s+/', '', $order_class ) );
	}

	/**
	 * Normalize Divi 5 `module_styles` args so order-class selectors match CPT/TB static CSS.
	 *
	 * Divi usually prefixes `orderClass` before calling `module_styles`; this covers edge paths
	 * (VB REST, portaled tooltips, custom selectors built from `baseOrderClass`, etc.).
	 *
	 * @param array<string, mixed> $args Style component arguments from {@see Module::render()}.
	 * @return array<string, mixed>
	 */
	public static function normalize_module_styles_args( array $args ): array {
		// Always mirror orderClass / baseOrderClass onto ModuleElements. Parent-rendered children
		// (e.g. Advanced Tabs) construct ModuleElements manually — without this sync,
		// `$elements->style()` leaves `{{selector}}` / `{{baseSelector}}` unresolved on FE
		// (VB Module::render sets them; CPT prefix path already synced below).
		if ( ! self::needs_builder_css_prefix() ) {
			return self::sync_module_elements_order_classes( $args );
		}

		// Full order classes used for {{selector}} / wrapper selectors — may receive CPT prefix.
		$prefixed_class_keys = array(
			'orderClass',
			'wrapperOrderClass',
			'parentOrderClass',
			'stickyParentOrderClass',
		);

		foreach ( $prefixed_class_keys as $key ) {
			if ( ! isset( $args[ $key ] ) || ! is_string( $args[ $key ] ) ) {
				continue;
			}

			$args[ $key ] = self::resolve_order_class( $args[ $key ] );
		}

		// Base order classes feed {{baseSelector}} / {{baseWrapperSelector}} while {{selectorPrefix}}
		// adds `.et-db #et-boc .et-l` once at the chain root — never prefix these (avoids doubled CPT scope).
		$base_class_keys = array(
			'baseOrderClass',
			'baseWrapperOrderClass',
		);

		foreach ( $base_class_keys as $key ) {
			if ( ! isset( $args[ $key ] ) || ! is_string( $args[ $key ] ) ) {
				continue;
			}

			$args[ $key ] = self::strip_builder_css_prefix_from_order_class( $args[ $key ] );
		}

		if ( empty( $args['selectorPrefix'] ) ) {
			$args['selectorPrefix'] = self::SELECTOR_PREFIX;
		}

		$args['isCustomPostType'] = true;

		return self::sync_module_elements_order_classes( $args );
	}

	/**
	 * Mirror prefixed order classes onto the ModuleElements instance.
	 *
	 * `$elements->style()` resolves `{{selector}}` from the elements object, not from `$args['orderClass']`.
	 * Divi only prefixes at render time when {@see Conditions::is_custom_post_type()} is true; WooCommerce
	 * products and some layout CPT views need the broader {@see self::needs_builder_css_prefix()} check instead.
	 *
	 * @param array<string, mixed> $args Style component arguments.
	 * @return array<string, mixed>
	 */
	private static function sync_module_elements_order_classes( array $args ): array {
		if ( ! isset( $args['elements'] ) || ! is_object( $args['elements'] ) ) {
			return $args;
		}

		$elements = $args['elements'];

		$sync_map = array(
			'orderClass'            => 'set_order_class',
			'baseOrderClass'        => 'set_base_order_class',
			'wrapperOrderClass'     => 'set_wrapper_order_class',
			'baseWrapperOrderClass' => 'set_base_wrapper_order_class',
		);

		foreach ( $sync_map as $arg_key => $setter ) {
			if ( ! isset( $args[ $arg_key ] ) || ! is_string( $args[ $arg_key ] ) || '' === $args[ $arg_key ] ) {
				continue;
			}

			if ( ! method_exists( $elements, $setter ) ) {
				continue;
			}

			$elements->{$setter}( $args[ $arg_key ] );
		}

		// Only override CPT flag when the caller sets it. Defaulting to true would incorrectly
		// prefix selectors on normal pages when this sync runs outside the CPT path.
		if (
			$elements instanceof \ET\Builder\Packages\Module\Layout\Components\ModuleElements\ModuleElements
			&& ( array_key_exists( 'isCustomPostType', $args ) || array_key_exists( 'is_custom_post_type', $args ) )
		) {
			self::set_module_elements_custom_post_type_flag(
				$elements,
				(bool) ( $args['isCustomPostType'] ?? $args['is_custom_post_type'] ?? false )
			);
		}

		return $args;
	}

	/**
	 * Enable CPT selector behaviour on ModuleElements (`{{selectorPrefix}}`, etc.).
	 *
	 * @param \ET\Builder\Packages\Module\Layout\Components\ModuleElements\ModuleElements $elements Module elements instance.
	 * @param bool                                                                        $is_custom_post_type Whether CPT/TB prefix context applies.
	 * @return void
	 */
	private static function set_module_elements_custom_post_type_flag(
		\ET\Builder\Packages\Module\Layout\Components\ModuleElements\ModuleElements $elements,
		bool $is_custom_post_type
	): void {
		try {
			$reflection = new \ReflectionProperty( $elements, '_is_custom_post_type' );
			$reflection->setAccessible( true );
			$reflection->setValue( $elements, $is_custom_post_type );
		} catch ( \ReflectionException $e ) {
			unset( $e );
		}
	}

	/**
	 * Basename for the CPT companion file (`frontend.css` → `frontend-cpt.css`).
	 *
	 * @param string $basename Filename only.
	 * @return string
	 */
	public static function cpt_variant_basename( string $basename ): string {
		$basename = trim( $basename );

		if ( '' === $basename ) {
			return $basename;
		}

		if ( str_contains( $basename, self::CPT_CSS_FILENAME_SUFFIX . '.' ) ) {
			return $basename;
		}

		$dot = strrpos( $basename, '.' );

		if ( false === $dot || $dot <= 0 ) {
			return $basename . self::CPT_CSS_FILENAME_SUFFIX;
		}

		return substr( $basename, 0, $dot ) . self::CPT_CSS_FILENAME_SUFFIX . substr( $basename, $dot );
	}

	/**
	 * Absolute path to the CPT companion for a base stylesheet when it exists.
	 *
	 * @param string $absolute_path Readable base stylesheet path.
	 * @return string|null
	 */
	public static function cpt_variant_path( string $absolute_path ): ?string {
		$absolute_path = wp_normalize_path( $absolute_path );

		if ( '' === $absolute_path || ! self::uses_cpt_stylesheet_variant( $absolute_path ) ) {
			return null;
		}

		$dir      = dirname( $absolute_path );
		$cpt_path = trailingslashit( $dir ) . self::cpt_variant_basename( basename( $absolute_path ) );
		$cpt_path = wp_normalize_path( $cpt_path );

		return is_readable( $cpt_path ) ? $cpt_path : null;
	}

	/**
	 * Whether a base stylesheet should have a `-cpt.css` companion for the current request.
	 *
	 * @param string $absolute_path Readable base stylesheet path.
	 * @return bool
	 */
	public static function uses_cpt_stylesheet_variant( string $absolute_path ): bool {
		$basename = basename( wp_normalize_path( $absolute_path ) );

		if ( '' === $basename ) {
			return true;
		}

		if ( false !== strpos( $basename, self::CPT_CSS_FILENAME_SUFFIX . '.' ) ) {
			return false;
		}

		return ! in_array( $basename, self::CPT_VARIANT_EXCLUDED_BASENAMES, true );
	}

	/**
	 * Pick base or `-cpt.css` absolute path for the current request.
	 *
	 * @param string $absolute_path Readable base stylesheet path.
	 * @return string
	 */
	public static function resolve_stylesheet_path( string $absolute_path ): string {
		$absolute_path = wp_normalize_path( $absolute_path );
		$cache_key     = ( did_action( 'wp' ) ? 'post:' : 'pre:' ) . $absolute_path;

		if ( isset( self::$resolved_path_cache[ $cache_key ] ) ) {
			return self::$resolved_path_cache[ $cache_key ];
		}

		if ( '' === $absolute_path || ! is_readable( $absolute_path ) ) {
			self::$resolved_path_cache[ $cache_key ] = $absolute_path;

			return $absolute_path;
		}

		if ( ! self::needs_builder_css_prefix() || ! self::uses_cpt_stylesheet_variant( $absolute_path ) ) {
			self::$resolved_path_cache[ $cache_key ] = $absolute_path;

			return $absolute_path;
		}

		$cpt_path = self::cpt_variant_path( $absolute_path );
		$resolved = null !== $cpt_path ? $cpt_path : $absolute_path;

		self::$resolved_path_cache[ $cache_key ] = $resolved;

		return $resolved;
	}

	/**
	 * Public URL for {@see resolve_stylesheet_path()} when the path is under the plugin.
	 *
	 * @param string $plugin_relative_url Plugin URL + relative path (e.g. `.../public/foo.css`).
	 * @return string
	 */
	public static function resolve_stylesheet_url( string $plugin_relative_url ): string {
		if ( ! defined( 'DSM_DIR_PATH' ) || ! defined( 'DSM_DIR_URL' ) ) {
			return $plugin_relative_url;
		}

		$plugin_url = trailingslashit( DSM_DIR_URL );

		if ( ! str_starts_with( $plugin_relative_url, $plugin_url ) ) {
			return $plugin_relative_url;
		}

		$url_relative = ltrim( substr( $plugin_relative_url, strlen( $plugin_url ) ), '/' );
		$absolute     = self::locate_stylesheet_absolute_path( $url_relative );

		if ( null === $absolute ) {
			return $plugin_relative_url;
		}

		$resolved = self::resolve_stylesheet_path( $absolute );

		if ( $resolved === $absolute ) {
			return $plugin_relative_url;
		}

		return $plugin_url . self::absolute_path_to_url_relative( $resolved );
	}

	/**
	 * Resolve a URL-relative path (under {@see DSM_DIR_URL}) to a readable absolute file.
	 *
	 * Built assets live under `divi-5/public/` while {@see DSM_DIR_URL} already points at the
	 * `divi-5/` directory — try that subtree first, then the plugin root.
	 *
	 * @param string $url_relative Path relative to {@see DSM_DIR_URL} (e.g. `public/foo.css`).
	 * @return string|null
	 */
	public static function locate_stylesheet_absolute_path( string $url_relative ): ?string {
		if ( ! defined( 'DSM_DIR_PATH' ) ) {
			return null;
		}

		$url_relative = ltrim( wp_normalize_path( $url_relative ), '/' );

		if ( '' === $url_relative ) {
			return null;
		}

		$plugin_path = wp_normalize_path( trailingslashit( DSM_DIR_PATH ) );
		$candidates  = array(
			$plugin_path . 'divi-5/' . $url_relative,
			$plugin_path . $url_relative,
		);

		foreach ( $candidates as $absolute ) {
			if ( is_readable( $absolute ) ) {
				return wp_normalize_path( $absolute );
			}
		}

		return null;
	}

	/**
	 * Convert an absolute plugin stylesheet path back to a {@see DSM_DIR_URL}-relative segment.
	 *
	 * @param string $absolute_path Absolute path under the plugin.
	 * @return string
	 */
	public static function absolute_path_to_url_relative( string $absolute_path ): string {
		if ( ! defined( 'DSM_DIR_PATH' ) ) {
			return ltrim( $absolute_path, '/' );
		}

		$absolute_path = wp_normalize_path( $absolute_path );
		$plugin_path   = wp_normalize_path( trailingslashit( DSM_DIR_PATH ) );
		$divi5_prefix  = $plugin_path . 'divi-5/';

		if ( str_starts_with( $absolute_path, $divi5_prefix ) ) {
			return ltrim( substr( $absolute_path, strlen( $divi5_prefix ) ), '/' );
		}

		if ( str_starts_with( $absolute_path, $plugin_path ) ) {
			return ltrim( substr( $absolute_path, strlen( $plugin_path ) ), '/' );
		}

		return ltrim( $absolute_path, '/' );
	}

	/**
	 * `filemtime()` for the resolved stylesheet path.
	 *
	 * @param string $absolute_path Readable base stylesheet path.
	 * @return string
	 */
	public static function resolve_stylesheet_version( string $absolute_path ): string {
		return self::resolved_stylesheet_version( self::resolve_stylesheet_path( $absolute_path ) );
	}

	/**
	 * `filemtime()` for a path that {@see resolve_stylesheet_path()} already chose.
	 *
	 * Does not run the CPT decision again. Repeated calls for the same file reuse the first mtime.
	 *
	 * @param string $resolved_path Absolute path of the stylesheet that will be enqueued.
	 * @return string
	 */
	public static function resolved_stylesheet_version( string $resolved_path ): string {
		$resolved_path = wp_normalize_path( $resolved_path );

		if ( isset( self::$version_cache[ $resolved_path ] ) ) {
			return self::$version_cache[ $resolved_path ];
		}

		if ( is_readable( $resolved_path ) ) {
			self::$version_cache[ $resolved_path ] = (string) filemtime( $resolved_path );
		} else {
			self::$version_cache[ $resolved_path ] = defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';
		}

		if ( ! self::$priming_version_cache ) {
			DsmFrontendModuleAssetRegistry::mark_stylesheet_versions_dirty();
		}

		return self::$version_cache[ $resolved_path ];
	}

	/**
	 * Reuse stylesheet versions stored with the library index.
	 *
	 * Primed values are not treated as new measurements, so loading the cache does not write it again.
	 *
	 * @param array<string, string> $versions Absolute path => version string.
	 * @return void
	 */
	public static function prime_version_cache( array $versions ): void {
		self::$priming_version_cache = true;

		foreach ( $versions as $path => $version ) {
			if ( ! is_string( $path ) || '' === $path || ! is_string( $version ) || '' === $version ) {
				continue;
			}

			$normalized = function_exists( 'wp_normalize_path' ) ? wp_normalize_path( $path ) : $path;

			if ( ! isset( self::$version_cache[ $normalized ] ) ) {
				self::$version_cache[ $normalized ] = $version;
			}
		}

		self::$priming_version_cache = false;
	}

	/**
	 * Stylesheet versions measured during this request.
	 *
	 * @return array<string, string>
	 */
	public static function export_version_cache(): array {
		return self::$version_cache;
	}

	/**
	 * Drop per-request stylesheet caches.
	 *
	 * Production requests never need this. Tests use it between cases in one process.
	 *
	 * @return void
	 */
	public static function reset_request_caches(): void {
		self::$prefix_before_wp      = null;
		self::$prefix_after_wp       = null;
		self::$resolved_path_cache   = array();
		self::$version_cache         = array();
		self::$priming_version_cache = false;
	}

	/**
	 * Prefix a selector list for TB/CPT without removing the unprefixed variant.
	 *
	 * @deprecated Prefer split `-cpt.css` files. Kept for ad-hoc dynamic selector construction.
	 * @param string $selector Single selector or comma-separated list.
	 * @return string Dual selectors: original plus prefixed copy when needed.
	 */
	public static function dual_selector( string $selector ): string {
		$selector = trim( $selector );

		if ( '' === $selector ) {
			return $selector;
		}

		$parts = preg_split( '/\s*,\s*/', $selector );
		if ( ! is_array( $parts ) ) {
			$parts = array();
		}
		$expanded = array();

		foreach ( $parts as $part ) {
			$part = trim( (string) $part );

			if ( '' === $part ) {
				continue;
			}

			$expanded[] = $part;

			if ( self::needs_prefix( $part ) ) {
				$expanded[] = self::SELECTOR_PREFIX . $part;
			}
		}

		return implode( ', ', $expanded );
	}

	/**
	 * Needs prefix.
	 *
	 * @param string $selector Single selector fragment.
	 * @return bool
	 */
	public static function needs_prefix( string $selector ): bool {
		$selector = trim( $selector );

		if ( '' === $selector ) {
			return false;
		}

		return 1 !== preg_match( '/^\.et-db\b/i', $selector );
	}

	/**
	 * Register WordPress hooks for CPT selector normalization.
	 *
	 * @return void
	 */
	public static function register_hooks(): void {
		add_filter( 'block_type_metadata', array( self::class, 'filter_block_type_metadata' ), 20 );
		// After Divi CriticalCSS::builder_style_tag — restore CPT specificity for TB section spacing.
		add_filter( 'et_core_page_resource_tag', array( self::class, 'filter_page_resource_tag_prefix_tb_section_spacing' ), 20, 2 );
	}

	/**
	 * Duplicate unprefixed Theme Builder section spacing selectors with the CPT wrapper.
	 *
	 * When Divi emits `.et_pb_section_0_tb_header.et_pb_section{padding-top:10px;…}` without
	 * `.et-db #et-boc .et-l`, Divi's wrapped customizer rule
	 * `.et-db #et-boc .et-l .et_pb_section{padding:54px 0}` (min-width:1350px) wins on specificity
	 * and Theme Builder header/menu padding is ignored.
	 *
	 * Does not invent padding values — only re-emits existing TB spacing declarations with higher specificity.
	 *
	 * @param string $tag  Page resource HTML tag.
	 * @param string $slug Resource slug.
	 * @return string
	 */
	public static function filter_page_resource_tag_prefix_tb_section_spacing( string $tag, string $slug = '' ): string {
		unset( $slug );

		if ( '' === $tag || is_admin() ) {
			return $tag;
		}

		if ( ! self::needs_builder_css_prefix() ) {
			return $tag;
		}

		if ( ! str_contains( $tag, '_tb_' ) || ! str_contains( $tag, 'padding' ) ) {
			return $tag;
		}

		return self::prefix_unwrapped_tb_section_spacing_in_css( $tag );
	}

	/**
	 * Prefix unwrapped tb section spacing in CSS.
	 *
	 * @param string $css CSS or HTML containing CSS.
	 * @return string
	 */
	public static function prefix_unwrapped_tb_section_spacing_in_css( string $css ): string {
		if ( '' === $css || ! str_contains( $css, '_tb_' ) ) {
			return $css;
		}

		$prefix = self::SELECTOR_PREFIX;

		// Match unprefixed TB section spacing longhands / shorthand, e.g.
		// `.et_pb_section_0_tb_header.et_pb_section{padding-top:10px;padding-bottom:10px}`
		// Skip selectors that already include the CPT wrapper (lookbehind for `.et-l `).
		$pattern = '/(?<!\\.et-l )(\\.et_pb_section_\\d+_tb_(?:header|body|footer)(?:\\.et_pb_section)?)\\s*\\{([^}]*padding[^}]*)\\}/i';

		return (string) preg_replace_callback(
			$pattern,
			static function ( array $matches ) use ( $prefix, $css ): string {
				$selector      = $matches[1];
				$declarations  = $matches[2];
				$block         = $matches[0];
				$prefixed_rule = $prefix . $selector . '{' . $declarations . '}';

				// Twin already present in the stylesheet — do not duplicate.
				if ( str_contains( $css, $prefixed_rule ) ) {
					return $block;
				}

				return $block . $prefixed_rule;
			},
			$css
		);
	}

	/**
	 * Rewrite parent-scoped child module selectors in module.json metadata (PHP + VB style resolution).
	 *
	 * @param array<string, mixed> $metadata Block metadata from module.json.
	 * @return array<string, mixed>
	 */
	public static function filter_block_type_metadata( array $metadata ): array {
		$name = isset( $metadata['name'] ) && is_string( $metadata['name'] ) ? $metadata['name'] : '';

		if ( '' === $name || ! str_starts_with( $name, 'dsm/' ) ) {
			return $metadata;
		}

		if ( ! empty( $metadata['attributes'] ) && is_array( $metadata['attributes'] ) ) {
			$metadata['attributes'] = self::rewrite_module_attribute_selectors( $metadata['attributes'] );
		}

		return $metadata;
	}

	/**
	 * Runtime parent/child selector for module_styles (mirrors Divi core child-module pattern).
	 *
	 * @param string $parent_class Parent module class without leading dot (e.g. `dsm_card_carousel`).
	 * @param string $order_class  Child order class (prefixed or not).
	 * @param string $suffix       Optional suffix after order class.
	 * @return string
	 */
	/**
	 * Parent-scoped child selector for runtime module_styles (single or multi-class parent chain).
	 *
	 * @param string $parent_chain Selector chain before child order class (e.g. `.dsm_stacking_card_container`).
	 * @param string $order_class  Child order class (prefixed or not).
	 * @param string $suffix       Optional suffix after order class.
	 * @return string
	 */
	public static function scoped_child_selector( string $parent_chain, string $order_class, string $suffix = '' ): string {
		$parent_chain = trim( $parent_chain );
		$order_class  = trim( $order_class );
		$suffix       = (string) $suffix;

		if ( '' === $parent_chain || '' === $order_class ) {
			return trim( "{$parent_chain} {$order_class}{$suffix}" );
		}

		if ( 1 === preg_match( '/^\.et-db\b/i', $order_class ) ) {
			$base = preg_replace( '/^\.et-db\s+#et-boc\s+\.et-l\s+/', '', $order_class );

			return self::SELECTOR_PREFIX . "{$parent_chain} " . trim( (string) $base ) . $suffix;
		}

		return "{$parent_chain} {$order_class}{$suffix}";
	}

	/**
	 * Runtime parent/child selector for module_styles (mirrors Divi core child-module pattern).
	 *
	 * @param string $parent_class Parent module class without leading dot (e.g. `dsm_card_carousel`).
	 * @param string $order_class  Child order class (prefixed or not).
	 * @param string $suffix       Optional suffix after order class.
	 * @return string
	 */
	public static function parent_child_selector( string $parent_class, string $order_class, string $suffix = '' ): string {
		$parent_class = trim( $parent_class, ". \t\n\r\0\x0B" );

		if ( '' === $parent_class ) {
			return self::scoped_child_selector( '', $order_class, $suffix );
		}

		return self::scoped_child_selector( '.' . $parent_class, $order_class, $suffix );
	}

	/**
	 * Rewrite `.parent {{selector}}` templates to `{{selectorPrefix}}.parent {{baseSelector}}`.
	 *
	 * @param string $selector Selector template.
	 * @return string
	 */
	public static function rewrite_parent_prefixed_selector_template( string $selector ): string {
		$selector = trim( $selector );

		if ( '' === $selector || str_contains( $selector, '{{selectorPrefix}}' ) ) {
			return $selector;
		}

		return (string) preg_replace_callback(
			'/([^{},]*?\{\{selector\}\})/',
			static function ( array $matches ): string {
				$fragment = trim( $matches[1] );

				if ( '' === $fragment || ! str_starts_with( $fragment, '.' ) ) {
					return $matches[1];
				}

				return '{{selectorPrefix}}' . str_replace( '{{selector}}', '{{baseSelector}}', $fragment );
			},
			$selector
		);
	}

	/**
	 * Recursively rewrite selector strings under module attribute metadata.
	 *
	 * @param array<string, mixed> $attributes Module attributes tree.
	 * @return array<string, mixed>
	 */
	private static function rewrite_module_attribute_selectors( array $attributes ): array {
		foreach ( $attributes as $key => $value ) {
			if ( is_string( $value ) && self::should_rewrite_selector_template( $value ) ) {
				$attributes[ $key ] = self::rewrite_parent_prefixed_selector_template( $value );
				continue;
			}

			if ( is_array( $value ) ) {
				$attributes[ $key ] = self::rewrite_module_attribute_selectors( $value );
			}
		}

		return $attributes;
	}

	/**
	 * Should rewrite selector template.
	 *
	 * @param string $value Possible selector template string.
	 * @return bool
	 */
	private static function should_rewrite_selector_template( string $value ): bool {
		return str_contains( $value, '{{selector}}' ) && ! str_contains( $value, '{{selectorPrefix}}' );
	}
}
