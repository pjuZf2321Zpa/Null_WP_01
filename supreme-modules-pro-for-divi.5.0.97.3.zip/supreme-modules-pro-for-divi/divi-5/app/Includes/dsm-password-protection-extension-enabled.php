<?php
/**
 * Whether the Password Protection extension is enabled.
 *
 * Opt-in: disabled unless the user turns on Password Protection under
 * Divi Supreme → Extensions.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * True when Divi Supreme → Extensions → Password Protection is on (default: off).
 *
 * Controls Section / Row / Column Password Protection in the Visual Builder and
 * frontend block gates, and visibility of the Password Protection settings tab.
 *
 * @return bool
 */
function dsm_is_password_protection_extension_enabled(): bool {
	$general = get_option( 'dsm_general', array() );

	if ( ! is_array( $general ) ) {
		return false;
	}

	if ( ! array_key_exists( 'dsm_use_password_protection', $general ) ) {
		return false;
	}

	return 'on' === $general['dsm_use_password_protection'];
}
