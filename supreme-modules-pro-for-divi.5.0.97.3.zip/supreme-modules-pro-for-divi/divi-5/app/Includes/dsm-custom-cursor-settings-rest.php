<?php
/**
 * REST: Custom Cursor global settings (Visual Builder modal).
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Registers `GET|POST /dsm/v1/custom-cursor-settings`.
 */
final class DSM_Custom_Cursor_Settings_REST {

	/**
	 * Hook REST routes.
	 */
	public function __construct() {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	/**
	 * Register routes.
	 *
	 * @return void
	 */
	public function register_routes(): void {
		register_rest_route(
			'dsm/v1',
			'/custom-cursor-settings',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_settings' ),
					'permission_callback' => array( $this, 'permission_callback' ),
				),
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'save_settings' ),
					'permission_callback' => array( $this, 'permission_callback' ),
				),
			)
		);
	}

	/**
	 * Permission callback.
	 *
	 * @return bool
	 */
	public function permission_callback(): bool {
		return current_user_can( 'edit_posts' );
	}

	/**
	 * Get settings.
	 *
	 * @return \WP_REST_Response
	 */
	public function get_settings(): \WP_REST_Response {
		if ( ! isset( $GLOBALS['dsm_custom_cursor_extension'] )
			|| ! $GLOBALS['dsm_custom_cursor_extension'] instanceof \DiviSupreme\Extensions\CustomCursor ) {
			return new \WP_REST_Response( array(), 200 );
		}

		return new \WP_REST_Response(
			$GLOBALS['dsm_custom_cursor_extension']->get_settings(),
			200
		);
	}

	/**
	 * Save settings.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function save_settings( \WP_REST_Request $request ) {
		if ( ! isset( $GLOBALS['dsm_custom_cursor_extension'] )
			|| ! $GLOBALS['dsm_custom_cursor_extension'] instanceof \DiviSupreme\Extensions\CustomCursor ) {
			return new \WP_Error(
				'dsm_custom_cursor_unavailable',
				esc_html__( 'Custom Cursor extension is not loaded.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 503 )
			);
		}

		$payload = $request->get_json_params();
		if ( ! is_array( $payload ) ) {
			$payload = array();
		}

		$saved = $GLOBALS['dsm_custom_cursor_extension']->save_settings( $payload );

		if ( ! $saved ) {
			return new \WP_Error(
				'dsm_custom_cursor_save_failed',
				esc_html__( 'Could not save Custom Cursor settings.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 500 )
			);
		}

		return new \WP_REST_Response(
			$GLOBALS['dsm_custom_cursor_extension']->get_settings(),
			200
		);
	}
}

new DSM_Custom_Cursor_Settings_REST();
