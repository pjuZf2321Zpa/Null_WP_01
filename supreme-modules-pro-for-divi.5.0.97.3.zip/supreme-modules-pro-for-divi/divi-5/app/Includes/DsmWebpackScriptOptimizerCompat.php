<?php
/**
 * Keep Webpack-produced frontend bundles from being concatenated/minified incorrectly.
 *
 * SiteGround Optimizer (and similar combiners) can merge unrelated scripts together. Our
 * singleton Webpack bundles include an inlined runtime (`__webpack_require__`). If that preamble
 * is stripped, reordered, or split across concatenated files, browsers throw ReferenceError and
 * dependent globals (for example {@see \DiviSupreme\Modules\MasonryGallery} jQuery init) fail.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Includes;

/**
 * Compatibility layer for caching / optimisation plugins that combine JavaScript assets.
 *
 * Handles map to bundles under `assets/js/` that retain a Webpack bootstrap (see webpack entry
 * `masonry-gallery-frontend`, `filterable-gallery-frontend`, etc.).
 */
final class DsmWebpackScriptOptimizerCompat {

	/**
	 * Filter the canonical list of {@see wp_register_script()} handles excluded from optimisation combiners.
	 *
	 * @since 5.0.0
	 */
	public const DSM_WEBPACK_OPTIMIZER_COMBINE_EXCLUDE_HANDLES = 'dsm_webpack_optimizer_combine_exclude_handles';

	/**
	 * Register WordPress and third‑party plugin filters.
	 *
	 * @since 5.0.0
	 * @return void
	 */
	public static function register_hooks(): void {
		add_filter(
			'script_loader_tag',
			array( self::class, 'filter_markup_hints' ),
			9,
			2
		);

		add_filter(
			'sgo_javascript_combine_exclude',
			array( self::class, 'merge_siteground_combine_handles' ),
			20,
			1
		);

		add_filter(
			'sgo_js_minify_exclude',
			array( self::class, 'merge_siteground_minify_handles' ),
			20,
			1
		);

		add_filter(
			'autoptimize_filter_js_exclude',
			array( self::class, 'merge_autoptimize_js_exclude_patterns' ),
			20,
			1
		);

		add_filter(
			'rocket_exclude_js',
			array( self::class, 'merge_wp_rocket_exclude_patterns' ),
			20,
			1
		);
	}

	/**
	 * Default handles that enqueue Webpack runtime bundles (`divi-5/assets/js/*.js`).
	 *
	 * @since 5.0.0
	 * @return array<int, string>
	 */
	private static function default_webpack_frontend_handles(): array {
		return array(
			'dsm-masonry-gallery',
			'dsm-filterable-gallery',
			'dsm-lottie-frontend',
			'dsm-svg-animation',
			'dsm-image-hover-reveal',
			'dsm-menu',
			'dsm-faq',
			'dsm-toc',
			'dsm-typing',
		);
	}

	/**
	 * Resolves handles after filtering.
	 *
	 * @since 5.0.0
	 * @return array<int, string>
	 */
	private static function resolved_combine_exclude_handles(): array {
		$handles = apply_filters(
			self::DSM_WEBPACK_OPTIMIZER_COMBINE_EXCLUDE_HANDLES,
			self::default_webpack_frontend_handles()
		);

		if ( ! is_array( $handles ) ) {
			return self::default_webpack_frontend_handles();
		}

		$out = array();

		foreach ( $handles as $raw ) {
			if ( ! is_string( $raw ) ) {
				continue;
			}
			$s = sanitize_key( $raw );
			if ( '' !== $s && ! isset( $out[ $s ] ) ) {
				$out[ $s ] = $s;
			}
		}

		return array_values( $out );
	}

	/**
	 * True when the handle is excluded from optimisation combiners.
	 *
	 * @since 5.0.0
	 * @param string $handle Registered script handle.
	 * @return bool
	 */
	private static function is_webpack_compat_handle( string $handle ): bool {
		if ( '' === $handle ) {
			return false;
		}

		return in_array( $handle, self::resolved_combine_exclude_handles(), true );
	}

	/**
	 * Basename patterns (`divi-5/assets/js/*.js`) for plugins that exclude by URL / path substring.
	 *
	 * @since 5.0.0
	 * @return array<int, string>
	 */
	private static function webpack_public_asset_basenames(): array {
		return array(
			'masonry-gallery',
			'filterable-gallery',
			'lottie-frontend',
			'svg-animation-frontend',
			'image-hover-reveal-frontend',
			'menu',
			'faq',
			'table-of-contents',
			'typing',
		);
	}

	/**
	 * Append LiteSpeed-style / Rocket Loader hints on Webpack-backed tags.
	 *
	 * @since 5.0.0
	 * @param string $tag    Raw script tag markup.
	 * @param string $handle Registered WordPress script handle.
	 * @return string
	 */
	public static function filter_markup_hints( string $tag, string $handle ): string {
		if ( is_admin() ) {
			return $tag;
		}

		if ( '' === trim( $tag ) || ! self::is_webpack_compat_handle( $handle ) ) {
			return $tag;
		}

		$attrs = sprintf(
			' data-webpack-runtime="%1$s" data-no-optimize="1" data-cfasync="false"',
			esc_attr( 'dsm' )
		);

		$replacement = '${1}' . $attrs . '${2}';

		$marked = preg_replace( '#(<script)(\s)#i', $replacement, $tag, 1 );

		return is_string( $marked ) ? $marked : $tag;
	}

	/**
	 * SiteGround Speed Optimizer: exclude enqueue handles from JavaScript combining.
	 *
	 * @see https://siteground.com/tutorials/wordpress/speed-optimizer/custom-filters/
	 * @since 5.0.0
	 * @param mixed $incoming SG combine exclude array.
	 * @return array<int, string|string>
	 */
	public static function merge_siteground_combine_handles( $incoming ): array {
		if ( ! is_array( $incoming ) ) {
			$incoming = array();
		}

		foreach ( self::resolved_combine_exclude_handles() as $handle ) {
			if ( ! in_array( $handle, $incoming, true ) ) {
				$incoming[] = $handle;
			}
		}

		return $incoming;
	}

	/**
	 * SiteGround Speed Optimizer: exclude handles from SG minification rewriting.
	 *
	 * Aggressive JS minifiers can rewrite Webpack output in ways that rename `__webpack_require__`.
	 *
	 * @since 5.0.0
	 * @param mixed $incoming SG exclude array.
	 * @return array<int, string|string>
	 */
	public static function merge_siteground_minify_handles( $incoming ): array {
		if ( ! is_array( $incoming ) ) {
			$incoming = array();
		}

		foreach ( self::resolved_combine_exclude_handles() as $handle ) {
			if ( ! in_array( $handle, $incoming, true ) ) {
				$incoming[] = $handle;
			}
		}

		return $incoming;
	}

	/**
	 * WP Rocket: regex patterns matching Webpack-backed Supreme bundle URLs under `divi-5/assets/js/`.
	 *
	 * @since 5.0.0
	 * @param mixed $patterns Existing exclude patterns from WP Rocket or other callbacks.
	 * @return string[]
	 */
	public static function merge_wp_rocket_exclude_patterns( $patterns ): array {
		if ( ! is_array( $patterns ) ) {
			$patterns = array();
		}
		foreach ( self::webpack_public_asset_basenames() as $base ) {
			$patterns[] = '/divi\\-5\\/assets\\/js\\/' . preg_quote( $base, '/' ) . '(\\.min)?\\.js(\\?|$)/';
		}

		return array_values(
			array_unique(
				array_filter(
					array_map( 'strval', $patterns )
				)
			)
		);
	}

	/**
	 * Autoptimize: substring exclusions (comma-separated in its filter convention).
	 *
	 * Autoptimize excludes scripts whose `src` contains any listed substring string.
	 *
	 * @since 5.0.0
	 * @param mixed $incoming Incoming comma-separated exclusions.
	 * @return string
	 */
	public static function merge_autoptimize_js_exclude_patterns( $incoming ): string {
		if ( ! is_string( $incoming ) ) {
			$incoming = '';
		}

		foreach ( self::webpack_public_asset_basenames() as $fragment ) {
			$needle = '/divi-5/assets/js/' . $fragment . '.js';
			if ( false === strpos( $incoming, $needle ) ) {
				if ( '' !== trim( $incoming ) ) {
					$incoming .= ',' . $needle;
				} else {
					$incoming = $needle;
				}
			}
		}

		return $incoming;
	}
}
