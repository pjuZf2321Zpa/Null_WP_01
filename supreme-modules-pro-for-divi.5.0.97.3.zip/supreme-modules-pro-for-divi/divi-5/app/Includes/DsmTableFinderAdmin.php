<?php
/**
 * Admin UI for the read-only Supreme Table finder.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Includes;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Submenu under Divi Supreme: scan layouts for Table modules.
 */
final class DsmTableFinderAdmin {

	public const PAGE_SLUG = 'dsm_table_finder';

	public const NONCE_ACTION = 'dsm_table_finder_scan';

	public const CAPABILITY = 'manage_options';

	/**
	 * Register admin hooks.
	 *
	 * @return void
	 */
	public static function register(): void {
		add_action( 'admin_menu', array( self::class, 'register_admin_menu' ), 101 );
		add_action( 'admin_enqueue_scripts', array( self::class, 'enqueue_admin_assets' ) );
	}

	/**
	 * Capability required to open Find tables.
	 *
	 * @return string
	 */
	public static function capability(): string {
		/**
		 * Capability required for the Find tables admin page.
		 *
		 * @param string $capability Capability slug.
		 */
		$cap = apply_filters( 'dsm_table_finder_capability', self::CAPABILITY );

		return is_string( $cap ) && '' !== $cap ? $cap : self::CAPABILITY;
	}

	/**
	 * Add submenu under Divi Supreme settings.
	 *
	 * @return void
	 */
	public static function register_admin_menu(): void {
		if ( ! current_user_can( self::capability() ) ) {
			return;
		}

		add_submenu_page(
			'divi_supreme_settings',
			__( 'Find on pages', 'dsm-supreme-modules-pro-for-divi' ),
			__( 'Find on pages', 'dsm-supreme-modules-pro-for-divi' ),
			self::capability(),
			self::PAGE_SLUG,
			array( self::class, 'render_page' )
		);
	}

	/**
	 * Styles for the results table.
	 *
	 * @param string $hook_suffix Current admin page hook.
	 * @return void
	 */
	public static function enqueue_admin_assets( string $hook_suffix ): void {
		if ( false === strpos( $hook_suffix, self::PAGE_SLUG ) ) {
			return;
		}

		if ( ! current_user_can( self::capability() ) ) {
			return;
		}

		$version = defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';
		wp_register_style( 'dsm-table-finder-admin', false, array(), $version );
		wp_enqueue_style( 'dsm-table-finder-admin' );
		wp_add_inline_style(
			'dsm-table-finder-admin',
			'.dsm-table-finder-summary{margin:12px 0 16px;}'
			. '.dsm-table-finder-actions{margin:16px 0;}'
		);
	}

	/**
	 * Render the Find tables screen.
	 *
	 * @return void
	 */
	public static function render_page(): void {
		if ( ! current_user_can( self::capability() ) ) {
			wp_die( esc_html__( 'Sorry, you are not allowed to access this page.', 'dsm-supreme-modules-pro-for-divi' ) );
		}

		$did_scan = false;
		$results  = null;

		if ( isset( $_POST['dsm_table_finder_run'] ) ) {
			check_admin_referer( self::NONCE_ACTION );
			$did_scan = true;
			$results  = DsmTableFinder::scan();
		}

		echo '<div class="wrap">';
		echo '<h1>' . esc_html__( 'Find on pages', 'dsm-supreme-modules-pro-for-divi' ) . '</h1>';
		echo '<p class="description">';
		echo esc_html__(
			'Scan published and draft layouts for Divi Table modules already on pages. This is read-only. Reusable tables live on the All tables tab.',
			'dsm-supreme-modules-pro-for-divi'
		);
		echo '</p>';

		echo '<form method="post" class="dsm-table-finder-actions">';
		wp_nonce_field( self::NONCE_ACTION );
		submit_button(
			__( 'Scan now', 'dsm-supreme-modules-pro-for-divi' ),
			'primary',
			'dsm_table_finder_run',
			false
		);
		echo '</form>';

		if ( $did_scan && is_array( $results ) ) {
			self::render_results( $results );
		}

		echo '</div>';
	}

	/**
	 * Print the scan summary and results table.
	 *
	 * @param array<string, mixed> $results Scan payload from DsmTableFinder::scan().
	 * @return void
	 */
	private static function render_results( array $results ): void {
		$total_posts  = isset( $results['total_posts'] ) ? (int) $results['total_posts'] : 0;
		$total_tables = isset( $results['total_tables'] ) ? (int) $results['total_tables'] : 0;
		$truncated    = ! empty( $results['truncated'] );
		$items        = isset( $results['items'] ) && is_array( $results['items'] ) ? $results['items'] : array();

		echo '<div class="dsm-table-finder-summary">';
		echo '<p><strong>';
		echo esc_html(
			sprintf(
				/* translators: 1: layout count, 2: table instance count */
				__( 'Found %1$d layout(s) with %2$d table(s).', 'dsm-supreme-modules-pro-for-divi' ),
				$total_posts,
				$total_tables
			)
		);
		echo '</strong></p>';

		if ( $truncated ) {
			echo '<div class="notice notice-warning inline"><p>';
			echo esc_html__(
				'Scan stopped at the post limit. Narrow content or raise the dsm_table_finder_max_posts filter if you need a larger pass.',
				'dsm-supreme-modules-pro-for-divi'
			);
			echo '</p></div>';
		}
		echo '</div>';

		if ( array() === $items ) {
			echo '<p>' . esc_html__( 'No Divi Table modules were found.', 'dsm-supreme-modules-pro-for-divi' ) . '</p>';
			return;
		}

		echo '<table class="widefat striped">';
		echo '<thead><tr>';
		echo '<th scope="col">' . esc_html__( 'Title', 'dsm-supreme-modules-pro-for-divi' ) . '</th>';
		echo '<th scope="col">' . esc_html__( 'Type', 'dsm-supreme-modules-pro-for-divi' ) . '</th>';
		echo '<th scope="col">' . esc_html__( 'Status', 'dsm-supreme-modules-pro-for-divi' ) . '</th>';
		echo '<th scope="col">' . esc_html__( 'Tables', 'dsm-supreme-modules-pro-for-divi' ) . '</th>';
		echo '<th scope="col">' . esc_html__( 'Data source', 'dsm-supreme-modules-pro-for-divi' ) . '</th>';
		echo '<th scope="col">' . esc_html__( 'Actions', 'dsm-supreme-modules-pro-for-divi' ) . '</th>';
		echo '</tr></thead><tbody>';

		foreach ( $items as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}

			$title      = isset( $item['title'] ) ? (string) $item['title'] : '';
			$type_label = isset( $item['post_type_label'] ) ? (string) $item['post_type_label'] : '';
			$status     = isset( $item['status_label'] ) ? (string) $item['status_label'] : '';
			$count      = isset( $item['table_count'] ) ? (int) $item['table_count'] : 0;
			$edit_url   = isset( $item['edit_url'] ) ? (string) $item['edit_url'] : '';
			$view_url   = isset( $item['view_url'] ) ? (string) $item['view_url'] : '';
			$sources    = isset( $item['sources'] ) && is_array( $item['sources'] ) ? $item['sources'] : array();

			$source_labels = array();
			foreach ( $sources as $source ) {
				if ( is_string( $source ) ) {
					$source_labels[] = DsmTableFinder::source_label( $source );
				}
			}

			echo '<tr>';
			echo '<td>' . esc_html( $title ) . '</td>';
			echo '<td>' . esc_html( $type_label ) . '</td>';
			echo '<td>' . esc_html( $status ) . '</td>';
			echo '<td>' . esc_html( (string) $count ) . '</td>';
			echo '<td>' . esc_html( implode( ', ', $source_labels ) ) . '</td>';
			echo '<td>';
			if ( '' !== $edit_url ) {
				echo '<a href="' . esc_url( $edit_url ) . '" target="_blank" rel="noopener noreferrer">' . esc_html__( 'Edit', 'dsm-supreme-modules-pro-for-divi' ) . '</a>';
			}
			if ( '' !== $view_url ) {
				if ( '' !== $edit_url ) {
					echo ' | ';
				}
				echo '<a href="' . esc_url( $view_url ) . '">' . esc_html__( 'View', 'dsm-supreme-modules-pro-for-divi' ) . '</a>';
			}
			echo '</td>';
			echo '</tr>';
		}

		echo '</tbody></table>';
	}
}
