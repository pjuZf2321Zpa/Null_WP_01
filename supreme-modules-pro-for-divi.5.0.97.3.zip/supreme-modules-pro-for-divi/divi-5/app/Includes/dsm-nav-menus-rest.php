<?php
/**
 * Visual Builder nav menus for Supreme Menu (D4 `et_builder_get_nav_menus_options()` parity).
 *
 * Divi's `/divi/v1/module-data/menu/terms` requires a route-specific `X-ET-Nonce`.
 * `@wordpress/api-fetch` sends `X-WP-Nonce`, so that route returns `invalid_nonce`
 * and the "Select a menu" field stays empty. This localizes menus and exposes
 * `GET /dsm/v1/nav-menus` authenticated with the WordPress REST nonce.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Registers `GET /dsm/v1/nav-menus` and lists WordPress menus for the builder.
 */
final class DSM_Nav_Menus_REST {

	/**
	 * Hook REST routes.
	 */
	public function __construct() {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	/**
	 * WordPress nav menus for the Supreme Menu Visual Builder select.
	 *
	 * @return array<int, array{term_id: int, name: string}>
	 */
	public static function get_for_vb(): array {
		if ( ! current_user_can( 'edit_posts' ) ) {
			return array();
		}

		$menus = wp_get_nav_menus();
		$out   = array();

		if ( is_array( $menus ) ) {
			foreach ( $menus as $menu ) {
				if ( ! is_object( $menu ) || ! isset( $menu->term_id ) ) {
					continue;
				}

				$term_id = (int) $menu->term_id;
				if ( $term_id <= 0 ) {
					continue;
				}

				$name = isset( $menu->name ) ? trim( (string) $menu->name ) : '';
				if ( '' === $name ) {
					$name = sprintf(
						/* translators: %d: menu term ID */
						__( 'Menu %d', 'dsm-supreme-modules-pro-for-divi' ),
						$term_id
					);
				}

				$out[] = array(
					'term_id' => $term_id,
					'name'    => $name,
				);
			}
		}

		/**
		 * Filter Supreme Menu Visual Builder nav-menu options.
		 *
		 * @since 5.0.68
		 * @param array<int, array{term_id: int, name: string}> $out Menus.
		 */
		return apply_filters( 'dsm_nav_menus_for_vb', $out );
	}

	/**
	 * Register the nav-menus collection.
	 *
	 * @return void
	 */
	public function register_routes(): void {
		register_rest_route(
			'dsm/v1',
			'/nav-menus',
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'rest_callback' ),
				'permission_callback' => array( $this, 'permission_callback' ),
			)
		);
	}

	/**
	 * Editors only (same as other Supreme Visual Builder REST routes).
	 *
	 * @return bool
	 */
	public function permission_callback(): bool {
		return current_user_can( 'edit_posts' );
	}

	/**
	 * List nav menus for the Supreme Menu select field.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response
	 */
	public function rest_callback( \WP_REST_Request $request ) {
		unset( $request );

		return new \WP_REST_Response( self::get_for_vb(), 200 );
	}
}

new DSM_Nav_Menus_REST();
