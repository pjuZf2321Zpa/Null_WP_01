<?php
/**
 * DSM attachment taxonomy registration.
 *
 * @package DiviSupreme
 */

/**
 * Class DSM_Attachment_Taxonomy
 */
class DSM_Attachment_Taxonomy {

	/**
	 * Initialize the class and set its properties.
	 */
	public function __construct() {
		add_action( 'init', array( $this, 'register_attachment_taxonomy' ) );
	}

	/**
	 * Register the attachment category taxonomy
	 *
	 * @return void
	 */
	public function register_attachment_taxonomy() {
		$labels = array(
			'name'              => esc_html__( 'Attachment Category - Divi Supreme', 'dsm-supreme-modules-pro-for-divi' ),
			'singular_name'     => esc_html__( 'Attachment Category - Divi Supreme', 'dsm-supreme-modules-pro-for-divi' ),
			'search_items'      => esc_html__( 'Search Categories', 'dsm-supreme-modules-pro-for-divi' ),
			'all_items'         => esc_html__( 'All Categories', 'dsm-supreme-modules-pro-for-divi' ),
			'parent_item'       => esc_html__( 'Parent Category', 'dsm-supreme-modules-pro-for-divi' ),
			'parent_item_colon' => esc_html__( 'Parent Category:', 'dsm-supreme-modules-pro-for-divi' ),
			'edit_item'         => esc_html__( 'Edit Category', 'dsm-supreme-modules-pro-for-divi' ),
			'update_item'       => esc_html__( 'Update Category', 'dsm-supreme-modules-pro-for-divi' ),
			'add_new_item'      => esc_html__( 'Add New Category', 'dsm-supreme-modules-pro-for-divi' ),
			'new_item_name'     => esc_html__( 'New Category Name', 'dsm-supreme-modules-pro-for-divi' ),
			'menu_name'         => esc_html__( 'Categories', 'dsm-supreme-modules-pro-for-divi' ),
		);

		$args = array(
			'hierarchical'      => true,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => array( 'slug' => 'dsm-attachment-category' ),
			'show_in_rest'      => true,
		);

		register_taxonomy( 'dsm-attachment-category', array( 'attachment' ), $args );

		// Update the taxonomy count callback.
		$this->update_taxonomy_count_callback();
	}

	/**
	 * Update the taxonomy count callback
	 *
	 * @return void
	 */
	private function update_taxonomy_count_callback() {
		global $wp_taxonomies;

		if ( ! taxonomy_exists( 'dsm-attachment-category' ) ) {
			return;
		}

		$wp_taxonomies['dsm-attachment-category']->update_count_callback = '_update_generic_term_count';
	}
}

new DSM_Attachment_Taxonomy();
