<?php
/**
 * Divi 5 native dynamic asset integration for Divi Supreme Pro frontend.
 *
 * - Registers all dsm/* block names with Divi's dynamic assets detector
 * (divi_frontend_assets_dynamic_assets_valid_blocks).
 * - Misc → Enable Dynamic Assets **ON**: enqueues split `frontend.css` per detected module; falls back to the
 * monolithic bundle when the page clearly contains `dsm/*` blocks but slug detection is still empty.
 * - Dynamic Assets **OFF**: enqueues full `style-modules-frontend-styles.css` bundle fallback.
 * - Dynamic Assets **ON** + Divi pipeline: {@see DsmFrontendAssetRegistry} early global assets filter.
 * - Dynamic Assets **ON** without Divi pipeline: registry-driven central wp_enqueue split path.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Includes;

use ET\Builder\FrontEnd\Assets\DynamicAssets;
use ET\Builder\FrontEnd\Assets\DynamicAssets\DynamicAssetsStore;
use ET\Builder\FrontEnd\Assets\DynamicAssetsUtils;

/**
 * Hooks Divi 5 dynamic asset filters and conditional enqueue for module CSS (split or bundled).
 */
final class DsmFrontendDynamicAssets {

	/**
	 * Prevent double localization of the Facebook handle.
	 *
	 * @var bool
	 */
	private static bool $facebook_localized = false;

	/**
	 * Whether Divi's row/section/block_row structure CSS has been queued for footer-injected popups.
	 *
	 * @var bool
	 */
	private static bool $queued_divi_popup_structure_styles = false;

	/**
	 * Skip `parse_blocks()` above this size to avoid memory exhaustion on Theme Builder mega-content.
	 */
	private const MAX_PARSE_BLOCKS_BYTES = 1_048_576;

	/**
	 * Cap merged detection string size for legacy callers (filters / substring scans).
	 */
	private const MAX_MERGED_CONTENT_BYTES = 2_097_152;

	/**
	 * Maximum library layout bodies merged into detection per request.
	 */
	private const MAX_SUPPLEMENT_LAYOUT_IDS = 75;

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public static function register_hooks(): void {
		add_filter(
			'divi_frontend_assets_dynamic_assets_valid_blocks',
			array( self::class, 'filter_valid_blocks' ),
			10,
			1
		);

		add_filter(
			'divi_frontend_assets_dynamic_assets_global_assets_list',
			array( DsmFrontendAssetRegistry::class, 'filter_global_assets_list' ),
			15,
			3
		);

		add_filter(
			'divi_frontend_assets_dynamic_assets_late_global_assets_list',
			array( DsmFrontendAssetRegistry::class, 'filter_global_assets_list' ),
			15,
			3
		);

		add_filter(
			'divi_frontend_assets_dynamic_assets_global_assets_list',
			array( self::class, 'filter_divi_icon_font_global_assets' ),
			25,
			3
		);

		add_filter(
			'divi_frontend_assets_dynamic_assets_late_global_assets_list',
			array( self::class, 'filter_divi_icon_font_global_assets' ),
			25,
			3
		);

		add_filter(
			'divi_frontend_assets_dynamic_assets_required_module_assets',
			array( self::class, 'filter_required_dsm_module_assets' ),
			10,
			2
		);

		add_filter(
			'divi_frontend_assets_dynamic_assets_required_module_assets',
			array( self::class, 'filter_divi_popup_required_module_assets' ),
			15,
			2
		);

		add_action( 'wp_head', 'dsm_print_divi_icon_font_fallback_styles', 8 );

		add_action(
			'wp_enqueue_scripts',
			array( DsmFrontendModuleAssetRegistry::class, 'refresh_scoped_frontend_style_handles' ),
			17
		);

		add_action(
			'wp_enqueue_scripts',
			array( self::class, 'maybe_enqueue_supreme_animate_styles' ),
			18
		);

		add_action(
			'wp_enqueue_scripts',
			array( self::class, 'maybe_enqueue_core_module_styles' ),
			20
		);

		add_action(
			'wp_enqueue_scripts',
			array( self::class, 'maybe_enqueue_detected_module_scripts' ),
			21
		);

		add_action(
			'wp_enqueue_scripts',
			array( self::class, 'maybe_enqueue_divi_structure_for_footer_popups' ),
			18
		);

		add_action(
			'wp_enqueue_scripts',
			array( self::class, 'maybe_enqueue_popup_extension_assets' ),
			20
		);

		add_action(
			'wp_enqueue_scripts',
			array( self::class, 'maybe_enqueue_supreme_parallax_extension_assets' ),
			22
		);

		add_action(
			'wp_enqueue_scripts',
			array( self::class, 'maybe_enqueue_image_parallax_extension_assets' ),
			23
		);

		add_action(
			'wp_enqueue_scripts',
			array( self::class, 'maybe_enqueue_tooltip_extension_assets' ),
			24
		);

		add_action(
			'init',
			array( self::class, 'maybe_localize_facebook_script' ),
			120
		);
	}

	/**
	 * Ensure Divi logs `dsm/*` blocks during early/late module detection.
	 *
	 * @param array<int, string> $additional_valid_names Block names.
	 * @return array<int, string>
	 */
	public static function filter_valid_blocks( array $additional_valid_names ): array {
		$slugs = DsmFrontendModuleAssetRegistry::get_all_module_slugs();
		return array_values( array_unique( array_merge( $additional_valid_names, $slugs ) ) );
	}

	/**
	 * Enqueue shared animate.css v3 (`dsm-supreme-animate`) once per request when needed.
	 *
	 * When Divi's Dynamic Assets pipeline already merged `dsm/shared-supreme-animate`, skip.
	 * `$force` still enqueues the WP handle if the pipeline missed it (render-time fallback;
	 * WordPress prints late styles in the footer).
	 *
	 * @param bool $force When true, skip page-level detection (module render fallback).
	 * @return bool True when the handle was enqueued by this call.
	 */
	public static function enqueue_supreme_animate_if_needed( bool $force = false ): bool {
		if ( is_admin() ) {
			return false;
		}
		if ( ! function_exists( 'et_builder_d5_enabled' ) || ! et_builder_d5_enabled() ) {
			return false;
		}
		if ( function_exists( 'et_core_is_fb_enabled' ) && et_core_is_fb_enabled() ) {
			return false;
		}
		if ( ! $force && ! self::page_needs_supreme_animate_css() ) {
			return false;
		}
		if ( DsmFrontendAssetRegistry::should_use_divi_dynamic_assets_pipeline() ) {
			if ( DsmFrontendAssetRegistry::pipeline_registered_asset_key( 'dsm/shared-supreme-animate' ) ) {
				return false;
			}
			if ( ! $force ) {
				return false;
			}
		}
		if ( ! wp_style_is( 'dsm-supreme-animate', 'registered' ) ) {
			return false;
		}
		if ( wp_style_is( 'dsm-supreme-animate', 'enqueued' ) ) {
			return false;
		}

		wp_enqueue_style( 'dsm-supreme-animate' );

		return true;
	}

	/**
	 * Central wp_enqueue path for shared animate.css (Dynamic Assets OFF or Supreme-only split).
	 *
	 * @return void
	 */
	public static function maybe_enqueue_supreme_animate_styles(): void {
		self::enqueue_supreme_animate_if_needed( false );
	}

	/**
	 * Whether the current request needs shared animate.css (v3 `.animated` + effect classes).
	 */
	public static function page_needs_supreme_animate_css(): bool {
		if ( self::merged_detection_includes_block_slug( 'dsm/text-rotator' ) ) {
			return true;
		}
		if ( self::merged_detection_includes_block_slug( 'dsm/image-text-reveal' ) ) {
			return true;
		}
		if ( self::content_suggests_advanced_tabs_animate_from_detection() ) {
			return true;
		}
		if ( self::content_suggests_image_carousel_slideshow_animate_from_detection() ) {
			return true;
		}
		if ( self::content_suggests_popup_animate_from_detection() ) {
			return true;
		}

		return false;
	}

	/**
	 * Content suggests advanced tabs animate from detection.
	 *
	 * @return bool
	 */
	private static function content_suggests_advanced_tabs_animate_from_detection(): bool {
		if (
			! self::merged_detection_includes_block_slug( 'dsm/advanced-tabs' )
			&& ! self::merged_detection_includes_block_slug( 'dsm/advanced-tabs-child' )
		) {
			return false;
		}

		// Pipeline mode leaves merged index fragments empty — scan Divi's DA blob like tooltip/icon gates.
		$fragments = DsmFrontendAssetRegistry::should_use_divi_dynamic_assets_pipeline()
			? self::each_icon_detection_content_blob()
			: iterator_to_array( self::each_merged_detection_content_source(), false );

		foreach ( $fragments as $fragment ) {
			if ( is_string( $fragment ) && self::content_suggests_advanced_tabs_animate( $fragment ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Content suggests image carousel slideshow animate from detection.
	 *
	 * @return bool
	 */
	private static function content_suggests_image_carousel_slideshow_animate_from_detection(): bool {
		if ( ! self::merged_detection_includes_block_slug( 'dsm/image-carousel' ) ) {
			return false;
		}

		foreach ( self::each_merged_detection_content_source() as $fragment ) {
			if ( self::content_suggests_image_carousel_slideshow_animate( $fragment ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Content suggests popup animate from detection.
	 *
	 * @return bool
	 */
	private static function content_suggests_popup_animate_from_detection(): bool {
		if ( ! function_exists( 'dsm_is_supreme_popup_extension_enabled' ) || ! dsm_is_supreme_popup_extension_enabled() ) {
			return false;
		}

		return self::merged_detection_has_popup_trigger();
	}

	/**
	 * Content suggests advanced tabs animate.
	 *
	 * @param string $blob Merged page content.
	 */
	private static function content_suggests_advanced_tabs_animate( string $blob ): bool {
		$has_tabs = self::page_content_suggests_block_name( $blob, 'dsm/advanced-tabs' )
			|| self::page_content_suggests_block_name( $blob, 'dsm/advanced-tabs-child' );
		if ( ! $has_tabs ) {
			return false;
		}

		return self::json_blob_has_non_none_inner_content_value( $blob, 'dsm_content_animation' )
			|| self::json_blob_has_non_none_inner_content_value( $blob, 'dsm_inner_content_animation' );
	}

	/**
	 * Mirror {@see \DiviSupreme\Modules\ImageCarousel} slideshow animate.css gating from stored attrs.
	 *
	 * @param string $blob Merged page content.
	 */
	private static function content_suggests_image_carousel_slideshow_animate( string $blob ): bool {
		if ( ! self::page_content_suggests_block_name( $blob, 'dsm/image-carousel' ) ) {
			return false;
		}

		$slider_type = self::json_blob_inner_content_desktop_value( $blob, 'slider_type', 'carousel' );
		if ( 'slideshow' !== $slider_type ) {
			return false;
		}

		$show_desc = self::json_blob_inner_content_desktop_value( $blob, 'slideshow_show_slide_description', 'off' );

		$anim_pairs = array(
			array( 'slideshow_title_animation', 'fadeInUp' ),
			array( 'slideshow_title_animation_out', 'fadeOutDown' ),
			array( 'slideshow_wrapper_animation_in', 'none' ),
			array( 'slideshow_wrapper_animation_out', 'none' ),
		);

		if ( 'on' === $show_desc ) {
			$anim_pairs[] = array( 'slideshow_description_animation', 'fadeInUp' );
			$anim_pairs[] = array( 'slideshow_description_animation_out', 'fadeOutDown' );
		}

		foreach ( $anim_pairs as $pair ) {
			$value = self::json_blob_inner_content_desktop_value( $blob, (string) $pair[0], (string) $pair[1] );
			if ( '' !== $value && 'none' !== $value ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * True when any stored `innerContent.desktop.value` for `$attr_key` is a real animation name.
	 *
	 * First-match can be `none` from another module on the same page (e.g. Circle Info).
	 *
	 * @param string $blob     Merged page content.
	 * @param string $attr_key Attribute key (e.g. `dsm_content_animation`).
	 */
	private static function json_blob_has_non_none_inner_content_value( string $blob, string $attr_key ): bool {
		if ( '' === $blob || '' === $attr_key ) {
			return false;
		}

		$quoted   = preg_quote( $attr_key, '/' );
		$patterns = array(
			'/"' . $quoted . '"\s*:\s*\{\s*"innerContent"\s*:\s*\{\s*"desktop"\s*:\s*\{\s*"value"\s*:\s*"((?:\\\\.|[^"\\\\])*)"/s',
			'/"' . $quoted . '"\s*:\s*\{[^{}]*(?:\{[^{}]*\}[^{}]*)*"value"\s*:\s*"((?:\\\\.|[^"\\\\])*)"/s',
		);

		foreach ( $patterns as $pattern ) {
			if ( ! preg_match_all( $pattern, $blob, $matches ) || empty( $matches[1] ) ) {
				continue;
			}

			foreach ( $matches[1] as $raw ) {
				$value = stripcslashes( (string) $raw );
				if ( '' !== $value && 'none' !== $value ) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Read a D5 `innerContent.desktop.value` leaf from raw block JSON in merged content.
	 *
	 * @param string $blob     Merged page content.
	 * @param string $attr_key Attribute key (e.g. `slider_type`).
	 * @param string $default  Value when the key is absent from stored JSON.
	 */
	private static function json_blob_inner_content_desktop_value( string $blob, string $attr_key, string $default ): string {
		if ( '' === $blob || '' === $attr_key ) {
			return $default;
		}

		$d5_pattern = '/"'
			. preg_quote( $attr_key, '/' )
			. '"\s*:\s*\{\s*"innerContent"\s*:\s*\{\s*"desktop"\s*:\s*\{\s*"value"\s*:\s*"((?:\\\\.|[^"\\\\])*)"/s';
		if ( preg_match( $d5_pattern, $blob, $matches ) && isset( $matches[1] ) ) {
			return stripcslashes( (string) $matches[1] );
		}

		$pattern = '/"'
			. preg_quote( $attr_key, '/' )
			. '"\s*:\s*\{[^{}]*(?:\{[^{}]*\}[^{}]*)*"value"\s*:\s*"((?:\\\\.|[^"\\\\])*)"/s';
		if ( preg_match( $pattern, $blob, $matches ) && isset( $matches[1] ) ) {
			return stripcslashes( (string) $matches[1] );
		}

		return $default;
	}

	/**
	 * Enqueue module CSS: bundled fallback when Disable Dynamic Assets, or split `frontend.css` per detected block when enabled.
	 *
	 * When Divi misc dynamic assets yield no DSM slugs, still scans merged page content for `dsm/*`
	 * block names so stylesheet coverage matches migrated layouts without loading the giant bundle.
	 *
	 * @return void
	 */
	public static function maybe_enqueue_core_module_styles(): void {
		if ( is_admin() ) {
			return;
		}
		if ( ! function_exists( 'et_builder_d5_enabled' ) || ! et_builder_d5_enabled() ) {
			return;
		}
		if ( function_exists( 'et_core_is_fb_enabled' ) && et_core_is_fb_enabled() ) {
			return;
		}

		// `wp_enqueue_scripts` priority 17 already refreshed CPT URLs. Calling again is a no-op
		// after that, and still registers handles when this enqueue runs without the earlier hook.
		DsmFrontendModuleAssetRegistry::refresh_scoped_frontend_style_handles();
		/**
		 * Force enqueue of the Supreme module bundle (compatibility).
		 *
		 * @param bool $force When true, always enqueue the bundle.
		 */
		if ( apply_filters( 'dsm_frontend_force_enqueue_module_styles', false ) ) {
			if ( wp_style_is( DsmFrontendModuleAssetRegistry::CORE_MODULES_STYLE_HANDLE, 'registered' ) ) {
				wp_enqueue_style( DsmFrontendModuleAssetRegistry::CORE_MODULES_STYLE_HANDLE );
			}
			return;
		}

		if ( ! dsm_supreme_dynamic_assets_enabled() ) {
			if ( ! wp_style_is( DsmFrontendModuleAssetRegistry::CORE_MODULES_STYLE_HANDLE, 'registered' ) ) {
				return;
			}
			if ( wp_style_is( DsmFrontendModuleAssetRegistry::CORE_MODULES_STYLE_HANDLE, 'enqueued' ) ) {
				return;
			}
			wp_enqueue_style( DsmFrontendModuleAssetRegistry::CORE_MODULES_STYLE_HANDLE );
			if ( wp_style_is( DsmFrontendModuleAssetRegistry::EXTENSION_POPUP_STYLE_HANDLE, 'registered' ) ) {
				wp_enqueue_style( DsmFrontendModuleAssetRegistry::EXTENSION_POPUP_STYLE_HANDLE );
			}
			return;
		}

		if ( DsmFrontendAssetRegistry::should_skip_central_wp_enqueue() ) {
			return;
		}

		/**
		 * Dynamic assets ON (central wp_enqueue split path): per-module split CSS only — no monolithic bundle (unless filtered above).
		 */
		$slugs = self::collect_dsm_block_slugs_for_split_frontend_styles();
		if ( array() === $slugs && self::merged_page_content_has_dsm_reference() ) {
			if ( wp_style_is( DsmFrontendModuleAssetRegistry::CORE_MODULES_STYLE_HANDLE, 'registered' ) ) {
				wp_enqueue_style( DsmFrontendModuleAssetRegistry::CORE_MODULES_STYLE_HANDLE );
			}
			if ( wp_style_is( DsmFrontendModuleAssetRegistry::EXTENSION_POPUP_STYLE_HANDLE, 'registered' ) ) {
				wp_enqueue_style( DsmFrontendModuleAssetRegistry::EXTENSION_POPUP_STYLE_HANDLE );
			}
			return;
		}
		DsmFrontendAssetRegistry::enqueue_wp_styles_for_block_slugs( $slugs );
	}

	/**
	 * Enqueue frontend scripts/styles for detected `dsm/*` modules via registry (central wp_enqueue split path).
	 *
	 * @return void
	 */
	public static function maybe_enqueue_detected_module_scripts(): void {
		if ( is_admin() ) {
			return;
		}
		if ( ! function_exists( 'et_builder_d5_enabled' ) || ! et_builder_d5_enabled() ) {
			return;
		}
		if ( function_exists( 'et_core_is_fb_enabled' ) && et_core_is_fb_enabled() ) {
			return;
		}

		$slugs = self::collect_dsm_block_slugs_for_split_frontend_styles();

		if ( function_exists( 'dsm_supreme_dynamic_assets_enabled' ) && dsm_supreme_dynamic_assets_enabled() ) {
			if ( DsmFrontendAssetRegistry::should_use_central_wp_enqueue() ) {
				DsmFrontendAssetRegistry::enqueue_wp_scripts_for_block_slugs( $slugs );
			} elseif ( DsmFrontendAssetRegistry::should_use_divi_dynamic_assets_pipeline() ) {
				// Divi merges CSS via global list; scripts must still wp_enqueue.
				DsmFrontendAssetRegistry::enqueue_wp_scripts_for_detected_blocks( $slugs );
			}
		} else {
			// Dynamic Assets OFF: monolithic CSS loads centrally; layout JS for detected blocks still required.
			DsmFrontendAssetRegistry::enqueue_wp_scripts_for_block_slugs_when_dynamic_assets_off( $slugs );
		}

		// Extensions (Custom Cursor, parallax, popup JS, …) — scripts always; CSS via pipeline or rows above.
		DsmFrontendAssetRegistry::enqueue_present_extension_assets();
	}

	/**
	 * Detect a `dsm/*` block in raw post / merged content (block JSON or HTML block comments).
	 *
	 * Stored layouts list blocks as `<!-- wp:dsm/foo ... -->` / `<!-- /wp:dsm/foo -->`, not as `"dsm/foo"` only.
	 * Requiring the JSON-quoted form misses most front-end pages and yields empty split-CSS slug lists.
	 *
	 * @param string $blob         Merged content.
	 * @param string $block_name   Full block name (e.g. `dsm/card`).
	 * @return bool
	 */
	public static function page_content_suggests_block_name( string $blob, string $block_name ): bool {
		if ( '' === $blob || '' === $block_name || ! str_starts_with( $block_name, 'dsm/' ) ) {
			return false;
		}

		if ( str_contains( $blob, '"' . $block_name . '"' ) ) {
			return true;
		}

		$needle = 'wp:' . $block_name;
		$len    = strlen( $needle );
		$offset = 0;

		while ( true ) {
			$pos = strpos( $blob, $needle, $offset );
			if ( false === $pos ) {
				return false;
			}

			$after = $blob[ $pos + $len ] ?? '';
			if ( '' === $after ) {
				return true;
			}

			$ord = ord( $after );
			if ( $ord <= 32 || in_array( $after, array( '/', '>' ), true ) ) {
				return true;
			}

			$offset = $pos + 1;
		}
	}

	/**
	 * Collect `dsm/*` block slugs by walking parsed blocks (preferred over substring scans).
	 *
	 * @param string $content Post / layout block content.
	 * @return list<string>
	 */
	public static function collect_dsm_block_slugs_from_parsed_content( string $content ): array {
		if ( '' === $content || ! str_contains( $content, 'dsm/' ) ) {
			return array();
		}

		$blocks = self::safe_parse_blocks( $content );
		if ( empty( $blocks ) ) {
			return array();
		}

		$slugs = array();
		self::walk_blocks_collect_dsm_block_slugs( $blocks, $slugs );

		return array_values( array_unique( $slugs ) );
	}

	/**
	 * Walk blocks collect dsm block slugs.
	 *
	 * @param array<int, mixed> $blocks Parsed blocks.
	 * @param array             $slugs Collected block names (by ref).
	 * @return void
	 */
	private static function walk_blocks_collect_dsm_block_slugs( array $blocks, array &$slugs ): void {
		foreach ( $blocks as $block ) {
			if ( ! is_array( $block ) ) {
				continue;
			}

			$name = $block['blockName'] ?? '';
			if ( is_string( $name ) && str_starts_with( $name, 'dsm/' ) ) {
				$slugs[] = $name;
			}

			$inner = $block['innerBlocks'] ?? array();
			if ( is_array( $inner ) && array() !== $inner ) {
				self::walk_blocks_collect_dsm_block_slugs( $inner, $slugs );
			}
		}
	}

	/**
	 * Collect `dsm/*` block slugs suggested by raw block / shortcode content.
	 *
	 * @param string $blob Post content, library layout body, or merged detection string.
	 * @return list<string>
	 */
	public static function collect_dsm_block_slugs_from_content( string $blob ): array {
		if ( '' === $blob ) {
			return array();
		}

		$parsed = self::collect_dsm_block_slugs_from_parsed_content( $blob );
		if ( array() !== $parsed ) {
			return $parsed;
		}

		$slugs = array();
		foreach ( DsmFrontendModuleAssetRegistry::get_all_module_slugs() as $candidate ) {
			if ( ! is_string( $candidate ) || ! str_starts_with( $candidate, 'dsm/' ) ) {
				continue;
			}

			if ( self::page_content_suggests_block_name( $blob, $candidate ) ) {
				$slugs[] = $candidate;
			}
		}

		return array_values( array_unique( $slugs ) );
	}

	/**
	 * Enqueue Supreme frontend assets for modules inside a rendered Divi Library layout.
	 *
	 * Fallback when nested modules render programmatically (cached HTML, late discovery, builder partials).
	 * Early detection via {@see get_merged_detection_block_slugs()} remains the primary path.
	 *
	 * @param \WP_Post $layout_post Library layout post (`et_pb_layout`).
	 * @return void
	 */
	public static function enqueue_assets_for_library_layout( \WP_Post $layout_post ): void {
		if ( ! class_exists( DsmFrontendAssetRegistry::class ) ) {
			return;
		}

		$post_content = isset( $layout_post->post_content ) ? (string) $layout_post->post_content : '';
		if ( '' === $post_content ) {
			return;
		}

		$fragments = array( $post_content );
		if ( class_exists( \DSM_Dynamic_Assets_Library_Supplement::class )
			&& \DSM_Dynamic_Assets_Library_Supplement::has_supplement_builders() ) {
			$nested_ids = \DSM_Dynamic_Assets_Library_Supplement::collect_supplement_layout_ids_for_content( $post_content );
			$fragments  = array_merge(
				$fragments,
				\DSM_Dynamic_Assets_Library_Supplement::fetch_layout_post_content_strings_for_ids( $nested_ids )
			);
		}

		$slugs = array();
		foreach ( $fragments as $fragment ) {
			foreach ( self::collect_dsm_block_slugs_from_content( $fragment ) as $slug ) {
				$slugs[ $slug ] = true;
			}
		}

		if ( array() === $slugs ) {
			return;
		}

		DsmFrontendAssetRegistry::enqueue_render_time_assets_for_block_slugs( array_keys( $slugs ) );
	}

	/**
	 * Merge DSM block names from Divi detection with a conservative serialized-content substring pass.
	 *
	 * Filterable list of `dsm/*` identifiers only.
	 *
	 * @return list<string>
	 */
	private static function collect_dsm_block_slugs_for_split_frontend_styles(): array {
		$detection = array();
		foreach ( self::get_merged_detection_module_slugs() as $slug ) {
			if ( is_string( $slug ) && str_starts_with( $slug, 'dsm/' ) ) {
				$detection[] = $slug;
			}
		}

		$content_based = array();
		if ( ! DsmFrontendAssetRegistry::should_use_divi_dynamic_assets_pipeline() ) {
			$content_based = self::get_merged_detection_block_slugs();
		}

		$merged = array_values( array_unique( array_merge( $detection, $content_based ) ) );
		$blob   = DsmFrontendAssetRegistry::should_use_divi_dynamic_assets_pipeline()
			? DsmFrontendAssetRegistry::get_da_all_content_for_pattern_scan()
			: self::get_merged_page_content_string();

		/**
		 * Filter block slugs that receive split `frontend.css` enqueue when Miscellaneous → Dynamic Assets is ON.
		 *
		 * @param list<string> $merged      Block names such as `dsm/card`.
		 * @param string       $blob       Merged post + retriever + popup-derived content snippet.
		 * @param array        $detection  Slugs from Divi DynamicAssets detector (early/processed/all).
		 */
		$filtered = apply_filters( 'dsm_frontend_per_module_styles_block_slugs', $merged, $blob, $detection );
		if ( ! is_array( $filtered ) ) {
			return $merged;
		}

		return array_values(
			array_unique(
				array_values(
					array_filter(
						array_map( 'strval', $filtered ),
						static function ( string $s ): bool {
							return str_starts_with( $s, 'dsm/' );
						}
					)
				)
			)
		);
	}

	/**
	 * For each DSM block slug, enqueue `dsm-frontend-*` stylesheet if built under `packages/module-library/{folder}/frontend.css`.
	 *
	 * @param array $block_slugs Block `name` values (e.g. `dsm/card`).
	 * @return void
	 */
	private static function enqueue_split_frontend_stylesheets_for_blocks( array $block_slugs ): void {
		$block_slugs = array_values(
			array_unique(
				array_filter(
					array_map( 'strval', $block_slugs ),
					static function ( string $s ): bool {
						return '' !== $s && str_starts_with( $s, 'dsm/' );
					}
				)
			)
		);

		if ( array() === $block_slugs ) {
			return;
		}

		$folder_map = DsmFrontendModuleAssetRegistry::get_block_name_to_library_folder_map();

		foreach ( $block_slugs as $slug ) {
			if ( '' === $slug ) {
				continue;
			}

			$folder = $folder_map[ $slug ] ?? '';

			if ( '' === $folder ) {
				continue;
			}

			$handle = DsmFrontendModuleAssetRegistry::frontend_style_handle_for_library_folder( $folder );

			if ( wp_style_is( $handle, 'registered' ) ) {
				wp_enqueue_style( $handle );
			}
		}
	}

	/**
	 * Enqueue popup extension CSS + `dsm-popup-extension` + Magnific when Advanced → Popup is used on any block.
	 *
	 * Without this, assets only run from {@see \DiviSupreme\Extensions\Popup::render_popup()} during
	 * `render_block`. On pages with no `dsm/*` modules, detection/enqueue ordering can leave the popup
	 * stack unloaded even though native Divi blocks carry `use_popup` attrs.
	 *
	 * @return void
	 */
	public static function maybe_enqueue_popup_extension_assets(): void {
		if ( DsmFrontendAssetRegistry::should_use_divi_dynamic_assets_pipeline() ) {
			return;
		}
		if ( ! dsm_is_supreme_popup_extension_enabled() ) {
			return;
		}
		if ( is_admin() ) {
			return;
		}
		if ( ! function_exists( 'et_builder_d5_enabled' ) || ! et_builder_d5_enabled() ) {
			return;
		}
		if ( function_exists( 'et_core_is_fb_enabled' ) && et_core_is_fb_enabled() ) {
			return;
		}

		$style_handle  = DsmFrontendModuleAssetRegistry::EXTENSION_POPUP_STYLE_HANDLE;
		$script_handle = DsmFrontendModuleAssetRegistry::EXTENSION_POPUP_SCRIPT_HANDLE;

		if ( ! wp_style_is( $style_handle, 'registered' ) || ! wp_script_is( $script_handle, 'registered' ) ) {
			return;
		}
		if ( wp_script_is( $script_handle, 'enqueued' ) ) {
			return;
		}

		/**
		 * Force enqueue of popup extension + Magnific (compatibility).
		 *
		 * @param bool $force When true, always enqueue.
		 */
		if ( apply_filters( 'dsm_frontend_force_enqueue_popup_assets', false ) ) {
			self::enqueue_popup_extension_bundle();
			self::enqueue_divi_structure_for_footer_popups();

			return;
		}

		if ( self::should_load_popup_assets_for_detection() ) {
			self::enqueue_popup_extension_bundle();
			self::enqueue_divi_structure_for_footer_popups();
		}
	}

	/**
	 * Enqueue Supreme Parallax frontend script when serialized layout references Supreme Parallax attrs.
	 *
	 * Native Divi blocks do not emit `dsm/*` slugs; scanning merged content parallels the popup-extension pattern.
	 *
	 * @return void
	 */
	public static function maybe_enqueue_supreme_parallax_extension_assets(): void {
		if ( DsmFrontendAssetRegistry::should_use_divi_dynamic_assets_pipeline() ) {
			return;
		}
		if (
			! function_exists( 'dsm_is_supreme_parallax_extension_enabled' )
			|| ! dsm_is_supreme_parallax_extension_enabled()
		) {
			return;
		}
		if ( is_admin() ) {
			return;
		}
		if ( ! function_exists( 'et_builder_d5_enabled' ) || ! et_builder_d5_enabled() ) {
			return;
		}
		if ( function_exists( 'et_core_is_fb_enabled' ) && et_core_is_fb_enabled() ) {
			return;
		}

		$handle = 'dsm-supreme-parallax-frontend';

		if ( ! wp_script_is( $handle, 'registered' )
			|| wp_script_is( $handle, 'enqueued' ) ) {
			return;
		}

		if ( apply_filters( 'dsm_frontend_force_enqueue_supreme_parallax_assets', false ) ) {
			wp_enqueue_script( $handle );
			return;
		}

		if (
			! self::merged_detection_content_contains( 'dsm_spx_' )
		) {
			return;
		}

		wp_enqueue_script( $handle );
	}

	/**
	 * Enqueue Image Parallax frontend script when layout contains enabled image markers.
	 *
	 * @return void
	 */
	public static function maybe_enqueue_image_parallax_extension_assets(): void {
		if ( DsmFrontendAssetRegistry::should_use_divi_dynamic_assets_pipeline() ) {
			return;
		}
		if (
			! function_exists( 'dsm_is_image_parallax_extension_enabled' )
			|| ! dsm_is_image_parallax_extension_enabled()
		) {
			return;
		}
		if ( is_admin() ) {
			return;
		}
		if ( ! function_exists( 'et_builder_d5_enabled' ) || ! et_builder_d5_enabled() ) {
			return;
		}
		if ( function_exists( 'et_core_is_fb_enabled' ) && et_core_is_fb_enabled() ) {
			return;
		}

		$handle = 'dsm-image-parallax-frontend';

		if ( ! wp_script_is( $handle, 'registered' )
			|| wp_script_is( $handle, 'enqueued' ) ) {
			return;
		}

		if ( apply_filters( 'dsm_frontend_force_enqueue_image_parallax_assets', false ) ) {
			wp_enqueue_script( $handle );
			return;
		}

		if (
			! self::merged_detection_content_contains( 'data-dsm-ipx-on' )
			&& ! self::merged_detection_content_contains( '"dsm_ipx_' )
		) {
			return;
		}

		wp_enqueue_script( $handle );

		if ( wp_style_is( 'dsm-image-parallax-frontend', 'registered' )
			&& ! wp_style_is( 'dsm-image-parallax-frontend', 'enqueued' ) ) {
			wp_enqueue_style( 'dsm-image-parallax-frontend' );
		}
	}

	/**
	 * Enqueue Tooltip frontend script when layout contains an enabled tooltip.
	 *
	 * @return void
	 */
	public static function maybe_enqueue_tooltip_extension_assets(): void {
		if ( DsmFrontendAssetRegistry::should_use_divi_dynamic_assets_pipeline() ) {
			return;
		}
		if (
			! function_exists( 'dsm_is_tooltip_extension_enabled' )
			|| ! dsm_is_tooltip_extension_enabled()
		) {
			return;
		}
		if ( is_admin() ) {
			return;
		}
		if ( ! function_exists( 'et_builder_d5_enabled' ) || ! et_builder_d5_enabled() ) {
			return;
		}
		if ( function_exists( 'et_core_is_fb_enabled' ) && et_core_is_fb_enabled() ) {
			return;
		}

		$handle = 'dsm-tooltip-frontend';

		if ( ! wp_script_is( $handle, 'registered' )
			|| wp_script_is( $handle, 'enqueued' ) ) {
			return;
		}

		if ( apply_filters( 'dsm_frontend_force_enqueue_tooltip_assets', false ) ) {
			wp_enqueue_script( $handle );
			if ( wp_style_is( 'dsm-tooltip-frontend', 'registered' )
				&& ! wp_style_is( 'dsm-tooltip-frontend', 'enqueued' ) ) {
				wp_enqueue_style( 'dsm-tooltip-frontend' );
			}
			return;
		}

		if ( ! self::merged_detection_has_enabled_tooltip() ) {
			return;
		}

		wp_enqueue_script( $handle );

		if ( wp_style_is( 'dsm-tooltip-frontend', 'registered' )
			&& ! wp_style_is( 'dsm-tooltip-frontend', 'enqueued' ) ) {
			wp_enqueue_style( 'dsm-tooltip-frontend' );
		}
	}

	/**
	 * Loads Divi's block-row/grid CSS for popup library layouts injected outside normal page scanning.
	 *
	 * WooCommerce/footer popups are not merged into scanned post_content, so Divi never attaches
	 * `dynamic-assets/.../row.css`, `block_row.css`, or gutters — floats/clearfixes break (.et_block_row).
	 *
	 * Runs for both DA ON and OFF: popup library bodies sit outside Divi's page scan; the fallback
	 * injects those packs scoped under `.dsm-popup` (never as global `<link>`s) so Theme Builder
	 * headers are not affected by Divi row/flex/grid rules.
	 *
	 * @return void
	 */
	public static function maybe_enqueue_divi_structure_for_footer_popups(): void {
		if ( ! dsm_is_supreme_popup_extension_enabled() ) {
			return;
		}
		if ( is_admin() ) {
			return;
		}
		if ( ! function_exists( 'et_builder_d5_enabled' ) || ! et_builder_d5_enabled() ) {
			return;
		}
		if ( function_exists( 'et_core_is_fb_enabled' ) && et_core_is_fb_enabled() ) {
			return;
		}

		self::enqueue_divi_structure_for_footer_popups();
	}

	/**
	 * Loads the same handles as {@see \DiviSupreme\Extensions\Popup::render_popup()} for scripts/styles.
	 *
	 * @return void
	 */
	private static function enqueue_popup_extension_bundle(): void {
		wp_enqueue_style( DsmFrontendModuleAssetRegistry::EXTENSION_POPUP_STYLE_HANDLE );

		if ( function_exists( 'dsm_enqueue_magnific_popup_assets' ) ) {
			dsm_enqueue_magnific_popup_assets();
		}

		wp_enqueue_script( DsmFrontendModuleAssetRegistry::EXTENSION_POPUP_SCRIPT_HANDLE );
	}

	/**
	 * Popup extension scripts/CSS + WooCommerce/footer popups.
	 *
	 * @return bool
	 */
	private static function should_load_popup_assets_for_detection(): bool {
		if ( isset( $GLOBALS['dsm_popup_extension'] ) && is_object( $GLOBALS['dsm_popup_extension'] ) ) {
			$popup_ext = $GLOBALS['dsm_popup_extension'];
			if ( method_exists( $popup_ext, 'has_woocommerce_footer_popup_for_current_request' )
				&& $popup_ext->has_woocommerce_footer_popup_for_current_request()
			) {
				return true;
			}
		}

		return self::merged_detection_has_popup_trigger();
	}

	/**
	 * Registers Divi core structure + common module CSS fragments for scanned popup markup.
	 *
	 * @return void
	 */
	private static function enqueue_divi_structure_for_footer_popups(): void {
		if ( self::$queued_divi_popup_structure_styles ) {
			return;
		}

		/**
		 * Opt out of enqueueing Divi structure assets for injected popups.
		 *
		 * @param bool   $enqueue True to enqueue.
		 * @param string $merged  Legacy merged content string for filter consumers (lazy-built).
		 */
		if ( false === apply_filters( 'dsm_frontend_enqueue_divi_popup_structure_assets', true, self::get_merged_page_content_string() ) ) {
			self::$queued_divi_popup_structure_styles = true;

			return;
		}

		$want = isset( $GLOBALS['dsm_popup_extension'] ) && is_object( $GLOBALS['dsm_popup_extension'] )
			&& method_exists( $GLOBALS['dsm_popup_extension'], 'has_woocommerce_footer_popup_for_current_request' )
			&& $GLOBALS['dsm_popup_extension']->has_woocommerce_footer_popup_for_current_request();

		if ( ! $want && ! self::current_request_has_active_popup() ) {
			return;
		}

		if ( ! class_exists( DynamicAssetsUtils::class ) ) {
			return;
		}

		self::queue_divi_dynamic_asset_stylesheets();
		self::$queued_divi_popup_structure_styles = true;
	}

	/**
	 * Popup DOM root used to scope Divi structure CSS so Theme Builder headers are unaffected.
	 *
	 * Markup is `#dsm-popup-{id}.dsm-popup` (closed in footer) and remains `.dsm-popup` inside
	 * `.mfp-content` when Magnific opens the modal.
	 */
	private const POPUP_DIVI_STRUCTURE_CSS_SCOPE = '.dsm-popup';

	/**
	 * Style handle for popup-scoped Divi structure CSS (inline; never global Divi pack links).
	 */
	private const POPUP_DIVI_STRUCTURE_STYLE_HANDLE = 'dsm-popup-divi-structure-scoped';

	/**
	 * Loads Divi structure + button packs for popup markup only.
	 *
	 * Reads Divi's dynamic-asset CSS files and scopes every selector under `.dsm-popup` via
	 * {@see DsmCssPreviewScope}. Global `<link>` enqueues of `flex_grid` / `row` / `block_row`
	 * break Theme Builder headers (e.g. `.et_pb_row { max-width: 1080px }`).
	 *
	 * Always uses the unprefixed Divi packs (not `*_cpt.css`): popup HTML is nested under
	 * `.dsm-popup` and does not reliably include Divi's full `.et-db #et-boc .et-l` chain.
	 *
	 * @return void
	 */
	private static function queue_divi_dynamic_asset_stylesheets(): void {
		if ( wp_style_is( self::POPUP_DIVI_STRUCTURE_STYLE_HANDLE, 'enqueued' ) ) {
			return;
		}

		$scoped_css = self::build_popup_scoped_divi_structure_css();

		if ( '' === $scoped_css ) {
			return;
		}

		$version = function_exists( 'et_get_theme_version' ) ? et_get_theme_version() : null;

		wp_register_style( self::POPUP_DIVI_STRUCTURE_STYLE_HANDLE, false, array(), $version );
		wp_enqueue_style( self::POPUP_DIVI_STRUCTURE_STYLE_HANDLE );
		wp_add_inline_style( self::POPUP_DIVI_STRUCTURE_STYLE_HANDLE, $scoped_css );
	}

	/**
	 * Build popup-scoped Divi structure CSS from on-disk dynamic-asset files.
	 *
	 * @return string Empty when no readable packs were found.
	 */
	private static function build_popup_scoped_divi_structure_css(): string {
		$base_uri  = DynamicAssetsUtils::get_dynamic_assets_path( true );
		$gutter_rt = is_rtl() ? '-rtl' : '';
		$gutter_n  = self::infer_gutter_width_for_popup_context();

		/**
		 * Relative paths under Divi's dynamic-assets CSS directory.
		 * Unprefixed packs only — scoped under `.dsm-popup` instead of Divi's CPT selector wrapper.
		 *
		 * Include `contact_form.css` whenever popup structure CSS is built (active popup only).
		 * Scoped `flex_grid.css` becomes `.dsm-popup .et_flex_module { --flex-direction: column }`,
		 * which beats unscoped `.et_pb_contact_form:not(.et_block_module) { --flex-direction: row }`
		 * and stacks Name/Email. Scoping the contact-form pack restores the field row.
		 *
		 * Desktop `flex_grid.css` has no `_*_phone` / `_*_tablet` width rules. Those live in
		 * `flex_grid_{phone,phonewide,tablet,tabletwide,widescreen,ultrawide}.css`. Without
		 * them, library classes like `et_flex_column_24_24_phone` never apply and popup rows
		 * stay 2-col on phone. Unprefixed packs only — not `*_cpt.css`.
		 *
		 * Max-width packs MUST be largest breakpoint first, phone last. All of
		 * `.dsm-popup .et_flex_column_*_{tablet,phoneWide,phone}` share the same specificity.
		 * A phone viewport also matches `max-width: 980px` (tablet 50%). If tablet comes after
		 * phone, tablet wins and the Library phone stack never applies.
		 *
		 * @var array<int, string>
		 */
		$relatives = array(
			'css/flex_grid.css',
			'css/flex_grid_widescreen.css',
			'css/flex_grid_ultrawide.css',
			'css/flex_grid_tabletwide.css',
			'css/flex_grid_tablet.css',
			'css/flex_grid_phonewide.css',
			'css/flex_grid_phone.css',
			'css/section.css',
			'css/row.css',
			'css/block_row.css',
			'css/gutters' . $gutter_n . $gutter_rt . '.css',
			'css/text.css',
			'css/buttons.css',
			'css/button.css',
			'css/contact_form.css',
		);

		/**
		 * Filter which Divi dynamic-asset CSS files are scoped into popup markup.
		 *
		 * @param array<int, string> $relatives Paths relative to Divi's dynamic-assets root.
		 */
		$relatives = apply_filters( 'dsm_frontend_popup_divi_structure_css_files', $relatives );

		if ( ! is_array( $relatives ) ) {
			return '';
		}

		$chunks = array();

		foreach ( $relatives as $relative ) {
			if ( ! is_string( $relative ) || '' === $relative ) {
				continue;
			}

			$url  = $base_uri . '/' . ltrim( $relative, '/' );
			$path = self::divi_dynamic_asset_uri_to_path( $url );

			if ( null === $path || ! is_readable( $path ) ) {
				continue;
			}

			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- local theme asset.
			$css = file_get_contents( $path );

			if ( ! is_string( $css ) || '' === trim( $css ) ) {
				continue;
			}

			$chunks[] = self::scope_divi_structure_css_for_popup( $css );
		}

		$combined = trim( implode( "\n", array_filter( $chunks ) ) );

		/**
		 * Filter the final popup-scoped Divi structure CSS before inline enqueue.
		 *
		 * @param string $combined Scoped CSS.
		 */
		$filtered = apply_filters( 'dsm_frontend_popup_divi_structure_scoped_css', $combined );

		return is_string( $filtered ) ? $filtered : $combined;
	}

	/**
	 * Scope a Divi dynamic-asset stylesheet so it only matches popup markup.
	 *
	 * `:root` / `html` / `body` variable roots are remapped onto `.dsm-popup` so flex/row
	 * custom properties still resolve inside the modal.
	 *
	 * @param string $css Raw Divi CSS.
	 * @return string
	 */
	private static function scope_divi_structure_css_for_popup( string $css ): string {
		$scope = self::POPUP_DIVI_STRUCTURE_CSS_SCOPE;

		/**
		 * Root selector used when scoping popup Divi structure CSS.
		 *
		 * @param string $scope Default `.dsm-popup`.
		 */
		$filtered_scope = apply_filters( 'dsm_frontend_popup_divi_structure_css_scope', $scope );
		$scope          = is_string( $filtered_scope ) && '' !== trim( $filtered_scope )
			? trim( $filtered_scope )
			: self::POPUP_DIVI_STRUCTURE_CSS_SCOPE;

		// Placeholder so DsmCssPreviewScope does not turn `:root` into `.dsm-popup :root`.
		$root_token = '.__dsm_popup_css_root__';
		$css        = (string) preg_replace(
			'/(^|[,\\s}])(\\s*)(?::root|html|body)\\b/i',
			'$1$2' . $root_token,
			$css
		);

		$scoped = DsmCssPreviewScope::apply( $css, $scope );
		$scoped = str_replace( $scope . ' ' . $root_token, $scope, $scoped );
		$scoped = str_replace( $root_token, $scope, $scoped );
		$scoped = self::demote_popup_flex_layout_defaults( $scoped, $scope );

		return $scoped;
	}

	/**
	 * Let a layout's own flex rules beat popup structure defaults.
	 *
	 * Scoped `flex_grid.css` is `.dsm-popup .et_flex_row { --flex-direction: row }` and
	 * `.dsm-popup .et_flex_group { --horizontal-gap: var(--module-gutter) }` (two classes).
	 * Divi prints Layout Direction and gap on `.et_pb_row_N` / `.et_pb_group_N` (one class),
	 * including inside `@media (max-width: 980px)` and `@media (max-width: 767px)`. The
	 * two-class default wins at every breakpoint, so phone/tablet stay on the desktop
	 * direction, and a group sized for an 8px gap (`width: calc(50% - 4px)`) wraps to one
	 * item per row when the popup forces the 30px module gutter.
	 *
	 * Those defaults are reprinted at zero specificity with `:where()`. `flex-direction: var(--flex-direction)`
	 * and `column-gap: var(--horizontal-gap)` stay on the two-class rule so they still read
	 * the variables. Contact-form rules are left alone: they must keep beating
	 * `.et_flex_module { --flex-direction: column }`.
	 *
	 * @param string $css   Popup-scoped CSS.
	 * @param string $scope Popup scope selector.
	 * @return string
	 */
	private static function demote_popup_flex_layout_defaults( string $css, string $scope ): string {
		if ( '' === $css || ! str_contains( $css, '--flex-direction' ) ) {
			return $css;
		}

		$demote = array(
			'--flex-direction',
			'--horizontal-gap',
			'--vertical-gap',
			'align-items',
			'justify-content',
			'align-content',
			'flex-wrap',
		);

		$updated = preg_replace_callback(
			'/([^{}@]+)\{([^{}]*)\}/',
			static function ( array $rule ) use ( $scope, $demote ): string {
				$selector = $rule[1];
				$body     = $rule[2];

				if ( ! str_contains( $selector, $scope ) || ! str_contains( $selector, 'et_flex_' ) ) {
					return $rule[0];
				}

				if ( str_contains( $selector, 'et_pb_contact_form' ) ) {
					return $rule[0];
				}

				$kept   = array();
				$moved  = array();
				$pieces = explode( ';', $body );

				foreach ( $pieces as $piece ) {
					$decl = trim( $piece );

					if ( '' === $decl ) {
						continue;
					}

					$colon = strpos( $decl, ':' );

					if ( false === $colon ) {
						$kept[] = $decl;
						continue;
					}

					$property = strtolower( trim( substr( $decl, 0, $colon ) ) );

					if ( in_array( $property, $demote, true ) ) {
						$moved[] = $decl;
						continue;
					}

					$kept[] = $decl;
				}

				if ( array() === $moved ) {
					return $rule[0];
				}

				$where = ':where(' . trim( $selector ) . ')';
				$out   = $where . '{' . implode( ';', $moved ) . '}';

				if ( array() !== $kept ) {
					$out .= trim( $selector ) . '{' . implode( ';', $kept ) . '}';
				}

				return $out;
			},
			$css
		);

		return is_string( $updated ) ? $updated : $css;
	}

	/**
	 * Map a Divi dynamic-asset URI to an absolute filesystem path when under the active theme.
	 *
	 * @param string $asset_uri Public URI.
	 * @return string|null Absolute path, or null when not mappable.
	 */
	private static function divi_dynamic_asset_uri_to_path( string $asset_uri ): ?string {
		$template_uri = get_template_directory_uri();
		$template_dir = get_template_directory();

		if ( ! str_starts_with( $asset_uri, $template_uri ) ) {
			return null;
		}

		$relative = ltrim( substr( $asset_uri, strlen( $template_uri ) ), '/' );
		$path     = $template_dir . '/' . $relative;

		return is_readable( $path ) ? $path : null;
	}

	/**
	 * Fallback gutter for {@see queue_divi_dynamic_asset_stylesheets()} when no layout stores `_et_pb_gutter_width`.
	 * WooCommerce templates often ship with theme gutter 3; library popups are commonly gutter 1.
	 *
	 * @return int Integer 1–4.
	 */
	private static function default_divi_popup_gutter_width(): int {
		$fallback = ( function_exists( 'is_woocommerce' ) && is_woocommerce() ) ? 1 : 3;

		/**
		 * Override inferred default gutter (only used when no popup layout yields `_et_pb_gutter_width`).
		 *
		 * @param int $fallback 1 on WooCommerce frontend, 3 elsewhere.
		 */
		$filtered = (int) apply_filters( 'dsm_frontend_popup_divi_default_gutter_width', $fallback );
		if ( $filtered < 1 || $filtered > 4 ) {
			return $fallback;
		}

		return $filtered;
	}

	/**
	 * Guess gutter width (1–4) from popup library post meta, else {@see default_divi_popup_gutter_width()}.
	 *
	 * @return int
	 */
	private static function infer_gutter_width_for_popup_context(): int {
		$default = self::default_divi_popup_gutter_width();
		$pids    = array();

		if ( isset( $GLOBALS['dsm_popup_extension'] ) && is_object( $GLOBALS['dsm_popup_extension'] ) ) {
			$popup_ext = $GLOBALS['dsm_popup_extension'];
			if ( method_exists( $popup_ext, 'has_woocommerce_footer_popup_for_current_request' )
				&& $popup_ext->has_woocommerce_footer_popup_for_current_request()
				&& method_exists( $popup_ext, 'get_global_popups' )
			) {
				foreach ( $popup_ext->get_global_popups( 'woocommerce' ) as $row ) {
					if ( isset( $row['id'] ) ) {
						$pids[] = (int) $row['id'];
					}
				}
			}
		}

		if ( array() === $pids ) {
			foreach ( self::collect_popup_layout_ids_for_dynamic_assets( self::resolve_base_page_content_string() ) as $lid ) {
				if ( $lid > 0 ) {
					$pids[] = $lid;
				}
			}
		}

		foreach ( $pids as $pid ) {
			if ( $pid <= 0 ) {
				continue;
			}
			$raw = get_post_meta( $pid, '_et_pb_gutter_width', true );
			if ( is_numeric( $raw ) ) {
				$gw = (int) $raw;
				if ( $gw >= 1 && $gw <= 4 ) {
					return $gw;
				}
			}
		}

		return $default;
	}

	/**
	 * Attach Facebook app ID to the registered script when it is actually used (module render enqueues it).
	 *
	 * @return void
	 */
	public static function maybe_localize_facebook_script(): void {
		if ( self::$facebook_localized || ! wp_script_is( 'dsm-facebook', 'registered' ) ) {
			return;
		}
		$settings = get_option( 'dsm_settings_social_media' );
		$app_id   = is_array( $settings ) && isset( $settings['dsm_facebook_app_id'] )
			? (string) $settings['dsm_facebook_app_id']
			: '';
		$data     = array( 'appId' => $app_id );
		wp_localize_script( 'dsm-facebook', 'facebookAppId', $data );
		self::$facebook_localized = true;
	}

	/**
	 * Whether Divi's dynamic assets store already knows about a `dsm/*` module on this request.
	 */
	public static function detection_lists_any_dsm_module(): bool {
		foreach ( self::get_merged_detection_module_slugs() as $slug ) {
			if ( is_string( $slug ) && str_starts_with( $slug, 'dsm/' ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Slugs from Divi DynamicAssets detection state (early + processed + all).
	 *
	 * @return list<string>
	 */
	public static function get_merged_detection_module_slugs(): array {
		if ( ! class_exists( DynamicAssets::class ) ) {
			return array();
		}
		$instance = DynamicAssets::get_instance();
		if ( ! $instance instanceof DynamicAssets ) {
			return array();
		}
		try {
			$ref = new \ReflectionClass( $instance );
			if ( ! $ref->hasProperty( '_store' ) ) {
				return array();
			}
			$prop = $ref->getProperty( '_store' );
			if ( PHP_VERSION_ID < 80100 ) {
				$prop->setAccessible( true );
			}
			$store = $prop->getValue( $instance );
			if ( ! $store instanceof DynamicAssetsStore ) {
				return array();
			}
			$state = $store->detection();
			$merge = array_merge(
				$state->early_modules,
				$state->processed_modules,
				$state->all_modules,
				$state->missed_modules
			);
			$out   = array();
			foreach ( $merge as $item ) {
				if ( is_string( $item ) && '' !== $item ) {
					$out[] = $item;
				}
			}
			return array_values( array_unique( $out ) );
		} catch ( \Throwable $e ) { // phpcs:ignore Generic.CodeAnalysis.EmptyStatement.DetectedCatch
			return array();
		}
	}

	/**
	 * True if any registered icon-dependent Supreme module appears in detection results.
	 */
	public static function detection_needs_divi_icon_stylesheets(): bool {
		$detected = array_fill_keys( self::get_merged_detection_module_slugs(), true );
		foreach ( DsmFrontendModuleAssetRegistry::ICON_DEPENDENT_MODULE_SLUGS as $slug ) {
			if ( isset( $detected[ $slug ] ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Whether the current frontend request needs Divi's ETmodules / FA icon-font CSS.
	 *
	 * @param object|null $list_builder Divi DynamicAssetsListBuilder (global assets filter arg).
	 */
	public static function page_needs_divi_icon_font( $list_builder = null ): bool {
		if ( self::detection_needs_divi_icon_stylesheets() ) {
			return true;
		}

		if ( self::current_request_has_active_popup() ) {
			return true;
		}

		if ( self::da_detected_blocks_suggest_icon_font( $list_builder ) ) {
			return true;
		}

		if ( self::merged_page_content_suggests_icon_modules() ) {
			return true;
		}

		foreach ( self::get_detected_dsm_block_slugs_for_frontend_assets() as $slug ) {
			if ( in_array( $slug, DsmFrontendModuleAssetRegistry::ICON_DEPENDENT_MODULE_SLUGS, true ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * True when Divi DA already-parsed block lists include icon-dependent Supreme or core icon blocks.
	 *
	 * @param object|null $list_builder Divi DynamicAssetsListBuilder.
	 */
	private static function da_detected_blocks_suggest_icon_font( $list_builder = null ): bool {
		if ( ! class_exists( DsmFrontendAssetRegistry::class ) ) {
			return false;
		}

		$icon_slugs = array_fill_keys( DsmFrontendModuleAssetRegistry::ICON_DEPENDENT_MODULE_SLUGS, true );

		foreach ( DsmFrontendAssetRegistry::get_da_detected_block_names( $list_builder ) as $block_name ) {
			if ( ! is_string( $block_name ) || '' === $block_name ) {
				continue;
			}

			if ( isset( $icon_slugs[ $block_name ] ) || 'divi/icon' === $block_name ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Ensure Divi icon-font CSS is merged when Supreme icon modules are present.
	 *
	 * Runs on Divi's global assets filter regardless of Supreme Dynamic Assets setting so
	 * ETmodules @font-face is resolved by DynamicAssets::get_assets_data().
	 *
	 * @param array<string, mixed> $assets_list  Global assets list.
	 * @param array<string, mixed> $assets_args  Divi asset args.
	 * @param object|null          $list_builder List builder instance.
	 * @return array<string, mixed>
	 */
	public static function filter_divi_icon_font_global_assets( array $assets_list, array $assets_args, $list_builder = null ): array {
		if ( class_exists( DsmFrontendAssetRegistry::class ) ) {
			DsmFrontendAssetRegistry::begin_da_filter_context();
		}

		try {
			if ( ! self::page_needs_divi_icon_font( $list_builder ) ) {
				return $assets_list;
			}
		} finally {
			if ( class_exists( DsmFrontendAssetRegistry::class ) ) {
				DsmFrontendAssetRegistry::end_da_filter_context();
			}
		}

		if ( ! class_exists( DsmFrontendAssetRegistry::class ) || ! DsmFrontendAssetRegistry::is_divi_frontend_dynamic_assets_active() ) {
			return $assets_list;
		}

		$prefix = isset( $assets_args['assets_prefix'] ) && is_string( $assets_args['assets_prefix'] ) && '' !== $assets_args['assets_prefix']
			? $assets_args['assets_prefix']
			: '';

		if ( '' === $prefix && function_exists( 'get_template_directory' ) ) {
			$prefix = get_template_directory() . '/includes/builder/feature/dynamic-assets/assets';
		}

		if ( '' === $prefix ) {
			return $assets_list;
		}

		if ( isset( $assets_list['et_icons_base'] ) && ! isset( $assets_list['et_icons_all'] ) ) {
			unset( $assets_list['et_icons_base'] );
		}

		if ( empty( $assets_list['et_icons_all'] ) ) {
			$assets_list['et_icons_all'] = array(
				'css' => $prefix . '/css/icons_all.css',
			);
		}

		if ( empty( $assets_list['et_icons_fa'] ) ) {
			$assets_list['et_icons_fa'] = array(
				'css' => $prefix . '/css/icons_fa_all.css',
			);
		}

		return $assets_list;
	}

	/**
	 * Get detected dsm block slugs for frontend assets.
	 *
	 * @return list<string>
	 */
	public static function get_detected_dsm_block_slugs_for_frontend_assets(): array {
		return self::collect_dsm_block_slugs_for_split_frontend_styles();
	}

	/**
	 * Content scan fallback: main post + Divi content retriever when available.
	 */
	public static function merged_page_content_has_dsm_reference(): bool {
		return array() !== self::get_merged_detection_block_slugs();
	}

	/**
	 * Fallback when detection is cold: icon-dependent module block names appear in raw content.
	 */
	public static function merged_page_content_suggests_icon_modules(): bool {
		foreach ( DsmFrontendModuleAssetRegistry::ICON_DEPENDENT_MODULE_SLUGS as $slug ) {
			if ( self::merged_detection_includes_block_slug( $slug ) ) {
				return true;
			}
		}

		foreach ( self::each_icon_detection_content_blob() as $blob ) {
			foreach ( DsmFrontendModuleAssetRegistry::ICON_DEPENDENT_MODULE_SLUGS as $slug ) {
				if ( self::page_content_suggests_block_name( $blob, $slug ) ) {
					return true;
				}
			}

			foreach ( DsmFrontendModuleAssetRegistry::get_icon_dependent_d4_shortcode_tags() as $shortcode_tag ) {
				if ( str_contains( $blob, '[' . $shortcode_tag ) ) {
					return true;
				}
			}

			if ( str_contains( $blob, 'et_pb_font_icon' ) || self::page_content_suggests_block_name( $blob, 'divi/icon' ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Content blobs for icon presence scans (DA merged content + singular post; no parse_blocks).
	 *
	 * @return list<string>
	 */
	private static function each_icon_detection_content_blob(): array {
		$blobs = array();

		if (
			class_exists( DsmFrontendAssetRegistry::class )
			&& DsmFrontendAssetRegistry::should_use_divi_dynamic_assets_pipeline()
		) {
			$da_blob = DsmFrontendAssetRegistry::get_da_all_content_for_pattern_scan();
			if ( '' !== $da_blob ) {
				$blobs[] = $da_blob;
			}
		}

		$base = self::resolve_base_page_content_string();
		if ( '' !== $base ) {
			$blobs[] = $base;
		} elseif ( function_exists( 'get_post' ) ) {
			$post = get_post();
			if ( $post instanceof \WP_Post && is_string( $post->post_content ) && '' !== $post->post_content ) {
				$blobs[] = $post->post_content;
			}
		}

		return array_values( array_unique( $blobs ) );
	}

	/**
	 * Theme Builder / singular page content for asset scans outside Divi's DA blob (no parse_blocks).
	 *
	 * @return string
	 */
	public static function get_base_page_content_for_detection(): string {
		return self::resolve_base_page_content_string();
	}

	/**
	 * Cached detection index: block slugs + discrete content fragments (no mega-string merge).
	 *
	 * @var array{block_slugs:list<string>,content_fragments:list<string>,base_content:string}|null
	 */
	private static ?array $merged_detection_index_cache = null;

	/**
	 * Post ID the cached detection index belongs to (0 = global / unknown).
	 *
	 * @var int
	 */
	private static int $merged_detection_index_post_id = 0;

	/**
	 * Re-entry guard while building the detection index.
	 *
	 * @var bool
	 */
	private static bool $merged_detection_index_building = false;

	/**
	 * Request cache for legacy {@see get_merged_page_content_string()} callers.
	 *
	 * @var string|null
	 */
	private static ?string $merged_page_content_cache = null;

	/**
	 * Get merged detection block slugs.
	 *
	 * @return list<string> Unique `dsm/*` block slugs present on the page (including nested library layouts).
	 */
	public static function get_merged_detection_block_slugs(): array {
		if ( DsmFrontendAssetRegistry::should_use_divi_dynamic_assets_pipeline() ) {
			$slugs = array();
			foreach ( self::get_merged_detection_module_slugs() as $slug ) {
				if ( is_string( $slug ) && str_starts_with( $slug, 'dsm/' ) ) {
					$slugs[] = $slug;
				}
			}
			return array_values( array_unique( $slugs ) );
		}

		return self::resolve_merged_detection_index()['block_slugs'];
	}

	/**
	 * Get merged detection content fragments.
	 *
	 * @return list<string> Discrete content fragments scanned for detection (page, popups, libraries).
	 */
	public static function get_merged_detection_content_fragments(): array {
		return self::resolve_merged_detection_index()['content_fragments'];
	}

	/**
	 * Merged detection includes block slug.
	 *
	 * @param string $block_name Full block name (e.g. `dsm/masonry-gallery`).
	 * @return bool
	 */
	public static function merged_detection_includes_block_slug( string $block_name ): bool {
		if ( '' === $block_name || ! str_starts_with( $block_name, 'dsm/' ) ) {
			return false;
		}

		return in_array( $block_name, self::get_merged_detection_block_slugs(), true );
	}

	/**
	 * Whether detection fragments include an enabled Tooltip (not merely the `enable_tooltip` key).
	 *
	 * @return bool
	 */
	public static function merged_detection_has_enabled_tooltip(): bool {
		if ( ! function_exists( 'dsm_content_has_enabled_tooltip' ) ) {
			return false;
		}

		if ( DsmFrontendAssetRegistry::should_use_divi_dynamic_assets_pipeline() ) {
			foreach ( self::each_icon_detection_content_blob() as $blob ) {
				if ( dsm_content_has_enabled_tooltip( $blob ) ) {
					return true;
				}
			}

			return false;
		}

		foreach ( self::each_merged_detection_content_source() as $fragment ) {
			if ( dsm_content_has_enabled_tooltip( $fragment ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Whether any detection fragment contains a substring.
	 *
	 * @param string $needle Substring to locate in any detection fragment.
	 * @return bool
	 */
	public static function merged_detection_content_contains( string $needle ): bool {
		if ( '' === $needle ) {
			return false;
		}

		if ( DsmFrontendAssetRegistry::should_use_divi_dynamic_assets_pipeline() ) {
			foreach ( self::each_icon_detection_content_blob() as $blob ) {
				if ( str_contains( $blob, $needle ) ) {
					return true;
				}
			}

			return false;
		}

		foreach ( self::each_merged_detection_content_source() as $fragment ) {
			if ( str_contains( $fragment, $needle ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Whether any detection fragment references a popup trigger.
	 *
	 * @return bool
	 */
	public static function merged_detection_has_popup_trigger(): bool {
		if ( DsmFrontendAssetRegistry::should_use_divi_dynamic_assets_pipeline() ) {
			foreach ( self::each_icon_detection_content_blob() as $blob ) {
				if ( self::content_blob_has_enabled_module_popup( $blob ) ) {
					return true;
				}
			}

			return self::current_request_has_woocommerce_footer_popup()
				|| self::current_request_has_enabled_global_popup();
		}

		foreach ( self::each_merged_detection_content_source() as $fragment ) {
			if ( self::content_has_popup_trigger( $fragment ) ) {
				return true;
			}
		}

		return self::current_request_has_enabled_global_popup();
	}

	/**
	 * Whether serialized content enables Advanced → Popup on a module (D5 `use_popup` on + layout).
	 *
	 * @param string $blob Post content or Divi DA scan blob.
	 * @return bool
	 */
	private static function content_blob_has_enabled_module_popup( string $blob ): bool {
		if ( '' === $blob || ! str_contains( $blob, 'use_popup' ) ) {
			return false;
		}

		if ( array() !== self::collect_popup_layout_ids_regex_fallback( $blob ) ) {
			return true;
		}

		return (bool) preg_match( '/"use_popup"[^}]{0,500}?"value"\s*:\s*"on"/s', $blob )
			&& str_contains( $blob, 'popup_layout' );
	}

	/**
	 * Whether any enabled non-module popup (page load, exit intent, targeted) should run on the frontend.
	 *
	 * @return bool
	 */
	public static function current_request_has_enabled_global_popup(): bool {
		if ( ! function_exists( 'dsm_is_supreme_popup_extension_enabled' ) || ! dsm_is_supreme_popup_extension_enabled() ) {
			return false;
		}

		if ( ! isset( $GLOBALS['dsm_popup_extension'] ) || ! is_object( $GLOBALS['dsm_popup_extension'] ) ) {
			return false;
		}

		$popup_ext = $GLOBALS['dsm_popup_extension'];

		return method_exists( $popup_ext, 'has_enabled_global_popup_for_frontend_request' )
			&& $popup_ext->has_enabled_global_popup_for_frontend_request();
	}

	/**
	 * Resolve merged detection index.
	 *
	 * @return array{block_slugs:list<string>,content_fragments:list<string>,base_content:string}
	 */
	private static function resolve_merged_detection_index(): array {
		$post_id = function_exists( 'get_the_ID' ) ? (int) get_the_ID() : 0;

		if (
			null !== self::$merged_detection_index_cache
			&& self::$merged_detection_index_post_id === $post_id
		) {
			return self::$merged_detection_index_cache;
		}

		if ( self::$merged_detection_index_building ) {
			return array(
				'block_slugs'       => array(),
				'content_fragments' => array(),
				'base_content'      => '',
			);
		}

		// Divi DA pipeline: use detection store only — never parse_blocks here (re-entrancy / memory risk).
		if ( DsmFrontendAssetRegistry::should_use_divi_dynamic_assets_pipeline() ) {
			$slugs = array();
			foreach ( self::get_merged_detection_module_slugs() as $slug ) {
				if ( is_string( $slug ) && str_starts_with( $slug, 'dsm/' ) ) {
					$slugs[] = $slug;
				}
			}
			self::$merged_detection_index_cache   = array(
				'block_slugs'       => array_values( array_unique( $slugs ) ),
				'content_fragments' => array(),
				'base_content'      => '',
			);
			self::$merged_detection_index_post_id = $post_id;
			self::$merged_page_content_cache      = null;

			return self::$merged_detection_index_cache;
		}

		self::$merged_detection_index_building = true;

		$block_slug_map   = array();
		$layout_fragments = array();
		$base             = self::resolve_base_page_content_string();

		if ( '' !== $base ) {
			foreach ( self::collect_dsm_block_slugs_from_content( $base ) as $slug ) {
				$block_slug_map[ $slug ] = true;
			}
		}

		$layout_ids_seen = array();
		$layout_queue    = array();
		$guard           = 0;

		$enqueue_layout_id = static function ( int $layout_id ) use ( &$layout_ids_seen, &$layout_queue ): void {
			if ( $layout_id <= 0 || isset( $layout_ids_seen[ $layout_id ] ) ) {
				return;
			}
			if ( count( $layout_ids_seen ) >= self::MAX_SUPPLEMENT_LAYOUT_IDS ) {
				return;
			}
			$layout_ids_seen[ $layout_id ] = true;
			$layout_queue[]                = $layout_id;
		};

		foreach ( self::collect_popup_layout_ids_for_dynamic_assets( $base ) as $popup_layout_id ) {
			$enqueue_layout_id( (int) $popup_layout_id );
		}

		if ( class_exists( \DSM_Dynamic_Assets_Library_Supplement::class )
			&& \DSM_Dynamic_Assets_Library_Supplement::has_supplement_builders() ) {
			foreach ( \DSM_Dynamic_Assets_Library_Supplement::collect_supplement_layout_ids_for_content(
				$base,
				array( \DSM_Dynamic_Assets_Popup_Library::class )
			) as $library_layout_id ) {
				$enqueue_layout_id( (int) $library_layout_id );
			}
		}

		while ( array() !== $layout_queue && $guard < 100 ) {
			++$guard;
			$layout_id = (int) array_shift( $layout_queue );
			if ( $layout_id <= 0 ) {
				continue;
			}

			$layout_post = get_post( $layout_id );
			if ( ! $layout_post instanceof \WP_Post ) {
				continue;
			}

			$layout_body = isset( $layout_post->post_content ) ? (string) $layout_post->post_content : '';
			if ( '' === $layout_body ) {
				continue;
			}

			if ( class_exists( \DSM_Dynamic_Assets_Library_Supplement::class )
				&& \DSM_Dynamic_Assets_Library_Supplement::has_supplement_builders() ) {
				foreach ( \DSM_Dynamic_Assets_Library_Supplement::collect_supplement_layout_ids_for_content(
					$layout_body,
					array( \DSM_Dynamic_Assets_Popup_Library::class )
				) as $nested_library_id ) {
					$enqueue_layout_id( (int) $nested_library_id );
				}
			}
		}

		if ( class_exists( \DSM_Dynamic_Assets_Library_Supplement::class ) ) {
			foreach ( \DSM_Dynamic_Assets_Library_Supplement::fetch_layout_post_content_strings_for_ids(
				array_map( 'intval', array_keys( $layout_ids_seen ) )
			) as $layout_fragment ) {
				$layout_fragments[] = $layout_fragment;
				foreach ( self::collect_dsm_block_slugs_from_content( $layout_fragment ) as $slug ) {
					$block_slug_map[ $slug ] = true;
				}
			}
		}

		self::$merged_detection_index_cache    = array(
			'block_slugs'       => array_keys( $block_slug_map ),
			'content_fragments' => $layout_fragments,
			'base_content'      => $base,
		);
		self::$merged_detection_index_post_id  = $post_id;
		self::$merged_detection_index_building = false;
		self::$merged_page_content_cache       = null;

		return self::$merged_detection_index_cache;
	}

	/**
	 * Theme Builder retriever output or singular post content (no supplements).
	 *
	 * @return string
	 */
	private static function resolve_base_page_content_string(): string {
		$post_content = '';
		if ( function_exists( 'get_post' ) ) {
			$post = get_post();
			if ( $post instanceof \WP_Post && is_string( $post->post_content ) ) {
				$post_content = $post->post_content;
			}
		}

		$entire_page_content = '';
		if ( class_exists( \Feature\ContentRetriever\ET_Builder_Content_Retriever::class ) ) {
			$retriever = \Feature\ContentRetriever\ET_Builder_Content_Retriever::init();
			$post_id   = function_exists( 'get_the_ID' ) ? (int) get_the_ID() : 0;
			if ( is_object( $retriever ) && method_exists( $retriever, 'get_entire_page_content' ) && $post_id > 0 ) {
				$extra = $retriever->get_entire_page_content( get_post( $post_id ) );
				if ( is_string( $extra ) && '' !== $extra ) {
					$entire_page_content = $extra;
				}
			}
		}

		if ( '' !== $entire_page_content ) {
			if ( strlen( $entire_page_content ) <= self::MAX_PARSE_BLOCKS_BYTES ) {
				return $entire_page_content;
			}

			// Theme Builder `get_entire_page_content()` can exceed PHP memory when parsed repeatedly.
			if ( '' !== $post_content ) {
				return $post_content;
			}

			return substr( $entire_page_content, 0, self::MAX_PARSE_BLOCKS_BYTES );
		}

		return $post_content;
	}

	/**
	 * Legacy merged string for filters / callers that still expect concatenated content.
	 *
	 * Built lazily from {@see get_merged_detection_content_fragments()} — not used for slug detection.
	 *
	 * @return string
	 */
	public static function get_merged_page_content_string(): string {
		$post_id = function_exists( 'get_the_ID' ) ? (int) get_the_ID() : 0;

		if (
			null !== self::$merged_page_content_cache
			&& self::$merged_detection_index_post_id === $post_id
		) {
			return self::$merged_page_content_cache;
		}

		$index      = self::resolve_merged_detection_index();
		$base       = isset( $index['base_content'] ) ? (string) $index['base_content'] : '';
		$fragments  = isset( $index['content_fragments'] ) && is_array( $index['content_fragments'] )
			? $index['content_fragments']
			: array();
		$merged     = $base;
		$merged_len = strlen( $merged );

		foreach ( $fragments as $fragment ) {
			if ( ! is_string( $fragment ) || '' === $fragment ) {
				continue;
			}
			$fragment_len = strlen( $fragment );
			if ( $merged_len + $fragment_len + 1 > self::MAX_MERGED_CONTENT_BYTES ) {
				break;
			}
			$merged    .= ( '' === $merged ? '' : "\n" ) . $fragment;
			$merged_len = strlen( $merged );
		}

		self::$merged_page_content_cache = $merged;

		return $merged;
	}

	/**
	 * Collect Divi Library layout IDs referenced by Advanced → Popup (`use_popup` on + layout).
	 *
	 * @param string $content Block / post content.
	 * @return list<int>
	 */
	public static function collect_popup_layout_ids_from_content( string $content ): array {
		if ( '' === $content || ! str_contains( $content, 'use_popup' ) ) {
			return array();
		}
		$blocks = self::safe_parse_blocks( $content );
		if ( empty( $blocks ) ) {
			return self::collect_popup_layout_ids_regex_fallback( $content );
		}
		$ids = array();
		self::walk_blocks_collect_popup_layout_ids( $blocks, $ids );

		return array_values( array_unique( array_filter( array_map( 'intval', $ids ) ) ) );
	}

	/**
	 * Lightweight popup layout ID extraction when block parsing is skipped (oversized content).
	 *
	 * @param string $content Serialized block / post content.
	 * @return list<int>
	 */
	private static function collect_popup_layout_ids_regex_fallback( string $content ): array {
		if ( '' === $content || ! str_contains( $content, 'use_popup' ) ) {
			return array();
		}

		$ids = array();

		// D4 / legacy library picker: `post_id` inside `popup_layout` JSON.
		if ( preg_match_all( '/popup_layout[^}]{0,400}?post_id["\']?\s*:\s*"?(\d+)"?/s', $content, $matches ) ) {
			foreach ( $matches[1] as $raw_id ) {
				$layout_id = (int) $raw_id;
				if ( $layout_id > 0 ) {
					$ids[] = $layout_id;
				}
			}
		}

		// D5 Advanced → Popup: `popup_layout.innerContent.desktop.value` (numeric layout id).
		if ( preg_match_all( '/popup_layout[^}]{0,800}?"value"\s*:\s*"?([1-9]\d*)"?/s', $content, $d5_matches ) ) {
			foreach ( $d5_matches[1] as $raw_id ) {
				$layout_id = (int) $raw_id;
				if ( $layout_id > 0 ) {
					$ids[] = $layout_id;
				}
			}
		}

		return array_values( array_unique( $ids ) );
	}

	/**
	 * Collect popup layout IDs (including nested) for asset detection.
	 *
	 * @param string $seed_content Page / merged content that may reference popups.
	 * @return list<int>
	 */
	public static function collect_popup_layout_ids_for_dynamic_assets( string $seed_content ): array {
		if ( '' === $seed_content || ! str_contains( $seed_content, 'use_popup' ) ) {
			return array();
		}

		$seen  = array();
		$queue = self::collect_popup_layout_ids_from_content( $seed_content );
		$guard = 0;

		while ( array() !== $queue && $guard < 100 ) {
			++$guard;
			$lid = (int) array_shift( $queue );
			if ( $lid <= 0 || isset( $seen[ $lid ] ) ) {
				continue;
			}
			$seen[ $lid ] = true;

			$layout_post = get_post( $lid );
			if ( ! $layout_post instanceof \WP_Post ) {
				continue;
			}

			$post_content = isset( $layout_post->post_content ) ? (string) $layout_post->post_content : '';
			if ( '' === $post_content ) {
				continue;
			}

			foreach ( self::collect_popup_layout_ids_from_content( $post_content ) as $nested_id ) {
				if ( $nested_id > 0 && ! isset( $seen[ $nested_id ] ) ) {
					$queue[] = $nested_id;
				}
			}
		}

		return array_map( 'intval', array_keys( $seen ) );
	}

	/**
	 * Concatenate `post_content` of layouts used as popups (and nested popup layouts) for asset detection.
	 *
	 * @param string $seed_content Page / merged content that may reference popups.
	 * @return string Extra raw content or empty string.
	 */
	public static function get_popup_layout_contents_for_dynamic_assets( string $seed_content ): string {
		$layout_ids = self::collect_popup_layout_ids_for_dynamic_assets( $seed_content );
		if ( array() === $layout_ids ) {
			$layout_ids = self::collect_popup_layout_ids_regex_fallback( $seed_content );
		}
		if ( array() === $layout_ids ) {
			return '';
		}

		if ( ! class_exists( \DSM_Dynamic_Assets_Library_Supplement::class ) ) {
			return '';
		}

		$pieces = \DSM_Dynamic_Assets_Library_Supplement::fetch_layout_post_content_strings_for_ids( $layout_ids );

		return implode( ' ', array_slice( $pieces, 0, self::MAX_SUPPLEMENT_LAYOUT_IDS ) );
	}

	/**
	 * Whether parsed block content includes Popup extension usage (`use_popup` on + layout id).
	 *
	 * @param string $content Post or merged layout content.
	 */
	public static function content_has_popup_trigger( string $content ): bool {
		return array() !== self::collect_popup_layout_ids_from_content( $content );
	}

	/**
	 * Walk blocks collect popup layout IDs.
	 *
	 * @param array<int, mixed> $blocks Parsed blocks.
	 * @param array             $ids Collected layout IDs (by ref).
	 */
	private static function walk_blocks_collect_popup_layout_ids( array $blocks, array &$ids ): void {
		foreach ( $blocks as $block ) {
			if ( ! is_array( $block ) ) {
				continue;
			}
			if ( ! empty( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ) {
				self::walk_blocks_collect_popup_layout_ids( $block['innerBlocks'], $ids );
			}
			$attrs = $block['attrs'] ?? array();
			if ( ! is_array( $attrs ) ) {
				continue;
			}
			$use = $attrs['use_popup']['innerContent']['desktop']['value'] ?? '';
			if ( 'on' !== $use ) {
				continue;
			}
			$pid = $attrs['popup_layout']['innerContent']['desktop']['value'] ?? 0;
			if ( is_numeric( $pid ) && (int) $pid > 0 ) {
				$ids[] = (int) $pid;
			}
		}
	}

	/**
	 * Whether this frontend request should load assets for an injected popup layout.
	 */
	public static function current_request_has_active_popup(): bool {
		if ( ! function_exists( 'dsm_is_supreme_popup_extension_enabled' ) || ! dsm_is_supreme_popup_extension_enabled() ) {
			return false;
		}

		if ( self::merged_detection_has_popup_trigger() ) {
			return true;
		}

		return self::current_request_has_woocommerce_footer_popup()
			|| self::current_request_has_enabled_global_popup();
	}

	/**
	 * Current request has woocommerce footer popup.
	 *
	 * @return bool
	 */
	private static function current_request_has_woocommerce_footer_popup(): bool {
		if ( ! isset( $GLOBALS['dsm_popup_extension'] ) || ! is_object( $GLOBALS['dsm_popup_extension'] ) ) {
			return false;
		}

		$popup_ext = $GLOBALS['dsm_popup_extension'];

		return method_exists( $popup_ext, 'has_woocommerce_footer_popup_for_current_request' )
			&& $popup_ext->has_woocommerce_footer_popup_for_current_request();
	}

	/**
	 * Raw `post_content` of popup library layouts referenced on this request.
	 *
	 * @return list<string>
	 */
	public static function get_popup_layout_content_fragments_for_assets(): array {
		if ( ! self::current_request_has_active_popup() ) {
			return array();
		}

		$layout_ids = self::collect_active_popup_layout_ids_for_assets();
		if ( array() === $layout_ids ) {
			return array();
		}

		if ( ! class_exists( \DSM_Dynamic_Assets_Library_Supplement::class ) ) {
			return array();
		}

		return \DSM_Dynamic_Assets_Library_Supplement::fetch_layout_post_content_strings_for_ids( $layout_ids );
	}

	/**
	 * Collect active popup layout IDs for assets.
	 *
	 * @return list<int>
	 */
	private static function collect_active_popup_layout_ids_for_assets(): array {
		$seen = array();

		foreach ( self::collect_popup_layout_ids_for_dynamic_assets( self::resolve_base_page_content_string() ) as $layout_id ) {
			$layout_id = (int) $layout_id;
			if ( $layout_id > 0 ) {
				$seen[ $layout_id ] = true;
			}
		}

		if ( self::current_request_has_woocommerce_footer_popup()
			&& isset( $GLOBALS['dsm_popup_extension'] )
			&& is_object( $GLOBALS['dsm_popup_extension'] )
			&& method_exists( $GLOBALS['dsm_popup_extension'], 'get_global_popups' )
		) {
			foreach ( $GLOBALS['dsm_popup_extension']->get_global_popups( 'woocommerce' ) as $row ) {
				if ( ! is_array( $row ) || ! isset( $row['id'] ) ) {
					continue;
				}
				$layout_id = (int) $row['id'];
				if ( $layout_id > 0 ) {
					$seen[ $layout_id ] = true;
				}
			}
		}

		return array_map( 'intval', array_keys( $seen ) );
	}

	/**
	 * Collect divi block slugs from content.
	 *
	 * @param string $content Block / post content.
	 * @return list<string>
	 */
	public static function collect_divi_block_slugs_from_content( string $content ): array {
		if ( '' === $content || ! str_contains( $content, 'divi/' ) ) {
			return array();
		}

		if ( ! DsmFrontendAssetRegistry::should_use_manual_block_parsing_for_detection() ) {
			return self::collect_divi_block_slugs_from_content_substring( $content );
		}

		$blocks = self::safe_parse_blocks( $content );
		if ( empty( $blocks ) ) {
			return self::collect_divi_block_slugs_from_content_substring( $content );
		}

		$slug_map = array();
		self::walk_blocks_collect_divi_block_slugs( $blocks, $slug_map );

		return array_keys( $slug_map );
	}

	/**
	 * Substring scan for `divi/*` block names (no parse_blocks — safe inside DA pipeline).
	 *
	 * @param string $content Serialized block / post content.
	 * @return list<string>
	 */
	private static function collect_divi_block_slugs_from_content_substring( string $content ): array {
		$slug_map   = array();
		$candidates = array(
			'divi/section',
			'divi/row',
			'divi/row-inner',
			'divi/column',
			'divi/button',
			'divi/text',
			'divi/image',
			'divi/cta',
			'divi/blurb',
			'divi/slider',
			'divi/accordion',
			'divi/tabs',
			'divi/tab',
			'divi/contact-form',
			'divi/signup',
			'divi/counter',
			'divi/countdown-timer',
			'divi/gallery',
			'divi/video',
			'divi/map',
			'divi/icon',
			'divi/team-member',
			'divi/testimonial',
			'divi/pricing-tables',
			'divi/pricing-table',
			'divi/social-media-follow',
			'divi/social-media-follow-network',
		);

		foreach ( $candidates as $slug ) {
			if ( self::page_content_suggests_block_name( $content, $slug ) ) {
				$slug_map[ $slug ] = true;
			}
		}

		return array_keys( $slug_map );
	}

	/**
	 * Parse blocks with a byte-size guard so Theme Builder mega-content cannot exhaust PHP memory.
	 *
	 * @param string $content Serialized block / post content.
	 * @return array<int, mixed>
	 */
	private static function safe_parse_blocks( string $content ): array {
		if ( '' === $content ) {
			return array();
		}

		if ( ! DsmFrontendAssetRegistry::should_use_manual_block_parsing_for_detection() ) {
			return array();
		}

		if ( strlen( $content ) > self::MAX_PARSE_BLOCKS_BYTES ) {
			return array();
		}

		return parse_blocks( $content );
	}

	/**
	 * Iterate base page content plus supplemental layout fragments for substring / option scans.
	 *
	 * @return \Generator<int, string, mixed, void>
	 */
	private static function each_merged_detection_content_source(): \Generator {
		$index = self::resolve_merged_detection_index();
		$base  = isset( $index['base_content'] ) ? (string) $index['base_content'] : '';
		if ( '' !== $base ) {
			yield $base;
		}

		$fragments = isset( $index['content_fragments'] ) && is_array( $index['content_fragments'] )
			? $index['content_fragments']
			: array();

		foreach ( $fragments as $fragment ) {
			if ( is_string( $fragment ) && '' !== $fragment ) {
				yield $fragment;
			}
		}
	}

	/**
	 * Divi core module slugs required inside popup library layouts on this request.
	 *
	 * @return list<string>
	 */
	public static function get_required_divi_modules_for_popup_layouts(): array {
		$slug_map = array();

		foreach ( self::get_popup_layout_content_fragments_for_assets() as $fragment ) {
			foreach ( self::collect_divi_block_slugs_from_content( $fragment ) as $slug ) {
				$slug_map[ $slug ] = true;
			}
		}

		$required = array_keys( $slug_map );
		if ( array() === $required && self::current_request_has_active_popup() ) {
			$required = array( 'divi/section', 'divi/row', 'divi/button' );
		}

		/**
		 * Filter Divi module slugs forced into Dynamic Assets when popup library layouts are present.
		 *
		 * @param list<string> $required     Module slugs (e.g. `divi/row`).
		 * @param list<int>    $layout_ids   Popup library layout IDs for this request.
		 */
		return array_values(
			array_unique(
				array_filter(
					array_map(
						'strval',
						apply_filters(
							'dsm_frontend_popup_required_divi_module_slugs',
							$required,
							self::collect_active_popup_layout_ids_for_assets()
						)
					)
				)
			)
		);
	}

	/**
	 * Force `dsm/*` module slugs into Divi block-asset detection when present in merged scan content.
	 *
	 * Substring scan only — no parse_blocks inside the DA pipeline.
	 *
	 * @param array  $required_assets Custom required module slugs.
	 * @param string $all_content     Divi merged scan content.
	 * @return list<string>
	 */
	public static function filter_required_dsm_module_assets( array $required_assets, string $all_content ): array {
		if ( ! function_exists( 'dsm_supreme_dynamic_assets_enabled' ) || ! dsm_supreme_dynamic_assets_enabled() ) {
			return $required_assets;
		}

		if ( ! DsmFrontendAssetRegistry::is_divi_frontend_dynamic_assets_active() ) {
			return $required_assets;
		}

		DsmFrontendAssetRegistry::begin_da_filter_context();

		try {
			$found = array();

			foreach ( self::get_merged_detection_module_slugs() as $slug ) {
				if ( is_string( $slug ) && str_starts_with( $slug, 'dsm/' ) ) {
					$found[] = $slug;
				}
			}

			if ( '' !== $all_content ) {
				foreach ( self::collect_dsm_block_slugs_from_content( $all_content ) as $slug ) {
					if ( str_starts_with( $slug, 'dsm/' ) ) {
						$found[] = $slug;
					}
				}
			}

			$base = DsmFrontendAssetRegistry::get_da_all_content_for_pattern_scan();
			if ( '' !== $base && $base !== $all_content ) {
				foreach ( self::collect_dsm_block_slugs_from_content( $base ) as $slug ) {
					if ( str_starts_with( $slug, 'dsm/' ) ) {
						$found[] = $slug;
					}
				}
			}

			if ( array() === $found ) {
				return $required_assets;
			}

			return array_values( array_unique( array_merge( $required_assets, $found ) ) );
		} finally {
			DsmFrontendAssetRegistry::end_da_filter_context();
		}
	}

	/**
	 * Merge popup library Divi module slugs into Divi Dynamic Assets required-module detection.
	 *
	 * Restores pre-3ead993bd behaviour where popup layout bodies were merged into Divi's scan content.
	 *
	 * @param array  $required_assets Custom required module slugs.
	 * @param string $all_content     Divi merged scan content.
	 * @return list<string>
	 */
	public static function filter_divi_popup_required_module_assets( array $required_assets, string $all_content ): array {
		if ( ! self::current_request_has_active_popup() ) {
			return $required_assets;
		}

		if ( ! DsmFrontendAssetRegistry::is_divi_frontend_dynamic_assets_active() ) {
			return $required_assets;
		}

		DsmFrontendAssetRegistry::begin_da_filter_context();

		try {
			return array_values(
				array_unique(
					array_merge( $required_assets, self::get_required_divi_modules_for_popup_layouts() )
				)
			);
		} finally {
			DsmFrontendAssetRegistry::end_da_filter_context();
		}
	}

	/**
	 * Walk blocks collect divi block slugs.
	 *
	 * @param array<int, mixed>   $blocks   Parsed blocks.
	 * @param array<string, true> $slug_map Collected slugs (by ref).
	 */
	private static function walk_blocks_collect_divi_block_slugs( array $blocks, array &$slug_map ): void {
		foreach ( $blocks as $block ) {
			if ( ! is_array( $block ) ) {
				continue;
			}

			if ( ! empty( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ) {
				self::walk_blocks_collect_divi_block_slugs( $block['innerBlocks'], $slug_map );
			}

			$name = isset( $block['blockName'] ) ? (string) $block['blockName'] : '';
			if ( '' !== $name && str_starts_with( $name, 'divi/' ) ) {
				$slug_map[ $name ] = true;
			}
		}
	}
}
