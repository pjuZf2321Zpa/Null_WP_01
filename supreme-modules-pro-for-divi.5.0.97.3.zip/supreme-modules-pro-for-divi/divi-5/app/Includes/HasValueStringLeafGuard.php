<?php
/**
 * Keep Divi `ModuleUtils::has_value()` from fatalling on a string leaf.
 *
 * From Divi 5.18.2 on, `ArrayUtility::get_value()` type-hints `array`. `has_value()`
 * passes `$value ?? []`, which leaves a string in place, then asks for `src` or
 * `text`. That TypeError aborts the whole request. The coerce runs for builder
 * version 5.18.2 and newer. It runs in memory on
 * `divi_module_library_register_module_attrs` and does not rewrite stored posts.
 *
 * Divi Text `content` is left alone. It renders a string leaf with no sub-name.
 * Supreme fields that pass `attrSubName` `text` are wrapped, including ones with
 * no `elementType` (`dsm/icon-list-child` `content`, `dsm/price-list-child`
 * `content`, `dsm/step-flow` `dsm_badge`).
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Includes;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Coerces string innerContent leaves for element types that always query a sub-name.
 */
final class HasValueStringLeafGuard {

	/**
	 * Register the render-time attr filter.
	 *
	 * @return void
	 */
	public static function register(): void {
		add_filter( 'divi_module_library_register_module_attrs', array( self::class, 'filter_module_attrs' ), 100, 2 );
	}

	/**
	 * Wrap string leaves before Divi asks `get_value()` for `src` or `text`.
	 *
	 * @param mixed $module_attrs Attrs after preset merge.
	 * @param mixed $filter_args  Divi filter args. `name` is the block name.
	 * @return mixed
	 */
	public static function filter_module_attrs( $module_attrs, $filter_args ) {
		if ( ! self::is_divi_5182_has_value_string_bug() ) {
			return $module_attrs;
		}

		if ( ! is_array( $module_attrs ) || ! is_array( $filter_args ) ) {
			return $module_attrs;
		}

		$name = $filter_args['name'] ?? '';
		if ( ! is_string( $name ) || '' === $name || ! class_exists( '\WP_Block_Type_Registry' ) ) {
			return $module_attrs;
		}

		$block = \WP_Block_Type_Registry::get_instance()->get_registered( $name );
		if ( ! is_object( $block ) || ! isset( $block->attributes ) || ! is_array( $block->attributes ) ) {
			return $module_attrs;
		}

		foreach ( $block->attributes as $attr_name => $attr_data ) {
			if ( ! is_string( $attr_name ) || ! isset( $module_attrs[ $attr_name ] ) || ! is_array( $module_attrs[ $attr_name ] ) ) {
				continue;
			}
			if ( ! is_array( $attr_data ) ) {
				continue;
			}

			$element_type = $attr_data['elementType'] ?? '';
			if ( ! is_string( $element_type ) ) {
				continue;
			}

			$leaf_key = self::leaf_key_for_attribute( $element_type, $name, $attr_name );
			if ( null === $leaf_key ) {
				continue;
			}

			self::coerce_inner_content( $module_attrs[ $attr_name ], $leaf_key );
		}

		return $module_attrs;
	}

	/**
	 * Whether the active Divi release fatals on a string leaf in `has_value()`.
	 *
	 * Divi 5.18.2 and every newer release type-hint `get_value()` as an array.
	 *
	 * @param string|null $version Builder version. Null reads the active Divi version.
	 * @return bool
	 */
	public static function is_divi_5182_has_value_string_bug( ?string $version = null ): bool {
		if ( null === $version ) {
			$version = '';

			if ( defined( 'ET_BUILDER_VERSION' ) ) {
				$version = (string) ET_BUILDER_VERSION;
			} elseif ( function_exists( 'et_get_theme_version' ) ) {
				$version = (string) et_get_theme_version();
			}
		}

		if ( '' === $version ) {
			return false;
		}

		return version_compare( $version, '5.18.2', '>=' );
	}

	/**
	 * Sub-name Divi passes to `has_value()` for this element type.
	 *
	 * @param string $element_type module.json `elementType`.
	 * @return string|null `src`, `text`, or null when the leaf must stay a string.
	 */
	public static function leaf_key_for_element_type( string $element_type ): ?string {
		if ( 'image' === $element_type || 'imageLink' === $element_type ) {
			return 'src';
		}

		if ( 'headingLink' === $element_type || 'button' === $element_type ) {
			return 'text';
		}

		return null;
	}

	/**
	 * Sub-name for one attribute, including Supreme fields that pass `attrSubName` `text` with no `elementType`.
	 *
	 * @param string $element_type module.json `elementType`, or an empty string.
	 * @param string $block_name   Registered block name.
	 * @param string $attr_name    Attribute key.
	 * @return string|null `src`, `text`, or null when the leaf must stay a string.
	 */
	public static function leaf_key_for_attribute( string $element_type, string $block_name, string $attr_name ): ?string {
		$from_type = self::leaf_key_for_element_type( $element_type );
		if ( null !== $from_type ) {
			return $from_type;
		}

		$map = array(
			'dsm/blob-image'            => array( 'blob_desc' ),
			'dsm/flipbox'               => array( 'front_content', 'back_content' ),
			'dsm/icon-list-child'       => array( 'content' ),
			'dsm/image-accordion-child' => array( 'image_accordion_desc' ),
			'dsm/price-list-child'      => array( 'content' ),
			'dsm/step-flow'             => array( 'dsm_content', 'dsm_badge' ),
		);

		if ( isset( $map[ $block_name ] ) && in_array( $attr_name, $map[ $block_name ], true ) ) {
			return 'text';
		}

		return null;
	}

	/**
	 * Wrap a scalar innerContent leaf. Existing arrays are unchanged.
	 *
	 * @param array<string, mixed> $attr     One module attribute, by reference.
	 * @param string               $leaf_key `src` or `text`.
	 * @return void
	 */
	public static function coerce_inner_content( array &$attr, string $leaf_key ): void {
		if ( ! array_key_exists( 'innerContent', $attr ) ) {
			return;
		}

		$inner = $attr['innerContent'];
		if ( self::is_scalar_leaf( $inner ) ) {
			$attr['innerContent'] = array(
				'desktop' => array(
					'value' => array(
						$leaf_key => (string) $inner,
					),
				),
			);
			return;
		}

		if ( ! is_array( $inner ) ) {
			return;
		}

		foreach ( $inner as $breakpoint => $bucket ) {
			if ( ! is_string( $breakpoint ) ) {
				continue;
			}

			if ( self::is_scalar_leaf( $bucket ) ) {
				$inner[ $breakpoint ] = array(
					'value' => array(
						$leaf_key => (string) $bucket,
					),
				);
				continue;
			}

			if ( ! is_array( $bucket ) ) {
				continue;
			}

			foreach ( $bucket as $state => $leaf ) {
				if ( ! is_string( $state ) || ! self::is_scalar_leaf( $leaf ) ) {
					continue;
				}

				$bucket[ $state ] = array(
					$leaf_key => (string) $leaf,
				);
			}

			$inner[ $breakpoint ] = $bucket;
		}

		$attr['innerContent'] = $inner;
	}

	/**
	 * Whether the leaf is a string or number Divi would pass into `get_value()`.
	 *
	 * @param mixed $value Candidate leaf.
	 * @return bool
	 */
	private static function is_scalar_leaf( $value ): bool {
		return is_string( $value ) || is_int( $value ) || is_float( $value );
	}
}
