<?php
/**
 * REST: Visual Builder shortcode-field preview (HTML via do_shortcode).
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Registers `POST /dsm/v1/shortcode-preview`.
 */
final class DSM_Shortcode_Preview_REST {

	/**
	 * Max raw shortcode field length (bytes of the request string).
	 */
	private const MAX_CONTENT_BYTES = 100000;

	/**
	 * Hook REST routes.
	 */
	public function __construct() {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	/**
	 * Register the preview route.
	 *
	 * @return void
	 */
	public function register_routes(): void {
		register_rest_route(
			'dsm/v1',
			'/shortcode-preview',
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'rest_callback' ),
				'permission_callback' => array( $this, 'permission_callback' ),
				'args'                => array(
					'content' => array(
						'type'              => 'string',
						'required'          => true,
						'validate_callback' => static function ( $param ) {
							return is_string( $param );
						},
					),
				),
			)
		);
	}

	/**
	 * Editors only (same as library-layout-preview / table-shortcode-preview).
	 *
	 * @return bool
	 */
	public function permission_callback(): bool {
		return current_user_can( 'edit_posts' );
	}

	/**
	 * Expand a shortcode field the same way the frontend helper does.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function rest_callback( \WP_REST_Request $request ) {
		$content = (string) $request->get_param( 'content' );

		if ( strlen( $content ) > self::MAX_CONTENT_BYTES ) {
			return new \WP_Error(
				'dsm_shortcode_preview_too_large',
				__( 'Shortcode preview is too large.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 400 )
			);
		}

		$html = \DiviSupreme\Includes\DiviLibraryLayoutRenderer::render_shortcode_field_content(
			$content,
			'dsm_shortcode_preview_styles'
		);

		/**
		 * Filter Visual Builder shortcode preview HTML.
		 *
		 * @param string $html    Rendered markup.
		 * @param string $content Raw shortcode field.
		 */
		$filtered = apply_filters( 'dsm_shortcode_preview_html', $html, $content );

		return rest_ensure_response(
			array(
				'html' => is_string( $filtered ) ? $filtered : $html,
			)
		);
	}
}

new DSM_Shortcode_Preview_REST();
