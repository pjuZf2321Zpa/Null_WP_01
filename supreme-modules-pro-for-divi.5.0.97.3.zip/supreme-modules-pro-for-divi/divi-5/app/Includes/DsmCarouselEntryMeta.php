<?php
/**
 * Shared entry-meta join helper for Blog Carousel and Post Carousel.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Includes;

/**
 * Joins visible meta HTML parts with a separator that never leads or trails.
 */
final class DsmCarouselEntryMeta {

	/**
	 * Default separator when the setting is empty.
	 */
	public const DEFAULT_SEPARATOR = '|';

	/**
	 * Normalize the stored separator; blank values fall back to `|`.
	 *
	 * @param mixed $raw Raw `meta_seperator` value.
	 * @return string
	 */
	public static function normalize_separator( $raw ): string {
		if ( ! is_string( $raw ) ) {
			return self::DEFAULT_SEPARATOR;
		}

		$trimmed = trim( $raw );

		return '' === $trimmed ? self::DEFAULT_SEPARATOR : $trimmed;
	}

	/**
	 * Separator span. Class `dsm-meta-seperator` is historical — do not rename.
	 *
	 * @param string $separator Plain-text separator.
	 * @return string Escaped HTML.
	 */
	public static function separator_html( string $separator ): string {
		return '<span class="dsm-meta-seperator">' . esc_html( self::normalize_separator( $separator ) ) . '</span>';
	}

	/**
	 * Join already-escaped meta parts with the separator between items only.
	 *
	 * @param array<int, string> $parts     Escaped HTML fragments.
	 * @param string             $separator Plain-text separator.
	 * @return string Escaped HTML (may be empty).
	 */
	public static function join( array $parts, string $separator ): string {
		$clean = array();

		foreach ( $parts as $part ) {
			if ( ! is_string( $part ) ) {
				continue;
			}

			$trimmed = trim( $part );
			if ( '' === $trimmed ) {
				continue;
			}

			$clean[] = $part;
		}

		if ( array() === $clean ) {
			return '';
		}

		return implode( ' ' . self::separator_html( $separator ) . ' ', $clean );
	}
}
