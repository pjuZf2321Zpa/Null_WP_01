<?php
/**
 * REST: Visual Builder Magnific popup preview (SSR markup often missing inside the iframe).
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Registers `POST /dsm/v1/popup-visual-preview`.
 */
final class DSM_Popup_Visual_Preview_REST {

	/**
	 * Hook REST routes.
	 */
	public function __construct() {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	/**
	 * Register routes.
	 *
	 * @return void
	 */
	public function register_routes(): void {
		register_rest_route(
			'dsm/v1',
			'/popup-visual-preview',
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'rest_callback' ),
				'permission_callback' => array( $this, 'permission_callback' ),
				'args'                => array(
					'layoutId' => array(
						'required'          => true,
						'sanitize_callback' => 'absint',
					),
				),
			)
		);
	}

	/**
	 * Permission callback.
	 *
	 * @return bool
	 */
	public function permission_callback(): bool {
		return current_user_can( 'edit_posts' );
	}

	/**
	 * Returns popup `#dsm-popup-{id}` HTML + combined CSS matching {@see Popup::compile_popup_markup_and_aggregate_css()}.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function rest_callback( \WP_REST_Request $request ) {
		$popup_id = (int) $request->get_param( 'layoutId' );

		if ( $popup_id <= 0 ) {
			return new \WP_Error(
				'dsm_invalid_popup_id',
				esc_html__( 'Invalid popup layout ID.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 400 )
			);
		}

		$post = get_post( $popup_id );
		if ( ! $post instanceof \WP_Post ) {
			return new \WP_Error(
				'dsm_layout_not_found',
				esc_html__( 'Popup layout was not found.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 404 )
			);
		}

		if ( ! defined( 'ET_BUILDER_LAYOUT_POST_TYPE' ) || ET_BUILDER_LAYOUT_POST_TYPE !== $post->post_type ) {
			return new \WP_Error(
				'dsm_invalid_post_type',
				esc_html__( 'The requested post is not a Divi Library layout.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 400 )
			);
		}

		$mgr = isset( $GLOBALS['dsm_popup_extension'] ) ? $GLOBALS['dsm_popup_extension'] : null;

		if ( ! $mgr instanceof \DiviSupreme\Extensions\Popup ) {
			return new \WP_Error(
				'dsm_popup_extension_missing',
				esc_html__( 'Popup extension failed to bootstrap.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 503 )
			);
		}

		$data = $mgr->export_visual_builder_popup_preview_fragment( $popup_id );

		if ( null === $data || empty( $data['markup'] ) ) {
			return new \WP_Error(
				'dsm_popup_preview_unavailable',
				esc_html__( 'Popup preview is unavailable. Enable Popup on the library layout and try again.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 400 )
			);
		}

		return new \WP_REST_Response( $data );
	}
}

new DSM_Popup_Visual_Preview_REST();
