<?php
/**
 * Legacy bootstrap for Divi dynamic global assets.
 *
 * Icon + supplemental global assets are registered via {@see \DiviSupreme\Includes\DsmFrontendAssetRegistry}
 * on `divi_frontend_assets_dynamic_assets_global_assets_list` (priority 15) from
 * {@see \DiviSupreme\Includes\DsmFrontendDynamicAssets::register_hooks()}.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}
