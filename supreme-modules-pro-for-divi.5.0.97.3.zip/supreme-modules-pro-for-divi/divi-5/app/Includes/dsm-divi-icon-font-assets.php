<?php
/**
 * Resolved Divi ETmodules / Font Awesome @font-face for non-pipeline frontend requests.
 *
 * Divi's icons_all.css uses `#dynamic-product-dir/` placeholders that only work when
 * merged by DynamicAssets::get_assets_data(). Never wp_enqueue that file directly.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Theme URI without protocol (matches Divi DynamicAssetsListBuilder replacement).
 *
 * @return string
 */
function dsm_get_divi_product_dir_uri_without_protocol(): string {
	if ( function_exists( 'et_is_builder_plugin_active' ) && et_is_builder_plugin_active() && defined( 'ET_BUILDER_PLUGIN_URI' ) ) {
		$uri = (string) ET_BUILDER_PLUGIN_URI;
	} elseif ( function_exists( 'get_template_directory_uri' ) ) {
		$uri = (string) get_template_directory_uri();
	} else {
		return '';
	}

	return str_replace( array( 'http:', 'https:' ), '', $uri );
}

/**
 * Read Divi icon CSS and resolve `#dynamic-product-dir/` font URLs.
 *
 * @param string $filename Basename under dynamic-assets/assets/css/.
 * @return string
 */
function dsm_get_resolved_divi_icon_font_css( string $filename ): string {
	static $cache = array();

	if ( isset( $cache[ $filename ] ) ) {
		return $cache[ $filename ];
	}

	if ( ! function_exists( 'get_theme_file_path' ) ) {
		$cache[ $filename ] = '';

		return '';
	}

	$path = get_theme_file_path( 'includes/builder/feature/dynamic-assets/assets/css/' . ltrim( $filename, '/' ) );

	if ( ! is_string( $path ) || ! is_readable( $path ) ) {
		$cache[ $filename ] = '';

		return '';
	}

	$content = file_get_contents( $path );

	if ( ! is_string( $content ) || '' === $content ) {
		$cache[ $filename ] = '';

		return '';
	}

	$product_dir = dsm_get_divi_product_dir_uri_without_protocol();

	if ( '' === $product_dir ) {
		$cache[ $filename ] = '';

		return '';
	}

	$resolved = preg_replace( '/#dynamic-product-dir/i', $product_dir, $content );

	$cache[ $filename ] = is_string( $resolved ) ? trim( $resolved ) : '';

	return $cache[ $filename ];
}

/**
 * Mark the current request as needing Divi icon fonts for a rendered popup.
 *
 * {@see \DiviSupreme\Extensions\Popup::render_popup()} runs during `render_block` (after `wp_head`),
 * so head-time DA detection may miss popups; resolved @font-face prints in `wp_footer`.
 *
 * @return void
 */
function dsm_request_divi_icon_font_for_popup_render(): void {
	$GLOBALS['dsm_popup_render_requested_divi_icon_font'] = true;

	if ( has_action( 'wp_footer', 'dsm_print_divi_icon_font_fallback_styles' ) ) {
		return;
	}

	add_action( 'wp_footer', 'dsm_print_divi_icon_font_fallback_styles', 7 );
}

/**
 * Print inline resolved icon @font-face rules when Divi's merge pipeline is inactive.
 *
 * @return void
 */
function dsm_print_divi_icon_font_fallback_styles(): void {
	static $printed = false;

	if ( $printed ) {
		return;
	}

	if ( is_admin() ) {
		return;
	}

	if ( function_exists( 'et_core_is_fb_enabled' ) && et_core_is_fb_enabled() ) {
		return;
	}

	if ( ! function_exists( 'et_builder_d5_enabled' ) || ! et_builder_d5_enabled() ) {
		return;
	}

	if ( ! class_exists( \DiviSupreme\Includes\DsmFrontendDynamicAssets::class ) ) {
		return;
	}

	$popup_render_requested = ! empty( $GLOBALS['dsm_popup_render_requested_divi_icon_font'] );

	if ( ! \DiviSupreme\Includes\DsmFrontendDynamicAssets::page_needs_divi_icon_font() && ! $popup_render_requested ) {
		return;
	}

	if (
		class_exists( \DiviSupreme\Includes\DsmFrontendAssetRegistry::class )
		&& \DiviSupreme\Includes\DsmFrontendAssetRegistry::is_divi_frontend_dynamic_assets_active()
		&& ! \DiviSupreme\Includes\DsmFrontendDynamicAssets::current_request_has_active_popup()
		&& ! $popup_render_requested
	) {
		return;
	}

	$css_parts = array(
		dsm_get_resolved_divi_icon_font_css( 'icons_all.css' ),
		dsm_get_resolved_divi_icon_font_css( 'icons_fa_all.css' ),
	);

	$css = trim( implode( "\n", array_filter( $css_parts ) ) );

	if ( '' === $css ) {
		return;
	}

	echo '<style id="dsm-divi-icon-font-fallback" class="dsm-divi-icon-font-fallback">';

	if ( function_exists( 'et_core_esc_previously' ) ) {
		echo et_core_esc_previously( $css );
	} else {
		echo esc_html( $css );
	}

	echo '</style>';

	$printed = true;
}
