<?php
/**
 * Responsive upload `<img>` markup helpers (srcset / attachment API).
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Includes;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Normalize D5 upload innerContent and render frontend images with srcset when possible.
 */
final class UploadImageMarkup {


	/**
	 * Normalize upload innerContent to a URL string (legacy D4 string or `{ src, id }`).
	 *
	 * @param mixed $raw Desktop innerContent value.
	 * @return string
	 */
	public static function resolve_upload_src_string( $raw ): string {
		if ( is_string( $raw ) && '' !== $raw ) {
			return $raw;
		}
		if ( is_array( $raw ) ) {
			if ( isset( $raw['src'] ) && is_string( $raw['src'] ) && '' !== $raw['src'] ) {
				return $raw['src'];
			}
			if ( isset( $raw['url'] ) && is_string( $raw['url'] ) && '' !== $raw['url'] ) {
				return $raw['url'];
			}
			$attachment_id = isset( $raw['id'] ) ? absint( $raw['id'] ) : 0;
			if ( $attachment_id > 0 ) {
				$url = wp_get_attachment_image_url( $attachment_id, 'full' );
				if ( is_string( $url ) && '' !== $url ) {
					return $url;
				}
			}
		}
		return '';
	}

	/**
	 * Resolve media-library attachment ID from upload innerContent.
	 *
	 * @param mixed $raw Desktop innerContent value.
	 * @return int
	 */
	public static function resolve_upload_attachment_id( $raw ): int {
		if ( is_array( $raw ) && ! empty( $raw['id'] ) ) {
			return absint( $raw['id'] );
		}

		$url = self::resolve_upload_src_string( $raw );
		if ( '' === $url || str_starts_with( $url, 'data:' ) ) {
			return 0;
		}

		if ( function_exists( 'et_get_attachment_id_by_url' ) ) {
			$found = (int) et_get_attachment_id_by_url( $url );
			return $found > 0 ? $found : 0;
		}

		$found = (int) attachment_url_to_postid( $url );
		return $found > 0 ? $found : 0;
	}

	/**
	 * Escape image `src` for output (http(s) or data URI).
	 *
	 * @param string $src Image URL.
	 * @return string
	 */
	public static function escape_image_src_attribute( string $src ): string {
		if ( str_starts_with( $src, 'data:image/' ) ) {
			return esc_attr( $src );
		}
		return esc_url( $src );
	}

	/**
	 * Front-end `<img>` with responsive srcset when attachment-based.
	 *
	 * @param mixed                $raw          Upload innerContent desktop value.
	 * @param string               $fallback_alt Alt text when attachment meta is empty.
	 * @param array<string, mixed> $extra_attrs  Extra `<img>` attributes (class, decoding, …).
	 * @return string Safe HTML (empty when no src).
	 */
	public static function render_img_html( $raw, string $fallback_alt = '', array $extra_attrs = array() ): string {
		$src = self::resolve_upload_src_string( $raw );
		if ( '' === $src ) {
			return '';
		}

		$fallback_alt  = trim( $fallback_alt );
		$attachment_id = self::resolve_upload_attachment_id( $raw );

		$default_attrs = array(
			'decoding' => 'async',
			'loading'  => 'lazy',
		);
		$img_attrs     = array_merge( $default_attrs, $extra_attrs );

		if ( $attachment_id > 0 && wp_attachment_is_image( $attachment_id ) ) {
			$alt = get_post_meta( $attachment_id, '_wp_attachment_image_alt', true );
			$alt = is_string( $alt ) ? trim( $alt ) : '';
			if ( '' === $alt ) {
				$alt = $fallback_alt;
			}

			$wp_attrs = array_merge(
				$img_attrs,
				array(
					'alt' => $alt,
				)
			);

			$img = wp_get_attachment_image(
				$attachment_id,
				'full',
				false,
				$wp_attrs
			);

			if ( is_string( $img ) && '' !== $img ) {
				return $img;
			}
		}

		$alt      = $fallback_alt;
		$img_html = sprintf(
			'<img src="%1$s" alt="%2$s" decoding="async" loading="lazy" />',
			self::escape_image_src_attribute( $src ),
			esc_attr( $alt )
		);

		if ( function_exists( 'et_image_add_srcset_and_sizes' ) ) {
			$img_html = et_image_add_srcset_and_sizes( $img_html, false );
		}

		return $img_html;
	}
}
