<?php
/**
 * Temporary Divi Supreme support login.
 *
 * The account does not exist until an administrator enables it. The secret
 * lives in the URL fragment, is stored only as ciphertext plus an HMAC, and
 * the account is removed on disable, expiry, deactivation, or uninstall.
 *
 * The account can open Divi Theme Options, the Theme Customizer, permalinks,
 * Divi Supreme settings, and plugin settings, and can change those settings,
 * so support can check the site. Users, General Settings, theme switching,
 * and this access grant stay locked.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Includes\Support;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Provisions, authenticates, and destroys the temporary support account.
 */
class TemporaryAccess {

	/**
	 * Grant option. Autoload is off because it holds ciphertext.
	 */
	public const OPTION = 'dsm_support_access';

	/**
	 * User ID pointer used to remove an orphaned account. Not a secret.
	 */
	public const USER_POINTER = 'dsm_support_user_id';

	/**
	 * Autoloaded 0/1 marker. Frontend requests skip the grant option when this is 0.
	 *
	 * The grant option stays non-autoloaded because it holds ciphertext.
	 */
	public const GRANT_PRESENT_OPTION = 'dsm_support_grant_present';

	/**
	 * User meta flag for the support account.
	 */
	public const USER_META = '_dsm_is_support_account';

	/**
	 * Role slug. Denied caps are forced off on every request.
	 */
	public const ROLE = 'dsm_support';

	/**
	 * Dedicated mailbox. Password mail is suppressed and password login is rejected.
	 */
	public const SUPPORT_EMAIL = 'support@divisupreme.com';

	/**
	 * Single cron event at expiry. Init also enforces expiry.
	 */
	public const CRON_HOOK = 'dsm_support_access_expire';

	/**
	 * Default access window in hours.
	 */
	public const DEFAULT_HOURS = 48;

	/**
	 * Hard maximum window in hours.
	 */
	public const MAX_HOURS = 168;

	/**
	 * Failed redeem attempts per IP before that IP is paused.
	 */
	private const RATE_LIMIT = 8;

	/**
	 * Rate-limit window in seconds.
	 */
	private const RATE_WINDOW = 900;

	/**
	 * Re-entry guard for revoke and user-deleted callbacks.
	 *
	 * @var bool
	 */
	private static $revoking = false;

	/**
	 * Allows this class to write the support role while that account is signed in.
	 *
	 * @var bool
	 */
	private static $allow_role_update = false;

	/**
	 * Per-request cache of support-account checks.
	 *
	 * @var array<int, bool>
	 */
	private static $support_users = array();

	/**
	 * Register hooks. Safe to call once on every request.
	 *
	 * @return void
	 */
	public static function register(): void {
		add_action( 'init', array( self::class, 'enforce_grant' ), 1 );
		add_action( 'admin_init', array( self::class, 'sweep_orphans' ) );
		add_action( 'admin_init', array( self::class, 'block_support_screens' ) );
		add_action( 'admin_menu', array( self::class, 'lock_admin_menus' ), 999 );
		add_action( 'admin_notices', array( self::class, 'render_admin_notice' ) );
		add_action( 'admin_notices', array( self::class, 'render_support_user_notice' ) );
		add_action( 'admin_post_dsm_support_access_disable', array( self::class, 'handle_disable_post' ) );
		add_action( 'wp_ajax_dsm_support_access_enable', array( self::class, 'handle_enable' ) );
		add_action( 'wp_ajax_dsm_support_access_disable', array( self::class, 'handle_disable' ) );
		add_action( 'wp_ajax_dsm_support_access_reset', array( self::class, 'handle_reset' ) );
		add_action( 'login_init', array( self::class, 'handle_login_request' ) );
		add_action( self::CRON_HOOK, array( self::class, 'cron_expire' ) );
		add_action( 'deleted_user', array( self::class, 'handle_deleted_user' ), 10, 1 );

		add_filter( 'user_has_cap', array( self::class, 'lock_caps' ), 10, 4 );
		add_filter( 'map_meta_cap', array( self::class, 'lock_meta_caps' ), 10, 4 );
		add_filter( 'option_et_pb_role_settings', array( self::class, 'allow_divi_theme_options' ) );
		add_action( 'customize_register', array( self::class, 'lock_customizer_theme_switching' ), 20 );
		add_filter( 'authenticate', array( self::class, 'block_password_auth' ), 30, 3 );
		add_filter( 'allow_password_reset', array( self::class, 'block_password_reset' ), 10, 2 );
		add_filter( 'wp_is_application_passwords_available_for_user', array( self::class, 'block_application_passwords' ), 10, 2 );
		add_filter( 'send_password_change_email', array( self::class, 'block_account_email' ), 10, 2 );
		add_filter( 'send_email_change_email', array( self::class, 'block_account_email' ), 10, 2 );
		add_filter( 'wp_send_new_user_notification_to_user', array( self::class, 'block_new_user_email' ), 10, 2 );
		add_filter( 'wp_send_new_user_notification_to_admin', array( self::class, 'block_new_user_email' ), 10, 2 );
		add_filter( 'rest_pre_dispatch', array( self::class, 'block_rest_user_routes' ), 10, 3 );
		add_filter( 'editable_roles', array( self::class, 'lock_editable_roles' ) );
		add_filter( 'user_row_actions', array( self::class, 'mark_support_user_row' ), 10, 2 );

		global $wpdb;
		if ( $wpdb instanceof \wpdb ) {
			add_filter( 'pre_update_option_' . $wpdb->prefix . 'user_roles', array( self::class, 'reject_support_option_change' ), 10, 2 );
		}

		foreach ( self::sensitive_options() as $option_name ) {
			add_filter( 'pre_update_option_' . $option_name, array( self::class, 'reject_support_option_change' ), 10, 2 );
		}
	}

	/**
	 * Whether a non-expired grant and account are stored.
	 *
	 * @return bool
	 */
	public static function is_active(): bool {
		return self::is_state_active( self::get_state() );
	}

	/**
	 * Dashboard payload. The link and nonce are omitted for the support account.
	 *
	 * @return array<string, mixed>
	 */
	public static function dashboard_payload(): array {
		$can_manage = self::current_user_can_manage();
		$live       = self::live_state( $can_manage );

		return array(
			'canManage'        => $can_manage,
			'active'           => $live['active'],
			'expiresAt'        => $live['expiresAt'],
			'expiresDisplay'   => $live['expiresDisplay'],
			'loginUrl'         => $live['loginUrl'],
			'loginCount'       => $live['loginCount'],
			'lastLoginDisplay' => $live['lastLoginDisplay'],
			'lastLoginIp'      => $live['lastLoginIp'],
			'delivery'         => $live['delivery'],
			'mailSent'         => $live['mailSent'],
			'adminEmail'       => $can_manage ? self::site_admin_email() : '',
			'canEmail'         => $can_manage && '' !== self::site_admin_email(),
			'localHttp'        => self::is_local_http(),
			'httpsOk'          => self::transport_allows_access(),
			'cryptoReady'      => self::can_encrypt(),
			'durations'        => self::duration_choices(),
			'defaultHours'     => self::DEFAULT_HOURS,
			'nonce'            => $can_manage ? wp_create_nonce( 'dsm_support_access' ) : '',
			'report'           => class_exists( SystemStatus::class ) ? SystemStatus::text() : '',
			'reportGroups'     => class_exists( SystemStatus::class ) ? SystemStatus::groups() : array(),
			'actions'          => array(
				'enable'  => 'dsm_support_access_enable',
				'disable' => 'dsm_support_access_disable',
				'reset'   => 'dsm_support_access_reset',
			),
			'strings'          => self::ui_strings(),
		);
	}

	/**
	 * Drop an expired grant, remove orphan accounts, and end a stale login.
	 *
	 * @return void
	 */
	public static function enforce_grant(): void {
		if ( self::$revoking ) {
			return;
		}

		if ( self::frontend_inactive_grant_is_known() ) {
			return;
		}

		$state = self::get_state();
		if ( is_array( $state ) && ! empty( $state['enabled'] ) ) {
			$user_id = isset( $state['user_id'] ) ? (int) $state['user_id'] : 0;
			$alive   = $user_id > 0 && get_userdata( $user_id ) && self::user_is_support_account( $user_id );
			if ( ! $alive ) {
				self::clear_storage_only();
				self::notify( 'disabled' );
				$state = null;
			} elseif ( (int) ( $state['expires_at'] ?? 0 ) <= time() ) {
				self::revoke( 'expired' );
				$state = null;
			}
		}

		$active_id = ( is_array( $state ) && self::is_state_active( $state ) ) ? (int) $state['user_id'] : 0;
		$pointer   = self::user_pointer();

		if ( $pointer > 0 && $pointer !== $active_id && self::user_is_support_account( $pointer ) ) {
			self::delete_support_user( $pointer, array() );
		}

		if ( $active_id > 0 ) {
			if ( self::user_pointer() !== $active_id ) {
				update_option( self::USER_POINTER, $active_id, false );
			}
			self::grant_plugin_role_caps();
		} elseif ( self::user_pointer() > 0 ) {
			delete_option( self::USER_POINTER );
		}

		self::logout_stale_support_session( $active_id );
		self::sync_grant_present_flag();
	}

	/**
	 * Delete support accounts that are not the active grant.
	 *
	 * @return void
	 */
	public static function sweep_orphans(): void {
		if ( self::$revoking || ! is_admin() ) {
			return;
		}

		if ( ! current_user_can( 'manage_options' ) && ! self::user_is_support_account( get_current_user_id() ) ) {
			return;
		}

		$state     = self::get_state();
		$active_id = ( is_array( $state ) && self::is_state_active( $state ) ) ? (int) $state['user_id'] : 0;
		self::sweep_user_ids( $active_id );
	}

	/**
	 * Cron callback. Init is authoritative if cron does not run.
	 *
	 * @return void
	 */
	public static function cron_expire(): void {
		$state = self::get_state();
		if ( ! is_array( $state ) || empty( $state['enabled'] ) ) {
			return;
		}

		if ( time() >= (int) ( $state['expires_at'] ?? 0 ) ) {
			self::revoke( 'expired' );
		}
	}

	/**
	 * Remove the account, sessions, and stored secret.
	 *
	 * @param string $reason disabled|expired|deactivated|uninstall.
	 * @return void
	 */
	public static function revoke( string $reason ): void {
		if ( self::$revoking ) {
			return;
		}

		self::$revoking = true;

		$state      = self::get_state();
		$was_active = is_array( $state ) && ! empty( $state['enabled'] );
		$user_id    = is_array( $state ) ? (int) ( $state['user_id'] ?? 0 ) : 0;
		if ( $user_id <= 0 ) {
			$user_id = self::user_pointer();
		}

		if ( $user_id > 0 && get_current_user_id() === $user_id ) {
			wp_logout();
		}

		if ( $user_id > 0 ) {
			self::destroy_sessions( $user_id );
			self::delete_support_user( $user_id, is_array( $state ) ? $state : array() );
		}

		self::clear_storage_only();
		self::sweep_user_ids( 0 );

		self::$revoking = false;

		if ( $was_active && in_array( $reason, array( 'disabled', 'expired', 'deactivated' ), true ) ) {
			self::notify( $reason );
		}
	}

	/**
	 * Clear storage when an administrator deletes the support user directly.
	 *
	 * @param int $user_id Deleted user ID.
	 * @return void
	 */
	public static function handle_deleted_user( int $user_id ): void {
		if ( self::$revoking || $user_id <= 0 ) {
			return;
		}

		$state    = self::get_state();
		$grant_id = is_array( $state ) ? (int) ( $state['user_id'] ?? 0 ) : 0;
		$pointer  = self::user_pointer();

		if ( $user_id !== $grant_id && $user_id !== $pointer ) {
			return;
		}

		$was_active = is_array( $state ) && ! empty( $state['enabled'] );
		self::clear_storage_only();

		if ( $was_active ) {
			self::notify( 'disabled' );
		}
	}

	/**
	 * Enable access from the settings screen.
	 *
	 * @return void
	 */
	public static function handle_enable(): void {
		self::assert_ajax_manager();

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- assert_ajax_manager() verified the nonce.
		$confirmed = isset( $_POST['confirmed'] ) ? sanitize_text_field( wp_unslash( (string) $_POST['confirmed'] ) ) : '';
		if ( '1' !== $confirmed ) {
			wp_send_json_error(
				array(
					'message' => __( 'Confirm that you will disable access when support is finished.', 'dsm-supreme-modules-pro-for-divi' ),
				),
				400
			);
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- assert_ajax_manager() verified the nonce.
		$hours = isset( $_POST['duration_hours'] ) ? absint( $_POST['duration_hours'] ) : 0;
		if ( ! in_array( $hours, self::allowed_hours(), true ) ) {
			wp_send_json_error(
				array(
					'message' => __( 'Choose a support window of 7 days or less.', 'dsm-supreme-modules-pro-for-divi' ),
				),
				400
			);
		}

		if ( ! self::transport_allows_access() ) {
			wp_send_json_error(
				array(
					'message' => __( 'Temporary support access requires HTTPS.', 'dsm-supreme-modules-pro-for-divi' ),
				),
				400
			);
		}

		if ( ! self::can_encrypt() ) {
			wp_send_json_error(
				array(
					'message' => __( 'Temporary support access requires the OpenSSL PHP extension.', 'dsm-supreme-modules-pro-for-divi' ),
				),
				400
			);
		}

		if ( self::is_active() ) {
			wp_send_json_success(
				array(
					'message'  => __( 'Temporary support access is already on. Copy the link below. No further email was sent.', 'dsm-supreme-modules-pro-for-divi' ),
					'mailSent' => null,
					'state'    => self::live_state( true ),
				)
			);
		}

		$delivery = self::requested_delivery();
		if ( 'email' === $delivery && '' === self::site_admin_email() ) {
			wp_send_json_error(
				array(
					'message' => __( 'This site has no admin email address. Choose “Show the link on this page” instead.', 'dsm-supreme-modules-pro-for-divi' ),
				),
				400
			);
		}

		$result = self::provision( $hours, $delivery );
		if ( is_wp_error( $result ) ) {
			wp_send_json_error(
				array(
					'message' => $result->get_error_message(),
				),
				400
			);
		}

		$mail_sent = self::maybe_email_link( $delivery );

		wp_send_json_success(
			array(
				'message'  => self::enable_message( $delivery, $mail_sent ),
				'mailSent' => $mail_sent,
				'state'    => self::live_state( true ),
			)
		);
	}

	/**
	 * Disable access from the settings screen.
	 *
	 * @return void
	 */
	public static function handle_disable(): void {
		self::assert_ajax_manager();
		self::revoke( 'disabled' );

		wp_send_json_success(
			array(
				'message' => __( 'Temporary support access is off and the support account was removed.', 'dsm-supreme-modules-pro-for-divi' ),
				'state'   => self::live_state( true ),
			)
		);
	}

	/**
	 * Replace the link and end existing support sessions.
	 *
	 * @return void
	 */
	public static function handle_reset(): void {
		self::assert_ajax_manager();

		$state = self::get_state();
		if ( ! self::is_state_active( $state ) || ! is_array( $state ) ) {
			wp_send_json_error(
				array(
					'message' => __( 'Temporary support access is off.', 'dsm-supreme-modules-pro-for-divi' ),
				),
				400
			);
		}

		$token = self::generate_token();
		if ( is_wp_error( $token ) ) {
			wp_send_json_error(
				array(
					'message' => $token->get_error_message(),
				),
				400
			);
		}

		$cipher = self::encrypt_token( $token );
		if ( '' === $cipher ) {
			wp_send_json_error(
				array(
					'message' => __( 'The new support link could not be stored.', 'dsm-supreme-modules-pro-for-divi' ),
				),
				500
			);
		}

		$delivery              = (string) ( $state['delivery'] ?? 'link' );
		$state['token_hash']   = self::token_hash( $token );
		$state['token_cipher'] = $cipher;
		$state['mail_sent']    = 0;
		update_option( self::OPTION, $state, false );
		self::mark_grant_present( true );

		$user_id = (int) $state['user_id'];
		self::destroy_sessions( $user_id );
		self::notify( 'reset' );
		$mail_sent = self::maybe_email_link( $delivery );

		if ( 'email' === $delivery && true !== $mail_sent ) {
			$message = __( 'The previous link no longer works, but the new link could not be emailed. Copy it below.', 'dsm-supreme-modules-pro-for-divi' );
		} elseif ( 'email' === $delivery ) {
			$message = __( 'The previous link no longer works. The new link was emailed and is also shown below.', 'dsm-supreme-modules-pro-for-divi' );
		} else {
			$message = __( 'The previous link no longer works. No email was sent. Copy the new link below.', 'dsm-supreme-modules-pro-for-divi' );
		}

		wp_send_json_success(
			array(
				'message'  => $message,
				'mailSent' => $mail_sent,
				'state'    => self::live_state( true ),
			)
		);
	}

	/**
	 * Disable from the admin notice. POST only.
	 *
	 * @return void
	 */
	public static function handle_disable_post(): void {
		if ( ! self::current_user_can_manage() ) {
			wp_die(
				esc_html__( 'You do not have permission to manage support access.', 'dsm-supreme-modules-pro-for-divi' ),
				'',
				array( 'response' => 403 )
			);
		}

		check_admin_referer( 'dsm_support_access_disable' );
		self::revoke( 'disabled' );
		wp_safe_redirect( admin_url( 'admin.php?page=divi_supreme_settings&tab=dsm_support' ) );
		exit;
	}

	/**
	 * Logged-out login gate. The token is posted, never placed in the query string.
	 *
	 * @return void
	 */
	public static function handle_login_request(): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Public gate flag. The token is the credential.
		if ( ! isset( $_GET['dsm_support_login'] ) ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Public gate flag. The token is the credential.
		$flag = sanitize_text_field( wp_unslash( (string) $_GET['dsm_support_login'] ) );
		if ( '1' !== $flag ) {
			return;
		}

		$method = isset( $_SERVER['REQUEST_METHOD'] )
			? strtoupper( sanitize_text_field( wp_unslash( (string) $_SERVER['REQUEST_METHOD'] ) ) )
			: '';

		if ( 'POST' === $method ) {
			if ( self::request_is_cross_site() ) {
				self::bump_rate_limit();
				self::render_login_document( self::generic_login_error() );
			}

			// phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Logged-out redeem. The token is the credential and sanitize_token() restricts the alphabet.
			$raw   = isset( $_POST['dsm_support_token'] ) ? sanitize_text_field( wp_unslash( (string) $_POST['dsm_support_token'] ) ) : '';
			$token = self::sanitize_token( $raw );
			self::redeem( $token );
		}

		self::render_login_document( '' );
	}

	/**
	 * Force denied caps off, and keep site-check and plugin caps on.
	 *
	 * An account enabled before those caps were allowed still has the old role.
	 * This filter grants them on every check. Site constants such as
	 * DISALLOW_FILE_MODS are applied by WordPress before this filter and stay in force.
	 *
	 * Parameters stay untyped. user_has_cap runs on every capability check, including
	 * admin menu rendering, and an earlier filter may return an unexpected value.
	 *
	 * @param mixed $allcaps All caps for the user.
	 * @param mixed $caps    Required primitive caps.
	 * @param mixed $args    Capability check arguments.
	 * @param mixed $user    User being checked.
	 * @return mixed All caps. Unchanged when the user is not the support account.
	 */
	public static function lock_caps( $allcaps, $caps, $args, $user ) {
		unset( $caps, $args );

		if ( ! is_array( $allcaps ) || ! $user instanceof \WP_User || ! self::user_is_support_account( (int) $user->ID ) ) {
			return $allcaps;
		}

		foreach ( self::denied_caps() as $cap ) {
			$allcaps[ $cap ] = false;
		}

		foreach ( self::caps_forced_on() as $cap ) {
			$allcaps[ $cap ] = true;
		}

		return $allcaps;
	}

	/**
	 * Block user management for the support account.
	 *
	 * The edit_theme_options capability is required for Divi Theme Options and the
	 * Theme Customizer. WordPress maps the customizer meta cap to that same
	 * primitive, so customize is left available here.
	 *
	 * WordPress passes null for the capability when an admin submenu row omits it.
	 * That value is ignored before the blocked-cap list is touched. A TypeError
	 * here takes down every wp-admin screen.
	 *
	 * @param mixed $caps    Required caps.
	 * @param mixed $cap     Meta capability. Null when the menu item omitted it.
	 * @param mixed $user_id User performing the check.
	 * @param mixed $args    Extra arguments. Unused.
	 * @return mixed Required caps. A support account also receives do_not_allow for user meta caps.
	 */
	public static function lock_meta_caps( $caps, $cap, $user_id, $args ) {
		unset( $args );

		if ( ! is_array( $caps ) || ! is_string( $cap ) || '' === $cap ) {
			return $caps;
		}

		if ( is_int( $user_id ) ) {
			$checked_user_id = $user_id;
		} elseif ( is_string( $user_id ) && is_numeric( $user_id ) ) {
			$checked_user_id = (int) $user_id;
		} else {
			return $caps;
		}

		if ( $checked_user_id <= 0 || ! self::user_is_support_account( $checked_user_id ) ) {
			return $caps;
		}

		$blocked = array( 'edit_user', 'delete_user', 'remove_user', 'promote_user' );
		if ( in_array( $cap, $blocked, true ) ) {
			$caps[] = 'do_not_allow';
		}

		return $caps;
	}

	/**
	 * Keep Divi Theme Options and the Theme Customizer available for support.
	 *
	 * Divi stores these as on/off values in et_pb_role_settings. A missing flag
	 * is already allowed, except where Divi treats a custom role as denied.
	 * This only changes the value returned for the support account. Other roles
	 * stay as saved. Theme Builder and the Role Editor are not turned on here.
	 *
	 * @param mixed $settings Stored role settings.
	 * @return mixed
	 */
	public static function allow_divi_theme_options( $settings ) {
		static $resolving = false;

		if ( $resolving || ! function_exists( 'get_current_user_id' ) ) {
			return $settings;
		}

		$resolving = true;

		try {
			$user_id = get_current_user_id();
			if ( is_int( $user_id ) ) {
				$checked_user_id = $user_id;
			} elseif ( is_string( $user_id ) && is_numeric( $user_id ) ) {
				$checked_user_id = (int) $user_id;
			} else {
				return $settings;
			}

			if ( ! self::user_is_support_account( $checked_user_id ) || ! is_array( $settings ) ) {
				return $settings;
			}

			$role = self::ROLE;
			if ( ! isset( $settings[ $role ] ) || ! is_array( $settings[ $role ] ) ) {
				$settings[ $role ] = array();
			}

			foreach ( self::divi_theme_option_role_caps() as $cap ) {
				$settings[ $role ][ $cap ] = 'on';
			}

			return $settings;
		} finally {
			$resolving = false;
		}
	}

	/**
	 * Divi role flags that gate Theme Options, the Theme Customizer, and their import.
	 *
	 * @return array<int, string>
	 */
	private static function divi_theme_option_role_caps(): array {
		return array(
			'theme_options',
			'theme_customizer',
			'module_customizer',
			'portability',
			'epanel_portability',
			'epanel_temp_portability',
			'et_code_snippets_portability',
			'et_divi_mods_portability',
			'et_extra_mods_portability',
			'divi_library',
			'add_library',
			'save_library',
		);
	}

	/**
	 * Hide theme switching inside the customizer.
	 *
	 * Divi Theme Options and the Theme Customizer stay open. The Themes panel
	 * is how the customizer changes the active theme, so it is removed.
	 *
	 * @param mixed $wp_customize Customizer manager.
	 * @return void
	 */
	public static function lock_customizer_theme_switching( $wp_customize ): void {
		if ( ! is_object( $wp_customize ) || ! method_exists( $wp_customize, 'remove_panel' ) ) {
			return;
		}

		if ( ! function_exists( 'get_current_user_id' ) || ! self::user_is_support_account( get_current_user_id() ) ) {
			return;
		}

		$wp_customize->remove_panel( 'themes' );
	}

	/**
	 * Reject password and XML-RPC login for the support account.
	 *
	 * @param \WP_User|\WP_Error|null $user     Authenticated user, if any.
	 * @param string                  $username Submitted username.
	 * @param string                  $password Submitted password. Unused.
	 * @return \WP_User|\WP_Error|null
	 */
	public static function block_password_auth( $user, $username, $password ) {
		unset( $password );

		if ( $user instanceof \WP_User && self::user_is_support_account( (int) $user->ID ) ) {
			return new \WP_Error(
				'authentication_failed',
				__( '<strong>Error:</strong> Invalid username or password.', 'dsm-supreme-modules-pro-for-divi' )
			);
		}

		$login = is_string( $username ) ? $username : '';
		if ( '' === $login ) {
			return $user;
		}

		$maybe = get_user_by( 'login', $login );
		if ( $maybe instanceof \WP_User && self::user_is_support_account( (int) $maybe->ID ) ) {
			return new \WP_Error(
				'authentication_failed',
				__( '<strong>Error:</strong> Invalid username or password.', 'dsm-supreme-modules-pro-for-divi' )
			);
		}

		return $user;
	}

	/**
	 * Disable password resets for the support account.
	 *
	 * @param bool $allow   Whether reset is allowed.
	 * @param int  $user_id User ID.
	 * @return bool
	 */
	public static function block_password_reset( $allow, $user_id ): bool {
		if ( self::user_is_support_account( (int) $user_id ) ) {
			return false;
		}

		return (bool) $allow;
	}

	/**
	 * Disable application passwords for the support account.
	 *
	 * @param bool     $available Whether application passwords are available.
	 * @param \WP_User $user      User being checked.
	 * @return bool
	 */
	public static function block_application_passwords( $available, $user ): bool {
		if ( $user instanceof \WP_User && self::user_is_support_account( (int) $user->ID ) ) {
			return false;
		}

		return (bool) $available;
	}

	/**
	 * Suppress password and email change notifications for the support account.
	 *
	 * @param bool                         $send Whether to send the email.
	 * @param array<string,mixed>|\WP_User $user User data.
	 * @return bool
	 */
	public static function block_account_email( $send, $user ): bool {
		$user_id = 0;
		if ( $user instanceof \WP_User ) {
			$user_id = (int) $user->ID;
		} elseif ( is_array( $user ) && isset( $user['ID'] ) ) {
			$user_id = (int) $user['ID'];
		}

		if ( self::user_is_support_account( $user_id ) ) {
			return false;
		}

		return (bool) $send;
	}

	/**
	 * Suppress new-user emails for the support account.
	 *
	 * @param bool     $send Whether to send.
	 * @param \WP_User $user New user.
	 * @return bool
	 */
	public static function block_new_user_email( $send, $user ): bool {
		if ( $user instanceof \WP_User && self::user_is_support_account( (int) $user->ID ) ) {
			return false;
		}

		return (bool) $send;
	}

	/**
	 * Block user, WordPress-setting, and theme writes in the REST API.
	 *
	 * The manage_options and switch_themes capabilities stay on so Divi Theme Options
	 * and Divi Supreme settings can open. These routes are the API equivalents
	 * of the screens that stay closed.
	 *
	 * @param mixed            $result  Short-circuit result.
	 * @param \WP_REST_Server  $server  REST server.
	 * @param \WP_REST_Request $request Request.
	 * @return mixed
	 */
	public static function block_rest_user_routes( $result, $server, $request ) {
		unset( $server );

		if ( ! self::user_is_support_account( get_current_user_id() ) || ! $request instanceof \WP_REST_Request ) {
			return $result;
		}

		$route  = (string) $request->get_route();
		$method = strtoupper( (string) $request->get_method() );
		$writes = array( 'POST', 'PUT', 'PATCH', 'DELETE' );

		if ( ! in_array( $method, $writes, true ) ) {
			return $result;
		}

		$blocked = array(
			'/wp/v2/users'    => __( 'The temporary support account cannot manage users.', 'dsm-supreme-modules-pro-for-divi' ),
			'/wp/v2/settings' => __( 'The temporary support account cannot change WordPress settings.', 'dsm-supreme-modules-pro-for-divi' ),
			'/wp/v2/themes'   => __( 'The temporary support account cannot change themes.', 'dsm-supreme-modules-pro-for-divi' ),
		);

		foreach ( $blocked as $prefix => $message ) {
			if ( 0 === strpos( $route, $prefix ) ) {
				return new \WP_Error(
					'dsm_support_rest_forbidden',
					$message,
					array( 'status' => 403 )
				);
			}
		}

		return $result;
	}

	/**
	 * Hide role assignment from the support account.
	 *
	 * @param array<string, mixed> $roles Editable roles.
	 * @return array<string, mixed>
	 */
	public static function lock_editable_roles( array $roles ): array {
		if ( self::user_is_support_account( get_current_user_id() ) ) {
			return array();
		}

		return $roles;
	}

	/**
	 * Label the account on the Users screen for real administrators.
	 *
	 * @param array<string, string> $actions Row actions.
	 * @param \WP_User              $user    Listed user.
	 * @return array<string, string>
	 */
	public static function mark_support_user_row( array $actions, $user ): array {
		if ( $user instanceof \WP_User && self::user_is_support_account( (int) $user->ID ) ) {
			$actions['dsm_support_account'] = '<span>' . esc_html__( 'Temporary support account', 'dsm-supreme-modules-pro-for-divi' ) . '</span>';
		}

		return $actions;
	}

	/**
	 * Refuse sensitive option writes from the support account.
	 *
	 * @param mixed $value     Proposed value.
	 * @param mixed $old_value Current value.
	 * @return mixed
	 */
	public static function reject_support_option_change( $value, $old_value ) {
		if ( self::$allow_role_update && self::is_role_option_filter() ) {
			return $value;
		}

		if ( self::user_is_support_account( get_current_user_id() ) ) {
			return $old_value;
		}

		return $value;
	}

	/**
	 * Remove menus the support account must not use.
	 *
	 * @return void
	 */
	public static function lock_admin_menus(): void {
		if ( ! self::user_is_support_account( get_current_user_id() ) ) {
			return;
		}

		remove_menu_page( 'users.php' );
		self::keep_customizer_menu();
		foreach ( self::core_settings_screens() as $screen ) {
			remove_submenu_page( 'options-general.php', $screen );
		}
		if ( ! self::settings_menu_has_plugin_page() ) {
			remove_menu_page( 'options-general.php' );
		}
		remove_submenu_page( 'et_divi_options', self::role_editor_page_slug() );
		remove_submenu_page( 'tools.php', 'import.php' );
		remove_submenu_page( 'tools.php', 'export.php' );
		remove_submenu_page( 'tools.php', 'export-personal-data.php' );
		remove_submenu_page( 'tools.php', 'erase-personal-data.php' );
		remove_submenu_page( 'index.php', 'update-core.php' );
	}

	/**
	 * Hard-block screens for users, theme switching, WordPress settings, and exports.
	 *
	 * Divi Theme Options (admin.php?page=et_divi_options), the Theme Customizer,
	 * permalinks, Divi Supreme settings, and plugin settings screens stay open.
	 * General, Writing, Reading, Discussion, Media, and Privacy stay closed.
	 * Plugin install, the plugin file editor, and plugin actions on update.php stay open.
	 * Theme and core actions on that shared screen stay closed.
	 *
	 * @return void
	 */
	public static function block_support_screens(): void {
		if ( ! self::user_is_support_account( get_current_user_id() ) ) {
			return;
		}

		global $pagenow;

		if ( ! is_string( $pagenow ) ) {
			return;
		}

		if ( 'admin.php' === $pagenow ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, ET.Sniffs.ValidatedSanitizedInput.InputNotSanitized -- Screen gate only. Non-strings are ignored and sanitize_key() restricts the slug.
			$raw_page = isset( $_GET['page'] ) ? wp_unslash( $_GET['page'] ) : '';
			$page     = is_string( $raw_page ) ? sanitize_key( $raw_page ) : '';
			if ( in_array( $page, self::blocked_support_pages(), true ) ) {
				self::deny_support_screen();
			}
		}

		if ( 'update.php' === $pagenow ) {
			if ( ! in_array( self::requested_update_action(), self::plugin_update_actions(), true ) ) {
				self::deny_support_screen();
			}
			return;
		}

		$blocked = array(
			'users.php',
			'user-new.php',
			'user-edit.php',
			'profile.php',
			'themes.php',
			'theme-install.php',
			'theme-editor.php',
			'site-editor.php',
			'widgets.php',
			'nav-menus.php',
			'options-writing.php',
			'options-reading.php',
			'options-discussion.php',
			'options-media.php',
			'options-privacy.php',
			'update-core.php',
			'import.php',
			'export.php',
			'export-personal-data.php',
			'erase-personal-data.php',
			'privacy.php',
		);

		if ( in_array( $pagenow, $blocked, true ) ) {
			self::deny_support_screen();
		}

		if ( 'options-general.php' === $pagenow && ! self::is_plugin_settings_page( self::request_admin_slug( 'page' ) ) ) {
			self::deny_support_screen();
		}

		if ( 'options.php' === $pagenow && ! self::is_plugin_settings_page( self::request_admin_slug( 'option_page' ) ) ) {
			self::deny_support_screen();
		}
	}

	/**
	 * Persistent warning for real administrators while access is on.
	 *
	 * @return void
	 */
	public static function render_admin_notice(): void {
		if ( ! self::current_user_can_manage() || ! self::is_active() ) {
			return;
		}

		$state   = self::get_state();
		$expires = is_array( $state ) ? (int) ( $state['expires_at'] ?? 0 ) : 0;
		?>
		<div class="notice notice-warning">
			<p>
				<?php
				echo esc_html(
					sprintf(
						/* translators: %s: expiration date and time. */
						__( 'Temporary support access is enabled until %s. Disable it when support is finished.', 'dsm-supreme-modules-pro-for-divi' ),
						self::format_time( $expires )
					)
				);
				?>
			</p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<?php wp_nonce_field( 'dsm_support_access_disable' ); ?>
				<input type="hidden" name="action" value="dsm_support_access_disable" />
				<p>
					<button type="submit" class="button button-secondary">
						<?php esc_html_e( 'Disable support access', 'dsm-supreme-modules-pro-for-divi' ); ?>
					</button>
				</p>
			</form>
		</div>
		<?php
	}

	/**
	 * Tell the support session when it expires. No link and no disable control.
	 *
	 * @return void
	 */
	public static function render_support_user_notice(): void {
		$user_id = get_current_user_id();
		if ( ! self::user_is_support_account( $user_id ) || ! self::is_active() ) {
			return;
		}

		$state   = self::get_state();
		$expires = is_array( $state ) ? (int) ( $state['expires_at'] ?? 0 ) : 0;
		?>
		<div class="notice notice-warning">
			<p>
				<?php
				echo esc_html(
					sprintf(
						/* translators: %s: expiration date and time. */
						__( 'You are signed in with temporary Divi Supreme support access. This account expires at %s.', 'dsm-supreme-modules-pro-for-divi' ),
						self::format_time( $expires )
					)
				);
				?>
			</p>
			<p>
				<?php esc_html_e( 'Divi Theme Options, the Theme Customizer, permalinks, Divi Supreme settings, and plugin settings are available. General Settings, users, theme switching, and this access grant stay locked.', 'dsm-supreme-modules-pro-for-divi' ); ?>
			</p>
		</div>
		<?php
	}

	/**
	 * Caps removed from the cloned administrator role and forced off at runtime.
	 *
	 * Plugin install, upload, update, and the plugin file editor stay allowed.
	 * Divi Theme Options and Divi Supreme settings stay allowed through
	 * allowed_check_caps(). Deleting a plugin stays denied. Theme switching stays
	 * closed by the Themes screen and by refusing stylesheet and template writes.
	 * Permalinks stays open. General, Writing, Reading, Discussion, Media, and
	 * Privacy stay closed by screen even where a capability is kept.
	 *
	 * @return array<int, string>
	 */
	private static function denied_caps(): array {
		return array(
			'create_users',
			'edit_users',
			'delete_users',
			'promote_users',
			'remove_users',
			'list_users',
			'delete_plugins',
			'install_themes',
			'upload_themes',
			'delete_themes',
			'update_themes',
			'edit_themes',
			'edit_files',
			'update_core',
			'import',
			'export',
			'export_others_personal_data',
			'erase_others_personal_data',
			'unfiltered_html',
			'manage_network',
			'manage_network_users',
			'manage_network_plugins',
			'manage_network_themes',
			'manage_network_options',
			'manage_sites',
			'upgrade_network',
			'delete_site',
		);
	}

	/**
	 * Plugin caps the support account keeps. Delete is not included.
	 *
	 * @return array<int, string>
	 */
	private static function allowed_plugin_caps(): array {
		return array(
			'install_plugins',
			'upload_plugins',
			'update_plugins',
			'edit_plugins',
		);
	}

	/**
	 * Built-in caps for Divi Theme Options and Divi Supreme settings.
	 *
	 * Used when the check-cap filter cannot run, including a nested capability check.
	 *
	 * @return array<int, string>
	 */
	private static function builtin_check_caps(): array {
		return array(
			'manage_options',
			'edit_theme_options',
			'switch_themes',
		);
	}

	/**
	 * Caps required to check Divi Theme Options and Divi Supreme settings.
	 *
	 * Divi registers Theme Options with switch_themes and, since Divi 4.25.2,
	 * hides that screen from roles without edit_theme_options. Divi Supreme
	 * settings use manage_options. Denied caps cannot be restored here.
	 *
	 * @return array<int, string>
	 */
	private static function allowed_check_caps(): array {
		$caps = self::builtin_check_caps();

		if ( function_exists( 'apply_filters' ) ) {
			/**
			 * Filter the capabilities the temporary support account keeps for site checks.
			 *
			 * The manage_options, edit_theme_options, and switch_themes capabilities are the defaults.
			 * Capabilities in denied_caps() are removed after this filter.
			 *
			 * @param array<int, string> $caps Capability names.
			 */
			$filtered = apply_filters( 'dsm_support_access_check_caps', $caps );
			if ( is_array( $filtered ) ) {
				$caps = $filtered;
			}
		}

		$denied = self::denied_caps();
		$clean  = array();

		foreach ( $caps as $cap ) {
			if ( ! is_string( $cap ) || '' === $cap || in_array( $cap, $denied, true ) ) {
				continue;
			}

			$clean[] = $cap;
		}

		return array_values( array_unique( $clean ) );
	}

	/**
	 * Caps forced on after the deny list, including for roles saved earlier.
	 *
	 * Resolved once per request. user_has_cap calls this on every check. A nested
	 * call, from the check-cap filter itself, uses the built-in list so a
	 * capability check cannot recurse through map_meta_cap.
	 *
	 * @return array<int, string>
	 */
	private static function caps_forced_on(): array {
		static $resolved  = null;
		static $resolving = false;

		if ( is_array( $resolved ) ) {
			return $resolved;
		}

		$plugin_caps = self::allowed_plugin_caps();

		if ( $resolving ) {
			return array_values( array_unique( array_merge( $plugin_caps, self::builtin_check_caps() ) ) );
		}

		$resolving = true;

		try {
			$resolved = array_values(
				array_unique(
					array_merge( $plugin_caps, self::allowed_check_caps() )
				)
			);
		} finally {
			$resolving = false;
		}

		return $resolved;
	}

	/**
	 * Divi Role Editor slug. Divi allows this slug to be filtered.
	 *
	 * @return string
	 */
	private static function role_editor_page_slug(): string {
		$slug = 'et_divi_role_editor';

		if ( function_exists( 'apply_filters' ) ) {
			$filtered = apply_filters( 'et_divi_role_editor_page', $slug );
			if ( is_string( $filtered ) && '' !== $filtered ) {
				$slug = $filtered;
			}
		}

		return function_exists( 'sanitize_key' ) ? sanitize_key( $slug ) : $slug;
	}

	/**
	 * Admin page slugs the support account cannot open.
	 *
	 * Divi Theme Options and Divi Supreme settings are not in this list.
	 *
	 * @return array<int, string>
	 */
	private static function blocked_support_pages(): array {
		$pages = array( self::role_editor_page_slug() );

		if ( function_exists( 'apply_filters' ) ) {
			/**
			 * Filter admin page slugs blocked for the temporary support account.
			 *
			 * The default is the Divi Role Editor. Do not add et_divi_options or
			 * divi_supreme_settings. Those screens are how support checks the site.
			 *
			 * @param array<int, string> $pages Page slugs.
			 */
			$filtered = apply_filters( 'dsm_support_access_blocked_pages', $pages );
			if ( is_array( $filtered ) ) {
				$pages = $filtered;
			}
		}

		$clean = array();

		foreach ( $pages as $page ) {
			if ( ! is_string( $page ) || '' === $page ) {
				continue;
			}

			$clean[] = function_exists( 'sanitize_key' ) ? sanitize_key( $page ) : $page;
		}

		return array_values( array_unique( $clean ) );
	}

	/**
	 * Core Settings screens that stay closed for the support account.
	 *
	 * Permalinks is omitted so support can open and save that screen.
	 *
	 * @return array<int, string>
	 */
	private static function core_settings_screens(): array {
		return array(
			'options-general.php',
			'options-writing.php',
			'options-reading.php',
			'options-discussion.php',
			'options-media.php',
			'options-privacy.php',
		);
	}

	/**
	 * WordPress option groups that stay closed for the support account.
	 *
	 * The permalink group stays open so Settings → Permalinks can save.
	 *
	 * @return array<int, string>
	 */
	private static function core_settings_groups(): array {
		return array(
			'general',
			'writing',
			'reading',
			'discussion',
			'media',
			'options',
			'privacy',
		);
	}

	/**
	 * Keep Appearance → Customize and hide theme switching from that menu.
	 *
	 * The parent item opens the customizer. Themes, the theme file editor,
	 * widgets, and menus are removed. A direct visit to themes.php stays blocked.
	 *
	 * @return void
	 */
	private static function keep_customizer_menu(): void {
		global $menu;

		remove_submenu_page( 'themes.php', 'themes.php' );
		remove_submenu_page( 'themes.php', 'theme-install.php' );
		remove_submenu_page( 'themes.php', 'theme-editor.php' );
		remove_submenu_page( 'themes.php', 'widgets.php' );
		remove_submenu_page( 'themes.php', 'nav-menus.php' );
		remove_submenu_page( 'themes.php', 'site-editor.php' );

		if ( ! is_array( $menu ) ) {
			return;
		}

		foreach ( $menu as $index => $item ) {
			if ( ! is_array( $item ) || ! isset( $item[2] ) || 'themes.php' !== $item[2] ) {
				continue;
			}

			// phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- Point Appearance at the customizer for this support session.
			$menu[ $index ][2] = 'customize.php';
		}
	}

	/**
	 * Whether the Settings menu still contains a plugin screen.
	 *
	 * Core Settings items are removed first. The menu stays when any other
	 * settings screen remains.
	 *
	 * @return bool
	 */
	private static function settings_menu_has_plugin_page(): bool {
		global $submenu;

		if ( ! isset( $submenu['options-general.php'] ) || ! is_array( $submenu['options-general.php'] ) ) {
			return false;
		}

		foreach ( $submenu['options-general.php'] as $item ) {
			if ( ! is_array( $item ) || ! isset( $item[2] ) || ! is_string( $item[2] ) ) {
				continue;
			}

			if ( self::is_plugin_settings_page( self::submenu_slug_to_page( $item[2] ) ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Page slug from a submenu entry.
	 *
	 * Entries are either a plugin slug or a URL that includes page=.
	 *
	 * @param string $slug Submenu slug.
	 * @return string
	 */
	private static function submenu_slug_to_page( string $slug ): string {
		$page  = $slug;
		$query = wp_parse_url( $slug, PHP_URL_QUERY );

		if ( is_string( $query ) && '' !== $query ) {
			$args = array();
			wp_parse_str( $query, $args );
			if ( isset( $args['page'] ) && is_string( $args['page'] ) ) {
				$page = $args['page'];
			}
		}

		return function_exists( 'sanitize_key' ) ? sanitize_key( $page ) : strtolower( $page );
	}

	/**
	 * Page or Settings API group from the current admin request.
	 *
	 * Non-strings are ignored. An array query value must not be cast.
	 *
	 * @param string $key Request key, page or option_page.
	 * @return string
	 */
	private static function request_admin_slug( string $key ): string {
		// phpcs:disable WordPress.Security.NonceVerification.Missing, WordPress.Security.NonceVerification.Recommended, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, ET.Sniffs.ValidatedSanitizedInput.InputNotSanitized -- Screen gate only. Non-strings are ignored and sanitize_key() restricts the slug.
		$raw = null;
		if ( isset( $_POST[ $key ] ) ) {
			$raw = wp_unslash( $_POST[ $key ] );
		} elseif ( isset( $_GET[ $key ] ) ) {
			$raw = wp_unslash( $_GET[ $key ] );
		}
		// phpcs:enable WordPress.Security.NonceVerification.Missing, WordPress.Security.NonceVerification.Recommended, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, ET.Sniffs.ValidatedSanitizedInput.InputNotSanitized

		if ( ! is_string( $raw ) ) {
			return '';
		}

		return function_exists( 'sanitize_key' ) ? sanitize_key( $raw ) : strtolower( $raw );
	}

	/**
	 * Whether this admin page is a plugin settings screen.
	 *
	 * Any non-empty slug is allowed except WordPress core Settings screens and
	 * option groups. Unexpected types are ignored.
	 *
	 * @param mixed $page Page slug or Settings API group. Unexpected types are ignored.
	 * @return bool
	 */
	public static function is_plugin_settings_page( $page ): bool {
		if ( ! is_string( $page ) || '' === $page ) {
			return false;
		}

		$page = function_exists( 'sanitize_key' ) ? sanitize_key( $page ) : strtolower( $page );

		return '' !== $page && ! self::is_core_settings_slug( $page );
	}

	/**
	 * Whether a slug is a WordPress core Settings screen or option group.
	 *
	 * @param string $slug Sanitized page slug or option group.
	 * @return bool
	 */
	private static function is_core_settings_slug( string $slug ): bool {
		if ( in_array( $slug, self::core_settings_groups(), true ) ) {
			return true;
		}

		foreach ( self::core_settings_screens() as $screen ) {
			if ( $slug === $screen ) {
				return true;
			}

			$screen_slug = function_exists( 'sanitize_key' ) ? sanitize_key( $screen ) : strtolower( $screen );
			if ( '' !== $screen_slug && $slug === $screen_slug ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Plugin actions on update.php that install, upload, update, or activate.
	 *
	 * Theme and core actions are omitted so the shared screen stays closed for those.
	 *
	 * @return array<int, string>
	 */
	private static function plugin_update_actions(): array {
		return array(
			'upgrade-plugin',
			'update-selected',
			'install-plugin',
			'upload-plugin',
			'upload-plugin-cancel-overwrite',
			'activate-plugin',
		);
	}

	/**
	 * Action argument on update.php. Empty when the request has none.
	 *
	 * @return string
	 */
	private static function requested_update_action(): string {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, ET.Sniffs.ValidatedSanitizedInput.InputNotSanitized -- Screen gate only. sanitize_key() restricts the action, and core checks its nonce before changing a plugin.
		$action = isset( $_REQUEST['action'] ) ? wp_unslash( $_REQUEST['action'] ) : '';
		if ( ! is_string( $action ) ) {
			return '';
		}

		return sanitize_key( $action );
	}

	/**
	 * Add site-check and plugin caps onto a role saved before they were allowed.
	 *
	 * @return void
	 */
	private static function grant_plugin_role_caps(): void {
		$role = get_role( self::ROLE );

		self::$allow_role_update = true;
		try {
			if ( ! $role instanceof \WP_Role ) {
				self::ensure_role();
				return;
			}

			foreach ( self::caps_forced_on() as $cap ) {
				if ( empty( $role->capabilities[ $cap ] ) ) {
					$role->add_cap( $cap );
				}
			}
		} finally {
			self::$allow_role_update = false;
		}
	}

	/**
	 * Whether the current filter is the roles option this class is allowed to rewrite.
	 *
	 * @return bool
	 */
	private static function is_role_option_filter(): bool {
		global $wpdb;

		if ( ! $wpdb instanceof \wpdb ) {
			return false;
		}

		return current_filter() === 'pre_update_option_' . $wpdb->prefix . 'user_roles';
	}

	/**
	 * Stop a support session from opening a blocked admin screen.
	 *
	 * @return void
	 */
	private static function deny_support_screen(): void {
		wp_die(
			esc_html__( 'The temporary support account cannot open this screen.', 'dsm-supreme-modules-pro-for-divi' ),
			'',
			array( 'response' => 403 )
		);
	}

	/**
	 * Options the support account must not change.
	 *
	 * Divi Theme Options and Divi Supreme settings are stored under other names
	 * and stay writable. The stylesheet and template options stay locked so the
	 * active theme cannot be switched. et_pb_role_settings is the Divi Role Editor.
	 *
	 * @return array<int, string>
	 */
	private static function sensitive_options(): array {
		return array(
			'admin_email',
			'new_admin_email',
			'users_can_register',
			'default_role',
			'siteurl',
			'home',
			'stylesheet',
			'template',
			'et_pb_role_settings',
			self::OPTION,
			self::USER_POINTER,
		);
	}

	/**
	 * Allowed window lengths.
	 *
	 * @return array<int, int>
	 */
	private static function allowed_hours(): array {
		return array( 48, 72, self::MAX_HOURS );
	}

	/**
	 * Create the account and store the encrypted token.
	 *
	 * @param int    $hours    Window length.
	 * @param string $delivery link or email.
	 * @return true|\WP_Error
	 */
	private static function provision( int $hours, string $delivery ) {
		self::ensure_role();

		$existing = get_user_by( 'email', self::SUPPORT_EMAIL );
		if ( $existing instanceof \WP_User ) {
			if ( ! self::user_is_support_account( (int) $existing->ID ) ) {
				return new \WP_Error(
					'dsm_support_email_in_use',
					__( 'A WordPress user already uses the support email address. Change that user before enabling temporary support access.', 'dsm-supreme-modules-pro-for-divi' )
				);
			}

			self::delete_support_user( (int) $existing->ID, array( 'enabled_by' => get_current_user_id() ) );
		}

		$login = self::unique_login();
		if ( '' === $login ) {
			return new \WP_Error(
				'dsm_support_login_failed',
				__( 'The support account could not be created.', 'dsm-supreme-modules-pro-for-divi' )
			);
		}

		$token = self::generate_token();
		if ( is_wp_error( $token ) ) {
			return $token;
		}

		$cipher = self::encrypt_token( $token );
		if ( '' === $cipher ) {
			return new \WP_Error(
				'dsm_support_encrypt_failed',
				__( 'The support link could not be stored.', 'dsm-supreme-modules-pro-for-divi' )
			);
		}

		$display = __( 'Divi Supreme Support', 'dsm-supreme-modules-pro-for-divi' );
		$user_id = wp_insert_user(
			array(
				'user_login'   => $login,
				'user_pass'    => wp_generate_password( 64, true, true ),
				'user_email'   => self::SUPPORT_EMAIL,
				'display_name' => $display,
				'nickname'     => $display,
				'role'         => self::ROLE,
			)
		);

		if ( is_wp_error( $user_id ) ) {
			return $user_id;
		}

		$user_id = (int) $user_id;
		self::lock_password( $user_id );
		update_user_meta( $user_id, self::USER_META, '1' );
		self::$support_users[ $user_id ] = true;

		if ( is_multisite() ) {
			add_user_to_blog( get_current_blog_id(), $user_id, self::ROLE );
		} else {
			$user = new \WP_User( $user_id );
			$user->set_role( self::ROLE );
		}

		$now   = time();
		$state = array(
			'enabled'        => 1,
			'user_id'        => $user_id,
			'enabled_by'     => get_current_user_id(),
			'enabled_at'     => $now,
			'expires_at'     => $now + ( $hours * HOUR_IN_SECONDS ),
			'duration_hours' => $hours,
			'delivery'       => 'email' === $delivery ? 'email' : 'link',
			'mail_sent'      => 0,
			'token_hash'     => self::token_hash( $token ),
			'token_cipher'   => $cipher,
			'login_count'    => 0,
			'last_login_at'  => 0,
			'last_login_ip'  => '',
		);

		update_option( self::OPTION, $state, false );
		update_option( self::USER_POINTER, $user_id, false );
		self::mark_grant_present( true );
		self::schedule_expiry( (int) $state['expires_at'] );

		return true;
	}

	/**
	 * Clone administrator, then strip dangerous caps again after the filter.
	 *
	 * @return void
	 */
	private static function ensure_role(): void {
		$admin = get_role( 'administrator' );
		$caps  = ( $admin instanceof \WP_Role ) ? $admin->capabilities : array();
		if ( ! is_array( $caps ) ) {
			$caps = array();
		}

		foreach ( self::denied_caps() as $cap ) {
			unset( $caps[ $cap ] );
		}

		/**
		 * Filter the temporary support role capabilities before the hard deny list is reapplied.
		 *
		 * User, theme-file, core, import, and unscoped file caps are removed again after this filter.
		 * Plugin install, upload, update, and edit are granted after that, along with the
		 * caps required for Divi Theme Options and Divi Supreme settings.
		 *
		 * @param array<string, bool> $caps Role capabilities.
		 */
		$filtered = apply_filters( 'dsm_support_access_role_caps', $caps );
		if ( ! is_array( $filtered ) ) {
			$filtered = array();
		}

		foreach ( self::denied_caps() as $cap ) {
			unset( $filtered[ $cap ] );
		}

		foreach ( self::caps_forced_on() as $cap ) {
			$filtered[ $cap ] = true;
		}

		$filtered['read'] = true;

		remove_role( self::ROLE );
		add_role(
			self::ROLE,
			__( 'Divi Supreme Support', 'dsm-supreme-modules-pro-for-divi' ),
			$filtered
		);
	}

	/**
	 * Build an unused login.
	 *
	 * @return string
	 */
	private static function unique_login(): string {
		for ( $attempt = 0; $attempt < 5; $attempt++ ) {
			$login = 'dsm-support-' . strtolower( wp_generate_password( 8, false, false ) );
			if ( ! username_exists( $login ) ) {
				return $login;
			}
		}

		return '';
	}

	/**
	 * Store an impossible password hash.
	 *
	 * @param int $user_id User ID.
	 * @return void
	 */
	private static function lock_password( int $user_id ): void {
		global $wpdb;

		if ( ! $wpdb instanceof \wpdb || $user_id <= 0 ) {
			return;
		}

		$wpdb->update(
			$wpdb->users,
			array( 'user_pass' => '*' ),
			array( 'ID' => $user_id ),
			array( '%s' ),
			array( '%d' )
		);
		clean_user_cache( $user_id );
	}

	/**
	 * Schedule the expiry event.
	 *
	 * @param int $timestamp Unix timestamp.
	 * @return void
	 */
	private static function schedule_expiry( int $timestamp ): void {
		wp_clear_scheduled_hook( self::CRON_HOOK );
		if ( $timestamp > time() ) {
			wp_schedule_single_event( $timestamp, self::CRON_HOOK );
		}
	}

	/**
	 * Verify a token and start a session cookie.
	 *
	 * @param string $token Sanitized token.
	 * @return void
	 */
	private static function redeem( string $token ): void {
		$limited = self::is_rate_limited();
		$state   = self::get_state();
		$active  = self::is_state_active( $state ) && is_array( $state );
		$user_id = $active ? (int) $state['user_id'] : 0;
		$match   = self::token_matches( $token, $active ? (string) $state['token_hash'] : '' );

		$accepted = $match && $active && is_array( $state ) && self::transport_allows_access() && self::user_is_support_account( $user_id );
		if ( ! $accepted ) {
			if ( ! $limited ) {
				self::bump_rate_limit();
			}
			self::render_login_document( self::generic_login_error() );
		}

		$state['login_count']   = (int) ( $state['login_count'] ?? 0 ) + 1;
		$state['last_login_at'] = time();
		$ip                     = self::client_ip();
		$state['last_login_ip'] = ( 'unknown' === $ip ) ? '' : $ip;
		self::mark_grant_present( true );
		update_option( self::OPTION, $state, false );

		wp_set_current_user( $user_id );
		wp_set_auth_cookie( $user_id, false, self::auth_cookie_secure() );
		$user = get_userdata( $user_id );
		if ( $user instanceof \WP_User ) {
			do_action( 'wp_login', $user->user_login, $user );
		}

		self::notify( 'login' );

		wp_safe_redirect( admin_url() );
		exit;
	}

	/**
	 * Constant-time token check. Inactive grants compare against a dummy hash.
	 *
	 * @param string $token    Submitted token.
	 * @param string $expected Stored HMAC, or empty when inactive.
	 * @return bool
	 */
	private static function token_matches( string $token, string $expected ): bool {
		if ( '' === $token ) {
			$expected = self::token_hash( 'dsm-support-inactive' );
			$token    = 'dsm-support-empty';
		} elseif ( '' === $expected ) {
			$expected = self::token_hash( 'dsm-support-inactive' );
		}

		$actual = self::token_hash( $token );
		if ( strlen( $expected ) !== strlen( $actual ) ) {
			$expected = self::token_hash( 'dsm-support-inactive' );
		}

		return hash_equals( $expected, $actual );
	}

	/**
	 * Whether this IP is over the failed-attempt limit.
	 *
	 * @return bool
	 */
	private static function is_rate_limited(): bool {
		return (int) get_transient( self::rate_key() ) >= self::RATE_LIMIT;
	}

	/**
	 * Count a failed redeem for this IP.
	 *
	 * @return void
	 */
	private static function bump_rate_limit(): void {
		$key   = self::rate_key();
		$count = (int) get_transient( $key );
		set_transient( $key, $count + 1, self::RATE_WINDOW );
	}

	/**
	 * Transient key for the client IP.
	 *
	 * @return string
	 */
	private static function rate_key(): string {
		return 'dsm_sa_rl_' . md5( self::client_ip() );
	}

	/**
	 * Validated remote address, or "unknown".
	 *
	 * @return string
	 */
	private static function client_ip(): string {
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( (string) $_SERVER['REMOTE_ADDR'] ) ) : '';
		if ( false === filter_var( $ip, FILTER_VALIDATE_IP ) ) {
			return 'unknown';
		}

		return $ip;
	}

	/**
	 * Reject cross-site posts of the login form.
	 *
	 * @return bool
	 */
	private static function request_is_cross_site(): bool {
		if ( ! isset( $_SERVER['HTTP_SEC_FETCH_SITE'] ) ) {
			return false;
		}

		$site = strtolower( sanitize_text_field( wp_unslash( (string) $_SERVER['HTTP_SEC_FETCH_SITE'] ) ) );

		return 'cross-site' === $site || 'same-site' === $site;
	}

	/**
	 * Generic failure copy. It does not say whether access is enabled.
	 *
	 * @return string
	 */
	private static function generic_login_error(): string {
		return __( 'This support link is invalid or has expired.', 'dsm-supreme-modules-pro-for-divi' );
	}

	/**
	 * Keep only the token alphabet.
	 *
	 * @param string $token Raw token.
	 * @return string
	 */
	private static function sanitize_token( string $token ): string {
		$token = trim( $token );
		if ( strlen( $token ) < 40 || strlen( $token ) > 128 ) {
			return '';
		}

		if ( 1 !== preg_match( '/^[A-Za-z0-9_-]+$/', $token ) ) {
			return '';
		}

		return $token;
	}

	/**
	 * 256-bit URL-safe token.
	 *
	 * @return string|\WP_Error
	 */
	private static function generate_token() {
		try {
			$raw = random_bytes( 32 );
		} catch ( \Exception $exception ) {
			unset( $exception );
			return new \WP_Error(
				'dsm_support_token_failed',
				__( 'The support link could not be created.', 'dsm-supreme-modules-pro-for-divi' )
			);
		}

		// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- URL-safe token encoding, not obfuscation.
		return rtrim( strtr( base64_encode( $raw ), '+/', '-_' ), '=' );
	}

	/**
	 * HMAC of the token. The raw token is not stored.
	 *
	 * @param string $token Token.
	 * @return string
	 */
	private static function token_hash( string $token ): string {
		return hash_hmac( 'sha256', $token, wp_salt( 'auth' ) );
	}

	/**
	 * AES-256-GCM key derived from the site auth salt.
	 *
	 * @return string
	 */
	private static function encryption_key(): string {
		return hash( 'sha256', wp_salt( 'auth' ) . '|dsm-support-access-v1', true );
	}

	/**
	 * Whether OpenSSL can seal the token.
	 *
	 * @return bool
	 */
	private static function can_encrypt(): bool {
		return function_exists( 'openssl_encrypt' ) && function_exists( 'openssl_decrypt' );
	}

	/**
	 * Encrypt the token for later display to a managing administrator.
	 *
	 * @param string $token Token.
	 * @return string Empty when encryption fails.
	 */
	private static function encrypt_token( string $token ): string {
		if ( ! self::can_encrypt() ) {
			return '';
		}

		try {
			$iv = random_bytes( 12 );
		} catch ( \Exception $exception ) {
			unset( $exception );
			return '';
		}

		$tag    = '';
		$cipher = openssl_encrypt( $token, 'aes-256-gcm', self::encryption_key(), OPENSSL_RAW_DATA, $iv, $tag );
		if ( ! is_string( $cipher ) || ! is_string( $tag ) || 16 !== strlen( $tag ) ) {
			return '';
		}

		// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- Packs the AES-GCM IV, tag, and ciphertext.
		return base64_encode( $iv . $tag . $cipher );
	}

	/**
	 * Decrypt a stored token for an administrator who can manage access.
	 *
	 * @param string $encoded Ciphertext.
	 * @return string
	 */
	private static function decrypt_token( string $encoded ): string {
		if ( ! self::can_encrypt() || '' === $encoded ) {
			return '';
		}

		// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- Unpacks the AES-GCM IV, tag, and ciphertext.
		$raw = base64_decode( $encoded, true );
		if ( ! is_string( $raw ) || strlen( $raw ) < 29 ) {
			return '';
		}

		$iv     = substr( $raw, 0, 12 );
		$tag    = substr( $raw, 12, 16 );
		$cipher = substr( $raw, 28 );
		$plain  = openssl_decrypt( $cipher, 'aes-256-gcm', self::encryption_key(), OPENSSL_RAW_DATA, $iv, $tag );

		return is_string( $plain ) ? $plain : '';
	}

	/**
	 * Login URL with the token in the fragment only.
	 *
	 * @param string $token Token.
	 * @return string
	 */
	private static function login_url_for_token( string $token ): string {
		$base = add_query_arg( 'dsm_support_login', '1', wp_login_url() );

		return $base . '#dsm=' . rawurlencode( $token );
	}

	/**
	 * Whether the support session cookie should be marked secure.
	 *
	 * The is_ssl() check misses HTTPS terminated at a proxy. The site URL is the fallback.
	 *
	 * @return bool
	 */
	private static function auth_cookie_secure(): bool {
		if ( is_ssl() ) {
			return true;
		}

		$scheme = wp_parse_url( home_url(), PHP_URL_SCHEME );

		return is_string( $scheme ) && 'https' === strtolower( $scheme );
	}

	/**
	 * HTTPS is required. Local and development HTTP is allowed with a warning.
	 *
	 * @return bool
	 */
	private static function transport_allows_access(): bool {
		if ( is_ssl() ) {
			return true;
		}

		return self::is_local_environment();
	}

	/**
	 * Whether this request is plain HTTP on a local environment.
	 *
	 * @return bool
	 */
	private static function is_local_http(): bool {
		return ! is_ssl() && self::is_local_environment();
	}

	/**
	 * Local, development, or loopback hosts.
	 *
	 * @return bool
	 */
	private static function is_local_environment(): bool {
		if ( function_exists( 'wp_get_environment_type' ) ) {
			$environment = wp_get_environment_type();
			if ( in_array( $environment, array( 'local', 'development' ), true ) ) {
				return true;
			}
		}

		$host = wp_parse_url( home_url(), PHP_URL_HOST );
		if ( ! is_string( $host ) ) {
			return false;
		}

		$host = strtolower( $host );

		return in_array( $host, array( 'localhost', '127.0.0.1', '::1' ), true );
	}

	/**
	 * Stored grant, or null.
	 *
	 * @return array<string, mixed>|null
	 */
	private static function get_state(): ?array {
		if ( self::frontend_inactive_grant_is_known() ) {
			return null;
		}

		$state = get_option( self::OPTION, null );

		return is_array( $state ) ? $state : null;
	}

	/**
	 * Stored support user ID, or 0.
	 *
	 * @return int
	 */
	private static function user_pointer(): int {
		if ( self::frontend_inactive_grant_is_known() ) {
			return 0;
		}

		return (int) get_option( self::USER_POINTER, 0 );
	}

	/**
	 * Whether this frontend request already knows support access is off.
	 *
	 * Admin and cron still read the grant so expiry and revocation run.
	 *
	 * @return bool
	 */
	private static function frontend_inactive_grant_is_known(): bool {
		if ( is_admin() || wp_doing_cron() ) {
			return false;
		}

		$alloptions = wp_load_alloptions();
		if ( ! is_array( $alloptions ) || ! array_key_exists( self::GRANT_PRESENT_OPTION, $alloptions ) ) {
			return false;
		}

		return '1' !== (string) $alloptions[ self::GRANT_PRESENT_OPTION ];
	}

	/**
	 * Record whether a grant or orphan pointer exists, without autoloading the ciphertext.
	 *
	 * @return void
	 */
	private static function sync_grant_present_flag(): void {
		$state   = self::get_state();
		$present = ( is_array( $state ) && ! empty( $state['enabled'] ) ) || self::user_pointer() > 0;
		self::mark_grant_present( $present );
	}

	/**
	 * Store the autoloaded presence marker.
	 *
	 * @param bool $present Whether a grant or orphan pointer exists.
	 * @return void
	 */
	private static function mark_grant_present( bool $present ): void {
		$value      = $present ? '1' : '0';
		$alloptions = wp_load_alloptions();

		if ( is_array( $alloptions ) && array_key_exists( self::GRANT_PRESENT_OPTION, $alloptions ) && (string) $alloptions[ self::GRANT_PRESENT_OPTION ] === $value ) {
			return;
		}

		update_option( self::GRANT_PRESENT_OPTION, $value, true );
	}

	/**
	 * Whether the stored grant is still inside its window.
	 *
	 * @param array<string, mixed>|null $state Grant.
	 * @return bool
	 */
	private static function is_state_active( ?array $state ): bool {
		if ( ! is_array( $state ) || empty( $state['enabled'] ) ) {
			return false;
		}

		$expires = isset( $state['expires_at'] ) ? (int) $state['expires_at'] : 0;
		$user_id = isset( $state['user_id'] ) ? (int) $state['user_id'] : 0;
		$hash    = isset( $state['token_hash'] ) ? (string) $state['token_hash'] : '';

		return $expires > time() && $user_id > 0 && '' !== $hash;
	}

	/**
	 * Fields the settings screen can refresh after enable, reset, or disable.
	 *
	 * @param bool $include_link Whether to decrypt the link. False for the support account.
	 * @return array<string, mixed>
	 */
	private static function live_state( bool $include_link ): array {
		$state  = self::get_state();
		$active = self::is_state_active( $state );
		$link   = '';

		if ( $include_link && $active && is_array( $state ) ) {
			$token  = self::decrypt_token( (string) ( $state['token_cipher'] ?? '' ) );
			$stored = (string) ( $state['token_hash'] ?? '' );
			$actual = '' !== $token ? self::token_hash( $token ) : '';
			if ( '' !== $actual && strlen( $stored ) === strlen( $actual ) && hash_equals( $stored, $actual ) ) {
				$link = self::login_url_for_token( $token );
			}
		}

		$expires = ( $active && is_array( $state ) ) ? (int) ( $state['expires_at'] ?? 0 ) : 0;
		$last    = ( $active && is_array( $state ) ) ? (int) ( $state['last_login_at'] ?? 0 ) : 0;
		$count   = ( $active && is_array( $state ) ) ? (int) ( $state['login_count'] ?? 0 ) : 0;

		$delivery = ( $active && is_array( $state ) && 'email' === (string) ( $state['delivery'] ?? '' ) ) ? 'email' : 'link';
		$mailed   = $active && is_array( $state ) && ! empty( $state['mail_sent'] );

		return array(
			'active'           => $active,
			'expiresAt'        => $expires,
			'expiresDisplay'   => $expires > 0 ? self::format_time( $expires ) : '',
			'loginUrl'         => $link,
			'loginCount'       => $count,
			'lastLoginDisplay' => $last > 0 ? self::format_time( $last ) : '',
			'lastLoginIp'      => ( $include_link && $active && is_array( $state ) ) ? (string) ( $state['last_login_ip'] ?? '' ) : '',
			'delivery'         => $delivery,
			'mailSent'         => $mailed,
		);
	}

	/**
	 * Site-timezone display.
	 *
	 * @param int $timestamp Unix timestamp.
	 * @return string
	 */
	private static function format_time( int $timestamp ): string {
		if ( $timestamp <= 0 ) {
			return '';
		}

		$date = (string) get_option( 'date_format' );
		$time = (string) get_option( 'time_format' );
		if ( '' === $date ) {
			$date = 'Y-m-d';
		}
		if ( '' === $time ) {
			$time = 'H:i';
		}

		return wp_date( $date . ' ' . $time, $timestamp );
	}

	/**
	 * Duration choices for the settings screen.
	 *
	 * @return array<int, array{hours: int, label: string}>
	 */
	private static function duration_choices(): array {
		return array(
			array(
				'hours' => 48,
				'label' => __( '48 hours', 'dsm-supreme-modules-pro-for-divi' ),
			),
			array(
				'hours' => 72,
				'label' => __( '72 hours', 'dsm-supreme-modules-pro-for-divi' ),
			),
			array(
				'hours' => self::MAX_HOURS,
				'label' => __( '7 days', 'dsm-supreme-modules-pro-for-divi' ),
			),
		);
	}

	/**
	 * Translated UI copy.
	 *
	 * @return array<string, string>
	 */
	private static function ui_strings(): array {
		return array(
			'warningLead'       => __( 'Access is on', 'dsm-supreme-modules-pro-for-divi' ),
			'warningBody'       => __( 'Disable temporary support access as soon as Divi Supreme support is finished. The account and link are removed immediately.', 'dsm-supreme-modules-pro-for-divi' ),
			'confirmLabel'      => __( 'I understand this creates a temporary support account that can open Divi Theme Options, the Theme Customizer, permalinks, Divi Supreme settings, and plugin settings, and can add and edit plugins. I will send the link only to Divi Supreme support and turn it off when the ticket is finished.', 'dsm-supreme-modules-pro-for-divi' ),
			'durationLabel'     => __( 'Access window', 'dsm-supreme-modules-pro-for-divi' ),
			'enable'            => __( 'Turn on access', 'dsm-supreme-modules-pro-for-divi' ),
			'disable'           => __( 'Turn off and remove account', 'dsm-supreme-modules-pro-for-divi' ),
			'reset'             => __( 'Reset link', 'dsm-supreme-modules-pro-for-divi' ),
			'copyLink'          => __( 'Copy link', 'dsm-supreme-modules-pro-for-divi' ),
			'copied'            => __( 'Copied', 'dsm-supreme-modules-pro-for-divi' ),
			'linkHelp'          => __( 'Send it only to Divi Supreme support, never in a public ticket, group, or screenshot. Opening it in this browser signs you out, so test in a private window.', 'dsm-supreme-modules-pro-for-divi' ),
			'expires'           => __( 'Expires', 'dsm-supreme-modules-pro-for-divi' ),
			'lastUsed'          => __( 'Last used', 'dsm-supreme-modules-pro-for-divi' ),
			'neverUsed'         => __( 'Not used yet', 'dsm-supreme-modules-pro-for-divi' ),
			'loginCount'        => __( 'Sign-ins', 'dsm-supreme-modules-pro-for-divi' ),
			'lastIp'            => __( 'IP address', 'dsm-supreme-modules-pro-for-divi' ),
			'httpsRequired'     => __( 'Temporary support access requires HTTPS. Turn on SSL before enabling it.', 'dsm-supreme-modules-pro-for-divi' ),
			'localHttpWarning'  => __( 'This site is using HTTP on a local environment. The link can be read on the network. Use HTTPS before sharing it outside this machine.', 'dsm-supreme-modules-pro-for-divi' ),
			'opensslRequired'   => __( 'The OpenSSL PHP extension is required to store the support link.', 'dsm-supreme-modules-pro-for-divi' ),
			'statusTitle'       => __( 'System status', 'dsm-supreme-modules-pro-for-divi' ),
			'statusHelp'        => __( 'Paste this into your ticket. Passwords, salts, and the support link are left out.', 'dsm-supreme-modules-pro-for-divi' ),
			'copyReport'        => __( 'Copy report', 'dsm-supreme-modules-pro-for-divi' ),
			'downloadReport'    => __( 'Download .txt', 'dsm-supreme-modules-pro-for-divi' ),
			'reportCopied'      => __( 'Report copied', 'dsm-supreme-modules-pro-for-divi' ),
			'cannotManage'      => __( 'The temporary support account can view this report. It cannot enable, reset, or disable support access.', 'dsm-supreme-modules-pro-for-divi' ),
			'linkMissing'       => __( 'The saved link could not be read. Reset the link to create a new one.', 'dsm-supreme-modules-pro-for-divi' ),
			'badgeOn'           => __( 'Access on', 'dsm-supreme-modules-pro-for-divi' ),
			'pillLabel'         => __( 'Support access on', 'dsm-supreme-modules-pro-for-divi' ),
			'accessTitle'       => __( 'Temporary support access', 'dsm-supreme-modules-pro-for-divi' ),
			'accessHelp'        => __( 'A separate login for Divi Supreme support. It can open Divi Theme Options, the Theme Customizer, permalinks, Divi Supreme settings, and plugin settings, and it can add, update, and edit plugins. It cannot manage users, open General, Writing, Reading, Discussion, Media, or Privacy, delete plugins, switch themes, or turn this access on or off.', 'dsm-supreme-modules-pro-for-divi' ),
			'linkLabel'         => __( 'Private support link', 'dsm-supreme-modules-pro-for-divi' ),
			'deliveryLabel'     => __( 'How should the link be shared?', 'dsm-supreme-modules-pro-for-divi' ),
			'deliveryLink'      => __( 'Show the link on this page', 'dsm-supreme-modules-pro-for-divi' ),
			'deliveryLinkHelp'  => __( 'No email is sent. Copy the link into your support reply. This works when the site has no mail server.', 'dsm-supreme-modules-pro-for-divi' ),
			'deliveryEmail'     => self::delivery_email_label(),
			'deliveryEmailHelp' => __( 'Also email the private link to the site admin address. If sending fails, the link is still shown here.', 'dsm-supreme-modules-pro-for-divi' ),
			'emailFailedNote'   => __( 'The link is ready below. Email could not be sent, so copy it from this page.', 'dsm-supreme-modules-pro-for-divi' ),
			'requestFailed'     => __( 'The server did not finish the request. Reload this page. If access is already on, copy the link here. Choose “Show the link on this page” so no email is sent.', 'dsm-supreme-modules-pro-for-divi' ),
			'statusOff'         => __( 'Off', 'dsm-supreme-modules-pro-for-divi' ),
			'durationHelp'      => __( 'The account and link are removed when the time runs out. You can turn access off sooner.', 'dsm-supreme-modules-pro-for-divi' ),
			'enableHint'        => __( 'Only turn this on when support asks for it.', 'dsm-supreme-modules-pro-for-divi' ),
			'enableHintLocked'  => __( 'Tick the box above to continue.', 'dsm-supreme-modules-pro-for-divi' ),
			'showLink'          => __( 'Show full link', 'dsm-supreme-modules-pro-for-divi' ),
			'hideLink'          => __( 'Hide link', 'dsm-supreme-modules-pro-for-divi' ),
			'confirmDisable'    => __( 'Removes the support account and link right away. Support is signed out.', 'dsm-supreme-modules-pro-for-divi' ),
			'confirmDisableBtn' => __( 'Turn off and remove', 'dsm-supreme-modules-pro-for-divi' ),
			'confirmReset'      => __( 'The current link stops working. Send support the new one.', 'dsm-supreme-modules-pro-for-divi' ),
			'cancel'            => __( 'Cancel', 'dsm-supreme-modules-pro-for-divi' ),
			'noSignIns'         => __( 'No sign-ins so far', 'dsm-supreme-modules-pro-for-divi' ),
			'expired'           => __( 'Expired', 'dsm-supreme-modules-pro-for-divi' ),
			'remaining'         =>
				/* translators: 1: whole hours remaining, 2: minutes remaining. */
				__( 'In %1$sh %2$sm', 'dsm-supreme-modules-pro-for-divi' ),
			'rawText'           => __( 'Raw text', 'dsm-supreme-modules-pro-for-divi' ),
			'tableView'         => __( 'Table view', 'dsm-supreme-modules-pro-for-divi' ),
			'flagMemoryLabel'   => __( 'WordPress memory limit', 'dsm-supreme-modules-pro-for-divi' ),
			'flagDebugLabel'    => __( 'WordPress debug', 'dsm-supreme-modules-pro-for-divi' ),
			'flagYes'           => __( 'Yes', 'dsm-supreme-modules-pro-for-divi' ),
			'flagMemoryNote'    => __( 'Below 256M. Large Divi pages can fail to save.', 'dsm-supreme-modules-pro-for-divi' ),
			'flagDebugNote'     => __( 'Turn this off on a live site.', 'dsm-supreme-modules-pro-for-divi' ),
			'flagsOne'          =>
				/* translators: %s: number of settings. */
				_n( '%s setting support may ask about', '%s settings support may ask about', 1, 'dsm-supreme-modules-pro-for-divi' ),
			'flagsMany'         =>
				/* translators: %s: number of settings. */
				_n( '%s setting support may ask about', '%s settings support may ask about', 2, 'dsm-supreme-modules-pro-for-divi' ),
		);
	}

	/**
	 * Chosen share method from the settings screen.
	 *
	 * @return string link or email.
	 */
	private static function requested_delivery(): string {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Caller verified the support-access nonce.
		$delivery = isset( $_POST['delivery'] ) ? sanitize_key( wp_unslash( (string) $_POST['delivery'] ) ) : 'link';

		return 'email' === $delivery ? 'email' : 'link';
	}

	/**
	 * Site admin mailbox, or empty when it is missing.
	 *
	 * @return string
	 */
	private static function site_admin_email(): string {
		$email = get_option( 'admin_email' );
		if ( ! is_string( $email ) || ! is_email( $email ) ) {
			return '';
		}

		return $email;
	}

	/**
	 * Label for the email option, including the destination address.
	 *
	 * @return string
	 */
	private static function delivery_email_label(): string {
		$email = self::site_admin_email();
		if ( '' === $email ) {
			return __( 'Email the link to the site admin', 'dsm-supreme-modules-pro-for-divi' );
		}

		return sprintf(
			/* translators: %s: site admin email address. */
			__( 'Email the link to %s', 'dsm-supreme-modules-pro-for-divi' ),
			$email
		);
	}

	/**
	 * Email the private link only when that option was chosen.
	 *
	 * @param string $delivery link or email.
	 * @return bool|null Null when no email was attempted.
	 */
	private static function maybe_email_link( string $delivery ) {
		if ( 'email' !== $delivery ) {
			return null;
		}

		$sent = self::email_access_link();
		self::remember_mail_result( $sent );

		return $sent;
	}

	/**
	 * Remember whether the last link email was accepted by the mailer.
	 *
	 * @param bool $sent Whether wp_mail accepted the message.
	 * @return void
	 */
	private static function remember_mail_result( bool $sent ): void {
		$state = self::get_state();
		if ( ! is_array( $state ) ) {
			return;
		}

		$state['mail_sent'] = $sent ? 1 : 0;
		update_option( self::OPTION, $state, false );
	}

	/**
	 * Success copy for enable. The link is always stored before this runs.
	 *
	 * @param string    $delivery link or email.
	 * @param bool|null $mail_sent Null when email was not attempted.
	 * @return string
	 */
	private static function enable_message( string $delivery, $mail_sent ): string {
		if ( 'email' === $delivery && true === $mail_sent ) {
			return sprintf(
				/* translators: %s: site admin email address. */
				__( 'Temporary support access is on. The link was emailed to %s and is also shown below.', 'dsm-supreme-modules-pro-for-divi' ),
				self::site_admin_email()
			);
		}

		if ( 'email' === $delivery ) {
			return __( 'Temporary support access is on, but the email could not be sent. Copy the link below. No mail server is required for that.', 'dsm-supreme-modules-pro-for-divi' );
		}

		return __( 'Temporary support access is on. No email was sent. Copy the link below and send it only to Divi Supreme support.', 'dsm-supreme-modules-pro-for-divi' );
	}

	/**
	 * Send the private link to the site admin.
	 *
	 * @return bool
	 */
	private static function email_access_link(): bool {
		$to   = self::site_admin_email();
		$live = self::live_state( true );
		$link = (string) ( $live['loginUrl'] ?? '' );
		if ( '' === $to || '' === $link ) {
			return false;
		}

		$site_name = wp_specialchars_decode( (string) get_bloginfo( 'name' ), ENT_QUOTES );
		$subject   = sprintf(
			/* translators: %s: site name. */
			__( '[%s] Temporary support link', 'dsm-supreme-modules-pro-for-divi' ),
			$site_name
		);
		$body    = __( 'Temporary support access is on. Forward this private link only to Divi Supreme support, then turn access off when the ticket is finished.', 'dsm-supreme-modules-pro-for-divi' );
		$body   .= "\n\n" . $link . "\n\n";
		$expires = (string) ( $live['expiresDisplay'] ?? '' );
		if ( '' !== $expires ) {
			$body .= sprintf(
				/* translators: %s: expiration date and time. */
				__( 'Expires: %s', 'dsm-supreme-modules-pro-for-divi' ),
				$expires
			) . "\n";
		}
		$body .= admin_url( 'admin.php?page=divi_supreme_settings&tab=dsm_support' ) . "\n";

		return self::send_mail( $to, $subject, $body );
	}

	/**
	 * Send one message without letting a mailer failure break the request.
	 *
	 * @param string $to      Recipient.
	 * @param string $subject Subject.
	 * @param string $body    Plain-text body.
	 * @return bool
	 */
	private static function send_mail( string $to, string $subject, string $body ): bool {
		if ( ! function_exists( 'wp_mail' ) || ! is_email( $to ) ) {
			return false;
		}

		$limit_timeout = static function ( $phpmailer ): void {
			if ( ! is_object( $phpmailer ) ) {
				return;
			}

			// Timeout covers the socket connect. Timelimit covers stream_select while reading SMTP replies.
			// The default Timelimit is 300 seconds, which hits max_execution_time and kills the login request.
			$phpmailer->Timeout = 8; // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- PHPMailer names this property Timeout.
			if ( ! is_callable( array( $phpmailer, 'getSMTPInstance' ) ) ) {
				return;
			}

			$smtp = $phpmailer->getSMTPInstance();
			if ( is_object( $smtp ) ) {
				$smtp->Timelimit = 8; // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- PHPMailer names this property Timelimit.
			}
		};

		add_action( 'phpmailer_init', $limit_timeout );
		$level = ob_get_level();
		$sent  = false;

		try {
			ob_start();
			$sent = wp_mail( $to, $subject, $body );
		} catch ( \Throwable $throwable ) {
			unset( $throwable );
			$sent = false;
		} finally {
			while ( ob_get_level() > $level ) {
				ob_end_clean();
			}
			remove_action( 'phpmailer_init', $limit_timeout );
		}

		return true === $sent;
	}

	/**
	 * Mail the site admin. The message never contains the link or token.
	 *
	 * @param string $reason Event key.
	 * @return void
	 */
	private static function notify( string $reason ): void {
		if ( 'uninstall' === $reason ) {
			return;
		}

		$admin_email = get_option( 'admin_email' );
		if ( ! is_string( $admin_email ) || ! is_email( $admin_email ) ) {
			return;
		}

		$subjects = array(
			'enabled'     =>
				/* translators: %s: site name. */
				__( '[%s] Temporary support access enabled', 'dsm-supreme-modules-pro-for-divi' ),
			'disabled'    =>
				/* translators: %s: site name. */
				__( '[%s] Temporary support access disabled', 'dsm-supreme-modules-pro-for-divi' ),
			'expired'     =>
				/* translators: %s: site name. */
				__( '[%s] Temporary support access expired', 'dsm-supreme-modules-pro-for-divi' ),
			'reset'       =>
				/* translators: %s: site name. */
				__( '[%s] Temporary support link reset', 'dsm-supreme-modules-pro-for-divi' ),
			'login'       =>
				/* translators: %s: site name. */
				__( '[%s] Temporary support link used', 'dsm-supreme-modules-pro-for-divi' ),
			'deactivated' =>
				/* translators: %s: site name. */
				__( '[%s] Temporary support access removed', 'dsm-supreme-modules-pro-for-divi' ),
		);

		$sentences = array(
			'enabled'     => __( 'Temporary support access was enabled.', 'dsm-supreme-modules-pro-for-divi' ),
			'disabled'    => __( 'Temporary support access was disabled and the support account was removed.', 'dsm-supreme-modules-pro-for-divi' ),
			'expired'     => __( 'Temporary support access expired and the support account was removed.', 'dsm-supreme-modules-pro-for-divi' ),
			'reset'       => __( 'The temporary support link was reset. The previous link no longer works.', 'dsm-supreme-modules-pro-for-divi' ),
			'login'       => __( 'The temporary support link was used to sign in.', 'dsm-supreme-modules-pro-for-divi' ),
			'deactivated' => __( 'Temporary support access was removed because Divi Supreme Pro was deactivated.', 'dsm-supreme-modules-pro-for-divi' ),
		);

		if ( ! isset( $subjects[ $reason ], $sentences[ $reason ] ) ) {
			return;
		}

		$site_name = wp_specialchars_decode( (string) get_bloginfo( 'name' ), ENT_QUOTES );
		$subject   = sprintf( $subjects[ $reason ], $site_name );
		$body      = $sentences[ $reason ] . "\n\n";
		$body     .= sprintf(
			/* translators: 1: site URL, 2: date and time. */
			__( "Site: %1\$s\nTime: %2\$s\n", 'dsm-supreme-modules-pro-for-divi' ),
			home_url(),
			wp_date( 'Y-m-d H:i:s T' )
		);
		$body .= __( 'This message never includes the access link.', 'dsm-supreme-modules-pro-for-divi' ) . "\n";
		$body .= admin_url( 'admin.php?page=divi_supreme_settings&tab=dsm_support' ) . "\n";

		if ( 'login' === $reason ) {
			$state = self::get_state();
			$ip    = is_array( $state ) ? (string) ( $state['last_login_ip'] ?? '' ) : '';
			if ( '' !== $ip ) {
				$body .= sprintf(
					/* translators: %s: IP address. */
					__( 'IP address: %s', 'dsm-supreme-modules-pro-for-divi' ),
					$ip
				) . "\n";
			}
		}

		self::send_mail( $admin_email, $subject, $body );
	}

	/**
	 * Delete support users except one ID.
	 *
	 * @param int $keep_id User ID to keep, or 0 to delete all support accounts.
	 * @return void
	 */
	private static function sweep_user_ids( int $keep_id ): void {
		$ids = get_users(
			array(
				'meta_key'   => self::USER_META, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- Orphan sweep, at most 20 support accounts.
				'meta_value' => '1', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value -- Matches the support-account marker only.
				'fields'     => 'ID',
				'number'     => 20,
			)
		);

		if ( ! is_array( $ids ) ) {
			return;
		}

		foreach ( $ids as $id ) {
			$id = (int) $id;
			if ( $id <= 0 || $id === $keep_id ) {
				continue;
			}

			if ( get_current_user_id() === $id ) {
				wp_logout();
			}

			self::destroy_sessions( $id );
			self::delete_support_user( $id, array() );
		}
	}

	/**
	 * Delete one support account and reassign content to the enabling administrator.
	 *
	 * @param int                  $user_id User ID.
	 * @param array<string, mixed> $state   Grant, when available.
	 * @return void
	 */
	private static function delete_support_user( int $user_id, array $state ): void {
		if ( $user_id <= 0 || ! self::user_is_support_account( $user_id ) ) {
			return;
		}

		if ( ! function_exists( 'wp_delete_user' ) ) {
			require_once ABSPATH . 'wp-admin/includes/user.php';
		}

		$reassign = self::reassign_target( $user_id, $state );

		if ( is_multisite() ) {
			if ( $reassign > 0 ) {
				remove_user_from_blog( $user_id, get_current_blog_id(), $reassign );
			} else {
				remove_user_from_blog( $user_id, get_current_blog_id() );
			}
			$blogs = get_blogs_of_user( $user_id );
			if ( empty( $blogs ) ) {
				require_once ABSPATH . 'wp-admin/includes/ms.php';
				if ( function_exists( 'wpmu_delete_user' ) ) {
					wpmu_delete_user( $user_id );
				}
			}
		} else {
			wp_delete_user( $user_id, $reassign > 0 ? $reassign : null );
		}

		unset( self::$support_users[ $user_id ] );
	}

	/**
	 * Administrator who should inherit content touched by support.
	 *
	 * @param int                  $support_user_id Support user ID.
	 * @param array<string, mixed> $state           Grant.
	 * @return int
	 */
	private static function reassign_target( int $support_user_id, array $state ): int {
		$enabled_by = isset( $state['enabled_by'] ) ? (int) $state['enabled_by'] : 0;
		if ( $enabled_by > 0 && $enabled_by !== $support_user_id && get_userdata( $enabled_by ) && ! self::user_is_support_account( $enabled_by ) ) {
			return $enabled_by;
		}

		$admins = get_users(
			array(
				'role'    => 'administrator',
				'number'  => 1,
				'fields'  => 'ID',
				'exclude' => array( $support_user_id ),
			)
		);

		if ( isset( $admins[0] ) ) {
			return (int) $admins[0];
		}

		$fallback = get_users(
			array(
				'number'  => 1,
				'fields'  => 'ID',
				'exclude' => array( $support_user_id ),
				'orderby' => 'ID',
				'order'   => 'ASC',
			)
		);

		if ( isset( $fallback[0] ) ) {
			return (int) $fallback[0];
		}

		return 0;
	}

	/**
	 * End every session for a user.
	 *
	 * @param int $user_id User ID.
	 * @return void
	 */
	private static function destroy_sessions( int $user_id ): void {
		if ( $user_id <= 0 || ! class_exists( '\WP_Session_Tokens' ) ) {
			return;
		}

		$tokens = \WP_Session_Tokens::get_instance( $user_id );
		$tokens->destroy_all();
	}

	/**
	 * Delete the grant option, pointer, cron event, and role.
	 *
	 * @return void
	 */
	private static function clear_storage_only(): void {
		wp_clear_scheduled_hook( self::CRON_HOOK );
		delete_option( self::OPTION );
		delete_option( self::USER_POINTER );
		self::mark_grant_present( false );
		remove_role( self::ROLE );
	}

	/**
	 * Log out a support session that no longer matches the grant.
	 *
	 * @param int $active_id Current grant user ID, or 0.
	 * @return void
	 */
	private static function logout_stale_support_session( int $active_id ): void {
		$current = get_current_user_id();
		if ( $current <= 0 || $current === $active_id || ! self::user_is_support_account( $current ) ) {
			return;
		}

		wp_logout();

		if ( wp_doing_ajax() || wp_doing_cron() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) || ( defined( 'WP_CLI' ) && WP_CLI ) ) {
			return;
		}

		wp_safe_redirect( wp_login_url() );
		exit;
	}

	/**
	 * Whether the user is the temporary support account.
	 *
	 * @param int $user_id User ID.
	 * @return bool
	 */
	private static function user_is_support_account( int $user_id ): bool {
		if ( $user_id <= 0 ) {
			return false;
		}

		if ( array_key_exists( $user_id, self::$support_users ) ) {
			return self::$support_users[ $user_id ];
		}

		$flag = get_user_meta( $user_id, self::USER_META, true );
		$flag = is_scalar( $flag ) ? (string) $flag : '';
		if ( '1' === $flag ) {
			self::$support_users[ $user_id ] = true;
			return true;
		}

		$user  = get_userdata( $user_id );
		$match = $user instanceof \WP_User
			&& self::SUPPORT_EMAIL === (string) $user->user_email
			&& 0 === strpos( (string) $user->user_login, 'dsm-support-' );

		self::$support_users[ $user_id ] = $match;

		return $match;
	}

	/**
	 * Whether the current request is the temporary support account.
	 *
	 * @return bool
	 */
	public static function current_user_is_support_account(): bool {
		return self::user_is_support_account( get_current_user_id() );
	}

	/**
	 * Real administrators only. The support account cannot manage this feature.
	 *
	 * @return bool
	 */
	private static function current_user_can_manage(): bool {
		if ( ! is_user_logged_in() ) {
			return false;
		}

		if ( self::user_is_support_account( get_current_user_id() ) ) {
			return false;
		}

		return current_user_can( 'manage_options' );
	}

	/**
	 * JSON auth gate for enable, disable, and reset.
	 *
	 * @return void
	 */
	private static function assert_ajax_manager(): void {
		if ( ! self::current_user_can_manage() ) {
			wp_send_json_error(
				array(
					'message' => __( 'You do not have permission to manage support access.', 'dsm-supreme-modules-pro-for-divi' ),
				),
				403
			);
		}

		if ( false === check_ajax_referer( 'dsm_support_access', 'nonce', false ) ) {
			wp_send_json_error(
				array(
					'message' => __( 'Security check failed.', 'dsm-supreme-modules-pro-for-divi' ),
				),
				403
			);
		}
	}

	/**
	 * Horizontal brand mark used on the settings top bar.
	 *
	 * @return string
	 */
	private static function brand_logo_markup(): string {
		if ( ! defined( 'DSM_DIR_PATH' ) ) {
			return '';
		}

		$path = DSM_DIR_PATH . 'divi-5/assets/static/logo-horizontal.svg';
		if ( ! is_readable( $path ) ) {
			return '';
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Local brand asset, not a remote request.
		$svg = file_get_contents( $path );
		if ( ! is_string( $svg ) ) {
			return '';
		}

		$svg = trim( $svg );
		if ( ! str_starts_with( $svg, '<svg' ) || false !== stripos( $svg, '<script' ) ) {
			return '';
		}

		$marked = preg_replace( '/<svg\b/', '<svg aria-hidden="true" focusable="false"', $svg, 1 );

		return is_string( $marked ) ? $marked : '';
	}

	/**
	 * Standalone login document. Exits.
	 *
	 * @param string $error Error already translated, or empty.
	 * @return void
	 */
	private static function render_login_document( string $error ): void {
		if ( ! defined( 'DONOTCACHEPAGE' ) ) {
			define( 'DONOTCACHEPAGE', true );
		}

		nocache_headers();
		status_header( 200 );

		if ( ! headers_sent() ) {
			header( 'Referrer-Policy: no-referrer' );
			header( 'X-Robots-Tag: noindex, nofollow' );
			header( 'X-Frame-Options: DENY' );
			header( 'X-Content-Type-Options: nosniff' );
			header( 'Cache-Control: no-store, no-cache, must-revalidate, max-age=0' );

			try {
				$csp_nonce = bin2hex( random_bytes( 16 ) );
			} catch ( \Exception $exception ) {
				unset( $exception );
				$csp_nonce = '';
			}

			if ( '' !== $csp_nonce ) {
				header( "Content-Security-Policy: default-src 'none'; style-src 'unsafe-inline'; script-src 'nonce-{$csp_nonce}'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'" );
			}
		} else {
			$csp_nonce = '';
		}

		$charset = get_bloginfo( 'charset' );
		if ( ! is_string( $charset ) || '' === $charset ) {
			$charset = 'UTF-8';
		}
		$charset = (string) preg_replace( '/[^a-zA-Z0-9._-]/', '', $charset );
		if ( '' === $charset ) {
			$charset = 'UTF-8';
		}

		$action = add_query_arg( 'dsm_support_login', '1', wp_login_url() );
		$title  = __( 'Temporary support access', 'dsm-supreme-modules-pro-for-divi' );
		$intro  = __( 'Paste the support code if this page does not continue automatically.', 'dsm-supreme-modules-pro-for-divi' );
		$label  = __( 'Support code', 'dsm-supreme-modules-pro-for-divi' );
		$button = __( 'Continue', 'dsm-supreme-modules-pro-for-divi' );

		if ( ! headers_sent() ) {
			header( 'Content-Type: text/html; charset=' . $charset );
		}
		// The login document is a standalone page. Indentation follows the HTML, not the method body.
		// phpcs:disable Generic.WhiteSpace.ScopeIndent.Incorrect, Generic.WhiteSpace.ScopeIndent.IncorrectExact
		?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php echo esc_attr( $charset ); ?>" />
	<meta name="referrer" content="no-referrer" />
	<meta name="robots" content="noindex, nofollow" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<title><?php echo esc_html( $title ); ?></title>
	<style>
		:root {
			color-scheme: light;
			--ink: #0e0b1c;
			--text: #4b463d;
			--paper: #faf7f2;
			--line: rgba(14, 11, 28, 0.08);
			--line-2: rgba(14, 11, 28, 0.16);
			--violet: #5b2bff;
			--violet-hover: #3914b5;
			--danger-bg: #fbe0de;
			--danger: #7a231e;
			--sans: "Geist", "Inter", ui-sans-serif, system-ui, -apple-system, "Segoe UI", sans-serif;
			--mono: "Geist Mono", ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
		}
		* { box-sizing: border-box; }
		html, body { height: 100%; }
		body {
			margin: 0;
			min-height: 100%;
			display: grid;
			place-items: center;
			padding: 24px 16px;
			background:
				radial-gradient(880px 380px at 50% -8%, rgba(91, 43, 255, 0.08), transparent 62%),
				var(--paper);
			color: var(--ink);
			font: 16px/1.5 var(--sans);
			-webkit-font-smoothing: antialiased;
		}
		main {
			width: min(26.5rem, 100%);
			background: #fff;
			border: 1px solid var(--line);
			border-radius: 16px;
			box-shadow: 0 1px 2px rgba(14, 11, 28, 0.04), 0 12px 32px rgba(14, 11, 28, 0.08);
			padding: 28px 28px 24px;
		}
		.logo {
			margin: 0 0 20px;
			line-height: 0;
		}
		.logo svg {
			display: block;
			height: 36px;
			width: auto;
		}
		h1 {
			margin: 0;
			color: var(--ink);
			font-size: 26px;
			font-weight: 700;
			letter-spacing: -0.02em;
			line-height: 1.15;
		}
		.lead {
			margin: 10px 0 0;
			color: var(--text);
			font-size: 15px;
			line-height: 1.5;
			text-wrap: pretty;
		}
		.lead.is-busy {
			color: var(--violet);
			font-weight: 600;
		}
		.alert {
			display: flex;
			gap: 10px;
			align-items: flex-start;
			margin: 16px 0 0;
			padding: 12px 14px;
			border-radius: 10px;
			background: var(--danger-bg);
			color: var(--danger);
			font-size: 14px;
			font-weight: 500;
			line-height: 1.45;
		}
		.alert svg { flex: 0 0 auto; margin-top: 1px; }
		form { margin-top: 20px; }
		label {
			display: block;
			margin: 0 0 6px;
			color: var(--text);
			font-size: 13px;
			font-weight: 500;
		}
		input {
			display: block;
			width: 100%;
			height: 44px;
			margin: 0;
			padding: 0 44px 0 14px;
			border: 1px solid var(--line-2);
			border-radius: 10px;
			background: #fdfcfa;
			box-shadow: inset 0 1px 2px rgba(14, 11, 28, 0.04);
			color: var(--ink);
			font: 16px/1 var(--mono);
		}
		input:focus {
			outline: none;
			border-color: var(--violet);
			box-shadow: 0 0 0 3px rgba(91, 43, 255, 0.22);
		}
		button {
			display: flex;
			align-items: center;
			justify-content: center;
			width: 100%;
			height: 42px;
			margin-top: 14px;
			border: 0;
			border-radius: 10px;
			background: var(--violet);
			color: #fff;
			font: 600 14px/1 var(--sans);
			cursor: pointer;
			transition: background 180ms cubic-bezier(0.16, 1, 0.3, 1), transform 180ms cubic-bezier(0.16, 1, 0.3, 1);
		}
		button:hover { background: var(--violet-hover); }
		button:active { transform: scale(0.98); }
		.links {
			display: flex;
			flex-wrap: wrap;
			justify-content: center;
			gap: 8px 16px;
			margin-top: 16px;
			padding-top: 14px;
			border-top: 1px solid var(--line);
		}
		.links a {
			color: var(--violet);
			font-size: 13px;
			font-weight: 500;
			line-height: 1.3;
			text-decoration: none;
		}
		.links a:hover {
			text-decoration: underline;
		}
		button:focus-visible,
		input:focus-visible,
		.links a:focus-visible {
			outline: 2px solid var(--violet);
			outline-offset: 2px;
		}
		input:focus-visible {
			outline: none;
		}
		@media (max-width: 480px) {
			main { padding: 24px 20px 20px; }
			h1 { font-size: 24px; }
		}
		@media (prefers-reduced-motion: reduce) {
			button { transition: none; }
			button:active { transform: none; }
		}
	</style>
</head>
<body>
<main>
	<div class="logo" role="img" aria-label="<?php echo esc_attr__( 'Divi Supreme', 'dsm-supreme-modules-pro-for-divi' ); ?>">
		<?php
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Local logo SVG, checked in brand_logo_markup().
		echo self::brand_logo_markup();
		?>
	</div>
	<h1><?php echo esc_html( $title ); ?></h1>
	<p class="lead" id="dsm-support-status"><?php echo esc_html( $intro ); ?></p>
	<?php if ( '' !== $error ) : ?>
		<p class="alert" role="alert">
			<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden="true"><circle cx="12" cy="12" r="9" stroke="#7A231E" stroke-width="1.75"/><path stroke="#7A231E" stroke-width="1.75" stroke-linecap="round" d="M12 8v5"/><circle cx="12" cy="16.25" r="0.9" fill="#7A231E"/></svg>
			<span><?php echo esc_html( $error ); ?></span>
		</p>
	<?php endif; ?>
	<form id="dsm-support-login" method="post" action="<?php echo esc_url( $action ); ?>" autocomplete="off">
		<label for="dsm-support-token"><?php echo esc_html( $label ); ?></label>
		<input id="dsm-support-token" name="dsm_support_token" type="text" maxlength="128" autocomplete="off" autocapitalize="off" spellcheck="false" data-1p-ignore="true" data-lpignore="true" />
		<button type="submit"><?php echo esc_html( $button ); ?></button>
	</form>
	<nav class="links" aria-label="<?php echo esc_attr__( 'Help', 'dsm-supreme-modules-pro-for-divi' ); ?>">
		<a href="<?php echo esc_url( 'https://docs.divisupreme.com/' ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html__( 'Documentation →', 'dsm-supreme-modules-pro-for-divi' ); ?></a>
		<a href="<?php echo esc_url( 'https://divisupreme.com/contact/' ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html__( 'Get Support →', 'dsm-supreme-modules-pro-for-divi' ); ?></a>
	</nav>
</main>
		<?php if ( '' !== $csp_nonce ) : ?>
<script nonce="<?php echo esc_attr( $csp_nonce ); ?>">
(function () {
	var hash = window.location.hash || '';
	var match = hash.match(/(?:^#|[?&#])dsm=([A-Za-z0-9_-]+)/);
	if (!match) { return; }
	var token = match[1];
	if (window.history && window.history.replaceState) {
		window.history.replaceState(null, '', window.location.pathname + window.location.search);
	}
	var input = document.getElementById('dsm-support-token');
	var form = document.getElementById('dsm-support-login');
	if (!input || !form) { return; }
	input.value = token;
	var status = document.getElementById('dsm-support-status');
	if (status) {
		status.textContent = <?php echo wp_json_encode( __( 'Signing in…', 'dsm-supreme-modules-pro-for-divi' ) ); ?>;
		status.className = 'lead is-busy';
	}
	form.submit();
})();
</script>
		<?php endif; ?>
</body>
</html>
		<?php
		// phpcs:enable Generic.WhiteSpace.ScopeIndent.Incorrect, Generic.WhiteSpace.ScopeIndent.IncorrectExact
		exit;
	}
}
