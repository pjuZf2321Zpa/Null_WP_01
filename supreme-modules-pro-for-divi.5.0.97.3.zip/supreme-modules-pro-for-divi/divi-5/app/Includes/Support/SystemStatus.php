<?php
/**
 * Read-only system report for the Divi Supreme support screen.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Includes\Support;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Collects WordPress, PHP, and plugin facts without secrets.
 */
class SystemStatus {

	/**
	 * Plain-text report safe to paste into a support ticket.
	 *
	 * @return string
	 */
	public static function text(): string {
		$lines   = array();
		$lines[] = __( 'Divi Supreme Pro system status', 'dsm-supreme-modules-pro-for-divi' );
		$lines[] = sprintf(
			/* translators: %s: date and time in the site timezone. */
			__( 'Generated: %s', 'dsm-supreme-modules-pro-for-divi' ),
			wp_date( 'Y-m-d H:i:s T' )
		);
		$lines[] = __( 'Secrets such as passwords, salts, and the support link are omitted.', 'dsm-supreme-modules-pro-for-divi' );
		$lines[] = '';

		foreach ( self::groups() as $group ) {
			if ( ! is_array( $group ) ) {
				continue;
			}

			$title = isset( $group['title'] ) ? self::plain( (string) $group['title'] ) : '';
			if ( '' === $title ) {
				continue;
			}

			$lines[] = '## ' . $title;
			$rows    = isset( $group['rows'] ) && is_array( $group['rows'] ) ? $group['rows'] : array();

			foreach ( $rows as $row ) {
				if ( ! is_array( $row ) ) {
					continue;
				}

				$label = isset( $row['label'] ) ? self::plain( (string) $row['label'] ) : '';
				$parts = self::plain_lines( isset( $row['value'] ) ? (string) $row['value'] : '' );
				if ( '' === $label || array() === $parts ) {
					continue;
				}

				if ( count( $parts ) > 1 ) {
					$lines[] = $label . ':';
					foreach ( $parts as $part ) {
						$lines[] = '  - ' . $part;
					}
					continue;
				}

				$lines[] = $label . ': ' . $parts[0];
			}

			$lines[] = '';
		}

		return implode( "\n", $lines );
	}

	/**
	 * Status groups. Values are plain text.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public static function groups(): array {
		$groups = array(
			array(
				'title' => __( 'Site', 'dsm-supreme-modules-pro-for-divi' ),
				'rows'  => array(
					self::row( __( 'Site URL', 'dsm-supreme-modules-pro-for-divi' ), site_url() ),
					self::row( __( 'Home URL', 'dsm-supreme-modules-pro-for-divi' ), home_url() ),
					self::row( __( 'HTTPS', 'dsm-supreme-modules-pro-for-divi' ), self::yes_no( self::home_is_https() ) ),
					self::row( __( 'Multisite', 'dsm-supreme-modules-pro-for-divi' ), self::yes_no( is_multisite() ) ),
					self::row( __( 'Language', 'dsm-supreme-modules-pro-for-divi' ), get_locale() ),
					self::row( __( 'Permalink structure', 'dsm-supreme-modules-pro-for-divi' ), self::permalinks() ),
					self::row( __( 'Environment', 'dsm-supreme-modules-pro-for-divi' ), function_exists( 'wp_get_environment_type' ) ? wp_get_environment_type() : '' ),
					self::row( __( 'WordPress', 'dsm-supreme-modules-pro-for-divi' ), get_bloginfo( 'version' ) ),
					self::row( __( 'WordPress memory limit', 'dsm-supreme-modules-pro-for-divi' ), defined( 'WP_MEMORY_LIMIT' ) ? (string) WP_MEMORY_LIMIT : '' ),
					self::row( __( 'WordPress max memory limit', 'dsm-supreme-modules-pro-for-divi' ), defined( 'WP_MAX_MEMORY_LIMIT' ) ? (string) WP_MAX_MEMORY_LIMIT : '' ),
					self::row( __( 'WordPress debug', 'dsm-supreme-modules-pro-for-divi' ), self::yes_no( defined( 'WP_DEBUG' ) && WP_DEBUG ) ),
					self::row( __( 'WordPress cron disabled', 'dsm-supreme-modules-pro-for-divi' ), self::yes_no( defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ) ),
				),
			),
			array(
				'title' => __( 'Server', 'dsm-supreme-modules-pro-for-divi' ),
				'rows'  => array(
					self::row( __( 'PHP version', 'dsm-supreme-modules-pro-for-divi' ), PHP_VERSION ),
					self::row( __( 'PHP SAPI', 'dsm-supreme-modules-pro-for-divi' ), PHP_SAPI ),
					self::row( __( 'PHP memory limit', 'dsm-supreme-modules-pro-for-divi' ), self::ini_value( 'memory_limit' ) ),
					self::row( __( 'Max execution time', 'dsm-supreme-modules-pro-for-divi' ), self::ini_value( 'max_execution_time' ) ),
					self::row( __( 'Max input vars', 'dsm-supreme-modules-pro-for-divi' ), self::ini_value( 'max_input_vars' ) ),
					self::row( __( 'Upload max filesize', 'dsm-supreme-modules-pro-for-divi' ), self::ini_value( 'upload_max_filesize' ) ),
					self::row( __( 'Post max size', 'dsm-supreme-modules-pro-for-divi' ), self::ini_value( 'post_max_size' ) ),
					self::row( __( 'MySQL', 'dsm-supreme-modules-pro-for-divi' ), self::database_version() ),
					self::row( __( 'Table prefix', 'dsm-supreme-modules-pro-for-divi' ), self::table_prefix() ),
					self::row( __( 'Server software', 'dsm-supreme-modules-pro-for-divi' ), self::server_software() ),
					self::row( __( 'cURL', 'dsm-supreme-modules-pro-for-divi' ), self::curl_version() ),
					self::row( __( 'PHP extensions', 'dsm-supreme-modules-pro-for-divi' ), self::extensions() ),
				),
			),
			array(
				'title' => __( 'Theme', 'dsm-supreme-modules-pro-for-divi' ),
				'rows'  => self::theme_rows(),
			),
			array(
				'title' => __( 'Divi Supreme', 'dsm-supreme-modules-pro-for-divi' ),
				'rows'  => array(
					self::row( __( 'Version', 'dsm-supreme-modules-pro-for-divi' ), defined( 'DSM_PRO_VERSION' ) ? (string) DSM_PRO_VERSION : '' ),
					self::row( __( 'License key', 'dsm-supreme-modules-pro-for-divi' ), self::masked_license() ),
				),
			),
			array(
				'title' => __( 'Active plugins', 'dsm-supreme-modules-pro-for-divi' ),
				'rows'  => array(
					self::row( __( 'Plugins', 'dsm-supreme-modules-pro-for-divi' ), self::active_plugins() ),
					self::row( __( 'Must-use plugins', 'dsm-supreme-modules-pro-for-divi' ), self::mu_plugins() ),
				),
			),
		);

		/**
		 * Filter the Divi Supreme support system status groups.
		 *
		 * Each group is `title` plus `rows` of `label` and `value`. Do not add secrets.
		 *
		 * @param array<int, array<string, mixed>> $groups Status groups.
		 */
		$filtered = apply_filters( 'dsm_support_system_status', $groups );

		return is_array( $filtered ) ? $filtered : $groups;
	}

	/**
	 * One label/value row.
	 *
	 * @param string $label Row label.
	 * @param string $value Row value.
	 * @return array{label: string, value: string}
	 */
	private static function row( string $label, string $value ): array {
		return array(
			'label' => $label,
			'value' => $value,
		);
	}

	/**
	 * Yes or no label.
	 *
	 * @param bool $value Flag.
	 * @return string
	 */
	private static function yes_no( bool $value ): string {
		return $value
			? __( 'Yes', 'dsm-supreme-modules-pro-for-divi' )
			: __( 'No', 'dsm-supreme-modules-pro-for-divi' );
	}

	/**
	 * Whether the home URL uses HTTPS.
	 *
	 * @return bool
	 */
	private static function home_is_https(): bool {
		return 0 === strpos( (string) home_url(), 'https://' );
	}

	/**
	 * Permalink structure, or a plain-permalink label.
	 *
	 * @return string
	 */
	private static function permalinks(): string {
		$structure = get_option( 'permalink_structure' );
		if ( ! is_string( $structure ) || '' === $structure ) {
			return __( 'Plain', 'dsm-supreme-modules-pro-for-divi' );
		}

		return $structure;
	}

	/**
	 * Sanitized php.ini value.
	 *
	 * @param string $key Ini key.
	 * @return string
	 */
	private static function ini_value( string $key ): string {
		$value = ini_get( $key );
		if ( false === $value ) {
			return '';
		}

		return self::plain( (string) $value );
	}

	/**
	 * Database server version without credentials.
	 *
	 * @return string
	 */
	private static function database_version(): string {
		global $wpdb;

		if ( ! $wpdb instanceof \wpdb ) {
			return '';
		}

		if ( method_exists( $wpdb, 'db_server_info' ) ) {
			$info = $wpdb->db_server_info();
			if ( is_string( $info ) && '' !== $info ) {
				return self::plain( $info );
			}
		}

		return self::plain( (string) $wpdb->db_version() );
	}

	/**
	 * Table prefix only. Database name, user, and password are omitted.
	 *
	 * @return string
	 */
	private static function table_prefix(): string {
		global $wpdb;

		if ( ! $wpdb instanceof \wpdb ) {
			return '';
		}

		return self::plain( (string) $wpdb->prefix );
	}

	/**
	 * Web server software banner, trimmed.
	 *
	 * @return string
	 */
	private static function server_software(): string {
		if ( ! isset( $_SERVER['SERVER_SOFTWARE'] ) ) {
			return '';
		}

		$software = sanitize_text_field( wp_unslash( (string) $_SERVER['SERVER_SOFTWARE'] ) );
		if ( strlen( $software ) > 200 ) {
			$software = substr( $software, 0, 200 );
		}

		return $software;
	}

	/**
	 * Curl version, or unavailable.
	 *
	 * @return string
	 */
	private static function curl_version(): string {
		if ( ! function_exists( 'curl_version' ) ) {
			return __( 'Unavailable', 'dsm-supreme-modules-pro-for-divi' );
		}

		$curl = curl_version();
		if ( ! is_array( $curl ) || empty( $curl['version'] ) ) {
			return __( 'Unavailable', 'dsm-supreme-modules-pro-for-divi' );
		}

		return self::plain( (string) $curl['version'] );
	}

	/**
	 * Presence of extensions support commonly needs.
	 *
	 * @return string
	 */
	private static function extensions(): string {
		$names = array( 'curl', 'dom', 'gd', 'imagick', 'zip', 'mbstring', 'intl', 'openssl' );
		$lines = array();

		foreach ( $names as $name ) {
			$lines[] = $name . ': ' . ( extension_loaded( $name ) ? 'yes' : 'no' );
		}

		return implode( "\n", $lines );
	}

	/**
	 * Active theme, parent theme, and Divi builder version.
	 *
	 * @return array<int, array{label: string, value: string}>
	 */
	private static function theme_rows(): array {
		$theme = wp_get_theme();
		$rows  = array(
			self::row(
				__( 'Active theme', 'dsm-supreme-modules-pro-for-divi' ),
				trim( self::plain( (string) $theme->get( 'Name' ) ) . ' ' . self::plain( (string) $theme->get( 'Version' ) ) )
			),
		);

		$parent = $theme->parent();
		if ( $parent instanceof \WP_Theme ) {
			$rows[] = self::row(
				__( 'Parent theme', 'dsm-supreme-modules-pro-for-divi' ),
				trim( self::plain( (string) $parent->get( 'Name' ) ) . ' ' . self::plain( (string) $parent->get( 'Version' ) ) )
			);
		}

		$rows[] = self::row(
			__( 'Divi', 'dsm-supreme-modules-pro-for-divi' ),
			defined( 'ET_BUILDER_VERSION' ) ? self::plain( (string) ET_BUILDER_VERSION ) : __( 'Not detected', 'dsm-supreme-modules-pro-for-divi' )
		);

		return $rows;
	}

	/**
	 * Masked product license key, or a not-set label.
	 *
	 * @return string
	 */
	private static function masked_license(): string {
		if ( function_exists( 'dsm_is_marketplace_build' ) && dsm_is_marketplace_build() ) {
			return __( 'Marketplace build', 'dsm-supreme-modules-pro-for-divi' );
		}

		$license = get_site_option( 'dsm_pro_license', array() );
		$key     = '';
		if ( is_array( $license ) && isset( $license['key'] ) ) {
			$key = trim( (string) $license['key'] );
		}

		if ( '' === $key ) {
			return __( 'Not set', 'dsm-supreme-modules-pro-for-divi' );
		}

		$length = strlen( $key );
		if ( $length <= 4 ) {
			return str_repeat( '*', $length );
		}

		return str_repeat( '*', $length - 4 ) . substr( $key, -4 );
	}

	/**
	 * Active plugin names and versions.
	 *
	 * @return string
	 */
	private static function active_plugins(): string {
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$plugins = get_plugins();
		$active  = get_option( 'active_plugins', array() );
		if ( ! is_array( $active ) ) {
			$active = array();
		}

		if ( is_multisite() ) {
			$network = get_site_option( 'active_sitewide_plugins', array() );
			if ( is_array( $network ) ) {
				$active = array_merge( $active, array_keys( $network ) );
			}
		}

		$active = array_values( array_unique( array_map( 'strval', $active ) ) );

		return self::plugin_lines( is_array( $plugins ) ? $plugins : array(), $active );
	}

	/**
	 * Must-use plugin names and versions.
	 *
	 * @return string
	 */
	private static function mu_plugins(): string {
		if ( ! function_exists( 'get_mu_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$plugins = get_mu_plugins();
		if ( ! is_array( $plugins ) || array() === $plugins ) {
			return __( 'None', 'dsm-supreme-modules-pro-for-divi' );
		}

		return self::plugin_lines( $plugins, array_keys( $plugins ) );
	}

	/**
	 * Format plugin header rows.
	 *
	 * @param array<string, mixed> $plugins Plugin headers keyed by file.
	 * @param array<int, string>   $files   Files to include.
	 * @return string
	 */
	private static function plugin_lines( array $plugins, array $files ): string {
		$lines = array();

		foreach ( $files as $file ) {
			if ( ! is_string( $file ) || ! isset( $plugins[ $file ] ) || ! is_array( $plugins[ $file ] ) ) {
				continue;
			}

			$name    = isset( $plugins[ $file ]['Name'] ) ? self::plain( (string) $plugins[ $file ]['Name'] ) : $file;
			$version = isset( $plugins[ $file ]['Version'] ) ? self::plain( (string) $plugins[ $file ]['Version'] ) : '';
			$line    = trim( $name . ' ' . $version );
			if ( '' !== $line ) {
				$lines[] = $line;
			}
		}

		if ( array() === $lines ) {
			return __( 'None', 'dsm-supreme-modules-pro-for-divi' );
		}

		sort( $lines );

		return implode( "\n", $lines );
	}

	/**
	 * Split a value into safe single-line parts.
	 *
	 * @param string $value Raw value.
	 * @return array<int, string>
	 */
	private static function plain_lines( string $value ): array {
		$value = str_replace( array( "\r\n", "\r" ), "\n", $value );
		$lines = array();

		foreach ( explode( "\n", $value ) as $line ) {
			$line = self::plain( $line );
			if ( '' !== $line ) {
				$lines[] = $line;
			}
		}

		return $lines;
	}

	/**
	 * Single-line plain text.
	 *
	 * @param string $value Raw value.
	 * @return string
	 */
	private static function plain( string $value ): string {
		$value = wp_strip_all_tags( $value );
		$value = str_replace( array( "\r", "\n" ), ' ', $value );
		$value = preg_replace( '/\s+/', ' ', $value );
		if ( ! is_string( $value ) ) {
			return '';
		}

		return trim( $value );
	}
}
