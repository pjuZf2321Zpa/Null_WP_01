<?php
/**
 * Page Tour extension — global enable flag (Divi Supreme → Extensions).
 *
 * Opt-in: disabled unless the user turns on Page Tour in plugin settings.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

if ( ! function_exists( 'dsm_is_page_tour_extension_enabled' ) ) {
	/**
	 * True when Divi Supreme → Extensions → Page Tour is on (default: off).
	 *
	 * @return bool
	 */
	function dsm_is_page_tour_extension_enabled(): bool {
		$general = get_option( 'dsm_general', array() );

		if ( ! is_array( $general ) ) {
			return false;
		}

		if ( ! array_key_exists( 'dsm_use_page_tour', $general ) ) {
			return false;
		}

		return 'on' === $general['dsm_use_page_tour'];
	}
}

if ( ! function_exists( 'dsm_content_has_enabled_page_tour' ) ) {
	/**
	 * True when layout HTML/JSON has a Page Tour step that is actually on.
	 *
	 * @param string $content Post content, DA scan blob, or rendered HTML.
	 * @return bool
	 */
	function dsm_content_has_enabled_page_tour( string $content ): bool {
		if ( '' === $content ) {
			return false;
		}

		if ( str_contains( $content, 'data-dsm-tour-step' ) ) {
			return true;
		}

		if ( ! str_contains( $content, 'dsm_page_tour_enabled' ) ) {
			return false;
		}

		if ( ! preg_match_all(
			'/"dsm_page_tour_enabled"\s*:\s*\{\s*"innerContent"\s*:\s*(\{(?:[^{}]|\{[^{}]*\})*\})/s',
			$content,
			$matches
		) ) {
			return false;
		}

		foreach ( $matches[1] as $inner ) {
			if ( ! is_string( $inner ) ) {
				continue;
			}

			if ( preg_match( '/"value"\s*:\s*"on"/', $inner ) ) {
				return true;
			}
		}

		return false;
	}
}
