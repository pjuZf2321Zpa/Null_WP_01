<?php
/**
 * Central registry for Divi Supreme Pro (Divi 5) frontend module slugs and shared handles.
 *
 * Module slugs are discovered from each module.json under public/packages/module-library/.
 * They are picked up without editing this file. Optional metadata documents script handles registered
 * in {@see \DiviSupreme\Core\Supreme5FrontendAssets::load_frontend_assets()} for maintenance and future per-module splits.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Includes;

/**
 * Configuration for dynamic asset loading and documentation of FE handles.
 */
final class DsmFrontendModuleAssetRegistry {

	public const CORE_MODULES_STYLE_HANDLE = 'dsm-supreme-modules-style';

	/**
	 * Visual Builder TB/CPT companion for {@see CORE_MODULES_STYLE_HANDLE} (`modules-vb-styles-cpt.css`).
	 */
	public const CORE_MODULES_VB_CPT_STYLE_HANDLE = 'dsm-supreme-modules-vb-cpt-style';

	public const EXTENSION_POPUP_STYLE_HANDLE = 'dsm-supreme-extensions-style';

	public const SWIPER_LIBRARY_STYLE_HANDLE = 'dsm-swiper-library-style';

	public const IMAGE_COMPARE_VIEWER_STYLE_HANDLE = 'dsm-image-compare-viewer';

	public const EXTENSION_POPUP_SCRIPT_HANDLE = 'dsm-popup-extension';

	/**
	 * Supreme modules that rely on Divi's full icon stylesheets when present on the page.
	 *
	 * @var list<string>
	 */
	public const ICON_DEPENDENT_MODULE_SLUGS = array(
		'dsm/advanced-tabs',
		'dsm/advanced-tabs-child',
		'dsm/block-reveal-image',
		'dsm/blog-carousel',
		'dsm/breadcrumbs',
		'dsm/button',
		'dsm/card',
		'dsm/card-carousel',
		'dsm/card-carousel-child',
		'dsm/circle-info',
		'dsm/circle-info-child',
		'dsm/content-timeline',
		'dsm/content-timeline-child',
		'dsm/faq',
		'dsm/faq-child',
		'dsm/filterable-gallery',
		'dsm/flipbox',
		'dsm/glitch-text',
		'dsm/icon-divider',
		'dsm/icon-list',
		'dsm/icon-list-child',
		'dsm/marquee',
		'dsm/marquee-child',
		'dsm/image-accordion',
		'dsm/image-accordion-child',
		'dsm/image-carousel',
		'dsm/image-hotspots',
		'dsm/image-hotspots-child',
		'dsm/menu',
		'dsm/on-scroll-header-animation',
		'dsm/perspective-image',
		'dsm/post-carousel',
		'dsm/post-reading-time',
		'dsm/random-image',
		'dsm/readmore',
		'dsm/scroll-image',
		'dsm/social-share-buttons',
		'dsm/social-share-buttons-child',
		'dsm/stacking-card-child',
		'dsm/step-flow',
		'dsm/table',
		'dsm/table-of-contents',
		'dsm/tilt-image',
	);

	/**
	 * Cached D4 shortcode tags for {@see ICON_DEPENDENT_MODULE_SLUGS}.
	 *
	 * @var list<string>|null
	 */
	private static ?array $icon_dependent_d4_shortcode_tags_cache = null;

	/**
	 * D4 shortcode tags (e.g. `dsm_image_hotspots`) for icon-dependent Supreme modules.
	 *
	 * @return list<string>
	 */
	public static function get_icon_dependent_d4_shortcode_tags(): array {
		if ( null !== self::$icon_dependent_d4_shortcode_tags_cache ) {
			return self::$icon_dependent_d4_shortcode_tags_cache;
		}

		self::read_library_index();

		$tags       = array();
		$shortcodes = self::$d4_shortcode_by_slug ?? array();

		foreach ( self::ICON_DEPENDENT_MODULE_SLUGS as $slug ) {
			if ( empty( $shortcodes[ $slug ] ) || ! is_string( $shortcodes[ $slug ] ) ) {
				continue;
			}

			$tags[] = $shortcodes[ $slug ];
		}

		self::$icon_dependent_d4_shortcode_tags_cache = array_values( array_unique( $tags ) );

		return self::$icon_dependent_d4_shortcode_tags_cache;
	}

	/**
	 * Cached slugs from disk (`module.json` `name` values).
	 *
	 * @var list<string>|null
	 */
	private static ?array $disk_module_slugs = null;

	/**
	 * Cached map of block `name` (e.g. dsm/flipbox) → filesystem folder (e.g. flipbox-perk).
	 *
	 * @var array<string, string>|null
	 */
	private static ?array $block_name_to_library_folder_map = null;

	/**
	 * Library folders that have a compiled `frontend.css`, cached for the request.
	 *
	 * @var list<string>|null
	 */
	private static ?array $frontend_css_folders = null;

	/**
	 * Block names registered with WordPress after `wp`, or null when that list is not trustworthy yet.
	 *
	 * @var list<string>|null
	 */
	private static ?array $registered_block_slugs = null;

	/**
	 * Whether {@see registered_dsm_block_slugs()} has already looked at the block registry.
	 *
	 * @var bool
	 */
	private static bool $block_slug_lookup_done = false;

	/**
	 * Whether scoped frontend styles were registered after the main query.
	 *
	 * A second call in the same request must not glob or stat the module library again.
	 *
	 * @var bool
	 */
	private static bool $scoped_styles_refreshed_after_wp = false;

	/**
	 * `d4Shortcode` values from the library index, keyed by block name.
	 *
	 * @var array<string, string>|null
	 */
	private static ?array $d4_shortcode_by_slug = null;

	/**
	 * Whether the persistent library index was already read this request.
	 *
	 * @var bool
	 */
	private static bool $persistent_index_checked = false;

	/**
	 * Whether this request rebuilt the library index from disk.
	 *
	 * @var bool
	 */
	private static bool $library_index_dirty = false;

	/**
	 * Whether a stylesheet mtime was measured and still needs to be stored.
	 *
	 * @var bool
	 */
	private static bool $stylesheet_versions_dirty = false;

	/**
	 * Whether a shutdown flush is already scheduled.
	 *
	 * @var bool
	 */
	private static bool $asset_index_flush_scheduled = false;

	/**
	 * Transient key for this request, or an empty string when the build sentinel is missing.
	 *
	 * @var string|null
	 */
	private static ?string $asset_index_transient_key = null;

	/**
	 * All `name` values from built module.json files under module-library.
	 *
	 * @return list<string>
	 */
	public static function get_all_module_slugs(): array {
		self::read_library_index();

		$all     = self::$disk_module_slugs ?? array();
		$enabled = self::asset_block_slugs();

		if ( null === $enabled ) {
			return $all;
		}

		$enabled_lookup = array_fill_keys( $enabled, true );
		$slugs          = array();

		foreach ( $all as $slug ) {
			if ( isset( $enabled_lookup[ $slug ] ) ) {
				$slugs[] = $slug;
			}
		}

		return $slugs;
	}

	/**
	 * Map `module.json` → `name` to the library subdirectory (folder name) that holds `style.scss` / `frontend.css`.
	 *
	 * Used to resolve `dsm/before-after-image` → `before-after-slider`, `dsm/flipbox` → `flipbox-perk`, etc.
	 *
	 * @return array<string, string> Block name keyed to folder basename.
	 */
	public static function get_block_name_to_library_folder_map(): array {
		self::read_library_index();

		return self::$block_name_to_library_folder_map ?? array();
	}

	/**
	 * Read every `module.json` once per request.
	 *
	 * Feeds both the slug list and the folder map so detection does not scan the library twice.
	 *
	 * @return void
	 */
	private static function read_library_index(): void {
		self::hydrate_persistent_library_index();

		if ( null !== self::$disk_module_slugs && null !== self::$block_name_to_library_folder_map && null !== self::$d4_shortcode_by_slug ) {
			return;
		}

		$slugs      = array();
		$folders    = array();
		$shortcodes = array();
		$pattern    = trailingslashit( self::get_module_library_path() ) . '*/module.json';

		foreach ( (array) glob( $pattern ) as $file ) {
			if ( ! is_string( $file ) || ! is_readable( $file ) ) {
				continue;
			}

			$json = json_decode( (string) file_get_contents( $file ), true );
			if ( ! is_array( $json ) || empty( $json['name'] ) || ! is_string( $json['name'] ) ) {
				continue;
			}

			$name   = $json['name'];
			$folder = basename( dirname( $file ) );

			if ( '' === $folder || ! str_starts_with( $name, 'dsm/' ) ) {
				continue;
			}

			$slugs[]             = $name;
			$folders[ $name ]    = $folder;
			$shortcodes[ $name ] = ( isset( $json['d4Shortcode'] ) && is_string( $json['d4Shortcode'] ) ) ? $json['d4Shortcode'] : '';
		}

		self::$disk_module_slugs                = array_values( array_unique( $slugs ) );
		self::$block_name_to_library_folder_map = $folders;
		self::$d4_shortcode_by_slug             = $shortcodes;
		self::$library_index_dirty              = true;
		self::schedule_asset_index_flush();
	}

	/**
	 * Handle for a compiled per-module stylesheet under `public/packages/module-library/{folder}/frontend.css`.
	 *
	 * @param string $folder Library folder basename (e.g. `card`, `flipbox-perk`).
	 * @return string
	 */
	public static function frontend_style_handle_for_library_folder( string $folder ): string {
		$clean = strtolower( sanitize_key( $folder ) );

		return 'dsm-frontend-' . $clean;
	}

	/**
	 * Absolute path to compiled public assets root (`divi-5/public`).
	 */
	public static function get_public_assets_path(): string {
		return DSM_DIR_PATH . 'divi-5/public';
	}

	/**
	 * Resolve a module folder's compiled frontend CSS on disk.
	 *
	 * Prefers `packages/module-library/{folder}/frontend.css` (postbuild target). Falls back to
	 * webpack's flat `public/style-mlfe-{folder}.css` when postbuild has not run yet.
	 *
	 * @param string $folder Library folder basename (e.g. `card`, `flipbox-perk`).
	 */
	public static function resolve_frontend_css_absolute_path( string $folder ): ?string {
		if ( '' === $folder ) {
			return null;
		}

		$nested = trailingslashit( self::get_module_library_path() ) . $folder . '/frontend.css';

		if ( is_readable( $nested ) ) {
			return DsmDiviBuilderCssScope::resolve_stylesheet_path( $nested );
		}

		$flat = trailingslashit( self::get_public_assets_path() ) . 'style-mlfe-' . $folder . '.css';

		if ( is_readable( $flat ) ) {
			return DsmDiviBuilderCssScope::resolve_stylesheet_path( $flat );
		}

		return null;
	}

	/**
	 * Public URL for a module folder's compiled frontend CSS.
	 *
	 * @param string $folder Library folder basename (e.g. `card`, `flipbox-perk`).
	 */
	public static function resolve_frontend_css_url( string $folder ): ?string {
		$absolute = self::resolve_frontend_css_absolute_path( $folder );

		if ( null === $absolute ) {
			return null;
		}

		if ( ! defined( 'DSM_DIR_URL' ) ) {
			return null;
		}

		return trailingslashit( DSM_DIR_URL )
			. DsmDiviBuilderCssScope::absolute_path_to_url_relative( $absolute );
	}

	/**
	 * Library folder basenames that have a compiled frontend CSS file on disk.
	 *
	 * @return list<string>
	 */
	public static function get_library_folders_with_frontend_css(): array {
		self::hydrate_persistent_library_index();

		if ( null !== self::$frontend_css_folders ) {
			return self::$frontend_css_folders;
		}

		$folders = array();

		foreach ( (array) glob( trailingslashit( self::get_module_library_path() ) . '*/frontend.css' ) as $absolute ) {
			if ( ! is_string( $absolute ) || ! is_readable( $absolute ) ) {
				continue;
			}

			$folder = basename( dirname( $absolute ) );

			if ( '' !== $folder ) {
				$folders[] = $folder;
			}
		}

		foreach ( (array) glob( trailingslashit( self::get_public_assets_path() ) . 'style-mlfe-*.css' ) as $absolute ) {
			if ( ! is_string( $absolute ) || ! is_readable( $absolute ) ) {
				continue;
			}

			if ( preg_match( '/^style-mlfe-(.+)\.css$/i', basename( $absolute ), $matches ) && '' !== $matches[1] ) {
				$folders[] = $matches[1];
			}
		}

		self::$frontend_css_folders = array_values( array_unique( $folders ) );
		self::$library_index_dirty  = true;
		self::schedule_asset_index_flush();

		return self::$frontend_css_folders;
	}

	/**
	 * Re-register monolithic + per-module frontend CSS with CPT/base URLs for the current request.
	 *
	 * Bundle handles are first registered on `init` (before the main query). Refresh here on
	 * `wp_enqueue_scripts` so WooCommerce products and other CPT singular views get `-cpt.css`.
	 *
	 * @return void
	 */
	public static function refresh_scoped_frontend_style_handles(): void {
		if ( ! defined( 'DSM_DIR_PATH' ) || ! defined( 'DSM_DIR_URL' ) ) {
			return;
		}

		// CPT/TB URLs are stable once the main query exists. Later render fallbacks must not rescan.
		if ( did_action( 'wp' ) && self::$scoped_styles_refreshed_after_wp ) {
			return;
		}

		self::register_core_modules_bundle_style_handle( true );
		self::register_extensions_bundle_style_handle( true );
		self::register_per_module_frontend_styles( true );
		self::refresh_scoped_auxiliary_style_handles();

		if ( did_action( 'wp' ) ) {
			self::$scoped_styles_refreshed_after_wp = true;
		}
	}

	/**
	 * Re-register shared Supreme styles registered on `init` (animate, flipbox, extensions).
	 *
	 * @return void
	 */
	public static function refresh_scoped_auxiliary_style_handles(): void {
		self::refresh_registered_style_handle(
			'dsm-supreme-animate',
			'divi-5/public/supreme-animate.css',
			'public/supreme-animate.css',
			array()
		);

		self::refresh_registered_style_handle(
			'dsm-flipbox-d5',
			'divi-5/assets/css/flipbox.css',
			'assets/css/flipbox.css',
			array()
		);

		self::refresh_registered_style_handle(
			'dsm-custom-cursor-frontend',
			'divi-5/public/style-custom-cursor-frontend-styles.css',
			'public/style-custom-cursor-frontend-styles.css',
			array()
		);

		self::refresh_registered_style_handle(
			'dsm-dark-mode-frontend',
			'divi-5/public/style-dark-mode-frontend-styles.css',
			'public/style-dark-mode-frontend-styles.css',
			array()
		);

		self::refresh_registered_style_handle(
			'dsm-icon-libraries-frontend',
			'divi-5/public/style-icon-libraries-frontend-styles.css',
			'public/style-icon-libraries-frontend-styles.css',
			array()
		);
	}

	/**
	 * Replace a registered style handle URL with the CPT/base variant for the current request.
	 *
	 * @param string        $handle        WordPress style handle.
	 * @param string        $path_relative Path relative to {@see DSM_DIR_PATH} (includes `divi-5/` when needed).
	 * @param string        $url_relative  Path relative to {@see DSM_DIR_URL} (no leading `divi-5/`).
	 * @param array<string> $deps          Style dependencies.
	 * @return void
	 */
	private static function refresh_registered_style_handle(
		string $handle,
		string $path_relative,
		string $url_relative,
		array $deps
	): void {
		if ( ! wp_style_is( $handle, 'registered' ) ) {
			return;
		}

		$base_path = DSM_DIR_PATH . ltrim( $path_relative, '/' );

		if ( ! is_readable( $base_path ) ) {
			return;
		}

		wp_deregister_style( $handle );

		wp_register_style(
			$handle,
			DsmDiviBuilderCssScope::resolve_stylesheet_url( DSM_DIR_URL . ltrim( $url_relative, '/' ) ),
			$deps,
			DsmDiviBuilderCssScope::resolve_stylesheet_version( $base_path )
		);
	}

	/**
	 * Register the monolithic module bundle (`style-modules-frontend-styles*.css`).
	 *
	 * @param bool $force_refresh When true, replace an existing registration (enqueue-time CPT resolution).
	 * @return void
	 */
	public static function register_core_modules_bundle_style_handle( bool $force_refresh = false ): void {
		$handle    = self::CORE_MODULES_STYLE_HANDLE;
		$relative  = 'divi-5/public/style-modules-frontend-styles.css';
		$base_path = DSM_DIR_PATH . $relative;

		if ( ! is_readable( $base_path ) ) {
			return;
		}

		if ( wp_style_is( $handle, 'registered' ) ) {
			if ( ! $force_refresh ) {
				return;
			}
			wp_deregister_style( $handle );
		}

		wp_register_style(
			$handle,
			DsmDiviBuilderCssScope::resolve_stylesheet_url( DSM_DIR_URL . 'public/style-modules-frontend-styles.css' ),
			array(),
			DsmDiviBuilderCssScope::resolve_stylesheet_version( $base_path )
		);
	}

	/**
	 * Register extension frontend bundle (`style-extensions-frontend-styles*.css`).
	 *
	 * CPT/TB requests load the `-cpt.css` companion via {@see DsmDiviBuilderCssScope::resolve_stylesheet_path()}.
	 *
	 * @param bool $force_refresh When true, replace an existing registration.
	 * @return void
	 */
	public static function register_extensions_bundle_style_handle( bool $force_refresh = false ): void {
		$handle    = self::EXTENSION_POPUP_STYLE_HANDLE;
		$relative  = 'divi-5/public/style-extensions-frontend-styles.css';
		$base_path = DSM_DIR_PATH . $relative;

		if ( ! is_readable( $base_path ) ) {
			return;
		}

		if ( wp_style_is( $handle, 'registered' ) ) {
			if ( ! $force_refresh ) {
				return;
			}
			wp_deregister_style( $handle );
		}

		// Animate.css is gated separately (`dsm-supreme-animate`); do not require it here.
		wp_register_style(
			$handle,
			DsmDiviBuilderCssScope::resolve_stylesheet_url( DSM_DIR_URL . 'public/style-extensions-frontend-styles.css' ),
			array(),
			DsmDiviBuilderCssScope::resolve_stylesheet_version( $base_path )
		);
	}

	/**
	 * Register built `frontend.css` per module folder when they exist under the published module-library tree.
	 *
	 * Handles are prefixed with {@see frontend_style_handle_for_library_folder()} and versioned via `filemtime()`.
	 *
	 * @param bool $force_refresh When true, replace existing registrations (enqueue-time CPT resolution).
	 * @return void
	 */
	public static function register_per_module_frontend_styles( bool $force_refresh = false ): void {
		if ( ! defined( 'DSM_DIR_URL' ) ) {
			return;
		}

		if ( ! $force_refresh && self::$scoped_styles_refreshed_after_wp ) {
			return;
		}

		$folders        = self::frontend_css_folders_for_request();
		$wanted_handles = array();

		foreach ( $folders as $folder ) {
			$wanted_handles[ self::frontend_style_handle_for_library_folder( $folder ) ] = true;
		}

		// A pre-query pass can register every folder. The post-query refresh must drop handles
		// for modules that are disabled or not on this request, or those styles stay queued.
		if ( $force_refresh ) {
			foreach ( self::get_library_folders_with_frontend_css() as $folder ) {
				$stale_handle = self::frontend_style_handle_for_library_folder( $folder );

				if ( isset( $wanted_handles[ $stale_handle ] ) ) {
					continue;
				}

				if ( wp_style_is( $stale_handle, 'registered' ) ) {
					wp_deregister_style( $stale_handle );
				}
			}
		}

		foreach ( $folders as $folder ) {
			$handle = self::frontend_style_handle_for_library_folder( $folder );

			if ( wp_style_is( $handle, 'registered' ) ) {
				if ( ! $force_refresh ) {
					continue;
				}
				wp_deregister_style( $handle );
			}

			$base_absolute = wp_normalize_path(
				trailingslashit( self::get_module_library_path() ) . $folder . '/frontend.css'
			);
			$flat_absolute = wp_normalize_path(
				trailingslashit( self::get_public_assets_path() ) . 'style-mlfe-' . $folder . '.css'
			);
			$source_base   = is_readable( $base_absolute ) ? $base_absolute : $flat_absolute;

			if ( ! is_readable( $source_base ) ) {
				continue;
			}

			$resolved = DsmDiviBuilderCssScope::resolve_stylesheet_path( $source_base );

			if ( ! is_readable( $resolved ) ) {
				continue;
			}

			wp_register_style(
				$handle,
				trailingslashit( DSM_DIR_URL ) . DsmDiviBuilderCssScope::absolute_path_to_url_relative( $resolved ),
				array(),
				DsmDiviBuilderCssScope::resolved_stylesheet_version( $resolved )
			);
		}
	}

	/**
	 * Enqueue a single module's split frontend CSS when dynamic assets are ON and the handle is registered.
	 *
	 * Does not load the monolithic {@see CORE_MODULES_STYLE_HANDLE} bundle.
	 *
	 * @param string $block_name Block `name` from module.json (e.g. `dsm/table-of-contents`).
	 * @return bool True if a style was enqueued.
	 */
	public static function maybe_enqueue_split_frontend_stylesheet_for_block( string $block_name ): bool {
		if ( ! function_exists( 'dsm_supreme_dynamic_assets_enabled' ) || ! dsm_supreme_dynamic_assets_enabled() ) {
			return false;
		}

		if ( function_exists( 'et_core_is_fb_enabled' ) && et_core_is_fb_enabled() ) {
			return false;
		}

		$folder = self::get_block_name_to_library_folder_map()[ $block_name ] ?? '';
		if ( '' === $folder ) {
			return false;
		}

		$handle = self::frontend_style_handle_for_library_folder( $folder );

		if ( ! wp_style_is( $handle, 'registered' ) ) {
			return false;
		}

		wp_enqueue_style( $handle );

		return true;
	}

	/**
	 * Absolute path to published module library (same tree PHP uses for module registration).
	 */
	public static function get_module_library_path(): string {
		return DSM_DIR_PATH . 'divi-5/public/packages/module-library';
	}

	/**
	 * Folders whose split CSS should be registered on this request.
	 *
	 * Before the main query, or when Divi has not registered blocks yet, every built folder is
	 * included so a hook-order surprise cannot drop CSS. After `wp`, only blocks WordPress
	 * actually registered are included, plus extension styles that are not a module toggle.
	 *
	 * @return list<string>
	 */
	private static function frontend_css_folders_for_request(): array {
		$all   = self::get_library_folders_with_frontend_css();
		$slugs = self::asset_block_slugs();

		if ( null === $slugs ) {
			return $all;
		}

		$map    = self::get_block_name_to_library_folder_map();
		$wanted = array();

		foreach ( $slugs as $slug ) {
			if ( isset( $map[ $slug ] ) ) {
				$wanted[ $map[ $slug ] ] = true;
			}
		}

		$folders = array();

		foreach ( $all as $folder ) {
			if ( isset( $wanted[ $folder ] ) ) {
				$folders[] = $folder;
			}
		}

		return $folders;
	}

	/**
	 * Block names that should receive frontend assets, or null to mean "every built module".
	 *
	 * @return list<string>|null
	 */
	private static function asset_block_slugs(): ?array {
		$registered = self::registered_dsm_block_slugs();

		if ( null === $registered ) {
			return null;
		}

		return array_values( array_unique( array_merge( $registered, self::extension_block_slugs() ) ) );
	}

	/**
	 * `dsm/*` blocks currently registered with WordPress.
	 *
	 * Returns null when the list would be a lie: before `wp`, when the block API is unavailable,
	 * or when modules are enabled but none have been registered yet.
	 *
	 * @return list<string>|null
	 */
	private static function registered_dsm_block_slugs(): ?array {
		if ( ! did_action( 'wp' ) ) {
			return null;
		}

		if ( self::$block_slug_lookup_done ) {
			return self::$registered_block_slugs;
		}

		self::$block_slug_lookup_done = true;

		if ( ! class_exists( '\WP_Block_Type_Registry' ) ) {
			self::$registered_block_slugs = null;

			return null;
		}

		$registry = \WP_Block_Type_Registry::get_instance();

		if ( ! is_object( $registry ) || ! method_exists( $registry, 'get_all_registered' ) ) {
			self::$registered_block_slugs = null;

			return null;
		}

		$registered = $registry->get_all_registered();

		if ( ! is_array( $registered ) ) {
			self::$registered_block_slugs = null;

			return null;
		}

		$names = array();

		foreach ( $registered as $name => $block_type ) {
			unset( $block_type );

			if ( is_string( $name ) && str_starts_with( $name, 'dsm/' ) ) {
				$names[] = $name;
			}
		}

		$modules_enabled = ! class_exists( \DiviSupreme\Core\ModuleRegistry::class ) || \DiviSupreme\Core\ModuleRegistry::has_enabled_module();

		if ( array() === $names && $modules_enabled ) {
			self::$registered_block_slugs = null;

			return null;
		}

		self::$registered_block_slugs = $names;

		return self::$registered_block_slugs;
	}

	/**
	 * Block names whose CSS must load even when that module's dashboard toggle is off.
	 *
	 * Line Hover Animation paints anchors inside other modules, so its stylesheet is not optional
	 * just because the standalone Line Hover module is disabled.
	 *
	 * @return list<string>
	 */
	private static function extension_block_slugs(): array {
		$slugs = array();

		$line_hover_enabled = function_exists( 'dsm_is_line_hover_animation_extension_enabled' )
			&& dsm_is_line_hover_animation_extension_enabled();

		if ( $line_hover_enabled ) {
			$slugs[] = 'dsm/line-hover';
		}

		return $slugs;
	}

	/**
	 * Drop per-request library and block-registry caches.
	 *
	 * @return void
	 */
	public static function reset_request_caches(): void {
		self::$disk_module_slugs                      = null;
		self::$block_name_to_library_folder_map       = null;
		self::$d4_shortcode_by_slug                   = null;
		self::$frontend_css_folders                   = null;
		self::$registered_block_slugs                 = null;
		self::$block_slug_lookup_done                 = false;
		self::$scoped_styles_refreshed_after_wp       = false;
		self::$persistent_index_checked               = false;
		self::$library_index_dirty                    = false;
		self::$stylesheet_versions_dirty              = false;
		self::$asset_index_flush_scheduled            = false;
		self::$asset_index_transient_key              = null;
		self::$icon_dependent_d4_shortcode_tags_cache = null;
	}

	/**
	 * Record that a stylesheet version was measured and should be stored with the library index.
	 *
	 * @return void
	 */
	public static function mark_stylesheet_versions_dirty(): void {
		if ( '' === self::asset_index_transient_key() ) {
			return;
		}

		self::$stylesheet_versions_dirty = true;
		self::schedule_asset_index_flush();
	}

	/**
	 * Write the library index and stylesheet versions for later requests.
	 *
	 * No-op until both the module.json index and the frontend.css folder list exist.
	 * The transient key includes the plugin version and the build file's mtime, so a
	 * plugin update or a frontend rebuild misses this cache.
	 *
	 * @return void
	 */
	public static function flush_persistent_library_index(): void {
		if ( ! self::$library_index_dirty && ! self::$stylesheet_versions_dirty ) {
			return;
		}

		if (
			null === self::$disk_module_slugs
			|| null === self::$block_name_to_library_folder_map
			|| null === self::$d4_shortcode_by_slug
			|| null === self::$frontend_css_folders
		) {
			return;
		}

		if ( ! function_exists( 'set_transient' ) ) {
			return;
		}

		$key = self::asset_index_transient_key();

		if ( '' === $key ) {
			return;
		}

		set_transient(
			$key,
			array(
				'slugs'      => self::$disk_module_slugs,
				'map'        => self::$block_name_to_library_folder_map,
				'folders'    => self::$frontend_css_folders,
				'shortcodes' => self::$d4_shortcode_by_slug,
				'mtimes'     => DsmDiviBuilderCssScope::export_version_cache(),
			),
			self::asset_index_ttl()
		);

		self::$library_index_dirty       = false;
		self::$stylesheet_versions_dirty = false;
	}

	/**
	 * Fill the in-request index from the transient when the build has not changed.
	 *
	 * @return void
	 */
	private static function hydrate_persistent_library_index(): void {
		if ( self::$persistent_index_checked ) {
			return;
		}

		self::$persistent_index_checked = true;

		if ( ! function_exists( 'get_transient' ) ) {
			return;
		}

		$key = self::asset_index_transient_key();

		if ( '' === $key ) {
			return;
		}

		$cached = get_transient( $key );

		if (
			! is_array( $cached )
			|| ! isset( $cached['slugs'], $cached['map'], $cached['folders'], $cached['shortcodes'] )
			|| ! is_array( $cached['slugs'] )
			|| ! is_array( $cached['map'] )
			|| ! is_array( $cached['folders'] )
			|| ! is_array( $cached['shortcodes'] )
		) {
			return;
		}

		self::$disk_module_slugs                = array_values( $cached['slugs'] );
		self::$block_name_to_library_folder_map = $cached['map'];
		self::$frontend_css_folders             = array_values( $cached['folders'] );
		self::$d4_shortcode_by_slug             = $cached['shortcodes'];

		if ( isset( $cached['mtimes'] ) && is_array( $cached['mtimes'] ) ) {
			DsmDiviBuilderCssScope::prime_version_cache( $cached['mtimes'] );
		}
	}

	/**
	 * Schedule one write at the end of the request.
	 *
	 * @return void
	 */
	private static function schedule_asset_index_flush(): void {
		if ( self::$asset_index_flush_scheduled || '' === self::asset_index_transient_key() ) {
			return;
		}

		self::$asset_index_flush_scheduled = true;

		if ( function_exists( 'add_action' ) ) {
			add_action( 'shutdown', array( self::class, 'flush_persistent_library_index' ), 0 );
		}
	}

	/**
	 * Transient name for the current plugin version and frontend build.
	 *
	 * An empty string means the build sentinel is missing, so the index stays in memory only.
	 *
	 * @return string
	 */
	private static function asset_index_transient_key(): string {
		if ( null !== self::$asset_index_transient_key ) {
			return self::$asset_index_transient_key;
		}

		self::$asset_index_transient_key = '';

		if ( ! defined( 'DSM_DIR_PATH' ) ) {
			return '';
		}

		$sentinel = rtrim( (string) DSM_DIR_PATH, '/\\' ) . '/divi-5/public/modules.js';

		if ( ! is_readable( $sentinel ) ) {
			return '';
		}

		$mtime = filemtime( $sentinel );

		if ( false === $mtime ) {
			return '';
		}

		$version = defined( 'DSM_PRO_VERSION' ) ? (string) DSM_PRO_VERSION : '0';

		self::$asset_index_transient_key = 'dsm_fe_asset_index_' . md5( $version . '|' . (string) $mtime );

		return self::$asset_index_transient_key;
	}

	/**
	 * How long the library index stays stored.
	 *
	 * The build sentinel already misses the cache when assets are rebuilt. The TTL drops
	 * abandoned keys after a version or build change.
	 *
	 * @return int
	 */
	private static function asset_index_ttl(): int {
		$default = defined( 'DAY_IN_SECONDS' ) ? (int) DAY_IN_SECONDS : 86400;
		$ttl     = $default;

		if ( function_exists( 'apply_filters' ) ) {
			$ttl = apply_filters( 'dsm_frontend_asset_index_ttl', $default );
		}

		$ttl = is_numeric( $ttl ) ? (int) $ttl : $default;

		return $ttl > 0 ? $ttl : $default;
	}
}
