<?php
/**
 * Whether the Supreme Parallax extension is enabled (General settings).
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * True when Divi Supreme → General → Enable Mouse Parallax is on (defaults to enabled when unset).
 *
 * @return bool
 */
function dsm_is_supreme_parallax_extension_enabled(): bool {
	$general = get_option( 'dsm_general', array() );

	if ( ! is_array( $general ) ) {
		return true;
	}

	if ( ! array_key_exists( 'dsm_use_supreme_parallax', $general ) ) {
		return true;
	}

	return 'on' === $general['dsm_use_supreme_parallax'];
}
