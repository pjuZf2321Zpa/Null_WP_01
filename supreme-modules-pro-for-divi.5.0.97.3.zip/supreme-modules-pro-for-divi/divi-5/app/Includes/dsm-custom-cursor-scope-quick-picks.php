<?php
/**
 * Custom Cursor scope picker — quick picks (homepage, current page) for Visual Builder.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

if ( ! function_exists( 'dsm_get_vb_builder_edited_post_id' ) ) {
	/**
	 * Post ID being edited in Divi Visual Builder (backend `?post=` or frontend singular).
	 *
	 * @return int
	 */
	function dsm_get_vb_builder_edited_post_id(): int {
		$post_id = 0;

		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only post ID for localized VB script data.
		if ( is_admin() && isset( $_GET['post'] ) ) {
			$post_id = absint( wp_unslash( $_GET['post'] ) );
		}
		// phpcs:enable WordPress.Security.NonceVerification.Recommended

		if ( 0 === $post_id && function_exists( 'is_singular' ) && is_singular() && function_exists( 'get_queried_object_id' ) ) {
			$queried = (int) get_queried_object_id();
			if ( $queried > 0 ) {
				$post_id = $queried;
			}
		}

		return $post_id;
	}
}

if ( ! function_exists( 'dsm_get_custom_cursor_scope_quick_picks' ) ) {
	/**
	 * Quick-add targets for the Custom Cursor scope page picker.
	 *
	 * @param int $builder_edited_post_id Post open in the builder (0 when unknown).
	 * @return array<string, array<string, mixed>>
	 */
	function dsm_get_custom_cursor_scope_quick_picks( int $builder_edited_post_id = 0 ): array {
		$homepage_id        = 0;
		$homepage_title     = '';
		$homepage_available = false;
		$homepage_reason    = __(
			'Set a static homepage under Settings → Reading.',
			'dsm-supreme-modules-pro-for-divi'
		);

		if ( 'page' === get_option( 'show_on_front' ) ) {
			$homepage_id = absint( get_option( 'page_on_front' ) );
			if ( $homepage_id > 0 ) {
				$homepage_available = true;
				$homepage_title     = dsm_get_custom_cursor_scope_post_title( $homepage_id );
				$homepage_reason    = '';
			}
		}

		$current_id        = max( 0, $builder_edited_post_id );
		$current_title     = '';
		$current_available = false;
		$current_reason    = __(
			'Open a page or post in the builder to use this shortcut.',
			'dsm-supreme-modules-pro-for-divi'
		);
		$current_type      = '';

		if ( $current_id > 0 ) {
			$current_available = true;
			$current_title     = dsm_get_custom_cursor_scope_post_title( $current_id );
			$current_reason    = '';
			$type_object       = get_post_type_object( (string) get_post_type( $current_id ) );
			$current_type      = $type_object instanceof \WP_Post_Type
				? (string) $type_object->labels->singular_name
				: '';
		}

		return array(
			'homepage'    => array(
				'id'        => $homepage_id,
				'title'     => $homepage_title,
				'available' => $homepage_available,
				'reason'    => $homepage_reason,
			),
			'currentPage' => array(
				'id'              => $current_id,
				'title'           => $current_title,
				'post_type_label' => $current_type,
				'available'       => $current_available,
				'reason'          => $current_reason,
			),
		);
	}
}

if ( ! function_exists( 'dsm_get_custom_cursor_scope_post_title' ) ) {
	/**
	 * Dsm get custom cursor scope post title.
	 *
	 * @param int $post_id Post ID.
	 * @return string
	 */
	function dsm_get_custom_cursor_scope_post_title( int $post_id ): string {
		if ( $post_id <= 0 ) {
			return '';
		}

		$title = get_the_title( $post_id );

		if ( is_string( $title ) && '' !== trim( $title ) ) {
			return wp_strip_all_tags( $title );
		}

		return sprintf(
			/* translators: %d: post ID */
			__( 'Untitled (#%d)', 'dsm-supreme-modules-pro-for-divi' ),
			$post_id
		);
	}
}
