<?php
/**
 * Shared Divi Library layout rendering for Supreme modules (D5 blocks + D4 shortcode fallback).
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Includes;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Renders saved Divi Library layouts inside parent modules (Content Toggle, Advanced Tabs child, etc.).
 *
 * This class is namespaced, so global Divi classes must be called with a leading backslash
 * (`\ET_Builder_Element`). `class_exists( 'ET_Builder_Element' )` checks the global class, but an
 * unqualified call resolves to `DiviSupreme\Includes\ET_Builder_Element` and fatals when a library
 * render falls back to the legacy shortcode path.
 */
final class DiviLibraryLayoutRenderer {


	/**
	 * Depth of nested `et_builder_render_layout` calls (libraries inside modules inside libraries).
	 *
	 * @var int
	 */
	private static $nested_library_parse_depth = 0;

	/**
	 * Layout post IDs currently rendering (recursion guard for nested `[divi_shortcode]` / library embeds).
	 *
	 * @var array<int, true>
	 */
	private static array $rendering_layout_ids = array();

	/**
	 * Normalize a library post ID from module attrs (int, numeric string, `id|layout_type`, etc.).
	 *
	 * @param mixed $raw Raw attribute value.
	 * @return int Post ID or 0.
	 */
	public static function normalize_post_id( $raw ): int {
		if ( is_string( $raw ) && str_contains( $raw, '|' ) ) {
			$raw = explode( '|', $raw, 2 )[0];
		}

		if ( is_numeric( $raw ) ) {
			$id = (int) $raw;

			return $id > 0 ? $id : 0;
		}

		return 0;
	}

	/**
	 * Resolve Divi Library `layout_type` slug for shortcode fallback wrapping.
	 *
	 * @param \WP_Post $layout_post Library post.
	 * @return string layout|section|row|module
	 */
	private static function get_library_item_type( \WP_Post $layout_post ): string {
		$type = '';

		if ( class_exists( DsmLibraryLayoutSelectOptions::class ) ) {
			$type = DsmLibraryLayoutSelectOptions::get_layout_type_slug( (int) $layout_post->ID );
		}

		if ( '' === $type && function_exists( 'et_pb_get_layout_type' ) ) {
			$raw = et_pb_get_layout_type( (int) $layout_post->ID );
			if ( is_string( $raw ) && '' !== $raw ) {
				$type = sanitize_key( explode( '|', $raw )[0] );
			}
		}

		if ( '' === $type ) {
			$terms = wp_get_post_terms( (int) $layout_post->ID, 'layout_type', array( 'fields' => 'slugs' ) );
			if ( ! is_wp_error( $terms ) && isset( $terms[0] ) && is_string( $terms[0] ) ) {
				$type = sanitize_key( $terms[0] );
			}
		}

		if ( in_array( $type, array( 'layout', 'section', 'row', 'module' ), true ) ) {
			return $type;
		}

		return 'layout';
	}

	/**
	 * D4-style global-module shortcode for library items when block render returns empty.
	 *
	 * Section/layout use `[et_pb_section global_module]`. Row is wrapped in a section.
	 * Module content is loaded and placed in a single-column section/row shell.
	 *
	 * @param int      $layout_post_id Library post ID.
	 * @param \WP_Post $layout_post    Library post.
	 * @return string Shortcode markup (not escaped).
	 */
	private static function build_global_module_fallback_shortcode( int $layout_post_id, \WP_Post $layout_post ): string {
		$type = self::get_library_item_type( $layout_post );

		if ( 'row' === $type ) {
			return sprintf(
				'[et_pb_section fullwidth="on"][et_pb_row global_module="%1$d" template_type="row"][/et_pb_row][/et_pb_section]',
				$layout_post_id
			);
		}

		if ( 'module' === $type ) {
			$inner = '';
			if ( function_exists( 'et_pb_load_global_module' ) ) {
				$loaded = et_pb_load_global_module( $layout_post_id );
				$inner  = is_string( $loaded ) ? $loaded : '';
			}
			if ( '' === trim( $inner ) ) {
				$inner = (string) $layout_post->post_content;
			}

			return sprintf(
				'[et_pb_section fullwidth="on"][et_pb_row][et_pb_column type="4_4"]%1$s[/et_pb_column][/et_pb_row][/et_pb_section]',
				$inner
			);
		}

		// section + layout (and unknown): Divi’s section global_module loader.
		return sprintf(
			'[et_pb_section global_module="%1$d" template_type="section" fullwidth="on"][/et_pb_section]',
			$layout_post_id
		);
	}

	/**
	 * Shortcode tags that embed a Divi Library layout by post ID.
	 *
	 * Canonical: `divi_shortcode`. Alias: `divi_library_layout` (migrated / third-party content).
	 */
	private const LIBRARY_EMBED_SHORTCODE_TAG_PATTERN = 'divi_shortcode|divi_library_layout';

	/**
	 * Extract `et_pb_layout` post IDs from library-embed shortcode tags in a string.
	 *
	 * Recognizes `[divi_shortcode id="…"]` and `[divi_library_layout id="…"]`.
	 *
	 * @param string $content Shortcode field or post content.
	 * @return int[] Unique positive layout IDs in document order.
	 */
	public static function extract_divi_shortcode_layout_ids( string $content ): array {
		$tag_alt = self::LIBRARY_EMBED_SHORTCODE_TAG_PATTERN;

		if ( '' === $content || 1 !== preg_match( '/\[(?:' . $tag_alt . ')\b/i', $content ) ) {
			return array();
		}

		$matches = array();
		if ( 1 !== preg_match_all( '/\[(?:' . $tag_alt . ')\b[^\]]*\bid\s*=\s*["\']?(\d+)["\']?/i', $content, $matches, PREG_SET_ORDER ) ) {
			return array();
		}

		$ids = array();
		foreach ( $matches as $match ) {
			$id = self::normalize_post_id( $match[1] ?? 0 );
			if ( $id > 0 && ! in_array( $id, $ids, true ) ) {
				$ids[] = $id;
			}
		}

		return $ids;
	}

	/**
	 * True when trimmed content is only one or more library-embed shortcode tags (optional whitespace).
	 *
	 * @param string $content Shortcode field value.
	 * @return bool
	 */
	public static function content_is_only_divi_shortcode_tags( string $content ): bool {
		$trimmed = trim( $content );
		if ( '' === $trimmed ) {
			return false;
		}

		$tag_alt      = self::LIBRARY_EMBED_SHORTCODE_TAG_PATTERN;
		$without_tags = (string) preg_replace( '/\s+/', '', $trimmed );
		$without_tags = (string) preg_replace( '/\[(?:' . $tag_alt . ')\b[^\]]*\]/i', '', $without_tags );

		return '' === $without_tags;
	}

	/**
	 * Render a module "shortcode" content field: library-embed tags use {@see self::render_layout()}.
	 *
	 * Other shortcodes use `do_shortcode()` only (same as D4 Advanced Tabs). Do not run
	 * `the_content` / `wpautop` here — that wraps third-party output in empty `<p></p>`
	 * and Divi's `.et-l` layout chrome.
	 *
	 * @param string $shortcode_content     Raw field value from module attrs.
	 * @param string $fallback_style_prefix Prefix for inline `<style>` in D4 shortcode fallback.
	 * @return string Rendered HTML (not HTML-escaped).
	 */
	public static function render_shortcode_field_content( string $shortcode_content, string $fallback_style_prefix = 'dsm_shortcode_field_styles' ): string {
		$shortcode_content = html_entity_decode( $shortcode_content, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
		$trimmed           = trim( $shortcode_content );

		if ( '' === $trimmed ) {
			return '';
		}

		if ( self::content_is_only_divi_shortcode_tags( $trimmed ) ) {
			$pieces = array();
			foreach ( self::extract_divi_shortcode_layout_ids( $trimmed ) as $layout_id ) {
				$rendered = self::render_layout( $layout_id, $fallback_style_prefix );
				if ( is_string( $rendered ) && '' !== $rendered ) {
					$pieces[] = $rendered;
				}
			}

			return implode( '', $pieces );
		}

		$html = $trimmed;
		if ( function_exists( 'shortcode_unautop' ) ) {
			$html = shortcode_unautop( $html );
		}

		return (string) do_shortcode( $html );
	}

	/**
	 * True when HTML already starts with Divi's layout wrapper (`et-l` on the root element).
	 *
	 * {@see et_builder_add_builder_content_wrapper} is hooked to {@see et_builder_render_layout} and
	 * prepends/appends {@see et_builder_get_layout_opening_wrapper} / closing — wrapping again duplicates
	 * `.et-l` / `.et_builder_inner_content`.
	 *
	 * @param string $markup Trimmed HTML.
	 * @return bool
	 */
	private static function layout_markup_has_et_containers( string $markup ): bool {
		if ( '' === $markup ) {
			return false;
		}

		return 1 === preg_match( '/^\s*<\s*(?:div|header|footer)\b[^>]*\bet-l\b/i', $markup );
	}

	/**
	 * Let this library render write instance CSS even when the host page already enqueued static CSS.
	 *
	 * Divi skips `styles` callbacks when `ET_Core_PageResource::$enqueued` is true, because those
	 * rules are supposed to live in the current page file. A Library post is not in that file, so
	 * the embed keeps the markup and loses backgrounds, flex layout, and button styles.
	 *
	 * @return bool|null Previous flag, or null when Divi has no style manager on this request.
	 */
	private static function suspend_host_static_css_enqueue(): ?bool {
		if ( ! class_exists( '\ET\Builder\FrontEnd\Assets\StaticCSS' ) ) {
			return null;
		}

		$manager = \ET\Builder\FrontEnd\Assets\StaticCSS::$styles_manager;

		if ( ! is_object( $manager ) || ! property_exists( $manager, 'enqueued' ) ) {
			return null;
		}

		$previous          = (bool) $manager->enqueued;
		$manager->enqueued = false;

		return $previous;
	}

	/**
	 * Restore the host page static-CSS flag after a library render.
	 *
	 * @param bool|null $previous Value from {@see self::suspend_host_static_css_enqueue()}.
	 * @return void
	 */
	private static function restore_host_static_css_enqueue( ?bool $previous ): void {
		if ( null === $previous || ! class_exists( '\ET\Builder\FrontEnd\Assets\StaticCSS' ) ) {
			return;
		}

		$manager = \ET\Builder\FrontEnd\Assets\StaticCSS::$styles_manager;

		if ( ! is_object( $manager ) ) {
			return;
		}

		$manager->enqueued = $previous;
	}

	/**
	 * Snapshot Divi Style store and clear it so nested library CSS cannot merge into the page bucket.
	 *
	 * Nested `et_builder_render_layout()` writes instance rules (`.et_pb_row_0 { max-width: … }`)
	 * into the shared `post` style key. Divi then concatenates those declarations onto the page’s
	 * matching order class -- Code-module `[divi_shortcode]` embeds were clamping the page hero row.
	 *
	 * Divi 5.11.1 does not define `Style::capture_state()`. {@see DsmDiviStyleState} snapshots
	 * the same private `$_styles` bucket (and the rest of the static style state) and restores
	 * it after the embed's CSS has been copied out. Page order-class rules therefore stay on
	 * the page, and the embed's rules are printed from the isolated bucket only.
	 *
	 * @return array<string, mixed>|null Snapshot from {@see DsmDiviStyleState::begin_isolation()}, or null.
	 */
	private static function begin_library_style_isolation(): ?array {
		return DsmDiviStyleState::begin_isolation();
	}

	/**
	 * Restore the page Style store after an isolated library render.
	 *
	 * @param array<string, mixed>|null $state Snapshot from {@see self::begin_library_style_isolation()}.
	 * @return void
	 */
	private static function end_library_style_isolation( ?array $state ): void {
		DsmDiviStyleState::end_isolation( $state );
	}

	/**
	 * Wraps rendered library HTML with Divi layout containers (`et-l`, `et_builder_inner_content`).
	 *
	 * @param string   $markup      Rendered layout HTML.
	 * @param \WP_Post $layout_post Library post (used for `post_type`; falls back to `et_pb_layout`).
	 * @return string
	 */
	private static function wrap_divi_library_markup( string $markup, \WP_Post $layout_post ): string {
		if ( '' === trim( $markup ) ) {
			return '';
		}

		if ( ! function_exists( 'et_builder_get_layout_opening_wrapper' ) || ! function_exists( 'et_builder_get_layout_closing_wrapper' ) ) {
			return $markup;
		}

		$layout_post_type = $layout_post->post_type;

		if ( '' === $layout_post_type ) {
			$layout_post_type = defined( 'ET_BUILDER_LAYOUT_POST_TYPE' ) ? ET_BUILDER_LAYOUT_POST_TYPE : 'et_pb_layout';
		}

		return et_builder_get_layout_opening_wrapper( $layout_post_type )
			. $markup
			. et_builder_get_layout_closing_wrapper( $layout_post_type );
	}

	/**
	 * Forces a dedicated BlockParserStore while parsing nested library content.
	 *
	 * @param bool $new_store_instance Divi default.
	 * @return bool
	 */
	public static function filter_force_new_block_parser_store_for_nested_library( $new_store_instance ) {
		if ( self::$nested_library_parse_depth > 0 ) {
			return true;
		}

		return (bool) $new_store_instance;
	}

	/**
	 * Begin nested library block parser isolation.
	 *
	 * @return void
	 */
	private static function begin_nested_library_block_parser_isolation() {
		if ( 0 === self::$nested_library_parse_depth ) {
			add_filter(
				'divi_front_end_block_parser_new_store_instance',
				array( self::class, 'filter_force_new_block_parser_store_for_nested_library' ),
				10,
				1
			);
		}
		++self::$nested_library_parse_depth;
	}

	/**
	 * End nested library block parser isolation.
	 *
	 * @return void
	 */
	private static function end_nested_library_block_parser_isolation() {
		--self::$nested_library_parse_depth;
		if ( self::$nested_library_parse_depth <= 0 ) {
			self::$nested_library_parse_depth = 0;
			remove_filter(
				'divi_front_end_block_parser_new_store_instance',
				array( self::class, 'filter_force_new_block_parser_store_for_nested_library' ),
				10
			);
		}
	}

	/**
	 * Begin nested-library render: continue module order indices instead of restarting at _0.
	 *
	 * @return bool Previous inner-content flag.
	 */
	private static function begin_divi_nested_library_order_context(): bool {
		if ( ! class_exists( '\ET\Builder\FrontEnd\BlockParser\BlockParserStore' ) ) {
			return false;
		}

		$previous = \ET\Builder\FrontEnd\BlockParser\BlockParserStore::is_rendering_inner_content();
		\ET\Builder\FrontEnd\BlockParser\BlockParserStore::set_rendering_inner_content( true );

		return $previous;
	}

	/**
	 * Restore inner-content flag after nested library render.
	 *
	 * @param bool $previous_flag Value from {@see self::begin_divi_nested_library_order_context()}.
	 * @return void
	 */
	private static function end_divi_nested_library_order_context( bool $previous_flag ): void {
		if ( ! class_exists( '\ET\Builder\FrontEnd\BlockParser\BlockParserStore' ) ) {
			return;
		}

		\ET\Builder\FrontEnd\BlockParser\BlockParserStore::set_rendering_inner_content( $previous_flag );
	}

	/**
	 * Renders a library layout using the same Builder flags as standalone REST previews
	 * ({@see DSM_Library_Layout_Preview_REST}) so Scroll/Animation ScriptData matches the DOM root.
	 * Not for nested layouts inside modules on the frontend — use {@see self::render_layout()} there.
	 *
	 * @param int $layout_post_id Library post ID (`et_pb_layout`).
	 * @return string Rendered HTML.
	 */
	public static function render_standalone_library_layout_for_visual_builder_preview( int $layout_post_id ): string {
		if ( $layout_post_id <= 0 ) {
			return '';
		}

		$layout_post = get_post( $layout_post_id );
		if ( ! $layout_post instanceof \WP_Post ) {
			return '';
		}

		if ( class_exists( DsmFrontendDynamicAssets::class ) ) {
			DsmFrontendDynamicAssets::enqueue_assets_for_library_layout( $layout_post );
		}

		$html              = '';
		$previous_inner    = false;
		$previous_tb_inner = false;

		if ( class_exists( '\ET\Builder\FrontEnd\BlockParser\BlockParserStore' ) ) {
			$previous_inner = \ET\Builder\FrontEnd\BlockParser\BlockParserStore::is_rendering_inner_content();
			\ET\Builder\FrontEnd\BlockParser\BlockParserStore::set_rendering_inner_content( false );
		}
		if ( class_exists( '\ET\Builder\FrontEnd\Module\Style' ) ) {
			$previous_tb_inner = \ET\Builder\FrontEnd\Module\Style::get_is_theme_builder_context_for_inner_content();
			\ET\Builder\FrontEnd\Module\Style::set_is_theme_builder_context_for_inner_content( true );
		}

		$stack_class = class_exists( 'ET_Post_Stack' );

		if ( $stack_class ) {
			\ET_Post_Stack::replace( $layout_post );
		}

		try {
			if ( function_exists( 'et_builder_render_layout' ) ) {
				$rendered = et_builder_render_layout( (string) $layout_post->post_content );
				if ( function_exists( 'et_core_intentionally_unescaped' ) ) {
					$html = (string) et_core_intentionally_unescaped( $rendered, 'html' );
				} else {
					$html = (string) $rendered;
				}
			}
		} finally {
			if ( $stack_class ) {
				\ET_Post_Stack::restore();
			}
			if ( class_exists( '\ET\Builder\FrontEnd\Module\Style' ) ) {
				\ET\Builder\FrontEnd\Module\Style::set_is_theme_builder_context_for_inner_content( $previous_tb_inner );
			}
			if ( class_exists( '\ET\Builder\FrontEnd\BlockParser\BlockParserStore' ) ) {
				\ET\Builder\FrontEnd\BlockParser\BlockParserStore::set_rendering_inner_content( $previous_inner );
			}
		}

		$html_trim = trim( (string) $html );

		if ( '' === $html_trim && class_exists( 'ET_Builder_Element' ) ) {
			self::begin_nested_library_block_parser_isolation();

			try {
				\ET_Builder_Element::clean_internal_modules_styles();

				ob_start();

				echo do_shortcode(
					self::build_global_module_fallback_shortcode( $layout_post_id, $layout_post )
				);

				$internal_style = \ET_Builder_Element::get_style();
				\ET_Builder_Element::clean_internal_modules_styles( false );

				$shortcode_html = (string) ob_get_clean();

				$style_markup = '';

				if ( is_string( $internal_style ) && '' !== $internal_style ) {
					$fallback_prefix = 'dsm_library_embed_standalone_styles';
					$style_markup    = sprintf(
						'<style id="%1$s-%2$d" type="text/css" class="%1$s-%2$d">%3$s</style>',
						esc_attr( $fallback_prefix ),
						$layout_post_id,
						$internal_style
					);
				}

				return self::wrap_divi_library_markup( $style_markup . $shortcode_html, $layout_post );
			} finally {
				self::end_nested_library_block_parser_isolation();
			}
		}

		if ( '' === trim( (string) $html_trim ) ) {
			return '';
		}

		if ( self::layout_markup_has_et_containers( $html_trim ) ) {
			return $html_trim;
		}

		return self::wrap_divi_library_markup( $html_trim, $layout_post );
	}

	/**
	 * Frontend markup for `[divi_shortcode]`, using the same Builder flags as
	 * `POST /dsm/v1/library-layout-preview` ({@see DSM_Library_Layout_Preview_REST}).
	 *
	 * The host page Style store is snapshotted so library rules can be printed under
	 * `.dsm-library-layout-renderer` and then the page store is restored.
	 *
	 * @param int $layout_post_id Library post ID (`et_pb_layout`).
	 * @return string HTML plus scoped preview CSS.
	 */
	public static function render_library_preview( int $layout_post_id ): string {
		if ( $layout_post_id <= 0 ) {
			return '';
		}

		if ( isset( self::$rendering_layout_ids[ $layout_post_id ] ) ) {
			return '';
		}

		$layout_post = get_post( $layout_post_id );

		if ( ! $layout_post instanceof \WP_Post ) {
			return '';
		}

		$layout_type = defined( 'ET_BUILDER_LAYOUT_POST_TYPE' ) ? ET_BUILDER_LAYOUT_POST_TYPE : 'et_pb_layout';
		if ( $layout_type !== $layout_post->post_type ) {
			return '';
		}

		self::$rendering_layout_ids[ $layout_post_id ] = true;

		if ( class_exists( DsmFrontendDynamicAssets::class ) ) {
			DsmFrontendDynamicAssets::enqueue_assets_for_library_layout( $layout_post );
		}

		$html                = '';
		$custom_css          = '';
		$module_css          = '';
		$style_state         = self::begin_library_style_isolation();
		$static_css_enqueued = null;
		$previous_inner      = false;
		$previous_tb_inner   = false;

		if ( class_exists( '\ET\Builder\FrontEnd\BlockParser\BlockParserStore' ) ) {
			$previous_inner = \ET\Builder\FrontEnd\BlockParser\BlockParserStore::is_rendering_inner_content();
			\ET\Builder\FrontEnd\BlockParser\BlockParserStore::set_rendering_inner_content( false );
		}
		if ( class_exists( '\ET\Builder\FrontEnd\Module\Style' ) ) {
			$previous_tb_inner = \ET\Builder\FrontEnd\Module\Style::get_is_theme_builder_context_for_inner_content();
			\ET\Builder\FrontEnd\Module\Style::set_is_theme_builder_context_for_inner_content( true );
		}

		$stack_class = class_exists( 'ET_Post_Stack' );

		try {
			$static_css_enqueued = self::suspend_host_static_css_enqueue();

			if ( $stack_class ) {
				\ET_Post_Stack::replace( $layout_post );
			}

			if ( function_exists( 'et_builder_render_layout' ) ) {
				$rendered = et_builder_render_layout( (string) $layout_post->post_content );
				if ( function_exists( 'et_core_intentionally_unescaped' ) ) {
					$html = (string) et_core_intentionally_unescaped( $rendered, 'html' );
				} else {
					$html = (string) $rendered;
				}
			}

			if ( class_exists( '\ET\Builder\FrontEnd\Page' ) ) {
				$custom_css = (string) \ET\Builder\FrontEnd\Page::custom_css( $layout_post_id );
			}

			if ( class_exists( '\ET\Builder\FrontEnd\Module\Style' ) ) {
				$snapshot = DsmDiviStyleState::capture();
				$keys     = array();
				if ( isset( $snapshot['styles'] ) && is_array( $snapshot['styles'] ) ) {
					$keys = array_keys( $snapshot['styles'] );
				}
				if ( empty( $keys ) ) {
					$keys[] = 'post';
				}

				foreach ( $keys as $key ) {
					foreach ( array( 'default', 'critical' ) as $style_type ) {
						$module_css .= \ET\Builder\FrontEnd\Module\Style::render( $style_type, 'presetNested', $key )
							. \ET\Builder\FrontEnd\Module\Style::render( $style_type, 'preset', $key )
							. \ET\Builder\FrontEnd\Module\Style::render( $style_type, 'presetGroup', $key )
							. \ET\Builder\FrontEnd\Module\Style::render( $style_type, 'module', $key );
					}
					\ET\Builder\FrontEnd\Module\Style::clear_styles_for_key( $key );
				}
				\ET\Builder\FrontEnd\Module\Style::set_detected_module_types_for_inner_content( array() );
			}
		} finally {
			if ( $stack_class ) {
				\ET_Post_Stack::restore();
			}
			if ( class_exists( '\ET\Builder\FrontEnd\Module\Style' ) ) {
				\ET\Builder\FrontEnd\Module\Style::set_is_theme_builder_context_for_inner_content( $previous_tb_inner );
			}
			if ( class_exists( '\ET\Builder\FrontEnd\BlockParser\BlockParserStore' ) ) {
				\ET\Builder\FrontEnd\BlockParser\BlockParserStore::set_rendering_inner_content( $previous_inner );
			}
			self::restore_host_static_css_enqueue( $static_css_enqueued );
			self::end_library_style_isolation( $style_state );
			unset( self::$rendering_layout_ids[ $layout_post_id ] );
		}

		$html_trim = trim( (string) $html );

		if ( '' === $html_trim && class_exists( 'ET_Builder_Element' ) ) {
			\ET_Builder_Element::clean_internal_modules_styles();
			ob_start();
			echo do_shortcode(
				self::build_global_module_fallback_shortcode( $layout_post_id, $layout_post )
			);
			$internal_style = \ET_Builder_Element::get_style();
			\ET_Builder_Element::clean_internal_modules_styles( false );
			$html_trim = trim( (string) ob_get_clean() );
			if ( is_string( $internal_style ) && '' !== $internal_style ) {
				$module_css .= $internal_style;
			}
		}

		if ( '' === $html_trim ) {
			return '';
		}

		if ( ! self::layout_markup_has_et_containers( $html_trim ) ) {
			$html_trim = self::wrap_divi_library_markup( $html_trim, $layout_post );
		}

		$scope        = DsmPreviewScriptScope::library_layout_renderer_root_selector( $layout_post_id );
		$css          = $custom_css . $module_css;
		$style_markup = '';

		if ( '' !== trim( $css ) ) {
			$scoped = DsmCssPreviewScope::apply( $css, $scope );
			$scoped = wp_strip_all_tags( $scoped );
			if ( '' !== trim( $scoped ) ) {
				$style_markup = sprintf(
					'<style class="dsm-library-layout-preview-css" type="text/css">%s</style>',
					$scoped
				);
			}
		}

		$inner = $style_markup . $html_trim;
		if ( function_exists( 'et_core_intentionally_unescaped' ) ) {
			$inner = (string) et_core_intentionally_unescaped( $inner, 'html' );
		}

		$markup = sprintf(
			'<div class="dsm-library-layout-renderer" data-dsm-library-preview="%1$d">%2$s</div>',
			absint( $layout_post_id ),
			$inner
		);

		/**
		 * Filter frontend markup for a `[divi_shortcode]` library preview.
		 *
		 * @param string $markup         HTML and scoped CSS.
		 * @param int    $layout_post_id Library post ID.
		 */
		$filtered = apply_filters( 'dsm_divi_shortcode_library_preview_markup', $markup, $layout_post_id );

		return is_string( $filtered ) ? $filtered : $markup;
	}

	/**
	 * Read order-class design CSS written by the current isolated library render.
	 *
	 * @param int $layout_post_id Library post ID.
	 * @return string CSS text, including global color variables when the rules reference them.
	 */
	private static function capture_library_design_css( int $layout_post_id ): string {
		$css = '';

		if ( class_exists( '\ET\Builder\FrontEnd\Page' ) ) {
			$css .= (string) \ET\Builder\FrontEnd\Page::custom_css( $layout_post_id );
		}

		if ( class_exists( '\ET\Builder\FrontEnd\Module\Style' ) ) {
			$snapshot = DsmDiviStyleState::capture();
			$keys     = array();
			if ( isset( $snapshot['styles'] ) && is_array( $snapshot['styles'] ) ) {
				$keys = array_keys( $snapshot['styles'] );
			}
			if ( empty( $keys ) ) {
				$keys[] = 'post';
			}

			foreach ( $keys as $key ) {
				foreach ( array( 'default', 'critical' ) as $style_type ) {
					$css .= \ET\Builder\FrontEnd\Module\Style::render( $style_type, 'presetNested', $key )
						. \ET\Builder\FrontEnd\Module\Style::render( $style_type, 'preset', $key )
						. \ET\Builder\FrontEnd\Module\Style::render( $style_type, 'presetGroup', $key )
						. \ET\Builder\FrontEnd\Module\Style::render( $style_type, 'module', $key );
				}
				\ET\Builder\FrontEnd\Module\Style::clear_styles_for_key( $key );
			}
			\ET\Builder\FrontEnd\Module\Style::set_detected_module_types_for_inner_content( array() );

			if ( false !== strpos( $css, '--gcid-' ) && preg_match_all( '/--(gcid-[a-z0-9_-]+)/i', $css, $color_ids ) ) {
				$ids = array_values( array_unique( $color_ids[1] ) );
				$css = \ET\Builder\FrontEnd\Module\Style::get_global_colors_style( $ids ) . $css;
			}
		}

		return $css;
	}

	/**
	 * Prepend `<style id="{prefix}-{id}">` when the D5 render produced design CSS.
	 *
	 * @param string $html                     Layout HTML.
	 * @param int    $layout_post_id           Library post ID.
	 * @param string $fallback_style_id_prefix Style id prefix.
	 * @return string
	 */
	private static function with_captured_design_css( string $html, int $layout_post_id, string $fallback_style_id_prefix ): string {
		$css = self::capture_library_design_css( $layout_post_id );
		$css = wp_strip_all_tags( $css );

		if ( '' === trim( $css ) ) {
			return $html;
		}

		$style_markup = sprintf(
			'<style id="%1$s-%2$d" type="text/css" class="%1$s-%2$d">%3$s</style>',
			esc_attr( $fallback_style_id_prefix ),
			$layout_post_id,
			$css
		);

		$combined = $style_markup . $html;

		if ( function_exists( 'et_core_intentionally_unescaped' ) ) {
			return (string) et_core_intentionally_unescaped( $combined, 'html' );
		}

		return $combined;
	}

	/**
	 * Renders a Divi Library item (blocks + shortcodes + post context).
	 *
	 * Falls back to the legacy `[et_pb_section global_module]` shortcode + captured module CSS (D4 parity).
	 * The Divi 5 path isolates the Style store, suspends the host static-CSS skip, and prepends the layout's order-class CSS.
	 *
	 * @param int    $layout_post_id            Library post ID (`et_pb_layout`).
	 * @param string $fallback_style_id_prefix  Prefix for `<style id="PREFIX-%d">` (no `%d`).
	 * @return string Rendered HTML.
	 */
	public static function render_layout( int $layout_post_id, string $fallback_style_id_prefix = 'dsm_library_embed_styles' ): string {
		if ( $layout_post_id <= 0 ) {
			return '';
		}

		if ( isset( self::$rendering_layout_ids[ $layout_post_id ] ) ) {
			return '';
		}

		$layout_post = get_post( $layout_post_id );

		if ( ! $layout_post instanceof \WP_Post ) {
			return '';
		}

		$layout_type = defined( 'ET_BUILDER_LAYOUT_POST_TYPE' ) ? ET_BUILDER_LAYOUT_POST_TYPE : 'et_pb_layout';
		if ( $layout_type !== $layout_post->post_type ) {
			return '';
		}

		self::$rendering_layout_ids[ $layout_post_id ] = true;

		if ( class_exists( DsmFrontendDynamicAssets::class ) ) {
			DsmFrontendDynamicAssets::enqueue_assets_for_library_layout( $layout_post );
		}

		$html                = '';
		$style_state         = null;
		$static_css_enqueued = null;

		try {
			$style_state         = self::begin_library_style_isolation();
			$static_css_enqueued = self::suspend_host_static_css_enqueue();

			if ( class_exists( '\ET_Post_Stack' ) && function_exists( 'et_builder_render_layout' ) ) {
				\ET_Post_Stack::replace( $layout_post );
				$was_inner_order = self::begin_divi_nested_library_order_context();
				self::begin_nested_library_block_parser_isolation();

				try {
					$rendered = et_builder_render_layout( (string) $layout_post->post_content );
					if ( function_exists( 'et_core_intentionally_unescaped' ) ) {
						$html = (string) et_core_intentionally_unescaped( $rendered, 'html' );
					} else {
						$html = (string) $rendered;
					}
				} finally {
					self::end_nested_library_block_parser_isolation();
					self::end_divi_nested_library_order_context( $was_inner_order );
					\ET_Post_Stack::restore();
				}
			}

			$html_trim = trim( (string) $html );

			if ( '' === $html_trim && class_exists( 'ET_Builder_Element' ) ) {
				$was_inner_order = self::begin_divi_nested_library_order_context();
				self::begin_nested_library_block_parser_isolation();

				try {
					\ET_Builder_Element::clean_internal_modules_styles();

					ob_start();

					echo do_shortcode(
						self::build_global_module_fallback_shortcode( $layout_post_id, $layout_post )
					);

					$internal_style = \ET_Builder_Element::get_style();
					\ET_Builder_Element::clean_internal_modules_styles( false );

					$shortcode_html = (string) ob_get_clean();

					$style_markup = '';

					if ( is_string( $internal_style ) && '' !== $internal_style ) {
						$style_markup = sprintf(
							'<style id="%1$s-%2$d" type="text/css" class="%1$s-%2$d">%3$s</style>',
							esc_attr( $fallback_style_id_prefix ),
							$layout_post_id,
							$internal_style
						);
					}

					return self::wrap_divi_library_markup( $style_markup . $shortcode_html, $layout_post );
				} finally {
					self::end_nested_library_block_parser_isolation();
					self::end_divi_nested_library_order_context( $was_inner_order );
				}
			}

			$html_trim = trim( (string) $html );

			if ( '' === $html_trim ) {
				return '';
			}

			if ( self::layout_markup_has_et_containers( $html_trim ) ) {
				return self::with_captured_design_css( $html_trim, $layout_post_id, $fallback_style_id_prefix );
			}

			return self::with_captured_design_css(
				self::wrap_divi_library_markup( $html_trim, $layout_post ),
				$layout_post_id,
				$fallback_style_id_prefix
			);
		} finally {
			self::restore_host_static_css_enqueue( $static_css_enqueued );
			self::end_library_style_isolation( $style_state );
			unset( self::$rendering_layout_ids[ $layout_post_id ] );
		}
	}
}
