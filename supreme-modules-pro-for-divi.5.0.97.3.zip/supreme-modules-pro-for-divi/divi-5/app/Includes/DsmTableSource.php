<?php
/**
 * Supreme Table Phase 2 source engines (CSV URL, Sheets, JSON, Loop).
 *
 * First-party parsers only. No Tabulator / PapaParse / SheetJS.
 * Remote fetches go through {@see DsmRemoteUrlGuard}.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Includes;

use DiviSupreme\Modules\Table;
use WP_Error;
use WP_Query;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Resolves remote and Loop grids for Supreme Table.
 */
class DsmTableSource {

	/**
	 * Transient TTL for remote body cache (seconds). Minimum Live interval is 5 minutes.
	 *
	 * @var int
	 */
	private const CACHE_TTL = 300;

	/**
	 * Transient TTL for last-good remote payload (seconds) — 7 days.
	 *
	 * @var int
	 */
	private const LAST_GOOD_TTL = 604800;

	/**
	 * Max editor preview requests per user per minute.
	 *
	 * @var int
	 */
	private const PREVIEW_RATE_LIMIT = 20;

	/**
	 * Max public Live requests per IP per minute.
	 *
	 * @var int
	 */
	private const LIVE_RATE_LIMIT = 12;

	/**
	 * Allowed Live refresh intervals (minutes).
	 *
	 * @var array<int, int>
	 */
	private const LIVE_INTERVALS = array( 5, 15, 30, 60 );

	/**
	 * Allowed remote source slugs.
	 *
	 * @var array<int, string>
	 */
	private const REMOTE_SOURCES = array( 'csv', 'sheets', 'json' );

	/**
	 * Max rows stored in `table_grid` / VB Confirm / library import.
	 *
	 * @var int
	 */
	private const STORED_MAX_ROWS = 100;

	/**
	 * Default max rows for Live remote fetch + SSR (not stored in attrs).
	 *
	 * @var int
	 */
	private const REMOTE_MAX_ROWS_DEFAULT = 2000;

	/**
	 * Floor for {@see get_remote_max_rows()}.
	 *
	 * @var int
	 */
	private const REMOTE_MAX_ROWS_MIN = 100;

	/**
	 * Ceiling for {@see get_remote_max_rows()}.
	 *
	 * @var int
	 */
	private const REMOTE_MAX_ROWS_MAX = 10000;

	/**
	 * Default max rows for file CSV import (library + module).
	 *
	 * @var int
	 */
	private const IMPORT_MAX_ROWS_DEFAULT = 5000;

	/**
	 * Allowed Loop field slugs.
	 *
	 * @var array<int, string>
	 */
	private const LOOP_FIELDS = array(
		'title',
		'date',
		'author',
		'excerpt',
		'permalink',
		'image',
		'status',
	);

	/**
	 * Allowed Loop orderby values.
	 *
	 * @var array<int, string>
	 */
	private const LOOP_ORDERBY = array( 'date', 'title', 'modified', 'menu_order', 'ID', 'rand' );

	/**
	 * Whether a data_source slug is a remote URL engine.
	 *
	 * @param string $source Source slug.
	 * @return bool
	 */
	public static function is_remote_source( string $source ): bool {
		return in_array( $source, self::REMOTE_SOURCES, true );
	}

	/**
	 * Normalize refresh minutes to an allowed interval.
	 *
	 * @param string $raw Raw attr.
	 * @return int
	 */
	public static function normalize_refresh_minutes( string $raw ): int {
		$minutes = (int) preg_replace( '/[^\d]/', '', $raw );
		if ( ! in_array( $minutes, self::LIVE_INTERVALS, true ) ) {
			return 15;
		}

		return $minutes;
	}

	/**
	 * Rewrite a Google Sheets share/edit URL to a published CSV export URL.
	 *
	 * Private sheets are not supported. Already-CSV URLs are returned unchanged.
	 *
	 * @param string $url Raw URL.
	 * @return string
	 */
	public static function normalize_sheets_csv_url( string $url ): string {
		$url = trim( $url );
		if ( '' === $url ) {
			return '';
		}

		$gid = '0';
		if ( 1 === preg_match( '/[#?&]gid=([0-9]+)/', $url, $gid_match ) ) {
			$gid = $gid_match[1];
		}

		$already_csv = ( false !== strpos( $url, 'output=csv' ) || false !== strpos( $url, 'format=csv' ) );

		if ( 1 === preg_match( '#/spreadsheets/d/e/([^/]+)#', $url, $pub ) ) {
			if ( $already_csv ) {
				return $url;
			}

			return 'https://docs.google.com/spreadsheets/d/e/' . $pub[1] . '/pub?output=csv&gid=' . rawurlencode( $gid );
		}

		if ( 1 === preg_match( '#/spreadsheets/d/([a-zA-Z0-9-_]+)#', $url, $id_match ) && 'e' !== $id_match[1] ) {
			if ( $already_csv ) {
				return $url;
			}

			return 'https://docs.google.com/spreadsheets/d/' . $id_match[1] . '/export?format=csv&gid=' . rawurlencode( $gid );
		}

		return $url;
	}

	/**
	 * Prepare a remote URL for fetch (Sheets rewrite, then SSRF validate).
	 *
	 * @param string $source Source slug (csv|sheets|json).
	 * @param string $url    Raw URL.
	 * @return string|WP_Error
	 */
	public static function prepare_remote_url( string $source, string $url ) {
		$url = trim( $url );
		if ( 'sheets' === $source ) {
			$url = self::normalize_sheets_csv_url( $url );
		}

		return DsmRemoteUrlGuard::validate_url( $url );
	}

	/**
	 * Fetch remote text (cached) for CSV / Sheets / JSON.
	 *
	 * @param string $validated Validated HTTPS URL.
	 * @param string $source    Source slug.
	 * @param bool   $skip_cache Bypass read cache.
	 * @return array{body: string, url: string, bytes: int, cached: bool}|WP_Error
	 */
	public static function fetch_remote_text( string $validated, string $source, bool $skip_cache = false ) {
		$cache_key = 'dsm_table_src_' . md5( $source . '|' . $validated );

		/**
		 * Filter remote Table source cache TTL (seconds).
		 *
		 * @param int    $ttl    Cache TTL.
		 * @param string $url    Validated URL.
		 * @param string $source Source slug.
		 */
		$ttl = (int) apply_filters( 'dsm_table_remote_cache_ttl', self::CACHE_TTL, $validated, $source );
		if ( $ttl < 0 ) {
			$ttl = 0;
		}

		if ( ! $skip_cache && $ttl > 0 ) {
			$cached = get_transient( $cache_key );
			if ( is_array( $cached ) && isset( $cached['body'] ) && is_string( $cached['body'] ) ) {
				return array(
					'body'   => $cached['body'],
					'url'    => isset( $cached['url'] ) && is_string( $cached['url'] ) ? $cached['url'] : $validated,
					'bytes'  => isset( $cached['bytes'] ) ? (int) $cached['bytes'] : strlen( $cached['body'] ),
					'cached' => true,
				);
			}
		}

		$accept = 'json' === $source
			? 'application/json,text/plain,*/*;q=0.1'
			: 'text/csv,text/plain,*/*;q=0.1';

		/**
		 * Filter max remote Table body bytes.
		 *
		 * @param int    $max_bytes Max bytes.
		 * @param string $url       Validated URL.
		 * @param string $source    Source slug.
		 */
		$max_bytes = (int) apply_filters( 'dsm_table_remote_max_bytes', 8 * 1024 * 1024, $validated, $source );

		$fetched = DsmRemoteUrlGuard::fetch_text(
			$validated,
			array(
				'max_bytes'  => $max_bytes,
				'accept'     => $accept,
				'user_agent' => 'DiviSupremeTable/' . ( defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0' ),
			)
		);
		if ( is_wp_error( $fetched ) ) {
			return $fetched;
		}

		$payload = array(
			'body'  => $fetched['body'],
			'url'   => $fetched['url'],
			'bytes' => $fetched['bytes'],
		);

		if ( $ttl > 0 ) {
			set_transient( $cache_key, $payload, $ttl );
		}

		return array(
			'body'   => $payload['body'],
			'url'    => $payload['url'],
			'bytes'  => $payload['bytes'],
			'cached' => false,
		);
	}

	/**
	 * Max rows written into a stored `table_grid` snapshot.
	 *
	 * @return int
	 */
	public static function get_stored_max_rows(): int {
		return self::STORED_MAX_ROWS;
	}

	/**
	 * Max rows parsed for Live refresh / SSR remote grids.
	 *
	 * @return int
	 */
	public static function get_remote_max_rows(): int {
		/**
		 * Filter max rows fetched for Live remote Table sources (SSR + `table-live`).
		 *
		 * @param int $max_rows Default 2000.
		 */
		$max_rows = (int) apply_filters( 'dsm_table_remote_max_rows', self::REMOTE_MAX_ROWS_DEFAULT );
		if ( $max_rows < self::REMOTE_MAX_ROWS_MIN ) {
			return self::REMOTE_MAX_ROWS_MIN;
		}
		if ( $max_rows > self::REMOTE_MAX_ROWS_MAX ) {
			return self::REMOTE_MAX_ROWS_MAX;
		}

		return $max_rows;
	}

	/**
	 * Max rows for file CSV import (library CPT + module Import CSV).
	 *
	 * Separate from Live so a 5000-row file import does not force a 5000-row URL fetch.
	 *
	 * @return int
	 */
	public static function get_import_max_rows(): int {
		/**
		 * Filter max rows accepted from a CSV file import.
		 *
		 * @param int $max_rows Default 5000.
		 */
		$max_rows = (int) apply_filters( 'dsm_table_import_max_rows', self::IMPORT_MAX_ROWS_DEFAULT );
		if ( $max_rows < self::REMOTE_MAX_ROWS_MIN ) {
			return self::REMOTE_MAX_ROWS_MIN;
		}
		if ( $max_rows > self::REMOTE_MAX_ROWS_MAX ) {
			return self::REMOTE_MAX_ROWS_MAX;
		}

		return $max_rows;
	}

	/**
	 * Max CSV upload size in bytes (plugin cap, never above WordPress upload max).
	 *
	 * @return int
	 */
	public static function get_csv_max_bytes(): int {
		$plugin_cap = 8 * 1024 * 1024;
		$wp_cap     = function_exists( 'wp_max_upload_size' ) ? (int) wp_max_upload_size() : $plugin_cap;
		$default    = min( $plugin_cap, $wp_cap > 0 ? $wp_cap : $plugin_cap );

		/**
		 * Filter max CSV upload size in bytes.
		 *
		 * @param int $max_bytes Default 8 MB or WordPress upload max, whichever is smaller.
		 */
		$max_bytes = (int) apply_filters( 'dsm_table_csv_max_bytes', $default );
		if ( $max_bytes < 1024 ) {
			return 1024;
		}

		return min( $plugin_cap, $max_bytes );
	}

	/**
	 * Resolve a parse/sanitize row cap. Null or invalid uses the stored (100) cap.
	 *
	 * @param int|null $max_rows Requested cap.
	 * @return int
	 */
	private static function resolve_parse_max_rows( ?int $max_rows ): int {
		if ( null === $max_rows || $max_rows < 1 ) {
			return self::STORED_MAX_ROWS;
		}

		return min( self::REMOTE_MAX_ROWS_MAX, $max_rows );
	}

	/**
	 * Parse remote body into a string matrix.
	 *
	 * @param string   $source   Source slug.
	 * @param string   $body     Remote text.
	 * @param int|null $max_rows Row cap. Null uses the stored (100) cap.
	 * @return array{matrix: array<int, array<int, string>>, warnings: array<int, string>}|WP_Error
	 */
	public static function parse_remote_matrix( string $source, string $body, ?int $max_rows = null ) {
		if ( self::looks_like_html_page( $body ) ) {
			if ( 'sheets' === $source ) {
				return new WP_Error(
					'dsm_table_sheets_unpublished',
					__( 'This Google Sheet is not available as CSV. Open the spreadsheet → File → Share → Publish to web → CSV, then paste that published link (or a view-shared sheet). Private sheets are not supported.', 'dsm-supreme-modules-pro-for-divi' ),
					array( 'status' => 400 )
				);
			}

			return new WP_Error(
				'dsm_table_remote_html',
				__( 'The URL returned a web page instead of table data. Use a public HTTPS CSV or JSON file.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 400 )
			);
		}

		if ( 'json' === $source ) {
			return self::parse_json_matrix( $body, $max_rows );
		}

		return self::parse_csv_matrix( $body, $max_rows );
	}

	/**
	 * Whether remote text looks like an HTML document (login / unpublished sheet).
	 *
	 * @param string $body Remote body.
	 * @return bool
	 */
	public static function looks_like_html_page( string $body ): bool {
		$sample = strtolower( ltrim( substr( $body, 0, 800 ) ) );
		if ( '' === $sample ) {
			return false;
		}

		if ( str_starts_with( $sample, '<!doctype html' ) || str_starts_with( $sample, '<html' ) ) {
			return true;
		}

		return false !== strpos( $sample, '<html' ) || false !== strpos( $sample, 'accounts.google.com' );
	}

	/**
	 * Parse CSV/TSV text into a rectangular string matrix.
	 *
	 * @param string   $raw      CSV text.
	 * @param int|null $max_rows Row cap. Null uses the stored (100) cap.
	 * @return array{matrix: array<int, array<int, string>>, warnings: array<int, string>}|WP_Error
	 */
	public static function parse_csv_matrix( string $raw, ?int $max_rows = null ) {
		$text = self::strip_utf8_bom( trim( $raw ) );
		if ( '' === $text ) {
			return new WP_Error(
				'dsm_table_csv_empty',
				__( 'CSV is empty.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 400 )
			);
		}

		if ( 1 === preg_match( '/\$variable\s*\(/i', $text ) ) {
			return new WP_Error(
				'dsm_table_csv_dynamic',
				__( 'This file cannot include Dynamic Content. Use plain text only.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 400 )
			);
		}

		$first_line = strstr( $text, "\n", true );
		if ( false === $first_line ) {
			$first_line = $text;
		}
		$delimiter = ( false !== strpos( $first_line, "\t" ) ) ? "\t" : ',';
		$lines     = self::split_csv_lines( $text );
		if ( array() === $lines ) {
			return new WP_Error(
				'dsm_table_csv_empty',
				__( 'CSV is empty.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 400 )
			);
		}

		$max_rows   = self::resolve_parse_max_rows( $max_rows );
		$max_cols   = 20;
		$matrix     = array();
		$warnings   = array();
		$width      = 0;
		$line_count = count( $lines );

		for ( $i = 0; $i < $line_count; $i++ ) {
			if ( count( $matrix ) >= $max_rows ) {
				$warnings[] = __( 'Extra rows were ignored (row limit reached).', 'dsm-supreme-modules-pro-for-divi' );
				break;
			}

			$cells = array_map( 'trim', self::parse_csv_line( $lines[ $i ], $delimiter ) );
			if ( count( $cells ) > $max_cols ) {
				$cells = array_slice( $cells, 0, $max_cols );
				if ( 0 === $i ) {
					$warnings[] = __( 'Extra columns were ignored (column limit reached).', 'dsm-supreme-modules-pro-for-divi' );
				}
			}

			if ( array() === $cells || '' === implode( '', $cells ) ) {
				continue;
			}

			$width    = max( $width, count( $cells ) );
			$matrix[] = $cells;
		}

		if ( array() === $matrix ) {
			return new WP_Error(
				'dsm_table_csv_no_data',
				__( 'CSV has no data rows.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 400 )
			);
		}

		foreach ( $matrix as $r => $row ) {
			$need = $width - count( $matrix[ $r ] );
			if ( $need > 0 ) {
				$matrix[ $r ] = array_merge( $matrix[ $r ], array_fill( 0, $need, '' ) );
			}
		}

		return array(
			'matrix'   => $matrix,
			'warnings' => $warnings,
		);
	}

	/**
	 * Stream-parse a CSV file path (no full-file `file_get_contents`).
	 *
	 * @param string   $path     Readable local path.
	 * @param int|null $max_rows Row cap. Null uses the stored (100) cap.
	 * @return array{matrix: array<int, array<int, string>>, warnings: array<int, string>}|WP_Error
	 */
	public static function parse_csv_matrix_from_path( string $path, ?int $max_rows = null ) {
		if ( '' === $path || ! is_readable( $path ) ) {
			return new WP_Error(
				'dsm_table_csv_upload',
				__( 'Could not upload the CSV file.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 400 )
			);
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- local upload tmp / readable path.
		$handle = fopen( $path, 'rb' );
		if ( false === $handle ) {
			return new WP_Error(
				'dsm_table_csv_upload',
				__( 'Could not upload the CSV file.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 400 )
			);
		}

		$max_rows  = self::resolve_parse_max_rows( $max_rows );
		$max_cols  = 20;
		$matrix    = array();
		$warnings  = array();
		$width     = 0;
		$delimiter = ',';
		$saw_first = false;
		$in_quotes = false;
		$current   = '';
		$truncated = false;
		$seen_bom  = false;

		while ( ! feof( $handle ) ) {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fread -- streaming parse.
			$chunk = fread( $handle, 8192 );
			if ( false === $chunk || '' === $chunk ) {
				break;
			}

			if ( ! $seen_bom ) {
				$chunk    = self::strip_utf8_bom( $chunk );
				$seen_bom = true;
			}

			$length = strlen( $chunk );
			for ( $i = 0; $i < $length; $i++ ) {
				$ch = $chunk[ $i ];
				if ( '"' === $ch ) {
					$in_quotes = ! $in_quotes;
					$current  .= $ch;
					continue;
				}
				if ( ! $in_quotes && ( "\n" === $ch || "\r" === $ch ) ) {
					if ( "\r" === $ch && ( $i + 1 ) < $length && "\n" === $chunk[ $i + 1 ] ) {
						++$i;
					}
					$line    = $current;
					$current = '';
					if ( '' === trim( $line ) && array() === $matrix ) {
						continue;
					}
					if ( '' === trim( $line ) && array() !== $matrix ) {
						continue;
					}
					if ( count( $matrix ) >= $max_rows ) {
						$truncated = true;
						break 2;
					}
					$added = self::append_csv_matrix_line( $matrix, $line, $delimiter, $max_cols, $warnings, $saw_first, $width );
					if ( is_wp_error( $added ) ) {
						// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- paired with fopen stream.
						fclose( $handle );
						return $added;
					}
					$saw_first = true;
					continue;
				}
				$current .= $ch;
			}
			if ( $truncated ) {
				break;
			}
		}

		if ( ! $truncated && ( '' !== trim( $current ) || ( '' !== $current && array() !== $matrix ) ) ) {
			if ( count( $matrix ) >= $max_rows ) {
				$truncated = true;
			} else {
				$added = self::append_csv_matrix_line( $matrix, $current, $delimiter, $max_cols, $warnings, $saw_first, $width );
				if ( is_wp_error( $added ) ) {
					// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- paired with fopen stream.
					fclose( $handle );
					return $added;
				}
			}
		}

		if ( ! $truncated && ! feof( $handle ) ) {
			$truncated = true;
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- paired with fopen stream.
		fclose( $handle );

		if ( $truncated ) {
			$warnings[] = __( 'Extra rows were ignored (row limit reached).', 'dsm-supreme-modules-pro-for-divi' );
		}

		if ( array() === $matrix ) {
			return new WP_Error(
				'dsm_table_csv_no_data',
				__( 'CSV has no data rows.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 400 )
			);
		}

		foreach ( $matrix as $r => $row ) {
			$need = $width - count( $matrix[ $r ] );
			if ( $need > 0 ) {
				$matrix[ $r ] = array_merge( $matrix[ $r ], array_fill( 0, $need, '' ) );
			}
		}

		return array(
			'matrix'   => $matrix,
			'warnings' => $warnings,
		);
	}

	/**
	 * Append one streamed CSV line onto a matrix.
	 *
	 * @param array<int, array<int, string>> $matrix    Matrix (by ref).
	 * @param string                         $line      Raw line.
	 * @param string                         $delimiter Delimiter (by ref on first line).
	 * @param int                            $max_cols  Column cap.
	 * @param array<int, string>             $warnings  Warnings (by ref).
	 * @param bool                           $saw_first Whether a data line was already stored.
	 * @param int                            $width     Widest row (by ref).
	 * @return true|WP_Error
	 */
	private static function append_csv_matrix_line( array &$matrix, string $line, string &$delimiter, int $max_cols, array &$warnings, bool $saw_first, int &$width ) {
		if ( 1 === preg_match( '/\$variable\s*\(/i', $line ) ) {
			return new WP_Error(
				'dsm_table_csv_dynamic',
				__( 'This file cannot include Dynamic Content. Use plain text only.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 400 )
			);
		}

		if ( ! $saw_first ) {
			$delimiter = ( false !== strpos( $line, "\t" ) ) ? "\t" : ',';
		}

		$cells = array_map( 'trim', self::parse_csv_line( $line, $delimiter ) );
		if ( count( $cells ) > $max_cols ) {
			$cells = array_slice( $cells, 0, $max_cols );
			if ( ! $saw_first ) {
				$warnings[] = __( 'Extra columns were ignored (column limit reached).', 'dsm-supreme-modules-pro-for-divi' );
			}
		}

		if ( array() === $cells || '' === implode( '', $cells ) ) {
			return true;
		}

		$width    = max( $width, count( $cells ) );
		$matrix[] = $cells;

		return true;
	}

	/**
	 * Parse JSON text into a rectangular string matrix.
	 *
	 * Accepts an array of arrays, an array of objects, `{ data|items|rows }`,
	 * or a single object.
	 *
	 * @param string   $raw      JSON text.
	 * @param int|null $max_rows Row cap. Null uses the stored (100) cap.
	 * @return array{matrix: array<int, array<int, string>>, warnings: array<int, string>}|WP_Error
	 */
	public static function parse_json_matrix( string $raw, ?int $max_rows = null ) {
		$text = self::strip_utf8_bom( trim( $raw ) );
		if ( '' === $text ) {
			return new WP_Error(
				'dsm_table_json_empty',
				__( 'JSON is empty.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 400 )
			);
		}

		if ( 1 === preg_match( '/\$variable\s*\(/i', $text ) ) {
			return new WP_Error(
				'dsm_table_json_dynamic',
				__( 'This file cannot include Dynamic Content. Use plain text only.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 400 )
			);
		}

		$decoded = json_decode( $text, true );
		if ( JSON_ERROR_NONE !== json_last_error() ) {
			return new WP_Error(
				'dsm_table_json_invalid',
				__( 'Remote response is not valid JSON.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 400 )
			);
		}

		$warnings = array();
		$data     = $decoded;

		if ( is_array( $data ) && self::is_assoc_array( $data ) ) {
			if ( isset( $data['data'] ) && is_array( $data['data'] ) ) {
				$data = $data['data'];
			} elseif ( isset( $data['items'] ) && is_array( $data['items'] ) ) {
				$data = $data['items'];
			} elseif ( isset( $data['rows'] ) && is_array( $data['rows'] ) && isset( $data['columns'] ) && is_array( $data['columns'] ) ) {
				return self::matrix_from_columns_and_rows( $data['columns'], $data['rows'], $max_rows );
			} elseif ( isset( $data['rows'] ) && is_array( $data['rows'] ) ) {
				$data = $data['rows'];
			} else {
				$data = array( $data );
			}
		}

		if ( ! is_array( $data ) || array() === $data ) {
			return new WP_Error(
				'dsm_table_json_rows',
				__( 'This JSON file is not a list of rows.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 400 )
			);
		}

		$first = reset( $data );
		if ( is_array( $first ) && ! self::is_assoc_array( $first ) ) {
			$matrix = array();
			foreach ( $data as $row ) {
				if ( ! is_array( $row ) ) {
					continue;
				}
				$matrix[] = array_map( array( self::class, 'flatten_json_cell' ), array_values( $row ) );
			}

			return self::trim_matrix( $matrix, $warnings, $max_rows );
		}

		if ( is_array( $first ) && self::is_assoc_array( $first ) ) {
			$keys = array();
			foreach ( $data as $row ) {
				if ( ! is_array( $row ) ) {
					continue;
				}
				foreach ( array_keys( $row ) as $key ) {
					$key = (string) $key;
					if ( ! in_array( $key, $keys, true ) ) {
						$keys[] = $key;
					}
				}
			}

			if ( array() === $keys ) {
				return new WP_Error(
					'dsm_table_json_keys',
					__( 'JSON objects have no fields to map as columns.', 'dsm-supreme-modules-pro-for-divi' ),
					array( 'status' => 400 )
				);
			}

			$matrix = array( $keys );
			foreach ( $data as $row ) {
				if ( ! is_array( $row ) ) {
					continue;
				}
				$line = array();
				foreach ( $keys as $key ) {
					$line[] = self::flatten_json_cell( $row[ $key ] ?? '' );
				}
				$matrix[] = $line;
			}

			return self::trim_matrix( $matrix, $warnings, $max_rows );
		}

		return new WP_Error(
			'dsm_table_json_shape',
			__( 'This JSON file is not a list of rows.', 'dsm-supreme-modules-pro-for-divi' ),
			array( 'status' => 400 )
		);
	}

	/**
	 * Build a sanitized grid from a string matrix.
	 *
	 * @param array<int, array<int, string>> $matrix            Rows of fields.
	 * @param bool                           $first_row_header  First row is headers.
	 * @param array<string, mixed>           $comparison        Previous comparison (remapped by header).
	 * @param array<string, string>          $source_meta       Optional source stamp.
	 * @param int|null                       $max_rows          Sanitize row cap. Null uses stored (100).
	 * @return array<string, mixed>
	 */
	public static function grid_from_matrix( array $matrix, bool $first_row_header, array $comparison = array(), array $source_meta = array(), ?int $max_rows = null ): array {
		if ( array() === $matrix ) {
			$matrix = array( array( '' ) );
		}

		$header_row = $first_row_header
			? $matrix[0]
			: array_map(
				static function ( $index ) {
					return sprintf(
						/* translators: %d: column number */
						__( 'Column %d', 'dsm-supreme-modules-pro-for-divi' ),
						(int) $index + 1
					);
				},
				array_keys( $matrix[0] )
			);
		$body_rows  = $first_row_header ? array_slice( $matrix, 1 ) : $matrix;
		if ( array() === $body_rows ) {
			$body_rows = array( array_fill( 0, count( $header_row ), '' ) );
		}

		$columns = array();
		foreach ( $header_row as $c => $header ) {
			$columns[] = array(
				'id'           => 'col-' . ( (int) $c + 1 ),
				'header'       => sanitize_text_field( (string) $header ),
				'hide_on'      => array(
					'tablet' => false,
					'phone'  => false,
				),
				'sticky'       => 0 === (int) $c,
				'type_default' => 'text',
				'width'        => '',
				'align'        => '',
			);
		}

		$rows   = array();
		$rows[] = self::make_role_row( 'row-h', 'header', $header_row );
		foreach ( $body_rows as $r => $line ) {
			$rows[] = self::make_role_row( 'row-' . ( (int) $r + 1 ), 'body', $line );
		}

		$grid = array(
			'schema_version' => 1,
			'columns'        => $columns,
			'rows'           => $rows,
			'merges'         => array(),
			'comparison'     => self::remap_comparison( $comparison, $columns ),
			'source'         => $source_meta,
		);

		$sanitized = DsmTableLibrary::maybe_sanitize_grid(
			$grid,
			self::resolve_parse_max_rows( $max_rows )
		);

		return is_array( $sanitized ) ? $sanitized : $grid;
	}

	/**
	 * Resolve a remote source into a sanitized grid (cached fetch + parse).
	 *
	 * @param string               $source           csv|sheets|json.
	 * @param string               $url              Raw URL.
	 * @param bool                 $first_row_header First row is headers.
	 * @param array<string, mixed> $comparison       Previous comparison.
	 * @param bool                 $skip_cache       Bypass cache.
	 * @param int|null             $max_rows         Row cap. Null uses Live remote cap (500).
	 * @return array<string, mixed>|WP_Error
	 */
	public static function resolve_remote_grid( string $source, string $url, bool $first_row_header, array $comparison = array(), bool $skip_cache = false, ?int $max_rows = null ) {
		$row_cap = null === $max_rows ? self::get_remote_max_rows() : self::resolve_parse_max_rows( $max_rows );

		$validated = self::prepare_remote_url( $source, $url );
		if ( is_wp_error( $validated ) ) {
			return $validated;
		}

		$fetched = self::fetch_remote_text( $validated, $source, $skip_cache );
		if ( is_wp_error( $fetched ) ) {
			return $fetched;
		}

		$parsed = self::parse_remote_matrix( $source, $fetched['body'], $row_cap );
		if ( is_wp_error( $parsed ) ) {
			return $parsed;
		}

		$grid = self::grid_from_matrix(
			$parsed['matrix'],
			$first_row_header,
			$comparison,
			array(
				'type' => $source,
				'url'  => $fetched['url'],
			),
			$row_cap
		);

		$last_key = 'dsm_table_last_' . md5( $source . '|' . $validated );
		/**
		 * Filter last-good Table remote grid TTL (seconds).
		 *
		 * @param int    $ttl Cache TTL.
		 * @param string $url Validated URL.
		 */
		$last_ttl = (int) apply_filters( 'dsm_table_remote_last_good_ttl', self::LAST_GOOD_TTL, $validated );
		if ( $last_ttl > 0 ) {
			set_transient( $last_key, $grid, $last_ttl );
		}

		return $grid;
	}

	/**
	 * Last-good remote grid for a validated URL.
	 *
	 * @param string $source Source slug.
	 * @param string $url    Validated URL.
	 * @return array<string, mixed>|null
	 */
	public static function get_last_good_grid( string $source, string $url ) {
		$last = get_transient( 'dsm_table_last_' . md5( $source . '|' . $url ) );

		return is_array( $last ) ? $last : null;
	}

	/**
	 * Public / editor payload: headers + body rows of plain text.
	 *
	 * @param array<string, mixed> $grid Sanitized grid.
	 * @return array{headers: array<int, string>, rows: array<int, array<int, string>>}
	 */
	public static function grid_to_matrix_payload( array $grid ): array {
		$headers = array();
		$columns = isset( $grid['columns'] ) && is_array( $grid['columns'] ) ? $grid['columns'] : array();
		foreach ( $columns as $c => $col ) {
			$header = '';
			if ( is_array( $col ) && isset( $col['header'] ) ) {
				$header = trim( (string) $col['header'] );
			}
			$headers[] = '' !== $header ? $header : (string) ( (int) $c + 1 );
		}

		$rows     = array();
		$raw_rows = isset( $grid['rows'] ) && is_array( $grid['rows'] ) ? $grid['rows'] : array();
		foreach ( $raw_rows as $row ) {
			if ( ! is_array( $row ) || 'header' === ( $row['role'] ?? '' ) ) {
				continue;
			}
			$line  = array();
			$cells = isset( $row['cells'] ) && is_array( $row['cells'] ) ? $row['cells'] : array();
			foreach ( $columns as $c => $_col ) {
				$cell   = isset( $cells[ $c ] ) && is_array( $cells[ $c ] ) ? $cells[ $c ] : array();
				$line[] = self::cell_plain_text( $cell );
			}
			$rows[] = $line;
		}

		return array(
			'headers' => $headers,
			'rows'    => $rows,
		);
	}

	/**
	 * Allowed Loop field slugs (filterable).
	 *
	 * @return array<int, string>
	 */
	public static function get_loop_fields(): array {
		$fields = apply_filters( 'dsm_table_loop_fields', self::LOOP_FIELDS );

		if ( ! is_array( $fields ) ) {
			return self::LOOP_FIELDS;
		}

		$clean = array();
		foreach ( $fields as $field ) {
			$field = sanitize_key( (string) $field );
			if ( '' !== $field ) {
				$clean[] = $field;
			}
		}

		return array() === $clean ? self::LOOP_FIELDS : array_values( array_unique( $clean ) );
	}

	/**
	 * Publicly queryable post types allowed for Loop (filterable).
	 *
	 * @return array<int, string>
	 */
	public static function get_loop_post_types(): array {
		$types = get_post_types(
			array(
				'public' => true,
			),
			'names'
		);
		if ( ! is_array( $types ) ) {
			$types = array( 'post' );
		}
		$types = array_values( array_map( 'strval', $types ) );

		/**
		 * Filter Loop post type slugs.
		 *
		 * @param array<int, string> $types Public post types.
		 */
		$filtered = apply_filters( 'dsm_table_loop_post_types', $types );

		return is_array( $filtered ) ? array_values( array_map( 'sanitize_key', $filtered ) ) : $types;
	}

	/**
	 * Authors available for the Loop picker (capability-gated REST).
	 *
	 * @return array<int, array{id: string, name: string}>
	 */
	public static function get_loop_authors(): array {
		$users = get_users(
			array(
				'capability' => 'edit_posts',
				'number'     => 100,
				'orderby'    => 'display_name',
				'order'      => 'ASC',
				'fields'     => array( 'ID', 'display_name' ),
			)
		);

		$authors = array();
		if ( is_array( $users ) ) {
			foreach ( $users as $user ) {
				if ( ! is_object( $user ) ) {
					continue;
				}
				$authors[] = array(
					'id'   => (string) (int) $user->ID,
					'name' => sanitize_text_field( (string) $user->display_name ),
				);
			}
		}

		/**
		 * Filter Loop author picker rows.
		 *
		 * @param array<int, array{id: string, name: string}> $authors Authors.
		 */
		$filtered = apply_filters( 'dsm_table_loop_authors', $authors );

		return is_array( $filtered ) ? $filtered : $authors;
	}

	/**
	 * Build a grid from a WordPress query (publish-only).
	 *
	 * @param array<string, mixed> $args Loop args: post_type, count, orderby, order, fields, comparison.
	 * @return array<string, mixed>|WP_Error
	 */
	public static function build_loop_grid( array $args ) {
		$post_type = sanitize_key( (string) ( $args['post_type'] ?? 'post' ) );
		$allowed   = self::get_loop_post_types();
		if ( ! in_array( $post_type, $allowed, true ) ) {
			return new WP_Error(
				'dsm_table_loop_type',
				__( 'This post type is not allowed for the table Loop.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 400 )
			);
		}

		$count = self::normalize_loop_posts_per_page( $args['count'] ?? '' );

		$orderby = sanitize_key( (string) ( $args['orderby'] ?? 'date' ) );
		if ( ! in_array( $orderby, self::LOOP_ORDERBY, true ) ) {
			$orderby = 'date';
		}

		$order = strtoupper( sanitize_text_field( (string) ( $args['order'] ?? 'DESC' ) ) );
		if ( ! in_array( $order, array( 'ASC', 'DESC' ), true ) ) {
			$order = 'DESC';
		}

		$field_slugs = self::parse_loop_field_list( $args['fields'] ?? 'title,date,author,excerpt' );
		$headers     = array();
		foreach ( $field_slugs as $field ) {
			$headers[] = self::loop_field_label( $field );
		}

		$author_id = self::parse_loop_author( (string) ( $args['author'] ?? '' ) );
		$tax_query = self::parse_loop_tax_query( $args['term_ids'] ?? '', $post_type );

		$query_args = array(
			'post_type'           => $post_type,
			// phpcs:ignore WordPress.WP.PostsPerPage.posts_per_page_posts_per_page -- 0/blank Loop count is unlimited.
			'posts_per_page'      => $count,
			'orderby'             => $orderby,
			'order'               => $order,
			'post_status'         => 'publish',
			'ignore_sticky_posts' => true,
			'no_found_rows'       => true,
		);
		if ( $author_id > 0 ) {
			$query_args['author'] = $author_id;
		}
		if ( array() !== $tax_query ) {
			$query_args['tax_query'] = $tax_query; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- publish-only Loop filter.
		}

		/**
		 * Filter the Loop WP_Query args.
		 *
		 * @param array<string, mixed> $query_args Query args.
		 * @param array<string, mixed> $args       Source args.
		 */
		$query_args = apply_filters( 'dsm_table_loop_query_args', $query_args, $args );
		if ( ! is_array( $query_args ) ) {
			$query_args = array(
				'post_type'      => $post_type,
				'posts_per_page' => $count,
				'post_status'    => 'publish',
			);
		}
		$query_args['post_status'] = 'publish';

		$query = new WP_Query( $query_args );
		$posts = $query->posts;
		wp_reset_postdata();

		$body = array();
		if ( is_array( $posts ) ) {
			foreach ( $posts as $post ) {
				if ( ! $post instanceof \WP_Post ) {
					continue;
				}
				$line = array();
				foreach ( $field_slugs as $field ) {
					$line[] = self::loop_field_value( $post, $field );
				}
				$body[] = $line;
			}
		}

		$grid = self::grid_from_matrix(
			array_merge( array( $headers ), $body ),
			true,
			isset( $args['comparison'] ) && is_array( $args['comparison'] ) ? $args['comparison'] : array(),
			array(
				'type' => 'loop',
				'url'  => '',
			)
		);

		// Typed cells for image / permalink / status after sanitize (text-only matrix).
		return self::apply_loop_cell_types( $grid, $field_slugs, is_array( $posts ) ? $posts : array() );
	}

	/**
	 * Editor preview rate limit.
	 *
	 * @return true|WP_Error
	 */
	public static function check_preview_rate_limit() {
		$user_id = get_current_user_id();
		if ( $user_id <= 0 ) {
			return new WP_Error(
				'dsm_table_source_forbidden',
				__( 'You must be logged in to preview a remote table source.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 403 )
			);
		}

		$key = 'dsm_table_src_rl_' . (string) $user_id;

		/**
		 * Filter max Table source preview requests per user per minute.
		 *
		 * @param int $limit Max requests.
		 */
		$limit = (int) apply_filters( 'dsm_table_source_rate_limit', self::PREVIEW_RATE_LIMIT );
		if ( $limit < 1 ) {
			return true;
		}

		return self::bump_rate_limit(
			$key,
			$limit,
			'dsm_table_source_rate_limited',
			__( 'Too many table source requests. Please wait a moment and try again.', 'dsm-supreme-modules-pro-for-divi' )
		);
	}

	/**
	 * Public Live rate limit (per IP).
	 *
	 * @return true|WP_Error
	 */
	public static function check_live_rate_limit() {
		$ip = '';
		if ( isset( $_SERVER['REMOTE_ADDR'] ) && is_string( $_SERVER['REMOTE_ADDR'] ) ) {
			$ip = sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) );
		}
		if ( '' === $ip ) {
			$ip = 'unknown';
		}

		$key = 'dsm_table_live_rl_' . md5( $ip );

		/**
		 * Filter max public Live Table requests per IP per minute.
		 *
		 * @param int $limit Max requests.
		 */
		$limit = (int) apply_filters( 'dsm_table_live_rate_limit', self::LIVE_RATE_LIMIT );
		if ( $limit < 1 ) {
			return true;
		}

		return self::bump_rate_limit(
			$key,
			$limit,
			'dsm_table_live_rate_limited',
			__( 'Too many table refresh requests. Please wait a moment and try again.', 'dsm-supreme-modules-pro-for-divi' )
		);
	}

	/**
	 * Increment a transient rate-limit counter.
	 *
	 * @param string $key     Transient key.
	 * @param int    $limit   Max hits.
	 * @param string $code    Error code.
	 * @param string $message Error message.
	 * @return true|WP_Error
	 */
	private static function bump_rate_limit( string $key, int $limit, string $code, string $message ) {
		$count = get_transient( $key );
		if ( false === $count ) {
			set_transient( $key, 1, MINUTE_IN_SECONDS );
			return true;
		}

		$count = (int) $count;
		if ( $count >= $limit ) {
			return new WP_Error(
				$code,
				$message,
				array( 'status' => 429 )
			);
		}

		set_transient( $key, $count + 1, MINUTE_IN_SECONDS );

		return true;
	}

	/**
	 * Whether an array is associative.
	 *
	 * @param array<mixed> $value Array.
	 * @return bool
	 */
	private static function is_assoc_array( array $value ): bool {
		if ( array() === $value ) {
			return false;
		}

		return array_keys( $value ) !== range( 0, count( $value ) - 1 );
	}

	/**
	 * Flatten a JSON cell to plain text.
	 *
	 * @param mixed $value Raw value.
	 * @return string
	 */
	public static function flatten_json_cell( $value ): string {
		if ( null === $value || false === $value ) {
			return '';
		}
		if ( true === $value ) {
			return '1';
		}
		if ( is_scalar( $value ) ) {
			return sanitize_text_field( (string) $value );
		}
		if ( is_array( $value ) ) {
			if ( ! self::is_assoc_array( $value ) ) {
				$parts = array();
				foreach ( $value as $item ) {
					$flat = self::flatten_json_cell( $item );
					if ( '' !== $flat ) {
						$parts[] = $flat;
					}
				}
				return implode( ', ', $parts );
			}
			foreach ( array( 'text', 'label', 'name', 'title', 'value' ) as $key ) {
				if ( isset( $value[ $key ] ) && is_scalar( $value[ $key ] ) ) {
					return sanitize_text_field( (string) $value[ $key ] );
				}
			}
		}

		return '';
	}

	/**
	 * Build a matrix from columns + rows JSON.
	 *
	 * @param array<int, mixed> $columns  Column labels or objects.
	 * @param array<int, mixed> $rows     Row arrays or objects.
	 * @param int|null          $max_rows Row cap. Null uses the stored (100) cap.
	 * @return array{matrix: array<int, array<int, string>>, warnings: array<int, string>}|WP_Error
	 */
	private static function matrix_from_columns_and_rows( array $columns, array $rows, ?int $max_rows = null ) {
		$headers = array();
		foreach ( $columns as $column ) {
			if ( is_array( $column ) ) {
				$headers[] = self::flatten_json_cell( $column['header'] ?? $column['label'] ?? $column['name'] ?? '' );
			} else {
				$headers[] = self::flatten_json_cell( $column );
			}
		}

		$matrix = array( $headers );
		foreach ( $rows as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			if ( isset( $row['cells'] ) && is_array( $row['cells'] ) ) {
				$line = array();
				foreach ( $row['cells'] as $cell ) {
					if ( is_array( $cell ) ) {
						$line[] = self::flatten_json_cell( $cell['value'] ?? $cell['text'] ?? '' );
					} else {
						$line[] = self::flatten_json_cell( $cell );
					}
				}
				$matrix[] = $line;
				continue;
			}
			$matrix[] = array_map( array( self::class, 'flatten_json_cell' ), array_values( $row ) );
		}

		return self::trim_matrix( $matrix, array(), $max_rows );
	}

	/**
	 * Cap matrix size and pad rows.
	 *
	 * @param array<int, array<int, string>> $matrix   Matrix.
	 * @param array<int, string>             $warnings Warnings.
	 * @param int|null                       $max_rows Row cap. Null uses the stored (100) cap.
	 * @return array{matrix: array<int, array<int, string>>, warnings: array<int, string>}|WP_Error
	 */
	private static function trim_matrix( array $matrix, array $warnings, ?int $max_rows = null ) {
		$max_rows = self::resolve_parse_max_rows( $max_rows );
		$max_cols = 20;
		if ( count( $matrix ) > $max_rows ) {
			$matrix     = array_slice( $matrix, 0, $max_rows );
			$warnings[] = __( 'Extra rows were ignored (row limit reached).', 'dsm-supreme-modules-pro-for-divi' );
		}

		$width = 0;
		foreach ( $matrix as $row ) {
			$width = max( $width, count( $row ) );
		}
		if ( $width > $max_cols ) {
			$width      = $max_cols;
			$warnings[] = __( 'Extra columns were ignored (column limit reached).', 'dsm-supreme-modules-pro-for-divi' );
		}
		if ( $width < 1 ) {
			return new WP_Error(
				'dsm_table_json_empty',
				__( 'JSON has no data rows.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 400 )
			);
		}

		$clean = array();
		foreach ( $matrix as $row ) {
			$row  = array_slice( $row, 0, $width );
			$need = $width - count( $row );
			if ( $need > 0 ) {
				$row = array_merge( $row, array_fill( 0, $need, '' ) );
			}
			$clean[] = $row;
		}

		return array(
			'matrix'   => $clean,
			'warnings' => $warnings,
		);
	}

	/**
	 * Header-role row of text cells.
	 *
	 * @param string             $id    Row id.
	 * @param string             $role  Row role.
	 * @param array<int, string> $line  Cell texts.
	 * @return array<string, mixed>
	 */
	private static function make_role_row( string $id, string $role, array $line ): array {
		$cells = array();
		foreach ( $line as $c => $text ) {
			$cells[] = array(
				'id'      => $id . '-c' . ( (int) $c + 1 ),
				'type'    => 'text',
				'colspan' => 1,
				'rowspan' => 1,
				'value'   => array( 'text' => (string) $text ),
				'design'  => array(),
			);
		}

		return array(
			'id'      => $id,
			'role'    => $role,
			'tooltip' => '',
			'cells'   => $cells,
		);
	}

	/**
	 * Remap comparison column ids by header label when ids change after import.
	 *
	 * @param array<string, mixed>             $comparison Previous comparison.
	 * @param array<int, array<string, mixed>> $columns New columns.
	 * @return array<string, string>
	 */
	private static function remap_comparison( array $comparison, array $columns ): array {
		$by_id = array();
		foreach ( $columns as $column ) {
			if ( ! is_array( $column ) ) {
				continue;
			}
			$id = (string) ( $column['id'] ?? '' );
			if ( '' !== $id ) {
				$by_id[ $id ] = $id;
			}
		}

		$pick = static function ( $key ) use ( $comparison, $by_id ) {
			$id = sanitize_text_field( (string) ( $comparison[ $key ] ?? '' ) );
			if ( '' !== $id && isset( $by_id[ $id ] ) ) {
				return $id;
			}

			return '';
		};

		return array(
			'highlight_column_id'  => $pick( 'highlight_column_id' ),
			'best_value_column_id' => $pick( 'best_value_column_id' ),
			'best_value_label'     => sanitize_text_field( (string) ( $comparison['best_value_label'] ?? '' ) ),
		);
	}

	/**
	 * Loop posts_per_page: blank or 0 means no limit (-1).
	 *
	 * @param mixed $raw Count from attrs or REST.
	 * @return int Positive count or -1.
	 */
	private static function normalize_loop_posts_per_page( $raw ): int {
		if ( is_array( $raw ) && isset( $raw['text'] ) ) {
			$raw = $raw['text'];
		}
		if ( ! is_scalar( $raw ) ) {
			return -1;
		}
		$raw = trim( (string) $raw );
		if ( '' === $raw ) {
			return -1;
		}
		$count = absint( $raw );
		if ( $count < 1 ) {
			return -1;
		}

		return $count;
	}

	/**
	 * Parse a comma list or checkbox array of Loop fields against the allow-list.
	 *
	 * @param mixed $raw Comma list or array of slugs.
	 * @return array<int, string>
	 */
	private static function parse_loop_field_list( $raw ): array {
		$allowed = self::get_loop_fields();
		if ( is_array( $raw ) ) {
			$parts = array();
			foreach ( $raw as $item ) {
				$parts[] = strtolower( sanitize_key( (string) $item ) );
			}
		} else {
			$parts = preg_split( '/[\s,|]+/', strtolower( (string) $raw ) );
			if ( ! is_array( $parts ) ) {
				$parts = array();
			}
		}

		$fields = array();
		foreach ( $parts as $part ) {
			$part = sanitize_key( $part );
			if ( '' !== $part && in_array( $part, $allowed, true ) && ! in_array( $part, $fields, true ) ) {
				$fields[] = $part;
			}
		}

		if ( array() === $fields ) {
			return array( 'title', 'date', 'author', 'excerpt' );
		}

		if ( count( $fields ) > 20 ) {
			$fields = array_slice( $fields, 0, 20 );
		}

		return $fields;
	}

	/**
	 * Parse a Loop author id (empty = any).
	 *
	 * @param string $raw Author id.
	 * @return int
	 */
	private static function parse_loop_author( string $raw ): int {
		$id = absint( $raw );
		if ( $id < 1 ) {
			return 0;
		}

		$user = get_userdata( $id );

		return $user instanceof \WP_User ? $id : 0;
	}

	/**
	 * Build a publish-only tax_query from `taxonomy:termId` tokens.
	 *
	 * @param mixed  $raw       Array or comma list of tokens.
	 * @param string $post_type Post type slug.
	 * @return array<int, array<string, mixed>>
	 */
	private static function parse_loop_tax_query( $raw, string $post_type ): array {
		$tokens = array();
		if ( is_array( $raw ) ) {
			foreach ( $raw as $item ) {
				$tokens[] = (string) $item;
			}
		} else {
			$parts  = preg_split( '/[\s,]+/', (string) $raw );
			$tokens = is_array( $parts ) ? $parts : array();
		}

		$by_tax = array();
		foreach ( $tokens as $token ) {
			$token = sanitize_text_field( trim( (string) $token ) );
			if ( '' === $token || false === strpos( $token, ':' ) ) {
				continue;
			}
			$chunks   = explode( ':', $token, 2 );
			$taxonomy = sanitize_key( (string) ( $chunks[0] ?? '' ) );
			$term_id  = absint( $chunks[1] ?? 0 );
			if ( '' === $taxonomy || $term_id < 1 ) {
				continue;
			}
			$term = get_term( $term_id, $taxonomy );
			if ( ! $term instanceof \WP_Term ) {
				continue;
			}
			$tax_obj = get_taxonomy( $taxonomy );
			if ( ! $tax_obj instanceof \WP_Taxonomy || ! in_array( $post_type, (array) $tax_obj->object_type, true ) ) {
				continue;
			}
			if ( ! isset( $by_tax[ $taxonomy ] ) ) {
				$by_tax[ $taxonomy ] = array();
			}
			$by_tax[ $taxonomy ][] = $term_id;
		}

		$query = array();
		foreach ( $by_tax as $taxonomy => $term_ids ) {
			$query[] = array(
				'taxonomy' => $taxonomy,
				'field'    => 'term_id',
				'terms'    => array_values( array_unique( $term_ids ) ),
			);
		}

		if ( count( $query ) > 1 ) {
			return array_merge( array( 'relation' => 'AND' ), $query );
		}

		return $query;
	}

	/**
	 * Translated Loop column header.
	 *
	 * @param string $field Field slug.
	 * @return string
	 */
	private static function loop_field_label( string $field ): string {
		switch ( $field ) {
			case 'date':
				return __( 'Date', 'dsm-supreme-modules-pro-for-divi' );
			case 'author':
				return __( 'Author', 'dsm-supreme-modules-pro-for-divi' );
			case 'excerpt':
				return __( 'Excerpt', 'dsm-supreme-modules-pro-for-divi' );
			case 'permalink':
				return __( 'Link', 'dsm-supreme-modules-pro-for-divi' );
			case 'image':
				return __( 'Image', 'dsm-supreme-modules-pro-for-divi' );
			case 'status':
				return __( 'Status', 'dsm-supreme-modules-pro-for-divi' );
			case 'title':
			default:
				return __( 'Title', 'dsm-supreme-modules-pro-for-divi' );
		}
	}

	/**
	 * Plain Loop cell text (typed cells applied after sanitize).
	 *
	 * @param \WP_Post $post  Post.
	 * @param string   $field Field slug.
	 * @return string
	 */
	private static function loop_field_value( \WP_Post $post, string $field ): string {
		switch ( $field ) {
			case 'date':
				return get_the_date( '', $post );
			case 'author':
				return get_the_author_meta( 'display_name', (int) $post->post_author );
			case 'excerpt':
				if ( post_password_required( $post ) ) {
					return get_the_excerpt( $post );
				}
				$excerpt = has_excerpt( $post ) ? (string) $post->post_excerpt : wp_trim_words( wp_strip_all_tags( (string) $post->post_content ), 16 );
				return wp_strip_all_tags( $excerpt );
			case 'permalink':
				return __( 'View', 'dsm-supreme-modules-pro-for-divi' );
			case 'image':
				$thumb_id = get_post_thumbnail_id( $post );
				if ( ! $thumb_id ) {
					return '';
				}
				$alt = (string) get_post_meta( $thumb_id, '_wp_attachment_image_alt', true );
				return '' !== $alt ? $alt : get_the_title( $post );
			case 'status':
				return sanitize_text_field( (string) $post->post_status );
			case 'title':
			default:
				return get_the_title( $post );
		}
	}

	/**
	 * Upgrade Loop text cells to link / image / badge / button where appropriate.
	 *
	 * @param array<string, mixed> $grid   Sanitized grid.
	 * @param array<int, string>   $fields Field slugs aligned to columns.
	 * @param array<int, mixed>    $posts  WP_Post list.
	 * @return array<string, mixed>
	 */
	private static function apply_loop_cell_types( array $grid, array $fields, array $posts ): array {
		$body_index = 0;
		foreach ( $grid['rows'] as $r => $row ) {
			if ( ! is_array( $row ) || 'body' !== ( $row['role'] ?? '' ) ) {
				continue;
			}
			$post = $posts[ $body_index ] ?? null;
			++$body_index;
			if ( ! $post instanceof \WP_Post ) {
				continue;
			}

			$permalink = get_permalink( $post );
			$permalink = is_string( $permalink ) ? $permalink : '';

			foreach ( $fields as $c => $field ) {
				if ( ! isset( $grid['rows'][ $r ]['cells'][ $c ] ) || ! is_array( $grid['rows'][ $r ]['cells'][ $c ] ) ) {
					continue;
				}
				$cell = $grid['rows'][ $r ]['cells'][ $c ];
				if ( 'title' === $field && '' !== $permalink ) {
					$cell['type']  = 'rich_text';
					$cell['value'] = array(
						'html' => sprintf(
							'<a href="%1$s">%2$s</a>',
							esc_url( $permalink ),
							esc_html( get_the_title( $post ) )
						),
					);
				} elseif ( 'title' === $field ) {
					$cell['type']  = 'text';
					$cell['value'] = array(
						'text' => get_the_title( $post ),
					);
				} elseif ( 'permalink' === $field && '' !== $permalink ) {
					$cell['type']  = 'button';
					$cell['value'] = array(
						'text'   => __( 'View', 'dsm-supreme-modules-pro-for-divi' ),
						'url'    => $permalink,
						'target' => '_self',
					);
				} elseif ( 'image' === $field ) {
					$thumb_id      = get_post_thumbnail_id( $post );
					$src           = $thumb_id ? wp_get_attachment_image_url( (int) $thumb_id, 'medium' ) : '';
					$src           = is_string( $src ) ? $src : '';
					$alt           = $thumb_id ? (string) get_post_meta( (int) $thumb_id, '_wp_attachment_image_alt', true ) : '';
					$cell['type']  = 'image';
					$cell['value'] = array(
						'src' => $src,
						'alt' => '' !== $alt ? $alt : get_the_title( $post ),
						'url' => $permalink,
					);
				} elseif ( 'status' === $field ) {
					$status        = sanitize_key( (string) $post->post_status );
					$variant       = 'publish' === $status ? 'success' : ( 'draft' === $status ? 'warning' : 'default' );
					$cell['type']  = 'badge';
					$cell['value'] = array(
						'text'    => $status,
						'variant' => $variant,
					);
				}
				$grid['rows'][ $r ]['cells'][ $c ] = $cell;
			}
		}

		return Table::sanitize_grid( $grid );
	}

	/**
	 * Plain text from a sanitized cell (search/export).
	 *
	 * @param array<string, mixed> $cell Cell.
	 * @return string
	 */
	private static function cell_plain_text( array $cell ): string {
		$type  = (string) ( $cell['type'] ?? 'text' );
		$value = isset( $cell['value'] ) && is_array( $cell['value'] ) ? $cell['value'] : array();

		switch ( $type ) {
			case 'rich_text':
				return trim( wp_strip_all_tags( Table::coerce_html_string( $value['html'] ?? $value['text'] ?? '' ) ) );
			case 'button':
			case 'badge':
			case 'text':
				return (string) ( $value['text'] ?? '' );
			case 'image':
				return (string) ( $value['alt'] ?? $value['src'] ?? '' );
			case 'shortcode':
				return (string) ( $value['content'] ?? '' );
			case 'star_rating':
				return (string) ( $value['rating'] ?? '' );
			default:
				return (string) ( $value['text'] ?? '' );
		}
	}

	/**
	 * Strip UTF-8 BOM.
	 *
	 * @param string $body Raw text.
	 * @return string
	 */
	private static function strip_utf8_bom( string $body ): string {
		if ( str_starts_with( $body, "\xEF\xBB\xBF" ) ) {
			return substr( $body, 3 );
		}

		return $body;
	}

	/**
	 * Split CSV into logical lines (quote-aware).
	 *
	 * @param string $text CSV text.
	 * @return array<int, string>
	 */
	private static function split_csv_lines( string $text ): array {
		$lines     = array();
		$current   = '';
		$in_quotes = false;
		$length    = strlen( $text );

		for ( $i = 0; $i < $length; $i++ ) {
			$ch = $text[ $i ];
			if ( '"' === $ch ) {
				$in_quotes = ! $in_quotes;
				$current  .= $ch;
				continue;
			}
			if ( ! $in_quotes && ( "\n" === $ch || "\r" === $ch ) ) {
				if ( "\r" === $ch && ( $i + 1 ) < $length && "\n" === $text[ $i + 1 ] ) {
					++$i;
				}
				if ( '' !== trim( $current ) || array() !== $lines ) {
					$lines[] = $current;
				}
				$current = '';
				continue;
			}
			$current .= $ch;
		}

		if ( '' !== trim( $current ) || ( '' !== $current && array() !== $lines ) ) {
			$lines[] = $current;
		}

		$filtered = array();
		foreach ( $lines as $index => $line ) {
			if ( 0 === $index || '' !== trim( $line ) ) {
				$filtered[] = $line;
			}
		}

		return $filtered;
	}

	/**
	 * Parse one delimited line into fields.
	 *
	 * @param string $line      Line.
	 * @param string $delimiter Delimiter.
	 * @return array<int, string>
	 */
	private static function parse_csv_line( string $line, string $delimiter ): array {
		$fields    = array();
		$current   = '';
		$in_quotes = false;
		$length    = strlen( $line );

		for ( $i = 0; $i < $length; $i++ ) {
			$ch = $line[ $i ];
			if ( $in_quotes ) {
				if ( '"' === $ch ) {
					if ( ( $i + 1 ) < $length && '"' === $line[ $i + 1 ] ) {
						$current .= '"';
						++$i;
					} else {
						$in_quotes = false;
					}
				} else {
					$current .= $ch;
				}
				continue;
			}
			if ( '"' === $ch ) {
				$in_quotes = true;
				continue;
			}
			if ( $delimiter === $ch ) {
				$fields[] = $current;
				$current  = '';
				continue;
			}
			$current .= $ch;
		}
		$fields[] = $current;

		return $fields;
	}
}
