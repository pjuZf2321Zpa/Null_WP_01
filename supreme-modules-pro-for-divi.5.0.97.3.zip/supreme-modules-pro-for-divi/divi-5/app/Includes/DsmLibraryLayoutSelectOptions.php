<?php
/**
 * Options list for Divi Library (`et_pb_layout`) selects (admin widget form, etc.).
 *
 * Uses the same transient key and shape as Divi 4 {@see DiviSupreme_Helpers::dsm_load_library()}.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Includes;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Provides cached ID => label pairs for Divi Library layouts.
 */
final class DsmLibraryLayoutSelectOptions {

	/**
	 * Transient cache key (shared with legacy D4 helper).
	 */
	private const TRANSIENT_KEY = 'dsm_load_library';

	/**
	 * Option that stores the library-options cache generation.
	 *
	 * Bumped when the query/shape changes so stale D4/D5 transients are rebuilt once.
	 */
	private const CACHE_VER_OPTION = 'dsm_load_library_cache_ver';

	/**
	 * Current cache generation (include layout/section/row/module; suppress Divi filters).
	 */
	private const CACHE_VERSION = 3;

	/**
	 * Layout taxonomy slugs shown in library selects (Divi Library “Type” column).
	 *
	 * @var string[]
	 */
	private const ALLOWED_LAYOUT_TYPES = array( 'layout', 'section', 'row', 'module' );

	/**
	 * Whether save/delete hooks were registered.
	 *
	 * @var bool
	 */
	private static bool $hooks_registered = false;

	/**
	 * Register transient invalidation for Divi Library CRUD (D4 parity).
	 *
	 * @return void
	 */
	public static function register_hooks(): void {
		if ( self::$hooks_registered ) {
			return;
		}

		self::$hooks_registered = true;

		add_action( 'save_post_et_pb_layout', array( self::class, 'invalidate' ), 10, 0 );
		add_action( 'deleted_post_et_pb_layout', array( self::class, 'invalidate' ), 10, 0 );
		add_action( 'trashed_post', array( self::class, 'invalidate_if_library_layout' ), 10, 1 );
		add_action( 'untrashed_post', array( self::class, 'invalidate_if_library_layout' ), 10, 1 );
		add_action( 'set_object_terms', array( self::class, 'invalidate_on_layout_type_terms' ), 10, 4 );
	}

	/**
	 * Drop the shared library select transient.
	 *
	 * @return void
	 */
	public static function invalidate(): void {
		delete_transient( self::TRANSIENT_KEY );
	}

	/**
	 * Invalidate if library layout.
	 *
	 * @param int $post_id Post ID.
	 * @return void
	 */
	public static function invalidate_if_library_layout( $post_id ): void {
		$post_id = (int) $post_id;
		if ( $post_id <= 0 ) {
			return;
		}

		if ( 'et_pb_layout' === get_post_type( $post_id ) ) {
			self::invalidate();
		}
	}

	/**
	 * Invalidate when `layout_type` terms change on a library item.
	 *
	 * @param int        $object_id  Object ID.
	 * @param array<int> $terms      Term IDs or slugs.
	 * @param array<int> $tt_ids     Term taxonomy IDs.
	 * @param string     $taxonomy   Taxonomy slug.
	 * @return void
	 */
	public static function invalidate_on_layout_type_terms( $object_id, $terms, $tt_ids, $taxonomy ): void {
		unset( $terms, $tt_ids );

		if ( 'layout_type' !== $taxonomy ) {
			return;
		}

		self::invalidate_if_library_layout( (int) $object_id );
	}

	/**
	 * Cached map of layout post ID (string) => title, plus `none` placeholder.
	 *
	 * Includes Divi Library types `layout`, `section`, `row`, and `module` (same breadth as D4
	 * `dsm_load_library` / Content Toggle), not layout-only.
	 *
	 * @return array<string, string>
	 */
	public static function get_options(): array {
		self::register_hooks();
		self::maybe_bust_stale_cache_generation();

		$cached = get_transient( self::TRANSIENT_KEY );

		if ( false !== $cached && is_array( $cached ) ) {
			return self::sanitize_options_map( $cached );
		}

		$list = array(
			'none' => __( '-- Select Library --', 'dsm-supreme-modules-pro-for-divi' ),
		);

		$posts = get_posts(
			array(
				'post_type'              => 'et_pb_layout',
				'post_status'            => array( 'publish', 'draft', 'private' ),
				'posts_per_page'         => -1,
				'orderby'                => 'title',
				'order'                  => 'ASC',
				'no_found_rows'          => true,
				'update_post_meta_cache' => false,
				'update_post_term_cache' => true,
				// Avoid Divi admin `pre_get_posts` / library UI filters when building VB options.
				'suppress_filters'       => true,
				'meta_query'             => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Library select options; cached.
					array(
						'key'     => '_et_pb_predefined_layout',
						'compare' => 'NOT EXISTS',
					),
				),
			)
		);

		if ( is_array( $posts ) ) {
			foreach ( $posts as $post ) {
				if ( ! $post instanceof \WP_Post ) {
					continue;
				}

				$layout_type = self::get_layout_type_slug( (int) $post->ID );
				if ( ! in_array( $layout_type, self::ALLOWED_LAYOUT_TYPES, true ) ) {
					continue;
				}

				$title = $post->post_title;
				if ( ! is_string( $title ) || '' === $title ) {
					$title = sprintf(
						/* translators: %d: library post ID */
						__( 'Untitled Library Item %d', 'dsm-supreme-modules-pro-for-divi' ),
						(int) $post->ID
					);
				}

				$list[ (string) $post->ID ] = $title;
			}
		}

		set_transient( self::TRANSIENT_KEY, $list, 24 * HOUR_IN_SECONDS );

		return $list;
	}

	/**
	 * Resolve Divi Library `layout_type` taxonomy slug for a post.
	 *
	 * @param int $post_id Library post ID.
	 * @return string One of layout|section|row|module, or empty when unknown.
	 */
	public static function get_layout_type_slug( int $post_id ): string {
		if ( $post_id <= 0 ) {
			return '';
		}

		if ( function_exists( 'et_pb_get_layout_type' ) ) {
			$raw = et_pb_get_layout_type( $post_id );
			if ( is_string( $raw ) && '' !== $raw ) {
				$slug = sanitize_key( explode( '|', $raw )[0] );
				if ( '' !== $slug ) {
					return $slug;
				}
			}
		}

		$terms = wp_get_post_terms( $post_id, 'layout_type', array( 'fields' => 'slugs' ) );
		if ( ! is_wp_error( $terms ) && isset( $terms[0] ) && is_string( $terms[0] ) && '' !== $terms[0] ) {
			return sanitize_key( $terms[0] );
		}

		// Divi treats missing type as a full layout.
		return 'layout';
	}

	/**
	 * Drop a previous generation of the shared transient when this class’s query changes.
	 *
	 * @return void
	 */
	private static function maybe_bust_stale_cache_generation(): void {
		$stored = (int) get_option( self::CACHE_VER_OPTION, 0 );
		if ( self::CACHE_VERSION === $stored ) {
			return;
		}

		self::invalidate();
		update_option( self::CACHE_VER_OPTION, self::CACHE_VERSION, false );
	}

	/**
	 * Ensure return shape is ID => string label (strip accidental non-string values).
	 *
	 * @param array<mixed> $cached Transient payload.
	 * @return array<string, string>
	 */
	private static function sanitize_options_map( array $cached ): array {
		$list = array();

		foreach ( $cached as $id => $label ) {
			if ( ! is_scalar( $id ) ) {
				continue;
			}
			if ( ! is_scalar( $label ) ) {
				continue;
			}
			$list[ (string) $id ] = (string) $label;
		}

		if ( ! isset( $list['none'] ) ) {
			$list['none'] = __( '-- Select Library --', 'dsm-supreme-modules-pro-for-divi' );
		}

		return $list;
	}
}
