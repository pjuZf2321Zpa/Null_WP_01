<?php
/**
 * Registry-driven frontend asset map for Divi Supreme Pro (Divi 5).
 *
 * Single source for:
 * - Divi Dynamic Assets early filter (`divi_frontend_assets_dynamic_assets_global_assets_list`) when
 * {@see should_use_divi_dynamic_assets_pipeline()} is true.
 * - Central wp_enqueue parity when DSP Dynamic Assets is ON but Divi's pipeline is inactive.
 * - Presence guards via {@see DynamicAssets::get_saved_page_blocks()} with detection/content fallbacks.
 *
 * New modules/extensions should register entries here only.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Includes;

use ET\Builder\FrontEnd\Assets\DynamicAssets;
use ET\Builder\FrontEnd\Assets\DynamicAssets\DynamicAssetsListBuilder;
use ET\Builder\FrontEnd\Assets\DynamicAssetsUtils;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Frontend asset registry and Dynamic Assets list builder integration.
 */
final class DsmFrontendAssetRegistry {

	/**
	 * Cached merged registry entries (modules + extensions + globals), split by query phase.
	 *
	 * The pre-`wp` list still includes every built module. The post-`wp` list is limited to
	 * blocks Divi registered plus extension styles that are not a module toggle.
	 *
	 * @var array<string, list<array<string, mixed>>>
	 */
	private static array $entries_cache = array();

	/**
	 * Nesting depth while Divi Dynamic Assets filters run (prevents parse_blocks re-entry).
	 *
	 * @var int
	 */
	private static int $da_filter_depth = 0;

	/**
	 * Cached `get_all_content()` from Divi's DynamicAssets content handler (per request).
	 *
	 * @var string|null
	 */
	private static ?string $da_all_content_cache = null;

	/**
	 * Cached shared asset path map keyed by slug.
	 *
	 * @var array<string, array{css?: list<string>, js?: list<string>}>|null
	 */
	private static ?array $shared_assets_cache = null;

	/**
	 * Asset keys successfully merged into Divi's global list during this request (early filter).
	 *
	 * @var array<string, true>
	 */
	private static array $pipeline_registered_asset_keys = array();

	/**
	 * Block slugs whose wp handles were enqueued by the central registry path this request.
	 *
	 * @var array<string, true>
	 */
	private static array $central_wp_enqueued_block_slugs = array();

	/**
	 * Whether this request can use Divi's Dynamic Assets merge pipeline (not merely the theme option).
	 */
	public static function should_use_divi_dynamic_assets_pipeline(): bool {
		if ( ! function_exists( 'dsm_supreme_dynamic_assets_enabled' ) || ! dsm_supreme_dynamic_assets_enabled() ) {
			return false;
		}
		if ( is_admin() ) {
			return false;
		}
		if ( function_exists( 'et_core_is_fb_enabled' ) && et_core_is_fb_enabled() ) {
			return false;
		}
		if ( ! function_exists( 'et_builder_d5_enabled' ) || ! et_builder_d5_enabled() ) {
			return false;
		}
		if ( ! class_exists( DynamicAssetsUtils::class ) ) {
			return false;
		}
		if ( ! DynamicAssetsUtils::should_generate_dynamic_assets() || ! DynamicAssetsUtils::use_dynamic_assets() ) {
			return false;
		}
		if ( ! class_exists( DynamicAssets::class ) ) {
			return false;
		}

		$instance = DynamicAssets::get_instance();
		if ( ! $instance instanceof DynamicAssets ) {
			return false;
		}

		return $instance->is_cachable_request();
	}

	/**
	 * Whether Divi 5 frontend Dynamic Assets generation is active on this request.
	 *
	 * Unlike {@see should_use_divi_dynamic_assets_pipeline()}, this does not require Supreme
	 * Miscellaneous → Dynamic Assets to be enabled. Used for ETmodules icon-font merging.
	 */
	public static function is_divi_frontend_dynamic_assets_active(): bool {
		if ( is_admin() ) {
			return false;
		}

		if ( function_exists( 'et_core_is_fb_enabled' ) && et_core_is_fb_enabled() ) {
			return false;
		}

		if ( ! function_exists( 'et_builder_d5_enabled' ) || ! et_builder_d5_enabled() ) {
			return false;
		}

		if ( ! class_exists( DynamicAssetsUtils::class ) ) {
			return false;
		}

		if ( ! DynamicAssetsUtils::should_generate_dynamic_assets() || ! DynamicAssetsUtils::use_dynamic_assets() ) {
			return false;
		}

		if ( ! class_exists( DynamicAssets::class ) ) {
			return false;
		}

		$instance = DynamicAssets::get_instance();

		if ( ! $instance instanceof DynamicAssets ) {
			return false;
		}

		return $instance->is_cachable_request();
	}

	/**
	 * True when the early global-assets filter registered at least one DSM asset key this request.
	 */
	public static function pipeline_registered_any_assets(): bool {
		return array() !== self::$pipeline_registered_asset_keys;
	}

	/**
	 * Whether a specific registry asset key was merged via the early global-assets filter.
	 *
	 * @param string $asset_key Registry `asset_key` value.
	 */
	public static function pipeline_registered_asset_key( string $asset_key ): bool {
		return isset( self::$pipeline_registered_asset_keys[ $asset_key ] );
	}

	/**
	 * True when wp_enqueue split/bundle handlers should be skipped because the Divi pipeline owns assets.
	 *
	 * When the pipeline is active, styles/scripts are merged into Divi's cached dynamic files even if the
	 * early filter did not run again on this request (cache hit).
	 */
	public static function should_skip_central_wp_enqueue(): bool {
		return self::should_use_divi_dynamic_assets_pipeline();
	}

	/**
	 * Whether module render callbacks should wp_enqueue their own scripts/styles.
	 */
	public static function should_module_render_enqueue_assets(): bool {
		return ! self::should_use_divi_dynamic_assets_pipeline();
	}

	/**
	 * Whether a module `render_callback` should wp_enqueue stylesheet handles.
	 *
	 * @param string $block_name Module block name (e.g. `dsm/image-carousel`).
	 */
	public static function should_wp_enqueue_module_styles( string $block_name ): bool {
		if ( ! function_exists( 'dsm_supreme_dynamic_assets_enabled' ) || ! dsm_supreme_dynamic_assets_enabled() ) {
			return true;
		}

		if ( self::should_use_divi_dynamic_assets_pipeline() ) {
			return false;
		}

		return ! isset( self::$central_wp_enqueued_block_slugs[ $block_name ] );
	}

	/**
	 * Whether a module `render_callback` should wp_enqueue script handles.
	 *
	 * Divi's dynamic asset generator only merges CSS; scripts always load via wp_enqueue.
	 *
	 * @param string $block_name Module block name (e.g. `dsm/image-carousel`).
	 */
	public static function should_wp_enqueue_module_scripts( string $block_name ): bool {
		if ( ! function_exists( 'dsm_supreme_dynamic_assets_enabled' ) || ! dsm_supreme_dynamic_assets_enabled() ) {
			return true;
		}

		return ! isset( self::$central_wp_enqueued_block_slugs[ $block_name ] );
	}

	/**
	 * Should wp enqueue module assets.
	 *
	 * @deprecated Use {@see should_wp_enqueue_module_styles()} and {@see should_wp_enqueue_module_scripts()}.
	 * @param string $block_name Module block name.
	 */
	public static function should_wp_enqueue_module_assets( string $block_name ): bool {
		return self::should_wp_enqueue_module_styles( $block_name )
			|| self::should_wp_enqueue_module_scripts( $block_name );
	}

	/**
	 * Whether central {@see DsmFrontendDynamicAssets} wp_enqueue handlers should run split assets.
	 *
	 * Only when Supreme Dynamic Assets is ON and Divi's merge pipeline is inactive (Supreme-only split mode).
	 */
	public static function should_use_central_wp_enqueue(): bool {
		if ( ! function_exists( 'dsm_supreme_dynamic_assets_enabled' ) || ! dsm_supreme_dynamic_assets_enabled() ) {
			return false;
		}

		return ! self::should_use_divi_dynamic_assets_pipeline();
	}

	/**
	 * Early filter callback for `divi_frontend_assets_dynamic_assets_global_assets_list`.
	 *
	 * @param array<string, mixed>          $assets_list  Global assets list.
	 * @param array<string, mixed>          $assets_args  Divi asset args (`assets_prefix`, …).
	 * @param DynamicAssetsListBuilder|null $list_builder List builder instance (3rd filter arg).
	 * @return array<string, mixed>
	 */
	public static function filter_global_assets_list( array $assets_list, array $assets_args, $list_builder = null ): array {
		if ( ! self::should_use_divi_dynamic_assets_pipeline() ) {
			return $assets_list;
		}

		self::begin_da_filter_context();

		try {
			foreach ( self::get_entries() as $entry ) {
				if ( ! self::is_entry_present( $entry, $list_builder ) ) {
					continue;
				}

				$key = isset( $entry['asset_key'] ) && is_string( $entry['asset_key'] ) && '' !== $entry['asset_key']
					? $entry['asset_key']
					: ( is_string( $entry['id'] ?? null ) ? (string) $entry['id'] : '' );

				if ( '' === $key || isset( $assets_list[ $key ] ) ) {
					continue;
				}

				$payload = self::resolve_entry_pipeline_css_payload( $entry, $assets_args );

				if ( array() === $payload ) {
					continue;
				}

				$assets_list[ $key ]                          = $payload;
				self::$pipeline_registered_asset_keys[ $key ] = true;
			}
		} finally {
			self::end_da_filter_context();
		}

		return $assets_list;
	}

	/**
	 * Mark entry into Divi Dynamic Assets filter callbacks (blocks manual parse_blocks fallbacks).
	 */
	public static function begin_da_filter_context(): void {
		++self::$da_filter_depth;
	}

	/**
	 * Leave Divi Dynamic Assets filter callback scope.
	 */
	public static function end_da_filter_context(): void {
		self::$da_filter_depth = max( 0, self::$da_filter_depth - 1 );
	}

	/**
	 * Whether code is running inside a Divi Dynamic Assets filter (global or required-module).
	 */
	public static function is_inside_da_filter_context(): bool {
		return self::$da_filter_depth > 0;
	}

	/**
	 * Whether manual block parsing is allowed on this request (off during Divi DA pipeline).
	 */
	public static function should_use_manual_block_parsing_for_detection(): bool {
		if ( self::is_inside_da_filter_context() ) {
			return false;
		}

		return ! self::should_use_divi_dynamic_assets_pipeline();
	}

	/**
	 * Enqueue registered wp handles for detected block slugs (split CSS + JS) when central wp_enqueue is active.
	 *
	 * @param array $block_slugs `dsm/*` block names.
	 * @return void
	 */
	public static function enqueue_wp_assets_for_block_slugs( array $block_slugs ): void {
		self::enqueue_wp_styles_for_block_slugs( $block_slugs );
		self::enqueue_wp_scripts_for_block_slugs( $block_slugs );
	}

	/**
	 * Enqueue split CSS/JS during library layout render when early detection missed nested modules.
	 *
	 * Skips handles already enqueued; safe to call from {@see DiviLibraryLayoutRenderer::render_layout()}.
	 *
	 * @param array $block_slugs `dsm/*` block names.
	 * @return void
	 */
	public static function enqueue_render_time_assets_for_block_slugs( array $block_slugs ): void {
		if ( is_admin() && ! ( function_exists( 'et_core_is_fb_enabled' ) && et_core_is_fb_enabled() ) ) {
			return;
		}

		$block_slugs = array_values(
			array_unique(
				array_filter(
					array_map( 'strval', $block_slugs ),
					static function ( string $s ): bool {
						return '' !== $s && str_starts_with( $s, 'dsm/' );
					}
				)
			)
		);

		if ( array() === $block_slugs ) {
			return;
		}

		$pipeline_css = self::should_use_divi_dynamic_assets_pipeline();
		$central_css  = self::should_use_central_wp_enqueue();

		foreach ( self::get_entries() as $entry ) {
			if ( ! self::entry_matches_block_slugs( $entry, $block_slugs ) ) {
				continue;
			}

			if ( ! $pipeline_css && ( $central_css || ! function_exists( 'dsm_supreme_dynamic_assets_enabled' ) || ! dsm_supreme_dynamic_assets_enabled() ) ) {
				foreach ( self::entry_wp_style_handles( $entry ) as $handle ) {
					if ( wp_style_is( $handle, 'registered' ) && ! wp_style_is( $handle, 'enqueued' ) ) {
						wp_enqueue_style( $handle );
					}
				}
			}

			foreach ( self::entry_wp_script_handles( $entry ) as $handle ) {
				if ( wp_script_is( $handle, 'registered' ) && ! wp_script_is( $handle, 'enqueued' ) ) {
					wp_enqueue_script( $handle );
				}
			}
		}
	}

	/**
	 * Enqueue registered split CSS handles for detected block slugs.
	 *
	 * @param array $block_slugs `dsm/*` block names.
	 * @return void
	 */
	public static function enqueue_wp_styles_for_block_slugs( array $block_slugs ): void {
		if ( ! self::should_use_central_wp_enqueue() ) {
			return;
		}

		$block_slugs = array_values( array_unique( array_filter( array_map( 'strval', $block_slugs ) ) ) );
		if ( array() === $block_slugs ) {
			return;
		}

		foreach ( self::get_entries() as $entry ) {
			if ( ! self::entry_matches_block_slugs( $entry, $block_slugs ) ) {
				continue;
			}
			self::mark_central_wp_enqueued_for_entry( $entry );
			foreach ( self::entry_wp_style_handles( $entry ) as $handle ) {
				if ( wp_style_is( $handle, 'registered' ) ) {
					wp_enqueue_style( $handle );
				}
			}
		}
	}

	/**
	 * Enqueue registered script handles for detected block slugs.
	 *
	 * @param array $block_slugs `dsm/*` block names.
	 * @return void
	 */
	public static function enqueue_wp_scripts_for_block_slugs( array $block_slugs ): void {
		self::enqueue_wp_scripts_for_block_slugs_internal( $block_slugs, false );
	}

	/**
	 * Enqueue script handles for detected blocks (Supreme Dynamic Assets ON, including Divi pipeline mode).
	 *
	 * @param array $block_slugs `dsm/*` block names.
	 * @return void
	 */
	public static function enqueue_wp_scripts_for_detected_blocks( array $block_slugs ): void {
		self::enqueue_wp_scripts_for_block_slugs_internal( $block_slugs, true );
	}

	/**
	 * Enqueue script handles for detected blocks when Supreme Dynamic Assets is OFF.
	 *
	 * Most modules enqueue in `render_callback`; this covers gaps (e.g. filterable gallery layout JS).
	 *
	 * @param array $block_slugs `dsm/*` block names.
	 * @return void
	 */
	public static function enqueue_wp_scripts_for_block_slugs_when_dynamic_assets_off( array $block_slugs ): void {
		if ( function_exists( 'dsm_supreme_dynamic_assets_enabled' ) && dsm_supreme_dynamic_assets_enabled() ) {
			return;
		}

		$block_slugs = array_values( array_unique( array_filter( array_map( 'strval', $block_slugs ) ) ) );
		if ( array() === $block_slugs ) {
			return;
		}

		foreach ( self::get_entries() as $entry ) {
			if ( ! self::entry_matches_block_slugs( $entry, $block_slugs ) ) {
				continue;
			}
			self::mark_central_wp_enqueued_for_entry( $entry );
			foreach ( self::entry_wp_script_handles( $entry ) as $handle ) {
				if ( wp_script_is( $handle, 'registered' ) ) {
					wp_enqueue_script( $handle );
				}
			}
		}
	}

	/**
	 * Enqueue wp style/script handles for active extension registry rows (page-wide / content-gated).
	 *
	 * Divi Dynamic Assets merges extension CSS via {@see filter_global_assets_list()}; scripts always wp_enqueue.
	 *
	 * @return void
	 */
	public static function enqueue_present_extension_assets(): void {
		$pipeline_css = self::should_use_divi_dynamic_assets_pipeline();

		foreach ( self::get_entries() as $entry ) {
			if ( ! self::is_extension_registry_entry( $entry ) ) {
				continue;
			}

			if ( empty( $entry['is_active'] ) || ! is_callable( $entry['is_active'] ) ) {
				continue;
			}

			if ( ! (bool) call_user_func( $entry['is_active'] ) ) {
				continue;
			}

			if ( ! self::is_entry_present( $entry ) ) {
				continue;
			}

			if ( ! $pipeline_css ) {
				foreach ( self::entry_wp_style_handles( $entry ) as $handle ) {
					if ( wp_style_is( $handle, 'registered' ) ) {
						wp_enqueue_style( $handle );
					}
				}
			}

			foreach ( self::entry_wp_script_handles( $entry ) as $handle ) {
				if ( wp_script_is( $handle, 'registered' ) ) {
					wp_enqueue_script( $handle );
				}
			}
		}
	}

	/**
	 * Is extension registry entry.
	 *
	 * @param array<string, mixed> $entry Registry row.
	 */
	public static function is_extension_registry_entry( array $entry ): bool {
		$id = isset( $entry['id'] ) ? (string) $entry['id'] : '';

		return str_starts_with( $id, 'dsm/extension-' );
	}

	/**
	 * Script handles that define layout (Shuffle/masonry/Swiper) — must not be deferred.
	 *
	 * @return list<string>
	 */
	public static function get_layout_critical_script_handles(): array {
		return array(
			'dsm-swiper-library',
			'dsm-image-carousel',
			'dsm-card-carousel',
			'dsm-post-carousel',
			'dsm-blog-carousel',
			'dsm-filterable-library-gallery',
			'dsm-filterable-gallery',
			'dsm-masonry-gallery',
		);
	}

	/**
	 * Enqueue wp scripts for block slugs internal.
	 *
	 * @param array $block_slugs Block names.
	 * @param bool  $force       Skip central-only guard (pipeline still needs scripts).
	 */
	private static function enqueue_wp_scripts_for_block_slugs_internal( array $block_slugs, bool $force ): void {
		if ( ! $force && ! self::should_use_central_wp_enqueue() ) {
			return;
		}

		if ( $force && ( ! function_exists( 'dsm_supreme_dynamic_assets_enabled' ) || ! dsm_supreme_dynamic_assets_enabled() ) ) {
			return;
		}

		$block_slugs = array_values( array_unique( array_filter( array_map( 'strval', $block_slugs ) ) ) );
		if ( array() === $block_slugs ) {
			return;
		}

		foreach ( self::get_entries() as $entry ) {
			if ( ! self::entry_matches_block_slugs( $entry, $block_slugs ) ) {
				continue;
			}
			self::mark_central_wp_enqueued_for_entry( $entry );
			foreach ( self::entry_wp_script_handles( $entry ) as $handle ) {
				if ( wp_script_is( $handle, 'registered' ) ) {
					wp_enqueue_script( $handle );
				}
			}
		}
	}

	/**
	 * Mark central wp enqueued for entry.
	 *
	 * @param array<string, mixed> $entry Registry row.
	 */
	private static function mark_central_wp_enqueued_for_entry( array $entry ): void {
		foreach ( self::entry_presence_keys( $entry ) as $slug ) {
			self::$central_wp_enqueued_block_slugs[ $slug ] = true;
		}
	}

	/**
	 * Enqueue wp style/script handles declared on a registry entry.
	 *
	 * @param array<string, mixed> $entry Registry row.
	 * @return void
	 */
	public static function enqueue_wp_handles_for_entry( array $entry ): void {
		foreach ( self::entry_wp_style_handles( $entry ) as $handle ) {
			if ( wp_style_is( $handle, 'registered' ) ) {
				wp_enqueue_style( $handle );
			}
		}

		foreach ( self::entry_wp_script_handles( $entry ) as $handle ) {
			if ( wp_script_is( $handle, 'registered' ) ) {
				wp_enqueue_script( $handle );
			}
		}
	}

	/**
	 * Get entries.
	 *
	 * @return list<array<string, mixed>>
	 */
	public static function get_entries(): array {
		$phase = did_action( 'wp' ) ? 'post' : 'pre';

		if ( isset( self::$entries_cache[ $phase ] ) ) {
			return self::$entries_cache[ $phase ];
		}

		$entries = array_merge(
			self::build_module_entries(),
			self::build_extension_entries(),
			self::build_global_entries()
		);

		/**
		 * Filter registry rows before cache.
		 *
		 * @param list<array<string, mixed>> $entries Registry rows.
		 */
		$filtered = apply_filters( 'dsm_frontend_asset_registry_entries', $entries );
		if ( ! is_array( $filtered ) ) {
			self::$entries_cache[ $phase ] = $entries;
			return self::$entries_cache[ $phase ];
		}

		self::$entries_cache[ $phase ] = array_values( $filtered );

		return self::$entries_cache[ $phase ];
	}

	/**
	 * Is entry present.
	 *
	 * @param array<string, mixed>                 $entry Registry row.
	 * @param DynamicAssetsListBuilder|object|null $list_builder Filter 3rd arg.
	 */
	public static function is_entry_present( array $entry, $list_builder = null ): bool {
		if ( isset( $entry['is_active'] ) && is_callable( $entry['is_active'] ) ) {
			if ( ! (bool) call_user_func( $entry['is_active'] ) ) {
				return false;
			}
		}

		// Auto-generated module rows only declare `id` (`dsm/blog-carousel`, …). That id is
		// appended by {@see entry_presence_keys()} and MUST count as a content gate or
		// Dynamic Assets never merges Swiper / split module CSS (slides stack as blocks).
		// Page-wide extensions (dark mode, custom cursor) also have an auto `id` and no
		// matching block — if content checks miss and there are no explicit gates, honor
		// `is_active` (already verified above). Popup / parallax keep content_patterns
		// and must not load site-wide just because the extension is enabled.
		$explicit_presence_keys = self::entry_explicit_presence_keys( $entry );
		$presence_keys          = self::entry_presence_keys( $entry );
		$patterns               = $entry['content_patterns'] ?? array();
		$has_content_test       = isset( $entry['content_test'] ) && is_callable( $entry['content_test'] );
		$has_explicit_gates     = array() !== $explicit_presence_keys
			|| ( is_array( $patterns ) && array() !== $patterns )
			|| $has_content_test;
		$has_presence           = array() !== $presence_keys || $has_explicit_gates;

		if ( ! $has_presence ) {
			return isset( $entry['is_active'] ) && is_callable( $entry['is_active'] );
		}

		$used_blocks = self::collect_used_block_names( $list_builder );

		foreach ( $presence_keys as $key ) {
			if ( in_array( $key, $used_blocks, true ) ) {
				return true;
			}
		}

		if ( $list_builder instanceof DynamicAssetsListBuilder ) {
			$block_assets = $list_builder->get_block_assets_list();
			foreach ( $presence_keys as $key ) {
				if ( isset( $block_assets[ $key ] ) ) {
					return true;
				}
			}
		}

		if ( $has_content_test ) {
			foreach ( self::get_presence_scan_content_blobs() as $scan_blob ) {
				if ( (bool) call_user_func( $entry['content_test'], $scan_blob ) ) {
					return true;
				}
			}
		}

		if ( is_array( $patterns ) && array() !== $patterns ) {
			foreach ( self::get_presence_scan_content_blobs() as $scan_blob ) {
				foreach ( $patterns as $pattern ) {
					if ( ! is_string( $pattern ) || '' === $pattern ) {
						continue;
					}
					if ( str_contains( $scan_blob, $pattern ) ) {
						return true;
					}
				}
			}

			if (
				! self::is_inside_da_filter_context()
				&& ! self::should_use_divi_dynamic_assets_pipeline()
				&& class_exists( DsmFrontendDynamicAssets::class )
			) {
				foreach ( $patterns as $pattern ) {
					if ( ! is_string( $pattern ) || '' === $pattern ) {
						continue;
					}
					if ( DsmFrontendDynamicAssets::merged_detection_content_contains( $pattern ) ) {
						return true;
					}
				}
			}
		}

		if ( self::presence_keys_suggested_by_content( $presence_keys ) ) {
			return true;
		}

		if (
			array() !== $presence_keys
			&& class_exists( DsmFrontendDynamicAssets::class )
			&& ! self::is_inside_da_filter_context()
			&& ! self::should_use_divi_dynamic_assets_pipeline()
		) {
			foreach ( $presence_keys as $key ) {
				if ( ! is_string( $key ) || ! str_starts_with( $key, 'dsm/' ) ) {
					continue;
				}
				if ( DsmFrontendDynamicAssets::merged_detection_includes_block_slug( $key ) ) {
					return true;
				}
			}
		}

		// Auto-id-only miss: modules stay off; dark mode / custom cursor still load via is_active.
		if ( ! $has_explicit_gates ) {
			return isset( $entry['is_active'] ) && is_callable( $entry['is_active'] );
		}

		return false;
	}

	/**
	 * Content blobs for presence / pattern scans inside Divi DA filters (substring only — no parse_blocks).
	 *
	 * @return list<string>
	 */
	private static function get_presence_scan_content_blobs(): array {
		$blobs = array();

		if ( self::is_inside_da_filter_context() || self::should_use_divi_dynamic_assets_pipeline() ) {
			$da_blob = self::get_da_all_content_for_pattern_scan();
			if ( '' !== $da_blob ) {
				$blobs[] = $da_blob;
			}
		}

		if ( class_exists( DsmFrontendDynamicAssets::class ) ) {
			$base = DsmFrontendDynamicAssets::get_base_page_content_for_detection();
			if ( '' !== $base ) {
				$blobs[] = $base;
			}
		}

		return array_values( array_unique( $blobs ) );
	}

	/**
	 * Whether any registry presence key appears in merged DA / page content (no parse_blocks).
	 *
	 * @param array $presence_keys Block names or extension ids to match.
	 */
	private static function presence_keys_suggested_by_content( array $presence_keys ): bool {
		if ( array() === $presence_keys || ! class_exists( DsmFrontendDynamicAssets::class ) ) {
			return false;
		}

		foreach ( self::get_presence_scan_content_blobs() as $scan_blob ) {
			foreach ( $presence_keys as $key ) {
				if ( ! is_string( $key ) || '' === $key ) {
					continue;
				}
				if ( str_starts_with( $key, 'dsm/' )
					&& DsmFrontendDynamicAssets::page_content_suggests_block_name( $scan_blob, $key ) ) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Divi Dynamic Assets merged scan string (already parsed by Divi — substring scans only).
	 */
	public static function get_da_all_content_for_pattern_scan(): string {
		if ( null !== self::$da_all_content_cache && '' !== self::$da_all_content_cache ) {
			return self::$da_all_content_cache;
		}

		$resolved = '';

		if ( class_exists( DynamicAssets::class ) ) {
			$instance = DynamicAssets::get_instance();
			if ( $instance instanceof DynamicAssets ) {
				try {
					$ref = new \ReflectionClass( $instance );
					if ( $ref->hasProperty( '_content' ) ) {
						$prop = $ref->getProperty( '_content' );
						if ( PHP_VERSION_ID < 80100 ) {
							$prop->setAccessible( true );
						}
						$content_handler = $prop->getValue( $instance );
						if (
							is_object( $content_handler )
							&& method_exists( $content_handler, 'get_all_content' )
						) {
							$all = $content_handler->get_all_content();
							if ( is_string( $all ) ) {
								$resolved = $all;
							}
						}
					}
				} catch ( \Throwable $e ) { // phpcs:ignore Generic.CodeAnalysis.EmptyStatement.DetectedCatch
					$resolved = '';
				}
			}
		}

		if ( '' === $resolved && class_exists( DsmFrontendDynamicAssets::class ) ) {
			$resolved = DsmFrontendDynamicAssets::get_base_page_content_for_detection();
		}

		if ( '' !== $resolved ) {
			self::$da_all_content_cache = $resolved;
		}

		return $resolved;
	}

	/**
	 * Block names Divi Dynamic Assets already detected (no manual parse_blocks).
	 *
	 * @param DynamicAssetsListBuilder|object|null $list_builder Filter 3rd arg.
	 * @return list<string>
	 */
	public static function get_da_detected_block_names( $list_builder = null ): array {
		return self::collect_used_block_names( $list_builder );
	}

	/**
	 * Collect used block names.
	 *
	 * @param DynamicAssetsListBuilder|object|null $list_builder Filter 3rd arg.
	 * @return list<string>
	 */
	private static function collect_used_block_names( $list_builder = null ): array {
		$used = array();

		if ( class_exists( DynamicAssets::class ) ) {
			$instance = DynamicAssets::get_instance();
			if ( $instance instanceof DynamicAssets ) {
				$saved = $instance->get_saved_page_blocks();
				if ( is_array( $saved ) ) {
					foreach ( $saved as $block_name ) {
						if ( is_string( $block_name ) && '' !== $block_name ) {
							$used[] = $block_name;
						}
					}
				}
			}
		}

		if ( $list_builder instanceof DynamicAssetsListBuilder ) {
			foreach ( array_keys( $list_builder->get_block_assets_list() ) as $block_name ) {
				if ( is_string( $block_name ) && '' !== $block_name ) {
					$used[] = $block_name;
				}
			}
		}

		if ( class_exists( DsmFrontendDynamicAssets::class ) ) {
			foreach ( DsmFrontendDynamicAssets::get_merged_detection_module_slugs() as $slug ) {
				if ( is_string( $slug ) && '' !== $slug ) {
					$used[] = $slug;
				}
			}
		}

		return array_values( array_unique( $used ) );
	}

	/**
	 * Resolve entry asset payload.
	 *
	 * @param array<string, mixed> $entry Registry row.
	 * @param array<string, mixed> $assets_args Divi assets args.
	 * @return array<string, list<string>|string>
	 */
	private static function resolve_entry_asset_payload( array $entry, array $assets_args ): array {
		$payload = array();

		$css_paths = self::resolve_paths_for_entry_side( $entry, 'css', $assets_args );
		if ( array() !== $css_paths ) {
			$payload['css'] = count( $css_paths ) === 1 ? $css_paths[0] : $css_paths;
		}

		$js_paths = self::resolve_paths_for_entry_side( $entry, 'js', $assets_args );
		if ( array() !== $js_paths ) {
			$payload['js'] = count( $js_paths ) === 1 ? $js_paths[0] : $js_paths;
		}

		return $payload;
	}

	/**
	 * Build global-list payload for Divi's merge pipeline (CSS only — JS uses wp_enqueue).
	 *
	 * @param array<string, mixed> $entry Registry row.
	 * @param array<string, mixed> $assets_args Divi assets args.
	 * @return array<string, list<string>|string>
	 */
	private static function resolve_entry_pipeline_css_payload( array $entry, array $assets_args ): array {
		$payload = array();

		$css_paths = self::resolve_paths_for_entry_side( $entry, 'css', $assets_args );
		if ( array() !== $css_paths ) {
			$payload['css'] = count( $css_paths ) === 1 ? $css_paths[0] : $css_paths;
		}

		return $payload;
	}

	/**
	 * Resolve paths for entry side.
	 *
	 * @param array<string, mixed> $entry Registry row.
	 * @param 'css'|'js'           $side Asset side.
	 * @param array<string, mixed> $assets_args Divi args.
	 * @return list<string> Absolute filesystem paths readable by Divi DynamicAssets.
	 */
	private static function resolve_paths_for_entry_side( array $entry, string $side, array $assets_args ): array {
		$paths = array();

		if ( ! empty( $entry['split_css'] ) && 'css' === $side ) {
			foreach ( self::entry_presence_keys( $entry ) as $block_name ) {
				$split = self::split_css_path_for_block( $block_name );
				if ( null !== $split ) {
					$paths[] = $split;
				}
			}
		}

		$shared_keys = $entry[ $side . '_shared' ] ?? array();
		if ( is_array( $shared_keys ) ) {
			foreach ( $shared_keys as $shared_key ) {
				if ( ! is_string( $shared_key ) || '' === $shared_key ) {
					continue;
				}
				$shared = self::get_shared_assets()[ $shared_key ][ $side ] ?? array();
				foreach ( (array) $shared as $relative ) {
					$absolute = self::absolute_readable_path( (string) $relative, $assets_args );
					if ( null !== $absolute ) {
						$paths[] = $absolute;
					}
				}
			}
		}

		$direct = $entry[ $side ] ?? array();
		if ( is_array( $direct ) ) {
			foreach ( $direct as $relative ) {
				$absolute = self::absolute_readable_path( (string) $relative, $assets_args );
				if ( null !== $absolute ) {
					$paths[] = $absolute;
				}
			}
		}

		$divi_rel = $entry[ 'divi_' . $side ] ?? array();
		if ( is_array( $divi_rel ) && isset( $assets_args['assets_prefix'] ) && is_string( $assets_args['assets_prefix'] ) ) {
			$prefix = $assets_args['assets_prefix'];
			foreach ( $divi_rel as $rel ) {
				if ( ! is_string( $rel ) || '' === $rel ) {
					continue;
				}
				$absolute = $prefix . '/' . ltrim( $rel, '/' );
				if ( is_readable( $absolute ) ) {
					$paths[] = $absolute;
				}
			}
		}

		return array_values( array_unique( $paths ) );
	}

	/**
	 * Absolute readable path.
	 *
	 * @param string               $relative Plugin-relative (`divi-5/...`, `assets/...`) or absolute path.
	 * @param array<string, mixed> $assets_args Unused for plugin paths; kept for API parity.
	 */
	private static function absolute_readable_path( string $relative, array $assets_args ): ?string { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter
		if ( '' === $relative ) {
			return null;
		}

		if ( str_starts_with( $relative, '/' ) && is_readable( $relative ) ) {
			return $relative;
		}

		if ( ! defined( 'DSM_DIR_PATH' ) ) {
			return null;
		}

		$relative_clean = ltrim( $relative, '/' );
		$candidates     = array(
			DSM_DIR_PATH . $relative_clean,
		);

		// Built assets live under divi-5/ while DSM_DIR_PATH is the plugin root.
		if ( ! str_starts_with( $relative_clean, 'divi-5/' ) ) {
			$candidates[] = DSM_DIR_PATH . 'divi-5/' . $relative_clean;
		}

		foreach ( $candidates as $absolute ) {
			if ( is_readable( $absolute ) ) {
				return DsmDiviBuilderCssScope::resolve_stylesheet_path( wp_normalize_path( $absolute ) );
			}
		}

		return null;
	}

	/**
	 * Split CSS path for block.
	 *
	 * @param string $block_name `dsm/*` block name.
	 */
	private static function split_css_path_for_block( string $block_name ): ?string {
		$folder = DsmFrontendModuleAssetRegistry::get_block_name_to_library_folder_map()[ $block_name ] ?? '';
		if ( '' === $folder ) {
			return null;
		}

		return DsmFrontendModuleAssetRegistry::resolve_frontend_css_absolute_path( $folder );
	}

	/**
	 * Presence keys declared on the registry row (excludes the auto-appended entry id).
	 *
	 * @param array<string, mixed> $entry Registry row.
	 * @return list<string>
	 */
	private static function entry_explicit_presence_keys( array $entry ): array {
		$keys = array();

		if ( empty( $entry['presence_keys'] ) || ! is_array( $entry['presence_keys'] ) ) {
			return $keys;
		}

		foreach ( $entry['presence_keys'] as $key ) {
			if ( is_string( $key ) && '' !== $key ) {
				$keys[] = $key;
			}
		}

		return array_values( array_unique( $keys ) );
	}

	/**
	 * Entry presence keys.
	 *
	 * @param array<string, mixed> $entry Registry row.
	 * @return list<string>
	 */
	private static function entry_presence_keys( array $entry ): array {
		$keys = self::entry_explicit_presence_keys( $entry );

		if ( isset( $entry['id'] ) && is_string( $entry['id'] ) && '' !== $entry['id'] ) {
			$keys[] = $entry['id'];
		}

		return array_values( array_unique( $keys ) );
	}

	/**
	 * Entry wp style handles.
	 *
	 * @param array<string, mixed> $entry Registry row.
	 * @return list<string>
	 */
	private static function entry_wp_style_handles( array $entry ): array {
		$handles = array();

		if ( ! empty( $entry['wp_style_handles'] ) && is_array( $entry['wp_style_handles'] ) ) {
			foreach ( $entry['wp_style_handles'] as $handle ) {
				if ( is_string( $handle ) && '' !== $handle ) {
					$handles[] = $handle;
				}
			}
		}

		if ( ! empty( $entry['split_css'] ) ) {
			foreach ( self::entry_presence_keys( $entry ) as $block_name ) {
				$folder = DsmFrontendModuleAssetRegistry::get_block_name_to_library_folder_map()[ $block_name ] ?? '';
				if ( '' !== $folder ) {
					$handles[] = DsmFrontendModuleAssetRegistry::frontend_style_handle_for_library_folder( $folder );
				}
			}
		}

		$shared_keys = $entry['css_shared'] ?? array();
		if ( is_array( $shared_keys ) ) {
			foreach ( $shared_keys as $shared_key ) {
				if ( ! is_string( $shared_key ) ) {
					continue;
				}
				$shared_handles = self::get_shared_assets()[ $shared_key ]['wp_style_handles'] ?? array();
				foreach ( (array) $shared_handles as $handle ) {
					if ( is_string( $handle ) && '' !== $handle ) {
						$handles[] = $handle;
					}
				}
			}
		}

		return array_values( array_unique( $handles ) );
	}

	/**
	 * Entry wp script handles.
	 *
	 * @param array<string, mixed> $entry Registry row.
	 * @return list<string>
	 */
	private static function entry_wp_script_handles( array $entry ): array {
		$handles = array();

		if ( ! empty( $entry['wp_script_handles'] ) && is_array( $entry['wp_script_handles'] ) ) {
			foreach ( $entry['wp_script_handles'] as $handle ) {
				if ( is_string( $handle ) && '' !== $handle ) {
					$handles[] = $handle;
				}
			}
		}

		$shared_keys = $entry['js_shared'] ?? array();
		if ( is_array( $shared_keys ) ) {
			foreach ( $shared_keys as $shared_key ) {
				if ( ! is_string( $shared_key ) ) {
					continue;
				}
				$shared_handles = self::get_shared_assets()[ $shared_key ]['wp_script_handles'] ?? array();
				foreach ( (array) $shared_handles as $handle ) {
					if ( is_string( $handle ) && '' !== $handle ) {
						$handles[] = $handle;
					}
				}
			}
		}

		return array_values( array_unique( $handles ) );
	}

	/**
	 * All wp style/script handles declared in the registry (for pipeline dequeue safety net).
	 *
	 * @return array{styles: list<string>, scripts: list<string>}
	 */
	public static function get_all_registered_wp_handles(): array {
		$styles  = array();
		$scripts = array();

		foreach ( self::get_entries() as $entry ) {
			$styles  = array_merge( $styles, self::entry_wp_style_handles( $entry ) );
			$scripts = array_merge( $scripts, self::entry_wp_script_handles( $entry ) );
		}

		$styles[]  = DsmFrontendModuleAssetRegistry::CORE_MODULES_STYLE_HANDLE;
		$styles[]  = DsmFrontendModuleAssetRegistry::EXTENSION_POPUP_STYLE_HANDLE;
		$scripts[] = DsmFrontendModuleAssetRegistry::EXTENSION_POPUP_SCRIPT_HANDLE;

		return array(
			'styles'  => array_values( array_unique( array_filter( $styles ) ) ),
			'scripts' => array_values( array_unique( array_filter( $scripts ) ) ),
		);
	}

	/**
	 * Entry matches block slugs.
	 *
	 * @param array<string, mixed> $entry Registry row.
	 * @param array                $block_slugs Detected slugs.
	 */
	private static function entry_matches_block_slugs( array $entry, array $block_slugs ): bool {
		foreach ( self::entry_presence_keys( $entry ) as $presence_key ) {
			if ( in_array( $presence_key, $block_slugs, true ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Shared bundles referenced by module/extension rows (`css_shared` / `js_shared`).
	 *
	 * @return array<string, array<string, mixed>>
	 */
	private static function get_shared_assets(): array {
		if ( null !== self::$shared_assets_cache ) {
			return self::$shared_assets_cache;
		}

		self::$shared_assets_cache = array(
			'swiper'          => array(
				'css'               => array( 'assets/css/swiper.css' ),
				'js'                => array( 'assets/js/swiper.js' ),
				'wp_style_handles'  => array( DsmFrontendModuleAssetRegistry::SWIPER_LIBRARY_STYLE_HANDLE ),
				'wp_script_handles' => array( 'dsm-swiper-library' ),
			),
			'chartjs'         => array(
				'js'                => array( 'assets/js/chart.js' ),
				'wp_script_handles' => array( 'dsm-chartjs-library' ),
			),
			'before_after'    => array(
				'css'               => array( 'assets/css/image-compare-viewer.min.css' ),
				'js'                => array(
					'assets/js/before-after-library.js',
					'assets/js/before-after-icv-mobile-fix.js',
					'assets/js/before-after-slider.js',
				),
				'wp_style_handles'  => array( DsmFrontendModuleAssetRegistry::IMAGE_COMPARE_VIEWER_STYLE_HANDLE ),
				'wp_script_handles' => array(
					'dsm-before-after-library',
					'dsm-before-after-icv-mobile-fix',
					'dsm-before-after-slider',
				),
			),
			'tilt'            => array(
				'js'                => array( 'assets/js/vanilla-tilt.min.js', 'assets/js/tilt-image.js' ),
				'wp_script_handles' => array( 'dsm-vanilla-tilt', 'dsm-tilt-image' ),
			),
			'shuffle_letters' => array(
				'js'                => array( 'assets/js/baffle.js', 'assets/js/shuffle.js' ),
				'wp_script_handles' => array( 'dsm-baffle', 'dsm-shuffle-letter' ),
			),
			'filterable'      => array(
				'js'                => array(
					'divi-5/assets/js/filterable-gallery-library.js',
					'divi-5/assets/js/filterable-gallery.js',
				),
				'wp_script_handles' => array( 'dsm-filterable-library-gallery', 'dsm-filterable-gallery' ),
			),
			'flipbox'         => array(
				'css'               => array( 'assets/css/flipbox.css' ),
				'js'                => array( 'assets/js/flipbox-frontend.js' ),
				'wp_style_handles'  => array( 'dsm-flipbox-d5' ),
				'wp_script_handles' => array( 'dsm-flipbox-click' ),
			),
			'popper_tippy'    => array(
				'js'                => array( 'assets/js/popper.js', 'assets/js/tippy.js' ),
				'wp_script_handles' => array( 'dsm-popper', 'dsm-tippy' ),
			),
			'gsap'            => array(
				'js'                => array( 'assets/js/gsap.js' ),
				'wp_script_handles' => array( 'dsm-gsap' ),
			),
			'scroll_trigger'  => array(
				'js'                => array( 'assets/js/scroll-trigger.js' ),
				'wp_script_handles' => array( 'dsm-scroll-trigger' ),
			),
			'splitting'       => array(
				'js'                => array( 'assets/js/splitting.js' ),
				'wp_script_handles' => array( 'dsm-splitting' ),
			),
			'lenis'           => array(
				'js'                => array( 'assets/js/lenis.js' ),
				'wp_script_handles' => array( 'dsm-lenis' ),
			),
			'reveal_library'  => array(
				'js'                => array( 'assets/js/reveal-library.js' ),
				'wp_script_handles' => array( 'dsm-reveal-library' ),
			),
			'supreme_animate' => array(
				'css'              => array( 'divi-5/public/supreme-animate.css' ),
				'wp_style_handles' => array( 'dsm-supreme-animate' ),
			),
			'typing'          => array(
				'js'                => array( 'assets/js/typing-library.js', 'assets/js/typing.js' ),
				'wp_script_handles' => array( 'dsm-typing-library', 'dsm-typing' ),
			),
			'text_rotator'    => array(
				'js'                => array( 'assets/js/replaceme.js', 'assets/js/text-rotator.js' ),
				'wp_script_handles' => array( 'dsm-replace-me', 'dsm-text-rotator' ),
			),
			'notation'        => array(
				'js'                => array( 'assets/js/notation-library.js', 'assets/js/notation.js' ),
				'wp_script_handles' => array( 'dsm-notation-library', 'dsm-text-notation' ),
			),
			'waypoint'        => array(
				'wp_script_handles' => array( 'divi-script-library-ext-waypoint' ),
			),
		);

		return self::$shared_assets_cache;
	}

	/**
	 * Auto split-css rows for every built module + explicit JS groupings.
	 *
	 * @return list<array<string, mixed>>
	 */
	private static function build_module_entries(): array {
		$entries = array();

		foreach ( DsmFrontendModuleAssetRegistry::get_all_module_slugs() as $block_name ) {
			$entries[] = array(
				'id'        => $block_name,
				'split_css' => true,
				'asset_key' => $block_name,
			);
		}

		$script_map = array(
			'dsm/before-after-image'         => array( 'js_shared' => array( 'before_after' ) ),
			'dsm/tilt-image'                 => array( 'js_shared' => array( 'tilt' ) ),
			'dsm/shuffle-letters'            => array( 'js_shared' => array( 'shuffle_letters' ) ),
			'dsm/image-accordion'            => array(
				'wp_script_handles' => array( 'dsm-image-accordion' ),
				'js'                => array( 'assets/js/image-accordion.js' ),
			),
			'dsm/image-carousel'             => array(
				'css_shared'        => array( 'swiper' ),
				'js_shared'         => array( 'swiper' ),
				'wp_script_handles' => array( 'dsm-image-carousel' ),
				'js'                => array( 'assets/js/image-carousel.js' ),
			),
			'dsm/card-carousel'              => array(
				'css_shared'        => array( 'swiper' ),
				'js_shared'         => array( 'swiper' ),
				'wp_script_handles' => array( 'dsm-card-carousel' ),
				'js'                => array( 'assets/js/card-carousel.js' ),
			),
			'dsm/post-carousel'              => array(
				'css_shared'        => array( 'swiper' ),
				'js_shared'         => array( 'swiper' ),
				'wp_script_handles' => array( 'dsm-post-carousel' ),
				'js'                => array( 'divi-5/assets/js/post-carousel.js' ),
			),
			'dsm/blog-carousel'              => array(
				'css_shared'        => array( 'swiper' ),
				'js_shared'         => array( 'swiper' ),
				'wp_script_handles' => array( 'dsm-blog-carousel' ),
				'js'                => array( 'divi-5/assets/js/blog-carousel.js' ),
			),
			'dsm/masonry-gallery'            => array(
				'wp_script_handles' => array( 'dsm-masonry-gallery' ),
				'js'                => array( 'assets/js/masonry-gallery.js' ),
			),
			'dsm/filterable-gallery'         => array(
				'js_shared'        => array( 'filterable' ),
				'content_patterns' => array(
					'wp:dsm/filterable-gallery',
					'"dsm/filterable-gallery"',
					'dsm_filterable_gallery',
					'[dsm_filterable_gallery',
				),
			),
			'dsm/flipbox'                    => array(
				'js_shared'     => array( 'flipbox' ),
				'presence_keys' => array( 'dsm/flipbox', 'dsm/flipbox-child' ),
			),
			'dsm/icon-list'                  => array(
				'js_shared'         => array( 'popper_tippy' ),
				'wp_script_handles' => array( 'dsm-icon-list' ),
				'js'                => array( 'assets/js/icon-list.js' ),
				'presence_keys'     => array( 'dsm/icon-list', 'dsm/icon-list-child' ),
			),
			'dsm/marquee'                    => array(
				'wp_script_handles' => array( 'dsm-marquee' ),
				'js'                => array( 'divi-5/assets/js/marquee.js' ),
				'presence_keys'     => array( 'dsm/marquee', 'dsm/marquee-child' ),
			),
			'dsm/image-hotspots'             => array(
				'js_shared'         => array( 'popper_tippy' ),
				'wp_script_handles' => array( 'dsm-image-hotspot' ),
				'js'                => array( 'divi-5/assets/js/image-hotspot.js' ),
				'presence_keys'     => array( 'dsm/image-hotspots', 'dsm/image-hotspots-child' ),
			),
			'dsm/page-tour'                  => array(
				'js_shared'         => array( 'popper_tippy' ),
				'wp_script_handles' => array( 'dsm-page-tour' ),
				'js'                => array( 'assets/js/page-tour.js' ),
				'presence_keys'     => array( 'dsm/page-tour', 'dsm/page-tour-step' ),
			),
			'dsm/lottie'                     => array(
				'wp_script_handles' => array( 'dsm-lottie-frontend' ),
				'js'                => array( 'assets/js/lottie-frontend.js' ),
			),
			'dsm/svg-animation'              => array(
				'wp_script_handles' => array( 'dsm-svg-animation' ),
				'js'                => array( 'assets/js/svg-animation-frontend.js' ),
			),
			'dsm/image-hover-reveal'         => array(
				'wp_script_handles' => array( 'dsm-image-hover-reveal' ),
				'js'                => array( 'assets/js/image-hover-reveal-frontend.js' ),
			),
			'dsm/image-text-reveal'          => array(
				'js_shared'         => array( 'gsap', 'splitting' ),
				'wp_script_handles' => array( 'dsm-text-reveal' ),
				'js'                => array( 'assets/js/image-text-reveal.js' ),
			),
			'dsm/on-scroll-header-animation' => array(
				'js_shared'         => array( 'gsap', 'scroll_trigger', 'splitting', 'lenis' ),
				'wp_script_handles' => array( 'dsm-scroll-header-animation' ),
				'js'                => array( 'assets/js/on-scroll-header-animation.js' ),
			),
			'dsm/stacking-card'              => array(
				'js_shared'         => array( 'gsap', 'scroll_trigger' ),
				'wp_script_handles' => array( 'dsm-stacking-card' ),
				'js'                => array( 'assets/js/stacking-card.js' ),
				'presence_keys'     => array( 'dsm/stacking-card', 'dsm/stacking-card-child' ),
			),
			'dsm/block-reveal-text'          => array(
				'js_shared'         => array( 'reveal_library' ),
				'wp_script_handles' => array( 'dsm-block-reveal-text' ),
				'js'                => array( 'assets/js/block-reveal-text.js' ),
			),
			'dsm/block-reveal-image'         => array(
				'js_shared'         => array( 'reveal_library' ),
				'wp_script_handles' => array( 'dsm-block-reveal-image' ),
				'js'                => array( 'assets/js/block-reveal-image.js' ),
			),
			'dsm/content-toggle'             => array(
				'wp_script_handles' => array( 'dsm-content-toggle' ),
				'js'                => array( 'assets/js/content-toggle.js' ),
			),
			'dsm/content-timeline'           => array(
				'wp_script_handles' => array( 'dsm-content-timeline' ),
				'js'                => array( 'assets/js/content-timeline.js' ),
				'presence_keys'     => array( 'dsm/content-timeline', 'dsm/content-timeline-child' ),
			),
			'dsm/circle-info'                => array(
				'css_shared'        => array( 'supreme_animate' ),
				'js_shared'         => array( 'waypoint' ),
				'wp_script_handles' => array( 'dsm-circle-info' ),
				'js'                => array( 'divi-5/assets/js/circle-info.js' ),
				'presence_keys'     => array( 'dsm/circle-info', 'dsm/circle-info-child' ),
			),
			'dsm/menu'                       => array(
				'wp_script_handles' => array( 'dsm-menu' ),
				'js'                => array( 'assets/js/menu.js' ),
			),
			'dsm/faq'                        => array(
				'wp_script_handles' => array( 'dsm-faq' ),
				'js'                => array( 'assets/js/faq.js' ),
				'presence_keys'     => array( 'dsm/faq', 'dsm/faq-child' ),
			),
			'dsm/loop-filter'                => array(
				'wp_script_handles' => array( 'dsm-loop-filter' ),
				'js'                => array( 'assets/js/loop-filter.js' ),
				'presence_keys'     => array( 'dsm/loop-filter' ),
			),
			'dsm/chart'                      => array(
				'js_shared'         => array( 'chartjs' ),
				'wp_script_handles' => array( 'dsm-chart' ),
				'js'                => array( 'assets/js/chart-module.js' ),
				'presence_keys'     => array( 'dsm/chart', 'dsm/chart-item' ),
			),
			'dsm/table-of-contents'          => array(
				'wp_script_handles' => array( 'dsm-toc' ),
				'js'                => array( 'assets/js/table-of-contents.js' ),
			),
			'dsm/testimonials'               => array(
				'css_shared'        => array( 'swiper' ),
				'js_shared'         => array( 'swiper' ),
				'wp_script_handles' => array( 'dsm-testimonials' ),
				'js'                => array( 'assets/js/testimonials.js' ),
				'presence_keys'     => array( 'dsm/testimonials', 'dsm/testimonial-item' ),
			),
			'dsm/advanced-tabs'              => array(
				'wp_script_handles' => array( 'dsm-advanced-tabs' ),
				'js'                => array( 'assets/js/advanced-tabs.js' ),
				'presence_keys'     => array( 'dsm/advanced-tabs', 'dsm/advanced-tabs-child' ),
			),
			'dsm/button'                     => array(
				'js_shared'         => array( 'popper_tippy' ),
				'wp_script_handles' => array( 'dsm-buttons' ),
				'js'                => array( 'assets/js/buttons.js' ),
			),
			'dsm/typing-effect'              => array( 'js_shared' => array( 'typing' ) ),
			'dsm/social-share-buttons'       => array(
				'wp_script_handles' => array( 'dsm-social-share-button' ),
				'js'                => array( 'assets/js/social-share-buttons.js' ),
				'presence_keys'     => array( 'dsm/social-share-buttons', 'dsm/social-share-buttons-child' ),
			),
			'dsm/text-rotator'               => array(
				'css_shared' => array( 'supreme_animate' ),
				'js_shared'  => array( 'text_rotator', 'waypoint' ),
			),
			'dsm/text-notation'              => array( 'js_shared' => array( 'notation' ) ),
			'dsm/progress-bar'               => array(
				'wp_script_handles' => array( 'dsm-progress-bar' ),
				'js'                => array( 'assets/js/progressbar.js' ),
			),
			'dsm/perspective-image'          => array(
				'wp_script_handles' => array( 'dsm-perspective-image' ),
				'js'                => array( 'assets/js/perspective-image.js' ),
			),
			'dsm/random-image'               => array(
				'wp_script_handles' => array( 'dsm-random-image' ),
				'js'                => array( 'assets/js/random-image.js' ),
			),
			'dsm/animated-headline'          => array(
				'wp_script_handles' => array( 'dsm-animated-headline' ),
				'js'                => array( 'assets/js/animated-headline.js' ),
			),
			'dsm/readmore'                   => array(
				'wp_script_handles' => array( 'dsm-readmore' ),
				'js'                => array( 'assets/js/readmore.js' ),
			),
			'dsm/facebook-simple-feed'       => array(
				'wp_script_handles' => array( 'dsm-facebook' ),
				'js'                => array( 'assets/js/facebook.js' ),
			),
			'dsm/facebook-embed'             => array(
				'wp_script_handles' => array( 'dsm-facebook' ),
				'js'                => array( 'assets/js/facebook.js' ),
			),
		);

		$indexed = array();
		foreach ( $entries as $row ) {
			$indexed[ (string) $row['id'] ] = $row;
		}

		foreach ( $script_map as $block_name => $overlay ) {
			// Disabled modules are absent from the indexed list after `wp`. Do not put them back.
			if ( ! isset( $indexed[ $block_name ] ) ) {
				continue;
			}
			$indexed[ $block_name ] = array_merge( $indexed[ $block_name ], $overlay );
		}

		return array_values( $indexed );
	}

	/**
	 * Extension rows (non-block presence via content patterns or runtime guards).
	 *
	 * @return list<array<string, mixed>>
	 */
	private static function build_extension_entries(): array {
		$entries = array();

		if ( function_exists( 'dsm_is_supreme_popup_extension_enabled' ) && dsm_is_supreme_popup_extension_enabled() ) {
			$entries[] = array(
				'id'                => 'dsm/extension-popup',
				'asset_key'         => 'dsm/extension-popup',
				'css'               => array( 'divi-5/public/style-extensions-frontend-styles.css' ),
				'js'                => array( 'assets/js/extensions/popup.js' ),
				'wp_style_handles'  => array( DsmFrontendModuleAssetRegistry::EXTENSION_POPUP_STYLE_HANDLE ),
				'wp_script_handles' => array( DsmFrontendModuleAssetRegistry::EXTENSION_POPUP_SCRIPT_HANDLE ),
				'content_patterns'  => array( 'use_popup' ),
				'is_active'         => static function (): bool {
					return function_exists( 'dsm_is_supreme_popup_extension_enabled' ) && dsm_is_supreme_popup_extension_enabled();
				},
			);
		}

		if ( function_exists( 'dsm_is_supreme_parallax_extension_enabled' ) && dsm_is_supreme_parallax_extension_enabled() ) {
			$entries[] = array(
				'id'                => 'dsm/extension-supreme-parallax',
				'asset_key'         => 'dsm/extension-supreme-parallax',
				'js'                => array( 'divi-5/public/supreme-parallax-frontend.js' ),
				'wp_script_handles' => array( 'dsm-supreme-parallax-frontend' ),
				'content_patterns'  => array( 'dsm_spx_' ),
				'is_active'         => static function (): bool {
					return function_exists( 'dsm_is_supreme_parallax_extension_enabled' ) && dsm_is_supreme_parallax_extension_enabled();
				},
			);
		}

		if ( function_exists( 'dsm_is_image_parallax_extension_enabled' ) && dsm_is_image_parallax_extension_enabled() ) {
			$entries[] = array(
				'id'                => 'dsm/extension-image-parallax',
				'asset_key'         => 'dsm/extension-image-parallax',
				'css'               => array( 'divi-5/public/image-parallax-frontend.css' ),
				'js'                => array( 'divi-5/public/image-parallax-frontend.js' ),
				'wp_style_handles'  => array( 'dsm-image-parallax-frontend' ),
				'wp_script_handles' => array( 'dsm-image-parallax-frontend' ),
				'content_patterns'  => array( 'data-dsm-ipx-on', '"dsm_ipx_' ),
				'is_active'         => static function (): bool {
					return function_exists( 'dsm_is_image_parallax_extension_enabled' ) && dsm_is_image_parallax_extension_enabled();
				},
			);
		}

		if ( function_exists( 'dsm_is_tooltip_extension_enabled' ) && dsm_is_tooltip_extension_enabled() ) {
			$entries[] = array(
				'id'                => 'dsm/extension-tooltip',
				'asset_key'         => 'dsm/extension-tooltip',
				'css'               => array( 'divi-5/public/style-tooltip-frontend.css' ),
				'js'                => array( 'divi-5/public/tooltip-frontend.js' ),
				'wp_style_handles'  => array( 'dsm-tooltip-frontend' ),
				'wp_script_handles' => array( 'dsm-tooltip-frontend' ),
				'content_patterns'  => array( 'data-dsm-tooltip-on' ),
				'content_test'      => static function ( string $blob ): bool {
					return function_exists( 'dsm_content_has_enabled_tooltip' )
						&& dsm_content_has_enabled_tooltip( $blob );
				},
				'is_active'         => static function (): bool {
					return function_exists( 'dsm_is_tooltip_extension_enabled' ) && dsm_is_tooltip_extension_enabled();
				},
			);
		}

		if ( function_exists( 'dsm_is_page_tour_extension_enabled' ) && dsm_is_page_tour_extension_enabled() ) {
			$entries[] = array(
				'id'                => 'dsm/extension-page-tour',
				'asset_key'         => 'dsm/extension-page-tour',
				'css'               => array( 'divi-5/public/style-extensions-frontend-styles.css' ),
				'js'                => array( 'divi-5/assets/js/page-tour.js' ),
				'wp_style_handles'  => array( DsmFrontendModuleAssetRegistry::EXTENSION_POPUP_STYLE_HANDLE ),
				'wp_script_handles' => array( 'dsm-page-tour' ),
				'content_patterns'  => array( 'data-dsm-tour-step', 'dsm_page_tour_enabled' ),
				'content_test'      => static function ( string $blob ): bool {
					return function_exists( 'dsm_content_has_enabled_page_tour' )
						&& dsm_content_has_enabled_page_tour( $blob );
				},
				'is_active'         => static function (): bool {
					return function_exists( 'dsm_is_page_tour_extension_enabled' ) && dsm_is_page_tour_extension_enabled();
				},
			);
		}

		if ( function_exists( 'dsm_is_custom_cursor_extension_enabled' ) && dsm_is_custom_cursor_extension_enabled() ) {
			$entries[] = array(
				'id'                => 'dsm/extension-custom-cursor',
				'asset_key'         => 'dsm/extension-custom-cursor',
				'css'               => array( 'divi-5/public/style-custom-cursor-frontend-styles.css' ),
				'js'                => array( 'divi-5/public/custom-cursor-frontend.js' ),
				'wp_style_handles'  => array( 'dsm-custom-cursor-frontend' ),
				'wp_script_handles' => array( 'dsm-custom-cursor-frontend' ),
				'is_active'         => static function (): bool {
					if ( ! function_exists( 'dsm_is_custom_cursor_extension_enabled' ) || ! dsm_is_custom_cursor_extension_enabled() ) {
						return false;
					}
					if ( ! isset( $GLOBALS['dsm_custom_cursor_extension'] ) || ! is_object( $GLOBALS['dsm_custom_cursor_extension'] ) ) {
						return false;
					}
					$ext = $GLOBALS['dsm_custom_cursor_extension'];
					return is_object( $ext ) && method_exists( $ext, 'should_load_on_current_request' )
						? (bool) $ext->should_load_on_current_request()
						: false;
				},
			);
		}

		if ( function_exists( 'dsm_is_preloader_extension_enabled' ) && dsm_is_preloader_extension_enabled() ) {
			// Overlay CSS is printed inline on wp_head. Do not merge CSS via Divi Dynamic Assets.
			$entries[] = array(
				'id'                => 'dsm/extension-preloader',
				'asset_key'         => 'dsm/extension-preloader',
				'js'                => array( 'divi-5/public/preloader-frontend.js' ),
				'wp_script_handles' => array( 'dsm-preloader-frontend' ),
				'is_active'         => static function (): bool {
					if ( ! function_exists( 'dsm_is_preloader_extension_enabled' ) || ! dsm_is_preloader_extension_enabled() ) {
						return false;
					}
					if ( ! isset( $GLOBALS['dsm_preloader_extension'] ) || ! is_object( $GLOBALS['dsm_preloader_extension'] ) ) {
						return false;
					}
					$ext = $GLOBALS['dsm_preloader_extension'];
					return is_object( $ext ) && method_exists( $ext, 'should_load_on_current_request' )
						? (bool) $ext->should_load_on_current_request()
						: false;
				},
			);
		}

		if ( function_exists( 'dsm_is_dark_mode_extension_enabled' ) && dsm_is_dark_mode_extension_enabled() ) {
			// Styles are owned by DarkMode::maybe_enqueue_frontend_assets() (global sheet; body-mounted
			// floating switch). Do not merge CSS via Divi Dynamic Assets — avoids CPT-scoped miss + dupes.
			$entries[] = array(
				'id'                => 'dsm/extension-dark-mode',
				'asset_key'         => 'dsm/extension-dark-mode',
				'js'                => array( 'divi-5/public/dark-mode-frontend.js' ),
				'wp_script_handles' => array( 'dsm-dark-mode-frontend' ),
				'is_active'         => static function (): bool {
					if ( ! function_exists( 'dsm_is_dark_mode_extension_enabled' ) || ! dsm_is_dark_mode_extension_enabled() ) {
						return false;
					}
					if ( ! isset( $GLOBALS['dsm_dark_mode_extension'] ) || ! is_object( $GLOBALS['dsm_dark_mode_extension'] ) ) {
						return false;
					}
					$ext = $GLOBALS['dsm_dark_mode_extension'];
					return is_object( $ext ) && method_exists( $ext, 'should_load_on_current_request' )
						? (bool) $ext->should_load_on_current_request()
						: false;
				},
			);
		}

		if ( function_exists( 'dsm_is_line_hover_animation_extension_enabled' ) && dsm_is_line_hover_animation_extension_enabled() ) {
			$entries[] = array(
				'id'               => 'dsm/extension-line-hover',
				'asset_key'        => 'dsm/extension-line-hover',
				'split_css'        => true,
				'presence_keys'    => array( 'dsm/line-hover' ),
				'content_patterns' => array( 'dsm_lhe_use' ),
				'is_active'        => static function (): bool {
					return function_exists( 'dsm_is_line_hover_animation_extension_enabled' ) && dsm_is_line_hover_animation_extension_enabled();
				},
			);
		}

		return $entries;
	}

	/**
	 * Global supplemental assets (icons, monolithic bundle fallback).
	 *
	 * @return list<array<string, mixed>>
	 */
	private static function build_global_entries(): array {
		$entries = array();

		$entries[] = array(
			'id'               => 'dsm/shared-supreme-animate',
			'asset_key'        => 'dsm/shared-supreme-animate',
			'css'              => array( 'divi-5/public/supreme-animate.css' ),
			'wp_style_handles' => array( 'dsm-supreme-animate' ),
			'is_active'        => static function (): bool {
				return class_exists( DsmFrontendDynamicAssets::class )
					&& DsmFrontendDynamicAssets::page_needs_supreme_animate_css();
			},
		);

		$icon_rows = array(
			array(
				'asset_key' => 'et_icons_all',
				'divi_css'  => array( 'css/icons_all.css' ),
			),
			array(
				'asset_key' => 'et_icons_fa',
				'divi_css'  => array( 'css/icons_fa_all.css' ),
			),
		);

		foreach ( $icon_rows as $icon_row ) {
			$entries[] = array_merge(
				$icon_row,
				array(
					'id'        => 'dsm/divi-icons-for-modules-' . $icon_row['asset_key'],
					'is_active' => static function (): bool {
						return class_exists( DsmFrontendDynamicAssets::class )
							&& DsmFrontendDynamicAssets::page_needs_divi_icon_font();
					},
				)
			);
		}

		return $entries;
	}
}
