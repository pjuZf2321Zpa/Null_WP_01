<?php
/**
 * Whether the Line Hover Animation extension is enabled (General settings).
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * True when Divi Supreme → General → Enable Line Hover Animation is on.
 *
 * Defaults to enabled when unset (matches settings default).
 *
 * @return bool
 */
function dsm_is_line_hover_animation_extension_enabled(): bool {
	$general = get_option( 'dsm_general', array() );

	if ( ! is_array( $general ) ) {
		return true;
	}

	if ( ! array_key_exists( 'dsm_use_line_hover_animation', $general ) ) {
		return true;
	}

	return 'on' === $general['dsm_use_line_hover_animation'];
}
