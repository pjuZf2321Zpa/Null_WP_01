<?php
/**
 * REST: search / resolve posts for Custom Cursor scope picker (Visual Builder).
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Registers `GET /dsm/v1/custom-cursor-scope-posts`.
 */
final class DSM_Custom_Cursor_Scope_Posts_REST {

	/**
	 * Hook REST routes.
	 */
	public function __construct() {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	/**
	 * Register routes.
	 *
	 * @return void
	 */
	public function register_routes(): void {
		register_rest_route(
			'dsm/v1',
			'/custom-cursor-scope-posts',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_posts' ),
					'permission_callback' => array( $this, 'permission_callback' ),
					'args'                => array(
						'search'    => array(
							'type'              => 'string',
							'default'           => '',
							'sanitize_callback' => 'sanitize_text_field',
						),
						'post_type' => array(
							'type'              => 'string',
							'default'           => 'all',
							'sanitize_callback' => 'sanitize_key',
						),
						'ids'       => array(
							'type'              => 'string',
							'default'           => '',
							'sanitize_callback' => 'sanitize_text_field',
						),
						'per_page'  => array(
							'type'    => 'integer',
							'default' => 20,
							'minimum' => 1,
							'maximum' => 100,
						),
					),
				),
			)
		);
	}

	/**
	 * Permission callback.
	 *
	 * @return bool
	 */
	public function permission_callback(): bool {
		return current_user_can( 'edit_posts' );
	}

	/**
	 * Post type slugs allowed in the scope picker (matches Divi Supreme VB post types).
	 *
	 * @return string[]
	 */
	private function get_allowed_post_type_slugs(): array {
		if ( ! function_exists( 'dsm_get_post_type_taxonomies' ) ) {
			require_once DSM_DIR_PATH . 'divi-5/app/Utils/get-post-type-taxonomies.php';
		}

		if ( ! function_exists( 'dsm_get_post_types' ) ) {
			require_once DSM_DIR_PATH . 'divi-5/app/Utils/get-post-types.php';
		}

		$types = dsm_get_post_types();

		if ( ! is_array( $types ) || array() === $types ) {
			return array( 'page', 'post' );
		}

		$slugs = array();

		foreach ( $types as $type ) {
			if ( is_array( $type ) && ! empty( $type['name'] ) && is_string( $type['name'] ) ) {
				$slugs[] = $type['name'];
			}
		}

		return array_values( array_unique( $slugs ) );
	}

	/**
	 * Parse IDs param.
	 *
	 * @param string $raw Comma-separated IDs.
	 * @return int[]
	 */
	private function parse_ids_param( string $raw ): array {
		if ( '' === trim( $raw ) ) {
			return array();
		}

		return array_values(
			array_filter(
				array_map(
					'absint',
					explode( ',', $raw )
				)
			)
		);
	}

	/**
	 * Format post item.
	 *
	 * @param \WP_Post $post Post object.
	 * @return array{id: int, title: string, post_type: string, post_type_label: string}
	 */
	private function format_post_item( \WP_Post $post ): array {
		$type_object = get_post_type_object( $post->post_type );
		$title       = get_the_title( $post );

		if ( '' === $title ) {
			$title = sprintf(
				/* translators: %d: post ID */
				__( 'Untitled (#%d)', 'dsm-supreme-modules-pro-for-divi' ),
				$post->ID
			);
		}

		return array(
			'id'              => (int) $post->ID,
			'title'           => wp_strip_all_tags( $title ),
			'post_type'       => (string) $post->post_type,
			'post_type_label' => $type_object instanceof \WP_Post_Type
				? (string) $type_object->labels->singular_name
				: (string) $post->post_type,
		);
	}

	/**
	 * Get posts.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response
	 */
	public function get_posts( \WP_REST_Request $request ): \WP_REST_Response {
		$allowed   = $this->get_allowed_post_type_slugs();
		$ids       = $this->parse_ids_param( (string) $request->get_param( 'ids' ) );
		$search    = (string) $request->get_param( 'search' );
		$post_type = sanitize_key( (string) $request->get_param( 'post_type' ) );
		$per_page  = min( 100, max( 1, (int) $request->get_param( 'per_page' ) ) );

		$query_args = array(
			'post_status'         => array( 'publish', 'draft', 'private', 'future', 'pending' ),
			'orderby'             => 'title',
			'order'               => 'ASC',
			'ignore_sticky_posts' => true,
			'no_found_rows'       => true,
		);

		if ( array() !== $ids ) {
			$query_args['post__in']       = $ids;
			$query_args['posts_per_page'] = count( $ids );
			$query_args['post_type']      = $allowed;
			$query_args['orderby']        = 'post__in';
		} else {
			if ( 'all' === $post_type || '' === $post_type ) {
				$query_args['post_type'] = $allowed;
			} elseif ( in_array( $post_type, $allowed, true ) ) {
				$query_args['post_type'] = $post_type;
			} else {
				$query_args['post_type'] = $allowed;
			}

			$query_args['posts_per_page'] = $per_page;

			if ( '' !== trim( $search ) ) {
				$query_args['s'] = $search;
			}
		}

		$query = new \WP_Query( $query_args );
		$items = array();

		foreach ( $query->posts as $post ) {
			if ( ! $post instanceof \WP_Post ) {
				continue;
			}
			$items[] = $this->format_post_item( $post );
		}

		return new \WP_REST_Response(
			array(
				'items' => $items,
			),
			200
		);
	}
}

new DSM_Custom_Cursor_Scope_Posts_REST();
