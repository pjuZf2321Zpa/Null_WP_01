<?php
/**
 * Tooltip extension — global enable flag (Divi Supreme → Extensions).
 *
 * Opt-in: disabled unless the user turns on Tooltip in plugin settings.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

if ( ! function_exists( 'dsm_is_tooltip_extension_enabled' ) ) {
	/**
	 * True when Divi Supreme → Extensions → Tooltip is on (default: off).
	 *
	 * @return bool
	 */
	function dsm_is_tooltip_extension_enabled(): bool {
		$general = get_option( 'dsm_general', array() );

		if ( ! is_array( $general ) ) {
			return false;
		}

		if ( ! array_key_exists( 'dsm_use_tooltip', $general ) ) {
			return false;
		}

		return 'on' === $general['dsm_use_tooltip'];
	}
}

if ( ! function_exists( 'dsm_content_has_enabled_tooltip' ) ) {
	/**
	 * True when layout HTML/JSON has a tooltip that is actually on.
	 *
	 * Bare `enable_tooltip` is not enough — Divi may keep the key with value `off`.
	 *
	 * @param string $content Post content, DA scan blob, or rendered HTML.
	 * @return bool
	 */
	function dsm_content_has_enabled_tooltip( string $content ): bool {
		if ( '' === $content ) {
			return false;
		}

		if ( str_contains( $content, 'data-dsm-tooltip-on' ) ) {
			return true;
		}

		if ( ! str_contains( $content, 'enable_tooltip' ) ) {
			return false;
		}

		if ( ! preg_match_all(
			'/"enable_tooltip"\s*:\s*\{\s*"innerContent"\s*:\s*(\{(?:[^{}]|\{[^{}]*\})*\})/s',
			$content,
			$matches
		) ) {
			return false;
		}

		foreach ( $matches[1] as $inner ) {
			if ( ! is_string( $inner ) ) {
				continue;
			}

			if ( preg_match( '/"value"\s*:\s*"on"/', $inner ) ) {
				return true;
			}
		}

		return false;
	}
}
