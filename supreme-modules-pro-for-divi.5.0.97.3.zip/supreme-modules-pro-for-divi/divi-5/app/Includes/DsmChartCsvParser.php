<?php
/**
 * Wide-schema Chart CSV parser (mirrors VB `chart-csv-parse.js`).
 *
 * Schema: first column = label/category, other columns = series.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Includes;

use WP_Error;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Parses Chart CSV text into labels + series value arrays.
 */
class DsmChartCsvParser {

	/**
	 * Maximum datasets.
	 *
	 * @var int
	 */
	private const MAX_DATASETS = 20;

	/**
	 * Maximum category / data-point rows.
	 *
	 * @var int
	 */
	private const MAX_CATEGORIES = 50;

	/**
	 * Parse wide Chart CSV into structured series data.
	 *
	 * @param string $raw CSV text.
	 * @return array{labels: array<int, string>, series: array<int, array{label: string, data: array<int, float|null>}>}|WP_Error
	 */
	public static function parse( string $raw ) {
		$text = self::strip_utf8_bom( trim( $raw ) );
		if ( '' === $text ) {
			return new WP_Error(
				'dsm_chart_csv_empty',
				__( 'CSV is empty.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 400 )
			);
		}

		if ( 1 === preg_match( '/\$variable\s*\(/i', $text ) ) {
			return new WP_Error(
				'dsm_chart_csv_dynamic',
				__( 'CSV cannot include Dynamic Content ($variable).', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 400 )
			);
		}

		$lines = self::split_lines( $text );
		if ( count( $lines ) < 2 ) {
			return new WP_Error(
				'dsm_chart_csv_rows',
				__( 'CSV needs a header row and at least one data row.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 400 )
			);
		}

		$header = array_map( 'trim', self::parse_line( $lines[0] ) );
		if ( count( $header ) < 2 ) {
			return new WP_Error(
				'dsm_chart_csv_header',
				__( 'CSV header must start with label/category and include at least one series column.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 400 )
			);
		}

		$first = strtolower( $header[0] );
		if ( ! in_array( $first, array( 'label', 'category' ), true ) ) {
			return new WP_Error(
				'dsm_chart_csv_label_header',
				__( 'First header cell must be “label”, “Label”, or “category”.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 400 )
			);
		}

		$series_labels = array_map( 'trim', array_slice( $header, 1 ) );
		foreach ( $series_labels as $series_label ) {
			if ( '' === $series_label ) {
				return new WP_Error(
					'dsm_chart_csv_series_header',
					__( 'Every series column needs a non-empty header name.', 'dsm-supreme-modules-pro-for-divi' ),
					array( 'status' => 400 )
				);
			}
		}

		if ( count( $series_labels ) > self::MAX_DATASETS ) {
			return new WP_Error(
				'dsm_chart_csv_too_many_datasets',
				sprintf(
					/* translators: %d: maximum dataset count */
					__( 'Too many datasets. Maximum is %d.', 'dsm-supreme-modules-pro-for-divi' ),
					self::MAX_DATASETS
				),
				array( 'status' => 400 )
			);
		}

		$labels     = array();
		$value_grid = array_fill( 0, count( $series_labels ), array() );
		$data_rows  = 0;

		$line_count = count( $lines );
		for ( $r = 1; $r < $line_count; $r++ ) {
			$cells     = self::parse_line( $lines[ $r ] );
			$category  = trim( (string) ( $cells[0] ?? '' ) );
			$all_empty = true;
			foreach ( $cells as $cell ) {
				if ( '' !== trim( (string) $cell ) ) {
					$all_empty = false;
					break;
				}
			}
			if ( $all_empty ) {
				continue;
			}
			if ( '' === $category ) {
				return new WP_Error(
					'dsm_chart_csv_row_label',
					__( 'Each data row needs a category label in the first column.', 'dsm-supreme-modules-pro-for-divi' ),
					array( 'status' => 400 )
				);
			}

			++$data_rows;
			if ( $data_rows > self::MAX_CATEGORIES ) {
				return new WP_Error(
					'dsm_chart_csv_too_many_rows',
					sprintf(
						/* translators: %d: maximum point/category count */
						__( 'Too many data rows. Maximum is %d points.', 'dsm-supreme-modules-pro-for-divi' ),
						self::MAX_CATEGORIES
					),
					array( 'status' => 400 )
				);
			}

			$labels[]     = $category;
			$series_count = count( $series_labels );
			for ( $s = 0; $s < $series_count; $s++ ) {
				$value_grid[ $s ][] = self::parse_number( (string) ( $cells[ $s + 1 ] ?? '' ) );
			}
		}

		if ( array() === $labels ) {
			return new WP_Error(
				'dsm_chart_csv_no_data',
				__( 'CSV has no data rows after the header.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 400 )
			);
		}

		$series = array();
		foreach ( $series_labels as $index => $series_label ) {
			$series[] = array(
				'label' => $series_label,
				'data'  => $value_grid[ $index ],
			);
		}

		return array(
			'labels' => $labels,
			'series' => $series,
		);
	}

	/**
	 * Strip UTF-8 BOM.
	 *
	 * @param string $body Raw text.
	 * @return string
	 */
	private static function strip_utf8_bom( string $body ): string {
		if ( str_starts_with( $body, "\xEF\xBB\xBF" ) ) {
			return substr( $body, 3 );
		}
		return $body;
	}

	/**
	 * Split CSV into logical lines (quote-aware).
	 *
	 * @param string $text CSV text.
	 * @return array<int, string>
	 */
	private static function split_lines( string $text ): array {
		$lines     = array();
		$current   = '';
		$in_quotes = false;
		$length    = strlen( $text );

		for ( $i = 0; $i < $length; $i++ ) {
			$ch = $text[ $i ];
			if ( '"' === $ch ) {
				$in_quotes = ! $in_quotes;
				$current  .= $ch;
				continue;
			}
			if ( ! $in_quotes && ( "\n" === $ch || "\r" === $ch ) ) {
				if ( "\r" === $ch && ( $i + 1 ) < $length && "\n" === $text[ $i + 1 ] ) {
					++$i;
				}
				if ( '' !== trim( $current ) || array() !== $lines ) {
					$lines[] = $current;
				}
				$current = '';
				continue;
			}
			$current .= $ch;
		}

		if ( '' !== trim( $current ) || ( '' !== $current && array() !== $lines ) ) {
			$lines[] = $current;
		}

		$filtered = array();
		foreach ( $lines as $index => $line ) {
			if ( 0 === $index || '' !== trim( $line ) ) {
				$filtered[] = $line;
			}
		}

		return $filtered;
	}

	/**
	 * Parse one CSV line into fields.
	 *
	 * @param string $line Line.
	 * @return array<int, string>
	 */
	private static function parse_line( string $line ): array {
		$fields    = array();
		$current   = '';
		$in_quotes = false;
		$length    = strlen( $line );

		for ( $i = 0; $i < $length; $i++ ) {
			$ch = $line[ $i ];
			if ( $in_quotes ) {
				if ( '"' === $ch ) {
					if ( ( $i + 1 ) < $length && '"' === $line[ $i + 1 ] ) {
						$current .= '"';
						++$i;
					} else {
						$in_quotes = false;
					}
				} else {
					$current .= $ch;
				}
				continue;
			}
			if ( '"' === $ch ) {
				$in_quotes = true;
				continue;
			}
			if ( ',' === $ch ) {
				$fields[] = $current;
				$current  = '';
				continue;
			}
			$current .= $ch;
		}
		$fields[] = $current;

		return $fields;
	}

	/**
	 * Parse a numeric cell to float or null.
	 *
	 * @param string $raw Cell text.
	 * @return float|null
	 */
	private static function parse_number( string $raw ): ?float {
		$plain = trim( $raw );
		if ( '' === $plain ) {
			return null;
		}
		$numeric = (float) preg_replace( '/[^\d.-]/', '', $plain );
		return is_finite( $numeric ) ? $numeric : null;
	}
}
