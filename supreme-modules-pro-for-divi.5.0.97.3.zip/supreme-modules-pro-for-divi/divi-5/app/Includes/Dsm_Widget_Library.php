<?php
/**
 * WordPress widget: render a Divi Library layout in widget areas (Divi 5 pipeline).
 *
 * Widget id base `dsm_widget_library` matches legacy `widget_dsm_widget_library` option entries.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Includes;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Renders library content via {@see DiviLibraryLayoutRenderer::render_layout()}.
 */
class Dsm_Widget_Library extends \WP_Widget {

	/**
	 * Canonical instance key for the selected layout post ID.
	 *
	 * @var string
	 */
	private const INSTANCE_KEY_LAYOUT = 'layout';

	/**
	 * Whether admin style hooks were registered.
	 *
	 * @var bool
	 */
	private static $admin_hooks_registered = false;

	/**
	 * Whether widgets-screen library styles were enqueued on this request.
	 *
	 * @var bool
	 */
	private static $admin_styles_enqueued = false;

	/**
	 * Constructor.
	 */
	public function __construct() {
		parent::__construct(
			'dsm_widget_library',
			esc_html__( 'Divi Supreme Library', 'dsm-supreme-modules-pro-for-divi' ),
			array(
				'classname'   => 'dsm_widget_library',
				'description' => esc_html__( 'Display a layout from the Divi Library.', 'dsm-supreme-modules-pro-for-divi' ),
			),
			array(
				'width'  => 400,
				'height' => 200,
			)
		);

		if ( ! self::$admin_hooks_registered ) {
			self::$admin_hooks_registered = true;
			add_action( 'enqueue_block_assets', array( self::class, 'enqueue_admin_library_styles' ) );
			add_action( 'admin_enqueue_scripts', array( self::class, 'enqueue_admin_library_styles' ) );
			add_action( 'wp_enqueue_scripts', array( self::class, 'enqueue_admin_library_styles' ) );
		}
	}

	/**
	 * Front-end output.
	 *
	 * @param array<string, mixed> $args     Widget args.
	 * @param array<string, mixed> $instance Saved widget settings.
	 * @return void
	 */
	public function widget( $args, $instance ) {
		$instance = is_array( $instance ) ? $instance : array();

		$layout_id = self::resolve_layout_post_id_from_instance( $instance );

		if ( $layout_id <= 0 ) {
			return;
		}

		$html = DiviLibraryLayoutRenderer::render_layout( $layout_id, 'dsm_widget_library' );

		if ( '' === trim( (string) $html ) ) {
			return;
		}

		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Theme-supplied widget wrappers.
		echo $args['before_widget'];

		$title = isset( $instance['title'] ) ? (string) $instance['title'] : '';

		if ( '' !== trim( $title ) ) {
			/**
			 * This filter is documented in wp-includes/widgets/class-wp-widget-pages.php
			 */
			$title = apply_filters( 'widget_title', $title, $instance, $this->id_base );
			// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Theme-supplied title wrappers.
			echo $args['before_title'] . $title . $args['after_title'];
		}

		// Divi prints button and module colors as `body #page-container .et_pb_section …`.
		// The widgets preview document has no theme #page-container, so those rules never match.
		if ( self::is_widgets_screen_request() ) {
			echo '<div id="page-container" class="dsm-widget-library-layout">';
		} else {
			echo '<div class="dsm-widget-library-layout">';
		}
		$structural = self::admin_structural_stylesheet_markup( $layout_id );
		if ( '' !== $structural ) {
			if ( function_exists( 'et_core_intentionally_unescaped' ) ) {
				echo et_core_intentionally_unescaped( $structural, 'html' );
			} else {
				echo $structural; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- href and id escaped in admin_structural_stylesheet_markup(); et_core is unavailable.
			}
		}
		if ( function_exists( 'et_core_esc_previously' ) ) {
			echo et_core_esc_previously( $html );
		} elseif ( function_exists( 'et_core_intentionally_unescaped' ) ) {
			echo et_core_intentionally_unescaped( $html, 'html' );
		} else {
			echo $html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Divi Builder layout HTML; et_core escaping helpers are unavailable.
		}
		echo '</div>';

		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Theme-supplied widget wrappers.
		echo $args['after_widget'];
	}

	/**
	 * Admin form.
	 *
	 * @param array<string, mixed> $instance Current settings.
	 * @return void
	 */
	public function form( $instance ) {
		$instance = is_array( $instance ) ? $instance : array();

		$title        = isset( $instance['title'] ) ? (string) $instance['title'] : '';
		$selected_raw = self::get_layout_value_from_instance( $instance );
		$selected     = ( 'none' === $selected_raw || '' === $selected_raw ) ? 'none' : (string) absint( $selected_raw );

		$field_id   = $this->get_field_id( 'title' );
		$field_name = $this->get_field_name( 'title' );

		$layout_field_id   = $this->get_field_id( self::INSTANCE_KEY_LAYOUT );
		$layout_field_name = $this->get_field_name( self::INSTANCE_KEY_LAYOUT );

		$options = DsmLibraryLayoutSelectOptions::get_options();
		?>
		<p>
			<label for="<?php echo esc_attr( $field_id ); ?>">
				<?php esc_html_e( 'Title:', 'dsm-supreme-modules-pro-for-divi' ); ?>
			</label>
			<input class="widefat" id="<?php echo esc_attr( $field_id ); ?>" name="<?php echo esc_attr( $field_name ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
		</p>
		<p>
			<label for="<?php echo esc_attr( $layout_field_id ); ?>">
				<?php esc_html_e( 'Divi Library layout:', 'dsm-supreme-modules-pro-for-divi' ); ?>
			</label>
			<select class="widefat" id="<?php echo esc_attr( $layout_field_id ); ?>" name="<?php echo esc_attr( $layout_field_name ); ?>">
				<?php foreach ( $options as $value => $label ) : ?>
					<?php
					$opt_value = (string) $value;
					if ( 'none' === $opt_value ) {
						$compare = 'none';
					} else {
						$compare = (string) absint( $opt_value );
					}
					?>
					<option value="<?php echo esc_attr( $opt_value ); ?>" <?php selected( $compare, $selected ); ?>>
						<?php echo esc_html( (string) $label ); ?>
					</option>
				<?php endforeach; ?>
			</select>
		</p>
		<?php
	}

	/**
	 * Save widget settings.
	 *
	 * @param array<string, mixed> $new_instance New values.
	 * @param array<string, mixed> $old_instance Previous values.
	 * @return array<string, mixed>
	 */
	public function update( $new_instance, $old_instance ) {
		$old_instance = is_array( $old_instance ) ? $old_instance : array();
		$new_instance = is_array( $new_instance ) ? $new_instance : array();

		$instance = $old_instance;

		if ( isset( $new_instance['title'] ) ) {
			$instance['title'] = sanitize_text_field( (string) $new_instance['title'] );
		} else {
			$instance['title'] = '';
		}

		$layout_raw = isset( $new_instance[ self::INSTANCE_KEY_LAYOUT ] ) ? $new_instance[ self::INSTANCE_KEY_LAYOUT ] : '';

		if ( 'none' === $layout_raw || '' === (string) $layout_raw ) {
			$instance[ self::INSTANCE_KEY_LAYOUT ] = '';
		} else {
			$instance[ self::INSTANCE_KEY_LAYOUT ] = (string) absint( $layout_raw );
		}

		return $instance;
	}

	/**
	 * Raw layout selection from instance (supports legacy keys).
	 *
	 * @param array<string, mixed> $instance Widget instance.
	 * @return string
	 */
	private static function get_layout_value_from_instance( array $instance ): string {
		if ( isset( $instance[ self::INSTANCE_KEY_LAYOUT ] ) && '' !== (string) $instance[ self::INSTANCE_KEY_LAYOUT ] ) {
			return (string) $instance[ self::INSTANCE_KEY_LAYOUT ];
		}

		$legacy_keys = array( 'library', 'library_id', 'divi_library', 'dsm_layout', 'layout_id' );

		foreach ( $legacy_keys as $key ) {
			if ( isset( $instance[ $key ] ) && '' !== (string) $instance[ $key ] && 'none' !== (string) $instance[ $key ] ) {
				return (string) $instance[ $key ];
			}
		}

		return '';
	}

	/**
	 * Normalized layout post ID for rendering.
	 *
	 * @param array<string, mixed> $instance Widget instance.
	 * @return int
	 */
	private static function resolve_layout_post_id_from_instance( array $instance ): int {
		$raw = self::get_layout_value_from_instance( $instance );

		if ( 'none' === $raw || '' === $raw ) {
			return 0;
		}

		return DiviLibraryLayoutRenderer::normalize_post_id( $raw );
	}

	/**
	 * Enqueue library design CSS and Divi structural styles on the widgets screen.
	 *
	 * The legacy widget preview iframe and the block editor canvas do not load Divi's
	 * frontend dynamic CSS. `the_widget()` keeps inline `<style>` tags; this enqueue
	 * still prints the same rules in the document head so the preview stays styled
	 * when the editor does not apply style tags from the widget HTML.
	 *
	 * @return void
	 */
	public static function enqueue_admin_library_styles(): void {
		if ( self::$admin_styles_enqueued || ! self::is_widgets_screen_request() ) {
			return;
		}

		self::$admin_styles_enqueued = true;

		$settings = get_option( 'widget_dsm_widget_library' );
		if ( ! is_array( $settings ) ) {
			return;
		}

		$design = '';

		foreach ( $settings as $instance ) {
			if ( ! is_array( $instance ) ) {
				continue;
			}

			$layout_id = self::resolve_layout_post_id_from_instance( $instance );
			if ( $layout_id <= 0 ) {
				continue;
			}

			self::enqueue_structural_styles_for_layout( $layout_id );

			$html    = DiviLibraryLayoutRenderer::render_layout( $layout_id, 'dsm_widget_library' );
			$design .= self::extract_design_css_from_markup( $html, 'dsm_widget_library-' . $layout_id );
		}

		$design = wp_strip_all_tags( $design );
		if ( '' === trim( $design ) ) {
			return;
		}

		$handle = 'dsm-widget-library-design';
		if ( ! wp_style_is( $handle, 'registered' ) ) {
			wp_register_style( $handle, '', array(), '1.0.0' );
		}
		wp_enqueue_style( $handle );
		wp_add_inline_style( $handle, $design );
	}

	/**
	 * Whether the current admin request is Appearance → Widgets or its preview iframe.
	 *
	 * @return bool
	 */
	private static function is_widgets_screen_request(): bool {
		global $pagenow;
		if ( isset( $pagenow ) && 'widgets.php' === $pagenow ) {
			return true;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only WordPress core preview query flag.
		if ( isset( $_GET['legacy-widget-preview'] ) ) {
			return true;
		}

		$uri = isset( $_SERVER['REQUEST_URI'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '';
		if ( false !== strpos( $uri, '/widget-types/dsm_widget_library/render' ) ) {
			return true;
		}

		if ( defined( 'REST_REQUEST' ) && REST_REQUEST && isset( $GLOBALS['wp']->query_vars['rest_route'] ) ) {
			$route = (string) $GLOBALS['wp']->query_vars['rest_route'];
			if ( false !== strpos( $route, '/widget-types/dsm_widget_library/render' ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Link tags for structural Divi CSS when this document has not already printed them.
	 *
	 * Printed inside the widget so the REST preview, which does not run `wp_head()`,
	 * still receives row, column, blurb, and button styles.
	 *
	 * @param int $layout_id Library post ID.
	 * @return string Escaped link markup, or empty on the frontend.
	 */
	private static function admin_structural_stylesheet_markup( int $layout_id ): string {
		if ( ! self::is_widgets_screen_request() || ! class_exists( '\ET\Builder\FrontEnd\Assets\DynamicAssetsUtils' ) ) {
			return '';
		}

		$base_dir = \ET\Builder\FrontEnd\Assets\DynamicAssetsUtils::get_dynamic_assets_path( false );
		$base_url = \ET\Builder\FrontEnd\Assets\DynamicAssetsUtils::get_dynamic_assets_path( true );
		$links    = '';

		foreach ( self::structural_css_relative_paths( $layout_id ) as $relative ) {
			$path = $base_dir . $relative;
			if ( ! is_readable( $path ) ) {
				continue;
			}

			$handle = 'dsm-widget-library-' . sanitize_key( basename( $relative, '.css' ) );
			if ( wp_style_is( $handle, 'done' ) ) {
				continue;
			}

			$href = add_query_arg( 'ver', (string) filemtime( $path ), $base_url . $relative );
			// The REST widget preview does not call wp_head(), so an enqueued style never prints there.
			$links .= sprintf(
				'<link rel="%1$s" id="%2$s-css" href="%3$s" media="all" />',
				esc_attr( 'stylesheet' ),
				esc_attr( $handle ),
				esc_url( $href )
			);
		}

		return $links;
	}

	/**
	 * Enqueue structural Divi stylesheets for one library layout.
	 *
	 * @param int $layout_id Library post ID.
	 * @return void
	 */
	private static function enqueue_structural_styles_for_layout( int $layout_id ): void {
		if ( ! class_exists( '\ET\Builder\FrontEnd\Assets\DynamicAssetsUtils' ) ) {
			return;
		}

		$base_dir = \ET\Builder\FrontEnd\Assets\DynamicAssetsUtils::get_dynamic_assets_path( false );
		$base_url = \ET\Builder\FrontEnd\Assets\DynamicAssetsUtils::get_dynamic_assets_path( true );

		foreach ( self::structural_css_relative_paths( $layout_id ) as $relative ) {
			$path = $base_dir . $relative;
			if ( ! is_readable( $path ) ) {
				continue;
			}

			$handle = 'dsm-widget-library-' . sanitize_key( basename( $relative, '.css' ) );
			$url    = $base_url . $relative;

			if ( wp_style_is( $handle, 'enqueued' ) || wp_style_is( $handle, 'done' ) ) {
				continue;
			}

			wp_enqueue_style( $handle, $url, array(), (string) filemtime( $path ) );
		}
	}

	/**
	 * Dynamic-asset CSS paths required to paint a library layout outside the frontend.
	 *
	 * @param int $layout_id Library post ID.
	 * @return string[] Paths beginning with `/css/`.
	 */
	private static function structural_css_relative_paths( int $layout_id ): array {
		$paths = array(
			'/css/flex_grid.css',
			'/css/grid_items_flex.css',
			'/css/section.css',
			'/css/row.css',
		);

		$post = get_post( $layout_id );
		if ( ! $post instanceof \WP_Post || ! class_exists( '\ET\Builder\FrontEnd\Assets\DynamicAssetsUtils' ) ) {
			return $paths;
		}

		$content = (string) $post->post_content;
		if ( '' === $content ) {
			return $paths;
		}

		$specialty_suffix = ( false !== strpos( $content, 'specialty' ) ) ? '_specialty' : '';
		$assets           = \ET\Builder\FrontEnd\Assets\DynamicAssetsUtils::get_assets_list(
			array(
				'prefix'           => '',
				'suffix'           => '',
				'specialty_suffix' => $specialty_suffix,
			)
		);

		foreach ( $assets as $block_name => $asset ) {
			if ( ! is_string( $block_name ) || ! is_array( $asset ) || ! isset( $asset['css'] ) ) {
				continue;
			}
			if ( ! self::layout_content_uses_divi_block( $content, $block_name ) ) {
				continue;
			}

			$files = $asset['css'];
			if ( is_string( $files ) ) {
				$files = array( $files );
			}
			if ( ! is_array( $files ) ) {
				continue;
			}

			foreach ( $files as $file ) {
				if ( ! is_string( $file ) || 0 !== strpos( $file, '/css/' ) ) {
					continue;
				}
				$paths[] = $file;
			}
		}

		if ( false !== strpos( $content, 'font_icon' ) || false !== strpos( $content, 'et_pb_icon' ) ) {
			$paths[] = '/css/icons_base.css';
			$paths[] = '/css/icons_all.css';
		}

		return array_values( array_unique( $paths ) );
	}

	/**
	 * Whether serialized layout content uses a Divi block or its legacy shortcode.
	 *
	 * @param string $content    Layout `post_content`.
	 * @param string $block_name Block name such as `divi/blurb`.
	 * @return bool
	 */
	private static function layout_content_uses_divi_block( string $content, string $block_name ): bool {
		if ( false !== strpos( $content, 'wp:' . $block_name ) ) {
			return true;
		}

		if ( 0 !== strpos( $block_name, 'divi/' ) ) {
			return false;
		}

		$tag = 'et_pb_' . str_replace( '-', '_', substr( $block_name, 5 ) );

		return false !== strpos( $content, '[' . $tag );
	}

	/**
	 * CSS text from a captured library `<style id="...">` tag.
	 *
	 * @param string $html     Rendered layout HTML.
	 * @param string $style_id Style element id.
	 * @return string
	 */
	private static function extract_design_css_from_markup( string $html, string $style_id ): string {
		$pattern = '/<style\b[^>]*\bid="' . preg_quote( $style_id, '/' ) . '"[^>]*>(.*?)<\/style>/s';
		if ( ! preg_match( $pattern, $html, $matches ) ) {
			return '';
		}

		return wp_strip_all_tags( $matches[1] );
	}
}
