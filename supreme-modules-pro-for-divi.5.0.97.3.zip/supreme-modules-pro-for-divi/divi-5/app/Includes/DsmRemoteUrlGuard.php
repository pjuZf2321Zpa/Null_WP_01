<?php
/**
 * Hardened remote HTTPS URL validation and fetch (SSRF-safe).
 *
 * Used by Chart CSV preview proxy and reusable for other VB remote imports.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Includes;

use WP_Error;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Validates and fetches remote HTTPS text resources with SSRF hardening.
 */
class DsmRemoteUrlGuard {

	/**
	 * Default max redirects (final hop re-validated).
	 *
	 * @var int
	 */
	private const DEFAULT_MAX_REDIRECTS = 1;

	/**
	 * Default request timeout in seconds.
	 *
	 * @var int
	 */
	private const DEFAULT_TIMEOUT = 15;

	/**
	 * Default max body bytes (512 KiB).
	 *
	 * @var int
	 */
	private const DEFAULT_MAX_BYTES = 524288;

	/**
	 * Validate a candidate remote URL before any network I/O.
	 *
	 * @param string $url Raw URL.
	 * @return string|WP_Error Sanitized HTTPS URL, or error.
	 */
	public static function validate_url( string $url ) {
		$url = trim( $url );
		if ( '' === $url ) {
			return new WP_Error(
				'dsm_remote_url_empty',
				__( 'Please enter a URL.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 400 )
			);
		}

		$sanitized = esc_url_raw( $url, array( 'https' ) );
		if ( '' === $sanitized ) {
			return new WP_Error(
				'dsm_remote_url_invalid',
				__( 'Invalid URL. HTTPS is required.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 400 )
			);
		}

		if ( function_exists( 'wp_http_validate_url' ) && ! wp_http_validate_url( $sanitized ) ) {
			return new WP_Error(
				'dsm_remote_url_rejected',
				__( 'This URL is not allowed.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 400 )
			);
		}

		$parts = wp_parse_url( $sanitized );
		if ( ! is_array( $parts ) ) {
			return new WP_Error(
				'dsm_remote_url_parse',
				__( 'Could not parse the URL.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 400 )
			);
		}

		$scheme = isset( $parts['scheme'] ) ? strtolower( (string) $parts['scheme'] ) : '';
		if ( 'https' !== $scheme ) {
			return new WP_Error(
				'dsm_remote_url_scheme',
				__( 'Only HTTPS URLs are allowed.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 400 )
			);
		}

		if ( isset( $parts['user'] ) || isset( $parts['pass'] ) ) {
			return new WP_Error(
				'dsm_remote_url_credentials',
				__( 'URLs with credentials are not allowed.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 400 )
			);
		}

		$host = isset( $parts['host'] ) ? strtolower( (string) $parts['host'] ) : '';
		if ( '' === $host ) {
			return new WP_Error(
				'dsm_remote_url_host',
				__( 'URL host is missing.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 400 )
			);
		}

		$host_check = self::validate_host( $host );
		if ( is_wp_error( $host_check ) ) {
			return $host_check;
		}

		/**
		 * Filter the sanitized HTTPS URL after structural validation.
		 *
		 * @param string $sanitized Sanitized URL.
		 * @param string $url       Original input.
		 */
		$filtered = apply_filters( 'dsm_remote_url_guard_url', $sanitized, $url );
		if ( ! is_string( $filtered ) || '' === $filtered ) {
			return new WP_Error(
				'dsm_remote_url_filtered',
				__( 'This URL is not allowed.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 400 )
			);
		}

		return $filtered;
	}

	/**
	 * Validate host name / literal IP (block private, loopback, link-local, metadata).
	 *
	 * @param string $host Hostname or IP (lowercase preferred).
	 * @return true|WP_Error
	 */
	public static function validate_host( string $host ) {
		$host = strtolower( trim( $host ) );
		$host = trim( $host, '[]' );

		if ( '' === $host ) {
			return new WP_Error(
				'dsm_remote_url_host',
				__( 'URL host is missing.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 400 )
			);
		}

		$blocked_hosts = array( 'localhost', 'metadata', 'metadata.google.internal' );
		/**
		 * Filter blocked hostnames (exact match, lowercase).
		 *
		 * @param string[] $blocked_hosts Hostnames.
		 */
		$blocked_hosts = apply_filters( 'dsm_remote_url_blocked_hosts', $blocked_hosts );
		if ( is_array( $blocked_hosts ) && in_array( $host, $blocked_hosts, true ) ) {
			return new WP_Error(
				'dsm_remote_url_blocked_host',
				__( 'This host is not allowed.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 400 )
			);
		}

		if ( self::is_blocked_ip( $host ) ) {
			return new WP_Error(
				'dsm_remote_url_blocked_ip',
				__( 'Private or local network addresses are not allowed.', 'dsm-supreme-modules-pro-for-divi' ),
				array( 'status' => 400 )
			);
		}

		// Hostname: resolve and reject if any address is private/reserved.
		if ( ! self::is_ip_literal( $host ) ) {
			$ips = self::resolve_host_ips( $host );
			if ( empty( $ips ) ) {
				return new WP_Error(
					'dsm_remote_url_dns',
					__( 'Could not resolve the URL host.', 'dsm-supreme-modules-pro-for-divi' ),
					array( 'status' => 400 )
				);
			}
			foreach ( $ips as $ip ) {
				if ( self::is_blocked_ip( $ip ) ) {
					return new WP_Error(
						'dsm_remote_url_blocked_ip',
						__( 'Private or local network addresses are not allowed.', 'dsm-supreme-modules-pro-for-divi' ),
						array( 'status' => 400 )
					);
				}
			}
		}

		return true;
	}

	/**
	 * Whether a string is an IPv4/IPv6 literal.
	 *
	 * @param string $value Candidate.
	 * @return bool
	 */
	public static function is_ip_literal( string $value ): bool {
		return false !== filter_var( $value, FILTER_VALIDATE_IP );
	}

	/**
	 * Whether an IP is private, loopback, link-local, or otherwise blocked.
	 *
	 * @param string $ip IP address.
	 * @return bool
	 */
	public static function is_blocked_ip( string $ip ): bool {
		$ip = trim( $ip );
		if ( '' === $ip ) {
			return true;
		}

		if ( false === filter_var( $ip, FILTER_VALIDATE_IP ) ) {
			return false;
		}

		// Reject private + reserved (includes 169.254/16 metadata / link-local).
		$blocked = false === filter_var(
			$ip,
			FILTER_VALIDATE_IP,
			FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE
		);

		// Extra explicit blocks (defense in depth).
		$extra = array( '0.0.0.0', '::', '::1' );
		if ( in_array( $ip, $extra, true ) ) {
			$blocked = true;
		}

		/**
		 * Filter whether a resolved IP should be blocked.
		 *
		 * @param bool   $blocked Default from built-in checks.
		 * @param string $ip      IP address.
		 */
		return (bool) apply_filters( 'dsm_remote_url_is_blocked_ip', $blocked, $ip );
	}

	/**
	 * Resolve A/AAAA records for a hostname.
	 *
	 * @param string $host Hostname.
	 * @return string[] IP addresses.
	 */
	public static function resolve_host_ips( string $host ): array {
		$ips = array();

		if ( function_exists( 'dns_get_record' ) ) {
			$type = defined( 'DNS_AAAA' ) ? DNS_A + DNS_AAAA : DNS_A;
			// phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- DNS may warn on NXDOMAIN.
			$records = @dns_get_record( $host, $type );
			if ( is_array( $records ) ) {
				foreach ( $records as $record ) {
					if ( ! is_array( $record ) ) {
						continue;
					}
					if ( ! empty( $record['ip'] ) && is_string( $record['ip'] ) ) {
						$ips[] = $record['ip'];
					}
					if ( ! empty( $record['ipv6'] ) && is_string( $record['ipv6'] ) ) {
						$ips[] = $record['ipv6'];
					}
				}
			}
		}

		if ( empty( $ips ) && function_exists( 'gethostbynamel' ) ) {
			// phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			$v4 = @gethostbynamel( $host );
			if ( is_array( $v4 ) ) {
				foreach ( $v4 as $ip ) {
					if ( is_string( $ip ) && '' !== $ip ) {
						$ips[] = $ip;
					}
				}
			}
		}

		return array_values( array_unique( $ips ) );
	}

	/**
	 * Fetch remote text with validation, redirect re-check, and byte cap.
	 *
	 * @param string               $url  Candidate URL.
	 * @param array<string, mixed> $args Optional overrides: max_bytes, timeout, max_redirects, user_agent.
	 * @return array{body: string, url: string, bytes: int}|WP_Error
	 */
	public static function fetch_text( string $url, array $args = array() ) {
		$sanitized = self::validate_url( $url );
		if ( is_wp_error( $sanitized ) ) {
			return $sanitized;
		}
		$max_bytes = isset( $args['max_bytes'] ) ? (int) $args['max_bytes'] : self::DEFAULT_MAX_BYTES;
		/**
		 * Filter max remote body bytes.
		 *
		 * @param int    $max_bytes Max bytes.
		 * @param string $sanitized URL.
		 */
		$max_bytes = (int) apply_filters( 'dsm_remote_url_max_bytes', $max_bytes, $sanitized );
		if ( $max_bytes < 1024 ) {
			$max_bytes = 1024;
		}

		$timeout = isset( $args['timeout'] ) ? (int) $args['timeout'] : self::DEFAULT_TIMEOUT;
		/**
		 * Filter remote fetch timeout (seconds).
		 *
		 * @param int    $timeout   Seconds.
		 * @param string $sanitized URL.
		 */
		$timeout = (int) apply_filters( 'dsm_remote_url_timeout', $timeout, $sanitized );
		if ( $timeout < 1 ) {
			$timeout = 1;
		}

		$max_redirects = isset( $args['max_redirects'] ) ? (int) $args['max_redirects'] : self::DEFAULT_MAX_REDIRECTS;
		/**
		 * Filter max redirects (each hop re-validated).
		 *
		 * @param int    $max_redirects Max hops.
		 * @param string $sanitized     URL.
		 */
		$max_redirects = (int) apply_filters( 'dsm_remote_url_max_redirects', $max_redirects, $sanitized );
		if ( $max_redirects < 0 ) {
			$max_redirects = 0;
		}
		if ( $max_redirects > 3 ) {
			$max_redirects = 3;
		}

			$user_agent = isset( $args['user_agent'] ) && is_string( $args['user_agent'] )
				? $args['user_agent']
				: 'DiviSupreme/' . ( defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0' );

			$accept = isset( $args['accept'] ) && is_string( $args['accept'] ) && '' !== trim( $args['accept'] )
				? trim( $args['accept'] )
				: 'text/csv,text/plain,*/*;q=0.1';

		$current   = $sanitized;
		$redirects = 0;

		while ( true ) {
			$hop = self::validate_url( $current );
			if ( is_wp_error( $hop ) ) {
				return $hop;
			}
			$current = $hop;

			$response = wp_remote_get(
				$current,
				array(
					'timeout'     => $timeout,
					'redirection' => 0,
					'sslverify'   => true,
					'user-agent'  => $user_agent,
					'headers'     => array(
						'Accept' => $accept,
					),
				)
			);

			if ( is_wp_error( $response ) ) {
				return new WP_Error(
					'dsm_remote_url_http',
					__( 'Could not fetch the remote file.', 'dsm-supreme-modules-pro-for-divi' ),
					array( 'status' => 502 )
				);
			}

			$code = (int) wp_remote_retrieve_response_code( $response );
			if ( $code >= 300 && $code < 400 ) {
				if ( $redirects >= $max_redirects ) {
					return new WP_Error(
						'dsm_remote_url_redirects',
						__( 'Too many redirects from the remote URL.', 'dsm-supreme-modules-pro-for-divi' ),
						array( 'status' => 400 )
					);
				}
				$location = (string) wp_remote_retrieve_header( $response, 'location' );
				$location = trim( $location );
				if ( '' === $location ) {
					return new WP_Error(
						'dsm_remote_url_redirect_missing',
						__( 'Remote URL redirected without a Location header.', 'dsm-supreme-modules-pro-for-divi' ),
						array( 'status' => 400 )
					);
				}
				// Resolve relative Location against current URL.
				if ( 0 !== strpos( $location, 'http://' ) && 0 !== strpos( $location, 'https://' ) ) {
					$base     = $current;
					$location = self::resolve_relative_url( $base, $location );
				}
				$current = esc_url_raw( $location, array( 'https' ) );
				if ( '' === $current ) {
					return new WP_Error(
						'dsm_remote_url_redirect_scheme',
						__( 'Redirect target must be HTTPS.', 'dsm-supreme-modules-pro-for-divi' ),
						array( 'status' => 400 )
					);
				}
				++$redirects;
				continue;
			}

			if ( $code < 200 || $code >= 300 ) {
				return new WP_Error(
					'dsm_remote_url_status',
					sprintf(
						/* translators: %d: HTTP status code */
						__( 'Remote URL returned HTTP %d.', 'dsm-supreme-modules-pro-for-divi' ),
						$code
					),
					array( 'status' => 400 )
				);
			}

			$content_length = (string) wp_remote_retrieve_header( $response, 'content-length' );
			if ( '' !== $content_length && (int) $content_length > $max_bytes ) {
				return new WP_Error(
					'dsm_remote_url_too_large',
					__( 'Remote file is too large.', 'dsm-supreme-modules-pro-for-divi' ),
					array( 'status' => 400 )
				);
			}

			$body = wp_remote_retrieve_body( $response );
			if ( ! is_string( $body ) ) {
				$body = '';
			}

			if ( strlen( $body ) > $max_bytes ) {
				return new WP_Error(
					'dsm_remote_url_too_large',
					__( 'Remote file is too large.', 'dsm-supreme-modules-pro-for-divi' ),
					array( 'status' => 400 )
				);
			}

			$body = self::strip_utf8_bom( $body );

			if ( self::looks_like_html_login( $body ) ) {
				return new WP_Error(
					'dsm_remote_url_html',
					__( 'Remote URL returned a web page instead of CSV. For Google Sheets, use File → Share → Publish to web (CSV).', 'dsm-supreme-modules-pro-for-divi' ),
					array( 'status' => 400 )
				);
			}

			if ( '' === trim( $body ) ) {
				return new WP_Error(
					'dsm_remote_url_empty_body',
					__( 'Remote file was empty.', 'dsm-supreme-modules-pro-for-divi' ),
					array( 'status' => 400 )
				);
			}

			return array(
				'body'  => $body,
				'url'   => $current,
				'bytes' => strlen( $body ),
			);
		}
	}

	/**
	 * Strip UTF-8 BOM if present.
	 *
	 * @param string $body Raw body.
	 * @return string
	 */
	public static function strip_utf8_bom( string $body ): string {
		if ( str_starts_with( $body, "\xEF\xBB\xBF" ) ) {
			return substr( $body, 3 );
		}

		return $body;
	}

	/**
	 * Detect HTML / login pages returned instead of CSV.
	 *
	 * @param string $body Body sample.
	 * @return bool
	 */
	public static function looks_like_html_login( string $body ): bool {
		$sample = strtolower( ltrim( substr( $body, 0, 2048 ) ) );
		if ( '' === $sample ) {
			return false;
		}

		if ( str_starts_with( $sample, '<!doctype html' ) || str_starts_with( $sample, '<html' ) ) {
			return true;
		}

		if ( false !== strpos( $sample, '<html' ) && ( false !== strpos( $sample, '<body' ) || false !== strpos( $sample, 'sign in' ) ) ) {
			return true;
		}

		return false;
	}

	/**
	 * Resolve a relative redirect Location against an absolute base URL.
	 *
	 * @param string $base     Absolute HTTPS URL.
	 * @param string $relative Relative or absolute path.
	 * @return string Absolute URL or empty.
	 */
	private static function resolve_relative_url( string $base, string $relative ): string {
		$relative = trim( $relative );
		if ( '' === $relative ) {
			return '';
		}
		if ( 0 === strpos( $relative, '//' ) ) {
			return 'https:' . $relative;
		}

		$parts = wp_parse_url( $base );
		if ( ! is_array( $parts ) || empty( $parts['host'] ) ) {
			return '';
		}

		$scheme = isset( $parts['scheme'] ) ? (string) $parts['scheme'] : 'https';
		$host   = (string) $parts['host'];
		$port   = isset( $parts['port'] ) ? ':' . (int) $parts['port'] : '';

		if ( str_starts_with( $relative, '/' ) ) {
			return $scheme . '://' . $host . $port . $relative;
		}

		$path = isset( $parts['path'] ) ? (string) $parts['path'] : '/';
		$dir  = preg_replace( '#/[^/]*$#', '/', $path );
		if ( ! is_string( $dir ) || '' === $dir ) {
			$dir = '/';
		}

		return $scheme . '://' . $host . $port . $dir . $relative;
	}
}
