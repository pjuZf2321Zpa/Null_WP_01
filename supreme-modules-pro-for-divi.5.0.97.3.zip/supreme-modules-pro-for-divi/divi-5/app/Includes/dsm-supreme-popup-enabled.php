<?php
/**
 * Whether the Supreme Popup extension is enabled (General settings).
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * True when Divi Supreme → General → Enable Divi Popup is on (default matches Settings default: on).
 *
 * @return bool
 */
function dsm_is_supreme_popup_extension_enabled(): bool {
	$general = get_option( 'dsm_general', array() );

	if ( ! is_array( $general ) ) {
		return true;
	}

	if ( ! array_key_exists( 'dsm_use_supreme_popup', $general ) ) {
		return true;
	}

	return 'on' === $general['dsm_use_supreme_popup'];
}
