<?php
/**
 * Divi static cache option helpers.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Dsm get misc settings option.
 *
 * @return array<string, mixed>
 */
function dsm_get_misc_settings_option(): array {
	$misc = get_option( 'dsm_settings_misc', array() );

	return is_array( $misc ) ? $misc : array();
}

/**
 * Dsm auto clear divi cache on update enabled.
 *
 * @return bool
 */
function dsm_auto_clear_divi_cache_on_update_enabled(): bool {
	$misc = dsm_get_misc_settings_option();

	return 'on' === ( $misc['dsm_auto_clear_divi_cache_on_update'] ?? 'on' );
}

/**
 * Dsm show clear divi cache admin bar enabled.
 *
 * @return bool
 */
function dsm_show_clear_divi_cache_admin_bar_enabled(): bool {
	$misc = dsm_get_misc_settings_option();

	return 'on' === ( $misc['dsm_show_clear_divi_cache_admin_bar'] ?? 'on' );
}
