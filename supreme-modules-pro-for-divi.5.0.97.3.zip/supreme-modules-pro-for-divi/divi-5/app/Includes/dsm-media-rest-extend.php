<?php
/**
 * REST extensions for the WordPress media (attachment) endpoint.
 *
 * Attachment categories use the shared `dsm-attachment-category` taxonomy
 * (see dsm-attachment-taxonomy.php) — not a separate media taxonomy.
 *
 * @package DiviSupreme
 */

/**
 * Extends the WordPress REST API media endpoint to include custom fields, including attachment categories.
 *
 * @return void
 */
function dsm_add_custom_fields_to_media_endpoint() {
	register_rest_field(
		'attachment',
		'custom_fields',
		array(
			'get_callback'    => function ( $post_arr ) {
				$post = get_post( $post_arr['id'] );

				$attachment_categories = wp_get_object_terms(
					$post_arr['id'],
					'dsm-attachment-category'
				);
				$categories            = array();

				if ( ! is_wp_error( $attachment_categories ) ) {
					foreach ( $attachment_categories as $category ) {
						$categories[] = array(
							'id'   => $category->term_id,
							'name' => $category->name,
							'slug' => $category->slug,
						);
					}
				}

				return array(
					'description'   => $post ? $post->post_content : '',
					'caption'       => $post ? $post->post_excerpt : '',
					'alt_text'      => get_post_meta( $post_arr['id'], '_wp_attachment_image_alt', true ),
					'media_type'    => wp_attachment_is_image( $post_arr['id'] ) ? 'image' : 'file',
					'media_details' => wp_get_attachment_metadata( $post_arr['id'] ),
					'categories'    => $categories,
				);
			},
			'update_callback' => null,
			'schema'          => null,
		)
	);
}
add_action( 'rest_api_init', 'dsm_add_custom_fields_to_media_endpoint' );

/**
 * Modifies the query arguments for the media endpoint to handle custom sorting.
 *
 * @param array           $args    Query arguments.
 * @param WP_REST_Request $request REST request.
 * @return array
 */
function dsm_custom_media_query_args( $args, $request ) {
	$order   = $request->get_param( 'order' );
	$orderby = $request->get_param( 'orderby' );

	if ( $order ) {
		$args['order'] = $order;
	}

	if ( $orderby ) {
		switch ( $orderby ) {
			case 'date':
				$args['orderby'] = 'date';
				break;
			case 'title':
				$args['orderby'] = 'title';
				break;
			default:
				$args['orderby'] = 'date';
		}
	}

	return $args;
}
add_filter( 'rest_attachment_query', 'dsm_custom_media_query_args', 10, 2 );

/**
 * One-time removal of the legacy duplicate `media_category` taxonomy (Divi 5 early builds).
 *
 * @global \wpdb $wpdb WordPress database abstraction object.
 * @return void
 */
function dsm_remove_legacy_media_category_taxonomy(): void {
	if ( get_option( 'dsm_legacy_media_category_removed', false ) ) {
		return;
	}

	global $wpdb;

	$taxonomy = 'media_category';

	$term_taxonomy_ids = $wpdb->get_col(
		$wpdb->prepare(
			"SELECT term_taxonomy_id FROM {$wpdb->term_taxonomy} WHERE taxonomy = %s",
			$taxonomy
		)
	);

	if ( is_array( $term_taxonomy_ids ) && array() !== $term_taxonomy_ids ) {
		$ids_sql = implode( ',', array_map( 'absint', $term_taxonomy_ids ) );
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- IDs built from absint list.
		$wpdb->query( "DELETE FROM {$wpdb->term_relationships} WHERE term_taxonomy_id IN ({$ids_sql})" );

		$term_ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT DISTINCT term_id FROM {$wpdb->term_taxonomy} WHERE taxonomy = %s",
				$taxonomy
			)
		);

		$wpdb->delete( $wpdb->term_taxonomy, array( 'taxonomy' => $taxonomy ), array( '%s' ) );

		if ( is_array( $term_ids ) ) {
			foreach ( $term_ids as $term_id ) {
				$term_id = (int) $term_id;
				if ( $term_id <= 0 ) {
					continue;
				}
				$remaining = (int) $wpdb->get_var(
					$wpdb->prepare(
						"SELECT COUNT(*) FROM {$wpdb->term_taxonomy} WHERE term_id = %d",
						$term_id
					)
				);
				if ( 0 === $remaining ) {
					$wpdb->delete( $wpdb->terms, array( 'term_id' => $term_id ), array( '%d' ) );
				}
			}
		}
	}

	update_option( 'dsm_legacy_media_category_removed', true, true );
}

/**
 * Run legacy taxonomy cleanup after plugin update in wp-admin (same one-time migration as admin_init).
 *
 * @param \WP_Upgrader $upgrader   Upgrader instance.
 * @param array        $hook_extra Extra arguments passed to hooked filters.
 * @return void
 */
function dsm_remove_legacy_media_category_taxonomy_on_upgrader( $upgrader, array $hook_extra ): void {
	unset( $upgrader );

	if (
		! isset( $hook_extra['action'], $hook_extra['type'] )
		|| 'update' !== $hook_extra['action']
		|| 'plugin' !== $hook_extra['type']
	) {
		return;
	}

	if ( ! defined( 'DSM_DIR_PATH' ) ) {
		return;
	}

	$plugin_basenames = array();

	if ( isset( $hook_extra['plugins'] ) && is_array( $hook_extra['plugins'] ) ) {
		$plugin_basenames = array_merge( $plugin_basenames, $hook_extra['plugins'] );
	}

	if ( isset( $hook_extra['plugin'] ) && is_string( $hook_extra['plugin'] ) ) {
		$plugin_basenames[] = $hook_extra['plugin'];
	}

	if ( array() === $plugin_basenames ) {
		return;
	}

	$our_plugin = plugin_basename( DSM_DIR_PATH . 'supreme-modules-pro-for-divi.php' );

	foreach ( $plugin_basenames as $plugin_basename ) {
		if ( is_string( $plugin_basename ) && $plugin_basename === $our_plugin ) {
			dsm_remove_legacy_media_category_taxonomy();
			break;
		}
	}
}

add_action( 'admin_init', 'dsm_remove_legacy_media_category_taxonomy', 100 );
add_action( 'upgrader_process_complete', 'dsm_remove_legacy_media_category_taxonomy_on_upgrader', 10, 2 );
