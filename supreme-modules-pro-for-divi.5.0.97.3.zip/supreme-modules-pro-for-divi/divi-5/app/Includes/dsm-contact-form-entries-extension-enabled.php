<?php
/**
 * Whether the Contact Form Pro extension is enabled.
 *
 * Opt-in: disabled unless the user turns on Contact Form Pro under
 * Divi Supreme → Extensions.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * True when Divi Supreme → Extensions → Contact Form Pro is on (default: off).
 *
 * When enabled, native Divi Contact Form submissions are stored and listed under
 * Divi Supreme → Form Entries.
 *
 * @return bool
 */
function dsm_is_contact_form_entries_extension_enabled(): bool {
	$general = get_option( 'dsm_general', array() );

	if ( ! is_array( $general ) ) {
		return false;
	}

	if ( ! array_key_exists( 'dsm_use_contact_form_entries', $general ) ) {
		return false;
	}

	return 'on' === $general['dsm_use_contact_form_entries'];
}
