<?php
/**
 * PSR-4 autoloader for DiviSupreme\* → app/ (no Composer vendor required in production).
 *
 * Resolves case-insensitive directory/file segments so Linux matches macOS for legacy
 * paths such as `Extensions\` → `app/extensions/` and `SettingsAPI` → `SettingsApi.php`.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Normalize a path segment for fuzzy filename matching (case + separators).
 *
 * Maps `DsmCssPreviewScope.php` and `dsm-css-preview-scope.php` to the same key.
 *
 * @param string $segment Directory or filename segment (may include `.php`).
 * @return string
 */
function dsm_autoload_normalize_segment( string $segment ): string {
	$without_ext = preg_replace( '/\.php$/i', '', $segment );
	if ( ! is_string( $without_ext ) ) {
		$without_ext = $segment;
	}

	$alnum = preg_replace( '/[^a-z0-9]/i', '', $without_ext );
	if ( ! is_string( $alnum ) ) {
		return strtolower( $segment );
	}

	return strtolower( $alnum );
}

/**
 * Resolve a relative path under $base when filesystem case may not match PSR-4.
 *
 * Handles legacy mismatches such as `Extensions\` → `app/extensions/`,
 * `SettingsAPI` → `SettingsApi.php`, and kebab Includes like
 * `DsmCssPreviewScope` → `dsm-css-preview-scope.php`.
 *
 * @param string $base          Absolute base directory (app/).
 * @param string $relative_path Relative path using `/` (e.g. Extensions/Foo.php).
 * @return string|null Absolute readable path or null.
 */
function dsm_autoload_resolve_path( string $base, string $relative_path ): ?string {
	$exact = $base . '/' . $relative_path;
	if ( is_readable( $exact ) ) {
		return $exact;
	}

	$parts  = explode( '/', $relative_path );
	$cursor = $base;

	foreach ( $parts as $index => $part ) {
		if ( '' === $part ) {
			continue;
		}

		$candidate = $cursor . '/' . $part;
		$is_last   = ( count( $parts ) - 1 === $index );

		if ( $is_last ) {
			if ( is_readable( $candidate ) ) {
				return $candidate;
			}

			if ( ! is_dir( $cursor ) ) {
				return null;
			}

			$part_lower = strtolower( $part );
			$part_norm  = dsm_autoload_normalize_segment( $part );
			$matches    = scandir( $cursor );
			if ( ! is_array( $matches ) ) {
				return null;
			}

			$normalized_hit = null;
			foreach ( $matches as $entry ) {
				if ( '.' === $entry || '..' === $entry ) {
					continue;
				}
				$full = $cursor . '/' . $entry;
				if ( ! is_readable( $full ) ) {
					continue;
				}
				if ( strtolower( $entry ) === $part_lower ) {
					return $full;
				}
				if ( null === $normalized_hit && dsm_autoload_normalize_segment( $entry ) === $part_norm ) {
					$normalized_hit = $full;
				}
			}

			return $normalized_hit;
		}

		if ( is_dir( $candidate ) ) {
			$cursor = $candidate;
			continue;
		}

		if ( ! is_dir( $cursor ) ) {
			return null;
		}

		$part_lower = strtolower( $part );
		$part_norm  = dsm_autoload_normalize_segment( $part );
		$matches    = scandir( $cursor );
		if ( ! is_array( $matches ) ) {
			return null;
		}

		$found            = null;
		$normalized_found = null;
		foreach ( $matches as $entry ) {
			if ( '.' === $entry || '..' === $entry ) {
				continue;
			}
			if ( ! is_dir( $cursor . '/' . $entry ) ) {
				continue;
			}
			if ( strtolower( $entry ) === $part_lower ) {
				$found = $cursor . '/' . $entry;
				break;
			}
			if ( null === $normalized_found && dsm_autoload_normalize_segment( $entry ) === $part_norm ) {
				$normalized_found = $cursor . '/' . $entry;
			}
		}

		if ( null === $found ) {
			$found = $normalized_found;
		}

		if ( null === $found ) {
			return null;
		}

		$cursor = $found;
	}

	return null;
}

spl_autoload_register(
	static function ( string $class ): void {
		$prefix = 'DiviSupreme\\';
		$len    = strlen( $prefix );
		if ( strncmp( $prefix, $class, $len ) !== 0 ) {
			return;
		}

		$relative      = substr( $class, $len );
		$relative_path = str_replace( '\\', '/', $relative ) . '.php';
		$file          = dsm_autoload_resolve_path( __DIR__, $relative_path );

		if ( null !== $file ) {
			require_once $file;
		}
	}
);
