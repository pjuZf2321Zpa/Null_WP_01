<?php
/**
 * Mask & Pattern Library settings rows and dashboard catalog payload.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Core;

use DiviSupreme\Extensions\MaskPatternLibrary\MaskPatternRegistry;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Per-item checkbox rows for `dsm_mask_pattern_library` (consumed by React preview panel).
 */
final class MaskPatternLibraryDashboardRows {

	/**
	 * Checkbox rows saved to `dsm_mask_pattern_library` (one per mask/pattern slug).
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public static function build_settings_fields(): array {
		if (
			! function_exists( 'dsm_is_mask_pattern_library_extension_enabled' )
			|| ! dsm_is_mask_pattern_library_extension_enabled()
		) {
			return array();
		}

		$fields = array();

		foreach ( MaskPatternRegistry::get_mask_slugs() as $slug ) {
			$fields[] = self::build_item_checkbox_field( $slug );
		}

		foreach ( MaskPatternRegistry::get_pattern_slugs() as $slug ) {
			$fields[] = self::build_item_checkbox_field( $slug );
		}

		return $fields;
	}

	/**
	 * Thumbnail catalog for the settings dashboard React preview grid.
	 *
	 * @return array{masks: array<int, array<string, string>>, patterns: array<int, array<string, string>>}
	 */
	public static function build_dashboard_catalog(): array {
		return MaskPatternRegistry::get_dashboard_catalog();
	}

	/**
	 * Build item checkbox field.
	 *
	 * @param string $slug Mask or pattern slug.
	 * @return array<string, mixed>
	 */
	private static function build_item_checkbox_field( string $slug ): array {
		return array(
			'name'    => $slug,
			'type'    => 'checkbox',
			'default' => 'on',
			'class'   => 'dsm-mask-pattern-library-item-field',
		);
	}
}
