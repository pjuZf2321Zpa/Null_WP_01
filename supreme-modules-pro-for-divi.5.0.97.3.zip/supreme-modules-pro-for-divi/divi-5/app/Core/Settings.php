<?php
/**
 * Admin settings.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Core;

use DiviSupreme\Core\License;
use DiviSupreme\Core\SettingsAPI;

/**
 * Divi Supreme settings screen.
 */
class Settings {


	/**
	 * Settings api instance.
	 *
	 * @var SettingsAPI $settings_api Settings API instance.
	 */
	private $settings_api;

	/**
	 * License instance (standard distribution only; null on marketplace builds).
	 *
	 * @var License|null
	 */
	public $license;

	/**
	 * Constructor.
	 *
	 * @return void
	 */
	public function __construct() {

		$this->settings_api = new SettingsAPI();
		$this->license      = null;

		if ( ! $this->dsm_settings_is_marketplace_build() ) {
			add_action( 'admin_init', array( $this, 'dsm_bootstrap_license' ), 5 );
			add_action( 'admin_notices', array( $this, 'dsm_render_missing_license_notice' ) );
		}

		add_action( 'admin_menu', array( $this, 'admin_menu' ) );
		add_action( 'admin_init', array( $this, 'admin_init' ) );
		add_action( 'wp_ajax_dsm_save_settings', array( $this, 'dsm_ajax_save_settings' ) );
		add_action( 'wp_ajax_dsm_get_dashboard_section_fields', array( $this, 'dsm_ajax_get_dashboard_section_fields' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ), 100 );

		$this->dsm_register_plugins_screen_links();

		add_filter( 'upload_mimes', array( $this, 'allow_svg_mime_types' ) );
		add_filter( 'wp_handle_upload_prefilter', array( $this, 'sanitize_svg_upload_prefilter' ), 10, 1 );
		add_filter( 'wp_handle_sideload_prefilter', array( $this, 'sanitize_svg_upload_prefilter' ), 10, 1 );
		add_filter( 'wp_check_filetype_and_ext', array( $this, 'fix_svg_filetype' ), 10, 4 );

		add_filter( 'upload_mimes', array( $this, 'allow_json_mime_types' ) );
		add_filter( 'wp_check_filetype_and_ext', array( $this, 'fix_json_filetype' ), 10, 4 );

		add_filter( 'wp_check_filetype_and_ext', array( $this, 'fix_lottie_filetype' ), 10, 4 );

		// Hook to inspect POST right when options.php processes.
		add_action(
			'admin_notices',
			function () {
				// Check for successful settings update redirect from options.php.
            // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only GET after options.php save redirect; manage_options verified below.
				if (
				isset( $_GET['settings-updated'] ) && 'true' === $_GET['settings-updated'] &&
				isset( $_GET['page'] ) && 'divi_supreme_settings' === $_GET['page'] &&
				current_user_can( 'manage_options' )
				) {
					// phpcs:enable WordPress.Security.NonceVerification.Recommended
					?>
				<div class="notice notice-success is-dismissible">
					<p>
						<?php esc_html_e( 'Settings saved successfully.', 'dsm-supreme-modules-pro-for-divi' ); ?>
					</p>
				</div>
					<?php
				}
			}
		);
	}

	/**
	 * Quick-action cards shown on the settings dashboard.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public function get_settings() {
		return array(
			array(
				'icon'        => Assets::getAssetPath( 'dashboard/settings/documentation.svg' ),
				'title'       => __( 'Documentation', 'dsm-supreme-modules-pro-for-divi' ),
				'description' => __( 'Get started by spending some time with the documentation to get familiar with Divi Supreme Pro. The Documentation will cover all the information needed when using our Divi Supreme to build an amazing website, as well as some helpful tips and tricks that will make your experience working with our Divi modules and extensions easier and more enjoyable.', 'dsm-supreme-modules-pro-for-divi' ),
				'actions'     => array(
					array(
						'type'   => 'link',
						'class'  => 'button button-primary',
						'href'   => 'https://docs.divisupreme.com/',
						'target' => '_blank',
						'text'   => __( 'Documentation', 'dsm-supreme-modules-pro-for-divi' ),
					),
				),
			),
			array(
				'icon'        => Assets::getAssetPath( 'dashboard/settings/help.svg' ),
				'title'       => __( 'Need Help?', 'dsm-supreme-modules-pro-for-divi' ),
				'description' => __( 'Having issues or difficulties? Get help from the community on our Facebook Divi Supreme Community or contact us through our website contact form.', 'dsm-supreme-modules-pro-for-divi' ),
				'actions'     => array(
					array(
						'type'   => 'link',
						'class'  => 'button button-primary',
						'href'   => 'https://www.facebook.com/groups/261974664518981/',
						'target' => '_blank',
						'text'   => __( 'Join Divi Supreme Community', 'dsm-supreme-modules-pro-for-divi' ),
					),
					array(
						'type'   => 'link',
						'class'  => 'button button-primary',
						'href'   => 'https://divisupreme.com/contact/',
						'target' => '_blank',
						'text'   => __( 'Contact Support', 'dsm-supreme-modules-pro-for-divi' ),
					),
				),
			),
			array(
				'icon'        => Assets::getAssetPath( 'dashboard/settings/support.svg' ),
				'title'       => __( 'Motivate us!', 'dsm-supreme-modules-pro-for-divi' ),
				'description' => __( 'Could you please do us a BIG favor and leave us a review on Trustpilot? This would boost our motivation and help other users make a comfortable decision while choosing Divi Supreme.', 'dsm-supreme-modules-pro-for-divi' ),
				'rating'      => array(
					'href'       => 'https://www.trustpilot.com/review/divisupreme.com',
					'target'     => '_blank',
					'style'      => 'color:#ffb900; text-decoration: none;',
					'class'      => 'dsm-rating-link',
					'data_rated' => esc_attr__( 'Thanks :)', 'dsm-supreme-modules-pro-for-divi' ),
					'stars'      => array(
						'dashicons dashicons-star-filled',
						'dashicons dashicons-star-filled',
						'dashicons dashicons-star-filled',
						'dashicons dashicons-star-filled',
						'dashicons dashicons-star-filled',
					),
				),
				'actions'     => array(
					array(
						'type'       => 'link',
						'class'      => 'button button-primary',
						'href'       => 'https://www.trustpilot.com/review/divisupreme.com',
						'data_rated' => esc_attr__( 'Thanks :)', 'dsm-supreme-modules-pro-for-divi' ),
						'target'     => '_blank',
						'text'       => __( 'Write a review', 'dsm-supreme-modules-pro-for-divi' ),
					),
				),
			),
		);
	}

	/**
	 * Register settings sections and fields with the WordPress Settings API.
	 *
	 * @return void
	 */
	public function admin_init() {

		// Set the settings (exclude React-only License tab from WordPress Settings API registration).
		$this->settings_api->set_sections( $this->dsm_get_settings_sections_for_settings_api() );
		$this->settings_api->set_fields( $this->dsm_get_settings_fields_for_settings_api() );

		// Initialize settings.
		$this->settings_api->admin_init();
	}

	/**
	 * Adds the admin menu and submenu pages.
	 *
	 * @return void
	 */
	public function admin_menu() {

		$dsm_plugin_menu_name = $this->settings_api->get_option( 'dsm_plugin_menu_name', 'dsm_settings_misc' );

		if ( '' === trim( $dsm_plugin_menu_name ) ) {
			$dsm_plugin_menu_name = __( 'Divi Supreme Pro', 'dsm-supreme-modules-pro-for-divi' );
		}

		$dsm_plugin_menu_icon = $this->settings_api->get_option( 'dsm_plugin_menu_icon', 'dsm_settings_misc' );

		if ( '' === trim( $dsm_plugin_menu_icon ) ) {
			$dsm_plugin_menu_icon = dsm_default_admin_menu_icon();
		} elseif ( filter_var( $dsm_plugin_menu_icon, FILTER_VALIDATE_URL ) !== false ) {
			$dsm_plugin_menu_icon = esc_url( $dsm_plugin_menu_icon );
		} else {
			$dsm_plugin_menu_icon = trim( $dsm_plugin_menu_icon );
		}

		add_menu_page(
			$dsm_plugin_menu_name,
			$dsm_plugin_menu_name,
			'manage_options',
			'divi_supreme_settings',
			array( $this, 'render_root' ),
			$dsm_plugin_menu_icon,
			99
		);

		// Same slug as the parent replaces WP's auto-copied first submenu
		// ("Divi Supreme Pro") without changing the top-level label.
		add_submenu_page(
			'divi_supreme_settings',
			$dsm_plugin_menu_name,
			__( 'Settings', 'dsm-supreme-modules-pro-for-divi' ),
			'manage_options',
			'divi_supreme_settings',
			array( $this, 'render_root' )
		);
	}

	/**
	 * Register Plugins admin list links (matches Divi Supreme Pro legacy Divi 4 behaviour).
	 *
	 * @return void
	 */
	protected function dsm_register_plugins_screen_links(): void {
		if ( ! defined( 'DSM_DIR_PATH' ) ) {
			return;
		}

		$dsm_basename = plugin_basename( DSM_DIR_PATH . 'supreme-modules-pro-for-divi.php' );

		add_filter( 'plugin_action_links_' . $dsm_basename, array( $this, 'dsm_filter_plugin_list_action_links' ), 10, 4 );
		add_filter( 'plugin_row_meta', array( $this, 'dsm_filter_plugin_list_row_meta' ), 10, 2 );
	}

	/**
	 * Add Settings / License links next to Activate on the Plugins screen.
	 *
	 * License opens the dashboard with the License tab (see Settings dashboard store `tab` query arg).
	 *
	 * @param array<string|string[]>      $actions     Existing rows.
	 * @param string                      $plugin_file Plugin path relative to plugins directory.
	 * @param array<string, string|false> $plugin_data Plugin headers.
	 * @param string                      $plugin_context all|active|inactive|recently_activated|upgrade|mustuse|dropins|search|paused.
	 * @return array<string|string[]>
	 */
	public function dsm_filter_plugin_list_action_links( array $actions, string $plugin_file = '', array $plugin_data = array(), string $plugin_context = '' ): array {
		unset( $plugin_file, $plugin_data, $plugin_context );

		$settings_url = admin_url( 'admin.php?page=divi_supreme_settings' );
		$license_url  = admin_url( 'admin.php?page=divi_supreme_settings&tab=dsm_license' );

		$settings = array(
			'dsm_settings' => sprintf(
				'<a href="%1$s">%2$s</a>',
				esc_url( $settings_url ),
				esc_html__( 'Settings', 'dsm-supreme-modules-pro-for-divi' )
			),
		);

		if ( ! $this->dsm_settings_is_marketplace_build() ) {
			$license = array(
				'dsm_license' => sprintf(
					'<a href="%1$s">%2$s</a>',
					esc_url( $license_url ),
					esc_html__( 'License', 'dsm-supreme-modules-pro-for-divi' )
				),
			);

			$actions = array_merge( $license, $actions );
		}

		$actions = array_merge( $settings, $actions );

		return $actions;
	}

	/**
	 * Add Documentation and Get Support under the plugin description (Visit plugin site comes from core via Plugin URI).
	 *
	 * @param array<int|string, string> $links Existing row meta.
	 * @param string                    $file  Plugin basename path.
	 * @return array<int|string, string>
	 */
	public function dsm_filter_plugin_list_row_meta( array $links, string $file ): array {
		if ( ! defined( 'DSM_DIR_PATH' ) ) {
			return $links;
		}

		$expected = plugin_basename( DSM_DIR_PATH . 'supreme-modules-pro-for-divi.php' );

		if ( $file !== $expected ) {
			return $links;
		}

		$row_meta = array(
			'dsm_docs'    => '<a href="' . esc_url( 'https://docs.divisupreme.com/' ) . '" target="_blank" rel="noopener noreferrer" aria-label="' . esc_attr__( 'Divi Supreme Documentation', 'dsm-supreme-modules-pro-for-divi' ) . '">' . esc_html__( 'Documentation', 'dsm-supreme-modules-pro-for-divi' ) . '</a>',
			'dsm_support' => '<a href="' . esc_url( 'https://divisupreme.com/contact/' ) . '" target="_blank" rel="noopener noreferrer" aria-label="' . esc_attr__( 'Get Support', 'dsm-supreme-modules-pro-for-divi' ) . '">' . esc_html__( 'Get Support', 'dsm-supreme-modules-pro-for-divi' ) . '</a>',
		);

		return array_merge( $links, $row_meta );
	}

	/**
	 * Enqueues necessary admin assets.
	 *
	 * @param string $hook_id The current admin page hook ID.
	 * @return void
	 */
	public function enqueue_assets( $hook_id ) {

		if ( 'toplevel_page_divi_supreme_settings' === $hook_id ) {
			wp_enqueue_script( 'wp-components' );
			wp_enqueue_style( 'dashicons' );

			$dashboard_script_path = 'divi-5/public/settings-dashboard.js';
			$dashboard_style_path  = 'divi-5/public/style-settings-dashboard-styles.css';

			wp_enqueue_script(
				'dsm-supreme-dashboard',
				DSM_DIR_URL . 'public/settings-dashboard.js',
				array( 'wp-components', 'wp-element', 'wp-i18n' ),
				$this->dsm_get_public_asset_version( $dashboard_script_path ),
				true
			);

			wp_enqueue_style(
				'dsm-supreme-dashboard-fonts',
				'https://fonts.googleapis.com/css2?family=Geist:wght@400;500;600&family=Bricolage+Grotesque:opsz,wght@12..96,700&display=swap',
				array(),
				null // phpcs:ignore WordPress.WP.EnqueuedResourceParameters.MissingVersion -- Google Fonts CSS must not receive a WordPress ver query argument.
			);

			wp_enqueue_style(
				'dsm-supreme-dashboard',
				DSM_DIR_URL . 'public/style-settings-dashboard-styles.css',
				array( 'dsm-supreme-dashboard-fonts' ),
				$this->dsm_get_public_asset_version( $dashboard_style_path )
			);

			$this->enqueue_divi_fontawesome();

			$sections = $this->get_settings_sections();
			wp_localize_script(
				'dsm-supreme-dashboard',
				'dsmSettings',
				array(
					'ajaxUrl'                       => admin_url( 'admin-ajax.php' ),
					'assetsBaseUrl'                 => \DiviSupreme\Core\Assets::getAssetsBasePath(),
					'version'                       => defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '',
					'sections'                      => $sections,
					'fields'                        => $this->dsm_populate_settings_fields_for_dashboard( $this->get_settings_fields() ),
					'nonce'                         => wp_create_nonce( 'divi_supreme_settings-options' ),
					'settings'                      => $this->get_settings(),
					'license'                       => $this->dsm_settings_dashboard_license_localize_payload(),
					'support'                       => class_exists( \DiviSupreme\Includes\Support\TemporaryAccess::class )
						? \DiviSupreme\Includes\Support\TemporaryAccess::dashboard_payload()
						: array(),
					'legacyConversion'              => $this->dsm_settings_dashboard_legacy_conversion_localize_payload(),
					'clientHandoff'                 => class_exists( \DiviSupreme\Extensions\ClientHandoff::class )
						? \DiviSupreme\Extensions\ClientHandoff::get_localize_payload()
						: array(),
					'clientGuide'                   => class_exists( \DiviSupreme\Extensions\ClientGuide::class )
						? \DiviSupreme\Extensions\ClientGuide::get_localize_payload()
						: array(),
					'diviCacheClear'                => $this->dsm_settings_dashboard_divi_cache_clear_localize_payload(),
					'betaUpdates'                   => $this->dsm_settings_dashboard_beta_updates_localize_payload(),
					'moduleDashboardCategoryLabels' => \DiviSupreme\Core\ModuleRegistry::get_module_dashboard_category_labels(),
					'moduleDashboardCategoryOrder'  => \DiviSupreme\Core\ModuleRegistry::get_module_dashboard_category_order(),
					'maskPatternLibrary'            => $this->dsm_settings_dashboard_mask_pattern_library_localize_payload(),
					'scopePagePicker'               => $this->dsm_settings_dashboard_scope_page_picker_localize_payload(),
				)
			);
		}
	}

	/**
	 * Load Divi's Font Awesome face so quick-action icons use the theme font.
	 *
	 * The icons_fa_all.css file points fonts at #dynamic-product-dir, which Divi rewrites
	 * on the front end. The settings screen does that rewrite here.
	 *
	 * @return void
	 */
	private function enqueue_divi_fontawesome(): void {
		if ( ! function_exists( 'get_template_directory' ) ) {
			return;
		}

		$fa_css_file = get_template_directory() . '/includes/builder/feature/dynamic-assets/assets/css/icons_fa_all.css';

		if ( ! is_readable( $fa_css_file ) ) {
			return;
		}

		$css_content = file_get_contents( $fa_css_file ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Local theme CSS, rewritten before it is printed.

		if ( ! is_string( $css_content ) || '' === $css_content ) {
			return;
		}

		$product_dir   = get_template_directory_uri();
		$processed_css = preg_replace(
			'/#dynamic-product-dir/i',
			str_replace( array( 'http:', 'https:' ), '', $product_dir ),
			$css_content
		);

		if ( ! is_string( $processed_css ) || '' === $processed_css ) {
			return;
		}

		$font_base      = str_replace( array( 'http:', 'https:' ), '', $product_dir ) . '/core/admin/fonts/fontawesome/';
		$processed_css .= '@font-face{font-family:DSMFontAwesomeRegular;font-style:normal;font-weight:400;font-display:swap;src:url(' . $font_base . 'fa-regular-400.woff2) format("woff2"),url(' . $font_base . 'fa-regular-400.woff) format("woff")}';

		wp_register_style( 'dsm-divi-fontawesome', false, array(), defined( 'ET_BUILDER_VERSION' ) ? ET_BUILDER_VERSION : false );
		wp_enqueue_style( 'dsm-divi-fontawesome' );
		wp_add_inline_style( 'dsm-divi-fontawesome', $processed_css );
	}

	/**
	 * Cache-busting version for built dashboard assets (filemtime + plugin version).
	 *
	 * @param string $relative_path Path under the plugin root, e.g. `divi-5/public/settings-dashboard.js`.
	 */
	private function dsm_get_public_asset_version( string $relative_path ): string {
		if ( ! defined( 'DSM_DIR_PATH' ) ) {
			return DSM_PRO_VERSION;
		}

		$absolute_path = DSM_DIR_PATH . ltrim( $relative_path, '/' );

		if ( is_readable( $absolute_path ) ) {
			$mtime = filemtime( $absolute_path );

			if ( false !== $mtime ) {
				return DSM_PRO_VERSION . '.' . (string) $mtime;
			}
		}

		return DSM_PRO_VERSION;
	}

	/**
	 * Settings sections registered with WordPress (excludes dashboard-only tabs such as License).
	 *
	 * @return array<int, array<string, mixed>>
	 */
	protected function dsm_get_settings_sections_for_settings_api(): array {
		return array_values(
			array_filter(
				$this->get_settings_sections(),
				static function ( $section ): bool {
					if ( ! isset( $section['id'] ) ) {
						return false;
					}

					$id = $section['id'];

					if (
						'dsm_icon_libraries' === $id
						&& ( ! function_exists( 'dsm_is_icon_libraries_extension_enabled' )
							|| ! dsm_is_icon_libraries_extension_enabled() )
					) {
						return false;
					}

					if (
						'dsm_mask_pattern_library' === $id
						&& ( ! function_exists( 'dsm_is_mask_pattern_library_extension_enabled' )
							|| ! dsm_is_mask_pattern_library_extension_enabled() )
					) {
						return false;
					}

					if (
						'dsm_settings_protection' === $id
						&& ( ! function_exists( 'dsm_is_password_protection_extension_enabled' )
							|| ! dsm_is_password_protection_extension_enabled() )
					) {
						return false;
					}

					if (
						'dsm_handoff' === $id
						&& ( ! function_exists( 'dsm_is_client_handoff_extension_enabled' )
							|| ! dsm_is_client_handoff_extension_enabled() )
					) {
						return false;
					}

					if (
						'dsm_settings_contact_form_pro' === $id
						&& ( ! function_exists( 'dsm_is_contact_form_entries_extension_enabled' )
							|| ! dsm_is_contact_form_entries_extension_enabled() )
					) {
						return false;
					}

					if (
						'dsm_settings_preloader' === $id
						&& ( ! function_exists( 'dsm_is_preloader_extension_enabled' )
							|| ! dsm_is_preloader_extension_enabled() )
					) {
						return false;
					}

					return ! in_array( $id, array( 'dsm_license', 'dsm_theme_builder', 'dsm_supreme5_migration', 'dsm_handoff', 'dsm_client_guide', 'dsm_support' ), true );
				}
			)
		);
	}

	/**
	 * Fields registered with WordPress Settings API (excludes dashboard-only tabs).
	 *
	 * @return array<string, array<int, array<string, mixed>>>
	 */
	protected function dsm_get_settings_fields_for_settings_api(): array {
		$fields = $this->get_settings_fields();

		unset( $fields['dsm_license'], $fields['dsm_theme_builder'], $fields['dsm_supreme5_migration'], $fields['dsm_handoff'], $fields['dsm_client_guide'], $fields['dsm_support'] );

		foreach ( $fields as $section_id => $section_fields ) {
			if ( ! is_array( $section_fields ) ) {
				continue;
			}

			$fields[ $section_id ] = array_values(
				array_filter(
					$section_fields,
					static function ( $field ): bool {
						if ( ! is_array( $field ) ) {
							return false;
						}

						return ! in_array(
							(string) ( $field['type'] ?? '' ),
							array( 'action_button', 'settings_group', 'subheading', 'password_entries', 'scope_page_picker' ),
							true
						);
					}
				)
			);
		}

		return $fields;
	}

	/**
	 * Localized config for the Divi static cache clear action (Miscellaneous tab).
	 *
	 * @return array<string, mixed>
	 */
	protected function dsm_settings_dashboard_divi_cache_clear_localize_payload(): array {
		if ( class_exists( \DiviSupreme\Includes\DiviCacheClear::class ) ) {
			return \DiviSupreme\Includes\DiviCacheClear::get_script_payload();
		}

		return array();
	}

	/**
	 * Localized config for the Supreme 5 legacy module bulk conversion tab.
	 *
	 * @return array<string, mixed>
	 */
	protected function dsm_settings_dashboard_legacy_conversion_localize_payload(): array {
		return array(
			'nonce'     => wp_create_nonce( \DiviSupreme\Includes\Divi5Conversion\LegacyModuleBulkConversion::AJAX_NONCE_ACTION ),
			'batchSize' => \DiviSupreme\Includes\Divi5Conversion\LegacyModuleBulkConversion::DEFAULT_BATCH_SIZE,
			'strings'   => array(
				'beforeYouStart'     => __( 'Before you start', 'dsm-supreme-modules-pro-for-divi' ),
				'backupNotice'       => __(
					'Take a full site backup before running this tool. WordPress revisions are created for each re-saved item, but a backup is strongly recommended.',
					'dsm-supreme-modules-pro-for-divi'
				),
				'confirmLabel'       => __(
					'I have a backup and understand this will re-save the selected items through Divi\'s builder save pipeline.',
					'dsm-supreme-modules-pro-for-divi'
				),
				'selectItemsLabel'   => __(
					'Choose which items to re-save. Tip: dry-run one page first before re-saving the rest of the site.',
					'dsm-supreme-modules-pro-for-divi'
				),
				'searchPlaceholder'  => __( 'Search by title or ID…', 'dsm-supreme-modules-pro-for-divi' ),
				'filterAllTypes'     => __( 'All types', 'dsm-supreme-modules-pro-for-divi' ),
				'selectVisible'      => __( 'Select visible', 'dsm-supreme-modules-pro-for-divi' ),
				'clearSelection'     => __( 'Clear selection', 'dsm-supreme-modules-pro-for-divi' ),
				// translators: %d: number of selected items.
				'selectedCount'      => __( '%d selected', 'dsm-supreme-modules-pro-for-divi' ),
				'selectAtLeastOne'   => __( 'Select at least one item to re-save.', 'dsm-supreme-modules-pro-for-divi' ),
				'noVisibleItems'     => __( 'No items match the current filter.', 'dsm-supreme-modules-pro-for-divi' ),
				'selectSectionTitle' => __( 'Select items to re-save', 'dsm-supreme-modules-pro-for-divi' ),
				'reasonLegacy'       => __( 'Legacy conversion', 'dsm-supreme-modules-pro-for-divi' ),
				'reasonResave'       => __( 'Builder re-save', 'dsm-supreme-modules-pro-for-divi' ),
				// translators: %d: number of layouts that need legacy conversion.
				'scanSummaryLegacy'  => __( '%d need legacy conversion', 'dsm-supreme-modules-pro-for-divi' ),
				// translators: %d: number of layouts that need a builder re-save.
				'scanSummaryResave'  => __( '%d need builder re-save only (native in database)', 'dsm-supreme-modules-pro-for-divi' ),
				'cliDiagnoseHint'    => __( 'Check one page: `wp dsm convert-legacy --diagnose=POST_ID`', 'dsm-supreme-modules-pro-for-divi' ),
				'scanButton'         => __( 'Scan site', 'dsm-supreme-modules-pro-for-divi' ),
				'rescanButton'       => __( 'Rescan', 'dsm-supreme-modules-pro-for-divi' ),
				'cardDescription'    => __(
					'Finds Divi 4 Supreme shortcodes in posts, pages and layouts and converts them to Divi 5 blocks. Run a scan first; conversion is per post and reversible from revisions.',
					'dsm-supreme-modules-pro-for-divi'
				),
				'scanPrompt'         => __(
					'Click Scan site to check whether any layouts still use legacy Divi Supreme modules (D4 shortcodes such as dsm_card). Third-party Divi modules are not included. Nothing runs until you scan or start re-save.',
					'dsm-supreme-modules-pro-for-divi'
				),
				'startButton'        => __( 'Start re-save', 'dsm-supreme-modules-pro-for-divi' ),
				// translators: %d: number of posts to convert.
				'convertButton'      => __( 'Convert %d posts', 'dsm-supreme-modules-pro-for-divi' ),
				// translators: %s: date and time of the last scan.
				'lastScanLabel'      => __( 'Last scan: %s', 'dsm-supreme-modules-pro-for-divi' ),
				'dryRunLabel'        => __( 'Dry run (report only, do not save changes)', 'dsm-supreme-modules-pro-for-divi' ),
				'cancelButton'       => __( 'Stop', 'dsm-supreme-modules-pro-for-divi' ),
				'resetButton'        => __( 'Clear job', 'dsm-supreme-modules-pro-for-divi' ),
				'allClear'           => __( 'No layouts with Supreme modules were found that need legacy conversion or builder re-save.', 'dsm-supreme-modules-pro-for-divi' ),
				'audienceNote'       => __(
					'Finds layouts with legacy shortcode-module blocks OR native dsm/* blocks that may still show D4 shortcodes on the frontend until re-saved through Divi\'s builder save pipeline.',
					'dsm-supreme-modules-pro-for-divi'
				),
				'cliHint'            => __( 'Developers: run `wp dsm convert-legacy --scan-only` or `wp dsm convert-legacy` from WP-CLI.', 'dsm-supreme-modules-pro-for-divi' ),
				'resaveNote'         => __(
					'Each item is re-saved through Divi\'s Visual Builder save pipeline (the same path as clicking Save in the builder). Divi handles legacy module conversion during save; this tool does not rewrite stored content separately.',
					'dsm-supreme-modules-pro-for-divi'
				),
				// translators: 1: current item number, 2: total items.
				'progressRunning'    => __( 'Re-saving %1$s of %2$s…', 'dsm-supreme-modules-pro-for-divi' ),
				'progressResaved'    => __( 'Re-saved:', 'dsm-supreme-modules-pro-for-divi' ),
			),
		);
	}

	/**
	 * Populates field definitions for the React dashboard (nested `fields` per section).
	 *
	 * @param array<string, array<int, array<string, mixed>>> $settings_fields Fields by section slug.
	 * @return array<string, array<string, mixed>>
	 */
	protected function dsm_populate_settings_fields_for_dashboard( array $settings_fields ): array {
		unset( $settings_fields['dsm_theme_builder'] );

		if ( $this->dsm_settings_is_marketplace_build() ) {
			unset( $settings_fields['dsm_license'] );
		}

		$result = array();

		foreach ( $settings_fields as $section_key => $field_list ) {
			if ( 'dsm_license' === $section_key ) {
				$result['dsm_license'] = array(
					'fields' => $this->dsm_populate_license_fields_for_dashboard( is_array( $field_list ) ? $field_list : array() ),
				);
				continue;
			}

			$section_options = get_option( $section_key, array() );
			if ( ! is_array( $section_options ) ) {
				$section_options = array();
			}

			$fields_out = array();

			foreach ( $field_list as $option ) {
				if ( ! isset( $option['name'] ) ) {
					continue;
				}

				if (
					$this->dsm_settings_is_marketplace_build()
					&& 'dsm_allow_beta_updates' === $option['name']
				) {
					continue;
				}

				$row = $option;

				if ( isset( $option['callback'] ) ) {
					unset( $row['callback'] );
				}

				if ( empty( $row['icon'] ) ) {
					$fallback_icon = $this->dsm_dashboard_fallback_row_icon( $section_key, $option );
					if ( '' !== $fallback_icon ) {
						$row['icon'] = $fallback_icon;
					}
				}

				$row['value'] = isset( $section_options[ $option['name'] ] )
					? $section_options[ $option['name'] ]
					: ( isset( $option['default'] ) ? $option['default'] : '' );

				$row['option_name'] = sprintf( '%s[%s]', $section_key, $option['name'] );

				if (
					'dsm_settings_contact_form_pro' === $section_key
					&& in_array(
						(string) $option['name'],
						array(
							'dsm_cf_turnstile_site_key',
							'dsm_cf_turnstile_secret_key',
							'dsm_cf_hcaptcha_site_key',
							'dsm_cf_hcaptcha_secret_key',
							'dsm_cf_webhook_secret',
						),
						true
					)
					&& is_scalar( $row['value'] )
					&& '' !== (string) $row['value']
				) {
					$row['value']        = $this->dsm_mask_license_key_for_display( (string) $row['value'] );
					$row['autocomplete'] = 'off';
				}

				if (
					'dsm_settings_misc' === $section_key
					&& 'dsm_allow_beta_updates' === $option['name']
					&& function_exists( 'dsm_beta_misc_settings_allow_beta_extra_html' )
				) {
					$row['desc']  = isset( $row['desc'] ) ? (string) $row['desc'] : '';
					$row['desc'] .= dsm_beta_misc_settings_allow_beta_extra_html( (string) $row['value'] );
				}

				if (
					'dsm_settings_misc' === $section_key
					&& class_exists( \DiviSupreme\Extensions\MaintenanceMode::class )
				) {
					if (
						'dsm_maintenance_mode_status' === $option['name']
						&& isset( $GLOBALS['dsm_maintenance_mode_extension'] )
						&& $GLOBALS['dsm_maintenance_mode_extension'] instanceof \DiviSupreme\Extensions\MaintenanceMode
					) {
						$mm_status    = $GLOBALS['dsm_maintenance_mode_extension']->get_status_for_settings();
						$row['label'] = sprintf(
							/* translators: %s: status label (Off, Scheduled, Active, Ended) */
							__( 'Status: %s', 'dsm-supreme-modules-pro-for-divi' ),
							$mm_status['label']
						);
						$row['desc']       = $mm_status['description'];
						$row['tone']       = $mm_status['tone'] ?? 'neutral';
						$row['statusLive'] = $GLOBALS['dsm_maintenance_mode_extension']->get_status_live_payload();
					}

					if (
						in_array(
							$option['name'],
							array(
								'dsm_maintenance_mode_start',
								'dsm_maintenance_mode_end',
							),
							true
						)
					) {
						$row['value']      = \DiviSupreme\Extensions\MaintenanceMode::stored_datetime_to_input_value(
							is_scalar( $row['value'] ) ? (string) $row['value'] : ''
						);
						$row['input_type'] = 'datetime-local';
						$base_desc         = 'dsm_maintenance_mode_start' === $option['name']
							? __( 'Optional. Leave empty to start as soon as this feature is enabled.', 'dsm-supreme-modules-pro-for-divi' )
							: __( 'Optional. Leave empty to keep the visitor page on until you disable it. Must be after the start time.', 'dsm-supreme-modules-pro-for-divi' );
						$row['desc']       = $base_desc . ' ' . \DiviSupreme\Extensions\MaintenanceMode::get_schedule_timezone_help_html();
					}
				}

				if (
					'dsm_settings_misc' === $section_key
					&& class_exists( \DiviSupreme\Extensions\Custom404::class )
					&& 'dsm_custom_404_status' === $option['name']
					&& isset( $GLOBALS['dsm_custom_404_extension'] )
					&& $GLOBALS['dsm_custom_404_extension'] instanceof \DiviSupreme\Extensions\Custom404
				) {
					$c404_status  = $GLOBALS['dsm_custom_404_extension']->get_status_for_settings();
					$row['label'] = sprintf(
						/* translators: %s: status label (Off, Active, Deferred, Enabled — no layout) */
						__( 'Status: %s', 'dsm-supreme-modules-pro-for-divi' ),
						$c404_status['label']
					);
					$row['desc'] = $c404_status['description'];
					$row['tone'] = $c404_status['tone'] ?? 'neutral';
				}

				if (
					'dsm_settings_protection' === $section_key
					&& class_exists( \DiviSupreme\Extensions\PasswordProtection::class )
				) {
					if (
						'dsm_password_protection_status' === $option['name']
						&& isset( $GLOBALS['dsm_password_protection_extension'] )
						&& $GLOBALS['dsm_password_protection_extension'] instanceof \DiviSupreme\Extensions\PasswordProtection
					) {
						$pp_status    = $GLOBALS['dsm_password_protection_extension']->get_status_for_settings();
						$row['label'] = sprintf(
							/* translators: %s: status label */
							__( 'Status: %s', 'dsm-supreme-modules-pro-for-divi' ),
							$pp_status['label']
						);
						$row['desc'] = $pp_status['description'];
						$row['tone'] = $pp_status['tone'] ?? 'neutral';
					}

					if ( \DiviSupreme\Extensions\PasswordProtection::OPTION_ENTRIES === $option['name'] ) {
						$row['value'] = \DiviSupreme\Extensions\PasswordProtection::entries_for_dashboard_ui(
							is_scalar( $row['value'] ) ? (string) $row['value'] : '[]'
						);
					}

					if ( \DiviSupreme\Extensions\PasswordProtection::OPTION_BYPASS_MODE === $option['name'] ) {
						$row['value'] = \DiviSupreme\Extensions\PasswordProtection::get_sitewide_bypass_mode();
					}

					if ( \DiviSupreme\Extensions\PasswordProtection::OPTION_BYPASS_ROLES === $option['name'] ) {
						$row['options'] = \DiviSupreme\Extensions\PasswordProtection::get_bypass_role_options_for_settings();
						$row['value']   = \DiviSupreme\Extensions\PasswordProtection::get_sitewide_bypass_roles_for_settings_multicheck();
					}
				}

				if (
					'dsm_settings_preloader' === $section_key
					&& class_exists( \DiviSupreme\Extensions\Preloader::class )
				) {
					if ( 'is_enabled' === $option['name'] ) {
						$row['value'] = ! empty( $row['value'] ) && 'off' !== $row['value'] && false !== $row['value'] && '0' !== (string) $row['value']
							? 'on'
							: 'off';
					}

					if ( 'dsm_preloader_status' === $option['name'] ) {
						if ( isset( $GLOBALS['dsm_preloader_extension'] )
							&& $GLOBALS['dsm_preloader_extension'] instanceof \DiviSupreme\Extensions\Preloader ) {
							$pl_status = $GLOBALS['dsm_preloader_extension']->get_status_for_settings();
						} else {
							$pl_status = ( new \DiviSupreme\Extensions\Preloader( false ) )->get_status_for_settings();
						}
						$row['label'] = sprintf(
							/* translators: %s: status label */
							__( 'Status: %s', 'dsm-supreme-modules-pro-for-divi' ),
							$pl_status['label']
						);
						$row['desc'] = $pl_status['description'];
						$row['tone'] = $pl_status['tone'] ?? 'neutral';
					}
				}

				$fields_out[] = $row;
			}

			$result[ $section_key ] = array(
				'fields' => $fields_out,
			);
		}

		return $result;
	}

	/**
	 * Populated dashboard field rows for a single settings section (React localize / AJAX refresh).
	 *
	 * @param string $section_key Section id (e.g. dsm_icon_libraries).
	 * @return array{fields: array<int, array<string, mixed>>}
	 */
	protected function dsm_dashboard_section_fields_payload( string $section_key ): array {
		$definitions = $this->get_settings_fields();

		if ( ! isset( $definitions[ $section_key ] ) || ! is_array( $definitions[ $section_key ] ) ) {
			return array(
				'fields' => array(),
			);
		}

		$populated = $this->dsm_populate_settings_fields_for_dashboard(
			array(
				$section_key => $definitions[ $section_key ],
			)
		);

		$section = $populated[ $section_key ] ?? array(
			'fields' => array(),
		);

		if ( ! isset( $section['fields'] ) || ! is_array( $section['fields'] ) ) {
			return array(
				'fields' => array(),
			);
		}

		return $section;
	}

	/**
	 * Sections whose field definitions depend on another tab's saved options.
	 *
	 * @param string $saved_section Section id that was just saved via AJAX.
	 * @return array<string, array{fields: array<int, array<string, mixed>>}>
	 */
	protected function dsm_dashboard_refreshed_sections_after_save( string $saved_section ): array {
		if ( 'dsm_settings_protection' === $saved_section ) {
			return array(
				'dsm_settings_protection' => $this->dsm_dashboard_section_fields_payload( 'dsm_settings_protection' ),
			);
		}

		if ( 'dsm_settings_preloader' === $saved_section ) {
			return array(
				'dsm_settings_preloader' => $this->dsm_dashboard_section_fields_payload( 'dsm_settings_preloader' ),
			);
		}

		if ( 'dsm_settings_contact_form_pro' === $saved_section ) {
			return array(
				'dsm_settings_contact_form_pro' => $this->dsm_dashboard_section_fields_payload( 'dsm_settings_contact_form_pro' ),
			);
		}

		if ( 'dsm_general' !== $saved_section ) {
			return array();
		}

		return array(
			'dsm_icon_libraries'            => $this->dsm_dashboard_section_fields_payload( 'dsm_icon_libraries' ),
			'dsm_mask_pattern_library'      => $this->dsm_dashboard_section_fields_payload( 'dsm_mask_pattern_library' ),
			'dsm_settings_protection'       => $this->dsm_dashboard_section_fields_payload( 'dsm_settings_protection' ),
			'dsm_settings_contact_form_pro' => $this->dsm_dashboard_section_fields_payload( 'dsm_settings_contact_form_pro' ),
			'dsm_settings_preloader'        => $this->dsm_dashboard_section_fields_payload( 'dsm_settings_preloader' ),
			'dsm_handoff'                   => $this->dsm_dashboard_section_fields_payload( 'dsm_handoff' ),
		);
	}

	/**
	 * Localized mask/pattern catalog for the settings dashboard preview panel.
	 *
	 * @return array{masks: array<int, array<string, string>>, patterns: array<int, array<string, string>>}
	 */
	protected function dsm_settings_dashboard_mask_pattern_library_localize_payload(): array {
		if (
			! function_exists( 'dsm_is_mask_pattern_library_extension_enabled' )
			|| ! dsm_is_mask_pattern_library_extension_enabled()
		) {
			return array(
				'masks'    => array(),
				'patterns' => array(),
			);
		}

		return \DiviSupreme\Core\MaskPatternLibraryDashboardRows::build_dashboard_catalog();
	}

	/**
	 * Localized REST + quick-picks payload for dashboard include/exclude page pickers.
	 *
	 * Reuses `GET /dsm/v1/custom-cursor-scope-posts` (edit_posts). Empty current-page
	 * pick is expected on this admin screen — Homepage still works when a static front page is set.
	 *
	 * restUrl: string,
	 * restNonce: string,
	 * postTypes: array<int, array{name: string, label: string}>,
	 * quickPicks: array<string, mixed>,
	 * strings: array<string, string>
	 * }
	 *
	 * @return array{
	 */
	protected function dsm_settings_dashboard_scope_page_picker_localize_payload(): array {
		$post_types = array();

		if ( ! function_exists( 'dsm_get_post_type_taxonomies' ) ) {
			$taxonomies_file = DSM_DIR_PATH . 'divi-5/app/Utils/get-post-type-taxonomies.php';
			if ( is_readable( $taxonomies_file ) ) {
				require_once $taxonomies_file;
			}
		}

		if ( ! function_exists( 'dsm_get_post_types' ) ) {
			$types_file = DSM_DIR_PATH . 'divi-5/app/Utils/get-post-types.php';
			if ( is_readable( $types_file ) ) {
				require_once $types_file;
			}
		}

		if ( function_exists( 'dsm_get_post_types' ) ) {
			$raw_types = dsm_get_post_types();
			if ( is_array( $raw_types ) ) {
				foreach ( $raw_types as $type ) {
					if ( ! is_array( $type ) || empty( $type['name'] ) || ! is_string( $type['name'] ) ) {
						continue;
					}

					$post_types[] = array(
						'name'  => $type['name'],
						'label' => isset( $type['label'] ) && is_string( $type['label'] ) && '' !== $type['label']
							? $type['label']
							: $type['name'],
					);
				}
			}
		}

		if ( array() === $post_types ) {
			$post_types = array(
				array(
					'name'  => 'page',
					'label' => __( 'Pages', 'dsm-supreme-modules-pro-for-divi' ),
				),
				array(
					'name'  => 'post',
					'label' => __( 'Posts', 'dsm-supreme-modules-pro-for-divi' ),
				),
			);
		}

		if ( ! function_exists( 'dsm_get_custom_cursor_scope_quick_picks' ) ) {
			$picks_file = DSM_DIR_PATH . 'divi-5/app/Includes/dsm-custom-cursor-scope-quick-picks.php';
			if ( is_readable( $picks_file ) ) {
				require_once $picks_file;
			}
		}

		$quick_picks = function_exists( 'dsm_get_custom_cursor_scope_quick_picks' )
			? dsm_get_custom_cursor_scope_quick_picks( 0 )
			: array();

		return array(
			'restUrl'    => rest_url( 'dsm/v1/custom-cursor-scope-posts' ),
			'restNonce'  => wp_create_nonce( 'wp_rest' ),
			'postTypes'  => $post_types,
			'quickPicks' => $quick_picks,
			'strings'    => array(
				'quickAdd'            => __( 'Quick add', 'dsm-supreme-modules-pro-for-divi' ),
				'quickAddDescription' => __( 'Add the site homepage in one click.', 'dsm-supreme-modules-pro-for-divi' ),
				'homepage'            => __( 'Homepage', 'dsm-supreme-modules-pro-for-divi' ),
				'currentPage'         => __( 'Current page', 'dsm-supreme-modules-pro-for-divi' ),
				'filterByType'        => __( 'Filter results by type', 'dsm-supreme-modules-pro-for-divi' ),
				'filterByTypeHelp'    => __( 'Optional. Narrows search results — selected items stay regardless of this filter.', 'dsm-supreme-modules-pro-for-divi' ),
				'allTypes'            => __( 'All types', 'dsm-supreme-modules-pro-for-divi' ),
				'searchPlaceholder'   => __( 'Search pages, posts, and more…', 'dsm-supreme-modules-pro-for-divi' ),
				'nothingSelected'     => __( 'Nothing selected yet.', 'dsm-supreme-modules-pro-for-divi' ),
				'keepTyping'          => __( 'Keep typing to search…', 'dsm-supreme-modules-pro-for-divi' ),
				'searching'           => __( 'Searching…', 'dsm-supreme-modules-pro-for-divi' ),
				'loading'             => __( 'Loading…', 'dsm-supreme-modules-pro-for-divi' ),
				'loadingSelection'    => __( 'Loading selection…', 'dsm-supreme-modules-pro-for-divi' ),
				'searchError'         => __( 'Could not search. Try again.', 'dsm-supreme-modules-pro-for-divi' ),
				'loadError'           => __( 'Could not load items. Try again.', 'dsm-supreme-modules-pro-for-divi' ),
				'noMatches'           => __( 'No matches found.', 'dsm-supreme-modules-pro-for-divi' ),
				'noItems'             => __( 'No items found. Try a different search or filter.', 'dsm-supreme-modules-pro-for-divi' ),
				'allSelected'         => __( 'All shown items are selected. Type to search for more…', 'dsm-supreme-modules-pro-for-divi' ),
				'removeItem'          => __( 'Remove', 'dsm-supreme-modules-pro-for-divi' ),
				'page'                => __( 'Page', 'dsm-supreme-modules-pro-for-divi' ),
			),
		);
	}

	/**
	 * Admin-ajax: return populated dashboard fields for a settings section (lazy tab refresh).
	 *
	 * @return void
	 */
	public function dsm_ajax_get_dashboard_section_fields(): void {
		if (
			! isset( $_POST['_wpnonce'] )
			|| ! wp_verify_nonce(
				sanitize_key( wp_unslash( (string) $_POST['_wpnonce'] ) ),
				'divi_supreme_settings-options'
			)
		) {
			wp_send_json_error(
				array(
					'message' => __( 'Security check failed.', 'dsm-supreme-modules-pro-for-divi' ),
				)
			);
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error(
				array(
					'message' => __( 'You do not have permission to load settings.', 'dsm-supreme-modules-pro-for-divi' ),
				)
			);
		}

		$section = isset( $_POST['section'] ) ? sanitize_key( wp_unslash( (string) $_POST['section'] ) ) : '';

		if ( '' === $section || ! isset( $this->get_settings_fields()[ $section ] ) ) {
			wp_send_json_error(
				array(
					'message' => __( 'Invalid settings section.', 'dsm-supreme-modules-pro-for-divi' ),
				)
			);
		}

		wp_send_json_success(
			array(
				'section'       => $section,
				'sectionFields' => $this->dsm_dashboard_section_fields_payload( $section ),
			)
		);
	}

	/**
	 * Fallback row icon for grouped settings fields that have no explicit icon.
	 *
	 * @param string               $section_key Section id.
	 * @param array<string, mixed> $option      Field definition.
	 * @return string
	 */
	protected function dsm_dashboard_fallback_row_icon( string $section_key, array $option ): string {
		$type = isset( $option['type'] ) ? (string) $option['type'] : '';

		if ( 'settings_group' === $type ) {
			return '';
		}

		if ( ! empty( $option['hidden_in_settings_ui'] ) ) {
			return '';
		}

		$icon_sections = array(
			'dsm_settings_misc',
			'dsm_settings_preloader',
			'dsm_settings_social_media',
			'dsm_settings_protection',
			'dsm_settings_contact_form_pro',
			'dsm_license',
		);

		if ( ! in_array( $section_key, $icon_sections, true ) ) {
			return '';
		}

		return Assets::getAssetPath( 'dashboard/rows/label.svg' );
	}

	/**
	 * License fields for localize (masked key, flat input name).
	 *
	 * @param array<int, array<string, mixed>> $field_list License field defs.
	 * @return array<int, array<string, mixed>>
	 */
	protected function dsm_populate_license_fields_for_dashboard( array $field_list ): array {
		$licence_data = get_site_option( 'dsm_pro_license', array() );
		$raw_key      = '';

		if ( is_array( $licence_data ) && isset( $licence_data['key'] ) ) {
			$raw_key = (string) $licence_data['key'];
		}

		$masked = '' === $raw_key ? '' : $this->dsm_mask_license_key_for_display( $raw_key );

		$rows = array();

		foreach ( $field_list as $option ) {
			$row = $option;

			if ( isset( $option['callback'] ) ) {
				unset( $row['callback'] );
			}

			$row['value']       = $masked;
			$row['option_name'] = 'dsm_pro_license_key';

			if ( empty( $row['icon'] ) ) {
				$fallback_icon = $this->dsm_dashboard_fallback_row_icon( 'dsm_license', $option );
				if ( '' !== $fallback_icon ) {
					$row['icon'] = $fallback_icon;
				}
			}

			$rows[] = $row;
		}

		return $rows;
	}

	/**
	 * Visible leading segment masking for licence keys (similar to Supreme AI Writer).
	 *
	 * @param string $key Full key stored on the server.
	 * @return string
	 */
	protected function dsm_mask_license_key_for_display( string $key ): string {
		$visible_length = 16;

		if ( '' === $key ) {
			return '';
		}

		if ( strlen( $key ) <= $visible_length ) {
			return $key;
		}

		return substr( $key, 0, $visible_length ) . str_repeat( '*', strlen( $key ) - $visible_length );
	}

	/**
	 * Resolve stored `expiry_date` for dashboard display and expired checks.
	 *
	 * @return array{kind: string, ts: int|null} `kind` is `none` (no key), `lifetime`, `invalid`, or `dated` with `ts` set.
	 */
	protected function dsm_license_dashboard_expiry_resolution(): array {
		$license_data = get_site_option( 'dsm_pro_license', array() );

		if ( ! is_array( $license_data ) ) {
			return array(
				'kind' => 'none',
				'ts'   => null,
			);
		}

		$key = isset( $license_data['key'] ) ? trim( (string) $license_data['key'] ) : '';

		if ( '' === $key ) {
			return array(
				'kind' => 'none',
				'ts'   => null,
			);
		}

		$exp = isset( $license_data['expiry_date'] ) ? trim( (string) $license_data['expiry_date'] ) : '';

		if ( '' === $exp ) {
			return array(
				'kind' => 'lifetime',
				'ts'   => null,
			);
		}

		$exp_ts = strtotime( $exp );

		if ( false === $exp_ts ) {
			return array(
				'kind' => 'invalid',
				'ts'   => null,
			);
		}

		return array(
			'kind' => 'dated',
			'ts'   => $exp_ts,
		);
	}

	/**
	 * Formatted licence expiry for the React License tab (reads `dsm_pro_license`).
	 *
	 * (e.g. lifetime); reactivation hint when a value is present but cannot be parsed as a date.
	 *
	 * @return string Empty when no key is stored; localized date; no-expiry copy when `expiry_date` is empty
	 */
	protected function dsm_license_expiry_display_string_for_dashboard(): string {
		$r = $this->dsm_license_dashboard_expiry_resolution();

		if ( 'none' === $r['kind'] ) {
			return '';
		}

		if ( 'lifetime' === $r['kind'] ) {
			/* translators: Shown when the licensing server left expiry empty (typical for lifetime licences). */
			return __( 'This license has no expiry date.', 'dsm-supreme-modules-pro-for-divi' );
		}

		if ( 'invalid' === $r['kind'] ) {
			return __( 'Unable to read the expiry date. Reactivate your license to refresh it.', 'dsm-supreme-modules-pro-for-divi' );
		}

		return date_i18n( (string) get_option( 'date_format' ), (int) $r['ts'] );
	}

	/**
	 * Whether the stored licence has a parsable expiry in the past.
	 *
	 * @return bool
	 */
	protected function dsm_license_is_expired_for_dashboard(): bool {
		$r = $this->dsm_license_dashboard_expiry_resolution();

		if ( 'dated' !== $r['kind'] || null === $r['ts'] ) {
			return false;
		}

		return $r['ts'] < time();
	}

	/**
	 * Customer account URL for renewals / licence management.
	 *
	 * @return string Absolute URL.
	 */
	protected function dsm_license_renewal_account_url(): string {
		return 'https://divisupreme.com/my-account/';
	}

	/**
	 * Short label for an expired licence (React badge).
	 *
	 * @return string Empty when not expired.
	 */
	protected function dsm_license_expired_badge_label_for_dashboard(): string {
		return $this->dsm_license_is_expired_for_dashboard()
			? __( 'Expired', 'dsm-supreme-modules-pro-for-divi' )
			: '';
	}

	/**
	 * Renewal hint markup when the licence is expired (localized link to My Account).
	 *
	 * @return string Safe HTML snippet or empty string.
	 */
	protected function dsm_license_expired_renew_hint_html_for_dashboard(): string {
		if ( ! $this->dsm_license_is_expired_for_dashboard() ) {
			return '';
		}

		$url        = esc_url( $this->dsm_license_renewal_account_url() );
		$link_inner = esc_html__( 'Renew through your Divi Supreme account', 'dsm-supreme-modules-pro-for-divi' );
		$link       = sprintf(
			'<a href="%s" class="dsm-license-renewal-link" target="_blank" rel="noopener noreferrer">%s</a>',
			$url,
			$link_inner
		);
		$lead       = esc_html__( 'Your license has expired.', 'dsm-supreme-modules-pro-for-divi' );

		$html = '<span class="dsm-license-expired-hint">' . $lead . ' ' . $link . '.</span>';

		return wp_kses(
			$html,
			array(
				'span' => array(
					'class' => true,
				),
				'a'    => array(
					'href'   => true,
					'class'  => true,
					'target' => true,
					'rel'    => true,
				),
			)
		);
	}

	/**
	 * AJAX payload fragment: licence expiry line + expired UI hints for `dsm_license` tab (camelCase keys).
	 *
	 * @return array<string, mixed>
	 */
	protected function dsm_license_dashboard_ajax_state_payload(): array {
		return array(
			'expiryDisplay'        => $this->dsm_license_expiry_display_string_for_dashboard(),
			'licenseExpired'       => $this->dsm_license_is_expired_for_dashboard(),
			'expiredBadgeLabel'    => $this->dsm_license_expired_badge_label_for_dashboard(),
			'expiredRenewHintHtml' => $this->dsm_license_expired_renew_hint_html_for_dashboard(),
		);
	}

	/**
	 * AJAX payload fragment after licence is cleared / inactive (camelCase keys).
	 *
	 * @return array<string, mixed>
	 */
	protected function dsm_license_dashboard_cleared_ajax_state_payload(): array {
		return array(
			'expiryDisplay'        => '',
			'licenseExpired'       => false,
			'expiredBadgeLabel'    => '',
			'expiredRenewHintHtml' => '',
		);
	}

	/**
	 * Licence tab UX: activate vs deactivate branch (locals always see informational messaging in React).
	 *
	 * @return bool
	 */
	protected function dsm_license_tab_shows_active_state(): bool {
		if ( $this->dsm_settings_is_marketplace_build() ) {
			return true;
		}

		if ( $this->dsm_license_is_local_instance() ) {
			return false;
		}

		return $this->dsm_license_has_nonempty_stored_key();
	}

	/**
	 * Non-empty licence key saved in network/site option.
	 *
	 * @return bool
	 */
	protected function dsm_license_has_nonempty_stored_key(): bool {
		$license_data = get_site_option( 'dsm_pro_license', array() );

		return is_array( $license_data )
			&& isset( $license_data['key'] )
			&& '' !== trim( (string) $license_data['key'] );
	}

	/**
	 * Persist settings submitted from the dashboard via admin-ajax.
	 *
	 * Verifies {@see wp_verify_nonce()} and `manage_options` before persisting. Sanitization runs through
	 * {@see SettingsApi::sanitize_options()} and section merge logic (including Misc options such as
	 * `dsm_defer_js_assets`).
	 *
	 * @return void
	 */
	public function dsm_ajax_save_settings(): void {
		if (
			! isset( $_POST['_wpnonce'], $_POST['option_page'] )
			|| ! wp_verify_nonce(
				sanitize_key( wp_unslash( (string) $_POST['_wpnonce'] ) ),
				sanitize_text_field( wp_unslash( (string) $_POST['option_page'] ) ) . '-options'
			)
		) {
			wp_send_json_error(
				array(
					'message' => __( 'Security check failed.', 'dsm-supreme-modules-pro-for-divi' ),
				)
			);
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error(
				array(
					'message' => __( 'You do not have permission to save settings.', 'dsm-supreme-modules-pro-for-divi' ),
				)
			);
		}

        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce and manage_options verified above.
		$option_page = isset( $_POST['option_page'] ) ? sanitize_text_field( wp_unslash( $_POST['option_page'] ) ) : '';

		$definitions = $this->get_settings_fields();

		if ( '' === $option_page || ! isset( $definitions[ $option_page ] ) ) {
			wp_send_json_error(
				array(
					'message' => __( 'Invalid settings section.', 'dsm-supreme-modules-pro-for-divi' ),
				)
			);
		}

		if ( 'dsm_license' === $option_page ) {
			$this->dsm_ajax_save_license_settings();
			return;
		}

		$merged = $this->dsm_merge_posted_section_options( $option_page, $definitions[ $option_page ] );

		if (
			'dsm_general' === $option_page
			&& class_exists( \DiviSupreme\Extensions\ClientHandoff::class )
		) {
			\DiviSupreme\Extensions\ClientHandoff::maybe_restore_on_extension_disable( $merged );
		}

		if (
			'dsm_settings_misc' === $option_page
			&& class_exists( \DiviSupreme\Extensions\MaintenanceMode::class )
		) {
			$merged = \DiviSupreme\Extensions\MaintenanceMode::normalize_schedule_in_options( $merged );
		}

		if (
			'dsm_settings_protection' === $option_page
			&& class_exists( \DiviSupreme\Extensions\PasswordProtection::class )
		) {
			$merged = \DiviSupreme\Extensions\PasswordProtection::normalize_options_after_save( $merged );
		}

		if (
			'dsm_settings_contact_form_pro' === $option_page
			&& class_exists( \DiviSupreme\Extensions\ContactFormEntries::class )
		) {
			$merged = \DiviSupreme\Extensions\ContactFormEntries::normalize_options_after_save( $merged );
		}

		if (
			'dsm_settings_preloader' === $option_page
			&& class_exists( \DiviSupreme\Extensions\Preloader::class )
		) {
			$merged = \DiviSupreme\Extensions\Preloader::normalize_options_after_save( $merged );
		}

		update_option( $option_page, $merged );

		$response = array(
			'message' => __( 'Settings saved successfully.', 'dsm-supreme-modules-pro-for-divi' ),
		);

		$refreshed = $this->dsm_dashboard_refreshed_sections_after_save( $option_page );

		if ( array() !== $refreshed ) {
			$response['refreshedSections'] = $refreshed;
		}

		if ( 'dsm_general' === $option_page ) {
			$response['maskPatternLibrary'] = $this->dsm_settings_dashboard_mask_pattern_library_localize_payload();
		}

		wp_send_json_success( $response );
	}

	/**
	 * Saves licence activation / deactivation from the dashboard (admin-ajax).
	 *
	 * @return void
	 */
	protected function dsm_ajax_save_license_settings(): void {
        // phpcs:disable WordPress.Security.NonceVerification.Missing -- Nonce and manage_options verified in dsm_ajax_save_settings() before this runs.
		if ( $this->dsm_settings_is_marketplace_build() ) {
			wp_send_json_error(
				array(
					'message' => __( 'License activation is not used in this distribution.', 'dsm-supreme-modules-pro-for-divi' ),
				)
			);
		}

		$license_row = isset( $_POST['dsm_pro_license_key'] )
			? sanitize_text_field( wp_unslash( (string) $_POST['dsm_pro_license_key'] ) )
			: '';

		$old_license_data = get_site_option( 'dsm_pro_license', array() );
		$old_key          = '';

		if ( is_array( $old_license_data ) && isset( $old_license_data['key'] ) ) {
			$old_key = (string) $old_license_data['key'];
		}

		/*
		 * UX: skipping server round-trip when masked / unchanged mirrors Supreme AI Writer.
		 */
		if (
			'' !== $license_row
			&& ( $license_row === $old_key
				|| false !== strpos( $license_row, '*' )
				|| false !== strpos( $license_row, '•' ) )
		) {
			wp_send_json_success(
				array_merge(
					array(
						'message' => __( 'Settings saved successfully.', 'dsm-supreme-modules-pro-for-divi' ),
					),
					$this->dsm_license_dashboard_ajax_state_payload()
				)
			);
		}

		if ( isset( $_POST['dsm_pro_licence_deactivate'] ) && ( 'true' === sanitize_text_field( wp_unslash( (string) $_POST['dsm_pro_licence_deactivate'] ) ) ) ) {
			if ( '' === $old_key && ! $this->dsm_license_is_local_instance() ) {
				wp_send_json_error(
					array(
						'message' => __( 'No license key found to deactivate.', 'dsm-supreme-modules-pro-for-divi' ),
					)
				);

				return;
			}

			if ( $this->dsm_license_is_local_instance() ) {
				wp_send_json_success(
					array_merge(
						array(
							'message' => __( 'Running on localhost; no remote license applies.', 'dsm-supreme-modules-pro-for-divi' ),
						),
						$this->dsm_license_dashboard_cleared_ajax_state_payload()
					)
				);

				return;
			}

			$remote = dsm_license_remote_deactivate_license_key( $old_key );
			$oc     = (string) $remote['outcome'];
			$o      = dsm_license_remote_deactivate_outcomes();
			/**
			 * Remote license response, when the deactivation call returned one.
			 *
			 * @var object|null $response_block
			 */
			$response_block = isset( $remote['response_block'] ) && is_object( $remote['response_block'] )
				? $remote['response_block']
				: null;

			if ( $o['http_error'] === $oc ) {
				wp_send_json_error(
					array(
						'message' => sprintf(
							/* translators: %s: Licensing API endpoint */
							__( 'There was a problem connecting to %s', 'dsm-supreme-modules-pro-for-divi' ),
							DSM_PRO_APP_API_URL
						),
					)
				);

				return;
			}

			if ( $o['invalid_json'] === $oc ) {
				wp_send_json_error(
					array(
						'message' => sprintf(
							/* translators: %s: Licensing API endpoint */
							__( 'There was a problem with the response from %s', 'dsm-supreme-modules-pro-for-divi' ),
							DSM_PRO_APP_API_URL
						),
					)
				);

				return;
			}

			if ( $o['invalid_block'] === $oc ) {
				wp_send_json_error(
					array(
						'message' => sprintf(
							/* translators: %s: Licensing API endpoint */
							__( 'There was a problem with the data block received from %s', 'dsm-supreme-modules-pro-for-divi' ),
							DSM_PRO_APP_API_URL
						),
					)
				);

				return;
			}

			if ( $o['deactivated_ok'] === $oc ) {
				dsm_license_remote_erase_stored_license();

				wp_send_json_success(
					array_merge(
						array(
							'message' => ( $response_block && isset( $response_block->message ) )
								? (string) $response_block->message
								: __( 'License deactivated successfully.', 'dsm-supreme-modules-pro-for-divi' ),
						),
						$this->dsm_license_dashboard_cleared_ajax_state_payload()
					)
				);

				return;
			}

			if ( $o['force_clear_ok'] === $oc ) {
				dsm_license_remote_erase_stored_license();
			}

			$message_part = '';

			if ( $response_block && isset( $response_block->message ) ) {
				$message_part = ' ' . (string) $response_block->message;
			}

			if ( $o['force_clear_ok'] === $oc || $o['rejected'] === $oc ) {
				wp_send_json_error(
					array(
						'message' => __( 'There was a problem deactivating the license.', 'dsm-supreme-modules-pro-for-divi' )
							. $message_part,
					)
				);

				return;
			}

			wp_send_json_error(
				array(
					'message' => __( 'There was a problem deactivating the license.', 'dsm-supreme-modules-pro-for-divi' ),
				)
			);
		}

		// Activation branch.
		if ( $this->dsm_license_is_local_instance() ) {
			wp_send_json_success(
				array_merge(
					array(
						'message' => __( 'Running on localhost; licensing server calls are skipped.', 'dsm-supreme-modules-pro-for-divi' ),
					),
					$this->dsm_license_dashboard_cleared_ajax_state_payload()
				)
			);

			return;
		}

		$activation_key = isset( $_POST['dsm_pro_license_key'] )
			? trim( sanitize_key( (string) wp_unslash( $_POST['dsm_pro_license_key'] ) ) )
			: '';

		if ( '' === $activation_key ) {
			wp_send_json_error(
				array(
					'message' => __( "License key can't be empty.", 'dsm-supreme-modules-pro-for-divi' ),
				)
			);

			return;
		}

		$activate_args = array(
			'woo_sl_action'     => 'activate',
			'licence_key'       => $activation_key,
			'product_unique_id' => DSM_PRODUCT_ID,
			'domain'            => DSM_PRO_INSTANCE,
		);

		$activate_uri        = DSM_PRO_APP_API_URL . '?' . http_build_query( $activate_args, '', '&' );
		$activation_response = wp_remote_get( $activate_uri );

		if ( is_wp_error( $activation_response ) || 200 !== (int) wp_remote_retrieve_response_code( $activation_response ) ) {
			wp_send_json_error(
				array(
					'message' => sprintf(
						/* translators: %s: Licensing API endpoint */
						__( 'There was a problem connecting to %s', 'dsm-supreme-modules-pro-for-divi' ),
						DSM_PRO_APP_API_URL
					),
				)
			);

			return;
		}

		$activation_body    = wp_remote_retrieve_body( $activation_response );
		$activation_decoded = json_decode( (string) $activation_body );

		if ( ! is_array( $activation_decoded ) || empty( $activation_decoded ) ) {
			wp_send_json_error(
				array(
					'message' => sprintf(
						/* translators: %s: Licensing API endpoint */
						__( 'There was a problem with the response from %s', 'dsm-supreme-modules-pro-for-divi' ),
						DSM_PRO_APP_API_URL
					),
				)
			);

			return;
		}

		$activation_block = $activation_decoded[ count( $activation_decoded ) - 1 ];

		if (
			isset( $activation_block->status )
			&& 'success' === $activation_block->status
			&& isset( $activation_block->status_code )
			&& in_array(
				(string) $activation_block->status_code,
				array( 's100', 's101' ),
				true
			)
		) {
			$raw_status = '';
			if ( isset( $activation_block->licence_status ) && is_string( $activation_block->licence_status ) ) {
				$raw_status = $activation_block->licence_status;
			} elseif ( isset( $activation_block->license_status ) && is_string( $activation_block->license_status ) ) {
				$raw_status = $activation_block->license_status;
			}
			$license_status = '' !== trim( $raw_status )
				? strtolower( sanitize_text_field( trim( $raw_status ) ) )
				: 'active';

			$license_data = array(
				'key'            => $activation_key,
				'last_check'     => time(),
				'expiry_date'    => isset( $activation_block->licence_expire ) ? (string) $activation_block->licence_expire : '',
				'license_status' => $license_status,
			);

			update_site_option( 'dsm_pro_license', $license_data );

			wp_send_json_success(
				array_merge(
					array(
						'message' => isset( $activation_block->message )
							? (string) $activation_block->message
							: __( 'License activated successfully.', 'dsm-supreme-modules-pro-for-divi' ),
					),
					$this->dsm_license_dashboard_ajax_state_payload()
				)
			);

			return;
		}

		$fallback_message = isset( $activation_block->message )
			? (string) $activation_block->message
			: __( 'License activation failed.', 'dsm-supreme-modules-pro-for-divi' );

		wp_send_json_error(
			array(
				'message' => $fallback_message,
			)
		);
        // phpcs:enable WordPress.Security.NonceVerification.Missing
	}

	/**
	 * Normalize posted option array for one section ($option_page) using dashboard field defs.
	 *
	 * @param string $section_id Settings section slug.
	 * @param array<int, array<string, mixed>> $field_defs Field definitions.
	 * @return array<string, mixed>
	 */
	/**
	 * Resolve a controlling field's posted value for `visible_when` checks.
	 *
	 * @param array<int, array<string, mixed>> $field_defs Section field definitions.
	 * @param array<string, mixed>             $posted     Posted section values.
	 * @param string                           $field_name Controlling field name.
	 * @return string
	 */
	protected function dsm_posted_value_for_visible_when( array $field_defs, array $posted, string $field_name ): string {
		$type = 'text';

		foreach ( $field_defs as $field ) {
			if ( (string) ( $field['name'] ?? '' ) !== $field_name ) {
				continue;
			}
			$type = isset( $field['type'] ) ? (string) $field['type'] : 'text';
			break;
		}

		if ( 'checkbox' === $type ) {
			return isset( $posted[ $field_name ] ) && 'on' === $posted[ $field_name ] ? 'on' : 'off';
		}

		return isset( $posted[ $field_name ] ) ? (string) $posted[ $field_name ] : '';
	}

	/**
	 * Whether a field should be read from POST (`visible_when` satisfied).
	 *
	 * @param array<string, mixed>             $field      Field definition.
	 * @param array<int, array<string, mixed>> $field_defs All section fields.
	 * @param array<string, mixed>             $posted     Posted section values.
	 * @return bool
	 */
	protected function dsm_field_visible_when_satisfied( array $field, array $field_defs, array $posted ): bool {
		if ( empty( $field['visible_when'] ) || ! is_array( $field['visible_when'] ) ) {
			return true;
		}

		$dep = isset( $field['visible_when']['field'] ) ? (string) $field['visible_when']['field'] : '';
		$eq  = isset( $field['visible_when']['equals'] ) ? (string) $field['visible_when']['equals'] : '';

		if ( '' === $dep ) {
			return true;
		}

		return $this->dsm_posted_value_for_visible_when( $field_defs, $posted, $dep ) === $eq;
	}

	/**
	 * Keep a stored option when a dependent field is hidden in the UI.
	 *
	 * @param string               $section_id Section option name.
	 * @param string               $name       Field name.
	 * @param array<string, mixed> $field      Field definition.
	 * @return mixed
	 */
	protected function dsm_preserved_option_when_hidden( string $section_id, string $name, array $field ) {
		$existing = get_option( $section_id, array() );
		if ( ! is_array( $existing ) ) {
			$existing = array();
		}

		if ( array_key_exists( $name, $existing ) ) {
			return $existing[ $name ];
		}

		$type = isset( $field['type'] ) ? (string) $field['type'] : 'text';

		if ( 'multicheck' === $type ) {
			return isset( $field['default'] ) && is_array( $field['default'] ) ? $field['default'] : array();
		}

		if ( 'checkbox' === $type ) {
			return isset( $field['default'] ) ? (string) $field['default'] : 'off';
		}

		return isset( $field['default'] ) ? $field['default'] : '';
	}

	/**
	 * Merge a posted settings section onto its field defaults.
	 *
	 * @param string                           $section_id Settings section slug.
	 * @param array<int, array<string, mixed>> $field_defs Field definitions for that section.
	 * @return array<string, mixed>
	 */
	protected function dsm_merge_posted_section_options( string $section_id, array $field_defs ): array {
        // phpcs:disable ET.Sniffs.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.NonceVerification.Missing -- Nonce verified in dsm_ajax_save_settings(); each field sanitized by type below and via sanitize_options().
		$posted = isset( $_POST[ $section_id ] ) && is_array( $_POST[ $section_id ] )
			? wp_unslash( $_POST[ $section_id ] )
			: array();
        // phpcs:enable ET.Sniffs.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.NonceVerification.Missing

		$merged = array();

		foreach ( $field_defs as $field ) {
			$type = isset( $field['type'] ) ? (string) $field['type'] : 'text';
			$name = isset( $field['name'] ) ? (string) $field['name'] : '';

			if ( '' === $name || 'subheading' === $type ) {
				continue;
			}

			/*
			 * Dependent fields are omitted from the form when hidden. Preserve stored
			 * values so toggling “Enable … by default” off does not wipe keys/settings.
			 */
			if ( ! $this->dsm_field_visible_when_satisfied( $field, $field_defs, $posted ) ) {
				$merged[ $name ] = $this->dsm_preserved_option_when_hidden( $section_id, $name, $field );
				continue;
			}

			if ( 'checkbox' === $type ) {
				if ( ! empty( $field['always_enabled'] ) ) {
					$merged[ $name ] = 'on';
					continue;
				}

				/*
				 * Hidden UI fields are not POSTed — keep stored value so unrelated Misc saves do not overwrite.
				 */
				if ( ! empty( $field['hidden_in_settings_ui'] ) ) {
					$existing        = get_option( $section_id, array() );
					$prev            = is_array( $existing ) && array_key_exists( $name, $existing ) ? $existing[ $name ] : null;
					$merged[ $name ] = is_string( $prev ) && '' !== $prev
						? $prev
						: ( isset( $field['default'] ) ? (string) $field['default'] : 'off' );

					continue;
				}

				$merged[ $name ] = isset( $posted[ $name ] ) && 'on' === $posted[ $name ] ? 'on' : 'off';

				continue;
			}

			if ( 'multicheck' === $type ) {
				$current      = array();
				$posted_group = isset( $posted[ $name ] ) && is_array( $posted[ $name ] )
					? $posted[ $name ]
					: array();

				foreach ( array_keys( $field['options'] ?? array() ) as $opt_key ) {
					if (
						isset( $posted_group[ $opt_key ] )
						&& '' !== trim( (string) $posted_group[ $opt_key ] )
					) {
						$current[ $opt_key ] = (string) $posted_group[ $opt_key ];

						continue;
					}
				}

				$merged[ $name ] = $current;

				continue;
			}

			if ( 'color' === $type ) {
				$raw_color       = isset( $posted[ $name ] ) ? (string) $posted[ $name ] : '';
				$validated       = sanitize_hex_color( $raw_color );
				$merged[ $name ] = false !== $validated ? $validated : '';

				continue;
			}

			if ( 'file' === $type ) {
				$merged[ $name ] = isset( $posted[ $name ] ) ? esc_url_raw( (string) $posted[ $name ] ) : '';

				continue;
			}

			if ( 'select' === $type ) {
				$raw_select = isset( $posted[ $name ] ) ? sanitize_text_field( (string) $posted[ $name ] ) : '';
				$allowed    = isset( $field['options'] ) && is_array( $field['options'] )
					? array_map( 'strval', array_keys( $field['options'] ) )
					: array();

				if ( '' !== $raw_select && ( empty( $allowed ) || in_array( $raw_select, $allowed, true ) ) ) {
					$merged[ $name ] = $raw_select;
				} else {
					$merged[ $name ] = isset( $field['default'] )
						? sanitize_text_field( (string) $field['default'] )
						: '';
				}

				continue;
			}

			if ( in_array( $type, array( 'settings_group', 'action_button', 'license' ), true ) ) {
				continue;
			}

			if ( 'password_entries' === $type ) {
				$raw_entries = isset( $posted[ $name ] ) ? (string) $posted[ $name ] : '[]';
				// Keep JSON as-is for sanitize_callback (do not strip structure via sanitize_text_field).
				$merged[ $name ] = $raw_entries;
				continue;
			}

			if ( 'scope_page_picker' === $type ) {
				$merged[ $name ] = isset( $posted[ $name ] )
					? sanitize_text_field( (string) $posted[ $name ] )
					: '';
				continue;
			}

			if ( 'textarea' === $type ) {
				$merged[ $name ] = isset( $posted[ $name ] )
					? sanitize_textarea_field( (string) $posted[ $name ] )
					: '';

				if ( '' === $merged[ $name ] && isset( $field['default'] ) && ! isset( $posted[ $name ] ) ) {
					$merged[ $name ] = sanitize_textarea_field( (string) $field['default'] );
				}

				continue;
			}

			$merged[ $name ] = isset( $posted[ $name ] ) ? sanitize_text_field( (string) $posted[ $name ] ) : '';

			if ( '' === $merged[ $name ] && isset( $field['default'] ) && 'text' === $type && ! isset( $posted[ $name ] ) ) {
				$merged[ $name ] = sanitize_text_field( (string) $field['default'] );
			}
		}

		return $this->settings_api->sanitize_options( $merged );
	}

	/**
	 * Remind admins to activate when no valid key is configured (locals are skipped).
	 *
	 * Closing the notice is saved by DSM_NOTICE from shared/persist-admin-notices-dismissal.
	 *
	 * @return void
	 */
	public function dsm_render_missing_license_notice(): void {
		if ( $this->dsm_settings_is_marketplace_build() ) {
			return;
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		if ( $this->dsm_license_key_verify() ) {
			return;
		}

		if ( class_exists( '\DSM_NOTICE' ) && ! \DSM_NOTICE::is_admin_notice_active( 'disable-done-notice-forever' ) ) {
			return;
		}

		$screen_id = '';

		if ( function_exists( 'get_current_screen' ) ) {
			$screen = get_current_screen();

			if ( $screen instanceof \WP_Screen ) {
				$screen_id = $screen->id;
			}
		}

		if ( 'toplevel_page_divi_supreme_settings' === $screen_id ) {
			return;
		}

		$settings_url = add_query_arg(
			array(
				'page' => 'divi_supreme_settings',
				'tab'  => 'dsm_license',
			),
			admin_url( 'admin.php' )
		);

		?>
		<div data-dismissible="disable-done-notice-forever" class="notice notice-info is-dismissible">
			<p>
				<strong><?php esc_html_e( 'Divi Supreme Pro:', 'dsm-supreme-modules-pro-for-divi' ); ?></strong>
				<?php
				echo ' ';
				echo wp_kses(
					sprintf(
						/* translators: %s: Dashboard URL linking to Licence tab text. */
						__( 'Please enter your %s on the Divi Supreme Pro dashboard to receive updates.', 'dsm-supreme-modules-pro-for-divi' ),
						'<a href="' . esc_url( $settings_url ) . '">' . esc_html__( 'license key', 'dsm-supreme-modules-pro-for-divi' ) . '</a>'
					),
					array(
						'a' => array(
							'href' => array(),
						),
					)
				);
				?>
			</p>
		</div>
		<?php
	}

	/**
	 * Field definitions for each settings section.
	 *
	 * @return array<string, array<int, array<string, mixed>>>
	 */
	public function get_settings_fields() {
		$settings_fields = array(
			'dsm_modules'                   => \DiviSupreme\Core\ModuleRegistry::build_dsm_modules_settings_fields(),
			'dsm_general'                   => \DiviSupreme\Core\ExtensionDashboardRows::build_dsm_general_settings_fields(),
			'dsm_handoff'                   => array(),
			'dsm_client_guide'              => array(),
			'dsm_icon_libraries'            => \DiviSupreme\Core\IconLibrariesDashboardRows::build_settings_fields(),
			'dsm_mask_pattern_library'      => \DiviSupreme\Core\MaskPatternLibraryDashboardRows::build_settings_fields(),
			'dsm_theme_builder'             => array(
				array(
					'name'    => 'dsm_theme_builder_header_fixed',
					'class'   => 'dsm-settings-checkbox',
					'label'   => __( 'Enable Fixed Header', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'    => __( 'This will make the Divi Theme Builder Header stay fixed to the top. For developers, the fixed header CSS Class Selector is ".dsm_fixed_header"', 'dsm-supreme-modules-pro-for-divi' ),
					'type'    => 'checkbox',
					'default' => 'off',
				),
				array(
					'name'    => 'dsm_theme_builder_header_fixed_devices',
					'label'   => __( 'Disable On', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'    => __( 'This will disable the fixed header on selected devices.', 'dsm-supreme-modules-pro-for-divi' ),
					'type'    => 'multicheck',
					'options' => array(
						'tablet' => 'Tablet',
						'phone'  => 'Phone',
					),
				),
				array(
					'name'    => 'dsm_theme_builder_header_auto_calc',
					'class'   => 'dsm-settings-checkbox',
					'label'   => __( 'Push Body Down', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'    => __( 'This will calculate the Divi Theme Builder Header height automatically and apply the height to the body to prevent the first section from overlapping. This will push the first section down based on the header height. This is not needed if you have a transparent background for the header.', 'dsm-supreme-modules-pro-for-divi' ),
					'type'    => 'checkbox',
					'default' => 'off',
				),
				array(
					'name'              => 'dsm_theme_builder_header_start_threshold',
					'label'             => __( 'On Scroll Threshold', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'              => __( 'You can define when the header should take effect after viewport. (Default: 200)', 'dsm-supreme-modules-pro-for-divi' ),
					'type'              => 'text',
					'default'           => '200',
					'sanitize_callback' => 'sanitize_text_field',
				),
				array(
					'name'  => 'dsm_theme_builder_header_scroll_options',
					'label' => __( 'Scrolling', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'  => __( 'Here you can make changes to the element on scroll.' ),
					'type'  => 'subheading',
				),
				array(
					'name'    => 'dsm_theme_builder_header_scroll',
					'class'   => 'dsm-settings-checkbox',
					'label'   => __( 'Enable Scrolling Options', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'    => __( 'This will enable the scrolling elements configured below. For developers, the active scroll CSS Class Selector is ".dsm_fixed_header_scroll_active"', 'dsm-supreme-modules-pro-for-divi' ),
					'type'    => 'checkbox',
					'default' => 'off',
				),
				array(
					'name'    => 'dsm_theme_builder_header_first_section_background_color',
					'label'   => __( '#1 Section Background Color', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'    => __( 'Change the background color for the first section in the Header on scroll.', 'dsm-supreme-modules-pro-for-divi' ),
					'type'    => 'color',
					'default' => '',
				),
				array(
					'name'    => 'dsm_theme_builder_header_second_section_background_color',
					'label'   => __( '#2 Section Background Color', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'    => __( 'Change the background color for the second section in the Header on scroll.', 'dsm-supreme-modules-pro-for-divi' ),
					'type'    => 'color',
					'default' => '',
				),
				array(
					'name'    => 'dsm_theme_builder_header_show_box_shadow_scroll',
					'class'   => 'dsm-settings-checkbox',
					'label'   => __( 'Show Box Shadow on Scroll', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'    => __( 'This will hide the box shadow on page load and show on shrink threshold.', 'dsm-supreme-modules-pro-for-divi' ),
					'type'    => 'checkbox',
					'default' => 'off',
				),
				array(
					'name'  => 'dsm_theme_builder_header_shrink_options',
					'label' => __( 'Shrink', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'  => __( 'Here you can make changes to the shrink elements.' ),
					'type'  => 'subheading',
				),
				array(
					'name'    => 'dsm_theme_builder_header_shrink',
					'class'   => 'dsm-settings-checkbox',
					'label'   => __( 'Enable Shrink on Scroll', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'    => __( 'This will shrink your Divi Theme Builder Header and stays fixed when you scroll. For developers, the active shrink CSS Class Selector is ".dsm_fixed_header_shrink_active"', 'dsm-supreme-modules-pro-for-divi' ),
					'type'    => 'checkbox',
					'default' => 'off',
				),

				/*
				 * Shrink devices field, kept for a future release.
				 *
				 * array(
				 *     'name'    => 'dsm_theme_builder_header_shrink_devices',
				 *     'label'   => __( 'Disable On', 'dsm-supreme-modules-pro-for-divi' ),
				 *     'desc'    => __( 'This will disable the shrink effect on selected devices.', 'dsm-supreme-modules-pro-for-divi' ),
				 *     'type'    => 'multicheck',
				 *     'options' => array(
				 *         'tablet' => 'Tablet',
				 *         'phone'  => 'Phone',
				 *     ),
				 * ),
				 */
				array(
					'name'              => 'dsm_theme_builder_header_section_padding',
					'label'             => __( 'Shrink Section Padding (px)', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'              => __( 'If Shrink on Scroll is enabled, you can define a custom top and bottom padding in pixel(px) value for the section when shrinked.', 'dsm-supreme-modules-pro-for-divi' ),
					'type'              => 'text',
					'default'           => '',
					'sanitize_callback' => 'sanitize_text_field',
				),
				array(
					'name'              => 'dsm_theme_builder_header_row_padding',
					'label'             => __( 'Shrink Row Padding (px)', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'              => __( 'If Shrink on Scroll is enabled, you can define a custom top and bottom padding in pixel(px) value for the row when shrinked.', 'dsm-supreme-modules-pro-for-divi' ),
					'type'              => 'text',
					'default'           => '',
					'sanitize_callback' => 'sanitize_text_field',
				),
				array(
					'name'              => 'dsm_theme_builder_header_menu_padding',
					'label'             => __( 'Shrink Menu Module Padding (px)', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'              => __( 'If Shrink on Scroll is enabled, you can define a custom top and bottom padding in pixel(px) value for the menu module when shrinked.', 'dsm-supreme-modules-pro-for-divi' ),
					'type'              => 'text',
					'default'           => '',
					'sanitize_callback' => 'sanitize_text_field',
				),
				array(
					'name'              => 'dsm_theme_builder_header_shrink_image',
					'label'             => __( 'Shrink Image (%)', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'              => __( 'If Shrink on Scroll is enabled, you can define a max-width in percentage(%) value when shrinked. (Default: 70)', 'dsm-supreme-modules-pro-for-divi' ),
					'type'              => 'text',
					'default'           => '70',
					'sanitize_callback' => 'sanitize_text_field',
				),
				array(
					'name'    => 'dsm_theme_builder_header_shrink_logo',
					'label'   => __( 'Switch Logo Image on Shrink', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'    => __( 'If Shrink on Scroll is enabled, you can change the logo image when shrinked.', 'dsm-supreme-modules-pro-for-divi' ),
					'type'    => 'file',
					'default' => '',
					'options' => array(
						'button_label' => 'Choose Image',
					),
				),
			),
			'dsm_settings_social_media'     => array(
				array(
					'name'              => 'dsm_facebook_app_id',
					'icon'              => Assets::getAssetPath( 'dashboard/rows/facebook.svg' ),
					'label'             => __( 'Facebook APP ID', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'              => sprintf(
						'Enter the Facebook App ID. You can go to <a href="%1$s" target="_blank">Facebook Developer</a> and click on Create New App to get one.',
						esc_url( 'https://developers.facebook.com/apps/' )
					),
					'default'           => ' ',
					'type'              => 'text',
					'sanitize_callback' => 'sanitize_text_field',
				),
				array(
					'name'    => 'dsm_facebook_site_lang',
					'icon'    => Assets::getAssetPath( 'dashboard/rows/translate.svg' ),
					'class'   => 'dsm-settings-checkbox',
					'label'   => __( 'Facebook Language', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'    => __( 'Check this box if you would like your Divi Facebook Modules to use your WordPress Site Language instead of the default English(US).', 'dsm-supreme-modules-pro-for-divi' ),
					'type'    => 'checkbox',
					'default' => 'off',
				),
			),
			'dsm_settings_preloader'        => class_exists( \DiviSupreme\Extensions\Preloader::class )
				? \DiviSupreme\Extensions\Preloader::get_dashboard_fields()
				: array(),
			'dsm_settings_protection'       => array(
				array(
					'type'    => 'settings_group',
					'name'    => 'dsm_protection_group_overview',
					'label'   => __( 'Overview', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'    => __( 'Sitewide password gate status. Maintenance Mode wins when it is actively serving visitors.', 'dsm-supreme-modules-pro-for-divi' ),
					'variant' => 'accent',
				),
				array(
					'type'  => 'subheading',
					'name'  => 'dsm_password_protection_status',
					'icon'  => Assets::getAssetPath( 'dashboard/extensions/password-protection.svg' ),
					'label' => __( 'Status: Password Protection is off', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'  => __( 'Sitewide Password Protection is disabled. Enable it below and add at least one password.', 'dsm-supreme-modules-pro-for-divi' ),
				),
				array(
					'type'  => 'settings_group',
					'name'  => 'dsm_protection_group_sitewide',
					'label' => __( 'Sitewide Password Protection', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'  => __( 'Lock the entire front end behind a password. Optionally assign a Divi Library layout that includes the Password Form module.', 'dsm-supreme-modules-pro-for-divi' ),
				),
				array(
					'name'    => 'dsm_password_protection_enabled',
					'icon'    => Assets::getAssetPath( 'dashboard/extensions/password-protection.svg' ),
					'class'   => 'dsm-settings-checkbox',
					'label'   => __( 'Enable sitewide Password Protection', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'    => __( 'When enabled, logged-out visitors must enter an enabled password (unless their IP is allowlisted). Users with Manage Options always bypass.', 'dsm-supreme-modules-pro-for-divi' ),
					'type'    => 'checkbox',
					'default' => 'off',
				),
				array(
					'name'              => 'dsm_password_protection_layout_id',
					'icon'              => Assets::getAssetPath( 'dashboard/rows/layout.svg' ),
					'label'             => __( 'Unlock layout', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'              => sprintf(
						/* translators: %s: link to Divi Library admin */
						__( 'Optional Divi Library layout shown while locked. Include the Password Form module in that layout. Create or edit layouts under %s. If none is selected, a built-in unlock form is used.', 'dsm-supreme-modules-pro-for-divi' ),
						'<a href="' . esc_url( admin_url( 'edit.php?post_type=et_pb_layout' ) ) . '">' . esc_html__( 'Divi Library', 'dsm-supreme-modules-pro-for-divi' ) . '</a>'
					),
					'type'              => 'select',
					'default'           => 'none',
					'options'           => class_exists( \DiviSupreme\Extensions\PasswordProtection::class )
						? \DiviSupreme\Extensions\PasswordProtection::get_layout_select_options()
						: array(
							'none' => __( '— Select Library Layout —', 'dsm-supreme-modules-pro-for-divi' ),
						),
					'sanitize_callback' => array( \DiviSupreme\Extensions\PasswordProtection::class, 'sanitize_layout_option' ),
				),
				array(
					'name'              => 'dsm_password_protection_cookie_ttl_days',
					'icon'              => Assets::getAssetPath( 'dashboard/rows/schedule.svg' ),
					'label'             => __( 'Remember unlock for', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'              => __( 'How long an unlocked browser stays unlocked. Changing passwords invalidates existing unlock cookies immediately.', 'dsm-supreme-modules-pro-for-divi' ),
					'type'              => 'select',
					'default'           => '14',
					'options'           => array(
						'1'  => __( '1 day', 'dsm-supreme-modules-pro-for-divi' ),
						'7'  => __( '7 days', 'dsm-supreme-modules-pro-for-divi' ),
						'14' => __( '14 days', 'dsm-supreme-modules-pro-for-divi' ),
						'30' => __( '30 days', 'dsm-supreme-modules-pro-for-divi' ),
					),
					'sanitize_callback' => array( \DiviSupreme\Extensions\PasswordProtection::class, 'sanitize_cookie_ttl_option' ),
				),
				array(
					'name'              => 'dsm_password_protection_bypass_mode',
					'icon'              => Assets::getAssetPath( 'dashboard/rows/person.svg' ),
					'label'             => __( 'Bypass for logged-in users', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'              => __( 'Optionally let logged-in users skip the sitewide gate without a password. Administrators always bypass. Passwords, unlock cookies, and IP allowlist still apply to everyone else.', 'dsm-supreme-modules-pro-for-divi' ),
					'type'              => 'select',
					'default'           => 'none',
					'options'           => array(
						'none'      => __( 'None', 'dsm-supreme-modules-pro-for-divi' ),
						'logged_in' => __( 'Any logged-in user', 'dsm-supreme-modules-pro-for-divi' ),
						'roles'     => __( 'Selected roles', 'dsm-supreme-modules-pro-for-divi' ),
					),
					'sanitize_callback' => array( \DiviSupreme\Extensions\PasswordProtection::class, 'sanitize_bypass_mode_option' ),
				),
				array(
					'name'         => 'dsm_password_protection_bypass_roles',
					'icon'         => Assets::getAssetPath( 'dashboard/rows/group.svg' ),
					'label'        => __( 'Bypass roles', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'         => __( 'Users with any selected role can skip the sitewide gate without a password. Administrator is not listed because admins always bypass.', 'dsm-supreme-modules-pro-for-divi' ),
					'type'         => 'multicheck',
					'default'      => array(),
					'options'      => class_exists( \DiviSupreme\Extensions\PasswordProtection::class )
						? \DiviSupreme\Extensions\PasswordProtection::get_bypass_role_options_for_settings()
						: array(),
					'visible_when' => array(
						'field'  => 'dsm_password_protection_bypass_mode',
						'equals' => 'roles',
					),
				),
				array(
					// Kept for older readers; synced from bypass mode on save (not shown in UI).
					'name'                  => 'dsm_password_protection_bypass_logged_in',
					'icon'                  => Assets::getAssetPath( 'dashboard/rows/person.svg' ),
					'class'                 => 'dsm-settings-checkbox',
					'label'                 => __( 'Allow logged-in users to bypass', 'dsm-supreme-modules-pro-for-divi' ),
					'type'                  => 'checkbox',
					'default'               => 'off',
					'hidden_in_settings_ui' => true,
				),
				array(
					'type'  => 'settings_group',
					'name'  => 'dsm_protection_group_passwords',
					'label' => __( 'Passwords', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'  => __( 'Multiple named passwords. Any enabled password unlocks the sitewide cookie. Passwords are stored as hashes only — they are never shown again after save. To lock a single page instead (or as well), open that page in the editor and use the Divi Supreme Password Protection box.', 'dsm-supreme-modules-pro-for-divi' ),
				),
				array(
					'name'              => 'dsm_password_protection_entries',
					'icon'              => Assets::getAssetPath( 'dashboard/rows/password.svg' ),
					'label'             => __( 'Passwords', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'              => __( 'Add one or more passwords. Leave the password field blank on an existing row to keep it unchanged. New rows require a password. Saved passwords are never shown again.', 'dsm-supreme-modules-pro-for-divi' ),
					'type'              => 'password_entries',
					'default'           => array(),
					'sanitize_callback' => array( \DiviSupreme\Extensions\PasswordProtection::class, 'sanitize_entries_option' ),
				),
				array(
					'type'  => 'settings_group',
					'name'  => 'dsm_protection_group_ip',
					'label' => __( 'IP allowlist', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'  => __( 'Matching visitors skip the password gate. One IPv4/IPv6 address or CIDR per line.', 'dsm-supreme-modules-pro-for-divi' ),
				),
				array(
					'name'              => 'dsm_password_protection_ip_allowlist',
					'icon'              => Assets::getAssetPath( 'dashboard/rows/lan.svg' ),
					'label'             => __( 'Allowed IPs / CIDRs', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'              => __( 'Example: <code>203.0.113.10</code> or <code>203.0.113.0/24</code>. Lines starting with # are ignored.', 'dsm-supreme-modules-pro-for-divi' ),
					'type'              => 'textarea',
					'default'           => '',
					'rows'              => 5,
					'sanitize_callback' => array( \DiviSupreme\Extensions\PasswordProtection::class, 'sanitize_ip_allowlist_option' ),
				),
			),
			'dsm_settings_contact_form_pro' => array(
				array(
					'type'    => 'settings_group',
					'name'    => 'dsm_cf_group_overview',
					'icon'    => Assets::getAssetPath( 'dashboard/extensions/contact-form-entries.svg' ),
					'label'   => __( 'Overview', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'    => __( 'Companion settings for Contact Form Pro (Divi’s native Contact Form). Entries appear under Divi Supreme → Form Entries. These options do not replace Divi’s own spam/captcha settings.', 'dsm-supreme-modules-pro-for-divi' ),
					'variant' => 'accent',
				),
				array(
					'type'  => 'settings_group',
					'name'  => 'dsm_cf_group_honeypot',
					'label' => __( 'Honeypot', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'  => __( 'Site default for Divi Contact Form blocks. Each form can override this under Content → Supreme Spam Protection. Filled honeypots are stored as Spam and Divi’s admin notification email is blocked.', 'dsm-supreme-modules-pro-for-divi' ),
				),
				array(
					'name'    => 'dsm_cf_honeypot',
					'icon'    => Assets::getAssetPath( 'dashboard/rows/bug.svg' ),
					'class'   => 'dsm-settings-checkbox',
					'label'   => __( 'Enable honeypot by default', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'    => __( 'Used when a Contact Form’s Honeypot setting is “Use site setting”. Forms set to On/Off ignore this.', 'dsm-supreme-modules-pro-for-divi' ),
					'type'    => 'checkbox',
					'default' => 'on',
				),
				array(
					'type'  => 'settings_group',
					'name'  => 'dsm_cf_group_turnstile',
					'label' => __( 'Cloudflare Turnstile', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'  => __( 'Site keys for Turnstile. Enable per form (or by default below) under Content → Supreme Spam Protection. Failed checks are stored as Spam and Divi’s admin notification email is blocked. Prefer only one interactive challenge (Turnstile or hCaptcha) per form.', 'dsm-supreme-modules-pro-for-divi' ),
				),
				array(
					'name'    => 'dsm_cf_turnstile_enabled',
					'icon'    => Assets::getAssetPath( 'dashboard/rows/verified-user.svg' ),
					'class'   => 'dsm-settings-checkbox',
					'label'   => __( 'Enable Turnstile by default', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'    => __( 'Used when a Contact Form’s Turnstile setting is “Use site setting”. Requires Site Key and Secret Key.', 'dsm-supreme-modules-pro-for-divi' ),
					'type'    => 'checkbox',
					'default' => 'off',
				),
				array(
					'name'         => 'dsm_cf_turnstile_site_key',
					'icon'         => Assets::getAssetPath( 'dashboard/rows/shield.svg' ),
					'label'        => __( 'Turnstile site key', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'         => __( 'Public site key from the Cloudflare Turnstile dashboard.', 'dsm-supreme-modules-pro-for-divi' ),
					'type'         => 'text',
					'default'      => '',
					'visible_when' => array(
						'field'  => 'dsm_cf_turnstile_enabled',
						'equals' => 'on',
					),
				),
				array(
					'name'         => 'dsm_cf_turnstile_secret_key',
					'icon'         => Assets::getAssetPath( 'dashboard/rows/lock.svg' ),
					'label'        => __( 'Turnstile secret key', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'         => __( 'Secret key used for server-side verification. Never expose this in frontend HTML.', 'dsm-supreme-modules-pro-for-divi' ),
					'type'         => 'text',
					'default'      => '',
					'visible_when' => array(
						'field'  => 'dsm_cf_turnstile_enabled',
						'equals' => 'on',
					),
				),
				array(
					'name'         => 'dsm_cf_turnstile_placement',
					'icon'         => Assets::getAssetPath( 'dashboard/rows/place.svg' ),
					'label'        => __( 'Default Turnstile position', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'         => __( 'Used when a form does not set its own position. “Above submit button” keeps the widget full-width on Divi’s flex form layout.', 'dsm-supreme-modules-pro-for-divi' ),
					'type'         => 'select',
					'default'      => 'above_button',
					'options'      => array(
						'above_button' => __( 'Above submit button', 'dsm-supreme-modules-pro-for-divi' ),
						'below_button' => __( 'Below submit button', 'dsm-supreme-modules-pro-for-divi' ),
						'above_fields' => __( 'Above form fields', 'dsm-supreme-modules-pro-for-divi' ),
					),
					'visible_when' => array(
						'field'  => 'dsm_cf_turnstile_enabled',
						'equals' => 'on',
					),
				),
				array(
					'name'         => 'dsm_cf_turnstile_align',
					'icon'         => Assets::getAssetPath( 'dashboard/rows/align.svg' ),
					'label'        => __( 'Default Turnstile alignment', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'         => __( 'Horizontal alignment of the Turnstile widget. Defaults to right to match Divi’s submit button.', 'dsm-supreme-modules-pro-for-divi' ),
					'type'         => 'select',
					'default'      => 'right',
					'options'      => array(
						'left'   => __( 'Left', 'dsm-supreme-modules-pro-for-divi' ),
						'center' => __( 'Center', 'dsm-supreme-modules-pro-for-divi' ),
						'right'  => __( 'Right', 'dsm-supreme-modules-pro-for-divi' ),
					),
					'visible_when' => array(
						'field'  => 'dsm_cf_turnstile_enabled',
						'equals' => 'on',
					),
				),
				array(
					'type'  => 'settings_group',
					'name'  => 'dsm_cf_group_hcaptcha',
					'label' => __( 'hCaptcha', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'  => __( 'Site keys from the hCaptcha dashboard. Enable per form (or by default below) under Content → Supreme Spam Protection. Failed checks are stored as Spam and Divi’s admin notification email is blocked. Prefer only one interactive challenge (Turnstile or hCaptcha) per form.', 'dsm-supreme-modules-pro-for-divi' ),
				),
				array(
					'name'    => 'dsm_cf_hcaptcha_enabled',
					'icon'    => Assets::getAssetPath( 'dashboard/rows/verified-user.svg' ),
					'class'   => 'dsm-settings-checkbox',
					'label'   => __( 'Enable hCaptcha by default', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'    => __( 'Used when a Contact Form’s hCaptcha setting is “Use site setting”. Requires Site Key and Secret Key.', 'dsm-supreme-modules-pro-for-divi' ),
					'type'    => 'checkbox',
					'default' => 'off',
				),
				array(
					'name'         => 'dsm_cf_hcaptcha_site_key',
					'icon'         => Assets::getAssetPath( 'dashboard/rows/shield.svg' ),
					'label'        => __( 'hCaptcha site key', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'         => __( 'Public site key from the hCaptcha dashboard.', 'dsm-supreme-modules-pro-for-divi' ),
					'type'         => 'text',
					'default'      => '',
					'visible_when' => array(
						'field'  => 'dsm_cf_hcaptcha_enabled',
						'equals' => 'on',
					),
				),
				array(
					'name'         => 'dsm_cf_hcaptcha_secret_key',
					'icon'         => Assets::getAssetPath( 'dashboard/rows/lock.svg' ),
					'label'        => __( 'hCaptcha secret key', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'         => __( 'Secret key used for server-side verification. Never expose this in frontend HTML.', 'dsm-supreme-modules-pro-for-divi' ),
					'type'         => 'text',
					'default'      => '',
					'visible_when' => array(
						'field'  => 'dsm_cf_hcaptcha_enabled',
						'equals' => 'on',
					),
				),
				array(
					'name'         => 'dsm_cf_hcaptcha_placement',
					'icon'         => Assets::getAssetPath( 'dashboard/rows/place.svg' ),
					'label'        => __( 'Default hCaptcha position', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'         => __( 'Used when a form does not set its own position. “Above submit button” keeps the widget full-width on Divi’s flex form layout.', 'dsm-supreme-modules-pro-for-divi' ),
					'type'         => 'select',
					'default'      => 'above_button',
					'options'      => array(
						'above_button' => __( 'Above submit button', 'dsm-supreme-modules-pro-for-divi' ),
						'below_button' => __( 'Below submit button', 'dsm-supreme-modules-pro-for-divi' ),
						'above_fields' => __( 'Above form fields', 'dsm-supreme-modules-pro-for-divi' ),
					),
					'visible_when' => array(
						'field'  => 'dsm_cf_hcaptcha_enabled',
						'equals' => 'on',
					),
				),
				array(
					'name'         => 'dsm_cf_hcaptcha_align',
					'icon'         => Assets::getAssetPath( 'dashboard/rows/align.svg' ),
					'label'        => __( 'Default hCaptcha alignment', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'         => __( 'Horizontal alignment of the hCaptcha widget. Defaults to right to match Divi’s submit button.', 'dsm-supreme-modules-pro-for-divi' ),
					'type'         => 'select',
					'default'      => 'right',
					'options'      => array(
						'left'   => __( 'Left', 'dsm-supreme-modules-pro-for-divi' ),
						'center' => __( 'Center', 'dsm-supreme-modules-pro-for-divi' ),
						'right'  => __( 'Right', 'dsm-supreme-modules-pro-for-divi' ),
					),
					'visible_when' => array(
						'field'  => 'dsm_cf_hcaptcha_enabled',
						'equals' => 'on',
					),
				),
				array(
					'type'  => 'settings_group',
					'name'  => 'dsm_cf_group_file_upload',
					'label' => __( 'File upload', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'  => __( 'Limits for Supreme Contact Field (Type → File). Add a File field inside the Contact Form; files upload before Divi’s AJAX submit. Uploaded files are stored in Contact Form Entries. The admin notification email lists the filename only (not as an email attachment). Optional attachment to the visitor confirmation email is under Autoresponder.', 'dsm-supreme-modules-pro-for-divi' ),
				),
				array(
					'name'    => 'dsm_cf_file_max_mb',
					'icon'    => Assets::getAssetPath( 'dashboard/rows/upload-file.svg' ),
					'label'   => __( 'Max file size (MB)', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'    => __( 'Maximum size per file (1–64). Also limited by the server upload_max_filesize.', 'dsm-supreme-modules-pro-for-divi' ),
					'type'    => 'text',
					'default' => '5',
				),
				array(
					'name'    => 'dsm_cf_file_allowed',
					'icon'    => Assets::getAssetPath( 'dashboard/rows/attachment.svg' ),
					'label'   => __( 'Allowed extensions', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'    => __( 'Comma-separated list, e.g. <code>pdf,jpg,png,docx</code>.', 'dsm-supreme-modules-pro-for-divi' ),
					'type'    => 'text',
					'default' => 'pdf,jpg,jpeg,png,gif,webp,doc,docx,txt,zip',
				),
				array(
					'type'  => 'settings_group',
					'name'  => 'dsm_cf_group_submit_loader',
					'label' => __( 'Submit loading indicator', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'  => __( 'Shows a curated loader while Divi’s AJAX submit (and file pre-upload) runs. Native Divi only fades the form. Override per form under Design → Supreme Submit Loader.', 'dsm-supreme-modules-pro-for-divi' ),
				),
				array(
					'name'    => 'dsm_cf_loader_enabled',
					'icon'    => Assets::getAssetPath( 'dashboard/rows/progress.svg' ),
					'class'   => 'dsm-settings-checkbox',
					'label'   => __( 'Enable submit loader by default', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'    => __( 'Used when a Contact Form’s Submit loader setting is “Use site setting”.', 'dsm-supreme-modules-pro-for-divi' ),
					'type'    => 'checkbox',
					'default' => 'off',
				),
				array(
					'name'         => 'dsm_cf_loader_style',
					'icon'         => Assets::getAssetPath( 'dashboard/rows/tune.svg' ),
					'label'        => __( 'Default style', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'         => __( 'Visual preset for the loading indicator.', 'dsm-supreme-modules-pro-for-divi' ),
					'type'         => 'select',
					'default'      => 'spinner',
					'options'      => array(
						'spinner' => __( 'Spinner', 'dsm-supreme-modules-pro-for-divi' ),
						'dots'    => __( 'Dots', 'dsm-supreme-modules-pro-for-divi' ),
						'pulse'   => __( 'Pulse ring', 'dsm-supreme-modules-pro-for-divi' ),
						'button'  => __( 'Button busy only', 'dsm-supreme-modules-pro-for-divi' ),
					),
					'visible_when' => array(
						'field'  => 'dsm_cf_loader_enabled',
						'equals' => 'on',
					),
				),
				array(
					'name'         => 'dsm_cf_loader_color',
					'icon'         => Assets::getAssetPath( 'dashboard/rows/palette-color.svg' ),
					'label'        => __( 'Default color', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'         => __( 'CSS color for the indicator (e.g. <code>#2ea3f2</code>).', 'dsm-supreme-modules-pro-for-divi' ),
					'type'         => 'text',
					'default'      => '#2ea3f2',
					'visible_when' => array(
						'field'  => 'dsm_cf_loader_enabled',
						'equals' => 'on',
					),
				),
				array(
					'name'         => 'dsm_cf_loader_size',
					'icon'         => Assets::getAssetPath( 'dashboard/rows/format-size.svg' ),
					'label'        => __( 'Default size', 'dsm-supreme-modules-pro-for-divi' ),
					'type'         => 'select',
					'default'      => 'md',
					'options'      => array(
						'sm' => __( 'Small', 'dsm-supreme-modules-pro-for-divi' ),
						'md' => __( 'Medium', 'dsm-supreme-modules-pro-for-divi' ),
						'lg' => __( 'Large', 'dsm-supreme-modules-pro-for-divi' ),
					),
					'visible_when' => array(
						'field'  => 'dsm_cf_loader_enabled',
						'equals' => 'on',
					),
				),
				array(
					'name'         => 'dsm_cf_loader_placement',
					'icon'         => Assets::getAssetPath( 'dashboard/rows/place.svg' ),
					'label'        => __( 'Default placement', 'dsm-supreme-modules-pro-for-divi' ),
					'type'         => 'select',
					'default'      => 'button',
					'options'      => array(
						'button'  => __( 'On submit button', 'dsm-supreme-modules-pro-for-divi' ),
						'overlay' => __( 'Form overlay', 'dsm-supreme-modules-pro-for-divi' ),
					),
					'visible_when' => array(
						'field'  => 'dsm_cf_loader_enabled',
						'equals' => 'on',
					),
				),
				array(
					'name'         => 'dsm_cf_loader_button_text',
					'icon'         => Assets::getAssetPath( 'dashboard/rows/text.svg' ),
					'label'        => __( 'Default busy button text', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'         => __( 'Replaces the submit label while Divi’s AJAX submit (or file pre-upload) is pending. Leave blank to use “Submitting…”.', 'dsm-supreme-modules-pro-for-divi' ),
					'type'         => 'text',
					'default'      => __( 'Submitting…', 'dsm-supreme-modules-pro-for-divi' ),
					'visible_when' => array(
						'field'  => 'dsm_cf_loader_enabled',
						'equals' => 'on',
					),
				),
				array(
					'type'  => 'settings_group',
					'name'  => 'dsm_cf_group_blacklist',
					'label' => __( 'Blacklist', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'  => __( 'Matching submissions are still stored, but marked as Spam so you can review them. One value per line. Lines starting with # are ignored.', 'dsm-supreme-modules-pro-for-divi' ),
				),
				array(
					'name'              => 'dsm_cf_blacklist_emails',
					'icon'              => Assets::getAssetPath( 'dashboard/rows/block.svg' ),
					'label'             => __( 'Blocked emails', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'              => __( 'Exact email addresses (case-insensitive), e.g. <code>spam@example.com</code>.', 'dsm-supreme-modules-pro-for-divi' ),
					'type'              => 'textarea',
					'default'           => '',
					'rows'              => 4,
					'sanitize_callback' => array( \DiviSupreme\Extensions\ContactFormEntries::class, 'sanitize_list_option' ),
				),
				array(
					'name'              => 'dsm_cf_blacklist_domains',
					'icon'              => Assets::getAssetPath( 'dashboard/rows/domain.svg' ),
					'label'             => __( 'Blocked email domains', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'              => __( 'Domain only, e.g. <code>mailinator.com</code>. Subdomains match when the domain is a suffix.', 'dsm-supreme-modules-pro-for-divi' ),
					'type'              => 'textarea',
					'default'           => '',
					'rows'              => 4,
					'sanitize_callback' => array( \DiviSupreme\Extensions\ContactFormEntries::class, 'sanitize_list_option' ),
				),
				array(
					'name'              => 'dsm_cf_blacklist_keywords',
					'icon'              => Assets::getAssetPath( 'dashboard/rows/block.svg' ),
					'label'             => __( 'Blocked keywords', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'              => __( 'If a keyword appears in any submitted field value (or email), the entry is marked Spam.', 'dsm-supreme-modules-pro-for-divi' ),
					'type'              => 'textarea',
					'default'           => '',
					'rows'              => 4,
					'sanitize_callback' => array( \DiviSupreme\Extensions\ContactFormEntries::class, 'sanitize_list_option' ),
				),
				array(
					'type'  => 'settings_group',
					'name'  => 'dsm_cf_group_autoresponder',
					'label' => __( 'Autoresponder', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'  => __( 'Send a confirmation email to the submitter after a successful (non-spam) entry is stored. Placeholders: <code>{{name}}</code>, <code>{{email}}</code>, <code>{{site_name}}</code>, <code>{{site_url}}</code>, <code>{{fields}}</code>.', 'dsm-supreme-modules-pro-for-divi' ),
				),
				array(
					'name'    => 'dsm_cf_autoresponder_enabled',
					'icon'    => Assets::getAssetPath( 'dashboard/rows/mail.svg' ),
					'class'   => 'dsm-settings-checkbox',
					'label'   => __( 'Enable autoresponder', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'    => __( 'Emails the submitter (not the site admin) after a non-spam entry is stored. Requires a valid email field on the form. Check the entry’s Autoresponder status if nothing arrives.', 'dsm-supreme-modules-pro-for-divi' ),
					'type'    => 'checkbox',
					'default' => 'off',
				),
				array(
					'name'         => 'dsm_cf_autoresponder_subject',
					'icon'         => Assets::getAssetPath( 'dashboard/rows/subject.svg' ),
					'label'        => __( 'Email subject', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'         => __( 'Supports the same placeholders as the message body.', 'dsm-supreme-modules-pro-for-divi' ),
					'type'         => 'text',
					'default'      => __( 'Thanks for contacting us', 'dsm-supreme-modules-pro-for-divi' ),
					'visible_when' => array(
						'field'  => 'dsm_cf_autoresponder_enabled',
						'equals' => 'on',
					),
				),
				array(
					'name'              => 'dsm_cf_autoresponder_message',
					'icon'              => Assets::getAssetPath( 'dashboard/rows/message.svg' ),
					'label'             => __( 'Email message', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'              => __( 'Plain-text message sent to the submitter.', 'dsm-supreme-modules-pro-for-divi' ),
					'type'              => 'textarea',
					'default'           => class_exists( \DiviSupreme\Extensions\ContactFormEntries::class )
						? \DiviSupreme\Extensions\ContactFormEntries::default_autoresponder_message()
						: '',
					'rows'              => 8,
					'sanitize_callback' => array( \DiviSupreme\Extensions\ContactFormEntries::class, 'sanitize_autoresponder_message' ),
					'visible_when'      => array(
						'field'  => 'dsm_cf_autoresponder_enabled',
						'equals' => 'on',
					),
				),
				array(
					'name'         => 'dsm_cf_autoresponder_from_name',
					'icon'         => Assets::getAssetPath( 'dashboard/rows/person.svg' ),
					'label'        => __( 'From name', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'         => __( 'Optional. Defaults to the site title.', 'dsm-supreme-modules-pro-for-divi' ),
					'type'         => 'text',
					'default'      => '',
					'visible_when' => array(
						'field'  => 'dsm_cf_autoresponder_enabled',
						'equals' => 'on',
					),
				),
				array(
					'name'         => 'dsm_cf_autoresponder_from_email',
					'icon'         => Assets::getAssetPath( 'dashboard/rows/mail.svg' ),
					'label'        => __( 'From email', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'         => __( 'Optional. Leave blank so your SMTP plugin sets the From address (recommended). Only set this if it matches an address your mail provider allows.', 'dsm-supreme-modules-pro-for-divi' ),
					'type'         => 'text',
					'default'      => '',
					'visible_when' => array(
						'field'  => 'dsm_cf_autoresponder_enabled',
						'equals' => 'on',
					),
				),
				array(
					'name'         => 'dsm_cf_autoresponder_attach_files',
					'icon'         => Assets::getAssetPath( 'dashboard/rows/attachment.svg' ),
					'class'        => 'dsm-settings-checkbox',
					'label'        => __( 'Attach uploaded files to autoresponder email', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'         => __( 'When the form includes a Supreme Contact Field (Type → File), attach those files to the confirmation email. Files are sent as local attachments (private uploads are never emailed as public URLs).', 'dsm-supreme-modules-pro-for-divi' ),
					'type'         => 'checkbox',
					'default'      => 'off',
					'visible_when' => array(
						'field'  => 'dsm_cf_autoresponder_enabled',
						'equals' => 'on',
					),
				),
				array(
					'type'  => 'settings_group',
					'name'  => 'dsm_cf_group_retention',
					'label' => __( 'GDPR retention', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'  => __( 'Automatically and permanently delete stored entries older than the retention period (runs daily via WP-Cron).', 'dsm-supreme-modules-pro-for-divi' ),
				),
				array(
					'name'    => 'dsm_cf_retention_enabled',
					'icon'    => Assets::getAssetPath( 'dashboard/rows/auto-delete.svg' ),
					'class'   => 'dsm-settings-checkbox',
					'label'   => __( 'Enable automatic deletion', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'    => __( 'When enabled, expired entries are force-deleted (not moved to Trash).', 'dsm-supreme-modules-pro-for-divi' ),
					'type'    => 'checkbox',
					'default' => 'off',
				),
				array(
					'name'              => 'dsm_cf_retention_days',
					'icon'              => Assets::getAssetPath( 'dashboard/rows/schedule.svg' ),
					'label'             => __( 'Retain entries for (days)', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'              => __( 'Minimum 1, maximum 3650 (10 years). Default 90.', 'dsm-supreme-modules-pro-for-divi' ),
					'type'              => 'text',
					'input_type'        => 'number',
					'default'           => '90',
					'sanitize_callback' => array( \DiviSupreme\Extensions\ContactFormEntries::class, 'sanitize_retention_days_option' ),
					'visible_when'      => array(
						'field'  => 'dsm_cf_retention_enabled',
						'equals' => 'on',
					),
				),
				array(
					'name'         => 'dsm_cf_retention_keep_starred',
					'icon'         => Assets::getAssetPath( 'dashboard/rows/stars.svg' ),
					'class'        => 'dsm-settings-checkbox',
					'label'        => __( 'Keep starred entries', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'         => __( 'Starred entries are never auto-deleted while this is on. Unstar them to allow purge.', 'dsm-supreme-modules-pro-for-divi' ),
					'type'         => 'checkbox',
					'default'      => 'on',
					'visible_when' => array(
						'field'  => 'dsm_cf_retention_enabled',
						'equals' => 'on',
					),
				),
				array(
					'type'  => 'settings_group',
					'name'  => 'dsm_cf_group_webhooks',
					'label' => __( 'Webhooks', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'  => __( 'POST a JSON payload to your URL after an entry is stored. Optional HMAC signature header: <code>X-DSM-Signature: sha256=&lt;hex&gt;</code>.', 'dsm-supreme-modules-pro-for-divi' ),
				),
				array(
					'name'    => 'dsm_cf_webhook_enabled',
					'icon'    => Assets::getAssetPath( 'dashboard/rows/webhook.svg' ),
					'class'   => 'dsm-settings-checkbox',
					'label'   => __( 'Enable webhook', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'    => __( 'Delivery is queued via WP-Cron shortly after the entry is saved.', 'dsm-supreme-modules-pro-for-divi' ),
					'type'    => 'checkbox',
					'default' => 'off',
				),
				array(
					'name'              => 'dsm_cf_webhook_url',
					'icon'              => Assets::getAssetPath( 'dashboard/rows/webhook.svg' ),
					'label'             => __( 'Webhook URL', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'              => __( 'HTTPS recommended. Must accept POST with <code>application/json</code>.', 'dsm-supreme-modules-pro-for-divi' ),
					'type'              => 'text',
					'input_type'        => 'url',
					'default'           => '',
					'sanitize_callback' => array( \DiviSupreme\Extensions\ContactFormEntries::class, 'sanitize_webhook_url' ),
					'visible_when'      => array(
						'field'  => 'dsm_cf_webhook_enabled',
						'equals' => 'on',
					),
				),
				array(
					'name'         => 'dsm_cf_webhook_secret',
					'icon'         => Assets::getAssetPath( 'dashboard/rows/https.svg' ),
					'label'        => __( 'Signing secret', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'         => __( 'Optional shared secret used to sign the raw JSON body (HMAC SHA-256).', 'dsm-supreme-modules-pro-for-divi' ),
					'type'         => 'text',
					'default'      => '',
					'visible_when' => array(
						'field'  => 'dsm_cf_webhook_enabled',
						'equals' => 'on',
					),
				),
				array(
					'name'         => 'dsm_cf_webhook_include_spam',
					'icon'         => Assets::getAssetPath( 'dashboard/rows/report.svg' ),
					'class'        => 'dsm-settings-checkbox',
					'label'        => __( 'Send webhooks for spam entries', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'         => __( 'Off by default. Enable if your automation should also receive blacklisted submissions.', 'dsm-supreme-modules-pro-for-divi' ),
					'type'         => 'checkbox',
					'default'      => 'off',
					'visible_when' => array(
						'field'  => 'dsm_cf_webhook_enabled',
						'equals' => 'on',
					),
				),
			),
			'dsm_settings_misc'             => array(
				array(
					'type'  => 'settings_group',
					'name'  => 'dsm_misc_group_performance',
					'label' => __( 'Performance & Assets', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'  => __( 'Control how Divi Supreme loads CSS and JavaScript on the front end.', 'dsm-supreme-modules-pro-for-divi' ),
				),
				array(
					'name'    => 'dsm_dynamic_assets',
					'icon'    => Assets::getAssetPath( 'dashboard/rows/bolt.svg' ),
					'class'   => 'dsm-settings-checkbox',
					'label'   => __( 'Enable Dynamic Assets', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'    => sprintf(
						'Only load CSS/JS files related to Divi Supreme Module and Extension when they are needed on the page. This eliminates all file bloat and greatly improves load times.<br><br>Note: You need to clear <strong>Static CSS File Generation</strong> under Advanced Tab <a href="%1$s" target="_blank">%2$s</a>. Resaving page might be required where the Divi Supreme Modules and Extension are being used if it does not work.',
						esc_url( admin_url( 'admin.php?page=et_divi_options#wrap-builder' ) ),
						esc_html__( 'Theme Options', 'dsm-supreme-modules-pro-for-divi' )
					),
					'type'    => 'checkbox',
					'default' => 'on',
				),
				array(
					'name'    => 'dsm_defer_js_assets',
					'icon'    => Assets::getAssetPath( 'dashboard/rows/timer.svg' ),
					'class'   => 'dsm-settings-checkbox',
					'label'   => __( 'Defer Render-blocking JavaScript', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'    => __( 'Check this box only if you have chosen to delay the loading of JavaScript files that slow down the rendering of your website through your cache plugin.', 'dsm-supreme-modules-pro-for-divi' ),
					'type'    => 'checkbox',
					'default' => 'off',
				),
				array(
					'name'                  => 'dsm_dynamic_assets_compatibility',
					'icon'                  => Assets::getAssetPath( 'dashboard/rows/extension.svg' ),
					'class'                 => 'dsm-settings-checkbox',
					'label'                 => __( 'Dynamic Assets (Compatibility)', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'                  => __( 'Check this box only if you have issue with Dynamic Assets above.', 'dsm-supreme-modules-pro-for-divi' ),
					'type'                  => 'checkbox',
					'default'               => 'off',
					'hidden_in_settings_ui' => true,
				),
				array(
					'type'    => 'settings_group',
					'name'    => 'dsm_misc_group_divi_cache',
					'label'   => __( 'Divi Static Cache', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'    => __( 'Divi stores generated CSS per page. After plugin updates, stale cache can cause styling issues until it is cleared. Divi rebuilds cache automatically on the next page visit.', 'dsm-supreme-modules-pro-for-divi' ),
					'variant' => 'accent',
				),
				array(
					'name'    => 'dsm_auto_clear_divi_cache_on_update',
					'icon'    => Assets::getAssetPath( 'dashboard/rows/refresh.svg' ),
					'class'   => 'dsm-settings-checkbox',
					'label'   => __( 'Auto-clear on plugin update', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'    => __( 'Automatically clears Divi\'s static CSS cache after a Divi Supreme update so styling renders correctly.', 'dsm-supreme-modules-pro-for-divi' ),
					'type'    => 'checkbox',
					'default' => 'on',
				),
				array(
					'name'    => 'dsm_show_clear_divi_cache_admin_bar',
					'icon'    => Assets::getAssetPath( 'dashboard/rows/toolbar.svg' ),
					'class'   => 'dsm-settings-checkbox',
					'label'   => __( 'Show Clear Divi Cache button in toolbar', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'    => __( 'Adds a Clear Divi Cache menu to the WordPress admin toolbar with options to clear all cache, this page, or the homepage.', 'dsm-supreme-modules-pro-for-divi' ),
					'type'    => 'checkbox',
					'default' => 'on',
				),
				array(
					'name'         => 'dsm_clear_divi_cache_action',
					'icon'         => Assets::getAssetPath( 'dashboard/rows/cleaning.svg' ),
					'label'        => __( 'Manual cache clear', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'         => __( 'Clear Divi\'s static CSS/JS cache for the entire site now.', 'dsm-supreme-modules-pro-for-divi' ),
					'type'         => 'action_button',
					'button_label' => __( 'Clear Divi Cache', 'dsm-supreme-modules-pro-for-divi' ),
				),
				array(
					'type'  => 'settings_group',
					'name'  => 'dsm_misc_group_updates',
					'label' => __( 'Plugin Updates', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'  => __( 'Choose whether to receive early beta releases or stay on the stable update channel.', 'dsm-supreme-modules-pro-for-divi' ),
				),
				array(
					'name'    => 'dsm_allow_beta_updates',
					'icon'    => Assets::getAssetPath( 'dashboard/rows/science.svg' ),
					'class'   => 'dsm-settings-checkbox',
					'label'   => __( 'Allow Beta Updates', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'    => __( 'Enable this option to receive early beta updates. Beta updates may include new features and fixes that have not yet been fully tested. Recommended for advanced users only. When disabled, only stable public releases are offered via the standard update channel.', 'dsm-supreme-modules-pro-for-divi' ),
					'type'    => 'checkbox',
					'default' => 'off',
				),
				array(
					'type'          => 'settings_group',
					'name'          => 'dsm_misc_group_site_maintenance',
					'label'         => __( 'Maintenance & Coming Soon', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'          => __( 'Show a Divi Library layout to visitors for temporary maintenance or a pre-launch Coming Soon page. Design the layout in Divi Library first, then assign it here. Use HTTP 503 for maintenance, or 200 for Coming Soon.', 'dsm-supreme-modules-pro-for-divi' ),
					'variant'       => 'accent',
					'documentation' => DocumentationUrls::settings_doc_url( 'dsm_misc_group_site_maintenance' ),
				),
				array(
					'name'    => 'dsm_maintenance_mode_enabled',
					'icon'    => Assets::getAssetPath( 'dashboard/rows/construction.svg' ),
					'class'   => 'dsm-settings-checkbox',
					'label'   => __( 'Enable visitor page', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'    => __( 'Master switch. When enabled, visitors see the assigned Divi Library layout during the active schedule window (or immediately if no schedule is set). Administrators with Manage Options always bypass.', 'dsm-supreme-modules-pro-for-divi' ),
					'type'    => 'checkbox',
					'default' => 'off',
				),
				array(
					'type'  => 'subheading',
					'name'  => 'dsm_maintenance_mode_status',
					'icon'  => Assets::getAssetPath( 'dashboard/rows/construction.svg' ),
					'label' => __( 'Status: Maintenance Mode is off', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'  => __( 'Visitor page is disabled. Enable it above to show the assigned layout to visitors.', 'dsm-supreme-modules-pro-for-divi' ),
				),
				array(
					'name'              => 'dsm_maintenance_mode_start',
					'icon'              => Assets::getAssetPath( 'dashboard/rows/event.svg' ),
					'label'             => __( 'Start date & time', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'              => __( 'Optional. Leave empty to start as soon as this feature is enabled.', 'dsm-supreme-modules-pro-for-divi' )
						. ' '
						. (
							class_exists( \DiviSupreme\Extensions\MaintenanceMode::class )
								? \DiviSupreme\Extensions\MaintenanceMode::get_schedule_timezone_help_html()
								: ''
						),
					'type'              => 'text',
					'input_type'        => 'datetime-local',
					'default'           => '',
					'placeholder'       => '',
					'sanitize_callback' => array( \DiviSupreme\Extensions\MaintenanceMode::class, 'sanitize_datetime_option' ),
				),
				array(
					'name'              => 'dsm_maintenance_mode_end',
					'icon'              => Assets::getAssetPath( 'dashboard/rows/event.svg' ),
					'label'             => __( 'End date & time', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'              => __( 'Optional. Leave empty to keep the visitor page on until you disable it. Must be after the start time.', 'dsm-supreme-modules-pro-for-divi' )
						. ' '
						. (
							class_exists( \DiviSupreme\Extensions\MaintenanceMode::class )
								? \DiviSupreme\Extensions\MaintenanceMode::get_schedule_timezone_help_html()
								: ''
						),
					'type'              => 'text',
					'input_type'        => 'datetime-local',
					'default'           => '',
					'placeholder'       => '',
					'sanitize_callback' => array( \DiviSupreme\Extensions\MaintenanceMode::class, 'sanitize_datetime_option' ),
				),
				array(
					'name'              => 'dsm_maintenance_mode_layout_id',
					'icon'              => Assets::getAssetPath( 'dashboard/rows/layout.svg' ),
					'label'             => __( 'Visitor layout', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'              => sprintf(
						/* translators: %s: link to Divi Library admin */
						__( 'Choose a full Divi Library layout for maintenance or Coming Soon. Create or edit layouts under %s. Only published layouts are shown to visitors.', 'dsm-supreme-modules-pro-for-divi' ),
						'<a href="' . esc_url( admin_url( 'edit.php?post_type=et_pb_layout' ) ) . '">' . esc_html__( 'Divi Library', 'dsm-supreme-modules-pro-for-divi' ) . '</a>'
					),
					'type'              => 'select',
					'default'           => 'none',
					'options'           => class_exists( \DiviSupreme\Extensions\MaintenanceMode::class )
						? \DiviSupreme\Extensions\MaintenanceMode::get_layout_select_options()
						: array(
							'none' => __( '— Select Library Layout —', 'dsm-supreme-modules-pro-for-divi' ),
						),
					'sanitize_callback' => array( \DiviSupreme\Extensions\MaintenanceMode::class, 'sanitize_layout_option' ),
				),
				array(
					'name'    => 'dsm_maintenance_mode_bypass_logged_in',
					'icon'    => Assets::getAssetPath( 'dashboard/rows/person.svg' ),
					'class'   => 'dsm-settings-checkbox',
					'label'   => __( 'Allow logged-in users to bypass', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'    => __( 'When enabled, any logged-in user sees the normal site. When disabled (default), only users with Manage Options bypass — safer for staging or pre-launch where editors should also see the visitor page.', 'dsm-supreme-modules-pro-for-divi' ),
					'type'    => 'checkbox',
					'default' => 'off',
				),
				array(
					'name'              => 'dsm_maintenance_mode_http_status',
					'icon'              => Assets::getAssetPath( 'dashboard/rows/http.svg' ),
					'label'             => __( 'HTTP Status', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'              => __( 'Use 503 for temporary maintenance (search engines treat the site as down; recommended for downtime). Use 200 for a Coming Soon / launch page you want crawlers to index.', 'dsm-supreme-modules-pro-for-divi' ),
					'type'              => 'select',
					'default'           => '503',
					'options'           => array(
						'503' => __( '503 Service Unavailable (maintenance)', 'dsm-supreme-modules-pro-for-divi' ),
						'200' => __( '200 OK (Coming Soon)', 'dsm-supreme-modules-pro-for-divi' ),
					),
					'sanitize_callback' => array( \DiviSupreme\Extensions\MaintenanceMode::class, 'sanitize_http_status_option' ),
				),
				array(
					'type'          => 'settings_group',
					'name'          => 'dsm_misc_group_custom_404',
					'label'         => __( 'Custom 404 Page', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'          => __( 'Show a Divi Library layout when a visitor hits a missing URL. Always sends HTTP 404. If Divi Theme Builder already has a 404 template, this feature defers to Theme Builder.', 'dsm-supreme-modules-pro-for-divi' ),
					'variant'       => 'accent',
					'documentation' => DocumentationUrls::settings_doc_url( 'dsm_misc_group_custom_404' ),
				),
				array(
					'name'    => 'dsm_custom_404_enabled',
					'icon'    => Assets::getAssetPath( 'dashboard/rows/error.svg' ),
					'class'   => 'dsm-settings-checkbox',
					'label'   => __( 'Enable custom 404 page', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'    => __( 'When enabled, missing URLs show the assigned Divi Library layout with an HTTP 404 status. Administrators see the same 404 page so they can preview it.', 'dsm-supreme-modules-pro-for-divi' ),
					'type'    => 'checkbox',
					'default' => 'off',
				),
				array(
					'type'  => 'subheading',
					'name'  => 'dsm_custom_404_status',
					'icon'  => Assets::getAssetPath( 'dashboard/rows/error.svg' ),
					'label' => __( 'Status: Custom 404 Page is off', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'  => __( 'Custom 404 Page is disabled. Enable it above and assign a Divi Library layout to replace the default 404 page.', 'dsm-supreme-modules-pro-for-divi' ),
				),
				array(
					'name'              => 'dsm_custom_404_layout_id',
					'icon'              => Assets::getAssetPath( 'dashboard/rows/layout.svg' ),
					'label'             => __( '404 layout', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'              => sprintf(
						/* translators: %s: link to Divi Library admin */
						__( 'Choose a full Divi Library layout for the 404 page. Create or edit layouts under %s. Only published layouts are shown to visitors.', 'dsm-supreme-modules-pro-for-divi' ),
						'<a href="' . esc_url( admin_url( 'edit.php?post_type=et_pb_layout' ) ) . '">' . esc_html__( 'Divi Library', 'dsm-supreme-modules-pro-for-divi' ) . '</a>'
					),
					'type'              => 'select',
					'default'           => 'none',
					'options'           => class_exists( \DiviSupreme\Extensions\Custom404::class )
						? \DiviSupreme\Extensions\Custom404::get_layout_select_options()
						: array(
							'none' => __( '— Select Library Layout —', 'dsm-supreme-modules-pro-for-divi' ),
						),
					'sanitize_callback' => array( \DiviSupreme\Extensions\Custom404::class, 'sanitize_layout_option' ),
				),
				array(
					'type'  => 'settings_group',
					'name'  => 'dsm_misc_group_maintenance',
					'label' => __( 'Data & Uninstall', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'  => __( 'Control what happens to plugin data when Divi Supreme Pro is removed.', 'dsm-supreme-modules-pro-for-divi' ),
				),
				array(
					'name'  => 'dsm_uninstall_on_delete',
					'icon'  => Assets::getAssetPath( 'dashboard/rows/delete-forever.svg' ),
					'class' => 'dsm-settings-checkbox',
					'label' => __( 'Remove Data on Uninstall?', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'  => __( 'Check this box if you would like Divi Supreme to completely remove all of its data when the plugin is deleted.', 'dsm-supreme-modules-pro-for-divi' ),
					'type'  => 'checkbox',
				),
				array(
					'type'  => 'settings_group',
					'name'  => 'dsm_misc_group_media',
					'label' => __( 'Media Uploads', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'  => __( 'Allow additional animation and vector file types in the WordPress Media Library.', 'dsm-supreme-modules-pro-for-divi' ),
				),
				array(
					'name'    => 'dsm_allow_mime_json_upload',
					'icon'    => Assets::getAssetPath( 'dashboard/rows/data-object.svg' ),
					'class'   => 'dsm-settings-checkbox',
					'label'   => __( 'Allow JSON & .lottie uploads', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'    => __( 'When enabled, users who can upload files may add plain .json animations and packaged .lottie (DotLottie / ZIP with manifest.json) via the Media Library—ideal for the Divi Supreme Lottie module. JSON uploads are validated with json_decode(); .lottie archives are inspected as ZIPs (manifest, entry limits, sane sizes)—not arbitrary zips renamed to .lottie. Leave off if your site never needs animation files in Media.', 'dsm-supreme-modules-pro-for-divi' ),
					'type'    => 'checkbox',
					'default' => 'on',
				),
				array(
					'name'    => 'dsm_allow_mime_svg_upload',
					'icon'    => Assets::getAssetPath( 'dashboard/rows/image.svg' ),
					'class'   => 'dsm-settings-checkbox',
					'label'   => __( 'Allow SVG file upload', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'    => __( 'When enabled, SVG and SVGZ uploads are allowed for users who can upload files. Each file is sanitized with an allowlist before it is saved, and files that cannot be made safe are rejected. SVG can still carry risk—only enable for trusted authors and editors.', 'dsm-supreme-modules-pro-for-divi' ),
					'type'    => 'checkbox',
					'default' => 'off',
				),
				array(
					'type'  => 'settings_group',
					'name'  => 'dsm_misc_group_admin_menu',
					'label' => __( 'Admin Menu', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'  => __( 'Customize how Divi Supreme Pro appears in the WordPress admin sidebar.', 'dsm-supreme-modules-pro-for-divi' ),
				),
				array(
					'name'              => 'dsm_plugin_menu_name',
					'icon'              => Assets::getAssetPath( 'dashboard/rows/menu.svg' ),
					'label'             => __( 'Menu Name', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'              => __( 'Change the menu name of Divi Supreme Pro.', 'dsm-supreme-modules-pro-for-divi' ),
					'type'              => 'text',
					'placeholder'       => __( 'Divi Supreme Pro', 'dsm-supreme-modules-pro-for-divi' ),
					'sanitize_callback' => 'sanitize_text_field',
				),
				array(
					'name'              => 'dsm_plugin_menu_icon',
					'icon'              => Assets::getAssetPath( 'dashboard/rows/star.svg' ),
					'label'             => __( 'Menu Icon', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'              => sprintf(
						'Image URL or <a href="%1$s" target="_blank">%2$s</a> to use for icon. Custom image should be 20px by 20px.',
						esc_url( 'https://developer.wordpress.org/resource/dashicons/' ),
						esc_html__( 'Dashicon class name', 'dsm-supreme-modules-pro-for-divi' )
					),
					'type'              => 'text',
					'placeholder'       => __( 'Full URL for icon or Dashicon class', 'dsm-supreme-modules-pro-for-divi' ),
					'sanitize_callback' => 'sanitize_text_field',
				),
			),
			'dsm_license'                   => array(
				array(
					'id'          => 'dsm_pro_license_key',
					'name'        => 'dsm_pro_license_key',
					'icon'        => Assets::getAssetPath( 'dashboard/sections/license.svg' ),
					'label'       => __( 'License Key', 'dsm-supreme-modules-pro-for-divi' ),
					'desc'        => wp_kses_post(
						sprintf(
							/* translators: %s: Link to customer account. */
							__( 'Enter the license key from your purchase to enable updates. Lost your key? Retrieve it from your %s.', 'dsm-supreme-modules-pro-for-divi' ),
							'<a href="https://divisupreme.com/my-account/" target="_blank" rel="noopener noreferrer">' . esc_html__( 'Divi Supreme account', 'dsm-supreme-modules-pro-for-divi' ) . '</a>'
						)
					),
					'type'        => 'license',
					'placeholder' => __( 'Paste your license key here', 'dsm-supreme-modules-pro-for-divi' ),
				),
			),
		);

		if ( $this->dsm_settings_is_marketplace_build() ) {
			unset( $settings_fields['dsm_license'] );

			if (
				isset( $settings_fields['dsm_settings_misc'] )
				&& is_array( $settings_fields['dsm_settings_misc'] )
			) {
				$settings_fields['dsm_settings_misc'] = array_values(
					array_filter(
						$settings_fields['dsm_settings_misc'],
						static function ( $field ): bool {
							return ! is_array( $field )
								|| ( ( $field['name'] ?? '' ) !== 'dsm_allow_beta_updates' );
						}
					)
				);
			}
		}

		return $settings_fields;
	}

	/**
	 * Settings sections shown in the dashboard.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public function get_settings_sections() {
		$sections = array(
			array(
				'id'    => 'dsm_general',
				'icon'  => \DiviSupreme\Core\Assets::getAssetPath( '/dashboard/sections/general.svg' ),
				'title' => __( 'Extensions', 'dsm-supreme-modules-pro-for-divi' ),
				'page'  => array(
					'description' => __( 'This is where you can enable Divi Extensions.', 'dsm-supreme-modules-pro-for-divi' ),
					'title'       => __( 'Divi Supreme Settings', 'dsm-supreme-modules-pro-for-divi' ),
				),
				'nonce' => wp_create_nonce( 'dsm_general-options' ),
			),
			array(
				'id'    => 'dsm_modules',
				'icon'  => \DiviSupreme\Core\Assets::getAssetPath( '/dashboard/sections/module-settings.svg' ),
				'title' => __( 'Modules', 'dsm-supreme-modules-pro-for-divi' ),
				'page'  => array(
					'title'       => __( 'Divi Supreme Modules', 'dsm-supreme-modules-pro-for-divi' ),
					'description' => __( 'The Divi Builder editor will display the activated modules that have been selected.', 'dsm-supreme-modules-pro-for-divi' ),
					'messages'    => array(
						'select_all' => __( 'Select All', 'dsm-supreme-modules-pro-for-divi' ),
					),
					'default'     => 'on',
				),
				'nonce' => wp_create_nonce( 'dsm_modules-options' ),
			),
			array(
				'id'    => 'dsm_icon_libraries',
				'icon'  => \DiviSupreme\Core\Assets::getAssetPath( '/dashboard/sections/icon-libraries.svg' ),
				'title' => __( 'Icon Libraries', 'dsm-supreme-modules-pro-for-divi' ),
				'page'  => array(
					'description' => __( 'Enable webfont icon libraries for the Divi composite icon picker. Each library appears as a Show Only category when enabled.', 'dsm-supreme-modules-pro-for-divi' ),
					'title'       => __( 'Icon Libraries', 'dsm-supreme-modules-pro-for-divi' ),
				),
				'nonce' => wp_create_nonce( 'dsm_icon_libraries-options' ),
			),
			array(
				'id'    => 'dsm_mask_pattern_library',
				'icon'  => \DiviSupreme\Core\Assets::getAssetPath( '/dashboard/sections/mask-pattern-library.svg' ),
				'title' => __( 'Mask & Pattern Library', 'dsm-supreme-modules-pro-for-divi' ),
				'page'  => array(
					'description' => __( 'Choose which Supreme background masks and patterns appear in Divi 5 background pickers. Native Divi masks and patterns are always available.', 'dsm-supreme-modules-pro-for-divi' ),
					'title'       => __( 'Mask & Pattern Library', 'dsm-supreme-modules-pro-for-divi' ),
				),
				'nonce' => wp_create_nonce( 'dsm_mask_pattern_library-options' ),
			),

			/*
			 * Easy Theme Builder — tab hidden for now; section + fields remain in get_settings_fields()
			 * for a future release. Re-add this block and remove dsm_theme_builder from the filters
			 * in dsm_get_settings_sections_for_settings_api(), dsm_get_settings_fields_for_settings_api(),
			 * and dsm_populate_settings_fields_for_dashboard() to restore the tab.
			 *
			 * array(
			 * 'id' => 'dsm_theme_builder',
			 * ...
			 * ),
			 */
			array(
				'id'    => 'dsm_settings_social_media',
				'icon'  => \DiviSupreme\Core\Assets::getAssetPath( '/dashboard/sections/social-media.svg' ),
				'title' => __( 'Social Media', 'dsm-supreme-modules-pro-for-divi' ),
				'page'  => array(
					'title'       => __( 'Social Media Settings', 'dsm-supreme-modules-pro-for-divi' ),
					'description' => __( 'Configure Social Media settings here.', 'dsm-supreme-modules-pro-for-divi' ),
				),
				'nonce' => wp_create_nonce( 'dsm_settings_social_media-options' ),
			),
			array(
				'id'    => 'dsm_settings_preloader',
				'icon'  => \DiviSupreme\Core\Assets::getAssetPath( '/dashboard/sections/preloader.svg' ),
				'title' => __( 'Preloader', 'dsm-supreme-modules-pro-for-divi' ),
				'page'  => array(
					'title'       => __( 'Preloader', 'dsm-supreme-modules-pro-for-divi' ),
					'description' => __( 'Failsafe, scope, and checkout excludes. Design presets, logo, stages, and page transitions in the Visual Builder (builder bar → Preloader).', 'dsm-supreme-modules-pro-for-divi' ),
				),
				'nonce' => wp_create_nonce( 'dsm_settings_preloader-options' ),
			),
			array(
				'id'    => 'dsm_handoff',
				'icon'  => \DiviSupreme\Core\Assets::getAssetPath( '/dashboard/sections/client-handoff.svg' ),
				'title' => __( 'Client Handoff', 'dsm-supreme-modules-pro-for-divi' ),
				'badge' => __( 'Editors', 'dsm-supreme-modules-pro-for-divi' ),
				'page'  => array(
					'title'       => __( 'Client Handoff', 'dsm-supreme-modules-pro-for-divi' ),
					'description' => __( 'Apply a content-only Divi Role Editor profile for Editor. Clients edit copy and images in the Visual Builder. Exit restores the Role Editor snapshot. Administrator is never changed.', 'dsm-supreme-modules-pro-for-divi' ),
				),
				'nonce' => wp_create_nonce( 'dsm_handoff-options' ),
			),
			array(
				'id'    => 'dsm_client_guide',
				'icon'  => \DiviSupreme\Core\Assets::getAssetPath( '/dashboard/sections/general.svg' ),
				'title' => __( 'Client Guide', 'dsm-supreme-modules-pro-for-divi' ),
				'badge' => __( 'Clients', 'dsm-supreme-modules-pro-for-divi' ),
				'page'  => array(
					'title'        => __( 'Client Guide', 'dsm-supreme-modules-pro-for-divi' ),
					'description'  => __( 'Agency welcome details for the Dashboard and the Visual Builder, plus a Client Help Library clients can read.', 'dsm-supreme-modules-pro-for-divi' ),
					'audienceNote' => __( 'Administrators edit this welcome and the Client Help Library. The Handoff role can read the welcome panel and Help. Administrator access is not limited.', 'dsm-supreme-modules-pro-for-divi' ),
				),
				'nonce' => wp_create_nonce( 'dsm_client_guide-options' ),
			),
			array(
				'id'    => 'dsm_settings_protection',
				'icon'  => \DiviSupreme\Core\Assets::getAssetPath( '/dashboard/sections/password-protection.svg' ),
				'title' => __( 'Password Protection', 'dsm-supreme-modules-pro-for-divi' ),
				'page'  => array(
					'title'       => __( 'Password Protection', 'dsm-supreme-modules-pro-for-divi' ),
					'description' => __( 'Sitewide and per-page password gates with multiple passwords, IP allowlist, and an optional Divi Library unlock layout. Maintenance Mode takes precedence when it is actively serving visitors. Protect individual Sections, Rows, and Columns when the Password Protection extension is enabled under Extensions.', 'dsm-supreme-modules-pro-for-divi' ),
				),
				'nonce' => wp_create_nonce( 'dsm_settings_protection-options' ),
			),
			array(
				'id'    => 'dsm_settings_contact_form_pro',
				'icon'  => \DiviSupreme\Core\Assets::getAssetPath( '/dashboard/sections/contact-form-entries.svg' ),
				'title' => __( 'Contact Form Pro', 'dsm-supreme-modules-pro-for-divi' ),
				'page'  => array(
					'title'       => __( 'Contact Form Pro', 'dsm-supreme-modules-pro-for-divi' ),
					'description' => __( 'Use Jump to for honeypot, Turnstile, hCaptcha, file upload, submit loader, blacklist, autoresponder, GDPR retention, and webhooks. Per-form spam overrides live on the Contact Form module (Supreme Spam Protection). Add File fields via Supreme Contact Field. Search also filters these groups.', 'dsm-supreme-modules-pro-for-divi' ),
				),
				'nonce' => wp_create_nonce( 'dsm_settings_contact_form_pro-options' ),
			),
			array(
				'id'    => 'dsm_settings_misc',
				'icon'  => \DiviSupreme\Core\Assets::getAssetPath( '/dashboard/sections/misc.svg' ),
				'title' => __( 'Miscellaneous', 'dsm-supreme-modules-pro-for-divi' ),
				'page'  => array(
					'title'       => __( 'Miscellaneous', 'dsm-supreme-modules-pro-for-divi' ),
					'description' => __( 'Use Jump to for Maintenance & Coming Soon, Custom 404 Page, performance, cache, updates, uploads, and admin menu. Search also filters these groups.', 'dsm-supreme-modules-pro-for-divi' ),
				),
				'nonce' => wp_create_nonce( 'dsm_settings_misc-options' ),
			),
			array(
				'id'    => 'dsm_supreme5_migration',
				'icon'  => \DiviSupreme\Core\Assets::getAssetPath( '/dashboard/sections/convert-legacy-modules.svg' ),
				'title' => __( 'Convert Legacy Modules', 'dsm-supreme-modules-pro-for-divi' ),
				'badge' => __( 'Legacy only', 'dsm-supreme-modules-pro-for-divi' ),
				'page'  => array(
					'title'       => __( 'Convert Legacy Modules', 'dsm-supreme-modules-pro-for-divi' ),
					'description' => __(
						'Migrate Divi 4 Supreme shortcodes to Divi 5 blocks.',
						'dsm-supreme-modules-pro-for-divi'
					),
				),
				'nonce' => wp_create_nonce( 'dsm_supreme5_migration-options' ),
			),
			array(
				'id'    => 'dsm_support',
				'icon'  => \DiviSupreme\Core\Assets::getAssetPath( '/dashboard/sections/support-access.svg' ),
				'title' => __( 'Support', 'dsm-supreme-modules-pro-for-divi' ),
				'badge' => (
					class_exists( \DiviSupreme\Includes\Support\TemporaryAccess::class )
					&& \DiviSupreme\Includes\Support\TemporaryAccess::is_active()
				)
					? __( 'Access on', 'dsm-supreme-modules-pro-for-divi' )
					: '',
				'page'  => array(
					'title'       => __( 'Support', 'dsm-supreme-modules-pro-for-divi' ),
					'description' => __( 'System status for support tickets, and a temporary login you can turn on when Divi Supreme asks for access. Access stays off until you enable it.', 'dsm-supreme-modules-pro-for-divi' ),
				),
				'nonce' => wp_create_nonce( 'dsm_support-options' ),
			),
			array(
				'id'    => 'dsm_license',
				'icon'  => \DiviSupreme\Core\Assets::getAssetPath( '/dashboard/sections/license.svg' ),
				'title' => __( 'License', 'dsm-supreme-modules-pro-for-divi' ),
				'page'  => array(
					'title'       => __( 'Divi Supreme Pro License', 'dsm-supreme-modules-pro-for-divi' ),
					'description' => __( 'Activate or deactivate your product license to receive automatic updates.', 'dsm-supreme-modules-pro-for-divi' ),
				),
				'nonce' => wp_create_nonce( 'dsm_license-options' ),
			),
		);

		if ( $this->dsm_settings_is_marketplace_build() ) {
			$sections = array_values(
				array_filter(
					$sections,
					static function ( $section ): bool {
						return ! is_array( $section ) || ( $section['id'] ?? '' ) !== 'dsm_license';
					}
				)
			);
		}

		return $sections;
	}

	/**
	 * Renders root for the react dashboard to render.
	 *
	 * @return void
	 */
	public function render_root() {
		?>
		<div id="app"></div>
		<?php
	}

	/**
	 * Allow SVG in Media Library when toggle is ON
	 *
	 * @param array<string, string> $mimes Mime types keyed by extension.
	 * @return array<string, string>
	 */
	public function allow_svg_mime_types( $mimes ) {
		if ( ! is_array( $mimes ) ) {
			$mimes = array();
		}

		$allow_svg = $this->settings_api->get_option( 'dsm_allow_mime_svg_upload', 'dsm_settings_misc', 'off' );

		if ( 'on' === $allow_svg ) {
			$mimes['svg']  = 'image/svg+xml';
			$mimes['svgz'] = 'image/svg+xml';
		}

		return $mimes;
	}

	/**
	 * Fix WordPress strict filetype check for SVG after content validation.
	 *
	 * @param array<string, mixed> $data    Filetype data.
	 * @param string               $file    Absolute path to temp file (when uploading).
	 * @param string               $filename Original filename.
	 * @param array<string, mixed> $mimes   Mime map.
	 * @return array<string, mixed>
	 */
	public function fix_svg_filetype( $data, $file, $filename, $mimes ) {
		if ( ! is_array( $data ) ) {
			$data = array();
		}

		$allow_svg = $this->settings_api->get_option( 'dsm_allow_mime_svg_upload', 'dsm_settings_misc', 'off' );

		if ( 'on' !== $allow_svg ) {
			return $this->reject_dsm_sensitive_extensions_when_toggle_off( $data, $filename, array( 'svg', 'svgz' ) );
		}

		if ( ! is_string( $filename ) || '' === $filename ) {
			return $data;
		}

		$ext = strtolower( pathinfo( $filename, PATHINFO_EXTENSION ) );

		if ( 'svg' !== $ext && 'svgz' !== $ext ) {
			return $data;
		}

		if ( ! is_string( $file ) || '' === $file || ! is_readable( $file ) ) {
			return $data;
		}

		if ( ! $this->svg_upload_passes_content_checks( $file, $ext ) ) {
			return $this->reject_upload_filetype( $data );
		}

		$data['ext']  = $ext;
		$data['type'] = 'image/svg+xml';

		return $data;
	}

	/**
	 * Sanitize an SVG temp file before Divi's upload prefilter reads it.
	 *
	 * Runs only while SVG uploads are enabled. Priority 10 stays below Divi
	 * Icon Manager's PHP_INT_MAX callback.
	 *
	 * @param array<string, mixed> $file One element from $_FILES.
	 * @return array<string, mixed>
	 */
	public function sanitize_svg_upload_prefilter( $file ) {
		$allow_svg = $this->settings_api->get_option( 'dsm_allow_mime_svg_upload', 'dsm_settings_misc', 'off' );

		if ( 'on' !== $allow_svg || ! function_exists( 'dsm_svg_upload_prefilter' ) ) {
			return is_array( $file ) ? $file : array();
		}

		return dsm_svg_upload_prefilter( $file );
	}

	/**
	 * Allow JSON / DotLottie (.lottie ZIP) uploads in Media Library when toggle is ON
	 *
	 * @param array<string, string> $mimes Mime types keyed by extension.
	 * @return array<string, string>
	 */
	public function allow_json_mime_types( $mimes ) {
		if ( ! is_array( $mimes ) ) {
			$mimes = array();
		}

		$allow_json = $this->settings_api->get_option( 'dsm_allow_mime_json_upload', 'dsm_settings_misc', 'on' );

		if ( 'on' === $allow_json ) {
			$mimes['json'] = 'application/json';
			// DotLottie is a constrained ZIP bundle; gated by {@see fix_lottie_filetype()}.
			$mimes['lottie'] = 'application/zip';
		}

		return $mimes;
	}

	/**
	 * Fix WordPress strict filetype check for DotLottie (.lottie ZIP) after content validation.
	 *
	 * @param array<string, mixed> $data     Filetype data.
	 * @param string               $file     Absolute path to temp file (when uploading).
	 * @param string               $filename Original filename.
	 * @param array<string, mixed> $mimes    Mime map.
	 * @return array<string, mixed>
	 */
	public function fix_lottie_filetype( $data, $file, $filename, $mimes ) {
		if ( ! is_array( $data ) ) {
			$data = array();
		}

		$allow_bundle = $this->settings_api->get_option( 'dsm_allow_mime_json_upload', 'dsm_settings_misc', 'on' );

		if ( 'on' !== $allow_bundle ) {
			return $this->reject_dsm_sensitive_extensions_when_toggle_off( $data, $filename, array( 'lottie' ) );
		}

		if ( ! is_string( $filename ) || '' === $filename ) {
			return $data;
		}

		$ext = strtolower( pathinfo( $filename, PATHINFO_EXTENSION ) );

		if ( 'lottie' !== $ext ) {
			return $data;
		}

		if ( ! is_string( $file ) || '' === $file || ! is_readable( $file ) ) {
			return $data;
		}

		if ( ! $this->lottie_upload_passes_content_checks( $file ) ) {
			return $this->reject_upload_filetype( $data );
		}

		$data['ext']  = 'lottie';
		$data['type'] = 'application/zip';

		return $data;
	}

	/**
	 * Fix WordPress strict filetype check for JSON after content validation.
	 *
	 * @param array<string, mixed> $data    Filetype data.
	 * @param string               $file    Absolute path to temp file (when uploading).
	 * @param string               $filename Original filename.
	 * @param array<string, mixed> $mimes   Mime map.
	 * @return array<string, mixed>
	 */
	public function fix_json_filetype( $data, $file, $filename, $mimes ) {
		if ( ! is_array( $data ) ) {
			$data = array();
		}

		$allow_json = $this->settings_api->get_option( 'dsm_allow_mime_json_upload', 'dsm_settings_misc', 'on' );

		if ( 'on' !== $allow_json ) {
			return $this->reject_dsm_sensitive_extensions_when_toggle_off( $data, $filename, array( 'json' ) );
		}

		if ( ! is_string( $filename ) || '' === $filename ) {
			return $data;
		}

		$ext = strtolower( pathinfo( $filename, PATHINFO_EXTENSION ) );

		if ( 'json' !== $ext ) {
			return $data;
		}

		if ( ! is_string( $file ) || '' === $file || ! is_readable( $file ) ) {
			return $data;
		}

		if ( ! $this->json_upload_passes_content_checks( $file ) ) {
			return $this->reject_upload_filetype( $data );
		}

		$data['ext']  = 'json';
		$data['type'] = 'application/json';

		return $data;
	}

	/**
	 * When a DSM Miscellaneous mime toggle is OFF, reject uploads that still bear that extension so other
	 * `upload_mimes` filters cannot allow Divi Supreme–controlled types anyway.
	 *
	 * @param array<string, mixed>|null $data        Filetype payload from WordPress.
	 * @param string                    $filename    Original filename from {@see wp_check_filetype_and_ext}.
	 * @param string[]                  $extensions Lowercase extensions without dots.
	 * @return array<string, mixed>
	 */
	private function reject_dsm_sensitive_extensions_when_toggle_off( ?array $data, string $filename, array $extensions ): array {
		if ( ! is_array( $data ) ) {
			$data = array();
		}

		if ( ! is_string( $filename ) || '' === $filename ) {
			return $data;
		}

		$ext = strtolower( pathinfo( $filename, PATHINFO_EXTENSION ) );
		foreach ( $extensions as $denied ) {
			if ( strtolower( (string) $denied ) === $ext ) {
				return $this->reject_upload_filetype( $data );
			}
		}

		return $data;
	}

	/**
	 * Mark filetype as disallowed for the upload pipeline.
	 *
	 * @param array<string, mixed> $data Existing data from WordPress.
	 * @return array<string, mixed>
	 */
	private function reject_upload_filetype( array $data ): array {
		$data['ext']             = false;
		$data['type']            = false;
		$data['proper_filename'] = false;

		return $data;
	}

	/**
	 * Max JSON file size considered for validation (parse-time DoS guard).
	 *
	 * @return positive-int
	 */
	private function get_max_json_validation_bytes(): int {
		/**
		 * Cap JSON upload validation size (default 5 MB).
		 *
		 * @param int $max_bytes Max file size in bytes.
		 */
		$filtered = (int) apply_filters( 'dsm_max_json_upload_validation_bytes', 5 * MB_IN_BYTES );

		return max( 1024, min( 20 * MB_IN_BYTES, $filtered ) );
	}

	/**
	 * Whether a JSON temp file is valid UTF-8 JSON within size limits.
	 *
	 * @param string $absolute_path Absolute path to the uploaded temp file.
	 * @return bool
	 */
	private function json_upload_passes_content_checks( string $absolute_path ): bool {
		$max  = $this->get_max_json_validation_bytes();
		$size = filesize( $absolute_path );

		if ( false === $size || $size < 1 ) {
			return false;
		}

		if ( (int) $size > $max ) {
			return false;
		}

		$contents = file_get_contents( $absolute_path );

		if ( false === $contents || '' === trim( $contents ) ) {
			return false;
		}

		/**
		 * Max nesting depth for JSON validation (Lottie and similar can be deep).
		 *
		 * @param int $max_depth Passed to json_decode().
		 */
		$max_depth = (int) apply_filters( 'dsm_json_upload_decode_max_depth', 1024 );
		$max_depth = max( 32, min( 10000, $max_depth ) );

		json_decode( $contents, true, $max_depth, JSON_BIGINT_AS_STRING );

		return JSON_ERROR_NONE === json_last_error();
	}

	/**
	 * Max .lottie (DotLottie ZIP) bundle size before opening as archive.
	 *
	 * @return positive-int
	 */
	private function get_max_lottie_archive_bytes(): int {
		/**
		 * Max .lottie file size accepted for DotLottie validation (default 40 MB).
		 *
		 * @param int $max_bytes Max archive size in bytes.
		 */
		$filtered = (int) apply_filters( 'dsm_max_lottie_upload_validation_bytes', 40 * MB_IN_BYTES );

		return max(
			(int) ( 512 * KB_IN_BYTES ),
			min( 120 * MB_IN_BYTES, $filtered )
		);
	}

	/**
	 * Validate DotLottie: ZIP with root manifest.json and expected manifest shape.
	 *
	 * @param string $absolute_path Absolute path to the uploaded temp file.
	 * @return bool
	 */
	private function lottie_upload_passes_content_checks( string $absolute_path ): bool {
		if ( ! class_exists( \ZipArchive::class, false ) ) {
			return false;
		}

		$max_archive = $this->get_max_lottie_archive_bytes();
		$fs          = filesize( $absolute_path );

		if ( false === $fs || $fs < 22 ) {
			// Smaller than empty ZIP EOCD (~22 bytes typical minimum for non-empty ZIP is higher).
			return false;
		}

		if ( (int) $fs > $max_archive ) {
			return false;
		}

		$magic = file_get_contents( $absolute_path, false, null, 0, 4 );
		if ( false === $magic || strlen( $magic ) !== 4 ) {
			return false;
		}

		// ZIP local file header magic PK\x03\x04 or empty/special PK\x05\x06.
		if ( "\x50\x4b" !== substr( $magic, 0, 2 ) ) {
			return false;
		}

		/**
		 * Max entries listed in DotLottie archive (zip-slip / resource exhaustion guard).
		 *
		 * @param int $max_files Max number of files in archive.
		 */
		$max_entries = (int) apply_filters( 'dsm_lottie_upload_max_zip_entries', 2000 );
		$max_entries = max( 16, min( 10000, $max_entries ) );

		/**
		 * Max uncompressed size (bytes) for manifest.json inside the archive.
		 *
		 * @param int $max_bytes Max manifest size.
		 */
		$manifest_max = (int) apply_filters( 'dsm_lottie_manifest_max_bytes', KB_IN_BYTES * 512 );
		$manifest_max = max( KB_IN_BYTES, min( MB_IN_BYTES, $manifest_max ) );

		$zip    = new \ZipArchive();
		$opened = $zip->open( $absolute_path );

		if ( true !== $opened ) {
			return false;
		}

		try {
			// phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- ZipArchive names this property numFiles.
			$num = $zip->numFiles;
			if ( $num < 1 || $num > $max_entries ) {
				return false;
			}

			$manifest_index = false;
			$scan_limit     = min( $num, $max_entries );
			for ( $i = 0; $i < $scan_limit; $i++ ) {
				$name = $zip->getNameIndex( $i );

				if ( false === $name || '' === $name || false !== strpos( $name, '..' ) ) {
					continue;
				}

				// Root-only manifest.json (reject path traversal / nested fake roots).
				$norm = str_replace( '\\', '/', (string) $name );
				if ( false !== strpos( $norm, '/' ) ) {
					continue;
				}

				if ( strcasecmp( $norm, 'manifest.json' ) === 0 ) {
					$manifest_index = $i;
					break;
				}
			}

			if ( false === $manifest_index ) {
				return false;
			}

			$st = $zip->statIndex( $manifest_index );

			if ( ! is_array( $st ) || ! isset( $st['size'] ) ) {
				return false;
			}

			if ( (int) $st['size'] < 2 || (int) $st['size'] > $manifest_max ) {
				return false;
			}

			$raw = $zip->getFromIndex( $manifest_index );

			if ( false === $raw || '' === trim( $raw ) ) {
				return false;
			}

			$max_depth = (int) apply_filters( 'dsm_lottie_manifest_json_max_depth', 64 );
			$max_depth = max( 8, min( 256, $max_depth ) );

			$decoded = json_decode( $raw, true, $max_depth, JSON_BIGINT_AS_STRING );

			if ( JSON_ERROR_NONE !== json_last_error() || ! is_array( $decoded ) ) {
				return false;
			}

			// DotLottie manifests declare an animations list (LottieFiles / dotlottie spec baseline).
			if ( ! isset( $decoded['animations'] ) || ! is_array( $decoded['animations'] ) || array() === $decoded['animations'] ) {
				return false;
			}

			$first = $decoded['animations'][0];

			if ( ! is_array( $first ) ) {
				return false;
			}

			if (
				( ! isset( $first['id'] ) || ! is_string( $first['id'] ) || trim( $first['id'] ) === '' )
				&& ( ! isset( $first['file'] ) || ! is_string( $first['file'] ) || ! preg_match( '/\.json\b/i', $first['file'] ) )
			) {
				return false;
			}
		} finally {
			$zip->close();
		}

		return true;
	}

	/**
	 * Sanitize an SVG or SVGZ temp file before WordPress stores it.
	 *
	 * The shared allowlist reads the whole document, including SVGZ after a
	 * capped decompress. Fail closed when that helper is unavailable.
	 *
	 * @param string $absolute_path Absolute path to the uploaded temp file.
	 * @param string $ext           File extension, svg or svgz.
	 * @return bool
	 */
	private function svg_upload_passes_content_checks( string $absolute_path, string $ext ): bool {
		if ( ! function_exists( 'dsm_svg_prepare_upload_file' ) ) {
			return false;
		}

		return dsm_svg_prepare_upload_file( $absolute_path, $ext );
	}

	/**
	 * Whether this plugin copy is the Elegant Themes Marketplace distribution (no licence UI / updater).
	 *
	 * @return bool
	 */
	protected function dsm_settings_is_marketplace_build(): bool {
		return function_exists( 'dsm_is_marketplace_build' ) && dsm_is_marketplace_build();
	}

	/**
	 * Whether license bootstrap/deactivation checks may run on this request (admin only, never public frontend).
	 *
	 * @return bool
	 */
	private function dsm_should_run_license_bootstrap(): bool {
		return is_admin() || wp_doing_ajax();
	}

	/**
	 * Instantiate license validation in admin/ajax contexts (avoids per-frontend-request option reads).
	 *
	 * @return void
	 */
	public function dsm_ensure_license_bootstrapped(): void {
		if ( null !== $this->license || $this->dsm_settings_is_marketplace_build() ) {
			return;
		}

		if ( ! $this->dsm_should_run_license_bootstrap() ) {
			return;
		}

		$this->license = new License();
	}

	/**
	 * Load the license object when the settings screen needs it.
	 *
	 * @return void
	 */
	public function dsm_bootstrap_license(): void {
		$this->dsm_ensure_license_bootstrapped();
	}

	/**
	 * Whether this site is treated as a local license instance.
	 *
	 * @return bool
	 */
	protected function dsm_license_is_local_instance(): bool {
		if ( $this->dsm_settings_is_marketplace_build() ) {
			return true;
		}

		$this->dsm_ensure_license_bootstrapped();

		return $this->license instanceof License && $this->license->is_local_instance();
	}

	/**
	 * Whether the stored license key passes verification.
	 *
	 * @return bool
	 */
	protected function dsm_license_key_verify(): bool {
		if ( $this->dsm_settings_is_marketplace_build() ) {
			return true;
		}

		$this->dsm_ensure_license_bootstrapped();

		return $this->license instanceof License && $this->license->licence_key_verify();
	}

	/**
	 * React dashboard beta channel strings + license gate (Misc → Allow Beta Updates).
	 *
	 * @return array<string, mixed>
	 */
	protected function dsm_settings_dashboard_beta_updates_localize_payload(): array {
		if ( $this->dsm_settings_is_marketplace_build() ) {
			return array(
				'enabled' => false,
			);
		}

		$license_ok = function_exists( 'dsm_beta_current_user_has_valid_license_for_updates' )
			? dsm_beta_current_user_has_valid_license_for_updates()
			: false;

		return array(
			'enabled'             => true,
			'licenseOkForChannel' => $license_ok,
			'strings'             => array(
				'stable'       => __( 'Stable', 'dsm-supreme-modules-pro-for-divi' ),
				'beta'         => __( 'Beta', 'dsm-supreme-modules-pro-for-divi' ),
				'licenseNote'  => __( 'Activate a valid license key to receive beta updates.', 'dsm-supreme-modules-pro-for-divi' ),
				'channelTitle' => __( 'Current update channel', 'dsm-supreme-modules-pro-for-divi' ),
				'warningTitle' => __( 'Warning', 'dsm-supreme-modules-pro-for-divi' ),
				'warningBody'  => __(
					'Beta releases may be unstable or incompatible with some setups. Enable only if you accept that risk.',
					'dsm-supreme-modules-pro-for-divi'
				),
				'regionLabel'  => __( 'Beta update channel', 'dsm-supreme-modules-pro-for-divi' ),
			),
		);
	}

	/**
	 * React dashboard `dsmSettings.license` payload.
	 *
	 * @return array<string, mixed>
	 */
	protected function dsm_settings_dashboard_license_localize_payload(): array {
		if ( $this->dsm_settings_is_marketplace_build() ) {
			return array(
				'isMarketplaceBuild'   => true,
				'local'                => true,
				'active'               => true,
				'expiryDateLabel'      => __( 'Expiry date', 'dsm-supreme-modules-pro-for-divi' ),
				'expiryIcon'           => Assets::getAssetPath( 'dashboard/rows/calendar.svg' ),
				'expiryDisplay'        => '',
				'licenseExpired'       => false,
				'expiredBadgeLabel'    => '',
				'expiredRenewHintHtml' => '',
			);
		}

		return array_merge(
			array(
				'isMarketplaceBuild' => false,
				'local'              => $this->dsm_license_is_local_instance(),
				'active'             => $this->dsm_license_tab_shows_active_state(),
				'expiryDateLabel'    => __( 'Expiry date', 'dsm-supreme-modules-pro-for-divi' ),
				'expiryIcon'         => Assets::getAssetPath( 'dashboard/rows/calendar.svg' ),
			),
			$this->dsm_license_dashboard_ajax_state_payload()
		);
	}
}

new Settings();