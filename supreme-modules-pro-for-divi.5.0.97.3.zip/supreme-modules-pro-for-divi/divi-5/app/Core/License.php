<?php
/**
 * License management.
 *
 * @package DiviSupreme
 */

namespace DiviSupreme\Core;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! defined( 'DSM_PRO_APP_API_URL' ) ) {
	define( 'DSM_PRO_APP_API_URL', 'https://divisupreme.com/index.php' );
}

if ( ! defined( 'DSM_PRODUCT_ID' ) ) {
	define( 'DSM_PRODUCT_ID', 'DSM-PRO' );
}

if ( ! defined( 'DSM_PRO_INSTANCE' ) ) {
	define( 'DSM_PRO_INSTANCE', str_replace( array( 'https://', 'http://' ), '', trim( network_site_url(), '/' ) ) );
}

/**
 * License class handles the verification and management of product licenses.
 *
 * This class is responsible for checking license validity, determining if the
 * instance is running locally, and performing license deactivation checks.
 */
class License {

	/**
	 * Initialize the license class and perform deactivation check.
	 */
	public function __construct() {
		$this->licence_deactivation_check();
	}

	/**
	 * Cleanup when the license object is destroyed.
	 */
	public function __destruct() {
	}

	/**
	 * Verify if a valid license key exists.
	 *
	 * Checks if a license key is stored in site options and returns TRUE if valid,
	 * or if the instance is running locally.
	 *
	 * @return bool TRUE if a valid license exists or instance is local, FALSE otherwise
	 */
	public function licence_key_verify() {
		$license_data = get_site_option( 'dsm_pro_license' );

		if ( $this->is_local_instance() ) {
			return true;
		}

		if ( ! isset( $license_data['key'] ) || '' === $license_data['key'] ) {
			return false;
		}

		return true;
	}

	/**
	 * Check if the current instance is running on a local environment.
	 *
	 * Determines if the current instance is running on localhost, 127.0.0.1, or
	 * a staging environment based on the DSM_PRO_INSTANCE constant.
	 *
	 * @return bool TRUE if instance is local, FALSE otherwise
	 */
	public function is_local_instance() {
		$instance = trailingslashit( DSM_PRO_INSTANCE );
		if ( strpos( $instance, base64_decode( 'bG9jYWxob3N0Lw==' ) ) !== false
			|| strpos( $instance, base64_decode( 'MTI3LjAuMC4xLw==' ) ) !== false
			|| strpos( $instance, base64_decode( 'c3RhZ2luZy53cGVuZ2luZS5jb20=' ) ) !== false ) {
			return true;
		}

		return false;
	}

	/**
	 * Check if the license has been deactivated on the server.
	 *
	 * Performs a status check against the remote API to verify if the license
	 * has been deactivated. Updates the local license data accordingly.
	 *
	 * @return void
	 */
	public function licence_deactivation_check() {
		if ( ! $this->licence_key_verify() || $this->is_local_instance() === true ) {
			return;
		}

		$license_data = get_site_option( 'dsm_pro_license' );

		if ( isset( $license_data['last_check'] ) ) {
			if ( time() < ( $license_data['last_check'] + 86400 ) ) {
				return;
			}
		}

		$license_key = $license_data['key'];
		$args        = array(
			'woo_sl_action'     => 'status-check',
			'licence_key'       => $license_key,
			'product_unique_id' => DSM_PRODUCT_ID,
			'domain'            => DSM_PRO_INSTANCE,
		);
		$request_uri = DSM_PRO_APP_API_URL . '?' . http_build_query( $args, '', '&' );
		$data        = wp_remote_get( $request_uri );

		if ( is_wp_error( $data ) || 200 !== (int) $data['response']['code'] ) {
			return;
		}

		$response_block = json_decode( $data['body'] );
		// Retrieve the last message within the $response_block.
		$response_block = $response_block[ count( $response_block ) - 1 ];
		$response       = $response_block->message;

		if ( isset( $response_block->status ) ) {
			if ( 'success' === $response_block->status ) {
				if ( 's203' === $response_block->status_code || 's204' === $response_block->status_code ) {
					$license_data['key']            = '';
					$license_data['license_status'] = '';
					$license_data['expiry_date']    = '';
				}
			}

			if ( 'error' === $response_block->status ) {
				$license_data['key']            = '';
				$license_data['license_status'] = '';
				$license_data['expiry_date']    = '';
			}
		}

		$license_data['last_check'] = time();
		update_site_option( 'dsm_pro_license', $license_data );
	}
}
