<?php
/**
 * Icon Libraries settings rows (card grid under General when extension is enabled).
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Core;

use DiviSupreme\Extensions\IconLibraries\IconLibraryRegistry;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Per-library card rows for `dsm_icon_libraries` option.
 */
final class IconLibrariesDashboardRows {

	/**
	 * Card text label.
	 *
	 * @param string $title Card title.
	 * @param int    $count Icon count.
	 * @return string
	 */
	private static function card_text_label( string $title, int $count ): string {
		return '<h4>' . esc_html( $title ) . '</h4>'
			. '<p class="dsm-icon-library-card-meta"><strong>' . esc_html(
				sprintf(
					/* translators: %d: number of icons in the library manifest */
					_n( '%d icon', '%d icons', $count, 'dsm-supreme-modules-pro-for-divi' ),
					$count
				)
			) . '</strong></p>';
	}

	/**
	 * Library manager checkbox rows (saved to `dsm_icon_libraries`).
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public static function build_settings_fields(): array {
		if ( ! function_exists( 'dsm_is_icon_libraries_extension_enabled' ) || ! dsm_is_icon_libraries_extension_enabled() ) {
			return array();
		}

		IconLibraryRegistry::boot();

		$fields = array();

		foreach ( IconLibraryRegistry::all() as $library ) {
			$id = $library->get_id();

			$brand_mark = $library->get_brand_mark();
			$default    = 'tabler' === $id ? 'on' : 'off';

			$fields[] = array(
				'name'          => $id,
				'class'         => 'dsm-settings-checkbox dsm-settings-column dsm-icon-library-card',
				'brandMark'     => $brand_mark,
				'label'         => self::card_text_label(
					$library->get_label(),
					$library->get_icon_count()
				),
				'desc'          => $library->get_license_note(),
				'documentation' => DocumentationUrls::icon_libraries_doc_url(),
				'type'          => 'checkbox',
				'default'       => $default,
			);
		}

		return $fields;
	}
}
