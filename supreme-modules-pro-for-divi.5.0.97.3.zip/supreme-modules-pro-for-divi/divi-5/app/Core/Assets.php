<?php
/**
 * Assets Management Class
 *
 * This class provides methods for managing and retrieving asset paths within the plugin.
 * It handles asset path generation for files located in the assets/static directory.
 *
 * @package DiviSupreme
 */

namespace DiviSupreme\Core;

/**
 * Handles asset path management for the plugin.
 *
 * Provides utility methods for retrieving both the base path to assets
 * and specific asset file paths. Designed to work with assets located
 * in the assets/static directory.
 *
 * @since 1.0.0
 */
class Assets {

	/**
	 * Gets the base path to the assets directory.
	 *
	 * Returns the base URL path to the assets directory, up to and including
	 * the 'static' directory. This provides a consistent base for constructing
	 * asset paths within the plugin.
	 *
	 * The path is constructed using the DSM_DIR_URL constant and pointing
	 * to the assets/static directory.
	 *
	 * Example: 'https://example.com/wp-content/plugins/supreme-modules-pro-for-divi/divi-5/assets/static/'
	 *
	 * @since 1.0.0
	 * @return string The base URL path to the assets/static directory.
	 */
	public static function getAssetsBasePath(): string {
		return DSM_DIR_URL . 'assets/static/';
	}

	/**
	 * Gets the full path to a specific asset file.
	 *
	 * Constructs the full URL path to an asset file by combining the base
	 * assets path with the provided relative path. The method ensures
	 * the static directory is properly included in the URL.
	 *
	 * Example: 'images/logo.png', 'css/style.css', 'js/script.js'
	 *
	 * Example: 'https://example.com/wp-content/plugins/supreme-modules-pro-for-divi/divi-5/assets/static/images/logo.png'
	 *
	 * @since 1.0.0
	 * @param string $path The relative path to the asset file within the assets/static directory.
	 * @return string The full URL path to the specified asset file.
	 */
	public static function getAssetPath( string $path ): string {
		$base_path = self::getAssetsBasePath();

		// Sanitize the path to prevent directory traversal vulnerabilities.
		$sanitized_path = ltrim( $path, '/' );

		return $base_path . $sanitized_path;
	}
}
