<?php
/**
 * Frontend and Visual Builder script/style registration for Divi Supreme Pro (Divi 5).
 *
 * Extracted from {@see Divi_Supreme_5} to keep the bootstrap class maintainable.
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Core;

use DiviSupreme\Extensions\PasswordProtection;
use DiviSupreme\Includes\DsmDiviBuilderCssScope;
use DiviSupreme\Includes\DsmFrontendModuleAssetRegistry;
use DiviSupreme\Includes\DsmLibraryLayoutSelectOptions;
use DiviSupreme\Includes\Testimonials\Attrs as TestimonialsAttrs;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Registers and enqueues shared handles used by DSM modules and the VB.
 */
final class Supreme5FrontendAssets {

	/**
	 * Main plugin instance (for {@see Divi_Supreme_5::is_divi_5_installed_and_active()}).
	 *
	 * @var \Divi_Supreme_5
	 */
	private $host;

	/**
	 * Set up the instance.
	 *
	 * @param \Divi_Supreme_5 $host Bootstrap class.
	 */
	public function __construct( $host ) {
		$this->host = $host;
		if ( class_exists( DsmLibraryLayoutSelectOptions::class ) ) {
			DsmLibraryLayoutSelectOptions::register_hooks();
		}
	}

	/**
	 * Register supreme lightbox assets.
	 */
	public function register_supreme_lightbox_assets() {
		if ( wp_script_is( 'dsm-perspective-image', 'registered' ) ) {
			return;
		}

		$version = defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';

		$mfp_handle = function_exists( 'dsm_get_active_magnific_popup_script_handle' )
			? dsm_get_active_magnific_popup_script_handle()
			: '';

		if ( '' === $mfp_handle ) {
			return;
		}

		if ( function_exists( 'dsm_register_magnific_popup_style_if_needed' ) ) {
			dsm_register_magnific_popup_style_if_needed();
		} elseif ( ! wp_style_is( 'dsm-magnific-popup', 'registered' ) ) {
			$mfp_css = get_theme_file_uri(
				'includes/builder/feature/dynamic-assets/assets/css/magnific_popup.css'
			);

			if ( is_string( $mfp_css ) && '' !== $mfp_css ) {
				wp_register_style(
					'dsm-magnific-popup',
					$mfp_css,
					array(),
					defined( 'ET_CORE_VERSION' ) ? ET_CORE_VERSION : $version
				);
			}
		}

		wp_register_script(
			'dsm-perspective-image',
			DSM_DIR_URL . 'assets/js/perspective-image.js',
			array( 'jquery', $mfp_handle ),
			$version,
			true
		);
	}

	/**
	 * Register Image Compare Viewer + before/after script handles (frontend + Visual Builder).
	 *
	 * @return void
	 */
	public function register_before_after_image_compare_assets() {
		if ( wp_style_is( DsmFrontendModuleAssetRegistry::IMAGE_COMPARE_VIEWER_STYLE_HANDLE, 'registered' ) ) {
			return;
		}

		wp_register_style(
			DsmFrontendModuleAssetRegistry::IMAGE_COMPARE_VIEWER_STYLE_HANDLE,
			DSM_DIR_URL . 'assets/css/image-compare-viewer.min.css',
			array(),
			'1.6.2'
		);

		wp_register_script(
			'dsm-before-after-library',
			DSM_DIR_URL . 'assets/js/before-after-library.js',
			array(),
			'1.6.2',
			true
		);

		$dsm_ba_version = defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';

		wp_register_script(
			'dsm-before-after-icv-mobile-fix',
			DSM_DIR_URL . 'assets/js/before-after-icv-mobile-fix.js',
			array( 'dsm-before-after-library' ),
			$dsm_ba_version,
			true
		);

		wp_register_script(
			'dsm-before-after-slider',
			DSM_DIR_URL . 'assets/js/before-after-slider.js',
			array( 'dsm-before-after-icv-mobile-fix' ),
			$dsm_ba_version,
			true
		);
	}

	/**
	 * Register Vanilla Tilt + frontend init script (Supreme Tilt Image module).
	 *
	 * @return void
	 */
	public function register_tilt_image_assets() {
		if ( wp_script_is( 'dsm-vanilla-tilt', 'registered' ) ) {
			return;
		}

		$version = defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';

		wp_register_script(
			'dsm-vanilla-tilt',
			DSM_DIR_URL . 'assets/js/vanilla-tilt.min.js',
			array(),
			$version,
			true
		);

		wp_register_script(
			'dsm-tilt-image',
			DSM_DIR_URL . 'assets/js/tilt-image.js',
			array( 'jquery', 'dsm-vanilla-tilt' ),
			$version,
			true
		);
	}

	/**
	 * Register Baffle and Shuffle Letters init script (dsm/shuffle-letters module).
	 *
	 * Waypoints: Divi 5 registers `divi-script-library-ext-waypoint` (no local `waypoints.min.js` fallback).
	 *
	 * @return void
	 */
	public function register_shuffle_letters_assets() {
		if ( ! ModuleRegistry::is_setting_enabled( 'ShuffleLetters' ) ) {
			return;
		}

		if ( wp_script_is( 'dsm-shuffle-letter', 'registered' ) ) {
			return;
		}

		$version = defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';

		if ( ! wp_script_is( 'dsm-baffle', 'registered' ) ) {
			wp_register_script(
				'dsm-baffle',
				DSM_DIR_URL . 'assets/js/baffle.js',
				array(),
				$version,
				true
			);
		}

		$waypoint_handle = 'divi-script-library-ext-waypoint';

		wp_register_script(
			'dsm-shuffle-letter',
			DSM_DIR_URL . 'assets/js/shuffle.js',
			array( 'jquery', 'dsm-baffle', $waypoint_handle ),
			$version,
			true
		);
	}

	/**
	 * Register animate.css v3 bundle (`assets/css/animate.scss` → `public/supreme-animate.css`).
	 * Loaded via {@see DsmFrontendDynamicAssets::enqueue_supreme_animate_if_needed()} and the
	 * registry global entry `dsm/shared-supreme-animate` — not embedded per-module copies.
	 *
	 * @return void
	 */
	public function register_supreme_animate_css() {
		if ( wp_style_is( 'dsm-supreme-animate', 'registered' ) ) {
			return;
		}

		$animate_path = DSM_DIR_PATH . 'divi-5/public/supreme-animate.css';
		$version      = is_readable( $animate_path )
			? DsmDiviBuilderCssScope::resolve_stylesheet_version( $animate_path )
			: ( defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0' );

		wp_register_style(
			'dsm-supreme-animate',
			DsmDiviBuilderCssScope::resolve_stylesheet_url( DSM_DIR_URL . 'public/supreme-animate.css' ),
			array(),
			$version
		);
	}

	/**
	 * Register Random Image client-side picker (cache-friendly).
	 *
	 * @return void
	 */
	public function register_random_image_fe_script() {
		if ( wp_script_is( 'dsm-random-image', 'registered' ) ) {
			return;
		}

		$version = defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';

		wp_register_script(
			'dsm-random-image',
			DSM_DIR_URL . 'assets/js/random-image.js',
			array(),
			$version,
			true
		);
	}

	/**
	 * Register shared library-preview re-init helpers (Visual Builder + Divi Library HTML injection).
	 *
	 * @return void
	 */
	public function register_library_module_reinit_assets() {
		if ( wp_script_is( 'dsm-library-module-reinit', 'registered' ) ) {
			return;
		}

		$version = defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';

		wp_register_script(
			'dsm-library-module-reinit',
			plugins_url( 'divi-5/assets/js/shared/library-module-reinit.js', DSM_DIR_PATH . 'supreme-modules-pro-for-divi.php' ),
			array( 'jquery' ),
			$version,
			true
		);
	}

	/**
	 * Register shared Post / Blog carousel frontend init script.
	 *
	 * @return void
	 */
	public function register_post_blog_carousel_shared_assets() {
		if ( wp_script_is( 'dsm-post-blog-carousel-shared', 'registered' ) ) {
			return;
		}

		$this->register_image_carousel_assets();

		$version = defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';

		wp_register_script(
			'dsm-post-blog-carousel-shared',
			plugins_url( 'divi-5/assets/js/shared/post-blog-carousel-shared.js', DSM_DIR_PATH . 'supreme-modules-pro-for-divi.php' ),
			array(
				'jquery',
				'dsm-swiper-library',
				'divi-script-library-ext-waypoint',
			),
			$version,
			true
		);
	}

	/**
	 * Register Image Accordion frontend script (`dsm/image-accordion`).
	 *
	 * @return void
	 */
	public function register_image_accordion_assets() {
		if ( wp_script_is( 'dsm-image-accordion', 'registered' ) ) {
			return;
		}

		$version = defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';

		wp_register_script(
			'dsm-image-accordion',
			DSM_DIR_URL . 'assets/js/image-accordion.js',
			array(),
			$version,
			true
		);
	}

	/**
	 * Register Masonry Gallery frontend (`dsm/masonry-gallery`).
	 *
	 * Bundles masonry-layout + imagesloaded; lightbox depends on Divi Magnific (`magnific-popup`; see {@see dsm_register_magnific_popup_script_if_needed()}).
	 * Script dependency order matters: `masonry-gallery.js` exits if `$.fn.magnificPopup` is missing when it runs.
	 *
	 * @return void
	 */
	public function register_masonry_gallery_assets() {
		if ( wp_script_is( 'dsm-masonry-gallery', 'registered' ) ) {
			return;
		}

		$version = defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';

		$masonry_deps = array( 'jquery' );
		$mfp_handle   = function_exists( 'dsm_get_active_magnific_popup_script_handle' )
			? dsm_get_active_magnific_popup_script_handle()
			: '';
		if ( '' !== $mfp_handle ) {
			$masonry_deps[] = $mfp_handle;
		}

		wp_register_script(
			'dsm-masonry-gallery',
			DSM_DIR_URL . 'assets/js/masonry-gallery.js',
			$masonry_deps,
			$version,
			true
		);
	}

	/**
	 * Register Filterable Gallery frontend (`dsm/filterable-gallery`).
	 *
	 * Shuffle.js (library script) + imagesLoaded progressive layout (`assets/js/filterable-gallery.js`);
	 * Magnific when `dsm_use_lightbox` is on (see `FilterableGallery::render_callback`).
	 * Visual Builder `edit.js` binds Magnific on the canvas — VB still loads Magnific globally with carousel/filter assets.
	 *
	 * @return void
	 */
	public function register_filterable_gallery_assets() {
		if ( wp_script_is( 'dsm-filterable-library-gallery', 'registered' ) ) {
			return;
		}

		$version = defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';

		if ( function_exists( 'dsm_register_magnific_popup_script_if_needed' ) ) {
			dsm_register_magnific_popup_script_if_needed();
		}

		wp_register_script(
			'dsm-filterable-library-gallery',
			plugins_url( 'divi-5/assets/js/filterable-gallery-library.js', DSM_DIR_PATH . 'supreme-modules-pro-for-divi.php' ),
			array( 'jquery' ),
			$version,
			true
		);

		wp_register_script(
			'dsm-filterable-gallery',
			plugins_url( 'divi-5/assets/js/filterable-gallery.js', DSM_DIR_PATH . 'supreme-modules-pro-for-divi.php' ),
			array(
				'jquery',
				'dsm-filterable-library-gallery',
			),
			$version,
			true
		);
	}

	/**
	 * Register Flipbox frontend (`dsm/flipbox`): layout CSS + click toggle script.
	 *
	 * CSS source: `divi-5/packages/module-library/flipbox-perk/common.scss` (built to `assets/css/flipbox.css` via `npm run build`).
	 *
	 * @return void
	 */
	public function register_flipbox_assets() {
		if ( wp_style_is( 'dsm-flipbox-d5', 'registered' ) ) {
			return;
		}

		$flipbox_path = DSM_DIR_PATH . 'divi-5/assets/css/flipbox.css';
		$version      = is_readable( $flipbox_path )
			? DsmDiviBuilderCssScope::resolve_stylesheet_version( $flipbox_path )
			: ( defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0' );

		wp_register_style(
			'dsm-flipbox-d5',
			DsmDiviBuilderCssScope::resolve_stylesheet_url( DSM_DIR_URL . 'assets/css/flipbox.css' ),
			array(),
			$version
		);

		wp_register_script(
			'dsm-flipbox-click',
			DSM_DIR_URL . 'assets/js/flipbox-frontend.js',
			array(),
			$version,
			true
		);
	}

	/**
	 * Register Swiper and Image Carousel frontend (`dsm/image-carousel`).
	 *
	 * Frontend: enqueue Magnific via `ImageCarousel::render_callback` only when lightbox is enabled (`show_lightbox` not `off`).
	 * Visual Builder: Magnific remains available from `load_vb_assets()` bundle when carousel scripts load.
	 *
	 * Handles must align with `ImageCarousel::render` ({@see DsmFrontendModuleAssetRegistry::SWIPER_LIBRARY_STYLE_HANDLE}, `dsm-swiper-library`,
	 * `dsm-image-carousel`). Magnific is enqueued only when `show_lightbox` is not `off` (see render).
	 *
	 * @return void
	 */
	public function register_image_carousel_assets() {
		if ( wp_script_is( 'dsm-image-carousel', 'registered' ) ) {
			return;
		}

		$this->register_supreme_lightbox_assets();

		$version = defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';

		if ( ! wp_style_is( DsmFrontendModuleAssetRegistry::SWIPER_LIBRARY_STYLE_HANDLE, 'registered' ) ) {
			wp_register_style(
				DsmFrontendModuleAssetRegistry::SWIPER_LIBRARY_STYLE_HANDLE,
				DSM_DIR_URL . 'assets/css/swiper.css',
				array(),
				$version
			);
		}

		if ( ! wp_script_is( 'dsm-swiper-library', 'registered' ) ) {
			wp_register_script(
				'dsm-swiper-library',
				DSM_DIR_URL . 'assets/js/swiper.js',
				array( 'jquery' ),
				$version,
				true
			);
		}

		if ( function_exists( 'dsm_register_magnific_popup_script_if_needed' ) ) {
			dsm_register_magnific_popup_script_if_needed();
		}

		wp_register_script(
			'dsm-image-carousel',
			DSM_DIR_URL . 'assets/js/image-carousel.js',
			array( 'dsm-swiper-library' ),
			$version,
			true
		);
	}

	/**
	 * Register Card Carousel frontend (`dsm/card-carousel`) — Swiper; Magnific only when a slide uses image/video lightbox (see {@see CardCarousel::render_callback}).
	 *
	 * @return void
	 */
	public function register_card_carousel_assets() {
		if ( wp_script_is( 'dsm-card-carousel', 'registered' ) ) {
			return;
		}

		$this->register_image_carousel_assets();

		$version = defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';

		wp_register_script(
			'dsm-card-carousel',
			DSM_DIR_URL . 'assets/js/card-carousel.js',
			array(
				'jquery',
				'dsm-swiper-library',
			),
			$version,
			true
		);
	}

	/**
	 * Register Post Carousel frontend (`dsm/post-carousel`) — Swiper (same stack as Card Carousel).
	 *
	 * @return void
	 */
	public function register_post_carousel_assets() {
		if ( wp_script_is( 'dsm-post-carousel', 'registered' ) ) {
			return;
		}

		$this->register_post_blog_carousel_shared_assets();

		$version = defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';

		wp_register_script(
			'dsm-post-carousel',
			plugins_url( 'divi-5/assets/js/post-carousel.js', DSM_DIR_PATH . 'supreme-modules-pro-for-divi.php' ),
			array(
				'dsm-post-blog-carousel-shared',
			),
			$version,
			true
		);
	}

	/**
	 * Register Blog Carousel frontend (`dsm/blog-carousel`) — Swiper (sibling to Post Carousel).
	 *
	 * @return void
	 */
	public function register_blog_carousel_assets() {
		if ( wp_script_is( 'dsm-blog-carousel', 'registered' ) ) {
			return;
		}

		$this->register_post_blog_carousel_shared_assets();

		$version = defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';

		wp_register_script(
			'dsm-blog-carousel',
			plugins_url( 'divi-5/assets/js/blog-carousel.js', DSM_DIR_PATH . 'supreme-modules-pro-for-divi.php' ),
			array(
				'dsm-post-blog-carousel-shared',
			),
			$version,
			true
		);
	}

	/**
	 * Register Supreme Marquee frontend script (`dsm/marquee`).
	 *
	 * @return void
	 */
	public function register_marquee_assets() {
		if ( wp_script_is( 'dsm-marquee', 'registered' ) ) {
			return;
		}

		$version = defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';

		wp_register_script(
			'dsm-marquee',
			DSM_DIR_URL . 'assets/js/marquee.js',
			array(),
			$version,
			true
		);
	}

	/**
	 * Register Popper, Tippy, and Icon List frontend script (`dsm/icon-list`).
	 *
	 * @return void
	 */
	public function register_icon_list_assets() {
		if ( wp_script_is( 'dsm-icon-list', 'registered' ) ) {
			return;
		}

		$version = defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';

		wp_register_script(
			'dsm-popper',
			DSM_DIR_URL . 'assets/js/popper.js',
			array(),
			$version,
			true
		);

		wp_register_script(
			'dsm-tippy',
			DSM_DIR_URL . 'assets/js/tippy.js',
			array( 'dsm-popper' ),
			$version,
			true
		);

		wp_register_script(
			'dsm-icon-list',
			DSM_DIR_URL . 'assets/js/icon-list.js',
			array( 'jquery', 'dsm-tippy' ),
			$version,
			true
		);
	}

	/**
	 * Register Tippy + Image Hotspots frontend init (dsm/image-hotspots module).
	 *
	 * @return void
	 */
	public function register_image_hotspot_assets() {
		if ( wp_script_is( 'dsm-image-hotspot', 'registered' ) ) {
			return;
		}

		$this->register_icon_list_assets();

		$version = defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';

		wp_register_script(
			'dsm-image-hotspot',
			DSM_DIR_URL . 'assets/js/image-hotspot.js',
			array( 'jquery', 'dsm-tippy' ),
			$version,
			true
		);
	}

	/**
	 * Register ReplaceMe + Text Rotator init script (dsm/text-rotator module).
	 *
	 * Waypoints: Divi 5 `divi-script-library-ext-waypoint` (no local fallback).
	 *
	 * @return void
	 */
	public function register_text_rotator_assets() {
		if ( ! ModuleRegistry::is_setting_enabled( 'TextRotator' ) ) {
			return;
		}

		if ( wp_script_is( 'dsm-text-rotator', 'registered' ) ) {
			return;
		}

		$version = defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';

		if ( ! wp_script_is( 'dsm-replace-me', 'registered' ) ) {
			wp_register_script(
				'dsm-replace-me',
				DSM_DIR_URL . 'assets/js/replaceme.js',
				array(),
				$version,
				true
			);
		}

		$waypoint_handle = 'divi-script-library-ext-waypoint';

		wp_register_script(
			'dsm-text-rotator',
			DSM_DIR_URL . 'assets/js/text-rotator.js',
			array( 'jquery', 'dsm-replace-me', $waypoint_handle ),
			$version,
			true
		);
	}

	/**
	 * Register Rough Notation library + Text Notation init (`dsm/text-notation`).
	 *
	 * @return void
	 */
	public function register_text_notation_assets() {
		if ( ! ModuleRegistry::is_setting_enabled( 'TextNotation' ) ) {
			return;
		}

		if ( wp_script_is( 'dsm-text-notation', 'registered' ) ) {
			return;
		}

		$version = defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';

		wp_register_script(
			'dsm-notation-library',
			DSM_DIR_URL . 'assets/js/notation-library.js',
			array(),
			$version,
			true
		);

		wp_register_script(
			'dsm-text-notation',
			DSM_DIR_URL . 'assets/js/notation.js',
			array( 'dsm-notation-library' ),
			$version,
			true
		);
	}

	/**
	 * Register Progress Bar front-end script (`dsm/progress-bar`).
	 *
	 * @return void
	 */
	public function register_progress_bar_assets() {
		if ( ! ModuleRegistry::is_setting_enabled( 'ProgressBar' ) ) {
			return;
		}

		if ( wp_script_is( 'dsm-progress-bar', 'registered' ) ) {
			return;
		}

		$version = defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';

		wp_register_script(
			'dsm-progress-bar',
			DSM_DIR_URL . 'assets/js/progressbar.js',
			array(),
			$version,
			true
		);
	}

	/**
	 * Register Supreme Lottie frontend bundle (`dsm/lottie`).
	 *
	 * Webpack output: `assets/js/lottie-frontend.js` (lottie-web, optional dotlottie chunk in
	 * `assets/js/`, @lottiefiles/lottie-interactivity on `window.dsmLottieInteractivity`).
	 * Waypoints required for viewport autoplay (non-hover).
	 *
	 * @return void
	 */
	public function register_lottie_assets() {
		if ( wp_script_is( 'dsm-lottie-frontend', 'registered' ) ) {
			return;
		}

		$version = defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';

		$waypoint_handle = 'divi-script-library-ext-waypoint';

		wp_register_script(
			'dsm-lottie-frontend',
			DSM_DIR_URL . 'assets/js/lottie-frontend.js',
			array( 'jquery', $waypoint_handle ),
			$version,
			true
		);

		wp_localize_script(
			'dsm-lottie-frontend',
			'diviSupremeLottie',
			array(
				'wasmUrl' => DSM_DIR_URL . 'assets/js/dotlottie-player.wasm',
			)
		);
	}

	/**
	 * Register Supreme SVG Animation frontend bundle (`dsm/svg-animation`).
	 *
	 * Webpack bundle: `assets/js/svg-animation-frontend.js` (Vivus from npm, pure DOM init).
	 *
	 * @return void
	 */
	public function register_svg_animation_assets() {
		if ( wp_script_is( 'dsm-svg-animation', 'registered' ) ) {
			return;
		}

		$version = defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';

		wp_register_script(
			'dsm-svg-animation',
			DSM_DIR_URL . 'assets/js/svg-animation-frontend.js',
			array(),
			$version,
			true
		);
	}

	/**
	 * Register Image Hover Reveal frontend bundle (`dsm/image-hover-reveal`).
	 *
	 * Webpack bundle: `assets/js/image-hover-reveal-frontend.js` (Splitting.js from npm).
	 *
	 * @return void
	 */
	public function register_image_hover_reveal_assets() {
		if ( wp_script_is( 'dsm-image-hover-reveal', 'registered' ) ) {
			return;
		}

		$version = defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';

		wp_register_script(
			'dsm-image-hover-reveal',
			DSM_DIR_URL . 'assets/js/image-hover-reveal-frontend.js',
			array(),
			$version,
			true
		);
	}

	/**
	 * Register GSAP, Splitting, and Image Text Reveal frontend (`dsm/image-text-reveal`).
	 *
	 * @return void
	 */
	public function register_image_text_reveal_assets() {
		if ( wp_script_is( 'dsm-text-reveal', 'registered' ) ) {
			return;
		}

		$version = defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';

		wp_register_script(
			'dsm-gsap',
			DSM_DIR_URL . 'assets/js/gsap.js',
			array(),
			$version,
			true
		);

		wp_register_script(
			'dsm-splitting',
			DSM_DIR_URL . 'assets/js/splitting.js',
			array(),
			$version,
			true
		);

		wp_register_script(
			'dsm-text-reveal',
			DSM_DIR_URL . 'assets/js/image-text-reveal.js',
			array( 'jquery', 'dsm-gsap', 'dsm-splitting' ),
			$version,
			true
		);
	}

	/**
	 * GSAP ScrollTrigger, Lenis, on-scroll header animation, animated headline, read more, etc.
	 *
	 * @return void
	 */
	public function register_gsap_scroll_ported_modules_assets() {
		if ( wp_script_is( 'dsm-scroll-header-animation', 'registered' ) ) {
			return;
		}

		$this->register_image_text_reveal_assets();

		$version = defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';

		wp_register_script(
			'dsm-scroll-trigger',
			DSM_DIR_URL . 'assets/js/scroll-trigger.js',
			array( 'jquery', 'dsm-gsap' ),
			$version,
			true
		);

		wp_register_script(
			'dsm-lenis',
			DSM_DIR_URL . 'assets/js/lenis.js',
			array(),
			$version,
			true
		);

		wp_register_script(
			'dsm-scroll-header-animation',
			DSM_DIR_URL . 'assets/js/on-scroll-header-animation.js',
			array(
				'dsm-gsap',
				'dsm-scroll-trigger',
				'dsm-splitting',
				'dsm-lenis',
			),
			$version,
			true
		);

		wp_register_script(
			'dsm-animated-headline',
			DSM_DIR_URL . 'assets/js/animated-headline.js',
			array( 'jquery' ),
			$version,
			true
		);

		wp_register_script(
			'dsm-readmore',
			DSM_DIR_URL . 'assets/js/readmore.js',
			array( 'jquery' ),
			$version,
			true
		);
	}

	/**
	 * Register Stacking Card frontend script (`dsm/stacking-card`).
	 *
	 * Depends on GSAP + ScrollTrigger (same as preset: registered next to carousel scripts).
	 *
	 * @return void
	 */
	public function register_stacking_card_assets() {
		if ( wp_script_is( 'dsm-stacking-card', 'registered' ) ) {
			return;
		}

		$version = defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';

		wp_register_script(
			'dsm-stacking-card',
			DSM_DIR_URL . 'assets/js/stacking-card.js',
			array(
				'jquery',
				'dsm-gsap',
				'dsm-scroll-trigger',
			),
			$version,
			true
		);
	}

	/**
	 * Register RevealFx library + Block Reveal Text/Image front-end scripts.
	 *
	 * Waypoints: Divi 5 `divi-script-library-ext-waypoint` (no local fallback).
	 *
	 * @return void
	 */
	public function register_block_reveal_assets() {
		if ( ! $this->any_module_enabled( array( 'BlockRevealImage', 'BlockRevealText' ) ) ) {
			return;
		}

		if ( wp_script_is( 'dsm-reveal-library', 'registered' ) ) {
			return;
		}

		$version = defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';

		wp_register_script(
			'dsm-reveal-library',
			DSM_DIR_URL . 'assets/js/reveal-library.js',
			array(),
			$version,
			true
		);

		$waypoint_handle = 'divi-script-library-ext-waypoint';

		wp_register_script(
			'dsm-block-reveal-text',
			DSM_DIR_URL . 'assets/js/block-reveal-text.js',
			array( 'jquery', $waypoint_handle, 'dsm-reveal-library' ),
			$version,
			true
		);

		wp_register_script(
			'dsm-block-reveal-image',
			DSM_DIR_URL . 'assets/js/block-reveal-image.js',
			array( 'jquery', 'dsm-reveal-library' ),
			$version,
			true
		);
	}

	/**
	 * Register Content Toggle frontend script (`dsm/content-toggle`).
	 *
	 * @return void
	 */
	public function register_content_toggle_assets() {
		if ( wp_script_is( 'dsm-content-toggle', 'registered' ) ) {
			return;
		}

		$version = defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';

		wp_register_script(
			'dsm-content-toggle',
			DSM_DIR_URL . 'assets/js/content-toggle.js',
			array(),
			$version,
			true
		);
	}

	/**
	 * Register Content Timeline frontend script (`dsm/content-timeline`).
	 *
	 * @return void
	 */
	public function register_content_timeline_assets() {
		if ( wp_script_is( 'dsm-content-timeline', 'registered' ) ) {
			return;
		}

		$version = defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';

		$deps = array( 'jquery' );

		wp_register_script(
			'dsm-content-timeline',
			DSM_DIR_URL . 'assets/js/content-timeline.js',
			$deps,
			$version,
			true
		);
	}

	/**
	 * Register Circle Info frontend script (`dsm/circle-info`).
	 *
	 * Requires Divi Waypoints for viewport init; script lives under `divi-5/assets/js/`.
	 *
	 * @return void
	 */
	public function register_circle_info_assets() {
		if ( wp_script_is( 'dsm-circle-info', 'registered' ) ) {
			return;
		}

		$version = defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';

		$waypoint_handle = 'divi-script-library-ext-waypoint';

		wp_register_script(
			'dsm-circle-info',
			DSM_DIR_URL . 'assets/js/circle-info.js',
			array( 'jquery', $waypoint_handle ),
			$version,
			true
		);
	}

	/**
	 * Register Supreme Menu submenu collapse script (`dsm/menu` module).
	 *
	 * @return void
	 */
	public function register_menu_module_assets() {
		if ( wp_script_is( 'dsm-menu', 'registered' ) ) {
			return;
		}

		$version = defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';

		wp_register_script(
			'dsm-menu',
			DSM_DIR_URL . 'assets/js/menu.js',
			array(),
			$version,
			true
		);
	}

	/**
	 * Register Supreme FAQ accordion script (`dsm/faq`).
	 *
	 * @return void
	 */
	public function register_faq_module_assets() {
		if ( wp_script_is( 'dsm-faq', 'registered' ) ) {
			return;
		}

		$version = defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';

		wp_register_script(
			'dsm-faq',
			DSM_DIR_URL . 'assets/js/faq.js',
			array(),
			$version,
			true
		);
	}

	/**
	 * Register Supreme Loop Filter frontend script (`dsm/loop-filter`).
	 *
	 * @return void
	 */
	public function register_loop_filter_module_assets() {
		if ( wp_script_is( 'dsm-loop-filter', 'registered' ) ) {
			return;
		}

		if ( ! function_exists( 'dsm_is_loop_filter_extension_enabled' ) || ! dsm_is_loop_filter_extension_enabled() ) {
			return;
		}

		$version = defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';

		wp_register_script(
			'dsm-loop-filter',
			DSM_DIR_URL . 'assets/js/loop-filter.js',
			array(),
			$version,
			true
		);

		wp_localize_script(
			'dsm-loop-filter',
			'dsmLoopFilter',
			array(
				'restNonce' => wp_create_nonce( 'wp_rest' ),
			)
		);
	}

	/**
	 * Register Chart.js library + Supreme Chart init (`dsm/chart`).
	 *
	 * @return void
	 */
	public function register_chart_module_assets() {
		$version = defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';

		if ( ! wp_script_is( 'dsm-chartjs-library', 'registered' ) ) {
			wp_register_script(
				'dsm-chartjs-library',
				DSM_DIR_URL . 'assets/js/chart.js',
				array(),
				$version,
				true
			);
		}

		if ( wp_script_is( 'dsm-chart', 'registered' ) ) {
			return;
		}

		wp_register_script(
			'dsm-chart',
			DSM_DIR_URL . 'assets/js/chart-module.js',
			array( 'dsm-chartjs-library' ),
			$version,
			true
		);

		$this->localize_chart_settings();
	}

	/**
	 * Localize Chart.js locale (BCP 47) for config builders.
	 *
	 * @return void
	 */
	private function localize_chart_settings(): void {
		if ( ! wp_script_is( 'dsm-chart', 'registered' ) && ! wp_script_is( 'dsm-chart', 'enqueued' ) ) {
			return;
		}

		$locale = '';
		if ( function_exists( 'determine_locale' ) ) {
			$locale = (string) determine_locale();
		}
		if ( '' === $locale && function_exists( 'get_user_locale' ) ) {
			$locale = (string) get_user_locale();
		}
		if ( '' === $locale ) {
			$locale = (string) get_locale();
		}

		$locale = str_replace( '_', '-', trim( $locale ) );
		if ( '' === $locale || 1 !== preg_match( '/^[a-zA-Z]{2,3}(-[a-zA-Z0-9]+)*$/', $locale ) ) {
			$locale = '';
		}

		wp_localize_script(
			'dsm-chart',
			'dsmChartSettings',
			array(
				'locale'       => $locale,
				// Divi default breakpoint max widths (px); FE swaps canvas colors.
				'tabletMax'    => 980,
				'phoneMax'     => 767,
				// Sample CSV for Content → Import data (VB download link).
				'sampleCsvUrl' => esc_url_raw( DSM_DIR_URL . 'assets/csv/chart-sample.csv' ),
				// Public Live refresh REST base (`chart-csv-live`).
				'restUrl'      => esc_url_raw( rest_url( 'dsm/v1/' ) ),
			)
		);
	}

	/**
	 * Register Supreme Table interactive script (`dsm/table`).
	 *
	 * @return void
	 */
	public function register_table_module_assets() {
		if ( wp_script_is( 'dsm-table', 'registered' ) ) {
			return;
		}

		$version = defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';

		wp_register_script(
			'dsm-table',
			DSM_DIR_URL . 'assets/js/table-module.js',
			array(),
			$version,
			true
		);

		wp_localize_script(
			'dsm-table',
			'dsmTableSettings',
			array(
				'restUrl' => esc_url_raw( rest_url( 'dsm/v1/' ) ),
			)
		);
	}

	/**
	 * Register Supreme Table of Contents script (`dsm/table-of-contents`).
	 *
	 * @return void
	 */
	public function register_table_of_contents_module_assets() {
		if ( wp_script_is( 'dsm-toc', 'registered' ) ) {
			return;
		}

		$version = defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';

		wp_register_script(
			'dsm-toc',
			DSM_DIR_URL . 'assets/js/table-of-contents.js',
			array(),
			$version,
			true
		);
	}

	/**
	 * Register Supreme Testimonials frontend (`dsm/testimonials`).
	 *
	 * Swiper is enqueued only for carousel layout. Magnific is attached when a card has video.
	 *
	 * @return void
	 */
	public function register_testimonials_module_assets() {
		if ( wp_script_is( 'dsm-testimonials', 'registered' ) ) {
			return;
		}

		$version    = defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';
		$deps       = array();
		$mfp_handle = function_exists( 'dsm_get_active_magnific_popup_script_handle' )
			? dsm_get_active_magnific_popup_script_handle()
			: '';
		if ( is_string( $mfp_handle ) && '' !== $mfp_handle ) {
			if ( function_exists( 'dsm_register_magnific_popup_script_if_needed' ) ) {
				dsm_register_magnific_popup_script_if_needed();
			}
			$deps[] = $mfp_handle;
		}

		wp_register_script(
			'dsm-testimonials',
			DSM_DIR_URL . 'assets/js/testimonials.js',
			$deps,
			$version,
			true
		);

		wp_localize_script(
			'dsm-testimonials',
			'dsmTestimonialsCollect',
			array(
				'restUrl'            => esc_url_raw( rest_url( 'dsm/v1/testimonials/collect' ) ),
				'restNonce'          => wp_create_nonce( 'wp_rest' ),
				'error'              => __( 'Could not submit your review.', 'dsm-supreme-modules-pro-for-divi' ),
				'consent'            => __( 'Please agree to the terms before submitting your review.', 'dsm-supreme-modules-pro-for-divi' ),
				'namePart'           => __( 'your name', 'dsm-supreme-modules-pro-for-divi' ),
				'emailPart'          => __( 'a valid email address', 'dsm-supreme-modules-pro-for-divi' ),
				'reviewPart'         => __( 'your review', 'dsm-supreme-modules-pro-for-divi' ),
				/* translators: %s: list of missing fields, e.g. “a valid email address”. */
				'pleaseEnter'        => __( 'Please enter %s.', 'dsm-supreme-modules-pro-for-divi' ),
				/* translators: %s: list of missing fields, e.g. “your name and a valid email address”. */
				'pleaseEnterConsent' => __( 'Please enter %s, and agree to the terms.', 'dsm-supreme-modules-pro-for-divi' ),
				/* translators: 1: first item, 2: second item. */
				'listAnd'            => __( '%1$s and %2$s', 'dsm-supreme-modules-pro-for-divi' ),
				/* translators: 1: comma-separated items, 2: last item. */
				'listAndLast'        => __( '%1$s, and %2$s', 'dsm-supreme-modules-pro-for-divi' ),
			)
		);
	}

	/**
	 * Register Advanced Tabs frontend script (`dsm/advanced-tabs`).
	 *
	 * @return void
	 */
	public function register_advanced_tabs_module_assets() {
		if ( wp_script_is( 'dsm-advanced-tabs', 'registered' ) ) {
			return;
		}

		$version = defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';

		wp_register_script(
			'dsm-advanced-tabs',
			DSM_DIR_URL . 'assets/js/advanced-tabs.js',
			array( 'jquery' ),
			$version,
			true
		);
	}

	/**
	 * Register Supreme Button module frontend script (`dsm/button`).
	 *
	 * @return void
	 */
	public function register_buttons_module_assets() {
		if ( wp_script_is( 'dsm-buttons', 'registered' ) ) {
			return;
		}

		$version = defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';

		wp_register_script(
			'dsm-buttons',
			DSM_DIR_URL . 'assets/js/buttons.js',
			array( 'jquery' ),
			$version,
			true
		);
	}

	/**
	 * Register Typed.js + Supreme Typing Effect frontend (`dsm/typing-effect`).
	 *
	 * Waypoints: Divi 5 `divi-script-library-ext-waypoint` (viewport animation).
	 *
	 * @return void
	 */
	public function register_typing_effect_assets() {
		if ( wp_script_is( 'dsm-typing-library', 'registered' ) ) {
			return;
		}

		$version = defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';

		wp_register_script(
			'dsm-typing-library',
			DSM_DIR_URL . 'assets/js/typing-library.js',
			array( 'jquery' ),
			$version,
			true
		);

		$waypoint_handle = 'divi-script-library-ext-waypoint';

		wp_register_script(
			'dsm-typing',
			DSM_DIR_URL . 'assets/js/typing.js',
			array( 'jquery', 'dsm-typing-library', $waypoint_handle ),
			$version,
			true
		);
	}

	/**
	 * Register Social Share Buttons frontend script (`dsm/social-share-buttons`).
	 *
	 * @return void
	 */
	public function register_social_share_buttons_assets() {
		if ( wp_script_is( 'dsm-social-share-button', 'registered' ) ) {
			return;
		}

		$version = defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';

		wp_register_script(
			'dsm-social-share-button',
			DSM_DIR_URL . 'assets/js/social-share-buttons.js',
			array( 'jquery' ),
			$version,
			true
		);
	}

	/**
	 * Register popup extension + shared module style handles on every request (cheap metadata only).
	 *
	 * Popup render enqueues these from {@see \DiviSupreme\Extensions\Popup}; they must exist even when
	 * the prior guard `! et_core_is_fb_enabled() && ! is_admin()` skipped registration (edge URLs).
	 *
	 * @return void
	 */
	public function register_popup_and_shared_style_handles() {
		$dsm_version = defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';

		if ( ! wp_style_is( DsmFrontendModuleAssetRegistry::EXTENSION_POPUP_STYLE_HANDLE, 'registered' ) ) {
			DsmFrontendModuleAssetRegistry::register_extensions_bundle_style_handle();
		}

		if ( ! wp_style_is( DsmFrontendModuleAssetRegistry::CORE_MODULES_STYLE_HANDLE, 'registered' ) ) {
			DsmFrontendModuleAssetRegistry::register_core_modules_bundle_style_handle();
		}

		// Per-module `frontend.css` is registered on `wp_enqueue_scripts` (priority 17), after the
		// main query, so CPT/Theme Builder URLs are chosen once. Registering all ~90 files here on
		// `init` scanned the library before that decision and was discarded by the later refresh.

		$this->register_supreme_parallax_frontend_script( $dsm_version );
		$this->register_image_parallax_frontend_script( $dsm_version );
		$this->register_tooltip_frontend_script( $dsm_version );
		$this->register_custom_cursor_frontend_script( $dsm_version );
		$this->register_preloader_frontend_script( $dsm_version );
		$this->register_dark_mode_frontend_script( $dsm_version );
		$this->register_icon_libraries_frontend_script( $dsm_version );
		$this->register_icon_libraries_vb_hooks_script( $dsm_version );
		$this->register_mask_pattern_library_vb_hooks_script( $dsm_version );

		if ( ! dsm_is_supreme_popup_extension_enabled() ) {
			return;
		}

		if ( wp_script_is( 'dsm-popup-extension', 'registered' ) ) {
			return;
		}

		$popup_ext_deps = array( 'jquery' );
		$mfp_handle     = function_exists( 'dsm_get_active_magnific_popup_script_handle' )
			? dsm_get_active_magnific_popup_script_handle()
			: '';
		if ( '' !== $mfp_handle ) {
			$popup_ext_deps[] = $mfp_handle;
		}

		wp_register_script(
			'dsm-popup-extension',
			DSM_DIR_URL . '/assets/js/extensions/popup.js',
			$popup_ext_deps,
			$dsm_version,
			true
		);

		wp_localize_script(
			'dsm-popup-extension',
			'diviSupreme5',
			array(
				'needsBuilderCssPrefix' => (
					function_exists( 'et_builder_should_wrap_styles' )
					&& et_builder_should_wrap_styles()
					&& ( ! function_exists( 'et_is_builder_plugin_active' ) || ! et_is_builder_plugin_active() )
				) || (
					class_exists( DsmDiviBuilderCssScope::class )
					&& DsmDiviBuilderCssScope::needs_builder_css_prefix()
				),
			)
		);
	}

	/**
	 * Register Supreme Parallax frontend script (one runtime per enabled section).
	 *
	 * @param string $dsm_version Plugin semver.
	 * @return void
	 */
	private function register_supreme_parallax_frontend_script( string $dsm_version ): void {
		if (
			! function_exists( 'dsm_is_supreme_parallax_extension_enabled' )
			|| ! dsm_is_supreme_parallax_extension_enabled()
		) {
			return;
		}

		if ( wp_script_is( 'dsm-supreme-parallax-frontend', 'registered' ) ) {
			return;
		}

		$file = DSM_DIR_PATH . 'divi-5/public/supreme-parallax-frontend.js';

		if ( ! is_readable( $file ) ) {
			return;
		}

		wp_register_script(
			'dsm-supreme-parallax-frontend',
			DSM_DIR_URL . 'public/supreme-parallax-frontend.js',
			array(),
			$dsm_version . '-' . (string) filemtime( $file ),
			true
		);
	}

	/**
	 * Register Image Parallax frontend script (simpleParallax.js bundled).
	 *
	 * @param string $dsm_version Plugin semver.
	 * @return void
	 */
	private function register_image_parallax_frontend_script( string $dsm_version ): void {
		if (
			! function_exists( 'dsm_is_image_parallax_extension_enabled' )
			|| ! dsm_is_image_parallax_extension_enabled()
		) {
			return;
		}

		if ( wp_script_is( 'dsm-image-parallax-frontend', 'registered' ) ) {
			return;
		}

		$file = DSM_DIR_PATH . 'divi-5/public/image-parallax-frontend.js';

		if ( ! is_readable( $file ) ) {
			return;
		}

		wp_register_script(
			'dsm-image-parallax-frontend',
			DSM_DIR_URL . 'public/image-parallax-frontend.js',
			array(),
			$dsm_version . '-' . (string) filemtime( $file ),
			true
		);

		$css_file = DSM_DIR_PATH . 'divi-5/public/image-parallax-frontend.css';

		if ( is_readable( $css_file )
			&& ! wp_style_is( 'dsm-image-parallax-frontend', 'registered' ) ) {
			wp_register_style(
				'dsm-image-parallax-frontend',
				DSM_DIR_URL . 'public/image-parallax-frontend.css',
				array(),
				$dsm_version . '-' . (string) filemtime( $css_file )
			);
		}
	}

	/**
	 * Register Tooltip frontend script + CSS (`dsm-tooltip-frontend`).
	 *
	 * Depends on `dsm-tippy` (already includes followCursor + sticky).
	 *
	 * @param string $dsm_version Plugin semver.
	 * @return void
	 */
	private function register_tooltip_frontend_script( string $dsm_version ): void {
		if (
			! function_exists( 'dsm_is_tooltip_extension_enabled' )
			|| ! dsm_is_tooltip_extension_enabled()
		) {
			return;
		}

		if ( ! wp_script_is( 'dsm-tippy', 'registered' ) ) {
			$this->register_icon_list_assets();
		}

		if ( wp_script_is( 'dsm-tooltip-frontend', 'registered' ) ) {
			return;
		}

		$file = DSM_DIR_PATH . 'divi-5/public/tooltip-frontend.js';

		if ( ! is_readable( $file ) ) {
			return;
		}

		wp_register_script(
			'dsm-tooltip-frontend',
			DSM_DIR_URL . 'public/tooltip-frontend.js',
			array( 'dsm-tippy' ),
			$dsm_version . '-' . (string) filemtime( $file ),
			true
		);

		$css_file = DSM_DIR_PATH . 'divi-5/public/style-tooltip-frontend.css';

		if ( is_readable( $css_file )
			&& ! wp_style_is( 'dsm-tooltip-frontend', 'registered' ) ) {
			wp_register_style(
				'dsm-tooltip-frontend',
				DSM_DIR_URL . 'public/style-tooltip-frontend.css',
				array(),
				$dsm_version . '-' . (string) filemtime( $css_file )
			);
		}
	}

	/**
	 * Register Custom Cursor frontend script + styles (scope-gated enqueue in CustomCursor.php).
	 *
	 * @param string $dsm_version Plugin semver.
	 * @return void
	 */
	private function register_custom_cursor_frontend_script( string $dsm_version ): void {
		if (
			! function_exists( 'dsm_is_custom_cursor_extension_enabled' )
			|| ! dsm_is_custom_cursor_extension_enabled()
		) {
			return;
		}

		if ( wp_script_is( 'dsm-custom-cursor-frontend', 'registered' ) ) {
			return;
		}

		$file = DSM_DIR_PATH . 'divi-5/public/custom-cursor-frontend.js';

		if ( ! is_readable( $file ) ) {
			return;
		}

		wp_register_script(
			'dsm-custom-cursor-frontend',
			DSM_DIR_URL . 'public/custom-cursor-frontend.js',
			array(),
			$dsm_version . '-' . (string) filemtime( $file ),
			true
		);

		if ( ! wp_style_is( 'dsm-custom-cursor-frontend', 'registered' ) ) {
			$css_file = DSM_DIR_PATH . 'divi-5/public/style-custom-cursor-frontend-styles.css';

			if ( is_readable( $css_file ) ) {
				wp_register_style(
					'dsm-custom-cursor-frontend',
					DsmDiviBuilderCssScope::resolve_stylesheet_url( DSM_DIR_URL . 'public/style-custom-cursor-frontend-styles.css' ),
					array(),
					DsmDiviBuilderCssScope::resolve_stylesheet_version( $css_file )
				);
			}
		}
	}

	/**
	 * Register Preloader frontend script (overlay CSS is inline; JS-only handle).
	 *
	 * @param string $dsm_version Plugin semver.
	 * @return void
	 */
	private function register_preloader_frontend_script( string $dsm_version ): void {
		if (
			! function_exists( 'dsm_is_preloader_extension_enabled' )
			|| ! dsm_is_preloader_extension_enabled()
		) {
			return;
		}

		if ( wp_script_is( 'dsm-preloader-frontend', 'registered' ) ) {
			return;
		}

		$file = DSM_DIR_PATH . 'divi-5/public/preloader-frontend.js';

		if ( ! is_readable( $file ) ) {
			return;
		}

		wp_register_script(
			'dsm-preloader-frontend',
			DSM_DIR_URL . 'public/preloader-frontend.js',
			array(),
			$dsm_version . '-' . (string) filemtime( $file ),
			true
		);
	}

	/**
	 * Register Dark Mode Toggle frontend script + styles (gated enqueue in DarkMode.php).
	 *
	 * @param string $dsm_version Plugin semver.
	 * @return void
	 */
	private function register_dark_mode_frontend_script( string $dsm_version ): void {
		if (
			! function_exists( 'dsm_is_dark_mode_extension_enabled' )
			|| ! dsm_is_dark_mode_extension_enabled()
		) {
			return;
		}

		if ( wp_script_is( 'dsm-dark-mode-frontend', 'registered' ) ) {
			return;
		}

		$file = DSM_DIR_PATH . 'divi-5/public/dark-mode-frontend.js';

		if ( ! is_readable( $file ) ) {
			return;
		}

		wp_register_script(
			'dsm-dark-mode-frontend',
			DSM_DIR_URL . 'public/dark-mode-frontend.js',
			array(),
			$dsm_version . '-' . (string) filemtime( $file ),
			true
		);

		if ( ! wp_style_is( 'dsm-dark-mode-frontend', 'registered' ) ) {
			$css_file = DSM_DIR_PATH . 'divi-5/public/style-dark-mode-frontend-styles.css';

			if ( is_readable( $css_file ) ) {
				wp_register_style(
					'dsm-dark-mode-frontend',
					DsmDiviBuilderCssScope::resolve_stylesheet_url( DSM_DIR_URL . 'public/style-dark-mode-frontend-styles.css' ),
					array(),
					DsmDiviBuilderCssScope::resolve_stylesheet_version( $css_file )
				);
			}
		}
	}

	/**
	 * Register Icon Libraries frontend styles (webfont glyph sizing).
	 *
	 * @param string $dsm_version Plugin semver.
	 * @return void
	 */
	private function register_icon_libraries_frontend_script( string $dsm_version ): void {
		if (
			! function_exists( 'dsm_is_icon_libraries_extension_enabled' )
			|| ! dsm_is_icon_libraries_extension_enabled()
		) {
			return;
		}

		if ( ! wp_style_is( 'dsm-icon-libraries-frontend', 'registered' ) ) {
			$css_file = DSM_DIR_PATH . 'divi-5/public/style-icon-libraries-frontend-styles.css';

			if ( is_readable( $css_file ) ) {
				wp_register_style(
					'dsm-icon-libraries-frontend',
					DsmDiviBuilderCssScope::resolve_stylesheet_url( DSM_DIR_URL . 'public/style-icon-libraries-frontend-styles.css' ),
					array(),
					DsmDiviBuilderCssScope::resolve_stylesheet_version( $css_file )
				);
			}
		}
	}

	/**
	 * Script handles that are registered before this script is enqueued (WP 6.9.1+ validates deps).
	 *
	 * @param string[] $handles Candidate dependency handles.
	 * @return string[]
	 */
	private function resolve_registered_script_deps( array $handles ): array {
		$resolved = array();

		foreach ( $handles as $handle ) {
			if ( is_string( $handle ) && '' !== $handle && wp_script_is( $handle, 'registered' ) ) {
				$resolved[] = $handle;
			}
		}

		return $resolved;
	}

	/**
	 * WordPress hooks script handle for the current VB window (app vs top).
	 *
	 * Divi registers `divi-vendor-wp-hooks` only in the app iframe; the top window
	 * (icon picker field panel) uses core `wp-hooks` instead.
	 *
	 * @return string[]
	 */
	private function get_icon_libraries_vb_wp_hooks_dependency_handles(): array {
		return $this->resolve_registered_script_deps(
			array(
				'divi-vendor-wp-hooks',
				'wp-hooks',
			)
		);
	}

	/**
	 * Refresh icon-library VB script deps after Divi registers window-specific vendors.
	 *
	 * @return void
	 */
	public function finalize_icon_libraries_vb_script_dependencies(): void {
		if (
			! function_exists( 'dsm_is_icon_libraries_extension_enabled' )
			|| ! dsm_is_icon_libraries_extension_enabled()
		) {
			return;
		}
		if ( ! function_exists( 'et_core_is_fb_enabled' ) || ! et_core_is_fb_enabled() ) {
			return;
		}
		if ( ! $this->host->is_divi_5_installed_and_active() ) {
			return;
		}

		$dsm_version = defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';

		$this->register_icon_libraries_vb_hooks_script( $dsm_version );
		$this->register_icon_libraries_vb_ui_script( $dsm_version );
		$this->dsm_ensure_icon_libraries_hooks_before_divi_icon_library();
	}

	/**
	 * Register Icon Libraries VB hook bootstrap (must load before `divi-icon-library`).
	 *
	 * @param string $dsm_version Plugin semver.
	 * @return void
	 */
	private function register_icon_libraries_vb_hooks_script( string $dsm_version ): void {
		if (
			! function_exists( 'dsm_is_icon_libraries_extension_enabled' )
			|| ! dsm_is_icon_libraries_extension_enabled()
		) {
			return;
		}

		$file = DSM_DIR_PATH . 'divi-5/public/icon-libraries-vb-hooks.js';

		if ( ! is_readable( $file ) ) {
			return;
		}

		$deps = array_merge(
			$this->resolve_registered_script_deps(
				array(
					'dsm-icon-libraries-vb-bootstrap',
				)
			),
			$this->get_icon_libraries_vb_wp_hooks_dependency_handles()
		);

		if ( wp_script_is( 'dsm-icon-libraries-vb-hooks', 'registered' ) ) {
			global $wp_scripts;

			if ( $wp_scripts instanceof \WP_Scripts && isset( $wp_scripts->registered['dsm-icon-libraries-vb-hooks'] ) ) {
				$wp_scripts->registered['dsm-icon-libraries-vb-hooks']->deps = $deps;
			}

			return;
		}

		wp_register_script(
			'dsm-icon-libraries-vb-hooks',
			DSM_DIR_URL . 'public/icon-libraries-vb-hooks.js',
			$deps,
			$dsm_version . '-' . (string) filemtime( $file ),
			true
		);
	}

	/**
	 * Adds `dsm-icon-libraries-vb-hooks` as a dependency of Divi's `divi-icon-library`.
	 *
	 * Divi evaluates fontIconTypes / fontIconFilters once at icon-library parse time.
	 *
	 * @return void
	 */
	public function dsm_ensure_icon_libraries_hooks_before_divi_icon_library(): void {
		if (
			! function_exists( 'dsm_is_icon_libraries_extension_enabled' )
			|| ! dsm_is_icon_libraries_extension_enabled()
		) {
			return;
		}
		if ( ! function_exists( 'et_core_is_fb_enabled' ) || ! et_core_is_fb_enabled() ) {
			return;
		}
		if ( ! $this->host->is_divi_5_installed_and_active() ) {
			return;
		}

		global $wp_scripts;

		if ( ! ( $wp_scripts instanceof \WP_Scripts ) ) {
			return;
		}

		$icon_lib_handle = 'divi-icon-library';
		$hooks_handle    = 'dsm-icon-libraries-vb-hooks';

		if (
			empty( $wp_scripts->registered[ $icon_lib_handle ] )
			|| empty( $wp_scripts->registered[ $hooks_handle ] )
		) {
			return;
		}

		$icon_lib = $wp_scripts->registered[ $icon_lib_handle ];

		if ( ! is_array( $icon_lib->deps ) ) {
			$icon_lib->deps = array();
		}

		if ( in_array( $hooks_handle, $icon_lib->deps, true ) ) {
			return;
		}

		array_unshift( $icon_lib->deps, $hooks_handle );
	}

	/**
	 * Register mask/pattern VB hook bootstrap (must load before `divi-mask-and-pattern-library`).
	 *
	 * @param string $dsm_version Plugin semver.
	 * @return void
	 */
	private function register_mask_pattern_library_vb_hooks_script( string $dsm_version ): void {
		if (
			! function_exists( 'dsm_is_mask_pattern_library_extension_enabled' )
			|| ! dsm_is_mask_pattern_library_extension_enabled()
		) {
			return;
		}

		$file = DSM_DIR_PATH . 'divi-5/public/mask-pattern-library-vb-hooks.js';

		if ( ! is_readable( $file ) ) {
			return;
		}

		$deps = array_merge(
			$this->resolve_registered_script_deps(
				array(
					'dsm-mask-pattern-library-vb-bootstrap',
				)
			),
			$this->get_icon_libraries_vb_wp_hooks_dependency_handles()
		);

		if ( wp_script_is( 'dsm-mask-pattern-library-vb-hooks', 'registered' ) ) {
			global $wp_scripts;

			if ( $wp_scripts instanceof \WP_Scripts && isset( $wp_scripts->registered['dsm-mask-pattern-library-vb-hooks'] ) ) {
				$wp_scripts->registered['dsm-mask-pattern-library-vb-hooks']->deps = $deps;
			}

			return;
		}

		wp_register_script(
			'dsm-mask-pattern-library-vb-hooks',
			DSM_DIR_URL . 'public/mask-pattern-library-vb-hooks.js',
			$deps,
			$dsm_version . '-' . (string) filemtime( $file ),
			true
		);
	}

	/**
	 * Enqueue mask/pattern VB hook script after inline bootstrap is registered.
	 *
	 * @param string $dsm_version Plugin semver.
	 * @return void
	 */
	private function enqueue_mask_pattern_library_vb_early_scripts( string $dsm_version ): void {
		if (
			! function_exists( 'dsm_is_mask_pattern_library_extension_enabled' )
			|| ! dsm_is_mask_pattern_library_extension_enabled()
		) {
			return;
		}

		if ( ! function_exists( 'et_core_is_fb_enabled' ) || ! et_core_is_fb_enabled() ) {
			return;
		}
		if ( ! $this->host->is_divi_5_installed_and_active() ) {
			return;
		}

		$this->register_mask_pattern_library_vb_hooks_script( $dsm_version );

		if ( wp_script_is( 'dsm-mask-pattern-library-vb-hooks', 'registered' ) ) {
			wp_enqueue_script( 'dsm-mask-pattern-library-vb-hooks' );
		}

		$this->dsm_ensure_mask_pattern_library_hooks_before_divi_library();
	}

	/**
	 * Adds `dsm-mask-pattern-library-vb-hooks` as a dependency of Divi's mask/pattern library bundle.
	 *
	 * @return void
	 */
	public function dsm_ensure_mask_pattern_library_hooks_before_divi_library(): void {
		if (
			! function_exists( 'dsm_is_mask_pattern_library_extension_enabled' )
			|| ! dsm_is_mask_pattern_library_extension_enabled()
		) {
			return;
		}

		if ( ! function_exists( 'et_core_is_fb_enabled' ) || ! et_core_is_fb_enabled() ) {
			return;
		}
		if ( ! $this->host->is_divi_5_installed_and_active() ) {
			return;
		}

		global $wp_scripts;

		if ( ! ( $wp_scripts instanceof \WP_Scripts ) ) {
			return;
		}

		$library_handle = 'divi-mask-and-pattern-library';
		$hooks_handle   = 'dsm-mask-pattern-library-vb-hooks';

		if (
			empty( $wp_scripts->registered[ $library_handle ] )
			|| empty( $wp_scripts->registered[ $hooks_handle ] )
		) {
			return;
		}

		$library = $wp_scripts->registered[ $library_handle ];

		if ( ! is_array( $library->deps ) ) {
			$library->deps = array();
		}

		if ( in_array( $hooks_handle, $library->deps, true ) ) {
			return;
		}

		array_unshift( $library->deps, $hooks_handle );
	}

	/**
	 * REST config for icon library VB fetch calls (top window + app iframe).
	 *
	 * @return array{restUrl:string,restNonce:string}
	 */
	private function get_icon_libraries_rest_script_data(): array {
		return array(
			'restUrl'   => esc_url_raw( rest_url( 'dsm/v1/icon-libraries' ) ),
			'restNonce' => wp_create_nonce( 'wp_rest' ),
		);
	}

	/**
	 * Build VB bootstrap payload for icon libraries (top + app windows).
	 *
	 * @return array<string, mixed>
	 */
	private function get_icon_libraries_vb_bootstrap(): array {
		$bootstrap = array(
			'enabled'       => false,
			'libraryIds'    => array(),
			'manifestRows'  => array(),
			'libraryLabels' => array(),
		);

		if (
			! function_exists( 'dsm_is_icon_libraries_extension_enabled' )
			|| ! dsm_is_icon_libraries_extension_enabled()
			|| ! class_exists( \DiviSupreme\Extensions\IconLibraries\IconLibraryRegistry::class )
		) {
			return $bootstrap;
		}

		$enabled_libraries   = \DiviSupreme\Extensions\IconLibraries\IconLibraryRegistry::enabled();
		$enabled_library_ids = array_keys( $enabled_libraries );
		$library_labels      = array();

		foreach ( $enabled_libraries as $library_id => $library ) {
			$library_labels[ $library_id ] = $library->get_label();
		}

		if ( array() === $enabled_library_ids ) {
			return $bootstrap;
		}

		return array(
			'enabled'                  => true,
			'libraryIds'               => $enabled_library_ids,
			'manifestRows'             => \DiviSupreme\Extensions\IconLibraries\IconLibraryRegistry::get_divi_icon_list_rows_for_enabled(),
			'libraryLabels'            => $library_labels,
			'pickerWebfontStylesheets' => \DiviSupreme\Extensions\IconLibraries\IconLibraryRegistry::get_vb_picker_webfont_stylesheets(),
			'iconLibrariesCatalog'     => \DiviSupreme\Extensions\IconLibraries\IconLibraryRegistry::get_public_catalog(),
		) + $this->get_icon_libraries_rest_script_data();
	}

	/**
	 * Inline bootstrap + enqueue early hook script (before `divi-icon-library`).
	 *
	 * @param string $dsm_version Plugin semver.
	 * @return void
	 */
	private function enqueue_icon_libraries_vb_early_scripts( string $dsm_version ): void {
		if (
			! function_exists( 'dsm_is_icon_libraries_extension_enabled' )
			|| ! dsm_is_icon_libraries_extension_enabled()
		) {
			return;
		}

		static $bootstrap_inlined = false;

		$bootstrap = $this->get_icon_libraries_vb_bootstrap();

		if ( ! wp_script_is( 'dsm-icon-libraries-vb-bootstrap', 'registered' ) ) {
			wp_register_script(
				'dsm-icon-libraries-vb-bootstrap',
				false,
				array(),
				$dsm_version,
				true
			);
		}

		if ( ! $bootstrap_inlined ) {
			wp_add_inline_script(
				'dsm-icon-libraries-vb-bootstrap',
				'window.__dsmIconLibrariesExtensionEnabled=' . ( $bootstrap['enabled'] ? 'true' : 'false' ) .
				';window.dsmIconLibrariesVbBootstrap=' . wp_json_encode( $bootstrap ) . ';',
				'after'
			);
			$bootstrap_inlined = true;
		}

		wp_enqueue_script( 'dsm-icon-libraries-vb-bootstrap' );

		$this->register_icon_libraries_vb_hooks_script( $dsm_version );
		wp_enqueue_script( 'dsm-icon-libraries-vb-hooks' );
		$this->dsm_ensure_icon_libraries_hooks_before_divi_icon_library();
	}

	/**
	 * Register top-window VB UI script (icon picker filter + webfont previews).
	 *
	 * @param string $dsm_version Plugin semver.
	 * @return void
	 */
	private function register_icon_libraries_vb_ui_script( string $dsm_version ): void {
		if (
			! function_exists( 'dsm_is_icon_libraries_extension_enabled' )
			|| ! dsm_is_icon_libraries_extension_enabled()
		) {
			return;
		}

		$file = DSM_DIR_PATH . 'divi-5/public/icon-libraries-vb-ui.js';

		if ( ! is_readable( $file ) ) {
			return;
		}

		$deps = array_merge(
			$this->resolve_registered_script_deps(
				array(
					'dsm-icon-libraries-vb-bootstrap',
					'dsm-icon-libraries-vb-hooks',
				)
			),
			$this->get_icon_libraries_vb_wp_hooks_dependency_handles()
		);

		if ( wp_script_is( 'dsm-icon-libraries-vb-ui', 'registered' ) ) {
			global $wp_scripts;

			if ( $wp_scripts instanceof \WP_Scripts && isset( $wp_scripts->registered['dsm-icon-libraries-vb-ui'] ) ) {
				$wp_scripts->registered['dsm-icon-libraries-vb-ui']->deps = $deps;
			}

			return;
		}

		wp_register_script(
			'dsm-icon-libraries-vb-ui',
			DSM_DIR_URL . 'public/icon-libraries-vb-ui.js',
			$deps,
			$dsm_version . '-' . (string) filemtime( $file ),
			true
		);

		wp_localize_script(
			'dsm-icon-libraries-vb-ui',
			'dsmIconLibraries',
			$this->get_icon_libraries_rest_script_data()
		);

		if ( ! wp_style_is( 'dsm-icon-libraries-vb-ui', 'registered' ) ) {
			$css_file = DSM_DIR_PATH . 'divi-5/public/icon-libraries-vb-ui.css';

			if ( is_readable( $css_file ) ) {
				wp_register_style(
					'dsm-icon-libraries-vb-ui',
					DSM_DIR_URL . 'public/icon-libraries-vb-ui.css',
					array(),
					$dsm_version . '-' . (string) filemtime( $css_file )
				);
			}
		}
	}

	/**
	 * Top-window VB assets — icon picker lives here (field panel), not the app iframe.
	 *
	 * @return void
	 */
	public function load_vb_top_window_icon_libraries_assets(): void {
		if ( ! function_exists( 'et_core_is_fb_enabled' ) || ! et_core_is_fb_enabled() ) {
			return;
		}
		if ( ! $this->host->is_divi_5_installed_and_active() ) {
			return;
		}
		if (
			! function_exists( 'dsm_is_icon_libraries_extension_enabled' )
			|| ! dsm_is_icon_libraries_extension_enabled()
		) {
			return;
		}

		$dsm_version = defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';

		$this->enqueue_icon_libraries_vb_early_scripts( $dsm_version );
		$this->register_icon_libraries_vb_ui_script( $dsm_version );
		$this->enqueue_icon_libraries_vb_picker_webfonts( $dsm_version );

		if ( wp_script_is( 'dsm-icon-libraries-vb-ui', 'registered' ) ) {
			wp_enqueue_script( 'dsm-icon-libraries-vb-ui' );
		}

		if ( wp_style_is( 'dsm-icon-libraries-vb-ui', 'registered' ) ) {
			wp_enqueue_style( 'dsm-icon-libraries-vb-ui' );
		}
	}

	/**
	 * Register self-hosted webfont stylesheets for the VB icon picker (lazy-loaded via JS).
	 *
	 * @param string $dsm_version Plugin semver.
	 * @return void
	 */
	private function enqueue_icon_libraries_vb_picker_webfonts( string $dsm_version ): void {
		if (
			! function_exists( 'dsm_is_icon_libraries_extension_enabled' )
			|| ! dsm_is_icon_libraries_extension_enabled()
			|| ! class_exists( \DiviSupreme\Extensions\IconLibraries\IconLibraryRegistry::class )
		) {
			return;
		}

		foreach ( \DiviSupreme\Extensions\IconLibraries\IconLibraryRegistry::get_vb_picker_webfont_stylesheets() as $sheet ) {
			$handle = (string) ( $sheet['handle'] ?? '' );
			$url    = (string) ( $sheet['url'] ?? '' );
			$path   = (string) ( $sheet['path'] ?? '' );

			if ( '' === $handle || '' === $url || ! is_readable( $path ) ) {
				continue;
			}

			if ( ! wp_style_is( $handle, 'registered' ) ) {
				wp_register_style(
					$handle,
					$url,
					array(),
					(string) filemtime( $path )
				);
			}
		}
	}

	/**
	 * Register Image Parallax Visual Builder field-panel script (app window).
	 *
	 * @param string $dsm_version Plugin version string.
	 * @return void
	 */
	private function register_image_parallax_vb_script( string $dsm_version ): void {
		if (
			! function_exists( 'dsm_is_image_parallax_extension_enabled' )
			|| ! dsm_is_image_parallax_extension_enabled()
		) {
			return;
		}

		if ( wp_script_is( 'dsm-image-parallax-vb', 'registered' ) ) {
			return;
		}

		$file = DSM_DIR_PATH . 'divi-5/public/image-parallax-vb.js';

		if ( ! is_readable( $file ) ) {
			return;
		}

		wp_register_script(
			'dsm-image-parallax-vb',
			DSM_DIR_URL . 'public/image-parallax-vb.js',
			array(
				'dsm-supreme-vb-config',
				'react',
				'jquery',
				'divi-module-library',
				'divi-edit-post',
				'divi-rest',
				'wp-hooks',
				'wp-dom',
				'wp-api-fetch',
			),
			$dsm_version . '-' . (string) filemtime( $file ),
			true
		);
	}

	/**
	 * Enqueue Image Parallax VB assets (field panels under image upload fields).
	 *
	 * @param string $dsm_version Plugin version string.
	 * @return void
	 */
	public function enqueue_image_parallax_vb_assets( string $dsm_version ): void {
		if (
			! function_exists( 'dsm_is_image_parallax_extension_enabled' )
			|| ! dsm_is_image_parallax_extension_enabled()
		) {
			return;
		}

		$this->register_image_parallax_vb_script( $dsm_version );

		if ( ! wp_script_is( 'dsm-image-parallax-vb', 'registered' ) ) {
			return;
		}

		wp_enqueue_script( 'dsm-image-parallax-vb' );

		wp_enqueue_style(
			'dsm-extensions-vb-style',
			DSM_DIR_URL . 'public/extensions-vb-styles.css',
			array(),
			$dsm_version
		);
	}

	/**
	 * Loads necessary frontend assets.
	 *
	 * @return void
	 */
	public function load_frontend_assets() {

		$this->register_supreme_animate_css();
		$this->register_popup_and_shared_style_handles();

		// Shared by carousels and library previews even when a single consumer module is the only one enabled.
		$this->register_library_module_reinit_assets();

		if ( ModuleRegistry::is_setting_enabled( 'PerspectiveImage' ) ) {
			$this->register_supreme_lightbox_assets();
		}
		if ( ModuleRegistry::is_setting_enabled( 'BeforeAfterImage' ) ) {
			$this->register_before_after_image_compare_assets();
		}
		if ( ModuleRegistry::is_setting_enabled( 'TiltImage' ) ) {
			$this->register_tilt_image_assets();
		}
		if ( ModuleRegistry::is_setting_enabled( 'RandomImage' ) ) {
			$this->register_random_image_fe_script();
		}
		if ( ModuleRegistry::is_setting_enabled( 'ImageAccordion' ) ) {
			$this->register_image_accordion_assets();
		}
		if ( $this->any_module_enabled( array( 'PostCarousel', 'BlogCarousel' ) ) ) {
			$this->register_post_blog_carousel_shared_assets();
		}
		// Swiper is shared by the carousel modules and Testimonials. Register it when any of them is on
		// so a Testimonials-only site still has `dsm-swiper-library` before render-time enqueue.
		if (
			$this->any_module_enabled(
				array( 'ImageCarousel', 'CardCarousel', 'PostCarousel', 'BlogCarousel', 'Testimonials' )
			)
		) {
			$this->register_image_carousel_assets();
		}
		if ( ModuleRegistry::is_setting_enabled( 'CardCarousel' ) ) {
			$this->register_card_carousel_assets();
		}
		if ( ModuleRegistry::is_setting_enabled( 'PostCarousel' ) ) {
			$this->register_post_carousel_assets();
		}
		if ( ModuleRegistry::is_setting_enabled( 'BlogCarousel' ) ) {
			$this->register_blog_carousel_assets();
		}
		if ( ModuleRegistry::is_setting_enabled( 'MasonryGallery' ) ) {
			$this->register_masonry_gallery_assets();
		}
		if ( ModuleRegistry::is_setting_enabled( 'FilterableGallery' ) ) {
			$this->register_filterable_gallery_assets();
		}
		if ( ModuleRegistry::is_setting_enabled( 'FlipBoxPerk' ) ) {
			$this->register_flipbox_assets();
		}
		if ( ModuleRegistry::is_setting_enabled( 'IconList' ) ) {
			$this->register_icon_list_assets();
		}
		if ( ModuleRegistry::is_setting_enabled( 'Marquee' ) ) {
			$this->register_marquee_assets();
		}
		if ( ModuleRegistry::is_setting_enabled( 'Lottie' ) ) {
			$this->register_lottie_assets();
		}
		if ( ModuleRegistry::is_setting_enabled( 'SvgAnimation' ) ) {
			$this->register_svg_animation_assets();
		}
		if ( ModuleRegistry::is_setting_enabled( 'ImageHoverReveal' ) ) {
			$this->register_image_hover_reveal_assets();
		}
		if ( ModuleRegistry::is_setting_enabled( 'ImageReveal' ) ) {
			$this->register_image_text_reveal_assets();
		}
		if (
			$this->any_module_enabled(
				array( 'ImageReveal', 'OnScrollHeaderAnimation', 'AnimatedHeadline', 'Readmore', 'StackingCard' )
			)
		) {
			$this->register_gsap_scroll_ported_modules_assets();
		}
		if ( ModuleRegistry::is_setting_enabled( 'StackingCard' ) ) {
			$this->register_stacking_card_assets();
		}
		if ( ModuleRegistry::is_setting_enabled( 'ContentToggle' ) ) {
			$this->register_content_toggle_assets();
		}
		if ( ModuleRegistry::is_setting_enabled( 'ContentTimeLine' ) ) {
			$this->register_content_timeline_assets();
		}
		if ( ModuleRegistry::is_setting_enabled( 'CircleInfo' ) ) {
			$this->register_circle_info_assets();
		}
		if ( ModuleRegistry::is_setting_enabled( 'Menu' ) ) {
			$this->register_menu_module_assets();
		}
		if ( ModuleRegistry::is_setting_enabled( 'Buttons' ) ) {
			$this->register_buttons_module_assets();
		}
		if ( ModuleRegistry::is_setting_enabled( 'TypingEffect' ) ) {
			$this->register_typing_effect_assets();
		}
		if ( ModuleRegistry::is_setting_enabled( 'SocialShareButtons' ) ) {
			$this->register_social_share_buttons_assets();
		}
		if ( ModuleRegistry::is_setting_enabled( 'Faq' ) ) {
			$this->register_faq_module_assets();
		}
		if ( ModuleRegistry::is_setting_enabled( 'LoopFilter' ) ) {
			$this->register_loop_filter_module_assets();
		}
		if ( ModuleRegistry::is_setting_enabled( 'Chart' ) ) {
			$this->register_chart_module_assets();
		}
		if ( ModuleRegistry::is_setting_enabled( 'Table' ) ) {
			$this->register_table_module_assets();
		}
		if ( ModuleRegistry::is_setting_enabled( 'TableOfContents' ) ) {
			$this->register_table_of_contents_module_assets();
		}
		if ( ModuleRegistry::is_setting_enabled( 'Testimonials' ) ) {
			$this->register_testimonials_module_assets();
		}
		if ( ModuleRegistry::is_setting_enabled( 'AdvancedTabs' ) ) {
			$this->register_advanced_tabs_module_assets();
		}
		if ( ModuleRegistry::is_setting_enabled( 'ImageHotSpots' ) ) {
			$this->register_image_hotspot_assets();
		}

		if ( function_exists( 'et_core_is_fb_enabled' ) && ! et_core_is_fb_enabled() && ! is_admin() ) {
			$this->register_frontend_only_module_scripts();
		}
	}

	/**
	 * Whether any of the given module toggles is on.
	 *
	 * @param array<int, string> $setting_keys `dsm_modules` keys.
	 * @return bool
	 */
	private function any_module_enabled( array $setting_keys ): bool {
		foreach ( $setting_keys as $setting_key ) {
			if ( ModuleRegistry::is_setting_enabled( $setting_key ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Front-end script handles that are not covered by the gated `register_*` methods above.
	 *
	 * Tippy/Popper stay available for Buttons, hotspots, page tour, and the Tooltip extension.
	 * Icon List's own registrar already loads them when that module is on.
	 *
	 * @return void
	 */
	private function register_frontend_only_module_scripts(): void {
		$dsm_version = defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';

		if (
			$this->any_module_enabled( array( 'FacebookEmbed', 'FacebookSimpleFeed' ) )
			&& ! wp_script_is( 'dsm-facebook', 'registered' )
		) {
			// Facebook SDK loader is vanilla JS (no jQuery). Single registration + plugin version for cache busting.
			wp_register_script(
				'dsm-facebook',
				DSM_DIR_URL . 'assets/js/facebook.js',
				array(),
				$dsm_version,
				true
			);
		}

		if (
			ModuleRegistry::is_setting_enabled( 'ImageAccordion' )
			&& ! wp_script_is( 'dsm-image-accordion', 'registered' )
		) {
			wp_register_script(
				'dsm-image-accordion',
				DSM_DIR_URL . 'assets/js/image-accordion.js',
				array( 'jquery' ),
				$dsm_version,
				true
			);
		}

		$needs_tippy = $this->any_module_enabled( array( 'IconList', 'ImageHotSpots', 'Buttons', 'PageTour' ) )
			|| ( function_exists( 'dsm_is_tooltip_extension_enabled' ) && dsm_is_tooltip_extension_enabled() );

		if ( ! $needs_tippy ) {
			return;
		}

		if ( ! wp_script_is( 'dsm-popper', 'registered' ) ) {
			wp_register_script(
				'dsm-popper',
				DSM_DIR_URL . 'assets/js/popper.js',
				array( 'jquery' ),
				$dsm_version,
				true
			);
		}

		if ( ! wp_script_is( 'dsm-tippy', 'registered' ) ) {
			wp_register_script(
				'dsm-tippy',
				DSM_DIR_URL . 'assets/js/tippy.js',
				array( 'jquery' ),
				$dsm_version,
				true
			);
		}

		if (
			ModuleRegistry::is_setting_enabled( 'IconList' )
			&& ! wp_script_is( 'dsm-icon-list', 'registered' )
		) {
			wp_register_script(
				'dsm-icon-list',
				DSM_DIR_URL . 'assets/js/icon-list.js',
				array( 'jquery' ),
				$dsm_version,
				true
			);
		}
	}

	/**
	 * Legacy entry point; dynamic enqueue is handled by {@see \DiviSupreme\Includes\DsmFrontendDynamicAssets}.
	 *
	 * @return void
	 */
	public function enqueue_divi5_frontend_module_styles() {
		if ( class_exists( \DiviSupreme\Includes\DsmFrontendDynamicAssets::class ) ) {
			\DiviSupreme\Includes\DsmFrontendDynamicAssets::maybe_enqueue_core_module_styles();
		}
	}

	/**
	 * Adds `dsm-supreme-extensions` as a dependency of Divi's `divi-modal-library` when both are registered.
	 *
	 * Divi's modal-library bundle applies `divi.modalLibrary.modalMapping` filters once at parse time.
	 * If our extensions script runs later, the Popup Customiser mapping is never included and
	 * `modalDispatch.open( { name: 'divi/dsm-popup-customiser' } )` is a no-op.
	 *
	 * @return void
	 */
	public function dsm_ensure_extensions_before_divi_modal_library() {
		$needs_modal_library =
			( function_exists( 'dsm_is_supreme_popup_extension_enabled' ) && dsm_is_supreme_popup_extension_enabled() )
			|| ( function_exists( 'dsm_is_custom_cursor_extension_enabled' ) && dsm_is_custom_cursor_extension_enabled() )
			|| ( function_exists( 'dsm_is_preloader_extension_enabled' ) && dsm_is_preloader_extension_enabled() )
			|| ( function_exists( 'dsm_is_dark_mode_extension_enabled' ) && dsm_is_dark_mode_extension_enabled() )
			|| ( function_exists( 'dsm_is_copy_to_clipboard_extension_enabled' ) && dsm_is_copy_to_clipboard_extension_enabled() );

		if ( ! $needs_modal_library ) {
			return;
		}
		if ( ! function_exists( 'et_core_is_fb_enabled' ) || ! et_core_is_fb_enabled() ) {
			return;
		}
		if ( ! $this->host->is_divi_5_installed_and_active() ) {
			return;
		}

		global $wp_scripts;

		if ( ! ( $wp_scripts instanceof \WP_Scripts ) ) {
			return;
		}

		$modal_handle = 'divi-modal-library';
		$ext_handle   = 'dsm-supreme-extensions';

		if ( empty( $wp_scripts->registered[ $modal_handle ] ) || empty( $wp_scripts->registered[ $ext_handle ] ) ) {
			return;
		}

		$modal = $wp_scripts->registered[ $modal_handle ];

		if ( ! is_array( $modal->deps ) ) {
			$modal->deps = array();
		}

		if ( in_array( $ext_handle, $modal->deps, true ) ) {
			return;
		}

		$modal->deps[] = $ext_handle;
	}

	/**
	 * Register and enqueue Swiper + carousel FE scripts for Visual Builder canvas.
	 *
	 * @return void
	 */
	public function enqueue_vb_swiper_carousel_assets(): void {
		$this->register_library_module_reinit_assets();
		$this->register_post_blog_carousel_shared_assets();
		$this->register_image_carousel_assets();
		$this->register_card_carousel_assets();
		$this->register_post_carousel_assets();
		$this->register_blog_carousel_assets();
		wp_enqueue_style( DsmFrontendModuleAssetRegistry::SWIPER_LIBRARY_STYLE_HANDLE );
		wp_enqueue_script( 'dsm-swiper-library' );
		wp_enqueue_script( 'dsm-library-module-reinit' );
		if ( function_exists( 'dsm_enqueue_magnific_popup_assets' ) ) {
			dsm_enqueue_magnific_popup_assets();
		}
		wp_enqueue_script( 'dsm-image-carousel' );
		wp_enqueue_script( 'dsm-card-carousel' );
		wp_enqueue_script( 'dsm-post-carousel' );
		wp_enqueue_script( 'dsm-blog-carousel' );
	}

	/**
	 * Enqueue Swiper + carousel assets in VB top window (Library editor, etc.).
	 *
	 * @return void
	 */
	public function load_vb_top_window_swiper_assets(): void {
		if ( ! function_exists( 'et_core_is_fb_enabled' ) || ! et_core_is_fb_enabled() ) {
			return;
		}
		if ( ! $this->host->is_divi_5_installed_and_active() ) {
			return;
		}

		$this->enqueue_vb_swiper_carousel_assets();
	}

	/**
	 * Add Block Reveal handles only after those scripts are registered.
	 *
	 * WordPress prints `dsm-supreme-modules` when every dependency handle exists.
	 * These two scripts are registered only while a Block Reveal module is on, so
	 * leaving them on the bundle unconditionally removes every Supreme module from
	 * Insert Module.
	 *
	 * @param array<int, string> $dependencies Bundle script handles.
	 * @return array<int, string>
	 */
	private function append_registered_block_reveal_dependencies( array $dependencies ): array {
		foreach ( array( 'dsm-block-reveal-text', 'dsm-block-reveal-image' ) as $handle ) {
			if ( wp_script_is( $handle, 'registered' ) && ! in_array( $handle, $dependencies, true ) ) {
				$dependencies[] = $handle;
			}
		}

		return $dependencies;
	}

	/**
	 * Loads the necessary visual builder assets.
	 *
	 * @return void
	 */
	public function load_vb_assets() {
		$is_vb_app_window = class_exists( '\ET\Builder\Framework\Utility\Conditions' )
			&& \ET\Builder\Framework\Utility\Conditions::is_vb_app_window();

		if ( function_exists( 'et_core_is_fb_enabled' ) && et_core_is_fb_enabled() && $this->host->is_divi_5_installed_and_active() && $is_vb_app_window ) {

			$dsm_version_vb = defined( 'DSM_PRO_VERSION' ) ? DSM_PRO_VERSION : '1.0.0';

			// Swiper before `dsm-supreme-modules` so carousel VB edit components can init on first paint.
			$this->enqueue_vb_swiper_carousel_assets();

			$current_post_type = get_post_type();

			$this->register_before_after_image_compare_assets();
			$this->register_tilt_image_assets();
			$this->register_supreme_lightbox_assets();
			$this->register_block_reveal_assets();
			$this->register_image_text_reveal_assets();
			wp_enqueue_script( 'dsm-gsap' );
			wp_enqueue_script( 'dsm-splitting' );
			wp_enqueue_script( 'dsm-text-reveal' );

			$this->register_gsap_scroll_ported_modules_assets();
			// Preset: enqueue Lenis in VB only; skip global ScrollTrigger / on-scroll FE scripts (breaks modal scroll).
			wp_enqueue_script( 'dsm-lenis' );
			wp_enqueue_script( 'dsm-animated-headline' );
			wp_enqueue_script( 'dsm-readmore' );

			wp_enqueue_style( DsmFrontendModuleAssetRegistry::IMAGE_COMPARE_VIEWER_STYLE_HANDLE );
			wp_enqueue_script( 'dsm-before-after-library' );

			wp_enqueue_script( 'dsm-reveal-library' );
			wp_enqueue_script( 'dsm-block-reveal-text' );
			wp_enqueue_script( 'dsm-block-reveal-image' );

			$this->register_image_accordion_assets();
			wp_enqueue_script( 'dsm-image-accordion' );

			if ( function_exists( 'dsm_enqueue_magnific_popup_assets' ) ) {
				dsm_enqueue_magnific_popup_assets();
			}

			$this->register_masonry_gallery_assets();
			wp_enqueue_script( 'dsm-masonry-gallery' );

			$this->register_filterable_gallery_assets();
			$this->register_flipbox_assets();
			wp_enqueue_style( 'dsm-flipbox-d5' );
			// Shuffle (window.Shuffle) + FE boot for server-rendered library previews in VB.
			// Native filterable modules still use React `edit.js` for layout/filter in the canvas.
			if ( function_exists( 'dsm_enqueue_magnific_popup_assets' ) ) {
				dsm_enqueue_magnific_popup_assets();
			}
			wp_enqueue_script( 'dsm-filterable-library-gallery' );
			wp_enqueue_script( 'dsm-filterable-gallery' );

			$this->register_icon_list_assets();
			$this->register_marquee_assets();
			$this->register_image_hotspot_assets();
			wp_enqueue_script( 'dsm-popper' );
			wp_enqueue_script( 'dsm-tippy' );
			wp_enqueue_script( 'dsm-icon-list' );
			wp_enqueue_script( 'dsm-image-hotspot' );

			// Copy to Clipboard / Tooltip canvas Tippy need the library in the VB app frame.
			if (
				wp_script_is( 'dsm-supreme-extensions', 'registered' )
				&& (
					(
						function_exists( 'dsm_is_copy_to_clipboard_extension_enabled' ) &&
						dsm_is_copy_to_clipboard_extension_enabled()
					)
					|| (
						function_exists( 'dsm_is_tooltip_extension_enabled' ) &&
						dsm_is_tooltip_extension_enabled()
					)
				)
			) {
				$ext = wp_scripts()->registered['dsm-supreme-extensions'] ?? null;
				if ( $ext && is_array( $ext->deps ) && ! in_array( 'dsm-tippy', $ext->deps, true ) ) {
					$ext->deps[] = 'dsm-tippy';
				}
			}

			$this->register_menu_module_assets();
			wp_enqueue_script( 'dsm-menu' );

			$this->register_buttons_module_assets();
			wp_enqueue_script( 'dsm-buttons' );

			$this->register_typing_effect_assets();
			wp_enqueue_script( 'dsm-typing-library' );
			wp_enqueue_script( 'dsm-typing' );

			$this->register_social_share_buttons_assets();
			wp_enqueue_script( 'dsm-social-share-button' );

			$this->register_faq_module_assets();
			wp_enqueue_script( 'dsm-faq' );
			$this->register_table_of_contents_module_assets();
			$this->register_testimonials_module_assets();
			wp_enqueue_script( 'dsm-testimonials' );
			$this->register_advanced_tabs_module_assets();
			$this->register_content_timeline_assets();
			wp_enqueue_script( 'dsm-content-timeline' );
			$this->register_circle_info_assets();
			wp_enqueue_script( 'dsm-circle-info' );

			// DSM extensions bundle (`extensions.js`) + extensions CSS — Popup / Line Hover Animation / Supreme Parallax when enabled under General settings.
			$dsm_supreme_popup_extension_enabled        = function_exists( 'dsm_is_supreme_popup_extension_enabled' )
				? dsm_is_supreme_popup_extension_enabled()
				: false;
			$dsm_line_hover_animation_extension_enabled = function_exists(
				'dsm_is_line_hover_animation_extension_enabled'
			)
				? dsm_is_line_hover_animation_extension_enabled()
				: false;
			$dsm_supreme_parallax_extension_enabled     = function_exists(
				'dsm_is_supreme_parallax_extension_enabled'
			)
				? dsm_is_supreme_parallax_extension_enabled()
				: false;
			$dsm_image_parallax_extension_enabled       = function_exists(
				'dsm_is_image_parallax_extension_enabled'
			)
				? dsm_is_image_parallax_extension_enabled()
				: false;
			$dsm_custom_cursor_extension_enabled        = function_exists(
				'dsm_is_custom_cursor_extension_enabled'
			)
				? dsm_is_custom_cursor_extension_enabled()
				: false;
			$dsm_preloader_extension_enabled            = function_exists(
				'dsm_is_preloader_extension_enabled'
			)
				? dsm_is_preloader_extension_enabled()
				: false;
			$dsm_dark_mode_extension_enabled            = function_exists(
				'dsm_is_dark_mode_extension_enabled'
			)
				? dsm_is_dark_mode_extension_enabled()
				: false;
			$dsm_icon_libraries_extension_enabled       = function_exists(
				'dsm_is_icon_libraries_extension_enabled'
			)
				? dsm_is_icon_libraries_extension_enabled()
				: false;
			$dsm_click_to_copy_extension_enabled        = function_exists(
				'dsm_is_copy_to_clipboard_extension_enabled'
			)
				? dsm_is_copy_to_clipboard_extension_enabled()
				: false;
			$dsm_loop_filter_extension_enabled          = function_exists(
				'dsm_is_loop_filter_extension_enabled'
			)
				? dsm_is_loop_filter_extension_enabled()
				: false;
			$dsm_tooltip_extension_enabled              = function_exists( 'dsm_is_tooltip_extension_enabled' )
				? dsm_is_tooltip_extension_enabled()
				: false;
			$dsm_page_tour_extension_enabled            = function_exists( 'dsm_is_page_tour_extension_enabled' )
				? dsm_is_page_tour_extension_enabled()
				: false;
			// Block Password Protection VB UI — gated by Extensions → Password Protection.
			$dsm_password_protection_block_enabled      = class_exists(
				\DiviSupreme\Extensions\PasswordProtection::class
			) && function_exists( 'dsm_is_password_protection_extension_enabled' )
				&& dsm_is_password_protection_extension_enabled();
			$dsm_contact_form_entries_extension_enabled = function_exists(
				'dsm_is_contact_form_entries_extension_enabled'
			)
				? dsm_is_contact_form_entries_extension_enabled()
				: false;

			$dsm_client_handoff_extension_enabled   = function_exists(
				'dsm_is_client_handoff_extension_enabled'
			)
				? dsm_is_client_handoff_extension_enabled()
				: false;
			$dsm_client_handoff_lock_content_groups = class_exists(
				\DiviSupreme\Extensions\ClientHandoff::class
			) && \DiviSupreme\Extensions\ClientHandoff::should_lock_editor_content_groups();

			$dsm_supreme_extensions_bundle_enabled = $dsm_supreme_popup_extension_enabled ||
				$dsm_line_hover_animation_extension_enabled ||
				$dsm_supreme_parallax_extension_enabled ||
				$dsm_image_parallax_extension_enabled ||
				$dsm_custom_cursor_extension_enabled ||
				$dsm_dark_mode_extension_enabled ||
				$dsm_icon_libraries_extension_enabled ||
				$dsm_click_to_copy_extension_enabled ||
				$dsm_loop_filter_extension_enabled ||
				$dsm_preloader_extension_enabled ||
				$dsm_dark_mode_extension_enabled ||
				$dsm_icon_libraries_extension_enabled ||
				$dsm_click_to_copy_extension_enabled ||
				$dsm_tooltip_extension_enabled ||
				$dsm_page_tour_extension_enabled ||
				$dsm_password_protection_block_enabled ||
				$dsm_contact_form_entries_extension_enabled ||
				$dsm_client_handoff_extension_enabled;

			$global_popups_vb = array();
			if ( $dsm_supreme_popup_extension_enabled && class_exists( \DiviSupreme\Extensions\Popup::class ) ) {
				$global_popups_vb = ( new \DiviSupreme\Extensions\Popup() )->get_global_popups();
			}

			$custom_cursor_settings_vb = array();
			if ( $dsm_custom_cursor_extension_enabled && isset( $GLOBALS['dsm_custom_cursor_extension'] )
				&& $GLOBALS['dsm_custom_cursor_extension'] instanceof \DiviSupreme\Extensions\CustomCursor ) {
				$custom_cursor_settings_vb = $GLOBALS['dsm_custom_cursor_extension']->get_settings();
			}

			$preloader_settings_vb = array();
			if ( $dsm_preloader_extension_enabled && isset( $GLOBALS['dsm_preloader_extension'] )
				&& $GLOBALS['dsm_preloader_extension'] instanceof \DiviSupreme\Extensions\Preloader ) {
				$preloader_settings_vb = $GLOBALS['dsm_preloader_extension']->get_settings();
			}

			$dark_mode_settings_vb = array();
			if ( $dsm_dark_mode_extension_enabled && isset( $GLOBALS['dsm_dark_mode_extension'] )
				&& $GLOBALS['dsm_dark_mode_extension'] instanceof \DiviSupreme\Extensions\DarkMode ) {
				$dark_mode_settings_vb = $GLOBALS['dsm_dark_mode_extension']->get_settings();
			}

			$cursor_scope_quick_picks_vb    = array();
			$dark_mode_scope_quick_picks_vb = array();
			$cursor_scope_quick_picks_vb    = array();
			$dark_mode_scope_quick_picks_vb = array();
			$preloader_scope_quick_picks_vb = array();
			$scope_quick_picks_post_id      = function_exists( 'dsm_get_vb_builder_edited_post_id' )
				? dsm_get_vb_builder_edited_post_id()
				: 0;
			if ( function_exists( 'dsm_get_custom_cursor_scope_quick_picks' ) ) {
				if ( $dsm_custom_cursor_extension_enabled ) {
					$cursor_scope_quick_picks_vb = dsm_get_custom_cursor_scope_quick_picks(
						$scope_quick_picks_post_id
					);
				}
				if ( $dsm_dark_mode_extension_enabled ) {
					$dark_mode_scope_quick_picks_vb = dsm_get_custom_cursor_scope_quick_picks(
						$scope_quick_picks_post_id
					);
				}
				if ( $dsm_preloader_extension_enabled ) {
					$preloader_scope_quick_picks_vb = dsm_get_custom_cursor_scope_quick_picks(
						$scope_quick_picks_post_id
					);
				}
			}

			$this->register_popup_and_shared_style_handles();

			$popup_ext_flag_js        = $dsm_supreme_popup_extension_enabled ? 'true' : 'false';
			$lh_animation_ext_flag_js = $dsm_line_hover_animation_extension_enabled ? 'true' : 'false';
			$parallax_ext_flag_js     = $dsm_supreme_parallax_extension_enabled ? 'true' : 'false';
			$image_parallax_flag_js   = $dsm_image_parallax_extension_enabled ? 'true' : 'false';
			$custom_cursor_flag_js    = $dsm_custom_cursor_extension_enabled ? 'true' : 'false';
			$dark_mode_flag_js        = $dsm_dark_mode_extension_enabled ? 'true' : 'false';
			$icon_libraries_flag_js   = $dsm_icon_libraries_extension_enabled ? 'true' : 'false';
			$click_to_copy_flag_js    = $dsm_click_to_copy_extension_enabled ? 'true' : 'false';
			$loop_filter_flag_js      = $dsm_loop_filter_extension_enabled ? 'true' : 'false';
			// Real boolean for VB (wp_localize_script stringifies scalars → `"1"` / `""`).
			$woocommerce_active_flag_js  = class_exists( 'WooCommerce' ) ? 'true' : 'false';
			$preloader_flag_js           = $dsm_preloader_extension_enabled ? 'true' : 'false';
			$dark_mode_flag_js           = $dsm_dark_mode_extension_enabled ? 'true' : 'false';
			$icon_libraries_flag_js      = $dsm_icon_libraries_extension_enabled ? 'true' : 'false';
			$click_to_copy_flag_js       = $dsm_click_to_copy_extension_enabled ? 'true' : 'false';
			$tooltip_flag_js             = $dsm_tooltip_extension_enabled ? 'true' : 'false';
			$page_tour_flag_js           = $dsm_page_tour_extension_enabled ? 'true' : 'false';
			$pp_block_flag_js            = $dsm_password_protection_block_enabled ? 'true' : 'false';
			$cf_entries_flag_js          = $dsm_contact_form_entries_extension_enabled ? 'true' : 'false';
			$handoff_lock_groups_flag_js = $dsm_client_handoff_lock_content_groups ? 'true' : 'false';
			$icon_libraries_catalog_vb   = array();
			$icon_libraries_vb_bootstrap = array(
				'enabled'       => false,
				'libraryIds'    => array(),
				'libraryLabels' => array(),
			);
			if ( $dsm_icon_libraries_extension_enabled && class_exists( \DiviSupreme\Extensions\IconLibraries\IconLibraryRegistry::class ) ) {
				$icon_libraries_catalog_vb = \DiviSupreme\Extensions\IconLibraries\IconLibraryRegistry::get_public_catalog();
				$enabled_libraries         = \DiviSupreme\Extensions\IconLibraries\IconLibraryRegistry::enabled();
				$enabled_library_ids       = array_keys( $enabled_libraries );
				$library_labels            = array();

				foreach ( $enabled_libraries as $library_id => $library ) {
					$library_labels[ $library_id ] = $library->get_label();
				}

				// Do not send manifestRows: [] — Object.assign would wipe the
				// full top-window bootstrap. Rows stay on the early inline script.
				$icon_libraries_vb_bootstrap = array(
					'enabled'                  => count( $enabled_library_ids ) > 0,
					'libraryIds'               => $enabled_library_ids,
					'libraryLabels'            => $library_labels,
					'pickerWebfontStylesheets' => \DiviSupreme\Extensions\IconLibraries\IconLibraryRegistry::get_vb_picker_webfont_stylesheets(),
					'iconLibrariesCatalog'     => $icon_libraries_catalog_vb,
				);
			}
			if ( ! wp_script_is( 'dsm-supreme-vb-config', 'registered' ) ) {
				wp_register_script(
					'dsm-supreme-vb-config',
					false,
					array(),
					$dsm_version_vb,
					true
				);
			}
			wp_add_inline_script(
				'dsm-supreme-vb-config',
				'window.__dsmSupremePopupExtensionEnabled=' . $popup_ext_flag_js .
				';window.__dsmSupremeLineHoverAnimationExtensionEnabled=' . $lh_animation_ext_flag_js .
				';window.__dsmSupremeParallaxExtensionEnabled=' . $parallax_ext_flag_js .
				';window.__dsmImageParallaxExtensionEnabled=' . $image_parallax_flag_js .
				';window.__dsmCustomCursorExtensionEnabled=' . $custom_cursor_flag_js .
				';window.__dsmPreloaderExtensionEnabled=' . $preloader_flag_js .
				';window.__dsmDarkModeExtensionEnabled=' . $dark_mode_flag_js .
				';window.__dsmIconLibrariesExtensionEnabled=' . $icon_libraries_flag_js .
				';window.__dsmCopyToClipboardExtensionEnabled=' . $click_to_copy_flag_js .
				';window.__dsmClickToCopyExtensionEnabled=' . $click_to_copy_flag_js .
				';window.__dsmLoopFilterExtensionEnabled=' . $loop_filter_flag_js .
				';window.__dsmWoocommerceActive=' . $woocommerce_active_flag_js .
				';window.__dsmTooltipExtensionEnabled=' . $tooltip_flag_js .
				';window.__dsmPageTourExtensionEnabled=' . $page_tour_flag_js .
				';window.__dsmPasswordProtectionBlockEnabled=' . $pp_block_flag_js .
				';window.__dsmContactFormEntriesExtensionEnabled=' . $cf_entries_flag_js .
				';window.__dsmClientHandoffLockContentGroups=' . $handoff_lock_groups_flag_js .
				';' . ( class_exists( \DiviSupreme\Extensions\ClientHandoff::class ) ? \DiviSupreme\Extensions\ClientHandoff::hidden_bar_tools_inline_assignment() : 'window.__dsmClientHandoffHiddenBarTools=[];' ) .
				';window.dsmIconLibrariesVbBootstrap=Object.assign(window.dsmIconLibrariesVbBootstrap||{},' . wp_json_encode( $icon_libraries_vb_bootstrap ) . ');',
				'after'
			);
			wp_enqueue_script( 'dsm-supreme-vb-config' );

			if ( $dsm_icon_libraries_extension_enabled ) {
				$this->enqueue_icon_libraries_vb_early_scripts( $dsm_version_vb );
			}

			$this->enqueue_mask_pattern_library_vb_early_scripts( $dsm_version_vb );

			if ( $dsm_image_parallax_extension_enabled ) {
				$this->enqueue_image_parallax_vb_assets( $dsm_version_vb );
			}

			if ( $dsm_supreme_extensions_bundle_enabled ) {
				wp_enqueue_style( DsmFrontendModuleAssetRegistry::EXTENSION_POPUP_STYLE_HANDLE );

				if ( $dsm_supreme_popup_extension_enabled ) {
					if ( function_exists( 'dsm_enqueue_magnific_popup_assets' ) ) {
						dsm_enqueue_magnific_popup_assets();
					}
					if ( wp_script_is( 'dsm-popup-extension', 'registered' ) ) {
						wp_enqueue_script( 'dsm-popup-extension' );
					}
				}

				// Register extensions before modules: Popup + Line Hover filters live in extensions.js.
				wp_enqueue_script(
					'dsm-supreme-extensions',
					DSM_DIR_URL . 'public/extensions.js',
					array(
						'dsm-supreme-vb-config',
						'react',
						'jquery',
						'divi-module-library',
						'divi-rest',
						'wp-hooks',
						'wp-dom',
						'wp-api-fetch',
					),
					$dsm_version_vb,
					true
				);

				// Bootstrap `diviSupreme5` before extensions.js (popup layout select reads `globalPopups` /
				// `libraryLayouts`). Modules localize overwrites with the full object when that bundle loads.
				wp_localize_script(
					'dsm-supreme-extensions',
					'diviSupreme5',
					array(
						'currentPostType'                  => $current_post_type,
						'globalPopups'                     => $global_popups_vb,
						'libraryLayouts'                   => DsmLibraryLayoutSelectOptions::get_options(),
						'navMenus'                         => class_exists( \DSM_Nav_Menus_REST::class )
							? \DSM_Nav_Menus_REST::get_for_vb()
							: array(),
						'dsmSupremePopupExtensionEnabled'  => $dsm_supreme_popup_extension_enabled,
						'dsmCustomCursorExtensionEnabled'  => $dsm_custom_cursor_extension_enabled,
						'dsmPreloaderExtensionEnabled'     => $dsm_preloader_extension_enabled,
						'dsmDarkModeExtensionEnabled'      => $dsm_dark_mode_extension_enabled,
						'dsmIconLibrariesExtensionEnabled' => $dsm_icon_libraries_extension_enabled,
						'dsmCopyToClipboardExtensionEnabled' => $dsm_click_to_copy_extension_enabled,
						// Legacy localize key (pre-rename).
						'dsmClickToCopyExtensionEnabled'   => $dsm_click_to_copy_extension_enabled,
						'dsmLoopFilterExtensionEnabled'    => $dsm_loop_filter_extension_enabled,
						'woocommerceActive'                => class_exists( 'WooCommerce' ),
						'dsmTooltipExtensionEnabled'       => $dsm_tooltip_extension_enabled,
						'dsmPageTourExtensionEnabled'      => $dsm_page_tour_extension_enabled,
						'dsmPasswordProtectionBlockEnabled' => $dsm_password_protection_block_enabled,
						'dsmContactFormEntriesExtensionEnabled' => $dsm_contact_form_entries_extension_enabled,
						'dsmClientHandoffLockContentGroups' => $dsm_client_handoff_lock_content_groups,
						'contactFormTurnstile'             => (
							$dsm_contact_form_entries_extension_enabled
							&& class_exists( \DiviSupreme\Extensions\ContactFormEntries\Turnstile::class )
						)
							? \DiviSupreme\Extensions\ContactFormEntries\Turnstile::get_vb_config()
							: array(),
						'contactFormHcaptcha'              => (
							$dsm_contact_form_entries_extension_enabled
							&& class_exists( \DiviSupreme\Extensions\ContactFormEntries\Hcaptcha::class )
						)
							? \DiviSupreme\Extensions\ContactFormEntries\Hcaptcha::get_vb_config()
							: array(),
						'contactFormFileUpload'            => (
							$dsm_contact_form_entries_extension_enabled
							&& class_exists( \DiviSupreme\Extensions\ContactFormEntries\FileUpload::class )
						)
							? \DiviSupreme\Extensions\ContactFormEntries\FileUpload::get_vb_config()
							: array(),
						'contactFormSubmitLoader'          => (
							$dsm_contact_form_entries_extension_enabled
							&& class_exists( \DiviSupreme\Extensions\ContactFormEntries\SubmitLoader::class )
						)
							? \DiviSupreme\Extensions\ContactFormEntries\SubmitLoader::get_vb_config()
							: array(),
						'passwordProtectionRoles'          => class_exists( PasswordProtection::class )
							? PasswordProtection::get_bypass_role_options_for_js()
							: array(),
						'iconLibrariesCatalog'             => $icon_libraries_catalog_vb,
						'customCursorSettings'             => $custom_cursor_settings_vb,
						'preloaderSettings'                => $preloader_settings_vb,
						'darkModeSettings'                 => $dark_mode_settings_vb,
						'siteName'                         => wp_strip_all_tags( (string) get_bloginfo( 'name' ) ),
						'cursorScopeQuickPicks'            => $cursor_scope_quick_picks_vb,
						'darkModeScopeQuickPicks'          => $dark_mode_scope_quick_picks_vb,
						'preloaderScopeQuickPicks'         => $preloader_scope_quick_picks_vb,
						'breadcrumbsThemeBuilderPreview'   => function_exists( 'dsm_breadcrumbs_get_theme_builder_preview_js_payload' )
							? dsm_breadcrumbs_get_theme_builder_preview_js_payload()
							: array(
								'active' => false,
								'crumbs' => array(),
							),
					)
				);

				if ( $dsm_icon_libraries_extension_enabled ) {
					wp_localize_script(
						'dsm-supreme-extensions',
						'dsmIconLibraries',
						array(
							'restUrl'   => esc_url_raw( rest_url( 'dsm/v1/icon-libraries' ) ),
							'restNonce' => wp_create_nonce( 'wp_rest' ),
						)
					);
				}

				$this->dsm_ensure_extensions_before_divi_modal_library();

				wp_enqueue_style(
					'dsm-extensions-vb-style',
					DSM_DIR_URL . 'public/extensions-vb-styles.css',
					array(),
					$dsm_version_vb
				);

				if ( $dsm_supreme_parallax_extension_enabled ) {
					$this->register_supreme_parallax_frontend_script(
						$dsm_version_vb
					);
					wp_enqueue_script( 'dsm-supreme-parallax-frontend' );
				}

				if ( $dsm_image_parallax_extension_enabled ) {
					$this->register_image_parallax_frontend_script(
						$dsm_version_vb
					);
					wp_enqueue_script( 'dsm-image-parallax-frontend' );
				}
			}

			$divi_supreme_modules_deps = array(
				'dsm-supreme-vb-config',
				'react',
				'jquery',
				'divi-module-library',
				'divi-rest',
				'wp-hooks',
				'wp-dom',
				'wp-api-fetch',
				'divi-script-library-ext-waypoint',
				'dsm-swiper-library',
				'dsm-text-reveal',
				'dsm-image-accordion',
				'dsm-image-carousel',
				'dsm-card-carousel',
				'dsm-post-carousel',
				'dsm-blog-carousel',
				'dsm-masonry-gallery',
				'dsm-filterable-library-gallery',
				'dsm-icon-list',
				'dsm-image-hotspot',
				'dsm-menu',
				'dsm-buttons',
				'dsm-social-share-button',
				'dsm-faq',
				'dsm-toc',
				'dsm-testimonials',
				'dsm-advanced-tabs',
				'dsm-content-timeline',
				'dsm-circle-info',
			);
			$divi_supreme_modules_deps = $this->append_registered_block_reveal_dependencies( $divi_supreme_modules_deps );
			if ( $dsm_supreme_extensions_bundle_enabled ) {
				$divi_supreme_modules_deps[] = 'dsm-supreme-extensions';
			}
			if ( $dsm_image_parallax_extension_enabled ) {
				$divi_supreme_modules_deps[] = 'dsm-image-parallax-vb';
			}
			// Design → Copy to Clipboard / Advanced → Tooltip need Tippy in the modules VB window.
			if (
				(
					function_exists( 'dsm_is_copy_to_clipboard_extension_enabled' ) &&
					dsm_is_copy_to_clipboard_extension_enabled()
				)
				|| (
					function_exists( 'dsm_is_tooltip_extension_enabled' ) &&
					dsm_is_tooltip_extension_enabled()
				)
			) {
				$divi_supreme_modules_deps[] = 'dsm-tippy';
			}

			$dsm_modules_bundle_ver = $dsm_version_vb;
			$dsm_modules_js_path    = DSM_DIR_PATH . 'divi-5/public/modules.js';
			if ( is_readable( $dsm_modules_js_path ) ) {
				$dsm_modules_bundle_ver .= '-' . (string) filemtime( $dsm_modules_js_path );
			}

			wp_enqueue_script(
				'dsm-supreme-modules',
				DSM_DIR_URL . 'public/modules.js',
				$divi_supreme_modules_deps,
				$dsm_modules_bundle_ver,
				true
			);

			wp_localize_script(
				'dsm-supreme-modules',
				'dsmMenu',
				array(
					'renderNonce' => wp_create_nonce( 'render_dsm_menu' ),
					'ajaxurl'     => admin_url( 'admin-ajax.php' ),
					'menus'       => class_exists( \DSM_Nav_Menus_REST::class )
						? \DSM_Nav_Menus_REST::get_for_vb()
						: array(),
				)
			);

			require_once DSM_DIR_PATH . 'divi-5/app/Utils/get-image-sizes.php';
			require_once DSM_DIR_PATH . 'divi-5/app/Utils/get-post-type-taxonomies.php';
			require_once DSM_DIR_PATH . 'divi-5/app/Utils/loop-filter-meta-keys.php';
			require_once DSM_DIR_PATH . 'divi-5/app/Utils/get-post-types.php';

			$post_types_for_vb = dsm_get_post_types();

			$dsm_builder_edited_post_id = function_exists( 'dsm_get_vb_builder_edited_post_id' )
				? dsm_get_vb_builder_edited_post_id()
				: 0;

			$popup_settings_vb = array();
			$popup_manager     = null;
			if ( dsm_is_supreme_popup_extension_enabled() && class_exists( \DiviSupreme\Extensions\Popup::class ) ) {
				$popup_manager     = new \DiviSupreme\Extensions\Popup();
				$popup_settings_vb = $popup_manager->get_popup_settings( get_the_ID() );
				if ( empty( $global_popups_vb ) ) {
					$global_popups_vb = $popup_manager->get_global_popups();
				}
			}

			$dsm_modules_settings = get_option( 'dsm_modules', array() );
			if ( ! is_array( $dsm_modules_settings ) ) {
				$dsm_modules_settings = array();
			}

			// Resolved on/off (saved Modules toggle, else legacy Extensions, else on) for VB gating.
			$dsm_modules_settings['LoopFilter'] = (
			function_exists( 'dsm_is_loop_filter_module_enabled' )
			&& dsm_is_loop_filter_module_enabled()
			) ? 'on' : 'off';

			// Extension OFF wins: do not offer Supreme Contact Field in the VB inserter.
			if ( ! $dsm_contact_form_entries_extension_enabled ) {
				$dsm_modules_settings['ContactFormField'] = 'off';
			}

			$table_library_vb = class_exists( \DiviSupreme\Includes\DsmTableLibrary::class )
				? \DiviSupreme\Includes\DsmTableLibrary::get_vb_payload()
				: array(
					'enabled' => false,
				);

			$dsm_vb_date_format = class_exists( TestimonialsAttrs::class )
				? TestimonialsAttrs::review_date_display_format()
				: (string) get_option( 'date_format' );
			if ( '' === $dsm_vb_date_format ) {
				$dsm_vb_date_format = 'F j, Y';
			}

			$global_data = array(
				'tableLibrary'                          => $table_library_vb,
				'imageSizes'                            => dsm_get_all_image_sizes(),
				'lottieWasmUrl'                         => DSM_DIR_URL . 'assets/js/dotlottie-player.wasm',
				'activeModules'                         => $dsm_modules_settings,
				'postTypes'                             => is_array( $post_types_for_vb ) ? $post_types_for_vb : array(),
				'taxonomyRestBases'                     => function_exists( 'dsm_get_taxonomy_rest_base_map' ) ? dsm_get_taxonomy_rest_base_map() : array(),
				'postTypeRestBases'                     => function_exists( 'dsm_get_post_type_rest_base_map' ) ? dsm_get_post_type_rest_base_map() : array(),
				// Post being edited in wp-admin (Visual Builder canvas iframe often lacks core/editor + URL ?post=).
				'builderEditedPostId'                   => $dsm_builder_edited_post_id,
				'nonces'                                => array(
					'library'       => \ET\Builder\Framework\Controllers\RESTController::create_nonce( 'divi/v1', '/divi-library', 'POST' ),
					'item'          => \ET\Builder\Framework\Controllers\RESTController::create_nonce( 'divi/v1', '/divi-library/item', 'POST' ),
					'module_render' => \ET\Builder\Framework\Controllers\RESTController::create_nonce( 'divi/v1', '/module-render', 'POST' ),
					'wp_rest'       => wp_create_nonce( 'wp_rest' ),
				),
				// All `et_pb_layout` posts for library selects (D4 `dsm_load_library` parity).
				'libraryLayouts'                        => DsmLibraryLayoutSelectOptions::get_options(),
				'navMenus'                              => class_exists( \DSM_Nav_Menus_REST::class )
					? \DSM_Nav_Menus_REST::get_for_vb()
					: array(),
				'popupSettings'                         => $popup_settings_vb,
				'currentPostType'                       => $current_post_type,
				// Library (`et_pb_layout`) and regular pages: modules need this for Popup layout select + FieldSettings reduce().
				'globalPopups'                          => $global_popups_vb,
				'dsmSupremePopupExtensionEnabled'       => $dsm_supreme_popup_extension_enabled,
				'dsmSupremeLineHoverAnimationExtensionEnabled' => $dsm_line_hover_animation_extension_enabled,
				'dsmSupremeParallaxExtensionEnabled'    => $dsm_supreme_parallax_extension_enabled,
				'dsmImageParallaxExtensionEnabled'      => $dsm_image_parallax_extension_enabled,
				'dsmCustomCursorExtensionEnabled'       => $dsm_custom_cursor_extension_enabled,
				'dsmPreloaderExtensionEnabled'          => $dsm_preloader_extension_enabled,
				'dsmDarkModeExtensionEnabled'           => $dsm_dark_mode_extension_enabled,
				'dsmIconLibrariesExtensionEnabled'      => $dsm_icon_libraries_extension_enabled,
				'dsmCopyToClipboardExtensionEnabled'    => $dsm_click_to_copy_extension_enabled,
				// Legacy localize key (pre-rename).
				'dsmClickToCopyExtensionEnabled'        => $dsm_click_to_copy_extension_enabled,
				'dsmLoopFilterExtensionEnabled'         => $dsm_loop_filter_extension_enabled,
				'woocommerceActive'                     => class_exists( 'WooCommerce' ),
				'loopFilterTaxonomies'                  => ( $dsm_loop_filter_extension_enabled && function_exists( 'dsm_get_public_taxonomies_for_loop_filter' ) )
					? dsm_get_public_taxonomies_for_loop_filter()
					: array(),
				'loopFilterPostTypeLabels'              => ( $dsm_loop_filter_extension_enabled && function_exists( 'dsm_get_loop_filter_post_type_labels' ) )
					? dsm_get_loop_filter_post_type_labels()
					: array(),
				'loopFilterMetaKeys'                    => ( $dsm_loop_filter_extension_enabled && function_exists( 'dsm_get_loop_filter_meta_key_options' ) )
					? dsm_get_loop_filter_meta_key_options()
					: array(
						'standard'    => array(),
						'nonStandard' => array(),
					),
				'dsmTooltipExtensionEnabled'            => $dsm_tooltip_extension_enabled,
				'dsmPageTourExtensionEnabled'           => $dsm_page_tour_extension_enabled,
				'dsmPasswordProtectionBlockEnabled'     => $dsm_password_protection_block_enabled,
				'dsmContactFormEntriesExtensionEnabled' => $dsm_contact_form_entries_extension_enabled,
				'dsmClientHandoffLockContentGroups'     => $dsm_client_handoff_lock_content_groups,
				'contactFormTurnstile'                  => (
					$dsm_contact_form_entries_extension_enabled
					&& class_exists( \DiviSupreme\Extensions\ContactFormEntries\Turnstile::class )
				)
					? \DiviSupreme\Extensions\ContactFormEntries\Turnstile::get_vb_config()
					: array(),
				'contactFormHcaptcha'                   => (
					$dsm_contact_form_entries_extension_enabled
					&& class_exists( \DiviSupreme\Extensions\ContactFormEntries\Hcaptcha::class )
				)
					? \DiviSupreme\Extensions\ContactFormEntries\Hcaptcha::get_vb_config()
					: array(),
				'contactFormFileUpload'                 => (
					$dsm_contact_form_entries_extension_enabled
					&& class_exists( \DiviSupreme\Extensions\ContactFormEntries\FileUpload::class )
				)
					? \DiviSupreme\Extensions\ContactFormEntries\FileUpload::get_vb_config()
					: array(),
				'contactFormSubmitLoader'               => (
					$dsm_contact_form_entries_extension_enabled
					&& class_exists( \DiviSupreme\Extensions\ContactFormEntries\SubmitLoader::class )
				)
					? \DiviSupreme\Extensions\ContactFormEntries\SubmitLoader::get_vb_config()
					: array(),
				'passwordProtectionRoles'               => class_exists( PasswordProtection::class )
					? PasswordProtection::get_bypass_role_options_for_js()
					: array(),
				'iconLibrariesCatalog'                  => $icon_libraries_catalog_vb,
				'customCursorSettings'                  => $custom_cursor_settings_vb,
				'preloaderSettings'                     => $preloader_settings_vb,
				'darkModeSettings'                      => $dark_mode_settings_vb,
				'siteName'                              => wp_strip_all_tags( (string) get_bloginfo( 'name' ) ),
				// Settings → General date format so VB cards match PHP `wp_date()`.
				'dateFormat'                            => $dsm_vb_date_format,
				'cursorScopeQuickPicks'                 => function_exists( 'dsm_get_custom_cursor_scope_quick_picks' ) && $dsm_custom_cursor_extension_enabled
					? dsm_get_custom_cursor_scope_quick_picks( $dsm_builder_edited_post_id )
					: array(),
				'darkModeScopeQuickPicks'               => function_exists( 'dsm_get_custom_cursor_scope_quick_picks' ) && $dsm_dark_mode_extension_enabled
					? dsm_get_custom_cursor_scope_quick_picks( $dsm_builder_edited_post_id )
					: array(),
				'preloaderScopeQuickPicks'              => function_exists( 'dsm_get_custom_cursor_scope_quick_picks' ) && $dsm_preloader_extension_enabled
					? dsm_get_custom_cursor_scope_quick_picks( $dsm_builder_edited_post_id )
					: array(),
				'breadcrumbsThemeBuilderPreview'        => function_exists( 'dsm_breadcrumbs_get_theme_builder_preview_js_payload' )
					? dsm_breadcrumbs_get_theme_builder_preview_js_payload()
					: array(
						'active' => false,
						'crumbs' => array(),
					),
			);

			wp_localize_script(
				'dsm-supreme-modules',
				'diviSupreme5',
				$global_data
			);

			$social_media_settings_fb = get_option( 'dsm_settings_social_media' );
			$facebook_app_id_vb       = isset( $social_media_settings_fb['dsm_facebook_app_id'] ) ? $social_media_settings_fb['dsm_facebook_app_id'] : '';
			wp_localize_script(
				'dsm-supreme-modules',
				'facebookAppId',
				array( 'appId' => $facebook_app_id_vb )
			);

			if ( $popup_manager instanceof \DiviSupreme\Extensions\Popup ) {
				wp_add_inline_script(
					'dsm-supreme-modules',
					'window.addEventListener("DOMContentLoaded", function() {
					try {
						if (typeof divi === "undefined" || !divi.data) { return; }
						var store = divi.data.dispatch("divi/page-settings");
						if (store && typeof store.update === "function") {
							store.update("dsm_popup_settings", ' . wp_json_encode( $popup_manager->get_popup_settings( get_the_ID() ) ) . ');
						}
					} catch (e) {}
				});',
					'after'
				);
			}

			if ( $dsm_page_tour_extension_enabled && isset( $GLOBALS['dsm_page_tour_extension'] )
				&& $GLOBALS['dsm_page_tour_extension'] instanceof \DiviSupreme\Extensions\PageTour ) {
				$page_tour_settings_vb = $GLOBALS['dsm_page_tour_extension']->get_page_settings(
					$dsm_builder_edited_post_id > 0 ? $dsm_builder_edited_post_id : (int) get_the_ID()
				);
				wp_add_inline_script(
					'dsm-supreme-modules',
					'window.addEventListener("DOMContentLoaded", function() {
					try {
						if (typeof divi === "undefined" || !divi.data) { return; }
						var store = divi.data.dispatch("divi/page-settings");
						if (store && typeof store.update === "function") {
							store.update("dsm_page_tour_settings", ' . wp_json_encode( $page_tour_settings_vb ) . ');
						}
					} catch (e) {}
				});',
					'after'
				);
			}

			if ( $dsm_custom_cursor_extension_enabled && isset( $GLOBALS['dsm_custom_cursor_extension'] )
				&& $GLOBALS['dsm_custom_cursor_extension'] instanceof \DiviSupreme\Extensions\CustomCursor ) {
				$cursor_page_enabled = $GLOBALS['dsm_custom_cursor_extension']->get_page_enabled( $dsm_builder_edited_post_id );
				wp_add_inline_script(
					'dsm-supreme-modules',
					'window.addEventListener("DOMContentLoaded", function() {
					try {
						if (typeof divi === "undefined" || !divi.data) { return; }
						var store = divi.data.dispatch("divi/page-settings");
						if (store && typeof store.update === "function") {
							store.update("dsm_custom_cursor_page_enabled", ' . wp_json_encode( $cursor_page_enabled ) . ');
						}
					} catch (e) {}
				});',
					'after'
				);
			}

			if ( $dsm_preloader_extension_enabled && isset( $GLOBALS['dsm_preloader_extension'] )
				&& $GLOBALS['dsm_preloader_extension'] instanceof \DiviSupreme\Extensions\Preloader ) {
				$preloader_page_enabled = $GLOBALS['dsm_preloader_extension']->get_page_enabled( $dsm_builder_edited_post_id );
				wp_add_inline_script(
					'dsm-supreme-modules',
					'window.addEventListener("DOMContentLoaded", function() {
					try {
						if (typeof divi === "undefined" || !divi.data) { return; }
						var store = divi.data.dispatch("divi/page-settings");
						if (store && typeof store.update === "function") {
							store.update("dsm_preloader_page_enabled", ' . wp_json_encode( $preloader_page_enabled ) . ');
						}
					} catch (e) {}
				});',
					'after'
				);
			}

			if ( $dsm_dark_mode_extension_enabled && isset( $GLOBALS['dsm_dark_mode_extension'] )
				&& $GLOBALS['dsm_dark_mode_extension'] instanceof \DiviSupreme\Extensions\DarkMode ) {
				$dark_mode_page_enabled = $GLOBALS['dsm_dark_mode_extension']->get_page_enabled( $dsm_builder_edited_post_id );
				wp_add_inline_script(
					'dsm-supreme-modules',
					'window.addEventListener("DOMContentLoaded", function() {
					try {
						if (typeof divi === "undefined" || !divi.data) { return; }
						var store = divi.data.dispatch("divi/page-settings");
						if (store && typeof store.update === "function") {
							store.update("dsm_dark_mode_page_enabled", ' . wp_json_encode( $dark_mode_page_enabled ) . ');
						}
					} catch (e) {}
				});',
					'after'
				);
			}

			wp_enqueue_style(
				'dsm-module-list-style',
				DSM_DIR_URL . '/assets/css/module-list.css',
				array(),
				$dsm_version_vb
			);

			wp_enqueue_style(
				DsmFrontendModuleAssetRegistry::CORE_MODULES_STYLE_HANDLE,
				DSM_DIR_URL . 'public/modules-vb-styles.css',
				array(),
				$dsm_version_vb
			);

			if ( DsmDiviBuilderCssScope::needs_builder_css_prefix() ) {
				$vb_cpt_base = DSM_DIR_PATH . 'divi-5/public/modules-vb-styles.css';
				$vb_cpt_path = DsmDiviBuilderCssScope::cpt_variant_path( $vb_cpt_base );

				if ( null !== $vb_cpt_path && is_readable( $vb_cpt_path ) ) {
					wp_enqueue_style(
						DsmFrontendModuleAssetRegistry::CORE_MODULES_VB_CPT_STYLE_HANDLE,
						DsmDiviBuilderCssScope::resolve_stylesheet_url( DSM_DIR_URL . 'public/modules-vb-styles.css' ),
						array( DsmFrontendModuleAssetRegistry::CORE_MODULES_STYLE_HANDLE ),
						DsmDiviBuilderCssScope::resolve_stylesheet_version( $vb_cpt_base )
					);
				}
			}

			$this->register_supreme_animate_css();
			wp_enqueue_style( 'dsm-supreme-animate' );
		}
	}
}
