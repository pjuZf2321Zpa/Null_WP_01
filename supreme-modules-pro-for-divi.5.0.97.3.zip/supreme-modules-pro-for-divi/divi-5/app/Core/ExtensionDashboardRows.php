<?php
/**
 * Extension toggle rows for the Divi Supreme settings dashboard (General tab).
 *
 * @package DiviSupreme
 */

declare(strict_types=1);

namespace DiviSupreme\Core;

/**
 * Card-grid field definitions for `dsm_general` extension toggles.
 */
final class ExtensionDashboardRows {

	/**
	 * Card label.
	 *
	 * @param string $icon_relative Path under assets/static (e.g. dashboard/extensions/popup.svg).
	 * @param string $title         Card title (plain text).
	 * @return string
	 */
	private static function card_label( string $icon_relative, string $title ): string {
		return '<div class="dsm-settings-modules-icon"><img src="' . esc_url( Assets::getAssetPath( $icon_relative ) ) . '" alt=""></div><h4>' . esc_html( $title ) . '</h4>';
	}

	/**
	 * Extension checkbox rows for the General / Extensions settings tab.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public static function build_dsm_general_settings_fields(): array {
		$rows = array(
			array(
				'name'    => 'dsm_use_page_tour',
				'class'   => 'dsm-settings-checkbox dsm-settings-column',
				'label'   => self::card_label(
					'dashboard/extensions/page-tour.svg',
					__( 'Page Tour', 'dsm-supreme-modules-pro-for-divi' )
				),
				'desc'    => __(
					'Adds a Page Tour group to the Advanced tab on sections, rows, columns, and modules. Turn on This is a tour step and set the step number on each module you want to include. Use the Page Tour customiser in the Visual Builder bar to style the overlay, popover, and navigation.',
					'dsm-supreme-modules-pro-for-divi'
				),
				'type'    => 'checkbox',
				'default' => 'off',
			),
			array(
				'name'    => 'dsm_use_tooltip',
				'class'   => 'dsm-settings-checkbox dsm-settings-column',
				'label'   => self::card_label(
					'dashboard/extensions/tooltip.svg',
					__( 'Tooltip', 'dsm-supreme-modules-pro-for-divi' )
				),
				'desc'    => __(
					'Adds a Tooltip group to the Advanced tab on sections, rows, columns, and modules. After enabling this, turn on Enable Tooltip on each module you want to use.',
					'dsm-supreme-modules-pro-for-divi'
				),
				'type'    => 'checkbox',
				'default' => 'off',
			),
			array(
				'name'    => 'dsm_use_supreme_popup',
				'class'   => 'dsm-settings-checkbox dsm-settings-column',
				'label'   => self::card_label(
					'dashboard/extensions/popup.svg',
					__( 'Divi Popup', 'dsm-supreme-modules-pro-for-divi' )
				),
				'desc'    => __(
					'Adds a Popup group under each module\'s Advanced tab. In the Divi Library, open a layout and use the Popup Customiser to enable the popup, choose a trigger (module click/hover, viewport, CSS class/ID, and more), and style the overlay. Then on any module turn on Use Popup and select that library layout. No extra class or ID is needed when you use the Module trigger.',
					'dsm-supreme-modules-pro-for-divi'
				),
				'type'    => 'checkbox',
				'default' => 'on',
			),
			array(
				'name'    => 'dsm_use_line_hover_animation',
				'class'   => 'dsm-settings-checkbox dsm-settings-column',
				'label'   => self::card_label(
					'dashboard/extensions/line-hover.svg',
					__( 'Line Hover Animation', 'dsm-supreme-modules-pro-for-divi' )
				),
				'desc'    => __(
					'Adds a Line Hover Animation group under each module\'s Design tab (same presets as the Line Hover module).',
					'dsm-supreme-modules-pro-for-divi'
				),
				'type'    => 'checkbox',
				'default' => 'on',
			),
			array(
				'name'    => 'dsm_use_supreme_parallax',
				'class'   => 'dsm-settings-checkbox dsm-settings-column',
				'label'   => self::card_label(
					'dashboard/extensions/mouse-parallax.svg',
					__( 'Mouse Parallax', 'dsm-supreme-modules-pro-for-divi' )
				),
				'desc'    => __(
					'Adds a Mouse Parallax group under each module\'s Advanced tab. Turn it on per element (rows, columns, group, and modules). Layers move with the cursor and stay scoped to the parent section. Adjust strength, depth, motion reference (section or viewport), and smoothing on the section motion root.',
					'dsm-supreme-modules-pro-for-divi'
				),
				'type'    => 'checkbox',
				'default' => 'on',
			),
			array(
				'name'    => 'dsm_use_image_parallax',
				'class'   => 'dsm-settings-checkbox dsm-settings-column',
				'label'   => self::card_label(
					'dashboard/extensions/image-parallax.svg',
					__( 'Image Parallax', 'dsm-supreme-modules-pro-for-divi' )
				),
				'desc'    => __(
					'Image Parallax adds smooth, scroll-driven motion to the images you upload in Divi and Divi Supreme modules. Your photos gain real depth as visitors scroll — with orientation, scale, and timing you set right inside each module. Works with any image field. Real img tags keep alt text in your page HTML, which helps accessibility and SEO. Background images sit in CSS and search engines usually do not treat them as page content.',
					'dsm-supreme-modules-pro-for-divi'
				),
				'type'    => 'checkbox',
				'default' => 'off',
			),
			array(
				'name'    => 'dsm_use_custom_cursor',
				'class'   => 'dsm-settings-checkbox dsm-settings-column',
				'label'   => self::card_label(
					'dashboard/extensions/custom-cursor.svg',
					__( 'Custom Cursor', 'dsm-supreme-modules-pro-for-divi' )
				),
				'desc'    => __(
					'Adds a Custom Cursor customiser in the Visual Builder (builder bar) with live preview, scope rules, and site-wide cursor styles on the frontend.',
					'dsm-supreme-modules-pro-for-divi'
				),
				'type'    => 'checkbox',
				'default' => 'off',
			),
			array(
				'name'    => 'dsm_use_preloader',
				'class'   => 'dsm-settings-checkbox dsm-settings-column',
				'label'   => self::card_label(
					'dashboard/extensions/preloader.svg',
					__( 'Preloader', 'dsm-supreme-modules-pro-for-divi' )
				),
				'desc'    => __(
					'Shows a branded overlay while the page loads. Design presets, logo, and page transitions in the Visual Builder (builder bar → Preloader). Failsafe and checkout excludes live under the Preloader settings tab.',
					'dsm-supreme-modules-pro-for-divi'
				),
				'type'    => 'checkbox',
				'default' => 'off',
			),
			array(
				'name'    => 'dsm_use_dark_mode',
				'class'   => 'dsm-settings-checkbox dsm-settings-column',
				'label'   => self::card_label(
					'dashboard/extensions/dark-mode.svg',
					__( 'Dark Mode Toggle', 'dsm-supreme-modules-pro-for-divi' )
				),
				'desc'    => __(
					'Lets visitors switch between light and dark color schemes. Adds a floating toggle on the frontend and a Dark Mode customiser in the Visual Builder (builder bar) for palette, default mode, and switch style.',
					'dsm-supreme-modules-pro-for-divi'
				),
				'type'    => 'checkbox',
				'default' => 'off',
			),
			array(
				'name'    => 'dsm_use_icon_libraries',
				'class'   => 'dsm-settings-checkbox dsm-settings-column',
				'label'   => self::card_label(
					'dashboard/extensions/icon-libraries.svg',
					__( 'Icon Libraries', 'dsm-supreme-modules-pro-for-divi' )
				),
				'desc'    => __(
					'Adds pluggable webfont icon libraries (Tabler, Phosphor, and future sets) to every Divi composite icon picker. Enable individual libraries under the Icon Libraries settings tab.',
					'dsm-supreme-modules-pro-for-divi'
				),
				'type'    => 'checkbox',
				'default' => 'off',
			),
			array(
				'name'    => 'dsm_use_mask_pattern_library',
				'class'   => 'dsm-settings-checkbox dsm-settings-column',
				'label'   => self::card_label(
					'dashboard/extensions/mask-pattern.svg',
					__( 'Mask & Pattern Library', 'dsm-supreme-modules-pro-for-divi' )
				),
				'desc'    => __(
					'Adds custom background masks and patterns to Divi 5 section, row, column, and module background pickers. Choose which items appear under the Mask & Pattern Library settings tab.',
					'dsm-supreme-modules-pro-for-divi'
				),
				'type'    => 'checkbox',
				'default' => 'off',
			),
			array(
				'name'    => 'dsm_use_library_widget',
				'class'   => 'dsm-settings-checkbox dsm-settings-column',
				'label'   => self::card_label(
					'dashboard/extensions/library-widget.svg',
					__( 'Divi Library Widget', 'dsm-supreme-modules-pro-for-divi' )
				),
				'desc'    => __(
					'Adds a Divi Library widget so you can embed saved layouts in sidebars and widget areas.',
					'dsm-supreme-modules-pro-for-divi'
				),
				'type'    => 'checkbox',
				'default' => 'off',
			),
			array(
				'name'    => 'dsm_use_click_to_copy',
				'class'   => 'dsm-settings-checkbox dsm-settings-column',
				'label'   => self::card_label(
					'dashboard/extensions/copy-to-clipboard.svg',
					__( 'Copy to Clipboard', 'dsm-supreme-modules-pro-for-divi' )
				),
				'desc'    => __(
					'Lets visitors click a module to copy text you configure (Dynamic Content supported). In Visual Builder, use the purple icon on text field labels or Advanced → Copy to Clipboard.',
					'dsm-supreme-modules-pro-for-divi'
				),
				'type'    => 'checkbox',
				'default' => 'off',
			),
			array(
				'name'    => 'dsm_use_client_handoff',
				'class'   => 'dsm-settings-checkbox dsm-settings-column',
				'label'   => self::card_label(
					'dashboard/extensions/client-handoff.svg',
					__( 'Client Handoff', 'dsm-supreme-modules-pro-for-divi' )
				),
				'desc'    => __(
					'Lets you apply a content-only Divi Role Editor profile for Editor: clients edit copy and images in the Visual Builder, without Design, Advanced, or layout changes. Apply and Exit live under the Client Handoff tab. Turning this off restores the Role Editor snapshot if Handoff is applied.',
					'dsm-supreme-modules-pro-for-divi'
				),
				'type'    => 'checkbox',
				'default' => 'off',
			),
			array(
				'name'    => 'dsm_use_password_protection',
				'class'   => 'dsm-settings-checkbox dsm-settings-column',
				'label'   => self::card_label(
					'dashboard/extensions/password-protection.svg',
					__( 'Password Protection', 'dsm-supreme-modules-pro-for-divi' )
				),
				'desc'    => __(
					'Adds Password Protection under Section, Row, and Column Advanced / Design tabs, and unlocks the Password Protection settings tab for sitewide and per-page gates. Lock a block’s content behind a password form on the frontend.',
					'dsm-supreme-modules-pro-for-divi'
				),
				'type'    => 'checkbox',
				'default' => 'off',
			),
			array(
				'name'    => 'dsm_use_contact_form_entries',
				'class'   => 'dsm-settings-checkbox dsm-settings-column',
				'label'   => self::card_label(
					'dashboard/extensions/contact-form-entries.svg',
					__( 'Contact Form Pro', 'dsm-supreme-modules-pro-for-divi' )
				),
				'desc'    => __(
					'Contact Form Pro saves successful submissions from the Divi Contact Form module into the WordPress admin. View, search, and export under Divi Supreme → Form Entries. Does not replace Contact Form 7.',
					'dsm-supreme-modules-pro-for-divi'
				),
				'type'    => 'checkbox',
				'default' => 'off',
			),
		);

		return array_map(
			static function ( array $row ): array {
				if ( isset( $row['name'] ) && is_string( $row['name'] ) && '' !== $row['name'] ) {
					$row['documentation'] = DocumentationUrls::extension_doc_url( $row['name'] );
				}

				return $row;
			},
			$rows
		);
	}
}
