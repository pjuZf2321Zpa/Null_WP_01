/**
 *  AJAX Conditional logic for fields scripts
 */
jQuery(document).ready(function($){
	var wppbConditionalAjaxTriggered = false;
	var wppbTypingTimer;                //timer identifier
	var wppbDoneTypingInterval =  500;  //time in ms

	wppb_conditional_logic();
	$(".wppb-user-forms").on( "change keyup", '.wppb-form-field select, .wppb-form-field input, .wppb-form-field input[type="checkbox"], .wppb-form-field textarea',  function(e){
		if( e.type === 'keyup' ){
			clearTimeout(wppbTypingTimer);
			wppbTypingTimer = setTimeout(wppb_conditional_logic, wppbDoneTypingInterval);
		}
		else {
			wppb_conditional_logic();
		}
		wppbConditionalAjaxTriggered = true;
	});

	//this is added for cascading conditionals ( if a field is triggered by another conditional field at page load )
	$("body").on('DOMSubtreeModified', ".wppb-user-forms ul", function() {
		if( !wppbConditionalAjaxTriggered ) {
			wppb_conditional_logic();
			wppbConditionalAjaxTriggered = true;
		}
	});

	function wppb_conditional_logic(){
		data = {};

		formType = '';
		formName = '';
		formID   = '';

		$('.wppb-form-field').each(function(){
			if(($(this).find('input').length || $(this).find('select').length || $(this).find('textarea').length) && typeof $(this).attr('id') != "undefined"){

				id = $(this).attr('id').replace('wppb-form-element-', '');


				value = $( 'input[type="text"], input[type="email"], input[type="number"], input[type="hidden"], textarea, select option:selected, input[type="checkbox"]:checked, input[type="radio"]:checked, input[type="url"]', $(this) ).map(function(){return jQuery(this).val(); }).get();
				data[id] = value;
			}

			formType = $(this).closest('form').find('#action').val();
			formName = $(this).closest('form').find('#form_name').val();
			formID = $(this).closest('form').find('#form_id').val();
		});

		var data = {
			'action'    : 'wppb_conditional_logic',
			'data'  	: JSON.stringify(data),
			'formType'  : formType,
			'formName'  : formName,
			'formID'  	: formID,

		};

		$.post( wppb_conditional_ajax.ajaxUrl, data, function(ret){
			res = JSON.parse(ret);
			var $injectedFields = $();
			for(i in res){
				if(res[i].type == 'show'){
					if($('#wppb-form-element-'+i).html() == ''){
						$('#wppb-form-element-'+i).html(res[i].html);
						$injectedFields = $injectedFields.add( $('#wppb-form-element-'+i) );
					}
					$('#wppb-form-element-'+i).show();
					if(res[i].html.includes('input type=\"file\"')) {
						if (typeof validate_simple_upload !== 'undefined') {
							validate_simple_upload();
						}
					}
				}
				if(res[i].type == 'hide'){
					$('#wppb-form-element-'+i).html('');
					$('#wppb-form-element-'+i).hide();
				}
			}

			/* the markup of the shown fields was just added to the page so the field scripts, which ran on document ready, never saw it */
			if( $injectedFields.length > 0 ){
				wppb_conditional_initialize_fields( $injectedFields );
			}

			if( $( '.wppb-repeater' ).length > 0 && typeof WPPB_RepeatersApp == 'function' ){
				WPPB_RepeatersApp()
			}

		});

	}

	/**
	 * Initialize the fields that rely on JS after their markup was injected by the AJAX conditional logic.
	 *
	 * Only the content of the form field container is replaced, so the initialization
	 * functions bound on document ready have to be called again for the new markup.
	 *
	 * @param $containers jQuery collection of form field containers that received new markup
	 */
	function wppb_conditional_initialize_fields( $containers ){

		// Datepicker Field
		if( $containers.find('.custom_field_datepicker').length > 0 && typeof wppb_initialize_datepicker === 'function' )
			wppb_initialize_datepicker();

		// Colorpicker Field
		if( $containers.find('.custom_field_colorpicker').length > 0 && typeof wppb_initialize_colorpicker === 'function' )
			wppb_initialize_colorpicker();

		// Phone Field
		if( $containers.find('.extra_field_phone, .custom_field_phone').length > 0 && typeof wppb_initialize_phone_field === 'function' )
			wppb_initialize_phone_field();

		// International Telephone Input Field
		if( $containers.find('.wppb-intl-tel-input').length > 0 && typeof window.wppbIntlTelInitAll === 'function' )
			$containers.each( function(){ window.wppbIntlTelInitAll( this ); });

		// Map Field
		if( $containers.find('.wppb-map-container').length > 0 && typeof wppb_initialize_map === 'function' )
			wppb_initialize_map();

		// WYSIWYG Field
		if( $containers.find('.wp-editor-area').length > 0 && typeof wppb_initialize_wysiwyg === 'function' )
			wppb_initialize_wysiwyg();

		// Select2 & Select2 (Multiple) Fields
		if( $containers.find('.custom_field_select2').length > 0 && typeof wppb_select2_initialize === 'function' )
			wppb_select2_initialize();

		// Select (CPT) Field
		$containers.find('.custom_field_cpt_select').each( function(){
			$(this).select2();
		});

	}
});