jQuery(function(){ wppbFacetSelectMultipleInit() });
function wppbFacetSelectMultipleInit(){
    jQuery(".wppb-facet-select-multiple ").each( function(){
        var currentFacetSelectMultiple = jQuery( this );

        if ( currentFacetSelectMultiple.hasClass( 'select2-hidden-accessible' ) ) {
            return;
        }

        var labelledBy = currentFacetSelectMultiple.attr( 'aria-labelledby' );

        currentFacetSelectMultiple.select2({
            placeholder: wppb_facet_select_multiple_obj.placeholder,
        }).on("select2:open", function(){
            if( jQuery(".wppb-user-to-edit").parents( ".overlay-container" ).length ){
                jQuery(".wppb-user-to-edit").data("select2").dropdown.$dropdownContainer.css( "z-index", "99999999" );
            }
        });

        if ( labelledBy ) {
            currentFacetSelectMultiple.next( '.select2-container' ).find( '.select2-selection' ).attr( 'aria-labelledby', labelledBy );
        }
    });
}
