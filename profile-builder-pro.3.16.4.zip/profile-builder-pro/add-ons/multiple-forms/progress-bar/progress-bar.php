<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class WPPB_Progress_Bar {

	public function __construct() {
		add_action( 'init', array( $this, 'register_settings' ) );
        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
        add_filter( 'wppb_before_form_fields', array( $this, 'add_progress_bar_before_form' ), 11, 3 );
        add_filter( 'wppb_form_bottom', array( $this, 'add_progress_bar_after_form' ), 10, 3 );
        add_action( 'wp_footer', array( $this, 'add_inline_styles' ) );
	}

	/**
	 * Register WCK Metaboxes for Progress Bar settings on Multiple Forms
	 */
	public function register_settings() {
		if ( ! class_exists( 'Wordpress_Creation_Kit_PB' ) ) {
			return;
		}

		$progress_bar_fields = array(
			array( 'type' => 'select', 'slug' => 'enable-progress-bar', 'title' => __( 'Enable Progress Bar', 'profile-builder' ), 'options' => array( 'No', 'Yes' ), 'default' => 'No', 'description' => __( 'Show a completion progress bar on the form', 'profile-builder' ) ),
			array( 'type' => 'select', 'slug' => 'calculation-mode', 'title' => __( 'Calculation Mode', 'profile-builder' ), 'options' => array( 'All Fields', 'Required Fields' ), 'default' => 'All Fields', 'description' => __( 'Choose how the progress is calculated', 'profile-builder' ) ),
			array( 'type' => 'select', 'slug' => 'display-options', 'title' => __( 'Style/Display Options', 'profile-builder' ), 'options' => array( 'Bar Only', 'Bar and Percentage Label' ), 'default' => 'Bar Only', 'description' => __( 'Choose what to display', 'profile-builder' ) ),
			array( 'type' => 'select', 'slug' => 'position', 'title' => __( 'Position', 'profile-builder' ), 'options' => array( 'Top of Form', 'Bottom of Form', 'Both' ), 'default' => 'Top of Form', 'description' => __( 'Where to display the progress bar', 'profile-builder' ) ),
		);

		// Multiple Edit Profile Forms
		$args_epf = array(
			'metabox_id' => 'wppb-epf-progress-bar-settings',
			'metabox_title' => __( 'Progress Bar Settings', 'profile-builder' ),
            'post_type' => 'wppb-epf-cpt',
			'meta_name' => 'wppb_epf_progress_bar_settings',
			'meta_array' => $progress_bar_fields,
			'sortable' => false,
			'single' => true
		);
		new Wordpress_Creation_Kit_PB( $args_epf );

		// Multiple Registration Forms
		$args_rf = array(
			'metabox_id' => 'wppb-rf-progress-bar-settings',
			'metabox_title' => __( 'Progress Bar Settings', 'profile-builder' ),
            'post_type' => 'wppb-rf-cpt',
			'meta_name' => 'wppb_rf_progress_bar_settings',
			'meta_array' => $progress_bar_fields,
			'sortable' => false,
			'single' => true
		);
		new Wordpress_Creation_Kit_PB( $args_rf );
	}

    /**
     * Enqueue Script
     */
    public function enqueue_scripts() {
        global $post;
        // Ensure $post is available
        if ( empty( $post ) ) {
            $post = get_post();
        }
        if ( ! $post || ! is_object( $post ) ) {
            return;
        }

        $post_content = isset( $post->post_content ) ? $post->post_content : '';
        $has_elementor = get_post_meta( $post->ID, '_elementor_data', true );

        // Only proceed if there's content or Elementor data to inspect
        if ( empty( $post_content ) && empty( $has_elementor ) ) {
            return;
        }

        $has_shortcode = false;
        if ( ! empty( $post_content ) ) {
            $has_shortcode = has_shortcode( $post_content, 'wppb-register' ) || has_shortcode( $post_content, 'wppb-edit-profile' );
        }

        $has_block = false;
        if ( function_exists( 'has_block' ) && ! empty( $post_content ) ) {
            $has_block = has_block( 'wppb/register', $post_content ) || has_block( 'wppb/edit-profile', $post_content );
        }

        if ( $has_shortcode || $has_block ) {
            wp_enqueue_script( 'wppb-progress-bar-js', WPPB_PAID_PLUGIN_URL . 'add-ons/multiple-forms/progress-bar/assets/js/wppb-progress-bar.js', array( 'jquery' ), PROFILE_BUILDER_VERSION, true );
        }
    }

    /**
     * Add inline styles for the Progress Bar
     */
    public function add_inline_styles() {
        $primary_color = '#4cd964'; // Default green
        $background_color = '#f0f0f0'; // Default gray
        $border_radius = '4px';

        if ( function_exists( 'wppb_get_active_form_design' ) ) {
            $active_design = wppb_get_active_form_design();
            if ( $active_design == 'form-style-1' ) { // Sublime
                $primary_color = '#1079F3';
                $background_color = '#D6F5FF';
                $border_radius = '4px';
            } elseif ( $active_design == 'form-style-2' ) { // Greenery
                $primary_color = '#558B2F';
                $background_color = '#DCEDC8';
                $border_radius = '4px';
            } elseif ( $active_design == 'form-style-3' ) { // Slim
                $primary_color = '#554FE6';
                $background_color = '#F0F2F5';
                $border_radius = '5px';
            }
        }
        ?>
        <style type="text/css">
            .wppb-progress-bar-container {
                width: 100%;
                box-sizing: border-box;
                background-color: var(--wppb-progress-bar-background-color, <?php echo esc_attr( $background_color ); ?>);
                border-radius: <?php echo esc_attr( $border_radius ); ?>;
                margin-top: 20px;
                margin-bottom: 20px;
                overflow: hidden;
                position: relative;
                height: 20px;
            }
            /* Style 3 specific overrides */
            .wppb-form-style-3 .wppb-progress-bar-container {
                 height: 10px;
            }

            .wppb-progress-bar-fill {
                height: 100%;
                background-color: var(--wppb-progress-bar-fill-color, <?php echo esc_attr( $primary_color ); ?>);
                width: 0%;
                transition: width 0.3s ease-in-out;
                border-radius: <?php echo esc_attr( $border_radius ); ?>;
            }
            .wppb-progress-bar-text {
                position: absolute;
                width: 100%;
                text-align: center;
                top: 50%;
                left: 0;
                transform: translateY(-50%);
                font-size: 12px;
                color: var(--wppb-progress-bar-text-color, #333333);
                font-weight: bold;
                mix-blend-mode: multiply;
            }
            .wppb-progress-bar-container.bottom {
                margin-top: 20px;
                margin-bottom: 20px;
            }
        </style>
        <?php
    }

	/**
	 * Inject HTML before the form fields (Top)
	 */
	public function add_progress_bar_before_form( $output, $form_type, $form_id ) {
        $html = $this->get_progress_bar_html( $form_type, $form_id, 'top' );
        return $html . $output;
    }

    /**
     * Inject HTML after the form fields (Bottom)
     */
    public function add_progress_bar_after_form( $output, $form_type, $form_id ) {
        $html = $this->get_progress_bar_html( $form_type, $form_id, 'bottom' );
        return $output . $html;
    }

    /**
     * Generate HTML for Progress Bar based on settings
     */
    public function get_progress_bar_html( $form_type, $form_id, $location ) {
		$meta_name = ( $form_type == 'register' ) ? 'wppb_rf_progress_bar_settings' : 'wppb_epf_progress_bar_settings';
		$settings = get_post_meta( $form_id, $meta_name, true );

		if ( empty( $settings ) || empty( $settings[0] ) || empty( $settings[0]['enable-progress-bar'] ) || $settings[0]['enable-progress-bar'] !== 'Yes' ) {
			return '';
		}

		$settings = $settings[0];
        $position = isset( $settings['position'] ) ? $settings['position'] : 'Top of Form';

        // Check availability based on location
        if ( $location == 'top' && ( $position == 'Bottom of Form' ) ) return '';
        if ( $location == 'bottom' && ( $position == 'Top of Form' ) ) return '';

		$calculation_mode = isset( $settings['calculation-mode'] ) ? strtolower( str_replace( ' ', '', $settings['calculation-mode'] ) ) : 'allfields';
		$display_style = isset( $settings['display-options'] ) ? $settings['display-options'] : 'Bar Only';
        
        // Map calculation mode to what the JS expects
        $js_calc_mode = ( strpos( $calculation_mode, 'required' ) !== false ) ? 'required' : 'all';

		$progress_bar_html = '<div class="wppb-progress-bar-container ' . esc_attr( $location ) . '" data-calculation-mode="' . esc_attr( $js_calc_mode ) . '">';
		$progress_bar_html .= '<div class="wppb-progress-bar-fill"></div>';
		
		if ( $display_style === 'Bar and Percentage Label' ) {
			$progress_bar_html .= '<div class="wppb-progress-bar-text"><span>0%</span></div>';
		}
		
		$progress_bar_html .= '</div>';
        
        return $progress_bar_html;
    }

}

new WPPB_Progress_Bar();
