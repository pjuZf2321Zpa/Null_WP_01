<?php

// send before wp-load so reverse-proxy and host caches see no-cache even if the bootstrap is slow or fails
header( 'Cache-Control: no-cache' );

// Load WordPress environment; resolve wp-load.php relative to this file's own directory, not the PHP working directory (which is unpredictable when reached through a rewrite)
require_once( dirname( __DIR__, 6 ) . '/wp-load.php' );

// get server request data
$wp_root = isset( $_SERVER['DOCUMENT_ROOT'] ) ? sanitize_text_field( $_SERVER['DOCUMENT_ROOT'] ) : '';

// use the raw (unslashed) request URI: sanitize_text_field() strips %xx octets, which corrupts encoded filenames. The realpath confinement below is the security boundary.
$request_uri = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- path is validated below via rawurldecode, null-byte rejection and realpath() confinement to the uploads dir; sanitizing here would strip %xx octets and break encoded filenames

// build the requested file path: strip any query string and decode percent-encoding so it maps to the real file on disk
$request_path = rawurldecode( strtok( $request_uri, '?' ) );

// reject null byte injection before any filesystem call
if ( strpos( $request_path, "\0" ) !== false )
    $request_path = '';

$file_path = $wp_root . $request_path;

// confine the served path to the uploads directory; reject anything that resolves outside it (path traversal)
$uploads_basedir = realpath( wp_get_upload_dir()['basedir'] );
$real_file_path = realpath( $file_path );

if ( $real_file_path === false || $uploads_basedir === false || strpos( $real_file_path, $uploads_basedir . DIRECTORY_SEPARATOR ) !== 0 ) {
    status_header( 404 );
    nocache_headers();
    die( 'File not found.' );
}

$file_path = $real_file_path;

// get the file url; strip the query string so the lookup matches the stored attachment URL, and decode percent-encoding so it matches the filename stored in the database
$file_url = rawurldecode( strtok( wppb_curpageurl(), '?' ) );

// get the attachment data
$attachment_id = attachment_url_to_postid( $file_url );
$file_mime_type = mime_content_type( $file_path );

// if the requested file is a WordPress generated image variant, resolve it to its parent attachment so the restriction is enforced for every size, not just the original.
// a -150x150 thumbnail strips to the base name; for a large upload WordPress stores the attachment as the -scaled file while the sub-sizes and kept original use the base name, so try both forms.
if ( $attachment_id === 0 ) {
    $base_file_url = preg_replace( '/-\d+x\d+(?=\.[^.]+$)/', '', $file_url );

    foreach ( array( $base_file_url, preg_replace( '/(\.[^.]+)$/', '-scaled$1', $base_file_url ) ) as $candidate ) {
        if ( $candidate !== $file_url && ( $attachment_id = attachment_url_to_postid( $candidate ) ) )
            break;
    }
}

/**
 * Serve requested File when:
 *
 * - the current user can manage the attachment (e.g. media library thumbnails and single file view in the WordPress Dashboard)
 * - there are no restrictions set for the attachment
 * - File Restriction Add-on is not active
 *
 * Note: authorization is based on the real, server-side resolved current user (the auth cookie is available because wp-load.php is loaded above)
 *
 */
if ( current_user_can( 'edit_post', $attachment_id ) || !wppb_content_restriction_is_post_restricted( $attachment_id ) || !wppb_check_if_add_on_is_active( 'wppb_fileRestriction' ) ) {
    wppb_file_restriction_serve_file( $file_path, $file_mime_type );
}

// get the general Content Restriction settings
$wppb_content_restriction_settings = get_option( 'wppb_content_restriction_settings', 'not_found' );

// get the attachment and global restriction types
$attachment_restriction_type = get_post_meta( $attachment_id, 'wppb-content-restrict-type', true );
$settings_restriction_type = $wppb_content_restriction_settings['restrict_type'];

// handle attachment Default type restriction
if ( $attachment_restriction_type === 'default' )
    $attachment_restriction_type = $wppb_content_restriction_settings['restrict_type'];

// handle attachment Redirect type restriction
if ( $attachment_restriction_type === 'redirect' ) {
    $attachment_redirect_url_enabled = get_post_meta( $attachment_id, 'wppb-content-restrict-custom-redirect-url-enabled', true );
    $attachment_redirect_url = get_post_meta( $attachment_id, 'wppb-content-restrict-custom-redirect-url', true );
    $redirect_url = ( !empty( $attachment_redirect_url_enabled ) && !empty( $attachment_redirect_url ) ? $attachment_redirect_url : '' );

    // if a custom redirect URL is not set for the attachment, get the default redirect URL from general Content Restriction settings
    if ( empty( $redirect_url ) )
        $redirect_url = ( !empty( $wppb_content_restriction_settings['redirect_url'] ) ? $wppb_content_restriction_settings['redirect_url'] : '' );

    // if there is no redirect URL, serve the file
    if ( empty( $redirect_url ) )
        wppb_file_restriction_serve_file( $file_path, $file_mime_type );

    // redirect the user to the specific URL
    nocache_headers();
    wp_redirect( apply_filters( 'wppb_file_restriction_redirect_url', $redirect_url ) );
    exit;
}

// default for the Message restriction type, and the fail-safe for any restricted attachment whose type is missing or unexpected: deny access with the configured restriction message
$message = wppb_content_restriction_get_post_message( $attachment_id );

status_header( 403 );
nocache_headers();
die( wp_kses_post( $message ) );

/**
 * Serve requested File
 *
 */
function wppb_file_restriction_serve_file( $file_path, $file_mime_type ) {

    if ( file_exists( $file_path ) ) {

        nocache_headers();
        header( 'Content-Type: ' . $file_mime_type );
        readfile( $file_path );
        exit;

    } else {

        status_header( 404 );
        nocache_headers();
        die( 'File not found.' );

    }

}