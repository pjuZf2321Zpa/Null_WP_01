jQuery(document).ready(function ($) {
    $('.wppb-user-forms').each(function () {
        var $form = $(this);
        var $progressBarContainer = $form.find('.wppb-progress-bar-container');

        if ($progressBarContainer.length === 0) {
            $progressBarContainer = $form.prev('.wppb-progress-bar-container').add($form.next('.wppb-progress-bar-container')).add($form.find('.wppb-progress-bar-container'));
        }

        if ($progressBarContainer.length === 0) return;

        var calculationMode = $progressBarContainer.data('calculation-mode'); // 'all' or 'required'

        function calculateProgress() {
            var total = 0;
            var filled = 0;

            var $fields = $form.find('li.wppb-form-field, .pms-field');
            $fields.each(function () {
                var $fieldLi = $(this);

                // Skip hidden fields (conditionally hidden)
                //if ($fieldLi.is(':hidden') && !$fieldLi.hasClass('wppb-repeater-field')) {
                if ($fieldLi.css('display') === 'none' && !$fieldLi.hasClass('wppb-repeater-field')) {
                    return;
                }

                // Ignore the "Send credentials via email" checkbox
                if ($fieldLi.hasClass('wppb-send-credentials-checkbox')) {
                    return;
                }

                // Ignore Repeater Field Templates (parent UL ID ending in '_template')
                if ($fieldLi.closest('ul').attr('id') && $fieldLi.closest('ul').attr('id').indexOf('_template') !== -1) {
                    return;
                }


                // We treat the entire 2FA block as a SINGLE item that is counted only if the "Activate" checkbox is
                // checked and is filled-in only if the verification result is valid.

                if ($fieldLi.find('#wppb_auth_enabled').length > 0) {
                    var $authEnabled = $fieldLi.find('#wppb_auth_enabled');
                    if (!$authEnabled.is(':checked')) {
                        return; // Not active, so not part of the total count.
                    }
                    // It is checked, so it counts as 1 item.
                    total++;

                    // Check if verified
                    var $verifyResult = $form.find('#wppb_auth_verify_result');
                    if ($verifyResult.length > 0 && $verifyResult.val() === 'valid') {
                        filled++;
                    }
                    return; // Done processing this 2FA group
                }

                // Any other field belonging to the 2FA group should be ignored to prevent double counting
                if ($fieldLi.hasClass('wppb_auth_active') || ($fieldLi.hasClass('wppb-form-field') && $fieldLi.find('[id^="wppb_auth_"]').length > 0)) {
                    return;
                }

                // Ignore some fields for Edit Profile forms (Password fields)
                if ($form.hasClass('wppb-edit-user') && $fieldLi.find('input[type="password"]').length > 0) {
                    return;
                }

                // Check inputs within this LI with special handling for WYSIWYG editors
                var $inputs = $fieldLi.find(':input:not([type="hidden"]):not([type="submit"]):not([type="button"])');

                if ($fieldLi.hasClass('wppb-upload') || $fieldLi.hasClass('wppb-avatar')) {
                    var $hiddenUpload = $fieldLi.find('input[type="hidden"]').filter(function () {
                        return $(this).attr('name').indexOf('allowed_extensions_') === -1;
                    });
                    if ($hiddenUpload.length > 0) {
                        $inputs = $inputs.add($hiddenUpload);
                    }
                }

                if ($inputs.length === 0) {
                    var $wysiwyg = $fieldLi.find('.wp-editor-area');
                    if ($wysiwyg.length > 0) {
                        $inputs = $wysiwyg;
                    } else {
                        // Check for Map markers (hidden inputs)
                        var $mapMarkers = $fieldLi.find('input.wppb-map-marker');
                        if ($mapMarkers.length > 0) {
                            $inputs = $mapMarkers;
                        } else {
                            if ($fieldLi.find('.wppb-map-container').length > 0) {
                                // Empty map container, treat as input to allow checking for requirement
                                $inputs = $fieldLi.find('.wppb-map-container');
                            } else {
                                return; // No inputs
                            }
                        }
                    }
                }

                var isRequired = $fieldLi.find('.wppb-required').length > 0 || $fieldLi.find(':input[required]').length > 0;

                if (calculationMode === 'required' && !isRequired) {
                    return;
                }

                total++;

                // Check if filled
                var isFilled = false;

                // For checkboxes/radios
                if ($inputs.is(':checkbox') || $inputs.is(':radio')) {
                    if ($inputs.filter(':checked').length > 0) {
                        isFilled = true;
                    }
                } else {
                    // For text/select/textarea
                    $inputs.each(function () {
                        var val = $(this).val();
                        var $input = $(this);

                        // Check for TinyMCE (WYSIWYG)
                        if ($input.hasClass('wp-editor-area') && typeof tinymce !== 'undefined') {
                            var editor = tinymce.get($input.attr('id'));
                            if (editor && !editor.isHidden()) {
                                var textContent = editor.getContent({ format: 'text' }).trim();
                                if (textContent.length > 0) val = textContent;
                                else val = '';
                            }
                        }

                        if (val !== null && val !== '' && typeof val !== 'undefined') {
                            if (typeof val === 'string') {
                                if (val.trim() !== '') {
                                    isFilled = true;
                                    return false; // break loop
                                }
                            } else if (Array.isArray(val)) {
                                if (val.length > 0) {
                                    isFilled = true;
                                    return false; // break loop
                                }
                            } else {
                                isFilled = true;
                                return false; // break loop
                            }
                        }
                    });
                }

                if (isFilled) {
                    filled++;
                }
            });

            var percentage = total === 0 ? 100 : Math.round((filled / total) * 100);
            updateProgressBar(percentage);
        }

        function updateProgressBar(percentage) {
            $progressBarContainer.each(function () {
                var $thisBar = $(this);
                $thisBar.find('.wppb-progress-bar-fill').css('width', percentage + '%');
                $thisBar.find('.wppb-progress-bar-text span').text(percentage + '%');
            });
        }

        // Bind events
        $form.on('change keyup paste', ':input', function () {
            calculateProgress();
        });

        // Bind to TinyMCE events (for WYSIWYG)
        if (typeof tinymce !== 'undefined') {
            setTimeout(function () {
                $form.find('.wp-editor-area').each(function () {
                    var editorId = $(this).attr('id');
                    var editor = tinymce.get(editorId);
                    if (editor) {
                        editor.on('KeyUp Change', function () {
                            calculateProgress();
                        });
                    }
                });
            }, 1000);
        }

        // Bind to Iris Colorpicker events
        setTimeout(function () {
            var $colorPickers = $form.find('.custom_field_colorpicker');
            if ($colorPickers.length > 0 && $.fn.iris) {
                $colorPickers.each(function () {
                    var $picker = $(this);
                    // Check if iris is initialized
                    if ($picker.data('a8cIris')) {
                        var existingChange = $picker.iris('option', 'change');
                        $picker.iris('option', 'change', function (event, ui) {
                            if (typeof existingChange === 'function') {
                                existingChange.call(this, event, ui);
                            }
                            // Ensure value is updated
                            $(this).val(ui.color.toString());
                            calculateProgress();
                        });
                    }
                });
            }
        }, 1000);



        // Listen for custom trigger from other scripts (e.g. Map field)
        $form.on('wppb-update-progress-bar', function () {
            calculateProgress();
        });

        $(document).on('wppb_file_uploaded wppb_removed_uploaded_file wppb_repeater_field_changed', function () {
            calculateProgress();
        });


        // Initial check
        calculateProgress();
    });
});
