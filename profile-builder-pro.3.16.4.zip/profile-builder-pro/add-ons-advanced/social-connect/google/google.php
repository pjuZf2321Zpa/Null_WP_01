<?php
// Exit if accessed directly
if( ! defined( 'ABSPATH' ) ) exit;

if( ! function_exists( 'wppb_in_sc_verify_google_userinfo' ) ) {
    /**
     * Ask Google who the supplied OAuth access token belongs to and return a
     * trusted identity. Shared by the classic Google and the Google Identity
     * Services flows (both send the provider access token as the "security
     * token"). The id/email are derived only from Google's verified userinfo
     * response, so a crafted platform_response can no longer be matched against
     * an arbitrary victim's _wppb_google(_gis)_connect_id. Returns an empty
     * array when the token is missing or invalid so the handler refuses login.
     */
    function wppb_in_sc_verify_google_userinfo( $platform_response = array() ) {
        $access_token = isset( $_POST['wppb_sc_security_token'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['wppb_sc_security_token'] ) ) ) : ''; //phpcs:ignore

        if( empty( $access_token ) ) {
            return array();
        }

        $response = wp_remote_get( 'https://www.googleapis.com/oauth2/v2/userinfo', array(
            'timeout' => 15,
            'headers' => array( 'Authorization' => 'Bearer ' . $access_token ),
        ) );

        if( is_wp_error( $response ) || 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
            return array();
        }

        $body = json_decode( wp_remote_retrieve_body( $response ), true );

        if( ! is_array( $body ) || empty( $body['id'] ) ) {
            return array();
        }

        $email = ( isset( $body['email'] ) && is_email( $body['email'] ) ) ? sanitize_email( $body['email'] ) : '';
        if( empty( $email ) && isset( $platform_response['email'] ) && is_email( $platform_response['email'] ) ) {
            $email = sanitize_email( $platform_response['email'] );
        }

        return array(
            'id'         => sanitize_text_field( $body['id'] ),
            'first_name' => isset( $body['given_name'] ) ? sanitize_text_field( $body['given_name'] ) : '',
            'last_name'  => isset( $body['family_name'] ) ? sanitize_text_field( $body['family_name'] ) : '',
            'email'      => $email,
        );
    }
}

/* Verify the Google login server-side; see wppb_in_sc_verify_google_userinfo(). */
add_filter( 'wppb_sc_process_google_response', 'wppb_in_sc_process_google_response' );
function wppb_in_sc_process_google_response( $platform_response ) {
    return wppb_in_sc_verify_google_userinfo( is_array( $platform_response ) ? $platform_response : array() );
}

/* Generate the Google button */
function wppb_in_sc_generate_google_button( $form_ID ) {
	global $social_connect_instance;

    if( empty( $social_connect_instance->wppb_social_connect_settings[0]['google-sign-in-button'] ) || ( ! empty( $social_connect_instance->wppb_social_connect_settings[0]['google-sign-in-button'] ) && $social_connect_instance->wppb_social_connect_settings[0]['google-sign-in-button'] == 'old' ) ) {
        $class = 'wppb-sc-google-login wppb-sc-button';
        global $pagenow;
        if( $pagenow == 'wp-login.php' ) {
            $class .= '-wp-default';
        }

        if( ! empty( $social_connect_instance->wppb_social_connect_settings[0]['buttons-style'] ) && $social_connect_instance->wppb_social_connect_settings[0]['buttons-style'] == 'text' ) {
            $class .= '-text';
        }

        $button = '';
        if( ! empty( $social_connect_instance->wppb_social_connect_settings[0]['buttons-style'] ) && $social_connect_instance->wppb_social_connect_settings[0]['buttons-style'] == 'text' ) {
            $button = '<div class="wppb-sc-buttons-text-div">';
        }
        $check_if_linked = get_user_meta( get_current_user_id(), '_wppb_google_connect_id' );
        if( isset( $social_connect_instance->forms_type ) && $social_connect_instance->forms_type == 'edit_profile' && ! empty( $check_if_linked ) ) {
            $class .= ' wppb-sc-disabled-btn';
        }
        $button .= '<a class="' . $class . '" href="#" data-wppb_sc_form_id_google="' . $form_ID . '">';
        $button .= '<i class="wppb-sc-icon-google-plus wppb-sc-icon"></i>';
        if( ! empty( $social_connect_instance->wppb_social_connect_settings[0]['buttons-style'] ) && $social_connect_instance->wppb_social_connect_settings[0]['buttons-style'] == 'text' ) {
            if( isset( $social_connect_instance->forms_type ) && $social_connect_instance->forms_type == 'edit_profile' ) {
                if( ! empty( $social_connect_instance->wppb_social_connect_settings[0]['google-button-text-ep'] ) ) {
                    $button .= wppb_icl_t( 'plugin profile-builder-pro', 'social_connect_google_button_text_ep_translation', esc_attr( $social_connect_instance->wppb_social_connect_settings[0]['google-button-text-ep'] ));
                } else {
                    $button .= __( 'Link with Google', 'profile-builder' );
                }
            } else {
                if( ! empty( $social_connect_instance->wppb_social_connect_settings[0]['google-button-text'] ) ) {
                    $button .= wppb_icl_t( 'plugin profile-builder-pro', 'social_connect_google_button_text_translation', esc_attr( $social_connect_instance->wppb_social_connect_settings[0]['google-button-text'] ));
                } else {
                    $button .= __( 'Sign in with Google', 'profile-builder' );
                }
            }
        }

        $button .= '</a>';
        if( ! empty( $social_connect_instance->wppb_social_connect_settings[0]['buttons-style'] ) && $social_connect_instance->wppb_social_connect_settings[0]['buttons-style'] == 'text' ) {
            $button .= '</div>';
        }
    }
    else{
        $class = 'wppb-sc-google-login-new wppb-sc-button';
        global $pagenow;
        if( $pagenow == 'wp-login.php' ) {
            $class .= '-wp-default';
        }
        $button = '<a class="' . $class . '" href="#" data-wppb_sc_form_id_google="' . $form_ID . '"><i class="wppb-sc-icon-google-plus-new wppb-sc-icon"></i></a>';
    }

    return $button;
}