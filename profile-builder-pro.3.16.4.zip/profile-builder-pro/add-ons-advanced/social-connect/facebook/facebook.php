<?php
// Exit if accessed directly
if( ! defined( 'ABSPATH' ) ) exit;

/**
 * Verify the Facebook login server-side and return a trusted identity.
 *
 * Security: the login handler must never trust the client-supplied
 * platform_response. The browser obtains a real Facebook OAuth access token and
 * sends it as the "security token"; here we ask Facebook's Graph API who that
 * token actually belongs to and derive the id/email only from that verified
 * response. This closes the account takeover where a crafted
 * platform_response[id] could be matched against an arbitrary victim's
 * _wppb_facebook_connect_id. An empty array is returned when the token is
 * missing or invalid so the handler refuses to authenticate.
 */
add_filter( 'wppb_sc_process_facebook_response', 'wppb_in_sc_process_facebook_response' );
function wppb_in_sc_process_facebook_response( $platform_response ) {
    $access_token = isset( $_POST['wppb_sc_security_token'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['wppb_sc_security_token'] ) ) ) : ''; //phpcs:ignore

    if( empty( $access_token ) ) {
        return array();
    }

    $response = wp_remote_get(
        'https://graph.facebook.com/me?fields=id,first_name,last_name,email&access_token=' . rawurlencode( $access_token ),
        array( 'timeout' => 15 )
    );

    if( is_wp_error( $response ) || 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
        return array();
    }

    $body = json_decode( wp_remote_retrieve_body( $response ), true );

    if( ! is_array( $body ) || empty( $body['id'] ) ) {
        return array();
    }

    /* Facebook does not always return an email; fall back to the address the
       user typed in the prompt only when the provider did not supply one. */
    $email = ( isset( $body['email'] ) && is_email( $body['email'] ) ) ? sanitize_email( $body['email'] ) : '';
    if( empty( $email ) && isset( $platform_response['email'] ) && is_email( $platform_response['email'] ) ) {
        $email = sanitize_email( $platform_response['email'] );
    }

    return array(
        'id'         => sanitize_text_field( $body['id'] ),
        'first_name' => isset( $body['first_name'] ) ? sanitize_text_field( $body['first_name'] ) : '',
        'last_name'  => isset( $body['last_name'] ) ? sanitize_text_field( $body['last_name'] ) : '',
        'email'      => $email,
    );
}

/* Generate the Facebook button */
function wppb_in_sc_generate_facebook_button( $form_ID ) {
	global $social_connect_instance;

	$class = 'wppb-sc-facebook-login wppb-sc-button';

	global $pagenow;
	if( $pagenow == 'wp-login.php' ) {
		$class .= '-wp-default';
	}

	if( ! empty( $social_connect_instance->wppb_social_connect_settings[0]['buttons-style'] ) && $social_connect_instance->wppb_social_connect_settings[0]['buttons-style'] == 'text' ) {
		$class .= '-text';
	}

	$button = '';
	if( ! empty( $social_connect_instance->wppb_social_connect_settings[0]['buttons-style'] ) && $social_connect_instance->wppb_social_connect_settings[0]['buttons-style'] == 'text' ) {
		$button = '<div class="wppb-sc-buttons-text-div">';
	}
	$check_if_linked = get_user_meta( get_current_user_id(), '_wppb_facebook_connect_id' );
	if( isset( $social_connect_instance->forms_type ) && $social_connect_instance->forms_type == 'edit_profile' && ! empty( $check_if_linked ) ) {
		$class .= ' wppb-sc-disabled-btn';
	}
	$button .= '<a class="' . $class . '" href="#" data-wppb_sc_form_id_facebook="' . $form_ID . '">';
    $button .= '<i class="wppb-sc-icon-facebook wppb-sc-icon"></i>';
    if( ! empty( $social_connect_instance->wppb_social_connect_settings[0]['buttons-style'] ) && $social_connect_instance->wppb_social_connect_settings[0]['buttons-style'] == 'text' ) {
		if( isset( $social_connect_instance->forms_type ) && $social_connect_instance->forms_type == 'edit_profile' ) {
			if( ! empty( $social_connect_instance->wppb_social_connect_settings[0]['facebook-button-text-ep'] ) ) {
				$button .= wppb_icl_t( 'plugin profile-builder-pro', 'social_connect_facebook_button_text_ep_translation', esc_attr( $social_connect_instance->wppb_social_connect_settings[0]['facebook-button-text-ep'] ));
			} else {
				$button .= __( 'Link with Facebook', 'profile-builder' );
			}
		} else {
			if( ! empty( $social_connect_instance->wppb_social_connect_settings[0]['facebook-button-text'] ) ) {
				$button .= wppb_icl_t( 'plugin profile-builder-pro', 'social_connect_facebook_button_text_translation', esc_attr( $social_connect_instance->wppb_social_connect_settings[0]['facebook-button-text'] ));
			} else {
				$button .= __( 'Sign in with Facebook', 'profile-builder' );
			}
		}
    }

    $button .= '</a>';
	if( ! empty( $social_connect_instance->wppb_social_connect_settings[0]['buttons-style'] ) && $social_connect_instance->wppb_social_connect_settings[0]['buttons-style'] == 'text' ) {
		$button .= '</div>';
	}

    return $button;
}