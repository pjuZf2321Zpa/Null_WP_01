const interfaceTranslations = {
  selectedCountryAriaLabel: "Tanlangan davlat",
  noCountrySelected: "Davlat tanlanmagan",
  countryListAriaLabel: "Davlatlar roʻyxati",
  searchPlaceholder: "Davlatni qidiring",
  clearSearchAriaLabel: "Qidiruvni tozalang",
  searchEmptyState: "Natija topilmadi",
  searchSummaryAria(count) {
    if (count === 0) {
      return "Natija topilmadi";
    }
    if (count === 1) {
      return "1-ta natija topildi";
    }
    return `${count}-ta natija topildi`;
  }
};
export default interfaceTranslations;
