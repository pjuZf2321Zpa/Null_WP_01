<?php

// SPDX-FileCopyrightText: 2026 Ovation S.r.l. <dev@novamira.ai>
// SPDX-License-Identifier: AGPL-3.0-or-later

declare(strict_types=1);

namespace Novamira\Pro\Abilities\Kirki;

use WP_Post;

/**
 * Content Manager validators shared by the collection and item abilities:
 * field definitions (the `kirki_cm_fields` list a collection stores) and
 * field values (the `kirki_cm_field_<collection>_<field>` meta rows and the
 * `kirki_cm_reference` rows an item stores).
 *
 * The rules mirror the editor's item form validation (required, character
 * limits, the email and phone
 * regexes, number formats, media formats and size limits) plus what the
 * renderer needs (`get_post_dynamic_content` reads `['id']` / `['url']` on
 * media values, `['value']` / `['unit']` on time values, formats dates with
 * the field's `default_format`). Kirki applies these rules in the item form;
 * the abilities apply them server-side.
 */

if (!defined('ABSPATH')) {
    exit();
}

/** The 16 field types (`Kirki\App\Constants\Collection\CustomFieldTypes`). */
const KK_CM_FIELD_TYPES = [
    'text',
    'rich-text',
    'image',
    'video',
    'email',
    'phone',
    'number',
    'date',
    'time',
    'switch',
    'option',
    'url',
    'file',
    'gallery',
    'reference',
    'multi-reference',
];

const KK_CM_REFERENCE_TYPES = ['reference', 'multi-reference'];

const KK_CM_MEDIA_TYPES = ['image', 'video', 'gallery'];

const KK_CM_NUMBER_FORMATS = ['integer', 'decimal', 'any-format'];

const KK_CM_IMAGE_TYPES = ['media-manager', 'image-url'];

const KK_CM_VIDEO_TYPES = ['media-manager', 'video-url'];

const KK_CM_SIZE_UNITS = ['kb', 'mb'];

/** Max bytes of a plain-text value (text, email, phone, url, file, option, date). */
const KK_CM_TEXT_BYTES = 65_536;

/** Max bytes of a rich-text value. */
const KK_CM_RICH_TEXT_BYTES = 262_144;

/** Max bytes of a field title / help text / option value / template key. */
const KK_CM_LABEL_BYTES = 200;

/** Max entries of a gallery / multi-reference value. */
const KK_CM_LIST_MAX = 200;

/**
 * Max bytes one page of item VALUES may carry (`list-collection-items` with
 * `include_fields`), the same budget the form readers use: a collection with
 * a hundred rich-text fields would otherwise return megabytes uncapped.
 */
const KK_CM_PAGE_BYTES = 1_048_576;

/**
 * Max field definitions in one collection. The editor's Fields panel adds them
 * one at a time and every field costs a meta row per item; nothing there comes
 * near this, so a list above it is a mistake rather than a design.
 */
const KK_CM_MAX_FIELDS = 100;

/** Characters a label / plain value may not carry (markup and control characters). */
const KK_CM_TEXT_PATTERN = '/[<>\x00-\x08\x0B\x0C\x0E-\x1F]/';

/** Kirki's field id format (`kk_new_id`). */
const KK_CM_ID_PATTERN = '/^k-[a-z0-9]{8}$/';

/** The email pattern the editor's item form applies. */
const KK_CM_EMAIL_PATTERN = '/^(([^<>()[\]\\\\.,;:\s@"]+(\.[^<>()[\]\\\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/';

/** The phone pattern the editor's item form applies. */
const KK_CM_PHONE_PATTERN = '/^[\+]?([0-9][\s]?|[0-9]?)([(][0-9]{3}[)][\s]?|[0-9]{3}[-\s\.]?)[0-9]{3}[-\s\.]?[0-9]{4,6}$/im';

/**
 * Time value shape: `HH:MM` on the editor's 12-hour clock (`09:00`), paired
 * with an am / pm unit. The editor's picker writes 01–12 (`h > 12 → h - 12`,
 * `h === 0 → 12`) and reads the pair back as `pm && h !== 12 → h + 12`,
 * `am && h === 12 → 0`, so an hour above 12 has no meaning there.
 */
const KK_CM_TIME_PATTERN = '/^(0[1-9]|1[0-2]):[0-5][0-9]$/';

/**
 * The editor's default definition per type (as of 6.3.1),
 * in the editor's key order; `title` is the editor's default label, `id`
 * is appended last and `editRefCollection` after it on reference types
 * (`CollectionService::save_fields`).
 *
 * @return array<string, array<string, mixed>>
 */
// @mago-expect lint:halstead -- one literal per type
function kk_cm_field_defaults(): array
{
    $limit = ['enabled' => false, 'min' => 0, 'max' => 10];
    return [
        'text' => [
            'kind' => 'custom',
            'type' => 'text',
            'title' => 'Text',
            'help_text' => '',
            'default_value' => '',
            'character_limit' => $limit,
            'required' => false,
        ],
        'rich-text' => [
            'kind' => 'custom',
            'type' => 'rich-text',
            'title' => 'Rich Text',
            'help_text' => '',
            'default_value' => '',
            'character_limit' => $limit,
            'required' => false,
        ],
        'image' => [
            'kind' => 'custom',
            'type' => 'image',
            'title' => 'Image',
            'help_text' => '',
            'image_file_format' => ['*'],
            'image_type' => 'media-manager',
            'default_value' => '',
            'size_limitation' => ['enabled' => false, 'min' => 0, 'max' => 2000, 'unit' => 'kb'],
            'required' => false,
        ],
        'video' => [
            'kind' => 'custom',
            'type' => 'video',
            'title' => 'Video',
            'help_text' => '',
            'default_value' => '',
            'size_limitation' => ['enabled' => false, 'min' => 0, 'max' => 2, 'unit' => 'mb'],
            'video_type' => 'media-manager',
            'video_format' => ['*'],
            'required' => false,
        ],
        'email' => kk_cm_plain_default(type: 'email', title: 'Email'),
        'phone' => kk_cm_plain_default(type: 'phone', title: 'Phone'),
        'number' => [
            'kind' => 'custom',
            'type' => 'number',
            'title' => 'Number',
            'help_text' => '',
            'default_value' => '',
            'number_format' => 'any-format',
            'allows_negative_numbers' => false,
            'required' => false,
        ],
        'date' => [
            'kind' => 'custom',
            'type' => 'date',
            'title' => 'Date',
            'help_text' => '',
            'default_value' => '',
            'default_format' => 'YYYY-MM-DD',
            'include_time_field' => false,
            'required' => false,
        ],
        'time' => kk_cm_plain_default(type: 'time', title: 'Time'),
        'switch' => [
            'kind' => 'custom',
            'type' => 'switch',
            'title' => 'Switch',
            'help_text' => '',
            'default_value' => 'on',
            'required' => false,
        ],
        'option' => [
            'kind' => 'custom',
            'type' => 'option',
            'title' => 'Option',
            'help_text' => '',
            'options' => [['value' => 'Option 1', 'isDefault' => true], ['value' => 'Option 2', 'isDefault' => false]],
            'required' => false,
        ],
        'url' => kk_cm_plain_default(type: 'url', title: 'URL'),
        'file' => kk_cm_plain_default(type: 'file', title: 'File'),
        'gallery' => [
            'kind' => 'custom',
            'type' => 'gallery',
            'title' => 'Gallery',
            'help_text' => '',
            'image_file_format' => ['*'],
            'image_type' => 'media-manager',
            'default_value' => '',
            'required' => false,
        ],
        'reference' => [
            'kind' => 'custom',
            'type' => 'reference',
            'title' => 'Reference',
            'help_text' => '',
            'ref_collection' => '',
            'required' => false,
        ],
        'multi-reference' => [
            'kind' => 'custom',
            'type' => 'multi-reference',
            'title' => 'Multiple Reference',
            'help_text' => '',
            'ref_collection' => '',
            'required' => false,
        ],
    ];
}

/** @return array<string, mixed> */
function kk_cm_plain_default(string $type, string $title): array
{
    return [
        'kind' => 'custom',
        'type' => $type,
        'title' => $title,
        'help_text' => '',
        'default_value' => '',
        'required' => false,
    ];
}

/** The keys a definition of `$type` may carry besides the common ones. */
function kk_cm_extra_keys(string $type): array
{
    return match ($type) {
        'text', 'rich-text' => ['character_limit'],
        'number' => ['number_format', 'allows_negative_numbers'],
        'date' => ['default_format', 'include_time_field'],
        'option' => ['options'],
        'image' => ['image_file_format', 'image_type', 'size_limitation'],
        'gallery' => ['image_file_format', 'image_type'],
        'video' => ['size_limitation', 'video_type', 'video_format'],
        'reference', 'multi-reference' => ['ref_collection', 'editRefCollection'],
        default => [],
    };
}

/**
 * Validate and complete a list of field definitions against the stored
 * list: every entry gets the editor's defaults for its type, an id (kept
 * when given and stored, fresh otherwise), unique titles and ids; a stored
 * id may not change type (its item values would stop matching).
 *
 * @param array<array-key, mixed> $fields the input list
 * @param list<array<string, mixed>> $stored the stored definitions
 * @return array{errors: list<string>, fields: list<array<string, mixed>>, warnings: list<string>}
 */
// @mago-expect lint:cyclomatic-complexity
// @mago-expect lint:halstead
// @mago-expect lint:kan-defect
function kk_cm_validate_field_defs(array $fields, array $stored): array
{
    $errors = [];
    $warnings = [];
    if (!kk_is_list($fields)) {
        return ['errors' => ['`fields` must be a list of definitions.'], 'fields' => [], 'warnings' => []];
    }
    if (count($fields) > KK_CM_MAX_FIELDS) {
        return [
            'errors' => [sprintf(
                '`fields` holds %d definitions; a collection takes at most %d (the editor\'s panel writes them one by one and nothing there produces more).',
                count($fields),
                KK_CM_MAX_FIELDS,
            )],
            'fields' => [],
            'warnings' => [],
        ];
    }
    $stored_by_id = [];
    foreach ($stored as $def) {
        if (!is_string($def['id'] ?? null)) {
            continue;
        }
        $stored_by_id[$def['id']] = $def;
    }
    $taken = [];
    $titles = [];
    $out = [];
    /** @var mixed $def */
    foreach ($fields as $index => $def) {
        $label = sprintf('fields[%d]', $index);
        if (!is_array($def) || kk_is_list($def)) {
            $errors[] = sprintf('%s must be an object.', $label);
            continue;
        }
        /** @var array<string, mixed> $def */
        /** @var mixed $type */
        $type = $def['type'] ?? null;
        if (!is_string($type) || !in_array($type, KK_CM_FIELD_TYPES, strict: true)) {
            $errors[] = sprintf('%s: `type` must be one of %s.', $label, implode(', ', KK_CM_FIELD_TYPES));
            continue;
        }
        $unknown = array_diff(
            array_keys($def),
            ['id', 'kind', 'type', 'title', 'help_text', 'required', 'default_value', 'templateKey'],
            kk_cm_extra_keys($type),
        );
        if ($unknown !== []) {
            $errors[] = sprintf(
                '%s (%s): unknown key(s) `%s`; the editor writes a fixed set per type.',
                $label,
                $type,
                implode('`, `', array_map('strval', $unknown)),
            );
            continue;
        }
        $title_error = kk_cm_label_error($def['title'] ?? null, field: 'title', required: true);
        if ($title_error !== null) {
            $errors[] = sprintf('%s: %s', $label, $title_error);
            continue;
        }
        /** @var string $title */
        $title = $def['title'];
        $title_key = mb_strtolower(trim($title));
        if (isset($titles[$title_key])) {
            $errors[] = sprintf(
                '%s: title `%s` is used twice; the editor labels and binds fields by title.',
                $label,
                $title,
            );
            continue;
        }
        $titles[$title_key] = true;
        /** @var mixed $id */
        $id = $def['id'] ?? null;
        if ($id !== null && (!is_string($id) || preg_match(KK_CM_ID_PATTERN, $id) !== 1)) {
            $errors[] = sprintf(
                '%s: `id` must match `k-` + 8 lowercase alphanumerics (Kirki\'s format), or be omitted.',
                $label,
            );
            continue;
        }
        if (is_string($id) && isset($taken[$id])) {
            $errors[] = sprintf('%s: id `%s` is used twice.', $label, $id);
            continue;
        }
        if (is_string($id) && isset($stored_by_id[$id]) && ($stored_by_id[$id]['type'] ?? null) !== $type) {
            $errors[] = sprintf(
                '%s: field `%s` is stored as `%s` and cannot become `%s` (its item values would stop matching); remove it and add a new field instead.',
                $label,
                $id,
                (string) ($stored_by_id[$id]['type'] ?? ''),
                $type,
            );
            continue;
        }
        $extra_errors = kk_cm_field_extra_errors(
            $type,
            $def,
            $label,
            is_string($id) ? $stored_by_id[$id]['ref_collection'] ?? null : null,
        );
        if ($extra_errors !== []) {
            array_push($errors, ...$extra_errors);
            continue;
        }
        /** @var array<string, mixed> $used */
        $used = $taken + $stored_by_id;
        $completed = kk_cm_complete_def($type, $def, is_string($id) ? $id : kk_new_id($used));
        $taken[$completed['id']] = true;
        $default_error = kk_cm_default_value_error($completed);
        if ($default_error !== null) {
            $errors[] = sprintf('%s: %s', $label, $default_error);
            continue;
        }
        if (is_string($id) && !isset($stored_by_id[$id])) {
            $warnings[] = sprintf(
                '%s: id `%s` is new (no stored field has it); it was kept as given. An id another collection uses is accepted too — item meta keys carry the collection id, so nothing collides — but the two fields stay unrelated.',
                $label,
                $id,
            );
        }
        $dead_ref = kk_cm_dead_ref_warning($type, $completed, $label);
        if ($dead_ref !== null) {
            $warnings[] = $dead_ref;
        }
        $out[] = $completed;
    }
    return ['errors' => $errors, 'fields' => $out, 'warnings' => $warnings];
}

/**
 * The stored shape of a definition: the editor's defaults for the type in the
 * editor's key order, the given keys on top, `id` last (and
 * `editRefCollection` after it on reference types, as Kirki's save adds it).
 *
 * @param array<string, mixed> $def
 * @return array<string, mixed>
 */
// @mago-expect lint:cyclomatic-complexity -- one overlay per type family
// @mago-expect lint:halstead
function kk_cm_complete_def(string $type, array $def, string $id): array
{
    $defaults = kk_cm_field_defaults()[$type];
    $out = [];
    /** @var mixed $default */
    foreach ($defaults as $key => $default) {
        $out[$key] = array_key_exists($key, $def) ? $def[$key] : $default;
    }
    $out['kind'] = 'custom';
    $out['type'] = $type;
    $out['title'] = trim((string) $def['title']);
    $out['help_text'] = is_string($def['help_text'] ?? null) ? $def['help_text'] : '';
    $out['required'] = kk_bool($def['required'] ?? false);
    if (is_string($def['templateKey'] ?? null) && $def['templateKey'] !== '') {
        $out['templateKey'] = $def['templateKey'];
    }
    if (in_array($type, KK_CM_REFERENCE_TYPES, strict: true)) {
        $out['ref_collection'] = (int) ($def['ref_collection'] ?? 0);
    }
    if ($type === 'option') {
        $out['options'] = kk_cm_normalize_options($def['options'] ?? null);
    }
    if (in_array($type, ['text', 'rich-text'], strict: true)) {
        /** @var array<string, mixed> $limit_default */
        $limit_default = is_array($defaults['character_limit'] ?? null) ? $defaults['character_limit'] : [];
        $out['character_limit'] = kk_cm_normalize_limit($def['character_limit'] ?? null, $limit_default);
    }
    if (in_array($type, ['image', 'video'], strict: true)) {
        /** @var array<string, mixed> $size_default */
        $size_default = is_array($defaults['size_limitation'] ?? null) ? $defaults['size_limitation'] : [];
        $out['size_limitation'] = kk_cm_normalize_limit($def['size_limitation'] ?? null, $size_default);
    }
    $out['id'] = $id;
    if (in_array($type, KK_CM_REFERENCE_TYPES, strict: true)) {
        $out['editRefCollection'] = kk_bool($def['editRefCollection'] ?? false);
    }
    return $out;
}

/**
 * @param array<string, mixed> $default
 * @return array<string, mixed>
 */
function kk_cm_normalize_limit(mixed $given, array $default): array
{
    if (!is_array($given)) {
        return $default;
    }
    $out = $default;
    $out['enabled'] = kk_bool($given['enabled'] ?? $default['enabled']);
    $out['min'] = kk_coerce_int_or_null($given['min'] ?? null) ?? $default['min'];
    $out['max'] = kk_coerce_int_or_null($given['max'] ?? null) ?? $default['max'];
    if (array_key_exists('unit', $default)) {
        $out['unit'] = is_string($given['unit'] ?? null) ? strtolower($given['unit']) : $default['unit'];
    }
    return $out;
}

/** @return list<array{value: string, isDefault: bool}> */
function kk_cm_normalize_options(mixed $given): array
{
    $out = [];
    $has_default = false;
    /** @var mixed $option */
    foreach (is_array($given) ? $given : [] as $option) {
        if (!is_array($option)) {
            continue;
        }
        $is_default = kk_bool($option['isDefault'] ?? false) && !$has_default;
        $has_default = $has_default || $is_default;
        $out[] = ['value' => trim((string) ($option['value'] ?? '')), 'isDefault' => $is_default];
    }
    if (!$has_default && $out !== []) {
        $out[0]['isDefault'] = true;
    }
    return $out;
}

/**
 * The value the editor prefills on a new item for this field, or null when
 * the field has none: `default_value` for the flat types, the option carrying
 * `isDefault` for an `option` field (it has no `default_value`), never for a
 * reference field (those start empty).
 *
 * @param array<string, mixed> $def
 */
function kk_cm_field_default(array $def): mixed
{
    if (in_array($def['type'] ?? '', KK_CM_REFERENCE_TYPES, strict: true)) {
        return null;
    }
    if (($def['type'] ?? '') === 'option') {
        /** @var mixed $option */
        foreach (is_array($def['options'] ?? null) ? $def['options'] : [] as $option) {
            if (is_array($option) && kk_bool($option['isDefault'] ?? false) && ($option['value'] ?? '') !== '') {
                return $option['value'];
            }
        }
        return null;
    }
    /** @var mixed $default */
    $default = $def['default_value'] ?? '';
    return $default === '' || $default === null ? null : $default;
}

/**
 * Errors in the type-specific keys of a definition. `$stored_ref` is the
 * `ref_collection` the field already had: when the input repeats it unchanged,
 * a target that has since been deleted is reported as a warning by the caller
 * instead of blocking every future edit of the field list.
 *
 * @param array<string, mixed> $def
 * @return list<string>
 */
// @mago-expect lint:cyclomatic-complexity -- one check per key
// @mago-expect lint:halstead
// @mago-expect lint:kan-defect
function kk_cm_field_extra_errors(string $type, array $def, string $label, mixed $stored_ref = null): array
{
    $errors = [];
    if (array_key_exists('kind', $def) && $def['kind'] !== 'custom') {
        $errors[] = sprintf('%s: `kind` must be `custom`.', $label);
    }
    if (array_key_exists('required', $def) && !is_bool($def['required'])) {
        $errors[] = sprintf('%s: `required` must be a boolean.', $label);
    }
    $help_error = kk_cm_label_error($def['help_text'] ?? null, field: 'help_text', required: false);
    if ($help_error !== null) {
        $errors[] = sprintf('%s: %s', $label, $help_error);
    }
    $key_error = kk_cm_label_error($def['templateKey'] ?? null, field: 'templateKey', required: false);
    if ($key_error !== null) {
        $errors[] = sprintf('%s: %s', $label, $key_error);
    }
    foreach (['character_limit', 'size_limitation'] as $limit_key) {
        if (!array_key_exists($limit_key, $def)) {
            continue;
        }
        $limit_error = kk_cm_limit_error($def[$limit_key], $limit_key, with_unit: $limit_key === 'size_limitation');
        if ($limit_error !== null) {
            $errors[] = sprintf('%s: %s', $label, $limit_error);
        }
    }
    if (
        array_key_exists('number_format', $def) && !in_array($def['number_format'], KK_CM_NUMBER_FORMATS, strict: true)
    ) {
        $errors[] = sprintf('%s: `number_format` must be one of %s.', $label, implode(', ', KK_CM_NUMBER_FORMATS));
    }
    if (array_key_exists('allows_negative_numbers', $def) && !is_bool($def['allows_negative_numbers'])) {
        $errors[] = sprintf('%s: `allows_negative_numbers` must be a boolean.', $label);
    }
    if (array_key_exists('include_time_field', $def) && !is_bool($def['include_time_field'])) {
        $errors[] = sprintf('%s: `include_time_field` must be a boolean.', $label);
    }
    if (array_key_exists('default_format', $def)) {
        $format_error = kk_cm_label_error($def['default_format'], field: 'default_format', required: true);
        if ($format_error !== null) {
            $errors[] = sprintf('%s: %s', $label, $format_error);
        }
    }
    if (array_key_exists('image_type', $def) && !in_array($def['image_type'], KK_CM_IMAGE_TYPES, strict: true)) {
        $errors[] = sprintf('%s: `image_type` must be `media-manager` or `image-url`.', $label);
    }
    if (array_key_exists('video_type', $def) && !in_array($def['video_type'], KK_CM_VIDEO_TYPES, strict: true)) {
        $errors[] = sprintf('%s: `video_type` must be `media-manager` or `video-url`.', $label);
    }
    foreach (['image_file_format', 'video_format'] as $format_key) {
        if (!array_key_exists($format_key, $def)) {
            continue;
        }
        if (!kk_cm_is_format_list($def[$format_key])) {
            $errors[] = sprintf('%s: `%s` must be a non-empty list of extensions (or `["*"]`).', $label, $format_key);
        }
    }
    if ($type === 'option') {
        $options_error = kk_cm_options_error($def['options'] ?? null);
        if ($options_error !== null) {
            $errors[] = sprintf('%s: %s', $label, $options_error);
        }
    }
    if (in_array($type, KK_CM_REFERENCE_TYPES, strict: true)) {
        /** @var mixed $given_ref */
        $given_ref = $def['ref_collection'] ?? null;
        $unchanged =
            $stored_ref !== null
            && kk_coerce_int_or_null($given_ref) !== null
            && kk_coerce_int_or_null($given_ref) === kk_coerce_int_or_null($stored_ref);
        $ref_error = $unchanged ? kk_cm_ref_collection_shape_error($given_ref) : kk_cm_ref_collection_error($given_ref);
        if ($ref_error !== null) {
            $errors[] = sprintf('%s: %s', $label, $ref_error);
        }
        if (array_key_exists('editRefCollection', $def) && !is_bool($def['editRefCollection'])) {
            $errors[] = sprintf('%s: `editRefCollection` must be a boolean.', $label);
        }
    }
    return $errors;
}

/** A plain label (title, help text, template key, option value): a string without markup / control characters. */
// @mago-expect lint:no-boolean-flag-parameter -- required-ness is the caller's rule
function kk_cm_label_error(mixed $value, string $field, bool $required): ?string
{
    if ($value === null) {
        return $required ? sprintf('`%s` is required.', $field) : null;
    }
    if (!is_string($value)) {
        return sprintf('`%s` must be a string.', $field);
    }
    if ($required && trim($value) === '') {
        return sprintf('`%s` must not be blank.', $field);
    }
    if (strlen($value) > KK_CM_LABEL_BYTES) {
        return sprintf('`%s` exceeds %d bytes.', $field, KK_CM_LABEL_BYTES);
    }
    if (
        preg_match(KK_CM_TEXT_PATTERN, $value) === 1
        || preg_match(KK_CM_TEXT_PATTERN, kk_decode_entities($value)) === 1
    ) {
        return sprintf('`%s` must not contain angle brackets or control characters.', $field);
    }
    return null;
}

// @mago-expect lint:no-boolean-flag-parameter -- size limits carry a unit, character limits do not
function kk_cm_limit_error(mixed $limit, string $key, bool $with_unit): ?string
{
    if (!is_array($limit) || kk_is_list($limit)) {
        return sprintf('`%s` must be an object `{enabled, min, max%s}`.', $key, $with_unit ? ', unit' : '');
    }
    if (array_key_exists('enabled', $limit) && !is_bool($limit['enabled'])) {
        return sprintf('`%s.enabled` must be a boolean.', $key);
    }
    $min = kk_coerce_int_or_null($limit['min'] ?? 0);
    $max = kk_coerce_int_or_null($limit['max'] ?? 10);
    if ($min === null || $max === null || $min < 0 || $max < $min) {
        return sprintf('`%s` needs integers `min` >= 0 and `max` >= `min`.', $key);
    }
    if ($with_unit && array_key_exists('unit', $limit)) {
        $unit = is_string($limit['unit']) ? strtolower($limit['unit']) : '';
        if (!in_array($unit, KK_CM_SIZE_UNITS, strict: true)) {
            return sprintf('`%s.unit` must be `kb` or `mb`.', $key);
        }
    }
    return null;
}

function kk_cm_is_format_list(mixed $value): bool
{
    if (!is_array($value) || $value === [] || !kk_is_list($value)) {
        return false;
    }
    /** @var mixed $entry */
    foreach ($value as $entry) {
        if (!is_string($entry) || $entry === '' || preg_match('/^(\*|[a-z0-9]{1,10})$/', $entry) !== 1) {
            return false;
        }
    }
    return true;
}

function kk_cm_options_error(mixed $options): ?string
{
    if (!is_array($options) || $options === [] || !kk_is_list($options)) {
        return '`options` must be a non-empty list of `{value, isDefault}`.';
    }
    $defaults = 0;
    $seen = [];
    /** @var mixed $option */
    foreach ($options as $index => $option) {
        if (!is_array($option) || kk_is_list($option)) {
            return sprintf('`options[%d]` must be an object `{value, isDefault}`.', $index);
        }
        $value_error = kk_cm_label_error(
            $option['value'] ?? null,
            sprintf('options[%d].value', $index),
            required: true,
        );
        if ($value_error !== null) {
            return $value_error;
        }
        $value = trim((string) $option['value']);
        if (isset($seen[$value])) {
            return sprintf('`options` lists the value `%s` twice.', $value);
        }
        $seen[$value] = true;
        if (array_key_exists('isDefault', $option) && !is_bool($option['isDefault'])) {
            return sprintf('`options[%d].isDefault` must be a boolean.', $index);
        }
        $defaults += kk_bool($option['isDefault'] ?? false) ? 1 : 0;
    }
    return $defaults > 1 ? 'exactly one option may carry `isDefault: true`.' : null;
}

function kk_cm_ref_collection_error(mixed $value): ?string
{
    $shape = kk_cm_ref_collection_shape_error($value);
    if ($shape !== null) {
        return $shape;
    }
    $id = kk_coerce_int_or_null($value) ?? 0;
    $post = kk_collection_post_or_error($id);
    return $post instanceof WP_Post ? null : sprintf('`ref_collection` %d is not a live collection.', $id);
}

/** The shape of `ref_collection` alone (a positive id), without asking whether that collection still exists. */
function kk_cm_ref_collection_shape_error(mixed $value): ?string
{
    $id = kk_coerce_int_or_null($value);
    if ($id === null || $id <= 0) {
        return '`ref_collection` must be the id of a Content Manager collection (kirki-list-collections); the editor refuses a reference field without a target.';
    }
    return null;
}

/**
 * The warning for a reference field kept as stored whose target collection is
 * gone: the field stays in the list (so the rest can still be edited) but no
 * value can be written for it any more.
 *
 * @param array<string, mixed> $def a completed definition
 */
function kk_cm_dead_ref_warning(string $type, array $def, string $label): ?string
{
    if (!in_array($type, KK_CM_REFERENCE_TYPES, strict: true)) {
        return null;
    }
    if (kk_cm_ref_collection_error($def['ref_collection'] ?? null) === null) {
        return null;
    }
    return sprintf(
        '%s: `ref_collection` %d no longer exists; the field was kept as stored so the rest of the list stays editable, but no value can be written for it. Remove it with `confirm_field_removal: true`, or point it at a live collection.',
        $label,
        kk_coerce_int_or_null($def['ref_collection'] ?? null) ?? 0,
    );
}

/**
 * A definition's `default_value` must be a valid value of its type (the
 * editor prefills it on every new item and the renderer prints it when the
 * stored value is empty).
 *
 * @param array<string, mixed> $def a completed definition
 */
function kk_cm_default_value_error(array $def): ?string
{
    if (!array_key_exists('default_value', $def) || $def['default_value'] === '' || $def['default_value'] === null) {
        return null;
    }
    $normalized = kk_cm_normalize_value($def, $def['default_value']);
    return $normalized['error'] === null ? null : sprintf('`default_value` %s', $normalized['error']);
}

// ---------------------------------------------------------------------------
// Values.
// ---------------------------------------------------------------------------

/**
 * Validate one value against its definition and return the shape to store:
 * meta value for every type but the reference ones, which return the list of
 * referenced item ids. `null` (clear) is accepted here; required-ness is the
 * caller's concern (it depends on create vs edit).
 *
 * @param array<string, mixed> $def a completed definition
 * @return array{error: ?string, value: mixed, empty: bool, warning?: string}
 */
function kk_cm_normalize_value(array $def, mixed $value): array
{
    $type = (string) ($def['type'] ?? '');
    if ($value === null) {
        return ['error' => null, 'value' => null, 'empty' => true];
    }
    return match ($type) {
        'text', 'email', 'phone', 'url', 'file' => kk_cm_plain_value($def, $value),
        'rich-text' => kk_cm_rich_text_value($def, $value),
        'number' => kk_cm_number_value($def, $value),
        'switch' => kk_cm_switch_value($value),
        'option' => kk_cm_option_value($def, $value),
        'date' => kk_cm_date_value($def, $value),
        'time' => kk_cm_time_value($value),
        'image', 'video' => kk_cm_media_value($def, $value),
        'gallery' => kk_cm_gallery_value($def, $value),
        'reference' => kk_cm_reference_value($def, $value, multiple: false),
        'multi-reference' => kk_cm_reference_value($def, $value, multiple: true),
        default => ['error' => sprintf('type `%s` is unknown.', $type), 'value' => null, 'empty' => true],
    };
}

/** @return array{error: ?string, value: mixed, empty: bool, warning?: string} */
function kk_cm_error(string $message): array
{
    return ['error' => $message, 'value' => null, 'empty' => true];
}

/** @return array{error: ?string, value: mixed, empty: bool, warning?: string} */
// @mago-expect lint:no-boolean-flag-parameter -- the emptiness verdict travels with the value
function kk_cm_ok(mixed $value, bool $empty): array
{
    return ['error' => null, 'value' => $value, 'empty' => $empty];
}

/**
 * @param array<string, mixed> $def
 * @return array{error: ?string, value: mixed, empty: bool, warning?: string}
 */
// @mago-expect lint:cyclomatic-complexity
function kk_cm_plain_value(array $def, mixed $value): array
{
    if (is_int($value) || is_float($value)) {
        $value = (string) $value;
    }
    if (!is_string($value)) {
        return kk_cm_error('must be a string.');
    }
    if (strlen($value) > KK_CM_TEXT_BYTES) {
        return kk_cm_error(sprintf('exceeds %d bytes.', KK_CM_TEXT_BYTES));
    }
    if (
        preg_match(KK_CM_TEXT_PATTERN, $value) === 1
        || preg_match(KK_CM_TEXT_PATTERN, kk_decode_entities($value)) === 1
    ) {
        return kk_cm_error('must not contain angle brackets or control characters (the renderer prints it as text).');
    }
    if ($value === '') {
        return kk_cm_ok('', empty: true);
    }
    $type = (string) ($def['type'] ?? '');
    if ($type === 'text') {
        $limit_error = kk_cm_length_error($def, mb_strlen($value));
        return $limit_error === null ? kk_cm_ok($value, empty: false) : kk_cm_error($limit_error);
    }
    if ($type === 'email' && preg_match(KK_CM_EMAIL_PATTERN, strtolower($value)) !== 1) {
        return kk_cm_error('is not an email address (the editor\'s rule).');
    }
    if ($type === 'phone' && preg_match(KK_CM_PHONE_PATTERN, $value) !== 1) {
        return kk_cm_error('is not a phone number the editor accepts (e.g. `+1 555 123 4567`, `555-123-4567`).');
    }
    if (in_array($type, ['url', 'file'], strict: true) && !kk_cm_is_url($value)) {
        return kk_cm_error('must be an absolute http(s) URL or a site-relative path starting with `/`.');
    }
    return kk_cm_ok($value, empty: false);
}

/** Absolute http(s) URL or a site-relative path; never a `javascript:` / `data:` scheme. */
function kk_cm_is_url(string $value): bool
{
    if (str_starts_with($value, '/') && !str_starts_with($value, '//')) {
        return true;
    }
    $scheme = strtolower((string) parse_url($value, PHP_URL_SCHEME));
    return in_array($scheme, ['http', 'https'], strict: true) && filter_var($value, FILTER_VALIDATE_URL) !== false;
}

/** @param array<string, mixed> $def */
function kk_cm_length_error(array $def, int $length): ?string
{
    $limit = is_array($def['character_limit'] ?? null) ? $def['character_limit'] : [];
    if (!kk_bool($limit['enabled'] ?? false)) {
        return null;
    }
    $min = kk_coerce_int_or_null($limit['min'] ?? 0) ?? 0;
    $max = kk_coerce_int_or_null($limit['max'] ?? 0) ?? 0;
    if ($length < $min || $length > $max) {
        return sprintf('must be %d to %d characters long (the field\'s character limit).', $min, $max);
    }
    return null;
}

/**
 * @param array<string, mixed> $def
 * @return array{error: ?string, value: mixed, empty: bool, warning?: string}
 */
function kk_cm_rich_text_value(array $def, mixed $value): array
{
    if (!is_string($value)) {
        return kk_cm_error('must be an HTML string.');
    }
    if (strlen($value) > KK_CM_RICH_TEXT_BYTES) {
        return kk_cm_error(sprintf('exceeds %d bytes.', KK_CM_RICH_TEXT_BYTES));
    }
    if (preg_match('/[\x00-\x08\x0B\x0C\x0E-\x1F]/', $value) === 1) {
        return kk_cm_error('must not contain control characters.');
    }
    if ($value === '') {
        return kk_cm_ok('', empty: true);
    }
    if (preg_match('/<\s*(script|iframe|object|embed|style)\b|\bon[a-z]+\s*=|javascript\s*:/i', $value) === 1) {
        return kk_cm_error(
            'must not carry scripts, iframes, event handlers or javascript: URLs: the renderer prints it raw.',
        );
    }
    $clean = wp_kses_post($value);
    if (wp_strip_all_tags($clean) !== wp_strip_all_tags($value)) {
        return kk_cm_error(
            'lost text to wp_kses_post (a tag the frontend would print raw was stripped with its content); send HTML wp_kses_post keeps.',
        );
    }
    $limit_error = kk_cm_length_error($def, mb_strlen(trim(wp_strip_all_tags($clean))));
    if ($limit_error !== null) {
        return kk_cm_error($limit_error);
    }
    $result = kk_cm_ok($clean, empty: false);
    if ($clean !== $value) {
        $result['warning'] = 'was stored after wp_kses_post normalised it (attributes or markup differ from the input).';
    }
    return $result;
}

/**
 * @param array<string, mixed> $def
 * @return array{error: ?string, value: mixed, empty: bool, warning?: string}
 */
function kk_cm_number_value(array $def, mixed $value): array
{
    if (is_int($value) || is_float($value)) {
        $value = (string) $value;
    }
    if (!is_string($value)) {
        return kk_cm_error('must be a number (or a numeric string, as the editor stores it).');
    }
    if ($value === '') {
        return kk_cm_ok('', empty: true);
    }
    if (!is_numeric($value)) {
        return kk_cm_error('must be a number.');
    }
    $number = (float) $value;
    if (!kk_bool($def['allows_negative_numbers'] ?? false) && $number < 0) {
        return kk_cm_error('must not be negative (the field does not allow negative numbers).');
    }
    $format = (string) ($def['number_format'] ?? 'any-format');
    $integral = floor($number) === $number;
    if ($format === 'integer' && !$integral) {
        return kk_cm_error('must be an integer (the field\'s number format).');
    }
    if ($format === 'decimal' && $integral) {
        return kk_cm_error('must be a decimal number such as 1.0 (the field\'s number format).');
    }
    if ($format === 'integer') {
        // The editor's integer input never writes `5.0` or `007`: store the integer spelling.
        $value = sprintf('%.0f', $number);
    }
    return kk_cm_ok($value, empty: false);
}

/** @return array{error: ?string, value: mixed, empty: bool, warning?: string} */
function kk_cm_switch_value(mixed $value): array
{
    if (is_bool($value)) {
        return kk_cm_ok($value ? 'on' : 'off', empty: false);
    }
    if ($value === 'on' || $value === 'off') {
        return kk_cm_ok($value, empty: false);
    }
    if ($value === '') {
        return kk_cm_ok('', empty: true);
    }
    return kk_cm_error('must be a boolean or `on` / `off`.');
}

/**
 * @param array<string, mixed> $def
 * @return array{error: ?string, value: mixed, empty: bool, warning?: string}
 */
function kk_cm_option_value(array $def, mixed $value): array
{
    if (!is_string($value)) {
        return kk_cm_error('must be one of the field\'s option values (a string).');
    }
    if ($value === '') {
        return kk_cm_ok('', empty: true);
    }
    $values = [];
    /** @var mixed $option */
    foreach (is_array($def['options'] ?? null) ? $def['options'] : [] as $option) {
        if (!is_array($option) || !is_string($option['value'] ?? null)) {
            continue;
        }
        $values[] = $option['value'];
    }
    if (!in_array($value, $values, strict: true)) {
        return kk_cm_error(sprintf('must be one of `%s`.', implode('`, `', $values)));
    }
    return kk_cm_ok($value, empty: false);
}

/**
 * @param array<string, mixed> $def
 * @return array{error: ?string, value: mixed, empty: bool, warning?: string}
 */
function kk_cm_date_value(array $def, mixed $value): array
{
    if (!is_string($value)) {
        return kk_cm_error('must be a `YYYY-MM-DD` string.');
    }
    if ($value === '') {
        return kk_cm_ok('', empty: true);
    }
    $with_time = kk_bool($def['include_time_field'] ?? false);
    $format = $with_time ? 'Y-m-d H:i' : 'Y-m-d';
    $parsed = \DateTimeImmutable::createFromFormat('!' . $format, $value);
    if ($parsed === false || $parsed->format($format) !== $value) {
        return kk_cm_error(sprintf(
            'must be a `%s` date%s.',
            $with_time ? 'YYYY-MM-DD HH:MM' : 'YYYY-MM-DD',
            $with_time ? ' (the field includes a time)' : '',
        ));
    }
    return kk_cm_ok($value, empty: false);
}

/** @return array{error: ?string, value: mixed, empty: bool, warning?: string} */
function kk_cm_time_value(mixed $value): array
{
    if (is_string($value)) {
        if ($value === '') {
            return kk_cm_ok('', empty: true);
        }
        $m = [];
        if (preg_match('/^(\d{1,2}:\d{2})\s*(am|pm)$/i', trim($value), $m) === 1) {
            $value = ['value' => $m[1], 'unit' => strtolower($m[2])];
        }
    }
    if (!is_array($value) || !is_string($value['value'] ?? null) || !is_string($value['unit'] ?? null)) {
        return kk_cm_error('must be `{value: "HH:MM", unit: "am"|"pm"}` (or the string `"HH:MM am"`).');
    }
    $unit = strtolower($value['unit']);
    $hhmm = strlen($value['value']) === 4 ? '0' . $value['value'] : $value['value'];
    if (!in_array($unit, ['am', 'pm'], strict: true) || preg_match(KK_CM_TIME_PATTERN, $hhmm) !== 1) {
        return kk_cm_error(
            'must be `{value: "HH:MM", unit: "am"|"pm"}` with HH 01–12 and MM 00–59: the editor\'s clock is a 12-hour one, so `20:00` is `08:00 pm` and midnight is `12:00 am`.',
        );
    }
    return kk_cm_ok(['value' => $hhmm, 'unit' => $unit], empty: false);
}

/**
 * A media value (image / video): `{id}` of a live attachment, completed with
 * the keys the editor stores (`name`, `url`, `alt`, `category`, `file_size`,
 * `file_extension`); or `{url}` alone when the field takes URLs
 * (`image_type` / `video_type` = `image-url` / `video-url`).
 *
 * @param array<string, mixed> $def
 * @return array{error: ?string, value: mixed, empty: bool, warning?: string}
 */
// @mago-expect lint:cyclomatic-complexity
// @mago-expect lint:halstead
function kk_cm_media_value(array $def, mixed $value): array
{
    if ($value === '') {
        return kk_cm_ok('', empty: true);
    }
    if (!is_array($value) || kk_is_list($value)) {
        return kk_cm_error('must be `{id: <attachment id>}` (or `{url}` for a URL-type field).');
    }
    $type = (string) ($def['type'] ?? 'image');
    $source = (string) ($def[$type === 'video' ? 'video_type' : 'image_type'] ?? 'media-manager');
    $id = kk_coerce_int_or_null($value['id'] ?? null);
    if ($id === null) {
        if (!str_ends_with($source, '-url')) {
            return kk_cm_error(sprintf(
                'needs `id`: the attachment id of a media-library %s (the field takes media-library files, not URLs).',
                $type,
            ));
        }
        /** @var mixed $url */
        $url = $value['url'] ?? null;
        if (!is_string($url) || !kk_cm_is_url($url)) {
            return kk_cm_error('needs `url`: an absolute http(s) URL (the field takes URLs).');
        }
        return kk_cm_ok(['url' => $url], empty: false);
    }
    if (str_ends_with($source, '-url')) {
        // The field's editor input is a URL box: it can only ever store `{url}`.
        return kk_cm_error(sprintf(
            'must be `{url}`: the field takes %s URLs (`%s`), so an attachment object is a shape its own editor input can never produce.',
            $type,
            $source,
        ));
    }
    // @mago-expect analysis:mixed-assignment
    $attachment = get_post($id);
    if (!$attachment instanceof WP_Post || $attachment->post_type !== 'attachment') {
        return kk_cm_error(sprintf('`id` %d is not a media-library attachment.', $id));
    }
    $mime = $attachment->post_mime_type;
    $mime_parts = explode('/', $mime, limit: 2);
    $category = $mime_parts[0] !== '' ? $mime_parts[0] : 'file';
    $wanted = $type === 'video' ? 'video' : 'image';
    if ($category !== $wanted) {
        return kk_cm_error(sprintf(
            '`id` %d is a %s, not %s (%s).',
            $id,
            $category,
            $wanted === 'image' ? 'an image' : 'a video',
            $mime,
        ));
    }
    $path = (string) get_attached_file($id);
    $extension = strtolower(pathinfo($path, PATHINFO_EXTENSION));
    $format_key = $type === 'video' ? 'video_format' : 'image_file_format';
    $formats = is_array($def[$format_key] ?? null)
        ? array_values(array_filter($def[$format_key], callback: 'is_string'))
        : ['*'];
    if (!in_array('*', $formats, strict: true) && !in_array($extension, $formats, strict: true)) {
        return kk_cm_error(sprintf(
            '`id` %d is a `%s` file; the field accepts %s.',
            $id,
            $extension,
            implode(', ', array_map('strval', $formats)),
        ));
    }
    $bytes = is_file($path) ? (int) filesize($path) : 0;
    $size_error = kk_cm_size_error($def, $bytes);
    if ($size_error !== null) {
        return kk_cm_error($size_error);
    }
    $given_url = is_string($value['url'] ?? null) ? $value['url'] : null;
    $url = (string) wp_get_attachment_url($id);
    if ($given_url !== null && $given_url !== $url) {
        return kk_cm_error(sprintf('`url` does not match attachment %d (%s).', $id, $url));
    }
    $alt = (string) get_post_meta($id, key: '_wp_attachment_image_alt', single: true);
    return kk_cm_ok([
        'id' => $id,
        'name' => $attachment->post_name,
        'url' => $url,
        'alt' => $alt !== '' ? $alt : basename($path),
        'category' => $category,
        'file_size' => kk_cm_file_size($bytes),
        'file_extension' => $extension,
    ], empty: false);
}

/** The editor's `file_size` label (`55 KB`, `1.2 MB`). */
function kk_cm_file_size(int $bytes): string
{
    if ($bytes >= 1_048_576) {
        $mb = number_format($bytes / 1_048_576, decimals: 2, decimal_separator: '.', thousands_separator: '');
        return sprintf('%s MB', rtrim(rtrim($mb, characters: '0'), characters: '.'));
    }
    if ($bytes >= 1024) {
        return sprintf('%d KB', (int) round($bytes / 1024));
    }
    return sprintf('%d B', $bytes);
}

/** @param array<string, mixed> $def */
function kk_cm_size_error(array $def, int $bytes): ?string
{
    $limit = is_array($def['size_limitation'] ?? null) ? $def['size_limitation'] : [];
    if (!kk_bool($limit['enabled'] ?? false)) {
        return null;
    }
    $unit = strtolower((string) ($limit['unit'] ?? 'kb'));
    $divisor = $unit === 'mb' ? 1_048_576 : 1024;
    $size = $bytes / $divisor;
    $min = kk_coerce_int_or_null($limit['min'] ?? 0) ?? 0;
    $max = kk_coerce_int_or_null($limit['max'] ?? 0) ?? 0;
    if ($size < $min || $size > $max) {
        return sprintf(
            'the file weighs %s, outside the field\'s %d–%d %s limit.',
            kk_cm_file_size($bytes),
            $min,
            $max,
            strtoupper($unit),
        );
    }
    return null;
}

/**
 * @param array<string, mixed> $def
 * @return array{error: ?string, value: mixed, empty: bool, warning?: string}
 */
function kk_cm_gallery_value(array $def, mixed $value): array
{
    if ($value === '' || $value === []) {
        return kk_cm_ok([], empty: true);
    }
    if (!is_array($value) || !kk_is_list($value)) {
        return kk_cm_error('must be a list of `{id: <attachment id>}`.');
    }
    if (count($value) > KK_CM_LIST_MAX) {
        return kk_cm_error(sprintf('lists more than %d images.', KK_CM_LIST_MAX));
    }
    $image_def = ['type' => 'image'] + $def;
    $out = [];
    /** @var mixed $entry */
    foreach ($value as $index => $entry) {
        $one = kk_cm_media_value($image_def, $entry);
        if ($one['error'] !== null) {
            return kk_cm_error(sprintf('[%d] %s', $index, $one['error']));
        }
        $out[] = $one['value'];
    }
    return kk_cm_ok($out, empty: false);
}

/**
 * Reference values: item ids (also `{value: id}` objects as kirki-get-collection-item
 * returns them), every id a live item of the field's target collection.
 *
 * @param array<string, mixed> $def
 * @return array{error: ?string, value: mixed, empty: bool, warning?: string}
 */
// @mago-expect lint:cyclomatic-complexity
// @mago-expect lint:no-boolean-flag-parameter -- one rule set for both reference types
function kk_cm_reference_value(array $def, mixed $value, bool $multiple): array
{
    if ($value === '' || $value === []) {
        return kk_cm_ok([], empty: true);
    }
    /** @var mixed $entries */
    if (!$multiple && is_array($value) && kk_is_list($value)) {
        return kk_cm_error('must be one item id (the field is a single reference).');
    }
    // @mago-expect analysis:mixed-assignment
    $entries = $multiple ? $value : [$value];
    if (!is_array($entries) || !kk_is_list($entries)) {
        return kk_cm_error($multiple ? 'must be a list of item ids.' : 'must be one item id.');
    }
    if (count($entries) > KK_CM_LIST_MAX) {
        return kk_cm_error(sprintf('lists more than %d items.', KK_CM_LIST_MAX));
    }
    $target = kk_coerce_int_or_null($def['ref_collection'] ?? null) ?? 0;
    $ids = [];
    /** @var mixed $entry */
    foreach ($entries as $entry) {
        $id = kk_coerce_int_or_null(is_array($entry) ? $entry['value'] ?? null : $entry);
        if ($id === null || $id <= 0) {
            return kk_cm_error('must be item id(s) (integers).');
        }
        $item = kk_item_post_or_error($id);
        if (!$item instanceof WP_Post || (int) $item->post_parent !== $target) {
            return kk_cm_error(sprintf('%d is not a live item of collection %d (the field\'s target).', $id, $target));
        }
        $ids[$id] = true;
    }
    return kk_cm_ok(array_keys($ids), empty: false);
}

// ---------------------------------------------------------------------------
// Reading an item's values.
// ---------------------------------------------------------------------------

/**
 * The stored field definitions of a collection (fresh read), completed with
 * the editor's defaults so every consumer sees the full shape.
 *
 * @return list<array<string, mixed>>
 */
function kk_cm_stored_defs(int $collection_id): array
{
    /** @var mixed $raw */
    $raw = kk_meta($collection_id, kk_meta_cm_fields());
    $out = [];
    /** @var mixed $def */
    foreach (is_array($raw) ? $raw : [] as $def) {
        if (!is_array($def) || !is_string($def['id'] ?? null) || !is_string($def['type'] ?? null)) {
            continue;
        }
        $type = in_array($def['type'], KK_CM_FIELD_TYPES, strict: true) ? $def['type'] : 'text';
        /** @var array<string, mixed> $merged */
        $merged = array_replace(kk_cm_field_defaults()[$type], $def);
        $out[] = $merged;
    }
    return $out;
}

/**
 * An item's values keyed by field id, as Kirki's `CollectionItemResource`
 * builds them: reference fields from the reference rows (`[{value, title}]`,
 * plus `status`), the others from the meta rows, the field's `default_value`
 * when no row exists (listed in `defaults_applied`).
 *
 * @param list<array<string, mixed>> $defs
 * @return array{fields: array<string, mixed>, defaults_applied: list<string>}
 */
function kk_cm_item_values(WP_Post $item, array $defs): array
{
    $collection_id = (int) $item->post_parent;
    $rows = kk_reference_rows(['post_id' => $item->ID]);
    $fields = [];
    $defaults = [];
    foreach ($defs as $def) {
        $id = (string) $def['id'];
        $key = kk_field_meta_key($collection_id, $id);
        if (in_array($def['type'], KK_CM_REFERENCE_TYPES, strict: true)) {
            $refs = [];
            foreach ($rows as $row) {
                if ($row['field_meta_key'] !== $key) {
                    continue;
                }
                // @mago-expect analysis:mixed-assignment
                $target = get_post($row['ref_post_id']);
                $refs[] = [
                    'value' => $row['ref_post_id'],
                    'title' => $target instanceof WP_Post ? $target->post_title : '',
                    'status' => $target instanceof WP_Post ? $target->post_status : 'missing',
                ];
            }
            $fields[$id] = $refs;
            continue;
        }
        if (!metadata_exists('post', $item->ID, $key)) {
            /** @var mixed $default */
            $default = $def['default_value'] ?? '';
            $fields[$id] = $default;
            $defaults[] = $id;
            continue;
        }
        /** @var mixed $stored */
        $stored = kk_meta($item->ID, $key);
        $fields[$id] = $stored;
    }
    return ['fields' => $fields, 'defaults_applied' => $defaults];
}

/** A short printable form of a value for messages. */
function kk_cm_value_label(mixed $value): string
{
    if (is_scalar($value)) {
        return (string) $value;
    }
    $json = wp_json_encode($value);
    return is_string($json) ? $json : '';
}

/**
 * Fields whose stored value the renderer replaces with the definition's
 * default because it is falsy (`get_post_dynamic_content`: `!$content`):
 * `"0"`, an empty string / list, null. A switch stored as `"off"` is NOT one
 * of them: `"off"` is a non-empty string, so PHP reads it as true and the
 * renderer prints it as stored.
 *
 * @param list<array<string, mixed>> $defs
 * @param array<string, mixed> $values normalised values keyed by field id
 * @return list<string>
 */
function kk_cm_fallback_warnings(array $defs, array $values): array
{
    $warnings = [];
    foreach ($defs as $def) {
        $id = (string) $def['id'];
        if (!array_key_exists($id, $values) || in_array($def['type'], KK_CM_REFERENCE_TYPES, strict: true)) {
            continue;
        }
        /** @var mixed $value */
        $value = $values[$id];
        /** @var mixed $default */
        $default = $def['default_value'] ?? '';
        $falsy = $value === '' || $value === '0' || $value === [] || $value === null;
        if ($falsy && $default !== '' && $default !== null && $default !== $value) {
            $warnings[] = sprintf(
                'Field `%s` (%s): the stored value `%s` is empty / falsy, so the frontend prints the field\'s default `%s` instead (Kirki falls back on any falsy value).',
                $id,
                (string) $def['title'],
                kk_cm_value_label($value),
                kk_cm_value_label($default),
            );
        }
    }
    return $warnings;
}
