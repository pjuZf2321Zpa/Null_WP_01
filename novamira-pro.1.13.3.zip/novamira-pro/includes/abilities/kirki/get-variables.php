<?php

// SPDX-FileCopyrightText: 2026 Ovation S.r.l. <dev@novamira.ai>
// SPDX-License-Identifier: AGPL-3.0-or-later

declare(strict_types=1);

namespace Novamira\Pro\Abilities\Kirki;

/**
 * Ability: Read Kirki's global design variables (colors, numbers, text styles,
 * font families) the way the renderer resolves them.
 */

if (!defined('ABSPATH')) {
    exit();
}

wp_register_ability('novamira/kirki-get-variables', [
    'label' => __('Get Kirki Variables', domain: 'novamira-pro'),
    'description' => __(
        'Returns Kirki\'s global design variables grouped as the editor shows them: `color`, `size` (Numbers), `text-style`, `font-family`. Each group lists its modes (e.g. `default`) and variables `{id, title, type, values}` where `values` is keyed by mode and already rendered as CSS text (`#000000`, `12px`, a font name). Color, size and font-family variables are emitted by Kirki as CSS custom properties on `:root`, so `css` gives the `var(--<id>)` expression to use inside style blocks; text-style variables apply through a node property instead (`apply` explains how) and are returned as-is under `raw`. `source` says whether the site has saved variables or Kirki\'s empty defaults are in effect. A variable whose stored value would break the public frontend (a `size` that is not `{value, unit}` or a non-string `font-family` make Kirki throw while printing `:root`; an array `color` prints `Array`) is flagged with `broken`, gets `css: null` and an entry in `issues`; malformed variable sections are left out and counted in `issues`. Pass `group` to fetch one group, `include_raw` to get the stored value objects for every variable.',
        domain: 'novamira-pro',
    ),
    'category' => 'kirki',
    'input_schema' => [
        'type' => 'object',
        'default' => [],
        'properties' => [
            'group' => [
                'type' => 'string',
                'enum' => ['color', 'size', 'text-style', 'font-family'],
                'description' => 'Return only this group. Omit for all four.',
            ],
            'include_raw' => [
                'type' => 'boolean',
                'description' => 'Also return the stored `value` object of every variable (mode => raw value). Default false.',
                'default' => false,
            ],
        ],
        'additionalProperties' => false,
    ],
    'output_schema' => [
        'type' => 'object',
        'properties' => [
            'global_data_post_id' => ['type' => ['integer', 'null']],
            'source' => [
                'type' => 'string',
                'enum' => ['saved', 'defaults'],
                'description' => '`saved` when the global data holds variables, `defaults` when Kirki falls back to its empty groups.',
            ],
            'groups' => ['type' => 'array', 'items' => ['type' => 'object']],
            'total_variables' => ['type' => 'integer'],
            'issues' => ['type' => 'array', 'items' => ['type' => 'string']],
        ],
        'required' => ['global_data_post_id', 'source', 'groups', 'total_variables', 'issues'],
        'additionalProperties' => false,
    ],
    'execute_callback' => 'Novamira\\Pro\\Abilities\\Kirki\\kirki_get_variables',
    'permission_callback' => 'novamira_permission_callback',
    'meta' => [
        'show_in_rest' => true,
        'mcp' => ['public' => true],
        'annotations' => [
            'instructions' => 'Read this before writing CSS in style blocks so colors, spacing and fonts reuse the site\'s tokens: write `color: var(--k-xxxxxxxx)` rather than a literal. Variables are global (one set per site), not per page. A page selects a mode through its `kirki_variable_mode` postmeta and an element through `properties.variableMode`; a variable with no value for the selected mode is NOT emitted there (no fallback to `default`). A font-family value is only a name: the frontend loads webfonts from Kirki\'s site-wide custom fonts (`kirki_user_custom_fonts`) alone, so use a font registered there or a system font. Never write the `kirki_user_saved_data` postmeta by hand: it also holds editor UI state (global colors, shadows).',
            'readonly' => true,
            'destructive' => false,
            'idempotent' => true,
        ],
    ],
]);

/**
 * @param array{group?: string, include_raw?: mixed} $input
 * @return array<string, mixed>
 */
// @mago-expect lint:cyclomatic-complexity -- source resolution, normaliser fallback, group filter: flat guards
// @mago-expect lint:halstead
// @mago-expect lint:kan-defect
function kirki_get_variables(array $input): array
{
    kk_begin();
    $only = $input['group'] ?? null;
    $include_raw = kk_bool($input['include_raw'] ?? false);
    $issues = [];
    $post_issue = kk_global_data_post_issue();
    if ($post_issue !== null) {
        $issues[] = $post_issue;
    }

    /** @var mixed $saved */
    $saved = kk_global_data(kk_meta_global_saved_data());
    if ($saved !== null && !is_array($saved)) {
        $issues[] = __(
            'The stored global data is not an array; Kirki will fall back to its default (empty) groups.',
            domain: 'novamira-pro',
        );
    }
    /** @var array<string, mixed> $saved_array */
    $saved_array = is_array($saved) ? $saved : [];
    // Feed Kirki's normaliser only what it can walk without warnings: a string
    // `data`, or a section whose `modes` / `variables` are not arrays, makes it
    // emit PHP warnings before falling back; such sections are dropped here
    // and reported.
    $dropped = 0;
    $fed = kk_has_saved_variables($saved_array) ? kk_walkable_variable_data($saved_array, $dropped) : [];
    if ($dropped > 0) {
        $issues[] = sprintf(
            /* translators: %d: number of sections */
            __(
                '%d stored variable section(s) are malformed (modes / variables that are not lists); Kirki warns on them and ignores them, so they are left out here.',
                domain: 'novamira-pro',
            ),
            $dropped,
        );
    }
    $source = kk_has_saved_variables($saved_array) ? 'saved' : 'defaults';
    $normalized = kk_variable_data($fed);
    if ($normalized instanceof \Throwable) {
        $issues[] = sprintf(
            /* translators: %s: exception class */
            __(
                'Kirki\'s variable normaliser threw %s on the stored variables (legacy duplicate ids, or a changed Kirki API); the frontend would fail the same way. Showing the defaults.',
                domain: 'novamira-pro',
            ),
            get_class($normalized),
        );
        $normalized = kk_variable_data([]);
        $source = 'defaults';
    }

    $groups = [];
    $total = 0;
    /** @var mixed $group */
    foreach (is_array($normalized) ? $normalized : [] as $group) {
        if (!is_array($group)) {
            continue;
        }
        /** @var array<string, mixed> $group */
        $row = kk_variable_group_row($group, $include_raw);
        if ($only !== null && $row['key'] !== $only) {
            continue;
        }
        $total += count($row['variables']);
        foreach ($row['variables'] as $variable) {
            if (!isset($variable['broken']) || !is_string($variable['broken'])) {
                continue;
            }
            $issues[] = sprintf(
                'Variable `%s`: %s',
                kk_truncate((string) $variable['id'], max: 64),
                $variable['broken'],
            );
        }
        $groups[] = $row;
    }
    if ($normalized === [] && $source === 'saved') {
        $source = 'defaults';
    }
    $ids = [];
    foreach ($groups as $group_row) {
        foreach ($group_row['variables'] as $variable) {
            $ids[] = (string) $variable['id'];
        }
    }
    $duplicates = array_keys(array_filter(array_count_values($ids), static fn(int $n): bool => $n > 1));
    if ($duplicates !== []) {
        $issues[] = sprintf(
            /* translators: %s: variable ids */
            __(
                'Variable id(s) used more than once: %s (Kirki emits the last one; the editor shows both).',
                domain: 'novamira-pro',
            ),
            implode(', ', array_map(static fn(string $id): string => kk_truncate($id, max: 40), $duplicates)),
        );
    }

    return [
        'global_data_post_id' => kk_global_data_post_id(),
        'source' => $source,
        'groups' => $groups,
        'total_variables' => $total,
        'issues' => $issues,
    ];
}

/**
 * Same test `GlobalDataManager::get_variable_data()` applies before choosing
 * between the saved groups and its initial (empty) groups.
 *
 * @param array<string, mixed> $saved
 */
function kk_has_saved_variables(array $saved): bool
{
    /** @var mixed $variable_data */
    $variable_data = $saved['variableData'] ?? null;
    if (!is_array($variable_data)) {
        return false;
    }
    return is_array($variable_data['data'] ?? null) && $variable_data['data'] !== [];
}

/**
 * The saved data with every `variableData.data` section Kirki's normaliser
 * cannot foreach over removed (`modes` / `variables` must be arrays when set).
 *
 * @param array<string, mixed> $saved
 * @return array<string, mixed>
 */
function kk_walkable_variable_data(array $saved, int &$dropped): array
{
    /** @var array<string, mixed> $variable_data */
    $variable_data = is_array($saved['variableData'] ?? null) ? $saved['variableData'] : [];
    $sections = [];
    /** @var mixed $section */
    foreach (is_array($variable_data['data'] ?? null) ? $variable_data['data'] : [] as $section) {
        $walkable =
            is_array($section)
            && (!isset($section['modes']) || is_array($section['modes']))
            && (!isset($section['variables']) || is_array($section['variables']));
        if (!$walkable) {
            ++$dropped;
            continue;
        }
        if (!is_string($section['key'] ?? null)) {
            // The normaliser sorts sections by `$section['key']` without isset (a
            // warning with two or more sections); legacy un-keyed sections stay, keyed ''.
            $section['key'] = '';
        }
        $sections[] = $section;
    }
    $variable_data['data'] = $sections;
    $saved['variableData'] = $variable_data;
    return $saved;
}

/**
 * Normalised + sorted variable groups, produced by Kirki's own
 * `GlobalDataManager::get_variable_data()` fed with the raw saved data (that
 * path performs no writes; the manager's `get()` would create the global post).
 *
 * Returns the Throwable when Kirki's normaliser fails on the stored data.
 *
 * @param array<string, mixed> $saved
 * @return array<array-key, mixed>|\Throwable
 */
function kk_variable_data(array $saved): array|\Throwable
{
    if (!class_exists('Kirki\App\Managers\GlobalDataManager')) {
        return [];
    }
    $manager = new \Kirki\App\Managers\GlobalDataManager();
    try {
        /** @var mixed $data */
        $data = $manager->get_variable_data($saved);
    } catch (\Throwable $e) {
        return $e;
    }
    if (!is_array($data) || !is_array($data['data'] ?? null)) {
        return [];
    }
    return $data['data'];
}

/** Variable types Kirki's renderer turns into CSS (`Preview::generateSingleVariableModeCssCode`). */
const KK_VARIABLE_TYPES = ['color', 'size', 'font-family', 'text-style'];

/**
 * One group row: `{key, title, modes: [{key, title}], variables: [...]}`.
 *
 * @param array<string, mixed> $group
 * @return array{key: string, title: string, modes: list<array{key: string, title: string}>, variables: list<array<string, mixed>>}
 */
// @mago-expect lint:no-boolean-flag-parameter -- include_raw is the ability input passed through
function kk_variable_group_row(array $group, bool $include_raw): array
{
    $key = isset($group['key']) && is_string($group['key']) ? $group['key'] : '';
    $variables = [];
    /** @var mixed $variable */
    foreach (is_array($group['variables'] ?? null) ? $group['variables'] : [] as $variable) {
        if (!is_array($variable) || !isset($variable['id']) || !is_string($variable['id'])) {
            continue;
        }
        /** @var array<string, mixed> $variable */
        $variables[] = kk_variable_row($variable, $key, $include_raw);
    }
    return [
        'key' => $key,
        'title' => isset($group['title']) && is_string($group['title']) ? $group['title'] : $key,
        'modes' => kk_variable_modes($group),
        'variables' => $variables,
    ];
}

/**
 * `[{key, title}]` modes of one group.
 *
 * @param array<string, mixed> $group
 * @return list<array{key: string, title: string}>
 */
function kk_variable_modes(array $group): array
{
    $modes = [];
    /** @var mixed $mode */
    foreach (is_array($group['modes'] ?? null) ? $group['modes'] : [] as $mode) {
        if (!is_array($mode) || !isset($mode['key']) || !is_string($mode['key'])) {
            continue;
        }
        $modes[] = [
            'key' => $mode['key'],
            'title' => isset($mode['title']) && is_string($mode['title']) ? $mode['title'] : $mode['key'],
        ];
    }
    return $modes;
}

/**
 * One variable row. Values are rendered exactly as
 * `Preview::generateSingleVariableModeCssCode()` emits them.
 *
 * @param array<string, mixed> $variable
 * @return array<string, mixed>
 */
// @mago-expect lint:no-boolean-flag-parameter -- include_raw is the ability input passed through
// @mago-expect lint:cyclomatic-complexity -- one branch per variable type
// @mago-expect lint:halstead
function kk_variable_row(array $variable, string $group_key, bool $include_raw): array
{
    $id = is_string($variable['id']) ? $variable['id'] : '';
    /** @var mixed $raw_type */
    $raw_type = $variable['type'] ?? null;
    $type = is_string($raw_type) ? $raw_type : '';
    /** @var mixed $raw_values */
    $raw_values = $variable['value'] ?? [];
    $values = [];
    $broken = null;
    if (is_array($raw_values) && $type !== 'text-style') {
        /** @var mixed $value */
        foreach ($raw_values as $mode => $value) {
            $problem = kk_variable_value_problem($type, $value);
            if ($problem !== null) {
                $broken ??= sprintf('mode `%s` %s', kk_truncate((string) $mode, max: 32), $problem);
                continue;
            }
            $css = kk_variable_css_value($type, $value);
            if ($css === null) {
                continue;
            }
            $values[(string) $mode] = $css;
        }
    }
    $row = [
        'id' => kk_truncate($id, max: 64),
        'title' => kk_truncate(
            isset($variable['title']) && is_string($variable['title']) ? $variable['title'] : $id,
            max: 120,
        ),
        'type' => kk_truncate($type, max: 32),
        'values' => $values,
    ];
    if (preg_match(KK_CLASS_TOKEN_PATTERN, $id) !== 1) {
        // Editor converters generate UUID ids that start with a digit: `--3fa8…` is a valid custom property.
        $broken ??= 'its id is not a plain token (letters, digits, `-`, `_`), so `var(--id)` cannot be written into CSS safely.';
    }
    if ($broken !== null) {
        $row['broken'] = $broken;
    }
    if (!in_array($type, KK_VARIABLE_TYPES, strict: true)) {
        // The renderer emits nothing for a variable without one of its four types.
        $row['css'] = null;
        $row['note'] = sprintf(
            'Kirki emits no CSS for this variable: `type` is `%s` (expected one of %s); in group `%s`.',
            $type,
            implode(', ', KK_VARIABLE_TYPES),
            $group_key,
        );
        $row['raw'] = $raw_values;
        return $row;
    }
    if ($type === 'text-style') {
        $row['apply'] =
            'Set `properties.textStyleId` = id on the text element; Kirki emits the rules under `[data-text_style="'
            . $id
            . '"]`.';
        $row['raw'] = $raw_values;
        return $row;
    }
    $row['css'] = $values === [] || $broken !== null ? null : 'var(--' . $id . ')';
    if ($values === [] && $broken === null) {
        $row['note'] = 'No mode holds a value (all modes unset), so Kirki emits no custom property for this variable.';
    }
    if ($include_raw || $values === []) {
        $row['raw'] = $raw_values;
    }
    return $row;
}

/**
 * Why `Preview::generateSingleVariableModeCssCode()` would break on one stored
 * mode value: a `size` that is not `{value, unit}` and a
 * `font-family` that is not a string throw a TypeError on the public frontend;
 * a `color` / `size` array prints `Array` with a PHP warning. Null when the
 * value renders.
 */
function kk_variable_value_problem(string $type, mixed $value): ?string
{
    if ($value === null) {
        return null;
    }
    if ($type === 'size') {
        if (!is_array($value)) {
            return 'is not a `{value, unit}` object: the frontend throws a TypeError while printing `:root`.';
        }
        if (!is_scalar($value['value'] ?? null)) {
            return 'lacks a scalar `value`: the frontend prints an invalid value into `:root` with a PHP warning.';
        }
        if (!array_key_exists('unit', $value)) {
            // Prints the bare number (valid for `0` / unitless values) but with a PHP warning on the public page.
            return 'has no `unit` key: the frontend prints the bare value with a PHP warning ("Undefined array key").';
        }
        if ($value['unit'] !== null && !is_scalar($value['unit'])) {
            return 'has a non-scalar `unit`: the frontend prints `Array` into `:root` with a PHP warning.';
        }
        return null;
    }
    if ($type === 'font-family') {
        return is_scalar($value) ? null : 'is not a string: the frontend throws a TypeError while printing `:root`.';
    }
    if ($type === 'color') {
        return is_scalar($value)
            ? null
            : 'is not a string: the frontend prints `Array` into `:root` with a PHP warning.';
    }
    return null;
}

/**
 * Render one stored mode value as the CSS text Kirki writes into `--<id>`.
 */
function kk_variable_css_value(string $type, mixed $value): ?string
{
    if ($type === 'size') {
        if (!is_array($value) || !isset($value['value'])) {
            return null;
        }
        /** @var mixed $unit */
        $unit = $value['unit'] ?? '';
        /** @var mixed $number */
        $number = $value['value'];
        return (is_scalar($number) ? (string) $number : '') . (is_string($unit) ? $unit : '');
    }
    if ($type === 'font-family') {
        if (!is_scalar($value)) {
            return null;
        }
        $value = (string) $value;
        $first = $value === '' ? '' : $value[0];
        return $first === '"' || $first === "'" ? $value : '"' . $value . '"';
    }
    return is_scalar($value) ? (string) $value : null;
}
