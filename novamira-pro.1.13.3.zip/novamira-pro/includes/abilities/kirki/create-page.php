<?php

// SPDX-FileCopyrightText: 2026 Ovation S.r.l. <dev@novamira.ai>
// SPDX-License-Identifier: AGPL-3.0-or-later

declare(strict_types=1);

namespace Novamira\Pro\Abilities\Kirki;

use Kirki\App\DTO\Page\PagePayloadDTO;
use Kirki\App\Services\PageService;
use Kirki\App\Supports\PageUrl;
use WP_Error;

/**
 * Ability: Create a Kirki-owned page, post, template or utility page with an
 * empty canvas (root → body), the way the Kirki dashboard does.
 */

if (!defined('ABSPATH')) {
    exit();
}

wp_register_ability('novamira/kirki-create-page', [
    'label' => __('Create Kirki Page', domain: 'novamira-pro'),
    'description' => __(
        'Creates a new post owned by the Kirki editor through Kirki\'s own page service — the same code path as the dashboard "New Page": sets the editor-mode marker, the Kirki full-canvas page template for pages, the utility template and rewrite rules for utility pages, and template conditions — then seeds the empty canvas (`root` → `body` with the body\'s flex style block) so the post opens in the editor and renders on the frontend. Utility pages keep the pre-built template Kirki imports for them (login form, 404 layout, …; `blocks_count` tells how many nodes). `kind` selects page, post, template (`kirki_template`, pass `conditions`) or utility (`kirki_utility`, pass `utility_type`: 404, login, sign_up, forgot_password, reset_password, retrive_username — one per site). The title is sanitised like Kirki\'s own request (tags and control characters stripped; longer than 200 characters is refused). Publishing a utility page (every type but 404, which gets no rule) registers `^<slug>$` at the TOP of the rewrite rules: the call is refused (`kirki_slug_collision`) when a published post of any type already uses that slug, and the login / sign-up / password kinds also redirect wp-login.php to the utility page once published. Template conditions are checked against live data (viewable post type, existing post of that type for `single`, existing term for a taxonomy). Utility pages need pretty permalinks to be published (`kirki_permalinks_required`), and importing their template also merges the template\'s viewports and custom fonts into the site-wide global data (Kirki\'s importer). Every created post gets Kirki\'s staging ledger seeded as version 1 published, so the editor opens it without running its legacy style migration. Returns the id, permalink and editor URL. Popups are not created here.',
        domain: 'novamira-pro',
    ),
    'category' => 'kirki',
    'input_schema' => [
        'type' => 'object',
        'properties' => [
            'title' => ['type' => 'string', 'description' => 'Post title. Also accepted as `post_title`.'],
            'post_title' => ['type' => 'string', 'description' => 'WordPress-native alias of `title`.'],
            'kind' => [
                'type' => 'string',
                'enum' => ['page', 'post', 'template', 'utility'],
                'description' => 'What to create. Default `page`.',
                'default' => 'page',
            ],
            'status' => [
                'type' => 'string',
                'enum' => ['draft', 'publish'],
                'description' => 'Post status. Default `draft` (what the dashboard creates). Also accepted as `post_status`.',
                'default' => 'draft',
            ],
            'post_status' => [
                'type' => 'string',
                'enum' => ['draft', 'publish'],
                'description' => 'WordPress-native alias of `status`.',
            ],
            'conditions' => [
                'type' => 'array',
                'items' => ['type' => 'object'],
                'description' => 'Template display conditions (kind=template), evaluated in order: `{from: post|term|user, type: "*"|post|user, post_type, where: "*"|single|<taxonomy>|role, to: "*"|<post id (integer)>|<term id or slug>|<role>, visibility: show|hide}`. A `single` target must be an integer post id (Kirki compares it strictly). Example — every single post: `[{"from":"post","type":"post","post_type":"post","where":"*","to":"*","visibility":"show"}]`; author pages of editors: `[{"from":"user","type":"user","where":"role","to":"editor","visibility":"show"}]`.',
            ],
            'utility_type' => [
                'type' => 'string',
                'enum' => ['404', 'login', 'sign_up', 'forgot_password', 'reset_password', 'retrive_username'],
                'description' => 'Required when kind=utility. Kirki allows one utility page per type.',
            ],
        ],
        'required' => [],
        'additionalProperties' => false,
    ],
    'output_schema' => [
        'type' => 'object',
        'properties' => [
            'id' => ['type' => 'integer'],
            'kind' => ['type' => 'string'],
            'post_type' => ['type' => 'string'],
            'status' => ['type' => 'string'],
            'title' => ['type' => 'string'],
            'slug' => ['type' => 'string'],
            'permalink' => ['type' => 'string'],
            'editor_url' => ['type' => 'string', 'description' => 'URL that opens the post in the Kirki editor.'],
            'root_id' => ['type' => 'string'],
            'body_id' => [
                'type' => 'string',
                'description' => 'Id of the `body` node — the parent to add sections to.',
            ],
            'blocks_count' => [
                'type' => 'integer',
                'description' => 'Nodes in the created tree: 2 for an empty canvas, more when Kirki imported a pre-built utility template.',
            ],
        ],
        'required' => [
            'id',
            'kind',
            'post_type',
            'status',
            'title',
            'slug',
            'permalink',
            'editor_url',
            'root_id',
            'body_id',
            'blocks_count',
        ],
        'additionalProperties' => false,
    ],
    'execute_callback' => 'Novamira\\Pro\\Abilities\\Kirki\\kirki_create_page',
    'permission_callback' => 'novamira_permission_callback',
    'meta' => [
        'show_in_rest' => true,
        'mcp' => ['public' => true],
        'annotations' => [
            'instructions' => 'Create as draft, add elements under `body_id` with kirki-add-element (or replace the whole canvas with kirki-set-content), then publish with the generic novamira/update-post (`status: publish`). Utility pages are the exception: publish them through this ability (`status: publish`) or ask the user to publish from Kirki, because Kirki registers their rewrite rules only for published utility pages and a plain status change leaves the URL at 404. Never write the page body through post_content: Kirki renders the block tree, not the WordPress content.',
            'readonly' => false,
            'destructive' => false,
            'idempotent' => false,
        ],
    ],
]);

/**
 * @param array<string, mixed> $input
 * @return array<string, mixed>|WP_Error
 */
function kirki_create_page(array $input): array|WP_Error
{
    kk_begin();
    $payload = kk_create_payload($input);
    if ($payload instanceof WP_Error) {
        return $payload;
    }
    /** @var string $kind */
    $kind = $payload['kind'];
    /** @var string $status */
    $status = $payload['status'];
    unset($payload['kind'], $payload['status']);
    if (!class_exists(PageService::class) || !class_exists(PagePayloadDTO::class)) {
        return new WP_Error(
            'kirki_api_missing',
            __(
                'Kirki\'s page service (PageService / PagePayloadDTO) is not available in this Kirki version; pages cannot be created through the ability.',
                domain: 'novamira-pro',
            ),
            ['status' => 501],
        );
    }

    if ($kind === 'utility') {
        /** @var string $utility_type */
        $utility_type = $payload['utility_page_type'];
        $lock = 'utility:' . $utility_type;
        return kk_with_post_lock(crc32($lock), static function () use (
            $payload,
            $kind,
            $status,
            $utility_type,
        ): array|WP_Error {
            $recheck = kk_validate_utility_type($utility_type);
            if ($recheck instanceof WP_Error) {
                return $recheck;
            }
            return kk_create_page_save($payload, $kind, $status);
        });
    }
    return kk_create_page_save($payload, $kind, $status);
}

/**
 * Run Kirki's page service and seed / keep the canvas. A failure inside
 * Kirki's save (e.g. the utility template download) leaves no orphan post
 * behind: it would otherwise block its utility type forever.
 *
 * @param array<string, mixed> $payload
 * @return array<string, mixed>|WP_Error
 */
// @mago-expect lint:halstead -- capture hook + try/catch + import check, all one flow
// @mago-expect lint:cyclomatic-complexity
function kk_create_page_save(array $payload, string $kind, string $status): array|WP_Error
{
    // Capture the id Kirki inserts so a failure later in its save (template
    // download, meta write) can be rolled back precisely.
    $inserted = 0;
    /** @var string $post_type */
    $post_type = $payload['post_type'] ?? '';
    // The LAST matching insert is ours: `wp_insert_post` fires after `save_post`,
    // so a translation plugin duplicating the post from `save_post` fires the
    // duplicate's action first and Kirki's own post's last.
    $capture = static function (int $id, \WP_Post $post) use (&$inserted, $post_type): void {
        if ($post->post_type === $post_type) {
            $inserted = $id;
        }
    };
    // Earliest priority: a third-party hook that throws before ours would otherwise leave the post behind.
    add_action('wp_insert_post', $capture, priority: PHP_INT_MIN, accepted_args: 2);
    $post_id = 0;
    try {
        $page = (new PageService())->save(PagePayloadDTO::from_array($payload));
        $post_id = kk_coerce_int_or_null($page->ID) ?? 0;
    } catch (\Throwable $e) {
        if ($inserted > 0) {
            wp_delete_post($inserted, force_delete: true);
        }
        return new WP_Error(
            'kirki_create_failed',
            sprintf(
                /* translators: %s: exception summary */
                __(
                    'Kirki could not create the page (%s). The inserted post was removed (Kirki may leave a temporary zip in the uploads folder); for utility pages this usually means the template download failed — retry when the site can reach the internet.',
                    domain: 'novamira-pro',
                ),
                kk_throwable_summary($e),
            ),
            ['status' => 502],
        );
    } finally {
        remove_action('wp_insert_post', $capture, priority: PHP_INT_MIN);
    }
    if ($post_id <= 0) {
        return new WP_Error('kirki_create_failed', __('Kirki did not return a post id.', domain: 'novamira-pro'), [
            'status' => 500,
        ]);
    }
    kk_refresh($post_id);
    $drift = kk_create_page_drift($post_id, $payload);
    if ($drift !== null) {
        // Kirki's DTO drops keys it does not know: a renamed field would give a
        // template without conditions or a page without the editor marker, silently.
        wp_delete_post($post_id, force_delete: true);
        return new WP_Error('kirki_create_failed', $drift, ['status' => 502]);
    }

    // Utility pages: Kirki's save imports its pre-built template (login form,
    // 404 layout, …) — keep it, and refuse an empty result (a login page with
    // no form would take over wp-login.php). Otherwise seed the empty canvas
    // exactly as the editor's first Save does.
    $imported = metadata_exists('post', $post_id, kk_meta_blocks()) ? kk_blocks($post_id) : null;
    $imported_ok =
        $imported !== null && $imported !== [] && kk_root_id($imported) === 'root' && isset($imported['body']);
    if ($kind === 'utility' && !$imported_ok) {
        wp_delete_post($post_id, force_delete: true);
        return new WP_Error(
            'kirki_utility_template_failed',
            __(
                'Kirki did not import a usable pre-built template for this utility page (download refused, empty, or without a root → body tree). The page was discarded; retry when the site can reach the internet.',
                domain: 'novamira-pro',
            ),
            ['status' => 502],
        );
    }
    if ($imported !== null && $imported !== []) {
        kk_ensure_ledger($post_id);
        return kk_create_page_result($post_id, $kind, $status, blocks_count: count($imported));
    }
    $body_style = kk_new_id([]);
    $blocks = [
        'root' => [
            'children' => ['body'],
            'id' => 'root',
            'name' => 'root',
            'accept' => '*',
            'title' => 'Body',
            'styleIds' => [],
        ],
        'body' => [
            'visibility' => true,
            'collapse' => false,
            'name' => 'body',
            'title' => 'Body',
            'properties' => ['tag' => 'div'],
            'className' => 'kirki-page',
            'source' => 'kirki',
            'children' => [],
            'id' => 'body',
            'parentId' => 'root',
            'styleIds' => [$body_style],
        ],
    ];
    $styles = [$body_style => kk_style_block_from_css($body_style, ['md' => 'display:flex;flex-direction:column;'])];
    try {
        $written = kk_write_jobs($post_id, [
            ['blocks' => $blocks, 'styles' => $styles, 'fonts' => [], 'version' => null],
        ]);
    } catch (\Throwable $e) {
        // A hook threw inside the seed write: the page would stay behind as an
        // editor-mode post without a tree (list-pages `has_blocks: false`).
        wp_delete_post($post_id, force_delete: true);
        return new WP_Error(
            'kirki_create_failed',
            sprintf(
                /* translators: %s: exception summary */
                __(
                    'A hook threw while the empty canvas was being written (%s); the created post was removed.',
                    domain: 'novamira-pro',
                ),
                kk_throwable_summary($e),
            ),
            ['status' => 500],
        );
    }
    if ($written instanceof WP_Error) {
        // The seed write was refused or a hook threw inside it: an editor-mode
        // post without a tree would stay behind (list-pages `has_blocks: false`).
        wp_delete_post($post_id, force_delete: true);
        return new WP_Error(
            'kirki_create_failed',
            sprintf(
                /* translators: %s: write error */
                __('The empty canvas could not be written (%s); the created post was removed.', domain: 'novamira-pro'),
                $written->get_error_message(),
            ),
            ['status' => 500],
        );
    }
    return kk_create_page_result($post_id, $kind, $status, blocks_count: 2);
}

/**
 * Publish when asked, then describe the created post.
 *
 * @return array<string, mixed>|WP_Error
 */
function kk_create_page_result(int $post_id, string $kind, string $status, int $blocks_count): array|WP_Error
{
    if ($status === 'publish') {
        $refused = kk_refuse_utility_publish($post_id, $kind);
        if ($refused !== null) {
            wp_delete_post($post_id, force_delete: true);
            return $refused;
        }
        wp_update_post(['ID' => $post_id, 'post_status' => 'publish']);
        kk_refresh($post_id);
        if ($kind === 'utility') {
            // Kirki registers utility rewrite rules for PUBLISHED pages only and
            // flushed them while the post was still a draft.
            flush_rewrite_rules(hard: false);
        }
    }
    // @mago-expect analysis:mixed-assignment
    $post = get_post($post_id);
    if (!$post instanceof \WP_Post) {
        return kk_invalid_post($post_id);
    }
    $urls = kk_page_urls($post_id);

    return [
        'id' => $post_id,
        'kind' => $kind,
        'post_type' => $post->post_type,
        'status' => $post->post_status,
        'title' => $post->post_title,
        'slug' => $post->post_name,
        'permalink' => $urls['permalink'],
        'editor_url' => $urls['editor_url'],
        'root_id' => 'root',
        'body_id' => 'body',
        'blocks_count' => $blocks_count,
    ];
}

/**
 * What Kirki's save did not persist from the payload (read back from the
 * post): the editor-mode marker, template conditions, the utility type. Null
 * when everything landed.
 *
 * @param array<string, mixed> $payload
 */
function kk_create_page_drift(int $post_id, array $payload): ?string
{
    if (!kk_is_kirki_mode($post_id)) {
        return __(
            'Kirki saved the post without the editor-mode marker; its page service no longer behaves as on 6.3.0. The post was removed.',
            domain: 'novamira-pro',
        );
    }
    if (isset($payload['conditions'])) {
        // @mago-expect analysis:mixed-assignment
        $stored = get_post_meta($post_id, kk_meta_template_conditions(), single: true);
        $expected = is_array($payload['conditions']) ? count($payload['conditions']) : 0;
        if (!is_array($stored) || count($stored) !== $expected) {
            return __(
                'Kirki saved the template without its conditions (its page payload no longer accepts `conditions` as on 6.3.0). The post was removed.',
                domain: 'novamira-pro',
            );
        }
    }
    if (isset($payload['utility_page_type'])) {
        // @mago-expect analysis:mixed-assignment
        $stored = get_post_meta($post_id, kk_meta_utility_page_type(), single: true);
        if ($stored !== $payload['utility_page_type']) {
            return __(
                'Kirki saved the utility page without its type (its page payload no longer accepts `utility_page_type` as on 6.3.0). The post was removed.',
                domain: 'novamira-pro',
            );
        }
        if (get_post_status($post_id) !== 'draft') {
            // A `wp_insert_post_data` filter forced another status: the publish
            // gate (permalinks, slug collision, one per type) never ran.
            return __(
                'A filter changed the status of the utility page at insert time, bypassing the publish checks. The post was removed.',
                domain: 'novamira-pro',
            );
        }
    }
    return null;
}

/**
 * Why a utility page must not be published now, or null. Publishing puts
 * `^<slug>$` first in the rewrite rules (every type except `404`, which has
 * no rule) and the login / sign-up / password kinds redirect wp-login.php to
 * the page, so: pretty permalinks are required (with plain permalinks Kirki's
 * URL is `home_url('/slug')`, which serves the front page and would break
 * login site-wide), and the slug WordPress will assign on publish (it is
 * re-uniqued against other utility posts then) must not belong to a live
 * post of another type.
 */
function kk_refuse_utility_publish(int $post_id, string $kind): ?WP_Error
{
    if ($kind !== 'utility') {
        return null;
    }
    if ((string) get_option('permalink_structure', default_value: '') === '') {
        return new WP_Error(
            'kirki_permalinks_required',
            __(
                'Utility pages need pretty permalinks: with plain permalinks Kirki serves them at `home_url(\'/slug\')`, which is the front page, and a published login page would redirect wp-login.php there. The page was discarded; enable a permalink structure first or create the page as a draft.',
                domain: 'novamira-pro',
            ),
            ['status' => 409],
        );
    }
    // @mago-expect analysis:mixed-assignment
    $utility_type = get_post_meta($post_id, kk_meta_utility_page_type(), single: true);
    if ($utility_type === '404') {
        return null;
    }
    // @mago-expect analysis:mixed-assignment
    $post = get_post($post_id);
    if (!$post instanceof \WP_Post) {
        return kk_invalid_post($post_id);
    }
    $final_slug = wp_unique_post_slug(
        $post->post_name,
        $post_id,
        post_status: 'publish',
        post_type: $post->post_type,
        post_parent: $post->post_parent,
    );
    $shadowed = kk_utility_slug_collision($post_id, $final_slug);
    if ($shadowed === null) {
        return null;
    }
    return new WP_Error(
        'kirki_slug_collision',
        sprintf(
            /* translators: 1: slug, 2: post id */
            __(
                'Published with slug `%1$s`, this utility page would shadow the public URL of post %2$d (Kirki puts its rewrite rule first). The page was discarded; choose another title or create it as a draft and rename it.',
                domain: 'novamira-pro',
            ),
            $final_slug,
            $shadowed,
        ),
        ['status' => 409],
    );
}

/**
 * Kirki's permalink and editor URL of a post; the plain WordPress permalink
 * and null when `PageUrl` is missing (a renamed class must not fatal after
 * the post exists).
 *
 * @return array{permalink: string, editor_url: string|null}
 */
function kk_page_urls(int $post_id): array
{
    if (!class_exists(PageUrl::class)) {
        return ['permalink' => (string) get_permalink($post_id), 'editor_url' => null];
    }
    $url = PageUrl::create($post_id);
    return ['permalink' => $url->get_page_permalink(), 'editor_url' => $url->get_editor_url()];
}

/**
 * Id of a live post of another type whose `post_name` equals this utility
 * page's slug (or the given one; slugs are unique per post type only), or null.
 */
function kk_utility_slug_collision(int $post_id, ?string $slug = null): ?int
{
    $slug ??= kk_post_slug($post_id);
    if ($slug === '') {
        return null;
    }
    global $wpdb;
    /** @var \wpdb $wpdb */
    // Direct SQL: `pre_get_posts` runs even with `suppress_filters` and a
    // membership-style status override would hide the colliding post.
    // A private or scheduled post has (or will have) a public URL too.
    // @mago-expect analysis:possibly-invalid-argument
    $sql = (string) $wpdb->prepare(
        sprintf(
            'SELECT ID FROM %s WHERE post_name = %%s AND post_status IN (%%s, %%s, %%s) AND ID <> %%d ORDER BY ID ASC LIMIT 1',
            $wpdb->posts,
        ),
        $slug,
        'publish',
        'private',
        'future',
        $post_id,
    );
    return kk_coerce_int_or_null($wpdb->get_var($sql));
}

/** The post's `post_name`, or `''`. */
function kk_post_slug(int $post_id): string
{
    $slug = get_post_field('post_name', $post_id);
    return is_string($slug) ? $slug : '';
}

/**
 * Validate the create input into the `PageService::save()` payload plus the
 * agent-facing `kind` and `status`.
 *
 * @param array<string, mixed> $input
 * @return array<string, mixed>|WP_Error
 */
// @mago-expect lint:cyclomatic-complexity -- one guard per input field, each an early return
function kk_create_payload(array $input): array|WP_Error
{
    /** @var mixed $raw_title */
    $raw_title = $input['title'] ?? $input['post_title'] ?? '';
    // sanitize_text_field keeps NUL and other control bytes; strip them and cap the length.
    $title = is_string($raw_title)
        ? sanitize_text_field(
            preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', replacement: '', subject: $raw_title) ?? '',
        )
        : '';
    if ($title === '') {
        return kk_invalid_input(__('title (or post_title) is required.', domain: 'novamira-pro'));
    }
    if (mb_strlen($title) > 200) {
        return kk_invalid_input(__('title must be 200 characters or fewer.', domain: 'novamira-pro'));
    }
    /** @var mixed $raw_kind */
    $raw_kind = $input['kind'] ?? 'page';
    $kind = is_string($raw_kind) ? $raw_kind : 'page';
    $types = kk_content_post_types();
    if (!isset($types[$kind]) || $kind === 'popup') {
        return kk_invalid_input(__('kind must be one of page, post, template, utility.', domain: 'novamira-pro'));
    }
    /** @var mixed $raw_status */
    $raw_status = $input['status'] ?? $input['post_status'] ?? 'draft';
    $payload = [
        'post_title' => $title,
        'post_type' => $types[$kind],
        'kind' => $kind,
        'status' => $raw_status === 'publish' ? 'publish' : 'draft',
    ];
    if ($kind !== 'template' && isset($input['conditions'])) {
        return kk_invalid_input(__('conditions apply to kind=template only.', domain: 'novamira-pro'));
    }
    if ($kind !== 'utility' && isset($input['utility_type'])) {
        return kk_invalid_input(__('utility_type applies to kind=utility only.', domain: 'novamira-pro'));
    }
    if ($kind === 'template') {
        $conditions = kk_validate_conditions($input['conditions'] ?? null);
        if ($conditions instanceof WP_Error) {
            return $conditions;
        }
        $payload['conditions'] = $conditions;
    }
    if ($kind === 'utility') {
        $utility = kk_validate_utility_type($input['utility_type'] ?? null);
        if ($utility instanceof WP_Error) {
            return $utility;
        }
        $payload['utility_page_type'] = $utility;
    }
    return $payload;
}

/**
 * Kirki's utility page types (`UtilityPageType` constants; 6.3.0 literals as fallback).
 *
 * @return list<string>
 */
function kk_utility_types(): array
{
    $fqcn = 'Kirki\\App\\Constants\\UtilityPageType';
    $fallback = ['404', 'login', 'sign_up', 'forgot_password', 'reset_password', 'retrive_username'];
    if (!class_exists($fqcn)) {
        return $fallback;
    }
    $values = [];
    /** @var mixed $value */
    foreach ((new \ReflectionClass($fqcn))->getConstants() as $value) {
        if (!is_string($value)) {
            continue;
        }
        $values[] = $value;
    }
    return $values === [] ? $fallback : $values;
}

/**
 * Template conditions: a non-empty list of objects with the keys the runtime
 * matcher reads (`HelperFunctions::check_all_conditions_for_this_post`).
 *
 * @return list<array<string, mixed>>|WP_Error
 */
function kk_validate_conditions(mixed $raw): array|WP_Error
{
    if (!is_array($raw) || $raw === []) {
        return kk_invalid_input(__('kind=template requires a non-empty `conditions` list.', domain: 'novamira-pro'));
    }
    $out = [];
    /** @var mixed $condition */
    foreach ($raw as $condition) {
        $normalised = kk_validate_condition($condition);
        if ($normalised instanceof WP_Error) {
            return $normalised;
        }
        $out[] = $normalised;
    }
    return $out;
}

/**
 * One condition object → normalised condition.
 *
 * @return array<string, mixed>|WP_Error
 */
function kk_validate_condition(mixed $condition): array|WP_Error
{
    if (!is_array($condition)) {
        return kk_invalid_input(__('Each condition must be an object.', domain: 'novamira-pro'));
    }
    /** @var mixed $type */
    $type = $condition['type'] ?? null;
    if ($type !== '*' && $type !== 'post' && $type !== 'user') {
        return kk_invalid_input(__(
            'condition.type must be `*` (entire site), `post` (a post type) or `user` (author pages, with from=user).',
            domain: 'novamira-pro',
        ));
    }
    /** @var mixed $visibility */
    $visibility = $condition['visibility'] ?? 'show';
    if ($visibility !== 'show' && $visibility !== 'hide') {
        return kk_invalid_input(__('condition.visibility must be `show` or `hide`.', domain: 'novamira-pro'));
    }
    /** @var mixed $from */
    $from = $condition['from'] ?? ($type === 'user' ? 'user' : 'post');
    if (!in_array($from, ['post', 'term', 'user'], strict: true)) {
        return kk_invalid_input(__('condition.from must be post, term or user.', domain: 'novamira-pro'));
    }
    $normalised = ['from' => $from, 'type' => $type, 'visibility' => $visibility];
    if ($type === '*') {
        return $normalised;
    }
    $scope = $type === 'user' ? kk_validate_user_condition_scope($condition) : kk_validate_condition_scope($condition);
    if ($scope instanceof WP_Error) {
        return $scope;
    }
    return array_merge($normalised, $scope);
}

/**
 * The `post_type` / `where` / `to` triple of a `type=post` condition. Kirki's
 * matcher compares a `single` target with `=== $post->ID`, so it is stored
 * as an integer; a taxonomy target may be a term id or slug (`has_term`).
 *
 * @param array<array-key, mixed> $condition
 * @return array<string, mixed>|WP_Error
 */
// @mago-expect lint:cyclomatic-complexity -- one branch per `where` kind
// @mago-expect lint:halstead
function kk_validate_condition_scope(array $condition): array|WP_Error
{
    /** @var mixed $post_type */
    $post_type = $condition['post_type'] ?? null;
    if (!is_string($post_type) || !post_type_exists($post_type) || !is_post_type_viewable($post_type)) {
        return kk_invalid_input(__(
            'condition.post_type must name a registered, publicly viewable post type when type=post (revisions, menu items and other internal types never render a template).',
            domain: 'novamira-pro',
        ));
    }
    /** @var mixed $where */
    $where = $condition['where'] ?? '*';
    if (!is_string($where) || $where === '') {
        return kk_invalid_input(__(
            'condition.where must be `*`, `single` or a taxonomy name.',
            domain: 'novamira-pro',
        ));
    }
    /** @var mixed $to */
    $to = $condition['to'] ?? '*';
    if ($where === '*') {
        return ['post_type' => $post_type, 'where' => '*', 'to' => '*'];
    }
    if ($where === 'single') {
        $id = kk_coerce_int_or_null($to);
        if ($id === null || $id <= 0) {
            return kk_invalid_input(__(
                'condition.to must be the integer id of the post when where=single (Kirki compares it strictly).',
                domain: 'novamira-pro',
            ));
        }
        // @mago-expect analysis:mixed-assignment
        $target = get_post($id);
        if (!$target instanceof \WP_Post || $target->post_type !== $post_type || $target->post_status === 'trash') {
            return kk_invalid_input(sprintf(
                /* translators: 1: post id, 2: post type */
                __(
                    'condition.to = %1$d is not a live post of type `%2$s`; the template would never match.',
                    domain: 'novamira-pro',
                ),
                $id,
                $post_type,
            ));
        }
        return ['post_type' => $post_type, 'where' => 'single', 'to' => $id];
    }
    if (!taxonomy_exists($where)) {
        return kk_invalid_input(sprintf(
            /* translators: %s: taxonomy */
            __('condition.where `%s` is not a registered taxonomy.', domain: 'novamira-pro'),
            $where,
        ));
    }
    if ($to !== '*' && !is_int($to) && !(is_string($to) && $to !== '')) {
        return kk_invalid_input(__(
            'condition.to must be `*`, a term id or a term slug when where is a taxonomy.',
            domain: 'novamira-pro',
        ));
    }
    if ($to !== '*') {
        // Kirki's matcher (`has_term`) treats numeric strings as term ids.
        $term_id = kk_coerce_int_or_null($to);
        $term = $term_id !== null ? get_term_by('id', $term_id, $where) : get_term_by('slug', (string) $to, $where);
        if (!$term instanceof \WP_Term) {
            return kk_invalid_input(sprintf(
                /* translators: 1: term, 2: taxonomy */
                __(
                    'condition.to `%1$s` is not a term of taxonomy `%2$s`; the template would never match.',
                    domain: 'novamira-pro',
                ),
                kk_short((string) $to),
                $where,
            ));
        }
    }
    return ['post_type' => $post_type, 'where' => $where, 'to' => $to];
}

/**
 * The `where` / `to` pair of a `type=user` condition (author archives):
 * `where` is `*` or `role`, `to` a role slug or `*`
 * (`HelperFunctions::check_all_conditions_for_this_user`).
 *
 * @param array<array-key, mixed> $condition
 * @return array<string, mixed>|WP_Error
 */
function kk_validate_user_condition_scope(array $condition): array|WP_Error
{
    /** @var mixed $where */
    $where = $condition['where'] ?? '*';
    if ($where !== '*' && $where !== 'role') {
        return kk_invalid_input(__('condition.where must be `*` or `role` when type=user.', domain: 'novamira-pro'));
    }
    if ($where === '*') {
        return ['where' => '*', 'to' => '*'];
    }
    /** @var mixed $to */
    $to = $condition['to'] ?? '*';
    if ($to !== '*' && (!is_string($to) || !isset(wp_roles()->roles[$to]))) {
        return kk_invalid_input(__(
            'condition.to must be `*` or a registered role slug when where=role.',
            domain: 'novamira-pro',
        ));
    }
    return ['where' => 'role', 'to' => $to];
}

/**
 * Utility page type: one of Kirki's fixed kinds, not already used on the site.
 *
 * @return string|WP_Error
 */
function kk_validate_utility_type(mixed $raw): string|WP_Error
{
    $allowed = kk_utility_types();
    if (!is_string($raw) || !in_array($raw, $allowed, strict: true)) {
        return kk_invalid_input(__(
            'kind=utility requires `utility_type` (404, login, sign_up, forgot_password, reset_password, retrive_username).',
            domain: 'novamira-pro',
        ));
    }
    global $wpdb;
    /** @var \wpdb $wpdb */
    $statuses = array_merge(KK_LIVE_STATUSES, ['auto-draft']);
    // Direct SQL (no query filters, no query cache): Kirki's own one-per-type
    // check (`exists()`) has no status filter, so an auto-draft counts too.
    // @mago-expect analysis:possibly-invalid-argument
    $sql = (string) $wpdb->prepare(
        sprintf(
            'SELECT p.ID FROM %s p INNER JOIN %s m ON m.post_id = p.ID WHERE p.post_type = %%s AND m.meta_key = %%s AND m.meta_value = %%s AND p.post_status IN (%s) ORDER BY p.ID ASC LIMIT 1',
            $wpdb->posts,
            $wpdb->postmeta,
            implode(',', array_fill(start_index: 0, count: count($statuses), value: '%s')),
        ),
        kk_content_post_types()['utility'],
        kk_meta_utility_page_type(),
        $raw,
        ...$statuses,
    );
    $existing = kk_coerce_int_or_null($wpdb->get_var($sql));
    if ($existing !== null) {
        return kk_invalid_input(sprintf(
            /* translators: 1: utility type, 2: post id */
            __(
                'A utility page of type `%1$s` already exists (post %2$s). Kirki allows one per type; edit it instead.',
                domain: 'novamira-pro',
            ),
            $raw,
            (string) $existing,
        ));
    }
    return $raw;
}
