<?php

// SPDX-FileCopyrightText: 2026 Ovation S.r.l. <dev@novamira.ai>
// SPDX-License-Identifier: AGPL-3.0-or-later

declare(strict_types=1);

namespace Novamira\Pro\Abilities\Kirki;

use WP_Error;
use WP_Post;

/**
 * Abilities: Kirki page settings — the SEO map and the custom code the
 * editor's "Page Settings" popover stores on a post.
 *
 * `kirki_page_seo_settings` feeds `<title>` (through `document_title_parts`)
 * and the description / Open Graph / Twitter meta tags Kirki prints in
 * `wp_head` (`Preview::getSeoMetaTags`, attribute-escaped); on a template
 * the map applies to every page the template renders, and its values may be
 * token lists Kirki resolves against the rendered post / archive
 * (`Preview::getSeoValue`). `kirki_page_custom_code` is printed RAW (head
 * inside `wp_head`, body before `</body>`): read here, never written.
 *
 * The popover's Save rewrites both metas whole (plus title / slug / excerpt /
 * thumbnail), and an open editor tab keeps them in memory: the per-post
 * editor gate applies to the SEO writer.
 */

if (!defined('ABSPATH')) {
    exit();
}

// Load order: this file's schemas use constants defined in other ability files of the folder; require them
// explicitly so the folder's alphabetical load order does not decide whether this file loads.
require_once __DIR__ . '/tree.php'; // KK_ALLOW_OPEN_EDITOR_SCHEMA

/** Byte caps of the SEO strings (the editor has none; Kirki prints them in `<title>` and meta tags). */
const KK_SEO_TITLE_BYTES = 512;

const KK_SEO_DESCRIPTION_BYTES = 2048;

const KK_SEO_MAX_TOKENS = 32;

/** Characters (not bytes: the truncation is multi-byte safe) of custom code returned by default. */
const KK_SEO_CUSTOM_CODE_DEFAULT_BYTES = 2048;

/** Characters of custom code `custom_code_bytes` may ask for at most. */
const KK_SEO_CUSTOM_CODE_MAX_BYTES = 65_536;

/**
 * Characters no SEO string may carry: markup (the editor renders its preview
 * as HTML) and control characters — tabs and line breaks included, because
 * every one of these fields is printed inside an HTML attribute value
 * (`getMeta` only runs htmlspecialchars over it).
 */
const KK_SEO_UNSAFE_PATTERN = '/[<>\x00-\x1F]/';

/** The flat SEO fields that carry text (string or token list), with their caps. */
const KK_SEO_TEXT_FIELDS = [
    'title' => KK_SEO_TITLE_BYTES,
    'meta_description' => KK_SEO_DESCRIPTION_BYTES,
    'og_title' => KK_SEO_TITLE_BYTES,
    'og_description' => KK_SEO_DESCRIPTION_BYTES,
];

const KK_SEO_TEXT_FIELD_SCHEMA = [
    'type' => ['string', 'array'],
    'items' => ['type' => 'object'],
    'description' => 'A plain string, or a token list `[{"type":"text","value":"…"},{"type":"post","value":"post_title"}]` (on a template, every family; on other posts only `post`, resolved against that post). `""` clears the field.',
];

const KK_SEO_OUTPUT_SCHEMA = [
    'type' => 'object',
    'properties' => [
        'stored' => [
            'type' => 'boolean',
            'description' => 'Whether the post carries a usable SEO map (false: no row at all OR a stored row that was not a map — `warnings` says which; WordPress defaults apply either way).',
        ],
        'title' => [
            'type' => ['string', 'array'],
            'description' => 'Text of `<title>`; a token list on dynamic fields.',
        ],
        'meta_description' => ['type' => ['string', 'array']],
        'og_title' => ['type' => ['string', 'array']],
        'og_title_same_as_title' => ['type' => 'boolean'],
        'og_description' => ['type' => ['string', 'array']],
        'og_description_same_as_meta' => ['type' => 'boolean'],
        'og_image' => [
            'type' => 'string',
            'description' => 'The URL Kirki prints as `og:image` / `twitter:image` (empty: none).',
        ],
        'og_image_source' => [
            'type' => 'string',
            'enum' => ['none', 'media', 'featured'],
            'description' => '`featured` = the editor copied the featured image URL when it was saved (a snapshot, not a live link).',
        ],
    ],
    'required' => [
        'stored',
        'title',
        'meta_description',
        'og_title',
        'og_title_same_as_title',
        'og_description',
        'og_description_same_as_meta',
        'og_image',
        'og_image_source',
    ],
    'additionalProperties' => false,
];

// ---------------------------------------------------------------------------
// get-page-settings
// ---------------------------------------------------------------------------

wp_register_ability('novamira/kirki-get-page-settings', [
    'label' => __('Get Kirki Page Settings', domain: 'novamira-pro'),
    'description' => __(
        'Reads what the Kirki editor\'s "Page Settings" popover holds for a post: the General tab (title, slug, excerpt, status, featured image, permalink — read-only here, change them with novamira/update-post and the media abilities), the SEO tab as flat fields (`title` → `<title>`, `meta_description`, Open Graph title / description with their "same as" flags, `og_image` and its source) and the Custom Code tab (head and body code, printed raw on the page — read-only for these abilities, truncated to `custom_code_bytes`). On a template the SEO values may be token lists Kirki resolves against the rendered post / archive (`tokens_allowed` says which families make sense here). Warns when the stored SEO map is not the full editor shape (Kirki\'s frontend logs PHP warnings on every request for such a post). Reads the rows fresh (Kirki\'s editor writes them with raw SQL). Popups are refused: Kirki never prints page settings for them.',
        domain: 'novamira-pro',
    ),
    'category' => 'kirki',
    'input_schema' => [
        'type' => 'object',
        'properties' => [
            'post_id' => [
                'type' => 'integer',
                'description' => 'A page, post, public custom post, template or utility page owned by Kirki.',
            ],
            'custom_code_bytes' => [
                'type' => 'integer',
                'minimum' => 0,
                'maximum' => KK_SEO_CUSTOM_CODE_MAX_BYTES,
                'description' => 'How much of each custom-code slot to return, counted in CHARACTERS despite the name (the cut is multi-byte safe, so multi-byte code can come back longer in bytes than the number asked for): default 2048, 0 omits the text. `bytes` always reports the stored size in bytes.',
            ],
        ],
        'required' => ['post_id'],
        'additionalProperties' => false,
    ],
    'output_schema' => [
        'type' => 'object',
        'properties' => [
            'post_id' => ['type' => 'integer'],
            'post_type' => ['type' => 'string'],
            'kind' => ['type' => 'string', 'description' => 'page | post | template | utility | custom.'],
            'status' => ['type' => 'string'],
            'general' => [
                'type' => 'object',
                'properties' => [
                    'title' => ['type' => 'string'],
                    'slug' => ['type' => 'string'],
                    'excerpt' => ['type' => 'string'],
                    'featured_image' => ['type' => ['object', 'null'], 'description' => '`{id, url}` or null.'],
                    'permalink' => ['type' => 'string'],
                ],
                'required' => ['title', 'slug', 'excerpt', 'featured_image', 'permalink'],
                'additionalProperties' => false,
            ],
            'seo' => KK_SEO_OUTPUT_SCHEMA,
            'custom_code' => [
                'type' => 'object',
                'properties' => [
                    'stored' => ['type' => 'boolean'],
                    'head' => [
                        'type' => 'object',
                        'description' => '`{bytes, text, truncated}` — `bytes` is the stored size in bytes, `text` the first `custom_code_bytes` CHARACTERS of it; printed raw inside `<head>`.',
                    ],
                    'body' => [
                        'type' => 'object',
                        'description' => '`{bytes, text, truncated}` — same shape as `head`; printed raw before `</body>`.',
                    ],
                    'note' => ['type' => 'string'],
                ],
                'required' => ['stored', 'head', 'body', 'note'],
                'additionalProperties' => false,
            ],
            'tokens_allowed' => [
                'type' => 'array',
                'items' => ['type' => 'string'],
                'description' => 'Token families kirki-edit-seo-settings accepts on this post: `post` everywhere, `term` / `user` on templates only.',
            ],
            'editor_open' => [
                'type' => ['object', 'null'],
                'description' => '`{sessions, newest_age_seconds}` from Kirki\'s collaboration heartbeat; null when the table is missing.',
            ],
            'warnings' => ['type' => 'array', 'items' => ['type' => 'string']],
        ],
        'required' => [
            'post_id',
            'post_type',
            'kind',
            'status',
            'general',
            'seo',
            'custom_code',
            'tokens_allowed',
            'editor_open',
            'warnings',
        ],
        'additionalProperties' => false,
    ],
    'execute_callback' => 'Novamira\\Pro\\Abilities\\Kirki\\kirki_get_page_settings',
    'permission_callback' => 'novamira_permission_callback',
    'meta' => [
        'show_in_rest' => true,
        'mcp' => ['public' => true],
        'annotations' => [
            'instructions' => 'Call before kirki-edit-seo-settings to see the current values and which token families this post accepts. `general` and `custom_code` are read-only here; the SEO tab is the writable part. A template\'s SEO applies to every page it renders, so read the template (kirki-resolve-template tells which one) when a post\'s tags are not what its own settings say.',
            'readonly' => true,
            'destructive' => false,
            'idempotent' => true,
        ],
    ],
]);

/**
 * @param array<string, mixed> $input
 * @return array<string, mixed>|WP_Error
 */
function kirki_get_page_settings(array $input): array|WP_Error
{
    kk_begin();
    $post_id = kk_coerce_int_or_null($input['post_id'] ?? null) ?? 0;
    $post = kk_settings_post_or_error($post_id);
    if ($post instanceof WP_Error) {
        return $post;
    }
    $code_bytes = kk_coerce_int_or_null($input['custom_code_bytes'] ?? null) ?? KK_SEO_CUSTOM_CODE_DEFAULT_BYTES;
    /** @var mixed $seo_map */
    $seo_map = kk_meta($post_id, kk_meta_page_seo());
    $warnings = [];
    if ($seo_map !== null && !kk_seo_map_is_complete($seo_map)) {
        $warnings[] = 'The stored SEO map is not the full editor shape: Kirki\'s frontend logs PHP warnings on every request for this post until it is complete. kirki-edit-seo-settings rewrites the full shape (any field).';
    }
    $thumbnail_id = kk_coerce_int_or_null(get_post_thumbnail_id($post)) ?? 0;
    $thumbnail_url = $thumbnail_id > 0 ? get_the_post_thumbnail_url($post, size: 'full') : false;
    $permalink = get_permalink($post);
    return [
        'post_id' => $post->ID,
        'post_type' => $post->post_type,
        'kind' => kk_settings_kind($post),
        'status' => $post->post_status,
        'general' => [
            'title' => $post->post_title,
            'slug' => $post->post_name,
            'excerpt' => $post->post_excerpt,
            'featured_image' => is_string($thumbnail_url) ? ['id' => $thumbnail_id, 'url' => $thumbnail_url] : null,
            'permalink' => $permalink,
        ],
        'seo' => kk_seo_flat($seo_map),
        'custom_code' => kk_custom_code_report(kk_meta($post_id, kk_meta_page_custom_code()), $code_bytes),
        'tokens_allowed' => kk_seo_tokens_allowed($post),
        'editor_open' => kk_open_editor_sessions($post_id),
        'warnings' => $warnings,
    ];
}

/** Agent-facing kind of a post the page abilities handle. */
function kk_settings_kind(WP_Post $post): string
{
    $kind = array_search($post->post_type, kk_content_post_types(), strict: true);
    return is_string($kind) ? $kind : 'custom';
}

/**
 * The custom-code meta as the reader reports it: one `{bytes, text, truncated}`
 * per slot, never more than `$max` characters of text.
 *
 * @return array<string, mixed>
 */
function kk_custom_code_report(mixed $stored, int $max): array
{
    $report = [
        'stored' => is_array($stored),
        'note' => 'Printed raw on the page (head inside <head>, body before </body>): read-only for these abilities; change it in the editor\'s Page Settings → Custom Code.',
    ];
    foreach (['head', 'body'] as $slot) {
        /** @var mixed $value */
        $value = is_array($stored) && is_array($stored[$slot] ?? null) ? $stored[$slot]['value'] ?? '' : '';
        $text = is_string($value) ? $value : '';
        $report[$slot] = [
            'bytes' => strlen($text),
            'text' => kk_truncate($text, $max),
            'truncated' => mb_strlen($text) > $max,
        ];
    }
    return $report;
}

// ---------------------------------------------------------------------------
// edit-seo-settings
// ---------------------------------------------------------------------------

wp_register_ability('novamira/kirki-edit-seo-settings', [
    'label' => __('Edit Kirki SEO Settings', domain: 'novamira-pro'),
    'description' => __(
        'Changes the SEO tab of a post\'s Kirki page settings: `title` (printed as `<title>`, WordPress appends the site name), `meta_description`, Open Graph title / description (or `og_title_same_as_title` / `og_description_same_as_meta` to mirror the SEO fields) and `og_image` (`"featured"` copies the post\'s CURRENT featured image URL the way the editor does — a snapshot, re-run after changing the image; an http(s) URL; `""` for none). Fields left out keep their stored value; `""` clears one. On a template the text fields accept token lists (`[{"type":"text","value":"… "},{"type":"post","value":"post_title"}]`; families `post`, `term`, `user`, resolved by Kirki against the rendered post / term archive / author page); on any other post only `post` tokens, resolved against that post. Strings and text parts must not contain angle brackets or control characters — tabs and line breaks included, the values are printed inside HTML attributes (the editor renders its preview as HTML); Kirki escapes them in the tags and runs shortcodes on the result. Always writes the complete editor shape (a partial map makes Kirki\'s frontend log PHP warnings) in one transaction under the post lock, read back and verified; a stored partial map is repaired by the write. Refused while a Kirki editor tab is open on the post (`kirki_editor_open`): the tab\'s Page Settings → Save rewrites the SEO map with its own copy. A template\'s SEO applies to every page it renders.',
        domain: 'novamira-pro',
    ),
    'category' => 'kirki',
    'input_schema' => [
        'type' => 'object',
        'properties' => [
            'post_id' => [
                'type' => 'integer',
                'description' => 'A page, post, public custom post, template or utility page owned by Kirki (popups have no page settings).',
            ],
            'title' => KK_SEO_TEXT_FIELD_SCHEMA,
            'meta_description' => KK_SEO_TEXT_FIELD_SCHEMA,
            'og_title' => KK_SEO_TEXT_FIELD_SCHEMA,
            'og_description' => KK_SEO_TEXT_FIELD_SCHEMA,
            'og_title_same_as_title' => [
                'type' => 'boolean',
                'description' => 'Print the SEO title as `og:title` / `twitter:title` (the stored `og_title` text is kept, as the editor does).',
            ],
            'og_description_same_as_meta' => [
                'type' => 'boolean',
                'description' => 'Print the meta description as `og:description` / `twitter:description`.',
            ],
            'og_image' => [
                'type' => 'string',
                'description' => '`"featured"`, an http(s) URL (media-library files are what the editor offers; others print anyway with a warning) or `""` for no image.',
            ],
            'allow_open_editor' => KK_ALLOW_OPEN_EDITOR_SCHEMA,
        ],
        'required' => ['post_id'],
        'additionalProperties' => false,
    ],
    'output_schema' => [
        'type' => 'object',
        'properties' => [
            'post_id' => ['type' => 'integer'],
            'seo' => KK_SEO_OUTPUT_SCHEMA,
            'written' => [
                'type' => 'array',
                'items' => ['type' => 'string'],
                'description' => 'Flat fields whose stored value changed (empty when the call was a no-op; the row is still completed when it was partial).',
            ],
            'warnings' => ['type' => 'array', 'items' => ['type' => 'string']],
        ],
        'required' => ['post_id', 'seo', 'written', 'warnings'],
        'additionalProperties' => false,
    ],
    'execute_callback' => 'Novamira\\Pro\\Abilities\\Kirki\\kirki_edit_seo_settings',
    'permission_callback' => 'novamira_permission_callback',
    'meta' => [
        'show_in_rest' => true,
        'mcp' => ['public' => true],
        'annotations' => [
            'instructions' => 'Read the post with kirki-get-page-settings first (values, `tokens_allowed`). Pass only the fields to change. Verify on the public page: `<title>` and the meta tags in `<head>` — when a published template renders the post, the TEMPLATE\'s SEO wins (kirki-resolve-template). `og_image: "featured"` stores the image URL of that moment.',
            'readonly' => false,
            'destructive' => false,
            'idempotent' => true,
        ],
    ],
]);

/**
 * @param array<string, mixed> $input
 * @return array<string, mixed>|WP_Error
 */
function kirki_edit_seo_settings(array $input): array|WP_Error
{
    kk_begin();
    $post_id = kk_coerce_int_or_null($input['post_id'] ?? null) ?? 0;
    $post = kk_settings_post_or_error($post_id);
    if ($post instanceof WP_Error) {
        return $post;
    }
    $patch = kk_seo_patch($input, kk_seo_tokens_allowed($post));
    if ($patch instanceof WP_Error) {
        return $patch;
    }
    $open = kk_refuse_open_editor_settings($post_id, $input['allow_open_editor'] ?? false);
    if ($open instanceof WP_Error) {
        return $open;
    }
    $key = kk_meta_page_seo();
    $warnings = [];
    $before = kk_seo_flat(kk_meta($post_id, $key));
    $flat = kk_seo_merge($post, $before, $patch, $warnings);
    $warnings = array_merge($warnings, kk_seo_token_warnings($post, $flat));
    $map = kk_seo_map($flat);
    $written = kk_with_post_lock($post_id, static function () use ($post_id, $key, $map): bool|WP_Error {
        if (kk_live_post($post_id) === null) {
            return kk_invalid_post($post_id);
        }
        if (kk_meta($post_id, $key) === $map) {
            return true;
        }
        return kk_write_meta_verified($post_id, [$key => $map]);
    });
    if ($written instanceof WP_Error) {
        return $written;
    }
    return [
        'post_id' => $post_id,
        'seo' => kk_seo_flat(kk_meta($post_id, $key)),
        'written' => kk_seo_changed_fields($before, $flat),
        'warnings' => $warnings,
    ];
}

/**
 * The stored flat map with the validated patch applied (`og_image` the way
 * the editor stores it).
 *
 * @param array<string, mixed> $before
 * @param array<string, mixed> $patch
 * @param list<string> $warnings
 * @return array<string, mixed>
 */
function kk_seo_merge(WP_Post $post, array $before, array $patch, array &$warnings): array
{
    $flat = $before;
    /** @var mixed $value */
    foreach ($patch as $field => $value) {
        $flat[$field] = $value;
    }
    if (array_key_exists('og_image', $patch)) {
        $flat = kk_seo_apply_image($post, $flat, $warnings);
    }
    return $flat;
}

/**
 * Flat fields whose value differs between two flat maps.
 *
 * @param array<string, mixed> $before
 * @param array<string, mixed> $after
 * @return list<string>
 */
function kk_seo_changed_fields(array $before, array $after): array
{
    $changed = [];
    foreach (array_keys(kk_seo_flat(null)) as $field) {
        if ($field === 'stored' || ($before[$field] ?? null) === ($after[$field] ?? null)) {
            continue;
        }
        $changed[] = $field;
    }
    return $changed;
}

/**
 * The validated flat fields present in the input (at least one), or the
 * refusal.
 *
 * @param array<string, mixed> $input
 * @param list<string> $families
 * @return array<string, mixed>|WP_Error
 */
function kk_seo_patch(array $input, array $families): array|WP_Error
{
    $patch = [];
    $errors = [];
    /** @var int $cap */
    foreach (KK_SEO_TEXT_FIELDS as $field => $cap) {
        if (!array_key_exists($field, $input)) {
            continue;
        }
        $errors = array_merge($errors, kk_seo_value_errors($input[$field], $field, $cap, $families));
        /** @var mixed $value */
        $value = $input[$field];
        $patch[$field] = is_array($value) ? kk_seo_value($value) : $value;
    }
    foreach (['og_title_same_as_title', 'og_description_same_as_meta'] as $flag) {
        if (!array_key_exists($flag, $input)) {
            continue;
        }
        if (!is_bool($input[$flag])) {
            $errors[] = sprintf('`%s` must be a boolean.', $flag);
        }
        $patch[$flag] = kk_bool($input[$flag]);
    }
    if (array_key_exists('og_image', $input)) {
        $image_error = kk_seo_image_error($input['og_image']);
        if ($image_error !== null) {
            $errors[] = $image_error;
        }
        $patch['og_image'] = $input['og_image'];
    }
    if ($errors !== []) {
        return kk_invalid_input(implode(' ', $errors));
    }
    if ($patch === []) {
        return kk_invalid_input(
            'Nothing to change: pass at least one of `title`, `meta_description`, `og_title`, `og_description`, `og_title_same_as_title`, `og_description_same_as_meta`, `og_image`.',
        );
    }
    return $patch;
}

/**
 * Errors of one text field: a string under the cap without markup / control
 * characters, or a token list of at most KK_SEO_MAX_TOKENS entries whose text
 * parts follow the same rule and whose dynamic tokens belong to the editor's
 * vocabulary and to a family this post resolves.
 *
 * @param list<string> $families
 * @return list<string>
 */
function kk_seo_value_errors(mixed $value, string $field, int $cap, array $families): array
{
    if (is_string($value)) {
        $error = kk_seo_string_error($value, $cap);
        return $error === null ? [] : [sprintf('`%s` %s', $field, $error)];
    }
    if (!is_array($value) || !kk_is_list($value)) {
        return [sprintf('`%s` must be a string or a list of `{type, value}` tokens.', $field)];
    }
    if (count($value) > KK_SEO_MAX_TOKENS) {
        return [sprintf('`%s` has more than %d tokens.', $field, KK_SEO_MAX_TOKENS)];
    }
    $errors = [];
    /** @var mixed $token */
    foreach ($value as $index => $token) {
        $error = kk_seo_token_error($token, $cap, $families);
        if ($error !== null) {
            $errors[] = sprintf('`%s[%d]` %s', $field, $index, $error);
        }
    }
    return $errors;
}

/** Error suffix for a SEO string, or null. */
function kk_seo_string_error(string $value, int $cap): ?string
{
    if (strlen($value) > $cap) {
        return sprintf('exceeds %d bytes.', $cap);
    }
    if (
        preg_match(KK_SEO_UNSAFE_PATTERN, $value) === 1
        || preg_match(KK_SEO_UNSAFE_PATTERN, kk_decode_entities($value)) === 1
    ) {
        return 'must not contain angle brackets or control characters, tabs and line breaks included (also as HTML entities): the editor renders the SEO preview as HTML and Kirki prints these fields inside an attribute value.';
    }
    return null;
}

/**
 * Error suffix for one token of a SEO token list, or null.
 *
 * @param list<string> $families
 */
function kk_seo_token_error(mixed $token, int $cap, array $families): ?string
{
    if (!is_array($token) || !isset($token['type']) || !array_key_exists('value', $token)) {
        return 'must be an object with `type` and `value`.';
    }
    /** @var mixed $type */
    $type = $token['type'];
    /** @var mixed $value */
    $value = $token['value'];
    if ($type === 'text') {
        if (!is_string($value)) {
            return 'has a non-string text `value`.';
        }
        return kk_seo_string_error($value, $cap);
    }
    if (!is_string($type) || !isset(KK_SEO_TOKENS[$type])) {
        return 'has an unknown `type`: use `text`, `post`, `term` or `user`.';
    }
    if (!is_string($value) || !in_array($value, KK_SEO_TOKENS[$type], strict: true)) {
        return sprintf('has an unknown `%s` token: one of %s.', $type, implode(', ', KK_SEO_TOKENS[$type]));
    }
    if (!in_array($type, $families, strict: true)) {
        return sprintf(
            'uses a `%s` token, which resolves only on a template (Kirki reads the archive\'s term / author from the URL; on this post it would print the viewer\'s own data or nothing).',
            $type,
        );
    }
    return null;
}

/** Error for the `og_image` input, or null. */
function kk_seo_image_error(mixed $value): ?string
{
    if (!is_string($value)) {
        return '`og_image` must be a string: `"featured"`, an http(s) URL or `""`.';
    }
    if ($value === '' || $value === 'featured') {
        return null;
    }
    $url_error = kk_validate_url_value($value);
    if ($url_error !== null) {
        return sprintf('`og_image` %s', $url_error);
    }
    if (preg_match('/^https?:\/\/\S+\z/i', $value) !== 1) {
        return '`og_image` must be an absolute http(s) URL, `"featured"` or `""`.';
    }
    return null;
}

/**
 * Apply the `og_image` request to the flat map the way the editor does:
 * `featured` snapshots the current featured image URL, a URL is stored as a
 * media-manager choice.
 *
 * @param array<string, mixed> $flat
 * @param list<string> $warnings
 * @return array<string, mixed>
 */
function kk_seo_apply_image(WP_Post $post, array $flat, array &$warnings): array
{
    /** @var mixed $requested */
    $requested = $flat['og_image'];
    $requested = is_string($requested) ? $requested : '';
    if ($requested === 'featured') {
        $url = get_the_post_thumbnail_url($post, size: 'full');
        $flat['og_image'] = is_string($url) ? $url : '';
        $flat['og_image_source'] = 'featured';
        if (!is_string($url)) {
            $warnings[] = sprintf(
                'Post %d has no featured image: `og_image` is stored empty and Kirki prints no `og:image`. Kirki stores a snapshot of the image URL, so set the featured image and call this ability again.',
                $post->ID,
            );
        }
        return $flat;
    }
    $flat['og_image'] = $requested;
    $flat['og_image_source'] = 'media';
    if ($requested !== '') {
        foreach (kk_seo_image_warnings($requested) as $warning) {
            $warnings[] = $warning;
        }
    }
    return $flat;
}

/**
 * What is wrong with an `og_image` URL: not a library file, or a library file
 * that is not an image, or one in the trash (Kirki snapshots the URL and
 * prints it verbatim, so none of these is refused — the tag simply points at
 * something no crawler can use).
 *
 * @return list<string>
 */
function kk_seo_image_warnings(string $url): array
{
    $attachment_id = attachment_url_to_postid($url);
    if ($attachment_id === 0) {
        return [
            '`og_image` is not a file of this site\'s media library (the editor only offers library images); Kirki prints the URL as given.',
        ];
    }
    // @mago-expect analysis:mixed-assignment
    $attachment = get_post($attachment_id);
    if (!$attachment instanceof WP_Post) {
        return [sprintf(
            '`og_image` resolves to attachment %d, which no longer exists; Kirki prints the URL as given.',
            $attachment_id,
        )];
    }
    $warnings = [];
    if (!str_starts_with($attachment->post_mime_type, 'image/')) {
        $warnings[] = sprintf(
            '`og_image` is attachment %d (`%s`), not an image: the editor only offers images and crawlers ignore the tag.',
            $attachment_id,
            $attachment->post_mime_type,
        );
    }
    if ($attachment->post_status === 'trash') {
        $warnings[] = sprintf(
            '`og_image` is attachment %d, which is in the trash: emptying the trash deletes the file and the URL 404s.',
            $attachment_id,
        );
    }
    return $warnings;
}

/**
 * Warnings about tokens that resolve to nothing (or to something the user
 * may not want printed) given the template's conditions.
 *
 * @param array<string, mixed> $flat
 * @return list<string>
 */
function kk_seo_token_warnings(WP_Post $post, array $flat): array
{
    $used = kk_seo_token_families($flat);
    $warnings = [];
    if ($post->post_type === kk_content_post_types()['template']) {
        $targets = kk_template_target_families($post->ID);
        foreach (['term', 'user'] as $family) {
            if (!isset($used[$family]) || in_array($family, $targets, strict: true)) {
                continue;
            }
            $warnings[] = sprintf(
                'A `%s` token is used but none of this template\'s conditions targets a %s (`%s`): Kirki resolves it to nothing on the pages this template renders.',
                $family,
                $family === 'term' ? 'term archive' : 'author page',
                $family === 'term' ? 'from: term' : 'type: user',
            );
        }
    }
    if (isset($used['user']['user_email'])) {
        $warnings[] = 'The `user_email` token prints the author\'s e-mail address in a public meta tag.';
    }
    foreach (array_keys(KK_SEO_TEXT_FIELDS) as $field) {
        if (!kk_seo_has_shortcode($flat[$field] ?? '')) {
            continue;
        }
        $warnings[] = sprintf(
            '`%s` contains a registered shortcode: Kirki runs shortcodes on SEO values before printing them.',
            $field,
        );
    }
    return $warnings;
}

/**
 * Token families (and token names) used across the text fields of a flat map.
 *
 * @param array<string, mixed> $flat
 * @return array<string, array<string, true>>
 */
function kk_seo_token_families(array $flat): array
{
    $used = [];
    foreach (array_keys(KK_SEO_TEXT_FIELDS) as $field) {
        /** @var mixed $value */
        $value = $flat[$field] ?? '';
        if (!is_array($value)) {
            continue;
        }
        /** @var mixed $token */
        foreach ($value as $token) {
            if (!is_array($token) || !isset($token['type'], $token['value']) || !is_string($token['type'])) {
                continue;
            }
            if ($token['type'] === 'text') {
                continue;
            }
            $used[$token['type']][is_string($token['value']) ? $token['value'] : ''] = true;
        }
    }
    return $used;
}

/**
 * Which archive families a template's stored conditions target: `term` when
 * an entry has `from: term`, `user` when one has `type: user`.
 *
 * @return list<string>
 */
function kk_template_target_families(int $post_id): array
{
    /** @var mixed $conditions */
    $conditions = kk_meta($post_id, kk_meta_template_conditions());
    $families = [];
    /** @var mixed $raw */
    foreach (is_array($conditions) ? $conditions : [] as $raw) {
        if (!is_array($raw)) {
            continue;
        }
        $condition = kk_normalize_condition($raw);
        if ($condition['from'] === 'term') {
            $families['term'] = true;
        }
        if ($condition['type'] === 'user') {
            $families['user'] = true;
        }
    }
    return array_keys($families);
}

/** Whether a SEO value (string or token list) carries a shortcode registered on the site. */
function kk_seo_has_shortcode(mixed $value): bool
{
    $texts = [];
    if (is_string($value)) {
        $texts[] = $value;
    }
    /** @var mixed $token */
    foreach (is_array($value) ? $value : [] as $token) {
        if (!is_array($token) || ($token['type'] ?? null) !== 'text' || !is_string($token['value'] ?? null)) {
            continue;
        }
        $texts[] = $token['value'];
    }
    $regex = '/' . get_shortcode_regex() . '/s';
    foreach ($texts as $text) {
        if (str_contains($text, '[') && preg_match($regex, $text) === 1) {
            return true;
        }
    }
    return false;
}

/**
 * The editor-open refusal worded for page settings: an open tab holds the
 * popover's values in memory and its Save rewrites the SEO map whole.
 */
function kk_refuse_open_editor_settings(int $post_id, mixed $allow_open_editor): ?WP_Error
{
    if (kk_bool($allow_open_editor)) {
        return null;
    }
    $open = kk_open_editor_sessions($post_id);
    if ($open === null || $open['sessions'] === 0) {
        return null;
    }
    return new WP_Error(
        'kirki_editor_open',
        sprintf(
            /* translators: 1: post id, 2: session count, 3: seconds */
            __(
                'Post %1$d is open in the Kirki editor right now (%2$d tab(s), last heartbeat %3$d s ago). The tab loaded the page settings when it opened and its Page Settings → Save rewrites the whole SEO map with that copy, so this write could be lost silently. Ask the user to close the tab and retry after about 40 seconds (the heartbeat outlives the tab by up to 20 s and expires 30 s later), or re-run with `allow_open_editor: true` if they accept that the tab may overwrite the change.',
                domain: 'novamira-pro',
            ),
            $post_id,
            $open['sessions'],
            $open['newest_age_seconds'] ?? 0,
        ),
        ['status' => 409],
    );
}
