<?php

// SPDX-FileCopyrightText: 2026 Ovation S.r.l. <dev@novamira.ai>
// SPDX-License-Identifier: AGPL-3.0-or-later

declare(strict_types=1);

namespace Novamira\Pro\Abilities\Kirki;

use WP_Post;

/**
 * Ability: List Kirki symbols (headers, footers, reusable components) and
 * report which ones Kirki currently renders as the site header / footer.
 */

if (!defined('ABSPATH')) {
    exit();
}

wp_register_ability('novamira/kirki-list-symbols', [
    'label' => __('List Kirki Symbols', domain: 'novamira-pro'),
    'description' => __(
        'Lists Kirki symbols: the reusable pieces (`kirki_symbol` posts) a page embeds through a `symbol` node, including the ones assigned as site header or footer. Each row is compact: id, name (from the symbol data, the WordPress title is empty), category, `set_as` (`header`, `footer` or null), post status, `active` (Kirki\'s editor list and its header/footer resolver only read symbols in `draft` status, the status it creates them with; an instance embedded in a page still renders whatever the status, trash included), root element, node and style-block counts, `is_component` / `fields_count` for 6.3 components with field bindings, `override_keys` (the keys a page instance may use in `properties.symbolElProps`: a node\'s `symbolElPropId`, or its id for legacy nodes without one — Kirki matches ONLY these and silently ignores any other key, so the writers refuse them) and `field_ids` (keys for `componentFieldValues`). Top-level `header_symbol_id` / `footer_symbol_id` resolve the site-wide header and footer exactly as Kirki does (a page can still disable them through its `kirki_disabled_page_symbols` meta or a theme filter). Filter with `set_as`, `search` (on the symbol name); page with `limit` / `offset`.',
        domain: 'novamira-pro',
    ),
    'category' => 'kirki',
    'input_schema' => [
        'type' => 'object',
        'default' => [],
        'properties' => [
            'set_as' => [
                'type' => 'string',
                'enum' => ['header', 'footer', 'none', 'any'],
                'description' => 'Keep only symbols assigned as header, as footer, or unassigned (`none`). Default `any`.',
                'default' => 'any',
            ],
            'search' => [
                'type' => 'string',
                'description' => 'Case-insensitive substring match on the symbol name.',
            ],
            'limit' => KK_LIMIT_SCHEMA,
            'offset' => KK_OFFSET_SCHEMA,
        ],
        'additionalProperties' => false,
    ],
    'output_schema' => [
        'type' => 'object',
        'properties' => [
            'symbols' => ['type' => 'array', 'items' => ['type' => 'object']],
            'total' => ['type' => 'integer', 'description' => 'Total matching rows before `limit` / `offset`.'],
            'returned' => ['type' => 'integer'],
            'header_symbol_id' => ['type' => ['integer', 'null']],
            'footer_symbol_id' => ['type' => ['integer', 'null']],
        ],
        'required' => ['symbols', 'total', 'returned', 'header_symbol_id', 'footer_symbol_id'],
        'additionalProperties' => false,
    ],
    'execute_callback' => 'Novamira\\Pro\\Abilities\\Kirki\\kirki_list_symbols',
    'permission_callback' => 'novamira_permission_callback',
    'meta' => [
        'show_in_rest' => true,
        'mcp' => ['public' => true],
        'annotations' => [
            'instructions' => 'Symbols keep their own block tree and style blocks. When rendered as the site header / footer their classes get the per-symbol prefix `kirki-s<id>`; when embedded in a page through a `symbol` node they are emitted verbatim, so a symbol class name can collide with a page class. A symbol whose `active` is false is not offered by the editor and never resolves as header / footer, but pages that already embed it keep rendering it. Do not edit symbol trees with the page element abilities: they operate on pages, not on `kirki_symbol` posts.',
            'readonly' => true,
            'destructive' => false,
            'idempotent' => true,
        ],
    ],
]);

/**
 * @param array{set_as?: string, search?: string, limit?: mixed, offset?: mixed} $input
 * @return array<string, mixed>
 */
// @mago-expect lint:cyclomatic-complexity -- two queries (Kirki-visible drafts, then the rest) plus filters
function kirki_list_symbols(array $input): array
{
    kk_begin();
    $set_as = $input['set_as'] ?? 'any';
    $search = isset($input['search']) ? trim($input['search']) : '';
    $limit = kk_clamp_limit($input['limit'] ?? null, default: 50);
    $offset = max(0, kk_coerce_int_or_null($input['offset'] ?? null) ?? 0);

    // Header / footer are resolved by walking EXACTLY the query Kirki runs in
    // `Symbol::fetch_list()` (draft symbols, get_posts defaults): the same
    // rows in the same order, so ties on `post_date` break the same way.
    $header = null;
    $footer = null;
    $order = [];
    /** @var mixed $drafts */
    $drafts = get_posts([
        'post_type' => kk_symbol_post_type(),
        'post_status' => 'draft',
        'numberposts' => -1,
        // Kirki's direct meta writes do not bump the query-cache salt (persistent object cache).
        'cache_results' => false,
        'update_post_meta_cache' => false,
    ]);
    $rows_by_id = [];
    if (is_array($drafts)) {
        /** @var mixed $post */
        foreach ($drafts as $post) {
            if (!$post instanceof WP_Post) {
                continue;
            }
            $row = kk_symbol_row($post);
            $rows_by_id[$post->ID] = $row;
            $order[] = $post->ID;
            if ($row['set_as'] === 'header' && $header === null) {
                $header = $post->ID;
            }
            if ($row['set_as'] === 'footer' && $footer === null) {
                $footer = $post->ID;
            }
        }
    }
    // Then the symbols the editor list and the header/footer resolver cannot
    // see (every other registered status plus trash, auto-draft and inherit
    // included: a page instance still renders such a symbol), newest first.
    /** @var mixed $others */
    $others = get_posts([
        'post_type' => kk_symbol_post_type(),
        'post_status' => array_values(array_diff(array_merge(array_keys(get_post_stati()), ['trash']), ['draft'])),
        'numberposts' => -1,
        'orderby' => ['post_date' => 'DESC', 'ID' => 'DESC'],
        'cache_results' => false,
        'update_post_meta_cache' => false,
    ]);
    if (is_array($others)) {
        /** @var mixed $post */
        foreach ($others as $post) {
            if (!$post instanceof WP_Post) {
                continue;
            }
            $rows_by_id[$post->ID] = kk_symbol_row($post);
            $order[] = $post->ID;
        }
    }
    $rows = [];
    foreach ($order as $id) {
        if (!kk_symbol_matches($rows_by_id[$id], $set_as, $search)) {
            continue;
        }
        $rows[] = $rows_by_id[$id];
    }

    $page = array_slice($rows, $offset, $limit);

    return [
        'symbols' => $page,
        'total' => count($rows),
        'returned' => count($page),
        'header_symbol_id' => $header,
        'footer_symbol_id' => $footer,
    ];
}

/**
 * @param array<string, mixed> $row
 */
function kk_symbol_matches(array $row, string $set_as, string $search): bool
{
    if ($set_as === 'none' && $row['set_as'] !== null) {
        return false;
    }
    if (($set_as === 'header' || $set_as === 'footer') && $row['set_as'] !== $set_as) {
        return false;
    }
    if ($search === '') {
        return true;
    }
    $name = is_string($row['name']) ? $row['name'] : '';
    return mb_stripos($name, $search) !== false;
}

/**
 * One symbol row. `active` mirrors `Symbol::fetch_list()`, which only queries
 * `post_status = draft`; `set_as` is null unless it is `header` / `footer`.
 *
 * @return array<string, mixed>
 */
// @mago-expect lint:cyclomatic-complexity -- one guarded field per row key
function kk_symbol_row(WP_Post $post): array
{
    $meta = kk_symbol_meta($post->ID) ?? [];
    /** @var array<string, mixed> $data */
    $data = is_array($meta['data'] ?? null) ? $meta['data'] : [];
    /** @var mixed $styles */
    $styles = $meta['styleBlocks'] ?? [];
    $root = kk_symbol_string($meta, key: 'root');
    /** @var array<string, mixed>|null $root_node */
    $root_node = $root !== null && is_array($data[$root] ?? null) ? $data[$root] : null;
    $set_as = kk_symbol_string($meta, key: 'setAs');

    $name = kk_symbol_string($meta, key: 'name');
    return [
        'id' => $post->ID,
        'name' => $name === null ? null : kk_truncate($name, max: 200),
        'category' => kk_truncate(kk_symbol_string($meta, key: 'category') ?? 'other', max: 64),
        'set_as' => $set_as === 'header' || $set_as === 'footer' ? $set_as : null,
        'status' => $post->post_status,
        'active' => $post->post_status === 'draft',
        'modified' => kk_modified_gmt($post),
        'editor_mode' => kk_is_kirki_mode($post->ID),
        'has_data' => $data !== [],
        'root_id' => $root === null ? null : kk_truncate($root, max: 64),
        'root_element' => $root_node === null ? null : kk_truncate(kk_node_title($root_node), max: 120),
        'root_tag' => $root_node === null ? null : kk_truncate(kk_node_tag($root_node) ?? '', max: 32),
        'nodes_count' => count($data),
        'style_blocks_count' => is_array($styles) ? count($styles) : 0,
        'is_component' => is_array($meta['fields'] ?? null) && $meta['fields'] !== [],
        'fields_count' => is_array($meta['fields'] ?? null) ? count($meta['fields']) : 0,
        'override_keys' => kk_symbol_override_rows($post->ID, $data),
        'field_ids' => array_slice(array_keys(kk_symbol_override_keys($post->ID)['field']), offset: 0, length: 50),
    ];
}

/**
 * The keys an instance may override through `properties.symbolElProps`, as
 * Kirki matches them (`symbolElPropId` when the node has one, the node id
 * otherwise), with the element they reach. Bounded to 50 rows.
 *
 * @param array<string, mixed> $data
 * @return list<array{key: string, node_id: string, element: string}>
 */
function kk_symbol_override_rows(int $symbol_id, array $data): array
{
    $rows = [];
    foreach (kk_symbol_override_keys($symbol_id)['element'] as $key => $node_id) {
        /** @var mixed $name */
        $name = is_array($data[$node_id] ?? null) ? $data[$node_id]['name'] ?? '' : '';
        $rows[] = [
            'key' => kk_truncate($key, max: 64),
            'node_id' => kk_truncate($node_id, max: 64),
            'element' => kk_truncate(is_string($name) ? $name : '', max: 64),
        ];
        if (count($rows) === 50) {
            break;
        }
    }
    return $rows;
}

/**
 * Non-empty string value of a symbol-meta key, or null.
 *
 * @param array<string, mixed> $meta
 */
function kk_symbol_string(array $meta, string $key): ?string
{
    /** @var mixed $value */
    $value = $meta[$key] ?? null;
    return is_string($value) && $value !== '' ? $value : null;
}
