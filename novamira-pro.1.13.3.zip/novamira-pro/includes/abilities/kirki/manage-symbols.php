<?php

// SPDX-FileCopyrightText: 2026 Ovation S.r.l. <dev@novamira.ai>
// SPDX-License-Identifier: AGPL-3.0-or-later

declare(strict_types=1);

namespace Novamira\Pro\Abilities\Kirki;

use WP_Error;
use WP_Post;

/**
 * Abilities: Kirki symbols — the reusable pieces (`kirki_symbol` posts) a
 * page embeds through a `symbol` node, including the site header / footer.
 *
 * A symbol stores `{root, name, data, styleBlocks, category, setAs?}` under
 * the `kirki` meta: `data` is a FLAT node map whose root has `parentId` null
 * and `properties.symbolId` = the post id, every node carries a
 * `symbolElPropId` (the key page instances override), the style blocks are
 * flagged `isSymbolStyle`. The editor creates symbols in `draft` status with
 * an empty title and only lists / resolves draft ones; `setAs` header /
 * footer is exclusive (Kirki blanks it on the other draft symbols) and
 * renders on every page unless the page disables it. The editor edits a
 * symbol from whatever page tab is open, so every writer here refuses while
 * ANY editor tab is open. Kirki deletes symbols permanently and leaves page
 * instances dangling (they render nothing).
 */

if (!defined('ABSPATH')) {
    exit();
}

// Load order: this file's schemas use constants defined in other ability files of the folder; require them
// explicitly so the folder's alphabetical load order does not decide whether this file loads.
require_once __DIR__ . '/tree.php'; // KK_MAX_SYMBOL_NODES and KK_ALLOW_OPEN_EDITOR_SCHEMA

const KK_SYMBOL_NAME_BYTES = 200;

const KK_SYMBOL_CATEGORY_BYTES = 64;

const KK_SYMBOL_DEFAULT_CATEGORY = 'Others';

const KK_SYMBOL_GET_DEFAULT_NODES = 500;

/**
 * The lock subject of the exclusive header / footer roles: the invariant spans
 * every symbol, so a per-post lock cannot hold it (`kk_with_lock`).
 */
const KK_SYMBOL_ROLE_LOCK = 'symbol-roles';

/** Characters a symbol name / category may not carry (the editor lists them as text; keep them plain). */
const KK_SYMBOL_TEXT_PATTERN = '/[<>\x00-\x08\x0B\x0C\x0E-\x1F]/';

const KK_SYMBOL_BLOCKS_SCHEMA = [
    'type' => 'object',
    'description' => 'Flat node map `{id: node}` with exactly ONE root: the node nobody lists in `children` (its `parentId` null), a container element (section, div, container…). Nodes use the page shape (`name`, `properties`, `styleIds`, `children`…); no `root` / `body` nodes, no nested `symbol`. Ids are re-generated on write (`id_map` tells the mapping) except ids that already name a stored node of this symbol.',
];

const KK_SYMBOL_STYLES_SCHEMA = [
    'type' => 'object',
    'description' => 'Style blocks the nodes reference through `styleIds`, keyed by id, same shape as kirki-set-content (`{id, type: "class", name, variant: {md: "css declarations", …}}`); stored with `isSymbolStyle: true`. Global classes (kirki-list-global-classes) resolve too.',
];

const KK_SYMBOL_WRITE_OUTPUT = [
    'symbol_id' => ['type' => 'integer'],
    'name' => ['type' => 'string'],
    'category' => ['type' => 'string'],
    'root_id' => ['type' => 'string', 'description' => 'Stored id of the root node.'],
    'set_as' => ['type' => ['string', 'null'], 'enum' => ['header', 'footer', null]],
    'status' => ['type' => 'string'],
    'active' => [
        'type' => 'boolean',
        'description' => 'Whether the editor lists it and the header / footer resolver sees it (status `draft`).',
    ],
    'nodes_count' => ['type' => 'integer'],
    'style_blocks_count' => ['type' => 'integer'],
    'id_map' => ['type' => 'object', 'description' => 'Input node id → stored node id.'],
    'override_keys' => [
        'type' => 'array',
        'items' => ['type' => 'object'],
        'description' => 'The keys a page instance may override through `properties.symbolElProps` (`{key, node_id, element}`).',
    ],
    'displaced_symbol_id' => [
        'type' => ['integer', 'null'],
        'description' => 'The symbol that lost the header / footer assignment, when `set_as` took it over.',
    ],
    'warnings' => ['type' => 'array', 'items' => ['type' => 'string']],
];

// ---------------------------------------------------------------------------
// get-symbol
// ---------------------------------------------------------------------------

wp_register_ability('novamira/kirki-get-symbol', [
    'label' => __('Get Kirki Symbol', domain: 'novamira-pro'),
    'description' => __(
        'Reads one Kirki symbol (header, footer or component) as stored: name, category, `set_as`, status and whether the editor sees it (`active`: draft symbols only), the root node id, the flat node map (`blocks`, root first, breadth-first, truncated to `max_nodes`), its style blocks, the override keys page instances may use, where it is embedded (`usage`: posts whose published tree or staged copies hold a `symbol` node pointing at it, with the node ids) and whether any Kirki editor tab is open. This is the read to pair with kirki-set-symbol-content: pass `blocks` / `style_blocks` back with your changes. Pages, templates and popups are refused (read them with kirki-get-content).',
        domain: 'novamira-pro',
    ),
    'category' => 'kirki',
    'input_schema' => [
        'type' => 'object',
        'properties' => [
            'symbol_id' => ['type' => 'integer', 'description' => 'The `kirki_symbol` post (kirki-list-symbols).'],
            'include_style_blocks' => ['type' => 'boolean', 'description' => 'Return the style blocks (default true).'],
            'max_nodes' => [
                'type' => 'integer',
                'minimum' => 1,
                'maximum' => KK_MAX_SYMBOL_NODES,
                'description' => 'Nodes returned at most (default 500), root first, breadth-first; `truncated` says whether some were left out.',
            ],
        ],
        'required' => ['symbol_id'],
        'additionalProperties' => false,
    ],
    'output_schema' => [
        'type' => 'object',
        'properties' => [
            'symbol_id' => ['type' => 'integer'],
            'name' => ['type' => ['string', 'null']],
            'category' => ['type' => 'string'],
            'set_as' => ['type' => ['string', 'null']],
            'status' => ['type' => 'string'],
            'active' => ['type' => 'boolean'],
            'root_id' => ['type' => ['string', 'null']],
            'blocks' => ['type' => 'object', 'description' => 'Node map as stored (`id: node`).'],
            'style_blocks' => ['type' => 'object'],
            'total_nodes' => ['type' => 'integer'],
            'returned_nodes' => ['type' => 'integer'],
            'truncated' => ['type' => 'boolean'],
            'is_component' => [
                'type' => 'boolean',
                'description' => 'Carries component field bindings (`fields`), which these abilities never write.',
            ],
            'override_keys' => ['type' => 'array', 'items' => ['type' => 'object']],
            'usage' => [
                'type' => 'array',
                'items' => ['type' => 'object'],
                'description' => 'Posts embedding the symbol: `{post_id, post_type, status, title, published_tree, node_ids}` (`published_tree` false = only a staged draft holds the instance).',
            ],
            'editor_open_any' => [
                'type' => ['object', 'null'],
                'description' => '`{sessions, newest_age_seconds}` across every post; the writers refuse while it is non-zero.',
            ],
            'warnings' => ['type' => 'array', 'items' => ['type' => 'string']],
        ],
        'required' => [
            'symbol_id',
            'name',
            'category',
            'set_as',
            'status',
            'active',
            'root_id',
            'blocks',
            'style_blocks',
            'total_nodes',
            'returned_nodes',
            'truncated',
            'is_component',
            'override_keys',
            'usage',
            'editor_open_any',
            'warnings',
        ],
        'additionalProperties' => false,
    ],
    'execute_callback' => 'Novamira\\Pro\\Abilities\\Kirki\\kirki_get_symbol',
    'permission_callback' => 'novamira_permission_callback',
    'meta' => [
        'show_in_rest' => true,
        'mcp' => ['public' => true],
        'annotations' => [
            'instructions' => 'Read before kirki-set-symbol-content or kirki-delete-symbol: `blocks` is what you send back (keep the stored ids of the nodes you keep, so page overrides keyed on them survive), `usage` is what a delete would leave dangling.',
            'readonly' => true,
            'destructive' => false,
            'idempotent' => true,
        ],
    ],
]);

/**
 * @param array<string, mixed> $input
 * @return array<string, mixed>|WP_Error
 */
// @mago-expect lint:cyclomatic-complexity -- one refusal per branch, all flat
function kirki_get_symbol(array $input): array|WP_Error
{
    kk_begin();
    $symbol_id = kk_coerce_int_or_null($input['symbol_id'] ?? null) ?? 0;
    $post = kk_symbol_post_or_error($symbol_id);
    if ($post instanceof WP_Error) {
        return $post;
    }
    $meta = kk_symbol_meta($symbol_id) ?? [];
    $max = kk_coerce_int_or_null($input['max_nodes'] ?? null) ?? KK_SYMBOL_GET_DEFAULT_NODES;
    /** @var array<string, mixed> $data */
    $data = is_array($meta['data'] ?? null) ? $meta['data'] : [];
    $root = kk_symbol_string($meta, key: 'root');
    $ordered = kk_symbol_ordered_ids($data, $root);
    $blocks = [];
    foreach (array_slice($ordered, offset: 0, length: $max) as $id) {
        $blocks[$id] = $data[$id];
    }
    $warnings = kk_symbol_status_warnings($post);
    if ($meta === []) {
        $warnings[] = sprintf(
            'Symbol %d has no `kirki` meta (or a malformed one): nothing renders for it.',
            $symbol_id,
        );
    }
    $set_as = kk_symbol_string($meta, key: 'setAs');
    return [
        'symbol_id' => $symbol_id,
        'name' => kk_symbol_string($meta, key: 'name'),
        'category' => kk_symbol_string($meta, key: 'category') ?? 'other',
        'set_as' => in_array($set_as, KK_SYMBOL_SET_AS, strict: true) ? $set_as : null,
        'status' => $post->post_status,
        'active' => $post->post_status === 'draft',
        'root_id' => $root,
        'blocks' => $blocks,
        'style_blocks' => kk_bool($input['include_style_blocks'] ?? true) && is_array($meta['styleBlocks'] ?? null)
            ? $meta['styleBlocks']
            : [],
        'total_nodes' => count($data),
        'returned_nodes' => count($blocks),
        'truncated' => count($blocks) < count($data),
        'is_component' => is_array($meta['fields'] ?? null) && $meta['fields'] !== [],
        'override_keys' => kk_symbol_override_rows($symbol_id, $data),
        'usage' => kk_symbol_usage($symbol_id),
        'editor_open_any' => kk_open_editor_sessions_any(),
        'warnings' => $warnings,
    ];
}

/**
 * Node ids of a symbol map, root first then breadth-first through
 * `children`, unreachable nodes last.
 *
 * @param array<string, mixed> $data
 * @return list<string>
 */
function kk_symbol_ordered_ids(array $data, ?string $root): array
{
    $ordered = [];
    $queue = $root !== null && isset($data[$root]) ? [$root] : [];
    while ($queue !== []) {
        $id = array_shift($queue);
        if (isset($ordered[$id]) || !is_array($data[$id] ?? null)) {
            continue;
        }
        $ordered[$id] = true;
        foreach (kk_node_child_ids(kk_node_map($data[$id])) as $child) {
            $queue[] = $child;
        }
    }
    foreach (array_keys($data) as $id) {
        $ordered[strval($id)] = true;
    }
    return array_keys($ordered);
}

/**
 * Warnings about a symbol's status: Kirki's editor list and its header /
 * footer resolver read `draft` symbols only.
 *
 * @return list<string>
 */
function kk_symbol_status_warnings(WP_Post $post): array
{
    if ($post->post_status === 'draft') {
        return [];
    }
    return [sprintf(
        'Symbol %d has status `%s`: Kirki\'s editor lists and resolves header / footer symbols in `draft` status only (the status it creates them with); page instances still render it. Set the status with novamira/update-post.',
        $post->ID,
        $post->post_status,
    )];
}

// ---------------------------------------------------------------------------
// create-symbol
// ---------------------------------------------------------------------------

wp_register_ability('novamira/kirki-create-symbol', [
    'label' => __('Create Kirki Symbol', domain: 'novamira-pro'),
    'description' => __(
        'Creates a Kirki symbol (a reusable piece: site header, footer or component) from a flat node map with one container root, the way the editor\'s "Create component" does: a `kirki_symbol` post in `draft` status (the status the editor lists and resolves; the WordPress title stays empty, the name lives in the symbol data), every node re-identified and given the `symbolElPropId` page instances override, the root marked with the symbol id, the style blocks flagged as symbol styles, the editor-mode marker set. Nodes follow the page rules (element vocabulary, attributes, css, raw sinks refused); no `root` / `body` nodes and no nested `symbol`. `set_as: header|footer` assigns it site-wide at once (exclusive: the symbol holding that role loses it, `displaced_symbol_id`). Written in one transaction under the post lock, read back and verified; a refused write leaves no post behind. Embed it in a page with kirki-add-element (`{"name":"symbol","properties":{"symbolId":<id>}}`). Refused while ANY Kirki editor tab is open (`kirki_editor_open`): the editor edits symbols from whatever page it has open.',
        domain: 'novamira-pro',
    ),
    'category' => 'kirki',
    'input_schema' => [
        'type' => 'object',
        'properties' => [
            'name' => [
                'type' => 'string',
                'description' => 'Symbol name shown in the editor\'s Assets → Components (1–200 bytes, no markup).',
            ],
            'blocks' => KK_SYMBOL_BLOCKS_SCHEMA,
            'styles' => KK_SYMBOL_STYLES_SCHEMA,
            'category' => ['type' => 'string', 'description' => 'Editor category label (default `Others`).'],
            'set_as' => [
                'type' => 'string',
                'enum' => ['header', 'footer'],
                'description' => 'Assign the new symbol as the site header or footer.',
            ],
            'allow_open_editor' => KK_ALLOW_OPEN_EDITOR_SCHEMA,
        ],
        'required' => ['name', 'blocks'],
        'additionalProperties' => false,
    ],
    'output_schema' => [
        'type' => 'object',
        'properties' => KK_SYMBOL_WRITE_OUTPUT,
        'required' => array_keys(KK_SYMBOL_WRITE_OUTPUT),
        'additionalProperties' => false,
    ],
    'execute_callback' => 'Novamira\\Pro\\Abilities\\Kirki\\kirki_create_symbol',
    'permission_callback' => 'novamira_permission_callback',
    'meta' => [
        'show_in_rest' => true,
        'mcp' => ['public' => true],
        'annotations' => [
            'instructions' => 'Build the map like a page subtree: one container root (section / div) listing its children, text elements with `text`-style `properties.contents`, css in `styles` referenced through `styleIds`. Use `set_as` for a header / footer; place components in pages with kirki-add-element. Verify on a public page: a header prints with classes prefixed `kirki-s<id>-`.',
            'readonly' => false,
            'destructive' => false,
            'idempotent' => false,
        ],
    ],
]);

/**
 * @param array<string, mixed> $input
 * @return array<string, mixed>|WP_Error
 */
// @mago-expect lint:cyclomatic-complexity -- one refusal per branch, all flat
function kirki_create_symbol(array $input): array|WP_Error
{
    kk_begin();
    $name_error = kk_symbol_text_error(
        $input['name'] ?? null,
        field: 'name',
        cap: KK_SYMBOL_NAME_BYTES,
        required: true,
    );
    $category_error = kk_symbol_text_error(
        $input['category'] ?? null,
        field: 'category',
        cap: KK_SYMBOL_CATEGORY_BYTES,
        required: false,
    );
    $set_as = kk_symbol_set_as_input($input['set_as'] ?? null, allow_none: false);
    $errors = array_filter([
        $name_error,
        $category_error,
        $set_as instanceof WP_Error ? $set_as->get_error_message() : null,
    ]);
    if ($errors !== []) {
        return kk_invalid_input(implode(' ', $errors));
    }
    $tree = kk_symbol_tree_input($input, stored_data: []);
    if ($tree instanceof WP_Error) {
        return $tree;
    }
    $open = kk_refuse_open_editor_global($input['allow_open_editor'] ?? false);
    if ($open instanceof WP_Error) {
        return $open;
    }
    $symbol_id = wp_insert_post(['post_type' => kk_symbol_post_type(), 'post_status' => 'draft'], wp_error: true);
    if ($symbol_id instanceof WP_Error) {
        return new WP_Error(
            'kirki_create_failed',
            __('WordPress refused to insert the symbol post.', domain: 'novamira-pro'),
            ['status' => 500],
        );
    }
    $built = kk_symbol_data_from_blocks($tree['blocks'], $tree['styles'], $symbol_id, $tree['root']);
    /** @var string $name */
    $name = $input['name'];
    $meta = [
        'root' => $built['root'],
        'name' => $name,
        'data' => $built['data'],
        'styleBlocks' => $built['styleBlocks'],
        'category' => is_string($input['category'] ?? null) && $input['category'] !== ''
            ? $input['category']
            : KK_SYMBOL_DEFAULT_CATEGORY,
    ];
    $written = kk_with_post_lock($symbol_id, static fn(): array|WP_Error => kk_db_transaction($symbol_id, static function () use (
        $symbol_id,
        $meta,
        $set_as,
    ): array|WP_Error {
        $ok = kk_write_meta_verified($symbol_id, [
            kk_meta_blocks() => $meta,
            kk_meta_editor_mode() => KK_EDITOR_MODE,
        ]);
        if ($ok instanceof WP_Error) {
            return $ok;
        }
        return is_string($set_as) ? kk_symbol_assign($symbol_id, $set_as) : ['displaced' => null];
    }));
    if ($written instanceof WP_Error) {
        wp_delete_post($symbol_id, force_delete: true);
        return $written;
    }
    $warnings = array_merge($tree['warnings'], is_string($set_as) ? kk_symbol_assign_warnings($set_as) : []);
    return kk_symbol_write_report($symbol_id, $built['id_map'], $written['displaced'], $warnings);
}

// ---------------------------------------------------------------------------
// set-symbol-content
// ---------------------------------------------------------------------------

wp_register_ability('novamira/kirki-set-symbol-content', [
    'label' => __('Set Kirki Symbol Content', domain: 'novamira-pro'),
    'description' => __(
        'Replaces the node map and style blocks of a Kirki symbol (and, when given, its name / category), the way the editor\'s symbol editing saves: the stored `data` / `styleBlocks` are swapped whole, `setAs` and component fields are kept. Nodes whose id already names a stored node keep that id AND its `symbolElPropId`, so page instances overriding them keep matching; new nodes get fresh ids and keys (`id_map`). Same rules as kirki-create-symbol (one container root, page node rules, no nested symbol). Every page embedding the symbol and the site header / footer change at once. Written in one transaction under the post lock, read back and verified; identical content is a no-op. Refused while ANY Kirki editor tab is open (`kirki_editor_open`).',
        domain: 'novamira-pro',
    ),
    'category' => 'kirki',
    'input_schema' => [
        'type' => 'object',
        'properties' => [
            'symbol_id' => ['type' => 'integer', 'description' => 'The `kirki_symbol` post.'],
            'blocks' => KK_SYMBOL_BLOCKS_SCHEMA,
            'styles' => KK_SYMBOL_STYLES_SCHEMA,
            'name' => ['type' => 'string', 'description' => 'New name (1–200 bytes, no markup); omitted = unchanged.'],
            'category' => ['type' => 'string', 'description' => 'New category label; omitted = unchanged.'],
            'allow_open_editor' => KK_ALLOW_OPEN_EDITOR_SCHEMA,
        ],
        'required' => ['symbol_id', 'blocks'],
        'additionalProperties' => false,
    ],
    'output_schema' => [
        'type' => 'object',
        'properties' => KK_SYMBOL_WRITE_OUTPUT
            + [
                'written' => [
                    'type' => 'array',
                    'items' => ['type' => 'string'],
                    'description' => 'Stored keys that changed (`data`, `styleBlocks`, `root`, `name`, `category`); empty for a no-op.',
                ],
            ],
        'required' => array_merge(array_keys(KK_SYMBOL_WRITE_OUTPUT), ['written']),
        'additionalProperties' => false,
    ],
    'execute_callback' => 'Novamira\\Pro\\Abilities\\Kirki\\kirki_set_symbol_content',
    'permission_callback' => 'novamira_permission_callback',
    'meta' => [
        'show_in_rest' => true,
        'mcp' => ['public' => true],
        'annotations' => [
            'instructions' => 'Read the symbol with kirki-get-symbol, edit its `blocks` / `style_blocks` and send them back whole — keep the stored ids of the nodes you keep. Check kirki-get-symbol `usage` first: every embedding page changes.',
            'readonly' => false,
            'destructive' => true,
            'idempotent' => true,
        ],
    ],
]);

/**
 * @param array<string, mixed> $input
 * @return array<string, mixed>|WP_Error
 */
// @mago-expect lint:cyclomatic-complexity -- one refusal per branch, all flat
// @mago-expect lint:halstead
function kirki_set_symbol_content(array $input): array|WP_Error
{
    kk_begin();
    $symbol_id = kk_coerce_int_or_null($input['symbol_id'] ?? null) ?? 0;
    $post = kk_symbol_post_or_error($symbol_id);
    if ($post instanceof WP_Error) {
        return $post;
    }
    $name_error = kk_symbol_text_error(
        $input['name'] ?? null,
        field: 'name',
        cap: KK_SYMBOL_NAME_BYTES,
        required: false,
    );
    $category_error = kk_symbol_text_error(
        $input['category'] ?? null,
        field: 'category',
        cap: KK_SYMBOL_CATEGORY_BYTES,
        required: false,
    );
    $errors = array_filter([$name_error, $category_error]);
    if ($errors !== []) {
        return kk_invalid_input(implode(' ', $errors));
    }
    $stored = kk_symbol_meta($symbol_id) ?? [];
    /** @var array<string, mixed> $stored_data */
    $stored_data = is_array($stored['data'] ?? null) ? $stored['data'] : [];
    $tree = kk_symbol_tree_input($input, $stored_data);
    if ($tree instanceof WP_Error) {
        return $tree;
    }
    $open = kk_refuse_open_editor_global($input['allow_open_editor'] ?? false);
    if ($open instanceof WP_Error) {
        return $open;
    }
    $built = kk_symbol_data_from_blocks($tree['blocks'], $tree['styles'], $symbol_id, $tree['root'], $stored_data);
    $meta = $stored;
    $meta['root'] = $built['root'];
    $meta['data'] = $built['data'];
    $meta['styleBlocks'] = $built['styleBlocks'];
    if (!isset($meta['name']) || !is_string($meta['name'])) {
        $meta['name'] = '';
    }
    if (is_string($input['name'] ?? null)) {
        $meta['name'] = $input['name'];
    }
    if (is_string($input['category'] ?? null) && $input['category'] !== '') {
        $meta['category'] = $input['category'];
    }
    $meta['category'] = is_string($meta['category'] ?? null) ? $meta['category'] : KK_SYMBOL_DEFAULT_CATEGORY;
    $changed = kk_symbol_changed_keys($stored, $meta);
    $written = kk_with_post_lock($symbol_id, static function () use ($symbol_id, $meta, $changed): bool|WP_Error {
        if (kk_live_post($symbol_id) === null) {
            return kk_invalid_post($symbol_id);
        }
        if ($changed === []) {
            return true;
        }
        return kk_write_meta_verified($symbol_id, [kk_meta_blocks() => $meta, kk_meta_editor_mode() => KK_EDITOR_MODE]);
    });
    if ($written instanceof WP_Error) {
        return $written;
    }
    $report = kk_symbol_write_report($symbol_id, $built['id_map'], displaced: null, warnings: $tree['warnings']);
    $report['written'] = $changed;
    return $report;
}

/**
 * Stored keys whose value differs between the stored meta and the meta about
 * to be written (`data`, `styleBlocks`, `root`, `name`, `category`).
 *
 * @param array<string, mixed> $stored
 * @param array<string, mixed> $meta
 * @return list<string>
 */
function kk_symbol_changed_keys(array $stored, array $meta): array
{
    $changed = [];
    foreach (['data', 'styleBlocks', 'root', 'name', 'category'] as $key) {
        if (($stored[$key] ?? null) === ($meta[$key] ?? null)) {
            continue;
        }
        $changed[] = $key;
    }
    return $changed;
}

// ---------------------------------------------------------------------------
// set-symbol-as
// ---------------------------------------------------------------------------

wp_register_ability('novamira/kirki-set-symbol-as', [
    'label' => __('Set Kirki Symbol As Header Or Footer', domain: 'novamira-pro'),
    'description' => __(
        'Assigns a Kirki symbol as the site header or footer, or takes the role away (`none`), exactly as the editor\'s Assets → ⋯ → "Set As" / "Unset as" does: `setAs` is written on the symbol and blanked on every other draft symbol holding that role (`displaced_symbol_id`), so the role stays exclusive. Kirki prints the assigned symbol on every page at once (classes prefixed `kirki-s<id>-`), except pages that switched that section off in their settings (listed as a warning) and only while the symbol is in `draft` status (the resolver reads draft symbols only; a warning says so otherwise). Written in one transaction under the post lock, read back and verified. Refused while ANY Kirki editor tab is open (`kirki_editor_open`).',
        domain: 'novamira-pro',
    ),
    'category' => 'kirki',
    'input_schema' => [
        'type' => 'object',
        'properties' => [
            'symbol_id' => ['type' => 'integer', 'description' => 'The `kirki_symbol` post.'],
            'set_as' => [
                'type' => 'string',
                'enum' => ['header', 'footer', 'none'],
                'description' => '`header`, `footer` or `none` (unset).',
            ],
            'allow_open_editor' => KK_ALLOW_OPEN_EDITOR_SCHEMA,
        ],
        'required' => ['symbol_id', 'set_as'],
        'additionalProperties' => false,
    ],
    'output_schema' => [
        'type' => 'object',
        'properties' => [
            'symbol_id' => ['type' => 'integer'],
            'set_as' => [
                'type' => ['string', 'null'],
                'description' => 'The stored role after the call (null = none).',
            ],
            'displaced_symbol_id' => ['type' => ['integer', 'null']],
            'header_symbol_id' => [
                'type' => ['integer', 'null'],
                'description' => 'The symbol Kirki resolves as header after the call.',
            ],
            'footer_symbol_id' => ['type' => ['integer', 'null']],
            'changed' => ['type' => 'boolean'],
            'warnings' => ['type' => 'array', 'items' => ['type' => 'string']],
        ],
        'required' => [
            'symbol_id',
            'set_as',
            'displaced_symbol_id',
            'header_symbol_id',
            'footer_symbol_id',
            'changed',
            'warnings',
        ],
        'additionalProperties' => false,
    ],
    'execute_callback' => 'Novamira\\Pro\\Abilities\\Kirki\\kirki_set_symbol_as',
    'permission_callback' => 'novamira_permission_callback',
    'meta' => [
        'show_in_rest' => true,
        'mcp' => ['public' => true],
        'annotations' => [
            'instructions' => 'Check kirki-list-symbols `header_symbol_id` / `footer_symbol_id` first: assigning displaces the current holder. Verify on any public page: the header / footer markup carries `kirki-s<id>-` classes.',
            'readonly' => false,
            'destructive' => false,
            'idempotent' => true,
        ],
    ],
]);

/**
 * @param array<string, mixed> $input
 * @return array<string, mixed>|WP_Error
 */
// @mago-expect lint:cyclomatic-complexity -- one refusal per branch, all flat
function kirki_set_symbol_as(array $input): array|WP_Error
{
    kk_begin();
    $symbol_id = kk_coerce_int_or_null($input['symbol_id'] ?? null) ?? 0;
    $post = kk_symbol_post_or_error($symbol_id);
    if ($post instanceof WP_Error) {
        return $post;
    }
    $set_as = kk_symbol_set_as_input($input['set_as'] ?? null, allow_none: true);
    if ($set_as instanceof WP_Error) {
        return $set_as;
    }
    if (kk_symbol_meta($symbol_id) === null) {
        return kk_invalid_input(sprintf(
            /* translators: %d: symbol id */
            __(
                'Symbol %d has no symbol data: give it content with kirki-set-symbol-content first.',
                domain: 'novamira-pro',
            ),
            $symbol_id,
        ));
    }
    $open = kk_refuse_open_editor_global($input['allow_open_editor'] ?? false);
    if ($open instanceof WP_Error) {
        return $open;
    }
    $role = $set_as === 'none' ? '' : (string) $set_as;
    // The header / footer roles are exclusive ACROSS symbols: the post lock of
    // the symbol being written says nothing about the one holding the role, so
    // two calls claiming `header` for two different symbols would never meet.
    // The role registry is locked first, the symbol second (owner → target).
    $written = kk_with_lock(
        KK_SYMBOL_ROLE_LOCK,
        static fn(): array|WP_Error => kk_with_post_lock($symbol_id, static function () use (
            $symbol_id,
            $role,
        ): array|WP_Error {
            if (kk_live_post($symbol_id) === null) {
                return kk_invalid_post($symbol_id);
            }
            return kk_db_transaction($symbol_id, static fn(): array|WP_Error => kk_symbol_assign($symbol_id, $role));
        }),
        subject: 'the site header / footer roles',
    );
    if ($written instanceof WP_Error) {
        return $written;
    }
    $after = kk_symbol_string(kk_symbol_meta($symbol_id) ?? [], key: 'setAs');
    $warnings = kk_symbol_status_warnings($post);
    if ($role !== '') {
        $warnings = array_merge($warnings, kk_symbol_assign_warnings($role));
    }
    $header = kk_symbols_set_as('header');
    $footer = kk_symbols_set_as('footer');
    return [
        'symbol_id' => $symbol_id,
        'set_as' => in_array($after, KK_SYMBOL_SET_AS, strict: true) ? $after : null,
        'displaced_symbol_id' => $written['displaced'],
        'header_symbol_id' => $header[0] ?? null,
        'footer_symbol_id' => $footer[0] ?? null,
        'changed' => $written['changed'],
        'warnings' => $warnings,
    ];
}

/**
 * Write `setAs` on a symbol and, for a header / footer role, blank it on
 * every other symbol holding it — whatever its status, so a symbol published
 * in the meantime cannot bring the role back when it returns to draft — each
 * write verified. Runs inside the caller's lock and transaction.
 *
 * @return array{displaced: ?int, changed: bool}|WP_Error
 */
function kk_symbol_assign(int $symbol_id, string $role): array|WP_Error
{
    $displaced = null;
    if ($role !== '') {
        foreach (kk_symbols_set_as_any_status($role) as $other_id) {
            if ($other_id === $symbol_id) {
                continue;
            }
            $other = kk_symbol_meta($other_id);
            if ($other === null) {
                continue;
            }
            $other['setAs'] = '';
            $ok = kk_write_meta_verified($other_id, [kk_meta_blocks() => $other]);
            if ($ok instanceof WP_Error) {
                return $ok;
            }
            $displaced ??= $other_id;
        }
    }
    $meta = kk_symbol_meta($symbol_id);
    if ($meta === null) {
        return kk_invalid_post($symbol_id);
    }
    if (($meta['setAs'] ?? '') === $role) {
        return ['displaced' => $displaced, 'changed' => false];
    }
    $meta['setAs'] = $role;
    $ok = kk_write_meta_verified($symbol_id, [kk_meta_blocks() => $meta]);
    if ($ok instanceof WP_Error) {
        return $ok;
    }
    return ['displaced' => $displaced, 'changed' => true];
}

/**
 * Warnings that go with a header / footer assignment: the pages that switch
 * that section off.
 *
 * @return list<string>
 */
function kk_symbol_assign_warnings(string $role): array
{
    $disabled = kk_disabled_symbol_pages($role);
    if ($disabled === []) {
        return [];
    }
    return [sprintf(
        'The %s is switched off on post(s) %s (their `kirki_disabled_page_symbols` setting): the symbol never prints there.',
        $role,
        implode(', ', array_map('strval', $disabled)),
    )];
}

// ---------------------------------------------------------------------------
// delete-symbol
// ---------------------------------------------------------------------------

wp_register_ability('novamira/kirki-delete-symbol', [
    'label' => __('Delete Kirki Symbol', domain: 'novamira-pro'),
    'description' => __(
        'Deletes a Kirki symbol PERMANENTLY, as the editor\'s Assets → ⋯ → Delete does (Kirki keeps no trash for symbols). Refused (`kirki_symbol_in_use`) while the symbol is the site header / footer or while a page\'s published tree or staged copy embeds it, unless `force: true`: Kirki leaves such instances dangling — a `symbol` node pointing at a deleted symbol renders nothing, silently — and the response lists them (`dangling`) so you can remove them with kirki-delete-element. The deletion is verified (the post row must be gone). Refused while ANY Kirki editor tab is open (`kirki_editor_open`).',
        domain: 'novamira-pro',
    ),
    'category' => 'kirki',
    'input_schema' => [
        'type' => 'object',
        'properties' => [
            'symbol_id' => ['type' => 'integer', 'description' => 'The `kirki_symbol` post.'],
            'force' => [
                'type' => 'boolean',
                'description' => 'Delete even when the symbol is the header / footer or embedded in pages (instances go dangling). Default false.',
            ],
            'allow_open_editor' => KK_ALLOW_OPEN_EDITOR_SCHEMA,
        ],
        'required' => ['symbol_id'],
        'additionalProperties' => false,
    ],
    'output_schema' => [
        'type' => 'object',
        'properties' => [
            'symbol_id' => ['type' => 'integer'],
            'deleted' => ['type' => 'boolean'],
            'was_set_as' => ['type' => ['string', 'null']],
            'dangling' => [
                'type' => 'array',
                'items' => ['type' => 'object'],
                'description' => 'Posts whose trees still hold instances of the deleted symbol: `{post_id, post_type, status, title, published_tree, node_ids}`.',
            ],
            'warnings' => ['type' => 'array', 'items' => ['type' => 'string']],
        ],
        'required' => ['symbol_id', 'deleted', 'was_set_as', 'dangling', 'warnings'],
        'additionalProperties' => false,
    ],
    'execute_callback' => 'Novamira\\Pro\\Abilities\\Kirki\\kirki_delete_symbol',
    'permission_callback' => 'novamira_permission_callback',
    'meta' => [
        'show_in_rest' => true,
        'mcp' => ['public' => true],
        'annotations' => [
            'instructions' => 'Read kirki-get-symbol `usage` and `set_as` first. Without `force` the call only succeeds for an unused symbol; with `force`, remove the dangling `symbol` nodes it reports from each page.',
            'readonly' => false,
            'destructive' => true,
            'idempotent' => false,
        ],
    ],
]);

/**
 * @param array<string, mixed> $input
 * @return array<string, mixed>|WP_Error
 */
// @mago-expect lint:cyclomatic-complexity -- one refusal per branch, all flat
function kirki_delete_symbol(array $input): array|WP_Error
{
    kk_begin();
    $symbol_id = kk_coerce_int_or_null($input['symbol_id'] ?? null) ?? 0;
    $post = kk_symbol_post_or_error($symbol_id);
    if ($post instanceof WP_Error) {
        return $post;
    }
    $meta = kk_symbol_meta($symbol_id) ?? [];
    $set_as = kk_symbol_string($meta, key: 'setAs');
    $was_set_as = in_array($set_as, KK_SYMBOL_SET_AS, strict: true) ? $set_as : null;
    $usage = kk_symbol_usage($symbol_id);
    if (!kk_bool($input['force'] ?? false) && ($was_set_as !== null || $usage !== [])) {
        return kk_symbol_in_use_error($symbol_id, $was_set_as, $usage);
    }
    $open = kk_refuse_open_editor_global($input['allow_open_editor'] ?? false);
    if ($open instanceof WP_Error) {
        return $open;
    }
    $deleted = kk_with_post_lock($symbol_id, static function () use ($symbol_id): bool|WP_Error {
        if (kk_live_post($symbol_id) === null) {
            return kk_invalid_post($symbol_id);
        }
        $result = wp_delete_post($symbol_id, force_delete: true);
        clean_post_cache($symbol_id);
        if ($result === false || $result === null || get_post($symbol_id) !== null) {
            return new WP_Error(
                'kirki_write_failed',
                sprintf(
                    /* translators: %d: symbol id */
                    __(
                        'WordPress did not delete symbol %d (a hook refused it or the row is still there).',
                        domain: 'novamira-pro',
                    ),
                    $symbol_id,
                ),
                ['status' => 500],
            );
        }
        return true;
    });
    if ($deleted instanceof WP_Error) {
        return $deleted;
    }
    $warnings = [];
    if ($usage !== []) {
        $warnings[] = 'Instances of the deleted symbol remain in the listed posts: each `symbol` node renders nothing until removed with kirki-delete-element.';
    }
    if ($was_set_as !== null) {
        $warnings[] = sprintf('The site has no %s now.', $was_set_as);
    }
    return [
        'symbol_id' => $symbol_id,
        'deleted' => true,
        'was_set_as' => $was_set_as,
        'dangling' => $usage,
        'warnings' => $warnings,
    ];
}

/**
 * The refusal of a delete while the symbol is the header / footer or embedded.
 *
 * @param list<array{post_id: int, post_type: string, status: string, title: string, published_tree: bool, node_ids: list<string>}> $usage
 */
function kk_symbol_in_use_error(int $symbol_id, ?string $was_set_as, array $usage): WP_Error
{
    $reasons = [];
    if ($was_set_as !== null) {
        $reasons[] = sprintf('it is the site %s (kirki-set-symbol-as `none` first)', $was_set_as);
    }
    if ($usage !== []) {
        $reasons[] = sprintf('it is embedded in post(s) %s', implode(', ', array_map(
            static fn(array $row): string => sprintf(
                '%d (%s)',
                $row['post_id'],
                $row['node_ids'] === [] ? 'nodes not decoded' : implode(', ', $row['node_ids']),
            ),
            $usage,
        )));
    }
    return new WP_Error(
        'kirki_symbol_in_use',
        sprintf(
            /* translators: 1: symbol id, 2: reasons */
            __(
                'Symbol %1$d is in use: %2$s. Pass `force: true` to delete it anyway (Kirki leaves the instances dangling; they render nothing).',
                domain: 'novamira-pro',
            ),
            $symbol_id,
            implode('; ', $reasons),
        ),
        ['status' => 409],
    );
}

// ---------------------------------------------------------------------------
// Shared helpers of the symbol writers.
// ---------------------------------------------------------------------------

/** Error for a symbol name / category input, or null. */
// @mago-expect lint:no-boolean-flag-parameter -- required / optional text
function kk_symbol_text_error(mixed $value, string $field, int $cap, bool $required): ?string
{
    if ($value === null) {
        return $required ? sprintf('`%s` is required.', $field) : null;
    }
    if (!is_string($value) || $required && trim($value) === '') {
        return sprintf('`%s` must be a non-empty string.', $field);
    }
    if (strlen($value) > $cap) {
        return sprintf('`%s` exceeds %d bytes.', $field, $cap);
    }
    if (
        preg_match(KK_SYMBOL_TEXT_PATTERN, $value) === 1
        || preg_match(KK_SYMBOL_TEXT_PATTERN, kk_decode_entities($value)) === 1
    ) {
        return sprintf('`%s` must not contain angle brackets or control characters.', $field);
    }
    return null;
}

/** The `set_as` input: `header` / `footer` (and `none` where allowed), null when absent, or the refusal. */
// @mago-expect lint:no-boolean-flag-parameter -- whether `none` is a valid value
function kk_symbol_set_as_input(mixed $value, bool $allow_none): string|null|WP_Error
{
    if ($value === null) {
        return null;
    }
    $allowed = $allow_none ? array_merge(KK_SYMBOL_SET_AS, ['none']) : KK_SYMBOL_SET_AS;
    if (!is_string($value) || !in_array($value, $allowed, strict: true)) {
        return kk_invalid_input(sprintf('`set_as` must be one of %s.', implode(', ', $allowed)));
    }
    return $value;
}

/**
 * The validated symbol tree of a create / set-content input.
 *
 * @param array<string, mixed> $input
 * @param array<string, mixed> $stored_data
 * @return array{blocks: array<string, mixed>, styles: array<string, array<string, mixed>>, root: string, warnings: list<string>}|WP_Error
 */
function kk_symbol_tree_input(array $input, array $stored_data): array|WP_Error
{
    /** @var mixed $raw_blocks */
    $raw_blocks = $input['blocks'] ?? null;
    if (!is_array($raw_blocks) || $raw_blocks === []) {
        return kk_invalid_input(__('blocks must be a non-empty object map of nodes.', domain: 'novamira-pro'));
    }
    /** @var mixed $raw_styles */
    $raw_styles = $input['styles'] ?? [];
    if (!is_array($raw_styles)) {
        return kk_invalid_input(__('styles must be an object map of style blocks.', domain: 'novamira-pro'));
    }
    $encoded = wp_json_encode([$raw_blocks, $raw_styles]);
    if (!is_string($encoded) || strlen($encoded) > KK_MAX_TREE_BYTES) {
        return new WP_Error(
            'kirki_too_large',
            sprintf(
                /* translators: %d: byte cap */
                __('The symbol content exceeds %d bytes (or cannot be encoded as JSON).', domain: 'novamira-pro'),
                KK_MAX_TREE_BYTES,
            ),
            ['status' => 413],
        );
    }
    $styles = kk_coerce_styles($raw_styles);
    if ($styles instanceof WP_Error) {
        return $styles;
    }
    $blocks = kk_coerce_blocks($raw_blocks);
    if ($blocks instanceof WP_Error) {
        return $blocks;
    }
    $verdict = kk_validate_symbol_tree($blocks, $styles, kk_node_map($stored_data));
    if ($verdict['errors'] !== []) {
        return kk_tree_error($verdict['errors']);
    }
    /** @var string $root */
    $root = $verdict['root'];
    return ['blocks' => $blocks, 'styles' => $styles, 'root' => $root, 'warnings' => $verdict['warnings']];
}

/**
 * The response of create / set-content, read back from the stored meta.
 *
 * @param array<string, string> $id_map
 * @param list<string> $warnings
 * @return array<string, mixed>
 */
function kk_symbol_write_report(int $symbol_id, array $id_map, ?int $displaced, array $warnings): array
{
    $post = kk_live_post($symbol_id);
    $meta = kk_symbol_meta($symbol_id) ?? [];
    /** @var array<string, mixed> $data */
    $data = is_array($meta['data'] ?? null) ? $meta['data'] : [];
    $set_as = kk_symbol_string($meta, key: 'setAs');
    return [
        'symbol_id' => $symbol_id,
        'name' => kk_symbol_string($meta, key: 'name') ?? '',
        'category' => kk_symbol_string($meta, key: 'category') ?? KK_SYMBOL_DEFAULT_CATEGORY,
        'root_id' => kk_symbol_string($meta, key: 'root') ?? '',
        'set_as' => in_array($set_as, KK_SYMBOL_SET_AS, strict: true) ? $set_as : null,
        'status' => $post === null ? '' : $post->post_status,
        'active' => $post !== null && $post->post_status === 'draft',
        'nodes_count' => count($data),
        'style_blocks_count' => is_array($meta['styleBlocks'] ?? null) ? count($meta['styleBlocks']) : 0,
        'id_map' => $id_map,
        'override_keys' => kk_symbol_override_rows($symbol_id, $data),
        'displaced_symbol_id' => $displaced,
        'warnings' => array_merge($post === null ? [] : kk_symbol_status_warnings($post), $warnings),
    ];
}
