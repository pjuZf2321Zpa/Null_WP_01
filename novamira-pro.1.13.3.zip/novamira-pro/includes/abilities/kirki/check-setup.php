<?php

// SPDX-FileCopyrightText: 2026 Ovation S.r.l. <dev@novamira.ai>
// SPDX-License-Identifier: AGPL-3.0-or-later

declare(strict_types=1);

namespace Novamira\Pro\Abilities\Kirki;

/**
 * Ability: Check Kirki setup and report environment status.
 */

if (!defined('ABSPATH')) {
    exit();
}

wp_register_ability('novamira/kirki-check-setup', [
    'label' => __('Check Kirki Setup', domain: 'novamira-pro'),
    'description' => __(
        'Reports the Kirki builder environment: Kirki version and floor, Kirki Pro presence and license state (Pro only changes the editor UI, never the stored data), the global-data post id, the viewport list the renderer uses for media queries, the current user\'s Kirki editor access level plus the per-role map, custom-table presence (forms, Content Manager references, collaboration), per-post-type counts of Kirki-mode content, whether the legacy Kirki Customizer Framework has fields registered by the active theme, and a list of detected issues. Call this BEFORE any other kirki-* ability.',
        domain: 'novamira-pro',
    ),
    'category' => 'kirki',
    'input_schema' => [
        'type' => 'object',
        'default' => [],
        'properties' => [],
        'additionalProperties' => false,
    ],
    'output_schema' => [
        'type' => 'object',
        'properties' => [
            'kirki' => [
                'type' => 'object',
                'properties' => [
                    'active' => ['type' => 'boolean'],
                    'version' => ['type' => 'string'],
                    'min_supported' => ['type' => 'string'],
                    'min_satisfied' => ['type' => 'boolean'],
                ],
            ],
            'kirki_pro' => [
                'type' => 'object',
                'properties' => [
                    'active' => ['type' => 'boolean'],
                    'version' => ['type' => 'string'],
                    'license_valid' => ['type' => 'boolean'],
                    'license_checked' => [
                        'type' => 'boolean',
                        'description' => 'False until Kirki Pro has run its first license check (dashboard opened once).',
                    ],
                ],
            ],
            'editor' => [
                'type' => 'object',
                'properties' => [
                    'editor_mode_value' => [
                        'type' => 'string',
                        'description' => 'Value the `kirki_editor_mode` postmeta must hold for the frontend to render a block tree.',
                    ],
                    'global_data_post_id' => ['type' => ['integer', 'null']],
                    'global_classes' => [
                        'type' => 'integer',
                        'description' => 'Global classes in the class manager (`kirki_class_manager_style_blocks` on the global-data post), the ones kirki-list-global-classes returns.',
                    ],
                    'viewports' => [
                        'type' => 'array',
                        'items' => ['type' => 'object'],
                        'description' => 'Viewports sorted as the renderer sorts them (by minWidth): `{id, title, width, min_width, max_width, query, is_base, renderer_ok}`. Style-block variant keys are prefixed with these ids (`md`, `md_hover`, `tablet`, …); `is_base` CSS is emitted without a media query, the others under `query` (max-width below md, min-width above); `renderer_ok: false` = the frontend fails on this entry.',
                    ],
                    'current_user_access' => [
                        'type' => 'string',
                        'enum' => ['full', 'editor', 'content', 'view', 'no'],
                        'description' => 'Kirki access level of the calling user: the strongest level its roles map to, `no` when none of them is in the map. It gates the editor UI and Kirki\'s own REST only; abilities are authorised by WordPress capabilities (`manage_options`; on multisite the super admin only), never by this level. Kirki compares a required level exactly, so `full` does not imply `editor` — a gate asking for `editor` refuses an administrator.',
                    ],
                    'role_access' => [
                        'type' => 'object',
                        'description' => 'Kirki\'s role → access level map. Hard-coded in the plugin since 6.3.2 (`AccessLevels::ROLE_ACCESS_MAP`: administrator `full`, editor `editor`, author `content`, subscriber `no`, every other role `no`) and not configurable: that release removed the Role Manager from the Settings panel.',
                    ],
                    'role_access_legacy_options' => [
                        'type' => 'object',
                        'description' => 'Leftover `kirki_<role>` options that still claim a level Kirki no longer applies, keyed by role (empty on a fresh install and on a site where they agree). Kirki stopped reading these options in 6.3.2; they are reported so nobody changes one expecting an effect. Safe to delete.',
                    ],
                ],
            ],
            'tables' => [
                'type' => 'object',
                'description' => 'Presence of each Kirki custom table, keyed by unprefixed name (per site on multisite).',
            ],
            'server' => [
                'type' => 'object',
                'description' => '`{memory_limit_bytes, max_execution_time, max_allowed_packet_bytes, multisite}` as this request sees them: the memory limit is what the abilities (and Kirki, whatever it asks for) actually get on the web; a write is refused before it starts when the tree would not fit (`kirki_too_large`).',
            ],
            'content' => [
                'type' => 'object',
                'description' => 'Counts per content kind: `{page, post, custom, template, popup, utility}` = posts in Kirki editor mode (any status except trash and auto-draft; `custom` = public custom post types); `symbols` and `collections` = Kirki CPT rows.',
            ],
            'customizer_framework' => [
                'type' => 'object',
                'properties' => [
                    'loaded' => ['type' => 'boolean'],
                    'fields_registered' => ['type' => 'integer'],
                ],
                'description' => 'The legacy Kirki Customizer Framework bundled in the plugin. `fields_registered` > 0 means the active theme registers Customizer fields through it; 0 means the framework is idle on this site.',
            ],
            'issues' => [
                'type' => 'array',
                'items' => ['type' => 'string'],
                'description' => 'Detected configuration issues or capability gaps.',
            ],
        ],
        'required' => ['kirki', 'kirki_pro', 'editor', 'tables', 'server', 'content', 'customizer_framework', 'issues'],
        'additionalProperties' => false,
    ],
    'execute_callback' => 'Novamira\\Pro\\Abilities\\Kirki\\kirki_check_setup',
    'permission_callback' => 'novamira_permission_callback',
    'meta' => [
        'show_in_rest' => true,
        'mcp' => ['public' => true],
        'annotations' => [
            'instructions' => 'Run this at the start of any Kirki work. Key signals: the kirki-* abilities exist only when Kirki ≥ 6.4.0 is active (below the floor they are not registered at all, so `kirki.min_satisfied` is always true when this call works), editor.viewports (the ids you must use in style-block variant keys), editor.current_user_access (what the user will be able to open in the editor), content counts (whether the site already has Kirki-built pages to read with kirki-list-pages), customizer_framework.fields_registered (non-zero only when the theme uses the legacy Customizer API — unrelated to the builder). The `issues` array summarizes actionable warnings.',
            'readonly' => true,
            'destructive' => false,
            'idempotent' => true,
        ],
    ],
]);

/**
 * @return array<string, mixed>
 */
// @mago-expect lint:cyclomatic-complexity -- one issue rule per signal, all flat
// @mago-expect lint:halstead
function kirki_check_setup(): array
{
    kk_begin();
    $kirki = kk_detect_setup();
    $pro = kk_detect_pro();
    $tables = kk_tables_present();
    $framework = kk_detect_customizer_framework();
    $global_post_id = kk_global_data_post_id();
    $content = kk_check_setup_content_counts();

    $issues = [];
    if (!$kirki['min_satisfied']) {
        $issues[] = sprintf(
            'Kirki %s is below the minimum supported version %s.',
            $kirki['version'],
            $kirki['min_supported'],
        );
    }
    if ($pro['active'] && !$pro['license_valid']) {
        $issues[] = $pro['license_checked']
            ? 'Kirki Pro is active but its license is not valid: Pro-only editor features are locked in the UI (server data is unaffected).'
            : 'Kirki Pro is active but has not checked its license yet (open the Kirki dashboard once); until then Pro-only editor features are locked in the UI (server data is unaffected).';
    }
    $global_issue = kk_global_data_post_issue();
    if ($global_issue !== null) {
        $issues[] = $global_issue;
    }
    foreach ($tables as $table => $present) {
        if ($present) {
            continue;
        }
        $issues[] = sprintf('Custom table %s is missing (Kirki migrations did not run).', $table);
    }
    $viewports = kk_viewports();
    $broken = array_filter($viewports, static fn(array $v): bool => !$v['renderer_ok']);
    if ($broken !== []) {
        $issues[] = sprintf(
            'Viewport(s) %s in the stored list (kirki_user_controller) lack a numeric minWidth / maxWidth: Kirki\'s frontend renderer fails on them (array_multisort ValueError, blank page); the editor must resave its viewport settings.',
            implode(', ', array_column($broken, 'id')),
        );
    }
    if ($viewports === []) {
        $issues[] = 'The stored viewport list (kirki_user_controller) is empty: Kirki emits the base (md) CSS only and drops every other viewport variant on the frontend.';
    }
    if ($viewports !== [] && array_filter($viewports, static fn(array $v): bool => $v['is_base']) === []) {
        $issues[] = 'The stored viewport list has no `md` entry: only media-query variants render, no base CSS.';
    }
    foreach (kk_const_drift() as $ref) {
        $issues[] = sprintf(
            'Kirki constant %s is missing or not a string in this Kirki version; the 6.3.0 literal is used instead — readers and writers may point at the wrong key.',
            $ref,
        );
    }
    $access = kk_current_user_access_level();
    if ($access === 'no') {
        $issues[] = wp_get_current_user()->roles === []
            ? 'The current user has no role on this site (a multisite super admin not added to the site): abilities still work, but Kirki\'s editor gate has no super-admin bypass — add the user to this site as administrator to open the editor.'
            : 'The current user has no Kirki access: none of its roles is in Kirki\'s role map (administrator, editor, author, subscriber). Abilities still work, but this user cannot open the Kirki editor to review changes, and the map is not configurable since Kirki 6.3.2.';
    }
    $server = kk_server_limits();
    if ($server['max_allowed_packet_bytes'] !== null && $server['max_allowed_packet_bytes'] < 16_777_216) {
        $issues[] = sprintf(
            'MySQL max_allowed_packet is %d bytes: a page tree larger than that cannot be saved (the abilities refuse with kirki_too_large; Kirki\'s editor would lose the save).',
            $server['max_allowed_packet_bytes'],
        );
    }
    $role_access = kk_role_access_map();
    $legacy_options = kk_legacy_role_options($role_access);
    if ($legacy_options !== []) {
        $pairs = [];
        foreach (array_keys($legacy_options) as $role) {
            $pairs[] = sprintf(
                '%s claims %s, Kirki applies %s',
                $role,
                $legacy_options[$role],
                $role_access[$role] ?? 'no',
            );
        }
        $issues[] = sprintf(
            'Leftover kirki_<role> options from a Kirki older than 6.3.2 still hold a level the plugin ignores (%s). Kirki now reads a hard-coded role map and the Role Manager is gone from its Settings panel, so changing these options has no effect.',
            implode('; ', $pairs),
        );
    }

    return [
        'kirki' => $kirki,
        'kirki_pro' => $pro,
        'editor' => [
            'editor_mode_value' => KK_EDITOR_MODE,
            'global_data_post_id' => $global_post_id,
            'global_classes' => count(kk_global_style_maps()['class_manager']),
            'viewports' => $viewports,
            'current_user_access' => $access,
            'role_access' => $role_access,
            'role_access_legacy_options' => $legacy_options,
        ],
        'tables' => $tables,
        'server' => $server,
        'content' => $content,
        'customizer_framework' => $framework,
        'issues' => $issues,
    ];
}

/**
 * Limits of the current request that bound what the abilities can write.
 *
 * @return array{memory_limit_bytes: int, max_execution_time: int, max_allowed_packet_bytes: int|null, multisite: bool}
 */
function kk_server_limits(): array
{
    return [
        'memory_limit_bytes' => wp_convert_hr_to_bytes((string) ini_get('memory_limit')),
        'max_execution_time' => kk_coerce_int_or_null(ini_get('max_execution_time')) ?? 0,
        'max_allowed_packet_bytes' => kk_max_allowed_packet(),
        'multisite' => is_multisite(),
    ];
}

/**
 * Counts of Kirki-mode content per kind plus symbol / collection rows. One
 * grouped query for the editor-mode posts, two cheap counts for the CPTs.
 *
 * @return array<string, int>
 */
function kk_check_setup_content_counts(): array
{
    global $wpdb;
    /** @var \wpdb $wpdb */
    $types = kk_content_post_types();
    $out = array_fill_keys(array_keys($types), value: 0);
    $out['custom'] = 0;
    $by_type = array_flip($types);
    foreach (kk_custom_content_post_types() as $custom_type) {
        $by_type[$custom_type] = 'custom';
    }
    // @mago-expect analysis:possibly-invalid-argument
    $sql = (string) $wpdb->prepare(
        "SELECT p.post_type AS post_type, COUNT(DISTINCT p.ID) AS n
         FROM {$wpdb->posts} p
         INNER JOIN {$wpdb->postmeta} m ON m.post_id = p.ID AND m.meta_key = %s AND BINARY m.meta_value = %s
         WHERE p.post_status <> 'trash' AND p.post_status <> 'auto-draft'
         GROUP BY p.post_type",
        kk_meta_editor_mode(),
        KK_EDITOR_MODE,
    );
    /** @var mixed $rows */
    $rows = $wpdb->get_results($sql, 'ARRAY_A');
    if (is_array($rows)) {
        /** @var mixed $row */
        foreach ($rows as $row) {
            if (!is_array($row) || !isset($row['post_type']) || !is_string($row['post_type'])) {
                continue;
            }
            if (isset($by_type[$row['post_type']])) {
                $out[$by_type[$row['post_type']]] += kk_coerce_int_or_null($row['n'] ?? null) ?? 0;
            }
        }
    }
    $out['symbols'] = kk_count_post_type(kk_symbol_post_type());
    $out['collections'] = kk_count_post_type(kk_collection_post_type());
    return $out;
}

/** Non-trash row count of a post type. */
function kk_count_post_type(string $post_type): int
{
    global $wpdb;
    /** @var \wpdb $wpdb */
    // @mago-expect analysis:possibly-invalid-argument
    $sql = (string) $wpdb->prepare(
        "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = %s AND post_status <> 'trash' AND post_status <> 'auto-draft'",
        $post_type,
    );
    /** @var mixed $n */
    $n = $wpdb->get_var($sql);
    return kk_coerce_int_or_null($n) ?? 0;
}
