<?php

// SPDX-FileCopyrightText: 2026 Ovation S.r.l. <dev@novamira.ai>
// SPDX-License-Identifier: AGPL-3.0-or-later

declare(strict_types=1);

namespace Novamira\Pro\Abilities\Kirki;

use WP_Error;
use WP_Post;

/**
 * Ability: List Kirki theme-builder templates with their display conditions
 * and the position each one holds in Kirki's resolution order.
 */

if (!defined('ABSPATH')) {
    exit();
}

wp_register_ability('novamira/kirki-list-templates', [
    'label' => __('List Kirki Templates', domain: 'novamira-pro'),
    'description' => __(
        'Lists Kirki theme-builder templates (`kirki_template` posts) with their display conditions, normalised exactly as Kirki\'s matcher reads them (`from`, `type`, `post_type`, `where`, `to`, `visibility`, plus `effective` / `note` when Kirki would ignore the entry as stored, and a one-line `summary`), `malformed_conditions` (entries that are not objects: Kirki\'s template list cannot process them), the collection type, the block tree / staging summary, and — for published templates — `resolution_rank`: the position in the order Kirki evaluates templates on the frontend. Kirki takes the newest published templates (highest id first), only as many as `resolution_window` allows, and renders the FIRST whose conditions match; `considered` is false for published templates outside that window. Draft templates never apply. Filter with `status`, `search`; page with `limit` / `offset`.',
        domain: 'novamira-pro',
    ),
    'category' => 'kirki',
    'input_schema' => [
        'type' => 'object',
        'default' => [],
        'properties' => [
            'status' => [
                'type' => 'string',
                'enum' => ['publish', 'draft', 'pending', 'private', 'future', 'any'],
                'description' => 'Post status filter. Default `any` (every non-trash status).',
                'default' => 'any',
            ],
            'search' => ['type' => 'string', 'description' => KK_SEARCH_DESCRIPTION],
            'limit' => KK_LIMIT_SCHEMA,
            'offset' => KK_OFFSET_SCHEMA,
        ],
        'additionalProperties' => false,
    ],
    'output_schema' => [
        'type' => 'object',
        'properties' => [
            'templates' => ['type' => 'array', 'items' => ['type' => 'object']],
            'total' => ['type' => 'integer', 'description' => 'Total matching rows before `limit` / `offset`.'],
            'returned' => ['type' => 'integer'],
            'published_count' => [
                'type' => 'integer',
                'description' => 'Published templates on the site (the resolution candidates), regardless of filters.',
            ],
            'resolution_window' => [
                'type' => 'integer',
                'description' => 'How many of the newest published templates Kirki evaluates per request (rank 1 = the newest by post id, unless `page_on_front` names one of them: Kirki moves that row first).',
            ],
            'resolution_window_source' => [
                'type' => 'string',
                'description' => 'Where the window was read from: Kirki\'s `fetch_list` default, `PageFilterDTO::$limit`, or `fallback` (6.3.0 literal, Kirki changed its API).',
            ],
        ],
        'required' => ['templates', 'total', 'returned', 'published_count', 'resolution_window'],
        'additionalProperties' => false,
    ],
    'execute_callback' => 'Novamira\\Pro\\Abilities\\Kirki\\kirki_list_templates',
    'permission_callback' => 'novamira_permission_callback',
    'meta' => [
        'show_in_rest' => true,
        'mcp' => ['public' => true],
        'annotations' => [
            'instructions' => 'Use this instead of kirki-list-pages when you need to know WHICH template Kirki will apply: walk the rows by `resolution_rank` (1 = evaluated first) and stop at the first whose conditions match the context. Templates apply to single posts / pages (incl. the front page), term archives and author archives; never to search, date or post-type archives (the blog index counts as a page only when a static posts page is set), and 404 goes to a utility page. Matching runs the conditions of one template in stored order: a `show` that applies (entire site, all posts of the type, a single post, a term) records a match; a `hide` on the entire site or on all posts of a type only cancels a match recorded earlier; a `hide` on a single post or on a term that applies stops the template with no match. `note` explains entries Kirki treats specially: a `from: term` entry makes the whole template never match on posts (term and author archives only); `type: user` entries apply to author archives only; `from: user` entries are matched against posts like `from: post`; on term archives `to` is compared with the TAXONOMY name (`category`), not a term id, and any `from: post` entry vetoes the template. A template with zero conditions never matches. Templates are ranked by post id, so a newly created template always evaluates before older ones.',
            'readonly' => true,
            'destructive' => false,
            'idempotent' => true,
        ],
    ],
]);

/**
 * @param array{status?: string, search?: string, limit?: mixed, offset?: mixed} $input
 * @return array<string, mixed>|WP_Error
 */
function kirki_list_templates(array $input): array|WP_Error
{
    kk_begin();
    $post_type = kk_content_post_types()['template'];
    /** @var mixed $status */
    $status = $input['status'] ?? 'any';
    $live = ['publish', 'draft', 'pending', 'private', 'future'];
    if (!is_string($status) || $status !== 'any' && !in_array($status, $live, strict: true)) {
        // The schema enum already refuses this; the guard keeps a direct PHP call from listing every status.
        return kk_invalid_input(__(
            'status must be one of publish, draft, pending, private, future, any.',
            domain: 'novamira-pro',
        ));
    }
    $post_status = $status === 'any' ? $live : [$status];
    $limit = kk_clamp_limit($input['limit'] ?? null, default: 50);
    $offset = max(0, kk_coerce_int_or_null($input['offset'] ?? null) ?? 0);

    $needle = kk_search_needle($input['search'] ?? null);
    if ($needle instanceof WP_Error) {
        return $needle;
    }
    $args = [
        'post_type' => $post_type,
        'post_status' => $post_status,
        'posts_per_page' => $limit,
        'offset' => $offset,
        'orderby' => 'ID',
        'order' => 'DESC',
        'no_found_rows' => false,
        'update_post_term_cache' => false,
        // Rows read their few keys with one grouped query (kk_list_meta):
        // priming the meta cache would load every staged copy of every tree.
        'update_post_meta_cache' => false,
        // Kirki's direct meta writes do not bump the query-cache salt.
        'cache_results' => false,
        // Kirki's resolver uses get_posts (filters suppressed); listing the same way keeps ranks gap-free under WPML-style filters.
        'suppress_filters' => true,
    ];
    if ($needle !== null) {
        $args['s'] = $needle;
        $args['search_columns'] = ['post_title'];
    }
    $query = new \WP_Query($args);

    $window_info = kk_template_resolution_window_info();
    $window = $window_info['window'];
    $ranks = kk_template_resolution_ranks($post_type, $window);
    $posts = array_values(array_filter($query->posts, static fn(mixed $post): bool => $post instanceof WP_Post));
    $ids = array_map(static fn(WP_Post $post): int => $post->ID, $posts);
    $meta = kk_list_meta(
        $ids,
        [
            kk_meta_blocks(),
            kk_meta_staged_versions(),
            kk_meta_template_conditions(),
            kk_meta_template_collection_type(),
            kk_meta_editor_mode(),
        ],
        inline_bytes: KK_LIST_TREE_BYTES,
    );
    // See list-pages: versions in one query, the legacy postmeta list as the
    // fallback for a page the migration cron has not reached.
    $ledgers = kk_stage_ledgers($ids);
    $rows = [];
    foreach ($posts as $post) {
        $rows[] = kk_template_row(
            $post,
            $ranks,
            $window,
            $meta[$post->ID] ?? [],
            kk_listed_ledger($post->ID, $meta[$post->ID] ?? [], $ledgers),
        );
    }

    return [
        'templates' => $rows,
        'total' => kk_found_total($query, $args),
        'returned' => count($rows),
        'published_count' => count($ranks),
        'resolution_window' => $window,
        'resolution_window_source' => $window_info['source'],
    ];
}

/**
 * Position of every published template in Kirki's evaluation order
 * (`Page::fetch_list`: `orderby ID DESC`, then the row whose `isFrontPage` is
 * true — `page_on_front == $post->ID` — moved to the first position of the
 * fetched window), keyed by post id, 1-based.
 *
 * On a site where `page_on_front` names a page, as the Reading settings write
 * it, that promotion never fires here: a `page` id is never a `kirki_template`
 * id. The branch stays because `page_on_front` is a plain option Kirki itself
 * rewrites with a remapped id on template import (`TemplateImport`:
 * `update_option('page_on_front', $this->post_id_tracker[...])`), and in that
 * state Kirki's own list promotes the row, so this one must too.
 *
 * @return array<int, int>
 */
function kk_template_resolution_ranks(string $post_type, int $window): array
{
    /** @var mixed $ids */
    $ids = get_posts([
        'post_type' => $post_type,
        'post_status' => 'publish',
        'posts_per_page' => -1,
        'orderby' => 'ID',
        'order' => 'DESC',
        'fields' => 'ids',
        'no_found_rows' => true,
        'update_post_term_cache' => false,
        'update_post_meta_cache' => false,
        'cache_results' => false,
    ]);
    $ranks = [];
    if (!is_array($ids)) {
        return $ranks;
    }
    $ordered = [];
    /** @var mixed $id */
    foreach ($ids as $id) {
        $int = kk_coerce_int_or_null($id);
        if ($int !== null) {
            $ordered[] = $int;
        }
    }
    $front = kk_coerce_int_or_null(get_option('page_on_front', default_value: 0)) ?? 0;
    $position = array_search($front, array_slice($ordered, offset: 0, length: $window), strict: true);
    if ($front > 0 && $position !== false) {
        array_splice($ordered, $position, length: 1);
        array_unshift($ordered, $front);
    }
    foreach ($ordered as $index => $int) {
        $ranks[$int] = $index + 1;
    }
    return $ranks;
}

/**
 * One template row, from the keys kk_list_meta read for it and the ledger
 * kk_stage_ledgers read for it.
 *
 * @param array<int, int> $ranks
 * @param array<string, array{bytes: int, value: mixed}> $meta
 * @param list<array{version: int, published: bool, last_updated: string|null, no_legacy_global_style: bool}> $ledger
 * @return array<string, mixed>
 */
// @mago-expect lint:cyclomatic-complexity -- one guard per meta key
function kk_template_row(WP_Post $post, array $ranks, int $window, array $meta, array $ledger): array
{
    $tree = kk_list_tree_summary($meta[kk_meta_blocks()] ?? null);
    /** @var mixed $raw_conditions */
    $raw_conditions = $meta[kk_meta_template_conditions()]['value'] ?? null;
    $conditions = [];
    $malformed = 0;
    if (is_array($raw_conditions)) {
        /** @var mixed $condition */
        foreach ($raw_conditions as $condition) {
            if (!is_array($condition)) {
                ++$malformed;
                continue;
            }
            // Site data echoed to the agent: bounded so one hostile meta cannot
            // make the whole response un-encodable or megabytes long.
            /** @var array<string, mixed> $bounded */
            $bounded = kk_bound_value($condition, depth: 4, bytes: 500);
            $conditions[] = kk_normalize_condition($bounded);
        }
    }
    if ($raw_conditions !== '' && $raw_conditions !== null && !is_array($raw_conditions)) {
        $malformed = 1;
    }
    /** @var mixed $collection_type */
    $collection_type = $meta[kk_meta_template_collection_type()]['value'] ?? null;
    $rank = $ranks[$post->ID] ?? null;
    $considered = $rank !== null && $rank <= $window;

    $row = [
        'id' => $post->ID,
        'title' => $post->post_title,
        'slug' => $post->post_name,
        'status' => $post->post_status,
        'modified' => kk_modified_gmt($post),
        'editor_mode' => ($meta[kk_meta_editor_mode()]['value'] ?? null) === KK_EDITOR_MODE,
        'has_blocks' => $tree['has_blocks'],
        'blocks_count' => $tree['blocks_count'],
        'blocks_bytes' => $tree['blocks_bytes'],
        'staging' => kk_staging_info_of($ledger, $post->post_type),
        'collection_type' => is_string($collection_type) && $collection_type !== '' ? $collection_type : null,
        'conditions' => $conditions,
        'malformed_conditions' => $malformed,
        'resolution_rank' => $rank,
        'considered' => $considered,
    ];
    if ($considered && !$tree['has_blocks']) {
        // Kirki still selects it (`templateId` is set) and its page template
        // falls back to `the_content()`: the visitor sees the post's own WordPress content.
        $row['note'] = __(
            'Published without a block tree: when its conditions match, Kirki applies it and prints the WordPress content of the post instead of a Kirki layout.',
            domain: 'novamira-pro',
        );
    }
    return $row;
}
