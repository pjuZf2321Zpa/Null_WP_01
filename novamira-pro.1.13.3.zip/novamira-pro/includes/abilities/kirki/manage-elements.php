<?php

// SPDX-FileCopyrightText: 2026 Ovation S.r.l. <dev@novamira.ai>
// SPDX-License-Identifier: AGPL-3.0-or-later

declare(strict_types=1);

namespace Novamira\Pro\Abilities\Kirki;

use WP_Error;

/**
 * Abilities: targeted mutations of a Kirki tree — add / edit / delete / move
 * one element. All four share the load → mutate → validate → write path in
 * tree.php and the `update_draft` policy.
 */

if (!defined('ABSPATH')) {
    exit();
}

// Load order: this file's schemas use constants defined in other ability files of the folder; require them
// explicitly so the folder's alphabetical load order does not decide whether this file loads.
require_once __DIR__ . '/tree.php'; // KK_ALLOW_OPEN_EDITOR_SCHEMA

const KK_ELEMENT_INPUT_SCHEMA = [
    'type' => 'object',
    'description' => 'Agent-facing element: `{name, tag?, title?, text?, attributes?, className?, css?, properties?, styleIds?, id?}`. `text` fills `properties.contents` on text elements (heading, paragraph, text, bold, label, link-text) and becomes the child `text` node on button / link-block; it is refused on other elements. `css` (`{md: "declarations", md_hover: "…", tablet: "…"}`) creates a page-local style block applied to the element. `attributes` values must be scalars without quotes or angle brackets; event-handler attributes are refused. `properties` is merged for element-specific settings (e.g. image `load`) and validated like the rest.',
    'properties' => [
        'name' => [
            'type' => 'string',
            'description' => 'Element name (lowercase), one of: section, div, heading, paragraph, text, bold, button, link-text, link-block, image, form, label, input, checkbox, checkbox-element, symbol (`properties.symbolId` = id of a kirki_symbol post from kirki-list-symbols; the symbol renders in place of the node). Other Kirki elements (video, select, map, slider, custom-code, collection lists, …) need element-specific properties and must be added in the editor.',
        ],
        'tag' => ['type' => 'string'],
        'title' => ['type' => 'string', 'description' => 'Layer title shown in the editor.'],
        'text' => ['type' => 'string'],
        'attributes' => ['type' => 'object'],
        'className' => ['type' => 'string'],
        'css' => ['type' => 'object'],
        'properties' => ['type' => 'object'],
        'styleIds' => ['type' => 'array', 'items' => ['type' => 'string']],
        'id' => ['type' => 'string', 'description' => 'Optional explicit id; generated as `k-xxxxxxxx` when omitted.'],
    ],
    'required' => ['name'],
    'additionalProperties' => false,
];

const KK_UPDATE_DRAFT_SCHEMA = [
    'type' => 'boolean',
    'description' => 'Also apply the SAME change to the newest unpublished staging draft (the draft keeps its own other edits). Default false: refuse when such a draft exists. Refused with `kirki_draft_mismatch` when the change cannot be applied to the draft (e.g. the element does not exist there).',
    'default' => false,
];

// ---------------------------------------------------------------------------
// add-element
// ---------------------------------------------------------------------------

wp_register_ability('novamira/kirki-add-element', [
    'label' => __('Add Kirki Element', domain: 'novamira-pro'),
    'description' => __(
        'Inserts one element into an existing Kirki tree under `parent_id` (use `body` from kirki-create-page for a top-level section, or any container id from kirki-get-content) at `index` (default: append). The element is described with `{name, tag?, title?, text?, attributes?, className?, css?, properties?}`; `css` becomes a new page-local style block on the element. The node is normalised with the keys the editor expects and the whole tree is validated before writing. Returns the new id and the warnings that concern the new node and its parent (pre-existing warnings about other nodes are not repeated; kirki-set-content returns the whole list). A `symbol` element (`properties.symbolId`) places a header / footer / component symbol from kirki-list-symbols.',
        domain: 'novamira-pro',
    ),
    'category' => 'kirki',
    'input_schema' => [
        'type' => 'object',
        'properties' => [
            'post_id' => ['type' => 'integer'],
            'parent_id' => ['type' => 'string', 'description' => 'Id of a container node (has `children`).'],
            'element' => KK_ELEMENT_INPUT_SCHEMA,
            'index' => [
                'type' => 'integer',
                'description' => 'Position among the parent\'s children; omit or -1 to append.',
            ],
            'update_draft' => KK_UPDATE_DRAFT_SCHEMA,
            'allow_open_editor' => KK_ALLOW_OPEN_EDITOR_SCHEMA,
        ],
        'required' => ['post_id', 'parent_id', 'element'],
        'additionalProperties' => false,
    ],
    'output_schema' => [
        'type' => 'object',
        'properties' => [
            'post_id' => ['type' => 'integer'],
            'element_id' => ['type' => 'string'],
            'style_id' => [
                'type' => ['string', 'null'],
                'description' => 'Id of the style block created from `css`, when given.',
            ],
            'parent_id' => ['type' => 'string'],
            'index' => ['type' => 'integer'],
            'draft_version_updated' => ['type' => ['integer', 'null']],
            'warnings' => ['type' => 'array', 'items' => ['type' => 'string']],
        ],
        'required' => ['post_id', 'element_id', 'style_id', 'parent_id', 'index', 'draft_version_updated', 'warnings'],
        'additionalProperties' => false,
    ],
    'execute_callback' => 'Novamira\\Pro\\Abilities\\Kirki\\kirki_add_element',
    'permission_callback' => 'novamira_permission_callback',
    'meta' => [
        'show_in_rest' => true,
        'mcp' => ['public' => true],
        'annotations' => [
            'instructions' => 'Build top-down: add a `section` under `body` (never under `root`), then `div` wrappers, then leaves (heading, paragraph, button, image). Text elements (heading, paragraph, text, label, link-text) take `text` as their content; a `button` / `link-block` takes `text` as a child `text` node (that is how the editor stores labels — the renderer ignores `contents` on them) and should only hold inline content; containers take children through further add-element calls. Form fields (input, checkbox, checkbox-element) belong inside a `form`; an image needs `attributes.src`. A section\'s title becomes its HTML id (lower-cased, whitespace to `-`, `-1`/`-2` appended on duplicates), so keep titles plain. Prefer `css` on the element over free-form `className`: only style blocks produce CSS. Everything lands raw on the public page: attribute values without double quotes / angle brackets (no single quotes in href / rel / target / name, no whitespace in href / target), URL attributes with an allowed scheme (never javascript: or data:), no `style` / `class` / `on*` attributes, no `properties.code`; the response error lists the exact rule when refused. The write is one transaction under a per-post lock; the Kirki editor takes neither, so the call is refused while a tab is open on the post (`kirki_editor_open`) — its next Publish would overwrite the change. After a timeout or a 5xx, re-read the page before retrying.',
            'readonly' => false,
            'destructive' => false,
            'idempotent' => false,
        ],
    ],
]);

/**
 * @param array<string, mixed> $input
 * @return array<string, mixed>|WP_Error
 */
// @mago-expect lint:cyclomatic-complexity -- guard chain of early returns, one per input
// @mago-expect lint:halstead
function kirki_add_element(array $input): array|WP_Error
{
    kk_begin();
    $post_id = kk_coerce_int_or_null($input['post_id'] ?? null) ?? 0;
    /** @var mixed $raw_parent */
    $raw_parent = $input['parent_id'] ?? '';
    $parent_id = is_string($raw_parent) ? $raw_parent : '';
    /** @var mixed $element */
    $element = $input['element'] ?? null;
    if (!is_array($element)) {
        return kk_invalid_input(__('element must be an object.', domain: 'novamira-pro'));
    }
    /** @var array<string, mixed> $element */
    $index = kk_coerce_int_or_null($input['index'] ?? null);

    $op = static function (array $blocks, array $styles) use ($element, $parent_id, $index): array|WP_Error {
        $blocks = kk_node_map($blocks);
        $styles = kk_style_map($styles);
        $container_error = kk_container_error($parent_id, $blocks);
        if ($container_error !== null) {
            return $container_error;
        }
        /** @var array<string, mixed> $parent */
        $parent = $blocks[$parent_id];
        $built = kk_node_from_element($element, $parent_id, $blocks, $styles);
        if ($built instanceof WP_Error) {
            return $built;
        }
        $blocks[$built['id']] = $built['node'];
        foreach ($built['extra'] as $extra_id => $extra_node) {
            $blocks[$extra_id] = $extra_node;
        }
        $blocks[$parent_id] = kk_insert_child($parent, $built['id'], $index);
        /** @var mixed $style_ids */
        $style_ids = $built['node']['styleIds'] ?? [];
        $created_style = null;
        if (isset($element['css']) && is_array($style_ids) && $style_ids !== []) {
            /** @var mixed $created_style */
            $created_style = end($style_ids);
        }
        return [
            'blocks' => $blocks,
            'styles' => $styles,
            'result' => [
                'element_id' => $built['id'],
                'style_id' => is_string($created_style) ? $created_style : null,
                'index' => kk_child_index($blocks, $parent_id, $built['id']),
                'created_ids' => array_merge(
                    [$built['id']],
                    array_map(static fn(string|int $key): string => strval($key), array_keys($built['extra'])),
                    is_string($created_style) ? [$created_style] : [],
                ),
            ],
        ];
    };
    $done = kk_apply_mutation($post_id, $input['update_draft'] ?? false, $op, $input['allow_open_editor'] ?? false);
    if ($done instanceof WP_Error) {
        return $done;
    }
    /** @var array{element_id: string, style_id: string|null, index: int, created_ids: list<string>} $result */
    $result = $done['result'];
    return [
        'post_id' => $post_id,
        'element_id' => $result['element_id'],
        'style_id' => $result['style_id'],
        'parent_id' => $parent_id,
        'index' => $result['index'],
        'draft_version_updated' => $done['draft_version'],
        'warnings' => kk_bypass_warnings(
            kk_scoped_warnings($done['warnings'], array_merge($result['created_ids'], [$parent_id])),
            $post_id,
            $input['allow_open_editor'] ?? false,
        ),
    ];
}

/**
 * Only the warnings that name one of the touched nodes: the tree-wide list
 * kk_validate_tree returns would otherwise repeat the same pre-existing
 * warnings on every later call (kirki-set-content keeps the whole list).
 *
 * @param list<string> $warnings
 * @param list<string> $ids
 * @return list<string>
 */
function kk_scoped_warnings(array $warnings, array $ids): array
{
    $needles = array_map(static fn(string $id): string => '`' . $id . '`', array_unique($ids));
    return array_values(array_filter($warnings, static function (string $warning) use ($needles): bool {
        foreach ($needles as $needle) {
            if (str_contains($warning, $needle)) {
                return true;
            }
        }
        return false;
    }));
}

// ---------------------------------------------------------------------------
// edit-element
// ---------------------------------------------------------------------------

wp_register_ability('novamira/kirki-edit-element', [
    'label' => __('Edit Kirki Element', domain: 'novamira-pro'),
    'description' => __(
        'Partially updates one element of a Kirki tree: `text` replaces its content (plain string; inline nodes such as bold runs that were only referenced from this element are deleted with it), `tag` / `title` / `className` / `hidden` set those fields, `attributes` merges into `properties.attributes` (null removes a key), `properties` merges element-specific settings, and `css` merges into the element\'s first page-local style block (created when the element has none) DECLARATION BY DECLARATION: `{md: "color:red"}` changes only `color` in the `md` variant; an empty string clears a whole variant. Keys not mentioned are preserved as the editor wrote them (the patched variant is re-serialised as `property:value;` pairs; a property repeated in the stored variant keeps its last value, the one the cascade applied). Every field goes through the same validation as kirki-set-content.',
        domain: 'novamira-pro',
    ),
    'category' => 'kirki',
    'input_schema' => [
        'type' => 'object',
        'properties' => [
            'post_id' => ['type' => 'integer'],
            'element_id' => ['type' => 'string'],
            'text' => ['type' => 'string'],
            'tag' => ['type' => 'string'],
            'title' => ['type' => 'string'],
            'className' => ['type' => 'string'],
            'hidden' => ['type' => 'boolean', 'description' => 'Sets `hide` (the renderer skips hidden nodes).'],
            'attributes' => [
                'type' => 'object',
                'description' => 'Merged into `properties.attributes`; pass null for a key to remove it.',
            ],
            'properties' => [
                'type' => 'object',
                'description' => 'Deep-merged into `properties` (raw element settings): object maps such as `form` or `onSubmit` merge key by key, lists replace, `null` removes a key. `code` (custom JavaScript) and `attributes` of a form cannot be removed; `access` must be one of all, guest, logged-in, admin, editor, author, subscriber.',
            ],
            'css' => [
                'type' => 'object',
                'description' => 'Viewport => declarations, merged into the element\'s style block; pass an empty string to clear a variant.',
            ],
            'update_draft' => KK_UPDATE_DRAFT_SCHEMA,
            'allow_open_editor' => KK_ALLOW_OPEN_EDITOR_SCHEMA,
        ],
        'required' => ['post_id', 'element_id'],
        'additionalProperties' => false,
    ],
    'output_schema' => [
        'type' => 'object',
        'properties' => [
            'post_id' => ['type' => 'integer'],
            'element_id' => ['type' => 'string'],
            'style_id' => ['type' => ['string', 'null']],
            'changed' => ['type' => 'array', 'items' => ['type' => 'string']],
            'draft_version_updated' => ['type' => ['integer', 'null']],
            'warnings' => ['type' => 'array', 'items' => ['type' => 'string']],
        ],
        'required' => ['post_id', 'element_id', 'style_id', 'changed', 'draft_version_updated', 'warnings'],
        'additionalProperties' => false,
    ],
    'execute_callback' => 'Novamira\\Pro\\Abilities\\Kirki\\kirki_edit_element',
    'permission_callback' => 'novamira_permission_callback',
    'meta' => [
        'show_in_rest' => true,
        'mcp' => ['public' => true],
        'annotations' => [
            'instructions' => 'Read the node with kirki-get-element first when the text has inline formatting (bold runs) — `text` flattens it. `text` works on text elements and on button / link-block (the label child is updated or created); it is refused on containers and images. `css` lands in the element\'s first page-local style block; when that block is shared with other elements the response warns and lists them, because they change too. To override a single declaration pass just that declaration (there is no removal: `font-size: unset` keeps a `font-size:unset;` declaration, which resets the property). Refused while a Kirki editor tab is open on the post (`kirki_editor_open`).',
            'readonly' => false,
            'destructive' => false,
            'idempotent' => true,
        ],
    ],
]);

/**
 * @param array<string, mixed> $input
 * @return array<string, mixed>|WP_Error
 */
// @mago-expect lint:cyclomatic-complexity -- guard chain of early returns, one per input
// @mago-expect lint:halstead
function kirki_edit_element(array $input): array|WP_Error
{
    kk_begin();
    $post_id = kk_coerce_int_or_null($input['post_id'] ?? null) ?? 0;
    /** @var mixed $raw_id */
    $raw_id = $input['element_id'] ?? '';
    $element_id = is_string($raw_id) ? $raw_id : '';
    if (isset($input['css']) && !is_array($input['css'])) {
        return kk_invalid_input(__('css must be an object of viewport => css declarations.', domain: 'novamira-pro'));
    }
    if (isset($input['css']) && is_array($input['css'])) {
        $css_errors = kk_validate_css_map_allow_clear($input['css']);
        /** @var mixed $declarations */
        foreach ($input['css'] as $key => $declarations) {
            if (
                !is_string($declarations)
                || trim($declarations) === ''
                || kk_parse_declarations($declarations) !== []
            ) {
                continue;
            }
            $css_errors[] = sprintf('css value for `%s` holds no `property:value` declaration.', (string) $key);
        }
        if ($css_errors !== []) {
            return kk_invalid_input(implode(' ', $css_errors));
        }
    }
    if (isset($input['tag']) && is_string($input['tag']) && trim($input['tag']) === '') {
        return kk_invalid_input(__('tag must not be empty.', domain: 'novamira-pro'));
    }
    if (kk_edit_fields($input) === []) {
        return kk_invalid_input(__(
            'Nothing to change: pass at least one of text, tag, title, className, hidden, attributes, properties, css.',
            domain: 'novamira-pro',
        ));
    }

    $op = static function (array $blocks, array $styles) use ($input, $element_id): array|WP_Error {
        $blocks = kk_node_map($blocks);
        $styles = kk_style_map($styles);
        if ($element_id === '' || !isset($blocks[$element_id]) || !is_array($blocks[$element_id])) {
            return kk_unknown_node($element_id);
        }
        return kk_edit_node($blocks, $styles, $element_id, $input);
    };
    $done = kk_apply_mutation($post_id, $input['update_draft'] ?? false, $op, $input['allow_open_editor'] ?? false);
    if ($done instanceof WP_Error) {
        return $done;
    }
    /** @var array{style_id: string|null, changed: list<string>, warnings: list<string>} $result */
    $result = $done['result'];
    $touched = [$element_id];
    if (is_string($result['style_id'])) {
        $touched[] = $result['style_id'];
    }
    foreach ($result['warnings'] as $warning) {
        // A label node created by a `text` edit is named in the op's own warning.
        $m = [];
        if (preg_match('/Created label node `([^`]+)`/', $warning, $m) !== 1) {
            continue;
        }
        $touched[] = $m[1];
    }
    return [
        'post_id' => $post_id,
        'element_id' => $element_id,
        'style_id' => $result['style_id'],
        'changed' => $result['changed'],
        'draft_version_updated' => $done['draft_version'],
        'warnings' => kk_bypass_warnings(
            array_merge($result['warnings'], kk_scoped_warnings($done['warnings'], $touched)),
            $post_id,
            $input['allow_open_editor'] ?? false,
        ),
    ];
}

/**
 * Input keys of edit-element that carry a change.
 *
 * @param array<string, mixed> $input
 * @return list<string>
 */
function kk_edit_fields(array $input): array
{
    $fields = [];
    foreach (['text', 'tag', 'title', 'className', 'hidden', 'attributes', 'properties', 'css'] as $key) {
        if (!array_key_exists($key, $input) || $input[$key] === null) {
            continue;
        }
        $fields[] = $key;
    }
    return $fields;
}

/**
 * Apply the edit-element inputs to one node of a tree.
 *
 * @param array<string, mixed> $blocks
 * @param array<string, array<string, mixed>> $styles
 * @param array<string, mixed> $input
 * @return array{blocks: array<string, mixed>, styles: array<string, array<string, mixed>>, result: array{style_id: string|null, changed: list<string>, warnings: list<string>}}|WP_Error
 */
// @mago-expect lint:cyclomatic-complexity -- one input key per branch
// @mago-expect lint:halstead
function kk_edit_node(array $blocks, array $styles, string $element_id, array $input): array|WP_Error
{
    /** @var array<string, mixed> $node */
    $node = $blocks[$element_id];
    $changed = [];
    $warnings = [];
    $node = kk_apply_scalar_edits($node, $input, $changed);
    $props = isset($node['properties']) && is_array($node['properties']) ? $node['properties'] : [];
    /** @var array<string, mixed> $props */
    if (isset($input['text']) && is_string($input['text'])) {
        $applied = kk_apply_text_edit($blocks, $node, $props, $element_id, $input['text']);
        if ($applied instanceof WP_Error) {
            return $applied;
        }
        $removed = array_diff(array_keys($blocks), array_keys($applied['blocks']));
        $blocks = $applied['blocks'];
        $node = $applied['node'];
        $props = $applied['props'];
        $warnings = array_merge($warnings, $applied['warnings']);
        $changed[] = 'text';
        if ($removed !== []) {
            $node['properties'] = $props;
            $blocks[$element_id] = $node;
            kk_prune_styles($blocks, $styles);
        }
    }
    if (isset($input['attributes']) && is_array($input['attributes'])) {
        $existing = isset($props['attributes']) && is_array($props['attributes']) ? $props['attributes'] : [];
        $props['attributes'] = kk_merge_nullable($existing, $input['attributes']);
        $changed[] = 'attributes';
    }
    if (isset($input['properties']) && is_array($input['properties'])) {
        $props = kk_merge_properties($props, $input['properties']);
        $changed[] = 'properties';
    }
    /** @var mixed $name */
    $name = $node['name'] ?? 'div';
    $node['properties'] = kk_normalize_props(is_string($name) ? $name : 'div', kk_node_map($props));
    if (isset($input['tag']) && array_key_exists('children', $node)) {
        $tag_warning = kk_void_tag_warning($element_id, $node);
        if ($tag_warning !== null) {
            return kk_invalid_input($tag_warning);
        }
    }

    $style_id = null;
    if (isset($input['css']) && is_array($input['css'])) {
        $style_id = kk_merge_css_into_node($node, $input['css'], $styles, $blocks);
        $shared = kk_style_block_sharers($style_id, $element_id, $blocks);
        if ($shared !== []) {
            $warnings[] = sprintf(
                'Style block `%s` is shared with %s; the css change applies to them too.',
                $style_id,
                implode(', ', $shared),
            );
        }
        $changed[] = 'css';
    }
    $blocks[$element_id] = $node;
    return [
        'blocks' => $blocks,
        'styles' => $styles,
        'result' => ['style_id' => $style_id, 'changed' => $changed, 'warnings' => $warnings],
    ];
}

/**
 * Replace the text of a node: on text elements `contents` becomes `[text]`
 * and inline nodes referenced only from here are removed with their style
 * blocks left for the next prune; on button / link-block the label child is
 * updated or created; refused elsewhere.
 *
 * @param array<string, mixed> $blocks
 * @param array<string, mixed> $node
 * @param array<string, mixed> $props
 * @return array{blocks: array<string, mixed>, node: array<string, mixed>, props: array<string, mixed>, warnings: list<string>}|WP_Error
 */
// @mago-expect lint:halstead -- label-child path, text-element path, inline cleanup
function kk_apply_text_edit(array $blocks, array $node, array $props, string $element_id, string $text): array|WP_Error
{
    /** @var mixed $name */
    $name = $node['name'] ?? '';
    $name = is_string($name) ? $name : '';
    $warnings = [];
    if (in_array($name, KK_LABEL_CHILD_ELEMENTS, strict: true)) {
        $label = kk_label_child_id($node, $blocks);
        if ($label === null) {
            $label = kk_new_id($blocks);
            $blocks[$label] = kk_normalize_node(
                $label,
                [
                    'id' => $label,
                    'name' => 'text',
                    'title' => 'Text',
                    'properties' => ['contents' => [$text], 'tag' => 'span'],
                ],
                $element_id,
            );
            $children = kk_node_child_ids($node);
            array_unshift($children, $label);
            $node['children'] = $children;
            return [
                'blocks' => $blocks,
                'node' => $node,
                'props' => $props,
                'warnings' => [sprintf('Created label node `%s` under `%s`.', $label, $element_id)],
            ];
        }
        /** @var array<string, mixed> $label_node */
        $label_node = $blocks[$label];
        $label_props = isset($label_node['properties']) && is_array($label_node['properties'])
            ? $label_node['properties']
            : [];
        $label_props['contents'] = [$text];
        $label_node['properties'] = $label_props;
        $blocks[$label] = $label_node;
        return ['blocks' => $blocks, 'node' => $node, 'props' => $props, 'warnings' => []];
    }
    if (!in_array($name, KK_TEXT_ELEMENTS, strict: true)) {
        return kk_invalid_input(sprintf(
            /* translators: 1: node id, 2: element name, 3: text elements */
            __(
                'Node `%1$s` (%2$s) does not render `text`; edit a child text element instead (%3$s).',
                domain: 'novamira-pro',
            ),
            $element_id,
            $name,
            implode(', ', KK_TEXT_ELEMENTS),
        ));
    }
    if (array_key_exists('children', $node)) {
        return kk_invalid_input(sprintf(
            /* translators: %s: node id */
            __(
                'Node `%s` carries `children`, so the renderer ignores its `contents` text; edit the child text element instead.',
                domain: 'novamira-pro',
            ),
            $element_id,
        ));
    }
    foreach (kk_inline_ref_ids(['properties' => $props]) as $ref) {
        $referrers = array_values(array_diff(kk_inline_referrers($ref, $blocks), [$element_id]));
        if ($referrers !== []) {
            // Shared with another text node: keep it, re-parent it to that node.
            if (isset($blocks[$ref]) && is_array($blocks[$ref])) {
                $blocks[$ref]['parentId'] = $referrers[0];
            }
            continue;
        }
        foreach (kk_subtree_ids($ref, $blocks) as $doomed) {
            unset($blocks[$doomed]);
        }
        $warnings[] = sprintf(
            'Inline node `%s` was removed with the old text; style blocks only it referenced are pruned.',
            $ref,
        );
    }
    $props['contents'] = [$text];
    return ['blocks' => $blocks, 'node' => $node, 'props' => $props, 'warnings' => $warnings];
}

/**
 * Error when a container now carries a void tag (its children would be dropped).
 *
 * @param array<string, mixed> $node
 */
function kk_void_tag_warning(string $id, array $node): ?string
{
    $tag = kk_node_tag($node);
    if ($tag === null || !in_array($tag, KK_VOID_TAGS, strict: true)) {
        return null;
    }
    if (kk_node_child_ids($node) === []) {
        return null;
    }
    return sprintf('Node `%s` has children; `<%s>` is a void tag and would drop them.', $id, $tag);
}

/**
 * Other nodes referencing a style block.
 *
 * @param array<string, mixed> $blocks
 * @return list<string>
 */
function kk_style_block_sharers(string $style_id, string $except, array $blocks): array
{
    $out = [];
    /** @var mixed $node */
    foreach ($blocks as $id => $node) {
        if ($id === $except || !is_array($node)) {
            continue;
        }
        $refs = kk_referenced_style_ids([$id => $node]);
        if (isset($refs[$style_id])) {
            $out[] = $id;
        }
    }
    return $out;
}

/**
 * `kk_validate_css_map` that also accepts empty strings (clear a variant).
 *
 * @param array<array-key, mixed> $css
 * @return list<string>
 */
function kk_validate_css_map_allow_clear(array $css): array
{
    $non_empty = [];
    $viewport_ids = array_column(kk_viewports(), 'id');
    $errors = [];
    /** @var mixed $text */
    foreach ($css as $key => $text) {
        if ($text === '') {
            $key_error = kk_validate_variant_key($key, $viewport_ids);
            if ($key_error !== null) {
                $errors[] = $key_error;
            }
            continue;
        }
        $non_empty[$key] = $text;
    }
    if ($non_empty === []) {
        return $errors;
    }
    return array_values(array_merge($errors, kk_validate_css_map($non_empty)));
}

/**
 * For button-like elements, the id of the child `text` node that carries the
 * label (the renderer ignores `contents` on them); null otherwise.
 *
 * @param array<string, mixed> $node
 * @param array<string, mixed> $blocks
 */
function kk_label_child_id(array $node, array $blocks): ?string
{
    /** @var mixed $name */
    $name = $node['name'] ?? '';
    if (!is_string($name) || !in_array($name, KK_LABEL_CHILD_ELEMENTS, strict: true)) {
        return null;
    }
    foreach (kk_node_child_ids($node) as $child) {
        if (!isset($blocks[$child]) || !is_array($blocks[$child])) {
            continue;
        }
        if (($blocks[$child]['name'] ?? '') === 'text') {
            return $child;
        }
    }
    return null;
}

/**
 * tag / title / className / hidden edits.
 *
 * @param array<string, mixed> $node
 * @param array<string, mixed> $input
 * @param list<string> $changed
 * @return array<string, mixed>
 */
function kk_apply_scalar_edits(array $node, array $input, array &$changed): array
{
    if (isset($input['tag']) && is_string($input['tag']) && $input['tag'] !== '') {
        $props = isset($node['properties']) && is_array($node['properties']) ? $node['properties'] : [];
        $props['tag'] = $input['tag'];
        $node['properties'] = $props;
        $changed[] = 'tag';
    }
    if (isset($input['title']) && is_string($input['title'])) {
        $node['customTitle'] = $input['title'];
        $node['title'] = $input['title'];
        $changed[] = 'title';
    }
    if (isset($input['className']) && is_string($input['className'])) {
        $node['className'] = $input['className'];
        $changed[] = 'className';
    }
    if (isset($input['hidden'])) {
        $node['hide'] = kk_bool($input['hidden']);
        $changed[] = 'hidden';
    }
    return $node;
}

/**
 * Merge `$patch` into `$base`; a null value removes the key.
 *
 * @param array<array-key, mixed> $base
 * @param array<array-key, mixed> $patch
 * @return array<array-key, mixed>
 */
/**
 * Deep merge of a `properties` patch: object maps (`form`, `attributes`,
 * `onSubmit`…) are merged key by key so a patch of one setting keeps the
 * others, lists replace, `null` removes a key.
 *
 * @param array<string, mixed> $base
 * @param array<array-key, mixed> $patch
 * @return array<string, mixed>
 */
// @mago-expect lint:halstead -- recursive map merge with three branches
function kk_merge_properties(array $base, array $patch): array
{
    /** @var mixed $value */
    foreach ($patch as $key => $value) {
        $key = (string) $key;
        if ($value === null) {
            unset($base[$key]);
            continue;
        }
        /** @var mixed $current */
        $current = $base[$key] ?? null;
        if (is_array($value) && !kk_is_list($value) && is_array($current) && !kk_is_list($current)) {
            /** @var array<string, mixed> $current */
            $base[$key] = kk_merge_properties($current, $value);
            continue;
        }
        $base[$key] = $value;
    }
    return $base;
}

function kk_merge_nullable(array $base, array $patch): array
{
    /** @var mixed $value */
    foreach ($patch as $key => $value) {
        if ($value === null) {
            unset($base[$key]);
            continue;
        }
        $base[$key] = $value;
    }
    return $base;
}

/**
 * Merge viewport CSS into the node's first page-local style block, creating
 * one when the node has none. Empty strings clear a variant. Returns the
 * style block id touched.
 *
 * @param array<string, mixed> $node (mutated)
 * @param array<array-key, mixed> $css
 * @param array<string, array<string, mixed>> $styles (mutated)
 * @param array<string, mixed> $blocks
 */
function kk_merge_css_into_node(array &$node, array $css, array &$styles, array $blocks): string
{
    $style_id = null;
    foreach (kk_string_list($node['styleIds'] ?? null) as $candidate) {
        if (!isset($styles[$candidate])) {
            continue; // global class or dangling: never edited from here
        }
        $style_id = $candidate;
        break;
    }
    if ($style_id === null) {
        $style_id = kk_new_id($styles + $blocks);
        $styles[$style_id] = kk_style_block_from_css($style_id, []);
        $ids = kk_string_list($node['styleIds'] ?? null);
        $ids[] = $style_id;
        $node['styleIds'] = $ids;
    }
    $block = $styles[$style_id];
    $variant = isset($block['variant']) && is_array($block['variant']) ? $block['variant'] : [];
    /** @var mixed $text */
    foreach ($css as $key => $text) {
        if (!is_string($key) || !is_string($text)) {
            continue;
        }
        if (trim($text) === '') {
            unset($variant[$key]);
            continue;
        }
        /** @var mixed $existing */
        $existing = $variant[$key] ?? '';
        $variant[$key] = kk_merge_declarations(is_string($existing) ? $existing : '', trim($text));
    }
    $block['variant'] = $variant;
    $styles[$style_id] = $block;
    return $style_id;
}

// ---------------------------------------------------------------------------
// delete-element
// ---------------------------------------------------------------------------

wp_register_ability('novamira/kirki-delete-element', [
    'label' => __('Delete Kirki Element', domain: 'novamira-pro'),
    'description' => __(
        'Removes one element and its whole subtree (children and inline content nodes that no surviving node references) from a Kirki tree and detaches it from its parent. Page-local style blocks no surviving node references anywhere (`styleIds`, `classesIds`, or any property string such as an interaction target) are pruned unless `keep_styles` is true. `root`, `body`, and any subtree containing them cannot be deleted; inline nodes referenced from a surviving element are kept and re-parented to it (with a warning).',
        domain: 'novamira-pro',
    ),
    'category' => 'kirki',
    'input_schema' => [
        'type' => 'object',
        'properties' => [
            'post_id' => ['type' => 'integer'],
            'element_id' => ['type' => 'string'],
            'keep_styles' => [
                'type' => 'boolean',
                'description' => 'Keep now-unreferenced style blocks. Default false.',
                'default' => false,
            ],
            'update_draft' => KK_UPDATE_DRAFT_SCHEMA,
            'allow_open_editor' => KK_ALLOW_OPEN_EDITOR_SCHEMA,
        ],
        'required' => ['post_id', 'element_id'],
        'additionalProperties' => false,
    ],
    'output_schema' => [
        'type' => 'object',
        'properties' => [
            'post_id' => ['type' => 'integer'],
            'deleted_ids' => ['type' => 'array', 'items' => ['type' => 'string']],
            'pruned_style_ids' => ['type' => 'array', 'items' => ['type' => 'string']],
            'draft_version_updated' => ['type' => ['integer', 'null']],
            'warnings' => ['type' => 'array', 'items' => ['type' => 'string']],
        ],
        'required' => ['post_id', 'deleted_ids', 'pruned_style_ids', 'draft_version_updated', 'warnings'],
        'additionalProperties' => false,
    ],
    'execute_callback' => 'Novamira\\Pro\\Abilities\\Kirki\\kirki_delete_element',
    'permission_callback' => 'novamira_permission_callback',
    'meta' => [
        'show_in_rest' => true,
        'mcp' => ['public' => true],
        'annotations' => [
            'instructions' => 'Destructive and not undoable: Kirki keeps no copy of the published tree (its version history holds only drafts the editor saved), so read the subtree with kirki-get-content (node_id) before deleting when in doubt. Pruning removes page-local style blocks no surviving node mentions anywhere (`styleIds`, `classesIds` or an interaction target under `properties`), including blocks that were already orphaned. The page\'s `kirki_used_font_list` is not recomputed (the frontend loads fonts from the site-wide list in 6.3, the editor recomputes it on its next save).',
            'readonly' => false,
            'destructive' => true,
            'idempotent' => false,
        ],
    ],
]);

/**
 * @param array<string, mixed> $input
 * @return array<string, mixed>|WP_Error
 */
// @mago-expect lint:cyclomatic-complexity -- guard chain of early returns, one per input
// @mago-expect lint:halstead
// @mago-expect lint:kan-defect
function kirki_delete_element(array $input): array|WP_Error
{
    kk_begin();
    $post_id = kk_coerce_int_or_null($input['post_id'] ?? null) ?? 0;
    /** @var mixed $raw_id */
    $raw_id = $input['element_id'] ?? '';
    $element_id = is_string($raw_id) ? $raw_id : '';
    $keep_styles = kk_bool($input['keep_styles'] ?? false);

    // @mago-expect lint:cyclomatic-complexity -- guards, fixed-point keep loop, prune
    // @mago-expect lint:kan-defect
    // @mago-expect lint:halstead
    $op = static function (array $blocks, array $styles) use ($element_id, $keep_styles): array|WP_Error {
        $blocks = kk_node_map($blocks);
        $styles = kk_style_map($styles);
        if ($element_id === '' || !isset($blocks[$element_id])) {
            return kk_unknown_node($element_id);
        }
        if (kk_inline_referrers($element_id, $blocks) !== []) {
            return kk_invalid_input(sprintf(
                /* translators: %s: node id */
                __(
                    'Node `%s` is inline content of a text element (referenced from `contents`); change the parent\'s text with kirki-edit-element instead.',
                    domain: 'novamira-pro',
                ),
                kk_short($element_id),
            ));
        }
        /** @var mixed $parent_of_deleted */
        $parent_of_deleted = $blocks[$element_id]['parentId'] ?? '';
        $doomed = kk_subtree_ids($element_id, $blocks);
        if (in_array('root', $doomed, strict: true) || in_array('body', $doomed, strict: true)) {
            return kk_invalid_input(__(
                '`root` and `body` cannot be deleted (directly or as part of a subtree); use kirki-set-content to replace the canvas.',
                domain: 'novamira-pro',
            ));
        }
        $warnings = [];
        // Inline nodes another surviving element still references stay — and
        // so does everything they reference: iterate to a fixed point so the
        // outcome does not depend on the walk order.
        $kept = [];
        do {
            $changed = false;
            foreach ($doomed as $i => $id) {
                $referrers = array_values(array_diff(kk_inline_referrers($id, $blocks), $doomed));
                if ($referrers === []) {
                    continue;
                }
                unset($doomed[$i]);
                $kept[$id] = $referrers;
                $changed = true;
            }
        } while ($changed);
        foreach ($kept as $id => $referrers) {
            if (
                isset($blocks[$id])
                && is_array($blocks[$id])
                && in_array($blocks[$id]['parentId'] ?? null, $doomed, strict: true)
            ) {
                $blocks[$id]['parentId'] = $referrers[0];
            }
            $warnings[] = sprintf('Inline node `%s` was kept: still referenced by %s.', $id, implode(', ', $referrers));
        }
        $doomed = array_values($doomed);
        foreach ($doomed as $id) {
            unset($blocks[$id]);
        }
        /** @var mixed $node */
        foreach ($blocks as $id => $node) {
            if (!is_array($node)) {
                continue;
            }
            /** @var array<string, mixed> $node */
            $children = kk_node_child_ids($node);
            $kept = array_values(array_diff($children, $doomed));
            if (count($kept) !== count($children)) {
                $node['children'] = $kept;
            }
            $blocks[$id] = kk_strip_inline_refs($node, $doomed);
        }
        $pruned = $keep_styles ? [] : kk_prune_styles($blocks, $styles);
        return [
            'blocks' => $blocks,
            'styles' => $styles,
            'result' => [
                'deleted_ids' => $doomed,
                'pruned_style_ids' => $pruned,
                'warnings' => $warnings,
                'parent_id' => is_string($parent_of_deleted) ? $parent_of_deleted : '',
            ],
        ];
    };
    $done = kk_apply_mutation($post_id, $input['update_draft'] ?? false, $op, $input['allow_open_editor'] ?? false);
    if ($done instanceof WP_Error) {
        return $done;
    }
    /** @var array{deleted_ids: list<string>, pruned_style_ids: list<string>, warnings: list<string>, parent_id: string} $result */
    $result = $done['result'];
    return [
        'post_id' => $post_id,
        'deleted_ids' => $result['deleted_ids'],
        'pruned_style_ids' => $result['pruned_style_ids'],
        'draft_version_updated' => $done['draft_version'],
        'warnings' => kk_bypass_warnings(
            array_merge($result['warnings'], kk_scoped_warnings($done['warnings'], [$result['parent_id']])),
            $post_id,
            $input['allow_open_editor'] ?? false,
        ),
    ];
}

/**
 * Drop `{id}` entries of `properties.contents` that point at deleted nodes.
 *
 * @param array<string, mixed> $node
 * @param list<string> $doomed
 * @return array<string, mixed>
 */
function kk_strip_inline_refs(array $node, array $doomed): array
{
    if (
        !isset($node['properties'])
        || !is_array($node['properties'])
        || !isset($node['properties']['contents'])
        || !is_array($node['properties']['contents'])
    ) {
        return $node;
    }
    $kept = [];
    /** @var mixed $part */
    foreach ($node['properties']['contents'] as $part) {
        if (
            is_array($part)
            && isset($part['id'])
            && is_string($part['id'])
            && in_array($part['id'], $doomed, strict: true)
        ) {
            continue;
        }
        $kept[] = $part;
    }
    $node['properties']['contents'] = $kept;
    return $node;
}

/**
 * Remove style blocks no node references. Returns the pruned ids.
 *
 * @param array<string, mixed> $blocks
 * @param array<string, array<string, mixed>> $styles (mutated)
 * @return list<string>
 */
function kk_prune_styles(array $blocks, array &$styles): array
{
    $used = kk_referenced_style_ids($blocks);
    $pruned = [];
    foreach (array_keys($styles) as $id) {
        if (isset($used[$id])) {
            continue;
        }
        unset($styles[$id]);
        $pruned[] = $id;
    }
    return $pruned;
}

/**
 * Style-block ids any node references, through `styleIds` or the older
 * `properties.classesIds` (the renderer resolves both).
 *
 * @param array<string, mixed> $blocks
 * @return array<string, true>
 */
function kk_referenced_style_ids(array $blocks): array
{
    $used = [];
    /** @var mixed $node */
    foreach ($blocks as $node) {
        if (!is_array($node)) {
            continue;
        }
        foreach (kk_string_list($node['styleIds'] ?? null) as $id) {
            $used[$id] = true;
        }
        // `classesIds`, interaction targets (`end.className.id`,
        // `deviceAndClassList.styleBlockId`, `<el>____info.styleBlockId`…) and
        // any other property the renderer or the editor resolves as a style
        // block: every string anywhere under `properties` counts, so a block
        // still in use is never pruned (an unused block kept is harmless).
        if (isset($node['properties']) && is_array($node['properties'])) {
            kk_collect_strings($node['properties'], $used, depth: 0);
        }
    }
    return $used;
}

/**
 * Add every string found under `$value` (any depth, bounded) as a key of `$into`.
 *
 * @param array<string, true> $into
 * @param-out array<string, true> $into
 */
function kk_collect_strings(mixed $value, array &$into, int $depth): void
{
    if ($depth > 32) {
        return;
    }
    if (is_string($value)) {
        $into[$value] = true;
        return;
    }
    if (!is_array($value)) {
        return;
    }
    /** @var mixed $item */
    foreach ($value as $item) {
        kk_collect_strings($item, $into, $depth + 1);
    }
}

// ---------------------------------------------------------------------------
// move-element
// ---------------------------------------------------------------------------

wp_register_ability('novamira/kirki-move-element', [
    'label' => __('Move Kirki Element', domain: 'novamira-pro'),
    'description' => __(
        'Moves one element (with its subtree) to `new_parent_id` at `index` (default: append), or reorders it within its current parent when `new_parent_id` is omitted. Refuses moving `root` / `body`, inline nodes (bold runs referenced from a text element\'s contents), moving a node into itself or one of its descendants, and moving into a leaf or into `root`.',
        domain: 'novamira-pro',
    ),
    'category' => 'kirki',
    'input_schema' => [
        'type' => 'object',
        'properties' => [
            'post_id' => ['type' => 'integer'],
            'element_id' => ['type' => 'string'],
            'new_parent_id' => [
                'type' => 'string',
                'description' => 'Target container. Omit to keep the current parent (reorder only).',
            ],
            'index' => [
                'type' => 'integer',
                'description' => 'Position among the target\'s children; omit or -1 to append.',
            ],
            'update_draft' => KK_UPDATE_DRAFT_SCHEMA,
            'allow_open_editor' => KK_ALLOW_OPEN_EDITOR_SCHEMA,
        ],
        'required' => ['post_id', 'element_id'],
        'additionalProperties' => false,
    ],
    'output_schema' => [
        'type' => 'object',
        'properties' => [
            'post_id' => ['type' => 'integer'],
            'element_id' => ['type' => 'string'],
            'parent_id' => ['type' => 'string'],
            'index' => ['type' => 'integer'],
            'draft_version_updated' => ['type' => ['integer', 'null']],
            'warnings' => ['type' => 'array', 'items' => ['type' => 'string']],
        ],
        'required' => ['post_id', 'element_id', 'parent_id', 'index', 'draft_version_updated', 'warnings'],
        'additionalProperties' => false,
    ],
    'execute_callback' => 'Novamira\\Pro\\Abilities\\Kirki\\kirki_move_element',
    'permission_callback' => 'novamira_permission_callback',
    'meta' => [
        'show_in_rest' => true,
        'mcp' => ['public' => true],
        'annotations' => [
            'instructions' => 'Use kirki-get-content to read the current order (children arrays are ordered) before choosing `index`.',
            'readonly' => false,
            'destructive' => false,
            'idempotent' => true,
        ],
    ],
]);

/**
 * @param array<string, mixed> $input
 * @return array<string, mixed>|WP_Error
 */
// @mago-expect lint:cyclomatic-complexity -- guard chain of early returns, one per input
// @mago-expect lint:halstead
function kirki_move_element(array $input): array|WP_Error
{
    kk_begin();
    $post_id = kk_coerce_int_or_null($input['post_id'] ?? null) ?? 0;
    /** @var mixed $raw_id */
    $raw_id = $input['element_id'] ?? '';
    $element_id = is_string($raw_id) ? $raw_id : '';
    /** @var mixed $raw_target */
    $raw_target = $input['new_parent_id'] ?? null;
    $requested_target = is_string($raw_target) && $raw_target !== '' ? $raw_target : null;
    $index = kk_coerce_int_or_null($input['index'] ?? null);

    // @mago-expect lint:cyclomatic-complexity -- guard chain: existence, root/body, inline, orphan, container, cycle
    $op = static function (array $blocks, array $styles) use ($element_id, $requested_target, $index): array|WP_Error {
        $blocks = kk_node_map($blocks);
        $styles = kk_style_map($styles);
        if ($element_id === '' || !isset($blocks[$element_id]) || !is_array($blocks[$element_id])) {
            return kk_unknown_node($element_id);
        }
        if ($element_id === 'root' || $element_id === 'body') {
            return kk_invalid_input(__('`root` and `body` cannot be moved.', domain: 'novamira-pro'));
        }
        if (kk_inline_referrers($element_id, $blocks) !== []) {
            return kk_invalid_input(sprintf(
                /* translators: %s: node id */
                __(
                    'Node `%s` is inline content of a text element (referenced from `contents`) and cannot be moved as an element.',
                    domain: 'novamira-pro',
                ),
                $element_id,
            ));
        }
        /** @var array<string, mixed> $node */
        $node = $blocks[$element_id];
        // The real parent is the node listing the element (parentId may be stale).
        $listers = kk_lister_map($blocks);
        $current_parent = $listers[$element_id] ?? null;
        if ($requested_target === null && $current_parent === null) {
            return kk_invalid_input(sprintf(
                /* translators: %s: node id */
                __(
                    'Node `%s` is not listed in any `children` (it never renders); pass `new_parent_id` to attach it to a container.',
                    domain: 'novamira-pro',
                ),
                kk_short($element_id),
            ));
        }
        $target_id = $requested_target ?? $current_parent ?? '';
        $container_error = kk_container_error($target_id, $blocks);
        if ($container_error !== null) {
            return $container_error;
        }
        if (in_array($target_id, kk_subtree_ids($element_id, $blocks), strict: true)) {
            return kk_invalid_input(__(
                'Cannot move a node into itself or one of its descendants.',
                domain: 'novamira-pro',
            ));
        }
        /** @var mixed $candidate */
        foreach ($blocks as $id => $candidate) {
            if (!is_array($candidate)) {
                continue;
            }
            /** @var array<string, mixed> $candidate */
            $children = kk_node_child_ids($candidate);
            if (!in_array($element_id, $children, strict: true)) {
                continue;
            }
            $candidate['children'] = array_values(array_diff($children, [$element_id]));
            $blocks[$id] = $candidate;
        }
        /** @var array<string, mixed> $target */
        $target = $blocks[$target_id];
        $blocks[$target_id] = kk_insert_child($target, $element_id, $index);
        $node['parentId'] = $target_id;
        $blocks[$element_id] = $node;
        return [
            'blocks' => $blocks,
            'styles' => $styles,
            'result' => ['parent_id' => $target_id, 'index' => kk_child_index($blocks, $target_id, $element_id)],
        ];
    };
    $done = kk_apply_mutation($post_id, $input['update_draft'] ?? false, $op, $input['allow_open_editor'] ?? false);
    if ($done instanceof WP_Error) {
        return $done;
    }
    /** @var array{parent_id: string, index: int} $result */
    $result = $done['result'];
    return [
        'post_id' => $post_id,
        'element_id' => $element_id,
        'parent_id' => $result['parent_id'],
        'index' => $result['index'],
        'draft_version_updated' => $done['draft_version'],
        'warnings' => kk_bypass_warnings(
            kk_scoped_warnings($done['warnings'], [$element_id, $result['parent_id']]),
            $post_id,
            $input['allow_open_editor'] ?? false,
        ),
    ];
}
