<?php

// SPDX-FileCopyrightText: 2026 Ovation S.r.l. <dev@novamira.ai>
// SPDX-License-Identifier: AGPL-3.0-or-later

declare(strict_types=1);

namespace Novamira\Pro\Abilities\Kirki;

use WP_Error;

/**
 * Ability: Replace the whole Kirki tree (and page-local style blocks) of a post.
 */

if (!defined('ABSPATH')) {
    exit();
}

// Load order: this file's schemas use constants defined in other ability files of the folder; require them
// explicitly so the folder's alphabetical load order does not decide whether this file loads.
require_once __DIR__ . '/tree.php'; // KK_ALLOW_OPEN_EDITOR_SCHEMA

wp_register_ability('novamira/kirki-set-content', [
    'label' => __('Set Kirki Content', domain: 'novamira-pro'),
    'description' => __(
        'Replaces the entire published Kirki tree of a post: `blocks` (the flat `id => node` map, must contain `root` → `body`) and `styles` (the page-local `id => style block` map, stored exactly as given so a map read back with kirki-get-content `include_style_blocks` round-trips byte for byte; `styleIds` may also point at global classes), optionally `fonts`. Nodes are normalised with the keys the editor expects (visibility, collapse, className, source, styleIds, title, properties.tag, noEndTag on void elements, `parentId` derived from `children`; `root` and `symbol` nodes are stored as given) and validated: ids, element names, tags, class names, attribute names / values and CSS text must be plain (the renderer emits them raw); unknown children, duplicate parents, cycles, an inline node placed both in `contents` and in `children`, missing body, dangling style ids, style ids that only the deprecated global map knows, malformed `dynamicContent`, symbol nodes without a valid `symbolId` or pointing at a self-referencing symbol are rejected; unreachable nodes, unknown element names, self-nested tags, an inline node referenced twice from `contents` and style-block names shared with a placed symbol or a published popup are returned as warnings. Caps: 6000 nodes and 4 MB of JSON per tree. Writes the published tree; when the editor holds a newer unpublished draft the call is refused unless `update_draft: true`, which REPLACES that draft with the same tree in the same transaction. Refused while a Kirki editor tab is open on the post (`kirki_editor_open`) unless `allow_open_editor: true`. Use kirki-add/edit/delete/move-element for targeted changes.',
        domain: 'novamira-pro',
    ),
    'category' => 'kirki',
    'input_schema' => [
        'type' => 'object',
        'properties' => [
            'post_id' => ['type' => 'integer', 'description' => 'Id of a post in Kirki editor mode.'],
            'blocks' => [
                'type' => 'object',
                'description' => 'Flat node map `{id: node}`. Read the shape with kirki-get-element; minimal node: `{id, name, parentId, children?, styleIds?, properties: {tag?, contents?, attributes?}}`.',
            ],
            'styles' => [
                'type' => 'object',
                'description' => 'Page-local style blocks `{id: {id, type: "class", name, variant: {md: "css", md_hover: "css", tablet: "css"}}}`. Default empty.',
            ],
            'fonts' => [
                'type' => 'array',
                'items' => ['type' => 'string'],
                'description' => 'Font family names the page uses (`kirki_used_font_list`), as a list. Omit to leave unchanged.',
            ],
            'update_draft' => [
                'type' => 'boolean',
                'description' => 'Also overwrite the newest unpublished staging draft with this tree, so the editor shows it on its next open (an open tab never re-reads the page). Default false: refuse when such a draft exists.',
                'default' => false,
            ],
            'allow_open_editor' => KK_ALLOW_OPEN_EDITOR_SCHEMA,
        ],
        'required' => ['post_id', 'blocks'],
        'additionalProperties' => false,
    ],
    'output_schema' => [
        'type' => 'object',
        'properties' => [
            'post_id' => ['type' => 'integer'],
            'total_nodes' => ['type' => 'integer'],
            'reachable_nodes' => ['type' => 'integer'],
            'style_blocks_count' => ['type' => 'integer'],
            'draft_version_updated' => ['type' => ['integer', 'null']],
            'warnings' => ['type' => 'array', 'items' => ['type' => 'string']],
        ],
        'required' => [
            'post_id',
            'total_nodes',
            'reachable_nodes',
            'style_blocks_count',
            'draft_version_updated',
            'warnings',
        ],
        'additionalProperties' => false,
    ],
    'execute_callback' => 'Novamira\\Pro\\Abilities\\Kirki\\kirki_set_content',
    'permission_callback' => 'novamira_permission_callback',
    'meta' => [
        'show_in_rest' => true,
        'mcp' => ['public' => true],
        'annotations' => [
            'instructions' => 'The previous tree and page-local style blocks are gone after this call (Kirki keeps no copy of the published tree): read them first with kirki-get-content `include_style_blocks: true` (raw style map) and kirki-get-element (raw nodes) if anything must survive, and feed those back unchanged — the rendered `classes` / `styles[].name` of the readers are NOT the stored names. Prefer kirki-add-element for building up a page section by section. Style-block ids referenced by nodes must resolve either in `styles` or among the site\'s global classes (kirki-get-element shows `scope`). Node and style ids start with a letter and use letters, digits, `-`, `_` (max 64); the editor generates `k-` + 8 lowercase alphanumerics. Every string under `properties` is validated because the renderer prints it raw on the public page (no markup / quotes / script schemes; `properties.code` only unchanged from the stored node; `content` of custom-code and `svgOuterHtml` only when KSES-clean), including the symbol-instance overrides `symbolElProps` / `componentFieldValues`, which Kirki copies into the symbol\'s nodes. Only pages, posts, public custom post types, templates and utility pages are written: popups (flat node map, no staging), symbols and the global-data post are refused (`kirki_unsupported_post_type`). A post without a staging ledger gets one seeded (v1 published) so the editor opens it without its legacy style migration. Every key is written in one database transaction under a per-post lock; the Kirki editor takes neither, so the call is refused while a tab is open on the post (`kirki_editor_open`). After a timeout or a 5xx / HTML response from the server, re-read the page before retrying: the write may have completed after the client gave up.',
            'readonly' => false,
            // Replaces content but never deletes the post; `destructive` would map the core REST route to DELETE with the tree in the query string.
            'destructive' => false,
            'idempotent' => true,
        ],
    ],
]);

/**
 * @param array<string, mixed> $input
 * @return array<string, mixed>|WP_Error
 */
// @mago-expect lint:cyclomatic-complexity -- guard chain of early returns, one per input
// @mago-expect lint:halstead
function kirki_set_content(array $input): array|WP_Error
{
    kk_begin();
    $post_id = kk_coerce_int_or_null($input['post_id'] ?? null) ?? 0;
    $post = kk_writable_post_or_error($post_id);
    if ($post instanceof WP_Error) {
        return $post;
    }
    if (!kk_is_kirki_mode($post_id)) {
        return kk_not_kirki_mode($post_id);
    }
    $open = kk_refuse_open_editor($post_id, $input['allow_open_editor'] ?? false);
    if ($open instanceof WP_Error) {
        return $open;
    }
    /** @var mixed $raw_blocks */
    $raw_blocks = $input['blocks'] ?? null;
    if (!is_array($raw_blocks) || $raw_blocks === []) {
        return kk_invalid_input(__('blocks must be a non-empty object map of nodes.', domain: 'novamira-pro'));
    }
    $encoded = wp_json_encode([$raw_blocks, $input['styles'] ?? []]);
    $size = kk_size_guard(
        $post_id,
        input_bytes: is_string($encoded) ? strlen($encoded) : KK_MAX_TREE_BYTES + 1,
        copies: kk_bool($input['update_draft'] ?? false) ? 2 : 1,
    );
    if ($size instanceof WP_Error) {
        return $size;
    }
    /** @var mixed $raw_styles */
    $raw_styles = $input['styles'] ?? [];
    if (!is_array($raw_styles)) {
        return kk_invalid_input(__('styles must be an object map of style blocks.', domain: 'novamira-pro'));
    }
    $styles = kk_coerce_styles($raw_styles);
    if ($styles instanceof WP_Error) {
        return $styles;
    }
    $fonts = kk_coerce_fonts($input['fonts'] ?? null);
    if ($fonts instanceof WP_Error) {
        return $fonts;
    }

    $blocks = kk_coerce_blocks($raw_blocks);
    if ($blocks instanceof WP_Error) {
        return $blocks;
    }
    // The published write is checked against the PUBLISHED tree: custom code
    // may only pass through unchanged from what is live, never be promoted from
    // an unpublished draft.
    $verdict = kk_validate_tree(
        $blocks,
        $styles,
        kk_effective_styles($post_id, version: null, local: $styles),
        kk_node_map(kk_blocks($post_id) ?? []),
    );
    $errors = array_merge($verdict['errors'], kk_deprecated_style_errors($post_id, version: null, blocks: $blocks));
    if ($errors !== []) {
        return kk_tree_error($errors);
    }
    $draft_version = kk_newest_unpublished_version($post_id);
    if ($draft_version !== null && kk_bool($input['update_draft'] ?? false)) {
        $draft = kk_blocks_for_version($post_id, $draft_version);
        $draft_stored = $draft instanceof WP_Error || !is_array($draft['blocks'] ?? null)
            ? []
            : kk_node_map($draft['blocks']);
        $draft_verdict = kk_validate_tree(
            $blocks,
            $styles,
            kk_effective_styles($post_id, $draft_version, $styles),
            $draft_stored,
        );
        $draft_errors = array_merge($draft_verdict['errors'], kk_deprecated_style_errors(
            $post_id,
            $draft_version,
            $blocks,
        ));
        if ($draft_errors !== []) {
            return kk_draft_tree_error($draft_version, $draft_errors);
        }
    }
    $written = kk_with_post_lock($post_id, static function () use (
        $post_id,
        $input,
        $blocks,
        $styles,
        $fonts,
    ): array|WP_Error {
        kk_refresh($post_id);
        if (kk_live_post($post_id) === null) {
            return kk_invalid_post($post_id);
        }
        $target = kk_write_target($post_id, $input['update_draft'] ?? false);
        if ($target instanceof WP_Error) {
            return $target;
        }
        $jobs = [['blocks' => $blocks, 'styles' => $styles, 'fonts' => $fonts, 'version' => null]];
        if ($target['draft_version'] !== null) {
            $jobs[] = [
                'blocks' => $blocks,
                'styles' => $styles,
                'fonts' => $fonts,
                'version' => $target['draft_version'],
            ];
        }
        // One transaction for both trees: a refused draft key rolls the published write back too.
        $result = kk_write_jobs($post_id, $jobs);
        if ($result instanceof WP_Error) {
            return $result;
        }
        return $target;
    });
    if ($written instanceof WP_Error) {
        return $written;
    }

    return [
        'post_id' => $post_id,
        'total_nodes' => count($blocks),
        'reachable_nodes' => $verdict['reachable'],
        'style_blocks_count' => count($styles),
        'draft_version_updated' => $written['draft_version'],
        'warnings' => kk_bypass_warnings(
            array_merge($verdict['warnings'], kk_foreign_style_warnings($blocks, $styles)),
            $post_id,
            $input['allow_open_editor'] ?? false,
        ),
    ];
}

/**
 * Coerce a `blocks` input map into normalised nodes keyed by id.
 *
 * @param array<array-key, mixed> $raw
 * @return array<string, mixed>|WP_Error
 */
function kk_coerce_blocks(array $raw): array|WP_Error
{
    $blocks = [];
    /** @var mixed $node */
    foreach ($raw as $id => $node) {
        if (!is_string($id)) {
            return kk_invalid_input(sprintf(
                /* translators: %s: node key */
                __(
                    'blocks key `%s` is not a valid node id: ids start with a letter (the map must be an object, not a list).',
                    domain: 'novamira-pro',
                ),
                (string) $id,
            ));
        }
        if (!is_array($node)) {
            return kk_invalid_input(sprintf(
                /* translators: %s: node key */
                __('blocks entry `%s` must be a node object.', domain: 'novamira-pro'),
                $id,
            ));
        }
        /** @var array<string, mixed> $node */
        if (array_key_exists('properties', $node) && !is_array($node['properties'])) {
            return kk_invalid_input(sprintf(
                /* translators: %s: node id */
                __('Node `%s`: `properties` must be an object.', domain: 'novamira-pro'),
                $id,
            ));
        }
        /** @var mixed $parent */
        $parent = $node['parentId'] ?? null;
        // The editor writes `root` without visibility / className / properties: keep it as given.
        $blocks[$id] = $id === 'root'
            ? $node + ['id' => 'root']
            : kk_normalize_node($id, $node, is_string($parent) ? $parent : null);
    }
    // `parentId` follows whoever lists the node; the editor relies on it.
    return kk_fix_parent_ids($blocks);
}

/**
 * Coerce a `styles` input map into well-formed style blocks.
 *
 * @param array<array-key, mixed> $raw
 * @return array<string, array<string, mixed>>|WP_Error
 */
function kk_coerce_styles(array $raw): array|WP_Error
{
    $out = [];
    /** @var mixed $block */
    foreach ($raw as $id => $block) {
        if (!is_string($id) || $id === '' || !is_array($block)) {
            return kk_invalid_input(__(
                'Each style block must be an object keyed by a non-empty id that starts with a letter.',
                domain: 'novamira-pro',
            ));
        }
        /** @var array<string, mixed> $block */
        if (!array_key_exists('id', $block)) {
            $block['id'] = $id;
        }
        if (!isset($block['type']) || !is_string($block['type'])) {
            $block['type'] = 'class';
        }
        if (!isset($block['name']) || !is_string($block['name']) && !is_array($block['name'])) {
            $block['name'] = $id;
        }
        $errors = kk_validate_style_block($id, $block);
        if ($errors !== []) {
            return kk_invalid_input(implode(' ', $errors));
        }
        $out[$id] = $block;
    }
    return $out;
}

/**
 * Coerce a `fonts` input into a list of strings, null when absent, error
 * when it is not a list of strings (WordPress would coerce a bare string
 * into a one-item list; be explicit instead).
 *
 * @return list<string>|null|WP_Error
 */
function kk_coerce_fonts(mixed $raw): array|null|WP_Error
{
    if ($raw === null) {
        return null;
    }
    if (!kk_is_string_list($raw)) {
        return kk_invalid_input(__('fonts must be a list of font family names.', domain: 'novamira-pro'));
    }
    $out = [];
    foreach (kk_string_list($raw) as $font) {
        if (trim($font) === '') {
            continue;
        }
        $out[] = trim($font);
    }
    return array_values(array_unique($out));
}
