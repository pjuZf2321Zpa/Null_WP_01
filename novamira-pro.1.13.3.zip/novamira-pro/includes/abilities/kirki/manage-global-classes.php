<?php

// SPDX-FileCopyrightText: 2026 Ovation S.r.l. <dev@novamira.ai>
// SPDX-License-Identifier: AGPL-3.0-or-later

declare(strict_types=1);

namespace Novamira\Pro\Abilities\Kirki;

use WP_Error;

/**
 * Abilities: Kirki global classes (the "class manager"): list, create, edit,
 * delete a global class, apply one to / clear one from an element of a page.
 *
 * A global class is a style block flagged
 * `isGlobalStyle: true` in the `kirki_class_manager_style_blocks` map of the
 * global-data post. The editor writes that map ENTIRE, immediately, on every
 * class change (`POST kirki/v1/global-styles` → `GlobalDataService::save_styles`),
 * from whatever page a tab is open on; the renderer merges the map into every
 * page (`PageManager::get_page_styleblocks`), prints its CSS before the page's
 * own and puts a class name in `class="…"` when a node lists the class id in
 * `properties.classesIds` (never `styleIds`). Deleting a class leaves those
 * references dangling; the renderer then skips them.
 */

if (!defined('ABSPATH')) {
    exit();
}

// Load order: this file's schemas use constants defined in other ability files of the folder; require them
// explicitly so the folder's alphabetical load order does not decide whether this file loads.
require_once __DIR__ . '/manage-elements.php'; // KK_UPDATE_DRAFT_SCHEMA
require_once __DIR__ . '/tree.php'; // KK_ALLOW_OPEN_EDITOR_SCHEMA

const KK_CLASS_ID_SCHEMA = [
    'type' => 'string',
    'description' => 'Global class id (`k-…`), from kirki-list-global-classes.',
];

const KK_GLOBAL_CSS_SCHEMA = [
    'type' => 'object',
    'description' => 'Viewport => CSS declarations, exactly like an element\'s `css`: keys are a viewport id (`md` is the base) optionally followed by `_<state>` (`md_hover`), values are `property:value;` lists (no selectors, braces or markup). The renderer prints them under `.<name>` inside the page\'s style element.',
];

const KK_GLOBAL_CLASS_ROW_SCHEMA = [
    'id' => ['type' => 'string'],
    'title' => ['type' => 'string', 'description' => 'Label shown in the editor\'s Assets → Styles → Classes panel.'],
    'name' => ['type' => 'string', 'description' => 'The CSS class printed on elements and used as the selector.'],
    'css' => ['type' => 'object', 'description' => 'Variant key => declarations as stored.'],
];

// ---------------------------------------------------------------------------
// list-global-classes
// ---------------------------------------------------------------------------

wp_register_ability('novamira/kirki-list-global-classes', [
    'label' => __('List Kirki Global Classes', domain: 'novamira-pro'),
    'description' => __(
        'Lists Kirki global classes (the class manager: reusable style blocks stored on the global-data post and merged into every page at render time). Each row: `id` (what a node lists in `properties.classesIds`), `title` (the label in the editor\'s Assets → Styles → Classes panel), `name` (the CSS class the renderer prints, `k-xxxxxxxx` when the editor created it) and `css` (variant key => declarations). `include_usage: true` adds, per class, the posts whose stored trees reference it (published tree and staging drafts; pages, templates, utility pages, popups and symbols). `legacy_count` counts the entries of the legacy global map (`kirki_global_style_block`), which the abilities never write. Filter with `search` (substring of title or name); page with `limit` / `offset`.',
        domain: 'novamira-pro',
    ),
    'category' => 'kirki',
    'input_schema' => [
        'type' => 'object',
        'default' => [],
        'properties' => [
            'search' => ['type' => 'string', 'description' => 'Case-insensitive substring match on title or name.'],
            'include_usage' => [
                'type' => 'boolean',
                'description' => 'Add `usage` per class: `{count, posts: [{post_id, post_type, status, title, published_tree}]}` (one SQL scan of the stored trees per class, capped at 200 rows).',
                'default' => false,
            ],
            'limit' => KK_LIMIT_SCHEMA,
            'offset' => KK_OFFSET_SCHEMA,
        ],
        'additionalProperties' => false,
    ],
    'output_schema' => [
        'type' => 'object',
        'properties' => [
            'classes' => [
                'type' => 'array',
                'items' => ['type' => 'object', 'properties' => KK_GLOBAL_CLASS_ROW_SCHEMA],
            ],
            'total' => ['type' => 'integer', 'description' => 'Matching classes before `limit` / `offset`.'],
            'returned' => ['type' => 'integer'],
            'legacy_count' => [
                'type' => 'integer',
                'description' => 'Entries of the deprecated global style map (read-only).',
            ],
            'global_data_post_id' => ['type' => 'integer'],
        ],
        'required' => ['classes', 'total', 'returned', 'legacy_count', 'global_data_post_id'],
        'additionalProperties' => false,
    ],
    'execute_callback' => 'Novamira\\Pro\\Abilities\\Kirki\\kirki_list_global_classes',
    'permission_callback' => 'novamira_permission_callback',
    'meta' => [
        'show_in_rest' => true,
        'mcp' => ['public' => true],
        'annotations' => [
            'instructions' => 'Call this before kirki-apply-global-class to get the class id, and with `include_usage: true` before deleting a class. Global classes apply to elements through `properties.classesIds`, not through `styleIds` (page-local blocks); kirki-get-element resolves both. A page-local block whose name equals a global class name is renamed `<name>-copy` by the renderer.',
            'readonly' => true,
            'destructive' => false,
            'idempotent' => true,
        ],
    ],
]);

/**
 * @param array{search?: mixed, include_usage?: mixed, limit?: mixed, offset?: mixed} $input
 * @return array<string, mixed>|WP_Error
 */
function kirki_list_global_classes(array $input): array|WP_Error
{
    kk_begin();
    $global = kk_global_classes();
    if ($global instanceof WP_Error) {
        return $global;
    }
    /** @var mixed $raw_search */
    $raw_search = $input['search'] ?? '';
    $search = is_string($raw_search) ? strtolower(trim($raw_search)) : '';
    $limit = kk_clamp_limit($input['limit'] ?? null, default: 50);
    $offset = max(0, kk_coerce_int_or_null($input['offset'] ?? null) ?? 0);
    $rows = [];
    foreach ($global['map'] as $id => $block) {
        $row = kk_global_class_row($id, $block);
        if (
            $search !== ''
            && !str_contains(strtolower($row['title']), $search)
            && !str_contains(strtolower($row['name']), $search)
        ) {
            continue;
        }
        $rows[] = $row;
    }
    $total = count($rows);
    $page = array_slice($rows, $offset, $limit);
    if (kk_bool($input['include_usage'] ?? false) && $page !== []) {
        $usage = kk_global_class_usage(array_column($page, 'id'));
        foreach ($page as $index => $row) {
            $posts = $usage[$row['id']] ?? [];
            $page[$index]['usage'] = ['count' => count($posts), 'posts' => $posts];
        }
    }
    $legacy = kk_style_map_of(kk_meta($global['post_id'], kk_meta_deprecated_global_styles()));
    return [
        'classes' => $page,
        'total' => $total,
        'returned' => count($page),
        'legacy_count' => count($legacy),
        'global_data_post_id' => $global['post_id'],
    ];
}

// ---------------------------------------------------------------------------
// create-global-class
// ---------------------------------------------------------------------------

wp_register_ability('novamira/kirki-create-global-class', [
    'label' => __('Create Kirki Global Class', domain: 'novamira-pro'),
    'description' => __(
        'Creates a Kirki global class: a reusable style block every page can apply through kirki-apply-global-class. `title` is the label in the editor\'s Assets → Styles → Classes panel; `css` the declarations per viewport / state (same rules as an element\'s `css`); `name` (optional) the CSS class printed on elements, a random `k-xxxxxxxx` like the editor\'s when omitted. The map is written on the global-data post in one transaction under a lock, read back and verified. Refused while any Kirki editor tab is open (`kirki_editor_open`): every open tab holds the whole class map and re-writes it entire on its next class change, erasing the new class.',
        domain: 'novamira-pro',
    ),
    'category' => 'kirki',
    'input_schema' => [
        'type' => 'object',
        'properties' => [
            'title' => ['type' => 'string', 'description' => 'Plain-text label, up to 200 bytes.'],
            'css' => KK_GLOBAL_CSS_SCHEMA,
            'name' => [
                'type' => 'string',
                'description' => 'Optional CSS class name: one token of letters, digits, `-`, `_` (max 128), unique among global classes, never starting with `kirki-`. Prefer the random default unless the class must match existing theme CSS; a page-local block with the same name is renamed `<name>-copy` by the renderer (the response warns and lists such posts).',
            ],
            'allow_open_editor' => KK_ALLOW_OPEN_EDITOR_SCHEMA,
        ],
        'required' => ['title', 'css'],
        'additionalProperties' => false,
    ],
    'output_schema' => [
        'type' => 'object',
        'properties' => KK_GLOBAL_CLASS_ROW_SCHEMA
            + [
                'warnings' => ['type' => 'array', 'items' => ['type' => 'string']],
            ],
        'required' => ['id', 'title', 'name', 'css', 'warnings'],
        'additionalProperties' => false,
    ],
    'execute_callback' => 'Novamira\\Pro\\Abilities\\Kirki\\kirki_create_global_class',
    'permission_callback' => 'novamira_permission_callback',
    'meta' => [
        'show_in_rest' => true,
        'mcp' => ['public' => true],
        'annotations' => [
            'instructions' => 'Create the class, then apply it to elements with kirki-apply-global-class (the class alone changes nothing on any page). The editor shows the new class in Assets → Styles → Classes and in every element\'s "Add class" search after a reload; an editor tab that was open keeps its own stale copy of the map, which is why writes are refused while one is open.',
            'readonly' => false,
            'destructive' => false,
            'idempotent' => false,
        ],
    ],
]);

/**
 * @param array<string, mixed> $input
 * @return array<string, mixed>|WP_Error
 */
function kirki_create_global_class(array $input): array|WP_Error
{
    kk_begin();
    $css = kk_global_css_input($input['css'] ?? null, allow_clear: false);
    if ($css instanceof WP_Error) {
        return $css;
    }
    $global = kk_global_classes();
    if ($global instanceof WP_Error) {
        return $global;
    }
    $open = kk_refuse_open_editor_global($input['allow_open_editor'] ?? false);
    if ($open instanceof WP_Error) {
        return $open;
    }
    /** @var mixed $raw_name */
    $raw_name = $input['name'] ?? null;
    /** @var mixed $raw_title */
    $raw_title = $input['title'] ?? null;
    $global_id = $global['post_id'];
    return kk_bypass_warned(kk_with_post_lock($global_id, static fn(): array|WP_Error => kk_create_global_class_locked(
        $global_id,
        $css,
        $raw_name,
        $raw_title,
    )), $input['allow_open_editor'] ?? false);
}

// ---------------------------------------------------------------------------
// edit-global-class
// ---------------------------------------------------------------------------

wp_register_ability('novamira/kirki-edit-global-class', [
    'label' => __('Edit Kirki Global Class', domain: 'novamira-pro'),
    'description' => __(
        'Partially updates a Kirki global class: `title` and `name` replace those fields; `css` merges into the stored declarations DECLARATION BY DECLARATION per variant key (`{md: "color:red"}` changes only `color` in `md`; an empty string clears a whole variant). Every page using the class changes with it on its next render. Same transaction, verification and editor gate as kirki-create-global-class.',
        domain: 'novamira-pro',
    ),
    'category' => 'kirki',
    'input_schema' => [
        'type' => 'object',
        'properties' => [
            'class_id' => KK_CLASS_ID_SCHEMA,
            'title' => ['type' => 'string'],
            'name' => [
                'type' => 'string',
                'description' => 'New CSS class name (same rules as on create). Pages print the new name on their next render; nothing else references the old one.',
            ],
            'css' => KK_GLOBAL_CSS_SCHEMA,
            'allow_open_editor' => KK_ALLOW_OPEN_EDITOR_SCHEMA,
        ],
        'required' => ['class_id'],
        'additionalProperties' => false,
    ],
    'output_schema' => [
        'type' => 'object',
        'properties' => KK_GLOBAL_CLASS_ROW_SCHEMA
            + [
                'changed' => ['type' => 'array', 'items' => ['type' => 'string']],
                'warnings' => ['type' => 'array', 'items' => ['type' => 'string']],
            ],
        'required' => ['id', 'title', 'name', 'css', 'changed', 'warnings'],
        'additionalProperties' => false,
    ],
    'execute_callback' => 'Novamira\\Pro\\Abilities\\Kirki\\kirki_edit_global_class',
    'permission_callback' => 'novamira_permission_callback',
    'meta' => [
        'show_in_rest' => true,
        'mcp' => ['public' => true],
        'annotations' => [
            'instructions' => 'Read the class with kirki-list-global-classes first: `css` is a merge, so to drop one declaration you must clear the variant (empty string) and pass the remaining declarations again. Use `include_usage: true` to know which posts change with the class.',
            'readonly' => false,
            'destructive' => false,
            'idempotent' => true,
        ],
    ],
]);

/**
 * @param array<string, mixed> $input
 * @return array<string, mixed>|WP_Error
 */
function kirki_edit_global_class(array $input): array|WP_Error
{
    kk_begin();
    $class_id = kk_class_id_input($input['class_id'] ?? null);
    if ($class_id instanceof WP_Error) {
        return $class_id;
    }
    $css = array_key_exists('css', $input) ? kk_global_css_input($input['css'], allow_clear: true) : null;
    if ($css instanceof WP_Error) {
        return $css;
    }
    $has_title = isset($input['title']) && is_string($input['title']);
    $has_name = isset($input['name']) && is_string($input['name']);
    if (!$has_title && !$has_name && $css === null) {
        return kk_invalid_input(__(
            'Nothing to change: pass at least one of title, name, css.',
            domain: 'novamira-pro',
        ));
    }
    $global = kk_global_classes();
    if ($global instanceof WP_Error) {
        return $global;
    }
    $open = kk_refuse_open_editor_global($input['allow_open_editor'] ?? false);
    if ($open instanceof WP_Error) {
        return $open;
    }
    $patch = [
        'title' => $has_title ? trim($input['title']) : null,
        'name' => $has_name ? $input['name'] : null,
        'css' => $css,
    ];
    $global_id = $global['post_id'];
    return kk_bypass_warned(kk_with_post_lock($global_id, static fn(): array|WP_Error => kk_edit_global_class_locked(
        $global_id,
        $class_id,
        $patch,
    )), $input['allow_open_editor'] ?? false);
}

// ---------------------------------------------------------------------------
// delete-global-class
// ---------------------------------------------------------------------------

wp_register_ability('novamira/kirki-delete-global-class', [
    'label' => __('Delete Kirki Global Class', domain: 'novamira-pro'),
    'description' => __(
        'Deletes a Kirki global class from the class manager. Refused with `kirki_class_in_use` while any stored tree still references it (published trees and staging drafts of pages, templates, utility pages, popups, symbols) unless `force: true`: Kirki keeps no copy, and a deleted class leaves every `properties.classesIds` reference dangling — the renderer then drops the class from those elements silently (exactly what the editor\'s own Delete does). The response lists the posts left with dangling references. Same transaction, verification and editor gate as kirki-create-global-class.',
        domain: 'novamira-pro',
    ),
    'category' => 'kirki',
    'input_schema' => [
        'type' => 'object',
        'properties' => [
            'class_id' => KK_CLASS_ID_SCHEMA,
            'force' => [
                'type' => 'boolean',
                'description' => 'Delete even when trees still reference the class (their elements lose it). Default false.',
                'default' => false,
            ],
            'allow_open_editor' => KK_ALLOW_OPEN_EDITOR_SCHEMA,
        ],
        'required' => ['class_id'],
        'additionalProperties' => false,
    ],
    'output_schema' => [
        'type' => 'object',
        'properties' => [
            'id' => ['type' => 'string'],
            'deleted' => ['type' => 'boolean'],
            'dangling' => [
                'type' => 'array',
                'items' => ['type' => 'object'],
                'description' => 'Posts whose stored trees still list the deleted id in `properties.classesIds` (`{post_id, post_type, status, title, published_tree}`).',
            ],
        ],
        'required' => ['id', 'deleted', 'dangling'],
        'additionalProperties' => false,
    ],
    'execute_callback' => 'Novamira\\Pro\\Abilities\\Kirki\\kirki_delete_global_class',
    'permission_callback' => 'novamira_permission_callback',
    'meta' => [
        'show_in_rest' => true,
        'mcp' => ['public' => true],
        'annotations' => [
            'instructions' => 'Destructive and not undoable. Prefer clearing the class from its elements first (kirki-clear-global-class) so no tree keeps a dangling reference; use `force` only when the user accepts that those elements lose the class.',
            'readonly' => false,
            'destructive' => true,
            'idempotent' => false,
        ],
    ],
]);

/**
 * @param array<string, mixed> $input
 * @return array<string, mixed>|WP_Error
 */
function kirki_delete_global_class(array $input): array|WP_Error
{
    kk_begin();
    $class_id = kk_class_id_input($input['class_id'] ?? null);
    if ($class_id instanceof WP_Error) {
        return $class_id;
    }
    $global = kk_global_classes();
    if ($global instanceof WP_Error) {
        return $global;
    }
    $open = kk_refuse_open_editor_global($input['allow_open_editor'] ?? false);
    if ($open instanceof WP_Error) {
        return $open;
    }
    $force = kk_bool($input['force'] ?? false);
    $global_id = $global['post_id'];
    return kk_with_post_lock($global_id, static function () use ($global_id, $class_id, $force): array|WP_Error {
        $global = kk_global_classes();
        if ($global instanceof WP_Error) {
            return $global;
        }
        $map = $global['map'];
        if (!isset($map[$class_id])) {
            return kk_unknown_class($class_id);
        }
        $usage = kk_global_class_usage([$class_id])[$class_id] ?? [];
        if ($usage !== [] && !$force) {
            return new WP_Error(
                'kirki_class_in_use',
                sprintf(
                    /* translators: 1: class id, 2: post count, 3: post ids */
                    __(
                        'Global class `%1$s` is still referenced by %2$d post(s) (%3$s). Clear it from their elements first (kirki-clear-global-class), or re-run with `force: true` to delete it anyway: those elements then lose the class and keep a dangling reference.',
                        domain: 'novamira-pro',
                    ),
                    $class_id,
                    count($usage),
                    implode(', ', array_map(
                        static fn(array $row): string => strval($row['post_id']),
                        array_slice($usage, offset: 0, length: 20),
                    )),
                ),
                ['status' => 409],
            );
        }
        unset($map[$class_id]);
        $written = kk_write_global_classes($global_id, $map);
        if ($written instanceof WP_Error) {
            return $written;
        }
        return ['id' => $class_id, 'deleted' => true, 'dangling' => $usage];
    });
}

// ---------------------------------------------------------------------------
// apply-global-class / clear-global-class
// ---------------------------------------------------------------------------

const KK_APPLY_CLASS_INPUT_SCHEMA = [
    'type' => 'object',
    'properties' => [
        'post_id' => ['type' => 'integer'],
        'element_id' => ['type' => 'string'],
        'class_id' => KK_CLASS_ID_SCHEMA,
        'update_draft' => KK_UPDATE_DRAFT_SCHEMA,
        'allow_open_editor' => KK_ALLOW_OPEN_EDITOR_SCHEMA,
    ],
    'required' => ['post_id', 'element_id', 'class_id'],
    'additionalProperties' => false,
];

const KK_APPLY_CLASS_OUTPUT_SCHEMA = [
    'type' => 'object',
    'properties' => [
        'post_id' => ['type' => 'integer'],
        'element_id' => ['type' => 'string'],
        'classes_ids' => [
            'type' => 'array',
            'items' => ['type' => 'string'],
            'description' => 'The element\'s `properties.classesIds` after the write.',
        ],
        'changed' => [
            'type' => 'boolean',
            'description' => 'False when the element already was in the requested state (nothing written).',
        ],
        'draft_version_updated' => ['type' => ['integer', 'null']],
        'warnings' => ['type' => 'array', 'items' => ['type' => 'string']],
    ],
    'required' => ['post_id', 'element_id', 'classes_ids', 'changed', 'draft_version_updated', 'warnings'],
    'additionalProperties' => false,
];

wp_register_ability('novamira/kirki-apply-global-class', [
    'label' => __('Apply Kirki Global Class', domain: 'novamira-pro'),
    'description' => __(
        'Applies a global class to one element of a Kirki page, template or utility page: appends the class id to the element\'s `properties.classesIds` (the renderer then prints the class name before the element\'s page-local classes and the class CSS applies). The class must exist in the class manager. Same write path as the element abilities: per-post lock, one transaction, verification, draft policy (`update_draft`), refused while an editor tab is open on that post (`kirki_editor_open`). Idempotent: applying a class the element already has changes nothing.',
        domain: 'novamira-pro',
    ),
    'category' => 'kirki',
    'input_schema' => KK_APPLY_CLASS_INPUT_SCHEMA,
    'output_schema' => KK_APPLY_CLASS_OUTPUT_SCHEMA,
    'execute_callback' => 'Novamira\\Pro\\Abilities\\Kirki\\kirki_apply_global_class',
    'permission_callback' => 'novamira_permission_callback',
    'meta' => [
        'show_in_rest' => true,
        'mcp' => ['public' => true],
        'annotations' => [
            'instructions' => 'Get the class id from kirki-list-global-classes and the element id from kirki-get-content. Global classes cannot be applied to `root` (never rendered) or to inline text runs (rendered without a class attribute); prefer them over duplicating `css` on many elements. Verify on the public page: the element\'s class attribute starts with the class name.',
            'readonly' => false,
            'destructive' => false,
            'idempotent' => true,
        ],
    ],
]);

wp_register_ability('novamira/kirki-clear-global-class', [
    'label' => __('Clear Kirki Global Class', domain: 'novamira-pro'),
    'description' => __(
        'Removes a global class from one element of a Kirki page, template or utility page: drops the class id from the element\'s `properties.classesIds` (the class itself stays in the class manager and on other elements). Accepts ids of deleted classes too, to clean dangling references. Same write path and gate as kirki-apply-global-class. Idempotent: clearing a class the element does not have changes nothing.',
        domain: 'novamira-pro',
    ),
    'category' => 'kirki',
    'input_schema' => KK_APPLY_CLASS_INPUT_SCHEMA,
    'output_schema' => KK_APPLY_CLASS_OUTPUT_SCHEMA,
    'execute_callback' => 'Novamira\\Pro\\Abilities\\Kirki\\kirki_clear_global_class',
    'permission_callback' => 'novamira_permission_callback',
    'meta' => [
        'show_in_rest' => true,
        'mcp' => ['public' => true],
        'annotations' => [
            'instructions' => 'Use it before kirki-delete-global-class on every post kirki-list-global-classes (`include_usage: true`) reports, so no tree keeps a dangling reference. It never deletes the class.',
            'readonly' => false,
            'destructive' => false,
            'idempotent' => true,
        ],
    ],
]);

/**
 * @param array<string, mixed> $input
 * @return array<string, mixed>|WP_Error
 */
function kirki_apply_global_class(array $input): array|WP_Error
{
    return kk_toggle_global_class($input, apply: true);
}

/**
 * @param array<string, mixed> $input
 * @return array<string, mixed>|WP_Error
 */
function kirki_clear_global_class(array $input): array|WP_Error
{
    return kk_toggle_global_class($input, apply: false);
}

/**
 * Shared body of apply / clear: the class is checked against the class
 * manager (apply only), then the element's `properties.classesIds` is
 * rewritten through kk_apply_mutation.
 *
 * @param array<string, mixed> $input
 * @return array<string, mixed>|WP_Error
 */
// @mago-expect lint:no-boolean-flag-parameter -- the two abilities share one body
function kk_toggle_global_class(array $input, bool $apply): array|WP_Error
{
    kk_begin();
    $post_id = kk_coerce_int_or_null($input['post_id'] ?? null) ?? 0;
    /** @var mixed $raw_element */
    $raw_element = $input['element_id'] ?? '';
    $element_id = is_string($raw_element) ? $raw_element : '';
    $class_id = kk_class_id_input($input['class_id'] ?? null);
    if ($class_id instanceof WP_Error) {
        return $class_id;
    }
    $global = kk_global_classes();
    if ($global instanceof WP_Error) {
        return $global;
    }
    $op = static fn(array $blocks, array $styles): array|WP_Error => kk_toggle_classes_ids(
        $blocks,
        $styles,
        $element_id,
        $class_id,
        $apply,
    );
    // `delete-global-class` scans the trees for references under the global
    // post's lock: a reference written while that scan runs would be invisible
    // and the class deleted from under this page. Take the same lock first
    // (owner → target), re-read the map inside it, then write the page.
    $global_id = $global['post_id'];
    $done = kk_with_post_lock($global_id, static function () use (
        $global_id,
        $post_id,
        $input,
        $op,
        $apply,
        $class_id,
    ): array|WP_Error {
        if ($apply) {
            $fresh = kk_global_classes();
            if ($fresh instanceof WP_Error) {
                return $fresh;
            }
            if ($fresh['post_id'] !== $global_id || !isset($fresh['map'][$class_id])) {
                return kk_unknown_class($class_id);
            }
        }
        return kk_apply_mutation($post_id, $input['update_draft'] ?? false, $op, $input['allow_open_editor'] ?? false);
    });
    if ($done instanceof WP_Error) {
        return $done;
    }
    /** @var array{classes_ids: list<string>, changed: bool} $result */
    $result = $done['result'];
    return [
        'post_id' => $post_id,
        'element_id' => $element_id,
        'classes_ids' => $result['classes_ids'],
        'changed' => $result['changed'],
        'draft_version_updated' => $done['draft_version'],
        'warnings' => kk_bypass_warnings(
            kk_scoped_warnings($done['warnings'], [$element_id]),
            $post_id,
            $input['allow_open_editor'] ?? false,
        ),
    ];
}

/**
 * Body of kirki-create-global-class under the global post's lock: the map is
 * re-read, the entry built (id and name generated like the editor's),
 * validated and written.
 *
 * @param array<string, string> $css
 * @return array<string, mixed>|WP_Error
 */
function kk_create_global_class_locked(int $global_id, array $css, mixed $raw_name, mixed $raw_title): array|WP_Error
{
    $global = kk_global_classes();
    if ($global instanceof WP_Error) {
        return $global;
    }
    $map = $global['map'];
    $taken = [];
    foreach ($map as $block) {
        if (!is_string($block['name'] ?? null)) {
            continue;
        }
        $taken[strtolower($block['name'])] = true;
    }
    $id = kk_new_id($map);
    $explicit = is_string($raw_name) && $raw_name !== '';
    $name = $explicit ? $raw_name : kk_new_class_name($taken);
    $block = [
        'id' => $id,
        'type' => 'class',
        'name' => $name,
        'isDefault' => false,
        'variant' => $css,
        'title' => is_string($raw_title) ? trim($raw_title) : '',
        'isGlobalStyle' => true,
    ];
    $errors = kk_validate_global_class($block, $map, self: null);
    if ($errors !== []) {
        return kk_invalid_input(implode(' ', $errors));
    }
    $map[$id] = $block;
    $written = kk_write_global_classes($global_id, $map);
    if ($written instanceof WP_Error) {
        return $written;
    }
    return kk_global_class_row($id, $block) + ['warnings' => kk_global_name_warnings($name, explicit: $explicit)];
}

/**
 * Body of kirki-edit-global-class under the global post's lock.
 *
 * @param array{title: string|null, name: string|null, css: array<string, string>|null} $patch
 * @return array<string, mixed>|WP_Error
 */
function kk_edit_global_class_locked(int $global_id, string $class_id, array $patch): array|WP_Error
{
    $global = kk_global_classes();
    if ($global instanceof WP_Error) {
        return $global;
    }
    $map = $global['map'];
    if (!isset($map[$class_id])) {
        return kk_unknown_class($class_id);
    }
    $changed = [];
    $block = kk_patch_global_class($map[$class_id], $patch, $changed);
    $errors = kk_validate_global_class($block, $map, self: $class_id);
    if ($errors !== []) {
        return kk_invalid_input(implode(' ', $errors));
    }
    $map[$class_id] = $block;
    $written = kk_write_global_classes($global_id, $map);
    if ($written instanceof WP_Error) {
        return $written;
    }
    $name = is_string($block['name'] ?? null) ? $block['name'] : '';
    return (
        kk_global_class_row($class_id, $block)
        + [
            'changed' => $changed,
            'warnings' => kk_global_name_warnings($name, explicit: $patch['name'] !== null),
        ]
    );
}

/**
 * Apply an edit patch to a stored global class entry: title / name replace,
 * css merges declaration by declaration per variant key (`''` clears a key).
 *
 * @param array<string, mixed> $block
 * @param array{title: string|null, name: string|null, css: array<string, string>|null} $patch
 * @param list<string> $changed
 * @return array<string, mixed>
 */
function kk_patch_global_class(array $block, array $patch, array &$changed): array
{
    if ($patch['title'] !== null) {
        $block['title'] = $patch['title'];
        $changed[] = 'title';
    }
    if ($patch['name'] !== null) {
        $block['name'] = $patch['name'];
        $changed[] = 'name';
    }
    if ($patch['css'] !== null) {
        $variant = is_array($block['variant'] ?? null) ? $block['variant'] : [];
        foreach ($patch['css'] as $key => $text) {
            if ($text === '') {
                unset($variant[$key]);
                continue;
            }
            /** @var mixed $existing */
            $existing = $variant[$key] ?? '';
            $variant[$key] = kk_merge_declarations(is_string($existing) ? $existing : '', $text);
        }
        $block['variant'] = $variant;
        $changed[] = 'css';
    }
    $block['isGlobalStyle'] = true;
    $block['type'] = 'class';
    return $block;
}

/**
 * The mutation of apply / clear on a loaded tree: the element's
 * `properties.classesIds` gains or loses the class id (unchanged when it
 * already is in the requested state).
 *
 * @param array<array-key, mixed> $blocks
 * @param array<array-key, mixed> $styles
 * @return array{blocks: array<string, mixed>, styles: array<array-key, mixed>, result: array{classes_ids: list<string>, changed: bool}}|WP_Error
 */
// @mago-expect lint:no-boolean-flag-parameter -- one mutation, two directions
function kk_toggle_classes_ids(
    array $blocks,
    array $styles,
    string $element_id,
    string $class_id,
    bool $apply,
): array|WP_Error {
    $blocks = kk_node_map($blocks);
    if ($element_id === '' || !isset($blocks[$element_id]) || !is_array($blocks[$element_id])) {
        return kk_unknown_node($element_id);
    }
    if ($element_id === 'root') {
        return kk_invalid_input(__(
            '`root` is never rendered; apply classes to `body` or to an element inside it.',
            domain: 'novamira-pro',
        ));
    }
    if (kk_inline_referrers($element_id, $blocks) !== []) {
        return kk_invalid_input(sprintf(
            /* translators: %s: node id */
            __(
                'Node `%s` is an inline text run (referenced from `contents`): the renderer prints it without a class attribute.',
                domain: 'novamira-pro',
            ),
            $element_id,
        ));
    }
    $node = kk_node_map($blocks[$element_id]);
    $props = isset($node['properties']) && is_array($node['properties']) ? $node['properties'] : [];
    $current = kk_string_list($props['classesIds'] ?? null);
    if ($apply && in_array($class_id, $current, strict: true)) {
        // Re-applying must not move the id to the end: the print order of
        // `classesIds` is the cascade tie-break between two classes that style
        // the same declaration.
        return ['blocks' => $blocks, 'styles' => $styles, 'result' => ['classes_ids' => $current, 'changed' => false]];
    }
    $next = array_values(array_filter($current, static fn(string $id): bool => $id !== $class_id));
    if ($apply) {
        $next[] = $class_id;
    }
    if ($next === $current) {
        return ['blocks' => $blocks, 'styles' => $styles, 'result' => ['classes_ids' => $current, 'changed' => false]];
    }
    unset($props['classesIds']);
    if ($next !== []) {
        $props['classesIds'] = $next;
    }
    $node['properties'] = $props;
    $blocks[$element_id] = $node;
    return ['blocks' => $blocks, 'styles' => $styles, 'result' => ['classes_ids' => $next, 'changed' => true]];
}

// ---------------------------------------------------------------------------
// Shared input helpers
// ---------------------------------------------------------------------------

/** A class id input as a string, or the invalid-input error. */
function kk_class_id_input(mixed $raw): string|WP_Error
{
    if (!is_string($raw) || $raw === '' || kk_validate_id($raw) !== null) {
        return kk_invalid_input(__(
            'class_id must be a global class id (`k-…`, from kirki-list-global-classes).',
            domain: 'novamira-pro',
        ));
    }
    return $raw;
}

/**
 * A `css` input as a trimmed variant map (`''` entries kept only when
 * clearing is allowed), or the invalid-input error.
 *
 * @return array<string, string>|WP_Error
 */
// @mago-expect lint:no-boolean-flag-parameter -- create refuses empty variants, edit uses them to clear
function kk_global_css_input(mixed $raw, bool $allow_clear): array|WP_Error
{
    if (!is_array($raw) || $raw !== [] && kk_is_list($raw)) {
        return kk_invalid_input(__('css must be an object of viewport => css declarations.', domain: 'novamira-pro'));
    }
    $errors = $allow_clear ? kk_validate_css_map_allow_clear($raw) : kk_validate_css_map($raw);
    $css = [];
    /** @var mixed $text */
    foreach ($raw as $key => $text) {
        if (!is_string($text)) {
            continue;
        }
        $text = trim($text);
        if ($text === '' && !$allow_clear) {
            $errors[] = sprintf('css value for `%s` is empty.', strval($key));
            continue;
        }
        if ($text !== '' && kk_parse_declarations($text) === []) {
            $errors[] = sprintf('css value for `%s` holds no `property:value` declaration.', strval($key));
            continue;
        }
        $css[strval($key)] = $text;
    }
    if ($errors !== []) {
        return kk_invalid_input(implode(' ', array_values(array_unique($errors))));
    }
    return $css;
}

/** The 404 of a class id the class manager does not hold. */
function kk_unknown_class(string $class_id): WP_Error
{
    return new WP_Error(
        'kirki_unknown_class',
        sprintf(
            /* translators: %s: class id */
            __(
                'No global class with id `%s` exists in the class manager (kirki-list-global-classes lists them).',
                domain: 'novamira-pro',
            ),
            $class_id,
        ),
        ['status' => 404],
    );
}

/**
 * Warning for an explicit class name a page-local style block already uses
 * (the renderer renames that block `<name>-copy`, so the page's own rule
 * stops matching its elements).
 *
 * @return list<string>
 */
// @mago-expect lint:no-boolean-flag-parameter -- random names never collide with editor-made ones
function kk_global_name_warnings(string $name, bool $explicit): array
{
    if (!$explicit) {
        return [];
    }
    $holders = kk_local_style_name_holders($name);
    if ($holders === []) {
        return [];
    }
    return [sprintf(
        'Class name `%s` is also the name of a page-local style block on post(s) %s: the renderer renames those local blocks `%s-copy`, so their elements lose that rule. Pick another name or rename the local blocks.',
        $name,
        implode(', ', array_map('strval', $holders)),
        $name,
    )];
}
