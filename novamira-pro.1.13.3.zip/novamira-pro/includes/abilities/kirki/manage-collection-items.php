<?php

// SPDX-FileCopyrightText: 2026 Ovation S.r.l. <dev@novamira.ai>
// SPDX-License-Identifier: AGPL-3.0-or-later

declare(strict_types=1);

namespace Novamira\Pro\Abilities\Kirki;

use WP_Error;
use WP_Post;
use WP_Query;

/**
 * Abilities: Kirki Content Manager items — the posts of type
 * `kirki_cm_<collection id>` (parent = the collection) whose field values
 * live in `kirki_cm_field_<collection>_<field>` meta rows and, for reference
 * fields, in `kirki_cm_reference` rows.
 *
 * Kirki's editor saves an item through `wp_insert_post` / `wp_update_post`
 * plus meta upserts and a delete + insert of the reference rows per field,
 * and validates values in its item form (required, character limits,
 * email / phone rules, number formats, media formats). The writers here
 * apply the same rules server-side, also check that references point at
 * items of the target collection, write in one transaction and
 * read every row back. Items are saved one by one, so the editor gate does
 * not apply: an open tab overwrites nothing but the item it saves.
 */

if (!defined('ABSPATH')) {
    exit();
}

const KK_CM_ITEM_STATUSES = ['draft', 'publish', 'future'];

const KK_CM_VALUES_SCHEMA = [
    'type' => 'object',
    'description' => 'Values keyed by field id (kirki-get-collection `fields[].id`). Shapes: text / email / phone / url / file → string; rich-text → HTML (wp_kses_post-clean); number → number or numeric string; switch → boolean or `on` / `off`; option → one of the option values; date → `YYYY-MM-DD` (`YYYY-MM-DD HH:MM` when the field includes a time); time → `{value: "HH:MM", unit: "am"|"pm"}` or `"HH:MM am"`, on the editor\'s 12-hour clock (HH 01–12); image / video → `{id: <attachment id>}` (`{url}` on URL-type fields); gallery → list of `{id}`; reference → item id; multi-reference → list of item ids. `null` clears a value.',
    'additionalProperties' => true,
];

const KK_CM_ITEM_ROW_PROPERTIES = [
    'id' => ['type' => 'integer'],
    'collection_id' => ['type' => 'integer'],
    'title' => ['type' => 'string'],
    'slug' => ['type' => 'string'],
    'status' => ['type' => 'string'],
    'date' => ['type' => 'string', 'description' => '`post_date` (site time zone).'],
    'modified' => ['type' => 'string'],
    'url' => [
        'type' => 'string',
        'description' => 'Permalink (served only for published items, and only when the rewrite rules were flushed; see kirki-get-collection `pretty_urls`).',
    ],
];

// ---------------------------------------------------------------------------
// list-collection-items
// ---------------------------------------------------------------------------

wp_register_ability('novamira/kirki-list-collection-items', [
    'label' => __('List Kirki Collection Items', domain: 'novamira-pro'),
    'description' => __(
        'Lists the items of a Content Manager collection (posts of type `kirki_cm_<collection id>`): id, title, slug, status (draft / publish / future), dates and permalink, newest first as the editor lists them; `include_fields: true` adds every field value (references resolved to `[{value, title, status}]`). Filter with `status` and `search` (title), page with `limit` / `offset`. Read straight from the database.',
        domain: 'novamira-pro',
    ),
    'category' => 'kirki',
    'input_schema' => [
        'type' => 'object',
        'properties' => [
            'collection_id' => ['type' => 'integer', 'description' => 'Id of the collection (kirki-list-collections).'],
            'status' => [
                'type' => 'string',
                'enum' => ['draft', 'publish', 'future', 'any'],
                'description' => 'Only items in this status (default `any`).',
            ],
            'search' => ['type' => 'string', 'description' => KK_SEARCH_DESCRIPTION],
            'limit' => KK_LIMIT_SCHEMA,
            'offset' => KK_OFFSET_SCHEMA,
            'include_fields' => [
                'type' => 'boolean',
                'description' => 'Add `fields` (values keyed by field id) to every row. Default false.',
                'default' => false,
            ],
        ],
        'required' => ['collection_id'],
        'additionalProperties' => false,
    ],
    'output_schema' => [
        'type' => 'object',
        'properties' => [
            'collection_id' => ['type' => 'integer'],
            'items' => [
                'type' => 'array',
                'items' => [
                    'type' => 'object',
                    'properties' => KK_CM_ITEM_ROW_PROPERTIES + ['fields' => ['type' => 'object']],
                    'required' => ['id', 'collection_id', 'title', 'slug', 'status', 'date', 'modified', 'url'],
                    'additionalProperties' => false,
                ],
            ],
            'total' => ['type' => 'integer'],
            'warnings' => ['type' => 'array', 'items' => ['type' => 'string']],
        ],
        'required' => ['collection_id', 'items', 'total', 'warnings'],
        'additionalProperties' => false,
    ],
    'execute_callback' => 'Novamira\\Pro\\Abilities\\Kirki\\kirki_list_collection_items',
    'permission_callback' => 'novamira_permission_callback',
    'meta' => [
        'show_in_rest' => true,
        'mcp' => ['public' => true],
        'annotations' => [
            'instructions' => 'Only published items render on the frontend and count as reference targets for visitors; drafts are editable but invisible.',
            'readonly' => true,
            'destructive' => false,
            'idempotent' => true,
        ],
    ],
]);

/**
 * @param array<string, mixed> $input
 * @return array<string, mixed>|WP_Error
 */
// @mago-expect lint:cyclomatic-complexity -- one refusal per filter, all flat
function kirki_list_collection_items(array $input): array|WP_Error
{
    kk_begin();
    $collection = kk_collection_post_or_error(kk_coerce_int_or_null($input['collection_id'] ?? null) ?? 0);
    if ($collection instanceof WP_Error) {
        return $collection;
    }
    $needle = kk_search_needle($input['search'] ?? null);
    if ($needle instanceof WP_Error) {
        return $needle;
    }
    /** @var mixed $status */
    $status = $input['status'] ?? 'any';
    if (!in_array($status, ['draft', 'publish', 'future', 'any'], strict: true)) {
        return kk_invalid_input('`status` must be draft, publish, future or any.');
    }
    $limit = kk_clamp_limit($input['limit'] ?? null, default: 50);
    $offset = max(0, kk_coerce_int_or_null($input['offset'] ?? null) ?? 0);
    kk_register_item_post_type($collection);
    $args = [
        'post_type' => kk_item_post_type($collection->ID),
        'post_parent' => $collection->ID,
        'post_status' => $status === 'any' ? KK_CM_ITEM_STATUSES : [$status],
        'posts_per_page' => $limit,
        'offset' => $offset,
        'orderby' => 'ID',
        'order' => 'DESC',
        'no_found_rows' => false,
        'ignore_sticky_posts' => true,
        'suppress_filters' => true,
    ];
    if ($needle !== null) {
        $args['s'] = $needle;
    }
    $query = new WP_Query($args);
    $defs = kk_cm_stored_defs($collection->ID);
    $with_fields = kk_bool($input['include_fields'] ?? false);
    $rows = [];
    $bytes = 0;
    foreach ($query->posts as $post) {
        if (!$post instanceof WP_Post) {
            continue;
        }
        $row = kk_cm_item_row($post);
        if ($with_fields) {
            $row['fields'] = kk_cm_item_values($post, $defs)['fields'];
            // A wide collection (100 fields, rich text) makes this page grow
            // without any cap: refuse like every other reader instead of
            // handing back megabytes.
            $bytes += strlen((string) wp_json_encode($row));
            if ($bytes > KK_CM_PAGE_BYTES) {
                return new WP_Error(
                    'kirki_too_large',
                    sprintf(
                        /* translators: 1: bytes, 2: item count */
                        __(
                            'The values of these items hold more than %1$d bytes (reached at item %2$d of the page); these abilities return less than that per call. Lower `limit`, or drop `include_fields` and read the items you need with kirki-get-collection-item.',
                            domain: 'novamira-pro',
                        ),
                        KK_CM_PAGE_BYTES,
                        count($rows) + 1,
                    ),
                    ['status' => 413],
                );
            }
        }
        $rows[] = $row;
    }
    return [
        'collection_id' => $collection->ID,
        'items' => $rows,
        'total' => kk_found_total($query, $args),
        'warnings' => [],
    ];
}

/** @return array<string, mixed> */
function kk_cm_item_row(WP_Post $post): array
{
    return [
        'id' => $post->ID,
        'collection_id' => (int) $post->post_parent,
        'title' => $post->post_title,
        'slug' => $post->post_name,
        'status' => $post->post_status,
        'date' => $post->post_date,
        'modified' => kk_modified_gmt($post),
        'url' => get_permalink($post),
    ];
}

// ---------------------------------------------------------------------------
// get-collection-item
// ---------------------------------------------------------------------------

wp_register_ability('novamira/kirki-get-collection-item', [
    'label' => __('Get Kirki Collection Item', domain: 'novamira-pro'),
    'description' => __(
        'Reads one Content Manager item: title, slug, status, dates, permalink and every field value keyed by field id exactly as stored (references resolved to `[{value, title, status}]` from the reference table); `defaults_applied` lists the fields with no stored row, whose value shown is the field\'s default (what the frontend prints); `referenced_by` lists the items whose reference fields point at this one.',
        domain: 'novamira-pro',
    ),
    'category' => 'kirki',
    'input_schema' => [
        'type' => 'object',
        'properties' => [
            'item_id' => ['type' => 'integer', 'description' => 'Id of the item (kirki-list-collection-items).'],
        ],
        'required' => ['item_id'],
        'additionalProperties' => false,
    ],
    'output_schema' => [
        'type' => 'object',
        'properties' => KK_CM_ITEM_ROW_PROPERTIES
            + [
                'fields' => ['type' => 'object'],
                'defaults_applied' => ['type' => 'array', 'items' => ['type' => 'string']],
                'referenced_by' => ['type' => 'array', 'items' => ['type' => 'object']],
                'warnings' => ['type' => 'array', 'items' => ['type' => 'string']],
            ],
        'required' => [
            'id',
            'collection_id',
            'title',
            'slug',
            'status',
            'date',
            'modified',
            'url',
            'fields',
            'defaults_applied',
            'referenced_by',
            'warnings',
        ],
        'additionalProperties' => false,
    ],
    'execute_callback' => 'Novamira\\Pro\\Abilities\\Kirki\\kirki_get_collection_item',
    'permission_callback' => 'novamira_permission_callback',
    'meta' => [
        'show_in_rest' => true,
        'mcp' => ['public' => true],
        'annotations' => [
            'instructions' => 'The values come back in the stored shape; pass them (or ids for references) to kirki-edit-collection-item to change some of them.',
            'readonly' => true,
            'destructive' => false,
            'idempotent' => true,
        ],
    ],
]);

/**
 * @param array<string, mixed> $input
 * @return array<string, mixed>|WP_Error
 */
function kirki_get_collection_item(array $input): array|WP_Error
{
    kk_begin();
    $post = kk_item_post_or_error(kk_coerce_int_or_null($input['item_id'] ?? null) ?? 0);
    if ($post instanceof WP_Error) {
        return $post;
    }
    return kk_cm_item_report($post, []);
}

/**
 * @param list<string> $warnings
 * @return array<string, mixed>
 */
function kk_cm_item_report(WP_Post $post, array $warnings): array
{
    $defs = kk_cm_stored_defs((int) $post->post_parent);
    $values = kk_cm_item_values($post, $defs);
    $stored = array_diff_key($values['fields'], array_flip($values['defaults_applied']));
    return (
        kk_cm_item_row($post)
        + [
            'fields' => $values['fields'],
            'defaults_applied' => $values['defaults_applied'],
            'referenced_by' => kk_item_referenced_by($post->ID),
            // The write path computed the same fallback warnings on the values it
            // normalised; keep one of each.
            'warnings' => array_values(array_unique(array_merge($warnings, kk_cm_fallback_warnings($defs, $stored)))),
        ]
    );
}

// ---------------------------------------------------------------------------
// create-collection-item
// ---------------------------------------------------------------------------

wp_register_ability('novamira/kirki-create-collection-item', [
    'label' => __('Create Kirki Collection Item', domain: 'novamira-pro'),
    'description' => __(
        'Creates an item in a Content Manager collection the way the editor\'s Add Item does: a post of type `kirki_cm_<collection id>` (title, slug, status `draft` by default / `publish` / `future` with `date`), one meta row per field value and reference rows for reference fields. Values are validated against the field definitions with the editor\'s own rules (required, character limits, email / phone patterns, number format, option values, media format and size) plus what the renderer needs (dates `YYYY-MM-DD`, media `{id}` of a real attachment, references = live items of the target collection). Required fields left out take the definition\'s default (stored). Written in one transaction, every row read back; a refused write leaves no post. Never gated by open editor tabs (Kirki saves items one by one). Also accepted: `post_title`, `post_name`, `post_status`, `post_date`.',
        domain: 'novamira-pro',
    ),
    'category' => 'kirki',
    'input_schema' => [
        'type' => 'object',
        'properties' => [
            'collection_id' => ['type' => 'integer', 'description' => 'Id of the collection.'],
            'title' => [
                'type' => 'string',
                'description' => 'Item name (1–200 bytes, plain). Also accepted as `post_title`.',
            ],
            'post_title' => ['type' => 'string', 'description' => 'Alias of `title`.'],
            'slug' => [
                'type' => 'string',
                'description' => 'Item slug (default: from the title; WordPress suffixes a taken one). Also accepted as `post_name`.',
            ],
            'post_name' => ['type' => 'string', 'description' => 'Alias of `slug`.'],
            'status' => [
                'type' => 'string',
                'enum' => KK_CM_ITEM_STATUSES,
                'description' => '`draft` (default), `publish`, or `future` (needs a future `date`). Also accepted as `post_status`.',
            ],
            'post_status' => ['type' => 'string', 'enum' => KK_CM_ITEM_STATUSES, 'description' => 'Alias of `status`.'],
            'date' => [
                'type' => 'string',
                'description' => 'Publication date-time in the site time zone (`YYYY-MM-DD HH:MM[:SS]`); required for `future`. Also accepted as `post_date`.',
            ],
            'post_date' => ['type' => 'string', 'description' => 'Alias of `date`.'],
            'fields' => KK_CM_VALUES_SCHEMA,
        ],
        'required' => ['collection_id'],
        'additionalProperties' => false,
    ],
    'output_schema' => [
        'type' => 'object',
        'properties' => KK_CM_ITEM_ROW_PROPERTIES
            + [
                'fields' => ['type' => 'object'],
                'defaults_applied' => ['type' => 'array', 'items' => ['type' => 'string']],
                'referenced_by' => ['type' => 'array', 'items' => ['type' => 'object']],
                'written' => ['type' => 'array', 'items' => ['type' => 'string']],
                'warnings' => ['type' => 'array', 'items' => ['type' => 'string']],
            ],
        'required' => [
            'id',
            'collection_id',
            'title',
            'slug',
            'status',
            'date',
            'modified',
            'url',
            'fields',
            'defaults_applied',
            'written',
            'warnings',
        ],
        'additionalProperties' => false,
    ],
    'execute_callback' => 'Novamira\\Pro\\Abilities\\Kirki\\kirki_create_collection_item',
    'permission_callback' => 'novamira_permission_callback',
    'meta' => [
        'show_in_rest' => true,
        'mcp' => ['public' => true],
        'annotations' => [
            'instructions' => 'Read kirki-get-collection first for the field ids and types. Publish to render; verify on the item URL (a template targeting the item post type must exist) or through kirki-get-collection-item.',
            'readonly' => false,
            'destructive' => false,
            'idempotent' => false,
        ],
    ],
]);

/**
 * @param array<string, mixed> $input
 * @return array<string, mixed>|WP_Error
 */
// @mago-expect lint:cyclomatic-complexity -- one refusal per branch, all flat
// @mago-expect lint:halstead
function kirki_create_collection_item(array $input): array|WP_Error
{
    kk_begin();
    $collection = kk_collection_post_or_error(kk_coerce_int_or_null($input['collection_id'] ?? null) ?? 0);
    if ($collection instanceof WP_Error) {
        return $collection;
    }
    kk_register_item_post_type($collection);
    /** @var mixed $title */
    $title = $input['title'] ?? $input['post_title'] ?? null;
    $title_error = kk_cm_label_error($title, field: 'title', required: true);
    if ($title_error !== null) {
        return kk_invalid_input($title_error);
    }
    $title = is_string($title) ? trim($title) : '';
    $slug = kk_cm_slug_input($input['slug'] ?? $input['post_name'] ?? null, $title);
    if ($slug instanceof WP_Error) {
        return $slug;
    }
    $slug_error = kk_cm_item_slug_error($slug, $collection->ID, exclude: 0);
    if ($slug_error !== null) {
        return $slug_error;
    }
    $timing = kk_cm_timing_input(
        $input['status'] ?? $input['post_status'] ?? 'draft',
        $input['date'] ?? $input['post_date'] ?? null,
        current: null,
    );
    if ($timing instanceof WP_Error) {
        return $timing;
    }
    $defs = kk_cm_stored_defs($collection->ID);
    $values = kk_cm_values_input($defs, $input['fields'] ?? [], partial: false);
    if ($values instanceof WP_Error) {
        return $values;
    }
    $payload = [
        'post_type' => kk_item_post_type($collection->ID),
        'post_parent' => $collection->ID,
        'post_title' => $title,
        'post_name' => $slug,
    ];
    foreach ($timing['post'] as $column => $value) {
        $payload[$column] = $value;
    }
    // @mago-expect analysis:possibly-invalid-argument
    $item_id = wp_insert_post($payload, wp_error: true);
    if ($item_id instanceof WP_Error) {
        return new WP_Error(
            'kirki_create_failed',
            sprintf(
                /* translators: %s: WordPress message */
                __('WordPress refused to insert the item post (%s).', domain: 'novamira-pro'),
                $item_id->get_error_message(),
            ),
            ['status' => 500],
        );
    }
    $collection_id = $collection->ID;
    $written = kk_with_post_lock($item_id, static fn(): bool|WP_Error => kk_db_transaction($item_id, static fn(): bool|WP_Error => kk_cm_write_values_verified(
        $item_id,
        $collection_id,
        $values,
    )));
    if ($written instanceof WP_Error) {
        wp_delete_post($item_id, force_delete: true);
        return $written;
    }
    $post = kk_live_post($item_id);
    if (!$post instanceof WP_Post) {
        return kk_invalid_post($item_id);
    }
    $warnings = $values['warnings'];
    if ($post->post_status !== $timing['post']['post_status']) {
        $warnings[] = sprintf(
            'WordPress stored the item as `%s` instead of `%s`.',
            $post->post_status,
            $timing['post']['post_status'],
        );
    }
    if ($post->post_name !== $slug) {
        $warnings[] = sprintf('The slug `%s` was taken; WordPress stored `%s`.', $slug, $post->post_name);
    }
    if ($post->post_status !== 'publish') {
        $warnings[] = 'The item is not published: the frontend does not render it and does not list it in collection elements.';
    }
    $report = kk_cm_item_report($post, $warnings);
    $report['written'] = array_merge(['post'], array_keys($values['meta']), array_keys($values['references']));
    return $report;
}

/**
 * Status + date to store, WordPress column names: `future` needs a future
 * date, `publish` with a future date would be turned into `future` by
 * WordPress (refused: say what you mean), `draft` keeps whatever date.
 *
 * @param WP_Post|null $current the item being edited (null on create)
 * @return array{post: array<string, string>, changed: list<string>}|WP_Error
 */
// @mago-expect lint:cyclomatic-complexity
function kk_cm_timing_input(mixed $status, mixed $date, ?WP_Post $current): array|WP_Error
{
    if (!is_string($status) || !in_array($status, KK_CM_ITEM_STATUSES, strict: true)) {
        return kk_invalid_input('`status` must be draft, publish or future.');
    }
    $post = [];
    $changed = [];
    if ($current === null || $current->post_status !== $status) {
        $post['post_status'] = $status;
        $changed[] = 'status';
    }
    if ($date !== null) {
        if (!is_string($date) || trim($date) === '') {
            return kk_invalid_input('`date` must be a `YYYY-MM-DD HH:MM[:SS]` string in the site time zone.');
        }
        $parsed = date_create_immutable(trim($date), wp_timezone());
        if ($parsed === false || preg_match('/^\d{4}-\d{2}-\d{2}([ T]\d{2}:\d{2}(:\d{2})?)?$/', trim($date)) !== 1) {
            return kk_invalid_input('`date` must be a `YYYY-MM-DD HH:MM[:SS]` string in the site time zone.');
        }
        $local = $parsed->format('Y-m-d H:i:s');
        if ($current === null || $current->post_date !== $local) {
            $post['post_date'] = $local;
            $post['post_date_gmt'] = get_gmt_from_date($local);
            $changed[] = 'date';
        }
    }
    $effective_date = $post['post_date'] ?? ($current instanceof WP_Post ? $current->post_date : current_time('mysql'));
    $in_future = $effective_date > current_time('mysql');
    if ($status === 'future' && !$in_future) {
        return kk_invalid_input('`status: future` needs a `date` later than now (site time zone).');
    }
    if ($status === 'publish' && $in_future && $date !== null) {
        return kk_invalid_input(
            '`status: publish` with a future `date` would be stored as `future` by WordPress; pass `status: future`.',
        );
    }
    if ($status === 'publish' && $current instanceof WP_Post && $current->post_status !== 'publish' && $date === null) {
        // Kirki's service stamps the publication moment when an item goes live.
        $now = current_time('mysql');
        $post['post_date'] = $now;
        $post['post_date_gmt'] = get_gmt_from_date($now);
    }
    return ['post' => $post, 'changed' => $changed];
}

/** Reserved words (Kirki's `validate_slug`) and other live items of the collection. */
function kk_cm_item_slug_error(string $slug, int $collection_id, int $exclude): ?WP_Error
{
    if (in_array($slug, KK_CM_RESERVED_SLUGS, strict: true)) {
        return kk_invalid_input(sprintf(
            '`slug` `%s` is reserved by Kirki (%s).',
            $slug,
            implode(', ', KK_CM_RESERVED_SLUGS),
        ));
    }
    $holder = kk_cm_slug_holder($slug, kk_item_post_type($collection_id), $exclude);
    if ($holder !== null) {
        return new WP_Error(
            'kirki_slug_collision',
            sprintf(
                /* translators: 1: slug, 2: post id */
                __('Slug `%1$s` is already used by item %2$d of the same collection.', domain: 'novamira-pro'),
                $slug,
                $holder,
            ),
            ['status' => 409],
        );
    }
    return null;
}

/**
 * Validate the `fields` input against the definitions and split it into what
 * to store: meta rows (value, or null = delete the row), reference rows
 * (list of item ids per field meta key), plus the normalised values.
 *
 * @param list<array<string, mixed>> $defs
 * @return array{meta: array<string, mixed>, references: array<string, list<int>>, normalized: array<string, mixed>, warnings: list<string>}|WP_Error
 */
// @mago-expect lint:cyclomatic-complexity
// @mago-expect lint:halstead
// @mago-expect lint:no-boolean-flag-parameter -- create fills defaults, edit merges
function kk_cm_values_input(array $defs, mixed $given, bool $partial): array|WP_Error
{
    if ($given === null) {
        $given = [];
    }
    if (!is_array($given) || $given !== [] && kk_is_list($given)) {
        return kk_invalid_input('`fields` must be an object keyed by field id.');
    }
    $by_id = [];
    foreach ($defs as $def) {
        $by_id[(string) $def['id']] = $def;
    }
    $unknown = array_diff(array_keys($given), array_keys($by_id));
    if ($unknown !== []) {
        return kk_invalid_input(sprintf(
            'Unknown field id(s) `%s`; the collection defines: %s.',
            implode('`, `', array_map('strval', $unknown)),
            implode(', ', array_map(static fn(array $d): string => sprintf(
                '`%s` (%s, %s)',
                (string) $d['id'],
                (string) $d['title'],
                (string) $d['type'],
            ), $defs)),
        ));
    }
    $errors = [];
    $meta = [];
    $references = [];
    $normalized = [];
    $notes = [];
    foreach ($defs as $def) {
        $id = (string) $def['id'];
        $is_reference = in_array($def['type'], KK_CM_REFERENCE_TYPES, strict: true);
        /** @var mixed $default */
        $default = kk_cm_field_default($def);
        if (!array_key_exists($id, $given)) {
            if ($partial) {
                continue;
            }
            if ($default === null) {
                if (kk_bool($def['required'] ?? false)) {
                    $errors[] = sprintf('field `%s` (%s) is required.', $id, (string) $def['title']);
                }
                continue;
            }
            // The editor prefills the default on every new item and stores it
            // (an `option` field's default is the option marked `isDefault`).
            $given[$id] = $default;
        }
        $result = kk_cm_normalize_value($def, $given[$id]);
        if ($result['error'] !== null) {
            $errors[] = sprintf('field `%s` (%s) %s', $id, (string) $def['title'], $result['error']);
            continue;
        }
        if ($result['empty'] && kk_bool($def['required'] ?? false)) {
            $errors[] = sprintf('field `%s` (%s) is required and cannot be empty.', $id, (string) $def['title']);
            continue;
        }
        $normalized[$id] = $result['value'];
        if (isset($result['warning'])) {
            $notes[] = sprintf('Field `%s` (%s) %s', $id, (string) $def['title'], $result['warning']);
        }
        if ($is_reference) {
            /** @var list<int> $ids */
            $ids = is_array($result['value']) ? $result['value'] : [];
            $references[$id] = $ids;
            continue;
        }
        $meta[$id] = $result['value'];
    }
    if ($errors !== []) {
        return kk_invalid_input(implode(' ', $errors));
    }
    return [
        'meta' => $meta,
        'references' => $references,
        'normalized' => $normalized,
        'warnings' => [...$notes, ...kk_cm_fallback_warnings($defs, $normalized)],
    ];
}

/**
 * Refuse a value write whose field is no longer in the collection's stored
 * list. The values were validated against the definitions read BEFORE this
 * item's lock, and the collection's own lock is a different key: a field
 * removed in between would otherwise leave a meta row for a field that does
 * not exist, or a row the removal's cleanup has already swept, while the
 * caller is told the write succeeded. Re-read inside the
 * transaction and refuse instead.
 *
 * @param array{meta: array<string, mixed>, references: array<string, list<int>>, normalized?: array<string, mixed>, warnings?: list<string>} $values
 */
function kk_cm_stale_fields_error(int $collection_id, array $values): ?WP_Error
{
    $known = [];
    foreach (kk_cm_stored_defs($collection_id) as $def) {
        if (!is_string($def['id'] ?? null)) {
            continue;
        }
        $known[$def['id']] = true;
    }
    $gone = [];
    foreach ([...array_keys($values['meta']), ...array_keys($values['references'])] as $field_id) {
        if (isset($known[$field_id])) {
            continue;
        }
        $gone[] = strval($field_id);
    }
    if ($gone === []) {
        return null;
    }
    return kk_invalid_input(sprintf(
        /* translators: 1: field ids, 2: collection id */
        __(
            'Field(s) `%1$s` are no longer defined on collection %2$d: they were removed while this write was being prepared (kirki-edit-collection removes a field and every item value for it). Nothing was written; read the field list again with kirki-get-collection.',
            domain: 'novamira-pro',
        ),
        implode('`, `', $gone),
        $collection_id,
    ));
}

/**
 * Write the values of an item: meta rows through kk_write_meta_verified
 * (null deletes the row, verified absent), reference rows deleted and
 * re-inserted per field and read back. Callers hold the post lock and the
 * transaction.
 *
 * @param array{meta: array<string, mixed>, references: array<string, list<int>>, normalized?: array<string, mixed>, warnings?: list<string>} $values keyed by field id
 */
function kk_cm_write_values_verified(int $item_id, int $collection_id, array $values): bool|WP_Error
{
    global $wpdb;
    /** @var \wpdb $wpdb */
    $stale = kk_cm_stale_fields_error($collection_id, $values);
    if ($stale instanceof WP_Error) {
        return $stale;
    }
    $writes = [];
    $deletes = [];
    /** @var mixed $value */
    foreach ($values['meta'] as $field_id => $value) {
        $key = kk_field_meta_key($collection_id, $field_id);
        if ($value === null) {
            $deletes[] = $key;
            continue;
        }
        $writes[$key] = $value;
    }
    if ($writes !== []) {
        $ok = kk_write_meta_verified($item_id, $writes);
        if ($ok instanceof WP_Error) {
            return $ok;
        }
    }
    foreach ($deletes as $key) {
        delete_post_meta($item_id, $key);
        kk_refresh($item_id);
        if (metadata_exists('post', $item_id, $key)) {
            return kk_write_refused($item_id, $key);
        }
    }
    $table = kk_reference_table();
    foreach ($values['references'] as $field_id => $ids) {
        $key = kk_field_meta_key($collection_id, $field_id);
        // @mago-expect analysis:possibly-invalid-argument
        $wpdb->query((string) $wpdb->prepare(
            "DELETE FROM {$table} WHERE post_id = %d AND field_meta_key = %s",
            $item_id,
            $key,
        ));
        foreach ($ids as $ref_id) {
            $wpdb->insert(
                $table,
                ['post_id' => $item_id, 'field_meta_key' => $key, 'ref_post_id' => $ref_id],
                ['%d', '%s', '%d'],
            );
        }
        $stored = array_column(kk_reference_rows(['post_id' => $item_id, 'field_meta_key' => $key]), 'ref_post_id');
        if ($stored !== $ids) {
            return kk_write_refused($item_id, $key);
        }
    }
    return true;
}

// ---------------------------------------------------------------------------
// edit-collection-item
// ---------------------------------------------------------------------------

wp_register_ability('novamira/kirki-edit-collection-item', [
    'label' => __('Edit Kirki Collection Item', domain: 'novamira-pro'),
    'description' => __(
        'Edits a Content Manager item: `title`, `slug`, `status` (draft / publish / future), `date`, and `fields` — a MERGE: only the field ids given change, `null` clears a value (deletes its meta row / reference rows), the others stay byte for byte. Values are validated like kirki-create-collection-item (a required field cannot be cleared). Written in one transaction under the post lock, every row read back; identical input is a no-op (`written: []`). Never gated by open editor tabs. Also accepted: `post_title`, `post_name`, `post_status`, `post_date`.',
        domain: 'novamira-pro',
    ),
    'category' => 'kirki',
    'input_schema' => [
        'type' => 'object',
        'properties' => [
            'item_id' => ['type' => 'integer', 'description' => 'Id of the item.'],
            'title' => ['type' => 'string', 'description' => 'New name. Also accepted as `post_title`.'],
            'post_title' => ['type' => 'string', 'description' => 'Alias of `title`.'],
            'slug' => ['type' => 'string', 'description' => 'New slug. Also accepted as `post_name`.'],
            'post_name' => ['type' => 'string', 'description' => 'Alias of `slug`.'],
            'status' => [
                'type' => 'string',
                'enum' => KK_CM_ITEM_STATUSES,
                'description' => 'New status. Also accepted as `post_status`.',
            ],
            'post_status' => ['type' => 'string', 'enum' => KK_CM_ITEM_STATUSES, 'description' => 'Alias of `status`.'],
            'date' => [
                'type' => 'string',
                'description' => 'New publication date-time (site time zone). Also accepted as `post_date`.',
            ],
            'post_date' => ['type' => 'string', 'description' => 'Alias of `date`.'],
            'fields' => KK_CM_VALUES_SCHEMA,
        ],
        'required' => ['item_id'],
        'additionalProperties' => false,
    ],
    'output_schema' => [
        'type' => 'object',
        'properties' => KK_CM_ITEM_ROW_PROPERTIES
            + [
                'fields' => ['type' => 'object'],
                'defaults_applied' => ['type' => 'array', 'items' => ['type' => 'string']],
                'referenced_by' => ['type' => 'array', 'items' => ['type' => 'object']],
                'written' => [
                    'type' => 'array',
                    'items' => ['type' => 'string'],
                    'description' => 'What changed: `title`, `slug`, `status`, `date`, and the field ids.',
                ],
                'warnings' => ['type' => 'array', 'items' => ['type' => 'string']],
            ],
        'required' => [
            'id',
            'collection_id',
            'title',
            'slug',
            'status',
            'date',
            'modified',
            'url',
            'fields',
            'defaults_applied',
            'written',
            'warnings',
        ],
        'additionalProperties' => false,
    ],
    'execute_callback' => 'Novamira\\Pro\\Abilities\\Kirki\\kirki_edit_collection_item',
    'permission_callback' => 'novamira_permission_callback',
    'meta' => [
        'show_in_rest' => true,
        'mcp' => ['public' => true],
        'annotations' => [
            'instructions' => 'Send only the fields you change. To publish a draft, pass `status: publish`. Verify with kirki-get-collection-item or on the item URL.',
            'readonly' => false,
            'destructive' => false,
            'idempotent' => true,
        ],
    ],
]);

/**
 * @param array<string, mixed> $input
 * @return array<string, mixed>|WP_Error
 */
// @mago-expect lint:cyclomatic-complexity -- one refusal per branch, all flat
// @mago-expect lint:halstead
function kirki_edit_collection_item(array $input): array|WP_Error
{
    kk_begin();
    $post = kk_item_post_or_error(kk_coerce_int_or_null($input['item_id'] ?? null) ?? 0);
    if ($post instanceof WP_Error) {
        return $post;
    }
    $collection_id = (int) $post->post_parent;
    $collection = kk_collection_post_or_error($collection_id);
    if ($collection instanceof WP_Error) {
        return $collection;
    }
    kk_register_item_post_type($collection);
    /** @var mixed $title_raw */
    $title_raw = $input['title'] ?? $input['post_title'] ?? null;
    $title_error = kk_cm_label_error($title_raw, field: 'title', required: false);
    if ($title_error !== null || $title_raw !== null && trim((string) $title_raw) === '') {
        return kk_invalid_input($title_error ?? '`title` must not be blank.');
    }
    $title = is_string($title_raw) ? trim($title_raw) : $post->post_title;
    /** @var mixed $slug_raw */
    $slug_raw = $input['slug'] ?? $input['post_name'] ?? null;
    $slug = $slug_raw === null ? $post->post_name : kk_cm_slug_input($slug_raw, $title);
    if ($slug instanceof WP_Error) {
        return $slug;
    }
    if ($slug !== $post->post_name) {
        $slug_error = kk_cm_item_slug_error($slug, $collection_id, exclude: $post->ID);
        if ($slug_error !== null) {
            return $slug_error;
        }
    }
    /** @var mixed $status_raw */
    $status_raw = $input['status'] ?? $input['post_status'] ?? null;
    /** @var mixed $date_raw */
    $date_raw = $input['date'] ?? $input['post_date'] ?? null;
    $timing = kk_cm_timing_input($status_raw ?? $post->post_status, $date_raw, current: $post);
    if ($timing instanceof WP_Error) {
        return $timing;
    }
    $fields_given = array_key_exists('fields', $input);
    $defs = kk_cm_stored_defs($collection_id);
    $values = $fields_given
        ? kk_cm_values_input($defs, $input['fields'], partial: true)
        : ['meta' => [], 'references' => [], 'normalized' => [], 'warnings' => []];
    if ($values instanceof WP_Error) {
        return $values;
    }
    if ($title_raw === null && $slug_raw === null && $status_raw === null && $date_raw === null && !$fields_given) {
        return kk_invalid_input('Nothing to change: pass `title`, `slug`, `status`, `date` or `fields`.');
    }
    $changes = $timing['post'];
    $written = $timing['changed'];
    if ($title !== $post->post_title) {
        $changes['post_title'] = $title;
        $written[] = 'title';
    }
    if ($slug !== $post->post_name) {
        $changes['post_name'] = $slug;
        $written[] = 'slug';
    }
    $values = kk_cm_drop_unchanged($post, $collection_id, $values);
    $written = array_merge($written, array_keys($values['meta']), array_keys($values['references']));
    if ($written === []) {
        return (
            kk_cm_item_report($post, ['Nothing changed: every value given equals the stored one.']) + ['written' => []]
        );
    }
    $item_id = $post->ID;
    $result = kk_with_post_lock($item_id, static fn(): bool|WP_Error => kk_db_transaction($item_id, static function () use (
        $item_id,
        $collection_id,
        $changes,
        $values,
    ): bool|WP_Error {
        $ok = kk_cm_update_post_verified($item_id, $changes);
        if ($ok instanceof WP_Error) {
            return $ok;
        }
        return kk_cm_write_values_verified($item_id, $collection_id, $values);
    }));
    if ($result instanceof WP_Error) {
        return $result;
    }
    $fresh = kk_live_post($item_id);
    if (!$fresh instanceof WP_Post) {
        return kk_invalid_post($item_id);
    }
    $warnings = $values['warnings'];
    if ($fresh->post_name !== $slug) {
        $warnings[] = sprintf('The slug `%s` was taken; WordPress stored `%s`.', $slug, $fresh->post_name);
    }
    if (in_array('status', $written, strict: true) && $fresh->post_status !== 'publish') {
        $warnings[] = sprintf('The item is now `%s`: the frontend does not render it.', $fresh->post_status);
    }
    return kk_cm_item_report($fresh, $warnings) + ['written' => $written];
}

/**
 * Drop the values equal to what the item already stores, so `written` and the
 * write itself cover the changes only.
 *
 * @param array{meta: array<string, mixed>, references: array<string, list<int>>, normalized: array<string, mixed>, warnings: list<string>} $values
 * @return array{meta: array<string, mixed>, references: array<string, list<int>>, normalized: array<string, mixed>, warnings: list<string>}
 */
function kk_cm_drop_unchanged(WP_Post $post, int $collection_id, array $values): array
{
    /** @var mixed $value */
    foreach ($values['meta'] as $field_id => $value) {
        $key = kk_field_meta_key($collection_id, $field_id);
        $exists = metadata_exists('post', $post->ID, $key);
        if ($value === null && !$exists) {
            unset($values['meta'][$field_id]);
            continue;
        }
        if ($exists && kk_meta($post->ID, $key) === $value) {
            unset($values['meta'][$field_id]);
        }
    }
    foreach ($values['references'] as $field_id => $ids) {
        $key = kk_field_meta_key($collection_id, $field_id);
        $stored = array_column(kk_reference_rows(['post_id' => $post->ID, 'field_meta_key' => $key]), 'ref_post_id');
        if ($stored === $ids) {
            unset($values['references'][$field_id]);
        }
    }
    return $values;
}

// ---------------------------------------------------------------------------
// delete-collection-item
// ---------------------------------------------------------------------------

wp_register_ability('novamira/kirki-delete-collection-item', [
    'label' => __('Delete Kirki Collection Item', domain: 'novamira-pro'),
    'description' => __(
        'Deletes a Content Manager item permanently (no trash, as the editor\'s Delete does) with its meta rows; its reference rows and the rows of other items pointing at it cascade away in the reference table. Refused (`kirki_item_in_use`, 409) while other items reference it unless `force: true`; `referenced_by` lists them either way. Verified: the row must be gone.',
        domain: 'novamira-pro',
    ),
    'category' => 'kirki',
    'input_schema' => [
        'type' => 'object',
        'properties' => [
            'item_id' => ['type' => 'integer', 'description' => 'Id of the item.'],
            'force' => [
                'type' => 'boolean',
                'description' => 'Delete even when other items reference it. Default false.',
                'default' => false,
            ],
        ],
        'required' => ['item_id'],
        'additionalProperties' => false,
    ],
    'output_schema' => [
        'type' => 'object',
        'properties' => [
            'item_id' => ['type' => 'integer'],
            'collection_id' => ['type' => 'integer'],
            'deleted' => ['type' => 'boolean'],
            'referenced_by' => ['type' => 'array', 'items' => ['type' => 'object']],
            'warnings' => ['type' => 'array', 'items' => ['type' => 'string']],
        ],
        'required' => ['item_id', 'collection_id', 'deleted', 'referenced_by', 'warnings'],
        'additionalProperties' => false,
    ],
    'execute_callback' => 'Novamira\\Pro\\Abilities\\Kirki\\kirki_delete_collection_item',
    'permission_callback' => 'novamira_permission_callback',
    'meta' => [
        'show_in_rest' => true,
        'mcp' => ['public' => true],
        'annotations' => [
            'instructions' => 'Permanent. Unpublish with kirki-edit-collection-item `status: draft` when the item may come back.',
            'readonly' => false,
            'destructive' => true,
            'idempotent' => false,
        ],
    ],
]);

/**
 * @param array<string, mixed> $input
 * @return array<string, mixed>|WP_Error
 */
function kirki_delete_collection_item(array $input): array|WP_Error
{
    kk_begin();
    $post = kk_item_post_or_error(kk_coerce_int_or_null($input['item_id'] ?? null) ?? 0);
    if ($post instanceof WP_Error) {
        return $post;
    }
    $referenced_by = kk_item_referenced_by($post->ID);
    if ($referenced_by !== [] && !kk_bool($input['force'] ?? false)) {
        $names = array_map(static fn(array $r): string => sprintf(
            '%d (%s, field %s)',
            $r['item_id'],
            $r['title'],
            $r['field_id'],
        ), $referenced_by);
        return new WP_Error(
            'kirki_item_in_use',
            sprintf(
                /* translators: 1: item id, 2: referencing items */
                __(
                    'Item %1$d is referenced by item(s) %2$s. Pass `force: true` to delete it anyway (those references disappear).',
                    domain: 'novamira-pro',
                ),
                $post->ID,
                implode(', ', $names),
            ),
            ['status' => 409, 'referenced_by' => $referenced_by],
        );
    }
    $item_id = $post->ID;
    $deleted = kk_with_post_lock($item_id, static function () use ($item_id): bool|WP_Error {
        $result = wp_delete_post($item_id, force_delete: true);
        if ($result === false || $result === null || get_post($item_id) !== null) {
            return kk_cm_delete_failed('item', $item_id);
        }
        return true;
    });
    if ($deleted instanceof WP_Error) {
        return $deleted;
    }
    $warnings = [];
    foreach ($referenced_by as $ref) {
        $warnings[] = sprintf(
            'Item %d (%s) lost its reference in field `%s`.',
            $ref['item_id'],
            $ref['title'],
            $ref['field_id'],
        );
    }
    return [
        'item_id' => $item_id,
        'collection_id' => (int) $post->post_parent,
        'deleted' => true,
        'referenced_by' => $referenced_by,
        'warnings' => $warnings,
    ];
}
