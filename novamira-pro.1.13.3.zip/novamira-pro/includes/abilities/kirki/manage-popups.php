<?php

// SPDX-FileCopyrightText: 2026 Ovation S.r.l. <dev@novamira.ai>
// SPDX-License-Identifier: AGPL-3.0-or-later

declare(strict_types=1);

namespace Novamira\Pro\Abilities\Kirki;

use WP_Error;
use WP_Post;

/**
 * Abilities: Kirki popups — the `kirki_popup` posts the frontend prints at
 * `wp_footer` on every page whose conditions match (or that a button / form
 * opens).
 *
 * A popup stores a FLAT node map under `kirki` (no `blocks` wrapper): the
 * `popup` root carries `parentId: "root"` (Kirki selects it by that), its
 * `properties.name` and `properties.popup` (visibility conditions in the
 * template-condition shape, triggers, delay, position, close switches,
 * animation — printed as JSON into `var kirkiPopups`), a `backdrop` and a
 * `popup-body` child marked `attributes.kirki-popup`. The editor creates a
 * popup in `draft` with a predefined skeleton, saves it whole through
 * `PUT /popups/{id}` (no staging), publishes through the post status and
 * deletes permanently. Popups are edited inside whatever page tab is open,
 * so every writer refuses while ANY editor tab is open.
 */

if (!defined('ABSPATH')) {
    exit();
}

// Load order: this file's schemas use constants defined in other ability files of the folder; require them
// explicitly so the folder's alphabetical load order does not decide whether this file loads.
require_once __DIR__ . '/tree.php'; // KK_POPUP_POSITIONS and KK_ALLOW_OPEN_EDITOR_SCHEMA

const KK_POPUP_TITLE_BYTES = 200;

const KK_POPUP_NAME_BYTES = 200;

/** Characters a popup title / name may not carry. */
const KK_POPUP_TEXT_PATTERN = '/[<>\x00-\x08\x0B\x0C\x0E-\x1F]/';

/** The close icon of the editor's predefined popup (an SVG cross). */
const KK_POPUP_CLOSE_ICON = '<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M16.8055 6.00672C17.1335 5.67871 17.6649 5.67879 17.993 6.00672C18.3209 6.33477 18.321 6.86621 17.993 7.19422L13.1883 11.9979L17.99 16.7968C18.318 17.1246 18.3185 17.6561 17.991 17.9843C17.6631 18.3122 17.1306 18.313 16.8025 17.9852L12.0008 13.1854L7.19316 17.994C6.86514 18.3218 6.33365 18.3219 6.00566 17.994C5.67776 17.666 5.67784 17.1346 6.00566 16.8065L10.8123 11.9989L6.00566 7.19422C5.67777 6.86633 5.67798 6.33481 6.00566 6.00672C6.33362 5.67876 6.86508 5.67884 7.19316 6.00672L12.0008 10.8104L16.8055 6.00672Z" fill="currentColor" fill-opacity="0.56"/>
</svg>';

/** The CSS of the editor's predefined popup style blocks, keyed by the node they dress. */
const KK_POPUP_DEFAULT_CSS = [
    'popup' => ['md' => 'position:relative;'],
    'backdrop' => [
        'md' => 'position: fixed; width: 100%; height: 100%; left: 0; top: 0; bottom: 0; right: 0; z-index: 0; background-color:rgba(0,0,0,0.7); backdrop-filter: blur(6px);',
    ],
    'body' => [
        'md' => 'position: fixed; width: 60vw; height: fit-content; box-shadow: rgba(0, 0, 0, 0.3) 2px 2px 10px; left: 50%; top: 50%; transform: translate(-50%, -50%);',
    ],
    'container' => [
        'md' => 'border-radius:8px;position:relative;display:flex;flex-direction:column;background-color:#ffffff;overflow:hidden;',
    ],
    'close_icon' => [
        'md' => 'cursor: pointer;display: inline-block;font-size:14px;letter-spacing:-0.28px;font-weight:500;line-height:24px;outline:none;border:none;text-decoration: none;height:40px;width:40px;padding:8px;position:absolute;top:8px;right:8px;border-radius:50%;background-color:#0000000A;color:#000000;',
        'md_hover' => 'background-color:#0000001A;',
    ],
    'svg' => ['md' => 'height:24px;width:24px;min-width:24px;min-height:24px;'],
    'close_button' => [
        'md' => 'cursor: pointer;display: inline-block;padding:8px 24px;font-size:14px;letter-spacing:-0.28px;font-weight:500;line-height:24px;border-radius: 6px;outline:none;border:none;text-decoration: none;right:12px;position:absolute;bottom:12px;background-color:#0000000A;color:#000000;',
        'md_hover' => 'border-color:#0d19c4;',
    ],
    'close_text' => [
        'md' => 'font-family:Inter;font-size:16px;font-weight:400;line-height:150%;width:stretch;height:max-content;',
    ],
];

/** The flat settings fields the agent exchanges, with their stored counterpart. */
const KK_POPUP_FLAT_FIELDS = [
    'conditions',
    'triggers',
    'delay_seconds',
    'show_count',
    'position',
    'offset_x',
    'offset_y',
    'x_icon',
    'close_button',
    'outside_click_close',
    'animation',
    'duration_seconds',
    'easing',
];

const KK_POPUP_SETTINGS_SCHEMA = [
    'type' => 'object',
    'properties' => [
        'conditions' => [
            'type' => 'array',
            'items' => ['type' => 'object'],
            'description' => 'Where the popup appears, same shape and matcher as template conditions (kirki-set-template-conditions): `{"type":"*"}` entire site, `{"type":"post","post_type":"page","where":"*"}`, `{"type":"post","post_type":"page","where":"single","to":<id>}`, `visibility: hide` to exclude. Replaces the stored list; `[]` = only where a button / form opens it.',
        ],
        'triggers' => [
            'type' => 'array',
            'items' => ['type' => 'string', 'enum' => ['onload', 'onexit']],
            'description' => '`onload` (after the delay), `onexit` (mouse leaves the page), both, or `[]` (opened only by buttons / forms).',
        ],
        'delay_seconds' => [
            'type' => 'number',
            'minimum' => 0,
            'description' => 'Seconds before an `onload` popup shows (default 5).',
        ],
        'show_count' => [
            'type' => 'integer',
            'minimum' => -1,
            'description' => 'Times a visitor sees it (browser localStorage), -1 = every time (default 1).',
        ],
        'position' => [
            'type' => 'string',
            'enum' => KK_POPUP_POSITIONS,
            'description' => 'Where the body sits (default `center-center`).',
        ],
        'offset_x' => ['type' => 'integer', 'minimum' => 0, 'description' => 'Horizontal offset in px.'],
        'offset_y' => ['type' => 'integer', 'minimum' => 0, 'description' => 'Vertical offset in px.'],
        'x_icon' => ['type' => 'boolean', 'description' => 'Show the corner close icon (default false).'],
        'close_button' => ['type' => 'boolean', 'description' => 'Show the Close button (default true).'],
        'outside_click_close' => [
            'type' => 'boolean',
            'description' => 'A click on the backdrop closes it (default true).',
        ],
        'animation' => [
            'type' => 'string',
            'enum' => ['fadeIn', 'none'],
            'description' => 'Opening animation (default `fadeIn`).',
        ],
        'duration_seconds' => [
            'type' => 'number',
            'minimum' => 0,
            'description' => 'Animation duration (default 0.3).',
        ],
        'easing' => [
            'type' => 'string',
            'description' => 'CSS timing function of the animation (default `ease`; a keyword or `cubic-bezier(...)`).',
        ],
    ],
    'additionalProperties' => false,
];

const KK_POPUP_SETTINGS_OUTPUT = [
    'type' => 'object',
    'description' => 'The settings as stored, flat: conditions (normalised rows with `effective` / `note`), triggers, delay_seconds, show_count, position, offset_x, offset_y, x_icon, close_button, outside_click_close, animation, duration_seconds, easing.',
];

// ---------------------------------------------------------------------------
// create-popup
// ---------------------------------------------------------------------------

wp_register_ability('novamira/kirki-create-popup', [
    'label' => __('Create Kirki Popup', domain: 'novamira-pro'),
    'description' => __(
        'Creates a Kirki popup the way the editor\'s Pages → + → Popup does: a `kirki_popup` post (status `draft` by default; `publish` prints it at once wherever its conditions match) holding the editor\'s predefined skeleton — the `popup` root (`parentId: "root"`, the popup name and settings), a backdrop, the popup body with an empty container, the corner close icon and a Close button — with the editor\'s default style blocks, an empty font list, the editor-mode marker and the staging ledger seeded (Kirki never stages popups afterwards). `settings` sets conditions / triggers / delay / position / close switches / animation (every key left out keeps the editor default). Fill the body with kirki-set-popup-content; open it from a page button (`type: "popup"`, `attributes.popup: <id>`, published popups only). Written in one transaction under the post lock, read back and verified; a refused write leaves no post. Refused while ANY Kirki editor tab is open (`kirki_editor_open`): popups are edited inside whatever page tab is open.',
        domain: 'novamira-pro',
    ),
    'category' => 'kirki',
    'input_schema' => [
        'type' => 'object',
        'properties' => [
            'title' => [
                'type' => 'string',
                'description' => 'WordPress post title (also the editor list label); 1–200 bytes, no markup. Also accepted as `post_title`.',
            ],
            'post_title' => ['type' => 'string', 'description' => 'Alias of `title`.'],
            'name' => [
                'type' => 'string',
                'description' => 'Popup name shown in the editor\'s settings panel (default: the title).',
            ],
            'status' => [
                'type' => 'string',
                'enum' => ['draft', 'publish'],
                'description' => '`draft` (default, prints nowhere) or `publish`. Also accepted as `post_status`.',
            ],
            'post_status' => [
                'type' => 'string',
                'enum' => ['draft', 'publish'],
                'description' => 'Alias of `status`.',
            ],
            'settings' => KK_POPUP_SETTINGS_SCHEMA,
            'allow_open_editor' => KK_ALLOW_OPEN_EDITOR_SCHEMA,
        ],
        'required' => [],
        'additionalProperties' => false,
    ],
    'output_schema' => [
        'type' => 'object',
        'properties' => [
            'id' => ['type' => 'integer'],
            'post_type' => ['type' => 'string'],
            'status' => ['type' => 'string'],
            'title' => ['type' => 'string'],
            'slug' => ['type' => 'string'],
            'editor_url' => [
                'type' => 'string',
                'description' => 'The editor opens popups from a page: this is the editor of the site\'s front page with the popup selected in its Pages list.',
            ],
            'root_id' => ['type' => 'string'],
            'blocks_count' => ['type' => 'integer'],
            'style_blocks_count' => ['type' => 'integer'],
            'settings' => KK_POPUP_SETTINGS_OUTPUT,
            'warnings' => ['type' => 'array', 'items' => ['type' => 'string']],
        ],
        'required' => [
            'id',
            'post_type',
            'status',
            'title',
            'slug',
            'editor_url',
            'root_id',
            'blocks_count',
            'style_blocks_count',
            'settings',
            'warnings',
        ],
        'additionalProperties' => false,
    ],
    'execute_callback' => 'Novamira\\Pro\\Abilities\\Kirki\\kirki_create_popup',
    'permission_callback' => 'novamira_permission_callback',
    'meta' => [
        'show_in_rest' => true,
        'mcp' => ['public' => true],
        'annotations' => [
            'instructions' => 'Create in `draft`, fill the body (kirki-get-content then kirki-set-popup-content: put your nodes inside the container of the popup body), then publish with `status` here or novamira/update-post. Give it conditions + a trigger, or leave both empty and open it from a page button. Verify on a public page: `popup-id="<id>"` and `var kirkiPopups` in the HTML.',
            'readonly' => false,
            'destructive' => false,
            'idempotent' => false,
        ],
    ],
]);

/**
 * @param array<string, mixed> $input
 * @return array<string, mixed>|WP_Error
 */
// @mago-expect lint:cyclomatic-complexity -- one refusal per branch, all flat
function kirki_create_popup(array $input): array|WP_Error
{
    kk_begin();
    /** @var mixed $title */
    $title = $input['title'] ?? $input['post_title'] ?? null;
    $title_error = kk_popup_text_error($title, field: 'title', cap: KK_POPUP_TITLE_BYTES, required: true);
    if ($title_error !== null) {
        return kk_invalid_input($title_error);
    }
    /** @var string $title */
    $name = is_string($input['name'] ?? null) ? $input['name'] : $title;
    $name_error = kk_popup_text_error($name, field: 'name', cap: KK_POPUP_NAME_BYTES, required: true);
    if ($name_error !== null) {
        return kk_invalid_input($name_error);
    }
    /** @var mixed $status */
    $status = $input['status'] ?? $input['post_status'] ?? 'draft';
    if (!in_array($status, ['draft', 'publish'], strict: true)) {
        return kk_invalid_input('`status` must be `draft` or `publish`.');
    }
    /** @var array<string, mixed> $patch */
    $patch = is_array($input['settings'] ?? null) ? $input['settings'] : [];
    /** @var array<string, mixed> $defaults */
    $defaults = KK_POPUP_DEFAULT_SETTINGS;
    $settings = kk_popup_settings_from_flat($defaults, $patch);
    if ($settings instanceof WP_Error) {
        return $settings;
    }
    $open = kk_refuse_open_editor_global($input['allow_open_editor'] ?? false);
    if ($open instanceof WP_Error) {
        return $open;
    }
    // Kirki's page service sets the slug from the title even for drafts (a draft popup keeps a slug).
    $popup_id = wp_insert_post([
        'post_type' => kk_popup_post_type(),
        'post_status' => $status,
        'post_title' => $title,
        'post_name' => sanitize_title($title),
    ], wp_error: true);
    if ($popup_id instanceof WP_Error) {
        return new WP_Error(
            'kirki_create_failed',
            __('WordPress refused to insert the popup post.', domain: 'novamira-pro'),
            ['status' => 500],
        );
    }
    $skeleton = kk_popup_default_blocks($name, $settings);
    $written = kk_with_post_lock($popup_id, static function () use ($popup_id, $skeleton): bool|WP_Error {
        $ok = kk_write_meta_verified($popup_id, [
            kk_meta_blocks() => $skeleton['blocks'],
            kk_meta_style_blocks() => $skeleton['styles'],
            kk_meta_used_fonts() => [],
            kk_meta_editor_mode() => KK_EDITOR_MODE,
        ]);
        if ($ok instanceof WP_Error) {
            return $ok;
        }
        kk_ensure_ledger($popup_id);
        return true;
    });
    if ($written instanceof WP_Error) {
        wp_delete_post($popup_id, force_delete: true);
        return $written;
    }
    $post = kk_live_post($popup_id);
    if (!$post instanceof WP_Post) {
        // A hook trashed or deleted the row after the insert: reporting the
        // REQUESTED status and title here would describe a popup that does not
        // exist. The other creators refuse; so does this.
        return kk_invalid_post($popup_id);
    }
    $report = kk_popup_report($popup_id);
    return [
        'id' => $popup_id,
        'post_type' => kk_popup_post_type(),
        'status' => $post->post_status,
        'title' => $post->post_title,
        'slug' => $post->post_name,
        'editor_url' => add_query_arg(['action' => KK_EDITOR_MODE], home_url('/')),
        'root_id' => $report['root_id'],
        'blocks_count' => $report['blocks_count'],
        'style_blocks_count' => $report['style_blocks_count'],
        'settings' => $report['settings'],
        'warnings' => array_merge($report['warnings'], kk_popup_status_warnings($post, $settings)),
    ];
}

/**
 * The editor's predefined popup skeleton with fresh ids: 8 nodes (popup →
 * backdrop + popup-body → container, close icon (button + svg), close
 * button (button + text)) and their 8 style blocks.
 *
 * @param array<string, mixed> $settings the stored `properties.popup`
 * @return array{blocks: array<string, mixed>, styles: array<string, array<string, mixed>>, root: string}
 */
function kk_popup_default_blocks(string $name, array $settings): array
{
    $taken = [];
    $ids = [];
    foreach (array_keys(KK_POPUP_DEFAULT_CSS) as $slot) {
        $id = kk_new_id($taken);
        $taken[$id] = true;
        $ids[$slot] = $id;
    }
    $styles = [];
    $style_ids = [];
    foreach (KK_POPUP_DEFAULT_CSS as $slot => $variant) {
        $style_id = kk_new_id($taken);
        $taken[$style_id] = true;
        $style_ids[$slot] = $style_id;
        $class_name = kk_popup_style_name($taken);
        $taken[$class_name] = true;
        $styles[$style_id] = ['id' => $style_id, 'type' => 'class', 'name' => $class_name, 'variant' => $variant];
    }
    $blocks = [];
    foreach (kk_popup_skeleton_spec($name, $settings) as $slot => $spec) {
        /** @var array{element: string, title: string, parent: ?string, props: array<string, mixed>, children?: list<string>, extra?: array<string, mixed>} $spec */
        $node = [
            'visibility' => true,
            'collapse' => false,
            'name' => $spec['element'],
            'title' => $spec['title'],
            'className' => '',
            'source' => 'kirki',
            'id' => $ids[$slot],
            'parentId' => $spec['parent'] === null ? 'root' : $ids[$spec['parent']],
            'styleIds' => [$style_ids[$slot]],
            'properties' => $spec['props'],
        ];
        if (isset($spec['children'])) {
            $node['children'] = array_map(static fn(string $child): string => $ids[$child], $spec['children']);
        }
        $blocks[$ids[$slot]] = ($spec['extra'] ?? []) + $node;
    }
    return ['blocks' => $blocks, 'styles' => $styles, 'root' => $ids['popup']];
}

/**
 * The editor's predefined popup skeleton, slot by slot (parents and children
 * name slots; ids are drawn by kk_popup_default_blocks).
 *
 * @param array<string, mixed> $settings
 * @return array<string, array<string, mixed>>
 */
function kk_popup_skeleton_spec(string $name, array $settings): array
{
    $locked = ['manualDelete' => false, 'allowClipboarActions' => false];
    $close_button_props = static fn(string $marker): array => [
        'tag' => 'button',
        'contents' => ['Button'],
        'type' => 'href',
        'attributes' => ['href' => '', 'target' => '', 'kirki-popup' => $marker],
    ];
    return [
        'popup' => [
            'element' => 'popup',
            'title' => 'Pop-up',
            'parent' => null,
            'props' => ['name' => $name, 'popup' => $settings, 'tag' => 'div'],
            'children' => ['backdrop', 'body'],
            'extra' => ['className' => 'kirki-popup-element', 'template_mounted' => true],
        ],
        'backdrop' => [
            'element' => 'backdrop',
            'title' => 'Backdrop',
            'parent' => 'popup',
            'props' => ['tag' => 'div', 'attributes' => ['kirki-popup' => 'backdrop']],
            'extra' => $locked,
        ],
        'body' => [
            'element' => 'popup-body',
            'title' => 'Pop-up body',
            'parent' => 'popup',
            'props' => ['tag' => 'div', 'attributes' => ['kirki-popup' => 'body']],
            'children' => ['container', 'close_icon', 'close_button'],
            'extra' => $locked + ['template_mounted' => true],
        ],
        'container' => [
            'element' => 'div',
            'title' => 'Popup container',
            'parent' => 'body',
            'props' => ['tag' => 'div'],
            'children' => [],
        ],
        'close_icon' => [
            'element' => 'button',
            'title' => 'Close icon',
            'parent' => 'body',
            'props' => $close_button_props('close-icon'),
            'children' => ['svg'],
            'extra' => $locked + ['template_mounted' => true],
        ],
        'svg' => [
            'element' => 'svg',
            'title' => 'SVG',
            'parent' => 'close_icon',
            'props' => ['tag' => 'svg', 'svgOuterHtml' => KK_POPUP_CLOSE_ICON],
        ],
        'close_button' => [
            'element' => 'button',
            'title' => 'Close button',
            'parent' => 'body',
            'props' => $close_button_props('close-btn'),
            'children' => ['close_text'],
            'extra' => $locked + ['template_mounted' => true],
        ],
        'close_text' => [
            'element' => 'text',
            'title' => 'Text',
            'parent' => 'close_button',
            'props' => ['contents' => ['Close'], 'tag' => 'span'],
        ],
    ];
}

/**
 * A fresh page-local class name in the editor's format (`k ` + 8 lower-case
 * alphanumerics), absent from `$taken`.
 *
 * @param array<string, mixed> $taken
 */
function kk_popup_style_name(array $taken): string
{
    $alphabet = 'abcdefghijklmnopqrstuvwxyz0123456789';
    do {
        $name = 'k ';
        for ($i = 0; $i < 8; ++$i) {
            $name .= $alphabet[random_int(min: 0, max: 35)];
        }
    } while (isset($taken[$name]));
    return $name;
}

// ---------------------------------------------------------------------------
// set-popup-content
// ---------------------------------------------------------------------------

wp_register_ability('novamira/kirki-set-popup-content', [
    'label' => __('Set Kirki Popup Content', domain: 'novamira-pro'),
    'description' => __(
        'Replaces the whole node map and style blocks of a Kirki popup, the way the editor\'s popup Save does (`PUT /popups/{id}`: the base `kirki`, style-block and font-list keys, no staging). The map is FLAT (no `root` → `body`): exactly one `popup` node with `parentId: "root"`, `properties.name` and a complete `properties.popup` settings map, a child marked `attributes.kirki-popup: "backdrop"` and one marked `"body"` (the frontend runtime needs both), your content under the body; page node rules apply (element vocabulary, attributes, css, raw sinks refused, buttons opening popups must name published ones). Read the current map with kirki-get-content and send it back with your changes. Written in one transaction under the post lock, read back and verified; identical content is a no-op. Refused while ANY Kirki editor tab is open (`kirki_editor_open`).',
        domain: 'novamira-pro',
    ),
    'category' => 'kirki',
    'input_schema' => [
        'type' => 'object',
        'properties' => [
            'post_id' => ['type' => 'integer', 'description' => 'The `kirki_popup` post.'],
            'blocks' => ['type' => 'object', 'description' => 'Flat node map `{id: node}` (see the description).'],
            'styles' => [
                'type' => 'object',
                'description' => 'Style blocks keyed by id, same shape as kirki-set-content.',
            ],
            'fonts' => [
                'type' => 'array',
                'items' => ['type' => 'string'],
                'description' => 'Font family names the popup uses (`kirki_used_font_list`). Omit to leave unchanged.',
            ],
            'allow_open_editor' => KK_ALLOW_OPEN_EDITOR_SCHEMA,
        ],
        'required' => ['post_id', 'blocks'],
        'additionalProperties' => false,
    ],
    'output_schema' => [
        'type' => 'object',
        'properties' => [
            'post_id' => ['type' => 'integer'],
            'root_id' => ['type' => 'string'],
            'blocks_count' => ['type' => 'integer'],
            'style_blocks_count' => ['type' => 'integer'],
            'settings' => KK_POPUP_SETTINGS_OUTPUT,
            'written' => [
                'type' => 'array',
                'items' => ['type' => 'string'],
                'description' => 'Meta keys that changed; empty for a no-op.',
            ],
            'warnings' => ['type' => 'array', 'items' => ['type' => 'string']],
        ],
        'required' => ['post_id', 'root_id', 'blocks_count', 'style_blocks_count', 'settings', 'written', 'warnings'],
        'additionalProperties' => false,
    ],
    'execute_callback' => 'Novamira\\Pro\\Abilities\\Kirki\\kirki_set_popup_content',
    'permission_callback' => 'novamira_permission_callback',
    'meta' => [
        'show_in_rest' => true,
        'mcp' => ['public' => true],
        'annotations' => [
            'instructions' => 'Read the popup with kirki-get-content (include_style_blocks) first and keep the skeleton (root, backdrop, body, close controls); put your nodes inside the body\'s container. Settings travel inside the root\'s `properties.popup`; kirki-edit-popup-settings is the simpler way to change them.',
            'readonly' => false,
            'destructive' => true,
            'idempotent' => true,
        ],
    ],
]);

/**
 * @param array<string, mixed> $input
 * @return array<string, mixed>|WP_Error
 */
// @mago-expect lint:cyclomatic-complexity -- one refusal per branch, all flat
// @mago-expect lint:halstead
function kirki_set_popup_content(array $input): array|WP_Error
{
    kk_begin();
    $post_id = kk_coerce_int_or_null($input['post_id'] ?? null) ?? 0;
    $post = kk_popup_post_or_error($post_id);
    if ($post instanceof WP_Error) {
        return $post;
    }
    /** @var mixed $raw_blocks */
    $raw_blocks = $input['blocks'] ?? null;
    if (!is_array($raw_blocks) || $raw_blocks === []) {
        return kk_invalid_input(__('blocks must be a non-empty object map of nodes.', domain: 'novamira-pro'));
    }
    /** @var mixed $raw_styles */
    $raw_styles = $input['styles'] ?? [];
    if (!is_array($raw_styles)) {
        return kk_invalid_input(__('styles must be an object map of style blocks.', domain: 'novamira-pro'));
    }
    $encoded = wp_json_encode([$raw_blocks, $raw_styles]);
    if (!is_string($encoded) || strlen($encoded) > KK_MAX_TREE_BYTES) {
        return new WP_Error(
            'kirki_too_large',
            sprintf(
                /* translators: %d: byte cap */
                __('The popup content exceeds %d bytes (or cannot be encoded as JSON).', domain: 'novamira-pro'),
                KK_MAX_TREE_BYTES,
            ),
            ['status' => 413],
        );
    }
    $styles = kk_coerce_styles($raw_styles);
    if ($styles instanceof WP_Error) {
        return $styles;
    }
    $fonts = kk_coerce_fonts($input['fonts'] ?? null);
    if ($fonts instanceof WP_Error) {
        return $fonts;
    }
    $blocks = kk_coerce_blocks($raw_blocks);
    if ($blocks instanceof WP_Error) {
        return $blocks;
    }
    $stored = kk_blocks_of(kk_meta($post_id, kk_meta_blocks())) ?? [];
    $verdict = kk_validate_popup_tree($blocks, $styles, kk_node_map($stored));
    if ($verdict['errors'] !== []) {
        return kk_tree_error($verdict['errors']);
    }
    $open = kk_refuse_open_editor_global($input['allow_open_editor'] ?? false);
    if ($open instanceof WP_Error) {
        return $open;
    }
    $writes = [kk_meta_blocks() => $blocks, kk_meta_style_blocks() => $styles];
    if ($fonts !== null) {
        $writes[kk_meta_used_fonts()] = $fonts;
    }
    $written = kk_with_post_lock($post_id, static function () use ($post_id, $writes): array|WP_Error {
        if (kk_live_post($post_id) === null) {
            return kk_invalid_post($post_id);
        }
        $changed = kk_popup_changed_keys($post_id, $writes);
        if ($changed === []) {
            return [];
        }
        $ok = kk_write_meta_verified($post_id, $writes);
        return $ok instanceof WP_Error ? $ok : $changed;
    });
    if ($written instanceof WP_Error) {
        return $written;
    }
    $report = kk_popup_report($post_id);
    return [
        'post_id' => $post_id,
        'root_id' => $report['root_id'],
        'blocks_count' => $report['blocks_count'],
        'style_blocks_count' => $report['style_blocks_count'],
        'settings' => $report['settings'],
        'written' => $written,
        'warnings' => array_merge(
            $verdict['warnings'],
            $report['warnings'],
            kk_popup_status_warnings(kk_live_post($post_id), settings: null),
        ),
    ];
}

/**
 * The keys of a write whose stored value differs (read fresh).
 *
 * @param array<string, mixed> $writes
 * @return list<string>
 */
function kk_popup_changed_keys(int $post_id, array $writes): array
{
    $changed = [];
    /** @var mixed $value */
    foreach ($writes as $key => $value) {
        if (kk_meta($post_id, $key) === $value) {
            continue;
        }
        $changed[] = $key;
    }
    return $changed;
}

// ---------------------------------------------------------------------------
// edit-popup-settings
// ---------------------------------------------------------------------------

wp_register_ability('novamira/kirki-edit-popup-settings', [
    'label' => __('Edit Kirki Popup Settings', domain: 'novamira-pro'),
    'description' => __(
        'Changes the settings of a Kirki popup (the `popup` root\'s `properties.popup` and its `properties.name`), the ones the editor\'s Popup panel shows: `conditions` (where it appears, template-condition shape, replaces the list), `triggers` (`onload` / `onexit`), `delay_seconds`, `show_count`, `position`, offsets, the three close switches, `animation`, `duration_seconds`, `easing`, plus `name`. Fields left out keep their stored value; the full editor shape is always written (the frontend runtime reads every key). The node map is rewritten whole, as the editor\'s Save does, in one transaction under the post lock, read back and verified. The response returns the settings as stored with the conditions normalised as kirki-list-templates does (`effective` / `note`). A draft popup prints nowhere whatever its settings (warning). Refused while ANY Kirki editor tab is open (`kirki_editor_open`).',
        domain: 'novamira-pro',
    ),
    'category' => 'kirki',
    'input_schema' => [
        'type' => 'object',
        'properties' => [
            'post_id' => ['type' => 'integer', 'description' => 'The `kirki_popup` post.'],
            'name' => ['type' => 'string', 'description' => 'Popup name shown in the editor (1–200 bytes, no markup).'],
        ]
            + KK_POPUP_SETTINGS_SCHEMA['properties']
            + [
                'allow_open_editor' => KK_ALLOW_OPEN_EDITOR_SCHEMA,
            ],
        'required' => ['post_id'],
        'additionalProperties' => false,
    ],
    'output_schema' => [
        'type' => 'object',
        'properties' => [
            'post_id' => ['type' => 'integer'],
            'status' => ['type' => 'string'],
            'name' => ['type' => 'string'],
            'settings' => KK_POPUP_SETTINGS_OUTPUT,
            'written' => [
                'type' => 'array',
                'items' => ['type' => 'string'],
                'description' => 'Flat fields whose stored value changed (`name` included); empty for a no-op.',
            ],
            'warnings' => ['type' => 'array', 'items' => ['type' => 'string']],
        ],
        'required' => ['post_id', 'status', 'name', 'settings', 'written', 'warnings'],
        'additionalProperties' => false,
    ],
    'execute_callback' => 'Novamira\\Pro\\Abilities\\Kirki\\kirki_edit_popup_settings',
    'permission_callback' => 'novamira_permission_callback',
    'meta' => [
        'show_in_rest' => true,
        'mcp' => ['public' => true],
        'annotations' => [
            'instructions' => 'Pass only the fields to change. `conditions` replaces the whole list (an entire-site `show` plus `hide` entries for exceptions, like templates). Publish with novamira/update-post; verify on a matching public page that `var kirkiPopups` carries the settings.',
            'readonly' => false,
            'destructive' => false,
            'idempotent' => true,
        ],
    ],
]);

/**
 * @param array<string, mixed> $input
 * @return array<string, mixed>|WP_Error
 */
// @mago-expect lint:cyclomatic-complexity -- one refusal per branch, all flat
// @mago-expect lint:halstead
function kirki_edit_popup_settings(array $input): array|WP_Error
{
    kk_begin();
    $post_id = kk_coerce_int_or_null($input['post_id'] ?? null) ?? 0;
    $post = kk_popup_post_or_error($post_id);
    if ($post instanceof WP_Error) {
        return $post;
    }
    $patch = array_intersect_key($input, array_flip(KK_POPUP_FLAT_FIELDS));
    $name_error = kk_popup_text_error($input['name'] ?? null, field: 'name', cap: KK_POPUP_NAME_BYTES, required: false);
    if ($name_error !== null) {
        return kk_invalid_input($name_error);
    }
    if ($patch === [] && !array_key_exists('name', $input)) {
        return kk_invalid_input(sprintf('Nothing to change: pass `name` or at least one of %s.', implode(
            ', ',
            KK_POPUP_FLAT_FIELDS,
        )));
    }
    $blocks = kk_blocks_of(kk_meta($post_id, kk_meta_blocks()));
    $root_id = kk_popup_root_of($blocks ?? []);
    if ($blocks === null || $root_id === null) {
        return new WP_Error(
            'kirki_corrupt_tree',
            sprintf(
                /* translators: %d: popup id */
                __(
                    'Popup %d stores no `popup` root with `parentId: "root"`: give it content with kirki-set-popup-content first.',
                    domain: 'novamira-pro',
                ),
                $post_id,
            ),
            ['status' => 422],
        );
    }
    /** @var array<string, mixed> $root_raw */
    $root_raw = is_array($blocks[$root_id] ?? null) ? $blocks[$root_id] : [];
    $root = kk_node_map($root_raw);
    /** @var array<string, mixed> $props */
    $props = is_array($root['properties'] ?? null) ? $root['properties'] : [];
    /** @var array<string, mixed> $stored */
    $stored = is_array($props['popup'] ?? null)
        ? $props['popup'] + KK_POPUP_DEFAULT_SETTINGS
        : KK_POPUP_DEFAULT_SETTINGS;
    $settings = kk_popup_settings_from_flat($stored, $patch);
    if ($settings instanceof WP_Error) {
        return $settings;
    }
    $open = kk_refuse_open_editor_global($input['allow_open_editor'] ?? false);
    if ($open instanceof WP_Error) {
        return $open;
    }
    $before_flat = kk_popup_settings_flat($stored) + ['name' => $props['name'] ?? ''];
    $props['popup'] = $settings;
    if (is_string($input['name'] ?? null)) {
        $props['name'] = $input['name'];
    }
    $root['properties'] = $props;
    $blocks[$root_id] = $root;
    $after_flat = kk_popup_settings_flat($settings) + ['name' => $props['name'] ?? ''];
    $changed = [];
    foreach (array_keys($after_flat) as $field) {
        if (($before_flat[$field] ?? null) === $after_flat[$field]) {
            continue;
        }
        $changed[] = $field;
    }
    $written = kk_with_post_lock($post_id, static function () use ($post_id, $blocks, $changed): bool|WP_Error {
        if (kk_live_post($post_id) === null) {
            return kk_invalid_post($post_id);
        }
        if ($changed === [] && kk_meta($post_id, kk_meta_blocks()) === $blocks) {
            return true;
        }
        return kk_write_meta_verified($post_id, [kk_meta_blocks() => $blocks]);
    });
    if ($written instanceof WP_Error) {
        return $written;
    }
    $report = kk_popup_report($post_id);
    $live = kk_live_post($post_id);
    return [
        'post_id' => $post_id,
        'status' => $live === null ? '' : $live->post_status,
        'name' => $report['name'],
        'settings' => $report['settings'],
        'written' => $changed,
        'warnings' => array_merge($report['warnings'], kk_popup_status_warnings($live, $settings)),
    ];
}

// ---------------------------------------------------------------------------
// delete-popup
// ---------------------------------------------------------------------------

wp_register_ability('novamira/kirki-delete-popup', [
    'label' => __('Delete Kirki Popup', domain: 'novamira-pro'),
    'description' => __(
        'Deletes a Kirki popup PERMANENTLY, as the editor\'s Pages list Delete does (no trash). Refused (`kirki_popup_in_use`) while any post\'s tree or staged copy opens it — a page, template, symbol or another popup holding a button / link with `attributes.popup` naming it, or a form whose `properties.form.onSubmit` targets it — unless `force: true`: such openers become silent no-ops on the frontend (the runtime finds no `popup-id`), and the response lists them (`referenced_by`) so you can retarget them with kirki-edit-element. The deletion is verified (the post row must be gone). Refused while ANY Kirki editor tab is open (`kirki_editor_open`).',
        domain: 'novamira-pro',
    ),
    'category' => 'kirki',
    'input_schema' => [
        'type' => 'object',
        'properties' => [
            'post_id' => ['type' => 'integer', 'description' => 'The `kirki_popup` post.'],
            'force' => [
                'type' => 'boolean',
                'description' => 'Delete even when pages open it (their openers go silent). Default false.',
            ],
            'allow_open_editor' => KK_ALLOW_OPEN_EDITOR_SCHEMA,
        ],
        'required' => ['post_id'],
        'additionalProperties' => false,
    ],
    'output_schema' => [
        'type' => 'object',
        'properties' => [
            'post_id' => ['type' => 'integer'],
            'deleted' => ['type' => 'boolean'],
            'was_published' => ['type' => 'boolean'],
            'referenced_by' => [
                'type' => 'array',
                'items' => ['type' => 'object'],
                'description' => 'Posts still opening the deleted popup: `{post_id, post_type, status, title, published_tree, node_ids}` (`node_ids` empty = a row too large to decode).',
            ],
            'warnings' => ['type' => 'array', 'items' => ['type' => 'string']],
        ],
        'required' => ['post_id', 'deleted', 'was_published', 'referenced_by', 'warnings'],
        'additionalProperties' => false,
    ],
    'execute_callback' => 'Novamira\\Pro\\Abilities\\Kirki\\kirki_delete_popup',
    'permission_callback' => 'novamira_permission_callback',
    'meta' => [
        'show_in_rest' => true,
        'mcp' => ['public' => true],
        'annotations' => [
            'instructions' => 'Without `force` the call succeeds only for a popup nothing opens; with `force`, retarget or remove the openers it reports.',
            'readonly' => false,
            'destructive' => true,
            'idempotent' => false,
        ],
    ],
]);

/**
 * The refusal of `delete-popup` when something still opens the popup.
 *
 * @param list<array<string, mixed>> $usage rows of kk_popup_usage
 */
function kk_popup_in_use_error(int $post_id, array $usage): WP_Error
{
    return new WP_Error(
        'kirki_popup_in_use',
        sprintf(
            /* translators: 1: popup id, 2: post list */
            __(
                'Popup %1$d is opened by post(s) %2$s. Pass `force: true` to delete it anyway (those openers become silent no-ops on the frontend).',
                domain: 'novamira-pro',
            ),
            $post_id,
            implode(', ', array_map(static function (array $row): string {
                $nodes = is_array($row['node_ids'] ?? null) ? $row['node_ids'] : [];
                return sprintf(
                    '%d (%s)',
                    kk_coerce_int_or_null($row['post_id'] ?? null) ?? 0,
                    $nodes === [] ? 'nodes not decoded' : implode(', ', array_map('strval', $nodes)),
                );
            }, $usage)),
        ),
        ['status' => 409],
    );
}

/**
 * @param array<string, mixed> $input
 * @return array<string, mixed>|WP_Error
 */
// @mago-expect lint:cyclomatic-complexity -- gate, locked re-scan, delete, report
function kirki_delete_popup(array $input): array|WP_Error
{
    kk_begin();
    $post_id = kk_coerce_int_or_null($input['post_id'] ?? null) ?? 0;
    $post = kk_popup_post_or_error($post_id);
    if ($post instanceof WP_Error) {
        return $post;
    }
    // A first scan outside the lock, so an obvious refusal costs nothing; the
    // scan that DECIDES runs inside the lock, just before the delete.
    $usage = kk_popup_usage($post_id);
    if (!kk_bool($input['force'] ?? false) && $usage !== []) {
        return kk_popup_in_use_error($post_id, $usage);
    }
    $open = kk_refuse_open_editor_global($input['allow_open_editor'] ?? false);
    if ($open instanceof WP_Error) {
        return $open;
    }
    $was_published = $post->post_status === 'publish';
    $force = kk_bool($input['force'] ?? false);
    $deleted = kk_with_post_lock($post_id, static function () use ($post_id, $force, &$usage): bool|WP_Error {
        if (kk_live_post($post_id) === null) {
            return kk_invalid_post($post_id);
        }
        // Re-scan inside the lock: the first scan ran before it, and a page
        // saved in between would be invisible to the gate and silently keep a
        // dead opener. This is also the list the caller
        // gets, so `referenced_by` describes the tree as it was at delete time.
        $usage = kk_popup_usage($post_id);
        if ($usage !== [] && !$force) {
            return kk_popup_in_use_error($post_id, $usage);
        }
        $result = wp_delete_post($post_id, force_delete: true);
        clean_post_cache($post_id);
        if ($result === false || $result === null || get_post($post_id) !== null) {
            return new WP_Error(
                'kirki_write_failed',
                sprintf(
                    /* translators: %d: popup id */
                    __(
                        'WordPress did not delete popup %d (a hook refused it or the row is still there).',
                        domain: 'novamira-pro',
                    ),
                    $post_id,
                ),
                ['status' => 500],
            );
        }
        return true;
    });
    if ($deleted instanceof WP_Error) {
        return $deleted;
    }
    return [
        'post_id' => $post_id,
        'deleted' => true,
        'was_published' => $was_published,
        'referenced_by' => $usage,
        'warnings' => $usage === []
            ? []
            : [
                'The listed posts still hold buttons / forms opening the deleted popup: they do nothing on the frontend until retargeted (kirki-edit-element) or removed.',
            ],
    ];
}

// ---------------------------------------------------------------------------
// Shared helpers of the popup abilities.
// ---------------------------------------------------------------------------

/** Error for a popup title / name input, or null. */
// @mago-expect lint:no-boolean-flag-parameter -- required / optional text
function kk_popup_text_error(mixed $value, string $field, int $cap, bool $required): ?string
{
    if ($value === null) {
        return $required ? sprintf('`%s` is required.', $field) : null;
    }
    if (!is_string($value) || trim($value) === '') {
        return sprintf('`%s` must be a non-empty string.', $field);
    }
    if (strlen($value) > $cap) {
        return sprintf('`%s` exceeds %d bytes.', $field, $cap);
    }
    if (
        preg_match(KK_POPUP_TEXT_PATTERN, $value) === 1
        || preg_match(KK_POPUP_TEXT_PATTERN, kk_decode_entities($value)) === 1
    ) {
        return sprintf('`%s` must not contain angle brackets or control characters.', $field);
    }
    return null;
}

/** The id of the `popup` root (`parentId: "root"`) of a flat map, or null. */
function kk_popup_root_of(array $blocks): ?string
{
    /** @var mixed $node */
    foreach ($blocks as $id => $node) {
        if (is_array($node) && ($node['parentId'] ?? null) === 'root') {
            return strval($id);
        }
    }
    return null;
}

/**
 * The stored settings map with a flat patch applied and validated
 * (`kk_validate_popup_settings` on the result), or the refusal.
 *
 * @param array<string, mixed> $stored
 * @param array<string, mixed> $patch
 * @return array<string, mixed>|WP_Error
 */
// @mago-expect lint:cyclomatic-complexity -- one flat field per branch, all flat
// @mago-expect lint:halstead
function kk_popup_settings_from_flat(array $stored, array $patch): array|WP_Error
{
    $settings = $stored + KK_POPUP_DEFAULT_SETTINGS;
    if (array_key_exists('conditions', $patch)) {
        /** @var mixed $conditions */
        $conditions = $patch['conditions'];
        if (!is_array($conditions) || !kk_is_list($conditions)) {
            return kk_invalid_input('`conditions` must be a list of condition objects (or `[]`).');
        }
        $checked = [];
        /** @var mixed $condition */
        foreach ($conditions as $condition) {
            $normalised = kk_validate_condition($condition);
            if ($normalised instanceof WP_Error) {
                return $normalised;
            }
            $checked[] = $normalised;
        }
        $settings['visibilityConditions'] = $checked;
    }
    if (array_key_exists('triggers', $patch)) {
        $settings['triggers'] = is_array($patch['triggers'])
            ? array_values(array_unique(kk_string_list($patch['triggers'])))
            : $patch['triggers'];
    }
    if (array_key_exists('delay_seconds', $patch)) {
        $settings['popupDelay'] = ['value' => $patch['delay_seconds'], 'unit' => 's'];
    }
    if (array_key_exists('show_count', $patch)) {
        $settings['numberOfTimes'] = $patch['show_count'];
    }
    if (array_key_exists('position', $patch)) {
        $settings['popupPosition'] = $patch['position'];
    }
    if (array_key_exists('offset_x', $patch)) {
        $settings['horizontalOffset'] = ['value' => $patch['offset_x'], 'unit' => 'px'];
    }
    if (array_key_exists('offset_y', $patch)) {
        $settings['verticalOffset'] = ['value' => $patch['offset_y'], 'unit' => 'px'];
    }
    foreach ([
        'x_icon' => 'xIcon',
        'close_button' => 'closeButton',
        'outside_click_close' => 'outsideClickClose',
    ] as $flat => $key) {
        if (!array_key_exists($flat, $patch)) {
            continue;
        }
        /** @var mixed $switch */
        $switch = $patch[$flat];
        $settings[$key] = is_bool($switch) ? (int) $switch : $switch;
    }
    if (array_key_exists('animation', $patch)) {
        $settings['animationName'] = $patch['animation'] === 'none' ? '' : $patch['animation'];
    }
    if (array_key_exists('duration_seconds', $patch)) {
        $settings['duration'] = $patch['duration_seconds'];
    }
    if (array_key_exists('easing', $patch)) {
        $settings['easing'] = $patch['easing'];
    }
    $errors = kk_validate_popup_settings($settings);
    if ($errors !== []) {
        return kk_invalid_input('settings: ' . implode(' ', $errors));
    }
    /** @var array<string, mixed> $settings */
    return $settings;
}

/**
 * The stored settings map in the flat form the abilities exchange, the
 * conditions normalised like kirki-list-templates (`effective` / `note`).
 *
 * @param array<string, mixed> $settings
 * @return array<string, mixed>
 */
function kk_popup_settings_flat(array $settings): array
{
    $settings += KK_POPUP_DEFAULT_SETTINGS;
    $conditions = [];
    /** @var mixed $raw */
    foreach (is_array($settings['visibilityConditions']) ? $settings['visibilityConditions'] : [] as $raw) {
        if (!is_array($raw)) {
            continue;
        }
        $conditions[] = kk_popup_condition_row(kk_normalize_condition($raw));
    }
    $delay = is_array($settings['popupDelay']) ? $settings['popupDelay'] : [];
    $delay_value = is_numeric($delay['value'] ?? null) ? (float) $delay['value'] : 0.0;
    return [
        'conditions' => $conditions,
        'triggers' => is_array($settings['triggers']) ? array_values($settings['triggers']) : [],
        'delay_seconds' => ($delay['unit'] ?? 's') === 'ms' ? $delay_value / 1000 : $delay_value,
        'show_count' => $settings['numberOfTimes'],
        'position' => $settings['popupPosition'],
        'offset_x' => is_array($settings['horizontalOffset']) ? $settings['horizontalOffset']['value'] ?? 0 : 0,
        'offset_y' => is_array($settings['verticalOffset']) ? $settings['verticalOffset']['value'] ?? 0 : 0,
        'x_icon' => kk_bool($settings['xIcon']),
        'close_button' => kk_bool($settings['closeButton']),
        'outside_click_close' => kk_bool($settings['outsideClickClose']),
        'animation' => $settings['animationName'] === '' ? 'none' : $settings['animationName'],
        'duration_seconds' => $settings['duration'],
        'easing' => $settings['easing'],
    ];
}

/**
 * A normalised condition row with its note worded for popups: Kirki evaluates
 * popup conditions on the rendered post only (`check_all_conditions_for_this_post`),
 * never on term or author archives.
 *
 * @param array<string, mixed> $row
 * @return array<string, mixed>
 */
function kk_popup_condition_row(array $row): array
{
    if (($row['from'] ?? null) === 'term') {
        $row['note'] = 'never matches: a `from: term` entry makes the WHOLE popup never print (popups are evaluated on posts only, never on term archives)';
        $row['effective'] = false;
        return $row;
    }
    if (($row['type'] ?? null) === 'user') {
        $row['note'] = 'never matches: `type: user` entries apply to author pages, where popups are not evaluated';
        $row['effective'] = false;
        return $row;
    }
    if (is_string($row['note'] ?? null)) {
        $row['note'] = str_replace('template', replace: 'popup', subject: $row['note']);
    }
    return $row;
}

/**
 * What the popup abilities report after a write, read back from the stored
 * map: root id, counts, name, flat settings, condition notes as warnings.
 *
 * @return array{root_id: string, blocks_count: int, style_blocks_count: int, name: string, settings: array<string, mixed>, warnings: list<string>}
 */
function kk_popup_report(int $post_id): array
{
    $blocks = kk_blocks_of(kk_meta($post_id, kk_meta_blocks())) ?? [];
    $root_id = kk_popup_root_of($blocks) ?? '';
    $root = $root_id !== '' && is_array($blocks[$root_id] ?? null) ? kk_node_map($blocks[$root_id]) : [];
    /** @var array<string, mixed> $props */
    $props = is_array($root['properties'] ?? null) ? $root['properties'] : [];
    /** @var array<string, mixed> $stored_settings */
    $stored_settings = is_array($props['popup'] ?? null) ? $props['popup'] : [];
    $settings = kk_popup_settings_flat($stored_settings);
    /** @var mixed $styles */
    $styles = kk_meta($post_id, kk_meta_style_blocks());
    $warnings = [];
    /** @var list<array<string, mixed>> $conditions */
    $conditions = $settings['conditions'];
    foreach ($conditions as $index => $condition) {
        /** @var mixed $note */
        $note = $condition['note'] ?? null;
        if (!is_string($note)) {
            continue;
        }
        $warnings[] = sprintf('conditions[%d]: %s.', $index, $note);
    }
    return [
        'root_id' => $root_id,
        'blocks_count' => count($blocks),
        'style_blocks_count' => is_array($styles) ? count($styles) : 0,
        'name' => is_string($props['name'] ?? null) ? $props['name'] : '',
        'settings' => $settings,
        'warnings' => $warnings,
    ];
}

/**
 * Warnings about whether the popup will print: a draft prints nowhere; a
 * published popup without conditions and without triggers prints only where
 * a button / form opens it.
 *
 * @param array<string, mixed>|null $settings
 * @return list<string>
 */
function kk_popup_status_warnings(?WP_Post $post, ?array $settings): array
{
    if ($post === null) {
        return [];
    }
    if ($post->post_status !== 'publish') {
        return [sprintf(
            'Popup %d is `%s`: the frontend prints published popups only (novamira/update-post sets the status).',
            $post->ID,
            $post->post_status,
        )];
    }
    if ($settings !== null && ($settings['visibilityConditions'] ?? []) === []) {
        return ['The popup has no visibility condition: it prints only on pages where a button / form opens it.'];
    }
    if ($settings !== null && ($settings['triggers'] ?? []) === []) {
        return [
            'The popup has no trigger: on the pages its conditions match it stays hidden until a button / form opens it.',
        ];
    }
    return [];
}
