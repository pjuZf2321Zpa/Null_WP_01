<?php

// SPDX-FileCopyrightText: 2026 Ovation S.r.l. <dev@novamira.ai>
// SPDX-License-Identifier: AGPL-3.0-or-later

declare(strict_types=1);

namespace Novamira\Pro\Abilities\Kirki;

use WP_Post;

/**
 * Ability: List content owned by the Kirki editor (pages, posts, templates,
 * popups, utility pages) with compact per-row signals.
 */

if (!defined('ABSPATH')) {
    exit();
}

wp_register_ability('novamira/kirki-list-pages', [
    'label' => __('List Kirki Pages', domain: 'novamira-pro'),
    'description' => __(
        'Lists posts the Kirki editor owns (the `kirki_editor_mode` postmeta is set): WordPress pages, posts and public custom post types built with Kirki (`kind: custom`, the row carries the real `post_type`), plus Kirki templates (`kirki_template`), popups (`kirki_popup`) and utility pages (`kirki_utility`: 404, login, sign-up, password flows). Each row is compact: id, title, slug, kind, post_type, status, `modified` (WordPress `post_modified_gmt`: Kirki\'s editor saves and the abilities never bump it, `staging.last_updated` holds the last Kirki edit), whether a published block tree exists, its node count (`blocks_count`, null when the stored tree is over 1 MB and is not decoded for a list — kirki-get-content reports `total_nodes`) and its stored size (`blocks_bytes`), staging summary (versions, published version, drafts newer than it, last update; popups are never staged, so `unpublished_versions` is 0 and `last_updated` null for them), and — for templates — the number of display conditions, for utility pages — the utility kind. Rows are read straight from the database (bypassing the object cache and the WordPress query cache). Filter with `kind`, `status`, `search`; page with `limit` / `offset`. Trashed posts are never returned.',
        domain: 'novamira-pro',
    ),
    'category' => 'kirki',
    'input_schema' => [
        'type' => 'object',
        'default' => [],
        'properties' => [
            'kind' => [
                'type' => 'string',
                'enum' => ['page', 'post', 'custom', 'template', 'popup', 'utility'],
                'description' => 'Restrict to one content kind (`custom` = every public custom post type built with Kirki; rows then carry the real `post_type`). Omit for all.',
            ],
            'status' => [
                'type' => 'string',
                'enum' => ['publish', 'draft', 'pending', 'private', 'future', 'any'],
                'description' => 'Post status filter. Default `any` (publish, draft, pending, private, future).',
                'default' => 'any',
            ],
            'search' => ['type' => 'string', 'description' => KK_SEARCH_DESCRIPTION],
            'limit' => KK_LIMIT_SCHEMA,
            'offset' => KK_OFFSET_SCHEMA,
        ],
        'additionalProperties' => false,
    ],
    'output_schema' => [
        'type' => 'object',
        'properties' => [
            'pages' => [
                'type' => 'array',
                'items' => ['type' => 'object'],
            ],
            'total' => [
                'type' => 'integer',
                'description' => 'Total matching rows before `limit` / `offset`.',
            ],
            'returned' => ['type' => 'integer'],
        ],
        'required' => ['pages', 'total', 'returned'],
        'additionalProperties' => false,
    ],
    'execute_callback' => 'Novamira\\Pro\\Abilities\\Kirki\\kirki_list_pages',
    'permission_callback' => 'novamira_permission_callback',
    'meta' => [
        'show_in_rest' => true,
        'mcp' => ['public' => true],
        'annotations' => [
            'instructions' => 'Run this to find the id of the page/template/popup to read or edit. Only posts in Kirki editor mode are listed: Kirki sets that marker on save (and on creation from its dashboard), so a post merely opened in the editor and never saved is NOT listed even though it already carries a staging ledger. `has_blocks=false` means the post is in Kirki mode but no tree was saved yet. `staging.unpublished_versions` counts the versions NEWER than the published one (Kirki marks every older version unpublished when it publishes, those do not count): when it is > 0 the editor holds a draft newer than the published tree; the published tree is what kirki-get-content shows and what the frontend serves — unless a published kirki_template matches the post (details templates of Content Manager items, templates with conditions), then the template renders instead. `staging.last_updated` is the newest version\'s stamp as Kirki stored it, in the SITE time zone: since Kirki 6.4.0 both a version\'s creation and its later edits are stamped site-local, where 6.3.x mixed the two.',
            'readonly' => true,
            'destructive' => false,
            'idempotent' => true,
        ],
    ],
]);

/**
 * @param array{kind?: string, status?: string, search?: string, limit?: mixed, offset?: mixed} $input
 * @return array<string, mixed>|\WP_Error
 */
function kirki_list_pages(array $input): array|\WP_Error
{
    kk_begin();
    $types = kk_content_post_types();
    $custom = kk_custom_content_post_types();
    $kind = $input['kind'] ?? null;
    $post_types = match (true) {
        $kind === 'custom' => array_values($custom),
        $kind !== null && isset($types[$kind]) => [$types[$kind]],
        default => kk_page_post_types(),
    };
    if ($post_types === []) {
        return ['pages' => [], 'total' => 0, 'returned' => 0];
    }
    $status = $input['status'] ?? 'any';
    $post_status = $status === 'any' ? ['publish', 'draft', 'pending', 'private', 'future'] : [$status];
    $limit = kk_clamp_limit($input['limit'] ?? null, default: 50);
    $offset = max(0, kk_coerce_int_or_null($input['offset'] ?? null) ?? 0);

    $needle = kk_search_needle($input['search'] ?? null);
    if ($needle instanceof \WP_Error) {
        return $needle;
    }
    $args = [
        'post_type' => $post_types,
        'post_status' => $post_status,
        'posts_per_page' => $limit,
        'offset' => $offset,
        'orderby' => 'modified',
        'order' => 'DESC',
        // BINARY: Kirki compares the marker with `===`, the DB collation would
        // also match `Kirki` / `kirki ` and list pages Kirki does not render.
        'meta_query' => [
            ['key' => kk_meta_editor_mode(), 'value' => KK_EDITOR_MODE, 'compare' => '=', 'type' => 'BINARY'],
        ],
        'no_found_rows' => false,
        'update_post_term_cache' => false,
        // Never prime the meta cache: a real page carries its tree plus one
        // staged copy per version (megabytes each); the row reads its few keys
        // with one grouped query instead (kk_list_meta).
        'update_post_meta_cache' => false,
        // Kirki's direct meta writes do not bump the `posts` last_changed
        // salt: a cached result set would keep listing a page
        // switched back to the WordPress editor.
        'cache_results' => false,
    ];
    if ($needle !== null) {
        $args['s'] = $needle;
        $args['search_columns'] = ['post_title'];
    }

    $query = new \WP_Query($args);
    $by_type = array_flip($types);
    $posts = array_values(array_filter($query->posts, static fn(mixed $post): bool => $post instanceof WP_Post));
    $ids = array_map(static fn(WP_Post $post): int => $post->ID, $posts);
    $meta = kk_list_meta(
        $ids,
        [kk_meta_blocks(), kk_meta_staged_versions(), kk_meta_template_conditions(), kk_meta_utility_page_type()],
        inline_bytes: KK_LIST_TREE_BYTES,
    );
    // Versions come from `kirki_stages` in one query. The legacy postmeta list is
    // still read above and used for a page the migration cron has not reached:
    // calling Kirki's per-post accessor here would be an N+1 and would migrate
    // every listed page from a read-only ability.
    $ledgers = kk_stage_ledgers($ids);
    $rows = [];
    foreach ($posts as $post) {
        $rows[] = kk_page_summary(
            $post,
            $by_type[$post->post_type] ?? 'custom',
            $meta[$post->ID] ?? [],
            kk_listed_ledger($post->ID, $meta[$post->ID] ?? [], $ledgers),
        );
    }

    return [
        'pages' => $rows,
        'total' => kk_found_total($query, $args),
        'returned' => count($rows),
    ];
}

/**
 * Compact row for one Kirki-mode post, from the keys kk_list_meta read for it
 * and the ledger kk_stage_ledgers read for it.
 *
 * @param array<string, array{bytes: int, value: mixed}> $meta
 * @param list<array{version: int, published: bool, last_updated: string|null, no_legacy_global_style: bool}> $ledger
 * @return array<string, mixed>
 */
function kk_page_summary(WP_Post $post, string $kind, array $meta, array $ledger): array
{
    $tree = kk_list_tree_summary($meta[kk_meta_blocks()] ?? null);
    $row = [
        'id' => $post->ID,
        'title' => $post->post_title,
        'slug' => $post->post_name,
        'kind' => $kind,
        'post_type' => $post->post_type,
        'status' => $post->post_status,
        'modified' => kk_modified_gmt($post),
        'has_blocks' => $tree['has_blocks'],
        'blocks_count' => $tree['blocks_count'],
        'blocks_bytes' => $tree['blocks_bytes'],
        'staging' => kk_staging_info_of($ledger, $post->post_type),
    ];
    if ($kind === 'template') {
        /** @var mixed $conditions */
        $conditions = $meta[kk_meta_template_conditions()]['value'] ?? null;
        $row['conditions_count'] = is_array($conditions) ? count($conditions) : 0;
    }
    if ($kind === 'utility') {
        /** @var mixed $utility */
        $utility = $meta[kk_meta_utility_page_type()]['value'] ?? null;
        $row['utility_type'] = is_string($utility) ? $utility : null;
    }
    return $row;
}

/**
 * `has_blocks` / `blocks_count` / `blocks_bytes` of a list row from the raw
 * `kirki` meta as kk_list_meta returned it. Trees over KK_LIST_TREE_BYTES are
 * not decoded (`blocks_count` null): kirki-get-content reports `total_nodes`.
 *
 * @param array{bytes: int, value: mixed}|null $entry
 * @return array{has_blocks: bool, blocks_count: int|null, blocks_bytes: int}
 */
function kk_list_tree_summary(?array $entry): array
{
    if ($entry === null) {
        return ['has_blocks' => false, 'blocks_count' => 0, 'blocks_bytes' => 0];
    }
    if ($entry['value'] === null) {
        return ['has_blocks' => $entry['bytes'] > 0, 'blocks_count' => null, 'blocks_bytes' => $entry['bytes']];
    }
    $blocks = kk_blocks_of($entry['value']);
    return [
        'has_blocks' => $blocks !== null,
        'blocks_count' => $blocks === null ? 0 : count($blocks),
        'blocks_bytes' => $entry['bytes'],
    ];
}
