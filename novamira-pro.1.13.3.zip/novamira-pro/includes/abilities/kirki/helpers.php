<?php

// SPDX-FileCopyrightText: 2026 Ovation S.r.l. <dev@novamira.ai>
// SPDX-License-Identifier: AGPL-3.0-or-later

declare(strict_types=1);

namespace Novamira\Pro\Abilities\Kirki;

use WP_Error;
use WP_Post;

if (!defined('ABSPATH')) {
    exit();
}

/**
 * Maximum number of rows returned by collection-style abilities. Callers may
 * ask for less; anything above is clamped so a single call cannot flood the
 * agent context.
 */
const KK_LIST_HARD_MAX = 500;

/**
 * The value Kirki stores in the editor-mode postmeta for content owned by its
 * builder (`Kirki\App\get_editor_mode()`). The frontend
 * only renders the block tree when this meta matches — a page with blocks but
 * without it falls back to the WordPress editor content.
 */
const KK_EDITOR_MODE = 'kirki';

/**
 * Kirki's own editor access levels (`Kirki\App\Constants\AccessLevels`),
 * ordered from strongest to weakest. Assigned per WP role by
 * `AccessLevels::ROLE_ACCESS_MAP` (see kk_role_access_map()); a user gets the
 * level of each of their roles (`HelperFunctions::has_access()`).
 */
// Kirki's access levels (`AccessLevels`). The ORDER is ours, strongest first,
// and only for reporting: Kirki itself never ranks them — `has_access()` is an
// `array_intersect` of the required level against the levels of the user's
// roles, so `full` does not imply `editor`.
const KK_ACCESS_LEVELS = ['full', 'editor', 'content', 'view', 'no'];

/**
 * Custom tables Kirki creates through its migrations (`database/migrations`),
 * without the WP prefix. Reported by check-setup so an agent knows whether the
 * forms / Content Manager / collaboration surfaces have storage.
 */
const KK_TABLES = [
    'kirki_forms',
    'kirki_forms_data',
    'kirki_cm_reference',
    'kirki_collaborations',
    'kirki_collaborations_connected',
    'kirki_collaborations_sent',
    'kirki_comments',
    'kirki_comments_seen',
];

// ---------------------------------------------------------------------------
// Constant mirrors. Kirki keeps every persisted identifier in
// `Kirki\App\Constants\*` classes; reading them at runtime keeps the abilities
// aligned with the installed release instead of repeating literals. The
// fallback is the 6.3.0 value, used only when the class is absent (never the
// case behind the gate, but the helpers stay total functions).
// ---------------------------------------------------------------------------

/**
 * Read a `Kirki\App\Constants\<class>::<name>` constant, or `$fallback` when
 * the class or constant is not available.
 */
function kk_const(string $class, string $name, string $fallback): string
{
    $fqcn = 'Kirki\\App\\Constants\\' . $class;
    $ref = $fqcn . '::' . $name;
    if (!class_exists($fqcn) || !defined($ref)) {
        kk_const_drift($ref, mark: true);
        return $fallback;
    }
    /** @var mixed $value */
    $value = constant($ref);
    if (!is_string($value)) {
        kk_const_drift($ref, mark: true);
        return $fallback;
    }
    return $value;
}

/**
 * Registry of Kirki constants `kk_const()` could not read this request (the
 * 6.3.0 literal was used instead). check-setup reports them: a renamed
 * constant would otherwise make every reader use the wrong meta key silently.
 *
 * @return list<string>
 */
// @mago-expect lint:no-boolean-flag-parameter -- read-or-mark accessor of one static list
function kk_const_drift(string $ref = '', bool $mark = false): array
{
    /** @var array<string, true> $missing */
    static $missing = [];
    if ($mark && $ref !== '') {
        $missing[$ref] = true;
    }
    return array_keys($missing);
}

/** Postmeta key holding the block tree (`PageMetaKeys::BLOCKS`). */
function kk_meta_blocks(): string
{
    return kk_const('PageMetaKeys', name: 'BLOCKS', fallback: 'kirki');
}

/** Postmeta key holding the editor-mode marker (`PageMetaKeys::EDITOR_MODE`). */
function kk_meta_editor_mode(): string
{
    return kk_const('PageMetaKeys', name: 'EDITOR_MODE', fallback: 'kirki_editor_mode');
}

/** Postmeta key holding the page-local style blocks (`PageMetaKeys::STYLE_BLOCKS`). */
function kk_meta_style_blocks(): string
{
    return kk_const('PageMetaKeys', name: 'STYLE_BLOCKS', fallback: 'kirki_global_style_block_random');
}

/** Postmeta key of the legacy per-page global style map (`PageMetaKeys::GLOBAL_STYLE_BLOCK_DEPRECATED`), also used for its staged copies. */
function kk_meta_global_style_block_deprecated(): string
{
    return kk_const('PageMetaKeys', name: 'GLOBAL_STYLE_BLOCK_DEPRECATED', fallback: 'kirki_global_style_block');
}

/** Postmeta key holding the staging ledger (`PageMetaKeys::STAGED_VERSIONS`). */
function kk_meta_staged_versions(): string
{
    return kk_const('PageMetaKeys', name: 'STAGED_VERSIONS', fallback: 'kirki_stage_versions');
}

/** Postmeta key holding template display conditions (`PageMetaKeys::TEMPLATE_CONDITIONS`). */
function kk_meta_template_conditions(): string
{
    return kk_const('PageMetaKeys', name: 'TEMPLATE_CONDITIONS', fallback: 'kirki_template_conditions');
}

/** Postmeta key holding the utility page kind (`PageMetaKeys::UTILITY_PAGE_TYPE`). */
function kk_meta_utility_page_type(): string
{
    return kk_const('PageMetaKeys', name: 'UTILITY_PAGE_TYPE', fallback: 'kirki_utility_page_type');
}

/** Postmeta key holding the page's SEO settings (`PageMetaKeys::SEO_SETTINGS`). */
function kk_meta_page_seo(): string
{
    return kk_const('PageMetaKeys', name: 'SEO_SETTINGS', fallback: 'kirki_page_seo_settings');
}

/** Postmeta key holding the font family names a post uses (`PageMetaKeys::USED_FONT_LIST`). */
function kk_meta_used_fonts(): string
{
    return kk_const('PageMetaKeys', name: 'USED_FONT_LIST', fallback: 'kirki_used_font_list');
}

/** Postmeta key holding a page's header / footer switches (`PageMetaKeys::DISABLED_PAGE_SYMBOLS`, `{header: bool, footer: bool}`). */
function kk_meta_disabled_symbols(): string
{
    return kk_const('PageMetaKeys', name: 'DISABLED_PAGE_SYMBOLS', fallback: 'kirki_disabled_page_symbols');
}

/** Postmeta key holding the page's custom head / body code (`PageMetaKeys::CUSTOM_CODE`). */
function kk_meta_page_custom_code(): string
{
    return kk_const('PageMetaKeys', name: 'CUSTOM_CODE', fallback: 'kirki_page_custom_code');
}

/**
 * Post types that carry a Kirki block tree, keyed by the agent-facing name.
 * `page` / `post` are WordPress types edited in Kirki mode; the rest are
 * Kirki's own CPTs (`Kirki\App\Constants\PostTypes`).
 *
 * @return array<string, string>
 */
function kk_content_post_types(): array
{
    return [
        'page' => kk_const('PostTypes', name: 'WP_PAGE', fallback: 'page'),
        'post' => kk_const('PostTypes', name: 'WP_POST', fallback: 'post'),
        'template' => kk_const('PostTypes', name: 'TEMPLATE', fallback: 'kirki_template'),
        'popup' => kk_const('PostTypes', name: 'POPUP', fallback: 'kirki_popup'),
        'utility' => kk_const('PostTypes', name: 'UTILITY', fallback: 'kirki_utility'),
    ];
}

/**
 * Public custom post types Kirki can also edit and render (its dashboard
 * offers every registered post type, the renderer has no type gate): every
 * viewable type except WordPress' page / post / attachment and Kirki's own
 * types. Keyed and valued by post type.
 *
 * @return array<string, string>
 */
function kk_custom_content_post_types(): array
{
    $own = array_merge(array_values(kk_content_post_types()), [
        kk_symbol_post_type(),
        kk_global_data_post_type(),
        kk_const('PostTypes', name: 'CONTENT_MANAGER', fallback: 'kirki_cm'),
        kk_const('PostTypes', name: 'COLLECTION', fallback: 'kirki_post'),
        'attachment',
    ]);
    $out = [];
    foreach (get_post_types(['public' => true], output: 'names') as $type) {
        if (in_array($type, $own, strict: true) || !is_post_type_viewable($type)) {
            continue;
        }
        $out[$type] = $type;
    }
    return $out;
}

/**
 * Every post type the page abilities read and write: the five named kinds
 * plus the public custom post types.
 *
 * @return list<string>
 */
function kk_page_post_types(): array
{
    return array_values(array_unique(array_merge(
        array_values(kk_content_post_types()),
        array_values(kk_custom_content_post_types()),
    )));
}

/** Kirki's popup post type: readable through the page readers, written by the popup abilities only (see kk_writable_post_or_error). */
function kk_popup_post_type(): string
{
    return kk_const('PostTypes', name: 'POPUP', fallback: 'kirki_popup');
}

/** Kirki's symbol (header / footer / component) post type. */
function kk_symbol_post_type(): string
{
    return kk_const('PostTypes', name: 'SYMBOL', fallback: 'kirki_symbol');
}

/** Kirki's Content Manager collection post type. */
function kk_collection_post_type(): string
{
    return kk_const('PostTypes', name: 'CONTENT_MANAGER', fallback: 'kirki_cm');
}

/** Kirki's global-data holder post type. */
function kk_global_data_post_type(): string
{
    return kk_const('PostTypes', name: 'GLOBAL_DATA', fallback: 'kirki_global_data');
}

// ---------------------------------------------------------------------------
// Detection. Static-cached per request.
// ---------------------------------------------------------------------------

/**
 * Snapshot of Kirki detection.
 *
 * @return array{active: bool, version: string, min_supported: string, min_satisfied: bool}
 */
function kk_detect_setup(): array
{
    /** @var array{active: bool, version: string, min_supported: string, min_satisfied: bool}|null $cache */
    static $cache = null;
    if ($cache !== null) {
        return $cache;
    }
    $min = NOVAMIRA_PRO_KIRKI_MIN_VERSION;
    if (!defined('KIRKI_VERSION') || !class_exists('KirkiMain')) {
        return $cache = ['active' => false, 'version' => '', 'min_supported' => $min, 'min_satisfied' => false];
    }
    /** @var mixed $raw */
    $raw = constant('KIRKI_VERSION');
    $version = is_string($raw) ? $raw : '';
    return $cache = [
        'active' => true,
        'version' => $version,
        'min_supported' => $min,
        'min_satisfied' => $version !== '' && version_compare($version, $min, operator: '>='),
    ];
}

/**
 * Snapshot of Kirki Pro detection. Pro ships no PHP data model: it swaps the
 * editor bundle and stores its license in the `kirki_wp_admin_common_data`
 * option (`HelperFunctions::is_pro_user()`).
 * `license_valid` mirrors that check; it only affects the editor UI, never the
 * server-side data the abilities read and write.
 *
 * @return array{active: bool, version: string, license_valid: bool, license_checked: bool}
 */
function kk_detect_pro(): array
{
    if (!defined('KIRKI_PRO_VERSION') || !class_exists('KirkiProMain')) {
        return ['active' => false, 'version' => '', 'license_valid' => false, 'license_checked' => false];
    }
    /** @var mixed $raw */
    $raw = constant('KIRKI_PRO_VERSION');
    /** @var mixed $common */
    $common = get_option(
        kk_const('OptionKeys', name: 'WP_ADMIN_COMMON_DATA', fallback: 'kirki_wp_admin_common_data'),
        [],
    );
    $valid = false;
    $checked = false;
    if (is_array($common) && isset($common['license_key']) && is_array($common['license_key'])) {
        // Pro writes `{key, valid}` after its first license check (`check_my_license`); before that the option has no `license_key`.
        $checked = true;
        /** @var mixed $flag */
        $flag = $common['license_key']['valid'] ?? false;
        $valid = is_scalar($flag) ? (bool) $flag : is_array($flag) && $flag !== []; // `is_pro_user()` uses boolval()
    }
    return [
        'active' => true,
        'version' => is_string($raw) ? $raw : '',
        'license_valid' => $valid,
        'license_checked' => $checked,
    ];
}

/**
 * Whether the legacy Kirki Customizer Framework (`customizer/`, the
 * `Kirki::add_field()` API themes call) is loaded. It boots with the plugin
 * regardless of whether the active theme uses it; `fields_registered` tells
 * the agent whether anything actually registered against it.
 *
 * @return array{loaded: bool, fields_registered: int}
 */
function kk_detect_customizer_framework(): array
{
    $class = 'Kirki\\Compatibility\\Kirki';
    if (!class_exists($class)) {
        return ['loaded' => false, 'fields_registered' => 0];
    }
    $count = 0;
    if (property_exists($class, 'fields')) {
        // `Kirki\Compatibility\Kirki::$fields` — the static registry every
        // `add_field()` call appends to.
        /** @var mixed $fields */
        $fields = $class::$fields;
        if (is_array($fields)) {
            $count = count($fields);
        }
    }
    return ['loaded' => true, 'fields_registered' => $count];
}

// ---------------------------------------------------------------------------
// Global data. Site-wide data lives as postmeta on a single
// `kirki_global_data` post whose id is cached in the
// `KIRKI_GLOBAL_DATA_POST_TYPE_ID` option (`HelperFunctions::get_global_data_post_id()`).
// The helper below never creates the post — reads must stay side-effect free.
// ---------------------------------------------------------------------------

/**
 * Id of the global-data post AS KIRKI RESOLVES IT: `GlobalDataManager::get_post_id()`
 * trusts a truthy `KIRKI_GLOBAL_DATA_POST_TYPE_ID` (then the legacy option)
 * without checking that the post exists, so a stale option makes Kirki read a
 * phantom post. Mirroring that keeps the readers on the same data as the
 * renderer; `kk_global_data_post_issue()` reports the mismatch. Falls back to
 * a post-type lookup only when neither option is set; null when no post exists.
 */
function kk_global_data_post_id(): ?int
{
    foreach (['KIRKI_GLOBAL_DATA_POST_TYPE_ID', 'DROIP_GLOBAL_DATA_POST_TYPE_ID'] as $option) {
        // @mago-expect analysis:mixed-assignment
        $raw = get_option($option, default_value: null);
        if (!is_scalar($raw) || !kk_flag_true($raw)) {
            continue;
        }
        // Kirki casts whatever truthy value it finds: `'abc'` → 0, `'-5'` → -5.
        return (int) $raw;
    }
    // Kirki has two fallbacks. The one that runs first in practice is the
    // frontend's (`HelperFunctions::get_global_data_post_id`, any page view):
    // `get_posts()` with the default `publish` status — which never finds the
    // draft post Kirki itself creates — then a NEW empty draft post, pinned in
    // the option. Mirror that prediction; kk_global_data_post_issue() names
    // the draft post that actually holds the data.
    /** @var mixed $found */
    $found = get_posts([
        'post_type' => kk_global_data_post_type(),
        'numberposts' => 1,
        'fields' => 'ids',
        'cache_results' => false,
    ]);
    if (is_array($found) && isset($found[0])) {
        return kk_coerce_int_or_null($found[0]);
    }
    return null;
}

/**
 * Global-data posts that are NOT published (the status Kirki creates them
 * with), oldest first: the ones the frontend fallback ignores.
 *
 * @return list<int>
 */
function kk_unpublished_global_data_posts(): array
{
    /** @var mixed $found */
    $found = get_posts([
        'post_type' => kk_global_data_post_type(),
        'post_status' => array_values(array_diff(array_merge(array_keys(get_post_stati()), ['trash']), ['publish'])),
        'numberposts' => -1,
        'orderby' => 'ID',
        'order' => 'ASC',
        'fields' => 'ids',
        'cache_results' => false,
    ]);
    $ids = [];
    /** @var mixed $id */
    foreach (is_array($found) ? $found : [] as $id) {
        $int = kk_coerce_int_or_null($id);
        if ($int !== null) {
            $ids[] = $int;
        }
    }
    return $ids;
}

/**
 * Human-readable problem with the global-data post Kirki resolves to, or null
 * when it exists and has the right post type.
 */
function kk_global_data_post_issue(): ?string
{
    $id = kk_global_data_post_id();
    if ($id === null) {
        $holders = kk_unpublished_global_data_posts();
        if ($holders !== []) {
            return sprintf(
                /* translators: %s: post ids */
                __(
                    'Option KIRKI_GLOBAL_DATA_POST_TYPE_ID is not set and no kirki_global_data post is published: on the next page view Kirki\'s frontend creates a NEW empty global post and pins it, orphaning the variables, global classes and fonts stored in post %s. Set the option to that id first.',
                    domain: 'novamira-pro',
                ),
                implode(' / ', array_map('strval', $holders)),
            );
        }
        return __(
            'Kirki has not created its global-data post yet (it does so on the first page view or editor open).',
            domain: 'novamira-pro',
        );
    }
    // @mago-expect analysis:mixed-assignment
    $post = $id > 0 ? get_post($id) : null;
    if ($post instanceof WP_Post && $post->post_type === kk_global_data_post_type()) {
        if ($post->post_status === 'trash') {
            return sprintf(
                /* translators: %d: post id */
                __(
                    'The kirki_global_data post %d is in the trash; Kirki keeps reading and writing it there, but emptying the trash deletes every variable, global class and font.',
                    domain: 'novamira-pro',
                ),
                $id,
            );
        }
        if (!kk_flag_true(get_option('KIRKI_GLOBAL_DATA_POST_TYPE_ID', default_value: null))) {
            return sprintf(
                /* translators: %d: post id */
                __(
                    'Option KIRKI_GLOBAL_DATA_POST_TYPE_ID is not set; this reader picked the published global post %d the way Kirki\'s frontend fallback does, and Kirki pins that choice in the option on the next page view.',
                    domain: 'novamira-pro',
                ),
                $id,
            );
        }
        return null;
    }
    return sprintf(
        /* translators: %d: post id */
        __(
            'Option KIRKI_GLOBAL_DATA_POST_TYPE_ID points at post %d, which is missing or not a kirki_global_data post; Kirki reads and writes its global data (variables, global classes, fonts) there anyway.',
            domain: 'novamira-pro',
        ),
        $id,
    );
}

/**
 * Read one global-data key (`Kirki\App\Constants\GlobalDataKeys`). Returns
 * null when the global post does not exist or the key is unset.
 */
function kk_global_data(string $key): mixed
{
    $post_id = kk_global_data_post_id();
    if ($post_id === null || $post_id <= 0) {
        return null;
    }
    return kk_meta($post_id, $key);
}

/**
 * Viewport list the renderer uses for media queries. Read from the global UI
 * controller when the user customised it, otherwise Kirki's defaults
 * (`GlobalDataManager::get_initial_viewports()`). `md` is the base viewport:
 * its CSS is emitted without a media query.
 *
 * @return list<array{id: string, title: string, width: int, min_width: int|null, max_width: int|null, query: string|null, is_base: bool, renderer_ok: bool}>
 */
// @mago-expect lint:cyclomatic-complexity -- mirrors Kirki's list resolution and sort, one guard per field
// @mago-expect lint:halstead
function kk_viewports(): array
{
    $defaults = [
        'md' => ['title' => 'Desktop', 'value' => 1200, 'minWidth' => 1200, 'maxWidth' => 1200],
        'tablet' => ['title' => 'Tablet', 'value' => 991, 'minWidth' => 768, 'maxWidth' => 991],
        'mobileLandscape' => ['title' => 'Landscape', 'value' => 767, 'minWidth' => 576, 'maxWidth' => 767],
        'mobile' => ['title' => 'Mobile', 'value' => 575, 'minWidth' => 0, 'maxWidth' => 575],
    ];
    /** @var mixed $controller */
    $controller = kk_global_data(kk_const('GlobalDataKeys', name: 'UI_CONTROLLER', fallback: 'kirki_user_controller'));
    $list = $defaults;
    if (
        is_array($controller)
        && $controller !== []
        && isset($controller['viewport'])
        && is_array($controller['viewport'])
        && array_key_exists('list', $controller['viewport'])
    ) {
        // Kirki uses the saved list whenever the key exists — an empty list means NO media queries at all.
        /** @var mixed $saved */
        $saved = $controller['viewport']['list'];
        $list = [];
        /** @var mixed $vp */
        foreach (is_array($saved) ? $saved : [] as $id => $vp) {
            if (!is_string($id) || !is_array($vp)) {
                continue;
            }
            /** @var mixed $title */
            $title = $vp['title'] ?? $id;
            $list[$id] = [
                'title' => is_string($title) ? $title : $id,
                'value' => kk_coerce_int_or_null($vp['value'] ?? null) ?? 0,
                'minWidth' => is_numeric($vp['minWidth'] ?? null) ? (int) $vp['minWidth'] : null,
                'maxWidth' => is_numeric($vp['maxWidth'] ?? null) ? (int) $vp['maxWidth'] : null,
            ];
        }
    }
    // The renderer sorts by minWidth; viewports after `md` get min-width
    // queries, the ones before it max-width queries (`sort_viewport_list`).
    uasort($list, static fn(array $a, array $b): int => ($a['minWidth'] ?? 0) <=> ($b['minWidth'] ?? 0));
    $passed_md = false;
    $out = [];
    foreach ($list as $id => $vp) {
        $type = match (true) {
            $id === 'md' => 'base',
            $passed_md => 'min',
            default => 'max',
        };
        if ($id === 'md') {
            $passed_md = true;
        }
        $out[] = [
            'id' => $id,
            'title' => $vp['title'],
            'width' => $vp['value'],
            'min_width' => $vp['minWidth'],
            'max_width' => $vp['maxWidth'],
            'query' => match ($type) {
                'base' => null,
                'min' => sprintf('min-width: %spx', (string) ($vp['minWidth'] ?? '')),
                default => sprintf('max-width: %spx', (string) ($vp['maxWidth'] ?? '')),
            },
            'is_base' => $id === 'md',
            // Kirki's frontend sorts viewports by minWidth, so every entry needs one.
            'renderer_ok' => $vp['minWidth'] !== null && $vp['maxWidth'] !== null,
        ];
    }
    return $out;
}

// ---------------------------------------------------------------------------
// Access levels (Kirki RBAC). These gate the Kirki editor UI and REST
// middlewares only; the abilities are authorised by `novamira_permission_callback`.
// Reported so the agent can tell the user what they will see in the editor.
// ---------------------------------------------------------------------------

/**
 * Kirki's role → access level map.
 *
 * Hard-coded in `AccessLevels::ROLE_ACCESS_MAP` since 6.3.2, which removed the
 * Role Manager from the Settings panel: `Role::get_access_levels_by_roles()`
 * reads that constant and nothing else, and the `kirki_<role>` options are no longer read.
 * They survive in `wp_options` on an upgraded site and can disagree with what
 * Kirki applies (`kirki_editor` saying `full` where Kirki answers `editor`), so
 * reading them would report a level the plugin does not apply. See
 * kk_legacy_role_options() for the leftovers, reported as an issue instead.
 *
 * @return array<string, string>
 */
function kk_role_access_map(): array
{
    $ref = 'Kirki\\App\\Constants\\AccessLevels::ROLE_ACCESS_MAP';
    if (defined($ref)) {
        /** @var mixed $map */
        $map = constant($ref);
        $out = [];
        if (is_array($map)) {
            foreach (array_keys($map) as $role) {
                if (!is_string($role) || !is_string($map[$role])) {
                    continue;
                }
                $out[$role] = $map[$role];
            }
        }
        if ($out !== []) {
            return $out;
        }
    }
    kk_const_drift($ref, mark: true);
    return ['administrator' => 'full', 'editor' => 'editor', 'author' => 'content', 'subscriber' => 'no'];
}

/**
 * Leftover `kirki_<role>` options that no longer do anything, mapped to the
 * level they claim, for the roles where that claim contradicts Kirki's map.
 * Only on a site upgraded from 6.3.1 or older; a fresh install has none.
 *
 * @param array<string, string> $map kk_role_access_map()
 * @return array<string, string> role => the level the unused option still holds
 */
function kk_legacy_role_options(array $map): array
{
    $out = [];
    /** @var array<string, array{name: string}> $roles */
    $roles = wp_roles()->roles;
    foreach (array_keys($roles) as $role) {
        /** @var mixed $stored */
        $stored = get_option('kirki_' . $role, default_value: null);
        if (!is_string($stored) || $stored === '' || $stored === '0') {
            continue;
        }
        if (($map[$role] ?? 'no') === $stored) {
            continue;
        }
        $out[$role] = $stored;
    }
    return $out;
}

/**
 * The level Kirki applies to one role: its map's entry, `no` for a role the map
 * does not list (`Role::get_access_levels_by_roles()` ends in `?? NO_ACCESS`).
 *
 * @param array<string, string> $map kk_role_access_map()
 */
function kk_effective_role_access(string $role, array $map): string
{
    return $map[$role] ?? 'no';
}

/**
 * Whether the user is one Kirki's own admin screens accept, which since 6.3.2 is
 * the `administrator` ROLE and not an access level: `HelperFunctions::user_is_admin()`
 * is `user_is('administrator')`, i.e. `in_array('administrator', $user->roles, true)`.
 * A capability check would be wider than what Kirki does.
 */
function kk_user_is_kirki_admin(): bool
{
    /** @var mixed $roles */
    $roles = wp_get_current_user()->roles;
    return is_array($roles) && in_array('administrator', $roles, strict: true);
}

/**
 * Strongest Kirki access level among the current user's roles, by the order of
 * KK_ACCESS_LEVELS — our reporting convention, since Kirki matches a required
 * level exactly rather than ranking (see KK_ACCESS_LEVELS). `no` when no role
 * of the user is in Kirki's map.
 */
function kk_current_user_access_level(): string
{
    $user = wp_get_current_user();
    $map = kk_role_access_map();
    $best = 'no';
    $rank = array_flip(KK_ACCESS_LEVELS);
    /** @var mixed $role */
    foreach ($user->roles as $role) {
        if (!is_string($role)) {
            continue;
        }
        $level = kk_effective_role_access($role, $map);
        if (isset($rank[$level]) && $rank[$level] < $rank[$best]) {
            $best = $level;
        }
    }
    return $best;
}

// ---------------------------------------------------------------------------
// Per-post readers.
// ---------------------------------------------------------------------------

/** Whether the post is owned by the Kirki editor (editor-mode meta matches). */
function kk_is_kirki_mode(int $post_id): bool
{
    return kk_meta($post_id, kk_meta_editor_mode()) === KK_EDITOR_MODE;
}

/**
 * Read one postmeta value bypassing a possibly stale object cache. Kirki's
 * ORM (`Kirki\App\Models\PostMeta`) writes with raw SQL and never invalidates
 * `wp_cache`, so on a site with a persistent object cache the editor's saves
 * would otherwise be invisible to these abilities. The cache is dropped once
 * per post per request, then every read goes through the normal API.
 */
function kk_meta(int $post_id, string $key): mixed
{
    kk_fresh($post_id);
    if (!metadata_exists('post', $post_id, $key)) {
        return null;
    }
    return get_post_meta($post_id, $key, single: true);
}

/**
 * Selected meta of many posts in ONE query, bypassing the object cache and
 * WordPress' whole-post meta loading. `get_post_meta` always loads EVERY key
 * of a post (a page keeps a staged copy of its tree per version, so a list
 * of 50 real pages would load hundreds of megabytes just to count nodes),
 * and `WP_Query` result caches are salted by a counter Kirki's direct meta
 * writes never bump. Values longer than `$inline_bytes` come back as null
 * with their size; a value is unserialised like `get_post_meta` does.
 *
 * @param list<int> $post_ids
 * @param list<string> $keys
 * @return array<int, array<string, array{bytes: int, value: mixed}>> post id => key => {bytes, value|null}
 */
function kk_list_meta(array $post_ids, array $keys, int $inline_bytes): array
{
    global $wpdb;
    /** @var \wpdb $wpdb */
    $out = [];
    if ($post_ids === [] || $keys === []) {
        return $out;
    }
    // @mago-expect analysis:possibly-invalid-argument
    $sql = (string) $wpdb->prepare(
        sprintf(
            'SELECT post_id, meta_key, LENGTH(meta_value) AS bytes, IF(LENGTH(meta_value) <= %%d, meta_value, NULL) AS value FROM %s WHERE post_id IN (%s) AND meta_key IN (%s) ORDER BY meta_id ASC',
            $wpdb->postmeta,
            implode(',', array_fill(start_index: 0, count: count($post_ids), value: '%d')),
            implode(',', array_fill(start_index: 0, count: count($keys), value: '%s')),
        ),
        $inline_bytes,
        ...$post_ids,
        ...$keys,
    );
    /** @var mixed $rows */
    $rows = $wpdb->get_results($sql, 'ARRAY_A');
    if (!is_array($rows)) {
        return $out;
    }
    /** @var mixed $row */
    foreach ($rows as $row) {
        if (!is_array($row)) {
            continue;
        }
        $id = kk_coerce_int_or_null($row['post_id'] ?? null) ?? 0;
        /** @var mixed $key */
        $key = $row['meta_key'] ?? null;
        if ($id <= 0 || !is_string($key) || isset($out[$id][$key])) {
            // First row wins, as `get_post_meta(single: true)` reads it.
            continue;
        }
        /** @var mixed $value */
        $value = $row['value'] ?? null;
        $out[$id][$key] = [
            'bytes' => kk_coerce_int_or_null($row['bytes'] ?? null) ?? 0,
            'value' => is_string($value) ? maybe_unserialize($value) : null,
        ];
    }
    return $out;
}

/** Bytes above which the list abilities stop decoding a stored tree just to count its nodes. */
const KK_LIST_TREE_BYTES = 1_048_576;

/** Drop the meta cache of a post once per request (see kk_meta). */
function kk_fresh(int $post_id): void
{
    if (kk_fresh_state($post_id, mark: true)) {
        return;
    }
    wp_cache_delete($post_id, group: 'post_meta');
}

/** Drop the post and meta caches of a post (after our own writes, before a read-back). */
function kk_refresh(int $post_id): void
{
    wp_cache_delete($post_id, group: 'post_meta');
    clean_post_cache($post_id);
}

/**
 * Whether the abilities have already dropped the meta cache of a post in this
 * request (see kk_fresh).
 */
function kk_is_fresh(int $post_id): bool
{
    return kk_fresh_state($post_id, mark: false);
}

/**
 * Forget which posts had their meta cache dropped, so the next kk_meta reads
 * the database again. Called at the start of every ability: "once per
 * request" is otherwise "once per PHP process", and a WP-CLI loop or an
 * Action Scheduler worker calling an ability twice around an editor save
 * would read the first state forever.
 */
function kk_begin(): void
{
    kk_fresh_state(post_id: 0, mark: false, reset: true);
}

/**
 * @internal shared state of kk_fresh / kk_is_fresh / kk_begin
 */
// @mago-expect lint:no-boolean-flag-parameter -- read-or-mark accessor of one static map
function kk_fresh_state(int $post_id, bool $mark, bool $reset = false): bool
{
    /** @var array<string, true> $done */
    static $done = [];
    if ($reset) {
        $done = [];
        return false;
    }
    $key = get_current_blog_id() . ':' . $post_id;
    $was = isset($done[$key]);
    if ($mark) {
        $done[$key] = true;
    }
    return $was;
}

/**
 * Kirki's own truthiness (`Kirki\App\to_boolean`): strings `''`, `'0'`, `'false'`
 * and numeric zero are false, everything else (incl. `'true'`, `'yes'`) true.
 * Used for the ledger `publish` flag exactly as `get_published_staged_version_info` does.
 */
function kk_flag_true(mixed $value): bool
{
    if (is_bool($value)) {
        return $value;
    }
    if ($value === null) {
        return false;
    }
    if (is_string($value) && ($value === '' || $value === '0' || strtolower($value) === 'false')) {
        return false;
    }
    if (is_numeric($value) && (int) $value === 0) {
        // `'0.5'`, `' 0'`, `'00'`, `0.5`: Kirki casts to int before comparing.
        return false;
    }
    if (is_array($value)) {
        return $value !== [];
    }
    return true;
}

/**
 * Parsed staging ledger: `{version, published, last_updated, no_legacy_global_style}`
 * per entry, in stored order, malformed entries dropped.
 *
 * @return list<array{version: int, published: bool, last_updated: string|null, no_legacy_global_style: bool}>
 */
function kk_ledger(int $post_id): array
{
    // Read-only on purpose. Kirki's own accessor would be the obvious call, but
    // every read path of its repository runs `migrate_post_if_needed()` first,
    // so a `readonly: true` ability would write. The write path migrates
    // deliberately (kk_migrate_versions) before it plans anything.
    /** @var mixed $legacy */
    $legacy = kk_meta($post_id, kk_meta_staged_versions());
    if (kk_legacy_versions_win($legacy)) {
        return kk_ledger_of($legacy);
    }
    return kk_stage_ledgers([$post_id])[$post_id] ?? [];
}

/**
 * Normalised ledger entries of a raw `kirki_stage_versions` value.
 *
 * @return list<array{version: int, published: bool, last_updated: string|null, no_legacy_global_style: bool}>
 */
function kk_ledger_of(mixed $ledger): array
{
    if (!is_array($ledger)) {
        return [];
    }
    $out = [];
    /** @var mixed $entry */
    foreach ($ledger as $entry) {
        if (!is_array($entry)) {
            continue;
        }
        // Kirki reads `intval($entry['version'])`: `'1abc'` → 1, `true` → 1, `1.5` → 1, missing → 0.
        /** @var mixed $raw_version */
        $raw_version = $entry['version'] ?? null;
        $version = is_scalar($raw_version) || $raw_version === null ? intval($raw_version) : 0;
        /** @var mixed $updated */
        $updated = $entry['last_updated'] ?? null;
        $out[] = [
            'version' => $version,
            'published' => kk_flag_true($entry['publish'] ?? false),
            'last_updated' => is_string($updated) && $updated !== '' ? $updated : null,
            'no_legacy_global_style' => kk_flag_true($entry['no_legacy_global_style'] ?? false),
        ];
    }
    return $out;
}

/**
 * The published version number: the FIRST flagged entry, as
 * `PageManager::get_published_staged_version_info()` picks it.
 */
function kk_published_version(int $post_id): ?int
{
    return kk_published_version_of(kk_ledger($post_id));
}

/**
 * @param list<array{version: int, published: bool, last_updated: string|null, no_legacy_global_style: bool}> $ledger
 */
function kk_published_version_of(array $ledger): ?int
{
    foreach ($ledger as $entry) {
        if ($entry['published']) {
            return $entry['version'];
        }
    }
    return null;
}

// ---------------------------------------------------------------------------
// Version store. Kirki 6.4.0 moved every version but the published one out of
// `wp_postmeta` into the `kirki_stages` / `kirki_stage_data` tables and
// deprecated `PageManager::get_staged_meta_name()`, whose docblock now says the
// key it builds "points to nothing". A staged value therefore has no meta key
// to mirror: the published version is read and written as before, everything
// else goes through Kirki's own accessors.
//
// Slashing is asymmetric: `update_post_meta()` unslashes, so a published write
// is slashed; the table's `AsMetaValue` cast only serialises, so a staged write
// must NOT be slashed or every backslash is stored doubled.
// ---------------------------------------------------------------------------

/**
 * Kirki's page / version store. A new instance per call on purpose: the
 * repository caches a page's version rows and values for the life of the
 * instance and never invalidates them after a write of ours, so a shared
 * instance would read stale values across a write.
 */
function kk_pages(): \Kirki\App\Managers\PageManager
{
    return new \Kirki\App\Managers\PageManager();
}

/**
 * Whether the legacy `kirki_stage_versions` value decides, rather than the
 * `kirki_stages` rows.
 *
 * Kirki's precedence, not ours: `PageStageRepository::migrate_post_if_needed()`
 * checks for the legacy list and NOT whether the table is empty, because — its
 * own words — "after a downgrade and update, a page can have both old rows in
 * the table and newer old-format data, and the newer data must win". Reading the
 * table first would answer from the stale half, so every reader asks this first.
 */
function kk_legacy_versions_win(mixed $legacy): bool
{
    return is_array($legacy) && $legacy !== [];
}

/** Whether `$version` is the one whose data lives in postmeta (null = it is). */
function kk_version_is_published(int $post_id, ?int $version): bool
{
    if ($version === null) {
        return true;
    }
    return kk_published_version($post_id) === $version;
}

/**
 * Value of `$meta` for `$version` of `$post_id`, null when that version holds
 * none. `$version === null` means the published version.
 */
function kk_version_value(int $post_id, string $meta, ?int $version): mixed
{
    if ($version === null || kk_version_is_published($post_id, $version)) {
        return kk_meta($post_id, $meta);
    }
    return kk_stage_value($post_id, $version, $meta);
}

/**
 * Value held by ONE version's own row, never routed to the published value. The
 * published version keeps BOTH: its live data in postmeta and a snapshot copy in
 * its row, which Kirki writes on every publish (`snapshot_published_data`) and
 * reads back to decide whether publishing again would lose history
 * (`published_data_changed`). The copy is a different fact from the published
 * value, so it needs its own accessor.
 *
 * Read straight from the table, not through Kirki: every read path of its
 * repository calls `migrate_post_if_needed()` (`get_all_values()` does it on
 * each call), so going through it would let a `readonly: true` ability write.
 * A page the migration has not reached yet still answers, from the legacy keys.
 */
function kk_stage_value(int $post_id, int $version, string $meta): mixed
{
    if (kk_legacy_versions_win(kk_meta($post_id, kk_meta_staged_versions()))) {
        return kk_meta($post_id, sprintf('staged_%d_%s', $version, $meta));
    }
    global $wpdb;
    /** @var \wpdb $wpdb */
    // @mago-expect analysis:possibly-invalid-argument
    $sql = (string) $wpdb->prepare(
        sprintf(
            'SELECT d.meta_value FROM `%s` d INNER JOIN `%s` s ON s.id = d.stage_id'
            . ' WHERE s.post_id = %%d AND s.version = %%d AND d.meta_key = %%s LIMIT 1',
            kk_stage_data_table(),
            kk_stages_table(),
        ),
        $post_id,
        $version,
        $meta,
    );
    /** @var mixed $raw */
    $raw = $wpdb->get_var($sql);
    // `PageStageRepository::get_value()` answers with its default for a value
    // that is null or the empty string, so an empty row reads as absent here too.
    if (!is_string($raw) || $raw === '') {
        return null;
    }
    return maybe_unserialize($raw);
}

/**
 * Write into ONE version's store, the same one kk_stage_value() reads.
 *
 * The symmetry is the invariant: writing where the readers do not look loses the
 * value silently. Kirki migrates a page at most ONCE
 * per PHP request (`PageStageMigrationService::$migrated_in_request`), so a
 * second page-with-legacy-data in the same request stays on the legacy keys
 * however often kk_migrate_versions() asks, and a writer that assumed the move
 * had happened would write into rows nothing reads. So the store is decided
 * here, per call, by Kirki's own precedence.
 *
 * Slashing follows the store: `update_post_meta()` unslashes, the table's
 * `AsMetaValue` cast does not.
 */
function kk_stage_write(int $post_id, int $version, string $meta, mixed $value): void
{
    if (kk_legacy_versions_win(kk_meta($post_id, kk_meta_staged_versions()))) {
        update_post_meta(
            $post_id,
            sprintf('staged_%d_%s', $version, $meta),
            is_array($value) || is_string($value) ? wp_slash($value) : $value,
        );
        return;
    }
    kk_pages()->stages()->set_value($post_id, $version, $meta, $value);
}

/**
 * The ledger of one listed post: its `kirki_stages` rows when it has them, the
 * legacy postmeta list when the migration cron has not reached it yet. Keeps
 * the choice in one place and out of the row builders.
 *
 * @param array<string, array{bytes: int, value: mixed}> $meta the keys kk_list_meta read for the post
 * @param array<int, list<array{version: int, published: bool, last_updated: string|null, no_legacy_global_style: bool}>> $ledgers
 * @return list<array{version: int, published: bool, last_updated: string|null, no_legacy_global_style: bool}>
 */
function kk_listed_ledger(int $post_id, array $meta, array $ledgers): array
{
    /** @var mixed $legacy */
    $legacy = $meta[kk_meta_staged_versions()]['value'] ?? null;
    if (kk_legacy_versions_win($legacy)) {
        return kk_ledger_of($legacy);
    }
    return $ledgers[$post_id] ?? [];
}

/** The `kirki_stages` table, prefixed. */
function kk_stages_table(): string
{
    global $wpdb;
    /** @var \wpdb $wpdb */
    return $wpdb->prefix . 'kirki_stages';
}

/** The `kirki_stage_data` table, prefixed. */
function kk_stage_data_table(): string
{
    global $wpdb;
    /** @var \wpdb $wpdb */
    return $wpdb->prefix . 'kirki_stage_data';
}

/**
 * Offer a page to Kirki's migration when it still holds the legacy version list.
 * Called on the write path, inside the caller's lock and before the transaction:
 * the move is Kirki's own and one-way, and it should survive a write of ours that
 * rolls back.
 *
 * It may do nothing, and the callers must not assume otherwise: Kirki migrates a
 * page at most once per PHP request and returns without migrating on a second call
 * (`$migrated_in_request`), and a failed run is only retried later. Every
 * accessor therefore re-reads the precedence per call, and never caches a verdict
 * taken here.
 *
 * Reads never call this — that is the whole point of kk_ledger() and
 * kk_stage_value() going to the stores directly.
 */
function kk_migrate_versions(int $post_id): void
{
    if (!kk_legacy_versions_win(kk_meta($post_id, kk_meta_staged_versions()))) {
        return;
    }
    kk_pages()->get_all_staged_versions($post_id, create_if_empty: false);
    kk_refresh($post_id);
}

/**
 * Ledgers of many posts in ONE query, for the list abilities.
 *
 * Kirki's own accessor is per post and its read path migrates the page, so
 * calling it in a list would be an N+1 AND would let a read-only list write.
 * This mirrors `PageManager::format_stage_version()` for the fields a ledger
 * entry needs, ordered by version like `PageStageRepository::query_versions()`.
 *
 * A post with no row is absent from the result rather than present and empty,
 * so a caller can tell "no versions" from "not migrated yet" and fall back to
 * the legacy postmeta list it already read in the same batch.
 *
 * @param list<int> $post_ids
 * @return array<int, list<array{version: int, published: bool, last_updated: string|null, no_legacy_global_style: bool}>>
 */
function kk_stage_ledgers(array $post_ids): array
{
    $ids = array_values(array_unique(array_filter($post_ids, static fn(int $id): bool => $id > 0)));
    if ($ids === []) {
        return [];
    }
    global $wpdb;
    /** @var \wpdb $wpdb */
    // @mago-expect analysis:possibly-invalid-argument
    $sql = (string) $wpdb->prepare(
        sprintf(
            'SELECT post_id, version, is_published, no_legacy_global_style, updated_at FROM `%s`'
            . ' WHERE post_id IN (%s) ORDER BY post_id ASC, version ASC',
            kk_stages_table(),
            implode(',', array_fill(start_index: 0, count: count($ids), value: '%d')),
        ),
        ...$ids,
    );
    /** @var mixed $raw */
    $raw = $wpdb->get_results($sql, 'ARRAY_A');
    $out = [];
    if (!is_array($raw)) {
        return $out;
    }
    /** @var mixed $row */
    foreach ($raw as $row) {
        if (!is_array($row)) {
            continue;
        }
        $post_id = kk_coerce_int_or_null($row['post_id'] ?? null);
        $version = kk_coerce_int_or_null($row['version'] ?? null);
        if ($post_id === null || $version === null) {
            continue;
        }
        /** @var mixed $updated */
        $updated = $row['updated_at'] ?? null;
        $out[$post_id][] = [
            'version' => $version,
            'published' => kk_flag_true($row['is_published'] ?? false),
            'last_updated' => is_string($updated) && $updated !== '' ? $updated : null,
            'no_legacy_global_style' => kk_flag_true($row['no_legacy_global_style'] ?? false),
        ];
    }
    return $out;
}

/**
 * The published block map of a post (`blocks[id] => node`), or null when the
 * post has no tree. Staged drafts live in suffixed meta keys and are NOT read
 * here.
 *
 * @return array<string, mixed>|null
 */
function kk_blocks(int $post_id): ?array
{
    /** @var mixed $data */
    $data = kk_meta($post_id, kk_meta_blocks());
    return kk_blocks_of($data);
}

/**
 * The node map inside a stored `kirki` value: `{blocks: map}` for pages,
 * templates and utility pages, `{…, data: map, …}` for symbols, or the FLAT
 * map Kirki writes for popups (no wrapper; the `popup` element has
 * `parentId: "root"` with no root node).
 *
 * @return array<string, mixed>|null
 */
function kk_blocks_of(mixed $data): ?array
{
    if (!is_array($data)) {
        return null;
    }
    /** @var mixed $blocks */
    $blocks = $data['blocks'] ?? null;
    // A symbol keeps its nodes under `data` (`{root, name, data, styleBlocks,
    // category}`); a popup keeps them at the top level with no wrapper.
    if ($blocks === null && !array_key_exists('blocks', $data) && is_array($data['data'] ?? null)) {
        $blocks = $data['data'];
    }
    if ($blocks === null && !array_key_exists('blocks', $data) && kk_is_flat_node_map($data)) {
        $blocks = $data;
    }
    if (!is_array($blocks) || kk_blocks_shape_error($blocks) !== null) {
        return null;
    }
    /** @var array<string, mixed> $blocks */
    return $blocks;
}

/** Whether a value is a popup-style flat node map (every entry an object carrying `name`). */
function kk_is_flat_node_map(array $data): bool
{
    if ($data === []) {
        return false;
    }
    /** @var mixed $node */
    foreach ($data as $node) {
        if (!is_array($node) || !isset($node['name']) || !is_string($node['name'])) {
            return false;
        }
    }
    return true;
}

/**
 * Why a stored block map cannot be treated as a Kirki tree (list-shaped or
 * numeric ids, which PHP turns into int keys), or null when it is well-formed.
 *
 * @param array<array-key, mixed> $blocks
 */
function kk_blocks_shape_error(array $blocks): ?string
{
    foreach (array_keys($blocks) as $key) {
        if (is_string($key)) {
            continue;
        }
        return sprintf(
            /* translators: %s: array key */
            __(
                'The block map has a numeric key (`%s`); Kirki trees are objects keyed by string node ids.',
                domain: 'novamira-pro',
            ),
            (string) $key,
        );
    }
    return null;
}

/**
 * Compact view of the staging ledger (`kirki_stage_versions`). Kirki writes
 * the ledger as soon as a post is opened in its editor, before any save and
 * before the editor-mode marker, so `versions > 0` does not imply a tree
 * exists (nor that the post is in Kirki mode).
 *
 * @return array{versions: int, published_version: int|null, unpublished_versions: int, last_updated: string|null}
 */
function kk_staging_info(int $post_id): array
{
    return kk_staging_info_of(kk_ledger($post_id), get_post_type($post_id));
}

/**
 * kk_staging_info from an already-read ledger (the list abilities read the
 * ledger of every row with one grouped query, see kk_list_meta).
 *
 * @param list<array{version: int, published: bool, last_updated: string|null, no_legacy_global_style: bool}> $ledger
 * @return array{versions: int, published_version: int|null, unpublished_versions: int, last_updated: string|null}
 */
function kk_staging_info_of(array $ledger, string|false $post_type): array
{
    $published = kk_published_version_of($ledger);
    if ($post_type === kk_popup_post_type()) {
        // Kirki never stages popups: the editor's save writes the base keys and
        // the ledger is a frozen creation snapshot (`create_first_stage_version_if_empty`).
        return [
            'versions' => count($ledger),
            'published_version' => $published,
            'unpublished_versions' => 0,
            'last_updated' => null,
        ];
    }
    $newer = 0;
    $highest = null;
    foreach ($ledger as $entry) {
        if ($published !== null && $entry['version'] > $published) {
            ++$newer;
        }
        if ($highest === null || $entry['version'] > $highest['version']) {
            $highest = $entry;
        }
    }
    if ($published === null) {
        $newer = count($ledger);
    }
    return [
        'versions' => count($ledger),
        'published_version' => $published,
        'unpublished_versions' => $newer,
        'last_updated' => $highest === null ? null : $highest['last_updated'],
    ];
}

/**
 * Resolve a post id to a live post. Trash, auto-drafts and revisions are
 * refused so a write can never target content the editor does not show.
 */
function kk_post_or_error(int $post_id): WP_Post|WP_Error
{
    if ($post_id <= 0) {
        return kk_invalid_post($post_id);
    }
    // @mago-expect analysis:mixed-assignment
    $post = get_post($post_id);
    if (!$post instanceof WP_Post) {
        return kk_invalid_post($post_id);
    }
    if (in_array($post->post_status, ['trash', 'auto-draft', 'inherit'], strict: true)) {
        return kk_invalid_post($post_id);
    }
    if (!in_array($post->post_type, kk_page_post_types(), strict: true)) {
        return kk_unsupported_post_type($post);
    }
    return $post;
}

/**
 * The gate of every WRITE ability: kk_post_or_error plus the popup refusal.
 * A popup stores a FLAT node map under `kirki` (no `blocks` wrapper, no
 * `root` → `body`; the `popup` element carries `parentId: "root"` and its
 * trigger / visibility settings live in `properties.popup`), and Kirki's
 * editor saves popups without staging. A page-shaped write there would
 * replace the popup with an empty canvas that never renders.
 */
function kk_writable_post_or_error(int $post_id): WP_Post|WP_Error
{
    $post = kk_post_or_error($post_id);
    if ($post instanceof WP_Error || $post->post_type !== kk_popup_post_type()) {
        return $post;
    }
    return new WP_Error(
        'kirki_unsupported_post_type',
        sprintf(
            /* translators: %d: post id */
            __(
                'Post %d is a Kirki popup: popups store a flat node map without `root` → `body` and keep their trigger settings on the `popup` element, so the page writers would destroy it. Read it with kirki-get-content and write it with kirki-set-popup-content / kirki-edit-popup-settings / kirki-delete-popup.',
                domain: 'novamira-pro',
            ),
            $post->ID,
        ),
        ['status' => 422],
    );
}

/**
 * Error for a post whose type these page abilities never read or write:
 * symbols and the global-data post store a different shape under the same
 * meta key (writing a page tree there destroys the header / footer or every
 * variable), a collection stores field definitions (its own abilities), and
 * everything else is simply not covered.
 */
function kk_unsupported_post_type(WP_Post $post): WP_Error
{
    $hint = match ($post->post_type) {
        kk_symbol_post_type() => __(
            'It is a Kirki symbol (header / footer / component): read it with kirki-get-symbol / kirki-list-symbols and write it with kirki-create-symbol, kirki-set-symbol-content, kirki-set-symbol-as, kirki-delete-symbol; a symbol stores a flat node map, not a page tree.',
            domain: 'novamira-pro',
        ),
        kk_global_data_post_type() => __(
            'It is the Kirki global-data post: read it with kirki-get-variables; it is never written by these abilities.',
            domain: 'novamira-pro',
        ),
        kk_collection_post_type() => __(
            'It is a Content Manager collection (a schema of typed fields, no block tree): read it with kirki-get-collection / kirki-list-collections and write it with kirki-create-collection, kirki-edit-collection, kirki-delete-collection; its items are handled by kirki-list-collection-items and the item abilities.',
            domain: 'novamira-pro',
        ),
        default => __(
            'The page abilities cover pages, posts, public custom post types, templates and utility pages (the kinds kirki-list-pages lists); popups have their own writers (kirki-create-popup, kirki-set-popup-content, kirki-edit-popup-settings, kirki-delete-popup), collections and their items too (kirki-create-collection, kirki-create-collection-item, …).',
            domain: 'novamira-pro',
        ),
    };
    return new WP_Error(
        'kirki_unsupported_post_type',
        sprintf(
            /* translators: 1: post id, 2: post type, 3: hint */
            __('Post %1$d has post type `%2$s`, which these abilities do not handle. %3$s', domain: 'novamira-pro'),
            $post->ID,
            $post->post_type,
            $hint,
        ),
        ['status' => 422],
    );
}

/**
 * A live `kirki_template` post, or the error naming what the post is instead
 * (the template abilities write conditions nowhere else).
 */
function kk_template_post_or_error(int $post_id): WP_Post|WP_Error
{
    $post = kk_post_or_error($post_id);
    if ($post instanceof WP_Error) {
        return $post;
    }
    if ($post->post_type === kk_content_post_types()['template']) {
        return $post;
    }
    return new WP_Error(
        'kirki_unsupported_post_type',
        sprintf(
            /* translators: 1: post id, 2: post type */
            __(
                'Post %1$d has post type `%2$s`; display conditions exist on Kirki templates (`kirki_template`) only. Create one with kirki-create-page kind=template, or list them with kirki-list-templates.',
                domain: 'novamira-pro',
            ),
            $post->ID,
            $post->post_type,
        ),
        ['status' => 422],
    );
}

// ---------------------------------------------------------------------------
// Tables.
// ---------------------------------------------------------------------------

/**
 * Presence of each Kirki custom table, keyed by unprefixed name.
 *
 * @return array<string, bool>
 */
function kk_tables_present(): array
{
    global $wpdb;
    /** @var \wpdb $wpdb */
    $out = [];
    foreach (KK_TABLES as $table) {
        $full = $wpdb->prefix . $table;
        // `wp_2_` prefixes carry `_` (a LIKE wildcard): escape so only the exact name matches.
        $sql = (string) $wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($full));
        /** @var mixed $found */
        $found = $wpdb->get_var($sql);
        $out[$table] = is_string($found) && $found === $full;
    }
    return $out;
}

// ---------------------------------------------------------------------------
// Errors and coercion.
// ---------------------------------------------------------------------------

function kk_invalid_post(int $post_id): WP_Error
{
    return new WP_Error(
        'kirki_invalid_post',
        sprintf(
            /* translators: %d: post id */
            __('Post %d does not exist, is trashed, or is an auto-draft / revision.', domain: 'novamira-pro'),
            $post_id,
        ),
        ['status' => 404],
    );
}

function kk_not_kirki_mode(int $post_id): WP_Error
{
    return new WP_Error(
        'kirki_not_kirki_mode',
        sprintf(
            /* translators: %d: post id */
            __(
                'Post %d is not in Kirki editor mode (Kirki never saved it, or the user switched it back to the WordPress editor): the frontend shows the WordPress content, not a block tree. Use kirki-list-pages to find Kirki-owned content.',
                domain: 'novamira-pro',
            ),
            $post_id,
        ),
        ['status' => 400],
    );
}

function kk_invalid_input(string $message): WP_Error
{
    return new WP_Error('kirki_invalid_input', $message, ['status' => 400]);
}

/** Integer coercion for JSON-ish input; null when not an integer-looking value. */
// @mago-expect lint:halstead -- int, integral float, numeric string: three flat branches
function kk_coerce_int_or_null(mixed $value): ?int
{
    if (is_int($value)) {
        return $value;
    }
    if (is_float($value) && floor($value) === $value) {
        return (int) $value;
    }
    if (is_string($value) && is_numeric($value)) {
        // Same acceptance as the schema validator (`rest_is_integer`): "5", "5.0", " 5".
        $number = (float) $value;
        if (floor($number) === $number && abs($number) < PHP_INT_MAX) {
            return (int) $number;
        }
    }
    return null;
}

/** Clamp a `limit` input into `[1, KK_LIST_HARD_MAX]`, defaulting when absent. */
function kk_clamp_limit(mixed $value, int $default): int
{
    $int = kk_coerce_int_or_null($value) ?? $default;
    return min(KK_LIST_HARD_MAX, max(1, $int));
}

// ---------------------------------------------------------------------------
// Tree sources. The published tree lives in the base meta keys; every other
// version lives in `kirki_stage_data`, keyed by the SAME meta key under its
// version's row (`PageMetaKeys::get_stage_content_keys()`). The published
// version keeps a snapshot copy in its own row as well, which Kirki refreshes
// on every publish. The editor's Save writes the highest version's row;
// Publish fills any empty published key from that row
// (`promote_stage_version_data`), flips `is_published` and re-snapshots.
//
// `PageManager::get_staged_meta_name()` still builds a `staged_<v>_<meta>` key,
// but it is deprecated upstream with the note that it "points to nothing".
// ---------------------------------------------------------------------------

/**
 * Read `$meta` for the requested version from whichever store owns it.
 *
 * Returns the value, not a key: since Kirki 6.4.0 only the published version is
 * reachable by a meta key, so there is no key that would name a staged source.
 *
 * @return array{value: mixed, kind: string, version: int|null}|WP_Error
 */
function kk_versioned_meta_value(int $post_id, string $meta, ?int $version): array|WP_Error
{
    $ledger = kk_staging_info($post_id);
    if ($version === null || $version === $ledger['published_version']) {
        return [
            'value' => kk_meta($post_id, $meta),
            'kind' => 'published',
            'version' => $ledger['published_version'],
        ];
    }
    if (!kk_staging_version_exists($post_id, $version)) {
        return kk_invalid_input(sprintf(
            /* translators: 1: version number, 2: post id */
            __(
                'Staging version %1$d does not exist on post %2$d. List versions with kirki-list-pages (staging.versions).',
                domain: 'novamira-pro',
            ),
            $version,
            $post_id,
        ));
    }
    return ['value' => kk_version_value($post_id, $meta, $version), 'kind' => 'staged', 'version' => $version];
}

/** Whether the staging ledger of the post lists `$version`. */
function kk_staging_version_exists(int $post_id, int $version): bool
{
    foreach (kk_ledger($post_id) as $entry) {
        if ($entry['version'] === $version) {
            return true;
        }
    }
    return false;
}

/**
 * Block map of a post for the published tree (`$version === null`) or a staged
 * version. Null when that source holds no tree.
 *
 * @return array{blocks: array<string, mixed>|null, kind: string, version: int|null}|WP_Error
 */
function kk_blocks_for_version(int $post_id, ?int $version): array|WP_Error
{
    $resolved = kk_versioned_meta_value($post_id, kk_meta_blocks(), $version);
    if ($resolved instanceof WP_Error) {
        return $resolved;
    }
    /** @var mixed $data */
    $data = $resolved['value'];
    $blocks = null;
    /** @var mixed $raw */
    $raw = is_array($data) && array_key_exists('blocks', $data) ? $data['blocks'] : $data;
    if (is_array($raw) && (is_array($data) && array_key_exists('blocks', $data) || kk_is_flat_node_map($raw))) {
        // `{blocks: map}` for pages, the flat map for popups (see kk_blocks_of).
        $shape = kk_blocks_shape_error($raw);
        if ($shape !== null) {
            return new WP_Error('kirki_corrupt_tree', $shape, ['status' => 422]);
        }
        /** @var array<string, mixed> $blocks */
        $blocks = $raw;
    }
    return ['blocks' => $blocks, 'kind' => $resolved['kind'], 'version' => $resolved['version']];
}

/**
 * Page-local style blocks (`id => block`) for the published tree or a staged
 * version. Empty array when none.
 *
 * @return array<string, array<string, mixed>>|WP_Error
 */
function kk_style_blocks_for_version(int $post_id, ?int $version): array|WP_Error
{
    $resolved = kk_versioned_meta_value($post_id, kk_meta_style_blocks(), $version);
    if ($resolved instanceof WP_Error) {
        return $resolved;
    }
    /** @var mixed $data */
    $data = $resolved['value'];
    if (!is_array($data)) {
        return [];
    }
    $out = [];
    /** @var mixed $block */
    foreach ($data as $id => $block) {
        if (!is_string($id) || !is_array($block)) {
            continue;
        }
        /** @var array<string, mixed> $block */
        $out[$id] = $block;
    }
    return $out;
}

/**
 * The two site-wide style-block maps on the global-data post: the class-manager
 * map (`kirki_class_manager_style_blocks`) and the legacy one
 * (`kirki_global_style_block`). Read fresh on every call (Kirki's editor writes
 * them through its ORM without touching the object cache).
 *
 * @return array{class_manager: array<string, array<string, mixed>>, deprecated: array<string, array<string, mixed>>}
 */
function kk_global_style_maps(): array
{
    return [
        'class_manager' => kk_style_map_of(kk_global_data(kk_const(
            'GlobalDataKeys',
            name: 'STYLE_BLOCKS',
            fallback: 'kirki_class_manager_style_blocks',
        ))),
        'deprecated' => kk_style_map_of(kk_global_data(kk_const(
            'GlobalDataKeys',
            name: 'STYLE_BLOCK_DEPRECATED',
            fallback: 'kirki_global_style_block',
        ))),
    ];
}

/**
 * @return array<string, array<string, mixed>>
 */
function kk_style_map_of(mixed $raw): array
{
    return is_array($raw) ? kk_style_map($raw) : [];
}

/**
 * Style blocks in effect for one read of a post, exactly as
 * `PageManager::get_page_styleblocks()` assembles them:
 *  - the PUBLISHED read (`$version === null`) always takes Kirki's "legacy"
 *    path (the flag is looked up for version 0): base local map ∪ deprecated
 *    global map, then — when a published version exists — the HIGHEST
 *    version's maps (deprecated + local) are merged in with
 *    precedence: a base block whose name collides with one of them is renamed
 *    `<name>_1`, an id only in that staged map renders too;
 *  - a staged read of a version flagged `no_legacy_global_style`: that
 *    version's local map (the base map when it is the published version);
 *  - a staged read of an unflagged version: base ∪ deprecated, with that
 *    version's staged maps merged in (colliding staged names renamed `_1`);
 *  - finally local names colliding with a class-manager name are renamed
 *    `<name>-copy` and the class-manager map is merged (its ids win).
 * Only STRING names take part in collisions (`extract_class_names`), array
 * (combo) names never rename or get renamed. Returned names are the rendered
 * ones; `renamed` lists ids whose name the renderer changed.
 *
 * @param array<string, array<string, mixed>> $local the map read for the requested version
 * @return array{map: array<string, array<string, mixed>>, renamed: list<string>}
 */
function kk_effective_style_info(int $post_id, ?int $version, array $local): array
{
    $maps = kk_global_style_maps();
    $global = $maps['class_manager'];
    $deprecated = $maps['deprecated'];
    $ledger = kk_ledger($post_id);
    $published = kk_published_version($post_id);
    $highest = 0;
    $flagged = false;
    $seen = false;
    foreach ($ledger as $entry) {
        $highest = max($highest, $entry['version']);
        if ($seen || $version === null || $entry['version'] !== $version) {
            continue;
        }
        // Kirki takes the FIRST ledger entry with that version.
        $flagged = $entry['no_legacy_global_style'];
        $seen = true;
    }
    $base = $version === null ? $local : kk_style_map_of(kk_meta($post_id, kk_meta_style_blocks()));
    $legacy = $version === null || !$flagged;
    if (!$legacy) {
        $current = $version === $published ? $base : $local;
        return kk_merge_with_global($current, $global, $current);
    }
    $current = kk_rename_duplicates($base, $deprecated);
    $merged = $current;
    foreach ($deprecated as $id => $block) {
        $merged[$id] = $block;
    }
    if ($published !== null && $version !== $published) {
        $stage = $version ?? $highest;
        // `PageManager::get_page_styleblocks()` reads both maps with
        // `read_page_meta($page_id, KEY, $stage_version, [])` since 6.4.0, which
        // routes the published version to postmeta and the rest to the table.
        $staging = kk_style_map_of(kk_version_value($post_id, kk_meta_global_style_block_deprecated(), $stage));
        foreach (kk_style_map_of(kk_version_value($post_id, kk_meta_style_blocks(), $stage)) as $id => $block) {
            $staging[$id] = $block;
        }
        $originals = $merged + $staging;
        $merged = $version !== null
            ? kk_merge_style_blocks($merged, $staging)
            : kk_merge_style_blocks($staging, $merged);
        return kk_merge_with_global($merged, $global, $originals);
    }
    return kk_merge_with_global($merged, $global, $merged);
}

/**
 * The effective map only (see kk_effective_style_info()).
 *
 * @param array<string, array<string, mixed>> $local
 * @return array<string, array<string, mixed>>
 */
function kk_effective_styles(int $post_id, ?int $version, array $local): array
{
    return kk_effective_style_info($post_id, $version, $local)['map'];
}

/**
 * Last step of Kirki's assembly: page blocks colliding with a class-manager
 * name get `-copy`, then the class-manager map is merged (its ids win).
 *
 * @param array<string, array<string, mixed>> $current
 * @param array<string, array<string, mixed>> $global
 * @param array<string, array<string, mixed>> $originals the page blocks with their STORED names (before any renaming)
 * @return array{map: array<string, array<string, mixed>>, renamed: list<string>}
 */
function kk_merge_with_global(array $current, array $global, array $originals): array
{
    $before = [];
    foreach ($originals as $id => $block) {
        $before[$id] = $block['name'] ?? null;
    }
    $map = kk_merge_style_blocks(kk_rename_duplicates($current, $global), $global);
    $renamed = [];
    foreach ($map as $id => $block) {
        if (!array_key_exists($id, $before) || ($block['name'] ?? null) === $before[$id]) {
            continue;
        }
        $renamed[] = $id;
    }
    return ['map' => $map, 'renamed' => $renamed];
}

/**
 * Kirki's collision key of a style-block name (`normalize_style_block_name`).
 */
function kk_style_name_key(string $name): string
{
    return strtolower(str_replace(search: ' ', replace: '-', subject: trim($name)));
}

/**
 * Collision keys of the STRING names in a map (`extract_class_names`: array names are ignored).
 *
 * @param array<string, array<string, mixed>> $blocks
 * @return array<string, true>
 */
function kk_string_name_keys(array $blocks): array
{
    $keys = [];
    foreach ($blocks as $block) {
        if (!isset($block['name']) || !is_string($block['name'])) {
            continue;
        }
        $keys[kk_style_name_key($block['name'])] = true;
    }
    return $keys;
}

/**
 * `resolve_duplicate_current_style_block_names`: page blocks whose string
 * name collides with a global string name are renamed `<name>-copy`
 * (`-copy_2`, … when taken); array names holding the same entry follow.
 *
 * @param array<string, array<string, mixed>> $current
 * @param array<string, array<string, mixed>> $global
 * @return array<string, array<string, mixed>>
 */
function kk_rename_duplicates(array $current, array $global): array
{
    $global_keys = kk_string_name_keys($global);
    $current_keys = kk_string_name_keys($current);
    $map = [];
    foreach (array_intersect_key($current_keys, $global_keys) as $key => $_) {
        $counter = 1;
        do {
            $candidate = $counter === 1 ? $key . '-copy' : $key . '-copy_' . $counter;
            ++$counter;
        } while (isset($global_keys[$candidate]) || isset($current_keys[$candidate]));
        $map[$key] = $candidate;
    }
    if ($map === []) {
        return $current;
    }
    foreach ($current as $id => $block) {
        /** @var mixed $name */
        $name = $block['name'] ?? null;
        if (is_string($name) && isset($map[kk_style_name_key($name)])) {
            $current[$id]['name'] = $map[kk_style_name_key($name)];
            continue;
        }
        if (!is_array($name)) {
            continue;
        }
        $current[$id]['name'] = array_map(static fn(mixed $entry): mixed => is_string($entry)
            && isset($map[kk_style_name_key($entry)])
                ? $map[kk_style_name_key($entry)]
                : $entry, $name);
    }
    return $current;
}

/**
 * `PageManager::merge_style_blocks`: `$new` blocks are merged over `$old`
 * (same id: new wins); a new block whose STRING name already exists in the
 * old map is renamed `<name>_1` (`_2`, …), array names holding that entry
 * follow.
 *
 * @param array<string, array<string, mixed>> $old
 * @param array<string, array<string, mixed>> $new
 * @return array<string, array<string, mixed>>
 */
function kk_merge_style_blocks(array $old, array $new): array
{
    $old_keys = kk_string_name_keys($old);
    $new_keys = kk_string_name_keys($new);
    foreach ($new as $id => $block) {
        /** @var mixed $name */
        $name = $block['name'] ?? null;
        if (!is_string($name) || $name === '') {
            continue;
        }
        $key = strtolower($name);
        if (isset($old[$id])) {
            unset($old[$id], $old_keys[$key]);
        }
        if (!isset($old_keys[$key])) {
            continue;
        }
        $suffix = 1;
        while (isset($old_keys[$key . '_' . $suffix]) || isset($new_keys[$key . '_' . $suffix])) {
            ++$suffix;
        }
        $renamed = $name . '_' . $suffix;
        foreach ($new as $other_id => $other) {
            if (!isset($other['name']) || !is_array($other['name'])) {
                continue;
            }
            $new[$other_id]['name'] = array_map(static fn(mixed $entry): mixed => $entry === $name
                ? $renamed
                : $entry, $other['name']);
        }
        $new[$id]['name'] = $renamed;
        unset($new_keys[$key]);
        $new_keys[strtolower($renamed)] = true;
    }
    foreach ($new as $id => $block) {
        $old[$id] = $block;
    }
    return $old;
}

/**
 * Id of the tree root: `root` when present (pages, popups), else `body`
 * (templates), else the first node without a parent.
 *
 * @param array<string, mixed> $blocks
 */
function kk_root_id(array $blocks): ?string
{
    if (isset($blocks['root'])) {
        return 'root';
    }
    if (isset($blocks['body'])) {
        return 'body';
    }
    /** @var mixed $node */
    foreach ($blocks as $id => $node) {
        if (!is_array($node)) {
            continue;
        }
        if (!isset($node['parentId'])) {
            return $id;
        }
    }
    // Popups: the `popup` element points at a `root` that is not stored
    // (Kirki selects popups by `parentId === 'root'`).
    /** @var mixed $node */
    foreach ($blocks as $id => $node) {
        if (is_array($node) && is_string($node['parentId'] ?? null) && !isset($blocks[$node['parentId']])) {
            return $id;
        }
    }
    return null;
}

/**
 * Human-readable class list of a node in the renderer's order: free-form
 * `className` tokens first, then the names of its style blocks
 * (`properties.classesIds`, then `styleIds`) resolved against the EFFECTIVE
 * map (page-local + global, see kk_effective_styles). Unknown ids are reported as `?<id>` so a dangling
 * reference is visible instead of silently dropped (the renderer drops them).
 *
 * @param array<string, mixed> $node
 * @param array<string, array<string, mixed>> $styles effective map
 * @return list<string>
 */
// @mago-expect lint:cyclomatic-complexity -- className, classesIds, styleIds, inline marker: flat guards
function kk_node_classes(array $node, array $styles): array
{
    $out = [];
    $ids = [];
    if (
        isset($node['properties'])
        && is_array($node['properties'])
        && isset($node['properties']['classesIds'])
        && is_array($node['properties']['classesIds'])
    ) {
        $ids = array_merge($ids, array_values($node['properties']['classesIds']));
    }
    if (isset($node['styleIds']) && is_array($node['styleIds'])) {
        $ids = array_merge($ids, array_values($node['styleIds']));
    }
    /** @var mixed $id */
    foreach ($ids as $id) {
        if (!is_string($id)) {
            continue;
        }
        if (!isset($styles[$id])) {
            $out[] = '?' . $id;
            continue;
        }
        foreach (kk_style_block_class_list($styles[$id]) as $class) {
            $out[] = $class;
        }
    }
    // The renderer puts `className` tokens first (`getClassNames`: className,
    // then classesIds, then styleIds) and appends `kirki-inline-element` to
    // its inline elements (`Preview::$inline_elements`: button, link-block, link-text).
    if (in_array($node['name'] ?? null, KK_RENDERER_INLINE_ELEMENTS, strict: true)) {
        $out[] = 'kirki-inline-element';
    }
    $free = [];
    if (isset($node['className']) && is_string($node['className']) && trim($node['className']) !== '') {
        $parts = preg_split('/\s+/', trim($node['className']));
        if (is_array($parts)) {
            foreach ($parts as $cls) {
                $free[] = strtolower($cls);
            }
        }
    }
    return array_values(array_merge($free, $out));
}

/**
 * The class names a style block puts on an element, exactly as the renderer
 * emits them (`HelperFunctions::add_prefix_to_class_name` +
 * `get_class_name_from_string`): each `name` entry lower-cased with spaces
 * turned into `-`, so the combo name `["k z0zfgqqw"]` is ONE class
 * `k-z0zfgqqw`, and `["k one", "k two"]` two classes.
 *
 * @param array<string, mixed> $block
 * @return list<string>
 */
function kk_style_block_class_list(array $block): array
{
    /** @var mixed $name */
    $name = $block['name'] ?? '';
    $entries = is_string($name) ? [$name] : kk_string_list_of($name);
    $out = [];
    foreach ($entries as $entry) {
        if (trim($entry) === '') {
            continue;
        }
        // The renderer does not trim: `" a"` becomes the class `-a`.
        $out[] = strtolower(str_replace(search: ' ', replace: '-', subject: $entry));
    }
    return $out;
}

/**
 * Display name of a style block: its rendered class names joined by a space
 * (one entry per class the element actually carries).
 *
 * @param array<string, mixed> $block
 */
function kk_style_block_name(array $block): string
{
    return implode(' ', kk_style_block_class_list($block));
}

/**
 * @return list<string>
 */
function kk_string_list_of(mixed $value): array
{
    if (!is_array($value)) {
        return [];
    }
    $out = [];
    /** @var mixed $item */
    foreach ($value as $item) {
        if (!is_string($item)) {
            continue;
        }
        $out[] = $item;
    }
    return $out;
}

/**
 * Plain text of a node as the renderer prints it: for leaves, the strings of
 * `properties.contents` in order with `{id}` entries (inline children such as
 * `bold`) resolved recursively, skipping hidden ones; for nodes that carry
 * `children` (containers, buttons, links) the renderer ignores `contents`, so
 * the text is that of their text-element descendants in order. Inline nesting
 * deeper than 25 levels, a node met twice (stored cycle) or more than 5000
 * nodes are cut with `…`.
 *
 * @param array<string, mixed> $node
 * @param array<string, mixed> $blocks
 */
// @mago-expect lint:cyclomatic-complexity -- container vs leaf paths, each a flat loop
function kk_node_text(array $node, array $blocks, int $depth = 0, array &$visited = []): string
{
    if ($depth > 25 || count($visited) > 5000) {
        return '…';
    }
    // A stored cycle (`body.children = [body, body]`) is otherwise walked
    // branching^25 times; each node contributes its text once.
    /** @var mixed $node_id */
    $node_id = $node['id'] ?? null;
    if (is_string($node_id)) {
        if (isset($visited[$node_id])) {
            return '…';
        }
        $visited[$node_id] = true;
    }
    if (array_key_exists('children', $node)) {
        $out = '';
        foreach (kk_node_child_ids($node) as $child_id) {
            if (!isset($blocks[$child_id]) || !is_array($blocks[$child_id])) {
                continue;
            }
            /** @var array<string, mixed> $child */
            $child = $blocks[$child_id];
            if (($child['hide'] ?? false) === true) {
                continue;
            }
            $out .= kk_node_text($child, $blocks, $depth + 1, $visited);
        }
        return $out;
    }
    if (!isset($node['properties']) || !is_array($node['properties'])) {
        return '';
    }
    /** @var mixed $contents */
    $contents = $node['properties']['contents'] ?? null;
    if (is_string($contents)) {
        return $contents;
    }
    if (!is_array($contents)) {
        return '';
    }
    $out = '';
    /** @var mixed $part */
    foreach ($contents as $part) {
        if (is_string($part)) {
            $out .= $part;
            continue;
        }
        if (!is_array($part) || !isset($part['id']) || !is_string($part['id'])) {
            continue;
        }
        if (!isset($blocks[$part['id']]) || !is_array($blocks[$part['id']])) {
            continue;
        }
        /** @var array<string, mixed> $child */
        $child = $blocks[$part['id']];
        if (($child['hide'] ?? false) === true) {
            continue;
        }
        $out .= kk_node_text($child, $blocks, $depth + 1, $visited);
    }
    return $out;
}

/** Truncate a UTF-8 string to `$max` characters with an ellipsis marker. */
function kk_truncate(string $text, int $max): string
{
    if ($max <= 0) {
        return '';
    }
    if (mb_strlen($text) <= $max) {
        return $text;
    }
    return mb_substr($text, start: 0, length: $max) . '…';
}

/**
 * Ordered child ids of a node (containers only; leaves have no `children`).
 *
 * @param array<string, mixed> $node
 * @return list<string>
 */
function kk_node_child_ids(array $node): array
{
    $out = [];
    if (!isset($node['children']) || !is_array($node['children'])) {
        return $out;
    }
    /** @var mixed $child */
    foreach ($node['children'] as $child) {
        if (!is_string($child)) {
            continue;
        }
        $out[] = $child;
    }
    return $out;
}

/**
 * Layer title of a node: the user-set `customTitle` wins over the element's
 * default `title`.
 *
 * @param array<string, mixed> $node
 */
function kk_node_title(array $node): string
{
    /** @var mixed $custom */
    $custom = $node['customTitle'] ?? null;
    if (is_string($custom) && $custom !== '') {
        return $custom;
    }
    /** @var mixed $title */
    $title = $node['title'] ?? '';
    return is_string($title) ? $title : '';
}

/**
 * HTML tag of a node (`properties.tag`), or null when unset.
 *
 * @param array<string, mixed> $node
 */
function kk_node_tag(array $node): ?string
{
    if (!isset($node['properties']) || !is_array($node['properties'])) {
        return null;
    }
    /** @var mixed $tag */
    $tag = $node['properties']['tag'] ?? null;
    return is_string($tag) ? $tag : null;
}

/**
 * Font family names the page declares (`kirki_used_font_list`), for the
 * published tree or a staged version. Empty when the version is unknown.
 *
 * @return list<string>
 */
function kk_fonts_for_version(int $post_id, ?int $version): array
{
    $resolved = kk_versioned_meta_value(
        $post_id,
        kk_const('PageMetaKeys', name: 'USED_FONT_LIST', fallback: 'kirki_used_font_list'),
        $version,
    );
    if ($resolved instanceof WP_Error) {
        return [];
    }
    /** @var mixed $raw */
    $raw = $resolved['value'];
    $out = [];
    if (!is_array($raw)) {
        return $out;
    }
    /** @var mixed $font */
    foreach ($raw as $font) {
        if (!is_string($font)) {
            continue;
        }
        $out[] = $font;
    }
    return $out;
}

function kk_unknown_node(string $id): WP_Error
{
    if ($id === '') {
        return kk_invalid_input(__('A node id is required (non-empty string).', domain: 'novamira-pro'));
    }
    return kk_invalid_input(sprintf(
        /* translators: %s: node id */
        __('Node `%s` does not exist in this tree.', domain: 'novamira-pro'),
        kk_short($id),
    ));
}

/**
 * A site-data value bounded for agent context: strings longer than `$bytes`
 * are cut with `…`, arrays nested deeper than `$depth` are replaced by the
 * marker `?deep` (PHP cannot JSON-encode past 512 levels and WordPress then
 * returns `{}`), everything else is returned as is.
 */
function kk_bound_value(mixed $value, int $depth = 8, int $bytes = 2000): mixed
{
    if (is_string($value)) {
        return kk_bound_string($value, $bytes);
    }
    if (!is_array($value)) {
        return $value;
    }
    if ($depth <= 0) {
        return '?deep';
    }
    $out = [];
    /** @var mixed $item */
    foreach ($value as $key => $item) {
        $out[$key] = kk_bound_value($item, $depth - 1, $bytes);
    }
    return $out;
}

/** A string cut to `$bytes` (UTF-8 safe) with `…` appended when it was longer. */
function kk_bound_string(string $value, int $bytes): string
{
    if (strlen($value) <= $bytes) {
        return $value;
    }
    return mb_strcut($value, start: 0, length: max($bytes - 3, 1)) . '…';
}

/** An id or token shortened for an error message (control characters replaced, 80 chars max). */
function kk_short(string $value): string
{
    $value = preg_replace('/[\x00-\x1F\x7F]/', replacement: '?', subject: $value) ?? $value;
    return strlen($value) > 80 ? mb_strcut($value, start: 0, length: 77) . '…' : $value;
}

// ---------------------------------------------------------------------------
// Site structure: templates, symbols, global variables (read side).
// ---------------------------------------------------------------------------

/** Meta key of the global variables / saved editor data (`GlobalDataKeys::UI_SAVED_DATA`). */
function kk_meta_global_saved_data(): string
{
    return kk_const('GlobalDataKeys', name: 'UI_SAVED_DATA', fallback: 'kirki_user_saved_data');
}

/** Meta key of the template collection type (`PageMetaKeys::TEMPLATE_COLLECTION_TYPE`). */
function kk_meta_template_collection_type(): string
{
    return kk_const('PageMetaKeys', name: 'TEMPLATE_COLLECTION_TYPE', fallback: 'kirki_template_collection_type');
}

/**
 * The window and where it came from: `fetch_list` (the resolver Kirki 6.3.0
 * still calls, `@deprecated` in favour of `PageService::paginated()`), else
 * `PageFilterDTO::$limit` (the successor's default), else the 6.3.0 literal.
 *
 * @return array{window: int, source: string}
 */
function kk_template_resolution_window_info(): array
{
    if (class_exists('Kirki\Ajax\Page') && method_exists('Kirki\Ajax\Page', 'fetch_list')) {
        try {
            $method = new \ReflectionMethod('Kirki\Ajax\Page', 'fetch_list');
            foreach ($method->getParameters() as $param) {
                if ($param->getName() !== 'numberposts' || !$param->isDefaultValueAvailable()) {
                    continue;
                }
                $default = kk_coerce_int_or_null($param->getDefaultValue());
                if ($default !== null && $default > 0) {
                    return ['window' => $default, 'source' => 'Kirki\Ajax\Page::fetch_list'];
                }
            }
        } catch (\ReflectionException $ignored) {
            unset($ignored); // fall through to the successor's default
        }
    }
    $dto = 'Kirki\App\DTO\Page\PageFilterDTO';
    if (class_exists($dto)) {
        try {
            /** @var mixed $limit */
            $limit = (new \ReflectionClass($dto))->getDefaultProperties()['limit'] ?? null;
            $default = kk_coerce_int_or_null($limit);
            if ($default !== null && $default > 0) {
                return ['window' => $default, 'source' => $dto . '::$limit'];
            }
        } catch (\ReflectionException $ignored) {
            unset($ignored); // fall through to the literal
        }
    }
    return ['window' => 20, 'source' => 'fallback'];
}

/**
 * Normalise one template display condition the way
 * `HelperFunctions::check_all_conditions_for_this_post()` does before matching:
 * legacy `category` becomes `type` / `post_type`, `from` defaults to `post`,
 * `visibility` to `show`. `effective` is false (with a `note`) when Kirki's
 * matcher can never act on the entry as stored: a visibility other than
 * `show` / `hide`, a `single` target that is not an integer (the matcher
 * compares `to === $post->ID` strictly), or an unknown `type`.
 *
 * @param array<array-key, mixed> $raw
 * @return array{from: string, type: ?string, post_type: ?string, where: mixed, to: mixed, visibility: mixed, effective: bool, note: ?string, summary: string}
 */
function kk_normalize_condition(array $raw): array
{
    $from = isset($raw['from']) && is_string($raw['from']) ? $raw['from'] : 'post';
    $type = isset($raw['type']) && is_string($raw['type']) ? $raw['type'] : null;
    $post_type = isset($raw['post_type']) && is_string($raw['post_type']) ? $raw['post_type'] : null;
    if (isset($raw['category']) && is_string($raw['category'])) {
        $type = $raw['category'] === '*' ? '*' : 'post';
        $post_type = $raw['category'] === '*' ? $post_type : $raw['category'];
    }
    /** @var mixed $visibility */
    $visibility = $raw['visibility'] ?? 'show'; // Kirki: `isset()`, so null means show
    $condition = [
        'from' => $from,
        'type' => $type,
        'post_type' => $post_type,
        'where' => $raw['where'] ?? null,
        'to' => $raw['to'] ?? null,
        'visibility' => $visibility,
    ];
    $condition['note'] = kk_condition_note($condition);
    $condition['effective'] = $condition['note'] === null;
    $condition['summary'] = kk_condition_summary($condition);
    return $condition;
}

/**
 * Why Kirki's matcher would ignore a condition as stored, or null.
 *
 * @param array{from: string, type: ?string, post_type: ?string, where: mixed, to: mixed, visibility: mixed} $c
 */
// @mago-expect lint:cyclomatic-complexity -- one rule per case of Kirki's condition matcher
function kk_condition_note(array $c): ?string
{
    if ($c['visibility'] !== 'show' && $c['visibility'] !== 'hide') {
        return 'weak hide: a visibility other than `show` / `hide` cancels a match recorded earlier in the list and never records one';
    }
    if ($c['type'] === 'user') {
        return 'author-archive contexts only: `type: user` entries are skipped on posts and term archives';
    }
    if ($c['type'] !== '*' && $c['type'] !== 'post') {
        return 'ignored: type must be `*`, `post` or `user`';
    }
    if ($c['type'] === 'post' && $c['where'] === 'single' && !is_int($c['to'])) {
        return 'never matches: a `single` target must be an integer post id (Kirki compares it strictly)';
    }
    if ($c['type'] === 'post' && !is_string($c['post_type'])) {
        return 'never matches: `type: post` needs a `post_type` string';
    }
    if ($c['type'] === 'post' && !post_type_exists($c['post_type'])) {
        return sprintf(
            'never matches: post type `%s` is not registered (a deleted Content Manager collection?); the template still takes a slot of the resolution window',
            $c['post_type'],
        );
    }
    if ($c['type'] === 'post' && $c['where'] !== null && !is_string($c['where'])) {
        return 'loose match: a non-string `where` is compared with `==`, so `true` behaves like `*` (every post of the type)';
    }
    if ($c['from'] === 'term') {
        return 'on posts this entry makes the WHOLE template never match; it is evaluated on term and author archives only';
    }
    return null;
}

/**
 * One-line reading of a normalised condition, e.g. `show: post all (post)`.
 *
 * @param array{from: string, type: ?string, post_type: ?string, where: mixed, to: mixed, visibility: mixed, note: ?string, effective?: bool} $c
 */
function kk_condition_summary(array $c): string
{
    $summary = kk_condition_scope_summary($c);
    return $c['note'] === null ? $summary : $summary . ' [' . $c['note'] . ']';
}

/**
 * @param array{from: string, type: ?string, post_type: ?string, where: mixed, to: mixed, visibility: mixed, note?: ?string, effective?: bool} $c
 */
function kk_condition_scope_summary(array $c): string
{
    $scalar = static fn(mixed $v): string => is_scalar($v)
        ? kk_truncate((string) $v, max: 120)
        : '[' . gettype($v) . ']';
    $visibility = $scalar($c['visibility']);
    if ($c['type'] === '*') {
        return sprintf('%s: entire site', $visibility);
    }
    if ($c['type'] === 'user') {
        return sprintf(
            '%s: author archives %s',
            $visibility,
            $c['where'] === 'role' ? 'of role ' . $scalar($c['to']) : 'all',
        );
    }
    if ($c['type'] !== 'post') {
        return sprintf('%s: unknown type %s', $visibility, $scalar($c['type']));
    }
    $scope = match (true) {
        $c['where'] === '*' => 'all',
        $c['where'] === 'single' => 'single #' . $scalar($c['to']),
        default => sprintf('%s = %s', $scalar($c['where']), $scalar($c['to'])),
    };
    return sprintf('%s: %s %s (%s)', $visibility, $c['post_type'] ?? '?', $scope, $c['from']);
}

/**
 * The `kirki` meta of a symbol post: `{root, name, data, styleBlocks, category?, setAs?}`
 * (written by `SymbolManager::save()` / `Ajax\Symbol::update`). Null when absent or malformed.
 *
 * @return array<string, mixed>|null
 */
function kk_symbol_meta(int $post_id): ?array
{
    /** @var mixed $meta */
    $meta = kk_meta($post_id, kk_meta_blocks());
    if (!is_array($meta)) {
        return null;
    }
    // Kirki reads `setAs` / `category` from the meta even when `data` is
    // missing or malformed (`Symbol::get_single_symbol`), so keep such metas.
    if (!isset($meta['data']) || !is_array($meta['data'])) {
        $meta['data'] = [];
    }
    /** @var array<string, mixed> $meta */
    return $meta;
}

// ---------------------------------------------------------------------------
// Input coercion and list plumbing shared by the list abilities.
// ---------------------------------------------------------------------------

/** `array_is_list()` for PHP 8.0 (the plugin floor). */
function kk_is_list(array $value): bool
{
    $expected = 0;
    foreach (array_keys($value) as $key) {
        if ($key !== $expected) {
            return false;
        }
        ++$expected;
    }
    return true;
}

/** Boolean coercion with WordPress REST semantics (`"true"`, `1`, `"1"` are true). */
function kk_bool(mixed $value): bool
{
    if (is_bool($value)) {
        return $value;
    }
    if (is_float($value)) {
        return $value !== 0.0;
    }
    if (is_int($value) || is_string($value)) {
        return rest_sanitize_boolean($value);
    }
    return false;
}

/**
 * A Throwable reduced to what the agent needs: class and message with
 * filesystem paths removed (Kirki's own errors embed the full upload path,
 * PHP errors append `called in /abs/path on line N`).
 */
function kk_throwable_summary(\Throwable $e): string
{
    $message = preg_replace(
        '/,? called in \S+ on line \d+/',
        replacement: '',
        subject: $e->getMessage(),
    ) ?? $e->getMessage();
    $message = preg_replace('#(?:/[^\s/:]+){2,}/?#', replacement: '[path]', subject: $message) ?? $message;
    return get_class($e) . ': ' . kk_truncate(trim($message), max: 200);
}

/** Post statuses the abilities list and write to (everything but trash / auto-draft). */
/** Elements the renderer marks with the `kirki-inline-element` class (`Preview::$inline_elements`). */
const KK_RENDERER_INLINE_ELEMENTS = ['button', 'link-block', 'link-text'];

const KK_LIVE_STATUSES = ['publish', 'draft', 'pending', 'private', 'future'];

/**
 * Serialise every write path of one post through a MySQL named lock scoped by
 * database, table prefix, blog and post id (`GET_LOCK`, 5 s), so two abilities
 * never interleave their load → validate → write. Returns the callback's
 * result, or WP_Error when the lock is not obtained in time. Kirki's own
 * editor does not take this lock.
 *
 * MySQL named locks are re-entrant on one connection: a hook fired by the
 * write (save_post, updated_post_meta) that calls a write ability on the SAME
 * post would get the lock again and its write would be overwritten by the
 * outer one when it returns. Such a nested call is refused instead
 * (`kirki_lock_error`); nested writes to OTHER posts are allowed.
 *
 * Kirki's stage migration takes a lock of its OWN, so this one alone does not
 * exclude it: the write also holds the migration lock (kk_with_migration_lock).
 *
 * @template T
 * @param callable(): (T|WP_Error) $callback
 * @return T|WP_Error
 */
function kk_with_post_lock(int $post_id, callable $callback): mixed
{
    return kk_with_lock(
        sprintf('post:%d', $post_id),
        static fn(): mixed => kk_with_migration_lock($post_id, $callback),
        subject: (string) $post_id,
    );
}

/**
 * Hold Kirki's OWN per-post migration lock for the duration of a write.
 *
 * Since 6.4.0 a cron moves a page's staged versions out of `wp_postmeta` into
 * `kirki_stages` / `kirki_stage_data`, and `copy_post_to_tables()` starts by
 * DELETING the rows the tables already hold for that page, because "the old
 * data is the truth". A migration that overlaps one of our writes therefore
 * discards it, and the read-back that verifies the write cannot see the loss:
 * it happens first. The two locks have different names, so ours alone leaves
 * the migration free to start.
 *
 * Taken AFTER the post lock. Kirki never takes ours, so the fixed order cannot
 * deadlock. Named locks count per connection and Kirki's ORM shares `$wpdb`,
 * so a migration this request forces itself (kk_migrate_versions) still gets
 * the lock, and the single release at the end of `migrate_post()` leaves this
 * one holding it.
 *
 * @template T
 * @param callable(): (T|WP_Error) $callback
 * @return T|WP_Error
 */
function kk_with_migration_lock(int $post_id, callable $callback): mixed
{
    global $wpdb;
    /** @var \wpdb $wpdb */
    $name = kk_migration_lock_name($post_id);
    /** @var mixed $got */
    $got = $wpdb->get_var((string) $wpdb->prepare('SELECT GET_LOCK(%s, %d)', $name, 5));
    if ($got === null) {
        return new WP_Error(
            'kirki_lock_error',
            sprintf(
                /* translators: %d: post id */
                __(
                    'The database refused the staging-migration lock for post %d (GET_LOCK failed); nothing was written.',
                    domain: 'novamira-pro',
                ),
                $post_id,
            ),
            ['status' => 500],
        );
    }
    if ((string) $got !== '1') {
        return new WP_Error(
            'kirki_migration_in_progress',
            sprintf(
                /* translators: %d: post id */
                __(
                    'Kirki is moving the staging data of post %d into its tables right now. The write was refused instead of being discarded by that migration; retry in a moment.',
                    domain: 'novamira-pro',
                ),
                $post_id,
            ),
            ['status' => 409],
        );
    }
    try {
        // @mago-expect lint:inline-variable-return
        $result = $callback();
        return $result;
    } finally {
        $wpdb->get_var((string) $wpdb->prepare('SELECT RELEASE_LOCK(%s)', $name));
    }
}

/**
 * The name Kirki locks a post with while it migrates that page's staging data
 * (`PageStageMigrationService::get_post_lock_name()`): `kirki_stage_` plus the
 * first 12 characters of `md5(DB_NAME . $wpdb->prefix)` plus the id. Mirrored
 * because the method is `protected`.
 */
function kk_migration_lock_name(int $post_id): string
{
    global $wpdb;
    /** @var \wpdb $wpdb */
    $db = defined('DB_NAME') ? (string) constant('DB_NAME') : '';
    return 'kirki_stage_' . substr(md5($db . $wpdb->prefix), offset: 0, length: 12) . '_' . $post_id;
}

/**
 * The same lock on an arbitrary subject, for invariants that span more than
 * one post: `role:header` (only one symbol may hold a role), `classes` (the
 * class map plus the trees referencing it). Writers that need both take the
 * OWNER lock first and the post lock second — the fixed order every call site
 * follows, so two of them can never deadlock.
 *
 * @template T
 * @param string $key what is being serialised (`post:12`, `role:header`, …)
 * @param callable(): (T|WP_Error) $callback
 * @param string $subject what the error messages name
 * @return T|WP_Error
 */
function kk_with_lock(string $key, callable $callback, string $subject = ''): mixed
{
    global $wpdb;
    /** @var \wpdb $wpdb */
    $post_id = str_starts_with($key, 'post:') ? (int) substr($key, offset: 5) : 0;
    $label = $subject;
    if ($label === '') {
        $label = $post_id > 0 ? sprintf('post %d', $post_id) : $key;
    }
    $held_key = get_current_blog_id() . ':' . $key;
    if (kk_lock_held($held_key, mark: null)) {
        return new WP_Error(
            'kirki_lock_error',
            sprintf(
                /* translators: %s: what is locked (a post id or a role) */
                __(
                    'A write to %s is already in progress in this request (a hook re-entered the write path); the nested write was refused so the outer one is not lost.',
                    domain: 'novamira-pro',
                ),
                $label,
            ),
            ['status' => 409],
        );
    }
    // Named locks are server-wide: scope by database and table prefix (several
    // installs on one MySQL server), blog and subject.
    $name = kk_lock_name($key);
    $sql = (string) $wpdb->prepare('SELECT GET_LOCK(%s, %d)', $name, 5);
    /** @var mixed $got */
    $got = $wpdb->get_var($sql);
    if ($got === null) {
        return new WP_Error(
            'kirki_lock_error',
            sprintf(
                /* translators: %s: what is locked (a post id or a role) */
                __(
                    'The database refused the write lock for %s (GET_LOCK failed); nothing was written.',
                    domain: 'novamira-pro',
                ),
                $label,
            ),
            ['status' => 500],
        );
    }
    if ((string) $got !== '1') {
        return new WP_Error(
            'kirki_lock_timeout',
            sprintf(
                /* translators: %s: what is locked (a post id or a role) */
                __('Another write to %s is in progress; retry in a moment.', domain: 'novamira-pro'),
                $label,
            ),
            ['status' => 409],
        );
    }
    kk_lock_held($held_key, mark: true);
    try {
        // @mago-expect lint:inline-variable-return
        $result = $callback();
        return $result;
    } finally {
        kk_lock_held($held_key, mark: false);
        $release = (string) $wpdb->prepare('SELECT RELEASE_LOCK(%s)', $name);
        $wpdb->get_var($release);
    }
}

/** The GET_LOCK name of a post. */
function kk_post_lock_name(int $post_id): string
{
    return kk_lock_name(sprintf('post:%d', $post_id));
}

/** The GET_LOCK name of any lock subject, scoped to this install and blog. */
function kk_lock_name(string $key): string
{
    global $wpdb;
    /** @var \wpdb $wpdb */
    $db = defined('DB_NAME') ? (string) constant('DB_NAME') : '';
    return 'novamira-kk:'
    . sha1(sprintf('db=%s|prefix=%s|blog=%d|key=%s', $db, $wpdb->prefix, get_current_blog_id(), $key));
}

/**
 * @internal in-request registry of the post locks this process holds
 * (`$mark` true = take, false = release, null = ask).
 */
function kk_lock_held(string $key, ?bool $mark): bool
{
    /** @var array<string, true> $held */
    static $held = [];
    $was = isset($held[$key]);
    if ($mark === true) {
        $held[$key] = true;
    }
    if ($mark === false) {
        unset($held[$key]);
    }
    return $was;
}

/**
 * Run `$fn` inside a database transaction (InnoDB): every meta row it writes
 * is committed together or not at all, so an exception thrown by a hook, an
 * out-of-memory fatal or a refused key can never leave a page with a new
 * style map and an old tree. Nested calls (a hook writing another post
 * through an ability) use a savepoint. A WP_Error or a Throwable rolls back;
 * the object cache is dropped for `$post_id` afterwards because WordPress
 * updated it before the rollback.
 *
 * @template T
 * @param callable(): (T|WP_Error) $fn
 * @return T|WP_Error
 */
function kk_db_transaction(int $post_id, callable $fn): mixed
{
    global $wpdb;
    /** @var \wpdb $wpdb */
    $depth = kk_transaction_depth(delta: 1);
    $savepoint = sprintf('kk_%d', $depth);
    $wpdb->query($depth === 1 ? 'START TRANSACTION' : sprintf('SAVEPOINT %s', $savepoint));
    $ok = false;
    try {
        $result = $fn();
        $ok = !$result instanceof WP_Error;
        return $result;
    } finally {
        kk_transaction_end($post_id, $depth, $savepoint, $ok);
    }
}

/** @internal commit / release or roll back the (nested) transaction opened by kk_db_transaction */
// @mago-expect lint:no-boolean-flag-parameter -- outcome of the guarded block
function kk_transaction_end(int $post_id, int $depth, string $savepoint, bool $ok): void
{
    global $wpdb;
    /** @var \wpdb $wpdb */
    kk_transaction_depth(delta: -1);
    if ($ok) {
        $wpdb->query($depth === 1 ? 'COMMIT' : sprintf('RELEASE SAVEPOINT %s', $savepoint));
        return;
    }
    $wpdb->query($depth === 1 ? 'ROLLBACK' : sprintf('ROLLBACK TO SAVEPOINT %s', $savepoint));
    kk_refresh($post_id);
}

/** @internal nesting depth of kk_db_transaction in this process */
function kk_transaction_depth(int $delta): int
{
    static $depth = 0;
    // @mago-expect lint:inline-variable-return -- the static must be updated, not only returned
    $depth = max(0, $depth + $delta);
    return $depth;
}

/**
 * Editor tabs currently open on a post, from Kirki's collaboration heartbeat
 * (`kirki_collaborations_connected`: one row per EventSource session,
 * `updated_at` refreshed on every reconnect, rows older than 20 s cleaned by
 * Kirki). null when the table does not exist. An open tab never re-reads the
 * page: its next Publish or "Save as draft" writes its own in-memory tree
 * over anything written meanwhile.
 *
 * @return array{sessions: int, newest_age_seconds: int|null}|null
 */
function kk_open_editor_sessions(int $post_id): ?array
{
    global $wpdb;
    /** @var \wpdb $wpdb */
    if (!(kk_tables_present()['kirki_collaborations_connected'] ?? false)) {
        return null;
    }
    $table = $wpdb->prefix . 'kirki_collaborations_connected';
    $since = gmdate('Y-m-d H:i:s', time() - 30);
    // @mago-expect analysis:possibly-invalid-argument
    $sql = (string) $wpdb->prepare(
        sprintf(
            'SELECT COUNT(*) AS sessions, MAX(updated_at) AS newest FROM `%s` WHERE post_id = %%d AND updated_at > %%s',
            $table,
        ),
        $post_id,
        $since,
    );
    /** @var mixed $row */
    $row = $wpdb->get_row($sql, 'ARRAY_A');
    if (!is_array($row)) {
        return ['sessions' => 0, 'newest_age_seconds' => null];
    }
    $sessions = kk_coerce_int_or_null($row['sessions'] ?? null) ?? 0;
    /** @var mixed $newest */
    $newest = $row['newest'] ?? null;
    $age = null;
    if ($sessions > 0 && is_string($newest)) {
        $stamp = strtotime($newest . ' UTC');
        $age = $stamp === false ? null : max(0, time() - $stamp);
    }
    return ['sessions' => $sessions, 'newest_age_seconds' => $age];
}

/**
 * Fresh look at a post right before a write: null when it no longer exists or
 * was trashed since the ability started.
 */
function kk_live_post(int $post_id): ?WP_Post
{
    clean_post_cache($post_id);
    // @mago-expect analysis:mixed-assignment
    $post = get_post($post_id);
    if (!$post instanceof WP_Post || !in_array($post->post_status, KK_LIVE_STATUSES, strict: true)) {
        return null;
    }
    return $post;
}

/** Longest search needle WordPress honours; longer ones are silently dropped by WP_Query. */
const KK_SEARCH_MAX_BYTES = 1600;

/** Reusable `limit` / `offset` schema fragments. */
const KK_LIMIT_SCHEMA = [
    'type' => 'integer',
    'minimum' => 1,
    'maximum' => KK_LIST_HARD_MAX,
    'description' => 'Maximum rows to return. Default 50, hard max 500.',
    'default' => 50,
];

const KK_OFFSET_SCHEMA = [
    'type' => 'integer',
    'minimum' => 0,
    'description' => 'Rows to skip, for paging. Default 0.',
    'default' => 0,
];

const KK_SEARCH_DESCRIPTION = 'Title search with WordPress semantics (case-insensitive): up to 9 words, every word must appear in the post title; a leading `-` excludes a word, quotes group a phrase, single-character words (A-Z, `-`) and WordPress stopwords (a, the, and, …) are ignored, backslashes are stripped; 10 words or more are matched as ONE phrase in that exact order. Max 1600 bytes.';

/**
 * Trimmed search needle, null when absent / blank, WP_Error when longer than
 * WordPress accepts (it would otherwise ignore the filter and list everything).
 */
function kk_search_needle(mixed $raw): string|null|WP_Error
{
    if (!is_string($raw)) {
        return null;
    }
    $needle = trim($raw);
    if ($needle === '') {
        return null;
    }
    if (strlen($needle) > KK_SEARCH_MAX_BYTES) {
        return kk_invalid_input(sprintf(
            /* translators: %d: byte count */
            __('search must be at most %d bytes; WordPress ignores longer needles.', domain: 'novamira-pro'),
            KK_SEARCH_MAX_BYTES,
        ));
    }
    return $needle;
}

/**
 * Total rows matching a list query regardless of paging. `WP_Query` skips
 * `SQL_CALC_FOUND_ROWS` when the requested page is empty (offset past the end),
 * reporting 0; recount in that case.
 *
 * @param array<string, mixed> $args the arguments the query ran with
 */
function kk_found_total(\WP_Query $query, array $args): int
{
    if ($query->posts !== [] || ($args['offset'] ?? 0) === 0) {
        return (int) $query->found_posts;
    }
    $args['fields'] = 'ids';
    $args['posts_per_page'] = -1;
    $args['offset'] = 0;
    $args['no_found_rows'] = true;
    $count = new \WP_Query($args);
    return count($count->posts);
}

/**
 * Last-modified timestamp (GMT) of a post; never-edited drafts carry
 * `0000-00-00 00:00:00` in `post_modified_gmt`, so fall back to the local
 * modified date and then to the creation date.
 */
function kk_modified_gmt(WP_Post $post): string
{
    if (!str_starts_with($post->post_modified_gmt, '0000')) {
        return $post->post_modified_gmt;
    }
    if (!str_starts_with($post->post_modified, '0000')) {
        return get_gmt_from_date($post->post_modified);
    }
    return $post->post_date_gmt;
}

/**
 * A block map re-keyed as `string id => node`.
 *
 * @param array<array-key, mixed> $blocks
 * @return array<string, mixed>
 */
function kk_node_map(array $blocks): array
{
    $out = [];
    /** @var mixed $node */
    foreach ($blocks as $id => $node) {
        $out[(string) $id] = $node;
    }
    return $out;
}

/**
 * A style map re-keyed as `string id => block`, dropping non-object entries.
 *
 * @param array<array-key, mixed> $styles
 * @return array<string, array<string, mixed>>
 */
function kk_style_map(array $styles): array
{
    $out = [];
    /** @var mixed $block */
    foreach ($styles as $id => $block) {
        if (!is_array($block)) {
            continue;
        }
        /** @var array<string, mixed> $block */
        $out[(string) $id] = $block;
    }
    return $out;
}

// ---------------------------------------------------------------------------
// Global classes (class manager): the style blocks Kirki merges into every
// page at render time, stored on the global-data post.
// ---------------------------------------------------------------------------

/** Meta key of the class-manager map on the global-data post. */
function kk_meta_class_manager(): string
{
    return kk_const('GlobalDataKeys', name: 'STYLE_BLOCKS', fallback: 'kirki_class_manager_style_blocks');
}

/** Meta key of the legacy global style map, read-only for the abilities. */
function kk_meta_deprecated_global_styles(): string
{
    return kk_const('GlobalDataKeys', name: 'STYLE_BLOCK_DEPRECATED', fallback: 'kirki_global_style_block');
}

/**
 * The global-data post id and its class-manager map, fresh (Kirki's editor
 * writes the map through its ORM without touching the object cache). The
 * map is keyed by class id; each entry is the stored block. WP_Error
 * (`kirki_no_global_data`, 422) when Kirki has not created its global-data
 * post yet: the first editor open or page view creates it.
 *
 * @return array{post_id: int, map: array<string, array<string, mixed>>}|WP_Error
 */
function kk_global_classes(): array|WP_Error
{
    $post_id = kk_global_data_post_id();
    if ($post_id === null || $post_id <= 0 || !get_post($post_id) instanceof WP_Post) {
        return new WP_Error(
            'kirki_no_global_data',
            __(
                'Kirki has no global-data post yet (it creates one on the first editor open or page view), so there is nowhere to store global classes. Open the Kirki editor once, then retry; kirki-check-setup reports the post id.',
                domain: 'novamira-pro',
            ),
            ['status' => 422],
        );
    }
    kk_refresh($post_id);
    return ['post_id' => $post_id, 'map' => kk_style_map_of(kk_meta($post_id, kk_meta_class_manager()))];
}

/**
 * Editor tabs currently open on ANY post (same heartbeat table and window as
 * kk_open_editor_sessions). Every open tab holds the whole class-manager
 * map in memory and re-posts it entire on its next class change, so a
 * global class written meanwhile is erased whatever page the tab shows.
 * null when the table does not exist.
 *
 * @return array{sessions: int, posts: list<int>, newest_age_seconds: int|null}|null
 */
function kk_open_editor_sessions_any(): ?array
{
    global $wpdb;
    /** @var \wpdb $wpdb */
    if (!(kk_tables_present()['kirki_collaborations_connected'] ?? false)) {
        return null;
    }
    $table = $wpdb->prefix . 'kirki_collaborations_connected';
    $since = gmdate('Y-m-d H:i:s', time() - 30);
    // @mago-expect analysis:possibly-invalid-argument
    $sql = (string) $wpdb->prepare(
        sprintf(
            'SELECT post_id, COUNT(*) AS sessions, MAX(updated_at) AS newest FROM `%s` WHERE updated_at > %%s GROUP BY post_id ORDER BY newest DESC LIMIT 20',
            $table,
        ),
        $since,
    );
    /** @var mixed $rows */
    $rows = $wpdb->get_results($sql, 'ARRAY_A');
    $sessions = 0;
    $posts = [];
    $age = null;
    /** @var mixed $row */
    foreach (is_array($rows) ? $rows : [] as $row) {
        if (!is_array($row)) {
            continue;
        }
        $sessions += kk_coerce_int_or_null($row['sessions'] ?? null) ?? 0;
        $post_id = kk_coerce_int_or_null($row['post_id'] ?? null);
        if ($post_id !== null) {
            $posts[] = $post_id;
        }
        /** @var mixed $newest */
        $newest = $row['newest'] ?? null;
        if ($age === null && is_string($newest)) {
            $stamp = strtotime($newest . ' UTC');
            $age = $stamp === false ? null : max(0, time() - $stamp);
        }
    }
    return ['sessions' => $sessions, 'posts' => $posts, 'newest_age_seconds' => $age];
}

/** Rows a usage scan reports per class at most. */
const KK_USAGE_ROWS = 200;

/**
 * Posts whose stored trees reference the given global class ids through
 * `properties.classesIds` (published tree and every `staged_<n>_kirki` copy:
 * pages, templates, utility pages, popups and symbols all keep their tree
 * under the same key). One query per id on the serialised meta
 * (`s:<len>:"<id>";`, the form a list entry takes), no tree decoded.
 *
 * @param list<string> $ids
 * @return array<string, list<array{post_id: int, post_type: string, status: string, title: string, published_tree: bool}>>
 */
function kk_global_class_usage(array $ids): array
{
    global $wpdb;
    /** @var \wpdb $wpdb */
    $usage = [];
    $blocks_key = kk_meta_blocks();
    foreach ($ids as $id) {
        $needle = '%' . $wpdb->esc_like(sprintf('s:%d:"%s";', strlen($id), $id)) . '%';
        // @mago-expect analysis:possibly-invalid-argument
        $sql = (string) $wpdb->prepare(
            "SELECT m.post_id, m.meta_key, p.post_type, p.post_status, p.post_title FROM {$wpdb->postmeta} m INNER JOIN {$wpdb->posts} p ON p.ID = m.post_id WHERE (m.meta_key = %s OR m.meta_key LIKE %s) AND m.meta_value LIKE %s ORDER BY m.post_id ASC LIMIT %d",
            $blocks_key,
            'staged\_%\_' . $wpdb->esc_like($blocks_key),
            $needle,
            KK_USAGE_ROWS,
        );
        /** @var mixed $rows */
        $rows = $wpdb->get_results($sql, 'ARRAY_A');
        $usage[$id] = kk_usage_rows_by_post(is_array($rows) ? $rows : [], $blocks_key);
    }
    return $usage;
}

/**
 * Group the rows of one usage query by post (`published_tree` true when the
 * base `kirki` row matched, not only a staged copy).
 *
 * @param array<array-key, mixed> $rows
 * @return list<array{post_id: int, post_type: string, status: string, title: string, published_tree: bool}>
 */
function kk_usage_rows_by_post(array $rows, string $blocks_key): array
{
    $by_post = [];
    /** @var mixed $row */
    foreach ($rows as $row) {
        if (!is_array($row)) {
            continue;
        }
        $post_id = kk_coerce_int_or_null($row['post_id'] ?? null) ?? 0;
        if ($post_id <= 0) {
            continue;
        }
        $entry = $by_post[$post_id] ?? [
            'post_id' => $post_id,
            'post_type' => is_string($row['post_type'] ?? null) ? $row['post_type'] : '',
            'status' => is_string($row['post_status'] ?? null) ? $row['post_status'] : '',
            'title' => is_string($row['post_title'] ?? null) ? $row['post_title'] : '',
            'published_tree' => false,
        ];
        if (($row['meta_key'] ?? '') === $blocks_key) {
            $entry['published_tree'] = true;
        }
        $by_post[$post_id] = $entry;
    }
    return array_values($by_post);
}

/**
 * Posts whose page-local style map already uses a class NAME (the renderer
 * renames the local block `<name>-copy` when a global class takes the name,
 * so the page's own rule stops matching). Capped, no tree decoded.
 *
 * @return list<int>
 */
function kk_local_style_name_holders(string $name): array
{
    global $wpdb;
    /** @var \wpdb $wpdb */
    $needle = '%' . $wpdb->esc_like(sprintf('"name";s:%d:"%s";', strlen($name), $name)) . '%';
    // @mago-expect analysis:possibly-invalid-argument
    $sql = (string) $wpdb->prepare(
        "SELECT DISTINCT post_id FROM {$wpdb->postmeta} WHERE (meta_key = %s OR meta_key LIKE %s) AND meta_value LIKE %s ORDER BY post_id ASC LIMIT 20",
        kk_meta_style_blocks(),
        'staged\_%\_' . $wpdb->esc_like(kk_meta_style_blocks()),
        $needle,
    );
    /** @var mixed $rows */
    $rows = $wpdb->get_col($sql);
    $ids = [];
    /** @var mixed $row */
    foreach (is_array($rows) ? $rows : [] as $row) {
        $id = kk_coerce_int_or_null($row);
        if ($id !== null) {
            $ids[] = $id;
        }
    }
    return $ids;
}

// ---------------------------------------------------------------------------
// Page settings: the SEO map and the custom code the editor's "Page Settings"
// popover stores on a post (`kirki_page_seo_settings`, `kirki_page_custom_code`).
// ---------------------------------------------------------------------------

/**
 * Dynamic tokens the editor offers in the SEO fields of a template, by
 * family (`Preview::getSeoValue` resolves `post` tokens against the rendered
 * post, `term` / `user` against the archive in the URL).
 */
const KK_SEO_TOKENS = [
    'post' => ['post_id', 'post_title', 'post_author', 'post_date', 'post_time', 'post_excerpt'],
    'term' => ['term_id', 'term_name', 'term_slug'],
    'user' => ['user_id', 'user_name', 'user_nicename', 'user_email', 'user_login', 'user_registered', 'user_url'],
];

/** Value of `openGraphImageType` the editor stores for each image source. */
const KK_SEO_IMAGE_TYPES = ['media' => 'media_manager', 'featured' => 'featured_image'];

/**
 * The SEO map exactly as the editor writes it for a post without settings
 * (the editor's defaults): every key Kirki's frontend indexes without `isset`
 * is present, so the frontend never warns.
 *
 * @return array<string, array<string, array<string, mixed>>>
 */
function kk_seo_default_map(): array
{
    return [
        'seoSettings' => ['seoTitleTag' => ['value' => ''], 'seoMetaDesc' => ['value' => '']],
        'openGraph' => [
            'openGraphImage' => ['value' => ''],
            'openGraphTitle' => ['sameAsSeoTitle' => false, 'value' => ''],
            'openGraphDesc' => ['sameAsSeoMeta' => false, 'value' => ''],
            'openGraphImageType' => ['value' => KK_SEO_IMAGE_TYPES['media']],
        ],
    ];
}

/**
 * Whether a stored SEO map carries every key Kirki's frontend reads without
 * `isset` (`Preview::getSeoMetaTags`, `PluginInitEvents::document_title`):
 * a map missing one of them logs PHP warnings on every request for the post.
 */
function kk_seo_map_is_complete(mixed $map): bool
{
    if (!is_array($map)) {
        return false;
    }
    foreach (kk_seo_default_map() as $section => $entries) {
        if (!isset($map[$section]) || !is_array($map[$section])) {
            return false;
        }
        foreach (array_keys($entries) as $key) {
            if (!isset($map[$section][$key]) || !is_array($map[$section][$key])) {
                return false;
            }
        }
    }
    return true;
}

/**
 * A stored SEO value as the abilities report it: a string, or the token list
 * `[{type, value}]` the editor stores for dynamic fields (anything else
 * becomes '' — Kirki prints nothing for it).
 *
 * @return string|list<array{type: string, value: string}>
 */
function kk_seo_value(mixed $value): string|array
{
    if (is_string($value)) {
        return $value;
    }
    if (!is_array($value)) {
        return '';
    }
    $tokens = [];
    /** @var mixed $item */
    foreach ($value as $item) {
        if (!is_array($item) || !isset($item['type'], $item['value']) || !is_string($item['type'])) {
            continue;
        }
        $tokens[] = ['type' => $item['type'], 'value' => is_scalar($item['value']) ? (string) $item['value'] : ''];
    }
    return $tokens;
}

/**
 * One `{value, <flag>}` entry of a stored SEO section (missing → defaults).
 *
 * @param array<string, mixed> $section
 * @return array{value: mixed, flag: bool}
 */
function kk_seo_entry(array $section, string $key, string $flag = ''): array
{
    $entry = is_array($section[$key] ?? null) ? $section[$key] : [];
    return [
        'value' => $entry['value'] ?? '',
        'flag' => $flag !== '' && kk_bool($entry[$flag] ?? false),
    ];
}

/**
 * The stored SEO map in the flat form the abilities exchange.
 *
 * @return array<string, mixed>
 */
function kk_seo_flat(mixed $map): array
{
    $stored = is_array($map) ? $map : [];
    /** @var array<string, mixed> $seo */
    $seo = is_array($stored['seoSettings'] ?? null) ? $stored['seoSettings'] : [];
    /** @var array<string, mixed> $og */
    $og = is_array($stored['openGraph'] ?? null) ? $stored['openGraph'] : [];
    $image = kk_seo_value(kk_seo_entry($og, key: 'openGraphImage')['value']);
    $image = is_string($image) ? $image : '';
    $featured = kk_seo_entry($og, key: 'openGraphImageType')['value'] === KK_SEO_IMAGE_TYPES['featured'];
    $og_title = kk_seo_entry($og, key: 'openGraphTitle', flag: 'sameAsSeoTitle');
    $og_desc = kk_seo_entry($og, key: 'openGraphDesc', flag: 'sameAsSeoMeta');
    return [
        'stored' => is_array($map),
        'title' => kk_seo_value(kk_seo_entry($seo, key: 'seoTitleTag')['value']),
        'meta_description' => kk_seo_value(kk_seo_entry($seo, key: 'seoMetaDesc')['value']),
        'og_title' => kk_seo_value($og_title['value']),
        'og_title_same_as_title' => $og_title['flag'],
        'og_description' => kk_seo_value($og_desc['value']),
        'og_description_same_as_meta' => $og_desc['flag'],
        'og_image' => $image,
        'og_image_source' => match (true) {
            $image === '' => 'none',
            $featured => 'featured',
            default => 'media',
        },
    ];
}

/**
 * The full editor-shaped map for a flat SEO description (the inverse of
 * kk_seo_flat): every key present, `openGraphImageType` derived from the
 * image source.
 *
 * @param array<string, mixed> $flat
 * @return array<string, mixed>
 */
function kk_seo_map(array $flat): array
{
    $map = kk_seo_default_map();
    $map['seoSettings']['seoTitleTag']['value'] = $flat['title'] ?? '';
    $map['seoSettings']['seoMetaDesc']['value'] = $flat['meta_description'] ?? '';
    $map['openGraph']['openGraphImage']['value'] = $flat['og_image'] ?? '';
    $map['openGraph']['openGraphTitle'] = [
        'sameAsSeoTitle' => kk_bool($flat['og_title_same_as_title'] ?? false),
        'value' => $flat['og_title'] ?? '',
    ];
    $map['openGraph']['openGraphDesc'] = [
        'sameAsSeoMeta' => kk_bool($flat['og_description_same_as_meta'] ?? false),
        'value' => $flat['og_description'] ?? '',
    ];
    $map['openGraph']['openGraphImageType']['value'] = ($flat['og_image_source'] ?? 'media') === 'featured'
        ? KK_SEO_IMAGE_TYPES['featured']
        : KK_SEO_IMAGE_TYPES['media'];
    return $map;
}

/**
 * Token families that resolve to something on this post: every family on a
 * template (Kirki reads the archive's term / author from the URL), only
 * `post` elsewhere — `Preview::getSeoValue` would print the VIEWER's own
 * name / e-mail for a `user` token on a page and nothing for a `term` one.
 *
 * @return list<string>
 */
function kk_seo_tokens_allowed(WP_Post $post): array
{
    return $post->post_type === kk_content_post_types()['template'] ? ['post', 'term', 'user'] : ['post'];
}

/**
 * The post gate of the page-settings abilities: kk_post_or_error plus a
 * popup refusal — Kirki never prints SEO tags or custom code for a popup.
 */
function kk_settings_post_or_error(int $post_id): WP_Post|WP_Error
{
    $post = kk_post_or_error($post_id);
    if ($post instanceof WP_Error || $post->post_type !== kk_popup_post_type()) {
        return $post;
    }
    return new WP_Error(
        'kirki_unsupported_post_type',
        sprintf(
            /* translators: %d: post id */
            __(
                'Post %d is a Kirki popup: popups have no page settings (Kirki never prints SEO tags or custom code for them).',
                domain: 'novamira-pro',
            ),
            $post->ID,
        ),
        ['status' => 422],
    );
}

// ---------------------------------------------------------------------------
// Symbols: the gate, the usage scan, the header / footer registry.
// ---------------------------------------------------------------------------

/** Values Kirki accepts for a symbol's `setAs`. */
const KK_SYMBOL_SET_AS = ['header', 'footer'];

/**
 * The post gate of the symbol abilities: a live `kirki_symbol` post in any
 * status (only `draft` symbols are listed by the editor and resolved as
 * header / footer, which the writers report as a warning).
 */
function kk_symbol_post_or_error(int $post_id): WP_Post|WP_Error
{
    if ($post_id <= 0) {
        return kk_invalid_post($post_id);
    }
    // @mago-expect analysis:mixed-assignment
    $post = get_post($post_id);
    if (!$post instanceof WP_Post || in_array($post->post_status, ['trash', 'auto-draft', 'inherit'], strict: true)) {
        return kk_invalid_post($post_id);
    }
    if ($post->post_type === kk_symbol_post_type()) {
        return $post;
    }
    return new WP_Error(
        'kirki_unsupported_post_type',
        sprintf(
            /* translators: 1: post id, 2: post type */
            __(
                'Post %1$d has post type `%2$s`; the symbol abilities handle Kirki symbols (`kirki_symbol`) only. List them with kirki-list-symbols; pages and templates are written by the page abilities.',
                domain: 'novamira-pro',
            ),
            $post->ID,
            $post->post_type,
        ),
        ['status' => 422],
    );
}

/**
 * Posts whose published tree or staged copies embed a symbol (a `symbol`
 * node with `properties.symbolId`): LIKE on the serialised property over the
 * `kirki` rows of every non-symbol post, capped at KK_USAGE_ROWS rows, then
 * the matched rows small enough to decode are scanned for the node ids.
 *
 * @return list<array{post_id: int, post_type: string, status: string, title: string, published_tree: bool, node_ids: list<string>}>
 */
function kk_symbol_usage(int $symbol_id): array
{
    global $wpdb;
    /** @var \wpdb $wpdb */
    $blocks_key = kk_meta_blocks();
    $int_needle = '%' . $wpdb->esc_like(sprintf('s:8:"symbolId";i:%d;', $symbol_id)) . '%';
    $string_needle =
        '%' . $wpdb->esc_like(sprintf('s:8:"symbolId";s:%d:"%d";', strlen((string) $symbol_id), $symbol_id)) . '%';
    // @mago-expect analysis:possibly-invalid-argument
    $sql = (string) $wpdb->prepare(
        "SELECT m.post_id, m.meta_key, p.post_type, p.post_status, p.post_title FROM {$wpdb->postmeta} m INNER JOIN {$wpdb->posts} p ON p.ID = m.post_id WHERE (m.meta_key = %s OR m.meta_key LIKE %s) AND (m.meta_value LIKE %s OR m.meta_value LIKE %s) AND p.ID <> %d ORDER BY m.post_id ASC LIMIT %d",
        $blocks_key,
        'staged\_%\_' . $wpdb->esc_like($blocks_key),
        $int_needle,
        $string_needle,
        $symbol_id,
        KK_USAGE_ROWS,
    );
    /** @var mixed $rows */
    $rows = $wpdb->get_results($sql, 'ARRAY_A');
    $usage = [];
    $keys_by_post = [];
    /** @var mixed $row */
    foreach (is_array($rows) ? $rows : [] as $row) {
        if (!is_array($row) || !is_string($row['meta_key'] ?? null)) {
            continue;
        }
        $keys_by_post[kk_coerce_int_or_null($row['post_id'] ?? null) ?? 0][] = $row['meta_key'];
    }
    foreach (kk_usage_rows_by_post(is_array($rows) ? $rows : [], $blocks_key) as $entry) {
        $entry['node_ids'] = kk_symbol_instance_ids(
            $entry['post_id'],
            $keys_by_post[$entry['post_id']] ?? [],
            $symbol_id,
        );
        $usage[] = $entry;
    }
    return $usage;
}

/**
 * Ids of the `symbol` nodes embedding `$symbol_id` in the given meta rows of a
 * post (rows over the list cap are not decoded: the ids stay unknown).
 *
 * @param list<string> $keys
 * @return list<string>
 */
function kk_symbol_instance_ids(int $post_id, array $keys, int $symbol_id): array
{
    $ids = [];
    foreach (kk_list_meta([$post_id], $keys, inline_bytes: KK_LIST_TREE_BYTES)[$post_id] ?? [] as $entry) {
        /** @var mixed $value */
        $value = $entry['value'];
        $blocks = is_array($value) && is_array($value['blocks'] ?? null) ? $value['blocks'] : [];
        /** @var mixed $node */
        foreach ($blocks as $id => $node) {
            if (!is_array($node) || ($node['name'] ?? null) !== 'symbol') {
                continue;
            }
            if (
                kk_coerce_int_or_null(
                    is_array($node['properties'] ?? null) ? $node['properties']['symbolId'] ?? null : null,
                ) === $symbol_id
            ) {
                $ids[strval($id)] = true;
            }
        }
    }
    return array_keys($ids);
}

/**
 * The DRAFT symbols whose meta carries `setAs === $type`, read fresh — the
 * set Kirki itself resolves (`Ajax\Symbol::update` → `fetch_list`, draft
 * status only), i.e. what actually prints on the frontend.
 *
 * @return list<int>
 */
function kk_symbols_set_as(string $type): array
{
    return kk_symbols_set_as_in($type, status: 'draft');
}

/**
 * Every symbol carrying `setAs === $type` whatever its post status. Kirki's
 * own list is draft-only, so a symbol published in the meantime keeps a role
 * Kirki ignores until it goes back to draft: the exclusivity pass must clear
 * those too, or the site ends up with two headers.
 *
 * @return list<int>
 */
function kk_symbols_set_as_any_status(string $type): array
{
    return kk_symbols_set_as_in($type, status: 'any');
}

/**
 * Symbols carrying `setAs === $type` among the posts of the given status.
 *
 * @return list<int>
 */
function kk_symbols_set_as_in(string $type, string $status): array
{
    /** @var array<array-key, mixed> $posts */
    $posts = get_posts([
        'post_type' => kk_symbol_post_type(),
        'post_status' => $status,
        'numberposts' => -1,
        'fields' => 'ids',
        'orderby' => 'date',
        'order' => 'DESC',
        'cache_results' => false,
        'update_post_meta_cache' => false,
    ]);
    $ids = [];
    /** @var mixed $post */
    foreach ($posts as $post) {
        $id = kk_coerce_int_or_null($post);
        if ($id === null) {
            continue;
        }
        $meta = kk_symbol_meta($id);
        if ($meta !== null && ($meta['setAs'] ?? null) === $type) {
            $ids[] = $id;
        }
    }
    return $ids;
}

/**
 * Posts that switch a header / footer off (`kirki_disabled_page_symbols[type]`
 * true), where an assigned symbol never prints. Capped at 20, LIKE on the
 * serialised flag.
 *
 * @return list<int>
 */
function kk_disabled_symbol_pages(string $type): array
{
    global $wpdb;
    /** @var \wpdb $wpdb */
    $needle = '%' . $wpdb->esc_like(sprintf('s:%d:"%s";b:1;', strlen($type), $type)) . '%';
    // @mago-expect analysis:possibly-invalid-argument
    $sql = (string) $wpdb->prepare(
        "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value LIKE %s ORDER BY post_id ASC LIMIT 20",
        kk_meta_disabled_symbols(),
        $needle,
    );
    /** @var mixed $rows */
    $rows = $wpdb->get_col($sql);
    $ids = [];
    /** @var mixed $row */
    foreach (is_array($rows) ? $rows : [] as $row) {
        $id = kk_coerce_int_or_null($row);
        if ($id !== null) {
            $ids[] = $id;
        }
    }
    return $ids;
}

// ---------------------------------------------------------------------------
// Popups: the gate and the usage scan.
// ---------------------------------------------------------------------------

/**
 * The post gate of the popup abilities: a live `kirki_popup` post in any
 * status (the frontend prints published popups only, which the writers
 * report as a warning).
 */
function kk_popup_post_or_error(int $post_id): WP_Post|WP_Error
{
    if ($post_id <= 0) {
        return kk_invalid_post($post_id);
    }
    // @mago-expect analysis:mixed-assignment
    $post = get_post($post_id);
    if (!$post instanceof WP_Post || in_array($post->post_status, ['trash', 'auto-draft', 'inherit'], strict: true)) {
        return kk_invalid_post($post_id);
    }
    if ($post->post_type === kk_popup_post_type()) {
        return $post;
    }
    return new WP_Error(
        'kirki_unsupported_post_type',
        sprintf(
            /* translators: 1: post id, 2: post type */
            __(
                'Post %1$d has post type `%2$s`; the popup abilities handle Kirki popups (`kirki_popup`) only. List them with kirki-list-pages kind=popup; pages and templates are written by the page abilities.',
                domain: 'novamira-pro',
            ),
            $post->ID,
            $post->post_type,
        ),
        ['status' => 422],
    );
}

/**
 * Posts whose trees or staged copies open a popup: a button / link with
 * `attributes.popup` naming it, or a form whose `properties.form.onSubmit`
 * targets it. LIKE on the serialised id over the `kirki` rows of every other
 * post (symbols and other popups included: they open popups too), capped at
 * KK_USAGE_ROWS, the matched rows small enough to decode scanned for the node
 * ids.
 *
 * @return list<array{post_id: int, post_type: string, status: string, title: string, published_tree: bool, node_ids: list<string>}>
 */
// @mago-expect lint:halstead -- one LIKE needle per opener shape, then the shared row walk
function kk_popup_usage(int $popup_id): array
{
    global $wpdb;
    /** @var \wpdb $wpdb */
    $blocks_key = kk_meta_blocks();
    $int_needle = '%' . $wpdb->esc_like(sprintf('s:5:"popup";i:%d;', $popup_id)) . '%';
    $string_needle =
        '%' . $wpdb->esc_like(sprintf('s:5:"popup";s:%d:"%d";', strlen((string) $popup_id), $popup_id)) . '%';
    // A form's `onSubmit` value carries the id as a string ("215743") or as an
    // int, depending on who wrote it: the prefilter must match both.
    $form_needle = '%' . $wpdb->esc_like(sprintf('s:%d:"%d";', strlen((string) $popup_id), $popup_id)) . '%';
    $form_int_needle = '%' . $wpdb->esc_like(sprintf('i:%d;', $popup_id)) . '%';
    // @mago-expect analysis:possibly-invalid-argument
    $sql = (string) $wpdb->prepare(
        "SELECT m.post_id, m.meta_key, p.post_type, p.post_status, p.post_title FROM {$wpdb->postmeta} m INNER JOIN {$wpdb->posts} p ON p.ID = m.post_id WHERE (m.meta_key = %s OR m.meta_key LIKE %s) AND (m.meta_value LIKE %s OR m.meta_value LIKE %s OR (m.meta_value LIKE %s AND (m.meta_value LIKE %s OR m.meta_value LIKE %s))) AND p.ID <> %d ORDER BY m.post_id ASC LIMIT %d",
        $blocks_key,
        'staged\_%\_' . $wpdb->esc_like($blocks_key),
        $int_needle,
        $string_needle,
        '%' . $wpdb->esc_like('s:8:"onSubmit";') . '%',
        $form_needle,
        $form_int_needle,
        $popup_id,
        KK_USAGE_ROWS,
    );
    /** @var mixed $rows */
    $rows = $wpdb->get_results($sql, 'ARRAY_A');
    $keys_by_post = [];
    /** @var mixed $row */
    foreach (is_array($rows) ? $rows : [] as $row) {
        if (!is_array($row) || !is_string($row['meta_key'] ?? null)) {
            continue;
        }
        $keys_by_post[kk_coerce_int_or_null($row['post_id'] ?? null) ?? 0][] = $row['meta_key'];
    }
    $usage = [];
    foreach (kk_usage_rows_by_post(is_array($rows) ? $rows : [], $blocks_key) as $entry) {
        $keys = $keys_by_post[$entry['post_id']] ?? [];
        $entry['node_ids'] = kk_popup_opener_ids($entry['post_id'], $keys, $popup_id);
        // A LIKE match without a decoded opener is either a row too large to decode
        // (kept, ids unknown) or a string that merely contains the digits (dropped).
        if ($entry['node_ids'] !== [] || kk_popup_row_undecoded($entry['post_id'], $keys)) {
            $usage[] = $entry;
        }
    }
    return $usage;
}

/**
 * Ids of the nodes opening `$popup_id` in the given meta rows of a post: a
 * button / link with `properties.type: popup` and `attributes.popup`, or a
 * form whose `onSubmit` success / fail value is the popup.
 *
 * @param list<string> $keys
 * @return list<string>
 */
function kk_popup_opener_ids(int $post_id, array $keys, int $popup_id): array
{
    $ids = [];
    foreach (kk_list_meta([$post_id], $keys, inline_bytes: KK_LIST_TREE_BYTES)[$post_id] ?? [] as $entry) {
        $blocks = kk_blocks_of($entry['value']) ?? [];
        /** @var mixed $node */
        foreach ($blocks as $id => $node) {
            if (!is_array($node) || !kk_node_opens_popup(kk_node_map($node), $popup_id)) {
                continue;
            }
            $ids[strval($id)] = true;
        }
    }
    return array_keys($ids);
}

/** Whether a node's properties open the popup (button / link target, or a form's onSubmit target). */
function kk_node_opens_popup(array $node, int $popup_id): bool
{
    $props = is_array($node['properties'] ?? null) ? $node['properties'] : [];
    $attributes = is_array($props['attributes'] ?? null) ? $props['attributes'] : [];
    if (kk_coerce_int_or_null($attributes['popup'] ?? null) === $popup_id) {
        return true;
    }
    // A form keeps its submit behaviour under `properties.form.onSubmit`
    // (`Preview::check_popup_inside_form($properties['form'])`); the
    // top level is read too because older / hand-written trees carry it there.
    $form = is_array($props['form'] ?? null) ? $props['form'] : [];
    /** @var mixed $candidate */
    foreach ([$props['onSubmit'] ?? null, $form['onSubmit'] ?? null] as $candidate) {
        if (kk_on_submit_opens_popup($candidate, $popup_id)) {
            return true;
        }
    }
    return false;
}

/** Whether an `onSubmit` map targets the popup on success or failure. */
function kk_on_submit_opens_popup(mixed $on_submit, int $popup_id): bool
{
    if (!is_array($on_submit) || ($on_submit['type'] ?? null) !== 'popup') {
        return false;
    }
    $value = is_array($on_submit['value'] ?? null) ? $on_submit['value'] : [];
    return (
        kk_coerce_int_or_null($value['success'] ?? null) === $popup_id
        || kk_coerce_int_or_null($value['fail'] ?? null) === $popup_id
    );
}

/**
 * Whether one of a post's matched rows is too large to decode (over the list cap), so its openers stay unknown.
 *
 * @param list<string> $keys
 */
function kk_popup_row_undecoded(int $post_id, array $keys): bool
{
    foreach (kk_list_meta([$post_id], $keys, inline_bytes: 0)[$post_id] ?? [] as $entry) {
        if ($entry['bytes'] > KK_LIST_TREE_BYTES) {
            return true;
        }
    }
    return false;
}

// ---------------------------------------------------------------------------
// Content Manager: meta keys, item post types, gates, counts and usage.
// ---------------------------------------------------------------------------

/** Meta key of a collection's field definitions (`with_prefix('cm_fields')`). */
function kk_meta_cm_fields(): string
{
    return kk_collection_post_type() . '_fields';
}

/** Meta key of a collection's Name / Slug labels (`with_prefix('cm_basic_fields')`). */
function kk_meta_cm_basic_fields(): string
{
    return kk_collection_post_type() . '_basic_fields';
}

/** Meta key of a collection's preset type (`with_prefix('cm_preset_type')`, set by "New Dynamic Page"). */
function kk_meta_cm_preset_type(): string
{
    return kk_collection_post_type() . '_preset_type';
}

/** Meta key binding a page to a collection (`PageMetaKeys::CONTENT_MANAGER_COLLECTION_ID`). */
function kk_meta_cm_collection_id(): string
{
    return kk_const(
        'PageMetaKeys',
        name: 'CONTENT_MANAGER_COLLECTION_ID',
        fallback: 'kirki_content_manager_collection_id',
    );
}

/** Meta key of a bound page's kind, `index` or `details` (`PageMetaKeys::CONTENT_MANAGER_PAGE_KIND`). */
function kk_meta_cm_page_kind(): string
{
    return kk_const('PageMetaKeys', name: 'CONTENT_MANAGER_PAGE_KIND', fallback: 'kirki_content_manager_page_kind');
}

/** The post type of a collection's items (`ContentManager::get_child_post_post_type_value`). */
function kk_item_post_type(int $collection_id): string
{
    return sprintf('%s_%d', kk_collection_post_type(), $collection_id);
}

/** The meta key holding an item's value for a field (`ContentManager::get_child_post_meta_key_using_field_id`). */
function kk_field_meta_key(int $collection_id, string $field_id): string
{
    return sprintf('%s_field_%d_%s', kk_collection_post_type(), $collection_id, $field_id);
}

/** The collection id an item post type names, null for any other type. */
function kk_collection_id_of_type(string $post_type): ?int
{
    $prefix = kk_collection_post_type() . '_';
    if (!str_starts_with($post_type, $prefix)) {
        return null;
    }
    $rest = substr($post_type, strlen($prefix));
    if ($rest === '' || !ctype_digit($rest) || $rest[0] === '0') {
        return null;
    }
    return (int) $rest;
}

/** The reference table (`kirki_cm_reference`), prefixed. */
function kk_reference_table(): string
{
    global $wpdb;
    /** @var \wpdb $wpdb */
    return (
        $wpdb->prefix
        . (defined('KIRKI_CM_REFERENCE_TABLE') ? (string) constant('KIRKI_CM_REFERENCE_TABLE') : 'kirki_cm_reference')
    );
}

/**
 * The post gate of the collection abilities: a live `kirki_cm` post in the
 * statuses Kirki's model lists (draft, publish, future).
 */
function kk_collection_post_or_error(int $post_id): WP_Post|WP_Error
{
    if ($post_id <= 0) {
        return kk_invalid_post($post_id);
    }
    // @mago-expect analysis:mixed-assignment
    $post = get_post($post_id);
    if (!$post instanceof WP_Post || !in_array($post->post_status, ['draft', 'publish', 'future'], strict: true)) {
        return kk_invalid_post($post_id);
    }
    if ($post->post_type === kk_collection_post_type()) {
        return $post;
    }
    return new WP_Error(
        'kirki_unsupported_post_type',
        sprintf(
            /* translators: 1: post id, 2: post type */
            __(
                'Post %1$d has post type `%2$s`; the collection abilities handle Content Manager collections (`kirki_cm`) only. List them with kirki-list-collections; items are handled by kirki-get-collection-item and the item writers.',
                domain: 'novamira-pro',
            ),
            $post->ID,
            $post->post_type,
        ),
        ['status' => 422],
    );
}

/**
 * The post gate of the item abilities: a live post whose type is
 * `kirki_cm_<n>` with `post_parent` n and a live collection n. An item whose
 * collection is gone (`kirki_orphan_item`, 409) is invisible to Kirki's own
 * lists too.
 */
function kk_item_post_or_error(int $post_id): WP_Post|WP_Error
{
    if ($post_id <= 0) {
        return kk_invalid_post($post_id);
    }
    // @mago-expect analysis:mixed-assignment
    $post = get_post($post_id);
    if (!$post instanceof WP_Post || !in_array($post->post_status, ['draft', 'publish', 'future'], strict: true)) {
        return kk_invalid_post($post_id);
    }
    $collection_id = kk_collection_id_of_type($post->post_type);
    if ($collection_id === null) {
        return new WP_Error(
            'kirki_unsupported_post_type',
            sprintf(
                /* translators: 1: post id, 2: post type */
                __(
                    'Post %1$d has post type `%2$s`; the item abilities handle Content Manager items (`kirki_cm_<collection id>`) only. Find them with kirki-list-collection-items; a collection itself is handled by kirki-get-collection and the collection writers.',
                    domain: 'novamira-pro',
                ),
                $post->ID,
                $post->post_type,
            ),
            ['status' => 422],
        );
    }
    // @mago-expect analysis:mixed-assignment
    $parent = get_post($collection_id);
    if (
        (int) $post->post_parent !== $collection_id
        || !$parent instanceof WP_Post
        || $parent->post_type !== kk_collection_post_type()
        || !in_array($parent->post_status, ['draft', 'publish', 'future'], strict: true)
    ) {
        return new WP_Error(
            'kirki_orphan_item',
            sprintf(
                /* translators: 1: post id, 2: collection id */
                __(
                    'Item %1$d belongs to collection %2$d, which no longer exists (or the item\'s parent does not match its post type): Kirki lists items by their live parent, so this row is unreachable from the editor. Delete it with novamira/delete-post.',
                    domain: 'novamira-pro',
                ),
                $post->ID,
                $collection_id,
            ),
            ['status' => 409],
        );
    }
    return $post;
}

/**
 * Item counts of a collection by status, in one query. Trashed items are
 * counted too: they are real rows a forced delete destroys.
 *
 * @return array{draft: int, publish: int, future: int, trash: int, total: int}
 */
function kk_collection_item_counts(int $collection_id): array
{
    global $wpdb;
    /** @var \wpdb $wpdb */
    $counts = ['draft' => 0, 'publish' => 0, 'future' => 0, 'trash' => 0, 'total' => 0];
    // Trashed items count too: Kirki's delete removes every child row whatever
    // its status, so a collection whose items are all trashed is NOT empty and
    // the delete gate (which reads `total`) must still ask for `force`.
    // @mago-expect analysis:possibly-invalid-argument
    $sql = (string) $wpdb->prepare(
        "SELECT post_status, COUNT(*) AS n FROM {$wpdb->posts} WHERE post_type = %s AND post_parent = %d AND post_status IN ('draft', 'publish', 'future', 'trash') GROUP BY post_status",
        kk_item_post_type($collection_id),
        $collection_id,
    );
    /** @var mixed $rows */
    $rows = $wpdb->get_results($sql, 'ARRAY_A');
    /** @var mixed $row */
    foreach (is_array($rows) ? $rows : [] as $row) {
        if (!is_array($row) || !is_string($row['post_status'] ?? null) || !isset($counts[$row['post_status']])) {
            continue;
        }
        $n = kk_coerce_int_or_null($row['n'] ?? null) ?? 0;
        $counts[$row['post_status']] = $n;
        $counts['total'] += $n;
    }
    return [
        'draft' => $counts['draft'],
        'publish' => $counts['publish'],
        'future' => $counts['future'],
        'trash' => $counts['trash'],
        'total' => $counts['total'],
    ];
}

/**
 * Reference rows (`kirki_cm_reference`) matching the given columns.
 *
 * @param array<string, int|string|list<int>|list<string>> $where column => value or list of values
 * @return list<array{id: int, post_id: int, field_meta_key: string, ref_post_id: int}>
 */
// @mago-expect lint:cyclomatic-complexity -- the WHERE builder and the row mapper, flat
function kk_reference_rows(array $where): array
{
    global $wpdb;
    /** @var \wpdb $wpdb */
    $clauses = [];
    $params = [];
    foreach ($where as $column => $value) {
        if (!in_array($column, ['post_id', 'field_meta_key', 'ref_post_id'], strict: true)) {
            continue;
        }
        $values = is_array($value) ? array_values($value) : [$value];
        if ($values === []) {
            return [];
        }
        $placeholder = $column === 'field_meta_key' ? '%s' : '%d';
        $clauses[] = sprintf('%s IN (%s)', $column, implode(', ', array_fill(0, count($values), $placeholder)));
        foreach ($values as $one) {
            $params[] = $one;
        }
    }
    if ($clauses === []) {
        return [];
    }
    $table = kk_reference_table();
    // @mago-expect analysis:possibly-invalid-argument
    $sql = (string) $wpdb->prepare(
        "SELECT id, post_id, field_meta_key, ref_post_id FROM {$table} WHERE "
        . implode(' AND ', $clauses)
        . ' ORDER BY id ASC',
        ...$params,
    );
    /** @var mixed $rows */
    $rows = $wpdb->get_results($sql, 'ARRAY_A');
    $out = [];
    /** @var mixed $row */
    foreach (is_array($rows) ? $rows : [] as $row) {
        if (!is_array($row) || !is_string($row['field_meta_key'] ?? null)) {
            continue;
        }
        $out[] = [
            'id' => kk_coerce_int_or_null($row['id'] ?? null) ?? 0,
            'post_id' => kk_coerce_int_or_null($row['post_id'] ?? null) ?? 0,
            'field_meta_key' => $row['field_meta_key'],
            'ref_post_id' => kk_coerce_int_or_null($row['ref_post_id'] ?? null) ?? 0,
        ];
    }
    return $out;
}

/**
 * Items whose reference fields point at `$item_id` (their rows cascade away
 * when the item is deleted).
 *
 * @return list<array{item_id: int, collection_id: int, field_id: string, title: string, status: string}>
 */
function kk_item_referenced_by(int $item_id): array
{
    $out = [];
    foreach (kk_reference_rows(['ref_post_id' => $item_id]) as $row) {
        // @mago-expect analysis:mixed-assignment
        $post = get_post($row['post_id']);
        if (!$post instanceof WP_Post) {
            continue;
        }
        $collection_id = kk_collection_id_of_type($post->post_type) ?? 0;
        $prefix = sprintf('%s_field_%d_', kk_collection_post_type(), $collection_id);
        $out[] = [
            'item_id' => $post->ID,
            'collection_id' => $collection_id,
            'field_id' => str_starts_with($row['field_meta_key'], $prefix)
                ? substr($row['field_meta_key'], strlen($prefix))
                : $row['field_meta_key'],
            'title' => $post->post_title,
            'status' => $post->post_status,
        ];
    }
    return $out;
}

/**
 * Where a collection is used outside its items: templates whose stored
 * conditions name the item post type, pages bound through
 * `kirki_content_manager_collection_id` (index / details pages), and the
 * OTHER collections whose reference fields point at its items. Kirki leaves
 * templates and pages in place when the collection is deleted; the reference
 * rows go with the items (`ON DELETE CASCADE`), so those values read empty.
 *
 * @return array{templates: list<array{post_id: int, title: string, status: string}>, pages: list<array{post_id: int, title: string, status: string, kind: string}>, referencing_items: list<array{collection_id: int, collection_title: string, items: int, rows: int, sample_title: string}>}
 */
// @mago-expect lint:cyclomatic-complexity -- three queries, three row mappers
function kk_collection_references(int $collection_id): array
{
    global $wpdb;
    /** @var \wpdb $wpdb */
    $type = kk_item_post_type($collection_id);
    $templates = [];
    $needle = '%' . $wpdb->esc_like(sprintf('s:%d:"%s";', strlen($type), $type)) . '%';
    // @mago-expect analysis:possibly-invalid-argument
    $sql = (string) $wpdb->prepare(
        "SELECT p.ID, p.post_title, p.post_status FROM {$wpdb->postmeta} m INNER JOIN {$wpdb->posts} p ON p.ID = m.post_id WHERE m.meta_key = %s AND m.meta_value LIKE %s AND p.post_type = %s AND p.post_status <> 'trash' ORDER BY p.ID ASC LIMIT %d",
        kk_meta_template_conditions(),
        $needle,
        kk_const('PostTypes', name: 'TEMPLATE', fallback: 'kirki_template'),
        KK_USAGE_ROWS,
    );
    /** @var mixed $rows */
    $rows = $wpdb->get_results($sql, 'ARRAY_A');
    /** @var mixed $row */
    foreach (is_array($rows) ? $rows : [] as $row) {
        if (!is_array($row)) {
            continue;
        }
        $templates[] = [
            'post_id' => kk_coerce_int_or_null($row['ID'] ?? null) ?? 0,
            'title' => is_string($row['post_title'] ?? null) ? $row['post_title'] : '',
            'status' => is_string($row['post_status'] ?? null) ? $row['post_status'] : '',
        ];
    }
    $pages = [];
    // @mago-expect analysis:possibly-invalid-argument
    $sql = (string) $wpdb->prepare(
        "SELECT p.ID, p.post_title, p.post_status, k.meta_value AS kind FROM {$wpdb->postmeta} m INNER JOIN {$wpdb->posts} p ON p.ID = m.post_id LEFT JOIN {$wpdb->postmeta} k ON k.post_id = p.ID AND k.meta_key = %s WHERE m.meta_key = %s AND m.meta_value = %s AND p.post_status <> 'trash' ORDER BY p.ID ASC LIMIT %d",
        kk_meta_cm_page_kind(),
        kk_meta_cm_collection_id(),
        (string) $collection_id,
        KK_USAGE_ROWS,
    );
    /** @var mixed $rows */
    $rows = $wpdb->get_results($sql, 'ARRAY_A');
    /** @var mixed $row */
    foreach (is_array($rows) ? $rows : [] as $row) {
        if (!is_array($row)) {
            continue;
        }
        $pages[] = [
            'post_id' => kk_coerce_int_or_null($row['ID'] ?? null) ?? 0,
            'title' => is_string($row['post_title'] ?? null) ? $row['post_title'] : '',
            'status' => is_string($row['post_status'] ?? null) ? $row['post_status'] : '',
            'kind' => is_string($row['kind'] ?? null) ? $row['kind'] : '',
        ];
    }
    return [
        'templates' => $templates,
        'pages' => $pages,
        'referencing_items' => kk_collection_referencing_items($collection_id),
    ];
}

/**
 * The other collections whose items hold a reference to an item of this one,
 * grouped by referring collection (its own items are left out: they go with
 * the delete anyway). `wp_kirki_cm_reference` cascades on the item row, so
 * these values silently become empty when the collection is deleted.
 *
 * @return list<array{collection_id: int, collection_title: string, items: int, rows: int, sample_title: string}>
 */
function kk_collection_referencing_items(int $collection_id): array
{
    global $wpdb;
    /** @var \wpdb $wpdb */
    $reference = kk_reference_table();
    // @mago-expect analysis:possibly-invalid-argument
    $sql = (string) $wpdb->prepare(
        sprintf(
            'SELECT c.ID AS collection_id, c.post_title AS collection_title, COUNT(*) AS rows_count, COUNT(DISTINCT r.post_id) AS items, MIN(p.post_title) AS sample_title FROM %1$s r INNER JOIN %2$s target ON target.ID = r.ref_post_id AND target.post_type = %%s AND target.post_parent = %%d INNER JOIN %2$s p ON p.ID = r.post_id INNER JOIN %2$s c ON c.ID = p.post_parent AND c.post_type = %%s AND c.ID <> %%d GROUP BY c.ID, c.post_title ORDER BY c.ID ASC LIMIT %%d',
            $reference,
            $wpdb->posts,
        ),
        kk_item_post_type($collection_id),
        $collection_id,
        kk_collection_post_type(),
        $collection_id,
        KK_USAGE_ROWS,
    );
    /** @var mixed $rows */
    $rows = $wpdb->get_results($sql, 'ARRAY_A');
    $out = [];
    /** @var mixed $row */
    foreach (is_array($rows) ? $rows : [] as $row) {
        if (!is_array($row)) {
            continue;
        }
        $out[] = [
            'collection_id' => kk_coerce_int_or_null($row['collection_id'] ?? null) ?? 0,
            'collection_title' => is_string($row['collection_title'] ?? null) ? $row['collection_title'] : '',
            'items' => kk_coerce_int_or_null($row['items'] ?? null) ?? 0,
            'rows' => kk_coerce_int_or_null($row['rows_count'] ?? null) ?? 0,
            'sample_title' => is_string($row['sample_title'] ?? null) ? $row['sample_title'] : '',
        ];
    }
    return $out;
}

/**
 * Register a collection's item post type the way Kirki's `init` hook does
 * (`ContentManager::register_parent_post_type`: public, no admin UI, rewrite
 * slug = the collection slug), so a collection created in this request has
 * permalinks and a viewable type before the next request. No-op when the type
 * is already registered with the collection's slug; re-registered when the
 * slug changed (so the rewrite flush that follows uses the new base).
 */
function kk_register_item_post_type(WP_Post $collection): void
{
    $type = strtolower(kk_item_post_type($collection->ID));
    if ($type === '') {
        return;
    }
    $existing = get_post_type_object($type);
    if ($existing !== null) {
        $rewrite = is_array($existing->rewrite) ? $existing->rewrite : [];
        if (($rewrite['slug'] ?? null) === $collection->post_name) {
            return;
        }
        // Registered at init with the previous slug: re-register so a flush uses the new base.
        unregister_post_type($type);
    }
    register_post_type($type, [
        'public' => true,
        'show_ui' => false,
        'label' => $collection->post_title,
        'rewrite' => ['slug' => $collection->post_name],
    ]);
}

/**
 * Whether the stored rewrite rules route `/<slug>/<item slug>/` to the
 * collection's items. Kirki registers the item type with a rewrite slug; the
 * item URLs resolve once the rewrite rules are flushed, and the writers here
 * flush them right away. null when the site uses plain permalinks (the item
 * URLs are then `?kirki_cm_<id>=<slug>` and always work).
 */
function kk_collection_pretty_urls(WP_Post $collection): ?bool
{
    if ((string) get_option('permalink_structure', default_value: '') === '') {
        return null;
    }
    /** @var mixed $rules */
    $rules = get_option('rewrite_rules');
    if (!is_array($rules)) {
        return false;
    }
    $prefix = $collection->post_name . '/([^/]+)';
    $type = kk_item_post_type($collection->ID);
    /** @var mixed $target */
    foreach ($rules as $pattern => $target) {
        if (
            is_string($pattern)
            && str_starts_with($pattern, $prefix)
            && is_string($target)
            && str_contains($target, $type . '=')
        ) {
            return true;
        }
    }
    return false;
}

/** The public URL pattern of a collection's items. */
function kk_collection_item_url_pattern(WP_Post $collection): string
{
    if ((string) get_option('permalink_structure', default_value: '') === '') {
        return add_query_arg([kk_item_post_type($collection->ID) => '<item slug>'], home_url('/'));
    }
    return home_url('/' . $collection->post_name . '/<item slug>/');
}
