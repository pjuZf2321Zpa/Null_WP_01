<?php

// SPDX-FileCopyrightText: 2026 Ovation S.r.l. <dev@novamira.ai>
// SPDX-License-Identifier: AGPL-3.0-or-later

declare(strict_types=1);

namespace Novamira\Pro\Abilities\Kirki;

use WP_Error;

/**
 * Ability: Get the Kirki element tree of a post as a compact nested summary.
 */

if (!defined('ABSPATH')) {
    exit();
}

wp_register_ability('novamira/kirki-get-content', [
    'label' => __('Get Kirki Content', domain: 'novamira-pro'),
    'description' => __(
        'Returns the Kirki element tree of a page, post, template, utility page or popup as a nested summary: per node `{id, name, title, tag, text, classes, hidden?, child_count, children, children_truncated?, symbol_id?, symbol_missing?, dynamic?, access?}`. `text` is the stored text as the renderer assembles it: a leaf\'s `contents` with inline runs (bold) resolved and hidden ones skipped, or, for nodes with children (containers, buttons, links), the text of their text descendants; truncated to `max_text_chars`. `classes` lists the class names the node carries (its style blocks, page-local and global, lower-cased with spaces turned into `-` as the renderer does, plus free-form classes), with unknown style-block ids reported as `?<id>`. A `symbol` node reports `symbol_id` (its content lives in that kirki_symbol post); a node bound to dynamic content reports `dynamic: true` (visitors see the dynamic value or nothing, never the stored text); a node restricted with `properties.access` reports `access` (the renderer prints it only for visitors that pass that check: all, guest, logged-in, admin, editor, author, subscriber) and `hidden_for_everyone: true` when the value is one Kirki does not know (then NO visitor sees it). `text` is the STORED text: Kirki decodes HTML entities and expands shortcodes on the page, and prints the dynamic value (or nothing) instead of `contents` for nodes with `dynamic: true`. Placeholder rows count against `max_nodes`. Children that cannot be walked appear as `?missing` / `?corrupt` / `?cycle` rows. Reads the PUBLISHED tree by default; pass `staging_version` to read a staged draft (versions come from `staging`, also returned here). `editor_open` tells whether a Kirki editor tab currently has the post open (its next save overwrites the tree). Popups are returned too (their flat node map starts at the `popup` element; write them with kirki-set-popup-content / kirki-edit-popup-settings, the page element writers refuse them). Use `node_id` to start from a subtree and `depth` to limit the walk; call kirki-get-element for the full raw node, and `include_style_blocks: true` for the page-local style-block map exactly as stored (what kirki-set-content expects back).',
        domain: 'novamira-pro',
    ),
    'category' => 'kirki',
    'input_schema' => [
        'type' => 'object',
        'properties' => [
            'post_id' => ['type' => 'integer', 'description' => 'Id of a post in Kirki editor mode.'],
            'staging_version' => [
                'type' => 'integer',
                'description' => 'Read this staged version instead of the published tree. The version flagged as published resolves to the published tree.',
            ],
            'node_id' => [
                'type' => 'string',
                'description' => 'Start the walk at this node instead of the root.',
            ],
            'depth' => [
                'type' => 'integer',
                'description' => 'Levels below the start node to include. -1 (default) walks the entire subtree; 0 returns only the start node; 1 adds its direct children.',
                'default' => -1,
            ],
            'max_nodes' => [
                'type' => 'integer',
                'minimum' => 1,
                'maximum' => 5000,
                'description' => 'Cap on summary rows. The walk is depth-first in document order and stops adding rows at the cap: the response then has `truncated: true` and every container whose children were cut carries `children_truncated: true` (its `child_count` is still the real number); continue with `node_id` on such a container. Default 500, max 5000 (about 600 KB of JSON).',
                'default' => 500,
            ],
            'max_text_chars' => [
                'type' => 'integer',
                'minimum' => 0,
                'description' => 'Characters of `text` kept per node. Default 120.',
                'default' => 120,
            ],
            'include_style_blocks' => [
                'type' => 'boolean',
                'description' => 'Also return `style_blocks`: the page-local style-block map of the source exactly as stored (ids, `name` as string or list, `variant` CSS, editor flags). Default false.',
                'default' => false,
            ],
        ],
        'required' => ['post_id'],
        'additionalProperties' => false,
    ],
    'output_schema' => [
        'type' => 'object',
        'properties' => [
            'post_id' => ['type' => 'integer'],
            'source' => [
                'type' => 'object',
                'description' => '`{kind: published|staged, version}` — which copy of the tree was read.',
            ],
            'root_id' => ['type' => ['string', 'null']],
            'has_blocks' => ['type' => 'boolean'],
            'tree' => ['type' => ['object', 'null']],
            'total_nodes' => [
                'type' => 'integer',
                'description' => 'Nodes in the whole tree (not only the returned subtree).',
            ],
            'returned_nodes' => ['type' => 'integer'],
            'truncated' => ['type' => 'boolean'],
            'style_blocks_count' => ['type' => 'integer'],
            'style_blocks' => [
                'type' => 'object',
                'description' => 'The stored page-local style-block map (only with `include_style_blocks`).',
            ],
            'fonts' => ['type' => 'array', 'items' => ['type' => 'string']],
            'staging' => [
                'type' => 'object',
                'description' => 'Ledger summary as kirki-list-pages reports it: versions, published_version, unpublished_versions (drafts newer than the published tree), last_updated.',
            ],
            'editor_open' => [
                'type' => ['object', 'null'],
                'description' => '`{sessions, newest_age_seconds}` from Kirki\'s collaboration heartbeat; null when Kirki\'s table is missing.',
            ],
        ],
        'required' => [
            'post_id',
            'source',
            'root_id',
            'has_blocks',
            'tree',
            'total_nodes',
            'returned_nodes',
            'truncated',
            'style_blocks_count',
            'fonts',
            'staging',
            'editor_open',
        ],
        'additionalProperties' => false,
    ],
    'execute_callback' => 'Novamira\\Pro\\Abilities\\Kirki\\kirki_get_content',
    'permission_callback' => 'novamira_permission_callback',
    'meta' => [
        'show_in_rest' => true,
        'mcp' => ['public' => true],
        'annotations' => [
            'instructions' => 'Start with the default (published tree, `max_nodes` 500): a real editor page holds 1 000-3 000 nodes, so expect `truncated: true` and continue from the containers flagged `children_truncated` with `node_id`, or raise `max_nodes` (5 000 rows ≈ 600 KB). Nesting is summarised down to 64 levels. A `?k-…` entry in `classes` means the node points at a style block that does not exist in this source: the frontend drops it silently. When `staging.unpublished_versions` > 0 and the user talks about what they see in the editor, read that staging_version, not the published tree. When a published kirki_template matches the post (details templates of Content Manager items, templates with conditions), visitors see the template, not this tree.',
            'readonly' => true,
            'destructive' => false,
            'idempotent' => true,
        ],
    ],
]);

/**
 * @param array<string, mixed> $input
 * @return array<string, mixed>|WP_Error
 */
// @mago-expect lint:cyclomatic-complexity -- gate checks + version resolution + cap fallback, each a flat early return
// @mago-expect lint:halstead
function kirki_get_content(array $input): array|WP_Error
{
    kk_begin();
    $post_id = kk_coerce_int_or_null($input['post_id'] ?? null) ?? 0;
    $post = kk_post_or_error($post_id);
    if ($post instanceof WP_Error) {
        return $post;
    }
    if (!kk_is_kirki_mode($post_id)) {
        return kk_not_kirki_mode($post_id);
    }
    $version = kk_coerce_int_or_null($input['staging_version'] ?? null);
    $source = kk_blocks_for_version($post_id, $version);
    if ($source instanceof WP_Error) {
        return $source;
    }
    $local_styles = kk_style_blocks_for_version($post_id, $version);
    if ($local_styles instanceof WP_Error) {
        return $local_styles;
    }
    $styles = kk_effective_styles($post_id, $version, $local_styles);

    $base = [
        'post_id' => $post_id,
        'source' => ['kind' => $source['kind'], 'version' => $source['version']],
        'root_id' => null,
        'has_blocks' => false,
        'tree' => null,
        'total_nodes' => 0,
        'returned_nodes' => 0,
        'truncated' => false,
        'style_blocks_count' => count($local_styles),
        'fonts' => array_map(
            static fn(string $font): string => kk_truncate($font, max: 120),
            kk_fonts_for_version($post_id, $version),
        ),
        'staging' => kk_staging_info($post_id),
        'editor_open' => kk_open_editor_sessions($post_id),
    ];
    if (kk_bool($input['include_style_blocks'] ?? false)) {
        // As stored: `name` may be a list (combo class), editor flags kept — what set-content expects back.
        $base['style_blocks'] = $local_styles;
    }
    $blocks = $source['blocks'];
    if ($blocks === null || $blocks === []) {
        return $base;
    }
    $root_id = kk_root_id($blocks);
    $base['root_id'] = $root_id;
    $base['has_blocks'] = true;
    $base['total_nodes'] = count($blocks);
    if ($root_id === null) {
        return kk_invalid_input(__(
            'The stored tree has no root node (every node has a parentId); Kirki cannot render it.',
            domain: 'novamira-pro',
        ));
    }

    /** @var mixed $raw_start */
    $raw_start = $input['node_id'] ?? null;
    $start = is_string($raw_start) ? $raw_start : $root_id;
    if (!isset($blocks[$start]) || !is_array($blocks[$start])) {
        return kk_unknown_node($start);
    }

    $ctx = [
        'blocks' => $blocks,
        'styles' => $styles,
        'max_nodes' => min(5000, max(1, kk_coerce_int_or_null($input['max_nodes'] ?? null) ?? 500)),
        'max_text' => max(0, kk_coerce_int_or_null($input['max_text_chars'] ?? null) ?? 120),
        'depth_capped' => false,
    ];
    $depth = kk_coerce_int_or_null($input['depth'] ?? null) ?? -1;
    // The REST encoder fails past 253 nesting levels (two per node): cap the walk.
    $ctx['depth_capped'] = $depth < 0 || $depth > KK_SUMMARY_MAX_DEPTH;
    $depth = $ctx['depth_capped'] ? KK_SUMMARY_MAX_DEPTH : $depth;
    $walk = ['count' => 0, 'visited' => [], 'truncated' => false];
    $base['tree'] = kk_summarize_node($start, $ctx, $depth, $walk);
    $base['returned_nodes'] = $walk['count'];
    $base['truncated'] = $walk['truncated'];
    return $base;
}

/**
 * Placeholder row for a child the walk cannot descend into: missing entry,
 * corrupt entry, or a cycle back to an ancestor (Kirki's renderer recurses
 * forever on the latter).
 *
 * @return array<string, mixed>
 */
function kk_placeholder_row(string $id, string $reason): array
{
    return [
        'id' => kk_truncate($id, max: 64),
        'name' => $reason,
        'title' => '',
        'tag' => null,
        'classes' => [],
        'child_count' => 0,
    ];
}

/**
 * Nested summary of a node, depth-first in document order. When `max_nodes`
 * rows have been emitted the remaining children are cut: the container gets
 * `children_truncated: true` and `$truncated` is raised (a nested `tree`
 * deeper than KK_SUMMARY_MAX_DEPTH is cut the same way). Children that
 * cannot be walked (missing, corrupt, or already on the current path — a
 * cycle) become `?missing` / `?corrupt` / `?cycle` placeholder rows.
 *
 * @param array{blocks: array<string, mixed>, styles: array<string, array<string, mixed>>, max_nodes: int, max_text: int, depth_capped: bool} $ctx
 * @param array{count: int, visited: array<string, true>, truncated: bool} $walk rows emitted, ids on the current path, cap hit (mutated)
 * @return array<string, mixed>|null null only when the start node itself is not a node
 */
function kk_summarize_node(string $id, array $ctx, int $depth, array &$walk): ?array
{
    $blocks = $ctx['blocks'];
    if (!isset($blocks[$id]) || !is_array($blocks[$id])) {
        return null;
    }
    ++$walk['count'];
    $walk['visited'][$id] = true;
    /** @var array<string, mixed> $node */
    $node = $blocks[$id];
    $child_ids = kk_node_child_ids($node);
    $row = kk_node_row($id, $node, $ctx);
    $row['child_count'] = count($child_ids);
    $raw_children = isset($node['children']) && is_array($node['children']) ? $node['children'] : [];
    if ($raw_children === []) {
        unset($walk['visited'][$id]);
        return $row;
    }
    if ($depth === 0) {
        unset($walk['visited'][$id]);
        if ($ctx['depth_capped']) {
            // The caller asked for the whole subtree; the summary depth cap cut it here.
            $row['children_truncated'] = true;
            $walk['truncated'] = true;
        }
        return $row;
    }
    $children = [];
    /** @var mixed $child_id */
    foreach ($raw_children as $child_id) {
        if ($walk['count'] >= $ctx['max_nodes']) {
            // Placeholder rows count against `max_nodes` too: a node listing
            // 400k missing children must not turn into a 33 MB response.
            $row['children_truncated'] = true;
            $walk['truncated'] = true;
            break;
        }
        $placeholder = kk_child_placeholder($child_id, $blocks, $walk['visited']);
        if ($placeholder !== null) {
            ++$walk['count'];
            $children[] = $placeholder;
            continue;
        }
        /** @var string $child_id */
        $child_row = kk_summarize_node($child_id, $ctx, $depth - 1, $walk);
        if ($child_row !== null) {
            $children[] = $child_row;
        }
    }
    unset($walk['visited'][$id]);
    $row['children'] = $children;
    return $row;
}

/**
 * The placeholder row for a child the walk cannot descend into, or null when
 * the child is a real node not on the current path.
 *
 * @param array<string, mixed> $blocks
 * @param array<string, true> $visited
 * @return array<string, mixed>|null
 */
function kk_child_placeholder(mixed $child_id, array $blocks, array $visited): ?array
{
    if (!is_string($child_id)) {
        return kk_placeholder_row('(non-string entry)', reason: '?corrupt');
    }
    if (isset($visited[$child_id])) {
        return kk_placeholder_row($child_id, reason: '?cycle');
    }
    if (!isset($blocks[$child_id])) {
        return kk_placeholder_row($child_id, reason: '?missing');
    }
    if (!is_array($blocks[$child_id])) {
        return kk_placeholder_row($child_id, reason: '?corrupt');
    }
    return null;
}

/**
 * The flat summary fields of one node (no children).
 *
 * @param array<string, mixed> $node
 * @param array{blocks: array<string, mixed>, styles: array<string, array<string, mixed>>, max_nodes: int, max_text: int, depth_capped: bool} $ctx
 * @return array<string, mixed>
 */
function kk_node_row(string $id, array $node, array $ctx): array
{
    /** @var mixed $name */
    $name = $node['name'] ?? '';
    $row = [
        'id' => $id,
        'name' => kk_truncate(is_string($name) ? $name : '', max: 64),
        'title' => kk_truncate(kk_node_title($node), max: 120),
        'tag' => kk_node_tag($node),
        'classes' => array_map(
            static fn(string $c): string => kk_truncate($c, max: 120),
            kk_node_classes($node, $ctx['styles']),
        ),
    ];
    if ($row['tag'] !== null) {
        $row['tag'] = kk_truncate($row['tag'], max: 32);
    }
    $text = kk_node_text($node, $ctx['blocks']);
    if ($text !== '' && $ctx['max_text'] > 0) {
        $row['text'] = kk_truncate($text, $ctx['max_text']);
    }
    return array_merge($row, kk_node_row_flags($node));
}

/**
 * The optional flags of a summary row: `hidden`, `access`, `symbol_id`, `dynamic`.
 *
 * @param array<string, mixed> $node
 * @return array<string, mixed>
 */
// @mago-expect lint:cyclomatic-complexity -- one optional flag per branch
function kk_node_row_flags(array $node): array
{
    $flags = [];
    if (isset($node['hide']) && $node['hide'] === true) {
        $flags['hidden'] = true;
    }
    if (
        isset($node['properties'])
        && is_array($node['properties'])
        && array_key_exists('access', $node['properties'])
    ) {
        /** @var mixed $access */
        $access = $node['properties']['access'];
        // The renderer prints the node only for visitors `is_element_accessible`
        // accepts; any value outside its list (`''`, `ALL`, a role name…) hides it from everyone.
        if ($access !== null && $access !== 'all') {
            $flags['access'] = is_string($access) ? kk_truncate($access, max: 32) : '?' . gettype($access);
            if (!is_string($access) || !in_array($access, KK_ACCESS_VALUES, strict: true)) {
                $flags['hidden_for_everyone'] = true;
            }
        }
    }
    if (($node['name'] ?? null) === 'symbol') {
        // Content lives in the referenced kirki_symbol post (kirki-list-symbols).
        $symbol_id = kk_coerce_int_or_null($node['properties']['symbolId'] ?? null);
        $flags['symbol_id'] = $symbol_id;
        if ($symbol_id === null || $symbol_id <= 0 || get_post_type($symbol_id) !== kk_symbol_post_type()) {
            // Kirki deletes symbols permanently; the instance stays and prints nothing.
            $flags['symbol_missing'] = true;
        }
    }
    /** @var mixed $dynamic */
    $dynamic = $node['properties']['dynamicContent'] ?? null;
    if (is_array($dynamic) && $dynamic !== []) {
        $flags['dynamic'] = true;
    }
    return $flags;
}
