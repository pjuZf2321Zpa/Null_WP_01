<?php

// SPDX-FileCopyrightText: 2026 Ovation S.r.l. <dev@novamira.ai>
// SPDX-License-Identifier: AGPL-3.0-or-later

declare(strict_types=1);

namespace Novamira\Pro\Abilities\Kirki;

use WP_Error;
use WP_Post;
use WP_Term;
use WP_User;

/**
 * Abilities: Kirki template display conditions (write) and template
 * resolution (read).
 *
 * Kirki stores a template's conditions in `kirki_template_conditions` and
 * evaluates them in `HelperFunctions::find_template_for_this_context`:
 * published templates newest first (window = `Page::fetch_list` default, the
 * newest first by post id, `page_on_front` promoted when it names one), the
 * FIRST whose conditions match the context wins.
 * The editor rewrites the whole list at template creation and on every Save
 * of the template, so the per-post editor gate applies to conditions too.
 */

if (!defined('ABSPATH')) {
    exit();
}

// Load order: this file's schemas use constants defined in other ability files of the folder; require them
// explicitly so the folder's alphabetical load order does not decide whether this file loads.
require_once __DIR__ . '/tree.php'; // KK_ALLOW_OPEN_EDITOR_SCHEMA

// ---------------------------------------------------------------------------
// set-template-conditions
// ---------------------------------------------------------------------------

wp_register_ability('novamira/kirki-set-template-conditions', [
    'label' => __('Set Kirki Template Conditions', domain: 'novamira-pro'),
    'description' => __(
        'Replaces the display conditions of a Kirki template (`kirki_template` post) with the given list, evaluated by Kirki in order: `{from: post|term|user, type: "*"|post|user, post_type, where: "*"|single|<taxonomy>|role, to: "*"|<post id (integer)>|<term id or slug>|<role>, visibility: show|hide}` (the same shape kirki-create-page accepts). Written in one transaction under the post lock, read back and verified. The response returns the conditions as Kirki will read them (normalised rows with `effective` / `note`), the template\'s `resolution_rank` / `considered` in Kirki\'s evaluation order and warnings: templates ranked above it that already cover the same target, a list with no `show` entry (it can never render), two entries fighting over one target, and a taxonomy entry whose `post_type` is not the one Kirki resolves for that taxonomy (its first registered owner), which can never match. Refused while a Kirki editor tab is open on the template (`kirki_editor_open`): the tab re-writes the conditions with its next Save.',
        domain: 'novamira-pro',
    ),
    'category' => 'kirki',
    'input_schema' => [
        'type' => 'object',
        'properties' => [
            'post_id' => ['type' => 'integer', 'description' => 'The `kirki_template` post.'],
            'conditions' => [
                'type' => 'array',
                'items' => ['type' => 'object'],
                'description' => 'Non-empty list, replaces the stored one. Entire site: `{"type":"*","visibility":"show"}`; every post of a type: `{"type":"post","post_type":"post","where":"*"}`; one post: `{"type":"post","post_type":"page","where":"single","to":<id>}`; posts with a term: `{"type":"post","post_type":"post","where":"category","to":<term id or slug>}` (or `"*"` for any term); term archives: `{"from":"term","type":"post","post_type":"post","where":"category","to":"*"}`; author pages: `{"type":"user","where":"role","to":"editor"}` (or `"where":"*"`). `visibility: hide` on a single post / a term stops the template for that target; on the entire site or a whole type it only cancels earlier `show` entries.',
            ],
            'allow_open_editor' => KK_ALLOW_OPEN_EDITOR_SCHEMA,
        ],
        'required' => ['post_id', 'conditions'],
        'additionalProperties' => false,
    ],
    'output_schema' => [
        'type' => 'object',
        'properties' => [
            'post_id' => ['type' => 'integer'],
            'status' => [
                'type' => 'string',
                'description' => 'Post status: only `publish` templates take part in resolution.',
            ],
            'conditions' => [
                'type' => 'array',
                'items' => ['type' => 'object'],
                'description' => 'The stored conditions normalised as kirki-list-templates returns them.',
            ],
            'resolution_rank' => [
                'type' => ['integer', 'null'],
                'description' => 'Position in Kirki\'s evaluation order (1 = first), null for unpublished templates.',
            ],
            'considered' => [
                'type' => 'boolean',
                'description' => 'Whether the rank is inside Kirki\'s resolution window.',
            ],
            'warnings' => ['type' => 'array', 'items' => ['type' => 'string']],
        ],
        'required' => ['post_id', 'status', 'conditions', 'resolution_rank', 'considered', 'warnings'],
        'additionalProperties' => false,
    ],
    'execute_callback' => 'Novamira\\Pro\\Abilities\\Kirki\\kirki_set_template_conditions',
    'permission_callback' => 'novamira_permission_callback',
    'meta' => [
        'show_in_rest' => true,
        'mcp' => ['public' => true],
        'annotations' => [
            'instructions' => 'Read the current list with kirki-list-templates first: this replaces it entirely. After writing, confirm with kirki-resolve-template on a real post / term / author that Kirki picks this template — a newer published template with an entire-site or same-type `show` entry wins over it whatever you write (the response warns). Templates apply only when published (flip the status with novamira/update-post) and only inside the resolution window (`considered`).',
            'readonly' => false,
            'destructive' => false,
            'idempotent' => true,
        ],
    ],
]);

/**
 * @param array<string, mixed> $input
 * @return array<string, mixed>|WP_Error
 */
function kirki_set_template_conditions(array $input): array|WP_Error
{
    kk_begin();
    $post_id = kk_coerce_int_or_null($input['post_id'] ?? null) ?? 0;
    $post = kk_template_post_or_error($post_id);
    if ($post instanceof WP_Error) {
        return $post;
    }
    $conditions = kk_validate_conditions($input['conditions'] ?? null);
    if ($conditions instanceof WP_Error) {
        return $conditions;
    }
    $open = kk_refuse_open_editor($post_id, $input['allow_open_editor'] ?? false);
    if ($open instanceof WP_Error) {
        return $open;
    }
    $written = kk_with_post_lock($post_id, static function () use ($post_id, $conditions): bool|WP_Error {
        if (kk_live_post($post_id) === null) {
            return kk_invalid_post($post_id);
        }
        return kk_write_meta_verified($post_id, [kk_meta_template_conditions() => $conditions]);
    });
    if ($written instanceof WP_Error) {
        return $written;
    }
    return kk_template_conditions_report($post, $conditions);
}

/**
 * The response of set-template-conditions: normalised rows, rank, warnings.
 *
 * @param list<array<string, mixed>> $conditions
 * @return array<string, mixed>
 */
function kk_template_conditions_report(WP_Post $post, array $conditions): array
{
    $window_info = kk_template_resolution_window_info();
    $window = $window_info['window'];
    $ranks = kk_template_resolution_ranks($post->post_type, $window);
    $rank = $ranks[$post->ID] ?? null;
    $rows = [];
    $warnings = [];
    foreach ($conditions as $index => $condition) {
        $row = kk_normalize_condition($condition);
        $rows[] = $row;
        if ($row['note'] !== null) {
            $warnings[] = sprintf('Condition %d: %s.', $index, $row['note']);
        }
    }
    clean_post_cache($post->ID);
    // @mago-expect analysis:mixed-assignment
    $fresh = get_post($post->ID);
    $status = $fresh instanceof WP_Post ? $fresh->post_status : $post->post_status;
    if ($status !== 'publish') {
        $warnings[] = sprintf(
            'Template %d is `%s`: Kirki evaluates published templates only, so these conditions apply to nothing until it is published.',
            $post->ID,
            $status,
        );
    }
    $considered = $rank !== null && $rank <= $window;
    if ($rank !== null && !$considered) {
        $warnings[] = sprintf(
            'Template %d is ranked %d, outside Kirki\'s resolution window of %d: it is never evaluated on the frontend.',
            $post->ID,
            $rank,
            $window,
        );
    }
    $warnings = array_merge($warnings, kk_conditions_self_warnings($rows));
    if ($considered) {
        $warnings = array_merge($warnings, kk_conditions_overlap_warnings($post->ID, $rows, $ranks, $window));
    }
    return [
        'post_id' => $post->ID,
        'status' => $status,
        'conditions' => $rows,
        'resolution_rank' => $rank,
        'considered' => $considered,
        'warnings' => $warnings,
    ];
}

/**
 * Warnings about published templates Kirki evaluates BEFORE this one whose
 * `show` entries already cover a target of the given conditions: an
 * entire-site entry covers everything, a whole-type entry covers every
 * condition of that post type. Kirki stops at the first match, so this
 * template never renders for those targets.
 *
 * @param list<array<string, mixed>> $rows normalised conditions of the template
 * @param array<int, int> $ranks
 * @return list<string>
 */
// @mago-expect lint:cyclomatic-complexity -- rank filter, condition filter, coverage test
function kk_conditions_overlap_warnings(int $post_id, array $rows, array $ranks, int $window): array
{
    $own_rank = $ranks[$post_id] ?? PHP_INT_MAX;
    $above = [];
    foreach ($ranks as $other_id => $rank) {
        if ($other_id === $post_id || $rank >= $own_rank || $rank > $window) {
            continue;
        }
        $above[$other_id] = $rank;
    }
    if ($above === []) {
        return [];
    }
    $meta = kk_list_meta(array_keys($above), [kk_meta_template_conditions()], inline_bytes: KK_LIST_TREE_BYTES);
    $post_types = [];
    foreach ($rows as $row) {
        if ($row['type'] !== 'post' || !is_string($row['post_type']) || $row['from'] === 'term') {
            continue;
        }
        $post_types[$row['post_type']] = true;
    }
    $warnings = [];
    foreach ($above as $other_id => $rank) {
        /** @var mixed $raw */
        $raw = $meta[$other_id][kk_meta_template_conditions()]['value'] ?? null;
        if (!is_array($raw)) {
            continue;
        }
        /** @var mixed $condition */
        foreach ($raw as $condition) {
            if (!is_array($condition)) {
                continue;
            }
            $other = kk_normalize_condition($condition);
            if ($other['visibility'] !== 'show' || $other['from'] === 'term') {
                continue;
            }
            $covers =
                $other['type'] === '*'
                || $other['type'] === 'post'
                && $other['where'] === '*'
                && is_string($other['post_type'])
                && isset($post_types[$other['post_type']]);
            if (!$covers) {
                continue;
            }
            $warnings[] = sprintf(
                'Template %d (rank %d, evaluated before this one) already shows on %s: Kirki stops at the first match, so this template never renders there.',
                $other_id,
                $rank,
                $other['type'] === '*' ? 'the entire site' : sprintf('every `%s`', (string) $other['post_type']),
            );
            break;
        }
    }
    return $warnings;
}

/**
 * Warnings a list of conditions carries on its own, whatever the other
 * templates do: a list that can never record a match, two entries fighting
 * over the same target, and a taxonomy entry whose `post_type` is not the one
 * Kirki resolves for that taxonomy.
 *
 * @param list<array<string, mixed>> $rows normalised conditions
 * @return list<string>
 */
function kk_conditions_self_warnings(array $rows): array
{
    $warnings = [];
    $shows = array_filter($rows, static fn(array $row): bool => $row['visibility'] === 'show');
    if ($rows !== [] && $shows === []) {
        $warnings[] = 'No condition has `visibility: show`: a `hide` entry can only cancel a match recorded earlier, so this template can never render. Add the `show` entry that says where it applies.';
    }
    $seen = [];
    foreach ($rows as $index => $row) {
        $target = wp_json_encode([$row['from'], $row['type'], $row['post_type'], $row['where'], $row['to']]);
        $target = is_string($target) ? $target : strval($index);
        if (isset($seen[$target]) && $seen[$target]['visibility'] !== $row['visibility']) {
            $warnings[] = sprintf(
                'Conditions %d and %d target the same thing with opposite visibility (`%s` then `%s`): Kirki reads the list in order, so the later entry decides and the earlier one is dead weight.',
                $seen[$target]['index'],
                $index,
                strval($seen[$target]['visibility']),
                strval($row['visibility']),
            );
        }
        $seen[$target] = ['index' => $index, 'visibility' => $row['visibility']];
        $taxonomy_warning = kk_condition_taxonomy_warning($index, $row);
        if ($taxonomy_warning !== null) {
            $warnings[] = $taxonomy_warning;
        }
    }
    return $warnings;
}

/**
 * A term-archive condition whose `post_type` is not the one Kirki resolves
 * for its taxonomy: `Taxonomy::get_post_type_from_term_id` takes the FIRST
 * post type of `get_post_types([])` that owns the taxonomy and
 * `check_all_conditions_for_this_term` compares the condition's `post_type`
 * with it, so any other owner can never match.
 *
 * @param array<string, mixed> $row normalised condition
 */
function kk_condition_taxonomy_warning(int $index, array $row): ?string
{
    if ($row['from'] !== 'term' || $row['type'] !== 'post' || !is_string($row['post_type'])) {
        return null;
    }
    /** @var mixed $where */
    $where = $row['where'];
    if (!is_string($where) || $where === '*' || $where === 'single') {
        return null;
    }
    $owner = kk_taxonomy_context_post_type($where);
    if ($owner === null || $owner === $row['post_type']) {
        return null;
    }
    return sprintf(
        'Condition %d targets taxonomy `%s` with `post_type: %s`, but Kirki resolves a term archive of `%s` to `%s` (the first registered post type that owns the taxonomy): this condition can never match. Use `post_type: %s`.',
        $index,
        $where,
        $row['post_type'],
        $where,
        $owner,
        $owner,
    );
}

/**
 * The post type Kirki attributes to a term archive of this taxonomy, the way
 * `Kirki\Ajax\Taxonomy::get_post_type_from_term_id` computes it: the first
 * post type in registration order whose taxonomies include it. Null when no
 * registered post type owns the taxonomy.
 */
function kk_taxonomy_context_post_type(string $taxonomy): ?string
{
    /** @var mixed $post_types */
    $post_types = get_post_types([]);
    /** @var mixed $post_type */
    foreach (is_array($post_types) ? $post_types : [] as $post_type) {
        if (!is_string($post_type)) {
            continue;
        }
        if (in_array($taxonomy, get_object_taxonomies($post_type), strict: true)) {
            return $post_type;
        }
    }
    return null;
}

// ---------------------------------------------------------------------------
// resolve-template
// ---------------------------------------------------------------------------

wp_register_ability('novamira/kirki-resolve-template', [
    'label' => __('Resolve Kirki Template', domain: 'novamira-pro'),
    'description' => __(
        'Answers "which Kirki template applies here?" for one context — a post / page / custom post type entry (`post_id`), a term archive (`term_id`) or an author archive (`user_id`) — by running Kirki\'s own matcher (`find_template_for_this_context`) on the real context object, exactly as the frontend does. `template_id` is Kirki\'s verdict (null: no template, the post shows its WordPress content or the theme archive). `walk` explains every published template inside the resolution window in evaluation order: `matched` (with the index of the condition that recorded the match), `hidden` (a `hide` entry stopped it), `vetoed` (an entry that disables the template in this context: `from: term` on a post, a non-term entry on a term archive), `no_match`. A disagreement between Kirki\'s verdict and the walk is reported as a warning.',
        domain: 'novamira-pro',
    ),
    'category' => 'kirki',
    'input_schema' => [
        'type' => 'object',
        'properties' => [
            'post_id' => [
                'type' => 'integer',
                'description' => 'A viewable post of a public post type (single view). Exactly one of post_id / term_id / user_id.',
            ],
            'term_id' => ['type' => 'integer', 'description' => 'A term whose archive page is the context.'],
            'user_id' => ['type' => 'integer', 'description' => 'A user whose author archive is the context.'],
        ],
        'additionalProperties' => false,
    ],
    'output_schema' => [
        'type' => 'object',
        'properties' => [
            'context' => [
                'type' => 'object',
                'description' => '`{type: post|term|user, id, label, post_type?, taxonomy?, roles?, url}`; for a term, `post_type` is the first registered post type owning the taxonomy (what Kirki compares `post_type` with).',
            ],
            'template_id' => ['type' => ['integer', 'null']],
            'template_title' => ['type' => ['string', 'null']],
            'resolution_rank' => ['type' => ['integer', 'null'], 'description' => 'Rank of the chosen template.'],
            'considered_count' => [
                'type' => 'integer',
                'description' => 'Published templates inside the window (the ones Kirki evaluated).',
            ],
            'walk' => [
                'type' => 'array',
                'items' => ['type' => 'object'],
                'description' => '`{template_id, title, rank, outcome, condition_index, reason}` per evaluated template, in order.',
            ],
            'warnings' => ['type' => 'array', 'items' => ['type' => 'string']],
        ],
        'required' => [
            'context',
            'template_id',
            'template_title',
            'resolution_rank',
            'considered_count',
            'walk',
            'warnings',
        ],
        'additionalProperties' => false,
    ],
    'execute_callback' => 'Novamira\\Pro\\Abilities\\Kirki\\kirki_resolve_template',
    'permission_callback' => 'novamira_permission_callback',
    'meta' => [
        'show_in_rest' => true,
        'mcp' => ['public' => true],
        'annotations' => [
            'instructions' => 'Use it after kirki-set-template-conditions or before creating a template, to see what Kirki actually applies to a given post, archive or author page and why another template wins. It evaluates the stored state (draft templates and unpublished condition edits never count). The blog index is not a post context: Kirki templates it only through the static posts page.',
            'readonly' => true,
            'destructive' => false,
            'idempotent' => true,
        ],
    ],
]);

/**
 * @param array<string, mixed> $input
 * @return array<string, mixed>|WP_Error
 */
// @mago-expect lint:cyclomatic-complexity -- walk, Kirki's verdict, disagreement, response
function kirki_resolve_template(array $input): array|WP_Error
{
    kk_begin();
    $context = kk_template_context($input);
    if ($context instanceof WP_Error) {
        return $context;
    }
    $post_type = kk_content_post_types()['template'];
    $window = kk_template_resolution_window_info()['window'];
    $ranks = kk_template_resolution_ranks($post_type, $window);
    $considered = array_keys(array_filter($ranks, static fn(int $rank): bool => $rank <= $window));
    usort($considered, static fn(int $a, int $b): int => $ranks[$a] <=> $ranks[$b]);
    $meta = kk_list_meta($considered, [kk_meta_template_conditions()], inline_bytes: KK_LIST_TREE_BYTES);
    $walk = [];
    $ours = null;
    foreach ($considered as $template_id) {
        /** @var mixed $raw */
        $raw = $meta[$template_id][kk_meta_template_conditions()]['value'] ?? null;
        $verdict = kk_template_walk_one($context, is_array($raw) ? $raw : []);
        // @mago-expect analysis:mixed-assignment
        $post = get_post($template_id);
        $walk[] =
            [
                'template_id' => $template_id,
                'title' => $post instanceof WP_Post ? $post->post_title : '',
                'rank' => $ranks[$template_id],
            ] + $verdict;
        if ($ours === null && $verdict['outcome'] === 'matched') {
            $ours = $template_id;
        }
    }
    $kirki = kk_kirki_template_verdict($context);
    $warnings = [];
    if ($kirki instanceof WP_Error) {
        $warnings[] = $kirki->get_error_message();
        $kirki = $ours;
    }
    if ($kirki !== $ours) {
        $warnings[] = sprintf(
            'Kirki\'s matcher picked %s while the explanation walk picked %s. Both were computed from the stored conditions read fresh, so they should agree: treat this as a real disagreement to investigate (the walk mirrors Kirki 6.3 and may be out of date, or a plugin filters the matcher) and check the conditions with kirki-list-templates before relying on either.',
            $kirki === null ? 'no template' : 'template ' . $kirki,
            $ours === null ? 'no template' : 'template ' . $ours,
        );
    }
    // @mago-expect analysis:mixed-assignment
    $chosen = $kirki !== null ? get_post($kirki) : null;
    return [
        'context' => $context['summary'],
        'template_id' => $kirki,
        'template_title' => $chosen instanceof WP_Post ? $chosen->post_title : null,
        'resolution_rank' => $kirki !== null ? $ranks[$kirki] ?? null : null,
        'considered_count' => count($considered),
        'walk' => $walk,
        'warnings' => $warnings,
    ];
}

/**
 * The context of a resolution from the input: exactly one of post_id /
 * term_id / user_id, resolved to the object Kirki's matcher receives
 * (`WP_Post`, the term array `Taxonomy::get_term_by_id` builds, the user
 * array `Users::get_user_by_id` builds).
 *
 * @param array<string, mixed> $input
 * @return array{type: string, id: int, object: mixed, summary: array<string, mixed>}|WP_Error
 */
function kk_template_context(array $input): array|WP_Error
{
    $given = array_values(array_filter(
        ['post_id', 'term_id', 'user_id'],
        static fn(string $k): bool => isset($input[$k]),
    ));
    if (count($given) !== 1) {
        return kk_invalid_input(__('Pass exactly one of post_id, term_id, user_id.', domain: 'novamira-pro'));
    }
    $kind = $given[0];
    $id = kk_coerce_int_or_null($input[$kind]) ?? 0;
    if ($id <= 0) {
        return kk_invalid_input(sprintf('%s must be a positive integer.', $kind));
    }
    return match ($kind) {
        'term_id' => kk_term_context($id),
        'user_id' => kk_user_context($id),
        default => kk_post_context($id),
    };
}

/**
 * @return array{type: string, id: int, object: mixed, summary: array<string, mixed>}|WP_Error
 */
function kk_post_context(int $id): array|WP_Error
{
    // @mago-expect analysis:mixed-assignment
    $post = get_post($id);
    if (!$post instanceof WP_Post || in_array($post->post_status, ['trash', 'auto-draft', 'inherit'], strict: true)) {
        return kk_invalid_post($id);
    }
    $type = get_post_type_object($post->post_type);
    if (
        $type === null
        || !is_post_type_viewable($type)
        || $post->post_type === 'attachment'
        || str_starts_with($post->post_type, 'kirki_')
    ) {
        return kk_invalid_input(sprintf(
            /* translators: 1: post id, 2: post type */
            __(
                'Post %1$d (`%2$s`) is not a context Kirki templates: only single views of publicly viewable post types are.',
                domain: 'novamira-pro',
            ),
            $id,
            $post->post_type,
        ));
    }
    return [
        'type' => 'post',
        'id' => $id,
        'object' => $post,
        'summary' => [
            'type' => 'post',
            'id' => $id,
            'label' => $post->post_title,
            'post_type' => $post->post_type,
            'status' => $post->post_status,
            'url' => get_permalink($post),
        ],
    ];
}

/**
 * @return array{type: string, id: int, object: mixed, summary: array<string, mixed>}|WP_Error
 */
function kk_term_context(int $id): array|WP_Error
{
    $term = get_term($id);
    if (!$term instanceof WP_Term) {
        return kk_invalid_input(sprintf(
            /* translators: %d: term id */
            __('Term %d does not exist.', domain: 'novamira-pro'),
            $id,
        ));
    }
    $object = kk_kirki_term_context($id);
    $link = get_term_link($term);
    return [
        'type' => 'term',
        'id' => $id,
        'object' => $object,
        'summary' => [
            'type' => 'term',
            'id' => $id,
            'label' => $term->name,
            'taxonomy' => $term->taxonomy,
            'post_type' => is_string($object['post_type'] ?? null) ? $object['post_type'] : null,
            'url' => is_string($link) ? $link : '',
        ],
    ];
}

/**
 * @return array{type: string, id: int, object: mixed, summary: array<string, mixed>}|WP_Error
 */
function kk_user_context(int $id): array|WP_Error
{
    $user = get_user_by('id', $id);
    if (!$user instanceof WP_User) {
        return kk_invalid_input(sprintf(
            /* translators: %d: user id */
            __('User %d does not exist.', domain: 'novamira-pro'),
            $id,
        ));
    }
    return [
        'type' => 'user',
        'id' => $id,
        'object' => kk_kirki_user_context($user),
        'summary' => [
            'type' => 'user',
            'id' => $id,
            'label' => $user->display_name,
            'roles' => array_values(array_map('strval', $user->roles)),
            'url' => get_author_posts_url($id),
        ],
    ];
}

/**
 * The term array Kirki hands to its matcher (`Taxonomy::get_term_by_id`):
 * the term's vars plus `post_type` = the first registered post type that
 * owns the taxonomy. Falls back to the same construction when the class
 * moved.
 *
 * @return array<string, mixed>
 */
function kk_kirki_term_context(int $term_id): array
{
    if (class_exists('Kirki\Ajax\Taxonomy') && method_exists('Kirki\Ajax\Taxonomy', 'get_term_by_id')) {
        /** @var mixed $term */
        $term = \Kirki\Ajax\Taxonomy::get_term_by_id($term_id);
        if (is_array($term)) {
            return kk_string_keyed($term);
        }
    }
    $term = get_term($term_id);
    $vars = $term instanceof WP_Term ? get_object_vars($term) : [];
    $owner = null;
    foreach (get_post_types() as $post_type) {
        if (!in_array($vars['taxonomy'] ?? '', get_object_taxonomies($post_type), strict: true)) {
            continue;
        }
        $owner = $post_type;
        break;
    }
    $vars['post_type'] = $owner;
    /** @var array<string, mixed> $vars */
    return $vars;
}

/**
 * The user array Kirki hands to its matcher (`Users::get_user_by_id`,
 * `roles` included); the same construction when the class moved.
 *
 * @return array<string, mixed>
 */
function kk_kirki_user_context(WP_User $user): array
{
    if (class_exists('Kirki\Ajax\Users') && method_exists('Kirki\Ajax\Users', 'get_user_by_id')) {
        /** @var mixed $formatted */
        $formatted = \Kirki\Ajax\Users::get_user_by_id($user->ID);
        if (is_array($formatted) && isset($formatted['roles'])) {
            return kk_string_keyed($formatted);
        }
    }
    return ['ID' => $user->ID, 'display_name' => $user->display_name, 'roles' => array_values($user->roles)];
}

/**
 * Drop the WordPress meta cache of every published template, so a matcher
 * that reads `kirki_template_conditions` with `get_post_meta` (Kirki's own)
 * sees the stored rows and not a copy this request primed earlier.
 */
function kk_fresh_templates(): void
{
    /** @var mixed $ids */
    $ids = get_posts([
        'post_type' => kk_content_post_types()['template'],
        'post_status' => 'publish',
        'posts_per_page' => -1,
        'fields' => 'ids',
        'no_found_rows' => true,
        'update_post_term_cache' => false,
        'update_post_meta_cache' => false,
        'cache_results' => false,
        'suppress_filters' => true,
    ]);
    /** @var mixed $id */
    foreach (is_array($ids) ? $ids : [] as $id) {
        $int = kk_coerce_int_or_null($id);
        if ($int !== null) {
            kk_fresh($int);
        }
    }
}

/**
 * Kirki's own verdict for a context: the id of the template
 * `find_template_for_this_context` returns, null when none, WP_Error when
 * the method is gone (the walk then stands alone).
 *
 * @param array{type: string, id: int, object: mixed, summary: array<string, mixed>} $context
 */
function kk_kirki_template_verdict(array $context): int|null|WP_Error
{
    if (
        !class_exists('Kirki\HelperFunctions')
        || !method_exists('Kirki\HelperFunctions', 'find_template_for_this_context')
    ) {
        return new WP_Error('kirki_api_missing', __(
            'Kirki\'s matcher (`HelperFunctions::find_template_for_this_context`) is not available; `template_id` is the explanation walk\'s verdict only.',
            domain: 'novamira-pro',
        ));
    }
    // Kirki's matcher reads `kirki_template_conditions` through WordPress'
    // object cache, which Kirki's direct meta writes do not invalidate: inside
    // one request its verdict could be computed from conditions that are no
    // longer stored. Drop the cache of every published
    // template first, the way `kk_meta` does for our own reads.
    kk_fresh_templates();
    try {
        /** @var mixed $template */
        $template = \Kirki\HelperFunctions::find_template_for_this_context($context['type'], $context['object']);
    } catch (\Throwable $e) {
        return new WP_Error('kirki_api_missing', sprintf(
            /* translators: %s: exception summary */
            __(
                'Kirki\'s matcher threw (%s); `template_id` is the explanation walk\'s verdict only.',
                domain: 'novamira-pro',
            ),
            kk_throwable_summary($e),
        ));
    }
    if (!is_array($template)) {
        return null;
    }
    return kk_coerce_int_or_null($template['id'] ?? null);
}

/**
 * Replay of Kirki's three matchers on one template's stored conditions for
 * a context: the outcome, the index of the deciding condition and a reason.
 * Mirrors `check_all_conditions_for_this_post` / `_term` / `_user` on 6.3
 * line by line (loose `==` on `where`, strict `===` on a `single` target).
 *
 * @param array{type: string, id: int, object: mixed, summary: array<string, mixed>} $context
 * @param array<array-key, mixed> $conditions
 * @return array{outcome: string, condition_index: int|null, reason: string}
 */
function kk_template_walk_one(array $context, array $conditions): array
{
    if ($conditions === []) {
        return ['outcome' => 'no_match', 'condition_index' => null, 'reason' => 'no conditions stored'];
    }
    return match ($context['type']) {
        'term' => kk_walk_term($context['object'], $conditions),
        'user' => kk_walk_user($context['object'], $conditions),
        default => kk_walk_post($context['object'], $conditions),
    };
}

/**
 * @param array<array-key, mixed> $raw
 * @return array{from: string, type: mixed, post_type: mixed, where: mixed, to: mixed, visibility: mixed}
 */
function kk_walk_condition(array $raw): array
{
    /** @var mixed $from */
    $from = $raw['from'] ?? 'post';
    /** @var mixed $type */
    $type = $raw['type'] ?? null;
    /** @var mixed $post_type */
    $post_type = $raw['post_type'] ?? null;
    if (isset($raw['category'])) {
        $type = $raw['category'] === '*' ? '*' : 'post';
        /** @var mixed $post_type */
        $post_type = $raw['category'] === '*' ? $post_type : $raw['category'];
    }
    return [
        'from' => is_string($from) ? $from : 'post',
        'type' => $type,
        'post_type' => $post_type,
        'where' => $raw['where'] ?? null,
        'to' => $raw['to'] ?? null,
        'visibility' => $raw['visibility'] ?? 'show',
    ];
}

/**
 * Kirki compares `where` with `==` (so `true` equals `*`) and checks roles
 * with a loose in_array; the replay keeps both, isolated here.
 */
// @mago-expect lint:identity-comparison -- mirrors Kirki's loose comparison on purpose
// @mago-expect analysis:mixed-operand
function kk_loose_equals(mixed $value, string $expected): bool
{
    return $value == $expected;
}

/**
 * @param array<array-key, mixed> $haystack
 */
// @mago-expect lint:strict-behavior -- mirrors Kirki's loose in_array on purpose
function kk_loose_in(mixed $needle, array $haystack): bool
{
    return in_array($needle, $haystack);
}

/**
 * One matcher step shared by the walkers: apply the show / hide flags of a
 * condition that applies to the context.
 *
 * @param array{show: bool, shown_by: int|null} $state
 * @return array{show: bool, shown_by: int|null}
 */
// @mago-expect lint:no-boolean-flag-parameter -- the show / hide verdict of one condition
function kk_walk_record(array $state, bool $wants_show, int $index): array
{
    $state['show'] = $wants_show;
    if ($wants_show) {
        $state['shown_by'] = $index;
    }
    return $state;
}

/**
 * @param array{show: bool, shown_by: int|null} $state
 * @return array{outcome: string, condition_index: int|null, reason: string}
 */
function kk_walk_verdict(array $state, string $context_label): array
{
    if ($state['show']) {
        return [
            'outcome' => 'matched',
            'condition_index' => $state['shown_by'],
            'reason' => 'condition recorded a show that no later entry cancelled',
        ];
    }
    return [
        'outcome' => 'no_match',
        'condition_index' => null,
        'reason' => sprintf('no show entry applies to this %s (or a later entry cancelled it)', $context_label),
    ];
}

/**
 * Whether a `type: post` condition applies to a post and whether it is a
 * targeted (single / term) hit that a `hide` can stop: `[applies, targeted]`.
 *
 * @param array{from: string, type: mixed, post_type: mixed, where: mixed, to: mixed, visibility: mixed} $c
 * @return array{bool, bool}
 */
function kk_walk_post_scope(array $c, WP_Post $post): array
{
    if ($c['post_type'] !== $post->post_type) {
        return [false, false];
    }
    if (kk_loose_equals($c['where'], expected: '*')) {
        return [true, false];
    }
    if (kk_loose_equals($c['where'], expected: 'single')) {
        return [$c['to'] === $post->ID, true];
    }
    if ($c['to'] === '*') {
        return [true, false];
    }
    $target = is_int($c['to']) || is_string($c['to']) ? $c['to'] : null;
    if ($target === null || !is_string($c['where'])) {
        return [false, false];
    }
    return [has_term($target, $c['where'], $post->ID), true];
}

/**
 * @param array<array-key, mixed> $conditions
 * @return array{outcome: string, condition_index: int|null, reason: string}
 */
function kk_walk_post(mixed $post, array $conditions): array
{
    if (!$post instanceof WP_Post) {
        return ['outcome' => 'no_match', 'condition_index' => null, 'reason' => 'no post context'];
    }
    $state = ['show' => false, 'shown_by' => null];
    $index = -1;
    /** @var mixed $raw */
    foreach ($conditions as $raw) {
        ++$index;
        if (!is_array($raw)) {
            continue;
        }
        $c = kk_walk_condition($raw);
        if ($c['from'] === 'term') {
            return [
                'outcome' => 'vetoed',
                'condition_index' => $index,
                'reason' => 'a `from: term` entry makes the template never match on posts',
            ];
        }
        $wants_show = $c['visibility'] === 'show';
        if ($c['type'] === '*') {
            $state = kk_walk_record($state, $wants_show, $index);
            continue;
        }
        if ($c['type'] !== 'post') {
            continue;
        }
        [$applies, $targeted] = kk_walk_post_scope($c, $post);
        if (!$applies) {
            continue;
        }
        $state = kk_walk_record($state, $wants_show, $index);
        if ($targeted && $c['visibility'] === 'hide') {
            return [
                'outcome' => 'hidden',
                'condition_index' => $index,
                'reason' => 'a `hide` entry matched this post and stops the template',
            ];
        }
    }
    return kk_walk_verdict($state, context_label: 'post');
}

/**
 * @param array<array-key, mixed> $conditions
 * @return array{outcome: string, condition_index: int|null, reason: string}
 */
function kk_walk_term(mixed $term, array $conditions): array
{
    if (!is_array($term)) {
        return ['outcome' => 'no_match', 'condition_index' => null, 'reason' => 'no term context'];
    }
    $state = ['show' => false, 'shown_by' => null];
    $index = -1;
    /** @var mixed $raw */
    foreach ($conditions as $raw) {
        ++$index;
        if (!is_array($raw)) {
            continue;
        }
        $c = kk_walk_condition($raw);
        if ($c['from'] !== 'term') {
            return [
                'outcome' => 'vetoed',
                'condition_index' => $index,
                'reason' => 'an entry without `from: term` makes the template never match on term archives',
            ];
        }
        $wants_show = $c['visibility'] === 'show';
        if ($c['type'] === '*') {
            $state = kk_walk_record($state, $wants_show, $index);
            continue;
        }
        if ($c['type'] !== 'post' || $c['post_type'] !== ($term['post_type'] ?? null)) {
            continue;
        }
        if (kk_loose_equals($c['where'], expected: '*') || $c['to'] === '*') {
            $state = kk_walk_record($state, $wants_show, $index);
            continue;
        }
        if (!is_string($c['to']) || !kk_loose_equals($term['taxonomy'] ?? null, expected: $c['to'])) {
            continue;
        }
        $state = kk_walk_record($state, $wants_show, $index);
        if ($c['visibility'] === 'hide') {
            return [
                'outcome' => 'hidden',
                'condition_index' => $index,
                'reason' => 'a `hide` entry matched this taxonomy and stops the template',
            ];
        }
    }
    return kk_walk_verdict(
        $state,
        context_label: 'term archive (`post_type` must equal the first post type owning the taxonomy)',
    );
}

/**
 * @param array<array-key, mixed> $conditions
 * @return array{outcome: string, condition_index: int|null, reason: string}
 */
function kk_walk_user(mixed $user, array $conditions): array
{
    if (!is_array($user)) {
        return ['outcome' => 'no_match', 'condition_index' => null, 'reason' => 'no user context'];
    }
    $roles = is_array($user['roles'] ?? null) ? $user['roles'] : [];
    $state = ['show' => false, 'shown_by' => null];
    $index = -1;
    /** @var mixed $raw */
    foreach ($conditions as $raw) {
        ++$index;
        if (!is_array($raw)) {
            continue;
        }
        $c = kk_walk_condition($raw);
        $wants_show = $c['visibility'] === 'show';
        if ($c['type'] === '*') {
            $state = kk_walk_record($state, $wants_show, $index);
            continue;
        }
        if ($c['type'] !== 'user') {
            continue;
        }
        $applies = $c['where'] === '*' || $c['where'] === 'role' && ($c['to'] === '*' || kk_loose_in($c['to'], $roles));
        if ($applies) {
            $state = kk_walk_record($state, $wants_show, $index);
        }
    }
    return kk_walk_verdict($state, context_label: 'author archive');
}
