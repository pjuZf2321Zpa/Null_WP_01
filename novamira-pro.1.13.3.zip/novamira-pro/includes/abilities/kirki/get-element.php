<?php

// SPDX-FileCopyrightText: 2026 Ovation S.r.l. <dev@novamira.ai>
// SPDX-License-Identifier: AGPL-3.0-or-later

declare(strict_types=1);

namespace Novamira\Pro\Abilities\Kirki;

use WP_Error;

/**
 * Ability: Get one Kirki element in full, with the style blocks it references.
 */

if (!defined('ABSPATH')) {
    exit();
}

wp_register_ability('novamira/kirki-get-element', [
    'label' => __('Get Kirki Element', domain: 'novamira-pro'),
    'description' => __(
        'Returns one node of a Kirki tree exactly as stored (id, name, title, parentId, children, styleIds, className, visibility, hide, properties with tag / contents / attributes / element-specific settings, stylePanels), plus `text` (its resolved plain text, cut at 16 KB with `text_truncated`) and `styles`: every style block the node references through `styleIds` (and the older `properties.classesIds`), resolved against the page-local map AND the site-wide global maps exactly as Kirki assembles them for that read (published: base local map + deprecated global map + the HIGHEST staged version\'s maps + class-manager map; a staged version flagged `no_legacy_global_style`: its own map + class-manager; an unflagged staged version: base + deprecated + its own maps + class-manager), each as `{id, scope: local|global|published-local, name, type, variant}` (`published-local` = a block of another version\'s map merged into this read) where `name` is the class the element carries (name entries lower-cased, spaces to `-`) and `variant` maps `<viewport>[_<state>]` keys to raw CSS declaration text; `missing: true` marks an id no map holds (the renderer drops it); `renamed_by_renderer: true` marks a block whose name the renderer changes before printing (`<name>-copy` when a page block collides with a class-manager name, `<name>_1` when the published read merges the highest staged version\'s map and a name collides; only string names collide, combo names never do); `name` is then the rendered one and `stored_name` the stored one. The published read merges the HIGHEST version\'s staged map (also an unpublished draft\'s), exactly as Kirki renders. Reads the published tree by default; pass `staging_version` for a staged draft. Use kirki-get-content first to find the node id.',
        domain: 'novamira-pro',
    ),
    'category' => 'kirki',
    'input_schema' => [
        'type' => 'object',
        'properties' => [
            'post_id' => ['type' => 'integer', 'description' => 'Id of a post in Kirki editor mode.'],
            'element_id' => ['type' => 'string', 'description' => 'Node id (e.g. `k-5bsj9bai`, `body`, `root`).'],
            'staging_version' => [
                'type' => 'integer',
                'description' => 'Read this staged version instead of the published tree.',
            ],
        ],
        'required' => ['post_id', 'element_id'],
        'additionalProperties' => false,
    ],
    'output_schema' => [
        'type' => 'object',
        'properties' => [
            'post_id' => ['type' => 'integer'],
            'source' => ['type' => 'object'],
            'element' => [
                'type' => 'object',
                'description' => 'The raw node as Kirki stores it (values nested deeper than 48 levels are replaced by `?deep`).',
            ],
            'text' => [
                'type' => 'string',
                'description' => 'Resolved plain text of the node (for containers: of its text descendants), cut at 16 KB (`text_truncated: true`).',
            ],
            'text_truncated' => ['type' => 'boolean'],
            'symbol_missing' => [
                'type' => 'boolean',
                'description' => 'Set on a `symbol` node whose symbol post no longer exists (the renderer prints nothing there).',
            ],
            'classes' => ['type' => 'array', 'items' => ['type' => 'string']],
            'styles' => [
                'type' => 'array',
                'items' => ['type' => 'object'],
                'description' => 'Referenced style blocks in `styleIds` (page-local) then `classesIds` (global classes) order; the renderer prints the global class names FIRST in class="…" (`classes` shows that order). A referenced id with no block yields `{id, missing: true}`. Page-local blocks also carry `stored`: the block exactly as stored (`name` may be a list for combo classes; editor flags kept) — feed THAT back to kirki-set-content, never the rendered `name`.',
            ],
        ],
        'required' => ['post_id', 'source', 'element', 'text', 'classes', 'styles'],
        'additionalProperties' => false,
    ],
    'execute_callback' => 'Novamira\\Pro\\Abilities\\Kirki\\kirki_get_element',
    'permission_callback' => 'novamira_permission_callback',
    'meta' => [
        'show_in_rest' => true,
        'mcp' => ['public' => true],
        'annotations' => [
            'instructions' => 'Read a node in full before editing it so every key Kirki wrote (stylePanels, source, visibility, collapse, template_mounted, …) is preserved on the way back. Text lives in `properties.contents` as an ordered list of strings and `{id}` references to inline child nodes (bold, links); the referenced nodes are separate entries in the tree, not in `children`.',
            'readonly' => true,
            'destructive' => false,
            'idempotent' => true,
        ],
    ],
]);

/**
 * Style blocks a node references, in `styleIds` then `classesIds` order,
 * resolved against the effective map (`$styles`); `$local` tells the scope.
 *
 * @param array<string, mixed> $node
 * @param array<string, array<string, mixed>> $styles effective map
 * @param array<string, array<string, mixed>> $local page-local map
 * @param list<string> $renamed ids whose name the renderer changed
 * @return list<array<string, mixed>>
 */
// @mago-expect lint:cyclomatic-complexity -- scope, rename and stored-shape branches per block
function kk_referenced_styles(array $node, array $styles, array $local, array $renamed): array
{
    $maps = kk_global_style_maps();
    $global_ids = array_keys($maps['class_manager'] + $maps['deprecated']);
    $ids = [];
    if (isset($node['styleIds']) && is_array($node['styleIds'])) {
        $ids = array_merge($ids, array_values($node['styleIds']));
    }
    $props = isset($node['properties']) && is_array($node['properties']) ? $node['properties'] : [];
    if (isset($props['classesIds']) && is_array($props['classesIds'])) {
        $ids = array_merge($ids, array_values($props['classesIds']));
    }
    $out = [];
    /** @var mixed $id */
    foreach ($ids as $id) {
        if (!is_string($id)) {
            continue;
        }
        if (!isset($styles[$id])) {
            $out[] = ['id' => $id, 'missing' => true];
            continue;
        }
        $block = $styles[$id];
        $scope = match (true) {
            in_array($id, $global_ids, strict: true) => 'global',
            isset($local[$id]) => 'local',
            default => 'published-local',
        };
        $entry = [
            'id' => $id,
            'scope' => $scope,
            'name' => kk_style_block_name($block),
            'type' => isset($block['type']) && is_string($block['type']) ? $block['type'] : 'class',
            'variant' => isset($block['variant']) && is_array($block['variant']) ? $block['variant'] : [],
        ];
        if (in_array($id, $renamed, strict: true)) {
            // `name` above is the rendered one (`-copy` / `_1`); the stored name differs.
            $entry['renamed_by_renderer'] = true;
            $entry['stored_name'] = isset($local[$id]) ? kk_style_block_name($local[$id]) : null;
        }
        if ($scope === 'local') {
            // The block as stored (list-shaped combo names, editor flags such as
            // `isComboClass` / `symbolRootSize`): what kirki-set-content must get back.
            $entry['stored'] = kk_bound_value($local[$id], depth: 8, bytes: KK_MAX_CSS_BYTES * 2);
        }
        $out[] = $entry;
    }
    return $out;
}

/**
 * @param array<string, mixed> $input
 * @return array<string, mixed>|WP_Error
 */
// @mago-expect lint:cyclomatic-complexity -- guard chain of early returns
function kirki_get_element(array $input): array|WP_Error
{
    kk_begin();
    $post_id = kk_coerce_int_or_null($input['post_id'] ?? null) ?? 0;
    $post = kk_post_or_error($post_id);
    if ($post instanceof WP_Error) {
        return $post;
    }
    if (!kk_is_kirki_mode($post_id)) {
        return kk_not_kirki_mode($post_id);
    }
    /** @var mixed $raw_id */
    $raw_id = $input['element_id'] ?? '';
    $element_id = is_string($raw_id) ? $raw_id : '';
    if ($element_id === '') {
        return kk_invalid_input(__('element_id must be a non-empty string.', domain: 'novamira-pro'));
    }
    $version = kk_coerce_int_or_null($input['staging_version'] ?? null);
    $source = kk_blocks_for_version($post_id, $version);
    if ($source instanceof WP_Error) {
        return $source;
    }
    $blocks = $source['blocks'] ?? [];
    if ($blocks === []) {
        return new WP_Error(
            'kirki_no_tree',
            sprintf(
                /* translators: 1: post id, 2: source kind */
                __('Post %1$d holds no Kirki tree in the %2$s source.', domain: 'novamira-pro'),
                $post_id,
                $source['kind'],
            ),
            ['status' => 404],
        );
    }
    if (!isset($blocks[$element_id]) || !is_array($blocks[$element_id])) {
        return kk_unknown_node($element_id);
    }
    $local = kk_style_blocks_for_version($post_id, $version);
    if ($local instanceof WP_Error) {
        return $local;
    }
    $info = kk_effective_style_info($post_id, $version, $local);
    $styles = $info['map'];
    /** @var array<string, mixed> $node */
    $node = $blocks[$element_id];

    $referenced = kk_referenced_styles($node, $styles, $local, $info['renamed']);
    $text = kk_node_text($node, $blocks);
    $out = [
        'post_id' => $post_id,
        'source' => ['kind' => $source['kind'], 'version' => $source['version']],
        'element' => kk_bound_value($node, depth: 48, bytes: PHP_INT_MAX),
        'text' => kk_bound_string($text, KK_ELEMENT_TEXT_BYTES),
        'classes' => kk_node_classes($node, $styles),
        'styles' => $referenced,
    ];
    if (strlen($text) > KK_ELEMENT_TEXT_BYTES) {
        // `body` of a big page concatenates every descendant's text, which can run to megabytes.
        $out['text_truncated'] = true;
    }
    if (($node['name'] ?? null) === 'symbol') {
        $symbol_id = kk_coerce_int_or_null($node['properties']['symbolId'] ?? null);
        if ($symbol_id === null || $symbol_id <= 0 || get_post_type($symbol_id) !== kk_symbol_post_type()) {
            $out['symbol_missing'] = true;
        }
    }
    return $out;
}
