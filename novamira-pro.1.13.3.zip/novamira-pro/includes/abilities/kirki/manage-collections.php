<?php

// SPDX-FileCopyrightText: 2026 Ovation S.r.l. <dev@novamira.ai>
// SPDX-License-Identifier: AGPL-3.0-or-later

declare(strict_types=1);

namespace Novamira\Pro\Abilities\Kirki;

use WP_Error;
use WP_Post;
use WP_Query;

/**
 * Abilities: Kirki Content Manager collections — the `kirki_cm` posts whose
 * `kirki_cm_fields` meta holds the typed field definitions their items
 * (posts of type `kirki_cm_<collection id>`) are filled with.
 *
 * Kirki's editor (Dashboard → Dynamic Content) creates a collection as a
 * published `kirki_cm` post, saves the field list whole on every change
 * (removed fields lose their item values and reference rows on every item),
 * registers a public post type per collection with the collection slug as
 * rewrite base (item URLs are `/<collection slug>/<item slug>/`, served once
 * the rewrite rules are flushed; the writers here flush them right away).
 * The schema writers refuse while ANY editor tab is open: the Content
 * Manager panel lives inside whatever page tab is open and re-posts the
 * whole field list on its next Save.
 */

if (!defined('ABSPATH')) {
    exit();
}

// Load order: this file's schemas use constants defined in other ability files of the folder; require them
// explicitly so the folder's alphabetical load order does not decide whether this file loads.
require_once __DIR__ . '/content-manager.php'; // KK_CM_* field type constants
require_once __DIR__ . '/tree.php'; // KK_ALLOW_OPEN_EDITOR_SCHEMA

const KK_CM_TITLE_BYTES = 200;

/** Kirki's reserved collection / item slugs (`ContentManager::RESERVED_SLUG_WORDS`, 6.3.1). */
const KK_CM_RESERVED_SLUGS = [
    'attachment',
    'author',
    'category',
    'comment',
    'feed',
    'page',
    'post',
    'tag',
    'profile',
    'index',
];

const KK_CM_FIELD_DEF_SCHEMA = [
    'type' => 'object',
    'properties' => [
        'id' => [
            'type' => 'string',
            'description' => 'Field id (`k-` + 8 lowercase alphanumerics). Omit on new fields (generated); pass the stored id to keep an existing field and its item values.',
        ],
        'type' => ['type' => 'string', 'enum' => KK_CM_FIELD_TYPES, 'description' => 'Field type.'],
        'title' => [
            'type' => 'string',
            'description' => 'Label shown in the item form, unique within the collection (1–200 bytes, plain).',
        ],
        'help_text' => ['type' => 'string', 'description' => 'Help shown under the input.'],
        'required' => ['type' => 'boolean', 'description' => 'Items must carry a non-empty value (default false).'],
        'default_value' => [
            'type' => ['string', 'number', 'boolean', 'object', 'array', 'null'],
            'description' => 'Default value in the type\'s value shape (prefilled on new items, printed when an item stores nothing). Not for option / reference types; `on` / `off` for switch (default `on`).',
        ],
        'character_limit' => [
            'type' => 'object',
            'description' => 'text / rich-text: `{enabled, min, max}` (default disabled, 0–10).',
        ],
        'number_format' => [
            'type' => 'string',
            'enum' => KK_CM_NUMBER_FORMATS,
            'description' => 'number: `integer`, `decimal` or `any-format` (default).',
        ],
        'allows_negative_numbers' => [
            'type' => 'boolean',
            'description' => 'number: allow values below 0 (default false).',
        ],
        'options' => [
            'type' => 'array',
            'items' => ['type' => 'object'],
            'description' => 'option: `[{value, isDefault}]`, exactly one default (the first when none is marked).',
        ],
        'image_file_format' => [
            'type' => 'array',
            'items' => ['type' => 'string'],
            'description' => 'image / gallery: accepted extensions, `["*"]` = any (default).',
        ],
        'image_type' => [
            'type' => 'string',
            'enum' => KK_CM_IMAGE_TYPES,
            'description' => 'image / gallery: `media-manager` (default, attachment ids) or `image-url`.',
        ],
        'size_limitation' => [
            'type' => 'object',
            'description' => 'image / video: `{enabled, min, max, unit: kb|mb}` (default disabled).',
        ],
        'video_type' => [
            'type' => 'string',
            'enum' => KK_CM_VIDEO_TYPES,
            'description' => 'video: `media-manager` (default) or `video-url`.',
        ],
        'video_format' => [
            'type' => 'array',
            'items' => ['type' => 'string'],
            'description' => 'video: accepted extensions, `["*"]` = any (default).',
        ],
        'default_format' => [
            'type' => 'string',
            'description' => 'date: the display format the frontend prints (default `YYYY-MM-DD`; values are always stored as `YYYY-MM-DD`).',
        ],
        'include_time_field' => [
            'type' => 'boolean',
            'description' => 'date: values carry a time (`YYYY-MM-DD HH:MM`), default false.',
        ],
        'ref_collection' => [
            'type' => 'integer',
            'description' => 'reference / multi-reference: id of the target collection (required).',
        ],
        'templateKey' => [
            'type' => 'string',
            'description' => 'Key the dynamic-page binder uses (set by "New Dynamic Page"); rarely needed.',
        ],
        'kind' => [
            'type' => 'string',
            'enum' => ['custom'],
            'description' => 'Always `custom` (the only kind the editor writes).',
        ],
        'editRefCollection' => ['type' => 'boolean', 'description' => 'reference types: editor flag (default false).'],
    ],
    'required' => ['type', 'title'],
    'additionalProperties' => false,
];

const KK_CM_FIELDS_SCHEMA = [
    'type' => 'array',
    'items' => KK_CM_FIELD_DEF_SCHEMA,
    'description' => 'Field definitions in display order. Each is completed with the editor\'s per-type defaults; ids are generated unless given.',
];

const KK_CM_FIELD_SUMMARY_OUTPUT = [
    'type' => 'array',
    'items' => [
        'type' => 'object',
        'properties' => [
            'id' => ['type' => 'string'],
            'type' => ['type' => 'string'],
            'title' => ['type' => 'string'],
            'required' => ['type' => 'boolean'],
        ],
        'required' => ['id', 'type', 'title', 'required'],
        'additionalProperties' => false,
    ],
];

const KK_CM_COUNTS_OUTPUT = [
    'type' => 'object',
    'properties' => [
        'draft' => ['type' => 'integer'],
        'publish' => ['type' => 'integer'],
        'future' => ['type' => 'integer'],
        'trash' => [
            'type' => 'integer',
            'description' => 'Items in the trash: they still exist and a forced delete destroys them.',
        ],
        'total' => ['type' => 'integer'],
    ],
    'required' => ['draft', 'publish', 'future', 'trash', 'total'],
    'additionalProperties' => false,
];

const KK_CM_REFERENCED_BY_OUTPUT = [
    'type' => 'object',
    'description' => 'Templates whose conditions target the item post type, pages bound to the collection (index / details pages of "New Dynamic Page"), and `referencing_items`: the OTHER collections whose reference fields point at items of this one (`{collection_id, collection_title, items, rows, sample_title}`). Deleting this collection drops those reference rows with the items (the reference table cascades), so those fields read empty afterwards.',
    'properties' => [
        'templates' => ['type' => 'array', 'items' => ['type' => 'object']],
        'pages' => ['type' => 'array', 'items' => ['type' => 'object']],
        'referencing_items' => ['type' => 'array', 'items' => ['type' => 'object']],
    ],
    'required' => ['templates', 'pages', 'referencing_items'],
    'additionalProperties' => false,
];

const KK_CM_PRETTY_URLS_DESCRIPTION = 'true when the site\'s rewrite rules route `/<slug>/<item slug>/` to the items; false when Kirki registered the type but the rules were never flushed (item URLs answer 404 until a writer here or a permalink save flushes them); null on plain permalinks (item URLs are `?kirki_cm_<id>=<item slug>`).';

// ---------------------------------------------------------------------------
// list-collections
// ---------------------------------------------------------------------------

wp_register_ability('novamira/kirki-list-collections', [
    'label' => __('List Kirki Collections', domain: 'novamira-pro'),
    'description' => __(
        'Lists Kirki Content Manager collections (`kirki_cm` posts, the CMS of the editor\'s Dynamic Content panel): title, slug, status, preset type, the number of fields (the definitions with `include_fields: true`), item counts by status, the public URL pattern of the items (`/<slug>/<item slug>/`) and whether the rewrite rules serve it. Filter with `search`, page with `limit` / `offset`. Read straight from the database (Kirki writes meta without invalidating the object cache).',
        domain: 'novamira-pro',
    ),
    'category' => 'kirki',
    'input_schema' => [
        'type' => 'object',
        'properties' => [
            'search' => ['type' => 'string', 'description' => KK_SEARCH_DESCRIPTION],
            'limit' => KK_LIMIT_SCHEMA,
            'offset' => KK_OFFSET_SCHEMA,
            'include_fields' => [
                'type' => 'boolean',
                'description' => 'Add `fields` (id, type, title, required) to every row. Default false.',
                'default' => false,
            ],
        ],
        'required' => [],
        'additionalProperties' => false,
    ],
    'output_schema' => [
        'type' => 'object',
        'properties' => [
            'collections' => [
                'type' => 'array',
                'items' => [
                    'type' => 'object',
                    'properties' => [
                        'id' => ['type' => 'integer'],
                        'title' => ['type' => 'string'],
                        'slug' => ['type' => 'string'],
                        'status' => ['type' => 'string'],
                        'preset_type' => ['type' => 'string'],
                        'field_count' => ['type' => 'integer'],
                        'fields' => KK_CM_FIELD_SUMMARY_OUTPUT,
                        'items' => KK_CM_COUNTS_OUTPUT,
                        'item_post_type' => ['type' => 'string'],
                        'item_url_pattern' => ['type' => 'string'],
                        'pretty_urls' => [
                            'type' => ['boolean', 'null'],
                            'description' => KK_CM_PRETTY_URLS_DESCRIPTION,
                        ],
                        'modified' => ['type' => 'string'],
                    ],
                    'required' => [
                        'id',
                        'title',
                        'slug',
                        'status',
                        'preset_type',
                        'field_count',
                        'items',
                        'item_post_type',
                        'item_url_pattern',
                        'pretty_urls',
                        'modified',
                    ],
                    'additionalProperties' => false,
                ],
            ],
            'total' => ['type' => 'integer'],
            'warnings' => ['type' => 'array', 'items' => ['type' => 'string']],
        ],
        'required' => ['collections', 'total', 'warnings'],
        'additionalProperties' => false,
    ],
    'execute_callback' => 'Novamira\\Pro\\Abilities\\Kirki\\kirki_list_collections',
    'permission_callback' => 'novamira_permission_callback',
    'meta' => [
        'show_in_rest' => true,
        'mcp' => ['public' => true],
        'annotations' => [
            'instructions' => 'Start here to find a collection id; kirki-get-collection returns the full field definitions you need to fill items.',
            'readonly' => true,
            'destructive' => false,
            'idempotent' => true,
        ],
    ],
]);

/**
 * @param array<string, mixed> $input
 * @return array<string, mixed>|WP_Error
 */
function kirki_list_collections(array $input): array|WP_Error
{
    kk_begin();
    $needle = kk_search_needle($input['search'] ?? null);
    if ($needle instanceof WP_Error) {
        return $needle;
    }
    $limit = kk_clamp_limit($input['limit'] ?? null, default: 50);
    $offset = max(0, kk_coerce_int_or_null($input['offset'] ?? null) ?? 0);
    $args = [
        'post_type' => kk_collection_post_type(),
        'post_status' => ['draft', 'publish', 'future'],
        'posts_per_page' => $limit,
        'offset' => $offset,
        'orderby' => 'ID',
        'order' => 'DESC',
        'no_found_rows' => false,
        'ignore_sticky_posts' => true,
        'suppress_filters' => true,
    ];
    if ($needle !== null) {
        $args['s'] = $needle;
    }
    $query = new WP_Query($args);
    $with_fields = kk_bool($input['include_fields'] ?? false);
    $rows = [];
    foreach ($query->posts as $post) {
        if (!$post instanceof WP_Post) {
            continue;
        }
        $rows[] = kk_cm_collection_row($post, $with_fields);
    }
    return ['collections' => $rows, 'total' => kk_found_total($query, $args), 'warnings' => []];
}

/**
 * One collection as list-collections returns it.
 *
 * @return array<string, mixed>
 */
// @mago-expect lint:no-boolean-flag-parameter -- opt-in detail of the list row
function kk_cm_collection_row(WP_Post $post, bool $with_fields): array
{
    $defs = kk_cm_stored_defs($post->ID);
    $row = [
        'id' => $post->ID,
        'title' => $post->post_title,
        'slug' => $post->post_name,
        'status' => $post->post_status,
        'preset_type' => kk_cm_preset_type($post->ID),
        'field_count' => count($defs),
    ];
    if ($with_fields) {
        $row['fields'] = kk_cm_field_summaries($defs);
    }
    $row['items'] = kk_collection_item_counts($post->ID);
    $row['item_post_type'] = kk_item_post_type($post->ID);
    $row['item_url_pattern'] = kk_collection_item_url_pattern($post);
    $row['pretty_urls'] = kk_collection_pretty_urls($post);
    $row['modified'] = kk_modified_gmt($post);
    return $row;
}

function kk_cm_preset_type(int $collection_id): string
{
    /** @var mixed $preset */
    $preset = kk_meta($collection_id, kk_meta_cm_preset_type());
    return is_string($preset) && $preset !== '' ? $preset : 'generic';
}

/**
 * @param list<array<string, mixed>> $defs
 * @return list<array{id: string, type: string, title: string, required: bool}>
 */
function kk_cm_field_summaries(array $defs): array
{
    $out = [];
    foreach ($defs as $def) {
        $out[] = [
            'id' => (string) $def['id'],
            'type' => (string) $def['type'],
            'title' => (string) ($def['title'] ?? ''),
            'required' => kk_bool($def['required'] ?? false),
        ];
    }
    return $out;
}

// ---------------------------------------------------------------------------
// get-collection
// ---------------------------------------------------------------------------

wp_register_ability('novamira/kirki-get-collection', [
    'label' => __('Get Kirki Collection', domain: 'novamira-pro'),
    'description' => __(
        'Reads one Content Manager collection: title, slug, status, preset type, the Name / Slug labels (`basic_fields`), every field definition as stored (`kirki_cm_fields`, completed with the editor defaults, plus the `meta_key` each item value lives under), item counts by status, the item URL pattern and whether the rewrite rules serve it, the pages bound to the collection (index / details), the templates whose conditions target its items and the other collections referencing its items (`referenced_by.referencing_items`, the values a delete would empty). Field ids are what kirki-create-collection-item / kirki-edit-collection-item key their `fields` by; the `meta_key` shown with each one is output only — kirki-edit-collection does not accept it back.',
        domain: 'novamira-pro',
    ),
    'category' => 'kirki',
    'input_schema' => [
        'type' => 'object',
        'properties' => [
            'collection_id' => [
                'type' => 'integer',
                'description' => 'Id of a `kirki_cm` post (kirki-list-collections).',
            ],
        ],
        'required' => ['collection_id'],
        'additionalProperties' => false,
    ],
    'output_schema' => [
        'type' => 'object',
        'properties' => [
            'id' => ['type' => 'integer'],
            'title' => ['type' => 'string'],
            'slug' => ['type' => 'string'],
            'status' => ['type' => 'string'],
            'preset_type' => ['type' => 'string'],
            'basic_fields' => [
                'type' => 'object',
                'description' => '`{post_title: {title, help_text}, post_name: {title, help_text}}` — the labels of the Name / Slug inputs.',
            ],
            'fields' => [
                'type' => 'array',
                'items' => ['type' => 'object'],
                'description' => 'Definitions as stored, each with `meta_key` added.',
            ],
            'items' => KK_CM_COUNTS_OUTPUT,
            'item_post_type' => ['type' => 'string'],
            'item_url_pattern' => ['type' => 'string'],
            'pretty_urls' => ['type' => ['boolean', 'null'], 'description' => KK_CM_PRETTY_URLS_DESCRIPTION],
            'referenced_by' => KK_CM_REFERENCED_BY_OUTPUT,
            'modified' => ['type' => 'string'],
            'warnings' => ['type' => 'array', 'items' => ['type' => 'string']],
        ],
        'required' => [
            'id',
            'title',
            'slug',
            'status',
            'preset_type',
            'basic_fields',
            'fields',
            'items',
            'item_post_type',
            'item_url_pattern',
            'pretty_urls',
            'referenced_by',
            'modified',
            'warnings',
        ],
        'additionalProperties' => false,
    ],
    'execute_callback' => 'Novamira\\Pro\\Abilities\\Kirki\\kirki_get_collection',
    'permission_callback' => 'novamira_permission_callback',
    'meta' => [
        'show_in_rest' => true,
        'mcp' => ['public' => true],
        'annotations' => [
            'instructions' => 'Read the field definitions before writing items: `fields[].id` keys the item values, `type` decides the value shape, `required` / `options` / `ref_collection` decide what is accepted.',
            'readonly' => true,
            'destructive' => false,
            'idempotent' => true,
        ],
    ],
]);

/**
 * @param array<string, mixed> $input
 * @return array<string, mixed>|WP_Error
 */
function kirki_get_collection(array $input): array|WP_Error
{
    kk_begin();
    $post = kk_collection_post_or_error(kk_coerce_int_or_null($input['collection_id'] ?? null) ?? 0);
    if ($post instanceof WP_Error) {
        return $post;
    }
    return kk_cm_collection_report($post, []);
}

/**
 * The full report of a collection (get-collection and the writers' result).
 *
 * @param list<string> $warnings
 * @return array<string, mixed>
 */
function kk_cm_collection_report(WP_Post $post, array $warnings): array
{
    $defs = kk_cm_stored_defs($post->ID);
    $fields = [];
    foreach ($defs as $def) {
        $def['meta_key'] = kk_field_meta_key($post->ID, (string) $def['id']);
        $fields[] = $def;
    }
    $pretty = kk_collection_pretty_urls($post);
    if ($pretty === false) {
        $warnings[] = sprintf(
            'The rewrite rules do not serve `/%s/<item slug>/` yet: item URLs answer 404 until a collection writer here runs or the permalinks are saved; `?%s=<item slug>` works meanwhile.',
            $post->post_name,
            kk_item_post_type($post->ID),
        );
    }
    /** @var mixed $basic */
    $basic = kk_meta($post->ID, kk_meta_cm_basic_fields());
    return [
        'id' => $post->ID,
        'title' => $post->post_title,
        'slug' => $post->post_name,
        'status' => $post->post_status,
        'preset_type' => kk_cm_preset_type($post->ID),
        'basic_fields' => is_array($basic) && $basic !== [] ? $basic : kk_cm_default_basic_fields(),
        'fields' => $fields,
        'items' => kk_collection_item_counts($post->ID),
        'item_post_type' => kk_item_post_type($post->ID),
        'item_url_pattern' => kk_collection_item_url_pattern($post),
        'pretty_urls' => $pretty,
        'referenced_by' => kk_collection_references($post->ID),
        'modified' => kk_modified_gmt($post),
        'warnings' => $warnings,
    ];
}

/**
 * The labels Kirki's resource assumes when no `kirki_cm_basic_fields` row exists.
 *
 * @return array{post_title: array{title: string, help_text: string}, post_name: array{title: string, help_text: string}}
 */
function kk_cm_default_basic_fields(): array
{
    return [
        'post_title' => ['title' => 'Name', 'help_text' => ''],
        'post_name' => ['title' => 'Slug', 'help_text' => ''],
    ];
}

// ---------------------------------------------------------------------------
// create-collection
// ---------------------------------------------------------------------------

wp_register_ability('novamira/kirki-create-collection', [
    'label' => __('Create Kirki Collection', domain: 'novamira-pro'),
    'description' => __(
        'Creates a Content Manager collection the way the editor\'s Dynamic Content → New Collection does: a published `kirki_cm` post (title, slug) whose `kirki_cm_fields` meta holds the given field definitions completed with the editor\'s per-type defaults and fresh ids. Then registers the items\' public post type (`kirki_cm_<id>`, rewrite base = the slug) and flushes the rewrite rules so `/<slug>/<item slug>/` works at once. Slugs in Kirki\'s reserved list (attachment, author, category, comment, feed, page, post, tag, profile, index) or used by another collection are refused; a published page owning the same root slug is reported (the collection rewrite wins). Fields: `type` (16 types), `title` (unique), `required`, `default_value`, per-type keys (options, character_limit, number_format, ref_collection, …). Written in one transaction, read back and verified; a refused write leaves no post. Refused while ANY Kirki editor tab is open (`kirki_editor_open`). Also accepted: `post_title`, `post_name`.',
        domain: 'novamira-pro',
    ),
    'category' => 'kirki',
    'input_schema' => [
        'type' => 'object',
        'properties' => [
            'title' => [
                'type' => 'string',
                'description' => 'Collection name (1–200 bytes, plain). Also accepted as `post_title`.',
            ],
            'post_title' => ['type' => 'string', 'description' => 'Alias of `title`.'],
            'slug' => [
                'type' => 'string',
                'description' => 'URL base of the items (default: from the title). Also accepted as `post_name`.',
            ],
            'post_name' => ['type' => 'string', 'description' => 'Alias of `slug`.'],
            'fields' => KK_CM_FIELDS_SCHEMA,
            'basic_fields' => [
                'type' => 'object',
                'description' => 'Optional labels of the Name / Slug inputs: `{post_title: {title, help_text}, post_name: {title, help_text}}`.',
            ],
            'allow_open_editor' => KK_ALLOW_OPEN_EDITOR_SCHEMA,
        ],
        'required' => [],
        'additionalProperties' => false,
    ],
    'output_schema' => [
        'type' => 'object',
        'properties' => [
            'id' => ['type' => 'integer'],
            'title' => ['type' => 'string'],
            'slug' => ['type' => 'string'],
            'status' => ['type' => 'string'],
            'fields' => KK_CM_FIELD_SUMMARY_OUTPUT,
            'item_post_type' => ['type' => 'string'],
            'item_url_pattern' => ['type' => 'string'],
            'pretty_urls' => ['type' => ['boolean', 'null'], 'description' => KK_CM_PRETTY_URLS_DESCRIPTION],
            'written' => ['type' => 'array', 'items' => ['type' => 'string']],
            'warnings' => ['type' => 'array', 'items' => ['type' => 'string']],
        ],
        'required' => [
            'id',
            'title',
            'slug',
            'status',
            'fields',
            'item_post_type',
            'item_url_pattern',
            'pretty_urls',
            'written',
            'warnings',
        ],
        'additionalProperties' => false,
    ],
    'execute_callback' => 'Novamira\\Pro\\Abilities\\Kirki\\kirki_create_collection',
    'permission_callback' => 'novamira_permission_callback',
    'meta' => [
        'show_in_rest' => true,
        'mcp' => ['public' => true],
        'annotations' => [
            'instructions' => 'Define the fields up front (removing one later deletes its values on every item). Then add items with kirki-create-collection-item and render them through a template whose conditions target `item_post_type` with elements bound by `dynamicContent: {type: "post", value: "<field id>"}`.',
            'readonly' => false,
            'destructive' => false,
            'idempotent' => false,
        ],
    ],
]);

/**
 * @param array<string, mixed> $input
 * @return array<string, mixed>|WP_Error
 */
// @mago-expect lint:cyclomatic-complexity -- one refusal per branch, all flat
function kirki_create_collection(array $input): array|WP_Error
{
    kk_begin();
    /** @var mixed $title */
    $title = $input['title'] ?? $input['post_title'] ?? null;
    $title_error = kk_cm_label_error($title, field: 'title', required: true);
    if ($title_error !== null) {
        return kk_invalid_input($title_error);
    }
    $title = is_string($title) ? trim($title) : '';
    $slug = kk_cm_slug_input($input['slug'] ?? $input['post_name'] ?? null, $title);
    if ($slug instanceof WP_Error) {
        return $slug;
    }
    $slug_error = kk_cm_collection_slug_error($slug, exclude: 0);
    if ($slug_error !== null) {
        return $slug_error;
    }
    $checked = kk_cm_validate_field_defs(is_array($input['fields'] ?? null) ? $input['fields'] : [], []);
    if ($checked['errors'] !== []) {
        return kk_invalid_input(implode(' ', $checked['errors']));
    }
    $basic = kk_cm_basic_fields_input($input['basic_fields'] ?? null);
    if ($basic instanceof WP_Error) {
        return $basic;
    }
    $open = kk_refuse_open_editor_global($input['allow_open_editor'] ?? false);
    if ($open instanceof WP_Error) {
        return $open;
    }
    $collection_id = wp_insert_post([
        'post_type' => kk_collection_post_type(),
        'post_status' => 'publish',
        'post_title' => $title,
        'post_name' => $slug,
    ], wp_error: true);
    if ($collection_id instanceof WP_Error) {
        return new WP_Error(
            'kirki_create_failed',
            __('WordPress refused to insert the collection post.', domain: 'novamira-pro'),
            ['status' => 500],
        );
    }
    $writes = [kk_meta_cm_fields() => $checked['fields']];
    if ($basic !== null) {
        $writes[kk_meta_cm_basic_fields()] = $basic;
    }
    $written = kk_with_post_lock($collection_id, static fn(): bool|WP_Error => kk_write_meta_verified(
        $collection_id,
        $writes,
    ));
    if ($written instanceof WP_Error) {
        wp_delete_post($collection_id, force_delete: true);
        return $written;
    }
    $post = kk_live_post($collection_id);
    if (!$post instanceof WP_Post) {
        return kk_invalid_post($collection_id);
    }
    kk_register_item_post_type($post);
    flush_rewrite_rules(hard: false);
    $warnings = array_merge($checked['warnings'], kk_cm_slug_warnings($post));
    $keys = array_keys($writes);
    return [
        'id' => $post->ID,
        'title' => $post->post_title,
        'slug' => $post->post_name,
        'status' => $post->post_status,
        'fields' => kk_cm_field_summaries($checked['fields']),
        'item_post_type' => kk_item_post_type($post->ID),
        'item_url_pattern' => kk_collection_item_url_pattern($post),
        'pretty_urls' => kk_collection_pretty_urls($post),
        'written' => array_merge(['post'], $keys),
        'warnings' => $warnings,
    ];
}

/** The slug to store: the given one sanitised, or the title's. */
function kk_cm_slug_input(mixed $given, string $title): string|WP_Error
{
    if ($given === null) {
        $slug = sanitize_title($title);
        return $slug !== ''
            ? $slug
            : kk_invalid_input('`slug` is required when the title yields no slug (no letters or digits).');
    }
    if (!is_string($given) || trim($given) === '') {
        return kk_invalid_input('`slug` must be a non-empty string.');
    }
    $slug = sanitize_title($given);
    if ($slug === '' || $slug !== trim($given)) {
        return kk_invalid_input(sprintf(
            '`slug` must already be in URL form (lowercase letters, digits, hyphens): `%s` would become `%s`.',
            trim($given),
            $slug,
        ));
    }
    return $slug;
}

/** Reserved words and other live collections (Kirki's `validate_slug`). */
function kk_cm_collection_slug_error(string $slug, int $exclude): ?WP_Error
{
    if (in_array($slug, KK_CM_RESERVED_SLUGS, strict: true)) {
        return kk_invalid_input(sprintf(
            '`slug` `%s` is reserved by Kirki (%s).',
            $slug,
            implode(', ', KK_CM_RESERVED_SLUGS),
        ));
    }
    $holder = kk_cm_slug_holder($slug, kk_collection_post_type(), $exclude);
    if ($holder !== null) {
        return new WP_Error(
            'kirki_slug_collision',
            sprintf(
                /* translators: 1: slug, 2: post id */
                __('Slug `%1$s` is already used by collection %2$d.', domain: 'novamira-pro'),
                $slug,
                $holder,
            ),
            ['status' => 409],
        );
    }
    return null;
}

/** Id of the live post of `$post_type` owning `$slug`, excluding one id; null when free. */
function kk_cm_slug_holder(string $slug, string $post_type, int $exclude): ?int
{
    global $wpdb;
    /** @var \wpdb $wpdb */
    // @mago-expect analysis:possibly-invalid-argument
    $sql = (string) $wpdb->prepare(
        "SELECT ID FROM {$wpdb->posts} WHERE post_name = %s AND post_type = %s AND post_status IN ('draft', 'publish', 'future', 'pending', 'private') AND ID <> %d LIMIT 1",
        $slug,
        $post_type,
        $exclude,
    );
    /** @var mixed $id */
    $id = $wpdb->get_var($sql);
    return kk_coerce_int_or_null($id);
}

/**
 * A published page / post owning the collection's root slug: `/<slug>/` keeps
 * serving it but `/<slug>/<child>/` is taken by the items.
 *
 * @return list<string>
 */
function kk_cm_slug_warnings(WP_Post $collection): array
{
    global $wpdb;
    /** @var \wpdb $wpdb */
    // @mago-expect analysis:possibly-invalid-argument
    $sql = (string) $wpdb->prepare(
        "SELECT ID, post_type FROM {$wpdb->posts} WHERE post_name = %s AND post_type IN ('page', 'post') AND post_status = 'publish' AND post_parent = 0 LIMIT 1",
        $collection->post_name,
    );
    /** @var mixed $row */
    $row = $wpdb->get_row($sql, 'ARRAY_A');
    if (!is_array($row)) {
        return [];
    }
    return [
        sprintf(
            'A published %s (%d) already owns the root slug `%s`: `/%s/` keeps serving it, but every `/%s/<child>/` path now resolves to a collection item (or 404) before the child page.',
            (string) $row['post_type'],
            kk_coerce_int_or_null($row['ID'] ?? null) ?? 0,
            $collection->post_name,
            $collection->post_name,
            $collection->post_name,
        ),
    ];
}

/**
 * @return array<string, array{title: string, help_text: string}>|null|WP_Error
 */
// @mago-expect lint:cyclomatic-complexity -- one check per label
function kk_cm_basic_fields_input(mixed $given): array|null|WP_Error
{
    if ($given === null) {
        return null;
    }
    if (!is_array($given) || kk_is_list($given)) {
        return kk_invalid_input(
            '`basic_fields` must be an object `{post_title: {title, help_text}, post_name: {title, help_text}}`.',
        );
    }
    $out = kk_cm_default_basic_fields();
    foreach (['post_title', 'post_name'] as $key) {
        if (!array_key_exists($key, $given)) {
            continue;
        }
        /** @var mixed $entry */
        $entry = $given[$key];
        if (!is_array($entry) || kk_is_list($entry)) {
            return kk_invalid_input(sprintf('`basic_fields.%s` must be an object `{title, help_text}`.', $key));
        }
        $title_error = kk_cm_label_error(
            $entry['title'] ?? null,
            sprintf('basic_fields.%s.title', $key),
            required: true,
        );
        $help_error = kk_cm_label_error(
            $entry['help_text'] ?? null,
            sprintf('basic_fields.%s.help_text', $key),
            required: false,
        );
        if ($title_error !== null || $help_error !== null) {
            return kk_invalid_input($title_error ?? $help_error ?? '');
        }
        $out[$key] = [
            'title' => trim((string) $entry['title']),
            'help_text' => is_string($entry['help_text'] ?? null) ? $entry['help_text'] : '',
        ];
    }
    $unknown = array_diff(array_keys($given), ['post_title', 'post_name']);
    if ($unknown !== []) {
        return kk_invalid_input(sprintf('`basic_fields` accepts `post_title` and `post_name` only (got `%s`).', implode('`, `', array_map(
            'strval',
            $unknown,
        ))));
    }
    return $out;
}

// ---------------------------------------------------------------------------
// edit-collection
// ---------------------------------------------------------------------------

wp_register_ability('novamira/kirki-edit-collection', [
    'label' => __('Edit Kirki Collection', domain: 'novamira-pro'),
    'description' => __(
        'Edits a Content Manager collection: `title`, `slug` (the item URLs change; the rewrite rules are flushed), `basic_fields`, and `fields`, which REPLACES the stored definition list the way the editor\'s Save does — pass the stored `id` on every field to keep (its item values follow the id; a kept id cannot change type), omit the id on new fields. Stored fields missing from the list are removed: refused (`kirki_field_removal`, 409, listing how many items hold data per field) unless `confirm_field_removal: true`, which deletes their item values and reference rows on every item in the same transaction (what Kirki\'s `cleanup_old_field_data` does). Every write is read back and verified; identical input is a no-op (`written: []`). Refused while ANY Kirki editor tab is open (`kirki_editor_open`). Also accepted: `post_title`, `post_name`.',
        domain: 'novamira-pro',
    ),
    'category' => 'kirki',
    'input_schema' => [
        'type' => 'object',
        'properties' => [
            'collection_id' => ['type' => 'integer', 'description' => 'Id of the collection.'],
            'title' => ['type' => 'string', 'description' => 'New name. Also accepted as `post_title`.'],
            'post_title' => ['type' => 'string', 'description' => 'Alias of `title`.'],
            'slug' => ['type' => 'string', 'description' => 'New URL base of the items. Also accepted as `post_name`.'],
            'post_name' => ['type' => 'string', 'description' => 'Alias of `slug`.'],
            'fields' => KK_CM_FIELDS_SCHEMA,
            'basic_fields' => [
                'type' => 'object',
                'description' => 'Labels of the Name / Slug inputs: `{post_title: {title, help_text}, post_name: {title, help_text}}`.',
            ],
            'confirm_field_removal' => [
                'type' => 'boolean',
                'description' => 'Allow `fields` to drop stored fields, deleting their values on every item. Default false.',
                'default' => false,
            ],
            'allow_open_editor' => KK_ALLOW_OPEN_EDITOR_SCHEMA,
        ],
        'required' => ['collection_id'],
        'additionalProperties' => false,
    ],
    'output_schema' => [
        'type' => 'object',
        'properties' => [
            'collection_id' => ['type' => 'integer'],
            'title' => ['type' => 'string'],
            'slug' => ['type' => 'string'],
            'fields' => KK_CM_FIELD_SUMMARY_OUTPUT,
            'removed_fields' => [
                'type' => 'array',
                'items' => [
                    'type' => 'object',
                    'properties' => [
                        'id' => ['type' => 'string'],
                        'title' => ['type' => 'string'],
                        'items_with_data' => ['type' => 'integer'],
                    ],
                    'required' => ['id', 'title', 'items_with_data'],
                    'additionalProperties' => false,
                ],
            ],
            'pretty_urls' => ['type' => ['boolean', 'null'], 'description' => KK_CM_PRETTY_URLS_DESCRIPTION],
            'written' => [
                'type' => 'array',
                'items' => ['type' => 'string'],
                'description' => 'What changed: `title`, `slug`, `fields`, `basic_fields`.',
            ],
            'warnings' => ['type' => 'array', 'items' => ['type' => 'string']],
        ],
        'required' => [
            'collection_id',
            'title',
            'slug',
            'fields',
            'removed_fields',
            'pretty_urls',
            'written',
            'warnings',
        ],
        'additionalProperties' => false,
    ],
    'execute_callback' => 'Novamira\\Pro\\Abilities\\Kirki\\kirki_edit_collection',
    'permission_callback' => 'novamira_permission_callback',
    'meta' => [
        'show_in_rest' => true,
        'mcp' => ['public' => true],
        'annotations' => [
            'instructions' => 'To add a field: kirki-get-collection, append the new definition to the stored `fields` (ids kept), send the whole list. Never send a partial list without `confirm_field_removal`: the missing fields would be deleted with their data.',
            'readonly' => false,
            'destructive' => true,
            'idempotent' => true,
        ],
    ],
]);

/**
 * @param array<string, mixed> $input
 * @return array<string, mixed>|WP_Error
 */
// @mago-expect lint:cyclomatic-complexity -- one refusal per branch, all flat
// @mago-expect lint:halstead
function kirki_edit_collection(array $input): array|WP_Error
{
    kk_begin();
    $post = kk_collection_post_or_error(kk_coerce_int_or_null($input['collection_id'] ?? null) ?? 0);
    if ($post instanceof WP_Error) {
        return $post;
    }
    /** @var mixed $title_raw */
    $title_raw = $input['title'] ?? $input['post_title'] ?? null;
    $title_error = kk_cm_label_error($title_raw, field: 'title', required: false);
    if ($title_error !== null || $title_raw !== null && trim((string) $title_raw) === '') {
        return kk_invalid_input($title_error ?? '`title` must not be blank.');
    }
    $title = is_string($title_raw) ? trim($title_raw) : $post->post_title;
    /** @var mixed $slug_raw */
    $slug_raw = $input['slug'] ?? $input['post_name'] ?? null;
    $slug = $slug_raw === null ? $post->post_name : kk_cm_slug_input($slug_raw, $title);
    if ($slug instanceof WP_Error) {
        return $slug;
    }
    if ($slug !== $post->post_name) {
        $slug_error = kk_cm_collection_slug_error($slug, exclude: $post->ID);
        if ($slug_error !== null) {
            return $slug_error;
        }
    }
    $fields_given = array_key_exists('fields', $input);
    $basic = kk_cm_basic_fields_input($input['basic_fields'] ?? null);
    if ($basic instanceof WP_Error) {
        return $basic;
    }
    if ($title_raw === null && $slug_raw === null && !$fields_given && $basic === null) {
        return kk_invalid_input('Nothing to change: pass `title`, `slug`, `fields` or `basic_fields`.');
    }
    // Fail fast on a field list that is wrong whatever is stored, so a bad
    // input never waits for the lock. The authoritative validation happens
    // again INSIDE it, against the stored list as it is at write time.
    $preflight = $fields_given
        ? kk_cm_validate_field_defs(is_array($input['fields']) ? $input['fields'] : [], kk_cm_stored_defs($post->ID))
        : ['errors' => [], 'fields' => [], 'warnings' => []];
    if ($preflight['errors'] !== []) {
        return kk_invalid_input(implode(' ', $preflight['errors']));
    }
    $open = kk_refuse_open_editor_global($input['allow_open_editor'] ?? false);
    if ($open instanceof WP_Error) {
        return $open;
    }
    $collection_id = $post->ID;
    $confirmed = kk_bool($input['confirm_field_removal'] ?? false);
    $given_fields = $fields_given && is_array($input['fields']) ? $input['fields'] : [];
    $stored_title = $post->post_title;
    $stored_slug = $post->post_name;
    // Read, diff and write in ONE locked span: reading the stored list before
    // the lock would let two concurrent edits start from the same snapshot, and
    // the second write would silently discard the first.
    $result = kk_with_post_lock($collection_id, static fn(): array|WP_Error => kk_db_transaction($collection_id, static fn(): array|WP_Error => kk_cm_edit_collection_locked($collection_id, [
        'fields_given' => $fields_given,
        'fields' => $given_fields,
        'confirmed' => $confirmed,
        'basic' => $basic,
        'title' => $title,
        'slug' => $slug,
        'stored_title' => $stored_title,
        'stored_slug' => $stored_slug,
    ])));
    if ($result instanceof WP_Error) {
        return $result;
    }
    $written = $result['written'];
    $removed = $result['removed'];
    $checked = ['warnings' => $result['warnings']];
    $fresh = kk_live_post($collection_id);
    if (!$fresh instanceof WP_Post) {
        return kk_invalid_post($collection_id);
    }
    $warnings = $checked['warnings'];
    if (in_array('slug', $written, strict: true)) {
        kk_register_item_post_type($fresh);
        flush_rewrite_rules(hard: false);
        $warnings[] = sprintf(
            'The canonical item URLs moved to `/%s/<item slug>/` (permalinks, sitemaps, the editor); WordPress may keep resolving the old `/%s/<item slug>/` paths by item slug, they are no longer canonical.',
            $fresh->post_name,
            $post->post_name,
        );
        $warnings = array_merge($warnings, kk_cm_slug_warnings($fresh));
    }
    return [
        'collection_id' => $fresh->ID,
        'title' => $fresh->post_title,
        'slug' => $fresh->post_name,
        'fields' => kk_cm_field_summaries(kk_cm_stored_defs($fresh->ID)),
        'removed_fields' => $removed,
        'pretty_urls' => kk_collection_pretty_urls($fresh),
        'written' => $written,
        'warnings' => $warnings,
    ];
}

/**
 * The whole read → validate → diff → write cycle of `edit-collection`, run
 * inside the collection's lock and its transaction. Everything that depends
 * on the STORED state is computed here, never before the lock, so two
 * concurrent edits cannot start from the same snapshot and have the later
 * write discard the earlier one while both report success.
 *
 * @param array{fields_given: bool, fields: array<array-key, mixed>, confirmed: bool, basic: array<string, mixed>|null, title: string, slug: string, stored_title: string, stored_slug: string} $input
 * @return array{written: list<string>, removed: list<array<string, mixed>>, warnings: list<string>}|WP_Error
 */
// @mago-expect lint:halstead -- the whole diff of one collection, deliberately in one place
function kk_cm_edit_collection_locked(int $collection_id, array $input): array|WP_Error
{
    $stored = kk_cm_stored_defs($collection_id);
    $checked = $input['fields_given']
        ? kk_cm_validate_field_defs($input['fields'], $stored)
        : ['errors' => [], 'fields' => $stored, 'warnings' => []];
    if ($checked['errors'] !== []) {
        return kk_invalid_input(implode(' ', $checked['errors']));
    }
    $removed = $input['fields_given'] ? kk_cm_removed_fields($collection_id, $stored, $checked['fields']) : [];
    if ($removed !== [] && !$input['confirmed']) {
        return kk_cm_field_removal_error($collection_id, $removed);
    }
    $written = [];
    $writes = [];
    /** @var mixed $stored_raw */
    $stored_raw = kk_meta($collection_id, kk_meta_cm_fields());
    if ($input['fields_given'] && $stored_raw !== $checked['fields']) {
        $writes[kk_meta_cm_fields()] = $checked['fields'];
        $written[] = 'fields';
    }
    /** @var mixed $basic_stored */
    $basic_stored = kk_meta($collection_id, kk_meta_cm_basic_fields());
    if ($input['basic'] !== null && $basic_stored !== $input['basic']) {
        $writes[kk_meta_cm_basic_fields()] = $input['basic'];
        $written[] = 'basic_fields';
    }
    $post_changes = [];
    if ($input['title'] !== $input['stored_title']) {
        $post_changes['post_title'] = $input['title'];
        $written[] = 'title';
    }
    if ($input['slug'] !== $input['stored_slug']) {
        $post_changes['post_name'] = $input['slug'];
        $written[] = 'slug';
    }
    if ($writes !== []) {
        $ok = kk_write_meta_verified($collection_id, $writes);
        if ($ok instanceof WP_Error) {
            return $ok;
        }
    }
    $cleaned = kk_cm_delete_field_data($collection_id, array_column($removed, 'id'));
    if ($cleaned instanceof WP_Error) {
        return $cleaned;
    }
    $updated = kk_cm_update_post_verified($collection_id, $post_changes);
    if ($updated instanceof WP_Error) {
        return $updated;
    }
    return ['written' => $written, 'removed' => $removed, 'warnings' => $checked['warnings']];
}

/**
 * Stored fields absent from the new list, with the number of items holding
 * a value (meta row or reference row) for each.
 *
 * @param list<array<string, mixed>> $stored
 * @param list<array<string, mixed>> $next
 * @return list<array{id: string, title: string, items_with_data: int}>
 */
function kk_cm_removed_fields(int $collection_id, array $stored, array $next): array
{
    global $wpdb;
    /** @var \wpdb $wpdb */
    $kept = [];
    foreach ($next as $def) {
        $kept[(string) $def['id']] = true;
    }
    $out = [];
    foreach ($stored as $def) {
        $id = (string) $def['id'];
        if (isset($kept[$id])) {
            continue;
        }
        $key = kk_field_meta_key($collection_id, $id);
        $table = kk_reference_table();
        // @mago-expect analysis:possibly-invalid-argument
        $sql = (string) $wpdb->prepare(
            "SELECT COUNT(DISTINCT post_id) FROM (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s UNION SELECT post_id FROM {$table} WHERE field_meta_key = %s) AS holders",
            $key,
            $key,
        );
        $out[] = [
            'id' => $id,
            'title' => (string) ($def['title'] ?? ''),
            'items_with_data' => kk_coerce_int_or_null($wpdb->get_var($sql)) ?? 0,
        ];
    }
    return $out;
}

/** @param list<array{id: string, title: string, items_with_data: int}> $removed */
function kk_cm_field_removal_error(int $collection_id, array $removed): WP_Error
{
    $parts = [];
    foreach ($removed as $field) {
        $parts[] = sprintf('`%s` (%s, %d item(s) with data)', $field['id'], $field['title'], $field['items_with_data']);
    }
    return new WP_Error(
        'kirki_field_removal',
        sprintf(
            /* translators: 1: collection id, 2: field list */
            __(
                'The new `fields` list drops stored field(s) of collection %1$d: %2$s. Kirki deletes their values and reference rows on every item when a field is removed; pass `confirm_field_removal: true` to do that, or include the stored ids to keep them.',
                domain: 'novamira-pro',
            ),
            $collection_id,
            implode(', ', $parts),
        ),
        ['status' => 409, 'removed_fields' => $removed],
    );
}

/**
 * Delete the meta rows and reference rows of the given fields on every item
 * (Kirki's `cleanup_old_field_data`), verified: none may remain.
 *
 * @param list<string> $field_ids
 */
function kk_cm_delete_field_data(int $collection_id, array $field_ids): bool|WP_Error
{
    global $wpdb;
    /** @var \wpdb $wpdb */
    if ($field_ids === []) {
        return true;
    }
    $keys = array_map(static fn(string $id): string => kk_field_meta_key($collection_id, $id), $field_ids);
    $placeholders = implode(', ', array_fill(start_index: 0, count: count($keys), value: '%s'));
    $table = kk_reference_table();
    // @mago-expect analysis:possibly-invalid-argument
    $holders = array_map(
        'intval',
        $wpdb->get_col((string) $wpdb->prepare(
            "SELECT DISTINCT post_id FROM {$wpdb->postmeta} WHERE meta_key IN ({$placeholders})",
            ...$keys,
        )),
    );
    // @mago-expect analysis:possibly-invalid-argument
    $wpdb->query((string) $wpdb->prepare(
        "DELETE FROM {$wpdb->postmeta} WHERE meta_key IN ({$placeholders})",
        ...$keys,
    ));
    // @mago-expect analysis:possibly-invalid-argument
    $wpdb->query((string) $wpdb->prepare("DELETE FROM {$table} WHERE field_meta_key IN ({$placeholders})", ...$keys));
    // @mago-expect analysis:possibly-invalid-argument
    // @mago-expect analysis:possibly-invalid-argument
    $left =
        kk_coerce_int_or_null($wpdb->get_var((string) $wpdb->prepare(
            "SELECT (SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key IN ({$placeholders})) + (SELECT COUNT(*) FROM {$table} WHERE field_meta_key IN ({$placeholders}))",
            ...array_merge($keys, $keys),
        ))) ?? 1;
    foreach ($holders as $holder) {
        kk_refresh($holder);
    }
    if ($left !== 0) {
        return new WP_Error(
            'kirki_write_failed',
            sprintf(
                /* translators: 1: collection id, 2: rows left */
                __(
                    'The item values of the removed fields of collection %1$d could not all be deleted (%2$d row(s) remain); nothing was changed.',
                    domain: 'novamira-pro',
                ),
                $collection_id,
                $left,
            ),
            ['status' => 500],
        );
    }
    return true;
}

/**
 * `wp_update_post` on the columns given, then read back: each must hold the
 * new value (a hook may rewrite the slug or the title).
 *
 * @param array<string, string> $changes column => value
 */
function kk_cm_update_post_verified(int $post_id, array $changes): bool|WP_Error
{
    if ($changes === []) {
        return true;
    }
    /** @var array<string, mixed> $payload */
    $payload = ['ID' => $post_id] + $changes;
    $result = wp_update_post($payload, wp_error: true);
    if ($result instanceof WP_Error) {
        return new WP_Error(
            'kirki_write_failed',
            sprintf(
                /* translators: 1: post id, 2: WordPress message */
                __('WordPress refused to update post %1$d (%2$s); nothing was changed.', domain: 'novamira-pro'),
                $post_id,
                $result->get_error_message(),
            ),
            ['status' => 500],
        );
    }
    clean_post_cache($post_id);
    // @mago-expect analysis:mixed-assignment
    $fresh = get_post($post_id);
    foreach ($changes as $column => $value) {
        /** @var mixed $stored */
        $stored = $fresh instanceof WP_Post ? get_object_vars($fresh)[$column] ?? null : null;
        if (!is_string($stored) || $stored !== $value) {
            return new WP_Error(
                'kirki_write_failed',
                sprintf(
                    /* translators: 1: column, 2: post id */
                    __(
                        '`%1$s` of post %2$d did not take the given value (a hook rewrote it); nothing was changed.',
                        domain: 'novamira-pro',
                    ),
                    $column,
                    $post_id,
                ),
                ['status' => 500],
            );
        }
    }
    return true;
}

// ---------------------------------------------------------------------------
// delete-collection
// ---------------------------------------------------------------------------

wp_register_ability('novamira/kirki-delete-collection', [
    'label' => __('Delete Kirki Collection', domain: 'novamira-pro'),
    'description' => __(
        'Deletes a Content Manager collection permanently (no trash, as the editor\'s Delete does), with every item, their values and reference rows. Refused (`kirki_collection_in_use`, 409) while the collection has items — trashed ones included, they are real rows this call destroys — unless `force: true`. Templates whose conditions target the items and pages bound to the collection are listed in `referenced_by` (Kirki leaves them in place: such a template never matches again, a bound page keeps rendering a missing collection), together with `referenced_by.referencing_items`: the other collections whose reference fields point at these items, whose stored references the database drops with the items (those fields then read empty) — one warning per referring collection. Verified: the collection row, the item rows and their meta must be gone; the rewrite rules are flushed. Meta rows carrying this collection\'s field keys under a post it did not delete (items removed outside WordPress) are reported as `orphan_meta_rows`, not deleted, and never block the call. Refused while ANY Kirki editor tab is open (`kirki_editor_open`).',
        domain: 'novamira-pro',
    ),
    'category' => 'kirki',
    'input_schema' => [
        'type' => 'object',
        'properties' => [
            'collection_id' => ['type' => 'integer', 'description' => 'Id of the collection.'],
            'force' => [
                'type' => 'boolean',
                'description' => 'Delete even when items exist (they are deleted too). Default false.',
                'default' => false,
            ],
            'allow_open_editor' => KK_ALLOW_OPEN_EDITOR_SCHEMA,
        ],
        'required' => ['collection_id'],
        'additionalProperties' => false,
    ],
    'output_schema' => [
        'type' => 'object',
        'properties' => [
            'collection_id' => ['type' => 'integer'],
            'deleted' => ['type' => 'boolean'],
            'items_deleted' => ['type' => 'integer'],
            'orphan_meta_rows' => [
                'type' => 'integer',
                'description' => 'Meta rows carrying this collection\'s field keys that belong to no post it deleted (items removed outside WordPress): reported, not deleted.',
            ],
            'referenced_by' => KK_CM_REFERENCED_BY_OUTPUT,
            'warnings' => ['type' => 'array', 'items' => ['type' => 'string']],
        ],
        'required' => ['collection_id', 'deleted', 'items_deleted', 'orphan_meta_rows', 'referenced_by', 'warnings'],
        'additionalProperties' => false,
    ],
    'execute_callback' => 'Novamira\\Pro\\Abilities\\Kirki\\kirki_delete_collection',
    'permission_callback' => 'novamira_permission_callback',
    'meta' => [
        'show_in_rest' => true,
        'mcp' => ['public' => true],
        'annotations' => [
            'instructions' => 'Check kirki-get-collection first: `items.total` and `referenced_by` tell what goes with it. Permanent.',
            'readonly' => false,
            'destructive' => true,
            'idempotent' => false,
        ],
    ],
]);

/**
 * @param array<string, mixed> $input
 * @return array<string, mixed>|WP_Error
 */
function kirki_delete_collection(array $input): array|WP_Error
{
    kk_begin();
    $post = kk_collection_post_or_error(kk_coerce_int_or_null($input['collection_id'] ?? null) ?? 0);
    if ($post instanceof WP_Error) {
        return $post;
    }
    $counts = kk_collection_item_counts($post->ID);
    if ($counts['total'] > 0 && !kk_bool($input['force'] ?? false)) {
        return new WP_Error(
            'kirki_collection_in_use',
            sprintf(
                /* translators: 1: collection id, 2: item count */
                __(
                    'Collection %1$d holds %2$d item(s)%3$s. Pass `force: true` to delete it with every item (permanent).',
                    domain: 'novamira-pro',
                ),
                $post->ID,
                $counts['total'],
                $counts['trash'] > 0
                    ? sprintf(
                        /* translators: %d: trashed item count */
                        __(', %d of them in the trash', domain: 'novamira-pro'),
                        $counts['trash'],
                    )
                    : '',
            ),
            ['status' => 409, 'items' => $counts],
        );
    }
    $open = kk_refuse_open_editor_global($input['allow_open_editor'] ?? false);
    if ($open instanceof WP_Error) {
        return $open;
    }
    $references = kk_collection_references($post->ID);
    $collection_id = $post->ID;
    $deleted = kk_with_post_lock($collection_id, static fn(): array|WP_Error => kk_db_transaction($collection_id, static fn(): array|WP_Error => kk_cm_delete_collection_rows(
        $collection_id,
    )));
    if ($deleted instanceof WP_Error) {
        return $deleted;
    }
    // The type is registered per collection at init: drop it now so this process
    // sees what the next one will (template conditions on it stop matching).
    if (post_type_exists(kk_item_post_type($collection_id))) {
        unregister_post_type(kk_item_post_type($collection_id));
    }
    flush_rewrite_rules(hard: false);
    return [
        'collection_id' => $collection_id,
        'deleted' => true,
        'items_deleted' => $deleted['items'],
        'orphan_meta_rows' => $deleted['orphans'],
        'referenced_by' => $references,
        'warnings' => kk_cm_delete_collection_warnings($references, $deleted['orphans']),
    ];
}

/**
 * What the caller has to know after the delete: the templates and pages Kirki
 * leaves pointing at nothing, the reference values the cascade emptied, and
 * the orphan meta rows the verification found.
 *
 * @param array{templates: list<array<string, mixed>>, pages: list<array<string, mixed>>, referencing_items: list<array<string, mixed>>} $references
 * @return list<string>
 */
// @mago-expect lint:cyclomatic-complexity -- one message per kind of leftover
function kk_cm_delete_collection_warnings(array $references, int $orphans): array
{
    $warnings = [];
    foreach ($references['templates'] as $template) {
        $warnings[] = sprintf(
            'Template %d (%s) targets the deleted items\' post type: its condition never matches again (remove it with kirki-set-template-conditions).',
            kk_coerce_int_or_null($template['post_id'] ?? null) ?? 0,
            strval($template['title'] ?? ''),
        );
    }
    foreach ($references['pages'] as $page) {
        $kind = strval($page['kind'] ?? '');
        $warnings[] = sprintf(
            'Page %d (%s) is bound to the deleted collection as its %s page; the binding meta stays.',
            kk_coerce_int_or_null($page['post_id'] ?? null) ?? 0,
            strval($page['title'] ?? ''),
            $kind !== '' ? $kind : 'dynamic',
        );
    }
    foreach ($references['referencing_items'] as $referrer) {
        $warnings[] = sprintf(
            'Collection %d (%s) held %d reference value(s) pointing at the deleted items, in %d of its own item(s) (for example `%s`): the database dropped those rows with the items, so those fields now read empty.',
            kk_coerce_int_or_null($referrer['collection_id'] ?? null) ?? 0,
            strval($referrer['collection_title'] ?? ''),
            kk_coerce_int_or_null($referrer['rows'] ?? null) ?? 0,
            kk_coerce_int_or_null($referrer['items'] ?? null) ?? 0,
            strval($referrer['sample_title'] ?? ''),
        );
    }
    if ($orphans > 0) {
        $warnings[] = sprintf(
            '%d meta row(s) carrying this collection\'s field keys belong to no post this call deleted: item rows removed outside WordPress left them behind and they are still in wp_postmeta.',
            $orphans,
        );
    }
    return $warnings;
}

/**
 * Delete every item of a collection (rows + meta, as Kirki's bulk delete
 * does through WordPress so the reference rows cascade), then the
 * collection; verified by fresh lookups.
 *
 * The verification counts the meta rows of the posts THIS call deleted. Rows
 * carrying the collection's field-key prefix under any other post id are
 * orphans left by an item row removed outside WordPress: they belong to no
 * post, so they are reported (`orphans`) instead of rolling the delete back.
 *
 * @return array{items: int, orphans: int}|WP_Error
 */
function kk_cm_delete_collection_rows(int $collection_id): array|WP_Error
{
    global $wpdb;
    /** @var \wpdb $wpdb */
    // @mago-expect analysis:possibly-invalid-argument
    $sql = (string) $wpdb->prepare(
        "SELECT ID FROM {$wpdb->posts} WHERE post_type = %s AND post_parent = %d",
        kk_item_post_type($collection_id),
        $collection_id,
    );
    /** @var list<int> $item_ids */
    $item_ids = array_map('intval', $wpdb->get_col($sql));
    foreach ($item_ids as $item_id) {
        $result = wp_delete_post($item_id, force_delete: true);
        if ($result === false || $result === null || get_post($item_id) !== null) {
            return kk_cm_delete_failed('item', $item_id);
        }
    }
    $result = wp_delete_post($collection_id, force_delete: true);
    if ($result === false || $result === null || get_post($collection_id) !== null) {
        return kk_cm_delete_failed('collection', $collection_id);
    }
    $deleted_ids = [$collection_id, ...$item_ids];
    $ids_sql = implode(', ', array_fill(start_index: 0, count: count($deleted_ids), value: '%d'));
    // @mago-expect analysis:possibly-invalid-argument
    $left_sql = (string) $wpdb->prepare(
        sprintf('SELECT COUNT(*) FROM %s WHERE post_id IN (%s)', $wpdb->postmeta, $ids_sql),
        ...$deleted_ids,
    );
    $left = kk_coerce_int_or_null($wpdb->get_var($left_sql)) ?? 1;
    if ($left !== 0) {
        return new WP_Error(
            'kirki_write_failed',
            sprintf(
                /* translators: 1: collection id, 2: rows */
                __(
                    '%2$d meta row(s) of collection %1$d survived the delete; the transaction was rolled back.',
                    domain: 'novamira-pro',
                ),
                $collection_id,
                $left,
            ),
            ['status' => 500],
        );
    }
    // @mago-expect analysis:possibly-invalid-argument
    $orphan_sql = (string) $wpdb->prepare(
        sprintf('SELECT COUNT(*) FROM %s WHERE meta_key LIKE %%s AND post_id NOT IN (%s)', $wpdb->postmeta, $ids_sql),
        $wpdb->esc_like(sprintf('%s_field_%d_', kk_collection_post_type(), $collection_id)) . '%',
        ...$deleted_ids,
    );
    return ['items' => count($item_ids), 'orphans' => kk_coerce_int_or_null($wpdb->get_var($orphan_sql)) ?? 0];
}

function kk_cm_delete_failed(string $what, int $post_id): WP_Error
{
    return new WP_Error(
        'kirki_delete_failed',
        sprintf(
            /* translators: 1: item / collection, 2: post id */
            __(
                'WordPress did not delete %1$s %2$d (a hook refused it or the row is still there); the transaction was rolled back.',
                domain: 'novamira-pro',
            ),
            $what,
            $post_id,
        ),
        ['status' => 500],
    );
}
