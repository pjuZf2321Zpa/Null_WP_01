<?php

// SPDX-FileCopyrightText: 2026 Ovation S.r.l. <dev@novamira.ai>
// SPDX-License-Identifier: AGPL-3.0-or-later

declare(strict_types=1);

namespace Novamira\Pro\Abilities\GeneratePress;

if (!defined('ABSPATH')) {
    exit();
}

wp_register_ability('novamira/generatepress-refresh-sites', [
    'label' => __('Refresh GeneratePress Site Library Catalogue', domain: 'novamira-pro'),
    'description' => __(
        'Fetches the catalogue of starter templates again from gpsites.co (network call) and caches it in the `generatepress_sites` option, replacing the cached list. generatepress-list-sites reads that cache: call this only when the list is empty or stale (the cache lasts 1 day). Returns whether the fetch left a catalogue, how many templates it holds and when the cache expires.',
        domain: 'novamira-pro',
    ),
    'category' => 'generatepress',
    'input_schema' => [
        'type' => 'object',
        'default' => [],
        'properties' => [],
        'additionalProperties' => false,
    ],
    'output_schema' => [
        'type' => 'object',
        'properties' => [
            'refreshed' => [
                'type' => 'boolean',
                'description' => 'False when the upstream fetch left the catalogue empty (network error, upstream 4xx/5xx, or no entries). Lets the agent distinguish a legitimately-empty catalogue from a broken refresh.',
            ],
            'total' => ['type' => 'integer'],
            'expires_at' => ['type' => 'integer'],
        ],
        'required' => ['refreshed', 'total'],
        'additionalProperties' => false,
    ],
    'execute_callback' => 'Novamira\\Pro\\Abilities\\GeneratePress\\generatepress_refresh_sites',
    'permission_callback' => 'novamira_permission_callback',
    'meta' => [
        'show_in_rest' => true,
        'mcp' => ['public' => true],
        'annotations' => [
            'instructions' => 'Use it when generatepress-list-sites returns no templates or the cache has expired, then call generatepress-list-sites again. It writes the `generatepress_sites` option.',
            'readonly' => false,
            'destructive' => false,
            'idempotent' => true,
        ],
    ],
]);

/**
 * gp_force_refresh_sites_catalogue dispatches the upstream REST endpoint and writes the option as a side
 * effect. A network failure leaves the option empty or set to the literal string "no results", so the
 * option is read back to tell a broken fetch from a catalogue that is legitimately empty.
 *
 * @param array<string, mixed> $input
 * @return array<string, mixed>
 */
function generatepress_refresh_sites(array $input = []): array
{
    gp_force_refresh_sites_catalogue();

    /** @var mixed $raw */
    $raw = get_option('generatepress_sites', []);
    $sites = is_array($raw) ? $raw : [];

    /** @var mixed $expires_raw */
    $expires_raw = get_option(option: 'generatepress_sites_expiration', default_value: 0);

    return [
        'refreshed' => $sites !== [],
        'total' => count($sites),
        'expires_at' => is_numeric($expires_raw) ? (int) $expires_raw : 0,
    ];
}
