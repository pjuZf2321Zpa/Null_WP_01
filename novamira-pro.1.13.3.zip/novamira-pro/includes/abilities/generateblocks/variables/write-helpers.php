<?php

// SPDX-FileCopyrightText: 2026 Ovation S.r.l. <dev@novamira.ai>
// SPDX-License-Identifier: AGPL-3.0-or-later

declare(strict_types=1);

namespace Novamira\Pro\Abilities\GenerateBlocks;

use GenerateBlocks_Pro_Design_Tokens;
use GenerateBlocks_Pro_Styles_Root;
use Normalizer;
use UnexpectedValueException;
use WP_Error;

if (!defined('ABSPATH')) {
    exit();
}

/**
 * The write path shared by the Design Tokens create, edit and delete
 * abilities.
 *
 * GenerateBlocks Pro saves the `:root` record as one aggregate (styles,
 * compiled CSS, registry) through GenerateBlocks_Pro_Styles_Root::save(), a
 * compare-and-save on a checksum with no lock, and it stores the CSS the
 * caller sends. Every write here therefore:
 *   1. holds a MySQL named lock, so two Novamira writes never interleave;
 *   2. reads the record and its checksum;
 *   3. recompiles the CURRENT styles with gbv_css_root() and refuses unless
 *      the result is byte-identical to the stored CSS (the drift guard: it
 *      proves, on this site, that the port reproduces the Design dashboard,
 *      and it refuses any record the port does not cover);
 *   4. applies the change, compiles the new CSS and saves through the vendor,
 *      which re-validates the values, keeps a snapshot and rebuilds the
 *      front-end stylesheet.
 */

/**
 * The style properties the Design Tokens screen lets a token of each type
 * apply to (its `rt` table; the screen drops any other entry). A new colour
 * token applies to every colour property; unit and text tokens start with none.
 */
const GBV_SCOPE_BY_TYPE = [
    'color' => [
        'color',
        'backgroundColor',
        'borderTopColor',
        'borderRightColor',
        'borderBottomColor',
        'borderLeftColor',
    ],
    'unit' => [
        'fontSize',
        'lineHeight',
        'letterSpacing',
        'paddingTop',
        'paddingRight',
        'paddingBottom',
        'paddingLeft',
        'marginTop',
        'marginRight',
        'marginBottom',
        'marginLeft',
        'columnGap',
        'rowGap',
        'width',
        'height',
        'minWidth',
        'minHeight',
        'maxWidth',
        'maxHeight',
        'borderTopWidth',
        'borderRightWidth',
        'borderBottomWidth',
        'borderLeftWidth',
        'borderTopLeftRadius',
        'borderTopRightRadius',
        'borderBottomRightRadius',
        'borderBottomLeftRadius',
    ],
    'text' => [
        'fontFamily',
        'aspectRatio',
        'backdropFilter',
        'transformOrigin',
        'gridTemplateColumns',
        'gridTemplateRows',
        'gridTemplateAreas',
        'gridAutoColumns',
        'gridAutoRows',
        'gridColumn',
        'gridRow',
        'gridArea',
        'containerName',
        'content',
        'cursor',
        'textWrap',
        'opacity',
        'listStyleImage',
        'fill',
        'stroke',
        'pointerEvents',
        'backgroundClip',
        'backgroundOrigin',
    ],
];

/** GenerateBlocks Pro's built-in breakpoints, used when its preset function is missing. */
const GBV_DEFAULT_AT_RULES = [
    '@media (min-width:1025px)',
    '@media (min-width:768px)',
    '@media (max-width:1024px) and (min-width:768px)',
    '@media (max-width:1024px)',
    '@media (max-width:767px)',
];

/**
 * The at-rules the Design dashboard offers on this site (its breakpoint
 * presets, filterable by the site).
 *
 * @return list<string>
 */
function gbv_preset_at_rules(): array
{
    if (!function_exists('generateblocks_pro_get_default_at_rules')) {
        return GBV_DEFAULT_AT_RULES;
    }
    $values = [];
    foreach (generateblocks_pro_get_default_at_rules() as $preset) {
        $values[] = $preset['value'];
    }
    return $values;
}

/**
 * The name the Design dashboard derives from a label: lower case, NFC, any
 * run of other characters as one dash, `_` prepended when it would not start
 * with a letter. Empty when the label has no letter or digit, when PHP's intl
 * extension (for NFC) is missing, or when PHP cannot derive the browser's
 * name: a character its Unicode tables do not know (the browser may count it
 * as a letter), or a capital sigma before PHP 8.3 (no final-sigma rule).
 */
function gbv_name_from_label(string $label): string
{
    if (!class_exists(Normalizer::class) || gbv_label_beyond_php($label)) {
        return '';
    }
    $slug = (string) Normalizer::normalize(mb_strtolower(gbv_css_js_trim($label)), Normalizer::FORM_C);
    $slug = (string) preg_replace('/[^\p{L}\p{N}\p{M}_-]+/u', replacement: '-', subject: $slug);
    $slug = (string) preg_replace('/^-+|-+$/', replacement: '', subject: $slug);
    if ($slug === '' || preg_match('/[\p{L}\p{N}]/u', $slug) !== 1) {
        return '';
    }
    return '--' . (preg_match('/^[\p{L}_]/u', $slug) === 1 ? $slug : '_' . $slug);
}

/**
 * Whether PHP may lower-case or classify `$label` differently from the
 * browser.
 */
function gbv_label_beyond_php(string $label): bool
{
    if (preg_match('/\p{Cn}/u', $label) === 1) {
        return true;
    }
    return PHP_VERSION_ID < 80_300 && str_contains($label, 'Σ');
}

/**
 * Check one value an agent asks to write, for a token of `$type`. Null when
 * it can be written.
 */
function gbv_check_value(string $value, string $type, string $where): ?WP_Error
{
    $trimmed = gbv_css_js_trim($value);
    if (!GenerateBlocks_Pro_Design_Tokens::is_valid_value_for_type($trimmed, $type)) {
        return new WP_Error('generateblocks_invalid_input', sprintf(
            /* translators: 1: where the value goes, 2: the value, 3: token type. */
            __(
                '%1$s: "%2$s" is not a valid %3$s value for GenerateBlocks. Colours take hex, rgb()/hsl()/oklch()/color-mix()/var() or a named colour; units take a number with a unit, calc()/min()/max()/clamp()/var() or auto; text takes anything without ; { } < >, a comment, a line break, an unclosed quote or bracket, or a trailing backslash.',
                domain: 'novamira-pro',
            ),
            $where,
            mb_substr($trimmed, start: 0, length: 80),
            $type,
        ));
    }
    try {
        gbv_css_value($trimmed);
    } catch (UnexpectedValueException $e) {
        return new WP_Error('generateblocks_invalid_input', sprintf(
            /* translators: 1: where the value goes, 2: the reason. */
            __(
                '%1$s: this value cannot be written from here (%2$s). Set it on the GenerateBlocks Design Tokens screen instead.',
                domain: 'novamira-pro',
            ),
            $where,
            $e->getMessage(),
        ));
    }
    return null;
}

/**
 * Check a `scope` list against the properties the Design Tokens screen
 * offers for a token of `$type`.
 *
 * @param list<mixed> $scope
 */
function gbv_check_scope(array $scope, string $type): ?WP_Error
{
    $allowed = GBV_SCOPE_BY_TYPE[$type] ?? [];
    // @mago-expect analysis:mixed-assignment -- input items are checked one by one.
    foreach ($scope as $entry) {
        if (!is_string($entry) || !in_array($entry, $allowed, strict: true)) {
            return new WP_Error('generateblocks_invalid_input', sprintf(
                /* translators: 1: the entry received, 2: token type, 3: the accepted list. */
                __(
                    'scope: "%1$s" is not a property a %2$s token can apply to. It takes these: %3$s.',
                    domain: 'novamira-pro',
                ),
                is_string($entry) ? mb_substr($entry, start: 0, length: 80) : gettype($entry),
                $type,
                implode(', ', $allowed),
            ));
        }
    }
    return null;
}

/**
 * Check a `conditional_values` map: every key a breakpoint the dashboard
 * offers, every value valid for the type. Null values are allowed when
 * `$allow_null` (they remove the value).
 *
 * @param array<array-key, mixed> $conditional
 */
// @mago-expect lint:no-boolean-flag-parameter -- create forbids removals, edit allows them.
function gbv_check_conditional(array $conditional, string $type, bool $allow_null): ?WP_Error
{
    $presets = gbv_preset_at_rules();
    // @mago-expect analysis:mixed-assignment -- input values are checked one by one.
    foreach ($conditional as $at_rule => $value) {
        if (!in_array((string) $at_rule, $presets, strict: true)) {
            return new WP_Error('generateblocks_invalid_input', sprintf(
                /* translators: 1: the at-rule received, 2: the accepted list. */
                __(
                    '"%1$s" is not a breakpoint of this site. conditional_values takes these keys: %2$s.',
                    domain: 'novamira-pro',
                ),
                mb_substr((string) $at_rule, start: 0, length: 80),
                implode(', ', $presets),
            ));
        }
        if ($value === null && $allow_null) {
            continue;
        }
        if (!is_string($value)) {
            return new WP_Error('generateblocks_invalid_input', sprintf(
                /* translators: %s: at-rule. */
                __('conditional_values["%s"] must be a string.', domain: 'novamira-pro'),
                (string) $at_rule,
            ));
        }
        $error = gbv_check_value($value, $type, where: 'conditional_values["' . $at_rule . '"]');
        if ($error !== null) {
            return $error;
        }
    }
    return null;
}

/**
 * Set, or remove (null), a token's value under an at-rule. A new key goes
 * last, an existing one keeps its place, and a branch left empty is dropped,
 * as in the Design dashboard. (The base value is a plain `$styles[$name]`
 * assignment, which keeps the same order; only a delete removes it.)
 *
 * @param array<array-key, mixed> $styles
 * @return array<array-key, mixed>
 */
function gbv_set_value(array $styles, string $at_rule, string $name, ?string $value): array
{
    $branch = is_array($styles[$at_rule] ?? null) ? $styles[$at_rule] : [];
    if ($value !== null) {
        $branch[$name] = $value;
        $styles[$at_rule] = $branch;
        return $styles;
    }
    unset($branch[$name]);
    if ($branch === []) {
        unset($styles[$at_rule]);
        return $styles;
    }
    $styles[$at_rule] = $branch;
    return $styles;
}

/**
 * Remove a custom property at every depth and drop the branches that end up
 * empty (the Design dashboard's own removal, `Me()`).
 *
 * @param array<array-key, mixed> $styles
 * @return array<array-key, mixed>
 */
function gbv_remove_name(array $styles, string $name): array
{
    $out = [];
    // @mago-expect analysis:mixed-assignment -- the styles object is vendor data; branches are type-checked.
    foreach ($styles as $key => $value) {
        if ((string) $key === $name) {
            continue;
        }
        if (is_array($value) && gbv_css_is_map($value)) {
            $value = gbv_remove_name($value, $name);
            if ($value === []) {
                continue;
            }
        }
        $out[$key] = $value;
    }
    return $out;
}

/**
 * Run `$callback` holding the site-wide Design Tokens write lock.
 *
 * @template T
 * @param callable(): T $callback
 * @return T|WP_Error
 */
function gbv_with_lock(callable $callback): mixed
{
    global $wpdb;
    /** @var \wpdb $wpdb */
    $lock = 'novamira-gbv:' . sha1('blog=' . get_current_blog_id() . '|key=root');
    // @mago-expect analysis:possibly-invalid-argument
    $got = $wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s, %d)', $lock, 5));
    if ((string) $got !== '1') {
        return new WP_Error('generateblocks_variables_locked', __(
            'Another Design Tokens write is in progress. Try again in a few seconds.',
            domain: 'novamira-pro',
        ));
    }
    try {
        // @mago-expect lint:inline-variable-return
        $result = $callback();
        return $result;
    } finally {
        // @mago-expect analysis:possibly-invalid-argument
        $wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)', $lock));
    }
}

/**
 * The error for a record that cannot be written, or null.
 *
 * @param array{state: string, post_id: int, styles: array<array-key, mixed>, css: string, tokens: list<array<string, mixed>>, recovered_from_backup: bool, checksum: string} $root
 */
function gbv_unwritable_error(array $root): ?WP_Error
{
    // An absent record never gets here: gbv_write() creates it first or refuses.
    $unavailable = gbv_unavailable_error($root['state']);
    if ($unavailable !== null) {
        return $unavailable;
    }
    if ($root['state'] === 'inactive') {
        return new WP_Error('generateblocks_variables_inactive', __(
            'The Design Tokens record exists but is not published, so none of its CSS is output. Saving it would publish it again: ask the user to review it on the GenerateBlocks Design Tokens screen first.',
            domain: 'novamira-pro',
        ));
    }
    if ($root['recovered_from_backup']) {
        return new WP_Error('generateblocks_variables_recovered', __(
            'The Design Tokens registry could not be read and GenerateBlocks is showing its newest backup. Ask the user to open the GenerateBlocks Design Tokens screen and save it, then try again.',
            domain: 'novamira-pro',
        ));
    }
    if (gbv_registry_unreadable($root['post_id'])) {
        return new WP_Error('generateblocks_variables_unreadable', __(
            'The Design Tokens registry cannot be read and GenerateBlocks has no readable backup of it, so it shows no token. Writing would replace it. Ask the user to check it on the GenerateBlocks Design Tokens screen.',
            domain: 'novamira-pro',
        ));
    }
    $names = array_map(static fn(array $t): string => (string) ($t['name'] ?? ''), $root['tokens']);
    if (count($names) !== count(array_unique($names))) {
        return new WP_Error('generateblocks_variables_duplicates', __(
            'The Design Tokens registry holds two tokens with the same name, which GenerateBlocks refuses to save. Ask the user to remove the duplicate on the GenerateBlocks Design Tokens screen.',
            domain: 'novamira-pro',
        ));
    }
    // Redundant on purpose: the new CSS is compiled again after the change and
    // would refuse too, but this names the cause before the change is tried.
    try {
        $compiled = gbv_css_root($root['styles']);
    } catch (UnexpectedValueException $e) {
        return gbv_drift_error($e->getMessage());
    }
    if ($compiled !== $root['css']) {
        return gbv_drift_error(__(
            'the stored CSS is not what the Design Tokens screen would compile from the stored values',
            domain: 'novamira-pro',
        ));
    }
    return null;
}

/**
 * Whether the record holds a registry GenerateBlocks cannot read and has no
 * readable backup for: it then reports no token at all, not a recovery.
 */
function gbv_registry_unreadable(int $post_id): bool
{
    if ($post_id <= 0 || !metadata_exists('post', $post_id, meta_key: 'gb_style_tokens')) {
        return false;
    }
    /** @var mixed $post */
    $post = get_post($post_id);
    return $post instanceof \WP_Post && GenerateBlocks_Pro_Design_Tokens::read_state($post)['source'] === 'none';
}

function gbv_drift_error(string $reason): WP_Error
{
    return new WP_Error('generateblocks_css_drift', sprintf(
        /* translators: %s: why the record is refused. */
        __(
            'Design Tokens cannot be written from here on this site: %s. Writing would replace CSS that only that screen can reproduce. Make the change on the GenerateBlocks Design Tokens screen.',
            domain: 'novamira-pro',
        ),
        $reason,
    ));
}

/**
 * Read, guard, change and save the `:root` record under the lock.
 *
 * `$mutate` receives the current styles and registry and returns the new
 * pair, or a WP_Error to abort without writing. With `$create` an absent
 * record is created first; callers validate their input before calling, so
 * a create is not refused after the record exists.
 *
 * @param callable(array<array-key, mixed>, list<array<string, mixed>>): (array{0: array<array-key, mixed>, 1: list<array<string, mixed>>}|WP_Error) $mutate
 * @return array{state: string, post_id: int, styles: array<array-key, mixed>, css: string, tokens: list<array<string, mixed>>, recovered_from_backup: bool, checksum: string}|WP_Error
 */
// @mago-expect lint:no-boolean-flag-parameter -- only create may make the record.
function gbv_write(callable $mutate, bool $create): array|WP_Error
{
    if (!GenerateBlocks_Pro_Design_Tokens::can_manage_tokens()) {
        return new WP_Error('generateblocks_forbidden', __(
            'The user the agent acts as may not manage GenerateBlocks Design Tokens on this site (by default this takes the manage_options capability). Ask an administrator to make the change, or to connect as a user who can.',
            domain: 'novamira-pro',
        ));
    }
    return gbv_with_lock(static function () use ($mutate, $create): array|WP_Error {
        $root = gbv_read_root_fresh();
        if ($root['state'] === 'absent') {
            $root = gbv_create_root($create);
            if ($root instanceof WP_Error) {
                return $root;
            }
        }
        $refused = gbv_unwritable_error($root);
        if ($refused !== null) {
            return $refused;
        }
        $change = $mutate($root['styles'], $root['tokens']);
        if ($change instanceof WP_Error) {
            return $change;
        }
        $tokens = gbv_order_tokens($change[1]);
        $cycle = gbv_cycle_name($tokens, $change[0]);
        if ($cycle !== '') {
            return new WP_Error('generateblocks_variable_circular', sprintf(
                /* translators: %s: CSS custom property name. */
                __(
                    'This change would make "%s" refer to itself through var() (directly or through other tokens), which leaves every token in the loop without a value. The Design Tokens screen refuses it too. Nothing was written: point one of those tokens at a plain value instead.',
                    domain: 'novamira-pro',
                ),
                $cycle,
            ));
        }
        try {
            $css = gbv_css_root($change[0]);
        } catch (UnexpectedValueException $e) {
            // Defence: every new value was checked with gbv_css_value() and the
            // branches are the site's presets, so this does not throw today.
            return gbv_drift_error($e->getMessage());
        }
        $saved = GenerateBlocks_Pro_Styles_Root::save($change[0], $css, $root['checksum'], $tokens);
        if ($saved instanceof WP_Error) {
            return gbv_save_error($saved);
        }
        return gbv_read_root_fresh();
    });
}

/**
 * gbv_read_root() bypassing the object cache of the record: a value cached
 * before the lock (or before a slow usage scan) would hide a save made in
 * between from both the drift guard and GenerateBlocks' checksum.
 *
 * @return array{state: string, post_id: int, styles: array<array-key, mixed>, css: string, tokens: list<array<string, mixed>>, recovered_from_backup: bool, checksum: string}
 */
function gbv_read_root_fresh(): array
{
    $root = gbv_read_root();
    if ($root['post_id'] === 0) {
        return $root;
    }
    clean_post_cache($root['post_id']);
    return gbv_read_root();
}

/**
 * The registry in the order the Design Tokens screen keeps it (`ne()`):
 * categories in order of first appearance, each with its tokens in their
 * order, then the uncategorised ones. A screen save would otherwise reorder it.
 *
 * @param list<array<string, mixed>> $tokens
 * @return list<array<string, mixed>>
 */
function gbv_order_tokens(array $tokens): array
{
    $groups = [];
    $rest = [];
    foreach ($tokens as $token) {
        $category = isset($token['category']) && is_string($token['category']) ? $token['category'] : '';
        if ($category !== '') {
            $groups[$category][] = $token;
            continue;
        }
        $rest[] = $token;
    }
    $out = [];
    foreach ($groups as $group) {
        array_push($out, ...$group);
    }
    array_push($out, ...$rest);
    return $out;
}

/**
 * Create the `:root` record for a first token, through GenerateBlocks' own
 * creation path. Every input was validated before the lock, so the change
 * cannot be refused on an empty record; the caller reads the record again
 * and applies the change to whatever it holds (another request may have
 * created it in between).
 *
 * @return array{state: string, post_id: int, styles: array<array-key, mixed>, css: string, tokens: list<array<string, mixed>>, recovered_from_backup: bool, checksum: string}|WP_Error
 */
// @mago-expect lint:no-boolean-flag-parameter -- only create may make the record.
function gbv_create_root(bool $create): array|WP_Error
{
    if (!$create) {
        return gbv_absent_error();
    }
    $created = GenerateBlocks_Pro_Styles_Root::create_for_dashboard();
    if ($created instanceof WP_Error) {
        return gbv_save_error($created);
    }
    $root = gbv_read_root();
    // Defence: create_for_dashboard() returns the record or an error, so the
    // record is not absent here unless GenerateBlocks changes that contract.
    if ($root['state'] === 'absent') {
        return new WP_Error('generateblocks_variables_create_failed', __(
            'GenerateBlocks could not create its Design Tokens record. Ask the user to save a first token on the GenerateBlocks Design Tokens screen.',
            domain: 'novamira-pro',
        ));
    }
    return $root;
}

function gbv_save_error(WP_Error $error): WP_Error
{
    // Any other code passes through. Every value, name and registry check the
    // vendor makes on save is made first by the abilities, so no input known
    // today reaches one of them.
    if ($error->get_error_code() === 'gb_root_style_conflict') {
        return new WP_Error('generateblocks_variables_changed', __(
            'The Design Tokens were saved from somewhere else (probably the Design Tokens screen) while this change was being made. Nothing was written: read them again and retry.',
            domain: 'novamira-pro',
        ));
    }
    return new WP_Error($error->get_error_code(), sprintf(
        /* translators: %s: GenerateBlocks' own error message. */
        __('GenerateBlocks refused the change: %s', domain: 'novamira-pro'),
        $error->get_error_message(),
    ));
}

/**
 * The registry row of `$name`, or null.
 *
 * @param list<array<string, mixed>> $tokens
 * @return array<string, mixed>|null
 */
function gbv_find_token(array $tokens, string $name): ?array
{
    foreach ($tokens as $token) {
        if (($token['name'] ?? '') === $name) {
            return $token;
        }
    }
    return null;
}

/**
 * Every value a token takes in `$styles`: the base one first.
 *
 * @param array<array-key, mixed> $styles
 * @return list<string>
 */
function gbv_token_values(array $styles, string $name): array
{
    $values = isset($styles[$name]) && is_string($styles[$name]) ? [$styles[$name]] : [];
    foreach (gbv_conditional_values($styles, $name) as $conditional) {
        $values[] = $conditional['value'];
    }
    return $values;
}

/**
 * The first registered token caught in a var() loop, '' when there is none:
 * the Design Tokens screen's own check (`Ke()`), which refuses to save. The
 * loop is looked for in every condition context the styles declare, with the
 * value each token resolves to in that context.
 *
 * @param list<array<string, mixed>> $tokens
 * @param array<array-key, mixed>    $styles
 */
function gbv_cycle_name(array $tokens, array $styles): string
{
    $registered = [];
    foreach ($tokens as $token) {
        $name = isset($token['name']) && is_string($token['name']) ? $token['name'] : '';
        if (($token['registered'] ?? true) !== false && gbv_is_valid_name($name)) {
            $registered[] = $name;
        }
    }
    $declarations = [];
    $contexts = ['[]' => []];
    gbv_cycle_declarations($styles, [], $declarations, $contexts);
    foreach ($contexts as $context => $path) {
        $cyclic = gbv_cycle_members(gbv_cycle_values($declarations, $context, $path));
        foreach ($registered as $name) {
            if (isset($cyclic[$name])) {
                return $name;
            }
        }
    }
    return '';
}

/**
 * Every custom property declaration, grouped by name in order of first
 * appearance, with its condition path (`We()` / `Ne()`), and the contexts
 * those paths make.
 *
 * @param array<array-key, mixed>                                                    $branch
 * @param list<string>                                                               $path
 * @param array<string, list<array{value: string, path: list<string>, context: string}>> $declarations
 * @param array<string, list<string>>                                                $contexts
 */
function gbv_cycle_declarations(array $branch, array $path, array &$declarations, array &$contexts): void
{
    // @mago-expect analysis:mixed-assignment -- the styles object is vendor data; every branch is type-checked here.
    foreach ($branch as $key => $value) {
        $key = (string) $key;
        if (gbv_is_valid_name($key)) {
            $normalised = gbv_cycle_path($path);
            $context = (string) wp_json_encode($normalised);
            $contexts[$context] = $normalised;
            $declarations[$key][] = [
                'value' => is_string($value) || is_int($value) ? (string) $value : '',
                'path' => $normalised,
                'context' => $context,
            ];
            continue;
        }
        if (is_array($value)) {
            gbv_cycle_declarations($value, [...$path, $key], $declarations, $contexts);
        }
    }
}

/**
 * A two-level path with one at-rule and one selector, at-rule first (`Ue()`).
 *
 * @param list<string> $path
 * @return list<string>
 */
function gbv_cycle_path(array $path): array
{
    if (count($path) !== 2 || str_starts_with($path[0], '@') === str_starts_with($path[1], '@')) {
        return $path;
    }
    return str_starts_with($path[0], '@') ? $path : [$path[1], $path[0]];
}

/**
 * The value each name takes in one context (`He()`): the declaration of that
 * exact context, else the most specific one whose conditions all hold there.
 *
 * @param array<string, list<array{value: string, path: list<string>, context: string}>> $declarations
 * @param list<string>                                                                 $path
 * @return array<string, string>
 */
function gbv_cycle_values(array $declarations, string $context, array $path): array
{
    $values = [];
    foreach ($declarations as $name => $list) {
        $best = null;
        $best_score = -1;
        foreach ($list as $declaration) {
            $applies =
                $declaration['context'] === '[]'
                || $declaration['context'] === $context
                || array_diff($declaration['path'], $path) === [];
            if (!$applies) {
                continue;
            }
            $score = $declaration['context'] === $context
                ? PHP_INT_MAX
                : (100 * count($declaration['path']))
                + count(array_filter($declaration['path'], static fn(string $p): bool => !str_starts_with($p, '@')));
            if ($score >= $best_score) {
                $best = $declaration;
                $best_score = $score;
            }
        }
        if ($best !== null) {
            $values[$name] = $best['value'];
        }
    }
    return $values;
}

/**
 * The names on a var() loop of `$values` (`Ve()`), as a set.
 *
 * @param array<string, string> $values
 * @return array<string, true>
 */
function gbv_cycle_members(array $values): array
{
    $state = [];
    $stack = [];
    $members = [];
    $visit = static function (string $name) use (&$visit, &$state, &$stack, &$members, $values): void {
        $state[$name] = 'visiting';
        $stack[] = $name;
        $refs = [];
        preg_match_all(
            '/var\(' . GBV_CSS_JS_SPACE . '*(--[\p{L}_][\p{L}\p{N}\p{M}_-]*)' . GBV_CSS_JS_SPACE . '*[,)]/u',
            $values[$name],
            $refs,
        );
        foreach ($refs[1] as $ref) {
            if (!array_key_exists($ref, $values)) {
                continue;
            }
            if (($state[$ref] ?? '') === 'visiting') {
                $from = (int) array_search($ref, array_reverse($stack, true), strict: true);
                foreach (array_slice($stack, $from) as $member) {
                    $members[$member] = true;
                }
                continue;
            }
            if (!isset($state[$ref])) {
                $visit($ref);
            }
        }
        array_pop($stack);
        $state[$name] = 'visited';
    };
    foreach (array_keys($values) as $name) {
        if (isset($state[$name])) {
            continue;
        }
        $visit($name);
    }
    return $members;
}
