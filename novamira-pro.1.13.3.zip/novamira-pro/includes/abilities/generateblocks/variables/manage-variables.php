<?php

// SPDX-FileCopyrightText: 2026 Ovation S.r.l. <dev@novamira.ai>
// SPDX-License-Identifier: AGPL-3.0-or-later

declare(strict_types=1);

namespace Novamira\Pro\Abilities\GenerateBlocks;

use GenerateBlocks_Pro_Design_Tokens;
use GenerateBlocks_Pro_Design_Tokens_Usage;
use WP_Error;

if (!defined('ABSPATH')) {
    exit();
}

/**
 * Abilities: GenerateBlocks Pro Design Tokens (CSS custom properties on
 * `:root`). Loaded only when gb_variables_available().
 */

const GBV_STATE_DESCRIPTION = 'Resolution of the GenerateBlocks `:root` record that holds the Design Tokens: `ready` (published, its CSS is output on the front end), `inactive` (the record exists but is not published, so no token CSS is output), `conflict` (more than one `:root` record: the abilities serve no token until the user keeps one on the GenerateBlocks Design Tokens screen, while the front end keeps outputting the oldest published record), `absent` (no Design Token was ever saved).';

const GBV_CONDITIONAL_DESCRIPTION = 'Values the token takes under a condition, a breakpoint or a selector: `context` is the path of at-rules / selectors from `:root` (e.g. ["@media (max-width:1024px)"] or ["&.dark"]). Absent when the token has only its base value.';

const GBV_ISSUES_DESCRIPTION = 'Present only when the token is not offered in the editor controls: `no_value` (no value at all, so no CSS is output for it), `no_default_value` (no base value: only its `conditional_values` are output), `value_invalid_for_type` (the base value does not fit the token type) or `value_not_string` (the stored base value is not text, which the Design Tokens screen never writes).';

const GBV_ROW_PROPERTIES = [
    'name' => [
        'type' => 'string',
        'description' => 'CSS custom property name, e.g. "--primary". Use it in styles as var(--primary).',
    ],
    'label' => ['type' => 'string', 'description' => 'Human label shown on the Design Tokens screen.'],
    'type' => ['type' => 'string', 'enum' => ['color', 'unit', 'text']],
    'category' => ['type' => 'string', 'description' => 'Category name; empty when uncategorised.'],
    'value' => [
        'type' => ['string', 'null'],
        'description' => 'Base value (outside any condition). Null when there is none: see `issues`.',
    ],
    'conditional_values' => [
        'type' => 'array',
        'description' => GBV_CONDITIONAL_DESCRIPTION,
        'items' => [
            'type' => 'object',
            'properties' => [
                'context' => ['type' => 'array', 'items' => ['type' => 'string']],
                'value' => ['type' => 'string'],
            ],
            'required' => ['context', 'value'],
        ],
    ],
    'issues' => [
        'type' => 'array',
        'description' => GBV_ISSUES_DESCRIPTION,
        'items' => [
            'type' => 'string',
            'enum' => ['no_value', 'no_default_value', 'value_invalid_for_type', 'value_not_string'],
        ],
    ],
];

/**
 * Output schema of one token as get, create and edit return it.
 *
 * @return array<string, mixed>
 */
function gbv_detail_schema(): array
{
    return [
        'type' => 'object',
        'properties' => array_merge(GBV_ROW_PROPERTIES, [
            'id' => ['type' => 'string'],
            'scope' => [
                'type' => 'array',
                'items' => ['type' => 'string'],
                'description' => 'Style properties (camelCase, e.g. backgroundColor, fontSize) whose controls offer this token. Empty = offered nowhere by default.',
            ],
            'display' => [
                'type' => 'object',
                'description' => 'Quick-edit control shown in the token list (colorPicker, unitControl, buttonGroup or select with options).',
            ],
        ]),
        'required' => ['name', 'label', 'type', 'category', 'value', 'id', 'scope'],
    ];
}

wp_register_ability('novamira/generateblocks-list-variables', [
    'label' => __('List GenerateBlocks Design Tokens', domain: 'novamira-pro'),
    'description' => __(
        'Lists the GenerateBlocks Pro Design Tokens (site-wide CSS custom properties such as --primary or --space-m) with their type, category, base value and the values they take under breakpoints or selectors. Call it before styling GenerateBlocks blocks so colours, spacing and fonts reference the design system with var(--name) instead of hard-coded values. Token names usually come from their labels but can differ, so never guess them: use the names returned here. Also names the custom properties declared on :root that are not registered tokens.',
        domain: 'novamira-pro',
    ),
    'category' => 'generateblocks',
    'input_schema' => [
        'type' => 'object',
        'default' => [],
        'properties' => [
            'type' => [
                'type' => 'string',
                'enum' => ['color', 'unit', 'text'],
                'description' => 'Only tokens of this type.',
            ],
            'category' => [
                'type' => 'string',
                'description' => 'Only tokens in this category (exact name; empty string = uncategorised).',
            ],
        ],
        'additionalProperties' => false,
    ],
    'output_schema' => [
        'type' => 'object',
        'properties' => [
            'state' => [
                'type' => 'string',
                'enum' => ['ready', 'inactive', 'conflict', 'absent'],
                'description' => GBV_STATE_DESCRIPTION,
            ],
            'recovered_from_backup' => [
                'type' => 'boolean',
                'description' => 'True when the registry was unreadable and GenerateBlocks served the newest readable backup instead.',
            ],
            'total' => ['type' => 'integer', 'description' => 'Number of tokens returned.'],
            'unregistered_variables' => [
                'type' => 'array',
                'items' => ['type' => 'string'],
                'description' => 'Custom properties declared on the `:root` record that are not registered tokens (not filtered by type or category). They are output as CSS and usable with var(), but have no type, label or editor control.',
            ],
            'variables' => [
                'type' => 'array',
                'items' => [
                    'type' => 'object',
                    'properties' => GBV_ROW_PROPERTIES,
                    'required' => ['name', 'label', 'type', 'category', 'value'],
                ],
            ],
        ],
        'required' => ['state', 'recovered_from_backup', 'total', 'variables', 'unregistered_variables'],
    ],
    'execute_callback' => 'Novamira\\Pro\\Abilities\\GenerateBlocks\\generateblocks_list_variables',
    'permission_callback' => 'novamira_permission_callback',
    'meta' => [
        'show_in_rest' => true,
        'mcp' => ['public' => true],
        'annotations' => [
            'instructions' => 'Reference a token in a GenerateBlocks block `styles` value as "var(--name)". A token with `issues` is not offered in the editor, so do not rely on it. Style with tokens only when `state` is `ready`; otherwise tell the user what the state means first. Use generateblocks-get-variable for the scope, the quick-edit control and where a token is used.',
            'readonly' => true,
            'destructive' => false,
            'idempotent' => true,
        ],
    ],
]);

wp_register_ability('novamira/generateblocks-get-variable', [
    'label' => __('Get GenerateBlocks Design Token', domain: 'novamira-pro'),
    'description' => __(
        'Reads one GenerateBlocks Pro Design Token by its CSS custom property name ("--primary"; the leading -- and a var() wrapper may be omitted): type, label, category, base and conditional values, scope (the style properties whose controls offer it) and quick-edit control. With include_usage it also reports where the token is used across Global Styles, post content, other tokens and token presets.',
        domain: 'novamira-pro',
    ),
    'category' => 'generateblocks',
    'input_schema' => [
        'type' => 'object',
        'properties' => [
            'name' => [
                'type' => 'string',
                'maxLength' => 200,
                'description' => 'CSS custom property name from generateblocks-list-variables, e.g. "--primary".',
            ],
            'include_usage' => [
                'type' => 'boolean',
                'default' => false,
                'description' => 'Also scan where the token is used. A fresh scan of up to the 5000 most recently modified posts, slower on large sites; it also refreshes GenerateBlocks\' own 15-minute usage cache. Ask for it before renaming or deleting a token, not for styling.',
            ],
        ],
        'required' => ['name'],
        'additionalProperties' => false,
    ],
    'output_schema' => [
        'type' => 'object',
        'properties' => [
            'state' => [
                'type' => 'string',
                'enum' => ['ready', 'inactive', 'conflict', 'absent'],
                'description' => GBV_STATE_DESCRIPTION,
            ],
            'variable' => gbv_detail_schema(),
            'usage' => [
                'type' => 'object',
                'description' => 'Only with include_usage. Where var(--name) appears. `global_styles` and `posts` are capped by GenerateBlocks; `limited` = true means the post or Global Styles scan covered only part of the site.',
                'properties' => [
                    'global_styles' => ['type' => 'array', 'items' => ['type' => 'object']],
                    'posts' => ['type' => 'array', 'items' => ['type' => 'object']],
                    'presets' => ['type' => 'array', 'items' => ['type' => 'object']],
                    'variables' => ['type' => 'array', 'items' => ['type' => 'object']],
                    'limited' => ['type' => 'boolean'],
                ],
                'required' => ['global_styles', 'posts', 'presets', 'variables', 'limited'],
            ],
        ],
        'required' => ['state', 'variable'],
    ],
    'execute_callback' => 'Novamira\\Pro\\Abilities\\GenerateBlocks\\generateblocks_get_variable',
    'permission_callback' => 'novamira_permission_callback',
    'meta' => [
        'show_in_rest' => true,
        'mcp' => ['public' => true],
        'annotations' => [
            'instructions' => 'When no token has that name the call fails with "No GenerateBlocks Design Token is named …": list the tokens with generateblocks-list-variables instead of guessing. It fails with a different message when the site has no token yet or more than one token record.',
            'readonly' => true,
            'destructive' => false,
            'idempotent' => true,
        ],
    ],
]);

/**
 * @param array{type?: string, category?: string} $input
 * @return array<string, mixed>
 */
function generateblocks_list_variables(array $input = []): array
{
    $root = gbv_read_root();
    $type = $input['type'] ?? null;
    $category = $input['category'] ?? null;

    $rows = [];
    foreach (gbv_unique_tokens($root['tokens']) as $token) {
        if ($type !== null && ($token['type'] ?? '') !== $type) {
            continue;
        }
        if ($category !== null && ($token['category'] ?? '') !== $category) {
            continue;
        }
        $rows[] = gbv_variable_row($token, $root['styles']);
    }

    return [
        'state' => $root['state'],
        'recovered_from_backup' => $root['recovered_from_backup'],
        'total' => count($rows),
        'variables' => $rows,
        'unregistered_variables' => gbv_unregistered_names($root['styles'], $root['tokens']),
    ];
}

/**
 * @param array{name: string, include_usage?: bool} $input
 * @return array<string, mixed>|WP_Error
 */
function generateblocks_get_variable(array $input): array|WP_Error
{
    $name = gbv_normalize_name($input['name']);
    if (!gbv_is_valid_name($name)) {
        return new WP_Error('generateblocks_invalid_input', sprintf(
            /* translators: %s: the name as received, shortened. */
            __(
                '"%s" is not a Design Token name. Token names look like "--primary"; use generateblocks-list-variables to see them.',
                domain: 'novamira-pro',
            ),
            mb_substr($name, start: 0, length: 80),
        ));
    }

    $root = gbv_read_root();
    $unavailable = gbv_unavailable_error($root['state']);
    if ($unavailable !== null) {
        return $unavailable;
    }

    foreach (gbv_unique_tokens($root['tokens']) as $token) {
        if (($token['name'] ?? '') !== $name) {
            continue;
        }
        $out = [
            'state' => $root['state'],
            'variable' => gbv_variable_detail($token, $root['styles']),
        ];
        if (($input['include_usage'] ?? false) === true) {
            $out['usage'] = gbv_usage($name, $root);
        }
        return $out;
    }

    return gbv_not_found($name);
}

/**
 * The error for a `:root` state in which no single token can be read, or null.
 */
function gbv_unavailable_error(string $state): ?WP_Error
{
    return match ($state) {
        'absent' => gbv_absent_error(),
        'conflict' => new WP_Error('generateblocks_variables_conflict', __(
            'This site has more than one GenerateBlocks Design Tokens record, so no token can be read until the user keeps one on the GenerateBlocks Design Tokens screen.',
            domain: 'novamira-pro',
        )),
        default => null,
    };
}

function gbv_absent_error(): WP_Error
{
    return new WP_Error('generateblocks_variable_not_found', __(
        'No GenerateBlocks Design Token has been saved on this site yet.',
        domain: 'novamira-pro',
    ));
}

/**
 * Where a token is referenced. Global Styles and post content come from the
 * vendor's scanner, always fresh: GenerateBlocks caches the result for 15
 * minutes and clears it only on a Design save, so a post saved a minute ago
 * would be missing from a cached answer (the fresh result replaces that cache
 * entry). Presets and token-to-token references are counted on the record
 * just read with the vendor's own counters: its scanner takes presets, and the
 * labels of referencing tokens, only from a published record.
 *
 * @param array{state: string, post_id: int, styles: array<array-key, mixed>, css: string, tokens: list<array<string, mixed>>, recovered_from_backup: bool, checksum: string} $root
 * @return array{global_styles: list<mixed>, posts: list<mixed>, presets: list<mixed>, variables: list<mixed>, limited: bool}
 */
function gbv_usage(string $name, array $root): array
{
    $found = GenerateBlocks_Pro_Design_Tokens_Usage::find_usages($name, refresh: true);
    $pattern = GenerateBlocks_Pro_Design_Tokens_Usage::build_usage_pattern($name);

    $list = static fn(mixed $rows): array => is_array($rows) ? array_values($rows) : [];

    return [
        'global_styles' => $list($found['styles'] ?? []),
        'posts' => $list($found['posts'] ?? []),
        'presets' => GenerateBlocks_Pro_Design_Tokens_Usage::count_preset_references($root['tokens'], $pattern),
        'variables' => GenerateBlocks_Pro_Design_Tokens_Usage::count_token_references(
            $root['styles'],
            $name,
            $pattern,
            $root['tokens'],
        ),
        'limited' => ($found['limited'] ?? false) === true,
    ];
}

const GBV_WRITE_NOTE = 'Each call is one save, like a save on the GenerateBlocks Design Tokens screen: the front-end CSS is rebuilt at once. GenerateBlocks keeps only its last three saves as backups, so a series of calls soon leaves the state from before them out of reach. It is refused, with nothing written, when the site\'s Design Tokens hold something only that screen can reproduce.';

const GBV_CONDITIONAL_INPUT_DESCRIPTION = 'Values under the site\'s breakpoints, keyed by the exact at-rule, e.g. {"@media (max-width:1024px)": "1.5rem", "@media (max-width:767px)": "1rem"}. Only the breakpoints generateblocks-check-setup lists in `breakpoints` are accepted. Values under a selector (a dark mode, for instance) are set on the GenerateBlocks Design Tokens screen.';

const GBV_SCOPE_INPUT_DESCRIPTION = 'Style properties (camelCase) whose editor controls offer the token. Only the ones the Design Tokens screen offers for the type are accepted (the error lists them): colours apply to color, backgroundColor and the four border colours; units to font size, line height, letter spacing, padding, margin, gaps, sizes, border widths and radii (e.g. "fontSize", "paddingTop", "columnGap"); text to fontFamily and a few others.';

wp_register_ability('novamira/generateblocks-create-variable', [
    'label' => __('Create GenerateBlocks Design Token', domain: 'novamira-pro'),
    'description' =>
        __(
            'Creates a GenerateBlocks Pro Design Token: a site-wide CSS custom property with a type, a label and a value, usable in block styles as var(--name). The name is derived from the label as the Design Tokens screen does ("Brand Blue" → --brand-blue) unless `name` is given. Optional: a category, the style properties whose controls offer it (`scope`; colours default to the colour properties), and values per breakpoint.',
            domain: 'novamira-pro',
        )
            . ' '
            . GBV_WRITE_NOTE,
    'category' => 'generateblocks',
    'input_schema' => [
        'type' => 'object',
        'properties' => [
            'label' => [
                'type' => 'string',
                'minLength' => 1,
                'maxLength' => 200,
                'description' => 'Human label, e.g. "Brand Blue".',
            ],
            'type' => ['type' => 'string', 'enum' => ['color', 'unit', 'text']],
            'value' => [
                'type' => 'string',
                'minLength' => 1,
                'maxLength' => 1000,
                'description' => 'Base value: a colour ("#1e73be", "oklch(60% 0.15 250)", "var(--primary)"), a length ("2rem", "clamp(1rem, 2vw, 2rem)") or text ("Inter, sans-serif").',
            ],
            'name' => [
                'type' => 'string',
                'maxLength' => 200,
                'description' => 'CSS custom property name, e.g. "--brand-blue". Omit it to derive the name from the label; a label PHP cannot derive the browser\'s name for (some recent Unicode letters, a capital sigma before PHP 8.3) asks for it.',
            ],
            'category' => ['type' => 'string', 'maxLength' => 100, 'description' => 'Category name; omit for none.'],
            'scope' => [
                'type' => 'array',
                'items' => ['type' => 'string'],
                'description' =>
                    GBV_SCOPE_INPUT_DESCRIPTION
                        . ' Default: every colour property for a colour, none for a unit or text token, which then appears in no control until given one (a font size scale wants ["fontSize"], a font stack ["fontFamily"]).',
            ],
            'conditional_values' => [
                'type' => 'object',
                'additionalProperties' => ['type' => 'string'],
                'description' => GBV_CONDITIONAL_INPUT_DESCRIPTION,
            ],
        ],
        'required' => ['label', 'type', 'value'],
        'additionalProperties' => false,
    ],
    'output_schema' => [
        'type' => 'object',
        'properties' => [
            'state' => ['type' => 'string', 'enum' => ['ready', 'inactive', 'conflict', 'absent']],
            'variable' => gbv_detail_schema(),
        ],
        'required' => ['state', 'variable'],
    ],
    'execute_callback' => 'Novamira\\Pro\\Abilities\\GenerateBlocks\\generateblocks_create_variable',
    'permission_callback' => 'novamira_permission_callback',
    'meta' => [
        'show_in_rest' => true,
        'mcp' => ['public' => true],
        'annotations' => [
            'instructions' => 'List the tokens first and reuse one that fits instead of creating a near-duplicate. Use the returned `name` in styles as var(--name).',
            'readonly' => false,
            'destructive' => false,
            'idempotent' => false,
        ],
    ],
]);

wp_register_ability('novamira/generateblocks-edit-variable', [
    'label' => __('Edit GenerateBlocks Design Token', domain: 'novamira-pro'),
    'description' =>
        __(
            'Changes an existing GenerateBlocks Pro Design Token in place: its label, base value, type, category, scope or breakpoint values (null removes one). Only the fields given change, except that a new type also resets the scope (unless `scope` is given) and the quick-edit control, as on the Design Tokens screen. When a user asks to rename a token they usually mean its label. The name (--name) cannot change here: every var(--name) that uses it would lose its value, and the Design Tokens screen\'s rename does not update those references either.',
            domain: 'novamira-pro',
        )
            . ' '
            . GBV_WRITE_NOTE,
    'category' => 'generateblocks',
    'input_schema' => [
        'type' => 'object',
        'properties' => [
            'name' => [
                'type' => 'string',
                'maxLength' => 200,
                'description' => 'The token\'s CSS custom property name, e.g. "--primary".',
            ],
            'label' => ['type' => 'string', 'minLength' => 1, 'maxLength' => 200],
            'value' => ['type' => 'string', 'minLength' => 1, 'maxLength' => 1000, 'description' => 'New base value.'],
            'type' => [
                'type' => 'string',
                'enum' => ['color', 'unit', 'text'],
                'description' => 'New type. Every value of the token must suit it; the scope resets as on the Design Tokens screen unless `scope` is also given.',
            ],
            'category' => [
                'type' => 'string',
                'maxLength' => 100,
                'description' => 'New category; empty string = none.',
            ],
            'scope' => [
                'type' => 'array',
                'items' => ['type' => 'string'],
                'description' => GBV_SCOPE_INPUT_DESCRIPTION . ' Replaces the old scope.',
            ],
            'conditional_values' => [
                'type' => 'object',
                'additionalProperties' => ['type' => ['string', 'null']],
                'description' =>
                    GBV_CONDITIONAL_INPUT_DESCRIPTION
                        . ' A null value removes the token\'s value under that breakpoint; breakpoints not named are left as they are.',
            ],
        ],
        'required' => ['name'],
        'additionalProperties' => false,
    ],
    'output_schema' => [
        'type' => 'object',
        'properties' => [
            'state' => ['type' => 'string', 'enum' => ['ready', 'inactive', 'conflict', 'absent']],
            'variable' => gbv_detail_schema(),
        ],
        'required' => ['state', 'variable'],
    ],
    'execute_callback' => 'Novamira\\Pro\\Abilities\\GenerateBlocks\\generateblocks_edit_variable',
    'permission_callback' => 'novamira_permission_callback',
    'meta' => [
        'show_in_rest' => true,
        'mcp' => ['public' => true],
        'annotations' => [
            'instructions' => 'Changing a value changes every element that uses var(--name) across the site: say so to the user before editing a token in use (generateblocks-get-variable with include_usage).',
            'readonly' => false,
            'destructive' => false,
            'idempotent' => true,
        ],
    ],
]);

wp_register_ability('novamira/generateblocks-delete-variable', [
    'label' => __('Delete GenerateBlocks Design Token', domain: 'novamira-pro'),
    'description' =>
        __(
            'Deletes a GenerateBlocks Pro Design Token and all of its values. Refused when the token is used in Global Styles, post content, other tokens or token presets, and when the usage scan could not cover the whole site, unless force is true: a deleted token leaves every var(--name) that uses it without a value.',
            domain: 'novamira-pro',
        )
            . ' '
            . GBV_WRITE_NOTE,
    'category' => 'generateblocks',
    'input_schema' => [
        'type' => 'object',
        'properties' => [
            'name' => [
                'type' => 'string',
                'maxLength' => 200,
                'description' => 'The token\'s CSS custom property name, e.g. "--primary".',
            ],
            'force' => [
                'type' => 'boolean',
                'default' => false,
                'description' => 'Delete even when the token is used. Only after the user has confirmed.',
            ],
        ],
        'required' => ['name'],
        'additionalProperties' => false,
    ],
    'output_schema' => [
        'type' => 'object',
        'properties' => [
            'state' => ['type' => 'string', 'enum' => ['ready', 'inactive', 'conflict', 'absent']],
            'deleted' => ['type' => 'string', 'description' => 'The name of the deleted token.'],
        ],
        'required' => ['state', 'deleted'],
    ],
    'execute_callback' => 'Novamira\\Pro\\Abilities\\GenerateBlocks\\generateblocks_delete_variable',
    'permission_callback' => 'novamira_permission_callback',
    'meta' => [
        'show_in_rest' => true,
        'mcp' => ['public' => true],
        'annotations' => [
            'instructions' => 'When the call is refused because the token is in use, tell the user where it is used and ask before retrying with force.',
            'readonly' => false,
            'destructive' => true,
            'idempotent' => true,
        ],
    ],
]);

/**
 * A name from the input, normalised and validated.
 */
function gbv_input_name(string $raw): string|WP_Error
{
    $name = gbv_normalize_name($raw);
    if (gbv_is_valid_name($name)) {
        return $name;
    }
    return new WP_Error('generateblocks_invalid_input', sprintf(
        /* translators: %s: the name as received, shortened. */
        __(
            '"%s" is not a Design Token name. Names look like "--brand-blue": a letter or _ after the dashes, then letters, digits, - or _.',
            domain: 'novamira-pro',
        ),
        mb_substr($name, start: 0, length: 80),
    ));
}

function gbv_not_found(string $name): WP_Error
{
    return new WP_Error('generateblocks_variable_not_found', sprintf(
        /* translators: %s: CSS custom property name. */
        __(
            'No GenerateBlocks Design Token is named "%s". Use generateblocks-list-variables to see the existing names.',
            domain: 'novamira-pro',
        ),
        $name,
    ));
}

/**
 * The response of a create or edit: the token as get returns it.
 *
 * @param array{state: string, post_id: int, styles: array<array-key, mixed>, css: string, tokens: list<array<string, mixed>>, recovered_from_backup: bool, checksum: string}|WP_Error $root
 * @return array<string, mixed>|WP_Error
 */
function gbv_written_response(array|WP_Error $root, string $name): array|WP_Error
{
    if ($root instanceof WP_Error) {
        return $root;
    }
    $token = gbv_find_token($root['tokens'], $name);
    if ($token === null) {
        return gbv_not_found($name);
    }
    return ['state' => $root['state'], 'variable' => gbv_variable_detail($token, $root['styles'])];
}

/**
 * The name a create uses: the one given, or the one derived from the label.
 *
 * @param array{name?: string, ...} $input
 */
function gbv_create_name(array $input, string $label): string|WP_Error
{
    if (isset($input['name'])) {
        return gbv_input_name($input['name']);
    }
    $name = gbv_name_from_label($label);
    if ($name !== '') {
        return $name;
    }
    $reason = match (true) {
        !class_exists(\Normalizer::class) => __(
            'PHP\'s intl extension, which the derivation needs, is missing on this site',
            domain: 'novamira-pro',
        ),
        gbv_label_beyond_php($label) => __(
            'PHP on this site would derive a different name from the one the Design Tokens screen shows for this label',
            domain: 'novamira-pro',
        ),
        default => __('the label has no letter or digit', domain: 'novamira-pro'),
    };
    return new WP_Error('generateblocks_invalid_input', sprintf(
        /* translators: %s: why no name is derived. */
        __('No token name is derived from this label (%s). Pass `name`, e.g. "--brand-blue".', domain: 'novamira-pro'),
        $reason,
    ));
}

/**
 * The registry row a create adds, once its value, scope and breakpoint
 * values check out.
 *
 * @param array{label: string, type: string, value: string, name?: string, category?: string, scope?: list<mixed>, conditional_values?: array<array-key, mixed>} $input
 * @return array<string, mixed>|WP_Error
 */
function gbv_new_row(array $input, string $name, string $label): array|WP_Error
{
    $type = $input['type'];
    $scope = $input['scope'] ?? ($type === 'color' ? GBV_SCOPE_BY_TYPE['color'] : []);
    $error =
        gbv_check_value($input['value'], $type, where: 'value') ?? gbv_check_scope(
            $scope,
            $type,
        ) ?? gbv_check_conditional($input['conditional_values'] ?? [], $type, allow_null: false);
    if ($error !== null) {
        return $error;
    }
    return [
        'id' => '',
        'name' => $name,
        'type' => $type,
        'label' => $label,
        'scope' => array_values($scope),
        'category' => gbv_css_js_trim($input['category'] ?? ''),
    ];
}

/**
 * The create, applied to the current styles and registry.
 *
 * @param array<array-key, mixed>    $styles
 * @param list<array<string, mixed>> $tokens
 * @param array<string, mixed>       $row
 * @param array<array-key, mixed>    $conditional
 * @return array{0: array<array-key, mixed>, 1: list<array<string, mixed>>}|WP_Error
 */
function gbv_create_mutation(
    array $styles,
    array $tokens,
    array $row,
    string $value,
    array $conditional,
): array|WP_Error {
    $name = (string) $row['name'];
    if (gbv_find_token($tokens, $name) !== null) {
        return new WP_Error('generateblocks_variable_exists', sprintf(
            /* translators: %s: CSS custom property name. */
            __(
                'A Design Token named "%s" already exists. Edit it with generateblocks-edit-variable, or pass another `name`.',
                domain: 'novamira-pro',
            ),
            $name,
        ));
    }
    if (in_array($name, gbv_unregistered_names($styles, $tokens), strict: true)) {
        return new WP_Error('generateblocks_variable_exists', sprintf(
            /* translators: %s: CSS custom property name. */
            __(
                '"%s" is already declared on :root without being a registered token. Pass another `name`, or ask the user to register it on the GenerateBlocks Design Tokens screen.',
                domain: 'novamira-pro',
            ),
            $name,
        ));
    }
    $tokens[] = $row;
    $styles[$name] = $value;
    // @mago-expect analysis:mixed-assignment -- values were checked by gbv_check_conditional().
    foreach ($conditional as $at_rule => $conditional_value) {
        $styles = gbv_set_value($styles, (string) $at_rule, $name, gbv_css_js_trim((string) $conditional_value));
    }
    return [$styles, $tokens];
}

/**
 * @param array{label: string, type: string, value: string, name?: string, category?: string, scope?: list<mixed>, conditional_values?: array<array-key, mixed>} $input
 * @return array<string, mixed>|WP_Error
 */
function generateblocks_create_variable(array $input): array|WP_Error
{
    $label = gbv_css_js_trim($input['label']);
    if ($label === '') {
        return new WP_Error('generateblocks_invalid_input', __('label cannot be empty.', domain: 'novamira-pro'));
    }
    $name = gbv_create_name($input, $label);
    if ($name instanceof WP_Error) {
        return $name;
    }
    $row = gbv_new_row($input, $name, $label);
    if ($row instanceof WP_Error) {
        return $row;
    }
    $value = gbv_css_js_trim($input['value']);
    $conditional = $input['conditional_values'] ?? [];
    $root = gbv_write(static fn(array $styles, array $tokens): array|WP_Error => gbv_create_mutation(
        $styles,
        $tokens,
        $row,
        $value,
        $conditional,
    ), create: true);
    return gbv_written_response($root, $name);
}

/**
 * @param array{name: string, label?: string, value?: string, type?: string, category?: string, scope?: list<mixed>, conditional_values?: array<array-key, mixed>} $input
 * @return array<string, mixed>|WP_Error
 */
function generateblocks_edit_variable(array $input): array|WP_Error
{
    $name = gbv_input_name($input['name']);
    if ($name instanceof WP_Error) {
        return $name;
    }
    if (array_diff_key($input, ['name' => true]) === []) {
        return new WP_Error('generateblocks_invalid_input', __(
            'Nothing to change: pass at least one of label, value, type, category, scope or conditional_values.',
            domain: 'novamira-pro',
        ));
    }
    if (isset($input['label']) && gbv_css_js_trim($input['label']) === '') {
        return new WP_Error('generateblocks_invalid_input', __('label cannot be empty.', domain: 'novamira-pro'));
    }
    $root = gbv_write(static fn(array $styles, array $tokens): array|WP_Error => gbv_edit_mutation(
        $styles,
        $tokens,
        $input,
        $name,
    ), create: false);
    return gbv_written_response($root, $name);
}

/**
 * The edit, applied to the current styles and registry. Every value the
 * token ends up with is checked against its final type.
 *
 * @param array<array-key, mixed>    $styles
 * @param list<array<string, mixed>> $tokens
 * @param array{name: string, label?: string, value?: string, type?: string, category?: string, scope?: list<mixed>, conditional_values?: array<array-key, mixed>} $input
 * @return array{0: array<array-key, mixed>, 1: list<array<string, mixed>>}|WP_Error
 */
function gbv_edit_mutation(array $styles, array $tokens, array $input, string $name): array|WP_Error
{
    $token = gbv_find_token($tokens, $name);
    if ($token === null) {
        return gbv_not_found($name);
    }
    $edited = gbv_edit_token($token, $input);
    if ($edited instanceof WP_Error) {
        return $edited;
    }
    $type = (string) $edited['type'];
    $conditional = $input['conditional_values'] ?? [];
    $error = (isset($input['scope']) ? gbv_check_scope($input['scope'], $type) : null) ?? gbv_check_conditional(
        $conditional,
        $type,
        allow_null: true,
    );
    if ($error !== null) {
        return $error;
    }
    $styles = gbv_edit_values($styles, $input, $name);
    // Like GenerateBlocks, check the values only when they or the type change:
    // a label, category or scope edit leaves a value it already holds alone.
    $values_change = isset($input['value']) || isset($input['type']) || $conditional !== [];
    foreach ($values_change ? gbv_token_values($styles, $name) : [] as $value) {
        $error = gbv_check_value($value, $type, where: $name);
        if ($error !== null) {
            return $error;
        }
    }
    $tokens = array_map(static fn(array $t): array => ($t['name'] ?? '') === $name ? $edited : $t, $tokens);
    return [$styles, $tokens];
}

/**
 * The styles with the edit's base and breakpoint values applied.
 *
 * @param array<array-key, mixed> $styles
 * @param array{value?: string, conditional_values?: array<array-key, mixed>, ...} $input
 * @return array<array-key, mixed>
 */
function gbv_edit_values(array $styles, array $input, string $name): array
{
    if (isset($input['value'])) {
        $styles[$name] = gbv_css_js_trim($input['value']);
    }
    // @mago-expect analysis:mixed-assignment -- values were checked by gbv_check_conditional().
    foreach ($input['conditional_values'] ?? [] as $at_rule => $value) {
        $styles = gbv_set_value($styles, (string) $at_rule, $name, is_string($value) ? gbv_css_js_trim($value) : null);
    }
    return $styles;
}

/**
 * The registry row with the requested type, label, category and scope.
 *
 * @param array<string, mixed> $token
 * @param array{label?: string, type?: string, category?: string, scope?: list<mixed>, ...} $input
 * @return array<string, mixed>|WP_Error
 */
function gbv_edit_token(array $token, array $input): array|WP_Error
{
    if (isset($input['type'])) {
        $changed = GenerateBlocks_Pro_Design_Tokens::change_token_type($token, $input['type']);
        if ($changed instanceof WP_Error) {
            return $changed;
        }
        $token = $changed;
    }
    if (isset($input['label'])) {
        $token['label'] = gbv_css_js_trim($input['label']);
    }
    if (isset($input['category'])) {
        $token['category'] = gbv_css_js_trim($input['category']);
    }
    if (isset($input['scope'])) {
        $token['scope'] = array_values($input['scope']);
    }
    return $token;
}

/**
 * @param array{name: string, force?: bool} $input
 * @return array<string, mixed>|WP_Error
 */
function generateblocks_delete_variable(array $input): array|WP_Error
{
    $name = gbv_input_name($input['name']);
    if ($name instanceof WP_Error) {
        return $name;
    }
    $before = gbv_read_root();
    $refused = gbv_unavailable_error($before['state']);
    // Checked here so a missing name is not scanned for, and again under the
    // lock, where it can only fail if the token was deleted in between.
    if ($refused === null && gbv_find_token($before['tokens'], $name) === null) {
        $refused = gbv_not_found($name);
    }
    if ($refused === null && ($input['force'] ?? false) !== true) {
        $refused = gbv_in_use_error($name, gbv_usage($name, $before));
    }
    if ($refused !== null) {
        return $refused;
    }

    $root = gbv_write(static function (array $styles, array $tokens) use ($name): array|WP_Error {
        if (gbv_find_token($tokens, $name) === null) {
            return gbv_not_found($name);
        }
        $kept = array_values(array_filter($tokens, static fn(array $t): bool => ($t['name'] ?? '') !== $name));
        return [gbv_remove_name($styles, $name), $kept];
    }, create: false);
    if ($root instanceof WP_Error) {
        return $root;
    }
    return ['state' => $root['state'], 'deleted' => $name];
}

/**
 * The refusal for a token still referenced, or null when it is unused.
 *
 * @param array{global_styles: list<mixed>, posts: list<mixed>, presets: list<mixed>, variables: list<mixed>, limited: bool} $usage
 */
function gbv_in_use_error(string $name, array $usage): ?WP_Error
{
    $counts = array_filter([
        'Global Styles' => count($usage['global_styles']),
        'posts' => count($usage['posts']),
        'other tokens' => count($usage['variables']),
        'token presets' => count($usage['presets']),
    ]);
    if ($counts === [] && $usage['limited']) {
        return new WP_Error('generateblocks_variable_usage_unknown', sprintf(
            /* translators: %s: CSS custom property name. */
            __(
                'No use of "%s" was found, but the usage scan covered only part of this site (GenerateBlocks scans the 5000 most recently modified posts), so an older post may still use it. Nothing was deleted. Tell the user, and retry with force only if they confirm.',
                domain: 'novamira-pro',
            ),
            $name,
        ));
    }
    if ($counts === []) {
        return null;
    }
    $where = [];
    foreach ($counts as $label => $count) {
        $where[] = $count . ' ' . $label;
    }
    return new WP_Error('generateblocks_variable_in_use', sprintf(
        /* translators: 1: CSS custom property name, 2: where it is used. */
        __(
            '"%1$s" is still used (%2$s), and deleting it would leave those var() references without a value. Nothing was deleted. Show the user where it is used (generateblocks-get-variable with include_usage) and retry with force only if they confirm.',
            domain: 'novamira-pro',
        ),
        $name,
        implode(', ', $where) . ($usage['limited'] ? ', possibly more' : ''),
    ));
}
