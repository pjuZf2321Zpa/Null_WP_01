<?php

// SPDX-FileCopyrightText: 2026 Ovation S.r.l. <dev@novamira.ai>
// SPDX-License-Identifier: AGPL-3.0-or-later

declare(strict_types=1);

namespace Novamira\Pro\Abilities\GenerateBlocks;

use GenerateBlocks_Pro_Design_Tokens;
use GenerateBlocks_Pro_Styles_Root;

if (!defined('ABSPATH')) {
    exit();
}

/**
 * Shared helpers for the GenerateBlocks Pro Design Tokens abilities.
 *
 * GenerateBlocks Pro stores Design Tokens on one `gblocks_styles` post whose
 * selector is `:root`. The registry (name, type, label, scope, category,
 * quick-edit control) is the `gb_style_tokens` meta; the values are custom
 * properties of the `:root` styles object (`gb_style_data`), where a top-level
 * string is the base value and a nested branch keyed by an at-rule or a
 * selector holds the value under that condition. Every read goes through the
 * vendor's own resolver and token reader, so snapshot recovery and row
 * sanitising behave exactly as in the Design dashboard.
 */

/**
 * Read the `:root` record without creating or repairing it.
 *
 * `state` is the vendor's resolution status: `ready` (published root, its CSS
 * is output), `inactive` (the root exists but is not published), `conflict`
 * (more than one root post, resolved in the Design dashboard) or `absent` (no
 * token was ever saved).
 *
 * @return array{
 *     state: string,
 *     post_id: int,
 *     styles: array<array-key, mixed>,
 *     css: string,
 *     tokens: list<array<string, mixed>>,
 *     recovered_from_backup: bool,
 *     checksum: string,
 * }
 */
function gbv_read_root(): array
{
    $resolved = GenerateBlocks_Pro_Styles_Root::resolve(fresh: true);
    $state = $resolved['status'];
    $post = in_array($state, ['ready', 'inactive'], strict: true) ? $resolved['post'] : null;

    if ($post === null) {
        return [
            'state' => $state,
            'post_id' => 0,
            'styles' => [],
            'css' => '',
            'tokens' => [],
            'recovered_from_backup' => false,
            'checksum' => '',
        ];
    }

    $aggregate = GenerateBlocks_Pro_Styles_Root::get_state($post);

    return [
        'state' => $state,
        'post_id' => $post->ID,
        'styles' => $aggregate['styles'],
        'css' => $aggregate['css'],
        'tokens' => $aggregate['tokens'],
        'recovered_from_backup' => $aggregate['recoveredFromBackup'],
        'checksum' => $aggregate['checksum'],
    ];
}

/**
 * Normalise a variable name as an agent may type it: surrounding whitespace
 * (Unicode included) trimmed, a `var(--x)` wrapper unwrapped, and `--` added
 * when the name has no leading dash at all. The result is not validated; see
 * gbv_is_valid_name().
 */
function gbv_normalize_name(string $name): string
{
    $name = (string) preg_replace('/^[\s\p{Z}\x{FEFF}]+|[\s\p{Z}\x{FEFF}]+$/u', replacement: '', subject: $name);
    $match = [];
    if (preg_match('/^var\(\s*(-[^\s,)]*)\s*(?:,[^)]*)?\)$/', $name, $match) === 1) {
        $name = $match[1];
    }
    if ($name === '' || str_starts_with($name, '-')) {
        return $name;
    }
    return '--' . $name;
}

/**
 * Whether a name is a valid Design Token name, by GenerateBlocks' own rule.
 */
function gbv_is_valid_name(string $name): bool
{
    return GenerateBlocks_Pro_Design_Tokens::is_valid_token_name($name);
}

/**
 * The registry as the Design dashboard shows it: a later row with a name
 * already seen is skipped (GenerateBlocks never writes duplicates, but a
 * hand-edited or imported registry can hold them).
 *
 * @param list<array<string, mixed>> $tokens
 * @return list<array<string, mixed>>
 */
function gbv_unique_tokens(array $tokens): array
{
    $seen = [];
    $out = [];
    foreach ($tokens as $token) {
        $name = (string) ($token['name'] ?? '');
        if (isset($seen[$name])) {
            continue;
        }
        $seen[$name] = true;
        $out[] = $token;
    }
    return $out;
}

/**
 * Custom properties declared on `:root` (at any depth) that are not
 * registered tokens, collected with GenerateBlocks' rule: a key that is a
 * valid token name is a variable, any other array is a branch to descend.
 *
 * @param array<array-key, mixed>    $styles
 * @param list<array<string, mixed>> $tokens
 * @return list<string>
 */
function gbv_unregistered_names(array $styles, array $tokens): array
{
    $registered = array_map(static fn(array $t): string => (string) ($t['name'] ?? ''), $tokens);
    $names = [];
    gbv_collect_names($styles, $names);
    return array_values(array_unique(array_diff($names, $registered)));
}

/**
 * @param array<array-key, mixed> $branch
 * @param list<string>            $names
 */
function gbv_collect_names(array $branch, array &$names): void
{
    // @mago-expect analysis:mixed-assignment -- the styles object is vendor data; every branch is type-checked here.
    foreach ($branch as $key => $value) {
        if (gbv_is_valid_name((string) $key)) {
            $names[] = (string) $key;
            continue;
        }
        if (is_array($value)) {
            gbv_collect_names($value, $names);
        }
    }
}

/**
 * Collect every conditional value of one custom property: each nested branch
 * of the `:root` styles object (at-rule or selector, at any depth) that sets
 * the property. `context` is the path of branch keys from the root.
 *
 * @param array<array-key, mixed> $styles
 * @param list<string>            $path
 * @return list<array{context: list<string>, value: string}>
 */
function gbv_conditional_values(array $styles, string $name, array $path = []): array
{
    $out = [];
    // @mago-expect analysis:mixed-assignment -- the styles object is vendor data; every branch is type-checked here.
    foreach ($styles as $key => $branch) {
        if (!is_array($branch)) {
            continue;
        }
        $context = [...$path, (string) $key];
        if (isset($branch[$name]) && is_string($branch[$name])) {
            $out[] = ['context' => $context, 'value' => $branch[$name]];
        }
        array_push($out, ...gbv_conditional_values($branch, $name, $context));
    }
    return $out;
}

/**
 * The compact row of one registry entry. `value` is the base value (outside
 * any condition), null when there is none or it is not a string. `issues` is
 * present only when something keeps the token out of the editor controls.
 *
 * @param array<array-key, mixed> $token
 * @param array<array-key, mixed> $styles
 * @return array<string, mixed>
 */
function gbv_variable_row(array $token, array $styles): array
{
    $name = (string) ($token['name'] ?? '');
    $type = (string) ($token['type'] ?? '');
    $has_base = array_key_exists($name, $styles);
    $value = $has_base && is_string($styles[$name]) ? $styles[$name] : null;

    $row = [
        'name' => $name,
        'label' => (string) ($token['label'] ?? ''),
        'type' => $type,
        'category' => (string) ($token['category'] ?? ''),
        'value' => $value,
    ];

    $conditional = gbv_conditional_values($styles, $name);
    if ($conditional !== []) {
        $row['conditional_values'] = $conditional;
    }

    $issue = match (true) {
        $has_base && $value === null => 'value_not_string',
        $value !== null => GenerateBlocks_Pro_Design_Tokens::is_valid_value_for_type($value, $type)
            ? ''
            : 'value_invalid_for_type',
        $conditional !== [] => 'no_default_value',
        default => 'no_value',
    };
    if ($issue !== '') {
        $row['issues'] = [$issue];
    }

    return $row;
}

/**
 * The compact row plus the registry fields only a single read returns.
 *
 * @param array<array-key, mixed> $token
 * @param array<array-key, mixed> $styles
 * @return array<string, mixed>
 */
function gbv_variable_detail(array $token, array $styles): array
{
    $row = gbv_variable_row($token, $styles);
    $row['id'] = (string) ($token['id'] ?? '');
    // GenerateBlocks' sanitize_token() always stores `scope` as a list.
    $row['scope'] = isset($token['scope']) && is_array($token['scope']) ? $token['scope'] : [];
    if (isset($token['display']) && is_array($token['display'])) {
        $row['display'] = $token['display'];
    }
    return $row;
}
