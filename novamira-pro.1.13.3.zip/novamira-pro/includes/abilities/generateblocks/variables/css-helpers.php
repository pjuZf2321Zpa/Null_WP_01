<?php

// SPDX-FileCopyrightText: 2026 Ovation S.r.l. <dev@novamira.ai>
// SPDX-License-Identifier: AGPL-3.0-or-later

declare(strict_types=1);

namespace Novamira\Pro\Abilities\GenerateBlocks;

use stdClass;
use UnexpectedValueException;

if (!defined('ABSPATH')) {
    exit();
}

/**
 * A PHP port of the CSS compiler GenerateBlocks Pro runs in the browser for
 * the `:root` Design Tokens record: `getCss(':root', styles)` from the Pro
 * `styles-builder` bundle, then its PostCSS pipeline (key sort, media query
 * merge and order, color-mix fallback, postcss-minify through
 * postcss-value-parser 4).
 *
 * GenerateBlocks has no server-side compiler: the Design dashboard compiles
 * the CSS in the browser and the server stores it as sent. A write from PHP
 * must therefore produce the bytes the dashboard would have produced. The port
 * covers what a Design Tokens root holds (custom properties on `:root`, under
 * at-rule and selector branches). Anything else throws
 * UnexpectedValueException, and the write abilities refuse instead of guessing.
 *
 * Checked against the vendor bundle, whose output in Node matches the browser.
 */
/** A character code past the end of the string: matches no delimiter, and is not whitespace. */
const GBV_CSS_PAST_END = 0x11_0000;

/** JavaScript's String.prototype.trim() whitespace set. */
const GBV_CSS_JS_SPACE = '[\x{0009}-\x{000D}\x{0020}\x{00A0}\x{1680}\x{2000}-\x{200A}\x{2028}\x{2029}\x{202F}\x{205F}\x{3000}\x{FEFF}]';

/**
 * @throws UnexpectedValueException Always.
 */
function gbv_css_unsupported(string $why): void
{
    throw new UnexpectedValueException($why);
}

/**
 * A word matched case-insensitively in ASCII only, as a JavaScript regex with
 * the `i` flag and no `u` flag does. PCRE's `/iu` would also fold `ſ` to `s`
 * and the Kelvin sign to `k`, which the builder does not.
 */
function gbv_css_ascii_ci(string $word): string
{
    $out = '';
    foreach (str_split($word) as $char) {
        $lower = strtolower($char);
        $upper = strtoupper($char);
        $out .= $lower === $upper ? preg_quote($char, delimiter: '/') : '[' . $lower . $upper . ']';
    }
    return $out;
}

/**
 * `/^word1<JS space>+word2$/u`, both words ASCII case-insensitive: the
 * builder's `/^in\s+oklch$/i` with JavaScript's `\s`.
 */
function gbv_css_ci_pattern(string $first, string $second): string
{
    return '/^' . gbv_css_ascii_ci($first) . GBV_CSS_JS_SPACE . '+' . gbv_css_ascii_ci($second) . '$/u';
}

/** String.prototype.trim(). */
function gbv_css_js_trim(string $s): string
{
    return (string) preg_replace(
        '/^' . GBV_CSS_JS_SPACE . '+|' . GBV_CSS_JS_SPACE . '+$/u',
        replacement: '',
        subject: $s,
    );
}

/** Array.prototype.sort()'s default order: UTF-16 code units. */
function gbv_css_js_compare(string $a, string $b): int
{
    return strcmp(
        (string) mb_convert_encoding($a, to_encoding: 'UTF-16BE', from_encoding: 'UTF-8'),
        (string) mb_convert_encoding($b, to_encoding: 'UTF-16BE', from_encoding: 'UTF-8'),
    );
}

/** String.prototype.localeCompare() for the media query strings it orders. */
function gbv_css_locale_compare(string $a, string $b): int
{
    if ($a === $b) {
        return 0;
    }
    if (!class_exists(\Collator::class)) {
        gbv_css_unsupported('ordering these media queries needs the intl extension');
    }
    static $collator = null;
    $collator ??= new \Collator('en');
    $result = $collator->compare($a, $b);
    if ($result === false) {
        gbv_css_unsupported('media query collation failed');
    }
    return (int) $result;
}

// ---------------------------------------------------------------------------
// postcss-value-parser 4: parse, minify, stringify. Byte based: every
// delimiter is ASCII and every byte of a multi-byte UTF-8 character is > 32,
// so the vendor's UTF-16 offsets and these byte offsets split values alike.

/**
 * A fresh parser state. `func` is the function the parser is in, or the root
 * container once a function has closed: the vendor reads `E.type` off
 * whichever was assigned last.
 *
 * @return array{css: string, length: int, end: int, pos: int, code: int, stack: list<stdClass>, func: ?stdClass, depth: int, name: string, before_div: string, before_close: string}
 */
function gbv_css_vp_state(string $css): array
{
    $root = gbv_css_vp_node('root', value: '');
    return [
        'css' => $css,
        'length' => strlen($css),
        'end' => strlen($css),
        'pos' => 0,
        'code' => gbv_css_vp_code($css, i: 0),
        'stack' => [$root],
        'func' => null,
        'depth' => 0,
        'name' => '',
        'before_div' => '',
        'before_close' => '',
    ];
}

function gbv_css_vp_code(string $css, int $i): int
{
    return $i >= 0 && $i < strlen($css) ? ord($css[$i]) : GBV_CSS_PAST_END;
}

/**
 * @param array{func: ?stdClass, ...} $p
 */
function gbv_css_vp_in_calc(array $p): bool
{
    $func = $p['func'];
    return $func !== null && $func->type === 'function' && $func->value === 'calc';
}

/**
 * The node list of the innermost open container.
 *
 * @param array{stack: list<stdClass>, ...} $p
 */
function gbv_css_vp_current(array $p): stdClass
{
    return $p['stack'][count($p['stack']) - 1];
}

/**
 * @param array{stack: list<stdClass>, ...} $p
 */
function gbv_css_vp_push(array $p, stdClass $node): void
{
    $current = gbv_css_vp_current($p);
    $nodes = gbv_css_vp_children($current);
    $nodes[] = $node;
    $current->nodes = $nodes;
}

/**
 * @return list<stdClass>
 */
function gbv_css_vp_parse(string $css): array
{
    $p = gbv_css_vp_state($css);
    while ($p['pos'] < $p['end']) {
        $c = $p['code'];
        match (true) {
            $c <= 32 => gbv_css_vp_space($p),
            $c === 0x27 || $c === 0x22 => gbv_css_vp_string($p),
            $c === 0x2F && gbv_css_vp_code($p['css'], $p['pos'] + 1) === 0x2A => gbv_css_unsupported('comment'),
            ($c === 0x2F || $c === 0x2A) && gbv_css_vp_in_calc($p) => gbv_css_vp_char_word($p),
            $c === 0x2F || $c === 0x2C || $c === 0x3A => gbv_css_vp_div($p),
            $c === 0x28 => gbv_css_vp_open($p),
            $c === 0x29 && $p['depth'] > 0 => gbv_css_vp_close($p),
            default => gbv_css_vp_word($p),
        };
    }
    // Functions still open at the end are unclosed.
    foreach (array_slice($p['stack'], offset: 1) as $open) {
        $open->unclosed = true;
    }
    return gbv_css_vp_children($p['stack'][0]);
}

function gbv_css_vp_node(string $type, string $value): stdClass
{
    $node = new stdClass();
    $node->type = $type;
    $node->value = $value;
    $node->before = '';
    $node->after = '';
    $node->quote = '';
    $node->unclosed = false;
    $node->nodes = [];
    return $node;
}

/** A text field of a node. */
function gbv_css_vp_text(stdClass $node, string $field): string
{
    // @mago-expect analysis:mixed-assignment -- every node field is set as a string by gbv_css_vp_node().
    $value = match ($field) {
        'type' => $node->type,
        'value' => $node->value,
        'before' => $node->before,
        'after' => $node->after,
        default => $node->quote,
    };
    return is_string($value) ? $value : '';
}

/**
 * @return list<stdClass>
 */
function gbv_css_vp_children(stdClass $node): array
{
    /** @var list<stdClass> */
    return is_array($node->nodes) ? $node->nodes : [];
}

/**
 * Whitespace: the after-space of a divider, the before-space of a divider or
 * of a closing parenthesis, or a space node.
 *
 * @param array{css: string, length: int, end: int, pos: int, code: int, stack: list<stdClass>, func: ?stdClass, depth: int, name: string, before_div: string, before_close: string} $p
 */
function gbv_css_vp_space(array &$p): void
{
    $f = $p['pos'];
    do {
        $f++;
        $p['code'] = gbv_css_vp_code($p['css'], $f);
    } while ($p['code'] <= 32);
    $space = substr($p['css'], $p['pos'], $f - $p['pos']);
    $nodes = gbv_css_vp_children(gbv_css_vp_current($p));
    $last = $nodes === [] ? null : $nodes[count($nodes) - 1];
    $c = $p['code'];
    $func = $p['func'];
    $slash_divides =
        $c === 0x2F
        && gbv_css_vp_code($p['css'], $f + 1) !== 0x2A
        && ($func === null || $func->type === 'function' && $func->value !== 'calc');
    $p['pos'] = $f;
    if ($c === 0x29 && $p['depth'] > 0) {
        $p['before_close'] = $space;
        return;
    }
    if ($last !== null && $last->type === 'div') {
        $last->after = $space;
        return;
    }
    if ($c === 0x2C || $c === 0x3A || $slash_divides) {
        $p['before_div'] = $space;
        return;
    }
    gbv_css_vp_push($p, gbv_css_vp_node('space', $space));
}

/**
 * A quoted string; an unclosed one is closed at the end, as the vendor does.
 *
 * @param array{css: string, length: int, end: int, pos: int, code: int, stack: list<stdClass>, func: ?stdClass, depth: int, name: string, before_div: string, before_close: string} $p
 */
function gbv_css_vp_string(array &$p): void
{
    $quote = $p['code'] === 0x27 ? "'" : '"';
    $f = $p['pos'];
    $unclosed = false;
    do {
        $escaped = false;
        $next = strpos($p['css'], $quote, $f + 1);
        if ($next === false) {
            $p['css'] .= $quote;
            $p['length'] = strlen($p['css']);
            $f = $p['length'] - 1;
            $unclosed = true;
            continue;
        }
        $f = $next;
        for ($y = $f; gbv_css_vp_code($p['css'], $y - 1) === 0x5C; $y--) {
            $escaped = !$escaped;
        }
    } while ($escaped);
    $node = gbv_css_vp_node('string', substr($p['css'], $p['pos'] + 1, $f - $p['pos'] - 1));
    $node->quote = $quote;
    $node->unclosed = $unclosed;
    gbv_css_vp_push($p, $node);
    $p['pos'] = $f + 1;
    $p['code'] = gbv_css_vp_code($p['css'], $p['pos']);
}

/**
 * `/` or `*` inside calc(): a one-character word.
 *
 * @param array{css: string, length: int, end: int, pos: int, code: int, stack: list<stdClass>, func: ?stdClass, depth: int, name: string, before_div: string, before_close: string} $p
 */
function gbv_css_vp_char_word(array &$p): void
{
    gbv_css_vp_push($p, gbv_css_vp_node('word', $p['css'][$p['pos']]));
    $p['pos']++;
    $p['code'] = gbv_css_vp_code($p['css'], $p['pos']);
}

/**
 * @param array{css: string, length: int, end: int, pos: int, code: int, stack: list<stdClass>, func: ?stdClass, depth: int, name: string, before_div: string, before_close: string} $p
 */
function gbv_css_vp_div(array &$p): void
{
    $node = gbv_css_vp_node('div', $p['css'][$p['pos']]);
    $node->before = $p['before_div'];
    gbv_css_vp_push($p, $node);
    $p['before_div'] = '';
    $p['pos']++;
    $p['code'] = gbv_css_vp_code($p['css'], $p['pos']);
}

/**
 * @param array{css: string, length: int, end: int, pos: int, code: int, stack: list<stdClass>, func: ?stdClass, depth: int, name: string, before_div: string, before_close: string} $p
 */
function gbv_css_vp_open(array &$p): void
{
    $f = $p['pos'];
    do {
        $f++;
        $p['code'] = gbv_css_vp_code($p['css'], $f);
    } while ($p['code'] <= 32);
    // Reached by at-rule parameters (`@supports (background:url(x))`), which
    // do not go through gbv_css_clean_value().
    if ($p['name'] === 'url' && $p['code'] !== 0x27 && $p['code'] !== 0x22) {
        gbv_css_unsupported('url()');
    }
    $node = gbv_css_vp_node('function', $p['name']);
    $node->before = substr($p['css'], $p['pos'] + 1, $f - $p['pos'] - 1);
    gbv_css_vp_push($p, $node);
    $p['pos'] = $f;
    $p['depth']++;
    $p['stack'][] = $node;
    $p['func'] = $node;
    $p['name'] = '';
}

/**
 * @param array{css: string, length: int, end: int, pos: int, code: int, stack: list<stdClass>, func: ?stdClass, depth: int, name: string, before_div: string, before_close: string} $p
 */
function gbv_css_vp_close(array &$p): void
{
    $p['pos']++;
    $p['code'] = gbv_css_vp_code($p['css'], $p['pos']);
    if ($p['func'] !== null) {
        $p['func']->after = $p['before_close'];
    }
    $p['before_close'] = '';
    $p['depth']--;
    array_pop($p['stack']);
    $p['func'] = $p['stack'][$p['depth']];
}

/**
 * A word, a unicode-range, or the name of the function that follows.
 *
 * @param array{css: string, length: int, end: int, pos: int, code: int, stack: list<stdClass>, func: ?stdClass, depth: int, name: string, before_div: string, before_close: string} $p
 */
function gbv_css_vp_word(array &$p): void
{
    $f = $p['pos'];
    do {
        $f += $p['code'] === 0x5C ? 2 : 1;
        $p['code'] = gbv_css_vp_code($p['css'], $f);
    } while ($f < $p['end'] && !gbv_css_vp_word_ends($p));
    $word = substr($p['css'], $p['pos'], $f - $p['pos']);
    $p['pos'] = $f;
    if ($p['code'] === 0x28) {
        $p['name'] = $word;
        return;
    }
    $type = preg_match('/^u\+[a-f0-9?-]+$/i', $word) === 1 ? 'unicode-range' : 'word';
    gbv_css_vp_push($p, gbv_css_vp_node($type, $word));
}

/**
 * @param array{code: int, func: ?stdClass, depth: int, ...} $p
 */
function gbv_css_vp_word_ends(array $p): bool
{
    $c = $p['code'];
    return (
        $c <= 32
        || in_array($c, [0x27, 0x22, 0x2C, 0x3A, 0x2F, 0x28], strict: true)
        || $c === 0x2A
        && gbv_css_vp_in_calc($p)
        || $c === 0x29
        && $p['depth'] > 0
    );
}

/**
 * @param list<stdClass> $nodes
 */
function gbv_css_vp_stringify(array $nodes): string
{
    $out = '';
    foreach ($nodes as $n) {
        $value = gbv_css_vp_text($n, field: 'value');
        $close = $n->unclosed === true ? '' : ')';
        $out .= match (gbv_css_vp_text($n, field: 'type')) {
            'string' => $n->unclosed === true
                ? gbv_css_vp_text($n, field: 'quote') . $value
                : gbv_css_vp_text($n, field: 'quote') . $value . gbv_css_vp_text($n, field: 'quote'),
            'div' => gbv_css_vp_text($n, field: 'before') . $value . gbv_css_vp_text($n, field: 'after'),
            'function' => $value
                . '('
                . gbv_css_vp_text($n, field: 'before')
                . gbv_css_vp_stringify(gbv_css_vp_children($n))
                . gbv_css_vp_text($n, field: 'after')
                . $close,
            default => $value,
        };
    }
    return $out;
}

/**
 * postcss-minify's value pass: no space around dividers or inside function
 * parentheses, and any run of whitespace becomes one space.
 *
 * @param list<stdClass> $nodes
 */
function gbv_css_vp_minify(array $nodes): void
{
    foreach ($nodes as $n) {
        $n->before = '';
        $n->after = '';
        if ($n->type === 'space') {
            $n->value = ' ';
        }
        gbv_css_vp_minify(gbv_css_vp_children($n));
    }
}

function gbv_css_minify_value(string $value): string
{
    $nodes = gbv_css_vp_parse(gbv_css_js_trim($value));
    gbv_css_vp_minify($nodes);
    return gbv_css_vp_stringify($nodes);
}

// ---------------------------------------------------------------------------
// Declaration values

/**
 * The builder's value clean-up (`Fr()`): trim, drop a `)` with no opener,
 * close what is left open, close an odd double quote.
 */
function gbv_css_clean_value(string $value): string
{
    $trimmed = gbv_css_js_trim($value);
    if (preg_match('/url' . GBV_CSS_JS_SPACE . '*\(/u', $trimmed) === 1) {
        gbv_css_unsupported('url()');
    }
    $depth = 0;
    $out = '';
    foreach (str_split($trimmed) as $c) {
        if ($c === ')' && $depth === 0) {
            continue;
        }
        $depth += match ($c) {
            '(' => 1,
            ')' => -1,
            default => 0,
        };
        $out .= $c;
    }
    $out .= str_repeat(')', $depth);
    return (substr_count($out, needle: '"') % 2) !== 0 ? $out . '"' : $out;
}

/**
 * Throw when PostCSS would fail to parse the cleaned value ("Unclosed string",
 * "Unclosed bracket"): the vendor then stores its raw, unminified CSS.
 */
function gbv_css_assert_parsable(string $clean): void
{
    $length = strlen($clean);
    $depth = 0;
    for ($i = 0; $i < $length; $i++) {
        $c = $clean[$i];
        if ($c === '"' || $c === "'") {
            $close = strpos($clean, $c, $i + 1);
            if ($close === false) {
                gbv_css_unsupported('unclosed string');
            }
            $i = (int) $close;
            continue;
        }
        $depth += match ($c) {
            '(' => 1,
            ')' => -1,
            default => 0,
        };
        if ($depth < 0) {
            gbv_css_unsupported('bracket inside a string');
        }
    }
    if ($depth !== 0) {
        gbv_css_unsupported('bracket inside a string');
    }
}

/**
 * The declaration value as the stylesheet carries it.
 *
 * @throws UnexpectedValueException For a value the port does not reproduce.
 */
function gbv_css_value(mixed $value): string
{
    if (is_int($value)) {
        $value = (string) $value;
    }
    if (!is_string($value)) {
        gbv_css_unsupported('a value that is not text');
    }
    /** @var string $value */
    if (preg_match('/[;{}!\\\\<]|\/\*|[\x00-\x08\x0B\x0E-\x1F\x7F]/', $value) === 1) {
        gbv_css_unsupported('a value with !, ;, {, }, <, a backslash, a comment or a control character');
    }
    $clean = gbv_css_clean_value($value);
    gbv_css_assert_parsable($clean);
    return gbv_css_minify_value($clean);
}

// ---------------------------------------------------------------------------
// color-mix fallback (the vendor's gb-color-mix-fallback plugin)

/** Index of the `)` closing the `(` at or after $from, outside strings; -1 if none. */
function gbv_css_close_index(string $e, int $from): int
{
    $depth = 0;
    $quote = '';
    $escaped = false;
    $length = strlen($e);
    for ($i = $from; $i < $length; $i++) {
        $c = $e[$i];
        if ($quote !== '') {
            [$quote, $escaped] = gbv_css_in_string($c, $quote, $escaped);
            continue;
        }
        if ($c === '"' || $c === "'") {
            $quote = $c;
            continue;
        }
        $depth += match ($c) {
            '(' => 1,
            ')' => -1,
            default => 0,
        };
        if ($c === ')' && $depth === 0) {
            return $i;
        }
    }
    return -1;
}

/**
 * One character inside a quoted string: the quote still open (or '') and
 * whether the next character is escaped.
 *
 * @return array{0: string, 1: bool}
 */
// @mago-expect lint:no-boolean-flag-parameter -- the escape flag is the scanner's state, threaded through.
function gbv_css_in_string(string $c, string $quote, bool $escaped): array
{
    if ($escaped) {
        return [$quote, false];
    }
    if ($c === '\\') {
        return [$quote, true];
    }
    return [$c === $quote ? '' : $quote, false];
}

/** The arguments of `fn(...)` when the whole string is that call, else null. */
function gbv_css_call_args(string $e, string $fn): ?string
{
    $open = $fn . '(';
    if (strtolower(substr($e, offset: 0, length: strlen($open))) !== $open) {
        return null;
    }
    $close = gbv_css_close_index($e, strlen($fn));
    return $close !== (strlen($e) - 1) ? null : substr($e, strlen($fn) + 1, $close - strlen($fn) - 1);
}

/**
 * Split on top-level commas (quotes and brackets respected).
 *
 * @return list<string>
 */
function gbv_css_split_args(string $e): array
{
    $out = [];
    $start = 0;
    $depth = 0;
    $quote = '';
    $escaped = false;
    $length = strlen($e);
    for ($i = 0; $i < $length; $i++) {
        $c = $e[$i];
        if ($quote !== '') {
            [$quote, $escaped] = gbv_css_in_string($c, $quote, $escaped);
            continue;
        }
        if ($c === '"' || $c === "'") {
            $quote = $c;
            continue;
        }
        $depth += match ($c) {
            '(' => 1,
            ')' => -1,
            default => 0,
        };
        if ($c === ',' && $depth === 0) {
            $out[] = substr($e, $start, $i - $start);
            $start = $i + 1;
        }
    }
    $out[] = substr($e, $start);
    return $out;
}

/** `var(--x...)` as given when it is one, else null. */
function gbv_css_var_expression(string $e): ?string
{
    $args = gbv_css_call_args($e, fn: 'var');
    if ($args === null) {
        return null;
    }
    $first = gbv_css_js_trim(gbv_css_split_args($args)[0]);
    return preg_match('/^--(?:(?!' . GBV_CSS_JS_SPACE . ')[^,()])+$/u', $first) === 1 ? $e : null;
}

/** `color-mix(in oklch, var(), #000|#fff N%)`: its var() expression. */
function gbv_css_shade_var(string $e): ?string
{
    $args = gbv_css_call_args($e, fn: 'color-mix');
    if ($args === null) {
        return null;
    }
    $parts = gbv_css_split_args($args);
    if (
        count($parts) !== 3
        || preg_match(gbv_css_ci_pattern(first: 'in', second: 'oklch'), gbv_css_js_trim($parts[0])) !== 1
    ) {
        return null;
    }
    $shade = preg_match(
        '/^(#000|#000000|'
        . gbv_css_ascii_ci('black')
        . '|#[fF]{3}|#[fF]{6}|'
        . gbv_css_ascii_ci('white')
        . ')'
        . GBV_CSS_JS_SPACE
        . '+((?:\d+(?:\.\d*)?)|(?:\.\d+))%$/u',
        gbv_css_js_trim($parts[2]),
    );
    $var = gbv_css_var_expression(gbv_css_js_trim($parts[1]));
    return $shade === 1 ? $var : null;
}

/**
 * The var() a "derived" color-mix() falls back to: a shade of a token, or a
 * token (or its shade) mixed with transparent in srgb. Null for anything else.
 */
function gbv_css_derived_var(string $e): ?string
{
    $t = gbv_css_js_trim($e);
    if ($t === '' || gbv_css_var_expression($t) !== null) {
        return null;
    }
    $args = gbv_css_call_args($t, fn: 'color-mix');
    $parts = $args === null ? [] : gbv_css_split_args($args);
    if (
        count($parts) === 3
        && preg_match(gbv_css_ci_pattern(first: 'in', second: 'srgb'), gbv_css_js_trim($parts[0])) === 1
    ) {
        $inner = gbv_css_js_trim($parts[1]);
        $var = gbv_css_var_expression($inner) ?? gbv_css_shade_var($inner);
        $alpha = preg_match(
            '/^' . gbv_css_ascii_ci('transparent') . GBV_CSS_JS_SPACE . '+((?:\d+(?:\.\d*)?)|(?:\.\d+))%$/u',
            gbv_css_js_trim($parts[2]),
        );
        if ($var !== null && $alpha === 1) {
            return $var;
        }
    }
    return gbv_css_shade_var($t);
}

/**
 * The fallback value the vendor declares just before a value holding a
 * derived color-mix(), or null when it adds none.
 */
function gbv_css_color_mix_fallback(string $value): ?string
{
    $out = '';
    $copied = 0;
    $quote = '';
    $escaped = false;
    $length = strlen($value);
    for ($i = 0; $i < $length; $i++) {
        $c = $value[$i];
        if ($quote !== '') {
            [$quote, $escaped] = gbv_css_in_string($c, $quote, $escaped);
            continue;
        }
        if ($c === '"' || $c === "'") {
            $quote = $c;
            continue;
        }
        $close = gbv_css_color_mix_close($value, $i);
        $var = $close === -1 ? null : gbv_css_derived_var(substr($value, $i, $close + 1 - $i));
        if ($var === null) {
            continue;
        }
        $out .= substr($value, $copied, $i - $copied) . $var;
        $copied = $close + 1;
        $i = $close;
    }
    return $copied === 0 ? null : $out . substr($value, $copied);
}

/** When a color-mix( call starts at $i (not inside a longer word): its closing index, else -1. */
function gbv_css_color_mix_close(string $value, int $i): int
{
    if (strtolower(substr($value, $i, length: 10)) !== 'color-mix(') {
        return -1;
    }
    if ($i > 0 && preg_match('/[a-z0-9_-]/i', $value[$i - 1]) === 1) {
        return -1;
    }
    return gbv_css_close_index($value, $i + 9);
}

// ---------------------------------------------------------------------------
// Selectors

/**
 * Split a selector list on top-level commas, each part trimmed.
 *
 * @return list<string>
 */
function gbv_css_selector_list(string $e): array
{
    $out = [];
    $depth = 0;
    $quote = '';
    $start = 0;
    $length = strlen($e);
    for ($i = 0; $i < $length; $i++) {
        $c = $e[$i];
        if ($c === '\\') {
            $i++;
            continue;
        }
        if ($quote !== '') {
            $quote = $c === $quote ? '' : $quote;
            continue;
        }
        if ($c === '"' || $c === "'") {
            $quote = $c;
            continue;
        }
        $depth += match ($c) {
            '(', '[' => 1,
            ')', ']' => $depth > 0 ? -1 : 0,
            default => 0,
        };
        if ($c === ',' && $depth === 0) {
            $out[] = gbv_css_js_trim(substr($e, $start, $i - $start));
            $start = $i + 1;
        }
    }
    $out[] = gbv_css_js_trim(substr($e, $start));
    return $out;
}

/**
 * The selector of a nested branch (`Hr()`), minified as postcss-minify does,
 * for the selector shapes the port supports.
 */
function gbv_css_nested_selector(string $base, string $nested): string
{
    if (preg_match('/&[a-zA-Z#][a-zA-Z0-9]*;|[\\\\(){}<;*]/', $nested) === 1) {
        gbv_css_unsupported('a selector with an entity, brackets, a backslash or *');
    }
    $out = [];
    foreach (gbv_css_selector_list($base) as $e) {
        foreach (gbv_css_selector_list($nested) as $t) {
            $selector = str_starts_with($t, '&') ? $e . substr($t, offset: 1) : $e . ' ' . $t;
            gbv_css_assert_simple_attributes($selector);
            $selector = (string) preg_replace(
                '/\s*([>+~])\s*/',
                replacement: '$1',
                subject: gbv_css_js_trim($selector),
            );
            $out[] = (string) preg_replace('/\s+/', replacement: ' ', subject: $selector);
        }
    }
    return implode(',', $out);
}

function gbv_css_assert_simple_attributes(string $selector): void
{
    if (!str_contains($selector, '[') && !str_contains($selector, '"') && !str_contains($selector, "'")) {
        return;
    }
    $attribute = '\[[a-zA-Z_-]+(?:[~|^$*]?=(?:"[^"\s]*"|\'[^\'\s]*\'|[a-zA-Z0-9_-]+))?\]';
    if (preg_match('/^[^"\'\[\]]*(?:' . $attribute . '[^"\'\[\]]*)*$/', $selector) !== 1) {
        gbv_css_unsupported('an attribute selector with spaces or unusual quoting');
    }
}

// ---------------------------------------------------------------------------
// Structure and output

/** array_is_list() for PHP 8.0. */
function gbv_css_is_list(array $value): bool
{
    return array_keys($value) === range(0, count($value) - 1);
}

function gbv_css_is_map(mixed $value): bool
{
    return is_array($value) && ($value === [] || !gbv_css_is_list($value));
}

/**
 * The builder's one-level merge of two branches.
 *
 * @param array<array-key, mixed> $into
 * @return array<array-key, mixed>
 */
function gbv_css_merge(array $into, mixed $from): array
{
    if (!is_array($from)) {
        return $into;
    }
    // @mago-expect analysis:mixed-assignment -- branch values are vendor data, checked when compiled.
    foreach ($from as $key => $value) {
        // @mago-expect analysis:mixed-assignment -- branch values are vendor data, checked when compiled.
        $current = $into[$key] ?? null;
        // Two maps only meet here in shapes compiled() refuses later (a
        // selector inside a selector inside an at-rule); kept as the builder
        // writes it, it never changes an accepted output.
        $into[$key] = is_array($current) && gbv_css_is_map($current) && is_array($value) && gbv_css_is_map($value)
            ? array_replace($current, $value)
            : $value;
    }
    return $into;
}

/**
 * @param array<array-key, mixed> $map
 * @return array<array-key, mixed>
 */
function gbv_css_sort_keys(array $map): array
{
    uksort($map, static fn(int|string $a, int|string $b): int => gbv_css_js_compare((string) $a, (string) $b));
    return $map;
}

/**
 * Split one styles object the way the builder does (`Wr()`): declarations,
 * nested selector branches (both key-sorted) and at-rules (in order).
 *
 * @param array<array-key, mixed> $styles
 * @return array{at: array<string, array<array-key, mixed>>, nested: array<array-key, mixed>, props: array<array-key, mixed>}
 */
function gbv_css_split(array $styles): array
{
    $at = [];
    $nested = [];
    $props = [];
    // @mago-expect analysis:mixed-assignment -- the styles object is vendor data; every branch is checked here.
    foreach ($styles as $key => $value) {
        if (!is_string($key)) {
            gbv_css_unsupported('a numeric key');
        }
        $key = (string) $key;
        if (str_starts_with($key, '@')) {
            if (!gbv_css_is_map($value)) {
                gbv_css_unsupported('an at-rule that is not a branch');
            }
            $at[$key] = gbv_css_merge($at[$key] ?? [], $value);
            continue;
        }
        if (!is_array($value)) {
            $props[$key] = $value;
            continue;
        }
        if (!gbv_css_is_map($value)) {
            gbv_css_unsupported('a branch that is a list');
        }
        // @mago-expect analysis:mixed-assignment -- branch values are vendor data, checked when compiled.
        foreach ($value as $inner => $inner_value) {
            if (!is_string($inner)) {
                gbv_css_unsupported('a numeric key');
            }
            $inner = (string) $inner;
            if (str_starts_with($inner, '@')) {
                $branch = $at[$inner] ?? [];
                $branch[$key] = gbv_css_merge(is_array($branch[$key] ?? null) ? $branch[$key] : [], $inner_value);
                $at[$inner] = $branch;
                continue;
            }
            $rule = is_array($nested[$key] ?? null) ? $nested[$key] : [];
            $rule[$inner] = $inner_value;
            $nested[$key] = $rule;
        }
    }
    return ['at' => $at, 'nested' => gbv_css_sort_keys($nested), 'props' => gbv_css_sort_keys($props)];
}

/**
 * The declarations of one rule, in output order, with the vendor's color-mix
 * fallbacks. Custom properties keep their order: postcss-sorting does not
 * move them, only the key sort in gbv_css_split() does.
 *
 * @param array<array-key, mixed> $props
 * @return list<array{0: string, 1: string}>
 */
function gbv_css_declarations(array $props): array
{
    $out = [];
    // @mago-expect analysis:mixed-assignment -- declaration values are vendor data, checked by gbv_css_value().
    foreach ($props as $prop => $value) {
        $prop = (string) $prop;
        if (!str_starts_with($prop, '--')) {
            gbv_css_unsupported('a property that is not a custom property');
        }
        if (is_array($value) || $value === null) {
            gbv_css_unsupported('a branch nested too deep');
        }
        // The builder silently skips a name its property filter rejects.
        if (preg_match('/^--[\p{L}\p{N}\p{M}_-]+$/u', $prop) !== 1) {
            continue;
        }
        $css = gbv_css_value($value);
        // The builder drops a fallback equal to the declaration before it;
        // in one rule each property appears once, so that never happens here.
        $fallback = gbv_css_color_mix_fallback($css);
        if ($fallback !== null) {
            $out[] = [$prop, $fallback];
        }
        $out[] = [$prop, $css];
    }
    return $out;
}

/**
 * @param list<array{0: string, 1: string}> $declarations
 */
function gbv_css_rule(string $selector, array $declarations): string
{
    if ($declarations === []) {
        return '';
    }
    $body = array_map(static fn(array $d): string => $d[0] . ':' . $d[1], $declarations);
    return $selector . '{' . implode(';', $body) . '}';
}

/**
 * The rules inside one at-rule branch.
 *
 * @param array<array-key, mixed> $body
 * @return list<string>
 */
function gbv_css_at_rule_rules(string $selector, array $body): array
{
    $inner = gbv_css_split($body);
    if ($inner['at'] !== []) {
        gbv_css_unsupported('an at-rule nested in an at-rule');
    }
    $rules = [];
    if ($inner['props'] !== []) {
        $rules[] = gbv_css_rule($selector, gbv_css_declarations($inner['props']));
    }
    // @mago-expect analysis:mixed-assignment -- nested branches are vendor data, checked below.
    foreach ($inner['nested'] as $nested => $props) {
        if (!is_array($props)) {
            gbv_css_unsupported('a selector branch that is not a branch');
        }
        /** @var array<array-key, mixed> $props */
        $rules[] = gbv_css_rule(gbv_css_nested_selector($selector, (string) $nested), gbv_css_declarations($props));
    }
    if ($rules === []) {
        gbv_css_unsupported('an empty at-rule branch');
    }
    return $rules;
}

/**
 * The CSS GenerateBlocks Pro's Design dashboard stores for a `:root` styles
 * object.
 *
 * @param array<array-key, mixed> $styles
 * @throws UnexpectedValueException For a styles object the port does not reproduce.
 */
function gbv_css_root(array $styles, string $selector = ':root'): string
{
    $split = gbv_css_split($styles);
    $css = gbv_css_rule($selector, gbv_css_declarations($split['props']));
    // @mago-expect analysis:mixed-assignment -- nested branches are vendor data, checked below.
    foreach ($split['nested'] as $nested => $props) {
        /** @var array<array-key, mixed> $props */
        $css .= gbv_css_rule(gbv_css_nested_selector($selector, (string) $nested), gbv_css_declarations($props));
    }

    // Media queries are merged by their raw text, moved after everything
    // else and sorted; other at-rules stay in place.
    $media = [];
    foreach ($split['at'] as $key => $body) {
        $match = [];
        if (preg_match('/^@(media|supports|container)\s+(\S.*)$/s', $key, $match) !== 1) {
            gbv_css_unsupported('an at-rule other than @media, @supports or @container');
        }
        $params = rtrim($match[2]);
        $rules = gbv_css_at_rule_rules($selector, $body);
        if ($match[1] === 'media') {
            $media[$params] = [...($media[$params] ?? []), ...$rules];
            continue;
        }
        $css .= gbv_css_at_rule($match[1], $params, $rules);
    }
    $order = gbv_css_v8_sort(array_map('strval', array_keys($media)), __NAMESPACE__ . '\\gbv_css_media_compare');
    foreach ($order as $params) {
        $css .= gbv_css_at_rule('media', $params, $media[$params]);
    }
    return $css;
}

/**
 * Array.prototype.sort() as V8 runs it on fewer than 64 items: the leading run
 * (reversed when strictly descending), then a binary insertion sort. The
 * vendor's media comparator is not transitive for queries that are both
 * min and max, so only the same algorithm, calling the comparator with the
 * same arguments in the same order, yields the same order.
 *
 * @param list<string>                  $items
 * @param callable(string, string): int $compare
 * @return list<string>
 */
function gbv_css_v8_sort(array $items, callable $compare): array
{
    $n = count($items);
    if ($n < 2) {
        return $items;
    }
    if ($n >= 64) {
        gbv_css_unsupported('64 or more media queries');
    }
    [$items, $run] = gbv_css_v8_leading_run($items, $compare);
    for ($start = $run; $start < $n; $start++) {
        $pivot = $items[$start];
        $left = 0;
        $right = $start;
        while ($left < $right) {
            $mid = $left + (($right - $left) >> 1);
            if ($compare($pivot, $items[$mid]) < 0) {
                $right = $mid;
                continue;
            }
            $left = $mid + 1;
        }
        array_splice($items, $start, length: 1);
        array_splice($items, $left, length: 0, replacement: [$pivot]);
    }
    return $items;
}

/**
 * V8's CountAndMakeRun: the length of the leading ascending (or strictly
 * descending, then reversed) run.
 *
 * @param list<string>                  $items
 * @param callable(string, string): int $compare
 * @return array{0: list<string>, 1: int}
 */
function gbv_css_v8_leading_run(array $items, callable $compare): array
{
    $n = count($items);
    $run = 2;
    $descending = $compare($items[1], $items[0]) < 0;
    for ($i = 2; $i < $n; $i++) {
        $order = $compare($items[$i], $items[$i - 1]);
        if ($descending ? $order >= 0 : $order < 0) {
            break;
        }
        $run++;
    }
    if ($descending) {
        $items = [...array_reverse(array_slice($items, offset: 0, length: $run)), ...array_slice($items, $run)];
    }
    return [$items, $run];
}

/**
 * @param list<string> $rules
 */
function gbv_css_at_rule(string $name, string $params, array $rules): string
{
    $body = implode('', $rules);
    return $body === '' ? '' : '@' . $name . ' ' . gbv_css_minify_value($params) . '{' . $body . '}';
}

// ---------------------------------------------------------------------------
// Media query order (the vendor's postcss-gb-sort-media-queries)

/** The vendor's media-range patterns, copied verbatim from styles-builder. */
const GBV_CSS_MEDIA = [
    'min_then_max_width' => '/(!?\(\s*min(-device)?-width)(.|\n)+\(\s*max(-device)?-width|\(\s*width\s*>(=)?(.|\n)+\(\s*width\s*<(=)?|(!?\(.*<(=)?\s*width\s*<(=)?)/i',
    'max_then_min_width' => '/(!?\(\s*max(-device)?-width)(.|\n)+\(\s*min(-device)?-width|\(\s*width\s*<(=)?(.|\n)+\(\s*width\s*>(=)?|(!?\(.*>(=)?\s*width\s*>(=)?)/i',
    'min_then_max_height' => '/(!?\(\s*min(-device)?-height)(.|\n)+\(\s*max(-device)?-height|\(\s*height\s*>(=)?(.|\n)+\(\s*height\s*<(=)?|(!?\(.*<(=)?\s*height\s*<(=)?)/i',
    'max_then_min_height' => '/(!?\(\s*max(-device)?-height)(.|\n)+\(\s*min(-device)?-height|\(\s*height\s*<(=)?(.|\n)+\(\s*height\s*>(=)?|(!?\(.*>(=)?\s*height\s*>(=)?)/i',
    'min_width' => '/\(\s*min(-device)?-width|\(\s*width\s*>(=)?/i',
    'max_width' => '/\(\s*max(-device)?-width|\(\s*width\s*<(=)?/i',
    'min_height' => '/\(\s*min(-device)?-height|\(\s*height\s*>(=)?/i',
    'max_height' => '/\(\s*max(-device)?-height|\(\s*height\s*<(=)?/i',
];

/** The vendor's Vt(): the range pattern, or the single pattern when the opposite range does not match. */
function gbv_css_media_test(string $query, string $range, string $opposite, string $single): bool
{
    $m = GBV_CSS_MEDIA;
    return (
        preg_match($m[$range], $query) === 1
        || preg_match($m[$opposite], $query) !== 1
        && preg_match($m[$single], $query) === 1
    );
}

/** Mobile-first query: min-width or min-height (the vendor's Pt() || Dt()). */
function gbv_css_media_is_min(string $query): bool
{
    return (
        gbv_css_media_test($query, range: 'min_then_max_width', opposite: 'max_then_min_width', single: 'min_width')
        || gbv_css_media_test(
            $query,
            range: 'min_then_max_height',
            opposite: 'max_then_min_height',
            single: 'min_height',
        )
    );
}

/** Desktop-first query: max-width or max-height (the vendor's Lt() || zt()). */
function gbv_css_media_is_max(string $query): bool
{
    return (
        gbv_css_media_test($query, range: 'max_then_min_width', opposite: 'min_then_max_width', single: 'max_width')
        || gbv_css_media_test(
            $query,
            range: 'max_then_min_height',
            opposite: 'min_then_max_height',
            single: 'max_height',
        )
    );
}

/** The query's first length in px, or INF (the vendor's $t()). */
// @mago-expect lint:no-boolean-flag-parameter -- mirrors the vendor's fallback for mobile-first queries.
function gbv_css_media_length(string $query, bool $is_min): float
{
    $match = [];
    if (preg_match('/(-?\d*\.?\d+)(ch|em|ex|px|rem)/', $query, $match) === 1) {
        $n = is_numeric($match[1]) ? (float) $match[1] : 0.0;
        return match ($match[2]) {
            'ch' => 8.898_437_5 * $n,
            'em', 'rem' => 16 * $n,
            'ex' => 8.296_875 * $n,
            default => $n,
        };
    }
    if ($is_min && preg_match('/(\d)/', $query, $match) === 1) {
        return is_numeric($match[1]) ? (float) $match[1] : INF;
    }
    return INF;
}

function gbv_css_media_compare(string $a, string $b): int
{
    $print = gbv_css_print_compare($a, $b);
    if ($print !== null) {
        return $print;
    }
    $a_min = gbv_css_media_is_min($a);
    $a_max = gbv_css_media_is_max($a);
    $b_min = gbv_css_media_is_min($b);
    $b_max = gbv_css_media_is_max($b);
    if (!$a_min && !$a_max || !$b_min && !$b_max) {
        return match (true) {
            $b_min || $b_max => -1,
            $a_min || $a_max => 1,
            default => gbv_css_locale_compare($a, $b),
        };
    }
    if ($a_min && $b_max) {
        return -1;
    }
    if ($a_max && $b_min) {
        return 1;
    }
    $la = gbv_css_media_length($a, $a_min);
    $lb = gbv_css_media_length($b, $b_min);
    $sign = $a_max ? -1 : 1;
    return match (true) {
        is_infinite($la) && is_infinite($lb) => gbv_css_locale_compare($a, $b),
        is_infinite($la) => 1,
        is_infinite($lb) => -1,
        $la > $lb => $sign,
        $la < $lb => -$sign,
        default => gbv_css_locale_compare($a, $b),
    };
}

/** Print queries go last; null when neither query mentions print. */
function gbv_css_print_compare(string $a, string $b): ?int
{
    $pa = preg_match('/print/i', $a) === 1;
    $pb = preg_match('/print/i', $b) === 1;
    if (!$pa && !$pb) {
        return null;
    }
    if ($pa !== $pb) {
        return $pa ? 1 : -1;
    }
    $oa = preg_match('/^print$/i', $a) === 1;
    $ob = preg_match('/^print$/i', $b) === 1;
    return match (true) {
        !$oa && $ob => 1,
        $oa && !$ob => -1,
        default => gbv_css_locale_compare($a, $b),
    };
}
