<?php

// SPDX-FileCopyrightText: 2026 Ovation S.r.l. <dev@novamira.ai>
// SPDX-License-Identifier: AGPL-3.0-or-later

declare(strict_types=1);

namespace Novamira\Pro\Abilities\GenerateBlocks;

if (!defined('ABSPATH')) {
    exit();
}

/**
 * Shared runtime guards + version helpers for the GenerateBlocks integration.
 *
 * Provides:
 *  - gb_available()        — free GenerateBlocks active at any version
 *  - gb_version()          — free version string ('' when inactive)
 *  - gb_pro_available()    — Pro plugin active
 *  - gb_pro_version()      — Pro version string ('' when inactive)
 *  - gb_variables_available() — Pro Design Tokens usable (loader condition
 *    of the `variables` folder)
 *
 * Scope note: for page content this integration is an introspection layer
 * only — block catalogue, attribute schemas, presence flags. The actual
 * reading and writing of block trees on a post lives in the
 * `novamira/gutenberg-*` abilities exposed by the base Novamira (free)
 * plugin; abilities here never duplicate that surface. The `variables`
 * folder also reads and writes the GenerateBlocks Pro Design Tokens.
 */

/**
 * GenerateBlocks Pro version string, or '' when not installed / inactive.
 * Detection: prefer the modern `GENERATEBLOCKS_PRO_VERSION` constant; fall
 * back to a class lookup for older builds that did not expose the constant.
 */
function gb_pro_version(): string
{
    if (defined('GENERATEBLOCKS_PRO_VERSION')) {
        return (string) constant('GENERATEBLOCKS_PRO_VERSION');
    }
    if (class_exists('GenerateBlocksPro') || class_exists('GenerateBlocks_Pro')) {
        return 'unknown';
    }
    return '';
}

/**
 * Whether GenerateBlocks Pro is active.
 */
function gb_pro_available(): bool
{
    return gb_pro_version() !== '';
}

/**
 * Whether GenerateBlocks Pro Design Tokens can be read and written: Pro at or
 * above NOVAMIRA_PRO_GENERATEBLOCKS_PRO_VARIABLES_MIN_VERSION, with the three
 * classes the variables abilities call. A Pro build that reports no version
 * ('unknown') is treated as below the floor.
 */
function gb_variables_available(): bool
{
    return (
        gb_pro_version_has_variables(gb_pro_version())
        && class_exists('GenerateBlocks_Pro_Design_Tokens')
        && class_exists('GenerateBlocks_Pro_Design_Tokens_Usage')
        && class_exists('GenerateBlocks_Pro_Styles_Root')
    );
}

/**
 * Whether a GenerateBlocks Pro version string is at or above the Design Tokens
 * floor. Kept apart from the site's state so it can be asked about any version.
 * version_compare() already ranks '' (Pro inactive) and 'unknown' (a build
 * without the version constant) below any release, so neither needs a branch.
 */
function gb_pro_version_has_variables(string $pro_version): bool
{
    return version_compare($pro_version, NOVAMIRA_PRO_GENERATEBLOCKS_PRO_VARIABLES_MIN_VERSION, operator: '>=');
}
