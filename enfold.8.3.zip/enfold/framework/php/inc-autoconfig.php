<?php
/**
 * This file first checks if the framework is used as a theme or plugin framework and sets values accordingly
 *
 * @author		Christian "Kriesi" Budschedl
 * @copyright	Copyright (c) Christian Budschedl
 * @link		http://kriesi.at
 * @link		http://aviathemes.com
 * @since		Version 1.0
 * @package 	AviaFramework
 */
if( ! defined( 'ABSPATH' ) )  {  exit( 'No direct script access allowed' );  }


/**
 * check if file is a plugin or theme based on its location, then set constant and globals for further use within the framework
 *
 * @todo create plugin version of framework and prevent interfering with theme version
 */



/**
* AVIA_BASE contains the root server path of the framework that is loaded
*/
if( ! defined( 'AVIA_BASE' ) )
{
	define( 'AVIA_BASE', get_template_directory() . '/' );
}


/**
* AVIA_BASE_URL contains the http url of the framework that is loaded
*/
if( ! defined( 'AVIA_BASE_URL' ) )
{
	define( 'AVIA_BASE_URL', get_template_directory_uri() . '/' );
}


/**
 * To fix a problem with Envato updater API 3.0 we add the Envato product ID to style.ccs - e.g.:
 * Envato ID: 4519990
 *
 * This allows us to support multiple themes in case we add new themes in future
 *
 * @since 4.5.3
 */
if( ! function_exists( 'handler_avia_extra_theme_headers' ) )
{
	add_filter( 'extra_theme_headers', 'handler_avia_extra_theme_headers', 10, 1 );

	/**
	 *
	 * @since 4.5.3
	 * @param array $extra_headers
	 * @return array
	 */
	function handler_avia_extra_theme_headers( array $extra_headers )
	{
		/**
		 * WP Bug 5.0.2: uses array_combine and makes keys = values
		 * This does not allow us to use a different key
		 */
		$extra_headers[] = 'Envato_ID';
		return $extra_headers;
	}
}

// get themedata version wp 3.4+
if( function_exists( 'wp_get_theme' ) )
{
	$wp_theme_obj = wp_get_theme();
	$avia_base_data['prefix'] = $avia_base_data['Title'] = $wp_theme_obj->get( 'Name' );
}

// get themedata lower versions
if( ! isset( $avia_base_data['Title'] ) )
{
	$avia_base_data = get_theme_data( AVIA_BASE . 'style.css' );
	$avia_base_data['prefix'] = $avia_base_data['Title'];
}

/*if we use a beta build remove the beta string so the theme saves all options for the actual release- beta builds use an _av_beta string at the end of the theme name*/
$avia_base_data['prefix'] = str_replace( '_av_beta', '', $avia_base_data['prefix'] );


/**
* THEMENAME contains the Name of the currently loaded theme
*/
if( ! defined( 'THEMENAME' ) )
{
	define( 'THEMENAME', $avia_base_data['Title'] );
}


if( ! defined( 'AVIA_FW' ) )
{
	//define path constants

	/**
	* AVIA_FW contains the server path of the framework folder
	*/
	define( 'AVIA_FW', AVIA_BASE . 'framework/' );


	/**
	* AVIA_PHP contains the server path of the frameworks php folder
	*/
	define( 'AVIA_PHP', AVIA_FW . 'php/' );


	/**
	* AVIA_JS contains the server path of the frameworks javascript folder
	*/
	define( 'AVIA_JS', AVIA_FW . 'js/' );


	/**
	* AVIA_CSS contains the server path of the frameworks css folder
	*/
	define( 'AVIA_CSS', AVIA_FW . 'css/' );


	/**
	* AVIA_OPTIONS contains the server path of the theme_option_pages folder
	*/
	define( 'AVIA_OPTIONS', AVIA_BASE . 'theme_option_pages' );


	//define url constants

	/**
	* AVIA_FW_URL contains the url of the framework folder
	*/
	define( 'AVIA_FW_URL', AVIA_BASE_URL . 'framework/' );

	/**
	* AVIA_IMG_URL contains the url of the frameworks images folder
	*/
	define( 'AVIA_IMG_URL', AVIA_FW_URL . 'images/' );


	/**
	* AVIA_PHP_URL contains the url of the frameworks php folder
	*/
	define( 'AVIA_PHP_URL', AVIA_FW_URL . 'php/' );


	/**
	* AVIA_JS_URL contains the url of the frameworks javascript folder
	*/
	define( 'AVIA_JS_URL', AVIA_FW_URL . 'js/' );


	/**
	* AVIA_CSS_URL contains the url of the frameworks css folder
	*/
	define( 'AVIA_CSS_URL', AVIA_FW_URL . 'css/' );


	/**
	* AVIA_OPTIONS contains the url of the theme_option_pages folder
	*/
	define( 'AVIA_OPTIONS_URL', AVIA_BASE_URL . 'theme_option_pages' );
}



//file includes

/**
 * This file holds the base class that supports fallback to former public properites
 */
require( AVIA_PHP . 'base-classes/class-object-properties.php' );

/**
 * This file holds the class that supports accessibility support
 */
require( AVIA_PHP . 'class-accessibility.php' );

/**
 * This file holds the class that supports svg images
 */
require( AVIA_PHP . 'class-svg-images.php' );

/**
 * This file holds the class that supports CPT's - added with support for ACF plugin
 */
if( ! current_theme_supports( 'avia_disable_cpt_support' ) )
{
	require( AVIA_PHP . 'class-cpt-support.php' );
}

/**
 * This file holds the class that supports responsive images
 */
require( AVIA_PHP . 'class-responsive-images.php' );

/**
* This file holds a function set for commonly used operations done by the frameworks frontend
*/
require( AVIA_PHP . 'function-set-avia-frontend.php' );

/**
* This file holds the class that improves the menu with megamenu capabilities
*/
require( AVIA_PHP . 'class-megamenu.php' );

/**
* This file holds the class that creates various styles for the frontend that are set within the backend
*/
require( AVIA_PHP . 'class-style-generator.php' );

/**
* This file holds the class that creates forms based on option arrays
*/
require( AVIA_PHP . 'class-form-generator.php' );

/**
* The google maps api source and key check (backend)
*/
require( AVIA_PHP . 'class-gmaps.php' );

/**
* The google reCAPTCHA api source
*/
require( AVIA_PHP . 'class-grecaptcha.php' );

/**
* The Cloudflare Turnstile api source
*/
require( AVIA_PHP . 'class-turnstile.php' );

/**
 * This file holds the class that manages framework specific widgets
 *
 * @since 4.9 - prior logic with all widgets in one file was removed
 */
require( AVIA_PHP . 'widgets/class-widget-loader.php' );

/**
 * Support for breadcrumbs
 */
require( AVIA_PHP . 'class-breadcrumb-trail.php' );

/**
* This file loads the classs necessary for dynamic sidebars
*/
require( AVIA_PHP . 'class-sidebar-generator.php' );

/**
 * These files load the classes necessary to manage type fonts (and icon fonts in future releases)
 */
require( AVIA_PHP . 'font-management/class-avia-font-management-base.php' );
require( AVIA_PHP . 'font-management/class-avia-type-fonts.php' );
//require( AVIA_PHP . 'font-management/class-avia-icon-fonts.php' );


/**
 * Handles update of theme options, ....  Must be loaded in frontend also, otherwise layout may be broken !!!
 */
require( AVIA_PHP . 'auto-updates/class-avia-theme-data-updater.php' );

if( ! function_exists( 'avia_fw_load_backend_files' ) )
{
	/**
	 * Load php scripts only needed in backend for the framework
	 * As REST API also might need backend functions e.g. in Widget Block Editor we
	 * use this function because REST API is initialised later
	 *
	 * @since 4.8.9
	 */
	function avia_fw_load_backend_files()
	{
		//	check if this function is already done
		if( class_exists( 'avia_adminpages', false ) )
		{
			return;
		}

		/**
		 * This file holds a function set for ajax operations done by the framework
		 */
		require( AVIA_PHP . 'function-set-avia-ajax.php' );

		/**
		 * The adminpage class creates the option page menu items
		 */
		require( AVIA_PHP . 'class-adminpages.php' );

		/**
		 * The metabox class creates meta boxes for single posts, pages and other custom post types
		 */
		require( AVIA_PHP . 'class-metabox.php' );

		/**
		 * The htmlhelper class is needed to render the options defined in the config files
		 */
		require( AVIA_PHP . 'class-htmlhelper.php' );

		/**
		 * This file improves the media uploader so it can be used within the framework
		 */
		require( AVIA_PHP . 'class-media.php' );

		/**
		 * This file loads the option set class to create new backend options on the fly
		 */
		require( AVIA_PHP . 'class-database-option-sets.php' );


		if( ! current_theme_supports( 'avia-no-duplicate-post' ) )
		{
			/**
			 * This file handles duplicate post feature also for custom post types
			 */
			require( AVIA_PHP . 'class-duplicate-post.php' );
		}

		/**
		 * This file handles admin notices
		 */
		require_once( AVIA_PHP . 'class-admin-notices.php' );

		/**
		 * This file loads the option set class to create new backend options on the fly
		 */
		require( AVIA_PHP . 'wordpress-importer/avia-export-class.php' );

		/**
		 * Repairs element settings whose quotes arrived encoded as &apos; while content is imported
		 *
		 * @since 8.2
		 */
		require_once( AVIA_PHP . 'wordpress-importer/quote-repair/init.php' );

		/**
		 * These files load the classes responsible for one click theme updates from Envato and option updates
		 */
		require( AVIA_PHP . 'auto-updates/class-avia-auto-updates.php' );
	}
}

if( is_admin() )
{
	avia_fw_load_backend_files();
}
else
{
	/**
	 * Force loading of backend scripts
	 *
	 * @since 4.8.9
	 */
	add_action( 'rest_api_init', 'avia_fw_load_backend_files', 500 );
}

/**
 * wp import runs outside the backend and needs the same repair of imported content
 *
 * @since 8.2
 */
if( defined( 'WP_CLI' ) && WP_CLI )
{
	require_once( AVIA_PHP . 'wordpress-importer/quote-repair/init.php' );
}

if( ! defined( 'THEMENAMECLEAN' ) )
{
	define( 'THEMENAMECLEAN', avia_clean_string( $avia_base_data['Title'] ) );
}
