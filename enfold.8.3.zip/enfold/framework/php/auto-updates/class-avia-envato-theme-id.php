<?php
/**
 * Reads a theme's Envato_ID header straight from its style.css.
 *
 * Asking the theme object ( $theme->get( 'Envato_ID' ) ) is not reliable: the header is
 * registered with the 'extra_theme_headers' filter when the theme loads, and since
 * WordPress 6.8 the active theme and its parent are built - and their headers cached for
 * the request - just before that. Every later theme object then answers false, the theme
 * never becomes an update candidate, and the update page reports "latest version".
 *
 * @since 8.3
 */
if( ! defined( 'ABSPATH' ) ) { exit; }		// Exit if accessed directly

if( ! class_exists( 'Avia_Envato_Theme_Id', false ) )
{
	class Avia_Envato_Theme_Id
	{
		/**
		 * The Envato_ID header of the theme in that folder, '' when it has none.
		 *
		 * @since 8.3
		 * @param string $theme_directory		absolute path of the theme folder, holding style.css
		 * @return string
		 */
		static public function of_directory( $theme_directory )
		{
			$header = get_file_data( trailingslashit( $theme_directory ) . 'style.css', array( 'id' => 'Envato_ID' ), 'theme' );

			return trim( (string) $header['id'] );
		}
	}
}
