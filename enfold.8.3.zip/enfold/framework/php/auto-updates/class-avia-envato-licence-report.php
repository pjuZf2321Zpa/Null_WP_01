<?php
/**
 * License enforcement preparations.
 * 
 * Prepares us for a future were the envato marketplace closes or we need to leave it
 * because of further price cuts and we need to  run our own update server, because we
 * now already earn less than 50% of our own theme sale:
 * https://author.envato.com/hub/changes-to-envato-market-revenue-share-and-exclusivity-what-you-need-to-know/
 *
 * @since 8.2
 */

if( ! defined( 'ABSPATH' ) ) { exit; }		// Exit if accessed directly


if( ! class_exists( 'Avia_Envato_Licence_Report', false ) )
{
	class Avia_Envato_Licence_Report
	{
		/**
		 * The last answer, so a report does not cost an Envato request
		 */
		const OPTION = 'avia_envato_licence_report';

		const REFRESH_AFTER = 30 * DAY_IN_SECONDS;

		const RETRY_AFTER = 10 * DAY_IN_SECONDS;

		/**
		 * Envato does not document its page size, so paging stops on an empty page or on
		 * a page with nothing new - this is only the backstop for an API that ignores
		 * the page parameter and keeps answering with page one.
		 */
		const MAX_PAGES = 10;

		/**
		 * Per request. The updater's own Envato calls allow 300 seconds, which is right
		 * for a download and wrong for a background count.
		 */
		const TIMEOUT = 10;

		const PURCHASES_URL = 'https://api.envato.com/v3/market/buyer/list-purchases?filter_by=wordpress-themes&page=';

		const USERNAME_URL = 'https://api.envato.com/v1/market/private/user/username.json';

		/**
		 * @var string
		 */
		protected $token;

		/**
		 * Our item id on ThemeForest, from the Envato_ID theme header
		 *
		 * @var string
		 */
		protected $item_id;

		/**
		 * The username Envato returned when the token was verified - saves a request
		 *
		 * @var string
		 */
		protected $known_username;

		/**
		 * @since 8.2
		 * @param string $token
		 * @param string $item_id
		 * @param string $known_username
		 */
		public function __construct( $token, $item_id, $known_username = '' )
		{
			$this->token = (string) $token;
			$this->item_id = (string) $item_id;
			$this->known_username = (string) $known_username;
		}

		/**
		 * Built from what the theme options already hold. Null when there is nothing to
		 * report: no token, a token Envato never accepted, or a SureCart key.
		 *
		 * @since 8.2
		 * @return Avia_Envato_Licence_Report|null
		 */
		static public function from_theme_options()
		{
			$token = trim( (string) avia_get_option( 'updates_envato_token' ) );
			$state = trim( (string) avia_get_option( 'updates_envato_token_state' ) );

			if( '' === $token || '' === $state )
			{
				return null;
			}

			if( ! class_exists( 'Avia_Credential_Classifier', false ) )
			{
				require_once( __DIR__ . '/class-avia-credential-classifier.php' );
			}

			if( Avia_Credential_Classifier::TYPE_SURECART === Avia_Credential_Classifier::classify( $token ) )
			{
				return null;
			}

			if( ! class_exists( 'Avia_Envato_Theme_Id', false ) )
			{
				require_once( __DIR__ . '/class-avia-envato-theme-id.php' );
			}

			$item_id = Avia_Envato_Theme_Id::of_directory( get_template_directory() );

			if( '' === $item_id )
			{
				return null;
			}

			$info = json_decode( (string) avia_get_option( 'updates_envato_info' ), true );
			$username = is_array( $info ) && isset( $info['username'] ) ? (string) $info['username'] : '';

			return new Avia_Envato_Licence_Report( $token, $item_id, $username );
		}

		/**
		 * The headers for the install report, refreshing the answer first when it is due.
		 *
		 * @since 8.2
		 * @return array
		 */
		public function headers()
		{
			$stored = get_option( self::OPTION, array() );
			$stored = is_array( $stored ) ? $stored : array();

			if( self::is_due( $stored, $this->token_key(), time() ) )
			{
				$stored = $this->refresh( $stored );
			}

			return self::headers_for( $stored, $this->token_key() );
		}

		/**
		 * @since 8.2
		 * @param array $stored
		 * @param string $token_key
		 * @param int $now
		 * @return boolean
		 */
		static public function is_due( array $stored, $token_key, $now )
		{
			//	a new token may belong to a different account - never report the old one's answer
			if( ! isset( $stored['token'] ) || $stored['token'] !== $token_key )
			{
				return true;
			}

			return $now >= ( isset( $stored['next'] ) ? (int) $stored['next'] : 0 );
		}

		/**
		 * @since 8.2
		 * @param array $stored
		 * @param string $token_key
		 * @return array
		 */
		static public function headers_for( array $stored, $token_key )
		{
			if( ! isset( $stored['token'] ) || $stored['token'] !== $token_key )
			{
				return array();
			}

			$headers = array();

			if( isset( $stored['user'] ) && preg_match( '/^[A-Za-z0-9_-]{1,64}$/D', (string) $stored['user'] ) )
			{
				$headers['X-Enfold-Envato-User'] = (string) $stored['user'];
			}

			if( isset( $stored['count'] ) && is_int( $stored['count'] ) )
			{
				$headers['X-Enfold-Licences'] = (string) min( $stored['count'], 9999 );
			}

			return $headers;
		}

		/**
		 * Adds one page of purchases to the running tally.
		 *
		 * Purchases are keyed by their purchase code, so a page the API repeats is
		 * counted once - and returning how many were new lets the caller stop there.
		 *
		 * @since 8.2
		 * @param array $results				one page of list-purchases 'results'
		 * @param string $item_id
		 * @param array $seen					purchase key => true, every item
		 * @param array $licences				purchase key => true, ours only
		 * @return int							purchases on this page not seen before
		 */
		static public function tally( array $results, $item_id, array &$seen, array &$licences )
		{
			$new = 0;

			foreach( $results as $purchase )
			{
				if( ! is_array( $purchase ) )
				{
					continue;
				}

				$id = isset( $purchase['item']['id'] ) ? (string) $purchase['item']['id'] : '';
				$code = isset( $purchase['code'] ) ? (string) $purchase['code'] : '';

				//	every purchase has a code; the fallback only keeps a malformed one from
				//	collapsing into the next
				$key = '' !== $code ? $code : $id . '|' . ( isset( $purchase['sold_at'] ) ? (string) $purchase['sold_at'] : '' );

				if( isset( $seen[ $key ] ) )
				{
					continue;
				}

				$seen[ $key ] = true;
				$new++;

				if( '' !== $id && $id === (string) $item_id )
				{
					$licences[ $key ] = true;
				}
			}

			return $new;
		}

		/**
		 * Asks Envato again. Whatever fails keeps its previous value, and a failure brings
		 * the next attempt forward to RETRY_AFTER rather than a full month.
		 *
		 * @since 8.2
		 * @param array $stored
		 * @return array
		 */
		protected function refresh( array $stored )
		{
			$count = $this->fetch_licence_count();
			$user = '' !== $this->known_username ? $this->known_username : $this->fetch_username();

			$fresh = self::merge( $stored, $this->token_key(), $user, $count, time() );

			update_option( self::OPTION, $fresh, false );

			return $fresh;
		}

		/**
		 * The new stored answer from what Envato just said.
		 *
		 * @since 8.2
		 * @param array $stored
		 * @param string $token_key
		 * @param string $user					'' when Envato did not say
		 * @param int|null $count				null when Envato could not be asked
		 * @param int $now
		 * @return array
		 */
		static public function merge( array $stored, $token_key, $user, $count, $now )
		{
			//	only an answer about the same token may stand in for a failed request
			$previous = isset( $stored['token'] ) && $stored['token'] === $token_key ? $stored : array();

			if( '' === (string) $user && isset( $previous['user'] ) )
			{
				$user = (string) $previous['user'];
			}

			$failed = ! is_int( $count );

			if( $failed )
			{
				$count = isset( $previous['count'] ) && is_int( $previous['count'] ) ? $previous['count'] : null;
			}

			return array(
						'token'	=> $token_key,
						'user'	=> (string) $user,
						'count'	=> $count,
						'next'	=> $now + ( $failed ? self::RETRY_AFTER : self::REFRESH_AFTER )
					);
		}

		/**
		 * @since 8.2
		 * @return int|null						null when Envato could not be asked
		 */
		protected function fetch_licence_count()
		{
			$seen = array();
			$licences = array();

			for( $page = 1; $page <= self::MAX_PAGES; $page++ )
			{
				$body = $this->request( self::PURCHASES_URL . $page );

				if( ! is_array( $body ) || ! isset( $body['results'] ) || ! is_array( $body['results'] ) )
				{
					return null;
				}

				if( empty( $body['results'] ) || 0 === self::tally( $body['results'], $this->item_id, $seen, $licences ) )
				{
					break;
				}
			}

			return count( $licences );
		}

		/**
		 * @since 8.2
		 * @return string
		 */
		protected function fetch_username()
		{
			$body = $this->request( self::USERNAME_URL );

			return is_array( $body ) && isset( $body['username'] ) ? (string) $body['username'] : '';
		}

		/**
		 * @since 8.2
		 * @param string $url
		 * @return array|null
		 */
		protected function request( $url )
		{
			$response = wp_remote_get( $url, array(
								'timeout'	=> self::TIMEOUT,
								'headers'	=> array( 'Authorization' => 'Bearer ' . $this->token )
							) );

			if( is_wp_error( $response ) || 200 !== (int) wp_remote_retrieve_response_code( $response ) )
			{
				return null;
			}

			$body = json_decode( (string) wp_remote_retrieve_body( $response ), true );

			return is_array( $body ) ? $body : null;
		}

		/**
		 * Recognises a changed token without keeping a second copy of it
		 *
		 * @since 8.2
		 * @return string
		 */
		protected function token_key()
		{
			return substr( hash( 'sha256', $this->token ), 0, 16 );
		}
	}
}
