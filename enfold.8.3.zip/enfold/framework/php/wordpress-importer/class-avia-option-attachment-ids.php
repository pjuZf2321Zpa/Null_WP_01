<?php
/**
 * Repoints attachment ids stored in imported theme options at the attachments this import
 * actually created.
 *
 * An upload field (logo, replacement logo, preloader logo, favicon, background images ...)
 * holds either a url or an attachment id. remap_option_urls() takes care of urls, but an id
 * was imported as it was. WordPress only keeps the demo's ids on an empty site - as soon as the
 * customer has a single post or attachment, the imported logo gets a new id and the old one
 * belongs to something else. On a site with WooCommerce active the Coffee Shop demo showed a
 * hero photo as its logo, because id 39 was the wordmark on our site and a photo on theirs.
 *
 * Works on the option definitions as the demo exported them (avia_wp_export::export_array_generator()),
 * where every value sits in 'std' next to its 'type' - so we know which values are upload fields
 * without having to rely on the option pages being registered while the import runs.
 *
 * Only an id that maps to an attachment this import created is changed. Anything else is left
 * alone: a wrong value is better than a wrong picture.
 *
 * @since 8.3
 */
if( ! defined( 'ABSPATH' ) ) { exit; }		// Exit if accessed directly

if( ! class_exists( 'Avia_Option_Attachment_Ids', false ) )
{
	class Avia_Option_Attachment_Ids
	{
		/**
		 * @since 8.3
		 * @param array $elements			exported option elements: array( id => array( 'type' => .., 'std' => .. ) )
		 * @param array $map				array( demo attachment id => attachment id on users site )
		 * @param int $replaced				incremented for every remapped value
		 * @return array
		 */
		public static function remap( array $elements, array $map, &$replaced = 0 )
		{
			if( empty( $map ) )
			{
				return $elements;
			}

			foreach( $elements as $key => $element )
			{
				if( ! is_array( $element ) || ! isset( $element['type'] ) || ! array_key_exists( 'std', $element ) )
				{
					continue;
				}

				if( 'group' == $element['type'] && is_array( $element['std'] ) )
				{
					foreach( $element['std'] as $i => $sub_elements )
					{
						if( is_array( $sub_elements ) )
						{
							$elements[ $key ]['std'][ $i ] = self::remap( $sub_elements, $map, $replaced );
						}
					}
				}
				else if( 'upload' == $element['type'] )
				{
					$demo_id = self::attachment_id( $element['std'] );

					if( $demo_id > 0 && isset( $map[ $demo_id ] ) && (int) $map[ $demo_id ] > 0 )
					{
						$elements[ $key ]['std'] = (string) (int) $map[ $demo_id ];
						$replaced ++;
					}
				}
			}

			return $elements;
		}

		/**
		 * @since 8.3
		 * @param mixed $value
		 * @return int						0 if the value is not an attachment id (a url, empty ...)
		 */
		protected static function attachment_id( $value )
		{
			if( is_int( $value ) )
			{
				return $value;
			}

			if( is_string( $value ) && '' !== trim( $value ) && ctype_digit( trim( $value ) ) )
			{
				return (int) trim( $value );
			}

			return 0;
		}
	}
}
