<?php
/**
 * Repairs shortcode attributes whose quotes arrived encoded as &apos;
 *
 * The layout builder writes every setting as name='value', and nothing in WordPress or Enfold
 * ever encodes that apostrophe - their escapers emit &#039;. When a page has been through an
 * HTML rewrite somewhere else, every one of those quotes comes back as &apos;. WordPress then
 * reads each value as the literal text &apos;4&apos;, and an element that does arithmetic on
 * a setting - the blog grid, the product slider - ends the page with a fatal error on PHP 8.
 *
 * The repair is narrow on purpose, because the one thing it must never do is change content
 * that was correct:
 *
 *   - only opening shortcode tags are looked at - prose, raw html and closing tags never are
 *   - only tags quoted with &apos; throughout - a tag that also has real quotes did not go
 *     through the same rewrite, and guessing there is how correct content gets broken
 *   - only the quotes around a value are converted, an &apos; inside a value is kept
 *   - the result has to read back as clean name='value' pairs, bare flags such as "first"
 *     included, or the tag is left exactly as it was and reported
 *
 * Checked against every post on the kriesi.at demo network: 12,722 occurrences, every one of
 * them a quote around a value, and on each affected page the repair produced the same layout
 * the builder had stored for it.
 *
 * Plain PHP without WordPress, so it can be tested on its own.
 *
 * @since 8.2
 */
if( ! defined( 'ABSPATH' ) ) { exit; }		// Exit if accessed directly

if( ! class_exists( 'Avia_Shortcode_Quote_Repair', false ) )
{
	class Avia_Shortcode_Quote_Repair
	{
		/**
		 * An opening shortcode tag. Closing tags carry no attributes and never match.
		 *
		 * @since 8.2
		 */
		const OPENING_TAG = '/\[[a-z][\w-]*(?:\s[^\]]*)?\]/i';

		/**
		 * One value quoted with &apos;. The closing &apos; has to end the value - followed by
		 * whitespace, the end of the tag or a self closing slash - so one standing inside the
		 * value stays part of it.
		 *
		 * @since 8.2
		 */
		const ENCODED_VALUE = '/([\w-]+)=&apos;(.*?)&apos;(?=[\s\]\/]|$)/s';

		/**
		 * A value with real quotes, single or double.
		 *
		 * @since 8.2
		 */
		const QUOTED_VALUE = '/[\w-]\s*=\s*[\x27\x22]/';

		/**
		 * @since 8.2
		 * @param string $text
		 * @return array			'text'		=> the repaired text
		 *							'repaired'	=> number of values whose quotes were converted
		 *							'refused'	=> tags quoted with &apos; that were left unchanged
		 */
		public function repair( $text )
		{
			$text = (string) $text;
			$repaired = 0;
			$refused = array();

			if( false !== strpos( $text, '=&apos;' ) )
			{
				$result = preg_replace_callback( self::OPENING_TAG, function( $match ) use ( &$repaired, &$refused )
				{
					return $this->repair_tag( $match[0], $repaired, $refused );
				}, $text );

				//	null on a regex failure, e.g. the backtrack limit on an enormous page - keep the original then
				if( null !== $result )
				{
					$text = $result;
				}
			}

			return array(
						'text'		=> $text,
						'repaired'	=> $repaired,
						'refused'	=> $refused
					);
		}

		/**
		 * @since 8.2
		 * @param string $tag
		 * @param int $repaired
		 * @param array $refused
		 * @return string
		 */
		protected function repair_tag( $tag, &$repaired, array &$refused )
		{
			if( false === strpos( $tag, '=&apos;' ) )
			{
				return $tag;
			}

			if( preg_match( self::QUOTED_VALUE, $tag ) )
			{
				$refused[] = $tag;
				return $tag;
			}

			$count = 0;
			$fixed = preg_replace( self::ENCODED_VALUE, '$1=\'$2\'', $tag, -1, $count );

			if( null === $fixed || ! $this->is_clean_tag( $fixed ) )
			{
				$refused[] = $tag;
				return $tag;
			}

			$repaired += $count;

			return $fixed;
		}

		/**
		 * True when nothing is left of a tag but its name, name='value' pairs and bare flags.
		 *
		 * @since 8.2
		 * @param string $tag
		 * @return boolean
		 */
		protected function is_clean_tag( $tag )
		{
			$rest = preg_replace( '/^\[[a-z][\w-]*|\/?\]$/i', '', $tag );
			$rest = preg_replace( '/[\w-]+=\x27[^\x27]*\x27/', '', $rest );
			$rest = preg_replace( '/[\w-]+/', '', $rest );

			return '' === trim( $rest );
		}
	}
}
