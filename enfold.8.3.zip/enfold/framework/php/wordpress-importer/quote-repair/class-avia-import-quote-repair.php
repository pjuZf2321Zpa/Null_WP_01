<?php
/**
 * Runs the &apos; quote repair on content while it is imported, and says so.
 *
 * Both import routes land here. The theme's demo import and the WordPress Importer plugin fire
 * the same filter for every item before it is written, and the item's post meta travels in the
 * same array - which matters, because the layout builder keeps its own copy of a page in meta.
 *
 * An item is looked at twice, because it can arrive broken and it can be broken on the way in:
 *
 *		- as the export file holds it, before the importer touches anything;
 *		- and again right before it is written, because the WordPress Importer 0.9 offers to
 *		  rewrite the urls of the site the export came from, ticked by default, and that rewrite
 *		  sends the content through an html parser which re-encodes every apostrophe in it. A
 *		  page that came out of the export intact is then written with every element setting
 *		  quoted with &apos;. Only content and excerpt pass that rewrite - post meta does not,
 *		  which is why a page hit by it renders from its builder copy while the editor fails.
 *
 * Every repair is logged, naming which of the two it was. A silent fix would hide that the
 * export, and the site it came from, still hold the broken version and will hand it to the next
 * import too - or that the importer is quietly rewriting shortcodes on every import. So each
 * repaired item and each tag left alone is named in the PHP error log, and the WordPress
 * Importer's result page gets a summary. The demo import shows nothing extra on screen: it reads
 * the importer's own output to decide whether the import worked, and added text there would turn
 * a clean import into a reported error.
 *
 * @since 8.2
 */
if( ! defined( 'ABSPATH' ) ) { exit; }		// Exit if accessed directly

if( ! class_exists( 'Avia_Import_Quote_Repair', false ) )
{
	class Avia_Import_Quote_Repair
	{
		/**
		 * The item already carried the encoded quotes when the importer read it.
		 *
		 * @since 8.2
		 * @var string
		 */
		const CAME_FROM_EXPORT = 'export';

		/**
		 * The importer encoded the quotes itself, while rewriting urls.
		 *
		 * @since 8.2
		 * @var string
		 */
		const CAME_FROM_IMPORT = 'import';

		/**
		 * @since 8.2
		 * @var Avia_Shortcode_Quote_Repair
		 */
		protected $repairer;

		/**
		 * Receives one message per call - error_log, unless a test hands in something else.
		 *
		 * @since 8.2
		 * @var callable
		 */
		protected $logger;

		/**
		 * What this request's import repaired so far.
		 *
		 * @since 8.2
		 * @var array
		 */
		protected $totals = array(
						'items'		=> 0,
						'repaired'	=> 0,
						'refused'	=> 0
					);

		/**
		 * @since 8.2
		 * @param Avia_Shortcode_Quote_Repair|null $repairer
		 * @param callable|null $logger
		 */
		public function __construct( $repairer = null, $logger = null )
		{
			$this->repairer = $repairer instanceof Avia_Shortcode_Quote_Repair ? $repairer : new Avia_Shortcode_Quote_Repair();
			$this->logger = is_callable( $logger ) ? $logger : 'error_log';
		}

		/**
		 * @since 8.2
		 */
		public function register()
		{
			add_filter( 'wp_import_post_data_raw', array( $this, 'handler_wp_import_post_data_raw' ), 5, 1 );
			add_filter( 'wp_import_post_data_processed', array( $this, 'handler_wp_import_post_data_processed' ), 5, 2 );
			add_action( 'import_end', array( $this, 'handler_import_end' ), 10 );
		}

		/**
		 * @since 8.2
		 * @param array $post			one item as the importer read it from the export file
		 * @return array
		 */
		public function handler_wp_import_post_data_raw( $post )
		{
			/**
			 * Switch the repair off - for every item, or for one.
			 *
			 * @since 8.2
			 * @param boolean $repair
			 * @param array $post
			 * @return boolean
			 */
			if( ! is_array( $post ) || ! apply_filters( 'avf_import_repair_encoded_quotes', true, $post ) )
			{
				return $post;
			}

			$report = $this->new_report();

			$post = $this->repair_fields( $post, $report );
			$post = $this->repair_meta( $post, $report );

			if( $this->has_findings( $report ) )
			{
				$this->record( $post, $report, self::CAME_FROM_EXPORT );
			}

			return $post;
		}

		/**
		 * Second look, on the data the importer is about to write.
		 *
		 * Everything the first pass repaired is long done here - this one is about content the
		 * importer itself re-encoded in between, while rewriting the urls of the site the export
		 * came from. Post meta is not part of $postdata and needs no second look: the rewrite
		 * never sees it.
		 *
		 * @since 8.2
		 * @param array $postdata		the data the importer is about to insert
		 * @param array $post			the item as it was read from the export file
		 * @return array
		 */
		public function handler_wp_import_post_data_processed( $postdata, $post = array() )
		{
			/**
			 * Switch the repair off - for every item, or for one.
			 *
			 * @since 8.2
			 * @param boolean $repair
			 * @param array $post
			 * @return boolean
			 */
			if( ! is_array( $postdata ) || ! apply_filters( 'avf_import_repair_encoded_quotes', true, $post ) )
			{
				return $postdata;
			}

			$report = $this->new_report();

			$postdata = $this->repair_fields( $postdata, $report );

			if( $this->has_findings( $report ) )
			{
				$this->record( is_array( $post ) && ! empty( $post ) ? $post : $postdata, $report, self::CAME_FROM_IMPORT );
			}

			return $postdata;
		}

		/**
		 * Summary on the WordPress Importer's result page.
		 *
		 * @since 8.2
		 */
		public function handler_import_end()
		{
			if( 0 === $this->totals['items'] || ! $this->is_importer_plugin_screen() )
			{
				return;
			}

			if( $this->totals['repaired'] > 0 )
			{
				$msg = __( 'Enfold repaired %1$s element settings in %2$s imported items whose quotes were encoded as &apos;. Each item is listed in the PHP error log, with what encoded them.', 'avia_framework' );
				echo '<p>' . esc_html( sprintf( $msg, number_format_i18n( $this->totals['repaired'] ), number_format_i18n( $this->totals['items'] ) ) ) . '</p>';
			}

			if( $this->totals['refused'] > 0 )
			{
				$msg = __( '%s shortcodes quoted with &apos; could not be repaired safely and were imported unchanged. The pages holding them will show an error until they are fixed by hand - the PHP error log names each one.', 'avia_framework' );
				echo '<p><strong>' . esc_html( sprintf( $msg, number_format_i18n( $this->totals['refused'] ) ) ) . '</strong></p>';
			}
		}

		/**
		 * @since 8.2
		 * @return array
		 */
		public function get_totals()
		{
			return $this->totals;
		}

		/**
		 * @since 8.2
		 * @return array
		 */
		protected function new_report()
		{
			return array(
						'repaired'	=> 0,
						'refused'	=> array()
					);
		}

		/**
		 * @since 8.2
		 * @param array $report
		 * @return boolean
		 */
		protected function has_findings( array $report )
		{
			return $report['repaired'] > 0 || ! empty( $report['refused'] );
		}

		/**
		 * @since 8.2
		 * @param array $post
		 * @param array $report
		 * @return array
		 */
		protected function repair_fields( array $post, array &$report )
		{
			foreach( array( 'post_content', 'post_excerpt' ) as $field )
			{
				if( isset( $post[ $field ] ) && is_string( $post[ $field ] ) )
				{
					$post[ $field ] = $this->repair_text( $post[ $field ], $report );
				}
			}

			return $post;
		}

		/**
		 * @since 8.2
		 * @param array $post
		 * @param array $report
		 * @return array
		 */
		protected function repair_meta( array $post, array &$report )
		{
			if( empty( $post['postmeta'] ) || ! is_array( $post['postmeta'] ) )
			{
				return $post;
			}

			foreach( $post['postmeta'] as $index => $meta )
			{
				//	a serialized value records the length of every string in it - editing inside would corrupt it
				if( ! isset( $meta['value'] ) || ! is_string( $meta['value'] ) || $this->is_serialized_value( $meta['value'] ) )
				{
					continue;
				}

				$post['postmeta'][ $index ]['value'] = $this->repair_text( $meta['value'], $report );
			}

			return $post;
		}

		/**
		 * @since 8.2
		 * @param string $text
		 * @param array $report
		 * @return string
		 */
		protected function repair_text( $text, array &$report )
		{
			$result = $this->repairer->repair( $text );

			$report['repaired'] += $result['repaired'];
			$report['refused'] = array_merge( $report['refused'], $result['refused'] );

			return $result['text'];
		}

		/**
		 * @since 8.2
		 * @param array $post
		 * @param array $report
		 * @param string $came_from		one of the CAME_FROM_ constants
		 */
		protected function record( array $post, array $report, $came_from = self::CAME_FROM_EXPORT )
		{
			$this->totals['items']++;
			$this->totals['repaired'] += $report['repaired'];
			$this->totals['refused'] += count( $report['refused'] );

			$item = sprintf( '%s "%s" (id %s in the export)',
							isset( $post['post_type'] ) ? $post['post_type'] : 'item',
							isset( $post['post_title'] ) ? $post['post_title'] : '',
							isset( $post['post_id'] ) ? $post['post_id'] : '?'
						);

			if( $report['repaired'] > 0 )
			{
				$this->log( sprintf( $this->repair_message( $came_from ), $report['repaired'], $item ) );
			}

			if( ! empty( $report['refused'] ) )
			{
				$this->log( sprintf( 'Enfold import: left %d shortcodes quoted with &apos; unchanged in %s because they could not be repaired safely - the page will show an error until they are fixed by hand. First one: %s', count( $report['refused'] ), $item, substr( $report['refused'][0], 0, 300 ) ) );
			}
		}

		/**
		 * Says who encoded the quotes, because the two call for different action: a broken export
		 * keeps handing the broken version to the next import, while the importer's url rewrite
		 * breaks a healthy export on every run until it is switched off.
		 *
		 * @since 8.2
		 * @param string $came_from		one of the CAME_FROM_ constants
		 * @return string
		 */
		protected function repair_message( $came_from )
		{
			if( self::CAME_FROM_IMPORT === $came_from )
			{
				return 'Enfold import: repaired %1$d element settings in %2$s that the WordPress Importer had encoded as &apos; itself while rewriting urls. The export file is not at fault - untick "rewrite urls" on the import screen to avoid it, or import with WP-CLI, which never rewrites.';
			}

			return 'Enfold import: repaired %1$d element settings in %2$s whose quotes had arrived encoded as &apos;. The export file, and the site it came from, still hold the broken version.';
		}

		/**
		 * @since 8.2
		 * @param string $message
		 */
		protected function log( $message )
		{
			call_user_func( $this->logger, $message );
		}

		/**
		 * @since 8.2
		 * @param string $value
		 * @return boolean
		 */
		protected function is_serialized_value( $value )
		{
			return is_serialized( $value );
		}

		/**
		 * @since 8.2
		 * @return boolean
		 */
		protected function is_importer_plugin_screen()
		{
			return ! wp_doing_ajax() && isset( $_GET['import'] ) && 'wordpress' === $_GET['import'];
		}
	}
}
