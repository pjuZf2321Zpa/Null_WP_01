<?php
/**
 * Loads the repair of element settings whose quotes arrived encoded as &apos;, and hooks it
 * into every import. Kept apart from the classes so they can be loaded under test without
 * registering anything.
 *
 * @since 8.2
 */
if( ! defined( 'ABSPATH' ) ) { exit; }		// Exit if accessed directly

require_once __DIR__ . '/class-avia-shortcode-quote-repair.php';
require_once __DIR__ . '/class-avia-import-quote-repair.php';

if( ! function_exists( 'avia_import_quote_repair' ) )
{
	/**
	 * @since 8.2
	 * @return Avia_Import_Quote_Repair
	 */
	function avia_import_quote_repair()
	{
		static $instance = null;

		if( null === $instance )
		{
			$instance = new Avia_Import_Quote_Repair();
			$instance->register();
		}

		return $instance;
	}

	avia_import_quote_repair();
}
