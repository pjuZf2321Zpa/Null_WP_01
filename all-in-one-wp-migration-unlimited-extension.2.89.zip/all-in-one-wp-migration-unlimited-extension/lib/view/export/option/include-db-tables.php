<?php
/**
 * Copyright (C) 2014-2025 ServMask Inc.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * Attribution: This code is part of the All-in-One WP Migration plugin, developed by
 *
 * ███████╗███████╗██████╗ ██╗   ██╗███╗   ███╗ █████╗ ███████╗██╗  ██╗
 * ██╔════╝██╔════╝██╔══██╗██║   ██║████╗ ████║██╔══██╗██╔════╝██║ ██╔╝
 * ███████╗█████╗  ██████╔╝██║   ██║██╔████╔██║███████║███████╗█████╔╝
 * ╚════██║██╔══╝  ██╔══██╗╚██╗ ██╔╝██║╚██╔╝██║██╔══██║╚════██║██╔═██╗
 * ███████║███████╗██║  ██║ ╚████╔╝ ██║ ╚═╝ ██║██║  ██║███████║██║  ██╗
 * ╚══════╝╚══════╝╚═╝  ╚═╝  ╚═══╝  ╚═╝     ╚═╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Kangaroos cannot jump here' );
}
?>

<li>
	<?php if ( ! empty( $tables ) ) : ?>
		<label for="ai1wmue-include-db-tables" v-show="showDbTablesIncluder">
			<input type="checkbox" id="ai1wmue-include-db-tables" name="options[include_db_tables]" />
			<?php esc_html_e( 'Include the selected non‑WP tables', AI1WMUE_PLUGIN_NAME ); ?>
			<small style="color: red;"><?php esc_html_e( 'new', AI1WMUE_PLUGIN_NAME ); ?></small>
		</label>
		<db-tables-includer v-show="showDbTablesIncluder" :db-tables='<?php echo json_encode( $tables, JSON_HEX_APOS ); ?>' label-id="#ai1wmue-include-db-tables" field-name="included_db_tables" />
	<?php endif; ?>
</li>
