<?php
/**
 * UAEL GfStyler Module.
 *
 * @package UAEL
 */

namespace UltimateElementor\Modules\GfStyler;

use Elementor\Plugin;
use UltimateElementor\Base\Module_Base;
use UltimateElementor\Classes\UAEL_Helper;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Class Module.
 */
class Module extends Module_Base {

	/**
	 * Settings keys that hold a saved Elementor template ID across UAE widgets.
	 *
	 * @since 1.45.5
	 * @var array
	 */
	const SAVED_TEMPLATE_KEYS = array(
		'ct_saved_rows',
		'ct_saved_container',
		'ct_saved_modules',
		'ct_page_templates',
		'content_saved_rows',
		'content_saved_widgets',
		'content_saved_container',
		'section_saved_rows_1',
		'section_saved_container_1',
		'section_saved_pages_1',
		'section_saved_rows_2',
		'section_saved_container_2',
		'section_saved_pages_2',
	);

	/**
	 * How deep saved templates embedded inside saved templates are followed.
	 *
	 * @since 1.45.5
	 * @var int
	 */
	const MAX_TEMPLATE_DEPTH = 3;

	/**
	 * Module should load or not.
	 *
	 * @since 0.0.1
	 * @access public
	 *
	 * @return bool true|false.
	 */
	public static function is_enable() {
		if ( class_exists( 'GFForms' ) ) {
			return true;
		}
		return false;
	}

	/**
	 * Get Module Name.
	 *
	 * @since 0.0.1
	 * @access public
	 *
	 * @return string Module name.
	 */
	public function get_name() {
		return 'uael-gf-styler';
	}

	/**
	 * Get Widgets.
	 *
	 * @since 0.0.1
	 * @access public
	 *
	 * @return array Widgets.
	 */
	public function get_widgets() {
		return array(
			'GfStyler',
		);
	}

	/**
	 * Constructor.
	 */
	public function __construct() {
		parent::__construct();
		if ( ! wp_script_is( 'jquery', 'enqueued' ) ) {
			wp_enqueue_script( 'jquery' );
		}
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_gravity_form_scripts' ) );
	}

	/**
	 * Enqueue Gravity Forms assets early for forms rendered by the GF Styler widget.
	 *
	 * Gravity Forms outputs its JS hooks bootstrap (gform.addAction / addFilter / doAction) only when
	 * its main script is already enqueued by the time `wp_enqueue_scripts` finishes. Gravity Forms
	 * finds shortcodes in the post content itself, but the widget renders the form with do_shortcode()
	 * during the_content, which is too late. Its late-render fallbacks are skipped when a caching or
	 * optimisation plugin replaces the shortcode with an AJAX placeholder (NitroPack, for example),
	 * leaving `gform.addAction` undefined and the form hidden. Enqueueing here mirrors what Gravity
	 * Forms does for shortcodes embedded directly in the post content.
	 *
	 * @since 1.45.5
	 * @access public
	 *
	 * @return void
	 */
	public function enqueue_gravity_form_scripts() {
		if ( is_admin() || ! function_exists( 'gravity_form_enqueue_scripts' ) || ! class_exists( '\Elementor\Plugin' ) ) {
			return;
		}

		$forms   = array();
		$scanned = array();

		foreach ( $this->get_candidate_post_ids() as $post_id ) {
			$this->collect_forms_from_post( $post_id, $forms, $scanned, 0 );
		}

		foreach ( $forms as $form_id => $ajax ) {
			gravity_form_enqueue_scripts( $form_id, $ajax );
		}
	}

	/**
	 * Post IDs that can render a GF Styler widget on this request.
	 *
	 * Covers the queried posts, the Elementor Theme Builder documents whose display conditions match
	 * this request (headers, footers, singles, archives and popups all register as locations), and the
	 * Header Footer Elementor templates active for this request. Each source resolves by the same
	 * conditions the renderer uses, so no template is scanned on a page where it will not appear.
	 *
	 * @since 1.45.5
	 * @access private
	 *
	 * @return array Unique post IDs.
	 */
	private function get_candidate_post_ids() {
		global $wp_query;

		$post_ids = array();

		if ( $wp_query instanceof \WP_Query && ! empty( $wp_query->posts ) && is_array( $wp_query->posts ) ) {
			foreach ( $wp_query->posts as $post ) {
				if ( $post instanceof \WP_Post ) {
					$post_ids[] = $post->ID;
				} elseif ( is_numeric( $post ) ) {
					$post_ids[] = absint( $post );
				}
			}
		}

		$post_ids = array_merge( $post_ids, $this->get_theme_builder_post_ids(), $this->get_hfe_post_ids() );

		return array_unique( array_filter( $post_ids ) );
	}

	/**
	 * Elementor Theme Builder documents matching this request, across every registered location.
	 *
	 * @since 1.45.5
	 * @access private
	 *
	 * @return array Post IDs.
	 */
	private function get_theme_builder_post_ids() {
		if ( ! class_exists( '\ElementorPro\Plugin' ) ) {
			return array();
		}

		$pro_plugin = \ElementorPro\Plugin::instance();

		if ( ! isset( $pro_plugin->modules_manager ) ) {
			return array();
		}

		$theme_builder = $pro_plugin->modules_manager->get_modules( 'theme-builder' );

		if ( ! $theme_builder || ! method_exists( $theme_builder, 'get_locations_manager' ) || ! method_exists( $theme_builder, 'get_conditions_manager' ) ) {
			return array();
		}

		$locations = $theme_builder->get_locations_manager()->get_locations();

		if ( empty( $locations ) || ! is_array( $locations ) ) {
			return array();
		}

		$post_ids = array();

		foreach ( array_keys( $locations ) as $location ) {
			$documents = $theme_builder->get_conditions_manager()->get_documents_for_location( $location );

			if ( empty( $documents ) || ! is_array( $documents ) ) {
				continue;
			}

			$post_ids = array_merge( $post_ids, array_keys( $documents ) );
		}

		return $post_ids;
	}

	/**
	 * Header Footer Elementor templates active for this request.
	 *
	 * @since 1.45.5
	 * @access private
	 *
	 * @return array Post IDs.
	 */
	private function get_hfe_post_ids() {
		if ( ! class_exists( '\Header_Footer_Elementor' ) || ! method_exists( '\Header_Footer_Elementor', 'get_settings' ) ) {
			return array();
		}

		$post_ids = array();

		foreach ( array( 'type_header', 'type_footer', 'type_before_footer' ) as $type ) {
			$template_id = \Header_Footer_Elementor::get_settings( $type, '' );

			if ( ! empty( $template_id ) ) {
				$post_ids[] = absint( $template_id );
			}
		}

		return $post_ids;
	}

	/**
	 * Walk one post's Elementor data and collect the Gravity Forms it renders through GF Styler.
	 *
	 * Recurses into saved Sections, Containers, Widgets and Page templates embedded by other UAE
	 * widgets (Nav Menu mega menu, Modal Popup, FAQ, Offcanvas, Content Toggle), because a form
	 * inside one of those is never part of the parent post's own element tree.
	 *
	 * @since 1.45.5
	 * @access private
	 *
	 * @param int   $post_id Post to scan.
	 * @param array $forms   Collected form IDs, keyed by ID with the AJAX flag as value. Passed by reference.
	 * @param array $scanned Already scanned post IDs, guarding against repeat work and reference loops. Passed by reference.
	 * @param int   $depth   Current recursion depth.
	 * @return void
	 */
	private function collect_forms_from_post( $post_id, &$forms, &$scanned, $depth ) {
		$post_id = absint( $post_id );

		if ( ! $post_id || $depth > self::MAX_TEMPLATE_DEPTH || isset( $scanned[ $post_id ] ) ) {
			return;
		}

		$scanned[ $post_id ] = true;

		// Cheap pre-check on the raw meta so archives full of Elementor posts don't decode every document.
		// Global widgets store "global" as the type, and saved-content keys mark a template worth following.
		$raw_data = get_post_meta( $post_id, '_elementor_data', true );

		if ( ! is_string( $raw_data ) || '' === $raw_data ) {
			return;
		}

		$markers = array_merge( array( 'uael-gf-styler', '"widgetType":"global"' ), self::SAVED_TEMPLATE_KEYS );
		$found   = false;

		foreach ( $markers as $marker ) {
			if ( false !== strpos( $raw_data, $marker ) ) {
				$found = true;
				break;
			}
		}

		if ( ! $found ) {
			return;
		}

		$document = Plugin::$instance->documents->get( $post_id );

		if ( ! $document || ! $document->is_built_with_elementor() ) {
			return;
		}

		$data = $document->get_elements_data();

		if ( empty( $data ) || ! is_array( $data ) ) {
			return;
		}

		$nested = array();

		Plugin::$instance->db->iterate_data(
			$data,
			function ( $element ) use ( &$forms, &$nested ) {
				$settings = ( isset( $element['settings'] ) && is_array( $element['settings'] ) ) ? $element['settings'] : array();

				if ( 'uael-gf-styler' === UAEL_Helper::get_widget_type( $element ) ) {
					// A global widget keeps its real settings on the template post, not on the instance.
					if ( isset( $element['widgetType'] ) && 'global' === $element['widgetType'] && ! empty( $element['templateID'] ) ) {
						$settings = $this->get_global_widget_settings( $element['templateID'] );
					}

					$form_id = isset( $settings['form_id'] ) ? absint( $settings['form_id'] ) : 0;

					if ( $form_id ) {
						// Same test as the widget template, which only passes ajax="true" for the saved switcher value.
						$ajax              = isset( $settings['form_ajax_option'] ) && 'yes' === $settings['form_ajax_option'];
						$forms[ $form_id ] = ! empty( $forms[ $form_id ] ) || $ajax;
					}
				}

				$nested = array_merge( $nested, $this->get_nested_template_ids( $settings ) );

				return $element;
			}
		);

		foreach ( array_unique( $nested ) as $nested_id ) {
			$this->collect_forms_from_post( $nested_id, $forms, $scanned, $depth + 1 );
		}
	}

	/**
	 * Resolve a global widget's stored settings from its template post.
	 *
	 * @since 1.45.5
	 * @access private
	 *
	 * @param int|string $template_id Global template ID.
	 * @return array Settings array, empty when the template cannot be resolved.
	 */
	private function get_global_widget_settings( $template_id ) {
		$template_data = Plugin::$instance->templates_manager->get_template_data(
			array(
				'source'      => 'local',
				'template_id' => $template_id,
			)
		);

		if ( is_wp_error( $template_data ) || empty( $template_data['content'][0]['settings'] ) || ! is_array( $template_data['content'][0]['settings'] ) ) {
			return array();
		}

		return $template_data['content'][0]['settings'];
	}

	/**
	 * Pull saved-template IDs out of one element's settings, including repeater rows.
	 *
	 * The IDs are run through `wpml_object_id` so the translated template is scanned on multilingual
	 * sites, matching what the widgets themselves render.
	 *
	 * @since 1.45.5
	 * @access private
	 *
	 * @param array $settings Element settings.
	 * @return array Template post IDs.
	 */
	private function get_nested_template_ids( $settings ) {
		if ( empty( $settings ) || ! is_array( $settings ) ) {
			return array();
		}

		$template_ids = array();

		foreach ( $settings as $key => $value ) {
			if ( is_array( $value ) ) {
				// Repeater rows, for example the FAQ, Nav Menu and Content Toggle item lists.
				foreach ( $value as $row ) {
					if ( is_array( $row ) ) {
						$template_ids = array_merge( $template_ids, $this->get_nested_template_ids( $row ) );
					}
				}
				continue;
			}

			if ( in_array( $key, self::SAVED_TEMPLATE_KEYS, true ) && ! empty( $value ) && is_numeric( $value ) ) {
				$template_ids[] = absint( apply_filters( 'wpml_object_id', absint( $value ), 'elementor_library', true ) );
			}
		}

		return $template_ids;
	}
}
