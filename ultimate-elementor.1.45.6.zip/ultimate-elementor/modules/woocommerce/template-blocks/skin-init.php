<?php
/**
 * UAEL Skin Init.
 *
 * @package UAEL
 */

namespace UltimateElementor\Modules\Woocommerce\TemplateBlocks;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Class Skin_Init
 */
class Skin_Init {

	/**
	 * Member Variable
	 *
	 * @var instance
	 */
	private static $skin_instance;

	/**
	 * Initiator
	 *
	 * @param string $style Skin.
	 * @return object|null Skin instance, or null for an unknown skin.
	 */
	public static function get_instance( $style ) {

		$style_arr = explode( '-', $style );

		$style = implode( '_', array_map( 'ucfirst', $style_arr ) );

		$skin_class = 'UltimateElementor\\Modules\\Woocommerce\\TemplateBlocks\\Skin_' . ucfirst( $style );

		if ( class_exists( $skin_class ) ) {

			self::$skin_instance[ $style ] = new $skin_class( $style );
		}

		// The skin can come from an AJAX request; avoid an undefined index notice in the JSON response.
		return isset( self::$skin_instance[ $style ] ) ? self::$skin_instance[ $style ] : null;
	}
}
