<?php
/**
 * UAEL Common Widget.
 *
 * @package UAEL
 */

namespace UltimateElementor\Base;

use Elementor\Widget_Base;
use UltimateElementor\Classes\UAEL_Helper;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Common Widget
 *
 * @since 0.0.1
 */
abstract class Common_Widget extends Widget_Base {

	/**
	 * Get categories
	 *
	 * @since 0.0.1
	 */
	public function get_categories() {
		return array( 'ultimate-elements' );
	}

	/**
	 * Get widget slug
	 *
	 * @param string $slug Module slug.
	 * @since 0.0.1
	 */
	public function get_widget_slug( $slug = '' ) {
		return UAEL_Helper::get_widget_slug( $slug );
	}

	/**
	 * Get widget title
	 *
	 * @param string $slug Module slug.
	 * @since 0.0.1
	 */
	public function get_widget_title( $slug = '' ) {
		return UAEL_Helper::get_widget_title( $slug );
	}

	/**
	 * Get widget icon
	 *
	 * @param string $slug Module slug.
	 * @since 0.0.1
	 */
	public function get_widget_icon( $slug = '' ) {
		return UAEL_Helper::get_widget_icon( $slug );
	}

	/**
	 * Get widget keywords
	 *
	 * @param string $slug Module slug.
	 * @since 1.5.1
	 */
	public function get_widget_keywords( $slug = '' ) {
		return UAEL_Helper::get_widget_keywords( $slug );
	}

	/**
	 * Is internal link
	 *
	 * @since 1.0.0
	 */
	public function is_internal_links() {
		return UAEL_Helper::is_internal_links();
	}

	/**
	 * Presets control
	 *
	 * @param string $slug Widget slug.
	 * @param string $widget Widget name.
	 * @since 1.33.0
	 */
	public function register_presets_control( $slug, $widget ) {

		if ( UAEL_Helper::is_widget_active( 'Presets' ) ) {

			$options       = array();
			$options['']   = __( 'Default', 'uael' );
			$presets_count = UAEL_Helper::get_widget_presets( $slug );

			for ( $i = 1; $i <= $presets_count; $i++ ) {
				// translators: %d Preset number.
				$options[ 'preset-' . $i ] = sprintf( __( 'Preset %d', 'uael' ), $i );
			}

			$widget->start_controls_section(
				'section_presets',
				array(
					'label' => __( 'Presets', 'uael' ),
					'tab'   => Controls_Manager::TAB_CONTENT,
				)
			);

			$widget->add_control(
				'presets_options',
				array(
					'label'   => __( 'Choose Preset', 'uael' ),
					'type'    => 'uael-presets-select',
					'options' => $options,
				)
			);

			$widget->add_control(
				'default_preset_note',
				array(
					'type'            => Controls_Manager::RAW_HTML,
					'raw'             => sprintf(
						/* translators: 1: <b> 2: </b> 3: </br> */
						__( '%1$sNote:%2$s %3$s 1. Choosing a preset will reset all Style settings for this widget. %3$s 2. Choosing \'default\' option after switching between preset options will change the default view of the widget.', 'uael' ),
						'<b>',
						'</b>',
						'</br>'
					),
					'content_classes' => 'uael-editor-doc',
				)
			);

			$widget->end_controls_section();
		}
	}

	/**
	 * Style dependencies for icons still saved in the Font Awesome 4 format.
	 *
	 * Icons saved before Elementor's icon migration, and never re-saved, print as plain
	 * <i class="fa fa-*"> markup instead of going through Icons_Manager. That markup needs
	 * the Font Awesome stylesheet, which UAE no longer loads on every page. Elementor builds
	 * each page's style list from widget instances, so the saved settings are available here.
	 *
	 * The editor preview also calls this on the registered widget type, which has no saved
	 * settings; reading them there is a fatal error on PHP 8. Any widget on the canvas may
	 * hold a Font Awesome 4 icon, so the stylesheet is loaded for the type instead.
	 *
	 * @since 1.45.6
	 * @access protected
	 *
	 * @return array Style handles, empty when every icon renders through Icons_Manager.
	 */
	protected function get_legacy_icon_style_depends() {
		$depends = array( 'uael-nav-menu-icons' );

		if ( $this->is_type_instance() ) {
			return $depends;
		}

		$settings = $this->get_settings();

		foreach ( $this->get_controls() as $name => $control ) {
			if ( ! empty( $control['fa4compatibility'] ) ) {
				if ( ! \Elementor\Icons_Manager::is_migration_allowed() || self::is_legacy_icon( $settings, $control['fa4compatibility'], $name ) ) {
					return $depends;
				}
				continue;
			}

			if ( Controls_Manager::REPEATER !== $control['type'] || empty( $control['fields'] ) || empty( $settings[ $name ] ) || ! is_array( $settings[ $name ] ) ) {
				continue;
			}

			foreach ( $control['fields'] as $field ) {
				if ( empty( $field['fa4compatibility'] ) || empty( $field['name'] ) ) {
					continue;
				}

				foreach ( $settings[ $name ] as $row ) {
					if ( is_array( $row ) && ( ! \Elementor\Icons_Manager::is_migration_allowed() || self::is_legacy_icon( $row, $field['fa4compatibility'], $field['name'] ) ) ) {
						return $depends;
					}
				}
			}
		}

		return array();
	}

	/**
	 * Whether an icon setting will render as Font Awesome 4 markup.
	 *
	 * Mirrors the widgets' render check: the old key holds a saved value and the icon was
	 * never marked as migrated to its Icons control.
	 *
	 * @since 1.45.6
	 * @access private
	 *
	 * @param array  $settings Widget settings or a repeater row.
	 * @param string $old_key  Font Awesome 4 setting key.
	 * @param string $new_key  Icons control key.
	 * @return bool
	 */
	private static function is_legacy_icon( $settings, $old_key, $new_key ) {
		return ! empty( $settings[ $old_key ] ) && is_string( $settings[ $old_key ] ) && ! isset( $settings['__fa4_migrated'][ $new_key ] );
	}
}
