<?php
/**
 * UAEL Helper.
 *
 * @package UAEL
 */

namespace UltimateElementor\Classes;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Class UAEL_Woo_Helper.
 */
class UAEL_Woo_Helper {

	/**
	 * Member Variable
	 *
	 * @var instance
	 */
	private static $instance;

	/**
	 *  Initiator
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor
	 */
	public function __construct() {
	}

	/**
	 * Restore the loop post and product globals.
	 *
	 * A third-party hook that runs a nested query and calls wp_reset_postdata()
	 * mid-card sets the page back up as the global post, which makes WooCommerce
	 * unset $GLOBALS['product']. WooCommerce loop templates then fatal on null,
	 * and title, link and excerpt output would come from the page. Code that
	 * points $GLOBALS['product'] at another product is corrected the same way.
	 * No-op while the globals still point at the card's product.
	 *
	 * @since 1.45.6
	 * @param \WC_Product $product Product the current card is rendering.
	 */
	public function restore_loop_product( $product ) {
		if ( ! $product instanceof \WC_Product ) {
			return;
		}

		$product_id = $product->get_id();

		if ( get_the_ID() !== $product_id ) {
			$GLOBALS['post'] = get_post( $product_id ); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
			setup_postdata( $GLOBALS['post'] );
			$GLOBALS['product'] = $product; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
		} elseif ( ! isset( $GLOBALS['product'] ) || ! $GLOBALS['product'] instanceof \WC_Product || $GLOBALS['product']->get_id() !== $product_id ) {
			$GLOBALS['product'] = $product; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
		}
	}

	/**
	 * Short Description.
	 *
	 * @since 0.0.1
	 */
	public function woo_shop_short_desc() {
		if ( has_excerpt() ) {
			echo '<div class="uael-woo-products-description">';
				echo wp_kses_post( the_excerpt() );
			echo '</div>';
		}
	}

	/**
	 * Parent Category.
	 *
	 * @since 1.1.0
	 */
	public function woo_shop_parent_category() {
		if ( apply_filters( 'uael_woo_shop_parent_category', true ) ) : ?>
			<span class="uael-woo-product-category">
				<?php
				global $product;
				$product_categories = function_exists( 'wc_get_product_category_list' ) ? wc_get_product_category_list( get_the_ID(), ',', '', '' ) : $product->get_categories( ',', '', '' );

				$product_categories = wp_strip_all_tags( $product_categories );
				if ( $product_categories ) {
					list( $parent_cat ) = explode( ',', $product_categories );
					echo esc_html( $parent_cat );
				}
				?>
			</span> 
			<?php
		endif;
	}

	/**
	 * Product Flip Image.
	 *
	 * @since 0.0.1
	 * @param string $image_size The image size to use for the flip image.
	 */
	public function woo_shop_product_flip_image( $image_size ) {

		global $product;

		$attachment_ids = $product->get_gallery_image_ids();

		if ( $attachment_ids ) {
			// Get the selected image resolution from settings.
			$image_size = isset( $image_size ) ? $image_size : 'woocommerce_thumbnail';
			
			// Only apply filter if using the default size.
			if ( 'woocommerce_thumbnail' === $image_size ) {
				$image_size = apply_filters( 'single_product_archive_thumbnail_size', 'woocommerce_thumbnail' );
			}
			
			$swap_images = apply_filters( 'uael_woocommerce_product_flip_image', wp_get_attachment_image( reset( $attachment_ids ), $image_size, false, array( 'class' => 'uael-show-on-hover' ) ) );

			echo wp_kses_post( $swap_images );
		}
	}
}
