;(function($){
"use strict";

    var $cartFormArea = $('.single-product .cart');
    var $stickyCartBtnArea = $('.woolentor-add-to-cart-sticky');

    /**
     * The sticky bar renders the add to cart form a second time, so any third party button
     * hooked into `woocommerce_after_add_to_cart_button` is rendered twice. The PHP side
     * renames the duplicated ids and keeps the original id in `data-woolentor-sticky-for`,
     * so make the duplicate reuse the handler already bound to the original element.
     */
    $stickyCartBtnArea.find('[data-woolentor-sticky-for]').each(function(){

        var clone = this;
        if ( ! /^(BUTTON|A|INPUT)$/.test( clone.tagName ) ) return;

        var original = document.getElementById( clone.getAttribute('data-woolentor-sticky-for') );
        if ( ! original || original === clone || $.contains( $stickyCartBtnArea[0], original ) ) return;

        clone.addEventListener('click', function( event ){
            event.preventDefault();
            event.stopImmediatePropagation();
            original.click();
        }, true);

    });

    if ( $stickyCartBtnArea.length <= 0 || $cartFormArea.length <= 0 ) return;

    var totalOffset = $cartFormArea.offset().top + $cartFormArea.outerHeight();

    var addToCartStickyToggler = function () {
        var windowScroll = $(window).scrollTop();
        var windowHeight = $(window).height();
        var documentHeight = $(document).height();

        if (totalOffset < windowScroll && windowScroll + windowHeight != documentHeight) {
            $stickyCartBtnArea.addClass('woolentor-sticky-shown');
        } else if (windowScroll + windowHeight == documentHeight || totalOffset > windowScroll) {
            $stickyCartBtnArea.removeClass('woolentor-sticky-shown');
        }
    };
    addToCartStickyToggler();
    $(window).scroll(addToCartStickyToggler);

    // If Variations Product
    $('.woolentor-sticky-add-to-cart').on('click', function (e) {
        e.preventDefault();
        $('html, body').animate({
            scrollTop: $('.single-product form.cart').offset().top - 30
        }, 500 );
    });

})(jQuery);