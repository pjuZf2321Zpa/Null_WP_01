<?php
namespace Woolentor\Modules\SideMiniCart\Frontend;
use WooLentorPro\Traits\Singleton;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Manage_Mini_Cart {
    use Singleton;

    public function __construct(){
        add_action( 'woolentor_footer_render_content', [ $this, 'mini_cart' ] );
        add_action( 'woolentor_cart_content', [ $this, 'get_cart_item' ] );
        add_filter( 'woocommerce_add_to_cart_fragments', [ $this,'wc_add_to_cart_fragment' ], 10, 1 );
    }

    /**
     * Mini Cart Template
     * @return void
     */
    public function mini_cart(){
        require( WOOLENTOR_TEMPLATE_PRO .'tmp-mini_cart.php' );
    }

    /**
     * [get_cart_item] Render fragment cart item
     * @return [html]
     */
    public function get_cart_item(){

        $args = [];
        ob_start();
        $mini_cart_tmp_id = method_exists( 'Woolentor_Template_Manager', 'get_template_id' ) ? \Woolentor_Template_Manager::instance()->get_template_id( 'mini_cart_layout', 'woolentor_get_option_pro' ) : '0';
        if( !empty( $mini_cart_tmp_id ) ){
            echo method_exists('Woolentor_Manage_WC_Template','render_build_content') ? \Woolentor_Manage_WC_Template::render_build_content( $mini_cart_tmp_id, true ) : '';
        }else{
            wc_get_template( 'tmp-mini_cart_content.php', $args, '', WOOLENTOR_TEMPLATE_PRO );
        }
        echo ob_get_clean();

    }

    /**
     * [item_data_html] Selected variation and extra item data markup.
     *
     * @param array $cart_item Cart item.
     * @param mixed $force     Null to follow the global setting, otherwise a truthy/falsy override.
     * @return string
     */
    public static function item_data_html( $cart_item, $force = null ){

        if ( is_null( $force ) ) {
            $enabled = 'on' === woolentor_get_option_pro( 'mini_cart_show_item_data', 'woolentor_others_tabs', 'off' );
        } else {
            $enabled = filter_var( $force, FILTER_VALIDATE_BOOLEAN );
        }

        if ( ! $enabled || ! function_exists( 'wc_get_formatted_cart_item_data' ) ) {
            return '';
        }

        // WooCommerce skips variation attributes that are already part of the product title,
        // so they are added back only while the mini cart item is rendered.
        add_filter( 'woocommerce_get_item_data', [ __CLASS__, 'add_variation_data' ], 5, 2 );
        $item_data_html = wc_get_formatted_cart_item_data( $cart_item ); // Escaped by WooCommerce.
        remove_filter( 'woocommerce_get_item_data', [ __CLASS__, 'add_variation_data' ], 5 );

        return $item_data_html;

    }

    /**
     * [add_variation_data] Add the selected variation attributes to the item data list.
     *
     * @param array $item_data Item data.
     * @param array $cart_item Cart item.
     * @return array
     */
    public static function add_variation_data( $item_data, $cart_item ){

        if ( empty( $cart_item['data'] ) || ! $cart_item['data']->is_type( 'variation' ) || empty( $cart_item['variation'] ) || ! is_array( $cart_item['variation'] ) ) {
            return $item_data;
        }

        $existing_keys = wp_list_pluck( $item_data, 'key' );

        foreach ( $cart_item['variation'] as $name => $value ) {

            $taxonomy = wc_attribute_taxonomy_name( str_replace( 'attribute_pa_', '', urldecode( $name ) ) );

            if ( taxonomy_exists( $taxonomy ) ) {
                $term = get_term_by( 'slug', $value, $taxonomy );
                if ( ! is_wp_error( $term ) && $term && $term->name ) {
                    $value = $term->name;
                }
                $label = wc_attribute_label( $taxonomy );
            } else {
                $value = apply_filters( 'woocommerce_variation_option_name', $value, null, $taxonomy, $cart_item['data'] );
                $label = wc_attribute_label( str_replace( 'attribute_', '', $name ), $cart_item['data'] );
            }

            if ( '' === $value || in_array( $label, $existing_keys, true ) ) {
                continue;
            }

            $item_data[] = [
                'key'   => $label,
                'value' => $value,
            ];

            $existing_keys[] = $label;

        }

        return $item_data;

    }

    /**
     * Cart Item HTML Return For fragment.
     */
    public function cart_item_html(){
        ob_start();
        $this->get_cart_item();
        return ob_get_clean();
    }

    /**
     * [wc_add_to_cart_fragment] add to cart freagment callable
     * @param  [type] $fragments
     * @return [type] $fragments
     */
    public function wc_add_to_cart_fragment( $fragments ){

        $item_count = WC()->cart->get_cart_contents_count();
        $cart_item  = $this->cart_item_html();

        // Cart Item
        $fragments['div.woolentor_cart_content_container'] = '<div class="woolentor_cart_content_container">'.$cart_item.'</div>';

        //Cart Counter
        $fragments['span.woolentor_mini_cart_counter'] = '<span class="woolentor_mini_cart_counter">'.$item_count.'</span>';

        return $fragments;
    }
    

}