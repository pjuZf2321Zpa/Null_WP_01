<?php
namespace WoolentorPro\Modules\FreeShippingBar\Frontend;
use WooLentorPro\Traits\Singleton;
use WoolentorPro\Modules\FreeShippingBar\Free_Shipping_Bar_Pro;

if ( ! defined( 'ABSPATH' ) ) exit;

class Multi_Bar {
    use Singleton;

    private function __construct() {}

    /**
     * Evaluate additional bars and return the first one matching the current
     * context (targeting, schedule, device). Returns null when none match.
     */
    public function get_best_bar() {
        $additional_bars = Free_Shipping_Bar_Pro::setting( 'additional_bars', [] );
        if ( empty( $additional_bars ) || ! is_array( $additional_bars ) ) {
            return null;
        }

        usort( $additional_bars, static function ( $a, $b ) {
            return (int) ( $a['bar_priority'] ?? 10 ) - (int) ( $b['bar_priority'] ?? 10 );
        } );

        foreach ( $additional_bars as $index => $bar ) {
            if ( ( $bar['bar_enabled'] ?? 'on' ) !== 'on' ) {
                continue;
            }

            // Schedule check
            if ( ( $bar['enable_schedule'] ?? 'off' ) === 'on' ) {
                $now   = time();
                $start = ! empty( $bar['schedule_start'] ) ? strtotime( $bar['schedule_start'] ) : 0;
                $end   = ! empty( $bar['schedule_end'] )   ? strtotime( $bar['schedule_end'] )   : 0;
                if ( $start && $now < $start ) continue;
                if ( $end   && $now > $end )   continue;
            }

            // User-role check
            $role = $bar['target_user_role'] ?? 'all';
            if ( $role === 'guest'     && is_user_logged_in() ) continue;
            if ( $role === 'logged_in' && ! is_user_logged_in() ) continue;

            // Shipping zone check — zone IDs are saved as strings by the multiselect.
            $target_zones = array_filter( array_map( 'strval', (array) ( $bar['target_zones'] ?? [] ) ), 'strlen' );
            if ( ! empty( $target_zones ) ) {
                $zone_id = self::get_customer_zone_id();
                if ( $zone_id === null || ! in_array( $zone_id, $target_zones, true ) ) {
                    continue;
                }
            }

            // Page check — display_pages is an array of page IDs (ajaxselect, multiple).
            // Shipping is recalculated in AJAX / REST requests that have no page, so a zone
            // bar keeps its threshold there instead of falling back to the main bar's.
            $display_pages = $bar['display_pages'] ?? [];
            $check_pages   = ! empty( $display_pages ) && is_array( $display_pages );
            if ( $check_pages && ! empty( $target_zones ) && self::is_pageless_request() ) {
                $check_pages = false;
            }
            if ( $check_pages ) {
                $page_ids = array_filter( array_map( 'absint', $display_pages ) );
                if ( ! empty( $page_ids ) ) {
                    $current = \Woolentor\Modules\FreeShippingBar\Frontend\Bar_Renderer::get_current_page_id();
                    if ( ! in_array( $current, $page_ids, true ) ) {
                        continue;
                    }
                }
            }

            // Threshold for this bar
            $bar_threshold = (float) ( $bar['manual_threshold'] ?? 0 );
            if ( $bar_threshold <= 0 ) {
                $bar_threshold = \Woolentor\Modules\FreeShippingBar\Frontend\Bar_Renderer::get_threshold();
            }
            if ( $bar_threshold <= 0 ) {
                continue;
            }

            return [
                '_index'         => $index,
                'threshold'      => $bar_threshold,
                'msg_initial'    => $bar['msg_initial']    ?? esc_html__( 'Spend {amount} more to get FREE shipping!', 'woolentor-pro' ),
                'msg_success'    => $bar['msg_success']    ?? esc_html__( "🎉 You've unlocked FREE shipping!", 'woolentor-pro' ),
                'bar_position'   => $bar['bar_position']   ?? 'top',
                'show_on_device' => $bar['show_on_device'] ?? 'all',
                'bar_skin'       => $bar['bar_skin']       ?? 'default',
                'bar_bg_color'   => $bar['bar_bg_color']   ?? '',
                'bar_text_color' => $bar['bar_text_color'] ?? '',
                'bar_fill_color' => $bar['bar_fill_color'] ?? '',
                'enable_countdown'   => $bar['enable_countdown']   ?? 'off',
                'countdown_end_date' => $bar['countdown_end_date'] ?? '',
                'countdown_message'  => $bar['countdown_message']  ?? '',
            ];
        }

        return null;
    }

    /**
     * ID (as a string) of the shipping zone matching the customer's address.
     *
     * @return string|null Null when the customer's location is not known yet.
     */
    private static function get_customer_zone_id() {
        if ( ! method_exists( '\\Woolentor\\Modules\\FreeShippingBar\\Frontend\\Shipping_Handler', 'get_customer_zone' ) ) {
            return null;
        }
        $zone = \Woolentor\Modules\FreeShippingBar\Frontend\Shipping_Handler::get_customer_zone();
        return $zone ? (string) $zone->get_id() : null;
    }

    /**
     * Whether this is an AJAX / REST request with no page to target (e.g. checkout updates).
     *
     * @return bool
     */
    private static function is_pageless_request() {
        if ( \Woolentor\Modules\FreeShippingBar\Frontend\Bar_Renderer::get_current_page_id() ) {
            return false;
        }
        return wp_doing_ajax() || ( defined( 'REST_REQUEST' ) && REST_REQUEST );
    }
}
