<?php
namespace WoolentorPro\Modules\FreeShippingBar\Frontend;
use WooLentorPro\Traits\Singleton;
use WoolentorPro\Modules\FreeShippingBar\Free_Shipping_Bar_Pro;

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Leave virtual and downloadable products out of the cart amount that
 * counts towards the free-shipping threshold (Module mode only).
 */
class Cart_Total {
    use Singleton;

    private function __construct() {
        add_filter( 'woolentor_fsb_cart_total', [ $this, 'exclude_virtual_products' ], 10, 2 );
    }

    public function exclude_virtual_products( $total, $cart ) {
        if ( Free_Shipping_Bar_Pro::setting( 'exclude_virtual_products', 'off' ) !== 'on' ) {
            return $total;
        }
        if ( Free_Shipping_Bar_Pro::setting( 'shipping_mode', 'module' ) !== 'module' ) {
            return $total;
        }
        if ( ! $cart instanceof \WC_Cart ) {
            return $total;
        }

        // Match get_displayed_subtotal(): include tax only when prices are shown with tax.
        $with_tax = $cart->display_prices_including_tax();
        $excluded = 0;

        foreach ( $cart->get_cart() as $item ) {
            $product = isset( $item['data'] ) ? $item['data'] : null;
            if ( ! $product instanceof \WC_Product ) {
                continue;
            }

            $exclude = $product->is_virtual() || $product->is_downloadable();

            /**
             * Filter whether a cart item is left out of the free-shipping threshold.
             *
             * @param bool        $exclude Whether to exclude the item.
             * @param \WC_Product $product Cart item product.
             * @param array       $item    Cart item data.
             */
            if ( ! apply_filters( 'woolentor_fsb_exclude_cart_item', $exclude, $product, $item ) ) {
                continue;
            }

            $excluded += (float) $item['line_subtotal'];
            if ( $with_tax ) {
                $excluded += (float) $item['line_subtotal_tax'];
            }
        }

        return max( 0, (float) $total - $excluded );
    }
}
