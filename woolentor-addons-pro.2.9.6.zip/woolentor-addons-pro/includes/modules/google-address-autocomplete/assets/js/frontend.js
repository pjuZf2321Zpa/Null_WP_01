;(function($) {
    'use strict';

    /**
     * Escape HTML string
     */
    function escapeHtml(str) {
        if (!str) return '';
        return String(str)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }

    /**
     * Highlight matched substring
     */
    function highlightMatch(text, query) {
        if (!text) return '';
        if (!query) return escapeHtml(text);

        const escapedQuery = query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        const regex = new RegExp('(' + escapedQuery + ')', 'gi');
        return escapeHtml(text).replace(regex, '<span class="pac-matched">$1</span>');
    }

    /**
     * Google Address Autocomplete Handler (Supporting Places API New & Legacy)
     */
    const WoolentorAddressAutocomplete = {

        /**
         * Settings from PHP
         */
        settings: {},

        /**
         * Autocomplete instances / state
         */
        autocompleteInstances: {},

        /**
         * Places library reference (loaded via importLibrary)
         */
        placesLib: null,

        /**
         * Initialize the autocomplete functionality
         */
        init: async function() {
            this.settings = window.woolentorGoogleAutocomplete || {};

            // Ensure Places library is loaded
            await this.loadPlacesLibrary();

            this.initAutocomplete();
            this.bindEvents();
        },

        /**
         * Load Places library using Google Maps dynamic importLibrary if available
         */
        loadPlacesLibrary: async function() {
            if (this.placesLib) {
                return this.placesLib;
            }

            try {
                if (typeof google !== 'undefined' && google.maps) {
                    if (typeof google.maps.importLibrary === 'function') {
                        this.placesLib = await google.maps.importLibrary('places');
                        return this.placesLib;
                    } else if (google.maps.places) {
                        this.placesLib = google.maps.places;
                        return this.placesLib;
                    }
                }
            } catch (error) {
                console.warn('WoolentorAddressAutocomplete: Failed to import places library', error);
                if (typeof google !== 'undefined' && google.maps && google.maps.places) {
                    this.placesLib = google.maps.places;
                }
            }

            return this.placesLib;
        },

        /**
         * Check if Places API (New) should be used
         */
        isNewApi: function() {
            const apiVersion = this.settings.apiVersion || 'new';
            if (apiVersion === 'legacy') {
                return false;
            }

            // Check if AutocompleteSuggestion is available in loaded library or global
            const lib = this.placesLib || (typeof google !== 'undefined' && google.maps && google.maps.places);
            return !!(lib && lib.AutocompleteSuggestion);
        },

        /**
         * Initialize autocomplete on target fields
         */
        initAutocomplete: function() {
            const self = this;
            const targets = this.getTargetFields();

            targets.forEach(function(fieldId) {
                const field = document.getElementById(fieldId);
                if (field && !self.autocompleteInstances[fieldId]) {
                    self.setupAutocomplete(field, fieldId, false);
                }
            });
        },

        /**
         * Get target field IDs based on settings
         *
         * @return {Array} Array of field IDs
         */
        getTargetFields: function() {
            const fields = [];
            const target = this.settings.targetFields || 'both';

            if (target === 'both' || target === 'billing') {
                fields.push('billing_address_1');
            }
            if (target === 'both' || target === 'shipping') {
                fields.push('shipping_address_1');
            }

            return fields;
        },

        /**
         * Setup autocomplete on a field (delegates to New or Legacy handler)
         *
         * @param {HTMLElement} field The input field element
         * @param {string} fieldId The field ID
         * @param {boolean} isBlock Whether this is a Block Checkout field
         */
        setupAutocomplete: function(field, fieldId, isBlock) {
            if (this.isNewApi()) {
                this.setupAutocompleteNew(field, fieldId, isBlock);
            } else {
                this.setupAutocompleteLegacy(field, fieldId, isBlock);
            }
        },

        /**
         * Setup Places API (New) autocomplete using Autocomplete Data API (Option B)
         *
         * @param {HTMLElement} field The input field element
         * @param {string} fieldId The field ID
         * @param {boolean} isBlock Whether this is a Block Checkout field
         */
        setupAutocompleteNew: function(field, fieldId, isBlock) {
            const self = this;
            const lib = this.placesLib || (typeof google !== 'undefined' && google.maps && google.maps.places);

            if (!lib || !lib.AutocompleteSuggestion) {
                // Fallback to legacy if available
                return this.setupAutocompleteLegacy(field, fieldId, isBlock);
            }

            const AutocompleteSuggestion = lib.AutocompleteSuggestion;
            const AutocompleteSessionToken = lib.AutocompleteSessionToken;

            // Create dropdown container
            const dropdown = document.createElement('div');
            dropdown.className = 'pac-container woolentor-pac-container';
            dropdown.style.display = 'none';
            document.body.appendChild(dropdown);

            let sessionToken = AutocompleteSessionToken ? new AutocompleteSessionToken() : null;
            let currentSuggestions = [];
            let selectedIndex = -1;
            let debounceTimer = null;
            let isFocused = false;

            // Mark instance active
            this.autocompleteInstances[fieldId] = {
                field: field,
                dropdown: dropdown,
                destroy: function() {
                    if (dropdown && dropdown.parentNode) {
                        dropdown.parentNode.removeChild(dropdown);
                    }
                }
            };

            // Prevent native autocomplete interference
            field.setAttribute('autocomplete', 'new-password');

            // Position the dropdown below the field
            const positionDropdown = function() {
                if (dropdown.style.display === 'none') return;
                const rect = field.getBoundingClientRect();
                dropdown.style.position = 'absolute';
                dropdown.style.top = (rect.bottom + window.pageYOffset) + 'px';
                dropdown.style.left = (rect.left + window.pageXOffset) + 'px';
                dropdown.style.width = rect.width + 'px';
                dropdown.style.zIndex = '100000';
            };

            // Hide dropdown
            const hideDropdown = function() {
                dropdown.style.display = 'none';
                dropdown.innerHTML = '';
                currentSuggestions = [];
                selectedIndex = -1;
            };

            // Select a suggestion by index
            const selectSuggestion = async function(index) {
                const suggestion = currentSuggestions[index];
                if (!suggestion || !suggestion.placePrediction) {
                    return;
                }

                hideDropdown();

                try {
                    const place = suggestion.placePrediction.toPlace();
                    await place.fetchFields({
                        fields: ['addressComponents', 'formattedAddress']
                    });

                    if (isBlock) {
                        self.fillInBlockAddress(place, fieldId);
                    } else {
                        self.fillInAddress(place, fieldId);
                    }
                } catch (error) {
                    console.warn('WoolentorAddressAutocomplete: Error fetching place details', error);
                }

                // Reset session token for next search
                sessionToken = AutocompleteSessionToken ? new AutocompleteSessionToken() : null;
            };

            // Highlight selected item in dropdown
            const updateSelection = function() {
                const items = dropdown.querySelectorAll('.pac-item');
                items.forEach(function(item, idx) {
                    if (idx === selectedIndex) {
                        item.classList.add('pac-item-selected');
                        // Ensure item is scrolled into view
                        item.scrollIntoView({ block: 'nearest' });
                    } else {
                        item.classList.remove('pac-item-selected');
                    }
                });
            };

            // Render suggestions in dropdown
            const renderSuggestions = function(suggestions, query) {
                dropdown.innerHTML = '';
                selectedIndex = -1;

                if (!suggestions || suggestions.length === 0) {
                    hideDropdown();
                    return;
                }

                suggestions.forEach(function(suggestion, idx) {
                    const pred = suggestion.placePrediction;
                    if (!pred) return;

                    const mainText = (pred.mainText && (pred.mainText.text || pred.mainText.toString())) || '';
                    const secondaryText = (pred.secondaryText && (pred.secondaryText.text || pred.secondaryText.toString())) || '';

                    const item = document.createElement('div');
                    item.className = 'pac-item';
                    item.setAttribute('data-index', idx);

                    let itemHtml = '<span class="pac-icon pac-icon-marker"></span>';
                    itemHtml += '<span class="pac-item-query">' + highlightMatch(mainText, query) + '</span>';
                    if (secondaryText) {
                        itemHtml += '<span>' + escapeHtml(secondaryText) + '</span>';
                    }

                    item.innerHTML = itemHtml;

                    // Mouse interactions
                    item.addEventListener('mouseenter', function() {
                        selectedIndex = idx;
                        updateSelection();
                    });

                    item.addEventListener('click', function(e) {
                        e.preventDefault();
                        e.stopPropagation();
                        selectSuggestion(idx);
                    });

                    dropdown.appendChild(item);
                });

                // "Powered by Google" branding
                const logo = document.createElement('div');
                logo.className = 'pac-logo';
                dropdown.appendChild(logo);

                dropdown.style.display = 'block';
                positionDropdown();
            };

            // Fetch suggestions from Google Autocomplete Data API
            const fetchSuggestions = async function(query) {
                if (!query || query.length < 2) {
                    hideDropdown();
                    return;
                }

                if (!sessionToken && AutocompleteSessionToken) {
                    sessionToken = new AutocompleteSessionToken();
                }

                const request = {
                    input: query,
                    sessionToken: sessionToken
                };

                // Add country restrictions if configured (up to 15 region codes)
                if (self.settings.countryRestrictions && self.settings.countryRestrictions.length > 0) {
                    request.includedRegionCodes = self.settings.countryRestrictions.slice(0, 15);
                }

                try {
                    const response = await AutocompleteSuggestion.fetchAutocompleteSuggestions(request);
                    const suggestions = (response && response.suggestions) ? response.suggestions : [];
                    currentSuggestions = suggestions;

                    if (isFocused) {
                        renderSuggestions(suggestions, query);
                    }
                } catch (error) {
                    console.warn('WoolentorAddressAutocomplete: fetchAutocompleteSuggestions failed', error);
                    hideDropdown();
                }
            };

            // Input typing listener with debounce
            field.addEventListener('input', function() {
                const query = field.value.trim();
                clearTimeout(debounceTimer);

                if (query.length < 2) {
                    hideDropdown();
                    return;
                }

                debounceTimer = setTimeout(function() {
                    fetchSuggestions(query);
                }, 300);
            });

            // Focus listener
            field.addEventListener('focus', function() {
                isFocused = true;
                const query = field.value.trim();
                if (query.length >= 2 && currentSuggestions.length > 0) {
                    dropdown.style.display = 'block';
                    positionDropdown();
                }
            });

            // Blur listener (delay to allow click to register)
            field.addEventListener('blur', function() {
                isFocused = false;
                setTimeout(function() {
                    if (!isFocused) {
                        hideDropdown();
                    }
                }, 250);
            });

            // Prevent dropdown mousedown from stealing input focus before click event fires
            dropdown.addEventListener('mousedown', function(e) {
                e.preventDefault();
            });

            // Keyboard navigation
            field.addEventListener('keydown', function(e) {
                if (dropdown.style.display === 'none') {
                    return;
                }

                const max = currentSuggestions.length;
                if (max === 0) return;

                if (e.keyCode === 40) { // Arrow Down
                    e.preventDefault();
                    selectedIndex = (selectedIndex + 1) % max;
                    updateSelection();
                } else if (e.keyCode === 38) { // Arrow Up
                    e.preventDefault();
                    selectedIndex = (selectedIndex - 1 + max) % max;
                    updateSelection();
                } else if (e.keyCode === 13) { // Enter
                    if (selectedIndex >= 0 && selectedIndex < max) {
                        e.preventDefault();
                        selectSuggestion(selectedIndex);
                    } else {
                        // Prevent form submit when dropdown is visible
                        e.preventDefault();
                    }
                } else if (e.keyCode === 27) { // Escape
                    e.preventDefault();
                    hideDropdown();
                }
            });

            // Reposition on window resize and scroll
            window.addEventListener('resize', positionDropdown);
            window.addEventListener('scroll', positionDropdown, true);
        },

        /**
         * Setup legacy Google Maps Autocomplete widget
         *
         * @param {HTMLElement} field The input field element
         * @param {string} fieldId The field ID
         * @param {boolean} isBlock Whether this is a Block Checkout field
         */
        setupAutocompleteLegacy: function(field, fieldId, isBlock) {
            const self = this;

            if (typeof google === 'undefined' || !google.maps || !google.maps.places || !google.maps.places.Autocomplete) {
                return;
            }

            // Autocomplete options
            const options = {
                types: ['address'],
                fields: ['address_components', 'formatted_address', 'icon']
            };

            // Add country restrictions if set
            if (this.settings.countryRestrictions && this.settings.countryRestrictions.length > 0) {
                options.componentRestrictions = {
                    country: this.settings.countryRestrictions
                };
            }

            // Create autocomplete instance
            const autocomplete = new google.maps.places.Autocomplete(field, options);
            this.autocompleteInstances[fieldId] = autocomplete;

            // Listen for place selection
            autocomplete.addListener('place_changed', function() {
                if (isBlock) {
                    self.fillInBlockAddress(autocomplete, fieldId);
                } else {
                    self.fillInAddress(autocomplete, fieldId);
                }
            });

            // Prevent form submission on Enter key in autocomplete field
            field.addEventListener('keydown', function(e) {
                if (e.keyCode === 13) {
                    const pacContainer = document.querySelector('.pac-container');
                    if (pacContainer && pacContainer.style.display !== 'none') {
                        e.preventDefault();
                    }
                }
            });
        },

        /**
         * Extract and normalize address components from either New or Legacy Places API
         *
         * @param {Object} place The Google place object
         * @return {Object} Parsed address data
         */
        parseAddressComponents: function(place) {
            // New API uses `place.addressComponents`, legacy uses `place.address_components`
            const rawComponents = place.addressComponents || place.address_components || [];

            const componentMapping = {
                street_number: 'short',
                route: 'long',
                locality: 'long',
                sublocality_level_1: 'long',
                administrative_area_level_1: 'short',
                administrative_area_level_2: 'long',
                country: 'short',
                postal_code: 'short',
                postal_code_suffix: 'short'
            };

            const addressData = {};

            rawComponents.forEach(function(component) {
                // New API: longText/shortText, Legacy API: long_name/short_name
                const longVal = component.longText || component.long_name || '';
                const shortVal = component.shortText || component.short_name || '';
                const types = component.types || [];

                types.forEach(function(type) {
                    if (componentMapping[type] && !addressData[type]) {
                        addressData[type] = (componentMapping[type] === 'short') ? shortVal : longVal;
                    }
                    if (type === 'country' && !addressData['country_long']) {
                        addressData['country_long'] = longVal;
                    }
                });
            });

            // Build street address
            const streetNumber = addressData.street_number || '';
            const route = addressData.route || '';
            let address1 = '';

            if (streetNumber && route) {
                address1 = streetNumber + ' ' + route;
            } else if (route) {
                address1 = route;
            } else if (streetNumber) {
                address1 = streetNumber;
            }

            // Get city (locality -> sublocality_level_1 -> administrative_area_level_2)
            const city = addressData.locality ||
                        addressData.sublocality_level_1 ||
                        addressData.administrative_area_level_2 ||
                        '';

            // Get postal code (with suffix if available)
            let postalCode = addressData.postal_code || '';
            if (addressData.postal_code_suffix) {
                postalCode += '-' + addressData.postal_code_suffix;
            }

            return {
                address_1: address1,
                city: city,
                postcode: postalCode,
                state: addressData.administrative_area_level_1 || '',
                country: addressData.country || '',
                country_long: addressData.country_long || ''
            };
        },

        /**
         * Fill in address fields for Classic / Template Checkout
         *
         * @param {Object} placeOrAutocomplete Place object or Autocomplete instance
         * @param {string} fieldId The source field ID
         */
        fillInAddress: function(placeOrAutocomplete, fieldId) {
            const place = (placeOrAutocomplete && typeof placeOrAutocomplete.getPlace === 'function')
                ? placeOrAutocomplete.getPlace()
                : placeOrAutocomplete;

            if (!place) {
                return;
            }

            const prefix = fieldId.replace('_address_1', '');
            const parsed = this.parseAddressComponents(place);

            // Reset fields first
            this.resetFields(prefix);

            // Fill street address 1 (fallback to formatted address if address_1 is empty)
            const formatted = place.formattedAddress || place.formatted_address || '';
            this.setFieldValue(prefix + '_address_1', parsed.address_1 || formatted);
            this.setFieldValue(prefix + '_city', parsed.city);
            this.setFieldValue(prefix + '_postcode', parsed.postcode);

            // Set state and country
            this.setStateField(prefix + '_state', parsed.state);
            this.setCountryField(prefix + '_country', parsed.country);

            // Trigger WooCommerce checkout update
            $(document.body).trigger('update_checkout');
        },

        /**
         * Set a field value and trigger change event
         *
         * @param {string} fieldId The field ID
         * @param {string} value The value to set
         */
        setFieldValue: function(fieldId, value) {
            const field = document.getElementById(fieldId);
            if (field) {
                $(field).val(value).trigger('change');
            }
        },

        /**
         * Set country field value (handles select2 dropdowns)
         *
         * @param {string} fieldId The field ID
         * @param {string} countryCode The country code
         */
        setCountryField: function(fieldId, countryCode) {
            const field = document.getElementById(fieldId);
            if (!field) return;

            const $field = $(field);
            const upperCode = countryCode.toUpperCase();

            // Check if option exists
            if ($field.find('option[value="' + upperCode + '"]').length > 0) {
                $field.val(upperCode).trigger('change');
            }
        },

        /**
         * Set state field value (handles both text and select fields)
         *
         * @param {string} fieldId The field ID
         * @param {string} stateValue The state value/code
         */
        setStateField: function(fieldId, stateValue) {
            const field = document.getElementById(fieldId);
            if (!field) return;

            const $field = $(field);

            // If it's a select field
            if (field.tagName === 'SELECT') {
                let found = false;

                $field.find('option').each(function() {
                    const $option = $(this);
                    const optVal = $option.val().toUpperCase();
                    const optText = $option.text().toUpperCase();
                    const searchVal = stateValue.toUpperCase();

                    if (optVal === searchVal || optText === searchVal) {
                        $field.val($option.val()).trigger('change');
                        found = true;
                        return false;
                    }
                });

                if (!found) {
                    $field.find('option').each(function() {
                        const $option = $(this);
                        const optText = $option.text().toUpperCase();
                        const searchVal = stateValue.toUpperCase();

                        if (optText.indexOf(searchVal) !== -1 || searchVal.indexOf(optText) !== -1) {
                            $field.val($option.val()).trigger('change');
                            return false;
                        }
                    });
                }
            } else {
                $field.val(stateValue).trigger('change');
            }
        },

        /**
         * Reset address fields
         *
         * @param {string} prefix Field prefix (billing or shipping)
         */
        resetFields: function(prefix) {
            const fieldsToReset = ['_address_2', '_city', '_state', '_postcode'];
            const self = this;

            fieldsToReset.forEach(function(suffix) {
                self.setFieldValue(prefix + suffix, '');
            });
        },

        /**
         * Bind events for dynamic checkout updates
         */
        bindEvents: function() {
            const self = this;

            // Re-initialize on checkout update (for dynamic fields)
            $(document.body).on('updated_checkout', function() {
                self.initAutocomplete();
            });

            // Re-initialize when ship to different address is toggled
            $(document.body).on('change', '#ship-to-different-address-checkbox', function() {
                setTimeout(function() {
                    self.initAutocomplete();
                }, 100);
            });

            // Handle WooCommerce Blocks checkout
            if (typeof wp !== 'undefined' && wp.data) {
                wp.data.subscribe(function() {
                    self.initBlockCheckoutAutocomplete();
                });
            }
        },

        /**
         * Initialize autocomplete for Block Checkout
         */
        initBlockCheckoutAutocomplete: function() {
            const self = this;
            const target = this.settings.targetFields || 'both';

            const blockFields = [];

            if (target === 'both' || target === 'billing') {
                blockFields.push('billing-address_1');
            }
            if (target === 'both' || target === 'shipping') {
                blockFields.push('shipping-address_1');
            }

            blockFields.forEach(function(fieldId) {
                const field = document.getElementById(fieldId);
                if (field && !self.autocompleteInstances[fieldId]) {
                    self.setupAutocomplete(field, fieldId, true);
                }
            });
        },

        /**
         * Fill in Block Checkout address fields
         *
         * @param {Object} placeOrAutocomplete Place object or Autocomplete instance
         * @param {string} fieldId The source field ID
         */
        fillInBlockAddress: function(placeOrAutocomplete, fieldId) {
            const place = (placeOrAutocomplete && typeof placeOrAutocomplete.getPlace === 'function')
                ? placeOrAutocomplete.getPlace()
                : placeOrAutocomplete;

            if (!place) {
                return;
            }

            const prefix = fieldId.replace('-address_1', '');
            const parsed = this.parseAddressComponents(place);
            const formatted = place.formattedAddress || place.formatted_address || '';

            this.setBlockFieldValue(prefix + '-address_1', parsed.address_1 || formatted);
            this.setBlockFieldValue(prefix + '-city', parsed.city);
            this.setBlockFieldValue(prefix + '-state', parsed.state);
            this.setBlockFieldValue(prefix + '-postcode', parsed.postcode);
            this.setBlockFieldValue(prefix + '-country', parsed.country);
        },

        /**
         * Set Block Checkout field value (React state compatible)
         *
         * @param {string} fieldId The field ID
         * @param {string} value The value to set
         */
        setBlockFieldValue: function(fieldId, value) {
            const field = document.getElementById(fieldId);
            if (!field) {
                return;
            }

            try {
                const tagName = field.tagName.toUpperCase();

                if (tagName === 'SELECT') {
                    const upperValue = value.toUpperCase();
                    let optionFound = false;

                    for (let i = 0; i < field.options.length; i++) {
                        const option = field.options[i];
                        if (option.value.toUpperCase() === upperValue ||
                            option.text.toUpperCase() === upperValue) {
                            field.selectedIndex = i;
                            optionFound = true;
                            break;
                        }
                    }

                    if (optionFound) {
                        field.dispatchEvent(new Event('change', { bubbles: true }));
                    }
                } else if (tagName === 'INPUT' || tagName === 'TEXTAREA') {
                    const descriptor = Object.getOwnPropertyDescriptor(
                        tagName === 'TEXTAREA' ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype,
                        'value'
                    );

                    if (descriptor && descriptor.set) {
                        descriptor.set.call(field, value);
                    } else {
                        field.value = value;
                    }

                    field.dispatchEvent(new Event('input', { bubbles: true }));
                    field.dispatchEvent(new Event('change', { bubbles: true }));
                    field.dispatchEvent(new Event('blur', { bubbles: true }));
                }
            } catch (error) {
                console.warn('WoolentorAddressAutocomplete: Error setting field value', fieldId, error);
                try {
                    field.value = value;
                    field.dispatchEvent(new Event('change', { bubbles: true }));
                } catch (e) {
                    // Silent fail
                }
            }
        }
    };

    // Initialize when document is ready and Google API is loaded
    $(document).ready(function() {
        const checkGoogleApi = function() {
            if (typeof google !== 'undefined' && google.maps) {
                WoolentorAddressAutocomplete.init();
            } else {
                setTimeout(checkGoogleApi, 100);
            }
        };

        checkGoogleApi();
    });

})(jQuery);
