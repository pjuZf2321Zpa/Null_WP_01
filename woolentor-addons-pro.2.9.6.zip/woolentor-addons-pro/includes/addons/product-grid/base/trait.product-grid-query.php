<?php
/**
 * Product Grid Query Controls
 *
 * Shared Query Type control for the product grid widgets (Modern, Luxury,
 * Editorial, Magazine), so the option list lives in one place.
 *
 * The context types (related, upsell, cross-sell, same category/tag) are
 * resolved by WooLentor_WooCommerce_Query_Manager against the product being
 * viewed, and are meant for a Single Product template.
 *
 * @package WooLentorPro
 */

namespace Elementor;

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

trait WooLentor_Product_Grid_Query_Controls {

    /**
     * Query Type control, overrides the free widget's Pro-labelled version.
     */
    protected function add_query_type_control(){
        $this->add_control(
            'query_type',
            [
                'label' => esc_html__( 'Query Type', 'woolentor-pro' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'products',
                'options' => [
                    'products'          => esc_html__( 'All Products', 'woolentor-pro' ),
                    'recent'            => esc_html__( 'Recent Products', 'woolentor-pro' ),
                    'manual'            => esc_html__( 'Manual Selection', 'woolentor-pro' ),
                    'featured'          => esc_html__( 'Featured', 'woolentor-pro' ),
                    'sale'              => esc_html__( 'On Sale', 'woolentor-pro' ),
                    'best_selling'      => esc_html__( 'Best Selling', 'woolentor-pro' ),
                    'top_rated'         => esc_html__( 'Top Rated', 'woolentor-pro' ),
                    'recently_viewed'   => esc_html__( 'Recently Viewed', 'woolentor-pro' ),
                    'related'           => esc_html__( 'Related Products', 'woolentor-pro' ),
                    'upsell'            => esc_html__( 'Upsells', 'woolentor-pro' ),
                    'cross_sell'        => esc_html__( 'Cross-sells', 'woolentor-pro' ),
                    'cart_cross_sell'   => esc_html__( 'Cart Cross-sells', 'woolentor-pro' ),
                    'same_category'     => esc_html__( 'Same Category', 'woolentor-pro' ),
                    'same_tag'          => esc_html__( 'Same Tag', 'woolentor-pro' ),
                ],
            ]
        );

        $this->add_control(
            'query_type_context_notice',
            [
                'type' => Controls_Manager::RAW_HTML,
                'raw' => esc_html__( 'Products are taken from the product being viewed, so use this in a Single Product template. The current product is excluded automatically. The editor previews the latest product.', 'woolentor-pro' ),
                'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
                'condition' => [
                    'query_type' => [ 'related', 'upsell', 'cross_sell', 'same_category', 'same_tag' ],
                ],
            ]
        );

        $this->add_control(
            'query_type_cart_notice',
            [
                'type' => Controls_Manager::RAW_HTML,
                'raw' => esc_html__( 'Shows the cross-sells of the products in the cart. Best used on the Cart page.', 'woolentor-pro' ),
                'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
                'condition' => [
                    'query_type' => 'cart_cross_sell',
                ],
            ]
        );
    }

}
