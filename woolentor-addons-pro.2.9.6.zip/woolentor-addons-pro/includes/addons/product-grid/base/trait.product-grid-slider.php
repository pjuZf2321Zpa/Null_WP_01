<?php
/**
 * Product Grid Slider Controls
 *
 * Reusable slider controls for the product grid widgets. Currently used by the
 * Modern widget; Luxury, Editorial and Magazine can adopt it with a single
 * `use` statement once their templates gain a slider branch.
 *
 * The control names follow the hero-banner convention (slider_arrows, not
 * slarrows) and the emitted settings match the JSON contract read by
 * WooLentorGridSlider() in woolentor-widgets-active.js.
 *
 * @package WooLentorPro
 */

namespace Elementor;

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

trait WooLentor_Product_Grid_Slider_Controls {

    /**
     * Slider Settings section.
     *
     * Slides-to-show lives here as dedicated Slider Items fields, alongside
     * Slides to Scroll, rather than reusing the responsive `columns` control.
     * The `columns` control is hidden while layout is slider (see
     * product_grid_modern.php) so there is only one "how many per view"
     * control visible at a time.
     */
    protected function register_slider_settings_controls() {

        $this->start_controls_section(
            'section_slider_settings',
            [
                'label'     => esc_html__( 'Slider Settings', 'woolentor-pro' ),
                'condition' => [
                    'layout' => 'slider',
                ],
            ]
        );

            $this->add_control(
                'slider_arrows',
                [
                    'label'        => esc_html__( 'Show Arrows', 'woolentor-pro' ),
                    'type'         => Controls_Manager::SWITCHER,
                    'return_value' => 'yes',
                    'default'      => 'yes',
                ]
            );

            $this->add_control(
                'slider_dots',
                [
                    'label'        => esc_html__( 'Show Dots', 'woolentor-pro' ),
                    'type'         => Controls_Manager::SWITCHER,
                    'return_value' => 'yes',
                    'default'      => 'yes',
                ]
            );

            $this->add_control(
                'slider_infinite',
                [
                    'label'        => esc_html__( 'Infinite Loop', 'woolentor-pro' ),
                    'type'         => Controls_Manager::SWITCHER,
                    'return_value' => 'yes',
                    'default'      => 'yes',
                ]
            );

            $this->add_control(
                'slider_autoplay',
                [
                    'label'        => esc_html__( 'Autoplay', 'woolentor-pro' ),
                    'type'         => Controls_Manager::SWITCHER,
                    'return_value' => 'yes',
                    'default'      => '',
                    'separator'    => 'before',
                ]
            );

            $this->add_control(
                'slider_autoplay_speed',
                [
                    'label'     => esc_html__( 'Autoplay Speed (ms)', 'woolentor-pro' ),
                    'type'      => Controls_Manager::NUMBER,
                    'default'   => 3000,
                    'min'       => 500,
                    'step'      => 100,
                    'condition' => [
                        'slider_autoplay' => 'yes',
                    ],
                ]
            );

            $this->add_control(
                'slider_speed',
                [
                    'label'   => esc_html__( 'Transition Speed (ms)', 'woolentor-pro' ),
                    'type'    => Controls_Manager::NUMBER,
                    'default' => 600,
                    'min'     => 100,
                    'step'    => 50,
                ]
            );

            $this->add_control(
                'slider_pause_on_hover',
                [
                    'label'        => esc_html__( 'Pause on Hover', 'woolentor-pro' ),
                    'type'         => Controls_Manager::SWITCHER,
                    'return_value' => 'yes',
                    'default'      => 'yes',
                    'condition'    => [
                        'slider_autoplay' => 'yes',
                    ],
                ]
            );

            $this->add_control(
                'slider_items',
                [
                    'label'        => esc_html__( 'Slider Items', 'woolentor-pro' ),
                    'type'         => Controls_Manager::NUMBER,
                    'default'      => 4,
                    'min'          => 1,
                    'step'         => 1,
                    'separator'    => 'before',
                    'prefix_class' => 'woolentor-slider-items-',
                ]
            );

            $this->add_control(
                'slider_scroll',
                [
                    'label'     => esc_html__( 'Slides to Scroll', 'woolentor-pro' ),
                    'type'      => Controls_Manager::NUMBER,
                    'default'   => 1,
                    'min'       => 1,
                    'step'      => 1,
                ]
            );

            $this->add_control(
                'slider_items_tablet',
                [
                    'label'        => esc_html__( 'Slider Items (Tablet)', 'woolentor-pro' ),
                    'type'         => Controls_Manager::NUMBER,
                    'default'      => 3,
                    'min'          => 1,
                    'step'         => 1,
                    'prefix_class' => 'woolentor-slider-items-tablet-',
                ]
            );

            $this->add_control(
                'slider_scroll_tablet',
                [
                    'label'   => esc_html__( 'Slides to Scroll (Tablet)', 'woolentor-pro' ),
                    'type'    => Controls_Manager::NUMBER,
                    'default' => 1,
                    'min'     => 1,
                    'step'    => 1,
                ]
            );

            $this->add_control(
                'slider_items_mobile',
                [
                    'label'        => esc_html__( 'Slider Items (Mobile)', 'woolentor-pro' ),
                    'type'         => Controls_Manager::NUMBER,
                    'default'      => 1,
                    'min'          => 1,
                    'step'         => 1,
                    'prefix_class' => 'woolentor-slider-items-mobile-',
                ]
            );

            $this->add_control(
                'slider_scroll_mobile',
                [
                    'label'   => esc_html__( 'Slides to Scroll (Mobile)', 'woolentor-pro' ),
                    'type'    => Controls_Manager::NUMBER,
                    'default' => 1,
                    'min'     => 1,
                    'step'    => 1,
                ]
            );

            $this->add_control(
                'slider_breakpoint_heading',
                [
                    'label'     => esc_html__( 'Breakpoints', 'woolentor-pro' ),
                    'type'      => Controls_Manager::HEADING,
                    'separator' => 'before',
                ]
            );

            $this->add_control(
                'slider_tablet_width',
                [
                    'label'       => esc_html__( 'Tablet Resolution', 'woolentor-pro' ),
                    'description' => esc_html__( 'Screen width in pixels below which the tablet column count applies.', 'woolentor-pro' ),
                    'type'        => Controls_Manager::NUMBER,
                    'default'     => 750,
                    'min'         => 1,
                ]
            );

            $this->add_control(
                'slider_mobile_width',
                [
                    'label'       => esc_html__( 'Mobile Resolution', 'woolentor-pro' ),
                    'description' => esc_html__( 'Screen width in pixels below which the mobile column count applies.', 'woolentor-pro' ),
                    'type'        => Controls_Manager::NUMBER,
                    'default'     => 480,
                    'min'         => 1,
                ]
            );

        $this->end_controls_section();
    }

    /**
     * Slider Controller Style section.
     * Filled in by the style task; declared here so the trait's surface is
     * complete from the start.
     */
    protected function register_slider_style_controls() {

        $this->start_controls_section(
            'section_slider_controller_style',
            [
                'label'     => esc_html__( 'Slider Controller Style', 'woolentor-pro' ),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'layout' => 'slider',
                ],
            ]
        );

            $this->start_controls_tabs( 'slider_controller_tabs' );

                $this->start_controls_tab(
                    'slider_controller_normal',
                    [
                        'label' => esc_html__( 'Normal', 'woolentor-pro' ),
                    ]
                );

                    $this->add_control(
                        'slider_arrow_heading',
                        [
                            'label' => esc_html__( 'Navigation Arrow', 'woolentor-pro' ),
                            'type'  => Controls_Manager::HEADING,
                        ]
                    );

                    $this->add_responsive_control(
                        'slider_arrow_position',
                        [
                            'label'      => esc_html__( 'Position (Top)', 'woolentor-pro' ),
                            'type'       => Controls_Manager::SLIDER,
                            'size_units' => [ 'px', '%' ],
                            'range'      => [
                                'px' => [ 'min' => 0, 'max' => 1000, 'step' => 1 ],
                                '%'  => [ 'min' => 0, 'max' => 100 ],
                            ],
                            'selectors'  => [
                                '{{WRAPPER}} .woolentor-grid-nav' => 'top: {{SIZE}}{{UNIT}};',
                            ],
                        ]
                    );

                    $this->add_control(
                        'slider_arrow_color',
                        [
                            'label'     => esc_html__( 'Color', 'woolentor-pro' ),
                            'type'      => Controls_Manager::COLOR,
                            'selectors' => [
                                '{{WRAPPER}} .woolentor-grid-nav' => 'color: {{VALUE}};',
                            ],
                        ]
                    );

                    $this->add_control(
                        'slider_arrow_bg',
                        [
                            'label'     => esc_html__( 'Background Color', 'woolentor-pro' ),
                            'type'      => Controls_Manager::COLOR,
                            'selectors' => [
                                '{{WRAPPER}} .woolentor-grid-nav' => 'background-color: {{VALUE}};',
                            ],
                        ]
                    );

                    $this->add_group_control(
                        Group_Control_Border::get_type(),
                        [
                            'name'     => 'slider_arrow_border',
                            'selector' => '{{WRAPPER}} .woolentor-grid-nav',
                        ]
                    );

                    $this->add_responsive_control(
                        'slider_arrow_border_radius',
                        [
                            'label'      => esc_html__( 'Border Radius', 'woolentor-pro' ),
                            'type'       => Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px', '%' ],
                            'selectors'  => [
                                '{{WRAPPER}} .woolentor-grid-nav' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            ],
                        ]
                    );

                    $this->add_responsive_control(
                        'slider_arrow_size',
                        [
                            'label'      => esc_html__( 'Icon Size', 'woolentor-pro' ),
                            'type'       => Controls_Manager::SLIDER,
                            'size_units' => [ 'px' ],
                            'range'      => [
                                'px' => [ 'min' => 8, 'max' => 60, 'step' => 1 ],
                            ],
                            'selectors'  => [
                                '{{WRAPPER}} .woolentor-grid-nav svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                            ],
                        ]
                    );

                    $this->add_responsive_control(
                        'slider_arrow_box_size',
                        [
                            'label'      => esc_html__( 'Button Size', 'woolentor-pro' ),
                            'type'       => Controls_Manager::SLIDER,
                            'size_units' => [ 'px' ],
                            'range'      => [
                                'px' => [ 'min' => 20, 'max' => 100, 'step' => 1 ],
                            ],
                            'selectors'  => [
                                '{{WRAPPER}} .woolentor-grid-nav' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                            ],
                        ]
                    );

                    $this->add_control(
                        'slider_dots_heading',
                        [
                            'label'     => esc_html__( 'Navigation Dots', 'woolentor-pro' ),
                            'type'      => Controls_Manager::HEADING,
                            'separator' => 'before',
                        ]
                    );

                    $this->add_responsive_control(
                        'slider_dots_spacing',
                        [
                            'label'      => esc_html__( 'Top Spacing', 'woolentor-pro' ),
                            'type'       => Controls_Manager::SLIDER,
                            'size_units' => [ 'px' ],
                            'range'      => [
                                'px' => [ 'min' => 0, 'max' => 100, 'step' => 1 ],
                            ],
                            'selectors'  => [
                                '{{WRAPPER}} .woolentor-grid-dots' => 'margin-top: {{SIZE}}{{UNIT}};',
                            ],
                        ]
                    );

                    $this->add_control(
                        'slider_dots_bg',
                        [
                            'label'     => esc_html__( 'Background Color', 'woolentor-pro' ),
                            'type'      => Controls_Manager::COLOR,
                            'selectors' => [
                                '{{WRAPPER}} .woolentor-grid-dots li button' => 'background-color: {{VALUE}};',
                            ],
                        ]
                    );

                    $this->add_control(
                        'slider_dots_active_bg',
                        [
                            'label'     => esc_html__( 'Active Color', 'woolentor-pro' ),
                            'type'      => Controls_Manager::COLOR,
                            'selectors' => [
                                '{{WRAPPER}} .woolentor-grid-dots li.slick-active button' => 'background-color: {{VALUE}};',
                            ],
                        ]
                    );

                    $this->add_group_control(
                        Group_Control_Border::get_type(),
                        [
                            'name'     => 'slider_dots_border',
                            'selector' => '{{WRAPPER}} .woolentor-grid-dots li button',
                        ]
                    );

                    $this->add_responsive_control(
                        'slider_dots_border_radius',
                        [
                            'label'      => esc_html__( 'Border Radius', 'woolentor-pro' ),
                            'type'       => Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px', '%' ],
                            'selectors'  => [
                                '{{WRAPPER}} .woolentor-grid-dots li button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            ],
                        ]
                    );

                $this->end_controls_tab();

                $this->start_controls_tab(
                    'slider_controller_hover',
                    [
                        'label' => esc_html__( 'Hover', 'woolentor-pro' ),
                    ]
                );

                    $this->add_control(
                        'slider_arrow_hover_heading',
                        [
                            'label' => esc_html__( 'Navigation Arrow', 'woolentor-pro' ),
                            'type'  => Controls_Manager::HEADING,
                        ]
                    );

                    $this->add_control(
                        'slider_arrow_color_hover',
                        [
                            'label'     => esc_html__( 'Color', 'woolentor-pro' ),
                            'type'      => Controls_Manager::COLOR,
                            'selectors' => [
                                '{{WRAPPER}} .woolentor-grid-nav:hover' => 'color: {{VALUE}};',
                            ],
                        ]
                    );

                    $this->add_control(
                        'slider_arrow_bg_hover',
                        [
                            'label'     => esc_html__( 'Background Color', 'woolentor-pro' ),
                            'type'      => Controls_Manager::COLOR,
                            'selectors' => [
                                '{{WRAPPER}} .woolentor-grid-nav:hover' => 'background-color: {{VALUE}};',
                            ],
                        ]
                    );

                    $this->add_group_control(
                        Group_Control_Border::get_type(),
                        [
                            'name'     => 'slider_arrow_border_hover',
                            'selector' => '{{WRAPPER}} .woolentor-grid-nav:hover',
                        ]
                    );

                    $this->add_control(
                        'slider_dots_hover_heading',
                        [
                            'label'     => esc_html__( 'Navigation Dots', 'woolentor-pro' ),
                            'type'      => Controls_Manager::HEADING,
                            'separator' => 'before',
                        ]
                    );

                    $this->add_control(
                        'slider_dots_bg_hover',
                        [
                            'label'     => esc_html__( 'Background Color', 'woolentor-pro' ),
                            'type'      => Controls_Manager::COLOR,
                            'selectors' => [
                                '{{WRAPPER}} .woolentor-grid-dots li button:hover' => 'background-color: {{VALUE}};',
                            ],
                        ]
                    );

                $this->end_controls_tab();

            $this->end_controls_tabs();

        $this->end_controls_section();
    }

    /**
     * Map the slider controls onto the settings the renderer reads.
     *
     * @param array $settings Raw Elementor settings.
     * @return array
     */
    protected function map_slider_settings( $settings ) {

        // Cross-repo contract: these keys (including slider_items,
        // slider_items_tablet, slider_items_mobile) must match woolentor-addons'
        // class.product-grid-base.php::get_slider_settings_json() and the
        // `defaults` object in woolentor-widgets-active.js::WooLentorGridSlider().
        // A rename here without updating both silently falls back to a default.
        $get = function( $key, $default = null ) use ( $settings ) {
            return isset( $settings[ $key ] ) ? $settings[ $key ] : $default;
        };

        return [
            'slider_arrows'         => 'yes' === $get( 'slider_arrows', 'yes' ),
            'slider_dots'           => 'yes' === $get( 'slider_dots', 'yes' ),
            'slider_infinite'       => 'yes' === $get( 'slider_infinite', 'yes' ),
            'slider_autoplay'       => 'yes' === $get( 'slider_autoplay', '' ),
            'slider_autoplay_speed' => absint( $get( 'slider_autoplay_speed', 3000 ) ),
            'slider_speed'          => absint( $get( 'slider_speed', 600 ) ),
            'slider_pause_on_hover' => 'yes' === $get( 'slider_pause_on_hover', 'yes' ),
            'slider_items'          => absint( $get( 'slider_items', 4 ) ),
            'slider_items_tablet'   => absint( $get( 'slider_items_tablet', 3 ) ),
            'slider_items_mobile'   => absint( $get( 'slider_items_mobile', 1 ) ),
            'slider_scroll'         => absint( $get( 'slider_scroll', 1 ) ),
            'slider_scroll_tablet'  => absint( $get( 'slider_scroll_tablet', 1 ) ),
            'slider_scroll_mobile'  => absint( $get( 'slider_scroll_mobile', 1 ) ),
            'slider_tablet_width'   => absint( $get( 'slider_tablet_width', 750 ) ),
            'slider_mobile_width'   => absint( $get( 'slider_mobile_width', 480 ) ),
        ];
    }
}
