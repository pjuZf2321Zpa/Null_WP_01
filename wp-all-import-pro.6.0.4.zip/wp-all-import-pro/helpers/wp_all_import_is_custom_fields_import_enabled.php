<?php

function wp_all_import_is_custom_fields_import_enabled( $import_id, $options ) {
    $custom_type = isset( $options['custom_type'] ) ? $options['custom_type'] : '';

    if ( wp_all_import_user_meta_requires_addon_pro( $custom_type ) ) {
        return false;
    }

    return (bool) apply_filters( 'pmxi_is_custom_fields_import_enabled', true, $import_id, $options );
}
