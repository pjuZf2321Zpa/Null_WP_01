<?php

function wp_all_import_sanitize_scheduling_times( $times ) {

	if ( ! is_array( $times ) ) {
		return array();
	}

	$sanitized = array();

	foreach ( $times as $time ) {
		$time = trim( (string) $time );

		if ( $time === '' ) {
			continue;
		}

		$normalized = wp_all_import_normalize_scheduling_time( $time );

		if ( $normalized === false ) {
			return false;
		}

		$sanitized[] = $normalized;
	}

	return $sanitized;
}

function wp_all_import_normalize_scheduling_time( $time ) {

	if ( preg_match( '/^(0?[1-9]|1[0-2])(?::([0-5]\d))?\s*([ap])\.?m\.?$/i', $time, $m ) ) {
		return (int) $m[1] . ':' . ( $m[2] === '' ? '00' : $m[2] ) . strtolower( $m[3] ) . 'm';
	}

	if ( preg_match( '/^([01]?\d|2[0-3]):([0-5]\d)$/', $time, $m ) ) {
		$hour = (int) $m[1];
		$meridiem = $hour < 12 ? 'am' : 'pm';
		$hour = $hour % 12;
		return ( $hour === 0 ? 12 : $hour ) . ':' . $m[2] . $meridiem;
	}

	return false;
}
