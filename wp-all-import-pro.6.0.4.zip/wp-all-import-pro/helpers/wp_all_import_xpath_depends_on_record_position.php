<?php

// Records are counted one chunk at a time but imported in batches under a shared
// <pmxi_records> parent, so anything that looks at a record's position among its
// siblings, or outside the record, selects different records at each stage.
// Positions deeper inside the record are unaffected.
if ( ! function_exists( 'wp_all_import_xpath_depends_on_record_position' ) ) {
	function wp_all_import_xpath_depends_on_record_position( $xpath ) {
		$xpath = wp_all_import_xpath_blank_literals( trim( (string) $xpath ) );

		if ( preg_match( '/(?<![\w.-])(preceding|following)\s*::/', $xpath ) ) {
			return true;
		}

		foreach ( wp_all_import_xpath_split_top_level( $xpath, '|' ) as $branch ) {
			foreach ( wp_all_import_xpath_first_step_predicates( trim( $branch ) ) as $predicate ) {
				if ( wp_all_import_xpath_predicate_is_positional( $predicate ) ) {
					return true;
				}
			}
		}

		return false;
	}
}

if ( ! function_exists( 'wp_all_import_xpath_blank_literals' ) ) {
	function wp_all_import_xpath_blank_literals( $xpath ) {
		return preg_replace_callback( '/"[^"]*"|\'[^\']*\'/', function ( $m ) {
			return $m[0][0] . str_repeat( ' ', strlen( $m[0] ) - 2 ) . $m[0][0];
		}, $xpath );
	}
}

if ( ! function_exists( 'wp_all_import_xpath_split_top_level' ) ) {
	function wp_all_import_xpath_split_top_level( $xpath, $separator ) {
		$parts = array();
		$depth = 0;
		$start = 0;
		for ( $i = 0, $n = strlen( $xpath ); $i < $n; $i++ ) {
			$c = $xpath[ $i ];
			if ( '[' === $c || '(' === $c ) {
				$depth++;
			} elseif ( ']' === $c || ')' === $c ) {
				$depth--;
			} elseif ( $separator === $c && 0 === $depth ) {
				$parts[] = substr( $xpath, $start, $i - $start );
				$start   = $i + 1;
			}
		}
		$parts[] = substr( $xpath, $start );
		return $parts;
	}
}

if ( ! function_exists( 'wp_all_import_xpath_first_step_predicates' ) ) {
	// The bodies of the predicates attached to the step that selects the record
	// itself, or to a parenthesized expression as a whole.
	function wp_all_import_xpath_first_step_predicates( $branch ) {
		$n = strlen( $branch );
		$i = 0;

		if ( $n && '(' === $branch[0] ) {
			$close = wp_all_import_xpath_matching( $branch, 0 );
			if ( false === $close ) {
				return array();
			}
			$inner = substr( $branch, 1, $close - 1 );
			$found = array();
			foreach ( wp_all_import_xpath_split_top_level( $inner, '|' ) as $part ) {
				$found = array_merge( $found, wp_all_import_xpath_first_step_predicates( trim( $part ) ) );
			}
			$i = $close + 1;
		} else {
			$found = array();
			while ( $i < $n && '/' === $branch[ $i ] ) {
				$i++;
			}
			while ( $i < $n && '[' !== $branch[ $i ] && '/' !== $branch[ $i ] ) {
				$i++;
			}
		}

		while ( $i < $n ) {
			while ( $i < $n && ctype_space( $branch[ $i ] ) ) {
				$i++;
			}
			if ( $i >= $n || '[' !== $branch[ $i ] ) {
				break;
			}
			$close = wp_all_import_xpath_matching( $branch, $i );
			if ( false === $close ) {
				break;
			}
			$found[] = substr( $branch, $i + 1, $close - $i - 1 );
			$i       = $close + 1;
		}

		return $found;
	}
}

if ( ! function_exists( 'wp_all_import_xpath_matching' ) ) {
	function wp_all_import_xpath_matching( $xpath, $open ) {
		$depth = 0;
		for ( $i = $open, $n = strlen( $xpath ); $i < $n; $i++ ) {
			$c = $xpath[ $i ];
			if ( '[' === $c || '(' === $c ) {
				$depth++;
			} elseif ( ']' === $c || ')' === $c ) {
				$depth--;
				if ( 0 === $depth ) {
					return $i;
				}
			}
		}
		return false;
	}
}

if ( ! function_exists( 'wp_all_import_xpath_predicate_is_positional' ) ) {
	function wp_all_import_xpath_predicate_is_positional( $predicate ) {
		// Nested predicates belong to steps inside the record.
		do {
			$predicate = preg_replace( '/\[[^\[\]]*\]/', '', $predicate, -1, $count );
		} while ( $count );

		if ( preg_match( '/(?<![\w.-])(position|last)\s*\(|(preceding|following)-sibling\s*::/', $predicate ) ) {
			return true;
		}

		// A predicate that evaluates to a number is compared with position().
		if ( preg_match( '/[=<>]|(?<![\w.-])(and|or)(?![\w.-])/', $predicate ) ) {
			return false;
		}
		$predicate = trim( $predicate );
		return (bool) preg_match( '/^(?:[\d\s.+*()-]|(?<![\w.-])(?:div|mod)(?![\w.-]))*\d(?:[\d\s.+*()-]|(?<![\w.-])(?:div|mod)(?![\w.-]))*$/', $predicate )
			|| (bool) preg_match( '/^(count|number|sum|floor|ceiling|round|string-length)\s*\(/', $predicate );
	}
}

if ( ! function_exists( 'wp_all_import_xpath_record_position_warning' ) ) {
	function wp_all_import_xpath_record_position_warning() {
		return __( '<strong>Warning:</strong> this XPath selects records by their position, such as [1] or last(), which WP All Import can\'t apply reliably, so records may be skipped. Filter on a value inside each record instead.', 'wp-all-import-pro' );
	}
}
