<?php

function wp_all_import_meta_keys_lookup_table( $custom_type ) {
    switch ( $custom_type ) {
        case 'import_users':
        case 'shop_customer':
            return 'usermeta';
        case 'taxonomies':
            return 'termmeta';
        case 'comments':
        case 'woo_reviews':
            return 'commentmeta';
    }

    return function_exists( 'post_type_exists' ) && post_type_exists( (string) $custom_type ) ? 'postmeta' : false;
}

function wp_all_import_meta_keys_groups( $custom_type, $with_variations = true ) {
    return 'product' === $custom_type && $with_variations ? array( 'product', 'product_variation' ) : array( (string) $custom_type );
}

function wp_all_import_search_meta_keys( $custom_type, $term = '', $limit = 20, $budget = 1.0, $with_variations = true ) {
    // These keys exist to fill the Custom Fields section, and for a user import
    // without the add-on that section is removed before it renders. Answering
    // would serve what the section itself is not allowed to show.
    if ( wp_all_import_user_meta_requires_addon_pro( $custom_type ) ) {
        return array();
    }

    $index = \Wpai\WordPress\MetaKeyIndex::forTable( (string) wp_all_import_meta_keys_lookup_table( $custom_type ) );
    if ( ! $index ) {
        return array();
    }

    $table     = wp_all_import_meta_keys_lookup_table( $custom_type );
    $groups    = wp_all_import_meta_keys_groups( $custom_type, $with_variations );
    $prefilter = null;

    $hidden = array();
    if ( 'postmeta' === $table ) {
        $hidden    = array_flip( array( '_edit_lock', '_edit_last', '_wp_trash_meta_status', '_wp_trash_meta_time' ) );
        $prefilter = function ( $keys ) use ( $custom_type ) {
            return apply_filters( 'wp_all_import_existing_meta_keys', $keys, $custom_type );
        };
    } elseif ( in_array( $custom_type, array( 'import_users', 'shop_customer' ), true ) ) {
        $hidden = array( 'first_name', 'last_name', 'nickname', 'description', PMXI_Plugin::getInstance()->getWPPrefix() . 'capabilities' );
        if ( 'shop_customer' === $custom_type ) {
            $hidden = array_merge( $hidden, array( 'billing_first_name', 'billing_last_name', 'billing_company', 'billing_address_1', 'billing_address_2', 'billing_city', 'billing_postcode', 'billing_country', 'billing_state', 'billing_phone', 'billing_email', 'shipping_first_name', 'shipping_last_name', 'shipping_company', 'shipping_address_1', 'shipping_address_2', 'shipping_city', 'shipping_postcode', 'shipping_country', 'shipping_state' ) );
        }
        $hidden = array_flip( array_map( 'strtolower', $hidden ) );
    }

    if ( 'postmeta' === $table ) {
        $exclude = function ( $key ) use ( $hidden ) {
            return isset( $hidden[ $key ] );
        };
    } else {
        $exclude = $hidden ? function ( $key ) use ( $hidden ) {
            return isset( $hidden[ strtolower( $key ) ] ) || 0 === strncasecmp( $key, '_wp', 3 );
        } : null;
    }

    return $index->search( (string) $term, $limit, $exclude, $budget, $groups, $prefilter );
}

/**
 * One key, enough to decide whether to offer See Detected Fields. While the key list is
 * still being collected an empty answer proves nothing, so the button stays on offer.
 */
function wp_all_import_probe_meta_keys( $custom_type ) {
    $keys = wp_all_import_search_meta_keys( $custom_type, '', 1, 0 );
    if ( $keys ) {
        return $keys;
    }
    $table = wp_all_import_meta_keys_lookup_table( $custom_type );
    $index = $table ? \Wpai\WordPress\MetaKeyIndex::forTable( $table ) : null;

    return $index && ! $index->isSettled( wp_all_import_meta_keys_groups( $custom_type ) ) ? array( '' ) : array();
}

/**
 * The whole key list when it is complete and short enough to send with the page, so the
 * autocomplete matches in the browser rather than loading WordPress once per word typed.
 *
 * @return string[]|null null when the field autocomplete should look keys up instead
 */
function wp_all_import_embedded_meta_keys( $custom_type, $max = 2000 ) {
    $table = wp_all_import_meta_keys_lookup_table( $custom_type );
    $index = $table ? \Wpai\WordPress\MetaKeyIndex::forTable( $table ) : null;
    if ( ! $index ) {
        return null;
    }

    $keys = wp_all_import_search_meta_keys( $custom_type, '', $max + 1, 0 );

    return count( $keys ) <= $max && $index->isSettled( wp_all_import_meta_keys_groups( $custom_type ) ) ? array_values( array_filter( $keys, 'strlen' ) ) : null;
}

function wp_all_import_meta_keys_collecting( $custom_type ) {
    $table = wp_all_import_meta_keys_lookup_table( $custom_type );
    $index = $table ? \Wpai\WordPress\MetaKeyIndex::forTable( $table ) : null;

    return $index && ! $index->isComplete();
}

/**
 * The fields See Detected Fields offers: each key with a sample value, at most 500.
 *
 * @return array<int, array{key: string, val: string, is_serialized: bool}>
 */
function wp_all_import_detect_custom_fields( $post_type ) {
    global $wpdb;

    $ignoreFields = array(
        '_edit_lock', '_edit_last', '_wp_trash_meta_status', '_wp_trash_meta_time', '_visibility', '_stock_status', '_downloadable', '_virtual', '_regular_price', '_sale_price', '_purchase_note', '_featured', '_weight', '_length',
        '_width', '_height', '_sku', '_sale_price_dates_from', '_sale_price_dates_to', '_price', '_sold_individually', '_manage_stock', '_stock', '_upsell_ids', '_crosssell_ids','_downloadable_files', '_download_limit', '_download_expiry', '_download_type', '_product_url', '_button_text', '_backorders', '_tax_status', '_tax_class', '_product_image_gallery', '_default_attributes','total_sales', '_product_attributes', '_product_version', '_thumbnail_id', '_is_first_variation_created', '_regular_price_tmp', '_sale_price_tmp', '_price_tmp', '_stock_tmp',
        '_order_total', '_order_version', '_order_tax', '_order_shipping_tax', '_order_shipping', '_cart_discount_tax', '_cart_discount', '_order_currency', '_order_key', '_prices_include_tax'
    );
    if ( 'shop_customer' === $post_type ) {
        $ignoreFields = array_merge( $ignoreFields, array( 'first_name', 'last_name', 'nickname', 'description', PMXI_Plugin::getInstance()->getWPPrefix() . 'capabilities' ),
            array( 'billing_first_name', 'billing_last_name', 'billing_company', 'billing_address_1', 'billing_address_2', 'billing_city', 'billing_postcode', 'billing_country', 'billing_state', 'billing_phone', 'billing_email' ),
            array( 'shipping_first_name', 'shipping_last_name', 'shipping_company', 'shipping_address_1', 'shipping_address_2', 'shipping_city', 'shipping_postcode', 'shipping_country', 'shipping_state' ) );
    }

    $table = wp_all_import_meta_keys_lookup_table( $post_type );
    if ( ! $table ) {
        return array();
    }
    $table     = $wpdb->$table;
    $id_column = $table === $wpdb->usermeta ? 'umeta_id' : 'meta_id';

    // The whole list, not its first 500 alphabetically: repeater rows and ignored keys are skipped below.
    $fields = wp_all_import_search_meta_keys( $post_type, '', \Wpai\WordPress\MetaKeyIndex::MAX_KEYS * 2, 5, false );
    $result = array();

    foreach ( (array) $fields as $field ) {
        if ( count( $result ) >= 500 ) {
            break;
        }
        if ( empty( $field )
            || in_array( $field, $ignoreFields )
            || strpos( $field, '_max_' ) === 0
            || strpos( $field, '_min_' ) === 0 || preg_match( '%_[0-9]{1,}_%', $field )
            || ( 'shop_order' === $post_type && ( strpos( $field, '_billing' ) === 0 || strpos( $field, '_shipping' ) === 0 ) ) ) {
            continue;
        }
        // Judge the first 200 values by length on the server, as empty() would, so only the chosen one is loaded.
        $value = null;
        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table and column come from the lookup above.
        foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT {$id_column} AS id, LENGTH(meta_value) AS bytes, meta_value = '0' AS zero FROM {$table} WHERE meta_key = %s LIMIT 200", $field ), ARRAY_A ) as $row ) {
            if ( (int) $row['bytes'] > 1 || ( 1 === (int) $row['bytes'] && ! (int) $row['zero'] ) ) {
                // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
                $value = $wpdb->get_var( $wpdb->prepare( "SELECT meta_value FROM {$table} WHERE {$id_column} = %d", $row['id'] ) );
                break;
            }
        }
        if ( null !== $value ) {
            $result[] = array(
                'key'           => $field,
                'val'           => $value,
                'is_serialized' => is_serialized( $value ),
            );
        }
    }

    return $result;
}
