<?php
if ( ! function_exists('wp_all_import_rand_char')){

	/**
	 * Callers pass the result through wp_all_import_url_title(), which strips anything
	 * outside [A-Za-z0-9._-] — widening this alphabet silently shortens the result.
	 */
	function wp_all_import_rand_char($length) {
		$length = max(1, (int) $length);

		if (function_exists('wp_generate_password')) {
			return wp_generate_password($length, false, false);
		}

		$alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
		$max      = strlen($alphabet) - 1;
		$random   = '';

		for ($i = 0; $i < $length; $i++) {
			$random .= $alphabet[function_exists('random_int') ? random_int(0, $max) : mt_rand(0, $max)];
		}

		return $random;
	}
}