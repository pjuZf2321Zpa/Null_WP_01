<?php

function wp_all_import_user_meta_requires_addon_pro( $custom_type ) {
    return in_array( $custom_type, array( 'import_users', 'shop_customer' ), true )
        && ! wp_all_import_is_user_addon_pro_active();
}
