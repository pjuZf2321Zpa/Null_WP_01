<?php

function wp_all_import_is_user_addon_pro_active() {
    return defined('PMUI_PRO_VERSION') || ( defined('PMUI_EDITION') && 'paid' === PMUI_EDITION );
}
