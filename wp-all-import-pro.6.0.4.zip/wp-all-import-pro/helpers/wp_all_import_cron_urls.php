<?php

/**
 * The cron URLs for an import, or the site-wide ones when no import is named.
 *
 * One builder, because there were two: the settings controller composed the
 * cleanup URL and the scheduling dialog's template composed the per-import
 * pair. They had already drifted apart on the host, the template using
 * site_url() and the controller home_url(). wp-load.php is a WordPress file, so
 * site_url() is the correct one and home_url() 404s wherever a site is served
 * from a different path than WordPress is installed at.
 *
 * @param  string    $cron_job_key  The secret key from the settings screen.
 * @param  int|null  $import_id     An import, or null for the site-wide actions.
 * @return array<string,string>     Action name => URL.
 */
function wp_all_import_cron_urls($cron_job_key, $import_id = null) {
	$base = site_url('/wp-load.php') . '?import_key=' . rawurlencode(is_scalar($cron_job_key) ? (string) $cron_job_key : '');

	if ($import_id === null) {
		return array('cleanup' => $base . '&action=cleanup');
	}

	$base .= '&import_id=' . rawurlencode((string) $import_id);

	return array(
		// Both, always: the trigger starts a run and the processing URL advances
		// it, so a cron job set up with only the first never finishes an import.
		'trigger'    => $base . '&action=trigger',
		'processing' => $base . '&action=processing',
	);
}
