<?php

use Wpai\Scheduling\Scheduling;

/**
 * @throws Exception
 */
function pmxi_wp_ajax_save_import_scheduling()
{

    if ( ! check_ajax_referer( 'wp_all_import_secure', 'security', false )){
        exit( json_encode(array('html' => __('Security check', 'wp-all-import-pro'))) );
    }

    if ( ! current_user_can( PMXI_Plugin::$capabilities ) ){
        exit( json_encode(array('html' => __('Security check', 'wp-all-import-pro'))) );
    }

    $elementId = $_POST['element_id'];

    $post = $_POST;

    if (isset($post['scheduling_times'])) {
        $times = wp_all_import_sanitize_scheduling_times($post['scheduling_times']);

        if ($times === false) {
            if (!empty($post['scheduling_enable'])) {
                header('HTTP/1.1 400 Bad request', true, 400);
                die('Invalid times provided');
            }
            // The time inputs are hidden while scheduling is off, so a disabled schedule keeps the times it already has.
            unset($post['scheduling_times']);
        } else {
            $post['scheduling_times'] = $times;
        }
    }

    try{
        $scheduling = Scheduling::create();
        $scheduling->handleScheduling($elementId, $post);
    } catch (\Wpai\Scheduling\Exception\SchedulingHttpException $e) {
        header('HTTP/1.1 503 Service unavailable', true, 503);
        echo json_encode(array('success' => false));

        die;
    }

    $import = new PMXI_Import_Record();
    $import->getbyId($elementId);
    $import->set(array('options' => array_merge($import->options, $post)));
    $import->save();

    echo json_encode(array('success' => true));
    die;
}
