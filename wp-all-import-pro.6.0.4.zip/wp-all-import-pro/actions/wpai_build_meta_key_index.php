<?php

function pmxi_wpai_build_meta_key_index( $table = '' ) {
	$index = \Wpai\WordPress\MetaKeyIndex::forTable( (string) $table );
	if ( $index ) {
		$index->advance( 10 );
	}
}
