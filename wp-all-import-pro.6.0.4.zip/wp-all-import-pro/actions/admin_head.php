<?php
function pmxi_admin_head(){
	$input = new PMXI_Input();
	$get_params = $input->get(array(
		'id' => false,
		'action' => false
	));
	
	// This runs on every admin page, so the id belongs to whoever put it in the
	// URL — WooCommerce's order list submits id[], which reaches the echo below
	// as an array.
	//
	// Emitted verbatim once it passes, rather than cast: every consumer in
	// admin.js sends import_id straight back as the id of the next request, so
	// it has to name the same session PMXI_Handler resolved for this one. A
	// cast would rewrite '007' to '7' and the two would then disagree.
	if ( PMXI_Handler::is_usable_import_id( $get_params['id'] ) ) {
		?>
		<script type="text/javascript">
			var import_id = '<?php echo esc_js( (string) $get_params["id"] ); ?>';
		</script>
		<?php
	}

	$wp_all_import_ajax_nonce = '';

	if ( get_current_user_id() and current_user_can( PMXI_Plugin::$capabilities )) {

		$wp_all_import_ajax_nonce = wp_create_nonce( "wp_all_import_secure" );		

	}

	?>
	<script type="text/javascript">
		var ajaxurl = '<?php echo esc_url( admin_url( "admin-ajax.php" ) ); ?>';
		var import_action = '<?php echo esc_js( is_scalar( $get_params["action"] ) ? (string) $get_params["action"] : '' ); ?>';
		var wp_all_import_security = '<?php echo esc_js( wp_unslash( $wp_all_import_ajax_nonce ) ); ?>';
	</script>
	<?php
}