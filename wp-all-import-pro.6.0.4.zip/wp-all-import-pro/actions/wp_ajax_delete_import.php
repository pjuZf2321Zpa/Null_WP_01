<?php
function pmxi_wp_ajax_delete_import(){

	if ( ! check_ajax_referer( 'wp_all_import_secure', 'security', false )){
		exit( json_encode(array('result' => false, 'error' => true, 'msg' => __('Security check', 'wp-all-import-pro'))) );
	}

	if ( ! current_user_can( PMXI_Plugin::$capabilities ) ){
		exit( json_encode(array('result' => false, 'error' => true, 'msg' => __('Security check', 'wp-all-import-pro'))) );
	}

	$input = new PMXI_Input();

	$post = $input->post(array(
		'data' => '',
		'iteration' => 1,
		'import_id' => 0
	));

	$params = array();
	parse_str($post['data'], $params);

	$response = array(
		'result' => false,
		'msg' => ''
	);

	$import_ids = array();
	if ( ! empty($params['import_ids']) && is_array($params['import_ids']) ) {
		$import_ids = array_values(array_unique(array_filter(array_map('intval', $params['import_ids']))));
	}

	if ( empty($import_ids) ) {
		$response['error'] = true;
		exit( json_encode( $response ));
	}

	$current_import_id = (int) $post['import_id'];
	if ( ! $current_import_id ) {
		$current_import_id = $import_ids[0];
	}
	$current_index = array_search($current_import_id, $import_ids, true);
	if ( $current_index === false ) {
		$response['error'] = true;
		exit( json_encode( $response ));
	}
	$is_last_import = ! isset($import_ids[$current_index + 1]);

	$is_delete_import = ! empty($params['is_delete_import']);
	$is_delete_posts = ! empty($params['is_delete_posts']);
	$is_delete_images = isset($params['is_delete_images']) ? $params['is_delete_images'] : 'no';
	$is_delete_attachments = isset($params['is_delete_attachments']) ? $params['is_delete_attachments'] : 'no';
	$is_bulk_delete = ! empty($params['is_bulk_delete']);
	$base_url = isset($params['base_url']) ? $params['base_url'] : '';

	$import = new PMXI_Import_Record();
	$import->getById($current_import_id);

	$cpt_name = '';
	if ( ! $import->isEmpty() && ! empty($import['options']['custom_type']) ) {
		switch ($import['options']['custom_type']) {
			case 'taxonomies':
				$tx = get_taxonomy($import['options']['taxonomy_type']);
				$custom_type = new stdClass();
				$custom_type->label = empty($tx->labels->name) ? __('Taxonomy Terms', 'wp-all-import-pro') : $tx->labels->name;
				break;
			case 'import_users':
				$custom_type = new stdClass();
				$custom_type->label = __('Users', 'wp-all-import-pro');
				break;
			case 'woo_reviews':
			case 'comments':
				$custom_type = new stdClass();
				$custom_type->label = __('Comments', 'wp-all-import-pro');
				break;
			case 'shop_customer':
				$custom_type = new stdClass();
				$custom_type->label = __('Customers', 'wp-all-import-pro');
				break;
			default:
				$custom_type = wp_all_import_custom_type( $import['options']['custom_type'] );
				break;
		}
		$cpt_name = ( ! empty($custom_type)) ? strtolower($custom_type->label) : '';
	}

	if ( $is_bulk_delete && $is_delete_import ) {
		$imports_count = count($import_ids);
		$response['redirect'] = esc_url_raw(add_query_arg('pmxi_nt', urlencode(sprintf(__('%d %s deleted', 'wp-all-import-pro'), $imports_count, _n('import', 'imports', $imports_count, 'wp-all-import-pro'))), $base_url));
	} elseif ( $is_delete_import and ! $is_delete_posts ) {
		$response['redirect'] = esc_url_raw(add_query_arg('pmxi_nt', urlencode(__('Import deleted', 'wp-all-import-pro')), $base_url));
	} elseif( ! $is_delete_import and $is_delete_posts) {
		$response['redirect'] = esc_url_raw(add_query_arg('pmxi_nt', urlencode(sprintf(__('All associated %s deleted.', 'wp-all-import-pro'), $cpt_name)), $base_url));
	} elseif( $is_delete_import and $is_delete_posts) {
		$response['redirect'] = esc_url_raw(add_query_arg('pmxi_nt', urlencode(sprintf(__('Import and all associated %s deleted.', 'wp-all-import-pro'), $cpt_name)), $base_url));
	} else {
		$response['redirect'] = esc_url_raw(add_query_arg('pmxi_nt', urlencode(__('Nothing to delete.', 'wp-all-import-pro')), $base_url));
		exit( json_encode( $response ));
	}

	$is_import_done = true;

	if ( ! $import->isEmpty() ) {
		if ((int) $post['iteration'] === 1) {
			$import->set(array(
				'deleted' => 0,
				'changed_missing' => 0
			))->update();
		}

		$is_import_done = $import->deletePostsAjax( ! $is_delete_posts, $is_delete_images, $is_delete_attachments ) === true;

		if ( count($import_ids) > 1 ) {
			$response['msg'] = sprintf(__('Import %d of %d (#%d) - %d records deleted', 'wp-all-import-pro'), $current_index + 1, count($import_ids), $import->id, $import->deleted);
		} else {
			$response['msg'] = sprintf(__('Import #%d - %d records deleted', 'wp-all-import-pro'), $import->id, $import->deleted);
		}

		if ( $is_import_done ) {
			do_action('pmxi_before_import_delete', $import, $is_delete_posts);
			$import->delete( ! $is_delete_posts, $is_delete_images, $is_delete_attachments, $is_delete_import );
			if ( $is_delete_import ) {
				$scheduling = \Wpai\Scheduling\Scheduling::create();
				$scheduling->deleteScheduleIfExists($current_import_id);
			}
		}
	}

	$response['result'] = $is_import_done && $is_last_import;
	if ( $is_import_done && ! $is_last_import ) {
		$response['next_import_id'] = $import_ids[$current_index + 1];
	}

	exit( json_encode( $response ));
}
