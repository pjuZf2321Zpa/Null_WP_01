<?php
function pmxi_wp_ajax_wpai_search_meta_keys(){

	if ( ! check_ajax_referer( 'wp_all_import_secure', 'security', false )){
		exit( json_encode(array('result' => array(), 'msg' => __('Security check', 'wp-all-import-pro'))) );
	}

	if ( ! current_user_can( PMXI_Plugin::$capabilities ) ){
		exit( json_encode(array('result' => array(), 'msg' => __('Security check', 'wp-all-import-pro'))) );
	}

	$input = new PMXI_Input();
	$custom_type = $input->post('custom_type', '');
	$term = $input->post('term', '');

	$custom_type = is_string($custom_type) ? sanitize_key($custom_type) : '';
	$term = is_string($term) ? mb_substr(trim($term), 0, 191) : '';

	exit( json_encode(array('result' => wp_all_import_search_meta_keys($custom_type, $term, 20))) );
}
