<?php
function pmxi_wp_ajax_auto_detect_cf(){

    if ( ! check_ajax_referer( 'wp_all_import_secure', 'security', false )){
        exit( json_encode(array('result' => array(), 'msg' => __('Security check', 'wp-all-import-pro'))) );
    }

    if ( ! current_user_can( PMXI_Plugin::$capabilities ) ){
        exit( json_encode(array('result' => array(), 'msg' => __('Security check', 'wp-all-import-pro'))) );
    }

    $input = new PMXI_Input();
    $post_type = $input->post('post_type', 'post');

    // The Custom Fields section this fills is removed for a user import without
    // the add-on, so there is nothing to detect into.
    if ( wp_all_import_user_meta_requires_addon_pro( $post_type ) ) {
        exit( json_encode(array('result' => array(), 'msg' => '')) );
    }
    $result = wp_all_import_detect_custom_fields( $post_type );

    if (empty($result)){
        switch ($post_type){
            case 'taxonomies':
                $custom_type = new stdClass();
                $custom_type->labels = new stdClass();
                $custom_type->labels->singular_name = __('Taxonomy Term', 'wp-all-import-pro');
                break;
            case 'comments':
                $custom_type = new stdClass();
                $custom_type->labels = new stdClass();
                $custom_type->labels->singular_name = __('Comment', 'wp-all-import-pro');
                break;
            default:
                $custom_type = wp_all_import_custom_type( $post_type );
                break;
        }
        $msg = sprintf(__('No Custom Fields are present in your database for %s', 'wp-all-import-pro'), $custom_type->labels->name);
    }
    elseif (count($result) === 1)
        $msg = sprintf(__('%s field was automatically detected.', 'wp-all-import-pro'), count($result));
    else{
        $msg = sprintf(__('%s fields were automatically detected.', 'wp-all-import-pro'), count($result));
    }

    if ( wp_all_import_meta_keys_collecting( $post_type ) ) {
        $note = __('WP All Import is still collecting the custom field names on this site, so try again shortly for the complete list.', 'wp-all-import-pro');
        $msg  = empty($result) ? $note : $msg . ' ' . $note;
    }

    exit( json_encode(array('result' => $result, 'msg' => $msg)) );
}