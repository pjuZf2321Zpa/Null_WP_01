<?php

function pmxi_wp_ajax_wpai_settings_check_license() {

	if ( ! check_ajax_referer( 'wp_all_import_secure', 'security', false ) ) {
		wp_send_json_error( array( 'message' => __( 'Security check', 'wp-all-import-pro' ) ) );
	}

	if ( ! current_user_can( PMXI_Plugin::$capabilities ) ) {
		wp_send_json_error( array( 'message' => __( 'Security check', 'wp-all-import-pro' ) ) );
	}

	$context = isset( $_POST['context'] ) ? sanitize_key( $_POST['context'] ) : '';
	$options = PMXI_Plugin::getInstance()->getOption();
	$settings = new PMXI_Admin_Settings();

	if ( 'scheduling' === $context ) {
		$key = empty( $options['scheduling_license'] ) ? '' : $options['scheduling_license'];

		// Not check_scheduling_license(): the save path drops the updater's version-info
		// transient and blocks on a remote request.
		$stored = isset( $options['scheduling_license_status'] ) && is_scalar( $options['scheduling_license_status'] )
			? (string) $options['scheduling_license_status']
			: '';

		if ( ! $key ) {
			$status = '';
		} elseif ( '' === $stored ) {
			$status = $settings->check_scheduling_license();
		} else {
			$status = $stored;
		}
	} else {
		$key = empty( $options['licenses']['PMXI_Plugin'] ) ? '' : $options['licenses']['PMXI_Plugin'];

		// Not check_license(): the save path drops the updater's site-wide version cache
		// and blocks on a remote request.
		$licensing = \Wpai\App\License\Licensing::instance();
		$stored    = isset( $options['statuses']['PMXI_Plugin'] ) && is_scalar( $options['statuses']['PMXI_Plugin'] )
			? (string) $options['statuses']['PMXI_Plugin']
			: '';

		if ( ! $key ) {
			$status = '';
		} elseif ( '' === $stored || \Wpai\App\Gate\Gate::instance()->blocks() || $licensing->state()->isDueForRecheck() || $licensing->shouldForceRecheck() ) {
			// recheck(), not check(): only recheck() reaches the result table
			// that opens the grace window, so a lapse this screen notices first
			// gets the same thirty dated days as one the daily event notices.
			// A background answer, not a Save, so a refusal opens the window
			// rather than blocking now.
			$result = $licensing->recheck( false );
			$status = $result['status'] === null ? false : $result['status']->license();
		} else {
			$status = $stored;
		}

		$status = wpai_settings_chip_literal(
			$status,
			isset( $result ) ? $result['status'] : $licensing->state()->answerFor( \Wpai\App\License\LicenseRefresh::decodedKey( $options ) )
		);
	}

	if ( ! $key ) {
		$network = 'scheduling' === $context ? null : wpai_settings_network_chip( \Wpai\App\License\Licensing::instance()->networkLicence(), \Wpai\App\Gate\Gate::instance() );

		wp_send_json_success( wpai_settings_with_notice( null !== $network ? $network : array(
			'state' => 'empty',
			'label' => __( 'Not activated', 'wp-all-import-pro' ),
			'help'  => '',
		), $context ) );
	}

	// After the check, not before: the check rewrites the state the gate reads.
	$blocked = \Wpai\App\Gate\Gate::instance()->blocks();

	// A WP_Error or false is indistinguishable from an unset licence downstream, so
	// surface it as retryable rather than as "invalid".
	if ( false === $status || '' === $status || null === $status ) {
		wp_send_json_success( wpai_settings_with_notice( wpai_settings_unreachable_state(
			$blocked,
			\Wpai\App\Gate\Gate::instance()->state() === \Wpai\App\Gate\Gate::STATE_VALID
		), $context ) );
	}

	// $status is decoded remote JSON, and a non-scalar would fatal on the cast.
	$state = wpai_settings_license_state(
		is_scalar( $status ) ? (string) $status : '',
		$context,
		$blocked,
		\Wpai\App\Gate\Gate::instance()->state(),
		\Wpai\App\Gate\Gate::instance()->graceUntil()
	);

	$state['blocked'] = $blocked;

	wp_send_json_success( wpai_settings_with_notice( $state, $context ) );
}

/**
 * @param  array<string,mixed>  $payload
 * @return array<string,mixed>
 */
function wpai_settings_with_notice( $payload, $context = '' ) {
	if ( 'scheduling' === $context ) {
		return $payload;
	}

	$gate    = \Wpai\App\Gate\Gate::instance();
	$state   = $gate->state();
	$blocked = $gate->blocks();
	$shown   = $state !== \Wpai\App\Gate\Gate::STATE_VALID;

	$payload['notice'] = array(
		'shown'   => $shown,
		'blocked' => $blocked,
		'html'    => $shown
			? wp_kses_post( $gate->messages()->settingsNotice( $state, $gate->stateReason(), $gate->graceUntil(), $blocked ) )
			: '',
	);

	return $payload;
}

/**
 * A sub-site with no key of its own runs on the licence stored on the network's
 * main site, so its chip names that licence rather than "Not activated".
 *
 * @param  array<string,mixed>|null  $main  the main site's licence row, from Licensing::networkLicence()
 * @param  \Wpai\App\Gate\Gate  $gate
 * @return array<string,mixed>|null  null when no network licence covers this site
 */
function wpai_settings_network_chip( $main, $gate ) {
	if ( ! is_array( $main ) || empty( $main['has_key'] ) ) {
		return null;
	}

	$blocked = $gate->blocks();
	$status  = is_scalar( $main['status'] ) ? (string) $main['status'] : '';

	$chip = '' === $status
		? wpai_settings_unreachable_state( $blocked, $gate->state() === \Wpai\App\Gate\Gate::STATE_VALID )
		: wpai_settings_license_state( $status, '', $blocked, $gate->state(), $gate->graceUntil() );

	$chip['help']    = wpai_settings_chip_help( __( 'This site uses the license saved on the main site of this network.', 'wp-all-import-pro' ), $chip['help'] );
	$chip['blocked'] = $blocked;

	return $chip;
}

/**
 * The server answers a disabled licence `license: invalid, status: disabled`, and
 * the legacy literal alone would tell the customer to check for a typo.
 *
 * @param  mixed  $literal
 * @param  \Wpai\App\License\LicenseStatus|null  $answer  the answer for the stored key
 * @return mixed
 */
function wpai_settings_chip_literal( $literal, $answer ) {
	if ( 'invalid' === $literal
		&& $answer instanceof \Wpai\App\License\LicenseStatus
		&& \Wpai\App\License\LicenseStatus::DISABLED === $answer->status() ) {
		return 'disabled';
	}

	return $literal;
}

/**
 * @return array<string,mixed>
 */
function wpai_settings_unreachable_state( $blocked = false, $stateIsValid = true ) {
	if ( $blocked ) {
		return array(
			'state'   => 'error',
			'label'   => __( 'Not active on this site', 'wp-all-import-pro' ),
			'help'    => __( "Couldn't reach the licensing server, so this key couldn't be re-checked. This site stays unlicensed until it can be.", 'wp-all-import-pro' ),
			'blocked' => true,
		);
	}

	// Keyed on the state, not on the block: `blocked` is false throughout a grace
	// window, where "your license is unaffected" would be wrong.
	if ( ! $stateIsValid ) {
		return array(
			'state'   => 'warning',
			'label'   => __( 'Status unavailable', 'wp-all-import-pro' ),
			'help'    => __( "Couldn't reach the licensing server, so this key couldn't be re-checked. Your license is unchanged by that; see the notice above for where it stands.", 'wp-all-import-pro' ),
			'blocked' => false,
		);
	}

	return array(
		'state'   => 'unknown',
		'label'   => __( 'Status unavailable', 'wp-all-import-pro' ),
		'help'    => __( "Couldn't reach the licensing server. Your license is unaffected. Retry when you have a connection.", 'wp-all-import-pro' ),
		'blocked' => false,
	);
}

/**
 * @param  string  $status  the legacy EDD literal
 * @param  string  $gateState  the gate's own state, which the literal alone cannot name
 */
function wpai_settings_license_state( $status, $context = '', $blocked = false, $gateState = '', $graceUntil = 0 ) {
	$portal = 'scheduling' === $context
		? 'https://www.wpallimport.com/portal/automatic-scheduling/'
		: 'https://www.wpallimport.com/portal';

	// The gate rules the plugin's own licence and nothing else, so a Scheduling
	// or add-on key must never be told that imports are about to stop.
	$consequence = 'scheduling' === $context
		? ''
		: ( new \Wpai\App\Gate\Messages() )->chipConsequence( $gateState, $graceUntil );

	$map = array(
		'valid'             => array( 'active', __( 'Active', 'wp-all-import-pro' ), '' ),
		'expired'           => array( 'error', __( 'Expired', 'wp-all-import-pro' ), sprintf( __( 'This license has expired. Renew it in the <a href="%s" target="_blank">customer portal</a>.', 'wp-all-import-pro' ), esc_url( $portal ) ) ),
		'invalid'           => array( 'error', __( 'Not recognized', 'wp-all-import-pro' ), sprintf( __( 'This key was not recognized. Check for a typo, or copy it again from the <a href="%s" target="_blank">customer portal</a>.', 'wp-all-import-pro' ), esc_url( $portal ) ) ),
		'disabled'          => array( 'error', __( 'Disabled', 'wp-all-import-pro' ), sprintf( __( 'This license has been disabled. Contact support via the <a href="%s" target="_blank">customer portal</a>.', 'wp-all-import-pro' ), esc_url( $portal ) ) ),
		'inactive'          => array( 'warning', __( 'Not activated', 'wp-all-import-pro' ), __( 'The key is valid but has not been activated on this site yet. Choose Activate to finish.', 'wp-all-import-pro' ) ),
		'site_inactive'     => array( 'warning', __( 'Not activated on this site', 'wp-all-import-pro' ), __( 'This key is valid but has not been activated for this domain. Choose Activate to finish.', 'wp-all-import-pro' ) ),
		'item_name_mismatch'=> array( 'error', __( 'Wrong product', 'wp-all-import-pro' ), __( 'This key belongs to a different product. Check that you pasted the WP All Import key.', 'wp-all-import-pro' ) ),
		'no_activations_left' => array( 'error', __( 'Site limit reached', 'wp-all-import-pro' ), sprintf( __( 'This license has reached its site limit. Deactivate a site you no longer use in the <a href="%s" target="_blank">customer portal</a>.', 'wp-all-import-pro' ), esc_url( $portal ) ) ),
	);

	// Aliased rather than copied: StateNames::LIMIT_LITERALS carries both, and two
	// entries would drift.
	$map['active sites limit reached'] = $map['no_activations_left'];

	// The EDD literal and the gate's cached entitlement can disagree: without this a
	// green "Active" prints beside the not-licensed banner.
	if ( $blocked && isset( $map[ $status ] ) && 'active' === $map[ $status ][0] ) {
		return array(
			'state' => 'error',
			'label' => __( 'Not active on this site', 'wp-all-import-pro' ),
			'help'  => wpai_settings_chip_help( $consequence, sprintf( __( 'The key itself checks out, but this site is not licensed to run WP All Import. Check the license in the <a href="%s" target="_blank">customer portal</a>.', 'wp-all-import-pro' ), esc_url( $portal ) ) ),
		);
	}

	if ( isset( $map[ $status ] ) ) {
		return array(
			'state' => $map[ $status ][0],
			'label' => $map[ $status ][1],
			'help'  => wpai_settings_chip_help( $consequence, $map[ $status ][2] ),
		);
	}

	return array(
		'state' => 'error',
		'label' => __( 'Not active', 'wp-all-import-pro' ),
		'help'  => wpai_settings_chip_help( $consequence, sprintf( __( 'The licensing server reported a problem with this key. Check it in the <a href="%s" target="_blank">customer portal</a>.', 'wp-all-import-pro' ), esc_url( $portal ) ) ),
	);
}

/**
 * The consequence leads: the chip's label already names the diagnosis.
 *
 * @return string
 */
function wpai_settings_chip_help( $consequence, $help ) {
	return trim( $consequence . ' ' . $help );
}
