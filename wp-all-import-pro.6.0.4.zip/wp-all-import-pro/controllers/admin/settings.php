<?php
/**
 * Admin Settings page
 *
 * @author Maksym Tsypliakov <maksym.tsypliakov@gmail.com>
 */
class PMXI_Admin_Settings extends PMXI_Controller_Admin {

	public static $path;

	public static $upload_transient;

	public $slug = 'wp-all-import-pro';

	/** @var array `tab` is preserved so a save redirect lands back on the tab being edited. */
	public $baseUrlParamNames = array('page', 'tab', 'pagenum', 'order', 'order_by', 'type', 's', 'f');

	/** @var  \Wpai\App\Service\License\LicenseActivator */
	private $licenseActivator;

	protected function init()
	{
		$this->licenseActivator = new \Wpai\App\Service\License\LicenseActivator();
	}

	/** Tab slug => label. Order is the rendered order. */
	public function get_tabs() {
		$tabs = array(
			'licenses'  => __('Licenses', 'wp-all-import-pro'),
			'imports'   => __('Imports', 'wp-all-import-pro'),
			'cron'      => __('Cron', 'wp-all-import-pro'),
			'files'     => __('Files', 'wp-all-import-pro'),
			'templates' => __('Templates', 'wp-all-import-pro'),
		);

		if (PMXI_Plugin::$is_php_allowed) {
			$tabs['functions'] = __('Functions', 'wp-all-import-pro');
		}

		$tabs['support'] = __('Support', 'wp-all-import-pro');

		/**
		 * Register a settings tab. Slug => label.
		 *
		 * A tab added here renders via `pmxi_settings_tab_content`; it does not need a
		 * view file. Core tabs can be relabelled but are rendered by core.
		 */
		$filtered = apply_filters('pmxi_settings_tabs', $tabs);

		if ( ! is_array($filtered)) {
			return $tabs;
		}

		// Lookups go through sanitize_key(), so a slug that does not survive it renders a
		// tab that can never be selected.
		foreach ($filtered as $slug => $label) {
			if ('' === (string) $slug || (string) $slug !== sanitize_key((string) $slug)) {
				unset($filtered[$slug]);
				_doing_it_wrong(
					'pmxi_settings_tabs',
					esc_html(sprintf('Tab slug "%s" must be sanitize_key()-safe; it was dropped.', $slug)),
					'5.1.0'
				);
			}
		}

		return $filtered ? $filtered : $tabs;
	}

	/** Tabs core renders itself; anything else is rendered by whoever added it. */
	public function get_core_tabs() {
		return array('licenses', 'imports', 'cron', 'files', 'templates', 'functions', 'support');
	}

	/**
	 * Rows contributed into the Advanced Settings table via pmxi_settings_advanced.
	 * Captured so the tab that hosts them can tell whether there is anything to show.
	 */
	protected function get_addon_settings($post) {
		ob_start();
		do_action('pmxi_settings_advanced', $post);

		return $this->bind_contributed_labels(trim(ob_get_clean()));
	}

	/**
	 * Whole sections (their own h3 + form-table) contributed via pmxi_settings_sections.
	 * A consumer may legitimately render nothing, so an empty string is a valid result.
	 */
	protected function get_contributed_sections($post) {
		ob_start();
		do_action('pmxi_settings_sections', $post);

		return $this->bind_contributed_labels(trim(ob_get_clean()));
	}

	/**
	 * Binds a contributed form-table row's label and description to its control.
	 * Third-party sections arrive as markup we do not own, so the row label is bound to
	 * nothing and the control announces without its group name or help text.
	 *
	 * @param  string $html
	 * @return string
	 */
	protected function bind_contributed_labels($html) {
		if ('' === $html || ! class_exists('DOMDocument')) {
			return $html;
		}

		// libxml parses <script>/<textarea> bodies as markup and drops tags that appear
		// inside JS strings, so stash the bodies, parse, then put them back verbatim.
		$stash = array();
		// Unguessable per call: strtr() replaces blindly, so a fixed token appearing
		// literally in contributed content would be overwritten with a script body.
		$nonce = function_exists('wp_generate_password') ? wp_generate_password(12, false) : (string) mt_rand();
		$html = preg_replace_callback(
			// A quoted attribute may legitimately contain '>'. The run is possessive so the
			// alternation cannot be re-entered, and the trailing group is the last-resort
			// path for an unbalanced quote, which would otherwise leave the body unstashed.
			'%(<(script|textarea)\b(?:"[^"]*"|\'[^\']*\'|[^>"\'])*+(?:["\'][^>]*)?>)(.*?)(</\2>)%is',
			function ($m) use (&$stash, $nonce) {
				$token = 'WPAIBINDSTASH' . $nonce . count($stash) . 'X';
				$stash[$token] = $m[3];

				return $m[1] . $token . $m[4];
			},
			$html
		);

		$doc = new DOMDocument();
		$previous = libxml_use_internal_errors(true);
		$loaded = $doc->loadHTML(
			'<?xml encoding="utf-8" ?><div id="wpai-bind-root">' . $html . '</div>',
			LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD
		);
		libxml_clear_errors();
		libxml_use_internal_errors($previous);

		if ( ! $loaded) {
			return $stash ? strtr($html, $stash) : $html;
		}

		$xpath = new DOMXPath($doc);

		// A contributed section title is an h3 restyled to look like the native h4 group
		// titles, so the accessibility tree reports a level the page does not show.
		// Override the level rather than rewrite a contributor's element.
		foreach ($xpath->query('//h3[not(@aria-level)]') as $heading) {
			$heading->setAttribute('role', 'heading');
			$heading->setAttribute('aria-level', '4');
		}

		foreach ($xpath->query('//tr') as $row) {
			$controls = $xpath->query('.//td//input[not(@type="hidden")] | .//td//select | .//td//textarea', $row);

			if ($controls->length !== 1) {
				continue;
			}

			$id = $controls->item(0)->getAttribute('id');

			if ('' === $id) {
				continue;
			}

			foreach ($xpath->query('.//th//label[not(@for)]', $row) as $label) {
				$label->setAttribute('for', $id);
			}

			$descriptions = $xpath->query('.//td//p[contains(concat(" ", normalize-space(@class), " "), " description ")]', $row);
			$tokens = preg_split('%\s+%', trim($controls->item(0)->getAttribute('aria-describedby')), -1, PREG_SPLIT_NO_EMPTY);
			$index = 0;

			foreach ($descriptions as $description) {
				$descId = $description->getAttribute('id');

				if ('' === $descId) {
					$descId = $id . '-desc' . ($index ? '-' . $index : '');
					$description->setAttribute('id', $descId);
				}

				// Append: an add-on may already point at a note of its own.
				if ( ! in_array($descId, $tokens, true)) {
					$tokens[] = $descId;
				}

				$index++;
			}

			if ($tokens) {
				$controls->item(0)->setAttribute('aria-describedby', implode(' ', $tokens));
			}
		}

		$root = $doc->getElementById('wpai-bind-root');

		if ($root === null) {
			return $stash ? strtr($html, $stash) : $html;
		}

		$out = '';
		// An unbalanced close tag in one contributor's markup closes the wrapper early, so
		// everything after it becomes a sibling of the wrapper rather than a child.
		foreach ($doc->childNodes as $top) {
			if ($top->nodeType === XML_PI_NODE) {
				continue;
			}
			if ($top === $root) {
				foreach ($top->childNodes as $child) {
					$out .= $doc->saveHTML($child);
				}
			} else {
				$out .= $doc->saveHTML($top);
			}
		}

		return $stash ? strtr($out, $stash) : $out;
	}

	/**
	 * wp_check_invalid_utf8()'s strip mode routes to iconv() without //IGNORE, which
	 * returns false on PHP 8, erasing the whole field rather than the bad sequence.
	 */
	protected function utf8_safe($value) {
		$value = (string) $value;

		if ('' === $value || (function_exists('mb_check_encoding') && mb_check_encoding($value, 'UTF-8'))) {
			return $value;
		}

		if (function_exists('iconv')) {
			$stripped = @iconv('UTF-8', 'UTF-8//IGNORE', $value);
			if (false !== $stripped) {
				return $stripped;
			}
		}

		return preg_replace('/[\x80-\xFF]/', '', $value);
	}

	protected function get_system_report() {
		global $wp_version;

		$theme  = wp_get_theme();
		$active = array();
		foreach ((array) get_option('active_plugins', array()) as $plugin) {
			$data    = @get_plugin_data(WP_PLUGIN_DIR . '/' . $plugin, false, false);
			$name    = $this->utf8_safe((string) (empty($data['Name']) ? $plugin : $data['Name']));
			$version = $this->utf8_safe((string) (empty($data['Version']) ? '' : $data['Version']));
			$active[] = '' === $version ? $name : $name . ' ' . $version;
		}
		sort($active);

		$server_limit  = $this->get_server_time_limit();
		$wpai_override = (int) PMXI_Plugin::getInstance()->getOption('max_execution_time');

		$lines = array(
			'== WP All Import ==',
			'WP All Import:      ' . PMXI_VERSION . (defined('PMXI_EDITION') ? ' (' . PMXI_EDITION . ')' : ''),
			'PHP in mappings:    ' . (PMXI_Plugin::$is_php_allowed ? 'allowed' : 'blocked'),
			'Secure mode:        ' . (PMXI_Plugin::getInstance()->getOption('secure') ? 'on' : 'off'),
			'Chunk size:         ' . PMXI_Plugin::getInstance()->getOption('large_feed_limit'),
			'',
			'== Environment ==',
			'WordPress:          ' . $wp_version . (is_multisite() ? ' (multisite)' : ''),
			'Theme:              ' . $this->utf8_safe((string) $theme->get('Name')) . ' ' . $this->utf8_safe((string) $theme->get('Version')),
			'PHP:                ' . PHP_VERSION,
			'Memory limit:       ' . ini_get('memory_limit'),
			'Max execution (server): ' . ($server_limit ? $server_limit . 's' : 'unlimited'),
			'Max execution (WPAI):   ' . ($wpai_override ? $wpai_override . 's' : 'unlimited (WP All Import overrides the server on its own admin pages)'),
			'Max upload size:    ' . size_format(wp_max_upload_size()),
			// The two raw limits behind it: the computed figure is the smaller of the
			// pair, so on its own it never says which one a failed upload hit.
			'Upload max filesize: ' . ini_get('upload_max_filesize'),
			'Post max size:      ' . ini_get('post_max_size'),
			// Truncates a large field mapping without reporting anything.
			'Max input vars:     ' . ini_get('max_input_vars'),
			'libxml:             ' . (defined('LIBXML_DOTTED_VERSION') ? LIBXML_DOTTED_VERSION : 'unknown'),
			'Server:             ' . (empty($_SERVER['SERVER_SOFTWARE']) ? 'unknown' : $this->utf8_safe((string) $_SERVER['SERVER_SOFTWARE'])),
			'MySQL:              ' . $this->utf8_safe((string) $this->get_db_version()),
			'WP_DEBUG:           ' . (defined('WP_DEBUG') && WP_DEBUG ? 'on' : 'off'),
			'',
			'== Active plugins (' . count($active) . ') ==',
		);

		// esc_textarea() is htmlspecialchars() without ENT_SUBSTITUTE, so one invalid byte
		// anywhere in here returns '' for the entire report.
		return $this->utf8_safe(implode("\n", array_merge($lines, $active)));
	}

	/**
	 * Normalises a request-derived option array before it is stored. A crafted POST can
	 * turn a scalar option into an array, which then persists and fatals on every later
	 * read; and no form here renders a licence field, so those must never come from the
	 * request whichever branch is saving.
	 *
	 * @param  array $post
	 * @return array
	 */
	protected function normalise_saved_options($post, $pin = array(), $owns = null) {
		$stored = PMXI_Plugin::getInstance()->getOption();

		// $post carries every option key merged over the request, so a branch that renders
		// only its own fields is otherwise a general settings-write primitive. When a branch
		// declares what it owns, everything else comes from stored.
		if (is_array($owns)) {
			$post = array_intersect_key($post, array_flip($owns)) + $stored;
		}

		// Per branch, because the branch that owns the licence options still has to be able
		// to save a new key. Read past the object cache: a concurrent activation writes
		// these after this request's copy was loaded, so pinning the in-memory value would
		// revert it.
		if ($pin) {
			$option_name = get_class(PMXI_Plugin::getInstance()) . '_Options';
			wp_cache_delete($option_name, 'options');
			$fresh = get_option($option_name);
			$fresh = is_array($fresh) ? $fresh : $stored;
		}

		foreach ($pin as $licence_key) {
			if (array_key_exists($licence_key, $fresh)) {
				$post[$licence_key] = $fresh[$licence_key];
			} elseif (array_key_exists($licence_key, $stored)) {
				$post[$licence_key] = $stored[$licence_key];
			}
		}

		foreach ($post as $key => $value) {
			if (is_scalar($value) || ! isset($stored[$key]) || is_array($stored[$key])) {
				continue;
			}

			$post[$key] = $stored[$key];
		}

		// $_POST is all strings, so an untouched int option comes back as "5" against a
		// stored 5, and saveOptions() compares with !==. The write is whole-row, so one
		// spurious change re-asserts every other option from this request's boot copy.
		foreach ($post as $key => $value) {
			if (is_int($stored[$key] ?? null) && is_string($value) && is_numeric($value)
				&& (string) (int) $value === $value) {
				$post[$key] = (int) $value;
			}
		}

		return $post;
	}

	/**
	 * The server's real execution ceiling. Not ini_get(): the plugin ini_set()s
	 * max_execution_time from its own option before any admin controller runs, so
	 * ini_get reports that override. get_cfg_var() reads php.ini and is unaffected.
	 */
	protected function get_server_time_limit() {
		$cfg = get_cfg_var('max_execution_time');

		return $cfg === false || $cfg === '' ? (int) ini_get('max_execution_time') : (int) $cfg;
	}

	protected function get_db_version() {
		global $wpdb;

		return $wpdb->get_var('SELECT VERSION()');
	}

	/** Which tab POSTed. Falls back to the current tab for forms without the marker. */
	protected function get_submitted_tab() {
		$tab  = isset($_POST['settings_tab']) ? sanitize_key($_POST['settings_tab']) : '';
		$tabs = $this->get_tabs();

		return isset($tabs[$tab]) ? $tab : $this->get_current_tab();
	}

	protected function get_visible_tabs() {
		if ( ! empty($this->data['wpai_gate_blocked'])) {
			return array_intersect_key($this->get_tabs(), array('licenses' => true));
		}

		return $this->get_tabs();
	}

	protected function get_current_tab() {
		$tabs = $this->get_tabs();

		// Blocked: Licenses is the only tab whose actions still run, so a deep link to any
		// other lands here rather than on a dead panel.
		if ( ! empty($this->data['wpai_gate_blocked'])) {
			return 'licenses';
		}
		$tab  = isset($_GET['tab']) ? sanitize_key($_GET['tab']) : '';

		return isset($tabs[$tab]) ? $tab : key($tabs);
	}

	public function __construct(){

		parent::__construct();

		self::$upload_transient = 'pmxi_uploads_path';

		$uploads = wp_upload_dir();

		$is_secure_import = PMXI_Plugin::getInstance()->getOption('secure');

		if ( ! $is_secure_import ){

			self::$path = wp_all_import_secure_file($uploads['basedir'] . DIRECTORY_SEPARATOR . PMXI_Plugin::UPLOADS_DIRECTORY );

		}
		else {

			self::$path = get_transient( self::$upload_transient );

			if ( empty(self::$path) ) {
				self::$path = wp_all_import_secure_file($uploads['basedir'] . DIRECTORY_SEPARATOR . PMXI_Plugin::UPLOADS_DIRECTORY );
				set_transient( self::$upload_transient, self::$path);
			}
		}

		$sleep = apply_filters( 'wp_all_import_shard_delay', 0 );
		usleep($sleep);

		$this->enqueue_settings_assets();
	}

	protected function enqueue_settings_assets() {

		wp_enqueue_style('pmxi-settings-style', WP_ALL_IMPORT_ROOT_URL . '/static/css/settings.css', array('pmxi-admin-style'), PMXI_VERSION);
		wp_enqueue_script('pmxi-settings-script', WP_ALL_IMPORT_ROOT_URL . '/static/js/settings.js', array('jquery'), PMXI_VERSION, true);

		wp_localize_script('pmxi-settings-script', 'wpaiSettingsL10n', array(
			'nonce'                 => wp_create_nonce('wp_all_import_secure'),
			'saving'                => __('Saving…', 'wp-all-import-pro'),
			'leaveWarning'          => __('You have unsaved changes that will be lost.', 'wp-all-import-pro'),
			'show'                  => __('Show', 'wp-all-import-pro'),
			'hide'                  => __('Hide', 'wp-all-import-pro'),
			'showValue'             => __('Show value', 'wp-all-import-pro'),
			'hideValue'             => __('Hide value', 'wp-all-import-pro'),
			'copied'                => __('Copied', 'wp-all-import-pro'),
			'copyFailed'            => __('Press Ctrl+C', 'wp-all-import-pro'),
			'confirm'               => __('Confirm', 'wp-all-import-pro'),
			'confirmTitle'          => __('Are you sure?', 'wp-all-import-pro'),
			'cancel'                => __('Cancel', 'wp-all-import-pro'),
			'statusUnavailable'     => __('Status unavailable', 'wp-all-import-pro'),
			'statusUnavailableHelp' => __("Couldn't reach the licensing server. Your license is unaffected. Retry when you have a connection.", 'wp-all-import-pro'),
			// Kept word for word with wpai_settings_unreachable_state().
			'notActiveHere'         => __('Not active on this site', 'wp-all-import-pro'),
			'statusUncheckedHelp'   => __("Couldn't reach the licensing server, so this key couldn't be re-checked. This site stays unlicensed until it can be.", 'wp-all-import-pro'),
			'regenerateWarning'     => __('Generate a new secret key? Every cron job you have already set up will stop working until you update it with the new URLs.', 'wp-all-import-pro'),
			'regenerateLabel'       => __('Generate new key', 'wp-all-import-pro'),
			'phpMaxExecution'       => $this->get_server_time_limit(),
			'cronOverPhpMax'        => __("This is above your server's PHP max execution time of %ds, so the script will be stopped before it reaches this limit.", 'wp-all-import-pro'),
		));
	}

	/**
	 * Called again after the licence branch, which rewrites what the gate reads.
	 *
	 * @param  \Wpai\App\Gate\Gate  $gate
	 * @return void
	 */
	protected function readGate($gate) {

		$blocked = $gate->blocks();

		$this->data['wpai_gate_blocked'] = $blocked;

		// Not $blocked: during grace the whole page renders, and this is the only
		// warning the customer gets before it stops.
		$this->data['wpai_gate_state'] = $gate->state();
		$this->data['wpai_gate_state_shown'] = $gate->state() !== \Wpai\App\Gate\Gate::STATE_VALID;
		$this->data['wpai_gate_message'] = $gate->messages()->settingsNotice(
			$gate->state(),
			$gate->stateReason(),
			$gate->graceUntil(),
			$blocked
		);
		$this->data['wpai_gate_redirected'] = $blocked
			&& isset($_GET['wpai_gate'])
			&& $_GET['wpai_gate'] === 'blocked';
		$this->data['wpai_gate_redirect_message'] = $gate->messages()->redirected();
	}

	public function index() {

		$this->data['post'] = $post = $this->postWithStoredOptions();

		$this->data['addons']['PMXI_Plugin'] = array(
			'title' => __('WP All Import', 'wp-all-import-pro'),
			'active' => (class_exists('PMXI_Plugin') and defined('PMXI_EDITION') and PMXI_EDITION == 'paid')
		);

		$this->data['addons'] = array_reverse($this->data['addons']);

		$this->data['license_message'] = '';

		/*
		 * This screen stays open while every other one redirects here, so the licence
		 * branches keep working and everything else is skipped. Skipped, not hidden.
		 * Hiding a form in the view leaves its POST handler reachable.
		 */
		$gate = \Wpai\App\Gate\Gate::instance();
		$this->readGate($gate);

		if ($this->input->post('is_license_submitted')) { // save license

			check_admin_referer('edit-license', '_wpnonce_edit-license');

			// Clearing a key has to be explicit: the activate path cannot express it.
			if ( ! empty($_POST['pmxi_license_remove'])) {
				$class = sanitize_text_field(wp_unslash($_POST['pmxi_license_remove']));

				if (isset($this->data['addons'][$class])) {
					// updateOption() re-encodes licence values, so writing '' leaves a
					// non-empty blob behind and the key still reads as present. Drop the
					// entries instead, and only the two being changed: getOption() is
					// filtered, so the array can carry an add-on's undeclared key, which
					// updateOption() throws for.
					$licenses = (array) PMXI_Plugin::getInstance()->getOption('licenses');
					$statuses = (array) PMXI_Plugin::getInstance()->getOption('statuses');
					unset($licenses[$class], $statuses[$class]);
					PMXI_Plugin::getInstance()->updateOption(array('licenses' => $licenses, 'statuses' => $statuses));

					// Removing the key leaves a record that still carries a package URL,
					// so the row keeps offering an update the site is no longer entitled
					// to until it expires.
					wp_all_import_pro_forget_version_record();

					wp_redirect(esc_url_raw(add_query_arg('pmxi_nt', urlencode(__('License removed', 'wp-all-import-pro')), $this->baseUrl)));
					die();
				}
			}

			// The field is rendered empty on purpose, because the key is never sent to the
			// browser, so an empty submit means "leave it as it is". Clearing is done with
			// Remove.
			$stored_licenses = PMXI_Plugin::getInstance()->getOption('licenses');

			// A crafted POST can make `licenses` a string, or any entry an array; both
			// fatal inside updateOption()'s re-encode loop before anything is stored.
			if ( ! isset($post['licenses']) || ! is_array($post['licenses'])) {
				$post['licenses'] = (array) $stored_licenses;
			}

			if ( ! isset($post['statuses']) || ! is_array($post['statuses'])) {
				$post['statuses'] = (array) PMXI_Plugin::getInstance()->getOption('statuses');
			}

			foreach ((array) $stored_licenses as $stored_class => $stored_key) {
				$submitted = isset($post['licenses'][$stored_class]) ? $post['licenses'][$stored_class] : '';

				if ( ! is_scalar($submitted) || '' === trim((string) $submitted)) {
					$post['licenses'][$stored_class] = $stored_key;
				}
			}

			foreach ($post['licenses'] as $k => $v) {
				if ( ! is_scalar($v)) {
					// The stored fallback can itself be the poisoned value, which would put
					// the array straight back into the re-encode loop.
					$fallback = isset($stored_licenses[$k]) ? $stored_licenses[$k] : '';
					$post['licenses'][$k] = is_scalar($fallback) ? $fallback : '';
				}
			}

			// Same for statuses: the guard above does not reach the entries, and a
			// non-scalar there makes the row permanently read as inactive.
			$stored_statuses = (array) PMXI_Plugin::getInstance()->getOption('statuses');
			foreach ($post['statuses'] as $k => $v) {
				if ( ! is_scalar($v)) {
					$post['statuses'][$k] = isset($stored_statuses[$k]) ? $stored_statuses[$k] : '';
				}
			}

			if ( ! $this->errors->get_error_codes()) { // no validation errors detected

				// Both buttons land here. Save used to leave the record alone,
				// so a customer who pasted a key and pressed Save kept the
				// "a valid license is required" row until the record expired.
				wp_all_import_pro_forget_version_record();

				$this->saveOptions($this->normalise_saved_options($post, array('scheduling_license', 'scheduling_license_status'), array('licenses', 'statuses')));

				if (empty($_POST['pmxi_license_activate']) and empty($_POST['pmxi_license_deactivate'])) {
					foreach ($this->data['addons'] as $class => $addon) {
						$status = $this->check_license($class);

						// Anything but a literal is "no answer": false for a
						// timeout or a 503, null for a 200 carrying no
						// `license`. Storing it would clear a licensed
						// customer's badge because we were unreachable.
						if (is_string($status) and $status !== '') {
							$post['statuses'][$class] = $status;
						}

						if ($status === 'valid'){
							$this->data['license_message'] = __('License activated.', 'wp-all-import-pro');
						}
					}
					$this->saveOptions($this->normalise_saved_options($post, array('scheduling_license', 'scheduling_license_status'), array('licenses', 'statuses')));
				}

				if (isset($_POST['pmxi_license_activate'])) {
					$this->activate_licenses();

					// Activate and Save are the same call, since the server ignores
					// edd_action, so the core product goes through the refresh
					// here, which activate_licenses() skips.
					$this->check_license(\Wpai\App\License\Licensing::PRODUCT_CLASS, true);
				}
			}

			$this->readGate($gate);
		}

		// Hiding the form is not enough: both licence fields are minted for the same
		// 'edit-license' nonce action, so the one a blocked page renders satisfies this.
		if ($this->input->post('is_scheduling_license_submitted') && ! $this->data['wpai_gate_blocked']) {

			check_admin_referer('edit-license', '_wpnonce_edit-scheduling-license');

			if ( ! empty($_POST['pmxi_scheduling_license_remove'])) {
				// Assign, don't unset: updateOption() merges with `$option + $this->options`,
				// so a removed top-level key is restored from the existing options. The
				// re-encode loop only touches `licenses`, so '' stays empty here.
				PMXI_Plugin::getInstance()->updateOption(array(
					'scheduling_license'        => '',
					'scheduling_license_status' => '',
				));

				delete_site_transient('update_plugins');

				wp_redirect(esc_url_raw(add_query_arg('pmxi_nt', urlencode(__('License removed', 'wp-all-import-pro')), $this->baseUrl)));
				die();
			}

			$stored_sched = PMXI_Plugin::getInstance()->getOption('scheduling_license');
			$stored_sched = is_scalar($stored_sched) ? $stored_sched : '';
			if (isset($post['scheduling_license']) && is_scalar($post['scheduling_license'])
				&& '' === trim((string) $post['scheduling_license']) && ! empty($stored_sched)) {
				$post['scheduling_license'] = $stored_sched;
			}

			if (!$this->errors->get_error_codes()) { // no validation errors detected

				$this->saveOptions($this->normalise_saved_options($post, array('licenses', 'statuses'), array('scheduling_license', 'scheduling_license_status')));

				// Mirrors the main licence branch: the status check runs unless we are
				// deactivating, and activation runs when the Activate submit is present.
				if (empty($_POST['pmxi_scheduling_license_deactivate'])) {
					$post['scheduling_license_status'] = $this->check_scheduling_license();

					if ($post['scheduling_license_status'] == 'valid') {
						$this->data['scheduling_license_message'] = __('License activated.', 'wp-all-import-pro');
					}

					$this->saveOptions($this->normalise_saved_options($post, array('licenses', 'statuses'), array('scheduling_license', 'scheduling_license_status')));
				}

				if ( ! empty($_POST['pmxi_scheduling_license_activate'])) {
					$this->activate_scheduling_licenses();
				}
			}

            if(class_exists('PMXE_Plugin')) {
			    if(method_exists('PMXE_Plugin', 'getSchedulingName')) {
			        if(!empty($post['scheduling_license_status'])) {
                        $schedulingLicenseData = array();
                        $schedulingLicenseData['scheduling_license_status'] = $post['scheduling_license_status'];
                        $schedulingLicenseData['scheduling_license'] = $post['scheduling_license'];

                        PMXE_Plugin::getInstance()->updateOption($schedulingLicenseData);
                    }
                }
            }
		}

		// Nothing on this render path may reach the network: the daily recheck and the
		// queued admin fallback are what keep the stored status fresh.
		//
		// The view decodes these, and a request-supplied array reaches
		// PMXI_Plugin::decode() and fatals on render, so pin all four for display.
		$post['scheduling_license_status'] = PMXI_Plugin::getInstance()->getOption('scheduling_license_status');

		$stored_for_view = PMXI_Plugin::getInstance()->getOption();
		foreach (array('licenses', 'statuses', 'scheduling_license') as $view_key) {
			if (array_key_exists($view_key, $stored_for_view)) {
				$post[$view_key] = $stored_for_view[$view_key];
			}
		}
		$this->data['post'] = $post;

		$this->data['is_license_active'] = false;
		if (!empty($post['license_status']) && $post['license_status'] == 'valid') {
			$this->data['is_license_active'] = true;
		}

		$this->data['is_scheduling_license_active'] = false;
		if (!empty($post['scheduling_license_status']) && $post['scheduling_license_status'] == 'valid') {
			$this->data['is_scheduling_license_active'] = true;
		}

		$this->data['is_license_active'] = false;

		foreach ($this->data['addons'] as $class => $addon) {
			if( ! empty($post['statuses'][$class]) && $post['statuses'][$class] == 'valid' ){
				$this->data['is_license_active'] = true;
			}
		}

		if ($this->input->post('is_settings_submitted') && ! $this->data['wpai_gate_blocked']) { // save settings form
			check_admin_referer('edit-settings', '_wpnonce_edit-settings');

			if (empty($post['html_entities'])) $post['html_entities'] = 0;
			if (empty($post['utf8_decode'])) $post['utf8_decode'] = 0;

			// A crafted POST can turn any scalar option into an array (port[]=…), which then
			// persists and fatals on every later read. The options that are legitimately
			// arrays are pinned to their stored values instead.
			$stored = PMXI_Plugin::getInstance()->getOption();

			foreach (array('licenses', 'statuses', 'scheduling_license', 'scheduling_license_status') as $licence_key) {
				if (array_key_exists($licence_key, $stored)) {
					$post[$licence_key] = $stored[$licence_key];
				}
			}
			foreach ($post as $key => $value) {
				if (is_scalar($value) || ! isset($stored[$key]) || is_array($stored[$key])) {
					continue;
				}
				$post[$key] = $stored[$key];
			}

			// min/max on the inputs is a convenience, not a guarantee. The same bounds
			// have to hold for anything that posts directly.
			$numeric_fields = array(
				'large_feed_limit'           => array(__('Chunk size', 'wp-all-import-pro'), 1, 100000),
				'log_storage'                => array(__('Logs kept', 'wp-all-import-pro'), 0, 1000),
				'history_file_count'         => array(__('Import files kept', 'wp-all-import-pro'), 0, 100000),
				'history_file_age'           => array(__('Delete files older than', 'wp-all-import-pro'), 0, 3650),
				'cron_processing_time_limit' => array(__('Processing time limit', 'wp-all-import-pro'), 0, 3600),
				'cron_sleep'                 => array(__('Pause between records', 'wp-all-import-pro'), 0, 60),
				'pmxi_file_download_timeout' => array(__('Download time limit', 'wp-all-import-pro'), 0, 3600),
				'port'                       => array(__('Custom port', 'wp-all-import-pro'), 1, 65535),
			);

			foreach ($numeric_fields as $field => $spec) {
				list($label, $min, $max) = $spec;

				// Only the submitted tab's fields are in $_POST. Validating the stored rest
				// too would let a value that predates these ranges block every other tab,
				// naming a field that is not on the page.
				if ( ! isset($_POST[$field]) || ! is_scalar($post[$field])) {
					continue;
				}

				$value = trim((string) $post[$field]);

				if ('' === $value) {
					continue;
				}

				if ( ! preg_match('%^\d+$%', $value)) {
					$this->errors->add('form-validation', sprintf(__('%s must be a whole number, or left blank.', 'wp-all-import-pro'), $label));
					continue;
				}

				if ((int) $value < $min || (int) $value > $max) {
					$this->errors->add('form-validation', sprintf(__('%1$s must be between %2$d and %3$d.', 'wp-all-import-pro'), $label, $min, $max));
				}
			}

			if ($this->input->post('regenerate_cron_job_key')) {
				$post['cron_job_key'] = wp_all_import_url_title(wp_generate_password(12, false));
			}

			if (isset($_POST['cron_job_key'])) {
				$submitted = is_scalar($post['cron_job_key']) ? (string) $post['cron_job_key'] : '';
				$sanitised = wp_all_import_url_title($submitted);

				if ('' === $sanitised) {
					// Empty falls through to the plugin's auto-regeneration, which is the
					// destructive act the Regenerate button gates behind a confirmation.
					$this->errors->add('form-validation', __('Secret key must contain at least one letter, number, dot, dash, or underscore.', 'wp-all-import-pro'));
					$post['cron_job_key'] = PMXI_Plugin::getInstance()->getOption('cron_job_key');
				} elseif ($sanitised !== $submitted) {
					$this->errors->add('form-validation', sprintf(__('Secret key can only contain letters, numbers, dots, dashes, and underscores. Try %s.', 'wp-all-import-pro'), $sanitised));
					$post['cron_job_key'] = PMXI_Plugin::getInstance()->getOption('cron_job_key');
				} else {
					$post['cron_job_key'] = $sanitised;
				}
			} else {
				// Not on this tab, so leave it exactly as stored.
				$post['cron_job_key'] = PMXI_Plugin::getInstance()->getOption('cron_job_key');
			}

            if ( ! $this->errors->get_error_codes()) { // no validation errors detected

                $current_cron_job_key = PMXI_Plugin::getInstance()->getOption('cron_job_key');
                $new_cron_job_key = $post['cron_job_key'];

                if($new_cron_job_key !== $current_cron_job_key) {

                    // Cron job key changed
                    $scheduling_service = \Wpai\Scheduling\Scheduling::create();
                    $imports = new PMXI_Import_List();
                    $imports = $imports->getBy('deleted', 0)->convertRecords();

                    foreach ($imports as $import) {
                        if($import->options['scheduling_enable'] === "1") {
                            $scheduling_service->updateApiKey($import->id, $new_cron_job_key);
                        }
                    }
                }

				$previous_port = (string) PMXI_Plugin::getInstance()->getOption('port');

				$this->saveOptions($this->normalise_saved_options($post, array('licenses', 'statuses', 'scheduling_license', 'scheduling_license_status')));

				/**
				 * Fires after the settings for one tab are saved.
				 *
				 * Settings are split across tabs, so a handler must not treat a missing
				 * field as "unchecked", because its control may live on another tab.
				 * Compare $tab against your own tab before acting.
				 *
				 * @param string $tab   Slug of the submitted tab.
				 * @param array  $post  The saved options.
				 */
				do_action('pmxi_settings_saved', $this->get_submitted_tab(), $post);

				// The base controller built baseUrl from the pre-save port, so a port change
				// would otherwise redirect to the old address.
				$new_port = isset($post['port']) ? (string) $post['port'] : '';
				if ($new_port !== (string) $previous_port) {
					$parts = parse_url($this->baseUrl);

					if ( ! empty($parts['host'])) {
						$site = parse_url(site_url());
						$fallback = ( ! empty($site['port']) && ! in_array((int) $site['port'], array(80, 443), true))
							? ':' . (int) $site['port']
							: '';

						$this->baseUrl = $parts['scheme'] . '://' . $parts['host']
							. ('' !== $new_port && is_numeric($new_port) ? ':' . (int) $new_port : $fallback)
							. (isset($parts['path']) ? $parts['path'] : '')
							. (isset($parts['query']) ? '?' . $parts['query'] : '');
					}
				}

				$files = new PMXI_File_List(); $files->sweepHistory(); // adjust file history to new settings specified

				wp_redirect(esc_url_raw(add_query_arg('pmxi_nt', urlencode(__('Settings saved', 'wp-all-import-pro')), $this->baseUrl))); die();
			}
		}

		if ($this->input->post('is_templates_submitted') && ! $this->data['wpai_gate_blocked']) { // delete templates form

			check_admin_referer('delete-templates', '_wpnonce_delete-templates');

			if ($this->input->post('import_templates')){

				if (!empty($_FILES)){
					$file_name = $_FILES['template_file']['name'];
					$file_size = $_FILES['template_file']['size'];
					$tmp_name  = $_FILES['template_file']['tmp_name'];

					if(isset($file_name))
					{

						$filename  = stripslashes($file_name);
						$extension = strtolower(pmxi_getExtension($filename));

						if (($extension != "txt"))
						{
							$this->errors->add('form-validation', __('Unknown File extension. Only txt files are permitted', 'wp-all-import-pro'));
						}
						else {
							$import_data = @file_get_contents($tmp_name);
							if (!empty($import_data)){
								$import_data = str_replace("\xEF\xBB\xBF", '', $import_data);
								$templates_data = json_decode($import_data, true);

								if ( ! empty($templates_data) ){
									if ( ! empty($templates_data[0]['options']) && is_array($templates_data[0]['options'])){
										$templateOptions = $templates_data[0]['options'];
									}
									else{
										$templateOptions = empty($templates_data[0]['options']) ? false : \pmxi_maybe_unserialize($templates_data[0]['options']);
									}
									if ( empty($templateOptions) ){
										$this->errors->add('form-validation', __('The template is invalid. Options are missing.', 'wp-all-import-pro'));
									}
									else{
										if (isset($templateOptions['is_user_export'])){
											$this->errors->add('form-validation', __('The template you\'ve uploaded is intended to be used with WP All Export plugin.', 'wp-all-import-pro'));
										}
										else{
											$template = new PMXI_Template_Record();
											foreach ($templates_data as $template_data) {
												unset($template_data['id']);
												$template->clear()->set($template_data)->insert();
											}
											wp_redirect(esc_url_raw(add_query_arg('pmxi_nt', urlencode(sprintf(_n('%d template imported', '%d templates imported', count($templates_data), 'wp-all-import-pro'), count($templates_data))), $this->baseUrl))); die();
										}
									}
								}
								else $this->errors->add('form-validation', __('Wrong imported data format', 'wp-all-import-pro'));
							}
							else $this->errors->add('form-validation', __('File is empty or doesn\'t exests', 'wp-all-import-pro'));
						}
					}
					else $this->errors->add('form-validation', __('Undefined entry!', 'wp-all-import-pro'));
				}
				else $this->errors->add('form-validation', __('Please select file.', 'wp-all-import-pro'));

			}
			else{
				$templates_ids = $this->input->post('templates', array());
				if (empty($templates_ids)) {
					$this->errors->add('form-validation', __('Templates must be selected', 'wp-all-import-pro'));
				}

				if ( ! $this->errors->get_error_codes()) { // no validation errors detected
					if ($this->input->post('delete_templates')){
						$template = new PMXI_Template_Record();
						foreach ($templates_ids as $template_id) {
							$template->clear()->set('id', $template_id)->delete();
						}
						wp_redirect(esc_url_raw(add_query_arg('pmxi_nt', urlencode(sprintf(_n('%d template deleted', '%d templates deleted', count($templates_ids), 'wp-all-import-pro'), count($templates_ids))), $this->baseUrl))); die();
					}
					if ($this->input->post('export_templates')){
						$export_data = array();
						$template = new PMXI_Template_Record();
						foreach ($templates_ids as $template_id) {
							$export_data[] = $template->clear()->getBy('id', $template_id)->toArray(TRUE);
						}

						$uploads = wp_upload_dir();
						$targetDir = $uploads['basedir'] . DIRECTORY_SEPARATOR . PMXI_Plugin::TEMP_DIRECTORY;
						$export_file_name = "templates_".uniqid().".txt";
						file_put_contents($targetDir . DIRECTORY_SEPARATOR . $export_file_name, json_encode($export_data));

						PMXI_download::csv($targetDir . DIRECTORY_SEPARATOR . $export_file_name);

					}
				}
			}
		}

		$this->data['tabs'] = $this->get_visible_tabs();
		$this->data['current_tab'] = $this->get_current_tab();
		$this->data['tab_url']     = array();
		foreach ($this->data['tabs'] as $slug => $label) {
			$this->data['tab_url'][$slug] = add_query_arg('tab', $slug, admin_url('admin.php?page=pmxi-admin-settings'));
		}

		// Built from the stored value, not the request: this runs on every page load
		// before any branch validates.
		$stored_cron_key = PMXI_Plugin::getInstance()->getOption('cron_job_key');
		$stored_cron_key = is_scalar($stored_cron_key) ? (string) $stored_cron_key : '';
		$this->data['cron_urls'] = $this->get_cron_urls($stored_cron_key);

		// The Cron tab renders this through esc_attr(), which throws on a non-string.
		if ( ! isset($post['cron_job_key']) || ! is_scalar($post['cron_job_key'])) {
			$this->data['post']['cron_job_key'] = $post['cron_job_key'] = $stored_cron_key;
		}

		$uploads = wp_upload_dir();
		$this->data['functions_file'] = apply_filters(
			'import_functions_file_path',
			$uploads['basedir'] . DIRECTORY_SEPARATOR . WP_ALL_IMPORT_UPLOADS_BASE_DIRECTORY . DIRECTORY_SEPARATOR . 'functions.php'
		);
		$this->data['uploads_basedir'] = $uploads['basedir'] . DIRECTORY_SEPARATOR . WP_ALL_IMPORT_UPLOADS_BASE_DIRECTORY;

		$this->data['server_time_limit']    = $this->get_server_time_limit();
		$this->data['addon_settings']        = $this->get_addon_settings($post);
		$this->data['contributed_sections'] = $this->get_contributed_sections($post);
		$this->data['system_report']  = $this->get_system_report();

		$this->render();
	}

	/**
	 * The manual-cron endpoints handled by pmxi_wp_loaded_99(). `cleanup` is site-wide;
	 * the rest need an import ID, which lives on Manage Imports.
	 */
	protected function get_cron_urls($cron_job_key) {
		return wp_all_import_cron_urls($cron_job_key);
	}

	/*
	*
	* Activate licenses for main plugin and all premium addons
	*
	*/
	protected function activate_licenses() {

		// listen for our activate button to be clicked
		if( isset( $_POST['pmxi_license_activate'] ) ) {

			// retrieve the license from the database
			$options = PMXI_Plugin::getInstance()->getOption();

			wp_all_import_pro_forget_version_record();

			foreach ($_POST['pmxi_license_activate'] as $class => $val) {

				// The core product is handled by the refresh the caller runs
				// straight after this. Asking twice is two writers for one answer.
				if ($class === \Wpai\App\License\Licensing::PRODUCT_CLASS) {
					continue;
				}

				if (!empty($options['licenses'][$class])){

					$product_name = (method_exists($class, 'getEddName')) ? call_user_func(array($class, 'getEddName')) : false;

					if ( $product_name !== false ){
						// data to send in our API request
						$api_params = array(
							'edd_action'=> 'activate_license',
							'license' 	=> PMXI_Plugin::decode($options['licenses'][$class]),
							'item_name' => urlencode( $product_name ), // the name of our product in EDD
							'url' => home_url()
						);

						// Call the custom API.
						$response = wp_remote_get( esc_url_raw(add_query_arg( $api_params, $options['info_api_url_new'].'/check_license' )), array( 'timeout' => 15, 'sslverify' => true ) );

						// make sure the response came back okay
						if ( is_wp_error( $response ) )
							continue;

						$adapter = new \Wpai\App\License\ResponseAdapter();

						$status = $adapter->adapt( array(
							'error' => false,
							'code'  => (int) wp_remote_retrieve_response_code( $response ),
							'body'  => (string) wp_remote_retrieve_body( $response ),
						), time() );

						// Non-definitive: a 503, an error page, a truncated body.
						// Dereferencing ->license here stores null and presents
						// our outage as the customer's problem.
						if ( $status === null || $status->license() === null ) {
							continue;
						}

						// Each iteration blocks on wp_remote_get, and updateOption()
						// writes the whole row, so writing back the copy read before
						// the first request re-asserts every other option as it stood
						// then. Read past the object cache, which is already warm from
						// plugins_loaded and would return that same stale snapshot.
						$option_name = get_class(PMXI_Plugin::getInstance()) . '_Options';
						wp_cache_delete($option_name, 'options');
						$fresh = get_option($option_name);

						if ( ! is_array($fresh)) {
							$fresh = $options;
						}

						// updateOption() throws for any key outside the declared set,
						// and this is a raw row read, so clip to the declared keys.
						// Declared means config/options.php, not getOption(): that one
						// is filtered and can carry an add-on's own key.
						$declared = PMXI_Config::createFromFile(PMXI_Plugin::ROOT_DIR . '/config/options.php')->toArray();
						$fresh    = array_intersect_key($fresh, $declared) + array_intersect_key($options, $declared) + $declared;

						if ( ! isset($fresh['statuses']) || ! is_array($fresh['statuses'])) {
							$fresh['statuses'] = array();
						}

						$fresh['statuses'][$class] = $status->license();
						$options['statuses'] = $fresh['statuses'];

						PMXI_Plugin::getInstance()->updateOption($fresh);
					}
				}

			}

		}
	}

	/*
    *
    * Activate licenses for main plugin and all premium addons
    *
    */
	protected function activate_scheduling_licenses()
	{
		// listen for our activate button to be clicked

		delete_transient(PMXI_Plugin::$cache_key);

		delete_site_transient('update_plugins');

		// retrieve the license from the database
		return $this->licenseActivator->activateLicense(PMXI_Plugin::getSchedulingName(),\Wpai\App\Service\License\LicenseActivator::CONTEXT_SCHEDULING);

	}

	/*
	*
	* Check plugin's license
	*
	*/
	/**
	 * @param string $class
	 * @param bool   $manual Whether this is a Save on the licence form, which is
	 *                       stricter than a background recheck: a definitive
	 *                       refusal blocks now rather than opening a window.
	 * @return string|false
	 */
	public function check_license($class, $manual = true) {

		global $wp_version;

		delete_transient(PMXI_Plugin::$cache_key);

		delete_site_transient('update_plugins');

		// The core product goes through the refresh, so a Save records the same state a
		// background recheck would. It persists its three fields itself: the array
		// getOption() returns is filtered and can carry an add-on's own key, which
		// updateOption() throws for.
		if ( $class === \Wpai\App\License\Licensing::PRODUCT_CLASS ) {
			$result = \Wpai\App\License\Licensing::instance()->recheck($manual);

			$statuses = isset($result['options']['statuses']) ? $result['options']['statuses'] : array();
			$status   = isset($statuses[$class]) ? $statuses[$class] : '';

			return (is_string($status) and $status !== '') ? $status : false;
		}

		$options = PMXI_Plugin::getInstance()->getOption();

		if (!empty($options['licenses'][$class])){

			$product_name = (method_exists($class, 'getEddName')) ? call_user_func(array($class, 'getEddName')) : false;

			if ( $product_name !== false ){

				$api_params = array(
					'edd_action' => 'check_license',
					'license' => PMXI_Plugin::decode($options['licenses'][$class]),
					'item_name' => urlencode( $product_name )
				);

				// Call the custom API.
				$response = wp_remote_get( esc_url_raw(add_query_arg( $api_params, $options['info_api_url_new'].'/check_license' )), array( 'timeout' => 15, 'sslverify' => true ) );

				if ( is_wp_error( $response ) )
					return false;

				$adapter = new \Wpai\App\License\ResponseAdapter();

				$status = $adapter->adapt( array(
					'error' => false,
					'code'  => (int) wp_remote_retrieve_response_code( $response ),
					'body'  => (string) wp_remote_retrieve_body( $response ),
				), time() );

				return $status === null ? false : $status->license();

			}
		}

		return false;

	}

	public function check_scheduling_license()
	{
		$options = PMXI_Plugin::getInstance()->getOption();

		delete_transient(PMXI_Plugin::$cache_key);

		return $this->licenseActivator->checkLicense(PMXI_Plugin::getSchedulingName(), $options, \Wpai\App\Service\License\LicenseActivator::CONTEXT_SCHEDULING);
	}

	public function cleanup( $is_cron = false ){

		// The cron entry point has no nonce and cannot have one: wp_loaded_99 has already
		// proved the caller knows the secret key, which is that route's credential.
		if ( ! $is_cron ) {
			$nonce = (!empty($_REQUEST['_wpnonce'])) ? $_REQUEST['_wpnonce'] : '';
			if ( ! wp_verify_nonce( $nonce, '_wpnonce-cleanup_logs' ) ) {
				die( __('Security check', 'wp-all-import-pro') );
			}
		}

		$removedFiles = 0;

		$wp_uploads = wp_upload_dir();

		$dir = $wp_uploads['basedir'] . DIRECTORY_SEPARATOR . PMXI_Plugin::TEMP_DIRECTORY;

		$cacheDir = PMXI_Plugin::ROOT_DIR . '/libraries/cache';

		$guards = array('index.php', '.htaccess');

		$files = array_diff(@scandir($dir), array_merge(array('.', '..'), $guards));

		$cacheFiles = @scandir($cacheDir);
		$cacheFiles = is_array($cacheFiles) ? @array_diff($cacheFiles, array('.','..')) : null;

		$removedFiles = count(is_array($files) ? $files : array()) + count(is_array($cacheFiles) ? $cacheFiles : array());

		$msg = __('Nothing to clean up. No temporary files were found.', 'wp-all-import-pro');

		if ( $removedFiles ){

			wp_all_import_clear_directory( $dir, $guards );

			wp_all_import_clear_directory( $cacheDir );

			$msg = sprintf(
				_n('Clean up complete. Removed %d temporary file.', 'Clean up complete. Removed %d temporary files.', $removedFiles, 'wp-all-import-pro'),
				$removedFiles
			);
		}

		// clean logs files
		$table = PMXI_Plugin::getInstance()->getTablePrefix() . 'history';
		global $wpdb;
		$histories = $wpdb->get_results("SELECT * FROM $table", ARRAY_A);

		if ( ! empty($histories) )
		{
			$importRecord = new PMXI_Import_Record();
			$importRecord->clear();
			foreach ($histories as $history) {
				$importRecord->getById($history['import_id']);
				if ( $importRecord->isEmpty() )
				{
					$historyRecord = new PMXI_History_Record();
					$historyRecord->getById($history['id']);
					if ( ! $historyRecord->isEmpty() ) {
						$historyRecord->delete();
					}
				}
				$importRecord->clear();
			}
		}

		// clean uploads folder
		$table = PMXI_Plugin::getInstance()->getTablePrefix() . 'files';
		$files = $wpdb->get_results("SELECT * FROM $table", ARRAY_A);

		$required_dirs = array();

		if ( ! empty($files) )
		{
			$importRecord = new PMXI_Import_Record();
			$importRecord->clear();
			foreach ($files as $file) {
				$importRecord->getById($file['import_id']);
				if ( $importRecord->isEmpty()){
					$fileRecord = new PMXI_File_Record();
					$fileRecord->getById($file['id']);
					if ( ! $fileRecord->isEmpty() ) {
						$fileRecord->delete();
					}
				}
				else
				{
					$path_parts = pathinfo(wp_all_import_get_absolute_path($file['path']));
					if ( ! empty($path_parts['dirname'])){
			            $path_all_parts = explode('/', $path_parts['dirname']);
			            $dirname = array_pop($path_all_parts);
			            if ( wp_all_import_isValidMd5($dirname)){
			            	$required_dirs[] = $path_parts['dirname'];
			            }
			        }
				}
				$importRecord->clear();
			}
		}

		$uploads_dir = $wp_uploads['basedir'] . DIRECTORY_SEPARATOR . PMXI_Plugin::UPLOADS_DIRECTORY;

		if (($dir = @opendir($uploads_dir . DIRECTORY_SEPARATOR)) !== false or ($dir = @opendir($uploads_dir)) !== false) {
			while(($file = @readdir($dir)) !== false) {
				$filePath = $uploads_dir . DIRECTORY_SEPARATOR . $file;

				if ( is_dir($filePath) and ! in_array($filePath, $required_dirs) and ( ! in_array($file, array('.', '..'))))
				{
					wp_all_import_rmdir($filePath);
				}
			}
		}

		if ( $is_cron )
		{
			return true;
		}
		else
		{
			wp_redirect(esc_url_raw(add_query_arg('pmxi_nt', urlencode($msg), $this->baseUrl))); die();
		}
	}

	public function dismiss(){

		PMXI_Plugin::getInstance()->updateOption("dismiss", 1);

		exit('OK');
	}

	public function dismiss_speed_up(){

		PMXI_Plugin::getInstance()->updateOption("dismiss_speed_up", 1);

		exit('OK');
	}

	public function meta_values(){

		if ( ! PMXI_Plugin::getInstance()->getAdminCurrentScreen()->is_ajax) { // call is only valid when send with ajax
			exit('nice try!');
		}

		if ( ! check_ajax_referer( 'wp_all_import_secure', 'security', false ) ){
			exit( json_encode(array('meta_values' => array())) );
		}

		global $wpdb;

		$meta_key = sanitize_text_field( wp_unslash( $_POST['key'] ) );

		$r = $wpdb->get_results($wpdb->prepare("SELECT DISTINCT postmeta.meta_value FROM {$wpdb->postmeta} as postmeta WHERE postmeta.meta_key = %s LIMIT 0,10", $meta_key), ARRAY_A);

		$meta_values = array();

		if ( ! empty($r) ){
			foreach ($r as $key => $value) { if (empty($value['meta_value'])) continue;
				$meta_values[] = esc_html($value['meta_value']);
			}
		}

		exit( json_encode(array('meta_values' => $meta_values)) );
	}

	/**
	 * upload.php
	 *
	 * Copyright 2009, Moxiecode Systems AB
	 * Released under GPL License.
	 *
	 * License: http://www.plupload.com/license
	 * Contributing: http://www.plupload.com/contributing
	 */
	public function upload(){

		if ( ! check_ajax_referer( 'wp_all_import_secure', '_wpnonce', false )){
			exit(json_encode(array("jsonrpc" => "2.0", "error" => array("code" => 100, "message" => __('Security check', 'wp-all-import-pro')), "id" => "id")));
		}

		$targetDir = self::$path;

		if (! is_dir($targetDir) || ! is_writable($targetDir)){
		    wp_mkdir_p($targetDir);
		}

		if (! is_dir($targetDir) || ! is_writable($targetDir)){
			delete_transient( self::$upload_transient );
			exit(json_encode(array("jsonrpc" => "2.0", "error" => array("code" => 100, "message" => __("Uploads folder is not writable.", "wp-all-import-pro")), "id" => "id")));
		}

		$cleanupTargetDir = true; // Remove old files
		$maxFileAge = 5 * 3600; // Temp file age in seconds

		// 5 minutes execution time
		@set_time_limit(5 * 60);

		// Uncomment this one to fake upload time
		// usleep(5000);

		// Get parameters
		$chunk = isset($_REQUEST["chunk"]) ? intval($_REQUEST["chunk"]) : 0;
		$chunks = isset($_REQUEST["chunks"]) ? intval($_REQUEST["chunks"]) : 0;
		$fileName = isset($_REQUEST["name"]) ? $_REQUEST["name"] : '';

		// Clean the fileName for security reasons
		$fileName = preg_replace('/[^\w\._]+/', '_', $fileName);

		if ( ! preg_match('%\W(xml|gzip|zip|csv|tsv|gz|json|txt|dat|psv|sql|xls|xlsx)$%i', trim(basename($fileName)))) {
			exit(json_encode(array("jsonrpc" => "2.0", "error" => array("code" => 100, "message" => __("Uploaded file must be XML, CSV, ZIP, GZIP, GZ, JSON, SQL, TXT, DAT or PSV", "wp-all-import-pro")), "id" => "id")));
		}

		// Make sure the fileName is unique but only if chunking is disabled
		if ($chunks < 2 && file_exists($targetDir . DIRECTORY_SEPARATOR . $fileName)) {
			$ext = strrpos($fileName, '.');
			$fileName_a = substr($fileName, 0, $ext);
			$fileName_b = substr($fileName, $ext);

			$count = 1;
			while (file_exists($targetDir . DIRECTORY_SEPARATOR . $fileName_a . '_' . $count . $fileName_b))
				$count++;

			$fileName = $fileName_a . '_' . $count . $fileName_b;
		}

		$filePath = $targetDir . DIRECTORY_SEPARATOR . $fileName;

		// Create target dir
		if (!file_exists($targetDir))
			@mkdir($targetDir);

		// Remove old temp files
		if ($cleanupTargetDir && is_dir($targetDir) && ($dir = opendir($targetDir))) {
			while (($file = readdir($dir)) !== false) {
				$tmpfilePath = $targetDir . DIRECTORY_SEPARATOR . $file;

				// Remove temp file if it is older than the max age and is not the current file
				if (preg_match('/\.part$/', $file) && (filemtime($tmpfilePath) < time() - $maxFileAge) && ($tmpfilePath != "{$filePath}.part")) {
					@unlink($tmpfilePath);
				}
			}

			closedir($dir);
		} else{
			delete_transient( self::$upload_transient );
			exit(json_encode(array("jsonrpc" => "2.0", "error" => array("code" => 100, "message" => __("Failed to open temp directory.", "wp-all-import-pro")), "id" => "id")));
		}


		// Look for the content type header
		if (isset($_SERVER["HTTP_CONTENT_TYPE"]))
			$contentType = $_SERVER["HTTP_CONTENT_TYPE"];

		if (isset($_SERVER["CONTENT_TYPE"]))
			$contentType = $_SERVER["CONTENT_TYPE"];

		// Handle non multipart uploads older WebKit versions didn't support multipart in HTML5
		if (strpos($contentType, "multipart") !== false) {
			if (isset($_FILES['async-upload']['tmp_name']) && is_uploaded_file($_FILES['async-upload']['tmp_name'])) {
				// Open temp file
				$out = fopen("{$filePath}.part", $chunk == 0 ? "wb" : "ab");
				if ($out) {
					// Read binary input stream and append it to temp file
					$in = fopen($_FILES['async-upload']['tmp_name'], "rb");

					if ($in) {
						while ($buff = fread($in, 4096))
							fwrite($out, $buff);
					} else {
						delete_transient( self::$upload_transient );
						exit(json_encode(array("jsonrpc" => "2.0", "error" => array("code" => 101, "message" => __("Failed to open input stream.", "wp-all-import-pro")), "id" => "id")));
					}
					fclose($in);
					fclose($out);
					@unlink($_FILES['async-upload']['tmp_name']);
				} else {
					delete_transient( self::$upload_transient );
					exit(json_encode(array("jsonrpc" => "2.0", "error" => array("code" => 102, "message" => __("Failed to open output stream.", "wp-all-import-pro")), "id" => "id")));
				}
			} else{
				delete_transient( self::$upload_transient );
				exit(json_encode(array("jsonrpc" => "2.0", "error" => array("code" => 103, "message" => __("Failed to move uploaded file.", "wp-all-import-pro")), "id" => "id")));
			}
		} else {
			// Open temp file
			$out = fopen("{$filePath}.part", $chunk == 0 ? "wb" : "ab");
			if ($out) {
				// Read binary input stream and append it to temp file
				$in = fopen("php://input", "rb");

				if ($in) {
					while ($buff = fread($in, 4096))
						fwrite($out, $buff);
				} else{
					delete_transient( self::$upload_transient );
					exit(json_encode(array("jsonrpc" => "2.0", "error" => array("code" => 101, "message" => __("Failed to open input stream.", "wp-all-import-pro")), "id" => "id")));
				}

				fclose($in);
				fclose($out);
			} else{
				delete_transient( self::$upload_transient );
				exit(json_encode(array("jsonrpc" => "2.0", "error" => array("code" => 102, "message" => __("Failed to open output stream.", "wp-all-import-pro")), "id" => "id")));
			}
		}

		$post_type = false;

		$taxonomy_type = false;

		$notice = false;

        $bundle_xpath = false;

        $template = false;

		// declare gravity form title variable
		$gravity_form_title = null;

		// Check if file has been uploaded
		if (!$chunks || $chunk == $chunks - 1) {
			// Strip the temp .part suffix off
			$res = rename("{$filePath}.part", $filePath);
			if (!$res){
				@copy("{$filePath}.part", $filePath);
				@unlink("{$filePath}.part");
			}
			@chmod($filePath, 0755);
			delete_transient( self::$upload_transient );

			$errors = new WP_Error;

			// Check if alternative Excel processing is requested
			if (!empty($_POST['use_alternative_excel']) && $_POST['use_alternative_excel'] === '1') {
				global $wp_all_import_force_alternative_excel;
				$wp_all_import_force_alternative_excel = true;

				// Store in session for later use when import is created
				if (!empty(PMXI_Plugin::$session)) {
					PMXI_Plugin::$session->set('use_alternative_excel_processing', true);
					PMXI_Plugin::$session->save_data();
				}
			}

			$parse_options = PMXI_ParseOptions::for_import_id($this->input->get('id', 0));
			$uploader = new PMXI_Upload($filePath, $errors, rtrim(str_replace(basename($filePath), '', $filePath), '/'), null === $parse_options ? PMXI_ParseOptions::for_new_import() : $parse_options);

			$upload_result = $uploader->upload();

			if ($upload_result instanceof WP_Error){

			    $errors = $upload_result;

				$msgs = $errors->get_error_messages();
				ob_start();
				?>
				<?php foreach ($msgs as $msg): ?>
					<p><?php echo $msg ?></p>
				<?php endforeach ?>
				<?php
				$response = ob_get_clean();

				exit(json_encode(array("jsonrpc" => "2.0", "error" => array("code" => 102, "message" => $response), "id" => "id")));

			} else {

				if ( ! empty($upload_result['post_type'])) {
					$post_type = $upload_result['post_type'];
					$taxonomy_type = $upload_result['taxonomy_type'];
					$gravity_form_title = $upload_result['gravity_form_title'];
                    $bundle_xpath = $upload_result['bundle_xpath'];
                    $template = $upload_result['template'];
					switch ( $post_type ) {
						case 'shop_order':
							if ( ! class_exists('WooCommerce') ) {
								$notice = __('<p class="wpallimport-bundle-notice">The import bundle you are using requires WooCommerce.</p><a class="upgrade_link" href="https://wordpress.org/plugins/woocommerce/" target="_blank">Get WooCommerce</a>.', 'wp-all-import-pro');
							} else {
								if ( ! defined('PMWI_EDITION') ) {
									$notice = __('<p class="wpallimport-bundle-notice">The import bundle you are using requires the Pro version of the WooCommerce Add-On.</p><a href="https://www.wpallimport.com/checkout/?edd_action=add_to_cart&download_id=5839961&edd_options%5Bprice_id%5D=1&discount=welcome-upgrade-169" class="upgrade_link" target="_blank">Purchase the WooCommerce Add-On</a>.', 'wp-all-import-pro');
								} elseif ( PMWI_EDITION != 'paid' ) {
									$notice = __('<p class="wpallimport-bundle-notice">The import bundle you are using requires the Pro version of the WooCommerce Add-On, but you have the free version installed.</p><a href="https://www.wpallimport.com/checkout/?edd_action=add_to_cart&download_id=5839961&edd_options%5Bprice_id%5D=1&discount=welcome-upgrade-169" target="_blank" class="upgrade_link">Purchase the WooCommerce Add-On</a>.', 'wp-all-import-pro');
								}
							}
							break;
						case 'import_users':
							if ( ! class_exists('PMUI_Plugin') ) {
								$notice = __('<p class="wpallimport-bundle-notice">The import bundle you are using requires the User Add-On.</p><a href="https://www.wpallimport.com/checkout/?edd_action=add_to_cart&download_id=5839963&edd_options%5Bprice_id%5D=1&discount=welcome-upgrade-169" target="_blank" class="upgrade_link">Purchase the User Add-On</a>.', 'wp-all-import-pro');
							}
							break;
						case 'shop_customer':
							if ( ! class_exists('WooCommerce') ) {
								$notice = __('<p class="wpallimport-bundle-notice">The import bundle you are using requires WooCommerce.</p><a class="upgrade_link" href="https://wordpress.org/plugins/woocommerce/" target="_blank">Get WooCommerce</a>.', 'wp-all-import-pro');
							} elseif ( ! wp_all_import_is_user_addon_pro_active() ) {
								$notice = __('<p class="wpallimport-bundle-notice">The import bundle you are using requires the User Import Add-On Pro.</p><p class="wpallimport-upgrade-links-container"><a href="https://www.wpallimport.com/checkout/?edd_action=add_to_cart&download_id=5839963&edd_options%5Bprice_id%5D=1&discount=welcome-upgrade-169" target="_blank" class="upgrade_link">Purchase the User Import Add-On Pro</a>.</p>', 'wp-all-import-pro');
							}
							break;
						default:
							# code...
							break;
					}
				}

				if ( ! empty($upload_result['is_empty_bundle_file'])) {
					// Return JSON-RPC response
					exit(json_encode(array("jsonrpc" => "2.0", "error" => null, "result" => null, "id" => "id", "name" => $upload_result['filePath'], "post_type" => $post_type, "taxonomy_type" => $taxonomy_type, "gravity_form_title" => $gravity_form_title, "notice" => $notice, "template" => $template, "bundle_xpath" => $bundle_xpath, "url_bundle" => true)));
				}
				else {

					// validate XML
					$file = new PMXI_Chunk($upload_result['filePath'], array('element' => $upload_result['root_element']));

					$is_valid = true;

					if ( ! empty($file->options['element']) ) {
                        $defaultXpath = "/". $file->options['element'];
                    }
					else {
                        $is_valid = false;
                    }

					if ( $is_valid ) {

						while ($xml = $file->read()) {

					    	if ( ! empty($xml) ) {

					      		//PMXI_Import_Record::preprocessXml($xml);
					      		$xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" . "\n" . $xml;
						      	$dom = new DOMDocument( '1.0', 'UTF-8' );
								$old = libxml_use_internal_errors(true);
								$dom->loadXML($xml);
								libxml_use_internal_errors($old);
								$xpath = new DOMXPath($dom);

								if (($elements = $xpath->query($defaultXpath)) and $elements->length){
									break;
								}

						    }
						}
						if ( empty($xml) ) {
                            $is_valid = false;
                        }
					}

					unset($file);

					if ( ! preg_match('%\W(xml)$%i', trim($upload_result['source']['path']))) @unlink($upload_result['filePath']);

					if ( ! $is_valid ) {

						ob_start();

						?>

						<div class="error inline"><p><?php _e('Please confirm you are importing a valid feed.<br/> Often, feed providers distribute feeds with invalid data, improperly wrapped HTML, line breaks where they should not be, faulty character encodings, syntax errors in the XML, and other issues.<br/><br/>WP All Import has checks in place to automatically fix some of the most common problems, but we can’t catch every single one.<br/><br/>It is also possible that there is a bug in WP All Import, and the problem is not with the feed.<br/><br/>If you need assistance, please contact support – <a href="mailto:support@wpallimport.com">support@wpallimport.com</a> – with your XML/CSV file. We will identify the problem and release a bug fix if necessary.', 'wp-all-import-pro'); ?></p></div>

						<?php

						$response = ob_get_clean();

						$file_type = strtoupper(pmxi_getExtension($upload_result['source']['path']));

						$error_message = sprintf(__("This %s file has errors and is not valid.", "wp-all-import-pro"), $file_type);

						exit(json_encode(array("jsonrpc" => "2.0", "error" => array("code" => 102, "message" => $error_message), "is_valid" => false, "id" => "id")));

					}
					else {
					    $copyFileAllowed = apply_filters('wp_all_import_copy_uploaded_file_into_files_folder', true);
					    if ($copyFileAllowed) {
                            $wp_uploads = wp_upload_dir();
                            $uploads = $wp_uploads['basedir'] . DIRECTORY_SEPARATOR . PMXI_Plugin::FILES_DIRECTORY . DIRECTORY_SEPARATOR;
                            if ( ! file_exists($uploads . basename($filePath))) {
                                @copy($filePath, $uploads . basename($filePath));
                            }
                        }
					}
				}
			}
		}

		// Return JSON-RPC response
		exit(json_encode(array("jsonrpc" => "2.0", "error" => null, "result" => null, "id" => "id", "name" => $filePath, "post_type" => $post_type, "taxonomy_type" => $taxonomy_type, "gravity_form_title" => $gravity_form_title, "notice" => $notice)));

	}

}
