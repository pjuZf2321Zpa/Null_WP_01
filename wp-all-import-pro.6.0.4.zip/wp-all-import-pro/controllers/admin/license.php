<?php 
/**
 * Admin License page
 *
 * @author Maksym Tsypliakov <maksym.tsypliakov@gmail.com>
 */
class PMXI_Admin_License extends PMXI_Controller_Admin {
	
	public function index() {			

		$this->data['post'] = $post = $this->postWithStoredOptions();

		$this->data['addons']['PMXI_Plugin'] = array(
			'title' => __('WP All Import', 'wp-all-import-pro'),
			'active' => (class_exists('PMXI_Plugin') and defined('PMXI_EDITION') and PMXI_EDITION == 'paid')
		);

		$this->data['addons'] = array_reverse($this->data['addons']);

		if ($this->input->post('is_licenses_submitted')) { // save settings form

			check_admin_referer('edit-licenses', '_wpnonce_edit-licenses');													

			if ( ! $this->errors->get_error_codes()) { // no validation errors detected																

				$this->saveOptions($post);

				if (empty($_POST['pmxi_license_activate']) and empty($_POST['pmxi_license_deactivate'])) {
					foreach ($this->data['addons'] as $class => $addon) {
						$status = $this->check_license($class);

						if (is_string($status) and $status !== '') {
							$post['statuses'][$class] = $status;
						}
					}					
					$this->saveOptions($post);
				}				

				isset( $_POST['pmxi_license_activate'] ) and $this->activate_licenses();

				isset( $_POST['pmxi_license_deactivate'] ) and $this->deactivate_licenses();

				// The branches above write only the legacy `statuses` option, but the gate
				// decides on the cached licence state, and without this a key accepted here
				// leaves the site blocked. recheck(), not check(): only recheck refreshes it.
				\Wpai\App\License\Licensing::instance()->recheck(true);

				wp_redirect(esc_url_raw(add_query_arg('pmxi_nt', urlencode(__('Licenses saved', 'wp-all-import-pro')), $this->baseUrl))); die();
			}

		}		
		else{

			// From the option, not $post: $post is $_POST merged over the options, so a
			// crafted request could otherwise put its own status on the screen.
			$statuses = PMXI_Plugin::getInstance()->getOption('statuses');

			$this->data['post']['statuses'] = is_array($statuses) ? $statuses : array();
		}

		$this->render();
	}	

	/*
	*
	* Activate licenses for main plugin and all premium addons
	*
	*/
	protected function activate_licenses() {

		// listen for our activate button to be clicked
		if( isset( $_POST['pmxi_license_activate'] ) ) {			

			// retrieve the license from the database
			$options = PMXI_Plugin::getInstance()->getOption();
			
			foreach ($_POST['pmxi_license_activate'] as $class => $val) {							

				if (!empty($options['licenses'][$class])){

					$product_name = (method_exists($class, 'getEddName')) ? call_user_func(array($class, 'getEddName')) : false;

					if ( $product_name !== false ){
						// data to send in our API request
						$api_params = array( 
							'edd_action'=> 'activate_license', 
							'license' 	=> $options['licenses'][$class], 
							'item_name' => urlencode( $product_name ) // the name of our product in EDD
						);
						
						// Call the custom API.
						$response = wp_remote_get( esc_url_raw(add_query_arg( $api_params, $options['info_api_url_new'].'/check_license' )), array( 'timeout' => 15, 'sslverify' => true ) );

						// make sure the response came back okay
						if ( is_wp_error( $response ) )
							continue;

						$status = ( new \Wpai\App\License\ResponseAdapter() )->adapt( array(
							'error' => false,
							'code'  => (int) wp_remote_retrieve_response_code( $response ),
							'body'  => (string) wp_remote_retrieve_body( $response ),
						), time() );

						// Non-definitive answers, a 503 or an error page, change nothing.
						if ( $status === null || $status->license() === null ) {
							continue;
						}

						$options['statuses'][$class] = $status->license();
						
						PMXI_Plugin::getInstance()->updateOption(array('statuses' => $options['statuses']));	
					}
				}

			}				

		}
	}

	/*
	*
	* Deactivate licenses for main plugin and all premium addons
	*
	*/
	protected function deactivate_licenses(){

		// listen for our activate button to be clicked
		if( isset( $_POST['pmxi_license_deactivate'] ) ) {	

			// retrieve the license from the database
			$options = PMXI_Plugin::getInstance()->getOption();	

			foreach ($_POST['pmxi_license_deactivate'] as $class => $val) {		

				if (!empty($options['licenses'][$class])){

					$product_name = (method_exists($class, 'getEddName')) ? call_user_func(array($class, 'getEddName')) : false;

					if ( $product_name !== false ){

						// data to send in our API request
						$api_params = array( 
							'edd_action'=> 'deactivate_license', 
							'license' 	=> $options['licenses'][$class], 
							'item_name' => urlencode( $product_name ) // the name of our product in EDD
						);
						
						// Call the custom API.
						$response = wp_remote_get( esc_url_raw(add_query_arg( $api_params, $options['info_api_url_new'].'/check_license' )), array( 'timeout' => 15, 'sslverify' => true ) );

						// make sure the response came back okay
						if ( is_wp_error( $response ) )
							continue;

						$status = ( new \Wpai\App\License\ResponseAdapter() )->adapt( array(
							'error' => false,
							'code'  => (int) wp_remote_retrieve_response_code( $response ),
							'body'  => (string) wp_remote_retrieve_body( $response ),
						), time() );

						if ( $status === null ) {
							continue;
						}

						// The deployed server never emits 'deactivated', so this branch is unreachable.
						if( $status->license() === 'deactivated' ){

							$options['statuses'][$class] = 'deactivated';

							PMXI_Plugin::getInstance()->updateOption(array('statuses' => $options['statuses']));	

						}							
					}
				}
			}			
		}
	}

	/*
	*
	* Check plugin's license
	*
	*/
	public static function check_license($class) {

		global $wp_version;

		$options = PMXI_Plugin::getInstance()->getOption();	

		if (!empty($options['licenses'][$class])){

			$product_name = (method_exists($class, 'getEddName')) ? call_user_func(array($class, 'getEddName')) : false;

			if ( $product_name !== false ){

				$api_params = array( 
					'edd_action' => 'check_license', 
					'license' => $options['licenses'][$class], 
					'item_name' => urlencode( $product_name ) 
				);

				// Call the custom API.
				$response = wp_remote_get( esc_url_raw(add_query_arg( $api_params, $options['info_api_url_new'].'/check_license' )), array( 'timeout' => 15, 'sslverify' => true ) );

				if ( is_wp_error( $response ) )
					return false;

				$status = ( new \Wpai\App\License\ResponseAdapter() )->adapt( array(
					'error' => false,
					'code'  => (int) wp_remote_retrieve_response_code( $response ),
					'body'  => (string) wp_remote_retrieve_body( $response ),
				), time() );

				return $status === null ? false : $status->license();

				/*if( $license_data->license == 'valid' ) {
					return true;
				
				} else {
					return false;
				
				}*/
			}
		}

		return false;

	}
}