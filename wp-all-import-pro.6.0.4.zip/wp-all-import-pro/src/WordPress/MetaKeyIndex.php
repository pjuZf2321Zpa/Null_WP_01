<?php

namespace Wpai\WordPress;

/**
 * The distinct meta keys of one meta table, collected in primary-key slices and kept
 * in an option, so the Custom Fields autocomplete can match anywhere in a key without
 * a query that reads every row: meta_key has only a 191-character prefix index, which
 * cannot seek past a key, so any live DISTINCT over a large table scans all of it.
 */
class MetaKeyIndex {

	const OPTION_PREFIX = 'wp_all_import_meta_keys_';
	const CRON_HOOK = 'wpai_build_meta_key_index';
	// Small enough that a slice of all-distinct keys stays well inside a 128 MB memory limit.
	const SLICE = 25000;
	const MAX_KEYS = 10000;
	const REBUILD_AFTER = 604800;
	const MAX_TOTAL = 30000;
	const FLOOR = 200;
	const ALL = '*';

	/** @var array<string, string> meta table property => primary key column */
	private static $tables = array(
		'usermeta'    => 'umeta_id',
		'termmeta'    => 'meta_id',
		'commentmeta' => 'meta_id',
		'postmeta'    => 'meta_id',
	);

	/** @var string */
	private $name;

	/** @var string */
	private $table;

	/** @var string */
	private $idColumn;

	/**
	 * @param string $name usermeta, termmeta, commentmeta or postmeta
	 * @return self|null
	 */
	public static function forTable( $name ) {
		global $wpdb;

		if ( ! isset( self::$tables[ $name ] ) || empty( $wpdb->$name ) ) {
			return null;
		}

		return new self( $name, $wpdb->$name, self::$tables[ $name ] );
	}

	/** @return string[] */
	public static function tableNames() {
		return array_keys( self::$tables );
	}

	private function __construct( $name, $table, $idColumn ) {
		$this->name     = $name;
		$this->table    = $table;
		$this->idColumn = $idColumn;
	}

	/**
	 * Keys matching $term anywhere, ignoring case and accents, keys that start with it first.
	 *
	 * @param string   $term
	 * @param int      $limit
	 * @param callable $exclude receives a key, returns true to leave it out
	 * @param float    $budget seconds of scanning this request may spend
	 * @param string[] $groups post types for postmeta; ignored for the other tables
	 * @param callable $prefilter receives and returns the candidate key list
	 * @return string[]
	 */
	public function search( $term, $limit, $exclude = null, $budget = 1.0, $groups = array(), $prefilter = null ) {
		global $wpdb;

		$term   = (string) $term;
		$groups = $this->grouped() ? array_values( array_filter( array_map( 'strval', (array) $groups ), 'strlen' ) ) : array( '' );
		if ( ! $groups ) {
			return array();
		}

		$state = $this->advance( $budget );
		$keys  = array();
		foreach ( $groups as $group ) {
			$keys = array_merge( $keys, isset( $state['keys'][ $group ] ) ? $state['keys'][ $group ] : array() );
			if ( $state['building'] && isset( $state['scan'][ $group ] ) ) {
				$keys = array_merge( $keys, $state['scan'][ $group ] );
			}
		}

		// Past the cap the list holds only the first keys found, so a later one is
		// looked up the way it was before the list existed, within a time limit.
		if ( '' !== $term && $this->capped( $state, $groups ) ) {
			// phpcs:ignore WordPress.DB.PreparedSQL -- prepared inside; bounded() only prefixes a time limit.
			$live = $wpdb->get_col( self::bounded( $this->prefixQuery( $term, $limit, $groups ), 1 ) );
			$keys = array_merge( $keys, array_map( 'strval', (array) $live ) );
		}

		$keys = array_values( array_unique( array_filter( $keys, 'strlen' ) ) );
		if ( $prefilter ) {
			$keys = array_values( array_map( 'strval', (array) call_user_func( $prefilter, $keys ) ) );
		}

		$needle  = self::fold( $term );
		$leading = array();
		$inside  = array();

		foreach ( $keys as $key ) {
			if ( $exclude && call_user_func( $exclude, $key ) ) {
				continue;
			}
			if ( '' === $needle ) {
				$leading[] = $key;
				continue;
			}
			$position = strpos( self::fold( $key ), $needle );
			if ( 0 === $position ) {
				$leading[] = $key;
			} elseif ( false !== $position ) {
				$inside[] = $key;
			}
		}

		sort( $leading, SORT_STRING | SORT_FLAG_CASE );
		sort( $inside, SORT_STRING | SORT_FLAG_CASE );

		return array_slice( array_merge( $leading, $inside ), 0, max( 1, (int) $limit ) );
	}

	/** @return bool whether every row of the table has been read into the list */
	public function isComplete() {
		return ! $this->state()['building'];
	}

	/**
	 * Scan slices until the table is covered or the budget is spent, and save progress.
	 *
	 * @param float $budget seconds; 0 reads one slice
	 * @return array the saved state
	 */
	public function advance( $budget ) {
		if ( ! $this->lock() ) {
			return $this->listed( $this->state() );
		}

		try {
			return $this->scan( $budget );
		} finally {
			$this->unlock();
		}
	}

	private function scan( $budget ) {
		global $wpdb;

		$state = $this->state();

		if ( ! $state['building'] && $state['built_at'] && ( time() - $state['built_at'] ) > self::REBUILD_AFTER ) {
			$state = $this->restart( $state );
		}

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table and column come from the fixed map above.
		$max = $wpdb->get_var( "SELECT MAX({$this->idColumn}) FROM {$this->table}" );
		if ( '' !== (string) $wpdb->last_error ) {
			return $this->listed( $state );
		}
		$max = (int) $max;

		// Rows deleted from the top leave every id below the cursor read; only a table
		// emptied and refilled hands those ids out again.
		$clamped = false;
		if ( $max < $state['cursor'] ) {
			if ( $state['cursor'] - $max > self::SLICE ) {
				$state = $this->restart( $state );
			} else {
				$state['cursor'] = $max;
				$clamped          = true;
			}
		}

		if ( $state['cursor'] >= $max ) {
			if ( $state['building'] || $clamped ) {
				$state = $state['building'] ? $this->finish( $state ) : $state;
				$this->save( $state );
			}
			return $this->listed( $state );
		}

		$started = microtime( true );
		$read    = false;
		do {
			$found = $this->slice( $state['cursor'], $state['cursor'] + self::SLICE );
			if ( '' !== (string) $wpdb->last_error ) {
				break;
			}
			if ( $found ) {
				$read   = true;
				$target = $state['building'] ? 'scan' : 'keys';
				foreach ( $found as $pair ) {
					list( $group, $key ) = $pair;
					$held = isset( $state[ $target ][ $group ] ) ? count( $state[ $target ][ $group ] ) : 0;
					if ( isset( $state[ $target ][ $group ][ $key ] ) ) {
						continue;
					}
					// Past the total, each post type still keeps a few keys, so none disappears.
					$total = $this->total( $state[ $target ] );
					if ( $held >= self::MAX_KEYS || ( $total >= self::MAX_TOTAL && $held >= self::FLOOR ) || $total >= 2 * self::MAX_TOTAL ) {
						$state['truncated'][ $group ] = true;
						continue;
					}
					$state[ $target ][ $group ][ $key ] = true;
				}
				$state['cursor'] += self::SLICE;
			} else {
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$next = $wpdb->get_var( $wpdb->prepare( "SELECT MIN({$this->idColumn}) FROM {$this->table} WHERE {$this->idColumn} > %d", $state['cursor'] + self::SLICE ) );
				if ( '' !== (string) $wpdb->last_error ) {
					break;
				}
				$state['cursor'] = null === $next ? $max : (int) $next - 1;
			}

			// Once nothing more can be kept, the rest of the table would be read for nothing.
			$held = $state['building'] ? $state['scan'] : $state['keys'];
			if ( $this->grouped() && $this->total( $held ) >= self::MAX_TOTAL ) {
				$state['truncated'][ self::ALL ] = true;
			}
			if ( ! $this->grouped() && isset( $held[''] ) && count( $held[''] ) >= self::MAX_KEYS ) {
				$state['truncated'][ self::ALL ] = true;
				$state['cursor']                 = $max;
			}
			// An empty range costs one seek, so it does not use up a call that has read nothing yet.
		} while ( $state['cursor'] < $max && ( ! $read || ( microtime( true ) - $started ) < $budget ) );

		$state['cursor'] = min( $state['cursor'], $max );

		if ( $state['building'] && $state['cursor'] >= $max ) {
			$state = $this->finish( $state );
		}

		$this->save( $state );

		if ( $state['building'] && function_exists( 'wp_next_scheduled' ) && ! wp_next_scheduled( self::CRON_HOOK, array( $this->name ) ) ) {
			wp_schedule_single_event( time() + 10, self::CRON_HOOK, array( $this->name ) );
		}

		return $this->listed( $state );
	}

	/** A SELECT the server abandons after $seconds rather than letting it read a whole table. */
	private static function bounded( $select, $seconds ) {
		global $wpdb;

		if ( method_exists( $wpdb, 'db_server_info' ) && false !== stripos( (string) $wpdb->db_server_info(), 'mariadb' ) ) {
			return sprintf( 'SET STATEMENT max_statement_time=%d FOR %s', $seconds, $select );
		}

		return preg_replace( '/^SELECT /', sprintf( 'SELECT /*+ MAX_EXECUTION_TIME(%d) */ ', $seconds * 1000 ), $select );
	}

	private static function fold( $text ) {
		$text = (string) $text;
		if ( function_exists( 'remove_accents' ) ) {
			$text = remove_accents( $text );
		}

		return function_exists( 'mb_strtolower' ) ? mb_strtolower( $text, 'UTF-8' ) : strtolower( $text );
	}

	/** @return array<int, array{0: string, 1: string}> group and key pairs */
	private function slice( $from, $to ) {
		global $wpdb;

		if ( $this->grouped() ) {
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$rows = $wpdb->get_results( $wpdb->prepare( "SELECT DISTINCT p.post_type, m.meta_key FROM {$this->table} m JOIN {$wpdb->posts} p ON p.ID = m.post_id WHERE m.meta_id > %d AND m.meta_id <= %d AND p.post_type NOT IN ('revision', 'nav_menu_item', 'customize_changeset', 'oembed_cache', 'custom_css', 'user_request', 'wp_global_styles', 'wp_template', 'wp_template_part', 'wp_navigation')", $from, $to ), ARRAY_N );
		} else {
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$keys = (array) $wpdb->get_col( $wpdb->prepare( "SELECT DISTINCT meta_key FROM {$this->table} WHERE {$this->idColumn} > %d AND {$this->idColumn} <= %d", $from, $to ) );
			$rows = array_map( function ( $key ) {
				return array( '', $key );
			}, $keys );
		}

		$wpdb->flush();

		$pairs = array();
		foreach ( (array) $rows as $i => $row ) {
			$key = (string) $row[1];
			if ( '' !== $key ) {
				$pairs[] = array( (string) $row[0], $key );
			}
			unset( $rows[ $i ] );
		}

		return $pairs;
	}

	private function prefixQuery( $term, $limit, $groups ) {
		global $wpdb;

		$like  = $wpdb->esc_like( $term ) . '%';
		$limit = max( 1, (int) $limit );

		if ( $this->grouped() ) {
			$in = implode( ', ', array_fill( 0, count( $groups ), '%s' ) );

			// Candidates first from the key index, then one existence check each; joining
			// first walks every row of the type.
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders
			return $wpdb->prepare( "SELECT c.k FROM (SELECT DISTINCT meta_key AS k FROM {$this->table} WHERE meta_key LIKE %s LIMIT %d) c WHERE EXISTS (SELECT 1 FROM {$this->table} m JOIN {$wpdb->posts} p ON p.ID = m.post_id WHERE m.meta_key = c.k AND p.post_type IN ({$in}))", array_merge( array( $like, $limit * 5 ), $groups ) );
		}

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return $wpdb->prepare( "SELECT DISTINCT meta_key FROM {$this->table} WHERE meta_key LIKE %s LIMIT %d", $like, $limit );
	}

	private function capped( $state, $groups ) {
		foreach ( array( $state['truncated'], $state['prev_truncated'] ) as $flags ) {
			// Every post type keeps up to FLOOR keys past the total, so only its own flag says it was cut short.
			if ( ! $this->grouped() && ! empty( $flags[ self::ALL ] ) ) {
				return true;
			}
			foreach ( $groups as $group ) {
				if ( ! empty( $flags[ $group ] ) ) {
					return true;
				}
			}
		}
		foreach ( $groups as $group ) {
			if ( isset( $state['keys'][ $group ] ) && count( $state['keys'][ $group ] ) >= self::MAX_KEYS ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Whether an empty answer can be trusted: the whole table read, and the asked groups not cut short.
	 *
	 * @param string[] $groups
	 * @return bool
	 */
	public function isSettled( $groups = array() ) {
		$state = $this->listed( $this->state() );

		return ! $state['building'] && ! $this->capped( $state, $this->grouped() ? array_map( 'strval', (array) $groups ) : array( '' ) );
	}

	private function total( $groups ) {
		$total = 0;
		foreach ( $groups as $keys ) {
			$total += count( $keys );
		}

		return $total;
	}

	/** postmeta keys are kept per post type, so a product import is not offered order fields. */
	private function grouped() {
		return 'postmeta' === $this->name;
	}

	/**
	 * A named database lock, released by the server if the request dies. Engines
	 * without one (SQLite) answer null, and the scan then runs unlocked.
	 */
	private function lock() {
		global $wpdb;

		$acquired = $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, 0)', $this->lockName() ) );

		return '0' !== (string) $acquired;
	}

	private function unlock() {
		global $wpdb;

		$wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $this->lockName() ) );
	}

	private function lockName() {
		return 'wpai_meta_keys_' . md5( ( defined( 'DB_NAME' ) ? DB_NAME : '' ) . '.' . $this->table );
	}

	private function restart( $state ) {
		$state['building']       = true;
		$state['scan']           = array();
		$state['cursor']         = 0;
		$state['prev_truncated'] = $state['truncated'];
		$state['truncated']      = array();

		return $state;
	}

	private function finish( $state ) {
		$state['prev_truncated'] = array();
		$state['keys']     = $state['scan'];
		$state['scan']     = array();
		$state['building'] = false;
		$state['built_at'] = time();

		return $state;
	}

	/** usermeta is shared by every site of a network, so its list is too. */
	private function network() {
		return 'usermeta' === $this->name && function_exists( 'is_multisite' ) && is_multisite();
	}

	private function option() {
		return self::OPTION_PREFIX . $this->name;
	}

	private function state() {
		$saved = $this->network() ? get_site_option( $this->option() ) : get_option( $this->option() );
		$state = array(
			'keys'      => array(),
			'scan'      => array(),
			'cursor'    => 0,
			'building'  => true,
			'built_at'  => 0,
			'truncated' => array(),
			'prev_truncated' => array(),
		);

		if ( is_array( $saved ) ) {
			$state = array_merge( $state, array_intersect_key( $saved, $state ) );
		}

		// Lists saved before keys were grouped are a flat list of keys.
		$flat = is_array( $saved ) && ! isset( $saved['groups'] );
		foreach ( array( 'keys', 'scan' ) as $part ) {
			$groups = $flat ? array( '' => (array) $state[ $part ] ) : (array) $state[ $part ];
			$state[ $part ] = array();
			foreach ( $groups as $group => $keys ) {
				$state[ $part ][ (string) $group ] = array_fill_keys( array_map( 'strval', (array) $keys ), true );
			}
		}
		if ( $this->grouped() ) {
			unset( $state['keys'][''], $state['scan'][''] );
		}
		foreach ( array( 'truncated', 'prev_truncated' ) as $flags ) {
			$state[ $flags ] = is_array( $state[ $flags ] ) ? $state[ $flags ] : ( $state[ $flags ] ? array( self::ALL => true ) : array() );
		}
		$state['cursor']    = (int) $state['cursor'];

		return $state;
	}

	private function save( $state ) {
		$stored = $this->listed( $state );

		// Tables without groups keep the earlier flat shape, which an older build can still read.
		if ( ! $this->grouped() ) {
			foreach ( array( 'keys', 'scan' ) as $part ) {
				$stored[ $part ] = isset( $stored[ $part ][''] ) ? $stored[ $part ][''] : array();
			}
			$stored['truncated']      = ! empty( $stored['truncated'] );
			$stored['prev_truncated'] = ! empty( $stored['prev_truncated'] );
			unset( $stored['groups'] );
		}

		if ( $this->network() ) {
			update_site_option( $this->option(), $stored );
		} elseif ( false === get_option( $this->option() ) ) {
			add_option( $this->option(), $stored, '', 'no' );
		} else {
			update_option( $this->option(), $stored, false );
		}
	}

	private function listed( $state ) {
		foreach ( array( 'keys', 'scan' ) as $part ) {
			foreach ( $state[ $part ] as $group => $keys ) {
				$state[ $part ][ $group ] = array_map( 'strval', array_keys( $keys ) );
			}
		}
		$state['groups'] = true;

		return $state;
	}
}
