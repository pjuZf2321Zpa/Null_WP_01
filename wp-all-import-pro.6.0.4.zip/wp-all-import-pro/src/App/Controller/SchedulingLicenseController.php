<?php

namespace Wpai\App\Controller;

use PMXI_Plugin;
use Wpai\App\Service\License\LicenseActivator;
use Wpai\Http\JsonResponse;
use Wpai\Scheduling\LicensingManager;

class SchedulingLicenseController
{
    /** @var  LicensingManager */
    private $licensingManager;

    /** @var LicenseActivator  */
    private $licensingActivator;

    private $slug = 'wp-all-import-pro';

    public function __construct()
    {
        $this->licensingManager = new LicensingManager();
        $this->licensingActivator = new LicenseActivator();
    }

    public function getSchedulingLicense()
    {
        $options = \PMXI_Plugin::getInstance()->getOption();

        if (empty($options['scheduling_license'])) {
            return false;
        }

        return new JsonResponse(
            array(
                'license' => $this->licensingManager->checkLicense($options['scheduling_license'], \PMXI_Plugin::getSchedulingName())
            )
        );
    }

    public function saveSchedulingLicenseAction()
    {
        $license = $_POST['license'];

	    $licenseCheckResponse = $this->licensingManager->checkLicense($license, \PMXI_Plugin::getSchedulingName());
	    if(!empty($licenseCheckResponse['success'])) {
            PMXI_Plugin::getInstance()->updateOption(array('scheduling_license' => $license));
            $post['license_status'] = $this->check_scheduling_license();
            $response = $this->activate_scheduling_licenses();

	        if(class_exists('PMXE_Plugin')) {
		        if(method_exists('PMXE_Plugin', 'getSchedulingName')) {
			        if(!empty($post['license_status'])) {
				        $schedulingLicenseData = array();
				        $schedulingLicenseData['scheduling_license_status'] = $post['license_status'];
				        $schedulingLicenseData['scheduling_license'] = $license;

				        \PMXE_Plugin::getInstance()->updateOption($schedulingLicenseData);
			        }
		        }
	        }

            return new JsonResponse($licenseCheckResponse);
        } else {
            return new JsonResponse($licenseCheckResponse);
        }
    }

    /*
    *
    * Activate licenses for main plugin and all premium addons
    *
    */
    protected function activate_scheduling_licenses()
    {
        delete_transient(PMXI_Plugin::$cache_key);

        delete_site_transient('update_plugins');

        // retrieve the license from the database
        return $this->licensingActivator->activateLicense(PMXI_Plugin::getSchedulingName(),\Wpai\App\Service\License\LicenseActivator::CONTEXT_SCHEDULING);
    }

    public function check_scheduling_license()
    {
        $options = PMXI_Plugin::getInstance()->getOption();

        delete_transient(PMXI_Plugin::$cache_key);

        return $this->licensingActivator->checkLicense(PMXI_Plugin::getSchedulingName(), $options, LicenseActivator::CONTEXT_SCHEDULING);
    }
}