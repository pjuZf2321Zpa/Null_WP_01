<?php

namespace Wpai\App\Gate;

/**
 * Refuses only when a licence source can answer AND this is the paid edition:
 * free and Pro share every hook, callback, option and table name.
 */
final class Gate
{
    const EDITION_CONSTANT = 'PMXI_EDITION';

    const PAID = 'paid';

    /**
     * The symbol that proves PMXI_Plugin finished booting. Reading a plugin option
     * before it exists dies with an Error, which a catch on Exception does not catch.
     */
    const BOOT_MARKER = 'wp_all_import_url_title';

    const SETTINGS_PAGE = 'pmxi-admin-settings';

    /**
     * Actions still dispatchable on the Settings slug while blocked. Per action
     * rather than per slug: `upload` is a file upload wearing the Settings page's URL.
     *
     * @var string[]
     */
    const SETTINGS_ACTIONS = ['index', 'cleanup', 'dismiss', 'dismiss_speed_up'];

    /**
     * Screens that stay reachable for a named action while blocked.
     * `pmxi-admin-import` => `process` is deferred, not exempt: the wizard's chunk
     * loop gates itself, so a run in flight can be told why it stopped.
     *
     * @var array<string,string[]>
     */
    const SCREEN_ACTIONS = [
        'pmxi-admin-manage' => ['cancel'],
        'pmxi-admin-license' => ['index'],
        'pmxi-admin-import' => ['process'],
    ];

    /**
     * Routes the umbrella ajax dispatcher keeps open while blocked. Neither runs
     * an import.
     *
     * @var string[]
     */
    const API_ROUTES = ['schedulingConnection/index', 'schedulingLicense/saveSchedulingLicense'];

    /** @var self|null */
    private static $instance;

    /** @var LicenceSource */
    private $source;

    /** @var Messages */
    private $messages;

    /** @var array<int,bool>  import id => admitted in this request */
    private $admitted = [];

    /**
     * Kept rather than rethrown: the gate is bound to all_admin_notices,
     * rest_pre_dispatch and debug_information, where an escaping Throwable takes
     * out every admin page, the REST API or Site Health.
     *
     * @var \Throwable|null
     */
    private $sourceError;

    public function __construct(?LicenceSource $source = null, ?Messages $messages = null)
    {
        $this->source = $source ?: new ClientState();
        $this->messages = $messages ?: new Messages();
    }

    /**
     * Every call into the licence source goes through here. The source reads
     * options through a filter any third-party plugin can hook, so on a throw
     * the gate answers with the value that REFUSES NOTHING: "cannot tell" is
     * not "unlicensed".
     *
     * @param  string  $method  a LicenceSource method taking no arguments
     * @param  mixed  $whenBroken  the answer that refuses nothing
     * @return mixed
     */
    private function ask($method, $whenBroken)
    {
        if ($this->sourceError !== null) {
            return $whenBroken;
        }

        try {
            return $this->source->$method();
        } catch (\Throwable $e) {
            $this->sourceError = $e;

            return $whenBroken;
        }
    }

    /** @return bool */
    public function sourceBroken()
    {
        return $this->sourceError !== null;
    }

    /** @return string  the class and message, never a key or any customer data */
    public function sourceErrorSummary()
    {
        if ($this->sourceError === null) {
            return '';
        }

        return get_class($this->sourceError) . ': ' . $this->sourceError->getMessage();
    }

    /** @return self */
    public static function instance()
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    /** @return void */
    public static function reset()
    {
        self::$instance = null;
    }

    /** @return Messages */
    public function messages()
    {
        return $this->messages;
    }

    /** @return bool */
    public function isPaidEdition()
    {
        return defined(self::EDITION_CONSTANT) && constant(self::EDITION_CONSTANT) === self::PAID;
    }

    /** @return bool  false where PMXI_Plugin never booted: there are no options to read */
    public function determinable()
    {
        return function_exists(self::BOOT_MARKER);
    }

    /**
     * Whether the licence source could read the state it owns. Asked outright
     * rather than caught: the gateway underneath already swallows Throwable and
     * returns defaults, so an unreadable store is otherwise indistinguishable
     * from a site that never bought anything.
     *
     * @return bool
     */
    public function sourceDeterminable()
    {
        return (bool) $this->ask('determinable', false);
    }

    /** @return bool  about the machinery, not the answer: true on a licensed site too */
    public function enforcing()
    {
        return $this->determinable()
            && $this->ask('available', false)
            && $this->sourceDeterminable()
            && $this->isPaidEdition();
    }

    /** @return bool */
    public function blocks()
    {
        return $this->enforcing() && ! $this->ask('licensed', true);
    }

    /**
     * @param  string  $page    the already-lowercased, regex-matched slug
     * @param  string  $action
     * @return bool
     */
    public function blocksScreen($page, $action)
    {
        if (! $this->blocks()) {
            return false;
        }

        if ($page === self::SETTINGS_PAGE) {
            return ! in_array((string) $action, self::SETTINGS_ACTIONS, true);
        }

        if (isset(self::SCREEN_ACTIONS[$page])) {
            return ! in_array((string) $action, self::SCREEN_ACTIONS[$page], true);
        }

        return true;
    }

    /**
     * Route-level, because the umbrella dispatcher multiplexes must-gate and
     * must-stay-open routes behind one hook name.
     *
     * @param  string  $route  the raw $_GET['q']
     * @return bool
     */
    public function blocksApiRoute($route)
    {
        return $this->blocks() && ! in_array((string) $route, self::API_ROUTES, true);
    }

    /**
     * @param  object  $record  a PMXI_Import_Record
     * @return bool
     */
    public function blocksRun($record)
    {
        $id = isset($record->id) ? (int) $record->id : 0;

        // Before the licence source, not after: this runs once per chunk.
        if ($id !== 0 && isset($this->admitted[$id])) {
            return false;
        }

        if (! $this->blocks()) {
            return false;
        }

        if ($this->runInProgress($record)) {
            if ($id !== 0) {
                $this->admitted[$id] = true;
            }

            return false;
        }

        return true;
    }

    /** Written on a fresh run before any record is read, so it is not evidence of progress. */
    const INITIAL_CHUNK_POINTER = 1;

    /** The pointer that says how far a run got. */
    const RUN_PROGRESS_COLUMN = 'queue_chunk_number';

    /** The value at or below which a run has not got anywhere. */
    const RUN_PROGRESS_FLOOR = self::INITIAL_CHUNK_POINTER;

    /**
     * When the run last moved. Two, because the wizard and the cron/CLI runner
     * stamp different ones; the newest decides. The sibling plugin's column of
     * this name means something else, which is why each gate declares its own.
     *
     * @var string[]
     */
    const RUN_ACTIVITY_COLUMNS = ['registered_on', 'last_activity'];

    /** @var string[]  live flags a runner clears when it stops; the runners disagree on which */
    const RUN_LIVE_FLAGS = ['executing', 'triggered', 'processing'];

    /**
     * The run is over whatever its live flags still say. A list, not one test:
     * the failure handler clears only one of the three flags and stamps the clock.
     *
     * @var string[]
     */
    const RUN_ENDED_FLAGS = ['canceled', 'failed'];

    /**
     * How long after its last committed chunk a run stays resumable. The pointer
     * and the live flags are one-way and a crash runs no cleanup, so without a
     * clock a run that died months ago still reads as in flight.
     */
    const RUN_STALE_AFTER_SECONDS = 86400;

    /**
     * Advanced, not marked ended, still carrying a live flag, and still moving.
     * `> INITIAL_CHUNK_POINTER` rather than `> 0` because execute() writes 1
     * during the first request, before any record exists.
     *
     * @param  object  $record
     * @return bool
     */
    public function runInProgress($record)
    {
        $pointer = self::RUN_PROGRESS_COLUMN;

        if (! isset($record->$pointer)
            || (int) $record->$pointer <= self::RUN_PROGRESS_FLOOR) {
            return false;
        }

        if ($this->runEnded($record)) {
            return false;
        }

        foreach (self::RUN_LIVE_FLAGS as $flag) {
            if (isset($record->$flag) && (int) $record->$flag > 0) {
                return $this->advancedRecently($record);
            }
        }

        return false;
    }

    /** @return bool  whether a marker says the run is over, whatever its live flags still say */
    private function runEnded($record)
    {
        foreach (self::RUN_ENDED_FLAGS as $ended) {
            if (isset($record->$ended) && (int) $record->$ended > 0) {
                return true;
            }
        }

        return false;
    }

    /** Not `failed`: that column's writer fires pmxi_import_failed, and nothing broke. */
    const RUN_STOPPED_FLAG = 'canceled';

    /** The clock beside RUN_STOPPED_FLAG that both its writers stamp. */
    const RUN_STOPPED_AT_COLUMN = 'canceled_on';

    /**
     * Says a stop was the gate's doing rather than a customer clicking Cancel. It
     * holds the RUN_STOPPED_AT_COLUMN value written beside it, so any later writer
     * of that column invalidates it without having to know it exists.
     */
    const RUN_STOPPED_MARKER = 'licence_stopped_on';

    /** @return bool  whether the run got past the pointer every entry point starts it at */
    public function runAdvanced($record)
    {
        $pointer = self::RUN_PROGRESS_COLUMN;

        return isset($record->$pointer)
            && (int) $record->$pointer > self::RUN_PROGRESS_FLOOR;
    }

    /** @return bool  false for a run refused on its way in or one that already ended: nothing to mark */
    public function stopsRunInFlight($record)
    {
        if ($this->runEnded($record)) {
            return false;
        }

        foreach (self::RUN_LIVE_FLAGS as $flag) {
            if (isset($record->$flag) && (int) $record->$flag > 0) {
                return true;
            }
        }

        return false;
    }

    /**
     * RUN_PROGRESS_COLUMN is deliberately absent, as is anything touching the
     * imported records: they are what let a renewed customer continue.
     *
     * @return array<string,mixed>
     */
    public function runStopFields($stoppedAt)
    {
        $fields = [];

        foreach (self::RUN_LIVE_FLAGS as $flag) {
            $fields[$flag] = 0;
        }

        $fields[self::RUN_STOPPED_FLAG] = 1;
        $fields[self::RUN_STOPPED_AT_COLUMN] = (string) $stoppedAt;

        return $fields;
    }

    /** @return bool  whether there was anything to write */
    public function stopRun($record)
    {
        if (! $this->stopsRunInFlight($record) || $this->alreadyStopped($record)) {
            return false;
        }

        $stoppedAt = date('Y-m-d H:i:s');

        $options = isset($record->options) && is_array($record->options) ? $record->options : [];
        $options[self::RUN_STOPPED_MARKER] = $stoppedAt;

        $fields = $this->runStopFields($stoppedAt);
        $fields['options'] = $options;

        $record->set($fields)->update();

        return true;
    }

    /** @return bool  without this the stop timestamp advances on every cron tick */
    private function alreadyStopped($record)
    {
        $flag = self::RUN_STOPPED_FLAG;
        $clock = self::RUN_STOPPED_AT_COLUMN;

        if (! isset($record->$flag) || (int) $record->$flag <= 0) {
            return false;
        }

        return self::stoppedThisRun(
            isset($record->$clock) ? $record->$clock : '',
            isset($record->options) ? $record->options : null
        );
    }

    /**
     * Static and argument-only so a list screen can ask it about a raw row.
     *
     * @param  mixed  $stoppedAt  the row's RUN_STOPPED_AT_COLUMN
     * @param  mixed  $options    the row's unserialised options
     * @return bool
     */
    public static function stoppedThisRun($stoppedAt, $options)
    {
        $stoppedAt = (string) $stoppedAt;

        if ($stoppedAt === '' || ! is_array($options)) {
            return false;
        }

        return isset($options[self::RUN_STOPPED_MARKER])
            && (string) $options[self::RUN_STOPPED_MARKER] === $stoppedAt;
    }

    /**
     * Unreadable admits, per column: `0000-00-00 00:00:00` is the schema default
     * of both clocks, and strtotime() parses it rather than rejecting it, to two
     * millennia before the epoch.
     *
     * @param  object  $record
     * @return bool
     */
    private function advancedRecently($record)
    {
        $newest = null;

        foreach (self::RUN_ACTIVITY_COLUMNS as $clock) {
            if (! isset($record->$clock)) {
                return true;
            }

            $stampedAt = strtotime((string) $record->$clock);

            if (! is_int($stampedAt) || $stampedAt <= 0) {
                return true;
            }

            if ($newest === null || $stampedAt > $newest) {
                $newest = $stampedAt;
            }
        }

        // Null rather than zero: at zero a negative stamp is silently discarded above.
        if ($newest === null) {
            return true;
        }

        return (time() - $newest) <= self::RUN_STALE_AFTER_SECONDS;
    }

    /** Record that a run started, so nothing downstream in the same request asks again. */
    public function admit($record)
    {
        $id = isset($record->id) ? (int) $record->id : 0;

        if ($id !== 0) {
            $this->admitted[$id] = true;
        }
    }

    /** @var string[]  everything else in the namespace is refused, so a new route is gated */
    const REST_OPEN = [
        '/wp-all-import/v1/session/validate',
        '/wp-all-import/v1/step1/validate',
        '/wp-all-import/v1/addon/fields',
    ];

    /** @var string[]  what getting out of a stuck run needs, and nothing that reads history */
    const REST_OPEN_SUFFIXES = [
        '/status',
        '/cancel',
        '/processing-limits',
        '/clear-processing-lock',
    ];

    const REST_NAMESPACE = '/wp-all-import/v1';

    /**
     * @param  string  $route  the matched route path, e.g. /wp-all-import/v1/import/3/execute
     * @return bool
     */
    public function blocksRestRoute($route)
    {
        $route = self::comparableRoute($route);

        // The namespace test is FIRST: rest_pre_dispatch fires for every REST request
        // the site serves, and reading plugin options on /wp/v2/posts is a fatal where
        // PMXI_Plugin never booted.
        if (strpos($route, self::REST_NAMESPACE) !== 0) {
            return false;
        }

        if (! $this->blocks()) {
            return false;
        }

        if (in_array($route, self::REST_OPEN, true)) {
            return false;
        }

        return ! self::isRestRecoveryRoute($route);
    }

    /** @return bool  matched by suffix, so it answers for the registered pattern and the request path alike */
    public static function isRestRecoveryRoute($route)
    {
        $route = self::comparableRoute($route);

        if (strpos($route, self::REST_NAMESPACE) !== 0) {
            return false;
        }

        foreach (self::REST_OPEN_SUFFIXES as $suffix) {
            if (substr($route, -strlen($suffix)) === $suffix) {
                return true;
            }
        }

        return false;
    }

    /**
     * WordPress matches a request to a route case-insensitively, and serves
     * /WP-ALL-IMPORT/v1/... from the same handler as the lowercase path.
     *
     * @return string
     */
    private static function comparableRoute($route)
    {
        return '/' . ltrim(strtolower((string) $route), '/');
    }

    /** @return array{status:int,message:string}  a bare return reports the import complete */
    public function runRefusal()
    {
        return ['status' => 403, 'message' => $this->apiRefusal()];
    }

    /** @return array{status:int,message:string}  "run it again" is wrong once records are written */
    public function stopRefusal($record)
    {
        return [
            'status' => 403,
            'message' => $this->runAdvanced($record)
                && ($this->stopsRunInFlight($record) || $this->alreadyStopped($record))
                ? $this->executionStopped()
                : $this->apiRefusal(),
        ];
    }

    const REFUSAL_CODE = 'license_required';

    /** @return array{status:int,code:string,message:string}  the chunk loop reads any other shape as a terminated import */
    public function jsonRefusal($message = null)
    {
        return [
            'status' => 403,
            'code' => self::REFUSAL_CODE,
            'message' => $message === null ? $this->ajaxRefusal() : (string) $message,
        ];
    }

    /** @return bool  lets execute() inherit a refusal rather than evaluate the gate again */
    public static function isRefusal($result)
    {
        return is_array($result)
            && isset($result['status'])
            && (int) $result['status'] === 403
            && isset($result['message']);
    }

    /** Held here so the gate's only dependency on the licence state stays LicenceSource. */
    const STATE_VALID = 'valid';

    /** @return bool */
    public function stateNameable()
    {
        return $this->source instanceof LicenceStateSource;
    }

    /** @return string  `valid` when the source could not answer, so it never reddens a paid dashboard */
    public function state()
    {
        if (! $this->stateNameable()) {
            return self::STATE_VALID;
        }

        return (string) $this->ask('state', self::STATE_VALID);
    }

    /** @return string */
    public function stateReason()
    {
        if (! $this->stateNameable()) {
            return '';
        }

        return (string) $this->ask('stateReason', '');
    }

    /** @return int */
    public function graceUntil()
    {
        if (! $this->stateNameable()) {
            return 0;
        }

        return (int) $this->ask('graceUntil', 0);
    }

    /**
     * Keyed on the state, NOT blocks(): blocks() is false for the whole of a grace
     * period, so a notice keyed on it warns nobody before the site stops.
     *
     * @return bool
     */
    public function shouldNotice()
    {
        return $this->enforcing()
            && $this->state() !== self::STATE_VALID
            && $this->ask('recordsExist', false)
            && ! $this->awaitingFirstAnswer();
    }

    /**
     * Optional on the source, so a source that cannot say keeps every notice.
     *
     * @return bool
     */
    private function awaitingFirstAnswer()
    {
        return method_exists($this->source, 'awaitingFirstAnswer')
            && (bool) $this->ask('awaitingFirstAnswer', false);
    }

    /** @return string  chosen by the state, not by whether the gate blocks */
    public function stateMessage()
    {
        return $this->messages->forState($this->state(), $this->stateReason(), $this->graceUntil());
    }

    /**
     * The refusal a transport with a reader on the other end sends, in the state
     * this site is actually in.
     *
     * Here rather than at the call sites so no surface has to go and read the
     * state for itself, and none can answer in a different one.
     *
     * @return string
     */
    public function ajaxRefusal()
    {
        return $this->messages->ajaxRefusal($this->state(), $this->stateReason(), $this->graceUntil());
    }

    /** @return string  The same sentence for a transport with no reader: no capability advice. */
    public function apiRefusal()
    {
        return $this->messages->apiRefusal($this->state(), $this->stateReason(), $this->graceUntil());
    }

    /** @return string */
    public function executionStopped()
    {
        return $this->messages->executionStopped($this->state(), $this->stateReason(), $this->graceUntil());
    }

    /** @return string */
    public function status()
    {
        return (string) $this->ask('status', '');
    }

    /** @return array<string,mixed> */
    public function describe()
    {
        return [
            'source' => $this->ask('name', 'unavailable'),
            'source_available' => $this->ask('available', false),
            'source_determinable' => $this->sourceDeterminable(),
            'determinable' => $this->determinable(),
            'edition' => defined(self::EDITION_CONSTANT) ? constant(self::EDITION_CONSTANT) : null,
            'edition_paid' => $this->isPaidEdition(),
            'enforcing' => $this->enforcing(),
            'blocking' => $this->blocks(),
            'blocked_reason' => $this->blockedReason(),
            'state' => $this->state(),
            'state_reason' => $this->stateReason(),
            'grace_until' => $this->graceUntil(),
            'should_notice' => $this->shouldNotice(),
            'source_error' => $this->sourceErrorSummary(),
        ];
    }

    /** @return string */
    public function blockedReason()
    {
        if (! $this->determinable()) {
            return 'indeterminate';
        }

        $available = $this->ask('available', false);

        // After the call, never before: a source that broke while being asked would
        // otherwise read as absent.
        if ($this->sourceError !== null) {
            return 'source-error';
        }

        if (! $available) {
            return 'no-licence-source';
        }

        // Before the entitlement question: asking first and labelling afterwards
        // reports `unlicensed` for a licensed site.
        if (! $this->sourceDeterminable()) {
            return 'source-indeterminate';
        }

        if ($this->sourceError !== null) {
            return 'source-error';
        }

        if (! $this->isPaidEdition()) {
            return 'not-paid-edition';
        }

        $licensed = $this->ask('licensed', true);

        if ($this->sourceError !== null) {
            return 'source-error';
        }

        return $licensed ? 'licensed' : 'unlicensed';
    }
}
