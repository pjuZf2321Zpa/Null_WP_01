<?php

namespace Wpai\App\Gate;

/** Where the gate gets its answer. */
interface LicenceSource
{
    /** @return bool Whether this source is present and able to answer. */
    public function available();

    /** @return bool  false means "could not determine", never "unlicensed" */
    public function determinable();

    /** @return bool */
    public function licensed();

    /** @return string A status vocabulary term, or '' when unavailable. */
    public function status();

    /** @return bool Whether the site has records of this plugin's own type. */
    public function recordsExist();

    /** @return string A short identifier for the source, for observability. */
    public function name();
}
