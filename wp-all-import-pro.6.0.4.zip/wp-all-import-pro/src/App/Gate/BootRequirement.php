<?php

namespace Wpai\App\Gate;

final class BootRequirement
{
    /** @var string[] URI fragments that mean this request reaches PMXI_* classes. */
    const MARKERS = ['wp-all-import/v1', 'mcp/mcp-adapter-default-server'];

    /** @return bool */
    private static function doingCron()
    {
        if (defined('DOING_CRON') && DOING_CRON) {
            return true;
        }

        return function_exists('wp_doing_cron') && wp_doing_cron();
    }

    /**
     * @param  array<string,mixed>|null  $server  defaults to $_SERVER
     * @param  array<string,mixed>|null  $query  defaults to $_GET
     * @param  bool|null  $doingCron  defaults to the real cron detection
     * @return bool
     */
    public static function required($server = null, $query = null, $doingCron = null)
    {
        if ($doingCron === null ? self::doingCron() : (bool) $doingCron) {
            return true;
        }

        $server = is_array($server) ? $server : $_SERVER;
        $query = is_array($query) ? $query : $_GET;

        // rest_route as well as REQUEST_URI: with plain permalinks the route is in
        // the query string and the path is /index.php.
        $haystacks = [
            isset($server['REQUEST_URI']) ? (string) $server['REQUEST_URI'] : '',
            isset($query['rest_route']) ? (string) $query['rest_route'] : '',
        ];

        foreach ($haystacks as $haystack) {
            if ($haystack === '') {
                continue;
            }

            // WordPress matches REST routes case-insensitively, and REQUEST_URI
            // arrives still percent-encoded.
            $haystack = strtolower(rawurldecode($haystack));

            foreach (self::MARKERS as $marker) {
                if (strpos($haystack, $marker) !== false) {
                    return true;
                }
            }
        }

        return false;
    }
}
