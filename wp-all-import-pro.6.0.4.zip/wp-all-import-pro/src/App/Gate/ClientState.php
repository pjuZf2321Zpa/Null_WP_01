<?php

namespace Wpai\App\Gate;

// Not left to the autoloader: the shared parity contract loads this directory
// from a named list and registers none, so the interface must be required here.
require_once __DIR__ . '/LicenceStateSource.php';

/** Never reads the licence option keys itself: it asks their owner, so there is one answer. */
final class ClientState implements LicenceStateSource
{
    const OWNER = '\\Wpai\\App\\License\\Licensing';

    /** @return bool */
    public function available()
    {
        return class_exists(self::OWNER);
    }

    /** @return object|null */
    private function owner()
    {
        if (! $this->available()) {
            return null;
        }

        return call_user_func([self::OWNER, 'instance']);
    }

    /** @return bool  a failed option read is indistinguishable from a genuine refusal */
    public function determinable()
    {
        $owner = $this->owner();

        return $owner === null ? false : (bool) $owner->determinable();
    }

    /** @return bool  an unavailable source answers `true`: it must never be what refuses somebody */
    public function licensed()
    {
        $owner = $this->owner();

        return $owner === null ? true : (bool) $owner->isLicensed();
    }

    /** @return string */
    public function state()
    {
        $owner = $this->owner();

        return $owner === null ? '' : (string) $owner->licenseState()['state'];
    }

    /** @return string */
    public function stateReason()
    {
        $owner = $this->owner();

        return $owner === null ? '' : (string) $owner->licenseState()['reason'];
    }

    /** @return int */
    public function graceUntil()
    {
        $owner = $this->owner();

        return $owner === null ? 0 : (int) $owner->licenseDeadline();
    }

    /** @return string */
    public function status()
    {
        $owner = $this->owner();

        return $owner === null ? '' : (string) $owner->status();
    }

    /** @return bool */
    public function recordsExist()
    {
        $owner = $this->owner();

        return $owner === null ? false : (bool) $owner->recordsExist();
    }

    /** @return bool */
    public function awaitingFirstAnswer()
    {
        $owner = $this->owner();

        return $owner === null ? false : (bool) $owner->awaitingFirstAnswer();
    }

    /** @return string */
    public function name()
    {
        return 'client-licence-state';
    }
}
