<?php

namespace Wpai\App\Gate;

/** Nothing here calls remove_action: free and Pro register the same hook and callback names. */
final class Surfaces
{
    /** Open while blocked: notices must stay dismissable, and the licence responder is the way out. */
    const ALLOW = [
        'wp_ajax_dismiss_notifications',
        'wp_ajax_soflyy_updater_dismiss_refusal',
        'wp_ajax_wpai_dismiss_ad',
        'wp_ajax_wpai_dismiss_review_modal',
        'wp_ajax_wpai_send_feedback',
        'wp_ajax_wpai_settings_check_license',
    ];

    /** import_failed is the only thing that lowers `executing` on a run that died. */
    const RUN_COMPLETION_OPEN = [
        'wp_ajax_import_failed',
    ];

    /** Ajax hooks registered outside actions/, so the glob does not see them. */
    const EXTRA_HOOKS = [
        'wp_ajax_wpai_register_preview_session',
        'wp_ajax_wpai_manual_preview_cleanup',
        'wp_ajax_wpai_dismiss_ad',
        'wp_ajax_wpai_save_llm_template',
        'wp_ajax_wpai_get_import_options',
        'wp_ajax_wpai_update_session_options',
        'wp_ajax_wpai_record_ai_consent',
        'wp_ajax_wpai_reset_template_to_defaults',
    ];

    /** The umbrella dispatcher, gated per route rather than per hook. */
    const UMBRELLA = 'wp_ajax_wp_all_import_api';

    /** @var Gate */
    private $gate;

    /** @var string */
    private $actionsDir;

    public function __construct(?Gate $gate = null, $actionsDir = null)
    {
        $this->gate = $gate ?: Gate::instance();
        $this->actionsDir = $actionsDir !== null
            ? $actionsDir
            : (defined('WP_ALL_IMPORT_ROOT_DIR') ? WP_ALL_IMPORT_ROOT_DIR . '/actions' : '');
    }

    /** @return string[] */
    public function gatedAjaxHooks()
    {
        $hooks = [];

        if ($this->actionsDir !== '' && is_dir($this->actionsDir)) {
            foreach ((array) glob($this->actionsDir . '/wp_ajax_*.php') as $path) {
                $hooks[] = basename($path, '.php');
            }
        }

        $hooks = array_merge($hooks, self::EXTRA_HOOKS);
        $hooks = array_unique($hooks);

        $open = array_merge(self::ALLOW, self::RUN_COMPLETION_OPEN, [self::UMBRELLA]);

        $gated = array_values(array_diff($hooks, $open));
        sort($gated);

        return $gated;
    }

    /** @return void */
    public function register()
    {
        foreach ($this->gatedAjaxHooks() as $hook) {
            add_action($hook, [$this, 'refuseAjax'], 1);
        }

        add_action(self::UMBRELLA, [$this, 'refuseApiRoute'], 1);

        add_action('all_admin_notices', [$this, 'renderNotice']);
        add_filter('rest_pre_dispatch', [$this, 'refuseRest'], 10, 3);
        add_filter('rest_endpoints', [$this, 'openRecoveryRoutes']);
        add_filter('debug_information', [$this, 'siteHealth']);
    }

    /** @param  callable  $body  Nothing it raises may escape: all_admin_notices fires on every admin page, so a Throwable is a white screen. */
    private function guarded($body, $passthrough = null)
    {
        try {
            return call_user_func($body);
        } catch (\Throwable $e) {
            return $passthrough;
        }
    }

    /** @return void  Bound at priority 1, in front of the priority-10 handlers in actions/. */
    public function refuseAjax()
    {
        $this->guarded(function () {
            if (! $this->gate->blocks()) {
                return;
            }

            $this->sendAjaxRefusal();
        });
    }

    /** @return void */
    public function refuseApiRoute()
    {
        $this->guarded(function () {
            $route = isset($_GET['q']) ? (string) wp_unslash($_GET['q']) : '';

            if (! $this->gate->blocksApiRoute($route)) {
                return;
            }

            $this->sendAjaxRefusal();
        });
    }

    /** @return void  403 not the 401 used elsewhere: authenticated but unauthorised. */
    private function sendAjaxRefusal()
    {
        $message = $this->gate->ajaxRefusal();

        if (function_exists('pmxi_send_json')) {
            pmxi_send_json(['status' => 403, 'message' => $message, 'html' => $message], 403);

            return;
        }

        wp_send_json(['status' => 403, 'message' => $message, 'html' => $message], 403);
    }

    /** @return mixed  Not a substitute for gating the run: MCP invokes handlers directly, so this never fires for it. */
    public function refuseRest($result, $server, $request)
    {
        // Passthrough is $result: a gate that cannot answer must not 500 the REST API.
        return $this->guarded(function () use ($result, $request) {
            if ($result !== null) {
                return $result;
            }

            if (! is_object($request) || ! method_exists($request, 'get_route')) {
                return $result;
            }

            if (! $this->gate->blocksRestRoute($request->get_route())) {
                return $result;
            }

            return new \WP_Error(
                'wpai_license_required',
                $this->gate->apiRefusal(),
                ['status' => 403, 'code' => 'license_required']
            );
        }, $result);
    }

    /** @return mixed  The recovery routes need a session token, and the routes that mint one are gated. */
    public function openRecoveryRoutes($endpoints)
    {
        // Passthrough is the map unchanged: a broken gate must not deregister the REST API.
        return $this->guarded(function () use ($endpoints) {
            if (! is_array($endpoints)) {
                return $endpoints;
            }

            foreach ($endpoints as $route => $handlers) {
                if (! is_array($handlers) || ! Gate::isRestRecoveryRoute($route)) {
                    continue;
                }

                foreach ($handlers as $index => $handler) {
                    if (! is_array($handler) || ! isset($handler['permission_callback'])) {
                        continue;
                    }

                    $endpoints[$route][$index]['permission_callback']
                        = $this->orCapableUser($handler['permission_callback']);
                }
            }

            return $endpoints;
        }, $endpoints);
    }

    /** @return \Closure  The original's refusal is returned unchanged: it is a WP_Error a client branches on. */
    private function orCapableUser($original)
    {
        return function ($request = null) use ($original) {
            $answer = is_callable($original)
                ? call_user_func($original, $request)
                : $original;

            if ($answer === true) {
                return true;
            }

            return $this->capableUser() ? true : $answer;
        };
    }

    /** @return bool */
    private function capableUser()
    {
        if (! class_exists('PMXI_Plugin') || ! isset(\PMXI_Plugin::$capabilities)) {
            return false;
        }

        return (bool) current_user_can(\PMXI_Plugin::$capabilities);
    }

    /** @return void  Only where the plugin has records: a site with no imports has had nothing taken away. */
    public function renderNotice()
    {
        $this->guarded(function () {
            if (is_network_admin() || $this->onSettingsScreen() || ! $this->gate->shouldNotice()) {
                return;
            }

            echo '<div class="notice notice-error wpai-license-gate-notice"><p>'
                . wp_kses_post($this->gate->stateMessage())
                . '</p></div>';
        });
    }

    /** @return bool  The Settings screen states the position itself; a notice there would repeat it. */
    private function onSettingsScreen()
    {
        return isset($_GET['page']) && (string) $_GET['page'] === Gate::SETTINGS_PAGE;
    }

    /**
     * @param  array<string,mixed>  $info
     * @return array<string,mixed>
     */
    public function siteHealth($info)
    {
        // Passthrough is $info: Site Health must survive a broken gate.
        return $this->guarded(function () use ($info) {
            return $this->siteHealthFields($info);
        }, $info);
    }

    /**
     * @param  array<string,mixed>  $info
     * @return array<string,mixed>
     */
    private function siteHealthFields($info)
    {
        if (! is_array($info)) {
            return $info;
        }

        $described = $this->gate->describe();

        $info['wp-all-import-license-gate'] = [
            'label' => __('WP All Import: license gate', 'wp-all-import-pro'),
            'fields' => [
                'enforcing' => [
                    'label' => 'Enforcing',
                    'value' => $described['enforcing'] ? 'yes' : 'no',
                ],
                'reason' => [
                    'label' => 'Reason',
                    'value' => $described['blocked_reason'],
                ],
                'licence_source' => [
                    'label' => 'Licence source',
                    'value' => $described['source'] . ($described['source_available'] ? ' (available)' : ' (absent)'),
                ],
                'edition' => [
                    'label' => 'Edition',
                    'value' => (string) $described['edition'],
                ],
                'source_determinable' => [
                    'label' => 'Licence state determinable',
                    'value' => $described['source_determinable'] ? 'yes' : 'no',
                ],
                'source_error' => [
                    'label' => 'Licence source error',
                    'value' => $described['source_error'] === '' ? 'none' : $described['source_error'],
                ],
            ],
        ];

        return $info;
    }
}
