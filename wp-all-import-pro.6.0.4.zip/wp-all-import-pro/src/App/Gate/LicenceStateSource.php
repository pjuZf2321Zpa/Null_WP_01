<?php

namespace Wpai\App\Gate;

/**
 * LicenceSource::licensed() is true for the whole of a grace period, so nothing
 * keyed on it can warn that a window is running out. Declared separately
 * because widening LicenceSource is fatal at declaration for implementations
 * outside this repository.
 */
interface LicenceStateSource extends LicenceSource
{
    /** @return string  a state vocabulary name, or '' when the source could not answer */
    public function state();

    /** @return string  unverified, invalid, expired or limit; '' when not a grace state */
    public function stateReason();

    /** @return int  check it is in the future before printing: 0 means there is none */
    public function graceUntil();
}
