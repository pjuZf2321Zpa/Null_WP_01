<?php

namespace Wpai\App\License;

/**
 * The production implementation must go through PMXI_Plugin::getOption() /
 * updateOption(), never get_option(): only those apply the
 * wp_all_import_config_options filter, through which hosting setups inject a
 * licence key that is never written to the row.
 */
interface OptionsGateway
{
    /** @param  mixed  $default  Returned for an undeclared key and an unreadable store alike; readable() tells them apart. */
    public function get($key, $default = null);

    /** @return array<string,mixed>  [] when the store could not be read. */
    public function all();

    /** @return bool  "no licence" and "no information about the licence" are different states */
    public function readable();

    /** @param  array<string,mixed>  $values */
    public function update(array $values);
}
