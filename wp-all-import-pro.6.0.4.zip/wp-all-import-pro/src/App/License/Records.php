<?php

namespace Wpai\App\License;

/** Whether this site has imports of its own. Resolved at most once per request. */
final class Records
{
    /** @var callable */
    private $probe;

    /** @var bool|null */
    private $result;

    /** @param  callable|null  $probe  fn(): bool */
    public function __construct($probe = null)
    {
        $this->probe = is_callable($probe) ? $probe : [self::class, 'queryImports'];
    }

    /** @return bool */
    public function exist()
    {
        if ($this->result === null) {
            $this->result = (bool) call_user_func($this->probe);
        }

        return $this->result;
    }

    /** @return void */
    public function forget()
    {
        $this->result = null;
    }

    /**
     * The table name must be built from $wpdb->prefix and a literal, never a
     * variable: prepare() cannot parameterise an identifier.
     */
    public static function queryImports()
    {
        global $wpdb;

        if (! isset($wpdb) || ! is_object($wpdb)) {
            return false;
        }

        $table = $wpdb->prefix . 'pmxi_imports';

        // A fresh install has no imports table, and wpdb prints a missing-table error
        // into whatever page is rendering. Here the name is a LIKE value, so prepare()
        // applies.
        $suppressed = $wpdb->suppress_errors(true);

        $exists = $wpdb->get_var(
            $wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($table))
        ) === $table;

        $found = $exists
            ? (bool) $wpdb->get_var('SELECT id FROM ' . $wpdb->prefix . 'pmxi_imports LIMIT 1')
            : false;

        $wpdb->suppress_errors($suppressed);

        return $found;
    }
}
