<?php

namespace Wpai\App\License;

/** A GET with the key in the query string: the routes are Route::get and POST answers 405. */
final class LicenseCheck
{
    /** @var LicenseState */
    private $state;

    /** @var ResponseAdapter */
    private $adapter;

    /** @var callable */
    private $transport;

    /** @param  callable  $transport  fn(string $url): array{error:bool,code:int,body:string} */
    public function __construct(LicenseState $state, ResponseAdapter $adapter, $transport)
    {
        $this->state = $state;
        $this->adapter = $adapter;
        $this->transport = $transport;
    }

    /**
     * @param  string  $itemName  Must match package.name exactly; a miss answers
     *                             "Package doesn't exist."
     * @return LicenseStatus|null  null when the answer was non-definitive
     */
    public function run($apiUrl, $key, $itemName, $siteUrl, $pluginVersion = '')
    {
        // Trimmed once, so the key on the wire is the key that was fingerprinted.
        $key = LicenseState::normaliseKey($key);

        $this->state->syncKey($key);
        $this->state->recordAttempt();

        if ($key === '') {
            return null;
        }

        $url = rtrim((string) $apiUrl, '/') . '/check_license?' . http_build_query([
            // Read by nothing here; sent because every shipped client sends it.
            'edd_action' => 'check_license',
            'license' => $key,
            'item_name' => (string) $itemName,
            'url' => (string) $siteUrl,
            'version' => (string) $pluginVersion,
        ]);

        $response = call_user_func($this->transport, $url);

        if (! is_array($response)) {
            $response = ['error' => true, 'code' => 0, 'body' => ''];
        }

        $status = $this->adapter->adapt($response, $this->state->now());

        if ($status === null) {
            $this->state->recordNonDefinitive();

            return null;
        }

        $this->state->recordDefinitive($status);

        return $status;
    }
}
