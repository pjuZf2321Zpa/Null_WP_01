<?php

namespace Wpai\App\UnsecuredController;


use Wpai\Http\Request;
use Wpai\Scheduling\Import;
use Wpai\Http\JsonResponse;

class SchedulingController
{
    /** Scheduling API Version */
    const VERSION = 1;

    /** @var Import */
    private $scheduledImportService;

    /** @var callable */
    private $logger;

    public function __construct($container)
    {
        $this->scheduledImportService = new Import();
        $this->logger = function($m) {
            print("<div class='progress-msg'>[". wp_all_import_local_date("H:i:s") ."] $m</div>\n");
        };
    }

    /**
     * With a record, blocksRun(), so a run already under way finishes rather than being
     * abandoned with half its records written; without one, blocks(). A scheduling
     * entitlement never substitutes for the core licence.
     *
     * @param  \PMXI_Import_Record|null  $import
     * @return JsonResponse|null
     */
    private function licenceRefusal($import = null)
    {
        $gate = \Wpai\App\Gate\Gate::instance();

        if (! ($import === null ? $gate->blocks() : $gate->blocksRun($import))) {
            return null;
        }

        if ($import !== null) {
            $gate->stopRun($import);
        }

        return new JsonResponse(array(
            'message' => $import === null
                ? $gate->apiRefusal()
                : $gate->stopRefusal($import)['message'],
            'code' => 'license_required',
        ), 403);
    }

    public function triggerAction(Request $request)
    {
        if (!$this->isRequestValid()) {
            return new JsonResponse(array('message' => 'Import hash is invalid'), 401);
        }

        if (($refusal = $this->licenceRefusal()) !== null) {
            return $refusal;
        }

        $importId = intval($request->get('import_id'));

        // Authenticated scheduled request: let the addon-installer SDK self-heal a missing companion.
        do_action('pmxi_scheduled_request_authenticated', $importId);

        $import = new \PMXI_Import_Record();
        $import->getById($importId);

        if ($import->isEmpty()) {
            return new JsonResponse(array('message' => 'Import not found'), 404);
        }

        if ((int)$import->executing) {
            return new JsonResponse(array("message" => "Import #" . $import->id . " is currently in manually process. Request skipped."), 409);
        }
        if ($import->processing and !$import->triggered) {
            return new JsonResponse(array("message" => "Import #" . $import->id . " currently in process. Request skipped."), 409);

        }
        if (!$import->processing and $import->triggered) {
            return new JsonResponse(array("message" => "Import #" . $import->id . " already triggered. Request skipped."), 409);
        }

        if (!$import->processing and !$import->triggered) {
            $this->scheduledImportService->trigger($import);

            return new JsonResponse(array('message' => "#" . $import->id . " Cron job triggered."));
        }

        return new JsonResponse(array("message" => "Can't process"), 500);
    }

    public function processAction(Request $request)
    {
        if (!$this->isRequestValid()) {
            return new JsonResponse(array('message' => 'Import hash is invalid'), 401);
        }

        $importId = intval($request->get('import_id'));

        // Authenticated scheduled request: let the addon-installer SDK self-heal a missing companion.
        do_action('pmxi_scheduled_request_authenticated', $importId);

        $import = new \PMXI_Import_Record();
        $import->getById($importId);

        if ($import->isEmpty()) {
            return new JsonResponse(array('message' => 'Import not found'), 404);
        }

        if (($refusal = $this->licenceRefusal($import)) !== null) {
            return $refusal;
        }

        if ($import->processing == 1 and (time() - strtotime($import->registered_on)) > 120) {
            // it means processor crashed, so it will reset processing to false, and terminate. Then next run it will work normally.
            $import->set(array(
                'processing' => 0
            ))->update();
        }

        // start execution imports that is in the cron process
        if (!(int)$import->triggered) {
            if (!empty($import->parent_id) or empty($queue_exports)) {
                return new JsonResponse(array("message" => 'Import #' . $importId . ' is not triggered. Request skipped.'), 400);
            }
        } elseif ((int)$import->executing) {
            return new JsonResponse(array('message' => 'Import #' . $importId . ' is currently in manually process. Request skipped.'), 409);
        } elseif ((int)$import->triggered and !(int)$import->processing) {

            $response = $this->scheduledImportService->process($import, $this->logger);

            if ( ! empty($response) and is_array($response)){
                if($response == array(
                    'status'     => 200,
                    'message'    => sprintf(__('Import #%s complete', 'wp-all-import-pro'),$importId)
                )) {
                    return new JsonResponse(array('Import #' . $importId . ' complete'), 201);
                } else {
                    wp_send_json($response);
                }
            }
            elseif ( ! (int) $import->queue_chunk_number ){
                return new JsonResponse(array('Import #' . $importId . ' complete'), 201);
            }
            else{
                return new JsonResponse(array('message' => 'Records Processed ' . (int)$import->imported . '.'));

            }

        } else {
            return new JsonResponse(array('message' => 'Import #' . $importId . ' already processing. Request skipped.'), 409);
        }

        return new JsonResponse(array("message" => "Can't process"), 500);
    }

    public function versionAction()
    {
        return new JsonResponse(array('version' => self::VERSION));
    }

    /**
     * @return bool
     */
    private function isRequestValid()
    {
        $cron_job_key = \PMXI_Plugin::getInstance()->getOption('cron_job_key');

        return
            !empty($cron_job_key) and
            !empty($_GET['import_id']) and
            !empty($_GET['import_key']) and
            hash_equals( $cron_job_key, sanitize_text_field( wp_unslash( $_GET['import_key'] ) ) );
    }

}