<?php
// Last word on the section list, after every add-on filter: the Custom Fields section is
// core's, so whether a user import gets it is decided here rather than by the add-on.
function pmxi_pmxi_visible_template_sections_9999( $sections, $post_type ) {

	if ( is_array($sections) && wp_all_import_user_meta_requires_addon_pro($post_type) ) {
		return array_values(array_diff($sections, array('cf')));
	}

	return $sections;
}
