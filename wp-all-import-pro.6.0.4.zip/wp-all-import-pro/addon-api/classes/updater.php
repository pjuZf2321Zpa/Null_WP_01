<?php

namespace Wpai\AddonAPI;

/**
 * Add-ons carry no licence key of their own — the base class decides that from the
 * absence of a 'license' key in the constructor data, so callers must not pass one.
 */
class PMXI_Addon_Updater extends \Wpai\Vendor\Soflyy\Updater\Updater {

	protected function textDomain() {
		return 'wp_all_import_pro';
	}

	protected function productName() {
		return isset( $this->apiData['item_name'] ) ? (string) $this->apiData['item_name'] : '';
	}

	protected function settingsUrl() {
		return admin_url( 'admin.php?page=pmxi-admin-settings' );
	}

	/**
	 * Add-ons live in a directory named for the add-on, and their main file is
	 * plugin.php, so the file's basename is useless as a slug.
	 */
	protected function deriveSlug() {
		return strtok( plugin_basename( $this->pluginFile ), '/' );
	}

	protected function updateTransientPriority() {
		return 21;
	}

	/*
	 * rendersUpdateRow() is deliberately not overridden: the base returns false for an
	 * unlicensed product on a single site, which is what routes a PHP refusal into
	 * WordPress's own update row instead of the one below.
	 */

	protected function changelogMetaTitle() {
		return esc_html__( 'View Changelog', 'wp_all_import_pro' );
	}

	protected function changelogUrl() {
		return self_admin_url(
			'index.php?edd_sl_action=view_plugin_changelog&plugin=' . $this->name
			. '&slug=' . $this->slug . '&TB_iframe=true&width=772&height=911'
		);
	}

	/**
	 * @param object $version_info
	 *
	 * @return string
	 */
	protected function updateWithoutPackageMessage( $version_info ) {
		return sprintf(
			/* translators: 1: add-on name, 2: changelog URL, 3: new version. */
			__( 'There is a new version of %1$s available. <a target="_blank" class="thickbox" href="%2$s">View version %3$s details</a>.', 'edd' ),
			esc_html( $version_info->name ),
			esc_url( $this->changelogUrl() ),
			esc_html( $version_info->new_version )
		);
	}

	/**
	 * @param object $version_info
	 *
	 * @return string
	 */
	protected function updateAvailableMessage( $version_info ) {
		return sprintf(
			/* translators: 1: add-on name, 2: changelog URL, 3: new version, 4: update URL. */
			__( 'There is a new version of %1$s available. <a target="_blank" class="thickbox" href="%2$s">View version %3$s details</a> or <a href="%4$s">update now</a>.', 'edd' ),
			esc_html( $version_info->name ),
			esc_url( $this->changelogUrl() ),
			esc_html( $version_info->new_version ),
			esc_url( wp_nonce_url( self_admin_url( 'update.php?action=upgrade-plugin&plugin=' ) . $this->name, 'upgrade-plugin_' . $this->name ) )
		);
	}

	/**
	 * @param array $plugin
	 * @param object $version_info
	 * @param string $message
	 *
	 * @return void
	 */
	protected function renderUpdateRow( $plugin, $version_info, $message ) {

		if ( empty( $message ) ) {
			return;
		}

		$wp_list_table = _get_list_table( 'WP_Plugins_List_Table' );

		echo '<tr class="plugin-update-tr"><td colspan="' . $wp_list_table->get_column_count() . '" class="plugin-update colspanchange"><div class="update-message">';
		echo $message;
		echo '</div></td></tr>';
	}
}
