<?php

declare(strict_types=1);

namespace Wpai\Vendor\ZipStream\Exception;

use Wpai\Vendor\ZipStream\Exception;

/**
 * This Exception gets invoked if file or comment encoding is incorrect
 */
class EncodingException extends Exception
{
}
