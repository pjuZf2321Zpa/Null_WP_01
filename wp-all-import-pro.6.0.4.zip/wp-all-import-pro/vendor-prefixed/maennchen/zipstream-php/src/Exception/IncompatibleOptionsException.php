<?php

declare(strict_types=1);

namespace Wpai\Vendor\ZipStream\Exception;

use Wpai\Vendor\ZipStream\Exception;

/**
 * This Exception gets invoked if options are incompatible
 */
class IncompatibleOptionsException extends Exception
{
}
