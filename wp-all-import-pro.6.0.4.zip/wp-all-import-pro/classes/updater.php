<?php

if ( ! class_exists( 'PMXI_Updater' ) ) {

	class PMXI_Updater extends \Wpai\Vendor\Soflyy\Updater\Updater {

		protected function textDomain() {
			return 'wp-all-import-pro';
		}

		protected function productName() {
			return 'WP All Import Pro';
		}

		protected function settingsUrl() {
			return admin_url( 'admin.php?page=pmxi-admin-settings' );
		}

		protected function pluginRowPriority() {
			return 11;
		}

		protected function hidesAutoUpdateSetting() {
			return true;
		}

		protected function changelogMetaTitle() {
			return __( 'View WP All Import Pro Changelog', 'wp-all-import-pro' );
		}

		/**
		 * @param object $version_info
		 *
		 * @return string
		 */
		protected function phpRefusalMessage( $version, $requires ) {
			return '<span class="wp-all-import-pro-new-version-notice">' . parent::phpRefusalMessage( $version, $requires ) . '</span>';
		}

		protected function wordPressRefusalMessage( $version, $requires ) {
			return '<span class="wp-all-import-pro-new-version-notice">' . parent::wordPressRefusalMessage( $version, $requires ) . '</span>';
		}

		protected function bothRefusalMessage( $version, $requires_php, $requires_wp ) {
			return '<span class="wp-all-import-pro-new-version-notice">' . parent::bothRefusalMessage( $version, $requires_php, $requires_wp ) . '</span>';
		}

		protected function phpRequirementMessage( $version_info ) {
			return '<span class="wp-all-import-pro-new-version-notice">' . sprintf(
				/* translators: 1: new version, 2: required PHP version, 3: current PHP version. */
				__( 'WP All Import Pro %1$s requires PHP %2$s or greater, you are using PHP %3$s. Please contact your host and tell them to update your server to at least PHP %2$s.', 'wp-all-import-pro' ),
				esc_html( $version_info->new_version ),
				esc_html( $version_info->php_version ),
				esc_html( $this->phpVersion )
			) . '</span>';
		}

		/**
		 * @return string
		 */
		protected function licenseRequiredMessage() {
			$message = '<span class="wp-all-import-pro-new-version-notice">' . sprintf(
				/* translators: %s: licences page URL. */
				__( 'A new version of WP All Import Pro is available. <strong>A valid license is required to use WP All Import Pro and to receive updates.</strong> Enter or check your license key on the <a href="%1$s">Settings</a> page.', 'wp-all-import-pro' ),
				esc_url( $this->settingsUrl() )
			) . '</span>';

			$message .= '<span class="wp-all-import-pro-licence-error-notice">' . sprintf(
				/* translators: 1: pricing page URL, 2: customer portal URL. */
				__( 'If you don\'t have a license, please see <a href="%1$s" target="_blank">details & pricing</a>. If you do have a license, you can access it at the <a href="%2$s" target="_blank">customer portal</a>.', 'wp-all-import-pro' ),
				esc_url( $this->pricingUrl() ),
				esc_url( $this->portalUrl() )
			) . '</span>';

			return $message;
		}

		/**
		 * @param object $version_info
		 *
		 * @return string
		 */
		protected function updateAvailableMessage( $version_info ) {
			return '<span class="wp-all-import-pro-new-version-notice">' . sprintf(
				/* translators: 1: changelog URL, 2: new version, 3: update URL. */
				__( 'There is a new version of WP All Import Pro available. <a target="_blank" class="thickbox" href="%1$s">View version %2$s details</a> or <a href="%3$s" class="update-link">update now</a>.', 'wp-all-import-pro' ),
				esc_url( $this->changelogUrl() ),
				esc_html( $version_info->new_version ),
				esc_url( wp_nonce_url( self_admin_url( 'update.php?action=upgrade-plugin&plugin=' ) . $this->name, 'upgrade-plugin_' . $this->name ) )
			) . '</span>';
		}

		/**
		 * @param array $plugin
		 * @param object $version_info
		 * @param string $message
		 *
		 * @return void
		 */
		protected function renderUpdateRow( $plugin, $version_info, $message ) {

			if ( empty( $message ) ) {
				return;
			}

			$plugin_title  = isset( $plugin['Name'] ) ? $plugin['Name'] : $this->productName();
			$plugin_slug   = sanitize_title( $plugin_title );
			$active        = is_plugin_active( $this->name ) ? 'active' : '';
			$shiny_updates = version_compare( get_bloginfo( 'version' ), '4.6-beta1-37926', '>=' );

			$update_msg_classes = $shiny_updates ? 'notice inline notice-warning notice-alt' : 'pre-shiny-updates';

			if ( $shiny_updates && ! $this->hasPackage( $version_info ) ) {
				$update_msg_classes .= ' post-shiny-updates';
			}

			$screen  = get_current_screen();
			$columns = get_column_headers( $screen );

			// If something went wrong with retrieving the columns, default to 3 for colspan.
			$colspan = ! is_countable( $columns ) ? 3 : count( $columns );

			// The 'in_plugin_update_message-' hook actions are performed to match default updater behavior and to allow
			// custom messages to be shown as provided by the update service.
			?>
			<tr class="plugin-update-tr <?php echo $active; ?> wp-all-import-pro-custom">
				<td colspan="<?php echo $colspan;?>" class="plugin-update colspanchange">
					<div class="update-message <?php echo $update_msg_classes; ?>">
						<p>
							<?php echo $message; ?>
							<?php do_action('in_plugin_update_message-'.$this->name, [], $version_info);?>
						</p>
					</div>
				</td>
			</tr>
			<script type="text/javascript">
				(function( $ ) {
					var wp_all_import_row = jQuery( '[data-slug=<?php echo $plugin_slug; ?>]:first' );

					// Fallback for earlier versions of WordPress.
					if ( ! wp_all_import_row.length ) {
						wp_all_import_row = jQuery( '#<?php echo $plugin_slug; ?>' );
					}

					var next_row = wp_all_import_row.next();

					// If there's a plugin update row - need to keep the original update row available so we can switch it out
					// if the user has a successful response from the 'check my license again' link
					if ( next_row.hasClass( 'plugin-update-tr' ) && !next_row.hasClass( 'wp-all-import-pro-custom' ) ) {
						var original = next_row.clone();
						original.add;
						next_row.html( next_row.next().html() ).addClass( 'wp-all-import-pro-custom-visible' );
						next_row.next().remove();
						next_row.after( original );
						original.addClass( 'wp-all-import-original-update-row' );
					}
				})( jQuery );
			</script>
			<?php
		}
	}

}
