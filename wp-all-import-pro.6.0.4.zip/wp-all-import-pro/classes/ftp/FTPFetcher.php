<?php
/**
 * PMXI_FTPFetcher Class.
 *
 * @version 1.0.0
 */

defined('ABSPATH') || exit;

require_once(WP_ALL_IMPORT_ROOT_DIR . '/classes/filesystem/RemoteFilesystem.php');

/**
 * Class PMXI_FTPFetcher
 */
class PMXI_FTPFetcher {

    /**
     * Fetch files from FTP server using retry logic.
     *
     * @param $options
     * @throws Exception
     */
    public static function fetch($options) {

    	$ftp = new RemoteFilesystem($options);

    	$files = $ftp->copy();

        // Browsed paths are relative to the root, but the cURL fallback reads from the login
        // directory, which is not the root on a server that does not chroot its users.
        if (empty($files) && self::isRetryableAsRootPath($options, $ftp)) {
            $options['ftp_path'] = '/' . $options['ftp_path'];
            $ftp = new RemoteFilesystem($options);
            $files = $ftp->copy();
        }

        if (empty($files)) {
            throw new Exception(__('Uploaded file is empty', 'wp-all-import-pro'));
        }
        return $files;
    }

    private static function isRetryableAsRootPath($options, RemoteFilesystem $ftp) {
        $path = isset($options['ftp_path']) ? (string) $options['ftp_path'] : '';

        return $path !== ''
            && $path[0] !== '/'
            && strpos($path, '{') === false
            && in_array($ftp->get_protocol(), ['ftp', 'ftps'], true)
            && in_array($ftp->get_root(), ['/', ''], true);
    }

}