<?php

class PMXI_Handler extends PMXI_Session {

	/** cookie name */
	private $_cookie;

	/** session due to expire timestamp */
	private $_session_expiring;

	/** session expiration timestamp */
	private $_session_expiration;

	/** Bool based on whether a cookie exists **/
	private $_has_cookie = false;

	/** When false, save_data() writes nothing. See suspend_persistence(). */
	private $_persist = true;

	/**
	 * Constructor for the session class.
	 *
	 * @access public
	 * @return void
	 */
	public function __construct() {
		
		$this->set_session_expiration();

		$this->_import_id = $this->generate_import_id();		

		$this->_data = $this->get_session_data();		

    	//add_action( 'shutdown', array( $this, 'save_data' ), 20 );

    }      

    /**
     * Return true if the current user has an active session, i.e. a cookie to retrieve values
     * @return boolean
     */
    public function has_session() {
    	return ( $this->_cookie !== null && isset( $_COOKIE[ $this->_cookie ] ) ) || $this->_has_cookie || is_user_logged_in();
    }

    /**
     * set_session_expiration function.
     *
     * @access public
     * @return void
     */
    public function set_session_expiration() {
	    $this->_session_expiring    = time() + intval( apply_filters( 'wpallimport_session_expiring', 60 * 60 * 47 ) ); // 47 Hours
		$this->_session_expiration  = time() + intval( apply_filters( 'wpallimport_session_expiration', 60 * 60 * 48 ) ); // 48 Hours
    }
	
	/**
	 * Whether a value can stand in for an import id.
	 *
	 * PMXI_Input::applyFilters() recurses into arrays and returns them as
	 * arrays, so whatever the request sent reaches an id intact — WooCommerce's
	 * order list submits id[] when HPOS is on — and every caller below builds
	 * an option name by concatenation.
	 *
	 * Public because actions/admin_head.php emits the id into a script tag and
	 * has to apply the same rule: whatever it emits is sent back as the id of
	 * the next request, so a second definition of "usable" here would let the
	 * page and its AJAX calls name different sessions.
	 *
	 * @param mixed $import_id
	 *
	 * @return bool
	 */
	public static function is_usable_import_id( $import_id ) {

		return 'new' === $import_id
			|| ( is_scalar( $import_id ) && ctype_digit( (string) $import_id ) );

	}

	public function generate_import_id() {

		$input = new PMXI_Input();
		$import_id = $input->get('id', 'new');

		if ( ! self::is_usable_import_id( $import_id ) ) {
			$import_id = 'new';
		}

		return $import_id;

	}

	/**
	 * get_session_data function.
	 *
	 * @access public
	 * @return array
	 */
	public function get_session_data()
	{
		$session = get_option('_wpallimport_session_' . $this->_import_id . '_', []);
		$delete_option = false;

		if( false === $session ){
			$delete_option = true;
		}

		if( !empty($session) && !is_array($session) ) {
			$session_clear = \maybe_unserialize( base64_decode( $session ) );
			if($session === $session_clear){
				$delete_option = true;
			}else{
				$session = $session_clear;
			}
		}

		if($delete_option){
			delete_option('_wpallimport_session_' . $this->_import_id . '_');
			delete_option('_wpallimport_session_expires_' . $this->_import_id . '_');
			$session = [];
		}

		return $session;
	}

    /**
     * save_data function.
     *
     * @access public
     * @return void
     */
    public function save_data() {
    	// Dirty if something changed - prevents saving nothing new
    	if ( $this->_persist && $this->_dirty && $this->has_session() ) {
			$this->write_session_data( $this->_data );
	    }
    }

	/**
	 * Stop this request from writing its copy of the session back. The copy is
	 * read when the request starts, so a long request that saves it undoes
	 * whatever other requests saved meanwhile.
	 */
	public function suspend_persistence() {
		$this->_persist = false;
	}

	/**
	 * Store one key against the session as stored now, not as this request read it.
	 *
	 * @param string $key
	 * @param mixed  $value
	 */
	public function save_key( $key, $value ) {
		$key   = sanitize_key( $key );
		$value = maybe_serialize( $value );

		$this->_data[ $key ] = $value;

		if ( ! $this->has_session() ) {
			return;
		}

		wp_cache_delete( 'notoptions', 'options' );
		wp_cache_delete( '_wpallimport_session_' . $this->_import_id . '_', 'options' );

		$stored = $this->get_session_data();
		if ( ! is_array( $stored ) ) {
			$stored = array();
		}
		$stored[ $key ] = $value;

		$this->write_session_data( $stored );
	}

	private function write_session_data( $data ) {
		$session_option        = '_wpallimport_session_' . $this->_import_id . '_';
		$session_expiry_option = '_wpallimport_session_expires_' . $this->_import_id . '_';

		wp_cache_delete( 'notoptions', 'options' );
		wp_cache_delete( $session_option, 'options' );
		wp_cache_delete( $session_expiry_option, 'options' );

		if ( false === get_option( $session_option ) )
		{
			add_option( $session_option, base64_encode(serialize($data)), '', 'no' );
			add_option( $session_expiry_option, $this->_session_expiration, '', 'no' );
		} else {
			update_option( $session_option, base64_encode(serialize($data)) );
		}
	}

    public function convertData( $import_id ){

    	$this->_import_id = 'new';

    	$this->_data = $this->get_session_data();

    	$this->set_session_expiration();    	
    	
    	$this->_import_id = $import_id;

    	$this->clean_session();        	

		$this->_dirty = true;

		$this->save_data();

		$parser_type = get_option('wpai_parser_type_0');

		if ( ! empty($parser_type) ){
			update_option('wpai_parser_type_' . $import_id, $parser_type, false);
			delete_option('wpai_parser_type_0');
		}
    }

    public function clean_session( $import_id = 'new' ){

    	global $wpdb;

		// Bail rather than fall back to 'new' the way generate_import_id()
		// does. That default is a read there and a DELETE here: an id this
		// method cannot use names no session, and treating it as 'new' would
		// destroy the wizard session of whoever made the request. Callers pass
		// the id straight from the request — controllers/admin/manage.php
		// reaches here on ?action=update with no nonce.
		if ( ! self::is_usable_import_id( $import_id ) ) {
			return;
		}

		$now                = time();
		$expired_sessions   = array();
		$like = $wpdb->esc_like( '_wpallimport_session_expires_' . $import_id . '_' ) . '%';
		$wpallimport_session_expires = $wpdb->get_results( $wpdb->prepare("SELECT option_name, option_value FROM $wpdb->options WHERE option_name LIKE %s", $like) );			
		
		$expired_sessions[] = "_wpallimport_session_{$import_id}_"; // Session key

		foreach ( $wpallimport_session_expires as $wpallimport_session_expire ) {
			//if ( $now > intval( $wpallimport_session_expire->option_value ) ) {
				//$session_id         = substr( $wpallimport_session_expire->option_name, 29 );
				$expired_sessions[] = $wpallimport_session_expire->option_name;  // Expires key
				//$expired_sessions[] = "_wpallimport_session_$session_id"; // Session key
			//}
		}

		if ( ! empty( $expired_sessions ) ) {
			wp_cache_delete( 'notoptions', 'options' );
			foreach ($expired_sessions as $expired) {				
				wp_cache_delete( $expired, 'options' );		
				delete_option($expired);
			}
			$expired_sessions_chunked = array_chunk( $expired_sessions, 100 );

			foreach ( $expired_sessions_chunked as $chunk ) {
				$placeholders = implode( ',', array_fill( 0, count( $chunk ), '%s' ) );
				// phpcs:ignore WordPress.DB.PreparedSQL,WordPress.DB.PreparedSQLPlaceholders
				$wpdb->query( $wpdb->prepare( "DELETE FROM $wpdb->options WHERE option_name IN ($placeholders)", $chunk ) );
			}			
		}
    }
}